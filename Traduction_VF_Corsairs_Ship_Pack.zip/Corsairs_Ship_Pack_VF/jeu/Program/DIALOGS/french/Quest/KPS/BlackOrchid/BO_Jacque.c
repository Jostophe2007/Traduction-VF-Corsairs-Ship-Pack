// Gregg: Jacque, the vagrant in George Bryan's house - the "Black Orchid" trilogy
// (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// Nodes 1-7 - downstairs by the chest, three ways to send him up; 8-15 - upstairs,
// where he remembers the business with the lost key.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Trois cents gaillards pour un tonneau de vin ! Hic... Ou comment c'est, déjà ? Hé, et vous, qui êtes-vous ?";
			link.l1 = "Et vous, qui êtes-vous ? Que faites-vous dans la maison de George Bryan ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Hic... Et en quoi ça vous regarde ? Allez-vous-en ! Hic...";
			link.l1 = "Je suis un ami de Bryan. Alors, que faites-vous dans sa maison ?";
			link.l1.go = "3";
			link.l2 = "Bryan a oublié de me rendre quelque chose, et j'en ai grand besoin. Je vais jeter un coup d'œil, si ça ne vous dérange pas ?";
			link.l2.go = "6";
			link.l3 = "Tais-toi, épave. Je suis venu reprendre ce qui est à moi. Couine encore une fois, et ce sera pire pour toi.";
			link.l3.go = "7";
		break;

		case "3":
			dialog.text = "Un ami ? De Bryan ? Mais moi aussi, je suis un ami de Bryan. Hic... Faisons connaissance. Jacque. Jacque tout court.";
			link.l1 = "Vous ne m'avez pas répondu. Que faites-vous dans sa maison ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Eh bien, voyez-vous... c'est lui qui me l'a proposé, de rester ici pendant son absence. דa fait un bon moment que je suis là. Pas mal, cette petite maison. Et vous, qu'est-ce qui vous amène ?";
			link.l1 = "Je viens reprendre une chose. Bryan a une mémoire de passoire, il a oublié de me la rendre. Je peux jeter un coup d'œil ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Allez-y. Et moi, je vais m'allonger, je suis très fatigué.";
			link.l1 = "Sage décision. Allez cuver votre vin, et moi, je vais chercher.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInHouseGeorgeBryanJacqueToRoom");
		break;

		case "6":
			dialog.text = "Allez-y, alors. Hic... Et moi, je vais dormir.";
			link.l1 = "Parfait.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInHouseGeorgeBryanJacqueToRoom");
		break;

		case "7":
			dialog.text = "Quoi ?! On va voir qui est l'épave ici. Hic... Dégaine ! Quoi, tu as perdu ton courage ? C'est bien ça. Vous êtes tous très forts en paroles, mais quand il s'agit de se battre, il n'y a plus personne. Hic... J'ai peut-être bu un coup de trop. Je vais dormir.";
			link.l1 = "Il était temps. Allez, file.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInHouseGeorgeBryanJacqueToRoom");
		break;

		case "8":
			dialog.text = "Hic... Et maintenant, quoi ? Je venais juste de m'installer, et vous voilà.";
			link.l1 = "Vous savez oם est la clé du coffre d'en bas ? Ce qu'il me faut est dedans, et sans la clé, il ne s'ouvre pas.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Je ne peux pas vous aider, désolé. Bryan a perdu cette clé.";
			link.l1 = "Perdue ? Il y a combien de temps ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Je ne me rappelle pas... Non, attendez, ça me revient. Il y a deux semaines jour pour jour. Ce jour-là, Bryan et moi avons déclenché une belle bagarre à la taverne, on s'en souviendra longtemps. Et après, Bryan s'est aperçu qu'il n'avait plus la clé. Il voulait la chercher, mais le tavernier l'a jeté dehors. Bryan s'est vexé et s'en est pris à un mousquetaire.";
			link.l1 = "Un mousquetaire ? Et ensuite ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Rien. Il a assommé Bryan d'un coup de crosse. Bryan est resté étendu devant la porte jusqu'au matin.";
			link.l1 = "Le tavernier aurait peut-être trouvé la clé ? Ou la serveuse ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Le tavernier, non, c'est certain : on l'aurait su. Et la serveuse s'est tout de suite cachée dans un coin, et elle n'a pas montré le bout de son nez avant la fin. Elle n'a pas pu la trouver.";
			link.l1 = "Et plus tard, quand elle a fait le ménage ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Non, le tavernier a fait le ménage tout seul. Il l'a renvoyée chez elle tout de suite, elle était morte de peur.";
			link.l1 = "Un client l'aurait peut-être ramassée ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Qu'est-ce que vous avez à me harceler avec votre clé ! Je veux dormir.";
			link.l1 = "Ha. Vous dormez assez bien comme ça. Au moins, vous êtes arrivé jusqu'au lit.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Je suis très bien comme je suis. Assez, vous m'avez épuisé. Laissez-moi dormir !";
			link.l1 = "D'accord, d'accord, je m'en vais.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxTavern");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
