// Gregg: Captain Mowgli - quest "The Monkey Ship" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\captainmonkey.c
// Nodes 1-2 - the first meeting in the grotto, 3-4 - the talk after the hopeless
// fight (these are new: in the original the player simply lost and was stripped),
// 5-8 - the cabin of the "Banana Paradise" during the final boarding.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Qu'est-ce que tu regardes ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Hé, l'ami, quel bon vent t'amène ici ? Eh bien, qu'est-ce que tu regardes ? On dirait que tu n'as jamais vu un singe qui parle de ta vie.";
			link.l1 = "Franchement, non. Je n'ai jamais eu ce plaisir : ni singe ni éléphant... Difficile à croire : même pas une girafe !";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Tu fais de l'esprit, hein ? Et aux dépens du capitaine Mowgli ! Maintenant, tu vas apprendre ce que ça veut dire, mille bananes pourries !";
			link.l1 = "?!";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyBattleWithCaptainInGrot");
		break;

		// Gregg: reached by lasting forty-five seconds against him, or by dropping
		// to five hit points - whichever comes first. Blade away, and a talk.
		case "3":
			dialog.text = "Tu en as eu assez ? Tu peux agiter ce bout de ferraille jusqu'à la fin des temps, il ne m'aura pas. Range-le avant de te faire mal.";
			link.l1 = "Que diable es-tu donc ? J'ai mis tout ce que j'avais dans ces coups, et tu n'es même pas essoufflé.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Moi ? Je suis le capitaine Mowgli, et on ne peut pas me tuer. Pas du tout. Et toi, reste assis ici un moment et réfléchis à ta conduite : mes gars vont te surveiller. Peut-être que tu deviendras plus sage.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyReloadInGrot");
		break;

		case "5":
			dialog.text = "Tu es le premier que je vais devoir battre deux fois ! Comment es-tu arrivé ici, espèce de noix de coco fêlée ?";
			link.l1 = "Je vais te tuer, Mowgli.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "L'espoir fait vivre la jeunesse ! J'ai bien peur qu'une nouvelle déception t'attende.";
			link.l1 = "Je vais te tuer, Mowgli.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Tu ne me battras jamais ! Tu ne comprends pas à qui tu as affaire.";
			link.l1 = "Mieux que tu ne le crois. Ton contrat avec le démon n'est plus qu'une poignée de cendres. Belle nouvelle, non ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Que le diable l'emporte, comment as-tu fait pour l'atteindre ?! Voilà qui complique un peu les choses... Mais quoi qu'il en soit, tu vas mourir !";
			link.l1 = "Non. C'est moi qui vais te tuer, Mowgli.";
			link.l1.go = "exit";
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
