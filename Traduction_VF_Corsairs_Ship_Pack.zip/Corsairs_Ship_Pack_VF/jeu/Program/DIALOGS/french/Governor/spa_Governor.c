// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
    int i, iTemp, iMoney, ShipType, Rank;
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_Novaya_Rodina.Guber") && pchar.questTemp.PDM_Novaya_Rodina.Guber == "HugoLesopilka")	//Квест "A New Homeland.". Спрашиваем про Лесопилку.
			{
				link.l2 = "L'un des pirates veut entrer à votre service. Il est prêt à payer 10 000 pièces d'or pour une lettre de marque qui lui permettra de servir sous vos ordres.");
				link.l2.go = "HugoLesopilka_1";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_Novaya_Rodina.Guber") && pchar.questTemp.PDM_Novaya_Rodina.Guber == "Lubopitno")	//Квест "A New Homeland.". Спрашиваем про Лесопилку.
			{
				link.l2 = "Qu'en est-il de ce Hugo Sawmill ?");
				link.l2.go = "HugoLesopilka_Lubopitno_1";
			}
		break;

		case "work_1":  // работа на благо короны - линейка нации
            // сюда вход только с патентом, проверка выше
			//if (CheckAttribute(npchar, "notQuestLine"))
			//{
            //    dialog.text = "Unfortunately, I cannot provide you with a job. You are not the person I would like to entrust my affairs to. Goodbye.";
            //    link.l1 = "Wow...";
            //    link.l1.go = "exit";
			//	break;
			//}
            dialog.text = LinkRandPhrase("Vous êtes au service de l'Espagne ! Je vous prie de commencer immédiatement la mission qui vous a été confiée !",
                                         "Commencez immédiatement à remplir vos obligations !",
                                         "J'attends votre rapport sur l'exécution de ma mission de confiance, pas des bavardages.");
            link.l1 = RandPhraseSimple("Je commence immédiatement, señor gouverneur général", "Je suis déjà en train de m'en occuper...");
            link.l1.go = "exit";

        	switch (pchar.questTemp.State)   // что делаем в данный момент
            {
                case "empty":   // Нет взятых квестов
                    if (GetQuestPastDayParam("questTemp") < sti(pchar.questTemp.Waiting_time))
                    {
                        dialog.text = LinkRandPhrase("Je n'ai pas de mission de confiance pour vous pour le moment. Vous pouvez revenir à ma résidence plus tard...",
                                                     "Veuillez m'excuser, je suis très occupé en ce moment !",
                                                     "Occupez-vous de vos affaires pour l'instant, je n'ai pas de mission pour vous en ce moment.");
                        link.l1 = "Très bien, señor gouverneur général.";
                        link.l1.go = "exit";
                    }
                    else
                    {
						switch(pchar.questTemp.CurQuestNumber)   // Взятие квестов начиная со второго
                        {
                            case "2":
                                dialog.text = "Ah, vous voilà, " + pchar.name + " ! On dit que vous avez fait preuve d'un courage et d'une ingéniosité rares ! J'ai le plaisir de vous informer que les personnes que vous avez sauvées sont déjà en route pour la Castille. Leur gratitude ne connaît littéralement pas de bornes. Nos amis de Port Royal rapportent des choses vraiment fantastiques : ils disent que vous avez taillé en pièces les geכliers anglais !";
                                link.l1 = "La peur exagère tout, don Francisco...";
                                link.l1.go = "Step_2_1";
                            break;
                            case "3":
                                dialog.text = "Content de vous revoir, "+ GetSexPhrase("mon ami","señorita") +". Je veux vous proposer une affaire, et je pense qu'elle sera à votre goמt.";
                                link.l1 = "Je suis tout ouïe.";
                                link.l1.go = "Step_3_1";
                            break;
                            case "4":
                                dialog.text = "וcoutez, j'ai une mission très inhabituelle cette fois.";
                                link.l1 = "Je vous écoute attentivement, don Francisco.";
                                link.l1.go = "Step_4_1";
                            break;
                            case "5":
                                dialog.text = "Je vous place à la disposition du gouverneur de Santiago, José Sancho Jimenez.";
                                link.l1 = "Que dois-je faire ?";
                                link.l1.go = "Step_5_1";
                            break;
                            case "6":
                                dialog.text = "J'ai une mission pour vous. Commençons par le contexte...";
                                link.l1 = "Je vous écoute attentivement, don Francisco.";
                                link.l1.go = "Step_6_1";
                            break;
                            case "7":
                                dialog.text = "Notre glorieux corsaire Manoel Rivero Pardal rכde en ce moment au large d'Antigua à la recherche de navires marchands anglais. J'ai reçu des informations selon lesquelles des flibustiers français, sous le commandement de Moses Vauclain, sont partis l'intercepter. Hâtez-vous vers Antigua et apportez à Pardal l'aide nécessaire. C'est un symbole de notre courage !";
                                link.l1 = "Compris, don Francisco. Je commence immédiatement.";
                                link.l1.go = "exit";
								pchar.questTemp.State = "Sp7SavePardal_toAntigua";
								AddQuestRecord("Spa_Line_7_SavePardal", "1");
								Pchar.quest.Sp7SavePardal_FightNearAntigua.win_condition.l1 = "location";
								Pchar.quest.Sp7SavePardal_FightNearAntigua.win_condition.l1.location = "Antigua";
								Pchar.quest.Sp7SavePardal_FightNearAntigua.win_condition = "Sp7SavePardal_FightNearAntigua";
							break;
                            case "8":
                                dialog.text = "Vous tombez à pic. J'ai une mission très importante pour vous. Le fait est que le célèbre flibustier, le capitaine Ansel, a réussi à unir des corsaires anglais et français pour attaquer Cumaná.";
                                link.l1 = "Don Francisco, avez-vous des informations sur la taille et la composition de cette escadre ?";
                                link.l1.go = "Step_8_1";
                            break;
                            case "9":
                                dialog.text = "Vous devez vous rendre immédiatement à Portobelo. Le gouverneur de la ville vous y attend, il vous confiera une mission.";
                                link.l1 = "Señor, pourriez-vous me décrire dans les grandes lignes ce que je dois faire ?";
                                link.l1.go = "Step_9_1";
                            break;
                            case "10":
                                dialog.text = "Je vous prie de vous rendre immédiatement chez le gouverneur de la ville de Maracaibo pour remplir une mission de confiance.";
                                link.l1 = "Encore, don Francisco ?";
                                link.l1.go = "Step_10_1";
                            break;
                            case "11":
                                dialog.text = "זtes-vous prêt pour une opération sérieuse : prendre d'assaut des villes fortifiées ?";
                                link.l1 = "Toujours prêt, señor gouverneur général";
                                link.l1.go = "Step_11_1";
                            break;
                            case "12":
                                dialog.text = "Ah, vous voilà, capitaine ! Je vous attendais...";
                                link.l1 = "Toujours à votre service, don Francisco.";
                                link.l1.go = "Step_12_1";
                            break;
						}
                    }
                break;

                case "":           // Квест №1, Спасти горожан от Моргана.
                    dialog.text = "Bien, bien, capitaine, on m'a informé de votre arrivée.";
                    link.l1 = "C'est un grand honneur pour moi, don Francisco. Je ne m'attendais pas à ce que mon humble personne retienne l'attention d'un si haut personnage.";
                    link.l1.go = "Step_1_1";
                break;
                case "SaveFromMorgan_OutOfPrison":
                    dialog.text = "Faites votre rapport sur le sauvetage des prisonniers.";
                    link.l1 = "Votre ordre a été exécuté, señor gouverneur général.";
                    link.l1.go = "Step_1_7";
                break;
                case "Inquisition_backBad":
                    dialog.text = "Ah, vous voilà de retour, très bien. Comment s'est passée l'affaire que la Sainte Inquisition vous a confiée ?";
                    link.l1 = "Pas très bien, don Juan. Mais rien de terrible ne s'est produit, ce qui, en fait, est réjouissant.";
                    link.l1.go = "Step_2_3";
                break;
                case "Inquisition_backPartGood":
                    dialog.text = "Ah, vous voilà de retour, très bien. Comment s'est passée l'affaire que la Sainte Inquisition vous a confiée ?";
                    link.l1 = "Plus ou moins bien, don Juan. Les instructions ont été en partie exécutées, ce qui, en fait, n'est pas mal non plus.";
                    link.l1.go = "Step_2_3";
                break;
                case "Inquisition_backAllGood":
                    dialog.text = "Ah, vous voilà de retour, très bien. Comment s'est passée l'affaire que la Sainte Inquisition vous a confiée ?";
                    link.l1 = "Un succès complet, don Francisco. Tout a été fait au mieux, la Sainte Inquisition est extrêmement satisfaite.";
                    link.l1.go = "Step_2_3";
                break;
                case "TakeRockBras_RockSink":
                    dialog.text = "Alors, que me dites-vous de Rock le Brésilien ?";
                    link.l1 = "J'ai attaqué sa corvette dans les eaux cכtières de Maracaibo, oם il chassait nos galions. Je suis désolé, don Francisco, mais je n'ai pas pu le prendre vivant : il a sombré avec son navire...";
                    link.l1.go = "Step_3_6";
                break;
                case "TakeRockBras_DieHardRock":
                    dialog.text = "Alors, que me dites-vous de Rock le Brésilien ?";
                    link.l1 = "J'allais attaquer sa corvette dans les eaux cכtières de Maracaibo, oם il chassait nos galions. Malheureusement, pour des raisons indépendantes de ma volonté, j'ai dמ quitter les eaux oם se trouvait Rock le Brésilien. Il m'a échappé...";
                    link.l1.go = "Step_3_6";
                break;
                case "TakeRockBras_RockTaken":
                    dialog.text = "Alors, que me dites-vous de Rock le Brésilien ?";
                    link.l1 = "Il est dans ma cale, don Francisco.";
                    link.l1.go = "Step_3_7";
                break;
                case "TakeRockBras_RockGiven":
                    dialog.text = "Oui, oui, on m'a déjà informé de la livraison réussie du Brésilien à Santiago. Je peux vous féliciter.";
                    link.l1 = "Merci, don Francisco. Que puis-je faire d'autre pour vous ?";
                    link.l1.go = "Step_3_8";
                break;
                case "TakeRockBras_WaitTwoDays":
                if (GetQuestPastDayParam("questTemp") > 2)
                    {
                        dialog.text = "Eh bien, comme je m'y attendais, le corsaire tant vanté n'a pas pu supporter longtemps la question telle qu'on la pratique à la Sainte Inquisition.";
                        link.l1 = "On l'a donc torturé ?";
                        link.l1.go = "Step_3_9";
                    }
                    else
                    {
                        dialog.text = "Je vous avais demandé de revenir dans deux jours, pas avant.";
                        link.l1 = "Excusez-moi, señor gouverneur général.";
                        link.l1.go = "exit";
                    }
                break;
                case "TakeRockBras_SeekRocksMoney":
                    dialog.text = "Eh bien, dites-moi, qu'avez-vous réussi à trouver des trésors du Brésilien ?";
                    link.l1 = "Rien de nouveau pour l'instant, señor gouverneur général. Mais je reste à l'affמt...";
                    link.l1.go = "exit";
                    if (sti(pchar.money) > 500000)
                    {
                        link.l2 = "Don Francisco, je suis prêt à faire mon rapport : les recherches sont terminées.";
                        link.l2.go = "Step_3_10";
                    }
                break;
                case "Sp4Detection_toMirderPlace":
                    dialog.text = "Avez-vous réussi à apprendre quelque chose sur cette affaire ?";
                    link.l1 = "J'y travaille, don Francisco, mais je n'ai encore rien pu apprendre...";
                    link.l1.go = "exit";
                break;
                case "Sp4Detection_toGovernor":
                    dialog.text = "Rapportez-moi ce que vous avez appris sur ce meurtre.";
                    link.l1 = "J'ai réussi à apprendre que l'assassin présumé ressemblerait à un ladron. Je crois que les traces du crime mènent à Tortuga.";
                    link.l1.go = "Step_4_6";
                break;
                case "Sp4Detection_toDEstre":
                    dialog.text = "J'attends avec impatience votre rapport sur l'enquête à Tortuga";
                    link.l1 = "Don Francisco, j'ai appris à Tortuga qu'une certaine doña Anna vit chez Bertrand d'Ogeron, qui l'entretient. On peut supposer qu'il s'agit de doña Anna Ramirez de Leyva, mais je ne peux pas l'affirmer avec certitude.";
                    link.l1.go = "Step_4_9";
                break;
                case "Sp4Detection_toDEstre_1":
                    dialog.text = "J'attends avec impatience votre rapport sur l'enquête à Tortuga";
                    link.l1 = "Don Francisco, j'ai appris à Tortuga qu'une certaine doña Anna vit chez Bertrand d'Ogeron, qui l'entretient. On peut supposer qu'il s'agit de doña Anna Ramirez de Leyva, mais je ne peux pas l'affirmer avec certitude.";
                    link.l1.go = "Step_4_9";
                break;
                case "Sp4Detection_toDEstre_2":
                    dialog.text = "J'attends avec impatience votre rapport sur l'enquête à Tortuga";
                    link.l1 = "Don Francisco, j'ai appris à Tortuga qu'une certaine doña Anna vit chez Bertrand d'Ogeron, qui l'entretient. De plus, j'ai réussi à rattraper l'homme de confiance du gouverneur général, un certain Henri d'Estre.";
                    link.l1.go = "Step_4_10";
                break;
                case "Sp4Detection_DEstreIsDead":
                    dialog.text = "Faites votre rapport : oם en est votre enquête ?";
                    link.l1 = "J'ai tout découvert. Le fait est que l'épouse de don José Ramirez de Leyva s'est enfuie de son plein gré chez le gouverneur général de Tortuga, d'Ogeron.";
                    link.l1.go = "Step_4_14";
                break;
                case "Sp5LaVegaAttack_BackToHavana":
                    dialog.text = "Oui, oui, je suis déjà au courant de votre nouvelle entreprise réussie. Eh bien, je ne doutais pas que la place à Hispaniola pour l'installation de nos colons de l'Ancien Monde serait dמment nettoyée.";
                    link.l1 = "Les boucaniers, c'est fini, don Francisco. Et Edward Mansfield a été tué de ma main !";
                    link.l1.go = "Step_5_3";
                break;
                case "Sp6TakeMess_waitMessanger":
                    dialog.text = "Alors, content de vous voir, "+ GetSexPhrase("capitaine","señorita") +".";
                    link.l1 = "Moi aussi, don Francisco, c'est un plaisir.";
                    link.l1.go = "Step_6_4";
                break;
                case "Sp6TakeMess_Action":
                    dialog.text = "Alors, content de vous voir, "+ GetSexPhrase("capitaine","señorita") +".";
                    link.l1 = "Moi aussi, don Francisco, c'est un plaisir.";
                    link.l1.go = "Step_6_4";
                break;
                case "Sp7SavePardal_PardalIsSink":
                    dialog.text = "Faites votre rapport sur les résultats de la mission.";
                    link.l1 = "Señor, je n'ai pas pu sauver Pardal : ses galions ont été coulés par des forces bien supérieures. Manoel lui-même est mort...";
                    link.l1.go = "Step_7_1";
                break;
                case "Sp7SavePardal_GoodWork":
                    dialog.text = "Faites votre rapport sur les résultats de la mission.";
                    link.l1 = "Señor, les informations que vous aviez reçues se sont révélées fiables. J'ai cinglé vers Antigua toutes voiles dehors et j'ai rejoint Pardal juste à temps : lui et deux galions de son escadre combattaient déjà des forces supérieures de pirates français. Ensemble, nous avons réussi à vaincre un ennemi puissant : les navires des flibustiers ont sombré !";
                    link.l1.go = "Step_7_3";
                break;
                case "Sp7SavePardal_2GoodWork":
                    dialog.text = "Faites votre rapport sur les résultats de la mission.";
                    link.l1 = "Señor, les informations que vous aviez reçues se sont révélées fiables. J'ai cinglé vers Antigua toutes voiles dehors et j'ai rejoint Pardal juste à temps : deux de ses galions combattaient déjà des forces supérieures de pirates français. Ensemble, nous avons réussi à vaincre un ennemi puissant : les navires des flibustiers ont sombré !";
                    link.l1.go = "Step_7_3";
                break;
                case "Sp7SavePardal_DieHard":
                    dialog.text = "Faites votre rapport sur les résultats de la mission.";
                    link.l1 = "Señor gouverneur général, malheureusement, cette mission s'est révélée au-dessus de mes forces. Je n'ai pas pu aider Pardal.";
                    link.l1.go = "Step_7_6";
                break;
                case "Sp8SaveCumana_YouLate":
                    dialog.text = "Quelques réfugiés de Cumaná sont déjà arrivés ici. Vous n'avez pas su sauver la ville et ses habitants.";
                    link.l1 = "J'ai cinglé vers Cumaná toutes voiles dehors, sans m'arrêter nulle part, pas même une minute. Mais je n'ai quand même pas eu le temps : c'était tout simplement impossible.";
                    link.l1.go = "Step_8_5";
					pchar.questTemp.Waiting_time = "20";
                break;
                case "Sp8SaveCumana_DieHard":
                    dialog.text = "Quelques réfugiés de Cumaná sont déjà arrivés ici. Vous n'avez pas su sauver la ville et ses habitants.";
                    link.l1 = "L'escadre de ladrones réunie était si puissante que nous n'avons pas pu en venir à bout. Avec les forces dont je disposais, c'était tout simplement impossible.";
                    link.l1.go = "Step_8_5";
					pchar.questTemp.Waiting_time = "40";
                break;
                case "Sp8SaveCumana_GoodWork":
                    dialog.text = "On m'a déjà informé que Cumaná a été sauvée. Parfait !";
                    link.l1 = "Nous avons réussi à couler la flotte des ladrones. Il n'y a aucun survivant...";
                    link.l1.go = "Step_8_6";
                break;
                case "Sp9SaveCumana_BackHavana":
                    dialog.text = "Rapportez-moi ce qui vous est arrivé ?";
                    link.l1 = "Don Francisco, le gouverneur général de Portobelo m'a confié la mission d'escorter quatre galions chargés d'or jusqu'à l'île inhabitée des Caïmans...";
                    link.l1.go = "Step_9_2";
                break;
                case "Sp10Maracaibo_DieHard":
                    dialog.text = "On m'a informé que Maracaibo a été prise et qu'un protectorat anglais y a été établi !";
                    link.l1 = "Oui, sans doute, monsieur.";
                    link.l1.go = "Step_10_6";
                break;
                case "Sp10Maracaibo_GoodWork":
                    dialog.text = "Je suis déjà au courant, vous avez fait un travail brillant !";
                    link.l1 = "Cette fois, nous avons dמ couler les navires des pirates anglais.";
                    link.l1.go = "Step_10_11";
                break;
                case "Sp10Maracaibo_2GoodWork":
                    dialog.text = "Je suis déjà au courant, vous avez fait un travail brillant !";
                    link.l1 = "Cette fois, nous avons dמ couler les navires des pirates anglais.";
                    link.l1.go = "Step_10_9";
                break;
                case "DestrHolland_GoOn":
                    dialog.text = "Vous n'avez encore réussi à prendre ni Willemstad ni Marigot...";
                    link.l1 = "Señor gouverneur général, je m'en occupe. La mission n'est pas facile, elle exige une sérieuse préparation.";
                    link.l1.go = "exit";
                    if (CheckAttribute(pchar, "questTemp.Q11_Villemstad"))
                    {
                        dialog.text = "Vous avez ruiné Willemstad, parfait ! Maintenant, c'est au tour de Marigot !";
                        link.l1 = "Exactement, don Francisco...";
                        link.l1.go = "exit";
                    }
                    if (CheckAttribute(pchar, "questTemp.Q11_Marigo"))
                    {
                        dialog.text = "Excellent, Marigot est ruinée ! Mais j'attends aussi que vous preniez et ruiniez Willemstad.";
                        link.l1 = "Je ferai tout, señor gouverneur.";
                        link.l1.go = "exit";
                    }
                    if (CheckAttribute(pchar, "questTemp.Q11_Villemstad") && CheckAttribute(pchar, "questTemp.Q11_Marigo"))
                    {
                        dialog.text = "Marigot et Willemstad ont été prises d'assaut et ruinées ! Beau travail, "+ GetSexPhrase("mon ami","" + pchar.name + "") +" !";
                        link.l1 = "C'est fait, don Francisco...";
                        link.l1.go = "Step_11_3";
                    }
                break;
                case "OccupyPortPax_WeWin":
                    dialog.text = "Eh bien, on peut féliciter l'Escurial pour cette digne acquisition. L'île d'Hispaniola est à nous !";
                    link.l1 = "Exactement, señor gouverneur général. J'ai réussi à prendre Port-au-Prince.";
                    link.l1.go = "Step_12_4";
                break;
                case "QuestLineBreake":
                    dialog.text = "Je ne traite pas avec les gens qui manquent à leur parole. Je n'ai rien de plus à vous dire.";
                    link.l1 = "...";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
                case "EndOfQuestLine":
                    dialog.text = ""+ GetSexPhrase("Don","Doña") +" " + pchar.name + ", l'Escurial vous donne toute liberté d'action dans l'intérêt de l'Espagne. Agissez par vous-même.";
                    link.l1 = "Très bien, don Francisco.";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
			}
        break;
        //********************** Квест №1, Спасти горожан от Моргана. ************************
        case "Step_1_1":
            dialog.text = "Mon attention se mérite en œuvrant pour le bien de la grande Castille, ce que vous, capitaine, n'avez pas encore fait.\n"+
                          "Mais vous avez un navire et une lettre de marque espagnole, ce qui est important pour mon pays. Surtout maintenant que les ennemis de l'Espagne ont relevé la tête et essaient de prendre leur revanche sur toutes leurs défaites passées.";
            link.l1 = "La situation de l'Espagne est-elle vraiment si grave ?";
            link.l1.go = "Step_1_2";
        break;
        case "Step_1_2":
            dialog.text = "Oui, même si, à première vue, tout semble en ordre. La richesse et la puissance de l'Espagne ont toujours fait l'envie des monarchies européennes. Maintenant que nos ennemis sont prêts à s'attacher des bandits de tout poil, la situation est devenue terriblement difficile.\n"+
                          "Les attaques contre nos colonies et nos caravanes marchandes se sont multipliées, et les enlèvements de citoyens fortunés contre rançon sont devenus monnaie courante. Les pirates ont littéralement envahi toutes les routes commerciales, ce qui rend la navigation dans ces eaux très dangereuse.\n"+
                          "L'Escurial est furieux, Sa Majesté la reine mère exige des mesures immédiates et décisives pour mettre un terme aux activités illégales des ladrones de tout poil. Pour atteindre ce but, il a été décidé de combattre l'ennemi avec ses propres méthodes, c'est-à-dire d'engager des corsaires au service de la Couronne.";
            link.l1 = "On dirait que j'arrive à point nommé...";
            link.l1.go = "Step_1_3";
        break;
        case "Step_1_3":
            dialog.text = "On dirait bien. Hier encore, quelqu'un comme vous ne pouvait compter que sur le bמcher de la Sainte Inquisition ou sur une corde de chanvre. Mais les temps ont changé. Prouvez votre dévouement à notre Seigneur et à la Castille, et vous aurez tout : la richesse, la gloire, les honneurs et les récompenses.";
            link.l1 = "Voilà qui sonne bien. Je suis prêt à passer directement à l'exécution du travail.";
            link.l1.go = "Step_1_4";
        break;
        case "Step_1_4":
            dialog.text = "Eh bien, passons aux affaires.\n"+
                          "Trois de nos honorables concitoyens ont été capturés par des pirates anglais. Et la rançon que demande Henry Morgan, connu pour sa ruse, dépasse tout ce qui est raisonnable et concevable. Ce bandit exige 500 000 en or ! Vous devrez entrer dans Port Royal, libérer nos concitoyens de prison et me les ramener sains et saufs.\n"+
                          "Vous devez vous introduire dans la prison et surprendre les gardes. Les prisonniers sont gardés de très près, l'évasion sera donc découverte immédiatement. C'est pourquoi il est préférable de débarquer dans une baie isolée, loin du fort. En aucun cas vous ne devez mettre en danger la vie des personnes qui vous seront confiées, c'est une exigence catégorique.\n"+
                          "Avez-vous tout compris ?";
            link.l1 = "Oui, señor gouverneur général.";
            link.l1.go = "Step_1_5";
        break;
        case "Step_1_5":
            dialog.text = "Vous avez un mois pour libérer les prisonniers, pas plus. Préparez-vous et mettez-vous en route.";
            link.l1 = "Je commence immédiatement.";
            link.l1.go = "Step_1_6";
        break;
        case "Step_1_6":
            SaveCurrentQuestDateParam("questTemp");
    		// остальные линейки в сад -->
    		pchar.questTemp.NationQuest = SPAIN;
    		// остальные линейки в сад <--
    		pchar.questTemp.State = "SaveFromMorgan_toPrison";
            AddQuestRecord("Spa_Line_1_SaveCitizens", "1");
            for (i=1; i<=3; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("SpaPrisoner"+i, "usurer_"+i, "man", "man", 10, SPAIN, -1, false));
                sld.Dialog.Filename = "Quest\SpaLineNpc_1.c";
                LAi_SetCitizenType(sld);
            	LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
                ChangeCharacterAddressGroup(sld, "PortRoyal_Prison", "goto", "goto9");
            }
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;
        case "Step_1_7":
            dialog.text = "Eh bien, vous avez fait le premier pas sur la voie épineuse d'une carrière au service de Sa Majesté la reine mère Marie-Anne d'Autriche. Recevez vos 50 mille honnêtement gagnés. Je suis content de ne pas m'être trompé sur votre compte.";
            link.l1 = "Merci, monsieur le gouverneur général. Au fait, vous êtes un excellent mathématicien.";
            link.l1.go = "Step_1_8";
        break;
        case "Step_1_8":
            dialog.text = "De quoi parlez-vous ?";
            link.l1 = "Eh bien, si vous ajoutez un « 0 » aux 50 mille que j'ai reçus, vous obtiendrez la somme que vous ne vouliez pas donner à Henry Morgan.";
            link.l1.go = "Step_1_9";
        break;
        case "Step_1_9":
            dialog.text = "Ah, c'est donc ce que vous voulez dire. Bien sמr, nous pouvons nous permettre de payer une rançon aussi fabuleuse, prouvant ainsi que nos concitoyens nous sont chers, mais alors, ces 50 mille ne seraient pas si confortablement dans votre poche, n'est-ce pas ?";
            link.l1 = "Oh oui, monsieur. Vous m'avez donné un exemple des plus instructifs !";
            link.l1.go = "Step_1_10";
        break;
        case "Step_1_10":
            dialog.text = "Dans ce cas, je n'ose pas vous retenir plus longtemps... Passez à ma résidence de temps en temps.";
            link.l1 = "Très bien, monsieur.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "2";
			if (startherotype == 2)
			{
				pchar.questTemp.CurQuestNumber = "4";
			}
            pchar.questTemp.Waiting_time = "7";
            CloseQuestHeader("Spa_Line_1_SaveCitizens");
            AddMoneyToCharacter(pchar, 50000);
            for (i=1; i<=3; i++)
            {
                sld = characterFromId("SpaPrisoner"+i);
                RemovePassenger(pchar, sld);
         	    sld.LifeDay = 0; // уберём нпс
            }
			AddTitleNextRate(sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Pistol", 150);
			AddCharacterExpToSkill(pchar, "Grappling", 120);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Vous savez, notre glorieux gouverneur général Oregon y Gascon a engagé le capitaine " + GetMainCharacterNameGen() + " pour libérer nos concitoyens capturés par ce diable de Morgan. Et vous savez, la mission a été accomplie avec succès.", SPAIN, 5, 1);
		break;
        //********************** Квест №2, задания Инквизиции. ************************
        case "Step_2_1":
            dialog.text = "Votre modestie vous honore... Eh bien, il est temps de passer à un nouveau travail. Un jésuite de haut rang, Antonio de Souza, est venu chez nous et a demandé un officier de sang-froid, courageux et honnête.\n"+
                          "Je vous ai recommandé. Rendez-vous à Santiago, oם se trouve le Saint-Office de l'Inquisition pour les Caraïbes, et trouvez de Souza. Faites tout ce qu'il vous ordonnera, sans vous poser de questions. Avez-vous des questions ?";
            link.l1 = "Non, señor gouverneur général.";
            link.l1.go = "Step_2_2";
        break;
        case "Step_2_2":
            dialog.text = "Alors, allez-y.";
            link.l1 = "...";
            link.l1.go = "exit";
    		pchar.questTemp.State = "Inquisition_toDeSouza";
            AddQuestRecord("Spa_Line_2_Inquisition", "1");
            SaveCurrentQuestDateParam("questTemp");
        break;
        case "Step_2_3":
            dialog.text = "Eh bien, voilà qui est bien. Vous vous reposerez quelques semaines de ces pieux labeurs au profit de l'וglise, puis je vous prierai de venir à mon bureau. Je suppose que je vous trouverai une nouvelle affaire.";
            link.l1 = "Toujours à votre service, señor !";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "3";
            pchar.questTemp.Waiting_time = "15";
            CloseQuestHeader("Spa_Line_2_Inquisition");
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "FencingLight", 150);
			AddCharacterExpToSkill(pchar, "Fencing", 150);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 120);
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);

			//слухи
			AddSimpleRumour("Le bruit court que le capitaine " + GetFullName(pchar) + " a accepté d'exécuter les ordres de de Souza en personne ! L'Inquisition... Rien qu'à ce mot, un frisson me parcourt le corps.", SPAIN, 5, 1);
        break;
        //********************** Квест №3, захватить Рока Бразица. ************************
        case "Step_3_1":
            dialog.text = "Alors, savez-vous quelque chose sur le ladron Rock le Brésilien ?";
            link.l1 = "Hum, un personnage célèbre, un corsaire très dangereux. Il traîne à Tortuga.";
            link.l1.go = "Step_3_2";
        break;
        case "Step_3_2":
            dialog.text = "Oui, c'est cela. Un vrai casse-tête pour nous.\n"+
                          "Eh bien, j'ai l'intention de me débarrasser moi-même de cette migraine et d'en débarrasser nos colons. Je veux que vous capturiez ce fameux Rock le Brésilien. Et ce qui est très important, c'est qu'il soit livré vivant.";
            link.l1 = "Est-ce nécessaire ? Ce sera un sacré combat, vous pouvez en être sמr.";
            link.l1.go = "Step_3_3";
        break;
        case "Step_3_3":
            dialog.text = "Et alors ? Je ne vous comprends pas bien, "+ GetSexPhrase("señor","señorita") +" " + pchar.name + ". Vous avez peur ?!";
            link.l1 = "Don Francisco, je ne crains ni Dieu ni diable. Je crois que vous avez eu l'occasion de le vérifier ! Mais ce que je veux dire, c'est que je ne peux pas contrכler entièrement un abordage. N'importe qui peut mourir dans une telle mêlée.";
            link.l1.go = "Step_3_4";
        break;
        case "Step_3_4":
            dialog.text = "Je le comprends. Mais je le répète quand même : il me faut Rock le Brésilien vivant. Ou plutכt, pas à moi, mais au célèbre monseigneur Antonio de Souza. C'est une exigence de la Sainte Inquisition ; comprenez-vous à quel point c'est important pour nous ?";
            link.l1 = "Oui, monsieur, je comprends. Eh bien, je peux vous promettre de faire tout mon possible pour mener à bien cette mission dans son intégralité.";
            link.l1.go = "Step_3_5";
        break;
        case "Step_3_5":
            dialog.text = "Excellent ! J'attends votre navire, avec Rock le Brésilien dans la cale, en rade de la baie de Santiago.";
            link.l1 = "Au revoir, señor.";
            link.l1.go = "exit";
            pchar.questTemp.State = "TakeRockBras_toTortuga";
            AddQuestRecord("Spa_Line_3_RockBrasilian", "1");
        break;
        case "Step_3_6":
            dialog.text = "Hum, c'est fâcheux. Vous m'avez déçu.\n"+
                          "Maintenant, laissez-moi, je vous prie... Cependant, vous pouvez venir à mes audiences de temps en temps, il y aura peut-être quelque chose pour vous...";
            link.l1 = "Je comprends, señor gouverneur général. Merci...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "30";
            CloseQuestHeader("Spa_Line_3_RockBrasilian");
			ChangeCharacterReputation(pchar, -3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sneak", -100);
			AddCharacterExpToSkill(pchar, "Sailing", -100);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le capitaine " + GetFullName(pchar) + " a échoué dans la mission du gouverneur général : capturer cet affreux ladron, Rock le Brésilien. Un raté, en un mot...", SPAIN, 5, 1);
        break;
        case "Step_3_7":
            dialog.text = "Parfait ! Maintenant, allez à Santiago et remettez-le à monseigneur Antonio de Souza.";
            link.l1 = "Très bien, señor, ce sera fait.";
            link.l1.go = "exit";
        break;
        case "Step_3_8":
            dialog.text = "Revenez me voir dans deux jours : monseigneur Antonio doit s'occuper de ce Brésilien, il devrait y avoir des nouvelles.";
            link.l1 = "Bien, je serai chez vous dans deux jours, monsieur.";
            link.l1.go = "exit";
            AddQuestRecord("Spa_Line_3_RockBrasilian", "9");
            pchar.questTemp.State = "TakeRockBras_WaitTwoDays";
            SaveCurrentQuestDateParam("questTemp");
        break;
        case "Step_3_9":
            dialog.text = "Bien sמr, ce n'est pas de la morale que monseigneur de Souza lui a faite ! Rock le Brésilien a eu exactement ce qu'il méritait.\n"+
                          "Il avait plus d'une fois torturé des citoyens espagnols pour leur faire avouer oם ils cachaient leur argent, et maintenant, sous la torture de la Sainte Inquisition, Rock a révélé l'emplacement de son propre trésor. Il l'avait partagé et caché en plusieurs endroits : à Cuba, à Hispaniola et dans la région de Belize.\n"+
                          "Vous devez trouver les caches du Brésilien et me les rapporter. D'après les estimations préliminaires, il y a environ 500 000 piastres au total !";
            link.l1 = "Pas mal, en effet ! Señor, avez-vous réussi à obtenir l'emplacement exact du trésor ?";
            link.l1.go = "Step_3_13";
        break;
        case "Step_3_13":
            dialog.text = "Non, malheureusement...";
            link.l1 = "Peut-être devrions-nous attendre un peu, et monseigneur Antonio nous donnera les informations nécessaires ?";
            link.l1.go = "Step_3_14";
        break;
        case "Step_3_14":
            dialog.text = "Ce n'est plus possible : Rock le Brésilien a rendu son âme à notre Seigneur. Amen...";
            link.l1 = "Amen... Señor, puis-je compter sur une partie des trésors que je trouverai ?";
            link.l1.go = "Step_3_15";
        break;
        case "Step_3_15":
            dialog.text = "Sans aucun doute. Un cinquième des piastres du Brésilien que vous trouverez vous reviendra. Et ne me les apportez pas par petits bouts : venez directement quand vous aurez réuni la somme requise, 500 mille.";
            link.l1 = "Bien, señor gouverneur général, je commence les recherches immédiatement.";
            link.l1.go = "exit";
         	pchar.GenQuestBox.Cuba_Grot = true;
            pchar.GenQuestBox.Cuba_Grot.box1.items.gold = 150000;
            pchar.GenQuestBox.Cuba_Grot.box1.items.indian17 = 1;
            pchar.GenQuestBox.Cuba_Grot.box1.items.indian10 = 1;
            pchar.GenQuestBox.Cuba_Grot.box1.items.indian18 = 1;
         	pchar.GenQuestBox.Hispaniola_Cave = true;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.gold = 150000;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.jewelry5 = 250;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.jewelry14= 10;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.potion3 = 5;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.mineral8 = 1;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.jewelry7 = 5;
            pchar.GenQuestBox.Hispaniola_Cave.box2.items.jewelry2 = 20;
         	pchar.GenQuestBox.Beliz_Cave = true;
            pchar.GenQuestBox.Beliz_Cave.box1.items.gold = 50000;
            pchar.GenQuestBox.Beliz_Cave.box1.items.indian6 = 1;
            pchar.GenQuestBox.Beliz_Cave.box1.items.indian11 = 1;
            pchar.GenQuestBox.Beliz_Cave.box1.items.indian15 = 1;
            pchar.GenQuestBox.Beliz_Cave.box1.items.indian12 = 1;
            pchar.GenQuestBox.Beliz_Cave.box2.items.gold = 150000;
            pchar.GenQuestBox.Beliz_Cave.box2.items.potion5 = 10;
            pchar.GenQuestBox.Beliz_Cave.box2.items.potionrum = 2;
            pchar.GenQuestBox.Beliz_Cave.box2.items.potion4 = 10;
            pchar.questTemp.State = "TakeRockBras_SeekRocksMoney";
            AddQuestRecord("Spa_Line_3_RockBrasilian", "8");
        break;
        case "Step_3_10":
            dialog.text = "Parfait ! Maintenant, faisons le compte... Vous versez 500 mille au trésor de l'Escurial ; votre part est donc de 100 mille piastres.";
            link.l1 = "Merci, señor gouverneur général.";
            link.l1.go = "Step_3_11";
        break;
        case "Step_3_11":
            dialog.text = "Bien... Je n'ose pas vous retenir maintenant, mais je vous prie d'être à mon audience dans une semaine.";
            link.l1 = "Bien, don Francisco, je serai chez vous à l'heure dite. Et maintenant, permettez-moi de prendre congé...";
            link.l1.go = "exit";
            AddMoneyToCharacter(pchar, -400000);
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "5";
            CloseQuestHeader("Spa_Line_3_RockBrasilian");
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sailing", 150);
			AddCharacterExpToSkill(pchar, "Repair", 250);
			//слухи
			AddSimpleRumour("Vous ne connaissez pas la merveilleuse nouvelle ? Un certain capitaine " + GetFullName(pchar) + " a capturé cet ignoble ladron, Rock le Brésilien. Gloire à Dieu tout-puissant !", SPAIN, 5, 1);
        break;
        //********************** Квест №4, расследование убийства. ************************
        case "Step_4_1":
            dialog.text = "La Havane est en émoi à cause d'un crime étrange. Le plus étrange, c'est qu'on ne comprend absolument pas comment c'est arrivé.\n"+
                          "Le commandant de La Havane, don José Ramirez de Leyva, a été tué dans sa propre maison, avec quatre domestiques. Tous étaient en tenue de combat, comme s'ils partaient en guerre.";
            link.l1 = "דa alors ! Et personne n'a rien entendu ? La cuisinière, par exemple ?";
            link.l1.go = "Step_4_2";
        break;
        case "Step_4_2":
            dialog.text = "Non, il n'y avait personne d'autre dans la maison, à part sa femme. La veille, don José avait fait une terrible scène à sa femme et avait renvoyé toutes les servantes.";
            link.l1 = "Et que dit sa femme ?";
            link.l1.go = "Step_4_3";
        break;
        case "Step_4_3":
            dialog.text = "Elle a disparu...";
            link.l1 = "Comment ça, disparu ? Complètement ?";
            link.l1.go = "Step_4_4";
        break;
        case "Step_4_4":
            dialog.text = "Non, en partie... Réfléchissez à ce que vous dites !";
            link.l1 = "Pardon, don Francisco. Tout cela est étrange... Vous savez, ce n'est pas mon domaine, je ne suis pas enquêteur. Que le bureau du commandant s'en occupe.";
            link.l1.go = "Step_4_5";
        break;
        case "Step_4_5":
            dialog.text = "Don José était le commandant de La Havane. וcoutez, je ne peux pas vous forcer à enquêter sur des crimes, mais en ce moment, je vous le demande.\n"+
                          "La ville est en émoi, vous comprenez. Et puis il y a cette disparition... Nous avons tout fouillé alentour, en vain. Il me faut immédiatement des mesures efficaces dans l'enquête, et vous êtes le meilleur candidat en ce moment.";
            link.l1 = "Très bien, señor gouverneur général. Je ferai ce que je pourrai.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp4Detection_toMirderPlace";
            AddQuestRecord("Spa_Line_4_MirderDetection", "1");
			AddQuestUserData("Spa_Line_4_MirderDetection", "sSex", GetSexPhrase("", "e"));
         	pchar.GenQuestBox.Havana_houseS1Bedroom = true;
            pchar.GenQuestBox.Havana_houseS1Bedroom.box2.items.letter_notes = 1;
        break;
        case "Step_4_6":
            dialog.text = "Tortuga est un refuge pour bandits de tout poil... Et qu'en est-il de doña Anna ?";
            link.l1 = "Difficile à deviner... Mais voici ce que j'ai trouvé : une lettre inachevée sur le lieu du crime...";
            link.l1.go = "Step_4_7";
        break;
        case "Step_4_7":
            dialog.text = "(lit) Hum, je ne sais même pas quoi dire... Vous devez vous rendre à Tortuga et découvrir de quoi il retourne.";
            link.l1 = "Très bien, don Francisco, je vais le faire.";
            link.l1.go = "Step_4_8";
            TakeItemFromCharacter(pchar, "letter_notes");
        break;
        case "Step_4_8":
            dialog.text = "Je vous remets la licence de la Compagnie française des Indes occidentales, valable 20 jours. Ce document vous permettra de circuler librement à Tortuga. Et j'espère que vous penserez à hisser le pavillon français sur votre navire...";
            link.l1 = "Bien sמr, don Francisco, voilà qui sera très utile. Je crois que je vais me mettre à la tâche.";
            link.l1.go = "exit";
            GiveUniLicence(20); // universal GWIK trade license
            pchar.questTemp.State = "Sp4Detection_toTortuga";
            AddQuestRecord("Spa_Line_4_MirderDetection", "4");
            sld = GetCharacter(NPC_GenerateCharacter("ServantDEstre", "Barmen_13", "man", "man", 10, FRANCE, -1, false));
        	sld.name 	= "Guido";
        	sld.lastname = "";
            sld.Dialog.Filename = "Quest\SpaLineNpc_1.c";
            LAi_SetStayType(sld);
        	LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
            ChangeCharacterAddressGroup(sld, "Tortuga_houseS2", "goto", "goto2");
        break;
        case "Step_4_9":
            dialog.text = "De simples suppositions... euh, ce n'est pas suffisant pour tirer des conclusions fermes.\n"+
                          "Vous ne me satisfaites pas. Je vous prie de me laisser, je n'ai pas d'affaire pour vous.\n"+
                          "Cependant, vous pouvez venir à mon bureau de temps en temps, il y aura peut-être quelque chose d'insignifiant...";
            link.l1 = "Bien, señor gouverneur général...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "30";
            CloseQuestHeader("Spa_Line_4_MirderDetection");
            TakeNationLicence(FRANCE);
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("Vous savez, notre gouverneur général a chargé le capitaine " + GetMainCharacterNameDat() + " d'enquêter sur le meurtre du commandant de Leyva. Cependant, cכté enquête, le capitaine n'a pas brillé...", SPAIN, 5, 1);
        break;
        case "Step_4_10":
            dialog.text = "Continuez...";
            link.l1 = "J'ai rattrapé ce flibustier, mais je n'ai pas pu le tuer : il est très fort, j'ai dמ battre en retraite.";
            link.l1.go = "Step_4_11";
        break;
        case "Step_4_11":
            dialog.text = "C'est compréhensible. Tuer cinq hommes lourdement armés et prêts à l'accueillir, ce n'est pas comme embrocher un épouvantail au champ de manœuvre...";
            link.l1 = "Bref, en parlant avec lui, j'ai réussi à apprendre que la passion de d'Ogeron est doña Anna Ramirez de Leyva. C'est tout, en fait...";
            link.l1.go = "Step_4_12";
        break;
        case "Step_4_12":
            dialog.text = "Eh bien, si don José avait traité doña Anna comme il faut, je suppose que rien de tout cela ne serait arrivé. Il faut reconnaître que doña Anna souffrait beaucoup des mœurs de son mari et des règles qu'il avait établies dans sa maison. Néanmoins, il en avait le droit...";
            link.l1 = "Señor gouverneur général, puis-je considérer l'enquête comme terminée ?";
            link.l1.go = "Step_4_13";
        break;
        case "Step_4_13":
            dialog.text = "Oui, bien sמr. Votre récompense est de 3 000 piastres. Si vous aviez pu tuer cet « homme de confiance », la récompense aurait été tout autre.\n"+
                          "Et maintenant, je vous prie de me laisser, je dois écrire aux parents de de Leyva, en Castille, pour leur annoncer la perte qui nous frappe.";
            link.l1 = "Bien, don Francisco, au revoir...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "10";
            CloseQuestHeader("Spa_Line_4_MirderDetection");
            AddMoneyToCharacter(pchar, 3000);
            TakeNationLicence(FRANCE);
			AddTitleNextRate(sti(NPChar.nation), 0.5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Grappling", 100);
			AddCharacterExpToSkill(pchar, "Defence", 170);
			AddCharacterExpToSkill(pchar, "Cannons", 120);
			ChangeCharacterReputation(pchar, 2);
			//слухи
			AddSimpleRumour("Vous savez, notre gouverneur général a chargé le capitaine " + GetFullName(pchar) + " d'enquêter sur le meurtre du commandant de Leyva. Notre capitaine a découvert que l'assassin était un Français. Mais la vengeance n'a pas pu être accomplie.", SPAIN, 5, 1);
        break;
        case "Step_4_14":
            dialog.text = "J'ai du mal à le croire...";
            link.l1 = "C'est pourtant vrai. Elle se trouve en ce moment à la résidence et semble très heureuse.";
            link.l1.go = "Step_4_15";
        break;
        case "Step_4_15":
            dialog.text = "Eh bien, si don José avait traité doña Anna comme il faut, je suppose que rien de tout cela ne serait arrivé. Il faut reconnaître que doña Anna souffrait beaucoup des mœurs de son mari et des règles qu'il avait établies dans sa maison. Néanmoins, il en avait le droit... Alors, qui a tué don José ?";
            link.l1 = "Le flibustier français Henri d'Estre, homme de confiance du gouverneur général d'Ogeron.";
            link.l1.go = "Step_4_16";
        break;
        case "Step_4_16":
            dialog.text = "Bon sang ! Je ne dirai pas que j'appréciais beaucoup don José, mais il est tout simplement inacceptable de tolérer cela sous mon nez ! Il faut un châtiment !";
            link.l1 = "Il a déjà eu lieu : l'assassin de don José est mort. Je l'ai tué à Tortuga.";
            link.l1.go = "Step_4_17";
        break;
        case "Step_4_17":
            dialog.text = "Bon sang ! Vous êtes vraiment un officier courageux, et une personne d'honneur, de surcroît. Je vous suis reconnaissant de votre courage.";
            link.l1 = "Merci, don Francisco.";
            link.l1.go = "Step_4_18";
        break;
        case "Step_4_18":
            dialog.text = "Vous êtes libre. Eh bien, je dois veiller à ce que doña Anna ne soit pas si heureuse. Je suppose qu'il ne lui reste plus longtemps à vivre...";
            link.l1 = "Vous avez l'intention de lui envoyer un assassin ?";
            link.l1.go = "Step_4_19";
        break;
        case "Step_4_19":
            dialog.text = "Moi ? Pas du tout, j'ai des affaires plus importantes. Mais j'estime de mon devoir d'informer en détail les parents de don José des résultats de votre enquête. Compte tenu des lois castillanes de l'honneur, il reste tout au plus six mois à vivre à doña Anna...";
            link.l1 = "Compris. Eh bien, ça ne me regarde plus vraiment. Señor gouverneur général, puis-je considérer l'enquête comme terminée ?";
            link.l1.go = "Step_4_20";
        break;
        case "Step_4_20":
            dialog.text = "Oui, bien sמr. Vous avez excellé dans votre mission, votre récompense est de 120 000 piastres.\n"+
                          "Et maintenant, je vous prie de me laisser. Et n'oubliez pas de passer à ma résidence de temps en temps...";
            link.l1 = "Bien, don Francisco, au revoir...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "4";
            CloseQuestHeader("Spa_Line_4_MirderDetection");
            AddMoneyToCharacter(pchar, 120000);
            TakeNationLicence(FRANCE);
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 180);
			AddCharacterExpToSkill(pchar, "Grappling", 200);
			AddCharacterExpToSkill(pchar, "Defence", 170);
			AddCharacterExpToSkill(pchar, "Cannons", 220);
			AddCharacterExpToSkill(pchar, "Fortune", 150);
			//слухи
			AddSimpleRumour("Vous savez, notre gouverneur général a chargé le capitaine " + GetMainCharacterNameDat() + " d'enquêter sur le meurtre du commandant de Leyva. Notre capitaine a découvert que l'assassin était un Français, et l'a envoyé dans l'autre monde.", SPAIN, 5, 1);
        break;
        //********************** Квест №5, Нападение на Ла Вегу. ************************
        case "Step_5_1":
            dialog.text = "Vous apprendrez tout de Jimenez. Prochainement, vous serez entièrement à sa disposition. Tout ce que je peux vous dire, c'est que vous ne vous ennuierez pas : il y aura une sérieuse opération militaire.";
            link.l1 = "Des détails...";
            link.l1.go = "Step_5_2";
        break;
        case "Step_5_2":
            dialog.text = "Tout est chez Jimenez. Rendez-vous immédiatement à Santiago.";
            link.l1 = "Très bien, monsieur.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp5LaVegaAttack_toSantiago";
            AddQuestRecord("Spa_Line_5_LaVegaAttack", "1");
 		AddQuestUserData("Spa_Line_5_LaVegaAttack", "sSex", GetSexPhrase("", "e"));
        break;
        case "Step_5_3":
            dialog.text = "Hum, bravo. Mansfield était une figure respectée ; c'est un succès indéniable des armes espagnoles. Je vous félicite pour cette victoire !\n"+
                          "Dites-moi, cette opération militaire a-t-elle été suffisamment payée par le gouverneur de Santiago ?";
            link.l1 = "Oui, señor gouverneur général, suffisamment. Tout va bien.";
            link.l1.go = "Step_5_4";
        break;
        case "Step_5_4":
            dialog.text = "Eh bien, parfait ! Je vous attendrai chez moi dans quelque temps, j'aurai peut-être encore du travail pour vous.";
            link.l1 = "Je vous rendrai visite de temps en temps, señor.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "6";
            pchar.questTemp.Waiting_time = "7";
            CloseQuestHeader("Spa_Line_5_LaVegaAttack");
			//--> огонь и пламень убираем
			DeleteAttribute(&locations[FindLocation("LaVega_town")], "hidden_effects");
			//<-- огонь и пламень
            //===> Эдвард убит :( теперь Ла Вегой рулит капитан Купер.
            sld = characterFromID("Edward Mansfield");
            sld.name 	= "Capitaine";
        	sld.lastname = "Cooper";
        	sld.model.animation = "man"
            sld.model = "officer_8";
            sld.Sp5LaVegaAttackDone = true; // fix 1.2.3
            sld.quest.meeting = "0";  // fix 1.2.3 типа новый чел
            // лишнее это тут 1.2.3 SendMessage(sld, "lss", MSG_CHARACTER_SETMODEL, sld.model, sld.model.animation);
            FaceMaker(sld);
            ChangeCharacterAddressGroup(sld, "LaVega_townhall", "sit", "sit1");
			AddTitleNextRate(sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "FencingLight", 350);
			AddCharacterExpToSkill(pchar, "Fencing", 350);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 320);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			SetLocationCapturedState("LaVega_town", false); // fix 1.2.3 вернуть людей
			//слухи
			AddSimpleRumour("On dit que c'est vous qui avez tué Mansfield, le chef des boucaniers. Il était temps, je vous le dis...", SPAIN, 5, 1);
        break;
        //********************** Квест №6, Разведка на Тортуге. ************************
        case "Step_6_1":
            dialog.text = "Le fait est que les Français et les Hollandais semblent travailler ensemble en secret. Il est clair que Louis XIV nous fait la guerre de Dévolution pour les provinces néerlandaises d'Europe.\nLes Pays-Bas eux-mêmes n'osent pas nous affronter ouvertement, mais leur aide financière aux Français joue un rכle très important, sinon décisif, dans cette guerre : tout le monde sait que Louis a des problèmes d'argent.\n"+
                          "Votre mission est de vous rendre de nouveau en secret à Tortuga et d'essayer d'intercepter une partie de la correspondance d'וtat entre le gouverneur général de Curaçao, Peter Stuyvesant, et le gouverneur général Bertrand d'Ogeron.\n"+
                          "Des messagers porteurs du courrier diplomatique y viennent régulièrement, vous devrez donc en intercepter un. Il me faut un document que notre service diplomatique pourra utiliser comme preuve de la coordination des actions des Hollandais et des Français.";
            link.l1 = "Je comprends, señor. Quels sont les délais ?";
            link.l1.go = "Step_6_2";
        break;
        case "Step_6_2":
            dialog.text = "Aucun. La seule chose que je vous demande, c'est de ne pas provoquer de massacre au grand jour à Tortuga : les officiers braves et zélés me sont précieux.";
            link.l1 = "Don Francisco, je tâcherai de survivre en toutes circonstances.";
            link.l1.go = "Step_6_3";
        break;
        case "Step_6_3":
            dialog.text = "Autre chose. Je vous remets une licence de la Compagnie française des Indes occidentales valable 20 jours. Vous devrez montrer ce papier au capitaine du port, et personne ne vous soupçonnera de quoi que ce soit.\n"+
                          "Eh bien, vous avez reçu toutes les instructions. Vous pouvez commencer la mission.";
            link.l1 = "Je m'y mets, señor gouverneur général.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp6TakeMess_toTotuga";
            AddQuestRecord("Spa_Line_6_TakeMessangeer", "1");
			GiveUniLicence(20); // universal GWIK trade license
        break;
        case "Step_6_4":
            dialog.text = "Eh bien, faites votre rapport sur l'accomplissement de la mission.";
			if (CheckCharacterItem(pchar, "letter_1"))
			{
				link.l1 = "J'ai réussi à obtenir la correspondance diplomatique entre les gouverneurs généraux de Tortuga et de Curaçao.";
				link.l1.go = "Step_6_6";
			}
			else
			{
				link.l1 = "Je n'ai pas réussi à obtenir les papiers jusqu'à présent. Il me semble que tout est inutile et que je ne peux plus accomplir cette mission...";
				link.l1.go = "Step_6_5";
			}
        break;
        case "Step_6_5":
            dialog.text = "Vous m'avez déçu, c'est très fâcheux... Eh bien, je n'ai plus besoin de vous. Vous pourrez revenir plus tard, je vous trouverai peut-être une tâche poussiéreuse pour un officier aussi stupide...";
            link.l1 = "Bien, señor gouverneur général...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "40";
            CloseQuestHeader("Spa_Line_6_TakeMessangeer");
            BackItemDescribe("letter_1");
  			TakeNationLicence(FRANCE);
			LocatorReloadEnterDisable("Tortuga_tavern", "reload2_back", true);
			DeleteAttribute(pchar, "questTemp.State.Open");
			LAi_group_SetLookRadius("FRANCE_CITIZENS", LAI_GROUP_DEF_LOOK);
			ChangeCharacterReputation(pchar, -5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Repair", -170);
			AddCharacterExpToSkill(pchar, "Defence", -130);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
			//слухи
			AddSimpleRumour("Notre gouverneur général a envoyé le capitaine " + GetMainCharacterNameGen() + " à Tortuga pour une mission très importante. Le capitaine en a été pour ses frais : un échec, en un mot...", SPAIN, 5, 1);
         break;
        case "Step_6_6":
            dialog.text = "Parfait, " + pchar.name + "C'est tout simplement formidable !";
            link.l1 = "Merci, don Francisco...";
            link.l1.go = "Step_6_7";
        break;
        case "Step_6_7":
            dialog.text = "Nous avons maintenant un argument sérieux dans la guerre diplomatique... Vous avez fait du beau travail.";
            link.l1 = "Vraiment, j'ai dמ travailler dur, que dire...";
            link.l1.go = "Step_6_8";
        break;
        case "Step_6_8":
            dialog.text = "50 mille pièces : voilà votre récompense ! Veuillez les recevoir... Je vous prie de ne pas quitter La Havane trop longtemps, j'aurai bientכt besoin de vous.";
            link.l1 = "Très bien, señor gouverneur général.";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 50000);
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "9";
            CloseQuestHeader("Spa_Line_6_TakeMessangeer");
			TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
			TakeNationLicence(FRANCE);
			LocatorReloadEnterDisable("Tortuga_tavern", "reload2_back", true);
			DeleteAttribute(pchar, "questTemp.State.Open");
			LAi_group_SetLookRadius("FRANCE_CITIZENS", LAI_GROUP_DEF_LOOK);
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sneak", 300);
			AddCharacterExpToSkill(pchar, "Cannons", 250);
			AddCharacterExpToSkill(pchar, "Accuracy", 350);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " a mené à bien une affaire extrêmement dangereuse à Tortuga. Mmm, le courage de "+ GetSexPhrase("cet homme","cette fille") +" force l'admiration...", SPAIN, 5, 1);
		break;
        //********************** Квест №7, Спасти Пардаля. ************************
        case "Step_7_1":
            dialog.text = "Diable, c'est très, très fâcheux. Le moral des colons va sérieusement baisser avec cette nouvelle...";
            link.l1 = "Je suis désolé, monsieur, j'ai fait tout ce que j'ai pu.";
            link.l1.go = "Step_7_2";
        break;
        case "Step_7_2":
            dialog.text = "Eh bien, ce qui est fait, ou plutכt ce qui n'est pas fait, ne peut être défait. Prenez du repos. Vous pourrez me rendre visite dans quelque temps, j'aurai peut-être une affaire pour vous.";
            link.l1 = "Très bien, don Francisco. Au revoir...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "20";
            CloseQuestHeader("Spa_Line_7_SavePardal");
		break;
        case "Step_7_3":
            dialog.text = "Parfait, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", tout simplement parfait !";
            link.l1 = "Señor, ce fut un beau combat ; Manoel, je pense, vous en racontera les détails...";
            link.l1.go = "Step_7_4";
        break;
        case "Step_7_4":
            dialog.text = "Sans aucun doute... Eh bien, vos efforts héroïques méritent tous les éloges et une haute récompense. 25 000 réaux : voilà votre récompense !";
            link.l1 = "Euh, la somme... la somme... Oui, en fait, ce n'est pas une question d'argent !";
            link.l1.go = "Step_7_5";
        break;
        case "Step_7_5":
            dialog.text = "Voilà les paroles d'un vrai soldat ! Je ne m'étais pas trompé sur votre compte.\n"+
				          "Je ne vous retiens pas maintenant ; je vous demanderai seulement d'être à ma résidence dans une semaine : une affaire est prévue pour le brave capitaine. Je crois savoir qui est ce capitaine...";
            link.l1 = "Très bien, don Francisco, je serai chez vous vers cette date.";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 25000);
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "5";
            CloseQuestHeader("Spa_Line_7_SavePardal");
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sneak", 250);
			AddCharacterExpToSkill(pchar, "Sailing", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 150);
			AddCharacterExpToSkill(pchar, "Fencing", 150);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 120);
			//слухи
			AddSimpleRumour("On dit que vous avez sauvé notre héros Pardal ! Permettez-moi de vous exprimer mon admiration : vous êtes "+ GetSexPhrase("un vrai guerrier ","une vraie guerrière ") +" !", SPAIN, 5, 1);
        break;
        case "Step_7_6":
            dialog.text = "Oui, vous m'avez déçu, c'est très fâcheux... Eh bien, je ne vous retiens pas plus longtemps. Dans quelque temps, vous pourrez venir à mon audience, je trouverai peut-être une affaire pour un capitaine aussi stupide...";
            link.l1 = "Bien, don Francisco, je suis désolé...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "40";
            CloseQuestHeader("Spa_Line_7_SavePardal");
			ChangeCharacterReputation(pchar, -4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("Le bruit court que Pardal est mort en grande partie par votre faute. C'est triste, "+ GetSexPhrase("señor le lâche","señorita la lâche") +"...", SPAIN, 5, 1);
        break;
//********************** Квест №8, Отбить нападение на Куману. ************************
        case "Step_8_1":
            dialog.text = "Malheureusement, seulement dans les grandes lignes. On m'a informé que leur escadre compte même un vaisseau de premier rang, ce qui est tout à fait inhabituel chez les pirates. Il ne fait aucun doute que cette attaque est financée par les autorités de Tortuga...";
            link.l1 = "Et nous ne pouvons pas les arrêter d'une manière ou d'une autre ?";
            link.l1.go = "Step_8_2";
        break;
        case "Step_8_2":
            dialog.text = "Eh, "+ GetSexPhrase("mon ami","chère señorita") +", nous vivons, vous et moi, une époque bien difficile... L'Espagne, notre patrie, reçoit des coups de toutes parts. Dans l'Ancien Monde, nous perdons les provinces du nord dans la guerre de Dévolution contre Louis, et la pression des puissances rivales ne cesse de croître...\n"+
				          "Inutile de dire qu'il semble que le pouvoir du pape sera bientכt sérieusement ébranlé dans le monde...";
            link.l1 = "C'est triste, señor...";
            link.l1.go = "Step_8_3";
        break;
        case "Step_8_3":
            dialog.text = "Cependant, il ne faut pas perdre courage. Nous sommes le fil de la lame qui punit nos ennemis au nom de l'Espagne et du Seigneur tout-puissant ! Et puisqu'on nous défie de nouveau, nous devons relever le défi.\n"+
				          "Plus d'une fois, des coquins et des criminels de tout poil, qui pullulent comme des puces, se sont emparés de nos villes, ont torturé et tué nos colons...\n"+
						  "Cette fois, nous devons assurer une protection fiable à Cumaná : c'est votre mission. Rendez-vous immédiatement à Cumaná et repoussez l'attaque des ladrones commandés par le capitaine Ansel.";
            link.l1 = "Compris, don Francisco. Ce sera fait.";
            link.l1.go = "Step_8_4";
        break;
		case "Step_8_4":
            dialog.text = "Parfait ! Et souvenez-vous qu'entre vos mains, entre les mains de vos soldats et de vos marins, se trouve le sort de toute une ville ! Ne me décevez pas.";
            link.l1 = "Les ladrones seront détruits, vous pouvez en être sמr, señor.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp8SaveCumana_toCumana";
            AddQuestRecord("Spa_Line_8_SaveCumana", "1");
			SetTimerCondition("Sp8SaveCumana_RescueTimeOver", 0, 0, 20, false);
            Pchar.quest.Sp8SaveCumana_Battle.win_condition.l1 = "location";
            Pchar.quest.Sp8SaveCumana_Battle.win_condition.l1.location = "Cumana";
            Pchar.quest.Sp8SaveCumana_Battle.win_condition = "Sp8SaveCumana_Battle";
        break;
		case "Step_8_5":
            dialog.text = "Quoi qu'il en soit, je suis très mécontent de vous. Vous pourrez venir à ma résidence un peu plus tard, mais pour l'instant, je n'ai pas d'affaire pour vous. Je n'ai pas besoin d'officiers qui échouent si souvent leurs opérations...";
            link.l1 = "Compris, don Francisco.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "9";
            CloseQuestHeader("Spa_Line_8_SaveCumana");
			SetLocationCapturedState("Cumana_town", false);
			ChangeCharacterReputation(pchar, -2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", -270);
			AddCharacterExpToSkill(pchar, "Sneak", -260);
			AddCharacterExpToSkill(pchar, "Cannons", -300);
			AddCharacterExpToSkill(pchar, "FencingLight", -270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -250);
 			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " n'a pas su sauver les habitants de Cumaná ! Un triste sort...", SPAIN, 5, 1);
        break;
		case "Step_8_6":
            dialog.text = "Parfait ! Un beau coup porté aux ennemis de l'Espagne dans les Caraïbes. En récompense de votre courage, je vous prie d'accepter 100 000 pièces d'or de la part de la Couronne espagnole !";
            link.l1 = "Merci, monsieur. Maintenant, permettez-moi de prendre congé : je dois remettre mes navires en état après la bataille...";
            link.l1.go = "Step_8_7";
        break;
		case "Step_8_7":
            dialog.text = "D'accord, "+ GetSexPhrase("mon ami","señorita") +". Je vous prie de ne pas vous absenter longtemps de la ville : il se peut fort bien que j'aie encore besoin de vous.";
            link.l1 = "Compris, don Francisco.";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 100000);
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "7";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "9";
            CloseQuestHeader("Spa_Line_8_SaveCumana");
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddTitleNextRate(sti(NPChar.nation), 2);
			AddCharacterExpToSkill(pchar, "Repair", 270);
			AddCharacterExpToSkill(pchar, "Sneak", 260);
			AddCharacterExpToSkill(pchar, "Cannons", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 230);
			AddCharacterExpToSkill(pchar, "Fencing", 250);
 			//слухи
			AddSimpleRumour("Capitaine, on dit que vous avez sauvé Cumaná ! Permettez-moi de vous exprimer mon admiration, "+ GetSexPhrase("señor","señorita") +"...", SPAIN, 5, 1);
        break;
//********************** Квест №9, Четыре золотых галеона. ************************
		case "Step_9_1":
            dialog.text = "La mission consistera à escorter des navires. Je ne peux rien dire de plus : le gouverneur de Portobelo a toutes les instructions. Veuillez recevoir une lettre de créance adressée au gouverneur de Portobelo.";
            link.l1 = "Je comprends, señor. Je commence immédiatement.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp9SaveCumana_toPortoBello";
            AddQuestRecord("Spa_Line_9_FourGolgGaleons", "1");
			AddQuestUserData("Spa_Line_9_FourGolgGaleons", "sSex", GetSexPhrase("", "e"));
            ChangeItemDescribe("letter_1", "itmdescr_letter_1_SpaLineQ10");
            GiveItem2Character(pchar,"letter_1");
        break;
		case "Step_9_2":
            dialog.text = "Vous deviez escorter les galions jusqu'à Belize, qu'est-ce que les Caïmans viennent faire là-dedans ?!";
            link.l1 = "Señor, je n'ai aucune idée de ce que les Caïmans viennent faire là-dedans, mais on m'avait promis qu'une escadre militaire espagnole viendrait à ma rencontre aux Caïmans.";
            link.l1.go = "Step_9_3";
        break;
		case "Step_9_3":
            dialog.text = "On est venu à votre rencontre ?";
            link.l1 = "L'escadre militaire espagnole, non, mais cinq navires de ladrones m'ont réservé un accueil chaleureux. Ils attendaient manifestement mes galions.";
            link.l1.go = "Step_9_4";
        break;
		case "Step_9_4":
            dialog.text = "Qu'est-ce qui vous fait croire ça ?";
            link.l1 = "Señor, que ferait une escadre entière de pirates près d'une île inhabitée, au milieu d'une partie déserte de la mer des Caraïbes ? On peut bien sמr supposer qu'ils voulaient jouer aux cartes, mais c'est peu probable.";
            link.l1.go = "Step_9_5";
        break;
		case "Step_9_5":
            dialog.text = "Bon sang, on dirait que nous avons affaire soit à une monstrueuse erreur, soit à une trahison. Je m'en occuperai, mais en attendant, dites-moi : tous les galions sont-ils intacts ?";
			iTemp = 0;
			iMoney = 0;
            for (i=1; i<=COMPANION_MAX; i++)
            {
                ShipType = GetCompanionIndex(pchar,i);
                if(ShipType != -1)
                {
                	sld = GetCharacter(ShipType);
                    ShipType = sti(sld.ship.type);
                    Rank = sti(RealShips[ShipType].basetype);
                    if (Rank == SHIP_ROTERLOW)
					{
						iTemp++;
						iMoney = iMoney + sti(sld.Ship.Cargo.Goods.Gold);
					}
                }
            }
			npchar.quest.money = iMoney;
			if (iTemp < 4 && iTemp > 0)
            {
                if (iTemp == 1)
                {
					link.l1 = "Señor, l'attaque a été soudaine. Je n'ai réussi à sauver qu'un seul galion.";
					link.l1.go = "Step_9_6";
                }
                else
                {
					link.l1 = "Señor, l'attaque a été soudaine. J'ai réussi à sauver " + iTemp + " galions...";
					link.l1.go = "Step_9_6";
                }
            }
            else
            {
				if (iTemp == 0)
				{
					link.l1 = "Señor, l'attaque des ladrones a été soudaine et d'une fureur extrême. J'ai perdu tous les galions...";
					link.l1.go = "Step_9_8";
				}
				else
				{
					link.l1 = "Señor, même si l'attaque des ladrones a été une surprise, j'ai réussi à sauver tous les galions qui m'avaient été confiés.";
					link.l1.go = "Step_9_11";
				}
            }
        break;
		case "Step_9_6":
            dialog.text = "C'est très fâcheux. Je comprends que vous étiez dans une situation difficile, mais vous auriez pu être plus efficace. Et maintenant, je dois rendre des comptes à Madrid pour ce sérieux manque dans les livraisons d'or... et cela au moment oם l'Espagne se bat en Europe !\n"+
				          "Mmm, c'est très, très fâcheux. Je comptais sur vous, et vous n'avez pas justifié ma confiance.";
            link.l1 = "Don Francisco, croyez-moi, j'ai fait tout ce que j'ai pu. Et même plus... Cependant, les forces étaient trop inégales, et je n'avais qu'un navire pour protéger quatre galions ! Sur l'insistance du gouverneur de Portobelo, d'ailleurs. Peut-être devrais-je lui demander des comptes, avec toute la rigueur de la loi ?";
            link.l1.go = "Step_9_7";
        break;
		case "Step_9_7":
            dialog.text = "Peut-être, mais ce n'est pas votre affaire. Je vous comprends, mais les nombreuses raisons que vous avez exposées pour expliquer la défaite n'atténuent pas votre culpabilité.";
            link.l1 = "Je comprends...";
            link.l1.go = "Step_9_71";
		break;
		case "Step_9_71":
			if (sti(npchar.quest.money) < (iTemp*1200))
			{
				dialog.text = "Je vous prie donc de me laisser maintenant. א l'avenir, vous pourrez venir à ma résidence, il y aura peut-être une mission qui vous conviendra...";
				link.l1 = "Merci, don Francisco.";
				link.l1.go = "Step_9_exit";
				pchar.questTemp.Waiting_time = "20";
				pchar.questTemp.State = "empty";
				SaveCurrentQuestDateParam("questTemp");
				pchar.questTemp.CurQuestNumber = "10";
			}
			else
			{
				dialog.text = "Euh, "+ GetSexPhrase("señor","señorita") +", vous essayez de tricher, ou quoi ?! Il manque de l'or sur les galions ! Je ne veux plus traiter avec vous en aucune circonstance. Adieu !";
				link.l1 = "Euh, eh bien...";
				link.l1.go = "Step_9_exit";
				pchar.questTemp.State = "QuestLineBreake";
				ChangeCharacterReputation(pchar, -5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
				AddCharacterExpToSkill(pchar, "Sailing", -300);
				AddCharacterExpToSkill(pchar, "Leadership", -300);
				AddCharacterExpToSkill(pchar, "Commerce", -300);
				AddCharacterExpToSkill(pchar, "Pistol", -300);
				//слухи
				AddSimpleRumour("Capitaine, on dit qu'on vous a pris à tricher. Et que le gouverneur général vous a mis à la porte de sa résidence. Désormais, la route de la résidence vous est fermée...", SPAIN, 5, 1);
			}
        break;
		case "Step_9_8":
            dialog.text = "Bon sang !!! Comment cela a-t-il pu arriver ?! Je comprends que vous étiez dans une situation difficile, mais vous auriez pu être plus efficace. Et maintenant, je dois rendre compte à Madrid d'un grave manque dans les livraisons d'or... Et cela au moment oם l'Espagne mène une bataille épuisante en Europe !";
            link.l1 = "Don Francisco, croyez-moi, j'ai fait tout ce que j'ai pu. De plus, le gouverneur de Portobelo m'a jeté dans un piège !";
            link.l1.go = "Step_9_10";
        break;
		case "Step_9_10":
            dialog.text = "Je ne veux même pas écouter vos excuses. Partez !\n"+
				          "Cependant, vous pourrez revenir me voir, il y aura peut-être du travail pour "+ GetSexPhrase("un incapable pareil","une maladroite pareille") +"...";
            link.l1 = "Très bien, don Francisco.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "60";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "10";
            CloseQuestHeader("Spa_Line_9_FourGolgGaleons");
        break;
		case "Step_9_11":
            dialog.text = "L'or qu'ils transportent est-il intact, lui aussi ?";
			if (sti(npchar.quest.money) >= 5000)
			{
				link.l1 = "Oui, don Francisco, tout va bien.";
				link.l1.go = "Step_9_12";
			}
			else
			{
				if(sti(npchar.quest.money) > 4800)
				{
					link.l1 = "Pas vraiment, don Francisco. J'ai " + FindRussianQtyString(sti(npchar.quest.money)) + " d'or à bord des galions.";
					link.l1.go = "Step_9_14";
				}
				else
				{
					link.l1 = "Pas vraiment, don Francisco. J'ai  " + FindRussianQtyString(sti(npchar.quest.money)) + " d'or à bord des galions.";
					link.l1.go = "Step_9_16";
				}
			}
        break;
		case "Step_9_12":
            dialog.text = "Voilà qui est très bien. Vous avez su vous tirer d'une situation difficile avec honneur. C'est pourquoi 220000 piastres seront pour vous une digne récompense.";
            link.l1 = "Je vous suis reconnaissant, monsieur, d'avoir apprécié mes actes. Si vous n'avez plus besoin de moi, permettez-moi de vous laisser pour un temps.";
            link.l1.go = "Step_9_13";
        break;
		case "Step_9_13":
            dialog.text = "Bien, occupez-vous de vos affaires. N'oubliez pas, cependant, de me rendre visite de temps en temps.";
            link.l1 = "Très bien, don Francisco.";
            link.l1.go = "Step_9_exit";
			pchar.questTemp.Waiting_time = "7";
			pchar.questTemp.State = "empty";
			AddMoneyToCharacter(pchar, 220000);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
			AddCharacterExpToSkill(pchar, "Sailing", 290);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Commerce", 250);
			AddCharacterExpToSkill(pchar, "Pistol", 350);
			//слухи
			AddSimpleRumour("Capitaine, on dit partout que, pendant l'escorte des galions chargés d'or, on vous a tendu une embuscade ! Comment vous avez réussi à vous en tirer avec honneur, ça me dépasse...", SPAIN, 5, 1);
        break;
		case "Step_9_14":
            dialog.text = "Eh bien, ces pertes sont justifiées dans votre situation. Cependant, la récompense vous sera versée déduction faite de l'or manquant. Votre récompense totale est de 200 000 pièces d'or.\n"+
				          "Je pense que l'on peut dire sans crainte que vous avez su vous tirer d'une situation difficile avec honneur.";
            link.l1 = "Je vous suis reconnaissant, monsieur, d'avoir apprécié mes actes. Si vous n'avez plus besoin de moi, permettez-moi de vous laisser pour un temps.";
            link.l1.go = "Step_9_15";
        break;
		case "Step_9_15":
            dialog.text = "Bien, occupez-vous de vos affaires. N'oubliez pas, cependant, de me rendre visite de temps en temps.";
            link.l1 = "Très bien, don Francisco.";
            link.l1.go = "Step_9_exit";
			pchar.questTemp.Waiting_time = "12";
			pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
			AddMoneyToCharacter(pchar, 200000);
			AddTitleNextRate(sti(NPChar.nation), 0.5);
			ChangeCharacterReputation(pchar, 1);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 190);
			AddCharacterExpToSkill(pchar, "Leadership", 70);
			AddCharacterExpToSkill(pchar, "Commerce", 150);
			AddCharacterExpToSkill(pchar, "Pistol", 150);
			//слухи
			AddSimpleRumour("Capitaine, on dit partout que, pendant l'escorte des galions chargés d'or, on vous a tendu une embuscade ! Vous avez perdu une partie des galions, mais ce n'est pas grave ! L'essentiel, c'est que vous avez mouché les ladrones !", SPAIN, 5, 1);
		break;
		case "Step_9_16":
			dialog.text = "Oם ont bien pu passer " + FindRussianQtyString(5000-sti(npchar.quest.money)) + " d'or ?! C'est tout simplement scandaleux et inacceptable.";
            link.l1 = "Señor gouverneur général, vous savez dans quel pétrin j'étais et ce que j'ai traversé. La panique sur les galions, le diable sait ce qui s'y passait...";
            link.l1.go = "Step_9_17";
        break;
		case "Step_9_17":
            dialog.text = "Ce n'est pas une excuse ! Cependant, discuter n'a pas de sens... Je ne veux plus traiter avec vous en aucune circonstance. Adieu !";
            link.l1 = "Euh, eh bien...";
            link.l1.go = "Step_9_exit";
			pchar.questTemp.State = "QuestLineBreake";
			ChangeCharacterReputation(pchar, -3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -300);
			AddCharacterExpToSkill(pchar, "Leadership", -300);
			AddCharacterExpToSkill(pchar, "Commerce", -300);
			AddCharacterExpToSkill(pchar, "Pistol", -300);
			//слухи
			AddSimpleRumour("Capitaine, on dit que le gouverneur général vous a mis à la porte de sa résidence. Désormais, la route de la résidence vous est fermée...", SPAIN, 5, 1);
		break;
		case "Step_9_exit":
			pchar.questTemp.CurQuestNumber = "10";
            CloseQuestHeader("Spa_Line_9_FourGolgGaleons");
            for (i=1; i<=4; i++)
            {
                sld = characterFromID("Captain_"+i);
				if (sld.id != "none")
				{
					RemoveCharacterCompanion(pchar, sld);
					sld.LifeDay = 0;
				}
            }
            DialogExit();
        break;
//********************** Квест №10, Защита Маракайбо ************************
		case "Step_10_1":
            dialog.text = "Oui, encore !";
            link.l1 = "Señor, comme vous le savez, en exécutant les instructions du gouverneur de Portobelo, j'ai eu de sérieux ennuis...";
            link.l1.go = "Step_10_2";
        break;
		case "Step_10_2":
            dialog.text = "Ce problème est le résultat d'actions mal coordonnées. Des mesures ont été prises, cela ne se reproduira plus.";
            link.l1 = "Quelles missions dois-je accomplir à Maracaibo ?";
            link.l1.go = "Step_10_3";
        break;
		case "Step_10_3":
            dialog.text = "Je vous y envoie pour renforcer la ville, son escadre et sa garnison. Votre mission sera de protéger Maracaibo contre les actions hostiles.";
            link.l1 = "Dans quelle mesure dois-je obéir au gouverneur de la ville ?";
            link.l1.go = "Step_10_4";
        break;
		case "Step_10_4":
            dialog.text = "Dans le cadre de la mission générale de protection de la ville, vous relevez du gouverneur de Maracaibo. Votre mission ne comprend pas d'opérations qui n'y sont pas directement liées.";
            link.l1 = "Parfait ! Eh bien, je suis prêt à commencer la mission.";
            link.l1.go = "Step_10_5";
        break;
		case "Step_10_5":
            dialog.text = "Parfait ! Rendez-vous à Maracaibo le plus tכt possible.";
            link.l1 = "Bien, don Francisco, ma traversée jusqu'à Maracaibo ne prendra pas longtemps.";
            link.l1.go = "exit";
            pchar.questTemp.State = "Sp10Maracaibo_toMaracaibo";
            AddQuestRecord("Spa_Line_10_Maracaibo", "1");
			AddQuestUserData("Spa_Line_10_Maracaibo", "sSex", GetSexPhrase("", "e"));
        break;
		case "Step_10_6":
            dialog.text = "Mais je vous avais envoyé spécialement pour protéger la ville !";
            link.l1 = "Don Francisco, les forces des pirates étaient sans commune mesure avec les miennes. Je n'ai pas pu leur opposer une résistance digne de ce nom, j'ai dמ quitter le champ de bataille pour rester en vie...";
            link.l1.go = "Step_10_7";
        break;
		case "Step_10_7":
            dialog.text = "Je n'en crois pas mes oreilles ! ";
            link.l1 = "Hélas, c'est ainsi...";
            link.l1.go = "Step_10_8";
        break;
		case "Step_10_8":
            dialog.text = "Je ne veux plus avoir affaire à vous. Il n'y a jamais eu de tels lâches et de tels bons à rien au service de l'Espagne ! Quelle honte... C'est fini, la conversation est close une fois pour toutes, adieu.";
            link.l1 = "...";
            link.l1.go = "exit";
			CloseQuestHeader("Spa_Line_10_Maracaibo");
            DeleteAttribute(pchar, "questTemp.CurQuestNumber");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			pchar.questTemp.State = "QuestLineBreake";
            bWorldAlivePause   = false; // Конец линейки
			ChangeCharacterReputation(pchar, -5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Pistol", -430);
			AddCharacterExpToSkill(pchar, "Fortune", -460);
			AddCharacterExpToSkill(pchar, "Accuracy", -420);
			AddCharacterExpToSkill(pchar, "Grappling", -450);
			AddCharacterExpToSkill(pchar, "Sailing", -300);
			AddCharacterExpToSkill(pchar, "Leadership", -300);
			AddCharacterExpToSkill(pchar, "Commerce", -300);
			//слухи
			AddSimpleRumour("Capitaine, on dit que le gouverneur général vous a mis à la porte de sa résidence pour lâcheté. Désormais, la route de la résidence vous est fermée...", SPAIN, 5, 1);
        break;
		case "Step_10_9":
            dialog.text = "Excellent ! Je ne doutais pas de vous.";
            link.l1 = "Le gouverneur de Maracaibo, le señor " + Characters[GetCharacterIndex("Maracaibo_Mayor")].name + ", m'a chargé de vous dire qu'il vous est reconnaissant de votre aide opportune.";
            link.l1.go = "Step_10_10";
        break;
		case "Step_10_10":
            dialog.text = "Bien... Il vous a remercié ?";
            link.l1 = "Oui, monsieur, tout va bien...";
            link.l1.go = "Step_10_11";
        break;
		case "Step_10_11":
            dialog.text = "Eh bien, parfait ! Maintenant, je vous prierai de vous reposer et de reprendre des forces pour les prochaines batailles. Et ne disparaissez pas longtemps de la ville : il est possible que j'aie besoin de vous prochainement.";
            link.l1 = "Très bien, don Francisco.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "15";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "11";
            CloseQuestHeader("Spa_Line_10_Maracaibo");
			ChangeCharacterReputation(pchar, 5);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Pistol", 430);
			AddCharacterExpToSkill(pchar, "Fortune", 460);
			AddCharacterExpToSkill(pchar, "Accuracy", 420);
			AddCharacterExpToSkill(pchar, "Grappling", 450);
			//слухи
			AddSimpleRumour("Capitaine, on dit que vous avez réussi à défendre Maracaibo ! Sans exagération, c'est un véritable exploit, "+ GetSexPhrase("señor","señorita") +" !", SPAIN, 5, 1);
        break;
//********************** Квест №11, Нападение на Кюрасао и Сан Мартин ************************
		case "Step_11_1":
            dialog.text = "Très bien ! Alors, écoutez la mission.\n"+
				          "Dans le cadre de la guerre de Dévolution que nous menons contre la France pour les possessions espagnoles de Hollande, la première tâche et la plus importante pour nous est de détruire Curaçao et Saint-Martin. La dépêche interceptée a révélé que les Hollandais consacraient des sommes énormes aux besoins militaires de la France.\n"+
						  "Nous ne pouvons pas le prouver, car toute la correspondance est chiffrée d'une manière particulière : le sens de la lettre est complètement différent. Mais néanmoins, nous devons y mettre fin : la puissance commerciale hollandaise doit prendre fin !\n"+
						  "Vous devez prendre d'assaut et détruire les colonies hollandaises de Willemstad, sur l'île de Curaçao, et de Marigot, sur l'île de Saint-Martin. Tous les trophées pris au cours de l'opération vous reviennent.\n"+
						  "זtes-vous prêt pour une telle mission ?";
            link.l1 = "Oui, don Francisco. Quels sont les délais ?";
            link.l1.go = "Step_11_2";
        break;
		case "Step_11_2":
            dialog.text = "Aucun.";
            link.l1 = "Eh bien, très bien. Je m'y mets.";
            link.l1.go = "exit";
            SetNationRelation2MainCharacter(HOLLAND, RELATION_ENEMY); //ссорим ГГ и голландцев.
            SetNationRelationBoth(HOLLAND, SPAIN, RELATION_ENEMY);
            SetQuestHeader("Spa_Line_11_DestrHolland");
            AddQuestRecord("Spa_Line_11_DestrHolland", "1");
			AddQuestUserData("Spa_Line_11_DestrHolland", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State = "DestrHolland_GoOn";
			characters[GetCharacterIndex("Villemstad_Mayor")].dialog.captureNode = "SpaLine11Quest_DestrHol"; //капитулянтская нода мэра
			characters[GetCharacterIndex("Marigo_Mayor")].dialog.captureNode = "SpaLine11Quest_DestrHol"; //капитулянтская нода мэра
		break;
		case "Step_11_3":
            dialog.text = "Bravo ! Les Hollandais ont reçu une bonne tape sur les doigts : espérons que cela les rendra plus regardants sur leurs dépenses, ha ha.\n"+
				          "Le butin pris sur l'île vous revient de droit ! Je vous prie de venir à mon bureau dans un mois. J'ai de nouveau une affaire en préparation pour vous.";
            link.l1 = "Très bien, don Francisco. Je serai chez vous sans faute vers cette date.";
            link.l1.go = "exit";
			AddTitleNextRate(sti(NPChar.nation), 2);
            DeleteAttribute(pchar, "questTemp.Q11_Villemstad");
            DeleteAttribute(pchar, "questTemp.Q11_Marigo");
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "30";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "12";
            CloseQuestHeader("Spa_Line_11_DestrHolland");
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 7);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 270);
			AddCharacterExpToSkill(pchar, "Sneak", 260);
			AddCharacterExpToSkill(pchar, "Cannons", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 230);
			AddCharacterExpToSkill(pchar, "Fencing", 250);
			//слухи
			AddSimpleRumour("Beau travail, capitaine ! Vous avez donné une belle raclée à ces gredins de Hollandais !", SPAIN, 5, 5);
        break;
//********************** Квест №12, Захват Порт-о-Принса ************************
		case "Step_12_1":
            dialog.text = "Il faut que vous preniez une autre ville. Seulement cette fois, non pas pour la ruiner, mais pour y affirmer la puissance de l'Espagne.";
            link.l1 = "Excellent, señor gouverneur général. De quelle ville s'agit-il ?";
            link.l1.go = "Step_12_2";
        break;
		case "Step_12_2":
            dialog.text = "Cette ville, c'est l'actuel Port-au-Prince français. Vous avez déjà su régler le problème des boucaniers de La Vega ; maintenant, c'est au tour de cette colonie. Hispaniola doit devenir entièrement espagnole !";
            link.l1 = "Je comprends... Quels sont les délais ?";
            link.l1.go = "Step_12_3";
        break;
		case "Step_12_3":
            dialog.text = "Encore une fois, aucun. Prendre des villes n'est pas une tâche facile, il serait donc imprudent de ma part d'exiger des délais. Préparez-vous bien à la prise de la ville et passez à l'action.";
            link.l1 = "Excellent, señor gouverneur général. Je m'y mets.";
            link.l1.go = "exit";
            SetQuestHeader("Spa_Line_12_OccupyPortPax");
            AddQuestRecord("Spa_Line_12_OccupyPortPax", "1");
			AddQuestUserData("Spa_Line_12_OccupyPortPax", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State = "OccupyPortPax_GoOn";
			characters[GetCharacterIndex("PortPax_Mayor")].dialog.captureNode = "SpaLine12Quest_PortPax"; //капитулянтская нода мэра
        break;
		case "Step_12_4":
            dialog.text = "Parfait ! Je vais immédiatement informer toutes les parties intéressées de cette grande nouvelle. Une victoire magnifique, capitaine, une chance tout simplement fabuleuse !";
            link.l1 = "Un bon entraînement et l'expérience du combat : rien de surnaturel, señor...";
            link.l1.go = "Step_12_5";
        break;
		case "Step_12_5":
            dialog.text = "Sans aucun doute, la modestie sied au guerrier. Eh bien, je suis franchement heureux pour vous, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", vous voilà le capitaine le plus important des Caraïbes. Félicitations !";
            link.l1 = "Merci, don Francisco...";
            link.l1.go = "Step_12_6";
        break;
		case "Step_12_6":
            dialog.text = "Les principales missions que l'Espagne m'avait fixées sont donc accomplies. Désormais, je vous laisse libre d'agir dans l'intérêt du royaume. J'espère vraiment que vos actions futures ne feront qu'accroître la puissance de l'Espagne dans ces eaux.";
            link.l1 = "Vous pouvez en être sמr, señor gouverneur général. Sur ce, permettez-moi de prendre congé.";
            link.l1.go = "exit";
            AddTitleNextRate(sti(NPChar.nation), 4);
            DeleteAttribute(pchar, "questTemp.CurQuestNumber");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
            pchar.questTemp.State = "EndOfQuestLine";
			bWorldAlivePause   = false; // Конец линейки
			AddTitleNextRate(sti(NPChar.nation), 4);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
			CloseQuestHeader("Spa_Line_12_OccupyPortPax");
			AddCharacterExpToSkill(pchar, "Repair", 630);
			AddCharacterExpToSkill(pchar, "Sneak", 490);
			AddCharacterExpToSkill(pchar, "FencingLight", 530);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 530);
			AddCharacterExpToSkill(pchar, "Fencing", 530);
			AddCharacterExpToSkill(pchar, "Pistol", 530);
			AddCharacterExpToSkill(pchar, "Fortune", 660);
			AddCharacterExpToSkill(pchar, "Accuracy", 520);
			AddCharacterExpToSkill(pchar, "Grappling", 750);
			//слухи
			AddSimpleRumour("Capitaine, on dit que vous avez réussi à prendre Port-au-Prince ! L'île tout entière est à nous maintenant ?! Formidable !!", SPAIN, 5, 1);
		break;

//********************** //Квест "A New Homeland.". Спрашиваем про Лесопилку ************************
		case "HugoLesopilka_1":
            dialog.text = "Qui est cette personne ?";
            link.l1 = "Il s'appelle Hugo Sawmill. Il...";
            link.l1.go = "HugoLesopilka_2";
			DeleteAttribute(pchar, "questTemp.PDM_Novaya_Rodina.Guber");
        break;

		case "HugoLesopilka_2":
            dialog.text = "Vous rendez-vous compte que cet homme est un pirate répugnant et un assassin brutal ? Je ne permettrai jamais qu'il serve dans notre marine.";
            link.l1 = "Il n'est pas nécessaire de l'accepter à votre service. Il suffit de prendre son argent, et ensuite... Le criminel doit être puni, n'est-ce pas ?";
            link.l1.go = "Nakazat_1";
			link.l2 = "Mais il n'est pas dangereux... Je l'ai vu, ce n'est qu'un vieil homme fatigué, et son plus grand souhait est de dormir dans un lit confortable. Il est prêt à se retirer et cherche un havre sמr oם on le laissera vivre en paix.";
            link.l2.go = "Na_Slujbu_1";
        break;

		case "Nakazat_1":
            dialog.text = "C'est terrible ! Vous me proposez un pot-de-vin venant d'un criminel ? C'est offensant et inacceptable, "+ GetSexPhrase("señor","señorita") +" ! Ne me parlez plus jamais de cela !";
            link.l1 = "Compris. C'était une erreur de ma part. Cela ne se reproduira plus. Hasta luego !";
            link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -12);
        break;

		case "Na_Slujbu_1":
            dialog.text = "Hummm... Si vous le dites, vous avez peut-être raison. Je vous fais confiance dans cette affaire, "+pchar.name+". Je vais préparer une lettre de marque pour cet homme et vous la remettre. Il devra venir me voir immédiatement après l'avoir reçue. Maintenant, laissez-moi retourner à mes affaires.";
            link.l1 = "Bien sמr, Votre Excellence. Hasta luego !";
            link.l1.go = "Na_Slujbu_2";
			Log_info("Vous avez reçu une lettre de marque espagnole pour Hugo");
			GiveItem2Character(PChar, "Patent_Espa_Lesopilka");
			PlaySound("Interface\important_item.wav");
			ChangeCharacterReputation(pchar, 1);
			sld = CharacterFromID("Hugo_Lesopilka")
			ChangeCharacterAddressGroup(sld,"none","","");
			pchar.questTemp.PDM_Novaya_Rodina.IshemHugo = "IshemHugo";
        break;

		case "Na_Slujbu_2":
			AddQuestRecord("PDM_Novaya_Rodina", "2");
			AddQuestUserData("PDM_Novaya_Rodina", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PDM_Novaya_Rodina.Patent = "Patent";
			DialogExit();
        break;

		case "HugoLesopilka_Lubopitno_1":
			dialog.text = "Oh, merci beaucoup, "+ GetSexPhrase("señor","señorita") +" "+pchar.name+". C'est un soldat très brave et expérimenté. Nos ennemis ont déjà perdu une demi-douzaine de navires. Et c'est aussi un excellent conteur. Ses histoires sur le bon vieux temps attirent des foules d'auditeurs à la taverne ! Maintenant, si vous voulez bien m'excuser, je vais vous demander de me laisser.";
            link.l1 = "Sí, Votre Excellence. Hasta luego !";
            link.l1.go = "HugoLesopilka_Lubopitno_2";
			sld = CharacterFromID("Hugo_Lesopilka")
			ChangeCharacterAddressGroup(sld,"Havana_Town","goto","goto2");
			LAi_SetCitizenType(sld);
        break;

		case "HugoLesopilka_Lubopitno_2":
			AddQuestRecord("PDM_Novaya_Rodina", "5");
			AddQuestUserData("PDM_Novaya_Rodina", "sSex", GetSexPhrase("", "e"));
			sld = CharacterFromID("Hugo_Lesopilka")
			sld.dialog.filename   = "Quest\PDM\Novaya_Rodina.c";
			sld.dialog.currentnode   = "Novoe_Zadanie_1";
			ChangeCharacterAddressGroup(sld,"Havana_Town","goto","goto2");
			LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
			LAi_SetCitizenType(sld);
			LAi_SetLoginTime(sld, 6.0, 21.99);
			DeleteAttribute(pchar, "questTemp.PDM_Novaya_Rodina.Guber");
			DialogExit();
        break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
