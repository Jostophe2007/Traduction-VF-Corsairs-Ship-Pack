void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;
	bool bOk;
	ref shTo;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Exit_Chinaman_Speak":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DoQuestFunctionDelay("WhisperChinamanSpeaks", 0.5);
			DialogExit();
		break;
		case "Exit_ChiGuard_Speak":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DoQuestFunctionDelay("WhisperChinamanCapSpeaksAgain", 0.5);
			DialogExit();
		break;
		case "Exit_portman":
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.questTemp.Whisper.Portman_Deck = true;
			DoQuestCheckDelay("TalkSelf_Quest", 1.0);
			DialogExit();
		break;

		case "First time":
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "exit";

			if (npchar.id == "W_ChinamanGuard")
			{

				if (!CheckAttribute(npchar, "quest.meting"))
				{
					Lai_SetPlayerType(pchar);
					dialog.Text = "Capitaine, regardez quel « rat » on a attrapé dans la cale.";
					Link.l1 = "Bon sang, pourvu que ce ne soit pas encore un voyageur du temps. Il comprend au moins notre langue ?";
					Link.l1.go = "Exit_Chinaman_Speak";
					npchar.quest.meting = 1;
				break;
				}
				if (npchar.quest.meting == 1)
				{
					Lai_SetPlayerType(pchar);
					dialog.text = "Tu as mal choisi ton endroit pour une vie meilleure. La situation n'est guère plus brillante ici, sauf que les femmes y sont plus faciles. Euh... Bien sמr, je ne parlais pas de vous, capitaine.";
					link.l1 = "Ne me dérange pas pendant mon interrogatoire.";
					link.l1.go = "Exit_Chinaman_Speak";
					npchar.quest.meting = 2;
					break;
				}
				if (npchar.quest.meting == 2)
				{
					Lai_SetPlayerType(pchar);
					dialog.text = "Mais, capitaine... Bon, d'accord.";
					RemoveCharacterEquip(npchar, BLADE_ITEM_TYPE);
					link.l1.go = "Exit_Chinaman_Speak";
					npchar.quest.meting = 3;
					break;
				}
			}
			if (npchar.id == "W_Chinaman")
			{

				if (!CheckAttribute(npchar, "quest.meting"))
				{
					Lai_SetPlayerType(pchar);
					dialog.Text = "Je comprends.";
					Link.l1 = "Et comment tu t'appelles ?";
					Link.l1.go = "ChinamanSpeak_1";
					npchar.quest.meting = 1;
				break;
				}
				if (npchar.quest.meting == 1)
				{
					Lai_SetPlayerType(pchar);
					dialog.Text = "Pendant un temps, tout se passer comme on nous avoir promis. Nous naviguer longtemps vers l'ouest, passer beaucoup de pays et de peuples inconnus chez nous. Même si la nourriture qu'on nous donner être toujours la même, la joie nous remplir. Nous arriver au pays des sables, au bord du monde, que le grand amiral décrire sans précision, et aller encore plus loin. Mais certains de nous commencer à tomber malades, perdre leurs dents, même mourir, alors que le voyage ne pas être dur. Quand enfin nous arriver, les Hollandais ne pas nous accueillir comme nous espérer. Nos navires devoir aller un par un dans une baie isolée. Moi sentir que quelque chose ne pas aller, et ordonner à l'équipage de se préparer au combat. Mais tout être déjà décidé bien avant. Les Hollandais mouiller notre poudre, alors notre équipage ne pas pouvoir bien se défendre. Les Hollandais prendre le navire, et faire de moi et de l'équipage des esclaves.";
					Link.l1 = "Une rude histoire. On m'a accueillie ici à peu près de la même façon.";
					Link.l1.go = "ChinamanSpeak_1_1";
					npchar.quest.meting = 2;
					break;
				}
				if (npchar.quest.meting == 2)
				{
					Lai_SetPlayerType(pchar);
					dialog.Text = "Merci, capitaine, moi ne pas oublier ça.";
					GiveItem2Character(npchar, "blade9");
					EquipCharacterByItem(npchar, "blade9");
					LAi_SetImmortal(NPChar, false);
					Link.l1 = "Je l'espère vraiment.";
					Link.l1.go = "ChinamanOff";
					npchar.quest.meting = 3;
					break;
				}
			}

			NextDiag.TempNode = "First time";
		break;

		case "Portman_Cabin":
			dialog.Text = "Dis donc, ma fille, tu n'as plus peur de rien ? Pourquoi diable m'as-tu attaqué ?";
			Link.l1 = "Tu sais quelque chose qui m'intéresse. Les coordonnées de l'île oם le trésor est enterré.";
			Link.l1.go = "Portman_Cabin_1";
		break;
		case "Portman_Cabin_1":
			dialog.Text = "Ah... C'est donc toi, la voleuse qui a vidé ma planque aux Bermudes. Et tu as encore le culot de venir me trouver ? Tu n'apprendras rien de moi !";
			Link.l1 = "Alors, je trouverai tout moi-même, dès que j'en aurai fini avec toi !";
			Link.l1.go = "Portman_Cabin_fight";
		break;
		case "Portman_Cabin_fight":
			//AddQuestRecord("WhisperQuestline", "8");
			//CloseQuestHeader("WhisperQuestline");
			//SetFunctionNPCDeathCondition("Whisper_Portman_Cabin_Is_Dead", npchar.id, false);
			pchar.questTemp.Whisper.KilledPortman = true;
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			//AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "Portman":
			dialog.Text = "Salutations, belle inconnue.";
			Link.l1 = "Bonjour, capitaine.";
			Link.l1.go = "Portman_1";

			if (CheckAttribute(pchar, "Whisper.BetrayChard"))
			{
				dialog.Text = "Alors, ce pirate effronté a-t-il reçu le châtiment qu'il méritait ?";
				Link.l1 = "Pas encore.";
				Link.l1.go = "exit";
				if (CheckCharacterItem(pchar, "Bible"))
				{
					Link.l1 = "Bien sמr. Voici votre bible.";
					Link.l1.go = "Portman_betray_chard_1";
					pchar.Whisper.GotPortmanAx = true;
				}
			}
		break;
		case "Portman_1":
			NextDiag.TempNode = "Portman_3";
			dialog.Text = "Que faites-vous à bord de mon navire ?";
			//Link.l1 = "I want to ask, is it possible to search your cabin? The fact is that my brother served with you and recently signed off on shore, but forgot some documents.";
			//Link.l1.go = "Portman_enemy";
			Link.l1 = "Je veux vous prévenir que votre cachette aux Bermudes a été découverte et pillée par un pirate. Cet homme est à la recherche de vos autres trésors, si vous en avez.";
			Link.l1.go = "Portman_ally";
			Link.l2 = "Je jette juste un coup d'œil. Je pense acheter un navire semblable.";
			Link.l2.go = "Portman_2";
		break;
		case "Portman_2":
			dialog.Text = "Dans ce cas, je ne vous dérangerai pas. Mais je vous en prie, ne vous attardez pas trop, nous allons bientכt appareiller.";
			Link.l1 = "D'accord.";
			Link.l1.go = "exit_portman";
		break;
		case "Portman_3":
			dialog.Text = "Je vous en prie, ne vous attardez pas trop, nous appareillons bientכt !";
			Link.l1 = "D'accord...";
			Link.l1.go = "exit";
		break;
		case "Portman_ally":
			dialog.Text = "Je suis au courant. Mais vous ne connaissiez pas le nom du voleur ? Qui est-ce ?";
			Link.l1 = "L'aventurier s'appelle Michael Chard. Cet imbécile m'a envoyée vous soutirer des informations sur vos cachettes.";
			Link.l1.go = "Portman_ally_1";
		break;
		case "Portman_ally_1":
			dialog.Text = "Je n'ai jamais entendu ce nom. Enfin, peu importe. Si c'est vraiment lui, il a sans doute ma bible. Tuez ce Chard et rapportez-la-moi.";
			Link.l1 = "Et quelle sera la récompense pour ce service ?";
			Link.l1.go = "Portman_ally_2";
		break;
		case "Portman_ally_2":
			AddQuestRecord("WhisperChardQuest", "4");
			pchar.Whisper.BetrayChard = true;
			NextDiag.TempNode = "Portman_betray_chard";
			dialog.Text = "Je ne serai pas ingrat, croyez-moi. Bon, allez-y. Quand vous aurez fait le travail, je pense que vous me retrouverez sans problème, puisque vous l'avez déjà fait une fois.";
			Link.l1 = "D'accord.";
			Link.l1.go = "exit";
		break;
		case "Portman_betray_chard":
			dialog.Text = "Alors, ce pirate effronté a-t-il reçu le châtiment qu'il méritait ?";
			Link.l1 = "Pas encore.";
			Link.l1.go = "exit";
			if (CheckCharacterItem(pchar, "Bible"))
			{
				Link.l1 = "Oui. Voici votre bible.";
				Link.l1.go = "Portman_betray_chard_1";
				pchar.Whisper.GotPortmanAx = true;
			}
		break;
		case "Portman_betray_chard_1":
			AddQuestRecord("WhisperChardQuest", "5");
			CloseQuestHeader("WhisperChardQuest");
			pchar.Whisper.PortmanAtSea = true;//Отключаем подсказки по поиску Портмана - квест закрыт
			TakeItemFromCharacter(pchar, "Bible");
			Log_Info("Vous avez reçu la hache impériale");
			GiveItem2Character(pchar, "topor_emperor");
			PlaySound("interface\important_item.wav");
			dialog.Text = "Parfait ! Maintenant, je vais pouvoir dormir tranquille sans craindre que cette charogne me dévalise encore. Je vous avais dit que je ne serais pas ingrat. Tenez, prenez cette hache. Ne me demandez pas oם je l'ai eue, il n'y en a pas d'autre comme elle. Si elle ne vous plaît pas, vous pouvez la vendre. Je suis sמr que cette chose vaut une fortune.";
			Link.l1 = "דa alors ! Merci.";
			Link.l1.go = "exit";
		break;

		case "WarDogCap":
			dialog.Text = "Encore toi ? Je pensais que tu avais disparu depuis longtemps entre les murs de l'Inquisition.";
			Link.l1 = "On ne se débarrasse pas de moi si facilement.";
			Link.l1.go = "WarDogCap_1";
		break;
		case "WarDogCap_1":
			dialog.Text = "Comment m'as-tu seulement retrouvé ?";
			Link.l1 = "Ton ami l'inquisiteur, Antonio de Souza, a tendu ce piège lui-même. Tes récents agissements ont beaucoup irrité la couronne d'Espagne ; de Souza voulait te capturer ici en personne, mais je lui ai poliment demandé de me laisser cet honneur.";
			Link.l1.go = "WarDogCap_2";
		break;
		case "WarDogCap_2":
			dialog.Text = "Qu'est-ce que tu me veux, bon sang ?";
			Link.l1 = "Tu as quelque chose qui m'appartient.";
			Link.l1.go = "WarDogCap_2_1";
		break;
		case "WarDogCap_2_1":
			dialog.Text = "Tu veux parler de ton costume ? Je peux te le rendre si tu me laisses partir.";
			Link.l1 = "Pas seulement le costume : tout mon équipement, y compris l'appareil qui m'a permis de me téléporter ici.";
			Link.l1.go = "WarDogCap_3";
		break;
		case "WarDogCap_3":
			dialog.Text = "Quoi ? Ah, tu veux parler de cette quincaillerie inutile ? Je m'en suis débarrassé, avec le reste de la camelote. Il ne reste que le costume.";
			Link.l1 = "Qu'est-ce que tu as fait, imbécile ?! Comment ça, tu t'en es débarrassé ?";
			Link.l1.go = "WarDogCap_4";
		break;
		case "WarDogCap_4":
			dialog.Text = "Que tu ne le reverras plus. Et je ne vais pas laisser une femme me parler sur ce ton !";
			Link.l1 = "Je vais t'enterrer, ordure !";
			Link.l1.go = "WarDogCap_fight";
		break;
		case "WarDogCap_fight":
			AddQuestRecord("WhisperQuestline", "8");
			CloseQuestHeader("WhisperQuestline");

			UnlockAchievement("WhisperLine", 3);

			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
			pchar.Whisper.NanoCostume = true;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "DeSouza":
			dialog.Text = "Tiens, quelle surprise. Je te cherchais partout, Whisper.";
			Link.l1 = "J'en ai eu assez d'attendre que tu me trouves, alors je suis venue à toi.";
			Link.l1.go = "DeSouza_1";
		break;
		case "DeSouza_1":
			dialog.Text = "Courageuse, mais stupide. Tu as une idée de ce que je vais te faire maintenant ?";
			Link.l1 = "Je doute que tu en aies la force, tu tiens à peine debout. Je te propose une trêve. Parlons un peu.";
			Link.l1.go = "DeSouza_2";
		break;
		case "DeSouza_2":
			dialog.Text = "Et de quoi veux-tu parler ?";
			Link.l1 = "Je suis venue ici avec une machine à remonter le temps. C'est un appareil à l'aspect inhabituel, tu t'en souviendrais forcément. Hernán Esteban t'a-t-il remis quelque chose de ce genre ?";
			Link.l1.go = "DeSouza_2_1";
		break;
		case "DeSouza_2_1":
			dialog.Text = "Oui, il m'a montré quelque chose comme ça le jour oם il t'a amenée. Je lui ai demandé de faire disparaître au plus vite cet objet diabolique de ma vue, puis de l'enfouir au fond de la mer. Je ne sais pas vraiment s'il m'a écouté ou non.";
			Link.l1 = "J'espère vraiment que non. Tu sais oם l'on peut trouver Esteban ?";
			Link.l1.go = "DeSouza_3";
		break;
		case "DeSouza_3":
			dialog.Text = "Si seulement ! J'aimerais bien le savoir, moi aussi. Jusqu'à récemment, c'était un corsaire exemplaire, mais depuis peu, il s'est mis à faire des choses inacceptables pour un serviteur de l'Espagne. Je n'imagine pas quelle mouche l'a piqué, mais il a cessé de se présenter chez le gouverneur général, et son navire, d'après les rumeurs, a été vu en train de piller d'autres navires espagnols. C'est inacceptable, alors le gouverneur général m'a demandé de le retrouver personnellement et de le châtier. C'est ce que je fais en ce moment, et j'en profite pour attraper d'autres ennemis de la couronne, comme toi.";
			Link.l1 = "Alors, il n'y a absolument aucune piste sur l'endroit oם il pourrait être ?";
			Link.l1.go = "DeSouza_4";
		break;
		case "DeSouza_4":
			dialog.Text = "Il y en a une, mais avant de te la donner, laisse-moi te poser une question. Viens-tu vraiment du futur ?";
			Link.l1 = "Oui.";
			Link.l1.go = "DeSouza_5";
		break;
		case "DeSouza_5":
			dialog.Text = "Mon Dieu, maintenant, je vois que tu ne mens pas. Dis-moi, est-ce que quelqu'un se souvient de moi et de mon ordre, dans le futur ?";
			Link.l1 = "Dans le futur, les gens s'efforceront d'oublier ton ordre insensé. Et quand ils en parleront, ce sera seulement en mal, comme d'un foyer de cruauté et d'ignorance. Tout ce que vous avez obtenu, c'est une foule de morts et de vies brisées.";
			Link.l1.go = "DeSouza_6";
		break;
		case "DeSouza_6":
			dialog.Text = "Pour ces paroles, je devrais te haïr, et pourtant, il y a du vrai là-dedans. En voulant accomplir la volonté du Seigneur, j'ai beaucoup péché. Cependant, je ne pense pas avoir eu tort : parfois, le péché est une mesure nécessaire pour apporter le bien à ces diables d'hommes ! Seul le Seigneur peut me juger !";
			Link.l1 = "J'ai satisfait ta curiosité. א ton tour.";
			Link.l1.go = "DeSouza_7";
		break;
		case "DeSouza_7":
			AddQuestRecord("WhisperQuestline", "7");
			AddQuestUserData("WhisperQuestline", "sWhCapName", GetFullName(characterFromId("wl_Pirate_Cap")));
			SetTimerCondition("Whisper_WarDog", 0, 0, 7, false);
			dialog.Text = "J'ai payé une fille de bordel souvent fréquentée par " + GetFullName(characterFromId("wl_Pirate_Cap"))+", pour qu'elle lui glisse une rumeur à l'oreille : un trésor serait caché dans une baie des îles Turques. C'est un homme cupide, il devrait mordre à l'hameçon. D'après mes calculs approximatifs, si tout a marché, il devrait se montrer là-bas d'ici une semaine.";
			Link.l1 = "Un plan perfide et cruel, tout à fait dans le style de l'Inquisition.";
			Link.l1.go = "DeSouza_8";
		break;
		case "DeSouza_8":
			dialog.Text = "Que le Seigneur décide lequel de nous deux est destiné à l'intercepter, et lequel ira aujourd'hui au jugement de Dieu.";
			Link.l1 = "Amen.";
			Link.l1.go = "DeSouza_fight";
		break;
		case "DeSouza_fight":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
			pchar.Whisper.DeSouzaTalked = true;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "ChinamanSpeak_1":
			dialog.Text = "Long Wei.";
			Link.l1 = "Je vois que tu es un peu loin de chez toi. Tu viens du Japon, n'est-ce pas ? Tu sais, j'ai eu autrefois un sabre japonais...";
			Link.l1.go = "ChinamanSpeak_2";
		break;
		case "ChinamanSpeak_2":
			dialog.Text = "Moi venir ici de Chine, province du Shandong.";
			Link.l1 = "Je vois. Et pour quelle raison, au lieu d'être dans ta Chine, t'es-tu retrouvé sur mon navire ?";
			Link.l1.go = "ChinamanSpeak_3";
		break;
		case "ChinamanSpeak_3":
			dialog.Text = "Longue histoire. La patrie être en guerre toute l'année. L'empereur sans cesse lever des soldats pour l'armée. Beaucoup d'hommes mourir sans connaître de femme, à servir sous l'amiral Jiang Yin, qui commander ce qui rester de la flotte autrefois grande de Zheng He, qui faire sept grands voyages en mer il y a deux siècles. Moi être capitaine de jonque quand l'amiral réunir officiers et capitaines de confiance, moi aussi, et proposer de quitter le service. Aller non pas chez les pirates, mais chez les Hollandais, peuple de marins comme nous, comme Zheng He. L'amiral dire : eux apprécier les bons marins. Beaucoup accepter de partir, ceux pas d'accord mourir. Ensuite, nous partir ici, dans les Caraïbes, chercher une vie meilleure.";
			Link.l1 = "...";
			Link.l1.go = "Exit_ChiGuard_Speak";
		break;
		case "ChinamanSpeak_1_1":
			dialog.Text = "Moi être revendu beaucoup de fois, jusqu'au jour oם on m'envoyer servir ces gens méchants que tu rencontrer sur le rivage. Eux me battre et me faire porter choses lourdes. Moi me cacher d'eux dans la cale de ce navire.";
			Link.l1 = "Bon, maintenant, tout est clair. Tu es donc un esclave en fuite.";
			Link.l1.go = "ChinamanSpeak_1_2";
		break;
		case "ChinamanSpeak_1_2":
			dialog.Text = "Il semble que oui.";
			Link.l1 = "Ton histoire m'a touchée. Je peux te proposer une place dans l'équipage. Tu dis que tu étais capitaine ? Quelqu'un de ton expérience me serait utile, puisque je suis moi-même nouvelle dans ce métier.";
			Link.l1.go = "ChinamanSpeak_1_3";
			Link.l2 = "Alors, ta place est parmi les autres esclaves. Juan, emmène-le à la cale.";
			Link.l2.go = "ChinamanSlave";
		break;
		case "ChinamanSpeak_1_3":
			dialog.Text = "Moi pouvoir aider à diriger le navire, et aussi, moi savoir manier le sabre, moi pouvoir être garde du corps.";
			Link.l1 = "Dans ce cas, Juan, donne-lui ta lame. Tu t'en trouveras une autre.";
			Link.l1.go = "Exit_ChiGuard_Speak";
		break;
		case "ChinamanSlave":
			DialogExit();
			ChangeCharacterReputation(pchar, -30);
			AddCharacterGoodsSimple(pchar, GOOD_SLAVES, 1);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 7);
			npchar.lifeday = 0;
			sld = characterFromID("W_ChinamanGuard");
			LAi_ActorGoToLocation(sld, "reload", "reload1", "none", "", "", "", 7);
			sld.lifeday = 0;

			PlayVoice("interface\"+LanguageGetLanguage()+"_EvEnemy1.wav");
			pchar.questTemp.Whisper.SmugPatrol = true;
			DoQuestCheckDelay("TalkSelf_Quest", 2.0);
		break;
		case "ChinamanOff":
			DialogExit();
			NPChar.Payment = true;
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			npchar.greeting = "GR_longway";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.HalfImmortal = true;  // Контузия
			npchar.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = true;
			LAi_SetWarriorType(NPChar);
			SetSelfSkill(NPChar, 25, 25, 25, 25, 25);
			SetShipSkill(NPChar, 15, 15, 20, 20, 40, 15, 15, 15, 15);
			SetSPECIAL(sld, 5, 5, 9, 4, 9, 9, 9);
			NPChar.rank = 6;
			LAi_SetHP(npchar, 120.0, 120.0);
			SetCharacterPerk(NPChar, "ByWorker");
			SetCharacterPerk(NPChar, "ShipSpeedUp");
			SetCharacterPerk(NPChar, "ShipTurnRateUp");
			SetCharacterPerk(NPChar, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней

			sld = characterFromID("W_ChinamanGuard");
			LAi_ActorGoToLocation(sld, "reload", "reload1", "none", "", "", "", 7);
			sld.lifeday = 0;
			PlayVoice("interface\"+LanguageGetLanguage()+"_EvShip3.wav");
			pchar.questTemp.Whisper.SmugPatrol = true;
			DoQuestCheckDelay("TalkSelf_Quest", 2.0);
		break;

		//Реакции
		case "WhisperIsHere_exit":
			DialogExit();
			RestoreOldDialog(npchar);
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_SetPlayerType(pchar);
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
		break;

		case "BS_21_WhisperIsHere":
			dialog.text = "";
			Link.l1 = "Tu tombes à pic ! Je me demande à quoi je pense quand je m'aventure seule dans les cabines pour affronter des capitaines.";
			Link.l1.go = "BS_21_WhisperIsHere_1";
		break;

		case "BS_21_WhisperIsHere_1":
			Pchar.CabinHelp = false;
			dialog.text = "Si tu veux, j'irai toujours à l'abordage des cabines avec toi.";
			Link.l1 = "Oui, ce serait bien.";
			Link.l1.go = "BS_21_WhisperIsHere_2";
			Link.l2 = "Ce n'est peut-être pas nécessaire.";
			Link.l2.go = "WhisperIsHere_exit";
		break;

		case "BS_21_WhisperIsHere_2":
			Pchar.CabinHelp = true;
			dialog.text = "D'accord.";
			Link.l1.go = "WhisperIsHere_exit";
		break;
	}
}
