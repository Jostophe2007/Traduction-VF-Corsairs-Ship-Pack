// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment..."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.MC == "toSeekSister")
			{
				link.l1 = "L'ami, je cherche une demoiselle nommée Elizabeth Sheppard. Tu en as déjà entendu parler ?";
				link.l1.go = "MCLiz";
			}
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_NevisTaverna_1"))
			{
				link.l1 = "J'aimerais savoir si une frégate noire est entrée au port.";
				link.l1.go = "BlackFregat_1";
			}
		break;
//========================  Квест "Strange things are happening in the archipelago" ==>
		case "BlackFregat_1":
			dialog.text = "Une frégate noire ? Laissez-moi réfléchir... Non, elle n'est certainement pas venue chez nous, mais je connais un gars qui semble être tombé dessus.";
			link.l1 = "Et ? Comment puis-je parler à cette personne ?";
			link.l1.go = "BlackFregat_2";
		break;
		case "BlackFregat_2":
			dialog.text = "Oui, il est assis là-bas, à une petite table ronde. Si je ne me trompe pas, il s'appelle Balltezar Figueidal.";
			link.l1 = "D'accord. Je vais aller lui parler.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_NevisTaverna_1");
			
			sld = CharacterFromID("PKM_SvpvA_Shturman_1")
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Shturman_v_taverne_2";			
		break;
//========================  Квест "Strange things are happening in the archipelago" <==		
		case "MCLiz":
			dialog.text = "Miss Liz Sheppard habite notre ville. Que lui voulez-vous ?";
			link.l1 = "Voyez-vous, elle a oublié quelque chose dans la baie de Maracaibo...";
			link.l1.go = "MCLiz_1";
		break;
		case "MCLiz_1":
			dialog.text = "Oui, Liz voyage beaucoup ces derniers temps. Vous ne la trouverez pas en ville.";
			link.l1 = "Et oם est-elle maintenant ?";
			link.l1.go = "MCLiz_2";
		break;
		case "MCLiz_2":
			dialog.text = "Chez elle, en ce moment.";
			link.l1 = "Elle a sa propre maison ?";
			link.l1.go = "MCLiz_3";
		break;
		case "MCLiz_3":
			dialog.text = "Oui, la maison de son père.";
			link.l1 = "Et qui est son père ?";
			link.l1.go = "MCLiz_4";
		break;
		case "MCLiz_4":
			dialog.text = "Eh bien, c'est une chose à dire tout bas, mais je vais vous le dire.\n"+
				"Vous avez entendu parler du capitaine Staton ? Non ? Ho ho, alors sachez que le capitaine Staton, l'un des premiers flibustiers, est le père de Liz. De son vivant, le capitaine a beaucoup fait pour le développement de la ville, c'est pourquoi les habitants de Niévès lui sont redevables.";
			link.l1 = "Elizabeth porte le nom de Sheppard.";
			link.l1.go = "MCLiz_5";
		break;
		case "MCLiz_5":
			dialog.text = "C'est ce qu'a décidé le capitaine. Quand il s'est installé en ville avec sa famille, il a pris un autre nom. Au cas oם...";
			link.l1 = "Et Liz vit seule maintenant ?";
			link.l1.go = "MCLiz_6";
		break;
		case "MCLiz_6":
			dialog.text = "Oui, sa mère n'a guère survécu à son mari, elle est enterrée ici, sur l'île. Et Danielle n'est pas revenue à la maison depuis deux ans.";
			link.l1 = "Daniel ?";
			link.l1.go = "MCLiz_7";
		break;
		case "MCLiz_7":
			dialog.text = "La sœur aînée de Liz.";
			link.l1 = "Compris. Eh bien, merci, l'ami.";
			link.l1.go = "MCLiz_8";
		break;
		case "MCLiz_8":
			dialog.text = "Je vous en prie. J'espère que vous apportez de bonnes nouvelles à Liz. C'est une brave fille, capitaine...";
			link.l1 = "En tout cas, rien de mauvais. דa, c'est sמr.";
			link.l1.go = "exit";
			pchar.questTemp.MC = "toSeekSisterAT";
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

