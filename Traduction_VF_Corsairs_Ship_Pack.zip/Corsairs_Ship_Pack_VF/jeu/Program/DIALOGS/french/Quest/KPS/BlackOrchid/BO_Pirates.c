// Gregg: Matthew Grehom, leader of the corsair band - the "Black Orchid" trilogy
// (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// The meeting in the Cuban jungle before the assault on Santiago. Grehom means to
// storm the fort head-on; the player proposes taking the defenceless town, and is refused.
// In the original these nodes shared a file with the Bermudes messenger; ours lives
// in BO_Messenger.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.lastname;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Heureux de vous voir, capitaine " + sName + " ! Je suis Grehom, Matthew Grehom, chef de cette bande de corsaires. Mes gars sont de bons combattants, mais sans votre aide, nous n'y arriverons pas. Le risque est grand, mais si nous libérons Jason, nous vous paierons cent mille piastres. Le temps presse : décidez-vous.";
			link.l1 = "Attaquer le fort une seconde fois ne sert à rien. Les Espagnols ont bien préparé leur défense, plusieurs canons couvrent la route que vous prendriez, et des forces considérables y ont été déplacées depuis la ville.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "N'en dites pas plus, capitaine " + sName + ", je comprends : vous ne nous aiderez pas. Je n'insisterai pas. Mais réfléchissez encore avant de refuser. Cent mille, ce n'est pas une petite somme.";
			link.l1 = "Au contraire, je veux vous aider. Seulement, mon plan est différent.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Dites-le, " + sName + ". Et faites vite.";
			link.l1 = "Je propose de frapper la ville elle-même. Le gros des forces espagnoles est au fort en ce moment, et Santiago est laissée sans défense. Pendant qu'ils tiennent leurs positions en attendant une attaque, nous prenons la ville sans défense, nous nous frayons un chemin jusqu'à la résidence et nous nous emparons du gouverneur, et avec lui d'une dame très influente, la señora Matilda. De là, deux voies s'offrent à nous. La première : nous menaçons de les tuer tous les deux si les Espagnols ne déposent pas les armes et ne livrent pas Jason.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Les Espagnols ne sont pas des imbéciles. Ils prendront la ville d'assaut, et alors...";
			link.l1 = "Et c'est la seconde voie. S'ils lancent l'assaut, nous ne libérerons pas Jason et nous devrons nous replier par la mer jusqu'à Puerto Príncipe.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "זtes-vous assez fou, " + sName + ", pour espérer que j'accepte ça ?";
			link.l1 = "Et vous, Grehom, êtes-vous assez fou pour vous jeter, vous et tous vos hommes, contre un fort bien fortifié ? Croyez-vous vraiment qu'une centaine de corsaires tiendront tête à un ennemi plus nombreux et mieux armé ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je parie qu'avec ou sans votre aide, je me frayerai un chemin jusqu'à cette prison, capitaine " + sName + ".";
			link.l1 = "Dans ce cas, je ne peux que vous souhaiter bonne chance, Grehom.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "...(avec malveillance)... Bonne chance à vous aussi, capitaine " + sName + ". Adieu.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInSantiagoJungleDialog");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
