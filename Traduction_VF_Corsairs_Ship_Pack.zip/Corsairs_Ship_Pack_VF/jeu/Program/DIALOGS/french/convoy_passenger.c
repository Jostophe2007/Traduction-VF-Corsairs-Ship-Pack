//пассажир на доставку
void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag, arAll;
	string NPC_Meeting, sTemp, sTitle, sTavern;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Vous vouliez quelque chose, capitaine ?";
			Link.l1 = "Non, rien. Je vérifie juste que tout va bien.";
			link.l1.go = "exit";
		break;

		case "prepare_convoy_quest":
			if (isBadReputation(pchar, 40))
			{
				dialog.text = RandPhraseSimple("Oh, bon sang !! Je sais qui vous êtes ! Il faut être un parfait idiot pour monter à votre bord comme passager. Adieu !", "Ah, je sais qui vous êtes ! Je ne mettrai pas les pieds à votre bord. Cherchez un autre imbécile...");
				link.l1 = RandPhraseSimple("Héhé, quel froussard...", "Que les gens sont devenus peureux !");
				link.l1.go = "convoy_refused";
			}
			else
			{
				dialog.text = TimeGreeting() + ", "+GetAddress_Form(NPChar) + " ! Je suis "+ GetFullName(NPChar) + ". J'ai entendu dire que vous preniez des passagers à bord ?";
				link.l1 = "Peut-être, tout dépend de ce que j'y gagne.";
				link.l1.go = "prepare_convoy_quest_3";
			}
		break;

		case "prepare_convoy_quest_3":
			LookShipPassenger();
			GenerateConvoyPassengerQuest(npchar);
			dialog.text = "Il faut me conduire à la taverne de " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + ", sur l'île de " + XI_ConvertString(GetIslandByCityName(npchar.GenQuest.GetPassenger_Destination) + "Voc") +
                          ", dans un délai de " + FindRussianDaysString(sti(npchar.GenQuest.GetPassenger_Time)) + ", et si tout se passe bien, je vous paierai " + FindRussianMoneyString(sti(npchar.GenQuest.GetPassenger_Money)) + ". Qu'en pensez-vous ?";
			link.l1 = "Je "+ GetSexPhrase("d'accord","d'accord") +".";
			link.l1.go = "convoy_agreeded";
			link.l2 = "Je ne pense pas que ça m'intéresse.";
			link.l2.go = "convoy_refused";
		break;

		case "convoy_refused":
			chrDisableReloadToLocation = false;
			sTemp = npchar.id + "_TimeOver";
			pchar.quest.(sTemp).over = "yes";
			sTemp = npchar.id + "_dead";
			pchar.quest.(sTemp).over = "yes";
			DeleteAttribute(npchar, "GenQuest.GetPassenger");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 5.0);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "convoy_agreeded":
			sTitle = npchar.index + "convoy_passenger";
			AddQuestRecordEx(sTitle, "Gen_convoy_passenger", "1");
			sTemp = XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + ", sur l'île de " + XI_ConvertString(GetIslandByCityName(npchar.GenQuest.GetPassenger_Destination) + "Voc") + ",";
			AddQuestUserDataForTitle(sTitle, "sCity", sTemp);
			AddQuestUserDataForTitle(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sCity", sTemp);
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sDay", FindRussianDaysString(sti(npchar.GenQuest.GetPassenger_Time)));
            AddQuestUserData(sTitle, "sMoney", FindRussianMoneyString(sti(npchar.GenQuest.GetPassenger_Money)));
            // по городу вернём его таверну
			sTavern = npchar.GenQuest.GetPassenger_Destination + "_tavern";
			sTemp = npchar.id + "_complited";
			pchar.quest.(sTemp).win_condition.l1 = "location";
			pchar.quest.(sTemp).win_condition.l1.location = sTavern;
			pchar.quest.(sTemp).win_condition = "AllPassangersComplited";
			pchar.quest.(sTemp).Idx	= npchar.index;
			if (rand(2) == 1) TraderHunterOnMap();
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			chrDisableReloadToLocation = false;
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 5.0);
			Diag.CurrentNode = "convoy_DeskTalk";
			DialogExit();
		break;

		case "complete_convoy_quest":
			dialog.text = "Merci. Vous avez rempli vos engagements. Me voici à destination. Voici votre récompense.";
			Link.l1 = "Merci.";
			link.l1.go = "complete_convoy_quest_1";
		break;

		case "complete_convoy_quest_1":
			//слухи
		    chrDisableReloadToLocation = false; //#20180201-01
			AddSimpleRumour(LinkRandPhrase("Une certaine personne du nom de " + GetFullName(npchar) + " dit qu'on peut faire confiance au capitaine " + GetMainCharacterNameDat() + ", qui l'a menée sans le moindre problème jusqu'à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + ".",
				"Un passager du nom de " + GetFullName(npchar) + " dit que le capitaine " + GetMainCharacterNameDat() + " est digne de confiance. "+ GetSexPhrase("Il l'a conduit","Elle l'a conduit") +" jusqu'à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + " sain et sauf.",
				"J'ai entendu dire, capitaine, que vous tenez parole envers vos passagers. Un certain marchand du nom de " + GetFullName(npchar) + " dit le plus grand bien de vous."), sti(npchar.nation), 40, 1);
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "GenQuest.ConvoyPassenger." + npchar.id); //извлекаем из структуры недовольных
			//--> смотрим Deck
    		makearef(arAll, pchar.GenQuest.ConvoyPassenger);
			if (GetAttributesNum(arAll) == 0) pchar.quest.ConvoyMapPassenger.over = "yes";
			//<-- смотрим Deck
			AddMoneyToCharacter(pchar, makeint(npchar.GenQuest.GetPassenger_Money));
			ChangeCharacterReputation(pchar, 1);
			RemovePassenger(PChar, npchar);
			OfficersReaction("good");
			AddCharacterExpToSkill(pchar, "Sailing", 80);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			sTitle = npchar.index + "convoy_passenger";
			AddQuestRecordEx(sTitle, "Gen_convoy_passenger", "4");
			AddGoodDeedRepeat(1); // Gregg: доброе дело - довёз пассажира живым и в срок
            CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 5.0);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "convoy_DeskTalk":
			dialog.text = NPCStringReactionRepeat(LinkRandPhrase(RandSwear() + "Capitaine, le temps est écoulé. Quand vais-je enfin arriver à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Acc") + " ?",
						  RandSwear() + "Capitaine, combien de temps allez-vous encore errer Dieu sait oם ?! Quand arriverons-nous à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + " ?" ,
						  RandSwear() + "וcoutez, capitaine, je devais me rendre à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + " et je veux savoir clairement et précisément quand ce sera le cas !"),
				RandPhraseSimple("Capitaine, c'est la deuxième fois que j'aborde la question de vos engagements. Quand arriverons-nous à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + " ?", "Capitaine, je dois soulever pour la deuxième fois la question de mon voyage. Quand verrons-nous enfin les cכtes de " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + " ?"),
				RandPhraseSimple(RandSwear() + "Capitaine, je vous pose la même question pour la troisième fois : quand arriverons-nous à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Acc") + " ?", "Capitaine, nous avons perdu Dieu sait combien de temps ! Quand m'emmènerez-vous enfin à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Acc") + " ?"),
                "וcoutez, capitaine, c'est inadmissible...", "block", 0, npchar, Dialog.CurrentNode);
            if (sti(npchar.GenQuest.GetPassenger_Money) > 100)
            {
				link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Excusez-moi, les affaires m'ont..."+ GetSexPhrase("accaparé","accaparée") +"... Vous y serez sans faute dans 7 jours.", "Pardon, " + GetAddress_FormToNPC(NPChar) + ", il m'a été absolument impossible de tenir mes engagements envers vous. Mais ne vous inquiétez pas, nous y serons dans une semaine."),
					RandPhraseSimple("Je "+ GetSexPhrase("suis obligé","suis obligée") +" de m'excuser pour la deuxième fois... Nous y serons dans une semaine.", "Je m'excuse pour la deuxième fois. Nous y serons dans une semaine."),
					RandPhraseSimple("Et pour la troisième fois, je "+ GetSexPhrase("suis obligé","suis obligée") +" de vous présenter mes excuses... Nous y serons dans une semaine.", "Je m'excuse pour la troisième fois. Nous y serons dans une semaine, c'est promis..."),
					"Je comprends, " + GetAddress_FormToNPC(NPChar) + ", mais prenez encore un peu patience... Je vous conduirai à destination dans sept jours !", npchar, Dialog.CurrentNode);
    			link.l1.go = "convoy_DeskTalk_1";
			}
			link.l2 = HeroStringReactionRepeat(RandPhraseSimple("Ah... le passager... Je vous avais complètement "+ GetSexPhrase("oublié","oublié") +" ! Je pense que vous vous sentirez plus en sécurité dans la cale, et vous cesserez de m'importuner.", "Héhé, ça alors ! J'ai des inconnus sur mon navire !.. Je suppose qu'il vous faut faire connaissance avec ma cale."),
				"La deuxième fois ? Eh bien, ça alors... Je crois que je vais vous envoyer visiter la cale.",
				"La troisième fois ? Comme c'est fâcheux, héhé... וcoute, l'ami, il est temps pour toi d'aller dans la cale, inutile de te promener sur mon navire.",
				"Encore ? Ah, je comprends, c'est le comble de l'agacement ! Bon, assez joué aux osselets... Bienvenue dans la cale, " + GetAddress_FormToNPC(NPChar) + ".", npchar, Dialog.CurrentNode);
			link.l2.go = "convoy_Prison_1";
			pchar.quest.Munity = "Deads"; //дверцы откроем
		break;

		case "convoy_DeskTalk_1":
			dialog.text = LinkRandPhrase("D'accord, mais je réduirai le paiement pour un tel retard.", "Bon, je veux bien vous croire... Mais sachez que je réduirai le montant de votre paiement !", "Hum, je n'ai nulle part oם aller depuis ce navire, mais sachez que le montant de votre rémunération sera réduit...");
			Link.l1 = LinkRandPhrase("D'accord.", "Bon, d'accord...", "D'accord, soit.");
			link.l1.go = "convoy_DeskTalk_2";
		break;

		case "convoy_DeskTalk_2":
			dialog.text = RandPhraseSimple("Je veux croire que le contrat sera rempli, cette fois.", "J'espère que c'est notre dernière conversation sur un sujet aussi désagréable...");
			Link.l1 = "Bien sמr.";
			link.l1.go = "convoy_DeskTalk_exit";
		break;

		case "convoy_DeskTalk_exit":
			DeleteAttribute(pchar, "GenQuest.ConvoyPassenger." + npchar.id); //извлекаем из структуры недовольных
			sTemp = npchar.id + "_TimeOver";
			SetTimerCondition(sTemp, 0, 0, 7, false);
			pchar.quest.(sTemp).win_condition              = "AllPassangersTimeOver";
			pchar.quest.(sTemp).Idx						   = npchar.index;
			npchar.GenQuest.GetPassenger_Money = makeint(sti(npchar.GenQuest.GetPassenger_Money) / 1.5);
			sTitle = npchar.index + "convoy_passenger";
			AddQuestRecordEx(sTitle, "Gen_convoy_passenger", "5");
			AddQuestUserData(sTitle, "sMoney", FindRussianMoneyString(sti(npchar.GenQuest.GetPassenger_Money)));
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", 4.0);
			Diag.CurrentNode = "convoy_DeskTalk";
			DialogExit();
		break;

		case "convoy_Prison_1":
			dialog.text = RandSwear() + "Quelle cale ? Je ne vous comprends pas !";
			if (GetPrisonerQty() < PRISONER_MAX)
			{
    			Link.l1 = "Qu'est-ce qui n'est pas clair ? Vous êtes désormais en captivité ! א la cale !";
    			link.l1.go = "convoy_Prison_2";
            }
			Link.l2 = "Je plaisante... Nous serons dans la ville voulue dans sept jours exactement.";
			link.l2.go = "convoy_DeskTalk_1";
		break;

		case "convoy_Prison_2":
			dialog.text = RandSwear() + "Vous allez me le payer, "+ GetSexPhrase("gredin","gredine") +" !";
			Link.l1 = "Tout le monde dit ça, mais c'est toujours le contraire qui arrive : c'est moi qu'on paie !";
			link.l1.go = "convoy_Prison_3";
		break;

		case "convoy_Prison_3":
			AddSimpleRumour(LinkRandPhrase("On a appris qu'un certain capitaine, " + GetFullName(pchar) + " , avait promis de transporter un passager du nom de " + GetFullName(npchar) + ", mais "+ GetSexPhrase("n'a pas tenu parole","n'a pas tenu parole") +". En plus, ce capitaine "+ GetSexPhrase("a fait prisonnier","a fait prisonnier") +" le pauvre homme. Voilà ce que c'est que de faire confiance à des inconnus...",
				"Eh, oם va le monde ?! Le capitaine " + GetFullName(pchar) + " "+ GetSexPhrase("a fait prisonnier","a fait prisonnier") +" un pauvre gars du nom de " + GetFullName(npchar) + ", alors qu'il voyageait comme passager sur son navire...",
				"Le bruit court, capitaine, que vous êtes "+ GetSexPhrase("une sacrée ordure","une sacrée ordure") +". On dit que le pauvre " + GetFullName(npchar) + " a été fait prisonnier sur votre navire. Alors que vous aviez promis de le conduire à " + XI_ConvertString("Colony" + npchar.GenQuest.GetPassenger_Destination + "Gen") + ". Oui, c'est laid..."), sti(npchar.nation), 40, 1);
            RemovePassenger(PChar, NPChar);
        	LAi_SetActorType(NPChar);
        	LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 5.0);
        	ChangeCharacterReputation(pchar, -5);
            OfficersReaction("bad");
			ChangeCharacterHunterScore(pchar, NationShortName(sti(NPChar.nation)) + "hunter", 10+rand(10));// награда
			DeleteAttribute(pchar, "GenQuest.ConvoyPassenger." + npchar.id); //извлекаем из структуры недовольных
			sTemp = npchar.id + "_complited";
            pchar.quest.(sTemp).over = "yes";
			sTemp = npchar.id + "_dead";
			pchar.quest.(sTemp).over = "yes";
			sTemp = npchar.id + "_TimeOver";
			pchar.quest.(sTemp).over = "yes";
			sTitle = npchar.index + "convoy_passenger";
			AddQuestRecordEx(sTitle, "Gen_convoy_passenger", "6");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader(sTitle);
			AddCharacterExpToSkill(pchar, "COMMERCE", 25);
            SetCharToPrisoner(NPChar);
        	DialogExit();
		break;
	}
}

void GenerateConvoyPassengerQuest(ref npchar)
{
	int iTradeMoney, iNation, irank;
	string sTemp, sR;

	iNation = GetRelation2BaseNation(sti(npchar.nation)); //если привезти нужно во вражеский город
	npchar.GenQuest.GetPassenger_Destination = sGlobalTemp;
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(pchar.GenQuest.GetPassenger_City), GetArealByCityName(sGlobalTemp));
	if (sti(daysQty) > 14) daysQty = 14;
	npchar.GenQuest.GetPassenger_Time  = makeint(sti(daysQty)*(frand(1.3)+0.7));
	iTradeMoney = (sti(daysQty)*500*sti(pchar.GenQuest.GetPassenger.Shipmod)+rand(100))*sti(daysQty)/sti(npchar.GenQuest.GetPassenger_Time);
	if (iNation == RELATION_ENEMY && sti(npchar.nation != PIRATE)) iTradeMoney = makeint(iTradeMoney * 1.3); //то размер награды увеличивается
	npchar.GenQuest.GetPassenger_Money = iTradeMoney;

	//Log_Info(FindRussianDaysString(sti(daysQty)));
	//Log_Info(npchar.GenQuest.GetPassenger_Destination);
	//Log_Info(pchar.GenQuest.GetPassenger_City);


	sTemp = npchar.id + "_TimeOver";
	SetTimerCondition(sTemp, 0, 0, sti(npchar.GenQuest.GetPassenger_Time), false);
	pchar.quest.(sTemp).win_condition              = "AllPassangersTimeOver";
	pchar.quest.(sTemp).Idx						   = npchar.index;

	sTemp = npchar.id + "_dead";
	pchar.quest.(sTemp).win_condition.l1           = "NPC_Death";
	pchar.quest.(sTemp).win_condition.l1.character = npchar.id;
	pchar.quest.(sTemp).win_condition              = "AllPassangersDead";
	pchar.quest.(sTemp).Idx						   = npchar.index;
}

void LookShipPassenger()
{
	switch(makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)))
	{
		case 0:
			pchar.GenQuest.GetPassenger.Shipmod = 0.8;
		break;
		case 1:
			pchar.GenQuest.GetPassenger.Shipmod = 1;
		break;
		case 2:
			pchar.GenQuest.GetPassenger.Shipmod = 1.2;
		break;
		case 3:
			pchar.GenQuest.GetPassenger.Shipmod = 1.5;
		break;
		case 4:
			pchar.GenQuest.GetPassenger.Shipmod = 2.2;
		break;
		case 5:
			pchar.GenQuest.GetPassenger.Shipmod = 3;
		break;
		case 6:
			pchar.GenQuest.GetPassenger.Shipmod = 4.5;
		break;
	}
}
