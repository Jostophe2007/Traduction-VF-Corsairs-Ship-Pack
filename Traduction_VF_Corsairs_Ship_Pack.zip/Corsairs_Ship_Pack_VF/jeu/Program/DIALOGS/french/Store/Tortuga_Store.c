// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Il y avait longtemps qu'on n'avait pas entendu de telles questions dans le magasin de Tortuga...",
                          "Des questions, des questions, encore des questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Eh bien, ce n'était pas... ce n'était pas comme ça.", "D'abord, oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "WormEnglPlans_WormPicarder": //Голландская линейка, квест №3. узнаем о Пеьере Пикардийце.
                    link.l2 = "וcoutez, Pierre Picardy est-il passé dans votre magasin ? On m'a dit qu'il était venu ici.";
                    link.l2.go = "Step_H3_1";
                break;

            }
             // <== Проверяем поле состояния квестов.
		break;
 	 	case "Step_H3_1":
			dialog.text = NPCStringReactionRepeat("Il est passé il y a deux heures, il a acheté un nouveau lot de babioles hors de prix, puis il est reparti mener la grande vie.", "Señor, faisons plutכt du commerce, à quoi bon toujours les mêmes questions ?", "Vous m'avez déjà interrogé sur Pierre...", "וcoutez, vous pourriez peut-être vous renseigner sur Pierre ailleurs, hein ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, Pierre vit comme un coq en pâte en ce moment... Il vient souvent chez vous pour ce genre d'affaires ?", "Je l'ai dit ? Eh bien, oui, sans doute...", "On peut commercer...", "Oui, je crois que je vais me renseigner ailleurs.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H3_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H3_2":
			dialog.text = "Pratiquement tous les jours, à de rares exceptions près.";
			link.l1 = "Oh, il y en a qui ont de la chance ! Bon, je vais continuer à le chercher. Merci.";
			link.l1.go = "exit";
            pchar.questTemp.Talks.Store = true;
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "8");
        break;



	}
	UnloadSegment(NPChar.FileDialog2);
}

