@echo off
rem Desinstalle la version francaise et restaure les fichiers d'origine du jeu.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\desinstaller.ps1" %*
