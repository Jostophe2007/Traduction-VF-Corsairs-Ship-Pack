
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name + " " + PChar.lastname;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		// Первый дуалист -->
		case "Duelist_1_1":
			dialog.text = "Bonjour, capitaine " + sName + ". J'espère que vous avez un peu de temps pour parler ?";
			link.l1 = "Salutations, monsieur. Que se passe-t-il ?";
			link.l1.go = "Duelist_1_2";
			LAi_CharacterPlaySound(NPChar, "Duel_Man_Help");
		break;

		case "Duelist_1_2":
			dialog.text = "Le fait est que j'ai un duel prévu aujourd'hui, avec une certaine personne...";
			link.l1 = "Et quel est votre problème ?";
			link.l1.go = "Duelist_1_3";
		break;

		case "Duelist_1_3":
			dialog.text = "Vous comprenez... Je ne voudrais pas me battre moi-même contre lui. Je manie mal l'épée, mais mon honneur est en jeu, et je ne peux pas renoncer au duel. J'ai pensé que...";
			link.l1 = "Que puis-je faire pour vous ?";
			link.l1.go = "Duelist_1_4";
		break;

		case "Duelist_1_4":
			dialog.text = "C'est cela. Je vous paierai.";
			link.l1 = "Combien ?";
			link.l1.go = "Duelist_1_5";
		break;

		case "Duelist_1_5":
			dialog.text = sti(PChar.GenerateQuestDuel.Money) + " piastres.";
			link.l1 = "Je suis à votre service.";
			link.l1.go = "Duelist_1_7";
			link.l2 = "Ha ha ha ! Battez-vous vous-même pour votre honneur.";
			link.l2.go = "Duelist_1_6";
			// LEO: third option for a bloody-murderer reputation - scare the petitioners off for good.
			if (sti(pchar.reputation) <= 10)
			{
				link.l3 = "Je vais tous vous tailler en pièces si vous continuez à me harceler pour que je me batte en duel à votre place !";
				link.l3.go = "Duelist_ScareOff";
			}
		break;

		case "Duelist_1_6":
			dialog.text = "Mais capitaine !";
			link.l1 = "Bonne chance. Vous en aurez besoin.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelManCancel");
		break;

		case "Duelist_1_7":
			dialog.text = "Merci infiniment, capitaine. Le duel doit avoir lieu hors des portes de la ville. L'heure est venue : allons-y.";
			link.l1 = "Allons-y.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelAgree");
		break;

		// LEO: the cutthroat threatened the petitioner - the duelist generator shuts down for good
		case "Duelist_ScareOff":
			dialog.text = "(L'homme pâlit et recule.) Pardonnez-moi... pardonnez-moi, capitaine ! Je vous ai pris pour quelqu'un d'autre... Je ne dirai à personne que j'étais à votre recherche, je le jure !";
			link.l1 = "Filez. Et prévenez les autres.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelScareOff");
		break;

		case "Duelist_1_8":
			dialog.text = PChar.GenerateQuestDuel.WifeName + ", qui est "+GetSexPhrase("cet homme", "cette jeune femme")+" ?";
			link.l1 = "";
			link.l1.go = "Duelist_1_9";
		break;
		
		case "Duelist_1_9":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Wife));
			dialog.text = + GetSexPhrase("Chéri, ce capitaine a accepté de nous aider.", "Chéri, cette jeune femme a accepté de nous aider.") +"";
			link.l1 = "";
			link.l1.go = "Duelist_1_10";
		break;

		case "Duelist_1_10":
			SetCameraDialogMode(NPChar);
			dialog.text = "Aider à quoi ?!";
			link.l1 = "Monsieur, j'ai promis à votre femme de vous dissuader de vous battre en duel.";
			link.l1.go = "Duelist_1_11";
		break;

		case "Duelist_1_11":
			dialog.text = "Il n'en est pas question. Le duel aura lieu, même si ce salaud me présente des excuses publiques. Ton honneur est blessé, ma chère, et je dois laver cette honte dans le sang !";
			link.l1 = "";
			link.l1.go = "Duelist_1_12";
		break;
		
		case "Duelist_1_12":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Wife));
			dialog.text = + PChar.GenerateQuestDuel.DuelistName + "Je t'en prie, par tous les saints, reviens à la raison et fais la paix !..";
			link.l1 = "";
			link.l1.go = "Duelist_1_13";
		break;

		case "Duelist_1_13":
			SetCameraDialogMode(NPChar);
			dialog.text = "Je me battrai pour toi, et s'il le faut, je mourrai. Mais je mourrai avec honneur !";
			link.l1 = "Tout est clair. Je vois qu'on ne peut pas empêcher ce duel. C'est pourquoi je vous propose de me battre à votre place.";
			link.l1.go = "Duelist_1_14";
		break;

		case "Duelist_1_14":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Wife));
			dialog.text = "Comme c'est gentil à vous ! " + PChar.GenerateQuestDuel.DuelistName + ", accepte !";
			link.l1 = "";
			link.l1.go = "Duelist_1_15";
		break;
		
		case "Duelist_1_15":
			SetCameraDialogMode(NPChar);
			dialog.text = "Dans ces circonstances, c'est la seule issue. Je ne vaux pas grand-chose au combat, et à en juger par votre allure, vous avez connu des bagarres plus sérieuses.";
			link.l1 = "Vous avez raison. Alors, pour " + sti(PChar.GenerateQuestDuel.Money) + " piastres, je suis à votre service. Oם le duel doit-il avoir lieu ?";
			link.l1.go = "Duelist_1_16";
		break;

		case "Duelist_1_16":
			dialog.text = "Hors des portes de la ville. Venez, capitaine, l'heure est venue. " + PChar.GenerateQuestDuel.WifeName + ", tu restes à la maison.";
			link.l1 = "";
			link.l1.go = "Duelist_1_17";
		break;
		
		case "Duelist_1_17":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Wife));
			dialog.text = "Que Dieu vous bénisse, capitaine...";
			link.l1 = "Il faut y aller.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelWoman2Agree");
		break;

		case "Duelist_1_18":
			dialog.text = "Capitaine, je ne sais comment vous remercier ! Vous m'avez sauvé la vie. Ce mercenaire ne m'aurait laissé aucune chance !";
			link.l1 = "Si je comprends bien, j'ai "+ GetSexPhrase("rempli ma part du marché", "rempli ma part du marché") +" ?";
			link.l1.go = "Duelist_1_19";
			LAi_group_Delete("EnemyFight");
		break;

		case "Duelist_1_19":
			dialog.text = "Tenez, prenez cet argent. Merci encore, capitaine !";
			link.l1 = "א plus tard.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithMercenaryHappyEnd");
		break;

		case "Duelist_1_20":
			dialog.text = "Je ne sais comment vous remercier, capitaine ! Prenez l'argent et... j'espère que personne n'apprendra les détails de ce duel ?";
			link.l1 = "Ne vous inquiétez pas, je sais tenir ma langue. א plus tard.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithDuelistHappyEnd");
			LAi_group_Delete("EnemyFight");
		break;
		// Первый дуалист <--

		// Жена первого дуэлянта -->
		case "Wife_1":
			dialog.text = "Capitaine ! Je vous en supplie, aidez-moi !";
			link.l1 = "Madame, calmez-vous, je vous prie. Que s'est-il passé ?";
			link.l1.go = "Wife_2";
			LAi_CharacterPlaySound(NPChar, "Duel_Woman_Help");
		break;

		case "Wife_2":
			dialog.text = "Mon mari s'est disputé avec un voisin, et la querelle est allée si loin qu'ils ont décidé de la régler en duel. " + PChar.GenerateQuestDuel.DuelistName + " ne manie pas bien l'épée. Il va se faire tuer, j'en suis sמre !";
			link.l1 = "Je comprends. Vous voulez que je réconcilie votre mari avec son voisin ?";
			link.l1.go = "Wife_3";
		break;

		case "Wife_3":
			dialog.text = "Oui ! Je vous paierai " + sti(PChar.GenerateQuestDuel.Money) + " piastres, dissuadez-le seulement de se battre.";
			link.l1 = "Je vais essayer. Conduisez-moi auprès de votre mari.";
			link.l1.go = "Wife_5";
			link.l2 = "Pardon, mais ce n'est pas pour moi. Cherchez un autre négociateur.";
			link.l2.go = "Wife_4";
			// LEO: third option for a bloody-murderer reputation - scare the petitioners off for good.
			if (sti(pchar.reputation) <= 10)
			{
				link.l3 = "Je vais tous vous tailler en pièces si vous continuez à me harceler pour que je me batte en duel à votre place !";
				link.l3.go = "Wife_ScareOff";
			}
		break;

		case "Wife_4":
			dialog.text = "Vous êtes sans cœur !";
			link.l1 = "Euh... Que voulez-vous que j'y fasse.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelWomanCancel");
		break;

		// LEO: the cutthroat threatened her - she drags her husband away, the generator shuts down for good
		case "Wife_ScareOff":
			dialog.text = "(La femme recule, une main sur la bouche.) Dieu me vienne en aide... pardonnez-moi, je ne savais pas à qui je m'adressais ! Nous partons, vous entendez ? Pour nous, vous n'avez jamais existé !";
			link.l1 = "Voilà qui est mieux. Et prévenez les autres aussi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelScareOff");
		break;

		case "Wife_5":
			QuestDuelWomanAgree();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		// Жена первого дуэлянта <--


		// Второй дуалист -->
		case "Duelist_2_1":
			dialog.text = "Ouais, je suis venu ! Hum !";
			link.l1 = "";
			link.l1.go = "Duelist_2_2";
		break;
		
		case "Duelist_2_2":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = "J'exige réparation !";
			link.l1 = "";
			link.l1.go = "Duelist_2_3";
		break;

		case "Duelist_2_3":
			SetCameraDialogMode(NPChar);
			dialog.text = "Vous l'aurez. Qui est-ce, avec vous ?";
			link.l1 = "";
			link.l1.go = "Duelist_2_4";
		break;
		
		case "Duelist_2_4":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = + GetSexPhrase("Cet homme", "Cette jeune femme") +" se battra à ma place.";
			link.l1 = "";
			link.l1.go = "Duelist_2_5";
		break;

		case "Duelist_2_5":
			SetCameraDialogMode(NPChar);
			dialog.text = "C'est votre droit. Eh bien, mon homme de confiance agira à ma place. Je vais vous confier un secret : c'est une excellente lame.";
			link.l1 = "";
			link.l1.go = "Duelist_2_6";
		break;
		
		case "Duelist_2_6":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = "Au diable les discours. Capitaine, on peut y aller ?";
			link.l1 = "א votre service, messieurs.";
			link.l1.go = "Duelist_2_7";
			LAi_ActorTurnToCharacter(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1), pchar);
		break;

		case "Duelist_2_7":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Mercenary));
			dialog.text = "Prépare-toi à mourir, "+GetSexPhrase("morveux", "morveuse")+" !";
			link.l1 = "Commençons !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithMercenary");
			LAi_ActorTurnToCharacter(CharacterFromID(PChar.GenerateQuestDuel.Characters.Mercenary), pchar);
		break;

		case "Duelist_2_8":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = "Bon sang !!! J'espère que vous êtes satisfait ?";
			link.l1 = "";
			link.l1.go = "Duelist_2_9";
			LAi_group_Delete("EnemyFight");
		break;
		
		case "Duelist_2_9":
			SetCameraDialogMode(NPChar);
			dialog.text = "Tout à fait. Maintenant, dehors. Je n'ai plus l'intention de vous voir.";
			link.l1 = "";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithMercenaryEnd");
		break;
		
		case "Duelist_2_10":
			dialog.text = "Salutations, messieurs ! " + PChar.GenerateQuestDuel.DuelistName + ", qui vous accompagne ?";
			link.l1 = "";
			link.l1.go = "Duelist_2_11";
		break;
		
		case "Duelist_2_11":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = + GetSexPhrase("Cet homme", "Cette jeune femme") +" se battra à ma place.";
			link.l1 = "";
			link.l1.go = "Duelist_2_12";
		break;
		
		case "Duelist_2_12":
			SetCameraDialogMode(NPChar);
			dialog.text = "Mon Dieu ! Vous êtes donc un fieffé lâche, " + PChar.GenerateQuestDuel.DuelistName + ", je ne le savais pas, je ne le savais pas...";
			link.l1 = "";
			link.l1.go = "Duelist_2_13";
		break;

		case "Duelist_2_13":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Duelist_1));
			dialog.text = "Assez de comédie ! Les règles permettent de recourir aux services de personnes de confiance.";
			link.l1 = "";
			link.l1.go = "Duelist_2_14";
		break;

		case "Duelist_2_14":
			SetCameraDialogMode(NPChar);
			dialog.text = "Eh bien, quand j'aurai réglé son compte à votre doublure, toute la ville saura que vous êtes un lâche. On commence ?";
			link.l1 = "א votre service.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithDuelist");
		break;
		// Второй дуалист <--

		// Родственники -->
		case "Relative_1":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Relative_1));
			dialog.text = "Que s'est-il passé ici ?";
			link.l1 = "Qui êtes-vous ?";
			link.l1.go = "Relative_2";
			LAi_CharacterPlaySound(NPChar, "Duel_Victory");
		break;

		case "Relative_2":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Relative_2));
			dialog.text = "On n'a pas réussi ! Notre oncle a été tué ! "+ GetSexPhrase("Salaud !!! Qu'as-tu fait ?", "Garce !!! Qu'as-tu fait ?") +"";
			link.l1 = "Attendez, je vais tout vous expliquer...";
			link.l1.go = "Relative_3";
		break;

		case "Relative_3":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Relative_1));
			dialog.text = "JE VAIS TE FAIRE LA PEAU !!!";
			link.l1 = "On s'est un peu mal compris...";
			link.l1.go = "Relative_4";
		break;

		case "Relative_4":
			SetCameraDialogMode(CharacterFromID(PChar.GenerateQuestDuel.Characters.Relative_2));
			dialog.text = "Défends-toi, charogne !";
			link.l1 = "Bon sang !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestDuelBattleWithRelativeRevenge");
		break;
		// Родственники <--

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
