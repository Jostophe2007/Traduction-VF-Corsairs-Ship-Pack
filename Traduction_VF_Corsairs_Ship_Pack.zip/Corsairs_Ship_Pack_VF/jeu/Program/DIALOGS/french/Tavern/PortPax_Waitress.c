// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// Gregg: the "Black Orchid" (ported from Damned Destiny) - the waitress has
			// the key to Brian George's chest. The attribute may not exist at all, hence
			// a separate check: Storm has no short-circuit, conditions cannot be merged.
			if (CheckAttribute(PChar, "MysteriousArtefact"))
			{
				if (PChar.MysteriousArtefact == "6")
				{
					link.l2 = "Vous vous souvenez de la bagarre dans votre taverne, il y a deux semaines ?";
					link.l2.go = "MysteriousArtefact_1";
				}
			}
		break;

		//==> Gregg: the Black Orchid - a mysterious artefact
		case "MysteriousArtefact_1":
			dialog.text = "Je préférerais de loin ne pas m'en souvenir, capitaine. C'était affreux.";
			link.l1 = "Je comprends, je vais aller droit au but. Un homme nommé Brian George a perdu une clé dans cette bagarre. L'avez-vous trouvée ?";
			link.l1.go = "MysteriousArtefact_2";
		break;

		case "MysteriousArtefact_2":
			dialog.text = "Oui. J'étais cachée dans un coin, et soudain une clé est tombée juste à cכté de moi. Je l'ai ramassée, et quand la bagarre a été finie, j'ai demandé à chaque client si elle était à lui. Personne n'avait perdu de clé, alors je l'ai gardée.";
			link.l1 = "Et Brian George ? Il était là, lui aussi : pourquoi ne lui avez-vous pas demandé ?";
			link.l1.go = "MysteriousArtefact_3";
		break;

		case "MysteriousArtefact_3":
			dialog.text = "Le patron l'a jeté dehors tout de suite. Et je n'aurais jamais imaginé qu'une si jolie petite clé puisse appartenir à cet ivrogne crasseux.";
			link.l1 = "Vous avez toujours la clé ?";
			link.l1.go = "MysteriousArtefact_4";
		break;

		case "MysteriousArtefact_4":
			dialog.text = "Oui. Mais je ne la donnerai qu'à son propriétaire légitime : Brian George.";
			link.l1 = "וcoutez, Brian George est mort : il a été tué il y a quelques jours aux Bermudes. Dans le coffre que cette clé ouvre, il y a quelque chose à moi qu'il devait me rendre. J'y tiens beaucoup, c'est un souvenir. Je vous en prie, donnez-moi la clé. Mon sort est entre vos mains.";
			link.l1.go = "MysteriousArtefact_5";

			if (sti(PChar.money) >= 5000)
			{
				link.l2 = "Je pourrais peut-être vous acheter cette petite clé ? Cinq mille piastres, disons. Qu'en pensez-vous ?";
				link.l2.go = "MysteriousArtefact_6";
			}

			link.l3 = "וcoute-moi bien, ma fille. Si tu ne me donnes pas cette clé, tu vas avoir de sérieux ennuis, je te le promets.";
			link.l3.go = "MysteriousArtefact_7";
		break;

		case "MysteriousArtefact_5":
			PChar.MysteriousArtefact.WaitressTalk = 1;
			dialog.text = "Bien, prenez-la. Elle est à vous.";
			link.l1 = "Bien obligé.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactFirstKeyGive");
		break;

		case "MysteriousArtefact_6":
			PChar.MysteriousArtefact.WaitressTalk = 2;
			AddMoneyToCharacter(PChar, -5000);
			dialog.text = "La clé est à vous.";
			link.l1 = "Bien obligé.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactFirstKeyGive");
		break;

		case "MysteriousArtefact_7":
			dialog.text = "Menacez-moi, et j'appelle la garde.";
			link.l1 = "Appelez-la. Voyez-vous, je suis en bons termes avec le gouverneur de votre ville, et il y a quelques jours, je lui ai sauvé la vie. Il ne laissera pas jeter son sauveur en prison. Mais vous, je vous ferai enfermer dans la pire cellule de votre prison pour le reste de vos jours. La jolie petite clé qu'on trouvera sur vous à la fouille me sera remise : personne ne croira qu'elle est à vous. א vous de choisir.";
			link.l1.go = "MysteriousArtefact_8";
		break;

		case "MysteriousArtefact_8":
			PChar.MysteriousArtefact.WaitressTalk = 3;
			dialog.text = "...(elle pâlit)... Prenez-la. Elle est à vous.";
			link.l1 = "Bien obligé. Et souvenez-vous : montrer les dents peut vous attirer bien des ennuis. Bonne journée.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactFirstKeyGive");
		break;
		//<== Gregg: the Black Orchid

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
