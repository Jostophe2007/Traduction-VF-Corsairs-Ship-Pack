
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\" + NPChar.City + "_Waitress.c";
    if (!HasCityDialogFile("Tavern", NPChar.City, "_Waitress.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\DefaultCity_Waitress.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\DefaultCity_Waitress.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
	switch(Dialog.CurrentNode)
	{
        case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
            NextDiag.TempNode = "First time";
			if (CheckAttribute(pchar, "questTemp.different.FackWaitress"))
			{
				if (pchar.questTemp.different == "FackWaitress_toRoom" || pchar.questTemp.different == "FackWaitress_toRoomUp")
				{
					dialog.text = "Je vous ai demandé de m'attendre en haut. Ne traînez pas ici, n'attirez pas l'attention...";
					link.l1 = "D'accord, je ne vais pas vous mettre dans l'embarras...";
					link.l1.go = "exit";
				}
				if (pchar.questTemp.different == "FackWaitress_noMoney" || pchar.questTemp.different == "FackWaitress_fighted")
				{
					dialog.text = "Je suis nouvelle ici, alors ne m'accaparez pas, je vous prie. Je ne me suis pas encore habituée à ma nouvelle place...";
					link.l1 = "Oם est la serveuse qui travaillait avant vous ? " + pchar.questTemp.different.FackWaitress.Name + ", je crois...";
					link.l1.go = "Love_IDN";
				}
				if (pchar.questTemp.different == "FackWaitress_facking")
				{
					dialog.text = "Reviens, mon chéri. S'il y a du temps, on s'amusera encore...";
					link.l1 = "Sans faute !";
					link.l1.go = "exit";
				}
				if (pchar.questTemp.different == "FackWaitress_fackNoMoney")
				{
					dialog.text = "Je ne vous connais pas, ne m'embêtez pas...";
					link.l1 = "Oם est mon argent ?!!";
					link.l1.go = "Love_IDN_1";
				}
				break;
			}
		    switch (Rand(4))
			{
				case 0:
					dialog.text = "Désolé, "+ GetSexPhrase("beau gosse", "ma belle") +", je suis occupée. Une bonne journée pour une taverne n'est pas toujours une bonne journée pour bavarder !";
					link.l1 = "...";
					link.l1.go = "exit";
					link.l9 = "Je veux vous poser deux ou trois questions.";
					link.l9.go = "quests";//(перессылка в файл города)
				break;

				case 1:
					dialog.text = "Je vous en prie, capitaine, ne faites pas de grabuge ! C'est si pénible de nettoyer après !";
					link.l1 = ""+ GetSexPhrase("Hum... Je n'en avais pas l'intention.", "J'ai l'air d'une bagarreuse ?") +"";
					link.l1.go = "exit";
					link.l9 = "Je veux vous poser deux ou trois questions.";
					link.l9.go = "quests";//(перессылка в файл города)
				break;

				case 2:
					dialog.text = ""+ GetSexPhrase("Oh, capitaine ! Vous voulez finir dans mes bras ce soir ? Je n'aime pas me vanter, mais...", "Asseyez-vous, capitaine. Un vrai loup de mer est toujours le bienvenu ici.") +"";
					link.l1 = ""+ GetSexPhrase("Hélas, je suis pressé en ce moment ! Une autre fois !", "Merci, ma jolie.") +"";
					link.l1.go = "exit";
					link.l9 = "Je veux vous poser deux ou trois questions.";
					link.l9.go = "quests";//(перессылка в файл города)
					// boal 27.03.2004 -->
					bool isBloodPrologue = false;
					if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true) isBloodPrologue = true;
					if (pchar.questTemp.different == "free" && !CheckAttribute(pchar, "questTemp.different.FackWaitress") && pchar.questTemp.piratesLine != "Soukins_toPuertoPrincipe" && PChar.sex != "woman" && pchar.questTemp.piratesLine != "Soukins_seekRings" && !isBloodPrologue && pchar.GenQuest.EncGirl != "HorseToTavern"/*&& npchar.city != "Villemstad"*/)
					{
						link.l2 = "Avec grand plaisir, ma belle !";
						link.l2.go = "Love_1";
						link.l9 = "Je veux vous poser deux ou trois questions.";
						link.l9.go = "quests";//(перессылка в файл города)
						if (SharleMaryIsHere())
						{
							link.l1 = "...";
							link.l1.go = "Mary_Eto_Lovushka_1";
							DeleteAttribute(link, "l2");
							DeleteAttribute(link, "l9");
							pchar.Mary.waitress.npcharID = npchar.id;
						}
					}
					// boal 27.03.2004 <--
				break;

				case 3:
					dialog.text = "Si vous voulez commander quelque chose, adressez-vous au patron. Il est derrière le comptoir.";
					link.l1 = "Merci du conseil.";
					link.l1.go = "exit";
					link.l9 = "Je veux vous poser deux ou trois questions.";
					link.l9.go = "quests";//(перессылка в файл города)
				break;

				case 4:
					dialog.text = "Si vous voulez bien vous reposer et reprendre des forces, louez une chambre pour la nuit. Dormir dans la salle commune n'ajoutera guère à vos forces.";
					link.l1 = "Merci.";
					link.l1.go = "exit";
					link.l9 = "Je veux vous poser deux ou trois questions.";
					link.l9.go = "quests";//(перессылка в файл города)
				break;
			}
			if (CheckAttribute(pchar, "GenQuest.SeekSpy.City")) //квест мэра поп поиску шпиона
			{
				link.l4 = "Dites-moi, "+ GetSexPhrase("ma belle", "ma chérie") +", vous n'avez remarqué personne de suspect ici ces derniers temps ?";
				if (pchar.GenQuest.SeekSpy.City == "1")
				{
					link.l4.go = "SeekSpy_Seen";
				}
				else
				{
					link.l4.go = "SeekSpy_NotSeen";
				}
			}
		break;

		case "Mary_Eto_Lovushka_1":
			StartInstantDialogNoType(pchar.SharleMaryId, "Mary_Eto_Lovushka_2", "Waitress_dialog.c");
		break;
		case "Mary_Eto_Lovushka_2":
			dialog.text = RandPhraseSimple("(à la serveuse) Je vais t'arracher les yeux, garce !", "(à la serveuse) Tu veux me prendre mon mari ?! Je vais t'envoyer en enfer, tout de suite !");
	        link.l1 = "Mary, range ce couteau ! Nous ne voulons pas d'ennuis ici.";
	        link.l1.go = "Mary_Eto_Lovushka_3";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorTurnToCharacter(npchar, CharacterFromID(pchar.Mary.waitress.npcharID));
		break;
		case "Mary_Eto_Lovushka_3":
			DialogExit();
			
			sld = characterFromID("SharleMary");
			sld.Dialog.Filename = "Quest\MainheroPrologues\Mary_dialog.c";
			sld.dialog.currentnode = "hired";
			LAi_SetOfficerType(sld);
		break;
        case "Love_1":
			dialog.text = "Alors écoute bien. Loue une chambre dans notre taverne. Montes-y et attends-moi. Je viendrai te rejoindre en douce plus tard...";
			link.l1 = "Hé ! Je vais tout faire, ma chérie ! J'attends !";
			link.l1.go = "exit";
			pchar.questTemp.different = "FackWaitress_toRoom";
			SetTimerFunction("WaitressFack_null", 0, 0, 1); //освобождаем разрешалку на миниквесты на след. день
			//Шанс, что ограбят, если рендом выпадет на 0. он же делитель сколько она вытащит из кармана
			pchar.questTemp.different.FackWaitress.Kick = cRand(2);
			pchar.questTemp.different.FackWaitress.Name = GetFullName(npchar); //запомним имя официантки
			pchar.questTemp.different.FackWaitress.City = npchar.city;
			//делаем клона официантки
			sld = GetCharacter(NPC_GenerateCharacter("WairessQuest", npchar.model, "woman", npchar.model.animation, 5, sti(npchar.nation), 3, false));
			sld.name = npchar.name;
			sld.lastname = npchar.lastname;
			sld.dialog.Filename = "Quest\ForAll_dialog.c";
			sld.dialog.currentnode = "Waitress";
			Pchar.quest.WaitressFack_inRoom.win_condition.l1 = "location";
			Pchar.quest.WaitressFack_inRoom.win_condition.l1.location = npchar.city + "_tavern_upstairs";
			Pchar.quest.WaitressFack_inRoom.function = "WaitressFack_inRoom";
			ChangeCharacterReputation(pchar, -1);
		break;
        case "Love_IDN":
			dialog.text = "Elle ne travaille plus ici, elle est partie... Désolée, j'ai beaucoup à faire.";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
		break;
        case "Love_IDN_1":
			dialog.text = "וcoute-moi bien, espèce de chien en rut. Je ne sais pas oם est ton argent ! Si tu m'embêtes, j'appelle la garde, et tu finiras en prison aujourd'hui même !";
			link.l1 = "Bon, pas besoin de la garde... Imbécile toi-même.";
			link.l1.go = "Love_IDN_2";
		break;
        case "Love_IDN_2":
			dialog.text = "C'est bien ça, imbécile toi-même. Désormais, tu seras plus malin et plus convenable.";
			link.l1 = "Ouais, je vais essayer...";
			link.l1.go = "exit";
		break;

		case "without_money":
			NextDiag.TempNode = "first time";
			dialog.text = "Vous êtes de retour parmi nous ?";
			link.l1 = "Mm-hmm.";
			link.l1.go = "without_money_2";
		break;

		case "without_money_2":
			dialog.text = "Vous vous sentez mal ? Vous avez mal à la tête ?";
			link.l1 = "Oם diable suis-je ?";
			link.l1.go = "without_money_3";
		break;

		case "without_money_3":
			dialog.text = "Vous ne vous souvenez donc de rien ? Pas même du vol ?";
			link.l1 = "Quoi ? Oh... ma tête... Qui a osé ?!";
			link.l1.go = "without_money_4";
		break;

		case "without_money_4":
			dialog.text = "Comment le saurais-je ? Ils sont venus, ont menacé de vous tuer, ont fouillé vos poches et sont repartis.";
			link.l2 = "Bon, ce qui est perdu est perdu.";
			link.l2.go = "exit";
		break;
		//==> eddy. квест мэра, вопросы не замечала ли шпиона
		case "SeekSpy_Seen":
			dialog.text = NPCStringReactionRepeat("Je ne sais même pas... Suspect ? Ah, attendez, il me semble qu'il y en a un. Il a l'air d'un citoyen ordinaire, mais il est trop collant, avec toutes sortes de questions, et je ne l'avais jamais vu en ville auparavant. Vous aurez du mal à le trouver ici, mais cherchez-le en ville.",
				"Oh, bon, nous avons déjà parlé de lui ! Je ne peux rien dire de plus.", "Encore la même chose... Je vous ai déjà tout dit.", "Combien de fois peut-on demander la même chose ?! Il vous faut peut-être autre chose ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, "+ GetSexPhrase("ma belle", "ma chérie") +". Bon, je vais chercher ce type.", "Ah oui ? Bon, d'accord...",
                      "Hum, oui...", "Pardon"+ GetSexPhrase(", ma belle", "") +"...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
		case "SeekSpy_NotSeen":
			dialog.text = NPCStringReactionRepeat("Non, je n'ai vu personne d'aussi suspect pour l'instant.",
				"Oh, bon, nous avons déjà parlé de lui ! Je ne peux rien dire de plus.", "Encore la même chose... Je vous ai déjà tout dit.", "Combien de fois peut-on demander la même chose ?! Il vous faut peut-être autre chose ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, "+ GetSexPhrase("ma belle", "ma chérie") +". Bon, je vais chercher ce type.", "Ah oui ? Bon, d'accord...",
                      "Hum, oui...", "Pardon"+ GetSexPhrase(", ma belle", "") +"...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
	}
}

