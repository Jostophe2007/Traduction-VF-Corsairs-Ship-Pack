
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":

            		if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";
				dialog.Text = NPCharRepPhrase(npchar,
                                LinkRandPhrase("Je m'appelle ", "Je m'appelle ", "Vous pouvez m'appeler ")
                                +GetFullName(npchar)
                                +LinkRandPhrase(". Que voulez-vous ?", ". Votre visage ne m'est pas familier. "
                                +"Qui êtes-vous ?", ". Qui êtes-vous, et que me voulez-vous ?"),

        		                LinkRandPhrase("Mes salutations, " + GetAddress_Form(NPChar) + ". Je m'appelle " + GetFullName(npchar) + ". Comment vous appelez-vous ?",
                                 "Bonjour, " + GetAddress_Form(NPChar) + " ! Je suis " + GetFullName(npchar) + ". Puis-je connaître votre nom ?",
                                 "Oui, " + GetAddress_Form(NPChar) + ". Que vouliez-vous ? Au fait, je m'appelle " + GetFullName(npchar) + ". Et vous ?"));

				Link.l1 = pcharrepphrase(
                                LinkRandPhrase("Sacrebleu ! ", "Mille diables ! ", "Que le diable t'emporte ! ") + "Oui, je suis le capitaine "+ GetFullName(Pchar)+ LinkRandPhrase(", vous êtes sourd"+NPCharSexPhrase(NPChar,"","e")+" ? Vous n'avez jamais entendu parler de moi, "+NPCharSexPhrase(NPChar,"canaille ?","ma belle ?"), " et la terreur de ces eaux ! ", " et que je sois damné si ce n'est pas vrai !"),
                                LinkRandPhrase("Je suis " + GetFullName(Pchar) + ", capitaine.", "Je m'appelle " + GetFullName(Pchar) + ".", "Appelez-moi capitaine " + GetFullName(Pchar) + "."));
                                Link.l1.go = "Meeting";
			}
			else
			{
				dialog.Text  = NPCharRepPhrase(npchar, LinkRandPhrase("Vous ne mentez pas, capitaine " + GetFullName(Pchar)+" ?",
                                                                    "Et alors, " + PChar.name+" ?",
                                                                    "Je me souviendrai de vous, " + GetFullName(Pchar)+".")
                                                                     + " Maintenant, dites-moi ce que vous voulez.",
                                                    LinkRandPhrase("Ravi de vous rencontrer, capitaine " + PChar.name,
                                                                    "Ravi"+NPCharSexPhrase(NPChar, "", "e")+" de vous rencontrer, " + GetAddress_Form(NPChar) + " " + PChar.lastname,
                                                                     "C'est un plaisir, capitaine " + PChar.name) + ". Mais vous ne vouliez sans doute pas seulement connaître mon nom, n'est-ce pas ?");
				link.l1 = PCharRepPhrase("Je veux apprendre quelque chose sur cette ville !", "Je veux apprendre quelque chose sur la ville.");
				link.l1.go = "new question";
 				link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
				link.l2.go = "quests";//(перессылка в файл города)
			}

			NextDiag.TempNode = "First time";
		break;


		case "Meeting":
		    dialog.Text  = NPCharRepPhrase(npchar, LinkRandPhrase("Vous ne mentez pas, capitaine " + GetFullName(Pchar)+" ?",
                                                                    "Et alors, " + PChar.name+" ?",
                                                                    "Je me souviendrai de vous, " + GetFullName(Pchar)+".")
                                                                     + " Maintenant, dites-moi ce que vous voulez.",
                                                    LinkRandPhrase("Ravi de vous rencontrer, capitaine " + PChar.name,
                                                                    "C'est un plaisir de vous rencontrer, " + GetAddress_Form(NPChar) + " " + PChar.lastname,
                                                                     "C'est un plaisir, capitaine " + PChar.name) + ". Mais je ne pense pas que vous vouliez seulement connaître mon nom, n'est-ce pas ?");

            	link.l1 = PCharRepPhrase("Je veux apprendre quelque chose sur cette ville !", "Je veux apprendre quelque chose sur la ville.");
			link.l1.go = "new question";
            		Link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
			Link.l2.go = "quests";

			Link.l5 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien : je vais à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			Link.l5.go = "exit";
			NextDiag.TempNode = "Meeting";
		break;

		case "new question":
            		dialog.text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Ah, oui, je pose la question avec plaisir... Mais vous feriez mieux d'avoir envie de boire un coup.", "Vous aimez bavarder, capitaine ? Eh bien, moi aussi... Surtout autour d'une chope de rhum.", "Oui, " + PChar.name + " ?"),
                                        LinkRandPhrase("Eh bien, que voulez-vous encore ?", "Je vois, capitaine "+PChar.name+", vous aimez faire la causette ? ", "Vous m'assommez de questions, capitaine ; il vaudrait mieux vous offrir du rhum.")),
		                PCharRepPhrase(LinkRandPhrase("Que vouliez-vous savoir, "+ GetAddress_Form(NPChar) + " ?", "Je vous écoute, capitaine.", "Je dois y aller, alors posez vite vos questions, capitaine."),
                                        LinkRandPhrase("Une bonne conversation, ça me fait toujours plaisir, " + GetAddress_Form(NPChar) + " " + PChar.lastname + ". Parlez.",
                                                        "Oui, " + GetAddress_Form(NPChar) + " ?",
                                                        "Vous aimez bavarder, capitaine ? Eh bien, moi aussi...")));

            		link.l1 = RandPhraseSimple("J'ai une affaire importante !", "J'ai une affaire pour vous.");
			link.l1.go = "quests";
			link.l2 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien : je vais à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			link.l2.go = "exit";
		break;

		case "quests":
            		dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment.");
		    	link.l1.go = "exit";
		break;


		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Faites attention dans les virages, capitaine, quand vous courez une arme à la main. Je pourrais perdre mes nerfs...", "Je n'aime pas qu'on se promène devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;




		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
