// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
		break;

		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Qu'est-ce qui vous intéresse ?";

            link.l1 = "Oם se trouve l'apothicairerie ?";
			link.l1.go = "Apteka";
			link.l2 = "Oם se trouve la Compagnie néerlandaise des Indes occidentales ?";
			link.l2.go = "GVIK";
			link.l3 = "J'ai une autre question.";
			link.l3.go = "new question";
		break;
		
		case "Apteka":
			dialog.text = "L'apothicairerie se trouve près du quai, à cכté de la taverne et de l'église. Le bâtiment est peint en bleu et blanc. L'entrée principale est fermée, il vaut donc mieux entrer par le cכté droit. Quand vous arriverez à l'arche, entrez tout de suite dans la cour et tournez à gauche vers la porte bleue. J'espère que ces informations vous ont été utiles.";
            link.l1 = "Vous avez été très obligeant"+ NPCharSexPhrase(NPChar, "", "e") +", merci !";
			link.l1.go = "exit";
			link.l2 = "Je voulais aussi vous demander quelque chose.";
			link.l2.go = "new question";
		break;
		
		case "GVIK":
			dialog.text = "La Compagnie néerlandaise des Indes occidentales se trouve dans un grand bâtiment administratif peint en jaune. Une immense et belle horloge orne l'une de ses tours. Il y a une garde bien armée à l'entrée. J'espère que ces informations vous ont été utiles.";
            link.l1 = "Vous avez été très obligeant"+ NPCharSexPhrase(NPChar, "", "e") +", merci !";
			link.l1.go = "exit";
			link.l2 = "Je voulais aussi vous demander quelque chose.";
			link.l2.go = "new question";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

