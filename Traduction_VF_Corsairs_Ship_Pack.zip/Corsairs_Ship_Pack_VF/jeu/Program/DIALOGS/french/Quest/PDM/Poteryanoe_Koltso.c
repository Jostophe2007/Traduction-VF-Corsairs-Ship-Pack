
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Vous n'avez pas vu ma bague, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "Pardon, madame ?";
			link.l1.go = "Starshka_1";
			PlayVoice("Kopcapkz\Voices\PDM\Old Woman.wav");
		break;

		case "Starshka_1":
			dialog.text = "J'ai perdu la bague... Vous ne l'avez pas vue ?";
			link.l1 = "Je ne sais pas trop... C'était quel genre de bague ?";
			link.l1.go = "Starshka_2";
			link.l2 = "Non, je ne l'ai pas vue. Au revoir.";
			link.l2.go = "exit";
		break;

		case "Starshka_2":
			dialog.text = "Oh, "+ GetSexPhrase("monsieur", "mademoiselle") +", c'était une bague très précieuse... elle coמtait très cher... Je suis tellement triste de l'avoir perdue...";
			link.l1 = "Précieuse, dites-vous ? Il y avait une pierre précieuse dessus, ou quelque chose comme ça ?";
			link.l1.go = "Starshka_3";
		break;

		case "Starshka_3":
			dialog.text = "Ha ha ha !!! Bien sמr ! Il y avait une pierre ! Un diamant ! Oui, c'était un diamant. Ou peut-être un rubis... Non, non, non, c'était une émeraude... C'est ça, une émeraude sur un anneau d'or... ou c'était une topaze... Ha ha ha !";
			link.l1 = "Madame, je ne pourrai pas retrouver votre bague sans une description précise... Bonne journée.";
			link.l1.go = "Starshka_4";
			NextDiag.TempNode = "Starshka_5";
			DeleteAttribute(npchar, "talker");
		break;

		case "Starshka_4":
			SetQuestHeader("PDM_Poteryanoe_Koltso");
			AddQuestRecord("PDM_Poteryanoe_Koltso", "1");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));

			pchar.questTemp.PDM_PK_UznatLichnost = "UznatLichnost";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Starshka_5":
			dialog.text = "Vous n'avez pas vu ma bague, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "Oh, non, madame. Je ne l'ai pas encore trouvée.";
			link.l1.go = "exit";
			PlayVoice("Kopcapkz\Voices\PDM\Old Woman.wav");
		break;

		case "Francheska":
			dialog.text = "Hé, "+ GetSexPhrase("matelot", "ma belle") +", je suis Francesca. Tu veux que je parte avec toi, et tu me raconteras tes voyages et tes grands exploits ? (souriant) Et tu me montreras...";
			link.l1 = "Hmmm... Volontiers. Mais je crois que tu vas d'abord me parler de ta bague.";
			link.l1.go = "SrazuProKoltso";
			link.l2 = "Oui, je peux te raconter beaucoup de choses sur mes aventures. Je crois que mon histoire va te plaire, Francesca. Dans une colonie vit une femme. Elle a perdu son fils il y a assez longtemps...";
			link.l2.go = "Istoria";
			PlayVoice("Kopcapkz\Voices\PDM\Francesca.wav");
			pchar.questTemp.PDM_PK_UvestiNaVerh = true;
		break;

		case "SrazuProKoltso":
			dialog.text = "Quelle bague ? Je n'ai pas de bague ! Va-t'en, va-t'en !";
			link.l1 = "Comprends-moi, j'ai besoin de cette bague pour une pauvre femme.";
			link.l1.go = "Otstan";
			link.l2 = "Donne-moi la bague, ou je décore ton joli minois avec mon couteau !";
			link.l2.go = "Krik";
			NextDiag.TempNode = "Uhodi";
		break;
		
		case "Otstan":
			dialog.text = "Tu veux ma bague ? Va-t'en, va-t'en !";
			link.l1 = "D'accord, je vais aller voir ta patronne.";
			link.l1.go = "exit";
		break;

		case "Krik":
			dialog.text = "Aaaaaaaaaaaa !!!! (cri terrible)";
			link.l1 = "דa suffit ! דa suffit ! Les gardes vont accourir... Bon, je vais aller voir ta patronne.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -2);
		break;

		case "Uhodi":
			dialog.text = "Tu veux ma bague ? Je n'ai pas de bague ! Va-t'en, va-t'en !";
			link.l1 = "D'accord, je vais aller voir ta patronne.";
			link.l1.go = "exit";
		break;

		case "Istoria":
			dialog.text = "C'est une histoire triste ! Je n'aime pas les histoires tristes, "+ GetSexPhrase("mon chou", "mon chou") +". Raconte-moi plutכt quelque chose de drכle !";
			link.l1 = "Non, Francesca, je vais d'abord finir celle-ci. Cette femme, comme je l'ai dit, a perdu son fils, et quand la nouvelle de sa mort est arrivée, elle est devenue folle. Elle avait donné à son garçon un souvenir. Et voilà que, dans sa folie, elle s'est imaginé avoir perdu ce talisman... Le talisman, pas son fils. J'aimerais le lui rendre. Je pense qu'elle souffre de façon inimaginable...";
			link.l1.go = "Istoria_2";
		break;

		case "Istoria_2":
			dialog.text = "(sanglot) Elle me rappelle ma maman ! Ma maman me confondait toujours avec la fille des voisins : elle s'appelait Francesca, elle aussi (sanglot). De quoi parlions-nous ? Ah, un objet magique ! Le talisman ! Quel genre de talisman c'était ?";
			link.l1 = "C'était une bague. Tu sais, on se sert souvent des bagues comme talismans.";
			link.l1.go = "Istoria_3";
		break;

		case "Istoria_3":
			dialog.text = "Oh ! Regarde, moi aussi, j'ai une bague. Elle est peut-être MAGIQUE ? C'est un homme gentil, un brave homme, qui me l'a donnée. Tiens. Dis-moi, c'est une bague MAGIQUE ?";
			link.l1 = "Oh, mon Dieu ! Incroyable ! C'est la bague MAGIQUE que la femme a perdue ! Si tu me rends cette bague, je la rapporterai à cette femme.";
			link.l1.go = "Volshebnoe";
			link.l2 = "Non, non, bien sמr que non, Francesca. Tout le monde voit bien que c'est une bague très ORDINAIRE. Si tu me rends cette bague, je la rapporterai à cette femme.";
			link.l2.go = "Obichnoe";
		break;

		case "Obichnoe":
			dialog.text = "Je ne veux pas de la bague d'un mort, surtout si elle n'est pas MAGIQUE. Tiens, prends-la.";
			link.l1 = "Merci. Tu es une fille très gentille, Francesca ! Je te promets qu'un jour, je reviendrai et je te raconterai une longue histoire sur mes aventures. Maintenant, je dois y aller.";
			link.l1.go = "Pomenyt";
			AddCharacterExpToSkill(pchar, "Leadership", 250);
			AddCharacterExpToSkill(pchar, "Sneak", 250);
			ChangeCharacterReputation(pchar, 5);
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;

			DeleteAttribute(pchar, "questTemp.PDM_PK_UvestiNaVerh");
			GiveItem2Character(PChar, "PDM_PK_Koltso");
			AddQuestRecord("PDM_Poteryanoe_Koltso", "4");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
		break;

		case "Volshebnoe":
			dialog.text = "C'est une bague ? Mais c'est une bague MAGIQUE ! Comment pourrais-je te la donner ?";
			link.l1 = "Je veux juste la rendre à sa véritable propriétaire. Réfléchis : une bague prise sur un mort, est-ce qu'elle te portera bonheur ?";
			link.l1.go = "Kupit";
		break;

		case "Kupit":
			dialog.text = "Vingt mille millions ! Et pas moins, pour la bague MAGIQUE ! La bague est MAGIQUE ! Tu l'as dit toi-même ! Alors, elle doit coמter cher ! Très cher !";
			link.l1 = "Tiens. (lui donner vingt)";
			link.l1.go = "Kupit_20";
			link.l2 = "Tiens. (lui donner vingt mille)";
			link.l2.go = "Kupit_20000";
			link.l3 = "Tiens. (lui donner vingt millions)";
			link.l3.go = "Kupit_20000000";
			link.l4 = "Tu sais, j'ai changé d'avis...";
			link.l4.go = "exit";
			NextDiag.TempNode = "Popitka_Vtoraya";
		break;

		case "Kupit_20":
			dialog.text = "Vingt mille millions ! J'ai vingt mille millions !!! Tiens, prends la bague.";
			link.l1 = "Merci. Avec ça, tu vas sמrement pouvoir acheter le palais du gouverneur. Adieu.";
			link.l1.go = "Pomenyt";
			AddMoneyToCharacter(pchar, -20);
			NextDiag.TempNode = "UNasKoltso";

			DeleteAttribute(pchar, "questTemp.PDM_PK_UvestiNaVerh");
			GiveItem2Character(PChar, "PDM_PK_Koltso");
			AddQuestRecord("PDM_Poteryanoe_Koltso", "4");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
		break;

		case "Kupit_20000":
			if (sti(pchar.Money) >= 20000)
			{
				dialog.text = "דa ne fait que mille ! Tu veux me rouler !!! Aaaaaaaaaaaa !!!! (cri terrible)";
				link.l1 = "דa suffit ! דa suffit ! Les gardes arrivent... Bon, je m'en vais.";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, -1);
			}
			else
			{
				dialog.text = "";
				link.l1 = "וcoute, je n'ai pas assez d'argent sur moi en ce moment, mais je te l'apporterai plus tard...";
				link.l1.go = "exit";
			}
		break;

		case "Kupit_20000000":
			if (sti(pchar.Money) >= 20000000)
			{
				dialog.text = "דa ne fait qu'un million ! Tu veux me rouler !!! Aaaaaaaaaaaa !!!! (cri terrible)";
				link.l1 = "דa suffit ! דa suffit ! Les gardes arrivent... Bon, je m'en vais.";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, -1);
			}
			else
			{
				dialog.text = "";
				link.l1 = "וcoute, je n'ai pas assez d'argent sur moi en ce moment, mais je te l'apporterai plus tard...";
				link.l1.go = "exit";
			}
		break;

		case "Popitka_Vtoraya":
			dialog.text = "Oh, c'est toi. Tu vas me raconter une histoire ?";
			link.l1 = "Non. Je viens chercher la bague.";
			link.l1.go = "Popitka_Vtoraya_2";
		break;

		case "Popitka_Vtoraya_2":
			dialog.text = "Tu as apporté vingt mille millions pour la bague MAGIQUE ?";
			link.l1 = "Tiens. (lui donner vingt)";
			link.l1.go = "Kupit_20";
			link.l2 = "Tiens. (lui donner vingt mille)";
			link.l2.go = "Kupit_20000";
			link.l3 = "Tiens. (lui donner vingt millions)";
			link.l3.go = "Kupit_20000000";
			link.l4 = "Tu sais, j'ai changé d'avis...";
			link.l4.go = "exit";
		break;

		case "UNasKoltso":
			dialog.text = "Hé, matelot ! J'ai vingt mille millions ! Tu sais d'oם je les tiens ?";
			link.l1 = "Bien sמr ! C'est moi qui te les ai donnés.";
			link.l1.go = "UNasKoltso_2";
			link.l2 = "דa ne m'intéresse pas.";
			link.l2.go = "UNasKoltso_3";
		break;

		case "UNasKoltso_2":
			dialog.text = "Oui, c'était toi ! Maintenant, je vais acheter le palais du gouverneur ! Et je t'invite à venir me voir !";
			link.l1 = "Merci, Francesca, ça me fait très plaisir pour toi.";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
		break;

		case "UNasKoltso_3":
			dialog.text = "Alors, va-t'en ! Je ne te dirai pas ce que j'ai fait de mes vingt mille millions !";
			link.l1 = "א plus tard, Francesca.";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
		break;

		case "Pomenyt":
			sld = CharacterFromID("Josephine_Lodet");
			sld.dialog.currentnode   = "Konets";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NaVerhuSFrancheska":
			dialog.text = "Entre, ne sois pas timide, fais comme chez toi pendant les deux prochaines heures.";
			link.l1 = "Non, Francesca, tu ne sortiras pas d'ici vivante.";
			link.l1.go = "UbitEE";
			link.l2 = "Viens à moi, mon poisson.";
			link.l2.go = "TrahEE";
			PlayVoice("Kopcapkz\Voices\PDM\Francesca.wav");
			npchar.lifeday = 0;
		break;

		case "TrahEE":
			AddDialogExitQuest("PlaySex_1");
			GiveItem2Character(pchar, "PDM_PK_Koltso");
			chrDisableReloadToLocation = false;
			sld = CharacterFromID("Josephine_Lodet");
			sld.dialog.currentnode   = "Konets";
			sld = CharacterFromID("PDM_PK_Francheska");
			sld.dialog.currentnode   = "PosleTraha";

			AddCharacterExpToSkill(pchar, "Sneak", 300);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Fortune", 100);
			AddCharacterHealth(pchar, 10);

			AddQuestRecord("PDM_Poteryanoe_Koltso", "5");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
			DialogExit();
		break;

		case "PosleTraha":
			dialog.text = "Je ne veux pas te laisser partir, "+ GetSexPhrase("mon", "ma") +" "+ GetSexPhrase("chevalier", "walkyrie") +".";
			link.l1 = "Adieu, Francesca.";
			link.l1.go = "exit";
			PlayVoice("Kopcapkz\Voices\PDM\Francesca.wav");
			LAi_CharacterDisableDialog(npchar);
		break;

		case "UbitEE":
			LAi_LocationFightDisable(loadedLocation, false);
			Lai_SetPlayerType(pchar);
			LAi_SetFightMode(pchar, true);

			sld = CharacterFromID("PDM_PK_Francheska");
			LAi_SetHP(sld, 20.0, 20.0);
			LAi_SetImmortal(sld, false);
			sld.SaveItemsForDead = true
			RemoveAllCharacterItems(sld, true);
			GiveItem2Character(sld, "PDM_PK_Koltso");
			LAi_SetActorType(sld); 
			LAi_ActorAnimation(sld, "afraid", "", 4.5);

			PChar.quest.PDM_PK_Ubita.win_condition.l1 = "item";
			PChar.quest.PDM_PK_Ubita.win_condition.l1.item = "PDM_PK_Koltso";
			PChar.quest.PDM_PK_Ubita.win_condition = "PDM_PK_Ubita";

			DialogExit();
		break;

		case "Konets":
			dialog.text = "Vous n'avez pas vu ma bague, "+ GetSexPhrase("monsieur", "mademoiselle") +" ? J'ai perdu ma bague. Elle doit être quelque part par ici. J'ai tellement honte, je m'en souviens à peine... Parfois, j'ai l'impression d'avoir perdu autre chose... Quelque chose que j'ai oublié...";
			link.l1 = "Oui, je sais ce que vous avez perdu. Je vous ai rapporté"+ GetSexPhrase("", "") +" votre bague, madame. On l'a retirée du corps de votre fils, mort pendant la bataille sous les murs de Santo Domingo. Tenez, prenez votre bague.";
			link.l1.go = "Konets_2";

			PlayVoice("Kopcapkz\Voices\PDM\Josephine Lodet.wav");
		break;

		case "Konets_2":
			TakeItemFromCharacter(pchar, "PDM_PK_Koltso");
			dialog.text = "Ma bague... Je me souviens de cette bague... Je l'avais donnée à quelqu'un qui devait la rapporter. Il devait revenir... Mon Jacques... oh...";
			link.l1 = "La vie continue, madame. Je pense que vous devriez retrouver vos proches, ils doivent beaucoup s'inquiéter de vous.";
			link.l1.go = "Konets_3";
		break;
		
		case "Konets_3":
			dialog.text = "Attendez, attendez, "+ GetSexPhrase("monsieur", "mademoiselle") +". Une récompense vous revient. Prenez ces cinq mille pièces et dix diamants. Ils sont à vous maintenant.";
			link.l1 = "Merci beaucoup, madame. Au revoir.";
			link.l1.go = "Nagrada";
			AddMoneyToCharacter(pchar, 5000);
			TakeNItems(PChar, "jewelry2", 10);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			ChangeCharacterReputation(pchar, 2);
		break;

		case "Nagrada":
			AddQuestRecord("PDM_Poteryanoe_Koltso", "6");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Poteryanoe_Koltso");
			pchar.questdata.KoltsoLodet = 1;
			sld = CharacterFromID("Josephine_Lodet");
			sld.dialog.filename   = "Common_citizen.c";
			sld.dialog.currentnode = "First Time";

			DialogExit();
		break;
	}
}
