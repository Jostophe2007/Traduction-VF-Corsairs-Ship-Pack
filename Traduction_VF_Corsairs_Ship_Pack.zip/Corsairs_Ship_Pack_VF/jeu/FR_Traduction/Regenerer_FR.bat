@echo off
rem Reconstruit la version francaise a partir des fichiers anglais du jeu et des memoires de traduction (tm\).
rem A relancer apres une mise a jour du jeu. Necessite Python 3 (avec numpy pour les polices).
cd /d "%~dp0tools"
where python >nul 2>nul || (echo Python introuvable : installez Python 3 puis relancez. & pause & exit /b 1)
python -X utf8 fr.py build || (echo Echec de fr.py build & pause & exit /b 1)
python -X utf8 patch_code.py || (echo Echec de patch_code.py & pause & exit /b 1)
echo.
echo Version francaise regeneree.
pause
