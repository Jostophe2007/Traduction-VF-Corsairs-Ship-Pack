# -*- coding: utf-8 -*-
"""Read/write Storm engine .tx textures (A8R8G8B8=21, A4R4G4B4=26, DXT3/DXT5 read-only via simple decoder)."""
import struct
import numpy as np

HDR = struct.Struct('<6i')

def read_tx(path):
    data = open(path, 'rb').read()
    flags, w, h, nmips, fmt, mipsize = HDR.unpack_from(data, 0)
    raw = data[24:24 + mipsize]
    if fmt == 21:
        a = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 4)  # B,G,R,A
        rgba = a[:, :, [2, 1, 0, 3]].copy()
    elif fmt == 26:
        v = np.frombuffer(raw, dtype='<u2').reshape(h, w)
        a = ((v >> 12) & 0xF) * 17
        r = ((v >> 8) & 0xF) * 17
        g = ((v >> 4) & 0xF) * 17
        b = (v & 0xF) * 17
        rgba = np.stack([r, g, b, a], axis=-1).astype(np.uint8)
    elif fmt in (0x33545844, 0x35545844):  # DXT3 / DXT5
        rgba = decode_dxt(raw, w, h, fmt)
    else:
        raise ValueError('unsupported fmt %d' % fmt)
    return dict(flags=flags, w=w, h=h, nmips=nmips, fmt=fmt, rgba=rgba, tail=data[24 + mipsize:])

def _c565(c):
    r = ((c >> 11) & 31) * 255 // 31; g = ((c >> 5) & 63) * 255 // 63; b = (c & 31) * 255 // 31
    return np.array([r, g, b], dtype=np.int32)

def decode_dxt(raw, w, h, fmt):
    out = np.zeros((h, w, 4), dtype=np.uint8)
    bw, bh = (w + 3) // 4, (h + 3) // 4
    off = 0
    for by in range(bh):
        for bx in range(bw):
            blk = raw[off:off + 16]; off += 16
            if fmt == 0x33545844:
                av = int.from_bytes(blk[0:8], 'little')
                alpha = [((av >> (4 * i)) & 0xF) * 17 for i in range(16)]
            else:
                a0, a1 = blk[0], blk[1]
                bits = int.from_bytes(blk[2:8], 'little')
                if a0 > a1:
                    pal = [a0, a1] + [((6 - i) * a0 + (i + 1) * a1) // 7 for i in range(6)]
                else:
                    pal = [a0, a1] + [((4 - i) * a0 + (i + 1) * a1) // 5 for i in range(4)] + [0, 255]
                alpha = [pal[(bits >> (3 * i)) & 7] for i in range(16)]
            c0 = int.from_bytes(blk[8:10], 'little'); c1 = int.from_bytes(blk[10:12], 'little')
            p0, p1 = _c565(c0), _c565(c1)
            cols = [p0, p1, (2 * p0 + p1) // 3, (p0 + 2 * p1) // 3]
            idx = int.from_bytes(blk[12:16], 'little')
            for i in range(16):
                px, py = bx * 4 + (i % 4), by * 4 + (i // 4)
                if px < w and py < h:
                    out[py, px, :3] = cols[(idx >> (2 * i)) & 3]
                    out[py, px, 3] = alpha[i]
    return out

def write_tx(path, rgba, fmt, nmips=None, flags=0):
    """Write texture. Generates a full mip chain if nmips>1 (box filter)."""
    h, w = rgba.shape[:2]
    levels = [rgba]
    if nmips and nmips > 1:
        cur = rgba.astype(np.float32)
        while len(levels) < nmips:
            hh, ww = cur.shape[:2]
            if hh == 1 and ww == 1:
                break
            nh, nw = max(1, hh // 2), max(1, ww // 2)
            cur = cur[:nh * 2, :nw * 2].reshape(nh, 2, nw, 2, 4).mean(axis=(1, 3)) if hh > 1 and ww > 1 else cur.reshape(nh, -1, nw, 4).mean(axis=1)
            levels.append(np.clip(cur + 0.5, 0, 255).astype(np.uint8))
    blobs = []
    for lv in levels:
        if fmt == 21:
            blobs.append(lv[:, :, [2, 1, 0, 3]].astype(np.uint8).tobytes())
        elif fmt == 26:
            q = (lv.astype(np.uint16) + 8) // 17
            v = (q[:, :, 3] << 12) | (q[:, :, 0] << 8) | (q[:, :, 1] << 4) | q[:, :, 2]
            blobs.append(v.astype('<u2').tobytes())
        else:
            raise ValueError('write fmt %d unsupported' % fmt)
    with open(path, 'wb') as f:
        f.write(HDR.pack(flags, w, h, len(levels), fmt, len(blobs[0])))
        for b in blobs:
            f.write(b)
