// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, jeune homme ?", "Que voulez-vous, beau gosse ?"), "Encore des questions ?", "Hi hi, la troisième fois aujourd'hui, toujours la même chose : des questions...",
                          "Hum, vous ne voudriez pas vous choisir une beauté ? Parce que sinon, je commence à me faire une idée bien précise de vous...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Hum, rien..."), "Non...",
                      "Ouais, c'est vraiment la troisième fois... Désolé.", "Pas maintenant... Une autre fois...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

