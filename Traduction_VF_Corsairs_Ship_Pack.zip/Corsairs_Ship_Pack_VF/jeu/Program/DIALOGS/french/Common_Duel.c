//navy 26.07.06
//генератор дуэлей...
//в диалоге НПС делаем линк с проверкой флага оскорбления... по нему переход на "outraged"
//если НПС сделал что-то ГГ (продажа фальшивки) или ГГ наехал на НПС, вешаем на него флаг.
//для некоторых, например ПГГ, можно делать переход сразу на вызов: "let_s_duel"
void ProcessDuelDialog(ref NPChar, aref Link, aref NextDiag)
{
	int iHour;
	string sLocation;

	//флаг убираем
	DeleteAttribute(NPChar, "Outrage");
    switch (Dialog.CurrentNode)
	{
	case "outraged":
		Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
				RandPhraseSimple("Comment osez-vous m'insulter, ordure ?!", "Vous allez payer cher vos paroles !"),
				RandPhraseSimple("Vous avez offensé mon honneur, " + GetAddress_Form(NPChar) + " ! Vous allez le payer.", "Comment osez-vous ? Retirez immédiatement vos paroles !"));

		//это такая засада.. чтобы читали текст :)
		MakeRandomLinkOrderTwo(link,
					NPCharRepPhrase(pchar,
				RandPhraseSimple("Hein ??!! Mais je ne veux pas salir mon épée avec vous !", "Hein ??!! Je ne veux même pas salir mon épée avec vous !"),
				RandPhraseSimple("Je suis toujours à votre service !", "Je n'ai pas l'intention de mâcher mes mots face à un moins-que-rien !")), "outraged_1",
					NPCharRepPhrase(pchar, RandSwear() +
				RandPhraseSimple("Je ne voulais pas...", "Je me suis emporté..."),
				RandPhraseSimple("C'était une erreur. Pardonnez-moi.", "Je me suis trompé, " + GetAddress_FormToNPC(NPChar) + ". Je vous prie de me pardonner.")), "change_mind");
		break;

	case "outraged_1":
		Dialog.Text = NPCharRepPhrase(NPChar,
				RandPhraseSimple("Je vais te couper les oreilles !", "Je vais t'arracher le cœur !"),
				RandPhraseSimple("J'espère que vous allez vous excuser immédiatement, sinon je ne réponds plus de moi !", "Vous comprenez ce que cela signifie ?"));

		MakeRandomLinkOrderTwo(link,
					NPCharRepPhrase(pchar, RandSwear() +
				RandPhraseSimple("J'espère que votre épée est aussi rapide que votre langue !", "Ma lame parlera pour moi."),
				RandPhraseSimple("Je vous provoque en duel !", "C'est une affaire d'honneur !")), "let_s_duel",
					NPCharRepPhrase(pchar,
				RandPhraseSimple("Je crois que je ne suis pas encore prêt à affronter le diable !", "Je pense que vous ne devriez pas vous emporter comme ça ! Ce ne sont que des mots !"),
				RandPhraseSimple("Je viens de me rappeler qu'on m'attend. Bonne continuation...", "Ah ! On dirait que mon navire lève déjà l'ancre.")), "change_mind");
		break;

	case "let_s_duel":
		//проверка на начатые дуэли.
		if (CheckAttribute(PChar, "questTemp.duel.Start") && sti(PChar.questTemp.duel.Start))
		{
			Dialog.Text = "Occupez-vous d'abord des autres, et ensuite nous parlerons.";
			if (PChar.questTemp.duel.enemy == NPChar.id)
			{
				Dialog.Text = "Vous et moi, nous nous sommes déjà mis d'accord sur tout.";
			}
			link.l1 = RandSwear() + "Comment ai-je pu oublier...";
			link.l1.go = "exit";
			break;
		}
		//может отказаться.
		if (drand(36) < GetCharacterSPECIALSimple(PChar, SPECIAL_E) + GetCharacterSPECIALSimple(PChar, SPECIAL_S) + GetCharacterSPECIALSimple(PChar, SPECIAL_A))         //WW
		{
			Dialog.Text = RandPhraseSimple("Un duel ?!!! Fichez le camp, vous ne valez pas qu'on perde son temps.", "Un duel ? Trop d'honneur ! Fichez le camp !");
			link.l1 = RandPhraseSimple("Eh bien, eh bien...", "Je peux attendre...");
			link.l1.go = "exit";
/**/
			//можно дать возможность драться полюбому :)
			if (drand(36) < GetCharacterSPECIALSimple(PChar, SPECIAL_E) + GetCharacterSPECIALSimple(PChar, SPECIAL_S) + GetCharacterSPECIALSimple(PChar, SPECIAL_A))    //WW
			{
				link.l1 = RandPhraseSimple("Eh bien, on va voir ça tout de suite !!!", "Qu'est-ce que vous dites ?! Je vais voir de quelle couleur est votre sang !");
				link.l1.go = "fight_right_now";
			}
/**/
			break;
		}

		//согласен.
		Dialog.Text = RandPhraseSimple("Un duel, dites-vous ? Je ne serais pas contre un peu d'exercice.",
			"Vous savez seulement par quel bout on tient une épée ?");
		link.l1 = RandPhraseSimple("Tu vas me supplier à genoux de t'épargner.", "Je vais t'achever de mes propres mains, misérab"+ GetSexPhrase("le","le") +" !");
		link.l1.go = "land_duel";
		if (sti(pchar.Ship.Type) != SHIP_NOTUSED && sti(NPChar.Ship.Type) != SHIP_NOTUSED)
		{
			Dialog.Text = RandPhraseSimple(Dialog.Text + " Ou alors, prenons la mer et voyons qui est le meilleur !",
				"Un duel ?!! Ha, je vais t'écraser comme une puce ! Choisis comment tu veux mourir !");
			link.l2 = RandPhraseSimple("En mer, je n'ai pas d'égal.", "Mon navire va couler ta vieille baille !");
			link.l2.go = "sea_duel";
		}
		link.l3 = "J'ai changé d'avis...";
		link.l3.go = "change_mind";
		break;

	//дуэль на подводных лодках :))))
	case "sea_duel":
		Dialog.Text = RandPhraseSimple("Je ne vois pas votre navire au port...", "Fichez le camp tant que vous ne vous serez pas trouvé ne serait-ce qu'une vieille baille !!!");
		link.l1 = RandPhraseSimple("Mon erreur...", "...Alors je vous laisse.");
		link.l1.go = "exit";
		if (pchar.location.from_sea == GetCurrentTown() + "_town")
		{
			Dialog.Text = "Bien, je vous attendrai à la sortie de la baie...";
			link.l1 = "Vous n'aurez pas à attendre longtemps.";

			pchar.questTemp.Duel.enemy = NPChar.id;
			pchar.questTemp.Duel.Sea_Location = Islands[GetCharacterCurrentIsland(PChar)].id;
			AddDialogExitQuestFunction("Duel_Sea_Prepare");
		}

		break;

	//на суше
	case "land_duel":
		iHour = 1 + rand(2);
		if (GetTime() > 4.0 && GetTime() < 17.0)
		{
//			iHour = MakeInt(18.0 - GetTime()) + rand(2); //раскоментировать для дуэлей только по ночам
		}
		pchar.questTemp.Duel.WaitTime = iHour;
		Dialog.Text = RandSwear() + RandPhraseSimple("Sortez votre lame, et voyons de quelle couleur est votre sang !", "Eh bien, si vous tenez tant à mourir...");
		link.l1 = RandPhraseSimple("Allons plutכt là oם il y a moins de témoins. Je connais un endroit hors des portes de la ville. Je vous y retrouve dans " + iHour + " heures.",
			"Hé... Pas si vite. Ce genre d'affaire se règle mieux sans témoins. Venez dans " + iHour + " heures à l'entrée de la ville.");
		link.l1.go = "fight_off_town";
		link.l2 = RandPhraseSimple("Eh bien, si vous êtes si pressé de mourir...", "Bon sang ! Je vais vous aider à aller en enfer !!!");
		link.l2.go = "fight_right_now";
		link.l3 = "J'ai changé d'avis...";
		link.l3.go = "change_mind";

		if (drand(1))
		{
			Dialog.Text = RandSwear() + RandPhraseSimple("Je pense que nous devrions sortir par les portes de la ville. Je vous y attendrai dans " + pchar.questTemp.Duel.WaitTime + " heures. Ne tardez pas !",
				"Ce n'est pas le meilleur endroit pour régler nos affaires. Mieux vaut sortir de la ville. Dans " + pchar.questTemp.Duel.WaitTime + " heure(s), j'y serai.");
			link.l1 = RandPhraseSimple("Trop d'honneur ! Défendez-vous !", "Je n'ai pas le temps ! Sortez votre lame !");
			link.l1.go = "fight_right_now";
			link.l2 = RandPhraseSimple("Eh bien, allons faire un tour.", "Vous avez peut-être raison. Je vous retrouve hors des portes.");
			link.l2.go = "fight_off_town_prep";
		}
		break;

	//предложение "Let's go outside." рассматривается
	case "fight_off_town":
		Dialog.Text = RandPhraseSimple("Trop d'honneur ! Défendez-vous !", "Je n'ai pas le temps ! Ici et maintenant !");
		link.l1 = RandPhraseSimple("Eh bien, si vous êtes si pressé de mourir...", "Bon sang ! Je vais vous aider à aller en enfer !!!");
		link.l1.go = "fight_right_now";
		if (drand(1))
		{
			Dialog.Text = RandPhraseSimple("Eh bien, allons faire un tour.", "Vous avez peut-être raison. Je vous retrouve hors des portes.");
			link.l1 = RandPhraseSimple("Je vous y attends.", "Ne soyez pas en retard.");
			link.l1.go = "fight_off_town_prep";
		}
		break;

	//что ж, пойдём выйдем
	case "fight_off_town_prep":
		SaveCurrentQuestDateParam("questTemp.Duel.StartTime");
		PChar.questTemp.duel.Start = true;
		PChar.questTemp.duel.enemy = NPChar.id;
		sLocation = GetCurrentTown();
		if (sLocation != "")
		{
			//где?
			sLocation += "_ExitTown";
			pchar.questTemp.duel.place = sLocation;

			Locations[FindLocation(sLocation)].DisableEncounters = true;
			//приходит ко времени.
			pchar.quest.duel_move_opponent2place.win_condition.l1 = "Location";
			pchar.quest.duel_move_opponent2place.win_condition.l1.location = pchar.questTemp.duel.place;
			pchar.quest.duel_move_opponent2place.function = "Duel_Move_Opponent2Place";
			//на случай, если не дождётся, часа вполне достаточно
			SetTimerConditionParam("duel_move_opponentBack", "Duel_Move_OpponentBack", 0, 0, 0, sti(GetTime() + 0.5) + sti(pchar.questTemp.Duel.WaitTime) + 1, false);
			pchar.quest.duel_move_opponentBack.function = "Duel_Move_OpponentBack";
			if (CheckAttribute(NPChar, "CityType"))
			{
				DeleteAttribute(NPChar, "City"); // чтоб не было ругани с нацией
	    		DeleteAttribute(NPChar, "CityType");
				if (!CheckAttribute(NPChar, "PGGAi"))
				{
					if (!CheckAttribute(NPChar, "LifeDay")) npchar.LifeDay = 0;
					npchar.LifeDay = sti(npchar.LifeDay) + 3; // чтоб до дуэли не помер
				}
    		}
		}
		NextDiag.CurrentNode = "let_s_duel";
		DialogExit();
		break;

	//последнее слово перед боем
	case "talk_off_town":
		Dialog.Text = "Alors, vous êtes prêt à aller en enfer ?";
		link.l1 = "Oui. Voyons maintenant qui vaut quoi !";
		link.l1.go = "fight_right_now";
		link.l2 = "Non, j'ai décidé de vous présenter mes excuses. J'avais tort, je me suis emporté.";
		link.l2.go = "change_mind";
		if (drand(36) < GetCharacterSPECIALSimple(PChar, SPECIAL_E) + GetCharacterSPECIALSimple(PChar, SPECIAL_S) + GetCharacterSPECIALSimple(PChar, SPECIAL_A))  //WW
		{
			Dialog.Text = RandPhraseSimple("וcoutez, j'ai réfléchi et j'ai fini par comprendre que j'avais tort. Je vous présente mes excuses",
				"Bon sang ! C'est la faute du rhum !!! Pardon, "+ GetSexPhrase("frère","sœur") +" !");
			link.l1 = NPCharRepPhrase(pchar,
				RandPhraseSimple("Eh bien non, maintenant seul votre sang peut me donner satisfaction !", "Sortez votre épée, et arrêtez de pleurnicher !"),
				RandPhraseSimple("Non ! J'exige réparation !", "Vous êtes la honte de votre famille ! Sortez votre épée !"));
			link.l1.go = "fight_right_now";
			link.l2 = NPCharRepPhrase(pchar,
				RandPhraseSimple("Bon, d'accord. J'ai réagi trop vivement.", "Pas de règlements de comptes entre nous !!"),
				RandPhraseSimple("Vous avez peut-être raison. Inutile de verser le sang pour des broutilles.", "Ma générosité n'a pas de limites ! Vous êtes pardonné !"));
			link.l2.go = "peace";
		}
		NextDiag.TempNode = npchar.BackUp.DialogNode;
		pchar.questTemp.Duel.End = true;
		break;

	//дуэли быть!
	case "fight_right_now":
		if(findsubstr(npchar.id, "PsHero_" , 0) != -1)
		{
			LAi_SetCheckMinHP(npchar, 1, true, "PGG_CheckHPDuel");
			SaveCurrentQuestDateParam("pchar.questTemp.DuelCooldown");
			chrDisableReloadToLocation = true;
		}
		PChar.questTemp.duel.enemy = NPChar.id;
		AddDialogExitQuestFunction("Duel_Prepare_Fight");
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		break;

	case "fight_right_now_1":	                  //WW  ?????
		PChar.questTemp.duel.enemy = NPChar.id;
		PChar.questTemp.duel.enemyQty = rand(2) + 1;
		AddDialogExitQuestFunction("Duel_Prepare_Fight");
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		break;

	//передумал, э... не хорошо ;)
	case "change_mind":
		if (CheckAttribute(pchar, "questTemp.Duel.End")) LAi_SetWarriorType(NPChar);
		Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
				RandPhraseSimple("Alors fichez le camp d'ici !", "Alors cachez-vous. Sinon, je pourrais changer d'avis."),
				RandPhraseSimple("Dans ce cas, je ne vous retiens pas plus longtemps !", "Alors vous feriez mieux de partir avant que je change d'avis."));
		link.l1 = "Je m'en vais déjà...";
		link.l1.go = "peace";
		break;

	case "after_peace":
		Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
				RandPhraseSimple("Fichez le camp d'ici !", "Cachez-vous. Sinon, je pourrais changer d'avis."),
				RandPhraseSimple("Que puis-je faire pour v"+ NPCharSexPhrase(NPChar,"ous","ous") +" ?", "Vous vouliez quelque chose ?"));
		link.l1 = "Je m'en vais.";
		link.l1.go = "peace";
		break;

	//мир и все такое.
	case "peace":
		chrDisableReloadToLocation = false;
		NextDiag.CurrentNode = "after_peace";
		DialogExit();
		break;

	case "Duel_Won":
		LAi_SetCurHPMax(npchar);
		Dialog.text = "Bon sang ! Je me rends.";
		link.l1 = "Je suis d'humeur clémente aujourd'hu"+GetSexPhrase("i","i")+". Fichez le camp.";
		link.l1.go = "duel_nomoney";
		link.l2 = "Parfait. Maintenant, videz vos poches !";
		link.l2.go = "duel_money";
		NextDiag.TempNode = "Second time";
		break;
	case "duel_nomoney":
		ChangeCharacterReputation(pchar, 10);
		PGG_ChangeRelation2MainCharacter(npchar, 20);
		Dialog.text = "Bon sang, vous êtes sérieux ? Je ne dis pas que je ferais pareil à votre place. Je ne l'oublierai pas.";
		link.l1 = "Filez avant que je change d'avis.";
		link.l1.go = "duel_exit";
		break;
	case "duel_money":
		ChangeCharacterReputation(pchar, -25);
		PGG_ChangeRelation2MainCharacter(npchar, -30);
		AddMoneyToCharacter(pchar, sti(npchar.money)/3);
		AddMoneyToCharacter(npchar, -sti(npchar.money)/3);
		Dialog.text = "Ah, espèce de "+GetSexPhrase("gredin","gredine")+" ! Bon, tant pis, je prendrai ma revanche.";
		link.l1 = "J'attendrai ça avec impatience.";
		link.l1.go = "duel_exit";
		if (!CheckAttribute(npchar, "PGGAi.Boosted"))
		{
			Train_PPG(npchar, true, true);
		}
		break;
	case "duel_exit":
		LAi_SetActorType(npchar);
		LAi_ActorRunToLocation(npchar, "reload", LAi_FindNearestFreeLocator2Pchar("reload"), npchar.PGGAi.location.town+"_Tavern", "", "", "", 10.0);
		NextDiag.CurrentNode = NextDiag.TempNode;
		LAi_SetImmortal(npchar, false);
		DialogExit();
		break;

	case "TreasureHunterPGG":
		NextDiag.CurrentNode = "Second time";
		//dialog.text = "Wait a minute, "+ GetSexPhrase("buddy","girlfriend") +"... I think you have something interesting. It is necessary to share the found treasures with your loved ones.";
		dialog.text = RandPhraseSimple("Je me doutais bien que cet escroc avait vendu plus d'une carte. Pas étonnant que je l'aie tué.","Un instant, "+ GetSexPhrase("l'ami","ma petite") +". Cette carte est à moi. Je ne sais pas exactement comment vous l'avez eue, mais un escroc me l'a volée pendant que j'étais ivre. Ces trésors ne vous appartiennent donc pas. ");
	    //if (PGG_ChangeRelation2MainCharacter(npchar, 0) < 41)
		if (sti(npchar.reputation) < 40)
		{
			dialog.text = "Vous étiez si aveugle que vous n'avez pas remarqué qu'on vous espionnait jusqu'au trésor.";
			Link.l1 = "Eh bien, il est temps de séparer ta tête de ton corps.";
			Link.l1.go = "battleTreasure";
			break;
		}
		Link.l1 = "Oui, la situation est délicate. Vous savez, je ne vais pas céder ce trésor comme ça : cette carte ne m'est pas tombée du ciel, et le chemin jusqu'ici n'était pas court. Mais je ne veux pas me disputer avec vous. Je propose qu'on partage le butin.";
		Link.l1.go = "Cost_Head";
            // boal 08.04.04 -->
        Link.l2 = "Eh bien, ce sont des choses qui arrivent, vous n'avez pas de chance. Maintenant, dégagez !";
		Link.l2.go = "NoMoney_1";
		break;
	case "battleTreasure":
        AddDialogExitQuest("Battle_PGGHunters_Land");
		PChar.quest.PGGbattleTreasure.win_condition.l1 = "NPC_Death";
		PChar.quest.PGGbattleTreasure.win_condition.l1.character = npchar.id;
		PChar.quest.PGGbattleTreasure.function = "T102_DoorUnlock";
        DialogExit();
        break;
	case "Cost_Head":
			PChar.HunterCost = MOD_SKILL_ENEMY_RATE*3/4 * sti(npchar.rank) * 1000 + rand(1000);
			dialog.text = "Vraiment ? J'étais déjà prêt à prendre les armes.\nBon, je ne suis pas contre. Je pense que " + sti(PChar.HunterCost) + " piastres me conviendront.";
			if(makeint(Pchar.money) < sti(PChar.HunterCost))
            {
                Link.l1 = "Je n'ai pas assez d'argent.";
                Link.l1.go = "NoMoney";
            }
			else
			{
                Link.l1 = "Soit, prenez-les.";
                Link.l1.go = "Cost_Head2";
                Link.l2 = "Donner une somme pareille à je ne sais qui... Je préfère encore vous embrocher !!!";
                Link.l2.go = "NoMoney";
            }
	break;
	case "NoMoney":
			dialog.text = "Dans ce cas, la conversation est terminée !";
			ChangeCharacterReputation(pchar, -15);
			Link.l1 = "On dirait bien.";
			Link.l1.go = "battleTreasure";
		break;
	case "NoMoney_1":
			dialog.text = "Pas question ! Vous n'irez nulle part avec mon trésor !";
			ChangeCharacterReputation(pchar, -15);
			Link.l1 = "Dans ce cas, il est temps de séparer ta tête de ton corps.";
			Link.l1.go = "battleTreasure";
	break;
	case "Cost_Head2":
        AddMoneyToCharacter(pchar, -(sti(PChar.HunterCost)));
		PGG_AddMoneyToCharacter(npchar, (sti(PChar.HunterCost)));
		ChangeCharacterReputation(pchar, 15);
		PGG_ChangeRelation2MainCharacter(npchar, 40);
		chrDisableReloadToLocation = false;
        dialog.text = "Vous êtes "+GetSexPhrase("un brave type","une chic fille")+" ! Merci de votre compréhension. J'espère qu'on se reverra, j'aurais bien bu un verre avec vous.";
		Link.l1 = "Voilà une offre tentante. Si l'occasion se présente, on boira un verre, c'est certain !";
		Link.l1.go = "Cost_Head3";
        break;
	case "Cost_Head3":
        AddDialogExitQuest("GoAway_PGGHunters_Land");
        DialogExit();
        break;

	case "Play_Game":
		bool allow = false;
		if (!CheckAttribute(pchar,"questTemp.pgggamesplayed"+npchar.index)) allow = true;
		if (GetQuestPastDayParam("questTemp.pgggamesplayed"+npchar.index) > 0) allow = true;
		if (PGG_ChangeRelation2MainCharacter(NPChar, 0) > 40 && allow)
		{
			DeleteAttribute(pchar,"questTemp.pgggamesplayed"+npchar.index);
			dialog.text = "Que proposez-vous ?";
			link.l1 = "Jouer aux cartes.";
			link.l1.go = "Card_Game";
			link.l2 = "Jouer aux dés.";
			link.l2.go = "Dice_Game";
			link.l10 = "Désolé, mais j'ai à faire.";
			link.l10.go = "exit";
		}
		else
		{
			dialog.text = LinkRandPhrase ("J'en ai peut-être envie, mais pas avec vous", "Fichez-moi la paix, je n'ai pas la tête à ça !", "Vous savez quoi ? " + LinkRandPhrase("J'ai déjà tout perdu.", "Je ne suis pas d'humeur, fichez-moi la paix", "Je ne suis pas d'humeur, fichez-moi la paix."));
			link.l10 = "Comme vous voudrez, c'est votre affaire.";
			link.l10.go = "exit";
		}
	break;
	// карты -->
	case "Card_Game":
		if (isBadReputation(pchar, 30) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < 1+rand(2))
		{
			dialog.text = "Ouste, je ne suis pas d'humeur.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "exit";
		}
		else
		{
			dialog.text = "Allez, jouons...";
			link.l1 = "Parfait.";
			link.l1.go = "Cards_begin";
			link.l2 = "Quelles sont les règles du jeu ?";
			link.l2.go = "Cards_Rule";
		}
	break;

	case "Cards_Rule":
		dialog.text = XI_ConvertString("CardsRules")
		link.l1 = "Eh bien, commençons !";
		link.l1.go = "Cards_begin";
		link.l3 = "Non, ce n'est pas pour moi...";
		link.l3.go = "exit";
	break;

	case "Cards_begin":
		Dialog.text = "Fixons la mise.";
		link.l1 = "On joue 500 pièces la carte.";
		link.l1.go = "Cards_Node_100";
		link.l2 = "Jouons 2000 pièces d'or la carte.";
		link.l2.go = "Cards_Node_500";
		link.l3 = "Je crois que je vais y aller.";
		link.l3.go = "exit";
	break;

	case "Cards_Node_100":
		if (sti(pchar.Money) < 15000)
		{
			dialog.text = "Vous plaisantez ? Vous n'avez pas un sou !";
			link.l1 = "דa arrive.";
			link.l1.go = "exit";
			break;
		}
		if (sti(npchar.Money) < 15000)
		{
			dialog.text = "J'en ai assez, sinon il ne me restera plus d'argent pour l'entretien du navire...";
			link.l1 = "Désolé.";
			link.l1.go = "exit";
			break;
		}
		dialog.text = "D'accord, jouons pour 500 pièces.";
		link.l1 = "Commençons !";
		link.l1.go = "Cards_begin_go";
		pchar.GenQuest.Cards.npcharIdx = npchar.index;
		pchar.GenQuest.Cards.iRate     = 500;
		pchar.GenQuest.Cards.SitType   = false;
	break;

	case "Cards_Node_500":
		if (sti(pchar.Money) < 60000)
		{
			dialog.text = "Vous plaisantez ? Vous n'avez pas de quoi miser autant !";
			link.l1 = "J'en aurai !";
			link.l1.go = "exit";
			break;
		}
		if (sti(npchar.Money) < 60000)
		{
			dialog.text = "Non, de telles mises ne mènent à rien de bon.";
			link.l1 = "Peu importe.";
			link.l1.go = "exit";
			break;
		}
		dialog.text = "D'accord, on joue pour 2000 pièces.";
		link.l1 = "Commençons !";
		link.l1.go = "Cards_begin_go";
		pchar.GenQuest.Cards.npcharIdx = npchar.index;
		pchar.GenQuest.Cards.iRate     = 2000;
		pchar.GenQuest.Cards.SitType   = false;
	break;

	case "Cards_begin_go":
		SaveCurrentQuestDateParam("questTemp.pgggamesplayed"+npchar.index);
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		LaunchCardsGame();
	break;
	// карты <--
	//  Dice -->
	case "Dice_Game":
		if (isBadReputation(pchar, 30) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < 1+rand(2))
		{
			dialog.text = "Fichez le camp, je ne suis pas d'humeur.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "exit";
		}
		else
		{
			dialog.text = "Allez ! Le jeu n'a jamais fait de mal à la santé... seulement à la bourse...";
			link.l1 = "Parfait.";
			link.l1.go = "Dice_begin";
			link.l2 = "Quelles sont les règles du jeu ?";
			link.l2.go = "Dice_Rule";
		}
	break;

	case "Dice_Rule":
		dialog.text = XI_ConvertString("DiceRules");
		link.l1 = "Eh bien, commençons !";
		link.l1.go = "Dice_begin";
		link.l3 = "Non, ce n'est pas pour moi...";
		link.l3.go = "exit";
	break;

	case "Dice_begin":
		Dialog.text = "Fixons la mise.";
		link.l1 = "On joue 200 pièces le coup de dés.";
		link.l1.go = "Dice_Node_100";
		link.l2 = "Jouons 1000 pièces d'or le coup de dés.";
		link.l2.go = "Dice_Node_500";
		link.l3 = "Je crois que je vais y aller.";
		link.l3.go = "exit";
	break;

	case "Dice_Node_100":
		if (!CheckDiceGameSmallRate())
		{
			dialog.text = "Votre réputation n'est plus à faire, tricheur. Je ne jouerai pas aux dés avec vous, un point c'est tout.";
			link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			link.l1.go = "exit";
			break;
		}

		if (sti(pchar.Money) < 15000)
		{
			dialog.text = "Vous plaisantez ? Vous n'avez pas un sou !";
			link.l1 = "דa arrive.";
			link.l1.go = "exit";
			break;
		}
		if (sti(npchar.Money) < 15000)
		{
			dialog.text = "דa suffit ! Il faut arrêter de jouer, sinon on va nous prendre pour des escrocs et nous débarquer...";
			link.l1 = "Désolé.";
			link.l1.go = "exit";
			break;
		}
		dialog.text = "D'accord, jouons pour 200 pièces.";
		link.l1 = "Commençons !";
		link.l1.go = "Dice_begin_go";
		pchar.GenQuest.Dice.npcharIdx = npchar.index;
		pchar.GenQuest.Dice.iRate     = 200;
		pchar.GenQuest.Dice.SitType   = false;
	break;

	case "Dice_Node_500":
		if (!CheckDiceGameSmallRate())
		{
			dialog.text = "Votre réputation n'est plus à faire, tricheur. Je ne jouerai pas aux dés avec vous, un point c'est tout.";
			link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			link.l1.go = "exit";
			break;
		}
		if (!CheckDiceGameBigRate())
		{
			dialog.text = "J'ai entendu dire que vous jouiez très bien. Je ne jouerai pas avec vous à des mises aussi élevées.";
			link.l1 = "Et si on misait moins ?";
			link.l1.go = "Dice_Node_100";
			link.l2 = "Désolé, je dois y aller.";
			link.l2.go = "exit";
			break;
		}

		if (sti(pchar.Money) < 60000)
		{
			dialog.text = "Vous plaisantez ? Vous n'avez pas autant d'argent !";
			link.l1 = "J'en aurai !";
			link.l1.go = "exit";
			break;
		}
		if (sti(npchar.Money) < 60000)
		{
			dialog.text = "Non, de telles mises ne mènent à rien de bon.";
			link.l1 = "Peu importe.";
			link.l1.go = "exit";
			break;
		}
		dialog.text = "D'accord, jouons 1000 pièces le coup.";
		link.l1 = "Commençons !";
		link.l1.go = "Dice_begin_go";
		pchar.GenQuest.Dice.npcharIdx = npchar.index;
		pchar.GenQuest.Dice.iRate     = 1000;
		pchar.GenQuest.Dice.SitType   = false;
	break;

	case "Dice_begin_go":
		SaveCurrentQuestDateParam("questTemp.pgggamesplayed"+npchar.index);
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		LaunchDiceGame();
	break;

// Квест ПГГ Виспер

	case "Whisper_Officer":
		Dialog.Text = "Bonjour, capitaine. J'aimerais vous demander un service.";
		link.l1 = "Hum. De quoi parlez-vous ?";
		link.l1.go = "Quest_Whisper";
		sld.PGGWhisperQuestStart = true;
	break;
	
	case "Quest_Whisper":
		npchar.PGGWhisperQuestStart = true;//предложит только один раз? если отказать, то повтора не будет. 

		Dialog.Text = "C'est une affaire sérieuse, je ne veux pas en discuter devant tout le monde. On continue dans ma chambre ?";
		link.l1 = "Allons-y.";
		link.l1.go = "Quest_Whisper_Room";
		link.l2 = "J'ai beaucoup entendu dire"+GetSexPhrase("","e")+" que vous portiez malheur dans toutes vos affaires, je ferais mieux de me tenir à l'écart.";
		link.l2.go = "exit";
	break;

	case "Quest_Whisper_Room":
		chrDisableReloadToLocation = true;
		DoReloadCharacterToLocation(GetCurrentTown() + "_tavern_upstairs","goto","goto1");
		ChangeCharacterAddressGroup(npchar, GetCurrentTown() + "_tavern_upstairs", "goto", "goto1");
		pchar.InstantDialog = npchar.id;

		npchar.Dialog.Filename = "Quest\WhisperLine\Whisper_PGG.c";
		npchar.dialog.currentnode   = "Quest_Whisper_1";
		DoQuestFunctionDelay("InstantDialog", 1);
		DialogExit();
	break;

	case "Quest_Whisper_1":
		dialog.text = "Bon, le travail n'est pas facile, mais le gros lot qu'on peut décrocher vaut le risque.";
		link.l1 = "Je vous écoute.";
		link.l1.go = "Quest_Whisper_2";
	break;

	case "Quest_Whisper_2":
		dialog.text = "Vous n'avez pas fermé la porte derrière vous ?";
		link.l1 = "...";
		link.l1.go = "Quest_Whisper_2_exit";
		for (int i = 1; i < 4; i++)
		{
			sld = GetCharacter(NPC_GenerateCharacter("PGG_Whisper_Incquisitor"+i, "PGG_Vincento_"+(2+i), "man", "man", MOD_SKILL_ENEMY_RATE*3/2, PIRATE, 1, false));
			ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1_back");
		}
	break;

	case "Quest_Whisper_2_exit":
		DialogExit();
		sld = CharacterFromId("PGG_Whisper_Incquisitor3");
		sld.Dialog.Filename = "Quest\WhisperLine\Whisper_PGG.c";
		sld.dialog.currentnode   = "Quest_Whisper_3";
		pchar.InstantDialog = sld.id;
		DoQuestFunctionDelay("InstantDialog", 0);
	break;
// <-- Квест ПГГ Виспер
	}
}
