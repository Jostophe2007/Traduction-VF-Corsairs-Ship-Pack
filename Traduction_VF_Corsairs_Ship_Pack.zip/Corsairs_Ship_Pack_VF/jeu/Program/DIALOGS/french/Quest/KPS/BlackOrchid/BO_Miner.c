// Gregg: A runaway convict in the cave near Cumana - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Arrière.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Vous n'irez pas plus loin.";
			link.l1 = "Je veux le coffre.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(il rit)... Tout le monde veut le coffre. Depuis huit ans, tout le monde veut le coffre. Personne ne peut l'ouvrir, et tout le monde le veut.";
			link.l1 = "J'ai la clé.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(il cesse de rire)... Montrez-la. ...(il la regarde longuement)... C'est bien elle. L'homme noir l'avait.";
			link.l1 = "Quel homme noir ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Celui qui a apporté le coffre ici et nous l'a laissé à garder. Il a dit : gardez-le, un homme viendra avec une clé. Nous l'avons gardé huit ans, et aucun homme n'est venu.";
			link.l1 = "L'homme est venu.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Oui. ...(il lève sa hache)... Seulement, personne ne nous a dit quoi faire quand il viendrait. Alors nous allons faire à notre façon.";
			link.l1 = "...(dégaine)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyBattleWithMiners");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
