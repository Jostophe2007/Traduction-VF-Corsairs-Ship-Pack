
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag, arAll;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Kamikazi":
			dialog.text = "...";
			link.l1 = "Qu'est-ce que...";
			link.l1.go = "Kamikazi_2";
		break;

		case "Kamikazi_2":
			StopSound(0,0);
			chrDisableReloadToLocation = false;
			LAi_Explosion(NPChar,20);
			LaunchBlood(NPChar,1.0,true);
			LaunchBlast(NPChar);
			LaunchBlastGrenade(NPChar, true);
			ChangeCharacterAddress(npchar, "none", "");

			pchar.quest.AllMayorsQuests_Late.over = "yes"; //снимаем общий таймер
			makearef(arAll, pchar.GenQuest.DestroyGang);
			pchar.GenQuest.DestroyGang = "Execute"; //флаг выполнил успешно
			pchar.Kamikazi = "Meet";
			string sTemp = GetFullName(&characters[GetCharacterIndex(arAll.MayorId)]);
			// судовой журнал
			AddQuestRecord("MayorsQuestsList", "22");
			// слухи
			AddSimpleRumour(LinkRandPhrase("Vous savez, le gouverneur " + sTemp + " a chargé "+ GetSexPhrase("un certain capitaine", "une certaine capitaine") +" " + GetMainCharacterNameDat() + " d'éliminer un célèbre bandit du nom de " + GetFullName(arAll) + ". Et on dirait que "+ GetSexPhrase("ce capitaine a bien rempli", "cette capitaine a bien rempli") +" la mission du gouverneur...",
				""+ GetSexPhrase("Un brave capitaine s'est porté volontaire", "Une brave fille s'est portée volontaire") +" pour retrouver et éliminer un bandit du coin nommé " + GetFullName(arAll) + ". Et il semble que ce soit chose faite !",
				"Ha, enfin notre gouverneur s'est attelé à rétablir l'ordre dans la jungle : il a chargé le capitaine " + GetMainCharacterNameDat() + " de retrouver le bandit le plus célèbre de la jungle et de le tuer. Et vous savez quoi ? Le bandit " + GetFullName(arAll) + " est bel et bien mort !"), sti(characters[GetCharacterIndex(arAll.MayorId)].nation), 5, 1);
			DialogExit();
		break;
	}
}
