
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//Скипаем с отравления три дня. ГГ приходит в себя в комнате таверны. Запись в СЖ: «Неожиданно. Но предсказуемо. Флинт поимел нас всех. Кто бы мог подумать. Хорошо, что жив(ва) остался(лась)! Нужно разобраться в происходящем. Дьявол, как же мутит то!

		//Далее, если договорились поймать Флинта для разведки – Вейна нет на Багамах. Если не договаривались – он в таверне за столом пьянствует.

		//Спускаемся в таверну. Вариант без Вейна. Подходит Макс// ВАЖНО! этот вариант для финала 3 7.04.2023

		case "BS_F1_1":	//Максин
			dialog.text = "Enfin, tu reviens à toi ! Tu as été dans les vapes plus longtemps que tous les autres.";
			link.l1 = "Tout le monde est vivant ? Quoi de neuf ?";
			link.l1.go = "BS_F1_2";
		break;

		case "BS_F1_2": //Максин
			dialog.text = "Tout le monde est vivant, il avait mis de la belladone dans le vin. Inès nous a tous fait boire du charbon de bois et Dieu sait quoi encore. On a vomi partout, mais on a survécu.";
			link.l1 = "Il faudra que je la remercie d'une façon ou d'une autre. Alors, quelles nouvelles ? Flint ? L'or ?"; //для въедливых, можно прописать какой то бонусный диалог с Инес. благодарности ГГ, попытка сунуть денег и посыл в пешее эротическое от Инес. это вполне в её характере 7.04.2023
			link.l1.go = "BS_F1_3";
		break;

		case "BS_F1_3":	//Максин
			dialog.text = "Ni Flint, ni or. Il n'y a qu'un coffre de doublons dans l'entrepכt, environ cinquante mille par tête. Et un mot : « Pardonnez-moi, partagez ceci et oubliez l'Urca et Flint. C'est ce qu'il faut faire. De toute façon, vous ne comprendriez pas. F. »";
			link.l1 = "Maudit hypocrite ! Et moi qui croyais presque à son « amitié ». Oם sont les autres ?";
			link.l1.go = "BS_F1_4";// получаем 50000 7.04.2023
			AddMoneyToCharacter(PChar, 50000);
		break;

		case "BS_F1_4":	//Максин
			dialog.text = "Eleanor est chez elle, avec Rackham et Bonny ; tous les trois sont furieux comme des diables. Ils n'arrêtent pas de casser des choses et de se hurler dessus. Vane, dès qu'il a tenu debout, a hissé les voiles et il est parti on ne sait oם.";
			link.l1 = "Je pense qu'il vaut mieux ne pas mettre les pieds à la résidence pour l'instant. Je vais prendre l'air.";
			link.l1.go = "exit";
		break;

		//Запись в СЖ: «Трудно думать, когда тебя постоянно тошнит. Но нужно что-то делать. Попробую подключить разведку. Какой там пароль? На Антигуа! В путь».

		//Вариант с Вейном финал номер один если убил Бонса 7.04.2023

		//Подходит Макс

		case "BS_F1_5":	//Максин
			LAi_SetActorType(npchar);
			dialog.text = "Enfin, tu reviens à toi ! Tu as été dans les vapes plus longtemps que tous les autres.";
			link.l1 = "Tout le monde est vivant ? Quoi de neuf ?";
			link.l1.go = "BS_F1_6";
		break;

		case "BS_F1_6": //Максин
			dialog.text = "Tout le monde est vivant, il avait mis de la belladone dans le vin. Inès nous a tous fait boire du charbon de bois et Dieu sait quoi encore. On a vomi partout, mais on a survécu.";
			link.l1 = "Il faudra que je la remercie d'une façon ou d'une autre. Alors, quelles nouvelles ? Flint ? L'or ?"; //для въедливых, можно прописать какой то бонусный диалог с Инес. благодарности ГГ, попытка сунуть денег и посыл в пешее эротическое от Инес. это вполне в её характере 7.04.2023
			link.l1.go = "BS_F1_7";
		break;

		case "BS_F1_7":	//Максин
			dialog.text = "Ni Flint, ni or. Il n'y a qu'un coffre de doublons dans l'entrepכt, environ cinquante mille par tête. Et un mot : \n« Pardonnez-moi, partagez ceci et oubliez l'Urca et Flint. C'est ce qu'il faut faire. De toute façon, vous ne comprendriez pas. F. »";
			link.l1 = "Maudit hypocrite ! Et moi qui croyais presque à son « amitié ». Oם sont les autres ?";
			link.l1.go = "BS_F1_8";
			AddMoneyToCharacter(PChar, 50000);
		break;

		case "BS_F1_8":	//Максин
			dialog.text = "א la résidence, Charles et Eleanor cherchent à savoir qui a les plus grosses couilles. Ils n'arrêtent pas de hurler et de casser des choses, puis ils se calment. Soit ils vont s'entretuer, soit ils vont coucher ensemble. Ou les deux.";
			link.l1 = "Ils n'étaient pas mariés, avant ? Mm-hmm. Pas la peine de répondre. Des pistes ?";
			link.l1.go = "BS_F1_9";
		break;

		case "BS_F1_9":	//Максин
			dialog.text = "Il faut que je retourne à Port Royal, les filles ont peut-être entendu quelque chose.";
			link.l1 = "Eh bien, dans ce cas, bienvenue à bord ! Laissons les tourtereaux régler leurs comptes. J'espère qu'ils vont coucher ensemble plutכt que s'entretuer.";
			link.l1.go = "BS_F1_9exit";
		break;

		case "BS_F1_9exit":	//Максин
			DialogExit();
			PChar.quest.BSHangover_PortRoyal.win_condition.l1 = "location";
			PChar.quest.BSHangover_PortRoyal.win_condition.l1.location = "PortRoyal_town";
			PChar.quest.BSHangover_PortRoyal.function = "BSHangover_PortRoyal";
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			AddQuestRecord("BSHangover", "2");
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_7_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;
		
		case "BS_F1_8_MaksRoyal":	//Максин
			chrDisableReloadToLocation = false;
			dialog.text = "Merci. Il me faudra un peu de temps pour recueillir des informations. Tu peux te reposer quelques jours à la taverne.";
			link.l1 = "Bon, je vais aller voir Vane et Guthrie. Je pense qu'ils se sont calmés.";
			link.l1.go = "BS_F1_8_MaksRoyal_exit";
		break;

		case "BS_F1_8_MaksRoyal_exit":
			DialogExit();
			BS_ReplaceHostessWithMaks();
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload9_back", "none", "", "", "", -1);
			AddQuestRecord("BSHangover", "3");
			sld = CharacterFromID("BS_Silver");
			sld.location = "none";
			sld = CharacterFromID("BS_Rakham");
			sld.location = "none";
			sld = CharacterFromID("BS_Vein");
			sld.location = "none";
			sld = CharacterFromID("BS_Bony");
			sld.location = "none";
			sld = CharacterFromID("Flint");
			sld.location = "none";

			sld = CharacterFromID("gatri_temp");
			ChangeCharacterAddressGroup(sld, "Nassau_OfisGatri", "quest", "quest5");
			CharacterTurnToLoc(sld, "reload", "reload1_back");
			LAi_SetStayType(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_10";
			BS_GatriHomeGuardsOn();
			LocatorReloadEnterDisable("Nassau_town", "houseS1", false);
		break;

		//Запись в СЖ: «Флинт не мог испариться бесследно и в Европу, ему путь заказан. Попробуем узнать что-то с помощью пташек Макс. В Порт Рояль!»

		//Далее вариант поисков Флинта, без договора с Бонсом

		//Отвозим Макс в Порт Рояль. Она покидает корабль. Заменяем мадам на Макс.

		//Запись в СЖ: «Максин пока займётся сбором слухов, а я проведаю Вейна и мисс Гатри»

		//Пиздуем на Багамы. В резиденции Гатри. Вейна пока нигде нет, после диалога, ставим его в комнату таверны.

		case "BS_F1_10": //Гатри
			dialog.text = "";
			link.l1 = "La tempête s'est apaisée ? Quand j'ai quitté ce port, les murs tremblaient et les rats se noyaient par centaines !";
			link.l1.go = "BS_F1_11";
		break;

		case "BS_F1_11": //Гатри
			dialog.text = "Ce crétin répugnant, narcissique et mal élevé ! Comment ose-t-il ! Je ne veux plus jamais le revoir ! Ne me parle plus de lui ! Ou mieux, va le rejoindre ! Qu'il aille au diable !";
			link.l1 = "";
			LAi_SetActorTypeNoGroup(npchar);
			link.l1.go = "BS_F1_11_exit";
			sld = CharacterFromID("Nassau_tavernkeeper");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_12";
		break;
		
		case "BS_F1_11_exit": //Гатри
			DialogExit();
			LocatorReloadEnterDisable("Nassau_town", "houseS1", true);
			DoReloadCharacterToLocation("Nassau_Town", "reload", "houseS1");
		break;

		//Выкидывает нас на порог. Дверь закрыта.

		//Идём в таверну. Ставим Вейна в комнату.

		//Подходим к Инес.

		case "BS_F1_12": //И
			dialog.text = "";
			link.l1 = "Vane est en haut ?";
			link.l1.go = "BS_F1_13";
		break;

		case "BS_F1_13": //И
			dialog.text = "Depuis trois jours. Il a vidé un tonneau de rhum et il en redemande.";
			link.l1 = "Attends un peu pour le rhum, il faut qu'on parle.";
			link.l1.go = "BS_F1_13exit";
		break;

		case "BS_F1_13exit": //И
			DialogExit();
			RestoreOldDialog(npchar);
			DoReloadCharacterToLocation("Nassau_tavern_upstairs", "goto", "goto1");
			pchar.quest.BSHangover_Vein.win_condition.l1          = "location";
			pchar.quest.BSHangover_Vein.win_condition.l1.location = "Nassau_tavern_upstairs";
			pchar.quest.BSHangover_Vein.function             = "BSHangover_Vein";
		break;

		//Идём наверх

		case "BS_F1_14": //Вейн
			dialog.text = "Dehors !";
			link.l1 = "Quelle puanteur ! Tu te soמles ici ? Reprends tes esprits. Nous avons peut-être une piste pour Flint ! Tu es avec moi ?";
			link.l1.go = "BS_F1_15";
		break;

		case "BS_F1_15": //Вейн
			dialog.text = "Une piste ? Bon sang, oui, je suis avec toi ! Et au diable cette pimbêche prétentieuse !";
			link.l1 = "Très bien. Je ne chercherai pas à savoir pourquoi vous vous êtes disputés. Rejoins l'escadre, cap sur Port Royal !";
			link.l1.go = "BS_F1_15exit";
			SetCompanionIndex(PChar, -1, GetCharacterIndex(npchar.id));
			BSRepairShip(npchar);
			SetCrewQuantityFull(npchar);
			npchar.ship.Crew.Morale = 60+rand(40);
			ChangeCrewExp(npchar, "Sailors", 60+rand(40));
			ChangeCrewExp(npchar, "Cannoners", 60+rand(40));
			ChangeCrewExp(npchar, "Soldiers", 60+rand(40));
			AddQuestRecord("BSHangover", "4");
			npchar.location = "none";
			pchar.quest.BSHangover_RoyalVein.win_condition.l1          = "location";
			pchar.quest.BSHangover_RoyalVein.win_condition.l1.location = "PortRoyal_SecBrRoom";
			pchar.quest.BSHangover_RoyalVein.function             = "BSHangover_RoyalVein";	
		break;

		case "BS_F1_15exit": //Вейн
			DialogExit();
			DoReloadCharacterToLocation("Nassau_town", "reload", "reload4_back");
			npchar.dialog.currentnode = "BS_F1_15Vein";
		break;

		case "BS_F1_15Vein": //Вейн
			dialog.text = "Flint va payer !";
			link.l1 = "Il ne nous échappera pas.";
			link.l1.go = "BS_F1_15Veinloopexit";
		break;
		
		case "BS_F1_15Veinloopexit": //Вейн
			DialogExit();
			npchar.dialog.currentnode = "BS_F1_15Vein"
		break;
		//Запись в СЖ: «Гатри и Вейн поссорились. Ничего нового. Главное мы снова в деле. Пора проведать Макс»

		//Без приключений плывём в Порт Рояль. Идём в кабинет Макс. Вейн прицепом.

		case "BS_F1_16": //Максин
			dialog.text = "";
			link.l1 = "Quelles nouvelles, madame ?";
			link.l1.go = "BS_F1_17";
		break;

		case "BS_F1_17": //Максин
			dialog.text = "Bonjour à vous aussi. J'ai des nouvelles inattendues. Une nouvelle fille nous est arrivée de Bridgetown, et elle m'a raconté qu'il y a chez eux un pirate qui dépense l'or à pleines poignées et raconte, ivre mort, à chaque fille comment son meilleur ami et capitaine l'a laissé tomber. Alors qu'il l'aimait comme son propre père. Et ainsi de suite, dans la même veine. Et ce marin s'appelle John Stinger.";
			link.l1 = "";
			link.l1.go = "BS_F1_17exit";
		break;

		case "BS_F1_17exit": //Максин
			RestoreOldDialog(npchar);
			StartInstantDialogNoType("BS_Vein", "BS_F1_18", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_18": //Вейн
			chrDisableReloadToLocation = false;
			npchar.location = "none";
			AddQuestRecord("BSHangover", "5");
			dialog.text = "Silver ?! Il s'est vanté un jour qu'on le surnommait « le Dard des catins » !";
			link.l1 = "Il faut se dépêcher. Je ne crois pas que Flint l'ait simplement débarqué !";
			link.l1.go = "BS_F1_18exit";

			pchar.quest.BSHangover_VeinFollows.win_condition.l1          = "location";
			pchar.quest.BSHangover_VeinFollows.win_condition.l1.location = "Bridgetown_town";
			pchar.quest.BSHangover_VeinFollows.function             = "BSHangover_VeinFollows"

			pchar.BSSearchStinger = 0;

			sld = CharacterFromID("Bridgetown_tavernkeeper");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_shipyarder");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_trader");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_hostess");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_usurer");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_priest");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";

			sld = CharacterFromID("Bridgetown_portman");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_SearchStinger";
		break;
		
		case "BS_F1_18exit": //Вейн
			DialogExit();
			DoReloadCharacterToLocation("PortRoyal_town", "reload", "reload9_back");
			npchar.dialog.currentnode = "BS_F1_15Vein";
		break;
		
		case "BS_F1_SearchStinger":
			dialog.text = "";
			link.l1 = "Bonjour. Je cherche quelqu'un. Euh, tu n'aurais pas vu un certain John Stinger ? Ou peut-être John Silver ? Il porte une jambe de bois. Je peux payer cher pour une information.";
			if(npchar.id == "BridgetownJailOff")
			{
				link.l1 = "Bonjour. Pardonnez ma question indiscrète, mais n'auriez-vous pas, par hasard, parmi vos « habitués », un homme du nom de John Stinger ? Ou peut-être John Silver ? Il porte aussi une jambe de bois.";
			}
			link.l1.go = "BS_F1_SearchStinger_1";
		break;

		case "BS_F1_SearchStinger_1":
			dialog.text = "Je regrette, mais c'est la première fois que j'entends ce nom. Je ne peux pas vous aider.";
			link.l1 = "Dommage.";
			link.l1.go = "BS_F1_SearchStinger_2";
		break;

		case "BS_F1_SearchStinger_2":
			pchar.BSSearchStinger = sti(pchar.BSSearchStinger)+1;
			Log_TestInfo(pchar.BSSearchStinger);
			RestoreOldDialog(npchar);
			DialogExit();
			if(npchar.id == "BridgetownJailOff")
			{
				chrDisableReloadToLocation = false;
				InterfaceStates.DisFastTravel = true;

				pchar.quest.BSHangover_StingerFound.win_condition.l1          = "location";
				pchar.quest.BSHangover_StingerFound.win_condition.l1.location = "Bridgetown_fort";
				pchar.quest.BSHangover_StingerFound.function             = "BSHangover_StingerFound";
			}
			else
			{
				BSHangover_SearchStingerCheck();
			}

		break;

		//Запись в СЖ: «Есть зацепка, в борделе на Барбадосе, сорит деньгами и жалуется на жизнь Джон Сильвер. Нужно успеть туда раньше Флинта и подготовить засаду!»

		//Плывём на Барбадос. В борделе никто ничего про Сильвера-Стингера не знает. Тыкаемся во все двери. После того, как оббежали всех (бармен, ПУ, верфь, церковь, магазин, банк) дзынь! Запись в СЖ: «Никто не видел или не хочет говорить о Сильвере или Стингере, или ком-то похожем на него. Остаётся проверить тюрьму!»

		//Идём в тюрячку. Комендант, тоже шлёт нахой. В расстроенных чувствах уходим. На переходе Форт-Гор Ворота, в локации ворот, подходит сам Сильвер.

		case "BS_F1_19": //Сильвер
			dialog.text = "Ravi de vous voir, compagnons ! Vous réfléchissez plus vite que les hommes de Flint !";
			link.l1 = "Tu t'es servi des filles de joie exprès pour que la rumeur du pauvre Stinger ivre arrive jusqu'à Maxine ? Un coup risqué. Flint aurait pu la trouver le premier !";
			link.l1.go = "BS_F1_19exit";
		break;

		case "BS_F1_19exit":
			StartInstantDialog("BS_Vein", "BS_F1_20", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_20": //Вейн
			dialog.text = "Sacrebleu ! Maxine ! Si Flint a pensé à la même chose que toi, elle est en danger !";
			link.l1 = "";
			link.l1.go = "BS_F1_20exit";
		break;

		case "BS_F1_20exit":
			StartInstantDialogNoType("BS_Silver", "BS_F1_21", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_21": //Сильвер
			dialog.text = "Oh, notre Max sait se défendre. Ce n'est plus la pauvre petite esclave de Louisiane qu'on a vendue à un bordel quand elle était enfant.";
			link.l1 = "Et pourtant, je sens qu'elle a des ennuis. Il faut se dépêcher d'aller à Port Royal.";
			link.l1.go = "BS_F1_22";
		break;

		case "BS_F1_22": //Сильвер
			dialog.text = "Ou attendre encore un peu. Que lui ferait Flint ? Il lui tendrait une embuscade, et c'est moi l'appât. Le pauvre Silver ivre.";
			link.l1 = "";
			link.l1.go = "BS_F1_22exit";
		break;

		case "BS_F1_22exit":
			StartInstantDialogNoType("BS_Vein", "BS_F1_23", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_23": //Вейн
			dialog.text = "Arrête de montrer les dents. Comment as-tu atterri ici, au fait ? Vous vous êtes brouillés ?";
			link.l1 = "";
			link.l1.go = "BS_F1_23exit";
		break;

		case "BS_F1_23exit":
			StartInstantDialogNoType("BS_Silver", "BS_F1_24", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_24": //Сильвер
			dialog.text = "Presque. Flint est arrivé sur le Walrus et a donné l'ordre d'appareiller sur-le-champ. « Je te parlerai plus tard, John, je pense que tu comprendras », m'a-t-il dit, avec ce regard à la Flint. Tu vois le genre. Et c'est là que j'ai compris. Je regarde sur le pont : que des visages inconnus. Quand s'est-il trouvé un nouvel équipage ? Il y a anguille sous roche, je me suis dit.";
			link.l1 = "Et ensuite ? Sans enjoliver, s'il te plaît !";
			link.l1.go = "BS_F1_25";
		break;

		case "BS_F1_25": //Сильвер
			dialog.text = "Quand nous étions à dix milles des Bahamas, les marins ont sorti des pistolets tout neufs et ont abattu tous les anciens avec qui nous avions pris l'or de l'Urca ! Le pont était couvert de sang, et ils achevaient les survivants au hachoir. Alors j'ai couru à la cabine, j'ai attrapé la ceinture pleine d'or, un tonneau de rhum vide, et j'ai sauté par-dessus bord. Le courant m'a porté jusqu'à Tortuga, oם j'ai payé des pêcheurs pour qu'ils m'emmènent plus loin. Et finalement, je me suis installé ici.";
			link.l1 = "Intéressant : Flint avait donc tout prévu à l'avance et n'avait l'intention de partager avec personne.";
			link.l1.go = "BS_F1_25exit";
		break;

		case "BS_F1_25exit":
			StartInstantDialogNoType("BS_Vein", "BS_F1_27", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_26": //Вейн
			dialog.text = "Je vais lui faire avaler cet or jusqu'à ce qu'il lui ressorte par le derrière !";
			link.l1 = "";
			link.l1.go = "BS_F1_27";
		break;

		case "BS_F1_27": //Вейн
			dialog.text = "Je vais lui faire avaler cet or jusqu'à ce qu'il lui ressorte par le derrière !";
			link.l1 = "";
			link.l1.go = "BS_F1_27exit";
		break;

		case "BS_F1_27exit":
			StartInstantDialogNoType("BS_Silver", "BS_F1_28", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_28": //Сильвер
			dialog.text = "Bon. Moi, je retourne au bordel jouer l'ivrogne désespéré, et vous, vous vous cachez ici et vous amenez les navires au cap Ragged Point. Et, euh... Hum... Vous ne pourriez pas me filer un peu d'argent pour le bordel ? J'ai pas mal dépensé, ici.";
			link.l1 = "Tiens. C'est ce qui reste des cinquante mille que Flint nous a laissés.";	//- 12000
			link.l1.go = "BS_F1_28exit";
		break;

		case "BS_F1_28exit":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			npchar.location = "none";
			AddMoneyToCharacter(PChar, -12000 - rand(500));
			StartInstantDialogNoType("BS_Vein", "BS_F1_27_1", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_27_1": //Вейн
			dialog.text = "Alors c'est réglé. Je m'occupe des navires pendant que tu prends une chambre à la taverne ; nous allons sans doute rester ici un moment.";
			link.l1 = "Euh, d'accord.";
			link.l1.go = "BS_F1_27_2";
		break;

		case "BS_F1_27_2": //Вейн
			DialogExit();
			UnLockWeapons("");
			InterfaceStates.DisFastTravel = false;
			chrDisableReloadToLocation = false;
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			npchar.location = "none";
			pchar.location.from_sea = "Shore5";

			sld = CharacterFromID("Bridgetown_tavernkeeper");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_RentRoom";
		break;

		case "BS_F1_RentRoom":
			dialog.text = "";
			link.l1 = "Bonjour. Je voudrais louer une chambre pour une semaine.";
			link.l1.go = "BS_F1_RentRoom_1";
		break;

		case "BS_F1_RentRoom_1":
			dialog.text = "Ce sera cent pièces.";
			if (sti(pchar.money) >= 100)
			{
				link.l1 = "Voilà.";
				link.l1.go = "BS_F1_RentRoom_2";
			}
			link.l2 = "Hum... Je reviendrai.";
			link.l2.go = "BS_F1_RentRoom_exit";
		break;

		case "BS_F1_RentRoom_2":
			dialog.text = "La chambre est à vous. Voici la clé.";
			AddMoneyToCharacter(PChar, -100);
			link.l1 = "Merci.";
			link.l1.go = "BS_F1_RentRoom_3";
		break;

		case "BS_F1_RentRoom_3":
			DialogExit();
			RestoreOldDialog(npchar);
			BSHangover_FewDaysLater();
		break;

		case "BS_F1_RentRoom_exit":
			DialogExit();
			npchar.dialog.currentnode = "BS_F1_RentRoom";
		break;

		//Ставим корабли в бухту. Ножками топаем в город и просто чилим три дня или скипаем. Через три дня, на улице, подходит шлюха

		case "BS_F1_29": //Шлюха
			dialog.text = "Le beau Johnny m'a dit de vous prévenir. Le Walrus est en rade. Il va attirer le chasseur dans la grotte, ici, sur l'île.";
			link.l1 = "Merci, ma jolie.";
			link.l1.go = "BS_F1_30";
		break;

		case "BS_F1_30": //Шлюха
			dialog.text = "Et les sous ?";
			link.l1 = "Ah, oui. Tiens, voilà quelques pièces pour toi."; //- 100
			link.l1.go = "BS_F1_30exit";
		break;

		case "BS_F1_30exit":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 10);
			StartInstantDialog("BS_Vein", "BS_F1_31", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_31": //Вейн
			AddMoneyToCharacter(PChar, -100);
			dialog.text = "C'est trop simple. דa ne me plaît pas !";
			AddQuestRecord("BSHangover", "7");
			link.l1 = "א moi non plus. Séparons-nous. Prends tes hommes et postez-vous autour de l'entrée de la grotte. Moi, j'entre. Si tu entends du grabuge, reste sur tes gardes, n'entre pas, reste en embuscade. Voyons comment ça tourne.";
			link.l1.go = "BS_F1_31_1";

		break;
		case "BS_F1_31_1": //Вейн
			npchar.dialog.currentnode = "BS_F1_15Vein";
			DialogExit();
			npchar.location = "none";
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_8_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;

		//Вейн уходит. Запись в СЖ: «Ну что же, посмотрим, какая рыба заглотила наживку!»

		//Идём в пещеру. Войдя – запускается аларм и в логе таймер 60 сек. «Джон в беде, нужно поспешить на выручку!» – это тоже в логе. Бежим в место шахтных выработок. Там, сразу гасим таймер, Сильвер – становится смертным. В пещёре 10-12 ОЗГов, начинается замес. Сильвер погиб – провал квеста, принудительный – экран смерти. Сильвер выжил – продолжаем.

		case "BS_F1_32": //Сильвер
			dialog.text = "";
			link.l1 = "Pas de Flint ! Bon sang !";
			link.l1.go = "BS_F1_33";
		break;

		case "BS_F1_32_beaten": //Сильвер
			dialog.text = "Oh, je crois qu'on m'a transpercé de part en part...";
			link.l1 = "Je ne vois rien de grave, tu vivras.";
			link.l1.go = "BS_F1_32_beaten_1";
		break;

		case "BS_F1_32_beaten_1": //Сильвер
			dialog.text = "Vraiment ? Je me sens bien plus mal que ça.";
			link.l1 = "Pas de Flint ! Bon sang !";
			link.l1.go = "BS_F1_33";
		break;

		case "BS_F1_33": //Сильвер
			dialog.text = "Bon, tu as remarqué ? Ce sont les visages dont je parlais. Ils ne sont certainement pas d'ici. Je connais la plupart des hommes de main du coin. Oם est Vane ?";
			link.l1 = "Dehors, en embuscade. Ne perdons pas de temps : filons dans la baie et essayons d'aborder le Walrus !";
			link.l1.go = "BS_F1_33_2";
		break;

		case "BS_F1_33_2":
			chrDisableReloadToLocation = false;
			npchar.dialog.currentnode = "BS_F1_33_1";
			DialogExit();
		break;
		case "BS_F1_33_1":
			dialog.text = "Je vais rester assis ici un moment, et puis je vous suivrai.";
			link.l1 = "Allons, ne fais pas l'idiot, simulateur.";
			link.l1.go = "BS_F1_33_2";
		break;

		//Бяжим к выходу. Снаружи идёт замес. Опять озги (модельки), Вейн, Бонни, Рекхэм и пара – тройка их матросов против десятка наёмников. Опять та же история, если кто то из ключевых героев гибнет – сразу экран смерти. Завалили геев. Говорим с Вейном.

		case "BS_F1_34": //Вейн
			dialog.text = "Ceux-là (il pousse un cadavre du pied) sont sortis des fourrés dès que tu as mis les pieds dans la grotte, j'ai dמ intervenir.";
			link.l1 = "דa chauffait à l'intérieur aussi ! Flint n'est pas parmi les cadavres ! Il faut rejoindre les navires et essayer de prendre le Walrus. Suivez-moi !";
			link.l1.go = "BS_F1_34exit";
			BSHangover_IsEveryoneOkay();
		break;
		case "BS_F1_34exit": //Вейн
			DialogExit();
			SetCompanionIndex(PChar, -1, GetCharacterIndex(npchar.id));
			LocatorReloadEnterDisable("Shore5", "boat", false);
			chrDisableReloadToLocation = false;

			for (int i = 1; i <= 4; i++)
			{
				if(i == 1)	sld = CharacterFromID("BS_Vein");
				if(i == 2)	sld = CharacterFromID("BS_Silver");
				if(i == 3)	sld = CharacterFromID("BS_Rakham");
				if(i == 4)	sld = CharacterFromID("BS_Bony");
				Lai_SetActorTypeNoGroup(sld);
				LAi_ActorFollow(sld, pchar, "", -1);
				sld.location = "none";
			}
		break;

		//Запись в СЖ: «На наживку клюнула целая стая рыбин! Но главного лосося, среди них не было. «Морж» всё ещё на рейде, нужно взять его на абордаж и быстро, пока сторожевики не решили посмотреть, кто там палит из пушек».

		//Скачем в Риггед Поинт, садимся на корабли берём Моржа на абордаж. В каюте рубимся с Флинтом. Суровый по статам мужик с какой нибудь уникальной саблей. Банки, жратва – всё по полной. Порубили. Заводит диалог// там драка в каюте подвязана на участие Виспер в ней. если её нет в команде, то спавн подсосов Флинта явно лишний. он и так крут. оставить спавн, если ГГ с Виспер или шарик, ему вроде ржавая помогает в каютных замесах 7.04.2023

		case "BS_F1_35": //Флинт
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			for (int z = 1; z <= 6; z++)
			{
				sld = CharacterFromID("FlintOff"+z);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			}
			PChar.quest.BSHangover_Fail1.over = "yes";

			dialog.text = "Ce n'est pas du tout comme ça que ça devait se passer ! Je suis désolé. Mais écoute-moi !";
			link.l1 = "Pas comme ça ?! Nous n'étions pas censés survivre ? J'ai été bête de croire que tu étais mon ami ! Bon sang, nous aurions pu faire de grandes choses ensemble ! Pourquoi as-tu fait ça ?";
			link.l1.go = "BS_F1_36";
		break;

		case "BS_F1_36": //Флинт
			dialog.text = "C'est compliqué, l'ami. Si tu ne t'étais pas lancé à ma poursuite, si je ne m'étais pas fait avoir par la ruse de John... Les choses auraient été différentes. Personne n'en serait sorti blessé. J'avais tout prévu ! Je croyais avoir tout prévu. Cet argent n'est pas pour moi, il doit servir à fonder une nation nouvelle et libre. Une république ! Sans rois ni guerres, un endroit oם les hommes libres pourront vivre selon leur conscience, sans dépendre des caprices des banquiers ou des aristocrates ! C'est le Nouveau Monde, alors qu'il soit le commencement d'un monde nouveau et meilleur ! Tu comprends ?!";
			link.l1 = "De quoi parles-tu ? Quelle république ? Sharp a essayé, Avery a essayé. Et comment ça a fini ? Dans le sang. Le sang de ces mêmes hommes libres pour qui tu veux bâtir un nouveau monde ! Ou ton « monde » est-il différent ? En quoi ?";
			link.l1.go = "BS_F1_37";
		break;

		case "BS_F1_37": //Флинт
			dialog.text = "Ce n'est pas le lieu pour des disputes philosophiques. Finissons-en et parlons comme des gens civilisés.";
			link.l1 = "Certainement pas. Tu vas aller dans la cale, maintenant. Aux fers. Et nous parlerons tous ensemble. Avec les hommes que tu as essayé d'empoisonner ! Et prie tous les dieux que tu connais pour que j'arrive à convaincre Vane de ne pas te faire passer sous la quille.";
			link.l1.go = "BS_F1_38";
		break;

		case "BS_F1_38": //Флинт
			dialog.text = "J'avais oublié que j'avais affaire à un pirate. Très bien, voici mon arme. Je te suis.";
			TakeNItems(PChar, "blade43", 1);
			PlaySound("interface\important_item.wav");
			Log_Info("Vous avez reçu « Narval » !");
			link.l1 = "";
			link.l1.go = "BS_F1_38exit";
		break;

		case "BS_F1_38exit": //Флинт
			for (int k = 1; k <= 6; k++)
			{
				sld = CharacterFromID("FlintOff"+k);
				ChangeCharacterAddressGroup(sld, "none", "", "");
				sld.lifeDay = 0;
			}
			
			DialogExit();

			QuestAboardCabinDialogFree();
			sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
			LAi_group_SetCheck(LAI_GROUP_BRDENEMY, "");
			DeleteAttribute(pchar, "FlintBoardingDialog");
			LAi_KillCharacter(npchar);
			DeleteCharacter(npchar);
			SetLaunchFrameFormParam("Vos hommes emmènent Flint. Pendant ce temps, vous fouillez sa cabine. Un livre attire votre regard : les « Pensées pour moi-même » de Marc Aurèle. Vous le prenez, ainsi que le journal de bord de Flint.", "", 0.1, 15.0);
			LaunchFrameForm();
			AddQuestRecord("BSHangover", "9");
			sld = CharacterFromID("PortRoyal_hostess");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
			sld.dialog.currentnode = "BS_F1_39";

			DeleteAttribute(pchar, "LockMapReload");

			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				sld = CharacterFromID(pchar.WhisperPGG);
				sld.dialog.filename = "Quest\WhisperLine\Whisper_cabin_dialog.c";
				sld.dialog.currentnode = "BS_21_WhisperIsHere";
				LAi_SetActorType(pchar);
				LAi_SetActorTypeNoGroup(sld);
				SetActorDialogAny2Pchar(sld.id, "", 0.0, 0.0);
				LAi_ActorFollow(pchar, sld, "ActorDialog_Any2Pchar", 0.5);
			}
		break;

		//ВАЖНО! Залочить возможность диалога с Флинтом в трюме, во избежание найма. Оставить фразу «Позже поговорим». 7.04.2023

		//Запись в СЖ: «Флинт пойман! Пытался нести какую -  то ахинею про Республику и свободных людей. Путь на Багамы, там расспросим подробнее, про Республику, а главное – про сто пятьдесят миллионов причин ввязаться в эту авантюру! Но сначала нужно проведать Макс в Порт Рояле. Компаньон как – никак». //тоже ВАЖНЫЙ момент, не забирая Максин из ПР можно словить софтлок. заблочить все двери на Багамах пока она не на корабле у нас 7.04.2023

		//Плывём в ПР, забираем Макс из борделя. С ней всё заебись.

		//Диалог в кабинете мадам.

		case "BS_F1_39": //Максин
			dialog.text = "";
			link.l1 = "J'ai des nouvelles ! Flint est aux fers, dans la cale. Tu es avec nous ? Il est temps de voir ce que deviennent nos millions !";
			link.l1.go = "BS_F1_40";
		break;

		case "BS_F1_40": //Максин
			dialog.text = "Bien sמr que j'en suis ! Il y avait des types louches qui traînaient dans le coin hier, manifestement pas d'ici. Je ne veux prendre aucun risque.";
			link.l1 = "Viens, je t'emmène à bord.";
			link.l1.go = "BS_F1_40_1";
			SetFunctionExitFromLocationCondition("BSHangover_MaksOnShip", pchar.location, false);
			SetFunctionLocationCondition("BSHangover_FlintEscaped", "Nassau_town", false);
		break;

		case "BS_F1_40_1":
			npchar.dialog.currentnode = "BS_F1_40_2";
			DialogExit();
		break;

		case "BS_F1_40_2": //Максин
			dialog.text = "Une minute, je prends mes affaires.";
			link.l1 = "D'accord, alors tu nous rattraperas.";
			link.l1.go = "BS_F1_40_1";
		break;

		//Плывём на Багамы. Удаляем Флинта из пленников. Сходим на берег, подбегает матрос.

		case "BS_F1_41": //Матрос
			dialog.text = "Capitaine ! Le prisonnier s'est évadé ! Les fers sont ouverts !";
			link.l1 = "";
			link.l1.go = "BS_F1_41exit";
		break;

		case "BS_F1_41exit":
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			StartInstantDialog("BS_Vein", "BS_F1_42", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_42": //Вейн
			dialog.text = "Bon sang ! Comment ?";
			link.l1 = "Fouillez chaque rocher, chaque palmier ! Qu'est-ce que vous attendez ? COUREZ !";
			link.l1.go = "BS_F1_42exit";
		break;

		case "BS_F1_42exit":
			DialogExit();
			SetLaunchFrameFormParam("Douze heures de recherches ont passé", "", 0.1, 2.0);
			LaunchFrameForm();
			StartInstantDialogNoType("BS_Vein", "BS_F1_43", "Quest\BlackSails\BS_Final_1.c");
		break;

		//Табличка «Прошло 12 часов поисков»

		//Улицы Нассау. Подходит Вейн. 7.04.2023

		case "BS_F1_43": //Вейн
			dialog.text = "";
			link.l1 = "Aucune trace de lui ?";
			link.l1.go = "BS_F1_44";
		break;

		case "BS_F1_44": //Вейн
			dialog.text = "C'est comme si la terre l'avait avalé. Et sur le navire ? Une idée de la façon dont il s'est échappé ?";
			link.l1 = "Soit on l'a mal fouillé, soit quelqu'un l'a aidé.";
			link.l1.go = "BS_F1_45";
		break;

		case "BS_F1_45": //Вейн
			dialog.text = "Silver ? C'est un renard, pas un homme. Je ne lui fais pas confiance !";
			link.l1 = "Peut-être, mais Silver ne va nulle part, et il est trop tכt pour l'accuser. Dans la cabine du Walrus, j'ai trouvé le journal de bord de Flint et un livre de Marc Aurèle.";
			link.l1.go = "BS_F1_46";
		break;

		case "BS_F1_46": //Вейн
			dialog.text = "J'ai vu son journal. Tout est chiffré.";
			link.l1 = "C'est pour ça que nous n'allons soupçonner M. Silver de rien du tout, et que nous serons délicats et polis avec lui.";
			link.l1.go = "BS_F1_47";
		break;

		case "BS_F1_47": //Вейн
			dialog.text = "Qu'est-ce que tu racontes ? Ah... J'ai compris. Le chiffre !";
			link.l1 = "Exactement. Allons rejoindre les autres, à la maison.";
			link.l1.go = "BS_F1_47exit";
		break;
		case "BS_F1_47exit": //Вейн
			AddQuestRecord("BSHangover", "10");
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable("Nassau_town", "houseS1", false);
			BS_GatriHomeGuardsOff();
			DialogExit();
			Lai_SetActorTypeNoGroup(npchar);
			LAi_ActorFollow(npchar, pchar, "", -1);
			RemoveCharacterCompanion(PChar, npchar);
			pchar.quest.BSHangover_TownHall.win_condition.l1          = "location";
			pchar.quest.BSHangover_TownHall.win_condition.l1.location = "Nassau_OfisGatri";
			pchar.quest.BSHangover_TownHall.function             = "BSHangover_TownHall";
		break;

		//Запись в СЖ: «Флинт, как угорь выскользнул из трюма и растворился неизвестно где. Остался только его судовой журнал и старая, зачитанная книга, за авторством римского императора. Стоит уговорить Сильвера, помочь с расшифровкой. И не давить на него. Нутром чую, без его участия, побег Флинта не обошёлся».

		//Идём в дом Гатри. Гатри, Макс, Вейн, ГГ, Бонни, Рекхэм, Сильвер.

		case "BS_F1_48": //ко всем
			dialog.text = "";
			link.l1 = "Alors, voilà oם nous en sommes. Flint s'est échappé du navire, il a ouvert ses fers on ne sait comment, par miracle. Les chaloupes sont là, donc il a nagé jusqu'ici. Il a peut-être emprunté un bateau à un habitant, et il file maintenant vers notre argent. Qu'il aille au diable ! Tכt ou tard, il se fera prendre. La bonne nouvelle, c'est que nous avons son journal de bord, chiffré. Et la clé du chiffre, c'est probablement ce livre.";
			link.l1.go = "BS_F1_49";
		break;

		case "BS_F1_49": //Гатри
			dialog.text = "Et M. Silver excelle à percer n'importe quel chiffre, tout comme les serrures !";
			link.l1 = "";
			link.l1.go = "BS_F1_49_1";
		break;

		case "BS_F1_49_1": //Гатри
			Lai_SetActorTypeNoGroup(npchar);
			StartInstantDialogNoType("BS_Silver", "BS_F1_50", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_50": //Сильвер
			dialog.text = "S'il s'agit des fers de Flint, je vous assure que je n'y suis pour rien ! Je serais heureux de vous aider à déchiffrer le journal. Contre une part du trésor. Même si elle n'est pas égale aux autres. Marché conclu ?";
			link.l1 = "";
			link.l1.go = "BS_F1_50_1";
		break;

		case "BS_F1_50_1":
			StartInstantDialogNoType("BS_Vein", "BS_F1_51", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_51": //Вейн
			dialog.text = "Marché conclu. Sauf que tu feras le déchiffrement sous la surveillance d'Anne et de deux ou trois hommes de main de Mlle Guthrie.";
			link.l1 = "";
			link.l1.go = "BS_F1_51_1";
		break;

		case "BS_F1_51_1":
			StartInstantDialogNoType("BS_Silver", "BS_F1_52", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_52": //Сильвер
			dialog.text = "Eh bien, je suis prêt à commencer. Puis-je voir le journal et le livre ?";
			link.l1 = "Tiens, amuse-toi bien. Je reviens dans quelques heures.";
			PlaySound("interface\important_item.wav");
			Log_Info("Vous avez remis le journal de bord et le livre de Flint");
			link.l1.go = "BS_F1_52exit";
		break;

		case "BS_F1_52exit": //Сильвер
			DialogExit();
			LAi_CharacterDisableDialog(npchar);
			sld = CharacterFromID("BS_Rakham");
			LAi_CharacterDisableDialog(sld);
			sld = CharacterFromID("BS_Vein");
			LAi_CharacterDisableDialog(sld);
			sld = CharacterFromID("BS_Bony");
			LAi_CharacterDisableDialog(sld);
			sld = CharacterFromID("BS_Silver");
			LAi_CharacterDisableDialog(sld);
			LAi_SetPlayerType(PChar);
			ChangeCharacterAddressGroup(PChar, "Nassau_OfisGatri", "goto", "goto5");
			AddQuestRecord("BSHangover", "11");
			DeleteAttribute(PChar, "currentsoundtrack");
			LocatorReloadEnterDisable("Nassau_town", "houseS1", true);
			pchar.quest.BSHangover_Cutscene.win_condition.l1          = "location";
			pchar.quest.BSHangover_Cutscene.win_condition.l1.location = "Nassau_tavern";
			pchar.quest.BSHangover_Cutscene.function             = "BSHangover_Cutscene";
		break;

		//Передаём то и другое.

		//Запись в СЖ: «Сильвер занят расшифровкой. Пойти, что ли выпить? Или искать Флинта? Местные течения, небольшой баркас или тартану, могут унести куда – угодно, хоть в открытый океан. Или чёрт с ним с Флинтом. Всё - таки такой человек, как он, заслуживает шанс. Да, буду считать это форой, из уважения. Пойду выпью!»

		//Идём в таверну, садим ГГ за столик, бухаем. Типо кат сцена (первая бля кат сцена!) Показываем табличку «Прошло три часа размышлений и возлияний».

		//Запись в СЖ: «Пора проведать нашего дешифратора!»

		//Идём в резиденцию. Сильвер за столом, Гатри, Бонни, Вейн.

		case "BS_F1_53": //Сильвер
			dialog.text = "";
			link.l1 = "Des résultats ?";
			link.l1.go = "BS_F1_54";
		break;

		case "BS_F1_54": //Сильвер
			dialog.text = "Oui. Tiens.";
			link.l1 = "21°3N, 80°00W. 15 25 N, 61 20 W. 12°07N61°40W. 72° 25'N 19° 00'W. 19°30N 80°30W. 55,755831°, 37,617673° N55.755831°, E37.617673° 55°45.35'N, 37°37.06'E. 15°N, 30°E. 15 10,234, 30 -23,456. 15,23456, -30,67890. Et ainsi de suite...";
			link.l1.go = "BS_F1_55_1";
		break;

		case "BS_F1_55_1":
			StartInstantDialog("BS_Vein", "BS_F1_55", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_55": //Вейн
			dialog.text = "Des coordonnées ? Qu'est-ce qu'on attend ?";
			link.l1 = "Il y a encore deux pages de coordonnées... Et aucun indice ? Marc Aurèle parle-t-il d'une île ? Il doit bien y avoir quelque chose ?!";
			link.l1.go = "BS_F1_56_1";
		break;

		case "BS_F1_56_1":
			Lai_SetActorTypeNoGroup(npchar);
			StartInstantDialogNoType("BS_Silver", "BS_F1_56", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_56": //Сильвер
			dialog.text = "Il me faut plus de temps. Nous devons étudier le livre, chercher des indices, les comparer avec les coordonnées !";
			link.l1 = "Rendez-vous à l'évidence. Flint nous a roulés, et il file vers des coordonnées que lui seul connaît ! Oם ? N'importe oם ! Il y a des centaines d'îles et de récifs. Bon sang, bon sang, bon sang, bon sang !";
			link.l1.go = "BS_F1_57_1";
		break;

		case "BS_F1_57_1":
			StartInstantDialog("BS_Vein", "BS_F1_57", "Quest\BlackSails\BS_Final_1.c");
		break;

		case "BS_F1_57": //Вейн
			dialog.text = "Tu abandonnes, comme ça ? J'avais une meilleure opinion de toi !";
			link.l1 = "Voici l'argent qui se trouvait dans les quartiers de Flint. J'en mets ma main au feu : c'est une partie de l'or de l'Urca. Un million chacun. Ce n'est pas si mal. Réfléchissez un peu. Chercher tout cet or sans connaître le point de départ prendrait des années, voire des décennies ! Consacrer toute sa vie à la chasse au trésor ? Il y a mieux à faire. Si vous avancez sur les coordonnées, faites-le-moi savoir. Moi, je m'en vais !";
			if(sti(pchar.money) < 5000000)	link.l1 = "Voici l'argent qui se trouvait dans les quartiers de Flint. J'en mets ma main au feu : c'est une partie de l'or de l'Urca. Un million chacun. Oh, pardon, je l'ai déjà dépensé. Prenez ce que j'ai, je vous devrai le reste. Si vous avancez sur les coordonnées, faites-le-moi savoir. Moi, je m'en vais !";
			link.l1.go = "BS_F1_57exit";	//минус 4кк.
		break;

		case "BS_F1_57exit": //Вейн
			bDisableOfficers = false;
			Lai_SetActorTypeNoGroup(npchar);
			LAi_SetPlayerType(PChar);
			sld = CharacterFromID("BS_Silver");
			LAi_CharacterDisableDialog(sld);
			if (sti(pchar.money) >= 4000000)
			{
				pchar.makslover = true;
				SaveCurrentQuestDateParam("MaksLoverDateDay");
			}
			BS_ReplaceHostessWithMaks();
			AddMoneyToCharacter(pchar, -4000000);
			AddQuestRecord("BSHangover", "13");
			pchar.currentsoundtrack = "Theme_from_Black_Sails";
			CloseQuestHeader("BSHangover");
			pchar.questdata.ChernyeParusa = 1;
			DialogExit();
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_14_WhisperIsHere_1", "Quest\WhisperLine\Whisper.c");
			}
			SetFunctionExitFromLocationCondition("BS_NassauCobHouseEnding_1", "Nassau_OfisGatri", false);
		break;

		//Запись в СЖ: «Несколько сотен возможных мест. Годы поисков, десятилетия уйдут на это. Тут всё ещё есть чем занять себя, клады, жирные торгаши, дуэли и осады фортов! Займусь развитием своей колонии или стану грозой Мейна. Но навсегда запомню капитана Джеймса, мать его Флинта и сто пятьдесят миллионов причин его ненавидеть или любить. Авантюра вышла запоминающаяся! Нужно отдать ему должное».

		//ФиналОчка. Макс теперь мадам в ПР со стандартными диалогами. Гатри – губернатор Бермуд. Про Вейна можно пустить слух по алкашам, что он отплыл на Нассау и ввязался в войну с колониальными властями. Сильвер? – гы гы. Читаем Остров Сокровищ.


	}
}
