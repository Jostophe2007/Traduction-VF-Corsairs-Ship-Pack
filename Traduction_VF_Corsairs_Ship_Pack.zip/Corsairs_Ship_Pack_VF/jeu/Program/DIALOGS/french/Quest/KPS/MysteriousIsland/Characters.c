
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	string sName = PChar.name + " " + PChar.lastname;
	
	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Qu'est-ce qu'il te faut encore, visage pâle ? Je n'ai pas envie de te parler en ce moment.";
			link.l1 = "Comme tu voudras.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Tiens, quelle rencontre, capitaine Geoffroy ! Je ne pensais pas que nous nous reverrions.";
			link.l1 = "";
			link.l1.go = "1_1";
			sld = CharacterFromID("Davy Forser");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("Zhofrua Djubben"));
		break;	
		
		case "1_1":
			DialogExit();
			StartInstantDialog("Zhofrua Djubben", "2", "Quest\KPS\MysteriousIsland\Characters.c");
		break;
		
		case "2":
			dialog.text = "Tu m'as trompé, sale brute !";
			link.l1 = "";
			link.l1.go = "2_1";
			sld = CharacterFromID("Zhofrua Djubben");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("Davy Forser"));
		break;
		
		case "2_1":
			DialogExit();
			StartInstantDialog("Davy Forser", "3", "Quest\KPS\MysteriousIsland\Characters.c");
		break;
		
		case "3":
			dialog.text = "Non, c'est ta cupidité et ton avidité qui t'ont fermé les yeux sur la vérité. Bref, je me suis servi de toi, et maintenant, je n'ai plus besoin de toi.";
			link.l1 = "";
			link.l1.go = "3_1";
			sld = CharacterFromID("Davy Forser");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("Zhofrua Djubben"));
		break;
		
		case "3_1":
			dialog.text = "Au fait, qui est-ce, avec toi ? Ton nouveau compagnon ?";
			link.l1 = "Le sang va maintenant effacer ce sourire de ton visage. Défends-toi, salaud de traître !";
			link.l1.go = "exit";
			sld = CharacterFromID("Davy Forser");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
			AddDialogExitQuestFunction("MysteriousIslandFightDavyForser");
			LAi_LocationDisableMonGenTimer("Hispaniola_Cave", 9999);
			LAi_LocationDisableToughSkeletonTimer("Hispaniola_Cave", 9999);
		break;
		
		case "5":
			dialog.text = "On dirait que le capitaine Davy Forser est mort, n'est-ce pas ? J'ai entendu des bruits de combat ?!";
			link.l1 = "Oui, vous ne vous êtes pas trompé : il a rendu son âme à Dieu.";
			link.l1.go = "6";
		break;
		
		case "6":
			dialog.text = "Avez-vous pris l'idole d'or que je lui avais donnée ?";
			link.l1 = "Oui, nous avons l'idole, mais nous ne savons pas à quoi elle sert.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "J'ai aidé Davy à pénétrer sur l'île la première fois : avec deux navires, nous avons réussi à contourner le sortilège. Il devait me rapporter une chose qui se trouvait dans une ancienne ruine souterraine située juste sous le village. Davy Forser a tenu parole et m'a apporté cette chose. En échange, je lui avais promis de lui donner l'idole qui lève le sortilège de cette île. Placez l'idole sur l'autel sacré qui se trouve à l'intérieur de l'épave, et prenez l'or. Autant que vous voudrez. Il n'y aura plus de danger.";
			link.l1 = "Pourquoi êtes-vous si gentil avec nous, Monchitlan ? Nous avons tué votre compagnon !";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Tous les Blancs sont pareils pour moi. Je ne vois pas la différence. Considérez que ce cadeau vous tombe du ciel.";
			link.l1 = "Vous dites des choses étranges. Il ne reste plus qu'à vous croire, adieu !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandRetryToIsland");
		break;

		case "9":
			dialog.text = "Oui, capitaine " + sName + ", vous m'avez beaucoup aidé. Et c'est pourquoi je vais vous remercier avec du bon acier.";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "9_1";
		break;
		
		case "9_1":
			dialog.text = "Tu es si naïf, "+pchar.name+" ! Tu croyais vraiment que j'allais partager l'or avec toi ?";
			link.l1 = "Oh, c'est donc ça que tu veux dire... J'aurais dמ m'en douter. C'est la cupidité qui a perdu le pigeon...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandFightWithDubbenInGrot");
		break;
		
		case "10":
			dialog.text = "Je vous attendais, capitaine !";
			link.l1 = "On dirait que tu t'es trompé quelque part, vieillard ! Regarde ce qui se passe autour de toi !";
			link.l1.go = "11";
			
			DeleteAllOfficersFromLocation();
			bDisableOfficers = true;
		break;
		
		case "11":
			dialog.text = "Il n'y a pas d'erreur, capitaine. Vous et Davy Forser vouliez de l'or : vous l'avez eu, n'est-ce pas ? Les Blancs ont exterminé presque tout notre ancien peuple pour de l'or, alors qu'ils s'y noient eux-mêmes, maintenant. Avant l'arrivée des visages pâles sur notre terre, les gens se servaient de l'or comme il faut : ils mangeaient dans de l'or, buvaient de l'eau dans des coupes d'or et faisaient de beaux bijoux pour leurs femmes ; mais quand les conquistadors sont arrivés, avides et impitoyables, ils se sont mis à tuer les gens pour des bibelots d'or ; alors les anciens indiens ont réuni un grand conseil. Il a été décidé d'enterrer l'or qui restait sur cette île même, et le chaman suprême l'a frappée d'un sortilège. Je suis son descendant direct.";
			link.l1 = "Tu l'as fait exprès, vieux salaud ! Pourquoi crois-tu que la génération actuelle de Blancs devrait payer de sa vie les actes des conquistadors du début du XVIe siècle ? En te servant de moi, tu veux condamner des mères innocentes et leurs enfants, d'honnêtes pères de famille et de nobles vieillards, mais je ne te laisserai pas faire ! C'est insensé de se venger de gens nés bien des années après les événements dont tu parles, et qui ont trouvé ce monde tel qu'il est ! On ne peut pas revenir en arrière dans l'histoire !";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Vos mœurs n'ont pas changé depuis, et vos valeurs non plus. Vous vouliez de l'or, capitaine : prenez-en autant que vous voudrez !";
			link.l1 = "Je "+GetSexPhrase("me suis trompé", "me suis trompée")+", mais Dieu a donné à l'homme le choix entre le bien et le mal, et maintenant, je vais réparer mon erreur ! Je vais te tuer !";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Stupide "+GetSexPhrase("garçon", "fille")+" ! Que peux-tu me faire !?";
			link.l1 = "Tout ce que je pourrai ! Si je meurs, eh bien, soit !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandFightWithMonchitlan");
		break;

		case "14":
			dialog.text = "Vous avez bien fait, capitaine " + GetFullName(pchar)+" ! Maintenant, le sortilège a retrouvé sa puissance !";
			link.l1 = "Comment me connaissez-vous ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Ne posez pas de questions stupides !";
			link.l1 = "Je ne sais pas comment m'adresser à vous...";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Il vaut mieux pour vous ne pas le savoir. Adieu, capitaine ! Je suis sמr que vous ne viendrez plus déranger la cache indienne, mais au cas oם, je vous rappelle de ne pas le faire.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandTheEnd");
			LAi_LocationDisableMonGenTimer("Hispaniola_Cave", -1);
			LAi_LocationDisableToughSkeletonTimer("Hispaniola_Cave", -1);
		break;
		
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
