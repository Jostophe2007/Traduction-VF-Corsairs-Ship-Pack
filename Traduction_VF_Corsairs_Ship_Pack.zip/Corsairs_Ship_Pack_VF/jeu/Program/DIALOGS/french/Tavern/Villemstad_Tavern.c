// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 7 - talk of a pirate frigate
			if (CheckAttribute(PChar, "SmallMongrel"))
			{
				if (PChar.SmallMongrel == "5")
				{
					link.l30 = "Une frégate lourde pirate a-t-elle mouillé dans votre port dernièrement ?";
					link.l30.go = "BO_SM_VT_1";
				}
			}
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";			if (pchar.questTemp.Slavetrader == "EscapeSlave_Villemstad")
            {
                link.l1 = "J'ai entendu dire qu'il y avait eu un sérieux grabuge sur l'île... Les esclaves se seraient révoltés.";
                link.l1.go = "EscapeSlaveVillemstad_T1";
            }
			//виспер
			if(CheckAttribute(pchar, "Whisper.FindDesouzaHol") && !CheckAttribute(npchar, "Whisper.FindDesouzaHol"))
			{
				npchar.Whisper.FindDesouzaHol = true;
				link.l1 = "Dites, des types à l'allure suspecte sont-ils venus vous voir ici ? Ils doivent aussi avoir une marque en forme de crucifix sur le bras.";
				link.l1.go = "FindDesouzaHol";
				break;
			}
			//виспер
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
			{
			case "Intelligence_Curacao_tavern":
				link.l1 = "וcoutez, j'ai besoin de savoir quelque chose...";
				link.l1.go = "Step_E4_1";
				break;
			case "Intelligence_Curacao_dWant_pay_tavern":
				dialog.text = "Vous êtes prêt ?";
				link.l1 = "Oui. Tenez vos mille pièces.";
				link.l1.go = "E4_OK_pay";
				link.l2 = "Mille pièces pour deux mots ?! C'est trop !";
				link.l2.go = "E4_dWant_pay";
				break;
			case "Intelligence_Curacao_NoMoney_tavern":
				dialog.text = "Vous avez mis de l'argent de cכté ?";
				link.l1 = "Oui, on dirait.";
				link.l1.go = "E4_OK_pay";
				break;
			case "Inquisition_toCuracao":
				dialog.text = "Je vous écoute.";
				link.l1 = "Je m'intéresse à ces gens : Joao Ilhaio, Joseph Nunen de Fonquesao et Jacob Lopez de Fonseca. Que pouvez-vous me dire sur eux ?";
				link.l1.go = "Step_S2_1";
				break;
			case "Inquisition_afterFrancisco":
				dialog.text = "Je vous écoute.";
				link.l1 = "Je m'intéresse à ces gens : Joao Ilhaio, Joseph Nunen de Fonquesao et Jacob Lopez de Fonseca. Que pouvez-vous me dire sur eux ?";
				link.l1.go = "Step_S2_1";
				break;
			case "Fr2Letter_SeekProblems":
				dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("cher hכte français", "chère hכte française") +" !";
				link.l1 = "Je veux comprendre pourquoi diable le gouverneur général Stuyvesant a jeté en prison un courrier officiel de la France. Que diable se passe-t-il ici ?";
				link.l1.go = "Step_F2_1";
				break;
			}
			if (pchar.questTemp.LSC == "toVillemstadTavern")
			{
				dialog.text = "Je vous écoute.";
				link.l1 = "וcoutez, j'ai besoin de faire faire une clé pour un coffre, ici.";
				link.l1.go = "MasterKeys";
			}
			if (pchar.questTemp.LSC == "toMasterKeysNoMoney")
			{
				dialog.text = "Je vous écoute attentivement.";
				link.l1 = "וcoutez, j'ai besoin d'un serrurier, vous en auriez vu un ?";
				link.l1.go = "MasterKeysNM";
			}
			if (pchar.questTemp.LSC == "toTalkStuvesant")
			{
				dialog.text = "Je vous écoute attentivement.";
				link.l1 = "Dites, vous connaissiez un vagabond nommé Teaser Dan ? On dit qu'il a vécu un temps dans votre ville.";
				link.l1.go = "TizerFind";
			}
            // <== Проверяем поле состояния квестов.
			//ОЗГ, Хален
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
		    	if (pchar.questTemp.Headhunter == "hunt_halen")
	    		{
	    			link.l1 = "Dites, savez-vous oם trouver Martin van Halen ?";
		    		link.l1.go = "Halen_tavern_1";
		    	}
	    		if (pchar.questTemp.Headhunter == "halen_still")
    			{
    				link.l1 = "Qu'est-ce qui se passe ici ?! On vient d'essayer de me tuer dans ma chambre !";
    				link.l1.go = "Halen_tavern_1_1";
    			}
    			if (pchar.questTemp.Headhunter == "halen_wait")
    			{
    				link.l1 = "Alors, Martin van Halen s'est-il montré ?";
	    			link.l1.go = "Halen_tavern_6_6";
    			}
			}
			//ОЗГ, Хален
 		break;
//*************************** Квест №4 английки, разведка в Кюрасао ***************************
 		case "Step_E4_1":
    		dialog.text = "Je vous aiderai autant que je le pourrai. Demandez.";
    		link.l1 = "J'ai accumulé quelques babioles, de l'or, des pierres... Il faut les écouler, mais discrètement. Bref, il me faut quelqu'un qui ne soit pas trop scrupuleux.";
    		link.l1.go = "Step_E4_2";
 		break;
 		case "Step_E4_2":
    		dialog.text = "Hum, 1000 pièces, et vous connaîtrez son nom.";
    		link.l1 = "Vous ne demandez pas un peu trop pour deux mots ?";
    		link.l1.go = "E4_dWant_pay";
    		link.l2 = "Tenez vos mille pièces.";
    		link.l2.go = "E4_OK_pay";
 		break;
 		case "E4_dWant_pay":
    		dialog.text = "Non, c'est trop peu. Si vous ne voulez pas payer, essayez de vous renseigner ailleurs. Vous reviendrez de toute façon.";
    		link.l1 = "Eh bien, je vais suivre votre conseil. Je vais essayer de me renseigner ailleurs.";
    		link.l1.go = "exit";
    		pchar.questTemp.State = "Intelligence_Curacao_dWant_pay_tavern";
 		break;
 		case "E4_OK_pay":
            if (sti(pchar.money) >= 1000)
            {
        		dialog.text = "Cet homme s'appelle Josef Nunen de Fonquezao. C'est un marchand, il est arrivé ici avec ces jansénistes qui ont formé une communauté assez importante ; Josef en est le principal organisateur et le chef.\n"+
                         "Mais si tous ces jansénistes sont des gens normaux, cet homme n'a aucune conscience : il est aussitכt devenu usurier en ville. Il prête l'argent volontiers, mais si vous ne le remboursez pas à la seconde près, vous êtes en prison le lendemain matin.\n"+
                         "Il a sur la conscience plus d'une mort de faim et plus d'un suicide, mais il se moque de tout.";
        		link.l1 = "Et le gouverneur général ?";
        		link.l1.go = "Step_E4_3";
            }
            else
            {
        		dialog.text = "Hé, "+ GetSexPhrase("frère", "sœur") +", pas d'argent ? Pourquoi me faites-vous tourner en bourrique ? Revenez quand vous en aurez.";
        		link.l1 = "Oui, on ne vous laisse pas entrer au banquet quand vous n'avez pas un sou en poche...";
        		link.l1.go = "exit";
        		pchar.questTemp.State = "Intelligence_Curacao_NoMoney_tavern";
        		//ChangeCharacterReputation(pchar, -1); TO_DO eddy
            }
 		break;
 		case "Step_E4_3":
    		dialog.text = "Notre gouverneur général semble aider Josef à recouvrer ses créances. Josef est le bienvenu chez lui.";
    		link.l1 = "Alors, s'il est ami avec les autorités, c'est dangereux pour moi de m'adresser à lui !";
    		link.l1.go = "Step_E4_4";
 		break;
 		case "Step_E4_4":
    		dialog.text = "Pas dangereux du tout. Il vous achètera votre marchandise, pas au prix du magasin, bien sמr, mais il ne vous la prendra pas non plus. Alors allez-y, vous n'êtes pas le premier que je lui envoie.";
    		link.l1 = "Eh bien, merci.";
    		link.l1.go = "exit";
    		pchar.questTemp.State = "Intelligence_Curacao_toYozef";
    		AddMoneyToCharacter(pchar, -1000);
    		AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "2");
 		break;
//*************************** Квест №2 испанки, задания Инквизиции ***************************
 		case "Step_S2_1":
    		dialog.text =  NPCStringReactionRepeat("Joao Ilhaio est un brave homme, il commerce honnêtement, ses marchandises sont bon marché, il ne prête pas à intérêt. Yakov Lopez de Fonseca est l'associé de Joao Ilhaio, ils tiennent le magasin ensemble. Mais Joseph Nunen de Fonquesao est un usurier, il a sur la conscience plus d'un suicide de gens qu'il a ruinés.",
            "Nous avons déjà parlé de ce sujet...", "Encore ?", "Hum, combien de fois faudra-t-il le répéter, hein ?", "block", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Vous êtes le diable en personne !", "Oui, exactement...", "Non, désolé...", "Désolé...", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_S2_2", "none", "none", "none", npchar, Dialog.CurrentNode);
 		break;
 		case "Step_S2_2":
    		dialog.text = "Peut-être pas le diable lui-même, mais je ferais un assez bon acolyte.";
    		link.l1 = "Merci, l'ami, vous m'avez beaucoup aidé.";
    		link.l1.go = "exit";
 		break;
//*************************** Квест №2 фр.линейки, доставка письма Стэвезанту ***************************
 		case "Step_F2_1":
    		dialog.text =  NPCStringReactionRepeat("Rien d'étonnant. Ce n'est pas une plaisanterie : en un mois, les pirates du galion ont déjà pillé dix-neuf de nos navires et les ont envoyés par le fond. Deux d'entre eux transportaient les marchandises du gouverneur général lui-même. Alors il regarde tous les étrangers comme un loup !",
            "Nous avons déjà parlé de ce sujet...", "Encore ?", "Hum, combien de fois faudra-t-il le répéter, hein ?", "block", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Et moi, "+ GetSexPhrase("je me suis révélé le plus suspect", "je me suis révélée la plus suspecte") +" de tous ?", "Oui, exactement.", "Non, désolé...", "Désolé...", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_F2_2", "none", "none", "none", npchar, Dialog.CurrentNode);
 		break;
 		case "Step_F2_2":
    		dialog.text = "Oui, vous êtes sans doute juste tombé au mauvais moment. Il y a des types plus étranges que vous.\n"+
				          "D'ailleurs, regardez, il y a deux personnes assises à cette table, dans le coin, à votre droite. Qui sont ces gens ? C'est la première fois que je les vois, et il ne semble pas y avoir de raison d'appeler la garde : je tiens à la réputation de mon établissement. Parlez-leur si vous voulez !";
    		link.l1 = "Merci, l'ami, vous m'avez beaucoup aidé.";
    		link.l1.go = "exit";
 		break;
//*************************** ГПК, Мастер Ключей ***************************
		case "MasterKeys":
			dialog.text = "Ah, eh bien, il vous faut aller voir le Maître des clés.";
			link.l1 = "Qu'est-ce que c'est, le Maître des clés ?";
			link.l1.go = "MasterKeys_1";
		break;
		case "MasterKeys_1":
			dialog.text = "C'est ainsi qu'on appelle Hill Corner, parce qu'il fabrique des serrures à clé pour les coffres et les portes.";
			link.l1 = "Hum, c'est un artisan d'ici ?";
			link.l1.go = "MasterKeys_2";
		break;
		case "MasterKeys_2":
			dialog.text = "Oui. Tenez, le voilà, assis à une table ronde près de l'escalier. Il porte une chemise rouge.";
			link.l1 = "Je vois. Merci.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toMasterKeys";
		break;

		case "MasterKeysNM":
			dialog.text = "Oui, le voilà, à sa place habituelle, dans le coin, près de l'entrée de la taverne.";
			link.l1 = "Ah, merci...";
			link.l1.go = "exit";
			if (!LAi_CheckLocatorFree("sit", "sit1"))
			{
				FreeSitLocator("Villemstad_tavern", "sit1");
			}
			ChangeCharacterAddressGroup(&characters[GetCharacterIndex("GiveKeyMan")], "Villemstad_tavern", "sit", "sit1");
		break;
		//ищем Тизера
		case "TizerFind":
			dialog.text = NPCStringReactionRepeat("Comment ne pas le connaître, toute la ville le connaissait ! C'était un sacré fabulateur...",
				"וcoutez, je vous en ai déjà parlé.",
				"Nous en avons déjà parlé.",
                "Désolé, mais je n'ai plus le temps pour un si long récit.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Comment ça ?",
				"Ah oui, je m'en souviens.",
                "Oui, bien sמr.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("TizerFind_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "TizerFind_1":
			dialog.text = "Eh bien, voyez-vous, il gagnait bien sa vie en racontant ses aventures. C'est très à la mode en ce moment, les voyages et la découverte de terres nouvelles : tout le monde n'a que ça à la bouche !";
			link.l1 = "Il vous a parlé de l'île ?";
			link.l1.go = "TizerFind_2";
		break;
		case "TizerFind_2":
			dialog.text = "Et de l'île aussi ! Bref, on ne s'ennuyait pas avec lui. Il commençait par : « Vous êtes déjà allé à Tahiti ? », et les gens s'attroupaient autour de lui. Et il racontait bien ! C'est dommage qu'il nous ait quittés.";
			link.l1 = "Oם ça ?";
			link.l1.go = "TizerFind_3";
		break;
		case "TizerFind_3":
			dialog.text = "Je ne sais pas, il ne l'a dit à personne. Un beau jour, je ne l'ai plus vu dans ma taverne, c'est tout. Je peux vous en dire plus : ses collègues le cherchaient, si l'on peut dire, des vagabonds, quoi. Je ne sais pas s'ils l'ont retrouvé ou non...";
			link.l1 = "Non, ils ne l'ont pas retrouvé.";
			link.l1.go = "TizerFind_4";
		break;
		case "TizerFind_4":
			dialog.text = "C'est dommage, c'était un brave homme, même si c'était un vagabond. Vous savez, il y a des gens qui ont un sens aigu de la justice. Teaser était de ceux-là, et pourtant la vie ne l'a pas épargné. Les histoires sur l'île de la Justice étaient son sujet favori.";
			link.l1 = "Hum, et que racontait-il ?";
			link.l1.go = "TizerFind_5";
		break;
		case "TizerFind_5":
			dialog.text = "Qu'il existe quelque part, pas très loin d'ici, une île faite de navires ! Que les gens y vivent très bien, et que tous y sont égaux. Le paradis sur terre, en somme. Une utopie.";
			link.l1 = "Comment votre gouverneur général traite-t-il les mendiants ?";
			link.l1.go = "TizerFind_6";
		break;
		case "TizerFind_6":
			dialog.text = "Vous savez, très mal. Teaser disait qu'on l'avait vendu comme esclave, et notre Stuyvesant ne considère pas les esclaves comme des êtres humains, ni les anciens esclaves non plus.";
			link.l1 = "Je vois. וcoutez, on dit que Stuyvesant est en affaires avec la Compagnie néerlandaise des Indes occidentales, et...";
			link.l1.go = "TizerFind_7";
		break;
		case "TizerFind_7":
			dialog.text = "Chut !! Doucement, "+ GetSexPhrase("l'ami", "ma petite") +". Il n'est pas d'usage de parler de ces relations de notre Peter. Et je ne vous conseille pas de poser des questions non plus : vous ne vous attireriez que des ennuis !";
			link.l1 = "Qu'y a-t-il ?";
			link.l1.go = "TizerFind_8";
		break;
		case "TizerFind_8":
			dialog.text = "Cette compagnie n'aime pas plaisanter, "+ GetSexPhrase("l'ami", "ma petite") +". Et ne vous fiez pas au fait que ses comptoirs se trouvent surtout en Europe et dans l'océan Indien. Elle est présente ici aussi, mais pas de façon aussi visible...";
			link.l1 = "Diable !.. Et oם peut-on les trouver ?";
			link.l1.go = "TizerFind_9";
		break;
		case "TizerFind_9":
			dialog.text = "Pourquoi avez-vous besoin d'eux ?";
			link.l1 = "Je veux leur proposer mes services pour le transport de marchandises.";
			link.l1.go = "TizerFind_10";
		break;
		case "TizerFind_10":
			dialog.text = "Vous savez, "+ GetSexPhrase("l'ami", "ma petite") +", cette compagnie fait ses affaires sans le concours de gens comme vous. On raconte que Curaçao elle-même lui appartient, et pas seulement cette île !..";
			link.l1 = "Oh, diable ! Une maison sérieuse.";
			link.l1.go = "TizerFind_11";
		break;
		case "TizerFind_11":
			dialog.text = "Oui. Un conseil : n'essayez pas de traiter avec eux, ici ils ne travaillent qu'avec notre Peter.";
			link.l1 = "Je vois... Eh bien, mon ami, merci pour cet exposé si détaillé. C'était très intéressant.";
			link.l1.go = "TizerFind_12";
		break;
		case "TizerFind_12":
			dialog.text = "Je vous en prie. J'aime bien bavarder, moi aussi.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_PoorsMurder", "8");
			AddQuestUserData("ISS_PoorsMurder", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_PoorsMurder", "sSex1", GetSexPhrase("", "e"));
		break;
		//работорговец
		case "EscapeSlaveVillemstad_T1":
			dialog.text = "Oui, on n'avait jamais vu ça... Plus de mille esclaves ont pris part à la révolte. Deux plantations ont été réduites en cendres, et leurs propriétaires massacrés presque jusqu'au dernier. Le commandant a craint qu'ils n'attaquent la ville : il a décrété la loi martiale. Et tout a commencé par l'histoire d'amour de deux esclaves, Tamango et Izaura...";
			link.l1 = "Intéressant ! Racontez-m'en davantage : qui sont-ils ?";
			link.l1.go = "EscapeSlaveVillemstad_T2";
		break;

		case "EscapeSlaveVillemstad_T2":
				dialog.text = "Tamango et Izaura sont des esclaves de la plantation de Blenheim, celle qui a brמlé la première. Ils s'aimaient. Et puis le fils du propriétaire de la plantation, Leoncio, est arrivé d'Europe et a jeté son dévolu sur Izaura. Bref, il a décidé d'en faire sa concubine. דa n'a pas beaucoup plu à Tamango, et Izaura n'était pas enchantée non plus : c'est son Tamango qu'elle aimait. Il faut dire que Tamango était une sorte de chef, ou de roi, dans son Afrique... Fort comme un taureau, maître dans le maniement de la hache, et respecté de tous les esclaves. Il les a donc poussés à la révolte : ils ont attaqué les gardes et massacré tous les Hollandais de Blenheim. Izaura leur a ouvert les portes du domaine : là aussi, ils ont tué tout le monde. Puis ils sont allés en foule à la plantation voisine, Blenburg, et y ont fait le même carnage. Ensuite, ils sont partis dans la jungle et ont disparu sans laisser de traces...";
			link.l1 = "En voilà une histoire ! On dirait l'intrigue d'un roman ! Et comment savez-vous tout ça ?";
			link.l1.go = "EscapeSlaveVillemstad_T3";
		break;

		case "EscapeSlaveVillemstad_T3":
			dialog.text = "Les rumeurs, "+ GetSexPhrase("mynheer", "madame") +", la terre est pleine de rumeurs. Le rhum délie les langues, il suffit d'écouter...";
			link.l1 = "Et comment cela s'est-il terminé ? On a retrouvé ces esclaves ?";
			link.l1.go = "EscapeSlaveVillemstad_T4";
		break;

		case "EscapeSlaveVillemstad_T4":
				dialog.text = "Vous parlez ! Tant que les renforts n'étaient pas arrivés, personne n'a osé mettre un pied dans la jungle. Ensuite, un navire de guerre est venu avec un détachement de soldats, ils ont fouillé l'île : plus personne.";
			link.l1 = "Pensez donc ! Mille personnes, et tout ce monde disparu corps et biens !";
			link.l1.go = "EscapeSlaveVillemstad_T5";
		break;

		case "EscapeSlaveVillemstad_T5":
			dialog.text = "Exactement, "+ GetSexPhrase("mynheer", "madame") +" ! Corps et biens, comme vous dites, et par la mer !";
			link.l1 = "Que voulez-vous dire par là, " + npchar.name + " ? Il y a quelque chose qui m'échappe...";
			link.l1.go = "EscapeSlaveVillemstad_T6";
		break;

		case "EscapeSlaveVillemstad_T6":
			dialog.text = "Héhé... Je parie qu'ils ont quitté l'île en bateau. Le fait est que la nuit qui a suivi le soulèvement, une barque a disparu du mouillage. Que je ne boive plus une goutte de rhum de toute ma vie si ce n'est pas l'œuvre de Tamango et de ses frères ! Voilà pourquoi ils ne sont plus sur l'île.";
			link.l1 = "D'accord, merci pour cette histoire passionnante, " + npchar.name + ". Mais j'ai du mal à imaginer des esclaves africains manœuvrer des voiles.";
			link.l1.go = "EscapeSlaveVillemstad_T7";
		break;

		case "EscapeSlaveVillemstad_T7":
			dialog.text = "Ma foi, ils en sont peut-être capables... L'un d'eux a peut-être été marin. Revenez me voir, " + pchar.name + ", n'oubliez pas, et je vous raconterai d'autres histoires.";
			link.l1 = "Merci ! Bon, je dois y aller.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "22_2");
			pchar.questTemp.Slavetrader = "EscapeSlaveVillemstad_P";
		break;

		//ОЗГ, Хален
		case "Halen_tavern_1":
			dialog.text = "Non, il n'est pas là en ce moment. Il est parti en mer, mais il devrait revenir d'un jour à l'autre. Vous pouvez loger chez moi. Quand il reviendra, je vous préviendrai.";
			link.l1 = "Compris. Il faut que je l'attende. Bon, je vous loue une chambre, alors ?";
			link.l1.go = "Halen_tavern_2";
		break;

		case "Halen_tavern_2":
			dialog.text = "Oui, bien sמr. דa coמte 100 pièces d'or.";
			link.l1 = "D'accord. Ouvrez-moi la chambre.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "halen_room";
			LocatorReloadEnterDisable("Villemstad_tavern", "reload2_back", false);
            AddMoneyToCharacter(pchar, -100);
			Pchar.quest.Headhunter_inRoom.win_condition.l1 = "location";
			Pchar.quest.Headhunter_inRoom.win_condition.l1.location = "Villemstad_tavern_upstairs";
			Pchar.quest.Headhunter_inRoom.function = "RatHunters_inRoom";
			AddQuestRecord("Headhunt", "27");
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
			pchar.quest.Headhunter_HalenOver.over = "yes";
		break;

		case "Halen_tavern_1_1":
			dialog.text = "Que dites-vous ? Je fais appeler le commandant sur-le-champ !";
			link.l1 = "Appelez-le. Et appelez aussi les fossoyeurs : j'ai tué ces deux types.";
			link.l1.go = "Halen_tavern_2_2";
		break;

		case "Halen_tavern_2_2":
			dialog.text = "Sainte Mère de Dieu ! Quelle horreur ! Et dans ma taverne, en plus...";
			link.l1 = "Calmez-vous. Faites plutכt ceci : sortez discrètement les corps par l'arrière-cour, sans faire trop de bruit, pour ne pas nuire à la réputation de votre établissement... Je ne crois pas que ces deux-là soient d'ici, personne n'en saura donc rien. Vous les avez vus entrer ? Deux types en noir, le visage couvert d'un foulard.";
			link.l1.go = "Halen_tavern_4_4";
		break;

		case "Halen_tavern_4_4":
			dialog.text = "Non... Je ne les ai pas vus. Mon Dieu... Quel châtiment !";
			link.l1 = "Allez-vous enfin cesser de gémir ? Vous ne les avez pas vus, dites-vous ? Remarquez, je ne m'attendais pas à une autre réponse... Vous ne seriez pas de mèche avec eux, par hasard ? Parce que sinon, je...";
			link.l1.go = "Halen_tavern_5_5";
		break;

		case "Halen_tavern_5_5":
			dialog.text = "Mais que dites-vous là, "+ GetSexPhrase("noble seigneur", "noble dame") +" ! Je vous le jure sur la croix, jamais je ne chargerais mon âme d'un tel péché...";
			link.l1 = "Bon, bon, je vous crois. Martin ne s'est pas montré, vous n'avez rien entendu ?";
			link.l1.go = "Halen_tavern_6_6";
		break;

		case "Halen_tavern_6_6":
			if (makeint(environment.time) > 18.0 || makeint(environment.time) < 6.0)
			{
				dialog.text = "Non, il ne s'est pas montré. Revenez demain matin, j'aurai peut-être des nouvelles.";
				link.l1 = "D'accord.";
				link.l1.go = "exit";
				pchar.questTemp.Headhunter = "halen_wait";
				break;
			}
			dialog.text = "Vous tombez à pic ! La corvette de Martin van Halen vient de jeter l'ancre dans notre port.";
			link.l1 = "Parfait ! Martin est donc déjà en ville ?";
			link.l1.go = "Halen_tavern_7_7";
		break;

		case "Halen_tavern_7_7":
			dialog.text = "Oui, il est allé voir le gouverneur général dès son arrivée. Si vous vous dépêchez, vous le trouverez à la résidence. Sinon, vous le trouverez sur son navire.";
			link.l1 = "Compris. J'y cours. Merci !";
			link.l1.go = "Halen_tavern_8_8";
		break;

		case "Halen_tavern_8_8":
			AddQuestRecord("Headhunt", "29");
			pchar.questTemp.Headhunter = "halen_town";
			CreateHalen();
			DialogExit();
		break;
		case "FindDesouzaHol":
    		dialog.text = "Non, je ne les ai certainement pas vus ici.";
    		link.l1 = "D'accord, merci.";
    		link.l1.go = "exit";
 		break;




		// Gregg: The Black Orchid, chapter 7 -->
		case "BO_SM_VT_1":
			dialog.text = "Oui ! Le navire de Bill le Sanglant, si ça vous dit quelque chose. Et il s'est passé avec elle une telle affaire qu'on la raconte encore. Vous voulez l'entendre ?";
			link.l1 = "Volontiers. Mais épargnez-moi les fioritures, je connais la mer moi-même.";
			link.l1.go = "BO_SM_VT_2";
		break;

		case "BO_SM_VT_2":
			dialog.text = "Il y a cinq jours, à l'aube, la vigie du fort l'a vue approcher. Le commandant a ordonné de la couler sans poser de questions. Et c'est là, capitaine, que tout a commencé.";
			link.l1 = "Il a ordonné de la couler, et elle n'a pas coulé ?";
			link.l1.go = "BO_SM_VT_3";
		break;

		case "BO_SM_VT_3":
			dialog.text = "Le fort l'a canonnée pendant une demi-heure sans la toucher une seule fois. Elle est entrée dans le port, a mouillé, et pas un seul boulet ne l'a atteinte. Tout est tombé à l'eau.";
			link.l1 = "...(sourit)... Vous avez de piètres canonniers.";
			link.l1.go = "BO_SM_VT_4";
		break;

		case "BO_SM_VT_4":
			dialog.text = "Les canonniers sont bons. Le jour même, ils ont réduit en miettes trois chaloupes d'exercice en moins d'une minute. Elle, ils n'arrivaient pas à la toucher, un point c'est tout.";
			link.l1 = "De bons canonniers, et la frégate intacte. Oם est-elle allée ensuite ?";
			link.l1.go = "BO_SM_VT_5";
		break;

		case "BO_SM_VT_5":
			dialog.text = "Pour la suite, demandez au capitaine du port, elle était amarrée à ses quais. Elle y est restée, puis elle est partie ...(baisse la voix)... toute seule, à ce qu'on dit. Et Bill n'a plus repris la mer depuis. Il reste aux Bermudes à boire.";
			link.l1 = "Partie toute seule, dites-vous. Eh bien, va pour le capitaine du port.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToCuracaoPortMan");
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

