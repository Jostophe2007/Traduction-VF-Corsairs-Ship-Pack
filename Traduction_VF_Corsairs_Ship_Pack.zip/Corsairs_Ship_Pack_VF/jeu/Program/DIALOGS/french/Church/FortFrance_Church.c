// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils", "ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils", "ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_FortFranceChurch_1"))	//Квест "Strange things are happening in the archipelago"
            {
                link.l1 = "Saint père, j'ai entendu dire que vous cherchiez, vous aussi, la mystérieuse frégate noire qui a enlevé les enfants de Saint-Martin.";
                link.l1.go = "PKM_SvtvA_Ch1_1";
            }
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_PismoKlermon"))	//Квест "Strange things are happening in the archipelago"
            {
                link.l1 = "J'ai une lettre pour vous.";
                link.l1.go = "PKM_SvtvA_Ch2_1";
            }
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_Clermon_Final"))	//Квест "Strange things are happening in the archipelago"
            {
				dialog.text = "Avez-vous réussi à apprendre quelque chose sur l'affaire qui vous a été confiée ?";
                link.l1 = "Mieux encore : mes hommes et moi avons détruit la secte.";
                link.l1.go = "PKM_SvtvA_Ch3_1";
            }
		break;
		
		//Квест "Strange things are happening in the archipelago"
		case "PKM_SvtvA_Ch1_1":
			dialog.text = "Des enfants enlevés ?! Hum. Je n'en savais rien. Nous sommes vraiment inquiets, car dans notre ville, on a trouvé dans une maison les traces d'un rituel païen, et les cadavres de nos bons citoyens respectueux des lois gisaient là. א chacun d'eux, on avait sauvagement arraché le cœur...";
			link.l1 = "Quels monstres ont pu faire une chose pareille ?";
			link.l1.go = "PKM_SvtvA_Ch1_2";
		break;
		case "PKM_SvtvA_Ch1_2":
			dialog.text = "Si tout cela vous tient vraiment à cœur, vous pourriez peut-être me rendre un service ? Ce que vous nous apprenez sur les enfants éclaire un peu le tableau.\nJe veux que vous portiez une lettre à Porto Rico et que vous la remettiez en main propre à un homme nommé padre Dominguez. Vous le trouverez à la cathédrale, et il vous donnera d'autres instructions s'il le juge bon.";
			link.l1 = "C'est une mission assez simple. Je pars immédiatement, saint père.";
			link.l1.go = "PKM_SvtvA_Ch1_3";
		break;
		case "PKM_SvtvA_Ch1_3":
			dialog.text = "Prenez votre temps, "+ GetSexPhrase("mon fils", "ma fille") +". L'homme qui devait porter la lettre aujourd'hui a été retrouvé mourant sur le seuil de sa maison. Tout ce qu'il a pu dire avant de mourir, c'est qu'il avait été attaqué par des gens en robe rouge armés de poignards.\nJ'ai des raisons de croire que l'affaire est louche : quelqu'un ne veut manifestement pas que cette lettre arrive à destination.";
			link.l1 = "Ils pourraient donc essayer de m'intercepter en chemin ?";
			link.l1.go = "PKM_SvtvA_Ch1_4";
		break;
		case "PKM_SvtvA_Ch1_4":
			dialog.text = "Oui, je crains que vous n'ayez raison. Si vous refusez de porter la lettre, je le comprendrai.";
			link.l1 = "Je ne vois aucune raison de renoncer à cette affaire.";
			link.l1.go = "PKM_SvtvA_Ch1_5";
		break;
		case "PKM_SvtvA_Ch1_5":
			dialog.text = "Parfait. Voici donc la lettre : vous devez la remettre à un prêtre nommé padre Dominguez, et à lui seul. Vous le trouverez à Porto Rico...";
			link.l1 = "";
			link.l1.go = "PKM_SvtvA_Ch1_5.1";
			GiveItem2Character(PChar, "PKM_SvtvA_pismo1");
		break;
		case "PKM_SvtvA_Ch1_5.1":
			dialog.text = "Je vais aussi vous donner un document qui vous permettra de séjourner légalement à Porto Rico. Je vous en supplie, n'entrez pas au port. Débarquez dans une baie isolée, pour que personne ne vous voie. Cette lettre est de la plus haute importance.";
			link.l1 = "D'accord. Je ne pense pas que cela me prendra très longtemps.";
			link.l1.go = "PKM_SvtvA_Ch1_6";
			GiveUniLicence(8); // universal GWIK trade license
		break;
		case "PKM_SvtvA_Ch1_6":
			DialogExit();
			AddQuestRecord("PKM_Animists", "8");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_FortFranceChurch_1");
			
			PChar.quest.PKM_SvtvA_SJ_B1.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_SJ_B1.win_condition.l1.location = "SanJuan_town";
			PChar.quest.PKM_SvtvA_SJ_B1.win_condition = "PKM_SvtvA_DostavkaPisma_Gorod_1";
			
			PChar.quest.PKM_SvtvA_SJ_B2.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_SJ_B2.win_condition.l1.location = "Shore44";
			PChar.quest.PKM_SvtvA_SJ_B2.win_condition = "PKM_SvtvA_DostavkaPisma_Buhta_1";
			
			PChar.quest.PKM_SvtvA_SJ_B3.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_SJ_B3.win_condition.l1.location = "Shore45";
			PChar.quest.PKM_SvtvA_SJ_B3.win_condition = "PKM_SvtvA_DostavkaPisma_Buhta_1";
		break;
		
		case "PKM_SvtvA_Ch2_1":
			dialog.text = "Ah ! Je me demandais justement si padre Dominguez vous enverrait ou non.";
			link.l1 = "Que voulez-vous dire par là ?";
			link.l1.go = "PKM_SvtvA_Ch2_2";
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_PismoKlermon");
			TakeItemFromCharacter(pchar, "PKM_SvtvA_pismo2");
		break;
		case "PKM_SvtvA_Ch2_2":
			dialog.text = "Ah, vous ne savez sans doute pas encore : la personne qui vous a remis cette lettre a été enlevée. Je crains que ce que je redoutais tant ne soit arrivé.";
			link.l1 = "Et de quoi s'agit-il ?";
			link.l1.go = "PKM_SvtvA_Ch2_3";
			
			sld = characterFromID("SanJuan_Priest");
			sld.name = "Padre";
			sld.lastname = "Robano";
		break;
		case "PKM_SvtvA_Ch2_3":
			dialog.text = "Il y a quelques années, le repaire des serviteurs de Satan a été détruit en Italie. Malheureusement, le chef de l'ordre a réussi à s'enfuir, et il s'est installé dans l'archipel. Maintenant, à en juger par la disparition des enfants et d'un prêtre de haut rang, il s'apprête à accomplir un rituel ancien, et nous devons l'arrêter !";
			link.l1 = "Et quel est mon rכle dans tout cela ?";
			link.l1.go = "PKM_SvtvA_Ch2_4";
		break;
		case "PKM_SvtvA_Ch2_4":
			dialog.text = "J'aimerais que vous soyez l'épée de Dieu. Je comprends que vous êtes quelqu'un d'affaires, alors que diriez-vous de 50 000 piastres en récompense de ce service ?";
			link.l1 = "Eh bien, pas mal, pas mal du tout...";
			link.l1.go = "exit";
			AddDialogExitQuest("PKM_SvtvA_Нападение_в_церкви");
		break;
		case "PKM_SvtvA_Ch3_1":
			AddMoneyToCharacter(pchar, 50000);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			dialog.text = "Oh, Dieu merci ! Vous avez réussi ! Je vais faire célébrer un office en l'honneur de cet événement capital !";
			link.l1 = "Maintenant, si vous voulez bien m'excuser, je dois y aller.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Clermon_Final");
			AddQuestRecord("PKM_Animists", "39");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PKM_Animists_OtetsKlermon = true;
			if (CheckAttribute(pchar, "questTemp.PKM_Animists_MamaDeti") && CheckAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo") && CheckAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon") && CheckAttribute(pchar, "questTemp.PKM_Animists_PadreDominges"))
			{
				CloseQuestHeader("PKM_Animists");
				pchar.questdata.Satanisty = 1;
				UnlockAchievement("AchStrannyeDela", 3);
				DeleteAttribute(pchar, "questTemp.PKM_Animists_MamaDeti");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_PadreDominges");
			}
		break;
		
		
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}



