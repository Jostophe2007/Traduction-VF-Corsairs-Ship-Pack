@echo off
rem Installe la version francaise de Corsairs Ship Pack (voir LISEZMOI_INSTALLATION.txt).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_install\installer.ps1" %*
