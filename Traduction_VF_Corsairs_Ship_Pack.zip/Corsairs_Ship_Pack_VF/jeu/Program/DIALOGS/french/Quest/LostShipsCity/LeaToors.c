#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					if (npchar.location == "PlutoStoreSmall") dialog.text = "Mes salutations, "+ GetSexPhrase("mynheer", "madame") +", et bienvenue chez moi : vous pouvez attendre ici la fin de cette tempête. Je m'appelle " + GetFullName(npchar) + ".";
					else dialog.text = "Mes salutations, mynheer. Je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "Et moi, je suis le capitaine " + GetFullName(pchar) + ". Attendre la fin de la tempête, dites-vous ?";
					link.l1.go = "FS_1";
				}
				else
				{
					if (npchar.location == "PlutoStoreSmall") dialog.text = "Mes salutations, "+ GetSexPhrase("mynheer", "madame") +", et bienvenue chez moi. Je m'appelle " + GetFullName(npchar) + ".";
					else dialog.text = "Mes salutations, "+ GetSexPhrase("mynheer", "madame") +". Je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "Et moi, je suis le capitaine " + GetFullName(pchar) + ". Pour être honnête, ancien capitaine, plutכt...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Puis-je vous aider en quelque chose, "+ GetSexPhrase("mynheer", "madame") +" ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//квест со скелетом Декстера
				if (CheckActiveQuest("LSC_findDekster") && !CheckAttribute(pchar, "questTemp.LSC.lostDecster"))
				{
					link.l4 = "Lea, j'ai entendu dire que vous saviez quelque chose sur un certain Leighton Dexter...";
					link.l4.go = "LostDecster";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && !CheckAttribute(npchar, "quest.grapes"))
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(npchar, "quest.grapes") && sti(npchar.quest.grapes))
				{
					link.l8 = "Je parle de mitraille.";
					link.l8.go = "TakeGrapes";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de venir avec moi sur le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "FS_1":
			dialog.text = "Oui, vous pouvez rester ici aussi longtemps que vous voudrez. La Loi dit que chaque propriétaire de la Cité doit donner un abri à ceux qui en ont besoin pendant le déchaînement des éléments. C'est justement le cas en ce moment.";
			link.l1 = "Oui, ça se voit... Eh bien, merci beaucoup.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Je comprends qu'il ne soit pas facile pour vous de tout perdre. Mais vous êtes en vie !";
			link.l1 = "Oui, oui, bien sמr...";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "וcoutez, il ne faut pas désespérer. Je vous conseille de vous mêler au plus vite à notre vie, elle n'est pas aussi terrible qu'elle peut le sembler au premier abord.";
			link.l1 = "Merci pour votre soutien.";
			link.l1.go = "exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez " + GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Je serai heureuse de vous aider si je le peux, bien sמr. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pense à quelqu'un d'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrées.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1") && npchar.location == "PlutoStoreSmall")
			{
				link.l1 = "Et quel effet ça fait d'être la maîtresse de cette maison ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l2 = "Dites-moi, vous vivez ici depuis longtemps ?";
				link.l2.go = "ansewer_2";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "C'est tout à fait normal, vous savez. Je contrכle tout, ma maison est ma forteresse.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Et n'essayez pas de me prendre quoi que ce soit, j'y veille de près !";
			link.l1 = "Pas question !";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Non, à peine un an environ.";
			link.l1 = "Compris... Dites-moi, connaissez-vous des anciens d'ici, qui vivent là depuis très longtemps ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "J'en connaissais un. Hill Brunner.";
			link.l1 = "Héhé, je le sais. Mais le malheur, c'est qu'il est mort...";
			link.l1.go = "ansewer_2_2";
		break;
		case "ansewer_2_2":
			dialog.text = "Oui, une histoire terrible ! Et totalement incompréhensible, en plus.";
			link.l1 = "C'est vrai... Eh bien, portez-vous bien, Lea.";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Et en quoi puis-je vous aider ?",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je cherche des boulets, des bombes, de la mitraille, des boulets ramés, des vivres, des médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "J'ai de la mitraille sur mon navire. Combien vous en faut-il ?";
			link.l1 = "Cinq quintaux devraient suffire.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "D'accord, je vous la donnerai. Apportez-moi d'abord 10 sacs de sel.";
			link.l1 = "Quoi ?";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Je veux que vous m'apportiez 10 sacs de sel. Qu'y a-t-il d'étrange à ça ? Et ensuite, je vous donnerai la mitraille.";
			link.l1 = "D'accord, vous aurez votre sel.";
			link.l1.go = "exit";
			npchar.quest.grapes = true;
			AddQuestRecord("ISS_MainLine", "53");
		break;
		//проверка на соль
		case "TakeGrapes":
			dialog.text = "Vous m'avez apporté les dix sacs ?";
            if (CheckCharacterItem(pchar, "Mineral10") && sti(pchar.items.Mineral10) >= 10)
            {
				link.l1 = "Oui, je les ai, les voici.";
				link.l1.go = "TakeGrapes_yes";
			}
			else
			{
				link.l1 = "Pas encore, je n'arrive pas à en trouver. Peut-être pourrions-nous nous arranger autrement ?";
				link.l1.go = "TakeGrapes_no";
			}
		break;
		case "TakeGrapes_no":
			dialog.text = "N'y songez même pas !";
			link.l1 = "Hum, je vois...";
			link.l1.go = "exit";
		break;
		case "TakeGrapes_yes":
			dialog.text = "Parfait ! Eh bien, vous pouvez prendre votre mitraille.";
			link.l1 = "Merci. Euh, comment puis-je la faire porter jusqu'au San Gabriel ?";
			link.l1.go = "TakeGrapes_1";
			TakeNItems(pchar, "Mineral10", -10);
		break;
		case "TakeGrapes_1":
			dialog.text = "Hum... Bon, je vous ai fait courir, alors maintenant, je vais vous aider. Le transport jusqu'au San Gabriel, je m'en charge moi-même, je connais beaucoup d'hommes...";
			link.l1 = "Parfait ! Je ne sais même pas comment vous remercier.";
			link.l1.go = "TakeGrapes_2";
		break;
		case "TakeGrapes_2":
			dialog.text = "Oh, allons, ça n'en vaut pas la peine. Tout va bien.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddCharacterGoods(pchar, GOOD_GRAPES, 100);
			AddQuestRecord("ISS_MainLine", "54");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			npchar.quest.grapes = false;
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "דa alors !.. Vous parlez sérieusement ?";
			link.l1 = "Aucun.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Vous savez, j'en ai assez de tout, ici. Alors, si vous dites la vérité, j'accepte.";
			link.l1 = "Vous avez fait le bon choix, je peux vous l'assurer.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Je l'espère vraiment. Alors, que dois-je faire maintenant ?";
			link.l1 = "Allez sur le San Gabriel. Henrik Wedeker vous emmènera sur mon navire. Et ne tardez pas !";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, je serai bientכt sur le « San Gabriel ».";
			link.l1 = "Je vous en prie, dépêchez-vous...";
			link.l1.go = "SeekCrew_all";
		break;
		//квест со скелетом Лейтона Декстера
		case "LostDecster":
			dialog.text = "Hum, pourquoi me demandez-vous ça ?";
			link.l1 = "Eh bien, comment dire ? Simple curiosité.";
			link.l1.go = "LostDecster_1";
		break;
		case "LostDecster_1":
			dialog.text = "Permettez-moi de vous dire que vos centres d'intérêt s'étendent dans une direction très dangereuse...";
			link.l1 = "Qu'est-ce que cela veut dire ?";
			link.l1.go = "LostDecster_2";
		break;
		case "LostDecster_2":
			dialog.text = "Si vous comptez vous opposer à l'amiral, j'ai bien peur que le sort du malheureux Leighton ne vous attende.";
			link.l1 = "Alors, qui est-ce ? Et que lui est-il arrivé, au juste ?";
			link.l1.go = "LostDecster_3";
		break;
		case "LostDecster_3":
			dialog.text = "Vous tenez vraiment à le savoir ?";
			link.l1 = "Absolument.";
			link.l1.go = "LostDecster_4";
		break;
		case "LostDecster_4":
			dialog.text = "Eh bien, je vais vous le dire. Vous savez sans doute déjà que Dexter était un pirate, comme Chad Capper, d'ailleurs. Au début, les deux corsaires se sont liés d'amitié. Chad, quand il est devenu amiral, a aussitכt nommé Leighton chef du Tartarus. J'espère que vous savez que c'est notre prison ?";
			link.l1 = "Hum... Oui, bien sמr, je le sais.";
			link.l1.go = "LostDecster_5";
		break;
		case "LostDecster_5":
			dialog.text = "Mais un jour, le torchon a brמlé entre eux. Une fois, je suis allée rendre visite à Maxim Taylor, qui était une fois de plus en prison. C'était le soir, et, bref, je suis restée là-bas jusqu'à minuit ; alors, quand je suis montée sur le pont, j'ai entendu deux voix : celles de Chad et de Leighton. Ils se disputaient pour de l'argent...";
			link.l1 = "Oui... Et que s'est-il passé ensuite ?";
			link.l1.go = "LostDecster_6";
		break;
		case "LostDecster_6":
			dialog.text = "Ensuite, la dispute a été interrompue par un gémissement rauque et gargouillant. Je ne suis pas idiote, et je me suis dépêchée de quitter discrètement le Tartarus. Je ne sais rien de plus, mais personne n'a revu Leighton Dexter depuis.";
			link.l1 = "Vous pensez que Chad l'a tué ?";
			link.l1.go = "LostDecster_7";
		break;
		case "LostDecster_7":
			dialog.text = "Je n'en sais rien, mais on dirait bien.";
			link.l1 = "Compris... Donc, tout ça s'est passé sur le Tartarus ?";
			link.l1.go = "LostDecster_8";
		break;
		case "LostDecster_8":
			dialog.text = "Apparemment.";
			link.l1 = "Clair. Merci pour votre franchise.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.lostDecster = "toAdmiral";
			AddQuestRecord("LSC_findDekster", "3");
		break;
	}
	NextDiag.PrevNode = NodeName;
}
