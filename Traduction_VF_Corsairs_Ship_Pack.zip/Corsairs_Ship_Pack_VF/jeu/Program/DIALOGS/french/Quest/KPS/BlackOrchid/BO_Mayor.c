// Gregg: the governor of Santiago - the "Black Orchid" trilogy (ported from Damned
// Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// This is a CLONE of the real mayor: same face and same name, but a separate
// character in the clone town. The real governor of Santiago stays alive.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Ah, señor capitaine. Savourez votre triomphe. Savourez-le : il ne vous reste plus longtemps.";
			link.l1 = "Vous aussi, José. Si vos hommes du fort ne se rendent pas à notre demande, j'ai bien peur de devoir vous tuer, vous et la señora Matilda. Qu'en dites-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Capitaine, sortez sur la jetée et regardez l'horizon. Vous voyez trois points blancs ? C'est l'escadre de l'amiral Merkes, à cinq ou six heures du port. La route de la jungle est tenue par nos soldats et une douzaine de canons royaux. Comme vous le voyez, vous n'avez aucune issue.";
			link.l1 = "Il y a toujours une issue, José. וcrivez un ultimatum au commandant du fort : « Accordez le libre passage hors de la ville au capitaine " + GetMainCharacterNameDat() + " et à ses hommes. Sinon, le gouverneur de Santiago et la señora Matilda seront tués. » Et votre sceau et votre signature en dessous.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je n'écrirai pas cela, señor capitaine. Vous pouvez me tuer ici et maintenant si cela vous chante. Ma mort ne changera rien.";
			link.l1 = "Elle me fera pourtant grand plaisir. Et Matilda, José ? Ou avez-vous oublié que vous devez la protéger par tous les moyens ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Permettez-moi de vous expliquer une chose. Matilda est un matériel usé. Ses échecs répétés nous ont obligés à lui trouver un remplaçant, et ce remplaçant arrivera à Santiago à bord du vaisseau amiral de Merkes. La mort de Matilda est inévitable, ce n'est qu'une question de temps : le poison versé dans son vin au dîner fera effet dans une heure, une heure et demie tout au plus. Ma propre mort aussi n'est qu'une question de temps : je suis gravement malade et je ne tiendrai pas deux jours.";
			link.l1 = "Vous mentez, chien d'Espagnol !";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Non, señor capitaine. Tout ce que j'ai dit est vrai. Croyez-le ou non, cela ne change rien. Vous êtes pris au piège, et il ne vous reste plus qu'à attendre la mort.";
			link.l1 = "C'est ce que nous verrons, José. Maintenant, parlez : oם est Matilda ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "J'aimerais bien le savoir moi-même. Quand l'assaut a commencé, elle a disparu sans laisser de traces. Mais il ne lui reste plus beaucoup de temps. Hum... ...(il songe)... Vous savez, capitaine, comme c'est agréable quand tout ce qu'on a entrepris dans la vie réussit. Quand on est prêt à partir pour l'autre monde en sachant que rien ne vous retient ici. Quand on voit devant soi le capitaine " + GetMainCharacterNameGen() + " – le plus heureux des chercheurs, acculé dans un coin, et... comment dire.";
			link.l1 = "Ne vous donnez pas cette peine, José.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactKillSantiagoGovernor");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
