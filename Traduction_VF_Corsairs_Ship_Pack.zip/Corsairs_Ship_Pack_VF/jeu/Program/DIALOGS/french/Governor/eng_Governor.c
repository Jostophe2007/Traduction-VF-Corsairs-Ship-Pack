// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.";
		    link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.BlackYosh_1"))	//Квест "Black Hedgehog"
			{
    			link.l1 = "J'ai entendu dire que deux frégates étaient arrivées au chantier naval de Port Royal pour se réarmer et se ravitailler.";
				link.l1.go = "BlackYosh_1";
			}
			if (CheckAttribute(PChar, "questTemp.silverfleet") && pchar.questTemp.silverfleet != "over" && NPChar.name == GetConvertStr("Variable_StoryCharacters_0.1", "Names.txt"))
			{
				if (!CheckAttribute(NPChar, "SilverFleetCancelThinking") || GetNpcQuestPastDayParam(NPChar, "SilverFleetCancelThinking") > 0)
				{
					link.l1 = "J'ai décidé de renoncer à votre mission de destruction du convoi.";
					link.l1.go = "SF_HuberDialogueThinking";
				}
				if (pchar.questTemp.silverfleet == "ToHuber")
				{
					link.l1 = "On m'a informé que vous souhaitiez me voir.";
					link.l1.go = "SF_HuberDialogueBeginning";
				}
				if (pchar.questTemp.silverfleet == "FirstSilverFleetDeath")
				{
					link.l1 = "Le Convoi d'argent est détruit, monsieur. J'aimerais une récompense.";
					link.l1.go = "SF_HuberDialogueFirstSilverFleetDeath";
				}
				if (pchar.questTemp.silverfleet == "SecondSilverFleetDeath")
				{
					link.l1 = "Je viens vous voir avec des nouvelles, monsieur. Mais à votre air, c'est vous qui allez parler.";
					link.l1.go = "SF_HuberDialogueSecondSilverFleetDeath";
				}
				if (pchar.questTemp.silverfleet == "ThirdSilverFleetDeath")
				{
					link.l1 = "C'est enfin terminé ?";
					link.l1.go = "SF_HuberDialogueTheEnd";
				}
				if (pchar.questTemp.silverfleet == "SeaBattleFail")
				{
					link.l1 = "Je n'ai pas pu détruire le Convoi d'argent. L'escadre est trop forte.";
					link.l1.go = "SF_HuberDialogueFail";
				}
			}
		break;

		case "work_1":  // работа на благо короны - линейка нации
			if (CheckAttribute(npchar, "notQuestLine"))
			{
                dialog.text = "Malheureusement, je ne peux pas vous donner de travail. Vous n'êtes pas la personne à qui j'aimerais confier mes affaires. Adieu.";
                link.l1 = "דa alors...";
                link.l1.go = "exit";
				break;
			}
            // сюда вход только с патентом, проверка выше
            dialog.text = LinkRandPhrase("Vous êtes un corsaire anglais et vous devez tenir parole envers moi ! Je vous prie de commencer immédiatement la mission qui vous a été confiée !",
                                         "Tant que vous n'aurez pas accompli ma mission, je n'ai rien à vous dire.",
                                         "J'attends votre rapport sur l'exécution d'une mission de confiance, pas des conversations creuses !");
            link.l1 = RandPhraseSimple("Je commence immédiatement.", "Je suis déjà en train de m'en occuper...");
            link.l1.go = "exit";

			switch (pchar.questTemp.State)   // что делаем в данный момент
            {
                case "empty":   // Нет взятых квестов
                    if (GetQuestPastDayParam("questTemp") < sti(pchar.questTemp.Waiting_time))
                    {
                        dialog.text = LinkRandPhrase("Je n'ai pas de mission spéciale pour vous pour l'instant. Passez me voir de temps en temps.",
                                                     "Pas maintenant, je suis trop occupé !",
                                                     "On n'a pas encore besoin de votre adresse et de votre courage ; vaquez à vos affaires de corsaire, "+ GetSexPhrase("mon ami","" + pchar.name + "") +".");
                        link.l1 = "Bien, monsieur.";
                        link.l1.go = "exit";
                    }
                    else
                    {
						switch(pchar.questTemp.CurQuestNumber)   // Взятие квестов начиная со второго
                        {
                            case "2":
                                dialog.text = "J'ai une mission pour vous.";
                                link.l1 = "Je suis prêt, monsieur.";
                                link.l1.go = "Step_2_1";
                            break;
                            case "3":   // раньше тройки не было, теперь нужно для того, чтобы ГГ мог взять квест №4 без квеста №3.
                                dialog.text = "Revenez me voir dans deux jours, j'ai une affaire en préparation pour vous.";
                                link.l1 = "Bien, monsieur.";
                                link.l1.go = "exit";
                                pchar.questTemp.Waiting_time = "2";
                                SaveCurrentQuestDateParam("questTemp");
                                pchar.questTemp.CurQuestNumber = "4";
                            break;
                            case "4":
                                dialog.text = "J'ai une affaire pour vous : une mission de reconnaissance. Je dois savoir ce que les Hollandais comptent faire dans cette guerre commerciale. Rendez-vous à Curaçao et tâchez de recueillir le plus d'informations possible sur ce qui s'y passe. Tout ce qui se passe en ville m'intéresse, jusqu'au moindre détail.";
                                link.l1 = "Je suis prêt, monsieur.";
                                link.l1.go = "Step_4_0";
                            break;
                            case "5":
                                dialog.text = "Ah, vous voilà. Je vous attendais.";
                                link.l1 = "Je suis à votre service.";
                                link.l1.go = "Step_5_1";
                            break;
                            case "6":
                                dialog.text = "Le capitaine de la frégate corsaire, Morris Williams, me demande l'autorisation de mouiller en rade de Port Royal.";
                                link.l1 = "Je connais le capitaine Williams.";
                                link.l1.go = "Step_6_1";
                            break;
                            case "7":
                                dialog.text = "C'est avec un profond regret que je dois vous informer que l'ordre du gouvernement anglais de restituer au propriétaire espagnol la cargaison saisie par Morris Williams a eu de graves conséquences pour la Jamaïque.";
                                link.l1 = "Hum... Je ne comprends pas très bien, monsieur...";
                                link.l1.go = "Step_7_1";
                                // ==> Убираем Морриса Уильямса
                                sld = characterFromID("Morris_Willams");
                        	    sld.LifeDay = 1; // уберём нпс на след.день.
                        	    SaveCurrentNpcQuestDateParam(sld, "LifeTimeCreate");
                            break;
                            case "8":
                                dialog.text = "J'ai encore besoin de vous, "+ GetSexPhrase("mon ami","" + pchar.name + "") +". Je dois envoyer une personne de confiance auprès du chef de la colonie de boucaniers de La Vega, à Hispaniola. Oui, vous connaissez Edward Mansfield, vous lui avez déjà rendu visite de ma part. Vous vous en souvenez ?";
                                link.l1 = "Je m'en souviens, monsieur. J'ai "+ GetSexPhrase("essayé","essayé") +" de le persuader d'organiser une attaque contre Curaçao.";
                                link.l1.go = "Step_8_1";
                            break;
                            case "9":
                                dialog.text = "זtes-vous prêt à accomplir la sérieuse mission de prendre d'assaut une ville espagnole ?";
                                link.l1 = "Oui, je suis assez "+ GetSexPhrase("préparé","préparée") +".";
                                link.l1.go = "Step_9_1";
                                link.l2 = "Non, monsieur. Je n'ai pas assez de navires pour une entreprise aussi sérieuse. Je vais bien me préparer et je reviendrai plus tard.";
                                link.l2.go = "exit";
                            break;
                            case "10":
                                dialog.text = "Le gouvernement espagnol a équipé contre les corsaires jamaïcains une escadre de sept vaisseaux de ligne, sous le commandement des amiraux de Bustos et del Campo y Espinosa. Ils ont déjà atteint la Jamaïque. Le moment n'aurait pu être mieux choisi : vous avez vu vous-même qu'il n'y a plus un seul corsaire en rade de Port Royal, à part vous ; ils sont tous partis avec Morgan pour une nouvelle chasse aux Espagnols. Vous devez repousser l'attaque. Les navires de garde passent sous vos ordres, c'est tout ce que je peux faire pour vous. Allez-y, et que le Seigneur nous vienne en aide !";
                                link.l1 = "Bien, monsieur. Je pense que nous allons les repousser.";
                                link.l1.go = "exit";
                                pchar.questTemp.State = "SpanishAttack_ShipsInShore";
                                SetQuestHeader("Eng_Line_10_SpanishAttack");
                                AddQuestRecord("Eng_Line_10_SpanishAttack", "1");
                                Pchar.quest.SpanishAttack_Battle.win_condition.l1 = "location";
                                Pchar.quest.SpanishAttack_Battle.win_condition.l1.location = "Jamaica";
                                Pchar.quest.SpanishAttack_Battle.win_condition = "SpanishAttack_Battle";
                                ChangeCharacterAddress(characterFromID("Henry Morgan"), "None", "");
                            break;
                            case "11":
                                dialog.text = "Entrez, je vous en prie ! J'ai une mission importante pour vous.";
                                link.l1 = "Je vous écoute, monsieur.";
                                link.l1.go = "Step_11_1";
                            break;
                            case "12":
                                dialog.text = ""+ GetSexPhrase("Mon ami","" + pchar.name + "") +", j'ai pour vous une mission quelque peu inhabituelle...";
                                link.l1 = "Je vous écoute attentivement.";
                                link.l1.go = "Step_12_1";
                            break;
                            case "13":
                                dialog.text = "Je suis très content de vous voir chez moi. Soyez le bienvenu, monsieur.";
                                link.l1 = "Monsieur ?";
                                link.l1.go = "Step_12_5";
                            break;
                        }
                    }
                break;

                case "":           // Квест №1 - сопровождение Альбермаля
                    dialog.text = "J'ai une mission très importante pour vous. Vous êtes un visage nouveau ici, je ne suis pas sמr de pouvoir vous faire confiance, mais je n'ai pas vraiment le choix.";
                    link.l1 = "Je serai "+ GetSexPhrase("content","contente") +" d'accomplir votre mission.";
                    link.l1.go = "Step_1_1";
                    link.l2 = "Désolé, mais je suis en train de régler un autre problème.";
                    link.l2.go = "exit";
                break;
                case "Albermal_good_time":                  // Геймер успел доставить Альбермаля за неделю.
                    dialog.text = "Dans la lettre que vous avez apportée, le duc d'Albemarle vous accorde une appréciation très flatteuse. Le duc est mon parent, et c'est à lui que je dois ma nomination à ce poste. Sans ses actions énergiques et opportunes en Angleterre, on ne sait pas comment mon gouvernorat à la Barbade aurait fini..\n"+
                                  "Vous avez brillamment accompli la mission. La récompense promise est de 50 000. Vous avez mérité cet argent et ma gratitude\n"+
                                  "La recommandation du duc d'Albemarle est pour moi la meilleure des garanties. Si vous êtes prêt à poursuivre votre coopération avec l'Angleterre, passez me voir de temps en temps.";
                    link.l1 = "Merci, monsieur. Vous pourrez compter sur moi à l'avenir.";
                    link.l1.go = "exit";
    				AddMoneyToCharacter(pchar, 50000);
    				ChangeCharacterReputation(pchar, 5);
					ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
    				AddCharacterExpToSkill(pchar, "Defence", 100);
    				AddTitleNextRate(sti(NPChar.nation), 1);
                    CloseQuestHeader("Eng_Line_1_Albermal");
                    pchar.questTemp.State = "empty";
                    SaveCurrentQuestDateParam("questTemp");
                    TakeItemFromCharacter(pchar, "letter_Albermal");
					//слухи
					AddSimpleRumour("Vous avez entendu ? Notre gouverneur général ne tarit pas d'éloges sur le capitaine " + GetMainCharacterNameGen() + " ! "+ GetSexPhrase("Il aurait réussi","Elle aurait réussi") +" à faire sortir clandestinement de l'île l'oncle londonien et protecteur du gouverneur, le pair d'Angleterre, le duc d'Albemarle. Vous savez qui est Albemarle ?! Je vous dirai en confidence que c'est uniquement grâce à lui que sir Thomas Madiford est gouverneur en exercice de la Jamaïque, sinon il ne s'en serait pas bien tiré...", ENGLAND, 5, 1);
                break;
                case "Albermal_late":  // Геймер не успел за неделю доставить Альбермаля.
                    dialog.text = "Eh bien, dans la lettre que vous avez apportée, Albemarle m'informe de son arrivée sans encombre à St. John's. Vous avez repoussé l'attaque du brick espagnol, mais vous n'avez pas su mener le duc à destination dans les délais. Votre récompense est de 20 000. Je ne dirais pas que je suis pleinement satisfait de vous.";
                    link.l1 = "Monsieur, je suis désolé pour ce retard, mais j'ai dמ faire face à un cas de force majeure. J'espère pouvoir compter sur des missions spéciales à l'avenir ?";
                    link.l1.go = "Step_1_4";
                break;
                case "after_talks_with_pirates":  // После опроса пиратов
                    dialog.text = "Avez-vous obtenu le soutien des pirates ? Quand Mansfield prévoit-il l'action ?";
                    link.l1 = "Monsieur, malheureusement, je n'ai pu m'entendre avec aucun des pirates que vous avez mentionnés. Partout, on a refusé d'attaquer Curaçao. Les raisons de ces refus sont diverses.";
                    link.l1.go = "Step_2_3";
                break;
                case "Intelligence_Curacao_Sink":  // Голландский флейт с инфой на борту был потоплен, провал миссии
                    dialog.text = "Rapportez-moi ce que vous avez appris.";
                    link.l1 = "Malheureusement, je n'ai pas pu capturer le navire sur lequel je "+ GetSexPhrase("devais","devais") +" trouver les papiers nécessaires. Je n'ai rien pu apprendre d'utile.";
                    link.l1.go = "Step_4_1";
                break;
                case "Intelligence_Curacao_Boarding":  // Миссия выполнена, голландский флейт взят на абордаж
                    dialog.text = "Rapportez-moi ce que vous avez appris.";
                    link.l1 = "Voici le document trouvé sur le brick hollandais capturé. C'est un ordre au gouverneur de Fort Orange de fortifier d'urgence la ville.";
                    link.l1.go = "Step_4_2";
                break;
                case "Intelligence_Curacao_BoardingNotFoundLetter":  // Миссия провалена, голландский флейт взят на абордаж, но письмо не найдено
                    dialog.text = "Rapportez-moi ce que vous avez appris.";
                    link.l1 = "J'ai reçu des informations sur le brick courrier hollandais. J'ai réussi à aborder ce brick, mais je n'y ai trouvé aucun document.";
                    link.l1.go = "Step_4_1";
                break;
                case "Intelligence_Curacao_OutPrison":  // Миссия провалена, ГГ побывал в тюрьме
                    dialog.text = "Rapportez-moi ce que vous avez appris.";
                    link.l1 = ""+ GetSexPhrase("Malheureusement, j'ai été capturé et jeté en prison. J'ai réussi à m'évader, mais je n'ai rien appris","Malheureusement, j'ai été capturée et jetée en prison. J'ai réussi à m'évader, mais je n'ai rien appris") +".";
                    link.l1.go = "Step_4_4";
                break;
                case "Intelligence_Curacao_FightGard": // Миссия провалена, ГГ дрался и ушёл из города ни с чем
                    dialog.text = "Rapportez-moi ce que vous avez appris.";
                    link.l1 = "Malheureusement, ma couverture a sauté pendant la mission. Il y a eu un combat, et j'ai eu bien du mal à "+ GetSexPhrase("m'échapper","m'échapper") +" de la ville. Désormais, il est hors de question que je me montre à Curaçao. Je n'ai rien pu apprendre d'intéressant pour vous.";
                    link.l1.go = "Step_4_5";
                break;
                case "AttackFortOrange_WeWin":   // Форт Оранж взят.
                    dialog.text = "Il y a du sang partout sur vous";
                    link.l1 = "C'est du sang hollandais... Nous avons réussi, Fort Orange est pillé. Mon équipage a fait un beau bénéfice. La mission est accomplie.";
                    link.l1.go = "Step_5_2";
                break;
                case "MorrisWillams_AfterFirstTalkingWithMorris": // Получено согласие Морриса Уильямса зайти в Порт Рояль.
                    dialog.text = "Alors, qu'avez-vous à me dire, " + GetFullName(pchar) + " ?";
                    link.l1 = "Monsieur, votre mission est accomplie, Morris Williams entre au port.";
                    link.l1.go = "Step_6_2";
                break;
                case "MorrisWillams_ToModifordForCoolTalking": // На разборки после разговора с Уильямсом в таверне
                    dialog.text = "Ah, vous revoilà, " + GetFullName(pchar) + ". Je vous écoute attentivement.";
                    link.l1 = "Bon sang ! Que se passe-t-il ?";
                    link.l1.go = "Step_6_3";
                break;
                case "MorrisWillams_ArrestedToModiford": // На разборки после разговора с начальником тюрьмы
                    dialog.text = "Ah, vous revoilà, " + GetFullName(pchar) + ". Qu'est-ce qui vous amène cette fois ?";
                    link.l1 = "Monsieur, je dois vous parler.";
                    link.l1.go = "Step_6_6";
                break;
                case "MorrisWillams_ModifordGood5000":
                    dialog.text = "Ah, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", vous avez déjà dépensé vos cinq mille et vous cherchez du travail ?";
                    link.l1 = "Non, je suis "+ GetSexPhrase("passé","passée") +" pour parler de choses et d'autres.";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_ModifordPolitic":
                    dialog.text = "Je n'ai rien de plus à vous dire. C'est la politique qui décide du sort des וtats ; il n'y a pas à se soucier du sort de quelques corsaires...";
                    link.l1 = "Bien dommage, monsieur.";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_SeekSpanishGoods":
                    dialog.text = "Alors, "+ GetSexPhrase("mon ami","" + pchar.name + "") +" ! Vous avez fini par digérer l'affaire Williams ? Je vous conseille de laisser tomber cette histoire : le pauvre garçon n'a pas de chance. Mais c'est la vie, il faut bien que quelqu'un perde...";
                    link.l1 = "Monsieur, j'apprécie hautement vos aimables conseils. J'essaierai de les suivre...";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_PinnaceBoard":
                    dialog.text = "J'ai entendu dire que vous aviez abordé une pinasse espagnole juste à cכté de San Juan, sous le feu du fort ?!! Je dois dire que c'était une opération risquée...";
                    link.l1 = "Tout est bien qui finit bien, monsieur...";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_PinnaceBoardNotFoundMoney":
                    dialog.text = "J'ai entendu dire que vous aviez abordé une pinasse espagnole juste à cכté de San Juan ?!! Dites-moi, le risque en valait-il la peine ?";
                    link.l1 = "Non, monsieur. Il n'y avait rien d'utile dans les cales...";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_PinnaceSink":
                    dialog.text = "J'ai entendu dire que vous aviez coulé une pinasse espagnole juste à cכté de San Juan. Et pourquoi aller vous jeter sous le feu du fort ?";
                    link.l1 = "C'est arrivé comme ça, monsieur...";
                    link.l1.go = "exit";
                break;
                case "MorrisWillams_DieHard":
                    dialog.text = "Le capitaine du port m'a rapporté que vous aviez pris en chasse une pinasse espagnole. Dites-moi, mon ami, avec succès ? (d'un ton moqueur)";
                    link.l1 = "Non, monsieur. "+ GetSexPhrase("J'ai essayé","J'ai essayé") +", en vain...";
                    link.l1.go = "exit";
                break;
                case "SevenTreasures_GoOn":
                    dialog.text = "Avez-vous trouvé l'or ?";
                    link.l1 = "Pas encore, mais je cherche sans relâche. La mission n'est pas facile...";
                    link.l1.go = "exit";
                    if (CheckCharacterItem(pchar, "jewelry5"))
                    {
                        link.l1 = "Il y a du nouveau.";
                        link.l1.go = "Step_7_4";
                    }
                    link.l2 = "Vous savez, gouverneur général, j'en ai par-dessus la tête. Je ne veux plus courir les Caraïbes pour vous chercher de l'or.";
                    link.l2.go = "Step_7_10";
                break;
                case "ToMansfield_CatchToPardal":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, la colonie de boucaniers a été attaquée par les Espagnols. Mansfield est tué, l'or est volé. L'amiral de l'escadre espagnole était apparemment Manoel Rivero Pardal.";
                    link.l1.go = "Step_8_3";
                break;
                case "ToMansfield_NotFoundGaleon":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, La Vega a été attaquée par les Espagnols. Mansfield est tué, l'or est volé. L'amiral de l'escadre espagnole était Manoel Rivero Pardal. Monsieur, j'ai pris soin de "+ GetSexPhrase("vérifier","vérifier") +" toute la route jusqu'à Santiago, mais je n'ai pas "+ GetSexPhrase("croisé","croisé") +" les Espagnols qui ont attaqué.";
                    if (CheckAttribute(npchar , "TempQuest.KnowAboutModiford"))
                    {
                        dialog.text = "Avez-vous réussi à rattraper les Espagnols ?";
                        link.l1 = "Non, monsieur. Je n'ai pas réussi. J'ai pris soin de "+ GetSexPhrase("vérifier","vérifier") +" toute la route jusqu'à Santiago, mais je n'ai pas "+ GetSexPhrase("croisé","croisé") +" les galions.";
                    }
                    link.l1.go = "Step_8_5";
                break;
                case "ToMansfield_Boarding":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, La Vega a été attaquée par les Espagnols. Mansfield est tué, l'or est volé. L'amiral de l'escadre espagnole était Manoel Rivero Pardal. J'ai réussi à rattraper l'un des trois galions assaillants et à l'aborder. Il n'y avait pas d'or à bord, mais j'ai trouvé dans la cabine du capitaine une lettre de Pardal au gouverneur de Santiago, Jimenez. La voici.";
                    if (CheckAttribute(npchar , "TempQuest.KnowAboutModiford"))
                    {
                        dialog.text = "Avez-vous réussi à rattraper les Espagnols ?";
                        link.l1 = "Près de Santiago, mon équipage "+ GetSexPhrase("a réussi","a réussi") +" à aborder un galion espagnol, l'un de ceux qui ont participé à l'attaque contre les boucaniers. Il n'y avait pas d'or à bord, mais une lettre de Pardal au gouverneur de Santiago, Jimenez, a été trouvée dans la cabine du capitaine ; la voici.";
                    }
                    link.l1.go = "Step_8_5";
                    npchar.TempQuest.KindResult = 1; // признак результата завершения квеста, 1 == было захвачено письмо
        			AddCharacterExpToSkill(pchar, "Cannons", 600);
        			AddCharacterExpToSkill(pchar, "Sailing", 750);
        			AddCharacterExpToSkill(pchar, "Defence", 550);
        			AddCharacterExpToSkill(pchar, "Accuracy", 700);
        			AddTitleNextRate(sti(NPChar.nation), 1);
                break;
                case "ToMansfield_BoardingNotFoundLetter":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, La Vega a été attaquée par les Espagnols. Mansfield est tué, l'or est volé. L'amiral de l'escadre espagnole était Manoel Rivero Pardal. J'ai réussi à rattraper l'un des trois galions assaillants et à l'aborder. Il n'y avait pas d'or à bord. Apparemment, il était sur un autre navire. Je ne sais pas oם sont allés les deux autres galions.";
                    if (CheckAttribute(npchar , "TempQuest.KnowAboutModiford"))
                    {
                        dialog.text = "Avez-vous réussi à rattraper les Espagnols ?";
                        link.l1 = "Près de Santiago, mon équipage "+ GetSexPhrase("a réussi","a réussi") +" à aborder un galion espagnol, l'un de ceux qui ont participé à l'attaque contre les boucaniers. Il n'y avait pas d'or à bord. Apparemment, il était sur un autre navire. Je ne sais pas oם sont allés les deux autres galions.";
                    }
                    link.l1.go = "Step_8_5";
        			AddCharacterExpToSkill(pchar, "Repair", 40);
        			AddCharacterExpToSkill(pchar, "Commerce", 50);
        			AddCharacterExpToSkill(pchar, "Defence", 20);
        			AddCharacterExpToSkill(pchar, "Leadership", 10);
        			AddTitleNextRate(sti(NPChar.nation), 0.5);
                break;
                case "ToMansfield_GaleonSink":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, La Vega a été attaquée par les Espagnols. Mansfield est tué, l'or est volé. L'amiral de l'escadre espagnole était Manoel Rivero Pardal. J'ai réussi à rattraper l'un des trois galions assaillants et à le couler. Je ne sais pas oם sont allés les deux autres galions.";
                    if (CheckAttribute(npchar , "TempQuest.KnowAboutModiford"))
                    {
                        dialog.text = "Avez-vous réussi à rattraper les Espagnols ?";
                        link.l1 = "Près de Santiago, mon équipage "+ GetSexPhrase("a réussi","a réussi") +" à aborder un galion espagnol, l'un de ceux qui ont participé à l'attaque contre les boucaniers. J'ai réussi à rattraper l'un des trois galions assaillants et à le couler. Je ne sais pas oם sont allés les deux autres galions.";
                    }
                    link.l1.go = "Step_8_5";
        			AddCharacterExpToSkill(pchar, "Repair", 5);
        			AddCharacterExpToSkill(pchar, "Commerce", 10);
        			AddCharacterExpToSkill(pchar, "Cannons", -50);
        			AddCharacterExpToSkill(pchar, "Accuracy", -70);
        			AddCharacterExpToSkill(pchar, "Fencing", -100);
					ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
                break;
                case "ToMansfield_DidNotFindBecaners":
                    dialog.text = "Avez-vous rapporté l'or de Mansfield ?";
                    link.l1 = "Monsieur, à mon arrivée à La Vega, elle était déserte ! Pas âme qui vive. J'ai fouillé les environs, mais je n'ai rien trouvé.";
                    link.l1.go = "Step_8_5";
                    npchar.TempQuest.KindResult = 2; // признак результата завершения квеста, 2 == вообще не в курсе, что произошло
        			AddCharacterExpToSkill(pchar, "Cannons", 10);
        			AddCharacterExpToSkill(pchar, "Pistol", -200);
        			AddCharacterExpToSkill(pchar, "Defence", -100);
        			AddCharacterExpToSkill(pchar, "Accuracy", -210);
        			AddCharacterExpToSkill(pchar, "Fencing", -400);
					ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
                break;
                case "AttackSantiago_GoodWork":
                    dialog.text = "Je suis déjà au courant de vos exploits. C'est une brillante victoire, "+ GetSexPhrase("mon ami","" + pchar.name + "") +".";
                    link.l1 = "Merci, monsieur. Je pense que vous serez content d'apprendre que le gouverneur de Santiago est mon prisonnier et qu'il est à bord.";
                    link.l1.go = "Step_9_4";
                break;
                case "SpanishAttack_GoodWork":
                    dialog.text = "Bon sang, vous nous avez littéralement tous sauvés ! La ville de Port Royal vous doit la vie !";
                    link.l1 = "Oui, les Espagnols ont rassemblé des forces que je n'aurais jamais soupçonnées ; sans les navires de garde, je n'aurais pas "+ GetSexPhrase("été en mesure","été en mesure") +"...";
                    link.l1.go = "Step_10_1";
                break;
                case "OccupyMein_GoOn":
                    dialog.text = "Vous n'avez toujours pas pris Cumaná ni Caracas. Toute la cכte du Continent est encore aux mains des Espagnols...";
                    link.l1 = "Monsieur, je m'en occupe. La mission n'est pas facile et demande une sérieuse préparation. L'attaque sera menée dès que tout sera prêt.";
                    link.l1.go = "exit";
                    if (CheckAttribute(pchar, "questTemp.Q11_Caracas"))
                    {
                        dialog.text = "Vous avez pris Caracas ! Très bien, "+ GetSexPhrase("mon ami","" + pchar.name + "") +". Mais Cumaná n'est pas encore prise. Dépêchez-vous !";
                        link.l1 = "Bien, monsieur.";
                        link.l1.go = "exit";
                    }
                    if (CheckAttribute(pchar, "questTemp.Q11_Cumana"))
                    {
                        dialog.text = "Cumaná appartient à l'Angleterre, et c'est grâce à vous ! Excellent, "+ GetSexPhrase("mon ami","" + pchar.name + "") +" ! Mais j'attends aussi que vous preniez Caracas, qui doit tomber elle aussi !";
                        link.l1 = "Je vais le faire, monsieur.";
                        link.l1.go = "exit";
                    }
                    if (CheckAttribute(pchar, "questTemp.Q11_Caracas") && CheckAttribute(pchar, "questTemp.Q11_Cumana"))
                    {
                        dialog.text = "Cumaná et Caracas sont prises ! Désormais, cette cכte du Continent appartient à l'Angleterre !";
                        link.l1 = "Oui, monsieur. Nous avons réussi.";
                        link.l1.go = "Step_11_2";
                    }
                break;
                case "ColonelLinch_ArrestModiford":
                    dialog.text = "Dites-moi, qu'avez-vous appris ? Que se passe-t-il à St. John's ?";
                    link.l1 = "Monsieur, j'ai rencontré le colonel Thomas Lynch à la résidence du gouverneur de St. John's.";
                    link.l1.go = "Step_12_2";
                break;
                case "ColonelLinch_ModifordArrested":
                    dialog.text = "Vous avez accompli la mission : Madiford a été arrêté et jeté en prison. Une enquête approfondie sur ses activités de gouverneur général de la Jamaïque commence. J'aimerais beaucoup vous revoir chez moi dans un mois environ.";
                    link.l1 = "Bien, monsieur.";
                    link.l1.go = "exit";
                    pchar.questTemp.State = "empty";
                    SaveCurrentQuestDateParam("questTemp");
                    pchar.questTemp.CurQuestNumber = "13";
                    pchar.questTemp.Waiting_time = "30";
                    CloseQuestHeader("Eng_Line_12_ColonelLinch");
                break;
                case "QuestLineBreake":
                    dialog.text = "Je ne traite pas avec les gens qui manquent à leur parole. Je n'ai rien de plus à vous dire.";
                    link.l1 = "...";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
                case "EndOfQuestLine":
                    dialog.text = pchar.name + ", je fais confiance à votre vision de la situation dans les Caraïbes. Vous avez donc toute liberté d'action dans l'intérêt de l'Angleterre.";
                    link.l1 = "Je comprends, monsieur. Merci de votre confiance.";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
             }
		break;

		case "Step_1_1":
			//LockQuestLine(characterFromId("Jackman")); // лочим пиратскую линейку
            dialog.text = "Mon proche parent, le duc d'Albemarle, séjourne en ce moment chez moi. Sa mission ici est terminée, et je dois l'escorter d'urgence vers l'Angleterre. Une frégate de la Royal Navy attend le duc sur l'île d'Antigua, à St. John's. Conduisez le duc à St. John's, à la résidence du gouverneur\n"+
                          "Partez immédiatement et faites preuve de prudence : deux espions espagnols ont déjà été pris à Port Royal, et je suis absolument sמr qu'il reste encore des agents en ville. Je dois supposer que les Espagnols savent qu'un personnage anglais d'un si haut rang se trouve ici. De plus, on m'informe d'une étrange activité des navires de guerre espagnols autour de la Jamaïque.";
            link.l1 = "Hum, en effet, mieux vaut s'attendre au pire.";
            link.l1.go = "Step_1_2";
        break;

        case "Step_1_2":
            dialog.text = "En ce moment, il me faut un capitaine avec un navire qui n'attire pas l'attention. Je mise sur l'effet de surprise. Personne ne vous connaît, votre voilier non plus. C'est avec vous que le duc d'Albemarle court le moins de risques en se rendant à Antigua.";
            link.l1 = "Je pense que vous avez raison, monsieur.";
            link.l1.go = "Step_1_3";
        break;

        case "Step_1_3":
            dialog.text = "Faites-le en deux semaines, et vous recevrez une riche récompense. Vous répondez du duc d'Albemarle sur votre tête. Il se trouve en ce moment dans ma résidence, dans un bureau à part. Mettez-vous en route dès que possible, et ne tardez pas.";
            link.l1 = "Je vous comprends, monsieur.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
			// остальные линейки в сад -->
			pchar.questTemp.NationQuest = ENGLAND;
			// остальные линейки в сад <--
            pchar.questTemp.State = "to_Albermal";               // переменная состояния квеста для линеек
            sld = GetCharacter(NPC_GenerateCharacter("Albermal", "Albermal", "man", "man", 10, ENGLAND, -1, false));
        	sld.name 	= "Le duc";
        	sld.lastname = "Albermal";
            sld.Dialog.Filename = "Quest\EngLineNpc_1.c";
			sld.greeting = "Gr_QuestMan";
        	LAi_SetHuberStayType(sld);
        	LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Albermal")], "PortRoyal_RoomTownhall", "goto", "goto3");
            AddQuestRecord("Eng_Line_1_Albermal", "1");
        break;

        case "Step_1_4":
            dialog.text = "Je le pense aussi. Mais désormais, faites preuve de plus de soin dans l'exécution de mes missions. Vous êtes un corsaire anglais. Les intérêts de l'Angleterre passent avant tout !";
            link.l1 = "Vous avez raison, monsieur. Vous pouvez compter sur moi pour être plus "+ GetSexPhrase("zélé","zélée") +".";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 20000);
			pchar.questTemp.Waiting_time = 10;
			ChangeCharacterReputation(pchar, 1);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
            CloseQuestHeader("Eng_Line_1_Albermal");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            TakeItemFromCharacter(pchar, "letter_Albermal");
			AddCharacterExpToSkill(pchar, "Leadership", -70);
			//слухи
			AddSimpleRumour("Vous savez, le capitaine " + GetFullName(pchar) + " "+ GetSexPhrase("a réussi","a réussi") +" à mener à bien une mission très dangereuse pour Madiford. "+ GetSexPhrase("Il","Elle") +" devait conduire le duc d'Albemarle en lieu sמr... Vous savez qui est Albemarle ?! Je vous dirai en confidence que c'est uniquement grâce à lui que sir Thomas Madiford est gouverneur en exercice de la Jamaïque... Seulement, les délais, le capitaine les a "+ GetSexPhrase("ratés","ratés") +".", ENGLAND, 5, 1);
        break;

        case "Step_2_1":
            dialog.text = "Il y a une guerre commerciale avec les Pays-Bas en Europe. La flotte anglo-française s'est approchée des cכtes de Hollande, mais, à la surprise générale, elle a été vaincue. Maintenant, sur ordre du gouvernement anglais, je dois organiser une attaque contre la colonie hollandaise de Curaçao\n"+
                          "Cependant, je n'ai pour l'instant à ma disposition aucune force capable de venir à bout d'une forteresse comme Willemstad. Je vais me servir des corsaires anglais pour l'attaque. D'ailleurs, il est très avantageux pour moi d'entretenir une flotte pirate improvisée à Port Royal : une bonne protection, et entièrement gratuite pour la Couronne ! Hé...";
            link.l1 = "Quelle est ma mission ?";
            link.l1.go = "Step_2_2";
        break;

        case "Step_2_2":
            dialog.text = "Vous devez trouver Edward Mansfield dans la colonie de boucaniers de La Vega, à Hispaniola, Henry Morgan, qui est en ce moment à St. John's, Jackman dans le repaire pirate des Bermudes, et John Morris sur l'île de la Trinité. Vous devez obtenir l'accord de ces pirates pour lancer une attaque contre Curaçao, qui sera menée par Mansfield. Faites-le le plus vite possible, je compte sur vous.";
            link.l1 = "Je m'y mets immédiatement, monsieur.";
            link.l1.go = "Step_2_21";
        break;

        case "Step_2_21":
            dialog.text = "Et je voudrais vous parler de Morgan à part. Le fait est que sa maison d'Antigua est une véritable forteresse. Il n'est pas si facile d'y entrer. Il faut pénétrer dans la maison par le souterrain qui se trouve sous St. John's.";
            link.l1 = "Je comprends, monsieur. Merci de l'avertissement. Je pense que je m'en sortirai.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "go_talks_with_pirates";          // переменная состояния квеста для линеек
            AddQuestRecord("Eng_Line_2_Talking", "1");
            // ==>  Помещаем Моргана на Антигуа и даём ноду доступа к квестам
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "SentJons_HouseF3", "goto", "goto1");
            QuestSetCurrentNode("Henry Morgan", "EngLine_quests");
            sld = characterFromID("Henry Morgan");
            LAi_SetHuberStayType(sld);
            LAi_SetLoginTime(sld, 0.0, 24.0);
            // ==>  Генерим и помещаем Джона Морриса в Бриджтаун и даём ноду доступа к квестам
            sld = GetCharacter(NPC_GenerateCharacter("John Morris", "bocman", "man", "man", 38, PIRATE, -1, false));
        	sld.name 	= "John";
        	sld.lastname = "Morris";
            sld.Dialog.Filename = "Quest\JohnMorris.c";
            FantomMakeCoolSailor(sld, SHIP_GALEON_H, "Lagoon", CANNON_TYPE_CANNON_LBS32, 90, 90, 90);
            FantomMakeCoolFighter(sld, 35, 90, 50, BLADE_LONG, "pistol3", 150);
			sld.greeting = "Gr_HeadPirates";
            LAi_NoRebirthDisable(sld);
			LAi_RebirthOldName(sld);
			sld.RebirthPhantom = true; //не тереть фантома после смерти.
           	LAi_SetHuberType(sld);
        	LAi_SetLoginTime(sld, 0.0, 24.0);
        	LAi_SetHP(sld, 180.0, 180.0);
            ChangeCharacterAddressGroup(sld, "PortSpein_houseF2", "sit", "sit1");
            LAi_LocationFightDisable(&Locations[FindLocation("PortSpein_houseF2")], true);
            // ==>  Даём ноду доступа к квестам Джону Моррису
            QuestSetCurrentNode("John Morris", "EngLine_quests");
            // ==>  Даём ноду доступа к квестам Джекмену
            QuestSetCurrentNode("Jackman", "EngLine_quests");
            // ==>  Даём ноду доступа к квестам Манфсфилду
            QuestSetCurrentNode("Edward Mansfield", "EngLine_quests");
            // ==>  Оформляем счётчик посещения корсаров, в итоге должен == 4
            pchar.questTemp.Count = "0";
        break;

        case "Step_2_3":
            dialog.text = "Pensez-vous que les choses puissent changer à l'avenir ?";
            link.l1 = "Difficile à dire, mais je ne crois pas, monsieur. On ne pourra pas les convaincre tous les quatre, c'est certain.";
            link.l1.go = "Step_2_4";
        break;

        case "Step_2_4":
            if (GetQuestPastDayParam("questTemp") < 35)
            {
                dialog.text = "Hum, je vois. Eh bien, malgré le résultat négatif de la mission, je suis satisfait de votre rapidité et de votre zèle. Vous avez droit à une récompense de 15 000. J'espère pouvoir faire appel à vos services à l'avenir ?";
                link.l1 = "Bien sמr, monsieur. Je serai "+ GetSexPhrase("content","contente") +" de vous aider.";
                AddMoneyToCharacter(pchar, 15000);
				ChangeCharacterReputation(pchar, 3);
				AddCharacterExpToSkill(pchar, "Repair", 150);
				AddCharacterExpToSkill(pchar, "Sailing", 100);
				AddTitleNextRate(sti(NPChar.nation), 2);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
            }
            else
            {
                dialog.text = "Je suis extrêmement déçu : l'ordre du gouvernement anglais ne sera pas exécuté. C'est fâcheux, et de plus, vous n'avez pas été assez rapide dans l'accomplissement de cette mission. Vous y avez mis " +
                                GetQuestPastDayParam("questTemp") + " jours ! La rétribution sera à l'avenant, c'est-à-dire faible.";
                link.l1 = "Eh bien, vous savez mieux que moi.";;
                AddMoneyToCharacter(pchar, 800);
				ChangeCharacterReputation(pchar, 1);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
            }
            link.l1.go = "exit";
			//слухи
			AddSimpleRumour("Vous savez, le capitaine " + GetFullName(pchar) + " "+ GetSexPhrase("a travaillé","a travaillé") +" aux ordres de Madiford : "+ GetSexPhrase("il a couru","elle a couru") +" les Caraïbes d'un bout à l'autre ; même chez Morgan, on l'a "+ GetSexPhrase("vu","vue") +"...", ENGLAND, 5, 1);
            DeleteAttribute(pchar, "questTemp.Count");
            pchar.questTemp.State = "empty";
            AddQuestRecord("Eng_Line_2_Talking", "6");
			AddQuestUserData("Eng_Line_2_Talking", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_2_Talking");
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "3";
            pchar.questTemp.Waiting_time = "70";    // Чтобы Мэдифорд дал квест №4 через 70 дней, даже если ГГ не зашёл к Моргану
            // ==> Моргана - в резиденцию на Ямайке
            LAi_SetHuberType(characterFromID("Henry Morgan"));
            QuestSetCurrentNode("Henry Morgan", "hot_business");
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "PortRoyal_houseS1", "sit", "sit2");
        break;

        case "Step_4_0":
            dialog.text = "Pour faciliter l'exécution de la mission, je vous remets une licence de la Compagnie néerlandaise des Indes occidentales valable 15 jours, qui vous permettra d'entrer en ville sans danger. Mettez-vous en route immédiatement.";
            link.l1 = "Bien, monsieur.";
            link.l1.go = "exit";
			GiveUniLicence(15); // universal GWIK trade license
			pchar.questTemp.State = "Intelligence_Curacao_tavern";
			SetQuestHeader("Eng_Line_4_Intelligence_Curacao");
			AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "1");
			AddQuestUserData("Eng_Line_4_Intelligence_Curacao", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Eng_Line_4_Intelligence_Curacao", "sSex1", GetSexPhrase("", "e"));
			SaveCurrentQuestDateParam("questTemp");
		break;

        case "Step_4_1":
            dialog.text = "C'est très fâcheux, vous m'avez déçu. Vous pourrez revenir plus tard, quand j'aurai réussi à obtenir les informations dont j'ai besoin.";
            link.l1 = "Bien sמr, monsieur. Pardon de ne pas avoir "+ GetSexPhrase("été en mesure","été en mesure") +" de vous aider.";
            link.l1.go = "exit";
			TakeNationLicence(HOLLAND);
            CloseQuestHeader("Eng_Line_4_Intelligence_Curacao");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "5";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.Waiting_time = "30";    //только через месяц следующий квест, т.к. Мэдифорд будет добывать инфу без участия ГГ
			AddCharacterExpToSkill(pchar, "Sailing", -140);
			AddCharacterExpToSkill(pchar, "Sneak", -180);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			//слухи
			AddSimpleRumour("On dit que vous n'avez pas réussi à mener la reconnaissance à Curaçao. Hum, voyez-vous ça...", ENGLAND, 5, 1);
        break;

        case "Step_4_2":
            dialog.text = "Vous avez réussi à vous procurer le document lui-même ?! Très bien, je ne me suis pas trompé sur votre compte\n"+
                          "Cependant, les Hollandais ont eu vent de nos plans... Je vous prie de revenir me voir un peu plus tard, je dois y réfléchir. Pour une mission parfaitement accomplie, vous avez droit à une récompense de 100 000.";
            link.l1 = "Monsieur, j'ai dמ soudoyer un usurier à Willemstad. Le montant du pot-de-vin est justement de cent mille. Avec cette récompense, vous ne ferez que couvrir mes frais.";
            link.l1.go = "Step_4_3";
        break;

        case "Step_4_3":
            dialog.text = "Eh bien, je vous donne 110000, je m'arrangerai. Maintenant, laissez-moi seul un moment. Revenez me voir dans deux ou trois jours, je vous prie.";
            link.l1 = "Merci beaucoup, monsieur. Je ne manquerai pas de repasser plus tard.";
            link.l1.go = "exit";
            AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "10");
			AddQuestUserData("Eng_Line_4_Intelligence_Curacao", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_4_Intelligence_Curacao");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "5";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.Waiting_time = "2";
            AddMoneyToCharacter(pchar, 110000);
			AddCharacterExpToSkill(pchar, "Sailing", 250);
			AddCharacterExpToSkill(pchar, "Sneak", 170);
			AddCharacterExpToSkill(pchar, "Grappling", 400);
			AddTitleNextRate(sti(NPChar.nation), 2);
			TakeItemFromCharacter(pchar, "letter_open");
			BackItemDescribe("letter_open");
			TakeNationLicence(HOLLAND);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("On dit que vous avez pénétré dans Willemstad et percé tous les secrets des Hollandais. Je crois que nous serons désormais mieux préparés à la guerre qui s'annonce...",ENGLAND, 5, 1);
        break;

        case "Step_4_4":
            dialog.text = "Le fait que vous ayez séjourné dans une prison hollandaise ne me dérange pas beaucoup. J'ai besoin d'informations, et vous n'en avez pas. Je suis déçu. Vous pourrez revenir plus tard, quand j'aurai réussi à obtenir les informations dont j'ai besoin.";
            link.l1 = "Bien sמr, monsieur. Pardon de ne pas avoir "+ GetSexPhrase("été en mesure","été en mesure") +" de vous aider.";
            link.l1.go = "exit";
            CloseQuestHeader("Eng_Line_4_Intelligence_Curacao");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "5";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.Waiting_time = "30";    // только через месяц следующий квест, т.к. Мэдифорд будет добывать инфу без участия ГГ
			AddCharacterExpToSkill(pchar, "Sailing", -150);
			AddCharacterExpToSkill(pchar, "Sneak", -200);
			AddCharacterExpToSkill(pchar, "Leadership", -150);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			//слухи
			AddSimpleRumour("On dit que vous avez eu l'occasion de visiter une prison hollandaise. Alors, comment sont les rats, là-bas ?", ENGLAND, 5, 1);
        break;

        case "Step_4_5":
            dialog.text = "Vous avez fait vos preuves en tant que guerrier, mais là oם il fallait de la ruse, vous n'avez pas été à la hauteur\n"+
                          "Je vais devoir obtenir les informations dont j'ai besoin par d'autres personnes, et quand je les aurai, j'aurai peut-être besoin de vous.";
            link.l1 = "Compris, monsieur. Pardon de ne pas avoir "+ GetSexPhrase("été en mesure","été en mesure") +" de vous aider.";
            link.l1.go = "exit";
            CloseQuestHeader("Eng_Line_4_Intelligence_Curacao");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "5";
            SaveCurrentQuestDateParam("questTemp");
			TakeNationLicence(HOLLAND);
            pchar.questTemp.Waiting_time = "30";    // только через месяц следующий квест, т.к. Мэдифорд будет добывать инфу без участия ГГ
			AddCharacterExpToSkill(pchar, "Sailing", -150);
			AddCharacterExpToSkill(pchar, "Sneak", -200);
			AddCharacterExpToSkill(pchar, "Fencing", -300);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			//слухи
			AddSimpleRumour("On dit que vous avez fait un beau carnage à Willemstad...", ENGLAND, 5, 1);
        break;

        case "Step_5_1":
            dialog.text = "Eh bien, nous savons maintenant que les Hollandais s'efforcent en hâte de fortifier leur colonie de la Jamaïque : Fort Orange. En principe, le fait qu'ils se soient installés de l'autre cכté de l'île ne me posait pas de problème, mais seulement jusqu'au début de la guerre commerciale\n"+
                          "Maintenant, il est de mon devoir de ruiner la colonie hollandaise en territoire anglais. Je vous confie cette tâche\n"+
                          "Tout le butin pris à Fort Orange est à vous. Passez à l'action.";
            link.l1 = "Très bien, monsieur.";
            link.l1.go = "exit";
         	pchar.GenQuestBox.Trinidad_Cave = true;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry3 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry4 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry5 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry7 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry8 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry10 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry14 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.jewelry17 = Rand(5)+1;
            pchar.GenQuestBox.FortOrange_townhall.box1.items.cirass3 = 1;
			//locations[FindLocation("FortOrange_townhall")].models.day.charactersPatch = "SmallResidence_BoxPatch";
			pchar.questTemp.State = "AttackFortOrange_GoToFort";
            SetQuestHeader("Eng_Line_5_AttackFortOrange");
            AddQuestRecord("Eng_Line_5_AttackFortOrange", "1");
            LAi_LocationFightDisable(&Locations[FindLocation("FortOrange_townhall")], false);
			
            Pchar.quest.AttackFortOrange_GoToFort.win_condition.l1 = "location";
            Pchar.quest.AttackFortOrange_GoToFort.win_condition.l1.location = "FortOrange_ExitTown";
            Pchar.quest.AttackFortOrange_GoToFort.win_condition = "AttackFortOrange_GoToFort";
			
			Pchar.quest.AttackFortOrange_GoToPort.win_condition.l1 = "location";
            Pchar.quest.AttackFortOrange_GoToPort.win_condition.l1.location = "FortOrange_port";
            Pchar.quest.AttackFortOrange_GoToPort.win_condition = "AttackFortOrange_GoToPort";
            SetLocationCapturedState("FortOrange_town", true);
        break;

        case "Step_5_2":
            dialog.text = "Oui, j'aimerais voir le fort juste après votre passage... Votre seule apparence en dit long : un vrai démon en chair et en os !\n"+
                          "Je respecte sincèrement les braves corsaires qui n'ont pas peur de faire couler des flots de sang... Gloire aux héros !\n"+
                          "J'espère vous voir plus souvent chez moi, "+ GetSexPhrase("mon ami","" + pchar.name + "") +".";
            link.l1 = "Sans aucun doute, monsieur, vous me verrez régulièrement... Je suis corsaire, et l'amitié de sir Thomas Madiford vaut cher. Et maintenant, permettez-moi de prendre congé : les affaires...";
            link.l1.go = "Step_5_3";
        break;

        case "Step_5_3":
            dialog.text = ""+ GetSexPhrase("Eh bien, je comprends... Apparemment, une demoiselle soupire quelque part en attendant votre venue... Haha","Eh bien, je comprends") +"\n"+
                          ""+ GetSexPhrase("Mon ami, je vous souhaite sincèrement du bon temps, avec la même ardeur, pour ainsi dire... Qui a du talent en a pour tout","" + pchar.name + ", je vous souhaite sincèrement du bon temps") +"\n"+
                          "Eh bien, je ne vous retiens pas. א plus tard...";
            link.l1 = "Au revoir, monsieur.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            CloseQuestHeader("Eng_Line_5_AttackFortOrange");
            pchar.questTemp.CurQuestNumber = "6";
            pchar.questTemp.Waiting_time = "30"; // По идее геймер должен испытывать угрызения совести после этого задания. Пусть поболтается просто так с месяц.
            // ==> вертаем разграбленному Форт Оранжу нормальную жизнь.
            SetLocationCapturedState("FortOrange_town", false);
            LAi_LocationFightDisable(&Locations[FindLocation("FortOrange_townhall")], true);
			//--> огонь и пламень убираем
			DeleteAttribute(&locations[FindLocation("FortOrange_town")], "hidden_effects");
			DeleteAttribute(&locations[FindLocation("FortOrange_ExitTown")], "hidden_effects");
			//<-- огонь и пламень
			//locations[FindLocation("FortOrange_townhall")].models.day.charactersPatch = "SmallResidence_patch";
			AddCharacterExpToSkill(pchar, "Pistol", 250);
			AddCharacterExpToSkill(pchar, "Leadership", 250);
			AddCharacterExpToSkill(pchar, "Repair", 350);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Ce que vous avez fait à Fort Orange est, vous savez, impressionnant... Ces pauvres Hollandais...", ENGLAND, 5, 1);
			
			//******Чёрный Ёж Sinistra******
			//Кристофер
			/*sld = GetCharacter(NPC_GenerateCharacter("BlackYosh_Kristofer", "sold_eng_2", "man", "man", 10, ENGLAND, -1, false));
			FantomMakeCoolFighter(sld, sti(pchar.rank), 15, 15, "blade7", "", 0);
			sld.name	= "Christopher";
			sld.lastname	= "Clayston";
			sld.Dialog.Filename = "Quest\PDM\Black_Yosh.c";
			LAi_SetSitType(sld);
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
			ChangeCharacterAddressGroup(sld,"PortRoyal_tavern","sit","sit3");*/
        break;

        case "Step_6_1":
            dialog.text = "Eh bien, c'est parfait. Il revient donc d'une expédition réussie contre les Espagnols, avec une cargaison d'acajou, d'argent et d'indigo dans ses cales\n"+
                          "Il doit vendre ses prises : qu'il vienne à Port Royal pour cela. Transmettez-lui personnellement mon autorisation de vendre la prise dans la colonie anglaise\n"+
                          "Et je veux que vous disiez cela à Williams en privé.";
            link.l1 = "Rien de plus facile.";
            link.l1.go = "exit";
            pchar.questTemp.State = "MorrisWillams_GoToMorrisBegin";
            SetQuestHeader("Eng_Line_6_MorrisWillams");
            AddQuestRecord("Eng_Line_6_MorrisWillams", "1");

			Pchar.quest.MorrisWillams_ShipToPort.win_condition.l1 = "location";
			Pchar.quest.MorrisWillams_ShipToPort.win_condition.l1.location = "Jamaica";
			Pchar.quest.MorrisWillams_ShipToPort.win_condition = "MorrisWillams_ShipToPort";
        break;

        case "Step_6_2":
            dialog.text = "J'ai déjà été informé. Voici 5 000 pour votre peine.";
            link.l1 = "דa ne m'a donné aucune peine, mais je ne refuserai pas l'argent.";
            link.l1.go = "exit";
            pchar.questTemp.State = "MorrisWillams_ModifordGood5000";
            AddMoneyToCharacter(pchar, 5000);
            AddTitleNextRate(sti(NPChar.nation), 0.5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "3");
            group_DeleteGroup("Willams_Group");

			Pchar.quest.MorrisWillams_ShipToPort.win_condition.l1 = "location";
			Pchar.quest.MorrisWillams_ShipToPort.win_condition.l1.location = Pchar.location.from_sea;
			Pchar.quest.MorrisWillams_ShipToPort.win_condition = "MorrisWillams_MeetWithManFromWillams";
        break;

        case "Step_6_3":
            dialog.text = "Quelles sont ces manières ? Qu'y a-t-il ?";
            link.l1 = "Vous avez confisqué la cargaison du corsaire Morris Williams ! Et c'est moi qui l'ai "+ GetSexPhrase("invité","invité") +" à Port Royal !";
            link.l1.go = "Step_6_4";
        break;

        case "Step_6_4":
            dialog.text = "Ce n'est pas vous, c'est moi qui l'ai invité à Port Royal. Vous n'avez servi que de messager, rien de plus. Quant à la cargaison, elle a été restituée à son propriétaire espagnol.";
            link.l1 = "Je n'en crois pas mes oreilles ! Pourquoi ?!!";
            link.l1.go = "Step_6_5";
        break;

        case "Step_6_5":
            dialog.text = "Les relations entre l'Angleterre et l'Espagne s'améliorent. C'est un geste de bonne volonté\n"+
                          ""+ GetSexPhrase("Mon ami","" + pchar.name + "") +", ne vous mêlez pas de politique, vous n'y pouvez rien changer. Adieu.";
            link.l1 = "Les mots me manquent... Eh bien, adieu, monsieur.";
            link.l1.go = "exit";
            pchar.questTemp.State = "MorrisWillams_ModifordPolitic";
            AddQuestRecord("Eng_Line_6_MorrisWillams", "5");
            QuestSetCurrentNode("Morris_Willams", "First time");
			//слухи
			AddSimpleRumour("Capitaine, vous avez vraiment piégé ce pauvre Williams ?! Personne ne vous croyait capable d'une chose pareille...", ENGLAND, 5, 1);
        break;

        case "Step_6_6":
            dialog.text = "Que s'est-il passé, "+ GetSexPhrase("mon ami","" + pchar.name + "") +" ?";
            link.l1 = "Morris Williams croupit en prison, et c'est ma faute. J'estime absolument nécessaire de le faire libérer.";
            link.l1.go = "Step_6_7";
        break;

        case "Step_6_7":
            dialog.text = "Eh bien, je vois que vous avez l'âme noble. Moi non plus, je n'aime pas garder un bon corsaire en détention, mais je suis obligé de le faire. La loi, c'est la loi\n"+
                          "Je vous conseille de vous adresser à l'usurier d'ici : c'est pour une dette impayée envers lui que Morris est en prison.";
            link.l1 = "Merci du conseil.";
            link.l1.go = "exit";
            pchar.questTemp.State = "MorrisWillams_ArrestedToUsurer";
            AddQuestRecord("Eng_Line_6_MorrisWillams", "17");
        break;

        case "Step_7_1":
            dialog.text = "Le fait est que les corsaires anglais ont cessé d'entrer au port avec les marchandises prises aux Espagnols. Ils ne viennent plus que pour des réparations, avec le minimum d'argent nécessaire.\n"+
                          "J'espère que je n'ai pas besoin de vous expliquer combien l'Angleterre perd chaque mois faute de percevoir la taxe de dix pour cent sur la valeur des cargaisons saisies, et combien perdent les marchands jamaïcains !!!\n"+
                          "Les corsaires cachent maintenant leurs cargaisons dans des endroits isolés des îles, ou essaient de se traîner jusqu'à Portsmouth pour y vendre leurs marchandises, ou encore écoulent les cargaisons capturées par des intermédiaires français à Tortuga.\n"+
                          "Autrement dit, la situation est claire comme le jour : les expéditions contre les Espagnols continuent, et nous n'en tirons RIEN !\n"+
                          "Le Conseil de la Jamaïque a décidé de reprendre la délivrance des lettres de marque à nos corsaires. Votre mission est très délicate et consiste en ceci : j'ai appris que sept corsaires célèbres ont caché de l'or dans des grottes un peu partout dans la région.\n"+
                          "J'ai appris les emplacements approximatifs des trésors :\n"+
                          "1. Thomas Wheatson : près de Carthagène.\n"+
                          "2. Adrian Swart : sur l'île de la Trinité.\n"+
                          "3. Le capitaine Gay : aux îles Turques.\n"+
                          "4. Le capitaine Cooper : sur l'île de la Dominique.\n"+
                          "5. George Brennenham : aux Caïmans.\n"+
                          "6. Le capitaine Goodley : à Cuba.\n"+
                          "7. Abraham Blauvelt : à la Guadeloupe.\n"+
                          "Trouvez tous ces trésors et apportez-les-moi. Je crois superflu de vous dire que la mission est strictement secrète : c'est dans votre intérêt...";
            link.l1 = "Je comprends. Je crois pouvoir régler cette question, monsieur.";
            link.l1.go = "Step_7_3";
            link.l2 = "Monsieur, je ne comprends pas bien la nature de la mission. Les trésors des corsaires, ce sont leurs affaires. Je n'ai rien à voir là-dedans...";
            link.l2.go = "Step_7_2";
        break;

        case "Step_7_2":
            dialog.text = "Votre comportement me laisse très perplexe...";
            link.l1 = "Monsieur, je suis désolé, mais je ne peux pas vous aider.";
            link.l1.go = "exit";
            ChangeCharacterReputation(pchar, 3);
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "8";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.Waiting_time = "35";
            AddCharacterExpToSkill(pchar, "Leadership", -500);
            AddCharacterExpToSkill(pchar, "Cannons", -300);
            AddCharacterExpToSkill(pchar, "Sneak", -350);
			//слухи
			AddSimpleRumour("Vous savez, le capitaine " + GetFullName(pchar) + " "+ GetSexPhrase("a refusé","a refusé") +" d'exécuter la mission de Madiford : chercher les caches des pirates...", ENGLAND, 5, 1);
        break;

        case "Step_7_3":
            dialog.text = "D'après mes estimations, il y a 2 100 lingots d'or dans les sept trésors ! Apportez-moi tout ça...";
            link.l1 = "Bien, monsieur. Je commence immédiatement.";
            link.l1.go = "exit";
            ChangeCharacterReputation(pchar, -4);
            pchar.questTemp.State = "SevenTreasures_GoOn";
            pchar.questTemp.GoldQtyGaveModiford = "0"; // кол-во сданное Мэдифорду
            pchar.questTemp.GoldQtyForSeek = "2100"; // кол-во, которое ещё нужно разыскать
            SaveCurrentQuestDateParam("questTemp");
            SetQuestHeader("Eng_Line_7_SevenTresures");
            AddQuestRecord("Eng_Line_7_SevenTresures", "1");
            // ==> клад Томаса Уитсона в пещере близ Картахены.
         	pchar.GenQuestBox.Cartahena_Cave = true;
            pchar.GenQuestBox.Cartahena_Cave.box1.items.jewelry5 = 300;
			pchar.GenQuestBox.Cartahena_Cave.box1.items.jewelry1 = 110;
            pchar.GenQuestBox.Cartahena_Cave.box1.items.statue1 = 1;
            pchar.GenQuestBox.Cartahena_Cave.box1.items.indian17 = 1;
            pchar.GenQuestBox.Cartahena_Cave.box1.items.pistol2 = 1;
			pchar.GenQuestBox.Cartahena_Cave.box1.items.icollection = 1;
            // ==> клад Адриана Сварта на Тринидаде.
         	pchar.GenQuestBox.Trinidad_Grot = true;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.jewelry5 = 450;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.blade5 = 1;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.potion2 = 10;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.potionwine = 3;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.jewelry2 = 90;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.indian6 = 1;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.indian11 = 1;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.indian15 = 1;
            pchar.GenQuestBox.Trinidad_Grot.box1.items.indian12 = 1;
			pchar.GenQuestBox.Trinidad_Grot.box1.items.chest = 1;
            // ==> клад Капитана Гея в гроте на Терксе.
         	pchar.GenQuestBox.Terks_Grot = true;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry5 = 250;
			pchar.GenQuestBox.Terks_Grot.box1.items.jewelry3 = 85;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade10 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.potion2 = 5;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian18 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry7 = 5;
            // ==> клад Капитана Купера на Домнинике.
         	pchar.GenQuestBox.Dominica_Grot = true;
            pchar.GenQuestBox.Dominica_Grot.box1.items.jewelry5 = 150;
			pchar.GenQuestBox.Dominica_Grot.box1.items.jewelry4 = 75;
            pchar.GenQuestBox.Dominica_Grot.box1.items.pistol10 = 1;
            pchar.GenQuestBox.Dominica_Grot.box1.items.potion1 = 5;
            pchar.GenQuestBox.Dominica_Grot.box1.items.potionrum = 2;
			pchar.GenQuestBox.Dominica_Grot.box1.items.chest = 1;
            // ==> клад Джоржа Бренинхема на Каймане.
         	pchar.GenQuestBox.Caiman_Grot = true;
            pchar.GenQuestBox.Caiman_Grot.box1.items.jewelry5 = 350;
			pchar.GenQuestBox.Caiman_Grot.box1.items.jewelry17 = 250;
            pchar.GenQuestBox.Caiman_Grot.box1.items.blade2 = 1;
            pchar.GenQuestBox.Caiman_Grot.box1.items.potion5 = 10;
            pchar.GenQuestBox.Caiman_Grot.box1.items.indian18 = 1;
            // ==> клад капитана Гудли на Кубе.
         	pchar.GenQuestBox.Cuba_Grot = true;
            pchar.GenQuestBox.Cuba_Grot.box1.items.jewelry5 = 350;
			pchar.GenQuestBox.Cuba_Grot.box1.items.jewelry17 = 150;
            pchar.GenQuestBox.Cuba_Grot.box1.items.topor2 = 1;
            pchar.GenQuestBox.Cuba_Grot.box1.items.potion2 = 5;
            pchar.GenQuestBox.Cuba_Grot.box1.items.indian10 = 1;
			pchar.GenQuestBox.Cuba_Grot.box1.items.chest = 3;
            // ==> клад Абрахама Блаувельта в катакомбах Гаити рядом с городом.
         	pchar.GenQuestBox.Guadeloupe_Cave = true;
            pchar.GenQuestBox.Guadeloupe_Cave.box1.items.jewelry5 = 250;
			pchar.GenQuestBox.Guadeloupe_Cave.box1.items.jewelry17= 100;
            pchar.GenQuestBox.Guadeloupe_Cave.box1.items.jewelry14= 10;
            pchar.GenQuestBox.Guadeloupe_Cave.box1.items.potion3 = 5;
            pchar.GenQuestBox.Guadeloupe_Cave.box1.items.mineral8 = 1;
			pchar.GenQuestBox.Guadeloupe_Cave.box4.items.jewelry5 = 250;
			pchar.GenQuestBox.Guadeloupe_Cave.box4.items.jewelry2 = 50;
            pchar.GenQuestBox.Guadeloupe_Cave.box4.items.jewelry14= 10;
            pchar.GenQuestBox.Guadeloupe_Cave.box4.items.potion3 = 5;
            pchar.GenQuestBox.Guadeloupe_Cave.box4.items.mineral8 = 1;
        break;

        case "Step_7_4":
            dialog.text = "Voyons voir...";
            link.l1 = "Eh bien, monsieur, j'ai actuellement " + pchar.items.jewelry5 + " lingots d'or. Je suis prêt à vous les remettre.";
            link.l1.go = "Step_7_5";
            link.l2 = "Monsieur, j'ai " + pchar.items.jewelry5 + " lingots d'or sur moi. Mais cet or n'est pas devenu le mien grâce à la mission que vous m'avez confiée. Je le garde donc pour moi.";
            link.l2.go = "Step_7_7";
        break;

        case "Step_7_5":
            if ((sti(pchar.questTemp.GoldQtyGaveModiford) + sti(pchar.items.jewelry5)) <= 2100)
            {
                pchar.questTemp.GoldQtyGaveModiford = sti(pchar.questTemp.GoldQtyGaveModiford) + sti(pchar.items.jewelry5);
                pchar.questTemp.GoldQtyForSeek = 2100 - sti(pchar.questTemp.GoldQtyGaveModiford);
                if (pchar.questTemp.GoldQtyForSeek != "0")
                {
                    dialog.text = "Très bien, j'accepte " + pchar.items.jewelry5 + " lingots d'or de votre part. Au total, vous m'avez remis " + pchar.questTemp.GoldQtyGaveModiford + " lingots d'or. Il vous reste donc à trouver et à m'apporter " + pchar.questTemp.GoldQtyForSeek + " lingots de plus.";
                    link.l1 = "Je comprends, monsieur. Les recherches continuent.";
                    link.l1.go = "exit";
                    AddQuestRecord("Eng_Line_7_SevenTresures", "3");
                    AddQuestUserData("Eng_Line_7_SevenTresures", "GoldQtyGaveModiford", pchar.questTemp.GoldQtyGaveModiford);
                    AddQuestUserData("Eng_Line_7_SevenTresures", "GoldQtyForSeek", pchar.questTemp.GoldQtyForSeek);
                }
                else
                {
                    dialog.text = "Vous avez accompli la mission. Vous m'avez apporté et remis, comme je m'y attendais, 2 100 lingots d'or. Vos 10 pour cent font 70 mille.";
                    link.l1 = "Merci, monsieur.";
                    link.l1.go = "Step_7_6";
                }
                DeleteAttribute(pchar, "items.jewelry5");
            }
            else
            {
                pchar.questTemp.GoldQtyForSeek = sti(pchar.questTemp.GoldQtyGaveModiford) + sti(pchar.items.jewelry5) - 2100);
                dialog.text = "דa alors, vous avez trouvé plus d'or que je ne le pensais ! Vous avez maintenant " + pchar.items.jewelry5 + " lingots d'or. Auparavant, vous m'en aviez remis " + pchar.questTemp.GoldQtyGaveModiford + " lingots d'or. Le plan est donc dépassé de " + pchar.questTemp.GoldQtyForSeek + " lingots.";
                link.l1 = "Monsieur, le « dépassement du plan », c'est mon or personnel, il n'a rien à voir avec la mission accomplie.";
                link.l1.go = "Step_7_6";
                pchar.items.jewelry5 = pchar.questTemp.GoldQtyForSeek;
            }
        break;

        case "Step_7_6":
            dialog.text = "Eh bien, je suis très, très content de vous. Notre coopération m'est très agréable. Je serai toujours heureux de vous voir chez moi.";
            link.l1 = "Merci, monsieur. Je passerai vous voir régulièrement.";
            link.l1.go = "exit";
            AddMoneyToCharacter(pchar, 70000);
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "2";
            AddQuestRecord("Eng_Line_7_SevenTresures", "2");
            CloseQuestHeader("Eng_Line_7_SevenTresures");
            DeleteQuestHeader("Eng_Line_7_Second");
            DeleteAttribute(pchar, "questTemp.GoldQtyGaveModiford");
            DeleteAttribute(pchar, "questTemp.GoldQtyForSeek");
			AddCharacterExpToSkill(pchar, "Repair", 500);
			AddCharacterExpToSkill(pchar, "Commerce", 550);
			AddCharacterExpToSkill(pchar, "Defence", 450);
			AddCharacterExpToSkill(pchar, "Leadership", 400);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Il court de vagues rumeurs selon lesquelles un certain capitaine aurait aidé Madiford à dérober les trésors de quelques pirates. Mais c'est la faute de Madiford lui-même si les corsaires se sont mis à cacher leur butin dans des cavernes et des grottes...", ENGLAND, 5, 1);
        break;

        case "Step_7_7":
            dialog.text = RandPhraseSimple("Et alors pourquoi diable l'agitez-vous sous mes yeux ?", "Désormais, je vous prie de ne parler que de MON or.");
            link.l1 = "Monsieur, vous m'avez demandé, et je vous ai "+ GetSexPhrase("répondu","répondu") +" franchement. Veuillez m'excuser.";
            link.l1.go = "exit";
        break;

        case "Step_7_10":
			dialog.text = "Hum, je ne vous recommande pas d'exprimer vos pensées sur ce ton ici. Vous m'avez déçu et je vous inflige une amende ! Je ne vous retiens plus, vous pouvez disposer.";
            link.l1 = "Pardon de vous avoir "+ GetSexPhrase("causé","causé") +" ce désagrément, monsieur.";
            link.l1.go = "exit";
			DeleteAttribute(pchar, "GenQuestBox.Cartahena_Cave");
			DeleteAttribute(pchar, "GenQuestBox.Trinidad_Grot");
			DeleteAttribute(pchar, "GenQuestBox.Terks_Grot");
			DeleteAttribute(pchar, "GenQuestBox.Dominica_Grot");
			DeleteAttribute(pchar, "GenQuestBox.Caiman_Grot");
			DeleteAttribute(pchar, "GenQuestBox.Cuba_Grot");
			DeleteAttribute(pchar, "GenQuestBox.Guadeloupe_Cave");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "20";
            AddQuestRecord("Eng_Line_7_SevenTresures", "4");
			AddQuestUserData("Eng_Line_7_SevenTresures", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_7_SevenTresures");
            DeleteQuestHeader("Eng_Line_7_Second");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			ChangeCharacterReputation(pchar, -5);
			AddMoneyToCharacter(pchar, -150000);
        break;

        case "Step_8_1":
            dialog.text = "Exactement ! Eh bien, tant mieux\n"+
                          "Mansfield a préparé pour nous une grosse quantité de lingots d'or. Je dois faire venir cet or à Port Royal. Je ne peux confier cette affaire qu'à vous.";
            link.l1 = "Bien, monsieur. Suis-je limité dans le temps ?";
            link.l1.go = "Step_8_2";
        break;

        case "Step_8_2":
            dialog.text = "Non, ce n'est pas très pressé. Mais il ne faut pas traîner non plus.";
            link.l1 = "Compris. Dès que je serai prêt, je prendrai immédiatement la mer.";
            link.l1.go = "exit";
            pchar.questTemp.State = "ToMansfield_GoOn";
            SetQuestHeader("Eng_Line_8_ToMansfield");
            AddQuestRecord("Eng_Line_8_ToMansfield", "1");
            Pchar.quest.ToMansfield_IntoTheTown.win_condition.l1 = "location";
            Pchar.quest.ToMansfield_IntoTheTown.win_condition.l1.location = "LaVega_town";
            Pchar.quest.ToMansfield_IntoTheTown.win_condition = "ToMansfield_IntoTheTown";
            SetLocationCapturedState("LaVega_town", true);
			//--> огонь и пламень
			locations[FindLocation("LaVega_town")].hidden_effects = true;
			locations[FindLocation("LaVega_ExitTown")].hidden_effects = true;
			//<-- огонь и пламень
            Log_QuestInfo("Le fort des boucaniers est vide et en flammes.");
        break;

        case "Step_8_3":
            dialog.text = "Bon sang !!! Avez-vous réussi à éclaircir la situation d'une façon ou d'une autre ?";
            link.l1 = "Il semble que les Espagnols soient partis vers Santiago. Je vais essayer de les intercepter.";
            link.l1.go = "Step_8_4";
        break;

        case "Step_8_4":
            dialog.text = "Très bien. Je vous demande de tout faire pour les retrouver.";
            link.l1 = "Compris, monsieur.";
            link.l1.go = "exit";
            npchar.TempQuest.KnowAboutModiford = 1;
        break;

        case "Step_8_5":
            dialog.text = "Je dois y réfléchir. Revenez me voir dans dix jours.";
            link.l1 = "Bien, monsieur.";
            link.l1.go = "exit";
            TakeItemFromCharacter(pchar, "letter_open");
			BackItemDescribe("letter_open");
            DeleteAttribute(npchar, "TempQuest.KnowAboutModiford");
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "9";
            pchar.questTemp.Waiting_time = "10";
            CloseQuestHeader("Eng_Line_8_ToMansfield");
            SetLocationCapturedState("LaVega_town", false);
			//--> огонь и пламень убираем
			DeleteAttribute(&locations[FindLocation("LaVega_town")], "hidden_effects");
			DeleteAttribute(&locations[FindLocation("LaVega_ExitTown")], "hidden_effects");
			//<-- огонь и пламень
            // ==> Мэнсфилд убит, теперь он будет Алистером Гудом.
            sld = characterFromID("Edward Mansfield");
            LAi_SetStayTypeNoGroup(sld);
            sld.model = "bocman";
        	sld.name 	= "Alistair";
        	sld.lastname = "Gud";
            SendMessage(sld, "lss", MSG_CHARACTER_SETMODEL, sld.model, sld.model.animation);
            FaceMaker(sld);
            QuestSetCurrentNode("Edward Mansfield", "No_Mansfield_first_time");
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Edward Mansfield")], "LaVega_townhall", "sit", "sit1");
			AddCharacterExpToSkill(pchar, "Fortune", 500);
			AddCharacterExpToSkill(pchar, "Sailing", 550);
			AddCharacterExpToSkill(pchar, "FencingLight", 450);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 400);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Le bruit court que la colonie de boucaniers d'Hispaniola a été ravagée par les Espagnols...", ENGLAND, 5, 1);
		break;

        case "Step_9_1":
            pchar.questTemp.State = "AttackSantiago_GoOn";
            if (!CheckAttribute(npchar, "TempQuest.KindResult")) // письмо не получено, но в курсе нападения испанцев
            {
                dialog.text = "J'ai pris certaines mesures et j'ai réussi à établir exactement qui était derrière l'attaque espagnole contre La Vega.";
                link.l1 = "Et qui est-ce ?";
                link.l1.go = "Step_9_2";
            }
            else if (npchar.TempQuest.KindResult == 2) // признак результата завершения квеста, 2 == вообще не в курсе, что произошло
            {
                dialog.text = "Je tiens à vous informer que le massacre de La Vega est le résultat d'une attaque espagnole.";
                link.l1 = "Je vois, monsieur.";
                link.l1.go = "Step_9_2";
            }
            else // признак результата завершения квеста, 1 == было захвачено письмо
            {
                dialog.text = "Grâce à la lettre que vous avez trouvée sur le galion espagnol, nous savons maintenant clairement qui est derrière l'attaque espagnole contre La Vega.";
                link.l1 = "Oui, monsieur. La lettre, je l'ai "+ GetSexPhrase("lue","lue") +".";
                link.l1.go = "Step_9_2";
            }
            Log_QuestInfo("Mission reçue.");
            DeleteAttribute(npchar, "TempQuest.KindResult");
			characters[GetCharacterIndex("Santiago_Mayor")].dialog.captureNode = "EL9_SantiagoAttack"; //капитулянтская нода мэра
        break;

        case "Step_9_2":
            dialog.text = "Cette attaque a été organisée par le gouverneur de Santiago, José Sancho Jimenez. Pour mener cette opération, il a fait appel à Manoel Rivero Pardal, le seul pirate espagnol de ces eaux.";
            link.l1 = "Que dois-je faire ?";
            link.l1.go = "Step_9_3";
        break;

        case "Step_9_3":
            dialog.text = "Vous devez attaquer Santiago et me ramener le gouverneur José Sancho Jimenez. J'ai besoin de Jimenez ; la ville est à vous.";
            link.l1 = "Je comprends, monsieur.";
            link.l1.go = "exit";
            SetQuestHeader("Eng_Line_9_AttackSantiago");
            AddQuestRecord("Eng_Line_9_AttackSantiago", "1");
        break;

        case "Step_9_4":
            dialog.text = "Bon sang, vous êtes vraiment indispensable, " + pchar.name + ". Mansfield a été glorieusement vengé !";
            link.l1 = "Que dois-je faire de Jimenez ?";
            link.l1.go = "Step_9_5";
            QuestSetCurrentNode("Santiago_Mayor", "First time");
        break;

        case "Step_9_5":
            dialog.text = "Remettez-le à mon officier de service. Je m'en occuperai demain ; aujourd'hui, je suis de trop bonne humeur pour ça\n"+
                          "Je pense que vous avez besoin de vous reposer et de vous remettre d'aplomb après de tels exploits. Je n'ose pas vous retenir, venez me voir quand vous voulez\n"+
                          "Oui, et encore une chose... Allez voir Morgan, je pense qu'il sera très content d'apprendre qu'Edward Mansfield a été vengé si vite et si efficacement. Mansfield était comme un père pour Morgan...";
            link.l1 = "Bien, monsieur. Je passerai le voir sans faute.";
            link.l1.go = "exit";
            QuestSetCurrentNode("Henry Morgan", "Give_blade");
            sld = characterFromID("Himenes");
            RemovePassenger(pchar, sld);
    	    sld.LifeDay = 1; // уберём нпс на след.день.
    	    SaveCurrentNpcQuestDateParam(sld, "LifeTimeCreate");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "10";
            pchar.questTemp.Waiting_time = "20";
            CloseQuestHeader("Eng_Line_9_AttackSantiago");
			AddCharacterExpToSkill(pchar, "Repair", 550);
			AddCharacterExpToSkill(pchar, "Cannons", 760);
			AddCharacterExpToSkill(pchar, "Defence", 450);
			AddCharacterExpToSkill(pchar, "Pistol", 300);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Capitaine, tout le monde parle du gouverneur espagnol que vous avez ramené captif à Port Royal ! Vous êtes "+ GetSexPhrase("un vrai héros","une vraie héroïne") +", capitaine...", ENGLAND, 5, 1);
        break;

        case "Step_10_1":
            dialog.text = "Les Espagnols ont décidé d'en finir avec nous. Rassembler un si grand nombre de vaisseaux de ligne ici, c'est tout simplement incroyable ! Mais nous en sommes venus à bout !";
            link.l1 = "Oui, monsieur. Même si ce fut extrêmement difficile, les habitants peuvent respirer. Et les Espagnols, je suppose, auront du mal à se remettre d'un tel coup...";
            link.l1.go = "Step_10_2";
        break;

        case "Step_10_2":
            dialog.text = "Je suis d'accord avec vous, "+ GetSexPhrase("mon ami","" + pchar.name + "") +". Je pense que la somme de 80 000 suffira à remettre vos navires en état et à recruter un nouvel équipage. L'Angleterre a besoin de vous, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", et l'Angleterre ne vous oubliera pas !"+
                          "Je suis désolé, mais en ce moment, je dois réfléchir à des mesures de représailles... Revenez me voir dans une semaine, je vous prie.";
            link.l1 = "Bien, je tâcherai d'être à l'heure, monsieur.";
            link.l1.go = "exit";
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "PortRoyal_houseS1", "sit", "sit2");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "11";
            pchar.questTemp.Waiting_time = "7";
            CloseQuestHeader("Eng_Line_10_SpanishAttack");
			AddCharacterExpToSkill(pchar, "Repair", 600);
			AddCharacterExpToSkill(pchar, "Leadership", 550);
			AddCharacterExpToSkill(pchar, "Commerce", 600);
			AddCharacterExpToSkill(pchar, "Accuracy", 400);
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddMoneyToCharacter(pchar, 80000);
			//слухи
			AddSimpleRumour("Capitaine, vous venez de nous sauver tous. Les habitants de la ville vous sont unanimement reconnaissants de votre exploit.", ENGLAND, 10, 6);
        break;

        case "Step_11_1":
            dialog.text = "La réponse à l'attaque espagnole contre Port Royal sera notre attaque contre les villes espagnoles.\n"+
                          "Il y a deux villes espagnoles sur le Continent, près de la Trinité : Cumaná et Caracas. Prenez ces villes et faites prêter serment à leur population envers Sa Majesté Charles II Stuart.\n"+
                          "Facilitez la nomination d'une nouvelle administration afin de normaliser la gestion des villes et de percevoir au plus vite les impכts et les droits.";
            link.l1 = "Je comprends, monsieur. Je commencerai dès que je serai prêt.";
            link.l1.go = "exit";
            SetQuestHeader("Eng_Line_11_OccupyMein");
            AddQuestRecord("Eng_Line_11_OccupyMein", "1");
            pchar.questTemp.State = "OccupyMein_GoOn";
			characters[GetCharacterIndex("Cumana_Mayor")].dialog.captureNode = "EngLine11Quest_OccupyMein"; //капитулянтская нода мэра
			characters[GetCharacterIndex("Caracas_Mayor")].dialog.captureNode = "EngLine11Quest_OccupyMein"; //капитулянтская нода мэра
        break;

        case "Step_11_2":
            dialog.text = "Parfait, "+ GetSexPhrase("mon ami","" + pchar.name + "") +". C'est tout simplement formidable ! Le butin pris sur l'île vous revient de droit !"+
                          " Je vous prie de vous présenter à ma résidence dans un mois. J'aurai de nouveau une affaire pour vous.";
            link.l1 = "Bien, monsieur.";
            link.l1.go = "exit";
            DeleteAttribute(pchar, "questTemp.Q11_Cumana");
            DeleteAttribute(pchar, "questTemp.Q11_Caracas");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "12";
            pchar.questTemp.Waiting_time = "30";
            CloseQuestHeader("Eng_Line_11_OccupyMein");
			AddCharacterExpToSkill(pchar, "Repair", 1000);
			AddCharacterExpToSkill(pchar, "Commerce", 1600);
			AddCharacterExpToSkill(pchar, "Accuracy", 1000);
			AddCharacterExpToSkill(pchar, "Defence", 1100);
			AddCharacterExpToSkill(pchar, "Cannons", 1300);
			AddCharacterExpToSkill(pchar, "Sailing", 1200);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Capitaine, on dirait que vous allez bientכt hériter d'un surnom : " + pchar.name + ""+ GetSexPhrase(" le Conquérant"," la Conquérante") +"", ENGLAND, 5, 1);
        break;

        case "Step_12_1":
            dialog.text = "Il se passe quelque chose d'inhabituel à St. John's. Je ne reçois pas du gouverneur de la ville les rapports de situation requis\n"+
                          "Vous avez toute ma confiance, je vous demande donc de vous rendre à la résidence de St. John's et d'éclaircir la situation auprès du gouverneur.";
            link.l1 = "Bien, monsieur. Je ne pense pas qu'il y ait de problème, mais je vais tout éclaircir.";
            link.l1.go = "exit";
            SetQuestHeader("Eng_Line_12_ColonelLinch");
            AddQuestRecord("Eng_Line_12_ColonelLinch", "1");
            pchar.questTemp.State = "ColonelLinch_GoToKingstown";

            Pchar.quest.ColonelLinch_IntoTheResidence.win_condition.l1 = "location";
            Pchar.quest.ColonelLinch_IntoTheResidence.win_condition.l1.location = "SentJons_townhall";
            Pchar.quest.ColonelLinch_IntoTheResidence.win_condition = "ColonelLinch_IntoTheResidence";
        break;

        case "Step_12_2":
            dialog.text = "Hum... Et alors ?";
            link.l1 = "Sur ordre du gouvernement anglais, vous êtes en état d'arrestation, monsieur...";
            link.l1.go = "Step_12_3";
        break;

        case "Step_12_3":
            dialog.text = "Pas si vite... Officier, à moi !!!";
            link.l1 = "Bon sang !!!";
            link.l1.go = "Step_12_4";
        break;

        case "Step_12_4":
            pchar.nation = PIRATE;
            LAi_SetImmortal(npchar, true);
            LAi_SetImmortal(characterFromID("PortRoyal_Mayor"), true);
            bDisableFastReload = true; // закрыть переходы.
            chrDisableReloadToLocation = true; // закрыть выход из локации.
            LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
            LAi_NoRebirthEnable(npchar);
            //LAi_SetActorType(npchar);
            //LAi_ActorAfraid(npchar, pchar, false);

            LAi_group_Register("EnemyFight");
           	float locx, locy, locz;
            GetCharacterPos(pchar, &locx, &locy, &locz);
			//поставим стражников во враждебную группу
			int num = FindNearCharacters(pchar, 20.0, -1.0, -1.0, 0.01, true, true);
			if(num > 0)
			{
				for(int i = 0; i < num; i++)
				{
					int idx = sti(chrFindNearCharacters[i].index);
					sld = &Characters[idx];
					if (sld.chr_ai.type == "guardian")
					{
						LAi_NoRebirthEnable(sld);
						LAi_CharacterReincarnation(sld, false, false);
						LAi_group_MoveCharacter(sld, "EnemyFight");
					}
				}
			}
			//добавим солдат для хардокора
            string SModel;
            for (i=1; i<=3; i++)
            {
                SModel = "off_eng_"+i;
                if (i == 3) SModel = "sold_eng_3";
                sld = GetCharacter(NPC_GenerateCharacter("EngSolder"+i, SModel, "man", "man", 30, ENGLAND, 0, true));
                FantomMakeCoolFighter(sld, 30, 100, 100, "topor1", "pistol3", 250);
            	LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, "EnemyFight");
               	ChangeCharacterAddressGroup(sld, "PortRoyal_townhall", "goto", LAi_FindFarLocator("goto", locx, locy, locz));
            }
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "ColonelLinch_AfterFight");
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
			//слухи
			AddSimpleRumour("Eh bien, il s'en passe des choses ici !! Le gouverneur Madiford a été arrêté et jeté en prison par l'un de ses propres corsaires ! דa alors !..", ENGLAND, 5, 1);
        break;

        case "Step_12_5":
            dialog.text = "Ne vous étonnez pas ! Mais prenons les choses dans l'ordre\n"+
                          "J'ai le grand plaisir de vous informer que vos services rendus à la patrie ont été dמment appréciés\n"+
                          "J'ai l'honneur de vous annoncer votre adoubement. Désormais, votre nom devra toujours être précédé du titre : "+ GetSexPhrase("sir","lady") +"\n"+
                          "De plus, l'enquête sur les activités de Madiford a mis au jour son énorme fortune. Une partie de cet argent vous revient, "+ GetSexPhrase("sir","lady") + ". Cela fait trois cent mille. Veuillez les recevoir.";
            link.l1 = "Merci. J'espère pouvoir continuer à être utile à Sa Majesté, comme toujours.";
            link.l1.go = "Step_12_6";
        break;

        case "Step_12_6":
            dialog.text = "J'y compte bien.\n"+
                          "J'espère qu'avec votre participation, "+ GetSexPhrase("sir","lady") +", les Caraïbes deviendront plus anglaises. Et n'oubliez pas que l'Espagne n'est pas notre ennemie. Pour l'instant, du moins...";
            link.l1 = "Je comprends, monsieur. Je ferai de mon mieux pour la prospérité des colonies anglaises des Caraïbes.";
            link.l1.go = "exit";
			if (PChar.sex == "woman")
			{
			pchar.name = "Lady " + pchar.name;
			}
			else
			{
			pchar.name = "Sir " + pchar.name;
			}
            AddMoneyToCharacter(pchar, 300000);
            AddTitleNextRate(sti(NPChar.nation), 4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
            SetNationRelationBoth(SPAIN, ENGLAND, RELATION_NEUTRAL);
            DeleteAttribute(pchar, "questTemp.Waiting_time");
            pchar.questTemp.State = "EndOfQuestLine";
			bWorldAlivePause   = false; // Конец линейки
			UnlockAchievement("Nation_quest_E", 3);
        break;
		
		case "BlackYosh_1":
            dialog.text = "Oui, c'est vrai. Je suppose que vous vouliez commander l'une de ces frégates ? Hélas, tous les postes ont déjà été attribués.";
            link.l1 = "C'est terrible, monsieur. Mais est-il vrai que ces frégates sont déjà très vieilles et totalement inaptes aux opérations militaires ?";
            link.l1.go = "BlackYosh_2";
        break;
		
		case "BlackYosh_2":
            dialog.text = "Qui a lancé une rumeur aussi stupide ? Parlez immédiatement, ou je vous fais pendre à la première vergue venue !";
            link.l1 = "Pardon, monsieur, mais pourquoi ma simple question a-t-elle provoqué une telle réaction ?";
            link.l1.go = "BlackYosh_3";
        break;
		
		case "BlackYosh_3":
            dialog.text = "Un vrai corsaire anglais ne doutera JAMAIS de l'état de préparation de la flotte. Vous jetez une ombre sur moi et sur ma compétence. Je vous le redemande : qui vous a dit ça ?";
            link.l1 = "J'ai rencontré dans une taverne un homme qui disait avoir été récemment affecté à l'une des frégates. Il se plaignait de l'état du navire. Il m'a semblé complètement ivre, mais ses paroles sonnaient vrai.";
            link.l1.go = "BlackYosh_4";
        break;
		
		case "BlackYosh_4":
            dialog.text = "Capitaine, si vous buvez dans les sales tavernes du coin, vous risquez d'entendre bien des sornettes. C'est une honte. Vous buvez dans une taverne avec d'autres officiers, puis vous venez ici répéter de fausses rumeurs. Quand je trouverai votre colporteur de ragots, je le ferai fouetter comme un simple matelot !";
            link.l1 = "Mais, monsieur...";
            link.l1.go = "BlackYosh_5_VREMENAYA_ZAGLUSHKA";	//Пока квест не будет сделан, дальше пройти нельзя. Будет переход на временную заглушку.
			//link.l1.go = "BlackYosh_5";
        break;
		
		case "BlackYosh_5_VREMENAYA_ZAGLUSHKA":	//Временная заглушка
            dialog.text = "Maintenant, laissez-moi, je dois travailler !";
			link.l1 = "Oui, monsieur, je m'en vais.";
            link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.BlackYosh_1");
        break;
		
		case "BlackYosh_5":
            dialog.text = "Bon, puisque vous êtes là, il me faut justement un capitaine pour escorter l'une de ces frégates en lieu sמr.";
            link.l1 = "Oui, monsieur, je suis prêt à me charger de cette affaire. Oם dois-je escorter la frégate ?";
            link.l1.go = "BlackYosh_6";
			link.l2 = "Monsieur, je suis désolé, mais je ne suis pas prêt pour l'instant.";
            link.l2.go = "exit";
			DeleteAttribute(pchar, "questTemp.BlackYosh_1");
        break;
		
		case "BlackYosh_6":
            dialog.text = "D'après les rapports des colonies anglaises de l'est, il n'y a pas assez de navires à Bridgetown pour patrouiller la frontière maritime. La frégate Black Hedgehog doit donc être escortée sans encombre jusqu'à Bridgetown. Est-ce clair pour vous ?";
            link.l1 = "Oui, monsieur, je prends la mer aujourd'hui.";
            link.l1.go = "BlackYosh_7";
        break;
		
		case "BlackYosh_7":
            dialog.text = "Et autre chose. Avant de mettre le cap sur Bridgetown, je veux que vous remettiez d'abord cette lettre au gouverneur de Charlestown. C'est important !";
            link.l1 = "D'abord la lettre à Charlestown, puis le « Black Hedgehog » à Bridgetown, c'est noté.";
            link.l1.go = "exit";
        break;
	// СФ
	case "SF_HuberDialogueBeginning":
    		dialog.text = "Oui, " + GetAddress_Form(pchar) + ", je vous attendais. J'ai un service à vous demander.";
    		link.l1 = "Pourquoi moi ?";
    		link.l1.go = "SF_HuberDialogueExplanation";
	break;
		
	case "SF_HuberDialogueExplanation":
    		dialog.text = "C'est simple. Vous avez coulé des dizaines de navires, et vous ne pendez pas au gibet, vous ne vous cachez pas dans des repaires de pirates : vous mouillez librement dans le principal port de la mer des Caraïbes. Vous êtes le meilleur que j'aie jamais vu.";
    		link.l1 = "L'affaire concerne-t-elle un raid en mer ?";
    		link.l1.go = "SF_HuberDialogueBingo";
	break;
		
	case "SF_HuberDialogueBingo":
    		dialog.text = "Exactement ! Et très lucrative pour vous.";
    		link.l1 = "Exposez votre affaire.";
    		link.l1.go = "SF_HuberDialogueDealDitails";
	break;
		
	case "SF_HuberDialogueDealDitails":
    		dialog.text = "Oui, vous avez la poigne d'un vrai loup de mer. C'est une affaire très simple. Sa Majesté royale fourre son nez là oם il ne faut pas ! Ils se sont emparés des secteurs les plus lucratifs avec leurs propres hommes venus de Londres. Et ça, de droit, ce devrait être mon travail !";
    		link.l1 = "Que puis-je faire pour vous, exactement ?";
    		link.l1.go = "SF_HuberDialogueBarbadosSilver";
	break;
		
	case "SF_HuberDialogueBarbadosSilver":
    		dialog.text = "La Barbade possède de gigantesques gisements d'argent et, bien sמr, on les exploite. Même la plantation n'y est entretenue que pour cacher l'ampleur des travaux, et la mortalité accrue des esclaves.";
    		link.l1 = "Très intéressant...";
    		link.l1.go = "SF_HuberDialogueSilverLogistic";
	break;
		
	case "SF_HuberDialogueSilverLogistic":
    		dialog.text = "Toutes les cargaisons des colonies anglaises des Caraïbes arrivent d'abord à Port Royal, puis repartent pour l'Europe. Et la Barbade abrite le bien le plus précieux de l'Angleterre dans les Caraïbes...";
    		link.l1 = "Je commence à comprendre. Vous voulez que j'intercepte justement cette cargaison de la Barbade.";
    		link.l1.go = "SF_HuberDialogueSilverIsMine";
	break;
		
	case "SF_HuberDialogueSilverIsMine":
    		dialog.text = "Vous avez bien compris. J'ai dit bien des fois que je n'avais pas besoin de l'aide de la métropole, mais on ne me fait pas confiance, voyez-vous.";
    		link.l1 = "Et il faut que les invités d'outre-mer perdent confiance et fassent de vous un personnage exceptionnel, capable d'organiser la logistique correctement et en toute sécurité.";
    		link.l1.go = "SF_HuberDialogueCloserToTheDeal";
	break;
		
	case "SF_HuberDialogueCloserToTheDeal":
    		dialog.text = "Plus court. Un Convoi d'argent circule entre la Barbade et la Jamaïque. J'ai besoin qu'il disparaisse en route, tout entier. Tout le butin est pour vous. De plus, si ça marche et que je supervise toutes les expéditions anglaises, un million de piastres par mois tombera sur votre compte à la banque de Port Royal. Marché conclu ?";
    		link.l1 = "Marché conclu. Quand le convoi quitte-t-il le port de Bridgetown ?";
    		link.l1.go = "SF_HuberDialogueDealAgreed";
		link.l2 = "Non. Les grandes escadres, ce n'est pas ma spécialité.";
    		link.l2.go = "SF_HuberDialogueNoDeal";
	break;
		
	case "SF_HuberDialogueDealAgreed":
    		dialog.text = "Eh bien, ce n'est pas si simple. Le convoi ne quitte jamais aucun port. Les navires se rassemblent un par un en haute mer pour former une escadre, puis poursuivent vers la Jamaïque. Ces étrangers savent se cacher. De plus, ils ont le pouvoir, et aucun sujet anglais, pas même mes proches, ne doit être sollicité pour m'aider dans cette affaire.";
    		link.l1 = "Ce ne serait donc que par hasard ? Comment puis-je garantir un résultat ?";
    		link.l1.go = "SF_HuberDialogueDealHelper";
		AddQuestRecord("SilverFleet", "QuestTaken");
		AddQuestUserData("SilverFleet", "sSex", GetSexPhrase("", "e"));
		pchar.questTemp.silverfleet = "FirstSilverFleet";
		pchar.SilverFleetAtSea = true;
	break;
		
	case "SF_HuberDialogueDealHelper":
    		dialog.text = "Ne vous inquiétez pas. Je ne vous presse pas pour le résultat : le convoi circule régulièrement. Mon vieil ami du François, le chef du repaire pirate, vous aidera dans cette entreprise. Il a des yeux tout le long de la route du convoi.";
    		link.l1 = "Compris. Mais avez-vous des informations sur les navires et la taille de l'escadre ?";
    		link.l1.go = "SF_HuberDialogueDealMoreDitals";
	break;
		
	case "SF_HuberDialogueDealMoreDitals":
    		dialog.text = "Très peu. C'est pourquoi je ne vous impose pas de délai. Les spécialistes d'outre-mer cachent soigneusement tout cela. Je peux seulement dire que, contrairement aux Espagnols, les escadres anglaises comprennent forcément des navires rapides et manœuvrants.";
    		link.l1 = "Tout est clair. Attendez les bonnes nouvelles. Au revoir.";
    		link.l1.go = "exit";	
	break;
		
	case "SF_HuberDialogueNoDeal":
    		dialog.text = "Ah oui ? Je me suis trompé sur votre compte. C'est bien dommage. Cette conversation n'a jamais eu lieu. Adieu.";
    		link.l1 = "Je comprends. Adieu.";
    		link.l1.go = "exit";
		pchar.questTemp.silverfleet = "over";
	break;
		
	case "SF_HuberDialogueThinking":
    		dialog.text = "Vraiment ? Je vous croyais plus d'ambition... Pourquoi n'y réfléchiriez-vous pas ?";
 		link.l2 = "Ouais, je crois que j'ai refusé un peu vite. Désolé pour le dérangement.";
    		link.l2.go = "exit";
		link.l1 = "C'est bien ce que je pensais. La décision est prise. Adieu, monsieur.";
    		link.l1.go = "SF_HuberDialogueQuestCancel";
		SaveCurrentNpcQuestDateParam(NPChar, "SilverFleetCancelThinking");
	break;
		
	case "SF_HuberDialogueQuestCancel":
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		pchar.questTemp.silverfleet = "over";
		pchar.SilverFleetAtSea = false;
		KillHeadSilverFleet();
		AddQuestRecord("SilverFleet", "SelfCancelingQuest");
		AddQuestUserData("SilverFleet", "sSex", GetSexPhrase("", "e"));
		CloseQuestHeader("SilverFleet");
		DeleteAttribute(NPChar, "SilverFleetCancelThinking");
	break;
		
	case "SF_HuberDialogueFail":
		dialog.text = "Merci d'avoir essayé. Bien sמr, je ne vous dois pas d'argent. Adieu, "  + pchar.name + ".";
    		link.l1 = "Je comprends, monsieur. Adieu.";
		link.l1.go = "SF_HuberDialogueQuestCancel";
	break;

	case "SF_HuberDialogueTheEnd":
		dialog.text = "Oui, c'est du travail brillant. Je ne serais pas venu vous voir si j'avais su quelle résistance ils opposeraient. Mais vous avez dépassé mes attentes, et de loin. Et vous savez quoi ? Les sbires du roi ne sont plus ici. Je pense que ce qui les attend à Londres, ce n'est pas seulement une rétrogradation...";
    		link.l1 = "Et la récompense ?";
		link.l1.go = "SF_HuberDialogueTheEndReward";
		ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 30);
	break;

	case "SF_HuberDialogueTheEndReward":
		dialog.text = "J'ai déjà donné l'ordre à la banque de vous verser votre argent. Soyez tranquille, on vous créditera exactement un million chaque mois. Adieu, " + pchar.name + ".";
    		link.l1 = "Ce fut un plaisir de traiter avec vous, monsieur. Adieu.";
		link.l1.go = "SF_HuberDialogueQuestСlose";
	break;

	case "SF_HuberDialogueQuestСlose":
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		SilverFleetMillionEveryMonth();
		pchar.questTemp.silverfleet = "over";
		pchar.questdata.SilverFleet = 1;
		AddQuestRecord("SilverFleet", "QuestEnd");
		CloseQuestHeader("SilverFleet");
		pchar.SilverFleetAtSea = true;
	break;

	case "SF_HuberDialogueFirstSilverFleetDeath":
		dialog.text = "Prenez votre temps, "  + GetAddress_Form(pchar) + " " + pchar.name + ". Nous étions convenus d'une récompense si ça marchait, si les étrangers recrachaient leur part de mon gâteau et s'en allaient. Je vous ai exposé mon plan, et vous étiez d'accord.";
		link.l1 = "Ne me faites pas tourner en bourrique. J'ai détruit le convoi de fond en comble. Qu'est-ce qui ne va pas ?";
		link.l1.go = "SF_HuberDialogueFirstSilverFleetProblem";
	break;

	case "SF_HuberDialogueFirstSilverFleetProblem":
		dialog.text = "C'est exact. Vous avez fait du beau travail, mais ils étaient plus coriaces que je ne le pensais. On a décidé de renforcer le convoi. Les choses vont vers la victoire, notre victoire. Mais ce n'est pas fini.";
		link.l1 = "Ce convoi n'a pas été une promenade de santé... Eh bien, je ne peux pas abandonner maintenant que je suis dans le coup.";
		link.l1.go = "SF_HuberDialogueFirstSilverFleetContinue";
	break;

	case "SF_HuberDialogueFirstSilverFleetContinue":
		dialog.text = "Nous continuons donc à travailler ensemble. Mêmes conditions que précédemment. J'attendrai des nouvelles.";
		link.l1 = "Vous en aurez.";
		link.l1.go = "exit";
		pchar.questTemp.silverfleet = "SecondSilverFleet";
		pchar.SilverFleetAtSea = true;
		AddQuestRecord("SilverFleet", "FirstSilverFleetContinue");
		AddQuestUserData("SilverFleet", "sSex", GetSexPhrase("", "e"));
	break;

	case "SF_HuberDialogueSecondSilverFleetDeath":
		dialog.text = "Oui, " + pchar.name + "J'ai entendu parler de vos exploits. Et oui, encore une fois, ce n'est pas tout. Mais il est certain que le troisième coup sera le dernier.";
		link.l1 = "Comment pouvez-vous en être si sמr ?";
		link.l1.go = "SF_HuberDialogueSecondSilverFleetProblem";
	break;

	case "SF_HuberDialogueSecondSilverFleetProblem":
		dialog.text = "Après la première attaque contre le convoi, la Couronne a envoyé ici un navire expérimental, le Silver Surfer, construit au chantier naval de Chatham. Ce que c'est, je ne le sais pas. On dit qu'il ne se distingue en rien des autres navires de sa classe, mais que c'est un véritable fourgon blindé ! Il a été construit spécialement pour transporter des cargaisons de valeur dans les Caraïbes, seul ! \nIl est si solide qu'il peut résister à tout un groupe de navires avant d'atteindre un port sמr, et il a assez de puissance de feu pour dissuader les ennemis de s'approcher à portée d'abordage. \nAlors, si vous venez à bout de ceux-là, il ne restera plus ici la moindre trace des sbires de la Couronne anglaise. Bien sמr, ils ne le laisseront pas partir seul...";
		link.l1 = "דa m'est égal. L'important, c'est que j'en finisse avec cette affaire.";
		link.l1.go = "SF_HuberDialogueSecondSilverFleetSmallDetail";
	break;

	case "SF_HuberDialogueSecondSilverFleetSmallDetail":
		dialog.text = "Un petit détail... Ils ont eu vent, je ne sais comment, de qui les attaquait, et ils ont lancé des chasseurs de primes. Faites attention qu'ils n'apprennent pas que ma tête est en jeu dans cette affaire. Tout ce que je peux faire, c'est les empêcher de vous attaquer dans les colonies anglaises : là, vous serez en sécurité.";
		if (CheckAttribute(PChar, "questTemp.silverfleet.lefransuamayorspeak"))
		{
			link.l1 = "Ils sont de mèche avec les pirates : c'est comme ça qu'ils l'ont appris ! Même votre copain du François rechigne à partager ses informations. Bah, ce n'est qu'une péripétie. Nous nous en sortirons !";
			DeleteAttribute(PChar, "questTemp.silverfleet.lefransuamayorspeak");
		}
		else link.l1 = "Ils sont de mèche avec les pirates : c'est comme ça qu'ils l'ont appris ! Bah, ce n'est qu'une péripétie. Nous nous en sortirons !";
		link.l1.go = "SF_HuberDialogueSecondSilverFleetPartingWords";
	break;

	case "SF_HuberDialogueSecondSilverFleetPartingWords":
		dialog.text = "Bon vent et bonne mer, " + pchar.name + " ! Vous allez peut-être livrer la bataille navale la plus dure de votre vie. Vous les avez vraiment mis en rage. Si vous baissez la garde, ils ne vous lâcheront jamais.";
		link.l1 = "Je ne suis pas du genre à baisser la garde. Et ne vous inquiétez pas pour votre tête : je suis de ceux qui sombrent avec leur navire, pas de ceux qui finissent dans la cale d'un navire ennemi.";
		link.l1.go = "SF_HuberDialogueSecondSilverFleetLetsGo";
	break;

	case "SF_HuberDialogueSecondSilverFleetLetsGo":
		dialog.text = "א notre victoire, " + pchar.name + ". א bientכt !";
		link.l1 = "א bientכt, monsieur.";
		link.l1.go = "exit";
		SaveCurrentQuestDateParam("SilverFleetHeadHunters");
		pchar.SilverFleetAtSea = true;
		pchar.questTemp.silverfleet = "ThirdSilverFleet";
		pchar.questTemp.silverfleet.waitingforheadhunters = true;
		AddQuestRecord("SilverFleet", "SecondSilverFleetContinue");
		AddQuestUserData("SilverFleet", "sSex", GetSexPhrase("", "e"));
	break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
