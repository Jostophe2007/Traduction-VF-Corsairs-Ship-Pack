// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Dans mon chantier naval, et dans toute la ville d'ailleurs, je n'ai jamais vu de gens aussi obstinément curieux.",
                          "Eh bien, quelles questions ? Mon métier, c'est de construire des navires, alors allons-y.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Hum, tout de même...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "Soukins_toSantoDomingo")
			{
				link.l1 = "On m'a dit que vous aviez la goélette Hirondelle à vendre, c'est vrai ?";
				link.l1.go = "PL_Q7_1";
			}
			if(PChar.MysteriousIsland == "10" && NPChar.City == "SantoDomingo")	//Загадочный остров
			{
				link.l1 = "Le capitaine Davy Forser s'est-il adressé à vous ?";
				link.l1.go = "MysteriousIsland_1";
			}
		break;
		//пиратка, квест №7
		case "PL_Q7_1":
			dialog.text = "Non, ce n'est pas ça. Pas à vendre : déjà vendue. Un acheteur est venu, et il m'a tellement plu que je lui ai cédé cette goélette pour trois fois rien...";
			link.l1 = "Ce n'est pas l'acheteur qui m'intéresse, c'est le vendeur. Qui vous a vendu la goélette ?";
			link.l1.go = "PL_Q7_2";
		break;
		case "PL_Q7_2":
			dialog.text = "Vendue ? Vendue... C'est un homme qui me l'a vendue...";
			link.l1 = "Oui, je me doute bien que ce n'est pas un cheval. Qui est cet homme, comment s'appelle-t-il ?";
			link.l1.go = "PL_Q7_3";
		break;
		case "PL_Q7_3":
			dialog.text = "Je ne connais pas son nom, je regardais plutכt le navire...";
			link.l1 = "Ne tournez pas autour du pot, l'ami, ça pourrait mal finir pour vous.";
			link.l1.go = "PL_Q7_4";
		break;
		case "PL_Q7_4":
			dialog.text = "Diable ! Je savais que cet achat pourrait mal tourner pour moi. Mais le prix proposé était si avantageux... J'ai tout de suite soupçonné qu'il y avait anguille sous roche, mais j'espérais me tromper.";
			link.l1 = "Vous ne vous trompiez sans doute pas. Oם puis-je trouver le vendeur ?";
			link.l1.go = "PL_Q7_5";
		break;
		case "PL_Q7_5":
			dialog.text = "En mer. Hier, il a pris la mer sur la frégate Leon, à ce que je sais. Je n'ai pas vu la frégate moi-même. Ce type était très prudent, mais un de mes ouvriers l'a vu et me l'a dit. Il croise quelque part au large d'Hispaniola. Je ne pense pas qu'il soit allé bien loin.";
			link.l1 = "Merci. Nous allons le chercher.";
			link.l1.go = "exit";
			pchar.questTemp.piratesLine = "Soukins_seekLeon";
			AddQuestRecord("Pir_Line_7_Soukins", "6");
			AddDialogExitQuestFunction("PQ7_LoginLeon");
			QuestSetCurrentNode("Henry Morgan", "PL_Q7_LeonNotFound"); //нода, ничего не узнал
		break;
		
		// Загадочный остров -->
		case "MysteriousIsland_1":
			dialog.text = "Eh bien, je connais Davy depuis longtemps. Il est venu reprendre son galion chez moi pas plus tard qu'hier, après le renforcement du gréement. Il a mentionné qu'il allait à La Vega, je m'en souviens bien parce que ça m'a étonné. On peut aller à La Vega à pied, à quoi bon de telles voiles ?!";
			link.l1 = "Merci, vous m'avez beaucoup aidé.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandToLaVega");
		break;
		// Загадочный остров <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

