// Gregg: Allen Gladstonn and the Black Boy - quest "The Monkey Ship" (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\captainmonkey.c
// Nodes 1-5 - the hook by the Bas-Terre church, 9-10 - Allen in the Beliz church,
// 11-13 - the last meeting beyond the gates, 14-19 - the Black Boy on the shore.
// Nodes 6-8 of the original are gone: there Allen came to the grotto to search the
// prisoner and take his sabre, and we take nothing - skeletons guard it instead.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sIsland = PChar.CaptainMonkey.IslandID;
	sIsland = XI_ConvertString(sIsland + "Gen");

	string sGrotIsland;
	int iMoney;
	// Gregg: the mod-wide "remove quest rank requirements" toggle. Read LIVE, the way
	// Tillman and Sajfus do it: with the option on the hook opens from rank one.
	int iRankReq = 1;
	if (!bQuestsRank) iRankReq = 13;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Personne, personne ne me croira... Tout le monde me prend pour un fou...";
			link.l1 = "C'est bien dommage...";
			link.l1.go = "exit";

			// Gregg: the hook is offered until the quest is taken. The rank threshold
			// matches CM_RANK_REQ in the logic (13): defines do not reach a dialogue segment.
			// The rank is read directly: GetRank(PChar, 0) adds the player's rank again
			// inside and would return double - the gate would open at rank seven.
			if (PChar.CaptainMonkey == "0")
			{
				if (CheckAttribute(PChar, "CaptainMonkey.NotTrust"))
				{
					link.l1 = "Oם avez-vous dit que c'était arrivé : au large de " + sIsland + " ?";
					link.l1.go = "4";
					link.l2 = "C'est bien dommage...";
					link.l2.go = "exit";
				}
				else
				{
					if (sti(PChar.rank) >= iRankReq)
					{
						link.l1 = "De quoi parles-tu, vagabond ? Qui ne croira pas quoi ?";
						link.l1.go = "1";
						link.l2 = "C'est bien dommage...";
						link.l2.go = "exit";
					}
				}
			}
		break;

		case "1":
			dialog.text = "Personne ne me croit, pas même le curé, et pourtant, je dis la pure vérité, rien que la vérité...";
			link.l1 = "Qu'est-ce que tu marmonnes ? Raconte dans l'ordre. Que t'est-il arrivé ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Dans l'ordre... Quel ordre peut-il y avoir, monsieur, quand on vous aborde avec un navire plein de singes !";
			link.l1 = "Eh bien, mon gars... Je vois que tu as bu un coup de trop.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Pas du tout, " + GetAddress_FormToNPC(NPChar) + " ! Croyez-moi ou non, mais je dis la pure vérité ! Dans les eaux cכtières de " + sIsland + " mon sloop marchand a été attaqué par un lougre avec des singes à bord ! Des singes, " + GetAddress_FormToNPC(NPChar) + " ! Ces singes se sont occupés de mes marins comme des pirates aguerris, et ils m'ont jeté par-dessus bord comme un tonnelet de rhum vide ! Ne me demandez pas comment je suis rentré chez moi ! Personne ne me croit, personne...";
			link.l1 = "Eh bien, seul un fou pourrait croire une histoire pareille. Oם avez-vous dit que c'était arrivé : au large de " + sIsland + " ?";
			link.l1.go = "4";
			link.l2 = "Et tu veux que je croie à ces sornettes ? א mon avis, tu ferais mieux de te rincer la cervelle avec une chope de rhum bien fort !";
			link.l2.go = "5";
		break;

		case "4":
			dialog.text = "Oui, " + GetAddress_FormToNPC(NPChar) + ". C'était dans les eaux cכtières de " + sIsland + ". Je jure que je dis la pure vérité !";
			link.l1 = "Très bien, je vous crois.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyStart");
		break;

		case "5":
			PChar.CaptainMonkey.NotTrust = true;
			dialog.text = "Personne, personne ne me croira...";
			link.l1 = "...";
			link.l1.go = "exit";
		break;

		case "9":
			dialog.text = "Capitaine, c'est vous ?! Comment m'avez-vous trouvé ?!";
			link.l1 = "Pourquoi ces questions idiotes ? Tu ferais mieux de compter combien de secondes il reste à ton âme pécheresse avant de s'envoler au ciel.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Vous n'allez tout de même pas tirer l'épée dans un lieu saint ? Je ne vous crois pas capable d'un tel sacrilège ! Sortons de la ville : là-bas, je vous raconterai bien des choses intéressantes !";
			link.l1 = "Très bien, allons-y.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyFromChurchToTown");
		break;

		case "11":
			dialog.text = "Capitaine, c'est la deuxième fois que vous m'étonnez ! Comment m'avez-vous trouvé, cette fois ?!";
			link.l1 = "J'espère que cette rencontre sera la dernière, mon cher ami des bêtes.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Je comprends : vous voulez me faire dire tout ce que je sais du capitaine Mowgli. Mais même sous peine de mort, je ne le ferai pas. Si je délie ma langue, Mowgli me retrouvera n'importe oם, et alors je suis un homme mort. Dans un combat contre vous, j'ai au moins une chance.";
			link.l1 = "Je suis désolé de vous décevoir, mais vous avez choisi le chemin le plus court pour l'autre monde.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "On verra bien ! En garde, capitaine " + GetFullName(PChar) + " !";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyBattleWithAllen");
		break;

		case "14":
			dialog.text = GetAddress_FormToNPC(NPChar) + ", pourriez-vous me donner quelques pièces pour manger ?..";
			link.l1 = "Pourquoi ne trouves-tu pas du travail ? Vivre d'aumכnes, ce n'est guère un sort enviable.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Le fait est que je ne vis pas ici depuis longtemps, et j'ai passé toute mon enfance dans la jungle, parmi les singes. Je n'ai pas de métier, et je ne connais presque personne ici : alors je ne peux pas encore gagner mon pain quotidien...";
			link.l1 = "Dans la jungle, parmi les singes ? Alors qui t'a appris à parler ? De toute ma vie, je n'ai vu qu'un seul singe qui parle : un certain capitaine Mowgli.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Vous connaissez le capitaine Mowgli ?! Un sort peu enviable attend d'habitude quiconque fait sa connaissance ! Et pourtant, vous, à ce que je vois, vous êtes sain et sauf ?!";
			link.l1 = "Alors tu le connais aussi ? Parle, alors !";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Bien sמr, je l'ai connu quand il était encore un homme : c'est lui qui m'a élevé. Et depuis qu'il a pactisé avec les puissances impures et qu'il s'est changé en singe, sa cruauté ne connaît plus de bornes. Je ne pouvais plus supporter ses mauvais traitements, et je me suis enfui. Mais comment avez-vous survécu à une rencontre avec lui, alors qu'il est immortel ?!";
			link.l1 = "C'est une longue histoire : on ne m'a laissé la vie que pour mettre la main sur mon argent, mais par chance, j'ai réussi à m'enfuir. Alors, tu dis qu'il a pactisé avec les puissances impures ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Oui, " + GetAddress_FormToNPC(NPChar) + ". Un jour, il a trouvé une bouteille scellée rejetée sur le rivage et, par curiosité, il l'a brisée... Le démon maléfique libéré de sa prison l'a convaincu... Je ne sais pas ce qui lui a pris, mais il a franchi le pas. Pourquoi il a accepté, je ne le comprends toujours pas. Le démon a promis à Mowgli l'immortalité et le soutien de toutes sortes de créatures démoniaques, et en échange, il a exigé qu'il punisse de mort les hommes coupables de l'un des péchés terrestres les plus innocents : la curiosité... Ils ont signé un contrat, et Mowgli l'a signé de son propre sang. Tant que ce contrat existe, Mowgli est immortel.";
			link.l1 = "Comment ça, tant que le contrat existe ? Alors, on peut le détruire ?";
			link.l1.go = "19";
		break;

		case "19":
			iMoney = sti(PChar.money) / 100;
			if (iMoney > 10000) iMoney = 10000;
			AddMoneyToCharacter(PChar, -iMoney);

			sGrotIsland = CaptainMonkeyGetGrotIsland();
			dialog.text = "Ce n'est pas une mince affaire, " + GetAddress_FormToNPC(NPChar) + ". Vous avez eu beaucoup de chance de me rencontrer : je vais vous dire comment l'atteindre. Mowgli a caché le coffret contenant le contrat dans une grotte (île : " + sGrotIsland + "). Le coffret est bien gardé par des créatures démoniaques de toutes sortes, mais si vous réussissez à vous emparer de ce papier et à le livrer aux flammes, le pacte sera rompu, Mowgli perdra son immortalité et sera impuissant !";
			link.l1 = "Oui, j'ai vraiment eu de la chance de te rencontrer... Prends ces " + iMoney + " pièces et essaie d'apprendre un métier. J'espère que nous nous reverrons !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyFindContract");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
