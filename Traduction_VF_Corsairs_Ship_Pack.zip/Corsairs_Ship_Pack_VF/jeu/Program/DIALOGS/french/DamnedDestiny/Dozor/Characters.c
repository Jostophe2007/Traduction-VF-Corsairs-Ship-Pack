
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = GetFullName(PChar);
	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		// РЫБАК ПЕДРО -->
		case "Fisher_Pedro_1":
			dialog.text = "...(presque en larmes)... Toi aussi, tu viens ? Tu veux te moquer de Pedro, toi aussi ? Allez, qu'est-ce que tu attends ?";
			link.l1 = "L'Escadre insaisissable est apparue dans les eaux de la mer des Caraïbes.";
			link.l1.go = "Fisher_Pedro_2";
		break;

		case "Fisher_Pedro_2":
			dialog.text = "Quoi ? Qu'est-ce que vous venez de dire ?";
			link.l1 = "L'Escadre insaisissable est apparue dans les eaux de la mer des Caraïbes.";
			link.l1.go = "Fisher_Pedro_3";
		break;

		case "Fisher_Pedro_3":
			dialog.text = "...(s'animant)... Alors, c'est toi qui joues à la Veille ?";
			link.l1 = "Oui, c'est moi. Tu as quelque chose pour moi ?";
			link.l1.go = "Fisher_Pedro_4";
		break;

		case "Fisher_Pedro_4":
			TakeNItems(PChar, "Dozor_Mekakhrom", 1);
			dialog.text = "Oui, tiens ! C'est le deuxième Meckachrome.";
			link.l1 = "Merci. Bonne chance à toi.";
			link.l1.go = "Fisher_Pedro_5";
		break;

		case "Fisher_Pedro_5":
			dialog.text = "Euh, capitaine, attendez ! Vous n'auriez pas, par hasard, 50 pièces d'or pour un pauvre pêcheur ?";

			if(sti(PChar.money) >= 50)
			{
				link.l1 = "Promets-moi seulement de les dépenser intelligemment, et pas de les boire ou de les perdre au jeu, d'accord ?";
				link.l1.go = "Fisher_Pedro_6";
			}

			link.l2 = "Par hasard, non. Adieu.";
			link.l2.go = "Fisher_Pedro_9";
		break;

		case "Fisher_Pedro_6":
			dialog.text = "D'accord ! Donne-les-moi vite !";
			link.l1 = "Ha ! Tu croyais vraiment que j'allais te les donner ? Tu peux toujours courir.";
			link.l1.go = "Fisher_Pedro_7";
			link.l2 = "Tiens, et adieu. Je n'ai pas le temps de traîner avec toi.";
			link.l2.go = "Fisher_Pedro_8";
		break;

		case "Fisher_Pedro_7":
			dialog.text = "Ah, toi ! Ah, sale brute avare ! Rapace repu, espèce de" +" " + GetSexPhrase("salaud","garce") +" ! Va-t'en ! ...(en pleurnichant)... Va-t'en !";
			link.l1 = "Disparais de ma vue, minable.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DozorFisherPedroExit");
		break;

		case "Fisher_Pedro_8":
			AddMoneyToCharacter(PChar, -50);
			DozorFisherPedroExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Fisher_Pedro_9":
			DozorFisherPedroExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		// РЫБАК ПЕДРО <--

		// УБИЙЦЫ АГЕНТА В ГРОТЕ ТЕРКСА -->
		case "Grot_Agent_Killers_1":
			SetCameraDialogMode(CharacterFromID("Dozor Grot Agent Killer 2"));
			dialog.text = "Goebels : Jette ce truc, Krieger, il ne vaut pas un clou.";
			link.l1 = "";
			link.l1.go = "Grot_Agent_Killers_2";
		break;

		case "Grot_Agent_Killers_2":
			SetCameraDialogMode(CharacterFromID("Dozor Grot Agent Killer 1"));
			dialog.text = "Krieger : Et moi, je suis sמr que c'est un objet très important. Regarde, c'est écrit ici...";
			link.l1 = "";
			link.l1.go = "Grot_Agent_Killers_3";
		break;

		case "Grot_Agent_Killers_3":
			SetCameraDialogMode(CharacterFromID("Dozor Grot Agent Killer 2"));
			dialog.text = "Goebels : ...(l'interrompant)... Regarde qui vient nous voir !";
			link.l1 = "";
			link.l1.go = "Grot_Agent_Killers_4";
		break;

		case "Grot_Agent_Killers_4":
			SetCameraDialogMode(CharacterFromID("Dozor Grot Agent Killer 1"));
			dialog.text = "Krieger : ...(entre ses dents)... Encore une victime. Droit dans nos griffes !";
			link.l1 = "";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DozorBattleInTerksGrot");
		break;
		// УБИЙЦЫ АГЕНТА В ГРОТЕ ТЕРКСА <--

		// СПАНЧ БОБ -->
		case "Spanch_Bob_1":
			dialog.text = "Et... hic ? Qu'est-ce que tu veux ?";
			link.l1 = "Le brave capitaine a engagé le combat avec l'Escadre insaisissable.";
			link.l1.go = "Spanch_Bob_2";
		break;

		case "Spanch_Bob_2":
			dialog.text = "Ah ! Tu fais la Veille, " + GetSexPhrase("l'ami","ma belle") +" ?";
			link.l1 = "Oui, j'ai décidé de m'y mettre, pour essayer.";
			link.l1.go = "Spanch_Bob_3";
		break;

		case "Spanch_Bob_3":
			dialog.text = "Et tu as bien fait ! Je me souviens d'avoir joué à ce jeu, moi aussi, c'était le bon temps. דa remonte à loin. Mais notre équipe n'avait jamais de chance. Tantכt le mât se brisait, tantכt on s'échouait, tantכt il nous arrivait une autre crasse.";
			link.l1 = "Ce genre de jeux a déjà eu lieu avant ?";
			link.l1.go = "Spanch_Bob_4";
		break;

		case "Spanch_Bob_4":
			dialog.text = "Bien sמr ! Tu ne le savais pas ?";
			link.l1 = "Je ne le savais pas. C'est la première fois que j'en entends parler.";
			link.l1.go = "Spanch_Bob_5";
		break;

		case "Spanch_Bob_5":
			dialog.text = "Eh, tu débarques de ta cambrousse, cap'tain. Bon, bonne chance pour... Hic ! Bref, adieu, " + GetSexPhrase("frère","sœur") +" !";
			link.l1 = "Hé ! Et le prochain Meckachrome, alors ?";
			link.l1.go = "Spanch_Bob_6";
		break;

		case "Spanch_Bob_6":
			dialog.text = "Le Mécha-quoi ? Le Meckachrome ?";
			link.l1 = "Tu devais me le remettre, il contient la prochaine énigme.";
			link.l1.go = "Spanch_Bob_7";
		break;

		case "Spanch_Bob_7":
			dialog.text = "Ah, ce bout de... ferraille qui ne sert à rien. Pardon, " + GetSexPhrase("frère","sœur") +", je l'ai bu l'autre jour.";
			link.l1 = "Quoi ?! Tu l'as bu ? Tu as complètement perdu la tête, épave imbibée ? Comment je fais pour continuer le jeu, d'après toi ? Hein ?!";
			link.l1.go = "Spanch_Bob_8";
		break;

		case "Spanch_Bob_8":
			dialog.text = "Ne t'énerve pas comme ça !";
			link.l1 = "J'ai claqué 20 000 pour ce jeu ! Je vais te trancher la gorge, sale porc !";
			link.l1.go = "Spanch_Bob_10";
		break;

		case "Spanch_Bob_10":
			dialog.text = "Hé ! Bas les pattes ! Hic ! Si tu m'aides, je t'aiderai !";
			link.l1 = "Et comment comptes-tu m'aider ?";
			link.l1.go = "Spanch_Bob_11";
		break;

		case "Spanch_Bob_11":
			dialog.text = "Si tu me donnes cinq cents, je te dirai l'énigme, je m'en souviens bien.";
			link.l1 = "Et comment je vais avoir la phrase clé sans Meckachrome ?";
			link.l1.go = "Spanch_Bob_12";
		break;

		case "Spanch_Bob_12":
			dialog.text = "Je te la dirai si tu résous l'énigme. Je m'en souviens bien.";
			link.l1 = "Ah oui ? Alors, tu l'as résolue, cette énigme du Meckachrome ?";
			link.l1.go = "Spanch_Bob_13";
		break;

		case "Spanch_Bob_13":
			dialog.text = "Qu'est-ce qu'il y a à résoudre ? Dans la vraie Veille, il y a des casse-tête à s'en briser le crâne, alors que tes « devinettes » pour enfants, n'importe qui les résout en cinq minutes.";
			link.l1 = "...(à voix basse)... Alors, tu pourrais peut-être me dire tout de suite la phrase clé, et au diable l'énigme !";
			link.l1.go = "Spanch_Bob_14";
		break;

		case "Spanch_Bob_14":
			dialog.text = "Eh non, " + GetSexPhrase("frère","sœur") +" ! Un vrai veilleur joue toujours franc-jeu, souviens-t'en ! Voici ton énigme. ...(Notée dans le journal de bord)\n Quand tu l'auras résolue, donne-moi la réponse. Si elle est juste, je te dis la phrase clé ; sinon... eh bien, tant pis. Et n'oublie pas les 500 pièces d'or ! Sans elles, je ne te dirai pas la phrase clé.";
			link.l1 = "...(tout bas)... Je n'oublierai pas, maudit fripon !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DozorGuadeloupeShoreGetTask");
			NextDiag.TempNode = "Spanch_Bob_15";
		break;

		case "Spanch_Bob_15":
			dialog.text = "Tu as apporté l'argent ?";

			if(sti(PChar.money) >= 500)
			{
				link.l1 = "Voilà tes piastres, canaille.";
				link.l1.go = "Spanch_Bob_16";
			}

			link.l2 = "Je ne les ai pas sur moi. Je les apporterai plus tard.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Spanch_Bob_15";
		break;

		case "Spanch_Bob_16":
			AddMoneyToCharacter(PChar, -500);
			dialog.text = "Voilà qui est mieux ! Alors, capitaine, quelles sont vos idées sur l'énigme ? Dites-moi juste l'endroit, et je vous donnerai la phrase clé.";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Spanch_Bob_17";
		break;

		case "Spanch_Bob_17":
			string sString = GetStrSmallRegister(dialogEditStrings[1]);
			if(sString == "gulf of doom" || sString == "golfe de la perdition" || sString == "le golfe de la perdition" || sString == "golfe perdition")
			{
				dialog.text = "Bingo ! La phrase clé est : « L'Escadre insaisissable a perdu son vaisseau amiral ».";
				Link.l1 = "Au revoir !";
				Link.l1.go = "exit";
				AddDialogExitQuestFunction("DozorToDeadShoreInMein");
			}
			else
			{
				dialog.text = "Non, capitaine, vous vous trompez. Essayez encore.";
				link.l1 = "Bon sang !";
				link.l1.go = "exit";
				NextDiag.TempNode = "Spanch_Bob_18";
			}
		break;

		case "Spanch_Bob_18":
			NextDiag.TempNode = "Spanch_Bob_18";
			dialog.text = "Alors, capitaine, quelles sont vos idées sur l'énigme ? Dites-moi juste l'endroit, et je vous donnerai la phrase clé.";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Spanch_Bob_17";
		break;
		// СПАНЧ БОБ <--

		// КАПИТАН ФЛЕЙТА У МАРТИНИКИ -->
		case "Justin_Butt_1":
			dialog.text = "Tu as gagné ! Prends le Meckachrome dans le coffre, mais laisse-moi tranquille !";
			link.l1 = "Pourquoi tu t'en es pris à moi ? Réponds !";
			link.l1.go = "Justin_Butt_2";
		break;

		case "Justin_Butt_2":
			dialog.text = "Ce n'est pas évident, capitaine ?";
			link.l1 = "דa fait partie de la mission ? Le but, c'est que je doive prendre le Meckachrome par la force ?";
			link.l1.go = "Justin_Butt_3";
		break;

		case "Justin_Butt_3":
			dialog.text = "Quelle mission, bon sang ? Tu ne comprends donc pas ce qui se passe ici ?";
			link.l1 = "Eh bien, explique-toi clairement, à la fin !";
			link.l1.go = "Justin_Butt_4";
		break;

		case "Justin_Butt_4":
			dialog.text = "Toi et moi, nous sommes rivaux, tu comprends ?";
			link.l1 = "Rivaux ?";
			link.l1.go = "Justin_Butt_5";
		break;

		case "Justin_Butt_5":
			dialog.text = "Oui ! On voit bien à ta tête que c'est la première fois que tu en entends parler. Eh bien, puisque tu as gagné, et loyalement, je vais te le dire. Vois-tu, il n'y a pas que toi dans ce jeu : en plus de toi et moi, trois autres capitaines jouent à la Veille.\nLe vieil homme qui avait organisé le jeu a proposé d'y jouer à tous les capitaines qui avaient jeté l'ancre à Sharp Town pendant qu'il y était. Et cinq d'entre eux ont accepté.";
			link.l1 = "Et tu faisais partie de ceux qui ont accepté ?";
			link.l1.go = "Justin_Butt_6";
		break;

		case "Justin_Butt_6":
			dialog.text = "C'est ça. Mais le vieux ne m'a pas dit qu'en plus de moi, d'autres joueraient. Seulement, je l'ai suivi et je l'ai découvert moi-même, après quoi je l'ai tué, et je me suis mis à chasser les autres capitaines.";
			link.l1 = "Et qu'est-ce qui leur est arrivé ?";
			link.l1.go = "Justin_Butt_7";
		break;

		case "Justin_Butt_7":
			dialog.text = "J'ai éliminé tous les concurrents sauf toi. J'ai coulé un navire dès qu'il a quitté les Bermudes, j'ai rattrapé le deuxième près de Porto Rico, et j'ai détruit le troisième près de Curaçao. Il n'y avait que toi qui posais problème. Je savais que tu avais de l'avance sur moi, mais je n'arrivais pas à savoir de combien.\nC'est sur la Terre Ferme que j'ai pu découvrir que je n'avais que quelques jours de retard sur toi. J'ai vite résolu l'énigme et j'ai filé toutes voiles dehors vers la Martinique.";
			link.l1 = "Il y a donc plusieurs joueurs ? דa veut dire qu'il devait y avoir plusieurs Meckachromes ?";
			link.l1.go = "Justin_Butt_8";
		break;

		case "Justin_Butt_8":
			dialog.text = "Oui, chaque agent avait dix Meckachromes. Ils devaient remettre un Meckachrome à quiconque leur dirait la phrase clé.";
			link.l1 = "Et aux îles Turques ? Je n'y ai trouvé qu'un seul Meckachrome, chez les bandits qui avaient apparemment tué l'agent.";
			link.l1.go = "Justin_Butt_9";
		break;

		case "Justin_Butt_9":
			dialog.text = "Ce que je ne sais pas, je ne le sais pas. Cette fois-là, j'avais du retard sur toi ; je suis arrivé aux îles Turques après toi et j'ai trouvé plusieurs cadavres. L'un d'eux était apparemment l'agent, et les deux autres avaient tout l'air de bandits, que tu avais abattus, je le comprends maintenant. J'ai trouvé les Meckachromes qui nous étaient destinés cachés dans une grotte.";
			link.l1 = "Et la Terre Ferme ? Comment as-tu su que j'avais deux jours d'avance sur toi ?";
			link.l1.go = "Justin_Butt_10";
		break;

		case "Justin_Butt_10":
			dialog.text = "Il y avait aussi un agent sur la Terre Ferme, mais il avait une autre mission. Selon la logique du jeu, les veilleurs devaient trouver le Meckachrome dans un coffre, sur une épave. Je l'ai trouvé là, moi aussi, mais je savais qu'il y avait d'autres joueurs, et donc d'autres Meckachromes.\nJ'ai fouillé les environs et j'ai trouvé un agent. Il m'a dit qu'il devait nous surveiller et remettre un Meckachrome en place chaque fois qu'un veilleur en prenait un.";
			link.l1 = "Autrement dit, après que j'ai trouvé le Meckachrome, il en a remis un nouveau, pour que tu le trouves ?";
			link.l1.go = "Justin_Butt_11";
		break;

		case "Justin_Butt_11":
			dialog.text = "Exactement, et après que j'ai pris le deuxième Meckachrome, il a mis le troisième ; mais comme il ne restait plus personne, grâce à moi, le Meckachrome comme l'agent ne servaient plus à rien.";
			link.l1 = "Tu l'as tué ?";
			link.l1.go = "Justin_Butt_12";
		break;

		case "Justin_Butt_12":
			dialog.text = "Oui, pourquoi l'aurais-je laissé en vie ? Seuls les agents de Tortuga et de Curaçao ont survécu. Ils étaient difficiles à éliminer sans se faire remarquer. Le pêcheur de la plage de Fajardo, je l'ai tué, l'ivrogne du cap Inaccessible aussi. Tu connais déjà l'agent du golfe du Destin : il a subi le même sort. L'agent du Lamentin s'est révélé le plus méfiant. Je ne sais pas comment il m'a démasqué, mais j'ai dמ lui courir après.";
			link.l1 = "Tu sais, je n'ai pas l'intention de te laisser vivre après ce que tu as fait. Défends-toi !";
			link.l1.go = "Justin_Butt_13";
		break;

		case "Justin_Butt_13":
			TakeNItems(PChar, "Dozor_Mekakhrom", -1);
			dialog.text = "Et tu croyais que j'allais te laisser partir comme ça ? Au diable !";
			link.l1 = "Eh bien, essaie, ordure !";
			link.l1.go = "exit";

			PChar.Dozor.CabinID = PChar.location;
			Locations[FindLocation(PChar.location)].box1.items.Dozor_Key = 1;
			Locations[FindLocation(PChar.location)].box1.items.Dozor_Mekakhrom = 1;

			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;
		// КАПИТАН ФЛЕЙТА У МАРТИНИКИ <--

		// НЕЗНАКОМЕЦ В ДОМЕ -->
		case "NoName_1":
			dialog.text = "Personne n'a atteint le trésor avant vous, veilleur. Félicitations !";
			link.l1 = "Qui êtes-vous ?";
			link.l1.go = "NoName_2";
		break;

		case "NoName_2":
			dialog.text = "Je viens de la part de Fabian Gronholm, l'organisateur de ce jeu. Vous vous souvenez de lui ?";
			link.l1 = "Je m'en souviens très bien. Vous savez que Fabian a été assassiné ?";
			link.l1.go = "NoName_3";
		break;

		case "NoName_3":
			dialog.text = "Vraiment ?";
			link.l1 = "J'ai croisé un capitaine à la Martinique. Il m'a raconté qu'il avait tué Gronholm, tous les autres veilleurs et aussi quelques agents. Il voulait me tuer aussi, mais ça n'a pas marché.";
			link.l1.go = "NoName_4";
		break;

		case "NoName_4":
			dialog.text = "C'est dommage, Fabian était un homme formidable : énergique, courageux, entreprenant.";
			link.l1 = "Et ça ne posait pas de problème qu'il n'ait dit à aucun de nous, ses joueurs, qu'il y aurait des rivaux ?";
			link.l1.go = "NoName_5";
		break;

		case "NoName_5":
			dialog.text = "Il ne voulait pas vous monter les uns contre les autres, parce qu'il savait que vous chercheriez non pas à résoudre les énigmes, mais à vous trancher la gorge.";
			link.l1 = "Moi, je n'aurais jamais fait une chose pareille... C'est triste.";
			link.l1.go = "NoName_6";
		break;

		case "NoName_6":
			dialog.text = "Mais le capitaine Justin Butt, comme vous le voyez, ne s'en est pas privé avec vous tous. Pour être franc, je suis content que vous ayez réussi à l'achever : je n'aime pas ce genre de personnes.";
			link.l1 = "Et quel est votre rכle dans ce jeu ? Vous êtes un agent, vous aussi ?";
			link.l1.go = "NoName_7";
		break;

		case "NoName_7":
			dialog.text = "On peut dire ça. En fait, je suis l'associé de Fabian, son bras droit. Je devais noter l'ordre de vos arrivées ici, vous remercier d'avoir joué, mettre un nouveau trésor dans le coffre et le refermer.";
			link.l1 = "Ceux qui devaient arriver ici après moi auraient donc reçu un trésor, eux aussi ?";
			link.l1.go = "NoName_8";
		break;

		case "NoName_8":
			dialog.text = "Exactement. Le premier reçoit le trésor le plus riche : 3 objets de valeur et 100 000 pièces d'or, de quoi couvrir largement vos dépenses. Le deuxième arrivé avait droit à un trésor contenant 1 objet de valeur, qui couvre les frais du jeu.\nAu troisième, nous remboursions le prix du jeu, et les autres devaient repartir les mains vides. Mais puisque personne d'autre ne viendra, ma mission est terminée.";
			link.l1 = "Ce genre de jeux a déjà eu lieu avant ? L'un des agents en a parlé, il me semble.";
			link.l1.go = "NoName_9";
		break;

		case "NoName_9":
			dialog.text = "Oui, il y a eu de tels jeux : Fabian avait déjà organisé 3 événements de ce genre...";
			link.l1 = "C'est étrange, mais avant que Fabian me propose de jouer, je n'avais jamais entendu parler de la Veille.";
			link.l1.go = "NoName_10";
		break;

		case "NoName_10":
			dialog.text = "Et vous auriez difficilement pu en entendre parler. א la fin du jeu, en règle générale, un seul capitaine survivait. Je vous le dis : ils cherchent à s'éliminer les uns les autres, ils ne savent pas jouer franc-jeu. C'est pour ça que vous ne connaissiez pas, ou plutכt ne deviez pas connaître, l'existence des autres. Comme vous le voyez, encore une fois, ça n'a pas marché : de tous les joueurs, il ne reste que vous.";
			link.l1 = "Et qu'adviendra-t-il du jeu maintenant ? Si Fabian a été tué, il n'y aura plus de parties ?";
			link.l1.go = "NoName_11";
		break;

		case "NoName_11":
			dialog.text = "J'aurais pu devenir l'organisateur, mais... Ce qui m'arrête, c'est que trop de gens sont déjà morts à cause de ce jeu. Le projet sera donc probablement abandonné.";
			link.l1 = "Je pense que c'est la bonne décision.";
			link.l1.go = "NoName_12";
		break;

		case "NoName_12":
			dialog.text = "Je suis content que vous soyez d'accord avec moi. Merci d'avoir joué. Bonne chance à vous !";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			UnlockAchievement("AchDozor", 3);
			AddDialogExitQuestFunction("DozorHappyEnd");
		break;
		// <-- НЕЗНАКОМЕЦ В ДОМЕ


		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
