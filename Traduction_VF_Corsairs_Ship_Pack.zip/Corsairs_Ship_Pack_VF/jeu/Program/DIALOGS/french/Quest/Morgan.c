// Генри Морган
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	float locx, locy, locz;
	string sTemp;
	int iTemp;
// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
            switch (npchar.angry.kind) //сюда расписываем реакцию ангри. В npchar.angry.name пробелы удалены!!!
            {
                case "repeat":
                    if (npchar.angry.name == "Firsttime") Dialog.CurrentNode = "AngryRepeat_1";
                    if (npchar.angry.name == "I_know_you_good") Dialog.CurrentNode = "AngryRepeat_2";
                break;
            }
        }
    }
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================
	// Gregg: диспетчер отложенных докладов хаба — когда Морган свободен, выдаём
	// следующий доклад из очереди; если же узлом владеет линия, у которой в
	// очереди лежит её более свежая нода — отдаём её (внутрилинейный догон).
	// Парковка/очередь — HubReportPark в QuestsUtilite.c.
	if (!CheckAttribute(NPChar, "angry"))
	{
		string _hubRep = "";
		if (HubIsIdleNode("Henry Morgan", Dialog.CurrentNode))
		{
			_hubRep = HubReportServe("Henry Morgan");
			if (_hubRep == "") NPChar.dialog.hubActiveKey = "";
		}
		else
		{
			_hubRep = HubReportServeKey("Henry Morgan", HubNodeKey(Dialog.CurrentNode));
		}
		if (_hubRep != "")
		{
			Dialog.CurrentNode = _hubRep;
			NextDiag.CurrentNode = _hubRep;
		}
	}
	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
            dialog.text = NPCStringReactionRepeat("Vous avez une affaire pour moi ? Non ? Alors quittez immédiatement ma résidence !",
                         "Je crois avoir été clair.", "J'ai pourtant été clair, mais vous continuez à me déranger !",
                         "Bon, ça commence à ressembler à de l'insolence, et ça me fatigue.", "repeat", 20, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je m'en vais déjà.",
                                               "Oui, Morgan, très clair.",
                                               "Pardon, Morgan...",
                                               "Oh...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			if (pchar.questTemp.Sharp == "begin")
			{
				link.l1 = "Morgan, écoute, tu as entendu parler de la pêche aux perles en mer ? On dit qu'il y a des pêcheurs par ici.";
				link.l1.go = "SharpPearl_1";
			}
		break;

 		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "I_know_you_good":
            dialog.text = NPCStringReactionRepeat(GetFullName(pchar) + ", content de te voir ! Qu'est-ce qui t'amène ici ?",
                         "Eh bien, que voulez-vous encore ?", "Combien de temps ça va durer ? Si vous n'avez rien à faire, ne dérangez pas les autres !",
                         "Vous êtes "+ GetSexPhrase("un bon corsaire","une brave fille") +", alors vivez pour l'instant. Mais je ne veux plus avoir affaire à vous ni vous parler.", "repeat", 3, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, en fait, je passais juste voir. Rien de spécial.",
                                               "Rien, comme ça...",
                                               "D'accord, Morgan, pardon...",
                                               "Bon sang, je l'ai bien cherché !!!", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			if (pchar.questTemp.Sharp == "begin")
			{
				link.l1 = "Morgan, écoute, tu as entendu parler de la pêche aux perles en mer ? On dit qu'il y a des pêcheurs par ici.";
				link.l1.go = "SharpPearl_1";
			}
			if (pchar.questTemp.piratesLine == "waiting_Q4" && GetQuestPastDayParam("questTemp.piratesLine") > 5 && pchar.questTemp.Sharp != "toPearl")
			{
				link.l1 = "וcoute, Henry, tu as une affaire qui me conviendrait ?";
				link.l1.go = "PL_Q4_1";
			}
			if (pchar.questTemp.piratesLine == "waiting_Q8" && GetQuestPastDayParam("questTemp.piratesLine") > 30)
			{
				link.l1 = "Henry, me voilà, comme convenu.";
				link.l1.go = "PL_Q8_1";
			}
		break;

		//********************* капитан Шарп *********************
		case "SharpPearl_1":
			dialog.text = "Héhé, ils pêchent, c'est vrai. Seulement, ça ne rapporte que des clopinettes... Cherche Sharp, c'est notre spécialiste des perles, héhé...";
			link.l1 = "Tu sais oם le trouver ?";
			link.l1.go = "SharpPearl_2";
			pchar.questTemp.Sharp = "seekSharp";
		break;
		case "SharpPearl_2":
			dialog.text = "Aucune idée. Mais ce meilleur corsaire de tous les temps traîne souvent dans les bordels. Cherche là-bas...";
			link.l1 = "Compris... Merci, Morgan.";
			link.l1.go = "exit";
		break;
		//********************* Английская линейка *********************
 		case "EngLine_quests":
			dialog.text = "Vous avez affaire à moi ?";
			link.l1 = "Monsieur, le gouverneur général de la Jamaïque, sir Thomas Madiford, a besoin de votre aide.";
			link.l1.go = "Step_1_1";
  		break;

 		case "Step_1_1":
			dialog.text = "Qui êtes-vous ?";
			link.l1 = "Je suis son émissaire.";
			link.l1.go = "Step_1_2";
  		break;

 		case "Step_1_2":
			dialog.text = "Hum, bien. Et en quoi puis-je aider sir Thomas Madiford ?";
			link.l1 = "Vous devez attaquer la ville hollandaise de Curaçao.";
			link.l1.go = "Step_1_3";
  		break;

 		case "Step_1_3":
			dialog.text = "Je ne pense pas que ce soit possible pour l'instant. Je n'ai pas assez de forces pour une telle opération en ce moment. Transmettez-le à Madiford.";
			link.l1 = "Sir Thomas Madiford compte sur vous dans cette affaire.";
			link.l1.go = "Step_1_4";
  		break;

 		case "Step_1_4":
			dialog.text = "Il me semble avoir été clair : je ne peux pas mener cette opération maintenant. Cependant, si vous venez me trouver un peu plus tard chez moi, en Jamaïque, je pourrai peut-être vous proposer personnellement une affaire brמlante. Une affaire pour un vrai corsaire. En attendant, bonne journée.";
			link.l1 = "Je me souviendrai de vos paroles. Je pense que nous aurons beaucoup à nous dire dès que je serai libre. Portez-vous bien.";
			link.l1.go = "exit";
            AddQuestRecord("Eng_Line_2_Talking", "2");
			AddQuestUserData("Eng_Line_2_Talking", "sSex", GetSexPhrase("", "e"));
			AddQuestRecord("Eng_Line_3_Morgan", "1");
			AddQuestUserData("Eng_Line_3_Morgan", "sSex", GetSexPhrase("", "e"));

            pchar.questTemp.Count = makeint(sti(pchar.questTemp.Count) + 1);
            if (pchar.questTemp.Count == "4")   {pchar.questTemp.State = "after_talks_with_pirates";}
            NextDiag.TempNode = "First time";
  		break;

 		case "hot_business":            // начало диалога по третьему квесту англ.линейки
			dialog.text = "Ah, tu as fini par trouver le temps de passer ?";
			link.l1 = "Bonjour, Henry. Je viens me renseigner sur l'« affaire brמlante pour un vrai corsaire ». C'est le moment ?";
			link.l1.go = "Step_3_1";
  		break;

	 	case "Step_3_1":
            if (GetQuestPastDayParam("questTemp") < 27 && pchar.questTemp.CurQuestNumber == "3")
            {
    			dialog.text = "Héhé, le moment est venu encore plus tכt ! Quand tu m'as transmis la demande d'attaquer Curaçao, j'avais déjà prévu une expédition et commencé à la préparer. Mais pas à Curaçao.";
    			link.l1 = "Pourquoi ne l'as-tu pas dit tout de suite ?";
    			link.l1.go = "Step_3_2";
            }
            else
            {
    			dialog.text = "Le moment est passé. Qu'est-ce que tu croyais, que j'allais t'attendre éternellement ? Héhé... Je voulais te proposer une virée à Cumaná, mais tu traînais je ne sais oם pendant tout ce temps. On s'est passé de toi.";
    			link.l1 = "Oh, quel dommage...";
    			link.l1.go = "exit";
                AddQuestRecord("Eng_Line_3_Morgan", "8");
				AddQuestUserData("Eng_Line_3_Morgan", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("Eng_Line_3_Morgan", "sSex1", GetSexPhrase("", "e"));
                CloseQuestHeader("Eng_Line_3_Morgan");
                NextDiag.TempNode = "First time";
                if (pchar.questTemp.CurQuestNumber == "3")
                {
                    SaveCurrentQuestDateParam("questTemp");
                    pchar.questTemp.Waiting_time = "2";
                    pchar.questTemp.CurQuestNumber = "4";
                }
            }
  		break;

	 	case "Step_3_2":
			dialog.text = "Parce que tu sillonnais tout l'archipel à tort et à travers, à t'échiner pour remplir la mission de Madiford. Et moi, je n'invite à participer à une affaire que les gens capables de rejoindre immédiatement mon escadre. Je n'ai pas besoin de bavardages inutiles. Et puis, cette mission de Madiford sentait mauvais.";
			link.l1 = "Explique-toi, qu'est-ce qui sentait mauvais ?";
			link.l1.go = "Step_3_3";
  		break;

	 	case "Step_3_3":
			dialog.text = "Le fait est que Madiford sait parfaitement qu'en règle générale, nous n'attaquons pas les Hollandais, même en mer, et encore moins pour prendre leurs colonies. Les Hollandais sont les commerçants les plus actifs, ce sont eux qui assurent l'abondance des marchandises dans l'archipel. Si nous les empêchons de commercer, nous perdrons beaucoup de choses qu'on vend partout aujourd'hui. "+
                          "De plus, il y a pas mal de Hollandais parmi les corsaires, c'est aussi un facteur. Alors, Madiford t'a donné une mission presque impossible.";
			link.l1 = "Maintenant, c'est clair. Si tu veux bien, revenons à nos affaires. Quelle est cette affaire brמlante ?";
			link.l1.go = "Step_3_4";
  		break;

	 	case "Step_3_4":
			dialog.text = "Je veux attaquer une ville espagnole. דa te dit de tuer quelques Espagnols ?";
			link.l1 = "וvidemment ! Je suis avec toi, pour une part égale du butin selon les lois des Frères de la Cכte.";
			link.l1.go = "I_want_attack";
			link.l2 = "Bon sang ! Aussi tentant que ça paraisse, je dois refuser. L'état de mon navire laisse beaucoup à désirer, et l'équipage est à bout après un long voyage dans les Caraïbes. Pas cette fois.";
			link.l2.go = "Step_3_6";
  		break;

	 	case "I_want_attack":    // Идём на испанцев, а может и не идём
            if (GetCompanionQuantity(pchar) == 1)   // Заставляем геймера избавиться от взятых кубиков.
            {
           		dialog.text = "Bon, la ville que nous attaquons, c'est Belize. On m'a informé qu'il y a en ce moment beaucoup d'or rassemblé là-bas, venu des mines d'or espagnoles du continent américain. L'or est en train d'être préparé pour être expédié en Europe, nous ne pouvons pas tarder. "+
                              "Il reste à terminer les derniers préparatifs de l'expédition. Maintenant, nous devons aller voir Jackman aux Bermudes et John Morris à Port-d'Espagne, sur l'île de la Trinité. Ils sont prêts et nous attendent. Nous avons cinquante jours pour prendre Belize. "+
                              "Et encore un point important : si tu prends le fort d'assaut et que tu as de la chance, sache que les équipages de nos navires te soutiendront pendant l'assaut. "+
                              "Et maintenant, il faut se dépêcher.";
    			link.l1 = "En avant !";
                link.l1.go = "Step_3_7";
            }
            else
            {
                NextDiag.TempNode = "Step_3_4";
               	dialog.text = "Tu traînes toute une queue derrière toi ! Nous partons pour une affaire sérieuse, nous n'avons pas besoin du fardeau de navires en trop\n"+
                              "Alors, occupe-toi de te préparer pour l'opération, débarrasse-toi des compagnons inutiles. Et ne tarde pas, sinon tu ne pourras pas participer à l'affaire.";
    			link.l1 = "Je ferai de mon mieux.";
    			link.l1.go = "exit";
    			link.l2 = "Je n'ai pas la possibilité de changer mes plans aussi brusquement. Je dois refuser l'affaire que tu me proposes.";
    			link.l2.go = "Step_3_6";
             }
  		break;

	 	case "Have_hot_bussines":    // Если геймеру вдруг захочется ещё пообщаться, не знаю, сможет ли. Но на всякий случай.
			dialog.text = "Qu'est-ce qu'on attend ? Le temps est précieux, il faut agir.";
			link.l1 = "Bien sמr, nous agissons immédiatement.";
			link.l1.go = "exit";
            NextDiag.TempNode = "Have_hot_bussines";
  		break;

	 	case "Step_3_6":                   // Отказ от предложения Моргана атаковать испанский город.
			dialog.text = "Eh bien, on dirait que tu n'as pas besoin d'argent... Ha ha ! "+
                          "Je ne te ferai plus une telle offre. Bonne journée.";
			link.l1 = "Allons, Morgan. Pardon...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -10);
            AddCharacterSkill(pchar, SKILL_LEADERSHIP, 0);

            AddQuestRecord("Eng_Line_3_Morgan", "2");
			AddQuestUserData("Eng_Line_3_Morgan", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_3_Morgan");
            pchar.questTemp.Waiting_time = "2";       // 2 так, для проформы, чтоб поддержать стандарт
            pchar.questTemp.CurQuestNumber = "4";     // идём на четвёртый квест
            NextDiag.TempNode = "First time";
  		break;

	 	case "Step_3_7":                  // Согласие на участие в нападении на Белиз
			AddQuestRecord("Eng_Line_3_Morgan", "3");
            pchar.nation = PIRATE;
            pchar.questTemp.State = "AttackBeliz_GoOn";
            LAi_SetActorType(NPChar);
            LAi_ActorSetStayMode(NPChar);
            ChangeCharacterAddressGroup(NPChar, "PortRoyal_houseS1", "goto", "goto7");
            CharacterIntoCompanionAndGoOut(pchar, npchar, "reload", "reload1", 8.5, false);
            Fantom_SetBalls(npchar, "pirate");
            npchar.CompanionEnemyEnable = false;  // нет отпора при обстреле
            // ==>  Кол-во компаньонов. Нужно для раздела золота независимо от того, кто остался жив, т.е. в обойме компаньонов(по закону берегового братства).
            pchar.questTemp.CompanionQuantity = "2";
            // ==>  Даём соотв. ноду Джекмену
            QuestSetCurrentNode("Jackman", "Lets_go_bussines"); // Gregg: через арбитраж хаба
            // ==>  Помещаем Джона Морриса в Бриджтаун и даём соотв. ноду
            characters[GetCharacterIndex("John Morris")].dialog.currentnode = "Lets_go_bussines";
            // ==>  Заводим таймер на прерывание, даём 31 дней.
            SetTimerCondition("time_over_Beliz_attack", 0, 0, 51, false);
            SaveCurrentQuestDateParam("questTemp");
            NextDiag.TempNode = "Have_hot_bussines";
            pchar.TempPerks.QuestTroopers = true; //перк квестового десанта
            // ==> капитулянтская нода губернатору Белиза
			characters[GetCharacterIndex("Beliz_Mayor")].dialog.captureNode = "EngLine3Quest_BelizAttack"; //капитулянтская нода мэра
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
  		break;

	 	case "time_over_Beliz":    // Геймер не успел взять Венесуэлу
			dialog.text = "Pendant que nous traînions ici, l'or de Belize est parti pour l'Espagne, et sans cet or, Belize ne m'intéresse pas. Tu as fait échouer nos plans, nous partons.";
			link.l1 = "Eh bien, c'est ton droit.";
			link.l1.go = "Step_3_8";
			// выход с палубы
			pchar.quest.Munity = "Deads";
            LAi_LockFightMode(Pchar, false);
        break;

        case "Step_3_8":
			LAi_SetPlayerType(pchar);
            if(IsCompanion(npchar))  {RemoveCharacterCompanion(pchar, npchar);}
            if(IsCompanion(characterFromID("Jackman")))  {RemoveCharacterCompanion(pchar, characterFromID("Jackman"));}
            if(IsCompanion(characterFromID("John Morris")))  {RemoveCharacterCompanion(pchar, characterFromID("John Morris"));}

            QuestToSeaLogin_Prepare(worldMap.playerShipX, worldMap.playerShipZ, worldMap.island);
            if(worldMap.island !=	WDM_NONE_ISLAND)      // если возле острова
            {
                questToSeaLoginer.FromCoast = true;
            }
            else
            {
                questToSeaLoginer.FromCoast = false;
            }
            QuestToSeaLogin_Launch();

            Log_SetStringToLog("Les navires des célèbres corsaires ont quitté l'escadre.");
            // ==> Возвращаем на место Моргана
            ChangeCharacterAddressGroup(npchar, "PortRoyal_houseS1", "sit", "sit2");
            LAi_SetHuberType(npchar);
            // ==> Возвращаем на место Джекмена
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Jackman"))
            {
                LAi_SetHuberType(characterfromID("Jackman"));
				LAi_group_MoveCharacter(characterfromID("Jackman"), "PIRATE_CITIZENS");
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Jackman")], "Pirates_townhall", "sit", "sit1");
                characters[GetCharacterIndex("Jackman")].dialog.currentnode = "First time";
            }
            // ==> Возвращаем на место Джона Морриса
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Morris"))
            {
                LAi_SetHuberType(characterfromID("John Morris"));
				LAi_group_MoveCharacter(characterfromID("John Morris"), "ENGLAND_CITIZENS");
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("John Morris")], "PortSpein_houseF2", "sit", "sit1");
                characters[GetCharacterIndex("John Morris")].dialog.currentnode = "First time";
            }
            AddMoneyToCharacter(pchar, -50000);
            ChangeCharacterReputation(pchar, -20);
            // нулим опыт в авторитете и удаче
            AddCharacterSkill(pchar, SKILL_LEADERSHIP, 0);
            AddCharacterSkill(pchar, SKILL_SNEAK, 0);

            AddQuestRecord("Eng_Line_3_Morgan", "6");
            CloseQuestHeader("Eng_Line_3_Morgan");
            pchar.questTemp.Waiting_time = "2";
            pchar.questTemp.CurQuestNumber = "4";     // идём на четвёртый квест
            DeleteAttribute(pchar, "questTemp.CompanionQuantity");
            DeleteAttribute(pchar, "TempPerks.QuestTroopers");  //снятие перка квестового десанта
			// потом подумаем как дать солдат в помошь...
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
  		break;

	 	case "Gold_found_in_fort":    // Нода разговора в форте Куманы
			dialog.text = "L'or a été trouvé, comme tu l'avais dit, dans le fort. Nous finissons de le charger dans les cales. Tu as du courage et tu te bats avec habileté.";
			link.l1 = "Merci.";
			link.l1.go = "Step_3_9";
        break;

	 	case "Step_3_9":
            if (!IsCompanion(characterFromID("Henry Morgan")))
            {
                dialog.text = "Bon, il est temps de quitter cette ville. Et même si j'ai perdu ici ma magnifique frégate, je considère ce raid comme un succès. Chacun de nous quitte Belize par sa propre route. Adieu, et porte-toi bien.";
            }
            else
            {
            	dialog.text = "Bon, il est temps de quitter cette ville. Nous avons fait ce que nous voulions et nous repartons avec une belle prise. Chacun de nous quitte Belize par sa propre route. Adieu, et porte-toi bien.";
            }
			link.l1 = "Bonne journée, Morgan.";
			link.l1.go = "Step_3_10";
        break;

	 	case "Step_3_10":
            if (GetCargoMaxSpace(pchar) >= RecalculateCargoLoad(pchar))
            {
                dialog.text = "Attends encore une minute. Je me disais : peut-être que ça t'arrangerait de ne pas t'embêter à acheter et vendre ? Si c'est le cas, je suis prêt à te racheter ta part d'or. "+
                              "Ta part d'or s'élève à " + pchar.Ship.Cargo.Goods.gold + " quintaux. Tu voudras peut-être en vendre une partie, voire la totalité ? Je le prends à 200 pièces l'unité de poids.";
            }
            else
            {
                dialog.text = "Attends une minute. Regarde, ton navire s'est enfoncé sous la ligne de flottaison. Tu as trop de charge, tu ne pourras pas aller bien loin du port. "+
                              "La capacité de charge maximale de ton navire est de " + GetCargoMaxSpace(pchar) + " quintaux, et tes cales en contiennent maintenant " + RecalculateCargoLoad(pchar) + " quintaux. "+
                              "Tu as " + pchar.Ship.Cargo.Goods.gold + " quintaux d'or. Pourquoi n'en vendrais-tu pas une partie ? Je le prends à 200 pièces l'unité de poids.";
            }
			link.l1 = "Non, Morgan. Je m'occuperai moi-même de mon or. Adieu.";
			link.l1.go = "out_fort";
			link.l2 = "J'ai vraiment besoin de vendre l'excédent.";
			link.l2.go = "Agree_sale_gold";
			link.l3 = "Laisse-moi réfléchir, je ne peux pas encore te répondre.";
			link.l3.go = "exit";
			NextDiag.TempNode = "Think_sale_gold";
        break;

	 	case "Think_sale_gold":    // ГГ думает о продаже золота
			dialog.text = "Alors, tu as décidé de me vendre de l'or ?";
			link.l1 = "Oh, je vends...";
			link.l1.go = "Agree_sale_gold";
			link.l2 = "Non, Morgan. Je le vendrai ailleurs. Adieu.";
			link.l2.go = "out_fort";
			link.l3 = "Je vais encore y réfléchir un peu...";
			link.l3.go = "exit";
			NextDiag.TempNode = "Think_sale_gold";
        break;

	 	case "Agree_sale_gold":    // ГГ согласен продать золото
			dialog.text = "Bien. Combien d'or veux-tu vendre ?";
			link.l1 = "Je veux bien vendre 25 % de ma part d'or.";
			link.l1.go = "sale_gold_25_persent";
			link.l2 = "Je veux bien vendre 50 % de ma part d'or.";
			link.l2.go = "sale_gold_50_persent";
			link.l3 = "Je veux bien vendre 75 % de ma part d'or.";
			link.l3.go = "sale_gold_75_persent";
			link.l4 = "Je veux bien tout vendre.";
			link.l4.go = "sale_gold_all";
			link.l5 = "Pardon, Morgan, j'ai changé d'avis... Adieu.";
			link.l5.go = "out_fort";
        break;

	 	case "sale_gold_25_persent":
			dialog.text = "Bien, tu m'as vendu un quart de ta part. Eh bien, c'est une bonne affaire pour nous deux. Adieu.";
			link.l1 = "Allons, Morgan. א plus tard.";
			link.l1.go = "out_fort";
			RemoveCharacterGoods(Pchar, GOOD_GOLD, makeint(sti(pchar.questTemp.BelizGoldQty)*0.25));
			AddMoneyToCharacter(pchar, makeint(sti(pchar.questTemp.BelizGoldQty)*0.25*200));
        break;

	 	case "sale_gold_50_persent":
			dialog.text = "Très bien, tu m'as vendu la moitié de ta part. Eh bien, c'est une bonne affaire pour nous deux. Adieu.";
			link.l1 = "Allons, Morgan. א plus tard.";
			link.l1.go = "out_fort";
   			RemoveCharacterGoods(Pchar, GOOD_GOLD, makeint(sti(pchar.questTemp.BelizGoldQty)*0.5));
			AddMoneyToCharacter(pchar, makeint(sti(pchar.questTemp.BelizGoldQty)*0.50*200));
        break;

	 	case "sale_gold_75_persent":
			dialog.text = "Très bien, tu m'as vendu les trois quarts de ta part. Eh bien, c'est une bonne affaire pour nous deux. Adieu.";
			link.l1 = "Allons, Morgan. א plus tard.";
			link.l1.go = "out_fort";
   			RemoveCharacterGoods(Pchar, GOOD_GOLD, makeint(sti(pchar.questTemp.BelizGoldQty)*0.75));
			AddMoneyToCharacter(pchar, makeint(sti(pchar.questTemp.BelizGoldQty)*0.75*200));
        break;

	 	case "sale_gold_all":
			dialog.text = "Tu me vends tout ? C'est parfait ! Une bonne affaire pour nous deux. Adieu.";
			link.l1 = "Allons, Morgan. א plus tard.";
			link.l1.go = "out_fort";
   			RemoveCharacterGoods(Pchar, GOOD_GOLD, sti(pchar.questTemp.BelizGoldQty));
			AddMoneyToCharacter(pchar, makeint(sti(pchar.questTemp.BelizGoldQty)*200));
        break;

	 	case "out_fort":
			pchar.quest.time_over_Beliz_attack_Map_01.over = "yes"; // сброс, если уже откладывали
	        pchar.quest.time_over_Beliz_attack_Map_02.over = "yes";
	        pchar.quest.time_over_Beliz_attack.over = "yes";

			if(IsCompanion(characterFromID("Jackman")))  {RemoveCharacterCompanion(pchar, characterFromID("Jackman"));}
            if(IsCompanion(characterFromID("John Morris")))  {RemoveCharacterCompanion(pchar, characterFromID("John Morris"));}
            AddQuestRecord("Eng_Line_3_Morgan", "7");
            RemoveCharacterCompanion(pchar, npchar);
            // ==> Возвращаем на место Моргана
            ChangeCharacterAddressGroup(npchar, "PortRoyal_houseS1", "sit", "sit2");
            LAi_SetHuberTypeNoGroup(npchar);
            // ==> Возвращаем на место Джекмена
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Jackman"))
            {
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Jackman")], "Pirates_townhall", "sit", "sit1");
                LAi_SetHuberType(characterfromID("Jackman"));
                characters[GetCharacterIndex("Jackman")].dialog.currentnode = "I_know_you_good";
            }
            else
            {
                characters[GetCharacterIndex("Jackman")].dialog.currentnode = "First time";
            }
            // ==> Возвращаем на место Джона Морриса
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Morris"))
            {
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("John Morris")], "PortSpein_houseF2", "sit", "sit1");
                LAi_SetHuberType(characterfromID("John Morris"));
                characters[GetCharacterIndex("John Morris")].dialog.currentnode = "I_know_you_good";
            }
            else
            {
               characters[GetCharacterIndex("John Morris")].dialog.currentnode = "First time";
            }
            ChangeCharacterReputation(pchar, 1);
            AddCharacterExpToSkill(pchar, "Leadership", 20);
            AddCharacterExpToSkill(pchar, "Fencing", 500);
            AddCharacterExpToSkill(pchar, "Pistol", 550);
            AddCharacterExpToSkill(pchar, "Sailing", 550);
            AddCharacterExpToSkill(pchar, "Accuracy", 330);
            AddCharacterExpToSkill(pchar, "Cannons", 150);

            CloseQuestHeader("Eng_Line_3_Morgan");
            pchar.questTemp.Waiting_time = "2";
            pchar.questTemp.CurQuestNumber = "4";     // идём на четвёртый квест
            pchar.questTemp.State = "empty";
            DeleteAttribute(pchar, "questTemp.CompanionQuantity");
            DeleteAttribute(pchar, "questTemp.BelizGoldQty");
            DeleteAttribute(pchar, "TempPerks.QuestTroopers"); //дублирование снятия перка квестового десанта
            LAi_LocationFightDisable(&Locations[FindLocation("Beliz_fort")], false); //вернём боевки
            chrDisableReloadToLocation = false;
            pchar.nation = ENGLAND; // вернём нацию
            InterfaceStates.Buttons.Save.enable = true;   // вернём запись
			DoReloadCharacterToLocation("Beliz_town",  "reload", "gate_back"); //ГГ в город
            NextDiag.CurrentNode = "I_know_you_good";
			DialogExit();
        break;

	 	case "Give_blade":
			dialog.text = GetFullName(pchar) + ", je te suis reconnaissant du fond du cœur. Le vieux Mansfield était un très brave homme et méritait mieux que de finir poignardé par un Espagnol.";
			link.l1 = "Je n'ai vu Mansfield que quelques fois, et je ne le fréquentais pas de près. Mais il m'a semblé être un homme honnête et noble.";
			link.l1.go = "Step_9_1";
        break;

	 	case "Step_9_1":
			dialog.text = "Et c'est vraiment le cas. "+
                          "En récompense d'un tel acte, je te prie d'accepter un cadeau de ma part : ma rapière. Cette lame n'a pas d'égale dans les Caraïbes.";
			link.l1 = "Merci, Morgan. Ce cadeau me fait honneur. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";

            GiveItem2Character(pchar, "blade27");
            RemoveCharacterEquip(NPChar, BLADE_ITEM_TYPE);
            TakeItemFromCharacter(NPChar, "blade27");
            GiveItem2Character(NPChar, "blade22");
            EquipCharacterByItem(NPChar, "blade22");
        break;
		//********************* Голландская линейка *********************
        case "HolLine3_fromMansfield":
            dialog.text = "א quoi dois-je le plaisir de vous voir ici ?";
            link.l1 = "Je viens vous voir de la part d'Edward Mansfield.";
            link.l1.go = "Step_H3_1";
        break;
 	 	case "Step_H3_1":
			dialog.text = "Je vous écoute très attentivement.";
			link.l1 = "Edward vous demande de m'aider. J'ai besoin d'informations sur les plans du gouverneur général de Port Royal, Thomas Madiford. Je voudrais savoir s'il a l'ordre d'ouvrir les hostilités contre les colonies hollandaises et ce qu'il compte faire exactement.";
			link.l1.go = "Step_H3_2";
        break;
 	 	case "Step_H3_2":
			dialog.text = "Hum, ni plus ni moins : c'est précisément ça qui vous intéresse ?!";
			link.l1 = "Oui, c'est cela, monsieur.";
			link.l1.go = "Step_H3_3";
        break;
 	 	case "Step_H3_3":
			dialog.text = "Eh bien, venons-en directement au fait. Mansfield est comme un père pour moi, je suis prêt à beaucoup pour lui. Mais pour la Hollande, je ne suis pas prêt à grand-chose. Alors, si vous voulez que je vous aide, vous devrez travailler pour moi personnellement.";
			link.l1 = "Je n'exécute que les ordres du gouverneur général de Curaçao.";
			link.l1.go = "Step_H3_NoWork";
			link.l2 = "J'exécuterai n'importe lequel de vos ordres.";
			link.l2.go = "Step_H3_4";
        break;
 	 	case "Step_H3_NoWork":
			dialog.text = "Dans ce cas, adieu. Nous n'avons plus rien à nous dire.";
			link.l1 = "Bien dommage...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
    		pchar.questTemp.State = "WormEnglPlans_SurrenderWorkMorgan";
    		AddQuestRecord("Hol_Line_3_WormEnglishPlans", "4");
		AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex", GetSexPhrase("", "e"));
        break;
 	 	case "Step_H3_4":
			dialog.text = "Bien. Voici la mission : un flibustier nommé Pierre Picardy traîne en ce moment à Tortuga. Nous avons participé ensemble à une même affaire, et je soupçonne Picardy d'avoir détourné une partie du butin. "+
                          "Je dois le vérifier. Allez à Tortuga, personne ne vous y connaît vraiment, et tâchez de me rapporter le plus d'informations possible sur Picardy.";
			link.l1 = "Attendez-moi, je reviendrai bientכt avec les résultats.";
			link.l1.go = "exit";
			NextDiag.TempNode = "HolLine3_aboutWorm";
    		pchar.questTemp.State = "WormEnglPlans_WormPicarder";
    		AddQuestRecord("Hol_Line_3_WormEnglishPlans", "6");
		AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex", GetSexPhrase("", "e"));
        break;
 	 	case "HolLine3_aboutWorm":
			dialog.text = "Qu'avez-vous appris ? Comment se porte mon grand ami et collègue Pierre Picardy ?";
            if (CheckAttribute(pchar, "questTemp.Talks"))
            {
    			link.l1 = "Oh, pas mal, il dépense l'argent à droite et à gauche.";
    			link.l1.go = "Step_H3_5";
            }
            else
            {
    			link.l1 = "Je n'ai encore rien pu découvrir d'important...";
    			link.l1.go = "exit";
            }
        break;
 	 	case "Step_H3_5":
            sTemp = "J'ai pu découvrir les faits suivants.";
            if (CheckAttribute(pchar, "questTemp.Talks.Tavern")) sTemp = sTemp + "Pierre Picardy a loué une chambre à la taverne de Tortuga pour un an, payée d'avance.";
            if (CheckAttribute(pchar, "questTemp.Talks.Store")) sTemp = sTemp + "Il achète des bijoux à la boutique de Tortuga presque en gros.";
            if (CheckAttribute(pchar, "questTemp.Talks.Shipyard")) sTemp = sTemp + "Il a fait installer les toutes dernières couleuvrines, très chères, sur sa frégate.";
            if (CheckAttribute(pchar, "questTemp.Talks.Usurer")) sTemp = sTemp + "Il a confié tant d'argent à l'usurier que celui-ci n'accepte plus l'argent de personne.";
            if (CheckAttribute(pchar, "questTemp.Talks.Brothel")) sTemp = sTemp + "C'est un habitué du bordel, et un client bienvenu.";
            dialog.text = "Désormais, je veux que vous me racontiez tout le plus en détail possible. א quoi exactement dépense-t-il son argent ?";
			link.l1 = sTemp;
			link.l1.go = "Step_H3_6";
        break;
 	 	case "Step_H3_6":
            if (CheckAttribute(pchar, "questTemp.Talks.Tavern") && CheckAttribute(pchar, "questTemp.Talks.Store") && CheckAttribute(pchar, "questTemp.Talks.Shipyard") && CheckAttribute(pchar, "questTemp.Talks.Usurer") && CheckAttribute(pchar, "questTemp.Talks.Brothel"))
 	 	    {
    			dialog.text = "Bon, je crois que tout est clair. Picardy n'avait pas une telle somme auparavant, et il ne l'a pas reçue à la suite de l'opération commune. Vu mes soupçons, il aura du mal à justifier de telles dépenses... Je vous remercie.";
    			link.l1 = "Euh, c'est un plaisir d'avoir pu aider. Bon, maintenant, si vous le voulez bien, passons à l'affaire qui m'amène ici, en fait.";
    			link.l1.go = "Step_H3_10";
 	 	    }
            else
            {
                dialog.text = "Compris. Mais cela ne prouve toujours rien avec certitude. Je sais qu'il dispose de telles sommes. Alors, vous devrez retourner à Tortuga et continuer à recueillir des informations.";
    			link.l1 = "J'en ai appris assez pour en tirer les conclusions qui s'imposent.";
    			link.l1.go = "Step_H3_7";
    			link.l2 = "D'accord, je retournerai à Tortuga et je poursuivrai mon enquête.";
    			link.l2.go = "exit";
    		}
        break;
 	 	case "Step_H3_7":
			dialog.text = "Je ne crois pas.";
			link.l1 = "Pierre Picardy a de l'argent.";
			link.l1.go = "Step_H3_8";
        break;
 	 	case "Step_H3_8":
			dialog.text = "Bien sמr qu'il en a, il a reçu sa part. La question, c'est combien.";
			link.l1 = "Je ne pourrai pas le découvrir.";
			link.l1.go = "Step_H3_9";
        break;
 	 	case "Step_H3_9":
			dialog.text = "Dans ce cas, considérez que nous ne nous sommes pas entendus. Par égard pour Mansfield, je n'informerai personne de votre étrange désir d'en savoir autant. Adieu, vous pouvez partir tranquille.";
			link.l1 = "Hum, eh bien, adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			AddQuestRecord("Hol_Line_3_WormEnglishPlans", "12");
            DeleteAttribute(pchar, "questTemp.Talks");
        break;
 	 	case "Step_H3_10":
			dialog.text = "Le fait est que je ne connais pas les plans de Madiford ni les ordres qu'il a reçus concernant la participation à la guerre. Cependant, je sais que Madiford prépare une opération de débarquement avec la garnison de Port Royal.";
			link.l1 = "דa ne me suffit pas, j'ai besoin de savoir exactement ce qu'il manigance.";
			link.l1.go = "Step_H3_11";
        break;
 	 	case "Step_H3_11":
			dialog.text = "Il y a un moyen de le savoir. Un officier anglais, un lieutenant du nom d'Alan McLane, est en ce moment en prison, et il doit se balancer au bout d'une corde demain. Hier, au cours d'une rixe d'ivrognes, il a envoyé un camarade de la garnison rejoindre ses ancêtres. Faites-le sortir de prison, et il vous dira ce qui se passe. Et n'oubliez pas qu'il sera pendu demain.";
			link.l1 = "Je comprends. Merci pour le conseil, Henry.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "13");
            DeleteAttribute(pchar, "questTemp.Talks");
            pchar.questTemp.State = "WormEnglPlans_SaveOfficer";
            sld = GetCharacter(NPC_GenerateCharacter("Alan_MacLine", "off_eng_2", "man", "man", 10, ENGLAND, 1, false));
        	sld.name 	= "Alan";
        	sld.lastname = "McLane";
            sld.Dialog.Filename = "Quest\HolLineNpc_1.c";
        	LAi_SetStayTypeNoGroup(sld);
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Alan_MacLine")], "SentJons_prison", "goto", "goto9");
        break;
        // ==> Квест №6 голландки.
 	 	case "HolLine6_fromStuvesant":
			dialog.text = "Qu'est-ce qui vous amène chez moi cette fois ?";
			link.l1 = "J'ai mandat pour déclarer que les Pays-Bas veulent venger la mort d'Edward Mansfield.";
			link.l1.go = "Step_H6_1";
        break;
 	 	case "Step_H6_1":
			dialog.text = "Eh bien, Edward était hollandais, je comprends... Que comptez-vous faire ?";
			link.l1 = "Je dois coordonner avec vous l'ordre de mes actions.";
			link.l1.go = "Step_H6_2";
        break;
 	 	case "Step_H6_2":
			dialog.text = "Hum, c'est raisonnable. Bon, laissez-moi vous dire ce que je sais moi-même. Les Espagnols ont attaqué la colonie des boucaniers. Le commanditaire et l'organisateur direct de cette attaque est le gouverneur général de Santiago, José Sancho Jiménez : c'est lui qui a conçu et financé cette opération.";
			link.l1 = "Nous allons attaquer Santiago ?";
			link.l1.go = "Step_H6_3";
        break;
 	 	case "Step_H6_3":
			dialog.text = "Peut-être. Cependant, nous ne devons pas nous précipiter : il y a déjà la queue pour la tête du gouverneur général de Santiago. Les Anglais veulent aussi son sang, mais vous êtes en guerre avec l'Angleterre, et une action commune est impossible. Il faut donc répartir clairement les rכles dans cette partie.";
			link.l1 = "Oui, Jiménez est dans de sales draps.";
			link.l1.go = "Step_H6_4";
        break;
 	 	case "Step_H6_4":
			dialog.text = "Héhé, c'est bien vrai. Bon, si vous voulez participer à cette affaire, vous devriez mener une mission de reconnaissance.";
			link.l1 = "Que dois-je faire exactement ?";
			link.l1.go = "Step_H6_5";
        break;
 	 	case "Step_H6_5":
			dialog.text = "Vous devez vous rendre à Santiago et découvrir si le gouverneur général de cette ville, le fameux José Sancho Jiménez, est sur place. L'attaque doit avoir lieu précisément quand le gouverneur général est en ville. Il est donc souhaitable de connaître son emploi du temps dans un avenir proche.";
			link.l1 = "Tout est clair. Je reviendrai bientכt vous voir avec les informations nécessaires.";
			link.l1.go = "exit";
            AddQuestRecord("Hol_Line_6_RevengeMansfield", "2");
			AddQuestUserData("Hol_Line_6_RevengeMansfield", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State = "RevengeMansfield_toTavern";
            NextDiag.TempNode = "I_know_you_good";
            LAi_group_MoveCharacter(characterFromID("Santiago_tavernkeeper"), "QuestGroup");
            LAi_group_MoveCharacter(characterFromID("Santiago_waitress"), "QuestGroup");
        break;
 	 	case "HolLine6_fromSantiago":
			dialog.text = "Alors, dites-moi vite ce que vous avez appris.";
			link.l1 = "Jiménez est en ville et ne compte pas partir de sitכt. Une fête municipale est prévue à Santiago, et on ne peut pas s'y passer du gouverneur général.";
			link.l1.go = "Step_H6_6";
        break;
 	 	case "Step_H6_6":
			dialog.text = "Parfait ! Eh bien, vous avez fait mon affaire, merci. Votre contribution importante à cette sainte cause sera appréciée par les Frères de la Cכte.";
			link.l1 = "C'est une joie d'avoir pu vous aider. Alors, et l'assaut de la ville ?";
			link.l1.go = "Step_H6_7";
        break;
 	 	case "Step_H6_7":
			dialog.text = "Ce n'est plus votre affaire, vous avez fait votre travail. Mansfield sera vengé.";
			link.l1 = "Je comprends. Adieu, Morgan.";
			link.l1.go = "exit";
            pchar.questTemp.State = "RevengeMansfield_FromMorganWithResult";
            AddQuestRecord("Hol_Line_6_RevengeMansfield", "4");
            NextDiag.TempNode = "I_know_you_good";
        break;
		//********************* Французская линейка *********************
        case "FraLine8_talk":
            dialog.text = "Bonjour, capitaine " + GetFullName(pchar) + " ! דa fait longtemps que je t'ai à l'œil. Jusqu'ici, tu n'as pas fourré ton nez dans mes affaires, c'est pour ça que tu es toujours en pleine forme. Dis-moi pourquoi tu es là. Pas pour bavarder, je suppose.";
            link.l1 = "וcoute, Morgan, tu sais bien que je ne viendrais pas te déranger pour rien. Je suis là pour affaires.";
            link.l1.go = "Step_F8_1";
        break;
        case "Step_F8_1":
            dialog.text = "Déballe...";
            link.l1 = "Que penses-tu de l'escarmouche anglo-hollandaise qui se prépare ?";
            link.l1.go = "Step_F8_2";
        break;
        case "Step_F8_2":
            dialog.text = "Toi aussi, tu es au courant... Eh bien, je peux te dire que les Hollandais ne nous gênent pas dans ces eaux ; au contraire, ils nous sont utiles : ce sont eux qui font tourner tout le commerce dans ces parages. Alors, l'idée même de la guerre ne me plaît pas, et les militaires anglais ne pourront pas vraiment embêter les Hollandais : ils ne feront que verser un sang inutile, pour le plus grand plaisir des Espagnols. "+
				          "Cependant, je crois que ce vieux renard de Madiford va essayer de tirer les marrons du feu avec les mains des autres.";
            link.l1 = "C'est bien ça, c'est bien ça. On pense qu'il va essayer d'utiliser les Frères de la Cכte dans cette guerre.";
            link.l1.go = "Step_F8_3";
        break;
        case "Step_F8_3":
            dialog.text = "C'est bien possible...";
            link.l1 = "Henry, je ne veux pas tourner autour du pot. J'ai besoin que tu ne prennes pas part à l'attaque contre les Hollandais. דa me fait plaisir que cette guerre ne t'intéresse pas...";
            link.l1.go = "Step_F8_4";
        break;
        case "Step_F8_4":
            dialog.text = "Hum, il y a un problème : cette guerre me déplaît, mais je ne dirais pas qu'elle ne m'intéresse pas. Le fait est que ma bande d'ivrognes a déjà dépensé ses dernières piastres dans les tavernes, et nous n'avons pas eu de grosse affaire depuis longtemps. Cependant, celui qui t'a envoyé me dissuader a sמrement prévu ce cas de figure ?";
            link.l1 = "Oui, sans me donner un sou pour autant. Mais ça, c'est mon problème. Combien faudrait-il à tes gaillards pour faire la fête à terre et ne pas se mêler de la grande politique ?";
            link.l1.go = "Step_F8_5";
        break;
        case "Step_F8_5":
            dialog.text = "Ils se fichent complètement de la politique, et 250 000, je pense, suffiront pour une ou deux semaines.";
            link.l1 = "J'ai l'intention de te dédommager des pertes que te causera ta non-agression envers les Hollandais.";
            link.l1.go = "Step_F8_6";
        break;
        case "Step_F8_6":
            dialog.text = "250 000 sur le tonneau, et je passe mon tour dans les affaires hollandaises de Madiford.";
			if (sti(pchar.money) >= 250000)
			{
				link.l1 = "Eh bien, tes gars sont costauds pour descendre le rhum ! Prends l'argent, et souviens-toi : c'est un marché d'honneur.";
				link.l1.go = "Step_F8_7";
				AddMoneyToCharacter(pchar, -250000);
			}
			else
			{
				link.l1 = "Je n'ai pas assez d'argent en ce moment, mais je vais forcément le trouver et te le donner. Alors, attends un peu.";
				link.l1.go = "exit";
				NextDiag.TempNode = "Step_F8_6";
			}
        break;
        case "Step_F8_7":
            dialog.text = "Depuis quand me parle-t-on d'honneur ? Tu parles, tu parles...";
            link.l1 = "Pardon, Henry, je ne voulais pas te vexer. Bon, adieu, et porte-toi bien.";
            link.l1.go = "exit";
			pchar.questTemp.Count = makeint(pchar.questTemp.Count)+1;
			NextDiag.TempNode = "I_know_you_good";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "4");
        break;
		//********************* Пиратская линейка *********************
		//квест №1, диалог в тюрьме
		case "PL_Q1_1":
			dialog.text = "Eh bien, "+ GetSexPhrase("le gars","la fille") +", te voilà dans de beaux draps. Tu as bien fait de ne pas résister. Heureusement que j'ai beaucoup d'amis à Port Royal, et le commandant m'a aussitכt prévenu. Alors, la question de ta libération est déjà réglée.";
			link.l1 = "Et John Bolton ? Je te l'amenais.";
			link.l1.go = "PL_Q1_2";
		break;
		case "PL_Q1_2":
			dialog.text = "Je le libérerai aussi... plus tard. Quelqu'un a essayé de me piéger, et je vais découvrir qui. Maintenant, parlons de toi. J'aurai une mission pour toi, je te préviens tout de suite : je n'accepterai pas de refus, j'ai besoin "+ GetSexPhrase("de gars qui ont du sang-froid","de corsaires qui ont du sang-froid") +". Règle tes affaires et viens me voir.";
			link.l1 = "D'accord, je vais juste me laver de cette moisissure de cachot. Et, Morgan, Goodley a dit que tu me rembourserais.";
			link.l1.go = "PL_Q1_3";
		break;
		case "PL_Q1_3":
			dialog.text = ""+ GetSexPhrase("Oh, merde, j'allais oublier... Garde en tête qu'il y a un bordel chic à Port Royal. Alors, ne perds pas ton temps.","Salut, capitaine !") +"";
			link.l1 = ""+ GetSexPhrase("D'accord, je m'en souviendrai","Salut, Morgan") +"."
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q2_1";
			AddMoneyToCharacter(PChar, 10000);
			AddDialogExitQuestFunction("PiratesLine_q1_MorganEnd");
		break;
		//квест №2, диалог в резиденции Порт Рояля.
		case "PL_Q2_1":
			CloseQuestHeader("Pir_Line_1_JohnBolton");
			dialog.text = "Te voilà. C'est bien. J'ai déjà appris quelque chose sur Bolton. Maintenant, tu dois aller en Martinique. Il y a là-bas un escroc, il s'appelle Edward Law. Quand tu l'auras trouvé, remets-lui une marque noire de ma part.";
			link.l1 = "Je peux lui transmettre quelque chose de vive voix ?";
			link.l1.go = "PL_Q2_2";
		break;
		case "PL_Q2_2":
			dialog.text = "Héhé, mais quelles paroles peut-il y avoir quand on remet une MARQUE NOIRE ?! דa suffit à soi seul. Mais inutile de le tuer, qu'il se fasse un peu de mauvais sang. Mes hommes s'en chargeront eux-mêmes le moment venu. Oui, dis-lui quand même de venir me voir s'il tient à la vie. Voilà, vas-y, une récompense t'attendra à ton retour.";
			link.l1 = "Je comprends. C'est ce que je vais faire.";
			link.l1.go = "exit";
			sld = GetCharacter(NPC_GenerateCharacter("EdwardLoy", "reservist_1", "man", "man", 20, PIRATE, -1, true));
			int iRank = sti(PChar.rank) + MOD_SKILL_ENEMY_RATE*3;
			FantomMakeCoolFighter(sld, iRank, 70, 70, "blade25", "pistol3", 50);
			FantomMakeCoolestSailor(sld, SHIP_BRIGSW, "Loup des Mers", CANNON_TYPE_CANNON_LBS20, 70, 70, 70);
			sld.name = "Edward";
			sld.lastname = "Law";
			sld.city = "LeFransua";
			sld.location	= "LeFransua_House4";
			sld.location.group = "goto";
			sld.location.locator = "goto1";
			sld.dialog.filename   = "Quest\PiratesLine_dialog.c";
			sld.dialog.currentnode   = "EdwardLoy";
			sld.greeting = "Gr_EvilPirate";
			sld.AlwaysSandbankManeuver = true;
			sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
			sld.ship.Crew.Morale = 70;
			ChangeCrewExp(sld, "Sailors", 100);
			ChangeCrewExp(sld, "Cannoners", 70);
			ChangeCrewExp(sld, "Soldiers", 70);
			LAi_SetWarriorType(sld);
			GiveItem2Character(pchar, "BlackLabel");
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			pchar.questTemp.piratesLine = "BlackLabel_toLaVega";
            SetQuestHeader("Pir_Line_2_BlackLabel");
            AddQuestRecord("Pir_Line_2_BlackLabel", "1");
			NextDiag.TempNode = "PL_Q2_wait";
		break;
		case "PL_Q2_wait":
			dialog.text = "Tu as remis la marque noire ?";
			link.l1 = "Pas encore, Morgan, je m'en occupe...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q2_wait";
		break;

		case "PL_Q2_away_1":
			dialog.text = "Ah, " + GetFullName(PChar) + ", je te salue. Alors, raconte, Law était-il en Martinique ?";
			link.l1 = "Il y était, je lui ai remis la marque.";
			link.l1.go = "PL_Q2_away_2";
			CloseQuestHeader("Pir_Line_2_BlackLabel");
		break;
		case "PL_Q2_away_2":
			dialog.text = "Et comment a-t-il réagi ?";
			link.l1 = "Eh bien, je ne dirais pas qu'il était ravi.";
			link.l1.go = "PL_Q2_away_3";
		break;
		case "PL_Q2_away_3":
			dialog.text = "Oui, je n'en doute pas. Cependant, tous les délais sont écoulés, et il n'est pas venu me voir. Bon, alors, il est temps de délivrer une licence pour sa capture. Tu ne veux pas participer ?";
			link.l1 = "Hum, pourquoi pas ? J'espère que la récompense sera à la hauteur ?";
			link.l1.go = "PL_Q2_away_4";
		break;
		case "PL_Q2_away_4":
			dialog.text = "Oui, à propos de récompense. Voici ce qui t'est dמ pour la remise de la marque.";
			link.l1 = "Merci... Et alors, cette nouvelle mission ?";
			link.l1.go = "PL_Q2_away_5";
			//AddMoneyToCharacter(PChar, 15000);
			TakeNItems(pchar, "chest", 1);
			Log_Info("Vous avez reçu un coffre de crédit");
			PlaySound("interface\important_item.wav");
		break;
		case "PL_Q2_away_5":
			dialog.text = "J'ai déjà fait cette offre à plusieurs de mes gars, je t'invite à te joindre à l'affaire. Celui qui m'apportera la tête de Law recevra une récompense de cinquante mille pièces d'or.";
			link.l1 = "Hum, il faut vraiment la tête ? Il n'est déjà pas très beau de son vivant, et je pense qu'il le sera encore moins une fois mort...";
			link.l1.go = "PL_Q2_away_6";
		break;
		case "PL_Q2_away_6":
			dialog.text = "Non, bien sמr que non. C'était une façon de parler, au sens figuré.";
			link.l1 = "Bon, bien sמr que je marche.";
			link.l1.go = "exit";
            SetQuestHeader("Pir_Line_3_KillLoy");
            AddQuestRecord("Pir_Line_3_KillLoy", "1");
			AddQuestUserData("Pir_Line_3_KillLoy", "sSex", GetSexPhrase("", "e"));
			NextDiag.TempNode = "PL_Q2_awaywait";
			pchar.questTemp.piratesLine = "KillLoy_toHouse";
			ChangeCharacterAddress(characterFromId("EdwardLoy"), "none", "");
			pchar.quest.PiratesLine_q3_LoyHouse.win_condition.l1 = "location";
			pchar.quest.PiratesLine_q3_LoyHouse.win_condition.l1.location = "LeFransua_House4";
			pchar.quest.PiratesLine_q3_LoyHouse.function = "PiratesLine_q3_LoyHouse";
		break;
		case "PL_Q2_awaywait":
			dialog.text = "Edward Law est mort ?";
			link.l1 = "Pas encore, Morgan, mais ça ne saurait tarder.";
			link.l1.go = "exit";
			link.l2 = "Tu sais, Morgan, j'en ai assez de tout ça. Je n'ai pas trouvé Law, et je n'ai plus la force de le chercher...";
			link.l2.go = "PL_Q3_notFound";
			NextDiag.TempNode = "PL_Q2_awaywait";
		break;

		case "PL_Q3_notFound":
			dialog.text = "Tu fais grise mine, tu as raté Law ?";
			link.l1 = "Je l'ai raté...";
			link.l1.go = "PL_Q3_notFound_1";
		break;
		case "PL_Q3_notFound_1":
			dialog.text = "Eh bien, je m'en doutais. Tu n'aurais peut-être pas dמ accepter ce genre de missions ; ton élément, ce sont peut-être les raids, les abordages, les combats ? L'avenir le dira. Va, un jour, peut-être, je te donnerai une autre chance.";
			link.l1 = "Merci pour ça, Morgan...";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "waiting_Q4";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			CloseQuestHeader("Pir_Line_3_KillLoy");
		break;

		case "PL_Q3_GoodWork":
			dialog.text = "א voir ta "+ GetSexPhrase("mine radieuse","mine radieuse") +", on comprend que tout s'est bien passé.";
			link.l1 = "Oui ! Edward Law est mort !";
			link.l1.go = "PL_Q3_GoodWork_1";
		break;
		case "PL_Q3_GoodWork_1":
			dialog.text = "Excellente nouvelle. Tu as dמ transpirer ? On dit que c'était un bon combattant et un capitaine habile.";
			link.l1 = "J'ai dמ travailler dur pour le faire sortir de son trou. Ensuite, le travail habituel, car l'argent ne saute pas tout seul dans la poche. Et puis, autre chose. Law disait que beaucoup de pirates sont mécontents de toi.";
			link.l1.go = "PL_Q3_GoodWork_2";
		break;
		case "PL_Q3_GoodWork_2":
			dialog.text = "Vois-tu, " + GetFullName(pchar) + ", c'est une question philosophique à part... " +
				"Je vais essayer de t'expliquer simplement. Même si tu n'as que deux subordonnés qui font le même travail et reçoivent la même paie, ils trouveront déjà une raison d'être mécontents de toi. Et tous les deux ! L'un, le moins paresseux, pensera que tu paies le paresseux plus qu'il ne le mérite. Le paresseux, lui, pensera que pour le même travail, il devrait gagner plus que son camarade, car il y dépense plus d'énergie. " +
				"Bref, tu ne contenteras pas tout le monde, et il ne faut pas chercher à le faire. Et toi, tu as honnêtement mérité ta récompense. Garde cette collection de bijoux. Et passe me voir de temps en temps, j'aurai peut-être bientכt une mission pour toi.";
			link.l1 = "D'accord, Morgan, merci !";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "waiting_Q4";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			CloseQuestHeader("Pir_Line_3_KillLoy");
			//AddMoneyToCharacter(PChar, 50000);
			TakeNItems(pchar, "icollection", 1);
			Log_Info("Vous avez reçu le trésor");
			PlaySound("interface\important_item.wav");
		break;
		//квест №4, жемчужные тартаны
		case "PL_Q4_1":
			dialog.text = "Oui. J'ai justement besoin de quelqu'un comme toi. Je te préviens tout de suite, il n'y a pas beaucoup de travail, mais le revenu est bon. Si on faisait concurrence au meilleur pirate de tous les temps, M. Bartholomew Sharp ? Bref, je sais oם se trouveront les tartanes des pêcheurs de perles pendant le mois qui vient.";
			link.l1 = "L'argent ne traîne pas sur la route. Et oם est-ce ?";
			link.l1.go = "PL_Q4_3";
		break;
		case "PL_Q4_3":
			dialog.text = "Aux îles Turques, dans la baie Nord. Alors, vas-y et fais un peu de bruit dans la pêcherie. Je t'attends avec un tas de perles.";
			link.l1 = "Allons-y !";
			link.l1.go = "PL_Q4_4";
		break;
		case "PL_Q4_4":
			dialog.text = "D'après mes calculs, ils devraient avoir à ce moment-là au moins mille petites perles et cinq cents grosses. Alors, fais de ton mieux. Le butin, moitié-moitié.";
			link.l1 = "Je comprends. Je lève déjà l'ancre.";
			link.l1.go = "PL_Q4_5";
		break;

		case "PL_Q4_5":
			dialog.text = "Attends. Au cas oם, je veux te prévenir. N'essaie pas de cacher ne serait-ce qu'une seule perle récupérée ! Si tu savais combien de gens se sont fait tuer pour une petite cupidité...";
			link.l1 = "Je m'en souviendrai. Même si tu n'avais pas besoin de le dire.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q4_wait";
			pchar.questTemp.piratesLine = "PearlQ4_toTerks"; //флаг квеста
			pchar.questTemp.Sharp.PearlAreal = "Terks";
			pchar.questTemp.Sharp.PearlAreal.Island = "Terks";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore56";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_1";
			pchar.questTemp.Sharp.PearlAreal.terms = 30; //сроки
			pchar.questTemp.Sharp.PearlAreal.qtyShips = 9; //кол-во тартан ловцов
			pchar.questTemp.Sharp.PearlAreal.SmallPearlQty = 0; //для итогового подсчёта
			pchar.questTemp.Sharp.PearlAreal.BigPearlQty = 0;
			SetQuestHeader("Pir_Line_4_Pearl");
			AddQuestRecord("Pir_Line_4_Pearl", "1");
			AddQuestUserData("Pir_Line_4_Pearl", "sSex", GetSexPhrase("", "e"));
			pchar.quest.PQ4_SeaPearl_login.win_condition.l1 = "location";
			pchar.quest.PQ4_SeaPearl_login.win_condition.l1.location = "Terks";
			pchar.quest.PQ4_SeaPearl_login.function = "PQ4_SeaPearl_login";
			SetTimerFunction("PQ4_SeaPearl_Late", 0, 0, sti(pchar.questTemp.Sharp.PearlAreal.terms));
		break;

		case "PL_Q4_wait":
			dialog.text = "Tu as dépouillé les pêcheurs de perles ?";
			link.l1 = "Pas encore, Morgan, je m'en occupe...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q4_wait";
		break;
		//опоздал
		case "PL_Q4_late":
			dialog.text = "Alors, qu'as-tu à dire ?";
			link.l1 = "Henry, il se trouve que j'ai raté le rendez-vous aux îles Turques.";
			link.l1.go = "PL_Q4_late_1";
		break;
		case "PL_Q4_late_1":
			dialog.text = ""+ GetSexPhrase("L'ami","Ma belle") +", tu manques vraiment de sérieux !.. Mais c'est ma faute. J'ai tant de gars à ma disposition, et c'est à toi que j'ai confié cette affaire. Je serai plus prudent la prochaine fois.";
			link.l1 = "Henry, j'ai vraiment eu des circonstances particulières...";
			link.l1.go = "PearlQ4_late_2";
		break;
		case "PearlQ4_late_2":
			dialog.text = "Forcément. Ce sera pour une autre fois. En attendant, va-t'en loin d'ici, je n'ai pas la tête à toi...";
			link.l1 = "Bien, amiral...";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "waiting_Q5";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			CloseQuestHeader("Pir_Line_4_Pearl");
			//дача пятого квеста
            Pchar.quest.PQ5_meetInPortRoyal.win_condition.l1 = "location";
            Pchar.quest.PQ5_meetInPortRoyal.win_condition.l1.location = "PortRoyal_town";
            Pchar.quest.PQ5_meetInPortRoyal.function = "PQ5_meetInPortRoyal";
		break;
		//неудачный наезд
		case "PL_Q4_badWork":
			dialog.text = "Alors, oם en es-tu avec les perles ?";
			link.l1 = "Mal. Ces maudites tartanes se sont dispersées devant moi. Je n'en ai rattrapé aucune.";
			link.l1.go = "PL_Q4_badWork_1";
		break;
		case "PL_Q4_badWork_1":
			dialog.text = ""+ GetSexPhrase("L'ami","Ma belle") +", tu manques vraiment de sérieux ! Il fallait se préparer ! Mais c'est ma faute. J'ai tant de gars à ma disposition, et c'est à toi que j'ai confié cette affaire. Je serai plus prudent la prochaine fois.";
			link.l1 = "Henry, c'est mon erreur. Mais je t'en supplie, ne tire pas de conclusions hâtives ! Je vais rattraper la situation.";
			link.l1.go = "PearlQ4_late_2";
		break;
		//удачный наезд
		case "PL_Q4_goodWork":
			dialog.text = "Alors... Oם sont les perles, "+ GetSexPhrase("l'ami","" + pchar.name + "") +" ?";
			if (!CheckAttribute(pchar, "items.jewelry12") || !CheckAttribute(pchar, "items.jewelry11"))
			{
				link.l1 = "Tu sais, Henry, tout est allé de travers. Il y a des problèmes avec les perles, en somme... Elles ne sont pas là.";
				link.l1.go = "PL_Q4_goodWork_lair";
			}
			else
			{
				link.l1 = "Je les ai toutes. En tout, j'ai récolté " + pchar.items.jewelry12 + " petites et " + pchar.items.jewelry11 + " grosses perles !";
				link.l1.go = "PL_Q4_goodWork_1";
			}
		break;

		case "PL_Q4_goodWork_lair":
			dialog.text = "Alors, tu es un rat ! Tu me prends pour un idiot ? Tu crois que je ne sais pas que tu as mené l'opération ?!";
			link.l1 = "Henry, ne t'emballe pas...";
			link.l1.go = "PL_Q4_goodWork_lair_1";
		break;
		case "PL_Q4_goodWork_lair_1":
			dialog.text = "Ne pas m'emballer ?!! Eh bien, tu ne manques pas de culot. וcoute-moi bien, sale rat, c'en est fini de toi. Je vais te tuer de mes propres mains... Fermez les portes !";
			link.l1 = "Henry, Henry !..";
			link.l1.go = "fight";
			chrDisableReloadToLocation = true;
			pchar.questTemp.piratesLine = "over";
		break;

		case "PL_Q4_goodWork_1":
			if (sti(pchar.items.jewelry12) < sti(pchar.questTemp.piratesLine.Qty.SmallPearl) || sti(pchar.items.jewelry11) < sti(pchar.questTemp.piratesLine.Qty.BigPearl))
			{
				dialog.text = "Euh, attends, j'ai d'autres informations. Tu as obtenu " + pchar.questTemp.piratesLine.Qty.SmallPearl + " petites et " + pchar.questTemp.piratesLine.Qty.BigPearl + " grosses perles de ce pillage. Qu'est-ce que tu en dis ?";
				link.l1 = "Allons, Henry ! Je te dis la vérité.";
				link.l1.go = "PL_Q4_goodWork_2";
			}
			else
			{
				if (sti(pchar.items.jewelry12) >= 1000 && sti(pchar.items.jewelry11) >= 500)
				{
					dialog.text = "Parfait, tu as fait du bon travail. De plus, tu as rempli le « plan de récolte » : il y a au moins la quantité de perles prévue. Bravo, que dire de plus !";
					link.l1 = "Comment pourrait-il en être autrement ?";
					link.l1.go = "PL_Q4_goodWork_3";
				}
				else
				{
					dialog.text = "Euh, je ne peux pas dire que je sois content. Tu n'as pas atteint le plan prévu de 1000 petites et 500 grosses perles. Alors, désolé, mais je prends tout pour moi...";
					link.l1 = "Bon sang ! Mais j'ai fait ce travail !";
					link.l1.go = "PL_Q4_goodWork_5";
				}
			}
		break;
		case "PL_Q4_goodWork_2":
			dialog.text = "Ce n'est pas mon avis. Mes informations sont d'une exactitude exceptionnelle. Tu as volé des perles. La seule punition pour ça, c'est la mort. Bon, fermez les portes, maintenant, je vais écraser ce rat...";
			link.l1 = "Henry, qu'est-ce que tu fais ?!..";
			link.l1.go = "fight";
			chrDisableReloadToLocation = true;
			pchar.questTemp.piratesLine = "over";
		break;

		case "PL_Q4_goodWork_3":
			dialog.text = "La moitié du butin est à toi, comme convenu. Le reste est à moi.";
			link.l1 = "Parfait ! Bon, amiral, je crois que je vais y aller.";
			link.l1.go = "PL_Q4_goodWork_4";
			TakeNItems(pchar, "jewelry12", -makeint(sti(pchar.items.jewelry12)/2));
			TakeNItems(pchar, "jewelry11", -makeint(sti(pchar.items.jewelry11)/2));
		break;
		case "PL_Q4_goodWork_4":
			dialog.text = "N'oublie pas de passer me voir. Il y aura peut-être autre chose.";
			link.l1 = "D'accord. Je passerai sמrement quand l'argent sera épuisé.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "waiting_Q5";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			CloseQuestHeader("Pir_Line_4_Pearl");
			//дача пятого квеста
            Pchar.quest.PQ5_meetInPortRoyal.win_condition.l1 = "location";
            Pchar.quest.PQ5_meetInPortRoyal.win_condition.l1.location = "PortRoyal_town";
            Pchar.quest.PQ5_meetInPortRoyal.function = "PQ5_meetInPortRoyal";
		break;
		case "PL_Q4_goodWork_5":
			dialog.text = "Tu as mal travaillé, "+ GetSexPhrase("l'ami","ma petite") +" ! Je comptais sur un tout autre revenu. Et si tu as laissé filer des tartanes, c'est sur ta part. Bref, inutile de discuter, je prends les perles...";
			link.l1 = "Hum, bon, je n'ai pas le choix, je cède... Je peux partir, maintenant ?";
			link.l1.go = "PL_Q4_goodWork_4";
			TakeNItems(pchar, "jewelry12", -sti(pchar.items.jewelry12));
			TakeNItems(pchar, "jewelry11", -sti(pchar.items.jewelry11));
		break;
		//квест №5, ГГ-ОЗГ. базар после дела
		case "PL_Q5_begin":
			dialog.text = "Ah, te voilà enfin. J'ai à te parler, " + PChar.Name + ", et ce sera une conversation plutכt désagréable.";
			link.l1 = "Que s'est-il passé ?";
			link.l1.go = "PL_Q5_begin_1";
		break;
		case "PL_Q5_begin_1":
			dialog.text = "On m'a informé que tu avais tué John Avory, après l'avoir longtemps traqué. C'est vrai ?!";
			link.l1 = "Oui, c'est vrai. J'avais un contrat sur lui. Et qu'est-ce qui ne va pas, exactement ?";
			link.l1.go = "PL_Q5_begin_2";
		break;
		case "PL_Q5_begin_2":
			dialog.text = "Qui t'a passé ce contrat ?";
			link.l1 = "Henry, tu sais bien que ces choses-là ne s'ébruitent pas.";
			link.l1.go = "PL_Q5_begin_3";
		break;
		case "PL_Q5_begin_3":
			dialog.text = "Qui est le commanditaire ?! Je te le demande !!!";
			link.l1 = "Le capitaine Goodley.";
			link.l1.go = "PL_Q5_begin_4";
		break;
		case "PL_Q5_begin_4":
			dialog.text = "Vraiment ?! Depuis quand travailles-tu pour le capitaine Goodley ? Je croyais que tu étais des miens ! Tu ne le savais peut-être pas, bien sמr, mais John Avory aussi était des miens ! Bon, si vous vous étiez battus en duel, ça arrive. Mais tuer un membre des Frères de la Cכte pour de l'argent ! Je vengerai cruellement sa mort.";
			link.l1 = "Diable !!! Mais je ne savais pas qu'Avory était des tiens !";
			link.l1.go = "PL_Q5_begin_5";
		break;
		case "PL_Q5_begin_5":
			dialog.text = "Admettons que tu ne le savais pas. Mais pourquoi diable as-tu fait confiance à Goodley ?! J'ai mené ma petite enquête quand on m'a informé de la mort d'Avory. Mais je ne vois pas QUI est le véritable commanditaire de toute cette agitation, qui essaie de déplacer les pièces sur mon échiquier ?!! Je l'avoue, c'est du travail fin. וliminer deux pièces d'un seul coup : toi et Avory. Deux de MES pièces, bon sang ! Qu'a dit Goodley sur le véritable commanditaire ?";
			link.l1 = "Rien. Je lui ai demandé, mais il n'a rien avoué.";
			link.l1.go = "PL_Q5_begin_6";
		break;
		case "PL_Q5_begin_6":
			dialog.text = "Bon. Oliver, ordonne à Goodley de venir ici immédiatement ! On va tirer ça au clair sur place, pour ainsi dire... Toi, mets-toi à l'écart pour l'instant.";
			link.l1 = "Maintenant, je comprends pourquoi ce chacal ricanait tout le temps.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q5_talking";
			AddDialogExitQuestFunction("PQ5_Morgan_1");
		break;

		case "PL_Q5_talking":
			sld = characterFromId("Blaze");
			dialog.text = "Oh, quelle visite ! Merci d'être passé. Dis-moi, notre ami Goodley, quelle mission as-tu confiée à " + GetMainCharacterNameDat() + " ?";
			link.l1 = "Moi ?!! Il n'y a rien eu de tel, amiral. Je n'ai jamais rien demandé de tel, et surtout pas à "+ NPCharSexPhrase(sld, "lui","lui") +" !";
			link.l1.go = "PL_Q5_talking_1";
		break;
		case "PL_Q5_talking_1":
			sld = characterFromId("Blaze");
			dialog.text = ""+ NPCharSexPhrase(sld, "Il","Elle") +" affirme que tu lui as donné l'ordre, contre de l'argent, d'éliminer John Avory. Tu ne t'en souviens pas ?";
			link.l1 = "Je suis malade, ou quoi ? Non, bien sמr que non ! Cette ordure essaie de me piéger !";
			link.l1.go = "PL_Q5_talking_2";
		break;

		case "PL_Q5_talking_2":
			sld = characterFromId("Blaze");
			dialog.text = "Bon, Goodley, ne te tortille pas. Je sais tout. J'ai interrogé des gens de ton entourage. Ils ont confirmé que c'était toi qui avais prévu de te débarrasser de " + GetMainCharacterNameGen() + " et d'Avory. Tu savais qu'aucun des deux n'était à ta portée, alors tu as eu l'idée d'éliminer l'un par la main de l'autre ! Tu savais aussi que je vengerais la mort de n'importe lequel d'entre eux, et qu'ainsi l'autre ne vivrait pas non plus. "+"Bon, tout est assez clair. Dis-moi plutכt qui t'a payé pour cette intrigue. Qui voudrait monter mes gens les uns contre les autres ?! Et combien as-tu touché pour ce coup habile ?!";
			link.l1 = "Amiral, c'est un malentendu ! On me calomnie ! Tu me connais depuis tant d'années, tu vas vraiment croire "+ NPCharSexPhrase(sld, "ce blanc-bec ","cette donzelle ") +" ?!";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q5_end";
			AddDialogExitQuestFunction("PQ5_Morgan_4");
		break;

		case "PL_Q5_end":
			dialog.text = "" + GetFullName(pchar) + " ! Combien t'a-t-il payé pour la mort d'Avory ?";
			link.l1 = "Quinze mille.";
			link.l1.go = "PL_Q5_end_1";
		break;
		case "PL_Q5_end_1":
			dialog.text = "Hum, je commence à croire que je paie ton travail trop généreusement, puisque tu as accepté d'affronter l'un des meilleurs combattants de l'archipel pour une telle misère.";
			link.l1 = "Mais nous nous étions mis d'accord sur cinquante.";
			link.l1.go = "PL_Q5_end_2";
		break;
		case "PL_Q5_end_2":
			dialog.text = "Oui, c'est parfait ! Puisqu'il ne te paiera pas de toute façon, je te charge, pour trente-cinq mille pièces d'or, de tuer cette crapule, ce rat de capitaine Goodley. Tu peux commencer ici même, je ne suis pas délicat.";
			link.l1 = "Ha, je le ferais même sans être payé !";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q5_end_3";
			AddDialogExitQuestFunction("PQ5_Morgan_5");
		break;

		case "PL_Q5_end_3":
			dialog.text = "D'abord, il faut finir le travail...";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q5_end_3";
		break;

		case "PL_Q5_afterFight":
			dialog.text = "Prends ton argent, je te prie. Oliver ! Apporte 35 000 pièces d'or pour le capitaine " + GetMainCharacterNameGen() + ". Eh bien, la chance était de ton cכté aujourd'hui : une crapule de moins.";
			link.l1 = "Oui, c'est vrai. Mais je me demandais ce qui se serait passé si tu n'avais pas enquêté ?";
			link.l1.go = "PL_Q5_afterFight_1";
			AddMoneyToCharacter(PChar, 35000);
		break;
		case "PL_Q5_afterFight_1":
			dialog.text = "Je vais être honnête : je ne sais PAS ce qui se serait passé si je n'avais pas mené d'enquête. Bon, ne te tracasse pas. De toute façon, tu ne sais pas mentir. Même un idiot peut le comprendre. Oui, ce n'est pas tout : va voir Jackman. Il a eu des ennuis, là-bas, dans lesquels ton nom apparaît encore. Raconte-lui par la même occasion ce qui s'est passé aujourd'hui. On dirait que ce sont les maillons d'une même chaîne.";
			link.l1 = "Bien, amiral. Je pars immédiatement.";
			link.l1.go = "PL_Q5_afterFight_2";
		break;
		case "PL_Q5_afterFight_2":
			dialog.text = "Fais attention. J'ai l'impression que quelqu'un creuse un peu trop activement sous tes pieds.";
			link.l1 = "Compris, amiral, je vais essayer.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "waiting_Q6";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			CloseQuestHeader("Pir_Line_5_Hunter");
			//сразу даём квест №6
			SetQuestHeader("Pir_Line_6_Jackman");
			AddQuestRecord("Pir_Line_6_Jackman", "1");
		break;
		//квест №7, охота на Соукинса
		case "PL_Q7_begin":
			dialog.text = "Ah, voilà donc " + pchar.name + " en personne ! Alors, les problèmes ne vont pas tarder.";
			link.l1 = "Henry, les plaisanteries, c'est bien beau, mais franchement, je n'ai plus envie de rire.";
			link.l1.go = "PL_Q7_begin_1";
			CloseQuestHeader("Pir_Line_6_Jackman");
		break;
		case "PL_Q7_begin_1":
			dialog.text = "Si tu veux me raconter l'histoire de"+ GetSexPhrase(" ton jumeau"," ta petite sœur") +", je la connais déjà.";
			link.l1 = "Et qu'en penses-tu ?";
			link.l1.go = "PL_Q7_begin_2";
		break;
		case "PL_Q7_begin_2":
			dialog.text = "Il est trop tכt pour tirer des conclusions. J'ai l'impression que quelque chose de très sanglant se prépare.";
			link.l1 = "Et que dois-je faire ? Attendre un couteau dans le dos ?";
			link.l1.go = "PL_Q7_begin_3";
		break;
		case "PL_Q7_begin_3":
			dialog.text = "Essaie de découvrir qui est derrière tous ces malentendus. Tout ça ressemble à des actions soigneusement préparées. J'ai pris quelques mesures pour éclaircir la situation. J'ai envoyé un homme enquêter, pour ainsi dire. Tu peux le retrouver et apprendre ce qu'il a découvert.";
			link.l1 = "Et quel genre d'homme ? Hum... fiable ?";
			link.l1.go = "PL_Q7_begin_4";
		break;
		case "PL_Q7_begin_4":
			dialog.text = "Ha ha ha ! Celui-là, il est fiable. Il s'appelle Steve Linnaeus, il est parti pour La Vega, puis il devait visiter chaque colonie pirate. Mais s'il les a visitées ou non, tu le découvriras toi-même.";
			link.l1 = "Je comprends. Je me prépare.";
			link.l1.go = "exit";
            SetQuestHeader("Pir_Line_7_Soukins");
            AddQuestRecord("Pir_Line_7_Soukins", "1");
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "Soukins_toLaVega";
			SetLocationCapturedState("LaVega_town", false);
		break;

		case "PL_Q7_LaVegaLate":
			dialog.text = "Ah, te revoilà, toi. Alors, qu'as-tu découvert ?";
			link.l1 = "Tu sais, je n'ai pas trouvé Steve Linnaeus à La Vega.";
			link.l1.go = "PL_Q7_LaVegaLate_1";
		break;
		case "PL_Q7_LaVegaLate_1":
			dialog.text = "Je ne sais même pas quoi te dire. Tu es lent comme une tortue de mer. Steve Linney a disparu, et la rumeur court que sa goélette, la Swallow, a été vendue au chantier naval de Santo Domingo.";
			link.l1 = "Diable !!";
			link.l1.go = "PL_Q7_LaVegaLate_2";
		break;
		case "PL_Q7_LaVegaLate_2":
			dialog.text = "Exactement. Va à Santo Domingo, renseigne-toi sur la Swallow au chantier naval. Et fais vite, pour une fois...";
			link.l1 = "D'accord, je ferai tout au mieux.";
			link.l1.go = "exit";
            AddQuestRecord("Pir_Line_7_Soukins", "4");
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "Soukins_toSantoDomingo";
		break;

		case "PL_Q7_LeonNotFound":
			dialog.text = "Ah, te revoilà, toi. Alors, qu'as-tu découvert ?";
			link.l1 = "Henry, Steve Linnaeus a disparu.";
			link.l1.go = "PL_Q7_LeonNotFound_1";
		break;
		case "PL_Q7_LeonNotFound_1":
			dialog.text = "Comment ça ?";
			link.l1 = "Deux inconnus l'ont fait venir quelque part à La Vega, personne ne l'a revu depuis, et son navire a été vendu au chantier naval de Santo Domingo.";
			link.l1.go = "PL_Q7_LeonNotFound_2";
		break;
		case "PL_Q7_LeonNotFound_2":
			dialog.text = "Bon, apparemment, nous ne reverrons plus Steve... Eh bien, passe me voir un de ces jours. Il y aura peut-être du travail pour toi.";
			link.l1 = "D'accord, Henry, je passerai.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			CloseQuestHeader("Pir_Line_7_Soukins");
			ChangeCharacterReputation(pchar, -3);
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			pchar.questTemp.piratesLine = "waiting_Q8";
		break;

		case "PL_Q7_afterLeon":
			dialog.text = "Ah, content de te voir. Quoi de neuf ?";
			link.l1 = "Malheureusement, Steve Linney est mort. Il a été tué par les pirates de la frégate Leon. Mais je leur ai déjà réglé leur compte.";
			link.l1.go = "PL_Q7_afterLeon_1";
		break;
		case "PL_Q7_afterLeon_1":
			dialog.text = "Caramba ! Pauvre Steve...";
			link.l1 = "Ce n'est pas tout. Le capitaine de cette frégate voulait me convaincre de travailler pour l'amiral des Frères de la Cכte.";
			link.l1.go = "PL_Q7_afterLeon_2";
		break;
		case "PL_Q7_afterLeon_2":
			dialog.text = "Vraiment ?! Je me demande qui d'autre, dans les Caraïbes, se prend pour l'amiral des Frères de la Cכte ? Ce serait Edward Mansfield ? Il me semblait que le vieux et moi, nous nous étions mis d'accord sur tout depuis longtemps.";
			link.l1 = "Non, Henry. C'est Richard Sawkins, le chef de Puerto Príncipe.";
			link.l1.go = "PL_Q7_afterLeon_3";
		break;
		case "PL_Q7_afterLeon_3":
			dialog.text = "Ha ! Mais pourquoi s'étonner ? L'envie, la cupidité et la vanité sont les trois piliers sur lesquels repose le monde. Le capitaine d'une goélette pirate risque à chaque minute de recevoir la marque noire de son équipage, pour peu qu'un de ses pirates se croie plus malin que les autres. Et l'amiral des Frères de la Cכte, alors...";
			link.l1 = "Hum, Jackman disait la même chose.";
			link.l1.go = "PL_Q7_afterLeon_4";
		break;
		case "PL_Q7_afterLeon_4":
			dialog.text = "Eh bien, Jackman est un philosophe réputé, alors il est assez malin pour se tenir loin des amiraux. Enfin, peu importe. Nous avons donc deux points positifs : le premier, c'est que la machination pour t'éliminer a échoué ; et le second, c'est que nous savons qui est derrière cette machination ! Maintenant, voyons ce que nous pouvons faire, à présent que Sawkins a lancé sa propagande.";
			link.l1 = "Voyons ça.";
			link.l1.go = "PL_Q7_afterLeon_5";
		break;
		case "PL_Q7_afterLeon_5":
			dialog.text = "Voilà. La rumeur dit que Sawkins prépare une opération. Nous ne devons pas laisser son projet réussir, sinon il prendra encore plus de poids. Il a de la chance, et il faut y remédier.";
			link.l1 = "Tu sais quelque chose sur cette opération ?";
			link.l1.go = "PL_Q7_afterLeon_6";
		break;
		case "PL_Q7_afterLeon_6":
			dialog.text = "Oui, comme toujours, il veut plumer les Espagnols. Et cette affaire doit échouer.";
			link.l1 = "Je veux dire, tu connais les détails de l'opération ?";
			link.l1.go = "PL_Q7_afterLeon_7";
		break;
		case "PL_Q7_afterLeon_7":
			dialog.text = "Non. Tu les découvriras toi-même, et tu réaliseras son plan avant lui. Ou bien tu le feras échouer. Bref, agis selon la situation. L'essentiel, pour moi, c'est un résultat positif.";
			link.l1 = "Compris. Bon, je m'y mets.";
			link.l1.go = "PL_Q7_afterLeon_8";
		break;
		case "PL_Q7_afterLeon_8":
			dialog.text = "Parfait ! Je t'attends avec de bonnes nouvelles.";
			link.l1 = "Je ferai tout comme il faut.";
			link.l1.go = "exit";
            AddQuestRecord("Pir_Line_7_Soukins", "8");
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "Soukins_toPuertoPrincipe";
			sld = ItemsFromID("OpenBook");
			sld.shown = true;
			sld = ItemsFromID("Ladder");
			sld.shown = true;
			sld.startLocation = "PuertoPrincipe_town";
			sld.startLocator = "item1";
			sld.useLocation = "PuertoPrincipe_town";
			sld.useLocator = "button01";
			//прерывание на вход в резиденцию, не дать осмотреться геймеру
            Pchar.quest.PQ7_inSoukinsResidence.win_condition.l1 = "location";
            Pchar.quest.PQ7_inSoukinsResidence.win_condition.l1.location = "PuertoPrincipe_townhall";
            Pchar.quest.PQ7_inSoukinsResidence.function = "PQ7_inSoukinsResidence";
		break;

		case "PL_Q7_BadWork":
			dialog.text = "Alors, oם en es-tu ? Tu as réussi à arrêter Sawkins ?";
			link.l1 = "Malheureusement, non, Henry...";
			link.l1.go = "PL_Q7_BadWork_1";
		break;
		case "PL_Q7_BadWork_1":
			dialog.text = "C'est fâcheux. Maintenant, Sawkins est devenu plus fort...";
			link.l1 = "J'ai fait tout ce que j'ai pu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			CloseQuestHeader("Pir_Line_7_Soukins");
			ChangeCharacterReputation(pchar, -10);
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			pchar.questTemp.piratesLine = "waiting_Q8";
		break;

		case "PL_Q7_GoodWork":
			dialog.text = "Alors, oם en es-tu ? Tu as réussi à arrêter Sawkins ?";
			link.l1 = "Oui, j'ai tout fait, comme prévu.";
			link.l1.go = "PL_Q7_GoodWork_1";
		break;
		case "PL_Q7_GoodWork_1":
			dialog.text = "Parfait ! Et que préparait-il ?";
			link.l1 = "Il comptait intercepter un vaisseau de ligne que les Espagnols envoyaient en Europe.";
			link.l1.go = "PL_Q7_GoodWork_2";
		break;
		case "PL_Q7_GoodWork_2":
			dialog.text = "Et alors ?";
			link.l1 = "Et il ne l'a pas intercepté...";
			link.l1.go = "PL_Q7_GoodWork_3";
		break;
		case "PL_Q7_GoodWork_3":
			dialog.text = "Alors, " + GetFullName(PChar) + ", voyons ça plus en détail. Qu'as-tu fait ?";
			link.l1 = "Je l'ai coulé. Les canonniers étaient habiles, ils m'ont aussitכt laissé sans voiles. Alors j'ai dמ le couler pour que Sawkins ne l'ait pas.";
			link.l1.go = "PL_Q7_GoodWork_4";
		break;
		case "PL_Q7_GoodWork_4":
			dialog.text = "Bon sang ! Et tu n'as même pas découvert pourquoi il avait tant de valeur pour Sawkins ?";
			link.l1 = "J'ai fait mon possible. J'ai même volé son journal de bord. Mais on n'y apprend que l'itinéraire et l'heure de l'opération. Tu peux voir par toi-même.";
			link.l1.go = "PL_Q7_GoodWork_5";
		break;
		case "PL_Q7_GoodWork_5":
			dialog.text = "En effet. Ce gredin a arraché des pages, apparemment, il ne voulait vraiment pas que l'information s'ébruite. Tant mieux si une opération aussi importante pour lui a échoué.";
			link.l1 = "C'est ce que je me suis dit quand j'ai ordonné de charger les bombes.";
			link.l1.go = "PL_Q7_GoodWork_6";
			RemoveItems(PChar, "OpenBook", 1);
		break;
		case "PL_Q7_GoodWork_6":
			dialog.text = "Bon, maintenant, tu ferais mieux de t'occuper de tes affaires ; si tu veux travailler pour une puissance quelconque, je n'y vois pas d'objection. Quand tu auras fini, viens me voir, nous poursuivrons notre collaboration.";
			link.l1 = "Et si je ne veux pas avoir affaire aux autorités ?";
			link.l1.go = "PL_Q7_GoodWork_7";
		break;
		case "PL_Q7_GoodWork_7":
			dialog.text = "Alors, reviens dans un mois environ.";
			link.l1 = "Compris, amiral.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "Soukins_toSantoDomingo";
			CloseQuestHeader("Pir_Line_7_Soukins");
			ChangeCharacterReputation(pchar, 10);
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			pchar.questTemp.piratesLine = "waiting_Q8";
		break;
		//квест №8, штурм Панамы
		case "PL_Q8_1":
			if (pchar.questTemp.State == "" || pchar.questTemp.State == "EndOfQuestLine")
			{
				dialog.text = "Tu tombes à pic ! Je voulais justement envoyer quelqu'un te chercher.";
				link.l1 = "Enfin ! De quoi s'agit-il ?";
				link.l1.go = "PL_Q8_2";
				pchar.questTemp.State = "EndOfQuestLine"; //если геймер ещё не брал нац.линейку, то и не даём её после штурма Панамы
				bWorldAlivePause = false; // Конец линейки
			}
			else
			{
				dialog.text = "Hum, j'ai entendu dire que tu fricotais avec " + NationNamePeopleAcc(sti(pchar.questTemp.NationQuest)) + ". Je crois t'avoir clairement dit de terminer ton travail pour les autorités, puis de venir me voir. Qu'est-ce que tu ne comprends pas ?!";
				link.l1 = "C'est clair, Henry, pardon...";
				link.l1.go = "exit";
			}
		break;
		case "PL_Q8_2":
			dialog.text = "Une affaire ? Hum, c'est une affaire sérieuse. Je rassemble tous les pirates pour une grande entreprise qui laissera une trace dans l'histoire !";
			link.l1 = "Voilà une déclaration sérieuse.";
			link.l1.go = "PL_Q8_3";
		break;
		case "PL_Q8_3":
			dialog.text = "Plus que ça ! Et dans cette affaire, "+ GetSexPhrase("mon ami","ma chère") +", tu auras une mission spéciale. Il est temps de régler nos comptes avec notre ami Sawkins.";
			link.l1 = "Il était temps.";
			link.l1.go = "PL_Q8_4";
		break;
		case "PL_Q8_4":
			dialog.text = "Quand le « temps » sera venu, c'est moi qui en déciderai, et ta tâche, c'est de faire strictement ce que je te demande.";
			link.l1 = "Henry, même si nous avons eu parfois des malentendus, j'ai toujours agi par loyauté envers l'amiral des Frères de la Cכte.";
			link.l1.go = "PL_Q8_5";
		break;
		case "PL_Q8_5":
			dialog.text = "Tu as bien agi, "+ GetSexPhrase("l'ami","" + pchar.name + "") +", et je l'apprécie. Bon, maintenant, laisse-moi te mettre au courant !";
			link.l1 = "Je t'écoute attentivement, Henry.";
			link.l1.go = "PL_Q8_6";
		break;
		case "PL_Q8_6":
			dialog.text = "Le principal. J'ai décidé de prendre Panama !!";
			link.l1 = "דa alors ! Tu es sמr que c'est possible, en principe ?";
			link.l1.go = "PL_Q8_7";
		break;
		case "PL_Q8_7":
			dialog.text = "Pourquoi serait-ce impossible ?";
			link.l1 = "C'est là qu'il y a toujours eu la garnison la plus nombreuse et la mieux entraînée. Je ne pense pas que les Espagnols soient prêts à l'affaiblir d'une façon ou d'une autre.";
			link.l1.go = "PL_Q8_8";
		break;
		case "PL_Q8_8":
			dialog.text = "Il ne t'est jamais venu à l'esprit que la garnison la plus forte garde ce que l'Escurial a de plus précieux dans le Nouveau Monde ?";
			link.l1 = "Hum, il me semblait qu'elle gardait la tête de pont... Attends, mais j'ai entendu dire que notre Charles avait fait la paix avec la reine d'Espagne ! Tu n'auras pas de problèmes à Londres ?";
			link.l1.go = "PL_Q8_9";
		break;
		case "PL_Q8_9":
			dialog.text = "Tu l'as bien dit : « entendu dire » ! Et moi, j'ai entendu dire qu'il serait très utile d'affaiblir la position des Espagnols et de ralentir leur conquête du continent. Bref, cette affaire est approuvée.";
			link.l1 = "Hum, bon, tu sais mieux que moi. Et tu es sמr qu'on peut amener l'escadre à Panama par le cap Horn sans pertes ?";
			link.l1.go = "PL_Q8_10";
		break;
		case "PL_Q8_10":
			dialog.text = "Je n'en suis pas sמr, c'est pourquoi nous ne passerons pas par le cap Horn, mais par l'isthme.";
			link.l1 = "Diable ! C'est encore plus fou !!";
			link.l1.go = "PL_Q8_11";
		break;
		case "PL_Q8_11":
			dialog.text = "C'est vrai. C'est pourquoi les Espagnols ne s'y attendent pas de notre part, et le fort ne les aidera pas à repousser une attaque par l'arrière. Mais retiens bien mes paroles : nous le ferons.";
			link.l1 = "Oh, merde ! C'est tentant, quoique dangereux ! Quand commençons-nous ?";
			link.l1.go = "PL_Q8_12";
			link.l2 = "Tu sais, Morgan, je doute du succès de cette aventure. Je vais refuser.";
			link.l2.go = "PL_Q8_17";
		break;
		case "PL_Q8_12":
			dialog.text = "Je te donne 20 jours pour bien te préparer. Prends un navire plus puissant, et surtout, rassemble un plus grand équipage. Tu ne peux participer à cette affaire qu'avec un seul navire, garde-le à l'esprit.";
			link.l1 = "Compris. Que dois-je savoir d'autre ?";
			link.l1.go = "PL_Q8_13";
		break;
		case "PL_Q8_13":
			dialog.text = "D'abord, nous prendrons Portobelo, pour ne pas laisser la garnison espagnole sur nos arrières. Ensuite, nous marcherons sur Panama à travers la jungle. Au fait, il est inutile d'attaquer Portobelo avant l'heure, alors n'essaie même pas.";
			link.l1 = "Oui, je n'en avais pas l'intention !";
			link.l1.go = "PL_Q8_14";
		break;
		case "PL_Q8_14":
			dialog.text = "Héhé, je connais "+ GetSexPhrase("les petits malins dans ton genre.","ton genre, petite futée !") +" L'essentiel, c'est qu'en plus de bien te battre, tu devras aussi régler certaines questions. Je te le dirai le moment venu.";
			link.l1 = "Quelles sont vos questions ?";
			link.l1.go = "PL_Q8_15";
		break;
		case "PL_Q8_15":
			dialog.text = "Je te le dis, tu le sauras le moment venu.";
			link.l1 = "Hum, c'est juste que je n'aime pas les mauvaises surprises.";
			link.l1.go = "PL_Q8_16";
		break;
		case "PL_Q8_16":
			dialog.text = "Je t'assure qu'il n'y a que de bonnes surprises qui nous attendent. Bref, je t'attends dans 20 jours, et maintenant, prépare-toi.";
			link.l1 = "Compris, Henry.";
			link.l1.go = "exit";
            AddQuestRecord("Pir_Line_8_Panama", "1");
			NextDiag.TempNode = "PL_Q8_ready";
			pchar.questTemp.piratesLine = "Panama_toReady";
			SaveCurrentQuestDateParam("questTemp.piratesLine");
			SetTimerFunction("PQ8_timeOver", 0, 0, 35);
			LocatorReloadEnterDisable("Shore48", "reload1_back", true); //закрывем подходы к Панаме
			LocatorReloadEnterDisable("PortoBello_Jungle_01", "reload1_back", true);
		break;
		
		case "PL_Q8_17":
			dialog.text = "Tu as bien tort. Ton refus me déçoit, mais je ne vais pas te persuader. Adieu.";
			link.l1 = "Bonne journée, Morgan.";
			link.l1.go = "PL_Q8_18";
		break;
		case "PL_Q8_18":
			DialogExit();
			NextDiag.TempNode = "First time";
		break;

		case "PL_Q8_ready":
			if (GetQuestPastDayParam("questTemp.piratesLine") > 19)
			{
				dialog.text = "Ah, te voilà ! C'est bien, car le moment est venu. Je suppose que tout est prêt de ton cכté ?";
				link.l1 = "Oui, amiral. Paré au combat.";
				link.l1.go = "PL_Q8_ready_1";
			}
			else
			{
				dialog.text = "Qu'est-ce que tu fais ici ? Dans 20 jours, je t'ai dit !";
				if (GetQuestPastDayParam("questTemp.piratesLine") == 19) dialog.text = "Qu'est-ce que tu fais ici ? Il reste encore un jour.";
				link.l1 = "Oui, je m'en souviens. Je voulais juste voir...";
				link.l1.go = "exit";
			}
		break;
		case "PL_Q8_ready_1":
            if (GetCompanionQuantity(pchar) == 1)
            {
				dialog.text = "Parfait ! Alors, en route. Jackman, John Morris et notre grand ami Richard Sawkins participent aussi à l'affaire en tant que capitaines. Je te confie le commandement de l'escadre et l'assaut de Portobelo.";
				link.l1 = "Merci de ta confiance, amiral. Je ne te décevrai pas, sois-en sמr !";
				link.l1.go = "PL_Q8_ready_2";
			}
			else
			{
				dialog.text = "וcoute, " + pchar.name + ", je t'ai dit de venir avec un seul navire. Tu n'as qu'à faire ce que je dis. Qu'est-ce qui n'est pas clair ?!";
				link.l1 = "Tout est clair, amiral, je vais tout faire.";
				link.l1.go = "exit";
				NextDiag.TempNode = "PL_Q8_ready";
			}
		break;
		case "PL_Q8_ready_2":
			dialog.text = "Je l'espère vraiment, "+ GetSexPhrase("l'ami","" + pchar.name + "") +". Sinon, il n'y aura pas de pardon pour toi.";
			link.l1 = "Ce n'est pas la première fois que je prends des forts, ne t'inquiète pas.";
			link.l1.go = "PL_Q8_ready_3";
		break;
		case "PL_Q8_ready_3":
			dialog.text = "Bien. Alors, commençons immédiatement.";
			link.l1 = "Alors, je prends le commandement.";
			link.l1.go = "PL_Q8_ready_4";
		break;
		case "PL_Q8_ready_4":
			pchar.quest.PQ8_timeOver.over = "yes"; //снимаем таймер
			SetTimerFunction("PQ8_PanamaTimerOver", 0, 0, 20); //ставим новый таймер
			pchar.Quest.PQ8_EnterPortoBello.win_condition.l1 = "location";
			pchar.Quest.PQ8_EnterPortoBello.win_condition.l1.location = "PortoBello";
			pchar.Quest.PQ8_EnterPortoBello.function = "PQ8_EnterPortoBello";
            pchar.questTemp.piratesLine = "Panama_toPortoBello";
			AddQuestRecord("Pir_Line_8_Panama", "4");
			AddQuestUserData("Pir_Line_8_Panama", "sSex", GetSexPhrase("", "e"));
			pchar.TempPerks.QuestTroopers = true; //перк квестового десанта
			characters[GetCharacterIndex("PortoBello_Mayor")].dialog.captureNode = "PQ8_MayorPortoBello"; //капитулянтская нода мэра
			//Морган
			FantomMakeCoolSailor(npchar, SHIP_REDOUTABLE, "Terrifying", CANNON_TYPE_CANNON_LBS32, 90, 90, 90);
            //pchar.nation = PIRATE;//фикс - чтобы не убегать из ПортРояля с боем
            LAi_SetActorType(NPChar);
            LAi_ActorSetStayMode(NPChar);
			//LAi_SetImmortal(NPChar, false);
			NPChar.Ship.Cargo.Goods.Food = 1000;
            LAi_NoRebirthDisable(NPChar);
			LAi_RebirthOldName(NPChar);
			npchar.DeckDialogNode = "PL_Q8_deck"; //ноду на палубу
            ChangeCharacterAddressGroup(NPChar, "PortRoyal_houseS1", "goto", "goto7");
            CharacterIntoCompanionAndGoOut(pchar, npchar, "reload", "reload1", 8.5, false);
            npchar.CompanionEnemyEnable = false;  // нет отпора при обстреле
			SetCharacterRemovable(npchar, false);
			//Джекмен
			sld = characterFromId("Jackman");
			FantomMakeCoolSailor(sld, SHIP_INGERMANLAND, "Fortunato", CANNON_TYPE_CULVERINE_LBS32, 90, 90, 90);
			sld.CompanionEnemyEnable = false;  // нет отпора при обстреле
			SetCharacterRemovable(sld, false);
			sld.Ship.Cargo.Goods.Food = 1000;
			LAi_SetImmortal(sld, false);
            LAi_NoRebirthDisable(sld);
			LAi_RebirthOldName(sld);
			SetCompanionIndex(pchar, -1, sti(sld.index));
			//Джон Моррис
			if (GetCharacterIndex("John Morris") == -1)
			{
				sld = GetCharacter(NPC_GenerateCharacter("John Morris", "bocman", "man", "man", 38, PIRATE, -1, false));
        		sld.name 	= "John";
        		sld.lastname = "Morris";
				sld.Dialog.Filename = "Quest\JohnMorris.c";
				sld.greeting = "Gr_HeadPirates";
				FantomMakeCoolFighter(sld, 35, 90, 50, BLADE_LONG, "pistol4", 150);
           		LAi_SetStayType(sld);
        		LAi_SetLoginTime(sld, 0.0, 24.0);
        		LAi_SetHP(sld, 180.0, 180.0);
			}
			else
			{
				sld = characterFromId("John Morris");
			}
			FantomMakeCoolSailor(sld, SHIP_FRIGATE, "Lagoon", CANNON_TYPE_CANNON_LBS32, 90, 90, 90);
			sld.CompanionEnemyEnable = false;  // нет отпора при обстреле
			LAi_SetImmortal(sld, false);
			SetCharacterRemovable(sld, false);
			sld.Ship.Cargo.Goods.Food = 1000;
            LAi_NoRebirthDisable(sld);
			LAi_RebirthOldName(sld);
			sld.RebirthPhantom = true; //не тереть фантома после смерти.
			sld.DeckDialogNode = "PL_Q8_deck"; //ноду на палубу
			SetCompanionIndex(pchar, -1, sti(sld.index));
			//Ричард Соукинс
			sld = characterFromId("Richard_Soukins");
			FantomMakeCoolSailor(sld, SHIP_MANOWAR, "Lucky guy", CANNON_TYPE_CULVERINE_LBS32, 90, 90, 90);
			sld.CompanionEnemyEnable = false;  // нет отпора при обстреле
			SetCharacterRemovable(sld, false);
			sld.Ship.Cargo.Goods.Food = 2500;
			LAi_SetImmortal(sld, true);
			LAi_NoRebirthEnable(sld);
			LAi_RemoveLoginTime(sld);
			sld.DeckDialogNode = "PL_Q8_deck"; //ноду на палубу
			SetCompanionIndex(pchar, -1, sti(sld.index));
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "PL_Q8_timeOver":
			dialog.text = "Je t'ai confié le commandement de l'escadre, et tu ne sais pas ce que tu fais. דa fait déjà vingt jours que nous croisons dans les Caraïbes, alors qu'il faut dix jours au plus de Port Royal à Portobelo !";
			link.l1 = "C'est arrivé comme ça, Henry...";
			link.l1.go = "PL_Q8_timeOver_1";
			// выход с палубы
			pchar.quest.Munity = "Deads";
            LAi_LockFightMode(Pchar, false);
		break;
		case "PL_Q8_timeOver_1":
			dialog.text = "Que ça « arrive comme ça » ailleurs. J'espère que les Espagnols te feront vite sauter la tête, avec une telle façon de travailler. Bref, nous partons, nous nous passerons de toi pour notre affaire. Adieu.";
			link.l1 = "Eh bien, allez au diable !";
			link.l1.go = "PL_Q8_timeOver_2";
		break;
		case "PL_Q8_timeOver_2":
			dialog.text = "Au revoir, "+ GetSexPhrase("l'ami","ma petite") +". Ne me casse pas les pieds.";
			link.l1 = "Qu'est-ce que j'en ai à faire, de ton Panama ? Juste de quoi nourrir les moustiques dans la jungle.";
			link.l1.go = "PL_Q8_timeOver_3";
		break;
		case "PL_Q8_timeOver_3":
			SetTimerFunction("PQ8_openPanama", 0, 0, 40);
			LocatorReloadEnterDisable("Shore48", "reload1_back", true); //закрывем подходы к Панаме
			LocatorReloadEnterDisable("PortoBello_Jungle_01", "reload1_back", true);
			pchar.questTemp.piratesLine = "over";
			AddQuestRecord("Pir_Line_8_Panama", "3");
			AddQuestUserData("Pir_Line_8_Panama", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Pir_Line_8_Panama");
			//возвращаем Моргана
            if(IsCompanion(npchar))  RemoveCharacterCompanion(pchar, npchar);
            //Возвращаем на место Джекмена
			iTemp = GetCharacterIndex("Jackman");
			if (iTemp != -1)
			{
				if(IsCompanion(&characters[iTemp]))
				{
					RemoveCharacterCompanion(pchar, &characters[iTemp]);
				}
				LAi_SetHuberType(&characters[iTemp]);
				LAi_group_MoveCharacter(&characters[iTemp], "PIRATE_CITIZENS");
                ChangeCharacterAddressGroup(&characters[iTemp], "Pirates_townhall", "sit", "sit1");
                characters[iTemp].dialog.currentnode = "First time";
            }
			//Джон Моррис
			iTemp = GetCharacterIndex("John Morris");
			if (iTemp != -1)
			{
				if(IsCompanion(&characters[iTemp]))
				{
					RemoveCharacterCompanion(pchar, &characters[iTemp]);
				}
				sld = &characters[iTemp];
				sld.lifeDay = 0;
			}
            //Возвращаем на место Соукинса
			iTemp = GetCharacterIndex("Richard_Soukins");
			if (iTemp != -1)
			{
				if(IsCompanion(&characters[iTemp]))
				{
					RemoveCharacterCompanion(pchar, &characters[iTemp]);
				}
				LAi_SetHuberType(&characters[iTemp]);
				LAi_group_MoveCharacter(&characters[iTemp], "PIRATE_CITIZENS");
                ChangeCharacterAddressGroup(&characters[iTemp], "PuertoPrincipe_townhall", "sit", "sit1");
                characters[iTemp].dialog.currentnode = "First time";
            }
            NextDiag.TempNode = "PL_Q8_timeOver_exit";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "PL_Q8_timeOver_exit":
			dialog.text = "Il n'y a plus rien à dire.";
			link.l1 = "...";
			link.l1.go = "PL_Q8_timeOver_exit";
		break;
		//в резиденции взятого Порто Белло
		case "PL_Q8_PBResidence":
			dialog.text = "Tu es doué pour les assauts, bravo.";
			link.l1 = "Portobelo est à nous, amiral. Mais nous avons un sérieux problème.";
			link.l1.go = "PL_Q8_PBResidence_1";
		break;
		case "PL_Q8_PBResidence_1":
			dialog.text = "Qu'y a-t-il ?";
			link.l1 = "Les Espagnols sont au courant de notre intention de marcher sur Panama. C'est le gouverneur capturé qui me l'a dit.";
			link.l1.go = "PL_Q8_PBResidence_2";
		break;
		case "PL_Q8_PBResidence_2":
			dialog.text = "Diable !! Et qui le lui a dit ?";
			link.l1 = "D'après lui, le gouverneur général espagnol.";
			link.l1.go = "PL_Q8_PBResidence_3";
		break;
		case "PL_Q8_PBResidence_3":
			dialog.text = "Bon, ce n'est pas important. J'ai l'impression que ce sont encore les manigances de Sawkins. Maintenant, les Espagnols sont sans doute prêts à nous recevoir et vont renforcer la défense de Panama.";
			link.l1 = "Oui, cette expédition semblait déjà risquée avant, mais maintenant, c'est carrément du suicide.";
			link.l1.go = "PL_Q8_PBResidence_4";
		break;
		case "PL_Q8_PBResidence_4":
			dialog.text = "Oui, oui, peut-être. וcoute-moi bien, " + pchar.name + ", il est temps de nous débarrasser de Sawkins.";
			link.l1 = "Je suis d'accord.";
			link.l1.go = "PL_Q8_PBResidence_5";
		break;
		case "PL_Q8_PBResidence_5":
			dialog.text = "Mais il y a un problème : ses hommes. J'ai besoin d'eux. S'il lui arrive quelque chose maintenant, ils pourraient bien nous quitter. Et ils sont absolument nécessaires pour l'assaut de Panama !";
			link.l1 = "Henry, tu ne vas donc pas renoncer à cette idée ?!";
			link.l1.go = "PL_Q8_PBResidence_6";
		break;
		case "PL_Q8_PBResidence_6":
			dialog.text = "Bien sמr que non !! Quand ai-je renoncé à m'en prendre aux dons castillans ? Ne t'inquiète pas, l'essentiel, c'est de faire ce que je te dis. Et tout ira bien.";
			link.l1 = "Tu es fou, Henry ! Mais je ne sais pourquoi, je crois au succès ! Que dois-je faire ?";
			link.l1.go = "PL_Q8_PBResidence_7";
		break;
		case "PL_Q8_PBResidence_7":
			if (pchar.location.from_sea == "Shore48")
			{
				dialog.text = "Tu as débarqué dans la baie de Darién, et c'est très bien. Va là-bas, rassemble tes hommes et marche sur Panama. Moi, je marcherai vers l'objectif avec mes combattants depuis ici, depuis Portobelo. Nous nous retrouverons aux portes de Panama et nous commencerons l'assaut par deux cכtés à la fois.";
				link.l1 = "Compris, amiral !";
				link.l1.go = "PL_Q8_PBResidence_8";
			}
			else
			{
				dialog.text = "Va dans la baie de Darién. Rassemble tes hommes et marche sur Panama. Moi, je marcherai vers l'objectif avec mes combattants depuis ici, depuis Portobelo. Nous nous retrouverons aux portes de Panama et nous commencerons l'assaut par deux cכtés à la fois.";
				link.l1 = "Compris, amiral !";
				link.l1.go = "PL_Q8_PBResidence_8";
			}
		break;
		case "PL_Q8_PBResidence_8":
			dialog.text = "Ce n'est pas tout. Jackman et Morris viennent avec moi. Toi, tu pars avec Sawkins. Les Espagnols sont au courant de notre campagne, et ils vont sמrement essayer de tendre une embuscade dans la jungle. Et très probablement plus d'une.";
			link.l1 = "Je le pense aussi, amiral. Nous serons prêts.";
			link.l1.go = "PL_Q8_PBResidence_9";
		break;
		case "PL_Q8_PBResidence_9":
			dialog.text = "Il ne suffit pas de repousser les Castillans. Règle aussi le problème de Sawkins pendant le combat, je ne veux pas le voir sous les murs de Panama. Il est sacrément courageux, et dès qu'il apparaîtra sur les murs de Panama, ses hommes porteront leur chef aux nues. Et on n'étrangle pas un héros si facilement : la popularité, c'est une grande chose chez les Frères de la Cכte.";
			link.l1 = "Que proposes-tu exactement ?"
			link.l1.go = "PL_Q8_PBResidence_10";
		break;
		case "PL_Q8_PBResidence_10":
			dialog.text = "C'est très simple. Achève discrètement Sawkins pendant le combat, mais sans que personne ne le voie. Une balle dans le dos, c'est le moyen le plus sמr.";
			link.l1 = "Hum, amiral, je ne pensais pas que tu pouvais dire une chose pareille.";
			link.l1.go = "PL_Q8_PBResidence_11";
		break;
		case "PL_Q8_PBResidence_11":
			dialog.text = "וcoute, " + PChar.name + ", ne faisons pas les délicats.";
			link.l1 = "Mais amiral...";
			link.l1.go = "PL_Q8_PBResidence_12";
		break;
		case "PL_Q8_PBResidence_12":
			dialog.text = "Bref, tu peux trouver n'importe quel autre moyen qui te convienne. Mais souviens-toi que Sawkins ne doit pas apparaître à l'assaut de Panama.";
			link.l1 = "D'accord, je trouverai quelque chose.";
			link.l1.go = "PL_Q8_PBResidence_13";
		break;
		case "PL_Q8_PBResidence_13":
			dialog.text = "Eh bien, parfait ! Bref, prends tes hommes et rends-toi à l'endroit indiqué. Tu dois y être en deux jours au plus. Et n'essaie pas de lancer l'assaut sans nous, ça donnerait de l'avance aux Espagnols.";
			link.l1 = "D'accord, Henry, je t'attendrai devant Panama.";
			link.l1.go = "PL_Q8_PBResidence_14";
		break;
		case "PL_Q8_PBResidence_14":
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
			//bQuestDisableMapEnter = false;
			LocatorReloadEnterDisable("Shore48", "reload1_back", false); //открываем проход в джанглы через бухту
            Pchar.quest.PQ8_PBExitResidence.win_condition.l1 = "ExitFromLocation";
            Pchar.quest.PQ8_PBExitResidence.win_condition.l1.location = pchar.location;
            Pchar.quest.PQ8_PBExitResidence.function = "PQ8_PBExitResidence";
			NextDiag.TempNode = "PL_Q8_PBResidence_over";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "PL_Q8_PBResidence_over":
			dialog.text = "Ne traîne pas, va à Panama !";
			link.l1 = "Oui, compris, Henry.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_PBResidence_over";
		break;
		//у ворот Панамы
		case "PL_Q8_ExTPanama":
			iTemp = GetCharacterIndex("Richard_Soukins");

			if(PChar.QuestTemp.piratesLine == "Panama_RichardBadWork")
			{
				if(LAi_IsDead(&Characters[iTemp]))
				{
					dialog.text = "J'ai vu Sawkins parmi ceux qui combattaient lors de la dernière bataille. On dirait que tu as raté ton coup dans la jungle...";
					link.l1 = "Oui, mais maintenant, il est mort ! Donc, le travail est fait : Richard peut préparer sa pierre tombale.";
					link.l1.go = "PL_Q8_ExTPanama_1";
				}
				else
				{
					dialog.text = "Donc, tu n'as pas pu accomplir la mission ! Notre ami se promène ici comme si de rien n'était.";
					link.l1 = "Henry, je n'ai rien pu faire, c'était très dangereux !";
					link.l1.go = "PL_Q8_ExTPanama_7_Soukins";
				}
			}
			else
			{
				dialog.text = "Oh oh, content de te voir, " + PChar.name + ", en vie et en pleine forme ! Je n'ai pas vu Sawkins dans ce combat.";
				link.l1 = "Henry, j'ai le regret de t'annoncer que Richard Sawkins a quitté ce monde mortel. Il est tombé en héros !";
				link.l1.go = "PL_Q8_ExTPanama_1";
			}
		break;
		case "PL_Q8_ExTPanama_1":
			dialog.text = "Je partage votre chagrin, mes amis ! Nous nous souviendrons de lui comme d'un héros. Bon, raconte-moi ce qui s'est passé pendant la marche ?";
			link.l1 = "Avant cette bataille sous les murs de Panama, nous avons dמ soutenir trois autres attaques. Même les Indiens nous ont attaqués !";
			link.l1.go = "PL_Q8_ExTPanama_2";
		break;
		case "PL_Q8_ExTPanama_2":
			dialog.text = "Il nous est arrivé la même chose. Tout se déroule comme prévu, "+ GetSexPhrase("l'ami","ma chère") +" !";
			link.l1 = "Comment ça ? Nous avons subi de lourdes pertes !";
			link.l1.go = "PL_Q8_ExTPanama_3";
		break;
		case "PL_Q8_ExTPanama_3":
			dialog.text = "Et comment faire sans pertes ? C'est la guerre. Mais le fait est que les Espagnols ont commis une grave erreur tactique. Ils ont dispersé leurs forces dans des embuscades, si bien que nous avons pu les détruire morceau par morceau ! S'ils avaient rassemblé toutes leurs forces en un seul poing, ils nous auraient sans aucun doute battus. Bon, maintenant, la ville elle-même n'est plus aussi forte. Je suis sמr que Panama est à nous !";
			link.l1 = "Tu crois qu'il n'y a pas de soldats dans la ville ?";
			link.l1.go = "PL_Q8_ExTPanama_4";
		break;
		case "PL_Q8_ExTPanama_4":
			dialog.text = "J'en suis sמr ! Maintenant, écoute : va tout de suite à la résidence du gouverneur et commence l'interrogatoire. J'ai un mauvais pressentiment.";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "PL_Q8_ExTPanama_5";
		break;
		case "PL_Q8_ExTPanama_5":
			dialog.text = "Il est déjà évident que le maire de Portobelo a dit la vérité : ils nous attendaient. Cela signifie que la population a quitté la ville avec tous ses biens de valeur. Dans ce cas, le revenu de notre campagne sera insignifiant. Mais nous avons une chance de prendre l'or de l'Escurial, et pour cela, nous avons besoin du gouverneur. Il sait sמrement oם l'or a été caché en prévision de l'assaut.";
			link.l1 = "Tu as vraiment raison.";
			link.l1.go = "PL_Q8_ExTPanama_6";
		break;
		case "PL_Q8_ExTPanama_6":
			dialog.text = "Va à la résidence de Panama, et ne traîne pas ! Je m'occupe du reste dans la ville.";
			link.l1 = "Compris. J'y vais.";
			link.l1.go = "PL_Q8_ExTPanama_7";
		break;
		case "PL_Q8_ExTPanama_7":
			AddQuestRecord("Pir_Line_8_Panama", "9");
			//characters[GetCharacterIndex("Panama_Mayor")].dialog.captureNode = "PQ8_afterAttack"; //капитулянтская нода мэра
			pchar.quest.PQ8_piratesInPanama.win_condition.l1 = "location";
			pchar.quest.PQ8_piratesInPanama.win_condition.l1.location = "Panama_town";
			pchar.quest.PQ8_piratesInPanama.function = "PQ8_piratesInPanama";
			NextDiag.TempNode = "PL_Q8_ExTPanama_over";
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload4", "none", "", "", "OpenTheDoors", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "PL_Q8_ExTPanama_over":
			dialog.text = "Va à la résidence, ne perds pas de temps !";
			link.l1 = "Oui, Henry, compris...";
			link.l1.go = "exit";
		break;
		case "PL_Q8_ExTPanama_7_Soukins":
			dialog.text = "Mais bien sמr !";
			link.l1 = "Si tu es si malin, tu n'avais qu'à l'abattre toi-même.";
			link.l1.go = "PL_Q8_ExTPanama_8_Soukins";
		break;
		case "PL_Q8_ExTPanama_8_Soukins":
			dialog.text = "J'ai compris ! Bon, restons-en là. Tu peux retourner sur ton navire, tu n'as rien à faire à Panama. Pour m'avoir laissé tomber, je t'exclus des Frères de la Cכte. Dehors !";
			link.l1 = "Je n'y tenais pas vraiment !";
			link.l1.go = "PL_Q8_ExTPanama_9_Soukins";
		break;
		case "PL_Q8_ExTPanama_9_Soukins":
			QuestSetCurrentNode("Richard_Soukins", "PQ8_exitTown");
			AddQuestRecord("Pir_Line_8_Panama", "10");
			CloseQuestHeader("Pir_Line_8_Panama");
			LocatorReloadEnterDisable("Panama_ExitTown", "reload4", true); //закроем вход в город
			SetTimerFunction("PQ8_openPanama_2", 0, 0, 30); //таймер на открыть все потом.
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload4", "none", "", "", "OpenTheDoors", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//в Панаме после выхода ГГ из резиденции
		case "PL_Q8_Panama1":
			dialog.text = "Tu as trouvé le gouverneur ?";
			link.l1 = "Oui, je l'ai trouvé et interrogé.";
			link.l1.go = "PL_Q8_Panama1_1";
		break;
		case "PL_Q8_Panama1_1":
			dialog.text = "Et qu'a-t-il dit ?";
			link.l1 = "L'or de l'Escurial se trouve peut-être dans le bureau du gouverneur, à la résidence. Seulement, il n'y a pas la clé du coffre, il est fermé.";
			link.l1.go = "PL_Q8_Panama1_2";
		break;
		case "PL_Q8_Panama1_2":
			dialog.text = "Et oם est cette clé ?";
			link.l1 = "Chez le commandant. Je devrais bien examiner le dernier champ de bataille, je trouverai peut-être le commandant là-bas. Sinon, il faudra chercher au fort.";
			link.l1.go = "PL_Q8_Panama1_3";
		break;
		case "PL_Q8_Panama1_3":
			dialog.text = "Hum, bon, vas-y. En attendant, je vais m'occuper du gouverneur, son histoire est suspecte. Le coffre est chez le gouverneur, et la clé chez le commandant ! Héhé, c'est bizarre...";
			link.l1 = "Qu'y a-t-il de si étrange ? C'était sמrement organisé pour empêcher les hauts fonctionnaires de la ville de piller le trésor. Heureusement que le coffre n'a pas été traîné dans la jungle. Sinon, bonne chance pour le retrouver.";
			link.l1.go = "PL_Q8_Panama1_4";
		break;
		case "PL_Q8_Panama1_4":
			sld = characterFromId("FantomMayor");
			sld.lifeDay = 0;
			pchar.quest.PL_Q8_ResEnterBox.win_condition.l1 = "locator";
			pchar.quest.PL_Q8_ResEnterBox.win_condition.l1.location = "Panama_TownhallRoom";
			pchar.quest.PL_Q8_ResEnterBox.win_condition.l1.locator_group = "box";
			pchar.quest.PL_Q8_ResEnterBox.win_condition.l1.locator = "private1";
			pchar.quest.PL_Q8_ResEnterBox.function = "PL_Q8_ResEnterBox";
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload3", "none", "", "", "OpenTheDoors", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//в резиденции Панамы с ключом
		case "PL_Q8_Panama2":
			npchar.quest.locInd = FindLocation(pchar.location);
			sld = &locations[sti(npchar.quest.locInd)];
			if (CheckAttribute(sld, "private1.money")) sld.private1.money = 0;
			if (CheckAttribute(sld, "private2.money")) sld.private2.money = 0;
			dialog.text = "Je vois que tu as accompli la mission. Tu as trouvé la clé !";
			link.l1 = "Oui ! Oם est le gouverneur ?";
			link.l1.go = "PL_Q8_Panama2_1";
		break;
		case "PL_Q8_Panama2_1":
			dialog.text = "Il est parti dans l'autre monde. J'ai eu l'impression qu'il ne t'avait pas tout dit, alors je l'ai interrogé avec passion. Mais sa santé l'a lâché...";
			link.l1 = "Hum, tu as appris quelque chose d'important ?";
			link.l1.go = "PL_Q8_Panama2_2";
		break;
		case "PL_Q8_Panama2_2":
			dialog.text = "Il savait combien d'or il y avait dans le coffre fermé. Il y a 50 millions de piastres, "+ GetSexPhrase("l'ami","" + pchar.name + "") +" ! Oui, tu le sais déjà sans moi ; allez, déballe le butin !";
			link.l1 = "Voici l'argent, Morgan. Dis-moi, comment comptes-tu organiser le partage ?";
			link.l1.go = "PL_Q8_Panama2_3";
			sld = &locations[sti(npchar.quest.locInd)];
			if (CheckAttribute(sld, "private1.items.gold")) DeleteAttribute(sld, "private1.items.gold");
			else AddMoneyToCharacter(pchar, -50000000);
		break;
		case "PL_Q8_Panama2_3":
			dialog.text = "Nos braves pirates ont caché beaucoup de choses dans leurs poches. Aujourd'hui, je vais les obliger à tout verser au pot commun, et ensuite, nous partagerons tout le butin selon les lois des Frères de la Cכte.";
			link.l1 = "Hum, ce serait juste !";
			link.l1.go = "PL_Q8_Panama2_4";
		break;
		case "PL_Q8_Panama2_4":
			dialog.text = "Tu as déjà remis ton butin, alors je n'ai rien à te reprocher : l'opération que je prépare ne te concerne pas. Mais j'ai un travail pour toi pendant ce temps. "+
				"Retourne au fort de Panama. Il y a un coffre derrière le fort, à l'extérieur du mur. Il doit contenir encore de l'or de l'Escurial ! C'est ce qu'a dit feu le gouverneur de Panama.";
			link.l1 = "Bon sang, ce n'est pas possible ! א l'extérieur ?!";
			link.l1.go = "PL_Q8_Panama2_5";
		break;
		case "PL_Q8_Panama2_5":
			dialog.text = "C'est exact, le coffre se trouve juste au bord d'une falaise à pic. Je t'attends avec cet or, alors ne traîne pas.";
			link.l1 = "D'accord, je vais vérifier tout de suite.";
			link.l1.go = "PL_Q8_Panama2_6";
		break;
		case "PL_Q8_Panama2_6":
			AddQuestRecord("Pir_Line_8_Panama", "12");
			AddQuestUserData("Pir_Line_8_Panama", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Pir_Line_8_Panama", "sSex1", GetSexPhrase("", "e"));
			Pchar.quest.PL_Q8_inPanamaFort2.win_condition.l1 = "location";
			Pchar.quest.PL_Q8_inPanamaFort2.win_condition.l1.location = "Panama_Fort";
			Pchar.quest.PL_Q8_inPanamaFort2.function = "PL_Q8_inPanamaFort2";
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload2", "none", "", "", "OpenTheDoors", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//Морган в Порт Рояле
		case "PL_Q8_afterPanama":
			dialog.text = "דa alors, quelle rencontre ! " + pchar.name + ", c'est toi ?!";
			link.l1 = "Moi, en personne. Je suis là pour te regarder dans les yeux.";
			link.l1.go = "PL_Q8_afterPanama_1";
		break;
		case "PL_Q8_afterPanama_1":
			dialog.text = "Tu m'en veux sans doute. Bon, je suis désolé d'avoir dמ te laisser à Panama, j'étais pressé, tu comprends.";
			link.l1 = "T'en vouloir ?!! Non, je ne t'en veux pas. Je te méprise comme un rat qui a volé la part des Frères de la Cכte !";
			link.l1.go = "PL_Q8_afterPanama_2";
		break;
		case "PL_Q8_afterPanama_2":
			dialog.text = "Réfléchis à ce que tu dis !!! Tu sais, les temps changent !";
			link.l1 = "De quels temps tu parles, bon sang ?!!";
			link.l1.go = "PL_Q8_afterPanama_3";
		break;
		case "PL_Q8_afterPanama_3":
			dialog.text = "Des temps tout à fait ordinaires, "+ GetSexPhrase("l'ami","" + pchar.name + "") +". Tu espères piller des navires en mer ou prendre des villes d'assaut jusqu'à la fin de tes jours ? La piraterie a pu se développer ainsi parce qu'il y avait la guerre entre les grandes puissances. Dès qu'une paix durable sera établie, nous deviendrons aussitכt superflus ! Ce temps est déjà venu ! Tu es déjà de trop !";
			link.l1 = "Oui, personne n'a jamais eu besoin de nous, à part des imposteurs qui cherchaient à s'enrichir sur notre dos ! Nous avons toujours été utilisés à des fins égoïstes par des gens comme toi ! Et puis ils nous ont trahis sous couvert de lois contre la piraterie !";
			link.l1.go = "PL_Q8_afterPanama_4";
		break;
		case "PL_Q8_afterPanama_4":
			dialog.text = "Personne ne te touchera maintenant. J'ai réussi à me justifier devant le tribunal pour la prise de Panama, mais sais-tu pourquoi ?";
			link.l1 = "Ne joue pas les saints ! L'argent que tu as emporté en Angleterre n'a aidé que toi, et nous, on nous a pourchassés et on nous pourchassera encore ! Les puissances, les rois, les gouverneurs, quand ça les arrange, essaient d'affaiblir l'ennemi par nos mains, puis ils nous pendent hypocritement sur les places ! Et ils nous rassemblent de nouveau sous leurs bannières quand le besoin s'en fait sentir.";
			link.l1.go = "PL_Q8_afterPanama_5";
		break;
		case "PL_Q8_afterPanama_5":
			dialog.text = "Oui. J'ai rendu un grand service à la couronne anglaise : j'ai considérablement réduit le nombre de pirates dans les Caraïbes, et j'ai même rapporté une telle somme au Trésor anglais !";
			link.l1 = "Notre argent, Morgan !!! Le nכtre ! L'argent de ces gars qui croyaient en toi comme en un héros, que tu as attirés dans la jungle par la flatterie et la promesse de gloire et de richesse, puis abandonnés dans un Panama pillé et affamé. L'argent de ceux dont les os pourrissent sous ses murs !";
			link.l1.go = "PL_Q8_afterPanama_6";
		break;
		case "PL_Q8_afterPanama_6":
			dialog.text = "Oui, "+ GetSexPhrase("l'ami","" + pchar.name + "") +". Et c'était la seule chance de continuer à exister. Et de toute façon, je suis planteur maintenant, pas amiral des Frères de la Cכte.";
			link.l1 = "C'était une chance pour toi ! Mais pour nous, tu as déjà cessé d'exister en tant que personnage d'importance. Et si ce genre d'existence te plaît, alors je vais te dire une chose : dans cinq ans à peine, tu seras devenu un gros porc ivrogne à qui aucun corsaire qui se respecte ne serrera la main. Et puis tu mourras du rhum dans une flaque de ton propre fumier, et les pirates viendront cracher sur la pierre tombale de la plus célèbre des crapules !";
			link.l1.go = "PL_Q8_afterPanama_7";
		break;
		case "PL_Q8_afterPanama_7":
			dialog.text = "Tu n'as rien compris ! J'ai payé pour moi, pour toi et pour tous les pirates qui veulent vivre une vie normale ! Les Frères de la Cכte n'existent plus, donc leur amiral non plus. J'ai apporté à tous les pirates le pardon du trכne d'Angleterre ! Et ceux qui ne veulent pas obéir, je les punirai.";
			link.l1 = "Que peux-tu faire ? Sans nous, tu es devenu une cible comme n'importe quel autre gouverneur. Sans le soutien des pirates, tu t'es transformé en un fonctionnaire ordinaire, obligé de nous payer pour ta tranquillité.";
			link.l1.go = "PL_Q8_afterPanama_8";
		break;
		case "PL_Q8_afterPanama_8":
			dialog.text = "Garde à l'esprit, " + PChar.name + ", que tu joues avec le feu. Je n'épargnerai personne, tu me connais !";
			link.l1 = "C'est pourquoi je te défie ! Je détruirai toutes les colonies l'une après l'autre jusqu'à ce qu'il ne reste plus une seule ville anglaise dans les Caraïbes, et alors on te rappellera en Europe pour te présenter la note ! D'ici là, tu te réveilleras la nuit au bruit des feuilles de palmier qui frappent à ta fenêtre et tu attraperas ton pistolet, de peur que " + GetFullName(PChar) + " ne vienne chercher ta sale âme !";
			link.l1.go = "PL_Q8_afterPanama_9";
		break;
		case "PL_Q8_afterPanama_9":
			dialog.text = "Eh bien, comme tu voudras... Tu as choisi ton destin toi-même.";
			link.l1 = "Adieu, Henry, tu es pitoyable. Je le dirai à tes anciens amis.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "over";
            AddQuestRecord("Pir_Line_8_Panama", "14");
	    AddQuestUserData("Pir_Line_8_Panama", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Pir_Line_8_Panama");
		break;

		//*************************** Квест "Orion fluyt accompaniment"Орион"" **********************

		case "Andre_Abel_Quest_Morgan_Dialog_1":
			dialog.text = "Vous avez affaire à moi ?";
			link.l1 = "Oui, amiral. Un brave homme a vraiment besoin de ton aide.";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_2";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_2":
			dialog.text = "Expose-moi l'affaire, je n'ai pas beaucoup de temps.";
			link.l1 = "Tu as entendu parler d'un marchand nommé André Abel ?";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_3";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_3":
			dialog.text = "André Abel, André Abel... J'ai entendu parler de lui... par Jackman, si je ne m'abuse.";
			link.l1 = "C'est exact. Jackman le poursuit depuis qu'Abel a refusé de lui verser 50 % de ses bénéfices.";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_4";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_4":
			dialog.text = "דa y est ! Je me souviens !.. Ah oui, Abel ! Ha ha ha !.. Alors, c'est lui qui t'a envoyé régler cette question ?";
			link.l1 = "Après plusieurs attaques de pirates, il est complètement ruiné, et il a demandé à Jackman d'intercéder en sa faveur, mais celui-ci ne veut rien entendre.";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_5";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_5":
			dialog.text = "Tu vois, capitaine " + GetFullName(pchar) + " ? Voilà oם mènent la cupidité et le refus de partager... "+
                          "Bon, je veux bien écrire à Jackman à son sujet, mais à condition que tu me rendes un service... Donnant, donnant, pour ainsi dire.";

			link.l1 = "Et de quel service s'agit-il ?";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_6";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_6":
			dialog.text = "J'ai besoin que tu remettes une lettre officielle au gouverneur général de Curaçao, Peter Stuyvesant.";
			link.l1 = "Ouf, je la remettrai, bien sמr !";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_9";
			link.l2 = "Pardon, amiral, mais j'avais de tout autres projets...";
			link.l2.go = "Andre_Abel_Quest_Morgan_Dialog_7";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_7":
			dialog.text = "Hum, d'oם vient une telle arrogance ? Alors, tu crois qu'on peut m'occuper avec des fables sur ce « brave homme » d'Abel, et qu'après que j'ai sacrifié mes principes et que je suis prêt à l'aider, toi, tu ne lèverais pas le petit doigt pour moi ? "+
                          "Nous ne nous entendrons pas là-dessus. Adieu.";
			link.l1 = "Soit, mais moi aussi, j'ai mes principes. Je ne fais pas les commissions de tout le monde...";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_8";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_8":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddQuestRecord("Andre_Abel_Quest", "12");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			ChangeCharacterAddressGroup(CharacterFromID("Andre_Abel"), "none", "", "");
			PChar.QuestTemp.Andre_Abel_Quest_PortPax_TavernOwner_Speek = true; // Флаг для разговора с тавернщиком в Порт-о-Принсе
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_9":
			dialog.text = "Eh bien, parfait. Tu as 10 jours pour t'en acquitter. Alors, dépêche-toi.";
			link.l1 = "D'accord, je pars immédiatement.";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_10";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_10":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			Log_TestInfo("A letter has been received from Henry Morgan.");
			GiveItem2Character(PChar, "letter_1");
			ChangeItemDescribe("letter_1", "itmdescr_Andre_Abel_Quest_Letter_1");
			AddQuestRecord("Andre_Abel_Quest", "14");
			QuestSetCurrentNode("hol_guber", "Andre_Abel_Quest_Hol_Gov_Node_1");
			SetFunctionTimerCondition("Andre_Abel_Quest_Curasao_10Days_Left", 0, 0, 10, false);
			SetFunctionLocationCondition("Andre_Abel_Quest_In_Curacao_Townhall", "Villemstad_townhall", false);
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_11":	// Попали в тюрьму
			dialog.text = "Content de te voir en vie et en un seul morceau... Alors, tu as remis la lettre ?";
			link.l1 = "Oui, je l'ai remise. C'est uniquement pour ça que j'ai fini en prison et qu'on a voulu me pendre !";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_12";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_12":
			dialog.text = "Hum, je savais que le gouverneur général de Curaçao était soupe au lait. Mais je ne m'attendais pas du tout à ce qu'on en arrive à une arrestation... "+
                          "Mais je suis content que tu aies réussi à t'en sortir.";
			link.l1 = "Et moi, donc ! Tu ne peux pas imaginer...";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_13";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_13":
			dialog.text = "Bon, bon... Si c'était aussi simple, j'aurais envoyé l'un de mes hommes de main, mais s'il avait échoué, on l'aurait pendu à coup sמr. Alors que toi, tu es une personne désintéressée, pour ainsi dire.";
			link.l1 = "Voilà donc ce qu'était mon service...";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_14";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_14":
			dialog.text = "Bon, ça suffit !.. En fait, je n'ai jamais douté que tu pourrais revenir en vie. Dans ce genre d'affaires, l'ignorance joue parfois un rכle décisif. Les bourgeois disent ensuite que la chance sourit aux simples d'esprit... "+
                          "Voici une lettre pour Jackman. Comme convenu : donnant, donnant.";
			link.l1 = "Merci quand même...";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_15";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_15":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			Log_TestInfo("A letter has been received from Henry Morgan.");
			GiveItem2Character(PChar, "letter_1");
			ChangeItemDescribe("letter_1", "itmdescr_Andre_Abel_Quest_Letter_2");
            AddQuestRecord("Andre_Abel_Quest", "21");
	    AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
	    AddQuestUserData("Andre_Abel_Quest", "sSex1", GetSexPhrase("", "e"));
            QuestSetCurrentNode("Jackman", "Andre_Abel_Quest_Jackman_Dialog_7");
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_16":	// Отбивались от солдат в резиденции
			dialog.text = "Content de te voir en vie et en un seul morceau... Alors, tu as remis la lettre ?";
			link.l1 = "Remise... Seulement, j'ai failli finir en prison !";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_12";
		break;

		case "Andre_Abel_Quest_Morgan_Dialog_17":
			dialog.text = "En prison ?! Les Hollandais sont plus sanguinaires que je ne le pensais : jeter un messager en prison... Bon, d'accord... L'essentiel, c'est que tu as remis la lettre, ce qui veut dire que tu as accompli ma mission.";
			link.l1 = "Et ?";
			link.l1.go = "Andre_Abel_Quest_Morgan_Dialog_14";
		break;


// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		case "AngryRepeat_1":
            dialog.text = RandPhraseSimple("Fichez le camp d'ici !", "Sors de mon bureau !");
			link.l1 = "Ah...";
		    link.l1.go = "AngryExitAgainWithOut";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся с Морганом через 10 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Vous ne devriez pas me distraire de mes affaires avec des appels creux. Désormais, le résultat pourrait être plus fâcheux...";
        			link.l1 = "Compris, Morgan.";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
            }
    	break;
		case "AngryRepeat_2":
            dialog.text = RandPhraseSimple("Tu m'as vraiment fatigué, fini les discussions.", "Je ne veux pas parler avec vous, alors vous feriez mieux de ne pas m'embêter.");
			link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Hum, eh bien...");
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся с Морганом через 20 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "J'espère qu'à l'avenir, vous ne m'ennuierez pas avec des conversations creuses, sinon je devrai vous tuer. J'avoue que cela me serait très désagréable.";
        			link.l1 = "Je ne le ferai plus, Morgan.";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
            }
    	break;
		case "AngryExitAgain":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
		break;
		case "AngryExitAgainWithOut":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
			if (Pchar.location == "SentJons_HouseF3")
			{
				DoReloadCharacterToLocation("SentJons_town","reload","houseF3");
			}
			else
			{
				DoReloadCharacterToLocation("PortRoyal_town","reload","houseS1");
			}
		break;
// <<<<<<<<<<<<============= блок нод angry =============================
	}
}

