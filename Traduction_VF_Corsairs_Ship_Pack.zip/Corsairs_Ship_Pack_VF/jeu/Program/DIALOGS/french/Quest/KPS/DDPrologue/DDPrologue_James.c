// Gregg: James Robinson - alternative prologue "Desert Island" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\ddprologue.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (CheckAttribute(PChar, "StartDamnedDestiny"))
			{
				if (PChar.StartDamnedDestiny == "1")
				{
					dialog.text = "Capitaine, nous devrions nous dépêcher d'aller à la grotte !";
					link.l1 = "Tu as raison, allons-y.";
					link.l1.go = "exit";
					break;
				}
			}
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "Start_1":
			dialog.text = "Capitaine " + PChar.lastname + ", vous êtes en vie ! Bon sang, comme je suis content de vous voir ! Vous avez des blessures ?";
			link.l1 = "Non, je ne crois pas. J'ai seulement très mal à la tête.";
			link.l1.go = "Start_2";
		break;

		case "Start_2":
			dialog.text = "Pas étonnant. Vous vous êtes cogné la tête contre un canon pendant cette terrible explosion. Vous avez eu beaucoup de chance de survivre.";
			link.l1 = "Que s'est-il passé, au fait ? Je ne me souviens de rien du tout...";
			link.l1.go = "Start_3";
		break;

		case "Start_3":
			dialog.text = "De rien du tout ?";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartDamnedDestinyStartFade");
		break;

		case "Start_4":
			dialog.text = "Pas même de votre nom ?";
			link.l1 = "Non, je n'arrive à me souvenir de rien.";
			link.l1.go = "Start_5";
		break;

		case "Start_5":
			dialog.text = "Vous avez dמ heurter ce canon bien fort. Bon, capitaine, écoutez. Je suis James Robinson, je suis entré à votre service il y a environ trois mois. J'étais fier d'avoir l'honneur de naviguer sur le navire du capitaine " + GetMainCharacterNameGen() + ". \n Il y a environ un mois, dans une taverne des Bermudes, vous avez rencontré votre vieil ami, le capitaine Grifo Sajfus, qui vous a proposé une affaire. L'attaque d'un petit navire qui transportait soi-disant un lot de diamants d'Afrique. Vous avez accepté de le retrouver ici, sur l'île déserte de la Dominique, pour mettre au point le plan et passer à l'action, mais \n Grifo vous a trahi. Et nous tous avec vous.";
			link.l1 = "Trahi ? Comment est-ce arrivé ?";
			link.l1.go = "Start_6";
		break;

		case "Start_6":
			dialog.text = "De nuit, quand les navires se sont rapprochés, il a vidé tous les canons de son bord bâbord sur notre chébec rapide, puis il a viré de bord et a balayé notre pont à la mitraille depuis tribord. La moitié de notre équipage est morte dès la première salve, et vous vous êtes cogné la tête contre un canon et vous avez perdu connaissance. \n Nous voulions riposter, mais après la deuxième salve, qui a coמté la vie à quinze ou vingt autres hommes, nous avons compris que c'était inutile et nous avons sauté à la mer. J'ai vu notre maître d'équipage, Andy Rejdol, vous charger sur son épaule et sauter avec vous. J'ai réussi à atteindre le rivage, et c'est là que je vous ai trouvé. Bon sang, cap'taine, comme je suis heureux que vous soyez en vie !";
			link.l1 = "Moi aussi, je suis content, " + NPChar.name + ". Combien de nos hommes ont survécu, à ton avis ?";
			link.l1.go = "Start_7";
		break;

		case "Start_7":
			dialog.text = "Je ne sais pas, cap'taine. Je doute que beaucoup de ceux qui ont sauté à la mer aient été sauvés. Le navire de Grifo Sajfus a continué longtemps à arroser l'eau de mitraille, dans l'espoir de nous achever tous. Alors, voyez-vous, cap'taine, s'il y a des survivants, ils sont quatre au plus, enfin cinq, pas davantage.";
			link.l1 = "וcoutez, " + NPChar.name + ", je me disais que nous restions plantés sur cette plage pour rien. Si le navire de Sajfus est encore là, ils vont nous repérer et ouvrir le feu. Ou pire, débarquer des hommes pour traquer les survivants. Il faut s'enfoncer dans la jungle.";
			link.l1.go = "Start_8";
		break;

		case "Start_8":
			dialog.text = "Je sais qu'il y a une petite grotte quelque part près d'ici, nous pourrons nous y abriter un moment et réfléchir à la suite. Et qui sait, ceux qui ont survécu y ont peut-être trouvé refuge.";
			link.l1 = "Alors ne traînons pas, en avant !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameGoToGrot");
		break;

		case "Start_9":
			dialog.text = "Capitaine " + PChar.lastname + ", excellente nouvelle ! Un petit lougre a jeté l'ancre au large de la plage voisine ! Son capitaine et quelques-uns de ses hommes sont déjà descendus à terre, et si nous nous dépêchons, nous pourrons encore les trouver là-bas.";
			link.l1 = "Parfait, " + NPChar.name + ". En route !";
			link.l1.go = "Start_10";
		break;

		case "Start_10":
			dialog.text = "Attendez, capitaine " + PChar.lastname + " ! Méfiez-vous du capitaine du lougre, il m'a paru louche.";
			link.l1 = "Alors toi, James, et toi, Andy, couvrez-moi si quelque chose tourne mal. C'est clair ? Alors en avant !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameNextDayToLugger");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
