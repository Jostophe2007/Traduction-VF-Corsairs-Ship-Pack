// Gregg: Алехон Кендарт - трилогия «Чёрная Орхидея», финал главы 5 (перенос из К:ПС).
// Логика - Program\Quests\reaction_functions\blackorchid.c
// Грот Теркса. Последний обладатель Орхидеи ждал того, кто соберёт Меритор:
//   1-3   - передача Орхидеи;
//   4-6   - чем она была и что от неё осталось;
//   6a-6b - посев: кого-то взяли вместо него, кто Орхидею и не искал (см. ниже);
//   7-9   - Меритор ушёл к новым соискателям, уничтожить Орхидею Кендарт не умеет;
//   10    - прощание, выход в бой (DestinyGiftFinalBattle).
// Узел 1 выставляет логика. Кендарт остаётся в мире и переходит в главы 6-9,
// поэтому «First time» - заглушка, её займёт диспетчер следующих глав.
//
// Gregg: ТРИ отступления от оригинала, оба принципиальные.
// 1. В К:ПС остаток силы Орхидеи - два месяца полной неуязвимости, после чего она
//    становится простым камнем. У нас Орхидея - оберег (снижение урона плюс одно
//    спасение от смертельного удара, см. BlackOrchid_IsWorn в blackorchid.c), и это
//    объясняется его же работой: он стёр её почти до конца, остаток скромен, но вечен.
// 2. В оригинале ГГ обещал через два месяца уничтожить Орхидею или спрятать её.
//    Обещания нет: глава 6 у нас идёт иначе, настоящая Орхидея остаётся у игрока,
//    и давать зарок, который мы не исполним, незачем. Вопрос оставлен открытым.
// 3. Узлы 6a-6b - НАШЕ добавление, в оригинале их нет. Оригинальный Кендарт молчит
//    о своём мотиве до самой главы 6, где выясняется, что испанцы, разыскивая его,
//    взяли и запытали до смерти его брата (Alehon Kendart.c, узел SpanishGenerosity_9).
//    Из-за этого его разворот в шестой главе - «продадим Орхидею Испании» - выглядит
//    подменой характера. Здесь мы кладём зацепку: кого-то взяли вместо него, и этот
//    кто-то Орхидею не искал. Ни нации, ни родства, ни имени - иначе разворот
//    в главе 6 перестанет быть разворотом. Заодно объясняется, почему он живёт
//    в гроте. Реплика узла 7 про «чтобы Орхидея досталась вам, а не Испании» тоже
//    наша: в главе 6 игрок процитирует её Кендарту в лицо.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name;
	string sFullName = GetFullName(PChar);


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Bonne chance à vous, " + sName + ".";
			link.l1 = "א vous aussi, Alejon.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(d'une voix douce et calme)... " + sFullName + ". Je savais que ce jour viendrait. Je savais que ce serait vous qui me trouveriez.";
			link.l1 = "...(d'un ton impérieux)... L'Orchidée noire. Donnez-la-moi. Maintenant.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je vais vous la donner, " + sName + ". Mais d'abord, une question. Acceptez-vous d'en devenir " + GetSexPhrase("le maître", "la maîtresse") + " ? Acceptez-vous que les autres viennent à votre poursuite, sans jamais s'arrêter ?";
			link.l1 = "J'accepte. Donnez-la-moi.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Dès cet instant, vous êtes " + GetSexPhrase("le maître", "la maîtresse") + " de l'Orchidée noire.";
			link.l1 = "...(retournant l'Orchidée)... C'est tout ? Une pierre ordinaire dans une monture.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Maintenant, oui. Pendant toutes les années oם l'Orchidée a été à moi, j'ai usé son pouvoir jusqu'à presque rien. Et j'y suis presque parvenu : c'est ce dont je suis le plus fier dans ma vie. Ce que vous tenez, c'est l'ombre de l'Orchidée d'autrefois.";
			link.l1 = "Une ombre ? Alors, elle ne sert plus à rien ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Si. Portez-la, et la lame qui aurait dמ vous couper en deux ne laissera qu'une égratignure. Et une fois, quand le coup se révélera mortel, elle ne vous laissera pas tomber. Une seule fois. Ensuite, il lui faut du temps pour se ressaisir. C'est tout ce qu'il lui reste, et ce n'est pas rien.";
			link.l1 = "Pas rien ? On m'avait dit que l'Orchidée rendait invulnérable.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "C'était le cas. Et c'est pour ça qu'elle tuait. L'Orchidée noire apporte la mort, même entre les mains de celui qui ne cherche pas le pouvoir, et moi, je ne le cherchais pas. Combien sont morts pendant que vous la cherchiez ? Combien mourront encore ? Elle fait des assassins des hommes bons, dès qu'ils comprennent ce dont ils sont capables en la tenant. Je lui ai retiré ça. Je lui ai laissé exactement de quoi garder son maître en vie, et pas une goutte de plus.";
			link.l1 = "Vous en parlez comme si vous l'aviez payé vous-même.";
			link.l1.go = "6a";
		break;

		case "6a":
			dialog.text = "C'est le cas. Et ce ne sont pas seulement ceux qui la cherchaient qui ont payé. Une fois, on l'a cherchée à travers moi : on ne m'a pas trouvé, alors on a pris un homme qui n'avait jamais entendu parler de l'Orchidée. Il n'avait rien à leur dire. Ils l'ont interrogé longtemps.";
			link.l1 = "Qui était-ce ?";
			link.l1.go = "6b";
		break;

		case "6b":
			dialog.text = "...(un long silence)... Pardonnez-moi. Je n'en parle pas. Je dirai seulement que si je vis dans une grotte, sur une île nue, ce n'est pas par goמt de l'humidité.";
			link.l1 = "...(doucement)... Alors, tout ça pour un talisman au bout d'un cordon.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Tout ça pour que l'Orchidée vous revienne, à vous, et non à l'Espagne. Quant au Meritor, il a rempli son office : dès que l'Orchidée s'est posée dans votre main, il a quitté votre poche. Il s'est de nouveau brisé en sept morceaux et s'est dispersé à travers les Caraïbes, pour attendre le suivant.";
			link.l1 = "Le suivant ? Alors ils viendront me chercher.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Ils viendront. Et ils continueront à venir tant que l'Orchidée existera.";
			link.l1 = "Alors aidez-moi à m'en débarrasser, Alejon. Vous avez vécu avec elle pendant des années : vous devez savoir comment faire.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Je ne sais pas, " + PChar.lastname + ". Et je ne vous conseillerais pas de le deviner : ceux qui ont essayé de deviner sont morts bien avant que l'Orchidée ne commence à faiblir. J'ai fait ce que j'ai pu ; le reste, c'est à vous de le décider. Et maintenant, je vais vous quitter.";
			link.l1 = "Me quitter ? Et comment comptez-vous sortir d'ici ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "J'ai appris à me passer de l'Orchidée, moi aussi, " + PChar.lastname + ". Bonne chance. Adieu.";
			link.l1 = "Non, attendez !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFinalBattle");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
