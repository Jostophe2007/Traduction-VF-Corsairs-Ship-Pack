// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_PK_IshemKoltso"))	// Квест "The Lost Ring"
            {
                link.l1 = "Je cherche une bague qui appartenait à... à l'un de mes amis. Une bague d'une certaine valeur. Et cette bague se trouve quelque part dans cette ville. Vous en avez peut-être entendu parler ? Un gros saphir serti dans de l'or.";
                link.l1.go = "IshemKoltso";
            }
			if(PChar.MysteriousIsland == "10" && PChar.MysteriousIsland.FindForser.Citizen == false)	// Квест "The Mysterious Island"
			{
				link.l1 = "וcoutez, savez-vous quelque chose sur un certain capitaine Davy Forser ?";
				link.l1.go = "MysteriousIsland_1";
			}
		break;

		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Que voulez-vous que je vous dise ? Je ne sais pas. Je ne sais rien.";

            link.l1 = "Quel imbécile ! Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

//******************** Квест "The Lost Ring" ******************
		case "IshemKoltso":
			int Phrase;
                Phrase = rand(4);
                if (Phrase == 0)
                {
					dialog.text = "Vous me prenez pour qui, un joaillier ? Cette question n'est vraiment pas pour moi.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
                if (Phrase == 1)
                {
					dialog.text = "J'ai bien une bague, mais elle porte " + LinkRandPhrase("un rubis", "une émeraude", "un diamant") + ".";
					link.l1 = "Tant mieux pour vous.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 2)
                {
					dialog.text = "J'ai des choses plus importantes à faire que de répondre à de telles sornettes.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 3)
                {
					dialog.text = "Je n'ai pas de bagues, désolé.";
					link.l1 = "Bon, je vais demander à quelqu'un d'autre.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 4)
                {
					dialog.text = "Hum... Un saphir, dites-vous ? Oui, j'en ai bien vu une, j'en suis sמr"+ NPCharSexPhrase(NPChar, "", "e") +" : une bague comme celle dont vous parlez. Une fille la porte ; vous la connaissez peut-être, du moins la plupart des marins la connaissent bien. Elle s'appelle Francesca. Pour être honnête, je n'ai jamais rencontré fille plus sotte. Un soldat lui a offert cette bague il y a deux ou trois ans. Il était peut-être encore plus sot qu'elle, car cette bague vaut beaucoup d'argent. Oui, c'est sans doute la bague que vous cherchez.";
					link.l1 = "Merci, " + npchar.name+", vous ne pouvez pas savoir à quel point vous m'avez rendu service. א plus tard.";
					link.l1.go = "exit";

					AddQuestRecord("PDM_Poteryanoe_Koltso", "3");
					AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
					DeleteAttribute(pchar, "questTemp.PDM_PK_IshemKoltso");

					sld = GetCharacter(NPC_GenerateCharacter("PDM_PK_Francheska", "BaynesDaughterSTOK", "woman", "woman", 10, SPAIN, -1, false));
					sld.name = "Francesca";
					sld.lastname = "";
					sld.city = "SantoDomingo";
					sld.location	= "SantoDomingo_Brothel";
					sld.location.group = "goto";
					sld.location.locator = "goto3";
					sld.dialog.filename   = "Quest\PDM\Poteryanoe_Koltso.c";
					sld.dialog.currentnode   = "Francheska";
					LAi_SetCitizenType(sld);
					LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
					LAi_SetImmortal(sld, true);
				break;
				}
        break;
//******************** Квест "The Mysterious Island" ******************		
		case "MysteriousIsland_1":
			PChar.MysteriousIsland.FindForser.Citizen = true;
			dialog.text = "Hum... Non, je ne m'en souviens pas.";
			link.l1 = "Désolé.";
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

