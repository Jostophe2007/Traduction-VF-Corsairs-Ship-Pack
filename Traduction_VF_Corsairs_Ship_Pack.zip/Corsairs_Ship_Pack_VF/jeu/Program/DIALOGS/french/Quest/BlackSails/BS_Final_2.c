
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;






/*
		==Начало в части 3== BS_F3_1 - BS_F3_22
//Скипаем с отравления три дня. ГГ приходит в себя в комнате таверны.
//Запись в СЖ: 'Неожиданно. Но предсказуемо. Флинт поимел нас всех. Кто бы мог подумать. Хорошо, что жив(ва) остался(лась)! Нужно разобраться в происходящем. Дьявол, как же мутит то!'
		case "BS_F2_1":	//Максин
			dialog.text = "Awake? Finally! You've been out the longest.";
			link.l1 = "Is everyone alive? What's new?";
			link.l1.go = "BS_F2_2";
CloseQuestHeader("BSUrka");
SetQuestHeader("BSSevereHangover");
AddQuestRecord("BSSevereHangover", "1");
AddQuestUserData("BSSevereHangover", "sSex", GetSexPhrase("", "e"));
		break;
		==Начало в части 3== BS_F3_1 - BS_F3_22
*/






//ВАРИАНТ 2 - помощь Бонсу, а позже Вейну.
//Если ищем Вейна, то при визите в Ла Вегу – он в Пуэрто-Присипе, если на Кубу, то в Ла Веге.
//Прибыв в один из вариантов – запись в СЖ: ''Рейнджера' на рейде не видно. Расспрошу местных'		 	AddQuestRecord("BSSevereHangover", "41");
		case "BS_F2_23":	//Бармены и мэры Ла Веги/ПуэртоПринсипе
			dialog.text = "Non, le capitaine Vane n'est pas venu ici depuis longtemps";
			link.l1 = "...";
			link.l1.go = "exit";
		break;

//Плывём на второй вариант.
//Запись в СЖ: ''Рейнджер' на якоре! Шлюпку на воду!'		AddQuestRecord("BSSevereHangover", "42");
		case "BS_F2_24":	//Говорим с вахтенным
			dialog.text = "";
			link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Oם est le capitaine ? J'ai à lui parler.";
			link.l1.go = "BS_F2_25";
		break;
		case "BS_F2_25":
			dialog.text = "Il a débarqué hier avec une compagnie d'abordage et il est parti dans la jungle. Il a fait un sacré raffut au village, ça a failli tourner à la bagarre ; nos gars ont peur de descendre à terre";
			link.l1 = "La diplomatie à la Vane. Ha. Je vois. Je descends à terre ; ne vous soמlez pas ici avec mes hommes !";
			link.l1.go = "exit";
		break;

//Высаживаемся на берег, идём в поселение. У главы или бармена диалог
		case "BS_F2_26":	//Бармены и мэры Ла Веги/ПуэртоПринсипе
			dialog.text = "";
			link.l1 = "J'ai entendu dire que le capitaine Vane était passé chez vous l'autre jour. Pourquoi a-t-il fait du grabuge ?";
			link.l1.go = "BS_F2_27";
		break;
		case "BS_F2_27":
			dialog.text = "C'est un pirate respecté et hardi, mais il a le sang trop chaud. Il a abîmé des biens ici, cassé deux ou trois têtes, et il a filé";
			link.l1 = "Et oם est-il allé ? Nous avons une affaire en commun, lui et moi. Bien sמr, je n'ai pas sa réputation de pirate, mais je sais aussi abîmer les biens et les têtes !";
			link.l1.go = "BS_F2_28";
		break;
		case "BS_F2_28":
			dialog.text = "Loin, dans la jungle. Il y a là-bas des camps d'esclaves fugitifs venus de tout l'archipel";
			link.l1 = "Et Flint, il s'est montré ici ?";
			link.l1.go = "BS_F2_29";
		break;
		case "BS_F2_29":
			dialog.text = "Pas depuis longtemps ; avant, il allait souvent dans la jungle";
			link.l1 = "Il y a des guides qui pourraient m'indiquer les camps ?";
			link.l1.go = "BS_F2_30";
		break;
		case "BS_F2_30":
			dialog.text = "Il y en avait un, il est parti avec Vane";
//Запись в СЖ: 'Возможность последовать за Вейном я упустил(), без опытных проводников, соваться в джунгли – самоубийство. Что же, подожду тут'
			AddQuestRecord("BSSevereHangover", "43");
			link.l1 = "Bon sang. Il n'y a plus qu'à attendre. א la prochaine";
			link.l1.go = "exit";
		break;

//Снимаем комнату, на второй день в таверну приходят Вейн и чел с моделькой негра, в красной рубахе Коффи.
		case "BS_F2_29":	//Вейн
			dialog.text = "";
			link.l1 = "Salut, Charles. J'ai eu du mal à te trouver ! Qui est avec toi ?";//Qwerry: Друг? Толерастия!
			link.l1.go = "BS_F2_30";
		break;
		case "BS_F2_30":	//Вейн
			dialog.text = "C'est Coffey, une sorte de chef des fugitifs. Et il sait oם est Flint.";
			link.l1 = "";
			link.l1.go = "BS_F2_30_1";
		break;
		case "BS_F2_30_1":
			DialogExit();
sld = CharacterFromID("");//TO DO<<<<<<<<!!!!!!!указать имя===================================<<<<<<<<<<<<<<<<<<<<<<<<
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_31";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_31":	//Коффи
			dialog.text = "Coffey sait. Vane a promis aider. Coffey dit oם est Flint.";
			link.l1 = "";
			link.l1.go = "BS_F2_31_1";
		break;
		case "BS_F2_31_1":
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_32";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_32":	//Вейн
			dialog.text = "Un vrai silex, ce Flint, rien ne l'entame. Voilà le fond de l'affaire : Flint a promis de faire passer les fugitifs sur le continent, dans les colonies du Nord. Là-bas, personne ne se soucie de qui tu es ni d'oם tu viens. Seulement, il n'a tenu sa promesse qu'à moitié. Ceux qui sont montés sur le navire ont été enrכlés, et ceux qui étaient contre, aussitכt par-dessus bord. Flint prépare quelque chose comme une guerre contre les autorités coloniales. Il se voit roi. Et notre butin, c'est le trésor de son royaume.";
			link.l1 = "Flint est un homme ambitieux ! Je ne peux pas m'empêcher de le respecter.";
			link.l1.go = "BS_F2_33";
		break;
		case "BS_F2_33":	//Вейн
			dialog.text = "Tu peux bien lui rouler une pelle si ça te chante ! D'abord notre argent, ensuite la tête de Flint, et après, fais-en ce que tu veux !";
			link.l1 = "";
			link.l1.go = "BS_F2_33_1";
		break;
		case "BS_F2_33_1":
			DialogExit();
sld = CharacterFromID("");//TO DO<<<<<<<<!!!!!!!указать имя===================================<<<<<<<<<<<<<<<<<<<<<<<<
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_34";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_34":	//Коффи
			dialog.text = "Vane a promis aider !";
			link.l1 = "";
			link.l1.go = "BS_F2_34_1";
		break;
		case "BS_F2_34_1":
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_35";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_35":	//Вейн
			dialog.text = "Le gouverneur du coin a récemment voulu faire cliqueter ses armes devant un gros bonnet de la métropole. Les soldats ont attrapé une bande de fugitifs dans la jungle et les ont vendus à une plantation. א la Barbade. Notre ami demande la libération des siens, et en échange, il nous livrera la cachette de Flint.";
			link.l1 = "La plantation de la Barbade est un bagne de la Couronne britannique, au fond d'une gorge, couverte par les canons du fort et les murs de la ville. Depuis le raid espagnol, la garnison a été renforcée par des fusiliers marins et des mercenaires suédois. C'est une putain de forteresse";//Qwerry: Нужна особая реплика для Блада?
			link.l1.go = "BS_F2_36";
		break;
		case "BS_F2_36":
			dialog.text = "Alors prenons-la d'assaut !";
			link.l1 = "Pour ça, il faut une préparation... et une escadre... et un millier d'hommes ou plus, alors que le temps presse. Nous partons pour la Barbade : j'ai une idée pour régler cette affaire sans verser trop de sang. Rejoins l'escadre.";
			link.l1.go = "exit";
			AddQuestRecord("BSSevereHangover", "44");
//Запись в СЖ: 'Флинт строит своё королевство. Вот так новость. Не удивлюсь, если он принц крови, в изгнании или бастард королевский. Информация о его схроне стоит дорого. Но надеюсь дело того стоит. Направляемся на Барбадос. Нужно продумать атаку плантации'
		break;

//Высаживаемся на мысе Гаррисон. На берегу Вейн, куча матросни.
		case "BS_F2_37":	//Вейн
			dialog.text = "";
			link.l1 = "J'ai envoyé des éclaireurs voir ce qu'il en est par ici. א leur retour, ils vous conduiront à la plantation ; d'après les rumeurs, il y a des sentiers dans les montagnes. Et moi, je vais en ville flairer la situation. Mes gars vont s'habiller plus convenablement et s'approcher de la plantation en passant par les portes de la ville. Quand tout sera prêt, nous frapperons des deux cכtés en même temps. Le signal, ce sera une salve de mousquets.";
			link.l1.go = "BS_F2_38";
		break;
		case "BS_F2_38":	//Вейн
			dialog.text = "Toi et Flint, vous vous ressemblez. Vous pensez de la même façon. Tu suivras le même chemin ?";
			link.l1 = "דa te dérange ? Nous avons une affaire à mener, et il faut la mener sans erreur. Bon, je vais en ville ; attends le retour des éclaireurs, puis mettez-vous en route.";
			link.l1.go = "exit";
//Запись в СЖ: 'Я на Флинта похожу? Что за бред. Осмотрюсь в городе, пока мои бойцы проникают за ворота'.
			AddQuestRecord("BSSevereHangover", "45");
		break;

//Проникаем в город. Просто бродим туда-сюда. У выхода из борделя встречаем Сильвера.
		case "BS_F2_39":	//Сильвер
			dialog.text = "";
			link.l1 = "Quelle surprise ! John, ça fait longtemps ! Flint est ici, lui aussi ?";
			link.l1.go = "BS_F2_40";
		break;
		case "BS_F2_40":	//Сильвер
			dialog.text = "Je me suis sauvé de chez Flint : il s'est mis à se débarrasser de l'ancien équipage, en pleine mer. Tout le pont était trempé de sang. J'ai eu du mal à m'en tirer ! Je cherche quelqu'un pour me déposer sur le continent, il faut que je disparaisse";
			link.l1 = "Pourquoi Flint voudrait-il se débarrasser de toi ?";
			link.l1.go = "BS_F2_41";
		break;
		case "BS_F2_41":	//Сильвер
			dialog.text = "Pas de témoins ! Il a atteint son but, il a eu l'or, et maintenant il s'attaque au suivant.";
			link.l1 = "Tu parles du royaume des pirates libres ? J'en ai entendu parler.";
			link.l1.go = "BS_F2_42";
		break;
		case "BS_F2_42":	//Сильвер
			dialog.text = "וcoute, nous ne nous sommes pas disputés, et il n'y a pas de sang entre nous. Chacun de son cכté ?";
			link.l1 = "Je sens dans mes tripes que tu ne me dis pas tout, mais je n'ai pas le temps de tirer ça au clair. D'accord, disparais.";
			link.l1.go = "exit";
			AddQuestRecord("BSSevereHangover", "46");
//Запись в СЖ: 'На улицах Бриджтауна встретил() Джона Сильвера, говорит, что сбежал от Флинта. Подозрительный тип, глазки бегают и напуган явно не мной. Ладно, к дьяволу Сильвера. Пора выдвигаться к плантации'.
		break;
//Сильвер уходит

//Плантация. Кучка англичан – солдат у входа. Человек 15 наших. Четверо с мушкетами.
		case "BS_F2_43":	//ГГ сам себе
			dialog.text = "";
			link.l1 = "Feu sur les uniformes ! Tous ensemble, feu !";
			link.l1.go = "exit";
		break;

//Бабах!! Начинается файт. Англичане прут в три волны со стороны плантации. На третьей волне со стороны плантации – Вейн с бригадой. Мясо. Говорим ч Вейном
		case "BS_F2_44":	//Вейн
			dialog.text = "";
			link.l1 = "Tu es en retard ! On a failli se faire hacher menu !";
			link.l1.go = "BS_F2_45";
		break;
		case "BS_F2_45":	//Вейн
			dialog.text = "Il y avait des patrouilles dans les montagnes, on a rampé sur le ventre pour ne pas donner l'alerte trop tכt !";
			link.l1 = "Bon, le travail est fait : rassemblez les forçats, qu'ils ramassent des armes, et repli vers les montagnes. Tu entends ? Diable, la garnison arrive de la ville. Prêts au combat !";
			link.l1.go = "exit";
		break;

//Со стороны города прут ещё пару волн англичан. Файт
		case "BS_F2_46":	//Qwerry: Вейн? или сразу после боя сам себе?
			dialog.text = "";
			link.l1 = "Nous les avons repoussés, mais d'autres uniformes vont bientכt arriver du fort ! Vite, dans les montagnes !";
			link.l1.go = "exit";
		break;
//Загрузка. Перемещаем ГГ, Вейна, матросов и кучку каторжан на пляж мыса Гаррисон.
		case "BS_F2_47":	//Вейн
			dialog.text = "Il ne reste plus grand-chose à faire. Nous débarquons ces pauvres diables à La Vega. Coffey nous y attendra.";
			link.l1 = "Toutes voiles dehors ! Il ne manquerait plus qu'on doive se battre contre les garde-cכtes.";
			link.l1.go = "exit";
		break;

//Выходим в море. На глобалке атакует фиолетовая энка. 'Скарборо' линейник 1 ранга и с ним пара фрегатов. Морской бой.
//Если брать на абордаж 'Скарборо' - капитан Френсис Ньюм, моделька офицера английского. Файт в каюте. Диалог
		case "BS_F2_48":	//Ньюм
			dialog.text = "Au nom du roi ! Rendez-vous !";
			link.l1 = "Ha. Vous avez été abordés, capitaine. Rendez-vous vous-même ! Et pourquoi diable nous avez-vous attaqués ? Nous avons un accord avec le commandant Blackham !";
			link.l1.go = "BS_F2_49";
		break;
		case "BS_F2_49":	//Ньюм
			dialog.text = "Blackham a été dégradé et arrêté pour collaboration avec les pirates ; il attend son procès et la potence à Boston.";
			link.l1 = "Je le savais bien : toutes ces belles paroles sur le pardon et les récompenses, c'est de la foutaise ! L'heure de mourir est venue !";
			link.l1.go = "exit";
			AddQuestRecord("BSSevereHangover", "47");
//Запись в СЖ: 'Каторжники отбиты. Недалеко от Барбадоса, были атакованы 'Скарборо', капитан Ньюм, перед смертью рассказал о судьбе Билли. Туда и дорога. Путь на Эспаньолу, в Ла Вега ждёт своих соплеменников Кофии'.
		break;

//Берег Ла Веги. Вейн, ГГ, Коффи.
		case "BS_F2_50":	//Коффи
			dialog.text = "";
			link.l1 = "Voici tes amis, Coffey : nous avons rempli notre part du marché. Oם est Flint ?";
			link.l1.go = "BS_F2_51";
		break;
		case "BS_F2_51":	//Коффи
			dialog.text = "Il y a une maison abandonnée à deux jours d'ici. La femme de Flint vivait là. Lui souvent aller là-bas. Coffey montrera chemin.";
			link.l1 = "On peut partir tout de suite, en ce qui me concerne. Vane ?";
			link.l1.go = "BS_F2_51_1";
		break;
		case "BS_F2_51_1":
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_52";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_52":	//Вейн
			dialog.text = "Moi aussi";
			link.l1 = "";
			link.l1.go = "BS_F2_52_1";
		break;
		case "BS_F2_52_1":
			DialogExit();
sld = CharacterFromID("");//TO DO<<<<<<<<!!!!!!!указать имя===================================<<<<<<<<<<<<<<<<<<<<<<<<
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_53";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_53":	//Коффи
			dialog.text = "";
			link.l1 = "Vous marcher dans nos pas. Coffey montrer comment.";
			link.l1.go = "BS_F2_54";
		break;

//Загрузка, дом в джунглях. Коффи остаётся у выхода из локи. ГГ с Вейном заходят в дом. В сундуке 2кк денег, книга Марк Аврелий 'Размышления'.
		case "BS_F2_54":	//Вейн
			dialog.text = "Les cendres sont encore chaudes. Il est passé ici récemment. On lui tend une embuscade ?";
			link.l1 = "Il y a de l'argent et un vieux livre dans le coffre. Tu prends ta part maintenant ?";//Qwerry: Реплика до обыска сундука или после должна быть? Нужен ли вообще обыск сундука?
			link.l1.go = "BS_F2_55";
		break;
		case "BS_F2_55":	//Вейн
			dialog.text = "Plus tard. D'abord, coinçons Flint.";
			link.l1 = "Comme tu voudras. Allons jeter un coup d'œil dehors.";
			link.l1.go = "exit";
		break;

//Выходим. На улице труп Коффи, Флинт.
		case "BS_F2_56":	//Флинт
			dialog.text = "On ne peut pas tout prévoir. N'est-ce pas ? Et pourtant, vous me plaisiez. Pourquoi m'avoir pourchassé ? De toute façon, vous ne verrez jamais l'or de l'Urca. Il est bien caché.";
			link.l1 = "";
			link.l1.go = "BS_F2_56_1";
		break;
		case "BS_F2_56_1":
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			sld.dialog.filename = "Quest\BlackSails\BS_Final_2.c";
			sld.dialog.currentnode   = "BS_F2_57";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_F2_57":	//Вейн
			dialog.text = "Alors nous le trouverons, mais d'abord, je vais régler mes comptes avec toi !";
			link.l1 = "";
			link.l1.go = "BS_F2_58";
		break;
//Вейн кидается в атаку – Флинт скриптово стреляет в него. Вейн падает. И атакует ГГ
//Сурьёзный замес. Нулим НР Флинту – он скриптово стреляет, нас корчит, Флинт убегает.

		case "BS_F2_58":	//ГГ себе
			dialog.text = "Bon sang, j'ai une cכte cassée ! Vane, comment ça va, mon vieux ? La blessure est grave, il risque de se vider de son sang.";
			link.l1 = "Rester pour panser Vane.";
			link.l1.go = "BS_F2_59";
		break;

//Прошло четыре дня. Еле-еле с раненым Вейном доковыляли до кораблей.  Загрузкой с табличкой, повествующей о событиях.
//Запись в СЖ: 'Логово Флинта найдено и сам Флинт тоже. Внушительная сумма денег и старая книга. Мерзавец скрылся. Понятия не имею, что делать дальше. Доставлю Чарльза на Бермуды и обмозгуем с Гатри варианты'.
//			AddQuestRecord("BSSevereHangover", "48");

//Отплываем на Бермуды, выводим 'Рейнджера' из эскадры.
//Бермуды. Резиденция закрыта. Идём в таверну.
		case "BS_F2_59":	//бармен
			dialog.text = "";
			link.l1 = "Dis-moi, oם est Mlle Guthrie ? La résidence est fermée...";
			link.l1.go = "BS_F2_60";
		break;
		case "BS_F2_60":	//бармен
			dialog.text = "Des militaires anglais ont débarqué ici il y a peu. Cinq cents hommes, et le vaisseau de ligne Scarborough a jeté l'ancre dans la baie. Ils ont mis la ville sens dessus dessous. Mlle Guthrie et plusieurs autres personnes ont été arrêtées. Le capitaine Newm criait que la justice les avait rattrapés et que le procès à Port Royal serait expéditif.";
			link.l1 = "Comment ? Je dois me dépêcher. Adieu.";
			link.l1.go = "BS_F2_61";
			AddQuestRecord("BSSevereHangover", "49");
//Запись в СЖ: 'Гатри арестована Ньюмом! Тем самым, кого я на корм рыбам отправил(ла)! Поспешу в Порт Рояль, может быть Максин чем то поможет. И не слова Вейну, какие у них бы там отношения не были, наделает глупостей. Слишком горяч. В порт заходить не стоит, неизвестно чем всё там обернётся'
		break;

//Высаживаемся в бухте, топаем в город. Сразу в бордель.
		case "BS_F2_61":	//Максин
			dialog.text = "Je sais pourquoi tu es là. Il y a peu, le capitaine Newm a donné tout un spectacle en ville. Il a fait conduire Eleanor et Bones du port jusqu'au fort, enchaînés. Le héros, le vainqueur des pirates. Un dindon pompeux.";
			link.l1 = "Un dindon mort ! J'ai croisé le Scarborough près de la Barbade et je l'ai envoyé par le fond ! Les prisonniers sont toujours ici ?";
			link.l1.go = "BS_F2_62";
		break;
		case "BS_F2_62":
			dialog.text = "Oui, au fort. Qu'est-ce que tu manigances ? C'est du suicide ! On ne peut plus rien pour eux !";
			link.l1 = "Eux ? Je me moque de Bones, il mérite bien la corde. Je veux faire sortir Eleanor et filer d'ici toutes voiles dehors ! Tu es avec moi ? Le navire est dans la baie de Portland.";
			link.l1.go = "BS_F2_63";
		break;
		case "BS_F2_63":
			dialog.text = "Non, je suis désolée. Il m'a fallu longtemps pour obtenir ce que j'ai aujourd'hui. J'en ai assez des aventures !";
			link.l1 = "Nous avons trouvé la cachette de Flint, mais le salaud s'est enfui en blessant grièvement Vane. Il y a là une partie de l'argent. J'en mets ma main au feu : c'est l'or de l'Urca. Tiens, 500 000.";
			link.l1.go = "BS_F2_64";
		break;
		case "BS_F2_64":
			AddmoneyToCharacter(PChar, -500000);
			dialog.text = "Tu ne pourrais pas arrêter de courir après le reste ? Contente-toi de ce que le destin t'envoie !";
			link.l1 = "Je ne vais pas m'arrêter si près du but !";
			link.l1.go = "BS_F2_65";
		break;
		case "BS_F2_65":
			dialog.text = "Parfois, il le faut ! Tu vas te perdre !";
			link.l1 = "Merci de t'inquiéter pour moi, mais c'est moi qui décide de mon destin. Adieu, Max. On se reverra peut-être !";
			link.l1.go = "exit";
		break;

//Топаем в форт. В тюрьму. Комендант пропускает без вопросов. В камере – Бонс
		case "BS_F2_66":
			dialog.text = "";	//Бонс
			link.l1 = "Sir William ! Quelle rencontre ! Vous avez décidé d'échanger votre luxueuse cabine contre un logement plus modeste ?";
			link.l1.go = "BS_F2_67";
		break;
		case "BS_F2_67":
			dialog.text = "Voilà qui change. D'habitude, tout le monde me réclame des trésors de pirates, ou vient juste me jeter des ordures. Quel bon vent vous amène, capitaine ?";
			link.l1 = "Oם est Mlle Guthrie ?";
			link.l1.go = "BS_F2_68";
		break;
		case "BS_F2_68":
			dialog.text = "Ah, oui. La reine des pirates. Vous arrivez trop tard : on l'a envoyée en Angleterre hier à l'aube, sur un brick courrier. Ils veulent la pendre à Londres même.";
			link.l1 = "...";
			link.l1.go = "BS_F2_69";
		break;
		case "BS_F2_69":
			dialog.text = "Sans voix ? Je sais, parfois tout part à vau-l'eau. Et on ne comprend tout simplement plus ce qui se passe.";
			link.l1 = "Comment as-tu atterri ici ? La dernière fois, tu avais tout d'un fier chevalier de l'Empire !";
			link.l1.go = "BS_F2_70";
		break;
		case "BS_F2_70":
			dialog.text = "C'est la faute de Flint. Comme je n'avais pas de nouvelles de toi, je me suis mis à chercher de mon cכté. Et j'ai trouvé quelque chose : les mouillages du Walrus. Il est encore plus insaisissable que l'Urca. Seulement, j'ai été présomptueux et je suis parti seul. Et à un moment donné, je suis tombé sur Flint et deux autres frégates. Manifestement pas d'ici. Le combat a été chaud, puis il y a eu l'abordage. J'ai même réussi à atteindre la cabine de Flint. Dans le feu de l'action, je me suis tellement emporté que j'y suis allé tout seul, et c'était une embuscade. Je ne sais pas comment j'ai survécu. Je me suis réveillé sur le rivage.";
			link.l1 = "Et ensuite, le Scarborough t'a repêché.";
			link.l1.go = "BS_F2_71";
		break;
		case "BS_F2_71":
			dialog.text = "Exactement. Newm était très content de lui et a décidé de me mettre tous ses échecs sur le dos. Ce crétin pompeux et suffisant ! וcoute, tu veux bien me rendre un service ? Achève-le quand tu le croiseras.";
			link.l1 = "C'est déjà fait. Qu'est-ce que je vais faire de toi, Billy ? Tu dis que tu connais les mouillages de Flint ? Tu veux bien me les donner ?";
			link.l1.go = "BS_F2_72";
		break;
		case "BS_F2_72":
			dialog.text = "Et pourquoi donc ?";
			link.l1 = "J'ai tué Newm.";
			link.l1.go = "BS_F2_73";
		break;
		case "BS_F2_73":
			dialog.text = "Son propre aide de camp aurait fini par l'égorger pendant qu'il se rasait. וcoute, tu peux me sortir d'ici ? Je te livrerai Flint.";
			link.l1 = "Te faire confiance, c'est clairement une erreur. Mais je n'ai tout simplement aucune idée de ce que je dois faire ensuite. Bon. Recule.";
			link.l1.go = "exit";
		break;
//Скриптово стреляем в замок, Бонс в абордаги, месим стражу, удираем в бухту. Пиздим на берегу с Бонсом.

		case "BS_F2_74":	//Бонс
			dialog.text = "";
			link.l1 = "Flint.";
			link.l1.go = "BS_F2_75";
		break;
		case "BS_F2_75":
			dialog.text = "La lagune de Chiriquí, le rivage de Boca de la Sierpe. J'ai eu le plaisir de le rencontrer au cap Catoche, alors celui-là, on peut le rayer.";
			link.l1 = "Rejoins le navire et installe-toi dans la cale. Je déciderai plus tard de ton sort !";
			link.l1.go = "BS_F2_76";
		break;
		case "BS_F2_76":
			dialog.text = "א vos ordres, cap'taine. Tu es le portrait craché de Flint ; il ne te manque plus que son regard !";
			link.l1 = "Dans la chaloupe !";
			link.l1.go = "exit";
			AddQuestRecord("BSSevereHangover", "50");
			AddQuestUserData("BSSevereHangover", "sSex", GetSexPhrase("", "e"));
//Запись в СЖ: 'Неужели я становлюсь Флинтом? Может плюнуть на всё, по совету Макс и довольствоваться малым? Как я устал(ла)! Нужно проверить стоянки, указанные Бонсом'

			//Вешаем НЗГ от Англии.

		break;

//В Чирике – пусто. Бока де ла Сьрпе – Морж, два фрегата. Месиво, берём Моржа на абордаж – в каюте кэп ОЗГ (наёмник) без диалогов валим пидора. В сундуке СЖ Флинта, зашифрованный, 1кк денег.
//После абордажа запись в СЖ: 'Стоянка найдена, эскадра уничтожена. Флинта на борту Моржа – нет. Высаживаюсь в бухте, нужно проверить здесь всё. В судовом журнале,  какая – то околесица, явно шифр'.
//			AddQuestRecord("BSSevereHangover", "51");
//На берегу файт в следующей локе – файт.
//Запись в СЖ: 'Флинт как сквозь землю провалился. Перебили уйму наёмников. Что дальше? Клад зарыт где то тут? Что делать?'
//			AddQuestRecord("BSSevereHangover", "52");

//Выходим в бухту, на берегу Бонс
		case "BS_F2_77":	//Бонс
			dialog.text = "";
			link.l1 = "J'ai besoin de tes talents. Tu t'y connais en chiffres secrets ?";
			link.l1.go = "BS_F2_78";
		break;
		case "BS_F2_78":
			dialog.text = "Je m'y connais : dans mon service, j'ai souvent utilisé différents chiffres";
			link.l1 = "Voici le journal de bord de Flint, et voici un livre lu et relu jusqu'à l'usure. (vous lui remettez les objets) Installe-toi dans le poste d'équipage et mets-toi au déchiffrement. Dès que nous arriverons aux Bermudes, il me faudra des réponses.";
			link.l1.go = "exit";
		break;

//Выходим в море. Идём на Бермуды. Причалив, сразу ТП в резиденцию. Внутри Вейн, Бонс, ГГ
		case "BS_F2_79":	//Вейн
			dialog.text = "";
			link.l1 = "Charles, je vois que tu es déjà sur pied !";
			link.l1.go = "BS_F2_80";
		break;
		case "BS_F2_80":
			dialog.text = "J'ai connu pire. Quelles nouvelles ?";
			link.l1 = "On emmène Eleanor en Angleterre ; il y aura un procès, et elle sera très probablement pendue. Flint a disparu, mais nous avons son journal de bord, et M. Bones sera peut-être content de ce qu'il contient. Jack et Bonny forment maintenant une famille heureuse et ont renoncé à la piraterie, au moins pour un temps, jusqu'à ce qu'Anne mette au monde un petit Jack, ou une petite Jane. Et voici une partie de l'argent de Flint. Ta part.";
			link.l1.go = "BS_F2_81";
		break;
		case "BS_F2_81":
			AddmoneyToCharacter(PChar, -750000);
			dialog.text = "Pas question que je la laisse pendre, bon sang ! C'est moi qui l'étranglerai, un jour !";
			link.l1 = "Tu es décidé ? J'ai besoin d'un compagnon comme toi, Charles !";
			link.l1.go = "BS_F2_82";
		break;
		case "BS_F2_82":
			dialog.text = "On ne peut plus décidé. Dans d'autres circonstances, j'aurais peut-être accepté. Mais tu ressembles trop à Flint, maintenant ! Salue la famille Rackham de ma part. Adieu !";
			link.l1 = "";
			link.l1.go = "BS_F2_83";
		break;
//Вейн уходит

		case "BS_F2_83":	//Бонс
			dialog.text = "J'ai déchiffré le journal de bord. Regarde (il tend plusieurs pages couvertes de coordonnées). Rien d'autre.";
			link.l1 = "(vous parcourez les pages) Garde-les. Flint a gagné. Au diable tout ça !";
			link.l1.go = "BS_F2_84";
		break;
		case "BS_F2_84":
			dialog.text = "Attends. Oui, il y a beaucoup de coordonnées, énormément même, mais par élimination... Avec un navire rapide... Hé, tu m'écoutes ?";
			link.l1 = "Tais-toi, Billy, tais-toi.";
			link.l1.go = "exit";
		break;
//Релоад на улицу
//Запись в СЖ: 'Кто такой, этот Флинт? Может сам дьявол? Как я стал(ла) превращаться в него? Бескомпромиссного, жестокого, расчётливого ублюдка! Погоня за его золотом, отобрала часть меня самого(самой). Мудрая шлюха Максин, ты была права. Нужно довольствоваться, тем, что имеешь и не гоняться за чужим, иначе, рискуешь потерять и то, что имеешь'
//			AddQuestRecord("BSSevereHangover", "53");
//			AddQuestUserData("BSSevereHangover", "sSex", GetSexPhrase("", "e"));
//			CloseQuestHeader("BSSevereHangover");
//Квест уходит в архив. Макс остаётся в ПР бригадиром шлюх (бесплатный перепихон). THE END
	}
}
