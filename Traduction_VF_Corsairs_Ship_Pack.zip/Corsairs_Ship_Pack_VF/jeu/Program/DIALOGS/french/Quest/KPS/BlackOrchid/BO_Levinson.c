// Gregg: Frederik Levinson - the "Black Orchid" trilogy (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\blackorchid.c
// Nodes 1-4 - by the cave on Bermudes right after the fight, 5-27 - the talk in the
// tavern. The long retellings about the Elusive Squadron are tightened a little: in
// the original they are half-screen walls of text. The meaning is kept in full.
//
// Nodes 28-37 - chapter 5, the reckoning for the betrayal, in the rented room upstairs
// in the Bermudes tavern. The entry point (node 28) is set by the logic, the last node
// leads straight into the fight (DestinyGiftBattleWithLevinson), which Levinson does
// not survive.
//
// Gregg: a departure from the original. In Damned Destiny Levinson hid in a room by
// Jackman's residence and said "he never comes into this room". There is no such
// location in CSP, here he rents a room above the tavern - so the line about the room
// is rewritten around the tavern keeper who is paid for his silence.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";

			if (PChar.MysteriousArtefact == "3")
			{
				dialog.text = sName + ", as-tu trouvé l'argent du créancier ?";
				link.l1 = "Je cherche encore, Frederik, je cherche encore.";
				link.l1.go = "exit";
			}
		break;

		case "1":
			dialog.text = "Qu'est-ce qui t'a pris de te mêler de notre duel ?";
			link.l1 = "Je voulais t'aider, Frederik. Si je n'étais pas arrivé à temps, il t'aurait tué.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je me serais débrouillé sans ton aide avec ce salaud. Attends. Comment sais-tu mon nom ?";
			link.l1 = "Tu ne me reconnais pas ? " + GetFullName(PChar) + ". Il y a trois ans, toi, Anthony et moi avons réussi un beau coup à Porto Rico.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = sName + ", que le diable m'emporte, je ne t'avais pas du tout reconnu. Ce jour-là, je m'en souviens parfaitement. Proprement fait, très proprement.";
			link.l1 = "Pourquoi es-tu revenu ? Tu avais juré de ne plus jamais remettre les pieds dans l'archipel. Tu répétais que tu étais trop vieux pour tout ça.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "C'est une longue histoire, " + sName + ". Passons à la taverne : nous y parlerons.";
			link.l1 = "Oui, tu as raison.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToBermudesTavern");
		break;

		case "5":
			dialog.text = "Eh bien, raconte, " + sName + ". Que s'est-il passé ici après mon départ ? Comment va Anthony ? Il a fini par conquérir cette beauté de Charlestown ?";
			link.l1 = "Beaucoup de choses ont changé, Frederik. Je commencerai par ceci : Anthony est mort, trois jours après cette affaire de Porto Rico. Nous faisions route vers Niévès, et de nuit, à quelques milles de l'île, deux lourds galions espagnols nous sont tombés dessus. Le brick d'Anthony a été réduit en miettes dès la première bordée, et ma corvette a sombré en quelques minutes. Je me suis accroché à un morceau de mât, et au matin, la mer m'a rejeté sur le rivage.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Quelqu'un d'autre que toi a survécu ?";
			link.l1 = "Un marin du brick, mortellement blessé : il n'a pas tenu un quart d'heure. Trois de mes hommes s'en sont sortis. Mais tu sais ce qu'il y a de plus étrange dans toute cette affaire ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Quoi ?";
			link.l1 = "Aujourd'hui encore, j'ai l'impression que ces galions ne sont pas tombés sur nous par hasard. Pas une seule lanterne allumée : comme des fantכmes dans le noir. Ils nous attendaient.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Peu probable. Ils chassaient plutכt les navires marchands anglais chargés de cargaison vivante au large de Niévès : il y a toujours de la demande pour ça en Espagne. Ils vous ont pris pour des marchands et ils ont frappé.";
			link.l1 = "Tu penses sérieusement qu'on peut prendre une corvette et un brick pour des négriers ? Les marchands ne naviguent pas sur ce genre de navires.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Le diable seul le sait, " + sName + ". Il faisait nuit, d'après ce que tu dis : ils n'ont donc pas distingué la classe de vos coques. Et les Espagnols sont des Espagnols, ils tirent sur tout ce qui est étranger. Assez. Buvons à Anthony et aux deux équipages. C'étaient de braves gars.";
			link.l1 = "Oui. C'est dommage, mais on n'y peut rien.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Tu as au moins fait payer les Espagnols ? Tu leur as montré qui est le maître en mer ?";
			link.l1 = "Les Anglais m'ont devancé. Une escadre de Port Royal a abordé ces galions, et leurs capitaines ont été pendus publiquement sur la place de la ville.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Ha. Alors ces salauds n'ont pas survécu longtemps à Anthony. Mais à ta place, j'aurais quand même brמlé un ou deux établissements espagnols.";
			link.l1 = "Frederik, après ce naufrage, il m'a fallu trois mois pour me remettre sur pied. Pas de navire, pas de lame, pas de pistolet : rien. Je me suis donné un mal de chien pour retrouver une coque sous mes pieds. Je préfère ne pas m'en souvenir. Assez parlé de moi. Pourquoi es-tu venu aux Caraïbes ? Qu'est-ce qui n'allait pas en Europe ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "C'est bien ça : tout allait bien. Je me suis acheté une ferme en Angleterre, et je n'ai pas supporté deux mois de cette maudite tranquillité. Alors je suis revenu.";
			link.l1 = "Et je vois que tu n'as pas perdu de temps : déjà en plein combat. Qui était ce type que j'ai achevé ? Un vieil ennemi ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Un débiteur. Il me devait une somme énorme, et pour ne pas payer, il s'est enfui jusqu'ici. Je lui avais bien promis de le retrouver n'importe oם.";
			link.l1 = "Mais tu n'es pas venu ici pour le tuer ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "C'est vrai, " + sName + ". J'ai une affaire ici. Tu es avec moi ?";
			link.l1 = "Bien sמr. Je dois aider un vieil ami.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Bien, je vois que tu n'as pas perdu la main. Alors, aux affaires. As-tu déjà entendu parler d'un artefact appelé l'Orchidée noire ?";
			link.l1 = "L'Orchidée noire ? Jamais. Quel genre d'artefact ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "J'ai mal commencé. וcoute bien. Tu as sמrement entendu parler de l'Escadre insaisissable espagnole. Elle terrorisait tout l'archipel : aujourd'hui, on la signalait au large de Tortuga, demain au large de Curaçao, le surlendemain déjà sur la cכte de Cuba. La rencontrer ne voulait dire qu'une chose : la défaite. Seuls les navires sous pavillon espagnol naviguaient en paix.";
			link.l1 = "J'en ai entendu parler. Et du capitaine qui a fini par la vaincre. On l'appelle le Sauveur.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Ce n'est pas de lui qu'il s'agit pour l'instant. Beaucoup ne croient plus que l'Escadre était vraiment insaisissable : ils disent qu'on la craignait tant que chaque escadre espagnole était prise pour elle, et qu'on la disait invincible seulement parce qu'on entrait au combat déjà vaincu. Mais pendant un temps, tout cela était la pure vérité.";
			link.l1 = "Pourtant, le Sauveur l'a vaincue. Ce n'étaient donc que des racontars de gens effrayés, finalement.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Le jour oם le Sauveur a pris son premier navire de l'Escadre, l'amiral don Pedro de la Encantario avait déjà perdu l'Orchidée noire.";
			link.l1 = "Quel don Pedro, et quelle Orchidée ? Explique-toi enfin, je n'y comprends rien.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Don Pedro de la Encantario, amiral de l'Escadre insaisissable, capitaine du vaisseau amiral, le vaisseau de ligne Azor. Il est mort en attaquant une colonie pirate. Et l'Orchidée noire, c'est l'artefact même qui rendait l'Escadre insaisissable et invincible. Jusqu'à ce que l'amiral la perde. Tu me suis, maintenant ?";
			link.l1 = "Frederik, tout ça sent le délire. Une Orchidée, une escadre invincible... Tu vas bientכt me dire que les Espagnols se changeaient en squelettes la nuit et tiraient au mousquet sur un singe immortel pour s'amuser.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Que le diable t'emporte, toi et ton esprit ! L'Orchidée noire existait. Avec ton aide ou sans elle, je la trouverai.";
			link.l1 = "Bon, calme-toi. J'accepte de t'aider, mais il y a une chose : je veux des preuves. Quelqu'un d'autre que le défunt amiral a-t-il vu cette Orchidée ?";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Un homme l'a vue. Alejon Kendart, un savant, un spécialiste des cultes indiens et aztèques. Quand l'Escadre est arrivée aux Caraïbes, on l'a longtemps cherché, et une fois trouvé, on l'a emmené de force dans la cabine de l'amiral, à bord de l'Azor. Don Pedro lui a montré l'Orchidée et lui a ordonné d'en étudier les pouvoirs jusqu'au bout : il soupçonnait qu'elle recelait plus que l'invincibilité de ses navires. Et au matin, Alejon avait disparu, et l'Orchidée avec lui, malgré les gardes.";
			link.l1 = "Du délire. Il s'est simplement éclipsé quand l'Escadre longeait une île, il a nagé jusqu'au rivage et il a disparu. Mais comment en sais-tu autant sur ce Kendart ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Je lui ai parlé. Une nuit, un vieux fou en haillons est venu à ma ferme, complètement hors de lui. Je voulais le chasser, mais la servante m'en a empêché et lui a donné une potion, qui lui a rendu la raison pour quelques heures. C'est alors qu'il m'a parlé de l'Escadre, de l'Orchidée et de son propre passé.";
			link.l1 = "Et tu as cru les histoires d'un vieillard qui avait perdu la tête ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Je te l'ai dit : la potion lui avait rendu la raison. Il fallait entendre CE qu'il disait, et COMMENT. Ce n'était pas du délire, mais un récit clair et réfléchi.";
			link.l1 = "Et qu'est-il devenu ensuite ? Le vieillard, je veux dire.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Il est parti au matin. Je ne l'ai jamais revu. Et moi, j'ai filé aux Caraïbes. Comprends-moi, " + sName + ", je dois trouver... non, NOUS devons trouver l'Orchidée noire. Si nous la trouvons, nous serons les hommes les plus puissants, pas seulement des Caraïbes, mais du monde entier.";
			link.l1 = "Hum. Et par oם commencer ? Le vieillard t'a dit quelque chose, au moins ?";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Il a dit : « désormais, l'Orchidée noire est à sa véritable place ».";
			link.l1 = "Et c'est tout ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "C'est tout. Mais j'ai une sorte de plan. D'abord, il nous faut de l'argent : deux ou trois cent mille piastres. Voici ta première mission : va à Port-au-Prince, oם vivait ce débiteur que tu as tué aujourd'hui. Je sais de source sמre que peu avant sa mort, il avait mis la main sur une somme énorme. Trouve cet argent, et nous commencerons les recherches.";
			link.l1 = "Une question. Comment s'appelait le débiteur ?";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Bryan George. Et puis, " + sName + ", merci. De m'avoir sauvé la vie près de cette grotte. J'étais mal en point : je croyais que c'était la fin.";
			link.l1 = "Ce n'est rien. Bon, j'y vais. Attends-moi ici, je reviens vite.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPax");
		break;

		case "28":
			// Gregg: a guard for case "Exit" - it reads NextDiag.TempNode, and this
			// branch of the dialogue can be reached without ever opening "First time".
			dialog.text = sName + " ?!";
			link.l1 = "Frederik ?! Que diable fais-tu...";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Silence, " + sName + ", je t'en supplie ! Si Jackman entend...";
			link.l1 = "...(à voix basse)... Que diable fais-tu ici, juste sous le nez de Jackman ?";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Je me cache. Il ne monte jamais ici, et le tavernier prend mon argent pour se taire : alors je reste là. Que le diable m'emporte, " + sName + ", comme je suis content de te voir. Tu aideras un vieil ami à sortir d'ici ?";
			link.l1 = "Au contraire. Je suis venu te faire payer. Pour ta trahison.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Une trahison ? Quelle trahison ? Je ne comprends pas de quoi tu parles.";
			link.l1 = "Tu comprends parfaitement, Frederik. Ne nie pas, on m'a tout raconté : après l'affaire de Porto Rico, tu n'étais pas content de ta part du butin, tu es passé du cכté des Espagnols et tu nous as trahis, Anthony et moi.";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "...(après un long silence)... Imagine ce que j'ai ressenti, " + sName + ". Nous avons préparé ce coup pendant deux mois, nous y avons risqué notre peau, nous avons failli tomber sous les mousquets espagnols. Et voilà que cet Anthony arrive, et que tu lui donnes une part, alors qu'il n'avait rien fait, absolument rien. Il nous avait juste un peu aidés à nous enfuir.";
			link.l1 = "...(doucement)... Il nous a sauvés. Je n'ai pas besoin de te le dire : tu as vu toi-même qu'avec ces corvettes, nous étions à deux doigts de la mort. Sans Anthony...";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Son aide ne valait pas qu'on lui donne un tiers de notre butin. Elle ne le valait pas.";
			link.l1 = "Pourtant, tu n'as pas exigé la moitié : tu as accepté un tiers. Comment pouvais-je savoir que tu n'étais pas content du partage ?";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Et pourquoi aurais-je dמ me contenter d'un tiers, " + sName + " ? Même cet Anthony a vu mon mécontentement quand tu lui as remis sa part. Et toi, tu n'as rien remarqué.";
			link.l1 = "Je ne suis pas obligé de remarquer quoi que ce soit. Tu connais la loi. Si tu n'es pas content du partage, dis-le à voix haute ou mets-le par écrit.";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Et qu'est-ce que j'aurais obtenu en le disant ? Rien. Anthony en serait venu aux mains plutכt que de renoncer à l'argent. Et toi ? Tu te serais mis à me faire la morale et à m'expliquer que j'avais tort.";
			link.l1 = "Ce n'est pas vrai, j'aurais...";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "C'est vrai, " + sName + ", et tu le sais toi-même ! Je n'y aurais rien gagné de toute façon.";
			link.l1 = "Tu n'as même pas essayé ! Je vois maintenant qu'il t'était plus facile de trahir un vieil ami que de demander ta part.";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "C'est possible. Mais tu sais, " + sName + ", je ne regrette pas du tout ce que j'ai fait.";
			link.l1 = "Tu vas le regretter maintenant ! Ordure !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftBattleWithLevinson");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
