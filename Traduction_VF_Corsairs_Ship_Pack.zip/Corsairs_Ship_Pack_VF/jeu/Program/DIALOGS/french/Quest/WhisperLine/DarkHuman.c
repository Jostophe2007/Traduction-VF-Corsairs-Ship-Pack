void ProcessDialogEvent()
{
	ref locLoad = &locations[reload_location_index];
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;
	int i;
	bool hungry = true;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":

			//dialog.text = "Error";
			link.l1 = "...";
			link.l1.go = "Exit";
			npchar.quest.meeting = "1";

			if (npchar.id == "CrazyScientist")
			{
				dialog.text = "Allez, attends !";
				link.l1.go = "CS";
			}
			NextDiag.TempNode = "First time";
		break;

		case "DH_Villemstad_merc":
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "ContraInterruptWaiting");
			dialog.Text = "Je ne pense pas qu'il vaille la peine de perdre du temps.";
			Link.l1 = "Je suis du même avis.";
			Link.l1.go = "DH_Villemstad_merc_exit_to_bank";
		break;

		case "DH_Villemstad_merc_exit_to_bank":
			DialogExit();
			sld = CharacterFromID("Villemstad_usurer");
			//LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.filename = "Quest\WhisperLine\DarkHuman.c";
			sld.dialog.currentnode = "DH_Villemstad_usurer";

			sld = CharacterFromID("Villemstad_shipyarder");
			//LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.filename = "Quest\WhisperLine\DarkHuman.c";
			sld.dialog.currentnode = "DH_Villemstad_shipyarder"

			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
		break;

		case "DH_Villemstad_shipyarder":
			dialog.Text = "Bonjour, mein Herr.";
			Link.l1 = "Bonjour. Je ne vais pas tricher : je m'intéresse aux navires, et si possible pas chers.";
			Link.l1.go = "DH_Villemstad_shipyarder_1";
		break;
		case "DH_Villemstad_shipyarder_1":
			dialog.Text = "C'est un plaisir de voir quelqu'un à la bourse modeste, mais qui sait ce qu'il veut. J'ai une excellente offre pour vous.";
			Link.l1 = "Et de quoi s'agit-il ?";
			Link.l1.go = "DH_Villemstad_shipyarder_2";
		break;
		case "DH_Villemstad_shipyarder_2":
			dialog.Text = "Une jonque, l'Impératrice. On en trouve parfois dans nos eaux. וtonnamment, ce sont mes compatriotes qui ont réussi à convoyer tout un groupe de ces navires de l'Extrême-Orient jusqu'à la mer des Caraïbes.";
			Link.l1 = "Les miracles existent, mais oם est le piège ?";
			Link.l1.go = "DH_Villemstad_shipyarder_3";
		break;
		case "DH_Villemstad_shipyarder_3":
			dialog.Text = "Voyez-vous, c'est une confiscation : l'ancien propriétaire a été pris à... comment dire, des affaires malhonnêtes. Et il a cru, dans sa frayeur, que tirer au canon sur un navire de patrouille était une bonne idée. Bien sמr, on a vite calmé son ardeur belliqueuse. Peu de temps après, une cravate de chanvre l'a aidé à danser une gigue endiablée, c'était un spectacle intéressant. Mais là n'est pas la question.";
			Link.l1 = "Oui, revenons à nos affaires.";
			Link.l1.go = "DH_Villemstad_shipyarder_4";
		break;
		case "DH_Villemstad_shipyarder_4":
			dialog.Text = "Donc, on a calmé son ardeur à coups de canon, ce qui a laissé certaines traces sur sa jonque. En plus, j'ai été obligé de la racheter, de plein gré et contre toutes les règles. Et maintenant, elle me pèse comme un poids mort.";
			Link.l1 = "Son état ?";
			Link.l1.go = "DH_Villemstad_shipyarder_5";
		break;
		case "DH_Villemstad_shipyarder_5":
			dialog.Text = "Je vous le dis tout de suite : pas le meilleur, mais sous la ligne de flottaison, j'ai colmaté toutes les brèches. Alors, vous ne coulerez pas, n'ayez crainte.";
			Link.l1 = "Le prix ?";
			Link.l1.go = "DH_Villemstad_shipyarder_6";
		break;
		case "DH_Villemstad_shipyarder_6":
			dialog.Text = "25 000, et elle est à vous. Honnêtement, personne d'autre ne veut la racheter, alors je peux bien patienter quelques semaines.";
			NextDiag.TempNode = "DH_Villemstad_shipyarder_wait_money";
			Link.l1 = "Bon, je la prendrai dès que j'aurai l'argent.";
			Link.l1.go = "exit";
			if(sti(pchar.money) >= 25000 && CheckAttribute(pchar, "DH_mercLeft"))
			{
				Link.l1 = "Je la prends.";
				Link.l1.go = "DH_Villemstad_shipyarder_getship";
			}
		break;
		case "DH_Villemstad_shipyarder_wait_money":
			dialog.Text = "Tu as apporté l'argent ?";
			Link.l1 = "Pas encore, il me reste quelques affaires à régler.";
			Link.l1.go = "exit";
			if(sti(pchar.money) >= 25000 && CheckAttribute(pchar, "DH_mercLeft"))
			{
				Link.l1 = "Oui.";
				Link.l1.go = "DH_Villemstad_shipyarder_getship";
			}
		break;
		case "DH_Villemstad_shipyarder_getship":
			PChar.quest.DHRaceAgainstTime.win_condition.l1 = "location";
			PChar.quest.DHRaceAgainstTime.win_condition.l1.location = "LaVega_town";
			PChar.quest.DHRaceAgainstTime.function = "DHRaceAgainstTime";
			SetQuestHeader("DHRaceAgainstTime");
			AddQuestRecord("DHRaceAgainstTime", "1");

			AddMoneyToCharacter(pchar, -25000);
			DeleteAttribute(pchar, "DH_mercLeft");
			pchar.location.from_sea = "Villemstad_town"
			setWDMPointXZ(pchar.location.from_sea);  // коорд на карте
			pchar.Ship.Type = GenerateShipExt(SHIP_SCHOONER_B, 0, pchar);
			ref shTo = &RealShips[sti(Pchar.Ship.Type)];
			shTo.SpeedRate        = 17.0;
			shTo.HP = 1900;
			shTo.WindAgainstSpeed = 7.35;
			shTo.TurnRate = 23.0;
			shTo.MaxCrew = 120;
			shTo.MastMultiplier = 1.45;
			shTo.Capacity = 1300;
			SetBaseShipData(pchar);
			pchar.Ship.Name = RandPhraseSimple(RandPhraseSimple(RandPhraseSimple(RandPhraseSimple(RandPhraseSimple(RandPhraseSimple(RandPhraseSimple(RandPhraseSimple("Sanglier Rapide", "Tigre de Combat"), "Transporteur"), "Antilope"), "Extra"), "וclair"), "Dauphin"), "Mystérieux"), "Terrible");
			SetCrewQuantityFull(pchar);
			ChangeCrewExp(pchar, "Sailors", rand(30)+20);
			ChangeCrewExp(pchar, "Cannoners", rand(30)+20);
			ChangeCrewExp(pchar, "Soldiers", rand(30)+20);
			SetCharacterGoods(pchar, GOOD_SAILCLOTH, 20 + rand(50));
			SetCharacterGoods(pchar, GOOD_PLANKS, 20 + rand(50));
			SetCharacterGoods(pchar, GOOD_RUM, 50 + rand(100));
			// коцаем корабль
			pchar.ship.HP = sti(pchar.ship.HP) - makeint(sti(pchar.ship.HP)*0.05) * (MOD_SKILL_ENEMY_RATE*3);
			SetCrewQuantity(pchar, GetMinCrewQuantity(pchar));

			InterfaceStates.DisFastTravel = false;
			bDisableLandEncounters = false;

			dialog.Text = "Bien, prenez-la. Il reste même quelques provisions dans la cale du navire, je n'avais pas vraiment envie d'y aller.";
			Link.l1 = "Merci. Au revoir.";
			Link.l1.go = "exit";
			npchar.Dialog.Filename = "Common_Shipyard.c";
			NextDiag.TempNode = "first time";
		break;

		case "DH_Villemstad_usurer":
			dialog.Text = "Vous voilà enfin, je commençais à m'inquiéter de savoir oם vous étiez passé. Vous savez, les temps sont troubles en ce moment, vous avez entendu les dernières rumeurs ?";
			Link.l1 = "Les rumeurs, c'est bien, mais pour l'instant, mon compagnon et moi, nous nous intéressons aux affaires.";
			Link.l1.go = "DH_Villemstad_usurer_0_1";
		break;
		case "DH_Villemstad_usurer_0_1":
			dialog.Text = "Oui. Les affaires. Vous voulez conclure le contrat avec ce monsieur ?";
			Link.l1 = "J'aimerais bien.";
			Link.l1.go = "DH_Villemstad_usurer_0_2";
		break;
		case "DH_Villemstad_usurer_0_2":
			dialog.Text = "Comme vous voudrez, " + GetFullName(characterFromId("DH_mercenary"))+". Félicitations, votre dette envers la banque est réglée.";
			Link.l1 = "...";
			Link.l1.go = "DH_Villemstad_usurer_0_3";
		break;
		case "DH_Villemstad_usurer_0_3":
			DialogExit();
			sld = CharacterFromID("DH_mercenary");
			LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.currentnode = "DH_Villemstad_usurer_0_4";
		break;
		case "DH_Villemstad_usurer_0_4":
			dialog.Text = "Eh bien, parfois, l'ami, je ne sais pas pour vous, mais moi, je vais me soמler.";
			Link.l1 = "Les affaires n'attendent pas.";
			Link.l1.go = "DH_Villemstad_usurer_0_5";
		break;
		case "DH_Villemstad_usurer_0_5":
			dialog.Text = "Comme vous voudrez.";
			npchar.lifeday = 0;
			Link.l1 = "...";
			Link.l1.go = "DH_Villemstad_usurer_0_6";
		break;
		case "DH_Villemstad_usurer_0_6":
			DialogExit();
			pchar.DH_mercLeft = true;
			LocatorReloadEnterDisable("SantaCatalina_town", "reload5_back", false);
			LocatorReloadEnterDisable("Villemstad_town", "gate_back", false);
			LocatorReloadEnterDisable("Villemstad_town", "reload4_back", false);
			LocatorReloadEnterDisable("SantaCatalina_exittown", "reload1_back", false);
			LocatorReloadEnterDisable("SantaCatalina_exittown", "reload2_back", false);

			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "", "", "", "", 5);
			sld = CharacterFromID("Villemstad_usurer");
			Lai_SetActorTypeNoGroup(sld);
			LAi_ActorDialog(sld, pchar, "", 1.0, 0);
			sld.dialog.currentnode = "DH_Villemstad_usurer_0_7";
		break;

		case "DH_Villemstad_usurer_0_7":
			dialog.Text = "Autre chose ?";
			Link.l1 = "J'aimerais retirer mon dépכt.";
			Link.l1.go = "DH_Villemstad_usurer_1";
		break;
		case "DH_Villemstad_usurer_1":
			dialog.Text = "Votre dépכt... Vous savez, il y a une petite difficulté...";
			Link.l1 = "Quelle difficulté peut-il y avoir à me rendre mon argent ?";
			Link.l1.go = "DH_Villemstad_usurer_2";
		break;
		case "DH_Villemstad_usurer_2":
			dialog.Text = "Voyez-vous... le commerce : parfois, les affaires réussissent, parfois non. Parfois, on a un besoin urgent d'argent, parfois non.";
			Link.l1 = "Mais quel rapport entre vos problèmes et mon dépכt ?";
			Link.l1.go = "DH_Villemstad_usurer_3";
		break;
		case "DH_Villemstad_usurer_3":
			dialog.Text = "Seulement que je ne pourrai pas vous rendre l'argent avant un mois : je n'ai plus un sou. Mais qu'est-ce qu'un mois de répit entre vieux amis ?";
			Link.l1 = "Rien, entre vieux amis. Cependant, ma poche est maintenant aussi vide que vos coffres, et il faut bien que je mange pendant ce mois !";
			Link.l1.go = "DH_Villemstad_usurer_4";
		break;
		case "DH_Villemstad_usurer_4":
			dialog.Text = "Vous savez, j'ai un objet pour connaisseurs, je pense qu'il couvrira un tiers de la valeur de votre dépכt.";
			Link.l1 = "Et de quoi s'agit-il ?";
			Link.l1.go = "DH_Villemstad_usurer_6";
		break;
		case "DH_Villemstad_usurer_6":
			dialog.Text = "Le crâne de cristal. Tenez, regardez.";
			Link.l1 = "Je ne sais pas...";
			Link.l1.go = "DH_Villemstad_usurer_7";
		break;
		case "DH_Villemstad_usurer_7":
			dialog.Text = "C'est dommage de m'en séparer, mais que ne ferait-on pas pour un ami...";
			Link.l1 = "Bon, compris, je le compte pour 30 % et un mois de délai pour le reste.";
			Link.l1.go = "DH_Villemstad_usurer_8";
		break;
		case "DH_Villemstad_usurer_8":
			LAi_SetOwnerTypeNoGroup(npchar);

			DeleteAttribute(pchar, "BlockOstin");

			Log_Info("Vous avez reçu le crâne de cristal.");
			PlaySound("interface\important_item.wav");
			TakeNItems(pchar, "sculMa"+(drand(2)+1), 1);
			dialog.Text = "Parfait, c'est un plaisir de faire affaire avec vous.";
			Link.l1 = "Je reviendrai.";
			Link.l1.go = "exit";
			SaveCurrentQuestDateParam("questTemp.DH_Villemstad_money");
			NextDiag.TempNode = "DH_Villemstad_usurer_get_money";
			AddQuestRecord("DarkHumanQuestline", "6");
		break;
		case "DH_Villemstad_usurer_get_money":
			dialog.Text = "Désolé, mais je n'ai pas encore la somme nécessaire.";
			Link.l1 = "Je reviendrai.";
			Link.l1.go = "exit";
			NextDiag.TempNode = "DH_Villemstad_usurer_get_money";
			if (GetQuestPastDayParam("questTemp.DH_Villemstad_money") >= 28)
			{
				AddMoneyToCharacter(pchar, 35000);
				dialog.Text = "Je vous attendais. Je suis maintenant prêt à vous rendre votre dépכt. Tenez. J'espère que vous voudrez encore recourir à mes services.";
				Link.l1 = "Eh bien, c'est parfait. Quant au dernier point, je n'y compterais pas.";
				Link.l1.go = "exit";
				NextDiag.TempNode = "First time";
				npchar.Dialog.Filename = "Usurer_dialog.c";
			}

		break;

		case "DH_mercenary_SK_vavern":
			dialog.Text = "C'est ici que nos chemins devaient se séparer.";
			Link.l1 = "Oui, vous avez rempli vos obligations dans la lettre et dans l'esprit de notre accord. Vous pourrez toucher la seconde partie de votre rémunération à Curaçao.";
			Link.l1.go = "DH_mercenary_SK_vavern_1";
		break;
		case "DH_mercenary_SK_vavern_1":
			dialog.Text = "Oui, oui, oui. Je sais, mais vu les circonstances, je préférerais vous accompagner jusqu'à la banque de Curaçao.";
			Link.l1 = "Et les autres ?";
			Link.l1.go = "DH_mercenary_SK_vavern_2";
		break;
		case "DH_mercenary_SK_vavern_2":
			dialog.Text = "Les autres partiront séparément : un groupe trop nombreux attirerait trop l'attention.";
			Link.l1 = "Bien.";
			Link.l1.go = "DH_mercenary_SK_vavern_exit";
		break;
		case "DH_mercenary_SK_vavern_exit":
			DialogExit();
			sld = CharacterFromID("SantaCatalina_Smuggler");
			//LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.filename = "Quest\WhisperLine\DarkHuman.c";
			sld.dialog.currentnode = "DH_SK_smuggler";

			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
		break;

		case "DH_SK_smuggler":
			dialog.Text = "Encore vous ? Que puis-je faire pour vous ?";
			Link.l1 = "Ce monsieur et moi devons nous rendre à Curaçao.";
			Link.l1.go = "DH_SK_smuggler_1";
		break;
		case "DH_SK_smuggler_1":
			LocatorReloadEnterDisable("SantaCatalina_town", "gate_back", false);
			dialog.Text = "Curaçao, c'est possible. Deux personnes, ce n'est pas un problème non plus. L'argent sur le tonneau.";
			Link.l1 = "Tenez.";
			Link.l1.go = "DH_SK_smuggler_2";
		break;
		case "DH_SK_smuggler_2":
			AddMoneyToCharacter(pchar, -sti(pchar.money));
			pchar.money = 10;
			//Log_Info("You gave away all the money you had with you.");
			PlaySound("interface\important_item.wav");
			dialog.Text = "Bon, ça suffit, on lève l'ancre.";
			Link.l1 = "...";
			Link.l1.go = "DH_SK_smuggler_exit";
		break;
		case "DH_SK_smuggler_exit":
			DialogExit();
			NextDiag.TempNode = "First time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			npchar.dialog.filename = "Smuggler_Agent_dialog.c";
			DoQuestFunctionDelay("DarkHuman_Villemstad", 1.0);
			WaitDate("",0,0,7,2,25);
		break;

		case "DH_mercenary_SK_gate":
			dialog.Text = "Nous y voilà.";
			Link.l1 = "Bon sang, trente jours entiers ! Je ne pensais pas que ce serait si long !";
			Link.l1.go = "DH_mercenary_SK_gate_1";
			PChar.quest.DHLockSK.win_condition.l1 = "location";
			PChar.quest.DHLockSK.win_condition.l1.location = "SantaCatalina_town";
			PChar.quest.DHLockSK.function = "DHLockSK";
		break;
		case "DH_mercenary_SK_gate_1":
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			chrDisableReloadToLocation = false;
			pchar.BlockOstin = true;
			dialog.Text = "Je pense que vous comprenez maintenant pourquoi nous demandions un tel prix.";
			Link.l1 = "Oui, je crois que oui.";
			Link.l1.go = "exit";
		break;

		case "DH_mercenary_Amatike_return":
			dialog.Text = "Qu'est-ce qui se passe ici, bon sang ?! ";
			Link.l1 = "Le navire est parti ? Nous sommes en retard ?";
			Link.l1.go = "DH_mercenary_Amatike_return_1";
		break;
		case "DH_mercenary_Amatike_return_1":
			dialog.Text = "Hé, petit ! Explique-moi ce qui se passe...";
			Link.l1 = "...";
			Link.l1.go = "DH_mercenary_Amatike_return_2_sailor";
		break;
		case "DH_mercenary_Amatike_return_2_sailor":
			DialogExit();
			sld = CharacterFromID("DH_sailor");
			LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.filename = "Quest\WhisperLine\DarkHuman.c";
			sld.dialog.currentnode = "DH_mercenary_Amatike_return_3_sailor";
		break;
		case "DH_mercenary_Amatike_return_3_sailor":
			dialog.Text = "Vous... Vous êtes revenus, Dieu merci !";
			Link.l1 = "Maintenant, nous allons savoir ce qui se passe ici ! Oם est passé le navire ? Les sept jours ne sont pas encore écoulés !";
			Link.l1.go = "DH_mercenary_Amatike_return_4_sailor";
		break;
		case "DH_mercenary_Amatike_return_4_sailor":
			dialog.Text = "Des Espagnols, sur une corvette. Dès que vous avez daigné quitter le rivage, une corvette espagnole est sortie de derrière le cap. Le capitaine a donné l'ordre de s'éloigner, mais cette canaille a réussi à nous rattraper à la sortie de la baie. ";
			Link.l1 = "Ensuite...";
			Link.l1.go = "DH_mercenary_Amatike_return_5_sailor";
		break;
		case "DH_mercenary_Amatike_return_5_sailor":
			dialog.Text = "Doucement, monsieur, nous sommes tous dans le même bateau, ici.";
			Link.l1 = "Ne traîne pas, petit.";
			Link.l1.go = "DH_mercenary_Amatike_return_6_sailor";
		break;
		case "DH_mercenary_Amatike_return_6_sailor":
			dialog.Text = "La corvette a tiré une bordée sur le navire, j'ai été projeté du mât et je suis tombé par miracle entre les rochers.";
			Link.l1 = "Et le navire ?";
			Link.l1.go = "DH_mercenary_Amatike_return_7_sailor";
		break;
		case "DH_mercenary_Amatike_return_7_sailor":
			dialog.Text = "Même si notre navire n'est pas le plus fort, il est agile ; en plus, la coque de la corvette était endommagée, et le capitaine a pu gagner le large.";
			Link.l1 = "Et toi, alors ?";
			Link.l1.go = "DH_mercenary_Amatike_return_8_sailor";
		break;
		case "DH_mercenary_Amatike_return_8_sailor":
			dialog.Text = "Moi ? Ils ne m'ont pas remarqué, d'autant que je m'étais caché près de la falaise. J'ai tout vu de mes propres yeux. Quand la corvette a été assez loin, j'ai gagné le rivage et je vous ai attendus, je savais que vous deviez revenir.";
			Link.l1 = "Admettons.";
			Link.l1.go = "DH_mercenary_Amatike_return_9";
		break;
		case "DH_mercenary_Amatike_return_9":
			DialogExit();
			sld = CharacterFromID("DH_mercenary");
			LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.currentnode = "DH_mercenary_Amatike_return_10";
		break;
		case "DH_mercenary_Amatike_return_10":
			dialog.Text = "Et qu'est-ce qu'on fait de lui ?";
			Link.l1 = "On l'abat.";
			Link.l1.go = "DH_mercenary_Amatike_return_kill";
			Link.l2 = "Je ne pense pas qu'il nous retardera, et des bras en plus ne feront pas de mal en chemin.";
			Link.l2.go = "DH_mercenary_Amatike_return_10_1";
		break;
		case "DH_mercenary_Amatike_return_10_1":
			ChangeCharacterReputation(PChar, 30);
			dialog.Text = "D'accord.";
			Link.l1 = "...";
			Link.l1.go = "DH_mercenary_Amatike_return_11";
		break;
		case "DH_mercenary_Amatike_return_kill":
			DialogExit();
			sld = CharacterFromID("DH_sailor");
			LAi_ActorDialog(sld, pchar, "", -1.0, 0);
			sld.dialog.currentnode = "DH_mercenary_Amatike_return_kill_1";
			sld = CharacterFromID("DH_mercenary");
			sld.dialog.currentnode = "DH_mercenary_Amatike_return_11";
		break;
		case "DH_mercenary_Amatike_return_11":
			dialog.Text = "Qu'est-ce qu'on fait ensuite ?";
			Link.l1 = "On rejoint la ville par nos propres moyens.";
			Link.l1.go = "DH_mercenary_Amatike_return_12";

			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				LAi_SetActorTypeNoGroup(sld);
				LAi_ActorFollowEverywhere(sld, "", -1);
				sld = CharacterFromID("DH_merc_blade" + i);
				LAi_SetActorTypeNoGroup(sld);
				LAi_ActorFollowEverywhere(sld, "", -1);
			}
		break;
		case "DH_mercenary_Amatike_return_kill_1":
			ChangeCharacterReputation(PChar, -30);
			dialog.Text = "Je vous en prie, ne me touchez pas !";
			Link.l1 = "Ne te débats pas comme ça, et tu ne sentiras rien.";
			Link.l1.go = "exit_fight_sailor";
		break;
		case "DH_mercenary_Amatike_return_12":
			dialog.Text = "Santa Catalina n'est pas loin.";
			Link.l1 = "Et la corvette espagnole peut revenir à tout moment, sans parler d'une équipe de guetteurs.";
			Link.l1.go = "DH_mercenary_Amatike_return_13";
		break;
		case "DH_mercenary_Amatike_return_13":
			dialog.Text = "Compris.";
			Link.l1 = "Heureusement, nous avions prévu ce cas de figure.";
			Link.l1.go = "DH_mercenary_Amatike_return_14";
		break;
		case "DH_mercenary_Amatike_return_14":
			dialog.Text = "Vous avez raison. En route ?";
			Link.l1 = "Allons-y.";
			Link.l1.go = "DH_mercenary_Amatike_return_15_exit";
		break;
		case "DH_mercenary_Amatike_return_15_exit":
			DialogExit();
			LAi_ActorFollowEverywhere(npchar, "", -1);

			LAi_Fade("", "");
			WaitDate("",0,1,3,17,25);
			RecalculateJumpTable();
			RefreshWeather();
			RefreshLandTime();
			DoQuestFunctionDelay("DarkHuman_SK", 1.5);
		break;

		case "DH_mercenary_temple_afterstash":
			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				LAi_SetImmortal(sld, true);
				sld = CharacterFromID("DH_merc_blade" + i);
				LAi_SetImmortal(sld, true);
			}
			dialog.Text = "Des problèmes ? ";
			Link.l1 = "Rien qu'on ne puisse régler... Au bout du compte.";
			Link.l1.go = "DH_mercenary_temple_afterstash_1";
		break;
		case "DH_mercenary_temple_afterstash_1":
			dialog.Text = "Quoi ?";
			Link.l1 = "Tout le monde est prêt à partir, il n'y a pas de temps à perdre. Le navire nous attend toujours, et il y a un autre chemin... Il prendrait trop de temps.";
			Link.l1.go = "DH_mercenary_temple_afterstash_2";
		break;
		case "DH_mercenary_temple_afterstash_2":
			dialog.Text = "Oui, mais pourquoi cette hâte ?";
			Link.l1 = "Le temps presse, et un autre groupe d'Indiens peut descendre à tout moment.";
			Link.l1.go = "DH_mercenary_temple_afterstash_3";
		break;
		case "DH_mercenary_temple_afterstash_3":
			dialog.Text = "En effet... Vous avez entendu, les gars, debout, on y va !";
			Link.l1 = "...";
			Link.l1.go = "DH_mercenary_temple_afterstash_exit";
		break;
		case "DH_mercenary_temple_afterstash_exit":
			DialogExit();
			LAi_ActorFollowEverywhere(npchar, "", -1);
			chrDisableReloadToLocation = false;
			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				LAi_SetActorTypeNoGroup(sld);
				LAi_ActorFollowEverywhere(sld, "", -1);
				sld = CharacterFromID("DH_merc_blade" + i);
				LAi_SetActorTypeNoGroup(sld);
				LAi_ActorFollowEverywhere(sld, "", -1);
			}

			LocatorReloadEnterDisable("Temple", "reload1_back", false);
			LocatorReloadEnterDisable("Temple", "reload2", true);
			DeleteAttribute(pchar, "CantTakeItems");
		break;

		case "Dark_Incquisitor":
			dialog.Text = "Dieu merci, vous êtes sau... C'est lui, tuez-le !";
			Link.l1 = "...";
			Link.l1.go = "Dark_Incquisitor_fight";
		break;
		case "Dark_Incquisitor_fight":
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorTypeNoGroup(npchar);
			sld = CharacterFromID("Dark_Incquisitor1");
			LAi_SetWarriorTypeNoGroup(sld);
			sld = CharacterFromID("Dark_Incquisitor2");
			LAi_SetWarriorTypeNoGroup(sld);
			AddQuestRecord("DarkHumanQuestline", "2");
			PChar.quest.DarkHuman_Temple_Stash.win_condition.l1 = "locator";
			PChar.quest.DarkHuman_Temple_Stash.win_condition.l1.location = "Temple_Inside";
			PChar.quest.DarkHuman_Temple_Stash.win_condition.l1.locator_group = "item";
			PChar.quest.DarkHuman_Temple_Stash.win_condition.l1.locator = "item1";
			PChar.quest.DarkHuman_Temple_Stash.function = "DarkHuman_Temple_Stash";
		break;

		case "DH_Ambush":
			dialog.Text = "Alors, nous nous retrouvons, mon ami. On nous a dit de te prendre vivant, si possible. Alors, lâche ton arme !";
			Link.l1 = "En voilà une autre, dis-moi plutכt qui vous a engagés.";
			Link.l1.go = "DH_Ambush_1";
		break;
		case "DH_Ambush_1":
			dialog.Text = "J'ai dit : lâche ton arme !";
			Link.l1 = "Je vois que le dialogue ne prend pas... Bon, faisons autrement.";
			Link.l1.go = "DH_Ambush_fight";
		break;
		case "DH_Ambush_fight":
			LAi_SetWarriorTypeNoGroup(npchar);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "DH_mercenary_temple_afterfight":
			dialog.Text = "On les a bien couchés, tous. Une racaille au cul rouge, que peuvent-ils contre une bonne salve de mousquets... Hé hé hé.";
			Link.l1 = "La voie est libre maintenant.";
			Link.l1.go = "DH_mercenary_temple_afterfight_1";
		break;
		case "DH_mercenary_temple_afterfight_1":
			dialog.Text = "Oui, nous allons rester ici. On ne sait jamais qui pourrait venir nous chercher. Et vous, allez faire ce pour quoi vous êtes venus...";
			Link.l1 = "On dirait qu'il y a quelqu'un dans la pyramide.";
			Link.l1.go = "DH_mercenary_temple_afterfight_2";
		break;
		case "DH_mercenary_temple_afterfight_2":
			dialog.Text = "Et ils vous en seront infiniment...";
			Link.l1 = "... à nous...";
			Link.l1.go = "DH_mercenary_temple_afterfight_3";
		break;
		case "DH_mercenary_temple_afterfight_3":
			chrDisableReloadToLocation = false;
			dialog.Text = " reconnaissants de les avoir sauvés.";
			Link.l1 = "...";
			Link.l1.go = "exit";
		break;

		case "DH_mercenary_temple":
			dialog.Text = "Il y a des Indiens là-bas, apparemment mal en point.";
			Link.l1 = "Combien avez-vous ?";
			Link.l1.go = "DH_mercenary_temple_2";
		break;
		case "DH_mercenary_temple_2":
			dialog.Text = "Huit, plus une dizaine de cadavres. Nous sommes tout à fait capables de les culbuter si nous agissons avec décision.";
			Link.l1 = "Un coup décisif ?";
			Link.l1.go = "DH_mercenary_temple_3";
		break;
		case "DH_mercenary_temple_3":
			dialog.Text = "Exactement.";
			Link.l1 = "En avant, à l'attaque !";
			Link.l1.go = "DH_mercenary_temple_exit";
		break;
		case "DH_mercenary_temple_exit":
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			SetCharacterTask_FollowCharacter(npchar, PChar);
			LAi_warrior_DialogEnable(npchar, false);
			chrDisableReloadToLocation = true;
			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				SetCharacterTask_FollowCharacter(sld, PChar);
				sld = CharacterFromID("DH_merc_blade" + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				SetCharacterTask_FollowCharacter(sld, PChar);
			}

			for (i = 0; i < sti(pchar.maxIndians) * 2; i++)
			{
				sld = CharacterFromID("DHindian" + i);
				LAi_SetWarriorTypeNoGroup(sld);
			}
			LAi_group_SetRelation("Jungle_indians", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("Jungle_indians", LAI_GROUP_PLAYER, true);
		break;

		case "DH_mercenary_shore":
			dialog.Text = "Bonjour, chef, nous sommes là.";
			Link.l1 = "Bonjour. La prochaine cible est-elle connue ?";
			Link.l1.go = "DH_mercenary_shore_1";
		break;
		case "DH_mercenary_shore_1":
			dialog.Text = "La pyramide...";
			Link.l1 = "Oui, la pyramide. Vous connaissez cette région mieux que moi. Que recommandez-vous ?";
			Link.l1.go = "DH_mercenary_shore_2";
		break;
		case "DH_mercenary_shore_2":
			dialog.Text = "Premièrement, ne pas perdre de temps ; deuxièmement, garder les yeux ouverts et les armes prêtes.";
			Link.l1 = "Les Indiens ?";
			Link.l1.go = "DH_mercenary_shore_3";
		break;
		case "DH_mercenary_shore_3":
			dialog.Text = "Oui, ces maudits sauvages. Cependant, nous avons une bonne puissance de feu. (il désigne d'un signe de tête les gars à cכté)";
			Link.l1 = "Alors, ne perdons vraiment pas de temps.";
			Link.l1.go = "DH_mercenary_shore_exit";
		break;
		case "DH_mercenary_shore_exit":
			DialogExit();
			LAi_ActorFollowEverywhere(npchar, "", -1);
			chrDisableReloadToLocation = false;
			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				LAi_ActorFollowEverywhere(sld, "", -1);
				sld = CharacterFromID("DH_merc_blade" + i);
				LAi_ActorFollowEverywhere(sld, "", -1);
			}
			PChar.quest.DarkHuman_Temple.win_condition.l1 = "location";
			PChar.quest.DarkHuman_Temple.win_condition.l1.location = "Temple";
			PChar.quest.DarkHuman_Temple.function = "DarkHuman_Temple";

			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		case "PGG_transporter":
			//LAi_ActorSetSitMode(pchar);
			dialog.Text = "Nous sommes arrivés, vos hommes sont prêts à débarquer.";
			Link.l1 = "Excellent, vos obligations contractuelles sont pratiquement remplies.";
			Link.l1.go = "PGG_transporter_1";
		break;
		case "PGG_transporter_1":
			dialog.Text = "La chaloupe attend.";
			Link.l1 = "Parfait, délai d'attente ?";
			Link.l1.go = "PGG_transporter_2";
		break;
		case "PGG_transporter_2":
			dialog.Text = "Une semaine à compter d'aujourd'hui.";
			Link.l1 = "C'est bien ça, allons-y.";
			Link.l1.go = "PGG_transporter_exit";
		break;
		case "PGG_transporter_exit":
			DialogExit();
			NextDiag.CurrentNode = "Second Time";
			if (npchar.sex != "woman")	npchar.Dialog.FileName = "PGG_dialog.c";
			else	npchar.Dialog.FileName = "PGG_dialog.c";
			//PGG_ChangeRelation2MainCharacter(npchar, 25);
			DoQuestFunctionDelay("DarkHuman_Amatike", 1.0);
			//LAi_SetWarriorType(npchar);
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_fight_sailor":
			pchar.quest.DH_mercenary.win_condition.l1 = "NPC_Death";
			pchar.quest.DH_mercenary.win_condition.l1.character ="DH_sailor";
			PChar.quest.DH_mercenary.function = "SpeakAfterKill";
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			LAi_SetImmortal(npchar, false);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();


			sld = CharacterFromID("DH_mercenary");
			LAi_SetWarriorTypeNoGroup(sld);
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			SetCharacterTask_FollowCharacter(sld, PChar);
			LAi_warrior_DialogEnable(sld, false);
			chrDisableReloadToLocation = true;
			for (i = 0; i < 4; i++)
			{
				sld = CharacterFromID("DH_merc_mush" + i);
				if (CheckAttribute(sld, "model"))
				{
					LAi_SetWarriorType(sld);
					LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
					SetCharacterTask_FollowCharacter(sld, PChar);
				}

				sld = CharacterFromID("DH_merc_blade" + i);
				if (CheckAttribute(sld, "model"))
				{
					LAi_SetWarriorType(sld);
					LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
					SetCharacterTask_FollowCharacter(sld, PChar);
				}

			}
		break;

		case "exit_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			LAi_SetImmortal(npchar, false);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();
		break;
	}
}

