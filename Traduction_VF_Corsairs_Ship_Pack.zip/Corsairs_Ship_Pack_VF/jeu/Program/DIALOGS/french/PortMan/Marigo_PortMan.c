// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			
			// ==> Анжелика Тич: Портниха знатной дамы
			if(CheckAttribute(pchar, "questTemp.AT_PZD_PU"))
			{
				DeleteAttribute(pchar, "questTemp.AT_PZD_taverna")
				DeleteAttribute(pchar, "questTemp.AT_PZD_PU")
				link.l1 = "Dites-moi, quels navires sous pavillon espagnol avez-vous vus la semaine dernière ?";
				link.l1.go = "AT_PZD_PU_1";
				break;
			}
			// <== Анжелика Тич: Портниха знатной дамы
		break;
		
		//============ Анжелика Тич: Портниха знатной дамы
		case "AT_PZD_PU_1":
    		dialog.text = "Sous pavillon espagnol, dites-vous ? Il n'y en a pas eu beaucoup. Le galion 'Ernal Diaz' du capitaine Gabriel de Seguens. Deux flמtes marchandes sont arrivées hier de Portobelo ; leur propriétaire à toutes deux est Andres Foseca. Et puis votre '" + PChar.Ship.Name + "'.";
    		link.l1 = "D'oם vient le galion ?";
    		link.l1.go = "AT_PZD_PU_2";
 		break;
		
		case "AT_PZD_PU_2":
    		dialog.text = "De La Havane. Mais c'est ce qu'indiquent mes documents ; personne n'a rendu compte de son itinéraire en détail.";
    		link.l1 = "Savez-vous quelque chose sur les passagers ?";
    		link.l1.go = "AT_PZD_PU_3";
 		break;
		
		case "AT_PZD_PU_3":
    		dialog.text = "Désolé, c'est tout.";
    		link.l1 = "Oui, c'est dommage.";
    		link.l1.go = "AT_PZD_PU_4";
 		break;
		
		case "AT_PZD_PU_4":
    		dialog.text = "Vous savez, si vous cherchez quelqu'un, interrogez les journaliers du port : ils fréquentent aussi les marins qui arrivent. Ils n'ont pas le temps de bavarder pendant la journée, mais le soir, ils installent souvent leur campement ici même, sur le rivage.";
    		link.l1 = "Merci.";
    		link.l1.go = "AT_PZD_PU_5";
 		break;
		
		case "AT_PZD_PU_5":
    		DialogExit();
			
			AddQuestRecord("AT_PZD", "3");
			
			//Сюда ставить матросов у костра
			sld = GetCharacter(NPC_GenerateCharacter("AT_PZD_Matros1", "shipowner_22", "man", "man", 3, HOLLAND, -1, false));
			sld.name = "Paltures";
			sld.lastname = "Kate";
			LAi_SetLoginTime(sld, 22.0, 3.99);
			LAi_SetGroundSitType(sld);
			sld.dialog.filename = "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c";
			sld.dialog.currentnode = "AT_PZD_MatrosUKostra_1";
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			sld.City = "Marigo";
			ChangeCharacterAddressGroup(sld, "Marigo_town", "sit", "fire1_1");
			
			sld = GetCharacter(NPC_GenerateCharacter("AT_PZD_Matros2", "pirate_19", "man", "man", 3, HOLLAND, -1, false));
			sld.name = "Paltures";
			sld.lastname = "Kate";
			LAi_SetLoginTime(sld, 22.0, 3.99);
			LAi_SetGroundSitType(sld);
			sld.dialog.filename = "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c";
			sld.dialog.currentnode = "AT_PZD_MatrosUKostra_1";
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			sld.City = "Marigo";
			ChangeCharacterAddressGroup(sld, "Marigo_town", "sit", "fire1_2");
			
			sld = GetCharacter(NPC_GenerateCharacter("AT_PZD_Matros3", "pirate_20", "man", "man", 3, HOLLAND, -1, false));
			sld.name = "Paltures";
			sld.lastname = "Kate";
			LAi_SetLoginTime(sld, 22.0, 3.99);
			LAi_SetGroundSitType(sld);
			sld.dialog.filename = "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c";
			sld.dialog.currentnode = "AT_PZD_MatrosUKostra_1";
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			sld.City = "Marigo";
			ChangeCharacterAddressGroup(sld, "Marigo_town", "sit", "fire1_3");
			
			sld = GetCharacter(NPC_GenerateCharacter("AT_PZD_Matros4", "shipowner_23", "man", "man", 3, HOLLAND, -1, false));
			LAi_SetLoginTime(sld, 22.0, 3.99);
			LAi_SetActorType(sld);
			LAi_ActorSetLayMode(sld);
			LAi_CharacterDisableDialog(sld);
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			sld.City = "Marigo";
			ChangeCharacterAddressGroup(sld, "Marigo_town", "sit", "fire2_1");
 		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}


