// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
            dialog.text = "Parlez, je vous écoute.";
			link.l1 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Adieu.";
			link.l1.go = "Exit";
            if (pchar.questTemp.State == "MorrisWillams_ArrestedToPrison")   // разговор по шестому квесту англ.линейки
            {
    			link.l2 = "Lieutenant, je n'irai pas par quatre chemins. Je veux que le prisonnier Morris Williams soit libéré.";
    			link.l2.go = "Step_E6_1";
            }
            if (pchar.questTemp.State == "SaveFromMorgan_toPrison")   // испанка, квест №1
            {
    			link.l2 = "Officier, je sais que vous détenez trois Espagnols ; il semble que Morgan les ait capturés.";
    			link.l2.go = "Step_S1_1";
            }
			if(CheckAttribute(PChar, "ToHelpMaksInPortRoyal"))
            {
    			link.l3 = "Je m'interroge sur le sort d'une certaine personne. Maxine.";
    			link.l3.go = "BS_F3_HelpMaks";
            }
		break;
		
		case "BS_F3_HelpMaks":	//Комендант.
			DeleteAttribute(PChar, "ToHelpMaksInPortRoyal");
			BS_ReplaceHostessWithMaks();
			sld = CharacterFromID("PortRoyal_Hostess");
			SaveOldDialog(sld);
			sld.dialog.filename = "Quest\BlackSails\BS_Final_3.c";
			sld.dialog.currentnode = "BS_F3_62";
			dialog.text = "Ah, madame ! Elle va bien. On l'a gardée en cage deux ou trois jours, puis un messager est venu de la part du gouverneur lui-même avec une grâce. Et on l'a laissée partir, à la grâce de Dieu !" ;
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

        case "Step_E6_1":
            dialog.text = "Hum... Eh bien, j'apprécie votre franchise. J'avoue que je n'aime pas non plus l'arrestation et la détention d'un gentilhomme\n"+
                          "Mais je suis militaire, et je n'enfreindrai les ordres en aucune circonstance. Je vous conseille de vous adresser au gouverneur général, et je vous souhaite bonne chance.";
			link.l1 = "Pourquoi au gouverneur général ?";
			link.l1.go = "Step_E6_2";
		break;
        case "Step_E6_2":
            dialog.text = "Parce que Morris Williams a été arrêté sur son ordre écrit.";
			link.l1 = "Compris... Dites-moi, lieutenant, puis-je parler à Williams ?";
			link.l1.go = "Step_E6_3";
		break;
        case "Step_E6_3":
            dialog.text = "Je pense que oui. Mais tout de suite, pas plus tard. Et soyez bref.";
			link.l1 = "Merci, lieutenant.";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			pchar.questTemp.State = "MorrisWillams_ArrestedToModiford";
			AddQuestRecord("Eng_Line_6_MorrisWillams", "16");
		break;

        case "Step_S1_1":
            dialog.text = "Et alors ?";
			link.l1 = "Rien de spécial. Je veux juste leur rendre la liberté.";
			link.l1.go = "Step_S1_2";
		break;
        case "Step_S1_2":
            dialog.text = "Cette question n'est pas de mon ressort.";
			link.l1 = "Et moi, je pense que vous devriez vous y intéresser de très près. Sinon, je vous tue.";
			link.l1.go = "Step_S1_3";
		break;
        case "Step_S1_3":
            dialog.text = "On n'a jamais vu une telle insolence. Gardes, sus à "+ GetSexPhrase("lui", "elle") +" !!";
			link.l1 = "Eh bien, tu l'auras voulu...";
			link.l1.go = "fight";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
