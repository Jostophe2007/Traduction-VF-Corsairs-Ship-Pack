#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bonjour ! Je suis heureuse de vous voir. Vous savez, il semble que vous ayez été la seule personne à survivre à cette terrible tempête... Oh, pardon, "+ GetSexPhrase("monsieur", "mademoiselle") +", je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service. C'est un plaisir de saluer des hכtes si accueillants.";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bonjour ! Je suis heureuse de voir une nouvelle tête. Vous savez, lors de cette dernière et terrible tempête, il semble que vous ayez été la seule personne à survivre... Oh, pardon, "+ GetSexPhrase("monsieur", "mademoiselle") +", je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service. C'est un plaisir de saluer des hכtes si accueillants.";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Vous avez besoin de quelque chose, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//покупка карты
				sld = characterFromId("LSC_Trader");
				if (CheckAttribute(sld, "quest.takeMap") && sld.quest.takeMap == "notTrade" && sld.quest.takeMap != "discount")
				{
					link.l4 = "Vous n'imaginez pas à quel point Eric Yost est cupide et égoïste !";
					link.l4.go = "takeMap";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de venir avec moi sur le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FS_1":
			dialog.text = "Vous savez, donner un abri à quiconque pendant une tempête est notre devoir. Cependant, je le fais toujours avec grand plaisir.";
			link.l1 = "C'est très louable.";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "Vous savez, nous sommes déjà comme dans une cage, dans la Cité. C'est pourquoi je suis toujours heureuse de rencontrer de nouvelles personnes.";
			link.l1 = "Moi aussi, c'est un plaisir de rencontrer une personne aussi charmante. Si je comprends bien, la Cité est peu peuplée.";
			link.l1.go = "FT_2";
		break;

		case "FT_1":
			dialog.text = "Vous savez, il fait beau en ce moment. Mais parfois, je suis même contente qu'une tempête éclate et que les gens surpris sur le Velasco restent chez moi pour attendre la fin du mauvais temps. J'ai quelqu'un à qui parler...";
			link.l1 = "Oui, vous n'avez pas beaucoup de monde ici.";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Que voulez-vous, l'ennui peut être mortel... Alors, comment avez-vous échoué chez nous ? Racontez-moi.";
			link.l1 = "Mon navire a fait naufrage et j'ai perdu tout mon équipage. Malheureusement... Même si, d'un autre cכté, j'ai eu de la chance.";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Euh... Cela sonne un peu sacrilège, mais vous avez vraiment de la chance.";
			link.l1 = "Oui, je le comprends.";
			link.l1.go = "exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez " + GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Je serai heureuse de vous aider si je le peux, bien sמr. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pense à quelqu'un d'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l2 = "Depuis combien de temps êtes-vous ici ?";
				link.l2.go = "ansewer_2";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Bienvenue dans la Cité des navires abandonnés, c'est le nom de cette île.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Pas depuis si longtemps. Cependant, tout ça m'ennuie déjà à mourir.";
			link.l1 = "Je comprends...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Mon Dieu, ce n'est pas un rêve ?";
			link.l1 = "C'est la réalité...";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Mon Dieu, c'est enfin arrivé ! Je peux partir d'ici ?";
			link.l1 = "Oui, si vous vous dépêchez.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Je suis prête à tout. Que dois-je faire ?";
			link.l1 = "Allez sur le San Gabriel. Henrik Wedeker vous emmènera sur mon navire. Et ne tardez pas !";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, je serai bientכt sur le « San Gabriel ».";
			link.l1 = "Je vous en prie, dépêchez-vous...";
			link.l1.go = "SeekCrew_all";
		break;
		//квест получения карты
		case "TakeMap":
			dialog.text = "Qu'est-ce qui vous arrive ?";
			link.l1 = "Vous savez, il veut littéralement me dépouiller !";
			link.l1.go = "TakeMap_1";
		break;
		case "TakeMap_1":
			dialog.text = "Ce n'est pas possible.";
			link.l1 = "Enfin, sans me mettre un couteau sous la gorge, bien sמr. Votre Eric Yost veut me vendre une carte de la Cité à un prix incroyable !";
			link.l1.go = "TakeMap_2";
		break;
		case "TakeMap_2":
			dialog.text = "Eh bien, ce n'est pas grave. Si vous avez quelque chose à vendre, vous avez le droit de fixer le prix que vous voulez. Et Eric est dans son droit, lui aussi.";
			link.l1 = "Eh bien, c'est un drכle de droit...";
			link.l1.go = "TakeMap_3";
		break;
		case "TakeMap_3":
			dialog.text = "Alors, vous avez vraiment besoin de cette carte ? Vous ne vous en sortez pas du tout sans elle ?";
			link.l1 = "Oui, c'est un peu difficile...";
			link.l1.go = "TakeMap_4";
		break;
		case "TakeMap_4":
			dialog.text = "Eh bien, je vais vous aider. Après tout, le Seigneur nous demande d'être miséricordieux envers notre prochain. Allez voir Eric demain, je lui dirai de baisser le prix de cette carte à un niveau raisonnable.";
			link.l1 = "Et il vous écoutera ?";
			link.l1.go = "TakeMap_5";
		break;
		case "TakeMap_5":
			dialog.text = "Sans aucun doute.";
			link.l1 = "Merci beaucoup !";
			link.l1.go = "exit";
			sld = characterFromId("LSC_Trader");
			sld.quest.takeMap = "discount";
			sld.quest.takeMap.name = GetFullName(npchar);
		break;
	}
	NextDiag.PrevNode = NodeName;
}
