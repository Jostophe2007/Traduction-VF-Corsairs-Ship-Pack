// Gregg: Alan Barret - «Чёрная Орхидея», глава 7 «Маленький ублюдок».
// Логика - Program\Quests\reaction_functions\blackorchid.c.
// После главы 7 Баррет остаётся привратником Джекмена насовсем: вход в резиденцию
// платный, разово или на месяц. Так в оригинале К:ПС.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			if (Locations[FindLocation("Pirates_town")].reload.l3.disable == 1)
			{
				dialog.text = "Jackman, c'est ça ? Tu connais le tarif.";
				link.l1 = "Je le connais. Je paie.";
				link.l1.go = "Open_1";
				link.l2 = "Une autre fois.";
				link.l2.go = "exit";
			}
			else
			{
				dialog.text = "La porte est ouverte. Vas-y.";
				link.l1 = "J'y vais.";
				link.l1.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "Open_1":
			dialog.text = "Pour une fois, ou pour le mois ?";
			link.l1 = "Pour une fois. Mille.";
			link.l1.go = "Open_2";
			link.l2 = "Pour le mois. Quinze mille.";
			link.l2.go = "Open_4";
			link.l3 = "Ni l'un ni l'autre.";
			link.l3.go = "exit";
		break;

		case "Open_2":
			if (sti(PChar.money) >= BO_SM_VISIT_PRICE)
			{
				dialog.text = "La porte est ouverte. Pour une fois.";
				link.l1 = "C'est noté.";
				link.l1.go = "Open_3";
			}
			else
			{
				dialog.text = "Tu es un peu léger. Reviens avec de quoi payer.";
				link.l1 = "Je le ferai.";
				link.l1.go = "exit";
			}
		break;

		case "Open_3":
			BO_BermudesResidenceOpen(BO_SM_VISIT_PRICE, "o");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Open_4":
			if (sti(PChar.money) >= BO_SM_MONTH_PRICE)
			{
				dialog.text = "Le mois est à toi. א compter d'aujourd'hui.";
				link.l1 = "C'est noté.";
				link.l1.go = "Open_5";
			}
			else
			{
				dialog.text = "Tu es un peu léger. Reviens avec de quoi payer.";
				link.l1 = "Je le ferai.";
				link.l1.go = "exit";
			}
		break;

		case "Open_5":
			BO_BermudesResidenceOpen(BO_SM_MONTH_PRICE, "m");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "1":
			dialog.text = "Qu'est-ce que tu veux, le chiot ?";
			link.l1 = "Surveille ton langage, Barret.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Tu sais qui je suis ? Alan Barret. Quarante ans dans ces eaux.";
			link.l1 = "Quarante ans, c'est un âge, pas un argument.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(avec un sourire)... Mon argument est à ma ceinture. Tu veux le voir ?";
			link.l1 = "C'est Jackman que je veux, pas ta ceinture.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Jackman est occupé. Pour toi, il est toujours occupé.";
			link.l1 = "C'est lui qui l'a décidé, ou c'est toi ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Tant que je garde cette porte, c'est moi. Fiche le camp, le chiot.";
			link.l1 = "Traite-moi encore une fois de chiot et tu le regretteras.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Chiot.";
			link.l1 = "...(dégaine)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelBattleWithBarret");
		break;

		case "7":
			dialog.text = "...(assis, adossé à l'épave)... Assez. Assez, tu m'entends.";
			link.l1 = "Oם as-tu appris à te battre comme ça ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Quarante ans, mon gars. Je te l'ai dit. En quarante ans, on m'a mis à terre trois fois, et tu es le troisième. Je ne vais pas mentir là-dessus.";
			link.l1 = "J'ai besoin de Jackman. Maintenant.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "דa peut s'arranger. Contre de l'argent.";
			link.l1 = "Payer pour une conversation ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Payer pour la tranquillité. Depuis ce coup de feu, il y a pris goמt. Et moi, je reste ici et je compte.";
			link.l1 = "J'ai entendu parler du coup de feu à la taverne. On a trouvé le tireur ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "...(il détourne les yeux)... Un homme qui n'est plus de ce monde. N'en demande pas plus.";
			link.l1 = "Combien.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Mille pour une fois. Ou quinze mille, et pendant un mois, tu entres comme chez toi.";
			link.l1 = "Et la moitié reste chez toi, n'est-ce pas ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "...(sans la moindre gêne)... Moins. Mais il en reste.";
			link.l1 = "Au moins, tu ne mens pas.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Pas de raison de mentir, il n'y a qu'une porte. Alors, tu paies ?";
			link.l1 = "Je vais y réfléchir. Je te retrouverai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToJackman");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
