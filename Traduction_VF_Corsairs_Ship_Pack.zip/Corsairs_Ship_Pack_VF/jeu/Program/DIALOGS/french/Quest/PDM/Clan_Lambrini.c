
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int Rank = sti(pchar.rank) - 4 + MOD_SKILL_ENEMY_RATE*3;
	if (Rank < 1) Rank = 1;
	int Sila = 70 + MOD_SKILL_ENEMY_RATE*3 * 3;
	int DopHP = 60 + MOD_SKILL_ENEMY_RATE*3 * 12;
	int Bonus = sti(pchar.rank);
	if (Bonus <= 6) Bonus = 1;
	if (Bonus >= 7 && Bonus <= 12) Bonus = 1.2;
	if (Bonus >= 13) Bonus = 1.5;
	int Plata1 = 10000 + 1800 * sti(pchar.rank) * Bonus;
	int Plata2 = 20000 + 2000 * sti(pchar.rank) * Bonus;
	int Plata3 = Plata2 * 2;
	pchar.PDM_NK_Plata1.Money = 10000 + 1800 * sti(pchar.rank) * Bonus;
	pchar.PDM_NK_Plata2.Money = 20000 + 2000 * sti(pchar.rank) * Bonus;

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Hé, "+ GetSexPhrase("le gars", "la fille") +" ! C'est ma table, et je ne cherche pas de compagnie.";
			link.l1 = "Mais tu l'as déjà TROUVוE. Alors, discutons.";
			link.l1.go = "Octavio_1_1";
			link.l2 = "Je ne veux pas te déranger. Adieu.";
			link.l2.go = "exit";
			PlayVoice("Kopcapkz\Voices\PDM\Octavio Lambrini.wav");
		break;

		case "Octavio_1_1":
			dialog.text = "Quoi ? Tu oses déranger Octavio Lambrini ? Pour qui te prends-tu ?";
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				link.l1 = "Eh oui, tu as devant toi " + GetFullName(pchar)+". Capitaine, noble brigand, médecin et sauveur de Bridgetown face aux Espagnols. Et le nom de « Lambrini » ne me dit rien.";
				link.l1.go = "Octavio_1_2";
			}
			if (pchar.name == "Whisper")
			{
				link.l2 = "Eh oui, tu as devant toi "+pchar.name+". Capitaine, noble brigande, voyageuse dans le temps qui s'est rendue au cœur même de l'Inquisition. Et le nom de « Lambrini » ne me dit rien.";
				link.l2.go = "Octavio_1_2";
			}
			if (pchar.lastname == "Sharp")
			{
				link.l3 = "Je m'appelle " + GetFullName(pchar)+" : je suis "+ GetSexPhrase("le fils", "la fille") +" du célèbre pirate Nicholas Sharp. Et le nom de « Lambrini » ne me dit rien.";
				link.l3.go = "Octavio_1_2";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				link.l4 = "Eh oui, tu as devant toi " + GetFullName(pchar)+". Gentilhomme, capitaine, sauveur du monde face au sinistre Kukulcán. Et le nom de « Lambrini » ne me dit rien.";
				link.l4.go = "Octavio_1_2";
			}
			if (pchar.lastname == "Hauk")
			{
				link.l6 = "Eh oui, tu as devant toi " + GetFullName(pchar)+". Capitaine, "+ GetSexPhrase("noble brigand", "noble brigande") +" et la personne qui a envoyé le Black Pearl par le fond. Et le nom de « Lambrini » ne me dit rien.";
				link.l6.go = "Octavio_1_2";
			}
			if (pchar.lastname == "Cortez")
			{
				link.l7 = "Je m'appelle " + GetFullName(pchar)+" : je descends du célèbre conquistador et explorateur Hernán Cortés. Et le nom de « Lambrini » ne me dit rien.";
				link.l7.go = "Octavio_1_2";
			}
			if (pchar.name == "Angelica" && pchar.lastname == "Teach")
			{
				link.l1 = "Je m'appelle " + GetFullName(pchar)+" : je suis la fille d'un célèbre pirate, Barbe Noire. Et le nom de « Lambrini » ne me dit rien.";
				link.l1.go = "Octavio_1_2";
			}
			if (sti(pchar.reputation) > 80)
			{
				link.l8 = "Je m'appelle " + GetFullName(pchar)+". Tout le monde sait que je suis une personne d'honneur et qu'on peut me faire confiance. Et le nom de « Lambrini » ne me dit rien.";
				link.l8.go = "Octavio_1_2_DB";
			}
			if (sti(pchar.reputation) < 20)
			{
				link.l8 = "Je m'appelle " + GetFullName(pchar)+". Et rien qu'à l'évocation de mon nom, tout le monde tremble et s'enfuit dans tous les sens. Et le nom de « Lambrini » ne me dit rien.";
				link.l8.go = "Octavio_1_2_DB";
			}
			link.l9 = "Je suis "+pchar.name+", capitaine et "+ GetSexPhrase("mercenaire", "mercenaire") +". Je ne me souviens pas de toi.";
			link.l9.go = "Octavio_1_2_ostalnoe";
		break;

		case "Octavio_1_2":
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				dialog.text = "Alors, c'est TOI le médecin qui a sauvé toute la ville de ces Espagnols ! Incroyable ! Si tu es vraiment à la hauteur de ta réputation, alors nous pouvons discuter.";
			}
			if (pchar.name == "Whisper")
			{
				dialog.text = "Alors, c'est TOI qui as tellement agacé de Souza que tout Santiago est sens dessus dessous ! Pas mal ! Si tu es vraiment à la hauteur de ta réputation, alors nous pouvons bavarder.";
			}
			if (pchar.lastname == "Sharp")
			{
				dialog.text = ""+ GetSexPhrase("Le fils", "La fille") +" de Nicholas Sharp ? Pas mal ! J'ai connu ton père il y a longtemps, quand les Lambrini venaient de s'installer sur cette île. Ton père était un brave homme. Si tu vaux la moitié de ce qu'il valait, nous pouvons discuter.";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				dialog.text = "Tenochtitlan, et la victoire sur un dieu en personne ? Incroyable ! Si tu es vraiment à la hauteur de ta réputation, alors nous pouvons discuter.";
			}
			if (pchar.lastname == "Hauk")
			{
				dialog.text = "" + GetFullName(pchar)+" ? Ici, à la Trinité ? Mille sabords ! Si tu es vraiment à la hauteur de ta réputation, alors nous pouvons discuter.";
			}
			if (pchar.lastname == "Cortez")
			{
				dialog.text = "Le sang d'Hernán Cortés ? Pas mal ! Ton ancêtre était un grand homme, et si tu vaux la moitié de ce qu'il valait, nous pouvons discuter.";
			}
			if (pchar.name == "Angelica" && pchar.lastname == "Teach")
			{
				dialog.text = "Le sang d'Edward Teach ? Pas mal ! Ton père est un grand homme, et si tu vaux la moitié de ce qu'il vaut, nous pouvons discuter.";
			}
			link.l1 = "Qu'est-ce que tu fais ?";
			link.l1.go = "Octavio_1_3";
		break;

		case "Octavio_1_2_ostalnoe":
			dialog.text = "C'est ton problème, "+ GetSexPhrase("garçon", "fille") +". La famille Lambrini est bien connue dans ces îles. Tu ferais mieux de te tenir loin de nous.";
			link.l1 = "D'accord, je reviendrai plus tard, quand je serai plus "+ GetSexPhrase("connu", "connue") +". (Il faut une réputation très basse ou très haute)";
			link.l1.go = "exit";
		break;

		case "Octavio_1_2_DB":
			dialog.text = ""+GetFullName(pchar)+" ? Oui, j'ai beaucoup entendu parler de toi. Si tu es vraiment à la hauteur de ta réputation, alors nous pouvons discuter.";
			link.l1 = "Qu'est-ce que tu fais ?";
			link.l1.go = "Octavio_1_3";
		break;

		case "Octavio_1_3":
			dialog.text = "Ma famille et moi faisons des affaires dans tout l'archipel des Caraïbes. Nos bénéfices sont importants, car nous évitons de payer de lourdes taxes sur nos cargaisons. Certains nous appellent des contrebandiers.";
			link.l1 = "Tu as parlé de ta famille : qui sont-ils ?";
			link.l1.go = "Octavio_1_4";
		break;

		case "Octavio_1_4":
			dialog.text = "Ah ! La famille, c'est une chose très importante pour les Lambrini. Nous sommes venus de Sicile dans le Nouveau Monde il y a quarante ans. א l'époque, c'était mon père qui dirigeait nos affaires ici. Après sa mort, je suis devenu le chef de la famille. Maintenant, je travaille avec mes fils, Fabio et Emilio, et mon neveu, Cesario.";
			link.l1 = "Je cherche du travail. Tu as quelque chose à me proposer ?";
			link.l1.go = "Octavio_1_5";
		break;

		case "Octavio_1_5":
			dialog.text = "Oui. Il y a un problème pour lequel tu peux nous aider.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "Octavio_1_6";
		break;

		case "Octavio_1_6":
			dialog.text = "Nous sommes des contrebandiers. Et même si la plupart des garde-cכtes ne voient pas d'inconvénient à traiter avec nous, un homme honnête parmi eux peut causer beaucoup d'ennuis. Oui, on peut tout à fait s'arranger avec la plupart d'entre eux. Mais il y a une exception. Ce type, Arcadio de Galvez, possède un beau navire appelé El Tiburón. Et ce salaud n'accepte pas les pots-de-vin ! Alors nous ne pouvons pas faire nos affaires près de Maracaibo.";
			link.l1 = "Et tu veux que je "+ GetSexPhrase("te débarrasse", "te débarrasse") +" de lui ?";
			link.l1.go = "Octavio_1_7";
			link.l2 = "דa ne m'intéresse pas, Octavio. Si tu es moitié aussi fort que tu le dis, tu peux régler son compte à ce type tout seul. Adieu.";
			link.l2.go = "exit";
		break;

		case "Octavio_1_7":
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Débrouille-toi simplement avec ce type, d'une façon ou d'une autre.";
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Si tu as vraiment battu les Espagnols à la Barbade, alors tu te débarrasseras de ce type d'autant plus facilement.";
			}
			if (pchar.name == "Whisper")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Si tu as vraiment réussi à agacer de Souza, alors tu te débarrasseras de ce type d'autant plus facilement.";
			}
			if (pchar.lastname == "Sharp")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Mais si tu es moitié aussi "+ GetSexPhrase("rusé", "rusée") +" que l'était ton père, tu en viendras à bout.";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Si tu as vraiment réussi à vaincre Kukulcán, alors tu viendras à bout de ce type d'autant plus facilement.";
			}
			if (pchar.lastname == "Hauk")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Si tu as vraiment coulé le Black Pearl, alors tu te débarrasseras de ce type d'autant plus facilement.";
			}
			if (pchar.lastname == "Cortez")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, brמle-le sur le bמcher ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Tu as en toi le sang d'un grand conquistador ; si tu es ne serait-ce qu'à moitié aussi "+ GetSexPhrase("rusé", "rusée") +" que lui, tu viendras d'autant plus facilement à bout de ce type.";
			}
			if (pchar.name == "Angelica" && pchar.lastname == "Teach")
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, brמle-le sur le bמcher ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Tu as en toi le sang d'Edward Teach ; si tu es ne serait-ce qu'à moitié aussi "+ GetSexPhrase("rusé", "rusée") +" que lui, tu viendras d'autant plus facilement à bout de ce type.";
			}
			if (sti(pchar.reputation) > 80 || sti(pchar.reputation) < 20)
			{
				dialog.text = "Peu importe. Tue-le, cloue-le à ton beaupré, donne-le aux requins, livre-le aux Anglais ou soudoie-le, ça n'a pas d'importance. Mais nous ne pouvons pas laisser passer un morceau aussi savoureux que Maracaibo. Les autres contrebandiers évitent Maracaibo. Ils ont peur des Espagnols, et à juste titre. Si tu t'appelles vraiment " + GetFullName(pchar)+", alors tu te débarrasseras de ce type d'autant plus facilement.";
			}
			link.l1 = "Combien ?";
			link.l1.go = "Octavio_1_8";
			link.l2 = "דa ne m'intéresse pas, Octavio. Si tu es moitié aussi fort que tu le dis, tu peux régler son compte à ce type tout seul. Adieu.";
			link.l2.go = "exit";
		break;

		case "Octavio_1_8":
			dialog.text = "" + Plata1 + " pièces d'or. Et sache qu'on ne marchande pas avec les Lambrini !";
			link.l1 = ""+ GetSexPhrase("d'accord", "d'accord") +".";
			link.l1.go = "Octavio_1_9";
			link.l2 = "דa ne m'intéresse pas, Octavio. Si tu es moitié aussi fort que tu le dis, tu peux régler son compte à ce type tout seul. Adieu.";
			link.l2.go = "exit";
		break;

		case "Octavio_1_9":
			dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand tu t'en seras occupé.";
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				dialog.text = "Yo-ho, mon garçon ! Tu parles comme un vrai docteur. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand tu t'en seras occupé.";
			}
			if (pchar.name == "Whisper")
			{
				dialog.text = "Yo-ho, la fille aux cheveux violets ! On dirait une vraie Chuchoteuse. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand tu t'en seras occupée.";
			}
			if (pchar.lastname == "Sharp")
			{
				dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! Oui, tu me rappelles ton père, un vrai Sharp. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand ce sera réglé.";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! Tu parles comme un vrai gentilhomme. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand tu t'en seras occupé.";
			}
			if (pchar.lastname == "Hauk")
			{
				dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! On reconnaît bien le légendaire Hawk. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand ce sera réglé.";
			}
			if (pchar.lastname == "Cortez")
			{
				dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! On dirait un vrai Hernán Cortés. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand ce sera réglé.";
			}
			if (pchar.name == "Angelica" && pchar.lastname == "Teach")
			{
				dialog.text = "Yo-ho, ma fille ! On dirait une vraie Barbe Noire. Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand tu t'en seras occupée.";
			}
			if (sti(pchar.reputation) > 80 || sti(pchar.reputation) < 20)
			{
				dialog.text = "Yo-ho, "+ GetSexPhrase("garçon", "fille") +" ! On reconnaît bien là " + GetFullName(pchar)+". Peu de mots, beaucoup d'action. Maintenant, je ne donnerais pas un centime de la vie de ce de Galvez. Va, et reviens quand ce sera réglé.";
			}
			link.l1 = "א plus tard, Octavio.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Octavio_1_10_EsheRaz";

			sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_Anto2", "SpaOfficer2", "man", "man", Rank, SPAIN, -1, false));	//ВТОРОЙ
			sld.name = "Antonio";
			sld.lastname = "de Galvez";
			FantomMakeCoolFighter(sld, Rank, Sila, Sila, "blade30", "pistol2", DopHP);
			sld.SaveItemsForDead = true;
			sld.greeting = "GR_Spainguard";
			if (pchar.rank <= 9)
			{
				FantomMakeCoolSailor(sld, SHIP_NAVY, "El Tiburon", CANNON_TYPE_CULVERINE_LBS16, 100, 100, 100);
			}
			if (pchar.rank >= 10 && pchar.rank <= 14)
			{
				FantomMakeCoolSailor(sld, SHIP_POSTILLIONEN, "El Tiburon", CANNON_TYPE_CULVERINE_LBS16, 100, 100, 100);
			}
			if (pchar.rank >= 15 && pchar.rank <= 19)
			{
				FantomMakeCoolSailor(sld, SHIP_DEBRACKW, "El Tiburon", CANNON_TYPE_CULVERINE_LBS24, 100, 100, 100);
			}
			if (pchar.rank >= 20 && pchar.rank <= 25)
			{
				FantomMakeCoolSailor(sld, SHIP_CECILIA, "El Tiburon", CANNON_TYPE_CULVERINE_LBS24, 100, 100, 100);
			}
			if (pchar.rank >= 26 && pchar.rank <= 32)
			{
				FantomMakeCoolSailor(sld, SHIP_AGAMEMNON, "El Tiburon", CANNON_TYPE_CANNON_LBS32, 100, 100, 100);
			}
			if (pchar.rank >= 33)
			{
				FantomMakeCoolSailor(sld, SHIP_ZEVENPROVINCIEN, "El Tiburon", CANNON_TYPE_CANNON_LBS42, 100, 100, 100);
			}
			sld.ship.Crew.Morale = Sila;								//Мораль
			ChangeCrewExp(sld, "Sailors", Sila);						//Матросы
			ChangeCrewExp(sld, "Cannoners", Sila);					//Канониры
			ChangeCrewExp(sld, "Soldiers", Sila);						//Солдаты
			sld.DontRansackCaptain = true; 							//Квестовые не сдаются
			sld.SinkTenPercent = false; 								//Уходит с повреждениями
			sld.SaveItemsForDead = true;							//Сохранить предметы после смерти
			sld.DontClearDead = true;								//не убирать труп через 200с
			sld.AnalizeShips = true;
			Group_FindOrCreateGroup("PDM_el_tib");					//Название группы
			Group_SetType("PDM_el_tib", "war");						//Тип поведения
			Group_AddCharacter("PDM_el_tib", "PDM_CL_Anto2");		//Добавить капитана

			Group_SetGroupCommander("PDM_el_tib", "PDM_CL_Anto2");
			Group_SetTaskAttack("PDM_el_tib", PLAYER_GROUP);
			Group_SetAddress("PDM_el_tib", "Maracaibo", "quest_ships", "reload_fort1");	//Установить местоположение
			Group_LockTask("PDM_el_tib");

//			PChar.quest.PDM_CL_Antonio_Ubit.win_condition.l1 = "NPC_Death";
//			PChar.quest.PDM_CL_Antonio_Ubit.win_condition.l1.character = "PDM_CL_Antonio";
//			PChar.quest.PDM_CL_Antonio_Ubit.win_condition = "PDM_CL_Antonio_Ubit";

			PChar.quest.PDM_CL_Antonio_Ubit2.win_condition.l1 = "NPC_Death";
			PChar.quest.PDM_CL_Antonio_Ubit2.win_condition.l1.character = "PDM_CL_Anto2";
			PChar.quest.PDM_CL_Antonio_Ubit2.win_condition = "PDM_CL_Antonio_Ubit";

			pchar.questTemp.PDM_CL_Ishem = "Ishem";

			SetQuestHeader("PDM_Clan_Lambrini");
			AddQuestRecord("PDM_Clan_Lambrini", "1");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
		break;

		case "Octavio_1_10_EsheRaz":
			dialog.text = "Alors, "+ GetSexPhrase("garçon", "fille") +" – tu as tué ce vermisseau de Galvez ?";
			link.l1 = "Je lui arracherai les yeux, n'en doute pas. Mais chaque chose en son temps.";
			link.l1.go = "Octavio_1_11_EsheRaz";
		break;

		case "Octavio_1_11_EsheRaz":
			dialog.text = "Alors, je te laisse du temps, "+ GetSexPhrase("garçon", "fille") +", mais souviens-toi : les Lambrini ne sont pas très patients.";
			link.l1 = "Sois tranquille : je ne te ferai pas attendre longtemps. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Octavio_1_10_EsheRaz";
		break;

		case "Antonio_1_1":
			dialog.text = "Que vouliez-vous, "+ GetSexPhrase("señor", "señorita") +" ?";
			link.l1 = "Vous vous appelez Arcadio de Galvez, et vous êtes des garde-cכtes ?";
			link.l1.go = "Antonio_1_2";
		break;

		case "Antonio_1_2":
			dialog.text = "Oui. Et vous, qui êtes-vous ?";
			link.l1 = "Je m'appelle " + GetFullName(pchar)+".";
			link.l1.go = "Antonio_1_3";
		break;

		case "Antonio_1_3":
			dialog.text = "Oui, oui, j'ai entendu parler de vous... Pourquoi êtes-vous ici ?";
			link.l1 = "La famille Lambrini vous salue ! (attaquer)";
			link.l1.go = "Antonio_Bitva";
			link.l2 = "Quelqu'un veut vous tuer. (trahir Lambrini)";
			link.l2.go = "Antonio_1_4";
			link.l3 = "Je dois y aller.";
			link.l3.go = "exit";
			NextDiag.TempNode = "Antonio_1_1";
		break;

		case "Antonio_Bitva":
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_SetRelation("SPAIN_CITIZENS", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("SPAIN_CITIZENS", LAI_GROUP_PLAYER, false);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Octavio_2_1":
			dialog.text = "Alors, "+ GetSexPhrase("garçon", "fille") +" – j'espère que tu as achevé ce vermisseau de Galvez ?";
			link.l1 = "Oui. Le pauvre salaud m'a supplié de l'épargner, mais ses prières ont été vaines.";
			link.l1.go = "Octavio_2_2";
		break;

		case "Octavio_2_2":
			dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			if (sti(pchar.reputation) > 80)
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tout le monde dit que tu es une personne honnête. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (sti(pchar.reputation) < 20)
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tout le monde dit que tu es une personne impitoyable. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				dialog.text = "Ha, mon garçon ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu es le sauveur de Bridgetown face aux Espagnols. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Whisper")
			{
				dialog.text = "Ha, ma fille ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as mis de Souza lui-même dans l'embarras. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Sharp")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu es "+ GetSexPhrase("le fils", "la fille") +" de Nicholas Sharp, le grand pirate. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				dialog.text = "Ha, mon garçon ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as vaincu Kukulcán en personne. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Hauk")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car c'est toi qui as coulé le Black Pearl. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Cortez")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as en toi le sang d'Hernán Cortés, le grand conquistador. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Angelica" && pchar.lastname == "Teach")
			{
				dialog.text = "Ha, ma fille ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as en toi le sang de Barbe Noire, le grand pirate. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			link.l1 = "Oui, maintenant, plus personne ne t'empêchera de commercer à Maracaibo, Octavio. Adieu.";
			link.l1.go = "exit";
			sld = CharacterFromID("PDM_Octavio_Lambrini");
			sld.lifeday = 0;
			AddMoneyToCharacter(pchar, sti(Plata1));
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, SPAIN, -6);
			AddCharacterExpToSkill(pchar, "Leadership", 130);
			AddCharacterExpToSkill(pchar, "FencingLight", 130);
			AddCharacterExpToSkill(pchar, "Fencing", 130);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 130);
			AddCharacterExpToSkill(pchar, "Pistol", 130);
			AddCharacterExpToSkill(pchar, "Fortune", 130);
			AddCharacterExpToSkill(pchar, "Sneak", 130);
			AddCharacterExpToSkill(pchar, "Sailing", 130);
			AddCharacterExpToSkill(pchar, "Accuracy", 130);
			AddCharacterExpToSkill(pchar, "Cannons", 130);
			AddCharacterExpToSkill(pchar, "Grappling", 130);
			AddCharacterExpToSkill(pchar, "Defence", 130);
			AddCharacterExpToSkill(pchar, "Repair", 130);
			NextDiag.TempNode = "Octavio_2_3_EsheRaz";
			CloseQuestHeader("PDM_Clan_Lambrini");
			pchar.questdata.ClanLambrini = 1;
		break;

		case "Octavio_2_3_EsheRaz":
			dialog.text = "Ah, "+pchar.name+" ! Bravo pour nous avoir débarrassés de ce vermisseau de Galvez ! Je pars bientכt pour Maracaibo signer des contrats avec des clients rentables.";
			link.l1 = "Bonne chance !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Octavio_2_3_EsheRaz";
		break;

		case "Antonio_1_4":
			dialog.text = "Et alors ? Si vous vouliez me surprendre, c'est raté. Lambrini veut ma mort, comme tous les autres contrebandiers d'ailleurs.";
			link.l1 = "Je viens vous faire une offre. Que diriez-vous si je vous donnais l'occasion de capturer ou de couler le navire de Lambrini ?";
			link.l1.go = "Antonio_1_6";
			link.l2 = "Eh bien, dans ce cas, adieu.";
			link.l2.go = "exit";
		break;

		case "Antonio_1_6":
			dialog.text = "Je donnerais ma main droite pour ça. Mais hélas, c'est impossible. Il a déjà acheté, semble-t-il, tous les douaniers des Caraïbes. Que puis-je faire seul ?";
			link.l1 = "Lambrini m'a proposé de l'aider à se débarrasser de vous. Il est sמr de ne pas pouvoir venir à bout de vous tout seul...";
			link.l1.go = "Antonio_1_7";
		break;

		case "Antonio_1_7":
			dialog.text = "Si vous travaillez pour les contrebandiers, nous n'avons rien à nous dire, "+ GetSexPhrase("señor", "señorita") +"...";
			link.l1 = "Euh, attendez, vous ne m'avez même pas laissé parler. Je peux dire à Lambrini que j'ai coulé votre navire. Après ça, tכt ou tard, il viendra ici, pensant qu'il n'est plus en danger. Et vous pourrez lui tendre une embuscade dans la baie, ou près de là.";
			link.l1.go = "Antonio_1_8";
		break;

		case "Antonio_1_8":
			dialog.text = "Intéressant... Ce plan pourrait marcher, "+ GetSexPhrase("señor", "señorita") +" "+pchar.name+". Et s'il réussit, je veillerai à ce que le señor gouverneur vous récompense généreusement !";
			link.l1 = "Et combien pensez-vous que pourrait valoir la tête de Lambrini ?";
			link.l1.go = "Antonio_1_9";
		break;

		case "Antonio_1_9":
			dialog.text = "Je dirais environ " + Plata2 + ". Nos revenus ont beaucoup baissé ces derniers temps, à cause des contrebandiers.";
			link.l1 = "Je pense que " + Plata2 + " pièces d'or seraient une rémunération suffisante. Alors, je dirai à Octavio Lambrini que c'en est fini de vous... Quand il arrivera ici, nous l'attraperons. Quoi de plus simple ?";
			link.l1.go = "Antonio_1_10";
		break;

		case "Antonio_1_10":
			dialog.text = "Dès que vous aurez dit à Lambrini que je suis mort, revenez me voir immédiatement : je vous attendrai à l'église de 9 heures à 13 heures. Nous verrons ensuite ce qu'il faut faire.";
			link.l1 = "Prenez soin de vous, señor. Bonne chance !";
			link.l1.go = "Antonio_1_11";
			NextDiag.TempNode = "Antonio_1_12";
		break;

		case "Antonio_1_11":
			sld = CharacterFromID("PDM_Octavio_Lambrini");
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Octavio_3_1";
			DeleteAttribute(pchar, "questTemp.PDM_CL_Ishem");
			PChar.quest.PDM_CL_Antonio_Ubit.over = "yes";
			AddQuestRecord("PDM_Clan_Lambrini", "4");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PDM_Clan_Lambrini", "sSex2", GetSexPhrase("", "e"));

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Antonio_1_12":
			dialog.text = "Dès que vous aurez annoncé ma mort à Lambrini, revenez immédiatement me voir, je vous attendrai à l'église de 9 heures à 14 heures. Nous verrons ensuite ce qu'il faut faire.";
			link.l1 = "Prenez soin de vous, señor. Bonne chance !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Antonio_1_12";
		break;

		case "Octavio_3_1":
			dialog.text = "Alors, "+ GetSexPhrase("garçon", "fille") +" – j'espère que tu as tué ce vermisseau de Galvez ?";
			link.l1 = "Oui. Le pauvre salaud m'a supplié de l'épargner, mais ses prières ont été vaines.";
			link.l1.go = "Octavio_3_2";
		break;

		case "Octavio_3_2":
			dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			if (sti(pchar.reputation) > 80)
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tout le monde dit que tu es une personne honnête. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (sti(pchar.reputation) < 20)
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tout le monde dit que tu es une personne impitoyable. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Peter" && pchar.lastname == "Blood")
			{
				dialog.text = "Ha, mon garçon ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu es le sauveur de Bridgetown face aux Espagnols. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Whisper")
			{
				dialog.text = "Ha, ma fille ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as mis de Souza lui-même dans l'embarras. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Sharp")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu es "+ GetSexPhrase("le fils", "la fille") +" de Nicholas Sharp, le grand pirate. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.name == "Charles" && pchar.lastname == "de Mor")
			{
				dialog.text = "Ha, mon garçon ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as vaincu Kukulcán en personne. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Hauk")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car c'est toi qui as coulé le Black Pearl. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			if (pchar.lastname == "Cortez")
			{
				dialog.text = "Ha, "+ GetSexPhrase("garçon", "fille") +" ! Tu aurais dמ rapporter sa tête comme preuve. ד'aurait fait un joli souvenir. Mais je te crois quand même, bien sמr, car tu as en toi le sang d'Hernán Cortés, le grand conquistador. Voici tes " + Plata1 + " pièces d'or. Et tous mes problèmes sont réglés.";
			}
			link.l1 = "Oui, maintenant, plus personne ne t'empêchera de commercer à Maracaibo, Octavio. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Octavio_3_3_EsheRaz";
			sld = CharacterFromID("PDM_Octavio_Lambrini");
			sld.lifeday = 0;
			AddMoneyToCharacter(pchar, sti(Plata1));
			ChangeCharacterReputation(pchar, -2);
			ChangeCharacterNationReputation(pchar, SPAIN, 6);
			AddCharacterExpToSkill(pchar, "Sneak", 160);
			AddCharacterExpToSkill(pchar, "Sailing", 100);

			PChar.quest.PDM_CL_Ubrat_Lodku.win_condition.l1 = "ExitFromLocation";
			PChar.quest.PDM_CL_Ubrat_Lodku.win_condition.l1.location = PChar.location;
			PChar.quest.PDM_CL_Ubrat_Lodku.function = "PDM_CL_Ubrat_Lodku";
			AddQuestRecord("PDM_Clan_Lambrini", "5");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
		break;

		case "Octavio_3_3_EsheRaz":
			dialog.text = "Ah, "+pchar.name+" ! Bravo pour nous avoir débarrassés de ce vermisseau de Galvez ! Je pars bientכt pour Maracaibo signer des contrats avec des clients rentables.";
			link.l1 = "Bonne chance !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Octavio_3_3_EsheRaz";
		break;

		case "Antonio_2_1":
			dialog.text = ""+TimeGreeting()+", "+ GetSexPhrase("señor", "señorita") +" "+pchar.name+". Comment ça s'est passé ?";
			link.l1 = "Octavio Lambrini a cru à votre mort, il est sans doute déjà en route pour Maracaibo.";
			link.l1.go = "Antonio_2_2";
		break;

		case "Antonio_2_2":
			dialog.text = "Excellent. Les contrebandiers aiment traîner à la taverne, il faut y aller voir s'il s'y est montré.";
			link.l1 = "D'accord, je vais le chercher à la taverne.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Antonio_2_3_EsheRaz";

			PChar.quest.PDM_CL_PVT.win_condition.l1 = "location";		//Вход в локацию
			PChar.quest.PDM_CL_PVT.win_condition.l1.location = "Maracaibo_tavern";
			PChar.quest.PDM_CL_PVT.win_condition = "PDM_CL_PVT";

			sld = GetCharacter(NPC_GenerateCharacter("PDM_Octavio_Lambrini", "barmen_3", "man", "man", 10, PIRATE, -1, false));
			sld.name	= "Octavio";
			sld.lastname	= "Lambrini";
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Octavio_4_1";
			LAi_SetSitType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			FreeSitLocator("Maracaibo_tavern", "sit_base2");  // очистим стул
			FreeSitLocator("Maracaibo_tavern", "sit_front2");  // очистим стул
			ChangeCharacterAddressGroup(sld, "Maracaibo_tavern", "sit", "sit_front2");

			pchar.LambriniPGG = SelectRandomPGG("woman", "YokoDias");

			if (pchar.LambriniPGG == "")
			{
				pchar.LambriniPGG = "PDM_CL_Pokupatel";
				if(pchar.name == "Victoria")
				{
					sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_Pokupatel", "PGG_Cirilla_7", "woman", "YokoDias", 10, PIRATE, -1, false));
				}
				else
				{
					sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_Pokupatel", "PGG_Victori_8", "woman", "YokoDias", 10, PIRATE, -1, false));
				}
				sld.name	= "Marilisa";
				sld.lastname	= "Rinn";
			}
			else sld = CharacterFromID(pchar.LambriniPGG);

			sld.PGGAi.DontUpdate = true;
			sld.PGGAi.Task.SetSail = true;
			DeleteAttribute(sld, "PGG_warrior");
			DeleteAttribute(sld, "PGG_trader");

			SaveOldDialog(sld);
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Pokupatel_1_1";
			LAi_SetSitType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			ChangeCharacterAddressGroup(sld, "Maracaibo_tavern", "sit", "sit_base2");

			AddQuestRecord("PDM_Clan_Lambrini", "6");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
		break;

		case "Antonio_2_3_EsheRaz":
			dialog.text = "Alors, "+ GetSexPhrase("señor", "señorita") +", avez-vous vu Lambrini à la taverne ?";
			link.l1 = "Pas encore, j'allais justement y aller.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Antonio_2_3_EsheRaz";
		break;

		case "Pokupatel_1_1":
			dialog.text = "Qu'est-ce que vous voulez ? Vous ne voyez pas que je suis occupé ?";
			link.l1 = "Pardon, je ne voulais pas vous gêner.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pokupatel_1_1";
		break;

		case "Octavio_4_1":
			dialog.text = "(vous écoutez Octavio en cachette, il discute en ce moment avec un client potentiel)... Et pourquoi donc ?";
			link.l1 = "";
			link.l1.go = "Pokupatel_2_1";

			sld = CharacterFromID(pchar.LambriniPGG);
			if (sld.location == "None") FreeSitLocator("Maracaibo_tavern", "sit_base2");  // очистим стул
			DoQuestCheckDelay("PDM_CL_PVT", 0.0);
		break;

		case "Pokupatel_2_1":
			sld = characterFromID(pchar.LambriniPGG);
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Pokupatel_2_2";
			DialogExit();
			DoQuestFunctionDelay("PDM_CL_Pokupatel_Speech", 0);
		break;

		case "Pokupatel_2_2":
			dialog.text = "Je veux vendre quelque chose qu'aucun marchand de cette île n'achètera. J'ai dans ma cale une marchandise de rêve ! Des montagnes de santal, rendez-vous compte, ah.";
			link.l1 = "";
			link.l1.go = "Pokupatel_2_3";
		break;

		case "Pokupatel_2_3":
			sld = characterFromID("PDM_Octavio_Lambrini");
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Pokupatel_2_4";
			DialogExit();
			DoQuestFunctionDelay("PDM_CL_Octavio_Speech", 0);
		break;

		case "Pokupatel_2_4":
			npchar.lifeday = 0;
			dialog.text = "Je sais qu'on peut faire affaire avec vous. Nous vous attendrons dans un endroit appelé la baie de la Guajira.";
			link.l1 = "";
			link.l1.go = "Pokupatel_2_5";
		break;

		case "Pokupatel_2_5":
			sld = characterFromID(pchar.LambriniPGG);
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Pokupatel_2_6";
			DialogExit();
			DoQuestFunctionDelay("PDM_CL_Pokupatel_Speech", 0);
		break;

		case "Pokupatel_2_6":
			dialog.text = "Je viendrai sans faute, ma belle.";
			link.l1 = "";
			link.l1.go = "Pokupatel_2_7";
		break;

		case "Pokupatel_2_7":
			sld = characterFromID("PDM_Octavio_Lambrini");
			LAi_CharacterDisableDialog(sld);
			sld = characterFromID(pchar.LambriniPGG);

			LAi_CharacterDisableDialog(sld);
			DoQuestFunctionDelay("PDM_CL_Pokupatel_Uhodit", 1.5);
			sld = CharacterFromID("PDM_CL_Antonio3");
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Antonio_5_1";
			LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

			AddQuestRecord("PDM_Clan_Lambrini", "7");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
		break;


		case "Antonio_5_1":
			dialog.text = ""+ GetSexPhrase("Señor", "Señorita") +" "+pchar.name+", vous voilà de retour. Avez-vous vu quelque chose d'intéressant ?";
			link.l1 = "Oui, Lambrini est déjà en ville et s'y sent très à l'aise. J'ai réussi à surprendre sa conversation avec une capitaine qui compte vendre une marchandise illégale et coמteuse : du santal. On devrait peut-être aller à la taverne et cueillir Lambrini tout chaud ?";
			link.l1.go = "Antonio_5_2";
		break;

		case "Antonio_5_2":
			dialog.text = "Non ! Laissons-le conclure son affaire. Ils se rassembleront tous dans la baie, avec la marchandise de valeur, en pensant qu'ils ne courent aucun danger. C'est là que nous apparaîtrons pour arrêter tout le monde. Avez-vous pu découvrir oם ils comptent mener leurs sombres affaires ?";
			link.l1 = "Lambrini parlait de la baie de la Guajira.";
			link.l1.go = "Antonio_5_3";
			Pchar.GenQuest.Hunter2Pause = true;
		break;

		case "Antonio_5_3":
			dialog.text = "Parfait ! Nous les prendrons à revers par la jungle et nous les surprendrons.";
			link.l1 = "En route !";
			link.l1.go = "Antonio_J_1";
		break;

		case "Antonio_J_1":
			DialogExit();

			LocatorReloadEnterDisable("Shore37", "reload1_back", true);
			LocatorReloadEnterDisable("Shore37", "boat", true);

			sld = CharacterFromID("PDM_CL_Antonio3");
			LAi_SetActorType(sld);
			ChangeCharacterAddressGroup(sld, "Shore37", "officers", "reload1_1");
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);

			for (i=1; i<=2; i++)	//испанцы
			{
				sTemp = "sold_spa_"+(rand(7)+1);
				sld = GetCharacter(NPC_GenerateCharacter("SraDruzya_"+i, sTemp, "man", "man", Rank, SPAIN, -1, true));
				FantomMakeCoolFighter(sld, Rank, 30, 30, "blade10", "", 20);
				LAi_SetActorType(sld);
				LAi_CharacterDisableDialog(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				ChangeCharacterAddressGroup(sld, "Shore37", "reload",  "reload1_back");
			}

			for (i=3; i<=6; i++)	//пираты м контрабандисты 1
			{
				sTemp = "pirate_"+(rand(24)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_PirVrag_"+i, sTemp, "man", "man", Rank, SPAIN, -1, true));
				FantomMakeCoolFighter(sld, Rank, 30, 30, "blade10", "", 20);
				LAi_SetActorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
				ChangeCharacterAddressGroup(sld, "Shore37", "goto",  "goto5");
			}

			for (i=7; i<=10; i++)	//пираты м контрабандисты 2
			{
				sTemp = "pirate_"+(rand(24)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_PirVrag_"+i, sTemp, "man", "man", Rank, SPAIN, -1, true));
				FantomMakeCoolFighter(sld, Rank, 30, 30, "blade10", "", 20);
				LAi_SetActorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
				ChangeCharacterAddressGroup(sld, "Shore37", "goto",  "goto6");
			}

			for (i=11; i<=14; i++)	//пираты м контрабандисты 3
			{
				sTemp = "pirate_"+(rand(24)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_PirVrag_"+i, sTemp, "man", "man", Rank, SPAIN, -1, true));
				FantomMakeCoolFighter(sld, Rank, 30, 30, "blade10", "", 20);
				LAi_SetActorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
				ChangeCharacterAddressGroup(sld, "Shore37", "reload",  "sea");
			}

			DoQuestReloadToLocation("Shore37", "goto", "goto1", "PDM_CL_Na_Plyaj");
			AddGeometryToLocation("Shore37", "smg");
			pchar.location.from_sea = "Shore37";

			sld = GetCharacter(NPC_GenerateCharacter("PDM_Octavio_Lambrini", "barmen_3", "man", "man", 10, PIRATE, -1, false));
			LAi_SetActorType(sld);
			sld.name	= "Octavio";
			sld.lastname	= "Lambrini";
			FantomMakeCoolFighter(sld, Rank, 80, 80, "blade33", "pistol2", 250);
			LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
			ChangeCharacterAddressGroup(sld, "Shore37", "goto", "goto7");

			sld = CharacterFromID(pchar.LambriniPGG);
			LAi_SetActorType(sld);

			sld.LambiniAsoleda = GetGeneratedItem("blade38");
			GiveItem2Character(sld, sld.LambiniAsoleda);
			EquipCharacterByItem(sld, sld.LambiniAsoleda);

			GiveItem2Character(sld, "pistol1");
			EquipCharacterByItem(sld, "pistol1");

			sld.BackupHP = LAi_GetCharacterMaxHP(sld);
			LAi_SetHP(sld, sti(sld.BackupHP) + 1000, sti(sld.BackupHP) + 1000);
			//LAi_SetHP(sld, 100, 100);
			SetCharacterPerk(sld, "Sliding");
			sld.perks.list.AgileMan = "1";
			ApplayNewSkill(sld, "AgileMan", 0);

			sld.SPECIAL.Agility = 10;
			sld.SPECIAL.Intellect = 10;
			sld.SPECIAL.Endurance = 10;
			sld.SPECIAL.Luck = 10;

			//FantomMakeCoolFighter(sld, Rank, 90, 90, "blade38", "pistol4", 500);

			LAi_SetCheckMinHP(sld, 1, true, "LambriniPGG_CheckHP");
			/*
			AddMoneyToCharacter(sld, 100000);
			AddItems(sld, "jewelry1", rand(20)+20);
			AddItems(sld, "jewelry2", rand(20)+20);
			AddItems(sld, "jewelry3", rand(20)+20);
			AddItems(sld, "jewelry4", rand(20)+20);
			AddItems(sld, "jewelry5", rand(20)+20);
			AddItems(sld, "suit_3", 1);
			AddItems(sld, "indian5", 1);
			sld.SaveItemsForDead = true;*/
			LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
			ChangeCharacterAddressGroup(sld, "Shore37", "goto", "goto7");
		break;

		case "Antonio_6_1":
			dialog.text = "Nous y sommes. Et voilà nos Lambrini... Je n'arrive pas à croire que nous allons bientכt en finir. Menez l'escouade, nous vous suivons.";
			link.l1 = "En avant !";
			link.l1.go = "Antonio_6_2";
		break;

		case "Antonio_6_2":
			DialogExit();

			LAi_SetActorType(pchar);
			LAi_ActorRunToLocator(pchar, "enc01", "enc01_03", "PDM_CL_Na_Plyaj_2", -1);
		break;

		case "Pokupatel_6_1":
			dialog.text = "Que faites-vous ici ?";
			link.l1 = "Il semble qu'il se passe ici quelque chose d'illégal.";
			link.l1.go = "Pokupatel_6_2";
		break;

		case "Pokupatel_6_2":
			dialog.text = "Non, non, "+ GetSexPhrase("señor", "señorita") +". Mes amis et moi, nous nous détendons simplement au bord de la mer.";
			link.l1 = "Qu'est-ce que vous me racontez ! Je ne suis pas aveugle ! Suivez-nous : vous êtes en état d'arrestation et la marchandise est confisquée !";
			link.l1.go = "Pokupatel_6_3";
		break;

		case "Pokupatel_6_3":
			dialog.text = "Je vais t'étriper !";
			link.l1 = "D'abord, je vais libérer la bête qui est en moi !";
			link.l1.go = "Pokupatel_6_4";
		break;

		case "Pokupatel_6_4":
			DialogExit();

			AddDialogExitQuest("MainHeroFightModeOn");

			for (i=3; i<=14; i++)	//пираты м контрабандисты
			{
				sld = CharacterFromID("PDM_CL_PirVrag_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");
			}
			for (i=19; i<=27; i++)	//испанцы 1
			{
				sTemp = "sold_spa_"+(rand(7)+1);
				sld = GetCharacter(NPC_GenerateCharacter("SraDruzya_"+i, sTemp, "man", "man", Rank, SPAIN, -1, true));
				FantomMakeCoolFighter(sld, Rank, 28, 28, "blade10", "", 16);
				LAi_SetWarriorType(sld);
				LAi_CharacterDisableDialog(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				ChangeCharacterAddressGroup(sld, "Shore37", "goto", "goto4");
				sld.lifeday = 0;
			}
			for (i=1; i<=2; i++)	//испанцы 2
			{
				sld = CharacterFromID("SraDruzya_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				sld.lifeday = 0;
			}

			sld = CharacterFromID("PDM_Octavio_Lambrini");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");

			sld = CharacterFromID(pchar.LambriniPGG)
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "PDM_CL_PirVrag_Status");

			sld = CharacterFromID("PDM_CL_Antonio3");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);

			LAi_group_SetRelation("PDM_CL_PirVrag_Status", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("PDM_CL_PirVrag_Status", LAI_GROUP_PLAYER, false);
			//LAi_group_SetCheck("PDM_CL_PirVrag_Status", "PDM_CL_Finish");
		break;

		case "Antonio_8_1":
			string OctavioDead = "";
			if(LAi_IsDead(CharacterFromID("PDM_Octavio_Lambrini")))	OctavioDead = "";

			dialog.text = "Je n'arrive pas à croire que nous ayons réussi ! Vous pouvez retourner en ville, mes hommes vont s'occuper de ce bazar. " + OctavioDead;

			OctavioDead = "Octavio Lambrini est mort, ";
			if(!LAi_IsDead(CharacterFromID("PDM_Octavio_Lambrini")))	OctavioDead = "Octavio Lambrini a été arrêté, ";
			link.l1 = OctavioDead + "et la récompense ?";
			link.l1.go = "Antonio_8_2";
		break;

		case "Antonio_8_2":
			pchar.LambriniPGGPlata = Plata2/2;
			string addPlata = "";
			if(!LAi_IsDead(CharacterFromID("PDM_Octavio_Lambrini")))
			{
				pchar.LambriniPGGPlata = Plata2;
				AddMoneyToCharacter(pchar, sti(Plata2*2));
				addPlata = "Mais puisque nous avons réussi à prendre ce salaud vivant, je double votre rémunération de ma propre poche ! Au total, " + Plata3 + " pièces d'or. Qui sait, peut-être qu'après quelques semaines en prison, Octavio nous dira comment attraper le reste de sa famille criminelle. "
			}
			else	AddMoneyToCharacter(pchar, sti(Plata2));
			dialog.text = "Oui, bien sמr, le gouverneur vous a alloué " + Plata2 + " pièces d'or. "+addPlata+"Je vous remets cet argent en personne. Au revoir !";
			link.l1 = "Merci, Antonio. Bonne chance à vous !";
			link.l1.go = "LambriniPGG_1_5";

			LocatorReloadEnterDisable("Shore37", "reload1_back", false);
			LocatorReloadEnterDisable("Shore37", "boat", false);
			ChangeCharacterNationReputation(pchar, SPAIN, 8);
			ChangeCharacterReputation(pchar, 5);
		break;

		case "LambriniPGG_1_1":
			dialog.text = RandSwear()+"Une cargaison de santal ne vaut pas nos vies. Nous nous rendons !";
			link.l1 = "Dans ce cas, vous devez rendre votre épée, capitaine.";
			link.l1.go = "LambriniPGG_1_2";

			for (i=3; i<=14; i++)	//пираты м контрабандисты прячут оружие, испанцы - нет
			{
				sld = CharacterFromID("PDM_CL_PirVrag_"+i);
				LAi_SetStayTypeNoGroup(sld);
			}
			sld = characterFromID("PDM_Octavio_Lambrini");
			LAi_SetStayTypeNoGroup(sld);
		break;

		case "LambriniPGG_1_2":
			for (i=3; i<=14; i++)	//пираты м контрабандисты
			{
				sld = CharacterFromID("PDM_CL_PirVrag_"+i);
				LAi_SetActorTypeNoGroup(sld);
			}
			sld = characterFromID("PDM_Octavio_Lambrini");
			LAi_SetActorTypeNoGroup(sld);
			sld.LifeDay = 0;
			dialog.text = RandSwear()+"Vous n'imaginez pas ce qu'elle m'a coמté !";
			link.l1 = "Je ne le répéterai pas deux fois. ";
			link.l1.go = "LambriniPGG_1_3";
		break;

		case "LambriniPGG_1_3":
			TakeItemFromCharacter(npchar, npchar.LambiniAsoleda);
			GiveItem2Character(pchar, npchar.LambiniAsoleda);
			RemoveCharacterEquip(npchar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(npchar, GUN_ITEM_TYPE);
			Log_Info("Vous avez reçu l'Asoleda !");
			PlaySound("interface\important_item.wav");

			dialog.text = RandSwear()+"(elle vous donne l'Asoleda) Tenez, étouffez-vous avec !";
			link.l1 = "Et maintenant, Antonio ?";
			link.l1.go = "LambriniPGG_1_4";

			PChar.quest.LambriniPGG_RemoveFromShore.win_condition.l1 = "ExitFromLocation";
			PChar.quest.LambriniPGG_RemoveFromShore.win_condition.l1.location = PChar.location;
			PChar.quest.LambriniPGG_RemoveFromShore.function = "LambriniPGG_RemoveFromShore";
		break;

		case "LambriniPGG_1_4":
			DialogExit();
			sld = GetCharacter(NPC_GenerateCharacter("PDM_CL_Antonio4", "SpaOfficer2", "man", "man", Rank, SPAIN, 0, false));
			sld.name = "Antonio";
			sld.lastname = "de Galvez";
			sld.greeting = "GR_Spainguard";
			string sBlade = GetGeneratedItem("blade40");
			GiveItem2Character(sld, sBlade);
			EquipCharacterbyItem(sld, sBlade);
			ChangeCharacterAddressGroup(sld, "Shore37", "goto", "goto7");
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			//sld = CharacterFromID("PDM_CL_Antonio3");
			sld.dialog.currentnode   = "Antonio_8_1";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "LambriniPGG_1_5":
			DialogExit();
			sld = CharacterFromID(pchar.LambriniPGG);
			sld.dialog.currentnode   = "LambriniPGG_1_6";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "LambriniPGG_1_6":
			dialog.text = "C'est votre règlement de comptes avec Octavio, et je n'y suis pour rien. Laissez-moi partir ! Le nom de " + GetFullName(npchar)+ " vous dit peut-être quelque chose ? Je suis une personne bien connue dans ces eaux ! Mieux vaut ne pas se mettre en travers de mon chemin.";
			link.l1 = "";
			link.l1.go = "LambriniPGG_1_7";
		break;

		case "LambriniPGG_1_7":
			DialogExit();
			sld = CharacterFromID("PDM_CL_Antonio4");
			sld.dialog.currentnode   = "LambriniPGG_1_8";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "LambriniPGG_1_8":
			dialog.text = "Vous avez fait affaire avec un criminel, ce qui veut dire que vous êtes aussi coupable que lui ! Nous allons vous emmener à la prison sous le fort de Maracaibo, et ensuite, le tribunal décidera de votre sort.";
			link.l1 = "";
			link.l1.go = "LambriniPGG_1_9";
		break;

		case "LambriniPGG_1_9":
			LAi_SetActorTypeNoGroup(npchar);
			DialogExit();
			sld = CharacterFromID(pchar.LambriniPGG);
			sld.dialog.currentnode   = "LambriniPGG_1_10";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "LambriniPGG_1_10":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_SetHP(npchar, sti(npchar.BackupHP) + 100, sti(npchar.BackupHP) + 100);
			dialog.text = "(elle vous chuchote) Antonio est trop honnête, pour lui la loi passe avant tout, il est peu probable qu'on puisse le convaincre, mais vous ? Je vois bien que vous êtes "+ GetSexPhrase("loin d'être un enfant de chœur", "une « mauvaise » fille") +". Sortez-moi de ce pétrin, et je vous récompenserai. En plus de l'épée, vous emporterez tout mon trésor !";
			link.l1 = "דa ne m'intéresse pas. Les criminels ont leur place derrière les barreaux.";
			link.l1.go = "LambriniPGG_1_11";
			link.l2 = "Un trésor, dites-vous... Je trouverai quelque chose.";
			link.l2.go = "LambriniPGG_1_12";
		break;

		case "LambriniPGG_1_11":
			dialog.text = RandSwear()+RandSwear()+RandSwear()+RandSwear()+RandSwear()+"Maudits soyez-vous ! Bon, peu importe, je sortirai et je me vengerai de vous tous !";
			link.l1 = "Bon, bon.";
			link.l1.go = "exit";
			AddQuestRecord("PDM_Clan_Lambrini", "9");
			CloseQuestHeader("PDM_Clan_Lambrini");
			pchar.questdata.ClanLambrini = 1;
			AddQuestUserData("PDM_Clan_Lambrini", "sName", GetFullName(npchar));
			PGG_ChangeRelation2MainCharacter(CharacterFromID(pchar.LambriniPGG), -200); //сильно обиделась
			SetTimerCondition("LambriniPGG_Freedom", 0, 0, 30, false); //Посидит месяц в тюрьме без кача и потом выйдет
			ChangeCharacterNationReputation(pchar, SPAIN, 10);
			AddCharacterExpToSkill(pchar, "Leadership", 200);
			AddCharacterExpToSkill(pchar, "Fencing", 200);
			AddCharacterExpToSkill(pchar, "Pistol", 200);
		break;

		case "LambriniPGG_1_12":	//Запустить таймер в 10 дней на возврат диалога коменданту потом то же, что и в комменте выше	
			dialog.text = "Vous ne le regretterez pas ! Seulement, je vous en prie, faites vite, je ne veux pas finir à la potence !";
			link.l1 = "D'accord.";
			link.l1.go = "LambriniPGG_1_13";
			AddQuestRecord("PDM_Clan_Lambrini", "8");
			AddQuestUserData("PDM_Clan_Lambrini", "sName", GetFullName(npchar));
		break;

		case "LambriniPGG_1_13":
			DialogExit();
			SetTimerCondition("LambriniPGG_Late", 0, 0, 3, false);//Три дня чтобы прийти в тюрьму
			pchar.LambriniPGGInPrison = true;
			//sld = CharacterFromID("MaracaiboJailOff");
			//SaveOldDialog(sld);
			//sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			//sld.dialog.currentnode   = "LambriniPGG_1_14";
		break;

		case "LambriniPGG_1_14"://Запустить таймер в 10 дней на возврат диалога коменданту потом то же, что и в комменте выше
			dialog.text = "Vous ne le regretterez pas ! Seulement, je vous en prie, faites vite, je ne veux pas finir à la potence !";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			DialogExit();
			//RestoreOldDialog(npchar);
		break;

		case "LambriniPGG_2_1":
			LocatorReloadEnterDisable(pchar.location.from_sea, "reload1_back", true);
			LocatorReloadEnterDisable("Maracaibo_exittown", "reload1_back", true);
			chrDisableReloadToLocation = false;
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			dialog.text = GetSexPhrase("Mon sauveur !", "Ma sauveuse !")+" Sauf, bien sמr, si c'est vous qui m'avez fait mettre ici.";
			link.l1 = "Puisque c'est mon œuvre, il fallait bien que je répare ça. Alors, et ce trésor ?";
			link.l1.go = "LambriniPGG_2_2";
		break;

		case "LambriniPGG_2_2":
			dialog.text = "Mon coffre devrait encore être ici, à Maracaibo. Prenez une chambre à la taverne.";
			link.l1 = "א la taverne, va pour la taverne.";
			link.l1.go = "exit";

			PChar.quest.LambriniPGG_Tavern.win_condition.l1 = "location";
			PChar.quest.LambriniPGG_Tavern.win_condition.l1.location = "Maracaibo_tavern_upstairs";
			PChar.quest.LambriniPGG_Tavern.function = "LambriniPGG_Tavern";
		break;

		case "LambriniPGG_2_3":
			chrDisableReloadToLocation = true;
			dialog.text = "Et voici le coffre. Nous avons eu de la chance que les soldats n'aient pas eu le temps de le trouver.";
			link.l1 = "Bien, ouvrez-le. Voyons ce qu'il y a dedans.";
			link.l1.go = "LambriniPGG_2_4";
		break;
		case "LambriniPGG_2_4":
			GiveItem2Character(pchar, "Chest_quest");
			Log_Info("Vous avez reçu un étrange coffre");
			PlaySound("interface\important_item.wav");
			dialog.text = "Il y a un problème. Je n'ai pas la clé.";
			link.l1 = "Alors, à quoi me sert un coffre fermé à clé ?";
			link.l1.go = "LambriniPGG_2_5";
		break;
		case "LambriniPGG_2_5":
			TakeNItems(PChar, "Lockpick", 3);
			Log_Info("Vous avez reçu des crochets");
			PlaySound("interface\important_item.wav");
			dialog.text = "Vous pouvez l'ouvrir avec des crochets. Tenez, regardez. Je les ai achetés à Octavio Lambrini, mais je n'ai jamais eu le temps de m'en servir.";
			link.l1 = "D'accord, donnez-les-moi, je me débrouillerai.";
			link.l1.go = "LambriniPGG_2_6";
		break;
		case "LambriniPGG_2_6":
			dialog.text = "Bon, je crois que nous avons tous les deux rempli notre part du marché...";
			link.l1 = "Soit, vous pouvez partir.";
			link.l1.go = "LambriniPGG_2_7";
			link.l2 = "Puisque nous sommes dans une chambre, et qu'il y a un lit si moelleux... Et si nous testions sa solidité ?";
			link.l2.go = "LambriniPGG_2_8";
		break;
		case "LambriniPGG_2_7":
			PGG_ChangeRelation2MainCharacter(CharacterFromID(pchar.LambriniPGG), 30);
			chrDisableReloadToLocation = false;
			dialog.text = "Bon, je dois y aller. Maintenant, il faut récupérer notre navire d'une manière ou d'une autre ; on se reverra peut-être. Bonne chance à vous.";
			link.l1 = "א vous aussi.";
			link.l1.go = "LambriniPGG_2_10";

			string finalWords = ".";
			if (CheckAttribute(npchar, "bonusEnergy"))	finalWords = "Vous ne manquez pas de culot ! J'accepte.";

			AddQuestRecord("PDM_Clan_Lambrini", "11");
			CloseQuestHeader("PDM_Clan_Lambrini");
			pchar.questdata.ClanLambrini = 1;
			AddQuestUserData("PDM_Clan_Lambrini", "sName", GetFullName(npchar));
			AddQuestUserData("PDM_Clan_Lambrini", "sContinue", finalWords);

			DeleteAttribute(pchar, "LambriniPGGInPrison");
			SetTimerCondition("LambriniPGG_Freedom", 0, 0, 7, false);//Через неделю вернётся в строй
			//DeleteAttribute(npchar, "PGGAi.DontUpdate");
			//DeleteAttribute(npchar, "PGGAi.Task.SetSail");
			//DeleteAttribute(pchar, "LambriniPGG");

			LocatorReloadEnterDisable(pchar.location.from_sea, "reload1_back", false);
			LocatorReloadEnterDisable("Maracaibo_exittown", "reload1_back", false);
		break;
		case "LambriniPGG_2_8":
			dialog.text = "Vous ne manquez pas d'audace ! J'accepte.";
			link.l1 = "";
			link.l1.go = "LambriniPGG_2_9";
		break;
		case "LambriniPGG_2_9":
			PGG_ChangeRelation2MainCharacter(CharacterFromID(pchar.LambriniPGG), 200);
			pchar.GenQuest.BrothelCount = 0;
            AddCharacterExpToSkill(pchar, "Leadership", 100);
            AddCharacterExpToSkill(npchar, "Leadership", 100);
            AddCharacterExpToSkill(pchar, "Fencing", 100);// утрахала
            AddCharacterExpToSkill(npchar, "Fencing", 100);
            AddCharacterExpToSkill(pchar, "Pistol", 100);
            AddCharacterExpToSkill(npchar, "Pistol", 100);
            AddCharacterHealth(pchar, 10);
            AddCharacterHealth(npchar, 10);
   			AddDialogExitQuest("PlaySex_1");
			NextDiag.CurrentNode = "LambriniPGG_2_7";
			DialogExit();
		break;

		case "LambriniPGG_2_10":
			RestoreOldDialog(npchar);
			DialogExit();
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
		break;
	}
}
