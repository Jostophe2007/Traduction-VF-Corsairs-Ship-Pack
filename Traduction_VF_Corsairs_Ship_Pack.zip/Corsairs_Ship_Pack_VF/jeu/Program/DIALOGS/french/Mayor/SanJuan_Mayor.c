// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "RomanticQuest.MayorOk"))
			{
				link.l1 = "Señor gouverneur, je suis le capitaine " + GetFullName(pchar) + ". C'est moi qui ai épousé, dans l'église de la ville, la veuve Isabella Olevares, née de Valdez.";
				link.l1.go = "Romantic_1";
			}
		break;
		case "Romantic_1":
			dialog.text = "Vous tombez à pic, capitaine ! J'ai déjà envoyé le commandant vous chercher\n"+
				          "Eh bien, puisque vous êtes là, dites-moi, pour l'amour de Dieu, quel terrible massacre vous avez commis dans notre église !";
			link.l1 = "Señor " + npchar.lastname + ", je défendais simplement ma vie, mon honneur et Isabella, mon épouse...";
			link.l1.go = "Romantic_2";
		break;
		case "Romantic_2":
			dialog.text = "Voilà qui est très beau, capitaine. Mais j'attends justement les détails de ce qui a mis toute la ville en émoi !";
			link.l1 = "Señor gouverneur, le défunt mari d'Isabella, Salvator Olevares, était une sacrée canaille. Il traîne derrière lui toute une série de crimes odieux, parmi lesquels de nombreux meurtres...";
			link.l1.go = "Romantic_3";
		break;
		case "Romantic_3":
			dialog.text = "Je le sais. א son retour de Belize, oם elle était chez son cousin Fernandez, Isabella s'est présentée à ma réception et m'a tout raconté. C'est donc vous, son sauveur ?";
			link.l1 = "Oui, monsieur le gouverneur. Je suppose qu'il n'est pas surprenant qu'Isabella et moi ayons décidé de nous marier dès que ce fut possible. Cependant, ce salaud de Salvator, avant même de mourir, avait engagé toute une bande d'immondes crapules venues de toutes les Caraïbes pour nous éliminer.";
			link.l1.go = "Romantic_4";
		break;
		case "Romantic_4":
			dialog.text = "Et c'étaient ces mercenaires, dans l'église ?";
			link.l1 = "C'est exact, señor gouverneur. Je crois avoir rendu un grand service à toute la région en tuant autant de bandits d'un coup...";
			link.l1.go = "Romantic_5";
		break;
		case "Romantic_5":
			dialog.text = "Sans aucun doute, capitaine, c'est bien le cas. Eh bien, maintenant, tout est assez clair pour moi. Je suppose que nous ferons procéder à une nouvelle consécration de l'église aux frais de la ville.";
			link.l1 = "Señor gouverneur, merci infiniment de votre compréhension...";
			link.l1.go = "Romantic_6";
		break;
		case "Romantic_6":
			dialog.text = "C'est mon devoir de comprendre ce genre d'affaires, capitaine ! Eh bien, je vous souhaite beaucoup de bonheur avec votre épouse. Félicitations.";
			link.l1 = "Merci, monsieur le gouverneur !";
			link.l1.go = "exit";
			AddQuestRecord("Romantic_Line", "27");
			DeleteAttribute(pchar, "RomanticQuest.MayorOk");
			LocatorReloadEnterDisable("SanJuan_town", "houseSp6", false); //и только теперь открываем дверь в дом Изабеллы
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

