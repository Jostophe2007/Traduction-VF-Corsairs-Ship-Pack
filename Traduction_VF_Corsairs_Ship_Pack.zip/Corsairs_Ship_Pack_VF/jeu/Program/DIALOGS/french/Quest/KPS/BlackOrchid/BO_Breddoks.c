// Gregg: Will Breddoks and Kharpich - «Чёрная Орхидея», глава 7 «Маленький ублюдок».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Maudite frégate.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(sans lever la tête)... Asseyez-vous, capitaine. Buvez avec moi à la mémoire de mon équipage.";
			link.l1 = "Que leur est-il arrivé ?";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelInPuertoPrincipeTalk");
		break;

		case "2":
			dialog.text = "Inutile de le raconter. Vous ne le croirez pas. Ici, plus personne n'y croit.";
			link.l1 = "Moi, je le croirai.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Nous avions jeté l'ancre dans la baie et nous nous préparions à descendre à terre. Et puis, tout est devenu noir. Pas comme pendant un grain, non : d'un coup, comme si on avait jeté quelque chose sur nous. Je me suis plaqué contre le bastingage, j'ai regardé, et je ne voyais même plus mes propres mains.";
			link.l1 = "Mais vous avez entendu.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "J'ai entendu. Un homme ne pousse ce cri qu'une fois dans sa vie, capitaine, et ensuite, on ne le confond plus jamais avec rien d'autre. Il venait de partout. De tout le pont à la fois.";
			link.l1 = "Et vous avez sauté.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(un long silence)... J'ai sauté. La dernière chose que j'ai entendue avant de toucher l'eau, c'est une lame qui m'a frכlé l'oreille. J'ai nagé vers le rivage en m'attendant tout le long à être rattrapé.";
			link.l1 = "Et au matin ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Au matin, je suis sorti sur la plage et j'ai regardé mon navire. Il était là, vide. Pas de corps, pas de sang, pas une chaloupe à la mer. Le jour même, je l'ai vendu au capitaine Kharpich pour une bouchée de pain, sans marchander.";
			link.l1 = "Oם est Kharpich, maintenant ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Aucune idée. Il a levé l'ancre hier soir. Dépêchez-vous, et vous le rattraperez.";
			if (sti(PChar.money) >= BO_SM_WAKE_PRICE)
			{
				link.l1 = "Je boirais volontiers avec vous à la mémoire de vos hommes, mais je dois partir. Voici mille piastres, buvez à leur mémoire pour moi.";
				link.l1.go = "8";
			}
			else
			{
				link.l1 = "Je boirais volontiers avec vous à la mémoire de vos hommes, mais je dois partir.";
				link.l1.go = "9";
			}
			AddDialogExitQuestFunction("SmallMongrelFindKharpich");
		break;

		case "8":
			AddMoneyToCharacter(PChar, -BO_SM_WAKE_PRICE);
			dialog.text = "...(il regarde la pièce, puis vous)... Je le ferai. א tous les trente.";
			link.l1 = "Adieu, Breddoks.";
			link.l1.go = "exit";
		break;

		case "9":
			dialog.text = "Allez, capitaine. Et ne restez pas à bord de ce navire la nuit, vous m'entendez ? Ni vous, ni vos gens.";
			link.l1 = "Je vous entends.";
			link.l1.go = "exit";
		break;

		case "20":
			dialog.text = "Que diable. Le combat n'est pas encore fini.";
			link.l1 = "Je veux ton navire, Kharpich. Toi, je suis prêt à te laisser partir.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Tu l'auras sur mon cadavre. Et ne prends pas cet air satisfait. Tu l'auras avec tout ce qu'il y a à bord.";
			link.l1 = "Sur ton cadavre, alors.";
			link.l1.go = "exit";
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
