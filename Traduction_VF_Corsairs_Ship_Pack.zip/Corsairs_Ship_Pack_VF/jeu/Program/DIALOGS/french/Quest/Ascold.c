// Аскольд
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Tichingitu_11":
			AddMoneyToCharacter(pchar, -10000);
			dialog.text = "Parfait ! Voilà ce qu'il fallait ! Maintenant, je vais écrire un mot et y apposer mon sceau, attendez un peu... Voilà. Donnez ceci au commandant, et vous pourrez prendre votre Indien. Mais pourquoi vous en avez besoin, je n'en sais rien. א part pour l'exhiber dans les foires contre de l'argent, ha ha !";
			link.l1 = "Dieu voit tout, Askold. Sauver la vie d'un homme, c'est une bonne chose.";
			npchar.quest.Tichingitu = "paid"
			link.l1.go = "Tichingitu_12";
		break;

		if (CheckAttribute(pchar, "questTemp.Tichingitu") && pchar.questTemp.Tichingitu == "ascold")
		{
			dialog.text = "Alors, qu'en dites-vous ? Vous avez vu cet épouvantail indien ?";
			link.l1 = "Oui, je l'ai vu... C'est pour ça que je reviens vous voir.";
			link.l1.go = "Tichingitu_7";
			if (!CheckAttribute(npchar, "quest.Tichingitu"))
			{
				npchar.quest.Tichingitu = true;
				break;
			}
		}
		if (CheckAttribute(pchar, "questTemp.Tichingitu") && pchar.questTemp.Tichingitu == "money")
		{
			dialog.text = "Oh, c'est encore vous ! Eh bien, vous avez apporté"+GetSexPhrase("","")+" l'argent pour l'Indien ?";
			if (sti(pchar.money) >= 10000)
			{
				link.l1 = "Oui. Tenez.";
				link.l1.go = "Tichingitu_11";
			}
			if (CheckAttribute(npchar, "quest.Tichingitu") && npchar.quest.Tichingitu != "paid")
			{
				link.l2 = "Non, je ne l'ai pas encore réuni.";
				link.l2.go = "exit";
				break;
			}
		}
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
            if (npchar.quest.meeting == "0")
            {
            	dialog.text = "Salutations. Je m'appelle Askold. Et à qui ai-je l'honneur de parler ?";
        		link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
        		link.l1.go = "Step_1";
                npchar.quest.meeting = "1";
            }
            else
            {
				
            	dialog.text = "Je n'aime pas que des gens que je ne connais pas me dérangent.";
        		link.l1 = "Je comprends, je m'en vais déjà...";
        		link.l1.go = "exit";
        		link.l2 = "Vous êtes grossier, monsieur ?";
        		link.l2.go = "Step_3";
                NextDiag.TempNode = "First time";
            }
		break;

 		case "Step_1":
        	dialog.text = "Qui êtes-vous, et que faites-vous ?";
    		link.l1 = "Je suis corsaire.";
    		link.l1.go = "Step_2";
		break;

 		case "Step_2":
        	dialog.text = "וcoutez, corsaire...";
    		link.l1 = "Oui ?";
    		link.l1.go = "First time";
		break;

 		case "Step_3":
            if (npchar.quest.meeting == "1")
            {
            	dialog.text = "Ooh, vous n'êtes pas un simple corsaire, vous êtes un corsaire redoutable... Dehors !";
        		link.l1 = "...";
        		npchar.quest.meeting = "2";
            }
            else
            {
            	dialog.text = RandPhraseSimple("Voilà de nouveau le redoutable et méchant corsaire qui daigne rompre le silence ?! Recommençons l'évacuation du corps...", "Encore à bouder... Il est temps d'agir.");
        		link.l1 = RandPhraseSimple("Oui, maintenant, vous me plaisez...", "Voyons qui jettera qui hors de la maison, cette fois...");
            }
            link.l1.go = "Step_4";
		break;

 		case "Step_4":
            DoReloadCharacterToLocation("BasTer_town", "reload", "houseSp1");
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

 		case "HaveRecomendation":
			sld = characterFromId(pchar.questTemp.Ascold.TraderId);
            if (npchar.quest.meeting == "0")
            {
            	dialog.text = "Salutations. Je m'appelle Askold. Et à qui ai-je l'honneur...";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Et je viens de la part de " + GetFullName(sld) + ", le propriétaire du magasin qui se trouve à " + XI_ConvertString("Colony" + sld.City + "Voc") + ".";
                npchar.quest.meeting = "1";
            }
            else
            {
            	dialog.text = "Voilà que réapparaît à l'horizon "+ GetSexPhrase("notre redoutable corsaire","notre redoutable corsaire") +". Que vous faut-il cette fois ?";
        		link.l1 = "Cette fois, je viens de la part de " + GetFullName(sld) + ", le propriétaire du magasin qui se trouve à " + XI_ConvertString("Colony" + sld.City + "Voc") + ".";
            }
            link.l1.go = "Step_5";
		break;

 		case "Step_5":
			sld = characterFromId(pchar.questTemp.Ascold.TraderId);
        	dialog.text = "Hé, je connais cette personne. Bon, entrez, asseyez-vous, buvons une vodka.. "+
                          "(en confidence) Dans ces parages, la vodka russe, c'est une denrée rare. Le rhum jamaïcain, à la rigueur, on en trouve, mais comparé à la vodka, le rhum, c'est de la pisse de requin\n"+
                          "Bref, dites-moi, quelle affaire vous amène ?";
    		link.l1 = sld.lastname + " m'a dit que vous cherchiez de la poudre de momie. J'en ai.";
    		link.l1.go = "Step_6";
		break;

 		case "Step_6":
        	dialog.text = "Très bien. Je paie 30 000 pour cette poudre.";
    		link.l1 = "Bon prix. Marché conclu.";
            if (CheckCharacterItem(pchar, "Powder_mummie"))
            {
        		link.l1.go = "Step_7";
        		TakeItemFromCharacter(pchar, "Powder_mummie");
        		AddMoneyToCharacter(pchar, 30000);
            }
            else
            {
        		link.l1.go = "No_Powder";
            }
		break;

 		case "No_Powder":
        	dialog.text = "Hé, "+ GetSexPhrase("frère","sœur") +", tu te moques de moi ! Tu n'as pas de poudre. Je ne veux plus connaître les gens qui essaient de me tromper.. "+
                          "Fichez le camp d'ici !";
    		link.l1 = "Qu'est-ce que vous racontez ! Je plaisantais ! Je n'en avais aucune idée...";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
		break;

 		case "Step_7":
        	dialog.text = "L'affaire est faite, maintenant, on peut boire...";
    		link.l1 = "Non, je ne boirai rien. Dites-moi plutכt pourquoi vous avez besoin de ce truc ? Je me suis creusé la tête bien des fois là-dessus, sans comprendre. Une chose absolument inutile et répugnante.";
    		link.l1.go = "Step_8";
		break;

 		case "Step_8":
        	dialog.text = "Eh bien, c'est vite dit. Cette poudre et d'autres objets du culte indien sont commandés par le célèbre savant Pierre de La Fontaine, en Europe.. "+
                          "Je suis ici en tant que son homme de confiance. En principe, ça me convient tout à fait. De La Fontaine paie le loyer de la maison et ma pension.. "+
                          "Et pour chaque objet de ce genre que je trouve ici sur commande, il paie très, très bien.";
    		link.l1 = "Compris.";
    		link.l1.go = "Step_9";
		break;

 		case "Step_9":
        	dialog.text = "וcoutez, puisque la chanson a pris ce tour et que nous avons travaillé ensemble, je vous propose un autre travail.. "+
                          "Je viens de recevoir une nouvelle commande de trois artefacts aztèques.";
    		link.l1 = "J'accepte.";
    		link.l1.go = "Step_10";
    		link.l2 = "Non, je ne le prends pas. J'ai d'autres choses à faire.";
    		link.l2.go = "No_Work";
		break;

 		case "No_Work":
        	dialog.text = "Ah oui ? Je n'aime pas qu'on me refuse quelque chose, je ne veux plus connaître ces gens-là. Alors, dehors, hors de ma maison !";
    		link.l1 = "Hé, hé ! Qu'est-ce que vous faites ?!!";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
    		group_DeleteGroup("Ascold_Spa_Attack");
    		DeleteAttribute(PChar, "questTemp.Ascold.Ship");
		break;

 		case "Step_10":
        	dialog.text = "D'accord. Maintenant, écoutez ce qu'il me faut trouver.. "+
                          "Il me faut une statuette de Tlaloc, le dieu aztèque de la pluie et du tonnerre, un vase cérémoniel de la tribu des Purépechas et un couteau cérémoniel tumi.";
    		link.l1 = "Je comprends. Bon, je vais chercher. Je rassemblerai les trois objets et je viendrai chez vous. Mais il me semble que quelque chose d'autre vous tracasse, non ?";
    		link.l1.go = "Tichingitu_1";
    	    pchar.questTemp.Ascold = "SeekThreeObject";
            AddQuestRecord("Ascold", "3");
			AddQuestUserData("Ascold", "sSex", GetSexPhrase("", "e"));
		break;

		case "Tichingitu_1":
			dialog.text = "Vous avez un flair étonnant. Bon, je vais vous le dire. Il y a une semaine, plusieurs bandits se sont introduits chez moi. Et oם regardaient les gardes...";
			link.l1 = "Partout, apparemment, sauf là oם il fallait. Et ensuite ?";
			link.l1.go = "Tichingitu_2";
		break;

		case "Tichingitu_2":
			dialog.text = "Eh bien, j'ai pris le gourdin et je les ai tabassés. Ils se sont enfuis de justesse. Oui, mais quelle attaque : ceux qui étaient entrés ont détourné mon attention. Un voleur est monté au premier étage et a emporté un coffre plein d'objets de valeur, que la cupidité le déchire !";
			link.l1 = "Et vous ne l'avez pas arrêté ?";
			link.l1.go = "Tichingitu_3";
		break;

		case "Tichingitu_3":
			dialog.text = "Pensez donc, il s'est enfui avec ses complices dans la jungle. Et là-bas, on ne les retrouvera plus. Bon, on n'y peut rien. Bien sמr, j'ai engagé des mercenaires pour fouiller l'île, mais les brigands et le voleur sont déjà loin.";
			link.l1 = "דa a l'air très désagréable. On peut dire que c'est un malheur...";
			link.l1.go = "Tichingitu_4";
		break;

		case "Tichingitu_4":
			dialog.text = "Et ce vol n'est pas tout. Pas plus tard que l'autre jour, imaginez, un voleur s'est de nouveau introduit dans ma chambre. C'en est trop ! Mais cette fois, il ne m'a pas échappé : je l'ai attrapé, je lui ai donné une bonne raclée et je l'ai livré au commandant. Je pense qu'on va bientכt le pendre. Et c'est bien fait pour lui !";
			link.l1 = "Vous ne trouvez pas que vous avez exagéré ?";
			link.l1.go = "Tichingitu_5";
		break;

		case "Tichingitu_5":
			dialog.text = "Peut-être. Il avait l'air plutכt émacié. On voit bien que c'est le désespoir complet. Et il ne s'intéressait qu'aux pièces. Mais comprenez-moi aussi... Vous imaginez, un épouvantail qui s'introduit dans ma chambre et fouille dans mes coffres. Un Indien de quelque jungle reculée, une vraie curiosité. Tout attifé, peinturluré... Vous pouvez aller dans nos casemates voir ce bouffon déguisé, si ça vous intéresse, tant qu'il est encore en vie.";
			link.l1 = "Hum... J'irai peut-être y jeter un œil.";
			link.l1.go = "Tichingitu_6";
		break;

		case "Tichingitu_6":
			dialog.text = "Allez-y, allez-y, regardez les curiosités ambulantes du coin...";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "ResultOfSeek";
			pchar.questTemp.Tichingitu = "true";
			AddDialogExitQuestFunction("SetTichingituJail");
			SetFunctionTimerCondition("FreeTichingituOver", 0, 0, 10, false);
		break;

		case "Tichingitu_7":
			dialog.text = "Eh bien, quoi encore ?";
			link.l1 = "Askold, j'ai parlé avec cet Indien. Et je vais intercéder pour lui. Ce malheureux voulait juste manger...";
			link.l1.go = "Tichingitu_8";
		break;

		case "Tichingitu_8":
			dialog.text = "On peut le comprendre. Alors, vous voulez le sauver ?";
			link.l1 = "Ils vont l'exécuter, mais il pourrait m'être utile sur le navire...";
			link.l1.go = "Tichingitu_9";
		break;

		case "Tichingitu_9":
			dialog.text = "Puisque c'est comme ça, je pense que vous pouvez le racheter. Une compensation de 10 000 piastres me satisfera.";
			if (sti(pchar.money) >= 10000)
			{
				link.l1 = "D'accord, voici l'argent.";
				link.l1.go = "Tichingitu_11";
			}
			link.l2 = "Je reviendrai sans doute plus tard, alors.";
			link.l2.go = "Tichingitu_10";
		break;

		case "Tichingitu_10":
			dialog.text = "Et dépêchez-vous ! Dans dix jours, il ne leur servira plus à rien...";
			link.l1 = "J'en prends note. Au revoir !";
			link.l1.go = "exit";
			pchar.questTemp.Tichingitu = "money";
		break;

		case "Tichingitu_12":
			GiveItem2Character(pchar, "letter_A");
			PlaySound("interface\important_item.wav");
			dialog.text = "C'est une question délicate. Et si vous sauviez un assassin ou un violeur ? Vous prendrez bien un peu de vodka ? Ensuite, allez chez le commandant avant qu'on ne pende votre ami à la peau rouge...";
			link.l1 = "Soit, vous m'avez convaincu.";
			link.l1.go = "exit_vodka";
			pchar.questTemp.Tichingitu = "pay";
		break;

		case "exit_vodka":
			LAi_MethodDelay("FrameAscoldVodka",0.1);
			DialogExit();
			AddQuestRecord("Ascold", "3_3");
		break;

 		case "ResultOfSeek":
        	dialog.text = "Vous avez trouvé les babioles indiennes ? Il me les faut toutes les trois en même temps, inutile de les apporter une par une.";
    		link.l1 = "Pas encore, mais je m'en occupe.";
    		link.l1.go = "exit";
    		NextDiag.TempNode = "ResultOfSeek";
            if (CheckCharacterItem(pchar, "indian19") && CheckCharacterItem(pchar, "indian20") && CheckCharacterItem(pchar, "indian21"))
            {
                link.l2 = "Oui, je les ai trouvées. Et oם est mon argent ?";
                link.l2.go = "Step_11";
            }
		break;

 		case "Step_11":
        	dialog.text = "Hé, je suis prêt à payer 30 000 pour chaque objet. En tout, 90 000 pièces. D'accord ?";
            link.l1 = "Le prix me convient. Marché conclu.";
            if (pchar.questTemp.Ascold == "SoughtThreeObject")
            {
               link.l1 = "Si vous saviez, Askold, combien j'ai payé pour ces artefacts... Mais je comprends qu'il est tout simplement irréaliste d'exiger de vous un remboursement, vous m'offrez déjà un prix six fois plus élevé... J'accepte.";
            }
    		link.l1.go = "Step_12";
            link.l2 = "Non, donnez-moi plus d'argent.";
    		link.l2.go = "WantMoreMoney";
		break;

 		case "WantMoreMoney":
        	dialog.text = "דa alors. On dirait que je me suis trompé sur votre compte : vous êtes "+ GetSexPhrase("un homme cupide au-delà de toute mesure","une fille cupide au-delà de toute mesure") +". Ce genre de personnes ne sont rien pour moi, je ne les connais pas. Je ne veux plus vous connaître.. "+
                          "Dehors !";
        	link.l1 = "Hé, Askold, attendez ! Nous sommes des gens normaux, marchandons, mettons-nous d'accord...";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
		break;

 		case "Step_12":
        	dialog.text = "Voici donc vos 90 000, et les objets sont maintenant à nous.";
        	link.l1 = "Prenez.";
    		link.l1.go = "Step_13";
		break;

 		case "Step_13":
        	dialog.text = "וcoutez, si vous voulez, repassez chez moi dans un mois ou deux. Il y aura peut-être un autre travail.";
    		link.l1 = "Je passerai, je viendrai vous voir sans faute. Vous ne proposez pas un travail poussiéreux, et le profit est correct.";
    		link.l1.go = "exit";
    		TakeItemFromCharacter(pchar, "indian19");
    		TakeItemFromCharacter(pchar, "indian20");
    		TakeItemFromCharacter(pchar, "indian21");
    		AddMoneyToCharacter(pchar, 90000);
			pchar.questTemp.Ascold = "TakenThreeObject";
    		SaveCurrentQuestDateParam("questTemp.Ascold");
    		NextDiag.TempNode = "WalkTwoMounth";
    		AddQuestRecord("Ascold", "4");
		break;

		case "WalkTwoMounth":
		    if (GetQuestPastDayParam("questTemp.Ascold") > 62)
		    {
            	dialog.text = "Oh, enfin ! Je vous attendais. J'ai besoin de vos services, " + GetFullName(pchar) + ".";
            	link.l1 = "Que faut-il trouver cette fois ?";
        		link.l1.go = "Step_14";
		    }
            else
            {
            	dialog.text = "Oh, qui vois-je ?! "+ GetSexPhrase("Mon ami","Mon amie") +", " + GetFullName(pchar) + ", content de vous voir. Si c'est pour du travail, je n'ai rien à vous proposer pour l'instant, je suis moi-même sans le sou. Repassez un peu plus tard.";
            	link.l1 = "D'accord, Askold. Si je passe dans le coin, je viendrai vous voir.";
        		link.l1.go = "exit";
        		NextDiag.TempNode = "WalkTwoMounth";
            }
		break;

 		case "Step_14":
        	dialog.text = "Vous savez, cette fois, il ne s'agit pas de recherches, ce sera une tâche plus sérieuse.";
        	link.l1 = "Ooh, ça me donne des frissons... Je sens qu'il y a beaucoup d'argent ! Allez, exposez le problème.";
    		link.l1.go = "Step_15";
		break;

 		case "Step_15":
        	dialog.text = "Le problème est le suivant. Les Espagnols, qui exterminent sans pitié les Indiens du continent et détruisent leur patrimoine culturel depuis des centaines d'années, se sont soudain mis à collectionner les objets de cette même culture indienne.. "+
                          "Le fait est qu'à la cour de Marianne, on ne sait d'oם, est apparue une étrange mode pour les objets de culte indiens. Et maintenant, les Espagnols ratissent partout et rassemblent des artefacts dont j'ai désespérément besoin. Et ils expédient ce qu'ils trouvent vers l'Ancien Monde. Mes affaires en souffrent, et je ne suis pas d'accord avec ça.. "+
                          "Bref, j'ai réussi à apprendre qu'un gros lot d'objets de culte aztèques d'une valeur inouïe a été rassemblé à La Havane. Je veux mettre la main sur ces objets ; il est clair que je ne pourrai pas tout prendre, mais au moins quelque chose.. "+
                          "Et puis, au fait... Je veux obtenir l'inventaire des marchandises indiennes rassemblées par les Espagnols. De La Fontaine sera très intéressé de le voir.";
        	link.l1 = "Et c'est tout ? Pas de problème. Vous aurez tout. Vous êtes sמr qu'il existe un tel inventaire ?";
    		link.l1.go = "Step_16";
        	link.l2 = "וcoutez, ne le prenez pas mal, mais je ne peux pas le faire en ce moment. Je n'ai pas le temps.";
    		link.l2.go = "No_Work";
		break;

 		case "Step_16":
        	dialog.text = "Oui, tout à fait. Mes amis me l'ont soufflé, de source pas inconnue... Un inventaire est joint à la cargaison : là oם sont les artefacts, il y a l'inventaire.";
        	link.l1 = "Compris. Bon, je m'y mets. Attendez-moi, pour ainsi dire, et je reviendrai.";
    		link.l1.go = "exit";
    		SaveCurrentQuestDateParam("questTemp.Ascold");
    		NextDiag.TempNode = "AfterManowarsBattle";
    		pchar.questTemp.Ascold = "ToHavanna";
    		AddQuestRecord("Ascold", "5");
		break;

 		case "AfterManowarsBattle":
        	dialog.text = "Vous avez fait quelque chose ?";
        	link.l1 = "Pas encore, mais je m'en occupe.";
    		link.l1.go = "exit";
        	link.l2 = "Je n'ai plus envie de m'occuper de vos problèmes. Désolé.";
    		link.l2.go = "No_Work";
            if (pchar.questTemp.Ascold == "SeekInformatorHavanna")
            {
             	link.l1 = "וcoutez, lors de notre dernière conversation, vous avez parlé de votre ami qui vous a soufflé l'existence de la liste que je cherche.";
        		link.l1.go = "Step_17";
            }
            if (pchar.questTemp.Ascold == "ReciveInformationManowar")
            {
             	link.l1 = "Askold ! J'ai trouvé votre ami informateur ! C'est un officier espagnol nommé Fernando Gonzalez, à Santiago. D'ailleurs, il vous salue...";
        		link.l1.go = "Step_20";
            }
            if (pchar.questTemp.Ascold == "ILookedThisAss" && !CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
             	link.l1 = "Askold ! Il y a une escadre espagnole de six navires, avec le vaisseau de ligne en tête !!!";
        		link.l1.go = "Step_24";
            }
            if (pchar.questTemp.Ascold == "ILookedThisAss" && CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
             	link.l1 = "Askold ! Vous avez la liste, mais il reste des navires qui ne sont pas coulés.";
        		link.l1.go = "Step_25";
            }
            if (pchar.questTemp.Ascold == "2ILookedThisAss" && CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
             	link.l1 = "Askold ! Vous avez la liste, mais il reste des navires qui ne sont pas coulés.";
        		link.l1.go = "Step_25";
            }
            if (pchar.questTemp.Ascold == "Ascold_ManowarsDead" && !CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
             	link.l1 = "J'ai coulé tous les navires, mais je n'ai pas pu trouver l'inventaire.";
        		link.l1.go = "NoFoundList";
            }
    		if (CheckCharacterItem(pchar, "ShipsJournal") && pchar.questTemp.Ascold == "ILookedThisAss")
    		{
            	link.l1 = "Oui, que le diable m'emporte ! J'ai traversé les sept cercles de l'enfer, mais j'ai la liste pour vous. La voici.";
        		link.l1.go = "Step_26";
    		}
    		if (CheckCharacterItem(pchar, "ShipsJournal") && pchar.questTemp.Ascold == "2ILookedThisAss")
    		{
            	link.l1 = "Oui, que le diable m'emporte ! J'ai traversé les sept cercles de l'enfer, mais j'ai obtenu cette liste pour vous. La voici.";
        		link.l1.go = "Step_26";
    		}
            if (CheckCharacterItem(pchar, "ShipsJournal") && pchar.questTemp.Ascold == "Ascold_ManowarsDead")
            {
             	link.l1 = "J'ai détruit les navires espagnols, et j'ai aussi l'inventaire.";
        		link.l1.go = "ManowarGoodWork";
            }
            if (pchar.questTemp.Ascold == "Ascold_ManowarsDead" && CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
             	link.l1 = "J'ai envoyé l'escadre par le fond !";
        		link.l1.go = "ManowarGoodWork";
            }
			if (pchar.questTemp.Ascold == "Ascold_ManowarsNoDead")
            {
             	link.l1 = "וcoutez, je n'ai pas réussi à couler l'escadre espagnole. Et je n'ai trouvé aucune expédition près du temple.";
        		link.l1.go = "ManowarNoGoodWork";
            }
		break;

 		case "Step_17":
        	dialog.text = "Et alors ?";
        	link.l1 = "J'ai besoin de votre aide : le fait est que j'ai eu un problème à La Havane. Je n'arrive pas à savoir oם est parti le vaisseau de ligne sur lequel on a chargé les artefacts indiens. Que votre ami m'aide.";
    		link.l1.go = "Step_18";
		break;

 		case "Step_18":
        	dialog.text = "Non, ça ne va pas. Je ne vais pas parler de mes relations dans toutes les Caraïbes.";
        	link.l1 = "Mais j'agis dans votre intérêt, après tout !!!";
    		link.l1.go = "Step_19";
		break;

 		case "Step_19":
        	dialog.text = "C'est vrai, mais agissez par vous-même. Ne comptez pas sur mon aide.";
        	link.l1 = "Eh bien, merci, mon ami Askold...";
    		link.l1.go = "exit";
    		pchar.questTemp.Ascold = "2SeekInformatorHavanna";
    		NextDiag.TempNode = "AfterManowarsBattle";
		break;

 		case "Step_20":
        	dialog.text = "Nous arriverons bien à communiquer sans votre intermédiaire... Vous avez trouvé quelque chose ?";
        	link.l1 = "Oui, les Espagnols ont trouvé un temple indien près de la baie d'Amatique, au sud de Belize, et maintenant, toute une expédition y travaille. Et des navires chargés arrivent à cet endroit de tout le Nouveau Monde.";
    		link.l1.go = "Step_21";
		break;

 		case "Step_21":
        	dialog.text = "Pourquoi ?";
        	link.l1 = "Je suppose qu'ils vont piller le temple indien et repartir en Espagne avec tout ça.";
    		link.l1.go = "Step_22";
		break;

 		case "Step_22":
        	dialog.text = "Triste nouvelle. Alors, j'ai une requête pour vous : vous devez détruire tous les Espagnols qui se trouvent près de la baie d'Amatique. Tous les navires doivent sombrer, et l'expédition elle-même, au temple, doit être anéantie.. "+
                          "Et il me faut l'inventaire des Espagnols.";
        	link.l1 = "Je suis prêt. Je peux commencer tout de suite.";
    		link.l1.go = "Step_23";
        	link.l2 = "Vous n'en demandez pas trop, l'ami ? Cherchez un imbécile ailleurs.";
    		link.l2.go = "No_Work";
		break;

 		case "Step_23":
        	dialog.text = "C'est bien, je ne sais même pas comment vous remercier pour votre aide...";
        	link.l1 = "Nous réglerons ça plus tard, mon ami Askold.";
    		link.l1.go = "exit";
    		AddQuestRecord("Ascold", "8");
    		pchar.questTemp.Ascold = "IMustKillAll";
    		NextDiag.TempNode = "AfterManowarsBattle";
		break;

 		case "Step_24":
        	dialog.text = "Très bien, ça devrait vous faire plaisir. Vous êtes un corsaire ou une chiffe molle ? Détruisez tous les Espagnols et rapportez-moi ce maudit inventaire.";
        	link.l1 = "Oui, bien sמr. Je vais le faire. Vous aurez l'inventaire, et les Espagnols seront détruits.";
    		link.l1.go = "Step_25";
            link.l2 = "Ce sera sans moi. Cherchez un imbécile !";
    		link.l2.go = "No_Work";
		break;

 		case "Step_25":
        	dialog.text = "Eh bien, qu'est-ce que vous attendez ! Allez les détruire.";
        	link.l1 = "Je suis en route.";
    		link.l1.go = "exit";
    		pchar.questTemp.Ascold = "2ILookedThisAss";
    		NextDiag.TempNode = "AfterManowarsBattle";
		break;

 		case "NoFoundList":
        	dialog.text = "Il fallait envoyer une myriade d'Espagnols rejoindre leurs ancêtres, et vous n'avez trouvé aucune liste. Je ne traite pas avec des incapables pareils.. "+
                      "Fichez le camp d'ici !";
    		link.l1 = "Ouais, et ça, après tout ce que j'ai enduré à cause de vous...";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
		break;

 		case "Step_26":
        	dialog.text = "La liste, c'est bien, vous êtes bon. Mais il faut que vous couliez tous les navires des Espagnols, et que vous nettoyiez aussi le temple. Personne ne doit en sortir vivant.";
        	link.l1 = "Donnez-moi une bonne raison qui m'intéresserait...";
    		link.l1.go = "Step_27";
            link.l2 = "Vous m'excuserez, bien sמr, mais je ne veux pas massacrer ces pauvres Espagnols.";
    		link.l2.go = "No_Work";
            link.l3 = "Askold, j'ai besoin d'argent. Après tout, je vous ai livré la liste. J'aimerais recevoir une récompense.";
    		link.l3.go = "WantMoreMoney";
            BackItemDescribe("ShipsJournal");
            TakeItemFromCharacter(pchar, "ShipsJournal");
            pchar.questTemp.Ascold.list = 1;
		break;

 		case "Step_27":
        	dialog.text = "J'attends l'argent de mon mécène, Pierre de La Fontaine. Patientez, et je vous paierai intégralement.";
        	link.l1 = "D'accord, je vais détruire les Espagnols. J'espère que le montant de la récompense me satisfera.";
    		link.l1.go = "exit";
            AddQuestRecord("Ascold", "10");
	    	AddQuestUserData("Ascold", "sSex", GetSexPhrase("", "e"));
		break;

 		case "ManowarGoodWork":
        	dialog.text = "Vous n'avez pas détruit les Espagnols sur l'île même. Tous les Espagnols qui travaillent au temple doivent être éliminés.";
        	link.l1 = "D'accord, je vais finir le travail.";
    		link.l1.go = "exit";
            link.l2 = "Vous m'excuserez, bien sמr, mais je ne veux plus massacrer ces pauvres Espagnols.";
    		link.l2.go = "Step_28";
    		NextDiag.TempNode = "ManowarGoodWork";
		break;

		case "ManowarNoGoodWork":
        	dialog.text = "Et pourtant, il le faut ! Et ça se dit corsaire. Je ne traite pas avec des incapables pareils.. "+
                      "Fichez le camp d'ici !";
    		link.l1 = "Ouais, et ça, après tout ce que j'ai enduré à cause de vous...";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
		break;

 		case "Step_28":
        	dialog.text = "Vous allez abandonner l'affaire à mi-chemin ?";
        	link.l1 = "Ouais, je laisse tomber, parce que vous m'avez eu.";
    		link.l1.go = "Step_4";
    		NextDiag.TempNode = "First time";
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "BreakeQuest";
    		pchar.quest.Ascold_FightNearTemple.over = "yes";
		break;

 		case "Ascold_KilledTemple":
        	dialog.text = "Alors, vous êtes revenu. Qu'avez-vous de bon à m'annoncer ?";
        	link.l1 = "Askold, l'expédition espagnole au temple inca a été entièrement détruite. Mais je n'ai trouvé ce maudit inventaire nulle part.";
    		link.l1.go = "NoFoundList";
            if (CheckCharacterItem(pchar, "ShipsJournal") || CheckAttribute(PChar, "questTemp.Ascold.List"))
            {
            	link.l1 = "Askold, l'expédition espagnole au temple inca a été entièrement détruite.";
        		link.l1.go = "Step_29";
                BackItemDescribe("ShipsJournal");
                TakeItemFromCharacter(pchar, "ShipsJournal");
                DeleteAttribute(PChar, "questTemp.Ascold.List");
            }
		break;

 		case "Step_29":
        	dialog.text = "Parfait ! Je savais que je pouvais compter sur vous.";
        	link.l1 = "Je veux parler de la récompense.";
    		link.l1.go = "Step_30";
		break;

 		case "Step_30":
        	dialog.text = "Oui, bien sמr... וcoutez, je n'ai rien pour vous payer, je n'ai pas encore reçu l'argent de mon mécène. Il faut attendre un peu.";
        	link.l1 = "Oh, je n'ai pas de mots... Si vous saviez ce que j'ai enduré...";
    		link.l1.go = "Step_31";
		break;

 		case "Step_31":
        	dialog.text = "Je comprends, mais je n'ai tout simplement pas l'argent. Je dois envoyer en France l'inventaire que vous avez saisi. J'espère que ça accélérera les choses. Passez me voir de temps en temps...";
        	link.l1 = "Eh bien, comme vous voudrez. Je viendrai vous voir dès que possible.";
    		link.l1.go = "exit";
    		NextDiag.TempNode = "Mummie_begin";
    		SaveCurrentQuestDateParam("questTemp.Ascold");
    		AddQuestRecord("Ascold", "12");
	        AddQuestUserData("Ascold", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Ascold", "sSex1", GetSexPhrase("", "e"));
		break;

 		case "Mummie_begin":
        	dialog.text = "Ravi de vous voir, "+ GetFullName(pchar) + ". Mais je n'ai pas encore de nouvelles. L'argent n'est pas encore arrivé...";
        	link.l1 = "Dommage... Bon, attendons.";
    		link.l1.go = "exit";
    		NextDiag.TempNode = "Mummie_begin";
		    if (GetQuestPastDayParam("questTemp.Ascold") > 40)
            {
            	dialog.text = "Oh, qui vois-je, "+ GetSexPhrase("mon ami","mon amie") +" "+ GetFullName(pchar) + "...";
            	link.l1 = "Des nouvelles ?";
        		link.l1.go = "Step_31A";
            }
		break;

 		case "Step_31A":
        	dialog.text = "Oui, mais elles ne vont pas vous plaire. Le fait est que j'ai reçu des nouvelles de La Fontaine.";
        	link.l1 = "Alors, il a envoyé l'argent ?";
    		link.l1.go = "Step_32";
		break;

 		case "Step_32":
        	dialog.text = "Il en a envoyé un peu. Mais le travail que vous avez fait ne l'a pas intéressé. L'inventaire s'est révélé sans intérêt, et la destruction de l'expédition espagnole, selon lui, a eu un effet néfaste sur la science européenne dans son ensemble.";
        	link.l1 = "דa alors...";
    		link.l1.go = "Step_33";
        break;

        case "Step_33":
        	dialog.text = "א vrai dire, je n'ai pas de mots non plus. Mais la vie continue. J'ai une affaire pour vous.";
        	link.l1 = "Et de quoi s'agit-il cette fois ?";
    		link.l1.go = "Step_34";
            link.l2 = "וcoutez, allez donc faire vos affaires quelque part très loin.";
    		link.l2.go = "No_Work";
		break;

 		case "Step_34":
        	dialog.text = "De La Fontaine a déterré en Europe d'anciens documents, qui semblent dire qu'il y a aussi une sorte de tombeau sur notre île, on ne sait pas de qui.. "+
                          "Il faudrait fouiller l'île comme il faut et tenter de trouver cet endroit, s'il existe vraiment.";
        	link.l1 = "D'accord, je vais le faire. Mon travail sera-t-il payé cette fois ?";
    		link.l1.go = "Step_35";
        	link.l2 = "וcoutez, Askold, j'ai l'air d'un fossoyeur ? Je ne vais pas fouiller des tombes.";
    		link.l2.go = "No_Work";
		break;

 		case "Step_35":
        	dialog.text = "N'en doutez même pas. C'est un ordre direct du mécène : en cas de succès, il y aura un paiement.";
        	link.l1 = "D'accord, j'ai compris. Je vais chercher.";
    		link.l1.go = "exit";
    		NextDiag.TempNode = "Seek_Grave";
    		AddQuestRecord("Ascold", "13");
    		CloseQuestHeader("Ascold");
			pchar.questdata.Ascold = 1;
    		pchar.questTemp.Ascold = "Ascold_SeekGrave";
		break;

 		case "Seek_Grave":
        	dialog.text = "Vous avez trouvé quelque chose ?";
        	link.l1 = "Pas encore, on cherche...";
    		link.l1.go = "exit";
    		NextDiag.TempNode = "Seek_Grave";
            if (pchar.questTemp.Ascold == "Ascold_SeekGrave")
            {
            	dialog.text = "Ah, bonjour, "+ GetSexPhrase("mon ami","mon amie") +". Comment allez-vous, qu'avez-vous de bon à m'annoncer ?";
            	link.l1 = "Bon sang, Askold, j'ai fouillé tous les environs, mais je n'ai rien trouvé. Absolument rien.";
        		link.l1.go = "Step_36";
            }
            if (pchar.questTemp.Ascold == "Ascold_CantSeekGrave")
            {
            	dialog.text = "Qu'en dites-vous cette fois ? Vous avez trouvé quelque chose ?";
            	link.l1 = "Non. Il n'y a pas de tombeau ici, tout ça, ce sont des bêtises...";
        		link.l1.go = "Step_37";
            }
            if (pchar.questTemp.Ascold == "Ascold_NotEnterFoundGrave")
            {
            	dialog.text = "Quels sont les résultats des recherches ? Quelque chose de nouveau ?";
            	link.l1 = "Je ne sais pas exactement ce que c'est, mais j'ai trouvé une entrée quelque part dans la grotte, seulement elle est fermée.";
        		link.l1.go = "Step_38";
            }
            if (pchar.questTemp.Ascold == "Ascold_SeekRockLetter" && !CheckCharacterItem(pchar, "Rock_letter"))
            {
            	dialog.text = "Vous avez trouvé les tablettes ?";
            	link.l1 = "Pas encore, mais je m'en occupe.";
        		link.l1.go = "exit";
            }
            if (pchar.questTemp.Ascold == "Ascold_SeekRockLetter" && CheckCharacterItem(pchar, "Rock_letter"))
            {
            	dialog.text = "Ah, je vois à vos yeux brillants que vous avez trouvé les tablettes.";
            	link.l1 = "Exactement, je les ai trouvées, caramba !";
        		link.l1.go = "Step_45";
            }
            if (pchar.questTemp.Ascold == "Ascold_EnterGrave")
            {
            	dialog.text = "Vous avez réussi à entrer dans le tombeau ?";
            	link.l1 = "Pas encore, mais je m'en occupe.";
        		link.l1.go = "exit";
            }
		break;

 		case "Step_36":
        	dialog.text = "Hum, je ne sais même pas quoi dire.. "+
                          "Peut-être qu'il n'y a pas de tombeau, je ne sais pas... Mais quand même, si vous avez la chance de trouver quelque chose, je serai content de vous voir.";
        	link.l1 = "Bon, je vais réessayer.";
    		link.l1.go = "exit";
    		pchar.questTemp.Ascold = "Ascold_CantSeekGrave";
		break;

 		case "Step_37":
        	dialog.text = "Peut-être que non, peut-être que si... Continuez à chercher.";
        	link.l1 = "D'accord.";
    		link.l1.go = "exit";
		break;

 		case "Step_38":
        	dialog.text = "Ouais, on dirait que vous avez trouvé exactement ce que cherche de La Fontaine... "+
                          "Bon sang, je suis sמr que c'est là que se trouve le tombeau. Il faut essayer d'y entrer à tout prix.";
        	link.l1 = "Facile à dire. Et comment faire ? Il est clair qu'il y a une entrée, mais elle est solidement bouchée par un rocher.";
    		link.l1.go = "Step_40";
		break;

 		case "Step_40":
        	dialog.text = "Hum, voilà donc comment c'est... וcoutez, apparemment, c'est une protection de tombeau, semblable à celle qu'utilisaient les pharaons en וgypte pour protéger leurs cryptes des visiteurs indésirables.. "+
                          "D'après mon expérience avec de La Fontaine, qui est un célèbre égyptologue, je peux vous dire qu'il y a quelque part à proximité un mécanisme qui ouvre l'entrée.. "+
                          "En règle générale, c'est une sorte d'objet qu'il faut placer quelque part.";
        	link.l1 = "Et quel est cet objet ? Et oם faut-il le mettre ?";
    		link.l1.go = "Step_41";
		break;

 		case "Step_41":
        	dialog.text = "Eh bien, je ne peux pas le savoir avec certitude. Attendez, pourtant.. "+
                          "De La Fontaine, dans sa lettre oם il me charge de trouver le tombeau, écrit qu'il est fait mention d'une sorte de tablette de pierre. Je n'y ai pas prêté beaucoup d'attention, mais il semble que ce soit important.. "+
                          "Donc, on y mentionne que certaines tablettes ouvrent le chemin vers Leif l'Heureux. Apparemment, c'est l'objet recherché.";
        	link.l1 = "Et qui est Leif l'Heureux ?";
    		link.l1.go = "Step_42";
		break;

 		case "Step_42":
        	dialog.text = "Je ne vous l'ai pas dit ? C'est son tombeau que vous cherchez.";
        	link.l1 = "Ah, voilà l'affaire... Alors, et ces tablettes ? Oם dois-je les chercher, et oם dois-je les mettre ?";
    		link.l1.go = "Step_43";
		break;

 		case "Step_43":
        	dialog.text = "Il faut les chercher ici, dans la mer des Caraïbes. Vous savez, on m'apporte toutes sortes de bric-à-brac, mais je n'ai même jamais entendu parler de tablettes. Je pense donc qu'il faut chercher sur les îles désertes ou sur la cכte ouest de la Terre Ferme, près des pêcheries de perles. Ou peut-être là oם se trouvent les ruines du temple découvert par les Espagnols. Sinon, ces tablettes auraient été trouvées depuis longtemps et apportées chez moi pour être vendues.. "+
                          "Je ne sais pas oם les mettre, mais je pense qu'il y a un endroit prévu pour ça quelque part près de l'entrée. Il faut le chercher.";
        	link.l1 = "Intéressant. Bon, je suppose que je vais commencer à chercher ces tablettes. J'espère que cette entrée mène vraiment au bon endroit.";
    		link.l1.go = "Step_44";
        	link.l2 = "J'en ai assez de courir sans but précis. Je ne chercherai plus rien.";
    		link.l2.go = "No_Work";
		break;

 		case "Step_44":
        	dialog.text = "Je l'espère vraiment. Bon, bonne chance dans vos recherches !";
        	link.l1 = "Merci pour vos vœux.";
    		link.l1.go = "exit";
    		pchar.questTemp.Ascold = "Ascold_SeekRockLetter";
            // ==> Делаем скрижали видимыми, теперь их можно найти.
            sld = ItemsFromID("Rock_letter");
            sld.shown = 1;
		break;

 		case "Step_45":
        	dialog.text = "Activez-les et essayez d'entrer dans le tombeau.";
        	link.l1 = "J'espère vraiment que tout va marcher et que mon travail ne sera pas vain.";
    		link.l1.go = "exit";
			bDisableLandEncounters = true; //закроем энкаунтеров, лучше раньше, чем баги.
    		pchar.questTemp.Ascold = "Ascold_EnterGrave";
		break;

 		case "Found_Grave":
            if (pchar.questTemp.Ascold == "Ascold_FoundMummy")
            {
            	dialog.text = "Ah, vous voilà, " + GetFullName(pchar) + " ! Dites-moi vite ce que vous avez trouvé.";
            	link.l1 = "J'ai réussi à ouvrir l'entrée de la grotte. Dans la grotte, dans une des galeries, il y avait l'entrée du tombeau. Je l'ai trouvé.";
        		link.l1.go = "Step_46";
            }
		break;

 		case "Step_46":
        	dialog.text = "Mille diables ! Oh, mon Dieu ! Vous avez trouvé quelque chose à l'intérieur ?";
        	link.l1 = "Il y a un sarcophage de pierre au milieu du tombeau, couvert d'une dalle massive. Je n'ai pas pu bouger la dalle, je n'ai rien d'adapté pour ce genre d'opération.";
    		link.l1.go = "Step_47";
		break;

 		case "Step_47":
        	dialog.text = "Hum, il n'y avait ni objets de valeur, ni mobilier funéraire, ni autres bêtises ?";
        	link.l1 = "Rien de spécial.";
    		link.l1.go = "Step_48";
		break;

 		case "Step_48":
        	dialog.text = "Hum... Donc, tout est à l'intérieur.. "+
                          "Voici ce qu'on va faire : prenez ce pied-de-biche, utilisez-le comme levier, et vous pourrez déplacer la dalle du sarcophage.";
        	link.l1 = "Hum, je ne suis pas sמr que ce soit une bonne idée de déranger le mort qui repose là...";
    		link.l1.go = "Step_49";
		break;

 		case "Step_49":
        	dialog.text = "Hé, voyons, voyons ! Capitaine, ce ne sont que des os pourris. Vous êtes corsaire, vous avez peur de la mort ?";
        	link.l1 = "Je n'ai peur de rien. C'est juste que, personnellement, je détesterais qu'un pilleur de tombes vienne trier mes restes dans ma tombe.";
    		link.l1.go = "Step_50";
		break;

 		case "Step_50":
        	dialog.text = "Vous le prenez ou pas ?";
        	link.l1 = "Je le prends. Je me demande ce qu'il y a là-dedans...";
    		link.l1.go = "Step_51";
		break;

 		case "Step_51":
        	dialog.text = "Eh bien, c'est parfait. Prenez votre pied-de-biche. Bon, j'ai hâte de vous revoir.";
           	link.l1 = "D'accord, Askold.";
    		link.l1.go = "exit";
    		pchar.questTemp.Ascold = "Ascold_WateringMummy";
		LAi_LocationDisableToughSkeletonTimer("Guadeloupe_Cave", 9999); //ПК не пускать 30 лет
    		GiveItem2Character(Pchar,"Ascold_rabble");
		break;

 		case "AfterAttackMummy":
        	dialog.text = "Ah, vous voilà. Vous ne pouvez pas imaginer ce qui s'est passé en ville ! La ville a été prise d'assaut par des squelettes ambulants !!!";
        	link.l1 = "Vraiment ?! Ce n'est pas possible !";
    		link.l1.go = "Step_52";
            if (pchar.questTemp.Ascold == "Ascold_SaveWorld")
            {
            	dialog.text = "Eh bien, excusez-moi, et le monstre ?";
            	link.l1 = "Pas encore, je suis en train de le détruire.";
        		link.l1.go = "exit";
                NextDiag.TempNode = "AfterAttackMummy";
            }
            if (GetCharacterIndex("LeifEricson") == -1)
            {
            	dialog.text = "Alors, oם en êtes-vous pour sauver le monde ?";
            	link.l1 = "Oui, tout va bien, le monde est sauvé, les gens peuvent dormir tranquilles.";
        		link.l1.go = "Step_60";

				// перебиваем иниты пещеры - возвращаем сферы обратно и закрываем гробницу   - ugeen fix
				locations[FindLocation("Guadeloupe_CaveEntrance")].reload.l1.name = "reload1_back";
				locations[FindLocation("Guadeloupe_CaveEntrance")].reload.l1.emerge = "reload1";

				locations[FindLocation("Guadeloupe_Cave")].reload.l1.name = "reload1_back";
				locations[FindLocation("Guadeloupe_Cave")].reload.l1.emerge = "reload1";
				LocatorReloadEnterDisable("Guadeloupe_Cave", "reload1_back", false);

				RestoreOfficers_Ascold(pchar);
				Log_Info("Le passage vers le tombeau s'est refermé");
            }
		break;

 		case "Step_52":
        	dialog.text = "Pas possible ?! Ils ont tué la moitié de la garnison, et ils ont tellement effrayé le gouverneur de la ville qu'il en a fait dans son pantalon !. "+
                          "Pendant l'assaut, je me suis barricadé au premier étage, et j'ai ainsi évité les problèmes. Ce n'était pas facile pour ces momies ambulantes d'arriver jusqu'à moi...";
        	link.l1 = "Content pour vous... Au fait, vous voulez savoir ce qu'il y avait dans la crypte ?";
    		link.l1.go = "Step_53";
		break;

 		case "Step_53":
        	dialog.text = "Quelle crypte ? Oh, alors vous l'avez ouverte ?";
        	link.l1 = "Oui, je l'ai ouverte. Votre pied-de-biche m'a été bien utile.";
    		link.l1.go = "Step_54";
		break;

 		case "Step_54":
        	dialog.text = "Diable ! Dès que vous êtes parti, j'ai reçu une lettre de La Fontaine. Il écrivait qu'il avait réussi à déchiffrer entièrement les anciens manuscrits.. "+
                          "On dit que si on ouvre le cercueil de pierre, ça réveille un ancien monstre indien.";
        	link.l1 = "C'est ce qui s'est passé. Ce monstre, c'est la maudite momie que je cherchais depuis si longtemps.";
    		link.l1.go = "Step_55";
		break;

 		case "Step_55":
        	dialog.text = "Et que s'est-il passé ensuite ?";
        	link.l1 = "Ensuite, moi... bref, l'attaque de squelettes contre la ville, c'était son œuvre.";
    		link.l1.go = "Step_56";
		break;

 		case "Step_56":
        	dialog.text = "Bon sang ! Nous avons joué avec le feu, vous et moi.. "+
                          "Que faire maintenant ? Ce monstre réveillé va détruire tout le monde sur l'île.";
        	link.l1 = "Pas seulement sur l'île. Il veut devenir le maître du monde. Le monde entier ne lui suffit pas...";
    		link.l1.go = "Step_57";
		break;

 		case "Step_57":
        	dialog.text = "דa alors... וcoutez, ça paraît stupide, mais vous devez sauver le monde.";
        	link.l1 = "Pourquoi moi ? Vous ne voulez pas sauver le monde, vous, par exemple ? Après tout, c'est vous qui m'avez envoyé là-bas, et vous êtes plus fort que moi.";
    		link.l1.go = "Step_58";
		break;

 		case "Step_58":
        	dialog.text = "Plus fort, je ne dis pas le contraire. Je me débrouille bien au gourdin, mais l'épée, ce n'est pas mon truc.. "+
                          "Vous avez parlé de la grotte, il faudra y aller. Et comment vais-je manier un gourdin dans un espace aussi étroit ? דa ne marchera pas pour moi.";
        	link.l1 = "Oui, c'est vrai, avec un gourdin, ça ne marchera pas... Bon, je vais sauver le monde moi-même. Il n'y a pas d'échappatoire.";
    		link.l1.go = "Step_59";
		break;

 		case "Step_59":
        	dialog.text = "דa alors, c'est formidable que vous ayez accepté. Bonne chance dans cette tâche difficile, "+ GetSexPhrase("l'ami","ma belle") +".";
        	link.l1 = "Merci pour vos vœux, Askold. דa m'aidera beaucoup.";
    		link.l1.go = "exit";
			LocatorReloadEnterDisable("Guadeloupe_Cave", "reload3_back", true);
			LAi_LocationFightDisable(&Locations[FindLocation("Guadeloupe_Cave")], false);
			pchar.quest.Ascold_LeifIsDead.win_condition.l1 = "NPC_Death";
			pchar.quest.Ascold_LeifIsDead.win_condition.l1.character = "LeifEricson";
			pchar.quest.Ascold_LeifIsDead.function = "Ascold_LeifIsDead";
			NextDiag.TempNode = "AfterAttackMummy";
    		pchar.questTemp.Ascold = "Ascold_SaveWorld";
			sld = characterFromId("LeifEricson");
            LAi_SetImmortal(sld, false);
            LAi_SetWarriorType(sld);
			LAi_warrior_SetStay(sld, true);
			LAi_group_MoveCharacter(sld, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
		break;

 		case "Step_60":
        	dialog.text = "Parfait. Oui, ça n'a pas dמ être facile pour vous, apparemment.. "+
                          "וcoutez, vous avez trouvé quelque chose d'intéressant là-bas ? De La Fontaine va bientכt venir sur l'île, ce serait formidable de lui montrer quelque chose.";
        	link.l1 = "Non, je n'ai rien trouvé.";
    		link.l1.go = "Step_61";
            if (CheckCharacterItem(pchar, "Azzy_bottle"))
            {
            	link.l2 = "Une sorte de lampe, une lampe orientale de Leif. Je ne sais pas ce que c'est.";
        		link.l2.go = "Step_63";
            }
		break;

 		case "Step_61":
        	dialog.text = "Oh, c'est dommage... וcoutez, il faudrait peut-être y regarder de nouveau.. "+
                          "Je sens qu'il doit y avoir quelque chose d'utile pour de La Fontaine. On peut tirer tant d'argent d'un petit objet intéressant...";
        	link.l1 = "Maintenant, écoutez-moi, Askold. J'ai tant enduré en faisant vos commissions que j'ai eu assez d'émotions pour une douzaine de vies. דa suffit, je ne travaille plus avec vous.";
    		link.l1.go = "Step_62";
		break;

 		case "Step_62":
        	dialog.text = "Oh, c'est dommage. Mais je vois qu'il est inutile de vous convaincre. Bon, quittons-nous en amis.";
        	link.l1 = "Oui, soit.";
    		link.l1.go = "exit";
            NextDiag.TempNode = "GoodFriends";
            pchar.questTemp.Ascold = "Ascold_OverBusiness";
			UnlockAchievement("Mummydust_quest", 3);
		break;

 		case "GoodFriends":
        	dialog.text = "Oh ! "+ GetSexPhrase("Vieux frère","Ma belle") +" " + GetFullName(pchar) + " ! Content de vous revoir. Vous êtes là pour affaires, ou vous passiez juste ?";
        	link.l1 = "Je voulais juste vous voir.";
    		link.l1.go = "exit";
            NextDiag.TempNode = "GoodFriends";
            if (pchar.questTemp.Azzy == "HowToKnowAzzy")
            {
            	link.l1 = "וcoutez, j'ai une affaire pour vous. Vous ne sauriez pas, par hasard, comment je pourrais trouver le démon ?";
        		link.l1.go = "Step_64";
            }
		break;

 		case "Step_63":
        	dialog.text = "Eh bien, vendez-la-moi. 50 000 pour ce truc.";
        	link.l1 = "Il n'y a rien dedans, elle est trop légère... Bon, prenez-la, je n'en ai pas besoin.";
    		link.l1.go = "BuyAzzy";
        	link.l2 = "Non, Askold, je vais retourner au navire, j'essaierai de trouver quelqu'un qui découpe ou dessoude proprement la lampe pour moi. Je verrai ce qu'il y a dedans.";
    		link.l2.go = "Step_62";
		break;

 		case "BuyAzzy":
        	dialog.text = "Votre argent, notre marchandise. Peut-être pourrions-nous encore travailler ensemble ? De telles affaires nous attendent...";
        	link.l1 = "Non, Askold. J'en ai assez de ce genre d'aventures.";
    		link.l1.go = "Step_62";
            TakeItemFromCharacter(pchar, "Azzy_bottle");
            AddMoneyToCharacter(pchar, 50000);
		break;

 		case "Step_64":
        	dialog.text = "Quoi ?!!";
        	link.l1 = "J'ai besoin d'un certain démon, et je n'arrive pas à le trouver. Et c'est une question vitale.";
    		link.l1.go = "Step_65";
		break;

 		case "Step_65":
        	dialog.text = "Vous êtes déjà en relation avec les démons ?!";
        	link.l1 = "Tout ça, c'est grâce à vous, ou plutכt à vos commandes ! וcoutez, il existe peut-être des recettes pour invoquer les démons ; les Toltèques en ont une, il me semble.";
    		link.l1.go = "Step_66";
		break;

 		case "Step_66":
        	dialog.text = "Ils ont un rituel, je sais même lequel. Je ne peux pas vous garantir qu'il marchera, mais vous pouvez essayer.";
        	link.l1 = "Quel rituel ? Dites-le-moi !!!";
    		link.l1.go = "Step_67";
		break;

 		case "Step_67":
        	dialog.text = "En gros, il faut trois crânes de cristal toltèques. Notre gouverneur en avait, mais vous vous souvenez, quand les squelettes ont attaqué la ville, leur chef a pris ces crânes.";
        	link.l1 = "Ah, c'est donc pour ça que Leif en avait besoin... C'est clair. Et ensuite ?";
    		link.l1.go = "Step_68";
		break;

 		case "Step_68":
        	dialog.text = "Il faut aussi un objet étrange, l'idole d'une ancienne divinité. Vous rassemblez les trois objets, et vous cherchez quelqu'un capable de célébrer la cérémonie. Une sorcière du coin fera très bien l'affaire.";
        	link.l1 = "Une sorcière ? J'en connais une, justement...";
    		link.l1.go = "Step_69";
		break;

 		case "Step_69":
        	dialog.text = "Parfait. Maintenant, procurez-vous les objets et allez-y. Je suppose que votre sorcière connaît le rituel, puisque c'est une sorcière.";
        	link.l1 = "Je suppose. Au fait, vous n'auriez pas l'un de ces objets ? Je vous l'achèterais.";
    		link.l1.go = "Step_70";
		break;

 		case "Step_70":
           	dialog.text = "Non, je n'ai rien. Alors, cherchez vous-même.";
        	link.l1 = "Eh bien, merci quand même. Portez-vous bien.";
    		link.l1.go = "exit";
            pchar.questTemp.Azzy = "DestrContract";
        	if (sti(pchar.questTemp.Azzy.Immortal.Penalty) >= 15 && GetQuestPastDayParam("questTemp.Azzy") > 90)
        	{
                dialog.text = "Oui. Je viens justement de récupérer les crânes du gouverneur. Je les ai trouvés dans des grottes, au péril de ma vie...";
                link.l1 = "Je suis prêt à vous les acheter à n'importe quel prix. Combien voulez-vous ?";
                link.l1.go = "Step_71";
            }
		break;

 		case "Step_71":
        	dialog.text = "Je ne vous prendrai pas d'argent. Après tout, de La Fontaine et moi vous devons bien plus... Vous avez tant fait pour nous... Et la récompense, vous l'attendez encore ? Disons que nous sommes quittes. Et prenez les crânes.";
        	link.l1 = "Merci infiniment, Askold. וcoutez, vous n'auriez pas trouvé une chose étrange, l'idole d'une divinité ?";
    		link.l1.go = "Step_72";
            GiveItem2Character(pchar, "sculMa1");
            GiveItem2Character(pchar, "sculMa2");
            GiveItem2Character(pchar, "sculMa3");
            GiveItem2Character(pchar, "indian22");
		break;

 		case "Step_72":
        	dialog.text = "Eh bien, je l'ai trouvée. Prenez-la aussi, oם est le problème ?";
        	link.l1 = "Bien, très bien. Maintenant, je suis prêt à retrouver une vie normale. Merci, Askold.";
    		link.l1.go = "exit";
		break;
	}
}


