// Gregg: Feregueyro, once known as Ambrosio - the "Black Orchid" trilogy (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// A former pearl diver, the first possessor of the Black Orchid and the eighth seeker:
//   First time - the stock line; after node 5 - the muttering of the hooded man;
//   1-5   - the shore of Shore50, he speaks of himself in the third person;
//   6-13  - the cabin after the boarding: who he really is;
//   14-25 - Turks, the grotto, how he found the Orchid and how he lost it;
//   26-31 - Jamaica, Fort Orange, the journal and the "rightful place";
//   32-34 - the Meritor: seven parts, and the curse that drives him at the village;
//   35-44 - the rules of the search: who holds which part, and how to find the last two;
//   45    - the talk ends in a fight in the cabin.
// Node 35 hands over MysteriousArtefact_MeritorChapter_2 - the second part of the Meritor.
// In the original nodes 40 and 44 contradicted each other over who held the fourth part
// and who the fifth. Set straight to match the quest logic: the fourth is Levinson's,
// the fifth lies in the hold of Bernaldinio Toranger's ship.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name;
	string sFullName = GetFullName(PChar);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";

			if (CheckAttribute(PChar, "DestinyGift"))
			{
				if (PChar.DestinyGift == "13")
				{
					dialog.text = "Feregueyro... sera... vengé...";
					link.l1 = "Hum...";
					link.l1.go = "exit";
				}
			}
		break;

		case "1":
			dialog.text = "Tous... seront... tués...";
			link.l1 = "Tués ? Qui doit être tué ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Pas un... ne sortira... vivant...";
			link.l1 = "Hé ! Tu m'entends, au moins ? Qu'est-ce que tu as ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Feregueyro... n'épargnera... personne...";
			link.l1 = "Reste ici. Ne va nulle part.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "L'heure... est venue... la malédiction... sera... levée...";
			link.l1 = "Parle clairement, l'ami ! Quelle malédiction ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Feregueyro... sera... vengé...";
			link.l1 = "Reste oם tu es. Je vais chercher de l'aide.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFindFeregueyro");
		break;

		case "6":
			dialog.text = "...(haletant)... Vous avez le dessus sur moi, " + sFullName + ". Achevez-moi et qu'on en finisse : à quoi bon les paroles creuses ?";
			link.l1 = "Pourquoi envoyez-vous sans cesse vos créatures contre le village des pêcheurs de perles ? Que cherchez-vous là-bas ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Comme si vous ne saviez pas, " + sFullName + ", pourquoi je tiens tant à y entrer.";
			link.l1 = "Assez de devinettes, Feregueyro. Parlez clairement.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Et moi qui pensais que l'un des plus grands chercheurs de l'Orchidée noire aurait l'esprit plus vif.";
			link.l1 = "Vous connaissez l'Orchidée ? Parlez, et vite : que savez-vous ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Ne me pressez pas, " + sFullName + ". Laissez-moi reprendre mon souffle, et je vous dirai tout.";
			link.l1 = "Ne traînez pas. Je n'ai pas le temps d'attendre.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Très bien. Vous savez déjà que le vieil Alejon Kendart vivait au village des pêcheurs de perles, avant même votre arrivée là-bas ?";
			link.l1 = "דa, je le sais.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Et ne vous êtes-vous jamais demandé, " + sFullName + ", pourquoi Kendart avait choisi ce village parmi tous les endroits du continent ? Je vais vous le dire. Parce que tous les chercheurs tiennent le village des pêcheurs de perles pour la véritable demeure de l'Orchidée noire : l'endroit même oם on l'a trouvée.";
			link.l1 = "Donc, depuis le jour oם Kendart a trouvé l'Orchidée, elle se trouvait au village depuis le début ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Exactement, " + sName + " ! Et seuls deux hommes le savaient : sir Andrew Murdoch et moi, Feregueyro. Murdoch l'a appris par hasard il y a quelques mois ; moi, je l'ai toujours su, et j'ai essayé plus d'une fois de reprendre l'Orchidée.";
			link.l1 = "Vous êtes donc le huitième chercheur de l'Orchidée noire.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Visez plus haut, " + sName + ". Vous avez devant vous le premier possesseur de l'Orchidée noire. Qu'en dites-vous, hein ?";
			link.l1 = "דa ne me stupéfie pas. דa m'étonne quelque peu.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Voici l'histoire. Il y a bien longtemps, j'étais un simple pêcheur de perles, et je m'appelais Ambrosio. Je me souviens bien de ce jour : nous pêchions des perles au large des îles Turques, une île déserte. \nLe grain est arrivé si soudainement que nous n'avons pas pu regagner la terre. Le ressac a jeté notre tartane sur les rochers et l'a réduite en miettes. Deux d'entre nous ont survécu : moi et un camarade.";
			link.l1 = "Vous avez eu de la chance d'en sortir vivant.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "De la chance, c'est beaucoup dire, " + sName + ". Nous étions tous les deux brisés : j'avais les deux jambes cassées, et le bras gauche broyé. Mon camarade s'en était mieux tiré, et il m'a traîné jusqu'à une grotte voisine, à l'abri de la pluie et du vent. \nא la tombée de la nuit, trois autres survivants sont arrivés. Je me souviens de cette nuit comme de l'enfer : mon bras me faisait si mal que je me retenais de toutes mes dernières forces pour ne pas hurler.";
			link.l1 = "Je comprends.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Le matin, mes camarades sont partis chercher de l'eau et de la nourriture. La douleur était telle que je me suis mis à penser à en finir. Et c'est alors que j'ai aperçu le filet de quelqu'un, avec trois huîtres dedans. Faute de mieux, je me suis mis à les ouvrir. \nDeux étaient vides ; dans la troisième, il y avait une grosse perle jaune, en forme de poire. Mon bras s'est remis à me lancer, et par dépit, j'ai jeté la perle au fond de la grotte. Et alors, j'ai tout oublié : là oם elle était tombée, dans l'obscurité, brillait une faible lueur argentée.";
			link.l1 = "Une lueur argentée ? Le signe de l'Orchidée noire ?";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Oui. J'ai rampé jusque-là malgré la douleur. Ce qui brillait, c'était une petite pierre lisse, qui avait exactement la forme d'une fleur. Je l'ai tenue entre mes mains, la douleur s'est dissipée et je me suis endormi. Je me suis réveillé vers midi : plus aucune douleur, et tous mes os ressoudés. \nJe me suis levé et je suis sorti de la grotte : une pluie fine, un vent humide. Je suis revenu, je me suis assis et j'ai examiné la pierre qui m'avait guéri. Pour sa forme, je lui ai donné le nom d'Orchidée noire.";
			link.l1 = "Et pourquoi une orchidée ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Les orchidées sont les fleurs de mon enfance : ma mère en rapportait souvent à la maison. Voilà toute la raison.";
			link.l1 = "Et que s'est-il passé ensuite ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "J'ai regardé autour de moi cette misérable grotte et j'ai pensé combien il serait bon d'être chez moi, au village des pêcheurs, à l'instant même. Une lumière m'a frappé les yeux, la douleur m'a transpercé et j'ai perdu connaissance. Je suis revenu à moi dans ma propre maison, l'Orchidée serrée dans mon poing, et elle brillait à faire mal aux yeux.";
			link.l1 = "Vous aviez utilisé l'un des pouvoirs de l'Orchidée pour vous transporter ?";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "C'est exact, même si je ne l'ai pas compris tout de suite. J'étais terrorisé, et j'ai mis longtemps à m'en remettre. Mais il est vite devenu évident que ses pouvoirs étaient sans limites. Bien sמr, je n'ai pas dit un mot à mes voisins : j'ai inventé une histoire pour expliquer mon sauvetage, j'ai joué l'invalide et j'ai passé des journées entières à l'étudier chez moi. En un mois, je connaissais tous ses pouvoirs.";
			link.l1 = "Et vos camarades restés aux îles Turques ? Vous n'êtes pas retourné les chercher ?";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Non. J'ai du mal à l'avouer, mais non. J'étais si fasciné par ma trouvaille que j'en ai oublié le monde entier, et eux avec. Même quand les Anglais ont attaqué le village, je me suis enfermé, j'ai pris l'Orchidée et j'ai voulu me transporter très loin. \nJ'ai été trop lent. Ils ont enfoncé la porte, m'ont saisi et ont pris l'Orchidée. א partir de ce jour, j'ai été esclave, et on m'a emmené à Niévès dans la cale puante d'une frégate anglaise.";
			link.l1 = "Et l'Anglais qui vous avait pris l'Orchidée ? Qu'en a-t-il fait ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "J'y viens. Pendant que je l'étudiais, l'Orchidée avait perdu tout son éclat : rien de remarquable, aucune valeur pour un Anglais. א Niévès, on m'a fait monter sur le pont et pousser vers la chaloupe. Et en traversant le pont, j'ai vu ce rouquin qui me l'avait prise. \nIl retournait la pierre entre ses mains en demandant à un autre à quoi elle pouvait servir. L'autre l'a tournée et retournée, la lui a rendue et a dit que c'était un morceau inutile de... enfin, vous devinez ce qu'il a dit.";
			link.l1 = "Hé, je devine.";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Le rouquin l'a examinée encore une fois et l'a jetée par-dessus bord. Et moi, j'étais au septième ciel. Assis dans cette cale, je croyais l'Orchidée perdue pour moi à jamais, et voilà qu'il s'avérait que tout n'était pas perdu.";
			link.l1 = "Elle est tombée à la mer. א quoi vous servait-il de voir oם ?";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Mais je suis pêcheur de perles ! La frégate mouillait par une quinzaine de pieds de fond, et j'ai repéré l'endroit oם elle avait coulé : il y avait une jetée juste à cכté. Seulement, mes espoirs ont été déçus : le jour même, on m'a acheté et emmené à la Jamaïque.";
			link.l1 = "Et l'Orchidée noire a été trouvée par Giancarlo, un docker ! En se reposant sur la jetée, il a vu une faible lueur argentée dans l'eau, il a plongé, et il est devenu son possesseur suivant.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Oui, l'histoire des possesseurs suivants, tous les chercheurs la connaissent. Mais comment l'Orchidée a été trouvée la première fois, moi seul le savais : moi, son premier possesseur. Maintenant, vous le savez aussi.";
			link.l1 = "Et que vous est-il arrivé à la Jamaïque ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "א la Jamaïque, j'ai longtemps travaillé comme charpentier au chantier naval, jusqu'à ce qu'une occasion de m'enfuir se présente. J'ai pris la jungle et j'ai rejoint les Hollandais à Fort Orange.";
			link.l1 = "Et les Hollandais vous ont accueilli ? Un esclave en fuite ?";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Oui. Il n'y a pas de paix entre les Hollandais et les Anglais ; on ne livre pas les fugitifs. Alors je suis resté, et je suis devenu porteur dans une boutique. Et un jour, à la taverne, j'ai surpris la conversation d'un Hollandais au surnom bizarre avec un grand gaillard balourd.";
			link.l1 = "Tulipe ! C'était bien le nom de ce Hollandais, n'est-ce pas ?";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Oui, il me semble. Il disait au grand gaillard que l'Orchidée noire était revenue à sa véritable demeure ; seulement, oם se trouvait cette demeure, personne ne le savait. Moi, je le savais. La véritable demeure de l'Orchidée noire, c'est le village des pêcheurs de perles. Et j'y suis allé.";
			link.l1 = "Attendez. Pourquoi le village des pêcheurs ? On l'a trouvée aux îles Turques : c'est donc aux îles Turques qu'est sa véritable demeure.";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "On l'a trouvée aux îles Turques, vous avez raison. Mais les mots « véritable demeure » sont de moi. Pendant que j'étudiais l'Orchidée, je tenais un journal oם je notais chacune de mes observations. Et tout au début, j'ai écrit qu'il fallait tenir le village des pêcheurs de perles pour la véritable demeure de l'Orchidée noire. Les îles Turques me rappellent de mauvais souvenirs, alors je n'en ai rien dit.";
			link.l1 = "Alors comment Kendart a-t-il appris que la véritable demeure était le village des pêcheurs ?";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Je ne peux que le deviner. Il a trouvé le journal, c'est certain : il employait les mots « véritable demeure », et on ne peut les avoir pris nulle part ailleurs. Comment le journal est tombé entre ses mains, je l'ignore. \nLe plus probable, c'est que Kendart est passé au village après l'attaque des Anglais et qu'il est tombé dessus. Et quand l'Orchidée lui est parvenue, il a choisi de la rendre à sa véritable demeure, celle que le journal désignait.";
			link.l1 = "C'est tout de même étrange qu'il l'ait cachée au village, et qu'en plus il ait parlé d'une véritable demeure. Il ne lui est jamais venu à l'idée que vous viendriez la chercher ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Il était sמr que j'étais mort pendant cette attaque. Et dans ce cas, personne ne connaissait la véritable demeure. C'est là qu'il s'est trompé.";
			link.l1 = "C'est vrai, il ne s'y attendait pas. Mais voici ce que je ne comprends pas : que voulez-vous au village, maintenant ? L'Orchidée n'y est plus, Kendart n'est plus là. Et pourquoi lâchez-vous ces créatures sur les gens ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Kendart n'est plus là, mais la chose qui vous mènera à l'Orchidée, si. Ou plutכt, l'une de ses sept parties. Rassemblez-les toutes les sept, et la chose vous indiquera la direction à suivre pour trouver l'Orchidée.";
			link.l1 = "En bref, c'est une boussole qui indique l'Orchidée noire ?";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "On peut le dire ainsi. Moi, j'appelle cette chose le Meritor.";
			link.l1 = "Et les attaques ? א quoi servent-elles ?";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Je ne peux pas mettre le pied au village tant qu'il y reste une seule âme vivante. Cette malédiction pèse sur moi depuis le jour même oם j'ai quitté cet endroit. D'oם elle vient, je l'ignore. Je ne la comprends pas. Alors j'envoie mes serviteurs : ils les tuent tous, et ensuite, j'entre dans un village vide et je prends ma partie du Meritor.";
			link.l1 = "Et oם sont les autres parties ? L'une est au village, ça, je l'ai compris.";
			link.l1.go = "35";
		break;

		case "35":
			TakeNItems(PChar, "MysteriousArtefact_MeritorChapter_2", 1);
			dialog.text = "Je vais vous dire tout ce que je sais. Une partie est à moi, et je vous la donne. Une autre est détenue par une chercheuse du nom de Matilda.";
			link.l1 = "Matilda ? Vous avez dit Matilda ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Oui, c'est bien son nom, je crois. L'une des parties est à elle.";
			link.l1 = "Attendez. Regardez cette chose. Matilda me l'a donnée avant de mourir. Est-ce une partie du Meritor ?";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "...(examine la chose)... Oui. Alors, cette partie, vous l'avez déjà trouvée. La troisième, comme je l'ai dit, est au village des pêcheurs de perles, dans la maison oם vivait Kendart.";
			link.l1 = "Cette maison a été fouillée de fond en comble. Il n'y a rien.";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "Cherchez mieux, elle y est. J'en suis certain : absolument certain qu'elle se trouve dans la maison oם vivait Kendart.";
			link.l1 = "Et d'oם vous vient une telle certitude ?";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Avec le temps, vous comprendrez. Ce n'est pas le moment.";
			link.l1 = "Très bien, ça fait la troisième. Et les autres ?";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "La quatrième est chez Frederick Levinson, l'un des chercheurs. La cinquième est chez un Espagnol, Bernaldinio Toranger, capitaine du « Vautour ».";
			link.l1 = "Frederick, je le connais. Mais oם chercher Toranger ?";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Comment le saurais-je ? Je vous dis qui détient les parties du Meritor, pas oם trouver leurs gardiens.";
			link.l1 = "Comme vous voudrez. Et les deux dernières ?";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "א vrai dire, c'est tout ce que je sais. Oם se trouvent la sixième et la septième, je n'en ai aucune idée. Mais avec le temps, vous l'apprendrez vous-même. Regardez seulement plus souvent les parties que vous détenez déjà, et vous comprendrez.";
			link.l1 = "Vous ne pouvez pas le dire clairement ? Faut-il que tout soit à demi-mot ?";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Que le diable vous emporte, je vous ai dit presque tout tel quel ! Il ne vous reste plus qu'à trouver les parties manquantes du Meritor, et l'Orchidée est à vous. Et vous me tombez encore dessus comme si je n'avais rien dit.";
			link.l1 = "Je voulais seulement...";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Taisez-vous, " + sName + ". Donc : deux parties du Meritor sont à vous. La troisième est dans la maison de Kendart, la quatrième chez Levinson, la cinquième chez Bernaldinio Toranger. Si vous voulez trouver la sixième et la septième, regardez plus souvent celles que vous avez rassemblées, et vous comprendrez. Et maintenant, " + sFullName + ", tuez-moi. J'ai perdu.";
			link.l1 = "Je n'ai aucune envie de vous tuer.";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Ce n'est pas l'heure de la pitié ! J'ai perdu, et c'est donc à moi de mourir. Et de toute façon, vous devrez me tuer, ou mourir vous-même. Défendez-vous !";
			link.l1 = "Mais...";
			link.l1.go = "exit";
			LAi_SetHP(NPChar, 500.0, 500.0);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
