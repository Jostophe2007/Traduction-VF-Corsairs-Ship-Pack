// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            //===> Проверка состояния текущего квеста
            if (pchar.questTemp.State == "Sp5LaVegaAttack_toSantiago")
            {
    			dialog.text = "Je vous écoute, "+ GetSexPhrase("señor", "señorita") +".";
    			link.l1 = "Je suis détaché à votre disposition par le gouverneur général de La Havane.";
    			link.l1.go = "Step_S5_1";
            }
            if (pchar.questTemp.State == "Sp5LaVegaAttack_WeWon")
            {
    			dialog.text = "Qu'avez-vous à me dire, officier ?";
    			link.l1 = "Tout s'est déroulé au mieux. La colonie de boucaniers de La Vega a été détruite, et leur chef, Mansfield, a été tué de ma main.";
    			link.l1.go = "Step_S5_6";
            }
            //<=== Проверка состояния текущего квеста
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;

        //********************** Девятый квест англ.линейки: нападение на Сантьяго ************************
        case "EL9_SantiagoAttack":
			dialog.text = "Vous avez gagné, ladron !";
			link.l1 = "Señor, je n'aime pas qu'on m'appelle ainsi. Je préférerais qu'on m'appelle corsaire.";
			link.l1.go = "Step_E9_1";
			AfterTownBattle();
        break;
        case "Step_E9_1":
            dialog.text = "Vous vous en passerez, sale porc d'Anglais.";
			link.l1 = "Je crains que non, monsieur. Le fait est que nous ne partons pas seuls. Vous allez nous accompagner jusqu'aux cכtes de la Jamaïque. Sir Thomas Madiford brמle de faire votre connaissance.";
			link.l1.go = "Step_E9_2";
        break;
        case "Step_E9_2":
            dialog.text = "Quoi ?!!! De quel droit ?!!!";
			link.l1 = "Du droit du vainqueur, señor. Et donc, puisque les circonstances nous obligent à faire route ensemble quelque temps...";
			link.l1.go = "Step_E9_3";
        break;
        case "Step_E9_3":
            dialog.text = "Manoel Rivero Pardal se précipite déjà à mon secours. Vous n'irez pas loin...";
			link.l1 = "Ce n'est pas la première fois que je croise un Espagnol en mer. Pardal ou pas Pardal, peu importe. Préparez-vous, honorable monsieur. Et dépêchez-vous !";
			link.l1.go = "Step_E9_4";
        break;
        case "Step_E9_4":
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_GrabbingTown", 1); // статистика
			AddQuestRecord("Eng_Line_9_AttackSantiago", "2");
			chrDisableReloadToLocation = false;
            Pchar.quest.AttackSantiago_FightWithPardal.win_condition.l1 = "location";
            Pchar.quest.AttackSantiago_FightWithPardal.win_condition.l1.location = "Cuba1";
            Pchar.quest.AttackSantiago_FightWithPardal.win_condition = "AttackSantiago_FightWithPardal";
            // ==> Меняем имя и модель у губера,
            npchar.model = "usurer_3";
            npchar.name 	= "Gregorio Florido";
        	npchar.lastname = "de Balboa";
        	SendMessage(npchar, "lss", MSG_CHARACTER_SETMODEL, npchar.model, npchar.model.animation);
        	FaceMaker(npchar);
            // ==> а пленным делаем Альбермаля.
            sld = GetCharacter(NPC_GenerateCharacter("Himenes", "huber_spa", "man", "man", 10, SPAIN, -1, false));
            LAi_SetStayTypeNoGroup(sld);
            sld.name 	= "Jose Sancho";
        	sld.lastname = "Jimenez";
            SetCharacterRemovable(sld, false);
            AddPassenger(pchar, sld, true);
			SetReturn_Gover_Dialog_Exit(NPChar);
            DoReloadCharacterToLocation("Santiago_town",  "reload", "reload3");
            NextDiag.CurrentNode = "Cupture_after";
            chrDisableReloadToLocation = false;
			AddDialogExitQuestFunction("TWN_ExitForPay");
            DialogExit();
        break;
        //********************** Квест №5, Нападение на Ла Вегу. ************************
        case "Step_S5_1":
            dialog.text = "Oui, c'est très bien que vous soyez là. זtes-vous prêt à combattre sur terre ?";
			link.l1 = "Toujours prêt.";
			link.l1.go = "Step_S5_2";
        break;
        case "Step_S5_2":
            dialog.text = "Bien. Dans ce cas, écoutez, je vous prie, ce que vous devez faire.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "Step_S5_3";
        break;
        case "Step_S5_3":
            dialog.text = "Vous devez attaquer et détruire la colonie de boucaniers d'Hispaniola appelée La Vega. Elle est dirigée par un certain Edward Mansfield, un vieux ladron. Cette colonie doit être entièrement détruite ; tout ce que vous y trouverez sera votre butin légitime. Hispaniola doit être entièrement espagnole, et le premier obstacle sur cette voie, c'est La Vega. J'attends un nouveau contingent de colons, il leur faut de la place pour vivre.";
			link.l1 = "Compris. Puis-je commencer ?";
			link.l1.go = "Step_S5_4";
        break;
        case "Step_S5_4":
            dialog.text = "Bien sמr, et le plus tכt sera le mieux. Encore une fois, j'attire votre attention sur le fait que la colonie doit être entièrement détruite : il ne doit pas y rester âme qui vive. Hispaniola est notre île, cette racaille n'y a pas sa place.";
			link.l1 = "Je comprends et je commence la mission immédiatement.";
			link.l1.go = "Step_S5_5";
        break;
        case "Step_S5_5":
            dialog.text = "Excellent ! Don Francisco vous a recommandé comme un officier de combat extrêmement capable et efficace. Je vous attends avec de bonnes nouvelles.";
			link.l1 = "Je peux vous assurer que La Vega cessera bientכt d'exister.";
			link.l1.go = "exit";
            pchar.questTemp.State = "Sp5LaVegaAttack_AttackLaVega";
            AddQuestRecord("Spa_Line_5_LaVegaAttack", "2");
            Pchar.quest.Sp5LaVegaAttack_AttackGoOn.win_condition.l1 = "location";
			Pchar.quest.Sp5LaVegaAttack_AttackGoOn.win_condition.l1.location = "LaVega_town";	// 22.08.2022 Sinistra Теперь сражение происходит сразу в городе из-за новой локации
            Pchar.quest.Sp5LaVegaAttack_AttackGoOn.win_condition = "Sp5LaVegaAttack_AttackGoOn";
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry3 = Rand(19)+40;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry4 = Rand(19)+40;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry5 = Rand(19)+40;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry7 = Rand(19)+20;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry8 = Rand(19)+20;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry10 = Rand(19)+20;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry14 = Rand(19)+20;
            pchar.GenQuestBox.LaVega_townhall.box1.items.jewelry17 = Rand(19)+40;
            pchar.GenQuestBox.LaVega_townhall.box1.items.cirass4 = 1;
			sld = characterFromId("Edward Mansfield");
			sld.Default.Crew.Quantity    = 1700;
			sld.Default.Crew.MinQuantity = 1100;
			sld.from_sea = ""; // для захвата с суши
			sld.Default  = "LaVega_townhall";  // чтоб сухопутные города вернули население
			sld.Default.BoardLocation = "LaVega_town";
			SetLocationCapturedState("Lavega_town", true);
        break;
        case "Step_S5_6":
            dialog.text = "Parfait, " + GetSexPhrase("señor","señorita") + " ! Tout simplement parfait ! Don Francisco Oregon y Gascon peut être très fier d'avoir de tels officiers à son service.";
			link.l1 = "Les boucaniers sont un adversaire de taille ; cette mission n'était pas une mince affaire. Señor, et ma rétribution ?";
			link.l1.go = "Step_S5_7";
        break;
        case "Step_S5_7":
            dialog.text = "Ah oui... La ville de Santiago estime l'accomplissement d'une mission aussi difficile à 100 000 piastres. Veuillez les recevoir.";
			link.l1 = "Excellent. Señor Jimenez, ce fut un plaisir de traiter avec vous. Au revoir.";
			link.l1.go = "exit";
            AddMoneyToCharacter(pchar, 100000);
            pchar.questTemp.State = "Sp5LaVegaAttack_BackToHavana";
            AddQuestRecord("Spa_Line_5_LaVegaAttack", "4");
        break;
	}
    UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

