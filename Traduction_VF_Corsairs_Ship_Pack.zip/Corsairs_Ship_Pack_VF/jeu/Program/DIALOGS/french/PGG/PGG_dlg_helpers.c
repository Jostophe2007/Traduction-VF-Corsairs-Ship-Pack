void ContrabandDialog(aref link) {
	Dialog.text = "וcoute, dégage d'ici ! Si tu fais capoter " + GetSexPhrase("l'affaire, je t'arrache le cœur !", "mon affaire, je t'arrache tes sales yeux !");
	link.l1 = RandPhraseSimple("Tu oses me menacer, " + GetSexPhrase("chien", "créature") + " ?", GetSexPhrase("Tu vas t'étrangler avec tes paroles, canaille !", "Je vais te découper en lanières, salope !"));
	link.l1.go = "Exit_Smugglers_Fight";
	link.l2 = "Allons, je sais ce que sont les affaires. א plus tard.";
	link.l2.go = "Exit";
}

void MaxCompanionsExceededDialog(aref link, ref NPChar) {
	Dialog.Text = RandPhraseSimple("On dirait que vous avez déjà assez de compagnons.", "Vous avez déjà beaucoup de navires. Pourquoi en voulez-vous un autre ?");
	link.l1 = "Ouais... Vous avez peut-être raison.";
	link.l1.go = "exit";
}

void NotEnoughMoneyDialog(aref link, ref NPChar) {
	Dialog.Text = RandSwear() + "C'était une blague ? Le vent siffle dans vos poches !"
	link.l1 = "C'est vrai... J'y vais.";
	link.l1.go = "exit";
}

void PGGNoShipDialog(aref link, ref NPChar) {
	Dialog.Text = "Oui, je me retrouve sans navire.";
	link.l1 = RandSwear() + "Alors nous reparlerons plus tard de la façon dont vous obtiendrez un navire.";
	link.l1.go = "exit";
}

void PCharNoShipDialog(aref link, ref NPChar) {
	Dialog.Text = "Que voulez-vous que je fasse ? Trouvez d'abord un bateau, ensuite on parlera !";
	link.l1 = RandSwear() + "Eh bien, tant pis !";
	link.l1.go = "exit";
}

void PCharShipClassIsLowDialog(aref link, ref NPChar) {
	Dialog.Text = "Qu'est-ce qui vous prend !?? Trouvez d'abord un navire convenable ! Votre coquille de noix est tout juste bonne à porter le courrier...";
	link.l1 = RandSwear() + "Eh bien, tant pis !";
	link.l1.go = "exit";
}

void PCharRankLowDialog(aref link, ref NPChar) {
	Dialog.Text = "Qu'est-ce qui vous prend !?? Acquérez d'abord de l'expérience !";
	link.l1 = RandSwear() + "Eh bien, tant pis !";
	link.l1.go = "exit";
}

void PGGQuestNotEnoughtTimePassedDialog(aref link, ref NPChar) {
	Dialog.Text = NPCharRepPhrase(NPChar, 
		"Pas d'affaires aujourd'hui, dégagez.", 
		"Désolé, je n'ai rien à vous proposer."
	);
	link.l1 = PCharRepPhrase(RandSwear(), "Eh bien, à plus tard.");
	link.l1.go = "exit";
}

bool PGGQuestAlreadyActive(aref link, ref NPChar) {
	if (!CheckAttribute(PChar, "GenQuest.PGG_Quest.PGGid"))
	{//висящий флаг без PGGid: само-залечивание
		DeleteAttribute(PChar, "GenQuest.PGG_Quest");
		return false;
	}
	int currQuestPGGid = GetCharacterIndex(PChar.GenQuest.PGG_Quest.PGGid);
	if (currQuestPGGid < 0 || currQuestPGGid >= TOTAL_CHARACTERS) {
		DeleteAttribute(PChar, "GenQuest.PGG_Quest");
		return false;
	}

	ref currQuestPGG = &characters[currQuestPGGid];
	if (!CheckAttribute(currQuestPGG, "PGGAi.ActiveQuest")) {
		DeleteAttribute(PChar, "GenQuest.PGG_Quest");
		return false;
	}
	Dialog.Text = "Et pourquoi avez-vous besoin de moi, je me le demande ? Revenez dès que vous aurez réglé toutes vos affaires avec le capitaine " + GetFullName(currQuestPGG) + " !";
	link.l1 = "C'est vrai, j'avais oublié...";
	link.l1.go = "exit";
	return true;
}

void GeneratePGGQuestLocation(ref NPChar) 
{
	PChar.GenQuest.PGG_Quest.Template = drand(1);
	if (CheckAttribute(NPChar, "PGGAi.ActiveQuest.QstNumber.Template"))
	{
		PChar.GenQuest.PGG_Quest.Template = NPChar.PGGAi.ActiveQuest.QstNumber.Template;
	}
	PChar.GenQuest.PGG_Quest.Parts = GetCompanionQuantity(PChar)+1;
	PChar.GenQuest.PGG_Quest.Nation = rand(3);

	// генерим остров и пляж, пока не найдем пустой(без квеста)
	PChar.GenQuest.PGG_Quest.Island.Shore = "";
	string sCurIsland = GetCharacterCurrentIslandId(pchar);
	string sCurIsland2 = "";
	if (PChar.ColonyBuilding.Stage != "0") sCurIsland2 = "Caiman";

	while(PChar.GenQuest.PGG_Quest.Island.Shore == "" || 
		PChar.GenQuest.PGG_Quest.Island == "Pearl" || 
        PChar.GenQuest.PGG_Quest.Island == "Panama" ||		
		PChar.GenQuest.PGG_Quest.Island == "KhaelRoa" ||
		PChar.GenQuest.PGG_Quest.Island == "Reefs" ||
		PChar.GenQuest.PGG_Quest.Island == sCurIsland ||
		PChar.GenQuest.PGG_Quest.Island == sCurIsland2)	//фикс - не даём квест на ближайший остров и на начавший строится кайман
	{
		if (sti(PChar.GenQuest.PGG_Quest.Template)) 
		{
			PChar.GenQuest.PGG_Quest.Island = GetRandomUninhabitatIsland();
		} 
		else 
		{
			PChar.GenQuest.PGG_Quest.Island = GetRandomIslandId();
		}
		PChar.GenQuest.PGG_Quest.Island.Shore = GetIslandRandomShoreId(PChar.GenQuest.PGG_Quest.Island);
		if (!isLocationFreeForQuests(PChar.GenQuest.PGG_Quest.Island.Shore)) PChar.GenQuest.PGG_Quest.Island.Shore = "";
	}
	
	PChar.GenQuest.PGG_Quest.Island.Town = FindTownOnIsland(PChar.GenQuest.PGG_Quest.Island);

	if (isSetSail) PChar.GenQuest.PGG_Quest.Days = rand(4) + 5;
	else PChar.GenQuest.PGG_Quest.Days = GetMaxDaysFromIsland2Island(GetCharacterCurrentIslandId(PChar), PChar.GenQuest.PGG_Quest.Island) + 1;

	PChar.GenQuest.PGG_Quest.Goods = GOOD_SLAVES + drand(2);
	
	PChar.GenQuest.PGG_Quest.PGGid = NPChar.id;
	NPChar.Nation.Bak = NPChar.Nation;
}
