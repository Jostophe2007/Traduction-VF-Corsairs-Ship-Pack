// Диалог начала игры (туториал) 03.10.06 boal
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref sld;

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Finish_2":
            DoQuestFunctionDelay("Tut_locCamera_2", 0.1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_RemoveCheckMinHP(Pchar); // снимем проверки
			LAi_SetImmortal(pchar, false);
			LAi_SetPlayerType(pchar);
			InterfaceStates.Buttons.Save.enable = true;
			DoReloadCharacterToLocation(Pchar.HeroParam.Location, Pchar.HeroParam.Group, Pchar.HeroParam.Locator);
		break;

		case "ChangePIRATES":
            LAi_SetCitizenTypeNoGroup(NPChar);
            LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = "Node_5";
			DialogExit();
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		case "ChangePIRATES_Jess":
            LAi_SetCitizenTypeNoGroup(NPChar);
            LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = "Node_5_Jess";
			DialogExit();
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		case "Teach_battle_1":
		    LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = "Teach_6";
			AddDialogExitQuestFunction("Tut_TeachBattle");
			DialogExit();
		break;

		case "First time":
			NextDiag.TempNode = "First time";
			EndQuestMovie();
			InterfaceStates.Buttons.Save.enable = false;
			LAi_LockFightMode(Pchar, false);
			LAi_SetActorTypeNoGroup(Pchar);
			LAi_ActorTurnToCharacter(Pchar, NPChar);
			if (pchar.name == "Jessica")
			{
				dialog.text = "Vous voilà enfin de nouveau sur pied, capitaine. Dieu merci, sinon nous ne savions plus que penser.";
				if (bBettaTestMode)
				{
					link.l0 = "Bêta-test : passer et commencer la partie";
					link.l0.go = "Finish_2";
				}
				link.l1 = "Sandro ? Que diable s'est-il passé ? Et pourquoi ai-je la tête qui me fait un mal de chien ?";
				link.l1.go = "Node_1_Jess";
			}
			else
			{
				dialog.text = "Voilà, capitaine, au moins, maintenant, vous vous ressemblez. Comment vous sentez-vous ?";
				if (bBettaTestMode)
				{
					link.l0 = "Bêta-test : passer et commencer la partie";
					link.l0.go = "Finish_2";
				}
				link.l1 = "Hum... et à qui je ressemblais avant ?";
				link.l1.go = "Node_1";
			}
		break;

        case "Node_1":
			dialog.text = "Eh bien, à ces impies au visage rouge, vous parliez même leur langue.";
			link.l1     = "Diable ! Sandro, qu'est-ce que tu racontes ?!";
			link.l1.go  = "Node_2";
		break;

		case "Node_1_Jess":
			dialog.text = "Alors, vous ne vous souvenez de rien ? Et ce n'est pas étonnant : un autre serait mort depuis longtemps d'une telle commotion, ou se serait mis à sourire bêtement et à souiller ses culottes pour le restant de ses jours, mais vous, vous avez la peau dure. Cependant, vous êtes très faible, vous tenez à peine debout : ça fait bientכt six mois que nous essayons de vous tirer de là.";
			link.l1     = "Dis-moi exactement ce que c'est que cette commotion : tu vois bien que je ne me souviens de rien.";
			link.l1.go  = "Node_2_Jess";
		break;

		case "Node_2":
			dialog.text = "Ne vous inquiétez pas, il ne faut pas vous inquiéter. Vous allez prendre l'air, regarder la mer, et votre tête s'éclaircira. C'est ce qu'a dit le médecin : s'il revient à lui, il ne se souviendra de rien ; alors, vous ne vous souvenez pas, et ce n'est pas nécessaire.";
			link.l1     = "Un cas intéressant : et si ça ne revient pas ?";
			link.l1.go  = "Node_3";
		break;

		case "Node_2_Jess":
			dialog.text = "Oh, qu'y a-t-il à raconter... On vous l'avait dit, moi et le second : laissez tomber ce Beltrop, il va nous mener à notre perte. Rien à faire !.. Alors vous avez joué jusqu'à ce que ce type au masque vous envoie une balle derrière la tête ! Oui, grâce à Dieu et à votre magnifique chevelure, la balle est passée de biais. Seul l'os a été entamé, mais elle ne s'est pas logée dans le crâne, sinon vous n'auriez pas survécu ; il y avait beaucoup de sang, et vous avez perdu connaissance, c'était même une bonne chose : le Masque a cru que c'en était fini de vous. Le temps qu'il se précipite, nous avions déjà réussi à vous tirer des ruines de cette vieille église.";
			link.l1     = "Bon sang ! Le Masque a essayé de me tuer... On ne peut faire confiance à personne... Et Lawrence ? Il est vivant ?";
			link.l1.go  = "Node_3_Jess";
		break;

		case "Node_3":
			dialog.text = "Et s'il ne revient pas à lui, a-t-il dit, c'est fini : emmenez-le dans un asile d'aliénés et ne vous en occupez même plus. Car ce n'est plus une personnalité, c'est un dédoublement... Hopkins et moi, on se dit : comment peut-il ne pas être lui, puisqu'il est là ! Seulement, on dirait qu'il a une sacrée gueule de bois, il essaie de jurer tout le temps, mais sa langue fourche, et ses paroles sortent à la manière des indigènes. Croyez-moi, voilà six mois que nous vous parlons ainsi, et à la fin, nous avions déjà pris l'habitude de comprendre. Seulement, on a mis les armes hors de portée, et le médecin a interdit de vous les rendre...";
			link.l1     = "Qu'est-ce que tu racontes comme bêtises ? Tout ça m'est arrivé, à moi ?";
			link.l1.go  = "Node_4";
		break;

		case "Node_3_Jess":
			dialog.text = "Non, Dieu merci. Oh, pardon... On l'a pendu, c'est le Masque qui en a donné l'ordre. Et le Masque lui-même, dit-on, s'est fait dévorer par un requin. Pour moi, c'est là qu'ils devaient aller tous les deux. Les deux sont du même acabit : des crapules. Ils vous ont fait tant de mauvais sang, ces crapules !";
			link.l1     = "On ne dit pas de mal des morts... Et on ne peut pas ramener le passé. Dieu sera leur juge... Merci, mes frères, de m'avoir tiré de la tombe, je ne l'oublierai pas.";
			link.l1.go  = "Node_4_Jess";
		break;

		case "Node_4":
			dialog.text = "Je vous le jure sur la croix. Nous avons eu peur nous-mêmes : et si vous ne reveniez pas à vous, qu'allions-nous faire ? Et qu'est-ce que ces salauds au cul rouge vous ont fait avaler, bon sang ! Bon, Dieu merci, vous avez déjà repris des forces. Comment vous sentez-vous maintenant ?";
			link.l1     = "Ils m'ont fait avaler quelque chose, dis-tu... דa y ressemble beaucoup : je ne me souviens de rien... Laisse-moi rassembler mes idées et reprendre mes esprits. (créer votre propre type de héros).";
			link.l1.go  = "ChangePIRATES";
			link.l2     = "Oui, je me sens bien. J'ai juste un peu la tête qui tourne, comme si j'avais la gueule de bois...";
			link.l2.go  = "Node_5";
		break;

		case "Node_4_Jess":
			dialog.text = "C'est notre devoir, capitaine ! Hopkins et moi, nous avons porté notre capitaine jusqu'au navire et nous avons arrêté l'hémorragie du mieux que nous avons pu. Puis on a fait venir le médecin : il voulait vous couper les cheveux, mais nous ne l'avons pas laissé faire. Il avait peur que nous l'abattions si vous rendiez votre âme à Dieu, mais tout s'est bien passé : maintenant, vous êtes sur pied. Comment vous sentez-vous ?";
			link.l1     = "Hum... Donne-moi une minute pour rassembler mes idées... (créer votre propre type de héros).";
			link.l1.go  = "ChangePIRATES_Jess";
			link.l2     = "Il me semble que ça va mieux. Merci de te soucier de moi, Sandro.";
			link.l2.go  = "Node_5_Jess";
		break;

		case "Node_5":
			dialog.text = "Bon, l'alcool vous est interdit, sinon le dédoublement va recommencer. Mais ça ne ferait pas de mal de vous entraîner à l'épée. Vous avez sans doute déjà oublié par quel bout on la tient.";
			link.l1     = "Tu sais trouver les mots, toi. Bon, essayons, sinon je me sens comme un ours mal léché.";
			link.l1.go  = "Teach_1";
			link.l2     = "Ne t'inquiète pas, c'est ma tête qui a eu des problèmes, pas mes mains. Je vais aller au port, sinon je vais devenir complètement sauvage.";
			link.l2.go  = "Finish_1";
		break;

		case "Node_5_Jess":
			dialog.text = "Eh bien, vous voyez, je savais que tout irait bien... Mais une blessure à la tête ne passe pas sans laisser de traces, il faudra du temps et de la persévérance pour retrouver vos forces et vos talents. Vous voulez vous dégourdir le bras et vous exercer à l'escrime ?";
			link.l1     = "Bonne idée. Voyons si je tombe vraiment en ruine.";
			link.l1.go  = "Teach_1_Jess";
			link.l2     = "Non, je n'en ai pas envie. J'ai confiance en mes capacités.";
			link.l2.go  = "Finish_1";
		break;

		case "Finish_1":
			if (pchar.name == "Jessica")
			{
				dialog.text = "Nous sommes en ce moment au port de " + XI_ConvertString("Colony" + pchar.HeroParam.ToCityId) + ". Il faut commencer une nouvelle vie d'une façon ou d'une autre, sans tous ces Masques et ces Beltrop, qu'ils soient maudits... Enfin, qu'ils reposent en paix, je voulais dire... Et nous ne vous laisserons pas tomber, capitaine. Votre équipage restera avec vous jusqu'au bout.";
				link.l1     = "Eh bien, alors, vers un nouveau rêve ! Je ne vous laisserai pas tomber et je ne vous décevrai pas. Voilà, je descends à terre.";
				link.l1.go  = "Finish_2";
				link.l2     = "Des crapules seront remplacées par d'autres, c'est la vie, Sandro. Tu me donnes un conseil avant que je descende à terre ?";
				link.l2.go  = "Advice_1";
			}
			else
			{
				dialog.text = "Nous sommes maintenant au port de la colonie de " + XI_ConvertString("Colony" + pchar.HeroParam.ToCityId) + ", prenez vos marques, et revenez. Les vraies affaires nous ont beaucoup manqué : nous avons dמ vendre l'ancien navire, et on ne gagne pas grand-chose avec celui-ci. Alors, nous vivions dans l'attente de votre guérison. Et les gars croient en vous, sinon, ils se seraient enfuis depuis longtemps...";
				link.l1     = "Parfait. Voilà, je descends à terre... Ne t'inquiète pas tant, je ne suis plus un enfant : je ne vais pas me perdre.";
				link.l1.go  = "Finish_2";
				link.l2     = "Si tu penses que c'est encore trop tכt, dis-le. Un bon conseil ne sera pas de trop.";
				link.l2.go  = "Advice_1";
			}
		break;

		case "Advice_1":
			dialog.text = "Eh bien, cap'... Il faut radouber le navire, compléter l'équipage et faire des provisions. Et repartir en quête d'aventures ! Le mieux, bien sמr, serait d'obtenir une lettre de marque : ainsi, nous ne serons pas hors-la-loi si nous nous livrons à la piraterie, et nous pourrons dire honnêtement à nos familles que notre travail est tout à fait légal. Et ensuite, vous pourrez faire une belle carrière et rendre votre nom célèbre.";
			link.l1     = "Que faut-il savoir d'autre ?";
			link.l1.go  = "Advice_2";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_2":
			dialog.text = "Pour commercer avec profit, il faut connaître les prix actuels des marchandises dans les boutiques de l'archipel. Vous pouvez les découvrir en visitant les boutiques en personne, ou bien interroger les marchands que vous croisez en mer, ou écouter les rumeurs.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_3";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_3":
			dialog.text = "Les canons du navire peuvent tomber en panne, et il faudra alors les remplacer. Vous pouvez aussi retirer une partie des canons pour libérer de la place pour la cargaison.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_4";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_4":
			dialog.text = "Si nous devenons corsaires, gardez à l'esprit que les navires capturés en mer se vendent au chantier naval à vil prix, alors que ceux achetés honnêtement peuvent être revendus avec un bon bénéfice dans un autre chantier.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_5";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_5":
			dialog.text = "Ne vous brouillez pas pour rien avec les contrebandiers : ils procurent un bon revenu, même si c'est au péril de votre santé.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_6";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_6":
			dialog.text = "Engagez des officiers, nous n'en avons aucun. Si votre autorité est faible, vous ne pourrez pas engager beaucoup d'officiers. Dans ce cas, engagez ceux qui peuvent occuper deux ou trois postes à la fois. Trois touche-à-tout de ce genre suffiront à pourvoir tous nos postes.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_7";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_7":
			dialog.text = "Le vol est une chose peu reluisante, mais il peut arriver que vous ayez vraiment besoin de vider un coffre dans une maison, une banque ou une boutique. Essayez d'attendre que le propriétaire se détourne, et seulement alors, fouillez le coffre. Et souvenez-vous : si le propriétaire se retourne soudain et voit que vous fouillez son coffre, il y aura des ennuis. Alors, il faut être rapide !";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_8";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_8":
			dialog.text = "Vous pourriez avoir besoin de vous infiltrer dans une ville ennemie. Retenez bien ce que je vais vous dire : la nuit, il n'y a pas de soldats au port et aux portes pour contrכler tous ceux qui entrent en ville ! Alors, mieux vaut entrer dans une ville ennemie la nuit, et là, vous savez ce qu'il faut faire : ne vous faites pas prendre par la patrouille. Les soldats de la patrouille, d'ailleurs, n'ont pas d'yeux derrière la tête et ne voient que devant eux et sur les cכtés. La nuit, dans une ville ennemie, glissez-vous dans une taverne, passez-y la nuit jusqu'au matin, et réglez vos affaires dans la journée. Mais quand vous vous déplacez en ville, tenez-vous loin des soldats.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_9";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_9":
			dialog.text = "Vous pouvez aussi hisser un pavillon ennemi sur le navire, si vous en avez un, et compter sur votre chance et votre discrétion. Mais le moyen le plus sמr d'entrer sans danger dans une ville ennemie, c'est d'acheter une licence à une compagnie de commerce nationale : dans ce cas, personne ne vous retiendra. Cependant, n'oubliez pas de hisser le pavillon correspondant sur le navire. Vous savez, c'est idiot d'essayer de montrer une licence espagnole si le pavillon au mât est anglais.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Advice_10";
			link.l2     = "Parfait. Voilà, je descends à terre.";
			link.l2.go  = "Finish_2";
		break;

		case "Advice_10":
			dialog.text = "Sachez que les casemates se trouvent dans les forts, ne les cherchez pas dans les villes.";
			link.l1     = "Merci. Il est temps pour moi de descendre à terre.";
			link.l1.go  = "Finish_2";
		break;
		/////   фехт
		case "Teach_1":
			dialog.text = "Bon, commençons, peut-être. דa a toujours été votre point fort, mais je vais vous le rappeler. Il y a trois attaques : le coup normal, la fente et le coup puissant. Il y a aussi trois actions défensives : le blocage, la parade et la feinte. Il y a aussi le moulinet, défensif et offensif. Et, bien sמr, le pistolet, pour régaler l'ennemi de loin d'un thaler de plomb.";
			link.l1     = "Bon, bon, venons-en au fait.";
			link.l1.go  = "Teach_2";
		break;

		case "Teach_1_Jess":
			dialog.text = "Bon, commençons, peut-être. דa a toujours été votre point fort, mais je vais vous le rappeler. Il y a trois attaques : le coup normal, la fente et le coup puissant. Il y a aussi trois actions défensives : le blocage, la parade et la feinte. Il y a aussi le moulinet, défensif et offensif. Et, bien sמr, le pistolet, pour régaler l'ennemi de loin d'un thaler de plomb.";
			link.l1     = "C'est clair. Et ensuite ?";
			link.l1.go  = "Teach_2";
		break;

		case "Teach_2":
			dialog.text = "Toute action offensive demande de l'énergie ; les actions défensives n'en dépensent pas. On peut aussi esquiver les coups en bondissant en arrière et sur les cכtés. Mais on risque alors de prendre une balle si la distance augmente et que l'ennemi n'est pas un imbécile.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Teach_3";
			link.l2     = "Qu'est-ce que l'énergie ?";
			link.l2.go  = "Teach_2_1";
		break;

		case "Teach_2_1":
			dialog.text = "L'énergie indique la réserve de forces d'un personnage au corps à corps. Toutes les actions offensives demandent de l'énergie. Autrement dit, pendant le combat, le personnage se fatigue et a besoin d'une pause pour reprendre des forces. "+
						  "La valeur maximale de l'énergie dépend du niveau actuel de réaction du personnage.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Teach_3";
		break;

		case "Teach_3":
			dialog.text = "Pendant le combat, évitez de vous faire encercler par de nombreux adversaires, sinon vous finirez vite en steaks. On peut encore résister à deux, mais en abattre trois ou plus à la fois, c'est déjà difficile. Quand l'énergie des adversaires s'épuise, ils commencent à feinter et à parer. Attention, ne vous faites pas prendre : vous vous retrouveriez vite sans tête.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Teach_4";
		break;

		case "Teach_4":
			dialog.text = "Si un adversaire se laisse prendre à votre feinte, il subira des dégâts notables, plus qu'avec une fente. Si vous vous faites prendre à une parade, vous risquez de vous retrouver sans énergie. On vous fera perdre le rythme, et c'en est fini.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Teach_5";
		break;

		case "Teach_5":
			dialog.text = "Chacun a des armes différentes, réparties selon leur poids en légères, moyennes et lourdes. Le poids de l'arme détermine la dépense d'énergie. On peut manier une dague légère sans se fatiguer, mais avec une hache lourde, on peut envoyer plusieurs adversaires dans l'autre monde d'un seul coup circulaire.";
			link.l1     = "Ensuite.";
			link.l1.go  = "Teach_6";
		break;

		case "Teach_6":
			pchar.HeroParam.Teach_battle = 1;
			Tut_RestoreState();
			dialog.text = "Bon, on passe à la pratique ? Je vous propose de vous dégourdir les os. Nous nous battrons pour de vrai, mais pas à mort. La vie au combat peut être restaurée avec des élixirs, des potions ou du rhum, mais pour l'instant, vous feriez mieux de les garder : nous allons nous entraîner.";
			link.l1     = "Allez, n'attends pas de pitié !";
			link.l1.go  = "Teach_battle_1";
			link.l2     = "Non, merci. J'ai déjà compris.";
			link.l2.go  = "Finish_1";
		break;

		case "Teach_battle_lose":
			Tut_RestoreState();
			dialog.text = LinkRandPhrase("Oui... Vous avez bien perdu la main. Faites plus attention, bloquez et parez davantage. Ne restez pas bouche bée face au coup puissant : le blocage ne vous en protège pas, utilisez la feinte, la parade ou le bond.",
			                             "Ne vous laissez pas toucher : interceptez la fente de l'adversaire par une fente ou une parade. Mais attention : si vous vous laissez prendre à une feinte, on interceptera votre fente, et on vous la retournera.",
										 "Si l'énergie vient à manquer, fuyez ou bondissez en arrière, et prenez l'ennemi par une feinte. Gardez à l'esprit qu'une feinte n'est pas si facile à repousser, mais qu'elle permet de tromper l'ennemi. Et s'il se laisse prendre à votre ruse et tente de répondre par un coup à votre geste trompeur, non seulement vous détournerez sa lame, mais vous le blesserez vous-même.");
			if (sti(pchar.rank) < 3) // чтоб не качались до упора
			{
				link.l1     = "Encore une fois !";
				link.l1.go  = "Teach_battle_1";
			}
			link.l2     = "Non, ça suffit. J'ai tout compris.";
			link.l2.go  = "Finish_1";
		break;

		case "Teach_battle_win":
			pchar.HeroParam.Teach_battle = 2;
			Tut_RestoreState();
			dialog.text = "Bien. Bravo ! Gardez à l'esprit que je me suis battu loyalement, mais les ennemis peuvent avoir leurs propres élixirs de vie, et ils ne se laisseront pas battre si facilement. " +
						  "Bon, compliquons la tâche. On passe à deux adversaires ?";
			link.l1     = "Eh bien, allons-y. Hé, Hopkins ! Prends ton coutelas et cours sur le pont !";
			link.l1.go  = "Teach_battle_1";
			link.l2     = "Non, merci. J'ai eu ma dose d'entraînement.";
			link.l2.go  = "Finish_1";
		break;

		case "Teach_battle_win_2":
			Tut_RestoreState();
			sld = characterFromID("Sailor_2");
			LAi_SetCitizenType(sld);
			if (pchar.name == "Jessica")
			{
				dialog.text = "Parfait, capitaine ! Les leçons de Beltrop n'ont pas été vaines, il vous a bien appris. Et un dernier conseil : plus vous ferraillez avec un même type d'arme, plus votre talent grandit. Si vous voulez retrouver la maîtrise de tous les types, changez plus souvent de type d'arme.";
			}
			else
			{
				dialog.text = "Oui, tout va bien avec vos mains : ce n'est pas pour rien qu'on avait caché les armes. Et un dernier conseil : plus vous ferraillez avec un même type d'arme, plus votre talent grandit. Si vous voulez exceller dans tous les types, changez plus souvent de type de lame.";
			}
			link.l1     = "Merci !";
			link.l1.go  = "Finish_1";
		break;

		case "Teach_battle_win_3":
			Tut_RestoreState();
			sld = characterFromID("Sailor_2");
			LAi_SetCitizenType(sld);
			dialog.text = "Eh bien, pas mal. Vous avez vaincu un adversaire, mais deux, ce n'est pas un. Il faut le coup de main. Les ennemis peuvent attaquer à trois ou quatre ensemble. On recommence ?";
   			if (sti(pchar.rank) < 3) // чтоб не качались до упора
			{
				link.l1     = "Encore une fois !";
				link.l1.go  = "Teach_battle_1";
			}
			link.l2     = "Non, j'ai déjà compris.";
			link.l2.go  = "Finish_1";
		break;

		//Альтернативные старты
		case "Alt_start":
			EndQuestMovie();
			LAi_LockFightMode(Pchar, false);
			LAi_SetActorTypeNoGroup(Pchar);
			LAi_ActorTurnToCharacter(Pchar, NPChar);
			dialog.text = "Oh, regardez qui se réveille ! Je croyais que tu étais "+ GetSexPhrase("mort !", "morte !");
			link.l = "Qu'est-ce qui se passe, bordel, qui êtes-vous ?";
			link.l.go = "Alt_start_2";
		break;

		case "Alt_start_2":
			if (pchar.sex != woman) LAi_CharacterPlaySound(NPChar, "Welcome_Fucking_Event1");
			else LAi_CharacterPlaySound(NPChar, "Welcome_Fucking_Event2");
			dialog.text = "Bienvenue dans les Caraïbes, " + GetSexPhrase("fils de chienne !", "garce chauve !")+" Et qui je suis ? דa ne te regarde pas ! Je suis ton bug.";
			link.l = "Je ne me souviens de rien... Quelles Caraïbes ?";
			link.l.go = "Alt_start_3";
		break;

		case "Alt_start_3":
			dialog.text = "Mon Dieu, sur "+GetSexPhrase("quel idiot", "quelle idiote")+" je suis tombé, misère... Remets vite tes idées en place !";
			link.l = "(créer votre propre type de héros)";
			link.l.go = "ChangePIRATES_Alt";
		break;

		case "ChangePIRATES_Alt":
            LAi_SetCitizenTypeNoGroup(NPChar);
            LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = "Alt_start_4";
			DialogExit();
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		case "Alt_start_4":
			dialog.text = "Bravo ! Maintenant, file au port, va prendre l'air !";
			link.l = "(doucement) Espèce d'enfoiré !";
			link.l.go = "Finish_2";
		break;

		case "Alt_start2":
			EndQuestMovie();
			LAi_LockFightMode(Pchar, false);
			LAi_SetActorTypeNoGroup(Pchar);
			LAi_ActorTurnToCharacter(Pchar, NPChar);
			dialog.text = "Salutations, héros ! Notre quête de l'« Amulette du Nécromancien » touche à sa fin.";
			link.l = "Qu'est-ce qui se passe ici ?! Quelle amulette ? Qui êtes-vous ?";
			link.l.go = "Alt_start2_2";
		break;

		case "Alt_start2_2":
			dialog.text = "Une minute... Vérification... Oh, merde ! Je me suis trompé. Bonne partie, désolé pour le dérangement ! Au revoir !";
			link.l = "Halte ! Qu'est-ce que ça veut dire ? Et l'entraînement ? La distribution PIRATES ?";
			link.l.go = "Alt_start2_3";
		break;

		case "Alt_start2_3":
			dialog.text = "Bon, bon. Qui êtes-vous dans la vie ?";
			link.l = "(créer votre propre type de héros)";
			link.l.go = "ChangePIRATES_Alt2";
		break;

		case "ChangePIRATES_Alt2":
            LAi_SetCitizenTypeNoGroup(NPChar);
            LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = "Alt_start2_4";
			DialogExit();
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		case "Alt_start2_4":
			dialog.text = "Vous avez décidé ? Voilà, allez au port, reprenez vos esprits. Bonne journée !";
			link.l = "Je ne comprends rien. Bon, d'accord...";
			link.l.go = "Finish_2";
		break;
	}
}
