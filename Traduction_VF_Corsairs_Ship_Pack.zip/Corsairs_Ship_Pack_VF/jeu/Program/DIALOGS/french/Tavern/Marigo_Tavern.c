// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 8 - the Beausing house and the missing Secretary
			if (CheckAttribute(PChar, "RaulEsperanto"))
			{
				if (PChar.RaulEsperanto == "7")
				{
					link.l30 = "Je cherche un homme nommé Jan Beausing. Oם dois-je le chercher ?";
					link.l30.go = "BO_RE_Mar_1";
				}
			}
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//виспер
			if(CheckAttribute(pchar, "Whisper.FindDesouzaHol"))
			{
				DeleteAttribute(pchar, "Whisper.FindDesouzaHol")
				link.l1 = "Dites, des types à l'allure suspecte sont-ils venus vous voir ici ? Ils doivent aussi avoir une marque en forme de crucifix sur le bras.";
				link.l1.go = "FindDesouzaHol";
				break;
			}
			//виспер
			
			// ==> Анжелика Тич: Портниха знатной дамы
			if(CheckAttribute(pchar, "questTemp.AT_PZD_taverna"))
			{
				DeleteAttribute(pchar, "questTemp.AT_PZD_taverna")
				link.l1 = "Il y a des Espagnols parmi vos clients. Savez-vous d'oם ils venaient, ou sur quel navire ils sont arrivés ?";
				link.l1.go = "AT_PZD_taverna_1";
				break;
			}
			// <== Анжелика Тич: Портниха знатной дамы

			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "SeekChumakeiro_ToAaronHouse": //Голландская линейка, квест №1. поиски Чумакейро.
                    link.l1 = HeroStringReactionRepeat("Dites, un certain Aaron Mendes Chumaqueiro séjourne à Marigot. Vous connaissez quelqu'un comme ça ?",
                    "Je parle d'Aaron... nous en avons déjà parlé, désolé.", "Aaron, Aa-a-aro-o-n...", "On en a fini avec Aaron, désolé...", npchar, Dialog.CurrentNode);
                    link.l1.go = DialogGoNodeRepeat("Step_H1_1", "", "", "", npchar, Dialog.CurrentNode);
                break;

            }
            // <== Проверяем поле состояния квестов.

 		break;
		//============ Анжелика Тич: Портниха знатной дамы
		case "AT_PZD_taverna_1":
    		dialog.text = "Je ne suis pas d'humeur à bavarder avec les clients en ce moment. Des Espagnols, des Portugais... le diable des mers lui-même n'est même pas passé aujourd'hui.";
    		link.l1 = "Alors les affaires marchent bien ?";
    		link.l1.go = "AT_PZD_taverna_2";
 		break;
		case "AT_PZD_taverna_2":
    		dialog.text = "Ce serait un péché de se plaindre. Ici, chaque soir, le gouverneur donne des réceptions à la résidence en l'honneur de la majorité de ses filles. Tantכt c'est un ambassadeur qui arrive, tantכt quelqu'un d'autre qui en amène un, et tout ce monde arrive en bateau. Les marins ne manquent pas, il faut juste avoir le temps de servir les plateaux. Vous feriez mieux d'aller à la capitainerie, tous les capitaines y sont inscrits. Ah ! Je n'ai rien à vous dire.";
			link.l1 = "Oui, je crois que c'est ce que je vais faire.";
    		link.l1.go = "exit";
 		break;
        //============ Голландская линейка, квест №1. поиски Чумакейро.
 		case "Step_H1_1":
    		dialog.text = "Je sais. Je lui ai trouvé une maison convenable à louer. Un brave homme, il a bien payé...";
    		link.l1 = "Compris... Et oם est cette maison qu'Aaron a louée ?";
    		link.l1.go = "Step_H1_2";
 		break;
 		case "Step_H1_2":
    		dialog.text = "Entre le bordel et la résidence de la Compagnie néerlandaise des Indes occidentales. Une petite maison en brique, un peu délabrée de l'extérieur. Mais à l'intérieur, tout va bien, " + npchar.name + " ne fait de mal à personne.";
    		link.l1 = "Merci, je vais aller rendre visite à cet Aaron.";
    		link.l1.go = "Step_H1_3";
 		break;
 		case "Step_H1_3":
    		dialog.text = "Faites la queue.";
    		link.l1 = "Comment ça ?";
    		link.l1.go = "Step_H1_4";
 		break;
 		case "Step_H1_4":
    		dialog.text = "C'est comme ça qu'il faut le comprendre : faites la queue pour rendre visite à Aaron. Quelqu'un a déjà demandé après lui et, apparemment, est allé le voir.";
    		link.l1 = "Qui ?";
    		link.l1.go = "Step_H1_5";
 		break;
 		case "Step_H1_5":
    		dialog.text = "Un inconnu, je l'ai vu pour la première fois dans notre ville. Aaron tient porte ouverte aujourd'hui, hé hé.";
    		link.l1 = "Oh, on dirait que... Bon, merci encore. Au revoir.";
    		link.l1.go = "exit";
 		break;
		case "FindDesouzaHol":
    		dialog.text = "Pas à moi, mais des types correspondant à cette description ont importuné ma serveuse. Vous pouvez lui demander les détails.";
    		link.l1 = "D'accord, merci.";
			pchar.Whisper.FindDesouzaHolWaitress = true;
    		link.l1.go = "exit";
 		break;



		// Gregg: The Black Orchid, chapter 8 -->
		case "BO_RE_Mar_1":
			dialog.text = "Beausing ? Un banquier. Un homme tranquille, qui paie d'avance, et les gens viennent sans cesse le voir avec du fer sur eux. Pour trouver sa maison : contournez la taverne, montez un peu la route, puis tournez à gauche. Quelques marches, et une porte en haut. Personne ne passe cette porte.";
			link.l1 = "Et il les reçoit tous ?";
			link.l1.go = "BO_RE_Mar_2";
		break;

		case "BO_RE_Mar_2":
			dialog.text = "Il ne reçoit personne. C'est à ça que sert le Secrétaire. Un grand gaillard, deux lames. C'est lui qui les reçoit, et ensuite, quelqu'un fait le ménage.";
			link.l1 = "Alors il faut que je parle au Secrétaire.";
			link.l1.go = "BO_RE_Mar_3";
		break;

		case "BO_RE_Mar_3":
			dialog.text = "Il le faut, seulement on ne l'a pas vu depuis trois jours. Il est parti vers les grottes, au-delà de la colonie, et il n'est jamais revenu. Beausing reste seul et n'ouvre pas sa porte.";
			link.l1 = "Les grottes. Je vais aller voir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoFindSecretary");
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

