void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref rItem, rChar, sld, MerPrm;
	aref arTemp1, arTemp2;
	bool bTemp;
	int iBanditsCount, i, iMoney, iNation, iTmp, iGoods;
	String sTitle, sGroup, sTemp;
	float locx, locy, locz;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Bug manifeste. Comment est-il arrivé ici ? Signalez-le à Warship et racontez en détail comment vous l'avez obtenu.";
					link.l1 = RandSwear() + "Je vous en informerai, c'est certain !";
					link.l1.go = "exit";

			if(HasSubStr(NPChar.id, "ContraMeetManQuest_Soldier_")) // Солдеры по квесту "meeting at the bay"
			{
				dialog.text = "Je ne suis pas autorisé à vous parler. Adressez-vous à notre officier.";
					link.l1 = LinkRandPhrase("Bien sמr...", "Je vois.", "Sans faute !");
					link.l1.go = "exit";
				break;
			}

			if(HasSubStr(NPChar.id, "ContraMeetManQuest_Officer_")) // Офицер по квесту "meeting at the bay"
			{
				dialog.text = "Présentez-vous, je veux savoir à qui j'ai affaire !";
					link.l1 = "Je m'appelle " + GetFullName(PChar) + ". Que se passe-t-il ici ?";
					link.l1.go = "ContraMeetManQuest_Sold_1";
				break;
			}

			if(NPChar.id == "ContraMeetManQuest_QuestMan" && PChar.location == PChar.GenQuest.ContraMeetMan.ShoreID) // Квестовый чел по генеру "meeting at the bay"
			{
				dialog.text = "Cap', vous vous appelez " + GetFullName(PChar) + ", n'est-ce pas ?";
					link.l1 = "Oui, c'est ça...";
					link.l1.go = "ContraMeetManQuest_1";
					link.l2 = "Non. Vous me confondez avec quelqu'un d'autre...";
					link.l2.go = "exit";
					break;
			}

			if(NPChar.id == "ContraMeetManQuest_QuestMan" && CheckAttribute(PChar, "GenQuest.ContraMeetMan.ContraIsDead")) // В комнате таверны после убицства контриков
			{
				LAi_LocationFightDisable(LoadedLocation, false);
				dialog.text = PChar.name + ", merci infiniment ! Sans vous, mon sort aurait été lamentable... Comment puis-je vous remercier ?";
					link.l1 = "Je n'ai besoin de rien...";
					link.l1.go = "ContraMeetManQuest_7";
					link.l2 = "Je ne refuserais pas une petite récompense.";
					link.l2.go = "ContraMeetManQuest_8";
					break;
			}

			if(NPChar.id == "ContraMeetManQuest_Contrick_0") // Контрик в комнате по квесту "meeting at the bay"
			{
				iMoney = (rand(3)+2)*500;
				PChar.GenQuest.ContraMeetMan.Money = iMoney;
				if(!CheckAttribute(PChar, "GenQuest.ContraMeetMan.ManIsTraitor")) // Просто платят деньги
				{
					dialog.text = "...Hum, en effet, c'est bien ça... Merci, "+ GetSexPhrase("le gars","la fille") +", sans ton aide, on aurait eu du mal : toutes les sorties de la ville nous sont bloquées. Tiens, prends " + FindRussianMoneyString(iMoney) + " et tu peux filer. Et nous, on va aller causer avec notre ami...";
						link.l1 = "...";
						link.l1.go = "ContraMeetManQuest_3";
				}
				else
				{
					dialog.text = "...Hum, en effet, c'est bien ça... Merci, "+ GetSexPhrase("le gars","la fille") +", sans ton aide, on aurait eu du mal : toutes les sorties de la ville nous sont bloquées. Tiens, prends " + FindRussianMoneyString(iMoney) + " et file. Ne nous empêche pas d'étriper ce traître !...";
						link.l1 = "Bien sמr. א plus tard, messieurs...";
						link.l1.go = "ContraMeetManQuest_4";
						link.l2 = "Quoi ?! Non, je ne permettrai pas qu'on commette un meurtre, qui que ce soit... Et je n'ai pas besoin de votre argent sale !";
						link.l2.go = "ContraMeetManQuest_5";
				}
					break;
			}

			if(NPChar.id == "ContraDeliverQuest_Soldier_0") // Солдер в комнате
			{
				dialog.text = "Tiens, tiens, tiens... Qu'avons-nous là ?! Des pirates ?! Vous allez devoir nous suivre à la commandanture pour être jugés...";
					link.l1 = "Nous ne sommes pas du tout des pirates ! Je ne connais même pas cet homme ! Il vient juste de s'installer dans cette chambre !";
					link.l1.go = "ContraDeliverQuest_Sold1";
					break;
			}

			if(CheckAttribute(PChar, "GenQuest.ContraDeliver.WaitOnRoom") && NPChar.id == "ContraDeliverQuest_Contra_1")
			{
				dialog.text = "Alors, qu'est-ce que vous disiez ? Vous devez me transmettre un message ?! Allez-y, alors !";
					link.l1 = "Tenez...";
					link.l1.go = "ContraDeliverQuest_1";
					DeleteAttribute(PChar, "GenQuest.ContraDeliver.WaitOnRoom");
					DeleteAttribute(PChar, "GenQuest.ContraDeliver.GoToTavern");
					break;
			}

			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.BanditsInShore") && NPChar.id == "Church_GenQuest2_Bandit_0")
			{
				dialog.text = "Hé, toi ! Oui, toi. Je vois que tu es quelqu'un de convenable, "+ GetSexPhrase("mon gars","ma fille") + ", et pas dans le besoin.";
					link.l1 = "Je prendrais ça pour un compliment, si ça ne venait pas d'un escroc comme toi.";
					link.l1.go = "Church_GenQuest_2_ShoreBandit_1";
					break;
			}

			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.WayOfShortVariant") && NPChar.id == "Church_GenQuest2_Bandit_0")
			{
				dialog.text = "Halte ! Allez, "+ GetSexPhrase("l'ami","ma petite") +" ! Montre-moi si ta bourse n'est pas trop lourde !";
					link.l1 = "Tu as déjà mis la main sur l'argent de l'église ?";
					link.l1.go = "Church_GenQuest_2_1";
					break;
			}

			if(NPChar.id == "ReasonToFast_Hunter")
			{
				if(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) > sti(pchar.questTemp.ReasonToFast.p2))
				{
					dialog.text = "Hé-hic, dans la chaloupe ! Dégagez le chenal, j'ai besoin de parler aux gars...";
					link.l1 = "Tu as bien fait la fête, l'ami. Va cuver.";
					link.l1.go = "ReasonToFast_Hunter1";
				}
				else
				{
					dialog.text = "Hé, cap' ! Jette l'ancre, on est arrivés...";
					link.l1 = "Et pourquoi donc...";
					link.l1.go = "ReasonToFast_Hunter2";
				}
				link.l2 = "א qui crois-tu parler sur ce ton !?";
				link.l2.go = "ReasonToFast_Hunter3";
			}

			if(NPChar.id == "Convict_0")
			{
				dialog.text = LinkRandPhrase("Attendez, "+ GetAddress_Form(pchar) +" ! M'accorderiez-vous un instant de votre précieuse attention ?","Le noble capitaine ne voudrait-il pas écouter l'humble requête de ses indignes interlocuteurs ?","Noble capitaine, accordez deux minutes de votre précieux temps pour parler à des déshérités.");
				link.l1 = LinkRandPhrase("Je n'ai pas le temps.", "וcartez-vous, j'ai assez de soucis sans vous.", "Fichez-moi la paix. Je n'ai pas de temps pour vous.");
				link.l1.go = "Convict_0End";
				link.l2 = LinkRandPhrase("Que voulez-vous ?", "Que voulez-vous ?", "Qu'y a-t-il ?");
				link.l2.go = "Convict_Begin";
			}
		break;

		// Генератор "The situation in the hold is a ransom"
		case "Hold_GenQuest1":
			pchar.quest.Hold_GenQuest_FindCharTimeIsOver.over = "yes";
			dialog.text = "Je vous écoute, capitaine. Vous êtes là pour affaires ?";
			link.l1 = "Je cherche " + pchar.GenQuest.Hold_GenQuest.Name + " ?";
			link.l1.go = "Hold_GenQuest2";
		break;

		case "Hold_GenQuest2":
			dialog.text = RandPhraseSimple("Je suis " + pchar.GenQuest.Hold_GenQuest.Name + ". א qui ai-je l'honneur, je vous prie ?","Vous l'avez trouvé. Que puis-je faire pour vous ?");
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ", j'ai une affaire à vous exposer au sujet de " + pchar.GenQuest.Hold_GenQuest.CapName + ".";
			link.l1.go = "Hold_GenQuest3";
		break;

		case "Hold_GenQuest3":
			sld = characterFromId(pchar.GenQuest.Hold_GenQuest.CapId);
			pchar.GenQuest.Hold_GenQuest.RansomSum = makeint(3 * sti(sld.rank) * (800 + GetCharacterSPECIALSimple(NPChar, SPECIAL_L) * 100) + GetCharacterSkillToOld(sld, "Leadership")*500 + GetCharacterSkillToOld(pchar, "commerce")*500);

			switch(drand(3))
			{
				case 0:
					dialog.text = "Qui est-ce ?";
					link.l1 = "Attendez, vous êtes bien " + pchar.GenQuest.Hold_GenQuest.Name + ", et vous ne savez pas qui est " + pchar.GenQuest.Hold_GenQuest.CapName + " ?";
					link.l1.go = "Hold_GenQuest40";
				break;
				case 1:
					dialog.text = "Oh, ça faisait longtemps qu'on n'avait pas eu de nouvelles de ce vieux filou ! Que lui est-il arrivé cette fois ?";
					link.l1 = "Il a de gros ennuis cette fois... Il a été capturé et il demande votre aide.";
					link.l1.go = "Hold_GenQuest50";
				break;
				case 2:
					dialog.text = "Bien, je vous écoute attentivement.";
					link.l1 = "Son navire a été attaqué par des pirates ; il a été capturé et m'a proposé de vous demander une rançon.";
					link.l1.go = "Hold_GenQuest60";
				break;
				case 3:
					dialog.text = "Oui, ça me fait plaisir d'avoir des nouvelles d'un vieil ami. Comment va-t-il ?";
					link.l1 = "Il est dans une situation si difficile qu'on a du mal à l'imaginer.";
					link.l1.go = "Hold_GenQuest70";
				break;
			}
		break;

		case "Hold_GenQuest40":
			dialog.text = "Vous avez tout à fait raison, je suis " + pchar.GenQuest.Hold_GenQuest.Name + " ! Mais pourquoi devrais-je connaître " + pchar.GenQuest.Hold_GenQuest.CapName + " ?!";
			link.l1 = "Désolé, il doit y avoir une erreur...";
			link.l1.go = "Hold_GenQuest41";
		break;

		case "Hold_GenQuest41":
			AddQuestRecord("HoldQuest", "10");
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.CapName);
			pchar.GenQuest.Hold_GenQuest = "prisoner_escaped";
			LAi_CharacterDisableDialog(NPChar);
			NPChar.LifeDay = 0;
			DialogExit();
			AddDialogExitQuestFunction("Hold_GenQuest_PrisonerEscaped");
		break;

		case "Hold_GenQuest50":
			dialog.text = "דa alors ! Et comment vais-je l'aider ? On ne devrait pas plutכt le libérer en tuant tous ses ennemis, ha ha ha ?";
			link.l1 = "Non, ce ne sera pas nécessaire... Il vous suffit de verser " + pchar.GenQuest.Hold_GenQuest.RansomSum + " pièces d'or de rançon.";
			link.l1.go = "Hold_GenQuest51";
		break;

		case "Hold_GenQuest51":
			dialog.text = "C'est le comble de l'insolence ! Pourquoi diable devrais-je payer une rançon pour lui ?! Qu'est-il pour moi, au juste ?!";
			link.l1 = "Hum, et il m'a dit que vous étiez son dernier espoir. Il a aussi fait allusion à une sorte de dette...";
			link.l1.go = "Hold_GenQuest52";
		break;

		case "Hold_GenQuest52":
			dialog.text = LinkRandPhrase("Oh, quel effronté ! C'est lui qui me doit une jolie somme ! Mais ce n'est pas une raison pour payer sa rançon en espérant qu'il me rembourse les deux dettes.",
				"Quelle canaille, non ?! Non seulement il m'a volé quand nous avons partagé l'affaire, mais il a en plus le culot de demander une rançon !",
				"דa alors ! Pourquoi diable devrais-je débourser pour lui ?! Nous ne nous connaissons pas si bien que ça.");
			link.l1 = "Dois-je donc lui dire que vous refusez de payer la rançon et que vous ne reconnaissez pas votre dette ?";
			link.l1.go = "Hold_GenQuest53";
		break;

		case "Hold_GenQuest53":
			dialog.text = "Mon Dieu ! Mais quelle dette ?! Je vous ai déjà tout expliqué ! Et de toute façon, si vous n'avez pas d'autres questions que cette histoire stupide, permettez-moi de prendre congé.";
			link.l1 = "Eh bien, je n'ai plus de questions pour vous... Mais j'en aurais eu beaucoup pour votre ami...";
			link.l1.go = "Hold_GenQuest54";
		break;

		case "Hold_GenQuest54":
			AddQuestRecord("HoldQuest", "10");
			AddQuestUserData("HoldQuest", "sName", GetFullName(NPChar));
			pchar.GenQuest.Hold_GenQuest = "prisoner_escaped";
			LAi_CharacterDisableDialog(NPChar);
			NPChar.LifeDay = 0;
			DialogExit();
			AddDialogExitQuestFunction("Hold_GenQuest_PrisonerEscaped");
		break;

		case "Hold_GenQuest60":
			dialog.text = "Hum, alors c'est vous qui"+ GetSexPhrase("","") +" le retenez... Eh bien, je serai ravi de l'aider.";
			link.l1 = "Parfait. Le montant de la rançon est de " + pchar.GenQuest.Hold_GenQuest.RansomSum + " pièces d'or.";
			link.l1.go = "Hold_GenQuest61";
		break;

		case "Hold_GenQuest61":
			dialog.text = "Vous m'avez mal compris : vous parlez à un membre du conseil municipal chargé de veiller au respect de la charte. " +
				"Gardes !!! Gardes ! Arrêtez "+ GetSexPhrase("cette personne","cette femme") +" pour traite d'esclaves et piraterie contre les navires de " + NationNameGenitive(sti(pchar.GenQuest.Hold_GenQuest.Nation)) + " !";
			link.l1 = "Eh bien, « camarade », je te retrouverai...";
			link.l1.go = "Hold_GenQuest62";
		break;

		case "Hold_GenQuest62":
			LAi_SetImmortal(NPChar, false);
			AddQuestRecord("HoldQuest", "10");
			AddQuestUserData("HoldQuest", "sName", GetFullName(NPChar));
			pchar.GenQuest.Hold_GenQuest = "prisoner_escaped";
			LAi_SetWarriorTypeNoGroup(NPChar);
   	        LAi_warrior_DialogEnable(NPChar, false);
            LAi_group_MoveCharacter(NPChar, "TmpEnemy");
			LAi_group_Attack(NPChar, Pchar);
			LAi_group_SetRelation("TmpEnemy", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_SetCheckFunction("TmpEnemy", "Hold_GenQuest_AfterBattle");
			chrDisableReloadToLocation = true;
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			AddDialogExitQuest("MainHeroFightModeOn");
			AddDialogExitQuestFunction("Hold_GenQuest_PrisonerEscaped");
			DialogExit();
		break;

		case "Hold_GenQuest70":
			dialog.text = "Que dites-vous ?! Puis-je faire quelque chose pour l'aider ?";
			link.l1 = "Il a été capturé et m'a demandé de vous parler de la rançon.";
			link.l1.go = "Hold_GenQuest71";
		break;

		case "Hold_GenQuest71":
			dialog.text = "Bien sמr, bien sמr. Je ferai tout mon possible. Oם est-il ? De quelle somme parle-t-on ?";
			link.l1 = "Les pirates exigent " + pchar.GenQuest.Hold_GenQuest.RansomSum + " pièces d'or. Je dois apporter l'argent au port, et votre ami sera libre.";
			link.l1.go = "Hold_GenQuest72";
		break;

		case "Hold_GenQuest72":
			dialog.text = "Voici l'argent. Heureusement, j'avais assez sur moi.";
			link.l1 = "Oui, ça s'est vraiment bien passé. Allez au port, vous reverrez bientכt votre ami.";
			link.l1.go = "Hold_GenQuest73";
		break;

		case "Hold_GenQuest73":
			addMoneyToCharacter(pchar, sti(pchar.GenQuest.Hold_GenQuest.RansomSum));
			AddQuestRecord("HoldQuest", "11");
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.CapName);
			AddQuestUserData("HoldQuest", "sNameChar", pchar.GenQuest.Hold_GenQuest.Name);
			AddQuestUserData("HoldQuest", "sSum", pchar.GenQuest.Hold_GenQuest.RansomSum);
			pchar.GenQuest.Hold_GenQuest = "prisoner_ransom";
			LAi_CharacterDisableDialog(NPChar);
			NPChar.LifeDay = 0;
			DialogExit();
			AddDialogExitQuestFunction("Hold_GenQuest_PrisonerEscaped");
		break;
		// Генератор "The situation in the hold is a ransom"

		// Генератор "The situation in the hold is an accomplice"
		case "Hold_GenQuest80":
			dialog.text = "Bonjour, capitaine, je n'ai pas eu l'honneur de vous être présenté. On m'a dit que vous me cherchiez.";
			link.l1 = "C'est exact, si vous êtes maître " + pchar.GenQuest.Hold_GenQuest.Name + ". Je me présente : capitaine " + GetFullName(pchar) + ", et je voulais vous parler d'une affaire.";
			link.l1.go = "Hold_GenQuest81";
		break;

		case "Hold_GenQuest81":
			dialog.text = "Et de quelle affaire s'agit-il, capitaine " + GetFullName(pchar) + " ?";
			link.l1 = "J'ai entendu dire que vous aviez quelque chose dont vous aimeriez vous débarrasser.";
			link.l1.go = "Hold_GenQuest82";
		break;

		case "Hold_GenQuest82":
			dialog.text = "Qu'est-ce que vous insinuez ?";
			link.l1 = "N'insistez pas, mon cher, je sais tout de votre sombre passé, et de la carte faite maison qui indique oם se trouve le trésor de " + GetName( NAMETYPE_VIP, pchar.GenQuest.Hold_GenQuest.PirateName, NAME_ACC) + " – inutile de nier.";
			link.l1.go = "Hold_GenQuest83";
		break;

		case "Hold_GenQuest83":
			dialog.text = "Oh, bon sang ! Je savais que cette canaille de " + pchar.GenQuest.Hold_GenQuest.CapName + " finirait tכt ou tard par vendre la mèche ! Et j'avais la langue qui me démangeait de lui proposer cette affaire !";
			link.l1 = "Bon, arrêtez de gémir. Je ne vous veux pas de mal... Vendez-moi cette carte, et continuez à vivre comme avant.";
			link.l1.go = "Hold_GenQuest84";
		break;

		case "Hold_GenQuest84":
			dialog.text = "Hum, ce serait bien si c'était le cas... Et combien m'en donnerez-vous ? N'oubliez pas qu'il y avait beaucoup d'or dans ce coffre : il a fallu quatre hommes pour le traîner jusqu'à l'endroit... Que Dieu ait leur âme...";
			link.l1 = "Mais, " + GetName( NAMETYPE_VIP, pchar.GenQuest.Hold_GenQuest.PirateName, NAME_NOM) + " aurait pu reprendre son trésor... ";
			link.l1.go = "Hold_GenQuest85";
		break;

		case "Hold_GenQuest85":
			dialog.text = "Vous avez raison... Eh, tant pis : pour " + pchar.GenQuest.Hold_GenQuest.Sum + " piastres, je vous la cède. De toute façon, je n'oserai jamais déranger les morts moi-même.";
			if(sti(pchar.money) >= sti(pchar.GenQuest.Hold_GenQuest.Sum) && !CheckCharacterItem(pchar,"mapQuest") && !CheckCharacterItem(pchar,"map_full"))
			{
				link.l1 = "Soit, marché conclu...";
				link.l1.go = "Hold_GenQuest86";
			}
			link.l2 = "Non, mon cher, votre bout de papier ne vaut pas autant d'argent. Adieu...";
			link.l2.go = "Hold_GenQuest87";
			pchar.quest.Hold_GenQuest_GetMapTimeIsOver.over = "yes";
		break;

		case "Hold_GenQuest86":
			AddMoneyToCharacter(pchar, -sti(pchar.GenQuest.Hold_GenQuest.Sum));
			GiveItem2Character(pchar, "mapQuest");
			rItem = ItemsFromID("mapQuest");
			Hold_GenQuest_GenerateTreasureMap(rItem);
			AddQuestRecord("HoldQuest", "15");
			AddQuestUserData("HoldQuest", "sPirateName", GetName( NAMETYPE_VIP, pchar.GenQuest.Hold_GenQuest.PirateName, NAME_ACC));
			AddQuestUserData("HoldQuest", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("HoldQuest", "sSum", pchar.GenQuest.Hold_GenQuest.Sum);
			NPChar.LifeDay = 0;
			LAi_CharacterDisableDialog(NPChar);
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Hold_GenQuest87":
			NPChar.LifeDay = 0;
			LAi_CharacterDisableDialog(NPChar);
			AddQuestRecord("HoldQuest", "16");
			AddQuestUserData("HoldQuest", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.Name);
			AddQuestUserData("HoldQuest", "sSum", pchar.GenQuest.Hold_GenQuest.Sum);
			CloseQuestHeader("HoldQuest");
			DeleteAttribute(pchar,"GenQuest.Hold_GenQuest");
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;
		// Генератор "The situation in the hold is an accomplice"

		// Генератор "Castaways"
		case "Convict_0End":
			DialogExit();
			pchar.GenQuest.Convict = "close";
			chrDisableReloadToLocation = false;
			ChangeCharacterReputation(pchar, -1);
			AddDialogExitQuestFunction("Convict_DialogDisable");
		break;

		case "Convict_Begin":
			switch(sti(pchar.GenQuest.Convict.var))
			{
				case 0:
					dialog.text = "Capitaine, aidez-nous à trouver une chaloupe ou une tartane, peu importe. Les circonstances nous obligent à quitter cet endroit inhospitalier, et nous ne pouvons pas nous montrer dans la colonie.";
					link.l1 = "Et quelles sont ces circonstances ?";
					link.l1.go = "Convict_11";
				break;
				case 1:
					dialog.text = "Capitaine, pourriez-vous nous prêter quelques centaines de piastres ? Nous ne l'aurions pas demandé, mais le besoin nous y oblige.";
					link.l1 = "Le besoin, vous dites ? Moi, je n'ai plus de rhum : voilà mon seul besoin.";
					link.l1.go = "Convict_12";
				break;
				case 2:
					pchar.GenQuest.Convict.ToCity = FindColonyWithMayakExceptIsland(GetCharacterCurrentIslandId(pchar));
					pchar.GenQuest.Convict.Mayak = GetMayakByCityName(pchar.GenQuest.Convict.ToCity);
					dialog.text = "Capitaine, auriez-vous la bonté de conduire notre humble compagnie jusqu'à " + XI_ConvertString("Colony" + pchar.GenQuest.Convict.ToCity + "Gen") + " et son phare.";
					link.l1 = "On ne lit pas une modestie particulière sur vos visages.";
					link.l1.go = "Convict_13";
				break;
			}
			link.l2 = LinkRandPhrase("Je ne fais pas l'aumכne le vendredi.","Je n'ai pas de temps pour ces bêtises.","Je ne vais aider personne.");
			link.l2.go = "Convict_14";
			Convict_GetMineType();
			pchar.GenQuest.Convict.ShoreLocation = SelectQuestShoreLocation();
		break;

		case "Convict_11":
			dialog.text = "Nous sommes des fugitifs... Nous nous sommes échappés de notre lieu de servitude : " + GetStrSmallRegister(XI_ConvertString("MineType" + pchar.GenQuest.Convict.MineType + "Dat")) + ". Et si l'ancien maître reprend ses esprits, il n'y aura plus d'échappatoire...";
			if(GetFreeCrewQuantity(pchar) >= sti(pchar.GenQuest.Convict.ConvictQty))
			{
				link.l1 = "Alors, vous savez manier les voiles ?";
				link.l1.go = "Convict_11_1";
			}
			link.l2 = "Et avec quoi allez-vous payer ?";
			link.l2.go = "Convict_11_2";
		break;

		case "Convict_12":
			dialog.text = "Le rhum, ce n'est pas pour nous en ce moment. Il y a une semaine, nous avons fui notre lieu de servitude : " + GetStrSmallRegister(XI_ConvertString("MineType" + pchar.GenQuest.Convict.MineType + "Dat")) + " ; depuis, nous nous cachons dans la jungle, pourvu qu'on ne meure pas de faim...";
			if(sti(pchar.money) >= 3000)
			{
				link.l1 = "Bon, disons que je vous donne de l'argent, et ensuite ? Vous allez vous cacher jusqu'à l'arrivée de la patrouille ?";
				link.l1.go = "Convict_12_1";
				link.l2 = "D'accord, combien demandez-vous ?";
				link.l2.go = "Convict_12_2";
			}
			link.l3 = "Avec les gens comme vous, je ne fais pas de longs discours : la tête sur le billot et une condamnation à mort.";
			link.l3.go = "Convict_12_3";
		break;

		case "Convict_12_1":
			if(drand(1) == 0 && GetFreeCrewQuantity(pchar) >= sti(pchar.GenQuest.Convict.ConvictQty))
			{
				dialog.text = "Que voulez-vous qu'on fasse ? On ne serait pas contre s'engager comme marins, mais qui voudra de fugitifs ?";
				link.l1 = "Moi, je vous prends, si vous savez manier la voile et ne fuyez pas devant les balles.";
				link.l1.go = "Convict_12_1_1";
			}
			else
			{
				dialog.text = "Oui, on s'est déjà arrangés avec les pêcheurs du coin. Il ne nous manque que trois mille pour partir d'ici.";
				link.l1 = "Gardez vos trois mille, si ça peut vraiment vous aider.";
				link.l1.go = "Convict_12_1_2";
			}
			link.l2 = "Eh bien, je ne sais pas... Ce sont vos problèmes, réglez-les sans moi.";
			link.l2.go = "Convict_12_1_End"; // выход из локи с закрытием квеста
		break;

		case "Convict_12_1_1":
			pchar.GenQuest.Convict.PirateName = "l" + rand(GetNamesCount(NAMETYPE_NICK) - 1);
			dialog.text = "Prenez-nous, capitaine, vous ne le regretterez pas ! Nous avons écumé l'Adriatique avec " + GetName( NAMETYPE_NICK, pchar.GenQuest.Convict.PirateName, NAME_ABL) + " jusqu'à ce qu'il soit pendu ; et nous, les " + pchar.GenQuest.Convict.ConvictQty + " survivants, avons été envoyés ici.";
			link.l1 = "Parfait. Il y a un endroit tout près, " + XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation) + " de son nom. Je viendrai vous y chercher vers minuit. Ne vous perdez pas.";
			link.l1.go = "Convict_11_6";
			pchar.GenQuest.Convict = "ToShore";
		break;

		case "Convict_12_1_2":
			addMoneyToCharacter(pchar, -3000);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Commerce", 60);

		    makeref(MerPrm, MerchantParam);
			iTmp = drand(2);
			iTmp += !MerPrm.active;//добавляем вариант с генерацией легкой добычи только если она сейчас неактивна
			if(iTmp <= 1)
			{
				dialog.text = "Bien sמr que ça va aider ! Aujourd'hui même, nous prendrons la mer, si le vent le permet et si les pêcheurs ne nous lâchent pas. Merci, capitaine, que Dieu vous protège...";
				link.l1 = "Bonne chance à vous aussi.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
			}
			if(iTmp == 2)
			{
				dialog.text = "Voilà de la chance ! Nous ne pensions pas obtenir de l'argent si vite. Permettez-moi, capitaine, de vous offrir du fond du cœur un petit objet que nous avons volé à notre ancien maître. Il vous portera peut-être chance.";
				link.l1 = "Merci, joli objet. Bonne chance à vous.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
				AddCharacterExpToSkill(pchar, "Fortune", 30);
			}
			if(iTmp == 3)
			{
				pchar.GenQuest.Find_Merchant.lastspeak_date = LastSpeakDate();//не используется сейчас, так как в слухи переведено
				GenerateMerchant();
				dialog.text = "On voit tout de suite une personne généreuse, qui n'a pas peur de se séparer de son argent, parce qu'elle sait comment le gagner ! Hier soir, nous avons vu des contrebandiers charger dans des chaloupes une cargaison de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(MerPrm.QuestGoodsIdx)].Name)) + ". Il faisait nuit, mais sur le flanc d'une des chaloupes, on pouvait lire le nom du navire : '" + MerPrm.ShipName + "'... Le navire bat pavillon de " + NationNameGenitive(sti(MerPrm.nation)) + ". Je pense que ça pourrait vous être utile, héhé.";
				link.l1 = "Ah oui ? דa pourrait servir... Bon, adieu, les fugitifs.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				AddQuestRecord("Convict", "7");
				AddQuestUserData("Convict", "sShipName", MerPrm.ShipName);
				AddQuestUserData("Convict", "sGoodName", MerPrm.QuestGoodsIdx);
				CloseQuestHeader("Convict");
				SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
				AddCharacterExpToSkill(pchar, "Sneak", 30);
			}
		break;

		case "Convict_12_2":
			dialog.text = "Pour l'amour de Dieu, comment poser des conditions ? Quoi que vous donniez, nous vous en serons reconnaissants.";
			link.l1 = "300 pièces d'or.";
			link.l1.go = "Convict_12_2_1";
			link.l2 = "1000 pièces d'or.";
			link.l2.go = "Convict_12_2_2";
			link.l3 = "3000 pièces d'or.";
			link.l3.go = "Convict_12_2_3";
		break;

		case "Convict_12_2_1":
			addMoneyToCharacter(pchar, -300);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Commerce", 20);
			dialog.text = "Merci, capitaine, que le Seigneur vous protège...";
			link.l1 = "Bonne chance à vous aussi.";
			link.l1.go = "exit";
			pchar.GenQuest.Convict = "close";
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_12_2_2":
			addMoneyToCharacter(pchar, -1000);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Commerce", 40);
			if(drand(1) == 0)
			{
				GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
				dialog.text = "Voilà de la chance ! Nous ne pensions pas obtenir de l'argent si vite. Permettez-moi, capitaine, de vous offrir du fond du cœur un petit objet que nous avons volé à notre ancien maître. Il vous portera peut-être chance.";
				link.l1 = "Merci, joli objet. Bonne chance à vous.";
				AddCharacterExpToSkill(pchar, SKILL_FORTUNE, 20);
			}
			else
			{
				dialog.text = "Merci, capitaine, que le Seigneur vous protège...";
				link.l1 = "Bonne chance à vous aussi.";
			}
			link.l1.go = "exit";
			pchar.GenQuest.Convict = "close";
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_12_2_3":
			addMoneyToCharacter(pchar, -3000);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Commerce", 60);

			makeref(MerPrm, MerchantParam);
			if(drand(1) == 0 || MerPrm.active != true)//если уже сгенерирована легкая добыча, новую не делаем
			{
				dialog.text = "Voilà de la chance ! Nous ne pensions pas obtenir de l'argent si vite. Permettez-moi, capitaine, de vous offrir du fond du cœur un petit objet que nous avons volé à notre ancien maître. Il vous portera peut-être chance.";
				link.l1 = "Merci, joli objet. Bonne chance à vous.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
				AddCharacterExpToSkill(pchar, "Fortune", 30);
			}
			else
			{
				pchar.GenQuest.Find_Merchant.lastspeak_date = LastSpeakDate();//не используется сейчас, так как в слухи переведено
				GenerateMerchant();
				dialog.text = "On voit tout de suite une personne généreuse, qui n'a pas peur de se séparer de son argent, parce qu'elle sait comment le gagner ! Hier soir, nous avons vu des contrebandiers charger dans des chaloupes une cargaison de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(MerPrm.QuestGoodsIdx)].Name)) + ". Il faisait nuit, mais sur le flanc d'une des chaloupes, on pouvait lire le nom du navire : '" + MerPrm.ShipName + "'... Le navire bat pavillon de " + NationNameGenitive(sti(MerPrm.nation)) + ". Je pense que ça pourrait vous être utile, héhé.";
				link.l1 = "Ah oui ? דa pourrait servir... Bon, adieu, les fugitifs.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				AddQuestRecord("Convict", "7");
				AddQuestUserData("Convict", "sShipName", MerPrm.ShipName);
				AddQuestUserData("Convict", "sGoodName", MerPrm.QuestGoodsIdx);
				CloseQuestHeader("Convict");
				SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
				AddCharacterExpToSkill(pchar, "Sneak", 30);
			}
		break;

		case "Convict_12_1_End":
			ChangeCharacterReputation(pchar, -2);
			OfficersReaction("bad");
			pchar.GenQuest.Convict = "close";
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_12_3":
			if(drand(1) == 0)
			{
				dialog.text = "Ne nous perdez pas, capitaine ! Nous avons un objet de valeur : prenez-le comme rançon, et laissez-nous partir de bon cœur...";
				link.l1 = "Donnez-moi votre objet et filez tant que vous êtes entiers.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
			}
			else
			{
				dialog.text = "On n'a pas le choix : on ne meurt qu'une fois. Allez, un dernier baroud !";
				link.l1 = "Voilà qui est mieux ! Et moi qui croyais que vous aviez décidé d'être gentils !";
				link.l1.go = "Convict_Fight";
			}
		break;

		case "Convict_13":
			dialog.text = "Bon, nous ne sommes pas des saints, c'est sמr, mais inutile de nous disputer pour des broutilles... Nous sommes des fugitifs, il faut qu'on parte d'ici au plus vite.";
			link.l1 = "Vous avez de quoi payer le passage ?";
			link.l1.go = "Convict_13_1";
			link.l2 = "C'est tout... Je ne veux pas ruiner ma réputation à cause de vous. Adieu.";
			link.l2.go = "Convict_11_5";
		break;

		case "Convict_11_1":
			pchar.GenQuest.Convict.PirateName = "l" + rand(GetNamesCount(NAMETYPE_NICK) - 1);
			dialog.text = "Comment faire autrement ? Nous avons aussi l'habitude des abordages. Pendant près de deux ans, feu " + GetName( NAMETYPE_NICK, pchar.GenQuest.Convict.PirateName, NAME_ABL) + " et nous avons terrorisé les marchands du coin ; puis il a été pendu, et nous, les " + pchar.GenQuest.Convict.ConvictQty + " survivants, avons été vendus aux travaux forcés.";
			link.l1 = "Vous voulez rejoindre mon équipage ? Je ne suis pas pingre pour la paie, mais je ne vous promets pas non plus une vie tranquille.";
			link.l1.go = "Convict_11_3";
		break;

		case "Convict_11_2":
			dialog.text = "Oui, nous avons emporté un petit quelque chose de notre lieu de servitude : " + GetStrSmallRegister(XI_ConvertString("MineType" + pchar.GenQuest.Convict.MineType + "Dat")) + " ; de quoi voir venir au début, alors nous paierons le double. Seulement, le paiement se fera sur place. Et n'amenez pas les gardes. Nous ne pardonnons pas les offenses...";
			link.l1 = "Bon, attendez-moi à " + XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Voc") + ". Une chaloupe viendra vous chercher vers minuit... Et ne comptez pas me rouler !";
			link.l1.go = "Convict_11_4";
			link.l2 = "Non, mes bons messieurs, et si je vous sers de chaloupe, et vous, de poignard entre mes cכtes ? Bref, je ne peux pas vous aider dans cette affaire.";
			link.l2.go = "Convict_11_5";
		break;

		case "Convict_11_3":
			dialog.text = "Avec grand plaisir, "+ GetSexPhrase("monsieur","madame") +" le capitaine. Ce métier nous est familier, mais la route de la Marine royale nous est fermée, avec de telles recommandations, héhé.";
			link.l1 = "Parfait. Il y a un endroit tout près, " + XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation) + " de son nom. Je viendrai vous y chercher après minuit. Ne vous perdez pas.";
			link.l1.go = "Convict_11_6";
		break;

		case "Convict_11_4":
			dialog.text = "Mais, capitaine, nous risquons plus que vous. Et si vous décidiez de nous dénoncer au commandant ?";
			link.l1 = "C'est juste... Si je ne me montre pas d'ici le matin, l'accord est annulé.";
			link.l1.go = "Convict_11_7";
		break;

		case "Convict_11_5":
			if(makeint(pchar.reputation) < 10 || makeint(pchar.reputation) > 90)
			{
				dialog.text = "Eh, capitaine, nous espérions tellement...";
				link.l1 = "Tant pis. Pas d'argent, pas de passeur. Adieu.";
				link.l1.go = "exit";
				pchar.GenQuest.Convict = "close";
				ChangeCharacterReputation(pchar, -2);
				AddDialogExitQuestFunction("Convict_DialogDisable");
				AddDialogExitQuest("OpenTheDoors");
			}
			else
			{
				dialog.text = "Et vous, capitaine, vous êtes une fine mouche. Vous allez sans doute courir tout droit chez le commandant. Vous croyez pouvoir filer comme ça ?";
				link.l1 = "Vous avez décidé de m'arrêter coמte que coמte ?! Eh bien, tenez !";
				link.l1.go = "Convict_Fight";
				pchar.GenQuest.Convict = "fight";
			}
		break;

		case "Convict_11_6":
			pchar.GenQuest.Convict = "ToShore";
			ReOpenQuestHeader("Convict");
			AddQuestRecord("Convict", "1");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sIslandType", XI_ConvertString(GetIslandByCityName(pchar.GenQuest.Convict.city) + "Gen"));
			AddQuestUserData("Convict", "sConvictNum", pchar.GenQuest.Convict.ConvictQty);
			AddQuestUserData("Convict", "sShoreName", XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Voc"));
			SetFunctionTimerCondition("Convict_SetTimerMeet", 0, 0, 1, false);
			locations[FindLocation(pchar.GenQuest.Convict.ShoreLocation)].DisableEncounters = true;
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_11_7":
			pchar.GenQuest.Convict = "GetShip";
			ReOpenQuestHeader("Convict");
			AddQuestRecord("Convict", "2");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sIslandType", XI_ConvertString(GetIslandByCityName(pchar.GenQuest.Convict.city) + "Gen"));
			AddQuestUserData("Convict", "sShoreName", XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Acc"));
			SetFunctionTimerCondition("Convict_SetTimerMeet", 0, 0, 1, false);
			locations[FindLocation(pchar.GenQuest.Convict.ShoreLocation)].DisableEncounters = true;
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_13_1":
			pchar.GenQuest.Convict.Sum = (sti(pchar.rank)+10)*100+1000;
			dialog.text = "Il y a de quoi. Nous avons un peu fouillé les coffres du maître, même si ça a fait beaucoup de bruit : nous avons dמ nous frayer un chemin par la force. Seuls " + PChar.GenQuest.Convict.ConvictQty + " hommes en sont sortis vivants.";
			link.l1 = "Vu les circonstances, je ne vous transporterai pas à moins de " + FindRussianMoneyString(sti(pchar.GenQuest.Convict.Sum)) + " par tête.";
			link.l1.go = "Convict_13_2";
			if(GetFreeCrewQuantity(pchar) >= sti(pchar.GenQuest.Convict.ConvictQty) && GetPassengersQuantity(pchar) < PASSENGERS_MAX)
			{
				link.l2 = "Et vous, je vois que vous n'êtes pas timides. Vous voulez rejoindre mon équipage ?";
				link.l2.go = "Convict_13_3";
			}
		break;

		case "Convict_13_2":
			dialog.text = "Je crois que nous n'avons pas le choix, va pour " + FindRussianMoneyString(sti(pchar.GenQuest.Convict.Sum)) + "...";
			link.l1 = "Alors rendez-vous à " + XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Acc") + " . Après minuit, j'enverrai une chaloupe vous chercher.";
			link.l1.go = "Convict_13_4";
			pchar.GenQuest.Convict = "ToMayak";
			pchar.GenQuest.Convict.Sum = sti(pchar.GenQuest.Convict.Sum) * sti(pchar.GenQuest.Convict.ConvictQty);
		break;

		case "Convict_13_3":
			pchar.GenQuest.Convict.PirateName = "l" + rand(GetNamesCount(NAMETYPE_NICK) - 1);
			dialog.text = "Pourquoi pas ? Ce métier nous est familier : " + GetName( NAMETYPE_NICK, pchar.GenQuest.Convict.PirateName, NAME_ABL) + " et nous, nous avons fait la chasse " + RandPhraseSimple("à Gibraltar","dans la Manche") + " jusqu'à ce que nous échouions ici.";
			link.l1 = "Parfait. Il y a un endroit tout près, " + XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation) + " de son nom. Je viendrai vous y chercher vers minuit. Ne vous perdez pas. ";
			link.l1.go = "Convict_11_6";
			pchar.GenQuest.Convict = "ToShore";
		break;

		case "Convict_13_4":
			ReOpenQuestHeader("Convict");
			AddQuestRecord("Convict", "8");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sIslandType", XI_ConvertString(GetIslandByCityName(pchar.GenQuest.Convict.city) + "Gen"));
			AddQuestUserData("Convict", "sConvictNum", pchar.GenQuest.Convict.ConvictQty);
			AddQuestUserData("Convict", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.Convict.ToCity + "Gen"));
			AddQuestUserData("Convict", "sSum", pchar.GenQuest.Convict.Sum);
			AddQuestUserData("Convict", "sShoreName", XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Acc"));
			SetFunctionTimerCondition("Convict_SetTimerMeet", 0, 0, 1, false);
			locations[FindLocation(pchar.GenQuest.Convict.ShoreLocation)].DisableEncounters = true;
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_14":
			dialog.text = RandPhraseSimple(RandPhraseSimple("Eh, capitaine, vous couriez sans doute avec une bourse vide il n'y a pas si longtemps, mais maintenant que ça sonne dans vos poches, vous faites la fine bouche devant les petites gens.","Capitaine, ce n'est pas bien de traiter les petites gens comme ça. Nous sommes tous sous le même Dieu."),
											RandPhraseSimple("Eh, eh, les gens ont le cœur complètement endurci. Vous vivez comme si vous aviez deux siècles devant vous.","On voit tout de suite que vous arrivez d'Europe : vous n'avez pas encore senti la puanteur de nos ordures tropicales."));
			link.l1 = LinkRandPhrase("Vous allez me faire la morale coמte que coמte ?! Je vais vous raccourcir la langue !","Vous me menacez ?! Eh bien, tenez bon !!!","Un philosophe, hein ? Je vais vous remettre les idées en place !");
			link.l1.go = "Convict_Fight";
			pchar.GenQuest.Convict = "fight";
		break;

		case "Convict_Fight":
			LAi_SetPlayerType(pchar);
			LAi_LocationFightDisable(pchar.location, true);
			LAi_LockFightMode(pchar, false);
			LAi_SetFightMode(pchar, true);
			chrDisableReloadToLocation = true;
			iTemp = sti(PChar.GenQuest.Convict.ConvictQty);
			for(i = 0; i < iTemp; i++)
			{
				rChar = CharacterFromID("Convict_" + i);
				DeleteAttribute(rChar, "City");
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, "ConvictGroup");
				LAi_SetImmortal(rChar, false);
			}
			LAi_group_SetRelation("ConvictGroup", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("ConvictGroup", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("ConvictGroup", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Convict_15":
			dialog.text = LinkRandPhrase("Alors, capitaine ? Vous avez amené une chaloupe ?","Bienvenue, capitaine. Alors, c'est fait ?","Bonjour, capitaine, on commençait à s'inquiéter. Tout s'est bien passé ?");
			if(Convict_CheckShipType(SHIP_LEUDO) || Convict_CheckShipType(SHIP_TARTANE) || Convict_CheckShipType(SHIP_FELUCA))
			{
				link.l1 = "Oui, prenez votre coquille de noix. Et n'oubliez pas l'argent. J'ai demandé " + pchar.GenQuest.Convict.ShipPrice + " pièces d'or ; donc, pour vous, ce sera " + sti(pchar.GenQuest.Convict.ShipPrice) * 2 + " pièces, comme convenu.";
				link.l1.go = "Convict_15_1";
			}
			link.l2 = "Non, j'ai changé d'avis. Trouvez-vous un autre assistant. Bonne continuation...";
			link.l2.go = "Convict_15_2";
		break;

		case "Convict_15_1":
			switch(sti(pchar.GenQuest.Convict.variant))
			{
				case 1:
					dialog.text = "Qu'est-ce que vous racontez ?! On nous a pris notre liberté, mais pas notre conscience : vous aurez votre paiement et notre immense gratitude. Vous nous avez rendu un fier service. On vous réglera en lingots d'argent, ça ne vous dérange pas ?";
					link.l1 = "Non, bien sמr que non. Bonne traversée. Seulement, ne vous faites pas prendre en haute mer : là-bas, je ne fais pas de longs discours.";
					link.l1.go = "Convict_15_1_1End";
					AddCharacterExpToSkill(pchar, "Leadership", 30);
					AddCharacterExpToSkill(pchar, "Commerce", 30);
					TakeNItems(pchar, "jewelry17", makeint(sti(pchar.GenQuest.Convict.ShipPrice)/50));
				break;
				case 2:
					dialog.text = "Capitaine, on s'est dit que l'argent n'est pas le plus important dans la vie. Et nous en avons sans doute plus besoin que vous en ce moment. Mais nous avons un objet volé à notre ancien maître, qui vous intéressera peut-être plus que n'importe quel argent. Jetez un œil...";
					link.l1 = "Oui, vous avez raison. L'objet est vraiment intéressant. Bon, merci, et adieu.";
					link.l1.go = "Convict_15_1_2End";
					AddCharacterExpToSkill(pchar, "Leadership", 30);
					AddCharacterExpToSkill(pchar, "Fortune", 30);
					GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
				break;
				case 3:
					pchar.GenQuest.Convict = "FightInShore";
					SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
					dialog.text = "Pourquoi avez-vous besoin d'autant d'argent, capitaine ? Vous n'êtes pas dans la misère. Et nous, sans cette chaloupe, c'est la mort assurée. Alors ne nous en voulez pas. Nous sommes des gens comme ci, comme ça... Bref, on la prend.";
					link.l1 = "C'est là que vous vous êtes trompés. Sans chaloupe, vous auriez pu partir à la nage ; maintenant, vous resterez ici pour toujours.";
					link.l1.go = "Convict_Fight";
					AddCharacterExpToSkill(pchar, "Leadership", 30);
					AddCharacterExpToSkill(pchar, "Sneak", 30);
				break;
			}
		break;

		case "Convict_15_1_1End":
			AddQuestRecord("Convict", "4");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sShoreName", XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Acc"));
			CloseQuestHeader("Convict");
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuestFunction("Convict_SetConvictToShip");
			AddDialogExitQuest("OpenTheDoors");
			DialogExit();
		break;

		case "Convict_15_1_2End":
			AddQuestRecord("Convict", "5");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sShoreName", XI_ConvertString(pchar.GenQuest.Convict.ShoreLocation + "Acc"));
			CloseQuestHeader("Convict");
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuestFunction("Convict_SetConvictToShip");
			AddDialogExitQuest("OpenTheDoors");
			DialogExit();
		break;

		case "Convict_15_2":
			AddQuestRecord("Convict", "3");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Convict");
			for(i = 0; i < sti(pchar.GenQuest.Convict.ConvictQty); i++)
			{
				sld = CharacterFromID("Convict_" + i);
				sld.LifeDay = 0;
			}
			ChangeCharacterReputation(pchar, -2);
			LAi_group_Delete("ConvictGroup");
			DeleteAttribute(pchar, "GenQuest.Convict");
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_16":
			// LEO: перевод съехал на строку - реплика отказа стояла в тексте NPC, а обе ссылки несли
			//   согласие, причём первая вела в отказную ветку. Восстановлено по русской версии.
			dialog.text = RandPhraseSimple("Alors, capitaine ? On peut embarquer ?","Enfin ! On commençait à s'inquiéter : on croyait que vous aviez changé d'avis.");
			link.l1 = "Mes plans ont changé. Vous allez devoir chercher un autre capitaine.";
			link.l1.go = "Convict_16_1";
			if(pchar.GenQuest.Convict == "ToMayak")
			{
				link.l2 = "Montez dans la chaloupe, je n'ai pas beaucoup de temps.";
				link.l2.go = "Convict_16_2";
			}
			if(pchar.GenQuest.Convict == "ToShore" && GetFreeCrewQuantity(pchar) >= sti(pchar.GenQuest.Convict.ConvictQty))
			{
				link.l2 = "Montez dans la chaloupe, je n'ai pas beaucoup de temps.";
				link.l2.go = "Convict_16_2";
			}
		break;

		case "Convict_16_1":
			if(rand(1) == 0)
			{
				dialog.text = "Ah ! Va te faire voir ! Je parie que tu as déjà envoyé une patrouille à nos trousses ! Tu ne t'en tireras pas comme ça !";
				link.l1 = "De quoi parlez-vous ?! Vous en avez assez de vivre ?!";
				link.l1.go = "Convict_Fight";
				pchar.GenQuest.Convict = "ShoreFight";
				SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
			}
			else
			{
				dialog.text = "Capitaine, vous êtes une vraie poule mouillée...";
				link.l1 = "Oh, la ferme...";
				link.l1.go = "Convict_16_3";
			}
		break;

		case "Convict_16_2":
			if(pchar.GenQuest.Convict == "ToShore")
			{
				AddCharacterExpToSkill(pchar, "Leadership", 30);
				AddCharacterCrew(pchar, sti(pchar.GenQuest.Convict.ConvictQty));
				OfficersReaction("bad");
				pchar.GenQuest.Convict = "close";
				AddQuestRecord("Convict", "10");
				CloseQuestHeader("Convict");
				SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
			}
			if(pchar.GenQuest.Convict == "ToMayak")
			{
				AddQuestRecord("Convict", "10");
				sld = characterFromId("Convict_0");
				AddPassenger(pchar, sld, false);
				SetCharacterRemovable(sld, false);
				SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
				SetFunctionLocationCondition("Convict_OnMayak", pchar.GenQuest.Convict.Mayak, true);
				locations[FindLocation(pchar.GenQuest.Convict.Mayak)].DisableEncounters = true;
			}
			DialogExit();
			AddDialogExitQuestFunction("Convict_DialogDisable");
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_16_3":
			ChangeCharacterReputation(pchar, -2);
			OfficersReaction("bad");
			pchar.GenQuest.Convict = "close";
			AddQuestRecord("Convict", "3");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Convict");
			SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
			AddDialogExitQuestFunction("Convict_DialogDisable");
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_17":
			dialog.text = LinkRandPhrase("Merci, "+ GetSexPhrase("brave homme","ma douce") +".","Merci, capitaine : considérez que vous nous avez sortis du nœud coulant.","Merci pour l'agréable traversée.");
			link.l1 = LinkRandPhrase("Tout ça, c'est bien beau, mais j'attends mon paiement.","Il est temps de payer.","L'argent sur le tonneau, comme convenu.");
			link.l1.go = "Convict_17_1";
		break;

		case "Convict_17_1":
			switch(sti(pchar.GenQuest.Convict.variant))
			{
				case 1:
					dialog.text = "Bien sמr, bien sמr ! Quelle question ! Tenez, voici la somme convenue en lingots d'or, et notre immense gratitude.";
					link.l1 = "Bonne chance à vous aussi... Bonne continuation.";
					link.l1.go = "Convict_17_1_1End";
					AddCharacterExpToSkill(pchar, "Sailing", 80);
					AddCharacterExpToSkill(pchar, "Commerce", 80);
					TakeNItems(pchar, "jewelry5", makeint(sti(pchar.GenQuest.Convict.Sum)/200));
					break;
				case 2:
					dialog.text = "Capitaine, on s'est dit que l'argent n'est pas le plus important dans la vie. Et nous en avons sans doute plus besoin que vous en ce moment. Mais nous avons un objet volé à notre ancien maître, qui vous intéressera peut-être plus que n'importe quel argent. Jetez un œil...";
					link.l1 = "Oui, vous avez raison. L'objet est vraiment intéressant. Bon, merci, et adieu.";
					link.l1.go = "Convict_17_1_2End";
					AddCharacterExpToSkill(pchar, "Sailing", 80);
					AddCharacterExpToSkill(pchar, "Fortune", 80);
					GiveItem2Character(pchar, pchar.GenQuest.Convict.Item);
					break;
				case 3:
					dialog.text = "Pourquoi avez-vous besoin d'autant d'argent ? Vous n'êtes pas dans la misère. Vous nous avez tirés d'affaire : à l'occasion, nous vous tirerons d'affaire aussi.";
					link.l1 = "דa n'arrivera pas. Priez, gredins, je ne pardonne pas les dettes.";
					link.l1.go = "Convict_Fight";
					pchar.GenQuest.Convict = "MayakFight";
					SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
					AddCharacterExpToSkill(pchar, "Sailing", 80);
					AddCharacterExpToSkill(pchar, "Sneak", 80);
					break;
			}
		break;


		case "Convict_17_1_1End":
			AddQuestRecord("Convict", "11");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sMayak", XI_ConvertString(pchar.GenQuest.Convict.Mayak + "Abl"));
			AddQuestUserData("Convict", "sSum", makeint(pchar.GenQuest.Convict.Sum));
			CloseQuestHeader("Convict");
			pchar.GenQuest.Convict = "close";
			SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "Convict_17_1_2End":
			AddQuestRecord("Convict", "12");
			AddQuestUserData("Convict", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Convict", "sMayak", XI_ConvertString(pchar.GenQuest.Convict.Mayak + "Abl"));
			CloseQuestHeader("Convict");
			pchar.GenQuest.Convict = "close";
			SetFunctionExitFromLocationCondition("Convict_LocExit", pchar.location, false);
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;
		// <-- Генератор "Convicts"

		// Генератор "A reason to hurry" -->
		// Встреча с ОЗГ на берегу
		case "ReasonToFast_Hunter1":
			dialog.text = "Celui qui m'a envoyé ici, c'est "  + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + ", d'accord ?";
			link.l1 = GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " vous attend depuis deux heures avec une réponse. C'est pour ça qu'il m'a envoyé.";
			link.l1.go = "ReasonToFast_Hunter4";
		break;

		case "ReasonToFast_Hunter2":
			dialog.text = "Je te suis depuis longtemps, mais tu es trop rapide.";
			link.l1 = "Et alors ?";
			link.l1.go = "ReasonToFast_Hunter6";
		break;

		case "ReasonToFast_Hunter3":
			dialog.text = "Réponds-moi plutכt : le gouverneur paie-t-il bien ses larbins ?";
			link.l1 = "Bon sang !...";
			link.l1.go = "ReasonToFast_Fight";
		break;

		case "ReasonToFast_Hunter4":
			dialog.text = "Je n'ai pas bu du tout, je cherchais un maître d'équipage...";
			link.l1 = "Va, va... Je dirai à "  + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + " que tu t'es perdu dans la jungle.";
			link.l1.go = "ReasonToFast_Hunter5";
			AddQuestRecord("ReasonToFast", "5");
			AddQuestUserData("ReasonToFast", "sName", GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN));
		break;

		case "ReasonToFast_Hunter5":
			LAi_SetPlayerType(pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("ReasonToFast_HunterGoOut");
		break;

		case "ReasonToFast_Hunter6":
			pchar.questTemp.ReasonToFast = "MeetHunterFail";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("ReasonToFast_PatrolAngry");
		break;

		case "ReasonToFast_Fight":
			LAi_SetPlayerType(pchar);
			pchar.questTemp.ReasonToFast = "PatrolAngry";
			pchar.questTemp.ReasonToFast.relation = GetNationRelation2MainCharacter(sti(pchar.questTemp.ReasonToFast.GuardNation));
			SetNationRelation2MainCharacter(sti(pchar.questTemp.ReasonToFast.GuardNation), RELATION_ENEMY);
			pchar.GenQuest.HunterScore2Pause = 1; //НЗГ не начисляются
			pchar.GenQuest.ReputationNotChange = 1; //репутацию не менять
			sTemp = "Patrol" + pchar.questTemp.ReasonToFast.LocIdx + "_";
			sGroup = "PatrolGroup_" + pchar.questTemp.ReasonToFast.LocIdx;
			LAi_LocationFightDisable(&locations[FindLocation(pchar.questTemp.ReasonToFast.PatrolLocation)], false);
			iTemp = sti(pchar.questTemp.ReasonToFast.PatrolNum);
			chrDisableReloadToLocation = true;
			rChar = CharacterFromID("ReasonToFast_Hunter");
			LAi_SetWarriorType(rChar);
			LAi_group_MoveCharacter(rChar, sGroup);
			for(i = 0; i < iTemp; i++)
			{
				rChar = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, sGroup);
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "OpenTheDoors");
			LAi_group_SetCheck(sGroup, "ReasonToFast_PatrolDied");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		// бой с кэпом пиратского корабля
		case "ReasonToFast_FightCap":
			dialog.text = "Eh bien, je vois que"+ GetSexPhrase(" tu es un petit malin"," tu es une petite maligne") +". Prie Dieu que tes manigances ne parviennent pas aux oreilles de " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + ".";
			link.l1 = "Il ne le saura pas si tu ne lui dis rien... Et tu ne vas pas le faire, n'est-ce pas ?";
			link.l1.go = "ReasonToFast_FightCap_1";
		break;

		case "ReasonToFast_FightCap_1":
			dialog.text = "Pourquoi donc ?! Je le ferai avec grand plaisir !";
			link.l1 = "Il te pendra de toute façon. Pour la bêtise que tu as commise. Alors ne perdons pas de temps, je vais t'aider à éviter la potence.";
			link.l1.go = "ReasonToFast_FightCap_2";
		break;

		case "ReasonToFast_FightCap_2":
			dialog.text = "Hum... De quelle façon ?";
			link.l1 = "Je vais te tuer...";
			link.l1.go = "ReasonToFast_FightCap_Last";
		break;

		case "ReasonToFast_FightCap_Last":
			LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		// встреча с лакеем в резиденции
		case "ReasonToFast_Lakey":
			dialog.text = "Vous venez pour affaires, "+ GetSexPhrase("monsieur","mademoiselle") +" ?";
			link.l1 = "Non, je visite cette résidence vraiment luxueuse à l'invitation de la charmante épouse du gouverneur.";
			link.l1.go = "ReasonToFast_Lakey1";
			link.l2 = "J'apporte"+ GetSexPhrase("","") +" un message de la part de gens que vous connaissez.";
			link.l2.go = "ReasonToFast_Lakey2";
			link.l3 = "Oui. Je veux vous livrer à la justice !";
			link.l3.go = "ReasonToFast_Lakey3";
			pchar.questTemp.ReasonToFast = "MeetLakey";
			pchar.questTemp.ReasonToFast.SpeakOther = true;
		break;

		case "ReasonToFast_Lakey1":
			NextDiag.TempNode = "ReasonToFast_Lakey11";
			dialog.text = "Oh oui, j'ai la chance de servir dans une si magnifique demeure.";
			link.l1 = "Pas étonnant...";
			link.l1.go = "ReasonToFast_Lakey11";
		break;

		case "ReasonToFast_Lakey11":
			NextDiag.TempNode = "ReasonToFast_Lakey11";
			dialog.text = "N'oubliez pas de jeter un œil à notre jardin !";
			link.l1 = "Merci, mon brave !";
			link.l1.go = "exit";
			bDisableFastReload = false;
		break;

		case "ReasonToFast_Lakey2":
			dialog.text = "Euh... " + pchar.questTemp.ReasonToFast.password + " ?";
			link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "ReasonToFast_Lakey21";
		break;

		case "ReasonToFast_Lakey3":
			dialog.text = "Tu n'y arriveras pas, Judas !";
			link.l1 = "Arrête, salaud !!!";
			link.l1.go = "ReasonToFast_Lakey_exit";
			pchar.questTemp.ReasonToFast = "LakeyExitFail";
			bDisableFastReload = false;
		break;

		case "ReasonToFast_Lakey21":
			if(GetStrSmallRegister(pchar.questTemp.ReasonToFast.ShipName) == GetStrSmallRegister(dialogEditStrings[1]))
			{
				dialog.text = "Dépêchez-vous, prenez vos objets de valeur et partez !";
				link.l1 = "Je crois qu'il est temps pour toi de filer aussi.";
				link.l1.go = "ReasonToFast_Lakey_exit";
				TakeNItems(pchar,"icollection", sti(pchar.questTemp.ReasonToFast.p8));
				TakeNItems(pchar,"Chest", sti(pchar.questTemp.ReasonToFast.p7));
				pchar.questTemp.ReasonToFast = "LakeyExitSuccess";
				bDisableFastReload = true;
			}
			else
			{
				dialog.text = "Mmm, excusez-moi, je dois partir immédiatement.";
				link.l1 = "Arrête, salaud !!!";
				link.l1.go = "ReasonToFast_Lakey_exit";
				pchar.questTemp.ReasonToFast = "LakeyExitFail";
				bDisableFastReload = false;
			}
		break;

		case "ReasonToFast_Lakey_exit":
			DialogExit();
			DeleteAttribute(pchar, "GenQuest.CannotWait");
			pchar.quest.ReasonToFast_ClearLakey.over = "yes"; //снимаем таймер
			ReasonToFast_SetHunterCoastal();
			AddDialogExitQuest("ReasonToFast_LakeyGoOut");
		break;

		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais vous êtes "+ GetSexPhrase("un voleur, mon cher ! Gardes, retenez-le","une voleuse ! Gardes, retenez-la") +" !!!", "דa alors ! א peine j'ai tourné la tête que vous plongez dans le coffre ! Arrêtez ce voleur !!!", "Gardes ! On vole !!! Arrêtez ce voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "ReasonToFast_Lakey_exit";
			pchar.questTemp.ReasonToFast = "LakeyExitFail";
			bDisableFastReload = false;
		break;
		// Генератор "A reason to hurry" <--

		// ситуации с капитаном захваченного корабля
		// взрыв на корабле
		case "ShipSituation11": // пираты или ДУ
			dialog.text = RandPhraseSimple("Bonjour, "+ GetSexPhrase("l'ami","ma petite") +" ! Je t'ai préparé une surprise : j'ai mis le feu à la mèche qui mène à la sainte-barbe. דa va faire une explosion qu'on entendra jusqu'en enfer !","Qu'est-ce que tu attends ?! Il y a le feu à la sainte-barbe ! דa va faire un de ces feux d'artifice, on le verra jusqu'en Europe !");
			link.l1 = RandPhraseSimple("Oh, canaille ! Tu ne me tromperas pas. Bats-toi, lâche !","Je vois que les rats quittent le navire, et toi, tu es aux premiers rangs ?!");
			link.l1.go = "ShipSituation12";
		break;

		case "ShipSituation12":
			dialog.text = RandPhraseSimple("Cours, toi aussi, si tu veux vivre... Bon, je n'ai pas le temps : la chaloupe m'attend. Et bonne pêche à toi !","Je n'ai pas le temps de jouer les nobles : les gars dans la chaloupe n'attendront pas. Bonne pêche, le vainqueur"+ GetSexPhrase("","") +" !");
			link.l1 = RandPhraseSimple("Oh, merde !!!.. Coupez les amarres !!! On file !","Il fallait vraiment se fourrer dans un tel pétrin !.. Ouvrez les vannes ! On file d'ici !");
			link.l1.go = "ShipSituation_End";
		break;

		case "ShipSituation21": // военный корабль (не флагман)
			dialog.text = "Quoi ?! Tu crois avoir gagné le duel ?! Tu te réjouis trop tכt. J'ai mis le feu à la mèche qui mène à la sainte-barbe : je ne peux pas te laisser quitter ce navire vivant.";
			link.l1 = RandPhraseSimple("Oh, canaille ! Tu ne me tromperas pas. Bats-toi, lâche !","Je vois que les rats quittent le navire, et toi, tu es aux premiers rangs ?!");
			link.l1.go = "ShipSituation22";
		break;

		case "ShipSituation22":
			dialog.text = RandPhraseSimple("J'accomplis mon serment, mais ça ne m'oblige pas à mourir aussi bêtement. Désolé, je ne t'offre pas de place dans la chaloupe : j'ai peur que les marins ne comprennent pas.","Les navires sont bien accrochés par l'abordage, ton sort est donc scellé. Désolé, la chaloupe m'attend...");
			link.l1 = RandPhraseSimple("Oh, merde !!!.. Coupez les amarres !!! On file !","Il fallait vraiment se fourrer dans un tel pétrin !.. Ouvrez les vannes ! On file d'ici !");
			link.l1.go = "ShipSituation_End";
		break;

		case "ShipSituation31": // ОЗГ
			dialog.text = RandPhraseSimple("Alors, le vainqueur ?! Bienvenue en enfer ! J'ai mis le feu à la mèche de la sainte-barbe.","Te voilà, mon cher ! Maintenant, tu ne t'en sortiras pas : j'ai mis le feu à la sainte-barbe.");
			link.l1 = RandPhraseSimple("Oh, canaille ! Tu ne me tromperas pas. Bats-toi, lâche !","Je vois que les rats quittent le navire, et toi, tu es aux premiers rangs ?!");
			link.l1.go = "ShipSituation32";
		break;

		case "ShipSituation32":
			dialog.text = RandPhraseSimple("דa fait longtemps que je te traque. Dommage qu'on ait dמ sacrifier le navire. Ce n'est pas grave : ta tête vaut tellement que je m'en paierai deux neufs. Bonne pêche !","Tu vois comme je dois te faire honneur ? Avec un feu d'artifice, comme pour "+ GetSexPhrase("un prince indien","une princesse indienne") +". Bon, allez, je n'en suis pas à ça près. Ta tête vaut plus que mon rafiot. Adieu, la chaloupe n'attendra pas...");
			link.l1 = RandPhraseSimple("Oh, merde !!!.. Coupez les amarres !!! On file !","Il fallait vraiment se fourrer dans un tel pétrin !.. Ouvrez les vannes ! On file d'ici !");
			link.l1.go = "ShipSituation_End";
		break;

		case "ShipSituation_End":
			AddCharacterExpToSkill(pchar, "Sneak", 200);
			DialogExit();
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", -1);
			NPChar.LifeDay = 0;
			LAi_LockFightMode(pchar, false);
			Log_Info(XI_ConvertString("Ship can explode"));
			pchar.GenQuest.ShipSituation.Explosion = ShipSituation_4;
			pchar.GenQuest.ShipSituation.Explosion.CapId = NPChar.CaptanId;
			LAi_EnableReload();
			Log_SetActiveAction("Reload");
		break;

		// эпидемия
		case "ShipEpidemy1":
			AddCharacterExpToSkill(pchar, "Fortune", 200);
			dialog.text = RandPhraseSimple("Arrêtez, capitaine ! Je veux vous dire quelques mots.","Attendez, capitaine ! Je crois que ça va vous intéresser.");
			link.l1 = LinkRandPhrase("Qu'est-ce que c'est que ces bavardages en plein combat ?!","Qu'ai-je à dire à un mort ?","Qu'y a-t-il ?! Vous voulez me léguer un testament ?");
			link.l1.go = "ShipEpidemy2";
		break;

		case "ShipEpidemy2":
			dialog.text = "Il y a une épidémie à bord. J'ai perdu un quart de l'équipage pendant le voyage. Vous êtes donc tous condamnés...";
			link.l1 = RandPhraseSimple("Sac pourri ! Pourquoi n'avez-vous pas hissé le signal de détresse ?!","Pourquoi avez-vous oublié le règlement de la marine ? Il doit y avoir un signal au mât indiquant qu'il y a un malheur à bord !");
			link.l1.go = "ShipEpidemy3";
		break;

		case "ShipEpidemy3":
			dialog.text = "Nous devions tous mourir. C'est pour ça que nous ne nous sommes pas rendus : pour emmener avec nous dans l'autre monde vous et vos sbires !.. Maintenant, je suis satisfait. Vous pouvez achever votre sale besogne.";
			link.l1 = RandPhraseSimple("Eh bien, vous allez me le payer !..","Moi, ce qui me satisfait, c'est que vous mourrez plus tכt. Et je le verrai...");
			link.l1.go = "ShipEpidemy31";
			link.l2 = RandPhraseSimple("Je ne salirai pas ma lame avec ton sang immonde : vis... Quoique, à quoi bon ? J'emmène l'équipage loin de ce rafiot pourri.","דa mérite la potence, mais tu n'en auras plus besoin. J'emmène les gens... Vis le temps qu'il te reste.");
			link.l2.go = "ShipEpidemy32";
			pchar.GenQuest.ShipSituation.Epidemy.CapId = NPChar.CaptanId;
			pchar.GenQuest.ShipSituation.Epidemy = ShipSituation_4;
		break;

		case "ShipEpidemy31":
			pchar.GenQuest.QuestAboardCabinDialogIdx = NPChar.index;
			pchar.GenQuest.ShipSituation.Epidemy.CapState = "Died"; // вражеский кэп на волосок от смерти от переизбытка стали и свинца в организме
			LAi_LockFightMode(pchar, false);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "ShipEpidemy32":
			DialogExit();
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "", -1);
			LAi_LockFightMode(pchar, false);
			pchar.GenQuest.ShipSituation.Epidemy.CapState = "Live"; // вражеский кэп остался в живых
			LAi_EnableReload();
			Log_SetActiveAction("Reload");
		break;
		// ситуации с капитаном захваченного корабля

		// Генератор "The Girl in the Jungle"
		case "EncGirl_Lover":
			dialog.text = "Bonjour, capitaine, on m'a dit que vous me cherchiez.";
			link.l1 = "Seulement si vous êtes " + pchar.GenQuest.EncGirl.sLoverId + ".";
			link.l1.go = "EncGirl_Lover1";
		break;

		case "EncGirl_Lover1":
			dialog.text = "Oui, c'est moi. Vous avez quelque chose d'important ?";
			link.l1 = "Je ne sais pas à quel point c'est important pour vous, mais j'ai amené " + pchar.GenQuest.EncGirl.name +". Elle s'est enfuie de chez elle et vous attend maintenant près de la taverne.";
			link.l1.go = "EncGirl_Lover2";
		break;

		case "EncGirl_Lover2":
			dialog.text = "Oh mon Dieu, je savais que ça finirait comme ça... Pourquoi s'est-elle enfuie, elle ne vous l'a pas dit ?";
			link.l1 = "On veut la marier au fils d'un usurier.";
			link.l1.go = "EncGirl_Lover3";
		break;

		case "EncGirl_Lover3":
			pchar.GenQuest.EncGirl.LoverCity = GetQuestNationsCity(sti(pchar.GenQuest.EncGirl.nation));
			pchar.GenQuest.EncGirl.LoverIsland = GetIslandByCityName(pchar.GenQuest.EncGirl.LoverCity);
			dialog.text = "Ah non, il ne faut pas laisser faire ça ! Capitaine, je suis dans une situation si bête... bref, je voudrais vous demander de nous emmener sur l'île de " + XI_ConvertString(pchar.GenQuest.EncGirl.LoverIsland + "Acc") + " – dans la colonie de " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.LoverCity) + ", mais je n'ai absolument pas d'argent en ce moment : je n'ai pas trouvé de travail. Et à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.LoverCity) + " j'ai des parents aisés et des perspectives de carrière... Je vous assure, mes parents seront heureux de me voir avec ma jeune fiancée et vous remercieront généreusement. Qu'en dites-vous ?";
			link.l1 = "...וcoutez, j'ai d'autres projets en ce moment. Je peux vous conseiller de vous engager comme marin sur n'importe quel navire et, au lieu d'un salaire, de louer une cabine pour votre fiancée. C'est comme ça que voyagent les gens d'Europe, alors qu'un cormoran volerait jusqu'à votre colonie en une nuit.";
			link.l1.go = "EncGirl_Lover4";
			link.l2 = "Ah, la jeunesse ! Savez-vous seulement ce que vous me demandez ? Enlever une fille à ses parents sans leur bénédiction ? Bien sמr que je vais le faire !";
			link.l2.go = "EncGirl_Lover5";
		break;

		case "EncGirl_Lover4":
			npchar.lifeDay = 0;
			AddDialogExitQuestFunction("EncGirl_LoverExit");
			DialogExit();
		break;

		case "EncGirl_Lover5":
			AddDialogExitQuestFunction("EncGirl_ToLoverParents");
			DialogExit();
		break;

		case "EncGirl_Lover6":
			AddSimpleRumourCityTip(RandPhraseSimple("Vous avez entendu ? " + pchar.GenQuest.EncGirl.name + " s'est enfuie avec son amoureux juste avant d'être conduite à l'autel. Elle ne voulait pas lier sa vie à un infirme. Et ce sont ses parents les fautifs : ils se sont laissé séduire par l'argent du fiancé, il ne fallait pas donner une si belle femme à un monstre.",
				"Vous savez la nouvelle ? " + pchar.GenQuest.EncGirl.name + " a planté là son papa et son tout nouveau fiancé. On dit qu'un noble capitaine l'a aidée à s'enfuir avec son amoureux sur une autre île, oם vivent les parents de celui-ci... Oh, il y a encore des gens qui n'ont pas oublié ce qu'est la passion !"), pchar.GenQuest.EncGirl.LoverCity, 3, 2, "citizen,habitue", "");
			dialog.text = "Merci, capitaine. Nous n'oublierons jamais ce service de toute notre vie.";
			link.l1 = "Il n'y a pas de quoi. L'essentiel, c'est que tout s'arrange pour vous maintenant.";
			link.l1.go = "EncGirl_Lover7";
		break;

		case "EncGirl_Lover7":
			switch (rand(4))
			{
				case 0:
					sTemp = "au magasin";
					pchar.GenQuest.EncGirl.LoverFather = "store_keeper";
				break;
				case 1:
					sTemp = "au chantier naval";
					pchar.GenQuest.EncGirl.LoverFather = "shipyard_keeper";
				break;
				case 2:
					sTemp = "à la capitainerie";
					pchar.GenQuest.EncGirl.LoverFather = "portman_keeper";
				break;
				case 3:
					sTemp = "à la taverne";
					pchar.GenQuest.EncGirl.LoverFather = "tavern_keeper";
				break;
				case 4:
					sTemp = "à la banque";
					pchar.GenQuest.EncGirl.LoverFather = "usurer_keeper";
				break;
			}
			if (pchar.location == "DesMoines_town")	//В Дес-Мойнес мало зданий
			{
				switch (rand(1))
				{
					case 0:
						sTemp = "au magasin";
						pchar.GenQuest.EncGirl.LoverFather = "store_keeper";
					break;
					case 1:
						sTemp = "à la taverne";
						pchar.GenQuest.EncGirl.LoverFather = "tavern_keeper";
					break;
				}
			}
			pchar.GenQuest.EncGirl.FatherLoc = sTemp;
			dialog.text = "J'ai promis de vous présenter à mes parents. Quand vous serez libre, passez " + sTemp + " : mon père y travaille, je lui raconterai ce que vous avez fait pour nous. Je vous assure qu'il sera heureux de vous voir.";
			link.l1 = "D'accord, d'accord, je passerai. Soyez heureux...";
			link.l1.go = "EncGirl_Lover8";
		break;

		case "EncGirl_Lover8":
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 5.0);
			npchar.lifeday = 0;
			AddQuestRecord("JungleGirl", "16");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sText", pchar.GenQuest.EncGirl.FatherLoc);
			if((GetSummonSkillFromName(pchar, SKILL_FORTUNE) + GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)) < 175)
			{
				pchar.GenQuest.EncGirl.LoverFatherAngry = 0; // папочка жениха счастлив за сына :)
			}
			else
			{
				pchar.GenQuest.EncGirl.LoverFatherAngry = 1; // папочка жениха разъярён за то что сын притащил в дом шалаву :)
			}
			chrDisableReloadToLocation = false;
			pchar.GenQuest.EncGirl = "toLoverFather";
			pchar.quest.EncGirl_GetLoverFather.win_condition.l1 = "Timer";
			pchar.quest.EncGirl_GetLoverFather.win_condition.l1.date.day = GetAddingDataDay(0, 0, 2);
			pchar.quest.EncGirl_GetLoverFather.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 2);
			pchar.quest.EncGirl_GetLoverFather.win_condition.l1.date.year = GetAddingDataYear(0, 0, 2);
			pchar.quest.EncGirl_GetLoverFather.function = "EncGirl_GenQuest_GetLoverFather";
			DialogExit();
		break;
		// Генератор "The Girl in the Jungle"

		// Генератор "The Captain's errand"
		case "CaptainComission_1":
			dialog.text = RandPhraseSimple("Arrêtez !.. Arrêtez, capitaine ! Attendez.","Capitaine, attendez, je vous en prie...");
			link.l1 = LinkRandPhrase("Vous êtes à bout de souffle ?","Lève ta lame ! Lâche.","Qu'y a-t-il ?! Vous avez oublié de laisser un testament ?");
			link.l1.go = "CaptainComission_2";
		break;

		case "CaptainComission_2":
			dialog.text = "Attendez, je suis blessé et je ne peux plus résister... Je ne demande pas grâce, mais j'ai une affaire inachevée. Promettez de ne pas refuser cela à un mourant.";
			link.l1 = RandPhraseSimple("Ne pleurniche pas, capitaine, accepte la mort comme un homme !..","Capitaine, qu'est-ce que c'est que ces sentiments ? La bataille gronde tout autour. Finissons dignement ce que nous avons commencé.");
			link.l1.go = "CaptainComission_21";
			link.l2 = "Expliquez-vous, mais vite. ";
			link.l2.go = "CaptainComission_22";
		break;

		case "CaptainComission_21":
			LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			ChangeCharacterReputation(pchar, -2);
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CaptainComission_22":
			if(rand(1) == 0) // "Ransom"
			{
				CaptainComission_Init(NPChar);
				dialog.text = "Dites à " + pchar.GenQuest.CaptainComission.Name + " qui vit à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City) + " que je n'ai pas pu accomplir sa mission... ou plutכt, que je n'en ai pas eu le temps. Qu'il me pardonne...";
				link.l1 = RandPhraseSimple("C'est tout ?! D'accord, je le ferai. Eh, mon cher...","D'accord, je le lui dirai si j'en trouve le temps. Eh, mon cher...");
				link.l1.go = "CaptainComission_22_1";
				link.l2 = "Je ne crois pas que je vais m'occuper de ce genre de bêtises. Finissons dignement ce que nous avons commencé.";
				link.l2.go = "CaptainComission_22_2";
			}
			else // "Operation Galleon"
			{
				CaptainComission_GaleonInit(NPChar);
				dialog.text = "Dites au capitaine de patrouille – " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Gen")) + " '" + pchar.GenQuest.CaptainComission.ShipTypeName + "' " + pchar.GenQuest.CaptainComission.Name + ", qu'il ne doit pas se montrer à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Voc") + "... " +
							"Le gouverneur a appris le naufrage du navire : " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim), "Name") + "Gen")) + " '" + pchar.GenQuest.CaptainComission.VictimShipName + "'... il faut faire vite, sinon il sera arrêté... Le navire " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name"))) + " fait route vers " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Acc") + " de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City1 + "Gen") + " et arrivera dans une quinzaine de jours... trouvez-le avant que ça n'arrive...";
				link.l1 = RandPhraseSimple("Je ne promets rien, mais je le lui dirai si nécessaire. Eh, mon cher... ","D'accord, je le lui dirai si j'ai le temps. Eh, mon cher...");
				link.l1.go = "CaptainComission_300";
			}
		break;

		case "CaptainComission_22_1":
			ReOpenQuestHeader("CaptainComission1");
			AddQuestRecord("CaptainComission1", "1");
			AddQuestUserData("CaptainComission1", "sShipName", pchar.GenQuest.CaptainComission.ShipName);
			AddQuestUserData("CaptainComission1", "sCapName", pchar.GenQuest.CaptainComission.CapName);
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City));
			SetFunctionTimerCondition("CaptainComission_Speak", 0, 0, 30, false);
			SetFunctionTimerCondition("CaptainComission_SellSlave", 0, 0, 15 + rand(5), false);
			LAi_KillCharacter(NPChar);
			LAi_SetPlayerType(pchar);
			pchar.GenQuest.CaptainComission = "Begin_1";
			LAi_EnableReload();
			Log_SetActiveAction("Reload");
			DialogExit();
		break;

		case "CaptainComission_22_2":
			dialog.text = "Quelle cruauté ! J'espère que ça vous sera compté dans l'autre monde.";
			link.l1 = "Et pas seulement ça..";
			link.l1.go = "CaptainComission_22_3";
		break;

		case "CaptainComission_22_3":
			ReOpenQuestHeader("CaptainComission1");
			AddQuestRecord("CaptainComission1", "1");
			AddQuestUserData("CaptainComission1", "sShipName", pchar.GenQuest.CaptainComission.ShipName);
			AddQuestUserData("CaptainComission1", "sCapName", pchar.GenQuest.CaptainComission.CapName);
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City));
			SetFunctionTimerCondition("CaptainComission_Speak", 0, 0, 30, false);
			SetFunctionTimerCondition("CaptainComission_SellSlave", 0, 0, 15 + rand(5), false);
			LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			ChangeCharacterReputation(pchar, -3);
			pchar.GenQuest.CaptainComission = "Begin_2";
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CaptainComission_3":
			// LEO: страховка для сейвов, где посредник уже завис. Срок поручения выходит по таймеру
			//   (CaptainComission_Speak), данные квеста стираются - и реплики подставляли пустоту, а
			//   CaptainComission_6 не находил своей ветки: диалог без текста и ответов, выход только alt+f4.
			if (!CheckAttribute(pchar, "GenQuest.CaptainComission.Name"))
			{
				dialog.text = "Pardonnez-moi, capitaine, je vous ai pris pour quelqu'un d'autre. Je n'ai plus besoin de rien.";
				link.l1 = "דa arrive. Bonne journée.";
				link.l1.go = "exit";
				AddDialogExitQuestFunction("CaptainComission_EndTavern");
				break;
			}
			dialog.text = LinkRandPhrase("Je vous écoute, " + GetAddress_Form(pchar) + ".","Que vouliez-vous ?","Que puis-je faire pour vous ?");
			link.l1 = "Vous êtes " + pchar.GenQuest.CaptainComission.Name + " ? J'ai une commission pour vous. Le capitaine " + pchar.GenQuest.CaptainComission.CapName + " m'a demandé de vous transmettre une information importante.";
			link.l1.go = "CaptainComission_4";
		break;

		case "CaptainComission_4":
			dialog.text = "Oui ? Eh bien, parlons. Alors, qu'est-ce que le capitaine " + pchar.GenQuest.CaptainComission.CapName + " vous a demandé de faire ?";
			link.l1 = "Il m'a demandé de vous dire qu'il ne pourra pas accomplir votre mission.";
			link.l1.go = "CaptainComission_5";
		break;

		case "CaptainComission_5":
			dialog.text = "Que dites-vous là ?! Je le connais depuis longtemps, c'est un honnête homme : il n'a pas pu faire ça !";
			link.l1 = "Disons que les circonstances l'en ont empêché. Autrement dit, il est mort.";
			link.l1.go = "CaptainComission_6";
		break;

		case "CaptainComission_6":
			CaptainComission_GetPirateIsland();
			CaptainComission_GetFamilyType();
			if(pchar.GenQuest.CaptainComission == "Begin_1")
			{
				dialog.text = "Oh, comme tout cela tombe mal ! Tant de temps perdu..."
					+ "Capitaine, dans ce cas, je dois vous demander votre aide. Des pirates de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.PiratesCity + "Gen") + " ont capturé mon " + GetStrSmallRegister(XI_ConvertString("Family" + pchar.GenQuest.CaptainComission.FamilyType + "Gen")) + " " + pchar.GenQuest.CaptainComission.SlaveName + " et exigent une rançon pour lui. Accepteriez-vous de vous charger de cette mission ? La récompense sera généreuse.";
				link.l1 = "Malheureusement, j'ai d'autres projets.";
				link.l1.go = "CaptainComission_6_1";
				link.l2 = "J'essaierai de vous aider, si vous m'expliquez l'affaire plus en détail.";
				link.l2.go = "CaptainComission_6_2";
			}
			if(pchar.GenQuest.CaptainComission == "Begin_2")
			{
				dialog.text = "Oh, comme tout cela tombe mal ! Tant de temps perdu... Oם sont les coffres ?";
				link.l1 = "Mm... Quels coffres ?";
				link.l1.go = "CaptainComission_6_3";
				pchar.GenQuest.CaptainComission.CanFindChest = true;
			}
		break;

		case "CaptainComission_6_1":
			dialog.text = "Je suis navré, capitaine... Dommage que vous ne vouliez pas m'aider.";
			link.l1 = "Ce n'est pas une question d'envie, mon cher. Vous comprenez... Adieu.";
			link.l1.go = "CaptainComission_6_1End";
		break;

		case "CaptainComission_6_2":
			dialog.text = "Hier, j'ai reçu une lettre de " + pchar.GenQuest.CaptainComission.PirateName + ", dans laquelle il m'annonçait qu'il augmentait le montant de la rançon et menaçait de vendre le prisonnier comme esclave. Feu le capitaine devait informer " + ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_ACC) + " que j'acceptais les conditions précédentes, et lui verser une avance. Mais maintenant, je comprends pourquoi les pirates ont fait monter les enchères.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "CaptainComission_6_21";
		break;

		case "CaptainComission_6_3":
			dialog.text = "Oh, "+ GetSexPhrase("l'ami","ma petite") +", il me semble que quelqu'un joue un jeu malhonnête. Je vous préviens tout de suite : c'est dangereux et lourd de conséquences. Le capitaine " + pchar.GenQuest.CaptainComission.CapName + " avait trois coffres d'or qu'il devait remettre à " + ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_DAT) + " à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.PiratesCity + "Voc") + " en guise de rançon pour une personne : " + pchar.GenQuest.CaptainComission.SlaveName + ". Puisqu'il vous a chargé de nous contacter, il n'a pas pu ne pas mentionner les coffres.";
			link.l1 = "Peut-être qu'il n'a simplement pas eu le temps ?";
			link.l1.go = "CaptainComission_6_31";
		break;

		case "CaptainComission_6_1End":
			AddQuestRecord("CaptainComission1", "3");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCharType", GetStrSmallRegister(XI_ConvertString("Family" + pchar.GenQuest.CaptainComission.FamilyType + "Gen")));
			CloseQuestHeader("CaptainComission1");
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			ChangeCharacterReputation(pchar, -2);
			DialogExit();
		break;

		case "CaptainComission_6_21":
			dialog.text = "Je n'ai pas le choix... La somme exigée, 150 000 pièces d'or, je l'ai déjà réunie. Je veux vous demander de l'apporter à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.PiratesCity + "Acc") + " et de ramener mon " + GetStrSmallRegister(XI_ConvertString("Family" + pchar.GenQuest.CaptainComission.FamilyType + "Gen")) + " ici. Je suis prêt à vous payer 40 000 pour ce service, que vous recevrez à votre retour.";
			link.l1 = "D'accord, je suis prêt.";
			link.l1.go = "CaptainComission_6_22";
			link.l2 = "Malheureusement, j'ai d'autres projets.";
			link.l2.go = "CaptainComission_6_1";
		break;

		case "CaptainComission_6_22":
			dialog.text = "Alors prenez l'argent, et que Dieu vous garde... Il faut juste se dépêcher : j'ai peur que " + pchar.GenQuest.CaptainComission.PirateName + " n'attende pas et vende le pauvre garçon comme esclave.";
			link.l1 = "Attendez-moi ici. Je pense que ce ne sera pas long.";
			link.l1.go = "CaptainComission_6_22End";
		break;

		case "CaptainComission_6_22End":
			AddQuestRecord("CaptainComission1", "4");
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City));
			AddQuestUserData("CaptainComission1", "sPirateName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_DAT));
			AddQuestUserData("CaptainComission1", "sPirateCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.PiratesCity + "Acc"));
			AddQuestUserData("CaptainComission1", "sFamilyType", GetStrSmallRegister(XI_ConvertString("Family" + pchar.GenQuest.CaptainComission.FamilyType + "Gen")));
			AddQuestUserData("CaptainComission1", "sSlaveName", pchar.GenQuest.CaptainComission.SlaveName);
			addMoneyToCharacter(pchar, 150000);
			pchar.GenQuest.CaptainComission = "Begin_11";
			pchar.GenQuest.CaptainComission.AfterTavernSpeak = "goodSpeak";
			pchar.GenQuest.CaptainComission.GetSlave = "NoSlave";
			pchar.GenQuest.CaptainComission.toMayor = true;
			SetFunctionTimerCondition("CaptainComission_30DaysIsLeft", 0, 0, 30, false);
			NextDiag.TempNode = "CaptainComission_7";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "CaptainComission_6_31":
			dialog.text = "Ou n'a pas voulu... דa ne change rien à l'affaire. Ceux qui ont réuni la rançon s'en moquent. Il leur faut un résultat : " + pchar.GenQuest.CaptainComission.SlaveName + " sain et sauf. Alors ne perdez pas de temps.";
			link.l1 = "Et si je refuse ?";
			link.l1.go = "CaptainComission_6_32";
		break;

		case "CaptainComission_6_32":
			dialog.text = "Je n'ai pas besoin de votre consentement. Je vous informe simplement que si, d'ici trente jours, vous n'amenez pas vivant dans cette taverne " + pchar.GenQuest.CaptainComission.SlaveName + ", j'enverrai des chasseurs de primes à vos trousses...";
			link.l1 = "Hum, tout de même... Et si je l'amène ?";
			link.l1.go = "CaptainComission_6_33";
		break;

		case "CaptainComission_6_33":
			dialog.text = "Alors, nous en reparlerons...";
			link.l1 = "Très bien... Voyons comment ça tourne.";
			link.l1.go = "CaptainComission_6_33End";
		break;

		case "CaptainComission_6_33End":
			AddQuestRecord("CaptainComission1", "5");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCapName",pchar.GenQuest.CaptainComission.CapName);
			AddQuestUserData("CaptainComission1", "sPirateName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_DAT));
			AddQuestUserData("CaptainComission1", "sPirateCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.PiratesCity + "Acc"));
			AddQuestUserData("CaptainComission1", "sSlaveName",pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			pchar.GenQuest.CaptainComission = "Begin_22";
			pchar.GenQuest.CaptainComission.AfterTavernSpeak = "badSpeak";
			pchar.GenQuest.CaptainComission.GetSlave = "NoSlave";
			pchar.GenQuest.CaptainComission.toMayor = true;
			SetFunctionTimerCondition("CaptainComission_30DaysIsLeft", 0, 0, 30, false);
			NextDiag.TempNode = "CaptainComission_7";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "CaptainComission_7":
			if(pchar.GenQuest.CaptainComission.GetSlave == "NoSlave")
			{
				if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "goodSpeak")
				{
					dialog.text = LinkRandPhrase("Bonjour, capitaine " + GetFullName(pchar) + ". Il y a du nouveau ?","Alors, capitaine, avez-vous déjà livré la rançon ?","Bonjour, j'espère que vous apportez de bonnes nouvelles ?");
					if(makeint(pchar.money)>=150000)
					{
						link.l1 = "Malheureusement, mes plans ont changé, je dois rompre notre accord.";
						link.l1.go = "CaptainComission_7_1";
					}
					link.l2 = "Pas encore. Je m'en occupe.";
					link.l2.go = "CaptainComission_7_2";
				}
				if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "badSpeak")
				{
					dialog.text = LinkRandPhrase("Ah, salutations, capitaine " + GetFullName(pchar) + ". Comment ça avance ?","Alors, capitaine, vous avez sauvé notre malheureux ?","Content de vous voir en bonne santé, capitaine. Comment avance notre affaire commune ?");
					link.l1 = "Pas encore de nouvelles, mais je m'en occupe.";
					link.l1.go = "CaptainComission_7_3";
					link.l2 = "וcoutez, mon cher, et de quel droit m'obligez-vous à m'occuper de cette affaire ?";
					link.l2.go = "CaptainComission_7_4";
				}
			}
			if(pchar.GenQuest.CaptainComission.GetSlave == "GetSlave")
			{
				if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "goodSpeak")
				{
					dialog.text = LinkRandPhrase("Bonjour, capitaine " + GetFullName(pchar) + ". Il y a du nouveau ?","Alors, capitaine, avez-vous déjà livré la rançon ?","Bonjour, j'espère que vous apportez de bonnes nouvelles ?");
					link.l1 = "Oui. Votre mission est accomplie : " + pchar.GenQuest.CaptainComission.SlaveName + " est à bord et se prépare à descendre à terre.";
					link.l1.go = "CaptainComission_30";
				}
				else
				{
					dialog.text = LinkRandPhrase("Ah, salutations, capitaine " + GetFullName(pchar) + ". Comment ça avance ?","Alors, capitaine, vous avez sauvé notre malheureux ?","Content de vous voir en bonne santé, capitaine. Comment avance notre affaire commune ?");
					link.l1 = "J'ai amené la personne dont vous parliez. Elle est à mon bord.";
					link.l1.go = "CaptainComission_32";
				}
			}
			if(pchar.GenQuest.CaptainComission.GetSlave == "SlaveDied")
			{
				if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "goodSpeak")
				{
					dialog.text = LinkRandPhrase("Bonjour, capitaine " + GetFullName(pchar) + ". Il y a du nouveau ?","Alors, capitaine, avez-vous déjà livré la rançon ?","Bonjour, j'espère que vous apportez de bonnes nouvelles ?");
					link.l1 = "Bonjour, " + pchar.GenQuest.CaptainComission.Name + ", je dois vous décevoir.";
					link.l1.go = "CaptainComission_50";
				}
				else
				{
					dialog.text = LinkRandPhrase("Ah, salutations, capitaine " + GetFullName(pchar) + ". Comment allez-vous ?","Alors, capitaine, vous avez sauvé notre malheureux ?","Content de vous voir en bonne santé, capitaine. Comment avance notre affaire commune ?");
					link.l1 = "La personne que vous m'avez demandée est morte.";
					link.l1.go = "CaptainComission_60";
				}
			}
		break;

		case "CaptainComission_30":
			dialog.text = "Merci, capitaine, vous avez rendu un service inestimable à toute notre famille. Voici votre récompense... Il y a trois coffres ici : 40 000 piastres tout juste. Excusez-moi, mais je me dépêche d'aller à sa rencontre.";
			link.l1 = "Bien sמr, bien sמr, heureuses retrouvailles, et tous mes vœux.";
			link.l1.go = "CaptainComission_30_1";
			if(CheckAttribute(pchar, "GenQuest.CaptainComission.SlaveAddMoney"))
			{
				link.l2 = "Je comprends votre impatience, mais des circonstances m'ont obligé à engager des frais supplémentaires.";
				link.l2.go = "CaptainComission_31";
			}
		break;

		case "CaptainComission_30_1":
			TakeNItems(pchar, "chest", 3);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("CaptainComission1", "14");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			CloseQuestHeader("CaptainComission1");
			ChangeCharacterReputation(pchar, 2);
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_EndTavern");
		break;

		case "CaptainComission_31":
			TakeNItems(pchar, "chest", 2);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			dialog.text = "Je ne vous comprends pas... Nous avions convenu du montant de la rémunération à l'avance.";
			link.l1 = "Oui, mais au lieu de 150 000 pièces d'or, j'ai dמ en payer 200 000. Et aller à la Barbade.";
			link.l1.go = "CaptainComission_31_1";
		break;

		case "CaptainComission_31_1":
			dialog.text = "Capitaine, ce n'est que le résultat de votre lenteur. Je n'ai reçu aucune condition supplémentaire de la part des pirates. Quelle drכle de façon d'essayer de tirer profit des malheurs des autres ?!";
			link.l1 = "Je vois qu'il est inutile de vous expliquer quoi que ce soit...";
			link.l1.go = "CaptainComission_31_1End";
		break;

		case "CaptainComission_31_1End":
			AddQuestRecord("CaptainComission1", "15");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			CloseQuestHeader("CaptainComission1");
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_EndTavern");
		break;

		case "CaptainComission_32":
			dialog.text = "Parfait ! Et vous qui doutiez que nous travaillerions ensemble.";
			link.l1 = "Mais j'ai dמ dépenser beaucoup pour cette affaire.";
			link.l1.go = "CaptainComission_32_1";
		break;

		case "CaptainComission_32_1":
			GetSlaveSpeciality();
			dialog.text = "Je sais, je sais... Mais c'est en partie de votre faute. Comment a-t-on pu couler trois coffres d'or, qu'on avait eu tant de mal à soutirer au trésor, pour que " + NationNameNominative(sti(pchar.GenQuest.CaptainComission.Nation)) + " puisse obtenir ce spécialiste " + pchar.GenQuest.CaptainComission.SlaveSpeciality + " ?";
			link.l1 = "Sachez que je n'ai pas l'intention de vous le remettre sans une compensation convenable.";
			link.l1.go = "CaptainComission_32_2";
		break;

		case "CaptainComission_32_2":
			dialog.text = "Voyons, vous qui êtes "+ GetSexPhrase("un homme intelligent","une fille intelligente") +", vous devez comprendre qu'il est trop tard pour marchander. Nous pourrions tout simplement saisir votre navire avec toute sa cargaison. Cependant, une compensation a été prévue à l'avance... Alors, au nom du gouvernement de " + NationNameGenitive(sti(pchar.GenQuest.CaptainComission.Nation)) + ", permettez-moi de vous féliciter pour la réussite de l'opération et de vous remettre ce précieux cadeau ainsi qu'une petite récompense en argent.";
			link.l1 = "Hum-hum... Merci quand même. Prenez votre important spécialiste.";
			link.l1.go = "CaptainComission_32_2End";
		break;

		case "CaptainComission_32_2End":
			AddQuestRecord("CaptainComission1", "16");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sSpeciality", pchar.GenQuest.CaptainComission.SlaveSpeciality);
			AddQuestUserData("CaptainComission1", "sNation", NationNameNominative(sti(pchar.GenQuest.CaptainComission.Nation)));
			CloseQuestHeader("CaptainComission1");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 15);
			GiveItem2Character(pchar, pchar.GenQuest.CaptainComission.Item);
			TakeNItems(pchar, "jewelry5", 100);
			PlaySound("interface\important_item.wav");
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_EndTavern");
		break;

		case "CaptainComission_7_1":
			dialog.text = "Oh, quel dommage ! J'ai déjà perdu trop de temps. Vous m'avez vraiment déçu, capitaine !";
			link.l1 = "Je comprends, mais les circonstances ont été plus fortes. Voici votre argent.";
			link.l1.go = "CaptainComission_7_1End";
		break;

		case "CaptainComission_7_1End":
			AddQuestRecord("CaptainComission1", "8");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			CloseQuestHeader("CaptainComission1");
			rChar = characterFromId("CapComission_1");
			rChar.lifeDay = 0;
			pchar.quest.CaptainComission1_30DaysIsLeft.over = "yes";
			addMoneyToCharacter(pchar, -150000);
			ChangeCharacterReputation(pchar, -4);
			LAi_CharacterDisableDialog(NPChar);
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_EndTavern");
		break;

		case "CaptainComission_7_2":
			dialog.text = "On ne pourrait pas se dépêcher ? J'ai peur que les pirates changent encore les conditions.";
			link.l1 = "Ne vous inquiétez pas, nous arriverons à temps.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_7";
		break;

		case "CaptainComission_7_3":
			dialog.text = "J'espère que vous comprenez que le temps joue contre vous ?";
			link.l1 = "Je vous répète que je m'occupe de votre affaire.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_7";
		break;

		case "CaptainComission_7_4":
			dialog.text = "Dieu m'en garde ! Aucune obligation : seulement l'aide bénévole d'un puritain... Il ne fallait pas vous mêler de ce qui ne vous regardait pas. Vous avez tué le capitaine " + pchar.GenQuest.CaptainComission.CapName + ", fait capoter la rançon d'une personne précieuse, et même notre or a été perdu. Maintenant, réparez les dégâts. Et ne comptez pas vous en tirer comme ça...";
			link.l1 = "Maudit sois-tu..";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_7";
		break;

		// диалоги с управляющим на плантации
		case "CaptainComission_10":
			dialog.text = "Bonjour, vous vouliez quelque chose ?";
			link.l1 = "Puis-je voir le propriétaire de la plantation ?";
			link.l1.go = "CaptainComission_10_1";
		break;

		case "CaptainComission_10_1":
			dialog.text = "Il est absent, il cherche un esclave en fuite, Blade ou Blood, je ne sais plus. Et je suis le régisseur, " + npchar.name + " de mon nom, et j'ai le pouvoir de régler toutes les questions en l'absence du propriétaire.";
			link.l1 = "Ah oui ? Très bien... Les questions de vente d'esclaves sont aussi de votre compétence ?";
			link.l1.go = "CaptainComission_10_2";
		break;

		case "CaptainComission_10_2":
			dialog.text = "Absolument. Vous avez un gros lot ?";
			link.l1 = "Non, je veux acheter un seul esclave.";
			link.l1.go = "CaptainComission_10_3";
		break;

		case "CaptainComission_10_3":
			dialog.text = "Euh, il ne vous faut vraiment qu'un seul esclave ?";
			link.l1 = "Oui, un seul : il s'appelle " + pchar.GenQuest.CaptainComission.SlaveName + ".";
			link.l1.go = "CaptainComission_10_4";
		break;

		case "CaptainComission_10_4":
			if(rand(1) == 0)
			{
				dialog.text = "Bon, vous comprenez bien que le prix d'un seul esclave sera toujours plus élevé que le prix unitaire d'un esclave acheté en gros lot ?";
				link.l1 = "Bon, puis-je enfin connaître ce prix ?";
				link.l1.go = "CaptainComission_11";
			}
			else
			{
				if(rand(100) < makeint(sti(pchar.rank) + 0.75 * GetSummonSkillFromName(pchar, SKILL_FORTUNE)))
				{
					dialog.text = "Hum, je suppose que vous savez qui vous demandez ?";
					link.l1 = "Dans quel sens ?";
					link.l1.go = "CaptainComission_12";
				}
				else
				{
					dialog.text = "Ah, ce fainéant. Je ne donnerais pas un sou pour lui. Il n'a rien fait depuis qu'on l'a amené. Et pourquoi le colonel dépense-t-il de l'argent pour ces forçats ? Les Noirs, c'est autre chose : ça, ce sont des travailleurs ! L'amour du travail, ils l'ont dans le sang. Et croyez-moi, peu leur importe le travail qu'ils font ! Si vous voulez, envoyez-les aux roseaux, si vous voulez, faites-en des présidents...";
					link.l1 = "Hé, mon cher, je n'ai pas besoin de Noirs, j'ai besoin de ce paresseux dont vous parliez.";
					link.l1.go = "CaptainComission_13";
				}
			}
		break;

		case "CaptainComission_11":
			dialog.text = "Bien sמr, bien sמr, voici la liste des prix... דa alors !!! 150 000 pièces d'or...";
			link.l1 = "Tout de même...";
			link.l1.go = "CaptainComission_11_1";
		break;

		case "CaptainComission_11_1":
			dialog.text = "C'est ce qui est écrit sur la liste des prix, regardez. Je n'y comprends rien moi-même... Les prix des autres esclaves sont normaux, mais pour une raison quelconque, le colonel a fixé une fortune pour celui-ci..";
			if(sti(pchar.money) >= 150000)
			{
				link.l1 = "Je crois deviner ce qui se passe ici... Voici l'argent, je l'emmène.";
				link.l1.go = "CaptainComission_14";
			}
			link.l2 = "Hum... Mais je ne libère pas un otage, j'achète juste un esclave. Vous ne trouvez pas qu'avec une telle somme, on peut acheter un navire tout armé ?";
			link.l2.go = "CaptainComission_15";
		break;

		case "CaptainComission_12":
			dialog.text = "Ce n'est pas un esclave ordinaire. Le colonel Bishop a donné des ordres stricts pour qu'on le surveille, il lui a même mis une garde renforcée.";
			link.l1 = "Alors on ne peut même pas l'acheter ?";
			link.l1.go = "CaptainComission_12_1";
		break;

		case "CaptainComission_12_1":
			dialog.text = "Pourquoi pas ? Le colonel en a fixé le prix à 200 000 pièces d'or, d'après la liste des prix.";
			if(sti(pchar.money) >= 200000)
			{
				link.l1 = "דa alors ! Je suppose que le colonel sait quel homme est tombé entre ses griffes...";
				link.l1.go = "CaptainComission_16";
			}
			link.l2 = "Hum... Mais je ne libère pas un otage, j'achète juste un esclave. Vous ne trouvez pas qu'avec une telle somme, on peut acheter un navire tout armé ?";
			link.l2.go = "CaptainComission_15";
		break;

		case "CaptainComission_13":
			dialog.text = "Ah oui, excusez-moi. Bishop a laissé une liste des prix quelque part par ici. Voyons, la voici. Mm-euh... ça alors !.. 150 000 !..";
			if(sti(pchar.money) >= 15000)
			{
				link.l1 = "Il y a sמrement une erreur. Vous conviendrez qu'une telle somme ne peut pas correspondre au prix d'un seul esclave. Je pense qu'il y a un zéro de trop et que la somme devrait être de 15 000. Et c'est déjà beaucoup pour un tel fainéant.";
				link.l1.go = "CaptainComission_17";
			}
			link.l2 = "Hum... Mais je ne libère pas un otage, j'achète juste un esclave. Vous ne trouvez pas qu'avec une telle somme, on peut acheter un navire tout armé ?";
			link.l2.go = "CaptainComission_15";
		break;

		case "CaptainComission_14":
			addMoneyToCharacter(pchar, -150000);
			pchar.GenQuest.CaptainComission.SlaveMoney = 150000;
			dialog.text = "Parfait ! Formidable ! On l'amène tout de suite... Euh, vous prendrez bien un thé ?";
			link.l1 = "Non, merci... Mes salutations au colonel Bishop.";
			link.l1.go = "CaptainComission_14_1";
		break;

		case "CaptainComission_14_1":
			dialog.text = "Et de la part de qui, excusez-moi ?";
			link.l1 = "Mm... Non, ce n'est pas la peine. Au revoir.";
			link.l1.go = "CaptainComission_14_1End";
		break;

		case "CaptainComission_14_1End":
			NextDiag.TempNode = "CaptainComission_18";
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.GenQuest.CaptainComission.GetSlave = "GetSlave";
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GetSlave");
		break;

		case "CaptainComission_15":
			dialog.text = "Hélas, malheureusement, je ne peux rien faire... Voici la liste des prix...";
			link.l1 = "Qu'est-ce que vous me chantez, liste des prix, liste des prix... Vous ne pouvez pas faire un pas sans Bishop. Dites-lui... Remarquez, pas besoin.";
			link.l1.go = "CaptainComission_15_1";
		break;

		case "CaptainComission_15_1":
			dialog.text = "Alors, vous n'achèterez pas cet esclave ?";
			link.l1 = "Non. Au revoir.";
			link.l1.go = "CaptainComission_15_1End";
		break;

		case "CaptainComission_15_1End":
			OfficersReaction("bad");
			AddQuestRecord("CaptainComission1", "30");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			NextDiag.TempNode = "CaptainComission_19";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GetSlave");
		break;

		case "CaptainComission_16":
			dialog.text = "Je ne sais rien de tout ça. J'ai seulement des instructions précises en cas de vente.";
			link.l1 = "Le diable sait ce que c'est... Voici l'argent. Faites amener l'esclave.";
			link.l1.go = "CaptainComission_16_1";
		break;

		case "CaptainComission_16_1":
			addMoneyToCharacter(pchar, -200000);
			pchar.GenQuest.CaptainComission.SlaveMoney = 200000;
			dialog.text = "Oui, bien sמr. On vous l'amène tout de suite.";
			link.l1 = "Au revoir.";
			link.l1.go = "CaptainComission_16_1End";
		break;

		case "CaptainComission_16_1End":
			NextDiag.TempNode = "CaptainComission_18";
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.GenQuest.CaptainComission.GetSlave = "GetSlave";
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GetSlave");
		break;

		case "CaptainComission_17":
			dialog.text = "Euh, vous avez sans doute raison. Une simple erreur.";
			link.l1 = "Bon, puisque nous sommes d'accord sur le prix, puis-je l'emmener ?";
			link.l1.go = "CaptainComission_17_1";
		break;

		case "CaptainComission_17_1":
			dialog.text = "Oui, bien sמr. On l'amène tout de suite.";
			link.l1 = "Parfait. Voici votre argent... Au revoir.";
			link.l1.go = "CaptainComission_17_1End";
		break;

		case "CaptainComission_17_1End":
			addMoneyToCharacter(pchar, -15000);
			pchar.GenQuest.CaptainComission.SlaveMoney = 15000;
			NextDiag.TempNode = "CaptainComission_18";
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.GenQuest.CaptainComission.GetSlave = "GetSlave";
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GetSlave");
		break;

		case "CaptainComission_18":
			dialog.text = "Une tasse de thé, capitaine ?";
			link.l1 = "Non. Merci.";
			link.l1.go = "exit";
		break;

		case "CaptainComission_19":
			dialog.text = "Vous avez finalement décidé de l'acheter ?";
			link.l1 = "Non. Au revoir.";
			link.l1.go = "exit";
		break;

		// диалоги с рабом
		case "CaptainComission_20":
			if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "goodSpeak")
			{
				dialog.text = "Bonjour, capitaine. Comment puis-je vous remercier ? Je n'arrive pas à croire que cet enfer est fini.";
				link.l1 = "Ce n'est pas moi qu'il faut remercier, mais votre parent, " + pchar.GenQuest.CaptainComission.Name + " de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen") + ". C'est lui qui a réuni votre rançon.";
				link.l1.go = "CaptainComission_201";
			}
			else
			{
				dialog.text = "Bonjour, capitaine. On m'a dit que c'est vous qui avez payé la caution. Merci, même si je comprends que vous n'êtes qu'un messager.";
				link.l1 = "Et vous n'avez pas l'air ravi de votre liberté retrouvée. Quelque chose vous tracasse ?";
				link.l1.go = "CaptainComission_202";
			}
		break;

		case "CaptainComission_201":
			dialog.text = "Je vous en supplie, si cela ne contrarie pas vos plans, emmenez-moi auprès de lui. Je dois le remercier.";
			link.l1 = "Bien sמr. Venez, je vous emmène à bord.";
			link.l1.go = "CaptainComission_201_1";
		break;

		case "CaptainComission_201_1":
			AddQuestRecord("CaptainComission1", "11");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sSum", pchar.GenQuest.CaptainComission.SlaveMoney);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", "reload2_back", "none", "", "", "OpenTheDoors", -1.0);
			DialogExit();
		break;

		case "CaptainComission_202":
			dialog.text = "Pour être sמr de ma liberté, j'ai besoin de connaître les noms de ceux qui l'ont payée.";
			link.l1 = "Eh bien, disons que c'est moi qui l'ai payée, même si je n'avais pas le choix.";
			link.l1.go = "CaptainComission_202_1";
		break;

		case "CaptainComission_202_1":
			dialog.text = "Ainsi, mes craintes se confirment. C'est donc un coup monté par " + NationNamePeople(sti(pchar.GenQuest.CaptainComission.Nation)) + " ?";
			link.l1 = "Oui, c'est " + pchar.GenQuest.CaptainComission.Name + " de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen") + ".";
			link.l1.go = "CaptainComission_202_2";
		break;

		case "CaptainComission_202_2":
			iNation = FindEnemyNation2NationWithoutPirates(sti(pchar.GenQuest.CaptainComission.Nation));
			if(iNation == -1) iNation(rand(3));
			pchar.GenQuest.CaptainComission.SlaveCity = FindAlliedColonyForNation(iNation, true);
			pchar.GenQuest.CaptainComission.EnemyNation = iNation;
			dialog.text = "C'est clair... Je ne sais pas ce qu'on vous a promis, mais je vous propose un marché : vous m'emmenez à la taverne de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.SlaveCity + "Gen") + ", oם je serai vraiment en sécurité, et je partagerai avec vous une partie des informations que je possède.";
			link.l1 = "Bien. D'ailleurs, on ne m'a rien promis. Suivez-moi, je vous emmène au navire.";
			link.l1.go = "CaptainComission_202_3";
			link.l2 = "Je ne vais pas risquer d'avoir des ennuis pour une information douteuse.";
			link.l2.go = "CaptainComission_203";
		break;

		case "CaptainComission_202_3":
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			rChar = characterFromId("CapComission_1");
			ChangeCharacterAddress(rChar, "none", "");
			rChar.lifeDay = 0;
			AddQuestRecord("CaptainComission1", "12");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sSum", pchar.GenQuest.CaptainComission.SlaveMoney);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.SlaveCity + "Gen"));
			pchar.quest.CapComission_DeliveSlave.win_condition.l1 = "location";
			pchar.quest.CapComission_DeliveSlave.win_condition.l1.location = pchar.GenQuest.CaptainComission.SlaveCity + "_tavern";
			pchar.quest.CapComission_DeliveSlave.function = "CaptainComission_DeliveSlave";
			DialogExit();
		break;

		case "CaptainComission_203":
			dialog.text = "Malheureusement, je ne peux pas vous en dévoiler la teneur maintenant. Cela pourrait nous nuire à tous les deux.";
			link.l1 = "Raison de plus... Suivez-moi et n'essayez pas de faire le malin. Considérez-vous de nouveau en état d'arrestation.";
			link.l1.go = "CaptainComission_203_1";
		break;

		case "CaptainComission_203_1":
			AddQuestRecord("CaptainComission1", "13");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sSum", pchar.GenQuest.CaptainComission.SlaveMoney);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			DialogExit();
		break;

		case "CaptainComission_50":
			dialog.text = "Quoi ?! Les pirates ont encore changé les conditions ? Mais je ne peux plus retirer d'argent de mes affaires. Bientכt, toute mon entreprise va partir à vau-l'eau !";
			link.l1 = "Non... Votre parent est mort dans les plantations de la Barbade, lors d'une tentative d'évasion manquée.";
			link.l1.go = "CaptainComission_51";
		break;

		case "CaptainComission_51":
			ChangeCharacterReputation(pchar, -3);
			dialog.text = "Ah... Je suis anéanti... Comment est-ce arrivé ?";
			link.l1 = "Les pirates, sans attendre la rançon, l'ont vendu comme esclave. Je l'ai suivi jusqu'à la Barbade, mais je n'ai pas pu le sauver...";
			link.l1.go = "CaptainComission_52";
		break;

		case "CaptainComission_52":
			dialog.text = "Mon Dieu ! Que se passe-t-il ? Bien, capitaine, merci pour votre participation... Et s'il vous plaît, rendez-moi l'argent que je vous ai avancé pour la rançon.";
			link.l1 = "Mes frais ont dépassé toutes les prévisions, je garde donc votre argent... Adieu.";
			link.l1.go = "CaptainComission_53";
			if(sti(pchar.money) >= 150000)
			{
				link.l2 = "Oui, bien sמr, prenez-le... Désolé de n'avoir pas pu vous aider... Adieu.";
				link.l2.go = "CaptainComission_54";
			}
		break;

		case "CaptainComission_53":
			ChangeCharacterReputation(pchar, -5);
			OfficersReaction("bad");
			AddQuestRecord("CaptainComission1", "22");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			CloseQuestHeader("CaptainComission1");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_54":
			OfficersReaction("good");
			addMoneyToCharacter(pchar, -150000);
			AddQuestRecord("CaptainComission1", "23");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			CloseQuestHeader("CaptainComission1");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_60":
			dialog.text = "C'est mauvais... vous n'avez pas idée à quel point c'est mauvais..";
			link.l1 = "Je ne peux pas vous aider... דa me convient même que ça ait tourné ainsi. Adieu.";
			link.l1.go = "CaptainComission_61";
		break;

		case "CaptainComission_61":
			ChangeCharacterReputation(pchar, -2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -15);
			AddQuestRecord("CaptainComission1", "32");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.Name);
			CloseQuestHeader("CaptainComission1");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			DialogExit();
		break;

		// диалог с рабом в колодках
		case "CaptainComission_70":
			dialog.text = "א boire... Capitaine, apportez de l'eau...";
			link.l1 = "Hé, l'ami, tu ne serais pas " + pchar.GenQuest.CaptainComission.SlaveName + " ?";
			link.l1.go = "CaptainComission_71";
		break;

		case "CaptainComission_71":
			dialog.text = "Oui... C'est moi...";
			link.l1 = "וcoute, si tu ne veux pas crever ici comme une limande sur un haut-fond, je te conseille de te réveiller et de m'écouter. Tu sais oם se trouve le phare de la Barbade ?";
			link.l1.go = "CaptainComission_72";
		break;

		case "CaptainComission_72":
			dialog.text = "Je sais...";
			link.l1 = "Dès que tu en auras l'occasion, cours-y. Et moi, j'essaierai de t'organiser cette occasion.";
			link.l1.go = "CaptainComission_73";
		break;

		case "CaptainComission_73":
			LAi_SetPlayerType(pchar);
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			LAi_LockFightMode(pchar, false);
			sTemp = GetNationNameByType(GetCityNation("Bridgetown"))  + "_citizens";
			for(i = 0; i < 3; i++)
			{
				if (GetCharacterIndex("SlaveGuard_" + i) == -1) continue;
				sld = CharacterFromID("SlaveGuard_" + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "SlaveGuards");
			}

			LAi_group_SetRelation("SlaveGuards", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_SetRelation("SlaveGuards", sTemp, LAI_GROUP_NEITRAL);
			LAi_group_SetAlarmReaction("SlaveGuards", sTemp, LAI_GROUP_NEITRAL, LAI_GROUP_FRIEND);
			LAi_group_FightGroups("SlaveGuards", LAI_GROUP_PLAYER, true);
			LAi_group_SetAlarm("SlaveGuards", LAI_GROUP_PLAYER, 0);
			LAi_group_SetCheck("SlaveGuards", "OpenTheDoors");
			LAi_group_SetCheckFunction("SlaveGuards", "CaptainComission_GuardsAfter");

			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		// диалог охранников раба
		case "CaptainComission_80":
			dialog.text = RandPhraseSimple("Demandez, capitaine, mais brièvement : je suis de service.","Ne parlez que d'affaires, je ne peux pas me laisser distraire par des broutilles.");
			link.l1 = RandPhraseSimple("Pouvez-vous me dire comment trouver un esclave ? Il s'appelle " + pchar.GenQuest.CaptainComission.SlaveName + ".","Quelque part sur la plantation, il doit y avoir un esclave nommé " + pchar.GenQuest.CaptainComission.SlaveName + ". Pouvez-vous me dire comment lui parler ?");
			link.l1.go = "CaptainComission_81";
		break;

		case "CaptainComission_81":
			dialog.text = "Il a été puni aujourd'hui et se trouve au cachot.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_80";
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "CaptainComission_85":
			dialog.text = "Merci... Capitaine, vous m'avez sauvé la vie...";
			link.l1 = "Cours au phare de la Barbade et attends-moi là-bas.";
			link.l1.go = "CaptainComission_86";
		break;

		case "CaptainComission_86":
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload2_back", "none", "", "", "OpenTheDoors", -1.0);
			sTemp = GetNationNameByType(GetCityNation("Bridgetown"))  + "_citizens";
			LAi_group_AttackGroup(sTemp, LAI_GROUP_PLAYER);
			DialogExit();
		break;

		case "CaptainComission_90":
			if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "goodSpeak")
			{
				dialog.text = "Capitaine, comment puis-je vous remercier ? Je n'arrive pas à croire que cet enfer est fini.";
				link.l1 = "Votre parent s'est déjà chargé de me remercier : " + pchar.GenQuest.CaptainComission.Name + " de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen") + ". J'agis en son nom.";
				link.l1.go = "CaptainComission_91";
			}
			if(pchar.GenQuest.CaptainComission.AfterTavernSpeak == "badSpeak")
			{
				dialog.text = "Merci, capitaine. Je ne sais pas au nom de qui vous agissez, mais une mauvaise liberté vaut toujours mieux qu'un bon esclavage.";
				link.l1 = "De quoi parlez-vous ?";
				link.l1.go = "CaptainComission_92";
			}
		break;

		case "CaptainComission_91":
			dialog.text = "Si cela ne contrarie pas vos plans, emmenez-moi auprès de lui. Je suis trop las de tout ça.";
			link.l1 = "Bien sמr, si je sors d'ici en vie.";
			link.l1.go = "CaptainComission_91End";
		break;

		case "CaptainComission_91End":
			pchar.GenQuest.CaptainComission = "toOurTavern";
			rChar = CharacterFromID("CapComission_Slave");
			LAi_SetWarriorType(rChar);
			LAi_group_MoveCharacter(rChar, LAI_GROUP_PLAYER);
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePatrol");
		break;

		case "CaptainComission_92":
			dialog.text = "Puis-je connaître les noms des gens qui vous ont payé pour ma libération ?";
			link.l1 = "Eh bien, disons que personne ne m'a rien payé... Je n'avais simplement pas le choix.";
			link.l1.go = "CaptainComission_93";
		break;

		case "CaptainComission_93":
			dialog.text = "Ainsi, mes craintes se confirment. C'est donc un coup monté par " + NationNamePeople(sti(pchar.GenQuest.CaptainComission.Nation)) + " ?";
			link.l1 = "Oui, c'est " + pchar.GenQuest.CaptainComission.Name + " de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen") + ".";
			link.l1.go = "CaptainComission_94";
		break;

		case "CaptainComission_94":
			iNation = FindEnemyNation2Nation(sti(pchar.GenQuest.CaptainComission.Nation));
			if(iNation == -1) iNation(rand(3));
			pchar.GenQuest.CaptainComission.SlaveCity = FindAlliedColonyForNation(iNation, true);
			pchar.GenQuest.CaptainComission.EnemyNation = iNation;
			dialog.text = "C'est clair... Je ne sais pas ce qu'on vous a promis, mais je vous propose un marché : vous m'emmenez à la taverne de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.SlaveCity + "Gen") + ", oם je serai vraiment en sécurité, et je partagerai avec vous une partie des informations que j'ai.";
			link.l1 = "Bien. D'ailleurs, on ne m'a rien promis. Suivez-moi, je vous emmène au navire.";
			link.l1.go = "CaptainComission_95";
			link.l2 = "Je ne vais pas risquer d'avoir des ennuis pour une information douteuse.";
			link.l2.go = "CaptainComission_96";
		break;

		case "CaptainComission_95":
			pchar.GenQuest.CaptainComission = "toEnemyTavern";
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePatrol");
		break;

		case "CaptainComission_96":
			dialog.text = "Malheureusement, je ne peux pas vous en dévoiler la teneur maintenant. Cela pourrait nous nuire à tous les deux.";
			link.l1 = "Raison de plus... Suivez-moi et n'essayez pas de faire le malin. Considérez-vous de nouveau en état d'arrestation.";
			link.l1.go = "CaptainComission_97";
		break;

		case "CaptainComission_97":
			pchar.GenQuest.CaptainComission = "toTavern";
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePatrol");
		break;

		case "CaptainComission_100":
			dialog.text = "Merci, capitaine. Maintenant, je suis vraiment en sécurité. Je ne vous offre pas d'argent, car je suis sמr que le savoir et son habile usage valent bien plus que ce métal périssable.";
			link.l1 = "J'attends l'information promise.";
			link.l1.go = "CaptainComission_101";
		break;

		case "CaptainComission_101":
			GetSlaveSpeciality();
			dialog.text = "Le fait est que je suis un savant, spécialiste " + pchar.GenQuest.CaptainComission.SlaveSpeciality + " et " + NationNamePeople(sti(pchar.GenQuest.CaptainComission.EnemyNation)) + " me proposent depuis longtemps de collaborer avec eux, " +
				"mais, en tant qu'ingénieur militaire, je suis resté fidèle à mon serment. Alors ils ont essayé de m'enlever. Mais ce n'était encore que la moitié du problème : le vrai cauchemar a commencé quand les chefs pirates ont appris l'importance de ma personne\n"+
				"Finalement, ils ont réussi à m'enlever, mais ils étaient avides d'or, et mon savoir ne les intéressait pas. Les parties intéressées, mes alliés comme mes adversaires, ont pour une raison ou une autre retardé la rançon, si bien que je me suis retrouvé dans les plantations... Bon, la suite, vous la connaissez.";
			link.l1 = "Oui, c'est le malheur d'avoir trop d'esprit, on ne peut pas dire autrement.";
			link.l1.go = "CaptainComission_102";
		break;

		case "CaptainComission_102":
			switch(sti(pchar.GenQuest.CaptainComission.Speciality))
			{
				case 0:
					sTemp = "protéger le navire et l'équipage pendant le combat.";
				break;
				case 1:
					sTemp = "charger rapidement les canons et mener un tir d'artillerie précis par mer agitée.";
				break;
				case 2:
					sTemp = "manœuvrer rapidement les voiles et le navire pendant le combat.";
				break;
			}
			dialog.text = "Eh bien, on peut le dire comme ça. Si vous m'écoutez attentivement, vous surpasserez vos adversaires dans l'art de " + sTemp;
			link.l1 = "Merci, l'information reçue est vraiment très utile.";
			link.l1.go = "CaptainComission_103";
		break;

		case "CaptainComission_103":
			dialog.text = "Eh bien, adieu, et merci pour tout.";
			link.l1 = "Merci à vous. Adieu, et ne vous faites plus prendre.";
			link.l1.go = "CaptainComission_104";
		break;

		case "CaptainComission_104":
			AddQuestRecord("CaptainComission1", "21");
			CloseQuestHeader("CaptainComission1");
			// а теперь раздача слонов !!!!!!!
			switch(sti(pchar.GenQuest.CaptainComission.Speciality))
			{
				case 0:
					if(drand(1) == 0)
					{
						AddCharacterSkill(pchar, SKILL_DEFENCE, 10);
					}
					else
					{
						AddCharacterSkill(pchar, SKILL_REPAIR, 10);
					}
				break;
				case 1:
					if(drand(1) == 0)
					{
						AddCharacterSkill(pchar, SKILL_CANNONS, 10);
					}
					else
					{
						AddCharacterSkill(pchar, SKILL_ACCURACY, 10);
					}
				break;
				case 2:
					AddCharacterSkill(pchar, SKILL_SAILING, 10);
				break;
			}
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "","OpenTheDoors", -1.0);
			NPChar.lifeDay = 0;
			DeleteAttribute(pchar,"GenQuest.CaptainComission");
			DialogExit();
		break;
		// Генератор "The Captain's errand"

		// Генератор "Operation Galleon"
		case "CaptainComission_300":
			ReOpenQuestHeader("CaptainComission2");
			AddQuestRecord("CaptainComission2", "1");
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.CapName);
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Gen")));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sCapName",  pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sCity1", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Voc"));
			AddQuestUserData("CaptainComission2", "sShipTypeNom", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name"))));
			AddQuestUserData("CaptainComission2", "sCity2", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City1 + "Gen"));
			AddQuestUserData("CaptainComission2", "sCity11", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			SetFunctionLocationCondition("CaptainComission_GenerateQuestContinuation", GetArealByCityName(pchar.GenQuest.CaptainComission.City), false);
			SetFunctionTimerCondition("CaptainComission_TimeIsOver", 0, 0, 15, false);
			SaveCurrentQuestDateParam("GenQuest.CaptainComission");
			LAi_KillCharacter(NPChar);
			LAi_SetPlayerType(pchar);
			pchar.GenQuest.CaptainComission = "Begin_1";
			LAi_EnableReload();
			Log_SetActiveAction("Reload");
			DialogExit();
		break;

		// диалог с кэпом на палубе
		case "CaptainComission_301":
			pchar.quest.CaptainComission_TimeIsOver.over = "yes";
			dialog.text = RandPhraseSimple("Bonjour, je suis le capitaine " + GetFullName(NPChar) + ", qu'est-ce qui vous amène sur le pont de mon navire, le '" + pchar.GenQuest.CaptainComission.ShipTypeName + "'?","Bonjour, je suis toujours heureux d'accueillir des invités à bord de mon navire. Capitaine " + GetFullName(NPChar) + ", pour vous servir.");
			link.l1 = "Bonjour, je me présente : capitaine " + GetFullName(pchar) +", j'agis au nom d'un certain capitaine " + pchar.GenQuest.CaptainComission.CapName +". Il m'a demandé de vous dire qu'à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Voc") + " vous serez arrêté. Les autorités ont eu vent d'une histoire concernant un certain navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Acc")) + " – si je ne me trompe pas.";
			link.l1.go = "CaptainComission_302";
		break;

		case "CaptainComission_302":
			dialog.text = "Oh, quel échec ! Attendez, laissez-moi réfléchir... Et oם est donc le capitaine " + pchar.GenQuest.CaptainComission.CapName + " ?";
			link.l1 = "Il est mort.";
			link.l1.go = "CaptainComission_303";
		break;

		case "CaptainComission_303":
			dialog.text = "Bon sang ! דa ne s'arrange pas d'heure en heure... וcoutez, " + GetFullName(pchar) + ", je ne suis pas du tout prêt à un tel retournement. Le capitaine " + pchar.GenQuest.CaptainComission.CapName + " et moi avions convenu de nous retrouver à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Voc") + " pour charger des marchandises à bord. Et voilà que le capitaine est mort, et que je ne peux même pas me montrer dans la colonie pour organiser l'enlèvement de la cargaison. On dirait que je n'ai pas d'autre choix que de vous demander de l'aide.";
			link.l1 = "Mon accord dépendra du genre d'aide dont vous avez besoin.";
			link.l1.go = "CaptainComission_304";
		break;

		case "CaptainComission_304":
			pchar.GenQuest.CaptainComission.ShoreLocation = SelectQuestShoreLocationFromSea(GetArealByCityName(pchar.GenQuest.CaptainComission.City));
			dialog.text = "Aidez-moi avec des hommes et des chaloupes à sortir la cargaison de " + XI_ConvertString(pchar.GenQuest.CaptainComission.ShoreLocation + "Gen") + ", et en échange, vous prendrez tout ce qui ne tiendra pas dans ma cale.";
			link.l1 = "Hum, on dirait que vous avez eu les yeux plus gros que le ventre.";
			link.l1.go = "CaptainComission_305";
			link.l2 = "Malheureusement, les circonstances ne me permettent pas de perdre du temps avec ça.";
			link.l2.go = "CaptainComission_306";
		break;

		case "CaptainComission_305":
			string sTempAcc = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Acc"));
			sTemp = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen"));//здесь нужен винительный падеж? его нет в коммон ини пока что
			dialog.text = "Bon, pour ne pas vous mener en bateau, je vais tout vous raconter dans l'ordre. " +
				"Lors d'une patrouille, j'ai croisé un navire battant pavillon de " + NationNameGenitive(sti(pchar.GenQuest.CaptainComission.Nation)) + ". Il a ignoré l'ordre de mettre en panne. " +
				"Après une courte poursuite, nous avons rattrapé ce navire de type " + sTemp + " '" + pchar.GenQuest.CaptainComission.VictimShipName + "', et les fugitifs ont hissé le pavillon pirate. Comme nous étions déjà loin du fort, j'ai dמ livrer combat seul. Nous avions une brèche dans la cloison, nous n'avons donc pas pu éviter l'abordage\n" +
				"Nous nous préparions déjà à mourir, mais grâce à la Sainte Vierge Marie et à un peloton de mousquetaires, nous avons réussi à tuer les pirates. Quelle n'a pas été notre joie en ouvrant la cale de ce navire de type " + sTempAcc + " : elle était remplie à ras bord de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Abl")) + ".\n" +
				"Nous avons décidé que c'était un signe de Dieu et une juste compensation pour nos blessures et la mort de nos camarades...\nLe crépuscule était déjà tombé. Nous avons amené le navire de type " + sTemp +" dans la baie la plus proche, nous avons débarqué le contenu de la cale et l'avons caché en lieu sמr, puis le navire de type " + sTemp + " a été remorqué au large et sabordé à l'explosif. Le lendemain matin, j'ai signalé à mon service le naufrage d'un navire pirate, sans dire un mot du contenu de la cale.";
			link.l1 = "Mais on dirait que quelqu'un a quand même vendu la mèche...";
			link.l1.go = "CaptainComission_307";
		break;

		case "CaptainComission_306":
			dialog.text = "Je suis navré, capitaine... Dommage que vous ne vouliez pas m'aider.";
			link.l1 = "Ce n'est pas une question d'envie, mon cher. Vous le comprenez bien... Au revoir...";
			link.l1.go = "CaptainComission_306End";
		break;

		case "CaptainComission_306End":
			AddQuestRecord("CaptainComission2", "3");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.CapName);
			CloseQuestHeader("CaptainComission2");
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "", 1.5);
			pchar.GenQuest.CaptainComission = "close";
			SetFunctionExitFromLocationCondition("CaptainComission_ExitFromLoc", pchar.location, false);
			DialogExit();
		break;

		case "CaptainComission_307":
			dialog.text = "Je ne pense pas que ce soient mes hommes. Le plus probable, c'est le propriétaire de la cargaison qui essaie de se rattraper de son échec. Alors ? Puis-je compter sur votre aide ?";
			link.l1 = "Oui, je crois que ça m'intéresse.";
			link.l1.go = "CaptainComission_308";
			link.l2 = "Non, mon cher. Premièrement : je ne sais pas combien de marchandises tiendront dans ma cale, et deuxièmement : rien ne garantit que les autorités ne les ont pas trouvées et emportées, en laissant une embuscade près de la cachette.";
			link.l2.go = "CaptainComission_309";
		break;

		case "CaptainComission_308":
			dialog.text = "Alors retrouvons-nous à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ShoreLocation + "Abl") + " juste après minuit : dans ma situation actuelle, il est trop dangereux de traîner en rade. Pourvu que la patrouille ne nous trouve pas.";
			link.l1 = "D'accord, attendez-moi là-bas.";
			link.l1.go = "CaptainComission_313";
		break;

		case "CaptainComission_309":
			dialog.text = "Désolé, mais vous ne me laissez pas le choix. Un seul navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " ne suffit pas pour emporter toute la cargaison, pour laquelle j'ai sacrifié une brillante carrière et risqué ma vie. Et votre équipage, contrairement à vous, ne refusera sמrement pas de m'aider en échange de sa part.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "CaptainComission_310";
		break;

		case "CaptainComission_310":
			dialog.text = "Je vais prendre votre navire et vous laisser à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ShoreLocation + "Abl") + ".";
			link.l1 = "Peu probable que vous y arriviez. Je remonterai à bord, même si je dois massacrer tout votre équipage pour ça.";
			link.l1.go = "CaptainComission_311";
			link.l2 = "On dirait que vous ne me laissez pas le choix non plus. Bon, je dois céder à la force...";
			link.l2.go = "CaptainComission_312";
		break;

		case "CaptainComission_311":
			pchar.GenQuest.CaptainComission.FightAfterDeck = true; //после резни на палубе - драка в море
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "CaptainComission_FightInDeck", 3.5);
			DialogExit();
		break;

		case "CaptainComission_312":
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_toShore");
		break;

		case "CaptainComission_313":
			NextDiag.TempNode = "CaptainComission_314";
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddQuestRecord("CaptainComission2", "7");
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ShoreLocation + "Gen"));
			AddQuestUserData("CaptainComission2", "sShoreNameDat", XI_ConvertString(pchar.GenQuest.CaptainComission.ShoreLocation + "Abl"));
			SetFunctionTimerCondition("CaptainComission_SailToShore", 0, 0, 1, false);
			DialogExit();
		break;

		case "CaptainComission_314":
			NextDiag.TempNode = "CaptainComission_314";
			dialog.text = "Capitaine, il faut se dépêcher. J'ai peur que la patrouille ne nous trouve.";
			link.l1 = "D'accord, dépêchons-nous.";
			link.l1.go = "exit";
		break;

		case "CaptainComission_315":
			dialog.text = "Capitaine, donnez l'ordre de mettre toutes les chaloupes à l'eau. Il faudra faire plus d'un voyage, et j'ai peur qu'une patrouille n'entre dans la baie.";
			link.l1 = "Ne vous inquiétez pas, tout se passera au mieux. Les chaloupes approchent déjà du rivage.";
			link.l1.go = "CaptainComission_316";
		break;

		case "CaptainComission_316":
			dialog.text = "Oh, bon sang ! Et voici les invités...";
			link.l1 = "Ce n'est pas pour rien qu'on dit : quand on parle du loup...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainComission_GenerateShorePatrol");
		break;

		// диалог с патрулём на берегу
		case "CaptainComission_317":
			dialog.text = "Capitaine, nous recherchons un criminel de guerre, " + pchar.GenQuest.CaptainComission.Name + ", qui a caché une cargaison de valeur aux autorités. Présentez vos papiers.";
			link.l1 = "Officier, quels papiers ? Nous avons débarqué pour refaire nos provisions d'eau douce.";
			link.l1.go = "CaptainComission_318";
		break;

		case "CaptainComission_318":
			dialog.snd = "Voice\COGU\COGU004";
			dialog.text = "Mais on dirait que c'est lui-même. Rendez vos armes et suivez-moi... tous les deux.";
			link.l1 = "Eh, officier, vous tombez bien mal...";
			link.l1.go = "CaptainComission_319";
		break;

		case "CaptainComission_319":
			DialogExit();
			for (i = 1; i <= sti(pchar.GenQuest.CaptainComission.SoldierQty); i++)
			{
    			sTemp = "SoldierIDX" + i;
				sld = GetCharacter(sti(pchar.GenQuest.CaptainComission.(sTemp)));
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "CoastalGuards");
            }

			LAi_group_SetHearRadius("CoastalGuards", 100.0);
			sld = characterFromId("CapComission_1");
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			LAi_group_SetRelation("CoastalGuards", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("CoastalGuards", LAI_GROUP_PLAYER, true);
            LAi_SetFightMode(Pchar, true);
		break;

		case "CaptainComission_320":
			pchar.GenQuest.CaptainComission.GoodsQty = makeint((sti(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Capacity")) - sti(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Capacity")) + rand(250)) / sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Weight));
			pchar.GenQuest.CaptainComission.GoodsQtyNorm = sti(pchar.GenQuest.CaptainComission.GoodsQty);
			dialog.text = "Il faut se dépêcher avant que des renforts n'arrivent. Le chargement touche à sa fin, votre part : " + pchar.GenQuest.CaptainComission.GoodsQty + " unités de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")) +".";
			link.l1 = "Parfait. Il est temps de partir. Ce fut un plaisir de faire affaire avec vous.";
			link.l1.go = "CaptainComission_321";
		break;

		case "CaptainComission_321":
			iTmp = FindNonEnemyColonyForAdventure(sti(pchar.GenQuest.CaptainComission.Nation),pchar.GenQuest.CaptainComission.City, true);
			sTemp = Colonies[iTmp].id;
			pchar.GenQuest.CaptainComission.ConvoyIsland = GetArealByCityName(sTemp);
			pchar.GenQuest.CaptainComission.ConvoyShore = SelectQuestShoreLocationFromSea(pchar.GenQuest.CaptainComission.ConvoyIsland);
			pchar.GenQuest.CaptainComission.ConvoyCity = sTemp;
			dialog.text = "Encore une demande. Les autorités vont sמrement organiser une poursuite : pourriez-vous escorter mon navire jusqu'à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Gen") + " sur l'île de " + XI_ConvertString(GetIslandByCityName(sTemp) + "Voc") + " ?";
			link.l1 = "Non, mon cher, à partir de là, c'est chacun pour soi. Adieu...";
			link.l1.go = "CaptainComission_322";
			if (GetCompanionQuantity(pchar) < COMPANION_MAX)
			{
				link.l2 = "Bien sמr que je le pourrais, si la récompense est à la hauteur.";
				link.l2.go = "CaptainComission_323";
			}
		break;

		case "CaptainComission_322":
			Group_DeleteGroup("Sea_CapComission_1");
			sld = characterFromId("CapComission_1");
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			sld.lifeDay = 0;
			CaptainComission_GenerateCoastalPatrol();
			iGoods = GetSquadronFreeSpace(pchar, sti(pchar.GenQuest.CaptainComission.Goods));
			if(iGoods < sti(pchar.GenQuest.CaptainComission.GoodsQty)) pchar.GenQuest.CaptainComission.GoodsQty = iGoods;
			AddCharacterGoods(pchar, sti(pchar.GenQuest.CaptainComission.Goods), sti(pchar.GenQuest.CaptainComission.GoodsQty));// меняю на распредление по всей эскадре
			AddQuestRecord("CaptainComission2", "10");
			AddQuestUserData("CaptainComission2", "sGoodsQuantity", pchar.GenQuest.CaptainComission.GoodsQty);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			CloseQuestHeader("CaptainComission2");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_323":
			sld = characterFromId("CapComission_1");
			Fantom_SetCharacterGoods(sld, sti(pchar.GenQuest.CaptainComission.Goods), GetCargoFreeSpace(sld), 1);
			pchar.GenQuest.CaptainComission.ConvoyMoney = makeint((sti(pchar.rank)*100 + sti(NPChar.rank)*170 + cRand(30)*20) * 2.5);
			pchar.GenQuest.CaptainComission.iDay  = 15 + cRand(10);
			iGoods = GetSquadronFreeSpace(pchar, sti(pchar.GenQuest.CaptainComission.Goods));
			if(iGoods < sti(pchar.GenQuest.CaptainComission.GoodsQty)) pchar.GenQuest.CaptainComission.GoodsQty = iGoods;
			AddCharacterGoods(pchar, sti(pchar.GenQuest.CaptainComission.Goods), sti(pchar.GenQuest.CaptainComission.GoodsQty));// меняю на распредление по всей эскадре

			dialog.text = "Cela va sans dire. Je suis prêt à payer pour l'escorte " + pchar.GenQuest.CaptainComission.ConvoyMoney + " pièces d'or. Mais à condition que nous n'y passions pas plus de " + pchar.GenQuest.CaptainComission.iDay + " jours. C'est important.";
			link.l1 = "Marché conclu. Partons immédiatement.";
			link.l1.go = "CaptainComission_324";
			NextDiag.TempNode = "CaptainComission_325";
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "CaptainComission_324":
			pchar.GenQuest.CannotWait = 1; // лочим интерфейс отдыха
			sld = characterFromId("CapComission_1");
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(sld);
			LAi_ActorSetStayMode(sld);
			CharacterIntoCompanionAndGoOut(pchar, sld, "reload", sTemp, 5, false);
			SetShipRemovable(sld, false);
			SetCharacterRemovable(sld, false);
			Group_ChangeCharacter(PLAYER_GROUP, "CapComission_1");
			AddQuestRecord("CaptainComission2", "11");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sGoodsQuantity", pchar.GenQuest.CaptainComission.GoodsQty);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Gen"));
			AddQuestUserData("CaptainComission2", "sShoreType", XI_ConvertString(GetIslandByCityName(pchar.GenQuest.CaptainComission.ConvoyCity) + "Voc"));
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.ConvoyMoney);
			CaptainComission_GenerateCoastalPatrol();
			pchar.quest.CaptainComission_MapEnter.win_condition.l1 = "MapEnter";
			pchar.quest.CaptainComission_MapEnter.function = "CaptainComission_MapEnter";
			pchar.quest.CaptainComission_CapShip_Sink.win_condition.l1 = "Character_sink";
			pchar.quest.CaptainComission_CapShip_Sink.win_condition.l1.character = "CapComission_1";
			pchar.quest.CaptainComission_CapShip_Sink.function = "CaptainComission_CapShip_Sink";
			DialogExit();
		break;

		case "CaptainComission_325":
			NextDiag.TempNode = "CaptainComission_314";
			dialog.text = LinkRandPhrase("Capitaine, nous perdons du temps. On peut nous découvrir à tout moment.","Capitaine, le temps joue contre nous. N'oubliez pas qu'on me recherche.","Capitaine, tout retard est inacceptable. Mon navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name"))) + " se fait trop remarquer par les patrouilles.");
			link.l1 = LinkRandPhrase("Oui, vous avez raison, il faut se dépêcher...","Alors, montez dans les chaloupes sans discuter.","Voilà... Rassemblez vos hommes. Allons-y.");
			link.l1.go = "exit";
		break;

		case "CaptainComission_326_0":
			dialog.text = "Capitaine, je dois parler à mes hommes.";
			link.l1 = "Permission accordée.";
			link.l1.go = "exit";
			InterfaceStates.Buttons.Save.enable = false;
			AddDialogExitQuestFunction("CaptainComission_DialogInShore");
		break;

		case "CaptainComission_326":
			sld = characterFromId("Blaze");
			dialog.text = "Salutations, capitaine " + pchar.CaptainComission.Name + ". Alors, vous avez apporté toute la cargaison ? Et oם est le capitaine " + pchar.CaptainComission.CapName + " ?";
			link.l1 = pchar.CaptainComission.CapName + " est mort. J'ai dמ recourir aux services de"+ NPCharSexPhrase(sld, " ce gentilhomme"," cette dame") +". Permettez-moi de vous présenter : capitaine " + pchar.CaptainComission.FullName + ".";
			link.l1.go = "CaptainComission_327";
		break;

		case "CaptainComission_327":
			sld = characterFromId("Blaze");
			dialog.text = "Et "+ NPCharSexPhrase(sld, "qui est ce type ? Il","qui est-elle ? Elle") +" est au courant de nos affaires ?";
			link.l1 = "Dans les grandes lignes, oui. Mais il y a une nuance : "+ NPCharSexPhrase(sld, "il est persuadé","elle est persuadée") +" que la moitié de la cargaison "+ NPCharSexPhrase(sld, "lui","lui") +" revient. Il faudrait "+ NPCharSexPhrase(sld, "lui","lui") +" prouver le contraire.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainComission_GangDialog");
		break;

		case "CaptainComission_328":
			dialog.text = "Voyons, " + GetFullName(pchar) +", vous avez déjà entendu tout ce que vous deviez savoir. Il nous faut l'accès à votre cale.";
			link.l1 = "Vous croyez que mes gars vont regarder tranquillement de pauvres diables vider leur cale ?";
			link.l1.go = "CaptainComission_329";
		break;

		case "CaptainComission_329":
			pchar.GenQuest.CaptainComission.GoodsSum = 2 * sti(pchar.GenQuest.CaptainComission.GoodsQtyNorm) * sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Cost);
			dialog.text = "C'est vrai aussi. Une somme en espèces, disons " + pchar.GenQuest.CaptainComission.GoodsSum + " pièces d'or, nous éviterait d'avoir à nous battre avec votre équipage. Notez bien : c'est la valeur de la moitié de nos marchandises, tout est donc équitable... Acceptez, et personne ne sera blessé.";
			link.l1 = "Et si je refuse ?";
			link.l1.go = "CaptainComission_330";
		break;

		case "CaptainComission_330":
			dialog.text = "Alors, la violence est inévitable. Mais vous serez la première victime et trouverez le repos dans cette baie accueillante, et l'équipage de votre navire n'aura tout simplement pas le temps de venir à votre secours... Que pensez-vous de cette perspective ?";
			link.l1 = "Vous ne me laissez pas le choix. Je n'ai d'autre choix que de me battre.";
			link.l1.go = "CaptainComission_331";
			if(sti(pchar.money) >= sti(pchar.GenQuest.CaptainComission.GoodsSum))
			{
				link.l2 = "Je ne semble pas avoir le choix. Voici votre or.";
				link.l2.go = "CaptainComission_332";
			}
		break;

		case "CaptainComission_331":
			dialog.text = "Eh bien, voilà une décision digne "+ GetSexPhrase("d'un noble gentilhomme","d'une femme courageuse") +".";
			link.l1 = "Assez de philosophie ! Passons aux affaires !";
			link.l1.go = "CaptainComission_334";
			CaptainComission_ChangeCaptain();
		break;

		case "CaptainComission_332":
			dialog.text = "Une décision raisonnable. Bonne chance à vous.";
			link.l1 = "Que ça vous étouffe...";
			link.l1.go = "CaptainComission_333";
		break;

		case "CaptainComission_333":
			addMoneyToCharacter(pchar, -sti(pchar.GenQuest.CaptainComission.GoodsSum));
			AddQuestRecord("CaptainComission2", "17");
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sShoreName", UpperFirst(XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Gen")));
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsSum);
			CloseQuestHeader("CaptainComission2");
			ChangeOfficersLoyality("bad_all", 1);
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GangExit");
		break;

		case "CaptainComission_334":
			LAi_SetPlayerType(pchar);
			sTemp = "Gang_";
			sGroup = "GangGroup_0";
			LAi_LocationFightDisable(&locations[FindLocation(pchar.GenQuest.CaptainComission.ConvoyShore)], false);
			iTemp = sti(pchar.GenQuest.CaptainComission.GangNum);
			chrDisableReloadToLocation = true;
			rChar = CharacterFromID("CapComission_1");
			LAi_SetWarriorType(rChar);
			LAi_group_MoveCharacter(rChar, sGroup);
			for(i = 0; i < iTemp; i++)
			{
				rChar = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, sGroup);
				LAi_SetImmortal(rChar, false);
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "OpenTheDoors");
			LAi_group_SetCheckFunction(sGroup, "CaptainComission_GangDied");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CaptainComission_340":
			dialog.text = "Capitaine " + GetFullName(pchar) + ", nous arrivons trop tard. Je pense que vous comprenez qu'il ne peut être question de rémunération.";
			link.l1 = "Bien sמr que je comprends. J'ai déjà beaucoup gagné grâce à vous. Adieu...";
			link.l1.go = "CaptainComission_341";
		break;

		case "CaptainComission_341":
			Group_DeleteGroup("Sea_CapComission_1");
			LAi_SetImmortal(NPChar, true);
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			NPChar.lifeDay = 0;
			AddQuestRecord("CaptainComission2", "15");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name"))));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			CloseQuestHeader("CaptainComission2");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_Canoneer":
			dialog.text = "Offririez-vous un rhum à un vieux soldat qui a souffert dans de féroces batailles navales pour la gloire de la couronne ?";
			link.l1 = "Du rhum pour nous, aubergiste !..";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_Canoneer1";
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddDialogExitQuest("CaptainComission_TalkCanoneer");
		break;

		case "CaptainComission_Canoneer1":
			dialog.text = "Merci, " + GetAddress_Form(pchar) + ", de respecter un pauvre invalide qui a perdu la mémoire...";
			link.l1 = "Perdu, vraiment ?";
			link.l1.go = "CaptainComission_Canoneer2";
		break;

		case "CaptainComission_Canoneer2":
			dialog.text = "Complètement, m"+ GetSexPhrase("onsieur","adame") +" le capitaine, c'est le trou noir. Je ne me souviens de rien, juste d'un boulet ramé qui m'arrive droit sur la tête. Regardez le trou qu'il m'a fait dans le crâne. C'est sמrement par là que toute la mémoire s'est échappée.";
			link.l1 = "Mon vieux, garde tes histoires touchantes pour les ménagères crédules. J'ai vu des gens après un coup direct de mitraille : leur mémoire avait été emportée avec leur tête. Et toi, tu t'inventes carrément un boulet ramé... Parlons plutכt du capitaine " + pchar.GenQuest.CaptainComission.Name +".";
			link.l1.go = "CaptainComission_Canoneer3";
		break;

		case "CaptainComission_Canoneer3":
			dialog.text = "Oui, c'est bien moi, il faut bien gagner sa vie... Et le capitaine " + pchar.GenQuest.CaptainComission.Name + " – je n'en parle pas au premier venu. Si je prenais 100 pièces pour chaque question sur lui, j'aurais déjà plus d'or que le gouverneur n'en récolte dans toute la colonie en un an...";
			link.l1 = "Vous avez essayé de vendre la cargaison cachée par le capitaine ?";
			link.l1.go = "CaptainComission_Canoneer4";
		break;

		case "CaptainComission_Canoneer4":
			dialog.text = "Quoi, on a encore envoyé un limier ?! Je ne me souviens d'aucun capitaine " + pchar.GenQuest.CaptainComission.Name + " ! On vous l'a dit : je suis commotionné, et j'ai un certificat ! Qu'est-ce qu'il vous faut de plus ?!";
			link.l1 = "D'accord, d'accord, ne vous énervez pas. Le fait est que... Bref, j'arrive trop tard. Le capitaine " + pchar.GenQuest.CaptainComission.CapName + " m'a demandé de vous prévenir, pour que " + pchar.GenQuest.CaptainComission.Name + " n'aille pas dans cette colonie : les autorités ont appris les circonstances de la perte du navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen")) + " '" + pchar.GenQuest.CaptainComission.VictimShipName + "', et il sera arrêté.";
			link.l1.go = "CaptainComission_Canoneer5";
		break;

		case "CaptainComission_Canoneer5":
			dialog.text = "Ouf. Il fallait le dire tout de suite, au lieu de tourner autour du pot... C'est moi qui ai demandé au capitaine " + pchar.GenQuest.CaptainComission.CapName + " d'intercepter notre navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name"))) + " à son retour des cales de radoub de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City1 + "Gen") + ". " +
				"On l'y avait remorqué pour réparation après cette malheureuse bataille... D'oם sortait donc ce pirate avec son chargement de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Abl")) + " ?! Tant de gars y ont laissé leur tête à cause de lui, les uns au combat, les autres sur le billot.";
			link.l1 = "Comment avez-vous survécu ?";
			link.l1.go = "CaptainComission_Canoneer6";
		break;

		case "CaptainComission_Canoneer6":
			dialog.text = "Par erreur. C'est grâce à sa propre erreur qu'il a survécu : l'ironie du sort. La mèche de la sainte-barbe du navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen")) + " – je l'avais coupée trop court, si bien que la chaloupe n'a pas eu le temps de s'éloigner quand la poudre a explosé. Et il n'y a que moi que le souffle a projeté au loin, et un éclat de bastingage m'a même assommé... Les gars ne m'ont pas trouvé dans le noir, et je ne me souviens vraiment pas comment j'ai regagné le rivage.";
			link.l1 = "Comment vous en êtes-vous tiré à l'enquête ?";
			link.l1.go = "CaptainComission_Canoneer7";
		break;

		case "CaptainComission_Canoneer7":
			dialog.text = "J'ai dit que j'avais été commotionné pendant l'abordage, que je ne savais rien d'aucune cargaison. J'ai aussi fait l'imbécile, car je ne me suis remis sur pied que récemment, juste avant l'arrivée du navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + ". Avant ça, je ne pouvais pas bouger normalement, la commotion m'avait déréglé la coordination.";
			link.l1 = "Au fait, qui a vendu la mèche au sujet de la cargaison ?";
			link.l1.go = "CaptainComission_Canoneer8";
		break;

		case "CaptainComission_Canoneer8":
			dialog.text = "Les pirates ont envoyé une lettre au gouverneur, soi-disant de la part du marchand lésé. Ils ont décidé de se venger du capitaine pour son obstination. Après tout, sans son entêtement, le navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen")) + " n'aurait jamais été rattrapé... Et le capitaine serait encore en vie : une vraie tête de mule.";
			link.l1 = "Et comment êtes-vous tombés sur ce pirate ?";
			link.l1.go = "CaptainComission_Canoneer9";
		break;

		case "CaptainComission_Canoneer9":
			dialog.text = "Le diable seul le sait... Une patrouille ordinaire, un navire ordinaire battant pavillon de " + NationNameGenitive(sti(pchar.GenQuest.CaptainComission.Nation)) + ". Je ne sais pas pourquoi le capitaine a décidé de le surveiller, mais le navire n'a pas répondu au coup de semonce, et quand nous l'avons rattrapé, les pirates ont hissé le Jolly Roger. " +
				"Nous nous étions déjà bien éloignés du fort, ce n'était donc pas facile. Ensuite, il y a eu la mêlée de l'abordage... Je ne comprends toujours pas comment nous avons pris le dessus. " +
				"Eh bien, quand nous sommes descendus dans la cale et que nous l'avons vue pleine de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")) + ", c'est là que toute l'agitation a commencé. C'est le diable en personne qui a dמ nous donner ce butin... Il a fallu décharger la marchandise à terre, et le navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen")) + " a dמ sauter : il gîtait presque jusqu'au bastingage, et le gréement était très endommagé...";
			link.l1 = "Vous n'avez pas peur que tous vos efforts et sacrifices soient vains si les gens du gouverneur trouvent la cachette ?";
			link.l1.go = "CaptainComission_Canoneer10";
		break;

		case "CaptainComission_Canoneer10":
			iTmp = FindNonEnemyColonyForAdventure(sti(pchar.GenQuest.CaptainComission.Nation),pchar.GenQuest.CaptainComission.City, true);
			pchar.GenQuest.CaptainComission.CanoneerCity = Colonies[iTmp].id;
			pchar.GenQuest.CaptainComission.Sum = 20000 + 2000 * sti(pchar.rank);
			dialog.text = "Ils ne la trouveront pas. J'ai fait sauter l'entrée de la grotte, un moustique n'y passerait pas : je suis le meilleur artificier de toute l'escadre. Si quelqu'un la trouve, ce ne seront que les contrebandiers, ils connaissent chaque crevasse de l'île.. " +
				"וcoutez, je me demande depuis longtemps quoi faire de cette cargaison, surtout après l'exécution de l'équipage. Je ne peux ni la vendre seul, ni la sortir, d'autant que personne ne fera d'affaires sérieuses avec un commotionné... Je ne veux pas spéculer sur la mort de mes camarades, mais pour " + pchar.GenQuest.CaptainComission.Sum + " piastres, je suis prêt à vous montrer la cachette, à condition qu'après le chargement, vous m'emmeniez à " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.CanoneerCity) + ".";
			if(sti(pchar.money) >= sti(pchar.GenQuest.CaptainComission.Sum))
			{
				link.l1 = "J'accepte. Voici l'argent. Maintenant, c'est à vous de tenir parole.";
				link.l1.go = "CaptainComission_Canoneer11";
			}
			else
			{
				link.l1 = "Bon sang ! Restez ici, je vais chercher l'argent tout de suite.";
				link.l1.go = "CaptainComission_Canoneer12";
			}
			link.l2 = "Tu demandes trop, l'ami. Et je n'ai pas de navire adapté. Bonne chance à toi, et adieu...";
			link.l2.go = "CaptainComission_Canoneer13";
		break;

		case "CaptainComission_Canoneer11":
			addMoneyToCharacter(pchar, -sti(pchar.GenQuest.CaptainComission.Sum));
			pchar.GenQuest.CaptainComission.ConvoyShore = SelectQuestShoreLocationFromSea(GetArealByCityName(pchar.GenQuest.CaptainComission.City));
			pchar.GenQuest.CaptainComission.GoodsQty = makeint(sti(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Capacity")) / sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Weight));
			dialog.text = "Parfait. Retrouvez-moi cette nuit après minuit à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Voc") + ". Et assurez-vous d'avoir de la place dans votre cale pour " + pchar.GenQuest.CaptainComission.GoodsQty + " unités de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")) + ". Ce serait dommage de jeter ce qu'on a eu tant de mal à gagner...";
			link.l1 = "Je m'en occuperai sans faute. א bientכt dans la baie...";
			link.l1.go = "CaptainComission_Canoneer14";
		break;

		case "CaptainComission_Canoneer12":
			AddQuestRecord("CaptainComission2", "41");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.Sum);
			AddQuestUserData("CaptainComission2", "sName", GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_NOM));
			SetFunctionTimerCondition("CaptainComission_CanoneerWaitMoney", 0, 0, 1, false);
			NextDiag.TempNode = "CaptainComission_Canoneer15";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("CaptainComission_exit_sit");
		break;

		case "CaptainComission_Canoneer13":
			AddQuestRecord("CaptainComission2", "40");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sName", GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_NOM));
			AddQuestUserData("CaptainComission2", "sShipTypeQuest", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipNameQuest", pchar.GenQuest.CaptainComission.VictimShipName);
			CloseQuestHeader("CaptainComission2");
			LAi_CharacterDisableDialog(NPChar);
			pchar.GenQuest.CaptainComission = "close";
			SetFunctionExitFromLocationCondition("CaptainComission_ExitFromLoc", pchar.location, false);
			DialogExit();
			AddDialogExitQuest("CaptainComission_exit_sit");
		break;

		case "CaptainComission_Canoneer14":
			AddQuestRecord("CaptainComission2", "43");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sName", GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_NOM));
			AddQuestUserData("CaptainComission2", "sShipTypeQuest", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipNameQuest", pchar.GenQuest.CaptainComission.VictimShipName);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsQty);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Acc"));
			LAi_CharacterDisableDialog(NPChar);
			SetFunctionTimerConditionParam("CaptainComission_TimeIsOver", 0, 0, 1, MakeInt(24 - GetHour()), false);
			SetFunctionTimerCondition("CaptainComission_MeetCanoneerInShoreTimer", 0, 0, 1, false);
			DialogExit();
			AddDialogExitQuest("CaptainComission_exit_sit");
		break;

		case "CaptainComission_Canoneer15":
			if(sti(pchar.money) >= sti(pchar.GenQuest.CaptainComission.Sum))
			{
				dialog.text = "Vous voilà enfin. Je commençais à m'inquiéter. Je croyais que vous alliez me livrer aux autorités, avec armes et bagages.";
				link.l1 = "Je n'ai pas perdu la tête. Voici l'argent. Maintenant, c'est à vous de tenir parole.";
				link.l1.go = "CaptainComission_Canoneer11";
			}
			else
			{
				dialog.text = "Alors, oם est l'argent ?";
				link.l1 = "Bon sang ! Restez là, je vais le chercher tout de suite.";
				link.l1.go = "exit";
				NextDiag.TempNode = "CaptainComission_Canoneer15";
				NextDiag.CurrentNode = NextDiag.TempNode;
			}
		break;

		case "CaptainComission_350":
			dialog.text = "Capitaine, on dirait que nous arrivons trop tard. Les contrebandiers ont fini par trouver la cachette.";
			link.l1 = "Je n'ai pas l'intention de laisser filer la proie, même si le diable en personne venait la chercher.";
			link.l1.go = "CaptainComission_351";
			link.l2 = "Bon sang ! Je m'en lave les mains, débrouillez-vous avec vos concurrents.";
			link.l2.go = "CaptainComission_352";
		break;

		case "CaptainComission_351":
			DialogExit();
			AddDialogExitQuest("CaptainComission_GangDialog_1");
		break;

		case "CaptainComission_352":
			DialogExit();
			SetFunctionExitFromLocationCondition("CaptainComission_NoGangDialog", pchar.location, false);
		break;

		case "CaptainComission_360":
			dialog.text = "Capitaine, nous avons une affaire sérieuse ici : vous feriez mieux d'éloigner votre escadre jusqu'à ce que nos navires viennent charger.";
			link.l1 = "Messieurs, on dirait que vous essayez de prendre quelque chose qui ne vous appartient pas.";
			link.l1.go = "CaptainComission_361";
		break;

		case "CaptainComission_361":
			dialog.text = "דa alors ! א qui crois-tu parler, là ?";
			link.l1 = "א toi, mon cher. Les marchandises que vous comptez vous approprier ont un propriétaire, dont je représente actuellement les intérêts.";
			link.l1.go = "CaptainComission_362";
		break;

		case "CaptainComission_362":
			dialog.text = "Même si tu étais le messie du Seigneur Dieu en personne, nous ne te laisserons pas te mêler de nos affaires ! Dégage le chenal si tu tiens à la vie !";
			link.l1 = "Ce n'est pas clair pour vous que cette marchandise est à moi, et que je ne partirai pas sans elle ?";
			link.l1.go = "CaptainComission_363";
		break;

		case "CaptainComission_363":
			dialog.text = "Maudit sois-tu ! Alors tu resteras ici pour toujours !..";
			link.l1 = "Voyons qui restera ici !..";
			link.l1.go = "CaptainComission_364";
		break;

		case "CaptainComission_364":
			LAi_SetPlayerType(pchar);
			sTemp = "Gang_";
			sGroup = "GangGroup_0";
			LAi_LocationFightDisable(&locations[FindLocation(pchar.GenQuest.CaptainComission.ConvoyShore)], false);
			iTemp = sti(pchar.GenQuest.CaptainComission.GangNum);
			chrDisableReloadToLocation = true;
			if(pchar.GenQuest.CaptainComission.variant == "A2")
			{
				rChar = CharacterFromID("CapComission_1");
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, LAI_GROUP_PLAYER);
			}
			if(pchar.GenQuest.CaptainComission.variant == "A3")
			{
				rChar = CharacterFromID("CapComission_Canoneer");
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, LAI_GROUP_PLAYER);
			}
			for(i = 0; i < iTemp; i++)
			{
				rChar = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(rChar);
				LAi_group_MoveCharacter(rChar, sGroup);
				LAi_SetImmortal(rChar, false);
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "OpenTheDoors");
			if(pchar.GenQuest.CaptainComission.variant == "A2")
			{
				LAi_group_SetCheckFunction(sGroup, "CaptainComission_CheckCaptainAfterBattle");
			}
			if(pchar.GenQuest.CaptainComission.variant == "A3")
			{
				LAi_group_SetCheckFunction(sGroup, "CaptainComission_CheckGangAfterBattle");
			}
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CaptainComission_365":
			dialog.text = "Capitaine, donnez l'ordre de se dépêcher, une patrouille peut arriver d'un moment à l'autre. Et les contrebandiers attendaient clairement le transport pour charger.";
			link.l1 = "Bien sמr, dépêchons-nous... On charge vite la marchandise dans les cales et on file.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CaptainComission_365";
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "CaptainComission_366":
			dialog.text = "Merci, capitaine " + GetFullName(pchar) + ". Sans vous, les contrebandiers auraient eu notre cargaison, et il ne resterait même rien pour se souvenir des gars qui y ont laissé leur tête...";
			link.l1 = "Merci de m'avoir fait confiance.";
			link.l1.go = "CaptainComission_367";
		break;

		case "CaptainComission_367":
			dialog.text = "J'ai un petit objet qui m'a peut-être gardé en vie. Je veux vous l'offrir comme amulette. Tenez, et adieu.";
			link.l1 = "Merci pour le cadeau, je ne m'y attendais pas. Vous devriez soigner votre santé avant que l'argent ne s'épuise.";
			link.l1.go = "CaptainComission_368";
		break;

		case "CaptainComission_368":
			LAi_SetActorType(NPChar);
			LAi_SetImmortal(NPChar, true);
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			NPChar.LifeDay = 0;
			GiveItem2Character(pchar, pchar.GenQuest.CaptainComission.Prize);
			AddQuestRecord("CaptainComission2", "48");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			AddQuestUserData("CaptainComission2", "sCharName", GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_ABL));
			AddQuestUserData("CaptainComission2", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.CanoneerCity + "Gen"));
			CloseQuestHeader("CaptainComission2");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_370":
			if(pchar.GenQuest.CaptainComission == "MayorTalkBad")
			{
				pchar.quest.CaptainComission_TimeIsOver.over = "yes";
			}
			dialog.text = "On dirait que j'ai un rendez-vous aujourd'hui. C'est moi que vous venez voir ?";
			link.l1 = "Si vous êtes le capitaine " + pchar.GenQuest.CaptainComission.Name + ", alors oui.";
			link.l1.go = "CaptainComission_371";
		break;

		case "CaptainComission_371":
			dialog.text = "...ancien capitaine " + pchar.GenQuest.CaptainComission.Name + "...";
			link.l1 = "Je suis " + GetFullName(pchar) + ", j'ai deux ou trois questions.";
			link.l1.go = "CaptainComission_372";
		break;

		case "CaptainComission_372":
			dialog.text = "Et pourquoi croyez-vous que j'y répondrai ?";
			link.l1 = "Capitaine " + pchar.GenQuest.CaptainComission.CapName + " m'a demandé de vous prévenir au sujet du navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Acc")) + " '" + pchar.GenQuest.CaptainComission.VictimShipName + "'... Le gouverneur sait tout, " +
				"mais je n'ai pas pu vous intercepter à temps en mer, sur la route de " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City1 + "Gen") + ".";
			link.l1.go = "CaptainComission_373";
		break;

		case "CaptainComission_373":
			dialog.text = "Oם est le capitaine " + pchar.GenQuest.CaptainComission.CapName + " ?";
			link.l1 = "Il est mort.";
			link.l1.go = "CaptainComission_374";
		break;

		case "CaptainComission_374":
			dialog.text = "Ouais... Voilà donc de quoi il retourne. Bon, maintenant, bien des choses s'éclairent... Donc, quelqu'un a cafardé que nous avions vidé le navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen")) + ". " +
				"Tכt ou tard, on trouvera la cargaison, et alors on me pendra. Le capitaine " + pchar.GenQuest.CaptainComission.CapName + " est mort, il n'y a donc plus personne de qui attendre de l'aide... Sauf de vous... Capitaine " + GetFullName(pchar) + ", sortez-moi d'ici et je vous remercierai généreusement.";
			if(!CheckAttribute(pchar,"GenQuest.CaptainComission.GetRumour"))
			{
				if(CheckAttribute(pchar,"GenQuest.CaptainComission.SpeakMayor"))
				{
					link.l1 = "Le propriétaire de la cargaison a adressé un rapport au gouverneur. Il y a des chiffres impressionnants dedans.";
					link.l1.go = "CaptainComission_375";
				}
				else
				{
					link.l1 = "Mais vous ne pensez pas que je vais vous aider les yeux fermés, n'est-ce pas ?";
					link.l1.go = "CaptainComission_375";
				}
			}
			else
			{
				if(CheckAttribute(pchar,"GenQuest.CaptainComission.SpeakMayor"))
				{
					link.l1 = "Le propriétaire de la cargaison a adressé un rapport au gouverneur. Il y a des chiffres impressionnants dedans.";
					link.l1.go = "CaptainComission_375";
				}
				else
				{
					link.l1 = "Le bruit court dans la colonie que vous êtes lié aux contrebandiers...";
					link.l1.go = "CaptainComission_375";
				}
			}
		break;

		case "CaptainComission_375":
			sTemp = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Name") + "Gen"));
			dialog.text = "Je vois que je dois tout vous raconter dans l'ordre, pour que vous n'ayez aucun doute sur moi. " +
				"Lors d'une de nos patrouilles, je suis tombé sur un navire battant pavillon de " + NationNameGenitive(sti(pchar.GenQuest.CaptainComission.Nation)) + ". Il a ignoré l'ordre de mettre en panne. " +
				"Après une courte poursuite, nous avons rattrapé ce navire de type " + sTemp + " '" + pchar.GenQuest.CaptainComission.VictimShipName + "', et les fugitifs ont hissé le pavillon pirate. Comme nous étions déjà loin du fort, j'ai dמ livrer combat seul. Nous avions une brèche dans la cloison, nous n'avons donc pas pu éviter l'abordage. " +
				"Nous nous préparions déjà à mourir, mais grâce à la Sainte Vierge Marie et à un peloton de mousquetaires, nous avons réussi à tuer les pirates. Quelle n'a pas été notre joie en ouvrant la cale de ce navire de type " + sTemp + " : elle était remplie à ras bord de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Abl")) + ". " +
				"Nous avons décidé que c'était un signe de Dieu et une juste compensation pour nos blessures et la mort de nos camarades... Le crépuscule était déjà tombé. Nous avons amené le navire de type " + sTemp +" dans la baie la plus proche, nous avons débarqué le contenu de la cale et l'avons caché en lieu sמr, puis le navire de type " + sTemp + " a été remorqué au large et sabordé à l'explosif. Le lendemain matin, j'ai signalé à mon service le naufrage d'un navire pirate, sans dire un mot du contenu de la cale.";
			link.l1 = "Je pense que vous n'avez aucun intérêt à me tromper... Alors je vous propose un marché : vous me montrez la cachette, et je vous emmène oם vous voudrez dans l'archipel.";
			link.l1.go = "CaptainComission_376";
		break;

		case "CaptainComission_376":
			dialog.text = "Ha ha ha... Non, capitaine, je ne quitterai pas la colonie sans ma part, même si je dois finir au gibet.";
			link.l1 = "D'accord. Vous aurez votre moitié.";
			link.l1.go = "CaptainComission_377";
			link.l2 = "Hum... Je ne vais pas risquer ma tête pour votre bien-être. Adieu...";
			link.l2.go = "CaptainComission_378";
		break;

		case "CaptainComission_377":
			dialog.text = "Voilà qui est autre chose. Maintenant, je suis prêt à aller jusque dans la gueule du diable. Avant tout, vous devez m'abriter à bord de votre navire. Là, je vous indiquerai la baie oם se trouve la cachette.";
			link.l1 = "Alors, on agit vite et en douceur : j'ouvre la cellule, et vous me suivez. Restez près de moi et taisez-vous jusqu'à ce que nous soyons sortis du fort.";
			link.l1.go = "CaptainComission_379";
		break;

		case "CaptainComission_378":
			pchar.quest.CaptainComission_GetSecretTimeIsOut.over = "yes";
			sld = CharacterFromID("CapComission_1");
			sld.LifeDay = 0;
			ChangeCharacterReputation(pchar, -5);
			AddQuestRecord("CaptainComission2", "8");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			CloseQuestHeader("CaptainComission2");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_379":
			AddQuestRecord("CaptainComission2", "21");
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			pchar.quest.CaptainComission_PrisonFree_Death.win_condition.l1 = "NPC_Death";
			pchar.quest.CaptainComission_PrisonFree_Death.win_condition.l1.character = "CapComission_1";
			pchar.quest.CaptainComission_PrisonFree_Death.win_condition = "CaptainComission_PrisonFree_Death";
			GetCharacterPos(npchar, &locx, &locy, &locz);
			ChangeCharacterAddressGroup(npchar, npchar.location, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz));
			LAi_group_Register("CapComission_Prison");
			LAi_group_SetRelation("CapComission_Prison", LAI_GROUP_PLAYER, LAI_GROUP_FRIEND);
			LAi_group_SetAlarmReaction(LAI_GROUP_PLAYER, "CapComission_Prison", LAI_GROUP_ENEMY, LAI_GROUP_FRIEND);
			LAi_group_MoveCharacter(npchar, "CapComission_Prison");
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			LAi_CharacterDisableDialog(npchar);
			pchar.GenQuest.CaptainComission.PrisonFree = true;
			if(pchar.GenQuest.CaptainComission == "MayorTalkGood")
			{
				chrDisableReloadToLocation = true;
				sld = CharacterFromId(pchar.GenQuest.CaptainComission.City + "JailOff");
				sld.dialog.currentnode = "CapComission_PrisonFree1";
			}
			pchar.quest.CapComission_ExitFromPrison.win_condition.l1 = "ExitFromLocation";
            pchar.quest.CapComission_ExitFromPrison.win_condition.l1.location = pchar.location;
            pchar.quest.CapComission_ExitFromPrison.win_condition = "CaptainComission_ExitFromPrison";
			DialogExit();
		break;

		case "CaptainComission_380":
			pchar.quest.CaptainComission_GetSecretTimeIsOut.over = "yes";
			pchar.quest.CaptainComission_PrisonFree_Death.over = "yes";
			DeleteAttribute(pchar,"GenQuest.CaptainComission.canSpeakCaptain");
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PrisonFree");
			pchar.GenQuest.CaptainComission = "CanGetGoods";
			pchar.GenQuest.CaptainComission.ConvoyShore = SelectQuestShoreLocationFromSea(GetArealByCityName(pchar.GenQuest.CaptainComission.City));
			dialog.text = "Merci de m'avoir sauvé. Maintenant, il faut aller à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Acc") + ", et là, je vous indiquerai l'emplacement de la cachette. Il faut juste se dépêcher avant que les limiers ne la trouvent.";
			link.l1 = "Nous pourrons vraiment emporter toutes les marchandises ?";
			link.l1.go = "CaptainComission_381";
		break;

		case "CaptainComission_381":
			pchar.GenQuest.CaptainComission.GoodsQty = makeint(sti(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim),"Capacity")) / sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Weight));
			dialog.text = "Oui, vous avez raison, il faut s'assurer qu'il y a de la place dans vos cales pour " + pchar.GenQuest.CaptainComission.GoodsQty + " unités de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")) + ". Le butin s'est révélé conséquent, et ce serait dommage de perdre une cargaison qui a coמté tant de vies. Et on ne nous donnera pas une seconde chance de sortir la marchandise.";
			link.l1 = "Je m'en occuperai sans faute.";
			link.l1.go = "CaptainComission_382";
		break;

		case "CaptainComission_382":
			AddQuestRecord("CaptainComission2", "24");
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Voc"));
			AddQuestUserData("CaptainComission2", "sGoodsQuantity", pchar.GenQuest.CaptainComission.GoodsQty);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			SetFunctionLocationCondition("CaptainComission_MeetInShore", pchar.GenQuest.CaptainComission.ConvoyShore, false);
			SetFunctionTimerConditionParam("CaptainComission_CapEscapeTimer", 0, 0, 1, MakeInt(24 - GetHour()), false);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			chrDisableReloadToLocation = false; // Откроем выход
			DeleteAttribute(pchar,"TownEscape");
			QuestOpenSeaExit();
			DialogExit();
			AddDialogExitQuest("CanEnterToMap");
		break;

		case "CaptainComission_383":
			dialog.text = "Capitaine, nous n'avons pas besoin de témoins. Essayez de faire sortir ces gens de la baie.";
			link.l1 = "D'accord, on s'en occupe tout de suite...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainComission_GangDialogGetGoods");
		break;

		case "CaptainComission_384":
			dialog.text = "Capitaine, vous avez mal choisi l'endroit pour vos exercices. Ce mouillage est déjà occupé.";
			link.l1 = "Messieurs, je suis ici pour admirer les environs. J'ai une affaire ici.";
			link.l1.go = "CaptainComission_385";
		break;

		case "CaptainComission_385":
			dialog.text = "Nous non plus, on n'est pas là pour attraper des méduses : faites demi-tour avec votre escadre et filez sous le vent.";
			link.l1 = "Je n'ai ni le temps ni l'envie de vous convaincre. Soit vous partez et vivez heureux, soit vous restez ici, mais pour toujours.";
			link.l1.go = "CaptainComission_386";
		break;

		case "CaptainComission_386":
			dialog.text = "Je vois que vous ne comprenez pas les mots. Eh bien, tenez bon...";
			link.l1 = "Voilà qui est mieux...";
			link.l1.go = "CaptainComission_364";
		break;

		case "CaptainComission_387":
			LAi_LocationDisableOfficersGen(pchar.GenQuest.CaptainComission.ConvoyShore, false);
			pchar.GenQuest.CaptainComission.MaxGoodsQty = GetSquadronFreeSpace(pchar, sti(pchar.GenQuest.CaptainComission.Goods));
			if(sti(pchar.GenQuest.CaptainComission.MaxGoodsQty) > sti(pchar.GenQuest.CaptainComission.GoodsQty)) pchar.GenQuest.CaptainComission.MaxGoodsQty = pchar.GenQuest.CaptainComission.GoodsQty;
			dialog.text = "Nous y voilà. La cachette est dans la niche de ce rocher, là-bas. L'entrée est obstruée par des pierres. Dans la cachette : " + pchar.GenQuest.CaptainComission.GoodsQty +" unités de " + GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")) +". Vous n'avez pas oublié que la moitié est à moi ?";
			link.l1 = "Je n'ai pas oublié. Pendant que mes hommes chargent, voyons oם il faut vous livrer, vous et votre cargaison.";
			link.l1.go = "CaptainComission_388";
			link.l2 = "Parfait. Maintenant, dites-moi : quelle raison me pousserait à partager avec vous ?";
			link.l2.go = "CaptainComission_389";
			if(CheckAttribute(pchar,"GenQuest.CaptainComission.MayorTalkGood"))
			{
				link.l3 = "Capitaine " + pchar.GenQuest.CaptainComission.Name + ", je dois vous décevoir. Je travaille vraiment pour le gouverneur. Et j'ai l'intention de lui remettre toute la cargaison que vous avez cachée. Et vous, vous allez devoir retourner en prison attendre votre sort.";
				link.l3.go = "CaptainComission_389";
			}
		break;

		case "CaptainComission_388":
			iTmp = FindNonEnemyColonyForAdventure(sti(pchar.GenQuest.CaptainComission.Nation),pchar.GenQuest.CaptainComission.City, true);
			sTemp = Colonies[iTmp].id;
			pchar.GenQuest.CaptainComission.ConvoyIsland = GetArealByCityName(sTemp);
			pchar.GenQuest.CaptainComission.ConvoyShore = SelectQuestShoreLocationFromSea(pchar.GenQuest.CaptainComission.ConvoyIsland);
			pchar.GenQuest.CaptainComission.ConvoyCity = sTemp;
			pchar.GenQuest.CaptainComission.iDay  = 20 + cRand(10);
			iGoods = GetSquadronFreeSpace(pchar, sti(pchar.GenQuest.CaptainComission.Goods));
			if(iGoods < sti(pchar.GenQuest.CaptainComission.GoodsQty)) pchar.GenQuest.CaptainComission.GoodsQty = iGoods;
			AddCharacterGoods(pchar, sti(pchar.GenQuest.CaptainComission.Goods), sti(pchar.GenQuest.CaptainComission.GoodsQty));//меняю на распределение по эскадре
			dialog.text = "Je dois me rendre à " + XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Gen") + ", sur l'île de " + XI_ConvertString(GetIslandByCityName(sTemp) + "Voc") + " à " + pchar.GenQuest.CaptainComission.iDay + " jours d'ici. C'est là que mes gens devaient préparer le partage.";
			link.l1 = "D'accord. Il est temps de partir.";
			link.l1.go = "CaptainComission_391";
		break;

		case "CaptainComission_389":
			dialog.text = "Ouais... « Quoi que la vie nous apprenne, nos cœurs croient aux miracles... » Notez-le, sinon vous oublierez. Je ne m'attendais pas à un tel retournement, mais je suis toujours prêt au combat. Vous allez répondre de votre trahison.";
			link.l1 = "Je suis à votre service...";
			link.l1.go = "CaptainComission_390";
		break;

		case "CaptainComission_390":
			LAi_SetPlayerType(pchar);
			LAi_group_Delete("EnemyFight");
			chrDisableReloadToLocation = true;
			rChar = CharacterFromID("CapComission_1");
			LAi_SetWarriorType(rChar);
			LAi_group_MoveCharacter(rChar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			if(pchar.GenQuest.CaptainComission == "CapDuel")
			{
				LAi_group_SetCheckFunction("EnemyFight", "CaptainComission_CaptainDiedDuel");
			}
			else
			{
				LAi_group_SetCheckFunction("EnemyFight", "CaptainComission_CheckCaptainDied");
			}
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CaptainComission_391":
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			GetCharacterPos(NPChar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			pchar.GenQuest.CaptainComission.CapGoodsQty = sti(pchar.GenQuest.CaptainComission.GoodsQty)/2;
			if(sti(pchar.GenQuest.CaptainComission.CapGoodsQty) > sti(pchar.GenQuest.CaptainComission.MaxGoodsQty)) pchar.GenQuest.CaptainComission.CapGoodsQty = pchar.GenQuest.CaptainComission.MaxGoodsQty;
			AddQuestRecord("CaptainComission2", "26");
			AddQuestUserData("CaptainComission2", "sGoodsQuantity", pchar.GenQuest.CaptainComission.MaxGoodsQty);
			AddQuestUserData("CaptainComission2", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Name + "Gen")));
			AddQuestUserData("CaptainComission2", "sSum1", pchar.GenQuest.CaptainComission.CapGoodsQty);
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sDays", pchar.GenQuest.CaptainComission.iDay);
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Acc"))
			AddQuestUserData("CaptainComission2", "sShoreType", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyIsland + "Voc"));
			OfficersReaction("bad");
			if(CheckAttribute(pchar,"GenQuest.CaptainComission.MayorTalkGood"))
			{
				ChangeCharacterReputation(pchar, -5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -10);
			}
			CaptainComission_GenerateCoastalPatrol();
			pchar.GenQuest.CaptainComission = "GetGoodsEscape";
			SetFunctionLocationCondition("CaptainComission_CapMeetInShore", pchar.GenQuest.CaptainComission.ConvoyShore, false);
			SaveCurrentQuestDateParam("GenQuest.CaptainComission.DeleiveCapShore");
			DialogExit();
		break;

		case "CaptainComission_392":
			dialog.text = "On dirait que nous arrivons trop tard... Les acheteurs n'ont pas attendu, et je n'ai aucun moyen d'organiser seul le stockage et la vente des marchandises...";
			link.l1 = "Vous avez des suggestions précises à ce sujet ?";
			link.l1.go = "CaptainComission_393";
		break;

		case "CaptainComission_393":
			pchar.GenQuest.CaptainComission.GoodsPrice = makeint(sti(pchar.GenQuest.CaptainComission.CapGoodsQty) * 0.75 * sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Cost));
			dialog.text = "Capitaine " + GetFullName(pchar) + ", je suis un peu gêné de vous le proposer, mais pourriez-vous me donner ma part en or ? Je pense que " + pchar.GenQuest.CaptainComission.GoodsPrice + " pièces d'or seraient un compromis honorable.";
			if(sti(pchar.money) >= sti(pchar.GenQuest.CaptainComission.GoodsPrice))
			{
				link.l1 = "Oui, c'est un bon prix. Je veux bien. Prenez votre argent, et adieu.";
				link.l1.go = "CaptainComission_394";
			}
			link.l2 = "Euh, non, mon cher, ce n'était pas convenu. Je ne vais pas vous materner éternellement. Si vous ne voulez pas prendre la cargaison, je la garderai en toute bonne conscience. Je saurai organiser son stockage et sa vente.";
			link.l2.go = "CaptainComission_395";
		break;

		case "CaptainComission_394":
			addMoneyToCharacter(pchar, -sti(pchar.GenQuest.CaptainComission.GoodsPrice));
			dialog.text = "Attendez, capitaine. Je veux vous remercier de m'avoir sauvé. Je n'espérais plus rien... Voici un petit objet qui vous sera très utile dans bien des situations... Et maintenant, adieu.";
			link.l1 = "Merci. Je ne m'y attendais pas. Ce fut un plaisir de faire affaire avec vous.";
			link.l1.go = "CaptainComission_395";
		break;

		case "CaptainComission_395":
			dialog.text = "Je ne m'attendais pas à un tel retournement de votre part... On dirait que je n'ai pas d'autre choix que de vous proposer un duel.";
			link.l1 = "Je suis à votre service...";
			link.l1.go = "CaptainComission_390";
			pchar.GenQuest.CaptainComission = "CapDuel";
		break;

		case "CaptainComission_395":
			GiveItem2Character(pchar, pchar.GenQuest.CaptainComission.Prize);
			AddQuestRecord("CaptainComission2", "32");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Voc"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsPrice);
			CloseQuestHeader("CaptainComission2");
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			NPChar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_396_0":
			dialog.text = "Capitaine, je dois parler à mes hommes.";
			link.l1 = "Permission accordée.";
			link.l1.go = "exit";
			InterfaceStates.Buttons.Save.enable = false;
			AddDialogExitQuestFunction("CaptainComission_DialogInShore");
		break;

		case "CaptainComission_396":
			sld = characterFromId("Blaze");
			dialog.text = "Salutations, capitaine " + GetFullName(pchar) + ". Alors, vous avez apporté toute la cargaison ? Et oם est le capitaine " + pchar.CaptainComission.CapName + " ?";
			link.l1 =  pchar.CaptainComission.CapName + " est mort, et on m'a arrêté sur dénonciation. Bref, si le capitaine " + pchar.CaptainComission.FullName + " ne m'avait pas aidé, vous ne reverriez ni moi ni la marchandise.";
			link.l1.go = "CaptainComission_397";
		break;

		case "CaptainComission_397":
			sld = characterFromId("Blaze");
			dialog.text = "Et "+ NPCharSexPhrase(sld, "qui est ce type ? Il","qui est-elle ? Elle") +" est au courant de nos affaires ?";
			link.l1 = "Plus que ça. "+ NPCharSexPhrase(sld, "Il m'a sorti","Elle m'a sorti") +" de prison et a apporté ici la moitié de la cargaison ; je lui ai promis l'autre moitié pour sa peine.";
			link.l1.go = "CaptainComission_398";
		break;

		case "CaptainComission_398":
			sld = characterFromId("Blaze");
			dialog.text = "Ah non, capitaine, c'est votre problème ! Après tout, j'avais tout de suite proposé d'emmener le navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.CaptainComission.ShipTypeVictim),"Name"))) + " dans un endroit isolé, mais vous, vous vous accrochiez à votre carrière. Et voilà : vous avez attendu que votre cher gouverneur vous jette en prison. " +
				"Et votre part dans cette affaire était bien inférieure à la moitié, elle aurait donc été à votre disposition ! Et nous n'avons pas risqué nos têtes sous la mitraille pour qu' "+ NPCharSexPhrase(sld, "un quelconque type puisse","une quelconque fille puisse") +" empocher aussi facilement toute la moitié !";
			link.l1 = "וcoute, maître d'équipage, tu as oublié que le navire de type " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.CaptainComission.ShipTypeVictim),"Name") + "Acc")) + " avait le grand mât brisé ? Tu as aussi oublié la gîte jusqu'au bastingage ? Tu te rends seulement compte que si je n'avais pas donné la moitié "+ NPCharSexPhrase(sld, "à cette personne","à elle") +", tu aurais attendu la neige plutכt que la marchandise ?";
			link.l1.go = "CaptainComission_399";
		break;

		case "CaptainComission_399":
			dialog.text = "Tu parles bien, mais tu ne me tromperas pas ! Comment savoir que vous n'étiez pas de mèche ? Peut-être qu'il n'y a jamais eu d'arrestation ?! Peut-être que la cupidité vous a fait convoiter la marchandise des marins ? Ou tu crois qu'on a oublié comment manier nos lames ?!";
			link.l1 = "Je vois que tu as complètement perdu la tête : tu as sans doute déjà le tintement des piastres dans les oreilles.";
			link.l1.go = "CaptainComission_400";
		break;

		case "CaptainComission_400":
			sld = characterFromId("Blaze");
			dialog.text = "Frères ! Regardez comme notre capitaine chante ! Voilà ce que la cupidité fait des gens. Il a vendu notre part à "+ NPCharSexPhrase(sld, "un escroc","une aventurière") +" !!";
			link.l1 = "Ferme ta sale gueule ! Ou je te la ferme pour toujours !..";
			link.l1.go = "exit";
			AddDialogExitQuest("CaptainComission_ShoreGangDialog");
		break;

		case "CaptainComission_401":
			dialog.text = "Désolé, capitaine, que vous ayez dמ assister et prendre part à cette scène ridicule. On a du mal à croire qu'il y a à peine un mois, nous formions une équipe soudée oם chacun était prêt à donner sa vie pour un ami.";
			link.l1 = "J'avoue que même ma riche imagination ne parvient pas à se représenter ce tableau.";
			link.l1.go = "CaptainComission_402";
		break;

		case "CaptainComission_402":
			dialog.text = "Malheureusement, je n'ai plus aucun moyen d'organiser seul le stockage et la vente des marchandises...";
			link.l1 = "Vous avez des suggestions précises à ce sujet ?";
			link.l1.go = "CaptainComission_403";
		break;

		case "CaptainComission_403":
			pchar.GenQuest.CaptainComission.GoodsPrice = makeint(sti(pchar.GenQuest.CaptainComission.CapGoodsQty) * 0.75 * sti(Goods[sti(pchar.GenQuest.CaptainComission.Goods)].Cost));
			dialog.text = "Capitaine " + GetFullName(pchar) + ", je suis un peu gêné de vous le proposer, mais pourriez-vous me donner ma part en or ? Je pense que " + pchar.GenQuest.CaptainComission.GoodsPrice + " pièces d'or seraient un compromis honorable.";
			if(sti(pchar.money) >= sti(pchar.GenQuest.CaptainComission.GoodsPrice))
			{
				link.l1 = "Peut-être bien. Je veux bien. Prenez votre argent, et adieu.";
				link.l1.go = "CaptainComission_404";
			}
			link.l2 = "Non, cette perspective ne me convient pas. Vous pouvez prendre la cargaison ou la laisser dans la cale, mais je ne vous donnerai pas l'argent.";
			link.l2.go = "CaptainComission_405";
		break;

		case "CaptainComission_404":
			bTemp = false;
			if(drand(1) == 0)
			{
			    NPChar.reputation = 61 + rand(29);
				NPChar.alignment = "good";
			}
			else
			{
			    NPChar.reputation = 10 + rand(29);
				NPChar.alignment = "bad";
			}
			if (NPChar.alignment == "good" && sti(pchar.reputation) >= 50) bTemp = true;
			if (NPChar.alignment == "bad" && sti(pchar.reputation) <= 50) bTemp = true;

			addMoneyToCharacter(pchar, -sti(pchar.GenQuest.CaptainComission.GoodsPrice));

			if(!bTemp || FindFreeRandomOfficer() < 0)
			{
				dialog.text = "Attendez, je veux vous remercier de m'avoir sauvé. Je n'espérais plus rien... Voici un petit objet qui vous sera très utile dans bien des situations... Et maintenant, adieu.";
				link.l1 = "Merci. Je ne m'y attendais pas. Ce fut un plaisir de faire affaire avec vous.";
				link.l1.go = "CaptainComission_406";
			}
			else
			{
				dialog.text = "Attendez... Je me disais que ma carrière était de toute façon ruinée, qu'il ne me restait plus d'équipage, que j'étais un paria dans ma patrie. Et vous avez sans doute besoin de gens loyaux, qui savent tenir une lame et tenir leur langue. Prenez-moi dans votre équipage, vous ne le regretterez pas.";
				if(!CaptainComission_CheckAllPassengersHired())
				{
					link.l1 = "J'avoue, j'ai attendu longtemps que vous vous décidiez. Bien sמr que je vous prends. Je vous retrouve à bord.";
					link.l1.go = "CaptainComission_407";
				}
				link.l2 = "Hum... il me semble que vous êtes une personne trop intelligente pour servir sous les ordres d'un autre. Adieu...";
				link.l2.go = "CaptainComission_408";
			}
		break;

		case "CaptainComission_405":
			dialog.text = "Ouais, apparemment, ce n'est pas mon jour... Capitaine, tirons nos lames et finissons-en d'un coup...";
			link.l1 = "Je suis à votre service...";
			link.l1.go = "CaptainComission_390";
			pchar.GenQuest.CaptainComission = "CapDuel";
			pchar.GenQuest.CaptainComission.Duel = true;
		break;

		case "CaptainComission_406":
			GiveItem2Character(pchar, pchar.GenQuest.CaptainComission.Prize);
			AddQuestRecord("CaptainComission2", "34");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsPrice);
			CloseQuestHeader("CaptainComission2");
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			NPChar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CaptainComission_407":
			AddQuestRecord("CaptainComission2", "36");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsPrice);
			CloseQuestHeader("CaptainComission2");
			npchar.CaptainComission = true;
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			SetCharacterRemovable(Npchar, true);
			NPChar.Dialog.Filename = "Enc_Officer_dialog.c";
			NPChar.Dialog.CurrentNode = "hired";
            NPChar.greeting = "Gr_Officer";
			NPChar.quest.OfficerPrice = sti(pchar.rank)*500;
			DeleteAttribute(NPChar, "LifeDay");
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);

			DeleteAttribute(Npchar, "Ship");
			Npchar.Ship.Type = SHIP_NOTUSED;
            DeleteAttribute(Npchar, "Fellows"); // его офицеры
            Npchar.Fellows.Passengers.id0 = Npchar.index; // свой пассажир

			Npchar.Fellows.Passengers.boatswain = "-1";
			Npchar.Fellows.Passengers.navigator = "-1";
			Npchar.Fellows.Passengers.doctor = "-1";
			Npchar.Fellows.Passengers.cannoner = "-1";
			Npchar.Fellows.Passengers.treasurer = "-1";
			Npchar.Fellows.Passengers.carpenter = "-1";

			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "CaptainComission_408":
			AddQuestRecord("CaptainComission2", "35");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sSum", pchar.GenQuest.CaptainComission.GoodsPrice);
			CloseQuestHeader("CaptainComission2");
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 5.0);
			NPChar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;
		// Генератор "Operation Galleon"

		// Квест "meeting at the bay" -->
		// Офицер
		case "ContraMeetManQuest_Sold_1":
			dialog.text = "Ce ne sont pas vos affaires. Dites-moi tout de suite ce que vous fouinez par ici ! Vous ne chercheriez pas la personne que nous venons d'arrêter ?!";
				link.l1 = "Une personne ?! Non...";
				link.l1.go = "ContraMeetManQuest_Sold_2";
			break;

		case "ContraMeetManQuest_Sold_2":
			dialog.text = "Tant mieux... Pour vous... Sinon, vous iriez en prison avec lui. Maintenant, ne vous mettez pas en travers de notre chemin, marin. Et ne vous avisez plus de me distraire !...";
				link.l1 = "Oui, je ferais mieux d'y aller...";
				link.l1.go = "ContraMeetManQuest_Sold_3";
			break;

		case "ContraMeetManQuest_Sold_3":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			DeleteQuestCondition("ContraMeetManQuest_TimeIsLeft"); // Время больше не роляет
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "8");
			PChar.GenQuest.ContraMeetMan.ToTavernPatrolInShore = true;
			LAi_CharacterDisableDialog(NPChar);
			DeleteAttribute(&Locations[FindLocation(PChar.GenQuest.ContraMeetMan.ShoreID)], "DisableEncounters"); // Включаем случайки
			ContraMeetManQuest_DeletePatrolFromShore(); // По выходу потрём всех из локации
			break;

		// Сам чел
		case "ContraMeetManQuest_1":
			dialog.text = "Parfait ! Il faut aller immédiatement à la taverne des contrebandiers : je n'ai vraiment pas envie de m'attarder !";
				link.l1 = "Je ne vois pas de problème. Allons-y...";
				link.l1.go = "ContraMeetManQuest_2";
			break;

		case "ContraMeetManQuest_2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetActorType(NPChar);
			LAi_ActorFollowEverywhere(NPChar, "", -1);
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "3");
			AddQuestUserData(sQuestTitle, "sDestination", XI_ConvertString(PChar.GenQuest.ContraMeetMan.ShoreID + "Dat"));
			PChar.GenQuest.ContraMeetMan.ToTavernWithMan = true;
			DeleteAttribute(&Locations[FindLocation(PChar.GenQuest.ContraMeetMan.ShoreID)], "DisableEncounters"); // Включаем случайки
			break;

		// Контрики в комнате таверны
		case "ContraMeetManQuest_3":
			ContraMeetManQuest_ContersGoQut();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ContraMeetMan.Money));
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "4");
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(sti(PChar.GenQuest.ContraMeetMan.Money)));
			CloseQuestHeader(sQuestTitle);
			ChangeContrabandRelation(PChar, 5);
			DeleteAttribute(PChar, "GenQuest.ContraMeetMan");
			break;

		case "ContraMeetManQuest_4":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ContraMeetMan.Money));
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "5");
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(sti(PChar.GenQuest.ContraMeetMan.Money)));
			CloseQuestHeader(sQuestTitle);
			ContraMeetManQuest_ContraBeatMan();
			ChangeContrabandRelation(PChar, 5);
			ChangeCharacterReputation(PChar, -5);
			DeleteAttribute(PChar, "GenQuest.ContraMeetMan");
			break;

		case "ContraMeetManQuest_5":
			dialog.text = "Héhé... Toi aussi, "+ GetSexPhrase("le gars","la fille") +", on dirait que tu vas aller en enfer avec lui... Hé, l'ami, étripons-les !";
				link.l1 = "Sale porc ! Défends-toi !";
				link.l1.go = "ContraMeetManQuest_6";
			break;

		case "ContraMeetManQuest_6":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			ContraMeetManQuest_PlayerBeatContra();
			break;

		case "ContraMeetManQuest_7":
			dialog.text = "Merci encore, " + PChar.name + ". Adieu...";
				link.l1 = "...";
				link.l1.go = "ContraMeetManQuest_9";
			break;

		case "ContraMeetManQuest_8":
			iMoney = (rand(3)+2)*500;
			PChar.GenQuest.ContraMeetMan.Money = iMoney;
			dialog.text = "Une récompense ?! Ah oui, bien sמr... Tenez, prenez " + FindRussianMoneyString(iMoney) + " et adieu...";
				link.l1 = "א plus tard...";
				link.l1.go = "ContraMeetManQuest_10";
			break;

		case "ContraMeetManQuest_9":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			ChangeCharacterReputation(PChar, 10);
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "6");
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(iMoney));
			AddQuestUserData(sQuestTitle, "sDestination", XI_ConvertString(PChar.GenQuest.ContraMeetMan.ShoreID + "Dat"));
			CloseQuestHeader(sQuestTitle);
			ContraMeetManQuest_ContersGoQut();
			DeleteAttribute(PChar, "GenQuest.ContraMeetMan");
			break;

		case "ContraMeetManQuest_10":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ContraMeetMan.Money));
			sQuestTitle = PChar.GenQuest.ContraMeetMan.QuestTown + "ContraMeetManQuest";
			AddQuestRecordEx(sQuestTitle, "ContraMeetManQuest", "7");
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(sti(PChar.GenQuest.ContraMeetMan.Money)));
			AddQuestUserData(sQuestTitle, "sDestination", XI_ConvertString(PChar.GenQuest.ContraMeetMan.ShoreID + "Dat"));
			CloseQuestHeader(sQuestTitle);
			ContraMeetManQuest_ContersGoQut();
			DeleteAttribute(PChar, "GenQuest.ContraMeetMan");
			break;
		// <-- Квест "meeting at the bay"

		// Квест на доставку письма контрику -->
		case "ContraDeliverQuest_Sold1":
			dialog.text = "Héhé, et vous croyez qu'on va gober ces sornettes ?! Allez, les gars, emmenez-moi ces deux gibiers de potence !";
			//{
				link.l1 = "Officier, croyez-moi, vous commettez une terrible erreur en tentant d'arrêter des innocents. Croyez-moi, je ne connais pas du tout cet homme, et qui plus est, je ne veux pas le connaître."
				+ " Je pense que votre commandant sera très mécontent si vous arrêtez deux citoyens respectueux des lois...";
				link.l1.go = "ContraDeliverQuest_Sold2_Liberty";
			//}
			/*else // Тюрьма
			{
				link.l1 = "";
				link.l1.go = "ContraDeliverQuest_Sold2_Prison";
			}*/
			break;

		case "ContraDeliverQuest_Sold2_Liberty":
			dialog.text = "Hum, oui, vous avez sans doute raison. Le commandant sera très mécontent. Vous savez quoi, oublions simplement ce petit malentendu.";
				link.l1 = "Merci, officier, vous nous avez fait gagner du temps. Désormais, je vous prie d'être plus prudent : vous ne voudriez pas perdre ce grade si élevé d'officier, n'est-ce pas ?!";
				link.l1.go = "ContraDeliverQuest_Sold2_Liberty1";
			break;

		case "ContraDeliverQuest_Sold2_Liberty1":
			dialog.text = "Pas question, je ne veux pas ça. Maintenant, je vais vous demander de vous disperser. J'ai l'honneur...";
				link.l1 = "Voilà, il fallait commencer par là !";
				link.l1.go = "ContraDeliverQuest_Sold2_Liberty2";
			break;

		case "ContraDeliverQuest_Sold2_Liberty2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			ContraDeliverQuest_SoldiersGoOut();
			break;

		case "ContraDeliverQuest_1":
			iMoney = (rand(3)+2)*500;
			if(rand(1) == 0) // Денег не даёт
			{
				dialog.text = "Parfait. Maintenant, tu peux filer !";
					link.l1 = "Quoi ?! Et l'argent ? On s'était mis d'accord...";
					link.l1.go = "ContraDeliverQuest_NoMon";
			}
			else // Деньги или патруль
			{
				if(rand(2) == 1) // Патруль
				{
					dialog.text = "Merci pour la livraison. Maintenant, tu peux toujours essayer... Hum, quelqu'un arrive...";
						link.l1 = "Quoi ?!";
						link.l1.go = "ContraDeliverQuest_Patrol";
				}
				else // Просто отдаёт деньги
				{
					dialog.text = "Excellent. Merci pour la livraison. Tiens, prends " + FindRussianMoneyString(iMoney) ". Et souviens-toi : les contrebandiers n'oublient pas les gens bien...";
					link.l1 = "Je l'espère bien. Adieu.";
					link.l1.go = "ContraDeliverQuest_GoWithMoney";
					PChar.GenQuest.ContraDeliver.Money = iMoney;
				}
			}

			ChangeContrabandRelation(PChar, 5); // Письмо доставили - повышаем отношение у контриков
			ChangeCharacterReputation(PChar, -5); // Помогли контрикам - репу понижаем
			RemoveItems(PChar, "letter_1", 1);
			BackItemDescribe("letter_1");
			DeleteAttribute(&Items[FindItem("letter_1")], "City");
			rChar = &Characters[GetCharacterIndex(Locations[FindLocation(PChar.location)].townsack + "_Smuggler")];
			SaveCurrentNpcQuestDateParam(rChar, "work_date");
			break;

		case "ContraDeliverQuest_Patrol":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_LocationFightDisable(LoadedLocation, true); // Чтоб не поубивали кого-нить
			ContraDeliverQuest_GeneratePatrolToRoom();
			break;

		case "ContraDeliverQuest_NoMon":
			dialog.text = "וcoute, toi et moi, on ne s'est mis d'accord sur rien. C'est celui qui a négocié avec toi qui doit te donner l'argent.";
				link.l1 = "J'ai une mauvaise journée aujourd'hui, que dire de plus ?! Bon, adieu...";
				link.l1.go = "ContraDeliverQuest_GoWithoutMoney";
				link.l2 = RandSwear() + "Tu vas me le payer ! Prépare-toi à mourir !";
				link.l2.go = "ContraDeliverQuest_PrepareToFight";
			break;

		case "ContraDeliverQuest_GoWithoutMoney": // Уходим без денег
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			chrDisableReloadToLocation = false;
			bDisableFastReload         = false;
			PChar.GenQuest.ContraDeliver.Complete.WithoutMoney = true;
			sQuestTitle = PChar.GenQuest.ContraDeliver.QuestTown + "ContraDeliverQuest";
			AddQuestRecordEx(sQuestTitle, "ContraDeliverQuest", "4");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ContraDeliver.QuestTown));
			LAi_ActorGoToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", 3.0);
			break;

		case "ContraDeliverQuest_PrepareToFight":
			dialog.text = "Tu as osé me défier, "+ GetSexPhrase("blanc-bec","traînée") +" ? Eh bien, tant pis pour toi. Je vais t'ouvrir le ventre !";
				link.l1 = "...";
				link.l1.go = "ContraDeliverQuest_Fight";
			break;

		case "ContraDeliverQuest_Fight": // Бой
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetImmortal(NPChar, false);
			LAi_ActorAttack(NPChar, PChar, "");
			LAi_SetFightMode(PChar, true);
			SetFunctionNPCDeathCondition("ContraDeliverQuest_ContraIsDead", NPChar.ID, false);
			break;

		case "ContraDeliverQuest_GoWithMoney": // Уходим с деньгами
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ContraDeliver.Money));
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			chrDisableReloadToLocation = false;
			bDisableFastReload         = false;
			sQuestTitle = PChar.GenQuest.ContraDeliver.QuestTown + "ContraDeliverQuest";
			AddQuestRecordEx(sQuestTitle, "ContraDeliverQuest", "3");
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(sti(PChar.GenQuest.ContraDeliver.Money)));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ContraDeliver"); // Квест пройден - атрибуды потрём
			LAi_ActorGoToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", 3.0);
			break;
		// <-- Квест на доставку письма контрику

		// Церковеый генератор. Квест № 1. Диалог кэпа, которого ищем -->
		case "ChurchGenQuest_1_DeckDialog_1":
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithCap"))
			{
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.CapWaitOnTavern")) // Если ждёт в таверне
				{
					dialog.text = RandPhraseSimple("Cinq cents hommes ! Et un-hic ! Sur le coffre du mort !.. Hic !", "Bu-hic ! Le diable te mènera... hic ! jusqu'au bout.");
						link.l1 = "Euh... oui. Bonjour, monsieur " + GetFullName(NPChar) + ".";
						link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_2";
						PChar.Quest.Church_GenQuest1_Timer.over = "yes";
				}
				else // на палубе своего шипа
				{
					if(!CheckAttribute(PChar, "GenQuest.ChurchQuest_1.Complete"))
					{
						dialog.text = "Alors, qu'avons-nous là... Trois pièces de toile et des planches pour le bordé, encore des bittes à remplacer et des cordages pour les bras...";
							link.l1 = "Bonjour, monsieur " + GetFullName(NPChar) + ". Je me présente : capitaine " + PChar.name + ".";
							link.l1.go = "ChurchGenQuest1_DialogShip_1";
					}
					else
					{
						dialog.text = LinkRandPhrase("Descends de mon navire : j'ai assez à faire sans toi !", "Tu as eu les livres, qu'est-ce qu'il te faut de plus ?!", "J'ai fait ce que tu voulais, qu'est-ce que tu veux de plus, bon sang ?!");
							link.l1 = "Ne bous pas comme ça, tu vas faire une attaque !";
							link.l1.go = "exit";
					}
				}
			}
			else
			{
				dialog.text = RandPhraseSimple("Du rhum, du rhum ! Donnez-moi du rhum... hic !", "דa faisait longtemps... hic ! que je ne m'étais pas soמlé comme ça...");
					link.l1 = "Oui, la cale est déjà pleine, il ne serait pas temps de rentrer au port ?";
					link.l1.go = "exit";
			}
			NextDiag.TempNode = "ChurchGenQuest_1_DeckDialog_1";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_2":
			dialog.text = RandPhraseSimple("Assieds-toi, cap-hic-taine ! Qu'est-ce qu'on boit ?", "Venez à table, cap' ! Qu'est-ce que vous buvez ? Hic !");
					link.l1 = "Merci, mais je préférerais une conversation agréable avec une personne de bien.";
					link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_3";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_3":
			dialog.text = "Tu veux m'offenser-hic ? Il n'y a pas une seule personne agréable dans toute la taverne. Ce sont tous des bandits, de maudits voyous ! Tous des extorqueurs, et celui-là est le premier ! Le chef. Le chef, qu'une murène lui descende dans le gosier !";
				link.l1 = "En fait, je parlais de vous. Et je voulais bavarder avec vous. Et qui est le chef de ces bandits extorqueurs, et pourquoi est-ce qu'il...";
				link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_4";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_4":
			dialog.text = ""+ GetSexPhrase("Monsieur","Mademoiselle") +" ! Comment avez-vous dit que vous vous appeliez ? Je vous respecte ! Pas une âme ne m'avait jamais traité, moi, le vieux loup de mer, de personne agréable et aimable ! Oui, je suis pour vous !.. Oui, je suis pour vous !.. Oui, je suis tout à vous !.. Jusqu'au dernier peso !.. Oh, j'oubliais... Les piastres, c'est fini. Même les gouvernails sont épuisés. Ce salaud, l'extorqueur, vient de me prendre mon dernier gouvernail, que les diables de l'enfer chargent un mortier avec ses tripes !";
				link.l1 = "Capitaine... Faut-il appeler un médecin ? Vous n'allez pas bien, vous avez de la fièvre... Vous voyez déjà des gouvernails partout...";
				link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_5";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_5":
			dialog.text = "Le vieux Cap est peut-être ivre, mais il a toute sa tête. Les livres et les rouleaux, c'est le père " + PChar.GenQuest.ChurchQuest_1.ToName + " qui me les a confiés, je les apportais à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + ". Et puis, ce matin, je suis allé à l'église du coin, et j'ai parlé de ces papiers. Le padre d'ici voulait vraiment y jeter ne serait-ce qu'un œil. Vous savez bien, ces frères-là, ne leur donnez pas de pain, mais laissez-les lire sur leurs saints et leurs justes. Bref, j'ai envoyé un mousse au navire pour qu'il rapporte mon coffre avec ces richesses. En attendant, j'ai réussi à perdre à plate couture, ils m'ont dépouillé jusqu'à l'os, et même les boissons restaient impayées. L'aubergiste a tout de suite compris, il a pris les livres en gage, et puis je lui ai donné les rouleaux...";
				link.l1 = "Autrement dit, vous avez bu les manuscrits et les rouleaux confiés par le prêtre de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Gen") + " ?";
				link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_6";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_6":
			dialog.text = "Je sais que je vais brמler en enfer, car maintenant, je ne peux plus me montrer ni devant le padre qui m'a confié la mission, ni devant celui à qui je portais ces papiers, ni devant celui d'ici... Qui priera pour mon âme ? Ou peut-être qu'on va m'excommunier ? Oh, malheur à moi... J'aurais bien bu un coup...";
				link.l1 = "Allons, allons, ne vous mettez pas dans un tel état. Vous avez agi de façon abominable et impie, mais je suis prêt à vous aider. Je vais payer votre dette à l'aubergiste et racheter ces gouvernails... ces manuscrits. D'autant que je connais les deux prêtres en question et que je fais route tout droit vers " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + ", je livrerai ces ouvrages à bon port. Vous êtes d'accord ?";
				link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_7";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_7":
			dialog.text = "Sauveur ! Un ange de Dieu... Oui, je ne suis pas d'accord. Je suis d'accord !.. Je donne tout, des deux mains, je donne tout... juste encore un petit verre...";
				link.l1 = "Vous avez assez bu... Bon, d'accord. Je vais parler à l'aubergiste et vous commander du rhum.";
				link.l1.go = "ChurchGenQuest1_DialogInTavernWithCap_8";
			break;

		case "ChurchGenQuest1_DialogInTavernWithCap_8":
			DialogExit();
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithCap");
			PChar.GenQuest.ChurchQuest_1.NeedToDialogWithBarmen = true;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "7_2");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown));
			AddQuestUserData(sQuestTitle, "sCapName", GetFullName(NPChar));
			NextDiag.CurrentNode = "ChurchGenQuest_1_DeckDialog_1";
			break;

		case "ChurchGenQuest1_DialogShip_1":
			dialog.text = "...et les écoutes ! il faut changer les écoutes !.. Oh, oui, bonjour et tout ça. Ne le prenez pas mal, qui que vous soyez, mais je suis très occupé en ce moment, et j'aimerais qu'on m'explique au plus vite l'objet de la broutille qui vous amène à bord de mon navire.";
				link.l1 = "Hum. En fait, l'affaire est vraiment insignifiante. א ce que je sais, à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Dat") + " le père " + PChar.GenQuest.ChurchQuest_1.ToName + " vous a remis des ouvrages théologiques que vous vous êtes engagé à livrer à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + ", puisque vous alliez par là.";
				link.l1.go = "ChurchGenQuest1_DialogShip_2";
			break;

		case "ChurchGenQuest1_DialogShip_2":
			dialog.text = "J'y allais, oui ! Mais cette maudite tempête a bien failli tuer mon vieux rafiot, et maintenant, je suis coincé ici pour Dieu sait combien de temps ! Parce que ces escrocs des docks essaient de rapiécer la coque avec des planches pourries de vieux baquets que la tempête a rejetés sur le rivage, et au lieu de voiles, ils tendent une vieille toile de sac sur laquelle leur arrière-grand-mère a rendu l'âme.";
				link.l1 = "Euh... Monsieur, une autre fois, j'écouterai volontiers votre avis sur l'arrière-grand-mère des dockers du coin, mais pour l'instant, j'aimerais connaître le sort des livres et manuscrits que vous avez reçus à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Dat") + ".";
				link.l1.go = "ChurchGenQuest1_DialogShip_3";
			break;

		case "ChurchGenQuest1_DialogShip_3":
			dialog.text = "Personne, personne, vous entendez ?! Personne ne peut m'accuser d'être en retard pour la livraison de ces maudits papiers !";
				link.l1 = "Dieu m'en garde, qui oserait ?! Je veux juste vous épargner des soucis inutiles. Le fait est que le père " + PChar.GenQuest.ChurchQuest_1.ToName + "tient beaucoup à ce que les livres et manuscrits soient livrés à destination au plus vite, et il se trouve que je vais tout droit à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + "...";
				link.l1.go = "ChurchGenQuest1_DialogShip_4";
			break;

		case "ChurchGenQuest1_DialogShip_4":
		if(rand(3) != 1)
		{
			dialog.text = "Il me semble, "+ GetSexPhrase("monsieur","mademoiselle") +", que dans chaque port, un autre directeur de conscience vous absout de vos péchés. Mais ça ne me regarde pas. Si vous et tous vos directeurs de conscience êtes si mal à l'aise, prenez vos livres et disparaissez. Bon vent !";
				link.l1 = "Merci, capitaine, et bonne réparation.";
				link.l1.go = "ChurchGenQuest1_DialogShip_5_1";
		}
		else // Свитки не отдаёт
		{
			dialog.text = "וpargnez-vous plutכt les soucis inutiles, "+ GetSexPhrase("monsieur","mademoiselle") +", et allez donc à " +  XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + ", car je me suis engagé à livrer ces papiers et je les livrerai, quoi qu'il m'en coמte : il n'est pas encore né, le gredin qui osera prétendre que le capitaine " + npchar.name + " ne tient pas parole !";
				link.l1 = "Mais, capitaine, il ne s'agit pas de ça...";
				link.l1.go = "ChurchGenQuest1_DialogShip_5_2";
		}
			break;

		case "ChurchGenQuest1_DialogShip_5_1":
			DialogExit();
			AddItems(PChar, "Bible", 1);	// Даём рукописи
			items[FindItem("Bible")].Name = "itmname_ChurchGenQuest1Bible";	// Меняем имя. Потом поменять обратно!
			ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest1Bible"); // Меняем дескрайб. Потом поменять обратно!
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"); // Переменная. Потом удалить!
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "10");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown));
			AddQuestUserData(sQuestTitle, "sCapName", GetFullName(NPChar));
			PChar.GenQuest.ChurchQuest_1.Complete = true; // Квест выполнен
			SetFunctionTimerCondition("Church_GenQuest1_DeleteCapitan", 0, 0, 1, false); // Трём судно кэпа
			break;

		case "ChurchGenQuest1_DialogShip_5_2":
			dialog.text = "Le fait est que je n'ai en réalité aucune affaire avec vous. J'ai une mission du Saint-Père : porter les livres à " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown) + " et les remettre au padre de là-bas. Et vous, dans tout ça ? Vous n'y êtes pour rien. Bonne journée.";
				link.l2 = "J'ai été patient assez longtemps, mais cet entêtement d'âne et cette arrogance mettraient en rage même un ange, alors moi, pauvre pécheur... Je dois exécuter les instructions de mon confesseur, et si vous ne voulez pas rendre de bon gré ce qui ne vous appartient pas, je vais devoir tirer mon arme !";
				link.l2.go = "ChurchGenQuest1_DialogShip_5_2_2"; //
			break;

		case "ChurchGenQuest1_DialogShip_5_2_1":
			DialogExit();
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "11");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown));
			AddQuestUserData(sQuestTitle, "sCapName", GetFullName(NPChar));
			PChar.GenQuest.ChurchQuest_1.Complete.NoManuscripts = true; // Квест выполнен без манускриптов
			SetFunctionTimerCondition("Church_GenQuest1_DeleteCapitan", 0, 0, 1, false); // Трём судно кэпа
			break;

		case "ChurchGenQuest1_DialogShip_5_2_2":
			dialog.text = "Doucement, doucement, capitaine " + PChar.name + " ! Je vous ai bien compris. Il semble que ce soit vrai : si vous ne rapportez pas les papiers, vous allez vous faire sermonner par tous vos Pères spirituels, et le Père céleste en rajoutera. Prenez vos joyaux théologiques et allez avec Dieu.";
				link.l1 = "Je me réjouis que vous ayez non seulement compris ma position, mais aussi retenu mon nom. Je vous conseille de le répéter trois fois chaque fois que votre mauvais caractère risquera de nuire à votre santé.";
				link.l1.go = "ChurchGenQuest1_DialogShip_5_2_3"; // Сваливаем, поверили ему
			break;

		case "ChurchGenQuest1_DialogShip_5_2_3":
			DialogExit();
			AddItems(PChar, "Bible", 1);	// Даём рукописи
			items[FindItem("Bible")].Name = "itmname_ChurchGenQuest1Bible";	// Меняем имя. Потом поменять обратно!
			ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest1Bible"); // Меняем дескрайб. Потом поменять обратно!
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"); // Переменная. Потом удалить!
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "10");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Dat"));
			AddQuestUserData(sQuestTitle, "sCapName", GetFullName(NPChar));
			PChar.GenQuest.ChurchQuest_1.Complete = true; // Квест выполнен
			SetFunctionTimerCondition("Church_GenQuest1_DeleteCapitan", 0, 0, 1, false); // Трём судно кэпа
			break;

		// <-- Церковеый генератор. Квест № 1. Диалог кэпа, которого ищем

		case "Left_Time_Case":
			dialog.text = RandPhraseSimple("Fichez le camp d'ici...", "Ne me dérangez pas !");
				link.l1 = "...";
				link.l1.go = "exit";
				NextDiag.TempNode = "Left_Time_Case";
			break;

		case "Church_GenQuest_2_1":
			if(sti(PChar.GenQuest.ChurchQuest_2.BanditsCount) == 1)
			{
				dialog.text = RandSwear() + "Tu n'aurais pas dמ dire ça... Maintenant, je vais devoir t'envoyer auprès du Seigneur pour expier mes péchés !";
			}

			if(sti(PChar.GenQuest.ChurchQuest_2.BanditsCount) == 2)
			{
				dialog.text = RandSwear() + "Tu n'aurais pas dמ dire ça... Maintenant, il va falloir t'envoyer auprès du Seigneur pour expier nos péchés !";
			}

			if(sti(PChar.GenQuest.ChurchQuest_2.BanditsCount) > 2)
			{
				dialog.text = RandSwear() + "Tu n'aurais pas dמ dire ça... Maintenant, il va falloir t'envoyer auprès du Seigneur, pour expier nos péchés devant Lui !";
			}

				link.l1 = "Pas question, l'ami. Devant le Seigneur, chacun répondra de lui-même !";
				link.l1.go = "exit";
				NPChar.money = sti(PChar.GenQuest.ChurchQuest_2.MoneyCount);
				LAi_LocationFightDisable(LoadedLocation, false);
				AddDialogExitQuest("Church_GenQuest2_BanditsIsEnemies");
			break;

		case "Church_GenQuest_2_ShoreBandit_1":
			dialog.text = "Ne jure pas pour rien, j'ai peut-être une affaire pour toi.";
				link.l1 = "En voilà une nouvelle ! Avec les gens comme toi, je ne fais pas de longs discours.";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_2";
				LAi_LocationFightDisable(LoadedLocation, false);
			break;

		case "Church_GenQuest_2_ShoreBandit_2":
			dialog.text = "Et moi, je ne vais pas faire de longs discours avec toi. Je voulais te proposer : tu ne voudrais pas acheter deux ou trois babioles ? On les cède pour pas cher...";
				link.l1 = "Tu trouves que j'ai l'air de quelqu'un qui achète de la marchandise volée ?!!";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_3";
			break;

		case "Church_GenQuest_2_ShoreBandit_3":
			if(rand(1) == 0)
			{
				dialog.text = "Doucement, mon cher. Il n'y a pas de voleurs parmi nous ! Ce vase, on l'a eu par un travail honnête. Regarde, c'est de l'or pur, et il est orné de perles. Mais nous, on n'en a pas besoin. On veut le vendre et partager l'argent honnêtement.";
					link.l1 = "Voyons ça de plus près... Bah ! Mais c'est un calice de communion !!! Alors c'est vous, les impies qui ont pillé l'église de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_2.QuestTown + "Gen") + " ?! Je vous ai donc retrouvés !";
					link.l1.go = "Church_GenQuest_2_ShoreBandit_4";
					break;
			}

			dialog.text = "Doucement, hypocrite ! On a eu un peu de mal pendant le voyage, et on a décidé de vendre quelque chose. Tiens, regarde ce vase : de l'or pur, orné de perles. On le cédera pour pas cher à une bonne personne... Disons pour mille pièces.";
				link.l1 = "Voyons ça de plus près... Bah ! Mais c'est un calice de communion !!! Alors c'est vous, les impies qui ont pillé l'église de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_2.QuestTown + "Gen") + " ?! Je vous ai donc retrouvés !";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_1";
			break;

		case "Church_GenQuest_2_ShoreBandit_4":
			dialog.text = "Hé, doucement dans les virages, "+ GetSexPhrase("monsieur","mademoiselle") +" !.. Bon sang, j'avais dit à ce lourdaud de ne pas s'agiter trop tכt...";
				link.l1 = "Qu'est-ce que tu marmonnes ?! Choisis : soit tu rends de bon gré la marchandise volée, soit j'appelle la garde.";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_5";
			break;

		case "Church_GenQuest_2_ShoreBandit_5":
			dialog.text = "וcoutez, "+ GetSexPhrase("brave homme","ma belle") +", inutile de se quereller... Réglons ça en douce. Il va falloir nous croire : nous n'avons pas pillé l'église, et nous n'avons pas d'argent. Oui, nous avons reçu quelques piastres et une pièce d'or pour mettre en scène un cambriolage. Ce maudit calice est la seule chose qui nous reste après avoir payé les contrebandiers...";
				link.l1 = "Et vous voulez dire que...";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_6";
			break;

		case "Church_GenQuest_2_ShoreBandit_6":
			dialog.text = "C'est ce maudit prêtre qui nous a engagés lui-même ! Mais pourquoi fallait-il organiser une poursuite ?! Enfin, maintenant on est quittes... Prenez le vase et montrez-le au saint homme, vous verrez vous-même comme il se tortillera comme un calmar sur un haut-fond !..";
				link.l1 = "Donnez-moi le calice et filez avant que je change d'avis.";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_7";
				link.l2 = "Bien chanté. Mais je ne suis pas si crédule. Si vous voulez me convaincre, convainquez d'abord ma lame.";
				link.l2.go = "Church_GenQuest_2_ShoreBandit_8";
				// Тут давать чашу, если будет
				ChurchGenQuest2_GiveCup();
				PChar.GenQuest.ChurchQuest_2.Complete.PriestIsThief = true;
			break;

		case "Church_GenQuest_2_ShoreBandit_7":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			iBanditsCount = PChar.GenQuest.ChurchQuest_2.BanditsCount;
			for(i=0; i<iBanditsCount; i++)
			{
				rChar = CharacterFromID("Church_GenQuest2_Bandit_" + i);
				LAi_Type_Actor_Reset(rChar);
				LAi_CharacterDisableDialog(rChar);
				rChar.LifeDay = 0;
				LAi_ActorRunToLocation(rChar, "reload", "reload1_back", "none", "", "", "", -1);
			}

			// Разрешим генерацию энкаунтеров, откроем выходы
			DeleteAttribute(LoadedLocation, "DisableEncounters");
			chrDisableReloadToLocation = false;

			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestrecordEx(sQuestTitle, "ChurchGenQuest2", "10_1");
			AddQuestUserData(sQuestTitle, "sName", PChar.GenQuest.ChurchQuest_2.QuestTown.PriestName);
			break;

		case "Church_GenQuest_2_ShoreBandit_8":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddDialogExitQuest("Church_GenQuest2_BanditsIsEnemies");
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestrecordEx(sQuestTitle, "ChurchGenQuest2", "10_2");
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_1":
			if(PChar.GenQuest.ChurchQuest_2.BanditsCount == 1)
			{
				dialog.text = RandSwear() + "Je l'avais dit à ces cormorans : retenez vos pattes crochues, ne prenez rien au prêtre à part l'argent !";
			}
			else
			{
				dialog.text = RandSwear() + "Je vous l'avais dit, cormorans insatiables : retenez vos pattes crochues, ne prenez rien au prêtre à part l'argent !";
			}

					link.l1 = "Qu'est-ce que tu marmonnes ?! Choisis : soit tu me rends de bon gré la marchandise volée, soit j'appelle la garde.";
					link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2";
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2":
			dialog.text = "Moi, je choisis autre chose : tu fermes ta bouche bavarde et tu me donnes le contenu de ta bourse, et moi, je te laisse la vie.";
				link.l1 = "Maintenant, je vais t'accorder une audience auprès de Dieu !";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_1";
				link.l2 = "Soit, je vais te donner de l'argent, mais seulement pour de nobles raisons. Pour que toi et tes compères puissiez commencer une vie honnête. Et ne plus vous abaisser à piller une église.";
				link.l2.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_2";
				link.l3 = "Euh... Oublions nos différends et revenons au début de la conversation. Alors, combien voulais-tu pour cet objet ?";
				link.l3.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_3";
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_1":
			// Не забыть чашу!
			ChurchGenQuest2_GiveCup();
			PChar.GenQuest.ChurchQuest_2.Complete.With_All = true;
			NPChar.money = ((rand(3) + 6) * 1000);
			PChar.GenQuest.ChurchQuest_2.MoneyCount = NPChar.money;
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddDialogExitQuest("Church_GenQuest2_BanditsIsEnemies");
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestrecordEx(sQuestTitle, "ChurchGenQuest2", "11_1");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sSex1", GetSexPhrase("", "e"));
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_2":
			AddMoneyToCharacter(PChar, -sti(PChar.money)/2); // Забираем половину денег
			PChar.GenQuest.ChurchQuest_2.Complete.Without_All = true; // Полностью проигрышный вариант. Остаёмся ни с чем
			iBanditsCount = PChar.GenQuest.ChurchQuest_2.BanditsCount;
			for(i=0; i<iBanditsCount; i++)
			{
				rChar = CharacterFromID("Church_GenQuest2_Bandit_" + i);
				LAi_SetCitizenType(rChar);
				rChar.LifeDay = 0;
				rChar.Dialog.Currentnode = "First time";
			}

			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.BanditsInShore");
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "11_2");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sSex1", GetSexPhrase("", "e"));
			DeleteAttribute(LoadedLocation, "DisableEncounters");
			chrDisableReloadToLocation = false;
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_3":
			iMoney = makeint(makeint(Pchar.money)/20)*10;
			dialog.text = "Je ne veux pas non plus de problèmes inutiles, " + GetAddress_Form(pchar) + ", mais maintenant, les prix ont augmenté. Pour ce vase inestimable, je prendrai tout ce que tu as.";
			if(iMoney >= makeint(Pchar.rank)*300)
			{
				link.l1 = "Espèce de racaille cupide !.. Je n'ai que " + FindRussianMoneyString(iMoney) + " sur moi. Prends-les et disparais !";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_1";
			}
			else
			{
				link.l1 = "Et c'est là que tu t'es trompé, sale rat cupide : tu ne profiteras pas de moi !"+ GetSexPhrase(" Je suis libre comme le vent : aujourd'hui ici, demain là-bas, aujourd'hui pauvre, demain riche...","") +"";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_2";
			}
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChurchGenQuest2_GiveCup();	// Даём чашу
			AddMoneyToCharacter(PChar, -(makeint(makeint(Pchar.money)/20)*10));
			PChar.GenQuest.ChurchQuest_2.Complete.Only_With_Cup = true;
			iBanditsCount = PChar.GenQuest.ChurchQuest_2.BanditsCount;
			for(i=0; i<iBanditsCount; i++)
			{
				rChar = CharacterFromID("Church_GenQuest2_Bandit_" + i);
				LAi_SetCitizenType(rChar);
				rChar.LifeDay = 0;
				rChar.Dialog.Currentnode = "Left_Time_Case"; // Диалог не забыть поменять.
			}

			DeleteAttribute(LoadedLocation, "DisableEncounters");
			chrDisableReloadToLocation = false;
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestrecordEx(sQuestTitle, "ChurchGenQuest2", "11_3");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.BanditsInShore");
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_2":
			dialog.text = "Tu veux vraiment dire que c'est justement aujourd'hui que "+ GetSexPhrase("tu es pauvre","tu n'as pas d'argent") +" ?!";
				link.l1 = "Oh oui, mon pauvre ami cupide ! א ta grande déception. Et maintenant, permets-moi de prendre congé, de grandes choses m'attendent.";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_3";
			break;

		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_3":
			dialog.text = "Halte ! On va vérifier, et si tu as menti, je fourrerai ta langue menteuse dans une fourmilière !";
				link.l1 = "Tu ne vivras pas après de telles paroles !";
				link.l1.go = "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_4";
			break;

		// Можно этот кэйс - Church_GenQuest_2_ShoreBandit_Real_Band_2_1
		case "Church_GenQuest_2_ShoreBandit_Real_Band_2_3_4":
				// ГГ как-бы может обыскать трупики и забрать все барахло...
				PChar.GenQuest.ChurchQuest_2.Complete.With_All = true;
				NPChar.money = ((rand(3) + 6) * 1000);
				PChar.GenQuest.ChurchQuest_2.MoneyCount = NPChar.money;
				DialogExit();
				NextDiag.CurrentNode = NextDiag.TempNode;
				AddDialogExitQuest("Church_GenQuest2_BanditsIsEnemies");
				sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
				AddQuestrecordEx(sQuestTitle, "ChurchGenQuest2", "11_4");
				AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
		break;

		case "Greedy":
			dialog.text = "Oh, vous avez trouvé notre pierre précieuse ? Rendez-la-nous, s'il vous plaît. דa ne vous fera pas de mal, et nous, ça nous aidera à tenir nos culottes.";
			link.l1 = "C'est ça, tout de suite. Je ne l'ai pas cherchée pour la donner à des va-nu-pieds comme vous.";
			link.l1.go = "Greedy_no";
			link.l2 = "Qu'est-ce que je vais dire à l'usurier ? Je me suis engagé à retrouver la pierre.";
			link.l2.go = "Greedy_3";
		break;

		case "Greedy_no":
			dialog.text = "Vous êtes en colère. Et moi, j'ai tué des léopards autrefois... Il faudrait que je vous apprenne les bonnes manières. Défendez-vous !";
			link.l1 = "Et pourquoi faut-il que tout finisse en bagarre...";
			link.l1.go = "Greedy_end";
		break;

		case "Greedy_3":
			dialog.text = "Rendez-la. Vous aurez encore besoin de nous. Nous avons vraiment du mal à joindre les deux bouts, et ça ne rendra pas votre bourse plus lourde. Ce grippe-sou, notre usurier, en cherche encore d'autres.";
			link.l1 = "D'accord. Tenez, extorqueurs. Je dirai que je ne l'ai pas trouvée : ce sera un mensonge.";
			link.l1.go = "Greedy_4";
			link.l2 = "Finalement, non. Je ne vous donnerai rien !";
			link.l2.go = "Greedy_no";
		break;

		case "Greedy_4":
			if (!CheckAttribute(pchar,"GemGiven")) pchar.GemGiven = 1;
			else pchar.GemGiven = sti(pchar.GemGiven) + 1;
			TakeItemFromCharacter(pchar, "UsurersJew");
			ChangeCharacterReputation(pchar, 3);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			AddCharacterExpToSkill(pchar, "Fortune", 20);
			if (sti(pchar.GemGiven)>=5)
			{
				bool ok = (GetCharacterItem(Pchar, "map_part1")>0)  && (GetCharacterItem(Pchar, "map_part2")>0);
				if (GetCharacterItem(Pchar, "map_full") > 0 || ok)
				{

					dialog.text = "Merci, capitaine. Nous essaierons de vous rendre votre générosité si l'occasion se présente. א plus tard !";
					AddQuestRecord("SeekUsurersJewel", "3");
				}
				else
				{
					if (GetCharacterItem(Pchar, "map_part1") > 0 && GetCharacterItem(Pchar, "map_part2") == 0 && GetCharacterItem(Pchar, "map_full") == 0)
					{
						dialog.text = "Merci, capitaine. Nous avons récemment trouvé un morceau de carte ici. Il ne nous sert à rien, mais à vous, il sera peut-être utile. Acceptez-le en cadeau.";
						AddQuestRecord("SeekUsurersJewel", "4");
						GiveItem2Character(pchar, "map_part2");
						DeleteAttribute(pchar,"GemGiven");
					}
					if (GetCharacterItem(Pchar, "map_part1") == 0 && GetCharacterItem(Pchar, "map_part2") > 0 && GetCharacterItem(Pchar, "map_full") == 0)
					{
						dialog.text = "Merci, capitaine. Nous avons récemment trouvé un morceau de carte ici. Il ne nous sert à rien, mais à vous, il sera peut-être utile. Acceptez-le en cadeau.";
						AddQuestRecord("SeekUsurersJewel", "4");
						GiveItem2Character(pchar, "map_part1");
						DeleteAttribute(pchar,"GemGiven");
					}
					if (GetCharacterItem(Pchar, "map_part1") == 0 && GetCharacterItem(Pchar, "map_part2") == 0 && GetCharacterItem(Pchar, "map_full") == 0)
					{
						aref item;
						Items_FindItem("map_full", &item);
						FillMapForTreasure(item);
						GiveItem2Character(pchar, "map_full");
						DeleteAttribute(pchar,"GemGiven");
						AddQuestRecord("SeekUsurersJewel", "5");
						dialog.text = "Merci, capitaine. Acceptez cet objet en cadeau. Nous ne pourrons sans doute pas nous en servir, mais vous, vous en aurez peut-être besoin...";
					}
				}
			}
			else
			{
				AddQuestRecord("SeekUsurersJewel", "3");
				dialog.text = "Merci, capitaine. Nous essaierons de vous rendre votre générosité si l'occasion se présente. א plus tard !";
			}
			link.l1 = "Allons donc !";
			link.l1.go = "Greedy_good_end";
		break;

		case "Greedy_end":
			LAi_group_SetRelation("greedybastard", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("greedybastard", LAI_GROUP_PLAYER, true);
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_SetFightMode(npchar, true);
			for(i = 0; i < sti(npchar.quant); i++)
			{
				sld = CharacterFromID("GreedyBastard_"+pchar.location+"_"+i);
				LAi_SetWarriorTypeNoGroup(sld);
			}
			DialogExit();
		break;

		case "Greedy_good_end":
			DialogExit();
			for(i = 0; i < sti(npchar.quant); i++)
			{
				sld = CharacterFromID("GreedyBastard_"+pchar.location+"_"+i);
				sld.lifeDay = 0;
				LAi_SetActorType(sld);
				LAi_ActorRunToLocation(sld, "reload", "reload1", "", "", "", "OpenTheDoors", -1);
			}
		break;

		// КОНЕЦ

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			break;
	}
}

void ChurchGenQuest2_GiveCup()
{
	AddItems(PChar, "Bible", 1);
	ref rItem = ItemsFromID("Bible");
	rItem.Name = "itmname_ChurchGenQuest2Cup"; // rItem.Name = "itmname_bible";
	rItem.City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_2.QuestTown + "Gen");
	rItem.Weight = 15.0; // rItem.Weight = 2;
	rItem.picIndex = 8; // itm.picIndex = 6;
	rItem.picTexture = "ITEMS_5"; // itm.picTexture = "ITEMS_9";
	ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest2Cup");
}
