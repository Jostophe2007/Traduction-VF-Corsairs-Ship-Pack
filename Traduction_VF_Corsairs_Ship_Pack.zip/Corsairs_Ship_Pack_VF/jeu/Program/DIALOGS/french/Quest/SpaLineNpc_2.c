// диалоговый файл №2 на испанку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            if (npchar.id == "Francisco")// квест №2, базар с Франциско
            {
    			dialog.text = "C'est vous "+ GetSexPhrase("la personne qui a reçu", "la jeune femme qui a reçu") +" une mission d'Antonio de Souza ?";
    			link.l1 = "Je viens de le quitter.";
    			link.l1.go = "Step_S2_1";
            }
            if (CheckAttribute(pchar, "questTemp.State.Usurer"))// квест №2, малый де Фонкейсао
            {
    			dialog.text = "Je me rends, vous avez gagné !";
    			link.l1 = "Jansen Noonan de Fonseca en personne, si je ne m'abuse...";
    			link.l1.go = "Step_S2_6";
            }
            if (npchar.id == "Bandit" && CheckAttribute(pchar, "questTemp.State.Store"))// квест №2, бандит на 1-м этаже
            {
    			dialog.text = "Que faites-vous ici ? Dehors !";
    			link.l1 = "Hé, du calme ! Qu'est-ce que c'est que ces manières ?";
    			link.l1.go = "Step_S2_11";
            }
			if (npchar.id == "JacowDeFonseka" && CheckAttribute(pchar, "questTemp.State.Store"))
			{
                dialog.text = "Qui êtes-vous ? Comment me connaissez-vous ? On se connaît ? Comment avez-vous su oם je suis ?";
    			link.l1 = "Halte ! Halte, mon cher. Je vais tout vous raconter, laissez-moi seulement vous libérer d'abord. Vous n'y voyez pas d'inconvénient, n'est-ce pas ?";
    			link.l1.go = "Step_S2_14";
            }
			if (npchar.id == "PortMansBoy")  //квест №6, посыльный начальника порта.
			{
                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", c'est le capitaine du port qui m'envoie vers vous.";
    			link.l1 = "Oui, très bien. Que vous a-t-il chargé de me dire ?";
    			link.l1.go = "Step_S6_1";
            }	//квест №7, Моисей Воклейн.
 			if (pchar.questTemp.State == "Sp7SavePardal_toAntigua" || pchar.questTemp.State == "Sp7SavePardal_PardalIsSink")
			{
                dialog.text = "Diable !!! Tout avait si bien commencé : nous avions attrapé Pardal... Et puis vous...";
    			link.l1 = "Hum, c'est bien pour ça que je suis là : pour que vos bons débuts ne finissent pas si bien...";
    			link.l1.go = "Step_S7_1";
            }  //квест №8, капитан Ансель.
 			if (pchar.questTemp.State == "Sp8SaveCumana_toCumana")
			{
                dialog.text = "Argh, maudit chien d'Espagnol !";
    			link.l1 = "Continuons, capitaine, ne nous laissons pas distraire...";
    			link.l1.go = "exit";
				LAi_SetCurHPMax(npchar);
				QuestAboardCabinDialogExitWithBattle("");
            }
		break;

//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//*************************** Квест №2, диалоги с Франциско на выходе из Инквизиии ***************************
 		case "Step_S2_1":
			dialog.text = "Je sais quelle est votre mission, et je sais comment elle peut finir. Il est avantageux pour l'Ordre d'améliorer ses affaires financières aux dépens des marchands, surtout par les mains des autres.";
			link.l1 = "Vous croyez que c'est la seule question ?";
			link.l1.go = "Step_S2_2";
		break;
 		case "Step_S2_2":
			dialog.text = "Peut-être pas, mais vous devez vous souvenir d'une chose : si vous vous trouvez devant la question de tuer des marchands, réfléchissez bien, je vous prie, à la raison pour laquelle vous כtez la vie à ces gens. Vous ne les connaissez pas, ils peuvent être de bons croyants et de bons citoyens.";
			link.l1 = "Comment peuvent-ils être de bons croyants, s'ils sont jansénistes ?!";
			link.l1.go = "Step_S2_3";
		break;
 		case "Step_S2_3":
			dialog.text = "Ils croient au même Seigneur que vous et moi. Réfléchissez-y...";
			link.l1 = "Je prends note de vos paroles. Mais à qui ai-je l'honneur ?";
			link.l1.go = "Step_S2_4";
		break;
 		case "Step_S2_4":
			dialog.text = "Francisco de San Agostinho.";
			link.l1 = "Merci, Francisco. Bonne journée.";
			link.l1.go = "Step_S2_5";
		break;
 		case "Step_S2_5":
			chrDisableReloadToLocation = false;
			pchar.questTemp.State = "Inquisition_afterFrancisco";
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "gate_back", "none", "", "", "", 40.0);
            LAi_SetPlayerType(pchar);
            DialogExit();
		break;
 		case "Step_S2_6":
			dialog.text = "C'est exact... Et comment me connaissez-vous ?";
			link.l1 = "Une jeune fille me l'a dit, elle s'appelle Tanneken Clemens. Vous la connaissez ?";
			link.l1.go = "Step_S2_7";
		break;
 		case "Step_S2_7":
			dialog.text = "Bon sang ! Qu'est-ce qu'elles ne feraient pas, ces filles, pour se marier ! Aller jusqu'à engager des gros bras !";
			link.l1 = "Ce n'est pas elle qui me paie, nos intérêts ont simplement coïncidé pour le moment...";
			link.l1.go = "Step_S2_8";
		break;
 		case "Step_S2_8":
			dialog.text = "Ouf, voilà qui est mieux... Vous savez, il est encore trop tכt pour moi pour fonder une famille... Que me voulez-vous ?";
			link.l1 = "Rien de vous. J'ai besoin de quelque chose de votre père. Vous allez passer un moment dans ma cale, à réfléchir à votre famille, aux enfants, aux valeurs humaines éternelles... Pendant ce temps, votre papa et moi, nous discuterons de quelque chose.";
			link.l1.go = "Step_S2_9";
		break;
 		case "Step_S2_9":
			dialog.text = "Ce n'est pas la pire option, vu ma situation actuelle. Merci de ne pas m'avoir tué.";
			link.l1 = "Remerciez Tanneken, elle m'a demandé de ne pas vous toucher, crapule... Bon, c'est tout.";
			link.l1.go = "Step_S2_10";
		break;
 		case "Step_S2_10":
            AddQuestRecord("Spa_Line_2_Inquisition", "8");
            pchar.quest.Inquisition_DieHard.over = "yes";
            Island_SetReloadEnableGlobal("Jamaica", true);
            QuestAboardCabinDialogQuestSurrender();
            DialogExit();
		break;
 		case "Step_S2_11":
			dialog.text = "Fiche le camp, je te dis. Tu en as assez de vivre ?!";
			link.l1 = "Hum, il y a quelque chose qui cloche ici... Je ne bouge pas d'ici tant que tu n'auras pas répondu à une question. Que faites-vous ici ? C'est Jacob Lopez de Fonseca que vous retenez prisonnier ?";
			link.l1.go = "Step_S2_12";
		break;
 		case "Step_S2_12":
			dialog.text = "Bon... Il est temps pour toi de mourir, beau parleur...";
			link.l1 = "Ce n'est pas à toi de décider de la durée de ma vie...";
			link.l1.go = "Step_S2_13";
		break;
 		case "Step_S2_13":
            LAi_SetPlayerType(pchar);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
 		case "Step_S2_14":
			dialog.text = "Bien sמr que non. C'est l'émotion. Je n'ai plus aucun espoir d'être libéré, et je n'ai pas l'habitude d'attendre des miracles. J'ai entendu ces bandits discuter du prix de ma rançon, et l'un d'eux est sans doute déjà arrivé à Curaçao\n"+
                          "Mais comment avez-vous fait pour venir si vite ? Et vous ne m'avez toujours pas dit votre nom.";
			link.l1 = "" + GetFullName(pchar) + ", à votre service. Eh bien... Mon navire attend à Portobelo, nous pouvons partir.";
			link.l1.go = "Step_S2_15";
		break;
 		case "Step_S2_15":
			dialog.text = "Je ne veux pas paraître importun, mais en voyant comment vous avez tenu tête à ces gens et comment vous les avez réglés, j'ai compris que vous étiez un militaire"+ GetSexPhrase("", ", même si vous êtes une femme") +". Je voudrais vous demander un service\n"+
                          "C'est sur le chemin d'ici à Curaçao. Je n'ai pas le droit d'insister, je peux seulement vous le demander. Le fait est que notre communauté possédait une ancienne relique chrétienne : l'וvangile de Judas Iscariote.";
			link.l1 = "Possédait ?";
			link.l1.go = "Step_S2_16";
		break;
 		case "Step_S2_16":
			dialog.text = "Elle a disparu il y a environ vingt ans avec son gardien, Samuel Coheno.";
			link.l1 = "J'ai déjà entendu ce nom quelque part...";
			link.l1.go = "Step_S2_17";
		break;
 		case "Step_S2_17":
			dialog.text = "דa m'étonnerait. Bref, récemment, nous avons retrouvé la trace du ravisseur, il est réapparu aux Bermudes. Nos tentatives pour lui racheter la relique ont échoué, alors nous avons engagé des marins à la taverne. Le voleur s'est montré étonnamment fort et a même blessé plusieurs hommes, après quoi il a pris la fuite. Les marins l'ont suivi de près et l'ont rattrapé au chantier naval. Mais là, il s'est volatilisé.";
			link.l1 = "Comment ça ?";
			link.l1.go = "Step_S2_18";
		break;
 		case "Step_S2_18":
			dialog.text = "Il est entré dans le bureau du chantier naval, et c'est tout. On ne sait absolument pas oם il est passé. Le propriétaire du chantier ne nous a rien dit. Je vous demande de m'aider à récupérer le livre. Vous m'aiderez ?";
			link.l1 = "Combien pensez-vous que ce livre puisse valoir ?";
			link.l1.go = "Step_S2_19";
		break;
 		case "Step_S2_19":
			dialog.text = "Il n'a pas de prix ! Mais pourquoi cette question ?";
			link.l1 = "La protection des reliques chrétiennes est le devoir sacré de tout vrai catholique... Mais je n'ai encore rien décidé, on verra selon les circonstances.";
			link.l1.go = "Step_S2_20";
		break;
 		case "Step_S2_20":
			dialog.text = "Merci !";
			link.l1 = "Pas encore.";
			link.l1.go = "Step_S2_21";
		break;
 		case "Step_S2_21":
 		    LAi_SetPlayerType(pchar);
            AddQuestRecord("Spa_Line_2_Inquisition", "12");
            AddQuestRecord("Spa_Line_2_Inquisition", "13");
            AddPassenger(pchar, npchar, false);
            SetCharacterRemovable(npchar, false);
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "", 5.0);
            pchar.questTemp.State.SeekBible = 1; //флаг на поиск Евангелие
            LocatorReloadEnterDisable("Shore3", "reload2_back", true); //закрываем для особо хитрых
            DialogExit();
		break;
//*************************** Квест №6, базар с посыльным начальника порта ***************************
 		case "Step_S6_1":
			dialog.text = "Le navire que vous attendez a jeté l'ancre en rade de Tortuga. Le messager, un officier hollandais, est en ce moment chez d'Ogeron ; vous pourrez le rencontrer un peu plus tard à la sortie de la résidence.";
			link.l1 = "Parfait ! Merci pour votre service.";
			link.l1.go = "Step_S6_2";
		break;
 		case "Step_S6_2":
			dialog.text = "Il n'y a pas de quoi. Remerciez le capitaine du port.";
			link.l1 = "Hum, je le remercierai sans faute.";
			link.l1.go = "Step_S6_3";
		break;
 		case "Step_S6_3":
			chrDisableReloadToLocation = false;
			AddQuestRecord("Spa_Line_6_TakeMessangeer", "3");
			bDisableFastReload = true; //закрываем фаст релоад
			SaveCurrentQuestDateParam("questTemp");
			Pchar.quest.Sp6TakeMess_Interception.win_condition.l1 = "location";
            Pchar.quest.Sp6TakeMess_Interception.win_condition.l1.location = "Tortuga_town";
            Pchar.quest.Sp6TakeMess_Interception.win_condition = "Sp6TakeMess_Interception";
            LAi_SetPlayerType(pchar);
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", -1);
            DialogExit();
		break;
//*************************** Квест №7, базар с Моисеем Воклейном при абордаже ***************************
 		case "Step_S7_1":
			dialog.text = "Bon, vous avez réussi... Après un peu de repos, je vous propose de continuer.";
			link.l1 = "Avec grand plaisir...";
			link.l1.go = "exit";
			LAi_SetCurHPMax(npchar);
            QuestAboardCabinDialogExitWithBattle("");
		break;


    }
}


