// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// Gregg: "Goods for Richard Tillman" - where Shon Stablovski sits.
			// Sent Jons has no tavern file of its own, so the city is checked as well.
			if (PChar.UneasyDelivery == "6" && NPChar.city == "SentJons")
			{
				link.l8 = "J'ai besoin de Shon Stablovski. Oם peut-on le trouver ?";
				link.l8.go = "UneasyDelivery_1";
			}

		break;

		case "UneasyDelivery_1":
			dialog.text = "Shon ? Shon Stablovski ?";
			link.l1 = "Oui, c'est justement l'homme qu'il me faut.";
			link.l1.go = "UneasyDelivery_2";
		break;

		case "UneasyDelivery_2":
			dialog.text = "Mais il est assis là-bas, à la table du fond.";
			link.l1 = "Merci de votre aide.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryAntiguaDialogExit");
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

