// Джон Моррис, авторитетный корсар по английской линейке
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
			dialog.text = "Je vous prie de quitter ma maison. Je suis occupé, et je n'ai pas le temps de vous parler.";
			link.l1 = "Je m'en vais déjà.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			if (pchar.questTemp.Sharp == "begin" && rand(1))
			{
				link.l1 = "John, j'ai entendu parler de pêcheurs de perles qui travaillent dans nos eaux. Tu n'es pas au courant de cette affaire ?";
				link.l1.go = "SharpPearl_1";
			}
		break;

 		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

        case "I_know_you_good":
			dialog.text = LinkRandPhrase(GetFullName(pchar) + ", content de te voir ! Qu'est-ce qui t'amène ici ?",
                                         RandSwear() + " Qui vois-je ?! " + GetFullName(pchar) + " ! Qu'est-ce qui t'amène sur l'île ?",
                                         "Tiens, tiens, "+ GetFullName(pchar)+ " en visite chez moi ! J'aimerais bien te revoir manier la lame... Bon, quelles sont tes questions, "+ GetSexPhrase("l'ami","ma belle") +" ?");
			link.l1 = RandPhraseSimple("Je suis juste passé voir comment tu allais.", "Des broutilles, rien d'important.");
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			if (pchar.questTemp.Sharp == "begin" && rand(1))
			{
				link.l1 = "John, j'ai entendu parler de pêcheurs de perles qui travaillent dans nos eaux. Tu n'es pas au courant de cette affaire ?";
				link.l1.go = "SharpPearl_1";
			}
		break;

		//********************* капитан Шарп *********************
		case "SharpPearl_1":
			dialog.text = "Non, je ne sais pas. דa, c'est pour Sharp, "+ GetSexPhrase("l'ami","ma petite") +". Je n'arrive pas à me résoudre à l'appeler capitaine...";
			link.l1 = "Tu sais oם le trouver ?";
			link.l1.go = "SharpPearl_2";
			pchar.questTemp.Sharp = "seekSharp";
		break;
		case "SharpPearl_2":
			dialog.text = "Aucune idée. Les affaires de perles ne m'intéressent pas. Mais à ta place, je le chercherais dans les bordels. Tכt ou tard, tu l'y trouveras...";
			link.l1 = "D'accord, John, merci.";
			link.l1.go = "exit";
		break;
		//********************* Английская линейка *********************
 		case "EngLine_quests":
            dialog.text = "Je vous prie de quitter ma maison. Je suis occupé, et je n'ai pas le temps de vous parler.";
			link.l1 = "Je m'en vais déjà.";
			link.l1.go = "exit";
			switch (pchar.questTemp.State)   // Доступ к квестам
            {
	     		case "go_talks_with_pirates":
	    			dialog.text = "Dis-moi pourquoi tu es venu ?";
	    			link.l1 = "Je viens de la part du gouverneur général de la Jamaïque, sir Thomas Madiford.";
	    			link.l1.go = "Step_1";
	      		break;
            }
		break;

 		case "Step_1":
			dialog.text = "Voilà qui devient intéressant ! Madiford ne m'aime pas, alors qu'est-ce qui l'a poussé à m'envoyer "+ GetSexPhrase("un pirate","une pirate") +" ?";
			link.l1 = "Madiford rassemble une escadre pour attaquer Curaçao.";
			link.l1.go = "Step_2";
  		break;

 		case "Step_2":
			dialog.text = "Sans moi.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "Step_3";
  		break;

 		case "Step_3":
			dialog.text = "Le gouverneur général de la Jamaïque me traite, pour le dire gentiment, sans grande amitié. C'est pourquoi son invitation à participer à cette affaire m'inquiète sérieusement. Il y a quelque chose qui cloche.";
			link.l1 = "Peut-être que Madiford a changé sa colère en clémence.";
			link.l1.go = "Step_4";
  		break;

 		case "Step_4":
			dialog.text = "Tu ne connais pas bien Madiford. Non, je ne suis pas si bête, il y a quelque chose qui cloche. Il y aura peut-être un bain de sang, et je n'ai pas vraiment envie de me baigner dans le sang pour le gouverneur général de la Jamaïque. Alors ce sera sans moi, et bonne chance à toi, "+ GetSexPhrase("corsaire","ma belle") +".";
			link.l1 = "Merci. Et bonne chance à toi aussi, l'ami.";
			link.l1.go = "exit";

            AddQuestRecord("Eng_Line_2_Talking", "5");
            pchar.questTemp.Count = makeint(sti(pchar.questTemp.Count) + 1);
            if (pchar.questTemp.Count == "4")   {pchar.questTemp.State = "after_talks_with_pirates";}
            NextDiag.TempNode = "First time";
  		break;

 		case "Lets_go_bussines":
			dialog.text = "Ah, te revoilà. Qu'est-ce que tu as à me dire, maintenant ?";
			link.l1 = "Je participe à l'affaire de Morgan. Tu es prêt à prendre Belize d'assaut ?";
			link.l1.go = "Step_5";
  		break;

 		case "Step_5":
            if (GetCompanionQuantity(pchar) != 4)
            {
    			dialog.text = "Je suis prêt à partir immédiatement.";
    			link.l1 = "Alors en avant !";
    			link.l1.go = "Step_6";
            }
            else
            {
    			dialog.text = "J'ai vu quatre navires en rade. Si je viens moi aussi avec toi, nous ne ferons que nous gêner pendant l'assaut. Alors ce sera sans moi, cette fois.";
    			link.l1 = "Eh bien, comme vous voudrez, portez-vous bien.";
    			link.l1.go = "exit";
                NextDiag.TempNode = "First time";
            }

  		break;

 		case "Step_6":
			AddQuestRecord("Eng_Line_3_Morgan", "5");
            LAi_SetActorType(NPChar);
            LAi_ActorSetStayMode(NPChar);
            ChangeCharacterAddressGroup(NPChar, "PortSpein_houseF2", "goto", "goto3");
            CharacterIntoCompanionAndGoOut(pchar, npchar, "reload", "reload1", 6, false);
            Fantom_SetBalls(npchar, "pirate");
            npchar.CompanionEnemyEnable = false;  // нет отпора при обстреле
            pchar.questTemp.CompanionQuantity = makeint(sti(pchar.questTemp.CompanionQuantity) + 1);
            pchar.questTemp.CompanionQuantity.Morris = true;
            NextDiag.TempNode = "Have_hot_bussines";
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;

  		break;

	 	case "Have_hot_bussines":   // Если геймеру вдруг захочется ещё пообщаться, не знаю, сможет ли. Но на всякий случай.
			dialog.text = "Il faut se dépêcher, le temps presse.";
			link.l1 = "Nous arriverons à temps.";
			link.l1.go = "exit";
            NextDiag.TempNode = "Have_hot_bussines";
  		break;

	 	case "Gold_found_in_fort":    // Нода разговора в форте Куманы
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Morris") && !IsCompanion(characterFromID("John Morris")))
    		{
            	dialog.text = "Bon sang, mon galion a sombré ! J'ai perdu le navire et un bon quart de l'équipage. Dommage pour ces braves gars..\n"+
                              " Enfin, pour les survivants, la vie continue, et la récompense, c'est l'or de Cumaná. Nous avons trouvé l'or dans cette pièce, sous les planches du plancher. Tu es un vrai corsaire"+ GetSexPhrase("",", même si tu es une femme") +".";
            }
            else
            {
            	dialog.text = "Je n'ai pas eu à chercher longtemps, bon sang ! Nous avons trouvé l'or dans cette pièce, sous les lattes du plancher. Tu es un vrai corsaire"+ GetSexPhrase("",", même si tu es une femme") +".";
            }
			link.l1 = "Merci. Je suis content de l'entendre de ta bouche.";
			link.l1.go = "Step_7";
        break;

	 	case "Step_7":
			dialog.text = "Je rentre chez moi, à la Trinité. Tu pourras toujours m'y trouver.";
			link.l1 = "Bonne journée, John. Nous nous reverrons !";
			link.l1.go = "Step_8";
        break;

	 	case "Step_8":
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 15.0);
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
        break;

		//********************* Французская линейка *********************
        case "FraLine8_talk":
            dialog.text = "Qui êtes-vous et que vous faut-il ?";
            link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ". Mais j'ai besoin d'une bagatelle. Des messagers du gouverneur général Madiford vont certainement venir vous voir...";
            link.l1.go = "Step_F8_1";
        break;
        case "Step_F8_1":
            dialog.text = "Quels messagers ? Parle franchement, pas de sous-entendus avec moi !";
            link.l1 = "D'accord, John. La question est, au fond, la suivante : Madiford prépare une attaque contre les Hollandais et veut y mêler la Confrérie.";
            link.l1.go = "Step_F8_2";
        break;
        case "Step_F8_2":
            dialog.text = "Et alors ?";
            link.l1 = "Il est important pour moi que tu ne participes pas à cette aventure.";
            link.l1.go = "Step_F8_3";
        break;
        case "Step_F8_3":
            dialog.text = "Hé, l'idée d'attaquer les Hollandais ne me plaît pas, et j'accepterai sans doute ta proposition. Mais tu vas devoir faire quelque chose pour moi.";
            link.l1 = "Quoi donc ?";
            link.l1.go = "Step_F8_4";
        break;
        case "Step_F8_4":
            dialog.text = "Je ne sais pas, je croyais que tu connaissais cette histoire... Bref, voilà l'affaire : un certain joyeux luron, le capitaine Gay, s'est offert une promenade en mer sans savoir qui étaient les siens et qui étaient les étrangers ; il a envoyé deux marchands anglais par le fond, et quand ça a commencé à sentir le roussi, il a tout mis sur mon dos. J'étais moi aussi en expédition à ce moment-là, et Madiford cherchait depuis longtemps à me tenir en bride. Bref, je n'ai plus accès à Port Royal en ce moment.";
            link.l1 = "Et que proposez-vous ?";
            link.l1.go = "Step_F8_5";
        break;
        case "Step_F8_5":
            dialog.text = "Tu vois, toute cette pagaille m'arrange. Si Madiford me demande un service, les accusations contre moi tombent. Mais si tu peux obtenir des documents prouvant que je ne suis pour rien dans les méfaits dont on m'accuse, c'est bien aussi. La seconde option me convient mieux, car je ne veux pas gâter mes relations avec les Hollandais.";
            link.l1 = "Eh bien, un service en vaut un autre. Je vais essayer d'obtenir un document qui te disculpe. Que me conseilles-tu de faire ?";
            link.l1.go = "Step_F8_6";
        break;
        case "Step_F8_6":
            dialog.text = "Pour fouiller dans les documents du capitaine Gay, il me faut son journal de bord.";
            link.l1 = "Bon, j'ai compris. Je vais agir, et toi, ne fais rien jusqu'à mon retour.";
            link.l1.go = "Step_F8_7";
        break;
        case "Step_F8_7":
            dialog.text = "Dépêche-toi...";
            link.l1 = "Absolument !";
            link.l1.go = "exit";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "6");
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex", GetSexPhrase("", "e"));
			NextDiag.TempNode = "Step_F8_Result";
			// ==> открываем дверь таверны Порт Рояля - там кэп Гей.
			LocatorReloadEnterDisable("PortRoyal_tavern", "reload2_back", false);
			LAi_LocationFightDisable(&Locations[FindLocation("PortRoyal_tavern_upstairs")], false);
            ref sld = GetCharacter(NPC_GenerateCharacter("CaptainGay", "bocman", "man", "man", 40, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 40, 100, 90, "blade34", "pistol5", 150);
            sld.Dialog.Filename    = "Quest\FraLineNpc_2.c";
        	sld.name 	= "Capitaine";
        	sld.lastname 	= "Gay";
			sld.items.ShipsJournal = 1;
			sld.money = 65720;
			sld.items.potion4 = 4;
			sld.items.potionrum = 1;
			sld.items.potionwine = 2;
			sld.items.sculMa2 = 1;
			sld.items.jewelry17 = 30;
			sld.items.jewelry18 = 15;
			sld.SaveItemsForDead = true; // сохранять на трупе вещи
			sld.DontClearDead = true; // не убирать труп через 200с
			LAi_NoRebirthEnable(sld);
			LAi_SetLoginTime(sld, 0.0, 24.0);
			LAi_SetStayType(sld);
			ChangeCharacterAddressGroup(sld, "PortRoyal_tavern_upstairs", "goto", "goto1");
		break;
        case "Step_F8_Result":
            dialog.text = "Alors, oם en es-tu, capitaine ? Tu as récupéré le journal de bord de ce salaud de Gay ?";
			if (CheckCharacterItem(pchar, "ShipsJournal"))
			{
				link.l1 = "J'ai deux nouvelles, et toutes les deux sont bonnes, ce qui n'arrive pas souvent. Gay est allé rejoindre ses ancêtres. Et son journal, le voici.";
				link.l1.go = "Step_F8_8";
			}
			else
			{
				link.l1 = "Pas encore... Mais je m'en occupe, ça viendra...";
				link.l1.go = "exit";
			}
        break;
        case "Step_F8_8":
            dialog.text = "Bon, bon... Oui, je me doutais bien que ce paon peindrait ses exploits de toutes les couleurs. Bon, je vais envoyer ce cahier à Madiford par des gens sמrs, et je suis sמr qu'il ne me fera plus chanter. Et toi, tu peux rassurer les Hollandais : je ne les toucherai pas !";
            link.l1 = "Parfait, Morris. Bon, maintenant je dois partir, au revoir...";
            link.l1.go = "exit";
			pchar.questTemp.Count = makeint(pchar.questTemp.Count)+1;
			NextDiag.TempNode = "I_know_you_good";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "7");
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex", GetSexPhrase("", "e"));
            TakeItemFromCharacter(pchar, "ShipsJournal");
        break;

		//********************* Пиратская линейка *********************
		case "PL_Q8_deck":
			dialog.text = "Et qu'est-ce que tu fais sur mon pont ? Nous partons pour Portobelo !";
			link.l1 = "Oui, je m'en souviens...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;
		case "PL_Q8_deck_1":
			dialog.text = "Tu ne devrais pas perdre de temps, crois-moi.";
			link.l1 = "Oui, je sais.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;


	}
}
