// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Dans mon chantier naval, et dans tout Tortuga d'ailleurs, je n'ai jamais vu de gens aussi obstinément curieux.",
                          "Mon métier, c'est de construire des navires, alors allons-y.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Hum, tout de même...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "WormEnglPlans_WormPicarder": //Голландская линейка, квест №3. узнаем о Пеьере Пикардийце.
                    link.l2 = "J'ai entendu dire que Pierre Picardy avait le meilleur navire de ces eaux.";
                    link.l2.go = "Step_H3_1";
                break;

            }
             // <== Проверяем поле состояния квестов.
		break;
 	 	case "Step_H3_1":
			dialog.text = NPCStringReactionRepeat("Peut-être bien. Sa frégate était déjà assez bonne, et l'autre jour, j'ai terminé de l'améliorer. Maintenant, ses couleuvrines sont les plus modernes qui soient : elles se chargent par la culasse ! C'est cher, mais ça en vaut la peine... Donc, apparemment, vous avez "+ GetSexPhrase("raison", "raison") +". Pourquoi cette question ?", ""+ GetSexPhrase("Señor", "Señorita") +", occupons-nous plutכt de navires, je me moque bien de Picardy pour l'instant...", "Vous m'avez déjà interrogé sur Pierre...", "וcoutez, vous pourriez peut-être vous renseigner sur Pierre ailleurs, hein ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je veux monter un petit coup, mais même "+ GetSexPhrase("le grand", "la grande") +" capitaine que je suis n'y arrivera pas sans aide... C'est pourquoi je cherche quelqu'un pour m'accompagner.", "Occupons-nous d'affaires...", "Ah oui ? Hum, c'est vrai, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +"...", "Oui, je crois que je vais me renseigner ailleurs.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H3_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H3_2":
			dialog.text = "Compris. Eh bien, Pierre est un bon choix pour ce genre de choses : Morgan lui-même lui propose ce genre d'expéditions de temps en temps.";
			link.l1 = "דa alors, Morgan lui-même ?! Ce Pierre est un homme sérieux. Merci pour la recommandation.";
			link.l1.go = "exit";
            pchar.questTemp.Talks.Shipyard = true;
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "9");
        break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

