// Герцог Альбермаль и другие
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            //Альбермаль, англ.линейка, квест №1
            if (npchar.id == "Albermal")
            {
                dialog.text = "Je vous écoute attentivement.";
                link.l1 = "Je m'appelle " + GetFullName(pchar) + ". J'ai reçu les instructions nécessaires du gouverneur Madiford.";
                link.l1.go = "Step_E1_1";
            }
            // тюремщик в Кюрасао, квест №4
            if (npchar.id == "Hoverd_Tantum")
            {
    			dialog.text = "Quoi, "+ GetSexPhrase("pris au piège, mon pigeon", "prise au piège, ma colombe") +" ?";
    			link.l1 = "Vous vous moquez de moi ?";
    			link.l1.go = "Step_E4_1";
            }
            // ==> Губернатор Форт Оранжа,  квест №5
            if (npchar.id == "Orange_Comendant")
            {
    			dialog.text = "Argh... Maudits chiens d'Anglais ! J'aurai encore le temps d'éventrer au moins l'un de vous...";
    			link.l1 = "Essaie donc...";
    			link.l1.go = "Step_E5_1";
            }
            // ==> Квест №6, Моррис Уильямс
            if (npchar.id == "Morris_Willams")
            {
                dialog.text = "Maudit soit le jour oם tu as mis le pied sur mon pont...";
                link.l1 = "Hum, tu n'aurais pas dמ faire ça...";
                link.l1.go = "exit";
            }
            if (pchar.questTemp.State == "MorrisWillams_GoToMorrisBegin" && npchar.id == "Morris_Willams")
            {
    			dialog.text = "Salutations ! Quel bon vent vous amène sur mon pont ?";
    			link.l1 = "Je suis venu voir l'heureux corsaire. On dit que vous avez pris trois galions espagnols !";
    			link.l1.go = "Step_E6_20";
            }
            if (pchar.questTemp.State == "MorrisWillams_AfterFirstTalkingWithMorris" && npchar.id == "Morris_Willams")
            {
    			dialog.text = "Nous avons déjà tout réglé, " + pchar.name + ". Je vais décharger à Port Royal.";
    			link.l1 = "Très bien.";
    			link.l1.go = "exit";
            }
            if (pchar.questTemp.State == "MorrisWillams_ModifordGood5000" && npchar.id == "Morris_Willams")
            {
                LAi_ActorSetSitMode(pchar);
                dialog.text = "Bon sang ! Je vous ai obéi, je suis allé au port, et ma cargaison a aussitכt été confisquée ! Vous m'avez piégé !";
                link.l1 = "Quoi ? Qui l'a confisquée ?";
                link.l1.go = "Step_E6_2";
            }
            if (pchar.questTemp.State == "MorrisWillams_ModifordPolitic" && npchar.id == "Morris_Willams")
            {
                dialog.text = "Eh bien, que vous a dit ce gredin en uniforme de gouverneur ?";
                link.l1 = "J'ai du mal à l'admettre, mais on dirait qu'on nous a roulés. Madiford ne rendra pas votre marchandise.";
                link.l1.go = "Step_E6_6";
            }
            if (pchar.questTemp.State == "MorrisWillams_PinnaceNotFound" || pchar.questTemp.State == "MorrisWillams_2PinnaceNotFound")
            {
                dialog.text = "Vous avez capturé mon « Indigo » ?";
                link.l1 = "J'ai suivi la pinasse, mais je n'ai même pas aperçu sa poupe : elle m'a semé. Toutes mes excuses...";
                link.l1.go = "Step_E6_11";
            }
            if (pchar.questTemp.State == "MorrisWillams_PinnaceBoard" && npchar.id == "Morris_Willams")
            {
                dialog.text = "Vous avez capturé mon « Indigo » ?";
                link.l1 = "J'ai capturé au large de San Juan cette même pinasse espagnole. Seulement, il n'y avait ni « Indigo », ni argent, ni acajou dans les cales.";
                link.l1.go = "Step_E6_10";
            }
            if (pchar.questTemp.State == "MorrisWillams_PinnaceBoardNotFoundMoney" && npchar.id == "Morris_Willams")
            {
                dialog.text = "Vous avez capturé mon « Indigo » ?";
                link.l1 = "J'ai capturé au large de San Juan cette même pinasse espagnole. Seulement, il n'y avait ni « Indigo », ni argent, ni acajou dans les cales. J'ai fouillé tout le navire, mais je n'ai rien trouvé de valeur, toutes mes excuses.";
                link.l1.go = "Step_E6_11";
            }
            if (pchar.questTemp.State == "MorrisWillams_DieHard" && npchar.id == "Morris_Willams")
            {
                dialog.text = "Vous avez capturé mon « Indigo » ?";
                link.l1 = "Pardonnez-moi, mais cette pinasse s'est révélée trop forte pour moi. Je n'ai pas réussi à la prendre.";
                link.l1.go = "Step_E6_11";
            }
            if (pchar.questTemp.State == "MorrisWillams_PinnaceSink" && npchar.id == "Morris_Willams")
            {
                dialog.text = "Vous avez capturé mon « Indigo » ?";
                link.l1 = "Cette maudite pinasse a coulé, et avec elle tout votre butin. J'ai fait tout ce que j'ai pu. Toutes mes excuses.";
                link.l1.go = "Step_E6_11";
            }
			// ==> Квест №12, диалоги с полковником Томасом Линчем
            if (pchar.questTemp.State == "ColonelLinch_GoToKingstown")
            {
                dialog.text = "א qui ai-je l'honneur de parler ? Présentez-vous !";
                link.l1 = "Je suis corsaire au service de l'Angleterre, monsieur. Je m'appelle " + GetFullName(pchar) + ".";
                link.l1.go = "Step_E12_1";
            }

            if (pchar.questTemp.State == "ColonelLinch_ArrestModiford")
            {
                dialog.text = "Vous devez arrêter Madiford. Dépêchez-vous.";
                link.l1 = "Bien, monsieur.";
                link.l1.go = "exit";
            }
        break;

//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Step_E1_1":
            if (GetQuestPastDayParam("questTemp") < 2)
            {
                dialog.text = "Votre navire et vous, êtes-vous parés pour cette mission ?";
                link.l1 = "Tout est paré, nous partons immédiatement.";
                link.l1.go = "Go_with_Albermal";
                link.l2 = "Plus tard, je dois me ravitailler. Le voyage sera dangereux.";
                link.l2.go = "exit";
			}
			else
			{
				dialog.text = "Vous tardez déraisonnablement à accomplir la mission qui vous a été confiée ! Vous savez que mon temps est compté. Combien de temps devrai-je attendre ?";
				link.l1 = "Monsieur, je regrette ce retard, mais il était nécessaire. Maintenant, tout est prêt, partons immédiatement !";
				link.l1.go = "Go_with_Albermal";
				link.l2 = "Monsieur, je dois encore faire quelques préparatifs. Je ne peux pas exposer votre vie à des risques inutiles faute d'avoir bien préparé l'opération. Je vous prie de patienter encore un peu.";
				link.l2.go = "exit";
				ChangeCharacterReputation(pchar, -1);
            }
            NextDiag.TempNode = "Step_E1_1";
        break;

        case "Go_with_Albermal":
            AddQuestRecord("Eng_Line_1_Albermal", "2");
            AddPassenger(pchar, npchar, false);
            SetCharacterRemovable(npchar, false);
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "", 10.0);
			pchar.quest.fight_withSpanish_Albermal.win_condition.l1          = "location";
			pchar.quest.fight_withSpanish_Albermal.win_condition.l1.location = "Antigua";
			pchar.quest.fight_withSpanish_Albermal.win_condition             = "fight_withSpanish_Albermal";
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

        case "in_the_SentJons":
            if (GetQuestPastDayParam("questTemp") < 14)
            {
                dialog.text = "Je vous suis reconnaissant du fond du cœur. Vous avez fait preuve d'un véritable héroïsme face à un adversaire redoutable. De plus, nous sommes arrivés à St. John's à temps. Je vous remets une lettre pour sir Thomas Madiford : remettez-lui cette dépêche en main propre. Adieu !";
                link.l1 = "Bon voyage jusqu'en Angleterre ! Adieu, monsieur.";
                link.l1.go = "Albermal_go_out";
                pchar.questTemp.State = "Albermal_good_time";
            }
            else
            {
                dialog.text = "Je vous suis reconnaissant pour l'héroïsme dont vous avez fait preuve au combat contre les Espagnols. Mais à cause de votre lenteur, tous mes plans se sont effondrés ! Je vous remets une lettre pour Madiford. Allez, je ne vous retiens pas plus longtemps.";
                link.l1 = "Mes meilleurs vœux, monsieur.";
                link.l1.go = "Albermal_go_out";
                ChangeCharacterReputation(pchar, -4);
                pchar.questTemp.State = "Albermal_late";
            }
            GiveItem2Character(pchar, "letter_Albermal");
            NextDiag.TempNode = "in_the_SentJons";
        break;

        case "Albermal_go_out":
            AddQuestRecord("Eng_Line_1_Albermal", "4");
            RemovePassenger(pchar, npchar);
            DialogExit();
            // уходит
            LAi_SetActorType(NPChar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload2", "none", "", "", "", 10.0);
            LAi_SetPlayerType(pchar);
    	    NPChar.LifeDay = 1; // уберём нпс на след.день.
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
        break;

        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Диалоги тюремщика по четвёртому квесту английки **********************************
 		case "Step_E4_1":
			dialog.text = "Non, c'est moi qui pose les questions. Je veux que vous soyez sérieux. Et que s'est-il passé ensuite ? Quel était ce tapage en ville à cause de vous ?";
			link.l1 = "Votre usurier, Josef Noonen de Foncacao, est une belle crapule. J'avais une proposition d'affaires à lui faire, mais quand nous ne sommes pas tombés d'accord, il a appelé la garde, et on m'a arrêté, on m'a pris mes armes et mon argent. Maintenant, on m'accuse d'espionnage.";
			link.l1.go = "Step_E4_2";
		break;

 		case "Step_E4_2":
			dialog.text = "Hum, on dirait bien que notre Josef... Et quelle affaire lui avez-vous proposée ?";
			link.l1 = "Lui racheter des bijoux et quelques babioles espagnoles. Je suis corsaire, je ne voulais pas aller jusqu'à Tortuga, j'ai décidé d'écouler le butin tout près.";
			link.l1.go = "Step_E4_3";
		break;

 		case "Step_E4_3":
			dialog.text = "Hé, contre les corsaires"+ GetSexPhrase("", ", et encore moins contre les femmes corsaires,") +" je n'ai rien : vous me plaisez bien, vous autres. Cependant, tu peux parier que Josef essaiera de te faire tuer ici cette nuit même, pour que tu ne fasses pas trop parler de toi, car il n'a besoin ni de liens avec des corsaires ni d'une réputation de receleur. C'est un homme respecté en ville, en quelque sorte.";
			link.l1 = "Si tu m'aides à sortir, je ne resterai pas en dette.";
			link.l1.go = "Step_E4_4";
		break;

 		case "Step_E4_4":
			dialog.text = "Je vais ouvrir le cadenas de ta grille. Tu pourras sortir dès que je serai parti. Je n'ai pas besoin d'argent, j'ai mes propres comptes à régler avec Josef...";
			link.l1 = "Je comprends. Eh bien, merci.";
			link.l1.go = "Step_E4_5";
		break;

 		case "Step_E4_5":
			dialog.text = "Sors par tes propres moyens, je ne suis pas ton complice. Au fait, comme tu n'as pas d'arme, je te donne un sabre de l'arsenal de la prison\n"+
                          "Adieu. J'espère que Josef sera furieux pendant longtemps.";
			link.l1 = "N'en doute pas. Adieu, l'ami. Merci encore pour ton aide.";
			link.l1.go = "Step_E4_6";
		break;

 		case "Step_E4_6":
            DoQuestReloadToLocation("Villemstad_prison", "goto", "goto12", "");
            AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "7");
            ChangeCharacterReputation(pchar, -1);  // за обман.
            GiveItem2Character(pchar, "blade1");   // себельку герою; и этого бы не давал, но без оружия солдеры не нападают.
            EquipCharacterbyItem(pchar, "blade1");
            pchar.questTemp.State = "Intelligence_Curacao_OutPrison";
			pchar.questTemp.jailCanMove = false; //на всякий случай
			//==> делаем солдат поменьше, а то хрен выберешься
			for (int i=1; i<=4; i++)
			{
				sld = characterFromId("VillemstadJailSold_"+i);
				if (sld.location.locator != "soldier3")
				{
					ChangeCharacterAddress(sld, "None", "");
				}
			}
			ChangeCharacterAddress(npchar, "None", "");
			DialogExit();
		break;
//*************************************** Диалог губернатора Форт Оранжа *********************************
        case "Step_E5_1":
            LAi_SetPlayerType(pchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "AttackFortOrange_AfterFightWithCommendant");
            ChangeCharacterHunterScore(pchar, "holhunter", 70);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

//**************************************** Диалоги Морриса Уильямса **************************************
        case "Step_E6_2":
            dialog.text = "Madiford, sur son ordre.";
            link.l1 = "Je n'y comprends rien. Pourquoi l'a-t-on confisquée ?";
            link.l1.go = "Step_E6_3";
        break;

        case "Step_E6_3":
            dialog.text = "La cargaison a été remise à son propriétaire espagnol.";
            link.l1 = "Je n'en crois pas mes oreilles ! Nous sommes amis avec les Espagnols, maintenant ?";
            link.l1.go = "Step_E6_4";
        break;

        case "Step_E6_4":
            dialog.text = "Le diable seul le sait !";
            link.l1 = "Je vais tirer ça au clair, attendez-moi ici.";
            link.l1.go = "Step_E6_5";
        break;

        case "Step_E6_5":
            AddQuestRecord("Eng_Line_6_MorrisWillams", "4");
            pchar.questTemp.State = "MorrisWillams_ToModifordForCoolTalking";
            NextDiag.CurrentNode = "Willams_waiting";
            DialogExit();
        break;

        case "Willams_waiting": // если ГГ подойдёт в таверне к Уильямсу до проведения разговора с Мэдифордом
            dialog.text = "Alors, vous avez appris quelque chose ?";
            link.l1 = "Pas encore, mais je vais m'occuper de cette affaire, c'est certain. Attendez et ne quittez pas la taverne.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Willams_waiting";
        break;

        case "Step_E6_6":
            dialog.text = "Vous venez de me ruiner. Cette marchandise devait servir à payer mes dettes\n"+
                          "Dès que je suis descendu à terre au port, j'ai découvert à ma grande surprise que toutes mes reconnaissances de dette avaient été rachetées par un usurier du coin. Il m'a coupé l'accès à la mer, et mon navire sert de garantie au remboursement. Voilà !";
            link.l1 = "Combien devez-vous ?";
            link.l1.go = "Step_E6_7";
            LocatorReloadEnterDisable("PortRoyal_town", "gate_back", false); //открываем выход из города
            LocatorReloadEnterDisable("PortRoyal_town", "reload1_back", false);
        break;

        case "Step_E6_7":
            dialog.text = "Ma dette est de cent quarante mille.";
            link.l1 = "Vous savez quoi, votre dette, c'est votre problème. Adieu, et portez-vous bien.";
            link.l1.go = "Willams_GoogBye";
            link.l2 = "J'ai 140 000. Je suis désolé, c'est à cause de moi que vous êtes tombé dans un piège. Alors prenez-les et réglez vos problèmes.";
            link.l2.go = "Willams_GiveMoney";
            link.l3 = "Je vous rendrai votre marchandise.";
            link.l3.go = "Willams_BackGoods";
        break;

        case "Willams_GoogBye":
            dialog.text = "Et portez-vous bien vous aussi, cher ami (avec ironie).";
            link.l1 = "Puissions-nous tous nous porter bien, amen... Adieu.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "empty";
            pchar.questTemp.Waiting_time = "10";
            pchar.questTemp.CurQuestNumber = "7";
            ChangeCharacterReputation(pchar, -100);
            AddCharacterExpToSkill(pchar, "Leadership", -350);
            AddCharacterExpToSkill(pchar, "Accuracy", -50);
            AddCharacterExpToSkill(pchar, "Commerce", -150);
            AddCharacterExpToSkill(pchar, "Sneak ", -150);
            AddCharacterExpToSkill(pchar, "Fencing  ", -100);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "6");
            CloseQuestHeader("Eng_Line_6_MorrisWillams");
            NextDiag.TempNode = "Willams_Fack";
			//слухи
			AddSimpleRumour("Capitaine, le bruit court que vous n'avez pas traité le pauvre Williams de la meilleure façon...", ENGLAND, 5, 1);
        break;

        case "Willams_Fack":
            dialog.text = "Vous êtes quelqu'un de parfaitement malhonnête, capitaine " + GetFullName(pchar) + ". Je ne veux pas vous parler.";
            link.l1 = "Comme vous voudrez, capitaine.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Willams_Fack";
			//слухи
			AddSimpleRumour("Morris Williams dit des choses si terribles sur vous ! א l'en croire, vous êtes"+ GetSexPhrase(" un vrai gredin", " une vraie gredine") +"...", ENGLAND, 5, 1);
        break;

        case "Willams_GiveMoney":
            dialog.text = "Oh, vous n'avez pas assez d'argent. Bon, je vais attendre ici, à la taverne, pendant que vous le réunissez.";
            link.l1 = "Oui, c'est vrai, je n'avais pas fait attention... Mais ce n'est rien, je reviens vite, vous n'aurez pas à attendre longtemps.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Step_E6_7";
            if (sti(pchar.money) >= 140000)
            {
                dialog.text = "Vous êtes "+ GetSexPhrase("un homme honnête et noble", "une femme honnête et noble") +", capitaine. Les lois de la Confrérie ne sont pas de vains mots pour vous. Je vais prendre cet argent, car j'en ai grand besoin. Merci.";
                link.l1 = "Inutile de me remercier, c'était aussi ma faute. Dès que vous aurez réglé vos dettes, j'espère vous retrouver en mer. Adieu, l'ami.";
                link.l1.go = "exit";
                SaveCurrentQuestDateParam("questTemp");
                pchar.questTemp.State = "empty";
                pchar.questTemp.Waiting_time = "5";
                pchar.questTemp.CurQuestNumber = "7";
                ChangeCharacterReputation(pchar, 20);
                AddCharacterExpToSkill(pchar, "Leadership", 150);
                AddCharacterExpToSkill(pchar, "Commerce", 250);
                AddCharacterExpToSkill(pchar, "Sneak ", 50);
                AddCharacterExpToSkill(pchar, "Defence", 150);
                AddQuestRecord("Eng_Line_6_MorrisWillams", "7");
				AddQuestUserData("Eng_Line_6_MorrisWillams", "sSex", GetSexPhrase("", "e"));
                CloseQuestHeader("Eng_Line_6_MorrisWillams");
                AddMoneyToCharacter(pchar, -140000);
                NextDiag.TempNode = "Willams_NiceTalking";
				//слухи
				AddSimpleRumour("Capitaine, on dit que vous avez beaucoup aidé Williams en payant sa dette. Vous êtes quelqu'un de noble, capitaine, c'est un honneur pour moi de vous parler !", ENGLAND, 5, 1);
            }
        break;

        case "Willams_NiceTalking":
            dialog.text = "Quel plaisir de vous revoir ! Comment allez-vous, capitaine " + GetFullName(pchar) + " ?";
            link.l1 = "דa va, Morris. J'espère que tu vas bien aussi.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Willams_NiceTalking";
        break;

        case "Willams_BackGoods":
            dialog.text = "J'aimerais bien, mais je ne peux pas : mon navire est au port, en cale sèche\n"+
                          "Et je vous souhaite bonne chance. Les Espagnols ont dמ déjà récupérer la marchandise confisquée. Il faut découvrir sur quel navire ils vont l'emporter, et ensuite, ce ne sera qu'une formalité !";
            link.l1 = "Qui pourrait le savoir, à votre avis ?";
            link.l1.go = "Step_E6_8";
        break;

        case "Step_E6_8":
            dialog.text = "Votre ami Madiford, en premier lieu, qui d'autre !"+
                          "Comme ça, je ne sais pas ; renseignez-vous à la taverne, au bordel, au port, ou peut-être que vous croiserez la bonne personne dans la rue.";
            link.l1 = "Je file chercher, le temps presse.";
            link.l1.go = "Step_E6_9";
        break;

        case "Step_E6_9":
            dialog.text = "Oui, dépêchez-vous, je vous en prie. Ma cargaison, c'est de l'acajou, de l'argent et de l'indigo, le reste m'est égal.";
            link.l1 = "D'accord. Attendez-moi ici, je m'occupe de cette affaire.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Willams_WaitSeek";
            pchar.questTemp.State = "MorrisWillams_SeekSpanishGoods";
            AddQuestRecord("Eng_Line_6_MorrisWillams", "8");
			AddQuestUserData("Eng_Line_6_MorrisWillams", "sSex", GetSexPhrase("", "e"));
        break;

        case "Willams_WaitSeek":
            dialog.text = "Vous avez déniché quelque chose ? Quand vais-je récupérer ma cargaison ?";
            link.l1 = "Je m'en occupe, attendez.";
            link.l1.go = "exit";
            NextDiag.TempNode = "Willams_WaitSeek";
        break;

        case "Step_E6_10":
            dialog.text = "Bon sang ! Et oם est passée ma marchandise ?";
            link.l1 = "Je n'en ai aucune idée, peut-être que les Espagnols l'ont déchargée quelque part en chemin. Toutes mes excuses.";
            link.l1.go = "MorrisWillams_NotGiveMoney";
            link.l2 = "Je suppose que les Espagnols l'ont vendue en chemin. Dans la cabine du capitaine, j'ai trouvé cent quarante mille pièces ! C'est votre argent, maintenant vous pouvez payer vos dettes.";
            link.l2.go = "MorrisWillams_GiveMoney";
            NextDiag.TempNode = "Willams_NiceTalking";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "7";
        break;

        case "MorrisWillams_NotGiveMoney":
            dialog.text = "C'est fini, je suis perdu. Eh bien, "+ GetSexPhrase("l'ami", "ma petite") +", merci quand même, tu as fait tout ce que tu as pu.";
            link.l1 = "Allons, Morris. Je te souhaite d'éviter la prison.";
            link.l1.go = "MorrisWillams_GoAway";
            pchar.questTemp.Waiting_time = "10";
            ChangeCharacterReputation(pchar, -100);
            AddCharacterExpToSkill(pchar, "Leadership", -150);
            AddCharacterExpToSkill(pchar, "Accuracy", -200);
            AddCharacterExpToSkill(pchar, "Commerce", -250);
            AddCharacterExpToSkill(pchar, "Sneak ", -170);
            AddCharacterExpToSkill(pchar, "Fencing  ", -140);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "13");
			AddQuestUserData("Eng_Line_6_MorrisWillams", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_6_MorrisWillams");
			//слухи
			AddSimpleRumour("On dit, capitaine, que c'est par votre faute que Morris Williams s'est retrouvé sans le sou...", ENGLAND, 5, 1);
        break;

        case "MorrisWillams_GiveMoney":
        if (sti(pchar.money) >= 140000)
        {
            dialog.text = "Vous avez tenu parole, merci ! Désormais, vous êtes mon ami pour toujours. Je n'ai rien pour vous remercier en ce moment. Enfin... il y a une chose dont l'importance dans notre métier ne saurait être surestimée. Vous êtes "+ GetSexPhrase("un homme intrépide", "une femme intrépide") +" et vous pourrez peut-être faire ce que mon équipage et moi n'avons pas osé faire.";
            link.l1 = "Hum, ça m'intéresse. Dites-m'en plus sur cette chose, et sur ce que des coupe-jarrets aussi désespérés n'ont pas osé faire.";
            link.l1.go = "Step_E6_14";
        }
        else
        {
            dialog.text = "Et oם est l'argent ? Vous ne l'avez pas !";
            link.l1 = "Bon sang, je l'ai oublié dans ma cabine. Je retourne au navire, et vous aurez les 140 000, ne vous inquiétez pas.";
            link.l1.go = "exit";
            NextDiag.TempNode = "MorrisWillams_GiveMoney";
        }
        break;

        case "Step_E6_14":
            dialog.text = "Cette chose, c'est une cuirasse ; je ne pense pas qu'il en existe une deuxième dans les Caraïbes. Pour l'acier, écoutez la suite... "+
                          "Il y a deux ans et demi, ma frégate a été jetée par une tempête sur les récifs au nord du continent, dans le golfe de la Perdition. La moitié seulement de mon équipage s'en est sortie vivante. Les autres sont restés étendus sur le rivage\n"+
                          "Parmi les disparus de cette terrible nuit se trouvait mon maître d'équipage de l'époque, le Hollandais Lambert Groff, un homme d'un courage à toute épreuve\n"+
                          "C'est lui qui l'avait, en plus d'un bel équipement, et parmi celui-ci, il y avait cette fameuse cuirasse, une véritable œuvre d'art et une armure extrêmement fiable. Je voulais retourner au navire plus tard, mais mes coupe-jarrets survivants m'ont supplié en pleurant de n'en rien faire\n"+
                          "Et le fait est qu'après le naufrage, nous avons réussi tant bien que mal à atteindre la baie de Cozumel, oם un navire marchand hollandais nous a recueillis et emmenés à Tortuga. א notre arrivée, cinq de mes hommes ont exprimé le souhait de partir sur un lougre vers le cap Catoche, dans la baie oם gisait notre frégate naufragée\n"+
                          "On les comprend : il fallait récupérer les bijoux et l'argent qui restaient. Comme les premiers ne revenaient pas, cinq autres pirates sont partis. Mais personne ne les a jamais revus, ni les uns ni les autres. Alors je ne sais toujours pas oם sont ces corsaires ni ce qui leur est arrivé. Mais moi, je n'irai certainement pas à l'épave de ma frégate\n"+
                          "Vous, vous pouvez essayer. Mes pirates se sont peut-être simplement enfuis avec l'argent, droit vers l'Ancien Monde ou ailleurs. Qui sait..\n"+
                          "Et la cuirasse, bon sang, vaut une fortune. Et ce n'est pas une question d'argent, mais de préserver sa santé et sa vie au combat.";
            link.l1 = "Eh bien, merci, l'ami. Je vais y réfléchir, j'irai peut-être y faire un tour.";
            link.l1.go = "exit";
            pchar.questTemp.Waiting_time = "2";
            ChangeCharacterReputation(pchar, 20);
            AddCharacterExpToSkill(pchar, "Leadership", 250);
            AddCharacterExpToSkill(pchar, "Accuracy", 100);
            AddCharacterExpToSkill(pchar, "Commerce", 250);
            AddCharacterExpToSkill(pchar, "Sneak", 70);
            AddCharacterExpToSkill(pchar, "Fencing", 150);
            AddCharacterExpToSkill(pchar, "Defence", 150);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "14");
			AddQuestUserData("Eng_Line_6_MorrisWillams", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Eng_Line_6_MorrisWillams");
            AddMoneyToCharacter(pchar, -140000);
            NextDiag.TempNode = "Willams_NiceTalking";
            Pchar.quest.MorrisWillams_SeekCirassa.win_condition.l1 = "location";
            Pchar.quest.MorrisWillams_SeekCirassa.win_condition.l1.location = "Shore_ship2";
            Pchar.quest.MorrisWillams_SeekCirassa.win_condition = "MorrisWillams_SeekCirassa";
			//слухи
			AddSimpleRumour("Morris Williams ne cesse de répéter que vous êtes un capitaine formidable et honnête. Une réputation tout simplement magnifique ! Je ne pensais même pas qu'il existait encore des gens pareils sur terre.", ENGLAND, 5, 1);
        break;

        case "MorrisWillams_GoAway":
			chrDisableReloadToLocation = true;//если провалить квест, то блочится переход чтоб показать как Моррис уходит
            LAi_SetActorType(npchar);
            ChangeCharacterAddressGroup(npchar, "PortRoyal_tavern", "tables", "stay8");
            LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1);
            NextDiag.CurrentNode = "First time";
            DialogExit();
        break;

        case "Step_E6_11":
            dialog.text = "Allez au diable, vous et vos excuses. La prison me guette, et vous me présentez vos excuses...";
            link.l1 = "Malgré l'échec avec la pinasse, je vais quand même essayer de vous aider.";
            link.l1.go = "Step_E6_12";
            link.l2 = "Vous savez, j'en ai plus qu'assez de votre grossièreté. Après tout, je ne vous dois rien. Adieu, et portez-vous bien.";
            link.l2.go = "Willams_GoogBye";
        break;

        case "Step_E6_12":
            dialog.text = "Eh bien, je vous serai reconnaissant de toute aide. Qu'allez-vous faire ?";
            link.l1 = "Je ne sais pas encore. Voyons ce qui se passe ensuite, et nous prendrons une décision.";
            link.l1.go = "Step_E6_13";
        break;

        case "Step_E6_13":
            dialog.text = "Comme vous voudrez, " + pchar.name + " – merci de ne pas m'avoir laissé dans le pétrin. Je dois m'occuper de mes affaires maintenant, à plus tard.";
            link.l1 = "Ne vous inquiétez pas, tout ira bien.";
            link.l1.go = "MorrisWillams_GoAway";
            pchar.questTemp.State = "MorrisWillams_GoToHimselfBussines"
            Pchar.quest.MorrisWillams_Arrest.win_condition.l1 = "ExitFromLocation";
            Pchar.quest.MorrisWillams_Arrest.win_condition.l1.location = "PortRoyal_tavern";
            Pchar.quest.MorrisWillams_Arrest.win_condition = "MorrisWillams_Arrest";
        break;

        case "Step_E6_20":
			dialog.text = "C'est exact. J'ai réussi à intercepter une petite escadre de trois Espagnols\n"+
                          "Ma frégate a attaqué ces bigots de catholiques, et ils ont pris la fuite au lieu de m'affronter ensemble. J'ai abordé les galions un par un !";
			link.l1 = "Vous avez saigné les Espagnols ?";
			link.l1.go = "Step_E6_21";
        break;
        case "Step_E6_21":
			dialog.text = "Au contraire, j'ai interdit à mes gars de massacrer l'équipage du premier galion. Les autres, voyant que leur vie n'était pas en danger, se sont rendus presque sans combattre.";
			link.l1 = "Hum, dans la Grèce antique, les Spartiates ne poursuivaient jamais au combat un adversaire qui fuyait : la loi l'interdisait. Les adversaires des Lacédémoniens savaient que s'ils jetaient leurs armes, ils resteraient en vie. C'est pourquoi l'ennemi se rendait généralement aux Spartiates après le premier assaut. Vous avez employé la même tactique, et elle a donné de bons résultats.";
			link.l1.go = "Step_E6_22";
        break;
        case "Step_E6_22":
			dialog.text = "La réputation de pirate miséricordieux peut vite m'enrichir. J'avais déjà compris ça, même si je ne savais rien des Spartiates\n"+
                          "Bon, dites-moi, pourquoi êtes-vous là ?";
			link.l1 = "Thomas Madiford vous autorise à accoster à Port Royal et à vendre les marchandises de vos prises dans les magasins de l'île.";
			link.l1.go = "Step_E6_23";
        break;
        case "Step_E6_23":
			dialog.text = "Hum, j'ai une lettre de marque française, je veux aller à Tortuga, j'y ai des relations bien établies.";
			link.l1 = "On ne refuse pas une invitation du gouverneur de la Jamaïque, ce serait stupide. Je vous conseille de l'accepter.";
			link.l1.go = "Step_E6_24";
        break;
        case "Step_E6_24":
			dialog.text = "Bon, ça me fait moins de soucis : je n'aurai pas à me traîner jusqu'à Tortuga avec les cales pleines\n"+
                          "Même si j'y perds un peu sur les prix, j'accepte quand même, je vais au port immédiatement.";
			link.l1 = "Bonne journée, Morris. Nous nous reverrons.";
			link.l1.go = "exit";
			pchar.questTemp.State = "MorrisWillams_AfterFirstTalkingWithMorris";
			AddQuestRecord("Eng_Line_6_MorrisWillams", "2");
        break;

//**************************************** Диалоги Томаса Линча **************************************
        case "Step_E12_1":
            dialog.text = "J'ai entendu parler de vous. Vos services rendus à l'Angleterre sont très appréciés.";
            link.l1 = "Merci, monsieur.";
            link.l1.go = "Step_E12_2";
        break;

        case "Step_E12_2":
            dialog.text = "Je m'appelle Thomas Lynch. J'ai présidé le Conseil de la Jamaïque jusqu'en 1664, quand ce gredin de Madiford a été nommé gouverneur.";
            link.l1 = "Monsieur, Thomas Madiford est le gouverneur de la Jamaïque et...";
            link.l1.go = "Step_E12_3";
        break;

        case "Step_E12_3":
            dialog.text = "Il n'est plus gouverneur de la Jamaïque. Sachez que la patience du gouvernement est à bout.\n"+
                          "Lors de sa nomination au poste de gouverneur de la Jamaïque, Madiford avait reçu de Sa Majesté Charles II des instructions claires : réprimer la piraterie et entretenir des relations amicales avec l'Espagne.\n"+
                          "Au lieu de suivre les instructions reçues, Madiford a toléré la piraterie, et son dernier « tour de force », la prise et le pillage de la cכte du continent, a provoqué un scandale sans précédent en Europe ! La reine d'Espagne, Anne d'Autriche, a été en proie à une crise de nerfs pendant trois jours.\n";
            link.l1 = "Monsieur, ce sont les Espagnols qui en sont responsables. Ce sont eux qui ont commencé les hostilités en attaquant Port Royal.";
            link.l1.go = "Step_E12_4";
        break;

        case "Step_E12_4":
            dialog.text = "Et il est difficile de le leur reprocher, car Port Royal est aujourd'hui un repaire de bandits et de brigands de tout poil\n"+
                          "Vous devez comprendre qu'on ne peut pas mettre en péril l'équilibre des forces en Europe pour remplir d'argent sonnant les bourses des brigands !";
            link.l1 = "Et Tortuga, monsieur ?";
            link.l1.go = "Step_E12_5";
        break;

        case "Step_E12_5":
            dialog.text = "Tortuga est une colonie française, et l'Espagne et la France sont en guerre permanente. Ha, Louis, si je puis dire, refroidit l'ardeur des papistes en Europe\n"+
                          "L'Angleterre ne peut pas se permettre un accroissement sérieux de l'influence française dans l'Ancien Monde, c'est pourquoi nous avons un traité de paix avec l'Espagne\n"+
                          "Et notre « cher » sir Thomas Madiford fait ici le diable sait quoi !!!";
            link.l1 = "Compris, monsieur.";
            link.l1.go = "Step_E12_6";
        break;

        case "Step_E12_6":
            dialog.text = "De plus, nous avons des raisons tout à fait claires de croire que Madiford maintient le statu quo à Port Royal dans son propre intérêt\n"+
                          "Bref, il tond les corsaires qui tondent les Espagnols.";
            link.l1 = "Monsieur, nous versons bien 10 % du butin au trésor anglais.";
            link.l1.go = "Step_E12_7";
        break;

        case "Step_E12_7":
            dialog.text = "Que nenni ! Le gouvernement britannique ne voit pas la couleur de cet argent\n"+
                          "Nous savons aussi que Madiford entretient des relations particulières avec des pirates et des boucaniers réputés. Et leurs soi-disant « affaires » communes rapportent des profits astronomiques.";
            link.l1 = "Monsieur, j'ai été mêlé à certaines de ces « affaires », et je peux confirmer que c'est le cas.";
            link.l1.go = "Step_E12_8";
        break;

        case "Step_E12_8":
            dialog.text = "Je n'en doute même pas... וcoutez, j'ai une proposition d'affaires pour vous.";
            link.l1 = "Je vous écoute attentivement, monsieur.";
            link.l1.go = "Step_E12_9";

        break;

        case "Step_E12_9":
            dialog.text = "Le fait est que Madiford doit être arrêté. Cependant, ce ne sera pas si facile\n"+
                          "Pour la garnison anglaise de Port Royal, il reste le gouverneur de la Jamaïque. En fait, nous risquons de provoquer une effusion de sang entre Anglais, ce que je n'ai pas l'intention de permettre. De plus, la garnison de Port Royal est très forte.\n"+
                          "א ce que je sais, vous avez directement accès à Madiford ?";
            link.l1 = "Oui, monsieur.";
            link.l1.go = "Step_E12_10";
        break;

         case "Step_E12_10":
            dialog.text = "Eh bien, très bien. J'ai besoin que vous rendiez visite à Madiford dans sa résidence sans faire d'histoires, accompagné d'une ou deux personnes. Une visite ordinaire\n"+
                          "Et une fois auprès de Madiford, il faudra procéder à l'arrestation discrètement et sans trop de bruit. Je vous donnerai tous les pouvoirs nécessaires\n"+
                          "Il est clair que c'est extrêmement dangereux.";
            link.l1 = "C'est vrai. Et la récompense, monsieur ?";
            link.l1.go = "Step_E12_11";
        break;

         case "Step_E12_11":
            dialog.text = "Que voudriez-vous ?";
            link.l1 = "Ces derniers temps, j'ai été assez proche de Madiford, et je souhaite que les nouvelles autorités anglaises des Caraïbes se montrent indulgentes à mon égard.";
            link.l1.go = "Step_E12_12";
        break;

         case "Step_E12_12":
            dialog.text = "Je n'ai rien à vous reprocher, vous avez agi en vertu d'une lettre de marque. En cas d'arrestation réussie de Madiford, je vous garantis non pas l'indulgence, mais la bienveillance des autorités britanniques envers votre personne.";
			link.l1 = "Parfait ! Et deuxièmement : je veux la moitié des revenus que Madiford a gagnés illégalement.";
            link.l1.go = "Step_E12_13";
        break;

        case "Step_E12_13":
            dialog.text = "Hum... Vous avez le sens des affaires, " + GetFullName(pchar) + ".";
            link.l1 = "Croyez-moi, je revendique cet argent à juste titre : ma contribution à cette tirelire est très, très solide...";
            link.l1.go = "Step_E12_14";
        break;

        case "Step_E12_14":
            dialog.text = "Oh là là, bon sang... D'accord ! La moitié des biens confisqués est à vous. Je vous nomme donc mon adjoint et je vous confie une mission de la plus haute importance.\n"+
                          "J'ai besoin que vous vous rendiez immédiatement à Port Royal pour arrêter l'ancien gouverneur et criminel d'וtat Thomas Madiford, afin qu'il soit jugé à Londres.";
            link.l1 = "Ce sera fait, monsieur.";
            link.l1.go = "exit";
            pchar.questTemp.State = "ColonelLinch_ArrestModiford";
            AddQuestRecord("Eng_Line_12_ColonelLinch", "2");
			AddQuestUserData("Eng_Line_12_ColonelLinch", "sSex", GetSexPhrase("", "e"));
            LAi_SetPlayerType(pchar);
            LAi_SetStayType(npchar);
            NextDiag.TempNode = "YouMustGo";
        break;

        case "YouMustGo":
            dialog.text = "Vous devez arrêter Madiford au plus vite.";
            link.l1 = "א vos ordres, monsieur !";
            link.l1.go = "exit";
            NextDiag.TempNode = "YouMustGo";
        break;
    }
}
