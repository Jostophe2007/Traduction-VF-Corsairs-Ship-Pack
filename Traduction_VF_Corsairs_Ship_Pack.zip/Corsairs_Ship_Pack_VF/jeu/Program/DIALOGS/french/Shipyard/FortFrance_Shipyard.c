// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Dans mon chantier naval, et dans toute la ville d'ailleurs, je n'ai jamais vu de gens aussi obstinément curieux.",
                          "Eh bien, quelles questions ? Mon métier, c'est de construire des navires, alors allons-y.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Hum, tout de même...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "KillLoy_toSeek")
			{
				link.l1 = "Un certain Edward Law s'est-il adressé à vous pour acheter un navire ?";
				link.l1.go = "PL_Q3_1";
			}
		break;
		//пиратка, квест №3, поиски Лоу
		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Il est venu, mais il n'a rien acheté.",
				"J'ai déjà tout dit à ce sujet...",
				"Il est venu, il est venu. Seulement, je n'ai rien à ajouter à ce que j'ai dit plus tכt.",
                "וcoutez, "+ GetSexPhrase("fatigué", "fatiguée") +" !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Qu'est-ce qui n'allait pas ?",
				"Oui, c'est vrai...",
                "Compris.",
				"Je m'en vais déjà...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q3_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q3_2":
			dialog.text = "Il voulait un brick, mais, désolé, il n'avait d'argent que pour un lougre.";
			link.l1 = "Je vois... Vous avez remarqué oם il est allé ?";
			link.l1.go = "PL_Q3_3";
		break;
		case "PL_Q3_3":
			dialog.text = "Héhé, on sait bien oם. Il est allé chez l'usurier pour emprunter de l'argent, mais celui-ci ne lui a rien donné, hé hé hé...";
			link.l1 = "Qu'est-ce qui vous fait dire ça ?";
			link.l1.go = "PL_Q3_4";
		break;
		case "PL_Q3_4":
			dialog.text = "Eh bien, il n'est pas revenu, donc il n'a pas trouvé l'argent, héhé...";
			link.l1 = "Bien vu !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "4");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

