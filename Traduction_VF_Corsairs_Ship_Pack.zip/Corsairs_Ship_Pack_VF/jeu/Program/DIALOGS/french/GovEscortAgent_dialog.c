// Deck talks with the allied messenger-agent (escort marine event, "agent" variant).
// Encounter is created in Treasure.c (GovEscortAgentOnMap); outcomes there (GovEscortAgent_Redirect and _OnExit wrappers).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iBase = sti(pchar.CargoQuest.iMoney);
	string sZ = pchar.CargoQuest.GovEscortAgentZ;

	switch (Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "First time":
			if (CheckAttribute(pchar, "GovEscortAgentResolved"))
			{
				dialog.text = "L'affaire est réglée, capitaine. Bon vent.";
				link.l1 = "א vous aussi.";
				link.l1.go = "exit";
				NextDiag.TempNode = "First time";
				break;
			}
			dialog.text = "Doucement, capitaine, pas besoin de sabres : je suis un ami. Un homme de confiance de la couronne, au service de " + NationNameGenitive(sti(NPChar.nation)) + ". Mauvaises nouvelles : des pirates vous attendent sur votre route ; quelqu'un a laissé échapper quelque chose au sujet de la cargaison d'וtat. Suivez un bon conseil : conduisez plutכt le convoi à " + XI_ConvertString("Colony" + sZ + "Acc") + " – la cargaison y sera reçue de la même façon, directement par le gouverneur, et pour la peine et le risque, la couronne vous paiera cinq fois plus. Ou bien gardez votre cap, à vous de choisir.";
			link.l1 = "D'accord. J'emmène la cargaison à " + XI_ConvertString("Colony" + sZ + "Acc") + ". (" + FindRussianMoneyString(iBase * 5) + ")";
			link.l1.go = "GovEscortAgent_Yes";
			link.l2 = "Non. Je garde mon cap.";
			link.l2.go = "GovEscortAgent_No";
			NextDiag.TempNode = "First time";
		break;

		case "GovEscortAgent_Yes":
			GovEscortAgent_Redirect(NPChar);
			AddDialogExitQuestFunction("GovEscortAgent_Depart_OnExit");
			dialog.text = "Sage décision, capitaine. Mettez le cap sur " + XI_ConvertString("Colony" + pchar.CargoQuest.iTradeColony + "Acc") + ". On vous y accueillera, et on vous paiera intégralement : cinq fois le prix de la guilde. Bon vent.";
			link.l1 = "Le cap est fixé.";
			link.l1.go = "exit";
		break;

		case "GovEscortAgent_No":
			dialog.text = "Comme vous voudrez, capitaine. Dieu veuille que vous passiez. Adieu.";
			link.l1 = "Nos chemins se séparent.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("GovEscortAgent_RefuseResolve_OnExit");
		break;
	}
}
