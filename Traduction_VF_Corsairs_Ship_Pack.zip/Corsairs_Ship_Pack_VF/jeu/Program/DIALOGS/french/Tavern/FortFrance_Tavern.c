// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "BlackLabel_toLaVega")
			{
				link.l1 = "L'ami, sais-tu si un certain Edward Law vit dans ta ville ?";
				link.l1.go = "PL_Q2_1";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_PJ_KV"))	//Квест ***Проклятая жара***		(Вино)
			{
				link.l1 = "Je viens de me rappeler qu'on m'a demandé d'acheter une bouteille de vin.";
				link.l1.go = "PDM_PJ_1";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_PJ_KR"))	//Квест ***Проклятая жара***		(Ром)
			{
				link.l1 = "J'ai besoin d'acheter du rhum.";
				link.l1.go = "PDM_PJ_Rom_1";
			}
		break;
		case "PL_Q2_1":
			dialog.text = NPCStringReactionRepeat("Non, c'est la première fois que j'en entends parler. Il n'y a personne de ce nom en ville.",
				"Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à son sujet : il n'y a personne de ce nom chez nous.",
				"Je vous ai déjà répondu qu'Edward Law n'est pas en ville.",
                "Vous me fatiguez...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Compris... Merci.",
				"Oui, oui, je comprends...",
                "Compris...",
				"...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
		break;

		case "PDM_PJ_1":
			dialog.text = "Mais ce n'est pas un problème ! Hé hé hé ! Vous êtes à la bonne adresse, et vous parlez à la bonne personne ! Vous voulez une bouteille de vin ? Vous pouvez même acheter un tonneau ! Le meilleur vin de tout l'archipel !",
			link.l1 = "Eh bien, c'est parfait, mais je n'ai besoin que d'une bouteille. Combien en voulez-vous ?",
			link.l1.go = "PDM_PJ_2";
		break;

		case "PDM_PJ_2":
			dialog.text = "Oh, "+ GetSexPhrase("monsieur", "mademoiselle") +", je suis sמr que vous saurez apprécier la vraie valeur de ce divin nectar ! Vous aurez une bouteille de mon bon vieux vin pour seulement 200 pièces d'or !",
			MakeRandomLinkOrderThree(link,
			"Je prends le vin, " + npchar.name+". Mais avec de tels prix, vous n'aurez sans doute pas beaucoup d'acheteurs.",
			"PDM_PJ_Beru_1",

			"Mais c'est stupide ! א ce prix-là, je peux acheter un excellent bourgogne de France ! Vous essayez de m'arnaquer, gredin !",
			"PDM_PJ_Beru_2",

			"Laissez tomber. Le garde se passera de sa bouteille de vin.",
			"exit");
		break;

		case "PDM_PJ_Beru_1":
			dialog.text = "Voici votre bouteille... Un vin noble pour un homme noble, hé hé hé. Vous ne serez pas déçu, "+ GetSexPhrase("monsieur", "mademoiselle") +". Vous voulez autre chose ?",
			link.l1 = "Non, je ne veux rien. Et j'espère qu'un puits d'esprit comme vous saura apprécier l'ironie de la situation : j'achète cette bouteille de vin exquis et hors de prix pour un simple soldat français. Au revoir, " + npchar.name+".",
			link.l1.go = "PDM_PJ_Beru_3";
		break;

		case "PDM_PJ_Beru_2":
			dialog.text = "Gonfler les prix ? Hé hé hé, "+ GetSexPhrase("monsieur", "mademoiselle") +", vous plaisantez, bien sמr. Oui, en France, on peut acheter une bouteille de bourgogne pour 200 pièces d'or. Mais la Martinique, ce n'est pas la France, n'est-ce pas ? Hé hé hé !",
			link.l1 = "Donnez-moi ce maudit vin, et au nom de Dieu, arrêtez de ricaner !",
			link.l1.go = "PDM_PJ_Beru_3";
		break;

		case "PDM_PJ_Beru_3":
			DialogExit();

			AddQuestRecord("PDM_Proklyataya_Jara", "2");
			GiveItem2Character(PChar, "PDM_PJ_Vino");
			AddMoneyToCharacter(pchar, -200);
			DeleteAttribute(pchar, "questTemp.PDM_PJ_KV");
			DeleteAttribute(pchar, "questTemp.PDM_PJ_SS");
			sld = CharacterFromID("PDM_PJ_Strajnik_1")
			sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
			sld.dialog.currentnode = "Prines_Vino_1";
		break;

		case "PDM_PJ_Rom_1":
			dialog.text = "Pour le vin, c'est bien plus simple, oui, oui ! Le rhum est la boisson la moins chère qu'on puisse acheter dans l'archipel, mais, "+ GetSexPhrase("monsieur", "mademoiselle") +", je ne vends jamais de rhum en quantité inférieure à un tonneau ! Hé hé hé ! Personne ne met le rhum en bouteille ! Hé hé hé !",
			link.l1 = "Oui, bon, " + npchar.name+" ! Les marins boivent sans arrêt du rhum dans votre taverne, et ils ne l'achètent pas au tonneau...",
			link.l1.go = "PDM_PJ_Rom_2";
		break;

		case "PDM_PJ_Rom_2":
			dialog.text = "Oh, vous êtes si perspicace, c'est bien ça, c'est bien ça. Seulement... ils boivent le rhum dans des chopes, et moi, je remplis les chopes au tonneau. Bien sמr, je peux vous vendre une chope de rhum... Mais, "+ GetSexPhrase("monsieur", "mademoiselle") +", vous n'allez pas vous promener dans la rue une chope à la main, n'est-ce pas ? Hé hé hé ! Oh, comme les gars vont rire !",
			link.l1 = "C'est l'absurdité la plus drכle qui soit... Attendez ! Vous pouvez remplir ces bouteilles de vin vides avec du rhum du tonneau ! Et voilà ! Il n'y a pas de problème...",
			link.l1.go = "PDM_PJ_Rom_3";
		break;

		case "PDM_PJ_Rom_3":
			dialog.text = "Vraiment, vous êtes presque un génie, capitaine. Vous avez tout à fait raison, je peux le faire... Mais j'espère que vous comprenez qu'il s'agit d'un service exclusif, spécial... la bouteille est lavée et séchée à la main, vous savez... Je peux vendre à mon client du rhum en bouteille pour... 200 pièces ! Hé hé hé !",
			link.l1 = "Vous avez complètement perdu la tête, " + npchar.name+". 200 pièces pour du rhum bon marché ? Non ! Au revoir !",
			link.l1.go = "exit";
			link.l2 = "Bon, d'accord ! Tu m'as vraiment amusé, gredin. Voici ton argent. Donne-moi le rhum. Tu as bien mérité ton or.",
			link.l2.go = "PDM_PJ_Rom_4";
		break;

		case "PDM_PJ_Rom_4":
			dialog.text = "Merci, "+ GetSexPhrase("monsieur", "mademoiselle") +". Un instant, s'il vous plaît\n"+
							"Voici votre tonneau de rhum en DEUX bouteilles, capitaine. Je l'ai noué avec des rubans roses rien que pour vous... Oh, hé hé hé...",
			link.l1 = "Attention, " + npchar.name+", un jour, vous allez tout simplement vous étouffer de rire. Je crois que si je ne pars pas d'ici, c'est exactement ce qui va arriver. Au revoir.",
			link.l1.go = "PDM_PJ_Rom_5";
			AddMoneyToCharacter(pchar, -200);
		break;

		case "PDM_PJ_Rom_5":
			DialogExit();

			Log_info("Vous avez reçu deux bouteilles, dont l'une est désormais א VOUS");
			GiveItem2Character(PChar, "PDM_PJ_Rom");
			GiveItem2Character(PChar, "PDM_PJ_BsRL");
			DeleteAttribute(pchar, "questTemp.PDM_PJ_KR");
			sld = CharacterFromID("PDM_PJ_Strajnik_2")
			sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
			sld.dialog.currentnode = "Prines_Rom_1";
			AddQuestRecord("PDM_Proklyataya_Jara", "4");
			
			sld = CharacterFromID("PDM_PJ_Strajnik_1")
			LAi_SetActorType(sld);
			LAi_ActorAnimation(sld, "stun_1", "", 1.0);
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

