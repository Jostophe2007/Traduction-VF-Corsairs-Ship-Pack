// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
   	float locx, locy, locz;
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> англ.линейка квест №4 Разведмиссию в Кюрасао
			if (pchar.questTemp.State == "Intelligence_Curacao_toYozef")
            {
                link.l1 = "Je voulais vous demander votre aide pour une affaire. Cette aide sera généreusement payée.";
                link.l1.go = "Step_E4_1";
            }
			if (pchar.questTemp.State == "Intelligence_Curacao_NoMoney_Yozef")
            {
                link.l1 = "Je voudrais vous parler d'une affaire à 100000 pièces.";
                link.l1.go = "no_money";
            }
            if (pchar.questTemp.State == "Inquisition_toCuracao" || pchar.questTemp.State == "Inquisition_afterFrancisco" )// квест №2 голл. линейки.
            {
                if (!CheckAttribute(pchar, "questTemp.State.Usurer"))
                {
        			dialog.text = "Que voulez-vous ?";
        			link.l1 = "La Sainte Inquisition vous accorde le pardon du pape pour seulement 50 000. Qu'y a-t-il ? Pourquoi ne vois-je pas de larmes de joie dans vos yeux ?";
        			link.l1.go = "Step_S2_1";
                }
                else
                {
                    if (CheckPassengerInCharacter(pchar, "JansenDeFonceicao"))
                    {
                        dialog.text = "Encore vous ! Sortez d'ici !";
            			link.l1 = "Vous me fatiguez ! Fermez-la. Maintenant, c'est moi qui dicte les conditions : vous, vous écoutez attentivement, vous réfléchissez, et vous commencez déjà à regretter de ne pas avoir tout de suite tenu compte de mes paroles.";
            			link.l1.go = "Step_S2_5";
                    }
                    else
                    {
                        if (pchar.questTemp.State.Usurer != "Ok")
                        {
                            dialog.text = "Quoi, vous ne m'avez pas encore tout "+ GetSexPhrase("dit", "dit") +" sur le pardon du pape ?";
                			link.l1 = "D'accord, Josef, parlons encore un peu...";
                			link.l1.go = "exit";
                        }
                        else
                        {
                            dialog.text = "Que vous faut-il encore, "+ GetSexPhrase("maudite sangsue, suppכt des jésuites", "maudite sangsue, suppכt des jésuites") +" ...";
                			link.l1 = "Quelle émotion, quel courage ! Formidable...";
                			link.l1.go = "exit";
                        }
                    }
                }
            }
			//пиратка, квест №5
			if (pchar.questTemp.piratesLine == "PL5Hunter_toVillemstad")
            {
				link.l1 = "Dites, papy, vous n'auriez pas des dettes à faire recouvrer ?!";
				link.l1.go = "Step_P5_1";
			}
		break;
//********************** Английская линейка, квест №4 "Exploration in Curacao" ************************
		case "Step_E4_1":
			dialog.text = "Dites-moi ce qu'il vous faut.";
			link.l1 = "Je suis prêt à payer cher pour une information. J'ai besoin de connaître les plans du gouverneur général de Curaçao à l'égard des Anglais.";
			link.l1.go = "Step_E4_2";
		break;
		case "Step_E4_2":
			dialog.text = "J'espère que vous comprenez ce que vous demandez.";
			link.l1 = "J'espère que vous comprenez que je saurai me montrer très "+ GetSexPhrase("généreux", "généreuse") +".";
			link.l1.go = "Step_E4_3";
		break;
		case "Step_E4_3":
			dialog.text = "100000 pièces, et je vous dirai tout ce que je sais.";
			link.l1 = "Je suis prêt à verser la somme demandée.";
			link.l1.go = "agree_to_pay";
			link.l2 = "Je n'ai pas assez d'argent sur moi, mais je reviendrai plus tard, c'est sמr.";
			link.l2.go = "no_money_now";
			link.l3 = "דa ne fait pas un peu beaucoup, sale porc ?";
			link.l3.go = "fack_yozef";
		break;
		case "agree_to_pay":
            if (sti(pchar.money) >= 100000)
            {
        		dialog.text = "Eh bien, je peux vous dire ceci : il y a environ une heure, à la résidence de Peter Stuyvesant, le gouverneur général de cette île, s'est achevé un conseil de guerre portant précisément sur votre question : la participation des colonies hollandaises à la guerre commerciale contre l'Angleterre. Je n'assistais pas à la réunion elle-même, mais je sais qu'à son issue, le messager du gouverneur général part quelque part pour une mission urgente. Un brick attend le messager en rade\n"+
                         "Vous avez l'air d'un pirate, et vous n'aurez aucun mal à prendre un brick hollandais. Alors dépêchez-vous, avant qu'il ne disparaisse à l'horizon. Et autre chose... Je ne vous connais pas. Adieu.";
        		link.l1 = "Voici votre argent. Moi non plus, je ne vous connais pas, et je ne veux pas vous connaître. Adieu.";
        		link.l1.go = "exit";
        		AddMoneyToCharacter(pchar, -100000);
        		AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "3");
        		pchar.questTemp.State = "Intelligence_Curacao_GaveMoneyYozef"; // заглушка на повторный вывод данного пункта в меню.
                Pchar.quest.Intelligence_Curacao_GoToShore.win_condition.l1 = "location";
                Pchar.quest.Intelligence_Curacao_GoToShore.win_condition.l1.location = "Curacao";
                Pchar.quest.Intelligence_Curacao_GoToShore.win_condition = "Intelligence_Curacao_GoToShore";
                Log_QuestInfo("Le brick est placé dans la baie.");
            }
            else
            {
        		dialog.text = "Hum, on dirait que vous n'avez pas assez d'argent, finalement. Désormais, je vous prie, ne me faites plus tourner en bourrique. Je vous attends avec la somme demandée.";
        		link.l1 = "D'accord, compris.";
        		link.l1.go = "exit";
        		pchar.questTemp.State = "Intelligence_Curacao_NoMoney_Yozef";
        		//ChangeCharacterReputation(pchar, -1); TO_DO eddy
            }
		break;
		case "no_money_now":
			dialog.text = "Eh bien, procurez-vous la somme demandée. Je vous attendrai.";
			link.l1 = "Je pense que ce sera bientכt réglé.";
			link.l1.go = "exit";
            if (pchar.questTemp.State != "Intelligence_Curacao_NoMoney_Yozef")
            {
                AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "4");
            }
            pchar.questTemp.State = "Intelligence_Curacao_NoMoney_Yozef";
		break;
		case "no_money":
			dialog.text = "Vous avez l'argent ? Oם sont mes 100000 ?";
			link.l1 = "Oui, j'ai l'argent et je suis prêt à vous le donner. Alors, qu'avez-vous appris ?";
			link.l1.go = "agree_to_pay";
			link.l2 = "Pas encore, mais je vais me le procurer, c'est sמr, et je reviendrai plus tard.";
			link.l2.go = "no_money_now";
			link.l3 = "דa ne fait pas un peu beaucoup, sale porc ?";
			link.l3.go = "fack_yozef";
		break;
		case "fack_yozef":    // посыл Йозефа с попыткой замочить
			dialog.text = "Quel culot ! Je vous prie de quitter ma maison immédiatement !";
			link.l1 = "Que le diable vous emporte, maudite sangsue ! Je vais vous étriper sur-le-champ !";
			link.l1.go = "Step_E4_4";
		break;
		case "Step_E4_4":
			dialog.text = "Pas si vite, "+ GetSexPhrase("gredin", "garce") +". Gardes, à moi !!!";
			link.l1 = "Bon sang !";
			link.l1.go = "Step_E4_5";
		break;
		case "Step_E4_5":
            pchar.questTemp.State = "Intelligence_Curacao_FightGard";
            LAi_LocationFightDisable(&Locations[FindLocation("Villemstad_bank")], false);
            AddQuestRecord("Eng_Line_4_Intelligence_Curacao", "5");
	    AddQuestUserData("Eng_Line_4_Intelligence_Curacao", "sSex", GetSexPhrase("", "e"));
	    AddQuestUserData("Eng_Line_4_Intelligence_Curacao", "sSex1", GetSexPhrase("", "e"));
            LAi_NoRebirthEnable(npchar);
            LAi_group_Register("EnemyFight");
            GetCharacterPos(pchar, &locx, &locy, &locz);
            for (int i=1; i<=3; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("HolSolder"+i, "sold_hol_"+i, "man", "man", 20, HOLLAND, 0, true));
                FantomMakeCoolFighter(sld, 20, 70, 60, BLADE_LONG, "pistol2", 40);
            	LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, "EnemyFight");
               	ChangeCharacterAddressGroup(sld, "Villemstad_bank", "goto", LAi_FindNearestFreeLocator("goto", locx, locy, locz));
            }
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_SetCheckMinHP(pchar, 10, true, "Intelligence_Curacao_KickYozef");
            LAi_SetPlayerType(pchar);
            LAi_SetFightMode(pchar, true);
            Pchar.quest.Intelligence_Curacao_GoToShore.win_condition.l1 = "location";
            Pchar.quest.Intelligence_Curacao_GoToShore.win_condition.l1.location = "Curacao";
            Pchar.quest.Intelligence_Curacao_GoToShore.win_condition = "Intelligence_Curacao_GoToShore";
			DialogExit();
		break;
//********************** Испанская линейка, квест №2 "The Inquisition" ************************
		case "Step_S2_1":
			dialog.text = "Vous me confondez avec quelqu'un d'autre. Je n'ai rien à me reprocher !";
			link.l1 = "C'est ce que vous croyez, mais l'Ordre est d'un autre avis. Vous allez donc devoir payer.";
			link.l1.go = "Step_S2_2";
		break;
		case "Step_S2_2":
			dialog.text = "Je ne vous paierai rien du tout ! Et si vous ne sortez pas de chez moi tout de suite, j'appelle les domestiques !";
			link.l1 = "Eh bien, comme vous voudrez, ce sera pire pour vous...";
			link.l1.go = "Step_S2_4";
		break;
		case "Step_S2_4":
			dialog.text = "Vous vous êtes "+ GetSexPhrase("mis en tête de me menacer ", "mis en tête de me menacer ") +" ?";
			link.l1 = "Non, pourquoi donc. Tout va bien, Joseph...";
			link.l1.go = "exit";
			AddQuestRecord("Spa_Line_2_Inquisition", "5");
			pchar.questTemp.State.Usurer = 1;
		break;
		case "Step_S2_5":
			dialog.text = "Et pourquoi devrais-je écouter les sornettes que vous racontez ?";
			link.l1 = "C'est simple, Josef : votre fils est entre mes mains. Suis-je assez convaincant ? Ou faut-il vous montrer une preuve ? Tenez, par exemple, je peux vous apporter un doigt coupé, ou une oreille de votre fils. Vous voulez ?";
			link.l1.go = "Step_S2_6";
		break;
		case "Step_S2_6":
			dialog.text = "Vous... Non, je vous crois... Si je rends l'argent maintenant, qu'est-ce qui me garantit que vous ne lui ferez rien ?";
			link.l1 = "Il n'y a aucune garantie. Mettez-vous un peu à la place de ceux que vous avez poussés au désespoir. Goמtez un peu à la misère. Et cessez de parler, donnez-moi l'argent.";
			link.l1.go = "Step_S2_7";
		break;
		case "Step_S2_7":
			dialog.text = "Prenez. Mais je ne l'oublierai pas.";
			link.l1 = "Pas de problème. Souvenez-vous-en. Et souvenez-vous aussi que l'Ordre vous a à l'œil...";
			link.l1.go = "Step_S2_8";
		break;
		case "Step_S2_8":
            AddQuestRecord("Spa_Line_2_Inquisition", "10");
			ReleasePrisoner(characterFromId("JansenDeFonceicao"));
            AddMoneyToCharacter(pchar, 50000);
            pchar.questTemp.State.Usurer = "Ok"; //бабки получены
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
//********************** Пиратская линейка, квест №5 ОГЗ ************************
		case "Step_P5_1":
			dialog.text = "Non. Inutile. Eh, vous autres, les soi-disant recouvreurs de dettes, vous êtes tous comme des jumeaux, "+ GetSexPhrase("vous parlez même pareil", "vous parlez même pareil. Même si vous êtes une femme") +". C'est exactement comme ça que parle Avory.";
			link.l1 = "John Avory ?! Mais c'est mon copain. Il est encore en ville ? Oם puis-je le trouver ?";
			link.l1.go = "Step_P5_2";
		break;
		case "Step_P5_2":
			dialog.text = "Je n'en ai aucune idée. C'est un homme libre, il va oם bon lui semble. Quant à savoir s'il est encore à Willemstad, c'est peu probable : il n'y a plus de travail pour lui ici. Vous êtes "+ GetSexPhrase("un ami", "une amie") +" de John, vous devez bien comprendre qu'il faut le chercher là oם le rhum coule à flots : dans les tavernes !";
			link.l1 = "Ha ! Bien sמr, qui en douterait... Mais vous êtes sמr de ne pas vous rappeler oם il aurait pu aller ? Il a dit quelque chose ?";
			link.l1.go = "Step_P5_3";
		break;
		case "Step_P5_3":
			pchar.questTemp.piratesLine.Q5.city_1 = GetQuestNationsCity(ENGLAND);
			dialog.text = "Il a dit qu'il partait chez les Anglais. Il me semble qu'il a parlé de " + XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_1 + "Voc") + ", mais je ne l'affirmerai pas.";
			link.l1 = "Vous disiez n'en avoir aucune idée. Eh bien, merci !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "2");
			AddQuestUserData("Pir_Line_5_Hunter", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Pir_Line_5_Hunter", "sCity", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_1));
			AddQuestUserData("Pir_Line_5_Hunter", "sIsland", XI_ConvertString(GetIslandByCityName(pchar.questTemp.piratesLine.Q5.city_1) + "Voc"));
			pchar.questTemp.piratesLine = "PL5Hunter_toFirst";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

