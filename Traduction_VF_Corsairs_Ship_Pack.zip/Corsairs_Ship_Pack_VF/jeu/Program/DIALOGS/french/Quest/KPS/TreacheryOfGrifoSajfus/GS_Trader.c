// Gregg: the trader with African diamonds - quest "The Treachery of Grifo Sajfus"
// (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\grifosajfus.c
// Nodes 1-4 - the talk before the fight, 5-15 - the tale of the beaten trader.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Hé, ça vous dirait d'acheter une paire de diamants africains ? Des pierres de première qualité, on s'arrangera sur le prix.";
			link.l1 = "Oם les avez-vous trouvés ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Et en quoi ça vous regarde ?";
			link.l1 = "Oם avez-vous trouvé ces diamants ? Répondez !";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Allez au diable !";
			link.l1 = "Ne tentez pas votre chance, ou vous le regretterez.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Ha ! Et qu'est-ce que vous pouvez me faire ? Vous croyez être le seul malin ici ? D'autres ont essayé aussi, et ils sont tous dans l'autre monde maintenant. Alors vous feriez mieux de filer vite, avant que je vous brise les os.";
			link.l1 = "Eh bien, essaie donc.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusBattleWithTrader");
		break;

		case "5":
			dialog.text = "D'accord, d'accord, je vais vous dire, je vais tout vous dire.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je suis anglais, je servais comme matelot sur la goélette « Rainbow ». Il y a quelques jours, on nous a débarqués, moi et trois camarades, aux îles Turques pour avoir tenté de fomenter une mutinerie. Trois jours plus tard, des pêcheurs de perles sont arrivés sur l'île." + NewStr() + "Nous nous sommes fait passer pour des naufragés espagnols, nous baragouinions assez bien l'espagnol, et nous avons réussi tant bien que mal à convaincre les pêcheurs de nous emmener au moins jusqu'à Porto Rico. Et le lendemain, l'un d'eux a trouvé un chébec coulé dans les hauts-fonds, à sept ou dix mètres de profondeur...";
			link.l1 = "Arrêtez ! Ce chébec s'appelait-il le « Piranha » ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Il me semble que c'était son nom. Les pêcheurs ne l'ont pas bien distingué. Et comment le savez-vous ?";
			link.l1 = "Peu importe. Continuez.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Les pêcheurs ont remonté de la cabine du capitaine un tas de marchandises intactes. Parmi tout cela, il y avait un petit coffre avec ces diamants. L'un d'eux, un connaisseur apparemment, a estimé que les pierres venaient d'Afrique et l'a dit à tout le monde.";
			link.l1 = "Ils ont compris comme ça qu'ils étaient africains ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Comme je vous le dis, c'était un connaisseur, il s'y entendait bien en ces choses.";
			link.l1 = "Bon, continuez, qu'en ont-ils fait ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Ils les ont comptés, les ont remis dans le coffre et l'ont fait garder avec la plus grande vigilance. Ils comptaient partir à l'aube, mais pendant la nuit, des pirates ont attaqué. Ils ont dמ apprendre que les pêcheurs travaillaient aux îles Turques, et ils sont venus.";
			link.l1 = "Et ensuite quoi ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Ils ont pris les pêcheurs par surprise. Ils ont débarqué une troupe de mousquetaires et en ont abattu presque tous dès les premières salves. Quelques-uns d'entre nous ont survécu à cette grêle de mitraille venue de tous cכtés et se sont repliés dans la jungle." + NewStr() + "La plus grande partie de la troupe pirate est restée sur le rivage, et une plus petite s'est lancée à nos trousses. Je ne sais pas ce que sont devenus les autres, mais moi, j'ai réussi à semer mes poursuivants.";
			link.l1 = "Et le coffre de diamants est tombé entre les mains de ces pirates ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "וcoutez la suite. J'ai couru jusqu'à la cכte nord, et j'y ai trouvé un pêcheur blessé qui se tordait de douleur. Il m'a parlé d'une tartane cachée sur ce rivage rocheux et m'a dit de quitter l'île avant que les corsaires n'y arrivent." + NewStr() + "Puis sa voix l'a trahi, et la seule chose qu'il a réussi à dire, c'est que pendant la poursuite, le coffre de diamants était avec lui et qu'il l'avait caché...";
			link.l1 = "Oם ? Oם l'a-t-il caché ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Il n'a pas eu le temps de le dire. Il a rendu l'âme.";
			link.l1 = "Donc, le coffre de diamants est toujours quelque part aux îles Turques ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Si les pirates ne l'ont pas trouvé. Ils en ont sמrement entendu parler et ont fouillé toute l'île de bout en bout.";
			link.l1 = "Ils n'en ont peut-être pas entendu parler. Quoi qu'il en soit, il faut aller voir aux îles Turques.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Et moi, cap'taine ? Je peux partir ? Je vous ai dit tout ce que je sais.";
			link.l1 = "Que le diable t'emporte, vis donc, mais ne te montre plus devant moi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusTraderExit");
		break;

		case "CitizenNotBlade":
			NextDiag.TempNode = "First time";
			dialog.text = "Fais attention, l'ami, à courir partout la lame à la main. Je pourrais devenir nerveux...";
			link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
