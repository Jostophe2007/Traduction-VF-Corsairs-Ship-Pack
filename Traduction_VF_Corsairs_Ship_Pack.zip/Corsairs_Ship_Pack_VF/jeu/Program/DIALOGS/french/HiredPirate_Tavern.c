// LEO: Hired privateer (caper) in the tavern. Offers to capture a ship for a fee.
// Logic - scripts/HiredPirate.c. Yellow "?" over head (isHiredCaper -> LAi_citizen.c).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int fee = 40000;
	if (CheckAttribute(NPChar, "hpFee")) fee = sti(NPChar.hpFee);
	int deposit = fee / 2;

	switch (Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
		break;

		case "First time":
			if (HiredPirate_IsActive()) // уже нанят - не предлагаем снова (страховка от повторного найма)
			{
				dialog.text = "Nous avons déjà un accord, capitaine. Je pars gagner mon argent. Renseignez-vous sur moi auprès des taverniers.";
				link.l1 = "Bien. Bonne chasse.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "(se penche, à voix basse) Vous avez l'air de quelqu'un qui aurait bien besoin d'une coque de plus sous son pavillon, sans trop regarder d'oם elle vient. Je suis un corsaire à louer. Indiquez-moi ces eaux, et je vous prendrai une prise : le navire sera à vous. Mon prix dépend de sa taille : " + FindRussianMoneyString(fee) + " en tout, la moitié maintenant, l'autre moitié quand vous viendrez le chercher dans la baie.";
			link.l1 = "Comment se passe la remise ?";
			link.l1.go = "explain";
			link.l2 = "דa ne m'intéresse pas.";
			link.l2.go = "decline";
		break;

		case "explain":
			dialog.text = "C'est simple. Vous me payez la moitié maintenant. Je pars en chasse : comptez de dix jours à deux semaines. Une fois le navire pris, je me cacherai dans une baie tranquille et j'attendrai. Les taverniers ont la langue bien pendue et touchent leur part : renseignez-vous sur moi auprès d'eux, et dès que je serai prêt, l'un d'eux vous soufflera dans quelle crique je me trouve. Venez-y avec le reste de mon argent et un officier disponible à bord : il faudra un capitaine au navire, et moi, je ne reste pas. Si vous traînez plus d'une semaine après le tuyau d'un tavernier, je le vendrai ailleurs. Marché conclu ?";
			if (sti(pchar.money) >= deposit)
			{
				link.l1 = "Marché conclu. Voici votre moitié. (" + FindRussianMoneyString(deposit) + ")";
				link.l1.go = "hire";
			}
			else
			{
				link.l1 = "Je n'ai pas " + FindRussianMoneyString(deposit) + " sur moi.";
				link.l1.go = "nomoney";
			}
			link.l2 = "Je vais y réfléchir.";
			link.l2.go = "decline";
		break;

		case "hire":
			HiredPirate_Hire(NPChar);
			DeleteAttribute(NPChar, "isHiredCaper"); // снять флаг метки (иначе тик LAi_sit перерисует "?")
			UnmarkCharacter(NPChar);                 // и саму метку - прямо здесь, у собеседника
			dialog.text = "La moitié en main, le reste à la livraison. Je m'en vais, alors. N'oubliez pas : renseignez-vous auprès des taverniers, et amenez un officier disponible dans la baie. Bon vent, capitaine.";
			link.l1 = "Bonne chasse.";
			link.l1.go = "exit";
		break;

		case "nomoney":
			dialog.text = "Revenez quand votre bourse sera plus lourde, capitaine. Je ne prends pas la mer sur des promesses.";
			link.l1 = "א plus tard, alors.";
			link.l1.go = "exit";
		break;

		case "decline":
			dialog.text = "Comme vous voudrez. Vous savez oם sont les tavernes si vous changez d'avis, mais je ne m'attarde pas.";
			link.l1 = "Adieu.";
			link.l1.go = "exit";
		break;
	}
}
