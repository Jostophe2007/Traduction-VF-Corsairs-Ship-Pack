// Gregg: диалоги квеста "Помощь святой инквизиции" (перенос из К:ПС).
// Стража за воротами Бас-Тера, Жаклин Дефо на Тортуге, Натан Рич на Бермудах.
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Oui ?";
			link.l1 = "Non.";
			link.l1.go = "exit";
		break;

		case "BasTer_Guardians_1":
			dialog.text = "Halte ! Vous êtes en état d'arrestation pour le meurtre de cet homme.";
			link.l1 = "Mais je ne l'ai pas tué !";
			link.l1.go = "BasTer_Guardians_2";
		break;

		case "BasTer_Guardians_2":
			AddDialogExitQuestFunction("HelpSacredInquisitionFightWithSoldAtExitBasTer");
			dialog.text = "Ne niez pas. Un habitant nous a lui-même dit que vous étiez sorti pour le tuer. Rendez vos armes et suivez-nous.";
			link.l1 = "Je ne crois pas.";
			link.l1.go = "exit";
		break;

		case "Jaklin_Defo_1":
			dialog.text = "Que voulez-vous, monsieur ?";
			link.l1 = "Vous êtes Jacqueline Defau ? L'épouse de François Defau ?";
			link.l1.go = "Jaklin_Defo_2";
		break;

		case "Jaklin_Defo_2":
			dialog.text = "Oui. Et vous, qui êtes-vous ?";
			link.l1 = "Une connaissance de votre mari.";
			link.l1.go = "Jaklin_Defo_3";
		break;

		case "Jaklin_Defo_3":
			dialog.text = "Pourquoi faites-vous cette tête ?..";
			link.l1 = "Toutes mes condoléances. Votre mari est mort.";
			link.l1.go = "Jaklin_Defo_4";
		break;

		case "Jaklin_Defo_4":
			dialog.text = "Comment ?!";
			link.l1 = "Il a été assassiné. Et je cherche le coupable.";
			link.l1.go = "Jaklin_Defo_5";
		break;

		case "Jaklin_Defo_5":
			dialog.text = "Je... Je ne sais pas. Revenez demain, j'ai besoin de me ressaisir.";
			link.l1 = "Je comprends, et j'en suis désolé. Mais la piste refroidit d'heure en heure, et demain, il n'en restera peut-être plus rien.";
			link.l1.go = "Jaklin_Defo_6";
		break;

		case "Jaklin_Defo_6":
			dialog.text = "...Il parlait d'une pierre. Avant de partir, il disait que nous serions riches à son retour. Je sentais que ça finirait mal.";
			link.l1 = "Qu'a-t-il dit exactement sur cette pierre ? Et a-t-il jamais prononcé le nom de Nathan Rich ?";
			link.l1.go = "Jaklin_Defo_7";
		break;

		case "Jaklin_Defo_7":
			dialog.text = "Oui. Il disait que Nathan était un ami. Sur la pierre, rien de tel.";
			link.l1 = "Oם peut-on trouver Nathan ?";
			link.l1.go = "Jaklin_Defo_8";
		break;

		case "Jaklin_Defo_8":
			NextDiag.TempNode = "Jaklin_Defo_9";
			AddDialogExitQuestFunction("HelpSacredInquisitionToBermudes");
			dialog.text = "Je ne sais pas. François a laissé échapper un jour qu'ils se retrouvaient souvent aux Bermudes. Promettez-moi que vous trouverez l'assassin !";
			link.l1 = "Je ferai tout ce que je pourrai.";
			link.l1.go = "exit";
		break;

		case "Jaklin_Defo_9":
			NextDiag.TempNode = "Jaklin_Defo_9";
			dialog.text = "Pardonnez-moi, je ne peux pas parler en ce moment.";
			link.l1 = "Oui, oui... Pardonnez-moi.";
			link.l1.go = "exit";
		break;

		case "Natan_Rich_1":
			SetCameraDialogMode(CharacterFromID("Natan Rich Guardian 1"));
			dialog.text = "Que se passe-t-il ici ?";
			link.l1 = "Rien, à part le bruit que vous avez fait.";
			link.l1.go = "Natan_Rich_2";
		break;

		case "Natan_Rich_2":
			SetCameraDialogMode(CharacterFromID("Natan Rich Guardian 2"));
			dialog.text = "C'était un accident, et Jake a déjà réglé les choses avec François.";
			link.l1 = "Tu laisses l'homme pour qui tu travailles réparer tes bêtises. Jake Smitt n'est pas un jouet. Tu joues avec le feu, l'ami.";
			link.l1.go = "Natan_Rich_3";
		break;

		case "Natan_Rich_3":
			SetCameraDialogMode(CharacterFromID("Natan Rich Guardian 1"));
			dialog.text = "Je comprends. J'espère que cette conversation restera entre nous. Et qui est ce Klein dont tu as parlé ?";
			link.l1 = "Un homme qui a des relations puissantes dans l'Ancien Monde, en Espagne. Ne gâche rien : nous avons grand besoin de lui. Il te reconnaîtra à ton amulette ; j'espère que tu l'as. Il attendra à la taverne ; si tu ne le trouves pas, demande au tavernier, il aura laissé un mot... Qu'est-ce que c'est que ce bruit ? Tu entends ?";
			link.l1.go = "Natan_Rich_4";
		break;

		case "Natan_Rich_4":
			SetCameraDialogMode(NPChar);
			AddDialogExitQuestFunction("HelpSacredInquisitionInBermudesFirstFight");
			dialog.text = "Nous avons de la visite ! Tuez-le !";
			link.l1 = "...";
			link.l1.go = "exit";
		break;

		case "Natan_Rich_5":
			dialog.text = "Et vous, qui êtes-vous ?! Que faites-vous ici ?!";
			link.l1 = "Capitaine " + GetFullName(pchar) + ". C'est la Sainte Inquisition qui m'envoie. Vous avez beaucoup péché.";
			link.l1.go = "Natan_Rich_6";
		break;

		case "Natan_Rich_6":
			dialog.text = "Bon sang... Je savais qu'ils finiraient par m'atteindre. Eh bien, faites ce pour quoi vous êtes venu.";
			link.l1 = "Nous avons le temps. Parlez-moi d'abord de cette pierre que vous recherchez tous.";
			link.l1.go = "Natan_Rich_7";
		break;

		case "Natan_Rich_7":
			dialog.text = "Très bien. Puisque vous m'avez trouvé... C'est la légende de la pierre de lune à la lumière fantomatique. Tout a commencé avec un fou qui est apparu aux Caraïbes en prétendant l'avoir vue. Il disait que la pierre donne à son détenteur le pouvoir de Dieu.";
			link.l1 = "דa, je le sais. Venez-en au fait.";
			link.l1.go = "Natan_Rich_8";
		break;

		case "Natan_Rich_8":
			dialog.text = "On dit que l'artefact appartenait aux Atlantes. Ils disposaient d'un grand pouvoir et n'ont pas su le maîtriser, et ils l'ont payé de leur vie. Nous nous sommes lancés dans les recherches quand le bruit a couru qu'un ancien ordre avait apporté la pierre ici il y a longtemps. Ses adeptes la gardent encore. Oם, nous ne le savons pas.";
			link.l1 = "Curieux. Et qui est Jake Smitt ?";
			link.l1.go = "Natan_Rich_9";
		break;

		case "Natan_Rich_9":
			AddDialogExitQuestFunction("HelpSacredInquisitionInBermudesFightWithRich");
			dialog.text = "דa, je ne vous le dirai pas. Vous en avez déjà trop appris, et vous mourrez avec.";
			link.l1 = "Hé...";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
