#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Oh, "+ GetSexPhrase("un nouveau capitaine", "une jeune fille") +" ! On dirait que c'est toi qui es "+ GetSexPhrase("sorti le dernier", "sortie la dernière") +" de cette tempête.";
					link.l1 = "Bonjour. Mon nom est " + pchar.name + ", " + GetFullName(pchar) + ". Avant cette maudite tempête, j'étais capitaine...";
					link.l1.go = "FT_1";
				}
				else
				{
					dialog.text = "Oh, "+ GetSexPhrase("un nouveau capitaine", "une jeune fille") +" ! On dirait que c'est toi "+ GetSexPhrase("le dernier arrivé", "la dernière arrivée") +".";
					link.l1 = "Bonjour. Mon nom est " + pchar.name + ", " + GetFullName(pchar) + ". Avant le naufrage, j'étais capitaine...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Tu voulais quelque chose de moi ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de quitter ces lieux avec moi pour le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FT_1":
			dialog.text = "Hum, tu sais, il me semble que ce nom me dit quelque chose. Capitaine... Bon, d'accord. Je suis Stefan Klein, un... habitant d'ici.";
			link.l1 = "Depuis combien de temps es-tu ici, Stefan ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "דa fait cinq ans, que Dieu me pardonne. Je m'y suis habitué, je me suis adapté : maintenant, je vis et je ne me plains même pas, j'accueille les nouveaux venus.";
			link.l1 = "Comment êtes-vous arrivée ici ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Oh, c'est une longue histoire, capitaine...";
			link.l1 = "Raconte, ça m'intéresse.";
			link.l1.go = "FT_4";
			link.l2 = "Hélas, je n'ai pas le temps pour les longues histoires.";
			link.l2.go = "exit";
		break;
		case "FT_4":
			dialog.text = "Bon, d'accord. Le galion Leader a quitté Belize avec une grosse cargaison de planches, de toile et d'acajou par un clair matin d'avril, mais vers midi, une tempête si terrible s'est levée que même notre intrépide capitaine – Dieu ait son âme – a renoncé à diriger le navire\n"+
				"J'ai nagé, nagé, nagé jusqu'à ce que le sang bouille dans mes veines et se change en acide... puis j'ai encore nagé un peu, mais bien sמr, je ne savais pas oם j'allais : c'étaient les vagues qui me guidaient\n"+
				"Quand j'ai vu cet endroit au loin, j'ai cru que c'était un mirage, mais ensuite, mes forces m'ont abandonné, et puis... et puis je me suis retrouvé ici.";
			link.l1 = "Tu as réussi à t'habituer facilement ?";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "C'était dur au début, bien sמr. Je pensais beaucoup à ceux qui sont morts ce jour-là... C'est dur d'être le seul survivant, n'est-ce pas ? Mais le temps guérit tout...";
			link.l1 = "Eh bien, merci pour la conversation, Stefan. C'était un plaisir de te rencontrer.";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Moi aussi, j'en suis très heureux, capitaine " + pchar.name + ".";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, pourquoi courez-vous partout comme d'Artagnan, en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Je vais essayer de redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Il y a souvent des tempêtes ici ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Dis, quel est cet endroit ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Que faites-vous ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l4 = "L'ami, tu vis sur cette île depuis longtemps ?";
				link.l4.go = "ansewer_4";
			}
			link.l10 = "Pas de questions. Désolé, l'ami...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Et désormais, c'est ici que tu habites, pour toujours. Bienvenue !";
			link.l1 = "Caramba !";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Et que doivent faire des gens confinés dans un petit espace, capitaine ? Nous existons.";
			link.l1 = "Une occupation intéressante, je trouve. Il faudra que j'essaie.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "דa arrive, mais souvent ou pas, difficile à dire. Pour certains, c'est souvent, pour d'autres, non...";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Pour ceux qui n'aiment pas les tempêtes, c'est souvent. Et pour ceux à qui ça est égal... eh bien, tu vois.";
			link.l1 = "Oui, c'est clair maintenant.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Eh bien, oui, depuis assez longtemps. Deux ans, il me semble...";
			link.l1 = "דa alors ! Feu Hill Brunner était-il déjà dans la Cité quand tu es arrivé ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Il y était, bien sמr.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Quelles marchandises ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de boulets, de bombes, de boulets ramés, de vivres, de médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Les vivres, tu peux les acheter à la boutique, je suppose. Mais pour les médicaments, tu peux t'adresser au saint père.";
			link.l1 = "א notre prêtre ?";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Bien sמr, il n'y en a pas d'autre ici. Il ne soigne pas que les âmes des paroissiens...";
			link.l1 = "Merci, l'ami.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Euh, je ne sais même pas quoi dire...";
			link.l1 ="Oui ou non ?";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Tu sais, je me suis déjà attaché à la Cité, ce serait dommage de partir d'ici...";
			link.l1 = "Si tu ne pars pas avec moi, tu mourras. La tempête qui approche va forcément détruire la Cité.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Vous êtes sמr ?";
			link.l1 = "Oui. C'est le Mécanicien qui l'a dit.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Bon sang, je crois le Mécanicien... Bon, dans ce cas, j'accepte.";
			link.l1 = "Tu as pris la bonne décision, félicitations. Maintenant, va tout de suite sur le San Gabriel. Le Mécanicien te fera passer sur mon navire.";
			link.l1.go = "SeekCrew_4";
		break;
		case "SeekCrew_4":
			dialog.text = "D'accord. Je rassemble juste mes affaires.";
			link.l1 = "Seulement, fais vite. Ne t'attarde nulle part !";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
