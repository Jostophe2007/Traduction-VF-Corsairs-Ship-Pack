// строковая дата, день_мес
string LastSpeakDate()
{
    return environment.date.day + " " + environment.date.month;
}
// Для диалогов НПС -->
string GetNPCQuestDate(ref npchar, string _type)
{
    if (!CheckAttribute(npchar, "QuestDate." + _type))
    {
        npchar.QuestDate.(_type) = "";
    }
    return npchar.QuestDate.(_type);
}
void SetNPCQuestDate(ref npchar, string _type)
{
    npchar.QuestDate.(_type) = LastSpeakDate();
}
bool CheckNPCQuestDate(ref npchar, string _type)
{
    if (GetNPCQuestDate(npchar, _type) != LastSpeakDate())
    {
        return true;
    }
    return false;
}
// Для ГГ <--
void SaveCurrentQuestDateParam(string _quest)
{ // запись даты получения квеста
    aref  arQ;
    makearef(arQ, PChar.(_quest));

    arQ.control_day = GetDataDay();
    arQ.control_month = GetDataMonth();
    arQ.control_year = GetDataYear();
    arQ.control_time = GetTime();
}
int GetQuestPastMonthParam(string _quest)
{
    aref  arQ;
    makearef(arQ, PChar.(_quest));

    return GetPastTime("month", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), stf(arQ.control_time),GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
}
int GetQuestPastDayParam(string _quest)
{
    aref  arQ;
    makearef(arQ, PChar.(_quest));
    if (CheckAttribute(PChar, _quest + ".control_year"))
    {
    	return GetPastTime("day", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), stf(arQ.control_time),GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
	}
	return 0;
}
int GetQuestPastTimeParam(string _quest)
{
    aref  arQ;
    makearef(arQ, PChar.(_quest));
    if (CheckAttribute(PChar, _quest + ".control_year"))
    {
    	return GetPastTime("hour", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), stf(arQ.control_time), GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
	}
	return 0;
}
//navy -->
//Ввел ещё одну функцию, т.к. нужны прошедшие минуты.
int GetQuestPastMinutesParam(string _quest)
{
    aref  arQ;
    makearef(arQ, PChar.(_quest));
    if (CheckAttribute(PChar, _quest + ".control_year"))
    {
    	return GetPastTime("minute", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), stf(arQ.control_time), GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
	}
	return 0;
}
//navy <--

// eddy
// ************* для неписей.
void SaveCurrentNpcQuestDateParam(ref _character, string _quest)
{ // запись даты получения квеста
    aref  arQ;
    makearef(arQ, _character.(_quest));

    arQ.control_day = GetDataDay();
    arQ.control_month = GetDataMonth();
    arQ.control_year = GetDataYear();
    arQ.control_time = GetTime();
}

int GetNpcQuestPastDayParam(ref _character, string _quest)
{
    aref  arQ;
    makearef(arQ, _character.(_quest));
    if (CheckAttribute(_character, _quest + ".control_year"))
    {
        return GetPastTime("day", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), 0,GetDataYear(), GetDataMonth(), GetDataDay(), 0);
    }
    else {return 0;}
}

int GetNpcQuestPastDayWOInit(ref _character, string _quest)
{
    aref  arQ;
    makearef(arQ, _character.(_quest));
    if (CheckAttribute(_character, _quest + ".control_year"))
    {
        return GetPastTime("day", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), 0,GetDataYear(), GetDataMonth(), GetDataDay(), 0);
    }
    else {return 1000;}  // если нет ветки, то это значит черти когда было дело
}

int GetNpcQuestPastTimeParam(ref _character, string _quest)
{
    aref  arQ;
    makearef(arQ, _character.(_quest));
    if (CheckAttribute(_character, _quest + ".control_year"))
    {
    	return GetPastTime("hour", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), sti(arQ.control_time), GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
	}
	return 0;
}
int GetNpcQuestPastMinutesParam(ref _character, string _quest)
{
    aref  arQ;
    makearef(arQ, _character.(_quest));
    if (CheckAttribute(_character, _quest + ".control_year"))
    {
    	return GetPastTime("minute", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), stf(arQ.control_time), GetDataYear(), GetDataMonth(), GetDataDay(), GetTime());
	}
	return 0;
}

int GetNpcQuestPastMonthParam(ref _character, string _quest)
{
    aref  arQ;
    makearef(arQ, _character.(_quest));
    if (CheckAttribute(_character, _quest + ".control_year"))
    {
        return GetPastTime("month", sti(arQ.control_year), sti(arQ.control_month), sti(arQ.control_day), 0,GetDataYear(), GetDataMonth(), GetDataDay(), 0);
    }
    else {return 0;}
}
// Поместить непися в компаньоны и тут же отправить его на выход из текущей локации.
void CharacterIntoCompanionAndGoOut(ref _mainCharacter, ref _compCharacter, string _group, string _locator, int _timeToGoOut, bool _compRemove)
{
    if (!bDisableFastReload) //чтобы не снимать запрет, если он установлен другим методом
	{
		bDisableFastReload = true;
		_mainCharacter.GenQuest.CallFunctionParam.CharacterIntoCompanion.FastReload = true;
	}
	if (_group == "")    {_group = "reload";}
    if (_locator == "")
    {
    	float locx, locy, locz;
        GetCharacterPos(_compCharacter, &locx, &locy, &locz);
        _locator = LAi_FindNearestFreeLocator(_group, locx, locy, locz);
    }
    LAi_ActorGoToLocation(_compCharacter, _group, _locator, "none", "", "", "", _timeToGoOut);
    _mainCharacter.GenQuest.CallFunctionParam = "Character_into_companion";
    _mainCharacter.GenQuest.CallFunctionParam.CharacterIntoCompanion.Id = _compCharacter.id;
    _mainCharacter.GenQuest.CallFunctionParam.CharacterIntoCompanion.Remove = _compRemove;
    DoQuestCheckDelay("CallFunctionParam", _timeToGoOut);
}

void Character_into_companion()    // относится к методу выше.
{
    ref NPChar = characterFromID(PChar.GenQuest.CallFunctionParam.CharacterIntoCompanion.Id);
    SetCompanionIndex(pchar, -1, getcharacterIndex(PChar.GenQuest.CallFunctionParam.CharacterIntoCompanion.Id));
    if (PChar.GenQuest.CallFunctionParam.CharacterIntoCompanion.Remove == false)    {SetCharacterRemovable(npchar, false);}
	//снимать запрет, только если он установлен этим методом
	if (CheckAttribute(PChar, "GenQuest.CallFunctionParam.CharacterIntoCompanion.FastReload")) bDisableFastReload = false;
}

string GetBookData(int day, int mn, int year)
{
	string result = "";

	if (day < 10)
	{
	    result = result + "0";
	}
	result = result + day + ".";
	if (mn < 10)
	{
	    result = result + "0";
	}
	result = result + mn + "." + year;

    return result;
}

// ========>>>>>> квест Аззи, подсчет контрольных сумм по неуязвимости =================
void AzzyCheckSumControl()
{
    int   QtyKilled, Result;
    float CurHP, MaxHP;

	if (CheckAttribute(pchar, "questTemp.Azzy.Immortal"))
    {
        QtyKilled = Statistic_AddValue(pchar, "Solder_s", 0) +
                    Statistic_AddValue(pchar, "Solder_g", 0) +
                    Statistic_AddValue(pchar, "Warrior_s", 0) +
                    Statistic_AddValue(pchar, "Warrior_g", 0) +
                    Statistic_AddValue(pchar, "Citizen_s", 0) +
                    Statistic_AddValue(pchar, "Citizen_g", 0) +
                    Statistic_AddValue(pchar, "Monster_s", 0) +
                    Statistic_AddValue(pchar, "Monster_g", 0) -
                    sti(pchar.questTemp.Azzy.Immortal.EarlyKilled);
        pchar.questTemp.Azzy.Immortal.AllQuota = makeint(pchar.questTemp.Azzy.Immortal.AllQuota) + sti(pchar.questTemp.Azzy.Immortal.DayQuota);
        Result = QtyKilled - sti(pchar.questTemp.Azzy.Immortal.AllQuota);
        if (Result < 0)
        {
            MaxHP = LAi_GetCharacterMaxHP(pchar);
            CurHP = LAi_GetCharacterHP(pchar);
            MaxHP = MaxHP - 5;
            pchar.questTemp.Azzy.Immortal.Penalty = makeint(pchar.questTemp.Azzy.Immortal.Penalty) + 5;
            if (!CheckAttribute(pchar, "questTemp.Azzy.OK"))
            {
                pchar.questTemp.Azzy = "HowToKnowAzzy";
                pchar.questTemp.Azzy.OK = 1;
            }
            if (MaxHP < 1)
            {
                LAi_KillCharacter(pchar);
                Log_SetStringToLog(GetConvertStrWithReplace("Variable_QuestsUtilite_1", "Logs.txt", "#space#", " "));
            }
            else
            {
                Log_SetStringToLog(GetConvertStrWithReplace("Variable_QuestsUtilite_2", "Logs.txt", "#space#", " "));
            }
            LAi_SetHP(pchar, CurHP, MaxHP);
        }
        if (GetQuestPastDayParam("questTemp.Azzy.Immortal") > 30)
        {
            pchar.questTemp.Azzy.Immortal.DayQuota = makeint(pchar.questTemp.Azzy.Immortal.DayQuota) * 2;
            SaveCurrentQuestDateParam("questTemp.Azzy.Immortal");
        }
        pchar.questTemp.Azzy.Immortal.CurKilled = QtyKilled;
        pchar.questTemp.Azzy.Immortal.CurBalance = Result;
        DeleteQuestHeader("Azzy_HellSign");
		if (sti(pchar.questTemp.Azzy.Immortal.Penalty) > 0)
		{
			AddQuestRecord("Azzy_HellSign", "2");
			AddQuestUserData("Azzy_HellSign", "Penalty", pchar.questTemp.Azzy.Immortal.Penalty);
		}
		AddQuestRecord("Azzy_HellSign", "1");
		AddQuestUserData("Azzy_HellSign", "sName", GetMainCharacterNameGen());
		AddQuestUserData("Azzy_HellSign", "DayQuota", pchar.questTemp.Azzy.Immortal.DayQuota);
		AddQuestUserData("Azzy_HellSign", "AllQuota", pchar.questTemp.Azzy.Immortal.AllQuota);
		AddQuestUserData("Azzy_HellSign", "CurKilled", pchar.questTemp.Azzy.Immortal.CurKilled);
		AddQuestUserData("Azzy_HellSign", "CurBalance", pchar.questTemp.Azzy.Immortal.CurBalance);
    }
}
// <<<<<======== квест Аззи, подсчет контрольныйх сумм по неуязвимости =================

// репутация плохого парня с границами
bool isBadReputation(ref _pchar, int _rep)
{
    if (GetCharacterPerkUsing(_pchar, "Trustworthy") || sti(_pchar.reputation) >= _rep)
    {
        return false;// good guy
    }
    return true;// bad guy
}

// --> ugeen  - генерация карт островов в сундуке каюты во время абордажа   07.07.09
void FillCabinBoxMap(ref _location, int _probability)
{
	int 	i;
	string  itemID, groupID;
    ref     itm;

	for (i=0; i<ITEMS_QUANTITY; i++)
	{
		makeref(itm,Items[i]);
		if(CheckAttribute(itm, "ID") && CheckAttribute(itm, "groupID"))
		{
			itemID = itm.id;
			groupID = itm.groupID;
			if(groupID == MAPS_ITEM_TYPE && !CheckAttribute(itm, "mapSpecial") && (itemID != "Map_Best") && (itemID != "Map_LSC"))
			{
				if(rand(_probability) == 1)
				{
					_location.box1.items.(itemID) = 1;
					return;
				}
			}
		}
	}
}
//<-- ugeen

//ugeen --> заполнить сундук в трюме квестовым барахлом
void FillQuestHoldBox(ref _location)
{
	_location.box1 = Items_MakeTime(GetTime(), GetDataDay(), GetDataMonth(), GetDataYear()); // нужно, чтоб не перетерлось

	int nShipType = sti(pchar.ship.type);

	if(CheckAttribute(pchar,"GenQuest.CaptainComission.CanFindChest"))
	{
		if(nShipType == sti(pchar.GenQuest.CaptainComission.ShipType) && !CheckAttribute(pchar,"GenQuest.CaptainComission.Treasure"))
		{
			Log_QuestInfo(GetConvertStrWithReplace("Variable_QuestsUtilite_3", "Logs.txt", "#space#", " "));
			DeleteAttribute(_location, "box1");
			_location.box1.items.chest = 3;
			pchar.GenQuest.CaptainComission.Treasure = true;
		}
	}
}
// <-- ugeen
// заполнить сундук каюты во время абордажа
void FillAboardCabinBox(ref _location, ref _npchar)
{
    int     iTemp;
    bool    ok;
	float   nLuck;
	int 	iNation;
	int     iRnd;
	_location.box1 = Items_MakeTime(GetTime(), GetDataDay(), GetDataMonth(), GetDataYear());// нужно, чтоб не перетерлось
	// нужно отметить, что в сундуке сгенерятся рандомные вещи, этот код срабатывает потом и правит токо деньги
	ok = true;
	// заготовка под квест
	if (_npchar.id == "GhostCapt" && CheckAttribute(pchar , "GenQuest.GhostShip.LastBattle"))
	{
        // трем все в сундуке
        DeleteAttribute(_location, "box1");
        // кладем супер хрень
        _location.box1.items.indian11 = 1;
        _location.box1.money = 66666;
		//Добавить Иону
		if (!CheckAttribute(pchar , "questTemp.IonaGathered"))
		{
			 _location.box1.items.talisman2 = 1;
		}
        ok = false;
	}
	if (HasSubStr(_npchar.id,"Hunter01") && rand(9)==0 && !CheckAttribute(pchar,"BermudesSurprise"))
	{
		_location.box1.items.letter_notes = 1;
		ChangeItemDescribe("letter_notes", "CSPD1");
		pchar.BermudesSurprise = 1;
	}
	// пасхалка Кукурузина
	// маленькая пасхалка от меня -> ugeen  17.06.09

	if (CheckAttribute(_npchar, "Ship.Name"))
	{
		if (_npchar.Ship.Name == "Колесо Фортуны" || _npchar.Ship.Name == "Wheel of Fortune")
		{
			DeleteAttribute(_location, "box1");
			if(drand(100) > 85)
			{
				if(rand(1) == 0) { _location.box1.items.jewelry1 = rand(1500) + 461; }
				if(rand(1) == 0) { _location.box1.items.jewelry2 = rand(800) + 1214; }
				if(rand(1) == 0) { _location.box1.items.jewelry3 = rand(2210) + 750; }
				if(rand(1) == 0) { _location.box1.items.jewelry4 = rand(3450) + 280; }
				if(rand(1) == 0) { _location.box1.items.jewelry5 = rand(2471) + 370; }
				iRnd = drand1(4);
				switch (iRnd)
				{
					case 0:
						_location.box1.items.indian18 = 1;
					break;
					case 1:
						_location.box1.items.indian21 = 1;
					break;
					case 2:
						_location.box1.items.indian20 = 1;
					break;
					case 3:
						_location.box1.items.indian11 = 1;
					break;
					case 4:
						_location.box1.items.indian6 = 1;
					break;
				}
			}
			else
			{
				if(rand(1) == 0) { _location.box1.items.mineral4 = rand(118) + 85; }
				_location.box1.items.mineral5 = rand(78) + 115;
				if(rand(1) == 0) { _location.box1.items.mineral8 = rand(86) + 44; }
				_location.box1.items.indian2 = rand(146) + 131;
			}
			_location.box1.money = 12560 + rand(1000);
			ok = false;
		}
	}
	// квест №4, англ., боевка с голландским бригом
	if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.EngLineQ4_PutLetter"))
	{
        DeleteAttribute(_location, "box1");
        ChangeItemDescribe("letter_1", "itmdescr_letter_1_EngLineQ4");
        _location.box1.items.letter_1 = 1;
        _location.box1.money = 7460;
        _location.box1.items.map_Curacao = 1;
        ok = false;
	}
	// квест №6, англ., боевка с испанским пинасом
	if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.EngLineQ6_PutMoney"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 140000;
        _location.box1.items.map_cumana = 1;
        _location.box1.items.spyglass3 = 1;
        _location.box1.items.potion4 = 10;
        _location.box1.items.indian7 = 1;
        ok = false;
	}
    // квест №8, англ., боевка с испанским галеоном
    if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.ELQ8_PutLetter"))
	{
        DeleteAttribute(_location, "box1");
        ChangeItemDescribe("letter_2", "itmdescr_letter_2_EngLineQ8");
        _location.box1.items.letter_2 = 1;
        _location.box1.money = 2203;
        _location.box1.items.map_cuba = 1;
        _location.box1.items.spyglass2 = 1;
        _location.box1.items.potion2 = 7;
        _location.box1.items.potionwine = 2;
        ok = false;
	}
    // квест №9, англ., боевка с Пардалем
    if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.ELQ9_Diffrent"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 853000;
        _location.box1.items.blade28 = 1;
        _location.box1.items.pistol6 = 1;
        _location.box1.items.pistol4 = 1;
        _location.box1.items.potion4 = 10;
        _location.box1.items.chest = 1;
        _location.box1.items.icollection = 1;
        _location.box1.items.map_cuba = 1;
        _location.box1.items.jewelry4 = 25;
        _location.box1.items.cirass4 = 1;
        ok = false;
	}
    // квест №7, испанка , выручаем Пардаля, сундук кэпа флибустьеров
    if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.SLQ7_Diffrent"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 753400;
        _location.box1.items.blade28 = 1;
        _location.box1.items.pistol6 = 1;
        _location.box1.items.pistol4 = 1;
        _location.box1.items.potion2 = 10;
        _location.box1.items.potionwine = 1;
        _location.box1.items.jewelry4 = 25;
        _location.box1.items.cirass4 = 1;
		_location.box1.items.cirass3 = 1;
        ok = false;
	}
    // квест №8, испанка , защищаем Куману, сундук кэпа флибустьеров
    if (_npchar.id == "CaptainAttack_1" && CheckAttribute(PChar, "questTemp.SLQ8_Diffrent"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 996400;
        _location.box1.items.spyglass4 = 1;
        _location.box1.items.potionrum = 2;
        _location.box1.items.pistol4 = 5;
        _location.box1.items.potion3 = 11;
        _location.box1.items.chest = 1;
        _location.box1.items.icollection = 1;
        _location.box1.items.jewelry5 = 50;
		_location.box1.items.indian13 = 1;
        ok = false;
	}
	// квест Аскольда.
	if (CheckAttribute(PChar, "questTemp.Ascold.Ship"))
	{
        if (_npchar.id == pchar.questTemp.Ascold.Ship)
        {
			pchar.questTemp.Ascold.Ship.foundcheck = true;
            DeleteAttribute(_location, "box1");
            _location.box1.items.ShipsJournal = 1;
            ok = false;
        }
	}
	// Осады  homo 22/10/06
	if (findsubstr(_npchar.id, "SiegeCap_" , 0) != -1)
	{
	    aref aData, itm;
	    makearef(aData, NullCharacter.Siege);
	    string sGroup = "Sea_"+NationShortName(sti(aData.nation))+"SiegeCap_1";
	    ref rchar = Group_GetGroupCommander(sGroup);  //поиск текущего командера, он меняется от убиеня
	    Log_TestInfo( _npchar.id +" == "+ rchar.id);
		if (_npchar.id == rchar.id && CheckAttribute(aData, "loot"))
		{
	        DeleteAttribute(_location, "box1");
	        _location.box1.money = sti(aData.loot);
	        _location.box1.items.potionrum = 3;
	        _location.box1.items.potionwine = 1;
	        _location.box1.items.Food1 = rand(2);
	        _location.box1.items.Food2 = rand(2);
	        _location.box1.items.Food3 = rand(2);
	        _location.box1.items.Food4 = rand(2);
	        string idmap = "map_"+aData.island;
            if (Items_FindItem(idmap, &itm) != -1)
            {
                _location.box1.items.(idmap) = 1;
            }

	        ok = false;
		}
	}
	//homo =>
    if (findsubstr(_npchar.id, "_QuestMerchant" , 0) != -1)
    {
        if (trap)
        {
            DeleteAttribute(_location, "box1");
            _location.box1.money = (cRand(30)+1) * 40;
            _location.box1.items.blade31 = 1;
            ok = false;
        }
    }

    if (_npchar.id == "Head_of_Gold_Squadron" )
    {

        DeleteAttribute(_location, "box2");
        _location.box2.money = 2212;
        _location.box2.items.map_normal = 1;
        ok = false;

    }
    //homo <=
    // пиратка, квест №7. драгоценности в каюту
    if (_npchar.id == "QuestCap_PL7")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 3983;
        _location.box1.items.jewelry1 = 763;
        _location.box1.items.jewelry2 = 562;
        _location.box1.items.jewelry3 = 1771;
        _location.box1.items.jewelry4 = 678;
        _location.box1.items.jewelry6 = 236;
        _location.box1.items.jewelry7 = 321;
        _location.box1.items.jewelry14 = 121;
		_location.box1.items.jewelry15 = 45;
		_location.box1.items.jewelry18 = 311;
        ok = false;
	}
    // пиратка, квест №7. драгоценности в каюту
    if (_npchar.id == "MushketCap")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 103;
		_location.box1.items.mushket2x2 = 1;
		//Пернатый Змей
		_location.box1.items.talisman1 = 1;
        ok = false;
	}
	 if (_npchar.id == "BlackBeardNPC" && CheckAttribute(pchar, "Titch_seabattle"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 500000;
		_location.box1.items.blackbeard_sword = 1;
		_location.box1.items.howdah = 1;
		_location.box1.items.spyglass5 = 1;
		_location.box1.items.cirass5 = 1;
        ok = false;
	}
	//работорговец, 2 эпизод
	if (_npchar.id == "CaptainSlaveAttack_2" && CheckAttribute(PChar, "questTemp.Slavetrader"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 20000;
		_location.box1.items.statue1 = 1;
        ok = false;
	}
	//работорговец, письмо, 4 эпизод
	if (_npchar.id == "CapBrigAttack" && CheckAttribute(PChar, "questTemp.Slavetrader"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 5500;
		_location.box1.items.letter_1 = 1;
        ok = false;
	}
	//работорговец, линкор
	if (_npchar.id == "GaleonCap" && CheckAttribute(PChar, "questTemp.Slavetrader"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 2350;
		_location.box1.items.jewelry5 = 1000;
		_location.box1.items.indian15 = 1;
		_location.box1.items.indian8 = 528;
		_location.box1.items.indian9 = 9;
		_location.box1.items.indian2 = 3;
		_location.box1.items.indian14 = 16;
		_location.box1.items.indian5 = 2;
		_location.box1.items.indian16 = 114;
		_location.box1.items.indian13 = 58;
		_location.box1.items.indian12 = 1;
		_location.box1.items.indian1 = 1;
        ok = false;
	}

	//малява курьер
	if (_npchar.id == "CureerAttack")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 1000;
        _location.box1.items.jewelry1 = 50+rand(200);
        _location.box1.items.jewelry2 = 50+rand(100);
        _location.box1.items.jewelry3 = 50+rand(100);
        _location.box1.items.jewelry4 = 50+rand(100);
        _location.box1.items.jewelry6 = 50+rand(80);
        _location.box1.items.jewelry7 = 50+rand(100);
		_location.box1.items.jewelry10 = 50+rand(160);
        _location.box1.items.jewelry14 = 50+rand(150);
		_location.box1.items.jewelry15 = rand(40);
		_location.box1.items.jewelry18 = rand(200);
		DeleteAttribute(_location, "box2");
		iRnd = rand(5);
			switch (iRnd)
			{
				case 0:
					_location.box2.items.cirass4 = 1;
				break;
				case 1:
					_location.box2.items.spyglass4 = 1;
				break;
				case 2:
					_location.box2.items.pistol5 = 1;
				break;
				case 3:
					_location.box2.items.blade34 = 1;
				break;
				case 4:
					_location.box2.items.blade19 = 1;
				break;
				case 5:
					_location.box2.items.pistol4 = 1;
				break;
			}
        ok = false;
	}
	//ОЗГ, пинас Крысы, драгоценности
	if (_npchar.id == "RatCaptain" && CheckAttribute(PChar, "questTemp.Headhunter"))
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 21500;
		_location.box1.items.icollection = rand(2);
		_location.box1.items.jewelry1 = 20+rand(20);
        _location.box1.items.jewelry2 = 20+rand(20);
        _location.box1.items.jewelry3 = 30+rand(20);
        _location.box1.items.jewelry4 = 10+rand(10);
        _location.box1.items.jewelry6 = rand(50);
        _location.box1.items.jewelry7 = rand(100);
		_location.box1.items.jewelry10 = rand(50);
        _location.box1.items.jewelry14 = rand(50);
		_location.box1.items.jewelry15 = rand(10);
		_location.box1.items.jewelry18 = rand(100);
        ok = false;
	}
	//Молот Тора + всякое на Нормандии
	if (_npchar.id == "zpqCaptain")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 25000;
        ok = false;
	}
	if(_npchar.id == "Flint")
	{
		_location.box1.items.icollection = 3 + drand(5);
		_location.box1.items.indian1 = 1;
		_location.box1.items.indian7 = 1;
		_location.box1.items.chest = 5 + drand(10);
		_location.box1.items.jewelry1 = 40+drand(5);
		_location.box1.items.jewelry2 = 40+drand(5);
		_location.box1.items.jewelry3 = 40+drand(5);
		_location.box1.items.jewelry4 = 31+drand(5);
		_location.box1.items.jewelry6 = drand(50);
		_location.box1.items.jewelry7 = drand(100);
		_location.box1.items.jewelry10 = drand(50);
		_location.box1.items.jewelry14 = drand(50);
		_location.box1.items.jewelry15 = drand(10);
		_location.box1.items.jewelry18 = drand(100);
		_location.box1.money = 5000000;
		ok = false;
	}
	//Квест "Золото не тонет", английский галеон у Доминики, драгоценности
	if (_npchar.id == "PDM_Lesopilka_Galeon")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 10000;
		_location.box1.items.jewelry1 = 20+rand(10);
        _location.box1.items.jewelry2 = 20+rand(10);
        _location.box1.items.jewelry3 = 30+rand(10);
        _location.box1.items.jewelry4 = 30+rand(10);
        _location.box1.items.jewelry5 = rand(80);
		_location.box1.items.PDM_SJ_Angl_Gal = 1);
        ok = false;
	}
	//Квест "Лиларкор", в корабле лежит Лиларкор
	if (_npchar.id == "UP_Korabl_s_klinkom")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 12000;
		_location.box1.items.jewelry1 = 5+rand(10);
        _location.box1.items.jewelry3 = 5+rand(10);
        _location.box1.items.jewelry4 = 5+rand(10);
		_location.box1.items.cirass1 = 1);
		_location.box1.items.Lilarcor_Sword1 = 1);
        ok = false;
	}
	//Квест "Странные вещи творятся на архипелаге", Мефисто, драгоценности
	if (_npchar.id == "Chernoe_Solntse2")
	{
        DeleteAttribute(_location, "box1");
        _location.box1.money = 10000;
		_location.box1.items.jewelry5 = 100+rand(20);
        _location.box1.items.jewelry17 = 100+rand(20);
        _location.box1.items.jewelry3 = 40+rand(10);
		_location.box1.items.jewelry18 = 15+rand(10);
		_location.box1.items.blade44 = 1;
		_location.box1.items.PKM_SvtvA_amulet = 1;
        ok = false;
	}
	// СФ
	if (CheckAttribute(PChar, "questTemp.silverfleet") && pchar.questTemp.silverfleet == "ThirdSilverFleet")
	{
		if (CheckAttribute(_npchar, "SilverSurferCap"))
		{
			DeleteAttribute(_location, "box1");
			_location.box1.money = 800 + drand(200);
			_location.box1.items.rabble = 1;
			_location.box1.items.jewelry7 = 1 + drand(2);
			_location.box1.items.potionrum = 1 + drand(1);
			_location.box1.items.book4_12 = 1;
			_location.box1.items.mineral6 = 1;
			ok = false;
		}
	}
	if (CheckAttribute(_npchar, "sftresureship"))
	{
		int sfshipclass = GetCharacterShipClass(_npchar);
		DeleteAttribute(_location, "box1");
		_location.box1.money = 50000 + makeint(drand(500000)/sfshipclass);
		_location.box1.items.Chest = 1 + drand(5-sfshipclass);
		_location.box1.items.jewelry17 = 15 + makeint(drand(100)/sfshipclass);
		_location.box1.items.jewelry5 = 3 + makeint(drand(20)/sfshipclass);
		_location.box1.items.jewelry1 = 10 + makeint(drand(80)/sfshipclass);
    		_location.box1.items.jewelry2 = 3 + makeint(drand(50)/sfshipclass);
    		_location.box1.items.jewelry3 = 7 + makeint(drand(65)/sfshipclass);
    		_location.box1.items.jewelry4 = 1 + makeint(drand(30)/sfshipclass);
		ok = false;
	}

    if (ok) // не квестовый
    {
    	// код для всех

		// Warship 02.07.09 Это прикол такой - можно у случайного кэпа в сундуке обраружить ключ от сундуков Моргана
		// Причем, сундуков у Моргана два, а открыть получится только один из них
		if(!CheckAttribute(PChar, "QuestTemp.MorganKeyTaken") && rand(250-(sti(pchar.rank) * 3)) == 5 && sti(pchar.rank)>10)
		{
			PChar.QuestTemp.MorganKeyTaken = true;
			_location.box1.items.keyMorgan = 1;
			Log_TestInfo(GetConvertStrWithReplace("Variable_QuestsUtilite_4", "Logs.txt", "#space#", " "));
		}

		if(startherotype == 2 && !CheckCharacterItem(pchar,"glasses") && drand(100) < 25)
		{
			_location.box1.items.glasses = 1;
		}

		if(rand(50) == 0)
		{
			switch (rand(3))
			{
				case 0: _location.box1.items.Chest_ammo = 1; break;
				case 1: _location.box1.items.Chest_treasure = 1; break;
				case 2: _location.box1.items.Chest_quest = 1; break;
				case 3: _location.box1.items.Chest_Craftsmans = 1; break;
			}
			Log_TestInfo("xzibit");
		}
		if(rand(100) < 2)//Книги - Gregg
		{
			string book = GetRandomBookbyTier(2);
			if (CheckForBookReady(book)) book = RegenerateBook(2);
			_location.box1.items.(book) = 1;
			Log_TestInfo("bookgen");
		}

		if(rand(99) == 1)
		{
			_location.box1.items.mushket_SeaCarbine = 1;
		}
    	iTemp = GetCharacterShipClass(_npchar);
		iNation = sti(_npchar.nation);

		if(iNation == PIRATE)
		{
			nLuck   = GetCharacterSkillToOld(Pchar, SKILL_FORTUNE);
			if (nLuck > rand(250) && GetCharacterItem(pchar, "map_full") == 0)  // шанс 1/30
			{
				if (GetCharacterItem(pchar, "map_part1") == 0)
				{
					_location.box1.items.map_part1 = 1;
				}
				else
				{
					if (GetCharacterItem(pchar, "map_part2") == 0)
					{
						_location.box1.items.map_part2 = 1;
					}
				}
			}
			FillCabinBoxMap(_location, 200 - (7 - iTemp) * 5);
		}
		else
		{
			FillCabinBoxMap(_location, 250 - (7 - iTemp) * 5);
		}

		if (CheckAttribute(_npchar, "Ship.Mode") && _npchar.Ship.Mode == "Trade")  // торговец
		{
			_location.box1.money = (10 - iTemp) * 200 + rand(10 - iTemp) * 2000 + rand(10)*50 + rand(6 - iTemp) * 4000;
		}
		else // все остальные
		{
			_location.box1.money = (10 - iTemp) * 90 + rand((10 - iTemp) * 2000);
		}
		//Контркурьер, губерский генер
		if (_npchar.id == "ContraCureerCap" && CheckAttribute(PChar, "GenQuest.TakePostcureer"))
		{
			DeleteAttribute(_location, "box1");
			_location.box1.money = rand(10000);
			_location.box1.items.chest = drand(2);
			_location.box1.items.sicretLetter = 1;
			ok = false;
		}
		if (_npchar.id == "ContraPassCap" && CheckAttribute(PChar, "GenQuest.TakePassenger"))
		{	
			DeleteAttribute(_location, "box1");
			_location.box1.money = rand(5000);
			_location.box1.items.chest = drand(1);
			ok = false;
		}
    }
}

// ugeen --> вычисление ранга квестовых проитвников в зависимости от ранга ГГ и уровня сложности
int SetQuestCharacterRank()
{
	int rank = 25 + makeint(sti(pchar.rank)*(0.1 + MOD_SKILL_ENEMY_RATE*3));

	return rank;
}
// <-- ugeen

// ==> две функции Эдди для крутизны невероятной.
void FantomMakeCoolSailor(ref _Character, int _ShipType, string _ShipName, int _CannonsType, int _Sailing, int _Accuracy, int _Cannons)
{
    _Character.Ship.Cannons.Type = _CannonsType;
	_Character.skill.Sailing  = GetCoffDiffSkill(_Sailing, SKILL_MAX);
	_Character.skill.Accuracy = GetCoffDiffSkill(_Accuracy, SKILL_MAX);
	_Character.skill.Cannons  = GetCoffDiffSkill(_Cannons, SKILL_MAX);

    _Character.DontRansackCaptain = true; //квестовые не сдаются
    _Character.SinkTenPercent     = false; // не тонуть при 10 процентах, не убегать в бою
    _Character.AboardToFinalDeck  = true; // абордаж всегда
	_Character.DontClearDead      = true;
	_Character.SaveItemsForDead   = true;
	_Character.AlwaysSandbankManeuver = true;

    _Character.Ship.Type = GenerateShipExt(_ShipType, true, _Character);
    if (_ShipName == "none" || _ShipName == "") {SetRandomNameToShip(_Character)}
    else {_Character.Ship.Name = _ShipName}

    SetBaseShipData(_Character);
    SetCrewQuantityFull(_Character);
    Fantom_SetBalls(_Character, "pirate");

	SetCharacterPerk(_Character, "FastReload");
	SetCharacterPerk(_Character, "HullDamageUp");
	SetCharacterPerk(_Character, "SailsDamageUp");
	SetCharacterPerk(_Character, "CrewDamageUp");
	SetCharacterPerk(_Character, "CriticalShoot");
	SetCharacterPerk(_Character, "LongRangeShoot");
	SetCharacterPerk(_Character, "CannonProfessional");
	SetCharacterPerk(_Character, "ShipDefenseProfessional");
	SetCharacterPerk(_Character, "ShipSpeedUp");
	SetCharacterPerk(_Character, "ShipTurnRateUp");

    DeleteAttribute(_Character, "ship.sails");// убрать дыры на парусах
    DeleteAttribute(_Character, "ship.blots");
    RepairMasts(_Character);// вернуть сбытые мачты

    DeleteAttribute(_Character, "Killer.status"); // снять аттрибут 'был захвачен на абордаж'
    _Character.questTemp.abordage = 0; //снять аттрибут отказа повторного захвата
   	DeleteAttribute(_Character, "Abordage.Enable"); //снять невозможноть абордажа
}
//лучший моряк
void FantomMakeCoolestSailor(ref _Character, int _ShipType, string _ShipName, int _CannonsType, int _Sailing, int _Accuracy, int _Cannons)
{
    _Character.Ship.Cannons.Type = _CannonsType;
	_Character.skill.Sailing  = GetCoffDiffSkill(_Sailing, SKILL_MAX);
	_Character.skill.Accuracy = GetCoffDiffSkill(_Accuracy, SKILL_MAX);
	_Character.skill.Cannons  = GetCoffDiffSkill(_Cannons, SKILL_MAX);

    _Character.DontRansackCaptain = true; //квестовые не сдаются
    _Character.SinkTenPercent     = false; // не тонуть при 10 процентах, не убегать в бою
    _Character.AboardToFinalDeck  = true; // абордаж всегда
	_Character.DontClearDead      = true;
	_Character.SaveItemsForDead   = true;
	_Character.AlwaysSandbankManeuver = true;

    _Character.Ship.Type = GenerateShipTop(_ShipType, true, _Character);
    if (_ShipName == "none" || _ShipName == "") {SetRandomNameToShip(_Character)}
    else {_Character.Ship.Name = _ShipName}

    SetBaseShipData(_Character);
    SetCrewQuantityFull(_Character);
    Fantom_SetBalls(_Character, "pirate");


    DeleteAttribute(_Character, "ship.sails");// убрать дыры на парусах
    DeleteAttribute(_Character, "ship.blots");
    RepairMasts(_Character);// вернуть сбытые мачты

    DeleteAttribute(_Character, "Killer.status"); // снять аттрибут 'был захвачен на абордаж'
    _Character.questTemp.abordage = 0; //снять аттрибут отказа повторного захвата
   	DeleteAttribute(_Character, "Abordage.Enable"); //снять невозможноть абордажа
}

void FantomMakeCoolFighter(ref _Character, int _Rank, int _Fencing, int _Pistol, string _Blade, string _Gun, float _AddHP)
{
    _Character.rank = GetCoffDiff(_Rank, 1000);
    _Character.skill.Fencing = GetCoffDiffSkill(_Fencing, SKILL_MAX);
    _Character.Skill.FencingLight  = GetCoffDiffSkill(sti(_Character.skill.Fencing), SKILL_MAX);
    _Character.Skill.FencingHeavy  = GetCoffDiffSkill(sti(_Character.skill.Fencing), SKILL_MAX);
    _Character.skill.Pistol = GetCoffDiffSkill(_Pistol, SKILL_MAX);
    _Character.skill.Fortune = GetCoffDiffSkill(_Pistol, SKILL_MAX); //zagolski. если умеет хорошо стрелять из пистоля, то умеет и хорошо от него защищаться
	// LEO: прибавка ХП БЕЗ сложности - раньше шла через GetCoffDiff и множилась на 0.6/1.0/1.4.
	//   Сложность продолжает влиять на статы и перки бойца, но не на его запас здоровья.
	_Character.chr_ai.hp = stf(_Character.chr_ai.hp) + _AddHP;
	_Character.chr_ai.hp_max = stf(_Character.chr_ai.hp_max) + _AddHP;
	SetCharacterPerk(_Character, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, дается ГГ и боссам уровней
	SetCharacterPerk(_Character, "SwordplayProfessional");
	SetCharacterPerk(_Character, "AdvancedDefense");
	SetCharacterPerk(_Character, "CriticalHit");
	SetCharacterPerk(_Character, "Sliding");
	SetCharacterPerk(_Character, "HardHitter");
	DeleteAttribute(_Character, "Items");
	_Character.SuperShooter  = true;
	If (_Blade == ""){
        _Blade = LAi_NPC_EquipBladeSelection(sti(_Character.rank), false);//не допускаем лапки
    }
	_Blade = GetGeneratedItem(_Blade);
	GiveItem2Character(_Character, _Blade);
	EquipCharacterbyItem(_Character, _Blade);
    if (_Gun != "")
	{
		GiveItem2Character(_Character, _Gun);
		EquipCharacterbyItem(_Character, _Gun);
		GiveGunAmmunition(_Character, _Gun);
	}
    FaceMaker(_Character);
    SetNewModelToChar(_Character);  // перерисуем модель на лету
}

// Gregg: боссовый защитный профиль одной строкой. Ставится ПОСЛЕ FantomMakeCoolFighter.
//   _DmgResist   - доля 0.0..1.0, режет ЛЮБОЙ входящий урон (LAi_ApplyCharacterDamage)
//   _GunResist   - доля 0.0..1.0, режет только огнестрел (LAi_ApplyCharacterFireDamage).
//                  Нужен отдельно: делитель урона 45/rank работает лишь по клинку, поэтому
//                  высокорангового босса без этого выгоднее расстреливать, не подходя вплотную.
//                  Паритет с клинком считается как _GunResist = 1 - 45/rank.
//   _StunSkip    - 0..100, шанс пропустить флинч от любого попадания (NPC_Event_HitStunSkip)
//   _PierceBlock - блок цели не спасает совсем (как у Стража грота)
// Нулевое / false значение СНИМАЕТ соответствующий атрибут - тем же вызовом удобно
// переключать фазы боя, не выписывая каждый раз четыре строки с DeleteAttribute.
void SetBossDefense(ref _Character, float _DmgResist, float _GunResist, int _StunSkip, bool _PierceBlock)
{
	if (_DmgResist > 0.0) _Character.DmgResist = _DmgResist;
	else DeleteAttribute(_Character, "DmgResist");

	if (_GunResist > 0.0) _Character.GunResist = _GunResist;
	else DeleteAttribute(_Character, "GunResist");

	if (_StunSkip > 0) _Character.HitStunSkip = _StunSkip;
	else DeleteAttribute(_Character, "HitStunSkip");

	if (_PierceBlock) _Character.FullBlockPierce = true;
	else DeleteAttribute(_Character, "FullBlockPierce");
}

// Gregg: боссовый НАСТУПАТЕЛЬНЫЙ профиль - зеркало SetBossDefense, всё в процентах шанса.
//   _Blooding  - valueB,  кровоток при непробитом блоке (LAi_CalcBloodingChance)
//   _BlockPrc  - valueBB, пробитие блока (LAi_CalcBlockBreakChance)
//   _CirassPrc - valueCB, пролом кирасы (LAi_CalcCuirassBreakChance)
//   _Poison    - valueP,  отравление (LAi_CalcPoisonChance; у скелетов сверху ещё +15)
// Нулевое значение ОБНУЛЯЕТ параметр (но не удаляет атрибут) - тем же вызовом удобно расписывать
// эскалацию по фазам. Именно обнуляет, а не удаляет: читатели этих полей обращаются к ним БЕЗ
// CheckAttribute - LAi_CalcBloodingChance (LAi_fightparams.c), LAi_CalcCuirassBreakChance,
// LAi_CalcBlockBreakChance (LAi_events.c), LAi_CalcPoisonChance (LAi_utils.c). Штатный
// UnsetSpecialAttributes тоже зануляет, а не удаляет - то есть в движке действует инвариант
// "эти поля всегда существуют". Удаление ломало бы его и сыпало "missed attribute" на каждом ударе.
// ВАЖНО: звать строго ПОСЛЕ FantomMakeCoolFighter и не переэкипировывать бойца потом -
// SetWeaponsSpecials при экипировке обнуляет всю ветку chr_ai.special и выставляет её от клинка.
// valueCrB и valueSS намеренно не трогаем: они обычно приходят от оружия.
void SetBossOffense(ref _Character, int _Blooding, int _BlockPrc, int _CirassPrc, int _Poison)
{
	_Character.chr_ai.special.valueB  = _Blooding;
	_Character.chr_ai.special.valueBB = _BlockPrc;
	_Character.chr_ai.special.valueCB = _CirassPrc;
	_Character.chr_ai.special.valueP  = _Poison;
}

void FantomMakeCoolFighterWRankDepend(ref _Character, int _Rank, int _Fencing, int _Pistol, float _AddHP)
{
    _Character.rank = GetCoffDiff(_Rank, 1000);
    _Character.skill.Fencing = GetCoffDiffSkill(_Fencing, SKILL_MAX);
    _Character.Skill.FencingLight  = GetCoffDiffSkill(sti(_Character.skill.Fencing), SKILL_MAX);
    _Character.Skill.FencingHeavy  = GetCoffDiffSkill(sti(_Character.skill.Fencing), SKILL_MAX);
    _Character.skill.Pistol = GetCoffDiffSkill(_Pistol, SKILL_MAX);
    _Character.skill.Fortune = GetCoffDiffSkill(_Pistol, SKILL_MAX); //zagolski. если умеет хорошо стрелять из пистоля, то умеет и хорошо от него защищаться
	// LEO: прибавка ХП БЕЗ сложности - раньше шла через GetCoffDiff и множилась на 0.6/1.0/1.4.
	//   Сложность продолжает влиять на статы и перки бойца, но не на его запас здоровья.
	_Character.chr_ai.hp = stf(_Character.chr_ai.hp) + _AddHP;
	_Character.chr_ai.hp_max = stf(_Character.chr_ai.hp_max) + _AddHP;
	SetCharacterPerk(_Character, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, дается ГГ и боссам уровней
	SetCharacterPerk(_Character, "SwordplayProfessional");
	SetCharacterPerk(_Character, "AdvancedDefense");
	SetCharacterPerk(_Character, "CriticalHit");
	SetCharacterPerk(_Character, "Sliding");
	SetCharacterPerk(_Character, "HardHitter");
	DeleteAttribute(_Character, "Items");
	_Character.SuperShooter  = true;
	string sword = LAi_NPC_EquipBladeSelection(sti(_Character.rank),false);
	sword = GetGeneratedItem(sword);
	GiveItem2Character(_Character, sword);
	EquipCharacterbyItem(_Character, sword);
	string Gun = GiveRankGun(_Character);
    if (Gun != "")
	{
		GiveItem2Character(_Character, Gun);
		EquipCharacterbyItem(_Character, Gun);
		GiveGunAmmunition(_Character, Gun);
	}
    FaceMaker(_Character);
    SetNewModelToChar(_Character);  // перерисуем модель на лету
}

string GiveRankGun(ref chr)
{
	string guntype = "";
	int iRnd = rand(1);
	if(sti(chr.rank) > 10) iRnd = rand(2);
	if(sti(chr.rank) > 15) iRnd = rand(2) + 1;
	if(sti(chr.rank) > 20) iRnd = rand(3) + 2;

	switch(iRnd)
	{
		case 0:
			if(rand(100) < 70)
			{
				guntype = "pistol1"; // Пистоль
			}
		break;

		case 1:
			if(rand(100) < 75)
			{
				guntype = "pistol2"; // Колониальный пистолет
			}
		break;

		case 2:
			if(rand(100) < 80)
			{
				guntype = "pistol3"; // Тромбон
			}
		break;

		case 3:
			if(rand(100) < 85)
			{
				guntype = "pistol6"; // Бок-пистолет
			}
		break;

		case 4:
			if(rand(100) < 90)
			{
				guntype = "pistol5"; // Бретерский пистолет
			}
		break;

		case 5:
			if(rand(100) < 95)
			{
				guntype = "pistol4"; // Четырёхствольный пистолет
			}
		break;
	}
	return guntype;
}

void GiveGunAmmunition(ref _Character, string sItem)
{
	ref itm = ItemsFromID(sItem);
	TakeNItems(_Character,itm.type.t1.bullet, 20+rand(20));
	if(itm.type.t1.gunpowder != "") AddItems(_Character, itm.type.t1.gunpowder, 20+rand(20));// порох при необходимости
	LAi_SetCharacterUseBullet(_Character, itm.type.t1.bullet);
}

void GiveGunAmmunitionPchar(ref _Character, string sItem, int qty)
{
	ref itm = ItemsFromID(sItem);
	TakeNItems(_Character,itm.type.t1.bullet, qty);
	if(itm.type.t1.gunpowder != "") AddItems(_Character, itm.type.t1.gunpowder, qty);// порох при необходимости
	LAi_SetCharacterUseBullet(_Character, itm.type.t1.bullet);
}

int GetCoffDiff(float _num, int _maxRange)
{
	switch (MOD_SKILL_ENEMY_RATE)
	{
		case SAILOR_DIFFICULTY:  _num *= 0.6;  break;
		case CAPTAIN_DIFFICULTY: _num *= 1; break;
		case ADMIRAL_DIFFICULTY: _num *= 1.4; break;
	}
	_num += 0.5;
	if (_num > _maxRange) return _maxRange;
	else return sti(_num);
}
int GetCoffDiffSkill(float _num, int _maxRange)
{
	switch (MOD_SKILL_ENEMY_RATE)
	{
		case SAILOR_DIFFICULTY:  _num *= 0.8;  break;
		case CAPTAIN_DIFFICULTY: _num *= 1; break;
		case ADMIRAL_DIFFICULTY: _num *= 1.2; break;
	}
	_num += 0.5;
	if (_num > _maxRange) return _maxRange;
	else return sti(_num);
}
// заполнение сундуков и рандитема по квесту
bool SetLocationQuestRandItem(int _index, aref _location, string _locatorName, aref al) // al - ветка локатора из модели, остальное тоже из обратотки локации
{   // метод редактировать не нужно - все задается в квестах
	string  lastSpawnTimeString;
    int     n;
	string  itemId;
	aref checkAref

	lastSpawnTimeString = _location.id;
    if (CheckAttribute(pchar , "GenQuestRandItem." + lastSpawnTimeString) && CheckAttribute(pchar , "GenQuestRandItem." + lastSpawnTimeString +"."+_locatorName))
    {
        itemId = pchar.GenQuestRandItem.(lastSpawnTimeString).(_locatorName);
        if (!CheckAttribute(pchar , "GenQuestRandItem." + lastSpawnTimeString +".stay"))
        {
			//--> fix eddy. нельзя было положить в несколько локаторов
			DeleteAttribute(pchar , "GenQuestRandItem." + lastSpawnTimeString + "." + _locatorName); // если токо один раз
			makearef(checkAref,  pchar.GenQuestRandItem.(lastSpawnTimeString));
			if (GetAttributesNum(checkAref) == 0) DeleteAttribute(pchar , "GenQuestRandItem." + lastSpawnTimeString);
        }
        // только один предмет!!!!!!!!!!!!
        n = SetRandItemShow(_index, al, itemId); // вывести 3д модель в лакацию, если модель вообще есть
		if (n != -1)
		{
            Log_TestInfo("SetLocationQuestRandItem");
            lastSpawnTimeString = "LastSpawnTime"+_index;
		    _location.(lastSpawnTimeString) = Items_MakeTime(GetTime(), GetDataDay(), GetDataMonth(), GetDataYear());
            lastSpawnTimeString = "RandItemType"+_index;
        	_location.(lastSpawnTimeString) = n;
            return true;
        }
    }

    return false;
}
// загрузить модель
int SetRandItemShow(int _index, aref al, string _itemId)
{
    int     n;
    aref    randItem;

    n = Items_FindItem(_itemId, &randItem);
	if (n != -1)
	{
        if (!CheckAttribute(randItem, "model") || randItem.model == "")
    	{
    		Trace("SetRandItemShow: no model for item "+randItem.id);
    		return -1;
    	}
	    Items_LoadModel(&randItemModels[_index],  randItem);
    	SendMessage(&randItemModels[_index], "lffffffffffff", MSG_MODEL_SET_POSITION, makeFloat(al.x), makeFloat(al.y), makeFloat(al.z), makeFloat(al.vx.x), makeFloat(al.vx.y), -makeFloat(al.vx.z), makeFloat(al.vy.x), makeFloat(al.vy.y), -makeFloat(al.vy.z), makeFloat(al.vz.x), makeFloat(al.vz.y), -makeFloat(al.vz.z));

        return n;
    }
    return n;
}
// заполнить сундук
bool SetLocationQuestBox(ref _location, string _locatorName)
{   // метод редактировать не нужно - все задается в квестах
    bool    ok = false;
    string  locId;
    aref    arToBox;
    aref    arFromBox;

 	locId  = _location.id;
    if (CheckAttribute(pchar , "GenQuestBox." + locId) && CheckAttribute(pchar , "GenQuestBox." + locId + "." + _locatorName))
    {
        Log_TestInfo("SetLocationQuestBox");

        makearef(arToBox, _location.(_locatorName));
        makearef(arFromBox, pchar.GenQuestBox.(locId).(_locatorName));
        CopyAttributes(arToBox, arFromBox);
        _location.(_locatorName) = Items_MakeTime(GetTime(), GetDataDay(), GetDataMonth(), GetDataYear()); // таймер, чтоб не затерлись рандомом при выходе из локации
        if (!CheckAttribute(pchar , "GenQuestBox." + locId +".stay"))
        {
			//--> fix eddy. нельзя было положить в несколько локаторов
			DeleteAttribute(pchar , "GenQuestBox." + locId + "." + _locatorName); // если токо один раз
			makearef(arToBox,  pchar.GenQuestBox.(locId));
			if (GetAttributesNum(arToBox) == 0) DeleteAttribute(pchar , "GenQuestBox." + locId);
        }
        return true;
    }
    return false;
}

// ==> Метод открытия\закрытия локаторов релоад. Если _flag=true - закрыть локатор, если _flag=false - открыть.
void LocatorReloadEnterDisable(string _locationID, string _locator, bool _flag)
{
    aref arDis, arRld;
	makearef(arRld, Locations[FindLocation(_locationID)].reload);
	int	Qty = GetAttributesNum(arRld);
	for (int i=0; i<Qty; i++)
	{
		arDis = GetAttributeN(arRld, i);
        if (arDis.name == _locator)
        {
    		if (_flag) arDis.disable = 1;
    		else DeleteAttribute(arDis, "disable");
            break;
        }
	}
}

//===>>> Функции по работе с диалоговыми файлами. Эдди. ================================================================
// == _strNormal - обычная строка диалога
// == _strBad1, _strBad2, _strBad3 - строки степени возмущения,  "" и "none" - базовый набор.
// == _kind - вид возмущения: "repeat" - снимается на следующий день при условии, что НПС вконец не разозлился (не задействован анги-файл).
//                            "quest"  - квестовые повторялки, не снимаются на следующий день, но может быть задан срок примирения после перевода на ангри.
//                            "block"  - реакцию НПС на повторные клики без включения ангри, для того, чтобы обозначить интеллект, но не ругаться. Ангри вообще не делать.
//                            "cycle"  - крутим цикл из повторялок, ангри не заряжать. На след. день все снимается.
// == _terms для "repeat" и "quest" - сроки в днях примирения само-собой после задействоания ангри-файла, если == 0, то ругань навсегда (примерение только через подарки).
//    _terms для "block" - сроки возврата в норму в днях, если 0 - навсегда.
// == _character и _Node - npchar и Dialog.CurrentNode
string NPCStringReactionRepeat(string _strNormal, string _strBad1, string _strBad2, string _strBad3, string _kind, int _terms, ref _character, string _Node)
{
    _Node = stripblank(_Node); //fix spaces
	string strBack;
    string strTemp = "quest.repeat." + _Node;
    if (!CheckAttribute(_character , strTemp))
    {
        _character.quest.repeat.(_Node) = 0;
        _character.quest.repeat.(_Node).ans = 0;
    }
    if (_kind == "cycle" || _kind == "repeat") //на след.день все снимается.
    {
        if (GetNpcQuestPastDayParam(_character, strTemp) >= 1)
        {
            _character.quest.repeat.(_Node) = 0;
            _character.quest.repeat.(_Node).ans = 0;
        }
    }
    else
    {
        if (GetNpcQuestPastDayParam(_character, strTemp) >= _terms && _terms!=0 && _kind != "quest") //снятие по "block"
        {
            _character.quest.repeat.(_Node) = 0;
            _character.quest.repeat.(_Node).ans = 0;
        }
    }
    switch(_character.quest.repeat.(_Node))
	{
        case "0":
            strBack = _strNormal;
            _character.quest.repeat.(_Node) = 1;
            _character.quest.repeat.(_Node).ans = 0;
            SaveCurrentNpcQuestDateParam(_character, strTemp);
        break;
        case "1":
            if (_strBad1 == "none" || _strBad1 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("I don't want to talk about the same thing several times.", "Je n'ai pas envie de parler plusieurs fois de la même chose."),
						FrS("We've already talked about it.", "Nous en avons déjà parlé."),
						FrS("We've already discussed this topic.", "Nous avons déjà abordé ce sujet."));
				}
				else
				{
                	strBack = LinkRandPhrase("Я не хочу говорить об одном и том же по нескольку раз.",
                        "Мы уже говорили об этом.",
                        "Эту тему мы уже обсуждали.");
				}
            }
            else
            {
                strBack = _strBad1;
            }
            _character.quest.repeat.(_Node) = 2;
            _character.quest.repeat.(_Node).ans = 1;
        break;
        case "2":
            if (_strBad2 == "none" || _strBad2 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("I repeat once again that I do not want to talk about the same thing ten times!", "Je vous le répète : je ne veux pas parler dix fois de la même chose !"),
						FrS("I repeat, we have already talked about this!", "Je le répète, nous en avons déjà parlé !"),
						FrS("I tell you, we have already discussed this. Memory problems?", "Je vous dis que nous en avons déjà discuté. Des problèmes de mémoire ?"));
				}
				else
				{
                	strBack = LinkRandPhrase("Ещё раз повторяю, что я не хочу говорить об одном и том же по десять раз!",
                        "Повторяю, мы уже говорили об этом!",
                        "Я же говорю, мы это уже обсуждали. Проблемы с памятью?");
				}
            }
            else
            {
                strBack = _strBad2;
            }
            _character.quest.repeat.(_Node) = 3;
            _character.quest.repeat.(_Node).ans = 2;
        break;
        case "3":
            if (_strBad3 == "none" || _strBad3 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("I don't intend to communicate with you anymore.", "Je n'ai plus l'intention de vous parler."),
						FrS("I won't talk to you anymore!", "Je ne vous parle plus !"),
						FrS("You made me pretty angry"+ GetSexPhrase("","a") +", no more communication.", "Vous avez épuisé ma patience, je ne vous parle plus.")); // FR_PATCH
				}
				else
				{
                	strBack = LinkRandPhrase("Я не намерен более с вами общаться.",
                	    "Не буду с тобой больше разговаривать!",
                	    "Ты меня порядком разозлил"+ GetSexPhrase("","а") +", никакого общения более.");
				}
            }
            else
            {
                strBack = _strBad3;
            }
            // ==> Реакция на третье повторение.
            if (_kind == "cycle") //снова на первую строку.
            {
			    _character.quest.repeat.(_Node) = 0;
            }
			else
            {
                if(_kind != "block") //если block, то опять в последнюю строку
                {
                    _character.quest.repeat.(_Node) = 4;
                    CharacterAddAngry(_character, _Node, _kind, _terms);
    			}
            }
            _character.quest.repeat.(_Node).ans = 3;
        break;
        case "4":
            strBack = "NPCStringReactionRepeat error!!!"
        break;
	}
    return strBack;
}

string HeroStringReactionRepeat(string _strNormal, string _strBad1, string _strBad2, string _strBad3, ref _character, string _Node)
{
    _Node = stripblank(_Node); //fix spaces
	string strBack;
    int Temp = sti(_character.quest.repeat.(_Node).ans);
    switch(Temp)
	{
        case "0":
            strBack = _strNormal;
        break;
        case "1":
            if (_strBad1 == "none" || _strBad1 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("Okay, buddy.", "D'accord, l'ami."),
						FrS("Whatever you say.", "Comme vous voudrez."),
						FrS("I blurted it out"+ GetSexPhrase("","a") +", sorry...", "J'ai trop parlé, pardon...")); // FR_PATCH
				}
				else
				{
                	strBack = LinkRandPhrase("Хорошо, приятель.",
                	    "Как скажешь.",
                	    "Не то ляпнул"+ GetSexPhrase("","а") +", извини...");
				}
            }
            else
            {
                strBack = _strBad1;
            }
        break;
        case "2":
            if (_strBad2 == "none" || _strBad2 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("Good, good. Just don't get angry.", "Bon, bon. Ne vous fâchez pas."),
						FrS("Whatever you say, just don't shout.", "Comme vous voudrez, mais ne criez pas."),
						FrS("Sorry, I'm not in shape today... My head is splitting in the morning...", "Pardon, je ne suis pas en forme aujourd'hui... J'ai la tête qui éclate depuis ce matin..."));
				}
				else
				{
                	strBack = LinkRandPhrase("Хорошо, хорошо. Только не кипятись.",
                	    "Как скажешь, только не надо кричать.",
                	    "Извини, что-то я сегодня не в форме... Голова с утра раскалывается...");
				}
            }
            else
            {
                strBack = _strBad2;
            }
        break;
        case "3":
            if (_strBad3 == "none" || _strBad3 == "")
            {
				if (LanguageGetLanguage() != "russian")
				{
					strBack = LinkRandPhrase(FrS("As you know.", "Comme vous voulez."),
						FrS("Very sorry ...", "Toutes mes excuses..."),
						FrS("Small loss.", "Pas une grande perte."));
				}
				else
				{
					strBack = LinkRandPhrase("Как знаешь.",
                        "Очень жаль...",
                        "Невелика потеря.");
				}
            }
            else
            {
                strBack = _strBad3;
            }
        break;
        case "4":
            strBack = "HeroStringReactionRepeat error!!!"
        break;
	}
    return strBack;
}

// возможны только две переходные ноды: _GoNode1 и _GoNode2, третья не нужна, т.к. идёт сразу в ангри-файл.
// неверно, оставил третью ноду для циклов и прочего.
string DialogGoNodeRepeat(string _NormalNode, string _GoNode1, string _GoNode2, string _GoNode3, ref _character, string _Node)
{
    _Node = stripblank(_Node); //fix spaces
	string strBack, Temp;
    Temp = sti(_character.quest.repeat.(_Node).ans);
    switch(Temp)
	{
        case "0":
            strBack = _NormalNode;
        break;
        case "1":
            if (_GoNode1 == "none" || _GoNode1 == "")
            {
                strBack = "exit";
            }
            else
            {
                strBack = _GoNode1;
            }
        break;
        case "2":
            if (_GoNode2 == "none" || _GoNode2 == "")
            {
                strBack = "exit";
            }
            else
            {
                strBack = _GoNode2;
            }
        break;
        case "3":
            if (_GoNode3 == "none" || _GoNode3 == "")
            {
                strBack = "exit";
            }
            else
            {
                strBack = _GoNode3;
            }
        break;
        case "4":
            strBack = "exit"
            Log_SetStringToLog("DialogGoNodeRepeat#4 error!!!");
        break;
    }
    return strBack;
}

// _Node - имя ноды, идентификатор текущей ангри. Если метод вызывается не в диалоговом файле, то == "none".
void CharacterAddAngry(ref _character, string _Node, string _kind, int _terms)
{
    if (_kind == "repeat" || _kind == "quest")
    {
        DeleteAttribute(_character, "angry");
        _character.angry.kind = _kind;
        _character.angry.name = _Node; //и имя ноды тоже, для расфасовки разных ангри
        if (_terms != 0) // если == 0, то ссора непроходящая с течением времени.
        {
            _character.angry.terms = _terms;
            SaveCurrentNpcQuestDateParam(_character, "angry.terms");
            if (_terms < 10) // размер вознаграждения за примирение, анти с/л
            {
                _character.angry.QtyMoney = (rand(10)+1) * 500;
            }
            else
            {
                _character.angry.QtyMoney = (rand(10)+1) * 5000;
            }
        }
        else
        {
            _character.angry.QtyMoney = (rand(10)+1) * 10000;
        }
    }
    else {Log_Info("CharacterAddAngry error!!!");}
}

void CharacterDelAngry(ref _character)
{
    DeleteAttribute(_character, "angry");
    DeleteAttribute(_character, "quest.repeat");
}

// Gregg: === Арбитраж квестовых хабов (Морган/Джекман) =========================
// Проблема: несколько сюжетных линий паркуют у одного NPC ноду "доклада" в
// единственный слот dialog.currentnode и молча затирают друг друга (Орион node16
// <-> пиратка PL_Q3_GoodWork и т.п.). Решение: держим отдельную очередь докладов
// (dialog.hubReportQ.<key>), а диспетчер в префиксе диалога хаба выдаёт их по
// одному, когда NPC свободен. dialog.hubActiveKey — линия, чей доклад сейчас в
// currentnode. Всё через атрибуты персонажа => совместимо с сейвами.

// Хаб, для которого включён арбитраж докладов.
bool HubIsArbitrated(string _chID)
{
    if (_chID == "Henry Morgan") return true;
    if (_chID == "Jackman")      return true;
    return false;
}

// "Свободная" (входная, между-диалоговая) нода хаба — на ней можно выдать доклад.
bool HubIsIdleNode(string _chID, string _node)
{
    if (_node == "First time")      return true;
    if (_node == "I_know_you_good") return true;
    return false;
}

// По имени ноды определяем, какой сюжетной линии она принадлежит (ключ очереди).
// Пустая строка => нода не участвует в арбитраже (ведём себя как раньше).
string HubNodeKey(string _node)
{
    if (_node == "") return "";
    if (findsubstr(_node, "Andre_Abel", 0) == 0) return "Andre_Abel"; // "Орион"
    if (findsubstr(_node, "PL_Q",       0) == 0) return "PiratesLine";
    if (findsubstr(_node, "PearlQ",     0) == 0) return "PiratesLine";
    if (findsubstr(_node, "EngLine",    0) == 0) return "EngLine";
    if (_node == "hot_business")                 return "EngLine";
    if (_node == "Give_blade")                   return "EngLine";
    if (findsubstr(_node, "HolLine",    0) == 0) return "HolLine";
    if (findsubstr(_node, "FraLine",    0) == 0) return "FraLine";
    if (_node == "Lets_go_bussines")             return "BelizHeist"; // англ. линейка 3 (налёт на Белиз)
    if (_node == "Gold_found_in_fort")           return "BelizHeist"; // та же линейка, поздняя фаза => upsert
    // LEO: нода-ожидание между согласием на налёт и докладом о золоте. Без неё в списке линия теряла
    //   собственный узел: губернатор Белиза слал Моргану Gold_found_in_fort, арбитраж считал хаб занятым
    //   ЧУЖОЙ линией и парковал доклад в очередь. А достать его оттуда было нечем - очередь отдаётся либо
    //   на свободной ноде, либо внутрилинейным догоном по ключу, но «Have_hot_bussines» самоподдерживающаяся
    //   (NextDiag.TempNode на саму себя) и ключа не имела. Морган навсегда повисал на «Чего мы ждём?».
    if (_node == "Have_hot_bussines")            return "BelizHeist"; // ожидание налёта - та же линейка
    return "";
}

// Припарковать доклад линии _key у хаба. Если хаб свободен (или уже занят этой же
// линией) — ставим ноду сразу; иначе кладём в очередь, не затирая чужой доклад.
void HubReportPark(string _chID, string _key, string _node)
{
    if (GetCharacterIndex(_chID) < 0) return;
    ref h = characterFromID(_chID);

    string cur = "";
    if (CheckAttribute(h, "dialog.currentnode")) cur = h.dialog.currentnode;
    string act = "";
    if (CheckAttribute(h, "dialog.hubActiveKey")) act = h.dialog.hubActiveKey;

    bool bFree = false;
    if (cur == "") bFree = true;
    if (HubIsIdleNode(_chID, cur)) bFree = true;
    // Gregg: владельца узла определяем по имени ноды, а не только по activeKey —
    // внутридиалоговые переходы (NextDiag.TempNode = ...) activeKey не обновляют.
    // Та же линия => прямой переход (легаси-поведение), напр. PL_Q2_wait -> PL_Q2_away_1.
    if (HubNodeKey(cur) == _key) bFree = true;
    if (act == _key) bFree = true;

    if (bFree)
    {
        if (CheckAttribute(h, "angry")) h.dialog.TempNode = _node;
        else h.dialog.currentnode = _node;
        h.dialog.hubActiveKey = _key;
        if (CheckAttribute(h, "dialog.hubReportQ." + _key)) DeleteAttribute(h, "dialog.hubReportQ." + _key);
    }
    else
    {
        h.dialog.hubReportQ.(_key) = _node; // upsert по ключу: у линии не более 1 ждущего доклада
    }
}

// Выдать следующий отложенный доклад (FIFO) и снять его с очереди. "" — очередь пуста.
// Вызывается из префикса диалога хаба, когда NPC стоит на свободной ноде.
string HubReportServe(string _chID)
{
    if (GetCharacterIndex(_chID) < 0) return "";
    ref h = characterFromID(_chID);
    if (!CheckAttribute(h, "dialog.hubReportQ")) return "";
    aref q; makearef(q, h.dialog.hubReportQ);
    if (GetAttributesNum(q) <= 0) return "";
    string key  = GetAttributeName(GetAttributeN(q, 0));
    string node = h.dialog.hubReportQ.(key);
    h.dialog.hubActiveKey = key;
    DeleteAttribute(h, "dialog.hubReportQ." + key);
    return node;
}

// Выдать отложенный доклад КОНКРЕТНОЙ линии (внутрилинейный догон): если узлом
// хаба владеет линия _key, а в очереди лежит её же более свежая нода — отдаём её.
// Также самоизлечивает сейвы, где нода той же линии успела застрять в очереди.
string HubReportServeKey(string _chID, string _key)
{
    if (_key == "") return "";
    if (GetCharacterIndex(_chID) < 0) return "";
    ref h = characterFromID(_chID);
    if (!CheckAttribute(h, "dialog.hubReportQ." + _key)) return "";
    string node = h.dialog.hubReportQ.(_key);
    h.dialog.hubActiveKey = _key;
    DeleteAttribute(h, "dialog.hubReportQ." + _key);
    return node;
}
// Gregg: === /Арбитраж квестовых хабов ========================================

//В условиях возможного тотального применения ангри по квестам, нужно подстраховаться.
//Если нода дается НПС в момет, когда у него задействован ангри, то нода будет возвращена после примирения.
//Соотв. менять ноды желательно данным методом.
void QuestSetCurrentNode(string _chID, string _Node)
{
    // Gregg: для хабов (Морган/Джекман) прогоняем известные ноды докладов через
    // арбитраж — иначе параллельные сюжетные линии затирают ноду друг у друга.
    if (HubIsArbitrated(_chID))
    {
        string _key = HubNodeKey(_Node);
        if (_key != "")
        {
            HubReportPark(_chID, _key, _Node);
            return;
        }
    }
    ref chref = characterFromID(_chID);
    if (CheckAttribute(chref, "angry")) chref.dialog.TempNode = _Node;
    else chref.dialog.currentnode = _Node;
}

// фраза от пола НПС
string NPCharSexPhrase(ref _character, string StrMan, string StrWoman)
{
	string strBack;
   	if (_character.sex == "woman" || findsubstr(_character.Model, "PGG_Ghost" , 0) != -1)
   	{
   	    strBack = StrWoman;
   	}
   	else
   	{
   	    strBack = StrMan;
   	}
   	return strBack;
}
// фраза от пола ГГ
string GetSexPhrase(string StrMan, string StrWoman)
{
	return NPCharSexPhrase(PChar, StrMan, StrWoman);
}
//<<<=== Функции по работе с диалоговыми файлами. =======================================================================


// Временно сохранить все данные о нашем корабле в памяти
//--------------------------------------------------------
bool SetTempRemoveParam(ref _refCharacter, string _param)
{
    string sParam = "TmpRemember" + _param;

	if( CheckAttribute(_refCharacter, sParam) ) return false;
	if( !CheckAttribute(_refCharacter, _param) ) return false;

	aref dstRef; makearef(dstRef, _refCharacter.(sParam));
	aref srcRef; makearef(srcRef, _refCharacter.(_param));

	CopyAttributes(dstRef,srcRef);
	return true;
}

// Восстановить данные о нашем старом корабле из памяти
//------------------------------------------------------
bool RestoreTempRemoveParam(ref _refCharacter, string _param)
{
    string sParam = "TmpRemember" + _param;

	if( !CheckAttribute(_refCharacter, sParam) ) return false;

	aref dstRef; makearef(dstRef, _refCharacter.(_param));
	aref srcRef; makearef(srcRef, _refCharacter.(sParam));

	//--> eddy. структура быть должна, иначе вылет в винду.
	CopyAttributes(dstRef,srcRef);
	DeleteAttribute(_refCharacter, sParam);
	return true;
}

// установка отмены боевки в резиденции при захвате города
// ВАЖНО: работает только не в пиратском городе - иначе это просто мятеж и губернатора там нет вообще
void SetCaptureResidenceQuest(string _city, string _method, bool _majorOff)
{
    PChar.GenQuestFort.ResidenceQuest.(_city) = true;
    // убирать ли губернатора из локации вообще, он пропадет, но потом обратно пропишется, чтоб не рушить мир игры.
    PChar.GenQuestFort.ResidenceQuest.(_city).MayorOff = _majorOff;
    if (_method != "")
    {
        PChar.GenQuestFort.ResidenceQuest.(_city).method = _method;
	}
}

// вернем диалог после разговора и спрячем
void  SetReturn_Gover_Dialog_Exit(ref NPChar)
{
	LAi_LoginInCaptureTown(NPChar, false);

	PChar.GenQuest.GoverIdx = NPChar.index;
	Pchar.quest.Return_Gover_Dialog_Exit.win_condition.l1          = "ExitFromLocation";
    Pchar.quest.Return_Gover_Dialog_Exit.win_condition.l1.location = Pchar.location;
    Pchar.quest.Return_Gover_Dialog_Exit.win_condition             = "Return_Gover_Dialog_Exit";
}

//#20171020-01 Bug fix SetNewModelToChar sending itemID, and needs model name
void SetNewModelToChar(ref chref)
{
    float liveTime = 0.1;
	int colors = argb(64, 64, 64, 64);
	int colore = argb(0, 32, 32, 32);

	aref arItm;
    string modelName;
    object emptyItm;

    if (IsEntity(chref))
    {
    	if(CheckAttribute(chref, "model"))
        {
			if(chref.model == "") chref.model = "none";
			SendMessage(chref, "lss",   MSG_CHARACTER_SETMODEL, chref.model, chref.model.animation);
			if (findsubstr(chref.model, "ghost" , 0) != -1 )
			{
				object persRef = GetCharacterModel(chref);
				SendMessage(persRef, "ls", MSG_MODEL_SET_TECHNIQUE, "DLightMark");
			}
        }
        if(CheckAttribute(chref, "equip.gun"))
        {
            modelName = chref.equip.gun;
            makearef(arItm,emptyItm);
            if(modelName!="")
            {
                Items_FindItem(modelName,&arItm);
            }
            if(CheckAttribute(arItm,"model"))    {modelName = arItm.model;}
            SendMessage(chref, "ls",    MSG_CHARACTER_SETGUN,   modelName);
        }
        if(CheckAttribute(chref, "equip.blade"))
        {
            modelName = chref.equip.blade;
            makearef(arItm,emptyItm);
            if(modelName!="")
            {
                Items_FindItem(modelName,&arItm);
            }
            if(CheckAttribute(arItm,"model"))    {modelName = arItm.model;}
             //#20191009-01
            if(CheckAttribute(arItm, "param.time")) //"blade.time"))
            {
                liveTime = stf(arItm.param.time);
            }
            if(CheckAttribute(arItm, "param.colorstart")) //"blade.colorstart"))
            {
                colors = sti(arItm.param.colorstart);
            }
            if(CheckAttribute(arItm, "param.colorend")) //"blade.colorend"))
            {
                colore = sti(arItm.param.colorend);
            }
            SendMessage(chref, "llsfll", MSG_CHARACTER_SETBLADE, 0, modelName, liveTime, colors, colore);
        }
    }
}
// функции из квест_реакшн
void SetNationToOfficers(int _nat)
{
    int j, cn;
    ref officer;

    for(j=1; j<COMPANION_MAX; j++)
    {
        cn = GetCompanionIndex(GetMainCharacter(),j);
        if( cn>0 )
        {
	        officer = GetCharacter(cn);
	        if (!GetRemovable(officer)) continue;
	        officer.nation = _nat;
	        Ship_FlagRefresh(officer); //флаг на лету
	    }
	}
}

bool IsOfficerCompanion(ref _refCharacter)
{
	int findIdx = sti(_refCharacter.index);
	ref mc = GetMainCharacter();
	int ci, cn;
	ref npc;
	for(int i=1; i<COMPANION_MAX; i++)
	{
		ci = GetCompanionIndex(mc,i);
		npc = GetCharacter(ci);
		for(int j=1; j<=MAX_NUM_FIGHTERS; j++)
		{
			if(GetOfficersIndex(npc,j)==findIdx) return true;
		}
	}
	return false;
}

// установка квестовых товаров и цен
void SetQuestGoodsToStore(ref refStore)
{
	string    goodName;
	if (CheckAttribute(pchar, "GenQuest.StoreGoods.StoreIdx") && refStore.index == pchar.GenQuest.StoreGoods.StoreIdx)
	{
		if (CheckAttribute(pchar, "GenQuest.StoreGoods.HL2_DiscountPrices")) //Голл.линейка, квест №2, дискаунт в Форт Оранже.
		{
		    DeleteAttribute(pchar, "GenQuest.StoreGoods"); // одноразовая операция, трем обе ветки
			goodName = Goods[GOOD_EBONY].Name;
		    pchar.questTemp.HL2Save.EbonyQty = refStore.Goods.(goodName).Quantity;
		    refStore.Goods.(goodName).Quantity       = 400;
		    pchar.questTemp.HL2Save.EbonyPrice = GetStoreGoodsPrice(refStore, GOOD_EBONY, PRICE_TYPE_BUY, pchar, refStore.Goods.(goodName).RndPriceModify);
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_EBONY, PRICE_TYPE_BUY, pchar, 10);

		    goodName = Goods[GOOD_COFFEE].Name;
		    pchar.questTemp.HL2Save.CoffeeQty = refStore.Goods.(goodName).Quantity;
		    refStore.Goods.(goodName).Quantity       = 400;
		    pchar.questTemp.HL2Save.CoffeePrice = GetStoreGoodsPrice(refStore, GOOD_COFFEE, PRICE_TYPE_BUY, pchar, refStore.Goods.(goodName).RndPriceModify);
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_COFFEE, PRICE_TYPE_BUY, pchar, 9);

		    goodName = Goods[GOOD_MAHOGANY].Name;
		    pchar.questTemp.HL2Save.MahoganyQty = refStore.Goods.(goodName).Quantity;
		    refStore.Goods.(goodName).Quantity       = 400;
		    pchar.questTemp.HL2Save.MahoganyPrice =  GetStoreGoodsPrice(refStore, GOOD_MAHOGANY, PRICE_TYPE_BUY, pchar, refStore.Goods.(goodName).RndPriceModify);
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_MAHOGANY, PRICE_TYPE_BUY, pchar, 14);

		    goodName = Goods[GOOD_SANDAL].Name;
		    pchar.questTemp.HL2Save.SandalQty = refStore.Goods.(goodName).Quantity;
		    refStore.Goods.(goodName).Quantity       = 400;
		    pchar.questTemp.HL2Save.SandalPrice = GetStoreGoodsPrice(refStore, GOOD_SANDAL, PRICE_TYPE_BUY, pchar, refStore.Goods.(goodName).RndPriceModify);
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_SANDAL, PRICE_TYPE_BUY, pchar, 11);
        	pchar.GenQuest.StoreGoods.StoreIdx = FortOrange_STORE; //держим цены для след. посещений
        	pchar.GenQuest.StoreGoods.HL2_AgainDiscount = true;
		}
		if (CheckAttribute(pchar, "GenQuest.StoreGoods.HL2_AgainDiscount")) //Голл.линейка, квест №2, держим дисконтные цены
		{
		    goodName = Goods[GOOD_EBONY].Name;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_EBONY, PRICE_TYPE_BUY, pchar, 10);

		    goodName = Goods[GOOD_COFFEE].Name;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_COFFEE, PRICE_TYPE_BUY, pchar, 9);

		    goodName = Goods[GOOD_MAHOGANY].Name;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_MAHOGANY, PRICE_TYPE_BUY, pchar, 14);

		    goodName = Goods[GOOD_SANDAL].Name;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_SANDAL, PRICE_TYPE_BUY, pchar, 11);
		}
		if (CheckAttribute(pchar, "GenQuest.StoreGoods.HL2_QtyPriceIsBack")) //Голл.линейка, квест №2, возврат цен и кол-ва после квеста.
		{
            DeleteAttribute(pchar, "GenQuest.StoreGoods"); // одноразовая операция, трем обе ветки
		    goodName = Goods[GOOD_EBONY].Name;
		    refStore.Goods.(goodName).Quantity       = pchar.questTemp.HL2Save.EbonyQty;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_EBONY, PRICE_TYPE_BUY, pchar, sti(pchar.questTemp.HL2Save.EbonyPrice));

		    goodName = Goods[GOOD_COFFEE].Name;
		    refStore.Goods.(goodName).Quantity       = pchar.questTemp.HL2Save.CoffeeQty;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_COFFEE, PRICE_TYPE_BUY, pchar, sti(pchar.questTemp.HL2Save.CoffeePrice));

		    goodName = Goods[GOOD_MAHOGANY].Name;
		    refStore.Goods.(goodName).Quantity       = pchar.questTemp.HL2Save.MahoganyQty;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_MAHOGANY, PRICE_TYPE_BUY, pchar, sti(pchar.questTemp.HL2Save.MahoganyPrice));

		    goodName = Goods[GOOD_SANDAL].Name;
		    refStore.Goods.(goodName).Quantity       = pchar.questTemp.HL2Save.SandalQty;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_SANDAL, PRICE_TYPE_BUY, pchar, sti(pchar.questTemp.HL2Save.SandalPrice));
            DeleteAttribute(pchar, "questTemp.HL2Save");
        }
		if (CheckAttribute(pchar, "GenQuest.StoreGoods.HL5_ThreeFleutes")) //Голл.линейка, квест №5, добавляем количества, снижаем цену
		{
            goodName = Goods[GOOD_FOOD].Name;
		    refStore.Goods.(goodName).Quantity       = sti(refStore.Goods.(goodName).Quantity) + 75000;
			pchar.questTemp.HL5Save.FoodPrice 		 = GetStoreGoodsPrice(refStore, GOOD_FOOD, PRICE_TYPE_BUY, pchar, refStore.Goods.(goodName).RndPriceModify);
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_FOOD, PRICE_TYPE_BUY, pchar, 10);
        }
		if (CheckAttribute(pchar, "GenQuest.StoreGoods.HL5_QtyPriceIsBack")) //Голл.линейка, квест №5, возврат цен после квеста.
		{
			DeleteAttribute(pchar, "GenQuest.StoreGoods"); // одноразовая операция, трем обе ветки
			goodName = Goods[GOOD_FOOD].Name;
			refStore.Goods.(goodName).RndPriceModify = GetStoreGoodsRndPriceModify(refStore, GOOD_FOOD, PRICE_TYPE_BUY, pchar, sti(pchar.questTemp.HL5Save.FoodPrice));
            DeleteAttribute(pchar, "questTemp.HL5Save");
        }
	}
}

void HolLine2_NullGoods() //для второго квеста голл. линейки.
{
    ref sld;
    int chComp;
    if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed")) pchar.Ship.Cargo.Goods.Ebony = 0;
    if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed")) pchar.Ship.Cargo.Goods.Coffee = 0;
    if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed")) pchar.Ship.Cargo.Goods.Mahogany = 0;
    if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed")) pchar.Ship.Cargo.Goods.Sandal = 0;
    for (int i=1; i<=COMPANION_MAX; i++)
	{
        chComp = GetCompanionIndex(pchar,i);
        if(chComp != -1)
		{
			sld = GetCharacter(chComp);
            if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed")) sld.Ship.Cargo.Goods.Ebony = 0;
            if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed")) sld.Ship.Cargo.Goods.Coffee = 0;
            if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed")) sld.Ship.Cargo.Goods.Mahogany = 0;
            if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed")) sld.Ship.Cargo.Goods.Sandal = 0;
        }
    }
}

// метод обработки капитана в каюте на абордаже. Ставим проверку на минНР + дилог
// refChar - это фантом, а не реальный кэп, он копия, диалог от настоящего, но ИД и индекс не его, а фантомный, поэтому управляем имено этим актером
// CaptanId - реальный ИД кэпа, запомненный в момент копирования.
void SetQuestAboardCabinDialog(ref refChar)
{
	// контрабандный фрахт: пиратский капитан-охотник (флагман) не гибнет в абордаже - сдаётся при 10 НР и заговаривает.
	// ВАЖНО: флаг ContraHunter стоит на ОРИГИНАЛЬНОМ капитане-фантоме; в каюту приходит клон (refChar), куда
	// кастомные атрибуты НЕ копируются (ChangeAttributesFromCharacter копирует только модель/имя/ранг/...).
	// Поэтому проверяем оригинал по refChar.CaptanId (он выставлен в LAi_boarding перед вызовом).
	if (CheckAttribute(refChar, "CaptanId"))
	{
		ref chOrigHunter = characterFromId(refChar.CaptanId);
		if (CheckAttribute(chOrigHunter, "ContraHunter"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "ContraHunterCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
		// Джентльмены Удачи (перехватчик губернаторского фрахта): ЛЮБОЙ капитан эскадры сдаётся в каюте
		if (CheckAttribute(chOrigHunter, "GentlemenHunter"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			pchar.GenQuest.GentlemenReward = 100; // награда за пощаду по умолчанию +100/+100
			if (CheckAttribute(chOrigHunter, "GovEscortHalfReward")) pchar.GenQuest.GentlemenReward = 50; // перехватчики эскорта (слабый рой 6-12) - половина
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "GentlemenHunterCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
		// Каперы (перехватчик комендантского фрахта): ЛЮБОЙ капитан эскадры сдаётся в каюте
		if (CheckAttribute(chOrigHunter, "FortHunter"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "FortHunterCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
		// Посыльный вражеской нации (после отказа от его предложений): сдаётся в каюте, торгуется за конвой
		if (CheckAttribute(chOrigHunter, "FortAgentRefused"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "FortAgentCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
		// Мстители берегового братства (за вырезанных смуглеров после откупа от патруля): ЛЮБОЙ капитан говорит в каюте, пощады нет
		if (CheckAttribute(chOrigHunter, "SmugRevengeHunter"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "SmugRevengeCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
		// Взыскатели гильдии (неустойка за кидалово фрахта): капитан сдаётся в каюте, можно дать слово вернуть долг
		if (CheckAttribute(chOrigHunter, "GuildEnforcer"))
		{
			pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
			refChar.Dialog.Filename    = "Capitans_dialog.c";
			refChar.Dialog.CurrentNode = "GuildEnforcerCabin";
			refChar.nodisarm = true; // LEO: анти-стан (как у контрабандистов) - добивающий удар не оглушает, иначе каютный диалог сдачи ломается
			return;
		}
	}

	if (CheckAttribute(refChar, "CaptanId"))
	{
        pchar.GenQuest.QuestAboardCabinDialogIdx = refChar.index;
        // Gregg: ГВИК, перехват беглого капитана Компании (ветка «угроза» бунта) - в каюте ГГ решает судьбу предателя
        if (refChar.CaptanId == "GWIK_RansomShip" && CheckAttribute(pchar, "GWIK.Job.Mutiny"))
        {
            LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog"); // бессмертен на ~10 HP - откроет каютный диалог, добить нельзя
            refChar.Dialog.Filename    = "Capitans_dialog.c";
            refChar.Dialog.CurrentNode = "GWIK_MutineerCabin";
            refChar.nodisarm = true; // анти-стан: добивающий удар не оглушает, иначе каютный диалог сдачи ломается
            return;
        }
        // Gregg: Чёрная Орхидея, глава 5 - Ферегуэйро сдаётся в каюте и отдаёт вторую часть
        // Меритора (BO_Feregueyro.c, узлы 6-45). Условие вложено, а не через &&: короткого
        // замыкания в Storm нет, и однострочная цепочка читала бы PChar.DestinyGift при КАЖДОМ
        // абордаже в игре - у кого этой ветки нет, вылетал бы missed attribute.
        if (refChar.CaptanId == "Feregueyro")
        {
            if (CheckAttribute(pchar, "DestinyGift"))
            {
                LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
                refChar.Dialog.Filename    = "Quest\KPS\BlackOrchid\BO_Feregueyro.c";
                refChar.Dialog.CurrentNode = "6";
                refChar.nodisarm = true; // анти-стан: добивающий удар не оглушает, иначе каютный диалог ломается
                return;
            }
        }
        // Gregg: Чёрная Орхидея, глава 9 - в каюте чёрного мановара ждёт Полл Стронгфилд
        if (refChar.CaptanId == "CursedBlackManowar")
        {
            // Gregg: капитан проклятого мановара - нежить. При генерации ему, как и в К:ПС,
            // штатно ставится обычная пиратская модель, поэтому в каюте её меняем.
            // Не "skeletcap" из К:ПС: FaceMaker собирает по нему варианты skeletcap_1..5,
            // а в CSP лежат только skeletcap_1_1..1_5 - недостающий файл роняет абордаж.
            refChar.model = "PGG_Skeletcap_0";
            refChar.model.animation = "man";
            SetNewModelToChar(refChar);
            if (CheckAttribute(pchar, "FindAndDestroy"))
            {
                if (pchar.FindAndDestroy == "14")
                {
                    FindAndDestroyTalkInManowar("");
                    return;
                }
            }
        }
        // Gregg: Чёрная Орхидея, глава 8 - в каюте призового корабля под Тортугой стоит
        // запертый сундук с именным мушкетом, а ключ от него у самого капитана.
        if (refChar.CaptanId == "RaulEsperanto Tortuga Ship")
        {
            if (CheckAttribute(pchar, "RaulEsperanto"))
            {
                if (pchar.RaulEsperanto == "4")
                {
                    pchar.RaulEsperanto.CabinKey = pchar.location;
                    int iReCab = FindLocation(pchar.location);
                    Locations[iReCab].box1.key = "RaulEsperanto_Key";
                    Locations[iReCab].box1.key.delItem = true;
                    Locations[iReCab].box1.items.RaulEsperanto_Musket = 1;
                }
            }
        }
        // Gregg: Чёрная Орхидея, глава 7 - Харпич в каюте «Маленького ублюдка».
        // Условие вложено по той же причине, что и у Ферегуэйро выше.
        if (refChar.CaptanId == "Kharpich")
        {
            if (CheckAttribute(pchar, "SmallMongrel"))
            {
                // Gregg: Проклятые часы лежат в сундуке этой самой каюты - обыск судна,
                // о котором просил Кендарт. Сундук не заперт: ключа у Харпича нет,
                // он и сам не знал, что везёт.
                int iKhCab = FindLocation(pchar.location);
                if (iKhCab >= 0) Locations[iKhCab].box1.items.DamnedClock = 1;
                LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
                refChar.Dialog.Filename    = "Quest\KPS\BlackOrchid\BO_Breddoks.c";
                refChar.Dialog.CurrentNode = "20";
                refChar.nodisarm = true; // анти-стан: добивающий удар не оглушает, иначе каютный диалог ломается
                return;
            }
        }
        //Голл. линейка, квест №7, доставка депеши до Тортуги
        if (refChar.CaptanId == "CaptainAttack_1" && pchar.questTemp.State == "DelivLettTortuga_NotFoundLetter")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "AntonioDeBarras" && pchar.questTemp.State == "DelivLettTortuga_NotFoundLetter")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
        //Исп. линейка, квест №2, задания Инквизиции
        if (refChar.CaptanId == "JansenDeFonceicao" && CheckAttribute(pchar, "questTemp.State.Usurer"))
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//Исп. линейка, квест №3, захват Рока Бразильца
		if (refChar.CaptanId == "RockBrasilian" && pchar.questTemp.State == "TakeRockBras_toNearestMaracaibo")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//Исп. линейка, квест №7, спасение рядового Пардаля, базар с Моисеем Воклейном
		if (refChar.CaptanId == "CaptainAttack_1" && pchar.questTemp.State == "Sp7SavePardal_toAntigua")
		{
		    LAi_SetCheckMinHP(refChar, 50, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "CaptainAttack_1" && pchar.questTemp.State == "Sp7SavePardal_PardalIsSink")
		{
		    LAi_SetCheckMinHP(refChar, 50, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "CaptainAttack_1" && pchar.questTemp.State == "Sp8SaveCumana_toCumana")
		{
		    LAi_SetCheckMinHP(refChar, 50, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//фр. линейка, квест №2, атака галеона испанских пиратов
		if (refChar.CaptanId == "CaptainAttack_1" && pchar.questTemp.State == "Fr2Letter_SeekProblems")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//капитан брига, который везет Изабеллу на убой Сальватору
		if (refChar.CaptanId == "IsaAttackCap" && pchar.RomanticQuest == "AttackBrig")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//капитан по квесту мэра на поиск и уничтожение пирата.
		if (refChar.CaptanId == "MQPirate" && CheckAttribute(pchar, "GenQuest.DestroyPirate"))
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.dialog.currentnode = "DestroyPirate_Abordage";
		    return;
		}
		//засада на ГГ по наводке на купца homo
		if (findsubstr(refChar.CaptanId, "_QuestMerchant" , 0) != -1  && trap)
		{
		    LAi_SetCheckMinHP(refChar, 30, true, "QuestAboardCabinDialog");  // сколько НР мин
		    refChar.dialog.filename = "Capitans_dialog.c";  //fix homo 23/03/07
			refChar.dialog.currentnode = "MerchantTrap_Abordage";
		    return;
		}
		//капитан шебеки Синяя Птица
		if (refChar.CaptanId == "BlueBirdCapitain" && pchar.questTemp.BlueBird == "toSeaBattle")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//капитан шебеки Синяя Птица
		if (refChar.CaptanId == "BlueBirdTrader" && pchar.questTemp.BlueBird == "attackFleut")
		{
		    LAi_SetCheckMinHP(refChar, 20, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		//пиратка, Эдвард Лоу на бриге Морской Волк
		if (refChar.CaptanId == "EdwardLoy" && pchar.questTemp.piratesLine == "KillLoy_SeaWolfBattle")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "LeonCapitain" && pchar.questTemp.piratesLine == "Soukins_seekLeon")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "ContraPassCap")//генер губера - ОЗГ - пассажир
		{
		    LAi_SetCheckMinHP(refChar, 20, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "MayorQuests_dialog.c";
			refChar.Dialog.CurrentNode = "ContraPass_abordage"; //даем абордажную ноду		
		}
		if (refChar.CaptanId == "TohmasPetit_TomasShip")//Квест Томаса
		{
			if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_SecuredPeacefully"))
			{
				LAi_SetCheckMinHP(refChar, 20, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.Dialog.FileName = "Quest\IP\Thomas\all.c";
				refChar.Dialog.CurrentNode = "TohmasPetit_Cap_AbordageFOrWhat"; //даем абордажную ноду
			}
			else
			{
				LAi_SetCheckMinHP(refChar, 20, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.Dialog.FileName = "Quest\IP\Thomas\all.c";
				refChar.Dialog.CurrentNode = "TohmasPetit_Cap_Abordage"; //даем абордажную ноду
			}
		}
		//квест возврата украденного корабля
		if (findsubstr(refChar.CaptanId, "SeekCap_" , 0) != -1)
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.CurrentNode = "SeekCap"; //даем абордажную ноду
		    return;
		}
		//квест Вызволение из плена мужа горожанки
		if (refChar.CaptanId == "QuetionsPortPax_KoriBoll")
		{
		    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
		}
		// Gregg: генератор ростовщика — должник-капитан, сдаётся и говорит в каюте
		if (findsubstr(refChar.CaptanId, "LoanCap_" , 0) != -1)
		{
			LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\ForAll_dialog.c";
			refChar.Dialog.CurrentNode = "LoanCap_Board"; //даем абордажную ноду
			return;
		}
		//квест горожанина по возвращения украденной жены
		if (findsubstr(refChar.CaptanId, "SeekCitizCap_" , 0) != -1)
		{
			switch(refChar.quest.SeekCap) {
                case "manRapeWife":
                    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
                    refChar.Dialog.CurrentNode = "RapeWifeCap_Board"; //даем абордажную ноду
                break;
                case "womanRevenge":
                    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
                    refChar.Dialog.CurrentNode = "RevengeCap_board"; //даем абордажную ноду
                break;
                case "womanPirates":
                    LAi_SetCheckMinHP(refChar, 5, true, "QuestAboardCabinDialog");  // сколько НР мин
                    refChar.Dialog.CurrentNode = "PiratesCap_Board"; //даем абордажную ноду
                break;
			}
		    return;
		}
		//зачарованный город, штурм брига с Данькой
		//#20180222-04
		if (findsubstr(refChar.CaptanId, "CompPrisCap_" , 0) != -1)
		{
		    return;
		}
		if (refChar.CaptanId == "Danielle")
		{
			LAi_LocationFightDisable(loadedLocation, false);
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "FakeSlaveTrader")
		{
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.dialog.filename = "Usurer_dialog.c";
			refChar.dialog.currentnode = "Betrayal";
		    return;
		}
		if (refChar.CaptanId == "BlackBeardNPC" && CheckAttribute(pchar,"Titch_seabattle"))
		{
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetCheckMinHP(refChar, 5.0, true, "Titch_seabattle");  // сколько НР мин
		    return;
		}
		if (refChar.CaptanId == "Dozor_Ship" && PChar.Dozor == "18")//Дозорный
		{
			refChar.Dialog.FileName = "DamnedDestiny\Dozor\Characters.c";
			refChar.Dialog.CurrentNode = "Justin_Butt_1";
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
		}
		if(CheckAttribute(pchar, "GenerateShipWreck.CharacterID") && refChar.CaptanId == PChar.GenerateShipWreck.CharacterID && PChar.GenerateShipWreck.State == "CanAbordage")//shipwreck
		{
			refChar.Dialog.Filename = "DamnedDestiny\ShipWreck_dialog.c";
			refChar.Dialog.CurrentNode = "17";
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
		}
		//генератор "Продажный патруль"
		if (refChar.CaptanId == "PirateCapt")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
		}

		// Генерратор "Поручение капитана 'Выкуп' или 'Операция Галеон'"
		if(CheckAttribute(pchar,"GenQuest.CaptainComission") && pchar.GenQuest.CaptainComission == "Begin")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "GenQuests_Dialog.c";
			refChar.Dialog.CurrentNode = "CaptainComission_1"; //даем абордажную ноду
		}

		if(refChar.CaptanId == "Sharp")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\ForAll_dialog.c";
			refChar.Dialog.CurrentNode = "SharpCapitain"; //даем абордажную ноду
		}

		if(refChar.CaptanId == "zpqCaptain")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\ForAll_dialog.c";
			refChar.Dialog.CurrentNode = "zpqCapitain"; //даем абордажную ноду
		}
		if(refChar.CaptanId == "BSBons1" && refChar.model == "BS_Billy")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			refChar.Dialog.CurrentNode = "BS_NU_12";
		}
		if(refChar.CaptanId == "pirateVikingQuest_Captain")
		{
			LAi_CharacterPlaySound(refChar, "valhalla_scream");
		}
		if(findsubstr(refChar.CaptanId, "PsHero_" , 0) != -1)
		{
			sld = CharacterFromID(refChar.CaptanId);
			refChar.money = sti(sti(refChar.money)*0.3);//Ибо жирно
			// LEO баг4+5: каютный диалог даём ЛЮБОМУ ПГГ-капитану (не спутнику свиты).
			// Раньше требовался ещё PGG_Grudge -> у охотников без грудж-флага диалога не было (баг4),
			// а без диалога не ставился willDie -> ПГГ шёл в обычную смерть с шансом ресна (баг5).
			// Каютная нода PGG_cabin сама ставит willDie, а PGG_DailyUpdateEx при willDie делает ранний return -> ПГГ не воскресает.
			if(!CheckAttribute(sld, "PGG_companion"))
			{
				sld.willDie = true;
				refChar.nodisarm = true;   // анти-стан, как у каютных капитанов фрахт-охотников
				// ⚠️ ЧИСТИМ СВОИ МЕТКИ: в каюту приходит фантом из слотов 1500+, а они ПЕРЕИСПОЛЬЗУЮТСЯ
				//   без очистки атрибутов (LAi_CreateFantomCharacterEx лишь перезаписывает нужные поля).
				//   Без этого следующий капитан унаследовал бы чужие метки и получил чужой сценарий.
				DeleteAttribute(refChar, "PGG_CabinBeaten");
				DeleteAttribute(refChar, "PGG_CabinWaiting");
				// Обработчик ВСЕГДА свой, даже без охраны: только он снимает стан, без которого сбитый
				//   выстрелом капитан не убирает клинок и не отзывается. А вот ДОБИВАНИЕ - привилегия тех,
				//   у кого была охрана: бессвитному оставляем прежний бой с полного здоровья.
				if (PGG_GetCabinGuards(sld) > 0) refChar.PGG_CabinHasGuards = true;
				else DeleteAttribute(refChar, "PGG_CabinHasGuards");
				LAi_SetCheckMinHP(refChar, 10, true, "PGG_CabinCaptainDown");
				refChar.Dialog.FileName = "Quest\ForAll_dialog.c";
				refChar.Dialog.CurrentNode = "PGG_cabin"; //даем абордажную ноду
			}
			else
			{
				if(findsubstr(refChar.CaptanId, "_Trader" , 0) != -1)
				{
					ChangeCharacterNationReputation(PChar, sti(sld.Nation), -15);
				}
			}
		}
		if(refChar.CaptanId == "AntonioDeSouza")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\WhisperLine\Whisper_cabin_dialog.c";
			refChar.Dialog.CurrentNode = "DeSouza"; //даем абордажную ноду
			refChar.greeting = "GR_DeSouza";
		}
		if(refChar.CaptanId == "wl_Pirate_Cap")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\WhisperLine\Whisper_cabin_dialog.c";
			refChar.Dialog.CurrentNode = "WarDogCap"; //даем абордажную ноду
			refChar.greeting = "GR_ErnanEsteban";
		}
		if(refChar.CaptanId == "BS_Vein")
		{
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			refChar.dialog.currentnode = "BS_KS_29";
		}
		if(refChar.CaptanId == "Whisper_Portman_Captain")
		{
			if(!CheckAttribute(pchar,"Whisper.BetrayChardKill"))
			{
				LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.Dialog.FileName = "Quest\WhisperLine\Whisper_cabin_dialog.c";
				refChar.Dialog.CurrentNode = "Portman_Cabin"; //даем абордажную ноду
			}
			else
			{
				DeleteAttribute(refChar,"SaveItemsForDead");
			}
		}
		if(refChar.CaptanId == "Flint")
		{
			if(CheckAttribute(pchar,"FlintBoardingDialog"))
			{
				LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.dialog.filename = "Quest\BlackSails\BS_Final_1.c";
				refChar.dialog.currentnode = "BS_F1_35";
				BSHangover_FlintFight();
				refChar.CantLoot = true;
			}
			else
			{
				DeleteAttribute(refChar,"SaveItemsForDead");
			}
			if(CheckAttribute(PChar,"FlintCatocheBoardingDialog"))
			{
				LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.dialog.filename = "Quest\BlackSails\BS_Final_3.c";
				refChar.dialog.currentnode = "BS_F3_48";
				refChar.SaveItemsForDead = true;
			}
		}

		if (refChar.CaptanId == "GhostCapt" && CheckAttribute(pchar,"GenQuest.GhostShip.Prize"))
		{
		    LAi_SetCheckMinHP(refChar, 50, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.CurrentNode = "GhostCapt_LastDialog";
		}
		if (refChar.CaptanId == "Slaveshorecap")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\Other_Quests_NPC.c";
			refChar.Dialog.CurrentNode = "TakeShoreCap"; //даем абордажную ноду
		}
		if (refChar.CaptanId == "RatCaptain")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\Other_Quests_NPC.c";
			refChar.Dialog.CurrentNode = "Rat_talk"; //даем абордажную ноду
		}
		if (refChar.CaptanId == "Jafar")
		{
		    LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
			refChar.Dialog.FileName = "Quest\Other_Quests_NPC.c";
			refChar.Dialog.CurrentNode = "Ja_talk"; //даем абордажную ноду
		}
		if (CheckAttribute(pchar, "questTemp.Ascold.Ship") && !CheckAttribute(pchar, "questTemp.Ascold.IKnowTheShip") && !CheckCharacterItem(pchar, "ShipsJournal") && !CheckAttribute(PChar, "questTemp.Ascold.SpainCapitainDialogue"))
		{
			sld = CharacterFromID(refChar.CaptanId);
			if (CheckAttribute(sld, "Ascold.ratmark"))
			{
				LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");  // сколько НР мин
				refChar.Dialog.FileName = "Quest\Other_Quests_NPC.c";
				refChar.Dialog.CurrentNode = "AscoldSpainCapitain"; //даем абордажную ноду
			}
		}
		if (CheckAttribute(PChar, "questTemp.silverfleet") && pchar.questTemp.silverfleet == "ThirdSilverFleet")
		{	
			sld = CharacterFromID(refChar.CaptanId);			
			if (CheckAttribute(sld, "SilverSurferCap")) // СФ
			{
				LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
				refChar.Dialog.FileName = "Quest\Other_Quests_NPC.c";
				refChar.Dialog.CurrentNode = "SilverSurferCaptain";
			}
		}
		// Gregg: капитан Маугли в каюте «Бананового рая» («Корабль обезьян»).
		// Клону явно возвращаем модель с обезьяньей анимацией и макокраб вместо клинка -
		// он же оружие макак на Арене. В К:ПС тут был "unarmed_monkey", которого у нас нет.
		if (refChar.CaptanId == "Captain Monkey" && PChar.CaptainMonkey == "9")
		{
			refChar.model = "monkey";
			refChar.model.animation = "monkey";
			SetNewModelToChar(refChar);
			RemoveCharacterEquip(refChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(refChar, GUN_ITEM_TYPE);
			GiveItem2Character(refChar, "monkrab");
			EquipCharacterByItem(refChar, "monkrab");
			// Gregg: каютный кэп - это КЛОН, ранг и HP ему считает абордажная генерация,
			// и настоящие 66/900 до него не доезжали: в финале Маугли выходил 46 уровня
			// с 414 HP, слабее себя же в гроте
			refChar.rank = CM_MAUGLI_RANK;
			SetFantomParamFromRank(refChar, CM_MAUGLI_RANK, true);
			LAi_SetHP(refChar, CM_MAUGLI_HP_FINAL, CM_MAUGLI_HP_FINAL);
			// Gregg: обыскивать его нечего - лапу игрок получает скриптом за победу над
			// кораблём. Без этого FantomMakeCoolestSailor оставлял SaveItemsForDead,
			// и с тела снимался в том числе макокраб ценой в 100 000
			DeleteAttribute(refChar, "SaveItemsForDead");
			refChar.Dialog.FileName = "Quest\KPS\CaptainMonkey\CM_Maugli.c";
			refChar.Dialog.CurrentNode = "5";
			LAi_SetCheckMinHP(refChar, 10, true, "QuestAboardCabinDialog");
		}
	}
}

// ugeen --> ситуации на абордаже в каюте вражеского кэпа (эпидемия или взрыв)
void SetQuestAboardCabinDialogSituation(ref refChar)
{
	LAi_SetFightMode(pchar, false);
	LAi_LockFightMode(pchar, true);
	refChar.Dialog.FileName = "GenQuests_Dialog.c";
	switch(refChar.situation.type)
	{
		case "pirate": 	// пираты или ДУ
			refChar.Dialog.CurrentNode = "ShipSituation11";
		break;
		case "hunter": 	// ОЗГ
			refChar.Dialog.CurrentNode = "ShipSituation31";
		break;
		case "war": 	// военные корабли
			refChar.Dialog.CurrentNode = "ShipSituation21";
		break;
		case "trade": 	// торговцы
			refChar.Dialog.CurrentNode = "ShipEpidemy1";
		break;
	}
	LAi_SetActorType(refChar);
	LAi_ActorDialog(refChar, pchar, "", -1, 0);
}
// <-- ugeen
void QuestAboardCabinDialogFree()
{
	ref sld;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	Lai_SetPlayerType(pchar);
	LAi_RemoveCheckMinHP(sld);
	LAi_SetImmortal(sld, false);
    LAi_SetWarriorType(sld);
    LAi_group_MoveCharacter(sld, LAI_GROUP_BRDENEMY);
}
//выход без боевки, но в плен не надо
void QuestAboardCabinDialogNotBattle()
{
	ref sld;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	Lai_SetPlayerType(pchar);
	LAi_RemoveCheckMinHP(sld);
	LAi_SetImmortal(sld, false);
    LAi_SetWarriorType(sld);
	LAi_LocationFightDisable(loadedLocation, false);
	DoQuestCheckDelay("LAi_ReloadBoarding", 1.0);
}
// выход с боевкой
void QuestAboardCabinDialogExitWithBattle(string _questName)
{
    QuestAboardCabinDialogFree(); // важный метод
	ref sld;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	LAi_SetFightMode(pchar, true);
	LAi_SetFightMode(sld, true);
	LAi_group_SetRelation(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
    LAi_group_FightGroups(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, true);
	LAi_group_SetCheck(LAI_GROUP_BRDENEMY, _questName);
}

void QuestAboardCabinDialogExitWithBattleNoParam() // homo тоже самое, только без параметров
{
    QuestAboardCabinDialogExitWithBattle("");
}

void QuestAboardCabinDialogSurrender()
{
 	ref sld;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	DeleteAttribute(sld, "DontRansackCaptain"); // если было зачем-то
	pchar.GenQuest.QuestAboardCaptanSurrender = true;
	Lai_SetPlayerType(pchar);
	LAi_RemoveCheckMinHP(sld);
	LAi_SetImmortal(sld, false);
	DoQuestCheckDelay("LAi_ReloadBoarding", 1.0);
}
//==> квестовое пленение с сохранением индекса пленного.
void QuestAboardCabinDialogQuestSurrender()
{
	ref sld;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	sld.DontRansackCaptain = true; // чтоб не сдался второй раз
	Lai_SetPlayerType(pchar);
	LAi_RemoveCheckMinHP(sld);
	LAi_SetImmortal(sld, false);
	pchar.GenQuest.LastQuestPrisonerIdx = SetCharToPrisoner(sld);
	SetCharacterRemovable(&characters[sti(pchar.GenQuest.LastQuestPrisonerIdx)], false);
	DoQuestCheckDelay("LAi_ReloadBoarding", 1.0);
}

// eddy. лицензии торговых компаний. -->
// текст-вставка в описание грамоты (плейсхолдер #sUniNote#): универсальная (для всех наций) или обычная (голландские колонии). Определена ВЫШЕ вызовов.
string GetUniLicenceNote(bool _universal)
{
	bool bRus = (LanguageGetLanguage() == "russian");
	if (_universal)
	{
		if (bRus) return "Позволяет посещать города и порты колоний ЛЮБОЙ нации - при условии, что на мачте поднят флаг этой нации. ";
		return FrS("It allows you to visit the cities and ports of ANY nation's colonies - provided you fly that nation's flag. ", "Elle permet de visiter les villes et les ports des colonies de N'IMPORTE QUELLE nation, à condition d'arborer le pavillon de cette nation. ");
	}
	if (bRus) return "Позволяет посещать города и порты голландских колоний. ";
	return FrS("It allows you to visit the cities and ports of the Dutch colonies. ", "Elle permet de visiter les villes et les ports des colonies hollandaises. ");
}
//дать лицензию
void GiveNationLicence(int _nation, int _validity)
{
	string sTemp;
	ref rItem;
	for(int i=0; i<4; i++)
	{
		if (CheckNationLicence(i) && GetDaysContinueNationLicence(i) == -1) TakeNationLicence(i);
	}
	if (_nation != PIRATE)
	{
		if (CheckNationLicence(_nation))
		{
			if (GetDaysContinueNationLicence(_nation) > 0) _validity += GetDaysContinueNationLicence(_nation);
			TakeNationLicence(_nation);
		}
		sTemp = NationShortName(_nation)+"TradeLicence";
		GiveItem2Character(pchar, sTemp);
		rItem = ItemsFromID(sTemp);
		SaveCurrentNpcQuestDateParam(rItem, "Action_date");
		rItem.Action_date = GetCurrentDate();
		rItem.Validity = FindRussianDaysString(_validity); //строка для дескрайба
		rItem.Validity.QtyDays = _validity; //время действия лицензии в днях для расчетов
		rItem.Days_left = sti(_validity);
	}
	// HOLLAND-специфика В КОНЦЕ (после выдачи предмета, чтобы не влиять на неё): обычная голландская грамота НЕ универсальна -
	// снимаем флаг и чиним прежнюю баговую подмену имени/описания (id name/describe прежней версии могли спрятать предмет).
	// GiveUniLicence поставит флаг заново. Описание различаем плейсхолдером #sUniNote#.
	if (_nation == HOLLAND)
	{
		DeleteAttribute(pchar, "UniLicence");
		ItemsFromID("HolTradeLicence").name     = "itmname_HolTradeLicence";
		ItemsFromID("HolTradeLicence").describe = "itmdescr_HolTradeLicence";
		ItemsFromID("HolTradeLicence").UniNote  = GetUniLicenceNote(false);
	}
}
//забрать лицензию
void TakeNationLicence(int _nation)
{
	string sTemp;
	if (_nation == HOLLAND) DeleteAttribute(pchar, "UniLicence"); // забрали голландскую грамоту - универсальная тоже снимается
	if (_nation != PIRATE && CheckCharacterItem(pchar, NationShortName(_nation)+"TradeLicence"))
	{
		sTemp = NationShortName(_nation)+"TradeLicence";
		TakeItemFromCharacter(pchar, sTemp);
		DeleteAttribute(ItemsFromID(sTemp), "Action_date");
		DeleteAttribute(ItemsFromID(sTemp), "Validity");
	}
}
// УНИВЕРСАЛЬНАЯ лицензия ГВИК = ОДИН реальный предмет (голландская грамота HolTradeLicence, ГВИК - голландская
// компания) + флаг pchar.UniLicence, который заставляет её действовать для ВСЕХ наций. Нового предмета не создаём.
void GiveUniLicence(int _days)
{
	GiveNationLicence(HOLLAND, _days); // выдаёт реальный предмет HolTradeLicence (видно в инвентаре); вернёт обычное имя/описание + снимет флаг
	pchar.UniLicence = true;           // ...а мы помечаем грамоту как универсальную
	// разное описание для универсальной/обычной - через плейсхолдер #sUniNote# в ОДНОМ описании носителя (id describe НЕ меняем!)
	ItemsFromID("HolTradeLicence").UniNote = GetUniLicenceNote(true);
}
//действует ли универсальная лицензия (флаг + сам предмет-носитель на руках)
bool IsUniLicenceActive()
{
	if (!CheckAttribute(pchar, "UniLicence")) return false;
	if (!CheckCharacterItem(pchar, "HolTradeLicence")) return false;
	return true;
}

//проверить наличие лицензии (понационной ИЛИ универсальной ГВИК)
bool CheckNationLicence(int _nation)
{
	if (_nation != PIRATE)
	{
		if (CheckCharacterItem(pchar, NationShortName(_nation)+"TradeLicence")) return true;
		if (IsUniLicenceActive()) return true; // универсальная грамота ГВИК действует для любой нации
	}
	return false;
}
//проверить сроки лицензии, сколько осталось дней. если -1, то просрочена или отсутствует
int GetDaysContinueNationLicence(int _nation)
{
	int iTerms = -1;
	ref rItem;
	if (_nation != PIRATE)
	{
		string sLic = NationShortName(_nation)+"TradeLicence";
		if (!CheckCharacterItem(pchar, sLic))
		{
			// своей понационной нет - но может действует универсальная (носитель - голландская грамота)
			if (IsUniLicenceActive()) sLic = "HolTradeLicence";
			else return -1;
		}
		rItem = ItemsFromID(sLic);
		if(!CheckAttribute(rItem, "Validity")) return -1; // Warship 10.07.09 fix
		int Validity = sti(rItem.Validity.QtyDays);
		iTerms = GetNpcQuestPastDayParam(rItem, "Action_date");
		if (iTerms > Validity) iTerms = -1;
		else iTerms = Validity - iTerms;
	}
	return iTerms;
}
//дать наименование лицензии, например 'Лицензия Голландской Вест-Индской компании'
string GetRusNameNationLicence(int _nation)
{
	string sTemp, itmTitle;
	int lngFileID;
	if (_nation != PIRATE)
	{
		if (CheckCharacterItem(pchar, NationShortName(_nation)+"TradeLicence"))
		{
			sTemp = NationShortName(_nation)+"TradeLicence";
			lngFileID = LanguageOpenFile("ItemsDescribe.txt");
			itmTitle = LanguageConvertString(lngFileID, Items[GetItemIndex(sTemp)].name);
		}
		else if (IsUniLicenceActive())
		{
			if (LanguageGetLanguage() == "russian") itmTitle = "универсальная торговая лицензия ГВИК";
			else itmTitle = FrS("universal GWIK trade license", "licence de commerce universelle de la GWIC");
		}
	}
	return itmTitle;
}
// eddy. лицензии торговых компаний. <--

//--> eddy. квест Изабеллы, методы для контроля семейной жизни
//запишем текущие показтели статистики. записать так же не все, а один из показателей.
// если _TypeOfCheck == "all", то обнулить все. _TypeOfCheck может быть "KillFort", "TakeTown",
void IsabellaSetCurrentState(string _TypeOfCheck)
{
	if (_TypeOfCheck == "all" || _TypeOfCheck == "KillFort")
	{
		DeleteAttribute(pchar, "RomanticQuest.Cheking.KillFort");
		pchar.RomanticQuest.State.KillFort = Statistic_AddValue(PChar, "pir_KillFort", 0) +
											Statistic_AddValue(PChar, "eng_KillFort", 0) +
											Statistic_AddValue(PChar, "fra_KillFort", 0) +
											Statistic_AddValue(PChar, "spa_KillFort", 0) +
											Statistic_AddValue(PChar, "hol_KillFort", 0);
	}
	if (_TypeOfCheck == "all" || _TypeOfCheck == "TakeTown")
	{
		DeleteAttribute(pchar, "RomanticQuest.Cheking.TakeTown");
		pchar.RomanticQuest.State.TakeTown = Statistic_AddValue(PChar, "pir_TakeTown", 0) +
											Statistic_AddValue(PChar, "eng_TakeTown", 0) +
											Statistic_AddValue(PChar, "fra_TakeTown", 0) +
											Statistic_AddValue(PChar, "spa_TakeTown", 0) +
											Statistic_AddValue(PChar, "hol_TakeTown", 0);
	}
	if (_TypeOfCheck == "all" || _TypeOfCheck == "GrabbingTown")
	{
		DeleteAttribute(pchar, "RomanticQuest.Cheking.GrabbingTown");
		pchar.RomanticQuest.State.GrabbingTown = Statistic_AddValue(PChar, "pir_GrabbingTown", 0) +
												Statistic_AddValue(PChar, "eng_GrabbingTown", 0) +
												Statistic_AddValue(PChar, "fra_GrabbingTown", 0) +
												Statistic_AddValue(PChar, "spa_GrabbingTown", 0) +
  												Statistic_AddValue(PChar, "hol_GrabbingTown", 0);
	}
	if (_TypeOfCheck == "all" || _TypeOfCheck == "AbordShip")
	{
		DeleteAttribute(pchar, "RomanticQuest.Cheking.AbordShip");
		pchar.RomanticQuest.State.AbordShip = Statistic_AddValue(PChar, "pir_AbordShip", 0) +
											Statistic_AddValue(PChar, "eng_AbordShip", 0) +
											Statistic_AddValue(PChar, "fra_AbordShip", 0) +
											Statistic_AddValue(PChar, "spa_AbordShip", 0) +
											Statistic_AddValue(PChar, "hol_AbordShip", 0);
	}
	if (_TypeOfCheck == "all" || _TypeOfCheck == "KillShip")
	{
		DeleteAttribute(pchar, "RomanticQuest.Cheking.KillShip");
		pchar.RomanticQuest.State.KillShip = Statistic_AddValue(PChar, "pir_KillShip", 0) +
											Statistic_AddValue(PChar, "eng_KillShip", 0) +
											Statistic_AddValue(PChar, "fra_KillShip", 0) +
											Statistic_AddValue(PChar, "spa_KillShip", 0) +
											Statistic_AddValue(PChar, "hol_KillShip", 0);
	}
}
//проверим текущее состояние в рамках контроля за статистикой
void IsabellaCheckBreachState()
{
	int iTemp;
	iTemp = Statistic_AddValue(PChar, "pir_KillFort", 0) +
			Statistic_AddValue(PChar, "eng_KillFort", 0) +
			Statistic_AddValue(PChar, "fra_KillFort", 0) +
			Statistic_AddValue(PChar, "spa_KillFort", 0) +
			Statistic_AddValue(PChar, "hol_KillFort", 0);
	if (iTemp > sti(pchar.RomanticQuest.State.KillFort)) pchar.RomanticQuest.Cheking.KillFort = iTemp - sti(pchar.RomanticQuest.State.KillFort);
	iTemp = Statistic_AddValue(PChar, "pir_TakeTown", 0) +
			Statistic_AddValue(PChar, "eng_TakeTown", 0) +
			Statistic_AddValue(PChar, "fra_TakeTown", 0) +
			Statistic_AddValue(PChar, "spa_TakeTown", 0) +
			Statistic_AddValue(PChar, "hol_TakeTown", 0);
	if (iTemp > sti(pchar.RomanticQuest.State.TakeTown)) pchar.RomanticQuest.Cheking.TakeTown = iTemp - sti(pchar.RomanticQuest.State.TakeTown);
	iTemp = Statistic_AddValue(PChar, "pir_GrabbingTown", 0) +
			Statistic_AddValue(PChar, "eng_GrabbingTown", 0) +
			Statistic_AddValue(PChar, "fra_GrabbingTown", 0) +
			Statistic_AddValue(PChar, "spa_GrabbingTown", 0) +
  			Statistic_AddValue(PChar, "hol_GrabbingTown", 0);
	if (iTemp > sti(pchar.RomanticQuest.State.GrabbingTown)) pchar.RomanticQuest.Cheking.GrabbingTown = iTemp - sti(pchar.RomanticQuest.State.GrabbingTown);
	iTemp = Statistic_AddValue(PChar, "pir_AbordShip", 0) +
			Statistic_AddValue(PChar, "eng_AbordShip", 0) +
			Statistic_AddValue(PChar, "fra_AbordShip", 0) +
			Statistic_AddValue(PChar, "spa_AbordShip", 0) +
			Statistic_AddValue(PChar, "hol_AbordShip", 0);
	if (iTemp > sti(pchar.RomanticQuest.State.AbordShip)) pchar.RomanticQuest.Cheking.AbordShip = iTemp - sti(pchar.RomanticQuest.State.AbordShip);
	iTemp = Statistic_AddValue(PChar, "pir_KillShip", 0) +
			Statistic_AddValue(PChar, "eng_KillShip", 0) +
			Statistic_AddValue(PChar, "fra_KillShip", 0) +
			Statistic_AddValue(PChar, "spa_KillShip", 0) +
			Statistic_AddValue(PChar, "hol_KillShip", 0);
	if (iTemp > sti(pchar.RomanticQuest.State.KillShip)) pchar.RomanticQuest.Cheking.KillShip = iTemp - sti(pchar.RomanticQuest.State.KillShip);
	return;
}
//сбросить счетчик по семейному бюджету
void IsabellaNullBudget()
{
	pchar.RomanticQuest.Budget = "0";
	SaveCurrentQuestDateParam("RomanticQuest.Budget");
}
//возвращает текущую задолженность в деньгах. положительное значение - задолж., отрицательное - профицит.
int IsabellaCheckBudgetMoney()
{
	int Debt = GetQuestPastMonthParam("RomanticQuest.Budget")*MOD_SKILL_ENEMY_RATE*3*10000;
	int CurMoney = sti(pchar.RomanticQuest.Budget);
	return Debt - CurMoney;
}
//добавить денег на текущий баланс бюджета
void IsabellaAddMoneyBudget(int _money)
{
	pchar.RomanticQuest.Budget = sti(pchar.RomanticQuest.Budget) + _money;
	AddMoneyToCharacter(pchar, -_money);
}
// <-- eddy. квест Изабеллы, методы для контроля семейной жизни

void SelectAscoldRendom()
{
	if (CheckAttribute(&colonies[1], "nation"))
	{
		int n, nation;
		int storeArray[MAX_COLONIES];
		int howStore = 0;
		for(n=0; n<MAX_COLONIES; n++)
		{
			if (colonies[n].nation != "none" && sti(colonies[n].nation) != PIRATE && colonies[n].id != "DesMoines")
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
		nation = storeArray[rand(howStore-1)];
		pchar.questTemp.Ascold.TraderId = colonies[nation].id + "_trader";
		nation = storeArray[rand(howStore-1)];
		pchar.questTemp.Ascold.MerchantColony = colonies[nation].id;
		pchar.questTemp.Ascold.dialogNation = sti(colonies[nation].nation);
		nation = storeArray[rand(howStore-1)];
		while (colonies[nation].id == "Panama")
		{
			nation = storeArray[rand(howStore-1)];
		}

		pchar.questTemp.Ascold.ShipyarderId = colonies[nation].id + "_shipyarder";
		pchar.questTemp.Ascold.ShipyarderColony = colonies[nation].id;
		items[GetItemIndex("Azzy_bottle")].useLocation = colonies[nation].id + "_Shipyard";
	}
}
void SelectSlavetraderRendom() // работорговец, выбор города
{
	if (CheckAttribute(&colonies[1], "nation"))
	{
		int n, nation;
		int storeArray[MAX_COLONIES];
		int howStore = 0;
		for(n=0; n<MAX_COLONIES; n++)
		{
			if (colonies[n].nation != "none" && sti(colonies[n].nation) != PIRATE && colonies[n].id != "FortOrange" && colonies[n].id != "Havana" && colonies[n].id != "Santiago" && colonies[n].id != "Portroyal" && colonies[n].id != "Villemstad" && colonies[n].id != "Tortuga" && colonies[n].id != "Panama")
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
		nation = storeArray[rand(howStore-1)];
		pchar.questTemp.Slavetrader.UsurerId = colonies[nation].id + "_usurer";
	}
}
// квест Изабеллы
void IsabellaInit()
{
	//Атилла
	pchar.quest.Romantic_Pirat_Spawn.win_condition.l1 = "Rank";
	pchar.quest.Romantic_Pirat_Spawn.win_condition.l1.value = 20;
	pchar.quest.Romantic_Pirat_Spawn.win_condition.l1.operation = ">=";
	PChar.quest.Romantic_Pirat_Spawn.win_condition = "Romantic_Pirat_Spawn";
	
	ref ch;
	// ==> состояние квеста Изабеллы, если равен "" - то квест Атилла не даст.
	pchar.RomanticQuest = "canTakeQuest";
	// Злой муж :)
	ch = GetCharacter(NPC_GenerateCharacter("Husband", "Usurer_7", "man", "man", 22, PIRATE, -1, false));
	ch.name 	= GetConvertStr("Variable_QuestsUtilite_0.1", "Names.txt");
	ch.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_1", "Names.txt", "#space#", " ");
	ch.location	= "SanJuan_houseSp6";
	ch.location.group = "goto";
	ch.location.locator = "goto2";
	ch.Dialog.Filename = "Quest\Isabella\Husband.c";
	GiveItem2Character(ch, "pistol5");
	ch.equip.gun = "pistol5";
	TakeNItems(ch,"bullet", Rand(20)+20);
	AddItems(ch, "GunPowder", rand(20)+20);
	GiveItem2Character(ch, "blade34");
	ch.equip.blade = "blade34";
	ch.rank 	= 40;
	ch.reputation = 15;
    SetRandSPECIAL(ch);
    SetSelfSkill(ch, 90, 90, 90, 70, 90);
    SetShipSkill(ch, 20, 90, 10, 10, 10, 20, 10, 10, 50);
	ch.money = "1000";
	ch.SaveItemsForDead = true; // сохранять на трупе вещи
	ch.DontClearDead = true; // не убирать труп через 200с
	LAi_SetLoginTime(ch, 0.0, 24.0);
	LAi_SetHP(ch, 220.0, 220.0);
	LAi_SetHuberStayType(ch);
	LAi_SetStayHuberPointWindow(ch, "goto", "goto1");
	LAi_SetStayHuberPointMap(ch, "goto", "goto2");
	LAi_group_MoveCharacter(ch, "SPAIN_CITIZENS");
	LAi_SetImmortal(ch, true);
	LAi_LoginInCaptureTown(ch, true);
	ch.greeting = "Gr_OliverTrast";
}
//установить говорилку на горожанина. нужно по Изабелле.
void SetIsabellaTalker(string qName)
{
	ref chr = characterFromID("Isabella");
	chr.talker = 10;
}
//LEO: страховка от софтлока в доме Изабеллы: выход из спальни запирает игрока до разговора с
//     Сальватором, а тот мог и не подойти. Отпускаем, если запрет ещё висит.
void RP_afterVisitBedroom_unlock(string qName)
{
	chrDisableReloadToLocation = false;
	bDisableFastReload = false;
}
//История давней дружбы Lipsar
void SilencePriceInit()
{
	//квестовый перс Люк
	ref ch;
	ch = GetCharacter(NPC_GenerateCharacter("Old Friend", "officer_34", "man", "man", 30, PIRATE, -1, false));
	ch.name = GetConvertStr("Variable_QuestsUtilite_2", "Names.txt");
	ch.lastname = GetConvertStr("Variable_QuestsUtilite_3", "Names.txt");
	ch.location	= "Bridgetown_town";
	ch.location.group = "goto";
	ch.location.locator = "goto1";
	ch.Dialog.Filename = "Quest\SilencePrice\Luke.c";
	FantomMakeCoolFighter(ch, 30, 90, 50, "blade44", "pistol9", 300);
	GiveItem2Character(ch, "cirass1");
	ch.equip.cirass = "cirass1";
	ch.rank = 30;
	ch.talker = -1;
	SelAllPerksToNotPchar(ch);
	ch.SaveItemsForDead = true;
	AddBonusEnergyToCharacter(ch, 50);
	SetSelfSkill(ch, 80, 100, 100, 100, 100);
	SetShipSkill(ch, 80, 80, 80, 80, 80, 80, 80, 80, 80);
	LAi_SetImmortal(ch, true);
	LAi_SetCitizenType(ch);
	LAi_SetLoginTime(ch, 0.0, 24.0);
	ch.greeting = "Gr_Atilla";
	ChangeCharacterAddressGroup(ch, "LaVega_town", "goto", "goto15");
}
//Проклятие Дальних Морей
void PDMQuestsInit()
{
	ref sld;
	//******Альбрехт Цальпфер Sinistra******
	//Альбрехт Цальпфер
	sld = GetCharacter(NPC_GenerateCharacter("Albreht_Zalpfer", "Mechanic", "man", "man", 6, ENGLAND, -1, false));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.1", "Names.txt");
	sld.lastname	= GetConvertStr("Variable_QuestsUtilite_3.2", "Names.txt");
	sld.Dialog.Filename = "Quest\PDM\Albreht_Zalpfer.c";
	sld.greeting = "GR_Kakovi_Merzavczi";
	GiveItem2Character(sld, "topor_05");
	EquipCharacterByItem(sld, "topor_05");
	SetCharacterPerk(sld, "Carpenter");
	SetCharacterPerk(sld, "BasicBattleState");
	SetShipSkill(sld, 2, 3, 2, 3, 1, 21, 3, 1, 2);
	sld.CompanionDisable = true;
	sld.talker = 6;
	LAi_SetLoginTime(sld, 6.0, 21.99);
	LAi_SetCitizenType(sld);
	LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
	LAi_SetImmortal(sld, false);
	ChangeCharacterAddressGroup(sld,"Charles_town","goto","goto22");

	//******Проклятый идол Sinistra******
	//Джеймс Кэллоу
	pchar.quest.PDM_CI_SpawnJC.win_condition.l1 = "Rank";
	pchar.quest.PDM_CI_SpawnJC.win_condition.l1.value = 3;
	pchar.quest.PDM_CI_SpawnJC.win_condition.l1.operation = ">=";
	PChar.quest.PDM_CI_SpawnJC.win_condition = "PDM_CI_SpawnJC";

	//******В поисках новой родины Sinistra******
	//Хьюго Лесопилка
	sld = GetCharacter(NPC_GenerateCharacter("Hugo_Lesopilka", "officer_40", "man", "man", 10, PIRATE, -1, true));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.3", "Names.txt");
	sld.lastname	= GetConvertStr("Variable_QuestsUtilite_3.4", "Names.txt");
	sld.sex = "man";
	sld.Dialog.Filename = "Quest\PDM\Novaya_Rodina.c";
	LAi_SetSitType(sld);
	LAi_SetImmortal(sld, true);
	ChangeCharacterAddressGroup(sld,"PuertoPrincipe_tavern","sit","sit_front2");

	//******Потерянное кольцо Sinistra******
	//Жозефина Лодет
	sld = GetCharacter(NPC_GenerateCharacter("Josephine_Lodet", "BaynesWife", "woman", "woman", 10, FRANCE, -1, false));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.5", "Names.txt");
	sld.lastname	= "";
	sld.Dialog.Filename = "Quest\PDM\Poteryanoe_Koltso.c";
	LAi_SetCitizenType(sld);
	LAi_SetLoginTime(sld, 6.0, 21.99);
	sld.talker = 7;
	LAi_SetImmortal(sld, true);
	LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
	sld.City = "BasTer";
	ChangeCharacterAddressGroup(sld,"BasTer_town","goto","goto4");
	
	//******Непутёвый казначей Sinistra******
	//Андреас Фиклер
	pchar.quest.PDM_NK_Nachalo.win_condition.l1 = "Rank";
	pchar.quest.PDM_NK_Nachalo.win_condition.l1.value = 3;
	pchar.quest.PDM_NK_Nachalo.win_condition.l1.operation = ">=";
	PChar.quest.PDM_NK_Nachalo.win_condition = "PDM_NK_Nachalo";

	//******Клан Ламбрини Sinistra******
	//Октавио Ламбрини
	sld = GetCharacter(NPC_GenerateCharacter("PDM_Octavio_Lambrini", "barmen_3", "man", "man", 10, PIRATE, -1, true));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.6", "Names.txt");
	sld.lastname	= GetConvertStr("Variable_QuestsUtilite_3.7", "Names.txt");
	sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
	LAi_SetSitType(sld);
	LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
	ChangeCharacterAddressGroup(sld,"PortSpein_tavern","sit","sit_front2");
	//******Проклятая жара Sinistra******
	//Стражники
	sld = GetCharacter(NPC_GenerateCharacter("PDM_PJ_Strajnik_1", "sold_fra_5KSM", "man", "manKSM", 10, FRANCE, -1, false));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.8", "Names.txt");
	sld.lastname	= "";
	sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
	LAi_SetLoginTime(sld, 6.0, 21.99);
	sld.talker = 7;
	LAi_SetStayType(sld);
	FantomMakeCoolFighter(sld, 25, 25, 25, "blade10", "", 40);
	LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
	sld.City = "FortFrance";
	ChangeCharacterAddressGroup(sld,"FortFrance_town","officers","soldier_uniq2");

	sld = GetCharacter(NPC_GenerateCharacter("PDM_PJ_Strajnik_2", "sold_fra_1", "man", "man", 10, FRANCE, -1, false));
	sld.name	= GetConvertStr("Variable_QuestsUtilite_3.9", "Names.txt");
	sld.lastname	= "";
	sld.dialog.filename   = "Common_Soldier.c";
	LAi_SetLoginTime(sld, 6.0, 21.99);
	LAi_SetGuardianType(sld);
	FantomMakeCoolFighter(sld, 25, 25, 25, "blade10", "", 40);
	LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
	sld.City = "FortFrance";
	ChangeCharacterAddressGroup(sld,"FortFrance_town","officers","soldier_uniq1");

	//******Аптекарь Sinistra******
	//Аптекарь
	sld = GetCharacter(NPC_GenerateCharacter("Doktor_Alumnus", "Alumnus", "man", "man", 10, HOLLAND, -1, false));
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_4", "Names.txt", "#space#", " ");
	sld.lastname = "";
	LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
	LAi_SetBarmanType(sld);
	sld.greeting = "GR_Doctor_Alumnus";
	sld.dialog.filename   = "Quest\PDM\Aptekar.c";
	sld.dialog.currentnode   = "First time";
	sld.City = "Marigo";
	ChangeCharacterAddressGroup(sld,"Farmacia","barmen","stay");
	
	//******Охота на ведьму Sinistra******
	//Бартоломью Ольстер
	pchar.quest.PDM_ONV_Nachalo.win_condition.l1 = "Rank";
	pchar.quest.PDM_ONV_Nachalo.win_condition.l1.value = 15;
	pchar.quest.PDM_ONV_Nachalo.win_condition.l1.operation = ">=";
	PChar.quest.PDM_ONV_Nachalo.win_condition = "PDM_ONV_Nachalo";
}
//Пираты Карибского Моря
void PKMQuestsInit()
{
	//******Странные вещи творятся на архипелаге******
	//Девушки ищут детей
	pchar.quest.PKM_SvtvA_SpawnQuest.win_condition.l1 = "Rank";
	pchar.quest.PKM_SvtvA_SpawnQuest.win_condition.l1.value = 10;
	pchar.quest.PKM_SvtvA_SpawnQuest.win_condition.l1.operation = ">=";
	PChar.quest.PKM_SvtvA_SpawnQuest.win_condition = "PKM_SvtvA_SpawnQuest";
}
//Сундук Мертвеца
void KSMQuestsInit()
{
	//******Спасение на рифах******
	//Джеймс Аллока
	pchar.quest.KSM_Snr_Alloka_Spawn.win_condition.l1 = "Rank";
	pchar.quest.KSM_Snr_Alloka_Spawn.win_condition.l1.value = 5;
	pchar.quest.KSM_Snr_Alloka_Spawn.win_condition.l1.operation = ">=";
	PChar.quest.KSM_Snr_Alloka_Spawn.win_condition = "KSM_Snr_Alloka_Spawn";
	Island_SetReloadEnableLocal("Reefs", "reload_3", false)
	Island_SetGotoEnableLocal("Reefs", "reload_3", false);
}
//Проклятые Судьбой
void KPSQuestsInit()
{
	//******Загадочный остров******
	//Джим Смит
	pchar.quest.KPS_ZO_JimSmit_Spawn.win_condition.l1 = "Rank";
	pchar.quest.KPS_ZO_JimSmit_Spawn.win_condition.l1.value = 15;
	pchar.quest.KPS_ZO_JimSmit_Spawn.win_condition.l1.operation = ">=";
	PChar.quest.KPS_ZO_JimSmit_Spawn.win_condition = "KPS_ZO_JimSmit_Spawn";
}
//Все остальные НПС
void VSEnpcInit()
{
	int iChar, i, iSex;
	string sTemp, sType;;
	ref sld;
	//Стражники в адмиралтействе
	sld = GetCharacter(NPC_GenerateCharacter("VSE_Admir_1", "sold_spa_2", "man", "man", 10, SPAIN, -1, true));
	sld.Dialog.Filename = "Admiralty.c";
	sld.dialog.currentnode = "Strajniki";
	LAi_SetGuardianType(sld);
	LAi_SetImmortal(sld, true);
	LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
	sld.city = "SantoDomingo";
	ChangeCharacterAddressGroup(sld,"SantoDomingo_Admiralty","soldiers","soldier1");
	
	sld = GetCharacter(NPC_GenerateCharacter("VSE_Admir_2", "sold_spa_1", "man", "man", 10, SPAIN, -1, true));
	sld.Dialog.Filename = "Admiralty.c";
	sld.dialog.currentnode = "Strajniki";
	LAi_SetGuardianType(sld);
	LAi_SetImmortal(sld, true);
	LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
	sld.city = "SantoDomingo";
	ChangeCharacterAddressGroup(sld,"SantoDomingo_Admiralty","soldiers","soldier2");
	
	sld = GetCharacter(NPC_GenerateCharacter("VSE_Admir_3", "sold_spa_3", "man", "man", 10, SPAIN, -1, true));
	sld.Dialog.Filename = "Admiralty.c";
	sld.dialog.currentnode = "Strajniki";
	sld.CityType = "soldier";
	LAi_SetPatrolType(sld);
	LAi_SetImmortal(sld, true);
	LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
	sld.city = "SantoDomingo";
	ChangeCharacterAddressGroup(sld,"SantoDomingo_Admiralty","goto","goto2");
	
	//Глаша уборщица в резиденции Мариго
	sld = GetCharacter(NPC_GenerateCharacter("CleanUpGrandmatha", "BaynesWife", "woman", "towngirl", 1, Holland, -1, false));
	ChangeCharacterAddressGroup(sld, "Marigo_hall", "goto", "goto11");
	LAi_SetCitizenType(sld);
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_5", "Names.txt", "#space#", " ");
	sld.lastname = "";
	LAi_SetLoginTime(sld, 11.0, 16.99);
	LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
	sld.city = "Marigo";
	sld.dialog.filename = "Janitor.c";
	sld.dialog.currentnode = "First";
	
	//Девушка с нежданным наследством
	pchar.quest.CSP_NN_SpawnGirl.win_condition.l1 = "Rank";
	pchar.quest.CSP_NN_SpawnGirl.win_condition.l1.value = 10;
	pchar.quest.CSP_NN_SpawnGirl.win_condition.l1.operation = ">=";
	PChar.quest.CSP_NN_SpawnGirl.function = "UnexpectedInheritance";
	
	//Джеки
	sld = GetCharacter(NPC_GenerateCharacter("MG_Obezyana", "Koata1", "monkey", "monkey", 1, PIRATE, -1, false));
	LAi_SetHP(sld, 1.0, 1.0);
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_6", "Names.txt", "#space#", " ");
	sld.lastname = "";
	LAi_SetWarriorType(sld);
	LAi_CharacterDisableDialog(sld);
	ChangeCharacterAddressGroup(sld, "Guadeloupe_deadlock", "monsters", "monster6");
	
	PChar.quest.MG_ObezyanaKill.win_condition.l1 = "NPC_Death";
	PChar.quest.MG_ObezyanaKill.win_condition.l1.character = "MG_Obezyana";
	PChar.quest.MG_ObezyanaKill.win_condition = "MG_ObezyanaKill";
	
	//Антонио де Соуза, Глава Инквизиции
	sld = GetCharacter(NPC_GenerateCharacter("AntonioDeSouza", "priest", "man", "man1", 10, SPAIN, -1, false));
    sld.name 	= GetConvertStr("Variable_QuestsUtilite_0.2", "Names.txt");
    sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_7", "Names.txt", "#space#", " ");
	sld.model.animation = "man1";
    sld.Dialog.Filename = "Quest\AntonioDeSouza.c";
	sld.greeting = "Gr_padre";
    LAi_SetHuberType(sld);
	LAi_SetImmortal(sld, true);
    LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
    ChangeCharacterAddressGroup(sld, "Santiago_Incquisitio", "sit", "armchair1");
	
	//Квест "Кот в мешке"
	pchar.quest.CSP_KvM_SpawnRibak.win_condition.l1 = "Rank";
	pchar.quest.CSP_KvM_SpawnRibak.win_condition.l1.value = 5;
	pchar.quest.CSP_KvM_SpawnRibak.win_condition.l1.operation = ">=";
	PChar.quest.CSP_KvM_SpawnRibak.win_condition = "CSP_KvM_SpawnRibak";
	
//============== Локаторы для вызова акулы =================
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula1 = 1.0;
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula2 = 2.0;
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula3 = 1.8;
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula4 = 1.5;
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula5 = 1.5;
	Locations[FindLocation("SantoDomingo_town")].locators_radius.item.akula6 = 1.5;
	
//============== Индейская деревня =================	

	//Шаманка Чани
	sld = GetCharacter(NPC_GenerateCharacter("Chani", "PGG_Chani", "woman", "Chani", 10, PIRATE, -1, false));
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_8", "Names.txt", "#space#", " ");
	sld.lastname = "";
	sld.dialog.Filename = "Indian_dialog.c";
	sld.dialog.currentnode = "Chani_1";
	LAi_SetOwnerType(sld);
	SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
	LAi_group_MoveCharacter(sld, "ItzaIndian");
	ChangeCharacterAddressGroup(sld, "Indian_Hut1", "barmen", "stay");
	
	SetCharacterPerk(sld, "BasicDefense");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "ByWorker");
	SetCharacterPerk(sld, "ByWorker2");
	SetCharacterPerk(sld, "IronWill");
	SetCharacterPerk(sld, "Doctor1");
	SetCharacterPerk(sld, "Doctor2");
	SetCharacterPerk(sld, "EmergentSurgeon");
	SetCharacterPerk(sld, "Energaiser");
	SetSPECIAL(sld, 6,5,8,5,9,10,5);
	SetSelfSkill(sld, 60,40,40,1,30);
	SetShipSkill(sld, 50,4,1,1,1,15,20,60,40);

	//Красавица Шоко
	sld = GetCharacter(NPC_GenerateCharacter("ItzaKrasavitsa", "TribeWife", "woman", "YokoDias", 10, PIRATE, -1, false));
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_9", "Names.txt", "#space#", " ");
	sld.lastname = "";
	sld.dialog.Filename = "Indian_dialog.c";
	sld.dialog.currentnode = "Shoko_1";
	LAi_SetCitizenType(sld);
	LAi_group_MoveCharacter(sld, "ItzaIndian");
	ChangeCharacterAddressGroup(sld, "IndianVillage", "quest", "teleport1");

	//******Макуауитль Куали******
	//Воин Куали
	pchar.quest.Kuali_Spawn.win_condition.l1 = "Rank";
	pchar.quest.Kuali_Spawn.win_condition.l1.value = 5;
	pchar.quest.Kuali_Spawn.win_condition.l1.operation = ">=";
	PChar.quest.Kuali_Spawn.win_condition = "Kuali_Spawn";
}
void OfficerGirlInit()
{
    ref sld;

    // Бывшая Данька. АйДи не меняю, т.к. нужно сменить просто модель и анимацию
    sld = GetCharacter(NPC_GenerateCharacter("Daniel", "PGG_YokoDias_0", "woman", "YokoDias", 15, PIRATE, -1, false));
	sld.name 	= GetConvertStr("Variable_QuestsUtilite_0.3", "Names.txt");
	sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_10", "Names.txt", "#space#", " ");
	sld.loyality = 12;
	sld.rank 	= 15;
    sld.reputation = 85; // good девочка
	sld.alignment = "good";
	// Прописка всех моделей для кирас. -->
	sld.HeroModel = "PGG_YokoDias_0,PGG_YokoDias_1,PGG_YokoDias_2,PGG_YokoDias_3,PGG_YokoDias_4,PGG_YokoDias_5,PGG_YokoDias_6,PGG_YokoDias_7,PGG_YokoDias_8";
	// Прописка всех моделей для кирас. <--
	GiveItem2Character(sld, "blade5");
	TakeNItems(sld,"potion2", Rand(4)+1);
	sld.equip.blade = "blade5";
	GiveItem2Character(sld, "pistol2");
	sld.equip.gun = "pistol2";
    TakeNItems(sld,"bullet", Rand(20)+20);
	AddItems(sld, "GunPowder", rand(20)+20);
    sld.Payment = true;
    sld.HoldEquip = false; // не отдавать саблю и пистоль

	sld.location	= "Pirates_town";
	sld.location.group = "goto";
	sld.location.locator = "goto20";
	sld.dialog.filename   = "Enc_OfficerGirl.c";
	sld.dialog.currentnode = "Yoko_meet";
	sld.greeting = "Gr_Danielle";
	sld.money = 0;
 	SetSPECIAL(sld, 9,4,8,6,7,8,6);
	//f_l, f, f_h, p, f
	SetSelfSkill(sld, 43,25,69,45,46);
	// l, c, a, cn, sl, re, gr, de, sn
	SetShipSkill(sld, 45,13,23,34,24,43,54,62,40);
	// LEO: рандомный набор перков убран - у этих троих перки прописаны явно ниже, а LAi_NPC_EquipPerk добирал их через rand()
	sld.perks.list.BasicDefense = true;
    sld.perks.list.AdvancedDefense = true;
    sld.perks.list.SwordplayProfessional = true;
    sld.perks.list.CriticalHit = true;
    sld.perks.list.Gunman = true;
    sld.perks.list.GunProfessional = true;
    sld.perks.list.Energaiser = true;
	sld.perks.list.Ciras = true;
	sld.perks.list.LongRangeGrappling = true;
    LAi_NoRebirthEnable(sld);
    LAi_SetWarriorType(sld);
    LAi_warrior_DialogEnable(sld, true);
    LAi_SetLoginTime(sld, 0.0, 24.0);
    SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
	LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");

	sld = GetCharacter(NPC_GenerateCharacter("Beatrice", "PGG_Rumba", "woman", "Milenace", 15, PIRATE, -1, false));
	sld.name 	= GetConvertStr("Variable_QuestsUtilite_0.4", "Names.txt");
	sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_11", "Names.txt", "#space#", " ");
	sld.loyality = 20;
	sld.rank 	= 15;
    sld.reputation = 50;
	sld.alignment = "good";
	sld.HeroModel = "PGG_Rumba_0,PGG_Rumba_1,PGG_Rumba_2,PGG_Rumba_3,PGG_Rumba_4,PGG_Rumba_5";
	GiveItem2Character(sld, "blade36");
	TakeNItems(sld,"potion2", Rand(4)+1);
	sld.equip.blade = "blade36";
	GiveItem2Character(sld, "pistol2");
	sld.equip.gun = "pistol2";
    TakeNItems(sld,"bullet", Rand(20)+20);
	AddItems(sld, "GunPowder", rand(20)+20);
    sld.Payment = true;
    sld.HoldEquip = false; // не отдавать саблю и пистоль

	sld.location	= "PuertoPrincipe_town";
	sld.location.group = "goto";
	sld.location.locator = "goto6";
	sld.dialog.filename   = "Enc_OfficerGirl.c";
	sld.dialog.currentnode = "Helen_meet";
	sld.greeting = "Gr_Danielle";
	sld.money = 0;
  	SetSPECIAL(sld, 6,8,7,6,7,9,5);
	//f_l, f, f_h, p, f
	SetSelfSkill(sld, 68,23,38,45,44);
	// l, c, a, cn, sl, re, gr, de, sn
	SetShipSkill(sld, 30,15,35,40,45,22,33,21,34);
	// LEO: рандомный набор перков убран - у этих троих перки прописаны явно ниже, а LAi_NPC_EquipPerk добирал их через rand()
	sld.perks.list.BasicDefense = true;
    sld.perks.list.AdvancedDefense = true;
    sld.perks.list.SwordplayProfessional = true;
    sld.perks.list.CriticalHit = true;
    sld.perks.list.Gunman = true;
    sld.perks.list.GunProfessional = true;
    sld.perks.list.Energaiser = true;
	sld.perks.list.Ciras = true;
	sld.perks.list.ShipSpeedUp = true;
    LAi_NoRebirthEnable(sld);
    LAi_SetWarriorType(sld);
    LAi_warrior_DialogEnable(sld, true);
    LAi_SetLoginTime(sld, 0.0, 24.0);
    SetFantomHP(sld);
    LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");

	sld = GetCharacter(NPC_GenerateCharacter("Angellica", "PGG_Angellica", "woman", "Milenace", 15, PIRATE, -1, false));
	sld.name 	= GetConvertStr("Variable_QuestsUtilite_0.5", "Names.txt");
	sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_12", "Names.txt", "#space#", " ");
	sld.loyality = 20;
	sld.rank 	= 15;
    sld.reputation = 15;
	sld.alignment = "bad";
	GiveItem2Character(sld, "blade34");
	TakeNItems(sld,"potion2", Rand(4)+1);
	sld.equip.blade = "blade34";
	GiveItem2Character(sld, "pistol2");
	sld.equip.gun = "pistol2";
    TakeNItems(sld,"bullet", Rand(20)+20);
	AddItems(sld, "GunPowder", rand(20)+20);
    sld.Payment = true;
    sld.HoldEquip = false; // не отдавать саблю и пистоль

	sld.location	= "LeFransua_town";
	sld.location.group = "rld";
	sld.location.locator = "loc0";
	sld.dialog.filename   = "Enc_OfficerGirl.c";
	sld.dialog.currentnode = "Angellica_meet";
	sld.greeting = "Gr_Danielle";
	sld.money = 0;
  	SetSPECIAL(sld, 7,8,7,5,7,9,5);
	//f_l, f, f_h, p, f
	SetSelfSkill(sld, 23,68,38,35,33);
	// l, c, a, cn, sl, re, gr, de, sn
	SetShipSkill(sld, 45,33,55,56,35,22,33,21,34);
	// LEO: рандомный набор перков убран - у этих троих перки прописаны явно ниже, а LAi_NPC_EquipPerk добирал их через rand()
	sld.perks.list.BasicDefense = true;
    sld.perks.list.AdvancedDefense = true;
    sld.perks.list.SwordplayProfessional = true;
    sld.perks.list.CriticalHit = true;
    sld.perks.list.Gunman = true;
    sld.perks.list.GunProfessional = true;
    sld.perks.list.Energaiser = true;
	sld.perks.list.Ciras = true;
	sld.perks.list.HullDamageUp = true;
    LAi_NoRebirthEnable(sld);
    LAi_SetWarriorType(sld);
    LAi_warrior_DialogEnable(sld, true);
    LAi_SetLoginTime(sld, 0.0, 24.0);
    SetFantomHP(sld);
    LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
}

void OfficerMushketerInit()
{
    ref sld;
    //мушкетер №1 - пират
    sld = GetCharacter(NPC_GenerateCharacter("OfMush1", "quest_mush_2", "man", "mushketer", 15, PIRATE, -1, true));
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_13", "Names.txt", "#space#", " ");
	sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_14", "Names.txt", "#space#", " ");
	sld.greeting = "Gr_Officer";
	sld.loyality = 18;
	sld.rank = 15;
	//Прописка всех моделей для кирас. -->
	sld.HeroModel = "quest_mush_2,quest_mush_2_1,quest_mush_2_2,quest_mush_2_3,quest_mush_2_4,quest_mush_2_5";
	//Прописка всех моделей для кирас. <--
	sld.reputation = 15;
	sld.alignment = "bad";
	SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
	sld.Dialog.Filename = "Enc_OfficerMush.c";
	sld.dialog.currentnode = "Lostpirate";
	TakeNItems(sld,"potion2", Rand(2)+2);
	sld.IsMushketer = true;
	sld.CanTakeMushket = true;
	sld.equip.gun = "mushket";
	sld.IsMushketer.LastGunID = -1;
	sld.IsMushketer.MushketID = "mushket";
    TakeNItems(sld,"bullet", 100);
	AddItems(sld, "GunPowder", 100);
    sld.Payment = true;
    sld.HoldEquip = false; // не отдавать саблю и пистоль
	sld.location	= "Shore59";
	sld.location.group = "goto";
	sld.location.locator = "goto3";
	sld.money = 0;
	sld.SuperShooter  = true;
 	SetSPECIAL(sld, 6, 9, 8, 3, 6, 9, 9);
	SetSelfSkill(sld, 60, 3, 3, 100, 80);
	SetShipSkill(sld, 40, 7, 25, 15, 8, 10, 5, 10, 25);
	DeleteAllPerksExceptChar(sld);
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "Gunman");
	SetCharacterPerk(sld, "GunProfessional");
	SetCharacterPerk(sld, "Energaiser");
	SetCharacterPerk(sld, "HPPlus");
    LAi_SetWarriorType(sld);
	LAi_warrior_DialogEnable(sld, true);
	LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
	locations[FindLocation("Shore59")].DisableEncounters = true; //энкаутеры в локации закроем до поры

	//мушкетер №2 - саксонец
	sld = GetCharacter(NPC_GenerateCharacter("OfMush2", "quest_mush_1", "man", "mushketer", 18, SPAIN, -1, true));
	sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_15", "Names.txt", "#space#", " ");
	sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_16", "Names.txt", "#space#", " ");
	sld.greeting = "Gr_Officer";
	sld.loyality = 13;
	sld.rank = 15;
	sld.reputation = 85;
	//Прописка всех моделей для кирас. -->
	sld.HeroModel = "quest_mush_1,quest_mush_1_1,quest_mush_1_2,quest_mush_1_3,quest_mush_1_4,quest_mush_1_5";
	//Прописка всех моделей для кирас. <--
	sld.alignment = "good";
	SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
	sld.Dialog.Filename = "Enc_OfficerMush.c";
	sld.dialog.currentnode = "Saxon";
	TakeNItems(sld,"potion2", Rand(2)+2);
	sld.IsMushketer = true;
	sld.CanTakeMushket = true;
	sld.equip.gun = "mushket";
	GiveItem2Character(sld, "cirass2");
	sld.IsMushketer.LastGunID = -1;
	sld.IsMushketer.MushketID = "mushket";
	EquipCharacterbyItem(sld, "cirass2");
    TakeNItems(sld,"bullet", 100);
	AddItems(sld, "GunPowder", 100);
    sld.Payment = true;
    sld.HoldEquip = false; // не отдавать саблю и пистоль
	sld.location	= "Santodomingo_town";
	sld.location.group = "goto";
	sld.location.locator = "goto10";
	sld.money = 0;
	sld.SuperShooter  = true;
 	SetSPECIAL(sld, 7, 9, 7, 4, 3, 10, 8);
	SetSelfSkill(sld, 70, 10, 10, 100, 70);
	SetShipSkill(sld, 30, 9, 8, 8, 15, 20, 18, 5, 30);
	DeleteAllPerksExceptChar(sld);
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "Gunman");
	SetCharacterPerk(sld, "GunProfessional");
	SetCharacterPerk(sld, "Energaiser");
	SetCharacterPerk(sld, "IronWill");
	SetCharacterPerk(sld, "Ciras");
    LAi_SetWarriorType(sld);
    LAi_warrior_DialogEnable(sld, true);
	LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
}

string CharToLower(string charstr) {
	switch(charstr)
	{
		case "А": return "а"; break;
		case "Б": return "б"; break;
		case "В": return "в"; break;
		case "Г": return "г"; break;
		case "Д": return "д"; break;
		case "Е": return "е"; break;
		case "Ё": return "ё"; break;
		case "Ж": return "ж"; break;
		case "З": return "з"; break;
		case "И": return "и"; break;
		case "Й": return "й"; break;
		case "К": return "к"; break;
		case "Л": return "л"; break;
		case "М": return "м"; break;
		case "Н": return "н"; break;
		case "О": return "о"; break;
		case "П": return "п"; break;
		case "Р": return "р"; break;
		case "С": return "с"; break;
		case "Т": return "т"; break;
		case "У": return "у"; break;
		case "Ф": return "ф"; break;
		case "Х": return "х"; break;
		case "Ц": return "ц"; break;
		case "Ч": return "ч"; break;
		case "Ш": return "ш"; break;
		case "Щ": return "щ"; break;
		case "Э": return "э"; break;
		case "Ю": return "ю"; break;
		case "Я": return "я"; break;

		case "A": return "a"; break;
		case "B": return "b"; break;
		case "C": return "c"; break;
		case "D": return "d"; break;
		case "E": return "e"; break;
		case "F": return "f"; break;
		case "G": return "g"; break;
		case "H": return "h"; break;
		case "I": return "i"; break;
		case "J": return "j"; break;
		case "K": return "k"; break;
		case "L": return "l"; break;
		case "M": return "m"; break;
		case "N": return "n"; break;
		case "O": return "o"; break;
		case "P": return "p"; break;
		case "Q": return "q"; break;
		case "R": return "r"; break;
		case "S": return "s"; break;
		case "T": return "t"; break;
		case "U": return "u"; break;
		case "V": return "v"; break;
		case "W": return "w"; break;
		case "X": return "x"; break;
		case "Y": return "y"; break;
		case "Z": return "z"; break;
	}
	return charstr;
}

string CharToUpper(string charstr) {
	switch(charstr)
	{
		case "а": return "А"; break;
		case "б": return "Б"; break;
		case "в": return "В"; break;
		case "г": return "Г"; break;
		case "д": return "Д"; break;
		case "е": return "Е"; break;
		case "ё": return "Ё"; break;
		case "ж": return "Ж"; break;
		case "з": return "З"; break;
		case "и": return "И"; break;
		case "й": return "Й"; break;
		case "к": return "К"; break;
		case "л": return "Л"; break;
		case "м": return "М"; break;
		case "н": return "Н"; break;
		case "о": return "О"; break;
		case "п": return "П"; break;
		case "р": return "Р"; break;
		case "с": return "С"; break;
		case "т": return "Т"; break;
		case "у": return "У"; break;
		case "ф": return "Ф"; break;
		case "х": return "Х"; break;
		case "ц": return "Ц"; break;
		case "ч": return "Ч"; break;
		case "ш": return "Ш"; break;
		case "щ": return "Щ"; break;
		case "э": return "Э"; break;
		case "ю": return "Ю"; break;
		case "я": return "Я"; break;

		case "a": return "A"; break;
		case "b": return "B"; break;
		case "c": return "C"; break;
		case "d": return "D"; break;
		case "e": return "E"; break;
		case "f": return "F"; break;
		case "g": return "G"; break;
		case "h": return "H"; break;
		case "i": return "I"; break;
		case "j": return "J"; break;
		case "k": return "K"; break;
		case "l": return "L"; break;
		case "m": return "M"; break;
		case "n": return "N"; break;
		case "o": return "O"; break;
		case "p": return "P"; break;
		case "q": return "Q"; break;
		case "r": return "R"; break;
		case "s": return "S"; break;
		case "t": return "T"; break;
		case "u": return "U"; break;
		case "v": return "V"; break;
		case "w": return "W"; break;
		case "x": return "X"; break;
		case "y": return "Y"; break;
		case "z": return "Z"; break;
	}
	return charstr;
}

// строку в нижний регистр
string GetStrSmallRegister(string _text)
{
	string retString, symbol;
	retString = "";
	int length = strlen(_text);

	for(int i = 0; i < length; i++)
	{
		symbol = GetSymbol(_text, i);
		retString += CharToLower(symbol);
	}

	return retString;
}

// строку в верхний регистр
string ToUpper(string _text)
{
	string retString, symbol;
	retString = "";
	int length = strlen(_text);

	for(int i = 0; i < length; i++)
	{
		symbol = GetSymbol(_text, i);
		retString += CharToUpper(symbol);
	}

	return retString;
}

// Первый символ в верхний регистр
string UpperFirst(string _text)
{
	string first = GetSymbol(_text, 0);
	string last = strcut(_text, 2, strlen(_text) - 1);
	return CharToUpper(first) + last;
}

// Первый символ в нижний регистр
string LowerFirst(string _text)
{
	string first = GetSymbol(_text, 0);
	first = GetStrSmallRegister(first);
	string last = strcut(_text, 2, strlen(_text) - 1);
	return first + last;
}
// <--

//===>>> постановка прерываний на жемчужный генератор
void PearlGen_SetSantaCatalina(string sQuest)
{
	pchar.quest.PearlGen_checkSantaCatalina.win_condition.l1 = "location";
	pchar.quest.PearlGen_checkSantaCatalina.win_condition.l1.location = "Pearl_Jungle_06";
	pchar.quest.PearlGen_checkSantaCatalina.win_condition = "PearlGen_checkSantaCatalina";
}
void PearlGen_SetTeno(string sQuest)
{
	pchar.quest.PearlGen_checkTeno.win_condition.l1 = "location";
	pchar.quest.PearlGen_checkTeno.win_condition.l1.location = "Pearl_Jungle_02";
	pchar.quest.PearlGen_checkTeno.win_condition = "PearlGen_checkTeno";
}
//домашние энкаунтеры. установка тамера 'покинуть дом'
void HouseEnc_TimerGoUot(string qName)
{
	if (CheckAttribute(pchar, "questTemp.HouseEncTimer"))
	{
		if (pchar.location == pchar.questTemp.HouseEncTimer && !actLoadFlag && !LAi_grp_alarmactive)
		{
			LAi_group_Attack(characterFromId(pchar.questTemp.HouseEncTimer.Id), Pchar);
		}
		DeleteAttribute(pchar, "questTemp.HouseEncTimer");
	}
}

//удаления группы с задержкой
void Delay_DeleteGroup(string GroupName)
{
	DoQuestCheckDelay("DeleteGroupOnExitLocation", 2.0);
	pchar.quest.DeleteGroupOnExitLocation.GroupName = GroupName;
}
//установка скелетов по пещерам
void SetSkeletonsToLocation(aref _location)
{
	int iRank, iStep;
	float sTime, eTime;
	ref sld;
	bMonstersGen = true; //флаг генерации монстров
	//--> генерим инкремент к рангу
	if (!CheckAttribute(_location, "Monsters_step"))
	{
		iStep = 0;
		_location.Monsters_step = sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
		SaveCurrentNpcQuestDateParam(_location, "Monsters_step"); //запись даты
	}
	else
	{
		if (GetNpcQuestPastDayParam(_location, "Monsters_step") > 3)
		{
			iStep = 0;
			_location.Monsters_step = sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
			SaveCurrentNpcQuestDateParam(_location, "Monsters_step"); //запись даты
		}
		else
		{
			iStep = _location.Monsters_step;
			_location.Monsters_step = iStep + sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
		}
	}
	LAi_group_Delete("EnemyFight");
	//<-- генерим инкремент к рангу
	//--> генерим ранг
	if (sti(pchar.rank) > 6)
	{
		if (sti(pchar.rank) > 20) iRank = sti(pchar.rank) + MOD_SKILL_ENEMY_RATE*3;
		else iRank = sti(pchar.rank) + sti(MOD_SKILL_ENEMY_RATE*3/2);
	}
	else
	{	//казуалам зеленый свет на начало игры
		iRank = sti(pchar.rank);
	}
	iRank += iStep;
	//<-- генерим ранг
	aref grp;
	makearef(grp, _location.locators.monsters);
	int num = GetAttributesNum(grp);
	int rNum = drand(num);
	for(int i = 0; i < num; i++)
	{
		sld = GetCharacter(NPC_GenerateCharacter("Skelet"+_location.index+"_"+i, "Skel"+(rand(3)+1), "skeleton", "skeleton", iRank, PIRATE, 1, true));
		//если квест по зачистке от нечисти - скелетов делаем круче
		if (CheckAttribute(_location, "DestroyGhost"))
		{
			FantomMakeCoolFighter(sld, sti(pchar.rank)+5, 90, 90, LinkRandPhrase(RandPhraseSimple("blade23","blade25"), RandPhraseSimple("blade30","blade26"), RandPhraseSimple("blade24","blade13")), RandPhraseSimple("pistol6", "pistol3"), MOD_SKILL_ENEMY_RATE*3*4);
			DeleteAttribute(sld, "SuperShooter");
		}
		else
		{
			if (i == rNum && sti(pchar.rank) > 5)
			{
				FantomMakeCoolFighter(sld, sti(pchar.rank)+5, 80, 80, LinkRandPhrase(RandPhraseSimple("blade23","blade25"), RandPhraseSimple("blade30","blade26"), RandPhraseSimple("blade24","blade13")), RandPhraseSimple("pistol6", "pistol4"), MOD_SKILL_ENEMY_RATE*3*3);
				DeleteAttribute(sld, "SuperShooter");
			}
			else SetFantomParamFromRank(sld, iRank, true);
		}
		LAi_SetWarriorType(sld);
		LAi_warrior_SetStay(sld, true);
			LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
		ChangeCharacterAddressGroup(sld, _location.id, "monsters", GetAttributeName(GetAttributeN(grp, i)));
	}
	//проверяем, есть ли на локацию квест по очистке от нечисти
	if (CheckAttribute(_location, "DestroyGhost"))
	{
		chrDisableReloadToLocation = true;
		characters[sti(_location.DestroyGhost)].quest.DestroyGhost = "GoodResult";
		DeleteAttribute(_location, "DestroyGhost");
		LAi_LocationDisableMonGenTimer(_location.id, 3); //монстров не генерить 3 дня
		LAi_group_SetCheck(LAI_GROUP_MONSTERS, "OpenTheDoors");
		if (!CheckAttribute(pchar,"Dovahkiin") && rand(3)==0) LAi_group_SetCheck(LAI_GROUP_MONSTERS, "Dovahkiin");
		AddQuestRecordEx(_location.id + "Church_DestroyGhost", "Church_DestroyGhost", "2");
	}
	else
	{
		LAi_LocationDisableMonGenTimer(_location.id, 1); //монстров не генерить 1 день
		pchar.GenQuest.monstersTimer = true;
		SetFunctionTimerConditionParam("GenQuest_EnableMonstersGen", 0, 0, 0, 24, false);
	}

	//#20190928-02
	LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
}

void SetReefSkeletonsToLocation(aref _location, string loc)
{
	int iRank, iStep;
	float sTime, eTime;
	ref sld;
	bMonstersGen = true; //флаг генерации монстров
	//--> генерим инкремент к рангу
	if (!CheckAttribute(_location, "Monsters_step"))
	{
		iStep = 0;
		_location.Monsters_step = sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
		SaveCurrentNpcQuestDateParam(_location, "Monsters_step"); //запись даты
	}
	else
	{
		if (GetNpcQuestPastDayParam(_location, "Monsters_step") > 3)
		{
			iStep = 0;
			_location.Monsters_step = sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
			SaveCurrentNpcQuestDateParam(_location, "Monsters_step"); //запись даты
		}
		else
		{
			iStep = _location.Monsters_step;
			_location.Monsters_step = iStep + sti(MOD_SKILL_ENEMY_RATE*3 / 1.5 + 0.5);
		}
	}
	LAi_group_Delete("EnemyFight");
	//<-- генерим инкремент к рангу
	//--> генерим ранг
	if (sti(pchar.rank) > 5)
	{
		if (sti(pchar.rank) > 20) iRank = sti(pchar.rank)+5 + MOD_SKILL_ENEMY_RATE*3;
		else iRank = sti(pchar.rank)+5 + sti(MOD_SKILL_ENEMY_RATE*3/2);
	}
	else
	{	//казуалам набьют ебало, ибо ранг+5 и толпа
		iRank = sti(pchar.rank)+5;
	}
	iRank += iStep;
	//<-- генерим ранг
	aref grp;
	int num;
	if (loc == "MountainPath")
	{
		makearef(grp, _location.locators.quest);
		num = GetAttributesNum(grp);
	}
	if (loc == "DeckWithReefs")
	{
		makearef(grp, _location.locators.monsters);
		num = makeint(GetAttributesNum(grp)/(11-(MOD_SKILL_ENEMY_RATE*3))); // LEO: ЛЮБЛЮ РЕЗНЮ на АДмирале!
	}
	int rNum = drand(num);
	LAi_group_Register("ReefAssholes");
	for(int i = 0; i < num; i++)
	{
		sld = GetCharacter(NPC_GenerateCharacter("Skelet"+_location.index+"_"+i, "Skel"+(rand(3)+1), "skeleton", "skeleton", iRank, PIRATE, 1, true));
		//если квест по зачистке от нечисти - скелетов делаем круче

		if (i == rNum && sti(pchar.rank) > 5)
		{
			FantomMakeCoolFighter(sld, iRank, 80, 80, LinkRandPhrase(RandPhraseSimple("blade23","blade25"), RandPhraseSimple("blade30","blade26"), RandPhraseSimple("blade24","blade13")), RandPhraseSimple("pistol6", "pistol4"), MOD_SKILL_ENEMY_RATE*3*3);
			DeleteAttribute(sld, "SuperShooter");
		}
		else SetFantomParamFromRank(sld, iRank, true);
		if (i == 0)
		{
			if (GetDataDay() == 3 && GetDataMonth() == 3 && GetTime() >= 3.0 && GetTime() < 4.0 && loc == "MountainPath" && !CheckAttribute(pchar,"salasarmet") && CheckAttribute(pchar,"SalasarEventKnow"))
			{
				pchar.salasarmet = true;
				if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("salasar", "salasar", "skeleton", "man_fast", iRank, PIRATE, 1, true)); // LEO: Превозмогаторам - страдать 01.12.2021
				else sld = GetCharacter(NPC_GenerateCharacter("salasar", "salasar", "skeleton", "skeleton", iRank, PIRATE, 1, true));
				sld.name = GetConvertStrWithReplace("Variable_QuestsUtilite_17", "Names.txt", "#space#", " ");
				sld.lastname = GetConvertStrWithReplace("Variable_QuestsUtilite_18", "Names.txt", "#space#", " ");
				sld.SaveItemsForDead = true;
				sld.locid = _location.index;
				sld.num = num;
				sld.norun = true;
				if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки

				SetSPECIAL(sld, 10,10,10,10,10,10,10); // SPECIAL (Сила, Восприятие, Выносливость, Лидерство, Обучаемость, Реакция, Удача)
				FantomMakeCoolFighter(sld, 55, 100, 100, RandPhraseSimple("blade46","blade010"), "pistol8", 300); //55 лвл, Кракемарт или Кавалерийский палаш, Бландербуз
				LAi_SetHP(sld,2500,2500);
				// Gregg: регенерация вручную - см. пояснение у Хранителя Грота
				// (quests_reaction.c, SpawnGiantEvilSkeleton). При 2580 HP штатная формула
				// упиралась в потолок 3.0 HP в секунду.
				LAi_SetDltHealth(sld, 1.0);

				SelAllPerksToNotPChar(sld); //укоротил все перки

				//установить ЛУ и КУ
				SetSelfSkill(sld, 100, 100, 100, 100, 100); //лёгкое, среднее, тяжёлое, пистолет, удача
				SetShipSkill(sld, 100, 100, 100, 100, 100, 100, 100, 100, 100); // лидерство, торговля, точность, пушки, навигация, ремонт, абордаж, защита, скрытность

				sld.money = 1000000;
				GiveItem2Character(sld, "cirass5");
				EquipCharacterbyItem(sld,"cirass5");
				SetCharacterPerk(sld, "Fencer"); //фехт
				AddBonusEnergyToCharacter(sld, 200);
				Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_5", "Logs.txt", "#space#", " "));
				Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_6", "Logs.txt", "#space#", " "));
				AddCharacterHealth(pchar, -10);
				chrDisableReloadToLocation = true; //пока Салазар жив - хер, а не выход
			}
			if (loc != "MountainPath")
			{
				if (pchar.name != "Виспер" && !CheckAttribute(pchar, "PGGWhisperQuest"))
				{
					Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_7", "Logs.txt", "#space#", " "));
					chrDisableReloadToLocation = true; //пока Злой Скелет Гигант жив - хер, а не выход
					pchar.GiantEvilSkeleton = true;
					LAi_group_SetCheck("ReefAssholes", "SpawnGiantEvilSkeleton");
				}
				else
				{
					if (CheckAttribute(pchar,"OrderDestroyed"))
					{
						Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_8", "Logs.txt", "#space#", " "));
						chrDisableReloadToLocation = true; //пока Злой Скелет Гигант жив - хер, а не выход
						pchar.GiantEvilSkeleton = true;
						LAi_group_SetCheck("ReefAssholes", "SpawnGiantEvilSkeleton");
					}
					else
					{
						return;
					}
				}
			}
		}
		LAi_SetWarriorType(sld);
		LAi_group_MoveCharacter(sld, "ReefAssholes");
		string locator = GetAttributeName(GetAttributeN(grp, i));
		if (loc == "MountainPath")
		{
			if (locator == "rock" || locator == "wall" || locator == "top") locator = "skeleton5"; //нет скелетам на скалах и на крыше
			ChangeCharacterAddressGroup(sld, _location.id, "quest", locator);
			if (i == 0 && sld.name == GetConvertStrWithReplace("Variable_QuestsUtilite_19", "Names.txt", "#space#", " "))
			{
				LAi_SetCheckMinHP(sld, 1750.0, false, "SpawnSalasarSupports");
			}
		}
		if (loc == "DeckWithReefs") ChangeCharacterAddressGroup(sld, _location.id, "monsters", locator);
	}

	LAi_LocationDisableMonGenTimer(_location.id, 1); //монстров не генерить 1 день
	pchar.GenQuest.monstersTimer = true;
	SetFunctionTimerConditionParam("GenQuest_EnableMonstersGen", 0, 0, 0, 24, false);

	if (loc == "MountainPath" && CheckAttribute(pchar,"salasarmet") && !CheckAttribute(pchar,"SalasarSpawned"))
	{
		sld = CharacterFromID("salasar");
		LAi_SetActorTypeNoGroup(sld);
		sld.dialog.filename = "Salasar.c";
		sld.dialog.currentnode = "First";
		LAi_ActorDialog(sld, pchar, "", 4.0, 0);
		LAi_SetFightMode(pchar, false);
		LAi_LockFightMode(pchar, false);
		LAi_LocationFightDisable(loadedLocation, true);
		pchar.SalasarSpawned = true;
	}
	else
	{
		LAi_group_SetRelation("ReefAssholes", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
		LAi_group_Attack(sld, Pchar);
		LAi_group_SetLookRadius("ReefAssholes", 1000.0);
	}
}

// заменяем копии частей карты
void ReplaceTreasureMapPartCopies(ref boxRef, ref charRef) {
	bool isPart1 = GetCharacterItem(charRef, "map_part1") != 0;
	bool isPart2 = GetCharacterItem(charRef, "map_part2") != 0;
	
	// если есть обе части, просто скипаем
	if (isPart1 && isPart2) return;

	// подменяем части карты
	if (GetCharacterItem(boxRef, "map_part1") != 0 && isPart1) {
		AddItems(boxRef, "map_part2", 1);
		RemoveItems(boxRef, "map_part1", 1);
	}
	
	if (GetCharacterItem(boxRef, "map_part2") != 0 && isPart2) {
		AddItems(boxRef, "map_part1", 1);
		RemoveItems(boxRef, "map_part2", 1);
	}
}

//Перехват всех попыток ГГ залезть в боксы
void QuestCheckTakeBoxes(ref itemsRef)
{
	//Boyer fix
	if (reload_location_index < 0) return; //Boyer fix
	ref locLoad = &locations[reload_location_index];
    ref sld;
	int i, num;
	String title;
	//--> флаг 'в сундуке'
	bMainCharacterInBox = true;
	//<-- флаг 'в сундуке'
	//-------------------- КЛАДЫ ------------>>>>>>>>>>>>>

	//Спавн проклятого кэпа
	if (!CheckAttribute(pchar,"treasurelocation"))
	{
		if (CheckCharacterItem(pchar,"letter_notes") && locLoad.id == "Bermudes_Dungeon" && !CheckAttribute(pchar,"FishHeadsSpawned"))
		{
			Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_9", "Logs.txt", "#space#", " "));
			/*string chesttype = "";
			switch (drand(3))
			{
				case 0: chesttype = "Chest_ammo"; break;
				case 1: chesttype = "Chest_treasure"; break;
				case 2: chesttype = "Chest_quest"; break;
				case 3: chesttype = "Chest_Craftsmans"; break;
			}
			TakeNItems(pchar,chesttype,1);
			Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_10", "Logs.txt", "#space#", " "));*/
			Log_info(GetConvertStrWithReplace("Variable_QuestsUtilite_11", "Logs.txt", "#space#", " "));
			ChangeItemDescribe("letter_notes", "CSPD2");
			pchar.FishHeadsSpawned = true;
			SpawnFishHeads();
			pchar.quest.EasterFish.win_condition.l1 = "ExitFromLocation";
			pchar.quest.EasterFish.win_condition.l1.location = pchar.location;
			pchar.quest.EasterFish.function = "FishHDS";
			return;
		}
		spawnToughSkeleton(locLoad);
	}
	if (CheckAttribute(pchar,"treasurelocation"))
	{
		if (locLoad.id != pchar.treasurelocation) spawnToughSkeleton(locLoad);
	}
	if (CheckAttribute(itemsRef, "Treasure"))
	{
		Log_Info(GetConvertStrWithReplace("Variable_QuestsUtilite_12", "Logs.txt", "#space#", " "));
		PlaySound("interface\notebook.wav");
		DeleteAttribute(itemsRef, "Treasure");
		DeleteAttribute(PChar, "treasurelocation");

		IncAndUnlock("AchTreasure", 1);

		//eddy. для безконфликтности квестов

		if (LAi_LocationIsMonstersGen(locLoad) && !bMonstersGen && LAi_grp_playeralarm == 0)
		{
			SetSkeletonsToLocation(locLoad);
		}

		if(CheckAttribute(itemsRef, "Hold_GenQuest_Treasure"))
		{
			if(sti(pchar.GenQuest.Hold_GenQuest.Treasure) == 0)
			{
				AddQuestRecord("HoldQuest", "18");
				AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.Name);
			}
			else
			{
				AddQuestRecord("HoldQuest", "17");
				AddQuestUserData("HoldQuest", "sCapName", pchar.GenQuest.Hold_GenQuest.CapName);
			}
			CloseQuestHeader("HoldQuest");
			DeleteAttribute(itemsRef, "Hold_GenQuest_Treasure");
			DeleteAttribute(pchar,"GenQuest.Hold_GenQuest");
		}
	}
	//<<<<<<<<<<---------- КЛАДЫ --------------------------
	//-->> Генератор грабежа жемчуга, у главы поселения
	if (GetCharacterIndex("HeadMan_2") != -1 && locLoad.id == "PearlTown2_Townhall")
	{
		if (pchar.questTemp.Sharp.SeekSpy != "begin" && pchar.questTemp.Sharp.SeekSpy != "over")
		{	//если взят квест на поиски крысы Шарпа - закрываем его
			pchar.questTemp.Sharp.SeekSpy = "over";
			CloseQuestHeader("SharpPearl_SeekSpy");
    		ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, SPAIN, -10);
		}
		ChangeCharacterReputation(pchar, -20);
		SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
		LAi_group_Attack(characterFromId("HeadMan_2"), Pchar);
		chrDisableReloadToLocation = true;
		pchar.quest.PearlGen_HeadMan_2_death.win_condition.l1 = "NPC_Death";
		pchar.quest.PearlGen_HeadMan_2_death.win_condition.l1.character = "HeadMan_2";
		pchar.quest.PearlGen_HeadMan_2_death.win_condition = "OpenTheDoors";
		return;
	}
	if (GetCharacterIndex("HeadMan_1") != -1 && locLoad.id == "PearlTown1_Townhall")
	{
		if (pchar.questTemp.Sharp.SeekSpy != "begin" && pchar.questTemp.Sharp.SeekSpy != "over")
		{	//если взят квест на поиски крысы Шарпа - закрываем его
			pchar.questTemp.Sharp.SeekSpy = "over";
			CloseQuestHeader("SharpPearl_SeekSpy");
    		ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, SPAIN, -10);
		}
		ChangeCharacterReputation(pchar, -20);
		SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
		LAi_group_Attack(characterFromId("HeadMan_1"), Pchar);
		chrDisableReloadToLocation = true;
		pchar.quest.PearlGen_HeadMan_1_death.win_condition.l1 = "NPC_Death";
		pchar.quest.PearlGen_HeadMan_1_death.win_condition.l1.character = "HeadMan_1";
		pchar.quest.PearlGen_HeadMan_1_death.win_condition = "OpenTheDoors";
		return;
	}
	//<<-- Генератор грабежа жемчуга, у главы поселения
	//-->> Квест Изабеллы.
	if (GetCharacterIndex("Husband") != -1  && locLoad.id == "SanJuan_houseSp6" && characters[GetCharacterIndex("Isabella")].location != "SanJuan_houseSp6" && characters[GetCharacterIndex("Husband")].location == "SanJuan_houseSp6")
	{
		ChangeCharacterReputation(pchar, -3);
		SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
		sld = characterFromId("Husband");
		LAi_SetWarriorType(sld);
		LAi_group_Attack(sld, Pchar);
		chrDisableReloadToLocation = true;
		LAi_LocationFightDisable(locLoad, false);
		LocatorReloadEnterDisable(locLoad.id, "reload2", true);
		pchar.quest.Husband_death.win_condition.l1 = "NPC_Death";
		pchar.quest.Husband_death.win_condition.l1.character = "Husband";
		pchar.quest.Husband_death.win_condition = "OpenTheDoors";
	}
	//<<-- Квест Изабеллы.
	//-->> Сундук с револьвером Колье в Тено.
	if (locLoad.id == "Temple_round")
	{
		TenoRoundTempleChestOpen();
	}
	//<<-- Сундук с револьвером Колье в Тено.
}
//открытие дверей в локации города для коммонов. только на текущие сутки + ещё одни, потом снимается само.
void SetOpenDoorCommonLoc(string City, string locationId)
{
	aref arRld, arDis, arRld2, arDis2;
	string LocId;
	makearef(arRld, locations[FindLocation(City + "_town")].reload);
    int Qty2, n, i;
	int Qty = GetAttributesNum(arRld);
	for (i=0; i<Qty; i++)
    {
    	arDis = GetAttributeN(arRld, i);
		LocId = arDis.go;
    	if (LocId == locationId)
    	{
			arDis.disable = false;
			arDis.canEnter = true;
			return;
    	}
		if (arDis.label != "Sea")
		{
			makearef(arRld2, Locations[FindLocation(LocId)].reload);
			Qty2 = GetAttributesNum(arRld2);
			for (n=0; n<Qty2; n++)
			{
    			arDis2 = GetAttributeN(arRld2, n);
				LocId = arDis2.go;
				if (LocId == locationId)
    			{
					// LEO: открывать надо НАЙДЕННЫЙ переход (arDis2), а не переход верхнего уровня.
					//   Из-за этого дом, лежащий за промежуточной локацией, оставался закрытым:
					//   квест мэра сажал туда лазутчика, а игрок не мог войти и не находил его.
					arDis2.disable = false;
					arDis2.canEnter = true;
					return;
				}
			}
		}
    }
}

//личные боевые навыки, нужны для экспы после сухопутных боев
void AddComplexSelfExpToScill(int l, int m, int h, int p)
{
	AddCharacterExpToSkill(pchar, "FencingLight", l);//легкое оружие
	AddCharacterExpToSkill(pchar, "Fencing", m);//среднее оружие
	AddCharacterExpToSkill(pchar, "FencingHeavy", h);//тяжёлое оружие
	AddCharacterExpToSkill(pchar, "Pistol", p); //пистоли
}

int CheckShipTypeInSquadron(int iShipType) //Jason, есть ли такой тип корабля в эскадре и сколько
{
	ref sld;
	int iTemp;
	int iShip = 0;
	for(int i = 0; i < COMPANION_MAX; i++)
	{
		iTemp = GetCompanionIndex(PChar, i);
		if(iTemp > 0)
		{
			sld = GetCharacter(iTemp);
			if(sti(RealShips[sti(sld.ship.type)].basetype) == iShipType) iShip++;
		}
	}
	return iShip;
}
void AddComplexSeaExpToScill(int s, int a, int c, int g, int d, int r, int t)
{
	AddCharacterExpToSkill(pchar, "Sailing", s);//навигация
	AddCharacterExpToSkill(pchar, "Accuracy", a);//меткость
	AddCharacterExpToSkill(pchar, "Cannons", c);//орудия
	AddCharacterExpToSkill(pchar, "Grappling", g);//абордаж
	AddCharacterExpToSkill(pchar, "Defence", d);//защита
	AddCharacterExpToSkill(pchar, "Repair", r);//починка
	AddCharacterExpToSkill(pchar, "Commerce", t);//торговля
}

// LEO: поднять сбитого конкурента на разговор в каюте. Тот же сценарий, что у обычного каютного диалога
// (QuestAboardCabinDialog), но зовётся отложенно - когда с его охраной покончено.
void PGG_CabinCaptainTalk()
{
	ref sld;
	if (!CheckAttribute(pchar, "GenQuest.QuestAboardCabinDialogIdx")) return;
	sld = &Characters[sti(pchar.GenQuest.QuestAboardCabinDialogIdx)];
	DeleteAttribute(sld, "PGG_CabinWaiting");
	LAi_SetActorType(pchar);
	LAi_SetActorType(sld);
	LAi_SetFightMode(sld, false);	// клинок в ножны - разговаривает безоружным (тип ПЕРЕД этим, иначе не сработает)
	SetActorDialogAny2Pchar(sld.id, "", 0.0, 0.0);
	LAi_ActorFollow(pchar, sld, "ActorDialog_Any2Pchar", 0.5);
}
