void ProcessDialogEvent()
{
    ref NPChar;
    aref Link, NextDiag;
    int i;

    DeleteAttribute(&Dialog, "Links");

    makeref(NPChar, CharacterRef);
    makearef(Link, Dialog.Links);
    makearef(NextDiag, NPChar.Dialog);

    switch (Dialog.CurrentNode)
    {
    case "Exit":
        NextDiag.CurrentNode = NextDiag.TempNode;
        DialogExit();
    break;
    case "First Time":
        dialog.text = "Qui es-tu ? Fiche le camp, je ne suis pas d'humeur à bavarder.";
        link.l1 = "Chut, chut, l'ami, je viens te remettre une lettre de la part de Luke l'Acteur.";
        link.l1.go = "GiveLetter1";
		Map_CreateFastWarriorTreasure();
		DeleteAttribute(Pchar, "Luke.SpawnMaks");
    break;
    case "GiveLetter1":
        dialog.text = "Ah oui ? Et oם est-elle ?";
        link.l1 = "Regarde ça.";
        NextDiag.CurrentNode = "Plata";
        AddDialogExitQuest("GiveLetter");
    break;
    case "Plata":
        dialog.text = "Bon, c'est bien ça. Ah oui, j'allais oublier, voici ton argent. Et maintenant, tiens-toi loin de moi.";
        link.l1 = "Merci. Je quitte ta compagnie avec plaisir.";
        AddQuestRecord("Silence_Price", "2");
        AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
        PlaySound("Interfaceotebook_01");
        link.l1.go = "exit";
        AddDialogExitQuest("Plata1");
		NextDiag.TempNode="Bye";
        Characters[GetCharacterIndex("Old Friend")].Dialog.CurrentNode = "SecondQuest_1";
		ChangeCharacterAddressGroup(CharacterFromID("Old Friend"), "none", "none", "none");
		Pchar.Quest.Luke = "1";

    break;
	case "Bye":
		dialog.text="Fiche le camp, je ne suis pas d'humeur à bavarder.";
		link.l1="Je n'en avais pas vraiment envie.";
		link.l1.go="exit";
	break;
	case "Guardians":
		dialog.text = "Que se passe-t-il ici ?! Un espion ennemi ?! Arrêtez " + GetSexPhrase("ce voleur !","cette voleuse !");
		link.l1 = "Eh bien, essaie donc...";
		link.l1.go = "exit";
		AddDialogExitQuest("FightGuardians");
		LAi_group_MoveCharacter(NPChar, "Maks1");
	break;
    }
}
