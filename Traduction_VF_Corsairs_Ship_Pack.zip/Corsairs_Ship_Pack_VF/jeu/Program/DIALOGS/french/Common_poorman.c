#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    /*NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Poorman\" + NPChar.City + "_Poorman.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}*/
    // вызов диалога по городам <--

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.quest.meeting == "0")
			{
				//если ГГ начал мочить бродяг -->
				if (pchar.questTemp.LSC == "PoorMurderBegin")
				{
					dialog.text = LinkRandPhrase("J'ai entendu dire que vous aviez tué des mendiants dans d'autres villes. Pourquoi faites-vous ça ?",
						"Je crois savoir qui vous êtes. Pourquoi nous tuez-vous ?",
						"Que nous voulez-vous ? Que vous avons-nous fait ? Pourquoi tuer d'inoffensifs mendiants ?");
					link.l1 = LinkRandPhrase("Tout est une question d'argent...", "On m'a promis une très grosse récompense pour ce travail !", "C'est la vie... En somme, tout est une question d'intérêt, mon ami.");
					link.l1.go = "exit";
					break;
				}
				//<-- если ГГ начал мочить бродяг
				//зачарованный город -->
				if (pchar.questTemp.MC == "toCaracas" && npchar.city == "Caracas")
				{
					dialog.text = "Eh bien, les citadins se sont vraiment dispersés. דa m'est égal.";
					link.l1 = "Je vois...";
					link.l1.go = "exit";
					break;
				}
				if (pchar.questTemp.MC == "toCaracasPadre" || pchar.questTemp.MC == "toCaracasTavern")
				{
					dialog.text = "Vous voulez vous occuper de cette affaire ? Eh bien, comme vous voudrez... דa m'est égal.";
					link.l1 = "Très bien.";
					link.l1.go = "exit";
					break;
				}
				//<-- зачарованный город
				dialog.text = LinkRandPhrase("Bonjour. Je m'appelle " + GetFullName(npchar) + ". Je ne pense pas que me rencontrer soit très agréable pour vous, mais peut-être vous souviendrez-vous de mon nom...",
					"Mes salutations, " + GetAddress_Form(NPChar) +  ". Je m'appelle " + GetFullName(npchar) + ".",
					"Je m'appelle " + GetFullName(npchar) + ", " + GetAddress_Form(NPChar) + ". Ravi de vous rencontrer.");
				link.l1 = RandPhraseSimple("Salutations.", "Bonjour.");
				link.l1.go = "First time";
				npchar.quest.meeting = "1";
			}
			else
			{
				//если ГГ начал мочить бродяг -->
				if (pchar.questTemp.LSC == "PoorMurderBegin")
				{
					dialog.text = LinkRandPhrase("J'ai entendu dire que vous "+ GetSexPhrase("aviez tué", "aviez tué") +" des mendiants dans d'autres villes. Pourquoi faites-vous ça ?",
						"Je crois savoir qui vous êtes. Pourquoi nous tuez-vous ?",
						"Que nous voulez-vous ? Que vous avons-nous fait ? Pourquoi tuer d'inoffensifs mendiants ?");
					link.l1 = LinkRandPhrase("Tout est une question d'argent...", "On m'a promis une très grosse récompense pour ce travail !", "C'est la vie... En somme, tout est une question d'intérêt, mon ami.");
					link.l1.go = "exit";
					break;
				}
				//<-- если ГГ начал мочить бродяг
				dialog.text = NPCStringReactionRepeat("Oh, voyez oם on en est arrivé...",
					"Ce n'est pas facile de vivre de la mendicité...",
					"Si seulement je pouvais sortir de la misère !",
					"Encore vous ?", "block", 1, npchar, Dialog.CurrentNode);
				//разговарием с нищими о наезде
				if (pchar.questTemp.LSC == "SignOnPoorMurder" || pchar.questTemp.LSC == "PoorIsGood")
				{
					if (CheckAttribute(pchar, "questTemp.LSC.qtyTalk.headPoormanId") && pchar.questTemp.LSC.qtyTalk.headPoormanId == npchar.id)
					{
						link.l1 = "J'ai entendu dire que vous vouliez me parler.";
						link.l1.go = "PoorHeadMan";
						npchar.quest.talk = true; //больше не говорить
						break;
					}
					if (!CheckAttribute(npchar, "quest.talk"))
					{
						if (!CheckAttribute(pchar, "questTemp.LSC.qtyTalk")) pchar.questTemp.LSC.qtyTalk = 0;
						pchar.questTemp.LSC.qtyTalk = sti(pchar.questTemp.LSC.qtyTalk) + 1; //инкремент на базары по душам
						if (sti(pchar.questTemp.LSC.qtyTalk) > 4) pchar.questTemp.LSC.qtyTalk = 4;
						switch (pchar.questTemp.LSC.qtyTalk)
						{
						case "1":
							link.l1 = "וcoutez, ça m'intéresse beaucoup : les mendiants des villes, c'est une bande de malfrats, ou quoi ?";
							npchar.quest.talk = true; //больше не говорить
							break;
						case "2":
							link.l1 = "וcoutez, j'ai une affaire assez inhabituelle pour vous.";
							npchar.quest.talk = true; //больше не говорить
							break;
						case "3":
							link.l1 = "Vous savez, j'ai une question à vous poser. Très étrange, à première vue...";
							npchar.quest.talk = true; //больше не говорить
							break;
						case "4":
							link.l1 = "Je voudrais te poser une question, l'ami.";
							break;
						}
						link.l1.go = "GoodTalk_" + pchar.questTemp.LSC.qtyTalk;
						break;
					}
				}
				//----------------------------------------------------------------
				link.l1 = HeroStringReactionRepeat("Je vois. Bon, ça va.",
					"C'est compréhensible. On ne peut pas se promener avec cet argent, allez...",
					"Alors inutile de traîner ici, faites plutכt quelque chose.",
					"Ouais. Vous êtes vraiment "+ GetSexPhrase("fatigué", "fatiguée") +" ?", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("exit", "exit", "exit", "pester", npchar, Dialog.CurrentNode);
				link.l2 = RandPhraseSimple("Que voulez-vous ?", "Que voulez-vous ?");
				link.l2.go = "Whants";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf en ville ?", "Oh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_poor";
				// --------------- линейка ГПК ---------------
				if (CheckCharacterItem(pchar, "letter_LSC") && (pchar.questTemp.LSC.qtyTalk.headPoormanId == npchar.id))
				{
					//нашёл письмо в сундуке Виллемстада
					if (pchar.questTemp.LSC == "CanFoundStuvesantKey")
					{
						link.l1 = "וcoute, il me semble que j'ai trouvé quelque chose de très intéressant à la résidence de Stuyvesant !";
						link.l1.go = "FoundLetter";
					}
					//базар о том, что нашёл причину заказа на нищих
					if (pchar.questTemp.LSC == "readyGoLSC" && GetCharacterFreeItem(pchar, "keyQuestLSC")==0)
					{
						link.l1 = "Vous savez, j'ai réussi à démêler cet écheveau !";
						link.l1.go = "GoLSC";
					}
				}
			}
			NextDiag.TempNode = "First time";
		break;
		case "pester":
			dialog.text = RandPhraseSimple("Non, pourquoi tout de suite "+ GetSexPhrase("fatigué", "fatiguée") +" ? Je ne suis pas aussi occupé que vous"+ GetSexPhrase("le grand", "la grande") +" - vous voyez...",
				"Pas "+ GetSexPhrase("fatigué", "fatiguée") +", mais plutכt "+ GetSexPhrase("fatigué", "fatiguée") +". Je suis peut-être un mendiant, mais je suis aussi un être humain.");
			link.l1 = "Hé, je vois...";
			link.l1.go = "exit";
		break;
		//выходы
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//милостыня
		case "Whants":
			if (!CheckAttribute(npchar, "wants_date") || GetNpcQuestPastDayParam(npchar, "wants_date") >= 1 || bBettaTestMode)
    		{
				dialog.text = PCharRepPhrase("Hum, " + GetAddress_Form(NPChar) +  " - il court de mauvaises rumeurs sur vous. Mais je crois aux gens, même aux gens comme vous. Je vous demande de l'argent pour manger et boire, ayez pitié.",
					"Je vous en prie, " + GetAddress_Form(NPChar) +  " ! Ne délaissez pas un malheureux, donnez-lui à manger...");
				link.l1 = RandPhraseSimple("Je ne vous donnerai rien.", "Vous vous débrouillerez bien.");
				link.l1.go = "exit";
				Link.l2 = "D'accord. Et de combien d'argent avez-vous besoin ?";
				Link.l2.go = "Whants_1";
			}
			else
			{
				dialog.text = PCharRepPhrase("De vous ? De rien.", "Je n'ai besoin de rien, " + GetAddress_Form(NPChar) + "Merci.");
				link.l1 = RandPhraseSimple("Hum, d'accord.", "Tu mènes la belle vie, l'ami.");
				link.l1.go = "exit";
			}
		break;
		case "Whants_1":
			dialog.text = "Je ne refuserai pas un sou, " + GetAddress_Form(NPChar) + ". Autant que votre bourse et votre charité vous le permettront...";
			Link.l1.edit = 2;
			link.l1 = "";
			link.l1.go = "Whants_2";
		break;
		case "Whants_2":
			SaveCurrentNpcQuestDateParam(npchar, "wants_date");
			int iTemp = sti(dialogEditStrings[2]);
			if (iTemp <= 0 || sti(pchar.money) < iTemp)
			{
				dialog.text = "C'est un péché de se moquer des malheureux...";
				link.l1 = "Ha ha ha, qu'est-ce que tu croyais, imbécile, que j'allais te donner de l'argent ?!";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, -2);
				break;
			}
			if (iTemp > 0 && iTemp <= 100)
			{
				dialog.text = "Merci pour " + FindRussianMoneyString(iTemp) + ", " + GetAddress_Form(NPChar) + ". J'achèterai du pain avec cet argent...";
				link.l1 = "Allez, va t'acheter à manger, vagabond.";
				link.l1.go = "exit";
				pchar.money = sti(pchar.money) - iTemp;
			}
			if (iTemp > 100 && iTemp <= 1000)
			{
				dialog.text = "Merci, " + GetAddress_Form(NPChar) + ". Cet argent me suffira pour une semaine !";
				link.l1 = ""+ GetSexPhrase("Ravi", "Ravie") +"aide.";
				link.l1.go = "exit";
				OfficersReaction("good");
				pchar.money = sti(pchar.money) - iTemp;
			}
			if (iTemp > 1000 && iTemp <= 5000)
			{
				dialog.text = "Merci, " + GetAddress_Form(NPChar) + ". Je dirai à tout le monde à quel point vous êtes bon !";
				link.l1 = "Eh bien, ce n'est pas nécessaire...";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, sti(iTemp/2000+0.5));
				pchar.money = sti(pchar.money) - iTemp;
			}
			if (iTemp > 5000 && iTemp <= 50000)
			{
				dialog.text = "Merci, cher " + GetAddress_Form(NPChar) + ". Que le Seigneur vous protège...";
				link.l1 = "Oui, la protection du Seigneur ne me fera certainement pas de mal !";
				link.l1.go = "exit";
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), sti(iTemp/10000+0.5));
				pchar.money = sti(pchar.money) - iTemp;
			}
			if (iTemp > 50000 && iTemp <= 100000)
			{
				dialog.text = "Merci, " + GetAddress_Form(NPChar) + ". Je vous souhaite bonne chance !";
				link.l1 = "Merci, l'ami.";
				link.l1.go = "exit";
				AddCharacterExpToSkill(pchar, "Leadership", sti(iTemp/5000));
				AddCharacterExpToSkill(pchar, "Fortune", sti(iTemp/5000));
				pchar.money = sti(pchar.money) - iTemp;
			}
			if (iTemp > 100000)
			{
				dialog.text = "וcoutez, " + GetAddress_Form(NPChar) + " Vous avez perdu la tête ? Vous me donnez " + FindRussianMoneyString(iTemp) + " ! Je ne prendrai pas une telle somme, je sens qu'il y a anguille sous roche... Partez !";
				link.l1 = "Eh bien, comme vous voudrez...";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, -2);
			}
		break;
		//линейка ГПК, разговоры по душам с нищими после заказа
		case "GoodTalk_1":
			dialog.text = "Kh-hé, kh-hé... Quoi ?!!";
			link.l1 = "Eh bien, comment vous dire... En somme, il y a des gens ici pour qui vous êtes une épine dans le pied.";
			link.l1.go = "GoodTalk_1_1";
		break;
		case "GoodTalk_1_1":
			dialog.text = "Je ne sais même pas quoi dire... "+ GetSexPhrase("Vous savez,", "Vous savez,") +" vous comprenez sans doute que nous sommes des sans-abri, on nous traite avec mépris.";
			link.l1 = "Au point de souhaiter votre mort ?";
			link.l1.go = "GoodTalk_1_2";
		break;
		case "GoodTalk_1_2":
			dialog.text = "La mort ?! Non, c'est peu probable. וcoutez, de quoi parlez-vous ? Vous me faites peur.";
			link.l1 = "Hé, et il fait bien, c'est ce qui fait peur. En somme, on ne sait pas qui pourraient être vos bienfaiteurs, si je comprends bien.";
			link.l1.go = "GoodTalk_1_3";
		break;
		case "GoodTalk_1_3":
			dialog.text = "Je ne sais pas, bien sמr ! C'est vous qui "+ GetSexPhrase("avez traité avec eux", "avez traité avec eux") +".";
			link.l1 = ""+ GetSexPhrase("J'ai traité avec eux", "J'ai traité avec eux") +" par un intermédiaire, pour ainsi dire. Ce qui m'intéresse, c'est de savoir qui se cache derrière tout ça... Bon, sois prudent, l'ami.";
			link.l1.go = "GoodTalk_1_4";
		break;
		case "GoodTalk_1_4":
			dialog.text = "Oui, je vais essayer, même si je n'en ai guère les moyens.";
			link.l1 = "Je comprends. Mais je vous ai "+ GetSexPhrase("prévenu", "prévenu") +".";
			link.l1.go = "exit";
		break;

		case "GoodTalk_2":
			dialog.text = "Allez, venez-en au fait.";
			link.l1 = "Vous savez, j'aimerais vraiment savoir à qui vous avez fait tant de tort qu'on ne peut plus vous voir en peinture ?";
			link.l1.go = "GoodTalk_2_1";
		break;
		case "GoodTalk_2_1":
			dialog.text = "On ne peut plus nous voir ? Et qui ça, nous ?";
			link.l1 = "Tous les mendiants des îles des Caraïbes.";
			link.l1.go = "GoodTalk_2_2";
		break;
		case "GoodTalk_2_2":
			dialog.text = "Je ne sais même pas quoi dire... Et alors, nous avons vraiment fait du tort ?";
			link.l1 = "Oui. Au point qu'on veut votre mort.";
			link.l1.go = "GoodTalk_2_3";
		break;
		case "GoodTalk_2_3":
			dialog.text = "Oh oh, eh bien !.. Mais "+ GetSexPhrase("vous-même", "vous-même") +" comprenez sans doute que le tort que nous causons aux autres se résume à la puanteur et aux puces. Si quelqu'un est prêt à nous tuer pour ça, alors je ne comprends plus rien à cette vie !";
			link.l1 = "C'est bien ce que je dis : je ne comprends pas d'oם vient une telle haine.";
			link.l1.go = "GoodTalk_2_4";
		break;
		case "GoodTalk_2_4":
			dialog.text = "Désolé, mais pour moi aussi, c'est un mystère complet. Je suis totalement perdu...";
			link.l1 = "Compris. Eh bien, désolé de vous avoir "+ GetSexPhrase("dérangé", "dérangé") +" dans vos affaires.";
			link.l1.go = "GoodTalk_2_5";
		break;
		case "GoodTalk_2_5":
			dialog.text = "Ce n'est rien. Je ne dirais pas que je suis très occupé...";
			link.l1 = "Eh bien, tout de même.";
			link.l1.go = "exit";
		break;

		case "GoodTalk_3":
			dialog.text = "Je vous écoute, demandez.";
			link.l1 = "Je me suis "+ GetSexPhrase("heurté", "heurtée") +" à une circonstance plutכt inattendue... En somme, le fait est qu'il y a aux Caraïbes des gens très mécontents de vos semblables.";
			link.l1.go = "GoodTalk_3_1";
		break;
		case "GoodTalk_3_1":
			dialog.text = "Oui, je sais qui vous êtes !";
			link.l1 = "Hum, et qui suis-je donc ?";
			link.l1.go = "GoodTalk_3_2";
		break;
		case "GoodTalk_3_2":
			dialog.text = "Vous êtes "+ GetSexPhrase("ce capitaine", "celle") +" qui cherche à savoir qui nous hait et veut soi-disant notre mort. La rumeur s'est déjà répandue parmi les nכtres.";
			link.l1 = "Oui, c'est moi. Mais je dis la vérité, sans aucun « soi-disant ». Et je vous recommande de prendre tout ça au sérieux : on offre beaucoup d'argent pour ce travail.";
			link.l1.go = "GoodTalk_3_3";
		break;
		case "GoodTalk_3_3":
			dialog.text = "Quoi qu'il en soit, l'un des nכtres veut vous parler de cette affaire.";
			link.l1 = "Et qui est-ce ?";
			link.l1.go = "GoodTalk_3_4";
		break;
		case "GoodTalk_3_4":
			pchar.questTemp.LSC.qtyTalk.headPoormanId = GetPoorHeadManId(npchar);
			sld = characterFromId(pchar.questTemp.LSC.qtyTalk.headPoormanId);
			dialog.text = "Il s'appelle " + GetFullName(sld) + ". Il traîne du cכté de " + XI_ConvertString("Colony" + sld.city + "Voc") + ".";
			link.l1 = "Compris. Eh bien, je crois que je passerai le voir à l'occasion.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_PoorsMurder", "3");
			AddQuestUserData("ISS_PoorsMurder", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_PoorsMurder", "sCity", XI_ConvertString("Colony" + sld.city + "Acc"));
			AddQuestUserData("ISS_PoorsMurder", "sName", GetFullName(sld));
		break;

		case "GoodTalk_4":
			dialog.text = "Je vous écoute.";
			link.l1 = "Qui, à votre avis, pourrait souhaiter la disparition des mendiants ?";
			link.l1.go = "GoodTalk_4_1";
		break;
		case "GoodTalk_4_1":
			sld = characterFromId(pchar.questTemp.LSC.qtyTalk.headPoormanId);
			dialog.text = "Je vous connais, mais je ne peux pas répondre à votre question. Il faut aller à " + XI_ConvertString("Colony" + sld.city + "Acc") + ", vous y trouverez l'un des nכtres, nommé " + GetFullName(sld) + ". Il voulait vous en parler.";
			link.l1 = "Compris. C'est ce que je vais faire.";
			link.l1.go = "exit";
		break;
		//основной бродяга
		case "PoorHeadMan":
			dialog.text = "Si vous êtes le capitaine " + GetFullName(pchar) + ", alors c'est bien ça.";
			link.l1 = "C'est exactement mon nom.";
			link.l1.go = "PoorHeadMan_1";
		break;
		case "PoorHeadMan_1":
			dialog.text = "Eh bien, c'est parfait. Si j'ai bien compris, vous cherchez à savoir à qui nous avons vraiment fait du tort. Et au point qu'on soit prêt à nous tuer. C'est bien ça ?";
			link.l1 = "Eh bien, oui. J'ajouterai seulement : pas à nous tuer, mais à engager un assassin.";
			link.l1.go = "PoorHeadMan_2";
		break;
		case "PoorHeadMan_2":
			dialog.text = "Hum, c'est un élément important... Et comment s'appelait l'homme qui vous en a parlé ?";
			link.l1 = "Oliver Trust.";
			link.l1.go = "PoorHeadMan_3";
		break;
		case "PoorHeadMan_3":
			dialog.text = "Ce nom ne me dit rien... En somme, j'ai une idée.";
			link.l1 = "Expliquez-vous.";
			link.l1.go = "PoorHeadMan_4";
		break;
		case "PoorHeadMan_4":
			dialog.text = "Il y a eu une histoire à Willemstad, à Curaçao, qui, à mon avis, ressemble un peu à ce qui vous est arrivé. En somme, nous avions un compagnon d'infortune qui avait décidé de s'installer chez les Hollandais, à Curaçao. Il s'appelait Teaser Dan\n"+
				"Bref, il a vécu là-bas environ un mois, et au bout de ce temps, il a attiré l'attention du gouverneur général Peter Stuyvesant. Depuis, Teaser a commencé à avoir des ennuis avec les soldats en ville, puis avec le commandant... Finalement, on l'a chassé de Willemstad, et on ne sait plus rien de lui.";
			link.l1 = "Hum, et quel rapport avec mon affaire ?";
			link.l1.go = "PoorHeadMan_5";
		break;
		case "PoorHeadMan_5":
			dialog.text = "וcoutez la suite. Nous avons commencé à chercher ce qui était arrivé à Teaser, oם il était passé, et nous avons appris quelque chose sur Stuyvesant. Peu de gens le savent, mais Stuyvesant est le plus gros fournisseur d'esclaves africains pour le Nouveau Monde !"+
				"Il travaille en étroite collaboration avec la Compagnie néerlandaise des Indes occidentales, et ils brassent ce genre d'affaires à ne plus savoir qu'en faire.";
			link.l1 = "Et alors ?";
			link.l1.go = "PoorHeadMan_6";
		break;
		case "PoorHeadMan_6":
			dialog.text = "Et le fait est que presque tous les nכtres sont d'anciens esclaves. Vous croyez que nous sommes paresseux et fainéants ? Pas du tout, c'est juste que, par un hasard du destin, nous avons dמ traverser cet enfer et y perdre la santé. Ici, on rend souvent la liberté aux Blancs, parce qu'on a besoin de colons "+
				"Mais tous les anciens esclaves ne peuvent pas labourer la terre et arracher des souches, après des mois passés dans la cale d'un galion pour venir jusqu'ici. Et Stuyvesant, apparemment, n'aime pas les anciens esclaves qui n'ont rien fait d'utile.";
			link.l1 = "Hum, tout ça me paraît un peu tiré par les cheveux...";
			link.l1.go = "PoorHeadMan_7";
		break;
		case "PoorHeadMan_7":
			dialog.text = "Peut-être, mais c'est tout ce que je sais et ce que je peux supposer. Je ne connais pas d'autres ennemis des mendiants aussi riches et influents. Alors si vous voulez en savoir plus sur cette affaire, je pense qu'il faut aller voir du cכté de la résidence de Willemstad.";
			link.l1 = "Et qu'est-ce que je dois y chercher ?";
			link.l1.go = "PoorHeadMan_8";
		break;
		case "PoorHeadMan_8":
			dialog.text = "Des papiers, "+ GetSexPhrase("mon ami", "madame") +", de la correspondance d'affaires. Tout ce que je vous ai dit est vraiment tiré par les cheveux. Il me semble qu'il y a derrière l'offre de ce Trust quelque chose de bien plus sérieux qu'une simple antipathie.";
			link.l1 = "Hum, je le pense aussi. Il se trame quelque chose de sérieux, vu l'ampleur du projet et le montant de la rémunération.";
			link.l1.go = "PoorHeadMan_9";
		break;
		case "PoorHeadMan_9":
			dialog.text = "Eh bien, j'ai dit tout ce que je voulais dire. Merci de m'avoir "+ GetSexPhrase("écouté", "écouté") +". Si vous trouvez quelque chose qui mérite votre attention, venez me voir tout de suite, nous y réfléchirons... Et merci de ne pas nous avoir "+ GetSexPhrase("fait", "fait") +" de mal.";
			link.l1 = "Je vous en prie. Merci pour l'information.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toVillemstadResidence";
			AddQuestRecord("ISS_PoorsMurder", "4");
			//сработает прерывание, чтобы показать геймеру, где нужный сундук
			pchar.quest.LSC_enterStuvesantBox.win_condition.l1 = "locator";
			pchar.quest.LSC_enterStuvesantBox.win_condition.l1.location = "Villemstad_TownhallRoom";
			pchar.quest.LSC_enterStuvesantBox.win_condition.l1.locator_group = "box";
			pchar.quest.LSC_enterStuvesantBox.win_condition.l1.locator = "private2";
			pchar.quest.LSC_enterStuvesantBox.function = "LSC_enterStuvesantBox";
		break;
		//базар с основным после нахождения письма
		case "FoundLetter":
			dialog.text = "Bon, voyons ce que vous avez là...";
			link.l1 = "Voici la lettre que j'ai trouvée à la résidence de Stuyvesant. C'est une correspondance entre lui et la Compagnie néerlandaise des Indes occidentales. Il en ressort clairement que c'est cette compagnie de commerce qui a lancé l'élimination des mendiants.";
			link.l1.go = "FoundLetter_1";
		break;
		case "FoundLetter_1":
			dialog.text = "Ah ah, je vois...";
			link.l1 = "Il y est question d'une île. Et d'objets de luxe. Et pour une raison inconnue, tout cela tourne autour des vagabonds. Dites-moi, l'ami, de quoi s'agit-il ?";
			link.l1.go = "FoundLetter_2";
			TakeItemFromCharacter(pchar, "letter_LSC");
		break;
		case "FoundLetter_2":
			dialog.text = "Hum, je ne sais même pas comment le dire... Je crois que l'île en question est la mythique île de la Justice, si populaire chez les mendiants.";
			link.l1 = "Quoi ?";
			link.l1.go = "FoundLetter_3";
		break;
		case "FoundLetter_3":
			dialog.text = "Eh bien, les vagabonds, vous le comprenez vous-même, ce sont des démunis : des destins brisés, des vies brisées. Et même sans santé, sans toit, sans argent, on a envie de croire à quelque chose de bon pour l'avenir. La plupart des nכtres croient à l'existence de cette île de la Justice, et cette croyance leur sauve souvent la vie.";
			link.l1 = "Parlez-moi de cette île. Tout ce que vous savez et ce qu'on en dit.";
			link.l1.go = "FoundLetter_4";
		break;
		case "FoundLetter_4":
			dialog.text = "On dit qu'il existe quelque part dans la région une île, mais qui n'a rien de naturel. Et que sur cette île règnent la loi et la justice, que la vie y est clémente pour les braves gens. Moi, je n'y crois pas beaucoup, il n'y a pas de justice sur terre...";
			link.l1 = "Hum, mais la lettre dit que cette île existe ! Lisez vous-même : « Il s'avère que les rumeurs sur l'île ont un fondement réel... »";
			link.l1.go = "FoundLetter_5";
		break;
		case "FoundLetter_5":
			dialog.text = "Eh bien, je ne sais pas...";
			link.l1 = "Et pourquoi ces rumeurs ont-elles commencé ? Comment tout cela a-t-il débuté ?";
			link.l1.go = "FoundLetter_6";
		break;
		case "FoundLetter_6":
			dialog.text = "Tout a commencé avec Teaser Dan. Il avait un peu perdu la tête : il avait survécu à plusieurs naufrages. Tous les nכtres lui avaient dit de ne pas aller à Curaçao, mais il a quand même décidé d'y vivre... Bref, il prétendait avoir vécu des mois sur cette île, et il racontait des contes de fées.";
			link.l1 = "Hum, et la Compagnie néerlandaise des Indes occidentales pense que ce ne sont pas des contes... Et oם est Teaser maintenant, dites-vous ?";
			link.l1.go = "FoundLetter_7";
		break;
		case "FoundLetter_7":
			dialog.text = "Disparu. Nous n'avons pas réussi à le retrouver. Il a disparu sans laisser de traces.";
			link.l1 = "Je me souviens que vous m'avez dit qu'il avait commencé à avoir des ennuis à Willemstad. On l'a chassé de la ville, il me semble...";
			link.l1.go = "FoundLetter_8";
		break;
		case "FoundLetter_8":
			dialog.text = "Oui, c'est exact. Après qu'il a attiré l'attention de Stuyvesant.";
			link.l1 = "Apparemment, il va falloir que je retourne à Curaçao...";
			link.l1.go = "FoundLetter_9";
		break;
		case "FoundLetter_9":
			dialog.text = "Eh bien, bonne chance ! Merci de votre aide, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			link.l1 = "Porte-toi bien, l'ami.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toTalkStuvesant";
			pchar.questTemp.LSC.poorName = GetFullName(npchar));
			AddQuestRecord("ISS_PoorsMurder", "7");
			AddQuestUserData("ISS_PoorsMurder", "sName", pchar.questTemp.LSC.poorName);
			//снимаем прерывание на завал нищих, деньги уже не получить
			pchar.quest.ISS_Murder1.over = "yes";
			pchar.quest.ISS_Murder2.over = "yes";
			pchar.quest.ISS_Murder3.over = "yes";
			pchar.quest.ISS_Murder4.over = "yes";
			pchar.quest.ISS_Murder5.over = "yes";
			pchar.quest.ISS_Murder6.over = "yes";
			pchar.quest.ISS_Murder7.over = "yes";
			pchar.quest.ISS_Murder8.over = "yes";
			pchar.quest.ISS_Murder9.over = "yes";
			pchar.quest.ISS_Murder10.over = "yes";
			pchar.quest.ISS_Murder11.over = "yes";
			pchar.quest.ISS_Murder12.over = "yes";
			pchar.quest.ISS_Murder13.over = "yes";
			pchar.quest.ISS_Murder14.over = "yes";
			pchar.quest.ISS_Murder15.over = "yes";
			pchar.quest.ISS_Murder16.over = "yes";
			pchar.quest.ISS_Murder17.over = "yes";
		break;
		//базар с основным после завала Оливера Траста
		case "GoLSC":
            dialog.text = "Parfait ! Alors, dites-moi, de quoi s'agit-il ?";
            link.l1 = "Vous savez, vous aviez raison dans l'hypothèse que vous avez faite au tout début de notre conversation. Il s'agit bien de Teaser Dan et de son île.";
            link.l1.go = "GoLSC_1";
		break;
		case "GoLSC_1":
			dialog.text = "Expliquez-vous, je vous en prie !";
			link.l1 = "Je ne peux pas en dire beaucoup pour l'instant. Mais je vous dirai ceci : l'île de la Justice, dont Teaser parlait tant, n'est pas une invention. Elle existe, et je vais m'y rendre !";
			link.l1.go = "GoLSC_2";
		break;
		case "GoLSC_2":
			dialog.text = "Je n'arrive pas à y croire !..";
			link.l1 = "Il y a aussi une très mauvaise nouvelle : Teaser Dan est mort.";
			link.l1.go = "GoLSC_3";
		break;
		case "GoLSC_3":
			dialog.text = "Ah, bon sang ! C'est dommage...";
			link.l1 = "Je n'ai jamais vu Teaser, mais j'ai compris quel genre d'homme c'était. C'est vraiment dommage.";
			link.l1.go = "GoLSC_4";
		break;
		case "GoLSC_4":
			dialog.text = "Alors vous allez essayer de trouver cette île ? Dans ce cas, je vais vous donner la clé de Teaser.";
			link.l1 = "Quelle clé ?";
			link.l1.go = "GoLSC_5";
		break;
		case "GoLSC_5":
			dialog.text = "Je ne sais pas exactement. Teaser me l'a confiée avant de partir pour Curaçao. Il disait que c'était la clé de Diffindur, mais je n'ai aucune idée de ce que ça veut dire.";
			link.l1 = "Une clé mystérieuse ! Intéressant...";
			link.l1.go = "GoLSC_6";
		break;
		case "GoLSC_6":
			dialog.text = "Selon ses instructions, je dois remettre cette clé à quiconque voudra trouver l'île. Teaser disait aussi que cette clé devait résoudre les problèmes du nouveau citoyen de l'île. Je n'ai aucune idée de ce que ça signifie, mais je suis heureux d'exaucer sa demande.";
			link.l1 = "Merci, l'ami. Et adieu.";
			link.l1.go = "exit";
			ChangeItemName("keyQuestLSC", "itmname_keyQuestLSC_Tizer");
			ChangeItemDescribe("keyQuestLSC", "itmdescr_keyQuestLSC_Tizer");
			sld = ItemsFromID("keyQuestLSC");
			DeleteAttribute(sld, "shown");
			GiveItem2Character(pchar, "keyQuestLSC");
		break;
	}
}

string GetPoorHeadManId(ref NPChar)
{
    ref ch;
	int n;
    string storeArray[30];	locations[n].private9.key = "key3";
	locations[n].private9.items.jewelry1 = 30;
    int howStore = 0;
	for(n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(ch,Characters[n]);
        if (CheckAttribute(ch, "Dialog.Filename") && ch.Dialog.Filename == "Common_poorman.c" && NPChar.id != ch.id && !CheckAttribute(ch, "quest.talk"))
		{
            storeArray[howStore] = ch.id;
            howStore++;
		}
    }
    if (howStore == 0) return "none";
    else return storeArray[rand(howStore-1)];
}
