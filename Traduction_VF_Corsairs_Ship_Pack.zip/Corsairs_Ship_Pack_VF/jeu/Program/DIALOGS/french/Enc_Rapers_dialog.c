void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, Diag;
	int i;
	string sTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "Exit_Fight":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			LAi_SetPlayerType(pchar);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_SetImmortal(sld, false);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");

			if(pchar.GenQuest.EncGirl == "RapersTreasure")
			{
				LAi_group_SetCheckFunction("EnemyFight", "EncGirl_RapersAfter");
			}
			else
			{
				LAi_group_SetCheck("EnemyFight", "LandEnc_RapersAfrer");
				sld = CharacterFromID("CangGirl");
				LAi_SetActorType(sld);
				LAi_ActorAfraid(sld, npchar, true);
			}
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "exit_noFight":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_SetActorType(sld);
				LAi_ActorFollow(sld, characterFromId("CangGirl"), "", -1);
				LAi_SetCheckMinHP(sld, LAi_GetCharacterHP(sld)-1, false, "LandEnc_RapersBeforeDialog");
			}
			sld = CharacterFromID("CangGirl");
			LAi_SetActorType(sld);
			LAi_ActorAfraid(sld, npchar, true);
			DialogExit();
			AddDialogExitQuest("OpenTheDoors");
		break;

		case "First time":
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_type_actor_Reset(sld);
				LAi_RemoveCheckMinHP(sld);
			}
//			Diag.TempNode = "OnceAgain";
			if(pchar.GenQuest.EncGirl == "Begin_1")
			{
				dialog.text = LinkRandPhrase("Passe ton chemin, "+ GetSexPhrase("l'ami", "ma petite") +". Elle nous remerciera plus tard.",
											 "Dégage ! N'empêche pas ces messieurs de s'amuser.",
											 "Ne te mêle pas de mes affaires, "+ GetSexPhrase("étranger", "ma belle") +". La belle affaire, on va juste s'amuser un peu !");
				link.l1 = LinkRandPhrase("Je ne laisserai pas faire ça !", "Cessez vos agissements !", "Je ne permettrai aucune violence !");
				link.l1.go = "Node_Fight";
				link.l2 = RandPhraseSimple("Compris, je m'en vais. Pardon de vous avoir interrompus.", "Je n'ose pas vous déranger. Excusez-moi de vous avoir importunés.");
				link.l2.go = "Exit_NoFight";
				pchar.GenQuest.EncGirl = "Begin_11";
			}
			if(pchar.GenQuest.EncGirl == "Begin_2")
			{
				if(sti(pchar.rank) < 10)
				{
					dialog.text = LinkRandPhrase("Passe ton chemin, "+ GetSexPhrase("l'ami", "ma petite") +". Elle nous remerciera plus tard.",
											 "Dégage ! N'empêche pas ces messieurs de s'amuser.",
											 "Ne te mêle pas de mes affaires, "+ GetSexPhrase("étranger", "ma belle") +". La belle affaire, on va juste s'amuser un peu !");
					link.l1 = LinkRandPhrase("Je ne laisserai pas faire ça !", "Cessez vos agissements !", "Je ne permettrai aucune violence !");
					link.l1.go = "Node_Fight";
					link.l2 = RandPhraseSimple("Compris, je m'en vais. Pardon de vous avoir interrompus.", "Je n'ose pas vous déranger. Excusez-moi de vous avoir importunés.");
					link.l2.go = "Exit_NoFight";
					pchar.GenQuest.EncGirl = "Begin_11";
				}
				else
				{
					dialog.text = RandPhraseSimple("Hé, "+ GetSexPhrase("étranger", "ma belle") +" ! Pourquoi chercher des ennuis ? C'est une fille bien connue dans la colonie. On l'a déjà payée. Mais en te voyant, elle a décidé de filer en douce.",
												   "Hé, "+ GetSexPhrase("l'ami", "ma petite") +", passe ton chemin et ne te mêle pas de ce qui ne te regarde pas. On a gagné cette fille aux dés, mais elle s'est révélée trop farouche. דa fait une heure qu'on lui court après.");
					link.l1 = "Je ne veux rien savoir, je ne laisserai pas faire de mal à cette fille !";
					link.l1.go = "Node_3";
					link.l2 = RandPhraseSimple("דa alors ! Et moi qui allais presque y croire ! Eh bien, elle est forte, la belle...", "Ah, bon, c'est une autre affaire. Eh bien, amusez-vous, si ça vous chante.");
					link.l2.go = "Exit_NoFight";
					pchar.GenQuest.EncGirl = "Begin_22";
				}
			}
			if(pchar.GenQuest.EncGirl == "Begin_3")
			{
				if(sti(pchar.rank) < 20)
				{
					dialog.text = "Passe ton chemin, "+ GetSexPhrase("l'ami", "ma jolie") +", va. On se débrouillera sans toi.";
					link.l1 = "Je ne permettrai aucune violence !";
					link.l1.go = "Node_5";
					pchar.GenQuest.EncGirl = "Begin_33";
				}
				else
				{
					dialog.text = RandPhraseSimple("Hé, "+ GetSexPhrase("étranger", "ma belle") +", pourquoi chercher des ennuis ? C'est une fille bien connue dans la colonie. On l'a déjà payée. Mais en te voyant, elle a décidé de filer en douce.",
												   "Hé, "+ GetSexPhrase("l'ami", "ma petite") +", passe ton chemin et ne te mêle pas de ce qui ne te regarde pas. On a gagné cette fille aux dés, mais elle s'est révélée trop farouche. דa fait une heure qu'on lui court après.");
					link.l1 = "Je ne veux rien savoir, je ne laisserai pas faire de mal à cette fille !";
					link.l1.go = "Node_3";
					link.l2 = RandPhraseSimple("דa alors ! Et moi qui allais presque y croire ! Eh bien, elle est forte, la belle...", "Ah, bon, c'est une autre affaire. Eh bien, amusez-vous, si ça vous chante.");
					link.l2.go = "Exit_NoFight";
					pchar.GenQuest.EncGirl = "Begin_22";
				}
			}
		break;

		case "Node_Fight":
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("Oh, tu es sorti te promener au mauvais moment... ", "Tu as décidé de jouer les héroïnes ? ") +"Les gars, sus à "+ GetSexPhrase("lui", "elle") +" !", "Oh, espèce de "+ GetSexPhrase("limace", "garce") +" ! א qui crois-tu barrer la route ?! Sus à "+ GetSexPhrase("lui", "elle") +" !");
			link.l1 = "J'en ai vu de plus menaçants que vous.";
			link.l1.go = "Exit_Fight";
			ChangeCharacterReputation(pchar, 5);
		break;

		case "Node_3":
			pchar.GenQuest.EncGirl.price = 1100*(rand(4)+5) + 200 * sti(pchar.rank);
			dialog.text = "Oui, elle nous a coמté une jolie somme ! Si tu es si noble, tu peux l'avoir pour " + sti(pchar.GenQuest.EncGirl.price) + " piastres."+ GetSexPhrase(" Tu vas bien t'amuser avec elle, héhé..", "") +"";
			if(sti(pchar.money) >= sti(pchar.GenQuest.EncGirl.price))
			{
				link.l1 = RandPhraseSimple("Voici votre argent, je l'emmène.", "Ne montre pas les dents. J'emmène la fille, voici l'argent.");
				link.l1.go = "Node_4";
			}
			link.l2 = LinkRandPhrase("Tu voulais des piastres ?! Tu ne voudrais pas plutכt de l'acier entre les cכtes ?!",
									 "Vous vous amusez, mais la fille tient à peine debout de peur !",
									 "Qui essaies-tu de rouler ?! וpouvantail des bois !");
			link.l2.go = "Node_Fight";
		break;

		case "Node_4": // бандюки уходят, девица остаётся - ГГ её выкупил у бандюков
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			AddMoneyToCharacter(pchar, -makeint(sti(pchar.GenQuest.EncGirl.price)));
			ChangeCharacterReputation(pchar, 7);
			sGlobalTemp = "Saved_CangGirl";
			pchar.GenQuest.EncGirl.Ransom = true;
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_SetImmortal(sld, true);
				LAi_SetActorType(sld);
				if(i == 1) LAi_ActorRunToLocation(sld, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
				else LAi_ActorRunToLocation(sld, "reload", sTemp, "none", "", "", "OpenTheDoors", 5.0);
			}
			DialogExit();
			AddDialogExitQuestFunction("EncGirl_Saved");
		break;

		case "Node_5":
			dialog.text = "Pourquoi la croyez-vous ?! Quelle violence ? Elle s'est enfuie de chez elle, on lui court après depuis ce matin : c'est son maître qui nous envoie.";
			link.l1 = RandPhraseSimple("Ah oui ? Eh bien, ça change tout. Rattrapez donc votre fugitive.", "Ah, bon, courez, courez. Moi, j'ai à faire ici...");
			link.l1.go = "Exit_NoFight";
			link.l2 = RandPhraseSimple("Ces histoires, tu les raconteras à tes petits-enfants, si tu vis assez longtemps !", "Qui as-tu décidé de tromper ?!");
			link.l2.go = "Node_6";
			link.l3 = "Je vais la ramener chez elle, pour qu'il n'arrive rien de fâcheux. Qui sont ses parents ?";
			link.l3.go = "Node_7";
		break;

		case "Node_6":
			dialog.text = "Eh bien, c'est toi qui l'as cherché. Alors, pardonne-moi...";
			link.l1 = "C'est l'hכpital qui se moque de la charité.";
			link.l1.go = "Exit_Fight";
		break;

		case "Node_7":
			sGlobalTemp = "Saved_CangGirl";
			if(pchar.GenQuest.EncGirl.city == "Panama") i = drand(2);
			else	i = drand(3);
			switch (i)
			{
				case 0:
					pchar.GenQuest.EncGirl.FatherNom = "le marchand";
					pchar.GenQuest.EncGirl.FatherGen = "le propriétaire du magasin";
					pchar.GenQuest.EncGirl.Father = "store_keeper";
				break;
				case 1:
					pchar.GenQuest.EncGirl.FatherNom = "il travaille à la capitainerie";
					pchar.GenQuest.EncGirl.FatherGen = "un employé de la capitainerie";
					pchar.GenQuest.EncGirl.Father = "portman_keeper";
				break;
				case 2:
					pchar.GenQuest.EncGirl.FatherNom = "il est commandant du fort";
					pchar.GenQuest.EncGirl.FatherGen = "le commandant du fort";
					pchar.GenQuest.EncGirl.Father = "fort_keeper";
				break;
				case 3:
					pchar.GenQuest.EncGirl.FatherNom = "le propriétaire du chantier naval";
					pchar.GenQuest.EncGirl.FatherGen = "le propriétaire du chantier naval";
					pchar.GenQuest.EncGirl.Father = "shipyard_keeper";
				break;
			}
			dialog.text = "Son père – " + pchar.GenQuest.EncGirl.FatherNom + " – vit à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ". Seulement, ne nous laissez pas tomber : il a un sale caractère, il nous écorcherait vifs...";
			link.l1 = "Ne vous en faites pas. Je la livrerai dans les meilleures conditions.";
			link.l1.go = "Node_12";
			pchar.GenQuest.EncGirl = "toParents";
		break;

		case "Node_12":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			ChangeCharacterReputation(pchar, 5);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_SetActorType(sld);
				LAi_SetImmortal(sld, true);
				if(i == 1) LAi_ActorRunToLocation(sld, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
				else LAi_ActorRunToLocation(sld, "reload", sTemp, "none", "", "", "OpenTheDoors", 5.0);
				sld.lifeDay = 0;
			}
			DialogExit();
			AddDialogExitQuestFunction("EncGirl_Saved");
		break;

		case "Node_8":
			dialog.text = "Nous voici de nouveau réunis. Et oם est votre compagne de voyage ? Remarquez, on n'a plus besoin d'elle, puisque vous êtes là.";
			link.l1 = "Messieurs, il me semble que la somme que vous avez reçue suffit pour laisser cette fille tranquille.";
			link.l1.go = "Node_9";
		break;

		case "Node_9":
			if(drand(1) == 0)
			{
				pchar.GenQuest.EncGirl.PirateName1 = "l" + rand(GetNamesCount(NAMETYPE_NICK) - 1);
				pchar.GenQuest.EncGirl.PirateIdx = NAMETYPE_NICK;
			}
			else
			{
				pchar.GenQuest.EncGirl.PirateName1 = "l" + rand(GetNamesCount(NAMETYPE_VIP) - 1);
				pchar.GenQuest.EncGirl.PirateIdx = NAMETYPE_VIP;
			}
			pchar.GenQuest.EncGirl.PirateName2 = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			switch(drand(4))
			{
				case 0:
					sTemp = "une jambe";
				break;
				case 1:
					sTemp = "une main";
				break;
				case 2:
					sTemp = "une oreille";
				break;
				case 3:
					sTemp = "le nez";
				break;
				case 4:
					sTemp = "un œil";
				break;
			}
			dialog.text = "Qu'est-ce que ta somme, comparée aux trésors de " + GetName(pchar.GenQuest.EncGirl.PirateIdx , pchar.GenQuest.EncGirl.PirateName1, NAME_GEN) + " ? " +
							"Il était si avare qu'il n'a pas marié sa propre fille, pour ne pas dépenser d'argent pour la noce...\nMais il y a aussi notre part dans ses coffres ! "+
							GetName(NAMETYPE_ORIG, pchar.GenQuest.EncGirl.PirateName2, NAME_NOM) +" a perdu " + sTemp +" pendant un abordage ! Et pour quoi ?" +
							" Pour une misérable poignée de piastres ?! " + GetName(pchar.GenQuest.EncGirl.PirateIdx , pchar.GenQuest.EncGirl.PirateName1, NAME_NOM) + " a traîné tout le butin jusqu'à sa cachette. Mais maintenant, nous ne reculerons pas ! Montre-nous oם sont ses coffres ! ";
			link.l1 = "Hum, même si garder les trésors de votre capitaine ne fait pas partie de mon contrat, je ne peux pas vous montrer l'endroit... Parce que je ne le connais pas.";
			link.l1.go = "Node_10";
		break;

		case "Node_10":
			dialog.text = "Tu mens !!! Je sens déjà l'odeur des piastres qui sort de cette grotte ! Montre-nous l'endroit si tu ne veux pas mourir !";
			link.l1 = "Je vois que mes paroles ne vous convainquent pas. Peut-être que ma lame vous convaincra ?";
			link.l1.go = "Node_11";
		break;

		case "Node_11":
			pchar.GenQuest.EncGirl = "RapersTreasure";
			dialog.text = "Vous êtes "+ GetSexPhrase("un chien", "une ordure") +" ! Hors de mon chemin !...";
			link.l1 = "Argh...";
			link.l1.go = "exit_fight";
		break;

		case "EncGirl_Berglar":
			dialog.text = "Salut, toi. Il y a des plaintes contre toi.";
			link.l1 = "Des plaintes de qui ? De cette traînée ?";
			link.l1.go = "EncGirl_Berglar1";
		break;

		case "EncGirl_Berglar1":
			dialog.text = "Surveille ton langage ! Je ne laisserai personne faire du mal à ma petite sœur ! D'abord, tu l'as draguée dans la jungle, ensuite "+ GetSexPhrase("tu l'as amenée ici pour lui faire des propositions obscènes", "tu l'as traînée ici pour la dépouiller") +".";
			link.l1 = "וcoute, l'ami, je suis obligé d'écouter tout ça ?";
			link.l1.go = "EncGirl_Berglar2";
		break;

		case "EncGirl_Berglar2":
			pchar.GenQuest.EncGirl.BerglarSum = makeint(sti(pchar.money)/5) + 5000;
			if(sti(pchar.GenQuest.EncGirl.BerglarSum) > 250000) pchar.GenQuest.EncGirl.BerglarSum = 220000 + rand(30000);
			if(sti(pchar.GenQuest.EncGirl.BerglarSum) > 0)
			{
				dialog.text = "Non. Une modeste somme de " + sti(pchar.GenQuest.EncGirl.BerglarSum) + " piastres peut t'éviter tous les ennuis.";
				if(sti(pchar.money) >= sti(pchar.GenQuest.EncGirl.BerglarSum))
				{
					link.l1 = "Hum, les nobles actions ne sont pas bon marché de nos jours. Tiens...";
					link.l1.go = "EncGirl_Berglar3";
				}
				link.l2 = "Ce sera moins cher de te faire un trou dans le ventre, pour que tu ne me barres plus le chemin de la sortie.";
				link.l2.go = "EncGirl_Berglar4";
			}
			else
			{
				dialog.text = "Non. Mais tu vas devoir retourner tes poches, ou je te plante !";
				link.l1 = "Tiens, morveux ! Mais tu ne t'en tireras pas si facilement...";
				link.l1.go = "EncGirl_Berglar3_1";
				link.l2 = "Ce sera plus simple de te faire un trou dans le ventre, pour que tu ne me barres plus le chemin de la sortie.";
				link.l2.go = "EncGirl_Berglar4";
			}
		break;

		case "EncGirl_Berglar3":
			AddMoneyToCharacter(pchar, -makeint(sti(pchar.GenQuest.EncGirl.BerglarSum)));
			dialog.text = "Parfait. Bon débarras.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirlFack_outRoom");
		break;

		case "EncGirl_Berglar3_1":
			dialog.text = "Bien sמr que ça ne suffira pas, qui dit le contraire ? Eh bien, adieu, "+ GetSexPhrase("l'ami", "ma petite") +"."+ GetSexPhrase(" Et souviens-toi : tu n'es pas assez beau pour que les filles se jettent à ton cou sur-le-champ. דa te servira de leçon !", "") +"";
			link.l1 = ""+ GetSexPhrase("דa, c'est sמr !..", "Allez, dégage !") +"";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirlFack_outRoomRaped");
		break;

		case "EncGirl_Berglar4":
			dialog.text = "Pour "+ GetSexPhrase("un homme d'apparence si noble", "une jeune fille d'apparence si bien élevée") +", vous manquez singulièrement de savoir-vivre.";
			link.l1 = "On fait ce qu'on peut...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirlFack_fight");
		break;

		case "Node_2":
			dialog.text = "Eh bien, ne t'en prends qu'à toi-même ! Les gars, chatouillez- "+ GetSexPhrase("lui", "lui") +" les cכtes avec de l'acier !";
			Link.l1 = "Prie avant de mourir !";
			Link.l1.go = "Exit_Fight";
		break;

		case "OnceAgain":
			Diag.TempNode = "OnceAgain";
			dialog.text = "Tu voulais te joindre à nous ? "+ GetSexPhrase("Va au diable, il n'y en a déjà pas assez pour nous ", "Fiche le camp, une fille nous suffit ") +" !";
			Link.l1 = "Si c'est comme ça, je ne vous dérangerai pas.";
			Link.l1.go = "Exit_NoFight";
			Link.l2 = "Je ne laisserai pas une telle violence se commettre sous mes yeux !";
			Link.l2.go = "Node_2";
		break;

	}
}
