#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bonjour, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je suis très heureuse que vous ayez réussi à vous en sortir après ce terrible désastre... Même si, inutile de le dire, nous sommes tous passés par là... Vous savez, cette tempête va bientכt se terminer, et votre humeur va certainement s'améliorer. Oui, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service, mademoiselle... Dites-moi, vous avez de nouveaux arrivants après chaque tempête ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bonjour, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je suis très heureuse que vous ayez réussi à vous en sortir après ce terrible désastre... Même si, inutile de le dire, nous sommes tous passés par là. Oui, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service, mademoiselle...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que voulez-vous ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//муж Элис Тейлор
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "begin")
				{
					link.l7 = "J'ai entendu dire que vous cherchiez de l'aide pour une affaire...";
					link.l7.go = "ELTHusb_begin";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toElis")
				{
					link.l7 = "C'est votre mari, Maxim Taylor, qui m'envoie.";
					link.l7.go = "ELTHusb_toElis";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toElisGood")
				{
					link.l7 = "Alice, l'amiral va libérer votre mari.";
					link.l7.go = "ELTHusb_good";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de venir avec moi sur le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "FS_1":
			dialog.text = "Non, c'est loin d'être le cas, malheureusement. Beaucoup de navires viennent s'échouer chez nous, mais il n'y a pas assez de survivants à bord. Je ne sais pas pourquoi... Et au fait, je suis madame.";
			link.l1 = "Oh, pardonnez-moi...";
			link.l1.go = "FT_2";
		break;
		case "FT_1":
			dialog.text = "Madame. Je suis mariée.";
			link.l1 = "Oh, pardonnez-moi...";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Au fait, si vous n'êtes pas encore allé voir notre chef, l'amiral Chad Capper, vous feriez mieux de vous dépêcher. Sinon, il viendra vous trouver lui-même.";
			link.l1 = "Hum, je vois.";
			link.l1.go = "exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Je serai heureuse de vous aider si je le peux, bien sמr. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, mais je préfère m'en occuper moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je parle d'un autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrées.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Vous êtes anglaise ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l3 = "Dites-moi, vous vivez dans la Cité depuis longtemps ?";
				link.l3.go = "ansewer_3";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Comment, vous ne le savez pas encore ? C'est la Cité des navires abandonnés. Et nous sommes tous des gens perdus ici... Oh, comme j'en ai assez de tout ça !";
			link.l1 = "Je comprends...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Oui, je suis anglaise. Pourquoi ?";
			link.l1 = "Il y a beaucoup d'Anglais ici, en général ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Il y en a, mais je ne les ai pas comptés. Vous savez, ici, peu importe votre nation. Cela ne dit absolument rien et n'a d'effet sur rien.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Oui, je suis anglaise. Pourquoi ?";
			link.l1 = "Il y a beaucoup d'Anglais ici, en général ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "Pas vraiment, environ six mois.";
			link.l1 = "Je vois.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Lesquelles exactement ?",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je cherche des boulets, des bombes, de la mitraille, des boulets ramés, des vivres, des médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Bon, je n'ai ni vivres ni médicaments. Mais il reste pas mal de boulets sur le navire, de l'époque oם il naviguait. Combien vous en faut-il ?";
			link.l1 = "100 suffiront largement.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Très bien, prenez-les.";
			link.l1 = "Merci beaucoup ! Pouvez-vous me dire qui pourrait les transporter jusqu'au San Gabriel ?";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Hum, eh bien, je ne sais pas... Demandez à Felix Mendoza !";
			link.l1 = "D'accord, je n'y manquerai pas. Merci !";
			link.l1.go = "exit";
			pchar.questTemp.LSC.additional.balls = true;
			AddQuestRecord("ISS_MainLine", "49");
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Cependant... Et pourquoi devrais-je vous croire ?";
			link.l1 ="Vous ne me devez rien. Mais si vous ne partez pas avec moi maintenant, vous mourrez à coup sמr. Le fait est que la tempête qui approche va détruire la Cité.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Comment le savez-vous ?";
			link.l1 = "C'est le Mécanicien qui l'a calculé.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Oh, je crois Wedeker, apparemment, c'est ce qui va se passer. Bon, j'accepte.";
			link.l1 = "D'accord. Maintenant, allez sur le San Gabriel. Henrik Wedeker vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord.";
			link.l1 = "Seulement, ne vous attardez nulle part !";
			link.l1.go = "SeekCrew_all";
		break;
		//вызволение мужа
		case "ELTHusb_begin":
			dialog.text = "C'est vrai, "+ GetSexPhrase("monsieur", "mademoiselle") +". Mon mari, ce crétin de Maxim, est encore allé en prison. Je veux l'aider une dernière fois.";
			link.l1 = "Si je comprends bien, vous voulez le faire sortir de prison.";
			link.l1.go = "ELTHusb_begin_1";
		break;
		case "ELTHusb_begin_1":
			dialog.text = "C'est exact. Faites-le, et je pourrai vous remercier.";
			link.l1 = "Avec quoi, si je puis me permettre ?";
			link.l1.go = "ELTHusb_begin_2";
		break;
		case "ELTHusb_begin_2":
			dialog.text = "Eh bien, vous êtes "+ GetSexPhrase("un nouveau citoyen", "une nouvelle citoyenne") +" de la Cité. Je peux vous donner une chose très utile.";
			link.l1 = "Quoi donc ?";
			link.l1.go = "ELTHusb_begin_3";
		break;
		case "ELTHusb_begin_3":
			dialog.text = "L'une des clés qui ferment tous les coffres de la Cité.";
			link.l1 = "C'est vraiment une chose utile. J'accepte.";
			link.l1.go = "ELTHusb_begin_4";
			link.l2 = "Désolé, je n'en ai pas besoin.";
			link.l2.go = "ELTHusb_begin_disagree";
		break;
		case "ELTHusb_begin_disagree":
			dialog.text = "Eh bien, c'est dommage. Je chercherai de l'aide auprès d'autres personnes.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			CloseQuestHeader("ISS_ElisHusband");
			pchar.questTemp.LSC.ElisHusband = "over"; //закончим
		break;
		case "ELTHusb_begin_4":
			dialog.text = "Très bien. Alors j'attendrai mon mari.";
			link.l1 = "Je vais tout faire, attendez.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "5");
			AddQuestUserData("ISS_ElisHusband", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC.ElisHusband = "seekFreeMotod";
			sld = characterFromId("MaximTailor");
			sld.dialog.currentnode = "DontRemember";
		break;

		case "ELTHusb_toElis":
			dialog.text = "Et que veut ce salaud ?";
			link.l1 = "Si je comprends bien, il veut sortir de prison.";
			link.l1.go = "ELTHusb_toElis_1";
		break;
		case "ELTHusb_toElis_1":
			dialog.text = "Comme j'en ai assez de lui !..";
			link.l1 = "וcoutez, vous voulez le faire sortir de là, oui ou non ? Si vous le voulez, je pourrais vous aider dans cette affaire.";
			link.l1.go = "ELTHusb_toElis_2";
		break;
		case "ELTHusb_toElis_2":
			dialog.text = "D'accord, j'accepte votre aide. Libérez-le, et je vous donnerai une chose très utile.";
			link.l1 = "Hum... Et quoi exactement, si je puis me permettre ?";
			link.l1.go = "ELTHusb_toElis_3";
		break;
		case "ELTHusb_toElis_3":
			dialog.text = "L'une des clés qui ouvrent les coffres de la Cité.";
			link.l1 = "C'est une chose utile, j'accepte !";
			link.l1.go = "ELTHusb_begin_4";
			link.l2 = "Désolé, je n'en ai pas besoin.";
			link.l2.go = "ELTHusb_begin_disagree";
		break;

		case "ELTHusb_good":
			dialog.text = "Oh, mon Dieu, c'est vraiment vrai ? Comment y êtes-vous parvenu ?";
			link.l1 = "Eh bien, j'ai découvert quelque chose et je l'ai raconté à l'amiral. Chad a accepté de donner à votre mari une nouvelle chance de se ranger.";
			link.l1.go = "ELTHusb_good_1";
		break;
		case "ELTHusb_good_1":
			dialog.text = "Formidable ! Je pense qu'après une telle secousse, il ne boira plus autant.";
			link.l1 = "Je l'espère vraiment.";
			link.l1.go = "ELTHusb_good_2";
		break;
		case "ELTHusb_good_2":
			dialog.text = "Vous avez tenu parole, et je vais tenir la mienne. Prenez la clé, je vous prie.";
			link.l1 = "Merci, j'en ai vraiment besoin.";
			link.l1.go = "ELTHusb_good_3";
			GiveItem2Character(pchar, "key1");
		break;
		case "ELTHusb_good_3":
			dialog.text = "Mais gardez à l'esprit que vous ne devez pas fouiller les coffres des autres. Si on vous prend, vous êtes fini.";
			link.l1 = "Je le comprends, merci.";
			link.l1.go = "exit";
			CloseQuestHeader("ISS_ElisHusband");
			pchar.questTemp.LSC.ElisHusband = "over"; //закончим
			SetTimerFunction("LSC_ElisHusbandSet", 0, 0, 1);
		break;

	}
	NextDiag.PrevNode = NodeName;
}
