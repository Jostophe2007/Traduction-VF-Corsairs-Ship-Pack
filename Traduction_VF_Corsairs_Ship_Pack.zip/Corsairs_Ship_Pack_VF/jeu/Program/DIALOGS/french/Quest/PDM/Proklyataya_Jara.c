
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Hé, toi ! Qu'est-ce que tu traînes ici ! Viens ici, "+ GetSexPhrase("le gars", "la fille") +" !";
			link.l1 = "Je me présente : capitaine "+pchar.name+"et je me promène, je ne traîne pas !";
			link.l1.go = "Mne_Jarko_1";
			PlayVoice("Kopcapkz\Voices\PDM\Hervisse - Town Guard.wav");
		break;

		case "Mne_Jarko_1":
			dialog.text = "Oh, pardon, capitaine. Je n'avais pas vu qui vous étiez. C'est cette maudite chaleur.";
			MakeRandomLinkOrderTwo(link,
			"J'accepte vos excuses. Rester ici au soleil toute la journée ne doit pas être très agréable. On vous accorde au moins une pause pendant le quart ?",
			"Mne_Jarko_2",

			"Non, ça ne suffit pas. Vous êtes négligent et débraillé. Soyez plus poli la prochaine fois.",
			"exit");
			npchar.dialog.filename   = "Common_Soldier.c";
			npchar.dialog.currentnode   = "First time";
			LAi_SetGuardianType(npchar);
			LAi_group_MoveCharacter(npchar, "FRANCE_CITIZENS");
		break;

		case "Mne_Jarko_2":
			dialog.text = "Parfois, on se relaie, celui de gauche à droite, celui de droite à gauche... Tout dépend de l'endroit oם tombe l'ombre. C'est terrible, je donnerais n'importe quoi pour une gorgée de vin frais.";
			link.l1 = "Oui, c'est tout simplement abominable... Je peux peut-être vous aider d'une manière ou d'une autre ?";
			link.l1.go = "Mne_Jarko_3";
		break;

		case "Mne_Jarko_3":
			dialog.text = "Oh, merci, "+ GetSexPhrase("monsieur", "mademoiselle") +" ! Tout ce dont je peux rêver en ce moment, c'est d'une petite gorgée de vin. Bien sמr, je ne suis pas censé boire pendant mon service, mais quand même... דa vous ennuierait de m'apporter une bouteille de vin ? Je pourrais même vous la payer.";
			MakeRandomLinkOrderTwo(link,
			"Je sais combien le devoir peut être dur parfois... Je vais vous apporter une bouteille de vin.",
			"Mne_Jarko_4",

			"Soldat, vous êtes tout près de manquer à votre devoir. Je fermerai les yeux pour cette fois... Mais ne me demandez plus jamais ça. א plus tard.",
			"exit");
			npchar.dialog.filename   = "Common_Soldier.c";
			npchar.dialog.currentnode   = "First time";
		break;

		case "Mne_Jarko_4":
			dialog.text = "Je vous en serai éternellement redevable. Je vous en prie, faites vite.";
			link.l1 = "Je reviens en un clin d'œil.";
			link.l1.go = "Mne_Jarko_5";
			DeleteAttribute(npchar, "talker");
		break;

		case "Mne_Jarko_5":
			SetQuestHeader("PDM_Proklyataya_Jara");
			AddQuestRecord("PDM_Proklyataya_Jara", "1");
			DialogExit();
			pchar.questTemp.PDM_PJ_KV = "KupitVino";
			pchar.questTemp.PDM_PJ_SS = "SdatSoldata";
			sld = CharacterFromID("PDM_PJ_Strajnik_1");
			sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
			sld.dialog.currentnode = "Mne_Jarko_5_EsheRaz";
		break;

		case "Mne_Jarko_5_EsheRaz":
			dialog.text = "Vous m'avez apporté le vin ?";
			link.l1 = "Pas encore, je faisais juste un tour en ville. Mais je passerai à la taverne plus tard.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Mne_Jarko_5_EsheRaz";
		break;

		case "Prines_Vino_1":
			npchar.dialog.filename   = "Common_Soldier.c";
			npchar.dialog.currentnode   = "First time";
			dialog.text = "Re-bonjour, "+ GetSexPhrase("monsieur", "mademoiselle") +" ! Capitaine, vous m'avez apporté le vin ?";
			link.l1 = "Tenez, prenez.";
			link.l1.go = "Prines_Vino_2";
		break;

		case "Prines_Vino_2":
			TakeItemFromCharacter(pchar, "PDM_PJ_Vino");
			dialog.text = "Je ne pensais pas que vous arriveriez vraiment à m'apporter une bouteille. Merci, capitaine "+pchar.name+". Combien vous dois-je pour ce vin ?";
			MakeRandomLinkOrderTwo(link,
			"Ne vous souciez pas de l'argent : ça m'a fait plaisir de vous rendre ce service.",
			"Prines_Vino_Drujba_1",

			"500 pièces d'or. J'ai demandé un vin pas très cher, mais on dirait que votre taverne est tenue par un ancien pirate, ce " + GetFullName(CharacterFromID("FortFrance_tavernkeeper"))+".",
			"Prines_Vino_Obman_1");
		break;

		case "Prines_Vino_Drujba_1":
			dialog.text = "Vous êtes quelqu'un de très bon. Je serai heureux de vous rendre service si vous avez besoin de quoi que ce soit.";
			link.l1 = "Merci, l'ami. א plus tard.";
			link.l1.go = "A_Eto_eshe_ne_vse";
			ChangeCharacterReputation(pchar, 3);
		break;

		case "Prines_Vino_Obman_1":
			dialog.text = "500 pièces d'or ? Mais c'est la moitié de ma solde... Qu'est-ce que je vais faire maintenant ?";
			MakeRandomLinkOrderTwo(link,
			"Vous auriez dמ y penser plus tכt. Maintenant, payez.",
			"Prines_Vino_Obman_2",

			"Oubliez ça. Considérons cette bouteille comme un simple cadeau.",
			"Prines_Vino_Drujba_1");
		break;

		case "Prines_Vino_Obman_2":
			dialog.text = "Bon sang. Eh bien, si je tombe sur ce " + GetFullName(CharacterFromID("FortFrance_tavernkeeper"))+". Bon, prenez l'argent. Voilà, je dois monter la garde, je ne peux plus vous parler. א plus tard.";
			link.l1 = "Adieu, soldat.";
			link.l1.go = "A_Eto_eshe_ne_vse";
			ChangeCharacterReputation(pchar, -4);
			AddMoneyToCharacter(pchar, 437);
		break;

		case "A_Eto_eshe_ne_vse":
			DialogExit();
			sld = CharacterFromID("PDM_PJ_Strajnik_2");
			sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
			sld.dialog.currentnode = "Ya_Toje_Hochu_1";
			LAi_SetActorType(sld);
			LAi_ActorDialog(sld, pchar, "", 0.0, 0);
		break;

		case "Ya_Toje_Hochu_1":
			PlayVoice("Kopcapkz\Voices\PDM\Eustache Heumont.wav");
			dialog.text = "Mes salutations, "+ GetSexPhrase("monsieur", "mademoiselle") +". Content de vous voir !";
			link.l1 = "Pourquoi êtes-vous si content de me voir, soldat ? Et c'est quoi, ce sourire sur votre visage ?";
			link.l1.go = "Ya_Toje_Hochu_2";
		break;

		case "Ya_Toje_Hochu_2":
			dialog.text = "Je sais que vous êtes quelqu'un de bon. Je vous ai vu apporter une bouteille de vin à mon camarade... C'était un acte chrétien, et je l'ai apprécié. Je voulais aussi vous demander, capitaine... Pourriez-vous me faire la même charité ? S'il vous plaît, capitaine !";
			link.l1 = "Quoi ?!? Vous voulez que je vous achète du vin ?";
			link.l1.go = "Ya_Toje_Hochu_3";
		break;

		case "Ya_Toje_Hochu_3":
			dialog.text = "Eh bien, à vrai dire, je ne suis pas un grand amateur de vin. Mais une goutte de rhum ne me ferait pas de mal.";
			MakeRandomLinkOrderTwo(link,
			"Eh bien, vous n'êtes pas du genre timide, vous... Bon, tant pis. Pour être honnête, ma propre bonté d'âme me déconcerte, mais je vais vous acheter du rhum. Attendez-moi ici.",
			"Ya_Toje_Hochu_4",

			"Apparemment, on accepte maintenant les aveugles dans l'armée, puisque vous me prenez pour une serveuse. Pas de rhum, jeune homme, et si j'apprends qu'une des sentinelles boit pendant son service, je le dirai au gouverneur.",
			"Ya_Toje_Hochu_Proval");
		break;

		case "Ya_Toje_Hochu_Proval":
			DialogExit();
			sld = CharacterFromID("PDM_PJ_Strajnik_2");
			sld.dialog.filename   = "Common_Soldier.c";
			sld.dialog.currentnode   = "First time";
			CloseQuestHeader("PDM_Proklyataya_Jara");
			pchar.questdata.ProklyatayaJara = 1;
		break;

		case "Ya_Toje_Hochu_4":
			dialog.text = "Bien sמr. Je ne peux aller nulle part : je suis de service... Merci beaucoup, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
			link.l1 = "Je reviens bientכt.";
			link.l1.go = "Ya_Toje_Hochu_5";
		break;

		case "Ya_Toje_Hochu_5":
			DialogExit();
			AddQuestRecord("PDM_Proklyataya_Jara", "3");
			pchar.questTemp.PDM_PJ_KR = "KupitRom";
			sld = CharacterFromID("PDM_PJ_Strajnik_2");
			sld.Dialog.Filename = "Quest\PDM\Proklyataya_Jara.c";
			sld.dialog.currentnode = "Ya_Toje_Hochu_5_EsheRaz";
			LAi_SetGuardianType(sld);
			LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
			sld.City = "FortFrance";
		break;

		case "Ya_Toje_Hochu_5_EsheRaz":
			dialog.text = "Oh, vous êtes déjà de retour, capitaine ? Oם est mon rhum ?";
			link.l1 = "J'ai honte de le dire, mais j'ai oublié notre petit contrat. Je vais le chercher tout de suite.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Ya_Toje_Hochu_5_EsheRaz";
		break;

		case "Prines_Rom_1":
			npchar.dialog.filename   = "Common_Soldier.c";
			npchar.dialog.currentnode   = "First time";
			dialog.text = "Oh, vous voilà, capitaine ? Et... pardon... mais... Vous avez trouvé du rhum ?";
			link.l1 = "Tenez, prenez. Je pense que ça renforcera ma réputation de meilleur fournisseur local d'alcool pour l'armée française.";
			link.l1.go = "Prines_Rom_2";
		break;

		case "Prines_Rom_2":
			ChangeCharacterNationReputation(pchar, FRANCE, 5);
			TakeItemFromCharacter(pchar, "PDM_PJ_Rom");
			dialog.text = "Bonne plaisanterie. Et merci beaucoup pour le rhum. Vous êtes "+ GetSexPhrase("un homme fort", "une jolie fille") + " au grand cœur, pas comme ces aristocrates arrogants. J'aimerais avoir un commandant comme vous.";
			link.l1 = "Bon, soldat, vous feriez mieux de retourner à votre poste. Et pas un mot sur le rhum, sinon ma plaisanterie risque de ressembler un peu trop à la vérité...";
			link.l1.go = "Prines_Rom_3";
		break;

		case "Prines_Rom_3":
			dialog.text = "Comme vous voudrez, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je tiendrai ma langue, je vous le promets. Merci. Bonne journée.";
			link.l1 = "Je vous en prie. א plus tard.";
			link.l1.go = "Prines_Rom_4";
		break;

		case "Prines_Rom_4":
			DialogExit();
			CloseQuestHeader("PDM_Proklyataya_Jara");
			pchar.questdata.ProklyatayaJara = 1;
			AddQuestRecord("PDM_Proklyataya_Jara", "5");
			AddCharacterExpToSkill(pchar, "Leadership", 170);
			AddCharacterExpToSkill(pchar, "Commerce", 80);
			
			sld = CharacterFromID("PDM_PJ_Strajnik_1");
			LAi_SetActorType(sld);
			LAi_ActorAnimation(sld, "stun_1", "", 1.0);
			LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
			sld.City = "FortFrance";
			
			PChar.quest.PDM_PJ_Protrezvel.win_condition.l1 = "ExitFromLocation";
			PChar.quest.PDM_PJ_Protrezvel.win_condition.l1.location = PChar.location;
			PChar.quest.PDM_PJ_Protrezvel.win_condition = "PDM_PJ_Protrezvel";
		break;

	}
}
