// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			 // ==> квест "Странные вещи творятся на архипелаге
            if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_PoiskUchitel_Tavern"))
            {
                link.l1 = "J'ai besoin de renseignements sur une personne. Il porte toujours un capuchon rouge et se fait appeler le Maître.";
                link.l1.go = "PKM_SvtvA_PU_1";
            }
			// Gregg: "Goods for Richard Tillman" - where to look for Prenol
			if (PChar.UneasyDelivery == "2" && !CheckAttribute(PChar, "UneasyDelivery.TavernPorPax"))
			{
				link.l8 = "Dites, savez-vous oם je pourrais trouver Jacque Prenol ?";
				link.l8.go = "UneasyDelivery_1";
			}

			// Gregg: the "Black Orchid" (ported from Damned Destiny) - the keeper knows
			// where Brian George lived and remembers that brawl. The attribute may not
			// exist at all, hence separate checks: Storm has no short-circuit.
			if (CheckAttribute(PChar, "MysteriousArtefact"))
			{
				if (PChar.MysteriousArtefact == "3")
				{
					link.l9 = "Dites, savez-vous oם est la maison de Brian George ?";
					link.l9.go = "MysteriousArtefact_1";
				}
				if (PChar.MysteriousArtefact == "6")
				{
					if (!CheckAttribute(PChar, "MysteriousArtefact.BarmenTalk"))
					{
						link.l10 = "Vous vous souvenez que Brian George a déclenché une bagarre ici il y a deux semaines ? J'aimerais connaître les détails.";
						link.l10.go = "MysteriousArtefact_9";
					}
				}
			}
		break;

		case "UneasyDelivery_1":
			dialog.text = "Il habite à cכté de la capitainerie. Mettez-vous face à la capitainerie : sa porte est sur votre gauche.";
			link.l1 = "Et que pouvez-vous me dire de lui ? Peut-on faire affaire avec lui ?";
			link.l1.go = "UneasyDelivery_2";
		break;

		case "UneasyDelivery_2":
			PChar.UneasyDelivery.TavernPorPax = true;
			dialog.text = "Avec Jacque ? Bien sמr, si vous n'êtes pas un imbécile. Prenol est rusé, et l'essentiel est de ne pas vous laisser duper. דa, il sait faire. Alors soyez prudent.";
			link.l1 = "Eh bien, merci de votre aide. Portez-vous bien.";
			link.l1.go = "exit";
		break;

		
		//Квест "Strange things are happening in the archipelago"
		case "PKM_SvtvA_PU_1":
			dialog.text = "Oh, je m'en souviens. Mais il a déjà été arrêté. On dit qu'il a essayé de déclencher une émeute. Alors si vous voulez le trouver, allez directement à la prison de Port-au-Prince.";
			link.l1 = "Merci, vous m'avez beaucoup aidé.";
			link.l1.go = "exit";
			
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_PoiskUchitel_Tavern");
			//pchar.questTemp.PKM_SvtvA_PoiskUchitel_Turma = true;
			AddQuestRecord("PKM_Animists", "27");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			
			PChar.quest.PKM_SvtvA_TuremchikQuest.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_TuremchikQuest.win_condition.l1.location = "PortPax_prison";
			PChar.quest.PKM_SvtvA_TuremchikQuest.win_condition = "PKM_SvtvA_TuremchikQuest";
			
			sld = GetCharacter(NPC_GenerateCharacter("Satanist_Uchitel", "Animists1", "man", "man", sti(pchar.rank), PIRATE, -1, false));
			sld.name = "le Maître";
			sld.lastname = "";
			LAi_SetStayType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Учитель_Смерть";
			ChangeCharacterAddressGroup(sld, "PortPax_prison", "goto",  "goto9");
		break;
		//==> Gregg: the Black Orchid - a mysterious artefact
		case "MysteriousArtefact_1":
			dialog.text = "Brian George ? Ce maudit ivrogne qui faisait une scène dans ma taverne tous les jours ?";
			link.l1 = "Mmm... Oui, ça ressemble bien à notre homme.";
			link.l1.go = "MysteriousArtefact_2";
		break;

		case "MysteriousArtefact_2":
			dialog.text = "Il habite à la limite de Port-au-Prince, à quelques pas des portes de la ville.";
			link.l1 = "Merci de votre aide.";
			link.l1.go = "MysteriousArtefact_3";
		break;

		case "MysteriousArtefact_3":
			dialog.text = "Hé, attendez. Que voulez-vous à ce maudit poivrot ?";
			link.l1 = "Il me doit quelques centaines de pièces d'or. Je compte les récupérer.";
			link.l1.go = "MysteriousArtefact_4";
			link.l2 = "J'ai affaire à lui.";
			link.l2.go = "MysteriousArtefact_8";
		break;

		case "MysteriousArtefact_4":
			dialog.text = "Une course inutile, capitaine. Il n'arrive pas à me rembourser dix piastres depuis des jours, et vous comptez lui soutirer quelques centaines. Vous n'en tirerez rien.";
			link.l1 = "J'ai des méthodes éprouvées pour recouvrer les dettes, même quand un homme n'a pas d'argent.";
			link.l1.go = "MysteriousArtefact_5";
		break;

		case "MysteriousArtefact_5":
			dialog.text = "Vous comptez le tuer, capitaine ?";

			if (sti(PChar.money) >= 200)
			{
				link.l1 = "Et si c'était le cas ?";
				link.l1.go = "MysteriousArtefact_6";
			}

			link.l2 = "Non, je ne compte pas le tuer, je pensais à d'autres méthodes. Plus efficaces. Et maintenant, je suis pressé. Adieu.";
			link.l2.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToHouseGeorgeBryan");
		break;

		case "MysteriousArtefact_6":
			dialog.text = "Bien sמr que je m'y oppose, capitaine ! Tuer un homme, même un homme comme Brian George... Il est de mon devoir d'appeler la garde.";
			link.l1 = "וcoutez, je pense que vous vous sentirez mieux quand Brian George aura quitté ce monde. Et encore mieux quand vous aurez reçu de moi deux cents pièces d'or. La vie est toujours plus gaie avec de l'argent, n'est-ce pas ?";
			link.l1.go = "MysteriousArtefact_7";
		break;

		case "MysteriousArtefact_7":
			AddMoneyToCharacter(PChar, -200);
			dialog.text = "Donnez-les ! Vite !";
			link.l1 = "Tenez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToHouseGeorgeBryan");
		break;

		case "MysteriousArtefact_8":
			dialog.text = "Une affaire ? Eh bien, vous me faites rire. Quelle affaire pourriez-vous avoir avec cet ivrogne ? Il n'arrive pas à rentrer chez lui sans aide, et vous lui proposez une affaire. Il n'arrive même pas à mendier dix piastres dans la rue pour me rembourser sa dette.";
			link.l1 = "L'affaire est très importante et je suis pressé. Adieu.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToHouseGeorgeBryan");
		break;

		case "MysteriousArtefact_9":
			dialog.text = "Pourquoi voulez-vous les connaître, capitaine ?";
			link.l1 = "Brian a perdu une clé dans cette bagarre, et j'en ai besoin. Votre récit éclaircira peut-être quelque chose.";
			link.l1.go = "MysteriousArtefact_10";
		break;

		case "MysteriousArtefact_10":
			dialog.text = "Une bagarre ordinaire, qu'y a-t-il à raconter ? Tout le monde s'y est mis ; moi-même, je me suis rappelé ma jeunesse et j'en ai collé deux à je ne sais quel voyou. Puis tout le monde s'est calmé et chacun est reparti de son cכté, comme d'habitude.";
			link.l1 = "Vous n'avez pas trouvé de clé après la bagarre ?";
			link.l1.go = "MysteriousArtefact_11";
		break;

		case "MysteriousArtefact_11":
			dialog.text = "Non, je n'en ai trouvé aucune.";
			link.l1 = "Et la serveuse ?";
			link.l1.go = "MysteriousArtefact_12";
		break;

		case "MysteriousArtefact_12":
			PChar.MysteriousArtefact.BarmenTalk = true;
			dialog.text = "Quoi, la serveuse ? Elle est restée dans son coin pendant toute la bagarre ; je l'ai renvoyée chez elle ensuite, elle était morte de peur.";
			link.l1 = "Je vois. Merci.";
			link.l1.go = "exit";
		break;
		//<== Gregg: the Black Orchid

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

