
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je ne veux pas parler.";
			link.l1 = "Hum, je vois...";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//встреча в бухте с перцем, который валит из Тено
		case "Shore53":
			pchar.defaultanimation = MainChAnim;
			dialog.text = GetSexPhrase("Señor", "Señorita") +", partez d'ici ! Prenez le large immédiatement !";
			link.l1 = "Qu'y a-t-il ?";
			link.l1.go = "Shore53_1";
		break;
		case "Shore53_1":
			dialog.text = "Ils sont tous morts, dévorés par les flammes de l'enfer !!!";
			link.l1 = "Qui est mort ?";
			link.l1.go = "Shore53_2";
		break;
		case "Shore53_2":
			dialog.text = "Ah, pourquoi sommes-nous allés là-bas ?";
			link.l1 = "L'ami, calme-toi ! Raconte-moi doucement et dans l'ordre ce qui s'est passé.";
			link.l1.go = "Shore53_3";
		break;
		case "Shore53_3":
			dialog.text = "D'accord, "+ GetSexPhrase("señor", "señorita") +". Je m'appelle Silvio Ricci. Tout a commencé quand don Esteban m'a engagé, avec d'autres, pour chercher un nouvel Eldorado. Nous avons débarqué dans cette baie et nous sommes allés à la cité indienne que Cortés lui-même a pillée il y a plus de cent ans. Mon Dieu, pourquoi ?!!";
			link.l1 = "Bon, ça recommence... Arrête immédiatement !!!";
			link.l1.go = "Shore53_4";
		break;
		case "Shore53_4":
			dialog.text = "D'accord, "+ GetSexPhrase("señor", "señorita") +"Il y a une semaine, près de 50 personnes sont entrées dans cette jungle. Et maintenant, il ne reste que moi.";
			link.l1 = "Oם sont les autres ?";
			link.l1.go = "Shore53_5";
		break;
		case "Shore53_5":
			dialog.text = "Ils sont morts, "+ GetSexPhrase("señor", "señorita") +" ! Ils ont été dévorés par les flammes de l'enfer !";
			link.l1 = "Quoi ?!";
			link.l1.go = "Shore53_6";
		break;
		case "Shore53_6":
			dialog.text = "Je dis la pure vérité, "+ GetSexPhrase("señor", "señorita") +". C'est le diable lui-même qui allume ce feu, là-bas !";
			link.l1 = "Tu as vu le diable, là-bas ?";
			link.l1.go = "Shore53_7";
		break;
		case "Shore53_7":
			dialog.text = "C'était peut-être le diable ! Il y a un Indien peinturluré qui se tient sur la rive, près de la ville. Il en restait une dizaine parmi nous, ceux qui avaient survécu au feu de l'enfer. Nous allions repartir quand Pedro a décidé de prendre les babioles en or de ce sauvage. א peine avait-il tendu les mains vers lui qu'il a reçu un coup de massue sur la tête. Et sa tête a éclaté comme une pastèque mמre ! Ensuite, ce démon s'est mis à nous courir après en frappant tout le monde avec sa massue. Un coup, et la tête vole en éclats. Je suis le seul à m'être enfui...";
			link.l1 = "Oם est ton chef, don Esteban ?";
			link.l1.go = "Shore53_8";
		break;
		case "Shore53_8":
			dialog.text = "Brמlé dans le feu de l'enfer.";
			link.l1 = "Eh oui, une fin sans gloire...";
			link.l1.go = "Shore53_9";
		break;
		case "Shore53_9":
			dialog.text = GetSexPhrase("Señor", "Señorita") +", n'allez pas là-bas. Cet endroit est maudit !";
			link.l1 = "Je vais quand même tenter ma chance.";
			link.l1.go = "Shore53_10";
		break;
		case "Shore53_10":
			dialog.text = "Bon, c'est vous qui voyez, mais moi, j'en ai assez. Adieu, "+ GetSexPhrase("señor", "señorita") +" !";
			link.l1 = "Au revoir...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("Teno_startInShore_2");
		break;
	}
}
