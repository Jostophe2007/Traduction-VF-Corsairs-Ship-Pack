
void ProcessDialogEvent()
{
	int amount, iGunQty, iGunGoods, iGunPrice, iTemp;
	int iTest;
	ref NPChar, sld;
	ref arItem;
	ref rColony;
	aref Link, NextDiag;
	string sTemp;
	float locx, locy, locz;
	bool  ok;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Prison\" + NPChar.City + "_Prison.c";
    if (!HasCityDialogFile("Prison", NPChar.City, "_Prison.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Prison\DefaultCity_Prison.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Prison\DefaultCity_Prison.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "NoMoreTalkExit":
			LAi_CharacterDisableDialog(npchar);
			DialogExit();
		break;
		//---------------- Начальник тюрьмы ------------------
		case "First_officer":
		if (rand(2) == 0 && GetNpcQuestPastDayWOInit(npchar, "questPrisonGun") > 365 && !CheckAttribute(pchar, "questTemp.PrisonGun"))
				{
					dialog.text = RandPhraseSimple(RandPhraseSimple("וcoutez, j'ai une affaire importante pour vous. J'espère que vous pourrez m'aider...", "Capitaine, une offre très lucrative vous intéresserait-elle ?"), RandPhraseSimple("Je me disais que vous pourriez nous aider dans une affaire très importante.", "Capitaine, j'ai une offre délicate qui pourrait nous être profitable à tous les deux."));
					link.l1 = "Expliquez-vous, essayons de régler ça...";
					link.l1.go = "GiveTaskGun";
					npchar.quest.PrisonGun = "Target";
					SaveCurrentNpcQuestDateParam(npchar, "questPrisonGun");
					break;
				}

			dialog.text = RandPhraseSimple("Je suis le commandant. Que voulez-vous ici ?", "Que voulez-vous ? Pourquoi êtes-vous venu à la prison ?");
			link.l1 = "Rien de spécial, je visite la ville, vous savez.";
			link.l1.go = "exit";
			link.l2 = "Je veux parler affaires.";
			if (CheckCharacterItem(pchar, "CaptainBook") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakFort"))
			{
				if((pchar.questTemp.different.GiveShipLetters.city == npchar.city) && CheckAttribute(pchar, "questTemp.different.GiveShipLetters"))
				{
					link.l2.go = "F_ShipLetters_1";
				}
				else
				{
					link.l2.go = "quests";
				}
			}
			else
			{
				if(CheckAttribute(pchar, "questTemp.ReasonToFast") && !CheckAttribute(pchar, "questTemp.ReasonToFast.SpeakOther") && !CheckAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther") && (pchar.questTemp.ReasonToFast.city == NPChar.city))
				{
					link.l2.go = "ReasonToFast_Prison1";
				}
				else
				{
					link.l2.go = "quests";
				}
			}

			if (!sti(pchar.questTemp.jailCanMove))
			{
				link.l4 = "Je veux entrer dans la prison.";
				link.l4.go = "ForGoodMove";
			}
			if (CheckAttribute(pchar, "questTemp.jailCanMove.City") && npchar.city == pchar.questTemp.jailCanMove.City)
			{
				link.l5 = "וcoutez, pouvez-vous me dire pour quel crime un prisonnier nommé " + GetFullName(characterFromId(pchar.questTemp.jailCanMove.prisonerId)) + " est enfermé ici ?";
				link.l5.go = "KnowAboutPrisoner";
			}

			if(CheckAttribute(pchar, "GenQuest.CaptainComission") && (pchar.GenQuest.CaptainComission.variant == "A2") && (pchar.GenQuest.CaptainComission.City == NPChar.city))
			{
				if(!CheckAttribute(pchar, "GenQuest.CaptainComission.PrisonFree"))
				{
					bool zMsm = (CheckAttribute(pchar, "GenQuest.CaptainComission.GetRumour")) && (!CheckAttribute(pchar, "GenQuest.CaptainComission.SpeakMayor"));
					if(pchar.GenQuest.CaptainComission == "MayorTalkBad" || zMsm) //говорил с губером и отказался или узнал слухи, но не говорил с губером
					{
						link.l6 = "J'ai entendu dire que l'ancien capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " était détenu chez vous. Puis-je lui parler ?";
						link.l6.go = "CapComission_PrisonBad1";
					}
					if(pchar.GenQuest.CaptainComission == "MayorTalkGood")
					{
						link.l6 = "Je suis " + GetFullName(pchar) + ", j'agis au nom et pour le compte du gouverneur " + XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen") + ". Je dois parler à l'ancien capitaine " + pchar.GenQuest.CaptainComission.Name + ".";
						link.l6.go = "CapComission_PrisonGood1";
					}
				}
			}

			if (CheckAttribute(pchar, "questTemp.PrisonGun") && pchar.questTemp.PrisonGun.Id == npchar.location)
			{
				link.l8 = "Je viens pour votre commande de canons.";
				link.l8.go = "CheckGun";
			}

			if(CheckAttribute(pchar, "GenQuest.EncGirl"))
			{
				if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
				{
					if(pchar.GenQuest.EncGirl.Father == "fort_keeper"  && npchar.city == pchar.GenQuest.EncGirl.city)
					{
						link.l9 = "C'est au sujet de votre fille...";
						link.l9.go = "EncGirl_1";
					}
				}
			}

			if(CheckAttribute(pchar, "UnexpectedInheritanceFort") && npchar.id == "FortFranceJailOff")
			{
				link.lUnexpectedInheritance = "Monsieur, j'ai une question à vous poser, elle peut paraître étrange, mais quand même...";
				link.lUnexpectedInheritance.go = "UnexpectedInheritance";
			}

			if(CheckAttribute(pchar, "LambriniPGGInPrison") && CheckAttribute(pchar, "LambriniPGGPlata") && npchar.id == "MaracaiboJailOff")
			{

				link.lLambriniPGGInPrison = "Señor, j'ai pris part à une récente descente contre les contrebandiers. On m'a dit que les personnes arrêtées étaient détenues ici. Puis-je vous demander de libérer une certaine personne ? Sous ma responsabilité, bien sמr.";
				link.lLambriniPGGInPrison.go = "LambriniPGGInPrison";
			}
			// комендантский (боеприпасный) фрахт: сдача боеприпасов гарнизону форта (incl. overdue)
			if (CheckAttribute(pchar, "CargoQuest.iOrderType") && sti(pchar.CargoQuest.iOrderType) == 7 && CheckAttribute(pchar, "CargoQuest.TraderID") && characters[GetCharacterIndex(pchar.CargoQuest.TraderID)].city == npchar.city)
			{
				if (CheckQuestAttribute("generate_trade_quest_progress", "begin") || CheckQuestAttribute("generate_trade_quest_progress", "failed"))
				{
					link.l10 = "Commandant, votre arsenal attend d'être réapprovisionné. Je vous amène un convoi de poudre et de munitions pour la garnison, sur commande de la guilde marchande.";
					link.l10.go = "FortFreight_Deliver";
				}
			}
			// redirected convoy: delivering the cargo to the commandant of the ENEMY nation (deal with the courier-agent, "I'll deliver it myself")
			// LEO: fix infinite re-trigger - once handed over (.delivered) hide the option; .active lingers +1 day for the guards' "already delivered" grace
			if (CheckAttribute(pchar, "FortAgentDeliver.active") && !CheckAttribute(pchar, "FortAgentDeliver.delivered"))
			{
				// LEO: нация коменданта - у КОЛОНИИ, а не у самого NPC: тюремщик перегенерируется по таймеру
				//   Jail_date и до этого носит флаг прежнего владельца города - строка сдачи не появлялась вовсе.
				bool bFADeliverHere = false;
				if (GetCityNation(npchar.city) == sti(pchar.FortAgentDeliver.nation))
				{
					if (npchar.city == pchar.FortAgentDeliver.city) bFADeliverHere = true;
					else
					{
						// LEO: в лейтгейме города переходят из рук в руки. Оговорённый порт уже не за нацией агента -
						//   груз некуда деть, заказ висел бы до провала. Принимаем в ЛЮБОМ её городе.
						if (GetCityNation(pchar.FortAgentDeliver.city) != sti(pchar.FortAgentDeliver.nation)) bFADeliverHere = true;
					}
				}
				if (bFADeliverHere)
				{
					link.l11 = "Commandant, j'ai une cargaison spéciale pour vous : de la poudre et des munitions. C'est votre homme, celui qui a intercepté le convoi en mer, qui m'envoie.";
					link.l11.go = "FortAgentDeliver_Hand";
				}
			}
			// LEO: merge - квест "Трусливый Томас": реплика офицеру; link переименован l11 -> lTohmasOfficerReport (была коллизия с FortAgentDeliver_Hand выше)
			if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_Search.ToOfficer") && npchar.location == "BasTer_prison") 
			{
				link.lTohmasOfficerReport = "Officier, une bande audacieuse sévit en plein jour non loin de la ville ! On m'a lâchement attiré dans un piège et forcé à remettre 40 000 piastres sous peine de mort !";
				link.lTohmasOfficerReport.go = "TohmasPetit_OfficerRefusal";
			}
			NextDiag.TempNode = "First_officer";
		break;

		case "FortFreight_Deliver":
			// конвой принимают с рейда ЭТОГО порта (не пешком и не с чужого причала)
			if (!CargoShipMooredInCity(npchar.city))
			{
				dialog.text = "Des munitions, capitaine ? Mais aucun de vos navires n'est dans notre port. Amenez le convoi en rade : la garnison déchargera la cargaison de main en main.";
				link.l1 = "Je vais amener le convoi au port.";
				link.l1.go = "exit";
				break;
			}
			// КОНВОЙ: считаем ВЕС боеприпасов на живых судах; комендант принимает то, что дошло
			int ffRequired = makeint(pchar.CargoQuest.iQuantityGoods); // требуемый вес (50% погруженного на конвой)
			int ffHave = FortConvoy_AmmoWeightAboard();
			int ffShips = FortConvoy_ShipsAlive();
			if (ffHave <= 0)
			{
				dialog.text = "Oם est le convoi, capitaine ? Pas un seul navire de l'וtat chargé de munitions dans la rade. Sans la cargaison, nous n'avons rien à discuter.";
				link.l1 = "Je reviendrai avec le convoi.";
				link.l1.go = "exit";
				break;
			}
			int ffPct = makeint(ffHave * 100 / ffRequired);
			if (ffPct > 100) ffPct = 100;
			bool ffFull = (ffPct >= 100);
			int ffReward = makeint(sti(pchar.CargoQuest.iMoney) * ffPct / 100); // плата пропорциональна доставленному
			if (CheckQuestAttribute("generate_trade_quest_progress", "failed"))
			{
				ffReward = makeint(ffReward / 2);
				dialog.text = "Vous êtes en retard, capitaine. La garnison s'est procuré sa poudre ailleurs : le trésor paiera la moitié, et seulement pour ce qui est réellement arrivé à l'arsenal.";
			}
			else
			{
				if (ffFull)
				{
					if (GetQuestPastDayParam("CargoQuest") * 2 < sti(pchar.CargoQuest.iDaysExpired)) ffReward = makeint(ffReward * 1.2);
					if (ffShips >= 4) dialog.text = "Excellent, capitaine ! Le convoi est arrivé intact, l'arsenal est plein. La garnison n'oublie pas un tel service : voici votre récompense, jusqu'à la dernière piastre.";
					else dialog.text = "Je vois que la traversée a été chaude... Le commandant examine la rade et fronce les sourcils, mais acquiesce. Quoi qu'il en soit, vous avez apporté tout ce qui était dמ. Marché conclu, marché tenu : le trésor paie en totalité.";
				}
				else
				{
					// груза дошло меньше уговора: комендант рассержен на нападавших и немного на ГГ, но принимает остаток
					dialog.text = "Diable... Oם sont les autres navires, capitaine ?! Le commandant s'assombrit en entendant le récit de l'attaque. Maudits vautours, si seulement mes canonniers les avaient attrapés... Ce n'est pas trop votre faute : vous avez ramené ce que vous pouviez, même si j'attendais davantage du convoi. Le trésor paiera ce qui est arrivé à l'arsenal.";
				}
			}
			link.l1 = "Heureux d'avoir pu servir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, ffReward);
			if (ffFull)
			{
				ChangeCharacterNationReputation(pchar, sti(npchar.nation), 5); // +отношение с нацией коменданта
				ChangeCharacterReputation(pchar, 1);
			}
			else
			{
				ChangeCharacterNationReputation(pchar, sti(npchar.nation), 2); // рассержен на нападавших и немного на ГГ - но услуга есть услуга
			}
			// опыт навыков как у обычного фрахта (Sailing=навигация, Leadership, Commerce); при просрочке - без бонуса за дни
			int ffDaysMul = GetQuestPastDayParam("CargoQuest") + 1;
			if (CheckQuestAttribute("generate_trade_quest_progress", "failed")) ffDaysMul = 1;
			AddCharacterExpToSkill(pchar, "Sailing", ffDaysMul * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_I));
			AddCharacterExpToSkill(pchar, "Leadership", ffDaysMul * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_C));
			AddCharacterExpToSkill(pchar, "Commerce", ffDaysMul * sti(pchar.rank) * (GetCharacterSPECIALSimple(pchar, SPECIAL_C) + GetCharacterSPECIALSimple(pchar, SPECIAL_I)));
			FortConvoy_Disband(); // суда с остатками груза уходят к форту - боеприпасы в арсенал гарнизона
			FortHunt_ClearWatch(); // вахты СЖ-записей о каперах больше не нужны
			FortAgent_Cleanup();   // груз сдан - посыльному ловить больше нечего, убираем энкаунтер
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			if (ffFull)
			{
				if (ffShips >= 4) AddQuestRecord("DELIVERY_TRADE_QUEST", "fort2");
				else AddQuestRecord("DELIVERY_TRADE_QUEST", "fort4"); // были потери, но положенное довезено - расчёт без вычетов
			}
			else
			{
				AddQuestRecord("DELIVERY_TRADE_QUEST", "fort3");
				AddQuestUserData("DELIVERY_TRADE_QUEST", "sPct", "" + ffPct);
			}
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			AchievementsCounter_genquests(1);
			// слухи в городе форта
			if (ffFull)
			{
				if (ffShips >= 4) AddSimpleRumourCity("Vous avez vu ? Un convoi de poudre est arrivé au fort : quatre navires, tous intacts. L'arsenal de la garnison est plein, et le commandant a fait rouler un tonneau de rhum pour ses canonniers.", npchar.city, 3, 5, "");
				else AddSimpleRumourCity("Vous avez entendu ? Un convoi de poudre a atteint le fort : malmené, avec des navires en moins, mais le capitaine a apporté tout ce qui était dמ à la garnison. Un dur à cuire, sans aucun doute.", npchar.city, 3, 5, "");
			}
			else AddSimpleRumourCity("Vous avez entendu parler du convoi de poudre ? Il a été sérieusement malmené en mer : une partie seulement est arrivée au fort. Le commandant a pris ce qui est arrivé, et on dit que toute l'escadre traque maintenant les assaillants.", npchar.city, 3, 5, "");
		break;

		case "FortAgentDeliver_Hand":
			// the convoy is accepted from THIS port's roadstead
			if (!CargoShipMooredInCity(npchar.city))
			{
				dialog.text = "Une cargaison, capitaine ? Mais il n'y a aucun de vos navires dans notre port. Amenez le convoi en rade.";
				link.l1 = "J'amène le convoi.";
				link.l1.go = "exit";
				break;
			}
			int faRequired = makeint(pchar.CargoQuest.iQuantityGoods);
			int faHave  = FortConvoy_AmmoWeightAboard();
			int faShips = FortConvoy_ShipsAlive();
			if (faHave <= 0)
			{
				// the whole convoy was lost en route - nothing to deliver, nothing to pay
				dialog.text = RandPhraseSimple(
					"Dommage que vous ayez perdu toute cette cargaison si importante pour nous, capitaine. Mais il n'y a rien à vous payer.",
					"Les mains vides, capitaine ? Toute la cargaison a péri en mer... Je compatis, mais le trésor ne paie pas pour ce qui a disparu.");
				link.l1 = "Pas de chance.";
				link.l1.go = "exit";
				FortConvoy_Disband();
				pchar.quest.FortAgentDeliver_Fail.over = "yes";
				AddQuestRecord("DELIVERY_TRADE_QUEST", "fortagent6");
				AddQuestUserData("DELIVERY_TRADE_QUEST", "sSex", GetSexPhrase("", "e"));
				pchar.quest.generate_trade_quest_progress = "";
				pchar.quest.generate_trade_quest.over = "yes";
				CloseQuestHeader("DELIVERY_TRADE_QUEST");
				FortHunt_ClearWatch();
				pchar.FortAgentDeliver.delivered = true; // дело с комендантом улажено - стража теперь узнаёт "уже доставил" (не "везёт груз")
				SetTimerCondition("FortAgentDeliver_Cleanup", 0, 0, 1, false); // +1 day grace to safely leave the hostile city
				break;
			}
			int faPct = makeint(faHave * 100 / faRequired);
			if (faPct > 100) faPct = 100;
			int faReward = makeint(sti(pchar.CargoQuest.iMoney) * 5 * faPct / 100); // fivefold the guild price, proportional to delivered
			if (faPct >= 100)
			{
				dialog.text = "Splendide, capitaine ! La cargaison est arrivée au complet : la garnison sera ravie. Voici votre or, comme convenu, le quintuple de ce que la guilde avait promis.";
			}
			else
			{
				dialog.text = "Vous avez perdu une partie du convoi en route, capitaine... Le commandant fronce les sourcils. Bon, je paierai ce que vous avez livré. Marché conclu, marché tenu.";
			}
			link.l1 = "Heureux d'avoir pu servir.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, faReward);
			ChangeCharacterNationReputation(pchar, sti(npchar.nation), 5);
			AddCharacterExpToSkill(pchar, "Leadership", 300);
			AddCharacterExpToSkill(pchar, "Sneak", 300);
			FortConvoy_Disband();
			pchar.quest.FortAgentDeliver_Fail.over = "yes";
			AddQuestRecord("DELIVERY_TRADE_QUEST", "fortagent4");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sPct", "" + faPct + "%");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sSex", GetSexPhrase("", "e"));
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			FortHunt_ClearWatch();
			AchievementsCounter_genquests(1);
			pchar.FortAgentDeliver.delivered = true; // груз сдан коменданту - стража теперь узнаёт "уже доставил"
			// keep the pass grace +1 more day so the player can safely leave the hostile city (then FortAgentDeliver_Cleanup clears it)
			SetTimerCondition("FortAgentDeliver_Cleanup", 0, 0, 1, false);
		break;

		case "LambriniPGGInPrison":
			dialog.Text = "De qui parlons-nous ?";
			Link.l1 = "Je crois qu'elle s'appelle " + GetFullName(CharacterFromID(pchar.LambriniPGG))+".";
			Link.l1.go = "LambriniPGGInPrison_1";
		break;
		case "LambriniPGGInPrison_1":
			dialog.Text = ""+GetFullName(CharacterFromID(pchar.LambriniPGG))+" ? Un instant, je vais consulter la liste des prisonniers.";
			Link.l1 = "Oui, bien sמr, j'attends.";
			Link.l1.go = "LambriniPGGInPrison_2";
		break;
		case "LambriniPGGInPrison_2":
			dialog.Text = "Hum... "+GetFullName(CharacterFromID(pchar.LambriniPGG))+"... " + GetFullName(CharacterFromID(pchar.LambriniPGG))+"... Oui, je l'ai trouvée. La propriétaire d'un lot de santal de contrebande. Son amende s'élève à 25 000 pièces d'or.";
			if (sti(pchar.money) >= 25000)
			{
				Link.l1 = "Voici votre argent.";
				Link.l1.go = "LambriniPGGInPrison_3";
			}
			Link.l2 = "Eh bien, vous avez des prix... Je dois y réfléchir.";
			Link.l2.go = "LambriniPGGInPrison_3_1";
		break;
		case "LambriniPGGInPrison_3":
			AddMoneyToCharacter(pchar, -25000);
			DeleteAttribute(pchar, "LambriniPGGPlata")
			dialog.Text = "Très bien. On va vous l'amener.";
			Link.l1 = "";
			Link.l1.go = "LambriniPGGInPrison_4";
		break;
		case "LambriniPGGInPrison_3_1":
			dialog.Text = "Si vous vous décidez, venez. Je vous conseille seulement de réfléchir vite, on ne sait jamais ce qui peut arriver ici en quelques jours. C'est votre amie, pas la mienne.";
			Link.l1 = "";
			Link.l1.go = "exit";
		break;
		case "LambriniPGGInPrison_4":
			DialogExit();
			chrDisableReloadToLocation = true;
			sld = CharacterFromID(pchar.LambriniPGG);
			ChangeCharacterAddressGroup(sld, "Maracaibo_prison", "goto", "goto20");
			LAi_SetStayTypeNoGroup(sld);
			sld.talker = 10;
			sld.dialog.currentnode   = "LambriniPGG_2_1";
		break;

		case "UnexpectedInheritance":
			dialog.Text = "Je vous écoute.";
			Link.l1 = "Le fait est que j'ai entendu parler de découvertes d'idoles indiennes inhabituelles sur le terrain du fort. Mon employeur est un collectionneur, et il ne regarde pas à la dépense pour les babioles païennes, si vous voyez ce que je veux dire.";
			Link.l1.go = "UnexpectedInheritance_1";
		break;
		case "UnexpectedInheritance_1":
			dialog.Text = "Je vous comprends parfaitement, capitaine. En métropole, l'exotisme est à la mode, et les marchands paient aujourd'hui une misère pour les trouvailles, en comptant bien s'enrichir. Effectivement, les soldats qui faisaient des travaux de terrassement ont découvert quelque chose d'intéressant.";
			Link.l1 = "Mon employeur ne manque pas d'argent. 12 000, ça vous convient ?";
			Link.l1.go = "UnexpectedInheritance_2";
		break;
		case "UnexpectedInheritance_2":
			dialog.Text = "Votre employeur est un usurier ? 25 000, et pas un peso de moins.";
			Link.l1 = "Mon employeur est un Français, et un gentilhomme. 16 000. Marché conclu ?";
			Link.l1.go = "UnexpectedInheritance_3";
		break;
		case "UnexpectedInheritance_3":
			dialog.Text = "Un Français ? Un gentilhomme ? Eh bien, je le céderai à un compatriote pour 18 000 misérables pesos.";
			if (sti(pchar.money) >= 18000)
			{
				Link.l1 = "Je vous en prie, monsieur, voici votre argent. Au revoir !";
				Link.l1.go = "UnexpectedInheritance_4";
			}
			else
			{
				Link.l1 = "Hum... Je n'ai pas autant sur moi. Je repasserai plus tard.";
				Link.l1.go = "exit";
			}
		break;
		case "UnexpectedInheritance_4":
			dialog.Text = "Merci. Il y avait aussi des papiers dans le coffre, prenez-les.";
			Log_Info("Vous avez reçu un parchemin avec un texte latin et une moitié de carte");
			Log_Info("Vous avez reçu un vase de cérémonie");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("UnexpectedInheritance", "10");
			TakeNItems(pchar, "indian21", 1);
			DeleteAttribute(pchar, "UnexpectedInheritanceFort");
			pchar.quest.UnexpectedInheritanceTerks.win_condition.l1 = "location";
			pchar.quest.UnexpectedInheritanceTerks.win_condition.l1.location = "Terks_Grot";
			pchar.quest.UnexpectedInheritanceTerks.function = "UnexpectedInheritanceTerks";
			Link.l1 = "Curieux...";
			Link.l1.go = "exit";
		break;

		case "GiveTaskGun":
			dialog.Text = LinkRandPhrase("Le fait est que les canons de notre fort sont plutכt usés. Le trésor a bien débloqué de l'argent pour les remplacer, mais en acheter des neufs coמte très cher en ce moment. Alors je me suis dit que les canons des prises que vous avez abordées pourraient être très utiles ici.", "Je dois remplacer la batterie de canons du fort. L'argent a été débloqué pour ça, mais, vous savez... je voudrais quelque chose de moins cher... Bref, j'espère que vous me comprenez.", "J'ai reçu l'ordre de remplacer les canons usés du fort, mais il y a un problème : je n'arrive à en réunir assez nulle part.");
			Link.l1 = "Hum, mais vous pourriez donner plus de détails : le calibre, la quantité... le prix, enfin.";
			Link.l1.go = "GiveTaskGun_1";
			pchar.questTemp.PrisonGun = true;
			SaveCurrentQuestDateParam("pchar.questTemp.PrisonGun");
		break;

		case "GiveTaskGun_1":
			GetGunType();
			pchar.questTemp.PrisonGun.Sum = makeint(sti(pchar.questTemp.PrisonGun.Price)*sti(pchar.questTemp.PrisonGun.Qty));
			pchar.questTemp.PrisonGun.Luck = rand(4);
			pchar.questTemp.PrisonGun.Id = npchar.location;
			dialog.Text = "Il me faut des "+ pchar.questTemp.PrisonGun.Text +", au nombre de " + sti(pchar.questTemp.PrisonGun.Qty) + " exactement. Je suis prêt à payer " + FindRussianMoneyString(sti(pchar.questTemp.PrisonGun.Sum)) + ", ce qui fera "+ sti(pchar.questTemp.PrisonGun.Price) +" piastres par pièce. Qu'en dites-vous ? Ah oui, encore une chose : je prendrai tout le lot d'un coup, mais pas avant un mois... L'argent est encore en route.";
			Link.l1 = RandPhraseSimple("Non, officier, votre offre ne m'intéresse pas... Désolé.", "C'est tentant, bien sמr, mais je refuse. Permettez-moi de ne pas expliquer ma décision...");
			Link.l1.go = "exit_gun";
			Link.l2 = RandPhraseSimple("Je ne vous le cache pas, l'offre est intéressante. Considérez que c'est entendu.", "Je crois que j'accepte. Ce n'est pas difficile pour moi, et les avantages sont évidents.");
			Link.l2.go = "GiveTaskGun_2";
		break;

		case "exit_gun":
			dialog.Text = "Dommage... Désolé, capitaine, je comptais sur vous... J'espère que cette conversation ne sortira pas du fort ?";
			Link.l1 = "Ce rappel était inutile. Bonne journée.";
			Link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PrisonGun");
			NextDiag.TempNode = "First_officer";
		break;

		case "GiveTaskGun_2":
			dialog.Text = "Voilà. Je ne vous impose pas de délai, mais tâchez quand même de ne pas dépasser six mois. Et j'espère que vous comprenez qu'il s'agit d'une affaire confidentielle ?";
			Link.l1 = "Je comprends. א plus tard.";
			Link.l1.go = "exit";
			ReOpenQuestHeader("PrisonGun");
			AddQuestRecord("PrisonGun", "1");
			AddQuestUserData("PrisonGun", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PrisonGun", "sName", GetFullName(npchar));
			AddQuestUserData("PrisonGun", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("PrisonGun", "sQty", makeint(pchar.questTemp.PrisonGun.Qty));
			AddQuestUserData("PrisonGun", "sSum", makeint(pchar.questTemp.PrisonGun.Sum));
			AddQuestUserData("PrisonGun", "sText", pchar.questTemp.PrisonGun.Text);
			NextDiag.TempNode = "First_officer";
		break;

		case "CheckGun":
			if (GetQuestPastDayParam("pchar.questTemp.PrisonGun") < 30)
			{
				dialog.Text = "Je vous avais dit de ne pas revenir avant au moins un mois !";
				Link.l1 = "Bon sang ! J'ai mal compté les jours... Désolé, je reviendrai plus tard, comme convenu.";
				Link.l1.go = "exit";
				NextDiag.TempNode = "First_officer";
				break;
			}
			if (GetQuestPastDayParam("pchar.questTemp.PrisonGun") > 180)
			{
				dialog.Text = "Hum... Vous savez, plus de six mois ont passé depuis la signature de notre « accord ». J'ai déjà acheté les canons. Ou vous pensiez que j'allais vous attendre éternellement ?";
				Link.l1 = "Bon sang ! Et qu'est-ce que je vais en faire, maintenant ?";
				Link.l1.go = "TakeGun_late";
				break;
			}
			iGunGoods = pchar.questTemp.PrisonGun.Goods;
			amount = GetSquadronGoods(Pchar, iGunGoods) - sti(pchar.questTemp.PrisonGun.Qty);
			sTemp = sti(pchar.questTemp.PrisonGun.Qty);
			iTest = FindColony(NPChar.City); // город

			if (iTest != -1)
			{
				rColony = GetColonyByIndex(iTest);
			}
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
			if (rColony.id == "Panama") ok = true;
			if(sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				dialog.Text = "Alors, vous êtes prêt à me faire plaisir ?";
				if (amount < 0)
				{
					Link.l1 = "Non, je cherche encore. Je voulais juste m'assurer que notre accord tenait toujours.";
					Link.l1.go = "exit";
				}
				else
				{
					Link.l1 = "Bien sמr. Tout le lot est dans la cale : "+ sTemp +" pièces, comme convenu.";
					Link.l1.go = "TakeGun";
				}
			}
			else
			{
				dialog.text = "Je ne vois pas votre navire au port. Ou vous comptez traîner les canons à travers la jungle ? Amarrez-vous dans notre port et revenez.";
				link.l1 = "Mon navire est de l'autre cכté de l'île. Je l'amène au port tout de suite.";
				link.l1.go = "exit";
			}
		break;

		case "TakeGun":
			if (pchar.questTemp.PrisonGun.Luck == 4)
			{
			dialog.Text = RandPhraseSimple("Je suis vraiment gêné, mais je dois annuler notre accord. Un contrכle financier est arrivé, et vous savez à quel point ils sont pointilleux sur ces questions. Hélas, il n'y a aucun moyen, désolé.", "Capitaine, voilà ce qui se passe... en somme, la métropole nous a envoyé des canons, et j'ai bien sמr été obligé de les racheter. Les prix sont exorbitants, évidemment, mais... Désolé de vous laisser tomber, je suis moi-même très déçu.");
			Link.l1 = "Bon sang ! Et qu'est-ce que je dois faire maintenant ?";
            Link.l1.go = "TakeGun_no";
			}
			else
			{
			dialog.Text = RandPhraseSimple("Parfait. J'envoie tout de suite une corvée de la garnison pour le déchargement.", "Parfait. Les soldats aideront vos hommes à décharger.");
			Link.l1 = "Vous avez préparé le paiement ?";
            Link.l1.go = "TakeGun_1";
			}
		break;

		case "TakeGun_no":
			dialog.Text = "Je ne sais pas. Vendez-les au chantier naval, équipez-en un navire marchand, coulez-les... Je ne sais vraiment pas. Et je vous en supplie, ne répandez pas cette affaire.";
			Link.l1 = "Qu'est-ce que c'est que ça ?! Je n'ai pas de mots !";
            Link.l1.go = "exit";
			AddQuestRecord("PrisonGun", "3");
			CloseQuestHeader("PrisonGun");
			DeleteAttribute(pchar, "questTemp.PrisonGun");
			SaveCurrentNpcQuestDateParam(npchar, "questPrisonGun");
			NextDiag.TempNode = "First_officer";
		break;

		case "TakeGun_late":
			dialog.Text = "Je ne sais pas. Ce sont vos difficultés. Vendez-les, jetez-les, coulez-les, ça m'est égal.";
			Link.l1 = "Oh, j'ai perdu mon temps...";
            Link.l1.go = "exit";
			AddQuestRecord("PrisonGun", "4");
			AddQuestUserData("PrisonGun", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PrisonGun", "sName", GetFullName(npchar));
			CloseQuestHeader("PrisonGun");
			DeleteAttribute(pchar, "questTemp.PrisonGun");
			SaveCurrentNpcQuestDateParam(npchar, "questPrisonGun");
			NextDiag.TempNode = "First_officer";
		break;

		case "TakeGun_1":
			iGunGoods = pchar.questTemp.PrisonGun.Goods;
			amount = sti(pchar.questTemp.PrisonGun.Qty);
			iTemp = makeint((sti(pchar.questTemp.PrisonGun.Sum) + 7500)/15000);
			dialog.Text = RandPhraseSimple("On m'a apporté l'argent des canons en coffres de crédit. Veuillez recevoir les "+ iTemp +" coffres qui vous reviennent.", "Et comment ! Mais on m'a apporté l'argent en coffres de crédit. Selon notre accord, vous avez droit à "+ iTemp +" coffres. Tenez, veuillez les recevoir.");
			Link.l1 = "Des coffres, va pour des coffres. Merci. Un plaisir de faire affaire avec vous.";
            Link.l1.go = "TakeGun_2";
			TakeNItems(pchar, "chest", iTemp);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			RemoveCharacterGoods(Pchar, iGunGoods, amount);
		break;

		case "TakeGun_2":
			dialog.Text = "Merci, vous m'avez beaucoup aidé. Et, s'il vous plaît, que cette affaire reste entre nous.";
			Link.l1 = "Eh bien, cela va sans dire. Bonne journée.";
            Link.l1.go = "exit";
			AddQuestRecord("PrisonGun", "2");
			AddQuestUserData("PrisonGun", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PrisonGun");
			DeleteAttribute(pchar, "questTemp.PrisonGun");
			SaveCurrentNpcQuestDateParam(npchar, "questPrisonGun");
			NextDiag.TempNode = "First_officer";
		break;

		case "EncGirl_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Je vous ai ramené votre fugitive.";
			link.l1.go = "EncGirl_2";
		break;

		case "EncGirl_2":
			dialog.text = "Ah, capitaine, merci beaucoup ! Comment va-t-elle ? Elle est en bonne santé, elle n'est pas blessée ? דa fait un jour qu'elle s'est enfuie, la malheureuse. Est-ce que je lui veux du mal ? Je veux la marier... Le fiancé est riche, jeune, et pas laid du tout, il ne faut pas faire la fine bouche. Mais non ! Elle n'en fait qu'à sa tête, tout comme sa mère, que le diable l'emporte... Et elle ne serait même pas née si sa mère ne s'était pas enfuie à l'époque avec un benêt entreprenant... Enfin, à quoi bon se souvenir... La jeunesse est naïve, sotte... et cruelle.";
			link.l1 = "Bien sמr, vous êtes son père et c'est à vous de décider, mais à votre place, je ne précipiterais pas un mariage heureux...";
			link.l1.go = "EncGirl_3";
		break;

		case "EncGirl_3":
			dialog.text = "";
			link.l1 = "Merci. Et tenez-la bien. Quelque chose me dit qu'elle ne s'arrêtera pas là.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirl_ToLoverParentsExit");
		break;

		// ------------------------- Повод для спешки -----------------------------
		case "ReasonToFast_Prison1":
			pchar.questTemp.ReasonToFast.SpeakOther = true;
			dialog.text = "Je vous écoute attentivement, capitaine.";
			link.l1 = "Je veux vous signaler un complot criminel entre un officier de votre garnison et des pirates (vous exposez les circonstances de l'affaire).";
			if(makeint(pchar.reputation) < 40)
			{
				link.l1.go = "ReasonToFast_Prison_BadRep";
			}
			else
			{
				link.l1.go = "ReasonToFast_Prison_GoodRep";
			}
		break;
		case "ReasonToFast_Prison_GoodRep":
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_1")
			{
				// вилка_А
				dialog.text = "Merci, capitaine ! Je vais immédiatement donner l'ordre d'arrêter ce gredin. Toutefois, vous avez beaucoup dépensé, et le trésor municipal est hélas vide...";
				link.l1 = "Votre Grâce ! Je ne l'ai pas fait pour l'argent...";
				link.l1.go = "ReasonToFast_Prison_GoodRep_11";

				if(pchar.questTemp.ReasonToFast.chain == "A0") ReasonToFast_RemoveVictim();
				if(pchar.questTemp.ReasonToFast.chain == "A1") pchar.quest.ReasonToFast_ClearLakey.over = "yes";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_2")
			{
				// получена карта
				dialog.text = "Merci, "+ GetSexPhrase("monsieur", "mademoiselle") +" ! Je vais immédiatement donner l'ordre d'arrêter ce gredin. Rendez-vous compte ! Nous voulions le récompenser d'une arme d'honneur pour ses états de service irréprochables. Heureusement que tout s'est éclairci et que nous avons évité cet embarras !";
				link.l1 = "Fier de servir la justice...";
				link.l1.go = "ReasonToFast_Prison_GoodRep_21";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolDied")
			{
				// патруль перебит
				dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +" ! Nous soupçonnions depuis longtemps cet officier et la racaille qui l'entoure de malhonnêteté, mais il me semble que vous avez agi imprudemment en réglant leur compte sans témoins.";
				link.l1 = "Votre Grâce ! Mais je défendais ma vie...";
				link.l1.go = "ReasonToFast_Prison_GoodRep_31";
				pchar.questTemp.ReasonToFast.speakAfterPatrolDied = true;
				pchar.quest.ReasonToFast_SpeakMayor.over = "yes";
			}
		break;

		case "ReasonToFast_Prison_BadRep":
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_1")
			{
				// вилка_А
				dialog.text = "Capitaine, vous rendez-vous seulement compte de ce dans quoi vous vous mêlez ?!! Cela fait plus d'un mois que nous essayons de tendre ce piège ! Et pour vous amuser, vous avez fait échouer la rencontre de notre patrouille avec le messager " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN) + " et vous venez en plus vous en vanter chez moi ! Peut-être pourriez-vous maintenant me dire comment je vais justifier les dépenses publiques engagées pour organiser cette opération ?!!";
				link.l1 = "Votre Honneur ! Vous refusez de voir le fond de l'affaire...";
				link.l1.go = "ReasonToFast_Prison_BadRep1";
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_A";

				if(pchar.questTemp.ReasonToFast.chain == "A0") ReasonToFast_RemoveVictim();
				if(pchar.questTemp.ReasonToFast.chain == "A1") pchar.quest.ReasonToFast_ClearLakey.over = "yes";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_2")
			{
				// получена карта
				dialog.text = "Voyons cette carte... Vous vous moquez de moi ? Ce vieux bout de parchemin usé, une preuve ?";
				link.l1 = "Votre Honneur ! Vous refusez de voir le fond de l'affaire...";
				link.l1.go = "ReasonToFast_Prison_BadRep1";
				TakeItemFromCharacter(pchar, "mapQuest");
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_B";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolDied")
			{
				// патруль перебит
				dialog.text = "Une justification originale pour la mort de toute une patrouille. Enfin, en venant ici, vous nous avez au moins épargné la peine de chercher l'assassin.";
				link.l1 = "Votre Grâce ! Vous refusez de voir le fond de l'affaire...";
				link.l1.go = "ReasonToFast_Prison_BadRep1";
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_A";
				pchar.quest.ReasonToFast_SpeakMayor.over = "yes";
			}
		break;

		case "ReasonToFast_Prison_GoodRep_11":
			dialog.text = "Néanmoins, je veux que vos efforts soient récompensés. Tenez, prenez cette carte trouvée dans les affaires d'un brigand des mers pendu récemment. Peut-être qu'avec l'aide du Seigneur, vous découvrirez vraiment ces trésors, même si j'en doute fort...";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			AddQuestRecord("ReasonToFast", "15");
			ChangeCharacterReputation(pchar, 1);
			GiveItem2Character(pchar, "mapQuest");
			arItem = ItemsFromID("mapQuest");
			ReasonToFast_GenerateTreasureMap(arItem);
			pchar.questTemp.ReasonToFast.state = "chain_A"; // вилка_А, наводки не генерим
			pchar.questTemp.ReasonToFast = "GetMap";
			ReasonToFast_SetHunterCoastal();
		break;
		case "ReasonToFast_Prison_GoodRep_21":
			dialog.text = "Un zèle louable. Prenez cette lame en récompense, c'est bien le moins que je puisse vous donner ! Oui.. et gardez cette carte pour vous. Je suis sמr qu'il circule beaucoup de faux de ce genre dans l'archipel.";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			AddQuestRecord("ReasonToFast", "14");
			ChangeCharacterReputation(pchar, 1);
			GiveItem2Character(pchar, pchar.questTemp.ReasonToFast.p6);
			pchar.questTemp.ReasonToFast.state = "chain_B"; // была получена карта
			pchar.questTemp.ReasonToFast = "GetMap";
			ReasonToFast_SetHunterCoastal();
		break;
		case "ReasonToFast_Prison_GoodRep_31":
			dialog.text = "Oui, peut-être, peut-être... Eh bien, je suis prêt à considérer que l'affaire a été réglée par le jugement de Dieu et selon Sa volonté.";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 1);
			AddQuestRecord("ReasonToFast", "16");
			CloseQuestHeader("ReasonToFast");
			DeleteAttribute(pchar, "ReasonToFast");
		break;

		case "ReasonToFast_Prison_BadRep1":
			dialog.text = "Ne vous avisez pas de me faire la leçon ! Votre collusion avec ces escrocs est évidente ! Garde, emmenez "+ GetSexPhrase("ce « bienfaiteur »", "cette « bienfaitrice »") +" !";
			link.l1 = "Pas question !";
			link.l1.go = "fight";

			pchar.quest.ReasonToFast_ExitFromTown.win_condition.l1			= "EnterToSea";
            pchar.quest.ReasonToFast_ExitFromTown.function    				= "ReasonToFast_ExitFromTownFight";
			pchar.questTemp.ReasonToFast.canSpeakSailor = true;
			pchar.TownEscape = true;
			Flag_Change(PIRATE);
		break;
		// ------------------------- Повод для спешки -----------------------------

		// -------------------------- Операция 'Галеон' ----------------------------
		case "CapComission_PrisonBad1":
			dialog.text = "Pour quelle affaire en avez-vous besoin ?";
			link.l1 = "J'ai quelques questions personnelles à lui poser.";
			link.l1.go = "CapComission_PrisonBad2";
		break;

		case "CapComission_PrisonBad2":
			dialog.text = "Capitaine, j'ai l'ordre formel d'arrêter et d'envoyer à la résidence pour interrogatoire quiconque s'intéressera à la personne de " + pchar.GenQuest.CaptainComission.Name + ".";
			link.l1 = "Bravo ! Voilà que les prisonniers viennent d'eux-mêmes se faire arrêter !";
			link.l1.go = "CapComission_PrisonBad3";
		break;

		case "CapComission_PrisonBad3":
			dialog.text = "Je vous demande néanmoins de rendre vos armes.";
			link.l1 = "Pas question ! Il faudra la prendre par la force.";
			link.l1.go = "fight";
			AddDialogExitQuest("CaptainComission_GenerateCapJail");
		break;

		case "CapComission_PrisonGood1":
			dialog.text = "Oui, bien sמr. J'ai reçu l'ordre du gouverneur de vous assister dans cette affaire. Vous pouvez aller voir le prisonnier.";
			link.l1 = "Merci...";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			AddDialogExitQuest("CaptainComission_GenerateCapJail");
		break;

		case "CapComission_PrisonFree1":
			dialog.text = "Euh, capitaine, je n'ai reçu aucune instruction pour libérer ce prisonnier. Il vous faut l'autorisation du gouverneur.";
			link.l1 = "Officier, j'agis dans l'intérêt de l'enquête. Le prisonnier a accepté de coopérer avec les autorités et il est prêt à indiquer l'emplacement de la cachette. Le moindre retard risque de laisser les contrebandiers trouver la précieuse cargaison, et la colonie la perdra.";
			link.l1.go = "CapComission_PrisonFree2";
		break;

		case "CapComission_PrisonFree2":
			dialog.text = "Mais je pourrais vous donner une escorte pour l'accompagner.";
			link.l1 = "Ce ne sera pas nécessaire, j'ai assez d'hommes pour la sécurité. Et puis, je crains que l'emplacement de la cachette ne s'ébruite.";
			link.l1.go = "CapComission_PrisonFree3";
		break;

		case "CapComission_PrisonFree3":
			dialog.text = "Mmm... bon, d'accord. Mais n'oubliez pas que vous en répondez sur votre tête.";
			link.l1 = "Absolument...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First_officer";
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddDialogExitQuest("OpenTheDoors");
		break;
		// -------------------------- Операция 'Галеон' ----------------------------

		case "F_ShipLetters_1":
			dialog.text = "Parlez, je vous écoute.";
			link.l1 = "J'ai les documents de bord d'un navire. Je pense que leur propriétaire les a oubliés par distraction, mais ils vont vous intéresser.....";
			link.l1.go = "F_ShipLetters_2";
			pchar.questTemp.different.GiveShipLetters.speakFort = true;
		break;

		case "F_ShipLetters_2":
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Balivernes ! Ne me dérangez pas dans mon travail, allez plutכt à la capitainerie.";
				link.l1 = "Merci quand même....";
				link.l1.go = "exit";
			}
			else
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					dialog.text = "Oui, le propriétaire est d'ici. Une récompense de " + sti(pchar.questTemp.different.GiveShipLetters.price2) + " pièces d'or serait une juste récompense de votre vigilance, capitaine.";
					link.l1 = "Plutכt pas.";
					link.l1.go = "F_ShipLetters_3";
					link.l2 = "Offre généreuse ! Les papiers sont désormais à vous....";
					link.l2.go = "F_ShipLetters_4";
				}
				else
				{
					if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 1)
					{
						dialog.text = "Eh bien, c'est à couper le souffle tellement ils sont intéressants ! Je pense que le trésor de la ville vous paiera avec reconnaissance "+ sti(pchar.questTemp.different.GiveShipLetters.price4) +" pièces d'or, pour votre aide dans la lutte contre le commerce illégal.";
						link.l1 = "Plutכt pas.";
						link.l1.go = "F_ShipLetters_3";
						link.l2 = "Offre généreuse ! Les papiers sont désormais à vous....";
						link.l2.go = "F_ShipLetters_4";
					}
					if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 2)
					{
						dialog.text = "Mon Dieu ! Quelle chance que vous soyez venu me voir ! Je pense que mon malheureux collègue acceptera de payer " + sti(pchar.questTemp.different.GiveShipLetters.price3) + " pour éviter le scandale.";
						link.l1 = "Plutכt pas.";
						link.l1.go = "F_ShipLetters_3";
						link.l2 = "Offre généreuse ! Les papiers sont désormais à vous....";
						link.l2.go = "F_ShipLetters_4";
					}
				}
			}
		break;

		case "F_ShipLetters_3":
			dialog.text = "Hé ! C'est ma ville, capitaine.";
			link.l1 = "Je m'en souviendrai.";
			link.l1.go = "exit";
		break;

		case "F_ShipLetters_4":
			TakeItemFromCharacter(pchar, "CaptainBook");
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 1)
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price2));
				}
				else
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price4));
				}
			}
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 2)
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price2));
				}
				else
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price3));
				}
			}

			if((sti(pchar.questTemp.different.GiveShipLetters.variant) == 0) || (sti(pchar.questTemp.different.GiveShipLetters.variant) == 2))
			{
				ChangeCharacterReputation(pchar, -1);
				OfficersReaction("bad");
			}
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "8");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;


        case "ForGoodMove":
			dialog.text = NPCStringReactionRepeat("Mais pourquoi voulez-vous faire ça ? Croyez-moi, il n'y a rien à voir, que des voleurs et des bandits.", "Nous avons déjà parlé de ce souhait.",
				"Encore la même chose ? Nous en avons déjà parlé deux fois !", "Euh, encore...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je voulais quand même visiter vos cachots. דa m'intéresse beaucoup !", "Oui, c'est exact. Mais je voulais en reparler.",
				"Eh bien, peut-être pour la troisième fois...", "L'espoir de voir vos prisonniers ne me quitte pas...", npchar, Dialog.CurrentNode);
			link.l1.go = "ForGoodMove_1";
		break;
        case "ForGoodMove_1":
			pchar.questTemp.jailCanMove.money = (rand(15)+10)*100;
			if (sti(colonies[FindColony(npchar.city)].jail) && sti(pchar.money) >= sti(pchar.questTemp.jailCanMove.money))
			{
				dialog.text = "Eh bien, je ne vois pas de raison de refuser. " + FindRussianMoneyString(sti(pchar.questTemp.jailCanMove.money)) + " - et jusqu'à ce que vous quittiez la prison, vous pourrez circuler librement dans les couloirs et même parler aux prisonniers.";
				link.l1 = "D'accord. Voici vos pièces !";
				link.l1.go = "ForGoodMove_agree";
				link.l2 = "דa ne va pas, c'est trop cher pour se promener sans but dans des couloirs.";
				link.l2.go = "exit";
			}
			else
			{
				dialog.text = RandPhraseSimple("Non, c'est strictement interdit par le règlement. Vous vous croyez au cirque ? Partez, et ne me distrayez pas de mon service.", "Je ne peux pas laisser des étrangers se promener dans la prison. Ne me dérangez pas, je vous prie !");
				link.l1 = "D'accord, comme vous voudrez...";
				link.l1.go = "exit";
			}
		break;
        case "ForGoodMove_agree":
            dialog.text = "Eh bien, vous pouvez commencer votre, pour ainsi dire, excursion...";
			link.l1 = "Merci, officier.";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.jailCanMove.money));
		break;
        case "KnowAboutPrisoner":
			switch (pchar.questTemp.jailCanMove.ownerPrison)
			{
				case "0": sTemp = "Pour meurtre."; break;
				case "1": sTemp = "Pour banditisme et vol à main armée."; break;
				case "2": sTemp = "Il a été pris en train de voler."; break;
				case "3": sTemp = "Pour menu larcin."; break;
				case "4": sTemp = "Pour escroquerie."; break;
			}
			dialog.text = sTemp;
			link.l1 = "Compris... Y a-t-il une possibilité de payer une rançon pour lui, une caution, ou de contribuer d'une autre façon à sa libération ?";
			link.l1.go = "KnowAboutPrisoner_" + pchar.questTemp.jailCanMove.ownerPrison;
			DeleteAttribute(pchar, "questTemp.jailCanMove.City");
		break;
        case "KnowAboutPrisoner_0":
			dialog.text = "Non, bien sמr que non. Ce gibier de potence est promis à l'enfer. Le gouverneur le surveille personnellement !";
			link.l1 = "Hé, je vois...";
			link.l1.go = "notFree_exit";
		break;
        case "KnowAboutPrisoner_1":
			dialog.text = "Je ne crois pas. Il a causé bien du tort aux habitants de notre ville. Alors n'y pensez même pas.";
			link.l1 = "Hum, je vois.";
			link.l1.go = "notFree_exit";
		break;
        case "KnowAboutPrisoner_2":
			dialog.text = "Non, plutכt pas. C'est un voleur, et un voleur doit être en prison !";
			link.l1 = "Eh bien ! Bien dit, lieutenant...";
			link.l1.go = "notFree_exit";
		break;
        case "KnowAboutPrisoner_3":
			dialog.text = "Je ne sais même pas. Ce gamin a volé une poêle à une ménagère. Je ne peux pas le relâcher, mais le laisser pourrir ici pour si peu, ce n'est pas juste non plus...";
			link.l1 = "Alors confiez-le-moi, lieutenant. Je paierai, dans des limites raisonnables, bien sמr.";
			link.l1.go = "KnowAboutPrisoner_free";
		break;
        case "KnowAboutPrisoner_4":
			dialog.text = "Le faire sortir ? C'est tout à fait possible. א mon avis, garder ce petit escroc ici n'a aucun sens.";
			link.l1 = "Alors confiez-le-moi, lieutenant. Je paierai, dans des limites raisonnables, bien sמr.";
			link.l1.go = "KnowAboutPrisoner_free";
		break;
        case "KnowAboutPrisoner_free":
			pchar.questTemp.jailCanMove.ownerPrison.money = (rand(3)+2)*1000;
			if (sti(pchar.money) > sti(pchar.questTemp.jailCanMove.ownerPrison.money))
			{
				dialog.text = "Hum, d'accord. " + FindRussianMoneyString(sti(pchar.questTemp.jailCanMove.ownerPrison.money)) + " sur la table, et vous pouvez l'emmener tout de suite.";
				link.l1 = "Parfait, j'accepte.";
				link.l1.go = "KnowAboutPrisoner_agree";
				link.l2 = "Non, ça va coמter cher. Je refuse.";
				link.l2.go = "KnowAboutPrisoner_exit";
			}
			else
			{
				dialog.text = "Non, ça ne marchera pas. Je peux avoir une inspection à tout moment, je ne veux pas prendre de risques.";
				link.l1 = "Eh bien ! Bien dit, lieutenant...";
				link.l1.go = "exit";
			}
		break;
        case "KnowAboutPrisoner_agree":
			dialog.text = "Voilà, vous pouvez aller à sa cellule chercher ce va-nu-pieds.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.jailCanMove.ownerPrison.money));
			DeleteAttribute(pchar, "questTemp.jailCanMove.ownerPrison");
			sld = characterFromId(pchar.questTemp.jailCanMove.prisonerId)
			LAi_CharacterEnableDialog(sld);
			sld.dialog.currentnode = "ToPrisonHead_canMove";
		break;
        case "KnowAboutPrisoner_exit":
			dialog.text = "Bon, réfléchissez bien, je ne vous laisserai pas d'autre chance...";
			link.l1 = "Inutile. Ma décision est prise.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.jailCanMove.ownerPrison");
			sld = characterFromId(pchar.questTemp.jailCanMove.prisonerId);
			LAi_CharacterEnableDialog(sld);
			sld.dialog.currentnode = "ToPrisonHead_expansive";
		break;
        case "notFree_exit":
			sld = characterFromId(pchar.questTemp.jailCanMove.prisonerId);
			LAi_CharacterEnableDialog(sld);
			sld.dialog.currentnode = "ToPrisonHead_notFree";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//---------------- Протектор ------------------
        case "First_protector":
			if (sti(pchar.questTemp.jailCanMove))
			{
				dialog.text = RandPhraseSimple("Vous pouvez passer, le commandant a donné son autorisation...", "L'ordre du commandant a été reçu. Vous pouvez passer librement.");
				link.l1 = "Eh bien, c'est parfait.";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "questTemp.jailCanMove.ownerPrison.money");
			}
			else
			{
				dialog.text = RandPhraseSimple("Il est strictement interdit d'aller plus loin sans l'autorisation du commandant !", "Je n'obéis qu'au commandant. Si vous essayez d'aller plus loin sans son autorisation, vous êtes fini !");
				link.l1 = RandPhraseSimple("Compris", "Compris") + ", soldat.";
				link.l1.go = "exit";
			}
			NextDiag.TempNode = "First_protector";
		break;
		//---------------- Солдаты ------------------
        case "First_soldier":
            dialog.text = RandPhraseSimple("Je suis de service, ne me distrayez pas.", "Passez votre chemin, je ne peux pas vous parler.");
			link.l1 = "D'accord, soldat.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First_soldier";
		break;
		//---------------- Заключённые ------------------
        case "First_prisoner":
			if (GetNationRelation2MainCharacter(sti(npchar.nation)) == RELATION_ENEMY)
			{
				dialog.text = LinkRandPhrase("Ho ho, que c'est drכle !!", "Taille-les, "+ GetSexPhrase("l'ami", "ma petite") +" taille-les !!!", "Oh, diable ! Je n'aurais jamais cru voir le cadavre de mon geכlier !");
				link.l1 = RandPhraseSimple("Hé !", "Argh...");
				link.l1.go = "NoMoreTalkExit";
				if (rand(10) > 6 && !CheckAttribute(pchar, "quest.GivePrisonFree") && !CheckAttribute(pchar, "quest.GivePrisonFree_Over") && !CheckAttribute(pchar, "quest.DeliverToBander"))
				{
					dialog.text = RandPhraseSimple("Attendez, "+ GetSexPhrase("l'ami", "ma petite") +" !!! Faites-moi sortir !", "וcoutez, "+ GetSexPhrase("l'ami", "ma petite") +", soyez assez aimable pour ouvrir la cellule.");
					link.l1 = "Et pourquoi donc ?";
					link.l1.go = "Prisoner_1"; // на квест освобождения заключённого
				}
			}
			else
			{
				dialog.text = LinkRandPhrase("On m'a arrêté pour vol, on me monte un dossier...", "Ah, vous êtes si élégant... Vous devriez passer une semaine dans ma cellule ! Hé hé hé...", "Je ne suis coupable de rien !");
				link.l1 = RandPhraseSimple("La ferme !", "Je me moque bien de toi...");
				link.l1.go = "NoMoreTalkExit";
				if (rand(10) > 6 && !CheckAttribute(pchar, "quest.GivePrisonFree_Over") && !CheckAttribute(pchar, "quest.GivePrisonFree") && !CheckAttribute(pchar, "quest.DeliverToBander") && !sti(colonies[FindColony(npchar.city)].HeroOwn))
				{
					dialog.text = RandPhraseSimple("Attendez, "+ GetSexPhrase("l'ami", "ma petite") +", ne passez pas si vite devant ma cellule !", "Prenez votre temps, "+ GetSexPhrase("l'ami", "ma petite") +" - parlons un peu.");
					link.l1 = "Et pourquoi donc ?";
					if (rand(1))
					{
						link.l1.go = "Prisoner_1"; // на квест освобождения заключённого
					}
					else
					{
						link.l1.go = "Deliver_1"; // на квест передачу весточки
					}
				}
			}
		break;
		// -------------------- освобождение заключённого --------------------
        case "Prisoner_1":
            dialog.text = "וcoutez-moi. Ne me regardez pas comme ça. J'aimerais sortir d'ici...";
			link.l1 = "Quoi ?!";
			link.l1.go = "Prisoner_2";
			GetChestPlaceName();
			pchar.questTemp.jailCanMove.prisonerId = npchar.id; //запомним Id
			pchar.questTemp.jailCanMove.IsTrue = rand(4); //вид клада
			pchar.questTemp.jailCanMove.Sum = (rand(10)+10)*1000+(sti(pchar.rank)*1000); //сумма клада
			pchar.questTemp.jailCanMove.Item1 = GenQuestPrison_GenerateArtefact();
			pchar.questTemp.jailCanMove.Item2 = GenQuestPrison_GenerateBlade();
			pchar.questTemp.jailCanMove.Name = GetFullName(npchar); //имя перца
		break;
        case "Prisoner_2":
            dialog.text = "Aidez-moi à sortir, et je saurai vous remercier.";
			link.l1 = "Voilà qui devient intéressant. Qui êtes-vous et que pouvez-vous me proposer ?";
			link.l1.go = "Prisoner_3";
		break;
        case "Prisoner_3":
            dialog.text = "Je m'appelle " + GetFullName(npchar) + ". J'ai quelque chose de caché en lieu sמr. Sortez-moi d'ici et emmenez-moi à " + XI_ConvertString(pchar.questTemp.jailCanMove.islandId + "Acc") + ". J'ai un trésor caché dans une grotte, là-bas. Allons le chercher et partageons-le en deux !";
			link.l1 = "Et qu'y a-t-il dans votre trésor ? Et comment savoir si vous dites vrai ?";
			link.l1.go = "Prisoner_4";
		break;
        case "Prisoner_4":
            dialog.text = "Je vous le jure, je dis l'entière vérité ! Et j'ai caché de l'argent et des bijoux dans ce trésor...";
			link.l1 = "Non, l'ami. Je ne vais pas risquer ma peau pour un trésor douteux. Désolé...";
			link.l1.go = "Prisoner_5";
			if (GetNationRelation2MainCharacter(sti(npchar.nation)) != RELATION_ENEMY)
			{
				link.l2 = "דa vaut sans doute le risque... Je propose ceci : je peux tuer les gardes de la prison et t'emmener jusqu'à mon navire. Si tout se passe bien, je veux que tu restes avec moi jusqu'à ce que nous arrivions à la grotte, sur " + XI_ConvertString(pchar.questTemp.jailCanMove.islandId + "Voc") + ". דa te va ?";
				link.l2.go = "Prisoner_agree"; //силовой способ вызволения
				link.l3 = "Bon, d'accord, je vais essayer de t'aider : je vais parler au commandant. Il sera peut-être possible de payer une caution pour ta libération.";
				link.l3.go = "ToPrisonHead_agree"; //мирный способ вызволения
			}
			else
			{
				link.l2 = "Bon, d'accord, je vais te croire et ouvrir la cellule. Je veux que tu restes avec moi jusqu'à ce que nous arrivions à la grotte, sur " + XI_ConvertString(pchar.questTemp.jailCanMove.islandId + "Voc") + ". דa te va ?";
				link.l2.go = "Prisoner_agree_3"; //силовой способ вызволения, когда тюремщики убиты
			}
		break;
        case "Prisoner_5":
            dialog.text = RandPhraseSimple("Maudit sois-tu, canaille !!", "Que le diable t'emporte, Judas...");
			link.l1 = RandPhraseSimple("Et bonne journée à toi. Au revoir...", "Le chien aboie, la caravane passe...");
			link.l1.go = "NoMoreTalkExit";
		break;
        case "Prisoner_agree":
            dialog.text = "D'accord, je n'ai pas le choix.";
			link.l1 = "D'accord. Je vais forcer ta serrure, tu sors de là, et on se fraie un passage. Tu es prêt ?";
			link.l1.go = "Prisoner_agree_1";
		break;
        case "Prisoner_agree_1":
            dialog.text = "Oui, "+ GetSexPhrase("l'ami", "ma petite") +"Je suis prêt !";
			link.l1 = "Au travail !";
			link.l1.go = "Prisoner_agree_2";
		break;
        case "Prisoner_agree_2":
			string slai_group = GetNationNameByType(sti(npchar.nation))  + "_citizens";
			LAi_group_AttackGroup(slai_group, LAI_GROUP_PLAYER);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			ReOpenQuestHeader("GivePrisonFree");
			AddQuestRecord("GivePrisonFree", "1");
            AddQuestUserData("GivePrisonFree", "sCity", XI_ConvertString("Colony"+npchar.city+"Gen"));
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
            AddQuestUserData("GivePrisonFree", "sIsland", XI_ConvertString(pchar.questTemp.jailCanMove.islandId+"Voc"));
			pchar.quest.GivePrisonFree_Death.win_condition.l1 = "NPC_Death";
			pchar.quest.GivePrisonFree_Death.win_condition.l1.character = npchar.id;
			pchar.quest.GivePrisonFree_Death.win_condition = "GivePrisonFree_Death";
			Pchar.quest.GivePrisonFree.win_condition.l1 = "location";
			Pchar.quest.GivePrisonFree.win_condition.l1.location = pchar.questTemp.jailCanMove.placeId;
			Pchar.quest.GivePrisonFree.win_condition = "GivePrisonFree";
			DeleteAttribute(npchar, "LifeDay");
			GiveItem2Character(npchar, "unarmed");
			EquipCharacterbyItem(npchar, "unarmed");
			GetCharacterPos(npchar, &locx, &locy, &locz);
			ChangeCharacterAddressGroup(npchar, npchar.location, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz));
			LAi_SetActorType(npchar);
			LAi_group_Register("DeliveQuest_Prison");
			LAi_group_SetRelation("DeliveQuest_Prison", LAI_GROUP_PLAYER, LAI_GROUP_FRIEND);
			LAi_group_SetAlarmReaction(LAI_GROUP_PLAYER, "DeliveQuest_Prison", LAI_GROUP_ENEMY, LAI_GROUP_FRIEND);
			LAi_group_MoveCharacter(npchar, "DeliveQuest_Prison");
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

        case "Prisoner_agree_3":
            dialog.text = "D'accord, je n'ai pas le choix.";
			link.l1 = "D'accord. Suis-moi aussi vite que tu peux, il faut encore rejoindre mon navire. Ne traîne pas !";
			link.l1.go = "Prisoner_agree_4";
		break;
        case "Prisoner_agree_4":
			ReOpenQuestHeader("GivePrisonFree");
			AddQuestRecord("GivePrisonFree", "1");
            AddQuestUserData("GivePrisonFree", "sCity", XI_ConvertString("Colony"+npchar.city+"Gen"));
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
            AddQuestUserData("GivePrisonFree", "sIsland", XI_ConvertString(pchar.questTemp.jailCanMove.islandId+"Voc"));
			pchar.quest.GivePrisonFree_Death.win_condition.l1 = "NPC_Death";
			pchar.quest.GivePrisonFree_Death.win_condition.l1.character = npchar.id;
			pchar.quest.GivePrisonFree_Death.win_condition = "GivePrisonFree_Death";
			Pchar.quest.GivePrisonFree.win_condition.l1 = "location";
			Pchar.quest.GivePrisonFree.win_condition.l1.location = pchar.questTemp.jailCanMove.placeId;
			Pchar.quest.GivePrisonFree.win_condition = "GivePrisonFree";
			DeleteAttribute(npchar, "LifeDay");
			GiveItem2Character(npchar, "unarmed");
			EquipCharacterbyItem(npchar, "unarmed");
			GetCharacterPos(npchar, &locx, &locy, &locz);
			ChangeCharacterAddressGroup(npchar, npchar.location, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz));
			LAi_SetActorType(npchar);
			LAi_group_Register("DeliveQuest_Prison");
			LAi_group_SetRelation("DeliveQuest_Prison", LAI_GROUP_PLAYER, LAI_GROUP_FRIEND);
			LAi_group_MoveCharacter(npchar, "DeliveQuest_Prison");
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;

        case "ToPrisonHead_agree":
            dialog.text = "Eh bien, essaie. Ah, si ça pouvait marcher ! Mais ne perds pas de temps, je ne serai plus là dans quelques jours...";
			link.l1 = "Attends, je vais arranger ça.";
			link.l1.go = "NoMoreTalkExit";
			pchar.questTemp.jailCanMove.MayorId = characters[GetCharacterIndex(npchar.city + "_Mayor")].id; //Id мэра
			pchar.questTemp.jailCanMove.City = npchar.City; //город
			pchar.questTemp.jailCanMove.ownerPrison = rand(4); //характер преступления
			SetTimerCondition("GivePrisonFree_Over", 0, 0, 2, false);
			AddQuestRecord("GivePrisonFree", "5");
			AddQuestUserData("GivePrisonFree", "sSex", GetSexPhrase("", "e"));
            AddQuestUserData("GivePrisonFree", "sCity", XI_ConvertString("Colony"+npchar.city+"Gen"));
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
		break;

        case "ToPrisonHead_canMove":
            dialog.text = "Alors, qu'est-ce que tu en dis, "+ GetSexPhrase("l'ami", "ma petite") +" ?";
			link.l1 = "Tout est réglé, je peux te faire sortir.";
			link.l1.go = "ToPrisonHead_canMove_1";
		break;
        case "ToPrisonHead_canMove_1":
            dialog.text = "Eh bien, filons d'ici au plus vite ! Bon sang, que je suis content !";
			link.l1 = "Récapitulons. Je veux que, pendant tout le trajet jusqu'à la grotte, sur " + XI_ConvertString(pchar.questTemp.jailCanMove.islandId + "Voc") + ", tu ne me quittes pas d'une semelle. Au cas oם, pour ainsi dire. Tu es d'accord ?";
			link.l1.go = "ToPrisonHead_canMove_2";
		break;
        case "ToPrisonHead_canMove_2":
            dialog.text = "Bien sמr que je suis d'accord ! Et je n'ai pas le choix.";
			link.l1 = "Alors tu es libre.";
			link.l1.go = "ToPrisonHead_canMove_exit";
		break;
        case "ToPrisonHead_canMove_exit":
			pchar.quest.GivePrisonFree_Over.over = "yes";
			ReOpenQuestHeader("GivePrisonFree");
			AddQuestRecord("GivePrisonFree", "1");
            AddQuestUserData("GivePrisonFree", "sCity", XI_ConvertString("Colony"+npchar.city+"Gen"));
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
            AddQuestUserData("GivePrisonFree", "sIsland", XI_ConvertString(pchar.questTemp.jailCanMove.islandId+"Voc"));
			pchar.quest.GivePrisonFree_Death.win_condition.l1 = "NPC_Death";
			pchar.quest.GivePrisonFree_Death.win_condition.l1.character = npchar.id;
			pchar.quest.GivePrisonFree_Death.win_condition = "GivePrisonFree_Death";
			Pchar.quest.GivePrisonFree.win_condition.l1 = "location";
			Pchar.quest.GivePrisonFree.win_condition.l1.location = pchar.questTemp.jailCanMove.placeId;
			Pchar.quest.GivePrisonFree.win_condition = "GivePrisonFree";
			DeleteAttribute(npchar, "LifeDay");
			GiveItem2Character(npchar, "unarmed");
			EquipCharacterbyItem(npchar, "unarmed");
			GetCharacterPos(npchar, &locx, &locy, &locz);
			ChangeCharacterAddressGroup(npchar, npchar.location, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz));
			LAi_SetActorType(npchar);
			LAi_group_Register("DeliveQuest_Prison");
			LAi_group_SetRelation("DeliveQuest_Prison", LAI_GROUP_PLAYER, LAI_GROUP_FRIEND);
			LAi_group_MoveCharacter(npchar, "DeliveQuest_Prison");
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;

        case "ToPrisonHead_notFree":
			switch (pchar.questTemp.jailCanMove.ownerPrison)
			{
				case "0": sTemp = "meurtre"; break;
				case "1": sTemp = "vol à main armée"; break;
				case "2": sTemp = "vol"; break;
			}
            dialog.text = "Alors, qu'est-ce que tu en dis, "+ GetSexPhrase("l'ami", "ma petite") +" ?";
			link.l1 = "Je n'ai pas pu négocier ta libération. Tu es accusé de " + sTemp + ", il ne peut donc être question de caution.";
			link.l1.go = "ToPrisonHead_notFree_1";
			DeleteAttribute(pchar, "questTemp.jailCanMove.ownerPrison");
		break;
        case "ToPrisonHead_notFree_1":
            dialog.text = "On m'a menti !.. Oh, diable !! Qu'est-ce que je vais faire maintenant ? Je vais pourrir ici vivant !";
			link.l1 = "Désolé, l'ami, mais je ne peux pas t'aider.";
			link.l1.go = "ToPrisonHead_notFree_2";
			link.l2 = "Il reste une chance de te libérer par la force. Je vais forcer ta serrure, tu sors de là, et on se fraie un passage. Tu es prêt ?";
			link.l2.go = "Prisoner_agree_1";
			pchar.quest.GivePrisonFree_Over.over = "yes";
		break;
        case "ToPrisonHead_notFree_2":
            dialog.text = RandPhraseSimple("Maudit sois-tu, crapule !!", "Que le diable t'emporte, Judas...");
			link.l1 = "Et bonne journée à toi. Au revoir...";
			link.l1.go = "NoMoreTalkExit";
			AddQuestRecord("GivePrisonFree", "7");
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			DeleteAttribute(pchar, "questTemp.jailCanMove.islandId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.placeId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.prisonerId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.IsTrue");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Sum");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Name");
		break;

        case "ToPrisonHead_expansive":
			dialog.text = "Alors, qu'est-ce qui vous ferait plaisir, "+ GetSexPhrase("l'ami", "ma petite") +" ?";
			link.l1 = "La caution pour ta libération est trop élevée, je n'ai pas assez d'argent. Je suis obligé de refuser.";
			link.l1.go = "ToPrisonHead_notFree_2";
			pchar.quest.GivePrisonFree_Over.over = "yes";
		break;
		//==> в месте, где клад припрятан
        case "PrisonerInPlace":
			switch (sti(pchar.questTemp.jailCanMove.IsTrue))
			{
				case 0:
					dialog.text = "וcoute, j'ai tout fouillé ici, mais je n'ai pas trouvé mon trésor. Dommage que ça se soit passé comme ça ; quelqu'un l'a sמrement déterré avant nous.";
					link.l1 = "Comment est-ce possible ?!";
					link.l1.go = "PrisonerInPlace_1";
				break;
				case 1:
					dialog.text = "Je l'ai trouvé ! Les bijoux étaient là oם je les avais laissés.";
					link.l1 = "Parfait. Alors, on partage ?";
					link.l1.go = "Node_1";
				break;
				case 2:
					dialog.text = "Eh bien, voilà ma cachette. Ce n'est pas grand-chose, en vérité, mais c'est tout ce que j'ai. Comme convenu, la moitié est à toi.";
					link.l1 = "Oui, le trésor n'est vraiment pas fameux. Enfin, merci quand même.";
					link.l1.go = "Node_2";
				break;
				case 3:
					dialog.text = "Capitaine, je suis désolé, c'est arrivé comme ça... Bref, il n'y a pas de trésor.";
					link.l1 = "Quoi ? Tu m'as roulé, gredin ! Je t'ai sorti de ta cellule, je t'ai traîné jusqu'à cette île, et pour quoi ?! Tu ne vas pas t'en tirer comme ça !";
					link.l1.go = "Node_3";
				break;
				case 4:
					dialog.text = "Bon sang... Comment ça ? Ce n'est pas possible !";
					link.l1 = "Qu'est-ce que tu fabriques, l'ami ? Oם est notre trésor ? Ne me dis pas qu'il n'est pas là !";
					link.l1.go = "Node_4";
				break;
			}
		break;

		case "Node_1":
			dialog.text = "Oui, bien sמr, comme convenu. La moitié du trésor est à toi.";
			link.l1 = "Eh bien, que d'objets précieux ici !";
			link.l1.go = "PrisonerInPlace_3";
			Log_Info("Vous avez reçu votre part du trésor");
			PlaySound("interface\important_item.wav");
			TakeNItems(pchar, "icollection", 1+drand(1));
			TakeNItems(pchar, "chest", 4+drand(4));
			TakeNItems(pchar, "jewelry1", 70+rand(15));
			TakeNItems(pchar, "jewelry2", 50+rand(15));
			TakeNItems(pchar, "jewelry3", 60+rand(15));
			TakeNItems(pchar, "jewelry4", 40+rand(10));
			TakeNItems(pchar, "jewelry15", 10+rand(10));
			TakeNItems(pchar, "jewelry18", 60+rand(20));
			TakeNItems(pchar, "jewelry14", 40+rand(15));
			TakeNItems(pchar, "jewelry7", 60+rand(20));
			AddQuestRecord("GivePrisonFree", "3_1");
			AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			CloseQuestHeader("GivePrisonFree");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item1");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item2");
		break;

		case "Node_2":
			dialog.text = "Capitaine, il y a cet objet indien ici, parmi d'autres choses. Prenez-le en plus de votre part.";
			link.l1 = "Eh bien, au moins, j'aurai quelque chose de valable pour ta libération ! Donne-le-moi.";
			link.l1.go = "PrisonerInPlace_3";
			Log_Info("Vous avez reçu votre part du trésor");
			PlaySound("interface\important_item.wav");
			sTemp = pchar.questTemp.jailCanMove.Item1;
			TakeNItems(pchar, sTemp, 1);
			TakeNItems(pchar, "jewelry5", 40+rand(10));
			TakeNItems(pchar, "jewelry6", 20+rand(20));
			TakeNItems(pchar, "jewelry17", 80+rand(20));
			TakeNItems(pchar, "jewelry13", 10+rand(10));
			TakeNItems(pchar, "jewelry11", 20+rand(20));
			TakeNItems(pchar, "jewelry12", 50+rand(20));
			AddQuestRecord("GivePrisonFree", "3_2");
			AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			CloseQuestHeader("GivePrisonFree");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item1");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item2");
		break;

		case "Node_3":
			dialog.text = "Attendez, capitaine, ne vous emportez pas, laissez-moi parler. Je suis marin moi aussi, tout comme vous. On m'a jeté en prison par erreur, je le jure. Vous étiez ma seule chance de m'échapper, et j'ai dמ vous mentir à propos du trésor. Il n'y a pas d'argent, mais j'ai caché ici une bonne chose. Prenez-la, et laissez-moi partir en paix. Peut-être aurez-vous plus d'une fois une pensée reconnaissante pour moi au combat.";
			link.l1 = "Bon, de toute façon, il n'y a rien à tirer de toi. Remercie Dieu que je sois clément.";
			link.l1.go = "PrisonerInPlace_3";
			Log_Info("Vous avez reçu l'équipement");
			PlaySound("interface\important_item.wav");
			sTemp = pchar.questTemp.jailCanMove.Item2;
			TakeNItems(pchar, sTemp, 1);
			AddQuestRecord("GivePrisonFree", "3_3");
			AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			CloseQuestHeader("GivePrisonFree");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item1");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item2");
		break;

		case "Node_4":
			dialog.text = "Non !!! Il n'existe vraiment pas ! Satané bout de papier... Capitaine, croyez-moi, je pensais vraiment qu'il était là ! Mais apparemment, je me suis trompé ! Tout est si confus sur ce bout de papier...";
			link.l1 = "Eh bien, on dirait que tu vas avoir de sérieux ennuis, l'ami. Mais je veux quand même entendre tes explications.";
			link.l1.go = "Node_4_1";
		break;

		case "Node_4_1":
			dialog.text = "J'avais un morceau de carte. Une vraie carte, je le jure ! Mais c'est si difficile de distinguer quelle île y est indiquée... Je pensais que c'était ici. Mais comme vous le voyez, ce n'est pas le cas.";
			link.l1 = "Quel morceau de carte ? Donne-le-moi, tout de suite !";
			link.l1.go = "Node_4_2";
		break;

		case "Node_4_2":
			if (CheckCharacterItem(pchar, "map_part1"))
			{
				GiveItem2Character(pchar, "map_part2");
			}
			else
			{
				GiveItem2Character(pchar, "map_part1");
			}
			dialog.text = "Tenez, prenez-le, bien sמr. Capitaine, laissez-moi partir, je vous en prie... Je pensais vraiment que le trésor était là. Peut-être arriverez-vous à trouver oם il est sur ce morceau, et à le prendre tout entier pour vous. Je vous en prie.";
			link.l1 = "Oui... C'est très difficile d'y distinguer quoi que ce soit. Il faut la seconde moitié de la carte. Bon, file, je vois que tu étais de bonne foi.";
			link.l1.go = "PrisonerInPlace_4";
		break;
        case "PrisonerInPlace_1":
			dialog.text = "Oui, c'est très simple, "+ GetSexPhrase("l'ami", "ma petite") +". Ce sont des choses qui arrivent dans la vie. Bon, vous êtes là, si vous voulez rester, cherchez encore. Moi, je dois y aller ! Adieu, "+ GetSexPhrase("l'ami", "ma belle") +", merci de m'avoir sauvé. Je me souviendrai de vous à jamais !";
			link.l1 = "Espèce de salaud ! Tu crois que je vais te laisser partir comme ça ?! Hé... Arrête-toi, lâche !";
			link.l1.go = "PrisonerInPlace_2";
			AddQuestRecord("GivePrisonFree", "4");
			AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			CloseQuestHeader("GivePrisonFree");

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.jailCanMove.Item1");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item2");
		break;
        case "PrisonerInPlace_2":
			LAi_group_Delete("EnemyFight");
			DeleteAttribute(pchar, "questTemp.jailCanMove.islandId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.placeId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.prisonerId");
			DeleteAttribute(pchar, "questTemp.jailCanMove.IsTrue");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Sum");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Name");
			chrDisableReloadToLocation = false;
			LAi_LocationDisableMonstersGen(pchar.location, false);
			npchar.lifeDay = 0;
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", -1);
			DialogExit();
            Pchar.quest.DeletePrisonGroup.win_condition.l1 = "ExitFromLocation";
            Pchar.quest.DeletePrisonGroup.win_condition.l1.location = pchar.location;
            Pchar.quest.DeletePrisonGroup.win_condition = "DeletePrisonGroup";
		break;
        case "PrisonerInPlace_3":
			dialog.text = "Veuillez recevoir. Et merci !";
			link.l1 = "Au revoir...";
			link.l1.go = "PrisonerInPlace_2";
		break;
        case "PrisonerInPlace_4":
			dialog.text = "Merci, capitaine ! Je prierai pour vous jusqu'à la fin de mes jours !";
			link.l1 = "Allons, ça suffit ! Va avec Dieu...";
			link.l1.go = "PrisonerInPlace_2";
			AddQuestRecord("GivePrisonFree", "3_4");
            AddQuestUserData("GivePrisonFree", "iSum", FindRussianMoneyString(sti(pchar.questTemp.jailCanMove.Sum)));
            AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Name);
			AddQuestUserData("GivePrisonFree", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("GivePrisonFree");

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.jailCanMove.Item1");
			DeleteAttribute(pchar, "questTemp.jailCanMove.Item2");
 		break;
		// -------------------- освобождение заключённого --------------------
		// ------------------------ передать маляву --------------------------
        case "Deliver_1":
			dialog.text = "Mon surnom, c'est " + GetFullName(npchar) + ". J'ai une petite requête pour vous, hé hé...";
			link.l1 = "Laquelle ?";
			link.l1.go = "Deliver_2";
		break;
        case "Deliver_2":
			dialog.text = "Il faut faire passer un petit mot dehors. Vous voulez bien ?";
			link.l1 = "Qu'est-ce que j'y gagne ?";
			link.l1.go = "Deliver_3";
		break;
        case "Deliver_3":
			dialog.text = "Mes potes ne vous oublieront pas, évidemment... Alors, vous le prenez ?";
			link.l1 = "Non, ça ne m'intéresse pas.";
			link.l1.go = "Prisoner_5";
			link.l2 = "Hum, si ce n'est pas trop loin, je le prends.";
			link.l2.go = "Deliver_agree";
		break;
        case "Deliver_agree":
			dialog.text = "D'accord. Maintenant, écoutez-moi bien. Deux gars attendent mon petit mot en ville ; ils se sont planqués dans une maison pour ne pas se faire coffrer. Je ne sais pas laquelle, il faudra la chercher.";
			link.l1 = "Chercher comment ?";
			link.l1.go = "Deliver_4";
		break;
        case "Deliver_4":
			dialog.text = "Chercher, tout simplement. Vous faites le tour de la ville, vous regardez les maisons... Une fois au bon endroit, ils ne vous laisseront pas repartir sans avoir causé. Mais n'oubliez pas que je ne serai plus là que deux jours, pas plus. Alors ne traînez pas.";
			link.l1 = "Compris. Bon, donnez-moi votre message.";
			link.l1.go = "Deliver_5";
		break;
        case "Deliver_5":
			pchar.questTemp.jailCanMove.Deliver.locationId = GetBanderLocation(npchar); //Id коммона
			if (pchar.questTemp.jailCanMove.Deliver.locationId == "none")
			{
				dialog.text = "Hum, vous ne me plaisez pas. J'ai changé d'avis. Allez, allez, ne restez pas planté là !";
				link.l1 = "Eh bien ! Bon, comme vous voudrez...";
				link.l1.go = "NoMoreTalkExit";
				DeleteAttribute(pchar, "questTemp.jailCanMove.Deliver");
			}
			else
			{
				dialog.text = "Tenez. Merci, "+ GetSexPhrase("l'ami", "ma petite") +" !";
				link.l1 = "Je vous en prie.";
				link.l1.go = "NoMoreTalkExit";
				GiveItem2Character(Pchar, "Malyava");
				pchar.questTemp.jailCanMove.Deliver.Id = npchar.id; //Id зэка
				pchar.questTemp.jailCanMove.Deliver.name = GetFullName(npchar); //имя зэка
				pchar.questTemp.jailCanMove.Deliver.City = npchar.city; //город (Id колонии)
				pchar.questTemp.jailCanMove.Deliver.good = rand(3); //опрокинут или нет
				pchar.questTemp.jailCanMove.Deliver.price = rand(6)*500+500; //цена услуги
				pchar.quest.DeliverToBander.win_condition.l1 = "location";
				pchar.quest.DeliverToBander.win_condition.l1.location = pchar.questTemp.jailCanMove.Deliver.locationId;
				pchar.quest.DeliverToBander.win_condition = "DeliverToBander";
				pchar.quest.DeliverToBander.again = true;
				SetTimerCondition("DeliverToBander_over", 0, 0, 2, false);
				ReOpenQuestHeader("GivePrisonFree");
				AddQuestRecord("GivePrisonFree", "8");
				AddQuestUserData("GivePrisonFree", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("GivePrisonFree", "sCity", XI_ConvertString("Colony"+npchar.city+"Gen"));
				AddQuestUserData("GivePrisonFree", "sName", pchar.questTemp.jailCanMove.Deliver.name);
			}
		break;
		case "TohmasPetit_OfficerRefusal":
			dialog.text = "Un piège dans la jungle et du racket ? Et vous y êtes allé seul ? Quelle imprudence. Qui est donc cet escroc audacieux qui vous a forcé à vous séparer de votre or ?";
			link.l1 = "Il s'appelle Thomas Petit ! Ce gamin m'a joué toute une comédie à propos de sa fiancée enlevée, il m'a traîné jusqu'à ses complices, et ils ont menacé de m'éventrer si je ne payais pas !";
			link.l1.go = "TohmasPetit_OfficerRefusal_2";
		break;

		case "TohmasPetit_OfficerRefusal_2":
			dialog.text = "Ah, monsieur Thomas... Je suis obligé de vous décevoir, capitaine, mais vous êtes loin d'être le premier à venir me raconter ce genre d'histoires. C'est toujours la même chanson : vous autres, chanceux gentilshommes de la mer, vous croyez le premier venu sur le port, et ensuite vous courez au bureau du commandant pour exiger justice.";
			link.l1 = "Vous ne comprenez pas ! On m'a dévalisé en plein jour, sous votre nez ! Vous devez envoyer une patrouille dans la jungle et mettre sa tête à prix !";
			link.l1.go = "TohmasPetit_OfficerRefusal_3";
		break;

		case "TohmasPetit_OfficerRefusal_3":
			dialog.text = "Je ne dois rien à personne, capitaine. Mon travail consiste à commander ce fort, à surveiller les poudrières et à préparer la garnison à un éventuel siège, pas à pourchasser le moindre escroc à travers la jungle. Réglez vous-même vos comptes avec ceux qui vous ont fait du tort. Maintenant, vous pouvez disposer, j'ai beaucoup de travail.";
			link.l1 = "Je vois... Inutile d'attendre de l'aide des autorités locales. Eh bien, je trouverai un moyen de reprendre ce qui m'appartient.";
			link.l1.go = "exit";
			AddQuestRecord("TohmasPetit", "OfficerRefused");
			DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search.ToOfficer");
			pchar.QuestTemp.TohmasPetit_Search = "active";
			pchar.QuestTemp.TohmasPetit_Search.Path = "near_left";
		break;
	}
}

void GetChestPlaceName()
{
	string islandId;
	int iTemp = rand(4);
	switch (iTemp)
	{
		case 0:
			pchar.questTemp.jailCanMove.islandId = "Bermudes";
			pchar.questTemp.jailCanMove.placeId = "Bermudes_Cavern";
		break;
		case 1:
			pchar.questTemp.jailCanMove.islandId = "Caiman";
			pchar.questTemp.jailCanMove.placeId = "Caiman_Grot";
		break;
		case 2:
			pchar.questTemp.jailCanMove.islandId = "Dominica";
			pchar.questTemp.jailCanMove.placeId = "Dominica_Grot";
		break;
		case 3:
			pchar.questTemp.jailCanMove.islandId = "Terks";
			pchar.questTemp.jailCanMove.placeId = "Terks_Grot";
		break;
		case 4:
			pchar.questTemp.jailCanMove.islandId = "StLucia";
			pchar.questTemp.jailCanMove.placeId = "StLucia_Grot";
		break;
	}
}

string GetBanderLocation(ref npchar)
{
    aref	arCommon, arRld, arRld2;
    int	i, n, Qty, Qty2;
	string LocId;
	string	storeArray [50];
	int howStore = 0;
    makearef(arRld, Locations[FindLocation(npchar.city + "_town")].reload);
	Qty = GetAttributesNum(arRld);
    if (CheckAttribute(pchar, "GenQuest.SeekSpy.Location")) //если взят квест мэра по поиску шпиона
	{
		for (i=0; i<Qty; i++)
		{
    		arCommon = GetAttributeN(arRld, i);
			LocId = arCommon.go;
    		if (findsubstr(LocId, "Common" , 0) != -1 && LocId != pchar.GenQuest.SeekSpy.Location)
    		{
				storeArray[howStore] = LocId;
				howStore++;
			}
			if (arCommon.label != "Sea")
			{
				makearef(arRld2, Locations[FindLocation(LocId)].reload);
				Qty2 = GetAttributesNum(arRld2);
				for (n=0; n<Qty2; n++)
				{
    				arCommon = GetAttributeN(arRld2, n);
					LocId = arCommon.go;
					if (findsubstr(LocId, "Common" , 0) != -1 && LocId != pchar.GenQuest.SeekSpy.Location)
    				{
						storeArray[howStore] = LocId;
						howStore++;
					}
				}
			}
		}
	}
	else
	{
		for (i=0; i<Qty; i++)
		{
    		arCommon = GetAttributeN(arRld, i);
			LocId = arCommon.go;
    		if (findsubstr(LocId, "Common" , 0) != -1)
    		{
				storeArray[howStore] = LocId;
				howStore++;
			}
			if (arCommon.label != "Sea")
			{
				makearef(arRld2, Locations[FindLocation(LocId)].reload);
				Qty2 = GetAttributesNum(arRld2);
				for (n=0; n<Qty2; n++)
				{
    				arCommon = GetAttributeN(arRld2, n);
					LocId = arCommon.go;
					if (findsubstr(LocId, "Common" , 0) != -1)
    				{
						storeArray[howStore] = LocId;
						howStore++;
					}
				}
			}
		}
	}
	if (howStore == 0) return "none";
	LocId = storeArray[rand(howStore-1)];
	SetOpenDoorCommonLoc(npchar.city, LocId); //открываем дверь
	for(n=0; n<MAX_CHARACTERS; n++)
	{
		if (CheckAttribute(&characters[n], "locations") && characters[n].locations == LocId)
		{
			characters[n].lifeDay = 0;
		}
	}
	return LocId;
}

string GenQuestPrison_GenerateArtefact() // артефакты
{
	string itemID;
	switch(rand(8))
	{
		case 0:
			itemID = "indian6";
		break;
		case 1:
			itemID = "indian10";
		break;
		case 2:
			itemID = "indian12";
		break;
		case 3:
			itemID = "indian19";
		break;
		case 4:
			itemID = "indian20";
		break;
		case 5:
			itemID = "indian22";
		break;
		case 6:
			itemID = "indian21";
		break;
		case 7:
			itemID = "sculMa2";
		break;
		case 8:
			itemID = "sculMa1";
		break;

	}
	return itemID;
}

string GenQuestPrison_GenerateBlade() // клинки и другое
{
	string itemID;
	switch(rand(8))
	{
		case 0:
			itemID = GetGeneratedItem("blade22");
		break;
		case 1:
			itemID = GetGeneratedItem("blade19");
		break;
		case 2:
			itemID = GetGeneratedItem("blade31");
		break;
		case 3:
			itemID = "cirass3";
		break;
		case 4:
			itemID = GetGeneratedItem("blade21");
		break;
		case 5:
			itemID = "spyglass4";
		break;
		case 6:
			itemID = GetGeneratedItem("blade15");
		break;
		case 7:
			itemID = GetGeneratedItem("blade34");
		break;
		case 8:
			itemID = "cirass4";
		break;

	}
	return itemID;
}

void GetGunType()
{
		int iGunType;
		ref rCannon;
		if(makeint(pchar.rank) < 5) { iGunType = rand(1); }	//24
		if(makeint(pchar.rank) >= 6 && makeint(pchar.rank) < 13) { iGunType = rand(3); } //24&&32
		if(makeint(pchar.rank) >= 13 && makeint(pchar.rank) < 20) { iGunType = rand(2)+2; } //32&&42
		if(makeint(pchar.rank) >= 20) { iGunType = 4; } //42

		switch (iGunType)
		{
			case 0:
				pchar.questTemp.PrisonGun.Goods = GOOD_CANNON_24;
				rCannon = GetGoodByType(GOOD_CANNON_24);
				pchar.questTemp.PrisonGun.Price = sti(rCannon.Cost) + 175*GetCharacterSPECIALSimple(PChar, SPECIAL_C)*GetSummonSkillFromName(pchar, SKILL_COMMERCE)/200;
                pchar.questTemp.PrisonGun.Qty = sti(makeint(pchar.rank)*5+30+rand(sti(pchar.rank)));
				pchar.questTemp.PrisonGun.Text = "canons de 24";
			break;
			case 1:
				pchar.questTemp.PrisonGun.Goods = GOOD_CULVERINE_24;
				rCannon = GetGoodByType(GOOD_CULVERINE_24);
				pchar.questTemp.PrisonGun.Price = sti(rCannon.Cost) + 225*GetCharacterSPECIALSimple(PChar, SPECIAL_C)*GetSummonSkillFromName(pchar, SKILL_COMMERCE)/200;
                pchar.questTemp.PrisonGun.Qty = sti(makeint(pchar.rank)*5+20+rand(sti(pchar.rank)));
				pchar.questTemp.PrisonGun.Text = "couleuvrines de 24";
			break;
			case 2:
				pchar.questTemp.PrisonGun.Goods = GOOD_CANNON_32;
				rCannon = GetGoodByType(GOOD_CANNON_32);
				pchar.questTemp.PrisonGun.Price = sti(rCannon.Cost) + 275*GetCharacterSPECIALSimple(PChar, SPECIAL_C)*GetSummonSkillFromName(pchar, SKILL_COMMERCE)/200;
                pchar.questTemp.PrisonGun.Qty = sti(makeint(pchar.rank)*4+10+rand(sti(pchar.rank)));
				pchar.questTemp.PrisonGun.Text = "canons de 32";
			break;
			case 3:
				pchar.questTemp.PrisonGun.Goods = GOOD_CULVERINE_32;
				rCannon = GetGoodByType(GOOD_CULVERINE_32);
				pchar.questTemp.PrisonGun.Price = sti(rCannon.Cost) + 325*GetCharacterSPECIALSimple(PChar, SPECIAL_C)*GetSummonSkillFromName(pchar, SKILL_COMMERCE)/200;
                pchar.questTemp.PrisonGun.Qty = sti(makeint(pchar.rank)*4+10+rand(sti(pchar.rank)));
				pchar.questTemp.PrisonGun.Text = "couleuvrines de 32";
			break;
			case 4:
				pchar.questTemp.PrisonGun.Goods = GOOD_CANNON_42;
				rCannon = GetGoodByType(GOOD_CANNON_42);
				pchar.questTemp.PrisonGun.Price = sti(rCannon.Cost) + 425*GetCharacterSPECIALSimple(PChar, SPECIAL_C)*GetSummonSkillFromName(pchar, SKILL_COMMERCE)/200;
                pchar.questTemp.PrisonGun.Qty = sti(makeint(pchar.rank)*3+20+rand(sti(pchar.rank)));
				pchar.questTemp.PrisonGun.Text = "canons de 42";
			break;
		}
}
