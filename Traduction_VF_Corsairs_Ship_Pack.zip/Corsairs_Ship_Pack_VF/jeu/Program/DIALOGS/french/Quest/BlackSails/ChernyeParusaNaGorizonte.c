
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "BS_CPNG_1":	//Бармен
			dialog.text = "Hé, ce ne serait pas toi que cherche notre espoir et notre soutien, la radieuse Mlle Guthrie ?";
			link.l1 = "Oh, mon Dieu ! Qu'est-ce que c'est, cette fois ?";
			link.l1.go = "BS_CPNG_2";
		break;

		case "BS_CPNG_2":
            dialog.text = "Aucune idée. Mais son messager a beaucoup insisté pour qu'on dise au capitaine "+pchar.name+" qu'on l'attend à la résidence Guthrie, aux Bahamas. Et si j'étais ce capitaine, je ne traînerais pas.";
            link.l1 = "D'accord, compris...";
			link.l1.go = "exit";
		break;

		//Багамы, перед магазином сценка. Гатри орёт на кучку пиратских кэпов. (штук 5-6 неписей Кэпов)

		case "BS_CPNG_3":	//Гатри
            dialog.text = "Monsieur Fix ! Le tabac a de la valeur quand il n'est pas imbibé d'urine ! Si vous ou votre second n'êtes pas capables de faire régner une discipline correcte sur le navire, je peux facilement vous trouver un remplaçant !";
            link.l1 = "";
			link.l1.go = "BS_CPNG_4_1";
		break;

		case "BS_CPNG_4_1":
            npchar.name = "Fix";
			npchar.lastname = "";
			NextDiag.CurrentNode = "BS_CPNG_4";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_4":	//Фикс
            dialog.text = "Mademoiselle Guthrie ! Avec tout le respect que je vous dois, c'est mon navire, et je...";
            link.l1 = "";
			link.l1.go = "BS_CPNG_5_1";
		break;

		case "BS_CPNG_5_1":
            npchar.name = "Eleanor";
			npchar.lastname = "Guthrie";
			NextDiag.CurrentNode = "BS_CPNG_5";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_5":	//Гатри
            dialog.text = "Prevon ! Vous êtes désormais capitaine du « Renard ». Prenez le commandement !";
            link.l1 = "";
			link.l1.go = "BS_CPNG_6_1";
		break;

		case "BS_CPNG_6_1":
            npchar.name = "Fix";
			npchar.lastname = "";
			NextDiag.CurrentNode = "BS_CPNG_6";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_6":	//Фикс
            dialog.text = "Je... Comment os... Je ne vais pas en rester là !";	//уходит
            link.l1 = "";
			link.l1.go = "BS_CPNG_7_1";
		break;

		case "BS_CPNG_7_1":
            npchar.name = "Eleanor";
			npchar.lastname = "Guthrie";
			NextDiag.CurrentNode = "BS_CPNG_7";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_7":	//Гатри
            dialog.text = "Ah, te voilà. Juste à temps. Bien, messieurs, faisons une courte pause. Nous reprendrons plus tard.";	//остальные уходят
            link.l1 = "";
			link.l1.go = "BS_CPNG_8";
		break;

		case "BS_CPNG_8":	//Гатри
			chrDisableReloadToLocation = false;
            dialog.text = "J'ai une affaire. Avantageuse pour nous deux ; continuons dans mon salon.";	//Релоад в дом Гатри, первый этаж.
            link.l1 = "Allons-y.";
			link.l1.go = "BS_CPNG_9_1";
		break;

		case "BS_CPNG_9_1":	//Гатри
			PChar.quest.Gatri_upstairs.win_condition.l1 = "location";
			PChar.quest.Gatri_upstairs.win_condition.l1.location = "Nassau_OfisGatri";
			PChar.quest.Gatri_upstairs.function = "Gatri_upstairs";
			NextDiag.CurrentNode = "BS_CPNG_9";
			DialogExit();
			ChangeCharacterAddressGroup(npchar, "Nassau_OfisGatri", "quest", "quest5");
            DoReloadCharacterToLocation("Nassau_OfisGatri","officers","reload1_3");
		break;

		case "BS_CPNG_9":	//Гатри
            dialog.text = "וcoute bien !";
            link.l1 = "Une minute. Pourquoi ce tutoiement, tout à coup ? Et que s'est-il passé pour qu'on ait besoin de mes services en particulier ? Je vois que les affaires vont bon train, ici : voyez combien de capitaines sont suspendus à vos lèvres.";
			link.l1.go = "BS_CPNG_10";
		break;

		case "BS_CPNG_10":
            dialog.text = "Un style plus formel vous conviendrait-il mieux ? Votre Seigneurie est offensée qu'on la tutoie ? Au diable les formalités ! J'ai une affaire. Urgente et très lucrative, et les Guthrie n'ont pas l'habitude de laisser passer ce genre d'occasion ! Tu arrives à suivre ?";
			link.l1 = "Je suis tout ouïe.";
			link.l1.go = "BS_CPNG_11"
		break;

		case "BS_CPNG_11":
            dialog.text = "Bien. J'ai un ami. Plus qu'un ami. Presque un père. Le capitaine Flint. Tu as entendu parler de lui ?";
            link.l1 = "Flint. דa alors. On fait peur aux enfants avec son nom jusqu'en Asie.";
			link.l1.go = "BS_CPNG_12";
		break;

		case "BS_CPNG_12":
            dialog.text = "Tu n'as rien à craindre. Et sa réputation est bien méritée : c'est un homme très cruel et très rationnel, mais juste, et qui sait apprécier l'amitié.\n"+
							"Voilà donc. Il s'est lancé dans une entreprise qui pourrait enrichir tous ceux qui y participent ou, au contraire, les ruiner. Et je veux que les choses tournent dans le bon sens, et j'ai l'intention d'aider de toutes les manières possibles.";
            link.l1 = "Et quel est mon rכle dans ce scénario ?";
			link.l1.go = "BS_CPNG_13";
		break;

		case "BS_CPNG_13":
            dialog.text = "Trouve-le en mer. Retiens bien ceci, c'est très important : tu dois être sous pavillon noir au moment de la rencontre ! Quand tu le verras, dis-lui que toi aussi, tu as lu Marc Aurèle. C'est le mot de passe. Il te dira le reste.";
            link.l1 = "Et oם trouver Flint ?";
			link.l1.go = "BS_CPNG_14";
		break;

		case "BS_CPNG_14":
            dialog.text = "Difficile à dire. Il ne fait escale que dans les criques de pirates, et jamais longtemps. Cherche-le en mer.";
            link.l1 = "א bientכt.";			
			link.l1.go = "BS_CPNG_14_exit";			
		break;
		
		case "BS_CPNG_14_exit":
			DialogExit();			
			DeleteAttribute(PChar, "currentsoundtrack");
			DeleteAttribute(npchar, "talker");
			LAi_LocationFightDisable(&Locations[FindLocation("Nassau_town")], false);
			AddQuestRecord("BSOnTheHorizon", "2");
			BSOnTheHorizon_Flint();
			SaveCurrentQuestDateParam("GatriSalutation");
			npchar.Dialog.FileName = "Quest\BlackSails\NePluyjVKolodec.c";
			npchar.dialog.currentnode = "BS_NPVK_20_meet";			
			DoReloadCharacterToLocation("Nassau_town", "reload", "houseS1");
		break;

		//Запись в сж, та же, что и теперь. Для сибиряка и прочих умственно отсталых, можно продублировать правильный пролог там. но я бы не стал 6.04.2023
		//После диалога запускаем по глобалке модельку БОЛЬШУЮ пиратскую( или фиолетовый квестовик), который курсирует между ПИРАТСКИМИ портами.
		//Под пиратским флагом – всё ОК. под любым другим – файт и провал квеста.
		//Флинт на Тяжёлом военном пинасе «Морж». Высылаем шлюпку. Говорим.

		case "BS_CPNG_15":	//Флинт
            dialog.text = "Je connais ce navire, mais c'est la première fois que je vois son capitaine. Présentez-vous.";
            link.l1 = "Je suis "+GetFullName(pchar)+". Mlle Guthrie m'a demandé de vous trouver, capitaine Flint.";
			link.l1.go = "BS_CPNG_16";
		break;

		case "BS_CPNG_16":
            dialog.text = "Je connais Mlle Guthrie et son père, mais quel est votre lien avec eux, et avec moi ?";

			//это такая засада.. чтобы читали текст :)
			MakeRandomLinkOrderThree(link,
			"Moi aussi, j'ai lu Marc Aurèle, j'admire beaucoup son œuvre, et je veux bien apporter tout le soutien et toute l'aide possibles à quelqu'un qui pense comme moi.",
			"BS_CPNG_17_Horosho",

			"Moi aussi, j'ai lu Marc Antoine, j'admire beaucoup son œuvre, et je veux bien apporter tout le soutien et toute l'aide possibles à quelqu'un qui pense comme moi.",
			"BS_CPNG_17_Ploho",

			"J'ai entendu dire que le légendaire Flint avait besoin d'aide pour une aventure. Et me voici !",
			"BS_CPNG_17_Ploho"
			);
		break;

		case "BS_CPNG_17_Ploho":
            DeleteAttribute (npchar, "AlwaysFriend");
			npchar.AlwaysEnemy = true;
			dialog.text = "Je ne sais pas qui vous êtes, et je vous suggère de quitter mon navire.";
            link.l1 = "Euh, euh... Au revoir.";
			NextDiag.TempNode = "BS_CPNG_17_Ploho_end";
			link.l1.go = "exit";
		break;

		case "BS_CPNG_17_Ploho_end":
            dialog.text = "Quittez mon navire immédiatement !";
            link.l1 = "Inutile d'être grossier, j'allais partir.";
			NextDiag.TempNode = "BS_CPNG_17_Ploho_end";
			link.l1.go = "exit";
		break;

		case "BS_CPNG_17_Horosho":
			PChar.quest.MeetFlintCrew.win_condition.l1 = "location";
			PChar.quest.MeetFlintCrew.win_condition.l1.location = "Nassau_town";
			PChar.quest.MeetFlintCrew.function = "MeetFlintCrew";
            dialog.text = "Il vaut mieux parler de ça loin des oreilles indiscrètes. Je vais régler quelques affaires et je me rendrai aux Bahamas, nous en parlerons là-bas.";
			npchar.StopSailing = true;
			AddQuestRecord("BSOnTheHorizon", "3");
            link.l1 = "Très bien, à bientכt.";
			NextDiag.TempNode = "BS_CPNG_17_Horosho_end";
			link.l1.go = "exit";
		break;

		case "BS_CPNG_17_Horosho_end":
            dialog.text = "Retournez sur votre navire, ne perdons plus de temps.";
            link.l1 = "Vous avez raison, j'y vais.";
			NextDiag.TempNode = "BS_CPNG_17_Horosho_end";
			link.l1.go = "exit";
		break;

		//Бвнвмы. На берегу Флинт, Сильвер, Бонс.

		case "BS_CPNG_18":	//Флинт
            dialog.text = "Je vous présente : mon second, Billy Bones, et le quartier-maître, John Silver.";
            link.l1 = "C'est un plaisir de vous rencontrer. Je suis "+GetFullName(pchar)+". Mlle Guthrie nous attend déjà ; je pense qu'il ne faut pas la faire attendre.";
			link.l1.go = "BS_CPNG_19";
		break;

		case "BS_CPNG_19":
            dialog.text = "Oui, ce n'est pas poli de faire attendre une dame. Surtout cette dame-là ! Allons-y, je veux mettre les points sur les i.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_19_exit";	//Переход в дом на первый этаж. Гатри, Флинт, ГГ.
		break;

		case "BS_CPNG_19_exit":
			sld = CharacterFromID("Gatri_temp");
			sld.dialog.filename = "Quest\BlackSails\ChernyeParusaNaGorizonte.c";
			sld.dialog.currentnode = "BS_CPNG_20";
			sld.talker = 10;
			DialogExit();
			SetFunctionLocationCondition("BS_GatryFlintInHouseDialogue", "Nassau_OfisGatri", false);
            StartReloadToCobHouse();
		break;

		case "BS_CPNG_20":	//Гатри
            dialog.text = "James, c'est moi qui te l'ai envoyé. Ce n'est pas quelqu'un qui cherche juste du butin : ce capitaine te ressemble, si tu vois ce que je veux dire.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_21_1";
		break;

		case "BS_CPNG_21_1":
			NextDiag.CurrentNode = "BS_CPNG_21";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_21":	//Флинт
			npchar.name = GetConvertStrWithReplace("Variable_black_sails_functions_6", "Names.txt", "#space#", " ");
			npchar.lastname = GetConvertStrWithReplace("Variable_black_sails_functions_7", "Names.txt", "#space#", " ");
            dialog.text = "Je vois un esprit aventureux, un capitaine expérimenté, avec un beau navire et un équipage bien entraîné. Je me trompe très rarement, Eleanor, tu le sais. Tu te portes garante de ce capitaine ?";
            link.l1 = "";
			link.l1.go = "BS_CPNG_22_1";
		break;

		case "BS_CPNG_22_1":
            npchar.name = GetConvertStrWithReplace("Variable_black_sails_functions_2", "Names.txt", "#space#", " ");
			npchar.lastname = GetConvertStrWithReplace("Variable_black_sails_functions_3", "Names.txt", "#space#", " ");
			NextDiag.CurrentNode = "BS_CPNG_22";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_CPNG_22":	//Гатри
            dialog.text = "Nous avons eu nos désaccords, mais tout s'est arrangé. Et si mon île est à moi, c'est grâce à "+ GetSexPhrase("lui","elle") +". Oui, je me porte garante de ce capitaine.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_23_1";
		break;

		case "BS_CPNG_23_1":
			sld = CharacterFromID("Flint");
			sld.dialog.currentnode = "BS_CPNG_23";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_CPNG_23":	//Флинт
            dialog.text = "Bien, passons maintenant à l'affaire.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_24";
		break;

		case "BS_CPNG_24":	//Флинт
            dialog.text = "Alors, capitaine "+GetFullName(pchar)+". Avez-vous entendu parler de l'Urca de Lima ? Ce galion espagnol chargé de monnaie, qui transporte non pas du minerai d'or, mais des doublons d'or déjà frappés ?";
            link.l1 = "Mmm... J'avoue avoir entendu des rumeurs sur cette forteresse flottante. Pas même des rumeurs, plutכt des spéculations et des racontars, selon lesquels ce galion transporterait quasiment le trésor de l'Escurial. Seulement, la « Flotte de l'or », beaucoup de gens l'ont vue, mais l'Urca, personne ne l'a jamais vue !";
			link.l1.go = "BS_CPNG_25";
		break;

		case "BS_CPNG_25":
            dialog.text = "L'Urca de Lima est un sacré morceau, c'est vrai. Et je sais oם et quand ce galion refera ses provisions d'eau et de vivres pour le voyage vers l'Espagne. C'est l'occasion rêvée d'en venir à bout.";
            link.l1 = "Et quel est l'enjeu ?";
			link.l1.go = "BS_CPNG_26";
		break;

		case "BS_CPNG_26":
            dialog.text = "Cent cinquante millions de pesos !";
            link.l1 = "Mère de Dieu !";
			link.l1.go = "BS_CPNG_27";
		break;

		case "BS_CPNG_27":
            dialog.text = "Vous en êtes ? Oui ou non ? Sinon, vous savez comment cette rencontre va se terminer.";
            link.l1 = "Bien sמr que j'en suis ! Oם, comment et quand ?!";
			link.l1.go = "BS_CPNG_28";
		break;

		case "BS_CPNG_28":
			chrDisableReloadToLocation = false;
            dialog.text = "Nous allons le demander à M. Silver, s'il n'est pas déjà ivre mort.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_28_exit";	//Спускаемся вниз. За столом Бонс и Сильвер.
		break;

		case "BS_CPNG_28_exit":
			PChar.quest.Silver_Downstairs.win_condition.l1 = "location";
			PChar.quest.Silver_Downstairs.win_condition.l1.location = "Nassau_tavern";
			PChar.quest.Silver_Downstairs.function = "Silver_Downstairs";
			NextDiag.CurrentNode = "BS_CPNG_24";
			DialogExit();           
			FreeSitLocator("Nassau_tavern", "sit_front2");
			FreeSitLocator("Nassau_tavern", "sit_base2");
			FreeSitLocator("Nassau_tavern", "sit_base1");
			FreeSitLocator("Nassau_tavern", "sit2");
			pchar.currentsoundtrack = "All_Saints";
			DoReloadCharacterToLocation("Nassau_tavern","sit", "sit_front2");
			ChangeCharacterAddressGroup(npchar, "Nassau_tavern", "sit", "sit_base2");
			LAi_SetSitType(npchar);
			LAi_SetSitType(pchar);
			sld = CharacterFromID("BS_Billy");
			ChangeCharacterAddressGroup(sld, "Nassau_tavern", "sit", "sit_base1");
			LAi_SetSitTypeNoGroup(sld);
			LAi_CharacterDisableDialog(sld);
			sld = CharacterFromID("BS_Silver");
			sld.dialog.filename = "Quest\BlackSails\ChernyeParusaNaGorizonte.c";
			sld.dialog.currentnode = "BS_CPNG_29";
			ChangeCharacterAddressGroup(sld, "Nassau_tavern", "sit", "sit2");
			LAi_SetSitType(sld);
			sld = CharacterFromID("gatri_temp");
			ChangeCharacterAddressGroup(sld, "Nassau_tavern", "tables", "stay3");
		break;

		case "BS_CPNG_29":	//Сильвер
            dialog.text = "...";
            link.l1 = "Monsieur Silver ? Je travaille désormais avec le capitaine Flint ; il est grand temps de partager vos informations !";
			link.l1.go = "BS_CPNG_30";
		break;

		case "BS_CPNG_30":
            dialog.text = "Salutations, capitaine ! Que pensez-vous des bordels coloniaux du coin ?";
            link.l1 = "...";
			link.l1.go = "BS_CPNG_30_flint_1";
		break;

		case "BS_CPNG_30_flint_1":
			sld = CharacterFromID("Flint");
			sld.dialog.currentnode = "BS_CPNG_30_flint";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_CPNG_30_flint":
            dialog.text = "Pas de plaisanteries !";
            link.l1 = "...";
			link.l1.go = "BS_CPNG_31_1";
		break;

		case "BS_CPNG_31_1":
			sld = CharacterFromID("BS_Silver");
			sld.dialog.currentnode = "BS_CPNG_31";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;

		case "BS_CPNG_31":
            dialog.text = "Je n'ai jamais été aussi sérieux ! Je n'ai qu'une partie du code de l'itinéraire chiffré ! Le capitaine Vane a le reste.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_32_1";
		break;

		case "BS_CPNG_32_1":
			sld = CharacterFromID("Gatri_temp");
			sld.dialog.currentnode = "BS_CPNG_32_gatri";
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\ChernyeParusaNaGorizonte.c";
			sld.talker = 10;
			DialogExit();
		break;

		case "BS_CPNG_32_gatri":
			LAi_SetActorTypeNoGroup(npchar);
            dialog.text = "Charles Vane ! Maudit soit-il ! Comment ! Grrr !!!";
            link.l1 = "";
			link.l1.go = "BS_CPNG_32_flint_1";
		break;

		case "BS_CPNG_32_flint_1":
			sld = CharacterFromID("Flint");
			sld.dialog.currentnode = "BS_CPNG_32_flint";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_CPNG_32_flint":
			SetCompanionIndex(PChar, -1, GetCharacterIndex(npchar.id));//Флинт присоединяется к эскадре
			Flag_Change(PIRATE);
			ProcessHullRepair(npchar, 100.0);
			ProcessSailRepair(npchar, 100.0);
			DeleteAttribute(npchar, "ship.blots");
			DeleteAttribute(npchar, "ship.sails");
			RepairMasts(npchar);
			SetShipRemovable(npchar, false);
			SetCharacterRemovable(npchar, false);
			Fantom_SetBalls(npchar, "war");
			SetCharacterGoods(npchar, GOOD_FOOD, 2900);
            dialog.text = "Calme-toi, Eleanor. Monsieur Silver, oם avez-vous vu Vane pour la dernière fois ?";
            link.l1 = "";
			link.l1.go = "BS_CPNG_32_silver_1";
		break;

		case "BS_CPNG_32_silver_1":
			sld = CharacterFromID("BS_Silver");
			sld.dialog.currentnode = "BS_CPNG_32_silver";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;

		case "BS_CPNG_32_silver":
            dialog.text = "Hé. Je vous l'ai déjà dit, mais vous n'écoutiez pas. Dans un bordel de la Martinique.";
            link.l1 = "";
			link.l1.go = "BS_CPNG_33";
		break;

		case "BS_CPNG_33":
			LAi_CharacterDisableDialog(npchar);
			sld = CharacterFromID("Flint");
			sld.dialog.currentnode = "BS_CPNG_Final";

            dialog.text = "";
            link.l1 = "J'adore déjà le début de cette aventure ! En route !";
			link.l1.go = "BS_CPNG_33_exit";
		break;

		case "BS_CPNG_33_exit":		
			SetFunctionExitFromLocationCondition("BS_OnTheHorizonTavernExit", pchar.location, false);
			DeleteAttribute(PChar, "currentsoundtrack");
			BSOnTheHorizon_SeaBattle();
			PChar.quest.BattleSeaDefenceColonyWinner.win_condition.l1 = "Group_Death";
			PChar.quest.BattleSeaDefenceColonyWinner.win_condition.l1.group = "Sea_BSOnTheHorizon_SeaBattle1";
			PChar.quest.BattleSeaDefenceColonyWinner.function = "BSOnTheHorizon_End";
			pchar.quest.BSCourtlyPassions_DontStart.win_condition.c1 = "NPC_Death";
			pchar.quest.BSCourtlyPassions_DontStart.win_condition.c1.character ="Flint";
			PChar.quest.BSCourtlyPassions_DontStart.function = "BSCourtlyPassions_DontStart";
			AddQuestRecord("BSOnTheHorizon", "4");
			InterfaceStates.Buttons.Save.enable = true;
			ChangeCharacterAddressGroup(pchar, "Nassau_tavern", "tables", "stay4");
			LAi_SetPlayerType(pchar);
			DialogExit();
		break;

		case "BS_CPNG_Final":
			dialog.text = "Nous allons boire encore une ou deux chopes avant d'appareiller.";
			NextDiag.TempNode = "BS_CPNG_Final";
            link.l1 = "Ne soyez pas en retard.";
			link.l1.go = "exit";
			if (npchar.id == "Gatri_temp")
			{
				dialog.text = "Bon vent, capitaine.";
				link.l1 = "Merci.";
				link.l1.go = "exit";
			}
			if (npchar.id == "Flint")
			{
				dialog.text = "Ne traînons pas.";
				link.l1 = "J'accepte.";
				link.l1.go = "exit";
			}
		break;

		//Выходим в море. В эскадре – Флинт на «Морже».
		//На глобалке, на подходе к Мартинике – энка английский патруль.
		//Файт. (4-6 второклассников). Квест уходит в архив (СЖ: «На подходе к Мартинике нарвались на патруль англичан. Вода вам пухом, саксы. Хе хе».)

	}
}
