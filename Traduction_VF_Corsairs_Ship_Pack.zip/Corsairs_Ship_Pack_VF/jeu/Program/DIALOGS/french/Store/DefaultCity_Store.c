// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Je vous écoute, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);
}

