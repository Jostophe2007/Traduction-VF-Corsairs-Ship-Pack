void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	ref _location;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		
////////////////////////////////////////////////////////////////////////////////////////////////
// Анжелика Тич: "Dreams come true"			Авторы: Nikk и Sinistra
////////////////////////////////////////////////////////////////////////////////////////////////			
		
		case "First time":
			dialog.text = "";
			link.l1 = "Becky, cette chambre va bientכt se transformer en cellule.";
			link.l1.go = "Rebekka_v_komnate_2";
		break;
		
		case "Rebekka_v_komnate_2":
			dialog.text = "Ne commence pas, je sais déjà comment notre conversation va encore finir.";
			link.l1 = "Je suis passée au port, il y a un navire de La Havane. Militaire... Un nouveau commandant est arrivé, nommé pour prendre la place de notre père. J'ai pu lui parler et lui décrire sans détour la situation difficile dans laquelle nous nous trouvons.";
			link.l1.go = "Rebekka_v_komnate_3";
		break;
		
		case "Rebekka_v_komnate_3":
			dialog.text = "Je ne pense pas que ce soit très délicat de ta part. Il aurait fallu d'abord l'inviter à dîner : après tout, cette maison sera bientכt la sienne. Nous lui aurions montré les pièces, réglé la question des meubles et de certaines affaires.";
			link.l1 = "On aura le temps ! Le commandant a eu la bonté de nous accorder un délai de quatre mois entiers. Quatre fichus mois pour te trouver un parti, et je serai tranquille quant à ton sort, sœurette.";
			link.l1.go = "Rebekka_v_komnate_4";
		break;
		
		case "Rebekka_v_komnate_4":
			dialog.text = "Tiens, cette fois, ton préambule a été plus court que jamais avant d'en venir au fait.";
			link.l1 = "Il y a assez de candidats sur le navire. De jeunes officiers en vue sont aussi présents à la parade ! Deux ou trois de ceux qui sont descendus de la première chaloupe sont de très beaux garçons. Allons nous faire remarquer avant qu'ils ne se cachent dans leurs terriers de caserne pour fuir la chaleur de midi.";
			link.l1.go = "Rebekka_v_komnate_5";
		break;
		
		case "Rebekka_v_komnate_5":
			dialog.text = "Trouve-toi quelqu'un, toi aussi...";
			link.l1 = "";
			link.l1.go = "Rebekka_v_komnate_5_1";
		break;
		
		case "Rebekka_v_komnate_5_1":
			dialog.text = "";
			link.l1 = "Non, je compte enfin quitter ce trou dès que je t'aurai mise en de bonnes mains. Ce n'est pas pour rien que j'ai appris l'art de la navigation et la lecture des cartes ces dernières années, non ? Je m'engagerai comme navigatrice sur un navire, je partirai à l'aventure. Ha ha ! J'ai plus de chances de devenir navigatrice que ces jeunes aristocrates illettrés qui ont le mal de mer rien qu'en regardant le pont.";
			link.l1.go = "Rebekka_v_komnate_6";
			locCameraFromToPos(1.00, 3.50, 9.00, false, -15.00, -5.70, 38.25);
		break;
		
		case "Rebekka_v_komnate_6":
			dialog.text = "Angelica, l'un de ces jeunes aristocrates illettrés sera sans doute mon futur mari, tu ne crois pas ? Et toi, tu irais plutכt au-devant de la mort que de l'aventure. Tu es une femme, et...";
			link.l1 = "Hé ! C'est le sang des Teach qui coule dans mes veines, pas celui des Remedios ! N'oublie pas qui est mon vrai père.";
			link.l1.go = "Rebekka_v_komnate_7";
		break;
		
		case "Rebekka_v_komnate_7":
			dialog.text = "Bien sמr que je m'en souviens. Ma belle-mère la sirène, qui a échangé ses jambes contre une voix, a raconté plus d'une fois cette histoire : comment tu n'as pas posé le pied sur la terre ferme pendant près d'un an, à parcourir l'archipel en quête de proies.";
			link.l1 = "Vraiment, comme c'est amusant. Si tu racontes notre parabole à ton futur cavalier avec les mêmes mots, il appréciera sמrement non seulement ta beauté, mais aussi ta vivacité d'esprit.";
			link.l1.go = "Rebekka_v_komnate_8";
		break;
		
		case "Rebekka_v_komnate_8":
			dialog.text = "C'est toi qui as commencé cette conversation.";
			link.l1 = "Et je vais la finir. Rattrape-moi.";
			link.l1.go = "Rebekka_v_komnate_9";
		break;
		
		case "Rebekka_v_komnate_9":
			DialogExit();
			EndQuestMovie();
			bDisableCharacterMenu = false;
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
			
			SetQuestHeader("AT_Mechty_Sbivautsya");
			AddQuestRecord("AT_Mechty_Sbivautsya", "0.1");
			
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorFollowEverywhere(sld, "", -1);
			
			PChar.quest.At_pr_Rebekka_gulyat.win_condition.l1 = "location";
			PChar.quest.At_pr_Rebekka_gulyat.win_condition.l1.location = "LaVega_town";
			PChar.quest.At_pr_Rebekka_gulyat.function = "At_pr_Rebekka_gulyat";
			
			sld = CharacterFromID("Edward Mansfield")
			ChangeCharacterAddressGroup(sld, "LaVega_town", "none", "");
			
			//Испанский губернатор
			sld = GetCharacter(NPC_GenerateCharacter("AT_pr_LaVegaIspanski_Gubernator", "SpaOfficer1", "man", "man", 15, SPAIN, -1, true));
			FantomMakeCoolFighter(sld, 100, 100, 100, "blade20", "howdah", 500);
			sld.name	= "Aurelio";
			sld.lastname	= "Serrano";
			sld.SaveItemsForDead = true;
			sld.Dialog.Filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "LaVegaIspanski_Gubernator";
			LAi_SetHuberType(sld);
			LAi_SetImmortal(sld, true);
			DeleteAttribute(sld, "items");
			AddMoneyToCharacter(sld, 12345);
			GiveItem2Character(sld, "blade19");
			EquipCharacterByItem(sld, "blade19");
			GiveItem2Character(sld, "BackPack2");
			GiveItem2Character(sld, "talisman6");
			AddItems(sld, "jewelry4", 30);
			ChangeCharacterAddressGroup(sld, "LaVega_townhall", "sit", "sit1");
			
			//Торговец на улице (продолжение квеста)
			FreeSitLocator("LaVega_town", "protector2");
			sld = GetCharacter(NPC_GenerateCharacter("Gasten_Kotes", "shipowner_13", "man", "man", 1, SPAIN, -1, false));
			FantomMakeCoolFighter(sld, 1, 10, 10, "blade3", "", 10);
			sld.name	= "Gasten";
			sld.lastname	= "Cats";
			SetCharacterPerk(sld, "Trader");
			SetCharacterPerk(sld, "BasicCommerce");
			SetSPECIAL(sld, 6, 4, 8, 8, 10, 6, 7);
			SetShipSkill(sld, 27, 45, 21, 14, 18, 21, 13, 9, 28);
			TakeNItems(sld, "potion1", -10);
			TakeNItems(sld, "potion2", -10);
			sld.Dialog.Filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "Torgovets_1";
			LAi_SetStayType(sld);
			LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "LaVega_town", "merchant", "merchant3");
			sld.talker = 5;
			
			//Девушка на улице (продолжение квеста)
			sld = GetCharacter(NPC_GenerateCharacter("AT_pr_devushka_na_rynke", "CitizenWom_2", "woman", "woman", 10, SPAIN, -1, false));
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld.quest.questflag.model = "exclamationmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
			sld.name	= "Sofia";
			sld.lastname	= "de la Piedad";
			LAi_SetActorType(sld);
			LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "LaVega_town", "merchant", "mrcActive3");
			
			//Какой-то мужик со шляпой
			sld = CharacterFromID("Old Friend")
			sld.Dialog.Filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "man_shlyapa";
			DeleteAttribute(sld, "talker");
		break;
		
		case "LaVegaIspanski_Gubernator":
			dialog.text = "Señorita Remedios ? Nous avons tout réglé. Ma décision tient, vous n'avez pas à vous inquiéter.";
			link.l1 = "Ma sœur a insisté pour que je vous invite à un dîner de famille.";
			link.l1.go = "LaVegaIspanski_Gubernator_2";
		break;
		
		case "LaVegaIspanski_Gubernator_2":
			dialog.text = "Hum, merci. Je crois que je serai occupé ces prochains jours, mais j'accepterai l'invitation sans faute.";
			link.l1 = "Parfait. Je ne vous retiens pas plus longtemps.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LaVegaIspanski_Gubernator_3";
		break;
		
		case "LaVegaIspanski_Gubernator_3":
			dialog.text = "Encore vous ?";
			link.l1 = "Je m'en vais.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LaVegaIspanski_Gubernator_3";
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_1":
			sld = CharacterFromID(pchar.ATP_MirJitId)
			dialog.text = "(à un passant) Nous sommes sorties nous promener avec ma sœur, vous avez peut-être besoin d'aide ?";
			link.l1 = "";
			link.l1.go = "Rebekka_s_mirnymi_jitelyami_1_1";
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(CharacterFromID("AT_pr_Rebekka"), CharacterFromID(pchar.ATP_MirJitId));
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_1_1":
			DialogExit();
			StartInstantDialog(pchar.ATP_MirJitId, "ATP_1_1", "Common_citizen.c");
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_2":
			sld = CharacterFromID(pchar.ATP_MirJitId)
			dialog.text = "(à un passant) "+sld.name+", merci pour le compliment.";
			link.l1 = "";
			link.l1.go = "Rebekka_s_mirnymi_jitelyami_2_1";
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(CharacterFromID("AT_pr_Rebekka"), CharacterFromID(pchar.ATP_MirJitId));
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_2_1":
			DialogExit();
			StartInstantDialog(pchar.ATP_MirJitId, "ATP_2_1", "Common_citizen.c");
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_3":
			sld = CharacterFromID(pchar.ATP_MirJitId)
			dialog.text = "(sourit timidement)";
			link.l1 = "";
			link.l1.go = "Rebekka_s_mirnymi_jitelyami_3_1";
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(CharacterFromID("AT_pr_Rebekka"), CharacterFromID(pchar.ATP_MirJitId));
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_3_1":
			DialogExit();
			StartInstantDialog(pchar.ATP_MirJitId, "ATP_3_1", "Common_citizen.c");
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_4":
			sld = CharacterFromID(pchar.ATP_MirJitId)
			dialog.text = "Non, Angelica, c'était plutכt étouffant hier matin.";
			link.l1 = "";
			link.l1.go = "Rebekka_s_mirnymi_jitelyami_4_1";
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(CharacterFromID("AT_pr_Rebekka"), pchar);
		break;
		
		case "Rebekka_s_mirnymi_jitelyami_4_1":
			DialogExit();
			StartInstantDialog(pchar.ATP_MirJitId, "ATP_4_1", "Common_citizen.c");
		break;
		
		case "man_shlyapa":
			dialog.text = "Bonjour ! Que puis-je faire pour vous ?";
			link.l1 = "Bonjour ! Vous avez un chapeau magnifique.";
			link.l1.go = "exit";
			NextDiag.TempNode = "man_shlyapa";
		break;
		
		case "Torgovets_1":
			LAi_SetActorType(pchar);
			LAi_ActorAnimation(pchar, "attack_break_1", "pchar_back_to_player", 0.1);
			StartQuestMovie(true, true, true);
			dialog.text = "Señorita, je ne peux pas vous faire crédit, vous n'êtes pas d'ici : demain, vous monterez sur un navire de passage, et on ne vous reverra plus.";
			link.l1 = "";
			link.l1.go = "Torgovets_2";
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("AT_pr_devushka_na_rynke"));
			locCameraToPos(-38.00, 7.00, 20.00, true);
		break;
		
		case "Torgovets_2":
			DialogExit();
			StartInstantDialog("AT_pr_devushka_na_rynke", "Torgovets_3", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "Torgovets_3":
			dialog.text = "Mais je ne demande pas de crédit, je paierai les deux tiers du prix tout de suite, et le reste, je peux le payer en travaillant : vous aider, vous ou votre épouse.";
			link.l1 = "";
			link.l1.go = "Torgovets_4";
			sld = CharacterFromID("AT_pr_devushka_na_rynke")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("Gasten_Kotes"));
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("Gasten_Kotes"));
			
			locCameraSleep(true);
		break;
		
		case "Torgovets_4":
			DialogExit();
			StartInstantDialog("Gasten_Kotes", "Torgovets_5", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "Torgovets_5":
			dialog.text = "Je n'ai pas vraiment beaucoup de travail, je fais tout parfaitement moi-même, et je ne suis pas marié. Je peux vous offrir les deux tiers de la marchandise...";
			link.l1 = "";
			link.l1.go = "Torgovets_6_1";
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, CharacterFromID("AT_pr_devushka_na_rynke"));
		break;
		
		case "Torgovets_6_1":
			DialogExit();
			LAi_SetActorType(pchar);
			LAi_ActorGoToLocator(pchar, "merchant", "mrcActive3", "", -1);
			DoQuestFunctionDelay("AT_pr_Torgovets_6_2", 1.0);
		break;
		
		case "Torgovets_6_3":
			dialog.text = "";
			link.l1 = "Gasten le Renard, tu ne vois pas que la señorita porte sur le visage les marques d'un destin difficile, malgré sa jeunesse ? Fais preuve de compassion.";
			link.l1.go = "Torgovets_7";
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
			sld = CharacterFromID("AT_pr_devushka_na_rynke")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "Torgovets_7":
			dialog.text = "Que comprendrais-tu aux gens, chère Angelica, toi qui n'as pas su voir une canaille dans ton beau-père, paix à son âme.";
			link.l1 = "Attention, le Renard, tu sais que je peux me fâcher pour une simple broutille.";
			link.l1.go = "Torgovets_8";
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
			sld = CharacterFromID("AT_pr_devushka_na_rynke")
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "Torgovets_8":
			dialog.text = "D'abord, échange ta jupe contre un pantalon avant de proférer des menaces. Il n'y a plus de commandant derrière toi, prêt à couvrir toutes tes frasques. C'est un bon conseil, ne le prends pas comme une insulte.";
			link.l1 = "Moi aussi, j'ai quelque chose sous ma jupe : ça s'appelle un coutelas. Laisse-moi te montrer comment je sais me défendre, et je vais te donner un bon conseil en même temps : défends-toi !";
			link.l1.go = "Torgovets_9";
		break;
		
		case "Torgovets_9":
			dialog.text = "Ne fais pas l'idiote.";
			link.l1 = "Défends-toi, ou échange ton pantalon contre une jupe !";
			link.l1.go = "Torgovets_10";
		break;
		
		case "Torgovets_10":
			DialogExit();
			
			LAi_SetActorType(pchar);
			AddQuestRecord("AT_Mechty_Sbivautsya", "0.2");
			Log_info("Il faut donner une leçon à ce gredin ! Suivez-le !");
			
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
			LAi_ActorRunToLocation(sld, "reload", "reload2_back", "none", "", "", "OpenTheDoors", -1);
			chrDisableReloadToLocation = true;
			
			sld = CharacterFromID("AT_pr_devushka_na_rynke")
			LAi_SetActorType(sld);
			
			PChar.quest.AT_pr_Draka_s_Kotesom.win_condition.l1 = "location";
			PChar.quest.AT_pr_Draka_s_Kotesom.win_condition.l1.location = "LaVega_ExitTown";
			PChar.quest.AT_pr_Draka_s_Kotesom.function = "AT_pr_Draka_s_Kotesom";
			
			DoQuestFunctionDelay("AT_pr_Torgovets_10_1", 1.0);
		break;
		
		case "Rebekka_posle_draki":
			dialog.text = "Arrête ! Tu as failli le tuer !";
			link.l1 = "J'ai juste montré à notre ami ce que vaut une langue quand elle est plus longue qu'une épée.";
			link.l1.go = "Rebekka_posle_draki_2";
			
			sld = characterFromId("Gasten_Kotes");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
			//LAi_ActorAnimation(sld, "kneeling_2", "", 2.4);
			LAi_SetGroundSitType(sld);
			LAi_CharacterDisableDialog(sld);
		break;
		
		case "Rebekka_posle_draki_2":
			dialog.text = "Bravo, maintenant aide-moi à le panser, et trouve-toi une excuse si tu ne veux pas être arrêtée. ";
			link.l1 = "Ne t'inquiète pas, tout ira bien. Quand ce renard s'est enfui dans la jungle, les soldats ont failli se faire éclater la panse de rire à ce spectacle, et l'égratignure guérira en deux heures. Ce qui m'inquiète davantage, c'est de savoir qui est cette fille, d'oם elle vient. Je vais aller la chercher.";
			link.l1.go = "Rebekka_posle_draki_3";
		break;
		
		case "Rebekka_posle_draki_3":
			chrDisableReloadToLocation = false;
			bDisableFastReload = true;
			pchar.questTemp.AnjelikaTichPrologue2 = "ATP2";
			AddQuestRecord("AT_Mechty_Sbivautsya", "0.3");
			
			PChar.quest.AT_pr_Oba_ischezaut.win_condition.l1 = "ExitFromLocation";
			PChar.quest.AT_pr_Oba_ischezaut.win_condition.l1.location = PChar.location;
			PChar.quest.AT_pr_Oba_ischezaut.function = "AT_pr_Oba_ischezaut";
		
			sld = characterFromId("AT_pr_Rebekka");
			LAi_SetActorType(sld);
			LAi_ActorFollow(sld, characterFromId("Gasten_Kotes"), "", -1);
			
			sld = CharacterFromID("AT_pr_devushka_na_rynke")
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld.quest.questflag.model = "exclamationmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
			LAi_SetCitizenType(sld);
			ChangeCharacterAddressGroup(sld, "LaVega_town", "goto", "goto2");
			sld.dialog.filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "Sofia_1";
			
			DialogExit();
		break;
		
		case "Sofia_1":
			dialog.text = "";
			link.l1 = "Excusez-moi, señorita, puis-je vous accompagner ?";
			link.l1.go = "Sofia_2";
			UnmarkCharacter(npchar);
		break;
		
		case "Sofia_2":
			dialog.text = "Bien sמr... Je m'appelle Sofia, Sofia de la Piedad, jusqu'à récemment. Vous n'auriez vraiment pas dמ traiter ce monsieur si durement.";
			link.l1 = "Ce monsieur méritait depuis longtemps qu'on le traite ainsi. Mais passons, Dieu le garde. Moi, je suis Angelica Remedios depuis bien longtemps. La fille adoptive de l'ancien commandant de cette colonie abandonnée de tous les saints chrétiens.";
			link.l1.go = "Sofia_3";
		break;
		
		case "Sofia_3":
			dialog.text = "Et maintenant ? Votre beau-père est muté à un autre poste ?";
			link.l1 = "Il est mort il y a un peu plus d'un mois, d'une mort plutכt ridicule : il s'est disputé avec un de ses subordonnés. Ma demi-sœur et moi n'avions plus d'autres parents ici, et nous nous sommes retrouvées livrées à nous-mêmes.";
			link.l1.go = "Sofia_4";
		break;
		
		case "Sofia_4":
			dialog.text = "Je suis désolée. Il semble que nous ayons un problème semblable, vous et moi.";
			link.l1 = "C'est ce qu'il m'a semblé tout de suite. Je suppose que vous êtes descendue du navire de guerre qui a accosté ce matin, mais visiblement sans votre père ni votre mari pour vous accompagner.";
			link.l1.go = "Sofia_5";
		break;
		
		case "Sofia_5":
			dialog.text = "Oui, j'ai été récemment mariée à un militaire. Nous nous sommes mariés à la hâte, sur l'insistance de mes parents, car mon mari attendait une mission ici, dans le Nouveau Monde. Il a quitté l'Europe pour La Havane en passant par la Sierra Leone, et deux semaines plus tard, on m'a embarquée sur un navire marchand qui allait tout droit dans ces parages\n"+
							"Je suis donc arrivée à La Havane encore plus tכt, et en attendant, j'ai appris qu'à peine avaient-ils quitté les cכtes d'Afrique, la fièvre s'était emparée du navire, et que mon mari faisait partie de ceux qui n'y avaient pas survécu.";
			link.l1 = "Ce sont vos parents qui vous ont mariée, c'était donc un mariage de raison ?";
			link.l1.go = "Sofia_6";
		break;
		
		case "Sofia_6":
			dialog.text = "Je ne savais même pas s'il fallait m'affliger ou me réjouir : je ne voulais pas épouser cet homme et je le connaissais à peine, mais je n'ai personne d'autre, et surtout, il ne me reste aucun moyen de subsistance. Le capitaine a eu la bonté d'accepter de me ramener en Europe, à condition qu'à mon arrivée, mes parents paient mon voyage, mais de quoi vais-je vivre maintenant ?"+
							"En plus, avant de repartir, il faut encore rester ici deux ou trois jours et passer par Portobelo, c'est ce qu'il a dit, je crois.";
			link.l1 = "Mon enfance et ma jeunesse n'ont pas été calmes, je prendrais sans doute de tels événements comme une aventure, mais ce doit être dur pour vous de vous arracher à une vie paisible et de vous retrouver dans un tel abîme d'ennuis. Mais il semble que la chance vous ait finalement souri : nous pouvons nous aider l'une l'autre.";
			link.l1.go = "Sofia_7";
		break;
		
		case "Sofia_7":
			dialog.text = "Ce n'est pas la peine, parler avec vous m'a déjà fait du bien...";
			link.l1 = "Pas d'objections. J'ai des affaires cachées dans une grotte près d'ici. Je ne peux ni les vendre ni les échanger, mais elles vous aideront sמrement.";
			link.l1.go = "Sofia_8";
		break;
		
		case "Sofia_8":
			dialog.text = "Qu'est-ce qu'elles ont, elles sont maudites ?";
			link.l1 = "Ha ha ! Non, bien sמr que non, mais je parie que leur ancien propriétaire a été maudit plus d'une fois. Attendez ici, je reviens vite, mais n'en dites pas un mot à personne.";
			link.l1.go = "Sofia_9";
		break;
		
		case "Sofia_9":
			LAi_CharacterDisableDialog(npchar);
			AddQuestRecord("AT_Mechty_Sbivautsya", "1");
			
			PChar.quest.AT_MS_PodskazkaGrot.win_condition.l1 = "location";
			PChar.quest.AT_MS_PodskazkaGrot.win_condition.l1.location = "Shore32";
			PChar.quest.AT_MS_PodskazkaGrot.function = "AT_MS_PodskazkaGrot";
			
			PChar.quest.AT_pr_Grot.win_condition.l1 = "location";
			PChar.quest.AT_pr_Grot.win_condition.l1.location = "Hispaniola_Grot";
			PChar.quest.AT_pr_Grot.function = "AT_pr_Grot";
			
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.jewelry6 = 10;
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.jewelry17 = 5;
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.jewelry12 = 15;
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.jewelry3 = 10;
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.potionwine = 2;
			pchar.GenQuestBox.Hispaniola_Grot.box1.items.spyglass1 = 1;
		
			DialogExit();
		break;
		
		case "Rebekka_v_grote_1":
			dialog.text = "Oh, Angelica !";
			link.l1 = "Becky ? Qu'est-ce que tu fais ici ? ";
			link.l1.go = "Rebekka_v_grote_2";
			locCameraToPos(3.80, 2.70, -4.00, true);
		break;
		
		case "Rebekka_v_grote_2":
			dialog.text = "Je cherche à flairer ce que tu fais ici. Tu te conduis bizarrement ces derniers temps : tu provoques tout le monde, tu files sans cesse dans les bois, puis ici, sur la cכte.";
			link.l1 = "Alors tu me surveilles de temps en temps. וcoute, je ne peux pas suivre ton exemple et rester enfermée toute la journée, et notre fort me donne la nausée. J'en ai assez de croiser les regards des soldats du coin, d'écouter leurs compliments et leurs plaisanteries primitifs.";
			link.l1.go = "Rebekka_v_grote_3";
			locCameraSleep(true);
		break;
		
		case "Rebekka_v_grote_3":
			dialog.text = "Je comprends. Mais ce n'est pas que ça, n'est-ce pas ? Regarde\n"+
							"On dirait que ce sont les affaires d'Arcadio ? Ce soldat qui a fait irruption chez nous en exigeant ma main, et la bague, c'est celle qu'il a essayé de m'offrir avant que tu ne le mettes dehors.";
			link.l1 = "On dirait. Oui.";
			link.l1.go = "Rebekka_v_grote_4";
		break;
		
		case "Rebekka_v_grote_4":
			dialog.text = "Quand j'ai appris qu'on l'avait retrouvé mort sur le rivage, j'ai prié notre mère d'intercession de nous avoir débarrassées de cet homme ignoble, et toi, tu as caché ses affaires ici ? Comment les as-tu eues ? Tu l'as tué !";
			link.l1 = "Non ! Bien sמr que non... euh... Oui, je me promenais hors de la ville, comme d'habitude, et je suis tombée sur des gens. Des pirates, ou des contrebandiers, je ne sais pas, en tout cas pas d'ici, et Arcadio était avec eux. Bien sמr, j'ai vite filé avant d'être remarquée, et plus tard, quand je suis revenue, je l'ai trouvé mort, j'ai fouillé ses poches et je me suis enfuie.";
			link.l1.go = "Rebekka_v_grote_5";
		break;
		
		case "Rebekka_v_grote_5":
			dialog.text = "Et tu as caché ici ce que tu y as trouvé, pour que personne ne le découvre et ne pense que tu l'avais poignardé ?";
			link.l1 = "Bien sמr.";
			link.l1.go = "Rebekka_v_grote_6";
		break;
		
		case "Rebekka_v_grote_6":
			dialog.text = "Oh, j'aimerais te croire, mais aujourd'hui... Le señor Cotes : si l'épée l'avait touché un peu plus à droite, qui sait...";
			link.l1 = "C'est un coutelas, pas une épée.";
			link.l1.go = "Rebekka_v_grote_7";
		break;
		
		case "Rebekka_v_grote_7":
			DialogExit();
			
			LAi_SetActorType(pchar);
			DoQuestFunctionDelay("AT_pr_Strelba_is_pushki", 1.3);
		break;
		
		case "Rebekka_v_grote_8":
			dialog.text = "On tire ? C'est le fort qui tire.";
			link.l1 = "Non, j'aurais reconnu les canons du fort. On dirait que le bruit vient de la mer. Allons-y, vite !";
			link.l1.go = "Rebekka_v_grote_9";
		break;
		
		case "Rebekka_v_grote_9":
			dialog.text = "Tu es folle ? Et si la ville était attaquée ? Restons ici, ce sera plus sמr.";
			link.l1 = "";
			link.l1.go = "Rebekka_v_grote_10";
		break;
		
		case "Rebekka_v_grote_10":
			DialogExit();
			
			LAi_SetActorType(pchar);
			DoQuestFunctionDelay("AT_pr_Strelba_is_pushki_4", 1.3);
		break;
		
		case "Rebekka_v_grote_11":
			dialog.text = "";
			link.l1 = "Et ça, c'est le fort qui tire. Bon sang, Rebecca, une chance que nous soyons arrivées à temps, toi et moi.";
			link.l1.go = "Rebekka_v_grote_12";
		break;
		
		case "Rebekka_v_grote_12":
			dialog.text = "J'espère que nos gars repousseront l'attaque, quels que soient les assaillants.";
			link.l1 = "";
			link.l1.go = "Rebekka_v_grote_13";
		break;
		
		case "Rebekka_v_grote_13":
			DialogExit();
			LAi_SetActorType(pchar);
			locCameraSleep(false);
			SetLaunchFrameFormParam("Le soir est tombé...", "", 0, 2.3);
			LaunchFrameForm();
			DoQuestFunctionDelay("AT_pr_Piraty_v_grote", 2.3);
		break;
		
		case "Pirate_v_grote_1":
			dialog.text = "Oh, qui se cache ici ? Quelle chance qu'on ait faussé compagnie aux nכtres.";
			link.l1 = "Comment êtes-vous arrivés ici ? Halte ! N'approchez pas ! Je ne vous laisserai pas faire !";
			link.l1.go = "Pirate_v_grote_2";
		break;
		
		case "Pirate_v_grote_2":
			dialog.text = "Regardez-moi ça, la souris est acculée. Attaquons, voyons si elles disent vrai...";
			link.l1 = "Becky, cours !";
			link.l1.go = "Pirate_v_grote_3";
		break;
		
		case "Pirate_v_grote_3":
			DialogExit();
			EndQuestMovie();
			
			sld = characterFromId("AT_pr_Rebekka");
			LAi_SetActorType(sld);
			LAi_ActorRunToLocation(sld, "reload", "reload1", "none", "", "", "", -1);
			
			LAi_SetFightMode(pchar, true);
			for (i=1; i<=2; i++)
				{
				sld = CharacterFromID("AT_pr_Piraty_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);		//стравливаем
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "AT_pr_Pobeda_v_grote");
		break;
		
		case "Stoim_na_pirse":
			dialog.text = "Angelica ! Tu ne vas pas le croire, mais je suis sacrément content de te voir saine et sauve.";
			link.l1 = "Qui nous a attaqués ? Nous avons repoussé l'attaque ? Oם sont les survivants ?";
			link.l1.go = "Stoim_na_pirse_2";
		break;
		
		case "Stoim_na_pirse_2":
			dialog.text = "Des pirates. Toute la garnison a été battue ; certains ont réussi à fuir dans la jungle, ou, comme moi, à se cacher, mais il ne reste plus personne ici : les derniers sont passés sur cette barque.";
			link.l1 = "Pourquoi ont-ils besoin de notre fort ? Il n'y a rien à y gagner ?";
			link.l1.go = "Stoim_na_pirse_3";
		break;
		
		case "Stoim_na_pirse_3":
			dialog.text = "On dirait qu'ils comptent s'en servir comme point de transit. Leurs équipes ont débarqué et se sont dirigées vers l'intérieur des terres. J'ai entendu parler de Santo Domingo : il y a là-bas une puissante forteresse, sans comparaison avec la nכtre, mais s'ils parviennent à attaquer la ville par la terre, la garnison du fort n'aura même pas le temps de venir à la rescousse avant que la ville ne soit pillée.";
			link.l1 = "Ils auraient pu débarquer dans n'importe quelle baie.";
			link.l1.go = "Stoim_na_pirse_4";
		break;
		
		case "Stoim_na_pirse_4":
			dialog.text = "Je ne connais pas leurs motifs, mais écoute, tu t'y connais en navigation, non ? Il reste plusieurs marins sur la barque, bien sמr, ils peuvent mener le navire le long de la cכte, mais le capitaine et le navigateur étaient en ville, et ils n'ont pas été épargnés, et il nous faut la meilleure route pour éviter récifs et hauts-fonds. Nous devons arriver à Santo Domingo avant les pirates.";
			link.l1 = "Mon beau-père m'a engagé des professeurs, mais je n'ai jamais dirigé un navire moi-même... Et oם est Rebecca, elle est montée sur la barque, elle aussi ?";
			link.l1.go = "Stoim_na_pirse_5";
		break;
		
		case "Stoim_na_pirse_5":
			dialog.text = "Je ne l'ai pas vue depuis le siège, depuis qu'elle m'a bandé l'épaule.";
			link.l1 = "Elle n'est pas revenue en ville ? Becky devait être ici quelques minutes avant moi. Oh non, je ne peux pas partir maintenant, il faut que je la retrouve.";
			link.l1.go = "Stoim_na_pirse_6";
		break;
		
		case "Stoim_na_pirse_6":
			dialog.text = "Nous ne pouvons pas attendre non plus : il ne s'agit même pas d'avoir le temps de prévenir le gouverneur de l'attaque, nous avons des navires ennemis à cכté de nous, et il y a encore des gens à bord qui peuvent débarquer ici à tout moment.";
			link.l1 = "Non, je ne peux toujours pas.";
			link.l1.go = "Stoim_na_pirse_7";
		break;
		
		case "Stoim_na_pirse_7":
			dialog.text = "וcoute, si Rebecca est tombée sur les pirates, ils l'ont très probablement emmenée en otage, et si elle a réussi à se cacher dans les bois, elle reviendra forcément ici. Dans tous les cas, nous devons arriver à Santo Domingo au plus vite. Alors, nous aurons une chance de retrouver ta sœur sous les murs de la ville, ou bien le gouverneur général du coin équipera un détachement pour reprendre notre fort, et elle pourra revenir en toute sécurité."+ 
							"Si tu restes ici, tu n'aideras certainement personne, à part divertir cette meute d'assassins avant de mourir.";
			link.l1 = "Diable... Si seulement elle était restée avec moi. Mais je n'aurais peut-être pas pu m'en sortir. Bon. D'accord, on prend la mer, mais donne-moi une minute.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Stoim_na_pirse_8";
		break;
		
		case "Stoim_na_pirse_8":
			dialog.text = "Je ne vois personne d'autre ici.";
			link.l1 = "Oui, elle est introuvable. Nous appareillons.";
			link.l1.go = "Stoim_na_pirse_9";
		break;
		
		case "Stoim_na_pirse_9":
			DialogExit();
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocator(sld, "reload", "reload1_back", "AT_pr_Stoim_na_pirse_9", -1);
			
			sld = GetCharacter(NPC_GenerateCharacter("AT_pr_OfficerRezid", "sold_spa_7", "man", "man", 10, SPAIN, -1, true));
			ChangeCharacterAddressGroup(sld, "SantoDomingo_town", "officers", "Reload3_1");
			LAi_SetLoginTime(sld, 6.0, 21.99);
			LAi_SetStayType(sld);
			sld.dialog.filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "AT_pr_Officer_u_rezidenta";
			sld.talker = 5;
			
			sld = CharacterFromID("LaVega_tavernkeeper")	//Возвращаем тавернщику его родной диалог
			sld.Dialog.Filename = "Common_Tavern.c";
			sld.dialog.currentnode = "First time";
		break;
		
		case "AT_pr_Officer_u_rezidenta":
			dialog.text = "Mademoiselle, attendez ! Oם allez-vous ?";
			link.l1 = "Je suis une messagère du fort de La Vega, avec un message urgent pour le gouverneur.";
			link.l1.go = "AT_pr_Officer_u_rezidenta_2";
		break;
		
		case "AT_pr_Officer_u_rezidenta_2":
			sld = CharacterFromID("SantoDomingo_Mayor")
			dialog.text = "Je vois. Je vous aurais laissée passer, mais Sa Seigneurie n'est pas à sa place. Le señor " + GetFullName(sld)+" est parti à l'Amirauté.";
			link.l1 = "Il est hors de la ville ? Alors, il me faut le commandant de la garnison, ou l'homme que le gouverneur a laissé à sa place.";
			link.l1.go = "AT_pr_Officer_u_rezidenta_3";
		break;
		
		case "AT_pr_Officer_u_rezidenta_3":
			dialog.text = "C'est votre première mission d'ambassadrice ? L'Amirauté, c'est ce grand bâtiment gris là-bas, que je suis condamné à regarder toute la journée. Passez sous l'arche et tournez à droite. Il y a aussi une banque juste en face de la porte qu'il vous faut.";
			link.l1 = "Merci.";
			link.l1.go = "AT_pr_Officer_u_rezidenta_4";
			npchar.lifeday = 0;
			LAi_SetActorType(npchar);
		break;
		
		case "AT_pr_Officer_u_rezidenta_4":
			DialogExit();
			
			pchar.questTemp.AnjelikaTichPrologue3 = "ATP3";
		break;
		
		case "ATpr_SD_Gubernator_1":
			dialog.text = "";
			link.l1 = "Je vous trouve enfin.";
			link.l1.go = "ATpr_SD_Gubernator_2";
		break;
		
		case "ATpr_SD_Gubernator_2":
			dialog.text = "Quelle est cette urgence, et qui vous a laissée entrer ici comme ça ?";
			link.l1 = "Je suis l'une des rares survivantes de la colonie de La Vega. Nous avons été attaqués par des boucaniers : ils ont d'abord tiré sur le fort depuis la mer, puis ils ont débarqué sur le rivage et y ont fait un massacre.";
			link.l1.go = "ATpr_SD_Gubernator_3";
		break;
		
		case "ATpr_SD_Gubernator_3":
			dialog.text = "Puis-je vous faire confiance ?";
			link.l1 = "J'ai à bord des gens qui vous diront la même chose, et quand je me suis présentée au secrétaire, à l'entrée, il a confirmé qu'il connaissait mon beau-père.";
			link.l1.go = "ATpr_SD_Gubernator_4";
		break;
		
		case "ATpr_SD_Gubernator_4":
			dialog.text = "Vous ne vous êtes pas présentée à moi, mais ce n'est pas important. L'un des survivants a-t-il parlé avec ces pirates ? Quelles sont leurs exigences ?";
			link.l1 = "א ma connaissance, aucun. Une partie de l'équipage pirate est restée dans le port, sur les navires, d'autres sont partis à travers la jungle. Ils viennent ici, et puisque nous parlons ici et que tout est calme en ville, c'est que nous avons réussi à contourner l'île par la mer avant eux.";
			link.l1.go = "ATpr_SD_Gubernator_5";
		break;
		
		case "ATpr_SD_Gubernator_5":
			DialogExit();
			StartInstantDialog("ATpr_SD_Off_Guber_2", "ATpr_SD_Gubernator_6", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "ATpr_SD_Gubernator_6":
			dialog.text = "Combien peuvent-ils être ?";
			link.l1 = "Nous n'avons vu que deux navires, pour une capacité totale de 300 à 400 hommes. Personne d'autre n'a été vu en chemin, il n'y a donc sans doute pas eu de débarquement dans les baies.";
			link.l1.go = "ATpr_SD_Gubernator_7";
		break;
		
		case "ATpr_SD_Gubernator_7":
			dialog.text = "Je ne peux pas faire venir toute la garnison du fort pour renforcer la ville. Nous ne connaissons pas leurs plans : ils attaqueront peut-être de plusieurs cכtés, si tant est qu'ils attaquent.";
			link.l1 = "";
			link.l1.go = "ATpr_SD_Gubernator_8";
			LAi_SetActorType(npchar);
		break;
		
		case "ATpr_SD_Gubernator_8":
			DialogExit();
			StartInstantDialog("SantoDomingo_Mayor", "ATpr_SD_Gubernator_9", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "ATpr_SD_Gubernator_9":
			dialog.text = "Je pense que deux ou trois escouades de mousquetaires suffiront. S'il y a des navires de guerre en rade, mieux vaut les envoyer vers le phare et le cap le plus proche pour contrכler les approches.";
			link.l1 = "J'ai une requête, señor gouverneur. Je dois absolument être là-bas, à l'endroit de l'attaque attendue par la terre. Ma sœur est peut-être avec eux.";
			link.l1.go = "ATpr_SD_Gubernator_10";
		break;
		
		case "ATpr_SD_Gubernator_10":
			dialog.text = "Vous êtes une jeune fille, vous n'avez pas à être là-bas. Cependant, je ne peux pas vous l'interdire, mais sachez que ce ne sera pas sמr pour vous.";
			link.l1 = "Ne vous inquiétez pas pour moi, je saurai prendre soin de moi.";
			link.l1.go = "ATpr_SD_Gubernator_11";
		break;
		
		case "ATpr_SD_Gubernator_11":
			DialogExit();
			StartInstantDialog("ATpr_SD_Off_Guber_1", "ATpr_SD_Gubernator_12", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "ATpr_SD_Gubernator_12":
			dialog.text = "Attendez devant les portes de la ville. La défense y sera organisée très bientכt. Le relief et la jungle ne permettent pas d'approcher par ailleurs.";
			link.l1 = "Merci.";
			link.l1.go = "ATpr_SD_Gubernator_13";
			LAi_SetActorType(npchar);
		break;
		
		case "ATpr_SD_Gubernator_13":
			DialogExit();
			StartInstantDialog("SantoDomingo_Mayor", "ATpr_SD_Gubernator_14", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
		break;
		
		case "ATpr_SD_Gubernator_14":
			dialog.text = "";
			link.l1 = "Puis-je... ?";
			link.l1.go = "ATpr_SD_Gubernator_15";
		break;
		
		case "ATpr_SD_Gubernator_15":
			dialog.text = "Oui, vous pouvez disposer.";
			link.l1 = "";
			link.l1.go = "ATpr_SD_Gubernator_16";
			LAi_SetActorType(npchar);
		break;
		
		case "ATpr_SD_Gubernator_16":
			DialogExit();
			
			PChar.quest.ATpr_OboronaSD.win_condition.l1 = "location";
			PChar.quest.ATpr_OboronaSD.win_condition.l1.location = "SantoDomingo_ExitTown";
			PChar.quest.ATpr_OboronaSD.win_condition = "ATpr_OboronaSD";
		break;
		
		case "ATpr_SD_Koten_1":
			dialog.text = "Te voilà ! Je vois que tout est fini, mais j'ai déjà couru la moitié de la ville, et dès que j'ai entendu les coups de feu, j'ai tout de suite su oם te chercher.";
			link.l1 = "Rebecca n'est pas là...";
			link.l1.go = "ATpr_SD_Koten_2";
		break;
		
		case "ATpr_SD_Koten_2":
			dialog.text = "Je suis désolé.";
			link.l1 = "Tu le savais, et je le savais. Je voulais juste voir l'horreur et la confusion sur leurs visages quand ils mourraient ici, sous les murs.";
			link.l1.go = "ATpr_SD_Koten_3";
		break;
		
		case "ATpr_SD_Koten_3":
			dialog.text = "Tout n'est pas encore perdu. וcoute, l'équipage du navire a tenu conseil. Nous avons discuté pour savoir si nous devions rester ici ou tenter notre chance et retourner à La Vega, et en même temps, on a proposé de choisir un capitaine par un vote général.";
			link.l1 = "Hum... Et qu'avez-vous décidé ?";
			link.l1.go = "ATpr_SD_Koten_4";
		break;
		
		case "ATpr_SD_Koten_4":
			dialog.text = "Nous avons décidé que le capitaine aurait le dernier mot. Tu es avec nous ?";
			link.l1 = "Avec vous, bien sמr. Mais d'abord, il faut aller voir le gouverneur : après tout, c'est grâce à nous que l'attaque contre la ville n'a pas été une surprise. Je compte sur une récompense qui nous permettra de tenir un moment.";
			link.l1.go = "ATpr_SD_Koten_5";
		break;
		
		case "ATpr_SD_Koten_5":
			dialog.text = "Ce serait plus que juste. Alors, je propose de ne pas traîner, et ensuite, bienvenue à bord, madame la capitaine.";
			link.l1 = "";
			link.l1.go = "ATpr_SD_Koten_6";
		break;
		
		case "ATpr_SD_Koten_6":
			dialog.text = "Et puis, j'ai fait un petit inventaire sur le navire. J'ai trouvé une tenue qui te convient. Oם a-t-on jamais vu un capitaine se promener sur le pont en jupe ?";
			link.l1 = "";
			link.l1.go = "ATpr_SD_Koten_6_1";
		break;
		
		case "ATpr_SD_Koten_6_1":
			dialog.text = "Tiens, essaie-la.";
			link.l1 = "Retourne-toi, je me change...";
			link.l1.go = "ATpr_SD_Koten_6_3";
		break;
		
		/*case "ATpr_SD_Koten_6_2":
			DialogExit();
			SetLaunchFrameFormParam("A minute of changing clothes...", "ATpr_Pereodevaemsya", 0, 2.0);
			LaunchFrameForm();
			WaitDate("", 0, 0, 0, 0, 1);
			LAi_SetActorType(pchar);
			sld = CharacterFromID("Gasten_Kotes")
			LAi_SetActorType(sld);
		break;*/
		
		case "ATpr_SD_Koten_6_3":
			LAi_Fade("", "");
			dialog.text = "";
			link.l1 = "Pas mal, pas mal. דa ira pour commencer. Merci, Gasten.";
			link.l1.go = "ATpr_SD_Koten_7";
			//SetLaunchFrameFormParam("A minute of changing clothes", "", 0, 2.0);
			//LaunchFrameForm();
			//WaitDate("", 0, 0, 0, 0, 1);
			
			PlaySound("Interface\important_item.wav");
			Log_info("Vous avez reçu une nouvelle tenue");
		break;
		
		case "ATpr_SD_Koten_7":
			dialog.text = "Nous sommes dans le même bateau maintenant. Quoi que paie le gouverneur, me voilà sans le sou, moi aussi, mais la fibre commerciale, ce n'est pas un étal sur la place : on ne me l'arrache pas si facilement d'une bordée, et avec un navire à nous deux, nous ne serons pas perdus.";
			link.l1 = "Oui, ce n'est pas une mauvaise idée de commencer par le fret. La pêche dans les eaux du coin, ce n'est vraiment pas pour moi. Bon, señor Cotes, nos projets d'avenir, ce sera pour plus tard : nous devons encore aller à la résidence aujourd'hui.";
			link.l1.go = "ATpr_SD_Koten_8";
			Log_info("Gasten est devenu votre officier");
			PlaySound("interface\notebook.wav");
		break;
		
		case "ATpr_SD_Koten_8":
			DialogExit();
			
			sld = CharacterFromID("Gasten_Kotes")
			AddPassenger(pchar, sld, false);
			SetCharacterRemovable(sld, true);
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true;
			ChangeCharacterReputation(sld, 20);
			sld.loyality = MAX_LOYALITY;
			LAi_SetCurHPMax(sld);
			LAi_SetImmortal(sld, false);
			sld.HalfImmortal = true;
			
			AddSimpleRumour("Des pirates se sont emparés de la colonie espagnole de La Vega, et ont en même temps tenté d'attaquer Santo Domingo. Mais ils ont échoué : ils ont tous été tués sous les murs de la ville.", PIRATE, 10, 1);
			AddSimpleRumour("Terrible nouvelle : des pirates ont fait un massacre dans notre colonie de La Vega, on dit qu'ils n'ont épargné personne. Dieu merci, le châtiment les a déjà rattrapés : tous ces gredins sont morts sous les murs de Santo Domingo, dans une tentative ratée de prendre la ville par la terre.", SPAIN, 10, 1);
			pchar.questTemp.AnjelikaTichPrologue6 = "ATP6";
			SetTimerCondition("ATpr_Jiteli_Uspokoilis", 0, 0, 1, false);
			DeleteAttribute(pchar, "questTemp.AnjelikaTichPrologue5");
			DeleteAttribute(pchar, "MaxSailing");
			DeleteAttribute(pchar, "GenQuest.CannotWait");
			RemoveCharacterEquip(pchar, SUIT_ITEM_TYPE);
			TakeItemFromCharacter(pchar, "suit_2");
			DoQuestReloadToLocation("SantoDomingo_town", "reload", "gate_back", "");
			pchar.questTemp.AnjelikaTichPrologue4 = "ATP4";
			LocatorReloadEnterDisable("SantoDomingo_town", "Reload3_back", false);
			chrDisableReloadToLocation = false;
			
			sld = CharacterFromID("SantoDomingo_Mayor")
			sld.Dialog.Filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "ATpr_SD_Gubernator_20";
			LAi_SetHuberType(sld);
			ChangeCharacterAddressGroup(sld, "SantoDomingo_townhall", "sit", "sit1");
		break;
		
		case "ATpr_SD_Gubernator_20":
			dialog.text = "Vous voilà. On m'a déjà informé de l'attaque repoussée avec succès. Je n'ai pas beaucoup de temps, alors venons-en directement au fait.";
			link.l1 = "Bien sמr. J'ose espérer...";
			link.l1.go = "ATpr_SD_Gubernator_21";
		break;
		
		case "ATpr_SD_Gubernator_21":
			dialog.text = "...Une récompense pour votre courage et votre devoir envers la couronne. Eh bien, votre action a été estimée à 15 000 piastres. Ce n'est que la moitié de ce que vous recevez dès maintenant. On m'a aussi informé que le navire sur lequel sont arrivés les réfugiés appartenait à un certain José Carpio, et qu'il est désormais sous votre commandement. C'est exact ?";
			link.l1 = "Il semble que ce soit le cas. J'ai été choisie comme capitaine par un vote général de l'équipage.";
			link.l1.go = "ATpr_SD_Gubernator_22";
		break;
		
		case "ATpr_SD_Gubernator_22":
			AddMoneyToCharacter(pchar, 30000);
			GiveItem2Character(PChar, "ATpr_pismo");
			dialog.text = "וtonnant. Cependant, c'est pourquoi la seconde partie des fonds vous est aussi remise personnellement. Utilisez-les pour remettre le navire en état, compléter l'équipage et aller à La Havane faire votre rapport à Sa Grâce Francisco Oregón y Gascón, gouverneur général des colonies espagnoles de l'archipel des Caraïbes, sur ce qui s'est passé. Personne ne peut le faire mieux que les témoins directs des événements ; remettez aussi ce rapport de ma part. Le reste des fonds sera votre récompense.";
			link.l1 = "Quel sort attend La Vega ? Est-il prévu de reprendre le contrכle de la colonie ?";
			link.l1.go = "ATpr_SD_Gubernator_23";
		break;
		
		case "ATpr_SD_Gubernator_23":
			dialog.text = "Vous aurez l'occasion de poser cette question en personne à Son Excellence. Je n'ai pas le droit de prendre des décisions d'une telle ampleur.";
			link.l1 = "Dans ce cas, j'ai moi aussi un intérêt personnel à me rendre à La Havane au plus vite.";
			link.l1.go = "ATpr_SD_Gubernator_24";
		break;
		
		case "ATpr_SD_Gubernator_24":
			dialog.text = "דa fait plaisir à entendre. Je ne vous retiens pas plus longtemps.";
			link.l1 = "";
			link.l1.go = "exit";
			AddDialogExitQuest("ATpr_VosstanovimGorod");
		break;
		
		case "Pirat_Guber":
			dialog.text = "As-tu eu le courage, femme, de te montrer ici, ou est-ce la bêtise qui t'a empêchée de voir les changements autour de toi ?";
			link.l1 = "Je m'appelle Angelica Teach, et je suis ici justement parce qu'il y a eu des changements autour de moi.";
			link.l1.go = "Pirat_Guber_2";
		break;
		
		case "Pirat_Guber_2":
			dialog.text = "Ah oui ? Explique-toi.";
			link.l1 = "Par chance, je me trouvais à Santo Domingo quand tes hommes ont fait une tentative ratée pour y entrer. Le bruit s'est répandu dans toute la ville que l'Espagne avait mis une prime sur deux jeunes demoiselles, les filles du commandant de ce fort, et j'ai bien l'intention de la toucher.";
			link.l1.go = "Pirat_Guber_3";
		break;
		
		case "Pirat_Guber_3":
			dialog.text = "Tu crois que si je les avais, je te les donnerais ?";
			link.l1 = "Je pense que tu as besoin d'un intermédiaire pour les négociations. Les Espagnols ne te laisseront approcher à portée de canon d'aucune de leurs colonies.";
			link.l1.go = "Pirat_Guber_4";
		break;
		
		case "Pirat_Guber_4":
			dialog.text = "Ils n'ont aucune raison de le faire. Ce ne sont pas mes hommes qui ont attaqué la colonie. J'ai juste profité de l'occasion pour occuper la fortification abandonnée. Un endroit avantageux, je le note : il serait stupide de le négliger. Les caravanes anglaises et françaises passent sans cesse par ici, et par beau temps, on voit même les cכtes de Tortuga.";
			link.l1 = "Et les sœurs, alors ?";
			link.l1.go = "Pirat_Guber_5";
		break;
		
		case "Pirat_Guber_5":
			dialog.text = "Tu peux prendre tes gars et fouiller l'île, mais je suis prêt à parier que si elles sont vivantes, elles viendront d'elles-mêmes. Ou alors, tu peux distribuer des pelles et donner l'ordre de fouiller le cimetière hors de la ville. Tu ne les trouveras pas chez moi.";
			link.l1 = "Personne n'aurait mis de prime sur des mortes.";
			link.l1.go = "Pirat_Guber_6";
		break;
		
		case "Pirat_Guber_6":
			dialog.text = "Alors, je ne peux rien pour toi.";
			link.l1 = "Je reviendrai à l'occasion.";
			link.l1.go = "Pirat_Guber_7";
		break;
		
		case "Pirat_Guber_7":
			DialogExit();
			
			AddQuestRecord("AT_Mechty_Sbivautsya", "5");
			sld = CharacterFromID("Edward Mansfield")
			sld.Dialog.Filename = "Mayor/EdwardMansfield.c";
			sld.dialog.currentnode = "First Time";
		break;
		
		case "Ispa_Guber":
			dialog.text = "";
			link.l1 = "Je viens de la part du señor gouverneur de Santo Domingo, avec un rapport sur les récents événements d'Hispaniola.";
			link.l1.go = "Ispa_Guber_2";
			TakeItemFromCharacter(pchar, "ATpr_pismo");
		break;
		
		case "Ispa_Guber_2":
			sld = CharacterFromID("SantoDomingo_Mayor")
			dialog.text = "J'ai déjà des informations sur ce qui s'est passé. Les rumeurs volent plus vite que le vent dans ces parages, vous savez, mais je lirai bien sמr le rapport officiel. Acceptez ceci en paiement de cette livraison rapide.";
			link.l1 = "Le señor "+GetFullName(sld)+" m'a déjà versé une récompense d'avance.";
			link.l1.go = "Ispa_Guber_3";
			AddMoneyToCharacter(pchar, 5000);
		break;
		
		case "Ispa_Guber_3":
			dialog.text = "Considérez que ceci couvre vos frais supplémentaires.";
			link.l1 = "Je ne dirai pas non, je suis dans une situation difficile en ce moment. א ce propos, j'ai une question, moins d'ordre public que personnel. Quel sort attend la colonie perdue par l'Espagne ? Elle a longtemps été ma maison.";
			link.l1.go = "Ispa_Guber_5";
		break;
		
		case "Ispa_Guber_5":
			dialog.text = "Nous ne pouvons pas prendre de décisions hâtives sur cette question. Mais je peux vous dire avec certitude que l'Espagne ne laissera pas passer le sanglant pillage commis par les pirates. Tכt ou tard, le drapeau espagnol flottera de nouveau sur La Vega, et la justice triomphera ! Maintenant, je vais vous demander de me laisser, je dois travailler.";
			link.l1 = "Merci, Votre Excellence !";
			link.l1.go = "Ispa_Guber_6";
		break;
		
		case "Ispa_Guber_6":
			DialogExit();
			
			AddQuestRecord("AT_Mechty_Sbivautsya", "6");
			CloseQuestHeader("AT_Mechty_Sbivautsya");
			sld = CharacterFromID("spa_guber")
			sld.Dialog.Filename = "Common_Governor.c";
			sld.dialog.currentnode = "First Time";
		break;
	}
}
