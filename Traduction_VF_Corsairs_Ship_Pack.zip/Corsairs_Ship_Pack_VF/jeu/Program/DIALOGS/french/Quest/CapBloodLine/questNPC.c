// Блад
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
    string sLocator, sTemp;
    int iTime, n, iChar;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);




	switch(Dialog.CurrentNode)
	{

		// ----------------------------------- Диалог первый - первая встреча
		case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Exit_Away":

            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", Pchar.questTemp.sLocator, "none", "", "", "", sti(Pchar.questTemp.iTime));
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

        case "Exit_RunAway":

            LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorRunToLocation(npchar, "reload", Pchar.questTemp.sLocator, "none", "", "", "", sti(Pchar.questTemp.iTime));
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;




        case "sfight":

			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
            LAi_group_Attack(NPChar, Pchar);

		break;

        case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
   	        LAi_SetWarriorTypeNoGroup(NPChar);
			LAi_group_Attack(NPChar, Pchar);
            AddDialogExitQuest("MainHeroFightModeOn");
			chrDisableReloadToLocation = false;
            LAi_CharacterPlaySound(npchar, "toArm");

		break;

        case "Qfight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
   	        LAi_SetWarriorType(NPChar);
            LAi_group_MoveCharacter(NPChar, "TmpEnemy");
			LAi_group_FightGroups("TmpEnemy", LAI_GROUP_PLAYER, true);
			LAi_group_FightGroups(GetNationNameByType(ENGLAND) + "_citizens", LAI_GROUP_PLAYER, true);
			AddDialogExitQuest("MainHeroFightModeOn");
			chrDisableReloadToLocation = true;
			//#20190120-03
			LAi_group_SetCheck("TmpEnemy", "OpenTheDoors");

		break;

		case "Finish":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			RestoreBridgetown();
			initMainCharacterItem();
            ref mc = GetMainCharacter();
            mc.Ship.Type = GenerateShipExt(SHIP_ARABELLA, true, mc);
            mc.Ship.name="Arabella";
            SetBaseShipData(mc);
            mc.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS32;
            SetCrewQuantityFull(mc);

            SetCharacterGoods(mc,GOOD_FOOD,2000);
        	SetCharacterGoods(mc,GOOD_BALLS,2000);//2000);
            SetCharacterGoods(mc,GOOD_GRAPES,300);//700);
            SetCharacterGoods(mc,GOOD_KNIPPELS,400);//700);
            SetCharacterGoods(mc,GOOD_BOMBS,2000);//1500);
            SetCharacterGoods(mc,GOOD_POWDER,2000);
            SetCharacterGoods(mc,GOOD_PLANKS,10);
            SetCharacterGoods(mc,GOOD_RUM,40);//600);
            SetCharacterGoods(mc,GOOD_WEAPON,2000);//2000);
            DoReloadCharacterToLocation(Pchar.HeroParam.Location, Pchar.HeroParam.Group, Pchar.HeroParam.Locator);
		break;

        case "Man_FackYou":
			dialog.text = LinkRandPhrase("Du vol en plein jour !!! Qu'est-ce que c'est que ces manières ?! Attends une minute, l'ami...", "Hé, qu'est-ce que tu fais là ?! Pas possible, tu essaies de me voler ? Eh bien, tu es fini...", "Attends, oם vas-tu ? Tu es donc un voleur ! Eh bien, considère que tu as fini de naviguer, mon cher...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, merde !");
			link.l1.go = "Qfight";
		break;

        case "Draguns_0":
			dialog.text = LinkRandPhrase("Le voilà, tenez-le !", "Attrapez-le, les gars !", "Une minute !");
			link.l1 = LinkRandPhrase("Diable !!", "Pas question !", "Oh, merde !");
			link.l1.go = "Draguns_1";
 		     NextDiag.TempNode = "Draguns_0";
		break;

        case "Draguns_1":

            LAi_group_FightGroups("TmpEnemy", LAI_GROUP_PLAYER, true);
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

		break;

		case "First time":
        	dialog.text = "Erreur";
            link.l1 = "...";
            link.l1.go = "Exit";


            if (CheckAttribute(npchar, "CityType") && npchar.CityType == "soldier")
            {

                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape2_1")
                {
                    dialog.text = "Passe ton chemin et ne me dérange pas.";
					link.l1 = "J'ai bien peur que ce soit une affaire sérieuse. Un espion espagnol s'est introduit en ville, peut-être même un mercenaire. Il est entré dans la maison de l'armurier, et maintenant, la porte de Griffin est fermée à double tour.";
					link.l1.go = "SQStep_0";
					Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape2_2";
				    break;
                }

               	if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY || ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 0) <= -15)
                {

    				dialog.text = RandPhraseSimple("Halte ! Rends tes armes ! Suis-moi !", "Un esclave en fuite ! Attrapez-le immédiatement !");
    				link.l1 = RandPhraseSimple("Ferme-la, petit idiot !", "Pas question !");
    				link.l1.go = "sfight";
    				break;
				}

        		switch (rand(5))
					{
						case 0: ////////////////////////////////////////
							dialog.text = "Qu'est-ce qu'un esclave fait à traîner ici sans rien faire ?";
							link.l1 = "Je fais une course pour le colonel Bishop.";
							link.l1.go = "exit";
						break;

						case 1:
							dialog.text = "Oh, c'est vous, docteur Blood. Vous m'avez soigné quand on m'a débarqué du Pride of Devon.";
							link.l1 = "Je suis content que vous vous soyez rétabli.";
							link.l1.go = "exit";
						break;

						case 2: ///////////////////////////////////////////
							dialog.text = "Fiche le camp, esclave !";
							link.l1 = "Moi aussi, je suis content de vous voir, qui que vous soyez.";
							link.l1.go = "exit";
						break;

						case 3:
							dialog.text = "Quel temps, et moi, je dois rester planté ici. Ma seule distraction, c'est de chasser les mouches de ma figure.";
							link.l1 = "J'en suis désolé. Mais je ne peux pas vous aider, c'est votre travail.";
							link.l1.go = "exit";
						break;

						case 4: ///////////////////////////////////////////
							dialog.text = "Si tu veux bavarder, trouve quelqu'un d'autre, ou mieux encore, retourne aux plantations.";
							link.l1 = "Absolument.";
							link.l1.go = "exit";
						break;



						case 5: ////////////////////////////////////////////
							dialog.text = "Passe ton chemin et ne me dérange pas.";
							link.l1 = "Comme vous voudrez, soldat.";
							link.l1.go = "exit";
						break;


					}
    		}

    		if (CheckAttribute(npchar, "CityType") && npchar.CityType == "citizen")
    		{
            	dialog.text = TimeGreeting() + ", docteur.";
        		link.l1 = "Bonjour.";
        		link.l1.go = "Exit";
        		if( Pchar.questTemp.CapBloodLine.stat == "WakerOffer")
        		{
                    link.l2 = RandPhraseSimple("Pouvez-vous me dire oם je peux trouver le docteur Wacker ?", "J'ai besoin du docteur Wacker. Vous l'avez vu ?");
                    link.l2.go = "Citizen_0";
                }
                if(CheckAttribute(Pchar, "questTemp.CapBloodLine.ShipForJack") && Pchar.questTemp.CapBloodLine.ShipForJack == true)
                {
                    Link.l2 = RandPhraseSimple("J'ai besoin de me rendre quelque part : pouvez-vous m'indiquer un capitaine honnête ?", "Je cherche un capitaine qui emmènerait un ami à moi quelque part, pour un prix raisonnable. Vous avez quelqu'un en tête ?");
    				Link.l2.go = "Citizen_1";
                }
    		}

    		if (CheckAttribute(npchar, "CityType") && npchar.CityType == "citizen" && npchar.location.group == "merchant")
    		{
                if(findsubstr(Pchar.questTemp.CapBloodLine.stat, "PrepareToEscape" , 0) != -1)
                {
                        if (CheckAttribute(npchar, "quest.bGoodMerch") && sti(Pchar.reputation) > 60)
                        {
                            dialog.text = "Oh, docteur Blood, bonjour ! Je ne vous ai toujours pas remercié."+NPCharSexPhrase(NPChar, " ", "e")+"merci, donc, d'avoir sauvé mon petit garçon ; j'y repense souvent, et je regrette de ne pas l'avoir fait plus tכt. Comme c'est bien de vous avoir rencontré aujourd'hui !";
                            link.l1 = "En effet, c'est agréable que les gens cherchent à vous remercier au moment le plus opportun. Pourriez-vous me dire, "+NPCharSexPhrase(NPChar, "mon cher ami", "ma chère")+", oם je pourrais me procurer quelques coutelas et deux pistolets, au plus vite et sans trop de bruit ni d'agitation ?";
                            link.l1.go = "Merchant_0";
                            break;
                        }
                }
                if (CheckAttribute(npchar, "quest.bGoodMerch"))
                {
                    dialog.text = TimeGreeting() + ", docteur.";
                    link.l1 = "Bonjour.";
                }
                else
                {
                    dialog.text = "Tu bloques ma marchandise. Dégage, charogne d'esclave !";
                    link.l1 = "Je m'en vais.";
                }
        		link.l1.go = "Exit";
				if (CheckAttribute(pchar, "SeekVolverstonRum") && !CheckCharacterItem(pchar, "potionrum") && !CheckAttribute(npchar, "VolverstonRum_fail") && !CheckAttribute(npchar, "quest.bGoodMerch"))
				{
					link.l2 = "Vous auriez une bouteille de rhum à vendre, par hasard ?";
                    link.l2.go = "Merchant_VolverstonRum";
				}
    		}
    		//Рабы на плантациях - постоянный диалог
    		if (CheckAttribute(npchar, "CityType") && npchar.CityType == "citizen" && findsubstr(npchar.id, "Slave_" , 0) != -1)
    		{
			    dialog.text = RandPhraseSimple(RandPhraseSimple("Je n'en peux plus de fatigue, je tiens à peine debout.", "Je n'ai plus la force de vivre comme ça !"), RandPhraseSimple("Ce travail est trop dur pour moi.", "Les contremaîtres ne m'ont pas laissé un pouce de peau intact !"));
				if(CheckAttribute(pchar, "GenQuest.CaptainComission") && pchar.GenQuest.CaptainComission.GetSlave == "NoSlave")
				{
					link.l1 = RandPhraseSimple("Oui, la vie en captivité est une rude épreuve. Et dites-moi, y aurait-il parmi vous " + pchar.GenQuest.CaptainComission.SlaveName + " ?", "Oui, on ne vous envie pas... Quelque part dans la plantation, il doit y avoir un esclave nommé " + pchar.GenQuest.CaptainComission.SlaveName + ". Vous le connaîtriez, par hasard ?");
					link.l1.go = "CapComission_1";
				}
				else
				{
					link.l1 = RandPhraseSimple("Je suis désolé, l'ami.", "Tu me fais de la peine.");
					link.l1.go = "exit";
				}
    		}

    		if (npchar.id == "Bridgetown_Poorman")
    		{
            	dialog.text = "Hé, petit, lance une pièce... Oh, c'est vous, docteur Blood.";
        		link.l1 = "Bonne chance.";
        		link.l1.go = "Exit";
    		}

    		if (npchar.id == "QuestCitiz_Bridgetown")
    		{
            	dialog.text = TimeGreeting() + ", docteur.";
        		link.l1 = "Toi aussi.";
        		link.l1.go = "Exit";
    		}

    		if (npchar.id == "SolderTakeBlades")
    		{
                dialog.text = RandPhraseSimple("Depuis quand les esclaves se promènent-ils avec des armes ?", "Tu es l'esclave du colonel Bishop, pourquoi es-tu armé ?");
        		link.l1 = RandPhraseSimple("Euh...", "Je ne comprends pas moi-même...");
        		link.l1.go = "STBStep_0";
    		}

    		if (npchar.id == "Winterwood")
    		{

                if(npchar.location == "Bridgetown_Brothel_room")
                {
                    dialog.text = "Qu'est-ce que tu veux ici, bon sang ?! Dehors, tout de suite !";
                    link.l1 = "Désolé, mais cette femme est à moi.";
                    link.l1.go = "WWStep_7";
                    break;
                }
                dialog.text = "Qu'est-ce que tu veux ici, bon sang ?! Dehors, tout de suite !";
        		link.l1 = "Ne soyez pas grossier ! J'ai une affaire à vous proposer.";
        		link.l1.go = "WWStep_0";
    		}

    		if (npchar.id == "Quest_Habitue")
    		{
				dialog.text = "Et... hic ! Oh, l'ami, tu as l'air d'un vieux loup de mer aguerri ! Tu ne me paierais pas un verre de rhum ?";
				link.l1 = "Je suis peut-être un loup de mer, mais ça ne veut pas dire que je vais boire n'importe quelle piquette...";
				link.l1.go = "exit";
    		}

    		if (npchar.id == "Weston")
    		{
				dialog.text = "Sortez de chez moi !";
				link.l1 = "Je m'en vais.";
				link.l1.go = "exit";
    		}

    		if (npchar.id == "MoneySpy")
    		{
                if(npchar.quest.meeting == "1")
                {
                    dialog.text = "Fichez le camp !";
    				link.l1 = "Je m'en vais.";
    				link.l1.go = "exit";
                }
                else
                {
                    npchar.quest.meeting = "1";
                    dialog.text = "Enfin ! Je croyais que tu ne viendrais pas ! Alors, euh, tu as appris quelque chose ?";
    				link.l1 = "Vous me prenez pour quelqu'un d'autre.";
    				link.l1.go = "MSStep_0";
    				link.l2 = "Euh-euh... oui, bien sמr.";
    				link.l2.go = "MSStep_1";
                }
    		}

    		if (npchar.id == "Fisherman")
    		{
                dialog.text = "Tu ne me paierais pas un godet, hein ? Hic..";
    			link.l1 = "Je ne crois pas.";
                link.l1.go = "exit";
    		}

    		if (npchar.id == "QStranger")
    		{
                dialog.text = "Que voulez-vous ?";
    			link.l1 = "Je suis venu savoir si vous comptiez quitter la ville en oubliant que vous devez trente mille à quelqu'un ?";
                link.l1.go = "QSTStep_0";
    			link.l2 = "Hé, mon vieux, qu'est-ce que tu fais ? Tu m'as complètement oublié ?";
                link.l2.go = "QSTStep_1";
    			link.l3 = "J'ai bien peur que votre situation soit grave. Votre supercherie, euh... Raf, a été découverte. Si vous ne rendez pas immédiatement les 30 000 aux usuriers, vous serez pendu ce soir !";
                link.l3.go = "QSTStep_2";
    		}


		break;

		case "CapComission_1":
			dialog.text = "Il n'a pas eu de chance aujourd'hui. Le pauvre homme a été fouetté et mis aux fers. Vous le trouverez dans la cour de la caserne. J'ai bien peur qu'il ne tienne pas longtemps sous un soleil pareil...";
			link.l1 = "Merci, l'ami.";
			link.l1.go = "exit";
		break;


		case "Citizen_0":

            if (!CheckAttribute(npchar, "quest.btmp"))
            {
                npchar.quest.btmp = true;
                if(rand(3)==2)
                {
                    dialog.text = LinkRandPhrase("Il est parti au trot vers la taverne : cherchez là-bas. N'oubliez pas de regarder sous les tables.", "Il est allé à la taverne il y a peu, je crois. Si je me souviens bien, il n'en est pas ressorti.", "Il vient de faire un saut à la taverne... Vous avez la gueule de bois, ou quoi ?");
                    link.l1 = "Merci.";
                    link.l1.go = "Exit";
                }
                else
                {
                    dialog.text = RandPhraseSimple(RandPhraseSimple("Je ne sais pas, fichez le camp !", "Je ne peux pas vous aider."), RandPhraseSimple("Allez, charogne d'esclave !", "Et qui est-ce ? Je ne connais que le docteur Blood... Oh, c'est vous, bonjour."));
                    link.l1 = "Merci.";
                    link.l1.go = "Exit";
                }

            }
            else
            {
                dialog.text = "Docteur, vous m'avez déjà demandé ça.";
                link.l1 = "Je suis désolé.";
                link.l1.go = "Exit";
            }

		break;

		case "Citizen_1":

            dialog.text = LinkRandPhrase("Je ne peux pas vous aider.", "Avec tout le respect que je vous dois, docteur, dans votre situation, vous ne devriez pas demander ça.", "Hélas, je n'ai personne à vous recommander, docteur Blood.");
            link.l1 = "Merci.";
            link.l1.go = "Exit";

		break;

		case "Merchant_VolverstonRum":

        	dialog.text = "J'en ai. Ce sera cinq cents pièces.";
			if (pchar.money >= 500)
			{
				link.l1 = "Tenez. Donnez-la-moi.";
				link.l1.go = "Merchant_VolverstonRum_1";
			}
			link.l2 = "Qu'est-ce qui est si cher ? Je reviendrai.";
    		link.l2.go = "exit";

		break;

		case "Merchant_VolverstonRum_1":
			AddMoneyToCharacter(pchar, -500);
        	dialog.text = "Une minute. Et oם un esclave a-t-il trouvé une telle somme ? Je ne te donnerai rien. Considère que c'est le prix de mon silence. Maintenant, dehors, ou j'appelle la garde !";
    		link.l1 = "וcoutez, j'ai vraiment besoin de cette bouteille. C'est une question de vie ou de mort.";
    		link.l1.go = "Merchant_VolverstonRum_2";
		break;
		case "Merchant_VolverstonRum_2":
        	dialog.text = "D'accord. Paie encore mille, ou fiche le camp.";
			if (pchar.money >= 1000)
			{
				link.l1 = "Tenez, étouffez-vous avec votre argent !";
				link.l1.go = "Merchant_VolverstonRum_3";
			}
			else
			{
				link.l1 = "Mais je n'en ai pas autant...";
				link.l1.go = "Merchant_VolverstonRum_2_1";
			}

		break;

		case "Merchant_VolverstonRum_2_1":
			npchar.VolverstonRum_fail = true;
        	dialog.text = "Dans ce cas, dehors ! Et ne me demande plus rien.";
    		link.l1 = "Je n'y songerais même pas.";
    		link.l1.go = "exit";

		break;

		case "Merchant_VolverstonRum_3":
			npchar.VolverstonRum_fail = true;
			AddMoneyToCharacter(pchar, -1000);
			TakeNItems(PChar, "potionrum", 1);
        	dialog.text = "Ha, il te reste de l'argent ? D'accord, prends ta bouteille. Et ne m'ennuie plus, esclave.";
    		link.l1 = "Oui, maintenant, je ne m'approcherai plus de vous, même à portée de canon.";
    		link.l1.go = "exit";

		break;

		case "Merchant_0":

        	dialog.text = "Je ne vous demanderai pas à quoi ça vous servira, et si on me pose la question, je n'aurai pas à mentir ni à me défiler. Cependant, on ne me demandera pas de rapport avant après-demain, donc...";
    		link.l1 = "Après-demain, vous pourrez dire en toute tranquillité que vous avez prêté plusieurs sabres et pistolets au docteur Peter Blood, qui était médecin à Bridgetown. Je ne pense pas que le colonel Bishop y verra d'inconvénient...";
    		link.l1.go = "Merchant_1";

		break;

		case "Merchant_1":

        	dialog.text = "Mon fils vous doit la vie, et moi aussi d'ailleurs. Tenez, prenez ceci, docteur Blood. Et bonne chance !";
    		link.l1 = "Merci beaucoup.";
    		link.l1.go = "Exit";
            NextDiag.TempNode = "Merchant_2";
            if (Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape") Pchar.questTemp.CapBloodLine.stat = "ReadyToEscape";//fix чтоб не сбивать
            GiveItem2Character(Pchar, "Weapon_for_escape");                                                                 //уже начатые варианты
            AddQuestRecord("WeaponsForEscape", "10");
    		CloseQuestHeader("WeaponsForEscape");

		break;

		case "Merchant_2":

        	dialog.text = "Et bonne chance à vous, docteur Blood !";
    		link.l1 = "Merci.";
    		link.l1.go = "Exit";
    		NextDiag.TempNode = "Merchant_2";

		break;


		// ==> Забираем клинки, пистоли.
		case "STBStep_0":
        	dialog.text = "Allez, rends-moi immédiatement toutes tes armes ! Il faudrait dire au colonel Bishop de te flanquer une bonne raclée...";
    		link.l1 = "Tenez, prenez-les, et n'en parlons plus.";
    		link.l1.go = "STBStep_1";
            link.l2 = "Maintenant, on va voir qui va flanquer une raclée à qui !";
            link.l2.go = "fight";
		break;

		case "STBStep_1":

                dialog.text = "Oh, bon, fiche le camp.";
                link.l1.go = "Exit_Away";
                Pchar.questTemp.sLocator = "reload1_back";
                Pchar.questTemp.iTime = 40;
                RemoveCharacterEquip(pchar, BLADE_ITEM_TYPE);
                RemoveCharacterEquip(pchar, GUN_ITEM_TYPE);
				string blads_blade;
				string blads_dagger = "";
				while (FindCharacterItemByGroup(pchar, BLADE_ITEM_TYPE) != "")
                {
					blads_blade = FindCharacterItemByGroup(pchar, BLADE_ITEM_TYPE);
					if (CheckAttribute(Pchar, "questTemp.CapBloodLine.dagger") && Pchar.questTemp.CapBloodLine.dagger == blads_blade) blads_dagger = blads_blade;
                    TakeItemFromCharacter(pchar, blads_blade);
                }
				if (blads_dagger != "") GiveItem2Character (PChar, blads_dagger);
                while (FindCharacterItemByGroup(pchar, GUN_ITEM_TYPE) != "")
                {
                    TakeItemFromCharacter(pchar, FindCharacterItemByGroup(pchar, GUN_ITEM_TYPE));
                }
                //GiveItem2Character(Pchar, "unarmed");
                //EquipCharacterByItem(Pchar, "unarmed");
                SetNewModelToChar(Pchar);
                //свободен
                pchar.quest.CapBloodDetectBlades1.over = "yes";
                pchar.quest.CapBloodDetectBlades2.over = "yes";
                chrDisableReloadToLocation = false;

		break;

		case "STBStep_2":
        	dialog.text = "Le colonel Bishop te cherche. Va immédiatement à la plantation...";
    		link.l1 = "Comme vous voudrez.";
            link.l1.go = "Exit_Away";
            //link.l1.go = "finish";
            Pchar.questTemp.sLocator = "gate1_back";
            Pchar.questTemp.iTime = -1;

            chrDisableReloadToLocation = false;
            pchar.quest.CapBloodEscape2.win_condition.l1          = "location";
            pchar.quest.CapBloodEscape2.win_condition.l1.location = "Bridgetown_Plantation";
            pchar.quest.CapBloodEscape2.function                  = "ReturnToPlantation2";

            sld = characterFromID("Hugtorp");
            sld.Dialog.CurrentNode = "HTStep_14";
            ChangeCharacterAddressGroup(sld, "BridgeTown_Plantation", "goto", "goto18");
		break;

		//замечение по обнажённому оружию
		case "SoldierNotBlade":

            if (Pchar.questTemp.CapBUnarmed == false )
            {
                dialog.text = LinkRandPhrase("Pourquoi diable cours-tu en ville avec une lame dégainée ? Range ton arme immédiatement !", "Je vous ordonne de rengainer votre arme immédiatement !", "Hé, l'ami, arrête de faire peur aux gens ! Rengaine ton arme.");
                link.l1 = LinkRandPhrase("Bien.", "D'accord.", "Comme vous voudrez...");
    			link.l1.go = "exit";
                link.l2 = LinkRandPhrase("Au diable tout ça !", "On peut toujours rêver...", "א la saint-glinglin.");
                link.l2.go = "fight";
			}
            else
            {
                dialog.text = RandPhraseSimple("Depuis quand les esclaves se promènent-ils partout avec des armes ?", "Tu es l'esclave du colonel Bishop, pourquoi es-tu armé ?")+"\nAllez, rends-moi immédiatement toutes tes armes ! Il faudrait dire au colonel Bishop de te flanquer une bonne raclée...";
                link.l1 = "Tenez, et n'en parlons plus.";
                link.l1.go = "SoldierNotBladeEx";
                link.l2 = "Maintenant, on va voir qui va flanquer une raclée à qui !";
                link.l2.go = "fight";
            }
			npchar.greeting = "soldier_common";
			NextDiag.TempNode = "First Time";
		break;

		case "SoldierNotBladeEx":

                RemoveCharacterEquip(pchar, BLADE_ITEM_TYPE);
                RemoveCharacterEquip(pchar, GUN_ITEM_TYPE);
                while (FindCharacterItemByGroup(pchar, BLADE_ITEM_TYPE) != "" )
                {
                    TakeItemFromCharacter(pchar, FindCharacterItemByGroup(pchar, BLADE_ITEM_TYPE));

                }
                while (FindCharacterItemByGroup(pchar, GUN_ITEM_TYPE) != "")
                {
                    TakeItemFromCharacter(pchar, FindCharacterItemByGroup(pchar, GUN_ITEM_TYPE));
                }
                //свободен
                pchar.quest.CapBloodDetectBlades1.over = "yes";
                pchar.quest.CapBloodDetectBlades2.over = "yes";

                iChar = GetCharacterIndex("SolderTakeBlades");
                if (iChar != -1)
                {
                    sld = &characters[iChar];
                    LAi_ActorGoToLocation(sld, "reload", "reload1_back", "none", "", "", "", -1);
                    chrDisableReloadToLocation = false;
                }
                NextDiag.CurrentNode = NextDiag.TempNode;
                DialogExit();

		break;


        // --> Квестовый солдат


 		case "SQStep_0":

            dialog.text = "L'Espagnol ? Vous plaisantez !.. L'Espagnol ne pourrait pas... ou bien... ?";
        	link.l1 = "Je vous assure, c'était un Espagnol.";
            link.l1.go = "SQStep_1";
		break;

 		case "SQStep_1":

            dialog.text = "J'y vais immédiatement. Oם se trouve cette maison ?";
        	link.l1 = "C'est la maison de M. Griffin, elle n'est pas loin du domaine du gouverneur.";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.sLocator = "houseSp2";
            Pchar.questTemp.iTime = 20;

            string smodel = NPChar.model;
            if (findsubstr(smodel, "eng_mush" , 0) != -1) smodel = "sold_eng_"+(rand(7)+1);
            sld = GetCharacter(NPC_GenerateCharacter("CPBQuest_Solder", smodel, "man", "man", 10, ENGLAND, 1, false));
            sld.dialog.filename = "Quest\CapBloodLine\questNPC.c";
            SetFantomParamHunter(sld); //крутые парни
            sld.SaveItemsForDead = true; // сохранять на трупе вещи
            sld.DontClearDead = true;
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorSetLayMode(sld);
            LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "CommonFlamHouse", "reload", "reload3");

            sld = &characters[GetCharacterIndex("Griffin")];
            ChangeCharacterAddressGroup(sld, "CommonRoom_MH4", "barmen", "bar1");
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorTurnToLocator(sld, "goto", "goto2");
            LAi_SetStayTypeNoGroup(sld);
            sld = &characters[GetCharacterIndex("Spain_spy")];
            ChangeCharacterAddressGroup(sld, "CommonRoom_MH4", "goto", "goto2");
            sld.dialog.currentnode = "SSStep_3";
            LAi_SetActorType(sld);
            LAi_ActorDialog(sld, pchar, "", 0, 0);
             //#20190120-02
            LocatorReloadEnterDisable("BridgeTown_town", "houseSp2", false);


            pchar.quest.PrepareToEscape2_3.win_condition.l1          = "location";
            pchar.quest.PrepareToEscape2_3.win_condition.l1.location = "CommonFlamHouse";
            pchar.quest.PrepareToEscape2_3.function                  = "_DeadSolder";

            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape2_3";
            DoQuestFunctionDelay("SpainSpyAttack", 20.0);

		break;
        // --> Квестовый раб

        case "SLQStep_0":

            dialog.text = "Bonjour, monsieur Blood, vous êtes bien notre médecin ? Vous me donneriez un remède contre le mal de tête ? Parfois, j'ai si mal à la tête que ça en devient insupportable.";
            if (GetCharacterItem(pchar, "migraine_potion") > 0)
            {
           	    link.l0 = "Tenez, prenez ce remède : il guérira votre migraine.";
                link.l0.go = "SLQStep_3";
            }
        	link.l1 = "Malheureusement, je n'ai rien contre le mal de tête. Et le colonel Bishop ne donnera sans doute pas d'argent pour acheter le remède nécessaire, puisqu'il croit que toutes les maladies de ses esclaves viennent de l'oisiveté. Hélas, je ne peux que vous conseiller de vous reposer davantage quand c'est possible.";
            link.l1.go = "SLQStep_1";

        break;

        case "SLQStep_1":

            dialog.text = "Docteur, dans ma situation, il est difficile de suivre votre conseil. Je n'ai pas d'argent, mais j'ai quelque chose qui pourrait vous être très utile. Alors, si vous arrivez à me procurer quelque chose, je ne resterai pas en dette.";
        	link.l1 = "D'accord, je vais essayer de vous procurer un remède.";
            link.l1.go = "Exit";
           	NextDiag.TempNode = "SLQStep_2";

        break;

        case "SLQStep_2":

            dialog.text = "Vous me donnerez le remède, docteur ?";
            if (GetCharacterItem(pchar, "migraine_potion") > 0)
            {
            	link.l1 = "Oui, j'ai apporté le remède contre la migraine.";
                link.l1.go = "SLQStep_3";
           		link.l2 = "Plutכt pas.";
                link.l2.go = "Exit";
             }
             else
             {
            	link.l1 = "Non, je n'ai pas encore réussi à trouver le bon remède.";
                link.l1.go = "Exit";
             }
           	NextDiag.TempNode = "SLQStep_2";

        break;

        case "SLQStep_3":

            dialog.text = "Merci, docteur. En signe de gratitude, acceptez ce poignard : je le cache aux contremaîtres depuis longtemps, mais je pense que vous en aurez plus besoin que moi.";
        	link.l1 = "Oui, mais les esclaves n'ont pas le droit d'avoir des armes !";
            link.l1.go = "SLQStep_4";
            TakeItemFromCharacter(Pchar, "migraine_potion");
			Pchar.questTemp.CapBloodLine.dagger = GetGeneratedItem("blade5");
			if (CheckAttribute(Pchar, "questTemp.CapBloodLine.dagger")) GiveItem2Character(Pchar, Pchar.questTemp.CapBloodLine.dagger);

        break;


        case "SLQStep_4":

            dialog.text = "Ne vous inquiétez pas, docteur, il est facile de le cacher sous vos vêtements, personne ne remarquera rien. א moins que vous ne l'agitiez devant les soldats.";
        	link.l1 = "Merci, mon ami, rétablissez-vous bien.";
            link.l1.go = "Exit";
            NPChar.talker = 0;
           	NextDiag.TempNode = "First time";

        break;


        // --> Уинтервуд

        case "WWStep_0":

            dialog.text = "Qu'est-ce que tu racontes, vermine d'esclave ?! Quelle affaire peux-tu avoir avec moi ?!";
        	link.l1 = "J'ai besoin de cette bague...";
            link.l1.go = "WWStep_1";

        break;

        case "WWStep_1":

            dialog.text = "La bague ?! Je ne te la vendrai pour rien au monde ! Va t'en acheter une autre chez un marchand qui accepte de traiter avec un esclave !";
        	link.l1 = "Il ne me faut pas seulement cette bague, mais aussi le doigt qui la porte.";
            link.l1.go = "WWStep_2";

        break;

        case "WWStep_2":

            dialog.text = "Vous allez payer cher vos paroles !";
        	link.l1 = "Je m'en doutais. Ce genre de choses se règle mieux sans témoins. Venez à l'entrée de la ville dans une heure.";
            link.l1.go = "WWStep_3";

        break;

       	case "WWStep_3":
		Dialog.Text = "Bien, je te retrouve devant la porte dans une heure. J'apporterai même de la ferraille pour toi, pour que ça ressemble un peu à un duel.";
		link.l1 = "א bientכt.";
		link.l1.go = "WWStep_4";
        break;

		//что ж, пойдём выйдем
	case "WWStep_4":

        PChar.quest.CapBloodLineTimer_3.win_condition.l1            = "Timer";
        PChar.quest.CapBloodLineTimer_3.win_condition.l1.date.hour  = sti(GetTime() + 1);
        PChar.quest.CapBloodLineTimer_3.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 0);
        PChar.quest.CapBloodLineTimer_3.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
        PChar.quest.CapBloodLineTimer_3.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 0);
        PChar.quest.CapBloodLineTimer_3.function = "WinterwoodDuel";

		NextDiag.CurrentNode = "WWStep_5";
		DialogExit();
    break;

    case "WWStep_5":

		Dialog.Text = "Eh bien, que voulez-vous encore ?";
		link.l1 = "Je n'ai pas beaucoup de temps, je veux en finir avec toi tout de suite !";
		link.l1.go = "WWStep_5_1";
		link.l2 = "Je voulais juste vous rappeler notre rendez-vous.";
		link.l2.go = "Exit";
		NextDiag.TempNode = "WWStep_5";
        break;

    case "WWStep_5_1":
		Dialog.Text = "Hum, tu as choisi ton destin !";
		link.l1 = "Passons aux choses sérieuses.";
		link.l1.go = "WWStep_6";
    break;

	case "talk_off_town":
		Dialog.Text = "Alors, vous êtes prêt à aller en enfer ?";
		link.l1 = "Oui. Voyons maintenant qui vaut quoi !";
		link.l1.go = "WWStep_6";
		GiveItem2Character(Pchar, "blade2");
        EquipCharacterByItem(Pchar, "blade2");
        chrDisableReloadToLocation = false;
    break;

	//дуэли быть!
	case "WWStep_6":
		AddDialogExitQuestFunction("Winterwood_Prepare_Fight");
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();

	break;

    case "WWStep_7":

        dialog.text = "Qu'est-ce que tu racontes, vermine d'esclave ?!";
    	link.l1 = "Je viens vous annoncer que votre agréable passe-temps est annulé.";
        link.l1.go = "WWStep_8";

    break;

    case "WWStep_8":

        dialog.text = "Tu as trois secondes pour retourner d'oם tu es sorti en rampant, et prie pour qu'on ne se revoie pas.";
    	link.l1 = "J'ai une meilleure idée. Mettez-vous en colère et provoquez-moi en duel ; moi, j'attendrai sans bouger.";
        link.l1.go = "WWStep_3";
        n = FindLocation("Bridgetown_Brothel");
        locations[n].reload.l2.disable = true;

    break;

    // --> Алкаш

    case "QHStep_0":

		dialog.text = "Et... hic ! Oh, l'ami, tu as l'air d'un vieux loup de mer aguerri ! On boit un verre de rhum ? C'est ma tournée.";
		link.l1 = "Je suis peut-être un loup de mer, mais ça ne veut pas dire que je bois avec n'importe qui.";
		link.l1.go = "exit";
		link.l2 = "Je me joindrai volontiers à vous, pour la compagnie.";
		link.l2.go = "QHStep_1";
		NextDiag.TempNode = "QHStep_0";

    break;

	case "QHStep_1":
		NextDiag.TempNode = "begin_sit";
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		pchar.questTemp.friend_in_tavern = npchar.id;
		AddDialogExitQuest("alc");
	break;

	case "begin_sit":
		NextDiag.TempNode = "first time";
		dialog.snd = "Voice\HADI\HADI028";
		dialog.text = "Hic ! Voilà ce que j'appelle parler ! C'est comme ça qu'on fait chez nous ! Aujourd'hui, c'est moi qui régale !";
		link.l1 = "Tavernier, du rhum !";
		link.l1.go = "QHStep_2";
	break;

	case "QHStep_2":
		WaitDate("",0,0,0, 0, 30);
		dialog.text = LinkRandPhrase("Tu es un vrai ami ! Faisons connaissance !",
		                             "Hic ! Quel rhum ! Bon... Trinquons !",
									 "א ta santé, et à ta libération prochaine !");
		link.l1 = "Dis-moi, mon frère, quelles histoires courent dans les tavernes ?";
		link.l1.go = "QHStep_3";
	break;

	case "QHStep_3":
		dialog.text = "Rien de bien nouveau... Un marchand est arrivé récemment de la Jamaïque par bateau. On dit qu'il a apporté une cargaison très précieuse. Si je ne me trompe pas, c'est une vieille connaissance du colonel Bishop. Il loge dans l'une des maisons de la ville, il compte rester encore un jour ou deux.";
		link.l1 = "Oui, nous avons passé un bon moment ; bon, je dois y aller.";
		link.l1.go = "exit_sit";
		NextDiag.TempNode = "First time";

		if (CheckNationLicence(HOLLAND)) TakeNationLicence(HOLLAND);
		sTemp = NationShortName(HOLLAND)+"TradeLicence";
		ref rItem = ItemsFromID(sTemp);
		SaveCurrentNpcQuestDateParam(rItem, "Action_date");
		rItem.Action_date = GetCurrentDate();
		rItem.Validity = FindRussianDaysString(24);
		rItem.Validity.QtyDays = 24;

       // pchar.GenQuestBox.CommonStoneHouse = true;
       // pchar.GenQuestBox.CommonStoneHouse.stay = true;

        n = FindLocation("CommonStoneHouse");
        locations[n].private1.items.indian1 = 1;
        locations[n].private1.items.HolTradeLicence = 1;
        locations[n].private1.items.potionrum = 1;
        locations[n].private1.money = 6000;




       // pchar.GenQuestBox.CommonStoneHouse.box1.money = 6000;
       // pchar.GenQuestBox.CommonStoneHouse.box1.items.EngTradeLicence = 1;
       // pchar.GenQuestBox.CommonStoneHouse.box1.items.indian1 = 1;

        //Чарльз Вестон
       	sld = GetCharacter(NPC_GenerateCharacter("Weston", "trader_3", "man", "man", 10, ENGLAND, 1, false));
        sld.dialog.filename = "Quest\CapBloodLine\questNPC.c";
        sld.name = "Charles";
        sld.lastname = "Weston";
		sld.greeting = "Gr_bankeer";
        FantomMakeCoolFighter(sld, 7, 100, 50, "topor2", "", 10);
       	LAi_SetImmortal(sld, true);
       	sTemp = GetNationNameByType(ENGLAND) + "_citizens";
        LAi_group_MoveCharacter(sld, sTemp);
        LAi_SetOwnerTypeNoGroup(sld);
        ChangeCharacterAddressGroup(sld, "CommonStoneHouse", "barmen", "stay");

        pchar.quest.MoneyForDieke.win_condition.l1 = "item";
        pchar.quest.MoneyForDieke.win_condition.l1.item = "HolTradeLicence";
        pchar.quest.MoneyForDieke.function = "MoneyForDieke";
        AddQuestRecord("DiekeQuest", "3");

	break;

	case "exit_sit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("exit_sit");
	break;

    //Шпион

    case "MSStep_0":

        dialog.text = "Alors dehors !";
    	link.l1 = "";
        link.l1.go = "Exit";

    break;

    case "MSStep_1":

        dialog.text = "Alors, combien sont-ils ?";
    	link.l1 = "Ils sont tous là.";
        link.l1.go = "MSStep_2";
       	link.l2 = "Ils sont cinq.";
        link.l2.go = "MSStep_3";
       	link.l3 = "Ils sont plus nombreux que je ne pourrais compter.";
        link.l3.go = "MSStep_4";

    break;

    case "MSStep_2":

        dialog.text = "C'est tout ? Qu'est-ce que tu racontes ?! Va-t'en, maudite vermine !";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_3":

        dialog.text = "Cinq... hum. C'est logique. Ils sont armés ?";
    	link.l1 = "Ils ont des armes légères, ils ne les exhibent pas.";
        link.l1.go = "MSStep_5";
       	link.l2 = "Non, ils sont plutכt pacifiques.";
        link.l2.go = "MSStep_6";

    break;

    case "MSStep_4":

        dialog.text = "Leurs... quoi ?! Sors de chez moi, menteur ! ";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_5":

        dialog.text = "Je le savais ! C'est Griffin qui leur a vendu les armes ! Ils demandent après moi ou après ma marchandise ?";
    	link.l1 = "C'est vous qui les intéressiez, ils ont interrogé la garde.";
        link.l1.go = "MSStep_7";
       	link.l2 = "Ils essayaient de tirer quelque chose sur vous du tavernier.";
        link.l2.go = "MSStep_8";

    break;

    case "MSStep_6":

        dialog.text = "Pacifiques ? Tu es fou !";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_7":

        dialog.text = "La garde ? (rires) Un bouffon, mais malin ! Va au diable !";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_8":

        dialog.text = "Le vieux chien ne me trahira pas. Comment sont-ils entrés en ville ?";
    	link.l1 = "Le Cinco Llagas a accosté : ils sont venus à son bord.";
        link.l1.go = "MSStep_9";
       	link.l2 = "Ils sont entrés en ville de nuit, par la jungle.";
        link.l2.go = "MSStep_10";
       	link.l3 = "Ils sont ici depuis un bon moment, ils ne se sont simplement pas montrés.";
        link.l3.go = "MSStep_11";

    break;

    case "MSStep_9":

        dialog.text = "Sur... Un navire ? Mais... Tu mens ! Va te faire voir ! ";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_10":

        dialog.text = "La jungle... א cinq ? Tu es ridicule ! Fiche le camp. ";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_11":

        dialog.text = "C'est ça, je suis sמr de les avoir déjà vus. Bon, tu as fait du bon travail, l'ami. Encore une chose... Qui sont-ils ?";
    	link.l1 = "Des Espagnols.";
        link.l1.go = "MSStep_12";
       	link.l2 = "Des pirates.";
        link.l2.go = "MSStep_13";
       	link.l3 = "Des chasseurs de primes.";
        link.l3.go = "MSStep_14";

    break;

    case "MSStep_12":

        dialog.text = "Pas mal essayé... Je pense qu'ils t'ont déjà payé. Va-t'en.";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_13":

        dialog.text = "Des pirates ? (rires) Tu sais me faire rire, toi. Va au diable des mers !";
    	link.l1 = "...";
        link.l1.go = "exit";

    break;

    case "MSStep_14":

        dialog.text = "Prends ton argent. Dis-lui que je suis satisfait de ton travail.";
    	link.l1 = "...";
        link.l1.go = "exit";
        AddMoneyToCharacter(pchar, 1000);
        AddCharacterExpToSkill(pchar, "Sneak", 80);
        AddCharacterExpToSkill(pchar, "Fortune", 30);
    break;

    case "FStep_1":

        dialog.text = "Eh-eh... Aujourd'hui, je crois que c'est ma tournée. Comme hier, et avant-hier, et tous les jours depuis... Enfin, peu importe.";
        if(makeint(Pchar.money) >=4 )
        {
            link.l1 = "Non, laisse-moi régaler le meilleur pêcheur de la Barbade !";
            link.l1.go = "FStep_1_2";
        }
       	link.l2 = "Comme tu voudras, seigneur... des poissons.";
        link.l2.go = "FStep_1_3";

    break;

   	case "FStep_1_2":
		NextDiag.TempNode = "FStep_2";
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		pchar.questTemp.friend_in_tavern = npchar.id;
		AddDialogExitQuest("alc");
	break;

	case "FStep_1_3":
		NextDiag.TempNode = "FStep_3";
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		pchar.questTemp.friend_in_tavern = npchar.id;
		AddDialogExitQuest("alc");
	break;


    case "FStep_2":

        AddMoneyToCharacter(pchar, -2);
        dialog.snd = "Voice\HADI\HADI028";
        dialog.text = "Tu as sacrément raison ! Buvons à ça !";
    	link.l1 = "Au meilleur pêcheur ! (vous videz votre chope d'un trait) Depuis combien de temps tu fais ça, Arnie ?";
        link.l1.go = "FStep_4";

    break;

    case "FStep_3":

        dialog.snd = "Voice\HADI\HADI028";
        dialog.text = "Qu'est-ce qui ne te plaît pas ? Bon sang, je suis le meilleur pêcheur de tout l'archipel !";
    	link.l1 = "Pas difficile d'être le meilleur là oם il n'y a pas de poisson... Moi aussi, j'en ai pêché... du poisson.";
        link.l1.go = "FStep_5";


    break;

    case "FStep_4":

        AddMoneyToCharacter(pchar, -2);
        dialog.text = "דa fait des décennies, mon ami. Pas la première dizaine d'années... mais דA, ça ne m'était jamais arrivé, mille sabords...";
    	link.l1 = "QU'EST-CE qui ne t'était jamais arrivé ? Bon, buvons à דA !";
        link.l1.go = "FStep_6";

    break;

    case "FStep_5":

        dialog.text = "Non ? Pas de poisson ?! Il faut connaître les coins, imbécile ! J'ai trouvé un coin unique... Le filet se remplit à ras bord en une nuit, Dieu m'en est témoin !";
    	link.l1 = "Des coins... Moi aussi, j'ai cherché des coins, j'ai pêché partout... Il n'y a pas de poisson ici, et il n'y a pas de coins. Au diable la pêche, ça ne rapporte rien !";
        link.l1.go = "FStep_7";

    break;

    case "FStep_6":

        dialog.text = "Buvons un coup... Et ça... un tel... un tel coin... c'est...";
    	link.l1 = "...";
        link.l1.go = "FStep_8";
       	link.l2 = "Eh bien ? Quel est ce coin ?!";
        link.l2.go = "FStep_Fail";

    break;

    case "FStep_7":

        dialog.text = "Tu ne sais pas chercher ! Je peux te montrer comment c'est... Comment on le sent...";
    	link.l1 = "...";
        link.l1.go = "FStep_8";
       	link.l2 = "Eh bien ? Quel est ce coin ?!";
        link.l2.go = "FStep_Fail";

    break;

    case "FStep_8":

        Pchar.questTemp.CapBloodLine.fishplace = "Le cap Ragged Point.";
        dialog.text = "...C'est tout près. "+Pchar.questTemp.CapBloodLine.fishplace;
    	link.l1 = "Incroyable !.. Mais je dois y aller, maintenant.";
        link.l1.go = "exit_sit";
        NextDiag.TempNode = "First time";
        AddQuestRecord("FishermanQuest", "2");

    break;

    case "FStep_Fail":

        dialog.text = "Oh, toi... Va-t'en, espèce d'espion d'esclave !..";
    	link.l1 = "Que le diable des mers t'emporte !";
        link.l1.go = "exit_sit";
        NextDiag.TempNode = "First time";

    break;

    case "QSTStep_0":

        dialog.text = "Qui es-tu, d'abord ? Je m'appelle Alex Winner, je suis marchand ! Dehors, ou je te rachète à ton maître et je t'envoie par le fond avec un boulet dans les bras !";
    	link.l1 = "Hum...";
        link.l1.go = "Exit_Away";
        Pchar.questTemp.sLocator = "reload1_back";
        if(npchar.location == "CommonRoom_MH7") Pchar.questTemp.sLocator = "reload1"
        Pchar.questTemp.iTime = -1;
   		CloseQuestHeader("UsurerQuest");

    break;

    case "QSTStep_1":

        dialog.text = "Mmm... on se connaît ? J'aurais oublié... Comment t'appelles-tu ?";
    	link.l1 = "Bien sמr, Raf ! Mais... Si tu as oublié ma dette envers toi, alors...";
        link.l1.go = "QSTStep_3";

    break;


    case "QSTStep_2":

        dialog.text = "Qu'est-ce que vous racontez ? Je ne connais aucun usurier !.. Je... bon sang !";
    	link.l1 = "Donnez-moi l'argent, et je dirai au gouverneur Steed que vous l'avez rendu de votre plein gré, et je vous laisserai partir.";
        link.l1.go = "QSTStep_6";

    break;

    case "QSTStep_3":

        dialog.text = "Je me souviens... il me semble. C'est ça. Alors, quand est-ce que tu me rembourses ?";
    	link.l1 = "Une dette de vie, mon ami... Oם voudrais-tu mourir ? Ici même, peut-être ?";
        link.l1.go = "QSTStep_4";

    break;

    case "QSTStep_4":

        dialog.text = "Quoi ?!";
    	link.l1 = "Tu m'as trahi, Guinness ! J'ai tout perdu à cause de toi !.. Tu vas mourir !";
        link.l1.go = "QSTStep_5";

    break;

    case "QSTStep_5":

        PChar.quest.QUsurer.win_condition.l1            = "Timer";
        PChar.quest.QUsurer.win_condition.l1.date.hour  = 0;
        PChar.quest.QUsurer.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
        PChar.quest.QUsurer.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
        PChar.quest.QUsurer.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 0);
        PChar.quest.QUsurer.function = "QUsurerLate";

        AddMoneyToCharacter(pchar, 55000);
        ChangeCharacterReputation(PChar, -10);
        AddCharacterExpToSkill(pchar, "Leadership", 30);
        dialog.text = "Non, attends... regarde... j'ai 55 000. Prends tout !";
    	link.l1 = "Merci beaucoup, cher ami.";
        link.l1.go = "Exit_Away";
        Pchar.questTemp.sLocator = "reload1_back";
        if(npchar.location == "CommonRoom_MH7") Pchar.questTemp.sLocator = "reload1";
        Pchar.questTemp.iTime = -1;
        AddQuestRecord("UsurerQuest", "3");

    break;

    case "QSTStep_6":

        PChar.quest.QUsurer.win_condition.l1            = "Timer";
        PChar.quest.QUsurer.win_condition.l1.date.hour  = 0;
        PChar.quest.QUsurer.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
        PChar.quest.QUsurer.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
        PChar.quest.QUsurer.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 0);
        PChar.quest.QUsurer.function = "QUsurerLate";

        AddMoneyToCharacter(pchar, 30000);
        dialog.text = "Toi... Bon. Tiens, prends, prends, bon sang !";
    	link.l1 = "Merci beaucoup, cher ami.";
        link.l1.go = "Exit_Away";
        Pchar.questTemp.sLocator = "reload1_back";
        if(npchar.location == "CommonRoom_MH7") Pchar.questTemp.sLocator = "reload1"
        Pchar.questTemp.iTime = -1;
        AddQuestRecord("UsurerQuest", "4");

    break;

    //Жак Соловей

    case "JSTStep_0":

        dialog.text = "Bonjour, étranger. Vous êtes ici pour affaires ? Sinon, fichez le camp.";
    	link.l1 = "Ce n'est pas très poli... Et qui êtes-vous ? Je n'avais pas entendu dire que notre marchand avait changé.";
        link.l1.go = "JSTStep_1";

    break;

    case "JSTStep_1":

        dialog.text = "Peut-être... Parce qu'il n'a pas changé, hein, mon ami ?";
    	link.l1 = "Je n'ai pas l'honneur d'être votre ami. Laissez-moi deviner... Vous êtes un pirate ? Ou un simple voleur ?";
        link.l1.go = "JSTStep_2";

    break;

    case "JSTStep_2":

        dialog.text = "Vous êtes étonnamment ignorant ! Vous n'avez jamais entendu parler du capitaine Rolando Pizarro ?";
    	link.l1 = "J'aurais dמ ?";
        link.l1.go = "JSTStep_3";

    break;

    case "JSTStep_3":

        dialog.text = "Hum, permettez-moi de combler cette regrettable lacune dans vos connaissances. Je m'empresse donc de me présenter ! Le capitaine Rolando Pizarro, dit le Renard catalan ! Champion de la justice et de l'honneur ! Connu sur les sept mers, des glaces du nord jusqu'à...";
    	link.l1 = "Tout cela est très intéressant, mais que faites-vous ici, vous, le champion de la justice et ainsi de suite ?";
        link.l1.go = "JSTStep_4";
    break;

    case "JSTStep_4":

        dialog.text = "Moi ? Ce que je fais ici... Euh, eh bien, disons la même chose que vous ! Oui, exactement ! Pourquoi êtes-vous venu ici ?";
    	link.l1 = "Honnêtement ? Ou la version pour le public ?";
        link.l1.go = "JSTStep_6";

    break;

    case "JSTStep_6":

        dialog.text = "Soyons honnêtes, nous sommes amis maintenant, n'est-ce pas ? Quand deux personnes s'introduisent dans la même boutique au même moment, à l'insu du propriétaire, le Ciel lui-même leur dit de devenir amis, non ?";
    	link.l1 = "Vous avez déjà essayé de parler au Parlement ? Tant de discours, et pas une seule réponse. Bon, j'ai plus besoin d'argent que de nouvelles connaissances en ce moment, alors désolé, mais je dois partir.";
        link.l1.go = "JSTStep_7";

    break;

    case "JSTStep_7":

        dialog.text = "Hé, hé, ne vous pressez pas, monsieur ! Joignons l'utile à l'agréable : il se trouve que, par le plus pur des hasards, j'ai mis la main sur quelques pièces... et si vous décidez de poursuivre notre connaissance, certaines d'entre elles pourraient vous revenir. Disons, en signe d'amitié ?";
    	link.l1 = "Quelque chose me dit que cet arrangement ne sera pas du tout désintéressé...";
        link.l1.go = "JSTStep_8";

    break;

    case "JSTStep_8":

        dialog.text = "Eh bien, nous voilà de nouveau très officiels. C'est mauvais signe, vous ne trouvez pas ? Notre amitié commence déjà à se fissurer dès qu'il est question d'argent ?";
    	link.l1 = "Vous êtes un garçon étonnamment collant et bavard. Et en tout autre moment, je...";
        link.l1.go = "JSTStep_9";

    break;

    case "JSTStep_9":

        dialog.text = "Sans entrer dans les détails : trouvez-moi quelqu'un qui accepte de m'emmener à Portobelo pour trois mille, et je vous en donnerai mille cinq cents. Marché conclu ? Je pense que, dans votre situation, un peso de plus ne serait pas de trop ?";
    	link.l1 = "Oui... C'est une offre tentante. Et je n'ai pas vraiment le choix. Marché conclu.";
        link.l1.go = "JSTStep_10";
       	link.l2 = "Vous savez, vous devriez aller... tourner la tête aux demoiselles crédules de province ! J'en ai assez pour aujourd'hui.";
        link.l2.go = "Exit_Away";
        Pchar.questTemp.sLocator = "reload1_back";
        Pchar.questTemp.iTime = -1;

    break;

    case "JSTStep_10":

        dialog.text = "Une condition, mon chéri : pas de noms. Enfin, vous pouvez donner le vכtre, si vous voulez... Et le mien... dites que je l'ai oublié... ou plutכt... Dites plutכt que je suis une belle jeune femme !";
    	link.l1 = "Une jeune femme ? Voyez-vous ça. Bon, je trouverai quelque chose.";
        link.l1.go = "Exit_Away";
        Pchar.questTemp.sLocator = "reload1_back";
        Pchar.questTemp.iTime = -1;
        AddQuestRecord("PirateQuest", "1");
        Pchar.questTemp.CapBloodLine.ShipForJack = true;
       	sld = characterFromID("Bridgetown_trader");
   	    LAi_RemoveLoginTime(sld);

    break;

    case "JSTStep_11":

        dialog.text = "Ravi de vous voir, mon nouvel ami. Alors, avez-vous réussi à me rendre... le service convenu ?";
    	link.l1 = "La corvette « Floating Briton ». Le capitaine John Miner vous attend déjà.";
        link.l1.go = "JSTStep_12";

    break;

    case "JSTStep_12":

        dialog.text = "Eh bien, que dire : je m'incline et vous remercie infiniment, oh...";
    	link.l1 = "Aboulez les 1500 piastres, Rolando.";
        link.l1.go = "JSTStep_13";

    break;

    case "JSTStep_13":

        dialog.text = "Bien sמr, bien sמr ! Je voulais juste vous exprimer ma sincère gratitude et vous proposer de goמter ce merveilleux rhum, afin de sceller les liens d'une merveilleuse amitié par un toast commun qui, désormais...";
    	link.l1 = "Aboulez les 1500 piastres ! J'attends... mon nouvel ami.";
        link.l1.go = "JSTStep_14";

    break;

    case "JSTStep_14":

        dialog.text = "Silence ! Tenez, voici votre argent !..";
    	link.l1 = "Merci.";
        link.l1.go = "Exit";
        AddMoneyToCharacter(pchar, 1500);
        AddQuestRecord("PirateQuest", "5");
        CloseQuestHeader("PirateQuest");
        NextDiag.TempNode = "JSTStep_15";
        NPChar.lifeDay = 0;

    break;

    case "JSTStep_15":

        dialog.text = "Je vous suis reconnaissant... mon ami. Allez dépenser votre argent pour quelque chose de beau.";
    	link.l1 = "Et bonne chance à vous...";
        link.l1.go = "Exit";
        NextDiag.TempNode = "JSTStep_15";

    break;

    //Джон Майнер

    case "MNStep_0":

        dialog.text = "John Miner, capitaine de la corvette Floating Briton, à votre service. Que puis-je faire pour vous ?";
    	link.l1 = "Bonjour, je m'appelle Peter Blood. Puis-je vous demander un service, capitaine ? L'un de mes, euh... amis a vraiment besoin de se rendre à Portobelo, et il est prêt à se séparer de trois mille piastres.";
        link.l1.go = "MNStep_1";

    break;

    case "MNStep_1":

        dialog.text = "Puis-je connaître le nom de votre ami, monsieur Blood ?";
    	link.l1 = "Bien sמr. Il s'appelle... elle... bref, oui : en fait, c'est une femme...";
        link.l1.go = "MNStep_2";
       	link.l2 = "Bien sמr. Il s'appelle Rolando Pizarro, vous en avez entendu parler ?";
        link.l2.go = "MNStep_3";
       	link.l3 = "Non.";
        link.l3.go = "MNStep_4";

    break;

    case "MNStep_2":

        dialog.text = "Une jeune femme ? Votre ami... je veux dire, votre amie va à Portobelo ?";
    	link.l1 = "Pourquoi pas ? Portobelo est un port tout à fait convenable. Pourquoi la jeune femme n'irait-elle pas là-bas ?";
        link.l1.go = "MNStep_5";

    break;

    case "MNStep_3":

        dialog.text = "Je... J'en ai entendu parler, oui. Bon, je l'attends à bord. Merci pour votre réponse honnête, monsieur Blood.";
    	link.l1 = "L'honnêteté est une lame à double tranchant. Portez-vous bien. J'espère que vous ne regretterez pas votre décision.";
        link.l1.go = "MNStep_Exit";

    break;


    case "MNStep_4":

        dialog.text = "Non ? Comment puis-je accepter de prendre un passager si je ne connais même pas son nom ?!";
    	link.l1 = "Vous le pouvez. Disons que c'est une certaine Mme Taylor... Oui, c'est ça : Mme Taylor, qui... laquelle vous donnera trois mille en or si vous cessez de poser des questions.";
        link.l1.go = "MNStep_6";

    break;

    case "MNStep_5":

        dialog.text = "D'accord, je le prends... la prends. Dites à mon futur passager que le Floating Briton est prêt à appareiller.";
    	link.l1 = "Merci.";
        link.l1.go = "MNStep_Exit";
        AddCharacterExpToSkill(pchar, "Sneak", 50);

    break;

    case "MNStep_6":

        dialog.text = "Il fallait le dire tout de suite ! Marché conclu : j'attends Mlle Taylor à bord.";
    	link.l1 = "Mme Taylor, avec votre permission. Bonne journée, capitaine.";
        link.l1.go = "MNStep_Exit";

    break;

   	case "MNStep_Exit":

            AddQuestRecord("PirateQuest", "4");
            sld = characterFromID("Jack");
            sld.Dialog.CurrentNode = "JSTStep_11";
            LAi_SetSitTypeNoGroup(sld);
            ChangeCharacterAddressGroup(sld, "Bridgetown_tavern", "sit", "sit4");
            LAi_SetActorType(npchar);
 			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
	break;


    //Служанка Арабеллы

    case "ASStep_0":

        dialog.text = "Vous m'avez sauvé ? Qui êtes-vous ?!";
    	link.l1 = "Je suis Peter Blood, euh... le médecin du coin. Vous allez attendre que je vous montre mes papiers ? Et que diable se passe-t-il ici ?";
        link.l1.go = "ASStep_1";
        ChangeCharacterReputation(pchar, 5);

    break;

    case "ASStep_1":

        dialog.text = "Les Espagnols... ils sont... Ce grand navire, qu'on a laissé entrer si tranquillement dans notre baie aujourd'hui sous un faux pavillon, s'est révélé être un corsaire espagnol. Sa ruse du pavillon est restée si bien inaperçue que, sans éveiller le moindre soupçon, il est entré tranquillement dans la baie et a salué le fort, à bout portant, d'une bordée de vingt canons...";
    	link.l1 = "Et maintenant, si je comprends bien, l'équipage de ce corsaire pille la ville ?";
        link.l1.go = "ASStep_2";

    break;

    case "ASStep_2":

        dialog.text = "Oui, au coucher du soleil, notre garnison s'est rendue, et deux cent cinquante Espagnols sont devenus les maîtres de Bridgetown.";
    	link.l1 = "Voilà ce qu'on appelle l'intervention opportune du destin. Même si le diable seul sait ce qu'il en sortira ! Et vous, courez vous cacher dans la forêt jusqu'à ce que les Espagnols quittent la ville.";
        Pchar.questTemp.CapBloodLine.SpainInBridgetown = true;
        Pchar.questTemp.sLocator = "gate1_back";
        Pchar.questTemp.iTime = -1;
        link.l1.go = "Exit_RunAway";
        AddQuestRecord("EscapeFormBarbados", "3");

    break;


	}
}

