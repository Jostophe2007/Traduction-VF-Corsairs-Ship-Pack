// Gregg: the rivals' agent - the land variant of the GWIC "strike at the competitors" assignment.
// He never puts to sea; he sits in a colony tavern. The killing rides entirely on the stock duel framework:
// our own nodes lead up to the insult, then link.go = "land_duel" - and Common_Duel.c/duel.c handle both
// "outside the town gates" (a clean one-on-one duel) and "right here and now" (tavern clone, with bodyguards).
#include "DIALOGS\french\Common_Duel.c"

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	bool ok;

	ProcessDuelDialog(NPChar, link, NextDiag); // the duel nodes (outraged/land_duel/fight_*/talk_off_town/change_mind) are served by the framework

	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			NextDiag.TempNode = "First time";
			ok = false;
			if (CheckAttribute(pchar, "GWIK.Job") && CheckAttribute(pchar, "GWIK.Job.RivalLand")) ok = true;
			if (ok && pchar.GWIK.Job != "rival") ok = false;
			if (CheckAttribute(pchar, "GWIK.Job.Done")) ok = false; // already dead - unreachable, but let it stand
			if (!ok)
			{
				dialog.text = "Excusez-moi, j'ai des affaires à régler. Bonne journée.";
				link.l1 = "Je ne vous retiens pas.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Un rhum correct, pour un trou pareil, vous ne trouvez pas ? Asseyez-vous si vous avez quelque chose à me dire. Sinon, cessez de me boucher la lumière.";
			link.l1 = "Erreur de ma part. Bonne soirée.";
			link.l1.go = "exit";
			link.l2 = "Vous êtes " + GetFullName(NPChar) + ", n'est-ce pas ? L'homme qui fait des affaires ici dans le dos de la Compagnie des Indes occidentales.";
			link.l2.go = "GWIK_RivalTalk";
		break;

		case "GWIK_RivalTalk":
			dialog.text = "Ah, c'est donc ça. Les Hollandais ont envoyé quelqu'un pour me parler. Dans leur dos, dites-vous ? Elle est bien bonne. Ce sont eux qui se mêlent de mon commerce, pas l'inverse ; et entre nous, ils s'y prennent bien mal.";
			link.l1 = "La Compagnie vous a proposé des conditions. Vous avez craché sur la main qu'on vous tendait.";
			link.l1.go = "GWIK_RivalTalk2";
			link.l2 = "J'en ai assez entendu. Nous nous reverrons.";
			link.l2.go = "exit";
		break;

		case "GWIK_RivalTalk2":
			dialog.text = "J'ai craché sur la PATTE qu'on me tendait. Nuance. Et dites ceci à vos maîtres : tant que je respirerai, pas une de leurs cargaisons ne circulera dans ces eaux à leur prix.";
			link.l1 = "Tant que vous respirerez. Cette condition se change facilement.";
			link.l1.go = "GWIK_RivalProvoke";
			link.l2 = "Je le leur dirai. Mot pour mot.";
			link.l2.go = "exit";
		break;

		case "GWIK_RivalProvoke":
			// Gregg: bodyguards are armed UP FRONT - the framework only seats them for a fight inside the tavern
			// (Duel_Prepare_Fight does that solely when type=="tavern"), so a duel outside the gates stays one-on-one.
			// Duel_Kill_Enemy clears the attribute itself.
			pchar.questTemp.duel.enemyQty = 1 + rand(1);
			dialog.text = "Quoi ?.. Comment osez-vous, toutou des Hollandais ! Personne ici ne vous protégera : ni votre Compagnie, ni votre dieu !";
			link.l1 = "Alors, sortons des portes de la ville. Personne ne nous dérangera là-bas.";
			link.l1.go = "GWIK_RivalDuelOut";
			link.l2 = "Au diable la promenade. Ici et maintenant.";
			link.l2.go = "GWIK_RivalDuelHere"; // our own node: same as the stock fight_right_now, but the escort is stripped first
			link.l3 = "Vivez donc encore un peu. Nous reprendrons cette conversation plus tard.";
			link.l3.go = "exit";
		break;

		case "GWIK_RivalDuelOut":
			// Gregg: the "outside the gates" path is NOT handed to the framework (land_duel/fight_off_town_prep/talk_off_town):
			// that chain waits N hours, requires you to walk to the gates, offers a change of mind, cowardice and the opponent's
			// return - far too many states, they kept breaking and let the assignment hang. Here there is no way back:
			// the next line teleports you out of town and starts the fight.
			dialog.text = "Allons-y, alors. J'espère que vous maniez la lame mieux que la langue.";
			link.l1 = "Après vous.";
			link.l1.go = "GWIK_RivalDuelGo";
		break;

		case "GWIK_RivalDuelGo":
			AddDialogExitQuestFunction("GWIK_RivalDuelOutTown"); // teleport out of town + fight on arrival (pattern: fight_right_now -> Duel_Prepare_Fight)
			NextDiag.CurrentNode = "First time";
			DialogExit();
		break;

		case "GWIK_RivalDuelHere":
			// Gregg: mirrors the stock fight_right_now (tavern clone via Duel_Prepare_Fight) but strips the escort first:
			// a duel is one-on-one, yet officers and boarders followed the player into the clone as well.
			// The TARGET's bodyguards (questTemp.duel.enemyQty) stay.
			GWIK_RivalDuelOfficersOff();
			pchar.questTemp.duel.enemy = NPChar.id;
			AddDialogExitQuestFunction("Duel_Prepare_Fight");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "after_peace":
			// Gregg: we OVERRIDE the framework node. The stock after_peace offers only "I'm leaving" -> peace -> after_peace again,
			// so after a change of mind the target would be stuck in a peaceful node and could never be duelled.
			dialog.text = "Encore là ? Filez, tant que je suis de bonne humeur.";
			link.l1 = "Je m'en vais.";
			link.l1.go = "exit";
			link.l2 = "J'ai changé d'avis. Dégainez.";
			link.l2.go = "GWIK_RivalProvoke";
		break;
	}
}
