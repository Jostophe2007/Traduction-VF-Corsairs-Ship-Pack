void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	ref PChar = GetMainCharacter();
	string sName = PChar.name + " " + PChar.lastname; 
	
	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Oh, c'est vous, capitaine " + sName + ". On boit un coup ?";
			link.l1 = "Euh, je n'ai pas le temps en ce moment.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Ah, assieds-toi, brave âme ! Tu ne paierais pas un rhum à un vieux marin ?";
			link.l1 = "Bien sמr, mon vieux, je ne dis pas non à un verre ! Tavernier, du rhum !";
			link.l1.go = "exit";	
			AddDialogExitQuestFunction("MysteriousIslandTalkWithSmith");
			FreeSitLocator(PChar.location, "sit_front3");
		break;
		
		case "2":
			dialog.text = "Merci, capitaine ! Je suis toujours content de boire gratis, parce que cette taverne, c'est là que je passe le plus clair de ma vie, et je suis à court d'argent.";
			link.l1 = "Toute ta vie dans cette taverne ?! Que t'est-il arrivé, l'ami ?";
			link.l1.go = "3";
		break;
		
		case "3":
			dialog.text = "Ah, ne me le demande pas, capitaine ! C'est une histoire effrayante. Buvons plutכt !";
			link.l1 = "Tavernier, encore deux chopes de rhum !";
			link.l1.go = "4";
		break;
		
		case "4":
			LAi_Fade("", "");
			dialog.text = "Tu es "+GetSexPhrase("un brave gars", "une brave fille")+" ! Autrefois, j'étais comme toi, mais ma vie a tourné de telle sorte que maintenant, je dors à peine la nuit : je suis hanté par d'affreux cauchemars ! Bon sang... Il n'y a que dans le rhum que je trouve du réconfort...";
			link.l1 = "Confie-moi ton malheur, marin : ça te soulagera peut-être.";
			link.l1.go = "5";
		break;
		
		case "5":
			dialog.text = "Eh bien, écoute, alors. J'ai navigué autrefois sur la frégate pirate Starfish, sous les ordres du capitaine Davy Forser. Un jour, nous avons débarqué sur une île déserte. Le capitaine nous a menés dans une grotte, et quelle grotte, je te le dis : les coffres débordaient de toutes sortes de richesses ! Bref, nous en avons pris autant que nous pouvions et nous sommes retournés au navire. On nous avait attendus, mais notre capitaine n'était pas là. Nous l'avons cherché partout, mais rien. Nous avons cru qu'il était mort et nous avons décidé de prendre la mer nous-mêmes, et soudain, ça a commencé ! Une tempête terrible, un vent d'ouragan : je n'avais jamais rien vu de pareil de ma vie ! Notre navire a été mis en pièces, et seuls quatre marins s'en sont sortis : les vagues les ont rejetés sur le rivage. L'un des survivants a dit qu'avant la tempête, il était entré dans la cabine du capitaine pour chercher à boire, et qu'il avait vu une carte sur la table. Bref, il l'avait prise au cas oם. Nous avons partagé la carte en deux : nous avions décidé de réunir un équipage et de revenir ici.";
			link.l1 = "Comment êtes-vous sortis de là ?";
			link.l1.go = "6";
		break;
		
		case "6":
			dialog.text = "Nous avons décidé de laisser sur l'île tout l'or que nous avions : nous avons tout remis en place. La peur nous a saisis : la nuit, toutes sortes de mauvais esprits d'apparence indienne se sont mis à apparaître, ils nous menaçaient, nous terrorisaient : une chose terrible. Bref, nous avons rendu l'or et nous nous sommes mis à construire un esquif : Dieu merci, il y avait un charpentier parmi nous, et quelques outils avaient été rejetés sur le rivage.. Voilà mon histoire, capitaine... Je suis rentré chez moi, mais je ne peux pas vivre en paix. Alors je noie mes peurs dans le rhum.";
			link.l1 = "En voilà une histoire ! Oם est la carte ?";
			link.l1.go = "7";
		break;
		
		case "7":
			TakeNItems(PChar, "MysteriousIsland_MapChapter", 1);
			dialog.text = "Oui, prends !";
			link.l1 = "Oם est le reste ?";
			link.l1.go = "8";
		break;
		
		case "8":
			dialog.text = "Oם ça ? Chez mes complices, s'ils sont encore en vie. Va, capitaine, tu me rends nerveux.";
			link.l1 = "Eh bien, bonne journée, marin !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandToBarmen");
		break;
		
		case "9":
			dialog.text = "On m'a dit que je vous devais ma liberté ?!";
			link.l1 = "Oui, Diego, j'avais besoin de te parler !";
			link.l1.go = "10";
		break;
		
		case "10":
			dialog.text = "Oh, voilà donc ce qu'il en est ! Mais j'ai de la chance. Si mille pièces pour un vieil ivrogne ne vous dérangent pas, je vous la donne tout de suite.";
			if(sti(PChar.money) >= 1000)
			{
				AddMoneyToCharacter(PChar, -1000);
				link.l1 = "Voici l'argent, Diego. Donne-moi un morceau de la carte !";
				link.l1.go = "11";			
			}
			else
			{
				link.l1 = "Donne-moi un morceau de la carte ! Sinon, tu retournes en prison tout de suite.";
				link.l1.go = "11";			
			}
		break;

		case "11":
			TakeNItems(PChar, "MysteriousIsland_MapChapter", -1);
			TakeNItems(PChar, "MysteriousIsland_Map", 1);
			dialog.text = "Prenez-le. Je devine ce que vous préparez, et je vous conseille sincèrement d'abandonner cette idée.";
			link.l1 = "Adieu, Diego. Je te souhaite bonne chance.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandFirstVisit");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}