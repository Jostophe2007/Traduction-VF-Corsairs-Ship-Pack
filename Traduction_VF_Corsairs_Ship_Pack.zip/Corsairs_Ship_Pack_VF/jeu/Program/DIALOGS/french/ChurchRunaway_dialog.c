// Диалог беглого послушника (церковный квест №3 "Беглый монах")
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sTitle;

	switch(Dialog.CurrentNode)
	{
		case "ChurchRunaway_Monk_Start":
			dialog.text = "Je vous en prie, parlez moins fort... Oui, j'ai fui le cloître. Je ne supportais plus les murs du monastère : la peur et le doute m'ont submergé. C'est le père " + PChar.GenQuest.ChurchRunaway.PriestName + " qui vous envoie à ma recherche ?";
			link.l1 = "Votre place est au cloître, mon frère. Retournez-y et accomplissez votre devoir envers Dieu.";
			link.l1.go = "ChurchRunaway_Persuade";
			link.l2 = "Chacun est libre de choisir sa voie. Allez en paix, je ne vous retiendrai pas.";
			link.l2.go = "ChurchRunaway_Release";
			link.l3 = "Assez de jérémiades. Vous venez avec moi, de gré ou de force.";
			link.l3.go = "ChurchRunaway_Force";
		break;

		case "ChurchRunaway_Persuade":
			if (rand(100) < 30 + sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)))
			{
				dialog.text = "Vos paroles... elles m'ont rendu courage. Vous avez raison, j'ai été faible. Je vais revenir et accepter ma pénitence. Merci de m'avoir ramené sur le droit chemin.";
				link.l1 = "Allez, mon frère. On vous attend.";
				link.l1.go = "ChurchRunaway_Done_Persuade";
			}
			else
			{
				dialog.text = "Non... vous ne comprenez pas ! Je ne peux pas y retourner. Plutכt la misère et l'errance que retrouver ces murs froids !";
				link.l1 = "Très bien, je ne vous forcerai pas. Allez en paix.";
				link.l1.go = "ChurchRunaway_Release";
				link.l2 = "Personne ne vous a demandé votre avis. Vous venez avec moi.";
				link.l2.go = "ChurchRunaway_Force";
			}
		break;

		case "ChurchRunaway_Release":
			dialog.text = "Que Dieu vous bénisse pour votre bonté ! Je ne l'oublierai jamais. Adieu...";
			link.l1 = "Adieu. Et que le Seigneur vous garde.";
			link.l1.go = "ChurchRunaway_Done_Release";
		break;

		case "ChurchRunaway_Force":
			dialog.text = "Non ! Lâchez-moi !.. Bon, bon, comme vous voudrez. Je viens. Mais Dieu voit ce qu'il y a dans mon cœur.";
			link.l1 = "Marchez. Et pas d'entourloupe.";
			link.l1.go = "ChurchRunaway_Done_Force";
		break;

		case "ChurchRunaway_Done_Persuade":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchRunaway.Outcome = "persuade";
			DeleteAttribute(PChar, "quest.ChurchRunaway_SpawnMonk");
			characters[GetCharacterIndex("ChurchRunaway_Monk")].LifeDay = 0;
			sTitle = PChar.GenQuest.ChurchRunaway.QuestTown + "ChurchRunaway";
			AddQuestRecordEx(sTitle, "ChurchRunaway", "2");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRunaway.QuestTown + "Gen"));
		break;

		case "ChurchRunaway_Done_Release":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchRunaway.Outcome = "release";
			DeleteAttribute(PChar, "quest.ChurchRunaway_SpawnMonk");
			characters[GetCharacterIndex("ChurchRunaway_Monk")].LifeDay = 0;
			sTitle = PChar.GenQuest.ChurchRunaway.QuestTown + "ChurchRunaway";
			AddQuestRecordEx(sTitle, "ChurchRunaway", "2");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRunaway.QuestTown + "Gen"));
		break;

		case "ChurchRunaway_Done_Force":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchRunaway.Outcome = "force";
			DeleteAttribute(PChar, "quest.ChurchRunaway_SpawnMonk");
			characters[GetCharacterIndex("ChurchRunaway_Monk")].LifeDay = 0;
			sTitle = PChar.GenQuest.ChurchRunaway.QuestTown + "ChurchRunaway";
			AddQuestRecordEx(sTitle, "ChurchRunaway", "2");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRunaway.QuestTown + "Gen"));
		break;
	}
}
