// boal 27.03.2004 Изабела Армани (романтическая ветка)
void ProcessDialogEvent()
{
	ref NPChar, d, sld, rColony;
	aref Link, NextDiag;
	string NPC_Meeting;
	int i, iMoney, iTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(NextDiag, NPChar.Dialog);

	string iDay, iMonth, sTemp;
	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;
// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
            switch (npchar.angry.kind) //сюда расписываем реакцию ангри. В npchar.angry.name пробелы удалены!!!
            {
                case "repeat":
					//когда достал обещаниями денег дать
                    if (npchar.angry.name == "NewLife_Budget_Add") Dialog.CurrentNode = "AngryRepeat_Budget_Add";
					//когда подарками достал, а сам не давал
					if (npchar.angry.name == "NewLife_Present") Dialog.CurrentNode = "AngryRepeat_Present";
                break;
				case "quest":
					//когда долги достали Изабеллу
					if (npchar.angry.name == "NewLife_Budget_Pay") Dialog.CurrentNode = "AngryRepeat_Budget_Pay";
					//когда достало Изабеллу пиратсво ГГ
					if (npchar.angry.name == "NewLife_KnowPirates") Dialog.CurrentNode = "AngryRepeat_KnowPirates";
				break;
            }
        }
    }
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================
	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

		case "First time":
			NextDiag.TempNode = "first time";
			//был в спальне
			pchar.quest.wasInBeedroom = true;
			bDisableFastReload = true;
			// прерывание на выход, а то ход истории в руках геймера
			pchar.quest.RP_afterVisitBedroom.win_condition.l1 = "ExitFromLocation";
			pchar.quest.RP_afterVisitBedroom.win_condition.l1.location = pchar.location;
			pchar.quest.RP_afterVisitBedroom.win_condition = "RP_afterVisitBedroom";
            dialog.text = "Comment êtes-vous entré ici ? Si vous ne quittez pas ma chambre immédiatement, j'appelle mon mari.";
			link.l1 = "Je suis " + GetFullName(pchar) + ". Puis-je connaître le nom d'une aussi belle señorita ?";
			link.l1.go = "Next_1";
			link.l2 = "Je vous prie de me pardonner. Je m'en vais déjà...";
			link.l2.go = "exit";
		break;

		case "Next_1":
			NextDiag.TempNode = "Next_2";

            dialog.text = "Señora, pas señorita. Je suis la maîtresse de cette maison, " + GetFullName(npchar) + ". Pourquoi êtes-vous entré dans mes appartements ?";
            link.l1 = "Calmez-vous, señora, je suis un associé de votre mari. Il m'a invité à visiter votre nouvelle maison, et il y a tant de pièces ici qu'il n'est pas difficile de se perdre.";
			link.l1.go = "Next_4";
			link.l2 = "Simple curiosité. Je m'en vais déjà.";
			link.l2.go = "exit";
		break;

		case "Next_2":
			NextDiag.TempNode = "Next_2";
            dialog.text = "Vous êtes encore là ? Laissez-moi tranquille !";
            link.l1 = "Puis-je savoir quelque chose ?";
			link.l1.go = "Next_3";
            link.l2 = "Désolé...";
			link.l2.go = "exit";
		break;

		case "Next_3":
			NextDiag.TempNode = "Next_2";
            dialog.text = "Que voulez-vous de moi ? Parlez à mon mari. Je ne veux pas vous parler pour l'instant.";
            link.l1 = "D'accord, c'est ce que je vais faire.";
			link.l1.go = "exit";
		break;

		case "Next_4":
            dialog.text = "Oui, nous avons acheté cette maison récemment. Et quelles affaires avez-vous en commun avec mon mari ?";
            link.l1 = "Nos intérêts se croisent dans la sphère d'influence commerciale de la Couronne espagnole.";
			link.l1.go = "Next_5";
            link.l2 = "Nous sommes de vieux amis.";
			link.l2.go = "Next_6";
			link.l3 = "Je dois prendre congé. Pardonnez-moi.";
			link.l3.go = "Next_7";
		break;

		case "Next_5":
            dialog.text = "Des intérêts... commerciaux... qui se croisent... Je suis bien loin de tout cela. Bon, passons. Comment trouvez-vous notre maison ? J'ai choisi la décoration moi-même.";
            link.l1 = "Tout simplement incomparable ! Vous avez un goמt si raffiné !";
			link.l1.go = "Next_8";
            link.l2 = "Honnêtement, ce n'est pas impressionnant. J'ai vu quelque chose de semblable dans une colonie anglaise.";
			link.l2.go = "Next_9";
			Pchar.RomanticQuest.TalkInShop = true;
		break;

		case "Next_6":
            dialog.text = "Des amis ? Je ne pense pas que mon mari puisse avoir de tels amis. "+ Characters[GetCharacterIndex("Husband")].Name + " !!!";
            link.l1 = "Attendez ! Je vais tout vous expliquer...";
			link.l1.go = "Romantic_Battle_in_Bedroom";
		break;

		case "Next_7":
			dialog.text = "Vous ne me plaisez pas. Je crois que je ferais mieux d'appeler mon mari. "+ Characters[GetCharacterIndex("Husband")].Name + " !!!";
            link.l1 = "Attendez ! Je vais tout vous expliquer...";
			link.l1.go = "Romantic_Battle_in_Bedroom";
		break;

		case "Next_8":
		    NextDiag.TempNode = "Good_1";
            dialog.text = "Vous me flattez. Vous savez conquérir une dame, señor.";
            link.l1 = "J'ai simplement dit la vérité. Et maintenant, permettez-moi de prendre congé, je ne vous dérangerai plus...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 3);
		break;

		case "Next_9":
		    NextDiag.TempNode = "Next_2";
            dialog.text = "א mon avis, vous n'êtes qu'un rustre mal dégrossi !";
            link.l1 = "Eh bien... certains pensent autrement...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -4);
		break;

		case "Good_1":
		    NextDiag.TempNode = "Good_1";
            dialog.text = "Heureuse de vous revoir. Quel bon vent vous amène ?";
            link.l1 = "Je suis juste venu vous saluer, charmante " + npchar.name+".";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "quest.VisitStep")) pchar.quest.VisitStep = 1;
			else pchar.quest.VisitStep = makeint(pchar.quest.VisitStep)+1;
			pchar.quest.wasInBeedroom = true;
			bDisableFastReload = true;
			pchar.quest.RP_afterVisitBedroom.win_condition.l1 = "ExitFromLocation";
			pchar.quest.RP_afterVisitBedroom.win_condition.l1.location = pchar.location;
			pchar.quest.RP_afterVisitBedroom.win_condition = "RP_afterVisitBedroom";
		break;

		case "Romantic_Battle_in_Bedroom":
		    NextDiag.CurrentNode = "Next_2";
			DialogExit();
			AddDialogExitQuest("Romantic_Battle_in_Bedroom_1");
		break;

		case "Murder":
		    NextDiag.TempNode = "Murder";
            dialog.text = "Laissez-moi tranquille, sale assassin !";
            link.l1 = "...";
			link.l1.go = "exit";
			PChar.quest.Romantic_TalkInShop.over = "yes";
		break;

		case "TalkInShop":
		    NextDiag.TempNode = "TalkInShop_2";
            dialog.text = "Capitaine " + GetFullName(PChar)+" !";
            link.l1 = "Señora ! Quelle agréable rencontre !";
			link.l1.go = "exit";
			//AddDialogExitQuest("Romantic_TalkInShop_3");
		break;

		case "TalkInShop_2":
            dialog.text = "Pour l'amour de Dieu, capitaine, laissez-le tranquille !";
            link.l1 = "Pas avant que ce gredin n'ait demandé pardon !";
			link.l1.go = "TalkInShop_3";
		break;

		case "TalkInShop_3":
            dialog.text = "Voyons, ce n'est qu'un petit malentendu.";
            link.l1 = "Alors, dites-moi ce qui s'est passé ?";
			link.l1.go = "TalkInShop_4";
		break;

		case "TalkInShop_4":
            dialog.text = "Je suis venue savoir pourquoi les provisions n'avaient pas été livrées aujourd'hui comme convenu. J'étais sמre que mon mari les avait payées, mais apparemment, il avait oublié. Il s'avère que nous avons un mois de dettes. Je n'ai pas 1200 pièces d'or. J'ai dit que je les apporterais plus tard, et le señor " +
                          GetCharacterFullName("SanJuan_trader")+" a cru que je refusais tout simplement de payer.";
            link.l1 = "(au marchand) Prends ton argent, misérable boutiquier.";
			link.l1.go = "TalkInShop_5";
			link.l2 = "(au marchand) Bon, maintenant, il vous croira, n'est-ce pas ?";
			link.l2.go = "TalkInShop_6";
		break;

		case "TalkInShop_5":
            AddMoneyToCharacter(pchar, -1200);
		    NextDiag.TempNode = "Good_1";
            dialog.text = "Je suis vraiment confuse, capitaine. Je vais vous rembourser immédiatement. Maintenant, je dois partir.";
            link.l1 = "Ce n'est rien, señora Isabella. Je suis amplement récompensé par le bonheur de vous voir.";
			link.l1.go = "TalkInShop_Go";
		break;

		case "TalkInShop_6":
            NextDiag.CurrentNode = "TalkInShop_7";
			DialogExit();
			characters[GetCharacterIndex("SanJuan_trader")].dialog.currentnode = "Romantic_2";
			AddDialogExitQuest("Romantic_TalkInShop_3");
		break;

		case "TalkInShop_7":
		    NextDiag.TempNode = "Good_1";
            dialog.text = "Merci. Mais je dois partir. Au revoir.";
            link.l1 = "Ce n'est rien, señora Isabella. Je suis amplement récompensé par le bonheur de vous voir.";
			link.l1.go = "TalkInShop_Go";
		break;

		case "TalkInShop_Go":
            NextDiag.CurrentNode = "Good_1";
			DialogExit();
            LAi_ActorGoToLocation(NPChar, "reload", "reload1_back", "SanJuan_church", "goto", "goto1", "Romantic_TalkInShop_end", 4.0);
			chrDisableReloadToLocation = true;
		break;

		case "TalkInChurch":
		    //NextDiag.TempNode = "TalkInChurch_1";
            dialog.text = "Capitaine, je suis contente de vous voir. Dites-moi, ne seriez-vous pas le capitaine du brick Les Cinq Plaies du Christ ?";
            link.l1 = "« Les Cinq Plaies du Christ » ? Un pécheur comme moi n'aurait jamais songé à donner à son navire un nom aussi pieux. Cependant, pour la belle señora, je suis prêt à changer non seulement le nom de mon navire, mais aussi le mien.";
			link.l1.go = "TalkInChurch_1";
			DeleteAttribute(npchar, "talker"); //снимаем говорилку
		break;

		case "TalkInChurch_1":
            dialog.text = "Pardonnez-moi, capitaine, je me suis trompée.";
            link.l1 = "Attendez, señora ! Pourquoi êtes-vous si triste ? Qui est ce capitaine chanceux dont le sort vous inquiète tant ? J'ai peut-être entendu parler de lui, et je peux peut-être vous aider ?";
			link.l1.go = "TalkInChurch_2";
		break;

		case "TalkInChurch_2":
            dialog.text = "Je me souviens, vous êtes capitaine, vous aussi, n'est-ce pas ? Le brick Les Cinq Plaies du Christ devait jeter l'ancre dans le port de San Juan hier. Une tempête l'aurait-elle surpris en chemin depuis Cumaná ?";
            link.l1 = "Hélas, señora, je ne sais rien du sort de ce brick, mais je suis prêt à partir immédiatement à la recherche de votre brave capitaine, si vous m'accordez un seul sourire.";
			link.l1.go = "TalkInChurch_3";
		break;

		case "TalkInChurch_3":
            dialog.text = "Ah, señor, ce n'est pas ce capitaine que j'attends, que Dieu le garde. Il doit y avoir un passager à bord : mon frère, don Miguel de Valdez. Je vous promets un sourire en échange de bonnes nouvelles de ce navire.";
            link.l1 = "Je fais voile vers Cumaná immédiatement, charmante señora !";
			link.l1.go = "TalkInChurch_4";
		break;

		case "TalkInChurch_4":
            dialog.text = "J'attends avec impatience des nouvelles de mon frère. Vous vous souvenez oם se trouve ma maison ?";
            link.l1 = "Oui, bien sמr. Bonne journée.";
			link.l1.go = "TalkInChurch_Go";
		break;

		case "TalkInChurch_Go":
			chrDisableReloadToLocation = true;
            NextDiag.CurrentNode = "WaitShip";
            Pchar.RomanticQuest.ShipToCumana = true;
			DialogExit();
			AddQuestRecord("Romantic_Line", "5");
			LAi_SetActorType(NPChar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload1", "SanJuan_houseS1Bedroom", "goto", "goto4", "Romantic_TalkInChurch_end", 20.0);
            // немного весёлой жизни
            TraderHunterOnMap();
		break;

		case "WaitShip":
		    NextDiag.TempNode = "WaitShip";
            dialog.text = "Il y a des nouvelles ?";
            link.l1 = "Je vous préviendrai dès que j'aurai appris le sort du navire « Les Cinq Plaies du Christ ». א bientכt, " + npchar.name+ ".";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "quest.VisitStep")) pchar.quest.VisitStep = 1;
			else pchar.quest.VisitStep = makeint(pchar.quest.VisitStep)+1;
			bDisableFastReload = true;
			pchar.quest.wasInBeedroom = true;
			pchar.quest.RP_afterVisitBedroom.win_condition.l1 = "ExitFromLocation";
			pchar.quest.RP_afterVisitBedroom.win_condition.l1.location = pchar.location;
			pchar.quest.RP_afterVisitBedroom.win_condition = "RP_afterVisitBedroom";
		break;
		// разговор с братом
		case "Brother_1":
            dialog.text = "Miguel ! Je suis si heureuse de te voir ! Je m'inquiétais pour toi ! Je n'ai pas eu de tes nouvelles depuis si longtemps ! Comment va notre père ?";
            link.l1 = "Isabella ! Sans ce brave capitaine, je n'aurais pas pu rejoindre San Juan avant longtemps. De terribles tempêtes faisaient rage autour de Cumaná, comme des démons. J'apporte une terrible nouvelle : notre père est mort, Isabella ! Il a été contraint de vendre le domaine familial pour payer tes lettres de change. Ce fut une véritable tragédie pour lui, et son cœur n'a pas tenu !";
			link.l1.go = "Brother_2";
		break;
		case "Brother_2":
            dialog.text = "Mais, Miguel ! Je n'ai jamais signé de lettres de change ! C'est un terrible malentendu !";
            link.l1 = "Ma sœur, tu n'as pas encore remercié notre merveilleux capitaine pour le service qu'il nous a si aimablement rendu. Je pense que nous pourrons régler nos affaires de famille plus tard.";
			link.l1.go = "exit";
			AddDialogExitQuest("Romantic_Brother_House_3");
			NextDiag.TempNode = "Brother_3";
		break;
		case "Brother_3":
            dialog.text = "Ah, capitaine " + GetFullName(pchar)+" ! Je vous suis reconnaissante du fond du cœur ! Pardonnez-moi ! La mort de mon père m'a tellement bouleversée que je vous ai oublié ! Je serai heureuse de vous recevoir chez nous ce soir !";
            link.l1 = "Señora Isabella ! Je suis toujours à votre service. Et maintenant, si vous voulez bien m'excuser, je dois vous quitter.";
			link.l1.go = "Brother_4";
		break;
		case "Brother_4":
			AddQuestRecord("Romantic_Line", "8");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload2", "SanJuan_houseS1Bedroom", "goto", "goto4", "Romantic_TalkInChurch_end", 5.0);
			NextDiag.CurrentNode = "Temp_Thanks";
			DialogExit();
		break;
		case "Temp_Thanks":
            NextDiag.TempNode = "Temp_Thanks";
            dialog.text = "Oh, brave capitaine ! Je vous attends pour dîner ce soir !";
            link.l1 = "J'y serai sans faute, señora Isabella.";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "quest.VisitStep")) pchar.quest.VisitStep = 1;
			else pchar.quest.VisitStep = makeint(pchar.quest.VisitStep)+1;
			bDisableFastReload = true;
			pchar.quest.wasInBeedroom = true;
			pchar.quest.RP_afterVisitBedroom.win_condition.l1 = "ExitFromLocation";
			pchar.quest.RP_afterVisitBedroom.win_condition.l1.location = pchar.location;
			pchar.quest.RP_afterVisitBedroom.win_condition = "RP_afterVisitBedroom";
		break;
		// разговор с ГГ на взятом бриге
		case "BrigAbordage":
            dialog.text = "C'EST VOUS !!! Assassin impitoyable et hypocrite ! Voleur et pirate !";
            link.l1 = "Señora, je ne suis pas sans péché, mais mon honneur ne permet à personne de m'offenser, pas même à vous !";
			link.l1.go = "BrigAbordage_1";
		break;
		case "BrigAbordage_1":
            dialog.text = "Ne faites pas l'innocent ! Salvator m'a raconté comment vous avez lâchement tué mon frère Miguel ! Oui ! Assassin !";
            link.l1 = "Et vous l'avez cru ? Señora ! Je suis prêt à faire tant de choses pour vous, et vous croyez que j'ai tué votre frère ? Señora...";
			link.l1.go = "BrigAbordage_2";
		break;
		case "BrigAbordage_2":
            dialog.text = "Mon frère est mort, et vous vous êtes enfui ! Je ne veux pas entendre vos excuses !";
			if (CheckCharacterItem(pchar, "Order"))
			{
				link.l1 = "Je n'ai pas besoin de me justifier, car j'ai vu Salvator poignarder votre frère de mes propres yeux. Miguel avait découvert que c'était Salvator qui avait falsifié les lettres de change qui ont tué votre père. Il comptait le dénoncer aux autorités, et c'est alors que Salvator l'a tué. J'ai trouvé les fausses lettres de change sur le corps de votre frère. Elles sont couvertes du sang de don Miguel, mais tout à fait lisibles. Les voici, regardez...";
				link.l1.go = "BrigAbordage_8";
			}
			else
			{
				link.l1 = "Je n'ai pas besoin de me justifier, car j'ai vu Salvator poignarder votre frère. Votre frère avait découvert que c'était Salvator qui avait falsifié les lettres de change qui ont tué votre père. Don Miguel comptait le dénoncer au gouverneur, et c'est alors que Salvator l'a tué. Il a aussi essayé de me tuer, pour couvrir son crime. Vous ne m'auriez pas cru de toute façon, alors j'ai décidé de quitter la ville pour un moment.";
				link.l1.go = "BrigAbordage_3";
			}
		break;
		// --> нету поддельных векселей в наличие
		case "BrigAbordage_3":
            dialog.text = "Vous, capitaine, vous n'êtes pas seulement un assassin sanguinaire, mais aussi un sale menteur ! Comment pouvez-vous prouver ce que vous dites ?";
            link.l1 = "Señora, j'ai entendu de mes propres oreilles votre frère lancer hardiment au visage de Salvator l'accusation d'avoir falsifié des lettres de change. Et ensuite, j'ai vu de mes propres yeux Salvator et deux assassins poignarder le pauvre Miguel ! Malheureusement, je n'ai pas eu le temps de lui porter secours...";
			link.l1.go = "BrigAbordage_4";
		break;
		case "BrigAbordage_4":
            dialog.text = "Vous voulez que je croie vos paroles ? Et oם sont ces « fausses lettres de change » qui ont tué mon frère ?! Montrez-les-moi !";
            link.l1 = "Je ne les ai pas, señora...";
			link.l1.go = "BrigAbordage_5";
		break;
		case "BrigAbordage_5":
            dialog.text = "Vraiment, la bassesse humaine n'a pas de limites. וcoutez-moi bien, capitaine ! Je vous hais et je vous méprise profondément...";
            link.l1 = "Señora Isabella, nous n'avons pas le temps de parler, le navire va bientכt couler. Je vous propose de poursuivre cette conversation sur mon navire.";
			link.l1.go = "BrigAbordage_6";
		break;
		case "BrigAbordage_6":
            dialog.text = "וcoutez-moi, ignoble pirate ! Aucune force au monde ne me fera partir avec vous. Si je dois mourir, que ce soit ici et maintenant. Et je vous maudis, capitaine, pour tous les malheurs que vous avez apportés à notre famille !";
            link.l1 = "Bon sang, Isabella !!";
			link.l1.go = "BrigAbordage_7";
		break;
		case "BrigAbordage_7":
            dialog.text = "Adieu, je ne dirai plus un mot...";
            link.l1 = "...";
			link.l1.go = "exit";
			LAi_SetPlayerType(pchar);
			LAi_CharacterDisableDialog(npchar);
			npchar.location = "none";
			npchar.location.group = "";
			npchar.location.locator = "";
			AddQuestRecord("Romantic_Line", "17");
			QuestSetCurrentNode("Atilla", "Isabella_Sink");
		break;
		// --> поддельные векселя - у ГГ.
		case "BrigAbordage_8":
            dialog.text = "QUOI ?!! Salvator ?!! C'est un ignoble mensonge !! Des lettres de change ! Salvator m'aime... Salaud ! Mais cette lettre... et ce navire... Je n'y comprends plus rien... Comme j'aimerais que ce ne soit qu'un rêve, capitaine " + GetFullName(pchar) + ".";
            link.l1 = "Une lettre ? Un navire ? De quoi parlez-vous ?";
			link.l1.go = "BrigAbordage_9";
			TakeItemFromCharacter(pchar, "Order");
		break;
		case "BrigAbordage_9":
            dialog.text = "Le capitaine de ce navire est venu chez moi avec une lettre écrite de la main de Salvator. Mon mari y parlait d'un danger qui me menaçait. Il me demandait de quitter San Juan sur le navire du capitaine qui avait apporté la lettre. Mais dès que le navire a quitté le port de San Juan, on m'a enfermée dans une cabine. Ce n'est que maintenant que je comprends que je suis tombée dans un piège !";
            link.l1 = "Oם est Salvator, maintenant ? Je crois qu'il est temps d'avoir une conversation avec lui.";
			link.l1.go = "BrigAbordage_10";
		break;
		case "BrigAbordage_10":
            dialog.text = "Je ne sais pas oם est mon mari... Mon Dieu, c'est tout simplement insupportable ! Perdre mon père et mon frère, et apprendre maintenant que mon mari Salvator est la cause de tous ces malheurs !"+
				          "Puis-je vous demander un service, capitaine ?";
            link.l1 = "Je serai heureux de vous servir, señora Isabella.";
			link.l1.go = "BrigAbordage_11";
		break;
		case "BrigAbordage_11":
            dialog.text = "Pourriez-vous m'emmener chez ma cousine Rosita Fernández, à Belize ?";
            link.l1 = "Bien sמr, señora. Mais permettez-moi, puisque nous sommes près de Portobelo, de faire escale dans cette ville. J'essaierai d'y trouver Salvator, car il attend votre arrivée.";
			link.l1.go = "BrigAbordage_12";
		break;
		case "BrigAbordage_12":
            dialog.text = "Très bien, capitaine. Mais ensuite, je vous en prie, emmenez-moi chez Rosita...";
            link.l1 = "Tout sera fait, señora.";
			link.l1.go = "exit";
			LAi_SetPlayerType(pchar);
			pchar.RomanticQuest = "SeekInPortoBello";
			AddQuestRecord("Romantic_Line", "18");
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			//засада, оставленная Сальватором в Порто Белло
            Pchar.quest.Romantic_AmbushInPortoBello.win_condition.l1 = "location";
            Pchar.quest.Romantic_AmbushInPortoBello.win_condition.l1.location = "PortoBello_houseF2";
            Pchar.quest.Romantic_AmbushInPortoBello.win_condition = "Romantic_AmbushInPortoBello";
			//кузину Роситу в дом Белиза
			sld = GetCharacter(NPC_GenerateCharacter("Rosita", "girl_11", "woman", "towngirl", 5, SPAIN, -1, false));
            sld.name 	= "Fernandez";
	        sld.lastname = "Señor ";
			sld.Dialog.Filename = "Quest\Isabella\BrigCaptain.c";
	        sld.dialog.currentnode = "Rosita";
			sld.greeting = "Gr_Dama";
			LAi_SetStayType(sld);
			ChangeCharacterAddressGroup(sld, "Beliz_houseS4", "goto", "goto2");
		break;
		//Изабелла в доме с засадой в Порто Белло
		case "AmbushPortoBello":
            dialog.text = "Señor " + pchar.name + ", je suis descendue à terre pour savoir comment vous alliez.";
            link.l1 = "Señora Isabella, c'est bien imprudent de votre part...";
			link.l1.go = "AmbushPortoBello_1";
		break;
		case "AmbushPortoBello_1":
            dialog.text = "Mon Dieu, que s'est-il passé ici ?!!";
            link.l1 = "Oh, Isabella, vous n'avez vraiment pas de chance avec votre mariage. Ce sont les deux bandits à qui Salvator a commandé votre assassinat.";
			link.l1.go = "AmbushPortoBello_2";
		break;
		case "AmbushPortoBello_2":
            dialog.text = "Mon assassinat ?!";
			link.l1 = "Exactement. Comme l'a dit l'un de ces deux-là : « l'étrangler en douce ». Ils m'ont tout raconté : ils m'ont pris pour le capitaine du brick qui vous a emmenée de San Juan. Señora, c'est une vraie chance que je l'aie appris à temps et que j'aie pu vous intercepter...";
			link.l1.go = "AmbushPortoBello_3";
		break;
		case "AmbushPortoBello_3":
            dialog.text = "C'est bien vrai, capitaine. Sans aucun doute, je vous dois la vie...";
            link.l1 = "Ce n'est rien, Isabella. Quand je vous vois si effrayée et si vulnérable, un sentiment jusqu'alors inconnu s'éveille dans mon âme... ";
			link.l1.go = "AmbushPortoBello_4";
		break;
		case "AmbushPortoBello_4":
            dialog.text = "Ah, señor " + pchar.name + ", ce n'est ni le moment ni, surtout, l'endroit pour ce genre de conversation. Pardonnez-moi, capitaine.\n"+
				          "Quittons cet endroit affreux !";
            link.l1 = "C'est à vous de me pardonner, señora Isabella, j'ai vraiment mal choisi mon moment... Nous partons. ";
			link.l1.go = "AmbushPortoBello_5";
		break;
		case "AmbushPortoBello_5":
			AddQuestRecord("Romantic_Line", "24");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 2.0);
			DialogExit();
		break;
		//Изабелла на выходе из дома Роситы в Белизе
		case "BelizTalk":
            dialog.text = "Eh bien, nous voilà arrivés. Qu'en dites-vous, señor " + pchar.name + " ?";
            link.l1 = "Señora, j'ai exaucé votre demande. J'ai déjà prévenu Rosita de votre arrivée, elle vous attend. De plus, j'ai inspecté la maison, et votre cousine m'a appris que Salvator ne s'était pas montré dans les environs.";
			link.l1.go = "BelizTalk_1";
		break;
		case "BelizTalk_1":
            dialog.text = "Capitaine, vous êtes mon ange gardien...";
            link.l1 = "Isabella, dites-moi, puis-je maintenant vous parler de mes sentiments ?";
			link.l1.go = "BelizTalk_2";
		break;
		case "BelizTalk_2":
            dialog.text = "Parlez, señor...";
            link.l1 = "Isabella, vous savez que je suis corsaire. Une occupation indigne du cavalier d'une dame telle que vous. Mais vous me plaisez, Isabella, et je veux que vous le sachiez !";
			link.l1.go = "BelizTalk_3";
		break;
		case "BelizTalk_3":
            dialog.text = "Capitaine " + pchar.name + ", vous êtes un homme noble, un vrai chevalier. Je vous dois la vie, mais je veux vous dire franchement que mes sentiments pour vous ne se limitent pas à la gratitude pour m'avoir sauvée...";
            link.l1 = "Señora, si je vous comprends bien, puis-je espérer qu'un jour vous me direz oui ?";
			link.l1.go = "BelizTalk_4";
		break;
		case "BelizTalk_4":
            dialog.text = "Vous avez bien compris, mon ange gardien.";
            link.l1 = "Je suis tout simplement diablement heureux, et prêt à sauter de joie comme un gamin ! Oh, pardonnez-moi, señora, ce gros mot : il m'a échappé...";
			link.l1.go = "BelizTalk_5";
		break;
		case "BelizTalk_5":
            dialog.text = "Ce n'est rien, capitaine. J'essaierai d'adoucir votre caractère, si l'occasion m'en est donnée.";
            link.l1 = "Isabella, je suis à vous corps et âme. Mais il nous reste une petite affaire à régler : Salvator.";
			link.l1.go = "BelizTalk_6";
		break;
		case "BelizTalk_6":
            dialog.text = "Et que comptez-vous faire ?";
            link.l1 = "Je ne sais pas, il n'y a pas de piste claire, Salvator ne cesse de se déplacer. Mais j'ai un ami commun, un pirate du nom d'Atilla. Salvator lui doit beaucoup...";
			link.l1.go = "BelizTalk_7";
		break;
		case "BelizTalk_7":
            dialog.text = "Je vois, capitaine. Bon, j'ai besoin de me remettre de ce que j'ai vécu ; je vous attendrai ici, chez ma cousine, avec de bonnes nouvelles.";
            link.l1 = "Au revoir, Isabella.";
			link.l1.go = "BelizTalk_8";
		break;
		case "BelizTalk_8":
			QuestSetCurrentNode("Atilla", "SalvatorNews");
			NextDiag.CurrentNode = "BelizTalk_after";
			AddQuestRecord("Romantic_Line", "19");
			chrDisableReloadToLocation = false;
			RemovePassenger(pchar, npchar);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "houseS4", "Beliz_houseS4", "goto", "goto1", "Romantic_TalkInChurch_end", 3.5);
			DialogExit();
		break;
		case "BelizTalk_after":
            dialog.text = "Capitaine, quelles nouvelles m'apportez-vous ?";
            link.l1 = "Aucune pour l'instant, Isabella.";
			link.l1.go = "exit";
			NextDiag.TempNode = "BelizTalk_after";
		break;
		//Изабелла в пещере
		case "IsabellaInCave":
            dialog.text = "Ah, vous voilà, " + pchar.name + " ! Je n'attendais plus que vous !";
            link.l1 = "Isabella, vous êtes vivante ! Le Seigneur soit loué ! J'ai trouvé une jeune fille morte dans la jungle, sans doute la servante avec qui vous avez quitté hier la maison de Rosita.";
			link.l1.go = "IsabellaInCave_1";
		break;
		case "IsabellaInCave_1":
            dialog.text = "Pauvre Conchita, c'est Salvator qui l'a tuée !";
            link.l1 = "Le salaud ! Racontez-moi vite, Isabella, que s'est-il passé ?";
			link.l1.go = "IsabellaInCave_2";
		break;
		case "IsabellaInCave_2":
            dialog.text = pchar.name + "Mon mari est un monstre ! Je dois avouer que j'ai agi de façon très imprudente : je sortais me promener hors de la ville tous les jours. Hier, Salvator et un autre bandit nous ont attaquées, et cet assassin, sans hésiter, a poignardé Conchita. Mon Dieu !..";
            link.l1 = "Calmez-vous, Isabella... Et ensuite ?";
			link.l1.go = "IsabellaInCave_3";
		break;
		case "IsabellaInCave_3":
            dialog.text = "Ensuite, ils m'ont traînée ici. Salvator a essayé de me faire signer une procuration pour disposer des biens du pauvre Miguel, car après sa mort, tout m'est revenu par testament.";
            link.l1 = "Voilà donc pourquoi il ne vous a pas tuée tout de suite ! Isabella, c'est une chance inouïe que Salvator ait appris l'existence du testament de Miguel.";
			link.l1.go = "IsabellaInCave_4";
		break;
		case "IsabellaInCave_4":
            dialog.text = "J'ai compris que dès que je signerais ces papiers, je serais morte dans la minute. J'ai rassemblé toutes mes forces et j'ai refusé de signer, malgré toutes les menaces. J'espérais seulement que Rosita vous préviendrait de ma disparition et que vous pourriez me retrouver...";
            link.l1 = "Oh, Isabella, quel imbécile je fais ! Je vous ai laissée seule et sans protection à Belize ! Et pourtant, on pouvait deviner à quoi cela mènerait...";
			link.l1.go = "IsabellaInCave_5";
		break;
		case "IsabellaInCave_5":
            dialog.text = "Ne vous faites pas de reproches, " + pchar.name + " : vous m'avez sauvée une fois de plus.";
            link.l1 = "Isabella, je me suis occupé de vos geכliers, mais oם est Salvator lui-même ?";
			link.l1.go = "IsabellaInCave_6";
		break;
		case "IsabellaInCave_6":
            dialog.text = "Il est allé en ville, mais il a promis de revenir bientכt avec un brasero.";
            link.l1 = "Quel brasero ?";
			link.l1.go = "IsabellaInCave_7";
		break;
		case "IsabellaInCave_7":
            dialog.text = "Un brasero et des pinces, pour me brמler les talons.";
            link.l1 = "Bon sang ! Je suis vraiment arrivé à temps...";
			link.l1.go = "exit";
			LAi_SetActorType(npchar);
			pchar.RomanticQuest = "FoundIsabella";
			AddDialogExitQuest("Romantic_SalvatorInCave");
		break;
		//после схватки с Сальватором в пещере
		case "SalvatorIsDead":
            dialog.text = "C'est fini !";
            link.l1 = "Enfin, Isabella...";
			link.l1.go = "SalvatorIsDead_1";
		break;
		case "SalvatorIsDead_1":
            dialog.text = "Señor " + pchar.name + "Je vous en prie, emmenez-moi chez Rosita.";
            link.l1 = "Señora Isabella, puisque les choses ont tourné ainsi et que vous voilà veuve, permettez-moi de vous offrir ma main et mon cœur !";
			link.l1.go = "SalvatorIsDead_2";
		break;
		case "SalvatorIsDead_2":
            dialog.text = pchar.name + ", j'accepte votre demande.";
            link.l1 = "Formidable ! En attendant, je vais essayer de retrouver ce que Salvator vous a volé.";
			link.l1.go = "SalvatorIsDead_3";
		break;
		case "SalvatorIsDead_3":
            dialog.text = "Señor, faites ce que vous voulez, je veux seulement oublier tout ce qui s'est passé\n"+
				          "Faisons ainsi : je vais rester quelques jours chez Rosita, puis je rejoindrai San Juan par mes propres moyens, car maintenant, je ne suis plus en danger.";
            link.l1 = "Oui, Isabella, je crois qu'il n'y a plus de danger pour vous.";
			link.l1.go = "SalvatorIsDead_4";
		break;
		case "SalvatorIsDead_4":
            dialog.text = "א San Juan, je mettrai de l'ordre dans mes affaires, je reprendrai mon nom de jeune fille, de Valdez, et dans un mois environ, nous nous marierons à l'église de la ville.";
            link.l1 = "C'est très raisonnable, Isabella...";
			link.l1.go = "SalvatorIsDead_5";
		break;
		case "SalvatorIsDead_5":
            dialog.text = "Mais vous devez me promettre que vous abandonnerez votre occupation actuelle : la course.";
            link.l1 = "Señora, c'est un pas important pour moi. C'est mon gagne-pain. Mais je ferai n'importe quoi pour vous... J'accepte, Isabella !";
			link.l1.go = "SalvatorIsDead_6";
		break;
		case "SalvatorIsDead_6":
            dialog.text = "Très bien, " + pchar.name + ". Et maintenant, je vous demande de m'emmener chez ma cousine, je ne peux plus rester ici...";
            link.l1 = "D'accord, Isabella.";
			link.l1.go = "SalvatorIsDead_7";
		break;
		case "SalvatorIsDead_7":
			Pchar.quest.Romantic_DelivToRosita.win_condition.l1 = "location";
			Pchar.quest.Romantic_DelivToRosita.win_condition.l1.location = "Beliz_houseS4";
			Pchar.quest.Romantic_DelivToRosita.win_condition = "Romantic_DelivToRosita";
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;
		//после спасения в доме у Роситы
		case "RositaHouse":
            dialog.text = "Capitaine " + GetFullName(pchar) + ", je vous attends à San Juan dans un mois...";
            link.l1 = "D'accord, Isabella. Mais êtes-vous sמre de pouvoir y aller seule sans problème ?";
			link.l1.go = "RositaHouse_1";
			AddQuestRecord("Romantic_Line", "22");
		break;
		case "RositaHouse_1":
            dialog.text = "Je serai à San Juan dans un mois, soyez tranquille...";
            link.l1 = "D'accord, Isabella.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RositaHouse_1";
		break;
		//Изабелла вновь в Сан-Хуане
		case "InSanJuanAgain":
            dialog.text = "Señor " + pchar.name + "Vous êtes arrivé...";
            link.l1 = "Oui, señora Isabella. Tout va bien ?";
			link.l1.go = "InSanJuanAgain_1";
		break;
		case "InSanJuanAgain_1":
            dialog.text = "Oui, tout va bien. Alors, mon ange gardien, êtes-vous prêt pour une vie de famille tranquille ?";
            link.l1 = "Oui, Isabella, j'ai assez versé de sang.";
			link.l1.go = "InSanJuanAgain_2";
		break;
		case "InSanJuanAgain_2":
            dialog.text = "Et vous m'aimez toujours ?";
            link.l1 = "Isabella, ma chérie, comment pouvez-vous demander une chose pareille ?! Je suis fou de vous !";
			link.l1.go = "InSanJuanAgain_3";
		break;
		case "InSanJuanAgain_3":
            dialog.text = "D'accord, " + pchar.name + ". Alors je vais vous dire que tout est déjà prêt pour le mariage. Je vous attendrai devant l'autel, à l'église, demain matin...";
            link.l1 = "Isabella... Demain matin, nos destins seront unis !";
			link.l1.go = "InSanJuanAgain_4";
		break;
		case "InSanJuanAgain_4":
            dialog.text = "Oui, mon chevalier. Et maintenant, je vous demande de quitter ma maison, vous n'avez rien à y faire avant le mariage...";
            link.l1 = "D'accord, Isabella, à demain...";
			link.l1.go = "exit";
			NextDiag.TempNode = "InSanJuanAgain_after";
			LocatorReloadEnterDisable("SanJuan_town", "houseSp6", true); //закрываем двери дома.
			pchar.RomanticQuest = "WaitBeginWidding";
			AddQuestRecord("Romantic_Line", "23");
		break;
		case "InSanJuanAgain_after":
			dialog.text = NPCStringReactionRepeat("Vous n'avez rien à faire ici avant le mariage...", "Señor, soyez raisonnable ! Avant le mariage, c'est impossible !", "Non, non et non !",
                          "Señor « mon bien-aimé », je vous demande de partir immédiatement !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oh, Isabella, comment pourrai-je supporter tout cela ?! Je veux vous voir maintenant...", "Isabella, c'est une malédiction. Je vais devenir fou d'ici demain !",
                      "Caramba ! Mais que faire ? Enfin, je suis heureux que les lois de l'honneur ne soient pas de vains mots pour ma fiancée...", "Ah, Isabella, je dois obéir...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "exit", "exit", "InSanJuanAgain_out", npchar, Dialog.CurrentNode);
			NextDiag.TempNode = "InSanJuanAgain_after";
		break;
		case "InSanJuanAgain_out":
			AddDialogExitQuest("Romantic_OutFromHouse");
			DialogExit();
		break;

		case "Cancel_Widding":
            dialog.text = "Comment avez-vous osé ne pas venir à l'église pour le mariage ?! Je vous ai donné mon amour, et vous l'avez piétiné si cruellement, si maladroitement !";
            link.l1 = "Isabella...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Cancel_Widding_1";
			LocatorReloadEnterDisable("SanJuan_town", "houseSp6", true); //закрываем дом
			CloseQuestHeader("Romantic_Line");
			pchar.questdata.IstoriyaIzabely = 1;
		break;
		case "Cancel_Widding_1":
            dialog.text = "C'en est assez. Dehors !";
            link.l1 = "Oh, Isabella...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Cancel_Widding_1";
		break;
		//свадьба
		case "TalkWidding":
            dialog.text = "Bonjour, " + pchar.name + ".";
            link.l1 = "Bonjour, Isabella... Vous êtes plus belle aujourd'hui que jamais !";
			link.l1.go = "TalkWidding_1";
		break;
		case "TalkWidding_1":
            dialog.text = "Merci, " + pchar.name + ". זtes-vous prêt, pouvons-nous commencer ?";
            link.l1 = "Bien sמr !";
			link.l1.go = "TalkWidding_2";
		break;
		case "TalkWidding_2":
            dialog.text = "Padre, vous pouvez commencer...";
            link.l1 = "...";
			link.l1.go = "exit";
			LAi_SetActorType(npchar);
			LAi_ActorTurnToLocator(npchar, "barmen", "stay");
			AddDialogExitQuest("Romantic_Padre");
		break;
		//драка в церкви
		case "AmbushInChurch":
            dialog.text = "Que se passe-t-il ? " + pchar.name + " ? J'ai peur !";
            link.l1 = "Isabella, écartez-vous !!";
			link.l1.go = "exit";
			AddDialogExitQuest("Romantic_fightInChurch_2");
		break;
		case "IsabellaIsMyWife":
			dialog.text = "C'étaient les hommes de Salvator ? Mais comment est-ce possible, vous l'avez tué sous mes yeux ?!";
			link.l1 = "Il les avait engagés avant que je le tue.";
			link.l1.go = "IsabellaIsMyWife_1";
		break;
		case "IsabellaIsMyWife_1":
			dialog.text = "Oh, mon Dieu, vais-je vraiment vivre dans une telle peur ?";
			link.l1 = "Isabella, c'est fini ! Salvator n'est plus, et les gens qu'il avait engagés non plus.";
			link.l1.go = "IsabellaIsMyWife_2";
		break;
		case "IsabellaIsMyWife_2":
			dialog.text = "Je l'espère vraiment... " + pchar.name + " ! Je veux rentrer à la maison au plus vite !";
			link.l1 = "Va, ma chérie, je serai un peu en retard, mais je rentrerai bientכt.";
			link.l1.go = "IsabellaIsMyWife_3";
		break;
		case "IsabellaIsMyWife_3":
			rColony = GetColonyByIndex(FindColony("SanJuan"));
			dialog.text = "Mon chéri, tu dois aller voir le gouverneur et lui raconter toi-même tout cet incident. Ensuite, il nous faudra l'accord des autorités pour vivre en ville.";
			if (sti(rColony.HeroOwn))
			{
				link.l1 = "Isabella, cette ville m'appartient tout entière. Alors ne t'inquiète pas...";
				LocatorReloadEnterDisable("SanJuan_town", "houseSp6", false);
			}
			else
			{
				link.l1 = "D'accord, Isabella, je ferai tout...";
				pchar.RomanticQuest.MayorOk = 1; //флаг на базар с мэром Сан-Хуана
			}
			link.l1.go = "IsabellaIsMyWife_4";
		break;
		case "IsabellaIsMyWife_4":
			chrDisableReloadToLocation = true;
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "SanJuan_houseSp6", "goto", "goto1", "Romantic_TalkInChurch_end", 15.0);
			NextDiag.TempNode = "NewLife_firstTime";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//первый диалог после свадьбы
		case "NewLife_firstTime":
			rColony = GetColonyByIndex(FindColony("SanJuan"));
			dialog.text = "Oh, mon chéri, c'est bien que tu sois enfin rentré ! Tu as réglé toutes les questions au sujet de l'incident à l'église ?";
			if (sti(rColony.HeroOwn))
			{
				dialog.text = "Oh, mon chéri, c'est bien que tu sois enfin rentré ! Tout va bien ?";
				link.l1 = "Oui, ma chérie, tout va bien...";
			}
			else
			{
				dialog.text = "Oh, mon chéri, c'est bien que tu sois enfin rentré ! Tu as réglé toutes les questions au sujet de l'incident à l'église ?";
				link.l1 = "Oui, ma chérie, j'ai été reçu par le gouverneur. Tout va bien : il nous félicite.";
			}
			link.l1.go = "NewLife_firstTime_1";
		break;
		case "NewLife_firstTime_1":
			dialog.text = "Eh bien, c'est très bien. Maintenant, si tu n'y vois pas d'inconvénient, discutons des principes de notre vie commune.";
			link.l1 = "Quels principes peut-il y avoir, Isabella ? Tu me plais : voilà le principe fondamental !";
			link.l1.go = "NewLife_firstTime_2";
		break;
		case "NewLife_firstTime_2":
			dialog.text = "Et toi aussi, tu me plais, mon chéri. Mais une famille, ce n'est pas seulement l'amour, c'est aussi une vie commune. Ainsi, en plus de l'amour réciproque, il y a au moins deux autres principes selon lesquels notre famille doit vivre.";
			link.l1 = "Isabella, j'admire ta sagesse ! Mais peut-être pourrions-nous nous en tenir au premier principe pour l'instant, et le mettre immédiatement en pratique ?";
			link.l1.go = "NewLife_firstTime_3";
		break;
		case "NewLife_firstTime_3":
			dialog.text = "Mon chéri, chaque chose en son temps, ne sois pas trop pressant ! Discutons d'abord des deux autres, tu veux bien... ?";
			link.l1 = "Ma chérie, tout ce que tu voudras... Discutons de ces deux principes.";
			link.l1.go = "NewLife_firstTime_4";
		break;
		case "NewLife_firstTime_4":
			dialog.text = "Mon chéri, je t'adore... Alors, le principe numéro deux, ce sont les finances. Nous devons fixer le budget familial. Ta maison, c'était un navire, mais maintenant, ta maison est ici, et tu dois comprendre que posséder un bien immobilier représente une certaine charge financière : les impכts de la ville\n"+
				          "En outre, subvenir à nos besoins quotidiens demande aussi des dépenses...";
			link.l1 = "Isabella, je suis prêt à donner tout ce que j'ai !";
			link.l1.go = "NewLife_firstTime_5";
		break;
		case "NewLife_firstTime_5":
			dialog.text = "D'accord, mais commençons modestement... Bon, pour résumer : chaque mois, tu devras rapporter à la maison " + FindRussianMoneyString(MOD_SKILL_ENEMY_RATE*3*10000) + ".";
			link.l1 = "Comme tu voudras, Isabella. Tout est pour toi ! Alors, quel est notre troisième principe ?";
			link.l1.go = "NewLife_firstTime_6";
		break;
		case "NewLife_firstTime_6":
			dialog.text = "Le troisième principe, c'est ta promesse d'abandonner la course. Fais vivre ta famille autrement, inutile de couler des navires et de prendre des villes : le Seigneur ne nous le pardonnera pas...";
			link.l1 = "Eh bien, je me souviens parfaitement de mes promesses. J'accepte ce programme, ma chérie.";
			link.l1.go = "exit";
			NextDiag.TempNode = "NewLife";
			UnlockAchievement("Isabella_quest", 3);
			AddDialogExitQuest("Romantic_afterFirstTime");
		break;
//************************************ новая жизнь бывшего корсара ********************************
		case "NewLife_hello":
			iDay = GetQuestPastDayParam("RomanticQuest");
			dialog.text = LinkRandPhrase("Bonjour, mon chéri !", "Salutations à mon mari.", "Heureuse de voir mon époux.");
			link.l1 = RandPhraseSimple("Bonjour, Isabella !", "Bonjour, ma chérie...");
			link.l1.go = "NewLife";
			if (iDay > 40)
			{
				dialog.text = RandPhraseSimple("Bonjour, mon chéri ! Et explique-moi tout de suite, s'il te plaît, oם tu étais pendant " + FindRussianDaysString(iDay) + " ?", "Salutations à mon mari, parti on ne sait oם pendant " + FindRussianDaysString(iDay) + ". Tu peux me le dire, mon chéri ?");
				link.l1 = RandPhraseSimple("Isabella, ma chérie, j'ai passé tout ce temps à m'occuper de mes affaires.", "Ma chérie, ça s'est fait comme ça...");
				link.l1.go = "NewLife_hello_1";
			}
			if (GetQuestPastDayParam("RomanticQuest") > 3 && pchar.RomanticQuest == "OpenTheDoosOfHouse")
			{
				dialog.text = "Bonjour, cher mari. Je ne t'ai ouvert la porte que parce que la cousine Rosita me l'a demandé.";
				link.l1 = "Isabella, je comprends tout, mais comprends-moi aussi : je suis marin !";
				link.l1.go = "NewLife_hello_2";
			}
		break;
		case "NewLife_hello_1":
			dialog.text = "וcoute, bien sמr, je comprends que tu es capitaine et que ton métier, c'est de naviguer. Mais comprends-moi aussi : je n'ai pas l'intention de rester seule à la maison pendant des mois ! Et sache que si tu restes absent aussi longtemps, je ne t'ouvrirai plus la porte !";
			link.l1 = RandPhraseSimple("Isabella, je comprends... Je suis désolé d'avoir dמ te laisser seule si longtemps.", "Je suis désolé que tu aies dמ rester seule si longtemps, je comprends tout...");
			link.l1.go = "NewLife";
			SaveCurrentQuestDateParam("RomanticQuest"); //обновим дату, от которой считаем отсутствие
			LAi_CharacterPlaySound(npchar, "Gr_Isabella_3");
		break;
		case "NewLife_hello_2":
			dialog.text = "Je ne veux comprendre qu'une chose : l'intérêt de ma famille. Si tu crois pouvoir venir ici de temps en temps, tu te trompes lourdement. Nous devons avoir une famille, pas une farce.";
			link.l1 = "D'accord, Isabella, j'essaierai de ne pas te laisser longtemps...";
			link.l1.go = "NewLife";
			SaveCurrentQuestDateParam("RomanticQuest"); //обновим дату, от которой считаем отсутствие
			LAi_CharacterPlaySound(npchar, "Gr_Isabella_3");
		break;
		//======================== типовое меню ==========================
		case "NewLife":
			//проверяем, как там с финансами у нас
			iMoney = IsabellaCheckBudgetMoney();
			if (iMoney > 0)
			{
				dialog.text = NPCStringReactionRepeat("Mon chéri, nous avons un problème : nous sommes criblés de dettes. Il faut ajouter " + FindRussianMoneyString(iMoney) + " pour régler ainsi les problèmes d'impכts.",
					"C'est la deuxième fois aujourd'hui que je te parle de nos problèmes d'argent. Nous devons " + FindRussianMoneyString(iMoney) + ".",
					"Pour la troisième fois aujourd'hui, je te rappelle nos dettes, qui s'élèvent à " + FindRussianMoneyString(iMoney) + ".",
					"Je te rappelle encore une fois un énorme problème : des dettes d'un montant de " + FindRussianMoneyString(iMoney) + ".", "block", 3, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Caramba !! Comment ai-je pu laisser les choses aller si loin ?!", "Eh bien, comme j'ai laissé aller les affaires de famille..."),
					"La deuxième fois ? Voilà le problème...",
					"Déjà la troisième fois ?! Ouais...",
					"Je me souviens, Isabella...", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_Budget_Pay";
				break;
			}
			//--> проверяем статистику на пиратство
			if (CheckAttribute(pchar, "RomanticQuest.Cheking.GrabbingTown") && pchar.RomanticQuest.Cheking != "Ok")
			{
				if (rand(sti(pchar.RomanticQuest.Cheking.GrabbingTown)*150) >= GetCharacterSkill(pchar, "Sneak"))//ранд типа слухи не дошли
				{
					dialog.text = RandPhraseSimple("וcoute, tout le monde dit que tu as pillé une ville. C'est vrai ?", "וcoute, le bruit court que tu as repris tes vieilles habitudes et que tu as pillé une ville. C'est vrai ?");
					link.l1 = LinkRandPhrase("Allons, ma chérie, c'est de la calomnie !", "Ma chérie, je n'ai rien fait de tel.", "Non, ma chérie, ce n'est pas vrai, j'ai promis !");
					link.l1.go = "NewLife_KnowPirates";
					IsabellaSetCurrentState("GrabbingTown");
					LAi_CharacterPlaySound(npchar, "Gr_Isabella_2");
					break;
				}
			}
			if (CheckAttribute(pchar, "RomanticQuest.Cheking.TakeTown") && pchar.RomanticQuest.Cheking != "Ok")
			{
				if (rand(sti(pchar.RomanticQuest.Cheking.TakeTown)*140) >= GetCharacterSkill(pchar, "Sneak"))//ранд типа слухи не дошли
				{
					dialog.text = RandPhraseSimple("וcoute, le bruit court que tu as pris une ville. C'est vrai ?", "וcoute, le bruit court que tu as repris tes vieilles habitudes et que tu as pris une ville. C'est vrai ?");
					link.l1 = LinkRandPhrase("Allons, ma chérie, c'est de la calomnie !", "Ma chérie, je n'ai rien fait de tel.", "Non, ma chérie, ce n'est pas vrai, j'ai promis !");
					link.l1.go = "NewLife_KnowPirates";
					IsabellaSetCurrentState("TakeTown");
					LAi_CharacterPlaySound(npchar, "Gr_Isabella_2");
					break;
				}
			}
			if (CheckAttribute(pchar, "RomanticQuest.Cheking.KillFort") && pchar.RomanticQuest.Cheking != "Ok")
			{
				if (rand(sti(pchar.RomanticQuest.Cheking.KillFort)*130) >= GetCharacterSkill(pchar, "Sneak"))//ранд типа слухи не дошли
				{
					dialog.text = RandPhraseSimple("וcoute, j'ai entendu dire que tu avais pris une sorte de fort. C'est vrai ?", "וcoute, le bruit court que tu as repris tes vieilles habitudes et que tu as pris un fort. C'est vrai ?");
					link.l1 = LinkRandPhrase("Allons, ma chérie, c'est de la calomnie !", "Ma chérie, je n'ai rien fait de tel.", "Non, ma chérie, ce n'est pas vrai, j'ai promis !");
					link.l1.go = "NewLife_KnowPirates";
					IsabellaSetCurrentState("KillFort");
					LAi_CharacterPlaySound(npchar, "Gr_Isabella_2");
					break;
				}
			}
			if (CheckAttribute(pchar, "RomanticQuest.Cheking.AbordShip") && pchar.RomanticQuest.Cheking != "Ok")
			{
				if (rand(sti(pchar.RomanticQuest.Cheking.AbordShip)*70) >= GetCharacterSkill(pchar, "Sneak"))//ранд типа слухи не дошли
				{
					dialog.text = RandPhraseSimple("J'ai entendu des rumeurs terribles : tu abordes des navires. C'est vrai ?", "וcoute, le bruit court que tu recommences tes vieux tours : aborder et piller des navires. C'est vrai ?");
					link.l1 = LinkRandPhrase("Allons, ma chérie, c'est de la calomnie !", "Ma chérie, je n'ai rien fait de tel.", "Non, ma chérie, ce n'est pas vrai, j'ai promis !");
					link.l1.go = "NewLife_KnowPirates";
					IsabellaSetCurrentState("AbordShip");
					LAi_CharacterPlaySound(npchar, "Gr_Isabella_2");
					break;
				}
			}
			if (CheckAttribute(pchar, "RomanticQuest.Cheking.KillShip") && pchar.RomanticQuest.Cheking != "Ok")
			{
				if (rand(sti(pchar.RomanticQuest.Cheking.KillShip)*50) >= GetCharacterSkill(pchar, "Sneak"))//ранд типа слухи не дошли
				{
					dialog.text = RandPhraseSimple("וcoute, les gens disent que tu coules des navires. C'est vrai ?", "וcoute, le bruit court que tu as repris tes vieilles habitudes : couler des navires. C'est vrai ?");
					link.l1 = LinkRandPhrase("Allons, ma chérie, c'est de la calomnie !", "Ma chérie, je n'ai rien fait de tel.", "Non, ma chérie, ce n'est pas vrai, j'ai promis !");
					link.l1.go = "NewLife_KnowPirates";
					IsabellaSetCurrentState("KillShip");
					LAi_CharacterPlaySound(npchar, "Gr_Isabella_2");
					break;
				}
			}
			//<-- проверяем статистику на пиратство
			//        -------  ОСНОВНОЕ МЕНЮ  ----------
			dialog.text = LinkRandPhrase("Mon chéri, je t'écoute...", "Que veut mon cher mari ?", "Le señor " + pchar.lastname + "ta femme t'écoute avec la plus grande attention...");
			link.l1 = "Comme ça, juste pour parler... Tu m'as manqué, tu sais...";
			link.l1.go = "NewLife_JustTalk";
			link.l2 = "Voyons oם en est notre budget familial...";
			link.l2.go = "NewLife_Budget";
			link.l3 = "Ma chérie, je t'ai apporté un cadeau.";
			link.l3.go = "NewLife_Present";
			link.l4 = "וcoute, ma chérie, à propos du devoir conjugal...";
			link.l4.go = "NewLife_Sex";
			link.l5 = "Je veux dormir, je n'ai plus de forces...";
			link.l5.go = "NewLife_Sleep";
		break;
		//=========================== Бюджет =================================
		case "NewLife_Budget":
			iMoney = IsabellaCheckBudgetMoney();
			if (iMoney > -(MOD_SKILL_ENEMY_RATE*3*10000)) //деньги на исходе
			{
				if (iMoney == 0)
				{
					dialog.text = RandPhraseSimple("Il n'y a pas encore de dettes, mais l'argent est épuisé, mon chéri...", "א part qu'il n'y a pas de dettes et que l'huissier ne frappe pas à la porte... Pour le reste, l'argent est complètement épuisé.");
				}
				else
				{
					dialog.text = "Il n'y a pas encore de dettes, mais l'argent s'épuise. Il me reste " + FindRussianMoneyString(-iMoney) + ".";
					link.l1 = RandPhraseSimple("Bon, le moment venu, nous verrons...", "Je n'ai pas la tête à ça maintenant, dépense ce que tu as...");
					link.l1.go = "NewLife";
				}
				link.l2 = RandPhraseSimple("Eh bien, nous allons te donner quelques piastres, ma chérie !", "Il faut renflouer le budget de toute urgence, allons-y !");
				link.l2.go = "NewLife_Budget_Add";
				LAi_CharacterPlaySound(npchar, "Gr_Isabella_4");
			}
			else //профицит
			{
				dialog.text = RandPhraseSimple("Pas de problème, mon chéri, il y a encore assez d'argent : " + FindRussianMoneyString(-iMoney) + " en caisse.", "Tout va bien, mon chéri, il y a assez d'argent dans notre budget : " + FindRussianMoneyString(-iMoney) + ".");
				link.l1 = RandPhraseSimple("Eh bien, c'est bien.", "Parfait, ma chérie, très bien !");
				link.l1.go = "NewLife";
				link.l2 = "Je veux aussi te laisser de l'argent, pour que tu ne manques de rien.";
				link.l2.go = "NewLife_Budget_Add";
			}
		break;
		case "NewLife_Budget_Add":
            dialog.text = NPCStringReactionRepeat("D'accord, mon chéri. Combien d'argent veux-tu me laisser ?", "Pourquoi veux-tu me laisser quelque chose pour la deuxième fois de la journée, je ne comprends pas... Alors, combien veux-tu me donner ?", "Tu te moques de moi ? Pour la troisième fois de la journée, tu veux me donner de l'argent ! On ne peut pas tout régler d'un coup ?", "דa suffit, tu me fatigues : tu es d'un ennui insupportable ! Je ne te parle plus !", "repeat", 10, npchar, Dialog.CurrentNode);
			if (sti(pchar.money) >= 50000 && npchar.quest.repeat.NewLife_Budget_Add.ans != "3")
			{
				link.l1 = HeroStringReactionRepeat("50 000.", "Hum, je veux te laisser 50 000.", "Euh... Je veux te laisser 50 000.", "...", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_Budget_50";
			}
			if (sti(pchar.money) >= 100000 && npchar.quest.repeat.NewLife_Budget_Add.ans != "3")
			{
				link.l2 = HeroStringReactionRepeat("100 000.", "100 000...", "100 000...", "...", npchar, Dialog.CurrentNode);
				link.l2.go = "NewLife_Budget_100";
			}
			if (sti(pchar.money) >= 200000 && npchar.quest.repeat.NewLife_Budget_Add.ans != "3")
			{
				link.l3 = HeroStringReactionRepeat("200 000.", "200 000...", "200 000...", "...", npchar, Dialog.CurrentNode);
				link.l3.go = "NewLife_Budget_200";
			}
			if (sti(pchar.money) >= 500000 && npchar.quest.repeat.NewLife_Budget_Add.ans != "3")
			{
				link.l4 = HeroStringReactionRepeat("500 000.", "500 000...", "500 000...", "...", npchar, Dialog.CurrentNode);
				link.l4.go = "NewLife_Budget_500";
			}
			link.l5 = HeroStringReactionRepeat("Hum... Rien pour l'instant, Isabella... L'argent manque...", "C'est comme ça, ma chérie... Pardonne-moi, mais il n'y a pas d'argent.", "דa n'a pas marché tout de suite, Isabella... Et il n'y a pas d'argent.", "Isabella, comment ça ?", npchar, Dialog.CurrentNode);
			link.l5.go = "NewLife_Budget_No";
		break;
		case "NewLife_Budget_50":
			dialog.text = "D'accord, " + pchar.name + "Merci.";
			link.l1 = "C'est mon devoir, Isabella...";
			link.l1.go = "NewLife";
			IsabellaAddMoneyBudget(50000);
		break;
		case "NewLife_Budget_100":
			dialog.text = "D'accord, mon chéri. 100 000, c'est beaucoup, merci.";
			link.l1 = "Il n'y a pas de quoi, ma chérie...";
			link.l1.go = "NewLife";
			IsabellaAddMoneyBudget(100000);
		break;
		case "NewLife_Budget_200":
			dialog.text = "Très bien, mon chéri. 200 000, c'est bien pour le budget familial.";
			link.l1 = "Je suis content que tu sois satisfaite, Isabella...";
			link.l1.go = "NewLife";
			IsabellaAddMoneyBudget(200000);
		break;
		case "NewLife_Budget_500":
			dialog.text = "Autant ! Oם as-tu trouvé tout cet argent ?";
			link.l1 = "Je l'ai gagné, oם veux-tu que ce soit ?";
			link.l1.go = "NewLife";
			IsabellaAddMoneyBudget(500000);
		break;
		case "NewLife_Budget_No":
            dialog.text = LinkRandPhrase("Alors pourquoi l'as-tu proposé ?", "Alors pourquoi en parles-tu ?" , "Alors pourquoi en parler ?");
			link.l1 = LinkRandPhrase("Je me suis trompé, ma chérie, pardonne-moi...", "Pardon, ma chérie, j'ai eu un trou de mémoire...", "Je n'ai pas toute ma tête, en ce moment...");
			link.l1.go = "NewLife";
		break;
		//заплатить долги и понулить счётчик бюджета
		case "NewLife_Budget_Pay":
			iMoney = IsabellaCheckBudgetMoney();
			dialog.text = NPCStringReactionRepeat("C'est bien ça, capitaine " + pchar.name + ", tu as bien laissé traîner les choses ! Alors, je t'en prie, règle cette dette !",
				"Tu aurais dמ trouver l'argent pour régler la dette !",
				"Capitaine, je te demande encore une fois de régler nos arriérés d'impכts !",
				"Capitaine, j'en ai assez de répéter toujours la même chose. Je parle, je parle, mais les problèmes d'argent sont toujours là. Je vais te dire une chose, mon cher mari : je peux régler les problèmes moi-même ! Et je ne veux plus te voir !", "quest", 30, npchar, Dialog.CurrentNode);
			if (sti(pchar.money) >= iMoney)
			{
				link.l1 = HeroStringReactionRepeat("D'accord, ma chérie, je suis prêt à régler la dette.", "Isabella, ma chérie, je me souviens parfaitement de tout. J'ai trouvé l'argent et je suis prêt à solder les dettes.", "Isabella, tout de suite...", "Tu vois, Isabella, en ce moment, je n'ai pas d'argent...", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_Budget_Pay_2";
				link.l2 = "וcoute, ma chérie, je ne l'ai pas en ce moment";
				link.l2.go = "NewLife_Budget_Pay_1";
			}
			else
			{
				link.l1 = HeroStringReactionRepeat(".. " + FindRussianMoneyString(iMoney) + "...", "J'aurais dמ, mais je ne l'ai pas trouvé...", "Isabella, je n'ai pas d'argent en ce moment !", "Ah, c'est comme ça ?", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_Budget_Pay_1";
			}
		break;
		case "NewLife_Budget_Pay_1":
			dialog.text = RandPhraseSimple("Alors va le trouver ! Je ne vais pas m'endetter à cause de toi !", "וcoute-moi bien, mon cher mari ! Je ne veux pas qu'un huissier vienne chez moi tous les deux jours exiger le paiement des dettes ! Trouve l'argent, c'est ta responsabilité directe !");
			link.l1 = RandPhraseSimple("D'accord, Isabella, comme tu voudras...", "Je comprends, Isabella, je vais essayer...");
			link.l1.go = "NewLife_exit";
		break;
		case "NewLife_Budget_Pay_2":
            dialog.text = RandPhraseSimple("Eh bien, c'est formidable ! Je suis très heureuse que mon mari soit un homme responsable.", "Parfait, mon chéri ! Tu es un vrai homme...");
			link.l1 = RandPhraseSimple("Oui...", "Hé, bien sמr !");
			link.l1.go = "NewLife";
			iMoney = IsabellaCheckBudgetMoney();
			AddMoneyToCharacter(pchar, -iMoney);
			IsabellaNullBudget();
		break;
		//=========================== Изабелла узнала, что ГГ опять пиратствует =================================
		case "NewLife_KnowPirates":
			pchar.RomanticQuest.Cheking = "Ok"; //флаг "don't check for piracy anymore" в этот раз
			if (rand(12) < GetCharacterSPECIAL(pchar, "Charisma")) //поверила, дура :)
			{
				dialog.text = LinkRandPhrase("Hum, je te crois, " + pchar.name + "...", "Bon, je préfère te croire, toi, plutכt que des rumeurs !", "C'est toi que j'aimerais croire, " + pchar.name + "... et pas les ragots...");
				link.l1 = RandPhraseSimple("Eh bien, c'est bien, ma chérie.", "Comme c'est bien ! Nous avons vite réglé ça, et le malentendu est dissipé...");
				link.l1.go = "NewLife";
			}
			else //не поверила, и правильно сделала
			{
				dialog.text = NPCStringReactionRepeat("Tu sais, mon chéri, j'ai tendance à croire ces rumeurs et ces racontars. Mais je ne peux rien prouver avec certitude, alors que ce soit ton premier avertissement.",
					"Je crois que je ne vais pas te croire : on en parle trop... Considère ceci comme un deuxième avertissement.",
					"Hum, écoute, je ne comprends pas, tu me prends pour une idiote ? Tout le monde en parle, et lui, il nie ! On dirait que tu ne tiens pas parole. En tout cas, c'était le dernier avertissement, " + pchar.name + ".",
					"דa suffit, capitaine " + pchar.name + ", je n'ai plus confiance en toi. Tu t'es moqué de moi ! Je ne veux plus te parler !", "quest", 80, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("D'accord, ma chérie. Je considère que j'ai été averti une fois.",
					"Bien, ma chérie, que ce soit l'avertissement numéro deux.",
					"Mmm, d'accord, Isabella, que ce soit le dernier avertissement.",
					"Oh, Isabella...", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife";
			}
		break;
		//=========================== Секс =================================
		case "NewLife_Sex":
			if (GetQuestPastMonthParam("RomanticQuest") > 2 && GetNpcQuestPastDayParam(npchar, "sex") != 0)
			{
				dialog.text = "Alors, mon marin, tu as trop longtemps navigué ?";
				link.l1 = "Eh bien, il y a de ça...";
				link.l1.go = "NewLife_Sex_1";
			}
			else
			{
				dialog.text = NPCStringReactionRepeat("De quoi parlez-vous ?",
					"Ah, je devine de quoi tu parles...",
					"Un devoir ? Et qu'est-ce que je te dois ?",
					"Hum, je ne comprends pas...", "cycle", 0, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Oui, c'est toujours de la même chose qu'il s'agit, Isabella : de l'amour...",
					"C'est de ça qu'il s'agit, ma chérie : de l'amour...",
					"Je parle du devoir d'amour, ma chérie...",
					"Isabella, je parle d'amour, ma chérie...", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_Sex_5";
			}
		break;
		case "NewLife_Sex_1":
			SaveCurrentNpcQuestDateParam(npchar, "sex"); //запоминаем секс
			dialog.text = "א ta place, mon chéri, je ne quitterais pas la maison aussi longtemps...";
			link.l1 = "Pourquoi donc ?";
			link.l1.go = "NewLife_Sex_2";
		break;
		case "NewLife_Sex_2":
			dialog.text = "Parce que ta femme est une belle femme, si tu ne l'avais pas encore remarqué. Et à San Juan, il n'y a pas que des femmes : il y a aussi bien des caballeros intéressants...";
			link.l1 = "Hé, diable !! Isabella, qu'est-ce que tu racontes ?!";
			link.l1.go = "NewLife_Sex_3";
		break;
		case "NewLife_Sex_3":
			dialog.text = "Je dis ça pour que tu rentres plus souvent à la maison, mon chéri !";
			link.l1 = "D'accord, Isabella, je te comprends... Ne nous disputons pas, ma chérie...";
			link.l1.go = "NewLife_Sex_4";
		break;
		case "NewLife_Sex_4":
			if (rand(6) < 5)
			{
				dialog.text = "D'accord... Je vais à la chambre...";
				link.l1 = "Je te suis !";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = "D'accord, ne nous disputons pas, mon chéri. Mais j'ai la migraine aujourd'hui, alors ça ne marchera pas. Je suis désolée...";
				link.l1 = "Oh, quel mauvais moment !..";
				link.l1.go = "NewLife_exit";
			}
		break;

		case "NewLife_Sex_Late":
			dialog.text = "Tu sais quoi, mon chéri, je ne vais pas t'attendre ici éternellement, sur le pied de guerre... Tu as laissé passer ta chance !";
			link.l1 = "Isabella, comment ça... ?";
			link.l1.go = "NewLife_Sex_Late_1";
		break;
		case "NewLife_Sex_Late_1":
			chrDisableReloadToLocation = true;
			bDisableFastReload = true;
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "SanJuan_houseSp6", "goto", "goto1", "Romantic_TalkInChurch_end", 3.5);
			NextDiag.TempNode = "NewLife";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NewLife_Sex_5":
			if (GetNpcQuestPastDayParam(npchar, "sex") > 3)
			{
				dialog.text = NPCStringReactionRepeat("Mm-hmm... J'aime ce genre de conversation...",
					"D'amour ? Eh bien, continue, mon chéri...",
					"L'amour, c'est intéressant... Alors, de quoi s'agit-il... ?",
					"Ah, l'amour... Je fais parfois de ces bêtises !..", "block", 60, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Isabella, je brמle de passion !!",
					"Isabella, je brמle de partager ton lit !",
					"Isabella, le désir de te posséder me submerge...",
					"Qu'est-ce que c'est que ces sottises, Isabella ?! Allons vite à la chambre, ma chérie ?", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("NewLife_Sex_10", "NewLife_Sex_11", "NewLife_Sex_12", "NewLife_Sex_13", npchar, Dialog.CurrentNode);
			}
			else //слишком часто, не прокатит
			{
				dialog.text = LinkRandPhrase("On ne peut pas parler d'amour trop souvent, mon chéri. Alors je suis désolée, mais ça ne marchera pas...", "Non, mon chéri, parler trop souvent d'amour est mauvais pour l'âme et pour le corps, c'est ce que dit le padre...", "Oh, mon chéri, je ne veux pas aborder ce sujet trop souvent, ne me fatigue pas, je t'en prie. Dans quelques jours, mon chéri...");
				link.l1 = RandPhraseSimple("Euh... Hum... C'est dommage...", "Ouais, je suis déçu...");
				link.l1.go = "NewLife_exit";
			}
			SaveCurrentNpcQuestDateParam(npchar, "sex"); //запоминаем секс
		break;
		case "NewLife_Sex_10":
			dialog.text = "Alors je t'attends dans la chambre, mon chéri !";
			link.l1 = "Isabella, je te suis...";
			link.l1.go = "NewLife_GoSex";
		break;
		case "NewLife_Sex_11":
			if (rand(10) < 8)
			{
				dialog.text = "Partager le lit ? Bon, d'accord. Je vais à la chambre...";
				link.l1 = "Oh, Isabella...";
				link.l1.go = "NewLife_GoSex";
			}
			else //не свезло
			{
				dialog.text = LinkRandPhrase("J'ai mal à la tête, mon chéri, pas aujourd'hui...", "Je ne me sens pas bien aujourd'hui, mon chéri. Pas maintenant...", "Mon chéri, remettons ça à plus tard... Je ne peux pas, je me sens mal.");
				link.l1 = RandPhraseSimple("Oh, quel mauvais moment !..", "Bon sang !.. Pardon, Isabella, ça m'a échappé...");
				link.l1.go = "NewLife_exit";
			}
		break;
		case "NewLife_Sex_12":
			if (rand(10) < 5)
			{
				dialog.text = "Le désir... Mm-hmm, d'accord. Je t'attends dans la chambre, mon chéri...";
				link.l1 = "Isabella, j'arrive tout de suite !..";
				link.l1.go = "NewLife_GoSex";
			}
			else //не свезло
			{
				dialog.text = LinkRandPhrase("J'ai mal à la tête, mon chéri, pas aujourd'hui...", "Je ne me sens pas bien aujourd'hui, mon chéri. Pas maintenant...", "Mon chéri, remettons ça à plus tard... Je ne peux pas, je me sens mal.");
				link.l1 = RandPhraseSimple("Oh, quel mauvais moment !..", "Bon sang !.. Pardon, Isabella, ça m'a échappé...");
				link.l1.go = "NewLife_exit";
			}
		break;
		case "NewLife_Sex_13":
			if (rand(10) < 2)
			{
				dialog.text = "Mon chéri, tu es un effronté !.. Bon, d'accord, tu m'as convaincue...";
				link.l1 = "Isabella...";
				link.l1.go = "NewLife_GoSex";
			}
			else //не свезло
			{
				dialog.text = "Nous n'irons nulle part ! Et désormais, ne te permets plus de phrases vulgaires !";
				link.l1 = "D'accord, Isabella, pardonne-moi...";
				link.l1.go = "NewLife_exit";
			}
		break;
		//идём в спальню
		case "NewLife_GoSex":
			chrDisableReloadToLocation = true;
			bDisableFastReload = true;
			NextDiag.TempNode = "NewLife";
			NextDiag.CurrentNode = NextDiag.TempNode;
			SaveCurrentNpcQuestDateParam(npchar, "sex"); //запомнить секс
			Pchar.quest.Romantic_Sex.win_condition.l1 = "location";
			Pchar.quest.Romantic_Sex.win_condition.l1.location = "SanJuan_houseS1Bedroom";
			Pchar.quest.Romantic_Sex.win_condition = "Romantic_Sex";
			SetTimerCondition("Romantic_IsabellaBackToHall", 0, 0, 1, false);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload2", "SanJuan_houseS1Bedroom", "goto", "goto6", "Romantic_TalkInChurch_end", 20.0);
			DialogExit();
		break;
		//после секса
		case "NewLife_afterSex":
			dialog.text = NPCStringReactionRepeat("Mm-hmm... Mon chéri, c'était... Merveilleux !",
				"Alors, comment ça va, mon chéri ? Tout va bien ?",
				"Tu n'es pas en forme, aujourd'hui...",
				"Ah, l'amour... C'est bien...", "block", 30, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, ma chérie...",
				"Parfait, ma chérie, tu as été tout simplement merveilleuse !",
				"Hum... Pardonne-moi, ma chérie, c'est arrivé comme ça...",
				"Je suis entièrement d'accord avec toi, ma chérie.", npchar, Dialog.CurrentNode);
			link.l1.go = "NewLife_afterSex_1";
		break;
		case "NewLife_afterSex_1":
			chrDisableReloadToLocation = true;
			bDisableFastReload = true;
			NextDiag.TempNode = "NewLife";
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "SanJuan_houseSp6", "goto", "goto2", "Romantic_TalkInChurch_end", 20.0);
			Pchar.quest.Romantic_IsabellaBackToHall.over = "yes";
			DialogExit();
		break;
		//=========================== Сон =================================
		case "NewLife_Sleep":
			dialog.text = "Quand dois-je te réveiller, mon chéri ?";
			if(!isDay())
			{
				link.l1 = "Le matin, sois gentille...";
				link.l1.go = "NewLife_Sleep_day";
			}
			else
			{
				link.l1 = "Je dois me lever dans la nuit, Isabella.";
				link.l1.go = "NewLife_Sleep_night";
				link.l2 = "Je veux bien dormir. Réveille-moi demain matin.";
				link.l2.go = "NewLife_Sleep_day";
			}
		break;
		case "NewLife_Sleep_day":
			dialog.text = "D'accord, je te réveillerai le matin.";
			link.l1 = "Bon, parfait. Alors, je vais à la chambre...";
			link.l1.go = "room_day_wait";
			link.l2 = "Tu sais, j'ai changé d'avis. Je ne vais pas dormir tout de suite.";
			link.l2.go = "NewLife_exit";
		break;
		case "NewLife_Sleep_night":
			dialog.text = "D'accord, je te réveillerai après minuit.";
			link.l1 = "Parfait, ma chérie. Alors, je vais à la chambre...";
			link.l1.go = "room_night_wait";
			link.l2 = "Tu sais, j'ai changé d'avis. Je préfère passer ce temps debout.";
			link.l2.go = "NewLife_exit";
		break;
		case "room_day_wait":
			DialogExit();
			NextDiag.TempNode = "NewLife_hello";
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate("wait_day");
			AddDialogExitQuest("sleep_in_home");
		break;
		case "room_night_wait":
			DialogExit();
			NextDiag.TempNode = "NewLife_hello";
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate("wait_night");
			AddDialogExitQuest("sleep_in_home");
		break;
		//=========================== Просто разговор =================================
		case "NewLife_JustTalk":
			if (CheckAttribute(pchar, "RomanticQuest.Atilla"))
			{
				switch (pchar.RomanticQuest.Atilla)
				{
					case "YouAreBaster":
						dialog.text = "וcoute, j'ai entendu dire que tu avais mal agi envers ton ami Attila. On dit que tu lui as donné très peu d'argent, alors que je sais tout ce qu'il a fait pour nous... Je suis tout simplement choquée !";
						link.l1 = "Ma chérie, tout ça, c'est fini maintenant, inutile de remuer le passé...";
						link.l1.go = "NewLife_exit";
					break;
					case "YouAreNormal":
						dialog.text = "Mon chéri, j'ai entendu dire que tu avais remercié ton ami Atilla. C'est un geste digne, je suis heureuse que mon mari soit un vrai homme, un homme d'honneur !";
						link.l1 = "Isabella, pouvait-il en être autrement ?";
						link.l1.go = "NewLife_exit";
					break;
					case "YouAreGood":
						dialog.text = "Mon chéri, tu ne m'as rien dit, mais j'ai appris par hasard que tu avais donné une très grosse somme à ton ami Atilla. Je suppose que c'est pour le remercier de tout ce qu'il a fait pour nous. Mon chéri, tu es le meilleur homme du monde ! J'en ai été convaincue une fois de plus.";
						link.l1 = "Isabella, allons... Ce n'est rien, j'ai seulement payé ma dette...";
						link.l1.go = "NewLife_exit";
					break;
				}
				DeleteAttribute(pchar, "RomanticQuest.Atilla");
				break;
			}
			switch (rand(1))
			{
				case 0:
					dialog.text = LinkRandPhrase("Oh, mon chéri, ton attention me fait tellement plaisir...", pchar.name + ", tu es un vrai chevalier...", "Oh, mon Dieu, quelle bénédiction que tu m'aies envoyé pour mari " + GetMainCharacterNameGen() + "...");
					link.l1 = RandPhraseSimple("Moi aussi, j'ai de la chance de t'avoir, ma chérie...", "Tu sais, Isabella, je me dis souvent que nous avons bien fait d'unir nos destins...");
					link.l1.go = "NewLife_exit";
				break;
				case 1:
					dialog.text = LinkRandPhrase("Mon chéri, tu sais, le gouverneur de la ville s'est enquis de notre situation.", "Le gouverneur m'a demandé l'autre jour comment tu allais, mon chéri.", "Hier, j'ai croisé le gouverneur dans la rue et nous avons bavardé. Il voulait savoir comment tu allais.");
					link.l1 = RandPhraseSimple("Tout va bien, dis-le-lui la prochaine fois.", "Je ne dirais pas que l'attention du gouverneur envers toi me flatte...");
					link.l1.go = "NewLife_exit";
				break;
			}
		break;
		//=========================== Подарки =================================
		case "NewLife_Present":
			dialog.text = RandPhraseSimple("Et que veux-tu m'offrir, mon chéri ?", "Allez, dis-moi vite, qu'est-ce que tu vas m'offrir ?");
			iTemp = 1;
			for (i=18; i>=1; i--)
			{
				if (i==8 || i==9) continue;
				if (CheckCharacterItem(pchar, "jewelry"+i))
				{
					sTemp = "l"+iTemp;
					link.(sTemp) = XI_ConvertString("jewelry"+i+"Gen") + ".";
					link.(sTemp).go = "NewLife_jewelry_"+i;
					iTemp++;
				}
			}
			if (iTemp == 1)
			{
				dialog.text = NPCStringReactionRepeat("Et que veux-tu m'offrir, mon chéri ?",
					"Tu veux encore m'offrir quelque chose ? Hum, alors qu'est-ce que c'est ?",
					pchar.name + ", tu te moques de moi avec ces cadeaux ? Qu'est-ce que c'est, cette fois ?",
					"דa suffit, tu m'as eue, espèce d'idiot ! Je suis fâchée contre toi et je ne veux plus te parler !", "repeat", 20, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Rien de tel...",
					"Je n'ai rien qui soit digne de toi, pardonne-moi...",
					"Isabella, je n'ai encore rien trouvé pour toi, pardonne-moi...",
					"Isabella, pardonne-moi !..", npchar, Dialog.CurrentNode);
				link.l1.go = "NewLife_exit";
			}
		break;
		case "NewLife_jewelry_1":
			dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. J'aime beaucoup les saphirs.", "Oh, comme il brille au soleil ! Merci, mon chéri..." , "Une pierre magnifique ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry1");
		break;
		case "NewLife_jewelry_2":
			if (rand(4)==1)
			{
				dialog.text = "Ah, un diamant... J'en deviens folle ! Mon chéri, montons à l'étage !";
				link.l1 = "Avec plaisir, ma chérie.";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. J'aime beaucoup les diamants.", "Oh, comme il brille au soleil ! Merci, mon chéri..." , "Une pierre magnifique ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry2");
		break;
		case "NewLife_jewelry_3":
			if (rand(10)==1)
			{
				dialog.text = "Oh, un rubis ! J'aime tant ces pierres rouge sang ! Mon chéri, tu m'as rendue très heureuse, et maintenant, j'ai envie de monter à l'étage avec toi...";
				link.l1 = "Moi aussi, j'en ai envie, ma chérie...";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. J'aime beaucoup les rubis.", "Oh, comme il brille au soleil ! Merci, mon chéri..." , "Une pierre magnifique ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry3");
		break;
		case "NewLife_jewelry_4":
			if (rand(3)==1)
			{
				dialog.text = "Oh, c'est ma pierre préférée, une émeraude ! Tu me gâtes, mon chéri... Mon amour, j'ai envie de monter à l'étage avec toi...";
				link.l1 = "Moi aussi, j'en ai envie, ma chérie...";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. J'aime beaucoup les émeraudes.", "Oh, comme il brille au soleil ! Merci, mon chéri..." , "Une pierre magnifique ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry4");
		break;
		case "NewLife_jewelry_5":
			dialog.text = LinkRandPhrase("Mmm, de l'or ! Un très beau cadeau, merci, mon chéri.", "Oh, et quelle forme il a, cette pépite ! Merci, mon chéri." , "Une pépite magnifique ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la femme la plus riche des Caraïbes !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry5");
		break;
		case "NewLife_jewelry_6":
			dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Les bijoux ornés de saphirs me vont très bien.", "Oh, comme un saphir est beau dans une monture d'argent ! Merci, mon amour..." , "Une bague magnifique ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry6");
		break;
		case "NewLife_jewelry_7":
			if (rand(2)==1)
			{
				dialog.text = "Ah, une bague ornée de mon émeraude préférée ! Tu me gâtes, mon chéri... Mon amour, j'ai envie de monter à l'étage avec toi...";
				link.l1 = "Moi aussi, j'en ai envie, ma chérie...";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Les bagues ornées d'émeraudes me vont vraiment bien...", "Oh, comme elle brille au soleil, dans sa monture d'or ! Merci, mon chéri..." , "Une pierre magnifique dans une belle monture ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry7");
		break;
		case "NewLife_jewelry_10":
			dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Les bijoux ornés de saphirs me vont très bien.", "Oh, comme un saphir est beau dans une monture d'or ! Merci, mon amour..." , "Une bague magnifique ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry10");
		break;
		case "NewLife_jewelry_11":
			dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Une perle aussi grosse, c'est magnifique !", "Des perles... Les pêcheries de la cכte des perles travaillent bien. Merci, mon chéri." , "Une perle magnifique ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry11");
		break;
		case "NewLife_jewelry_12":
			dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil...", "Des perles... Les pêcheries de la cכte des perles travaillent bien..." , "Une perle magnifique ! Merci, mon chéri...");
			link.l1 = RandPhraseSimple("Hum...", "Hum...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry12");
		break;
		case "NewLife_jewelry_13":
			dialog.text = LinkRandPhrase("Oh, quel bijou intéressant, ce camée... Merci, mon chéri.", "Une petite chose intéressante, mon chéri. Merci..." , "Un joli bijou ! Merci, mon chéri...");
			link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry13");
		break;
		case "NewLife_jewelry_14":
			if (rand(1)==1)
			{
				dialog.text = "Ah, mon chéri, cette broche est digne d'une reine... J'ai envie de monter à l'étage avec toi tout de suite...";
				link.l1 = "Moi aussi, j'en ai envie...";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Cette broche en or est très belle...", "Oh, comme elle est belle en pleine lumière ! Merci, mon chéri..." , "Des pierres magnifiques dans une belle monture ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry14");
		break;
		case "NewLife_jewelry_15":
			if (rand(1)==1)
			{
				dialog.text = "Oh, mon chéri, ces pendentifs... Je suis folle de toi, et j'ai envie de monter à l'étage avec toi tout de suite...";
				link.l1 = "Je ne dis pas non, ma chérie.";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil. Ce pendentif à émeraudes me va très bien...", "Oh, comme les émeraudes sont belles en pleine lumière ! Merci, mon chéri..." , "Des pierres magnifiques dans une belle monture ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry15");
		break;
		case "NewLife_jewelry_16":
			dialog.text = LinkRandPhrase("Mon chéri, garde ce collier pour toi, je ne me vexerai pas...", "Hum, et tu crois que je vais porter ça ?" , "Quel goמt tu as, mon chéri. Tu n'es qu'un balourd, si tu crois que je vais porter ça !");
			link.l1 = RandPhraseSimple("Ah oui ? Eh bien...", "Je me suis trompé...");
			link.l1.go = "NewLife_exit";
		break;
		case "NewLife_jewelry_17":
			dialog.text = LinkRandPhrase("Ah, de l'argent ! Bon, je le prends, ça servira à la maison...", "De l'argent ? Bon, au revoir..." , "Une pépite d'argent ? Hum, l'argent n'a de valeur qu'en grande quantité. Mais d'accord, prenons-la...");
			link.l1 = RandPhraseSimple("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la femme la plus riche des Caraïbes !");
			link.l1.go = "NewLife_exit";
			TakeItemFromCharacter(pchar, "jewelry17");
		break;
		case "NewLife_jewelry_18":
			if (rand(8)==1)
			{
				dialog.text = "Les émeraudes et les rubis sont mes pierres préférées. Cette bague est tout simplement magnifique, tu me gâtes, mon chéri... Mon amour, j'ai envie de monter à l'étage avec toi...";
				link.l1 = "Moi aussi, j'en ai envie...";
				link.l1.go = "NewLife_GoSex";
			}
			else
			{
				dialog.text = LinkRandPhrase("Merci, mon chéri, tu es très gentil, cette bague ornée d'un rubis est très belle...", "Un rubis serti d'or, c'est très beau ! Merci, mon chéri..." , "Une pierre magnifique dans une belle monture ! Merci, mon chéri...");
				link.l1 = LinkRandPhrase("Il n'y a pas de quoi, ma chérie...", "Je veux que tu sois la plus belle femme du monde !", "Tout est pour toi, ma chérie...");
				link.l1.go = "NewLife_exit";
			}
			TakeItemFromCharacter(pchar, "jewelry18");
		break;
		//выход
		case "NewLife_exit":
			NextDiag.TempNode = "NewLife";
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocator(npchar, "goto", "goto"+(rand(3)+1), "Romantic_TalkInChurch_end", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		//==> попытки дать денег
		case "AngryRepeat_Budget_Add":
            dialog.text = RandPhraseSimple("Je ne veux pas parler à un tel rabat-joie ! א moins qu'une bague d'or et d'argent ornée de saphirs ne fasse fondre mon cœur...", "Je ne veux pas parler, tu m'as vexée, rabat-joie et grippe-sou ! D'ailleurs, je veux une bague d'or et d'argent ornée de saphirs...");
			link.l1 = "Oh, Isabella...";
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся 10 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Bon, d'accord, mon cher mari, j'accepte de te reparler. Mais ne sois pas aussi pingre ! Et surtout, ne promets rien quand il n'y a pas d'argent !";
        			link.l1 = "D'accord, Isabella, je vais essayer...";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
				else //примирение через кольцо с сапфиром
				{
					if (CheckCharacterItem(pchar, "jewelry6") && CheckCharacterItem(pchar, "jewelry10"))
					{
         				dialog.text = "Oh, tu m'as apporté ce que je voulais : une bague d'or et d'argent ornée de saphirs ! Hum, tu sais me faire plaisir... Bon, je suis prête à te reparler...";
        				link.l1 = "Ouf, parfait !";
        				link.l1.go = NextDiag.TempNode;
        				CharacterDelAngry(npchar);
						TakeItemFromCharacter(pchar, "jewelry6");
						TakeItemFromCharacter(pchar, "jewelry10");
					}
				}
            }
    	break;
		//==> вовремя не рассчитался с долгами
		case "AngryRepeat_Budget_Pay":
            dialog.text = RandPhraseSimple("וcoute, mon cher mari, tu n'es pas capable de subvenir aux besoins de ta femme, j'ai dמ régler nos problèmes d'argent moi-même. Ce n'est pas bien du tout !", "Rends-toi compte, je dois régler moi-même tous les problèmes de la famille ! Ton incapacité à subvenir aux besoins de ta famille me sidère !");
			link.l1 = "Señora Isabella, c'est arrivé comme ça...";
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся 30 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Bon, j'accepte de me réconcilier, mais tu dois régler toutes les dettes qui se sont accumulées !";
        			link.l1 = "D'accord, Isabella, je ferai tout ce que tu diras.";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
				else //примирение через изумруды
				{
					if (CheckCharacterItem(pchar, "jewelry4") && CheckCharacterItem(pchar, "jewelry7") && CheckCharacterItem(pchar, "jewelry15"))
					{
         				dialog.text = "Salaud ! Tu m'as apporté des bijoux ornés d'émeraudes... J'adore ces pierres, elles me plaisent tant !.. Bon, j'accepte de me réconcilier, mais tu dois régler toutes les dettes qui se sont accumulées !";
        				link.l1 = "D'accord, Isabella, d'accord...";
        				link.l1.go = NextDiag.TempNode;
        				CharacterDelAngry(npchar);
						TakeItemFromCharacter(pchar, "jewelry4");
						TakeItemFromCharacter(pchar, "jewelry7");
						TakeItemFromCharacter(pchar, "jewelry15");
					}
				}
            }
    	break;
		//==> если попался на пиратстве
		case "AngryRepeat_KnowPirates":
            dialog.text = RandPhraseSimple("Tu as trahi la parole que tu m'avais donnée avant le mariage ! Je ne veux plus te voir !", "Tu m'avais promis d'en finir avec la course, mais tu n'as même pas songé à cesser de verser le sang des innocents !");
			link.l1 = "Isabella, je ne voulais pas que ça arrive...";
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся 80 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Voilà, mon mari ! Je suis prête à me réconcilier, mais désormais, tu dois tenir parole !";
        			link.l1 = "D'accord, Isabella, je ferai tout ce que tu diras. Il n'y aura plus de piraterie, ma chérie...";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
					IsabellaSetCurrentState("All");
                }
				else //примирение через алмаз, рубины и большую жемчужину
				{
					if (CheckCharacterItem(pchar, "jewelry1") && CheckCharacterItem(pchar, "jewelry2") && CheckCharacterItem(pchar, "jewelry3") && CheckCharacterItem(pchar, "jewelry18") && CheckCharacterItem(pchar, "jewelry11"))
					{
         				dialog.text = "Oh, " + pchar.name + " – tu sais comment m'apaiser... Mais tu dois tenir parole et en finir avec la course !";
        				link.l1 = "Oh, Isabella, qu'il en soit ainsi. Je ne peux pas vivre sans toi...";
        				link.l1.go = NextDiag.TempNode;
        				CharacterDelAngry(npchar);
						TakeItemFromCharacter(pchar, "jewelry1");
						TakeItemFromCharacter(pchar, "jewelry2");
						TakeItemFromCharacter(pchar, "jewelry3");
						TakeItemFromCharacter(pchar, "jewelry18");
						TakeItemFromCharacter(pchar, "jewelry11");
						IsabellaSetCurrentState("All");
					}
				}
			}
    	break;
		//==> если достал подарками
		case "AngryRepeat_Present":
            dialog.text = RandPhraseSimple("Non, mais c'est tout simplement impossible de vivre avec un tel homme ! Et pourquoi fallait-il me promettre des cadeaux qui n'existent pas ?! Je n'ai pas de mots !!", "Je ne veux pas parler à un balourd aussi borné et aussi effronté ! Offrir à sa femme des cadeaux qui n'existent pas ! Eh bien, merci, mon chéri !..");
			link.l1 = RandPhraseSimple("Isabella, tu es injuste envers moi...", "Je ne sais pas ce qui m'a pris, Isabella. Je ne l'ai pas fait exprès...");
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся 20 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Bon, je suis prête à faire la paix avec toi. Mais ne sois pas aussi balourd, et ne propose pas de cadeaux si tu n'en as pas !";
        			link.l1 = "D'accord, ma chérie, je ne le ferai plus...";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
				else //примирение через злато-серебро
				{
					if (CheckCharacterItem(pchar, "jewelry5") && CheckCharacterItem(pchar, "jewelry17"))
					{
						if (sti(pchar.items.jewelry5) >= 3 && sti(pchar.items.jewelry17) >=5)
						{
         					dialog.text = "דa alors !.. Tu m'as apporté la seule chose dont j'ai vraiment envie en ce moment : des lingots d'or et d'argent... Bon, je suis prête à te reparler. Mais que ce petit jeu cruel avec les cadeaux ne se reproduise plus !!";
        					link.l1 = "D'accord, Isabella, comme tu voudras...";
        					link.l1.go = NextDiag.TempNode;
        					CharacterDelAngry(npchar);
							TakeNItems(pchar, "jewelry5", -3);
							TakeNItems(pchar, "jewelry17", -5);
						}
					}
				}
			}
    	break;
		case "AngryExitAgain":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
		break;

// <<<<<<<<<<<<============= блок нод angry =============================
	}
}
