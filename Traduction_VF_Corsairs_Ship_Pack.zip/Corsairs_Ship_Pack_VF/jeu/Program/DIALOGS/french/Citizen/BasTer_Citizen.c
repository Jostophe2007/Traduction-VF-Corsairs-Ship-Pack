// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			//Gregg+SeaBoss-внес, см. строку-11 - Квест "The Lost Ring.".
			if (CheckAttribute(pchar, "questTemp.PDM_PK_UznatLichnost")) // Квест "The Lost Ring"
            {
                link.l1 = "Parlez-moi d'une femme étrange qui a perdu sa bague. Vous la connaissez ?";
                link.l1.go = "PDM_PK_UznatLichnost";
            }
		break;

		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Que voulez-vous que je vous dise ? Je ne sais pas. Je ne sais rien.";

            link.l1 = "Quel imbécile ! Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

//**************************Квест "The Lost Ring"*******************************
		case "PDM_PK_UznatLichnost":
			int Phrase;
                Phrase = rand(4);
                if (Phrase == 0)
                {
					dialog.text = "Elle est simplement folle, ne faites pas attention à elle.";
					link.l1 = "D'accord.";
					link.l1.go = "exit";
				break;
				}
                if (Phrase == 1)
                {
					dialog.text = "Et pourquoi vous intéressez-vous à cette folle, vous n'avez rien d'autre à faire ?";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 2)
                {
					dialog.text = "J'ai des choses plus importantes à faire que de répondre à de telles sornettes.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 3)
                {
					dialog.text = "Je ne la connais pas, désolé.";
					link.l1 = "Bon, je vais demander à quelqu'un d'autre.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 4)
                {
					dialog.text = "Elle n'a pas simplement perdu une bague. C'est une terrible histoire. J'en ai le cœur brisé chaque fois que je la raconte. Elle s'appelle Josephine Lodet. Elle avait offert une magnifique bague à son fils la veille de son premier voyage. Pour lui porter chance, disait-elle. Il a pris part à l'attaque de Santo Domingo et il a été tué au premier combat. Quand la nouvelle de sa mort est arrivée sur nos rivages, la pauvre Josephine... Enfin, vous avez des yeux, vous avez vu ce qui lui est arrivé.";
					link.l1 = "Quel genre de bague était-ce ?";
					link.l1.go = "PDM_PK_UznatLichnost_2";
				break;
				}
        break;

		case "PDM_PK_UznatLichnost_2":
			dialog.text = "Un bijou très beau et très cher. Le plus beau saphir que j'aie jamais vu, serti dans de l'or. Son grand-père l'avait rapporté d'Europe. Je ne suis pas joaillier, mais il pouvait valoir dix... ou vingt mille ? Ah, une terrible histoire ! Bon, je m'en vais. Au revoir.";
			Link.l1 = "Merci, " + npchar.name+". Vous m'avez été d'une grande aide. Au revoir.";
			Link.l1.go = "exit";

			sld = CharacterFromID("Josephine_Lodet")
			sld.name = "Josephine";
			sld.lastname = "Lodet";

			AddQuestRecord("PDM_Poteryanoe_Koltso", "2");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));

			pchar.questTemp.PDM_PK_IshemKoltso = "IshemKoltso";
			DeleteAttribute(pchar, "questTemp.PDM_PK_UznatLichnost");
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

