// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Oficiantka_Beliz"))	// Квест "Witch Hunt"
			{
				link.l1 = "Savez-vous oם est Maria en ce moment ?";
				link.l1.go = "PDM_ONV_WOMAN";
			}
		break;
		
//========================== Квест "Witch Hunt" ==================================
		case "PDM_ONV_WOMAN":
			dialog.text = "Euh... non. Il vaut mieux demander aux habitants de la ville. Je pense qu'ils vous diront sמrement quelque chose.");
			link.l1 = "D'accord, ma belle, j'y vais.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Oficiantka_Beliz");
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

