
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, Diag;
	string NPC_Meeting;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

    int iTemp, i; // нужно для вычислений любых целых (нации)
	string attrName; // любые строки для вычислений
	ref sld;
	bool bFencing = false;

    switch(Dialog.CurrentNode)
	{
		case "exit":
			StopCoastalGuardPursuit();
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			LAi_SetPlayerType(Pchar);
		break;

		case "First time":
			chrDisableReloadToLocation = false;
   			LAi_LockFightMode(pchar, false);
			dialog.text = RandPhraseSimple("Il semble qu'il se passe ici quelque chose d'illégal.",
                                     "Au nom de "+NationKingsName(npchar)+ ", cessez ces agissements illégaux !!!");
			Link.l1 = "Non, non, officier. Mes amis et moi nous détendons simplement au bord de la mer.";
			if (makeint(Pchar.reputation) > 70 && GetSummonSkillFromNameToOld(Pchar, SKILL_LEADERSHIP) >= 5)
			{
				Link.l1.go = "ThisTimeFree";
			}
			else
			{
				Link.l1.go = "IDontBelieveYou";
			}
			Link.l2 = "Je distribue de l'or. Peut-on considérer cela comme une activité illégale ?";
			if(makeint(Pchar.rank) >= 4 && GetSummonSkillFromNameToOld(Pchar, SKILL_COMMERCE) >= 2)
			{
				Link.l2.go = "GiveMeSomeMoneyToo";
			}
			else
			{
				Link.l2.go = "TryingToGiveBribe";
			}
			Link.l3 = "Fiche le camp, soldat. דa ne te regarde pas !";
			//#20181215-02
			if(GetSummonSkillFromNameToOld(Pchar, SKILL_FENCING) >= 8)
                bFencing = true;
            if(!bFencing && GetSummonSkillFromNameToOld(Pchar, SKILL_F_LIGHT) >= 8)
                bFencing = true;
            if(!bFencing && GetSummonSkillFromNameToOld(Pchar, SKILL_F_HEAVY) >= 8)
                bFencing = true;
			if(makeint(Pchar.reputation) < 20 && bFencing)
			{
				Link.l3.go = "GettingLostFromHere";
			}
			else
			{
				Link.l3.go = "howDareYou";
			}

		break;

		case "ThisTimeFree":
			dialog.snd = "Voice\COGU\COGU002";
			dialog.text = "Ne nous faites pas d'histoires, capitaine " + Pchar.name + " ! Qui aurait cru qu'une personne aussi honorable et respectée que vous trempait dans la contrebande !";
			Link.l1 = "Hélas, tout le monde fait des erreurs. Mais je me repens déjà !";
			Link.l1.go = "ThisTimeFree_1";
			Link.l2 = "Je vais te couper la tête tout de suite !";
			Link.l2.go = "ThisTimeFree_fight";
		break;

		case "ThisTimeFree_1":
			dialog.snd = "Voice\COGU\COGU003";
			ChangeCharacterReputation(pchar, -40);
			dialog.text = "Comme je n'ai entendu que du bien de vous, je vous laisse partir pour cette fois. Et nous emmenons ces salauds avec nous !";
			Link.l1 = "Merci, officier. Tous mes vœux !";
			Link.l1.go = "ThisTimeFree_exit";
		break;

		case "ThisTimeFree_fight":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			for (i = 1; i <= sti(Pchar.quest.contraband.SoldierQty); i++)
			{
    			attrName = "SoldierIDX"+i;
				sld = GetCharacter(sti(Pchar.quest.contraband.(attrName)));
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "CoastalGuards");
            }

			LAi_group_SetRelation(pchar.GenQuest.Smugglers_Group, "CoastalGuards", LAI_GROUP_ENEMY);
			LAi_group_SetHearRadius("CoastalGuards", 100.0);
			LAi_group_SetHearRadius(pchar.GenQuest.Smugglers_Group, 100.0);
			LAi_group_FightGroups("CoastalGuards", pchar.GenQuest.Smugglers_Group, true);
			LAi_group_SetRelation("CoastalGuards", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("CoastalGuards", LAI_GROUP_PLAYER, true);

			//LAi_SetPlayerType(Pchar);
            LAi_SetFightMode(Pchar, true);
			//trace("And we fight those soldiers!!" + Pchar.quest.contraband.CurrentPlace);
		break;

		case "ThisTimeFree_exit":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;

            DialogExit();
			StopCoastalGuardPursuit();
			ChangeContrabandRelation(pchar, -30);
			for (i = 1; i <= sti(Pchar.quest.contraband.SoldierQty); i++)
			{
    			attrName = "SoldierIDX"+i;
				sld = GetCharacter(sti(Pchar.quest.contraband.(attrName)));
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "CoastalGuards");
            }
			LAi_group_SetRelation(pchar.GenQuest.Smugglers_Group, "CoastalGuards", LAI_GROUP_ENEMY);
			LAi_group_FightGroups(pchar.GenQuest.Smugglers_Group, "CoastalGuards", true);
			LAi_SetPlayerType(Pchar);
		break;

		case "IDontBelieveYou":
			dialog.snd = "Voice\COGU\COGU004";
			dialog.text = "Qu'est-ce que vous me racontez ! Je ne suis pas aveugle ! Suivez-nous : vous êtes en état d'arrestation et la marchandise est confisquée !";
			Link.l1 = "Dépêche-toi, ou je t'étripe !";
			Link.l1.go = "ThisTimeFree_fight";
		break;

		case "GiveMeSomeMoneyToo":
			dialog.snd = "Voice\COGU\COGU005";
			dialog.text = "Ah oui ? Non, bien sמr, cette activité est parfaitement légale... Si nous en avons notre part aussi, bien sמr. Et combien distribuez-vous ?";
			Link.l1 = "Je pense que " + makeint(sti(Pchar.contratradedmoney)*(0.1+(0.01*MOD_SKILL_ENEMY_RATE*3))) + " piastres suffiront.";
			//if(makeint(Pchar.rank)*1000 <= makeint(sti(Pchar.money)/10))
			if (sti(pchar.money)>=makeint(sti(Pchar.contratradedmoney)*(0.1+(0.01*MOD_SKILL_ENEMY_RATE*3))))
			{
				Link.l1.go = "MoneyAccepted10";
			}
			else
			{
				Link.l1.go = "TryingToGiveBribe";
			}
			Link.l2 = "J'ai changé d'avis, soldat. Je ne paierai pas une seule pièce. Fiche le camp !"
			if(GetSummonSkillFromNameToOld(Pchar, SKILL_FENCING) >= 8)
                bFencing = true;
            if(!bFencing && GetSummonSkillFromNameToOld(Pchar, SKILL_F_LIGHT) >= 8)
                bFencing = true;
            if(!bFencing && GetSummonSkillFromNameToOld(Pchar, SKILL_F_HEAVY) >= 8)
                bFencing = true;
			if (makeint(Pchar.reputation) < 20 && bFencing)
			{
				Link.l2.go = "GettingLostFromHere";
			}
			else
			{
				Link.l2.go = "howDareYou";
			}

			/*Link.l2 = "How about " + makeint(sti(Pchar.money)/5) + "piastres?";
			if(makeint(Pchar.rank)*1000 <= makeint(sti(Pchar.money)/5))
			{
				Link.l2.go = "MoneyAccepted5";
			}
			else
			{
				Link.l2.go = "TryingToGiveBribe";
			}

			Link.l3 = "I'm ready to give it to you, officer " + makeint(sti(Pchar.money)/2) + "piastres!";
			if(makeint(Pchar.rank)*1000 <= makeint(sti(Pchar.money)/2))
			{
				Link.l3.go = "MoneyAccepted2";
			}
			else
			{
				Link.l3.go = "TryingToGiveBribe";
			}*/
		break;

		case "TryingToGiveBribe":
			dialog.snd = "Voice\COGU\COGU006";
			dialog.text = "Ah, vous proposez un pot-de-vin ? Non, l'honneur de l'uniforme m'est plus précieux ! Veuillez nous suivre !";
			Link.l1 = "Bon sang ! Désolé de vous décevoir, mais je ne crois pas que vous irez oם que ce soit maintenant !";
			Link.l1.go = "ThisTimeFree_fight";
		break;

		case "MoneyAccepted10":
			dialog.snd = "Voice\COGU\COGU007";
			dialog.text = "J'accepte volontiers votre don. Puisque vous faites œuvre de charité.";
			Link.l1 = "Toujours à votre service.";
			Link.l1.go = "GettingLostFromHere_exit";
			AddMoneyToCharacter(pchar, -makeint(sti(Pchar.contratradedmoney)*(0.1+(0.01*MOD_SKILL_ENEMY_RATE*3))));
		break;

		case "MoneyAccepted5":
			dialog.snd = "Voice\COGU\COGU007";
			dialog.text = "J'accepte volontiers votre don. Puisque vous faites œuvre de charité.";
			Link.l1 = "Toujours à votre service.";
			Link.l1.go = "GettingLostFromHere_exit";
			AddMoneyToCharacter(pchar, -makeint(sti(Pchar.money)/5));
		break;

		case "MoneyAccepted2":
			dialog.snd = "Voice\COGU\COGU007";
			dialog.text = "J'accepte volontiers votre don. Puisque vous faites œuvre de charité.";
			Link.l1 = "Toujours à votre service.";
			Link.l1.go = "GettingLostFromHere_exit";
			AddMoneyToCharacter(pchar, -makeint(sti(Pchar.money)/2));
		break;

		case "GettingLostFromHere":
			dialog.snd = "Voice\COGU\COGU008";
			dialog.text = "Mais... Diable... Je dois vous arrêter !";
			Link.l1 = "Arrgh ! Tu es encore là ? Tu en as assez de vivre ?";
			Link.l1.go = "GettingLostFromHere_1";
		break;

		case "GettingLostFromHere_1":
			dialog.snd = "Voice\COGU\COGU009";
			dialog.text = "Je... Je vais porter plainte ! Je ne vais pas laisser passer ça...";
			Link.l1 = "Pff !";
			Link.l1.go = "GettingLostFromHere_exit";
		break;

		case "GettingLostFromHere_exit":
			ChangeContrabandRelation(pchar, 10);
			// патруль спроважен миром (откуп/на испуг) - боя не было, смуглеры не должны хвалить за драку
			if (CheckAttribute(PChar, "GenQuest.contraTravel.PatrolFight")) PChar.GenQuest.contraTravel.PatrolBribed = true;
			SmugRevenge_ArmDeathWatch(); // вырежешь смуглеров после откупа - братство пришлёт мстителей

			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
            DialogExit();

			StopCoastalGuardPursuit();
			for (i = 1; i <= sti(Pchar.quest.contraband.SoldierQty); i++)
			{
                attrName = "SoldierIDX"+i;
                LAi_SetActorType(&Characters[sti(Pchar.quest.contraband.(attrName))]);
                LAi_ActorRunToLocation(&Characters[sti(Pchar.quest.contraband.(attrName))], "reload", "Reload1", "none", "", "", "", 40);
			}
			LAi_SetPlayerType(Pchar);
		break;

		case "howDareYou":
			dialog.snd = "Voice\COGU\COGU010";
			dialog.text = "Oh, chien ! Maintenant, tu ne t'en tireras certainement pas. Tu vas mourir sur ce rivage !";
			Link.l1 = "Essaie donc de tenir parole, moulin à paroles !";
			Link.l1.go = "ThisTimeFree_fight";
		break;
	}
}
