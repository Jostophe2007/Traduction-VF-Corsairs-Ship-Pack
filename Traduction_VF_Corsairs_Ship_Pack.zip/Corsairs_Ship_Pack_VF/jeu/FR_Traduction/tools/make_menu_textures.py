# -*- coding: utf-8 -*-
"""Build French versions of the main-menu sign textures (Text01.tga / Text02.tga).

The English textures hold 6 bands (New Game, Load Game, Settings, Multiplayer, Credits, Exit),
each = left ornament + label + right ornament. The ornaments are reused; the label is redrawn
in small caps (serif font) with a golden material + dark outline, fitted in the original band.
Output: FR_Traduction/assets/MainMenu/Text01.tga, Text02.tga
"""
import os
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SRC = os.path.join(ROOT, 'RESOURCE', 'Textures', 'MainMenu', 'English')
OUT = os.path.join(ROOT, 'FR_Traduction', 'assets', 'MainMenu')
LABELS = ['Nouvelle partie', 'Charger', 'Options', 'Multijoueur', 'Crédits', 'Quitter']
FONT_CANDIDATES = [r'C:\Windows\Fonts\palab.ttf', r'C:\Windows\Fonts\georgiab.ttf', r'C:\Windows\Fonts\timesbd.ttf']


def find_bands(alpha):
    rows = (alpha > 20).sum(1)
    bands, inb, s = [], False, 0
    for y, v in enumerate(rows):
        if v and not inb:
            inb, s = True, y
        elif not v and inb:
            inb = False
            if y - s > 6:
                bands.append((s, y))
    if inb:
        bands.append((s, len(rows)))
    return bands


def segments(alpha, y0, y1):
    cols = (alpha[y0:y1] > 20).sum(0)
    segs, ins, s = [], False, 0
    for x, v in enumerate(cols):
        if v and not ins:
            ins, s = True, x
        elif not v and ins:
            ins = False
            segs.append([s, x])
    if ins:
        segs.append([s, len(cols)])
    return segs


def material(w, h, ref):
    """golden material: per-row colour profile measured on the original letters + grain."""
    rng = np.random.default_rng(7)
    prof = ref  # (N,3) colours from top to bottom
    idx = np.linspace(0, len(prof) - 1, h).astype(int)
    base = prof[idx][:, None, :].repeat(w, 1).astype(np.float32)
    noise = rng.normal(0, 1, (h // 2 + 1, w // 2 + 1)).astype(np.float32)
    noise = np.asarray(Image.fromarray(noise).resize((w, h), Image.BILINEAR))
    spots = rng.random((h // 3 + 1, w // 3 + 1)).astype(np.float32)
    spots = np.asarray(Image.fromarray(spots).resize((w, h), Image.BICUBIC))
    shade = 1.0 + 0.10 * noise - 0.28 * np.clip(spots - 0.72, 0, 1) * 3
    return np.clip(base * shade[..., None], 0, 255)


def color_profile(img, alpha, y0, y1, x0, x1):
    sub = img[y0:y1, x0:x1, :3].astype(np.float32)
    a = alpha[y0:y1, x0:x1] > 200
    # remove dark outline pixels
    lum = sub.mean(-1)
    prof = []
    for r in range(sub.shape[0]):
        m = a[r] & (lum[r] > 90)
        prof.append(sub[r][m].mean(0) if m.sum() > 2 else None)
    good = [p for p in prof if p is not None]
    fill = np.mean(good, 0) if good else np.array([200, 160, 70.0])
    prof = [p if p is not None else fill for p in prof]
    return np.array(prof)


def render_label(text, cap_h, font_path, ref_prof):
    """small caps: first letter of each word at full size, others at 0.8; returns RGBA array."""
    big = ImageFont.truetype(font_path, int(cap_h / 0.70))
    small = ImageFont.truetype(font_path, int(cap_h / 0.70 * 0.80))
    pad = 6
    # layout
    x = pad
    parts = []
    for wi, word in enumerate(text.split(' ')):
        if wi:
            x += int(cap_h * 0.38)
        for ci, ch in enumerate(word):
            f = big if (ci == 0 and wi == 0) else small
            c = ch.upper()
            bb = f.getbbox(c)
            parts.append((c, f, x))
            x += f.getlength(c) + cap_h * 0.02
    W = int(x + pad)
    H = int(cap_h * 1.9)
    mask = Image.new('L', (W, H), 0)
    d = ImageDraw.Draw(mask)
    base_y = int(cap_h * 1.45)
    for c, f, xx in parts:
        d.text((xx, base_y), c, font=f, fill=255, anchor='ls')
    m = np.asarray(mask).astype(np.float32) / 255.0
    # outline = dilated mask
    outline = np.asarray(mask.filter(ImageFilter.MaxFilter(5))).astype(np.float32) / 255.0
    ys, xs = np.nonzero(m > 0.1)
    top, bot = ys.min(), ys.max()
    mat = np.zeros((H, W, 3), np.float32)
    mat[top:bot + 1] = material(W, bot - top + 1, ref_prof)
    # bevel: lighten upper-left edges, darken lower-right
    sh = np.roll(np.roll(m, 1, 0), 1, 1) - m
    mat *= (1.0 - 0.35 * np.clip(sh, 0, 1))[..., None]
    sh2 = np.roll(np.roll(m, -1, 0), -1, 1) - m
    mat = mat + 60 * np.clip(sh2, 0, 1)[..., None]
    dark = np.array([45, 28, 10], np.float32)
    rgb = mat * m[..., None] + dark * (1 - m[..., None])
    a = np.clip(np.maximum(m, outline * 0.92), 0, 1)
    out = np.dstack([np.clip(rgb, 0, 255), a * 255]).astype(np.uint8)
    # crop
    ys, xs = np.nonzero(out[..., 3] > 10)
    return out[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def main():
    font = next(p for p in FONT_CANDIDATES if os.path.exists(p))
    os.makedirs(OUT, exist_ok=True)
    for name in ('Text01.tga', 'Text02.tga'):
        im = Image.open(os.path.join(SRC, name)).convert('RGBA')
        arr = np.asarray(im).copy()
        alpha = arr[..., 3]
        bands = find_bands(alpha)
        out = np.zeros_like(arr)
        for bi, (y0, y1) in enumerate(bands[:len(LABELS)]):
            segs = segments(alpha, y0, y1)
            left, right = segs[0], segs[-1]
            text_x0, text_x1 = segs[1][0], segs[-2][1]
            # vertical extent of the label letters
            lab = alpha[y0:y1, text_x0:text_x1] > 20
            ys = np.nonzero(lab.any(1))[0]
            ly0, ly1 = y0 + ys.min(), y0 + ys.max()
            prof = color_profile(arr, alpha, ly0, ly1 + 1, text_x0, text_x1)
            cap_h = (ly1 - ly0 + 1) * 0.78
            label = render_label(LABELS[bi], cap_h, font, prof)
            orn_l = arr[y0:y1, left[0]:left[1]]
            orn_r = arr[y0:y1, right[0]:right[1]]
            gap = max(6, (text_x0 - left[1]))
            total_w = orn_l.shape[1] + orn_r.shape[1] + 2 * gap + label.shape[1]
            avail = right[1] - left[0]          # stay inside the original sign area
            if total_w > avail:
                gap = 5
                total_w = orn_l.shape[1] + orn_r.shape[1] + 2 * gap + label.shape[1]
            scale = min(1.0, avail / float(total_w))
            if scale < 1.0:
                lw = int(label.shape[1] * scale)
                lh = int(label.shape[0] * scale)
                label = np.asarray(Image.fromarray(label).resize((lw, lh), Image.LANCZOS))
                ow = lambda o: np.asarray(Image.fromarray(o).resize((max(1, int(o.shape[1] * scale)), max(1, int(o.shape[0] * scale))), Image.LANCZOS))
                orn_l, orn_r = ow(orn_l), ow(orn_r)
                gap = int(gap * scale)
            total_w = orn_l.shape[1] + orn_r.shape[1] + 2 * gap + label.shape[1]
            cx = (left[0] + right[1]) / 2.0
            x = int(round(cx - total_w / 2.0))
            x = max(2, min(x, 510 - total_w))
            cy = (y0 + y1) / 2.0
            canvas = Image.fromarray(out)
            for piece in (orn_l, None, orn_r):
                if piece is None:
                    p = label
                    py = int(round((ly0 + ly1) / 2.0 - p.shape[0] / 2.0))
                else:
                    p = piece
                    py = int(round(cy - p.shape[0] / 2.0))
                canvas.alpha_composite(Image.fromarray(np.ascontiguousarray(p)), (x, py))
                x += p.shape[1] + gap
            out = np.asarray(canvas).copy()
        Image.fromarray(out).save(os.path.join(OUT, name))
        print('ecrit', os.path.join(OUT, name), [b for b in bands])


if __name__ == '__main__':
    main()
