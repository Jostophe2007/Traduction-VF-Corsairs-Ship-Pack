
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	string sTemp, sStr, sPlace;
	float locx, locy, locz;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	if (!CheckAttribute(NPChar,"refreshanim") && NPChar.id != "Ostin") NPChar.refreshanim = "yes";
    if (NPChar.refreshanim == "yes")
    {
        if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) NPChar.model.animation = "man_fast"; //LEO: Превозмогаторам страдать 08.12.2021
        if (bHardBoss) NPChar.AlwaysReload = true;//перезарядка независимо от Дозарядки
        NPChar.refreshanim = "no";
		CheckForCirass(NPChar);
		AddHealingPots(NPChar,true);
    }
	if (Dialog.CurrentNode == "First time")
	{
		switch (pchar.questTemp.tugs.berglarState)
		{
			case "2": Dialog.CurrentNode = "Second time";	break;
			case "3": Dialog.CurrentNode = "Third time";	break;
			case "4": Dialog.CurrentNode = "Fourth time";	break;
			case "5": Dialog.CurrentNode = "Fifth time";	break;
			case "6": Dialog.CurrentNode = "Sixth time";	break;
		}
	}

	switch (Dialog.CurrentNode)
    {
        //------------- первая боевка --------------
		case "First time":
            dialog.text = "Attendez, "+ GetSexPhrase("l'ami","ma petite") +"... Ayez la bonté de me dire votre nom ?";
            if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = GetFullName(pchar) + " en personne. Qu'y a-t-il ?";
				link.l1.go = "Step1_1";
			}
			link.l2 = "Désolé, mais je n'achète ni ne vends rien en ce moment. Au revoir.";
			link.l2.go = "exit";
        break;
 		case "Step1_1":
        	dialog.text = "Ouais, c'est bien celui qu'il me faut...";
    		link.l1 = "Je vous écoute attentivement.";
    		link.l1.go = "Step1_2";
		break;
 		case "Step1_2":
			if (npchar.city == "SentJons" || npchar.city == "FortFrance") sStr = "sous";
			else sStr = "derrière";
        	dialog.text = "C'est bien d'être prudent, car nous devons discuter de quelque chose d'important... Alors voilà : je vous attendrai dans le souterrain qui se trouve " + sStr + " la ville.";
    		link.l1 = "Et si nous allions à la taverne pour en discuter ? Qu'est-ce que c'est que ces histoires de terriers ?";
    		link.l1.go = "Step1_3";
		break;
 		case "Step1_3":
        	dialog.text = "Non, nous n'avons pas besoin d'oreilles et d'yeux en trop, croyez-moi...";
    		link.l1 = "Hum, je ne sais même pas... דa en vaut la peine ?";
    		link.l1.go = "Step1_4";
		break;
 		case "Step1_4":
        	dialog.text = "Une question de vie ou de mort, "+ GetSexPhrase("l'ami","ma petite") +". Bon, je n'ai pas le temps de vous parler ici, je vous attends dans le souterrain jusqu'à minuit. Si vous ne venez pas, tant pis pour vous...";
    		link.l1 = "C'est ce que je voulais demander...";
    		link.l1.go = "Step_overAll";
			AddQuestRecord("BerglarsGang", "1");
			AddQuestUserData("BerglarsGang", "sCity", GetCityName(npchar.City));
		break;
		//--------------
        case "Fight_1":
            dialog.text = "Vous voilà...";
            link.l1 = "Oui, je suis venu. Dites-moi vite, quelle est votre affaire de vie ou de mort ?";
            link.l1.go = "FirstFight_1";
			PChar.quest.Birglars_Time.over = "yes";
        break;
		case "FirstFight_1":
            dialog.text = "C'est vrai, "+ GetSexPhrase("l'ami","ma petite") +", c'est bien ça... Précisons les détails : il s'agit de TA mort.";
            link.l1 = "De quoi parlez-vous ?";
            link.l1.go = "FirstFight_2";
        break;
		case "FirstFight_2":
            dialog.text = "J'espère que tu t'es confessé récemment. Tu vas maintenant rejoindre tes ancêtres ; ce serait bien que tu aies communié, sinon je vais me faire du souci pour toi...";
            link.l1 = "Hé, j'apprécie ta sollicitude. Tu sais seulement à qui tu parles sur ce ton ?";
            link.l1.go = "FirstFight_3";
        break;
		case "FirstFight_3":
            dialog.text = "Un capitaine, c'est tout, et je n'ai pas besoin d'en savoir plus. Tu n'es pas le premier imbécile qui vient ici et y reste pour toujours. D'ailleurs, tu marches juste sur l'un d'eux, c'était un brave gars. Et il était beau comme Apollon. Tu comprends, je dois absolument te tuer, il n'y a pas d'autre solution.";
            link.l1 = "דa alors, je n'aurais jamais cru qu'un tueur cynique puisse se cacher derrière une telle apparence...";
            link.l1.go = "FirstFight_4";
		break;
		case "FirstFight_4":
            dialog.text = "Hé, c'est voulu, "+ GetSexPhrase("l'ami","ma petite") +", les apparences sont trompeuses. Je voulais dire : retiens-le pour l'avenir, mais quel avenir as-tu...";
			link.l1 = "J'espère qu'il sera heureux...";
            link.l1.go = "FirstFight_overAll";
			AddQuestRecord("BerglarsGang", "2");
        break;
        //------------ вторая боевка ----------------
        case "Second time":
            dialog.text = "Dites-moi, puis-je vous prendre une minute ?";
			if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = "Vous pouvez.";
				link.l1.go = "Step2_1";
			}
			link.l2 = "Désolé, mais je n'achète ni ne vends rien en ce moment. Au revoir.";
			link.l2.go = "exit";
        break;
        case "Step2_1":
            dialog.text = "Votre nom...";
            link.l1 = GetFullName(pchar) + ". Et alors ?";
            link.l1.go = "Step2_2";
        break;
        case "Step2_2":
            dialog.text = "Alors, c'est vous qu'il me faut. J'ai quelque chose pour vous, il faut qu'on se voie en privé.";
            link.l1 = "Allons à la taverne, on boira une chope et on discutera de tout là-bas.";
            link.l1.go = "Step2_3";
        break;
        case "Step2_3":
			if (npchar.city == "SentJons" || npchar.city == "FortFrance") sStr = "sous";
			else sStr = "près de ";
            dialog.text = "Je suis désolé, mais je ne peux pas, et croyez-moi, il y a une raison. Je ne peux pas vous parler longtemps, je vous demande donc de venir dans le souterrain qui se trouve " + sStr + " la ville.";
            link.l1 = "Hé, ça me rappelle quelque chose...";
            link.l1.go = "Step_overAll";
			AddQuestRecord("BerglarsGang", "3");
			AddQuestUserData("BerglarsGang", "sCity", GetCityName(npchar.City));
        break;
		//----------
        case "Fight_2":
            dialog.text = "J'attendais...";
            link.l1 = "Oui, comme vous voyez, je suis là. Qu'avez-vous pour moi, dites-le vite !";
            link.l1.go = "SecondFight_1";
			PChar.quest.Birglars_Time.over = "yes";
        break;
        case "SecondFight_1":
            dialog.text = "Sors tout ce que tu as, et dis-moi quel navire tu as, quelles marchandises sont dans les cales...";
            link.l1 = "Et pourquoi donc ?";
            link.l1.go = "SecondFight_2";
        break;
        case "SecondFight_2":
            dialog.text = "Parle, sale garce, sinon tu vas perdre la tête dans un instant !";
            link.l1 = "Pff, quelle attaque ! Tu es le deuxième à essayer de me tuer de cette façon.";
            link.l1.go = "SecondFight_3";
        break;
        case "SecondFight_3":
            dialog.text = "Hum, voilà donc comment c'est, bon, maintenant, quelque chose s'éclaire pour moi...";
            link.l1 = "Et qu'est-ce qui s'éclaire pour toi ?";
            link.l1.go = "FirstFight_overAll";
			AddQuestRecord("BerglarsGang", "4");
        break;
        //------------ третья встреча, сумасшедший ----------------
        case "Third time":
            dialog.text = "Méfie-toi des optimates, "+ GetSexPhrase("l'ami","ma petite") +" !";
			if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = "Quoi ?";
				link.l1.go = "Step3_1";
			}
			link.l2 = "וcarte-toi, ou j'appelle la garde, fou que tu es !";
			link.l2.go = "exit";
        break;
        case "Step3_1":
            dialog.text = "Les proscriptions de Sylla sont un mal absolu ! S'il savait seulement ce que ça va faire à l'empire...";
            link.l1 = "De quoi parlez-vous ?";
            link.l1.go = "Step3_2";
        break;
        case "Step3_2":
            dialog.text = "Comment ça, quoi ? Tu ne comprends pas ?! « Méfiez-vous du jeune homme mal ceinturé » : voilà ce que Sylla disait aux optimates, et il avait raison ! Le divin Jules a détruit les restes de la république...";
            link.l1 = "Mon vieux, on dirait que tu es très malade. Alors, désolé, mais je m'en vais...";
            link.l1.go = "Step3_3";
        break;
        case "Step3_3":
            dialog.text = "Oם ça ?! Oם vas-tu ? Le mal est à chaque coin de rue, et tu as déjà eu le malheur de connaître son contact glacé. Tomber deux fois dans le piège et échapper à la mort, hi hi hi...";
            link.l1 = "Tu parles de ces gens étranges qui m'ont invité dans le souterrain et ont essayé de me tuer ?";
            link.l1.go = "Step3_4";
        break;
        case "Step3_4":
            dialog.text = "C'est vrai, "+ GetSexPhrase("mon ami","ma chère") +", c'est bien ça...";
            link.l1 = "Mais qui sont-ils, bon sang ?!";
            link.l1.go = "Step3_5";
        break;
        case "Step3_5":
            dialog.text = "Hi hi hi, je ne le dirai pas...";
            link.l1 = "Parle, ou je te tords le cou en un éclair !";
            link.l1.go = "Step3_6";
        break;
        case "Step3_6":
            dialog.text = "Je n'ai plus peur... J'ai tué des capitaines aussi, j'ai dמ le faire... Ah, la peur me rongeait l'âme !!! Mais maintenant, c'est fini, je n'ai plus peur. Et je dois me dépêcher ! Il faut prévenir Auguste qu'il ne réchauffe pas sa vésicule, mais qu'au contraire, il se fasse une compresse froide. Alors, la bile sortira...";
            link.l1 = "Quoi ?!";
            link.l1.go = "Step3_7";
        break;
        case "Step3_7":
            dialog.text = "Rien, ça ne te concerne pas. Ce sont mes affaires avec les Césars !";
            link.l1 = "Ah, c'est compréhensible...";
            link.l1.go = "Step3_8";
        break;
        case "Step3_8":
            dialog.text = "Bon, cherche-les. Il faut que tu arrives jusqu'à Austin avant qu'ils n'apprennent que tu en as tué deux. Sois prudent et rusé, ne les effraie pas, sinon, ils disparaîtront !";
            link.l1 = "Austin ?";
            link.l1.go = "Step3_9";
			AddQuestRecord("BerglarsGang", "5");
			AddQuestUserData("BerglarsGang", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("BerglarsGang", "sCity", GetCityName(npchar.City));
        break;
        case "Step3_9":
			sTemp = "berglar" + npchar.city;
			pchar.questTemp.tugs.berglarState = sti(pchar.questTemp.tugs.berglarState) + 1; //счётчик
			npchar.LifeDay = 0;
			LAi_SetActorTypeNoGroup(NPChar);
            LAi_ActorRunToLocation(NPChar, "reload", pchar.questTemp.tugs.(sTemp).locator, "none", "", "", "", -1);
			pchar.questTemp.(sTemp) = "over";
			DialogExit();
        break;
        //------------ четвёртая встреча ----------------
        case "Fourth time":
            dialog.text = "Bonjour, " + GetAddress_Form(NPChar) + ".";
			if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = "Bonjour. א quoi dois-je l'honneur ?";
				link.l1.go = "Step4_1";
			}
			link.l2 = "Désolé, mais je n'achète ni ne vends rien en ce moment. Au revoir.";
			link.l2.go = "exit";
        break;
        case "Step4_1":
            dialog.text = "וcoutez, j'ai quelque chose pour vous qui vous intéressera sans aucun doute. Et à un prix raisonnable !";
            link.l1 = "Eh bien, je suis toujours à la recherche de propositions d'affaires. Dites-moi ce que vous avez.";
            link.l1.go = "Step4_2";
        break;
        case "Step4_2":
			if (npchar.city == "SentJons" || npchar.city == "FortFrance") sStr = "sous";
			else sStr = "derrière";
            dialog.text = "Pas ici, " + GetAddress_Form(NPChar) + ". Pas besoin d'yeux et d'oreilles en trop. Je vous attendrai jusqu'à minuit dans le souterrain qui se trouve " + sStr + " la ville. Venez, vous ne le regretterez pas !";
            link.l1 = "Tu sais, l'ami, tu es déjà le troisième type quelconque à m'inviter dans les catacombes du coin. Les deux dernières fois, ça s'est très mal terminé...";
            link.l1.go = "Step4_3";
            link.l2 = "Hé, je viendrai volontiers au rendez-vous, vous m'avez intrigué. C'est cher ?";
            link.l2.go = "Step4_5";
        break;
        case "Step4_3":
			pchar.questTemp.OstinDelete = "true";
            dialog.text = "Ah, c'est comme ça... Désolé, notre affaire est annulée.";
            link.l1 = "Vraiment ?!";
            link.l1.go = "Step4_4";
        break;
        case "Step4_4":
			sTemp = "berglar" + npchar.city;
			npchar.LifeDay = 0;
			LAi_SetActorTypeNoGroup(NPChar);
            LAi_ActorRunToLocation(NPChar, "reload", pchar.questTemp.tugs.(sTemp).locator, "none", "", "", "", -1);
			pchar.questTemp.(sTemp) = "over";
			AddQuestRecord("BerglarsGang", "6");
			AddQuestUserData("BerglarsGang", "sSex", GetSexPhrase("", "e"));
			AddDialogExitQuestFunction("Birglars_Time");
			DialogExit();
        break;
        case "Step4_5":
            dialog.text = "Oui, ce n'est pas bon marché.";
            link.l1 = "Alors, je prendrai plus d'argent !";
            link.l1.go = "Step4_6";
        break;
        case "Step4_6":
            dialog.text = "Eh bien, j'ai hâte de vous voir, " + GetAddress_Form(NPChar) + ".";
            link.l1 = "א bientכt, l'ami.";
            link.l1.go = "Step_overAll";
			AddQuestRecord("BerglarsGang", "7");
			AddQuestUserData("BerglarsGang", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("BerglarsGang", "sCity", GetCityName(npchar.City));
        break;
        case "Fight_4":
            dialog.text = "Ah, enfin !";
            link.l1 = "Dites-moi ce que vous avez.";
            link.l1.go = "Fight4_1";
			PChar.quest.Birglars_Time.over = "yes";
        break;
        case "Fight4_1":
            dialog.text = "Hé, vous voilà. Combien d'argent avez-vous apporté ?";
            link.l1 = "Montrez d'abord votre marchandise.";
            link.l1.go = "Fight4_2";
        break;
        case "Fight4_2":
			dialog.text = "Mais il n'y a pas de marchandise, vous n'avez toujours pas compris ?";
            link.l1 = "Pas besoin d'être très malin pour le comprendre. Tu es le troisième d'affilée à essayer de me dépouiller de cette façon. Alors, dis-moi qui vous êtes et qui est Austin ?";
            link.l1.go = "Fight4_3";
        break;
        case "Fight4_3":
            dialog.text = "Je ne m'attendais pas à un tel retournement...";
            link.l1 = "Je comprends... Bon, arrête de tirer le chat par la queue, réponds tout de suite aux questions, ou tu vas mourir !";
            link.l1.go = "Fight4_4";
        break;
        case "Fight4_4":
            dialog.text = "Hum, je ne serais pas si catégorique.";
            link.l1 = "Tu l'as cherché, alors...";
            link.l1.go = "FirstFight_overAll";
			AddQuestRecord("BerglarsGang", "8");
        break;
        //------------ пятая встреча ----------------
        case "Fifth time":
            dialog.text = "Bonjour, " + GetAddress_Form(NPChar) + ". Dites-moi, vous ne seriez pas ce célèbre capitaine qui transporte de grosses cargaisons de coprah de l'Ancien Monde ?";
			if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = "Non, je ne fais pas de transport vers l'Ancien Monde.";
				link.l1.go = "Step5_1";
			}
			link.l2 = "Désolé, mais j'ai des choses à faire en ce moment. Au revoir.";
			link.l2.go = "exit";
        break;
        case "Step5_1":
            dialog.text = "Oh, quel dommage, quel dommage ! Je voulais proposer à ce capitaine une affaire extrêmement avantageuse.";
            link.l1 = "Vous avez besoin de coprah ?";
            link.l1.go = "Step5_2";
        break;
        case "Step5_2":
            dialog.text = "Non, pas du tout ! J'ai une marchandise peu volumineuse, mais très chère. C'est exactement ce dont rêvent les capitaines marchands : un minimum de place à bord, et un maximum de bénéfices.";
            link.l1 = "Et quelle est cette marchandise ? דa pourrait m'intéresser.";
            link.l1.go = "Step5_3";
        break;
        case "Step5_3":
            dialog.text = "Hum, capitaine, je ne peux pas le dire comme ça. Vous comprenez, la sécurité avant tout. Je ne peux pas abattre toutes mes cartes devant le premier venu.";
            link.l1 = "Mais comment puis-je, moi ou n'importe quel autre capitaine, évaluer l'intérêt de la transaction si vous ne voulez pas parler de la marchandise ?";
            link.l1.go = "Step5_4";
        break;
        case "Step5_4":
			if (npchar.city == "SentJons" || npchar.city == "FortFrance") sStr = "sous";
			else sStr = "derrière";
            dialog.text = "Je suis prêt à tout discuter en détail, mais pas ici. Je vous propose de nous retrouver seul à seul dans le souterrain qui se trouve " + sStr + " la ville. Ce ne sera pas long, mais je serai sמr de ma propre sécurité.";
            link.l1 = "Hé, on m'a déjà donné rendez-vous trois fois dans des souterrains. Et les trois fois, on a essayé de m'y tuer.";
            link.l1.go = "Step5_5";
            link.l2 = "Je pense que c'est une exigence juste. De nos jours, il faut être très prudent...";
            link.l2.go = "Step5_7";
        break;
        case "Step5_5":
			pchar.questTemp.OstinDelete = "true";
            dialog.text = "Dans ce cas, nous n'avons rien à nous dire !";
            link.l1 = "...";
            link.l1.go = "Step5_6";
        break;
        case "Step5_6":
			sTemp = "berglar" + npchar.city;
			npchar.LifeDay = 0;
			LAi_SetActorTypeNoGroup(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", pchar.questTemp.tugs.(sTemp).locator, "none", "", "", "", -1);
			pchar.questTemp.(sTemp) = "over";
			AddQuestRecord("BerglarsGang", "9");
			AddQuestUserData("BerglarsGang", "sSex", GetSexPhrase("", "e"));
			AddDialogExitQuestFunction("Birglars_Time");
			DialogExit();
        break;
        case "Step5_7":
            dialog.text = "Bon, c'est réglé. Je vous attendrai là-bas jusqu'à minuit ; si vous ne venez pas, tout est annulé.";
            link.l1 = "D'accord, compris.";
            link.l1.go = "Step_overAll";
        break;
        case "Fight_5":
            dialog.text = "Bien, bien, bien, parfait !";
            link.l1 = "Montrez votre marchandise.";
            link.l1.go = "Fight5_1";
			PChar.quest.Birglars_Time.over = "yes";
        break;
        case "Fight5_1":
            dialog.text = "Vous savez, j'ai une mauvaise nouvelle. La marchandise a disparu, mais vous allez devoir la payer quand même.";
            link.l1 = "Hum, comme d'habitude...";
            link.l1.go = "Fight5_2";
        break;
        case "Fight5_2":
            dialog.text = "De quoi parlez-vous ?";
            link.l1 = "De mémoire, tu es déjà le quatrième escroc à essayer de me dépouiller de cette façon. La chasse est ouverte contre moi, ou quoi ?";
            link.l1.go = "Fight5_3";
        break;
        case "Fight5_3":
            dialog.text = "Alors, tu les as tous tués ?! Hum, un adversaire de valeur...";
            link.l1 = "Dis-moi oם est Austin, et tu vivras.";
            link.l1.go = "Fight5_4";
        break;
        case "Fight5_4":
            dialog.text = "Si je te dis oם est Austin, je suis fichu de toute façon : la bande ne pardonne pas la trahison. Comme ça, au moins, j'ai une chance de survivre.";
            link.l1 = "Tu n'as aucune chance de survivre à un combat contre moi. Parle, tu vivras plus longtemps, au moins...";
            link.l1.go = "Fight5_5";
        break;
        case "Fight5_5":
            dialog.text = "J'essaierai quand même !";
            link.l1 = "Hum, comme tu voudras...";
            link.l1.go = "FirstFight_overAll";
			AddQuestRecord("BerglarsGang", "11");
        break;
        //------------ шестая встреча ----------------
        case "Sixth time":
            dialog.text = "Mes salutations, " + GetAddress_Form(NPChar) + ". Dites-moi, vous êtes bien le capitaine " + GetFullName(pchar) + " ?";
			if (!CheckAttribute(pchar, "BlockOstin"))
			{
				link.l1 = "Oui, c'est bien moi.";
				link.l1.go = "Step6_1";
			}
			link.l2 = "Désolé, mais j'ai des choses à faire en ce moment. Au revoir.";
			link.l2.go = "exit";
        break;
        case "Step6_1":
			dialog.text = "J'ai un message pour vous : un certain Austin souhaite vous voir.";
            link.l1 = "Hum, d'accord.";
            link.l1.go = "Step6_2";
        break;
        case "Step6_2":
			if (npchar.city == "SentJons" || npchar.city == "FortFrance") sStr = "sous";
			else sStr = "derrière";
            dialog.text = "Bien. Il vous attendra jusqu'à minuit dans le souterrain qui se trouve " + sStr + " la ville.";
            link.l1 = "Toujours la même chanson... Bon, d'accord.";
            link.l1.go = "Step_overAll";
			AddQuestRecord("BerglarsGang", "12");
			AddQuestUserData("BerglarsGang", "sCity", GetCityName(npchar.City));
        break;
        case "Fight_6":
            dialog.text = "Ah, vous voilà...";
            link.l1 = "Oם est Austin ?";
            link.l1.go = "Fight6_1";
			PChar.quest.Birglars_Time.over = "yes";
        break;
        case "Fight6_1":
            dialog.text = "Il n'est pas là en personne, mais il vous envoie ses salutations et a ordonné qu'on vous tue.";
            link.l1 = "Hum, rien de nouveau. Tu sais ce qui est arrivé à ceux qui ont essayé avant toi ?";
            link.l1.go = "Fight6_2";
        break;
        case "Fight6_2":
            dialog.text = "Je sais, mais je pense que j'y arriverai.";
            link.l1 = "Bon, mais oם est ce foutu Austin ? Il commence sérieusement à me fatiguer, pour être honnête.";
            link.l1.go = "Fight6_3";
        break;
        case "Fight6_3":
            dialog.text = "Il vit dans l'un des villages de pêcheurs de perles, sur la cכte ouest du continent.";
            link.l1 = "Eh bien, merci pour l'information : je n'aurais jamais deviné que le chef d'une bande de voleurs et d'assassins se cachait si loin.";
            link.l1.go = "Fight6_4";
        break;
        case "Fight6_4":
            dialog.text = "Eh bien, voyons maintenant si tu sauras te servir de ce que tu sais.";
            link.l1 = "Comme tu voudras, l'ami...";
            link.l1.go = "FirstFight_overAll";
			AddQuestRecord("BerglarsGang", "13");
        break;
		//------------ общие ноды ----------------
 		case "Step_overAll":
			sTemp = "berglar" + npchar.city;
			LAi_LocationDisableMonGenTimer(pchar.questTemp.tugs.(sTemp), 1); //монстров не генерить 1 день
			LAi_LocationDisableOffGenTimer(pchar.questTemp.tugs.(sTemp), 1); //офицеров не пускать 1 день
			LAi_LocationDisableToughSkeletonTimer(pchar.questTemp.tugs.(sTemp), 1); //ПК не пускать 1 день
			sStr = "Birglars_fight_" + npchar.index;
			pchar.quest.(sStr).win_condition.l1 = "locator";
			pchar.quest.(sStr).win_condition.l1.location = pchar.questTemp.tugs.(sTemp);
			pchar.quest.(sStr).win_condition.l1.locator_group = "item";
			pchar.quest.(sStr).win_condition.l1.locator = "berglar1";
			pchar.quest.(sStr).function = "Birglars_fight";
			pchar.quest.(sStr).city = npchar.city; //запомним город грабителя
			npchar.LifeDay = 1;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
            NextDiag.CurrentNode = "Fight_" + pchar.questTemp.tugs.berglarState;
			if (npchar.city == "SentJons")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("blade22"));
			}
			if (npchar.city == "FortFrance")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("blade31"));
			}
			if (npchar.city == "Marigo")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("blade34"));
			}
			if (npchar.city == "Panama")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("blade21"));
			}
			if (npchar.city == "Cartahena")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("topor2"));
			}
			if (npchar.city == "SantaCatalina")
			{
				GiveItem2Character(npchar, "pistol2");
				GiveItem2Character(npchar, GetGeneratedItem("blade15"));
			}
			LAi_SetActorTypeNoGroup(NPChar);
            LAi_ActorRunToLocation(NPChar, "reload", pchar.questTemp.tugs.(sTemp).locator, pchar.questTemp.tugs.(sTemp), "item", "berglar1", "OpenTheDoors", -1.0);
			chrDisableReloadToLocation = true;
			PChar.quest.Birglars_Time.win_condition.l1 = "Timer";
			PChar.quest.Birglars_Time.win_condition.l1.date.hour = 22;
			PChar.quest.Birglars_Time.win_condition.l1.date.day = GetAddingDataDay(0, 0, 0);
			PChar.quest.Birglars_Time.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
			PChar.quest.Birglars_Time.win_condition.l1.date.year = GetAddingDataYear(0, 0, 0);
			PChar.quest.Birglars_Time.function = "Birglars_Time";
			//pchar.questTemp.tugs.(sTemp) = "fight";
			DialogExit();
		break;
		case "FirstFight_overAll":
			LAi_group_Delete("EnemyFight");
			pchar.questTemp.tugs.berglarState = sti(pchar.questTemp.tugs.berglarState) + 1; //счётчик
			npchar.SaveItemsForDead  = true;
			npchar.DontClearDead = true;
			SetCharacterPerk(npchar, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			npchar.cirassId           = Items_FindItemIdx("cirass5"); //1.2.3
			sTemp = "berglar" + npchar.city;

			// дадим слухи
			if(sti(pchar.questTemp.tugs.berglarState) == 2)
			{
				AddSimpleRumourCityTip("Oh, nous vivons une époque difficile, " + GetAddress_Form(pchar) + ". Il y avait un navire en rade il y a peu ; son capitaine est descendu à terre, mais n'est jamais revenu à bord. Ce n'est qu'une semaine plus tard que les gardes ont trouvé son cadavre dans les grottes, hors de la ville... la gorge tranchée d'une oreille à l'autre !.. " +
					"Pendant l'enquête, les habitants ont raconté qu'ils avaient vu ce capitaine se diriger vers la grotte avec un filou d'apparence tout à fait ordinaire. Alors, il faut garder les yeux ouverts...", npchar.city, 3, 1, "habitue", "");
			}
			if(sti(pchar.questTemp.tugs.berglarState) == 4)
			{
				AddSimpleRumourCityTip("Il nous est arrivé une drכle d'histoire : un capitaine a disparu... Il est descendu de son navire, et plus aucune nouvelle. On l'a retrouvé un mois plus tard, dans une grotte hors de la ville. Une balle dans la tête, et pas un sou en poche ! Oui, " + GetAddress_Form(pchar) + ", je vous le dis, ce n'est pas l'œuvre des mauvais esprits ! Les mauvais esprits ne fouillent pas les poches. Il s'agit d'autre chose, c'est certain !.. " +
					"J'ai entendu dire que des capitaines avaient aussi disparu à St. John's, et pas qu'une fois... Allez, à la vכtre...", npchar.city, 3, 1, "habitue", "");
			}

			LAi_SetHP(npchar, stf(pchar.questTemp.tugs.(sTemp).hp), stf(pchar.questTemp.tugs.(sTemp).hp));
			LAi_SetCurHPMax(npchar);
			chrDisableReloadToLocation = true;
			DeleteAttribute(npchar, "city"); //чтобы не ругались с нацией
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			if (npchar.id == "BerglarFortFrance")
			{
				GetCharacterPos(pchar, &locx, &locy, &locz);
				if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man_fast", 18, PIRATE, 0, true)); //LEO: Превозмогаторам страдать 08.12.2021
				else sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man", 18, PIRATE, 0, true));
				if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
				FantomMakeCoolFighter(sld, 18, 60, 50, BLADE_LONG, "pistol3", 10);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				ChangeCharacterAddressGroup(sld, npchar.location, "monsters", LAi_FindNearestFreeLocator("monsters", locx, locy, locz));
			}
			if (npchar.id == "BerglarPanama")
			{
				GetCharacterPos(pchar, &locx, &locy, &locz);
				if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man_fast", 21, PIRATE, 0, true)); //LEO: Превозмогаторам страдать 08.12.2021
				else sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man", 21, PIRATE, 0, true));
				if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
				FantomMakeCoolFighter(sld, 21, 60, 50, BLADE_LONG, "pistol3", 20);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				ChangeCharacterAddressGroup(sld, npchar.location, "monsters", LAi_FindNearestFreeLocator("monsters", locx, locy, locz));
			}
			if (npchar.id == "BerglarSantaCatalina")
			{
				GetCharacterPos(pchar, &locx, &locy, &locz);
				if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man_fast", 20, PIRATE, 0, true)); //LEO: Превозмогаторам страдать 08.12.2021
				else sld = GetCharacter(NPC_GenerateCharacter("Berglars_Helper", "pirate_"+(rand(9)+1), "man", "man", 20, PIRATE, 0, true));
				if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
				FantomMakeCoolFighter(sld, 20, 60, 50, BLADE_LONG, "pistol3", 20);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				ChangeCharacterAddressGroup(sld, npchar.location, "monsters", LAi_FindNearestFreeLocator("monsters", locx, locy, locz));
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");

			//--> главарь грабителей
			if (sti(pchar.questTemp.tugs.berglarState) > 6)
			{
				pchar.quest.Berglars_Ostin.win_condition.l1 = "location";
				pchar.quest.Berglars_Ostin.win_condition.l1.location = "PearlTown2_House6";
				pchar.quest.Berglars_Ostin.win_condition = "Berglars_Ostin";
				//==> трём базу по квесту
				DeleteAttribute(pchar, "questTemp.tugs");
				//==> ставим счётчик, чтобы не глючило по коду
				pchar.questTemp.tugs.berglarState = 0;
			}
			//<-- главарь грабителей

			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;
        //------------ финальная боевка с Остином ----------------
        case "Final_fight":
            dialog.text = "Salut à toi, visiteur ! C'est une rareté, dans notre coin perdu. א quoi dois-je cet honneur ?";
            link.l1 = "Bonjour, Austin. Je voulais te voir en personne, pour ainsi dire. Parce que tes gens m'envoient tes salutations, et tout finit toujours dans les souterrains...";
            link.l1.go = "StepF1_1";
        break;
        case "StepF1_1":
            dialog.text = "Austin ? Peu de gens connaissent mon nom... Ah, je comprends. Vous êtes le capitaine qui a tué plusieurs de mes gens : " + GetFullName(pchar) + ", n'est-ce pas ?";
            link.l1 = "C'est bien ça, Austin... Dis-moi, mon ami, qu'est-ce qui se passe en ce bas monde ? Des assassins rכdent dans les villes, attirent les capitaines crédules et leur ouvrent le ventre.";
            link.l1.go = "StepF1_2";
        break;
        case "StepF1_2":
            dialog.text = "Je n'en crois pas mes oreilles ! Tu essaies de me faire honte ? Toi qui fais exactement la même chose ?!";
            link.l1 = "Qu'est-ce que ça veut dire ?!";
            link.l1.go = "StepF1_3";
        break;
        case "StepF1_3":
            dialog.text = "Tu ne pourchasses pas les marchands sur toute la mer ? Tu ne tues pas les gens par centaines ? Et je pose la question : pour quoi faire ? J'y réponds moi-même : pour l'argent. Nous sommes "+ GetSexPhrase("frères","frère et sœur") +" par le sang de nos victimes, sauf que moi, je suis un frère de la terre ferme.";
            link.l1 = "Moi, je n'attire pas lâchement les gens dans des trous !";
            link.l1.go = "StepF1_4";
        break;
        case "StepF1_4":
            dialog.text = "Hum, tu ne hisses pas les pavillons d'autres puissances pour tromper ta victime et l'approcher sans encombre ?";
            link.l1 = "Ce n'est pas pareil...";
            link.l1.go = "StepF1_5";
        break;
        case "StepF1_5":
            dialog.text = "C'est la même chose, "+ GetSexPhrase("l'ami","ma petite") +" ! La tromperie, le meurtre, la mainmise sur les biens de la victime. Tout concorde, "+ GetSexPhrase("frère de la cכte","sœur de la cכte") +". Alors je vais répondre à la question que tu posais au début : il ne se passe rien d'extraordinaire, tout est comme avant, et tout suit son cours habituel.";
            link.l1 = "Tu enrobes bien les choses...";
            link.l1.go = "StepF1_6";
        break;
        case "StepF1_6":
            dialog.text = "Hum, peut-être bien... Dis-moi pourquoi tu es là, "+ GetSexPhrase("frère de la cכte","sœur de la cכte") +" ?";
            link.l1 = "Tu es doué pour embrouiller les gens, mais on ne me la fait pas. Et je vais te dire une chose : il y a une énorme différence entre nous. Moi, je laisse le choix aux gens : se rendre ou accepter la mort. Toi, tu ne laisses aucun choix, et toutes tes victimes sont enterrées au même endroit, dans les souterrains. Alors tu n'es pas mon frère.";
            link.l1.go = "StepF1_7";
        break;
        case "StepF1_7":
            dialog.text = "Tu es là pour en découdre ?";
            link.l1 = "Exactement. Je veux finir ce que j'ai commencé et débarrasser les Caraïbes de la racaille.";
            link.l1.go = "StepF1_8";
        break;
        case "StepF1_8":
            dialog.text = "Eh bien, tant mieux, tu m'as bien fatigué, toi aussi. Allons-y, ordure !";
            link.l1 = "Il est temps, je crois...";
            link.l1.go = "StepF1_9";
        break;
        case "StepF1_9":
			LAi_LocationFightDisable(loadedLocation, false);
			AddQuestRecord("BerglarsGang", "14");
			AddQuestUserData("BerglarsGang", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("BerglarsGang");
			pchar.questdata.Ostin = 1;
			LAi_group_Delete("EnemyFight");
			LAi_group_MoveCharacter(npchar, "EnemyFight");
   			npchar.cirassId           = Items_FindItemIdx("cirass5"); //1.2.3
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;

 		case "Exit":
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
    }
}
