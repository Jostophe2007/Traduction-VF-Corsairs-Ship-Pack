// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
            dialog.text = "Parlez, je vous écoute.";
			link.l1 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Adieu.";
			link.l1.go = "Exit";
			// ==> Проверяем поле состояния квестов.
            if (pchar.questTemp.State == "WormEnglPlans_SaveOfficer")   // разговор по квест №3 голландской линейке.
            {
    			link.l2 = "Je veux voir le lieutenant Alan McLane.";
    			link.l2.go = "Step_H3_1";
            }
             // <== Проверяем поле состояния квестов.
		break;

        case "Step_H3_1":
            dialog.text = "C'est impossible.";
			link.l1 = "Tout est possible, mais pour ça, il va falloir tous vous tuer. En garde !";
			link.l1.go = "fight";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

