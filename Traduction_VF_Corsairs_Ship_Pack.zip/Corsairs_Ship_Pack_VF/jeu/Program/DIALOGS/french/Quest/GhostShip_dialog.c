
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;
	bool bOk;
	ref shTo;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
        case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Mes salutations, "+ GetSexPhrase("frère","sœur") +" !";
			link.l1 = GetSexPhrase("Frère","Sœur") +" ? Tu es visiblement un métis indien. Et qu'est-ce que tu fais dans de tels haillons ?";
			link.l1.go = "Meeting_1";
			NextDiag.TempNode = "First time";
		break;

        case "Meeting_1":
			dialog.text = "C'était mon erreur ? Toi es homme blanc, moi blanc aussi, mon nom est même « Garçon Blanc ». Ces habits sont souvenir de mes ancêtres, je les porte depuis longtemps.";
			link.l1 = "Bon, c'est sמr que tu n'es pas une fille, mais tu as clairement passé l'âge d'être un garçon, et tu n'as toujours pas de cervelle. Pourquoi te promener en haillons toute ta vie ?";
			link.l1.go = "Meeting_2";
		break;

		case "Meeting_2":
			dialog.text = "Pas comprendre toi. Moi fils de la fille du grand chaman et du capitaine blanc d'un grand navire. Je porte ça pour que les esprits ne me voient pas et ne m'emmènent pas chez eux.";
			link.l1 = "Bref, encore un fou, tout est clair. Tu vends des perles ?";
			link.l1.go = "Meeting_3";
		break;

		case "Meeting_3":
			dialog.text = "Moi acheter des perles.";
			link.l1 = "Tu achètes ou tu vends ? Tu en as ?";
			link.l1.go = "Meeting_4";
		break;

		case "Meeting_4":
			dialog.text = "Non, pas maintenant, mais toi en avoir besoin.";
			link.l1 = "Tu m'as embrouillé comme un idiot. Adieu.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "AfterMeet";
			ReOpenQuestHeader("GhostShipQuest");
        	AddQuestRecord("GhostShipQuest", "4");
		break;

		case "AfterMeet":
			dialog.text = "Voilà "+ GetSexPhrase("frère","sœur") +"  au visage pâle de retour. Tu as quelque chose à dire ?";
			link.l1 = "Non, nous n'avons rien à nous dire.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "AfterMeet";
			bOk = (sti(PChar.GenQuest.GhostShip.KillMe) > 0) || (sti(PChar.GenQuest.GhostShip.DeadByMe) > 0);
			if (bOk && !CheckAttribute(pchar , "GenQuest.GhostShip.NeedCoins"))
            {
    			Link.l3 = "Que sais-tu du vaisseau fantכme ?";
    			Link.l3.go = "GhostCapt";
			}
			if (GetCharacterItem(Pchar, "Coins") >= 666 && CheckAttribute(pchar , "GenQuest.GhostShip.NeedCoins"))
			{
                Link.l4 = "Je t'ai apporté"+ GetSexPhrase("","") +" tes perles.";
    			Link.l4.go = "quest_coin_2";
			}
		break;

		// корабль
		case "GhostCapt":
			NextDiag.TempNode = "AfterMeet";
			dialog.Text = "Grand navire ? Naviguer depuis longtemps, d'abord simple, puis devenir fantכme avec voile noire.";
			Link.l1 = "Quand et comment est-il apparu ?";
			Link.l1.go = "GhostCapt_1";
		break;

		case "GhostCapt_1":
			dialog.Text = "Une erreur, ou peut-être mauvais esprit du capitaine venu. Ils étaient ici il y a 40 hivers, vivaient et commerçaient en paix. Le capitaine a beaucoup offensé la tribu, a pris ma mère de force, nous a pillés, a volé les perles noires sacrées.";
			Link.l1 = "Hum... C'est monnaie courante, mais comment le vaisseau fantכme est-il apparu ?";
			Link.l1.go = "GhostCapt_2";
		break;

		case "GhostCapt_2":
			dialog.Text = "J'ai déjà tout expliqué. Tu n'écoutes pas ? Notre chef a exigé la vie du capitaine en signe de réconciliation, les marins ont soutenu le capitaine et le navire est parti loin, très loin. Alors le chaman de notre peuple a maudit le capitaine et le navire.";
			Link.l1 = "La malédiction, je l'imaginais comme quelque chose de mauvais. Comment ont-ils obtenu la puissance et l'immortalité ?";
			Link.l1.go = "GhostCapt_3";
		break;

		case "GhostCapt_3":
			dialog.Text = "Ils vont souffrir, beaucoup souffrir. דa ne marche pas comme ça, le pouvoir des perles sacrées les protège, ils souffriront jusqu'à ce que tout revienne. Je me tiens ici depuis ma naissance et je rassemble nos perles, je les échange contre des blanches, ils vendent, je cherche.";
			Link.l1 = "א mon avis, ce sont les autres qui souffrent le plus de cette malédiction. Leur trancher la gorge la nuit, et c'est tout. Comment peut-on leur retirer leur immortalité ?";
			Link.l1.go = "GhostCapt_4";
		break;

		case "GhostCapt_4":
			dialog.Text = "Il ne reste plus beaucoup, ils ont déjà presque tout dépensé, j'ai rassemblé tout ce qu'il y avait, il en reste très peu, il me faut 666 perles noires de leur navire. Alors la malédiction se retournera du bon cכté.";
			Link.l1 = "D'accord, attends-moi, je reviendrai !";
			Link.l1.go = "Exit";
			AddQuestRecord("GhostShipQuest", "5");
			PChar.GenQuest.GhostShip.NeedCoins = true;
		break;

		case "quest_coin_2":
            dialog.Text = "C'est très bien. Toi nous sauver tous ! Dépêche-toi de me les donner. Tout ce que tu as à faire, c'est de croiser à nouveau le navire et de le briser ou de le prendre au combat. C'est la fin de leur voyage. Maintenant, ils deviennent de simples pirates, sans voile noire.";
			Link.l1 = "Bien. Prends-les.";
			Link.l1.go = "Exit";
			TakeNItems(pchar, "Coins", -666);
			AddQuestRecord("GhostShipQuest", "6");
			AddQuestUserData("GhostShipQuest", "sSex", GetSexPhrase("", "e"));
			PChar.GenQuest.GhostShip.LastBattle = true;
			NPChar.location = "none";
			NPChar.LifeDay = 0;
			GhostShipOnMap();
            NextDiag.TempNode = "temp_coins";
		break;

		case "temp_coins":
            dialog.Text = "Merci, ami.";
			Link.l1 = "J'espère que tout se passera comme tu l'as promis.";
			Link.l1.go = "Exit";
			NextDiag.TempNode = "temp_coins";
		break;

		case "GhostCapt_Prize":
			dialog.text = "Mes salutations, " + GetSexPhrase("jeune homme","ma dame") + " ! Cela faisait bien longtemps que des capitaines aussi braves et aussi habiles n'étaient pas venus dans notre marais."
			link.l1 = "Qui êtes-vous ?! Et d'oם sortez-vous ?";
			link.l1.go = "GhostCapt_Prize1";
		break;

		case "GhostCapt_Prize1":
			dialog.text = "Oui... rares sont ceux, même parmi ceux qui m'ont vu vivant, qui reconnaîtraient aujourd'hui le vieux Davy Jones...";
			link.l1 = "Alors vous êtes le légendaire capitaine du Hollandais volant, Davy Jones ?!";
			link.l1.go = "GhostCapt_Prize2";
		break;

		case "GhostCapt_Prize2":
			dialog.text = "Ho ho ! Non, "+ GetSexPhrase("jeune homme","ma dame") +", je ne suis que sa pitoyable copie, ou plutכt ce qu'il en reste...  " +
				"Bon, passons aux choses sérieuses : comment se fait-il que mon beau navire ne t'ait pas fait peur ? Et tu as même réussi à le trouer de partout, au point de l'envoyer dans la gueule des calmars, ha ha.. " +
				"Bon, je ne t'en veux pas : il ne lui arrivera rien, demain il sera de nouveau à flot. Mais avoue que tu as eu une sacrée chance : sans ce boulet sous la ligne de flottaison, tu barboterais en ce moment comme une crevette en eau peu profonde, ha ha ha.. " +
				"et dès demain, tu tiendrais compagnie à mes gars. Et je t'aurais volontiers pris dans mon équipage, comme second. דa ne te dit pas ?";
			link.l1 = "Non, je me suis donné tant de mal justement pour ne pas partir dans l'autre monde après le combat. J'ai encore beaucoup à faire ici.";
			link.l1.go = "GhostCapt_Prize21";
		break;

		case "GhostCapt_Prize21":
			dialog.text = "Eh bien, si tel est ton destin, vis... pour l'instant. Ah, avoue que je t'ai bien malmené, moi aussi, ho ho ho... " +
				"Oh, sans ce boulet juste sous la ligne de flottaison... J'ai quelques idées sur la façon de te remercier en retour. Je crois que je vais te donner ce talisman. Les connaisseurs l'appellent « Jonas ». Si tu le possèdes, tu ne craindras plus aucune tempête. Tiens, n'aie pas peur, ce n'est pas une diablerie.";
				Log_Info("Vous avez reçu le talisman « Jonas ».");
			AddItems(pchar, "talisman2", 1);
			pchar.questTemp.IonaGathered = true;
			link.l1 = "Incroyable ! Merci du fond du cœur.";
			link.l1.go = "GhostCapt_Prize3";
		break;

		case "GhostCapt_Prize3":
			dialog.text = "Au fait, pendant notre combat, il m'a semblé que tu n'avais pas révélé tout ton potentiel de capitaine. Mais je pense que c'est par manque d'expérience. Je peux t'aider pour ça. Ou bien tu préfères n'apprendre que de tes erreurs, hein ?";
			link.l1 = "Ce serait bête de refuser. Allez, dites-moi.";
			link.l1.go = "GhostCapt_Prize31";
			link.l2 = "Non, merci, je préfère me débrouiller seul.";
			link.l2.go = "GhostCapt_noupgrade";
		break;
		
		case "GhostCapt_Prize31":
			WasteTime(1);
			dialog.text = "...Alors, tu sens déjà les changements ? Je suppose que oui. Et ne me remercie pas, tu as vraiment su m'impressionner. Et puis... si tu passes par l'ouest du continent, trouve Garçon Blanc dans le village de pêcheurs de perles, et salue-le de ma part...";
			link.l1 = "Et que dois-je lui dire : qu'il a le bonjour du défunt capitaine du Hollandais volant, M. Davy Jones ?";
			link.l1.go = "GhostCapt_Prize5";
			pchar.GhostShipTuning = true;
		break;

		case "GhostCapt_noupgrade":
			dialog.text = "Regarde-moi ça ! Tu fais le brave. Je te le dis, tu as de la chance, "+ GetSexPhrase("blanc-bec","gamine") +". Je vais tirer les oreilles à mes canonniers, la prochaine fois, je t'enverrai par le fond !.. Bon, il est temps pour moi. Je suis resté trop longtemps avec toi. C'est rare, tu sais, de parler comme ça avec un vivant..\n"+
				"Et puis... si tu passes par l'ouest du continent, trouve Garçon Blanc dans le village de pêcheurs de perles, et salue-le de ma part...";
			link.l1 = "Et que dois-je lui dire : qu'il a le bonjour du défunt capitaine du Hollandais volant, M. Van der Decken ?";
			link.l1.go = "GhostCapt_Prize5";
		break;

		case "GhostCapt_Prize5":
			dialog.text = "Hum, c'est vrai... Bon, je n'ai besoin de rien... Si c'est écrit, ça arrivera sans salutations... Adieu... Ne te mets plus sur mon chemin : la prochaine fois, je ne te laisserai pas filer...";
			link.l1 = "Ravi d'avoir rencontré le légendaire capitaine.";
			link.l1.go = "GhostCapt_PrizeExit";
		break;

		case "GhostCapt_PrizeExit":
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "GhostShipCapInCabinDied", 5.0);
			LAi_LockFightMode(pchar, false);
			DoQuestCheckDelay("OpenTheDoors", 5.0);
			InterfaceStates.Buttons.Save.enable = true;
			DialogExit();
			AddDialogExitQuest("CanEnterToMap");
		break;

		case "GhostCapt_LastDialog":
			dialog.text = "Ah, " + GetSexPhrase("vieille connaissance","vieille connaissance") + " ! Je t'attendais : je savais que tu trouverais la réponse...";
			link.l1 = " Je " + GetSexPhrase("suis venu","suis venue") + " pour te libérer, toi et tes hommes, de la malédiction. Ton temps est écoulé : il est temps de prendre ta retraite, terreur des mers, capitaine fantכme Davy Jones.";
			link.l1.go = "GhostCapt_LastDialog1";
		break;

		case "GhostCapt_LastDialog1":
			dialog.text = "Je sais, je sais... Les têtus comme toi finissent toujours par obtenir ce qu'ils veulent. J'étais comme ça, moi aussi.. " +
				"Seulement, ne joue pas les sauveurs. J'y suis habitué, j'y prends même goמt parfois, et je ne suis pas pressé de quitter l'existence, même fantomatique. Alors ne crois pas que je vais me rendre si facilement !";
			link.l1 = "Je m'y attends. Et ton rafiot m'a vraiment plu.";
			link.l1.go = "GhostCapt_LastDialog2";
		break;

		case "GhostCapt_LastDialog2":
			dialog.text = "Je te crois volontiers. Seulement, le droit d'être le capitaine d'un vaisseau fantכme, il faut encore le mériter. Pour l'instant, c'est moi son capitaine, et je défendrai mon navire comme l'exigent les lois de la mer... Quoique... si je perds, je ne m'en affligerai pas...";
			link.l1 = "Prépare-toi au dernier combat, vieux tueur ! Que l'océan apaise ton âme pécheresse...";
			link.l1.go = "GhostCapt_LastDialog3";
		break;

		case "GhostCapt_LastDialog3":
			LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
	}
}
