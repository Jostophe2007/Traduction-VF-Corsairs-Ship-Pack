// Gregg: Jan Beausing - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Vous maniez bien la lame, capitaine. Continuez.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "L'Inquisition a encore envoyé ses gens. Troisième fois cette année. Ils ne lâchent pas l'affaire.";
			link.l1 = "L'Inquisition ? Que leur avez-vous fait ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Rien. J'ai une chose qu'ils veulent, voilà tout. Au début, je les repoussais moi-même, puis je m'en suis lassé et j'ai engagé le Secrétaire.";
			link.l1 = "Le Secrétaire est mort. Je l'ai trouvé dans une grotte.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Mort. ...(un silence)... Alors on a trouvé quelqu'un pour lui aussi. Bien. Merci d'avoir fait le ménage. Maintenant, dites-moi pourquoi vous êtes venu. Et ne mentez pas, je l'entends.";
			link.l1 = "Je suis venu pour vous, Beausing. Je travaille pour l'Inquisition, et je dois vous livrer à Santiago.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "...(il pose son verre)... Direct. Bien. Une question avant que je vous tue : vous pensiez vraiment entrer ici et m'emmener ?";
			link.l1 = "Voyons voir.";
			link.l1.go = "exit";
			PChar.RaulEsperanto.BeausingBattle = 1;
			AddDialogExitQuestFunction("RaulEsperantoBattleWithBeausing");
		break;

		case "5":
			dialog.text = "Argh.";
			link.l1 = "Assez, Jan. דa ne peut qu'empirer, maintenant.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Non.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "exit";
			PChar.RaulEsperanto.BeausingBattle = 2;
			AddDialogExitQuestFunction("RaulEsperantoBattleWithBeausing");
		break;

		case "7":
			dialog.text = "Vous croyez avoir gagné ? Vous n'avez rien gagné du tout.";
			link.l1 = "Encore ?";
			link.l1.go = "exit";
			PChar.RaulEsperanto.BeausingBattle = 3;
			AddDialogExitQuestFunction("RaulEsperantoBattleWithBeausing");
		break;

		case "8":
			dialog.text = "Vous ne m'aurez pas vivant. En garde.";
			link.l1 = "Vous n'arrêterez donc jamais ?";
			link.l1.go = "exit";
			PChar.RaulEsperanto.BeausingBattle = 4;
			AddDialogExitQuestFunction("RaulEsperantoBattleWithBeausing");
		break;

		case "9":
			dialog.text = "...(assis par terre, haletant)... Assez. Vous avez gagné. Vous m'entendez ? Gagné.";
			link.l1 = "Maintenant, nous sortons tranquillement et nous montons à bord.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "N'importe oם, sauf à Santiago.";
			link.l1 = "Vous n'avez pas le choix.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Si. וcoutez-moi une minute. Ce n'est pas moi qu'ils veulent. C'est un וvangile dont j'étais le gardien. Je vous le donnerai, mais ne m'emmenez pas là-bas.";
			link.l1 = "Mes ordres sont de vous livrer, vous, pas un livre.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Vos ordres disent une chose, mais ce qu'ils veulent, c'en est une autre. Livrez-moi, et ils commenceront à m'arracher l'emplacement du livre. Lentement. Alors que moi, je vous le dirai tout de suite, et pour rien.";
			link.l1 = "Très bien. Nous allons d'abord chercher le livre, puis Santiago. S'ils disent qu'ils n'ont pas besoin de vous, je vous ramène à Saint-Martin.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Marché conclu. Le livre est chez l'usurier de Willemstad.";
			link.l1 = "Alors, mettons les voiles.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoToVillemstadBank");
		break;

		case "14":
			dialog.text = "Le voici. Je viens de le récupérer chez l'usurier. ...(il le tient avec précaution)... Plus lourd que dans mon souvenir.";
			link.l1 = "Maintenant, Cuba. Vous restez à bord, je remets le livre.";
			link.l1.go = "15";
			TakeNItems(PChar, "RaulEsperanto_Evangelie", 1);
		break;

		case "15":
			dialog.text = "Je resterai. Vous savez, capitaine, je regrette presque de ne pas voir sa tête.";
			link.l1 = "Nous verrons.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoGetEvangelie");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
