#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bienvenue dans la Cité des navires abandonnés, capitaine " + pchar.name + ". Comment trouvez-vous la situation dans votre nouveau lieu de résidence ? Le temps vous plaît ?";
					link.l1 = "Je suis marin, j'aime tous les temps, du moment que je suis en mer. Attendez, comment me connaissez-vous ?";
					link.l1.go = "FT_1";
				}
				else
				{
					dialog.text = "Bienvenue dans la Cité des navires abandonnés, capitaine " + pchar.name + ".";
					link.l1 = "Vous me connaissez ?";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Puis-je vous aider en quelque chose, "+ GetSexPhrase("señor", "señorita") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(pchar, "questTemp.LSC.additional.balls"))
				{
					link.l8 = "וcoute, l'ami, j'ai besoin de faire transporter quelque chose jusqu'à la barque San Gabriel. Tu veux bien m'aider ?";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de venir avec moi.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FT_1":
			dialog.text = "Comment ne pas vous connaître, "+ GetSexPhrase("señor", "señorita") +". Je m'appelle " + GetFullName(npchar) + " : autrefois, nous nous sommes affrontés au combat.";
			link.l1 = "Nous nous sommes battus ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Le passé n'a pas d'importance ici, ni votre grade, ni votre nationalité. Je ne vous considère pas comme mon ennemi tant que nous sommes ici, et je ne vous le conseille pas non plus. Mon brick a sombré dans l'abîme de l'éternité, comme tous mes hommes, et j'ai commencé une nouvelle vie ici.";
			link.l1 = "Depuis combien de temps êtes-vous ici ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Six mois, ou... un an, peut-être.";
			link.l1 = "Avez-vous essayé de partir ?";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Ha, je n'accuserais pas de lâcheté ceux qui n'y pensent même pas. דa ne vaut pas la peine d'essayer : ce n'est pas du courage, c'est de la folie.";
			link.l1 = "Pourquoi ? Rien n'est impossible.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Tiens ? Vous semblez en savoir plus que moi sur cet endroit, hein ?";
			link.l1 = "Des rumeurs ont filtré jusqu'au continent. Si personne n'était sorti d'ici, d'oם viendraient ces rumeurs ?";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = ""+ GetSexPhrase("Mon ami", "Ma chère") +", croyez-moi, c'est une coïncidence. Et ne vous remplissez pas la tête de vains espoirs.";
			link.l1 = "Merci du conseil.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "señorita") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Les tempêtes sont-elles fréquentes ici ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Comment vous êtes-vous fait aux règles d'ici ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "C'est une impression, ou les gens autour sont pressés ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l4 = "Dites-moi, depuis combien de temps vivez-vous ici ?";
				link.l4.go = "ansewer_4";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_3":
			dialog.text = "Oui, souvent. On le ressent particulièrement quand on est constamment en mer, comme nous tous ici.";
			link.l1 = "Vous n'en avez pas assez ?";
			link.l1.go = "ansewer_3_1";
		break;
		case "ansewer_3_1":
			dialog.text = "Oם aller ? Nulle part, "+ GetSexPhrase("l'ami", "señorita") +" !";
			link.l1 = "Oui, c'est triste...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_1":
			dialog.text = "Impossible de ne pas les accepter. Moi aussi, comme beaucoup, j'ai essayé d'empêcher certaines choses, mais je ne suis pas allé jusqu'à l'absurde.";
			link.l1 = "Jusqu'à l'absurde ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Autrement dit, jusqu'à sa propre mort.";
			link.l1 = "Hum...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Ce n'est pas la première fois que j'entends cette question... Oui, haha. Il y avait ici un plaisantin, Bert. Il a mis dans la tête de plusieurs personnes que la vie s'écoulait plus vite sur cette île maudite...";
			link.l1 = "Et alors... ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Il plaisantait, en fait, mais ces imbéciles l'ont cru. Plus encore, ils se sont mis à répandre cette « théorie ». Si bien qu'on en est arrivé au point oם ceux qui y croient sont toujours pressés d'aller quelque part pour ne pas perdre de temps.";
			link.l1 = "Très intéressant.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Eh bien, deux ans, sans doute. Je ne m'en souviens plus exactement.";
			link.l1 = "Hill Brunner était-il déjà là quand vous êtes arrivé ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Oui, bien sמr. Hill Brunner était l'un des plus anciens citoyens. C'est dommage qu'on l'ait tué.";
			link.l1 = "Oui, c'est vraiment dommage.";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Ha ! Et pourquoi donc, je vous prie ?",
				"Tout est réglé.",
				"Je m'occupe de tout.",
                "Oh, vous êtes bien agaçant.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Alice Taylor m'a dit de vous parler...",
				"Parfait !",
                "Ah, oui.",
				"Ouais.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Compris. Bon, ça change tout, je lui dois bien ça. Et que faut-il transporter, d'oם et jusqu'oם ?";
			link.l1 = "De la flמte « Ceres Smithy », il faut livrer 100 boulets à la barque « San Gabriel ».";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Allons-y, pas de problème.";
			link.l1 = "Eh bien, merci, l'ami !";
			link.l1.go = "exit";
			AddCharacterGoods(pchar, GOOD_BALLS, 100);
			AddQuestRecord("ISS_MainLine", "50");
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "C'est vraiment possible ?!";
			link.l1 ="Bien sמr que c'est possible. J'attends une réponse.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "J'accepte. Que dois-je faire ?";
			link.l1 = "Allez sur le San Gabriel tout de suite, oם le Mécanicien organisera votre transfert sur mon navire.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "D'accord. Je serai sur le San Gabriel dans l'heure.";
			link.l1 = "Eh bien, bienvenue. Ne soyez pas en retard.";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
