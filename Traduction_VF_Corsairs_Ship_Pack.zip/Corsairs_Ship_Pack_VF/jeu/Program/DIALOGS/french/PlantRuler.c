
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int slaveCount, i, companion, slavePartCount;

	switch(Dialog.CurrentNode)
	{
		case "Meet":
			dialog.text = "Salutations. Je suis " + GetFullName(NPChar) + ", régisseur de la plantation de la Barbade. Veuillez vous présenter.";
			Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je suis " + GetFullName(PChar) + ", capitaine du navire '" + PChar.ship.name + "'.";
			link.l1.go = "Meet_2";
		break;

		case "Exit":
			NextDiag.CurrentNode = "Meet_2";
			DialogExit();
		break;

		case "Meet_2":
			if (!CheckAttribute(npchar, "met")) dialog.text = "Enchanté. Qu'est-ce qui vous amène ?";
			else dialog.text = "Qu'est-ce qui vous amène, capitaine ?";

			if (sti(npchar.SlavesLimit) > 0)
			{
				slaveCount = sti(PChar.Ship.Cargo.Goods.Slaves);

				for (i = 1; i < COMPANION_MAX; i++)
				{
					companion = GetCompanionIndex(PChar, i);
					if(companion != -1 && GetRemovable(&Characters[companion]))
						slaveCount += sti(Characters[companion].Ship.Cargo.Goods.Slaves);
				}

				if (slaveCount > 0)
				{
					NPchar.HeroSlaveCount = slaveCount;
					Link.l1 = "Je vous propose d'acheter... de la marchandise.";
					link.l1.go = "trade_good";
				}
			}
			Link.l2 = "Je passais juste, bonne journée.";
			link.l2.go = "exit";
			npchar.met = 1;
		break;

		case "trade_good":
			dialog.text = "De la marchandise ? Vous voulez dire des esclaves ?";
			Link.l1 = "Oui, exactement.";
			link.l1.go = "trade_good_2";
			Link.l2 = "J'ai changé d'avis. Bonne journée.";
			link.l2.go = "exit";
		break;

		case "trade_good_2":
			dialog.text = "Les fonds de la plantation me permettent d'acheter jusqu'à 1000 esclaves toutes les deux semaines à des particuliers. Combien voulez-vous en proposer ?";
			Link.l1 = (NPchar.HeroSlaveCount) + " esclaves.";
			link.l1.go = "trade_good_3";
			Link.l2 = "J'ai changé d'avis. Bonne journée.";
			link.l2.go = "exit";
		break;

		case "trade_good_3":
			slaveCount = func_min(sti(NPchar.HeroSlaveCount), sti(NPchar.SlavesLimit));
			dialog.text = "Pour l'instant, je peux acheter jusqu'à " + slaveCount + " esclaves à 215 l'unité. Au total : " + FindRussianMoneyString(slaveCount * 215) + ". Cela vous convient ?";
			Link.l1 = "Tout à fait.";
			link.l1.go = "trade_good_4";
			Link.l2 = "J'ai changé d'avis. Bonne journée.";
			link.l2.go = "exit";
		break;

		case "trade_good_4":
			slaveCount = func_min(sti(NPchar.HeroSlaveCount), sti(NPchar.SlavesLimit));

			AddMoneyToCharacter(PChar, 215 * slaveCount);
			npchar.SlavesLimit = sti(npchar.SlavesLimit) - slaveCount;

			slavePartCount = func_min(slaveCount, sti(PChar.Ship.Cargo.Goods.Slaves));
			PChar.Ship.Cargo.Goods.Slaves = sti(PChar.Ship.Cargo.Goods.Slaves) - slavePartCount;
			slaveCount -= slavePartCount;

			for (i = 1; (i < COMPANION_MAX) && (slaveCount > 0); i++)
			{
				companion = GetCompanionIndex(PChar, i);
				if(companion != -1 && GetRemovable(&Characters[companion]))
				{
					slavePartCount = func_min(slaveCount, sti(Characters[companion].Ship.Cargo.Goods.Slaves));
					Characters[companion].Ship.Cargo.Goods.Slaves = sti(Characters[companion].Ship.Cargo.Goods.Slaves) - slavePartCount;
					slaveCount -= slavePartCount;
				}
			}

			SetTimerFunction("RefreshSlavesLimit", 0, 0, 14);
			dialog.text = "Tenez, voici votre argent.";
			Link.l1 = "Merci.";
			link.l1.go = "exit";
		break;
	}
}
