void ProcessDialogEvent()
{
	ref NPChar, sld;
	ref arItem;
	aref Link, Diag;
	int i, iShipType, iShipGoods;
	int jewelType;
	string sItemName = "";
	string sItem;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);
	int iTemp = sti(npchar.EncQty);
	string sTemp = "Patrol" + locations[FindLocation(npchar.location)].index + "_";
	string sGroup = "PatrolGroup_" + locations[FindLocation(npchar.location)].index;
	string sTemp1, sTemp2;

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "exit_fight":
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, sGroup);
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "LandEnc_PatrolAfrer");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "exit_noFight":
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				sld.Dialog.CurrentNode = "GoodBye";
				sld.greeting = "soldier_common";
				LAi_SetWarriorType(sld);
				LAi_warrior_DialogEnable(sld, true);
				LAi_group_MoveCharacter(sld, sGroup);
			}
			LAi_group_SetCheck(sGroup, "LandEnc_PatrolAfrer");
			DialogExit();
		break;

		case "First Time":
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_type_actor_Reset(sld);
				LAi_RemoveCheckMinHP(sld);
			}
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
    			if (pchar.nation == npchar.nation)
				{
					dialog.text = RandPhraseSimple("Ah, on dirait que "+ GetSexPhrase("ce salaud a donné", "cette garce a donné") +" l'alarme à " + XI_ConvertString("Colony" + npchar.city + "Dat") + " ! Sus à "+ GetSexPhrase("lui", "elle") +" !!", "Hé, voyez-moi ça ! Voilà que " + NationNamePeople(sti(pchar.nation))+ " osent se brouiller avec " + NationNameAblative(sti(npchar.nation)) + " ! Attrapez cette canaille !!!");
				}
				else
				{
					dialog.text = RandPhraseSimple("Un agent ennemi rכde près de " + XI_ConvertString("Colony" + npchar.city + "Gen") + " ! Sus à "+ GetSexPhrase("lui", "elle") +" !!", "Voyez-moi ça : " + NationNamePeople(sti(pchar.nation))+ " qui se promènent jusqu'aux portes de " + XI_ConvertString("Colony" + npchar.city + "Dat") + " ! Qu'on l'arrête sur-le-champ !!!");
				}
				NPChar.bribe = 50*MOD_SKILL_ENEMY_RATE*3*sti(NPChar.EncQty)+makeint(50 * sti(PChar.rank))+makeint(50 * sti(NPChar.rank)*sti(NPChar.EncQty));
				if (sti(pchar.money) >= sti(NPChar.bribe))
				{
					link.l0 = "Et si on réglait ça à l'amiable ? Disons, "+FindRussianMoneyString(sti(NPChar.bribe))+" ?";
					link.l0.go = "bribe";
				}
				link.l2 = RandPhraseSimple("Essayez donc, nous sommes seuls ici...", "Héhé, personne ne viendra vous aider ici.");
				link.l2.go = "exit_fight";
				if (IsCharacterPerkOn(pchar, "Adventurer") || IsCharacterPerkOn(pchar, "Agent"))
				{
					link.l1 = RandPhraseSimple("Vous faites erreur, "+GetAddress_Form(NPChar)+" ! Je suis une personne respectueuse des lois.", "Pourquoi tant d'agressivité ? Je ne peux pas simplement me promener ?");
					link.l1.go = "CheckPeg";
				}
			}
			else
			{
				dialog.text = LinkRandPhrase("J'ai l'honneur de me présenter ! Je suis le chef de la patrouille de " + XI_ConvertString("Colony" + npchar.city + "Gen") + ", nous recherchons un forçat évadé.",
					"Bonjour, je suis le chef de cette patrouille. Nous recherchons un esclave évadé de " + XI_ConvertString("Colony" + npchar.city + "Gen") + ".",
					"Mes salutations, " + GetAddress_Form(NPChar) + ". Mon unité patrouille dans les environs de " + XI_ConvertString("Colony" + npchar.city + "Gen") + ".");
				Link.l1 = LinkRandPhrase("Très bien. Comment puis-je vous aider ?",
				"Fort bien. Puis-je vous aider, " + GetAddress_FormToNPC(NPChar) + " ?",
				"Parfait. Que puis-je faire pour vous personnellement ?");
				Link.l1.go = "Node_2";
			}
		break;
		
		case "bribe":
			AddMoneyToCharacter(pchar, -sti(NPChar.bribe));
			AddMoneyToCharacter(npchar, sti(NPChar.bribe));
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 10*sti(NPChar.EncQty));
			dialog.text = RandPhraseSimple("Ah, ah, ah, je vois... C'est bon, vous pouvez passer, " + GetAddress_Form(pchar) + ".", "Tout va bien, "+GetAddress_Form(NPChar)+", vous pouvez passer.");
			link.l1 = "Voilà !";
			link.l1.go = "exit_noFight";
		break;

		case "CheckPeg":
		switch (rand(1))
		{
			case 0:
				dialog.text = RandPhraseSimple("Ah, je vois... C'est bon, vous pouvez passer, " + GetAddress_Form(pchar) + ".", "Je suis un peu fatigué par la patrouille... C'est bon, "+GetAddress_Form(NPChar)+", excusez-moi.");
				link.l1 = "Voilà !";
				link.l1.go = "exit_noFight";
				if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
				{
					AddCharacterExpToSkill(pchar, SKILL_SNEAK, 80);
					pchar.questTemp.stels.landSolder = GetDataDay();
				}
				break;
			case 1:
				dialog.text = RandPhraseSimple("Ne me racontez pas d'histoires ! Rendez vos armes !", "Bon, c'est un espion, aucun doute... Rendez-vous immédiatement !");
				link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
				link.l1.go = "exit_fight";
				if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
				{
					AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
					pchar.questTemp.stels.landSolder = GetDataDay();
				}
				break;
		}
		break;

		case "Node_2":
			dialog.text = RandPhraseSimple("Avez-vous vu quelque chose de suspect dans les environs ?", "Avez-vous croisé quelqu'un de suspect, " + GetAddress_Form(NPChar) + " ?");
			link.l1 = RandPhraseSimple("Non, rien de tel.", "Non, officier, tout est calme.");
			link.l1.go = "Node_3";

			/* Nathaniel (09.03.2021): возможность спровоцировать драку с патрулём ------------- */
			link.l2 = "Oui, officier, j'ai une affaire très importante pour vous... Allez, défendez-vous, soldats !";
			link.l2.go = "exit_fight";
			/* --------------------------------------------------------------------------------- */
		break;

		case "Node_3":
			Diag.TempNode = "GoodBye";
			dialog.text = RandPhraseSimple("Eh bien, je n'ose pas vous retenir. Au revoir, " + GetAddress_Form(NPChar) + ".",
				"Je vois. Dans ce cas, au revoir.");
			Link.l1 = "Bonne chance à vous.";
			Link.l1.go = "exit_noFight";
		break;

		case "GoodBye":
			Diag.TempNode = "GoodBye";
			dialog.text = LinkRandPhrase("Ne nous détournez pas de notre devoir.",
				"Je vous prie de ne pas nous déranger !",
				"Oh, c'est encore vous... Passez votre chemin, ne nous dérangez pas.");
			Link.l1 = "Bien.";
			Link.l1.go = "Exit";
		break;

		// генератор "A reason to hurry"
		case "Reason_To_Fast_1":
			chrDisableReloadToLocation = false;
			if(Pchar.Location == Pchar.location.from_sea)
			{
				dialog.text = "Hum... Votre tête ne me dit rien. Qui êtes-vous ?";
				link.l1 = "C'est moi que vous attendez...";
				link.l1.go = "Reason_To_Fast_11";
				link.l2 = "Je me présente : capitaine " + GetFullName(pchar) + ". Je voudrais savoir pourquoi vous étiez si pressé de venir ici : vous avez failli oublier votre pantalon au bordel...";
				link.l2.go = "Reason_To_Fast_21";
				link.l3 = "Je me présente : capitaine " + GetFullName(pchar) + ". Je me promène par ici, je respire la brise marine...";
				link.l3.go = "Reason_To_Fast_31";
			}
			else
			{
				Diag.TempNode = "GoodBye";
				dialog.text = "Enfin, vous voilà. Je croyais ne jamais en voir le bout... Ce type est avec vous ?";
				link.l1 = "Quel type ?";
				link.l1.go = "Reason_To_Fast_Hunter";
			}
		break;

		case "Reason_To_Fast_Hunter":
			DialogExit();
			AddDialogExitQuest("ReasonToFast_MeetHunter");
		break;

		case "Reason_To_Fast_11":
			dialog.text = "Vous n'avez pas l'air d'être quelqu'un qui aurait la confiance de " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + ".";
			if(!CheckCharacterItem(pchar, "mapQuest"))
			{
				link.l1 = "D'accord, je le lui dirai.";
				link.l1.go = "Reason_To_Fast_12";
			}
			link.l2 = "Et qui est donc ce " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " ?";
			link.l2.go = "Reason_To_Fast_13";
		break;

		case "Reason_To_Fast_21":
			dialog.text = "La curiosité n'est certes pas un vilain défaut, mais elle abrège parfois sérieusement la vie...";
			link.l1 = "Allons, allons !";
			link.l1.go = "Reason_To_Fast_ExitFight";
			pchar.questTemp.ReasonToFast = "PatrolAfter";
		break;

		case "Reason_To_Fast_31":
			Diag.TempNode = "Reason_To_Fast_GoodBye";
			dialog.text = "La marée monte. Vous feriez mieux de quitter la baie : ici, l'eau monte jusqu'aux palmiers.";
			link.l1 = "Pas de souci, je nage bien.";
			link.l1.go = "Reason_To_Fast_GoodBye_0";
			pchar.questTemp.ReasonToFast = "MeetPatrolFail";
		break;

		case "Reason_To_Fast_12":
			jewelType = sti(pchar.questTemp.ReasonToFast.p4);
			pchar.questTemp.ReasonToFast.item = "jewelry" + jewelType;
			sItem = "jewelry" + jewelType;
			switch (jewelType)
			{
				case 1:
					sItemName = "saphirs";
				break;
				case 2:
					sItemName = "diamants";
				break;
				case 3:
					sItemName = "rubis";
				break;
				case 4:
					sItemName = "émeraudes";
				break;
			}
			pchar.questTemp.ReasonToFast.jewType = sItemName;
			dialog.text = "Bon, bon. Les 30 " + sItemName + " promis, vous les avez sur vous ?";
			link.l1 = GetName(NAMETYPE_MAIN , pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " a dit qu'il y avait trop peu de temps pour réunir autant de cailloux. Il m'a chargé de vous proposer de l'argent.";
			link.l1.go = "Reason_To_Fast_14";
			if (GetCharacterItemWithCabin(pchar, pchar.questTemp.ReasonToFast.item, true) >= 30)
			{
				link.l2 = "Tenez.";
				link.l2.go = "Reason_To_Fast_15";
			}
		break;

		case "Reason_To_Fast_13":
			dialog.text = "Héhé ! Vous le saurez dans l'autre monde !";
			link.l1 = "Quelle assurance...";
			link.l1.go = "Reason_To_Fast_ExitFight";
			pchar.questTemp.ReasonToFast = "PatrolAfter";
		break;

		case "Reason_To_Fast_14":
			dialog.text = "Bien, alors ce sera " + sti(pchar.questTemp.ReasonToFast.p5) + " pièces d'or, comme convenu.";
			link.l1 = "Vous ne demandez pas un peu trop ?";
			link.l1.go = "Reason_To_Fast_16";
			if(makeint(pchar.money) >= sti(pchar.questTemp.ReasonToFast.p5))
			{
				link.l2 = "Tenez.";
				link.l2.go = "Reason_To_Fast_17";
			}
			link.l3 = "Mais je n'ai pas cette somme sur moi !";
			link.l3.go = "Reason_To_Fast_18";
			AddQuestRecord("ReasonToFast", "9");
			AddQuestUserData("ReasonToFast", "sText", pchar.questTemp.ReasonToFast.jewType);
		break;

		case "Reason_To_Fast_15":
			TakeNItemsWithCabin(pchar, pchar.questTemp.ReasonToFast.item, -30, false);
			dialog.text = "Tout est conforme à notre accord. Tenez. Cette carte a été prise sur le pirate pendu au sujet duquel s'est renseigné "  + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + ".";
			link.l1 = "Marché conclu !";
			link.l1.go = "Reason_To_Fast_15_1";
		break;

		case "Reason_To_Fast_15_1":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);//fix
			Diag.TempNode = "Reason_To_Fast_GoodBye";
			DialogExit();
			AddQuestRecord("ReasonToFast", "10");
			AddQuestUserData("ReasonToFast", "sName", GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM));
			pchar.questTemp.ReasonToFast = "PatrolSuccess_2";
			GiveItem2Character(pchar, "mapQuest");
			arItem = ItemsFromID("mapQuest");
			ReasonToFast_GenerateTreasureMap(arItem);
			DeleteAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther");//можем говорить с губером
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Reason_To_Fast_16":
			dialog.text = "La somme avait été convenue d'avance avec " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_ABL) + " ... דa ne me plaît pas... Les gars, sus à "+ GetSexPhrase("lui", "elle") +" !";
			link.l1 = "Eh bien, essaie donc !";
			link.l1.go = "Reason_To_Fast_ExitFight";
			pchar.questTemp.ReasonToFast = "PatrolAfter";
		break;

		case "Reason_To_Fast_17":
			pchar.questTemp.ReasonToFast = "PatrolSuccess_1";
			AddMoneyToCharacter(pchar, -makeint(sti(pchar.questTemp.ReasonToFast.p5)));
			pchar.GenQuest.CannotWait = 1; // лочим интерфейс отдыха
			if(CheckAttribute(pchar, "questTemp.ReasonToFast.chain")) DeleteAttribute(pchar, "questTemp.ReasonToFast.chain");
			if(CheckAttribute(pchar, "questTemp.ReasonToFast.ShipName")) DeleteAttribute(pchar, "questTemp.ReasonToFast.ShipName");
			if(CheckAttribute(pchar, "questTemp.ReasonToFast.ShipTypeName")) DeleteAttribute(pchar, "questTemp.ReasonToFast.TypeName");
			switch (sti(pchar.questTemp.ReasonToFast.target))
			{
				case 0: // корабль с товаром
					sTemp1 = generateRandomNameToShip(sti(pchar.questTemp.ReasonToFast.GuardNation));
					iShipType = ReasonToFast_GetVictimShipType();
					iShipGoods = ReasonToFast_GetVictimShipGoods();
					dialog.text = "Parfait ! Venons-en à l'affaire. Nous avons arraisonné la prise : '" + GetStrSmallRegister(pchar.questTemp.ReasonToFast.ShipTypeName) +" '" + sTemp1 + "', avec une cargaison de " + GetGoodsNameAlt(iShipGoods) + ", tout l'équipage est déjà dans les casemates, et la « marchandise » est toujours à bord. L'équipage de convoyage a été recruté parmi les ivrognes du port : il y a peu de chances qu'il atteigne le port avant demain. Faites-en ce que bon vous semble.";
					link.l1 = "Bien. Je rapporterai tout cela tel quel à " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + ".";
					link.l1.go = "Reason_To_Fast_GoodBye_0";
					pchar.questTemp.ReasonToFast.chain = "A0";
					pchar.questTemp.ReasonToFast.ShipName = sTemp1;
					DeleteAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther");//можем говорить с губером
					AddQuestRecord("ReasonToFast", "11");
					AddQuestUserData("ReasonToFast", "sShipType", pchar.questTemp.ReasonToFast.ShipTypeName);
					AddQuestUserData("ReasonToFast", "sShipName", sTemp1);
					AddQuestUserData("ReasonToFast", "sGoodsName", GetGoodsNameAlt(iShipGoods));
					ReasonToFast_GenerateVictimShip(iShipType, iShipGoods);
				break;

				case 1: // сокровища губернатора
					switch(rand(3))
					{
						case 0:
							sTemp1 = "la dot de sa fille";
						break;
						case 1:
							sTemp1 = "les cadeaux destinés au vice-roi";
						break;
						case 2:
							sTemp1 = "les cadeaux pour son anniversaire";
						break;
						case 3:
							sTemp1 = "sa « retraite »";
						break;
					}
					switch(rand(3))
					{
						case 0:
							sTemp2 = "Friponne";
						break;
						case 1:
							sTemp2 = "Coquine";
						break;
						case 2:
							sTemp2 = "Espiègle";
						break;
						case 3:
							sTemp2 = "Polissonne";
						break;
					}
					pchar.questTemp.ReasonToFast.password = sTemp2;
					sTemp2 = generateRandomNameToShip(sti(pchar.questTemp.ReasonToFast.GuardNation));
					dialog.text = "Parfait ! Le gouverneur garde " + sTemp1 + " dans son boudoir. Un navire courrier doit venir en prendre livraison d'un jour à l'autre, mais vous arriverez à temps. Le valet de pied est « notre » homme. Mot de passe : '"+ pchar.questTemp.ReasonToFast.password +"', réponse : '"+ sTemp2 +"'.";
					link.l1 = "Bien. Je rapporterai tout cela tel quel à " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + ".";
					link.l1.go = "Reason_To_Fast_GoodBye_0";
					pchar.questTemp.ReasonToFast.chain = "A1";
					AddQuestRecord("ReasonToFast", "12");
					pchar.questTemp.ReasonToFast.ShipName = sTemp2;
					DeleteAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther");//можем говорить с губером

					pchar.quest.ReasonToFast_ClearLakey.win_condition.l1 = "Timer";
					pchar.quest.ReasonToFast_ClearLakey.win_condition.l1.date.day = GetAddingDataDay(0, 0, 2);
					pchar.quest.ReasonToFast_ClearLakey.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 2);
					pchar.quest.ReasonToFast_ClearLakey.win_condition.l1.date.year = GetAddingDataYear(0, 0, 2);
					pchar.quest.ReasonToFast_ClearLakey.function = "ReasonToFast_ClearLakey";
				break;
			}
		break;

		case "Reason_To_Fast_18":
			if(makeint(pchar.money) >= sti(pchar.questTemp.ReasonToFast.p5))
			{
				dialog.text = "Tu essaies de me rouler ?! Chien !";
				link.l1 = "Ferme-la !";
				link.l1.go = "Reason_To_Fast_ExitFight";
				pchar.questTemp.ReasonToFast = "PatrolAfter";
			}
			else
			{
				dialog.text = "Toi ! Tu as bu ! Mon ! Argent !... Argh !";
				link.l1 = "Bon sang !";
				link.l1.go = "Reason_To_Fast_ExitFight";
				pchar.questTemp.ReasonToFast = "PatrolAfter";
			}
		break;

		case "Reason_To_Fast_GoodBye_0":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);//fix
			LAi_SetPlayerType(pchar);
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				sld.Dialog.CurrentNode = "Reason_To_Fast_GoodBye";
				sld.greeting = "soldier_common";
				LAi_SetWarriorType(sld);
				LAi_warrior_DialogEnable(sld, true);
				LAi_group_MoveCharacter(sld, sGroup);
			}
			pchar.quest.RemovePatrolFromShore.win_condition.l1          = "ExitFromLocation";
			pchar.quest.RemovePatrolFromShore.win_condition.l1.location = pchar.location;
            pchar.quest.RemovePatrolFromShore.function    				= "ReasonToFast_DeletePatrolFromShore";
			DialogExit();
		break;

		case "Reason_To_Fast_GoodBye":
			Diag.TempNode = "Reason_To_Fast_GoodBye";
			dialog.text = "Vous feriez mieux de quitter la baie, la marée a déjà commencé...";
			link.l1 = "Oui, oui, je m'en vais.";
			link.l1.go = "Exit";
		break;

		case "Reason_To_Fast_ExitFight":
			pchar.questTemp.ReasonToFast.relation = GetNationRelation2MainCharacter(sti(pchar.questTemp.ReasonToFast.GuardNation));
			SetNationRelation2MainCharacter(sti(pchar.questTemp.ReasonToFast.GuardNation), RELATION_ENEMY);

			pchar.GenQuest.HunterScore2Pause = 1; //НЗГ не начисляются
			pchar.GenQuest.ReputationNotChange = 1; //репутацию не менять

			chrDisableReloadToLocation = true;
			LAi_SetPlayerType(pchar);
			LAi_LocationFightDisable(&locations[FindLocation(pchar.questTemp.ReasonToFast.PatrolLocation)], false);
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, sGroup);
			}
			if(pchar.questTemp.ReasonToFast == "PatrolAngry")
			{
				sld = CharacterFromID("ReasonToFast_Hunter");
				if(sld != -1)
				{
					LAi_SetWarriorType(sld);
					LAi_group_MoveCharacter(sld, sGroup);
				}
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "OpenTheDoors");
			LAi_group_SetCheck(sGroup, "ReasonToFast_PatrolDied");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Reason_To_Fast_AfterHunter1":
			dialog.text = "On avait dit que le messager viendrait seul !";
			link.l1 = "Il y a eu un contretemps. Le messager s'est perdu, vous voyez ? On m'a envoyé le remplacer.";
			link.l1.go = "Reason_To_Fast_11";
			link.l2 = "Et moi, je suis venu"+ GetSexPhrase(" seul,", "e seule,") +" mais pas pour ce que vous croyez.";
			link.l2.go = "Reason_To_Fast_AfterHunter2";
		break;

		case "Reason_To_Fast_AfterHunter2":
			dialog.text = "Alors vous m'avez retrouvé... Eh bien, pardonnez-moi.";
			link.l1 = "Argh...";
			link.l1.go = "Reason_To_Fast_ExitFight";
			pchar.questTemp.ReasonToFast = "PatrolAfterHunter";
		break;

		case "Reason_To_Fast_AfterHunter3":
			dialog.text = "Ah, ordure ! Et j'ai failli me faire prendre !.. Gardes ! Sus à "+ GetSexPhrase("lui", "elle") +"...";
			link.l1 = "Argh...";
			link.l1.go = "Reason_To_Fast_ExitFight";
			pchar.questTemp.ReasonToFast = "PatrolAngry";
		break;
		// генератор "A reason to hurry"
	}
}
