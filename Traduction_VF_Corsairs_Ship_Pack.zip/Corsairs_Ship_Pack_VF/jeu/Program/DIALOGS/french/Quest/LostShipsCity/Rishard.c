// Ришард Шамбон - контрабандист
#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (CheckAttribute(pchar, "GenQuest.CitizenConflict") && sti(pchar.GenQuest.CitizenConflict) > 3)
			{
				dialog.text = "Je ne veux pas te parler. Tu attaques des civils sans raison, tu les provoques à la bagarre. Va-t'en !";
				link.l1 = "Hum...";
				link.l1.go = "exit";
				break;
			}
			// --> кольцо
			if (GetNpcQuestPastDayParam(npchar, "quest_date") >= 1 && !CheckAttribute(npchar, "quest.ring"))
			{
				dialog.text = "Oh ! Te voilà, "+ GetSexPhrase("le gars", "la fille") +". Et moi qui m'apprêtais justement à partir à ta recherche. J'ai besoin de toi, "+ GetSexPhrase("mon vieux.", "ma belle.") +"";
				link.l1 = "Tu m'as l'air étrangement amical, aujourd'hui, Richard. Bon, je t'écoute.";
				link.l1.go = "ring";
				break;
			}
			// <-- кольцо
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Bon, qu'est-ce que tu veux ? א vrai dire, je ne suis pas d'humeur. D'ailleurs, j'ai oublié la dernière fois que je l'ai été.";
				link.l1 = "C'est si grave que ça, l'ami ?";
				link.l1.go = "meeting";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = "Ah, " + GetFullName(pchar)+" ! "+TimeGreeting()+" ! Tu voulais quelque chose ?";
				link.l1 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?", "Quoi de neuf sur l'île ces derniers temps ?", "Tu me racontes les derniers potins ?");
				link.l1.go = "rumours_LSC";
				link.l2 = "Je voudrais te poser quelques questions sur l'île.";
				link.l2.go = "int_quests"; //информационный блок
				link.l5 = "Je voulais juste savoir comment tu allais. א la prochaine !";
				link.l5.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "meeting": // первая встреча
			dialog.text = "Grave ? Non, ce n'est pas grave. Je suis juste un peu de mauvais poil. Alors, qu'est-ce que tu voulais ?";
			link.l1 = "Oh, juste faire connaissance. Je suis ici depuis peu, je me promène sur l'île et je parle avec les gens.";
			link.l1.go = "meeting_1";
		break;

		case "meeting_1":
			dialog.text = "Ah oui ? Bon, d'accord. Je suis Richard Chambon. Autrefois, je faisais commerce de toutes sortes de marchandises de valeur, y compris interdites, mais depuis dix ans, je ne fais que fouiller les entrailles des épaves, à la recherche de toutes sortes de babioles que j'échange contre de la nourriture et de l'or.";
			link.l1 = "Et moi, je suis " +GetFullName(pchar)+", capitaine de mon propre navire...";
			link.l1.go = "meeting_2";
		break;

		case "meeting_2":
			dialog.text = "Tu voulais sans doute dire « ancien capitaine », héhé ?";
			link.l1 = "Eh bien, oui... Ancien.";
			link.l1.go = "meeting_4";
		break;

		case "meeting_4":
			dialog.text = "Ah... J'y ai déjà pensé... Bon, "+ GetSexPhrase("l'ami", "ma petite") +", je préférerais un verre de rhum...";
			link.l1 = "Bonne chance. C'était agréable de bavarder. א la prochaine !";
			link.l1.go = "exit";
			link.l2 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?", "Quoi de neuf sur l'île ces derniers temps ?", "Tu me racontes les derniers potins ?");
			link.l2.go = "rumours_LSC";
			link.l3 = "Je voudrais te poser quelques questions sur l'île.";
			link.l3.go = "int_quests"; //информационный блок
			NextDiag.TempNode = "First time";
		break;

		// Кольцо
		case "ring":
			dialog.text = "Pourquoi, j'étais différent avant ? Allons, j'ai eu des jours sans, qui n'en a pas ! Dis-moi plutכt : il court des rumeurs sur l'île selon lesquelles tu manies les armes comme personne. C'est vrai ?";
			link.l1 = "Je ne sais pas qui dit quoi sur mes talents de combattant. Mais je sais par quel bout tenir une épée, si c'est ce que tu demandes.";
			link.l1.go = "ring_1";
			npchar.quest.ring = "true";
		break;

		case "ring_1":
			dialog.text = "Je vois. Les rumeurs ne mentent pas, à ce que je vois... וcoute, "+pchar.name+", tu te souviens que je t'ai parlé un jour de l'anneau extérieur ? Du fait qu'on peut y fouiller et trouver des choses de valeur ?";
			link.l1 = "Oui, vous n'avez tous que cet anneau extérieur à la bouche, ici... Et toujours la même chose.";
			link.l1.go = "ring_2";
		break;

		case "ring_2":
			dialog.text = "Et que dire d'autre à son sujet, haha ! Bon. Assez de préambules, j'en viens au fait. (baissant la voix) J'ai réussi à trouver un navire bien conservé près de l'anneau extérieur. Il se tient à l'écart des autres, au milieu des récifs, et bien droit, ce qui est très rare. Le navire est grand : une pinasse. Il est arrivé chez nous récemment, il y a deux mois ou un peu plus. Jusqu'ici, aucun des autres habitants ne l'a découvert, alors il y a moyen de faire un joli bénéfice en fouillant sa cale et ses cabines.";
			link.l1 = "Tant mieux pour toi. Mais quel rapport avec moi ? Ou tu veux m'inviter pour te tenir compagnie ?";
			link.l1.go = "ring_3";
		break;

		case "ring_3":
			dialog.text = "Exactement ! וcoute la suite. La proue de cette pinasse est fracassée. Ces maudits crabes sont entrés dans la cale par la brèche de la coque et y ont fait un véritable nid. Tant qu'ils sont à l'intérieur, impossible de monter à bord, car je ne vois pas comment grimper sur le pont depuis l'eau le long d'une coque lisse ; et je ne peux pas venir à bout des crabes par la brèche : je l'avoue, je ne me suis jamais distingué à l'escrime, et ces dernières années, je n'ai même plus touché une arme, je n'en avais pas besoin. C'est pourquoi je suis venu te voir.";
			link.l1 = "Donc, tu me proposes de tuer les crabes à l'intérieur de ce navire, c'est ça ?";
			link.l1.go = "ring_4";
		break;

		case "ring_4":
			dialog.text = "Eh bien, oui. On passe un accord : je te montre le chemin jusqu'au navire, et toi, tu élimines les crabes. Tout ce qu'on trouvera sur le navire sera pour nous deux. C'est juste : j'ai trouvé le navire, tu as ouvert le passage.";
			link.l1 = "Non, l'ami, ta proposition ne m'intéresse pas. Me battre dans la cale d'un navire à moitié coulé contre une meute de crabes pour des trophées douteux, très peu pour moi. Cherche "+ GetSexPhrase("un autre casse-cou", "quelqu'un d'autre") +" pour te tirer les marrons du feu.";
			link.l1.go = "ring_exit";
			link.l2 = "Intéressant... דa fait longtemps que je voulais visiter l'anneau extérieur. Marché conclu ! Je m'occupe des crabes.";
			link.l2.go = "ring_5";
		break;

		case "ring_exit":
			dialog.text = "Tu as tort... Les navires de l'anneau extérieur regorgent de toutes sortes de choses... Et en plus, personne n'est encore monté sur ce navire. Bon, c'est toi qui vois. Porte-toi bien...";
			link.l1 = "Salut, l'ami...";
			link.l1.go = "exit";
		break;

		case "ring_5":
			dialog.text = "Je suis content de ne pas m'être trompé sur ton compte, "+ GetSexPhrase("l'ami", "ma petite") +". J'ai le sentiment que nous allons trouver beaucoup de choses intéressantes là-bas...";
			link.l1 = "On verra. Combien y a-t-il de crabes dans la cale, tu le sais ?";
			link.l1.go = "ring_6";
		break;

		case "ring_6":
			dialog.text = "Il m'a semblé quatre, ou cinq... Bon, c'est à peu près ça.";
			link.l1 = "On s'en sortira. Quand partons-nous ?";
			link.l1.go = "ring_7";
		break;

		case "ring_7":
			dialog.text = "Demain, plutכt : toi et moi, nous devons d'abord nous préparer. Fais provision de potions médicinales, fouille dans les coffres ou passe à la boutique ; du rhum fera l'affaire : il y a du poison dans les mâchoires des crabes. Un peu de prudence ne fait pas de mal. Nous nous retrouverons à huit heures du matin sur le « pont incliné ». Tu sais oם c'est ?";
			link.l1 = "Non. Explique-moi.";
			link.l1.go = "ring_8";
		break;

		case "ring_8":
			dialog.text = "Il y a un morceau d'une vieille épave qui sort de l'eau derrière le San Augustine. Sa proue est passée sous l'eau, et sa poupe est relevée : c'est pour ça qu'on l'appelle le « pont incliné ». On ne peut y aller qu'à la nage. Le plus pratique est d'entrer dans l'eau depuis le San Augustine, sous le pont suspendu, et de contourner le navire par n'importe quel cכté. De là, nous nagerons jusqu'à l'anneau extérieur.";
			link.l1 = "D'accord. א demain !";
			link.l1.go = "ring_9";
		break;

		case "ring_repeat":
			dialog.text = "א huit heures, sur le « pont incliné »...";
			link.l1 = "Oui, oui, je m'en souviens...";
			link.l1.go = "exit";
			NextDiag.TempNode = "ring_repeat";
		break;

		case "ring_9":
			DialogExit();
			NextDiag.CurrentNode = "ring_repeat";
			pchar.quest.LSC_Ring_Start.win_condition.l1 = "Timer";
			pchar.quest.LSC_Ring_Start.win_condition.l1.date.hour  = 7.0;
			pchar.quest.LSC_Ring_Start.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
			pchar.quest.LSC_Ring_Start.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 1);
			pchar.quest.LSC_Ring_Start.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 1);
			pchar.quest.LSC_Ring_Start.function = "LSC_RingStart"; // готовы
			pchar.quest.LSC_Ring_Over.win_condition.l1 = "Timer";
			pchar.quest.LSC_Ring_Over.win_condition.l1.date.hour  = 10.0;
			pchar.quest.LSC_Ring_Over.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
			pchar.quest.LSC_Ring_Over.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 1);
			pchar.quest.LSC_Ring_Over.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 1);
			pchar.quest.LSC_Ring_Over.function = "LSC_RingOver"; // опоздание
			AddQuestRecord("LSC_Ring", "1");
		break;

		case "ring_10":
			dialog.text = "Ah, te voilà, "+ GetSexPhrase("l'ami", "ma petite") +". On va faire de la salade de crabe ?";
			link.l1 = "Bien sמr !";
			link.l1.go = "ring_11";
		break;

		case "ring_11":
			dialog.text = "Très bien. Maintenant, tourne la tête vers l'anneau extérieur et regarde : tu vois ces deux épaves qui sortent de l'eau ?";
			link.l1 = "Euh... Oui, je les vois.";
			link.l1.go = "ring_12";
		break;

		case "ring_12":
			dialog.text = "Maintenant, regarde l'anneau extérieur entre elles. Tu vois le galion de l'anneau, la proue en l'air ? Il regarde droit vers nous. Regarde bien.";
			link.l1 = "...";
			link.l1.go = "ring_look";
		break;

		case "ring_look":
			DialogExit();
			LAi_SetActorType(pchar);
			LAi_ActorTurnToLocator(pchar, "reload", "reload_ring");
			DoQuestCheckDelay("LSC_RingTalkLook", 6.0);
		break;

		case "ring_13":
			dialog.text = "";
			link.l1 = "Je crois que je le vois... Oui ! Le voilà !";
			link.l1.go = "ring_13a";
		break;

		case "ring_13a":
			dialog.text = "C'est là que nous allons. Nous nageons tout droit, sans tourner nulle part, en direction de ce galion. Dès que nous aurons atteint l'anneau, je te montrerai le chemin, il faudra passer de l'autre cכté. L'entrée de la cale de mon navire se fait par une brèche dans la proue. Je te le dis tout de suite : je n'y entre pas tant que tu n'auras pas nettoyé tous les crabes.";
			link.l1 = "Nous en avons déjà convenu hier, je m'en souviens. Tu montres le navire, je détruis les crabes. On y va ?";
			link.l1.go = "ring_14";
		break;

		case "ring_14":
			dialog.text = "Allons-y ! Passe devant, je te suis !";
			link.l1 = "...";
			link.l1.go = "ring_swim";
		break;

		case "ring_swim":
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorFollow(npchar, pchar, "", -1);
			LAi_SetImmortal(npchar, true);
			pchar.quest.LSC_Ring_enter.win_condition.l1 = "locator";
			pchar.quest.LSC_Ring_enter.win_condition.l1.location = "LostShipsCity_town";
			pchar.quest.LSC_Ring_enter.win_condition.l1.locator_group = "reload";
			pchar.quest.LSC_Ring_enter.win_condition.l1.locator = "reload_ring";
			pchar.quest.LSC_Ring_enter.function = "LSC_RingEnter";
			AddQuestRecord("LSC_Ring", "3");
		break;

		case "ring_15":
			dialog.text = "Héhé, tu as été formidable !";
			link.l1 = "Quelqu'un m'a parlé de « quatre ou cinq » crabes... Tu peux me rappeler qui c'était ?";
			link.l1.go = "ring_16";
		break;

		case "ring_16":
			dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +", je ne suis pas entré dans la cale pour les compter. J'ai regardé de l'extérieur, par la brèche, et j'en ai compté exactement autant. Je n'avais donc aucune intention de te mentir.";
			link.l1 = "Bon. Inspectons la cale, quoi...";
			link.l1.go = "ring_17";
		break;

		case "ring_17":
			dialog.text = "Bien sמr ! C'est pour ça qu'on est venus, non ?";
			link.l1 = "Exactement ! Ne perdons pas de temps...";
			link.l1.go = "ring_18";
		break;

		case "ring_18":
			DialogExit();
			NextDiag.CurrentNode = "ring_wait";
			LAi_SetWarriorType(npchar);
			LAi_warrior_DialogEnable(npchar, true);
			LAi_group_MoveCharacter(npchar, "TMP_FRIEND");
			DoQuestCheckDelay("LSC_RingDialog", 60.0); // 1 минуту на пошариться
			npchar.quest.diagnode = "ring_19";
			AddQuestRecord("LSC_Ring", "4");
		break;

		case "ring_wait":
			dialog.text = "Attends, "+ GetSexPhrase("l'ami", "ma petite") +", je n'ai pas encore regardé tout ce que je voulais. Cherche mieux, tu trouveras peut-être autre chose.";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "ring_wait";
		break;

		case "ring_19":
			dialog.text = "Rien de spécial pour l'instant. Dommage qu'il n'y ait pas de marchandises de grande valeur : il y a des vivres dans des tonneaux, du coprah dans des caisses. Quoiqu'il y avait une caisse de bouteilles de vin cher. Et toi ?";
			link.l1 = "Rien de spécial non plus. Quelques caisses présentaient de l'intérêt, le reste, comme tu l'as dit, du bœuf salé et du coprah.";
			link.l1.go = "ring_20";
		break;

		case "ring_20":
			dialog.text = "דa ne suffira pas... Montons, fouillons le pont et les cabines.";
			link.l1 = "Allons-y.";
			link.l1.go = "ring_21";
		break;

		case "ring_21":
			DialogExit();
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable("ExternalRingInside", "reload1", true);
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			pchar.quest.LSC_Ring_deck.win_condition.l1 = "ExitFromLocation";
			pchar.quest.LSC_Ring_deck.win_condition.l1.location = pchar.location;
			pchar.quest.LSC_Ring_deck.win_condition = "LSC_RingEnterDeck";
/* 			for (i=1; i<=3; i++)
			{
				sld = ItemsFromID("purse"+i);
				sld.shown = true;
				sld.startLocation = "ExternalRingDeck";
				sld.startLocator = "item"+i;
			} */
		break;

		case "ring_22":
			dialog.text = "Bon sang ! Regarde-moi ça ! Cette maudite racaille de crabes a grimpé sur le pont ! Comment ont-ils fait ?!";
			link.l1 = "Ne fais pas le froussard ! Reste ici et ne bouge pas, n'attire pas leur attention. Je vais régler leur compte à ces créatures...";
			link.l1.go = "ring_23";
		break;

		case "ring_23":
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocator(npchar, "reload", "reload1", "", -1);
		break;

		case "ring_24":
			dialog.text = "דa alors ! Ce n'est pas pour rien qu'on disait de toi que tu manies les armes à merveille. Si j'avais été seul, j'aurais sauté par-dessus bord depuis longtemps...";
			link.l1 = "Dis-moi, comment as-tu pu être contrebandier, autrefois, hein ? Ou tu as toujours fui tout le monde ?";
			link.l1.go = "ring_25";
		break;

		case "ring_25":
			dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +"Premièrement, j'étais alors plus jeune, plus fort et plus téméraire. Deuxièmement, je ne suis pas un mercenaire qui fait la guerre : je suis contrebandier, et nous avons toujours essayé d'éviter les accrochages avec les soldats. Troisièmement, j'étais plus porté sur les voiles et la barre que sur les épées et les pistolets. Et quatrièmement, après dix ans de vie tranquille sur l'île, je me suis complètement ramolli, alors ne me juge pas trop sévèrement. Jetons un œil sur le pont. On dirait qu'avant d'arriver ici, ce navire a livré une sérieuse bataille : regarde, des trous de boulets dans la coque et le pont, des barils de poudre près des canons...";
			link.l1 = "Tu as raison. Le navire a essuyé des tirs, c'est évident. Bon, cherchons quelque chose d'intéressant.";
			link.l1.go = "ring_26";
		break;

		case "ring_26":
			dialog.text = "Oui-oui. Et il faut chercher les accès à l'intérieur.";
			link.l1 = "C'est ça, ne perds pas de temps. Si tu tombes sur un crabe, appelle à l'aide.";
			link.l1.go = "ring_27";
		break;

		case "ring_27":
			DialogExit();
			NextDiag.CurrentNode = "ring_wait";
			LAi_SetWarriorType(npchar);
			LAi_warrior_DialogEnable(npchar, true);
			LAi_group_MoveCharacter(npchar, "TMP_FRIEND");
			DoQuestCheckDelay("LSC_RingDialog", 80.0); // 1.3 минуты на пошариться
			npchar.quest.diagnode = "ring_28";
			AddQuestRecord("LSC_Ring", "5");
		break;

		case "ring_28":
			dialog.text = "Et encore une fois, rien d'important... J'ai trouvé deux ou trois petites choses intéressantes, et c'est tout. Mais c'est normal : il n'y a généralement pas d'objets de valeur sur les ponts. Tout ce qu'il y a de mieux est dans les cabines. Là-bas, c'est l'entrée de la cabine du capitaine. Allons y fouiller...";
			link.l1 = "Regarde bien : le diable sait ce qui peut se cacher là-dedans. Je ferais peut-être mieux de passer "+ GetSexPhrase("en premier ", "en premier ") +" ?";
			link.l1.go = "ring_29";
		break;

		case "ring_29":
			dialog.text = "Allons-y, "+pchar.name+". Je ne vais pas me cacher derrière ton dos tout le temps. Et franchement, ce serait une honte...";
			link.l1 = "Eh bien, allons-y...";
			link.l1.go = "ring_30";
		break;

		case "ring_30":
			DialogExit();
			chrDisableReloadToLocation = true;
			LocatorReloadEnterDisable("ExternalRingDeck", "reload2", false);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload2", "ExternalRingCabin1", "reload", "reload1", "OpenTheDoors", -1);
			pchar.quest.LSC_Ring_cabin.win_condition.l1 = "location";
			pchar.quest.LSC_Ring_cabin.win_condition.l1.location = "ExternalRingCabin1";
			pchar.quest.LSC_Ring_cabin.win_condition = "LSC_RingEnterCabin";
			sld = ItemsFromID("RingCapBook"); // кладём журнал 'Санта-Люсии'
			sld.shown = true;
			sld.startLocation = "ExternalRingCabin1";
			sld.startLocator = "item1";
		break;

		case "ring_31":
			dialog.text = "Je crois que j'ai eu de la chance : ni crabes ni autre saleté. Et maintenant, mettons toute cette cabine sens dessus dessous ; je le jure sur mon honneur, je commence déjà à m'énerver : à part deux douzaines de doublons et toutes sortes de babioles sans valeur, je n'ai encore rien trouvé !";
			link.l1 = "Ne commence pas. Tu l'as bien dit : tous les objets de valeur sont gardés dans la cabine du capitaine. Cherchons bien !";
			link.l1.go = "ring_32";
		break;

		case "ring_32":
			DialogExit();
			NextDiag.CurrentNode = "ring_wait";
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocator(npchar, "goto", "goto2", "LSC_RingSetToBarman", -1);
			DoQuestCheckDelay("LSC_RingDialog", 30.0); // 30 сек на пошариться
			npchar.quest.diagnode = "ring_33";
		break;

		case "ring_33":
			dialog.text = "Haha ! Je m'en doutais ! Je connais les habitudes de ces marchands : aménager des cachettes et y planquer la caisse du navire ! Le capitaine de cette pinasse était un sacré malin, mais on ne me la fait pas ! Regarde ce que j'ai réussi à dénicher ! Tout seul, tu n'aurais jamais trouvé cette cache !";
			link.l1 = "Allez, montre-moi ça !";
			link.l1.go = "ring_34";
		break;

		case "ring_34":
			dialog.text = "Quarante mille piastres, deux coffres de doublons, un sac d'émeraudes et tout un tas de bijoux ! Le propriétaire était riche... Bon, au moins, ça paiera nos efforts, même si j'espérais davantage. On partage fraternellement, moitié-moitié, comme convenu.";
			link.l1 = "Excellent, Richard. Au moins, on a gagné quelque chose !";
			link.l1.go = "ring_35";
		break;

		case "ring_35":
			TakeNItems(pchar, "jewelry4", 25);
			TakeNItems(pchar, "chest", 1);
			TakeNItems(pchar, "icollection", 1);
			AddMoneyToCharacter(pchar, 20000);
			Log_Info("Vous avez reçu le coffre");
			Log_Info("Vous avez reçu 25 émeraudes");
			Log_Info("Vous avez reçu une collection de bijoux");
			PlaySound("interface\important_item.wav");
			dialog.text = "Bon, ce que chacun de nous a trouvé dans la cale et sur le pont, on le garde pour soi. D'accord ? Il y avait quelque chose d'utile dans les coffres et les placards ?";
			link.l1 = "Quelques babioles indiennes, des amulettes, des papiers et d'autres petites choses.";
			link.l1.go = "ring_36";
		break;

		case "ring_36":
			dialog.text = "Garde-les pour toi. Après tout, c'est toi qui as fait le travail le plus dangereux.";
			if (CheckAttribute(pchar, "questTemp.LSC.Ring.ReadCapBook")) // прочёл журнал
			{
				link.l1 = "D'accord. Mais j'ai trouvé autre chose, qui est dans tes cordes, chercheur de cachettes. Il y avait un journal de bord sur la table. L'histoire qu'il raconte est bien triste... mais maintenant, elle nous concerne d'une certaine façon : quelque part dans la cale, il y a toute une caisse d'or cachée ! Lis toi-même !";
				link.l1.go = "ring_41";
			}
			else
			{
				if (CheckCharacterItem(pchar, "RingCapBook")) // взял журнал
				{
					link.l1 = "D'accord. Mais j'ai trouvé autre chose : le journal de bord du capitaine de ce navire.";
					link.l1.go = "ring_38";
				}
				else
				{
					link.l1 = "D'accord, cet arrangement me va, héhé. Bon, il est temps de rentrer ?";
					link.l1.go = "ring_37";
				}
			}
		break;

		case "ring_37":
			dialog.text = "Oui. Ne parle de ce navire à personne : que ce soit notre secret. Bien sמr, personne n'a besoin de coprah ici, mais les vivres nous seront utiles. Pas besoin de les acheter à l'amiral.";
			link.l1 = "D'accord, faisons comme ça. J'espère que les autres ne trouveront pas ce navire de sitכt. Allons-y !";
			link.l1.go = "ring_cabin_exit";
		break;

		case "ring_38":
			dialog.text = "Et sa dernière page, tu l'as "+ GetSexPhrase("lue", "lue") +" ?";
			link.l1 = "Pas encore...";
			link.l1.go = "ring_39";
		break;

		case "ring_39":
			dialog.text = "Alors, lisons-le ! Il contient peut-être des informations importantes. Et puis, c'est intéressant de savoir comment ce navire a fini ici. Lis-le !";
			link.l1 = "Hum. D'accord, lisons-le tout de suite...";
			link.l1.go = "ring_40";
		break;

		case "ring_40":
			DialogExit();
			NextDiag.CurrentNode = "book_wait";
			LAi_SetWarriorType(npchar);
			LAi_warrior_DialogEnable(npchar, true);
			LAi_group_MoveCharacter(npchar, "TMP_FRIEND");
		break;

		case "book_wait":
			dialog.text = ""+ GetSexPhrase("Tu l'as lu", "Tu l'as lu") +" ? Qu'est-ce qu'il y a d'écrit ?";
			if (CheckAttribute(pchar, "questTemp.LSC.Ring.ReadCapBook")) // прочёл журнал
			{
				link.l1 = "Voilà ce qu'il dit... L'histoire est bien triste... Mais maintenant, elle nous concerne d'une certaine façon. Bref, c'est dans tes cordes, chercheur de cachettes : quelque part dans la cale, il y a toute une caisse d'or cachée ! Lis toi-même !";
				link.l1.go = "ring_41";
			}
			else
			{
				link.l1 = "Attends. Je le lis tout de suite et je te raconte...";
				link.l1.go = "exit";
				NextDiag.TempNode = "book_wait";
			}
		break;

		case "ring_41":
			dialog.text = "Qu'est-ce que tu fais ?! "+pchar.name+", moi, euh... je ne lis pas très bien. Raconte-moi plutכt en détail ce qu'il y a d'écrit, hein ?";
			link.l1 = "En bref : cette pinasse traversait la mer des Caraïbes depuis le sud du Main vers la Nouvelle-Espagne. Le capitaine avait épousé une princesse indienne des tribus du bas Orénoque, et elle lui avait montré l'endroit oם son peuple faisait des sacrifices aux dieux...";
			link.l1.go = "ring_42";
		break;

		case "ring_42":
			dialog.text = "";
			link.l1 = "Les offrandes se faisaient sous forme de pépites d'or. Notre brave capitaine a bien sמr pillé cette réserve d'or et, avec le second et le quartier-maître, il l'a transportée en cachette de l'équipage dans la cale du navire, l'a mise dans l'une des caisses et l'a recouverte de coprah...";
			link.l1.go = "ring_43";
		break;

		case "ring_43":
			dialog.text = "";
			link.l1 = "Mais apparemment, le pillage du lieu sacré des Indiens n'est pas passé inaperçu : le navire a été pris dans un calme plat, l'eau douce a commencé à manquer, une épidémie de fièvre s'est déclarée à bord, des pirates ont attaqué. Les marins ont tout mis sur le dos de l'Indienne, la femme du capitaine, et ont exigé qu'on la jette par-dessus bord. Le capitaine a bien sמr refusé, et l'équipage s'est mutiné...";
			link.l1.go = "ring_44";
		break;

		case "ring_44":
			dialog.text = "";
			link.l1 = "Le capitaine a perdu ce combat. Les dernières lignes : il s'est enfermé dans sa cabine avec l'Indienne, en ripostant, et les marins enragés ont enfoncé la porte. Une tempête approchait à l'horizon... Apparemment, c'est elle qui a amené la pinasse ici. On devine comment la tragédie s'est terminée : la jeune femme a été abattue, et le capitaine, bien sמr, a été tué par les mutins.";
			link.l1.go = "ring_45";
		break;

		case "ring_45":
			dialog.text = "Hum. C'est vraiment triste. Mais tu ne plaisantes pas ? Il y a vraiment toute une caisse d'or cachée dans la cale ? Je n'en crois pas mes oreilles ! Mais laquelle ? Descendons dans la cale ! Je vais fouiller chaque ballot, chaque tonneau !";
			link.l1 = "Allons-y. J'ai hâte de commencer à chercher, moi aussi.";
			link.l1.go = "ring_seek_gold";
		break;

		case "ring_cabin_exit":
			DialogExit();
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable("ExternalRingInside", "reload1", false); // открываем выход
			LocatorReloadEnterDisable("LostShipsCity_town", "reload_ring", false); // открываем вход // patch-2
			DoQuestReloadToLocation("ExternalRingDeck", "reload", "reload2", "LSC_RingFinalStage");
			sld = ItemsFromID("RingCapBook");
			sld.shown = false; // убираем журнал
			AddQuestRecord("LSC_Ring", "6");
		break;

		case "ring_seek_gold":
			DialogExit();
			chrDisableReloadToLocation = false;
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			// ставим прерывание на локатор
			pchar.quest.LSC_Ring_gold.win_condition.l1 = "locator";
			pchar.quest.LSC_Ring_gold.win_condition.l1.location = "ExternalRingInside";
			pchar.quest.LSC_Ring_gold.win_condition.l1.locator_group = "quest";
			pchar.quest.LSC_Ring_gold.win_condition.l1.locator = "gold";
			pchar.quest.LSC_Ring_gold.win_condition = "LSC_RingFindGold";
			// подменяем состав бокса
			pchar.GenQuestBox.ExternalRingInside = true;
			pchar.GenQuestBox.ExternalRingInside.box1.items.jewelry5 = 2522;
			AddQuestRecord("LSC_Ring", "7");
		break;

		case "ring_46":
			dialog.text = "Haha ! On l'a trouvée ! Elle est vraiment là ! Regarde-moi ce tas énorme ! Toute une caisse ! Il doit y avoir au moins cinq mille lingots ici ! Je n'ai jamais vu autant d'or !";
			link.l1 = "Félicitations, compagnon. On dirait que notre entreprise a été un succès phénoménal... Qu'allons-nous faire de l'or ?";
			link.l1.go = "ring_47";
		break;

		case "ring_47":
			dialog.text = "Comment ça ? On le partage en deux !";
			link.l1 = "דa, c'est compréhensible. Oם vas-tu garder le tien ? Tu vas le laisser ici, ou tu vas le traîner quelque part ?";
			link.l1.go = "ring_48";
		break;

		case "ring_48":
			dialog.text = "Ha ! Bien sמr, je vais tout cacher dans mes planques, que personne ne trouvera jamais. Je sais cacher les choses ! Mettons tout de suite la moitié de l'or dans un tonneau : ce sera ma part. Et avant le lever du soleil, je l'emporterai de ce navire, et toi, fais de ta part ce que bon te semble. Mais tu ferais mieux de la cacher aussi, sinon elle risque de disparaître d'un coup, et c'est moi que tu accuseras. Mais je te le dis tout de suite : je suis honnête à ma façon, et je n'oserai même pas toucher à ta part. Par contre, les autres qui viendront ici... ils pourraient la trouver par hasard.";
			link.l1 = "D'accord. Je déciderai quoi faire de mon or. Mettons ta part dans le tonneau...";
			link.l1.go = "ring_49";
		break;

		case "ring_49":
			DialogExit();
			SetLaunchFrameFormParam("Deux heures ont passé..."+ NewStr() +"L'or est partagé !", "", 0, 5);//табличка
			WaitDate("", 0, 0, 0, 2, 10);
			LaunchFrameForm();
			RecalculateJumpTable();
			sld = characterFromId("LSC_Rishard");
			sld.quest.diagnode = "ring_50";
			DoQuestCheckDelay("LSC_RingDialog", 5.0);
		break;

		case "ring_50":
			dialog.text = "Voilà... Merci, "+pchar.name+". Sans toi, ça n'aurait pas marché. Maintenant, on peut songer à construire une tartane pour rejoindre l'archipel... Oh, bon. Je n'y penserai pas aujourd'hui, j'ai encore beaucoup de travail : mettre mon or en lieu sמr. Salut, "+ GetSexPhrase("l'ami", "ma petite") +", je te souhaite de bien faire fructifier ta part !";
			link.l1 = "Salut, Richard. C'était une belle journée. א bientכt !";
			link.l1.go = "ring_51";
		break;

		case "ring_51":
			DialogExit();
			LocatorReloadEnterDisable("ExternalRingInside", "reload1", false); // открываем выход
			LocatorReloadEnterDisable("LostShipsCity_town", "reload_ring", false); // открываем вход
			DoQuestCheckDelay("LSC_RingFinalStage", 0.5);
			DeleteAttribute(pchar, "questTemp.LSC.Ring.ReadCapBook");
			AddQuestRecord("LSC_Ring", "8");
		break;
//--------------------------------------- блок вопросов и ответов ---------------------------------------------
		case "int_quests":
			dialog.text = "Des questions ? Oh, bon, si tu y tiens tant que ça...";
			if (!CheckAttribute(npchar, "quest.answer_1"))
			{
				link.l1 = "Comment êtes-vous arrivée ici ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(npchar, "quest.answer_2"))
			{
				link.l2 = "Tu aimerais partir d'ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(npchar, "quest.answer_3"))
			{
				link.l3 = "Tu n'as jamais eu envie d'entrer dans l'un des clans ? Chez les Narvals, par exemple ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(npchar, "quest.answer_4"))
			{
				link.l4 = "Donc, on peut trouver beaucoup de choses intéressantes sur les navires de l'anneau extérieur ?";
				link.l4.go = "ansewer_4";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;

		case "ansewer_1":
			dialog.text = "Il y a dix ans, mes camarades et moi faisions sans cesse la traversée entre l'île et Cuba sur une tartane bien équipée. Nous gardions secrète la position de l'île : nous apportions ici des carcasses de bœuf et échangions la viande fraîche contre des marchandises tirées des cales des navires morts et contre de l'or. C'était le bon temps ! Ici, on manquait toujours de nourriture, surtout des biscuits et du bœuf salé, alors on payait la viande juteuse avec des épices qui valaient une fortune en Europe ! En un seul voyage, je gagnais de quoi m'offrir toutes les putains de Tortuga pour l'éternité, mais tout a une fin, et notre vie de cocagne a pris fin. Le temps a changé dans ces parages : les tempêtes sont devenues plus fréquentes et plus violentes, et il était de plus en plus dangereux de gagner l'île. Certains de mes collègues se sont retirés de l'affaire, mais une dizaine de braves et moi avons continué nos voyages, jusqu'à ce que nous finissions fracassés sur les récifs à deux milles de l'île. Comment je suis arrivé ici à la nage à travers une mer démontée, je ne le comprends toujours pas moi-même. C'est ainsi que je suis devenu l'un de ceux avec qui je commerçais autrefois.";
			link.l1 = "Histoire intéressante...";
			link.l1.go = "int_quests";
			npchar.quest.answer_1 = "true";
		break;

		case "ansewer_2":
			dialog.text = "Ha ! Je partirai d'ici, bon sang ! Mais pas maintenant. Qu'est-ce que j'irais faire à Cuba ? Je n'ai plus d'amis là-bas, et pas beaucoup d'argent non plus. Dès que je trouverai sur l'anneau extérieur un navire avec une riche cargaison, ou un tas de doublons d'or, je me mettrai aussitכt à construire une embarcation.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			npchar.quest.answer_2 = "true";
			SaveCurrentNpcQuestDateParam(npchar, "quest_date");
		break;

		case "ansewer_3":
			dialog.text = "Pour quoi faire ? Pour monter la garde au garde-à-vous comme un idiot, un jour sur trois, à chasser tous ceux qui auraient l'idée de s'approcher du San Gabriel ? Et puis, ils ne brמlent pas d'envie d'accueillir des étrangers. Ce sont des insulaires de naissance, voyons... Et les Noirs ne valent pas mieux qu'eux. Non, je préfère rester mon propre maître.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			npchar.quest.answer_3 = "true";
		break;

		case "ansewer_4":
			dialog.text = "Bien sמr ! C'est de ça que vivent tous les insulaires. Tu sais quand c'est jour de fête, sur l'île ? Quand un nouveau navire arrive chez nous. Mais de toute façon, il reste encore beaucoup de rafiots inexplorés et inconnus sur l'anneau extérieur, dans les cales desquels on peut trouver des marchandises de valeur et de l'or ; la difficulté, c'est qu'il est presque impossible de se déplacer sur l'anneau extérieur : tout y est en vrac, et si tu te perds ou que tu glisses et que tu tombes mal, tu peux atterrir dans un endroit d'oם tu ne sortiras pas tout seul. Et là, tu es fichu. Beaucoup de gens ont déjà disparu comme ça.";
			link.l1 = "Hum... intéressant.";
			link.l1.go = "int_quests";
			npchar.quest.answer_4 = "true";
		break;
// <-- блок вопросов и ответов

//----------------------------------------- специальные реакции -----------------------------------------------
		//обнаружение ГГ в сундуках
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Qu'est-ce que vous faites là, hein ? Vous êtes un voleur !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Vous avez décidé de fouiller les coffres ?! Vous ne vous en tirerez pas comme ça !");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;

		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous avez décidé de fouiller les coffres ?! Vous ne vous en tirerez pas comme ça !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//замечание по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, pourquoi courez-vous partout comme "+ GetSexPhrase("d'Artagnan", "une forcenée") +" en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jolie fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma fille") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des filles") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
// <-- специальные реакции

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
