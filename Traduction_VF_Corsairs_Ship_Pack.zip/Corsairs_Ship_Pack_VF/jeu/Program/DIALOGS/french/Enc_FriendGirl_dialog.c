void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i, iRank;
	string attr;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = LinkRandPhrase("Mon Dieu, quelle chance de vous avoir rencontré !",
				"Enfin, quelqu'un est apparu ici !!",
				"Mon Dieu, je suis si contente de vous voir !");
			Link.l1 = LinkRandPhrase("Qu'y a-t-il, ma belle ?",
				"Quel est le problème, ma jolie ?",
				"Ne vous inquiétez pas tant, c'est mauvais pour la santé. Dites-moi vite, que s'est-il passé ?");
			Link.l1.go = "Step_1";
		break;
		case "Step_1":
			dialog.text = LinkRandPhrase("Mon amie est si intrépide, elle est descendue dans un puits abandonné !",
				"Mon amie est descendue dans un puits abandonné, et ça fait des heures qu'elle n'est pas remontée !",
				"Mon amie a disparu dans un puits abandonné !");
			Link.l1 = "Que diable allait-elle faire là-dedans ?!";
			Link.l1.go = "Step_2";
		break;
		case "Step_2":
			dialog.text = "Oh, elle n'a peur de rien ! Elle a entendu dire quelque part qu'il y a là-dessous un souterrain oם l'on peut trouver de l'or, alors elle est descendue. Mais moi, je ne suis pas si bête, je n'y mets pas les pieds...";
			Link.l1 = "Et vous avez raison, vous n'avez rien à faire là-bas.";
			Link.l1.go = "Step_3";
		break;
		case "Step_3":
			dialog.text = "Que dois-je faire maintenant ? Je vous en prie, pour l'amour de Dieu, aidez-la !";
			Link.l1 = "Bon, je vais m'en occuper. Et vous, rentrez chez vous, vous n'avez rien à faire ici toute seule.";
			Link.l1.go = "Step_agree";
			Link.l2 = "Ce sont vos problèmes, ça m'est égal. Au revoir...";
			Link.l2.go = "Step_disAgree";
		break;

		case "Step_agree":
			pchar.quest.Enc_FriendGirl_after.over = "yes";
			if (rand(1))
			{ //бандюганы
				LAi_LocationDisableMonGenTimer(pchar.GenQuest.EncGirl.locationId, 1); //монстров не генерить 1 день
				LAi_LocationDisableOffGenTimer(pchar.GenQuest.EncGirl.locationId, 1); //офицеров не пускать 1 день
				LocatorReloadEnterDisable(pchar.GenQuest.EncGirl.locationId, "reload2", true);
				pchar.GenQuest.OpenTheRopeExit = pchar.GenQuest.EncGirl.locationId; //флаг для открытия релоада
				object models;
				for (i = 0; i < 10; i++)
				{
					attr = "s" + i;
					models.(attr) = "pirate_" + (i + 1);
				}
				RandomShuffle(&models);
				for (i = 0; i < 3; i++)
				{
					iRank = sti(pchar.rank) - rand(5) + rand(5);
					if (iRank < 1) iRank = 1;
					attr = "s" + i;
					sld = GetCharacter(NPC_GenerateCharacter("CaveGandMan" + i, models.(attr), "man", "man", iRank, PIRATE, 1, true));
					SetFantomParamFromRank(sld, iRank, true);
					sld.SaveItemsForDead = true;
					sld.DontClearDead = true;
					sld.money = iRank*200+1000+rand(500);
					LAi_CharacterDisableDialog(sld);
					LAi_SetWarriorType(sld);
					LAi_warrior_SetStay(sld, true);
					//LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
					ChangeCharacterAddressGroup(sld, pchar.GenQuest.EncGirl.locationId, "quest", "quest" + i);
					LAi_group_MoveCharacter(sld, "CaveBandit");// лесник изменил группу чтобы ядом таино травить можно было
					LAi_group_FightGroups("CaveBandit", LAI_GROUP_PLAYER, true);
					i++;
				}
				pchar.quest.Enc_FriendGirl_afterGang.win_condition.l1 = "ExitFromLocation";
				pchar.quest.Enc_FriendGirl_afterGang.win_condition.l1.location = pchar.location;
				pchar.quest.Enc_FriendGirl_afterGang.win_condition = "Enc_FriendGirl_afterGang";
			}
			else
			{ //и правда девка
				sld = GetCharacter(NPC_GenerateCharacter("UndergroundGirl", "girl_"+(rand(7)+1), "woman", "towngirl", 5, PIRATE, 1, false));
				sld.dialog.filename = "Enc_FriendGirl_dialog.c";
				int iTemp = rand(1);
				sld.dialog.currentnode = "Underground1";//+ iTemp; //здесь рендом поведения девки: 0-помогите, 1-сама крутая
				sld.greeting = "Enc_RapersGirl_" + (iTemp+1); //соотв. озвучка
				LAi_SetStayType(sld);
				LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
				ChangeCharacterAddressGroup(sld, pchar.GenQuest.EncGirl.locationId, "monsters", "monster"+(rand(9)+1));
			}
			LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Step_disAgree":
			ChangeCharacterReputation(pchar, -3);
			LAi_SetCitizenTypeNoGroup(npchar);
			//#20200315-01
            npchar.chr_ai.type.checkFight = 999999.0;
			pchar.quest.Enc_FriendGirl_after.over = "yes";
			NextDiag.CurrentNode = "FackYou";
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;
		//#20200315-01
		case "CitizenNotBlade ":
		    npchar.chr_ai.type.checkFight = 999999.0;
            NextDiag.TempNode = "FackYou";
            dialog.text = "Je ne veux pas parler à "+ GetSexPhrase("un idiot aussi dépourvu de cœur", "une fille aussi dépourvue de cœur") +". Fichez le camp !";
			Link.l1 = "Hé, garce...";
			Link.l1.go = "exit";
		break;
		case "FackYou":
            NextDiag.TempNode = "FackYou";
            dialog.text = "Je ne veux pas parler à "+ GetSexPhrase("un idiot aussi dépourvu de cœur", "une fille aussi dépourvue de cœur") +". Fichez le camp !";
			Link.l1 = "Hé, garce...";
			Link.l1.go = "exit";
		break;

		case "Underground0": //девка реально заблудилась
            dialog.text = "Mon Dieu, comme je suis contente de vous voir !!";
			Link.l1 = "Qu'y a-t-il, ma belle ?";
			Link.l1.go = "Underground0_1";
		break;
		case "Underground0_1":
            dialog.text = "Je me suis perdue ici ! Mon Dieu, j'ai eu si peur !!!";
			Link.l1 = "Bon, tout va bien maintenant. Suivez-moi, je vais vous faire sortir. Dès que vous serez à la surface, rentrez vite chez vous, et j'espère ne plus vous revoir !";
			Link.l1.go = "Underground0_2";
		break;
		case "Underground0_2":
            dialog.text = "Comme vous voudrez, " + GetAddress_Form(NPChar) + ".";
			Link.l1 = "Bien.";
			Link.l1.go = "exit";
			npchar.LifeDay = 0;
			LAi_SetActorType(npchar);
			LAi_ActorFollow(npchar, pchar, "", -1);
			ChangeCharacterReputation(pchar, 4);
			DeleteAttribute(pchar, "GenQuest.EncGirl");
		break;

		case "Underground1": //крутая мочалка
            dialog.text = "דa alors, quelqu'un d'autre s'intéresse à ce souterrain !";
			Link.l1 = "Ma belle, qu'est-ce que vous faites ici ?";
			Link.l1.go = "Underground1_1";
		break;
		case "Underground1_1":
            dialog.text = "דa ne vous regarde pas !";
			Link.l1 = "דa alors, une réponse à un million de piastres...";
			Link.l1.go = "Underground1_2";
		break;
		case "Underground1_2":
            dialog.text = "א deux millions... Vous feriez mieux de passer votre chemin, vous ne m'intéressez pas.";
			Link.l1 = "Hé, vous ne m'intéressez pas non plus, à vrai dire, mais votre amie a semé la panique là-haut...";
			Link.l1.go = "Underground1_3";
		break;
		case "Underground1_3":
            dialog.text = "Quelle idiote ! Elle est prête à faire dans ses jupons de peur, et elle croit que je suis pareille.";
			Link.l1 = "Ouais, vous n'êtes manifestement pas pareille. Le diable en jupons !";
			Link.l1.go = "Underground1_4";
		break;
		case "Underground1_4":
            dialog.text = "Doucement avec les épithètes ! Bref, fichez le camp, et qu'on n'en parle plus.";
			Link.l1 = "Eh bien, puisque vous n'avez pas besoin de mon aide...";
			Link.l1.go = "Underground1_5";
		break;
		case "Underground1_5":
            dialog.text = "Je n'en ai pas besoin !";
			Link.l1 = "Alors, adieu et portez-vous bien.";
			Link.l1.go = "exit";
			NextDiag.TempNode = "Underground1_again";
			DeleteAttribute(pchar, "GenQuest.EncGirl");
		break;
		case "Underground1_again":
            dialog.text = "Encore vous ? Fichez le camp, vous me fatiguez...";
			Link.l1 = "Hum...";
			Link.l1.go = "exit";
			NextDiag.TempNode = "Underground1_again";
		break;

	}
}
