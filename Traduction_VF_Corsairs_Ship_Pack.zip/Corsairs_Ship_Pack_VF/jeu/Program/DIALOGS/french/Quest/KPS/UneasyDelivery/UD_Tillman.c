// Gregg: Richard Tillman - quest "Goods for Richard Tillman" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\uneasydelivery.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (CheckAttribute(PChar, "UneasyDelivery.Cancel"))
			{
				dialog.text = "Que voulez-vous encore ?! Nous nous sommes déjà tout dit !";
				link.l1 = "Ne vous énervez pas comme ça, marchand. Je m'en vais.";
				link.l1.go = "exit";
				break;
			}
			if (sti(PChar.UneasyDelivery) >= 3)
			{
				dialog.text = "Ah, c'est vous, capitaine " + GetFullName(PChar) + " ? Oם en sont vos affaires concernant ma commission ?";
				link.l1 = "Je l'ai accomplie depuis longtemps, " + NPChar.lastname + ".";
				link.l1.go = "exit";
				break;
			}
			if (sti(PChar.UneasyDelivery) > 1)
			{
				dialog.text = "Ah, c'est vous, capitaine " + GetFullName(PChar) + " ? Oם en sont vos affaires concernant ma commission ?";
				link.l1 = "Je m'y emploie activement.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = GetFullName(NPChar) + ", à votre service. א qui ai-je l'honneur ?";
			link.l1 = "Capitaine " + GetFullName(PChar) + ". Je vous ai apporté un lot de cacao.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Eh bien, enfin ! Pourquoi avez-vous mis si longtemps à atteindre la Barbade ? דa fait des semaines que j'attends. Expliquez-vous !";
			link.l1 = "Ce cacao devait être livré par le capitaine Tommi Fatman, mais il se trouve que je me suis emparé de son navire et de votre cargaison. J'ai appris qu'elle devait vous être apportée et j'ai mis le cap sur la Barbade sans tarder. Il n'y a eu aucun retard de ma part ; pourquoi Fatman a traîné, je l'ignore.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Peu importe qui m'a apporté la cargaison, ce qui compte, c'est qu'elle est arrivée terriblement en retard. J'espérais la vendre à bon prix, mais la demande a baissé maintenant, et pour ce cacao, je n'obtiendrai strictement rien.";
			link.l1 = "Attendez deux mois, la demande remontera, et alors vous le vendrez.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Ne me donnez pas de leçons, capitaine " + PChar.lastname + " ! Je sais parfaitement ce que je dois faire et comment. Maintenant, aux affaires : je suis prêt à vous payer 750 piastres pour la livraison.";
			link.l1 = "750 piastres ? C'est tout au plus la moitié de la somme sur laquelle je comptais.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Vous n'avez pas respecté les conditions, alors le paiement est à l'avenant. Oui, ce n'est pas votre faute, c'est celle du capitaine qui a traîné. Mais vous avez repris son engagement de livrer, n'est-ce pas ? Oui. La cargaison aurait dמ arriver il y a des semaines, n'est-ce pas ? Oui. Eh bien, tirez-en les conclusions.";
			link.l1 = "Que le diable vous emporte, donnez-moi votre argent.";
			link.l1.go = "6";
		break;

		case "6":
			AddMoneyToCharacter(PChar, 750);
			RemoveCharacterGoodsSelf(PChar, GOOD_CHOCOLATE, 50);
			dialog.text = "Je suis content que nous soyons tombés d'accord. Mes gars déchargent déjà votre navire.";
			link.l1 = "...(entre ses dents)... Un plaisir de faire affaire avec vous, " + NPChar.name + ". Adieu.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Attendez, capitaine " + PChar.lastname + ", j'ai une commission pour vous, et si vous l'accomplissez à temps, vous gagnerez bien.";
			link.l1 = "Quelle commission ?";
			link.l1.go = "8";
		break;

		// Gregg: the tavern entry - without the prologue the player has neither the cocoa
		// nor the Fatman story, so the conversation begins straight at the commission
		case "30":
			dialog.text = GetFullName(NPChar) + ", à votre service. C'est le tavernier qui vous envoie, je suppose ? J'ai en effet une affaire pour un capitaine qui a un navire solide.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Livrer un petit lot de porcelaine à mon associé Jacque Prenol, à Port-au-Prince. Faites-le, et il vous paiera 7000 piastres. Alors, vous acceptez ? Je vous conseille de ne pas refuser.";
			link.l1 = "J'accepte.";
			link.l1.go = "9";
			link.l2 = "Non, je refuse.";
			link.l2.go = "11";
		break;

		case "9":
			dialog.text = "Parfait. Seulement, pour l'amour de Dieu, faites attention à la porcelaine. Un geste maladroit, et elle risque de se briser. Et cette fois, il n'y a pas de délai.";
			link.l1 = "Très bien, je comprends.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Vous remettrez cette lettre à Prenol. C'est tout. Bon vent, capitaine " + PChar.lastname + " !";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryAgree");
		break;

		// Gregg: in Damned Destiny the refusal branch was commented out and never used.
		// Restored: the player is entitled to decline, and the quest already handles it.
		case "11":
			// Gregg: register the handler BEFORE DialogExit - calling a function with
			// a parameter after the dialog closes fails with "Invalid call"
			AddDialogExitQuestFunction("UneasyDeliveryCancel");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		// Gregg: player caught stealing. The short local variant of the block is used:
		// the Damned Destiny branches with a pay-off relied on GetStealMoneyLeaderShip /
		// GetStealMoneyLuck, which do not exist in CSP. Model - Graveyard_Watcher_dialog.c.
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur ! La garde, arrêtez le voleur !!!", "דa alors ! Je détourne les yeux un instant, et vous voilà la tête la première dans le coffre ! Au voleur !!!", "La garde ! Au vol !!! Arrêtez le voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
