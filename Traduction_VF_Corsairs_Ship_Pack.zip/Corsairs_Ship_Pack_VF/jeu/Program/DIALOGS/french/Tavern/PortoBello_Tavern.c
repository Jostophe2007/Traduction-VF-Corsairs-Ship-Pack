// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.RomanticQuest == "SeekInPortoBello")
			{
				link.l1 = "Dites, vous ne sauriez pas si quelqu'un attend ici l'arrivée du brick « Enthousiaste » ?";
				link.l1.go = "Romantic_1";
			}

			if (pchar.questTemp.Slavetrader == "FindRatPortobello")
            {
                link.l1 = "Dites, avez-vous vu un corsaire nommé François Gontier ? Il était dans votre ville récemment.";
                link.l1.go = "Portobello_rat_1";
            }

			if (CheckAttribute(pchar, "questTemp.mushket2x2_stid") && !CheckCharacterItem(pchar, "mushket2x2"))
			{
				link.l1 = "וcoute, Rolando, sais-tu oם je peux trouver Albert Sievert, capitaine du brick « Arrow » ?";
				link.l1.go = "Mushket_stid";
			}

			if (CheckAttribute(pchar, "questTemp.PDM_ONV_PortoBello"))	//Квест "Witch Hunt"
            {
                link.l1 = "Le nom de Maria Carle vous dit-il quelque chose ?";
                link.l1.go = "PDM_ONV_PB_1";
            }
		break;

		case "PDM_ONV_PB_1":	//Квест "Witch Hunt"
			dialog.text = "Ce nom ne me dit rien. Mais vous avez de la chance : cet homme, à la table, a prononcé ce nom plus d'une fois en avalant son rhum avec une rage folle.";
			link.l1 = "Vous m'avez bien aidé. Merci !";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_PortoBello");
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld = CharacterFromID("PDM_ONV_Viktor_Martos");
				sld.quest.questflag.model = "questionmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
		break;

		case "Portobello_rat_1":
			dialog.text = NPCStringReactionRepeat("Non, je ne sais pas. Il n'est pas venu à la taverne, et je ne l'ai pas vu en ville.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Gontier.", "וcoutez, reculez et ne me barrez pas la route ! Vous avez perdu la boule ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Eh bien... Ce ne sera pas facile.", "Oui, c'est vrai...", "Oui, déjà "+ GetSexPhrase("posé la question", "posé la question") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			break;

		case "Mushket_stid":
			dialog.text = "Eh bien !.. Ha ha ha ! Pourquoi as-tu besoin de mon meilleur ami, le célèbre brigand Alberto Sievert ?!";
			link.l1 = "Il le faut... J'ai affaire à lui.";
			link.l1.go = "Mushket_stid_1";
			break;

		case "Mushket_stid_1":
			dialog.text = "Vraiment ?! Le dernier qui avait une « affaire » avec lui a été dévoré par les crabes depuis longtemps. Il ne traite avec personne : un psychopathe solitaire, un avare malheureux. Seuls les contrebandiers le supportent, parce qu'il leur livre régulièrement de la marchandise. Il n'entre pas dans les ports : dans chacun d'eux, un unijambiste l'attend. Même les pirates le traquent... C'est Jackman qui t'a envoyé à ses trousses, par hasard ?";
			link.l1 = "Non... Il a un petit objet qui ne lui appartient pas, je veux le lui racheter...";
			link.l1.go = "Mushket_stid_2";
		break;

		case "Mushket_stid_2":
			dialog.text = "Ha ha ! Sievert ne possède même pas sa propre peau : Jackman a juré de la lui arracher dès qu'il l'attraperait. Mais non, l'« Arrow » lui appartient légalement : il l'a fait construire par Alexus avec son propre argent, d'après ses propres plans. Dis donc, tu n'aurais pas des vues sur son bateau, hein ? Et moi qui me demande quelle « affaire » tu peux bien avoir avec lui ! Mais n'oublie pas : Sievert peut très bien t'envoyer par le fond avant que tu aies mis ta chaloupe à l'eau. C'est sa façon de faire : il tire d'abord, il parle ensuite.";
			link.l1 = "Je n'ai pas besoin de son brick ! Tu peux juste me dire oם le trouver ?";
			link.l1.go = "Mushket_stid_3";
		break;

		case "Mushket_stid_3":
			dialog.text = "C'est un pirate solitaire, il se cache dans les criques, se faufile d'île en île et attaque par surprise, il n'est donc pas facile à trouver... Mais je ne serais pas le Renard catalan si je ne savais pas oם il est allé ! Alors prépare ta bourse, "+ GetSexPhrase("l'ami", "ma petite") +" !";
			link.l1 = "Parfait ! Et combien veux-tu pour cette information ?";
			link.l1.go = "Mushket_stid_4";
		break;

		case "Mushket_stid_4":
			dialog.text = "Cent mille, l'ami ! Cent mille, tout de suite.";
			if(makeint(Pchar.money) >= 100000)
			{
				link.l1 = "Combien ?? Tu es fou de demander une somme pareille pour deux mots ?!";
				link.l1.go = "Mushket_stid_nopay";
				link.l2 = "Pas de problème, Rolando. Tiens tes piastres.";
				link.l2.go = "Mushket_stid_paymoney";
			}
			link.l3 = "וcoute, je n'ai pas assez d'argent !";
			link.l3.go = "Mushket_stid_nomoney";
		break;

		case "Mushket_stid_nopay":
			dialog.text = "Ne me prends pas pour un nigaud : son brick vaut bien plus cher. Et ton histoire d'« objet », raconte-la à une oie dans l'arrière-cour d'une taverne : seul un gamin du chantier naval de Panama te croirait... Si tu réussis à t'emparer du brick, tu me remercieras encore. Et si tu échoues, les morts n'ont pas besoin d'argent, ha ha ha...";
			link.l1 = "D'accord, que le diable t'emporte. Tiens.";
			link.l1.go = "Mushket_stid_paymoney";
			link.l2 = "Assez de jacasseries. Je peux m'en passer, de ton or. Je le trouverai moi-même.";
			link.l2.go = "Mushket_stid_nomoney";
		break;

		case "Mushket_stid_nomoney":
			dialog.text = "Eh bien, visiblement, l'« Arrow » n'est pas ton destin. J'attendrai que quelqu'un de plus sérieux s'intéresse à mon ancien ami. Et inutile d'attendre que tu t'enrichisses : il est ici aujourd'hui et ailleurs demain... Alors si tu le veux, tu le trouveras en gardant les yeux ouverts. Mais moi, je ne t'aiderai pas.";
			link.l1 = "Eh bien, au revoir, Rolando. Ne t'inquiète pas, je t'apporterai ton argent...";
			link.l1.go = "exit";
			AddQuestRecord("SeekDoubleMushket", "5");
		break;

		case "Mushket_stid_paymoney":
			AddMoneyToCharacter(Pchar, -100000);
			SetMushketCapitainInWorld();
			dialog.text = "Oh, me voilà avec "+ GetSexPhrase("un ami généreux", "une amie généreuse") +" ! J'en venais même à me demander si je n'avais pas vendu à trop bas prix ! Bon, allez, que ne ferait-on pas pour une amitié désintéressée... וcoute bien : il est parti récemment pour une baie appelée Mosquitos. Il n'y restera pas longtemps : il déchargera et repartira, alors dépêche-toi et file plus vite que le vent, hé hé... Sinon, il faudra le chercher par toi-même. Je suis content de t'aider, en signe d'amitié, mais il ne me confie pas ses routes.";
			link.l1 = "Merci, le Renard ! Je pars immédiatement.";
			link.l1.go = "exit";
			AddQuestRecord("SeekDoubleMushket", "4");
			//AddQuestUserData("SeekDoubleMushket", "sShore", XI_ConvertString(pchar.questTemp.Mushket.Shore));
			DeleteAttribute(pchar, "questTemp.mushket2x2_stid");
		break;

		case "Romantic_1":
            dialog.text = "Non, personne ne m'a rien demandé.";
            link.l1 = "Compris... Dis-moi, quelqu'un te loue-t-il une chambre ?";
			link.l1.go = "Romantic_2";
		break;
		case "Romantic_2":
            dialog.text = "Non, " + GetAddress_Form(pchar) + ", elle est vide.";
            link.l1 = "Je vois... Eh bien, merci.";
			link.l1.go = "exit";
			pchar.RomanticQuest = "ToRositaInBeliz";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

void SetMushketCapitainInWorld()
{
	//создаём кэпов
	int Rank = sti(pchar.rank) + 15;
	if (Rank > 30) Rank = 30;
	if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) ref sld = GetCharacter(NPC_GenerateCharacter("MushketCap", "officer_17", "man", "man_fast", Rank, PIRATE, -1, true));
	else sld = GetCharacter(NPC_GenerateCharacter("MushketCap", "officer_17", "man", "man", Rank, PIRATE, -1, true));
	sld.name = "Albert";
	sld.lastname = "Sievert";
 	SetCaptanModelByEncType(sld, "pirate");
	FantomMakeCoolestSailor(sld, SHIP_VALCIRIA, "Arrow", CANNON_TYPE_CANNON_LBS20, 70, 70, 70);
	int iRank = sti(PChar.rank) + MOD_SKILL_ENEMY_RATE*3;
	FantomMakeCoolFighter(sld, iRank, 70, 70, "blade34", "pistol2", 50);
	sld.Ship.Mode = "pirate";
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	sld.WatchFort = true; //видеть форты
	if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
	/* SetCharacterPerk(sld, "FastReload");
	SetCharacterPerk(sld, "HullDamageUp");
	SetCharacterPerk(sld, "SailsDamageUp");
	SetCharacterPerk(sld, "CrewDamageUp");
	SetCharacterPerk(sld, "CriticalShoot");
	SetCharacterPerk(sld, "LongRangeShoot");
	SetCharacterPerk(sld, "CannonProfessional");
	SetCharacterPerk(sld, "ShipDefenseProfessional");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "StormProfessional");
	SetCharacterPerk(sld, "SwordplayProfessional");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "CriticalHit");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "Tireless");
	SetCharacterPerk(sld, "HardHitter");
	SetCharacterPerk(sld, "GunProfessional"); */ // LEO: Убрал нахер перебафы
	SetCharacterPerk(sld, "MusketsShoot");
	//в морскую группу кэпа
	string sGroup = "MushketCapShip";
	Group_FindOrCreateGroup(sGroup);
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	sld.quest = "InMap"; //личный флаг искомого кэпа
	sld.city = "SantaCatalina"; //определим колонию, из бухты которой с мушкетом выйдет
	sld.cityShore = GetIslandRandomShoreId(GetArealByCityName(sld.city));
	sld.quest.targetCity = "PortoBello"; //определим колонию, в бухту которой он придёт
	sld.quest.targetShore = "Shore47";
	pchar.questTemp.Mushket.Shore = sld.quest.targetShore;
	//==> на карту
	sld.mapEnc.type = "trade";
	//выбор типа кораблика на карте
	sld.mapEnc.worldMapShip = "quest_ship";
	sld.mapEnc.Name = "Brick 'Arrow'";
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sld.quest.targetCity), GetArealByCityName(sld.city)) + 1; //дней доехать даём с запасом
	Map_CreateTrader(sld.cityShore, sld.quest.targetShore, sld.id, daysQty);

	Log_TestInfo("Cap with a musket came out of: " + sld.cityShore + " and headed to: " + sld.quest.targetShore);
	//заносим Id кэпа в базу нпс-кэпов
	sTemp = sld.id;
	NullCharacter.capitainBase.(sTemp).quest = "mushket"; //идентификатор квеста
	NullCharacter.capitainBase.(sTemp).questGiver = "none"; //запомним Id квестодателя для затирки в случае чего
	NullCharacter.capitainBase.(sTemp).Tilte1 = "SeekDoubleMushket"; //заголовок квестбука
	NullCharacter.capitainBase.(sTemp).Tilte2 = "SeekDoubleMushket"; //имя квеста в квестбуке
	NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
    NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
    NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
    NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
}
