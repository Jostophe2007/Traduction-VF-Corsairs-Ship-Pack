
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//Условия – закончен морской файт у Мартиники, 'Морж' цел. У гг пиратский флаг. Иначе файт с флинтом. Весь квест запрет на смену флага.
		//Пляж Ламантен. ГГ, Флинт, Сильвер, Бонс. Бродят матросы, несколько штук.

		case "BS_KS_1":	//Флинт
			dialog.text = "Inattendu, mais prévisible.";
			link.l1 = "Quoi ? Ah, tu parles des Anglais ? Ils n'ont quand même pas décidé de reprendre la colonie ?";
			link.l1.go = "BS_KS_2";
		break;

		case "BS_KS_2":
            dialog.text = "J'ai une idée de la provenance de cette patrouille, mais ce ne sont que des suppositions, il faut les vérifier. Je ne pense pas que ce soit une tentative de reprendre l'île : ils s'y prendraient tout autrement. Ligne de bataille, parlementaires, siège. Je sais très bien comment se bat la flotte de Sa Majesté Charles II. Non. C'est autre chose. Monsieur Silver, vous partez avec le capitaine "+GetFullName(pchar)+" pour Fort-de-France. Votre mission : récupérer la seconde partie du code. א tout prix. C'est compris ?";
            link.l1 = "";
			link.l1.go = "BS_KS_3_1";
		break;

		case "BS_KS_3_1":
			sld = CharacterFromID("BS_Silver");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			sld.dialog.currentnode = "BS_KS_3";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;

		case "BS_KS_3":	//Сильвер
            dialog.text = "Compris. Pourquoi tant de sévérité, capitaine ? Je croyais que nous étions déjà amis.";
            link.l1 = "";
			link.l1.go = "BS_KS_4_1";
		break;

		case "BS_KS_4_1":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.currentnode = "BS_KS_4";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_KS_4":	//Флинт
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorTypeNoGroup(npchar);
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorTurnToCharacter(npchar, sld);
			LAi_ActorTurnToCharacter(sld, npchar);
            dialog.text = "(Il fixe Silver sans ciller)";
            link.l1 = "";
			link.l1.go = "BS_KS_5_1";
		break;

		case "BS_KS_5_1":
			sld = CharacterFromID("BS_Silver");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.currentnode = "BS_KS_5";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;

		case "BS_KS_5":	//Сильвер
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorTypeNoGroup(npchar);
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorTurnToCharacter(npchar, sld);
			LAi_ActorTurnToCharacter(sld, npchar);
            dialog.text = "Hum... Oui, oui, nous allons le faire, capitaine.";
            link.l1 = "";
			link.l1.go = "BS_KS_6_1";
		break;

		case "BS_KS_6_1":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.currentnode = "BS_KS_6";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_KS_6":
			SetQuestHeader("BSCourtlyPassions");
			AddQuestRecord("BSCourtlyPassions", "1");

            dialog.text = "Dès que vous aurez percé le code, je vous attendrai chez Mlle Guthrie. Bonne chance.";
            link.l1 = "Merci, capitaine ! Silver, suis-moi !";
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorFollowEverywhere(sld, "", -1);
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "BSCPFlint_talk");
			pchar.quest.BSCourtlyPassions_begin.over = "yes";
			DeleteAttribute(pchar, "LockMapReload");
			DeleteAttribute(npchar, "curtown");
			pchar.BSCPSailor_talk = true;
			pchar.BSCPSilver_talk = true;
			link.l1.go = "BS_KS_6_exit";
		break;

		case "BS_KS_6_exit":
			DialogExit();
			RemoveCharacterCompanion(PChar, npchar);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", LAi_FindNearestFreeLocator2Pchar("reload"), "Pirates_store", "", "", "", -1);
			//Запускаем Матроса.
			if(pchar.location == "LeFransua_town" || pchar.location == "FortFrance_town" ||  pchar.location == "Shore38" ||   pchar.location == "Shore39")
			{
				BSCourtlyPassions_sailor();
			}
			else
			{
				SetFunctionExitFromLocationCondition("BSCourtlyPassions_sailor_begin_again", pchar.location, true);
			}

		break;

		//Ставим Сильвера во временные оффы. Лучше сразу в абордаги, если возможно.

		case "BS_KS_7":	//Обращаемся к матросу
            dialog.text = "Des ordres ?";
			string order1, order2, order3;
			if (pchar.nation != FRANCE)
			{
				order1 = "Retourne à bord et hisse le pavillon français.";
				Flag_Change(FRANCE);
			}
			else order1 = "";
			if (pchar.location != "Shore39")
			{
				order2 = "Conduis le navire à la baie du Marin.";
				pchar.location.from_sea = "Shore39";
			}
			else order2 = "";
			if (order1 == "" && order2 == "") order3 = "Retourne au navire et reste sur tes gardes. Si une patrouille se présente, dis-leur que le gouvernail est bloqué et que tu ne peux pas rejoindre le chantier naval.";
			else order3 = "Si une patrouille se présente, dis-leur que le gouvernail est bloqué et que tu ne peux pas rejoindre le chantier naval.";
            link.l1 = order1+order2+order3;
			link.l1.go = "BS_KS_7_1";
		break;

		case "BS_KS_7_1":	//Обращаемся к матросу
			AddQuestRecord("BSCourtlyPassions", "2");
			dialog.text = "א vos ordres, capitaine !";
            link.l1 = "Tu es un bon marin, Sandro, et tu es avec moi depuis plus longtemps que tous les autres. Continue comme ça, et un jour, on te nommera peut-être officier.";
			link.l1.go = "BS_KS_7_2";
		break;

		case "BS_KS_7_2":	//Обращаемся к матросу
            dialog.text = "Ce n'est pas pour moi, capitaine. Trop de responsabilités, et d'obligations. Je suis un simple matelot, et je ne veux pas que ça change.";
            link.l1 = "Comme tu voudras. Bon, file, exécute les ordres.";
			link.l1.go = "BS_KS_7_2_exit";
		break;

		case "BS_KS_7_2_exit":	//Обращаемся к матросу
			DialogExit();
			DeleteAttribute(pchar, "BSCPSailor_talk");
			LocatorReloadEnterDisable(pchar.location.from_sea, "boat", true);
			chrDisableReloadToLocation = false;
			LAi_SetActorTypeNoGroup(npchar);
			PChar.MapBestTeleportDisable = true;
			LAi_ActorRunToLocation(npchar, "reload", "sea", Get_My_Cabin(), "", "", "", 10);
			sld = CharacterFromID("Flint");
			DeleteAttribute(sld, "curtown");
			//Запускаем Сильвера.
			if(pchar.location == "FortFrance_town")
			{
				BSCourtlyPassions_sailor();
			}
			else
			{
				SetFunctionExitFromLocationCondition("BSCourtlyPassions_sailor_begin_again", pchar.location, true);
			}
		break;

		//Переместить корабль в Ле Марен

		//Запись в СЖ: Жаркая схватка у Нассау была. Какого дьявола тут забыли английские патрули? Ну да ладно, этим вопросом займётся Флинт, моя задача – добыть часть кода у Чарльза Вейна. Отправляюсь на Мартинику, нужно пристать в одной из бухт, мало ли чем там дело обернётся.

		//Залочить выход в море. Топаем в Форт де Франс ножками.

		//На следующей локе, Сильвер заводит диалог.

		case "BS_KS_8":	//Сильвер
			dialog.text = "Vous avez un beau navire, et l'équipage, de vrais aigles !";
            link.l1 = "Merci. Alors, qu'est-ce que c'est que cette histoire de code en deux moitiés ? En bref, je te prie. Je ne suis pas d'humeur à écouter des histoires.";
			link.l1.go = "BS_KS_9";
		break;

		case "BS_KS_9":
            dialog.text = "On dirait qu'on vous enfonce un bâton dans le derrière, vous les capitaines, quand on vous donne un commandement : וcoutez les ordres !!! Un ris dans les huniers de misaine !!! La barre à bâbord !!!";
            link.l1 = "Ha. Tu es drכle. J'avais un cuisinier qui aimait bien faire des blagues, lui aussi.";
			link.l1.go = "BS_KS_10";
		break;

		case "BS_KS_10":
            dialog.text = "Il faut un type comme ça dans chaque équipage ! Comme ça, la vie de marin paraît moins dure !";
			link.l1 = "Peut-être. Seulement, à force de plaisanter, on l'a retrouvé avec une garcette enroulée autour du cou. Dans la cale. Et personne n'avait rien vu ni entendu. Pourquoi tu pâlis ? Je plaisante. Ha ha.";
			link.l1.go = "BS_KS_11"
		break;

		case "BS_KS_11":
            dialog.text = "Ha ha. Bon, venons-en au fait. J'ai mis la main sur une partie du journal de bord d'un caboteur espagnol. Comment je l'ai eu et ce que je faisais sur ce navire espagnol, c'est une autre histoire. En bref, en jetant un coup d'œil sur les papiers, j'ai compris qu'on y avait chiffré l'itinéraire d'un navire très important ; or, je me passionnais déjà pour toutes sortes de chiffres et d'énigmes au monastère, mais ça aussi, c'est une autre histoire. J'ai décidé de fêter ma trouvaille au bordel, et il y a là-bas une fille, Maxine qu'elle s'appelle. Une Créole de Louisiane. Jolie comme un cœur, la diablesse. Ce qu'elle fait au lit... Il n'y a pas de mots pour le décrire. Mais elle n'est pas seulement douée pour la bagatelle : elle a aussi la tête bien faite. Dans tous les sens du terme. Elle m'a roulé comme un gamin, ivre et épuisé de plaisir, et elle m'a pris la page chiffrée.";
            link.l1 = "C'est curieux, et ce serait presque drכle si cette page ne valait pas cent cinquante millions.";
			link.l1.go = "BS_KS_12";
		break;

		case "BS_KS_12":
            dialog.text = "Je suis d'accord. Je n'ai retenu que la moitié de la page, je n'avais pas beaucoup de temps, tu comprends. J'ai tout essayé avec elle, mais la fille est maligne, et elle a autant de relations en ville que le gouverneur. Nous avons décidé de devenir associés et de vendre ce code à un corsaire ou à un pirate. Ses relations tombaient à pic.";
            link.l1 = "Hum, hum, et ensuite ?";
			link.l1.go = "BS_KS_13";
		break;

		case "BS_KS_13":
            dialog.text = "Eh bien, elle est tombée sur le second de Charles Vane. Jack Rackham. Jack est un brave gars, tu feras sa connaissance, tu verras par toi-même ; il était prêt à faire un échange honnête. Seulement, son équipage, c'est une belle bande de coupe-jarrets et de vauriens. Quelqu'un a entendu quelque chose, et ça a tourné au massacre sur le lieu de l'échange. Flint m'a tiré de là par miracle ; Maxine est chez les pirates, et la page avec le code aussi, probablement.";
            link.l1 = "Et pourquoi irions-nous au bordel, si la fille et la page sont chez les pirates ? Oם est leur repaire ? Au François ?";
			link.l1.go = "BS_KS_14";
		break;

		case "BS_KS_14":
            dialog.text = "Oui, mais les petits oiseaux m'ont chanté que Max était retournée dans son nid, et que Vane cherchait un plus gros navire et recrutait un équipage. Il a dמ entendre lui aussi les histoires sur l'Urca.";
            link.l1 = "Voilà qui devient intéressant... Allons d'abord voir le tavernier du coin. Je veux en savoir plus sur cette Maxine.";
			link.l1.go = "BS_KS_14_1";
		break;

		case "BS_KS_14_1":
			AddQuestRecord("BSCourtlyPassions", "3");
			dialog.text = "Va pour la taverne. C'est vous le capitaine.";
            link.l1 = "Voilà qui est mieux.";
			link.l1.go = "BS_KS_14_2";
		break;

		case "BS_KS_14_2":
            DialogExit();
			DeleteAttribute(pchar, "BSCPSilver_talk")
			chrDisableReloadToLocation = false;
			LAi_ActorFollowEverywhere(npchar, "", -1);
			sld = CharacterFromID("FortFrance_tavernkeeper");
			sld.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			sld.dialog.currentnode = "BS_KS_15";
		break;

		//Запись в СЖ 'Страница у девки, девка у пиратов, пираты в ларце, ларец на дубе... Ничего не понятно, но начать стоит с таверны, разузнать про эту Максин'.

		//Форт де Франс. У бармена интересуемся Максин

		case "BS_KS_15":	//Бармен
            dialog.text = "Bienvenue dans notre modeste établissement, capitaine. Que puis-je faire pour vous ?";
            link.l1 = "Et en ville, comment ça se passe, cכté plaisirs de la chair ? J'ai entendu dire que vous aviez une petite traînée, une Créole.";
			link.l1.go = "BS_KS_16";
		break;

		case "BS_KS_16":
            dialog.text = "Pour les plaisirs de l'alcכve, renseignez-vous dans les endroits appropriés, "+ GetSexPhrase("monsieur", "mademoiselle") +". Mon établissement est respectable.";
            link.l1 = "Je comprends. Cinq cents piastres t'aideront-elles à délier ta langue ?";
			link.l1.go = "BS_KS_17";
		break;

		case "BS_KS_17":
            dialog.text = "Cinq cents ? J'ai l'air d'un mendiant ? Cinq mille pesos, et je vous dirai tout.";
			NextDiag.TempNode = "BS_KS_15";
			if (sti(pchar.money >= 5000))
			{
				link.l1 = "Je vous écoute.";
				link.l1.go = "BS_KS_18";
			}
			link.l2 = "Bon sang, oם est passée ma bourse ?";
			link.l2.go = "exit";
		break;

		case "BS_KS_18":
			AddMoneyToCharacter(pchar, -5000);
            dialog.text = "Il te faut Maxine, elle travaille au bordel du coin. Tu ferais mieux de demander à la patronne, elle est bien mieux renseignée que moi.";
            link.l1 = "Et c'est pour ça que je t'ai payé cinq mille ? Tu ne veux pas deux pieds d'acier froid dans le ventre ?";
			link.l1.go = "BS_KS_19";
		break;

		case "BS_KS_19":
			AddQuestRecord("BSCourtlyPassions", "4");
            dialog.text = "Pitié ! Bon, j'ai aussi entendu dire qu'elle ne reçoit plus de clients : les pirates l'ont durement malmenée, pour une raison ou une autre. On dit que c'est l'équipage de Vane lui-même... Oui, tout l'équipage, carrément. Alors cherche-en une autre, il y a des filles pour tous les goמts, ici. Seulement, je t'en prie, ne touche pas à la serveuse. C'est ma nièce.";
            link.l1 = "C'est par là qu'il fallait commencer. Bon, tu peux vivre. Et Vane lui-même, il se montre en ville ?";
			link.l1.go = "BS_KS_19_1";
		break;

		case "BS_KS_19_1":
            dialog.text = "Je ne fais pas d'affaires avec les pirates. דa finit toujours mal. Alors ce n'est pas à moi qu'il faut demander.";
            link.l1 = "Au revoir.";
			link.l1.go = "BS_KS_19_1exit";
		break;

		case "BS_KS_19_1exit":
			DialogExit();
			npchar.dialog.filename = "Common_tavern.c";
			NPChar.Dialog.CurrentNode = "First time";
			sld = CharacterFromID("FortFrance_hostess");
			sld.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			sld.dialog.currentnode = "BS_KS_20";
		break;
		//Запись в СЖ. Пора поискать Максин в борделе.

		//Идём в бордель, спрашиваем о Максин у хозяйки.

		case "BS_KS_20":
            dialog.text = "Bienvenue, "+GetSexPhrase("monsieur", "mademoiselle")+". Quel bon vent vous amène ?";
            link.l1 = "Je voudrais passer un moment avec l'une de tes beautés. Il court des rumeurs dans tout l'archipel sur votre Créole... Maxine, c'est bien son nom ? Alors, ça m'intrigue.";
			link.l1.go = "BS_KS_21";
		break;

		case "BS_KS_21":
            dialog.text = "Elle n'est pas en état de recevoir des clients en ce moment. Mais pour dix mille, nous pouvons faire une exception.";
            NextDiag.TempNode = "BS_KS_20";
			if (sti(pchar.money >= 10000))
			{
				link.l1 = "Merci, mademoiselle, je brמle déjà d'impatience.";	//Даём ей 10000
				link.l1.go = "BS_KS_21_exit";
			}
			link.l2 = "Bon sang, oם est passée ma bourse ?";
			link.l2.go = "exit";
		break;

		case "BS_KS_21_exit":
			DialogExit();
			npchar.Dialog.Filename = "Common_Brothel.c";
			NPChar.Dialog.CurrentNode = "First time";
			LocatorReloadEnterDisable("FortFrance_Brothel", "reload2_back", false);
            AddMoneyToCharacter(pchar, -10000);

			sld = GetCharacter(NPC_GenerateCharacter("BS_Maks", "BS_Maks", "woman", "woman", 1, PIRATE, -1, false));
			LAi_SetImmortal(sld, true);
			sld.name = GetConvertStrWithReplace("Variable_black_sails_functions_18", "Names.txt", "#space#", " ");
			sld.lastname 	= "";
			ChangeCharacterAddressGroup(sld, "FortFrance_Brothel_room", "goto", "goto3");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			sld.dialog.currentnode = "BS_KS_22";
		break;

		//Наверху смуглая шлюха

		case "BS_KS_22":	//Максин
            dialog.text = "Je t'attendais, "+ GetSexPhrase("mon chaton", "ma renarde") +". Et toi, qu'est-ce que tu fais ici, John ?";
            link.l1 = "Je pense que tu as deviné que nous ne sommes pas venus pour le plaisir.";
			link.l1.go = "BS_KS_22_1";
		break;

		case "BS_KS_22_1":	//Максин
            dialog.text = "Pourquoi donc ?";
            link.l1 = "Nous savons tout de tes mésaventures. J'en viens au fait. J'ai besoin de ce que tu as essayé de vendre au second de Vane. Dis-moi oם se cachent ces maudits pirates, et je leur ferai sortir les tripes, si ça peut te consoler.";
			link.l1.go = "BS_KS_23";
		break;

		case "BS_KS_23":
			AddQuestRecord("BSCourtlyPassions", "5");
            dialog.text = "Quelqu'un a décidé de prendre la défense d'une pauvre catin ? Comme c'est inattendu ! Comment pourrais-je résister ? א minuit, toute la bande de Charles Vane sera dans le souterrain, ici, en ville. Je t'en prie, quand tout sera fini, emmène-moi à Port Royal ?";
			link.l1 = "Marché conclu. א l'aube, attends-moi à la baie du Marin.";
			link.l1.go = "BS_KS_24_1";
		break;

		case "BS_KS_24_1":
			LAI_SetActorType(npchar);
			sld = CharacterFromID("BS_Silver");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.currentnode = "BS_KS_25";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;
		//На выходе из борделя диалог с Сильвером

		case "BS_KS_24":	//Сильвер
            dialog.text = "Alors, oם en sommes-nous ?";
            link.l1 = "Demain, nous irons au souterrain, à minuit.";
			link.l1.go = "BS_KS_25";
		break;

		case "BS_KS_25":
            dialog.text = "Cap'taine, je ne suis pas un combattant. Je me bats plus avec la langue qu'avec le sabre.";
            link.l1 = "Je l'avais remarqué. Reste ici et garde notre petite Maxine, puis escorte-la jusqu'à la baie du Marin.";
			link.l1.go = "BS_KS_26";
		break;

		case "BS_KS_26":
            dialog.text = "Avec grand plaisir !";
			LAI_SetActorType(npchar);
            link.l1 = "א plus tard.";
			link.l1.go = "exit";
			LAi_LockFightMode(PChar, true);
			PChar.quest.BSCourtlyPassions_wait.win_condition.l1 = "location";
			PChar.quest.BSCourtlyPassions_wait.win_condition.l1.location = "FortFrance_town";
			PChar.quest.BSCourtlyPassions_wait.function = "BSCourtlyPassions_wait";
		break;

		//Запись В СЖ 'Следующей ночью отправляюсь в подземелье Форт де Франс. Бой предстоит жаркий, нужно подготовиться. Ах да. И не забыть потом Максин доставить в Порт Рояль'

		//Тусим до следующей полуночи. Идём в подземку. Там по полной пиратов, прям чтоб мясо. Вейн среди них, но бессмертный.

		case "BS_KS_27":	//Чарльз Вейн
            ref _location = &locations[reload_location_index];
			LAi_LocationFightDisable(_location, false);
		    dialog.text = "Qu'est-ce que tu viens fouiner ici, bon sang ?";
            link.l1 = "J'ai à te parler, Charles. De la page que tu t'es appropriée.";
			link.l1.go = "BS_KS_28";
		break;

		case "BS_KS_28":
			AddQuestRecord("BSCourtlyPassions", "6");
			LAi_LockFightMode(PChar, false);
            dialog.text = "Qu'est-ce que vous attendez, plantés là comme des moutons ? Tuez-les tous !";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", Get_My_Cabin(), "", "", "", 10);
            link.l1 = "Oם est-ce que tu crois aller ? Halte !";
			link.l1.go = "BS_KS_28_exit";
			chrDisableReloadToLocation = false;

			PChar.quest.BSCourtlyPassions_fleeng.win_condition.l1 = "location";
			PChar.quest.BSCourtlyPassions_fleeng.win_condition.l1.location = "FortFrance_town";
			PChar.quest.BSCourtlyPassions_fleeng.function = "BSCourtlyPassions_fleeng";
		break;

		case "BS_KS_28_exit":
			DialogExit();
			LAi_group_SetHearRadius("EnemyFight", 100.0);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", Get_My_Cabin(), "", "", "", 10);
			AddDialogExitQuest("MainHeroFightModeOn");
			Log_info("« Arrête-toi ! De toute façon, je te rattraperai ! »");
		break;

		//Файт. Вейн удирает. Вывести лог "А ну стой! Всё равно догоню же!" - типо намёк, что файтится не обязательно со всеми. Там ещё вроде как должен музон играть боевой во время погони. 6.04.2023  

		case "BS_KS_29":
            dialog.text = "Eh bien, on dirait que la chance a abandonné Charles Vane. Mais je ne me rendrai pas comme ça !";
            link.l1 = "On ne pourrait pas simplement parler ?";
			link.l1.go = "BS_KS_30";

			PChar.quest.BSCourtlyPassions_final.win_condition.l1 = "location";
			PChar.quest.BSCourtlyPassions_final.win_condition.l1.location = "Shore39";
			PChar.quest.BSCourtlyPassions_final.function = "BSCourtlyPassions_final";
			DeleteAttribute(pchar, "BSCourtlyPassionsFail");
		break;

		case "BS_KS_30":
            dialog.text = "Ha ha ha. Tu te moques de moi !";
            link.l1 = "La page chiffrée. J'ai quelqu'un qui peut casser ce chiffre. Et toi, tu as la réputation d'être le pirate le plus intrépide et le plus chanceux de ces eaux. Unissons nos forces ? Il y a assez d'or de l'Urca pour tout le monde.";
			link.l1.go = "BS_KS_31";
		break;

		case "BS_KS_31":
            dialog.text = "Qui ça, « nous » ? Tu ne serais pas avec Flint, par hasard ?";
            link.l1 = "Si, je suis avec lui. Je connais sa réputation, mais cent cinquante millions, Charles, réfléchis !";
			link.l1.go = "BS_KS_32";
		break;

		case "BS_KS_32":
			AddQuestRecord("BSCourtlyPassions", "7");		
            dialog.text = "Bon, j'en suis. Pourquoi pas ? Tout part à vau-l'eau ces derniers temps, mais je remettrai la page à Flint en personne. J'ai vraiment envie de regarder ses yeux de poisson à ce moment-là.";
            link.l1 = "Très bien. On se voit aux Bahamas. J'ai encore une affaire à régler.";
			link.l1.go = "BS_KS_32exit";
		break;

		case "BS_KS_32exit":
            QuestAboardCabinDialogSurrender();
			SetFunctionExitFromLocationCondition("BS_Vein_Immortal", pchar.location, false);
			PChar.quest.BSCourtlyPassions_fail_to_board.over = "yes";
            DialogExit();
		break;

		//Топаем в Ле Марен. Уникумы тут используют фичу с телепортом по карте и ломают квест. Либо пусть ломают, либо  как то отключить возможность ТП на время 6.04.2023

		case "BS_KS_33":	//Сильвер
			Group_DeleteGroup("BSCourtlyPassions_SeaBattle");
            dialog.text = " Kapitan ?";
            link.l1 = "C'est fait, allons-y.";
			link.l1.go = "BS_KS_34";
		break;

		case "BS_KS_34":	//Сильвер
            dialog.text = "Je n'ai jamais douté de toi une seule seconde !";
            link.l1 = "C'est ça, arrête de me lécher les bottes.";
			link.l1.go = "BS_KS_35exit";
		break;


		case "BS_KS_35exit":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", 10);
			sld = CharacterFromID("BS_Maks");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Kurtuaznye_Strasti.c";
			sld.dialog.currentnode = "BS_KS_35";
			DialogExit();
			DoQuestFunctionDelay("MaksSpeech", 0);
		break;

		case "BS_KS_35":
            dialog.text = "Ils sont morts ?";
            link.l1 = "La plupart.";
			link.l1.go = "BS_KS_36_1";
		break;

		case "BS_KS_36_1":
            dialog.text = "Alors, tu m'emmènes à Port Royal, maintenant ?";
            link.l1 = "Je te l'ai promis. Tout le monde à bord !";
			link.l1.go = "BS_KS_36_exit";
			PChar.quest.BSCourtlyPassions_finalRoyal.win_condition.l1 = "location";
			PChar.quest.BSCourtlyPassions_finalRoyal.win_condition.l1.location = "PortRoyal_town";
			PChar.quest.BSCourtlyPassions_finalRoyal.function = "BSCourtlyPassions_finalRoyal";
		break;

		case "BS_KS_36_exit":
			DialogExit();
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", 10);
		break;

		case "BS_KS_36":
            dialog.text = "Merci, capitaine ! Personne n'a jamais pris autant soin de moi.";
            link.l1 = "Il y a une première fois à tout.";
			link.l1.go = "BS_KS_37";
		break;

		case "BS_KS_37":
            dialog.text = "J'espère que nous nous reverrons ?";
            link.l1 = "Qui sait ? Peut-être. Prends soin de toi.";
			link.l1.go = "BS_KS_37exit";
		break;

		case "BS_KS_37exit":
			DialogExit();
			pchar.quest.BSCourtlyPassions_DontStart.over = "yes";
			chrDisableReloadToLocation = false;
			pchar.ContraInterruptWaiting = true;
			LAi_ActorGoToLocation(npchar, "reload", "reload9_back", "none", "", "", "", -1);
			SetFunctionLocationCondition("BS_BahamasArrival", "Bahames", false);
			AddQuestRecord("BSCourtlyPassions", "8");
			CloseQuestHeader("BSCourtlyPassions");
			BSChaseBegun();
		break;

		//Отвозим шлюху в ПР, она уходит с корабля. Отправляемся на Багамы.

		//Запись в СЖ «Дело сделано, теперь можно отправиться на Багамы.»

	}
}
