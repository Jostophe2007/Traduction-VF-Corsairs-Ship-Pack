
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "FirstMeet":
			dialog.text = "דa alors, le grand champion de l'arène en personne est venu à ma rencontre ! Je peux te suivre ? S'il te plaît, s'il te plaît !";
			link.l1 = "Soit... Allez, viens.";
			link.l1.go = "exit";
			LAi_CharacterPlaySound(NPChar, "Fan_FirstMeet");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_ActorFollowEverywhere(npchar, "", -1);
			Log_info("Scam Games, le fan le plus dévoué du champion de l'arène, vous suit désormais.");
		break;

		case "exit_2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "", "", "", "OpenTheDoors", -1);
			npchar.LifeDay = 0;
			pchar.ScamDestroyed = true;
		break;

		case "exit_3":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_ActorFollowEverywhere(npchar, "", -1);
			chrDisableReloadToLocation = false;
			InterfaceStates.DisFastTravel = false;
		break;

		case "Scared":
			dialog.text = "Qu'est-ce qu'on fait ici ?! Il faut fuir d'ici immédiatement !";
			link.l1 = "Hum, c'est la première fois que je te vois réagir comme ça. Pourquoi tout à coup... ?";
			link.l1.go = "Scared_2";
			LAi_CharacterPlaySound(NPChar, "Fan_Scared");
		break;

		case "Scared_2":
			SpawnDeadGodSkulls();
			DialogExit();
		break;

		case "DeadGod":
		if (CheckCharacterItem(pchar, "skullAztec"))
		{
			dialog.text = "Oh, qui vois-je... Tu portes toujours mon petit cadeau ?";
			link.l1 = "Mictlantecuhtli, j'ai une requête à te présenter. Tu veux bien m'écouter ?";
			link.l1.go = "DeadGod_2";
		}
		else
		{
			dialog.text = "Que fait un mortel dans le temple des sacrifices ? J'exige une explication !";
			link.l1 = "Je ne sais pas qui tu es, mais ta seule vue me fait déjà peur.";
			link.l1.go = "DeadGod_2";
		}
		break;

		case "DeadGod_2":
			if (CheckCharacterItem(pchar, "skullAztec"))
			{
				dialog.text = "Laisse-moi deviner. Cet énergumène est avec toi ? Tu veux t'en débarrasser ?";
				link.l1 = "En plein dans le mille. Tu vas m'aider ?";
				link.l1.go = "DeadGod_3";
			}
			else
			{
				dialog.text = "Attends un peu... Qui d'autre est avec toi ? Cette odeur m'est très familière. Ne serait-ce pas l'idiot à qui j'ai donné l'immortalité pour m'amuser, en voyant son insignifiance totale ?";
				link.l1 = "Si tu m'aides à me débarrasser de lui, je ferai n'importe quoi.";
				link.l1.go = "DeadGod_3";
			}
		break;

		case "DeadGod_3":
			dialog.text = "Un jeu d'enfant... C'est fait ! Il ne reviendra jamais ici, sur la terre des pécheurs. Il était temps qu'il parte.";
			link.l1 = "Comment puis-je te remercier ?";
			link.l1.go = "DeadGod_4";
			ref rChar = CharacterFromID("ScamCharacter");
			rChar.LifeDay = 0;
			ChangeCharacterAddressGroup(rChar, "none", "", "");
			Log_info("Scam Games, le fan le plus dévoué du champion de l'arène, vous laisse tranquille pour de bon.");
		break;

		case "DeadGod_4":
			dialog.text = "Ne fais pas de bêtises ici. Il est rare de voir des vivants à Tenochtitlan, à part mes prêtres, alors je surveillerai ce que tu fais ici.";
			link.l1 = "J'essaierai de ne pas te contrarier inutilement. Adieu !";
			link.l1.go = "exit_2";
		break;

		case "CoolStory":
			string coolstory = "";
			switch (rand(20))
			{
				case 0:
					coolstory = "Vous devriez absolument ajouter à l'encyclopédie une liste des quêtes uniques, avec une description des villes oם l'on peut les obtenir."
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_0");
				break;
				case 1:
					coolstory = "Une proposition pour équilibrer un peu les navires. Actuellement, l'amélioration des Bermudes est très avantageuse et, dans une certaine mesure, trop bonne. Il s'agit surtout des calibres. Passer de 24 à 32 livres, c'est un sacré saut. D'oם la proposition d'équilibrer un peu cet aspect, pour que ça reste une excellente amélioration, mais sans un bonus aussi fort qu'aujourd'hui. Prenons n'importe quel navire armé de 24 livres. Actuellement, l'amélioration le fait passer de 24 à 32. Proposition : créer un calibre intermédiaire de 28 livres. Ce serait toujours un bon renforcement, mais moins fort qu'aujourd'hui. Faire de même pour les autres calibres, par exemple ajouter un calibre intermédiaire de 18 livres au lieu de passer de 16 à 20. Je suis sמr que ça aurait un effet raisonnable sur l'équilibre du jeu."
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_1");
				break;
				case 2:
					coolstory = "
";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_2");
				break;
				case 3:
					coolstory = "Proposition : permettre aux contrebandiers de nous commander les canons dont on a besoin. Le prix serait plus élevé que d'habitude. Ce serait aussi utile à ceux qui jouent pour la nation pirate.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_3");
				break;
				case 4:
					coolstory = "Personnellement, je pense que les squelettes en héros principaux, c'est une idée ratée. Personne ne veut coder ni écrire d'histoire pour eux, alors ils ne servent à rien. א la rigueur, on pourrait garder un seul personnage de ce genre comme personnage unique, mais seulement à condition d'avoir au moins une petite intrigue, ainsi qu'un modèle unique sous la forme d'une personne vivante après sa renaissance.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_4");
				break;
				case 5:
					coolstory = "En toute logique, il faudrait rendre le Chien au CPC. Donner à Whisper un autre senau à la place du Chien. La coque doit être retirée de la Cité des navires abandonnés et gardée pour plus tard. Comme le Hollandais volant, elle a besoin de sa propre quête séparée. Il y aura une quête avec Barbe Noire pour la Revanche de la Reine Anne. C'est du moins ce que certains disaient. Même si la Revanche de la Reine Anne ne me plaît pas non plus. D'ailleurs, j'en ai vu des modèles bien meilleurs. Dommage qu'il faille les texturer, et ainsi de suite.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_5");
				break;
				case 6:
					coolstory = "Il y a beaucoup trop de navires dans le pack. Passe encore pour les mauvais modèles, beaucoup peuvent être remplacés. Mais bien des navires sont tout simplement inutiles. Ils ne servent à rien, tout bêtement. Pourquoi ajouter au jeu dix sortes de sloops inutiles, alors qu'il pourrait y en avoir trois corrects et bien équilibrés ?";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_6");
				break;
				case 7:
					coolstory = "La solution à l'inutilité des officiers en fin de partie est simple : 1. Rendre certaines compétences exclusives aux officiers, sans possibilité de les prendre pour le héros. On peut introduire de nouvelles compétences pour ça. 2. Lier strictement les officiers à leur spécialité. Pour qu'un marchand ne puisse être que marchand, sans pouvoir être officier d'abordage. Et pareil pour les autres postes.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_7");
				break;
				case 8:
					coolstory = "Si vous voulez aider à introduire quelque chose de nouveau, il est bien plus utile pour tout le monde d'ajouter de nouvelles animations de coups que d'ajouter à Corsaires ce genre de jeu avec des enfants. On a assez vu ces gamins dans Skyrim. Ce genre de jeux n'a aucun intérêt, surtout quand ils jouent le rכle de simples figurants. Et jouer une telle horreur, qui plus est sur le moteur Storm, non merci !";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_8");
				break;
				case 9:
					coolstory = "En fait, séparer les navires par leurs noms n'est pas si simple. Une bonne solution, comme aujourd'hui, c'est quand les noms de certains navires sont séparés par nation. C'est-à-dire le galion anglais, l'espagnol, et ainsi de suite. En revanche, il faudrait se débarrasser d'une façon ou d'une autre des noms du genre « flמte de combat lourde ». Les navires de 1re classe pourraient être répartis par rangs en vaisseaux de ligne selon le nombre de canons.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_9");
				break;
				case 10:
					coolstory = "Tout ça, c'est du vent, tous ces repaints vieux de plusieurs décennies. Sans nouveaux modèles, on n'aura rien.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_10");
				break;
				case 11:
					coolstory = "Tout le problème, c'est que le jeu est intéressant en combat naval. C'est vraiment intéressant de se battre. Mais en combat à terre, c'est parfois très étouffant. Quelqu'un a proposé il y a longtemps de diviser la difficulté en deux curseurs : difficulté à terre et en mer. On pourrait alors régler sans crainte la barre pour les batailles navales et, par exemple, mettre une difficulté moindre pour le combat à terre. Il n'y aurait alors plus de plaintes sur les combats étouffants à terre.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_11");
				break;
				case 12:
					coolstory = "Ajouter à l'Angleterre, à la Hollande et à l'Espagne leurs navires uniques en récompense de la ligne nationale. C'est un peu injuste que seule la France ait son Soleil. Les autres pourraient aussi recevoir des navires semblables. Pas des méga-monstres, mais que chacun ait ses propres caractéristiques uniques.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_12");
				break;
				case 13:
					coolstory = "Supprimer l'absurde gâchis de la quête de l'Orion. Je comprends que cela a peut-être été fait pour que le joueur tombe par hasard sur cette quête, etc. Mais beaucoup de joueurs n'en entendront même pas parler, car beaucoup ne voudront tout simplement pas prendre un travail d'escorte et, par conséquent, ne découvriront peut-être jamais cette quête. La solution simple, c'est d'ajouter chez le tavernier un dialogue séparé sur les rumeurs et le travail. Cela a déjà été fait dans beaucoup de quêtes normales.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_13");
				break;
				case 14:
					coolstory = "Une proposition un peu étrange, mais compréhensible : retirer les pistolets aux squelettes. דa ne plaira peut-être pas à tout le monde, puisque tout le monde est habitué aux squelettes avec des pistolets à quatre canons et ainsi de suite, mais c'est compréhensible du point de vue du bon sens, et même selon l'univers du jeu. Les squelettes ne peuvent pas avoir d'armes en état de marche.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_14");
				break;
				case 15:
					coolstory = "Au moins, on pourrait prolonger l'intrigue de Blood, puisqu'il n'en a pas, alors que Whisper en a une. Et aussi Grammont, Patterson et Diego.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_15");
				break;
				case 16:
					coolstory = "Pour commencer, on aimerait que tous les personnages clés aient de vrais prologues. Et c'est étrange de penser à une intrigue globale.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_16");
				break;
				case 17:
					coolstory = "Le plus drכle, c'est que même en difficulté « Impossible », vers le rang 30, on détruit tranquillement n'importe quel navire. Autrement dit, même dans cette difficulté, le héros reste surpuissant. Mais maintenant, l'IA a reçu des améliorations et une protection de coque. On ne perce plus aussi facilement un 1re classe avec un 3e classe.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_17");
				break;
				case 18:
					coolstory = "D'une manière générale, l'équilibre des navires pose évidemment des problèmes. Qu'il y ait plein de modèles médiocres, on le comprend, mais remplacer un modèle rendra seulement les navires plus jolis, pas plus jouables. Ce sont surtout les navires de 6e et 5e classe qui en souffrent : toutes ces goélettes, sloops et lougres tout simplement très faibles face à leurs concurrents de la même classe. Par exemple, le sloop lourd de 6e classe vaut carrément un 5e classe. א cכté de lui, les autres sont nuls. Et puis, il y a le problème de l'équilibre des 1re et 2e classes. א mon avis, il y en a beaucoup trop dans le jeu. Tout le monde aime les beaux combats entre des tas de navires de guerre, mais là, c'est sans doute trop. L'équilibre idéal, ce serait que les 2e et 1re classes soient rares, et seulement dans les escadres les plus fortes. Le joueur serait alors motivé pour chercher et capturer de tels navires.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_18");
				break;
				case 19:
					coolstory = "D'une manière générale, c'est un sujet étrange, les officiers. De toute façon, par exemple, personne ne nommera un marchand officier d'abordage avec ses faibles compétences. Donc, toutes ces discussions sur leur nullité sont un peu tirées par les cheveux. Les officiers proposés par les quêtes sont aussi des personnages de quête, ils sont polyvalents, et beaucoup d'entre eux restent à trouver.";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_19");
				break;
				case 20:
					coolstory = "D'une manière générale, ce serait bien de répartir tous les modèles d'officiers actuels par nation. Pour que, par exemple, les pirates n'aient que des modèles à l'allure de pirates et de matelots. Et que, dans les villes nationales, il y ait des officiers dans l'uniforme approprié. Pour l'instant, tous les officiers sont simplement aléatoires. Je me demande si on peut leur attribuer une nation, comme pour les capitaines générés et le héros ?";
					LAi_CharacterPlaySound(NPChar, "Fan_CoolStory_20");
				break;
			}
			dialog.text = coolstory;
			link.l1 = "Tu racontes des histoires étonnantes, frérot... !";
			link.l1.go = "exit_3";
		break;
	}
}

void SpawnDeadGodSkulls()
{
	ref sld = GetCharacter(NPC_GenerateCharacter("FakeDeadmansGod", "mictlantecuhtli", "skeleton", "man", 100, PIRATE, 0, true));
    FantomMakeCoolFighter(sld, 100, 100, 100, "toporAZ", "pistol5", 3000);
	GetCharacterPos(pchar, &locx, &locy, &locz);
	ChangeCharacterAddressGroup(sld, "Temple_skulls", "goto", "goto2");
	LAi_SetActorTypeNoGroup(sld);
	LAi_SetImmortal(sld,true);
	sld.name = "Mictlantecuhtli";
	sld.lastname = "";
	sld.dialog.filename = "Fan.c";
	sld.dialog.currentnode = "DeadGod";
	LAi_group_MoveCharacter(sld, "player");
	LAi_ActorDialog(sld, pchar, "", 4.0, 0);
}
