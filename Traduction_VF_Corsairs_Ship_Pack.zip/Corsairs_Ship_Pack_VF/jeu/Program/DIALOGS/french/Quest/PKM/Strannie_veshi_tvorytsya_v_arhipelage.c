
void ProcessDialogEvent()
{
	ref NPChar;											// 						АВТОРЫ И БЛАГОДАРНОСТИ
	aref Link, NextDiag;								// Оригинальная идея квеста				    			 - Акелла
														// Написанный с нуля код и переосмысление квеста 	 	 - Sinistra
	DeleteAttribute(&Dialog, "Links");					// Улучшенная и обновлённая локация "The Lair of Satanists"  - Nikk
														// Улучшенный и обновлённый корабль "Mephisto"			 - Noctus
	makeref(NPChar,CharacterRef);						// Новая анимация "Worship"							 - Antix
	makearef(Link, Dialog.Links);						// Улучшенная и обновлённая иконка "Amulet of Chaos"		 - LEOPARD
	makearef(NextDiag, NPChar.Dialog);					// Новая текстура модели для "Maltese" 				 - Gregg
														// Новая текстура модели для "Satanists" 				 - Ерилейн
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "First time":
			dialog.text = "Quoi ? Vous vous moquez aussi des pauvres femmes !?";
			link.l1 = "Que se passe-t-il exactement ?";
			link.l1.go = "Verni_detey_1";
			PlayVoice("Kopcapkz\Voices\Quest\Dut_f_a_002.wav");
		break;
		
		case "Verni_detey_1":
			dialog.text = "Regardez-moi "+GetSexPhrase("cet effronté", "cette effrontée")+" ! Vous n'avez pas honte de vous moquer de nous ?!";
			link.l1 = "Je ne comprends vraiment pas ce qui s'est passé. Vous pourriez peut-être me le dire ?";
			link.l1.go = "Verni_detey_2";
		break;
		
		case "Verni_detey_2":
			dialog.text = "Braves gens, qu'est-ce qui se passe dans ce monde ! On nous a volé nos enfants la nuit dernière, et ce provincial n'a même pas levé le petit doigt !";
			link.l1 = "Attendez, comment ça, volés ? Par qui ?";
			link.l1.go = "Verni_detey_3";
		break;
		
		case "Verni_detey_3":
			dialog.text = "Je ne sais pas ! Je me suis endormie, l'enfant était dans son berceau, et la nuit, je me suis réveillée parce que mon cœur s'est serré très fort ; je regarde, et le bébé n'est plus là !";
			link.l1 = "C'est très étrange. Et que dit le gouverneur ?";
			link.l1.go = "Verni_detey_4";
		break;
		
		case "Verni_detey_4":
			dialog.text = "Il ne met pas le nez hors de chez lui ! Il a peur, voilà ! Il n'a rien à nous dire !";
			link.l1 = "Attendez, arrêtez de crier, je vais essayer de lui parler.";
			link.l1.go = "Verni_detey_5";
		break;
		
		case "Verni_detey_5":
			dialog.text = "Que Dieu vous bénisse, "+GetSexPhrase("bon monsieur", "brave fille")+" !";
			link.l1 = "Attendez-moi ici.";
			link.l1.go = "Verni_detey_6";
		break;
		
		case "Verni_detey_6":
			DialogExit();
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_1")
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Verni_detey_7";
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_2")
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Verni_detey_7";
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_3")
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Verni_detey_7";
			
			pchar.questTemp.PKM_SvtvA_Gde_Deti = "Gde_Deti";
			SetQuestHeader("PKM_Animists");
			AddQuestRecord("PKM_Animists", "1");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
		break;
		
		case "Verni_detey_7":
			dialog.text = "Alors ? Vous avez appris quelque chose ? Comment vont nos enfants ?!";
			link.l1 = "Je vais essayer de vous aider. Maintenant, je vous en prie, dispersez-vous.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Verni_detey_7";
			PlayVoice("Kopcapkz\Voices\Quest\Dut_f_a_002.wav");
		break;
		
		case "Capitan_v_taverne_1":
			dialog.text = "Tu veux me payer à boire ?";
			link.l1 = "Pardon, l'ami, je ne te paierai pas à boire, mais je vais te poser des questions.";
			link.l1.go = "Capitan_v_taverne_1_5";
			UnmarkCharacter(npchar);
		break;
		
		case "Capitan_v_taverne_1_5":
			dialog.text = "Alors, pose-les vite et fiche le camp.";
			link.l1 = "On dit que tu as vu une sorte de frégate noire en approchant de l'île.";
			link.l1.go = "Capitan_v_taverne_2";
		break;
		
		case "Capitan_v_taverne_2":
			dialog.text = "Eh bien, et toi, tu l'as vue ?";
			link.l1 = "Quel cap a-t-elle pris ?";
			link.l1.go = "Capitan_v_taverne_3";
		break;
		
		case "Capitan_v_taverne_3":
			dialog.text = "Droit sur Niévès.";
			link.l1 = "דa pourrait être des pirates ?";
			link.l1.go = "Capitan_v_taverne_4";
		break;
		
		case "Capitan_v_taverne_4":
			dialog.text = "Le diable seul le sait ! Va donc leur demander. Ha ha !";
			link.l1 = "Merci, mon cher.";
			link.l1.go = "Capitan_v_taverne_5";
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
		break;
		
		case "Capitan_v_taverne_5":
			DialogExit();
			AddQuestRecord("PKM_Animists", "4");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PKM_SvtvA_SprositKapitanov_v_more = true;
			pchar.questTemp.PKM_SvtvA_NevisTaverna_1 = true;
			pchar.questTemp.PKM_SvtvA_NevisPortMan_1 = true;
			
			PChar.quest.PKM_SvtvA_SprositKapitanov_v_more.win_condition.l1 = "MapEnter";
			PChar.quest.PKM_SvtvA_SprositKapitanov_v_more.win_condition = "PKM_SvtvA_SprositKapitanov_v_more";
			
			sld = GetCharacter(NPC_GenerateCharacter("PKM_SvpvA_Shturman_1", "shipowner_17", "man", "man", 10, ENGLAND, -1, true));
			sld.name = "Balltezar";
			sld.lastname = "Figueidal";
			FreeSitLocator("Charles_tavern", "sit_base4");
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Shturman_v_taverne_1";
			LAi_SetSitType(sld);
			LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
			ChangeCharacterAddressGroup(sld, "Charles_tavern", "sit", "sit_base4");	
		break;
		
		case "Shturman_v_taverne_1":
			dialog.text = "Fiche le camp, "+ GetSexPhrase("l'ami", "ma fille") +" !";
			link.l1 = "";
			link.l1.go = "exit";
			NextDiag.TempNode = "Shturman_v_taverne_1";
		break;
		
		case "Shturman_v_taverne_2":
			dialog.text = ""+ GetSexPhrase("Mon vieux", "Ma belle") +" ! Paie à boire au meilleur navigateur du Nouveau Monde !";
			link.l1 = "Tu as déjà tout bu, l'ami ?";
			link.l1.go = "Shturman_v_taverne_3";
		break;
		
		case "Shturman_v_taverne_3":
			dialog.text = "Tout, jusqu'au dernier sou. Alors, tu me paies une chope ?";
			link.l1 = "Attends, je me demandais si tu avais vu une frégate noire pendant ta traversée ?";
			link.l1.go = "Shturman_v_taverne_4";
		break;
		
		case "Shturman_v_taverne_4":
			dialog.text = "Paie-moi un rhum et je te dirai tout !";
			link.l1 = "D'accord, voilà ton rhum.";
			link.l1.go = "Shturman_v_taverne_5";
			link.l2 = "Oh, et si je te cognais un peu la tête contre le comptoir ?";
			link.l2.go = "Shturman_v_taverne_9";
		break;
		
		case "Shturman_v_taverne_5":
			dialog.text = "Glou-glou. Il est bo-o-on, ce rhum !";
			link.l1 = "Alors, tu as vu la frégate noire ?";
			link.l1.go = "Shturman_v_taverne_6";
			AddMoneyToCharacter(pchar, -10);
		break;
		
		case "Shturman_v_taverne_9":
			dialog.text = "Hum... On va s'en passer.";
			link.l1 = "Alors, tu as vu la frégate noire ?";
			link.l1.go = "Shturman_v_taverne_6";
			ChangeCharacterReputation(pchar, -2);
		break;
		
		case "Shturman_v_taverne_6":
			dialog.text = "La frégate ? Noire ?! Je l'ai vue comme je te vois. Si nous n'avions pas navigué à vide, je ne serais pas là à te parler : elle, en revanche, avait visiblement les cales pleines à ras bord. Elle portait aussi un nom étrange, pas chrétien : « Mephisto ».";
			link.l1 = "Elle t'a poursuivi ? Et oם est-elle allée quand elle a compris qu'elle ne pourrait pas te rattraper ?";
			link.l1.go = "Shturman_v_taverne_7";
		break;
		
		case "Shturman_v_taverne_7":
			dialog.text = "Le diable seul le sait. Quelque part vers le sud, et il n'y a que Le François, par là.";
			link.l1 = "Bon, continue à boire.";
			link.l1.go = "Shturman_v_taverne_8";
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
		break;
		
		case "Shturman_v_taverne_8":
			DialogExit();
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_NevisPortMan_1");
			AddQuestRecord("PKM_Animists", "6");
			pchar.questTemp.PKM_SvtvA_LeFrancuaTaverna_1 = "Taverna";
		break;
		
		case "Satanist_v_gorode_1":
			dialog.text = "Pas si vite, "+ GetSexPhrase("señor", "señorita") +" ! Vous ne refuserez pas de parler avec nous, n'est-ce pas ?!";
			link.l1 = "Je ne crois pas avoir envie de vous parler.";
			link.l1.go = "Satanist_v_gorode_2";
		break;
		
		case "Satanist_v_gorode_2":
			dialog.text = "Donnez-nous la lettre, tout de suite !";
			link.l1 = "Et si on buvait une chope de bière avant de se séparer ? Non ? Je m'en doutais.";
			link.l1.go = "Satanist_v_gorode_3";
		break;
		
		case "Satanist_v_gorode_3":		//Битва в городе
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			for (i=1; i<=11; i++)
			{
				sld = CharacterFromID("SatanaElita_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PKM_SvtvA_DostavkaPisma_Gorod_2");
			LAi_SetFightMode(pchar, true);			
		break;
		
		case "Satanist_v_buhte_1":
			dialog.text = "Pas si vite, "+ GetSexPhrase("señor", "señorita") +" ! Vous ne refuserez pas de parler avec nous, n'est-ce pas ?!";
			link.l1 = "Je ne crois pas avoir envie de vous parler.";
			link.l1.go = "Satanist_v_buhte_2";
			link.l2 = "Parlons, mais faites vite, le temps presse.";
			link.l2.go = "Satanist_v_buhte_4";
		break;
		
		case "Satanist_v_buhte_2":
			dialog.text = "Donnez-nous la lettre, tout de suite !";
			link.l1 = "Et si on buvait une chope de bière avant de se séparer ? Non ? Je m'en doutais.";
			link.l1.go = "Satanist_v_buhte_3";
		break;
		
		case "Satanist_v_buhte_3":		//Битва в бухте без разговора
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			for (i=1; i<=4; i++)
			{
				sld = CharacterFromID("Satanist_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PKM_SvtvA_DostavkaPisma_Buhta_2");
			LAi_SetFightMode(pchar, true);			
		break;
		
		case "Satanist_v_buhte_4":
			dialog.text = "Nous avons appris que vous transportiez une lettre, et nous devons la lire. Ne vous inquiétez pas, nous avons une copie du sceau qui l'a scellée, et le destinataire ne saura rien de ce qui s'est passé. Et en récompense de ce service, nous sommes prêts à vous payer 20 000 piastres. Qu'en dites-vous ?";
			link.l1 = "Ce que j'en dis ? Laissez-moi trouver la bonne formule... hum... ah ! D'abord, si vous alliez voir ailleurs ? Et votre sceau, vous pouvez vous le mettre oם je pense.";
			link.l1.go = "Satanist_v_buhte_5";
			link.l2 = "Hum... 20 000 piastres... c'est tentant, je crois que nous avons un accord. Voici la lettre.";
			link.l2.go = "Satanist_v_buhte_7";
		break;
		
		case "Satanist_v_buhte_5":
			dialog.text = "Dans ce cas, nous allons devoir vous tuer.";
			link.l1 = "Essayez donc !";
			link.l1.go = "Satanist_v_buhte_6";
		break;
		
		case "Satanist_v_buhte_6":		//Битва в бухте с разговором и отказываемся отдавать письмо
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			for (i=1; i<=4; i++)
			{
				sld = CharacterFromID("Satanist_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PKM_SvtvA_DostavkaPisma_Buhta_3");
			LAi_SetFightMode(pchar, true);			
		break;
		
		case "Satanist_v_buhte_7":
			dialog.text = "Vous avez bien agi, "+ GetSexPhrase("señor", "señorita") +". Voici votre argent, et maintenant, regardons cette lettre. Hum... C'est bien ce que je pensais... Eh bien, ils se trompent là-dessus... Bon, j'ai appris tout ce que je voulais savoir. Je rescelle la lettre : vous voyez que le motif des sceaux est identique ? Vous pouvez partir maintenant.";
			link.l1 = "D'accord.";
			link.l1.go = "Satanist_v_buhte_8";
			AddMoneyToCharacter(pchar, 20000);
		break;
		
		case "Satanist_v_buhte_8":
			DialogExit();
			for (i=1; i<=4; i++)
			{
				sld = CharacterFromID("Satanist_"+i)
				LAi_SetActorType(sld);
				LAi_ActorGoToLocation(sld, "reload", "reload1_back", "none", "", "", "", -1);
				sld.lifeday = 0;
				LAi_CharacterDisableDialog(sld);
				LAi_SetImmortal(sld, true);
			}
			LAi_LocationFightDisable(loadedLocation, false);
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			AddQuestRecord("PKM_Animists", "12");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PKM_SvtvA_SanJuanChurch_1_Zlo = "Church1";
			PChar.quest.PKM_SvtvA_SJ_B1.over = "yes";
			PChar.quest.PKM_SvtvA_SJ_B2.over = "yes";
			PChar.quest.PKM_SvtvA_SJ_B3.over = "yes";
		break;
		
		case "Знакомство с Жаком":
			dialog.text = "Capitaine, je ne sais même pas comment vous remercier ! Sans vous, mon navire et tout son équipage reposeraient déjà au fond de la mer. Je m'appelle Jacquin de Masset, chevalier de l'ordre de Malte.";
			link.l1 = "C'est un plaisir, Jacquin. Et moi, je suis " + GetFullName(pchar)+".";
			link.l1.go = "Знакомство с Жаком_2";
		break;
		case "Знакомство с Жаком_2":
			dialog.text = "Alors, c'est vous le capitaine dont on m'a averti par pigeon voyageur.";
			link.l1 = "Vous devinez juste. J'ai pour instructions de vous escorter jusqu'à Porto Rico.";
			link.l1.go = "Знакомство с Жаком_3";
		break;
		case "Знакомство с Жаком_3":
			dialog.text = "Bien. Dans ce cas, nous pouvons prendre la route.";
			link.l1 = "Parfait ! Alors, ne tardons pas !";
			link.l1.go = "Знакомство с Жаком_4";
		break;
		case "Знакомство с Жаком_4":
			DialogExit();
			pchar.questTemp.PKM_SvtvA_Znakomstvo_s_Malta2 = true;
			pchar.questTemp.PKM_SvtvA_Dostavka_Malty = true;
			Group_DeleteGroup("PKM_SvtvA_Malta");
			SetCompanionIndex(pchar, -1, sti(NPChar.index));
			SetShipRemovable(npchar, false);
			SetCharacterRemovable(npchar, false);
			AddQuestRecord("PKM_Animists", "18");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			npchar.dialog.currentnode = "Знакомство с Жаком_5";
		break;
		case "Знакомство с Жаком_5":
			dialog.text = "Au nom de tous les saints ! Nous n'avons pas de temps à perdre, il faut se hâter vers Porto Rico.";
			link.l1 = "Oui, Jacquin, vous avez raison.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Знакомство с Жаком_5";
		break;
		
		case "Satanist_zasada2":
			dialog.text = "Je ne crois pas que vous irez oם que ce soit ! Donnez-nous la lettre, tout de suite !";
			link.l1 = "Et si on buvait une chope de bière avant de se séparer ? Non ? Je m'en doutais.";
			link.l1.go = "Satanist_zasada2_2";	
		break;
		
		case "Satanist_zasada2_2":
			dialog.text = "Arrêtez de faire le pitre ! Je compte jusqu'à trois, et si vous ne nous donnez pas la lettre, vous ne pourrez vous en prendre qu'à vous-même. Un...";
			link.l1 = "Trois !";
			link.l1.go = "Satanist_zasada2_3";
		break;
		
		case "Satanist_zasada2_3":
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			for (i=1; i<=3; i++)
			{
				sld = CharacterFromID("Satanist_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PKM_SvtvA_Zasada2_Pobeda");
			LAi_SetFightMode(pchar, true);
		break;
		
		case "Сатанист_крыса":
			dialog.text = "Meurs ! Satan arrive ! Tu ne peux pas l'arrêter !";
			link.l1 = "Diable ! Votre assistant est un sataniste !";
			link.l1.go = "Сатанист_крыса_2";
			
			for (i=1; i<=5; i++)
			{
				sld = GetCharacter(NPC_GenerateCharacter("Satanist_"+i, "Animists1", "man", "man", sti(pchar.rank), PIRATE, -1, true));
				sld.SaveItemsForDead = true;
				sld.DontChangeBlade = true;
				sld.DontChangeGun = true;
				sld.DeleteFood = true;
				LAi_SetActorType(sld);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1_back");
				GiveItem2Character(sld, "PKM_SvtvA_znachok");
				AddItems(sld, "mineral3", rand(7)-4);
			}
		break;
		
		case "Сатанист_крыса_2":
			DialogExit();
			
			LAi_LocationFightDisable(loadedLocation, false);
			sld = CharacterFromID("Satanist_Krisa")
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "Satanist");
			for (i=1; i<=5; i++)
			{
				sld = CharacterFromID("Satanist_"+i)
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "Satanist");
			}
			LAi_group_SetRelation("Satanist", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("Satanist", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("Satanist", "PKM_SvtvA_Нападение_в_церкви_Победа");
			LAi_SetFightMode(pchar, true);
			
			DoQuestFunctionDelay("PKM_SvtvA_Malta_na_pomosh", 15.0);
		break;
		
		case "Победа_в Церкви":
			dialog.text = "Qui aurait cru que le père Gareth adorait le Prince des Ténèbres... Qui l'aurait cru...";
			link.l1 = "Mais maintenant, je sais qui m'a causé tant d'ennuis ! C'est lui qui rapportait tous mes déplacements à ces moines.";
			link.l1.go = "Победа_в Церкви_2";
		break;
		
		case "Победа_в Церкви_2":
			dialog.text = "Des moines ?! Non, ce ne sont pas des moines. Ce sont des serviteurs du Diable !";
			link.l1 = "Hum... Mais leur habit...";
			link.l1.go = "Победа_в Церкви_3";
		break;
		
		case "Победа_в Церкви_3":
			dialog.text = "Oui, vous avez raison. Mais d'abord, il faut découvrir oם se trouve le repaire de ces païens. Je pense que le mieux serait que vous alliez à San Juan pour essayer d'y trouver plus d'informations.";
			link.l1 = "Alors, bénissez-moi.";
			link.l1.go = "Победа_в Церкви_4";
		break;
		
		case "Победа_в Церкви_4":
			dialog.text = "Ce n'est pas tout. J'aimerais vous présenter quelqu'un...";
			link.l1 = "";
			link.l1.go = "Победа_в Церкви_5";
		break;
		
		case "Победа_в Церкви_5":
			DialogExit();
			StartInstantDialog("Maltese", "Победа_в Церкви_6", "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c");
		break;
		
		case "Победа_в Церкви_6":
			dialog.text = "Nous nous sommes déjà rencontrés, capitaine "+pchar.name+".";
			link.l1 = "Jacquin ! Comment êtes-vous arrivé ici à temps ! Sans vous, la partie aurait été perdue. Votre aide est tombée à pic.";
			link.l1.go = "Победа_в Церкви_7";
		break;
		
		case "Победа_в Церкви_7":
			dialog.text = "Je suis heureux d'avoir pu vous être utile. Mais passons aux choses sérieuses. Il y a quelques années, j'ai pris part à la défaite des païens en Italie...";
			link.l1 = "Ah, et maintenant, vous êtes venu ici pour finir le travail commencé ?";
			link.l1.go = "Победа_в Церкви_8";
		break;
		
		case "Победа_в Церкви_8":
			dialog.text = "Exactement. Et si vous n'y voyez pas d'inconvénient, je me joins à vous.";
			link.l1 = "Eh bien, vous connaissez l'ennemi de vue, vous savez vous battre, je ne vois aucune raison de refuser.";
			link.l1.go = "Победа_в Церкви_9";
		break;
		
		case "Победа_в Церкви_9":
			dialog.text = "Heureux d'avoir votre accord. Eh bien, donnez vos ordres, capitaine.";
			link.l1 = "Cap sur Porto Rico ! Il nous faut plus d'informations.";
			link.l1.go = "Победа_в Церкви_10";
		break;
		
		case "Победа_в Церкви_10":
			DialogExit();
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			PChar.quest.PKM_SvtvA_MalteseMertv.over = "yes";
		
			sld = CharacterFromID("Maltese");
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true;
			sld.loyality = MAX_LOYALITY;
			AddPassenger(pchar, sld, false);
			SetShipRemovable(sld, true);
			SetCharacterRemovable(sld, true);
			sld.location = "None";
			sld.Dialog.CurrentNode = "hired";
			sld.Payment = true;
			sld.rank = 15;
			LAi_SetHP(sld, 250.0, 250.0);
			sld.HalfImmortal = true;
			sld.HasNoFear = true;		//Не убегает
		
			sld = CharacterFromID("FortFrance_Priest");
			LAi_SetPriestType(sld);
			sld.dialog.filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Победа_в Церкви_11";
			
			sld = CharacterFromID("SanJuan_Priest");
			sld.dialog.filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Падре_Робано";			
			
			PChar.quest.PKM_SvtvA_PriestVernuDialog.win_condition.l1 = "ExitFromLocation";
			PChar.quest.PKM_SvtvA_PriestVernuDialog.win_condition.l1.location = PChar.location;
			PChar.quest.PKM_SvtvA_PriestVernuDialog.win_condition = "PKM_SvtvA_PriestVernuDialog";
			
			pchar.questTemp.PKM_SvtvA_PoiskPadre_Tavern = true;
			
			AddQuestRecord("PKM_Animists", "21");
		break;
		
		case "Победа_в Церкви_11":
			dialog.text = "Ne vous inquiétez pas pour moi, je vais faire le ménage ici. Vous feriez mieux de commencer à chercher le repaire des païens.";
			link.l1 = "Oui, j'y vais.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Победа_в Церкви_11";
		break;
		
		case "Падре_Робано":
			dialog.text = "Le padre Dominguez a été enlevé par d'étranges individus ? Que dois-je faire, que dois-je faire...";
			link.l1 = "Diable ! דa me plaît de moins en moins !";
			link.l1.go = "Падре_Робано_2";
			locCameraFromToPos(2.00, 3.00, -2.00, true, -4.00, -0.20, -12.50);
		break;
		
		case "Падре_Робано_2":
			dialog.text = "Cessez de blasphémer dans la maison du Seigneur !";
			link.l1 = "Vraiment ? Et que va-t-il m'arriver si je dis autre chose ? Par exemple : Bon sang ! Satan !";
			link.l1.go = "Падре_Робано_3";
		break;
		
		case "Падре_Робано_3":
			dialog.text = "";
			link.l1 = "Hein... Qu'est-ce que c'était ?!";
			link.l1.go = "Падре_Робано_4";
			LAi_SetActorType(pchar);
			LAi_ActorAnimation(pchar, "hit_fire", "", 2);
			LAi_SetAfraidDead(pchar);
			DoQuestFunctionDelay("PKM_SvtvA_Gospod_nakazal", 1.15);
			LaunchBlood(pchar, 1.0, true);
			LaunchBlood(pchar, 2.0, true);
			LAi_SetCurHP(pchar, 30.0);
		break;
		
		case "Падре_Робано_4":
			dialog.text = "Un miracle ! C'était un miracle ! Dieu, pour une raison ou une autre, a décidé de vous rappeler son existence de cette façon ! Oh ! Je réciterai vingt fois le « Notre Père » aujourd'hui à ce sujet, et je célébrerai pour vous un office supplémentaire !";
			link.l1 = "Kh-kh. Faites comme vous voulez, moi, je crois que je vais y aller.";
			link.l1.go = "Падре_Робано_5";
		break;
		
		case "Падре_Робано_5":
			DialogExit();
			
			LAi_SetPlayerType(pchar);
			sld = CharacterFromID("SanJuan_Priest");
			sld.dialog.filename = "Common_church.c";
			sld.dialog.currentnode = "First time";
			AddCharacterExpToSkill(pchar, "Leadership", 200);
			AddCharacterExpToSkill(pchar, "Fortune", 200);
		break;
		
		case "Джордано_1":
			dialog.text = "Tu apportes des nouvelles du Maître ? Il a dit qu'il enverrait son homme.";
			link.l1 = "Oui, je viens de la part du Maître, mais tu pourrais peut-être éviter de le crier dans toute la rue, crétin ?";
			link.l1.go = "Джордано_2";
			PlayVoice("Kopcapkz\Voices\Quest\Spa_m_b_001.wav");
		break;
		
		case "Джордано_2":
			dialog.text = "Oh ! De la part du Maître ! Je le savais ! Oh, pardon, bien sמr, je vais parler moins fort. Oם est ton médaillon ?";
			link.l1 = "Ah, tu t'en es souvenu, finalement ; tu sautes comme un chiot, tu avais tout oublié. Le voici, le médaillon.";
			link.l1.go = "Джордано_3";
		break;
		
		case "Джордано_3":
			dialog.text = "Oh ! Je savais que c'était toi ! Alors, je cours prévenir les autres. Quand partons-nous ?";
			link.l1 = "Partir ? Tu sais tout, toi. Tu sais peut-être même oם aller ?";
			link.l1.go = "Джордано_4";
		break;
		
		case "Джордано_4":
			dialog.text = "Non, le Maître ne nous l'a pas dit.";
			link.l1 = "C'est bien : tu n'as pas encore à savoir ce genre de choses, sinon tu irais le crier sur tous les toits. Et oם est le Maître lui-même ? Nous ne partirons nulle part sans lui.";
			link.l1.go = "Джордано_5";
		break;
		
		case "Джордано_5":
			dialog.text = "Il a dit qu'il allait à Port-au-Prince pour quelques jours. Il devait revenir hier, mais il n'est toujours pas là.";
			link.l1 = "וtrange. Alors, je pense que notre voyage est reporté.";
			link.l1.go = "Джордано_6";
		break;		
		
		case "Джордано_6":
			dialog.text = "Comment ? Pourquoi ?";
			link.l1 = "Tu crois vraiment que nous allons partir sans lui ? Je dois d'abord découvrir ce qui lui est arrivé, et c'est seulement ensuite que nous prendrons la route.";
			link.l1.go = "Джордано_7";
		break;
		
		case "Джордано_7":
			DialogExit();
			
			sld = CharacterFromID("PKM_Jordano");
			sld.lifeday = 0;
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "houseF2", "none", "", "", "PKM_SvtvA_IdemSledom", -1);
			
			AddQuestRecord("PKM_Animists", "26");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PKM_Animists", "sSex1", GetSexPhrase("", "e"));
			
			pchar.questTemp.PKM_SvtvA_PoiskUchitel_Tavern = true;
		break;
		
		case "Разговор с тюремщиком":
			dialog.text = "" + TimeGreeting() + ", "+ GetSexPhrase("monsieur", "mademoiselle") +". Que voulez-vous ?";
			link.l1 = "Je dois parler à un prisonnier.";
			link.l1.go = "Разговор с тюремщиком_2";
		break;
		
		case "Разговор с тюремщиком_2":
			dialog.text = "En fait, il nous est interdit de parler aux prisonniers...";
			link.l1 = "Mais permettez ! Je m'occupe d'une affaire d'importance nationale !";
			link.l1.go = "Разговор с тюремщиком_3";
			link.l2 = "(sortant une arme) Vous allez me conduire au prisonnier tout de suite, ou, par Dieu, je vous tue !";
			link.l2.go = "Угроза тюремщику_1";
		break;
		
		case "Разговор с тюремщиком_3":
			dialog.text = "Quelle autre affaire ? De quoi parlez-vous donc ?!";
			if (sti(pchar.reputation) > 80)
			{
				link.l1 = "Vous avez sמrement entendu parler des enlèvements d'enfants, des choses étranges qui se passent dans l'archipel ces derniers temps ? Eh bien, votre prisonnier peut m'aider à tirer tout ça au clair !";
				link.l1.go = "Уговариваем тюремщика_1";
			}
			else
			{
				link.l1 = "Vous avez sמrement entendu parler des enlèvements d'enfants, de...";
				link.l1.go = "Деньги тюремщику_1";
			}
		break;
		
		case "Уговариваем тюремщика_1":
			dialog.text = "Bon, bon, vous m'avez convaincu. Ce qui se passe ne me plaît pas non plus. Vous pouvez parler à ce salaud, de toute façon, il sera pendu cet après-midi.";
			link.l1 = "Parfait ! Merci !";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			NextDiag.TempNode = "Уговариваем тюремщика_2";
			
			AddQuestRecord("PKM_Animists", "30");
			
			sld = CharacterFromID("Satanist_Uchitel");
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Учитель_Спасение";
		break;
		
		case "Уговариваем тюремщика_2":
			dialog.text = "J'espère que vous tirerez de cette ordure toutes les informations dont vous avez besoin.";
			link.l1 = "Merci, officier. Je cherche déjà sa cellule.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Уговариваем тюремщика_2";
		break;
		
		case "Деньги тюремщику_1":
			dialog.text = "Vous perdez votre temps. Quoique... Si vous me rendiez un service...";
			link.l1 = "Quel autre service ?";
			link.l1.go = "Деньги тюремщику_2";
		break;
		
		case "Деньги тюремщику_2":
			dialog.text = "Mon fils se marie bientכt, et j'aimerais fêter ça en grand... Bref, si vous voulez parler à un prisonnier, pour 40 000 piastres, je vous laisserai faire avec plaisir.";
			if (sti(pchar.Money) >= 40000)
			{
				link.l1 = "Voici votre argent.";
				link.l1.go = "Деньги тюремщику_3_да";
			}
			link.l2 = "J'ai bien peur de ne pas avoir le choix... En garde !";
			link.l2.go = "Деньги тюремщику_3_нет";
		break;
		
		case "Деньги тюремщику_3_нет":
			DialogExit();
			pchar.questTemp.jailCanMove = true;
			LAi_group_AttackGroup("FRANCE_CITIZENS", LAI_GROUP_PLAYER);
			LAi_SetFightMode(pchar, true);
		break;
		
		case "Деньги тюремщику_3_да":
			dialog.text = "Bien, vous pouvez parler au prisonnier.";
			link.l1 = "...";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			NextDiag.TempNode = "Деньги тюремщику_4_да";
			
			AddQuestRecord("PKM_Animists", "29");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			
			sld = CharacterFromID("Satanist_Uchitel");
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Учитель_Спасение";
		break;
		
		case "Деньги тюремщику_4_да":
			dialog.text = "Autre chose ?";
			link.l1 = "Non. Je visite juste la prison.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Деньги тюремщику_4_да";
		break;
		
		case "Угроза тюремщику_1":
			dialog.text = "Qu'est-ce que... Vous allez répondre de ça !";
			link.l1 = "Peut-être, mais pour l'instant, c'est vous mon prisonnier. Alors, restez tranquille jusqu'à ce que j'aie libéré le prisonnier.";
			link.l1.go = "exit";
			pchar.questTemp.jailCanMove = true;
			NextDiag.TempNode = "Угроза тюремщику_2";
			
			AddQuestRecord("PKM_Animists", "28");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			ChangeCharacterReputation(pchar, -30);
			ChangeCharacterNationReputation(pchar, FRANCE, -30);
		break;
		
		case "Угроза тюремщику_2":
			dialog.text = "Que voulez-vous encore ?";
			link.l1 = "Rien. Restez tranquille et ne bougez pas.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Угроза тюремщику_2";
		break;
		
		case "Учитель_Смерть":
			dialog.text = "Qu'est-ce que tu me veux ?!";
			link.l1 = "Dis-moi oם est votre repaire, et je te laisserai mourir vite.";
			link.l1.go = "Учитель_Смерть_1";
			PChar.quest.PKM_SvtvA_TuremchikKonets.over = "yes";
		break;
		
		case "Учитель_Смерть_1":
			dialog.text = "Tu essaies de me faire peur ?! Je suis un serviteur des forces du chaos ! Je n'ai pas peur de la mort !";
			link.l1 = "Hum... en effet...";
			link.l1.go = "Учитель_Смерть_2";
		break;
		
		case "Учитель_Смерть_2":
			dialog.text = "Que m'importe la mort ! א moi, qui vais prendre une place digne au pied du trכne de mon maître !";
			link.l1 = "Peut-être que tu n'as pas peur de la mort. Et la perpétuité dans cette cage ?";
			link.l1.go = "Учитель_Смерть_3";
		break;
		
		case "Учитель_Смерть_3":
			dialog.text = "...";
			link.l1 = "Mais c'est encore une cellule assez confortable ; je peux demander qu'on te transfère dans un endroit plus sombre et plus humide.";
			link.l1.go = "Учитель_Смерть_4";
		break;
		
		case "Учитель_Смерть_4":
			dialog.text = "...";
			link.l1 = "De l'eau glacée sur le sol, qui ne laisse pas une minute de repos, la chair qui pourrit... דa sonne bien, bon sang !";
			link.l1.go = "Учитель_Смерть_5";
		break;
		
		case "Учитель_Смерть_5":
			dialog.text = "Attends ! Je vais tout te dire. Qu'est-ce qu'il te faut ?";
			link.l1 = "Oם est votre repaire ?";
			link.l1.go = "Учитель_Смерть_6";
		break;
		
		case "Учитель_Смерть_6":
			dialog.text = "Sur l'île de Marie-Galante, près de...";
			link.l1 = "";
			link.l1.go = "Учитель_Смерть_7";
			npchar.lifeday = 0;
			LAi_SetHP(npchar, 1.0, 1.0);
		break;
		
		case "Учитель_Смерть_7":
			dialog.text = "Kh... noooon... hum...";
			link.l1 = "Qu'est-ce que... ?!";
			link.l1.go = "Учитель_Смерть_8";
			LAi_SetActorType(npchar);
			LAi_ActorAnimation(npchar, "death_citizen_1", "", 2.0);
			DoQuestFunctionDelay("PKM_SvtvA_Uchitel_smert", 2.2);
		break;
		
		case "Учитель_Смерть_8":
			DialogExit();
			
			AddQuestRecord("PKM_Animists", "32");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition.l1 = "ExitFromLocation";  //Выход из локации
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition.l1.location = PChar.location;
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition = "PKM_SvtvA_TuremchikDialog";
				
			locations[FindLocation("Guadeloupe_deadlock")].models.day.charactersPatch = "jungle9_patch";
			locations[FindLocation("Guadeloupe_deadlock")].models.night.charactersPatch = "jungle9_patch";
			Locations[FindLocation("Guadeloupe_deadlock")].models.always.l4 = "jungle9_nowall";
			
			PChar.quest.LogovoSatanistov.win_condition.l1 = "location";
			PChar.quest.LogovoSatanistov.win_condition.l1.location = "Cave_Satanists";
			PChar.quest.LogovoSatanistov.win_condition = "LogovoSatanistov";
		break;
		
		case "Учитель_Спасение":
			dialog.text = "Qu'est-ce que vous me voulez, sales porcs ?!";
			link.l1 = "Nous sommes venus vous libérer.";
			link.l1.go = "Учитель_Спасение_1";
			PChar.quest.PKM_SvtvA_TuremchikKonets.over = "yes";
		break;
		
		case "Учитель_Спасение_1":
			dialog.text = "Comme c'est gentil de votre part. Et pourquoi diable ai-je droit à une telle faveur ?";
			link.l1 = "Pas le temps d'expliquer. א tout moment, on peut découvrir que les papiers de votre libération sont des faux.";
			link.l1.go = "Учитель_Спасение_2";
		break;
		
		case "Учитель_Спасение_2":
			dialog.text = "Vraiment ? Bon. Je vous permets de m'accompagner jusqu'à San Juan, et ensuite, nous déciderons de ce que nous ferons de vous.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "Учитель_Спасение_3";
		break;
		
		case "Учитель_Спасение_3":
			DialogExit();
			
			AddQuestRecord("PKM_Animists", "31");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition.l1 = "ExitFromLocation";  //Выход из локации
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition.l1.location = PChar.location;
			PChar.quest.PKM_SvtvA_TuremchikDialog.win_condition = "PKM_SvtvA_TuremchikDialog";
			
			sld = CharacterFromID("Satanist_Uchitel");
			ChangeCharacterAddressGroup(sld, "PortPax_prison", "goto", "goto23");
			LAi_SetActorType(sld);
			LAi_ActorFollow(sld, pchar, "", -1);
			AddPassenger(pchar, sld, true);
			
			PChar.quest.PKM_SvtvA_UchitelPassakir.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_UchitelPassakir.win_condition.l1.location = "PuertoRico";
			PChar.quest.PKM_SvtvA_UchitelPassakir.win_condition = "PKM_SvtvA_UchitelPassakir";
		break;
		
		case "Обманываем Учителя":
			dialog.text = "Nous sommes presque à San Juan, mais vous n'avez pas eu le temps de faire vos preuves. Vous ne pourriez pas vous rattraper ?";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "Обманываем Учителя_2";
		break;
		
		case "Обманываем Учителя_2":
			dialog.text = "Dans ce cas, dès le débarquement, j'espère vous voir dans l'une des chambres de la taverne.";
			link.l1 = "D'accord.";
			link.l1.go = "Обманываем Учителя_3";
		break;
		
		case "Обманываем Учителя_3":
			DialogExit();
			
			if (GetDaysContinueNationLicence(SPAIN) < 2) GiveUniLicence(2); // universal GWIK trade license
			DoQuestReloadToLocation("SanJuan_tavern_upstairs", "goto", "goto2", "PKM_SvtvA_UchitelvTaverne");
		break;
		
		case "Обманываем Учителя_4":
			dialog.text = "Oui, je vois que vous ne mentez pas, et que vous êtes vraiment lié à notre Confrérie. La version de ce garçon coïncide parfaitement avec la vכtre ; je ne sais pas quand ni oם vous nous avez rejoints, peu importe maintenant ; ce qui compte, c'est que nous devons d'urgence nous rendre à notre refuge, car le moment du rituel est venu. Je pense que vous accepterez de m'escorter, avec quelques-uns des gens d'ici, jusqu'à notre temple ?";
			link.l1 = "Bien sמr. Dites-moi simplement oם nous devons aller.";
			link.l1.go = "Обманываем Учителя_5";
		break;
		
		case "Обманываем Учителя_5":
			dialog.text = "Notre temple se trouve sur l'île de Marie-Galante. C'est là que nous prévoyons de... et...";
			link.l1 = "...Bon, maintenant, j'ai appris tout ce qu'il me fallait. Je crois qu'il est temps pour vous de mourir.";
			link.l1.go = "Обманываем Учителя_6";
		break;
		
		case "Обманываем Учителя_6":
			dialog.text = "Quoi ?! Alors, vous...";
			link.l1 = "Oui, je n'appartiens pas à votre confrérie. Maintenant, défendez-vous !";
			link.l1.go = "Обманываем Учителя_7";
			LAi_group_MoveCharacter(pchar, "PIRATE_CITIZENS");
		break;
		
		case "Обманываем Учителя_7":
			DialogExit();
			
			LAi_SetWarriorType(npchar);
			LAi_group_Attack(characterFromId("Satanist_Uchitel"), Pchar);
			LAi_SetFightMode(pchar, true);
			
			PChar.quest.PKM_SvtvA_UbivaemUchitelya.win_condition.l1 = "NPC_Death";
			PChar.quest.PKM_SvtvA_UbivaemUchitelya.win_condition.l1.character = "Satanist_Uchitel";
			PChar.quest.PKM_SvtvA_UbivaemUchitelya.win_condition = "PKM_SvtvA_UbivaemUchitelya";
		break;
		
		case "Спасите, помогите1":
			dialog.text = "Sauvez-moi ! Sortez-nous d'ici !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Спасите, помогите1";
		break;
		
		case "Спасите, помогите2":
			dialog.text = "Ne nous laissez pas ici ! Je ne veux pas mourir !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Спасите, помогите2";
		break;
		
		case "Спасите, помогите3":
			dialog.text = "Ouvrez la grille ! Je veux sortir d'ici !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Спасите, помогите3";
		break;
		
		case "Домингес в клетке":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +"... C'est vraiment vous ?";
			link.l1 = "Oui, c'est moi, saint père.";
			link.l1.go = "Домингес в клетке_2";
		break;
		
		case "Домингес в клетке_2":
			dialog.text = "On m'a capturé juste après votre départ de San Juan. Mais je suis heureux que vous ayez réussi à trouver le repaire de ces païens sans âme. Leur chef, Soleil Noir, est assis dans la salle du trכne. Vous devez l'arrêter !";
			link.l1 = "Ne vous inquiétez pas, saint père. Je suis justement là pour en finir avec cette secte diabolique.";
			link.l1.go = "Домингес в клетке_3";
		break;
		
		case "Домингес в клетке_3":
			dialog.text = "Dans ce cas, je prierai pour vous !";
			link.l1 = "Je ne vous décevrai pas !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Домингес в клетке_4";
		break;
		
		case "Домингес в клетке_4":
			dialog.text = "Je prierai pour vous !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Домингес в клетке_4";
		break;
		
		case "Лорд_Хаоса_1":
			dialog.text = "Tu vas mourir, et les démons danseront sur tes os, limace !";
			link.l1 = "Eh bien, oui, bien sמr, je vais mourir tout de suite. J'en rêve !";
			link.l1.go = "Лорд_Хаоса_2";
			PlayVoice("Kopcapkz\Voices\Quest\Dark_teacher.wav");
		break;
		
		case "Лорд_Хаоса_2":
			DialogExit();
			
			EndQuestMovie();
			LAi_SetFightMode(pchar, true);
			
			sld = CharacterFromID("Chernoe_Solntse");
			LAi_SetImmortal(sld, false);
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "Chernoe_Solntse");
			ChangeCharacterAddressGroup(sld, "Cave_Satanists", "goto",  "goto57");
			
			for (i=1; i<=2; i++)
			{
				sld = CharacterFromID("Satanist_"+i);
				LAi_SetImmortal(sld, false);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "Chernoe_Solntse");
			}			
			for (i=1; i<=5; i++)
			{
				sld = CharacterFromID("Satanist_Oderjim_"+i);
				LAi_SetImmortal(sld, false);
				LAi_group_MoveCharacter(sld, "Chernoe_Solntse_sluga");
			}
			for (i=1; i<=3; i++)
			{
				sld = CharacterFromID("Satanist_Turma_"+i);
				LAi_SetGuardianType(sld);
				LAi_group_MoveCharacter(sld, "Chernoe_Solntse");
			}
			if (!CheckAttribute(pchar, "questTemp.PKM_SvtvA_Satanist_Kuhnya_Pobeda"))
			{
				for (i=1; i<=5; i++)
				{
					sld = CharacterFromID("Satanist_Kuhnya_"+i);
					LAi_SetHP(sld, 180.0, 180.0);
					LAi_SetWarriorType(sld);
					LAi_group_MoveCharacter(sld, "Chernoe_Solntse");
					LAi_group_SetRelation("Chernoe_Solntse", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
					LAi_group_SetLookRadius("Chernoe_Solntse", 10.0);
					LAi_group_SetHearRadius("Chernoe_Solntse", 3.0);
					LAi_group_SetSayRadius("Chernoe_Solntse", 1.0);
					ChangeCharacterAddressGroup(sld, "Cave_Satanists", "goto",  "goto8");
				}
			}
			
			PChar.quest.PKM_SvtvA_KuhnyaStels1.over = "yes";
			PChar.quest.PKM_SvtvA_KuhnyaStels2.over = "yes";
			PChar.quest.PKM_SvtvA_KuhnyaStels3.over = "yes";
			PChar.quest.PKM_SvtvA_KuhnyaStels4.over = "yes";
			PChar.quest.PKM_SvtvA_KuhnyaStels5.over = "yes";
			
			LAi_group_SetRelation("Chernoe_Solntse", "Chernoe_Solntse_sluga", LAI_GROUP_FRIEND);
			LAi_group_SetRelation("Chernoe_Solntse_sluga", "Chernoe_Solntse", LAI_GROUP_FRIEND);
			
			LAi_group_SetRelation("Chernoe_Solntse", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("Chernoe_Solntse", LAI_GROUP_PLAYER, true);
			
			//LAi_group_SetRelation("Chernoe_Solntse_sluga", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			//LAi_group_FightGroups("Chernoe_Solntse_sluga", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("Chernoe_Solntse_sluga", "PKM_SvtvA_Lord_Haos_Padet");
		break;
		
		case "Лорд_Хаоса_3":
			dialog.text = "Non ! Ce n'est pas possible !..";
			link.l1 = "Quoi ? Tu ne t'attendais pas à ce que quelqu'un mette ton sinistre repaire en pièces ?";
			link.l1.go = "Лорд_Хаоса_4";
			
			sld = CharacterFromID("Satanist_Oderjim_1");
			sld.lifeday = 0;
			ChangeCharacterAddressGroup(sld, "none", "", "");
			sld = CharacterFromID("Satanist_Oderjim_2");
			sld.lifeday = 0;
			ChangeCharacterAddressGroup(sld, "none", "", "");
			sld = CharacterFromID("Satanist_Oderjim_3");
			sld.lifeday = 0;
			ChangeCharacterAddressGroup(sld, "none", "", "");
			sld = CharacterFromID("Satanist_Oderjim_4");
			sld.lifeday = 0;
			ChangeCharacterAddressGroup(sld, "none", "", "");
			sld = CharacterFromID("Satanist_Oderjim_5");
			sld.lifeday = 0;
			ChangeCharacterAddressGroup(sld, "none", "", "");
		break;
		
		case "Лорд_Хаоса_4":
			dialog.text = "Ce n'est pas encore fini...";
			link.l1 = "";
			link.l1.go = "Лорд_Хаоса_5";
		break;
		
		case "Лорд_Хаоса_5":
			dialog.text = "";
			link.l1 = "Hé, oם tu vas ? Lâche !";
			link.l1.go = "exit";
			
			sld = CharacterFromID("Chernoe_Solntse");
			sld.lifeday = 0;
			LAi_SetActorType(sld);
			LAi_ActorRunToLocation(sld, "goto", "goto28", "none", "", "", "PKM_SvtvA_Lord_Haos_Pobeda_no_ne_sovsem2", 4);
		break;
		
		case "Спасение пленников":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", avons-nous gagné ?";
			link.l1 = "Il ne reste rien de leur repaire, saint père, mais leur chef a réussi à s'enfuir...";
			link.l1.go = "Спасение пленников_2";
		break;
		case "Спасение пленников_2":
			dialog.text = "Ce n'est rien, "+ GetSexPhrase("mon fils", "ma fille") +". Pendant que vous combattiez ces démons, j'ai réussi à libérer tous les civils.";
			link.l1 = "Parfait ! Mon navire, le « " + PChar.Ship.Name + " », est dans la baie, emmenez-les à bord. Je vous suis, et je m'assurerai que pas une seule de ces créatures ne s'échappe. Allez-y !";
			link.l1.go = "Спасение пленников_3";
		break;
		
		case "Спасение пленников_3":
			DialogExit();
			AddQuestRecord("PKM_Animists", "34");
			sld = CharacterFromID("Plennik_Dominges");
			LAi_ActorRunToLocation(sld, "reload", "reload1_back", "none", "", "", "PKM_SvtvA_Dominges_na_bort", -1);
		break;
		
		case "Домингес_спасён_1":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", enfin, toutes ces horreurs sont derrière nous. Vous ne pouvez même pas imaginer quel malheur vous avez évité.";
			link.l1 = "Vous dites ça comme s'ils avaient voulu ouvrir un portail vers l'enfer d'oם serait sortie une immense armée d'esprits maléfiques.";
			link.l1.go = "Домингес_спасён_2";
		break;
		
		case "Домингес_спасён_2":
			dialog.text = "J'ai peur d'imaginer ce qui serait arrivé s'ils avaient eu le temps d'accomplir leur rite démoniaque. Mais ça n'a plus d'importance. Je vais aller maintenant à l'office, et je remercierai le Seigneur Dieu pour l'aide qu'il vous a apportée dans cette bataille sacrée.";
			link.l1 = "Adieu, saint père. Ce fut un honneur pour moi de servir la Lumière.";
			link.l1.go = "Домингес_спасён_3";
		break;
		
		case "Домингес_спасён_3":
			DialogExit();
			AddCharacterExpToSkill(pchar, "Leadership", 50);
			AddCharacterExpToSkill(pchar, "Sailing", 150);
			sld = CharacterFromID("Plennik_Dominges");
			sld.lifeday = 0;
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "reload7", "none", "", "", "", -1);
			
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			
			sld = CharacterFromID("SanJuan_Priest");
			sld.name		= "Padre Dominguez";
			sld.lastname = "";
			sld.dialog.filename = "Common_church.c";
			sld.dialog.currentnode = "First time";
			
			AddQuestRecord("PKM_Animists", "40");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PKM_Animists_PadreDominges = true;
			if (CheckAttribute(pchar, "questTemp.PKM_Animists_MamaDeti") && CheckAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo") && CheckAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon") && CheckAttribute(pchar, "questTemp.PKM_Animists_PadreDominges"))
			{
				CloseQuestHeader("PKM_Animists");
				pchar.questdata.Satanisty = 1;
				UnlockAchievement("AchStrannyeDela", 3);
				DeleteAttribute(pchar, "questTemp.PKM_Animists_MamaDeti");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_PadreDominges");
			}
		break;
		
		case "Verni_detey_11":
			dialog.text = "Vous êtes de retour ? Oם sont nos petits ?";
			link.l1 = "Vos enfants sont sains et saufs. On les ramène à terre depuis mon navire en ce moment même.";
			link.l1.go = "Verni_detey_12";
		break;
		
		case "Verni_detey_12":
			dialog.text = "Oh ! Merci, merci, "+GetSexPhrase("bon monsieur ", "brave fille ")+" !";
			link.l1 = "Je vous en prie.";
			link.l1.go = "Verni_detey_13";
		break;
		
		case "Verni_detey_13":
			DialogExit();
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			ChangeCharacterReputation(pchar, 12);
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_1")
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
			LAi_SetCitizenType(sld);
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_2")
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
			LAi_SetCitizenType(sld);
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_3")
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
			LAi_SetCitizenType(sld);
			
			AddQuestRecord("PKM_Animists", "37");
			pchar.questTemp.PKM_Animists_MamaDeti = true;
			if (CheckAttribute(pchar, "questTemp.PKM_Animists_MamaDeti") && CheckAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo") && CheckAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon") && CheckAttribute(pchar, "questTemp.PKM_Animists_PadreDominges"))
			{
				CloseQuestHeader("PKM_Animists");
				pchar.questdata.Satanisty = 1;
				UnlockAchievement("AchStrannyeDela", 3);
				DeleteAttribute(pchar, "questTemp.PKM_Animists_MamaDeti");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_PadreDominges");
			}
		break;
		
	}
}
