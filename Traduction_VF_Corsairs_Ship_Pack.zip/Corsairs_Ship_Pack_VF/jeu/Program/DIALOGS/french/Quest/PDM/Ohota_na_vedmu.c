
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);						// 						АВТОРЫ И БЛАГОДАРНОСТИ
	makearef(Link, Dialog.Links);						// Оригинальная идея квеста				    			 - Акелла
	makearef(NextDiag, NPChar.Dialog);					// Написанный с нуля код и переосмысление квеста 	 	 - Sinistra
														// Новая модель и текстура для "Witches" 				 - Domovoy
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First_time":
			dialog.text = "Mes salutations, "+ GetSexPhrase("sir", "lady")+". Je m'appelle Bartholomew Ulster. Au fait, avez-vous vu Maria Carle, la fille de la taverne ? Elle a disparu quelque part...";
			link.l1 = "Non, je ne sais pas qui elle est, et encore moins oם elle est. Mais vous avez un accent anglais : dites-moi, comment êtes-vous arrivé ici ?";
			link.l1.go = "Bartolom";
			link.l2 = "Je ne sais pas. Vous devriez peut-être regarder à la taverne, ce serait logique.";
			link.l2.go = "exit";
			NextDiag.TempNode = "First_time";
			PlayVoice("Kopcapkz\Voices\Queste_videli_Mariu.wav");
			UnmarkCharacter(npchar);
		break;

		case "Bartolom":
			dialog.text = "Pardonnez-moi, mais je ne peux pas vous parler maintenant. Je dois retrouver Maria !";
			link.l1 = "Dans ce cas, à plus tard.";
			link.l1.go = "PoraVTavernu";
		break;

		case "PoraVTavernu":
			SetQuestHeader("PDM_Ohota_na_vedmu");
			AddQuestRecord("PDM_Ohota_na_vedmu", "1");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

			sld = CharacterFromID("PDM_Isp_sekr_guber");
			sld.lifeday = 0;
			LAi_SetActorType(sld);
			LAi_ActorGoToLocator(sld, "reload", "reload3_back", "PDM_ONV_BARTO_Ischezni", -1);

			sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Carla", "Witch", "woman", "woman", 10, SPAIN, -1, false));
			LAi_SetImmortal(sld, true);
			sld.name = "Maria";
			sld.lastname = "Carle";
			sld.city = "Beliz";
			ChangeCharacterAddressGroup(sld, "Beliz_tavern", "waitress", "stay2");
			LAi_SetWaitressType(sld);
			sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
			sld.dialog.currentnode   = "First_Carla_1";
			
			sld = CharacterFromID("Beliz_waitress");
			sld.model	= "girl_6";			

			DialogExit();
		break;

		case "First_Carla_1":
			dialog.text = "Que cherchez-vous ici, "+ GetSexPhrase("beau gosse", "ma belle")+" ? Du plaisir, je suppose ? Je m'appelle Maria Carle, ou Maria la Joyeuse, comme m'appellent la plupart des hommes de cette ville. Et vous, comment vous appelez-vous, "+ GetSexPhrase("señor", "señorita")+" ?";
			link.l1 = "Vous pouvez m'appeler "+pchar.name+", ma chère. Mais je suppose qu'il y a un autre homme en ville qui cherche du plaisir. Je l'ai vu sur la place : il a l'air de ne pas tenir en place à l'idée de vous rencontrer.";
			link.l1.go = "First_Carla_2";
			PlayVoice("Kopcapkz\Voices\PDM\Spain\Catalina.wav");
		break;

		case "First_Carla_2":
			dialog.text = "Quoi ? Bartholomew ? Mais je croyais qu'il était... Oh, peu importe... Vous savez quoi, "+ GetSexPhrase("beau gosse", "ma belle")+" – je viens de me rappeler que je suis un peu occupée aujourd'hui. Mais nous ferons tout ce que nous voudrons une autre fois, quand je serai plus disponible. Vous avez de très jolies jambes, au fait.";
			link.l1 = "Euh... Merci. Je repasserai sans doute plus tard.";
			link.l1.go = "First_Carla_Uhodit";
		break;

		case "First_Carla_Uhodit":
			AddQuestRecord("PDM_Ohota_na_vedmu", "2");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

			//bDisableFastReload = true;
			LocatorReloadEnterDisable("Beliz_town", "reload3_back", true);
			LocatorReloadEnterDisable("Beliz_town", "reloadR1", true);
			LocatorReloadEnterDisable("Beliz_TownhallRoom", "reload1", true);
			LocatorReloadEnterDisable("Beliz_TownhallRoom", "reload2", true);
			LocatorReloadEnterDisable("Beliz_TownhallRoom", "reload3", true);
			LocatorReloadEnterDisable("Beliz_townhall", "reload2", true);
			LocatorReloadEnterDisable("Beliz_townhall", "reload1_back", true);

			sld = CharacterFromID("PDM_ONV_Carla");
			LAi_SetActorType(sld);
			sld.lifeday = 0;
			LAi_ActorRunToLocator(sld, "reload", "reload1_back", "PDM_ONV_Clara_Ischezni", -1);

			sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Sin", "SpaOfficer1", "man", "man", 100, SPAIN, -1, false));
			sld.name = "Sinistra";
			sld.lastname = "";
			sld.greeting = "GR_Spainguard";
			sld.city = "Beliz";
			FantomMakeCoolFighter(sld, 100, 100, 100, "blade27", "pistol6", 0);
			LAi_SetHP(sld, 1.0, 1.0);
			LAi_SetImmortal(sld, false);
			ChangeCharacterAddressGroup(sld, "Beliz_town", "reload", "reload3_back");
			LAi_SetGuardianType(sld);
			LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
			sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
			sld.dialog.currentnode   = "OfficerGuard";
			
			PChar.quest.PDM_ONV_Vkomnate.win_condition.l1 = "location";
			PChar.quest.PDM_ONV_Vkomnate.win_condition.l1.location = "Beliz_TownhallRoom";
			PChar.quest.PDM_ONV_Vkomnate.win_condition = "PDM_ONV_Vkomnate";

			PChar.quest.PDM_ONV_Vzaimno.win_condition.l1 = "NPC_Death";
			PChar.quest.PDM_ONV_Vzaimno.win_condition.l1.character = "PDM_ONV_Sin";
			PChar.quest.PDM_ONV_Vzaimno.win_condition = "PDM_ONV_Vzaimno";

			DialogExit();
		break;

		case "OfficerGuard":
			dialog.text = "Désolé, "+ GetSexPhrase("señor", "señorita")+", mais je ne dois laisser entrer personne.";
			link.l1 = "Comme vous voudrez, officier. Au revoir !";
			link.l1.go = "OfficerGuard_Cod";
			NextDiag.TempNode = "OfficerGuard_Again";
		break;

		case "OfficerGuard_Cod":
			AddQuestRecord("PDM_Ohota_na_vedmu", "3");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));
			LocatorReloadEnterDisable("Beliz_town", "reloadR1", false);

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "OfficerGuard_Again":
			dialog.text = "Désolé, "+ GetSexPhrase("señor", "señorita")+", mais je ne dois laisser entrer personne.";
			link.l1 = "Comme vous voudrez, officier. Au revoir !";
			link.l1.go = "exit";
			NextDiag.TempNode = "OfficerGuard_Again";
		break;

		case "Soldat15":
			dialog.text = ""+ GetSexPhrase("Señor", "Señorita")+", veuillez parler au gouverneur.";
			link.l1 = "Merci, soldat, c'est ce que je vais faire.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Soldat15";
		break;

		case "RazgovorSGuberom":
			dialog.text = "";
			link.l1 = "Señor gouverneur ! Pardonnez-moi cette intrusion, mais j'ai remarqué une activité suspecte dans votre résidence et j'ai voulu en avoir le cœur net. Dans l'une des pièces, j'ai trouvé le cadavre...";
			link.l1.go = "RazgovorSGuberom_2";
			locations[FindLocation("Beliz_TownhallRoom")].id.label = "TownhallRoom";	//возвращает работников в спальни
		break;

		case "RazgovorSGuberom_2":
			dialog.text = "Il se passe des choses étranges ici, capitaine. Mon bras droit, mon secrétaire, a été retrouvé mort dans sa chambre. Quelqu'un l'a étranglé dans son lit, ses mains étaient crispées sur sa gorge et ses yeux exorbités. Mais il n'y a aucune trace de corde ou de doigts sur son cou. Je ne sais pas ce que tout cela signifie. C'est une terrible tragédie.";
			link.l1 = "Quelle étrange histoire. Mais comment se fait-il qu'un Anglais soit devenu votre secrétaire ?";
			link.l1.go = "RazgovorSGuberom_3";
		break;

		case "RazgovorSGuberom_3":
			dialog.text = "(s'adressant aux gardes) Laissez-nous.";
			link.l1 = "";
			link.l1.go = "RazgovorSGuberom_4";
		break;

		case "RazgovorSGuberom_4":
			dialog.text = "Le gouvernement anglais l'a exilé. On a porté contre lui de fausses accusations. C'était un homme très noble, d'un caractère merveilleux. Nous nous sommes rencontrés il y a quinze ans en Europe. Il était alors un jeune diplomate, et nous nous sommes connus à la cour. L'un de mes agents l'a croisé à Port Royal. Il avait été jeté à la rue après avoir été accusé de détournement de fonds. Déchu de son titre, il a accepté de devenir mon secrétaire.";
			link.l1 = "Je crois que je l'ai rencontré. Bartholomew, dites-vous ? Il me semble qu'il cherchait sur la place une fille de la taverne, Maria Carle.";
			link.l1.go = "RazgovorSGuberom_5";
			sld = CharacterFromID("PDM_ONV_SoldatGub_1");
			LAi_SetActorType(sld);
			sld.lifeday = 0;
			LAi_ActorGoToLocator(sld, "goto", "goto3", "PDM_ONV_STRAJIschezni", 3);
			sld = CharacterFromID("PDM_ONV_SoldatGub_2");
			LAi_SetActorType(sld);
			sld.lifeday = 0;
			LAi_ActorGoToLocator(sld, "goto", "goto3", "PDM_ONV_STRAJIschezni", 3);
		break;

		case "RazgovorSGuberom_5":
			dialog.text = "La fille de la taverne ? C'est très étrange. C'était un homme noble, comme je l'ai dit, il ne pouvait rien avoir en commun avec une femme d'une telle réputation.";
			link.l1 = "Señor gouverneur, que pensez-vous de sa mort ? Qui aurait pu le tuer ?";
			link.l1.go = "RazgovorSGuberom_6";
		break;

		case "RazgovorSGuberom_6":
			dialog.text = "Ce sont des intrigues des ennemis de la couronne d'Espagne, je suppose. Mais je ne peux nommer personne en particulier...";
			link.l1 = "J'espère, señor gouverneur, que ce mystère pourra être résolu. Mais j'ai des affaires importantes à régler, et si vous le permettez, je vais y aller.";
			link.l1.go = "RazgovorSGuberom_6_1";
		break;

		case "RazgovorSGuberom_6_1":
			DialogExit();
			LAi_SetActorType(pchar);
			LAi_ActorGoToLocator(pchar, "officers", "reload1_2", "", -1);
			DoQuestFunctionDelay("PDM_ONV_NaRabotu", 2.6);
		break;

		case "RazgovorSGuberom_7":
			dialog.text = "En fait, oui, "+ GetSexPhrase("señor", "señorita")+" "+pchar.name+". Vous avez dit que ce pauvre Bartholomew cherchait une fille de la taverne nommée Maria Carle, n'est-ce pas ? Ne voudriez-vous pas me l'amener ? Je pourrais l'envoyer chercher, mais cela provoquerait une vague de rumeurs. Vous pourriez peut-être traiter cette affaire plus délicatement. J'ai décidé de prendre l'enquête sous mon contrכle personnel.";
			link.l1 = "D'accord, señor gouverneur, si je la trouve, je vous l'amènerai, bien sמr.";
			link.l1.go = "RazgovorSGuberom_COD";
			link.l2 = "Pardon, mais ce travail n'est pas pour moi.";
			link.l2.go = "OtkazOtZadaniya";
			NextDiag.TempNode = "RazgovorSGuberom_Again";
		break;
		
		case "OtkazOtZadaniya":
			dialog.text = "C'est dommage, alors je n'ose pas vous retenir.";
			link.l1 = "Au revoir !";
			link.l1.go = "OtkazOtZadaniya_2";
			NextDiag.TempNode = "RazgovorSGuberom_AgainOtkaz";
		break;
		
		case "OtkazOtZadaniya_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			
			LocatorReloadEnterDisable("Beliz_Townhall", "reload1_back", false);
			LocatorReloadEnterDisable("Beliz_Townhall", "reload3", true);
			PChar.quest.PDM_ONV_VernutBezZadaniya.win_condition.l1 = "location";
			PChar.quest.PDM_ONV_VernutBezZadaniya.win_condition.l1.location = "Beliz_town";
			PChar.quest.PDM_ONV_VernutBezZadaniya.win_condition = "PDM_ONV_VernutBezZadaniya";
			CloseQuestHeader("PDM_Ohota_na_vedmu");			
			pchar.questdata.OhotaNaVedmu = 1;			
			sld = CharacterFromID("PDM_ONV_Sin");
			ChangeCharacterAddressGroup(sld, "none", "", "");
		break;
		
		case "RazgovorSGuberom_AgainOtkaz":
			dialog.text = "Je vais vous demander de quitter mon bureau, j'ai beaucoup de travail.";
			link.l1 = "Je m'en vais déjà.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RazgovorSGuberom_AgainOtkaz";
		break;

		case "RazgovorSGuberom_Again":
			dialog.text = "Je vous ai déjà confié une tâche, "+ GetSexPhrase("señor", "señorita")+". Que vouliez-vous me demander d'autre ?";
			link.l1 = "J'ai oublié, señor gouverneur. Je pars à la recherche de la fille Maria. Au revoir !";
			link.l1.go = "exit";
			NextDiag.TempNode = "RazgovorSGuberom_Again";
		break;

		case "RazgovorSGuberom_COD":
			LocatorReloadEnterDisable("Beliz_Townhall", "reload1_back", false);
			LocatorReloadEnterDisable("Beliz_Townhall", "reload3", true);

			PChar.quest.PDM_ONV_SVOBODA_URA.win_condition.l1 = "location";
			PChar.quest.PDM_ONV_SVOBODA_URA.win_condition.l1.location = "Beliz_town";
			PChar.quest.PDM_ONV_SVOBODA_URA.win_condition = "PDM_ONV_SVOBODA_URA";

			AddQuestRecord("PDM_Ohota_na_vedmu", "5");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex2", GetSexPhrase("", "e"));
			sld = CharacterFromID("PDM_ONV_Sin");
			ChangeCharacterAddressGroup(sld, "none", "", "");

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "RazgovorSViktorom_1":
			dialog.text = "Qui es-tu, "+ GetSexPhrase("le gars", "la fille")+" ? Et qu'est-ce que tu veux, bon sang ?";
			link.l1 = "Je pensais que tu étais un marchand qui aurait besoin d'une escorte... Mais on dirait que je fais erreur.";
			link.l1.go = "RazgovorSViktorom_2";
			PlayVoice("Kopcapkz\Voices\PDM\Gavrila Dubinin.wav");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_PortoBello");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_SanJuan");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Maracaibo");
			UnmarkCharacter(npchar);
		break;

		case "RazgovorSViktorom_2":
			dialog.text = "Oui, "+ GetSexPhrase("l'ami, tu fais erreur", "ma belle, tu fais erreur")+". Je suis Silino Sav, un maître d'équipage sans emploi. Hier, un idiot sans cervelle m'a proposé un travail de bמcheron. Tu sais ce qui lui est arrivé ?";
			link.l1 = "Je vois... Mais asseyons-nous devant une chope de rhum, et tu me raconteras ton histoire.";
			link.l1.go = "RazgovorSViktorom_3";
		break;

		case "RazgovorSViktorom_3":
			ChangeCharacterAddressGroup(pchar, PChar.location, "sit", "sit_front2");
			LAi_SetSitType(pchar);
			LAi_SetSitType(npchar);
			locCameraTarget(PChar)
            locCameraFollow();
			dialog.text = "Je vais te raconter ce qui m'est arrivé, mais ce n'est pas un joli conte qu'on raconte aux enfants. Tout est arrivé à cause de cette maudite sorcière que le capitaine a ramassée à La Havane. Je te le dis, s'il ne s'était pas acoquiné avec cette sorcière, il serait encore en vie. Mais il a toujours été trop têtu. Il aurait pu avoir raison du diable lui-même dans une dispute, notre bon vieux Miguel\n"+
							"Mais après que cette femme est montée à bord, il a changé. Oui, il a changé. Il s'est desséché comme un hareng saur. Nous lui avions dit de ne pas emmener cette femme : chez les marins, on dit qu'une femme à bord, ça porte malheur... Quand il y a une femme à bord, attends-toi à des ennuis\n"+
							"Et à cause de cette Maria Carle...";
			link.l1 = "Attends ! Tu as dit qu'elle s'appelait Maria Carle ? Cette femme est recherchée par le gouverneur de Belize. Il pense qu'elle pourrait être mêlée au meurtre !";
			link.l1.go = "RazgovorSViktorom_4";
		break;

		case "RazgovorSViktorom_4":
			dialog.text = "Oui, le gouverneur a raison. Cette maudite sorcière a tué notre capitaine. Il était mort comme une morue quand nous avons atteint Santiago. Nous venions d'entrer au port quand nous l'avons trouvé mort sur le pont. Nous nous sommes précipités pour chercher la sorcière maudite, mais elle avait mystérieusement disparu. Et maintenant, je suis un maître d'équipage sans emploi. Ce gourdin de second a exécuté à la lettre les dernières volontés du capitaine : il a vendu notre rafiot et donné tout l'argent à l'וglise.";
			link.l1 = "Quelle créature infernale que cette femme ! Elle a déjà tué deux personnes. Il faut l'arrêter.";
			link.l1.go = "RazgovorSViktorom_5";
		break;

		case "RazgovorSViktorom_5":
			dialog.text = "Bonne chance, capitaine, pour la retrouver !";
			link.l1 = "Je la retrouverai sans faute. א plus tard !";
			link.l1.go = "RazgovorSViktorom_COD";
			NextDiag.TempNode = "RazgovorSViktorom_Again";
		break;

		case "RazgovorSViktorom_COD":
			sld = CharacterFromID("PDM_ONV_Viktor_Martos");
			sld.lifeday = 0;

			AddQuestRecord("PDM_Ohota_na_vedmu", "11");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

			ChangeCharacterAddressGroup(pchar, PChar.location, "tables", "stay2");
			LAi_SetPlayerType(pchar);
			locCameraTarget(PChar)
            locCameraFollow();

			sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Carla", "Witch", "woman", "woman", 10, SPAIN, -1, false));
			sld.city = "Santiago";
			ChangeCharacterAddressGroup(sld, "Santiago_tavern", "goto", "goto4");
			LAi_SetWaitressType(sld);
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
			sld.name = "Maria";
			sld.lastname = "Carle";
			sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
			sld.dialog.currentnode   = "Carla_Final_1";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "RazgovorSViktorom_Again":
			dialog.text = "Bonne chance, capitaine, pour la retrouver !";
			link.l1 = "Je la retrouverai sans faute. א plus tard !";
			link.l1.go = "exit";
			NextDiag.TempNode = "RazgovorSViktorom_Again";
		break;

		case "Carla_Final_1":
			dialog.text = "Oh, mon cher ! Que faites-vous ce soir ? Ou tout de suite ?";
			link.l1 = "Sorcière effrontée ! Tu te permets de poursuivre tes pratiques impies et de pousser d'honnêtes Espagnols à servir le diable !? On m'a ordonné de te traduire en justice !";
			link.l1.go = "Carla_Final_2";
			PlayVoice("Kopcapkz\Voices\PDM\Carla.wav");
		break;

		case "Carla_Final_2":
			dialog.text = "Qu-quoi, que dites-vous, "+ GetSexPhrase("señor", "señorita")+" ? Je ne sais rien de ces crimes.";
			link.l1 = "Tu crois pouvoir prouver ton innocence en niant l'évidence ? J'ai un témoin : le maître d'équipage Silino Sav. Il est prêt à témoigner que tu es une sorcière.";
			link.l1.go = "Carla_Final_5";
			link.l2 = "J'ai un témoin : le maître d'équipage Silino Sav. Miguel Cuenda est mort sur son navire près de Santiago ! Et nous découvrirons quel rכle répugnant ta sorcellerie a joué dans la terrible mort de Bartholomew Ulster à La Havane. Et... Non, j'ai changé d'avis. Je vais te faire rendre justice ici même, dans cette ville. L'Inquisition m'écoutera, et mes paroles suffiront à te punir.";
			link.l2.go = "NaKoster_2";
		break;

		case "Carla_Final_5":
			dialog.text = "Je sais que la mort de Miguel est ma faute... Mais je n'ai rien pu faire : je devais me débarrasser de ce salaud de Bartholomew. Mais quand il a fini par prononcer sa malédiction, j'ai compris que c'était fini. Miguel était condamné. Je l'aimais...";
			link.l1 = "Attends. Je n'ai rien compris. Quelle malédiction ? Tu aimais qui ?";
			link.l1.go = "Carla_Final_6";
		break;

		case "Carla_Final_6":
			dialog.text = "Bartholomew Ulster a jeté un sort de mort sur Miguel. J'ai essayé de sauver Miguel pendant tout le trajet jusqu'à Santiago, mais... En vain. Mes forces ne suffisaient tout simplement pas à dissiper sa puissante magie. Je n'étais qu'une élève qui n'était pas destinée à surpasser le maître.";
			link.l1 = "Donc, tu avoues que tu es une sorcière ?";
			link.l1.go = "Carla_Final_7";
		break;

		case "Carla_Final_7":
			dialog.text = "Oui. Bartholomew Ulster était mon mentor dans l'art de la divination. Il a remarqué ce Don en moi quand je n'avais que quatorze ans. J'étais alors une fille sotte qui ne comprenait pas ce qu'elle faisait. Je n'étais pas jolie, mais il m'a appris à conquérir le cœur des hommes, et je suis devenue une prostituée de bas étage. Il se servait de moi pour soutirer des secrets aux clients, il m'a fait subir toutes les humiliations imaginables. Je ne pouvais tout simplement plus vivre : il était trop fort..\n"+
							"Mais quand j'ai rencontré Miguel, j'ai cru que j'avais une chance... Je suis tombée amoureuse de ce brave capitaine... mais Bartholomew a dit que si j'essayais de m'enfuir, il dirait aux prêtres que j'étais une sorcière et qu'ils me brמleraient sur le bמcher. J'ai tout raconté à Miguel. Et il a décidé que nous devions tuer Ulster. Mon Don était trop faible pour s'en charger par la magie, et je ne suis qu'une faible femme. Mais Miguel m'a donné la foi.";
			link.l1 = "Mais comment avez-vous passé les gardes ?";
			link.l1.go = "Carla_Final_8";
		break;

		case "Carla_Final_8":
			dialog.text = "C'était le plus simple. J'ai versé une potion de sommeil dans leur boisson... et ils se sont endormis comme des bébés. Ensuite, nous nous sommes glissés dans la chambre de ce monstre à visage humain. Mais il ne dormait pas, comme nous l'avions espéré. Je pense qu'il avait mis sur la porte une formule de garde qui l'a réveillé. Miguel s'est jeté sur lui, mais le salaud a réussi à se servir de la magie. Blessé, Miguel s'est battu contre le sorcier et a fini par l'étouffer avec un oreiller\n"+
							"J'ai essayé de sauver Miguel pendant tout le trajet jusqu'à Santiago. Mais quand il est tombé mort sur le pont, j'ai dמ m'enfuir du navire. L'équipage était furieux : j'étais la seule femme à bord, et le capitaine ne laissait personne me toucher du bout du doigt. Pendant la traversée, ils étaient devenus enragés comme une meute de chiens sauvages.";
			link.l1 = "Et ensuite, que s'est-il passé ?";
			link.l1.go = "Carla_Final_10";
		break;

		case "Carla_Final_10":
			dialog.text = "Je ne savais pas quoi faire. Tout ce que je voulais, c'était fuir mon passé. Quand je suis arrivée ici, je n'avais pas d'argent, et je suis retournée à la seule chose que je connaisse...";
			link.l1 = "La seule chose qui compte dans tout ça, c'est que tu es une sorcière. C'est pourquoi je vais te livrer à l'Inquisition.";
			link.l1.go = "NaKoster_2";
			link.l2 = "Je ne pense pas que tu aies commis de crime, Maria. Tu es libre.";
			link.l2.go = "Carla_Final_11";
		break;

		case "Carla_Final_11":
			dialog.text = "Oh, "+ GetSexPhrase("señor", "señorita")+" – vous êtes très noble. Je vais vous dire une chose. Tout le monde croit que la sorcellerie est une occupation qui déplaît à Dieu. Mais moi, je vous dis que ce n'est qu'un Don, ou un Talent, comme un autre...";
			link.l1 = "";
			link.l1.go = "Carla_Final_12";
		break;

		case "NaKoster_2":
			dialog.text = "Comme vous voudrez, "+ GetSexPhrase("señor", "señorita")+". Ma vie ne signifie plus rien pour moi : je n'ai pas connu la pitié, je n'ai pas obtenu l'amour ; il serait étrange de compter sur la justice.";
			link.l1 = "N'essaie pas de m'attendrir, maudite sorcière ! Tu brמleras sur le bמcher !";
			link.l1.go = "NaKoster_COD";
			NextDiag.TempNode = "NaKoster_Again";
		break;

		case "Carla_Final_12":
			dialog.text = "Et acceptez mon présent. La chance vous accompagnera à partir de ce jour.";
			link.l1 = "Je te souhaite bonne chance, Maria ! א plus tard.";
			link.l1.go = "Dobro_Final";
			NextDiag.TempNode = "Carla_Final_Again";
			LAi_SetHP(pchar,LAi_GetCharacterMaxHP(pchar)+40,LAi_GetCharacterMaxHP(pchar)+40);
			PlaySound("Interfaceew_level.wav");
			Log_info("La sorcière vous a jeté un sort.");
			Log_info("Votre santé a augmenté de 40 pour toujours.");
		break;

		case "Dobro_Final":
			AddQuestRecord("PDM_Ohota_na_vedmu", "12");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Ohota_na_vedmu");
			pchar.questdata.OhotaNaVedmu = 1;
			ChangeCharacterReputation(pchar, 3);
			AddCharacterExpToSkill(pchar, "Fortune", 300);

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Carla_Final_Again":
			dialog.text = "Merci, "+ GetSexPhrase("bon señor", "bonne señorita")+" ! Je n'oublierai pas votre générosité !";
			link.l1 = "Bonne chance à toi, Maria !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Carla_Final_Again";
			PlayVoice("Kopcapkz\Voices\PDM\Carla.wav");
		break;

		case "NaKoster_COD":
			pchar.questTemp.PDM_ONV_OhotaNaVedmu = true;

			AddQuestRecord("PDM_Ohota_na_vedmu", "13");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NaKoster_Again":
			dialog.text = "Ma vie ne vaut plus rien... Mais je ne passerai pas une seule minute du temps qu'il me reste à vous parler.";
			link.l1 = "Tu brמleras sur le bמcher, ignoble sorcière !";
			link.l1.go = "exit";
			NextDiag.TempNode = "NaKoster_Again";
		break;

		case "Inqizitor_1":
			dialog.text = "... cette ville est embourbée dans le péché ! Mais bientכt, nous délivrerons les gens des sombres filets de Satan par le feu et la volonté de notre Seigneur ! Euh... que voulez-vous, "+ GetSexPhrase("mon fils", "ma fille") +" ?";
			link.l1 = "Saint père, je sais qu'il y a ici une sorcière nommée Maria, une ancienne prostituée du port. Par son art ténébreux, elle a déjà tué deux personnes : le capitaine Miguel Cuenda, et le bon hidalgo Bartholomew, mort avant d'avoir pu se repentir. Il était au service de don Francisco. Je prie Dieu pour que la Sainte Inquisition la punisse de ses actes impies.";
			link.l1.go = "Inqizitor_2";
			PlayVoice("Kopcapkz\Voices\PDM\Zaharia Marlow-02.wav");
		break;

		case "Inqizitor_2":
			dialog.text = "Ah, que votre âme soit éternellement bénie pour votre action juste, "+ GetSexPhrase("mon fils", "ma fille") +". Nous nous occuperons de cette sorcière.";
			link.l1 = "Je l'espère, Saint Père. Bonne journée.";
			link.l1.go = "KAZN";
			AddBonusEnergyToCharacter(pchar, 25);
			PlaySound("Interfaceew_level.wav");
			Log_info("Votre énergie a augmenté de 25 pour toujours.");
		break;

		case "KAZN":
			DoQuestReloadToLocation("Santiago_town", "officers", "reload8_2", "PDM_ONV_KaznVedmi");
			TavernWaitDate("wait_night");
		break;
	}
}
