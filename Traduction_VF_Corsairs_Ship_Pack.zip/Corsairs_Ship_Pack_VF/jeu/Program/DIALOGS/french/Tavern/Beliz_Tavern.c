// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Vous êtes comme un perroquet, vous répétez toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
			{
				dialog.text = "Posez vos questions, "+ GetSexPhrase("señor", "señorita") +".";
				link.l1 = "J'ai entendu dire que vous aviez réussi récemment à capturer Rock le Brésilien !";
				link.l1.go = "Step_F7_1";
			}
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Tavern_NET"))	// Квест "Witch Hunt"
            {
                link.l1 = "J'ai besoin d'une fille... qui s'appelle Maria. Oם puis-je la trouver ?";
                link.l1.go = "PDM_ONV_Sprashivaem_Pro_Karlu_NeZnaet";
            }
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Tavern_DA"))	// Квест "Witch Hunt"
            {
                link.l1 = "J'ai besoin d'une fille... qui s'appelle Maria. Oם puis-je la trouver ?";
                link.l1.go = "PDM_ONV_Sprashivaem_Pro_Karlu";
            }
		break;
//******************** Фр.линейка, квест №7. Спасение Рока Бразильца ******************
 	 	case "Step_F7_1":
			dialog.text = NPCStringReactionRepeat("Oui, c'est vrai, c'est arrivé. Une chance inouïe, je vous le dis, "+ GetSexPhrase("señor", "señorita") +".", "Vous m'avez déjà interrogé sur le Brésilien.",
				          "Encore le Brésilien ?", "Eh bien, combien de temps allons-nous parler de ces pirates ? Parlons d'autre chose...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("C'est vrai, c'est vrai... Et qu'est-ce qu'on lui a fait ? On l'a sans doute étranglé sur place.", ""+ GetSexPhrase("Je vous l'ai demandé", "Je vous l'ai demandé") +" ? Eh bien, oui, sans doute...", "Oui, exactement, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +", désolé...", "On peut parler d'autre chose...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_F7_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_F7_2":
			dialog.text = "Mais que dites-vous là, "+ GetSexPhrase("señor", "señorita") +". On l'a amené et montré à tout le monde. Puis on l'a remis aux saints pères...";
			link.l1 = "Et pourquoi les saints pères en ont-ils besoin ?";
			link.l1.go = "Step_F7_3";
        break;
 	 	case "Step_F7_3":
			dialog.text = "Hé, "+ GetSexPhrase("señor", "señorita") +", ce ne sont pas des confesseurs. Ces saints pères-là sont des moines militants ! L'Inquisition...";
			link.l1 = "Ah, l'affaire est claire. Eh bien, merci, l'ami.";
			link.l1.go = "exit";
        break;
//******************** Квест "Witch Hunt" ******************
		case "PDM_ONV_Sprashivaem_Pro_Karlu_NeZnaet":
			dialog.text = "Je ne connais aucune Maria. Et nous ne proposons pas d'autres services ici, à part à manger ou à boire. Vous voulez boire quelque chose ?";
			Link.l1 = "Non, merci. Je vais y aller.";
			Link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Tavern_NET");
			AddQuestRecord("PDM_Ohota_na_vedmu", "6");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PDM_ONV_Detectiv_Jiteli_Beliz = true;
			pchar.questTemp.PDM_ONV_Detectiv_Oficiantka_Beliz = true;
		break;

		case "PDM_ONV_Sprashivaem_Pro_Karlu":
			dialog.text = "Je vous ai déjà dit qu'il n'y a pas de Maria ici !";
			Link.l1 = "Elle est accusée de sorcellerie ! Vous savez ce que ça veut dire ? Que c'est une SORCIהRE, et que si vous la couvrez, vous brמlerez sur le même bמcher qu'elle. C'est clair ? On l'a vue entrer plus d'une fois dans votre taverne. Alors, vous allez vous entêter, ou... ?";
			Link.l1.go = "PDM_ONV_SPKarlu_2";
		break;

		case "PDM_ONV_SPKarlu_2":
			dialog.text = "Oh, épargnez-moi, "+ GetSexPhrase("señor", "señorita") +" capitaine ! Je ne voulais pas enfreindre la loi, c'est juste que... j'arrive à peine à joindre les deux bouts... Je n'avais pas d'autre choix que de laisser les catins amener leurs clients ici.";
			Link.l1 = "Votre faute pourrait se régler pour, disons, deux mille pesos, à me verser. Et je dois savoir oם elle est.";
			Link.l1.go = "PDM_ONV_SPKarlu_3";
			Link.l2 = "Vos petites jérémiades ne m'intéressent pas. Je veux juste savoir oם elle est.";
			Link.l2.go = "PDM_ONV_SPKarlu_5";
		break;

		case "PDM_ONV_SPKarlu_3":
			dialog.text = "Oh, "+ GetSexPhrase("señor", "señorita") +" : vous allez me ruiner, moi et mon affaire ! Je dois payer le percepteur le mois prochain ! Deux mille, c'est tout simplement impossible ! Vous m'avez menacé du bמcher, et maintenant vous voulez que je meure de faim ?!";
			Link.l1 = "Vous n'êtes qu'un pécheur insignifiant... Bon, dites-moi oם est Maria, et je vous laisse tranquille. Que le Seigneur vous pardonne.";
			Link.l1.go = "PDM_ONV_SPKarlu_5";
			Link.l2 = "Vous avez abrité des ennemis publics dans votre taverne : vous allez donc devoir payer, d'une façon ou d'une autre.";
			Link.l2.go = "PDM_ONV_SPKarlu_4";
		break;

		case "PDM_ONV_SPKarlu_4":
			dialog.text = "Oh, vous avez ruiné ma vie ! Oui, prenez l'or, mais vous serez damné pour l'éternité !";
			Link.l1 = "Pensez à votre sort, misérable pécheur ! Si vous ne me dites pas oם est Maria, vos cris venant des cachots du gouverneur troubleront longtemps les habitants de Belize.";
			Link.l1.go = "PDM_ONV_SPKarlu_5";
			ChangeCharacterReputation(pchar, -2);
			AddMoneyToCharacter(pchar, 2000);
		break;

		case "PDM_ONV_SPKarlu_5":
			dialog.text = "Oui, oui, elle était ici ! Mais elle est partie récemment avec un capitaine. Quand elle m'a dit qu'elle s'en allait, j'ai failli fondre en larmes. Une si brave fille a enfin trouvé sa voie. Son capitaine était "+ GetSexPhrase("un vrai homme, comme vous : tout aussi fort et courageux", "un homme fort et courageux, comme vous.") +"...";
			Link.l1 = "Comment s'appelait-il ?";
			Link.l1.go = "PDM_ONV_SPKarlu_6";
		break;

		case "PDM_ONV_SPKarlu_6":
			dialog.text = "Miguel Cuenda, si je me souviens bien. Il est parti en emmenant Maria Carle avec lui. Et... pardonnez-moi, "+ GetSexPhrase("señor", "señorita") +" : je vous demande de ne pas lui dire que c'est moi qui l'ai dénoncée. Je ne veux pas qu'elle maudisse mon nom pour l'éternité...";
			Link.l1 = "Je ne lui dirai rien. Mais vous devez me dire oם ils sont allés.";
			Link.l1.go = "PDM_ONV_SPKarlu_7";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Tavern_DA");
		break;

		case "PDM_ONV_SPKarlu_7":
			int Isp_Coloni
			Isp_Coloni = rand(2);
			if (Isp_Coloni == 0)
			{
				dialog.text = "Je n'en ai aucune idée, "+ GetSexPhrase("señor", "señorita") +" capitaine. Je me souviens qu'elle a parlé d'une colonie, espagnole bien sמr... Et il y avait deux lettres : « p » et « b ».";
				Link.l1 = "Je vous crois. Mais souvenez-vous : vous devez prendre grand soin de votre âme, sale mais hélas immortelle. Bonne journée !";
				Link.l1.go = "exit";
				AddQuestRecord("PDM_Ohota_na_vedmu", "8");
				AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

				sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Viktor_Martos", "officer_22", "man", "man", 10, SPAIN, -1, false));
				sld.name = "Silino";
				sld.lastname = "Sav";
				sld.city = "PortoBello";
				FreeSitLocator("PortoBello_tavern", "sit_base2");
				ChangeCharacterAddressGroup(sld, "PortoBello_tavern", "sit", "sit_base2");
				LAi_SetSitType(sld);
				sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
				sld.dialog.currentnode   = "RazgovorSViktorom_1";
				pchar.questTemp.PDM_ONV_PortoBello = true;
			break;
			}
			if (Isp_Coloni == 1)
			{
				dialog.text = "Je n'en ai aucune idée, "+ GetSexPhrase("señor", "señorita") +" capitaine. Je me souviens qu'elle a parlé d'une colonie, espagnole bien sמr... Et il y avait deux lettres : « m » et « b ».";
				Link.l1 = "Je vous crois. Mais souvenez-vous : vous devez prendre grand soin de votre âme, sale mais hélas immortelle. Bonne journée !";
				Link.l1.go = "exit";
				AddQuestRecord("PDM_Ohota_na_vedmu", "9");
				AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

				sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Viktor_Martos", "officer_22", "man", "man", 10, SPAIN, -1, false));
				sld.name = "Silino";
				sld.lastname = "Sav";
				sld.city = "Maracaibo";
				FreeSitLocator("Maracaibo_tavern", "sit_base2");
				ChangeCharacterAddressGroup(sld, "Maracaibo_tavern", "sit", "sit_base2");
				LAi_SetSitType(sld);
				sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
				sld.dialog.currentnode   = "RazgovorSViktorom_1";
				pchar.questTemp.PDM_ONV_Maracaibo = true;
			break;
			}
			if (Isp_Coloni == 2)
			{
				dialog.text = "Je n'en ai aucune idée, "+ GetSexPhrase("señor", "señorita") +" capitaine. Je me souviens qu'elle a parlé d'une colonie, espagnole bien sמr... Et il y avait deux lettres : « S » et « J ».";
				Link.l1 = "Je vous crois. Mais souvenez-vous : vous devez prendre grand soin de votre âme, sale mais hélas immortelle. Bonne journée !";
				Link.l1.go = "exit";
				AddQuestRecord("PDM_Ohota_na_vedmu", "10");
				AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));

				sld = GetCharacter(NPC_GenerateCharacter("PDM_ONV_Viktor_Martos", "officer_22", "man", "man", 10, SPAIN, -1, false));
				sld.name = "Silino";
				sld.lastname = "Sav";
				sld.city = "SanJuan";
				FreeSitLocator("SanJuan_tavern", "sit_base2");
				ChangeCharacterAddressGroup(sld, "SanJuan_tavern", "sit", "sit_base2");
				LAi_SetSitType(sld);
				sld.dialog.filename   = "Quest\PDM\Ohota_na_vedmu.c";
				sld.dialog.currentnode   = "RazgovorSViktorom_1";
				pchar.questTemp.PDM_ONV_SanJuan = true;
			break;
			}
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

