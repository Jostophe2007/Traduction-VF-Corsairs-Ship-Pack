// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	ref FortChref;
	FortChref = GetFortCommander(NPChar.City);
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;

		case "Slavetrader_HavanaAttack":
			dialog.text = "Maudits ladrones ! Oser attaquer La Havane, c'est une audace inouïe ! Que vous faut-il ?!";
			link.l1 = "Réfléchissez bien et vous comprendrez.";
			link.l1.go = "Slavetrader_HavanaAttack_1";
			pchar.quest.Slavetrader_HavanaOver.over = "yes";
			AfterTownBattle();
        break;

		case "Slavetrader_HavanaAttack_1":
			dialog.text = "De l'or, bien sמr ! Que vous faut-il d'autre, maudits que vous êtes, à part de l'or ? Mais nous n'en avons pas... א part les quelques misérables mesures qui sont dans l'entrepכt du magasin.";
			link.l1 = "Héhé... Non, ce n'est pas l'or qui nous intéresse. Nous sommes venus pour le bois... le bois d'ébène. Vous comprenez de quoi je parle ?";
			link.l1.go = "Slavetrader_HavanaAttack_2";
        break;

		case "Slavetrader_HavanaAttack_2":
			if (CheckAttribute(FortChref, "Fort.Mode") && sti(FortChref.Fort.Mode) != FORT_DEAD)//для особо хитрых - нефиг лезть с суши
			{
				dialog.text = "Haha ! Je me doutais que c'étaient les esclaves que vous visiez. Oui, mais ils sont dans le fort. Des renforts arrivent, et il ne restera même pas un tricorne troué de votre bande.";
				link.l1 = "Oh, diable ! Bon, restez tranquille et ne bougez pas... On y va ! Bon sang...";
				link.l1.go = "Slavetrader_HavanaAttack_lose";
			}
			else
			{
				dialog.text = "Comment... Comment l'avez-vous appris ?";
				link.l1 = "Ha ! Réunir cinq mille esclaves au même endroit et espérer que personne ne le saura, il faut être un parfait idiot. דa empeste jusqu'à Tortuga... Quoi qu'il en soit, nous les emmenons.";
				link.l1.go = "Slavetrader_HavanaAttack_3";
			}
        break;

		case "Slavetrader_HavanaAttack_3":
			dialog.text = "Eh bien, vous avez gagné, et nous sommes contraints de nous soumettre à la violence. Mais ne croyez pas que ce pillage et le naufrage de deux navires de guerre espagnols resteront impunis ! Vous paierez cher cet outrage !";
			link.l1 = "Ne vous gonflez pas tant, vous allez nous faire une attaque. Restez tranquille et ne bougez pas...";
			link.l1.go = "Slavetrader_HavanaAttack_4";
			ChangeCharacterHunterScore(pchar, NationShortName(sti(npchar.Nation)) + "hunter", 50);
			ChangeCharacterReputation(pchar, -8);
        break;

		 case "Slavetrader_HavanaAttack_4":
			string sTemp;
            NextDiag.CurrentNode = "Cupture_after";
			DialogExit();
			SetReturn_Gover_Dialog_Exit(NPChar);
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_GrabbingTown", 1);
			pchar.quest.Slavetrader_DieHardHavana.over = "yes";//теперь можно на карту
            SetCharacterGoods(pchar, GOOD_SLAVES, 5000+rand(500));// c перегрузом пойдёт
            Log_SetStringToLog("Les esclaves sont embarqués sur le navire");
			Log_SetStringToLog("Vous avez 30 jours pour livrer les esclaves à votre employeur");
			chrDisableReloadToLocation = false;
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			AddQuestRecord("Slavetrader", "27");
			AddQuestUserData("Slavetrader", "sQty", sTemp);
			SetFunctionTimerCondition("Slavetrader_FiveTSlavesOver", 0, 0, 30, false);	//таймер
			pchar.questTemp.Slavetrader = "Win_HavanaFort";
        break;

		case "Slavetrader_HavanaAttack_lose":
            NextDiag.CurrentNode = "Cupture_after";
			DialogExit();
			SetReturn_Gover_Dialog_Exit(NPChar);
			ChangeCharacterReputation(pchar, -8);
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_GrabbingTown", 1);
			chrDisableReloadToLocation = false;
			pchar.quest.Slavetrader_DieHardHavana.over = "yes";//можно на карту
			pchar.quest.Slavetrader_HavanaAttack.over = "yes";//если из Сантьяго по суше пришёл - уберём корабли
			AddQuestRecord("Slavetrader", "27_1");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";
        break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

