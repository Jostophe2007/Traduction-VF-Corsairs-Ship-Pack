
void ProcessDialogEvent()
{
	ref NPChar, sld, chr, sldGirl;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "TohmasPetit_SelfTalkStart":
			dialog.text = "Assez de temps a passé, il faut se mettre en route.";
			link.l1 = "";
			link.l1.go = "TohmasPetit_SelfTalkEnd";
		break;
		
		case "TohmasPetit_SelfTalkEnd":
			DialogExit();
			LAi_SetPlayerType(PChar);
			PChar.dialog.filename = "MainHero_dialog.c";
			PChar.Dialog.CurrentNode = "TalkSelf_Main"; 
		break;
		
		case "TohmasPetitBandit_1":
			dialog.text = "Ha ha ! Notre Thomas nous a encore amené un pigeon ! Bon, capitaine, crache le pognon si tu tiens à ta peau.";
			link.l1 = "Qu'est-ce que ça signifie ?";
			link.l1.go = "TohmasPetitBandit_2";
		break;
		
		case "TohmasPetitBandit_2":
			dialog.text = "Thomas et sa copine touchent leur part pour chaque pigeon qu'ils amènent. Et tu es loin d'être "+GetSexPhrase("le premier","la première")+" à courir au secours de notre ami commun.";
			link.l1 = "Tiens, tiens... Il avait l'air d'un homme convenable, mais ce n'était qu'un gredin de plus. Et je me suis fait avoir "+GetSexPhrase("comme un imbécile.","comme une idiote.");
			link.l1.go = "TohmasPetitBandit_2_1"; 
		break;
		
		case "TohmasPetitBandit_2_1":
			dialog.text = "Bon, capitaine, assez bavardé. Maintenant, paie : 40 000 piastres feront l'affaire, sinon, nous devrons prendre l'argent sur ton cadavre !";
			link.l1 = "Pourquoi si silencieux, Thomas ? Tes nouveaux amis attendent que je commence à payer. Tu as quelque chose à dire pour ta défense ?";
			link.l1.go = "TohmasPetitBandit_ToThomas"; 
		break;

		case "TohmasPetitBandit_ToThomas":
			DialogExit();
			chr = CharacterFromID("TohmasPetit");
			chr.dialog.filename = "Quest\IP\Thomas\all.c"; 
			chr.dialog.currentnode = "TohmasPetitBandit_3"; 
			LAi_SetActorType(chr);
			LAi_ActorDialog(chr, pchar, "", 1.5, 0);
		break;

		case "TohmasPetitBandit_3":
			dialog.text = "Capitaine... וcoutez, je suis désolé, mais vous n'avez aucune chance contre eux quatre. Donnez-leur simplement votre bourse, ne laissez pas les choses mal tourner ! Après tout, la vie vaut plus que des piastres.";
			link.l1 = "Quatre voyous et un guetteur trouillard ? Vos chances ne sont pas si grandes. Sortez vos coutelas, bande de chiens, je vais faire de vous de la pâture pour les vers !";
			link.l1.go = "TohmasPetitBandit_4"; 
			if(sti(pchar.money)>=40000){
				link.l2 = "Tu as raison, Thomas... Ta vie ne vaut peut-être pas un liard, mais moi, je tiens à la mienne. Je vais payer.";
				link.l2.go = "TohmasPetitBandit_pay"; 
			}
		break;
		
		case "TohmasPetitBandit_pay":
			DialogExit();
			chr = CharacterFromID("TohmasPetit_bandit4");
			chr.dialog.filename = "Quest\IP\Thomas\all.c"; 
			chr.dialog.currentnode = "TohmasPetit_PayBanditTalk1"; 
			LAi_SetActorType(chr);
			LAi_ActorDialog(chr, pchar, "", 1.5, 0);
		break;	
		
		case "TohmasPetit_PayBanditTalk1":
			dialog.text = "Sage décision, capitaine. Thomas, prends ta donzelle et filez d'ici. Vous aurez votre part comme d'habitude, au même endroit.";
			link.l1 = "C'est ça, file, espèce de lâche. Mais sache une chose : je te retrouverai, oם que tu te caches !";
			link.l1.go = "TohmasPetit_PayTomasInit";
		break;
		
		case "TohmasPetit_PayTomasInit":
			DialogExit();
			chr = CharacterFromID("TohmasPetit");
			chr.dialog.filename = "Quest\IP\Thomas\all.c"; 
			chr.dialog.currentnode = "TohmasPetit_PayTomasTalk"; 
			LAi_SetActorType(chr);
			LAi_ActorDialog(chr, pchar, "", 1.5, 0);
		break;
		
		case "TohmasPetit_PayTomasTalk":
			dialog.text = "Capitaine, inutile de me menacer. Les bonnes personnes me connaissent en ville, et nous avons de solides protections : vous allez devoir beaucoup courir rien que pour nous trouver ! Adieu.";
			link.l1 = "C'est ce qu'on verra.";
			link.l1.go = "TohmasPetit_PayTomasExit";
		break;
		
		case "TohmasPetit_PayTomasExit":
			DialogExit();
			chr = CharacterFromID("TohmasPetit");
			LAi_SetActorType(chr);
			LAi_ActorRunToLocation(chr, "reload", "reload3_back", "none", "", "", "", 2);
			chr = CharacterFromID("TohmasPetit_girl");
			LAi_SetActorType(chr);
			LAi_ActorRunToLocation(chr, "reload", "reload3_back", "none", "", "", "", 2);
			chr = CharacterFromID("TohmasPetit_bandit4");
			chr.dialog.filename = "Quest\IP\Thomas\all.c"; 
			chr.dialog.currentnode = "TohmasPetit_PayBanditStall1"; 
			LAi_SetActorType(chr);
			LAi_ActorDialog(chr, pchar, "", 1.0, 0);
			AddMoneyToCharacter(pchar, -40000); // dialogue says 40k, was deducting 30k - mismatch
		break;
		
		case "TohmasPetit_PayBanditStall1":
			dialog.text = "Donne le sac ! C'est un plaisir de faire affaire avec des gens raisonnables. Et toi, capitaine, je vois que tu n'aimes pas du tout le risque, pour te séparer si facilement de 40 000 piastres ?";
			link.l1 = "Je tiens plus à ma vie qu'aux piastres. Prenez l'argent, et séparons-nous.";
			link.l1.go = "TohmasPetit_PayBanditStall2";
		break;
		
		case "TohmasPetit_PayBanditStall2":
			dialog.text = "Ha ha ! Vous avez entendu, les gars ? "+GetSexPhrase("Il","Elle")+" tient à la vie ! Ce Thomas est un malin. Quel coup il a monté ! Il t'a raconté une histoire de fiancée enlevée, de bandits dans la jungle... et toi, la terreur des mers, tu t'es fait avoir "+GetSexPhrase("comme un écolier","comme une gamine")+" !";
			link.l1 = "Tout le monde peut se tromper. Arrête de ricaner.";
			link.l1.go = "TohmasPetit_PayBanditStall3";
		break;

		case "TohmasPetit_PayBanditStall3":
			dialog.text = "Allez, ne fais pas la tête ! Vois le bon cכté des choses : ce soir, tout le bordel et toutes les tavernes de la ville vont faire la fête à tes frais. Nous boirons le meilleur rhum à ta santé, parole d'honneur !";
			link.l1 = "Rira bien qui rira le dernier.";
			link.l1.go = "TohmasPetit_PayBanditStall4";
		break;

		case "TohmasPetit_PayBanditStall4":
			dialog.text = "Tu nous menaces ? Tiens, tiens. Fais attention de ne pas éclater de colère, capitaine. Nous avons l'argent, nous avons les armes, et toi, tu repars d'ici les poches vides. Considère ça comme le prix d'une bonne leçon.";
			link.l1 = "Je m'en vais. Notre conversation est terminée.";
			link.l1.go = "TohmasPetit_PayBanditStall5";
		break;

		case "TohmasPetit_PayBanditStall5":
			dialog.text = "Allez, va-t'en, et vite. Adieu, capitaine crédule !";
			link.l1 = "J'espère que vous vous étoufferez avec ce rhum, ordures.";
			link.l1.go = "TohmasPetit_PayFinal";
		break;

		case "TohmasPetit_PayFinal":
			DialogExit();
			AddQuestRecord("TohmasPetit", "TrapWithPay");
			AddDialogExitQuest("TohmasPetit_Pay");
		break;
		
		case "TohmasPetitBandit_4":
			dialog.text = "Oh, mon Dieu ! La garde ! La garde !!! Au meurtre !!! Au secours !!!";
			link.l1 = "(dégainer votre coutelas et attaquer les bandits)";
			link.l1.go = "TohmasPetit_BeforeFightRecord";
		break;

		case "TohmasPetit_BeforeFightRecord":
			DialogExit();
			AddQuestRecord("TohmasPetit", "TrapWithFight");
			AddDialogExitQuest("TohmasPetit_Fight");
		break;	
		
		case "TohmasPetitGirl_1":
			dialog.text	= "Au secours ! א l'assassin ! Par ici ! La patrouille !!! Vite !!!";
			link.l1 = "La patrouille ? Vous auriez dמ appeler à l'aide plus tכt. Vous êtes en sécurité, maintenant.";
			link.l1.go = "Exit";
		break;

		case "TohmasPetitSoldier_1":
			dialog.text = "Que s'est-il passé ici ?! Capitaine, baissez votre arme immédiatement.";
			link.l1 = "Officier, c'était de la légitime défense ! Ces bandits m'ont attaqué !";
			link.l1.go = "TohmasPetitSoldier_2";
		break;
		
		case "TohmasPetitSoldier_2":
			dialog.text = "Quatre cadavres et un capitaine avec un coutelas ensanglanté. דa ne ressemble pas beaucoup à de la légitime défense.";
			link.l1 = "On m'a tendu un piège.";
			link.l1.go = "TohmasPetitSoldier_3";
		break;
		
		case "TohmasPetitSoldier_3":	
			dialog.text = "Thomas, tu étais là. Je veux entendre ce que tu as à dire.";
			link.l1 = "...";
			link.l1.go = "TohmasPetitSoldier_CallThomas";
		break;
		
		case "TohmasPetitSoldier_CallThomas":
			DialogExit();
			chr = CharacterFromID("TohmasPetit");
			chr.dialog.filename = "Quest\IP\Thomas\all.c"; 
			chr.dialog.currentnode = "TohmasPetitSoldier_4"; 
			LAi_SetActorType(chr);
			LAi_ActorDialog(chr, pchar, "", 1.5, 0);
		break;

		case "TohmasPetitSoldier_4":
			dialog.text = "Ma fiancée et moi voulions nous promener hors de la ville. J'ai engagé ces hommes comme gardes, et puis "+GetSexPhrase("ce monstre a surgi et s'est mis","cette folle a surgi et s'est mise")+" à les massacrer comme du bétail !";
			link.l1 = "Espèce de rat... Officier, tout cela est un mensonge.";
			link.l1.go = "TohmasPetitThomas_ToSoldier";
		break;
		
		case "TohmasPetitThomas_ToSoldier":
			DialogExit();
			sld = CharacterFromID("TohmasPetit_soldier1");
			sld.dialog.filename = "Quest\IP\Thomas\all.c";
			sld.dialog.currentnode = "TohmasPetitSoldier_5";
			LAi_SetActorType(sld);
			LAi_ActorDialog(sld, pchar, "", 1.5, 0);
		break;
		
		case "TohmasPetitSoldier_5":
			dialog.text = "Un mensonge, dites-vous ? וcoutons la version de la jeune fille. Mademoiselle, racontez-nous ce qui s'est passé.";
			link.l1 = "...";
			link.l1.go = "TohmasPetitSoldier_ToBride";
		break;

		case "TohmasPetitSoldier_ToBride":
			DialogExit();
			sldGirl = CharacterFromID("TohmasPetit_girl");
			sldGirl.dialog.filename = "Quest\IP\Thomas\all.c";
			sldGirl.dialog.currentnode = "TohmasPetitSoldier_6";
			LAi_SetActorType(sldGirl);
			LAi_ActorDialog(sldGirl, pchar, "", 1.5, 0);
		break;
		
		case "TohmasPetitSoldier_6":
			dialog.text = "Officier, Dieu merci, vous êtes arrivés si vite, j'ai cru que "+GetSexPhrase("ce monstre","cette folle")+" allait me dépouiller et me tuer !";
			link.l1 = "Officier, ce n'est pas ça. On m'a tendu un piège.";
			link.l1.go = "TohmasPetit_BrideToOfficer";
		break;
		
		case "TohmasPetit_BrideToOfficer":
			DialogExit();
			sld = CharacterFromID("TohmasPetit_soldier1");
			sld.dialog.filename = "Quest\IP\Thomas\all.c";
			sld.dialog.currentnode = "TohmasPetitSoldier_7";
			LAi_SetActorType(sld);
			LAi_ActorDialog(sld, pchar, "", 1.5, 0);
		break;

		case "TohmasPetitSoldier_7":
			PlaySound("Kopcapkz\Voices\Soldiers\Soldier_arrest_03.ogg");
			dialog.text = "Silence ! Nous vous avons trouvé avec une arme ensanglantée, entouré de plusieurs cadavres qui étaient des citoyens de Basse-Terre. Ce fait, ajouté au témoignage de deux habitants contre la parole d'un capitaine vagabond, me suffit amplement. Rendez votre arme et suivez-nous avant que j'ordonne à mes hommes de vous abattre sur place.";
			link.l1 = "Essayez donc de me prendre, si vous le pouvez.";
			link.l1.go = "TohmasPetitSoldier_fight";
			link.l2 = "Très bien, sergent. Je me rends. Allons-y.";
			link.l2.go = "TohmasPetitSoldier_prison";
		break;

		case "TohmasPetitSoldier_fight":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_soldiers_fight");
		break;

		case "TohmasPetitSoldier_prison": 
			ref rOfficer = CharacterFromID("TohmasPetit_soldier1");
			aref arItems, officerItems;
			ref rItem;
			string sName;
			int i, iItemsNum, iSavedMoney;
			int iPotion1 = 0;
			int iPotion2 = 0;
			int iPotion3 = 0;
			int iPotion4 = 0;
			
			RemoveCharacterEquip(pchar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(pchar, GUN_ITEM_TYPE);
			RemoveCharacterEquip(pchar, SUIT_ITEM_TYPE);
			RemoveCharacterEquip(pchar, SPYGLASS_ITEM_TYPE);
			iSavedMoney = sti(pchar.money);
			
			iPotion1 = GetCharacterItem(pchar, "potion1"); 
			iPotion2 = GetCharacterItem(pchar, "potion2");
			iPotion3 = GetCharacterItem(pchar, "potion3"); 
			iPotion4 = GetCharacterItem(pchar, "potion4"); 

			makearef(arItems, pchar.items);
			makearef(officerItems, rOfficer.items);
			iItemsNum = GetAttributesNum(arItems);
			for(i = 0; i < iItemsNum; i++)
			{
				sName = GetAttributeName(GetAttributeN(arItems, i));

				if (sName == "unarmed") continue;
				// potions are preserved separately (kept on the player), so don't store them here or they would double up
				if (sName == "potion1" || sName == "potion2" || sName == "potion3" || sName == "potion4") continue;

				// quest items (totems, mummy powder, atlas, etc.) are NOT removed by RemoveAllCharacterItems,
				// so we must not store/copy them to the officer or they would duplicate and stay on the player
				rItem = ItemsFromID(sName);
				if (CheckAttribute(rItem, "ItemType") && rItem.ItemType == "QUESTITEMS") continue;

				// store ALL of the player's other belongings (weapons, armor, maps, bullets, food, jewelry, etc.)
				pchar.QuestTemp.ArrestStorage.(sName) = pchar.items.(sName);
			}
			// Борода: только ЗАПОМИНАЕМ надетый патент - по этой метке офицер отдельно давит на потерю
			// званий, а при выкупе документ вернётся. Сам предмет изымает TohmasPetitSoldier_go_prison:
			// здесь, внутри диалога и сразу после RemoveAllCharacterItems, TakeItemFromCharacter молча
			// не срабатывал (в трассировке патент оставался в инвентаре).
			if (isMainCharacterPatented()) pchar.QuestTemp.ArrestPatent = Items[sti(pchar.EquipedPatentId)].id;
			RemoveAllCharacterItems(pchar, true);
			pchar.money = iSavedMoney;
			if (iPotion1 > 0) TakeNItems(pchar, "potion1", iPotion1);
			if (iPotion2 > 0) TakeNItems(pchar, "potion2", iPotion2);
			if (iPotion3 > 0) TakeNItems(pchar, "potion3", iPotion3);
			if (iPotion4 > 0) TakeNItems(pchar, "potion4", iPotion4);
			if (CheckAttribute(pchar, "QuestTemp.ArrestStorage"))
			{
				makearef(arItems, pchar.QuestTemp.ArrestStorage);
				makearef(officerItems, rOfficer.items);
				iItemsNum = GetAttributesNum(arItems);

				for(i = 0; i < iItemsNum; i++)
				{
					sName = GetAttributeName(GetAttributeN(arItems, i));
					officerItems.(sName) = pchar.QuestTemp.ArrestStorage.(sName);
				}
				// ArrestStorage is intentionally NOT deleted: it holds the player's confiscated belongings
				// for the peaceful (bribe) return, so the player isn't handed the officer's own gear.
			}
			if (CheckAttribute(rOfficer, "items")) 
			{
				SetCharacterGoods(rOfficer, GOOD_BALLS, GetCargoGoods(rOfficer, GOOD_BALLS)); 
			}
			LAi_SetFightMode(pchar, false);
			DialogExit();
			AddDialogExitQuest("TohmasPetitSoldier_go_prison");
		break;

		case "TohmasPetitOfficer_1":
			dialog.text = "Capitaine, vous êtes dans une situation si délicate qu'à votre place, je commencerais à me confesser avant même l'arrivée du prêtre.";
			link.l1 = "C'est vraiment si grave ?";
			link.l1.go = "TohmasPetitOfficer_2";
		break;

		case "TohmasPetitOfficer_2":
			// Борода: если у ГГ изъяли каперский патент - офицер отдельно давит на потерю званий
			if (CheckAttribute(pchar, "QuestTemp.ArrestPatent"))
			{
				dialog.text = "On t'accuse du meurtre de quatre hommes et d'une tentative de vol contre deux citoyens, "+GetSexPhrase("mon gars","ma belle")+". Et nous avons saisi ta lettre de marque. Retiens bien ceci : si tu refuses de coopérer, tu seras déchu de tous tes grades et privilèges. א titre posthume, bien sמr. Mais je peux faire « disparaître » toute cette affaire, et ta lettre de marque te reviendra intacte, comme si de rien n'était. Cela dit, ça va te coמter une jolie somme.";
				link.l1 = "Et à quel prix estimez-vous ma réputation ?";
			}
			else
			{
				dialog.text = "On t'accuse du meurtre de quatre hommes et d'une tentative de vol contre deux citoyens, "+GetSexPhrase("mon gars","ma belle")+". Mais je peux faire « disparaître » toute cette affaire. Cela dit, ça va te coמter une jolie somme.";
				link.l1 = "De quelle somme parlons-nous ?";
			}
			link.l1.go = "TohmasPetitOfficer_3";
		break;
		
		case "TohmasPetitOfficer_3":
			dialog.text = "Eh bien, disons cent cinquante mille piastres.";
			link.l1 = "Vous avez perdu la tête ? C'est une fortune.";
			link.l1.go = "TohmasPetitOfficer_4";
		break;
		
		case "TohmasPetitOfficer_4":
			dialog.text = "Oui, c'est beaucoup, mais il faut comprendre ma position. Je vais devoir graisser bien des pattes, sans parler de mon propre intérêt et de la part de mon ami.";
			if(sti(pchar.money)>=150000)
			{
				link.l1 = "On dirait que je n'ai pas le choix. Je peux payer.";
				link.l1.go = "TohmasPetitOfficer_money";
			}
			link.l2 = "Je n'ai pas une telle somme.";
			link.l2.go = "TohmasPetitOfficer_executon";
			
		break;
		
		case "TohmasPetitOfficer_money":
			dialog.text = "Bien. Tu vas devoir patienter jusqu'à demain, mais sois tranquille : au matin, tu seras libéré et on te rendra toutes tes affaires.";
			link.l1 = "Rien à faire, je vais devoir attendre.";
			link.l1.go = "TohmasPetitOfficer_money2";
		break;
		
		case "TohmasPetitOfficer_money2":
			DialogExit();
			AddTimeToCurrent(24, 00);
			SetCurrentTime(8, 20);
			AddQuestRecord("TohmasPetit", "TohmasPetit_PrisonBribePaid");
			AddDialogExitQuest("TohmasPetitSoldier_free");
		break;
		
		case "TohmasPetitOfficer_executon":
			dialog.text = "Eh bien, comme tu voudras. Demain matin, le prêtre arrive, et à midi, tu seras exécuté. Et nous aurons notre argent de toute façon, en vendant tes biens confisqués.";
			link.l1 = "J'espère que vous vous étoufferez avec cet argent.";
			link.l1.go = "TohmasPetit_PrisonDecision_No";
		break;
		
        case "TohmasPetit_PrisonDecision_No":
			DialogExit();
			SetCurrentTime(22, 20);
            SetLaunchFrameFormParam("L'officier s'est éloigné de votre cellule, vous laissant à vos pensées dans l'attente de l'aube et de la corde, et le sommeil vous a gagné sans que vous vous en rendiez compte. Quelques heures ont passé, et à travers un lourd sommeil, vous entendez cliqueter le loquet de la geכle...", "Reload_To_Location", 0.1, 2.0);
			SetLaunchFrameReloadLocationParam("BasTer_prison", "goto","goto24", "TohmasPetit_CellmateWakeUp");
			playSound("Ambient\JAIL\jail_door2.wav");
			LaunchFrameForm();
        break;
		
		case "Prison_Escaper_Start":
			dialog.text = GetSexPhrase("Hé, l'ami... Tu as une sale mine. Qu'est-ce qui t'amène ici ?","דa alors, en voilà de la chance, cכté compagnie de cellule. Hé, ma jolie, pourquoi est-ce qu'on t'a coffrée ?");
			link.l1 = "Un meurtre.";
			link.l1.go = "Prison_Escaper_1";
		break;

		case "Prison_Escaper_1":
			dialog.text = "Un meurtre, tu dis... Et qui as-tu tué, alors ?";
			link.l1 = "Quatre voyous qui se sont révélés être des citoyens du coin, et non des bandits. Et tout ça à cause de ce gredin de Thomas.";
			link.l1.go = "Prison_Escaper_2";
		break;
		
		case "Prison_Escaper_2":
			dialog.text = "Thomas ? Tu ne parlerais pas de Thomas Petit, par hasard ?";
			link.l1 = "Si, lui-même. Comment le connais-tu ? Il t'a envoyé ici pour m'achever avant l'heure ?";
			link.l1.go = "Prison_Escaper_3";
		break;
		
		case "Prison_Escaper_3":
			dialog.text = "Non, bien sמr que non. Je ferais un piètre assassin, moi, c'est plutכt les serrures et le vol. Quant à Thomas, beaucoup de gens le connaissent dans certains milieux : lui et son copain, un officier de la garde de la ville. Ils montent souvent ensemble des escroqueries louches.";
			link.l1 = "Voilà pourquoi la patrouille est arrivée si vite. דa explique bien des choses.";
			link.l1.go = "Prison_Escaper_4";
		break;
		
		case "Prison_Escaper_4":
			dialog.text = "Ouais, tu n'es pas le premier à tomber dans cette arnaque. Le plan est simple : ils engagent toutes sortes de racaille, d'anciens marins ou des voyous, des gars qui savent tenir une arme mais qui noient leur vie au fond d'une chope. C'est risqué, mais ces gens-là n'ont pas grand-chose à perdre de toute façon.";
			link.l1 = "Je vois. C'était agréable de bavarder, même si c'est dommage que ces informations ne me servent à rien : demain, j'ai rendez-vous avec la potence.";
			link.l1.go = "Prison_Escaper_5";
		break;

		case "Prison_Escaper_5":
			dialog.text = "Nous avons eu une chance inouïe, tous les deux. J'ai préparé une évasion, la serrure, c'est mon affaire. Mais là-bas, dans le couloir, il y a un officier. Seul, je ne peux pas passer, mais avec toi, nous avons une chance. Prends ce surin, mon copain l'a caché sous les couchettes. Ton travail, c'est de neutraliser le garde sans bruit. Derrière lui, il y a le passage vers le vieux mur. Pas de traînasserie, les patrouilles passent toutes les demi-heures. J'ouvre ?";
			link.l1 = "Hum, j'ai donc une chance de survivre, et peut-être même de récupérer mes affaires. Donne-moi le surin et ouvre la cellule.";
			link.l1.go = "Prison_Escaper_6";
		break;
		
		case "Prison_Escaper_6":
			dialog.text = "D'accord, attends une seconde, que je trouve oם il l'a planqué. Ah, le voilà, prends-le. Maintenant, j'ouvre la cellule.";
			link.l1 = "Souhaite-moi bonne chance.";
			link.l1.go = "Prison_Escaper_7";
		break;

		case "Prison_Escaper_7":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Start_Fight");
			AddQuestRecord("TohmasPetit", "TohmasPetit_PrisonEscapeStart");
		break;

		case "Prison_Escaper_8":
			dialog.text = "Ouf, nous nous sommes évadés ! La garde du fort est en émoi, maintenant, il n'y a plus de retour en arrière possible. Pour l'instant, il faut filer d'ici avant de nous faire prendre.";
			link.l1 = "En route !";
			link.l1.go = "exit";
			AddDialogExitQuest("TohmasPetit_follow");
		break;

		case "Prison_Escaper_10":
			dialog.text = "On dirait qu'il n'y a pas de poursuite. וcoute, capitaine, je ne peux pas quitter cette île sans espèces sonnantes. Il faut que j'achète une barque aux pêcheurs du coin. Il se trouve que j'ai une petite chose... Un morceau de carte au trésor. Je vais être franc : la carte est déchirée, je n'en ai qu'une partie. J'y ai passé un temps fou, et je crois avoir compris oם se trouve l'endroit ! Toi aussi, tu arriveras peut-être à t'y retrouver, ou bien la chance te sourira et tu trouveras le morceau manquant. Je suis prêt à te la vendre pour quarante mille piastres. Tu me tireras d'affaire, et toi-même, tu pourras t'enrichir.";
			bool bHasTreasure = false;
			if (GetCharacterItem(pchar, "map_full") > 0)
			{ 
				bHasTreasure = true;
			}
			if (GetCharacterItem(pchar, "map_part1") > 0 && GetCharacterItem(pchar, "map_part2") > 0) 
			{
				bHasTreasure = true;
			}
			if (sti(pchar.money) >= 40000 && bHasTreasure == false) 
			{
				link.l1 = "Marché conclu. 40 000 piastres, c'est un prix honnête pour une telle piste. Prends l'or, et bonne chance avec les pêcheurs.";
				link.l1.go = "Prison_Escape_BuyMap";
			}
			link.l2 = "Quel trésor, Jacques ? Le fort est en émoi, je veux juste tirer mon navire de ce pétrin. Adieu.";
			link.l2.go = "Prison_Escape_Farewell";
			link.l3 = "Attends. Puisque tu as déjà deviné l'emplacement, pourquoi achèterais-je chat en poche ? J'ai un excellent navire, tu as les coordonnées. Unissons nos forces. Je nous conduirai jusqu'à la cache, nous prendrons le butin et le partagerons moitié-moitié. J'espère qu'aucun de nous n'y perdra.";
			link.l3.go = "Prison_Escape_Klad";
			pchar.questTemp.Tohmas_ShipName = pchar.Ship.name;
		break;

		case "Prison_Escape_BuyMap":
			AddMoneyToCharacter(pchar, -40000);
			if (GetCharacterItem(pchar, "map_full") == 0)
			{
				if (!GetCharacterItem(pchar, "map_part1")) GiveItem2Character(pchar, "map_part1");
				else 									   GiveItem2Character(pchar, "map_part2");
			}
			dialog.text = "Bonne chance, capitaine ! J'espère que ce bout de papier vous portera plus chance qu'à moi.";
			link.l1 = "Adieu.";
			link.l1.go = "Prison_Escape_End";
		break;
		
		case "Prison_Escape_End":
			DialogExit();
            DisableAllExits (false);
			bDisableOfficers = false; // bought the map — escape over, officers are back with the player
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
			AddQuestRecord("TohmasPetit", "TohmasPetit_JacquesBoughtMap");
			CloseQuestHeader("TohmasPetit");
			AddGoodDeed("TohmasPetit", 3); // Gregg: доброе дело - развязка без резни
			pchar.questdata.TohmasPetit = 1; 
			TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
			DeleteAttribute(pchar, "DisableChangeFlagMode"); // unblock flag change (the check tests attribute existence, not its value)
		break;

		case "Prison_Escape_Farewell":
			dialog.text = "Eh bien, comme tu voudras. Adieu, et ne te fais plus prendre par la garde !";
			link.l1 = "Adieu.";
			link.l1.go = "Prison_Escape_End3";
		break;
		
		case "Prison_Escape_End3":
			DialogExit();
            DisableAllExits (false);
			bDisableOfficers = false; // refused the map — escape over, officers are back with the player
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
			AddQuestRecord("TohmasPetit", "TohmasPetit_JacquesRefused");
			CloseQuestHeader("TohmasPetit");
			pchar.questdata.TohmasPetit = 1;
			TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
			DeleteAttribute(pchar, "DisableChangeFlagMode"); // unblock flag change (the check tests attribute existence, not its value)
		break;
		
		case "Prison_Escape_Klad":
			bool ok = false;
			if (CheckAttribute(pchar, "location.from_sea") && pchar.location.from_sea == "BasTer_town")
			{
				ok = true;
			}
			dialog.text = "Hum... Tu as raison. Avec toi, nous avons une vraie chance. Oם est amarré ton navire ?";
			if (ok == true) 
			{
				link.l1 = "Au quai de la ville : le navire '" + pchar.questTemp.Tohmas_ShipName + "', avitaillé et prêt à appareiller.";
				link.l1.go = "Prison_Escape_ShipInPort";
			}
			else
			{
				link.l1 = "Mon navire '" + pchar.questTemp.Tohmas_ShipName + "' est ancré hors du port de la ville : " + XI_ConvertString(pchar.location.from_sea) + ".";
				link.l1.go = "Prison_Escape_ShipSafe";
			}
			DeleteAttribute(pchar, "DisableChangeFlagMode"); // unblock flag change (the check tests attribute existence, not its value)
		break;
		
		case "Prison_Escape_ShipInPort":
			dialog.text = "דa ne marchera pas ! Même si nous contournons la garde de la ville et réussissons à atteindre le quai, le fort transformera ton rafiot en passoire. J'ai une idée. Attends ici, je vais faire passer un mot secret à mes gars en ville. Ils trouveront un moyen de contacter ton équipage pour qu'il amène discrètement le navire dans la baie du Morne-à-l'Eau. C'est un coin tranquille, et nous nous y rendrons à pied par la jungle.";
			link.l1 = "Bien vu. Laisse-moi écrire un mot pour eux, que l'équipage fasse confiance à tes gens. Mon second devrait reconnaître mon écriture.";
			link.l1.go = "Prison_Escape_ShipInPort1";
		break;

		case "Prison_Escape_ShipInPort1":
			DialogExit();
			AddTimeToCurrent(0, 15);
			Log_Info("Vous avez écrit le billet et l'avez fait remettre");
			PlaySound("interface\important_item.wav");
			SetLaunchFrameFormParam("Jacques est parti en courant vers la ville. Un quart d'heure a passé ; vous entendez des pas...", "Reload_To_Location", 0.1, 2.0);
			SetLaunchFrameReloadLocationParam(pchar.location, "reload", "reload3_back", "TohmasPetit_AtGatesScene2");
			LaunchFrameForm();
		break;

		case "Prison_Escape_ShipInPort2":
			dialog.text = "C'est fait, le billet a été remis. Ton équipage devrait se mettre en route. Nous ne pouvons pas traîner ici : allons à pied jusqu'à la baie du Morne-à-l'Eau, par la jungle.";
			link.l1 = "Allons-y, pas de temps à perdre.";
			link.l1.go = "exit";
			AddQuestRecord("TohmasPetit", "TohmasPetit_JacquesShipInPort");
			AddDialogExitQuest("TohmasPetit_MoveShipToMonrlo_Start");
			DisableAllExits(false);
		break;

		case "Prison_Escape_SailorReport":
			ref rSailor = CharacterFromID("TohmasQuest_Sailor");
			dialog.text = "Capitaine ! Vous êtes vivant ! Eh bien, vous nous avez donné du fil à retordre. Des types louches montent à bord et nous fourrent un billet sous le nez... Heureusement que j'ai tout de suite reconnu votre écriture. Nous avons levé l'ancre en douce et nous nous sommes faufilés jusqu'ici, le fort n'a même pas bronché.";
			link.l1 = "Excellent travail. Jacques, le navire est là, la chaloupe attend. Oם allons-nous, maintenant ?";
			link.l1.go = "exit";
			AddDialogExitQuest("Prison_Escape_SailorReport_2");
		break;

		case "Prison_Escape_ShipInPort_Final":
			dialog.text = "Tu as un équipage formidable, capitaine ! Puisque la chaloupe est sur le rivage, sautons à bord. Ordonne à l'équipage de faire route vers " + XI_ConvertString(pchar.questTemp.TohmasPetit_landId) + " : c'est exactement là que notre or est enterré !";
			link.l1 = "Parfait, Jacques. Prends une cabine, nous larguons les amarres.";
			link.l1.go = "exit";
			AddDialogExitQuest("TohmasPetit_ToGrot");
			string sTargetIsland1 = XI_ConvertString(pchar.questTemp.TohmasPetit_landId);
			AddQuestRecord("TohmasPetit", "TohmasPetit_SailFromPortToBay");
			AddQuestUserData("TohmasPetit", "sTargetIsland", sTargetIsland1);
		break;

		case "Prison_Escape_ShipSafe":
			dialog.text = "Voilà qui simplifie les choses ! Puisque le fort ne nous coincera pas, nous allons traverser la jungle jusqu'à ton navire, dans la baie.";
			link.l1 = "Alors allons-y, pas de temps à perdre.";
			link.l1.go = "exit";
			string sBayName; 
			
			if (CheckAttribute(pchar, "location.from_sea"))
			{
				string sBayID = pchar.location.from_sea; 
				sBayName = XI_ConvertString(sBayID);   
			}
			AddDialogExitQuest("TohmasPetit_WalkToSafeBay_Start");
			AddQuestRecord("TohmasPetit", "TohmasPetit_JacquesShipSafe");
			AddQuestUserData("TohmasPetit", "sBayName", sBayName);
			DisableAllExits(false);
		break;

		case "Prison_Escape_ShipSafe_Final":
			dialog.text = "Eh bien, nous voilà arrivés entiers à ton rafiot ! Beau navire. Montons à bord et hissons vite les voiles. Notre cap : " + XI_ConvertString(pchar.questTemp.TohmasPetit_landId) + ", le trésor a assez attendu !"; 
			link.l1 = "Parfait, Jacques. Prends une cabine, nous larguons les amarres.";
			link.l1.go = "exit";
			AddDialogExitQuest("TohmasPetit_ToGrot");
			sTargetIsland1 = XI_ConvertString(pchar.questTemp.TohmasPetit_landId);
			AddQuestRecord("TohmasPetit", "TohmasPetit_SailFromSafeBay");
			AddQuestUserData("TohmasPetit", "sTargetIsland", sTargetIsland1);
		break;
		
		case "Prison_Escaper_InGrot":
			float fFortuneSkill = makefloat(GetCharacterSKILL(pchar, SKILL_FORTUNE)); 
			float fMultiplier = 1.0;

			if (fFortuneSkill <= 40.0) {
				fMultiplier = 0.8 + (fFortuneSkill / 40.0) * 0.2;
			} else {
				fMultiplier = 1.0 + ((fFortuneSkill - 40.0) / 60.0) * 1.0;
			}

			int iLuckChar = sti(pchar.SPECIAL.Luck);
			int iCount;
			// --- TIER 1 ---
			iCount = makeint(8.0 * fMultiplier); 
			TakeNItems(pchar, "icollection", iCount/2);
			TakeNItems(pchar, "chest", iCount);  

			// --- TIER 2 ---
			if (iLuckChar >= 4)
			{
				iCount = makeint(50.0 * fMultiplier); 
				TakeNItems(pchar, "jewelry2", iCount); 
				TakeNItems(pchar, "jewelry4", iCount); 
			}

			// --- TIER 3 ---
			if (iLuckChar >= 8)
			{
				TakeNItems(pchar, "Chest_quest", 1);
				TakeNItems(pchar, "Chest_treasure", 3);
			}		
			Log_Info("Vous avez reçu votre part du trésor");
			PlaySound("interface\important_item.wav");
            DeleteAttribute(pchar, "questTemp.TohmasPetit");
			dialog.text = "Le voilà, le trésor ! Il y a toute une montagne de richesses ici. Bon, capitaine, marché conclu, marché tenu. Voici ta moitié, prends-la.";
			link.l1 = "Un excellent butin, Jacques. Que comptes-tu faire ensuite ?";
			link.l1.go = "Prison_Escaper_InGrot_2";
		break;

		case "Prison_Escaper_InGrot_2":
			dialog.text = "Avec un butin pareil, je peux quitter la piraterie et retourner dans l'Ancien Monde. Dépose-moi dans n'importe quel port civilisé, sauf Basse-Terre. Les chiens du gouverneur me mettraient aux fers sur-le-champ.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
			AddDialogExitQuest("TohmasPetit_EscaperPassenger_Start");
		break;
		
		case "Prison_Escaper_Goodbye":
			dialog.text = "Oui, ce port fera très bien l'affaire. Merci pour tout, capitaine ! Sans toi, je pourrirais encore sur une couchette de prison, ou pire. Adieu, et que la mer te soit toujours clémente !";
			link.l1 = "Adieu, Jacques. Ne dilapide pas tout cet or dans la première taverne venue. Bon vent.";
			link.l1.go = "Prison_Escaper_ubigaet";
			pchar.QuestTemp.TohmasPetit_Search = "active";
			pchar.QuestTemp.TohmasPetit_Search.Path = "TooLate";
		break;
		
		case "Prison_Escaper_ubigaet":
			DialogExit();
			AddQuestRecord("TohmasPetit", "TohmasPetit_JacquesLeftSearchActive");
			AddCharacterExpToSkill(PChar, "Fortune", 50);
			AddCharacterExpToSkill(PChar, "Sneak", 50);
			AddDialogExitQuest("TohmasPetit_Escaper_FullEnd");
		break;
		
		// Диалог в трюме корабля ГГ
		case "TohmasPetit_Hold_Dialog":
			if (!CheckAttribute(npchar, "IsTomas"))
			{
				if (!CheckAttribute(npchar, "TohmasPetit_HoldTalked"))
				{
					dialog.text = "Je vous en prie, ne vous approchez pas... J'ai peur. Je ne vous dirai rien ! Parlez à Thomas, c'est lui qui a tout fait...";
					link.l1 = "Bon, arrête de trembler. Je vais parler à ton bien-aimé.";
				}
				else
				{
					dialog.text = "Je vous en supplie, ne me touchez pas... Adressez toutes vos questions à Thomas. Laissez-moi tranquille !";
					link.l1 = "D'accord, reste tranquille.";
				}
				link.l1.go = "TohmasPetit_Girl_Hold_Exit";
				break;
			}
			dialog.text = "Capitaine, écoutez-moi ! Je sais que j'ai agi de façon terrible en fuyant la Guadeloupe, mais nous n'avions tout simplement pas le choix ! Nous n'avons jamais voulu faire de mal à personne.";
			link.l1 = "Vous avez commis une folie en volant l'or d'autrui et en entraînant tout un tas de gens dans cette histoire. Maintenant, il est temps d'en assumer les conséquences.";
			link.l1.go = "TohmasPetit_Hold_To_Girl_1";
		break;

		case "TohmasPetit_Hold_To_Girl_1":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Hold_Girl_Speak_1");
		break;

		case "TohmasPetit_Girl_Hold_Dialog_1":
			dialog.text = "Nous ne voulions entraîner personne ! Thomas cherchait seulement un moyen de me sortir d'ici. Nous rêvions d'acheter des billets pour l'Europe et de commencer une nouvelle vie, loin de cette île étouffante !";
			link.l1 = "Un beau conte de fées romantique. Dommage qu'il soit bâti sur le vol.";
			link.l1.go = "TohmasPetit_Girl_To_Tomas_1";
		break;

		case "TohmasPetit_Girl_To_Tomas_1":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Hold_Tomas_Speak_1");
		break;

		case "TohmasPetit_Hold_Dialog_3":
			dialog.text = "Capitaine, soyez raisonnable ! Quel profit tirerez-vous à nous ramener ou à nous laisser pourrir dans ces chaînes humides ? Il me reste une partie de l'or que je n'ai pas eu le temps de dépenser pour les billets. Je vous donnerai TOUT, jusqu'à la dernière piastre, si vous nous laissez partir !";
			link.l1 = "Oh oh, un voleur qui essaie d'acheter sa liberté avec de l'or volé ? Tentant, mais je n'ai pas encore décidé.";
			link.l1.go = "TohmasPetit_Hold_To_Girl_2";
		break;

		case "TohmasPetit_Hold_To_Girl_2":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Hold_Girl_Speak_2");
		break;

		case "TohmasPetit_Girl_Hold_Dialog_2":
			dialog.text = "Je vous en supplie, prenez cet or maudit ! Il ne nous a apporté que des ennuis. Je vous en prie, ayez pitié, ne gâchez pas nos vies, laissez-nous une chance de partir...";
			link.l1 = "Assez de larmes et de lamentations.";
			link.l1.go = "TohmasPetit_Girl_To_Tomas_2";
		break;

		case "TohmasPetit_Girl_To_Tomas_2":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Hold_Tomas_Speak_2");
		break;

		case "TohmasPetit_Hold_Dialog_5":
			dialog.text = "Quel est notre sort, capitaine ? Que décidez-vous ?";
			if (CheckAttribute(pchar, "equip.gun") && pchar.equip.gun != "")
			{
				link.l1 = "Vous avez mis ma patience à l'épreuve bien trop longtemps, tous les deux. Vous méritez la mort. Ici et maintenant, je vais vous abattre.";
			}
			else
			{
				link.l1 = "Vous méritez la mort. Je vais te loger une balle dans le front avec ton propre pistolet, Thomas, celui que mes marins t'ont pris pendant la fouille.";
			}
			link.l1.go = "TohmasPetit_Hold_Choice_Kill";
			link.l2 = "Votre or pourrait en effet compenser mes dépenses. Prends ta donzelle ; je vous déposerai au port civilisé le plus proche, et je ne veux plus jamais vous revoir.";
			link.l2.go = "TohmasPetit_Hold_Choice_Release";
			
			if (!CheckAttribute(pchar, "QuestTemp.TohmasPetit_bloodytake"))
			{
				link.l3 = "Pas de marché avec les voleurs. Je vais vous conduire à Basse-Terre et vous livrer aux autorités locales. Qu'elles décident de votre sort.";
				link.l3.go = "TohmasPetit_Hold_Choice_Gov";
			}
		break;

		case "TohmasPetit_Hold_Choice_Kill":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Kill_Start");
		break;

		case "TohmasPetit_Girl_Shock_Dialog":
			dialog.text = "Thomas ?! Oh, mon Dieu, non, non, non ! Thomas ! Vous l'avez tué !.. Monstre ! Boucher sanguinaire ! Je vous en supplie, non, pitié-é-é !..";
			link.l1 = "Il fallait voler moins. Il est trop tard pour la pitié, ma jolie.";
			link.l1.go = "TohmasPetit_Girl_Shock_End";
		break;

		case "TohmasPetit_Girl_Shock_End":
			DialogExit();
			AddDialogExitQuest("TohmasPetit_Kill_Girl_Final");
		break;

		case "TohmasPetit_Hold_Choice_Release":
			DialogExit();
			
			sld = CharacterFromID("TohmasPetit");
			sld.TohmasPetitQuestHold = true;
			RemovePassenger(pchar, sld);
			AddPassenger(pchar, sld, false);
			ChangeCharacterAddressGroup(sld, "none", "", "");
			
			sld = CharacterFromID("TohmasPetit_girl");
			sld.TohmasPetitQuestHold = true;
			RemovePassenger(pchar, sld);
			AddPassenger(pchar, sld, false);
			ChangeCharacterAddressGroup(sld, "none", "", "");

			AddDialogExitQuest("TohmasPetit_SetupRelease");
				AddQuestRecord("TohmasPetit", "TohmasPetit_Released"); // LEO: запись была только в рус. версии
		break;

		case "TohmasPetit_Hold_Choice_Gov":
			DialogExit();
			AddQuestRecord("TohmasPetit", "TohmasPetit_HoldToGov");
			pchar.QuestTemp.TohmasPetit_Quest = "return_to_baster"; // Стадия: Вернуться на Бас-Тер
		break;

		case "TohmasPetit_Girl_Hold_Exit":
			DialogExit();
			NPChar.TohmasPetit_HoldTalked = true;
		break;
		
		case "TohmasPetit_Cap_Abordage":
			if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_CapTalked") && pchar.QuestTemp.TohmasPetit_CapTalked == "failed")
			{
				dialog.text = "Vous ?! Alors vous êtes vraiment allé jusqu'au bout de cette folie en attaquant mon sloop ?! Verser le sang de mes marins pour un misérable fugitif... Vous n'avez ni honneur ni conscience !";
				link.l1 = "Je vous avais prévenu, capitaine, que j'aurais Thomas d'une façon ou d'une autre. C'est vous qui avez choisi cette voie en refusant de régler les choses à l'amiable, et maintenant, je vais devoir me débarrasser des témoins.";
			}
			else
			{
				dialog.text = "Que diable ?! Qui êtes-vous, et de quel droit avez-vous attaqué mon navire ?!";
				link.l1 = "J'ai besoin du passager que vous cachez à bord, Thomas Petit. Et quant à vous, capitaine, notre conversation sera brève. Je n'ai que faire de témoins superflus.";
			}
			link.l1.go = "TohmasPetit_Cap_Abordage_Kill";
		break;

		case "TohmasPetit_Cap_AbordageFOrWhat":
			dialog.text = "Mais c'est de la pure folie ! J'ai satisfait votre exigence : je vous ai livré Thomas et sa fiancée, comme vous l'aviez demandé ! Nous nous sommes quittés en paix, alors pourquoi ce bain de sang maintenant ? Que voulez-vous de plus ?";
			link.l1 = "C'est vrai, capitaine, je n'ai plus de griefs contre vous. Mais vous et votre équipage en avez vu et en savez beaucoup trop. Et je n'ai pas l'habitude de laisser des témoins derrière moi.";
			link.l1.go = "TohmasPetit_Cap_Abordage_Kill2";
		break;

		case "TohmasPetit_Cap_Abordage_Kill":
			DialogExit();
			// Борода: QuestAboardCabinDialogExitWithBattle сам ставит LAi_SetFightMode -
			// отдельный MainHeroFightModeOn дублировал его с задержкой (гонка).
			QuestAboardCabinDialogExitWithBattle("TohmasPetit_Vkaute");
		break;
		case "TohmasPetit_Cap_Abordage_Kill2":
			DialogExit();
			// Борода: Томас уже получен мирно - без колбэка, просто дерёмся с командой шлюпа
			QuestAboardCabinDialogExitWithBattle("");
		break;
		
		case "TohmasPetit_Sailor_Report":
			dialog.text = "Capitaine, le combat sur les ponts a cessé, le navire est sous notre contrכle ! Nous avons fouillé à fond les cales du sloop et trouvé ce filou de Thomas avec sa donzelle Madeline, comme vous l'aviez ordonné. On vous les amène ?";
			link.l1 = "Excellent travail. Amenez-les ici, dans la cabine, puis retournez auprès du reste de l'équipe d'abordage et préparez-vous à appareiller.";
			link.l1.go = "TohmasPetit_Sailor_Leave";
		break;

		case "TohmasPetit_Sailor_Leave":
			DialogExit();
			ChangeCharacterAddressGroup(CharacterFromID("TohmasPetit_sailor"), "none", "", ""); 
			AddDialogExitQuest("TohmasPetit_Vkaute2"); 
		break;
		
		case "TohmasPetit_Cabin_Thomas_Kill":
			dialog.text = "Capitaine, je vous en supplie, épargnez-nous ! Nous vous donnerons tout l'or, jusqu'à la dernière pièce ! Prenez tout, mais épargnez nos vies !";
			link.l1 = "Tu m'as coמté tout un navire et un tas de marins morts. Il est trop tard pour implorer ma pitié, Thomas. Et je n'ai pas l'intention de laisser en vie le moindre témoin de ce massacre.";
			link.l1.go = "TohmasPetit_Hold_Choice_Kill"; 
		break;
		
		case "TohmasPetit_Gratitude":
			dialog.text = "Merci de nous avoir amenés ici. Voici votre récompense, comme convenu.";
			link.l1 = "Bonne chance à vous.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 200000); 
			AddDialogExitQuest("TohmasPetit_RunAway");
		break;

		case "exit":
			if (CheckAttribute(NextDiag,"TempNode")) NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}	
}
