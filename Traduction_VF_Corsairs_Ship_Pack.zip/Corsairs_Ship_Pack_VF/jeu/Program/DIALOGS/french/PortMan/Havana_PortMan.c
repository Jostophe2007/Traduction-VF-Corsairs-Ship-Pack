// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.Slavetrader == "FindRatHavana")
            {
                link.l1 = "Bonjour. J'aimerais savoir si la corvette '" + pchar.questTemp.Slavetrader.ShipName + "', commandée par François Gontier, a fait escale dans votre port ?";
                link.l1.go = "Havana_ratP_1";
			}

		break;

		case "Havana_ratP_1":
			dialog.text = NPCStringReactionRepeat("Oui, elle a fait escale. Mais il nous a déjà quittés. Demandez à notre aubergiste : le capitaine de la corvette lui a loué une chambre à la taverne.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Gontier.", "Je vous prie de ne pas me déranger dans mon travail !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci ! C'est ce que je vais faire.", "Hum, eh bien, oui...", "Oui, c'est vrai, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
