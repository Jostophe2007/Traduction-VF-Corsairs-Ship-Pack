
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag, arRld, arDis;
	int i, Qty;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "exit_GoOut":
			makearef(arRld, Locations[reload_cur_location_index].reload);
    		Qty = GetAttributesNum(arRld);
			for (i=0; i<Qty; i++)
    		{
    			arDis = GetAttributeN(arRld, i);
    			if (arDis.go == npchar.location)
    			{
					arDis.disable = true; //закрываем вход в дом
					break;
    			}
    		}
			DoQuestFunctionDelay("HouseEnc_TimerGoUot", 10.0);
			pchar.questTemp.HouseEncTimer = pchar.location;
			pchar.questTemp.HouseEncTimer.Id = npchar.id;
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_close":
			makearef(arRld, Locations[reload_cur_location_index].reload);
    		Qty = GetAttributesNum(arRld);
			for (i=0; i<Qty; i++)
    		{
    			arDis = GetAttributeN(arRld, i);
    			if (arDis.go == npchar.location)
    			{
					arDis.disable = true; //закрываем вход в дом
					break;
    			}
    		}
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//--------------------------------- мужик ---------------------------------
		case "HouseMan":
			NextDiag.TempNode = "HouseMan";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = PCharRepPhrase(LinkRandPhrase("L'alarme a été donnée en ville. On dirait qu'il est temps que je prenne les armes...", "Ce ne serait pas toute la garde de la ville qui te court après ? א moi, soldats !!!", "Tu ne trouveras pas refuge chez moi. Mais tu trouveras quelques pouces d'acier froid sous les cכtes !"),
					LinkRandPhrase("Qu'est-ce qu'il te faut, canaille ?! La garde de la ville est déjà sur ta piste, tu n'iras pas loin, sale pirate !", "Sale assassin ! Gardes !!!", "Je n'ai pas peur de vous, gredin ! On vous pendra bientכt dans notre fort, vous n'irez pas loin..."));
				link.l1 = PCharRepPhrase(RandPhraseSimple("On dirait que tu en as assez de vivre...", "Héhé, même les citoyens paisibles ne vivent pas en paix à " + XI_ConvertString("Colony" + npchar.city + "Gen") + " !"),
					RandPhraseSimple("Va au diable !", "Héhé, il te reste quelques secondes à vivre..."));
				link.l1.go = PCharRepPhrase("exit_setOwner", "fight");
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				if (CheckAttribute(pchar, "questTemp.HouseEncTimer"))
				{
					dialog.text = "Je t'avais prévenu. Maintenant, à toi de voir si tu veux t'y frotter...";
					link.l1 = "Hé !";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Qu'est-ce que tu veux dans ma maison, canaille ?! Je te donne dix secondes pour sortir d'ici !";
					link.l1 = LinkRandPhrase("Héhé, on me connaît ici aussi !", "Ma réputation me précède...", "Hum, je vois.");
					link.l1.go = "exit_GoOut";
				}
			}
			else
			{
				if (IsDay())
				{
					dialog.text = NPCStringReactionRepeat("C'est un plaisir de vous accueillir chez moi. Vous venez me voir pour affaires ?",
						"Que puis-je faire pour vous ?",
						"Hum, que puis-je faire pour vous ?",
						"Excusez-moi, si vous n'avez pas besoin de moi, je vous prie de ne pas me déranger...", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("Non, je visite juste la ville, je fais connaissance avec les habitants...",
						"Oh, rien de spécial...",
						"Rien...",
						"D'accord, comme vous voudrez.", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("HouseMan_1", "exit_setOwner", "exit_setOwner", "exit_setOwner", npchar, Dialog.CurrentNode);
				}
				else
				{
					dialog.text = NPCStringReactionRepeat("Pardon, mais vous vous présentez chez moi au mauvais moment : il fait nuit. Je vous prie de quitter ma maison !",
						"Je vous ai déjà dit qu'il est tard. Partez, s'il vous plaît.",
						"Je ne veux pas manquer de politesse, mais j'insiste pour que vous quittiez ma maison immédiatement !",
						"Qu'est-ce que c'est que ça ?! Gardes, au voleur !!!", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("Bon, je comprends...",
						"Oui, tout de suite...",
						"Bon, ne vous énervez pas.",
						"Taisez-vous, quels voleurs ?!", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("exit_close", "exit_setOwner", "exit_setOwner", "fight", npchar, Dialog.CurrentNode);
				}
			}
		break;

		case "HouseMan_1":
			dialog.text = "Oh, permettez-moi de me présenter : " + GetFullName(npchar) + ". Nous sommes heureux de vous voir : les lois de l'hospitalité ne sont pas de vains mots dans notre ville.";
			link.l1 = GetFullName(pchar) + ", avec votre permission...";
			link.l1.go = "exit_setOwner";
		break;
		case "Man_FackYou":
			if(!CheckCharacterPerk(pchar, "Grunt") && pchar.reputation >= 30)
			{
				dialog.text = LinkRandPhrase("Mais vous êtes "+ GetSexPhrase("un voleur, mon cher ! Gardes, retenez-le", "une voleuse ! Gardes, retenez-la") +" !!!", "דa alors ! א peine ai-je tourné la tête que tu as plongé dans le coffre ! Arrêtez "+ GetSexPhrase("le voleur", "la voleuse") +" !!!", "Gardes ! On me vole !!! Arrêtez "+ GetSexPhrase("le voleur", "la voleuse") +" !!!");
				link.l1 = "Ah, diable !!!";
				link.l1.go = "fight";
				if (CheckAttribute(pchar, "KIP_PI_SleditZaNami"))	//Проверка квеста "The losing player"
				{
					DoQuestFunctionDelay("LooserGenerator_FailedByEnc", 0.1);
				}
			}
			if(CheckCharacterPerk(pchar, "Grunt") || pchar.reputation < 30)
			{
				dialog.text = LinkRandPhrase("Mais vous êtes "+ GetSexPhrase("un voleur, mon cher ! Gardes, retenez-le", "une voleuse ! Gardes, retenez-la") +" !!!", "דa alors ! א peine ai-je tourné la tête que tu as plongé dans le coffre ! Arrêtez "+ GetSexPhrase("le voleur", "la voleuse") +" !!!", "Gardes ! On me vole !!! Arrêtez "+ GetSexPhrase("le voleur", "la voleuse") +" !!!");
				link.l1 = "Tais-toi ! Je vais te déchirer la bouche, te crever les yeux ! Toute ta vie... tu bosseras pour payer tes médicaments !";
				link.l1.go = "nofight";
			}
		break;
		// --------------------------------- баба ---------------------------------
		case "HouseWoman":
			NextDiag.TempNode = "HouseWoman";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = PCharRepPhrase(LinkRandPhrase("Je vous préviens, mon mari va bientכt rentrer ! Vous feriez mieux de sortir de chez moi...", "Je ne pense pas que vous pourrez vous échapper. Et sachez que mon mari rentre bientכt !", "Mon mari sera bientכt à la maison, vous devez partir d'ici immédiatement !"),
					LinkRandPhrase("Oh, quel dommage que mon mari ne soit pas là... Dehors !!!", "Sale assassin, hors de chez moi ! Gardes !!", ""+ GetSexPhrase("Quel scélérat", "Quelle scélérate") +"... Mon mari va bientכt rentrer, et il verra de quelle couleur est ton sang !"));
				link.l1 = PCharRepPhrase(RandPhraseSimple("Ton mari ? Il peut toujours courir...", "Héhé, tu ne me fais pas peur avec ton mari, ma mignonne..."),
					RandPhraseSimple("Ferme-la, ou je te fais sortir les tripes...", "Je resterai ici aussi longtemps que je le voudrai. Et toi, tiens-toi tranquille, sinon ce sera pire..."));
				link.l1.go = "exit_setOwner";
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				if (CheckAttribute(pchar, "questTemp.HouseEncTimer"))
				{
					dialog.text = "C'est mon dernier avertissement. Sortez, ou ce sera pire !";
					link.l1 = "Bref, une idiote...";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Que voulez-vous dans ma maison, "+ GetSexPhrase("gredin", "gredine") +" ?! Si vous ne sortez pas dans dix secondes, j'appelle la garde !";
					link.l1 = "Quelle idiote...";
					link.l1.go = "exit_GoOut";
				}
			}
			else
			{
				if (IsDay())
				{
					dialog.text = NPCStringReactionRepeat("C'est un plaisir de vous voir chez nous. Je m'appelle " + GetFullName(npchar) + ". Comment puis-je vous aider ?",
						"Tu es encore là ?",
						"Hum, excusez-moi, mais vous ne trouvez pas que vous vous attardez un peu trop chez nous ?",
						"Je vous prie de ne pas abuser de notre hospitalité.", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat( GetFullName(pchar) + ", à votre service. Je viens sans affaire particulière, juste pour faire connaissance.",
						"Je suis encore là.",
						"Eh bien, comment dire...",
						"D'accord.", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("HouseWoman_1", "exit_setOwner", "exit_setOwner", "exit_setOwner", npchar, Dialog.CurrentNode);
				}
				else
				{
					dialog.text = NPCStringReactionRepeat("Oh, mon Dieu, pourquoi entrez-vous ainsi chez les gens à une heure pareille ! Vous m'avez fait peur... Je vous prie de partir, revenez nous voir demain.",
						"Partez, je vous en prie ! "+ GetSexPhrase("Je suis une femme mariée !", "") +"",
						"Je vous demande une dernière fois de bien vouloir quitter notre maison !",
						"Mais qu'est-ce que vous faites ?!!", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("N'ayez pas peur, je ne vous ferai pas de mal.",
						"Bon, ne vous inquiétez pas...",
						"Je m'en vais.",
						"Qu'y a-t-il ?", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("exit_close", "exit_setOwner", "exit_setOwner", "HouseWoman_2", npchar, Dialog.CurrentNode);
				}
			}
		break;

		case "HouseWoman_1":
			dialog.text = "Eh bien, nous sommes toujours heureux d'avoir des invités. Je vous demande seulement de ne pas rester trop longtemps"+ GetSexPhrase(", car je suis mariée...", ", car j'ai beaucoup à faire.") +"";
			link.l1 = "Oh, oui, bien sמr...";
			link.l1.go = "exit_setOwner";
		break;
		case "Woman_FackYou":
			if(!CheckCharacterPerk(pchar, "Grunt") && pchar.reputation >= 30)
			{
				dialog.text = "Ah, c'est comme ça ?! Je vous laisse entrer chez moi en invité, et vous décidez de fouiller dans les coffres ?! Gardes !!!";
				link.l1 = "Tais-toi, idiote...";
				link.l1.go = "exit_setOwner";
				LAi_group_Attack(NPChar, Pchar);
				if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			}
			if(CheckCharacterPerk(pchar, "Grunt") || pchar.reputation < 30)
			{
				dialog.text = "Ah, c'est comme ça ?! Je vous laisse entrer chez moi en invité, et vous décidez de fouiller dans les coffres ?! Gardes !!!";
				link.l1 = "Tais-toi ! Je vais te déchirer la bouche, te crever les yeux ! Toute ta vie... tu bosseras pour payer tes médicaments !";
				link.l1.go = "nofight";
			}
		break;
		case "HouseWoman_2":
			dialog.text = "Combien de fois vous ai-je demandé de quitter la maison gentiment ! Bon, ça suffit... א l'aide ! Gardes !!!";
			link.l1 = "Tais-toi, idiote, tu es folle ?!";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
		break;
		//--------------------------------- завсклад ---------------------------------
		case "SkladMan":
			NextDiag.TempNode = "SkladMan";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville. On dirait qu'il est temps que je prenne les armes...", "Ce ne serait pas toute la garde de la ville qui te court après ? א moi, soldats !!!", "Tu ne trouveras pas refuge chez moi. Mais tu trouveras quelques pouces d'acier froid sous les cכtes !"),
					LinkRandPhrase("Qu'est-ce qu'il te faut, canaille ?! La garde de la ville est déjà sur ta piste, tu n'iras pas loin, sale pirate !", "Sale assassin ! Gardes !!!", "Je n'ai pas peur de vous, gredin ! On vous pendra bientכt dans notre fort, vous n'irez pas loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("On dirait que tu en as assez de vivre...", "Héhé, même les citoyens paisibles ne vivent pas en paix à " + XI_ConvertString("Colony" + npchar.city + "Gen") + " !"),
					RandPhraseSimple("Va au diable !", "Héhé, il te reste quelques secondes à vivre..."));
				link.l1.go = NPCharRepPhrase("exit_setOwner", "fight");
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				dialog.text = "Qu'est-ce que tu fais ici ? Attends, je crois que je te connais... Gardes, arrêtez cette ordure !!!";
				link.l1 = "Maintenant, tu vas te taire pour toujours...";
				link.l1.go = "fight";
				if (CheckAttribute(pchar, "KIP_PI_SleditZaNami"))	//Проверка квеста "The losing player"
				{
					DoQuestFunctionDelay("LooserGenerator_FailedByEnc", 0.1);
				}
			}
			else
			{
				dialog.text = NPCStringReactionRepeat("Salutations ! Je m'appelle " + GetFullName(npchar) + ". C'est moi qui m'occupe de tout ici, alors n'emportez rien...",
					"Tenez-vous bien. Et souvenez-vous que je vous surveille.",
					"Tant que vous ne touchez pas aux coffres, ça va, vous pouvez rester. Je m'ennuie, tout seul...",
					RandPhraseSimple("Oh, on s'ennuie à mourir ici !", "Oh, bon sang, que voulez-vous faire ?"), "block", 3, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("D'accord, ne vous inquiétez pas.",
					"Bien sמr !",
					"Je comprends...",
					"Oui, vous avez de sérieux problèmes...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("exit", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
				//открывание двери верфи по квесту промышленного шпионажа
				if (CheckAttribute(pchar, "questTemp.different.ShipyardsMap") && pchar.questTemp.different.ShipyardsMap == "toTarget" && npchar.city == pchar.questTemp.different.ShipyardsMap.city && locations[reload_cur_location_index].type == "shipyard")
				{
					link.l2 = "וcoute, l'ami, je veux te parler franchement.";
					link.l2.go = "ShipyardsMap_1";
					pchar.questTemp.different.ShipyardsMap = "toResult";
				}
			}
		break;
		case "ShipyardsMap_1":
			dialog.text = "Héhé ! Eh bien, parlons.";
			link.l1 = "J'ai besoin d'entrer au chantier naval la nuit, quand il n'y a personne.";
			link.l1.go = "ShipyardsMap_2";
		break;
		case "ShipyardsMap_2":
			if (sti(pchar.questTemp.different.ShipyardsMap.skladFight))
			{
				dialog.text = "דa alors ! Hé, gardes, il y a un voleur !!!";
				link.l1 = "Quel voleur ?! Je veux parler !..";
				link.l1.go = "fight";
				AddCharacterExpToSkill(pchar, "FencingLight", 5);
				AddCharacterExpToSkill(pchar, "Fencing", 5);
				AddCharacterExpToSkill(pchar, "FencingHeavy", 5);
				ChangeCharacterReputation(pchar, -1);
			}
			else
			{
				dialog.text = "Oh ! Eh bien, tu ne manques pas d'air, "+ GetSexPhrase("l'ami. Venir", "ma belle. Venir") +" au magasin du chantier naval avec une demande pareille !";
				link.l1 = "Je n'ai pas besoin d'aller au magasin, mais au chantier. Je n'ai jamais mis les pieds ici...";
				link.l1.go = "ShipyardsMap_3";
				AddCharacterExpToSkill(pchar, "Fortune", 10);
			}
		break;
		case "ShipyardsMap_3":
			dialog.text = "Pourquoi en as-tu besoin ?";
			link.l1 = "Il le faut, l'ami, il le faut. Je suis même d'accord pour payer...";
			link.l1.go = "ShipyardsMap_4";
		break;
		case "ShipyardsMap_4":
			dialog.text = "Hum, voilà qui devient plus intéressant... Bref, voilà ! Aboule " + FindRussianMoneyString(sti(pchar.questTemp.different.ShipyardsMap.sklad)*1000) + ", et pour la journée de demain, je laisserai la porte d'entrée du chantier ouverte.";
			link.l1 = "C'est trop cher pour moi. Je me débrouillerai...";
			link.l1.go = "exit";
			if (sti(pchar.money) >= (sti(pchar.questTemp.different.ShipyardsMap.sklad)*1000))
			{
				link.l2 = "Bon, je suis " + GetSexPhrase("d'accord", "d'accord") +". Prends l'argent et fais comme convenu.";
				link.l2.go = "ShipyardsMap_5";
			}
		break;
		case "ShipyardsMap_5":
			dialog.text = "Ne t'en fais pas, je le ferai.";
			link.l1 = "D'accord, je te crois...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.different.ShipyardsMap.sklad)*1000);
			AddQuestRecord("ShipyardsMap", "5");
			AddQuestUserData("ShipyardsMap", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			//снимаем close_for_night
			string  sName;
			int location_index = FindLocation(npchar.city + "_town");
    		makearef(arRld, Locations[location_index].reload);
    		Qty = GetAttributesNum(arRld);
    		for (int a=0; a<Qty; a++)
    		{
    			arDis = GetAttributeN(arRld, a);
				sName = arDis.go;
    			if (findsubstr(sName, "_shipyard" , 0) != -1)
    			{
					DeleteAttribute(arDis, "close_for_night");
					break;
    			}
    		}
			LocatorReloadEnterDisable(npchar.city + "_shipyard", "reload2", true);
			//ставим таймер на возврат close_for_night
			SetTimerFunction("ShipyardsMap_returnCFN", 0, 0, 2);
		break;
		case "nofight":
			dialog.text = "D'accord, d'accord, je ne veux pas d'ennuis ! Prenez ce que vous voulez, mais ne me touchez pas !";
			link.l1 = "Avec votre permission, héhé !";
			link.l1.go = "exit_setOwner";
			NextDiag.TempNode = "nofight";
		break;
	}
}
