// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";

            //******************** голландская линейка ***************************
        	switch (pchar.questTemp.State)   // что делаем в данный момент
            {
				case "DelivLettTortuga_toDOjeron": // Квест №7 голл. линейки. Письмо от Стэвезанта
					link.l1 = "Monsieur, je suis chargé de vous remettre une dépêche diplomatique du gouverneur général de Curaçao, Peter Stuyvesant. Veuillez la recevoir.";
					link.l1.go = "Step_H7_1";
				break;
				case "DelivLettTortuga_WaitTwoHours":
					if (GetQuestPastTimeParam("questTemp") > 1)
					{
						link.l1 = "Monsieur le gouverneur général, me voici.";
						link.l1.go = "Step_H7_3";
					}
					else
					{
						dialog.text = "Vous voilà trop tכt, je vous avais dit : dans deux heures !";
						link.l1 = "Pardon, monsieur, j'ai fait trop vite.";
						link.l1.go = "exit";
					}
				break;
				case "DelivLettTortuga_AfterRape": //Голландская линейка, квест №7. после грабежа.
					link.l1 = "Monsieur le gouverneur général, c'est encore moi !";
					link.l1.go = "Step_H7_5";
				break;
			}
		break;
		//******************** французская линейка ***************************
		case "work_1":  // работа на благо короны - линейка нации
            // сюда вход только с патентом, проверка выше
            dialog.text = LinkRandPhrase("Vous êtes au service de la France ! Je vous prie de commencer immédiatement la mission qui vous a été confiée !",
                                         "Je ne vous cacherai pas que beaucoup de choses dépendent de la réussite de vos actions. Alors, remplissez vos obligations !",
                                         "J'attends votre rapport sur l'exécution de ma mission de confiance, pas des explications creuses.");
            link.l1 = RandPhraseSimple("Je commence immédiatement, monsieur le gouverneur général.", "Je suis déjà en train de m'en occuper...");
            link.l1.go = "exit";

        	switch (pchar.questTemp.State)   // что делаем в данный момент
            {
                case "empty":   // Нет взятых квестов
                    if (GetQuestPastDayParam("questTemp") < sti(pchar.questTemp.Waiting_time))
                    {
                        dialog.text = LinkRandPhrase("Je n'ai pas de mission de confiance pour vous pour le moment. Vous pouvez revenir à ma résidence plus tard...",
                                                     "Veuillez m'excuser, je suis très occupé en ce moment !",
                                                     "Occupez-vous de vos affaires pour l'instant, je n'ai pas de mission pour vous en ce moment.");
                        link.l1 = "Très bien, monsieur le gouverneur général.";
                        link.l1.go = "exit";
                    }
                    else
                    {
						switch(pchar.questTemp.CurQuestNumber)   // Взятие квестов начиная со второго
                        {
                            case "2":
                                dialog.text = "Il faut que vous remettiez cette lettre au gouverneur général Peter Stuyvesant, à Curaçao, le plus vite possible. Et plus vite ce sera fait, plus la récompense sera élevée.";
								link.l1 = "Très bien, monsieur le gouverneur général, je vais le faire. Donnez-moi votre lettre.";
                                link.l1.go = "Step_2_1";
                            break;
                            case "3":
                                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", j'ai pour vous une mission de nature très délicate. Vous êtes honnête, vous savez tenir parole, vous l'avez prouvé plus d'une fois... Je veux remettre entre vos mains l'honneur d'une personne qui m'est chère...";
								link.l1 = "Monsieur, venons-en au fait...";
                                link.l1.go = "Step_3_1";
                            break;
                            case "4":
                                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous avez prouvé votre loyauté et votre honneur, je vous confie donc une affaire importante et strictement secrète.";
								link.l1 = "J'espère qu'elle a encore un rapport avec la mer ?";
                                link.l1.go = "Step_4_1";
                            break;
                            case "5":
                                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", encore une mission de nature délicate pour vous. Je crains sérieusement pour la vie de doña de Leyva. Rendez-lui visite, je vous prie : elle se trouve en ce moment dans ma résidence, dans la pièce voisine. La señora vous expliquera les détails.";
								link.l1 = "Je le fais immédiatement.";
                                link.l1.go = "exit";
								LAi_group_Delete("PeaceGroup");
    							pchar.questTemp.State = "Fr5AnnaHant_toAnna";
								AddQuestRecord("Fra_Line_5_KillAnnaHanters", "1");
								sld = GetCharacter(NPC_GenerateCharacter("AnnaDeLeiva", "AnnaDeLeiva", "woman", "towngirl2", 10, SPAIN, -1, false));
								sld.Dialog.Filename = "Quest\FraLineNpc_1.c";
								sld.name = "Anna Ramirez";
								sld.lastname = "de Leyva";
								LAi_SetStayType(sld);
								LAi_group_MoveCharacter(sld, "PeaceGroup");
								ChangeCharacterAddressGroup(sld, "Tortuga_townhallRoom", "goto", "goto2");
                            break;
                            case "6":
                                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", remettez d'urgence ce pli à M. Jean David, qui se trouve en ce moment à la Guadeloupe. Seulement, n'essayez pas d'y trouver un Jean David, haha : il est plus connu sous le nom de François l'Olonnais.";
								link.l1 = "Le célèbre flibustier ?";
                                link.l1.go = "Step_6_1";
                            break;
                            case "7":
                                dialog.text = "Vous tombez bien, j'allais justement donner l'ordre de vous faire chercher. J'ai pour vous une affaire qui ne peut pas attendre.";
								link.l1 = "Alors, allons-y vite !";
                                link.l1.go = "Step_7_1";
                            break;
                            case "8":
                                dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", j'ai reçu l'ordre d'envoyer un flibustier intelligent, zélé, loyal et assez respecté auprès de l'intendant de la marine française, le marquis de Bonrepos, qui se trouve en ce moment à la Guadeloupe. J'estime que votre candidature en est digne.";
								link.l1 = "Merci de votre confiance. Mais quelle est ma mission ?";
                                link.l1.go = "Step_8_1";
                            break;
                            case "9":
                                dialog.text = ""+ GetSexPhrase("Baron", "Baronne") +", j'ai reçu l'ordre de vous nommer commandant du corps spécial d'infanterie de marine punitive et de mettre à votre disposition le vaisseau Soleil Royal, que vous connaissez déjà. Vos prochaines missions seront des opérations militaires contre l'Espagne dans le cadre de la guerre de Dévolution. La première mission est de repousser l'attaque de l'escadre espagnole contre Port-au-Prince.";
								link.l1 = "Hum, apparemment, les Espagnols veulent posséder Hispaniola à eux seuls...";
                                link.l1.go = "Step_9_1";
                            break;
                            case "10":
                                dialog.text = "Alors, "+ GetSexPhrase("Baron", "Baronne") +", je suis content de vous voir. Vous tombez à pic !";
								link.l1 = "Je vous écoute, monsieur.";
                                link.l1.go = "Step_10_1";
                            break;
                            case "11":
                                dialog.text = "Alors, "+ GetSexPhrase("Baron", "Baronne") +", la France attend de vous de nouveaux exploits. Cette fois, une opération militaire très semblable à la précédente.";
								link.l1 = "La prise d'une ville, monsieur ?";
                                link.l1.go = "Step_11_1";
                            break;
                            case "12":
                                dialog.text = ""+ GetSexPhrase("Baron", "Baronne") +", la guerre de Dévolution s'est achevée par la magnifique victoire de notre bien-aimé Roi-Soleil Louis XIV !!!";
								link.l1 = "Vivat, monsieur le gouverneur général !";
                                link.l1.go = "Step_12_1";
                            break;
						}
					}
				break;
                case "":           // Квест №1, Охрана пирата Леграна.
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", connaissez-vous Pierre Legrand ? L'autre jour, imaginez-vous, il a capturé un galion militaire espagnol avec un beau butin, sur un simple lougre. Le navire et la cargaison ont été vendus, la rançon des Espagnols a été perçue, la part du roi a été versée au trésor royal. Legrand est devenu un homme riche et veut rentrer en France. Eh bien, je respecte sa décision.";
                    link.l1 = "Et il est souhaitable qu'il parte discrètement ?";
                    link.l1.go = "Step_1_1";
                break;
                case "Fr1Legran_backGovernor":
                    dialog.text = "Monsieur Legrand a réussi à me faire savoir que tout allait bien pour lui. D'ailleurs, il a dit le plus grand bien de vous. Je suis content de ne pas m'être trompé en choisissant une personne honnête et fiable.";
                    link.l1 = "Merci pour ces éloges, monsieur...";
                    link.l1.go = "Step_1_2";
                break;
                case "Fr1Legran_LegranKilled":
                    dialog.text = "Ah, c'est vous... Eh bien, qu'avez-vous à me dire ?";
                    link.l1 = "J'ai accompli votre mission, tout va bien. Mieux encore, j'ai aidé Legrand à se débarrasser des bandits qui essayaient de le dévaliser.";
                    link.l1.go = "Step_1_3";
                break;
                case "Fr1Legran_LegranIsDead":
                    dialog.text = "Ah, c'est vous... Eh bien, qu'avez-vous à me dire ?";
                    link.l1 = "Monsieur le gouverneur général, cela me peine de vous le dire, mais une embuscade nous attendait en Martinique. Legrand et moi avons dמ nous battre. Malheureusement, Legrand est mort dans ce combat...";
                    link.l1.go = "Step_1_5";
                break;
                case "Fr2Letter_SeekProblems":
                    dialog.text = "Alors, capitaine, dites-moi ce que vous avez ?";
                    link.l1 = "Votre lettre a été remise à son destinataire, monsieur.";
                    link.l1.go = "Step_2_3";
                break;
                case "Fr2Letter_NiceResult":
                    dialog.text = "Alors, capitaine, dites-moi, qu'avez-vous ?";
                    link.l1 = "Je vais vous dire, monsieur d'Ogeron, que j'ai atterri dans un sacré pétrin...";
                    link.l1.go = "Step_2_6";
                break;
                case "Fr3TakeAnna_BadResult":
                    dialog.text = "Je vous attendais. Qu'avez-vous à me dire, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
                    link.l1 = "Je n'ai pas pu ramener doña Anna, je suis désolé que ça se soit passé ainsi...";
                    link.l1.go = "Step_3_5";
                break;
                case "Fr3TakeAnna_NiceResult":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", je ne sais même pas comment vous remercier !";
                    link.l1 = "Ce n'était pas difficile, monsieur...";
                    link.l1.go = "Step_3_7";
                break;
                case "Fr4SoleiRoyal_DieHard":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", faites votre rapport sur l'accomplissement de la mission.";
                    link.l1 = "Monsieur le gouverneur général, je n'ai pas trouvé l'escadre française près de la Dominique, mais l'escadre espagnole de Juan Galeno m'est tombée dessus. Je n'ai pas pu lui résister, j'ai dמ quitter le lieu du combat...";
                    link.l1.go = "Step_4_7";
                break;
                case "Fr4SoleiRoyal_SoleiRoyalSunk":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", faites votre rapport sur l'accomplissement de la mission.";
                    link.l1 = "Monsieur le gouverneur général, je n'ai pas trouvé l'escadre française près de la Dominique, mais l'escadre espagnole de Juan Galeno m'est tombée dessus. J'ai repoussé l'attaque, mais au cours du combat, le Soleil Royal a été coulé. J'en suis vraiment désolé...";
                    link.l1.go = "Step_4_9";
                break;
                case "Fr4SoleiRoyal_backTortuga":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", faites votre rapport sur l'accomplissement de la mission.";
                    link.l1 = "Tout va bien, monsieur, même si ce ne fut pas sans problèmes. J'ai repoussé l'attaque de l'escadre espagnole commandée par ce même Juan Galeno ; je n'ai pas trouvé l'escadre française près de la Dominique, j'ai donc dמ mener le Soleil Royal jusqu'à Basse-Terre.";
                    link.l1.go = "Step_4_11";
                break;
                case "Fr5AnnaHant_GoodWork":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", je commence à penser qu'il n'existe pas de mission que vous ne puissiez accomplir. Voici votre récompense, et doña de Leyva veut vous remercier en personne.";
                    link.l1 = "Merci, monsieur le gouverneur général...";
                    link.l1.go = "exit";
					DeleteAttribute(&locations[FindLocation("Mayak10")], "DisableEncounters"); //откроем энканутеры
					pchar.questTemp.State = "empty";
					SaveCurrentQuestDateParam("questTemp");
					pchar.questTemp.CurQuestNumber = "6";
					pchar.questTemp.Waiting_time = "7";
					CloseQuestHeader("Fra_Line_5_KillAnnaHanters");
					AddMoneyToCharacter(pchar, 5000);
                break;
                case "Fr6Olone_OloneIsDead":
                    dialog.text = "Qu'avez-vous à me dire, capitaine ? Tout s'est bien passé ?";
                    link.l1 = "La lettre a été remise, mais il y a eu un problème avec l'Olonnais...";
                    link.l1.go = "Step_6_3";
                break;
                case "Fr6Olone_OloneIsLive":
                    dialog.text = "Qu'avez-vous à me dire, capitaine ? Tout s'est bien passé ?";
                    link.l1 = "Oui, tout va bien, monsieur. En plus de tout le reste, nous avons réussi à prendre Cumaná et à faire un joli butin.";
                    link.l1.go = "Step_6_7";
                break;
                case "Fr6Olone_TakeMoney":
                    dialog.text = "Qu'avez-vous à me dire, capitaine ? Tout s'est bien passé ?";
                    link.l1 = "Oui, monsieur, la lettre a été remise en main propre au destinataire. Tout va bien.";
                    link.l1.go = "Step_6_9";
                break;
                case "Fr7RockBras_toSeekPlace":
                    dialog.text = "Bien, capitaine. Parlez-moi des résultats de la mission de sauvetage de Rock le Brésilien.";
                    link.l1 = "Pour l'instant, je n'ai pas réussi à le trouver, mais je continue à chercher...";
                    link.l1.go = "exit";
					link.l2 = "Monsieur, je l'ai cherché partout, mais je n'ai pas pu le trouver. Je dois reconnaître que tout est inutile...";
                    link.l2.go = "Step_7_6";
                break;
                case "Fr7RockBras_RockIsDead":
                    dialog.text = "Alors, capitaine, je vous attendais. Y a-t-il des nouvelles du Brésilien ?";
                    link.l1 = "Il y a des nouvelles, monsieur le gouverneur général. Mais elles sont décevantes : Rock le Brésilien est mort en s'évadant des cachots de l'Inquisition...";
                    link.l1.go = "Step_7_7";
                break;
                case "Fr7RockBras_RockIsSaved":
                    dialog.text = "Je vois, capitaine, tout est en ordre. Rock m'a déjà raconté ce qu'il a enduré à l'Inquisition et comment vous l'en avez sorti. Je suis ravi !";
                    link.l1 = "Monsieur, c'était une affaire tout à fait ordinaire...";
                    link.l1.go = "Step_7_8";
                break;
                case "Fr7RockBras_RockIsAgony":
                    dialog.text = "Alors, capitaine, je vous attendais. Y a-t-il des nouvelles du Brésilien ?";
                    link.l1 = "Il y a des nouvelles, monsieur le gouverneur général. Mais elles sont décevantes : l'Inquisition a torturé Rock le Brésilien à mort. Il a expiré dans mes bras...";
                    link.l1.go = "Step_7_7";
                break;
                case "Fr8ThreeCorsairs_backGovernor":
                    dialog.text = "Alors, " + GetFullName(pchar) + ", je suis heureux de vous féliciter pour le titre de "+ GetSexPhrase("baron", "baronne") +" ! Croyez-moi, rares sont ceux qui reçoivent un tel honneur.";
                    link.l1 = "Je dois avouer, monsieur, que je ne comprends pas bien à quoi il me servira ? D'autant qu'il ne m'a pas coמté bon marché...";
                    link.l1.go = "Step_8_2";
                break;
                case "Fr9GuardPP_GoodWork":
					if (LAi_IsDead(characterFromId("SoleiRoyalCaptain")))
					{
						dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous avez perdu le Soleil Royal !";
						link.l1 = "J'ai sauvé Port-au-Prince et envoyé par le fond la plus puissante escadre des Espagnols !";
						link.l1.go = "Step_9_4";
					}
					else
					{
						dialog.text = ""+ GetSexPhrase("Baron", "Baronne") +", je suis déjà au courant de votre victoire. Que dire ? Très bien, "+ GetSexPhrase("mon ami", "mademoiselle") +", c'est tout simplement formidable !";
						link.l1 = "La première opération militaire est terminée, monsieur le gouverneur général...";
						link.l1.go = "Step_9_2";
					}
                break;
                case "Fr9GuardPP_SoleiRoyalSunk":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous avez perdu le Soleil Royal !";
                    link.l1 = "J'ai sauvé Port-au-Prince et envoyé par le fond la plus puissante escadre des Espagnols !";
                    link.l1.go = "Step_9_4";
                break;
                case "Fr9GuardPP_DieHard":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous n'avez pas su protéger Port-au-Prince ! Que s'est-il passé ?!";
                    link.l1 = "Monsieur le gouverneur, les Espagnols ont réussi à rassembler une escadre d'une puissance sans précédent ! J'ai dמ battre en retraite...";
                    link.l1.go = "Step_9_6";
                break;
                case "Fr9GuardPP_Late":
                    dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous n'avez pas su protéger Port-au-Prince ! Que s'est-il passé ?!";
                    link.l1 = "Je n'ai pas eu le temps, monsieur le gouverneur général : à mon arrivée, la ville était déjà espagnole...";
                    link.l1.go = "Step_9_7";
                break;
                case "Fr10OccupySD_toWeWon":
					dialog.text = "Alors, qu'avez-vous à me dire, "+ GetSexPhrase("Baron", "Baronne") +" ? Comment s'est passée l'opération ?";
					if (LAi_IsDead(characterFromId("SoleiRoyalCaptain")))
					{
						link.l1 = "J'ai pris Santo Domingo, cette ville appartient désormais à la France ! Mais tout ne s'est pas passé sans accroc...";
						link.l1.go = "Step_10_4";
					}
					else
					{
						link.l1 = "J'ai pris Santo Domingo, cette ville appartient désormais à la France !";
						link.l1.go = "Step_10_6";
					}
                break;
                case "Fr11OccupySC_toWeWon":
					dialog.text = ""+ GetSexPhrase("Baron", "Baronne") +", j'attends votre rapport : comment se déroule l'opération de prise de Santa Catalina ?";
					if (LAi_IsDead(characterFromId("SoleiRoyalCaptain")))
					{
						link.l1 = "Santa Catalina est prise et a prêté serment à Louis XIV. C'est la bonne nouvelle ; la mauvaise, c'est que j'ai perdu le « Soleil Royal »...";
						link.l1.go = "Step_11_3";
					}
					else
					{
						link.l1 = "Santa Catalina est prise et a prêté serment à Louis XIV.";
						link.l1.go = "Step_11_5";
					}
                break;
                case "QuestLineBreake":
                    dialog.text = "Je ne traite pas avec les gens qui manquent à leur parole. Je n'ai rien de plus à vous dire.";
                    link.l1 = "...";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
                case "EndOfQuestLine":
                    dialog.text = "Agissez de façon indépendante dans l'intérêt de la France, et n'oubliez pas non plus les flibustiers. La guerre est finie, il est temps de refaire votre vie, "+ GetSexPhrase("Baron", "Baronne") +"...";
                    link.l1 = "Très bien, monsieur.";
                    link.l1.go = "exit";
                    // Gregg: заказ на копию «Солей Руаяль». Торг и приёмка - в узлах build_ship* общего Common_Governor.c
                    if (!CheckAttribute(npchar, "quest.answer_1"))
                    {
                        link.l2 = "Monsieur, le Soleil Royal part pour l'Ancien Monde, et les Caraïbes restent derrière lui. Les chantiers royaux pourraient-ils mettre sur cale un second vaisseau comme lui ?";
                        link.l2.go = "build_ship";
                    }
                    bWorldAlivePause   = false; // Конец линейки
                break;
			}
		break;
        //********************** Квест №7 голландки, Доставка письма д'Ожерону от Стэвезанта ************************
        case "Step_H7_1":
            dialog.text = "Bien.";
            link.l1 = "Pour cela, permettez-moi de prendre congé...";
            link.l1.go = "Step_H7_2";
            TakeItemFromCharacter(pchar, "letter_2");
            BackItemDescribe("letter_2");
        break;
        case "Step_H7_2":
            dialog.text = "Attendez. Revenez me voir dans deux heures, je dois prendre connaissance du contenu de ce document. Il y aura peut-être une réponse.";
            link.l1 = "Je comprends, je serai à votre résidence dans deux heures, monsieur.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "2");
            pchar.questTemp.State = "DelivLettTortuga_WaitTwoHours";
            SaveCurrentQuestDateParam("questTemp");
        break;
        case "Step_H7_3":
            dialog.text = "Oui, bien. J'ai donc pris connaissance du contenu de la dépêche. J'ai effectivement une réponse pour Stuyvesant, veuillez porter ce pli à Curaçao.";
            link.l1 = "Très bien, monsieur. Puis-je partir maintenant ?";
            link.l1.go = "Step_H7_4";
        break;
        case "Step_H7_4":
            dialog.text = "Oui, bien sמr. Bon voyage de retour. Depuis le début de la guerre de Dévolution, les Espagnols sont devenus très actifs. Redoublez donc de prudence. Si une partie de notre correspondance tombait entre les mains des Espagnols, ils pourraient prouver que nous agissons de concert contre l'Espagne. La jeune République des Provinces-Unies ne s'en porterait pas bien.";
            link.l1 = "Je comprends, monsieur. Au revoir, et bonne chance à vous aussi.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "3");
	    AddQuestUserData("Hol_Line_7_DelivLettTortuga", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State = "DelivLettTortuga_SnapMeeting";
            ChangeItemDescribe("letter_1", "itmdescr_letter_1_HolLineQ7");
            GiveItem2Character(pchar, "letter_1");
            LocatorReloadEnterDisable("Tortuga_town", "gate_back", true);
            LocatorReloadEnterDisable("Tortuga_town", "reload1_back", true);
            LocatorReloadEnterDisable("Tortuga_town", "reload2_back", true);
            LocatorReloadEnterDisable("Tortuga_tavern", "reload2_back", false);
            LAi_LocationFightDisable(&Locations[FindLocation("Tortuga_tavern_upstairs")], true);
            Pchar.quest.DelivLettTortuga_SnapMeeting.win_condition.l1 = "location";
            Pchar.quest.DelivLettTortuga_SnapMeeting.win_condition.l1.location = "Tortuga_town";
            Pchar.quest.DelivLettTortuga_SnapMeeting.win_condition = "DelivLettTortuga_SnapMeeting";
        break;
        case "Step_H7_5":
            dialog.text = "Je vois. Pourquoi êtes-vous encore là ? On dirait que rien ne presse pour vous non plus !";
            link.l1 = "Monsieur, la dépêche que vous avez écrite m'a été volée. On m'a frappé à la tête, et je viens seulement de reprendre mes esprits !";
            link.l1.go = "Step_H7_6";
        break;
        case "Step_H7_6":
            dialog.text = "Allez immédiatement voir le capitaine du port avec mes instructions pour qu'il vous dise quel navire a quitté Tortuga au cours des deux dernières heures. Ensuite, rattrapez-le, abordez-le et retrouvez le pli !";
            link.l1 = "Je comprends, monsieur, merci de votre aide !";
            link.l1.go = "exit";
            pchar.questTemp.State = "DelivLettTortuga_toPortMan";
        break;
        //********************** Квест №1 французской линейки, охрана Леграна ************************
        case "Step_1_1":
            dialog.text = "Vous avez bien compris. Monsieur Legrand doit rejoindre la Martinique en secret ; de là, il pourra partir pour Dieppe sur un navire régulier. Mais il est « assis » sur un tas d'or et tout le monde le sait : il y a donc de sérieuses craintes quant à l'issue de son retour dans l'Ancien Monde\n"+
				          "Allez à la taverne, vous y trouverez Legrand. Votre mission est de le conduire jusqu'à la baie du Marin, en Martinique. Pierre vous remerciera, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
            link.l1 = "Très bien, monsieur, je ferai comme vous dites.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
    		// остальные линейки в сад -->
    		pchar.questTemp.NationQuest = FRANCE;
    		// остальные линейки в сад <--
    		pchar.questTemp.State = "Fr1Legran_toTavern";
            AddQuestRecord("Fra_Line_1_LegranDis", "1");
            sld = GetCharacter(NPC_GenerateCharacter("Legran", "officer_9", "man", "man", 40, FRANCE, -1, false));
			FantomMakeCoolFighter(sld, 40, 90, 40, "blade33", "pistol10", 120);
			sld.name = "Pierre";
			sld.lastname = "Legrand";
            sld.Dialog.Filename = "Quest\FraLineNpc_1.c";
			sld.SaveItemsForDead = true; // сохранять на трупе вещи
			sld.DontClearDead = true; // не убирать труп через 200с
			sld.money = 1000000;
			sld.items.jewelry5 = 30;
			sld.items.indian6 = 1;
			sld.items.jewelry14 = 12;
			sld.items.indian2 = 1;
			sld.items.indian8 = 1;
			sld.items.indian7 = 1;
			sld.items.indian12 = 1;
			sld.items.jewelry2 = 20;
			sld.greeting = "Gr_MiddPirate";
			GiveItem2Character(sld, "cirass3");
			FreeSitLocator("Tortuga_tavern", "sit3");
            LAi_SetSitType(sld);
            ChangeCharacterAddressGroup(sld, "Tortuga_tavern", "sit", "sit3");
        break;
		case "Step_1_2":
            dialog.text = "Bon, je ne vous retiens pas pour le moment, mais je vous prie de ne pas disparaître trop longtemps de mon champ de vision : j'ai souvent du travail pour un flibustier.";
            link.l1 = "Très bien, monsieur le gouverneur général, je passerai vous voir de temps en temps.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "2";
            pchar.questTemp.Waiting_time = "7";
			CloseQuestHeader("Fra_Line_1_LegranDis");
			AddTitleNextRate(sti(NPChar.nation), 2);
			AddCharacterExpToSkill(pchar, "Sneak", -170);
			AddCharacterExpToSkill(pchar, "Commerce", 90);
			AddCharacterExpToSkill(pchar, "Fencing", 80);
			AddCharacterExpToSkill(pchar, "Fortune",70);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
        break;
        case "Step_1_3":
            dialog.text = "Hum, tout cela est bien beau, mais voici le problème : Legrand lui-même a disparu. Il devait m'écrire avant de quitter Fort-de-France, mais il n'y a pas de lettre, et lui-même s'est volatilisé. Qu'en pensez-vous ?";
            link.l1 = "Je ne suis pas au courant, monsieur...";
            link.l1.go = "Step_1_4";
        break;
        case "Step_1_4":
            dialog.text = "Tout cela est bien étrange... Voilà ce qu'il en est, "+ GetSexPhrase("monsieur", "mademoiselle") +", je ne veux plus avoir affaire à vous. De plus, si jamais j'apprends que vous avez tué Legrand, il m'est difficile de décrire avec des mots ce qui vous arrivera\n"+
				          "Je ne vous retiens pas !";
            link.l1 = "Je comprends, monsieur...";
            link.l1.go = "exit";
            pchar.questTemp.State = "QuestLineBreake";
			CloseQuestHeader("Fra_Line_1_LegranDis");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -3);
			bWorldAlivePause   = false; // Конец линейки
			ChangeCharacterReputation(pchar, -10);
			AddCharacterExpToSkill(pchar, "Sneak", -170);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le gouverneur général a mis à la porte de sa résidence le capitaine " + GetMainCharacterNameGen() + " pour une sombre histoire liée à Legrand... Désormais, toutes les portes lui sont fermées.", FRANCE, 5, 1);
        break;
        case "Step_1_5":
            dialog.text = "Oui, je suis déjà au courant de ce triste événement... C'est dommage que Legrand n'ait jamais pu revenir à une vie normale, c'est bien dommage...";
            link.l1 = "Je ne le connaissais qu'un tout petit peu, mais il m'a semblé être un brave type.";
            link.l1.go = "Step_1_6";
        break;
		case "Step_1_6":
            dialog.text = "Et c'est bien le cas, "+ GetSexPhrase("monsieur", "mademoiselle") +" " + pchar.lastname + ". Eh bien, c'est triste que ce soit arrivé, mais je vous suis néanmoins reconnaissant de votre coopération. Je vous prie donc de passer me voir de temps en temps : il y aura peut-être du travail pour un flibustier.";
            link.l1 = "Très bien, monsieur d'Ogeron, je passerai à votre résidence.";
            link.l1.go = "Step_1_7";
        break;
        case "Step_1_7":
            dialog.text = "Une minute, "+ GetSexPhrase("monsieur", "mademoiselle") +" ! Rendez l'argent qu'avait Legrand, il ne vous appartient pas.";
            link.l1 = "Hum, monsieur...";
            link.l1.go = "Step_1_8";
        break;
        case "Step_1_8":
            dialog.text = "Je ne croirai jamais que vous ne l'avez pas pris. Rendez-moi donc 1 200 000 pièces, et je continuerai à travailler avec vous.";
            link.l1 = "Pourquoi autant : 1200000 ?";
            link.l1.go = "Step_1_9";
        break;
        case "Step_1_9":
            dialog.text = "Parce que je sais combien d'argent avait Legrand.";
			link.l1 = "Alors, que dois-je faire maintenant ?";
			link.l1.go = "Step_1_10";
        break;
        case "Step_1_10":
            dialog.text = "Tant que vous ne m'aurez pas rendu l'argent de Legrand en totalité, vous n'avez rien à faire à ma résidence.";
			if (sti(pchar.money) >= 1200000)
			{
				link.l1 = "Très bien, monsieur, prenez-le...";
				link.l1.go = "Step_1_11";
				AddMoneyToCharacter(pchar, -1200000);
				NextDiag.TempNode = "First time";
			}
			else
			{
				link.l1 = "Je n'ai pas encore assez d'argent. Mais je vais le trouver et je vous l'apporterai.";
				link.l1.go = "exit";
				NextDiag.TempNode = "Step_1_10";
			}
        break;

		case "Step_1_11":
            dialog.text = "Eh bien, nous sommes quittes. Vous pouvez de nouveau me rendre visite, je vous donnerai du travail de temps en temps, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
			link.l1 = "Très bien, monsieur le gouverneur général.";
			link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "2";
            pchar.questTemp.Waiting_time = "15";
			CloseQuestHeader("Fra_Line_1_LegranDis");
			AddTitleNextRate(sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Pistol", 150);
			AddCharacterExpToSkill(pchar, "Grappling", 120);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Vous savez, le capitaine " + GetFullName(pchar) + " s'est vu confier par le gouverneur général l'escorte du glorieux corsaire Legrand. Et "+ GetSexPhrase("il", "elle") +" a rempli cette mission avec honneur !", FRANCE, 5, 1);
        break;
        //********************** Квест №2 доставка письма на Кюрасао ************************
        case "Step_2_1":
            dialog.text = "Peter Stuyvesant, gouverneur général de Curaçao, est mon ami personnel et un ami de la République des Provinces-Unies. Alors n'essayez pas de faire quoi que ce soit de ce genre là-bas, sinon, à votre retour à Tortuga, je vous écorcherai vif.";
			link.l1 = "Monsieur Bertrand, je suis flibustier, mais ai-je l'air irresponsable ? Tout sera fait au mieux, ne vous inquiétez pas.";
            link.l1.go = "Step_2_2";
        break;
        case "Step_2_2":
            dialog.text = "Eh bien, très bien. Allez, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
            link.l1 = "Au revoir, monsieur.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
    		pchar.questTemp.State = "Fr2Letter_toCuracao";
            AddQuestRecord("Fra_Line_2_DelivLetter", "1");
            ChangeItemDescribe("letter_1", "itmdescr_letter_1_FraLineQ1");
            GiveItem2Character(pchar, "letter_1");
        break;
        case "Step_2_3":
            dialog.text = "Tout s'est bien passé, sans ennuis ?";
			link.l1 = "Eh bien, comment vous dire, pas vraiment. D'abord, j'ai fait un séjour en prison pour une raison inconnue, puis on m'a rendu la liberté...";
            link.l1.go = "Step_2_4";
        break;
        case "Step_2_4":
            dialog.text = "Pour quelle raison aurait-on pu vous arrêter ?";
			link.l1 = "Je n'en ai aucune idée. Pour la forme, je suppose. Mais tout s'est bien terminé, monsieur. Il n'y a donc pas lieu de s'inquiéter pour l'instant.";
            link.l1.go = "Step_2_5";
        break;
        case "Step_2_5":
            dialog.text = "Oui, c'est étrange... Bon, très bien. Je n'ai pas de travail pour vous pour le moment, alors passez à ma résidence de temps en temps, il y aura peut-être quelque chose.";
			link.l1 = "Très bien, monsieur le gouverneur général.";
            link.l1.go = "exit";
			group_DeleteGroup("Spa_Attack");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "3";
            pchar.questTemp.Waiting_time = "20";
			CloseQuestHeader("Fra_Line_2_DelivLetter");
			DeleteAttribute(pchar, "questTemp.Out");
			DeleteAttribute(pchar, "questTemp.shore");
			AddCharacterExpToSkill(pchar, "Sneak", -100);
			AddCharacterExpToSkill(pchar, "Accuracy", 200);
			ChangeCharacterReputation(pchar, -1);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le capitaine " + GetFullName(pchar) + ", qui a servi de messager à notre gouverneur général... Et vous savez, il s'est passé une histoire étrange avec "+ GetSexPhrase("lui", "elle") +" à Willemstad, une histoire très étrange...", FRANCE, 5, 1);
        break;
        case "Step_2_6":
            dialog.text = "Que s'est-il passé, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "Oh, monsieur, prenons les choses dans l'ordre. D'abord, j'ai atterri en prison et on voulait me pendre, mais on m'a rendu la liberté le lendemain matin.";
            link.l1.go = "Step_2_7";
        break;
        case "Step_2_7":
            dialog.text = "Comment ça, vous pendre ? Vous étiez mon messager !";
			link.l1 = "Ils me prenaient pour un espion des bandits qui pillent les navires hollandais près de Curaçao. Bref, au bout du compte, j'ai trouvé cette bande et je l'ai achevée. Il s'agissait de corsaires espagnols, qu'en dites-vous ?!";
            link.l1.go = "Step_2_8";
        break;
        case "Step_2_8":
            dialog.text = "Des corsaires espagnols ?! Haha, voilà qui est très convaincant\n"+
				          "C'est bien que vous ayez pu faire vos preuves à Willemstad. Je suis content d'avoir confié cette mission à "+ GetSexPhrase("un flibustier aussi méticuleux", "une fille aussi intelligente et courageuse") +"\n"+
						  "Maintenant, je n'ose plus vous retenir : reposez-vous. Mais dans une semaine ou deux, venez à ma résidence, je vous trouverai encore du travail.";
			link.l1 = "Excellent, monsieur le gouverneur général. Je serai là sans faute.";
            link.l1.go = "exit";
			group_DeleteGroup("Spa_Attack");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "3";
            pchar.questTemp.Waiting_time = "10";
			CloseQuestHeader("Fra_Line_2_DelivLetter");
			DeleteAttribute(pchar, "questTemp.Out");
			DeleteAttribute(pchar, "questTemp.shore");
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "FencingLight", 150);
			AddCharacterExpToSkill(pchar, "Fencing", 150);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 120);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le capitaine " + GetFullName(pchar) + ", qui a servi de messager à notre gouverneur général... Et vous savez, il s'est passé une histoire étrange avec "+ GetSexPhrase("lui", "elle") +" à Willemstad : "+ GetSexPhrase("il", "elle") +" a fini en prison. Mais, à l'honneur des Français, "+ GetSexPhrase("il a su", "elle a su") +" se tirer d'affaire. D'Ogeron doit être content...", FRANCE, 5, 1);
		break;
        //********************** Квест №3 похищение донны Анны ************************
        case "Step_3_1":
            dialog.text = "On raconte de vous que vous êtes "+ GetSexPhrase("un gredin sans foi ni loi", "une sacrée casse-cou") +", et je sais que pour vous le mot « honneur » n'est pas un vain mot. J'avoue qu'il ne m'est pas facile de vous faire confiance, mais je pense que c'est la meilleure solution... Ma vie est entre vos mains, et c'est à vous de décider si vous l'échangerez contre de l'or ou si vous prouverez que vous êtes "+ GetSexPhrase("un chevalier", "une femme noble") +" !";
			link.l1 = "Bon sang, tout le monde vous dira que je sais trancher des gorges, mais personne n'osera dire que je suis "+ GetSexPhrase("une canaille et un traître", "une traîtresse") +" ! Je vous écoute.";
            link.l1.go = "Step_3_2";
        break;
        case "Step_3_2":
            dialog.text = "Vous savez sans doute que j'ai fait venir de France des compagnes pour nos braves flibustiers. Maintenant, Tortuga est un paradis pour pirates : partout flotte un parfum d'amour, les rires des femmes vous tournent la tête... Mais hélas, tout le monde ne goמte pas aux fruits du paradis.";
			link.l1 = "Cupidon aurait-il visé autre chose que des boucaniers ?";
            link.l1.go = "Step_3_3";
        break;
        case "Step_3_3":
            dialog.text = "Il ne s'agit pas de moi. Il y a une dame qui serait heureuse de respirer l'air libre de notre colonie, mais qui est forcée de rester enfermée sous la coupe d'un époux tyrannique... La tirer du cachot oם elle se trouve, c'est une affaire "+ GetSexPhrase("digne d'un chevalier", " d'honneur ! Vous, en tant que femme, vous devez me comprendre") +" !";
			link.l1 = "Grâce au Créateur, vous en venez enfin au fait. Qui dois-je sauver ?";
            link.l1.go = "Step_3_4";
        break;
        case "Step_3_4":
            dialog.text = "Vous acceptez donc cette affaire ? Parfait ! La dame dont je parle est l'épouse de don José Ramirez de Leyva, le commandant de La Havane. Vous devez entrer dans la ville et trouver un moyen de l'en faire sortir\n"+
						  "Pour que vous y parveniez, je vous remets une licence commerciale espagnole de l'Escurial valable 15 jours, avec laquelle on vous laissera entrer dans les ports espagnols et visiter les villes espagnoles. Et veillez à ce qu'un pavillon espagnol ami flotte sur votre navire\n"+
				          "Tenez, prenez cette bague : grâce à elle, doña Anna Ramirez de Leyva saura que vous avez ma confiance. Et souvenez-vous que l'honneur de cette digne femme est entre vos mains.";
			link.l1 = "Je vous comprends, monsieur. J'avoue que c'est une affaire inhabituelle, mais j'apprécie votre confiance... Tout sera fait au mieux, n'en doutez pas.";
            link.l1.go = "exit";
            GiveUniLicence(15); // universal GWIK trade license
			GiveItem2Character(pchar, "DOjeronRing");
    		pchar.questTemp.State = "Fr3TakeAnna_toHavana";
            AddQuestRecord("Fra_Line_3_TakeAnna", "1");
	    AddQuestUserData("Fra_Line_3_TakeAnna", "sSex", GetSexPhrase("", "e"));
			LocatorReloadEnterDisable("Havana_town", "houseS1", true);
        break;
        case "Step_3_5":
            dialog.text = "Diable ! Et moi qui comptais sur votre intelligence et votre habileté. Que s'est-il passé ?";
			link.l1 = "Rien de spécial, monsieur. Je n'ai tout simplement pas pu l'approcher : c'est l'épouse du commandant de la capitale, après tout...";
            link.l1.go = "Step_3_6";
        break;
        case "Step_3_6":
            dialog.text = "Oui, c'est triste... Eh bien, c'était une demande personnelle de ma part, vous n'êtes donc pas coupable aux yeux de la France\n"+
				          "Je vous prie de revenir me voir à l'avenir, j'aurai peut-être une affaire pour vous.";
			link.l1 = "Très bien, monsieur le gouverneur général...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "20";
			CloseQuestHeader("Fra_Line_3_TakeAnna");
            TakeItemFromCharacter(pchar, "letter_open");
            BackItemDescribe("letter_open");
			TakeNationLicence(SPAIN);
			ChangeCharacterReputation(pchar, 10);
			AddCharacterExpToSkill(pchar, "Sneak", -100);
			AddCharacterExpToSkill(pchar, "Sailing", -100);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			//слухи
			AddSimpleRumour("Le bruit court que le capitaine " + GetFullName(pchar) + " a échoué dans une mission très importante pour d'Ogeron, une affaire de cœur...", FRANCE, 5, 1);
		break;
        case "Step_3_7":
			dialog.text = "Néanmoins, acceptez de ma part une modeste récompense\n"+
				          "Et puis, bon sang, laissez-moi tranquille, je n'ai pas la tête aux affaires administratives en ce moment. Revenez dans quelque temps...";
			link.l1 = "Très bien, monsieur le gouverneur général. Je reviendrai sans faute plus tard...";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "40";
			CloseQuestHeader("Fra_Line_3_TakeAnna");
            TakeItemFromCharacter(pchar, "letter_open");
            BackItemDescribe("letter_open");
			TakeNationLicence(SPAIN);
			AddMoneyToCharacter(pchar, 25000);
            sld = characterFromId("AnnaDeLeiva");
            RemovePassenger(pchar, sld);
			DeleteAttribute(sld, "RebirthPhantom");
         	sld.LifeDay = 0; // уберём нпс
			pchar.questTemp.AnnaIsLife = true; //но оставим флаг на пятый квест
			//==> вешаем прерывание на узнавание в таверне.
			Pchar.quest.Fr3_AfterAnna_IKnowYou.win_condition.l1 = "location";
			Pchar.quest.Fr3_AfterAnna_IKnowYou.win_condition.l1.location = "Havana_tavern";
			Pchar.quest.Fr3_AfterAnna_IKnowYou.win_condition = "Fr3_AfterAnna_IKnowYou";
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sailing", 150);
			AddCharacterExpToSkill(pchar, "Repair", 250);
			//слухи
			AddSimpleRumour("Le bruit court que c'est le capitaine " + GetFullName(pchar) + " qui, faisant preuve d'un courage et d'une ingéniosité prodigieux, a ramené ici la passion espagnole de d'Ogeron : doña Anna...", FRANCE, 5, 1);
		break;

        //********************** Квест №4  Солей Руаяль ************************
		case "Step_4_1":
            dialog.text = "Oui, je sais que vous êtes un marin, et non un amateur de secrets d'alcכve. Mais je vais vous rassurer : l'affaire actuelle est à votre goמt. Récemment, le navire le plus puissant et le plus beau du monde, le Soleil Royal, a été lancé en métropole. Sa Majesté s'intéresse à la sécurité des colonies françaises des Indes occidentales, et c'est un grand honneur pour nous que ce navire nous soit envoyé.";
			link.l1 = "Quand arrivera-t-il ?";
            link.l1.go = "Step_4_2";
        break;
		case "Step_4_2":
            dialog.text = "Il est déjà ici, en rade. Et maintenant, il doit partir pour la Dominique. Vous devez l'accompagner jusqu'à cette île.";
			link.l1 = "Avec mon navire, garder le meilleur navire de France ? Hum, c'est bizarre...";
            link.l1.go = "Step_4_3";
        break;
		case "Step_4_3":
            dialog.text = "Rien d'étrange. Deux navires valent toujours mieux qu'un, et vous êtes "+ GetSexPhrase("un capitaine brave et habile", "une capitaine brave et habile") +". De plus, j'ai des raisons de croire que les Espagnols vont faire la chasse au Soleil Royal. Trois ou quatre galions avec un équipage d'abordage sont tout à fait capables de capturer même le navire le plus puissant\n"+
				          "De plus, je sais avec certitude que ces galions, commandés par un certain Juan Galeno, sont déjà prêts. Donnez votre vie s'il le faut, mais nous ne devons pas permettre que notre navire amiral tombe entre les mains de l'Escurial. Soit vous reviendrez avec le rapport d'une mission réussie, soit mieux vaut ne pas revenir...";
			link.l1 = "Donner ma vie... Je suis loin d'être lâche"+ GetSexPhrase("", "") +", mais ça ne sonne pas très engageant !";
            link.l1.go = "Step_4_4";
        break;
		case "Step_4_4":
            dialog.text = "J'ai saisi l'allusion, capitaine. J'espère que la promesse d'une généreuse récompense pour ce travail sonne plus engageante ?";
			link.l1 = "Pourquoi emmener le navire à la Dominique ? C'est une île déserte...";
            link.l1.go = "Step_4_5";
        break;
		case "Step_4_5":
            dialog.text = "Vous devrez y faire votre jonction avec l'escadre de la Guadeloupe. Elle doit être envoyée à la Dominique par le gouverneur général de Basse-Terre " + GetFullName(characterFromId("BasTer_Mayor")) + ".";
			link.l1 = "Compris. Eh bien, j'accepte d'accomplir cette mission.";
            link.l1.go = "Step_4_6";
        break;
		case "Step_4_6":
            dialog.text = "Excellent. Le Soleil Royal passe donc sous votre commandement. Je vous prie de vous présenter immédiatement au capitaine du port : il enregistrera le capitaine du Soleil Royal comme votre compagnon.";
			link.l1 = "Nous y allons, monsieur.";
            link.l1.go = "exit";
			pchar.questTemp.State = "Fr4SoleiRoyal_toPortMan";
			AddQuestRecord("Fra_Line_4_SoleiRoyal", "1");
        break;
		case "Step_4_7":
            dialog.text = "Je n'arrive pas à y croire... Vous avez abandonné le Soleil Royal pour sauver votre peau ?!";
			link.l1 = "J'ai dמ le faire, monsieur...";
            link.l1.go = "Step_4_8";
        break;
		case "Step_4_8":
            dialog.text = "Tout est clair pour moi : vous êtes "+ GetSexPhrase("un parfait lâche", "une simple froussarde") +", capitaine. Je vous prie de partir immédiatement, je ne veux plus vous voir. Peut-être pourrez-vous un jour compter de nouveau sur ma faveur, mais pas dans un avenir proche...";
			link.l1 = "Bien, monsieur, je comprends.";
            link.l1.go = "Step_4_check";
			pchar.questTemp.State = "QuestLineBreake";
			bWorldAlivePause   = false; // Конец линейки
			CloseQuestHeader("Fra_Line_4_SoleiRoyal");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			ChangeCharacterReputation(pchar, -10);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence pour avoir abandonné le Soleil Royal au combat. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_4_9":
            dialog.text = "Bon sang, vous n'avez pas su protéger le Soleil Royal... C'est une catastrophe...";
			link.l1 = "Monsieur le gouverneur général, j'ai fait tout ce que j'ai pu...";
            link.l1.go = "Step_4_10";
        break;
		case "Step_4_10":
            dialog.text = "Bien mal, puisque vous n'avez pas pu accomplir une mission élémentaire. Vous coulez les Espagnols par dizaines, et là, vous n'avez pas su tout régler ! Vous m'avez extrêmement déçu, et je ne veux plus avoir affaire à vous !"+
				          "Maintenant, laissez-moi tranquille !";
			link.l1 = "Très bien, monsieur...";
            link.l1.go = "Step_4_check";
			pchar.questTemp.State = "QuestLineBreake";
			bWorldAlivePause   = false; // Конец линейки
			CloseQuestHeader("Fra_Line_4_SoleiRoyal");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence parce que vous avez réussi à faire couler le Soleil Royal. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_4_11":
            dialog.text = "Hum, des circonstances imprévues... Eh bien, vous avez pris la bonne décision, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je vous félicite pour la réussite d'une nouvelle affaire et vous prie d'accepter une récompense de 28 000 pièces d'or.";
			link.l1 = "Merci, monsieur le gouverneur général...";
            link.l1.go = "Step_4_12";
        break;
		case "Step_4_12":
            dialog.text = "Je vous prie de vous présenter à ma résidence dans une semaine ou deux, j'aurai peut-être une nouvelle affaire pour vous.";
			link.l1 = "Très bien, monsieur. Je viendrai sans faute.";
            link.l1.go = "Step_4_check";
			npchar.quest.answer_3 = "true";
			AddMoneyToCharacter(pchar, 28000);
            pchar.questTemp.Waiting_time = "8";
        break;
		case "Step_4_check":
			if (CheckAttribute(pchar, "questTemp.AnnaIsLife"))
			{
				pchar.questTemp.CurQuestNumber = "5";
				DeleteAttribute(pchar, "questTemp.AnnaIsLife");
			}
			else pchar.questTemp.CurQuestNumber = "6";
			SaveCurrentQuestDateParam("questTemp");
			pchar.questTemp.State = "empty";
			CloseQuestHeader("Fra_Line_4_SoleiRoyal");
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 180);
			AddCharacterExpToSkill(pchar, "Grappling", 200);
			AddCharacterExpToSkill(pchar, "Defence", 170);
			AddCharacterExpToSkill(pchar, "Cannons", 220);
			AddCharacterExpToSkill(pchar, "Fortune", 150);
			//слухи
			AddSimpleRumour("Le bruit court que les Espagnols s'en sont pris à vous pendant l'escorte du Soleil Royal ! Permettez-moi de vous exprimer mon admiration"+ GetSexPhrase(" : vous êtes un merveilleux marin et un vrai guerrier ", " : vous êtes une vraie Jeanne d'Arc ") +" !", FRANCE, 5, 1);
			DialogExit();
        break;
        //********************** Квест №6. Доставка письма Олоне ************************
		case "Step_6_1":
            dialog.text = "C'est tout. Et n'oubliez pas qu'en aucun cas cette lettre ne doit tomber entre de mauvaises mains. Si vous avez des ennuis, vous n'avez même pas le droit de mourir avant d'avoir détruit le pli.";
			link.l1 = "Vous pensez qu'il y aura des gens qui voudront voir ce que contient cette lettre ?";
            link.l1.go = "Step_6_2";
        break;
		case "Step_6_2":
            dialog.text = "Les curieux n'ont jamais manqué. Partez immédiatement, la récompense vous sera remise par monsieur David lui-même.";
			link.l1 = "Très bien, monsieur le gouverneur général. J'espère qu'elle sera à la hauteur.";
            link.l1.go = "exit";
			LAi_group_Delete("PeaceGroup");
    		pchar.questTemp.State = "Fr5Olone_toGuadeloupe";
            AddQuestRecord("Fra_Line_6_Olone", "1");
            ChangeItemDescribe("letter_1", "itmdescr_letter_1_FraLineQ6");
            GiveItem2Character(pchar, "letter_1");
			Pchar.quest.Fr6Olone_GuadeloupeBattle.win_condition.l1 = "location";
			Pchar.quest.Fr6Olone_GuadeloupeBattle.win_condition.l1.location = "Guadeloupe";
			Pchar.quest.Fr6Olone_GuadeloupeBattle.win_condition = "Fr6Olone_GuadeloupeBattle";
			//==> Олоне
            sld = GetCharacter(NPC_GenerateCharacter("Olone", "BigPirate", "man", "man", 45, FRANCE, -1, false));
            FantomMakeCoolSailor(sld, SHIP_FRIGATE, "Blood Demon", CANNON_TYPE_CULVERINE_LBS32, 90, 80, 80);
			FantomMakeCoolFighter(sld, 45, 100, 90, "blade28", "pistol5", 200);
			sld.name = "François";
			sld.lastname = "Olone";
            sld.Dialog.Filename = "Quest\FraLineNpc_1.c";
			sld.CompanionEnemyEnable = false;
			sld.Abordage.Enable = false; // НЕЛЬЗЯ!
			sld.RebirthPhantom = true;
			sld.greeting = "Gr_EvilPirate";
			ChangeCharacterReputation(sld, -100);
            LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "PeaceGroup");
            ChangeCharacterAddressGroup(sld, "BasTer_houseF1", "goto", "goto5");
        break;
		case "Step_6_3":
            dialog.text = "Que s'est-il passé ?";
			link.l1 = "Monsieur le gouverneur général, l'Olonnais et moi avions convenu de prendre Cumaná... Nous l'avons prise, mais ensuite il y a eu une querelle... Bref, l'Olonnais est mort, monsieur...";
            link.l1.go = "Step_6_4";
        break;
		case "Step_6_4":
            dialog.text = "דa alors... Et qui est ce héros qui a osé défier François l'Olonnais en personne ?";
			link.l1 = "Monsieur, "+ GetSexPhrase("c'est votre humble serviteur ", "euh... c'est moi") +"...";
            link.l1.go = "Step_6_5";
        break;
		case "Step_6_5":
            dialog.text = "Ma foi, vous êtes, "+ GetSexPhrase("monsieur, un sacré forban", "madame, une sacrée casse-cou") +" ! L'Olonnais était un démon en chair et en os\n"+
				          "Je ne dirais pas que sa mort me réjouit, mais je ne vais pas non plus la pleurer. D'ailleurs, ce genre de bagarres n'est pas rare chez les Frères de la Cכte.";
			link.l1 = "C'est exact, monsieur le gouverneur général.";
            link.l1.go = "Step_6_6";
        break;
		case "Step_6_6":
            dialog.text = "Eh bien, je ne vous retiens pas plus longtemps. Je n'ai pas encore d'affaire pour vous, mais vous pouvez passer chez moi de temps en temps...";
			link.l1 = "Très bien, monsieur, c'est exactement ce que je vais faire.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "30";
			CloseQuestHeader("Fra_Line_6_Olone");
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, -2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", 170);
			AddCharacterExpToSkill(pchar, "Sneak", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -230);
			//слухи
			AddSimpleRumour("Le bruit court que vous avez réglé son compte à François l'Olonnais en personne ! Je vous le dis, vous êtes d'un courage fou, "+ GetSexPhrase("mon gars", "ma fille") +"...", FRANCE, 5, 1);
        break;
		case "Step_6_7":
            dialog.text = "Oh, c'est formidable. En fait, c'est justement la prise de Cumaná que je recherchais. Eh bien, beau travail, "+ GetSexPhrase("mon ami", "mademoiselle") +". Votre promptitude me satisfait pleinement.";
			link.l1 = "Merci pour ces aimables paroles, monsieur. Sur ce, permettez-moi de prendre congé : les affaires...";
            link.l1.go = "Step_6_8";
        break;
		case "Step_6_8":
            dialog.text = "Oui, bien sמr, je n'ose pas vous retenir, capitaine. Mais n'oubliez pas de passer à ma résidence de temps en temps.";
			link.l1 = "Très bien, monsieur le gouverneur général.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "7";
			CloseQuestHeader("Fra_Line_6_Olone");
			AddTitleNextRate(sti(NPChar.nation), 4);
			ChangeCharacterReputation(pchar, 6);
			AddCharacterExpToSkill(pchar, "Grappling", 220);
			AddCharacterExpToSkill(pchar, "Sneak", 160);
			AddCharacterExpToSkill(pchar, "Defence", 280);
			AddCharacterExpToSkill(pchar, "Accuracy", 190);
			AddCharacterExpToSkill(pchar, "Fencing", 150);
			AddCharacterExpToSkill(pchar, "Fortune", 250);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
			//слухи
			AddSimpleRumour("Le bruit court en ville que vous avez pillé Cumaná avec François l'Olonnais. Les dons espagnols ont dמ en prendre pour leur grade ! ", FRANCE, 5, 1);
        break;
		case "Step_6_9":
            dialog.text = "Qu'a fait l'Olonnais au sujet de la dépêche ?";
			link.l1 = "Il m'a proposé une expédition contre Cumaná. Malheureusement, j'ai dמ refuser. Cependant, je pense qu'il s'en sortira sans moi, avec trois navires dans son escadre.";
            link.l1.go = "Step_6_10";
        break;
		case "Step_6_10":
            dialog.text = "Eh bien, espérons que mon plan fonctionnera... Je n'ose pas vous retenir plus longtemps, "+ GetSexPhrase("monsieur", "mademoiselle") +". N'oubliez pas de me rendre visite de temps en temps, on pourrait avoir besoin de vous.";
			link.l1 = "Très bien, monsieur le gouverneur général.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "15";
			CloseQuestHeader("Fra_Line_6_Olone");
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 2);
			AddCharacterExpToSkill(pchar, "Sneak", 190);
			AddCharacterExpToSkill(pchar, "Defence", 150);
			AddCharacterExpToSkill(pchar, "Accuracy", 220);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
        break;
        //********************** Квест №7. Вызволение из тюрьмы Рока Бральзильца ************************
		case "Step_7_1":
            dialog.text = "Les Espagnols ont mis la main sur le célèbre flibustier Rock le Brésilien. Il n'a pas de pitié à attendre, car il a beaucoup malmené les Espagnols. Bien sמr, avant de lui passer la cravate de chanvre, ils voudront savoir oם il a caché l'or qu'il leur a pris. Mais ce n'est même pas le plus important.";
			link.l1 = "L'or n'est pas l'essentiel ?! Alors quoi ?";
            link.l1.go = "Step_7_2";
        break;
		case "Step_7_2":
            dialog.text = "Les saints pères de l'Inquisition savent délier les langues, et je crains que le Brésilien ne parle pas seulement de l'or...";
			link.l1 = "... mais aussi des lettres qui, je crois, sont remises de votre part à d'autres que Jean David...";
            link.l1.go = "Step_7_3";
        break;
		case "Step_7_3":
            dialog.text = "C'est exact. Vous comprenez donc qu'il faut agir sans délai. On m'a informé que Rock avait été envoyé dans une prison de La Havane. Vous devez vous y rendre au plus vite et le tirer de captivité à tout prix. Je veux que le Brésilien soit ici, et si possible sain et sauf.";
			link.l1 = "Mais s'il meurt...";
            link.l1.go = "Step_7_4";
        break;
		case "Step_7_4":
            dialog.text = "Alors les Espagnols ne sauront rien, mais nous non plus. Et j'ai des raisons de croire que Rock, par reconnaissance pour son sauvetage, cédera au gouvernement une partie de ses trésors...";
			link.l1 = "La mission n'est pas facile, mais elle est faite pour moi ! Je pars immédiatement.";
            link.l1.go = "Step_7_5";
        break;
		case "Step_7_5":
            dialog.text = "Très bien. Autre chose : en ville, vous devez agir discrètement, si possible sans donner l'alarme. Pour cela, je vous remets une fois de plus les lettres de créance d'une compagnie commerciale espagnole.";
			link.l1 = "Merci beaucoup, monsieur le gouverneur général.";
            link.l1.go = "exit";
			LAi_group_Delete("PeaceGroup");
			GiveUniLicence(10); // universal GWIK trade license
			SetNationRelation2MainCharacter(SPAIN, RELATION_NEUTRAL);
    		pchar.questTemp.State = "Fr7RockBras_toSeekPlace";
            AddQuestRecord("Fra_Line_7_RockBras", "1");
			SaveCurrentQuestDateParam("questTemp");
			//==> Бразильца - в инквизицию.
            sld = GetCharacter(NPC_GenerateCharacter("RockBrasilian", "bocman", "man", "man", 30, PIRATE, -1, false));
			FantomMakeCoolFighter(sld, 30, 90, 90, "", "", 80);
            sld.Dialog.Filename    = "Quest\FraLineNpc_2.c";
			sld.RebirthPhantom = true;
        	sld.name 	= "Rock";
        	sld.lastname 	= "le Brésilien";
			LAi_LoginInCaptureTown(sld, true);
			LAi_NoRebirthEnable(sld);
			LAi_SetLoginTime(sld, 0.0, 24.0);
			LAi_SetGroundSitType(sld);
			LAi_group_MoveCharacter(sld, "PeaceGroup");
			ChangeCharacterAddressGroup(sld, "Santiago_Incquisitio", "prison", "prison9");

			sld = CharacterFromID("AntonioDeSouza");	//Прячем главу инквизиции на время квеста
			ChangeCharacterAddressGroup(sld, "none", "", "");
        break;
		case "Step_7_6":
            dialog.text = "Hum, « inutile », dites-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +". Ne parlez pas au nom de tout le Nouveau Monde\n"+
				          "Je suis navré, "+ GetSexPhrase("monsieur", "mademoiselle") +". C'est dommage que vous n'ayez pas su accomplir la mission... Je ne crois pas avoir encore besoin de vous. Vous pouvez passer à ma résidence de temps en temps, il y aura peut-être du travail pour vous...";
			link.l1 = "Très bien, monsieur le gouverneur général.";
            link.l1.go = "Step_7_exit";
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", -170);
			AddCharacterExpToSkill(pchar, "Defence", -130);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " n'a pas réussi à tirer Rock le Brésilien des cachots espagnols. Dommage, c'était un brave homme...", FRANCE, 5, 1);
            pchar.questTemp.Waiting_time = "35";
        break;
		case "Step_7_7":
            dialog.text = "Oui, c'est triste... C'était un bon corsaire et un vrai homme. C'est bien dommage\n"+
				          "Eh bien, je suppose que vous avez fait tout votre possible pour le sauver. Je vous invite donc à venir à ma résidence dans deux semaines : je vous trouverai une nouvelle affaire.";
			link.l1 = "Très bien, monsieur, j'y serai sans faute.";
            link.l1.go = "Step_7_exit";
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 1);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 100);
			AddCharacterExpToSkill(pchar, "Defence", 100);
			AddCharacterExpToSkill(pchar, "Cannons", 100);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " n'a pas réussi à tirer Rock le Brésilien des cachots espagnols. Dommage, c'était un brave homme...", FRANCE, 5, 1);
            pchar.questTemp.Waiting_time = "15";
        break;
		case "Step_7_exit":
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
			CloseQuestHeader("Fra_Line_7_RockBras");
			TakeNationLicence(SPAIN);
			SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
            sld = characterFromId("RockBrasilian");
			DeleteAttribute(sld, "RebirthPhantom");
         	sld.LifeDay = 0; // уберём нпс
			sld = CharacterFromID("AntonioDeSouza");	//Возвращаем главу инквизиции на место
			ChangeCharacterAddressGroup(sld, "Santiago_Incquisitio", "sit", "armchair1");
			DialogExit();
        break;
		case "Step_7_8":
            dialog.text = "Ne soyez pas modeste, capitaine. La récompense pour le travail accompli est de 30 mille pièces. Veuillez les recevoir.";
			link.l1 = "Merci, monsieur le gouverneur général...";
            link.l1.go = "Step_7_9";
        break;
		case "Step_7_9":
            dialog.text = "Comme toujours, je vous prie de passer à ma résidence de temps en temps, je pense que j'aurai besoin de vous prochainement.";
			link.l1 = "Eh bien, monsieur, je vous rendrai visite sans faute.";
            link.l1.go = "Step_7_Rock";
			AddMoneyToCharacter(pchar, 30000);
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
			CloseQuestHeader("Fra_Line_7_RockBras");
            TakeNationLicence(SPAIN);
			SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 6);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sneak", 300);
			AddCharacterExpToSkill(pchar, "Cannons", 250);
			AddCharacterExpToSkill(pchar, "Accuracy", 350);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " a tiré Rock le Brésilien des cachots espagnols. Bonne nouvelle, je vous le dis : Rock est respecté ici.", FRANCE, 5, 1);
        break;
		case "Step_7_Rock":
			sld = characterFromId("RockBrasilian");
			RemovePassenger(PChar, sld);
			LAi_SetActorType(sld);
			LAi_CharacterEnableDialog(sld);
			LAi_ActorDialog(sld, pchar, "", 0, 0);
			DialogExit();
        break;
        //********************** Квест №8. Встреча с тремя корсарами ************************
		case "Step_8_1":
            dialog.text = "Pour l'instant, la seule chose à faire est de vous rendre au plus vite chez le marquis. Je ne connais pas les détails ; apparemment, l'affaire sera très secrète.";
			link.l1 = "Eh bien, ce n'est pas la première fois. Pas de problème, j'y vais...";
            link.l1.go = "exit";
    		pchar.questTemp.State = "Fr8ThreeCorsairs_toBonrepo";
            AddQuestRecord("Fra_Line_8_ThreeCorsairs", "1");
			//==> маркиз Бонрепо.
            sld = GetCharacter(NPC_GenerateCharacter("Bonrepo", "huber_fra", "man", "man", 20, FRANCE, -1, false));
            sld.Dialog.Filename    = "Quest\FraLineNpc_1.c";
        	sld.name 	= "Marquis";
        	sld.lastname 	= "Bonrepo";
			sld.greeting = "Gr_QuestMan";
			LAi_SetStayType(sld);
			LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
			ChangeCharacterAddressGroup(sld, "BasTer_townhall", "goto", "governor1");
        break;
		case "Step_8_2":
            dialog.text = "Capitaine, tout dans cette vie ne se mesure pas en argent. Aucune somme ne peut acheter l'honneur d'un noble ni le respect des autres.";
			link.l1 = "C'est exact, monsieur...";
            link.l1.go = "Step_8_3";
        break;
		case "Step_8_3":
            dialog.text = "Eh bien, je n'ai pas encore de nouvelles demandes pour vous, mais je serai heureux que vous me rendiez visite de temps en temps : nous avons peut-être encore des choses à faire ensemble !";
			link.l1 = "Très bien, monsieur. En tant que "+ GetSexPhrase("gentilhomme français et baron", "noble dame française et baronne") +", je passerai plus souvent à votre résidence.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "12";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "9";
			CloseQuestHeader("Fra_Line_8_ThreeCorsairs");
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterReputation(pchar, 5);
			AddCharacterExpToSkill(pchar, "Sailing", 290);
			AddCharacterExpToSkill(pchar, "Leadership", -100);
			AddCharacterExpToSkill(pchar, "Commerce", 250);
			AddCharacterExpToSkill(pchar, "Pistol", 350);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetMainCharacterNameDat() + " a reçu le titre de noblesse de "+ GetSexPhrase("Baron", "Baronne") +" ! Eh bien, il s'en passe, des choses...", FRANCE, 5, 1);
        break;
        //********************** Квест №9. Отбить нападение на Порт-о-Принс ************************
		case "Step_9_1":
            dialog.text = "C'est vrai, "+ GetSexPhrase("Baron", "Baronne") +". Ils ont déjà attaqué la colonie de boucaniers de La Vega ; maintenant, apparemment, c'est au tour de Port-au-Prince.";
			link.l1 = "Je comprends, monsieur. Puis-je commencer la mission ?";
            link.l1.go = "Step_9_11";
        break;
		case "Step_9_11":
            dialog.text = "En principe, oui. Cependant, je dois vous informer de ceci : le Soleil Royal vous est affecté en renfort de votre escadre\n"+
				          "En aucun cas vous ne devez perdre ce navire, cela signifierait l'échec de la mission. Et vous ne pourriez plus travailler pour le gouvernement français.";
			link.l1 = "Hum, eh bien, je prendrai toutes les mesures pour que le magnifique Soleil Royal ne subisse pas de dégâts sérieux.";
            link.l1.go = "exit";
    		pchar.questTemp.State = "Fr9GuardPP_toPortPax";
            AddQuestRecord("Fra_Line_9_GuardPortPax", "1");
			sld = GetCharacter(NPC_GenerateCharacter("SoleiRoyalCaptain", "off_fra_2", "man", "man", 35, FRANCE, -1, true));
			sld.Ship.Type = CreateBaseShip(SHIP_SOLEYRU);
			sld.Ship.Name = "Soleil Royal";
			SetBaseShipData(sld);
			ResetShipCannonsDamages(sld);
			SetCrewQuantityFull(sld);
			Fantom_SetBalls(sld, "pirate");
			FantomMakeCoolFighter(sld, 35, 80, 70, BLADE_LONG, "pistol3", 100);
			sld.CompanionEnemyEnable = false;
			sld.Abordage.Enable = false; // НЕЛЬЗЯ!
			SetCompanionIndex(pchar, -1, sti(sld.index));
			SetShipRemovable(sld, false);
			pchar.TempPerks.QuestTroopers = true; //перк квестового десанта
			SetTimerCondition("Fr9GuardPP_Late", 0, 0, 5, false);
            Pchar.quest.Fr9GuardPP_Fight.win_condition.l1 = "location";
            Pchar.quest.Fr9GuardPP_Fight.win_condition.l1.location = "Hispaniola2";
            Pchar.quest.Fr9GuardPP_Fight.win_condition = "Fr9GuardPP_Fight";
        break;
		case "Step_9_2":
            dialog.text = "C'est vrai, "+ GetSexPhrase("Baron", "Baronne") +", et brillamment. Le gouvernement français a alloué une certaine somme pour la réparation des navires et le renouvellement des équipages : 5 mille pièces d'or... Veuillez les recevoir.";
			link.l1 = "Seulement 5 mille ?! Caramba, c'est moins que rien !";
            link.l1.go = "Step_9_3";
        break;
		case "Step_9_3":
            dialog.text = ""+ GetSexPhrase("Baron", "Baronne") +", cette guerre exige de chacun de nous le plus grand effort. Je vous prie de comprendre la situation : il y a une pénurie d'argent catastrophique. Je vous prie donc d'accepter la situation telle qu'elle est\n"+
				          "Je n'ose pas vous retenir maintenant : préparez-vous à la prochaine action militaire. Et souvenez-vous : la France a besoin de vous !";
			link.l1 = "Euh, eh bien, si la France a tant besoin de moi, elle m'aura. Je serai à votre résidence quand j'aurai mis de l'ordre dans mes affaires, monsieur. Au revoir.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "18";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "10";
			CloseQuestHeader("Fra_Line_9_GuardPortPax");
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 7);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 270);
			AddCharacterExpToSkill(pchar, "Sneak", 260);
			AddCharacterExpToSkill(pchar, "Cannons", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 230);
			AddCharacterExpToSkill(pchar, "Fencing", 250);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " a sauvé les habitants de Port-au-Prince des Espagnols !", FRANCE, 5, 1);
        break;
		case "Step_9_4":
            dialog.text = "Mais vous avez perdu le Soleil Royal, capitaine, et il n'y a pas d'excuse à cela !";
			link.l1 = "J'ai fait tout ce qui était en mon pouvoir...";
            link.l1.go = "Step_9_5";
        break;
		case "Step_9_5":
            dialog.text = "Vous n'en avez pas fait assez ! En somme, la perte d'un tel navire fait que la France renonce à vos services, "+ GetSexPhrase("monsieur", "mademoiselle") +". Adieu.";
			link.l1 = "Et ça, après tout ce que j'ai fait pour la Couronne de France ?! Adieu, monsieur, j'en ai déjà assez de tout ça...";
            link.l1.go = "exit";
			pchar.questTemp.State = "QuestLineBreake";
			bWorldAlivePause   = false; // Конец линейки
			CloseQuestHeader("Fra_Line_9_GuardPortPax");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Repair", -270);
			AddCharacterExpToSkill(pchar, "Sneak", -200);
			AddCharacterExpToSkill(pchar, "FencingLight", -230);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -230);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence parce que vous avez réussi à faire couler le Soleil Royal. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_9_6":
            dialog.text = "Bon sang, vous êtes tout simplement "+ GetSexPhrase("un parfait lâche", "une froussarde") +" ! Je ne veux plus rien avoir à faire avec vous. Adieu, "+ GetSexPhrase("Baron", "Baronne") +"...";
			link.l1 = "Adieu, monsieur, et mes salutations ferventes au marquis de Bonrepos...";
            link.l1.go = "exit";
			pchar.questTemp.State = "QuestLineBreake";
			bWorldAlivePause   = false; // Конец линейки
			CloseQuestHeader("Fra_Line_9_GuardPortPax");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Repair", -270);
			AddCharacterExpToSkill(pchar, "Sneak", -200);
			AddCharacterExpToSkill(pchar, "FencingLight", -230);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -230);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence pour avoir abandonné le Soleil Royal au combat. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_9_7":
            dialog.text = "Diable, comment est-ce possible ?! C'est à deux jours d'ici !! Bref, je ne veux plus rien avoir à faire avec vous. Adieu, "+ GetSexPhrase("Baron", "Baronne") +"...";
			link.l1 = "Adieu, monsieur, et mes salutations ferventes au marquis de Bonrepos...";
            link.l1.go = "exit";
			sld = characterFromId("SoleiRoyalCaptain");
			RemoveCharacterCompanion(pchar, sld);
			sld.LifeDay = 0;
			pchar.questTemp.State = "QuestLineBreake";
			CloseQuestHeader("Fra_Line_9_GuardPortPax");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			bWorldAlivePause   = false; // Конец линейки
			CloseQuestHeader("Fra_Line_9_GuardPortPax");
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Repair", -270);
			AddCharacterExpToSkill(pchar, "Sneak", -200);
			AddCharacterExpToSkill(pchar, "FencingLight", -230);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -230);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence parce que vous avez manqué le rendez-vous à Port-au-Prince et que la ville a été ravagée par les Espagnols. C'est bien fait pour vous !", FRANCE, 5, 1);
        break;
        //********************** Квест №10. Захват Санто-Доминго ************************
		case "Step_10_1":
            dialog.text = "Il est temps de donner une réponse adéquate à la tentative de prise de Port-au-Prince. Et il me semble que la meilleure réponse serait de réaliser le plan espagnol de conquête d'Hispaniola, mais à l'envers...";
			link.l1 = "Monsieur le gouverneur général, je vous prie de parler moins fleuri.";
            link.l1.go = "Step_10_2";
        break;
		case "Step_10_2":
            dialog.text = "D'accord, "+ GetSexPhrase("Baron", "Baronne") +". Je vous charge donc de prendre Santo Domingo ! Ainsi, Hispaniola tout entière appartiendra à une seule puissance, non pas à l'Espagne, mais à la France. Vous comprenez maintenant ?";
			link.l1 = "Je vois, monsieur. Dites-moi, qu'en est-il du paiement de cette opération militaire ? Je ne peux pas entretenir le Soleil Royal et faire la guerre à mes frais !";
            link.l1.go = "Step_10_3";
        break;
		case "Step_10_3":
            dialog.text = "Oui, je comprends. La question est pour ainsi dire réglée : après la prise de Santo Domingo, vous recevrez une récompense très importante.";
			link.l1 = "Eh bien, monsieur, je vous crois. Je commence donc l'opération ; attendez-moi avec de bonnes nouvelles.";
            link.l1.go = "exit";
    		pchar.questTemp.State = "Fr10OccupySD_toSantoDomingo";
            AddQuestRecord("Fra_Line_10_OccupySantoDomingo", "1");
			CloseQuestHeader("Fra_Line_12_EndOfWar");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			characters[GetCharacterIndex("SantoDomingo_Mayor")].dialog.captureNode = "FraLine10Quest_OccupySD"; //капитулянтская нода мэра
        break;
		case "Step_10_4":
            dialog.text = "Vous avez perdu le Soleil Royal !!";
			link.l1 = "La bataille a été chaude, monsieur le gouverneur général, et ce beau navire a bel et bien sombré. J'en suis vraiment désolé...";
            link.l1.go = "Step_10_5";
        break;
		case "Step_10_5":
            dialog.text = "Je n'ai que faire de vos regrets. La perte de ce navire est une terrible tragédie pour la France. C'est pourquoi je ne veux plus avoir affaire à vous : le gouvernement français ne vous confiera plus rien. Adieu.";
			link.l1 = "Hum, comme vous voudrez, monsieur...";
            link.l1.go = "exit";
			CloseQuestHeader("Fra_Line_10_OccupySantoDomingo");
			pchar.questTemp.State = "QuestLineBreake";
			CloseQuestHeader("Fra_Line_12_EndOfWar");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			bWorldAlivePause   = false; // Конец линейки
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", -170);
			AddCharacterExpToSkill(pchar, "Sneak", -100);
			AddCharacterExpToSkill(pchar, "FencingLight", -130);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -130);
			AddCharacterExpToSkill(pchar, "Fencing", -130);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence parce que vous avez réussi à couler le Soleil Royal. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_10_6":
            dialog.text = "Très bien, "+ GetSexPhrase("mon ami", "mademoiselle") +", c'est tout simplement formidable !"+
				          " Maintenant, parlons d'un sujet qui vous tient à cœur : la rétribution. J'ai réussi à obtenir du budget une somme inouïe pour financer votre expédition : 40 mille pièces d'or... Elles sont à vous, "+ GetSexPhrase("Baron", "Baronne") +" !";
			link.l1 = "Excellent, monsieur le gouverneur général. C'est déjà bien mieux !";
            link.l1.go = "Step_10_7";
        break;
		case "Step_10_7":
            dialog.text = "Je suis très content que cela vous convienne... Eh bien, je n'ose pas vous retenir plus longtemps ; je vous prie de commencer à vous préparer pour une nouvelle affaire. Remettez votre escadre en ordre et soyez chez moi dans un mois environ, "+ GetSexPhrase("Baron", "Baronne") +".";
			link.l1 = "Très bien, monsieur le gouverneur général, je serai là à temps.";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 40000);
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "30";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "11";
			CloseQuestHeader("Fra_Line_10_OccupySantoDomingo");
			AddTitleNextRate(sti(NPChar.nation), 3);
			ChangeCharacterReputation(pchar, 7);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Pistol", 330);
			AddCharacterExpToSkill(pchar, "Fortune", 360);
			AddCharacterExpToSkill(pchar, "Accuracy", 320);
			AddCharacterExpToSkill(pchar, "Grappling", 350);
			AddCharacterExpToSkill(pchar, "Defence", 350);
			//слухи
			AddSimpleRumour("On dit que vous avez pris Santo Domingo ! Beau travail, capitaine, tout simplement formidable !", FRANCE, 5, 1);
        break;
        //********************** Квест №11. Захват Санта-Каталины ************************
		case "Step_11_1":
            dialog.text = "C'est vrai, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
			link.l1 = "Compris... Et quelle ville deviendra française d'ici quelque temps ?";
            link.l1.go = "Step_11_2";
        break;
		case "Step_11_2":
            dialog.text = "Santa Catalina, sur le Continent. Cette ville contrכle les pêcheries de perles de la cכte ouest du Nouveau Monde. Le gouvernement français estime que l'exploitation des perles nous sera très utile en ce moment...";
			link.l1 = "Je suis tout à fait d'accord avec le gouvernement français. Je suis prêt à mener cette opération. Je commence immédiatement.";
            link.l1.go = "exit";
    		pchar.questTemp.State = "Fr11OccupySC_toSantaCatalina";
            AddQuestRecord("Fra_Line_11_OccupySantaCatalina", "1");
			characters[GetCharacterIndex("SantaCatalina_Mayor")].dialog.captureNode = "FraLine11Quest_OccupySC"; //капитулянтская нода мэра
        break;
		case "Step_11_3":
            dialog.text = "Diable, c'est très, très fâcheux. La perte de ce navire rend impossible toute coopération future entre nous.";
			link.l1 = "Il vous est donc si cher ?";
            link.l1.go = "Step_11_4";
        break;
		case "Step_11_4":
            dialog.text = "Il ne s'agit même pas de moi : le Soleil Royal est la fierté de la Marine royale française. Ce chef-d'œuvre de la construction navale vous a été confié, sur la foi de vos capacités de chef naval. Vous n'avez pas justifié cette haute confiance, je dois donc vous refuser toute coopération future.";
			link.l1 = "Eh bien, soit. J'en avais assez, moi aussi, de missions totalement non financées. Adieu, monsieur.";
            link.l1.go = "Step_11_2";
			CloseQuestHeader("Fra_Line_11_OccupySantaCatalina");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			pchar.questTemp.State = "QuestLineBreake";
			bWorldAlivePause   = false; // Конец линейки
			DeleteAttribute(pchar, "TempPerks.QuestTroopers"); //снятия перка квестового десанта
			AddCharacterExpToSkill(pchar, "Repair", -550);
			AddCharacterExpToSkill(pchar, "Pistol", -530);
			AddCharacterExpToSkill(pchar, "Fortune", -560);
			AddCharacterExpToSkill(pchar, "Accuracy", -520);
			AddCharacterExpToSkill(pchar, "Grappling", -550);
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence parce que vous avez réussi à faire couler le Soleil Royal. Hé, c'est bien fait pour vous...", FRANCE, 5, 1);
        break;
		case "Step_11_5":
            dialog.text = "Excellent ! Vous avez une fois de plus prouvé que la confiance placée en vous est entièrement justifiée.";
			link.l1 = "Monsieur le gouverneur général, qu'en est-il du financement de l'opération ?";
            link.l1.go = "Step_11_6";
        break;
		case "Step_11_6":
            dialog.text = "D'autres questions ?";
			link.l1 = "Je voulais discuter de ma participation à l'exploitation des pêcheries de perles, monsieur...";
            link.l1.go = "Step_11_7";
        break;
		case "Step_11_7":
            dialog.text = "C'est impossible, "+ GetSexPhrase("monsieur", "mademoiselle") +". Cette question relève de Jean-Baptiste Colbert, le Premier ministre de la France ! "+ GetSexPhrase("Baron", "Baronne") +", il n'est pas bon de s'enrichir au moment oם la France fournit des efforts surhumains dans cette guerre.";
			link.l1 = "Hum, vous avez peut-être raison, monsieur...";
            link.l1.go = "Step_11_8";
        break;
		case "Step_11_8":
            dialog.text = "Eh bien, je suis sincèrement content que nous nous comprenions bien. "+ GetSexPhrase("Baron", "Baronne") +", je n'ose pas vous retenir maintenant ; je vous prie de remettre votre escadre en ordre et de vous préparer à de nouveaux exploits pour le bien de la France et de notre grand Roi-Soleil !";
			link.l1 = "Monsieur le gouverneur général, je me conformerai à votre demande. א plus tard.";
            link.l1.go = "exit";
            pchar.questTemp.State = "empty";
			pchar.questTemp.Waiting_time = "10";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "12";
			DeleteAttribute(pchar, "TempPerks.QuestTroopers"); //снятия перка квестового десанта
			CloseQuestHeader("Fra_Line_11_OccupySantaCatalina");
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 6);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			AddCharacterExpToSkill(pchar, "Pistol", 430);
			AddCharacterExpToSkill(pchar, "Fortune", 460);
			AddCharacterExpToSkill(pchar, "Accuracy", 420);
			AddCharacterExpToSkill(pchar, "Grappling", 450);
			//слухи
			AddSimpleRumour("Le bruit court que vous avez pris Santa Catalina. Et qu'ensuite, vous avez essayé d'obtenir de d'Ogeron une part des pêcheries de perles. Hé, on appelle ça avoir les yeux plus gros que le ventre...", FRANCE, 5, 1);
        break;
        //********************** Квест №12. Завершение линейки ************************
		case "Step_12_1":
            dialog.text = "Vous avez vous aussi contribué à cette victoire. En fait, c'est vous qui avez assuré la défaite décisive des forces espagnoles dans les Caraïbes\n"+
				          "Jean-Baptiste Colbert a souligné vos actions réussies lors de son rapport au Louvre : votre nom est désormais connu de Louis XIV lui-même !";
			link.l1 = "Voilà qui me fait très, très plaisir. Dites-moi, monsieur, y a-t-il des récompenses en argent pour les résultats de la guerre ?";
            link.l1.go = "Step_12_2";
        break;
		case "Step_12_2":
            dialog.text = "Je n'en sais rien. Cependant, nous pouvons poser cette question au marquis de Bonrepos. Votre prochaine mission est de vous rendre à Basse-Terre, à la Guadeloupe, et d'y rencontrer le marquis. Il vous attend.";
			link.l1 = "Excellent, monsieur ! Je ne manquerai pas cette occasion... Je pars immédiatement.";
            link.l1.go = "Step_12_3";
        break;
		case "Step_12_3":
            dialog.text = "Et remettez le Soleil Royal en état : il doit être prêt au combat.";
			link.l1 = "Très bien, monsieur.";
            link.l1.go = "exit";
			pchar.questTemp.State = "Fr12EndWar_toBorepo";
			AddQuestRecord("Fra_Line_12_EndOfWar", "1");
			//==> маркиз Бонрепо.
            sld = GetCharacter(NPC_GenerateCharacter("Bonrepo", "huber_fra", "man", "man", 20, FRANCE, -1, false));
            sld.Dialog.Filename    = "Quest\FraLineNpc_1.c";
        	sld.name 	= "Marquis";
        	sld.lastname 	= "Bonrepo";
			LAi_SetStayType(sld);
			LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
			ChangeCharacterAddressGroup(sld, "BasTer_townhall", "goto", "governor1");
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
