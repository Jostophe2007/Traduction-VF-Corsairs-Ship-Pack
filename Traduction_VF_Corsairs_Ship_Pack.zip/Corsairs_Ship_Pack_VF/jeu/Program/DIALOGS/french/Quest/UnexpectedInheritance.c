void ProcessDialogEvent()
{
	ref locLoad = &locations[reload_location_index];
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;
	int i;
	bool hungry = true;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":

			//dialog.text = "Error";
			link.l1 = "...";
			link.l1.go = "Exit";
			npchar.quest.meeting = "1";

			if (npchar.id == "CrazyScientist")
			{
				dialog.text = "Allez, attends !";
				link.l1.go = "CS";
			}
			NextDiag.TempNode = "First time";
		break;

		case "GrottoSkeleton":
			scareOfficers(70);
			InterfaceStates.Buttons.Save.enable = false;
			LAi_SetImmortal(npchar, false);
			dialog.Text = "Tu es venu mêler tes os aux nכtres ?";
			Link.l1 = "Qui êtes-vous ?";
			Link.l1.go = "GrottoSkeleton_1";
		break;
		case "GrottoSkeleton_1":
			dialog.Text = "Maudit perdant ! Voilà ce que je suis ! Papa nous a laissé ses trésors, à mon frère et à moi, mais au lieu de partager et d'oublier, il a décidé que nous étions encore des enfants et que son idée de chasse au trésor nous rapprocherait. Eh bien, nous nous sommes tellement rapprochés qu'on ne pourrait pas l'être plus !";
			Link.l1 = "J'ai suivi tous ses indices, ils sont intacts, ou presque. Comment es-tu arrivé ici ?";
			Link.l1.go = "GrottoSkeleton_2";
		break;
		case "GrottoSkeleton_2":
			dialog.Text = "Luigi était un gars malin et sournois, il se faufilait dans le bureau de son père et étudiait attentivement ses notes. Et quand le vieux est mort, il est aussitכt venu ici. Eh bien, moi, j'ai interrogé les domestiques avec passion et je l'ai suivi.";
			Link.l1 = "Mais quelque chose a mal tourné ?";
			Link.l1.go = "GrottoSkeleton_3";
		break;
		case "GrottoSkeleton_3":
			dialog.Text = "Tout a mal tourné. Je l'ai surpris en train d'ouvrir un coffre et je lui ai tiré une balle dans la tête. Le fracas du coup de feu a fait s'effondrer le plafond de la grotte, et je me suis retrouvé écrasé contre le cadavre de mon demi-frère. Alors, je suis resté couché dans le noir, le visage dans la bouillie qu'était devenue sa tête. Puis je suis mort. Et maintenant, te voilà.";
			Link.l1 = "Un sort terrible, mais un fratricide ne mérite pas moins ! Meurs encore une fois !";
			Link.l1.go = "exit_fight";
		break;

		case "GrottoPirate":
			dialog.Text = "Quelqu'un a vendu la mèche sur notre destination ? Tout le monde au couteau ! Fils de chiennes !";
			Link.l1 = "...";
			Link.l1.go = "exit_fight_grotto";
		break;

		case "Girl":
			dialog.Text = GetSexPhrase("Monsieur", "Madame") + ", excusez-moi, vous êtes capitaine ?";
			Link.l1 = "Capitaine, oui, mais je n'achète rien et je ne fais l'aumכne qu'à l'église, le dimanche.";
			Link.l1.go = "Girl_1";
		break;
		case "Girl_1":
			dialog.Text = "Non, "+GetSexPhrase("monsieur", "madame")+", je ne suis pas une mendiante, écoutez-moi, je vous en prie ! Mon beau-père, capitaine lui aussi, un corsaire au service de la France, il...";
			Link.l1 = "Une belle journée, une jeune demoiselle qui demande de l'aide : ça ressemble au début d'une aventure. Je vous écoute.";
			Link.l1.go = "Girl_2";
			Link.l2 = "Il va sans doute vous gronder de parler à des inconnus. Désolé, mais j'ai une affaire urgente !";
			Link.l2.go = "Exit_cancel";
		break;
		case "Girl_2":
			dialog.Text = "Merci, capitaine. Mon beau-père a rendu son âme à Dieu il y a trois jours, laissant ma mère, mes deux frères et moi complètement sans ressources. Son sloop était hypothéqué auprès d'un usurier, et on l'a saisi pour dettes.";
			Link.l1 = "Mademoiselle, j'aurais aimé vous aider, mais j'ai des choses à faire...";
			Link.l1.go = "Girl_3";
		break;
		case "Girl_3":
			dialog.Text = "Attendez, je vous en prie. Avant de mourir, mon beau-père a remis ce journal à ma mère, il a parlé d'un héritage et a rendu l'âme. J'ai fréquenté l'école de la paroisse, je sais un peu lire et écrire, mais ici, c'est une sorte de langue incompréhensible. Peut-être que l'endroit oם il a caché le trésor est indiqué ici ! C'était un corsaire !";
			Link.l1 = "Ou alors, c'est un recueil de chansons de marins obscènes...";
			Link.l1.go = "Girl_4";
		break;
		case "Girl_4":
			dialog.Text = "Capitaine, je vous en prie !";
			if (sti(pchar.money) >= 7000)
			{
				Link.l1 = "Bon, je vous achète ce journal. Cinq mille, ça suffit ? Bon, prenez-en sept, j'espère que ça aidera votre famille pour commencer. Tenez...";
				Link.l1.go = "Girl_5";
			}
			Link.l2 = "דa ne m'intéresse pas. Au revoir.";
			Link.l2.go = "Exit_cancel";
		break;
		case "Girl_5":
			dialog.Text = "Merci infiniment, capitaine ! Voici le journal.";
			AddMoneyToCharacter(PChar, -7000);
			SetQuestHeader("UnexpectedInheritance");
			AddQuestRecord("UnexpectedInheritance", "1");
			AddQuestUserData("UnexpectedInheritance", "sSex", GetSexPhrase("", "e"));
			pchar.UnexpectedInheritance = "part1";
			Link.l1 = "Bon, nous le lirons à loisir.";
			Link.l1.go = "Girl_done";
		break;
		case "Girl_done":
			DialogExit();			
			npchar.lifeday = 0;
			LAi_SetCitizenType(npchar);
			LAi_CharacterDisableDialog(npchar);
		break;

		case "Exit_cancel":
			NextDiag.TempNode = "Girl";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;


		case "exit_fight":
			locLoad = &locations[reload_location_index];
			locLoad.box1.items.indian11 = 1;
			locLoad.box1.items.jewelry1 = 5;
			locLoad.box1.items.jewelry2 = 10;
			locLoad.box1.items.jewelry3 = 15;
			locLoad.box1.items.jewelry4 = 20;
			locLoad.box1.items.jewelry5 = 25;
			locLoad.box1.items.jewelry6 = 30;
			locLoad.box1.items.jewelry7 = 35;
			SetSkeletonsToLocation(&locations[reload_location_index]);
			AddDialogExitQuest("MainHeroFightModeOn");
			//LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			LAi_SetImmortal(npchar, false);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();
		break;

		case "exit_fight_grotto":
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			//LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);;
			for (i = 1; i <= MOD_SKILL_ENEMY_RATE; i++)
			{
				sld = CharacterFromID("UI_pirate"+i)
				LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			}
			LAi_SetImmortal(npchar, false);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();
		break;
	}
}

