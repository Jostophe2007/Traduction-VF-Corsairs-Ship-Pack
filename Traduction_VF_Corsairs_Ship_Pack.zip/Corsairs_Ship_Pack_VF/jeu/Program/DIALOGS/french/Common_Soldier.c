// boal 25/04/04 общий диалог солдат
void ProcessDialogEvent()
{
	int bribe_price = sti(PChar.rank) * (500) * (0.01 * (160 - GetSummonSkillFromName(PChar, SKILL_COMMERCE)));

	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Soldier\" + NPChar.City + "_Soldier.c";
    if (!HasCityDialogFile("Soldier", NPChar.City, "_Soldier.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Soldier\DefaultCity_Soldier.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Soldier\DefaultCity_Soldier.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
    int iTest, iTemp;
	string sTemp;
    iTest = FindColony(NPChar.City); // город
    ref rColony;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			sTemp = npchar.location;
			if (findsubstr(sTemp, "_townhall" , 0) != -1) AddDialogExitQuest("MainHeroFightModeOff");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "First time":
            NextDiag.TempNode = "First time";
			// заглушка на нежить
			if (pchar.sex == "Skeleton" && GetCharacterEquipSuitID(pchar)!= "suit_1")
			{
				dialog.text = RandPhraseSimple("Des morts-vivants en ville ?! Aux armes !!!", "Périssez, esprits du mal !!!");
				link.l1 = "Pour cette audace, je vais prendre ton âme, imbécile !";
				link.l1.go = "fight";
				break;
			}
			// самовоз казённого конвоя (сделка с посыльным-агентом): солдат нации-адресата узнаёт ГГ по опознавательному флагу - пропускает с почётом
			if (FortAgent_LandGraceIdx(sti(NPChar.index)))
			{
				if (CheckAttribute(pchar, "FortAgentDeliver.delivered")) // cargo already handed to the commandant - different lines (during the +1 day grace before cleanup)
					dialog.text = LinkRandPhrase(
						"Ah, le capitaine du convoi de poudre ! Votre affaire avec le commandant est réglée : bon voyage, je ne vous retiens pas.",
						"C'est vous qui avez amené le convoi au commandant ? Tout est en ordre. Bonne route, capitaine.",
						"Nous sommes au courant : vos affaires au fort sont terminées. La voie est libre, capitaine, bon vent.");
				else
					dialog.text = LinkRandPhrase(
						"Ah, c'est donc vous qui amenez le convoi de poudre et de munitions au commandant ! Sous le pavillon convenu, comme prévu. Passez, capitaine, on vous attend au fort.",
						"Un capitaine avec le convoi de poudre pour la garnison ? On nous a prévenus : vous arborez les couleurs convenues, comme annoncé. La route jusqu'au commandant est libre, je ne vous retiens pas.",
						"Ah, ce convoi-là ! On a repéré votre flamme depuis la mer. Passez, capitaine, le commandant attend ses munitions depuis longtemps.");
				link.l1 = LinkRandPhrase("Bien obligé, soldat.", "Bon service, soldat.", "Merci. Portez-vous bien.");
				link.l1.go = "exit";
				break;
			}
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
				// заглушка на пирата
				if (sti(pchar.nation) == PIRATE)
				{
    				dialog.text = RandPhraseSimple("Des pirates en ville ?! דa y est... Sus à "+ GetSexPhrase("lui", "elle") +" !!!", "C'est un pirate !! Sus à "+ GetSexPhrase("lui", "elle") +" !!!");
					link.l1 = RandPhraseSimple("Pirate, et alors...", "Hé, essayez donc de m'attraper.");
					link.l1.go = "fight";
					break;
				}
				dialog.text = RandPhraseSimple("Un espion ? Rendez vos armes !! Suivez-moi !", "Agent ennemi ! Sus à "+ GetSexPhrase("lui", "elle") +" !");
				link.l1 = RandPhraseSimple("Ferme-la, petit idiot !", "Qu'importe !");
				link.l1.go = "fight";
				// ==> eddy. Засада, если опознали в инквизиции.
				if (Pchar.location == "Santiago_Incquisitio") StartIncquisitioAttack();
			}
			else
			{
				// eddy. проверяем, не казачок ли. -->
				if (GetNationRelation(sti(NPChar.nation), GetBaseHeroNation()) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
				{
					dialog.text = RandPhraseSimple("Qui êtes-vous et que voulez-vous ici ?", "Halte ! Qui êtes-vous ? א quel titre essayez-vous d'entrer en ville ?");
					//==> по лицензии
					if (CheckNationLicence(sti(npchar.nation)))
					{
						link.l1 = "Officier, j'ai " + GetRusNameNationLicence(sti(npchar.nation)) + ", je suis donc ici en toute légalité. Veuillez en prendre connaissance...";
						link.l1.go = "LicenceOk";
						if (findsubstr(pchar.location.from_sea, "_town" , 0) != -1) //если причалил в городе
						{
							link.l2 = "Vous ne voyez donc pas que le pavillon de " + NationNameGenitive(sti(pchar.nation)) + " flotte sur mon navire ?!";
						}
						else //если причалил не в городе
						{
							link.l2 = "J'ai jeté l'ancre près de " + XI_ConvertString(GetIslandByCityName(npchar.city)+"Gen") + " sous le pavillon de " + NationNameGenitive(sti(pchar.nation)) + ". Qu'est-ce que vous ne comprenez pas ?";
						}
						if (GetSummonSkillFromName(pchar, SKILL_SNEAK) < (10+rand(50)+rand(50)))
						{
							link.l2.go = "PegYou";
						}
						else
						{
							link.l2.go = "NotPegYou";
						}
					}
					else
					{
						//==> по флагу
						// заглушка на пирата
						if (sti(pchar.nation) == PIRATE)
						{
    						dialog.text = RandPhraseSimple("Des pirates en ville ?! דa y est... Attrapez-le !!", "C'est un pirate !! Arrêtez-le !!!");
							link.l1 = RandPhraseSimple("Oui, pirate, et alors...", "Hé, essayez donc de m'attraper...");
							link.l1.go = "fight";
							break;
						}
						if (findsubstr(pchar.location.from_sea, "_town" , 0) != -1) //если причалил в городе
						{
							link.l1 = "Vous ne voyez donc pas que le pavillon de " + NationNameGenitive(sti(pchar.nation)) + " flotte sur mon navire ?!";
						}
						else //если причалил не в городе
						{
							link.l1 = "J'ai jeté l'ancre près de " + XI_ConvertString(GetIslandByCityName(npchar.city)+"Gen") + " sous le pavillon de " + NationNameGenitive(sti(pchar.nation)) + ". Qu'est-ce que vous ne comprenez pas ?";
						}
						if (GetSummonSkillFromName(pchar, SKILL_SNEAK) < (10+rand(50)+rand(50)))
						{
							link.l1.go = "PegYou";
						}
						else
						{
							link.l1.go = "NotPegYou";
						}
					}
				}
				// <-- eddy. проверяем, не казачок ли.
				else
				{
					if (sti(NPChar.nation) == PIRATE)
					{
						if (sti(rColony.HeroOwn) == true) // наш горожанин
						{
			         		switch (rand(10))
							{
								case 0:
									dialog.text = "Eh, capitaine, qu'on était bien avec vous en mer ! Combien de navires on a coulés sous vos ordres ! Et ici...";
									link.l1 = "Et ici, mon ami, tu as sans cesse sous les yeux de charmantes femmes, comme on n'en voit jamais en mer.";
									link.l1.go = "exit";
								break;

								case 1:
									dialog.text = "Capitaine, pourquoi cette punition ?! On n'est pas des rats de terre !";
									link.l1 = "Du calme, matelot ! Tu occupes un poste important et honorable, alors arrête de geindre.";
									link.l1.go = "exit";
								break;

								case 2:
									dialog.text = "Comment ça se passe en mer, capitaine ? On la reverra un jour ?";
									link.l1 = "Bien sמr, matelot ! Fais-toi relever de ta garde, va sur le quai et profite de la mer autant que tu veux.";
									link.l1.go = "exit";
								break;

								case 3:
									dialog.text = "Je dois me plaindre, capitaine : on veut tous retourner en mer. Ce service à terre nous reste en travers de la gorge !";
									link.l1 = "J'en ai assez de ces jérémiades ! Vous avez assez de gnכle à terre ! Servez là oם le capitaine vous a mis ! Sinon, il faudra en pendre un pour l'exemple.";
									link.l1.go = "exit";
								break;

								case 4:
									dialog.text = "Je vais vous confier un secret, capitaine : le nouveau gouverneur est un concussionnaire et un voleur. Mais bien sמr, ce ne sont pas mes affaires...";
									link.l1 = "Tu as raison, corsaire : ton travail, c'est de monter la garde et de maintenir l'ordre. Quant à pendre le gouverneur à une vergue, c'est mon affaire. Bien joué !";
									link.l1.go = "exit";
								break;

								case 5:
									dialog.text = "Merci de ne pas nous oublier, capitaine ! On vous suivra dans le feu et dans l'eau !";
									link.l1 = "Je vous connais, bande de canailles ! Vous n'aimez que l'or. Ce soir, on fait la fête à la taverne, c'est moi qui régale. N'oubliez pas de passer.";
									link.l1.go = "exit";
								break;

								case 6:
									dialog.text = "Eh, capitaine ! דa fait longtemps qu'on n'a pas eu un vrai combat sanglant ! Des corsaires qui jouent les gendarmes, non mais !";
									link.l1 = "Ne te relâche pas, corsaire ! Des armadas ennemies rכdent autour de nos îles, un bain de sang peut éclater à tout moment.";
									link.l1.go = "exit";
								break;

								case 7:
									dialog.text = "Capitaine, on dit que les autorités royales envoient encore une escadre par ici ?";
									link.l1 = "Bien sמr, corsaire. Tant que nous serons en vie, il n'y aura jamais de paix. Et même en enfer, nous nous battrons contre les diables !";
									link.l1.go = "exit";
								break;

								case 8:
									dialog.text = "Yo-ho-ho ! Quelle fête on a faite hier, capitaine ! Dommage que vous n'ayez pas été là.";
									link.l1 = "Peu importe, je me rattraperai. Et je ne vous envie pas, les gars.";
									link.l1.go = "exit";
								break;

								case 9:
									dialog.text = "Je vais vous confier un secret, capitaine, puisque vous ne nous avez jamais fait de tort : hier, avec les gars, on a fait la fête avec une poulette ici...";
									link.l1 = "Eh, corsaire, la corde te réclame !";
									link.l1.go = "exit";
								break;

								case 10:
									dialog.text = "Capitaine ! Libérez-moi de ce maudit service ! Je ne peux pas jouer les gardiens de la loi ici !";
									link.l1 = "Rappelle-toi plutכt que ce n'est pas facile non plus de prendre le quart de nuit sur un navire. Le service, mon frère, c'est le service partout.";
									link.l1.go = "exit";
								break;
							}
							link.l2 = RandPhraseSimple("J'ai une affaire importante !", "J'ai une affaire pour vous.");
							link.l2.go = "quests";//(перессылка в файл города)
							break;
						}
						else
						{ // пираты, не наши
							dialog.text = LinkRandPhrase(RandPhraseSimple("Vous avez affaire à moi, capitaine ?", "Je suis ici pour affaires ; si vous avez besoin de quelque chose, demandez, ne traînez pas."), RandPhraseSimple("Capitaine, je suis très occupé, alors cherchez d'autres interlocuteurs.", "Quelque chose ne va pas, capitaine ? Si vous n'avez pas de questions, laissez-moi passer."), "וcartez-vous, capitaine, je suis pressé.");
							link.l1 = LinkRandPhrase("Désolé, l'ami, je me suis trompé.", "D'accord, occupe-toi de tes affaires.", "Non, rien.");
							link.l1.go = "exit";
							link.l2 = LinkRandPhrase(RandPhraseSimple("J'ai quelques questions à vous poser.", "J'ai une affaire pour vous."), RandPhraseSimple("Je vois que vous êtes pressé. Une question, et vous serez libre.", "Je voulais vous demander quelque chose."), "Vos affaires attendront. J'ai une question à vous poser.");
							link.l2.go = "quests";//(перессылка в файл города)
							break;
						}
					}
					else
					{ //если негодяй, имеющий НЗГ к дружественной или нейтральной нации
						if (ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 0) <= -15)
						{
							dialog.text = RandPhraseSimple("Voyez-moi ça, "+ GetSexPhrase("quel salaud ! Il a osé", "quelle garce ! Elle a osé") +" se montrer à " + XI_ConvertString("Colony" + npchar.city)+ ". Sus à "+ GetSexPhrase("lui", "elle") +" !!", "Ha, je t'ai reconnu, gredin ! Sus à "+ GetSexPhrase("lui", "elle") +" !!");
							link.l1 = RandPhraseSimple("Argh !..", "Eh bien, tu l'auras voulu...");
							link.l1.go = "fight";
							break;
						}
					}
					//зачарованный город -->
					if (pchar.questTemp.MC == "toCaracas" && npchar.city == "Caracas")
					{
						dialog.text = LinkRandPhrase("Vous voyez ce qui se passe en ville ? Mais nous ne nous mêlerons de rien...",
							"Tant que les troubles ne tournent pas au pillage, nous ne ferons rien. Laissons-les se bagarrer.",
							"Nous faisons comme si tout était normal en ville. Il ne faut pas céder à l'humeur de la foule, sinon les troubles risquent de tourner à l'émeute !");
						link.l1 = "Je vois...";
						link.l1.go = "exit";
						break;
					}
					if (pchar.questTemp.MC == "toCaracasPadre" || pchar.questTemp.MC == "toCaracasTavern")
					{
						dialog.text = "Vous êtes allé à la taverne. Et qu'en dites-vous ?";
						link.l1 = "Rien pour l'instant...";
						link.l1.go = "exit";
						break;
					}
					//<-- зачарованный город
					// --> девица в джунглях
					if(rand(2) == 1 && CheckAttribute(pchar, "GenQuest.EncGirl") && CheckAttribute(pchar, "GenQuest.EncGirl.MeetSoldiers"))
					{
						if(sti(pchar.GenQuest.EncGirl.MeetSoldiers) == 1)
						{
							dialog.text = "Oh, voyez qui voilà ! " + pchar.GenQuest.EncGirl.name + " en personne est venue nous voir ! Et comment avez-vous osé ? Nous vous cherchions déjà ! Veuillez vous rendre au cachot, votre cellule est prête depuis longtemps et n'attend plus que vous.";
							link.l1 = "De quoi parlez-vous ?! Vous faites erreur ! Je me promenais avec "+ GetSexPhrase("mon galant", "mon amie") +" dans la jungle, nous cueillions des fleurs. Lâchez-moi ! Quelles manières ont donc ces soldats ?! Dès qu'ils voient une jolie fille, ils trouvent aussitכt un prétexte pour s'accrocher à elle ! "+ GetSexPhrase("Mon chéri, dis à ces lourdauds de s'en aller et de ne pas importuner une honnête dame", "Ma chérie, dis à ces lourdauds...") +" !";
							link.l1.go = "GirlEnc_1";
						}
						if(sti(pchar.GenQuest.EncGirl.MeetSoldiers) == 2)
						{
							dialog.text = "Vous voilà, ma belle. Vous êtes venue toute seule ! Votre papa a mis toute la garnison sur le pied de guerre, il nous a ordonné de vous retrouver et de vous ramener à la maison.";
							link.l1 = "Lâchez-moi ! Je sais oם je vais et je n'ai pas besoin de votre aide !.. Capitaine, dites-leur d'enlever leurs mains.";
							link.l1.go = "GirlEnc_2";
						}
						DeleteAttribute(pchar, "GenQuest.EncGirl.MeetSoldiers");
					}
					// <-- девица в джунглях

					switch (rand(10))
					{
						case 0: ////////////////////////////////////////
							dialog.text = "Le règlement du service de garde ne me permet pas de bavarder avec les passants.";
							link.l1 = "Bravo, soldat ! Continue comme ça.";
							link.l1.go = "exit";
						break;

						case 1:
							dialog.text = "Quelque chose ne va pas ? Vous avez remarqué des troubles ?";
							link.l1 = "Non, tout va bien. Mais votre vigilance est louable.";
							link.l1.go = "exit";
						break;

						case 2: ///////////////////////////////////////////
							dialog.text = "Les bagarres et les duels sont interdits dans les rues de la ville. On ne peut tirer l'arme qu'en cas de danger.";
							link.l1 = "D'accord, j'en tiendrai compte.";
							link.l1.go = "exit";
						break;

						case 3:
							dialog.text = "Oh, quel temps ! Et moi, je suis planté là comme une statue... Je ne fais que chasser les mouches.";
							link.l1 = RandPhraseSimple("Ne te relâche pas, soldat. L'ennemi ne dort pas.", "Ce n'est pas bien de se plaindre du service. Avec un tel état d'esprit, tu n'iras pas loin au combat.");
							link.l1.go = "exit";
						break;

						case 4: ///////////////////////////////////////////
							dialog.text = "Cherchez un autre interlocuteur si vous voulez bavarder : j'ai reçu l'ordre de maintenir l'ordre, pas de jacasser.";
							link.l1 = "Bravo, soldat, tu sers bien ! Seulement, tu es trop grossier.";
							link.l1.go = "exit";
						break;

						case 5: ////////////////////////////////////////////
							dialog.text = "Maintenir l'ordre, je vous le dis, ce n'est pas aussi facile qu'on pourrait le croire vu de l'extérieur. C'est un travail très exigeant et dangereux. Une fois, à la garnison...";
							link.l1 = LinkRandPhrase("Ne te laisse pas distraire à ton poste.", "Qu'est-ce que c'est que ces bavardages en service ?!", "Reste à ton poste. Tu bavarderas à la taverne.");
							link.l1.go = "exit";
						break;

						case 6: ////////////////////////////////////////////
							dialog.text = RandPhraseSimple("Ne me distrayez pas, " + GetAddress_Form(NPChar) + ", je suis de service.", "Passez votre chemin, " + GetAddress_Form(NPChar) + ", ne distrayez pas la sentinelle de son service.");
							link.l1 = "Je voulais juste "+ GetSexPhrase("vérifier", "vérifier") +" si vous ne vous étiez pas endormi en faction. Vous êtes planté là comme une statue.";
							link.l1.go = "exit";
						break;

						case 7:
							dialog.text = "Hé, " + GetAddress_Form(NPChar) + " Vous n'auriez pas deux gorgées de vin pour me rincer le gosier ? Je meurs de soif.";
							link.l1 = "Le service, c'est le service. Patiente jusqu'à la relève.";
							link.l1.go = "exit";
						break;

						case 8://///////////////////////////////////////////
							dialog.text = ""+ GetSexPhrase("Vous n'êtes pas le premier marin à vouloir me distraire de mon service. Pourquoi ce ne sont jamais d'appétissantes veuves qui viennent me voir", "Hé, la belle ! Que diriez-vous d'un petit flirt avec ce brave soldat") +" ?";
							link.l1 = RandPhraseSimple("Tu as oublié que tu es de service, pas au bordel.", "Ton travail, c'est de maintenir l'ordre... et de ravaler ta bave.");
							link.l1.go = "exit";
						break;

						case 9://///////////////////////////////////////////
							dialog.text = ""+ GetSexPhrase("Vous avez l'air d'un dur à cuire ! Vous ne voudriez pas vous engager ? Nous avons une caserne spacieuse, une bonne nourriture, et à boire gratuitement.", "Oh, vous ne pouvez pas imaginer, ma belle, comme c'est agréable de rencontrer une personne aussi charmante que vous dans ce trou perdu !") +"";
							link.l1 = ""+ GetSexPhrase("C'est diablement tentant, mais je dois refuser. L'exercice de caserne, ce n'est pas pour moi.", "Merci du compliment, soldat, ça me fait très plaisir.") +".";
							link.l1.go = "exit";
						break;

						case 10:
							dialog.text = "Cette chaleur... Je donnerais la moitié de ma vie pour retourner en Europe.";
							link.l1 = RandPhraseSimple("Eh bien, tu es un piètre soldat.", "Le service militaire n'est rose nulle part.");
							link.l1.go = "exit";
						break;
					}
					link.l3 = "Une minute. Je voulais vous demander...";
					link.l3.go = "quests";//(перессылка в файл города)
				}
			}
		break;
		//============================== ноды на разборки при распознавании =========================
		case "PegYou":
		if (GetQuestPastDayParam("questTemp.LastBribe") > 0 || !CheckAttribute(pchar, "BribePrice"))
		{
			SaveCurrentQuestDateParam("questTemp.LastBribe");
			pchar.BribePrice = bribe_price;
		}
		if (IsCharacterPerkOn(pchar, "Adventurer") || IsCharacterPerkOn(pchar, "Agent"))
		{
			dialog.text = RandPhraseSimple("J'ai l'impression que c'est une supercherie... Allons au bureau du commandant, "+ GetSexPhrase("mon cher", "ma chère") +", nous tirerons ça au clair là-bas...", "Hum, quelque chose me dit que vous n'êtes pas "+ GetSexPhrase("celui", "celle") +" que vous prétendez être... Rendez immédiatement votre arme, " + GetAddress_Form(npchar) + ", et suivez-moi pour la suite de la procédure !");
			link.l1 = RandPhraseSimple("Pourquoi ne me croyez-vous pas ?", "Pourquoi de telles conclusions ?");
			switch (rand(1))
			{
				case 0: link.l1.go = "NotPegYou"; break;
				else link.l1.go = "PegYou_2"; break;
			}
			if(bBribeSoldiers == true)
			{
				if(makeint(Pchar.money) >= sti(pchar.BribePrice))
				{
					link.l2 = RandPhraseSimple("Il y avait une bourse par terre, juste à cכté, ce n'était pas la vכtre ? Eh bien, elle est lourde, bon sang ! Tenez, gardez-la et ne la perdez plus. Au fait, je peux passer ?", "Vous m'avez percé à jour. En fait, je parcours simplement les Caraïbes en distribuant de l'argent à ceux qui en ont besoin. On dit que les gardes ne sont pas assez payés ? Il faut y remédier. Commençons par vous. Tenez. Tout va bien, maintenant ?");
					link.l2.go = "NotPegYou_2";
				}
			}
		}
		else
		{
			if(bBribeSoldiers == true)
			{
				if(makeint(Pchar.money) >= sti(pchar.BribePrice))
				{
					link.l2 = RandPhraseSimple("Il y avait une bourse par terre, juste à cכté, ce n'était pas la vכtre ? Eh bien, elle est lourde, bon sang ! Tenez, gardez-la et ne la perdez plus. Au fait, je peux passer ?", "Vous m'avez percé à jour. En fait, je parcours simplement les Caraïbes en distribuant de l'argent à ceux qui en ont besoin. On dit que les gardes ne sont pas assez payés ? Il faut y remédier. Commençons par vous. Tenez. Tout va bien, maintenant ?");
					link.l2.go = "NotPegYou_2";
				}
			}
			dialog.text = RandPhraseSimple("J'ai l'impression que c'est une supercherie... Allons au bureau du commandant, "+ GetSexPhrase("mon cher", "ma chère") +", nous tirerons ça au clair là-bas...", "Hum, quelque chose me dit que vous n'êtes pas "+ GetSexPhrase("celui", "celle") +" que vous prétendez être... Rendez immédiatement votre arme, " + GetAddress_Form(npchar) + ", et suivez-moi pour la suite de la procédure !");
			link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
			link.l1.go = "fight";

		}
		if (!CheckAttribute(pchar, "questTemp.stels.landSolder"))
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		break;
		case "PegYou_2":
		dialog.text = RandPhraseSimple("Ne me racontez pas d'histoires ! Rendez vos armes !", "Bon, c'est un espion, aucun doute... Rendez-vous immédiatement !");
		if(bBribeSoldiers == true)
			{

				if(makeint(Pchar.money) >= sti(pchar.BribePrice))
				{
					link.l2 = RandPhraseSimple("Il y avait une bourse par terre, juste à cכté, ce n'était pas la vכtre ? Eh bien, elle est lourde, bon sang ! Tenez, gardez-la et ne la perdez plus. Au fait, je peux passer ?", "Vous m'avez percé à jour. En fait, je parcours simplement les Caraïbes en distribuant de l'argent à ceux qui en ont besoin. On dit que les gardes ne sont pas assez payés ? Il faut y remédier. Commençons par vous. Tenez. Tout va bien, maintenant ?");
					link.l2.go = "NotPegYou_2";
				}
			}
		link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
		link.l1.go = "fight";
		if (!CheckAttribute(pchar, "questTemp.stels.landSolder"))
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		break;
		case "NotPegYou":
			dialog.text = RandPhraseSimple("Ah, je vois... C'est bon, vous pouvez passer, " + GetAddress_Form(NPChar) + ".", "Je suis un peu fatigué par la garde... C'est bon, " + GetAddress_Form(NPChar) + ", excusez-moi.");
			link.l1 = "Voilà !";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "questTemp.stels.landSolder"))
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 80);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 80);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		break;
				case "NotPegYou_2":
			dialog.text = RandPhraseSimple("Et merci pour ça, " + GetAddress_Form(NPChar) + " " + " En guise d'adieu, je vous donne un conseil gratuit : allez voir notre capitaine de port et demandez-lui un certain papier. La vie vous paraîtra tout de suite plus facile.", "Je pense qu'il y aurait bien plus de pièces dans votre bourse, " + GetAddress_Form(NPChar) + ", mais bon, je suis de bonne humeur aujourd'hui " + " En guise d'adieu, je vous donne un conseil gratuit : allez voir notre capitaine de port et demandez-lui un certain papier. La vie vous paraîtra tout de suite plus facile.");
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddMoneyToCharacter(Pchar, -sti(pchar.BribePrice));

			IncAndUnlock("AchVzyatka", 1);

			pchar.BribePrice = sti(pchar.BribePrice) * 1.33;

			if (!CheckAttribute(pchar, "questTemp.stels.landSolder"))
			{
				AddCharacterExpToSkill(pchar, SKILL_COMMERCE, 60);
				pchar.questTemp.stels.landSolder = GetDataDay();
			}
			if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
			{
				AddCharacterExpToSkill(pchar, SKILL_COMMERCE, 60);
				pchar.questTemp.stels.landSolder = GetDataDay();
			}
		break;
		case "LicenceOk":
			iTemp = GetDaysContinueNationLicence(sti(npchar.nation));
			if (iTemp == -1)
			{
				dialog.text = "Votre licence doit être retirée, car elle a expiré et n'est donc plus valable. Rendez vos armes et suivez-moi pour la suite de la procédure !";
				link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
				link.l1.go = "fight";
				TakeNationLicence(sti(npchar.nation));
				AddCharacterExpToSkill(pchar, SKILL_SNEAK, 20); // враг, которого узнали - потом будет умнее - бонус в скрытность
			}
			if (iTemp == 0)
			{
				dialog.text = "Hum, c'est en règle. Permettez-moi toutefois de vous signaler que votre licence expire aujourd'hui. Je vous laisse passer pour cette fois, mais il vous faudra la remplacer par une licence valide.";
				link.l1 = "Merci, j'en prendrai une nouvelle à la première occasion.";
				link.l1.go = "exit";
			}
			if (iTemp > 0 && iTemp <= 10)
			{
				dialog.text = "Hum, c'est en règle. Permettez-moi toutefois de vous signaler que votre licence expire bientכt : elle n'est plus valable que " + FindRussianDaysString(iTemp) + ". Alors gardez-le à l'esprit, " + GetAddress_Form(npchar) + ".";
				link.l1 = "Merci, j'en prendrai une nouvelle à la première occasion.";
				link.l1.go = "exit";
			}
			if (iTemp > 10)
			{
				dialog.text = LinkRandPhrase("Bien, très bien, votre licence est encore valable " + FindRussianDaysString(iTemp) + ". Vous pouvez passer.", "Tout est en ordre, "+GetAddress_Form(npchar)+". Vous pouvez entrer librement en ville, votre licence est encore valable " + FindRussianDaysString(iTemp) + ". Désolé de vous avoir dérangé.", "Tout va bien, " + GetAddress_Form(npchar) + ", je ne vous retiens pas.");
				link.l1 = RandPhraseSimple("Parfait. Bonne journée.", "Merci, officier.");
				link.l1.go = "exit";
			}
		break;
		//============================== ноды маяка Порт Рояля =========================
		case "PortRoyal_Mayak":
			dialog.text = RandPhraseSimple("Hé, l'ami, ne casse rien au phare.", "Le phare est un ouvrage très important pour la ville. Faites attention !");
			link.l1 = RandPhraseSimple("D'accord, ne vous inquiétez pas.", "Tout ira bien.");
			link.l1.go = "exit";
			NextDiag.TempNode = "PortRoyal_Mayak";
		break;
		case "PortRoyal_Gans":
			dialog.text = LinkRandPhrase("Ne traînez pas près des canons : c'est une installation militaire !", "L'accès aux canons est strictement interdit aux personnes non autorisées !", "Si je vous vois rכder autour des canons, vous êtes fini !");
			link.l1 = RandPhraseSimple("Compris.", "D'accord, compris.");
			link.l1.go = "exit";
			NextDiag.TempNode = "PortRoyal_Gans";
		break;
		//=================== ноды квеста мэра. поиск шпиона на улице ==================
		case "SeekSpy_Checking":
			dialog.text = "Oui, je vous le confirme. " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)], "C'est bien quelqu'un d'ici.", "C'est bien une habitante d'ici.");
			link.l1 = RandPhraseSimple("Je comprends. Merci de votre aide.", "Tout est clair. Merci de votre aide.");
			link.l1.go = "SeekSpy_Checking_1";
		break;
		case "SeekSpy_Checking_1":
			switch (pchar.GenQuest.SeekSpy.Type)
			{
				case "guardian": LAi_SetGuardianTypeNoGroup(npchar); break;
				case "patrol":   LAi_SetPatrolTypeNoGroup(npchar);   break;
				case "citizen":  LAi_SetCitizenTypeNoGroup(npchar);  break;
				case "merchant": LAi_SetMerchantTypeNoGroup(npchar); break;
			}
			LAi_SetCitizenTypeNoGroup(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)]);
			NextDiag.CurrentNode = "First Time";
			DialogExit();
		break;

		// --> генератор "The Girl in the Jungle"
		case "GirlEnc_1":
			dialog.text = "Et vous, capitaine, qui êtes-vous ? Le « mignon » de la plus célèbre voleuse de toute la colonie ?";
			link.l1 = "Qui traites-tu de « mignon », sac à merde ?! Le soleil t'a tapé sur la tête ?! Bas les pattes, laisse cette fille !";
			link.l1.go = "GirlEnc_11";
			link.l2 = "Oui, en fait, je viens juste de la rencontrer...";
			link.l2.go = "GirlEnc_12";
		break;

		case "GirlEnc_11":
			dialog.text = ""+ GetSexPhrase("Monsieur", "Madame") +", nous avons ordre de l'arrêter et de l'escorter au cachot. Et ne croyez pas que vous pourrez nous en empêcher.";
			link.l1 = "Vérifions tout de suite...";
			link.l1.go = "GirlEnc_11End";
		break;

		case "GirlEnc_11End":
			DialogExit();
			ChangeCharacterReputation(pchar, -2);
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			sld = CharacterFromID("CangGirl");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1.0);
			sld.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "GirlEnc_12":
			dialog.text = "Ah oui ? Vous auriez dמ vérifier vos poches, alors. דa ne fait même pas une heure... Cette dame est une professionnelle, avec un grand P";
			link.l1 = "Merci, je vais vérifier sans faute. Quelle méprise...";
			link.l1.go = "GirlEnc_12End";
		break;

		case "GirlEnc_12End":
			pchar.money = sti(pchar.money) - makeint(sti(pchar.money)/20);
			NextDiag.CurrentNode = NextDiag.TempNode;
			sld = CharacterFromID("CangGirl");
			LAi_SetActorType(sld);
			LAi_ActorStay(sld);
			LAi_CharacterDisableDialog(sld);
			sld.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "GirlEnc_2":
			dialog.text = ""+ GetSexPhrase("Monsieur", "Madame") + " – nous avons ordre de retrouver cette personne et de la ramener à son père.";
			link.l1 = "Hum, eh bien, ramenez-la, si c'est l'ordre.";
			link.l1.go = "GirlEnc_2End";
			link.l2 = "Vous arrivez trop tard. Je la ramène déjà chez elle.";
			link.l2.go = "GirlEnc_21";
		break;

		case "GirlEnc_2End":
			NextDiag.CurrentNode = NextDiag.TempNode;
			sld = CharacterFromID("CangGirl");
			LAi_SetActorType(sld);
			LAi_ActorStay(sld);
			LAi_CharacterDisableDialog(sld);
			sld.lifeDay = 0;
			ChangeCharacterReputation(pchar, -2);
			AddQuestRecord("JungleGirl", "11");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "GirlEnc_21":
			ChangeCharacterReputation(pchar, 2);
			if(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < rand(100))
			{
				dialog.text = "Capitaine, nous avons des ordres, et vous avez tort de croire que vous pouvez nous en empêcher.";
				link.l1 = "Vérifions ça tout de suite...";
				link.l1.go = "GirlEnc_21End";
			}
			else
			{
				dialog.text = "Eh, "+ GetSexPhrase("veinard", "veinarde") +". Son père a promis une généreuse récompense à qui lui ramènerait sa fille..";
				link.l1 = "Ne désespérez pas, vos récompenses sont encore devant vous.";
				link.l1.go = "exit";
			}
		break;

		case "GirlEnc_21End":
			DialogExit();
			AddQuestRecord("JungleGirl", "12");
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city));
			CloseQuestHeader("JungleGirl");
			ChangeCharacterReputation(pchar, -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			sld = CharacterFromID("CangGirl");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1.0);
			sld.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		// <-- генератор "The Girl in the Jungle"

		//замечение по обнажённому оружию
		case "SoldierNotBlade":
			dialog.text = LinkRandPhrase("Pourquoi brandissez-vous une lame ?! Rangez immédiatement vos armes !", "Je vous ordonne de ranger immédiatement vos armes !", "Hé, " + GetAddress_Form(NPChar) + ", n'effrayez pas les gens ! Rangez votre arme.");
			link.l1 = LinkRandPhrase("D'accord, je la range...", "Je l'ai déjà "+ GetSexPhrase("rangée", "rangée") +".", "Comme vous voudrez...");
			link.l1.go = "exit";
			link.l2 = LinkRandPhrase("Au diable tout ça !", "Je vais m'en servir tout de suite !", "Je la rangerai le moment venu.");
			link.l2.go = "fight";
			npchar.greeting = "soldier_common";
			NextDiag.TempNode = "First Time";
			if(NPChar.chr_ai.type == "guardian") link.l1.go = "First Time";
		break;

	}
}
