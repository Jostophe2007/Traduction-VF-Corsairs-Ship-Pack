void ProcessDialogEvent()
{
    ref NPChar;
    ref Pchar = GetMainCharacter();
    aref Link, NextDiag;

    DeleteAttribute(&Dialog, "Links");

    makeref(NPChar, CharacterRef);
    makearef(Link, Dialog.Links);
    makearef(NextDiag, NPChar.Dialog);
    switch (Dialog.CurrentNode)
    {
    case "Exit":
        NextDiag.CurrentNode = NextDiag.TempNode;
        DialogExit();
    break;
	case "CitizenNotBlade":
		if (loadedLocation.type == "town")
		{
			dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
		}
		else
		{
			dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
			link.l1 = RandPhraseSimple("Compris.", "Je la range.");
		}
		Link.l1.go = "exit";
		NextDiag.TempNode = "First Time";
	break;
    case "First Time":
        if (!isMainCharacterPatented())
        {
            Log_info("Vous n'avez pas de lettre de marque");
            dialog.text = "Allez, qu'y a-t-il ?";
            link.l1 = "Bon, bon, ne t'énerve pas.";
            link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
        }
        else
        {
            dialog.text = "Oh ! Qui vois-je ?! " + GetFullName(pchar) + ", en personne ! Quelle rencontre !";
            link.l1 = "Euh... J'ai bien peur de ne pas te reconnaître.";
            link.l1.go = "StartQuest_1";
            AddBonusEnergyToCharacter(NPChar, 50);
        }
    break;
    case "StartQuest_1":
        dialog.text = "Mais si, c'est moi, Luke ! Nous avons navigué sous le pavillon de Bart le Portugais.";
        link.l1 = "Par mon artimon ! Luke ! Comme tu as changé, mon vieux !";
        link.l2 = "Hum... Toujours rien. Tu ferais mieux de t'éloigner de moi, l'ami, et pour de bon.";
        link.l1.go = "StartQuest_3";
        link.l2.go = "exit";
    break;
    case "StartQuest_3":
        dialog.text = "Héhé ! Et moi qui croyais être devenu complètement fou, et que ce n'était pas toi. Allons à la taverne, asseyons-nous et bavardons !";
        link.l1 = "Ha ! Avec plaisir !";
		DeleteAttribute(NPChar, "quest");
        AddDialogExitQuest("Taverna");
    break;
    case "StartQuest_4":
        dialog.text = GetFullName(pchar) + ", comment vas-tu, " + GetSexPhrase("l'ami", "ma petite") + " ? Raconte, qu'est-ce qui t'amène ici ?";
        link.l1 = "Je voyage, en quelque sorte : je fais voile vers une île, puis vers une autre, et peut-être que j'aurai envie d'aller sur le Main.";
        link.l1.go = "StartQuest_6";
    break;
    case "StartQuest_6":
        dialog.text = "Voilà donc. Je me souviens de notre dernière expédition, quand nous sommes allés piller la Guinée pour des esclaves. On a failli y rester. La colonie que nous avions décidé de prendre était très bien défendue. Oui... Tout le monde n'a pas réussi à repartir... Buvons au fait que nous sommes restés en vie !";
        link.l1 = "Oh, oui, beaucoup des nכtres sont morts, cette fois-là. Mais tout le monde aurait pu repartir sans la cupidité de notre commandant ! Buvons !";
        link.l1.go = "StartQuest_7";
    break;
    case "StartQuest_7":
        dialog.text = "Je vois que tu as ton propre navire et un rang... וcoute, ça me gêne de te demander ça, nous ne nous sommes pas vus depuis si longtemps, et comme ça, tout de suite...";
        link.l1 = "Ne tourne pas autour du pot, crache le morceau, je t'aiderai si je peux.";
        link.l1.go = "GiveQuest";
    break;
    case "GiveQuest":
        string spawn_max;
        int Gorod;
        NPChar = characterFromID("Old Friend");
        if (Pchar.PatentNation == "eng")
        {
            while (0 < 1)
            {
                Gorod = rand(5);
                if (Gorod == 0)
                {
                    spawn_max = "PortRoyal_tavern";
                    dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Port Royal. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                    link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                    link.l1.go = "StartQuest_8";
                    SetQuestHeader("Silence_Price");
                    AddQuestRecord("Silence_Price", "1");
                    AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                    AddQuestUserData("Silence_Price", "sCity2", "Port Royal");
                    AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                    AddDialogExitQuest("AfterDialog");
                    TakeItemFromCharacter(NPChar, "Lukes_letter");
                    GiveItem2Character(Pchar, "Lukes_letter");
                    PlaySound("Interface\important_item.wav");
                    SpawnMaks(spawn_max);
                break;
                }
                if (Gorod == 1)
                {
                    spawn_max = "SentJons_tavern";
                    dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à St. John's. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                    link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                    link.l1.go = "StartQuest_8";
                    SetQuestHeader("Silence_Price");
                    AddQuestRecord("Silence_Price", "1");
                    AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                    AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                    AddQuestUserData("Silence_Price", "sCity2", "St. John's");
                    AddDialogExitQuest("AfterDialog");
                    TakeItemFromCharacter(NPChar, "Lukes_letter");
                    GiveItem2Character(Pchar, "Lukes_letter");
                    PlaySound("Interface\important_item.wav");
                    SpawnMaks(spawn_max);
                break;
                }
                if (Gorod == 2)
                {
                    spawn_max = "Charles_tavern";
                    dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Charlestown. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                    link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                    link.l1.go = "StartQuest_8";
                    SetQuestHeader("Silence_Price");
                    AddQuestRecord("Silence_Price", "1");
                    AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                    AddQuestUserData("Silence_Price", "Friendname", NPChar.name + " " + NPChar.lastname);
                    AddQuestUserData("Silence_Price", "sCity2", "Charlestown");
                    AddDialogExitQuest("AfterDialog");
                    TakeItemFromCharacter(NPChar, "Lukes_letter");
                    GiveItem2Character(Pchar, "Lukes_letter");
                    PlaySound("Interface\important_item.wav");
                    SpawnMaks(spawn_max);
                break;
                }
                if (Gorod == 3)
                {
                    spawn_max = "Bridgetown_tavern";
                    dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Bridgetown. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                    link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                    link.l1.go = "StartQuest_8";
                    SetQuestHeader("Silence_Price");
                    AddQuestRecord("Silence_Price", "1");
                    AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                    AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                    AddQuestUserData("Silence_Price", "sCity2", "Bridgetown");
                    AddDialogExitQuest("AfterDialog");
                    TakeItemFromCharacter(NPChar, "Lukes_letter");
                    GiveItem2Character(Pchar, "Lukes_letter");
                    PlaySound("Interface\important_item.wav");
                    SpawnMaks(spawn_max);
                break;
                }
                if (Gorod == 4)
                {
                    spawn_max = "Portspein_tavern";
                    dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Port-d'Espagne. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                    link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                    link.l1.go = "StartQuest_8";
                    SetQuestHeader("Silence_Price");
                    AddQuestRecord("Silence_Price", "1");
                    AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                    AddQuestUserData("Silence_Price", "sCity2", "Port-d'Espagne");
                    AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                    AddDialogExitQuest("AfterDialog");
                    TakeItemFromCharacter(NPChar, "Lukes_letter");
                    GiveItem2Character(Pchar, "Lukes_letter");
                    PlaySound("Interface\important_item.wav");
                    SpawnMaks(spawn_max);
                break;
                }
            }
        }
        else
        {
            if (Pchar.PatentNation == "hol")
            {
                while (0 < 1)
                {
                    Gorod = rand(3);
                    if (Gorod == 0)
                    {
                        spawn_max = "Villemstad_tavern";
                        dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Willemstad. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                        link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                        link.l1.go = "StartQuest_8";
                        SetQuestHeader("Silence_Price");
                        AddQuestRecord("Silence_Price", "1");
                        AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                        AddQuestUserData("Silence_Price", "sCity2", "Willemstad");
                        AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                        AddDialogExitQuest("AfterDialog");
                        TakeItemFromCharacter(NPChar, "Lukes_letter");
                        GiveItem2Character(Pchar, "Lukes_letter");
                        PlaySound("Interface\important_item.wav");
                        SpawnMaks(spawn_max);
                    break;
                    }
                    if (Gorod == 1)
                    {
                        spawn_max = "Marigo_tavern";
                        dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Marigot. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                        link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                        link.l1.go = "StartQuest_8";
                        SetQuestHeader("Silence_Price");
                        AddQuestRecord("Silence_Price", "1");
                        AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                        AddQuestUserData("Silence_Price", "sCity2", "Marigot");
                        AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                        AddDialogExitQuest("AfterDialog");
                        TakeItemFromCharacter(NPChar, "Lukes_letter");
                        GiveItem2Character(Pchar, "Lukes_letter");
                        PlaySound("Interface\important_item.wav");
                        SpawnMaks(spawn_max);
                    break;
                    }
                    if (Gorod == 2)
                    {
                        spawn_max = "FortOrange_tavern";
                        dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Fort Orange. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                        link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                        link.l1.go = "StartQuest_8";
                        SetQuestHeader("Silence_Price");
                        AddQuestRecord("Silence_Price", "1");
                        AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                        AddQuestUserData("Silence_Price", "sCity2", "e");
                        AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                        AddDialogExitQuest("AfterDialog");
                        TakeItemFromCharacter(NPChar, "Lukes_letter");
                        GiveItem2Character(Pchar, "Lukes_letter");
                        PlaySound("Interface\important_item.wav");
                        SpawnMaks(spawn_max);
                    break;
                    }
                }
            }
            else
            {
                if (Pchar.PatentNation == "fra")
                {
                    while (0 < 1)
                    {
                        Gorod = rand(4);
                        if (Gorod == 0)
                        {
                            spawn_max = "FortFrance_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Fort-de-France. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Fort-de-France");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 1)
                        {
                            spawn_max = "FortFrance_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Fort-de-France. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Fort-de-France");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 2)
                        {
                            spawn_max = "BasTer_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Basse-Terre. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Basse-Terre");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 3)
                        {
                            spawn_max = "Tortuga_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Tortuga. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Tortuga");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                    }
                }
                else
                {
                    while (0 < 1)
                    {
                        Gorod = rand(9);
                        if (Gorod == 0)
                        {
                            spawn_max = "Caracas_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Caracas. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Caracas");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 1)
                        {
                            spawn_max = "Cumana_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Cumaná. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Cumaná");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 2)
                        {
                            spawn_max = "Cartahena_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Carthagène. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Carthagène");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 3)
                        {
                            spawn_max = "Maracaibo_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Maracaibo. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Maracaibo");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 4)
                        {
                            spawn_max = "PortoBello_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Portobelo. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Portobelo");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 5)
                        {
                            spawn_max = "SantaCatalina_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Santa Catalina. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Santa Catalina");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 6)
                        {
                            spawn_max = "Beliz_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Belize. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Belize");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 7)
                        {
                            spawn_max = "SantoDomingo_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Santo Domingo. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Santo Domingo");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 8)
                        {
                            spawn_max = "SanJuan_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à San Juan. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1")
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "San Juan");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                        if (Gorod == 9)
                        {
                            spawn_max = "Santiago_tavern";
                            dialog.text = "Je t'en prie, remets une lettre de ma part à mon ami, à Santiago. Ne fais pas cette tête, on te paiera à l'arrivée ! Tu le trouveras sans doute à la taverne. Mon ami s'appelle Maximilian Weber, dis-lui que tu viens de la part de Luke l'Acteur.";
                            link.l1 = "Ha ! Ton vieux surnom ! Donne-moi la lettre !";
                            link.l1.go = "StartQuest_8";
                            SetQuestHeader("Silence_Price");
                            AddQuestRecord("Silence_Price", "1");
                            AddQuestUserData("Silence_Price", "sSex", GetSexPhrase("", "e"));
                            AddQuestUserData("Silence_Price", "sCity2", "Santiago");
                            AddQuestUserData("Silence_Price", "FriendName", NPChar.name + " " + NPChar.lastname);
                            AddDialogExitQuest("AfterDialog");
                            TakeItemFromCharacter(NPChar, "Lukes_letter");
                            GiveItem2Character(Pchar, "Lukes_letter");
                            PlaySound("Interface\important_item.wav");
                            SpawnMaks(spawn_max);
                        break;
                        }
                    }
                }
            }
        }
        break;
    case "StartQuest_8":
        dialog.text = "Oui, le surnom m'est resté ! Merci beaucoup ! Bonne navigation et bon vent ! Buvons !";
        link.l1 = "Buvons !";
        NextDiag.TempNode = "Story1";
        link.l1.go = "Exit";
		Pchar.Luke.SpawnMaks = "1";
    break;
    case "Story1":
		dialog.text = "Qu'est-ce que tu attends ? Il est temps de prendre la route !";
		link.l1="Attends, Luke. Comment as-tu réussi à t'en sortir, à l'époque ? Je me souviens qu'à la fin, il n'y avait plus que moi. Raconte, que s'est-il passé alors ?";
		link.l1.go="Story2";
	break;
	case "Story2":
		dialog.text = "Hum, je savais que tu le demanderais. Bon, écoute. Pendant notre fuite, un mousquetaire m'a touché en pleine cuisse et je suis tombé parmi les cadavres. Quand les tirs ont cessé, les soldats ennemis m'ont trouvé vivant. Ils ne m'ont pas tué, mais ils m'ont fait prisonnier...";
		link.l1="Et ensuite ?";
		link.l1.go="Story3";
	break;
	case "Story3":
		dialog.text = "וcoute. Ils ne m'ont pas torturé, au contraire, ils ont soigné ma blessure et m'ont remis sur pied. Ils m'ont enseigné l'art militaire et naval, et m'ont libéré contre une promesse.";
		link.l1="Quelle promesse leur as-tu faite ?";
		link.l1.go="Story4";
	break;
	case "Story4":
		dialog.text = "Hum, je te promets de te le dire quand tu reviendras de chez Maximilian. Ce n'est pas le moment pour cette conversation.";
		link.l1="D'accord, Luke, j'espère que tu tiendras ta promesse";
		link.l1.go="exit";
		AddQuestRecord("Silence_Price", "3");
		AddQuestUserData("Silence_Price", "sSex",GetSexPhrase("", "e"));
		NextDiag.TempNode="Pause";
	break;
    case "Pause":
        dialog.text = "Oh, qui vois-je ! Assieds-toi, buvons un coup.";
        link.l1 = "Oui, c'est moi. Non, merci, j'ai des choses à faire.";
        link.l1.go = "exit";
    break;
	case "SecondQuest_1":
		dialog.text = Pchar.name +" ?! Qu'est-ce que tu fais ici ?! Comment... Comment m'as-tu trouvé ? C'est... C'est impossible !";
		link.l1="Qu'est-ce qui te prend, Luke ? א quoi riment tes petits jeux ? Tu veux te débarrasser de moi ? M'agacer ? Quel est ton but, salaud ?";
		link.l1.go="SecondQuest_2";
	break;
	case "SecondQuest_2":
		dialog.text = "Tu ne comprends pas... J'avais tout, tout ce qu'il me fallait. J'étais heureux. Mais après cette maudite expédition, bon sang, ma vie a dégringolé. Je veux me venger de tous ceux qui en sont responsables.";
		link.l1 = "Attends, Luke, mais qu'ai-je fait de mal, moi ?";
		link.l1.go = "SecondQuest_3";
	break;
	case "SecondQuest_3":
		dialog.text = Pchar.Name + ", je te l'ai dit, tu ne comprendras pas. Homo homini lupus est. Il n'y a pas d'innocents. Il n'y a que différents degrés de responsabilité. Et maintenant, tu vas te sentir responsable de tout ce qui s'est passé à l'époque.";
		link.l1 = "Comme tu voudras. Je vais mettre fin à ta carrière d'acteur tout de suite, salaud !";
		link.l1.go = "exit";
		AddDialogExitQuest("LukeFight");
	break;
	case "SecondQuest_4":
		dialog.text = Pchar.Name + ", attends, je me rends... Tu as gagné.";
		link.l1 = "Quoi ?! Comme ça ?!";
		link.l1.go = "SecondQuest_5";
	break;
	case "SecondQuest_5":
		dialog.text = "Bien sמr que non ! Max, à moi ! " + Pchar.Name + ", attrape ça !";
		link.l1 = "Kh, kh kh... Qu'est-ce que c'est ?!";
		link.l1.go = "exit";
		AddDialogExitQuest("LukeOut");
	break;
	}
}
