
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = GetFullName(PChar);

	switch(Dialog.CurrentNode)
	{
		case "First time":

			if(PChar.Dozor == "0")
			{
				if(sti(PChar.rank) >= 1)
				{
					dialog.text = "Approche, " + GetSexPhrase("mon fils","ma fille") +" ! Plus près, que je puisse voir ton visage. Ma vue a fichu le camp avec l'âge. Oui, c'est beaucoup mieux.";
					link.l1 = "Qu'est-ce que tu as avec mon visage, le vieux ! Tu ferais mieux de passer ton chemin, au lieu de distraire les gens qui ont à faire.";
					link.l1.go = "1";
				}
				else
				{
					dialog.text = "Tu es encore trop bête pour discuter avec moi. Reviens plus tard...";
					link.l1 = "Bête, moi ? Attends un peu que je te... ! Bah, le vieux...";
					link.l1.go = "exit";
				}
				break;
			}

			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Ne me traite pas comme ça, " + GetSexPhrase("mon fils","ma fille") +", car je veux te donner quelque chose que personne d'autre ne peut te donner. Tu vois oם je veux en venir ?";
			link.l1 = "דa a l'air alléchant. Et qu'est-ce que c'est, ce truc ? Encore une babiole inutile ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Ne tire pas de conclusions hâtives : je vois sur ton visage la volonté de vaincre, il y a des étincelles d'enthousiasme dans tes yeux, et tes vêtements trahissent un goמt pour l'aventure.";
			link.l1 = "Attends, attends. Regarde autour de toi ! Oם que tu regardes, tout le monde ici court l'aventure, on est aux Bermudes !";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Non, non, ce sont tous des capitaines ordinaires, certains plus chanceux que d'autres, peu importe. Ils n'ont pas ce qu'il y a en toi, ce qui saute aux yeux, ce pour quoi je t'ai remarqué. Tu comprends, " + GetSexPhrase("mon fils","ma fille") +" ?";
			link.l1 = "Pas vraiment. Et qu'est-ce que c'est ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "L'envie de se jeter tête baissée dans la lutte contre un adversaire perfide et indéniablement dangereux, qui s'appelle l'aventure !";
			link.l1 = "Tu vois, l'ami, je n'ai pas l'intention de risquer ma tête pour une aventure sans profit, je te le dis tout de suite. Alors, si ton aventure ne me promet pas une cale pleine d'argent ou un sac de galions, notre conversation peut s'arrêter là.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(sourit mystérieusement)... Bien sמr, tu ne seras pas en reste : si tu as la tête bien faite, et surtout si tu sais t'en servir, tu peux t'enrichir pas mal ; et si tu es plus malin que tous les autres dans l'archipel, tu pourras rafler quelques objets de valeur. Seulement, pour commencer, j'aimerais te raconter une histoire... ...(en se pourléchant les babines)... וcoute-la, elle te sera utile.";
			link.l1 = "Bon, écoutons ça.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Mon père a jadis servi comme mousse sur un brick pirate, le Faylor. Sang jeune, tête brמlée, mains solides, œil perçant. Et Dieu ne l'avait pas privé d'esprit, sauf qu'il était terriblement agité, mon père, tout comme toi. Sans cette agitation excessive, il serait devenu capitaine en moins de deux ans ; au lieu de ça, il est resté mousse plus d'une année. Et quand il a repris ses esprits, il était déjà trop tard : on ne remonte pas le temps. Alors, retiens bien, mon enfant : avant tout, ne t'agite pas. Car la précipitation est mère de l'échec...";
			link.l1 = "Qu'est-ce que tu racontes, le vieux ? De nos jours, si tu ne te remues pas, tu te retrouves Gros-Jean comme devant.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Attends, ne confonds pas promptitude et agitation. La promptitude, c'est le succès. L'agitation, c'est l'échec. Tu as retenu ?";
			link.l1 = "Retenu. Alors, et cette aventure ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Ah, la jeunesse, c'est vert... Voilà que tu bouscules encore un vieillard, tu n'as pas honte ?";
			link.l1 = "C'est ta faute, aussi : j'ai à faire, et toi, tu viens me distraire. Faisons vite.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Bon, bon. Alors, tu écoutes ? וcoute bien. Je te propose une aventure, ou pour être plus précis, un jeu. Si tu es quelqu'un de futé, pas dénué de jugeote et ami avec la logique, l'aventure t'attend sur ta route. Et si tu es bête, oui, bête, alors bon débarras...";
			link.l1 = "Je ne suis pas bête, si c'est ce que tu veux dire ! Ou tu crois que je pourrais commander un navire si j'étais stupide ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Dans ce cas, tu veux bien te joindre au jeu ?";
			link.l1 = "Tu peux m'en dire plus ? C'est quoi, ce jeu ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Rien de plus simple ! Enfin, en paroles, c'est simple, mais dans la vie, vois-tu, tout est bien plus compliqué. Hmph... Tu as déjà entendu parler d'un jeu appelé la Veille, "+ GetSexPhrase("mon fils","ma fille") +" ?";
			link.l1 = "Bien sמr que j'en ai entendu parler !";
			link.l1.go = "12";
			link.l2 = "C'est la première fois que j'entends ça. Tu peux m'en dire plus ? Qu'est-ce que c'est, ce terme ?";
			link.l2.go = "13";
		break;

		case "12":
			dialog.text = "Parfait ! Alors, inutile de t'expliquer quoi que ce soit ! Seulement, dans notre jeu, contrairement à la vraie Veille, tout est plus simple : huit épreuves, sans indices, sans niveaux de danger ni limites de temps. Je répète : tu entres les données dans un appareil spécial que je vais te donner (ça s'appelle un Meckachrome), tu obtiens la phrase clé, tu hisses les voiles et en route pour l'île suivante, chez l'agent ! Tu lui dis la phrase clé, et tu reçois le Meckachrome suivant.";
			link.l1 = "C'est quoi, ce Meckachrome ?";
			link.l1.go = "15";
		break;

		case "13":
			dialog.text = "Dans ce jeu, tu dois accomplir huit épreuves. Chaque épreuve est une énigme, un casse-tête que tu dois résoudre, ou, comme disent les professionnels, « craquer ». ";
			link.l1 = "Par exemple ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Eh bien, tu connais sans doute celle-là : Pet et Répète sont sur un bateau. Pet tombe à l'eau. Qui reste-t-il ? La bonne réponse : Répète ! Ici, c'est le même genre. On te donne une énigme. Une fois que tu l'as résolue, tu entres la solution dans un appareil spécial que je vais te donner (ça s'appelle un Meckachrome), tu obtiens la phrase clé, tu hisses les voiles et en route pour l'île suivante, chez l'agent ! Tu lui dis la phrase clé, et tu reçois l'épreuve suivante.";
			link.l1 = "C'est quoi, ce Meckachrome ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "C'est un appareil qui permet d'obtenir la phrase clé.";
			link.l1 = "Et comment je me sers de cet appareil ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Eh, qu'est-ce qu'il y a à savoir ? C'est simple comme bonjour, tu t'en sortiras si tu as résolu les énigmes.";
			link.l1 = "Bon, d'accord, disons que j'ai résolu les huit énigmes, et au bout du compte ? Tu n'as pas parlé d'objets de valeur ?";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Eh bien, si tu arrives au bout du jeu, tu auras de l'argent, de la gloire et des objets de valeur, crois-moi ! Bon, tu es d'accord ?";
			link.l1 = "Sans doute. Seulement, j'ai encore une question, la voici...";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Euh, attends, "+ GetSexPhrase("mon brave","ma bonne dame") +", attends. Je prépare ce jeu depuis deux ans, et je veux être payé pour mon travail...";
			link.l1 = "Payer ?! Et combien je te dois ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Euh, ne crie pas, voyons, ne crie pas. Qu'est-ce que je te dis ? Que je prépare ce jeu depuis deux ans ! J'ai cherché des agents dans tout l'archipel, inventé des énigmes, et ceci, et cela.";
			link.l1 = "Combien voulez-vous ?";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "20 000 piastres.";
			link.l1 = "Quoi ?!";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "...(avec un sourire en coin)... Tu n'as donc toujours rien compris, "+ GetSexPhrase("mon fils","ma fille") +" ?";
			link.l1 = "J'ai compris que si j'accepte, mes 20 000 durement gagnés partiront en fumée !";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = ""+ GetSexPhrase("Mon fils","Ma fille") +" ! Une fois ce jeu terminé, tu obtiendras un trésor si riche que tu n'en as jamais rêvé ! Et la gloire d'être l'un des capitaines les plus intelligents de l'archipel.";
			link.l1 = "Et si je n'arrive pas au bout ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Tu as peur ?";
			link.l1 = "Je n'ai peur de rien ni de personne !";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Alors, en avant ! Vers l'aventure ! C'est pour ça que tu es là. N'est-ce pas ?!";
			link.l1 = "Oui, en plus, seulement...";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "On dirait que je perds mon temps. Je te le propose pour la dernière fois. Oui ou non ?";

			NPChar.NeedMoney = 20000;
			if(sti(PChar.money) >= sti(NPChar.NeedMoney))
			{
				link.l1 = "D'accord, j'accepte.";
				link.l1.go = "26";
			}

			link.l2 = "Il me faut du temps pour réunir cette somme.";
			link.l2.go = "27";
			link.l3 = "Va te faire voir ! Trouve-toi un autre pigeon. Je ne marche pas dans ce genre d'arnaque.";
			link.l3.go = "29";
		break;

		case "26":
	        AddMoneyToCharacter(pchar,-sti(NPChar.NeedMoney));
			dialog.text = "Voilà qui est mieux. Tiens, voici le premier Meckachrome, il contient les informations sur la première énigme. Bonne chance !";
			link.l1 = "Bonne chance à toi aussi. Adieu.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DozorStart");
		break;

		case "27":
			dialog.text = "Dépêche-toi, je n'attendrai pas longtemps.";
			link.l1 = "Dès que je l'aurai trouvée, je viendrai directement te voir. א plus tard, le vieux.";
			link.l1.go = "exit";
			NextDiag.TempNode = "28";
			AddDialogExitQuestFunction("DozorWait");
		break;

		case "28":
			dialog.text = "Tu as trouvé l'argent ?";
			NPChar.NeedMoney = 20000;
			if(sti(PChar.money) >= sti(NPChar.NeedMoney))
			{
				link.l1 = "Les 20 000 sont là.";
				link.l1.go = "26";
			}

			link.l2 = "Pas encore ; dès que je l'aurai trouvé, je viendrai directement te voir.";
			link.l2.go = "exit";

			link.l3 = "Tu sais, j'ai réfléchi... Va te faire voir ! Trouve-toi un autre pigeon. Je ne marche pas dans ce genre d'arnaque.";
			link.l3.go = "29";
			NextDiag.TempNode = "28";
		break;

		case "29":
			DozorCancel();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
