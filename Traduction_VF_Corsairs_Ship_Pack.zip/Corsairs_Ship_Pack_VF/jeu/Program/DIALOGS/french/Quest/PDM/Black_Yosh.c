
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Hein ? Qui c'est ? Hé... hic... Je te... hic... connais, moi ?";
			link.l1 = "Je m'appelle "+pchar.name+". Qu'est-ce que tu fais ici ?";
			link.l1.go = "Kristofer_1";
			//PlayVoice("Kopcapkz\Voices\PDM\пьяница.wav");
		break;

		case "Kristofer_1":
            dialog.text = "Tu vois pas ? Je f-f-f... je fête ça. J'ai eu une affectation... hic... sur une frégate. Voilà ce qu'il m'a dit... hic. Hé, hé, Hו ! Tu essaies de... hic... de découvrir... un secret... d'ו-וtat ! Je t'arrête...";
            link.l1 = "Non, l'ami, tu te trompes. Je ne cherche pas du tout à t'arracher un secret d'וtat. C'est toi qui essaies de me le raconter... Mon Dieu, qu'est-ce que tu bois comme tord-boyaux ?";
			link.l1.go = "Kristofer_2";
		break;
		
		case "Kristofer_2":
            dialog.text = "Ah. דa. De quoi je parlais ? Je veux dire... hic... Si tu me paies à boire, je te dirai un secret d'ו-וtat. Hic... Si je m'en souviens, je m'en souviens.";
            link.l1 = "Ah oui ? Un vrai secret d'וtat ? Formidable. Je te paie à boire.";
			link.l1.go = "Kristofer_3";
			link.l2 = "Qu'est-ce qu'une brute avinée comme toi peut savoir des secrets d'וtat ? Tu es soמl comme un cochon. Fiche-moi la paix.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Kristofer_6_snova";
			npchar.lifeday = 0;
		break;
		
		case "Kristofer_3":
            dialog.text = "Mais fais pas le radin. Si je manque de rhum... hic... je serai muet comme... comme... comme un truc, là. Chut ! Chut ! A-approche-toi ! Encore ! Ces frégates ? On les a p-p-prises pour les r-r-réarmer ? C'est... DE LA CAMELOTE ! De maudites ruines ! Une bande d'Indiens dans leurs canots p-pourrait les couler.";
            link.l1 = "Mais alors, à quoi bon tout ça ? Pourquoi le gouverneur Thomas Madiford les fait-il réarmer ?";
			link.l1.go = "Kristofer_4";
		break;
		
		case "Kristofer_4":
            dialog.text = "Euh... J'ai d-dit « réarmer » ? Oui, quelque chose comme ça. Tu m'as soמlé de questions ! Fiche le camp !";
            link.l1 = "Hé, l'ami, on dirait que tu fais une crise de delirium tremens.";
			link.l1.go = "Kristofer_5";
		break;
		
		case "Kristofer_5":
            dialog.text = "Exactement. Hé, attends une minute. On m'a affecté sur une de ces maudites frégates. Je... hic... Je suis déjà mort. Je vais n-nourrir les requins dès la première bataille... tu sais... Voilà. Oups ! דa me rend pas joyeux. On d-d-dirait que je suis... hic... soמl.";
            link.l1 = "Soמl ? Bon Dieu, tu es soמl comme un cochon. Pardon, mais ça me dégoמte de te regarder. Bonne chance à toi, matelot.";
			link.l1.go = "exit";
			pchar.questTemp.BlackYosh_1 = "BlackYosh_1";
		break;
		
		case "Kristofer_6_snova":
            dialog.text = "Pfffff.... Hic ! Pfff... Hic ! Rrr...";
            link.l1 = "Il est tellement soמl qu'il ne peut plus parler.";
			link.l1.go = "exit";
		break;


	}
}
