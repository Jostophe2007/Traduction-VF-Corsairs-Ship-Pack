
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, Diag;
	string NPC_Meeting;
	int Shit, i;
	ref refStore;
	ref sld;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

		case "First time":
			Diag.TempNode = "first time";
			// благодарность за бой с патрулём уже получена - все смуглеры сворачивают разговор (без повторных наград и торговли)
			if (CheckAttribute(pchar, "quest.Contraband.ThanksGot"))
			{
				dialog.text = RandPhraseSimple("Voilà, capitaine, il est temps pour nous de partir. Adieu.", "Le travail est fait, nos chemins se séparent. Sans rancune.");
				link.l1 = "Adieu.";
				link.l1.go = "exit";
				break;
			}
			// === contraband FREIGHT handover (order from the trader journal) ===
			if (CheckAttribute(pchar, "quest.SmuggleFreight.active") && sti(pchar.quest.SmuggleFreight.active) == true)
			{
				// груз принимают только с корабля, пришвартованного в ЭТОЙ бухте - не пешком из города
				// (та же проверка, что у обычной сделки; фикс сдачи "через порт")
				bool bShipInBay = false;
				if (CheckAttribute(pchar, "location.from_sea"))
				{
					if (pchar.location == pchar.location.from_sea)
					{
						if (sti(pchar.Ship.Type) != SHIP_NOTUSED) bShipInBay = true;
					}
				}
				if (!bShipInBay)
				{
					dialog.text = "Oh non. Et oם est votre navire ? Vous comptez porter la marchandise sur votre dos ? Mouillez dans cette baie : nous transborderons tout discrètement, bord à bord.";
					link.l1 = "Très bien, je vais venir me ranger le long du bord.";
					link.l1.go = "exit";
					break;
				}
				// хитрецы: взяли заказ на малой эскадре, а в бухту привели большую/мощную - сделки не будет
				if (!CheckSmuggleFreightShips())
				{
					dialog.text = "Qu'est-ce que vous fabriquez ?! Le marché, c'était de venir discrètement : pas plus de trois voiles, et pas de grosses baignoires au-dessus du troisième rang. Emmenez votre armada avant que la patrouille ne rapplique, sinon pas d'affaire.";
					link.l1 = "Très bien, je vais renvoyer les navires en trop et je reviens.";
					link.l1.go = "exit";
					break;
				}
				int fchkGoods = makeint(pchar.CargoQuest.iTradeGoods);
				int fchkQty   = makeint(pchar.CargoQuest.iQuantityGoods);
				if (GetSquadronGoods(pchar, fchkGoods) < fchkQty)
				{
					dialog.text = "Oם est la cargaison ? Elle n'est pas complète. Pas de cargaison complète, pas d'affaire.";
					link.l1 = "Je vais la livrer tout de suite.";
					link.l1.go = "exit";
					break;
				}
				// КИДАЛОВО (флаг отролен при взятии заказа, шанс как в обычной сделке): платы не будет - бой или груз даром
				if (CheckAttribute(pchar, "CargoQuest.SmuggleScam"))
				{
					dialog.text = RandPhraseSimple("Tiens, tiens, la cargaison est au complet... Vous savez quoi ? Je crois que nous allons la prendre gratuitement. א qui allez-vous vous plaindre, au gouverneur, avec une marchandise pareille ?",
						"Hum, vous avez tout apporté, beau travail... Maintenant, écoutez bien : il n'y aura pas de paiement. Estimez-vous heureux qu'on vous laisse repartir vivant. Alors, qu'est-ce que vous décidez ?");
					link.l1 = "La seule façon d'avoir cette cargaison, c'est avec ma lame en prime !";
					link.l1.go = "SmuggleFreight_ScamFight";
					link.l2 = "(pesant le pour et le contre) Bon, prenez-la. Vous avez gagné, cette fois.";
					link.l2.go = "SmuggleFreight_ScamGive";
					break;
				}
				dialog.text = "(entre ses dents) Bien, la cargaison est là. Nous la prenons. Voici votre argent : maintenant, filez, ça risque de chauffer par ici.";
				link.l1 = "Je m'en vais déjà.";
				link.l1.go = "SmuggleFreight_BayDone";
				break;
			}
			if(CheckAttribute(PChar, "quest.Contraband.active"))
			{
				if ((sti(pchar.Ship.Type) != SHIP_NOTUSED) && !CheckCharacterPerk(pchar, "UnlimitedContra"))
				{
					if (GetCompanionQuantity(pchar) > 1 && GetBaseHeroNation() != PIRATE)
					{
						dialog.text = NPCStringReactionRepeat("וcoutez, on vous a clairement dit à la taverne de venir avec un seul navire. Dehors, et débarrassez-vous de votre escadre.",
							"Vous feriez mieux de partir d'ici. Sinon, nous vous livrerons nous-mêmes à la patrouille.",
							"Allez, montez dans la chaloupe et filez.",
							"Vous m'avez fatigué...", "block", 1, npchar, Dialog.CurrentNode);
						link.l1 = HeroStringReactionRepeat("Bon, bon, je reviens tout de suite sur le navire amiral.",
							"Ne jurez pas, je cours juste à la capitainerie, je laisse les navires en trop et je reviens aussitכt.",
							"Eh, impossible de tricher...",
							"Oui, je suis tenace !", npchar, Dialog.CurrentNode);
						link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
						break;
					}
					//редкостная хрень, но по-другому не работает-класс корабля ГГ считается отдельно от компаньонов, и всё тут
					int iClass, ipClass;
					ipClass = 4-sti(RealShips[sti(pchar.ship.type)].Class);
					iClass = 3;//т.к. не пройдёт по числу кораблей в любом случае
					if (GetBaseHeroNation() == PIRATE)
					{
						ipClass = sti(ipClass)-1;
						int iChIdx;
						// поиск старшего класса компаньонов
						for (i=0; i<COMPANION_MAX; i++)
						{
							iChIdx = GetCompanionIndex(GetMainCharacter(), i);
							if (iChIdx>=0)
							{
								sld = GetCharacter(iChIdx);
								iClass = GetCharacterShipClass(sld);
							}
						}
					}
					if (sti(ipClass) > 0 || 3 - sti(iClass) > 0)
					{
						dialog.text = NPCStringReactionRepeat("On ne vous a pas dit de ne pas vous montrer sur un navire aussi voyant ? Il ne vous manquait plus que d'amener deux ou trois vaisseaux de guerre. Dehors, et revenez sur un navire plus petit.",
							"Vous feriez mieux de partir d'ici. Sinon, nous vous livrerons nous-mêmes à la patrouille.",
							"Allez, montez dans la chaloupe et filez.",
							"Vous m'avez fatigué...", "block", 1, npchar, Dialog.CurrentNode);
						link.l1 = HeroStringReactionRepeat("Bon, bon, je vais changer de bateau.",
							"Ne vous fâchez pas, je fais l'aller-retour en un clin d'œil.",
							"Eh, impossible de tricher...",
							"Oui, je suis tenace !", npchar, Dialog.CurrentNode);
						link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
						break;
					}
				}
				Dialog.snd = "voice\SMSH\SMSH001";
				dialog.Text = RandPhraseSimple("Hé, qu'est-ce que tu fais ici, "+ GetSexPhrase("l'ami", "ma petite") +" ?",
                                          RandSwear() + "Qu'est-ce que tu veux ici ?!");
				Link.l1 = RandPhraseSimple("Du calme, l'ami, j'ai apporté de la marchandise !", "Qu'est-ce que tu regardes ? J'ai apporté de la marchandise !");
				Pchar.quest.Contraband.Counter = 0; // не торговали
				if ((Pchar.Location == Pchar.location.from_sea) && (sti(pchar.Ship.Type) != SHIP_NOTUSED))
				{
					Link.l1.go = "Exchange";
				}
				else
				{
					Link.l1.go = "No_Ship";
				}
				//по заданию губернатора, истребление контры, только эта ветка.
				if (CheckAttribute(pchar, "GenQuest.KillSmugglers") && pchar.GenQuest.KillSmugglers == "" && pchar.GenQuest.KillSmugglers.Areal == GiveArealByLocation(&locations[FindLocation(pchar.location)]))
				{
					Link.l2 = "Je suis ici sur ordre du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.KillSmugglers.MayorId)].city+"Gen") + " ! Je vous ordonne de déposer les armes et de me suivre : vous êtes en état d'arrestation !";
					Link.l2.go = "GenQuestKillContraband_1";
				}
			}
			else
			{
				if (CheckAttribute(PChar, "GenQuest.contraTravel.payed") && sti(PChar.GenQuest.contraTravel.payed) == true) //если заплатил, то разговаривают, иначе посылают
				{
					dialog.Text = RandPhraseSimple("Ah, enfin !!! Vous voilà, ça fait un bon moment que nous attendons. Allez, on part.", "Dépêchez-vous, il y a des patrouilles partout. Il faut partir d'ici au plus vite !");
					//по заданию губернатора, истребление контры, только эта ветка.
					if (CheckAttribute(pchar, "GenQuest.KillSmugglers") && pchar.GenQuest.KillSmugglers == "" && pchar.GenQuest.KillSmugglers.Areal == GiveArealByLocation(&locations[FindLocation(pchar.location)]))
					{
						Link.l1 = "Je suis ici sur ordre du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.KillSmugglers.MayorId)].city+"Gen") + " ! Je vous ordonne de déposer les armes et de me suivre : vous êtes en état d'arrestation !";
						Link.l1.go = "GenQuestKillContraband_1";
						break;
					}
					//если набрал пассажиров, в сад..
					if (GetPassengersQuantity(PChar) > 0)
					{
						dialog.Text = "Et vous, qui êtes-vous ? Nous étions convenus de transporter un passager, pas une foule.";
						Link.l1 = "Oups...";
						Link.l1.go = "Exit";
						break;
					}
					//если набрал компаньонов или купил корабль себе уже :), в сад..
					if (GetCompanionQuantity(PChar) > 1 || sti(PChar.ship.type) != SHIP_NOTUSED)
					{
						dialog.Text = RandPhraseSimple("Qui êtes-vous ? Nous étions convenus de transporter le passager, pas son capitaine.", "Dehors ! Ne revenez pas avant de vous être débarrassé de votre navire.");
						Link.l1 = "Oh, bon sang...";
						Link.l1.go = "Exit";
						break;
					}
					//типа помог отбиться, свой парень...
					if (CheckAttribute(PChar, "GenQuest.contraTravel.PatrolFight") && sti(PChar.GenQuest.contraTravel.PatrolFight) == true)
					{
						if (chrDisableReloadToLocation) // ещё бой идёт
						{
							dialog.Text = "La patrouille ! Nous ne vous connaissons pas, vous ne nous connaissez pas.";
							Link.l1 = "Oui...";
							Link.l1.go = "Exit";
							break;
						}
						if (CheckAttribute(PChar, "GenQuest.contraTravel.PatrolBribed")) // патруль спроважен миром (откуп/на испуг), боя не было
						{
							dialog.Text = RandPhraseSimple("Bien joué : vous vous êtes débarrassé de ces soldats sans verser une goutte de sang. Respect. Allons-y.", "Vous savez y faire avec les patrouilles. Nous partons.");
							DeleteAttribute(PChar, "GenQuest.contraTravel.PatrolBribed");
						}
						else
						{
							dialog.Text = RandPhraseSimple("Merci pour votre aide. Nous ne l'oublierons pas. Allons-y.", "Bravo ! Vous vous êtes bien battu.");
						}
						ChangeContrabandRelation(PChar, 5);
						PChar.GenQuest.contraTravel.PatrolFight = false;
						AddCharacterExpToSkill(Pchar, "Sneak", 50);
					}
					//тут все ок, отправляемся.
					Link.l2 = "Je suis en route.";
					Link.l2.go = "Exit";
					
					//поместим Грея в локацию.
					refStore = CharacterFromID("Abracham_Gray");
					ChangeCharacterAddressGroup(refStore, "Ship_deck", "goto", "goto2");
					refStore.dialog.Filename = "Smuggler_Ship_dialog.c";
					refStore.dialog.CurrentNode = "Travel_talkStart";
					//поплыл, иначе RemoveTravelSmugglers грохнет всю ветку
					PChar.GenQuest.contraTravel.ship = true;
					PChar.quest.Munity = "";  // признак выхода с палубы

					SetLaunchFrameFormParam("Il s'est écoulé " + sti(Pchar.GenQuest.contraTravel.destination.days) + " jours " + NewStr() + "Le pont du navire des contrebandiers.",
																	"Reload_To_Location", 0.1, 5.0);
											bQuestCheckProcessFreeze = true;
					WaitDate("", 0, 0, sti(Pchar.GenQuest.contraTravel.destination.days), rand(20), 0);
					bQuestCheckProcessFreeze = false;
					MakeCloneShipDeck(refStore, true); // подмена палубы
					SetLaunchFrameReloadLocationParam("Ship_deck", "reload", "reload1", "Travel_talkOnDeck");
					AddDialogExitQuest("LaunchFrameForm");
					AddCharacterExpToSkill(Pchar, "Sneak", 50);
				}
				else
				{
					if (CheckAttribute(NPChar, "ContrabandInterruption")) // если таможня уже бежит
					{
						if (CheckAttribute(PChar, "GenQuest.contraTravel.PatrolFight"))
						{
							if (chrDisableReloadToLocation)
							{
								dialog.Text = RandSwear()+ "La patrouille ! Nous ne vous connaissons pas, vous ne nous connaissez pas !";
								Link.l1 = "Exactement !";
								Link.l1.go = "Exit";
								break;
							}
							if (CheckAttribute(PChar, "GenQuest.contraTravel.PatrolBribed")) // патруль спроважен миром (откуп/на испуг), боя не было
							{
								dialog.Text = RandPhraseSimple("Bien joué : vous vous êtes débarrassé de ces soldats sans verser une goutte de sang. Respect.", "Vous savez y faire avec les patrouilles. C'est un plaisir de travailler avec des capitaines comme vous.");
								DeleteAttribute(PChar, "GenQuest.contraTravel.PatrolBribed");
							}
							else
							{
								dialog.Text = RandPhraseSimple("Merci pour votre aide. Nous ne l'oublierons pas. Allons-y.", "Bravo ! Vous vous êtes bien battu.");
							}
							ChangeContrabandRelation(PChar, 5);
							DeleteAttribute(PChar, "GenQuest.contraTravel.PatrolFight");
							ContrabandInterruptionSetStatus(false);
							AddCharacterExpToSkill(Pchar, "Sneak", 50);
							pchar.quest.Contraband.ThanksGot = true; // благодарность ОДИН раз: дальше все смуглеры сворачивают разговор (чистится при новой высадке)
							Link.l2 = "Je suis en route.";
							Link.l2.go = "Exit";
							break;
						}
					}
					else
					{
						// один диалог - одна сделка: повторный запуск торговли (Exchange1) УБРАН - закрывает дыру с многократным спавном патруля и фармом наград
						dialog.Text = "וcoutez, filez d'ici ! L'affaire est faite : inutile de traîner avant qu'une patrouille ne se montre.";
						Link.l2 = RandPhraseSimple("Tu oses me menacer, chien ?", "Tu vas ravaler tes paroles, gredin !");
						Link.l2.go = "Exit_fight";
						Link.l3 = "Allons, je sais ce que sont les affaires. א plus tard.";
						Link.l3.go = "Exit";
					}
				}
			}
		break;

		case "No_Ship":
			Dialog.snd = "voice\SMSH\SMSH003";
			dialog.Text = "Sur ton dos, ou quoi ? Oם est ton navire ?";
			Link.l1 = RandPhraseSimple("D'abord, je voulais m'assurer qu'il n'y avait pas d'entourloupe.", "Je ne voulais pas risquer le navire. Je préfère d'abord tout voir de mes propres yeux.");
			Link.l1.go = "No_ship_1";
			Link.l2 = "L'affaire est annulée !";
			Link.l2.go = "Cancellation";
		break;

		case "No_ship_1":
			Dialog.snd = "voice\SMSH\SMSH004";
			dialog.Text = "Nous sommes d'honnêtes gens, et nous ne vivons pas de tromperie. Amène ton navire, mais fais attention que la patrouille cכtière ne te suive pas.";
			Link.l1 = "Bien. Attendez-moi ici.";
			Link.l1.go = "Exit";
		break;

		case "Exit_fight":
			//DeleteAttribute(Pchar, "quest.Contraband");
			DeleteAttribute(Pchar, "quest.Contraband.active");
			DeleteAttribute(Pchar, "quest.Contraband.counter");
			DeleteAttribute(Pchar, "quest.Contraband.price1");
			DeleteAttribute(Pchar, "quest.Contraband.price2");
			DeleteAttribute(Pchar, "quest.Contraband.price3");
			DeleteAttribute(Pchar, "quest.Contraband.price4");
			DeleteAttribute(Pchar, "quest.Contraband.price5");
			DeleteAttribute(Pchar, "quest.Contraband.price6");
			DeleteAttribute(Pchar, "quest.Contraband.price7");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX1");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX2");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX3");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX4");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX5");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX6");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX7");
			DeleteAttribute(Pchar, "quest.Contraband.sum");
			DeleteAttribute(Pchar, "quest.Contraband.ChooseGoodsQty");
			DeleteAttribute(Pchar, "quest.Contraband.ChooseGoodsID");

			AddSimpleRumourCity("Vous avez entendu ? Récemment, une patrouille a fait une descente chez des contrebandiers, dans la baie. Et que croyez-vous ? Le capitaine qui livrait des marchandises aux acheteurs d'ici a réussi à s'enfuir ! " +
				"Il avait des gaillards hardis dans son équipage : toute l'escouade de la patrouille a été abattue. Et nos gens d'ici se sont volatilisés. On n'a trouvé que des cadavres dans la baie : ni la marchandise, ni la cachette, ni les contrebandiers eux-mêmes. Voilà comment ces escrocs organisent leur pêche !", Pchar.quest.contraband.City, 3, 5, "");

			CloseQuestHeader("Gen_Contraband");
			Pchar.quest.Rand_Smuggling.over = "yes";
			LAi_group_FightGroups(LAI_GROUP_PLAYER, pchar.GenQuest.Smugglers_Group, true);
			RemoveSmugglersFromShore();
			//#20190121-01
			//LAi_SetFightMode(Pchar, true);

			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			//#20190121-01
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Exit_Cancel":
			DeleteAttribute(Pchar, "quest.Contraband");
			CloseQuestHeader("Gen_Contraband");
			Pchar.quest.Rand_Smuggling.over = "yes";
			RemoveSmugglersFromShore();
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

		case "Cancellation":
			if (sti(Pchar.quest.Contraband.Counter) == 0)
			{
				dialog.Text = "Annulée ? Vous plaisantez ?";
				Link.l1 = "Tout à fait sérieux.";
				Link.l1.go = "Cancellation_1";
			}
			else
			{
				dialog.Text = "Eh bien, très bien. Nous avons déjà assez bien commercé comme ça.";
				Link.l1 = "Exactement !";
				Link.l1.go = "Finish_exit";
			}
		break;

		case "Cancellation_1":
			if( makeint(Pchar.rank) <= 3 || GetSummonSkillFromNameToOld(Pchar, SKILL_FENCING) <= 5 || GetSummonSkillFromNameToOld(Pchar, SKILL_LEADERSHIP) <= 5 )
			{
				if(Rand(1) == 1)
				{
					ChangeContrabandRelation(pchar, -30);
					Dialog.snd = "voice\SMSH\SMSH006";
					dialog.Text = "Chien ! Tu ne nous auras pas comme ça ! Tu vas le payer de ta tête !";
					Link.l1 = "דa m'étonnerait !";
					Link.l1.go = "Exit_fight";
				}
				else
				{
					ChangeContrabandRelation(pchar, -10);
					Dialog.snd = "voice\SMSH\SMSH007";
					dialog.Text = "Tu ne t'en tireras pas comme ça !";
					Link.l1 = "Allez aboyer ailleurs, chiens !";
					Link.l1.go = "Exit_cancel";
				}
			}
			else
			{
				ChangeContrabandRelation(pchar, -10);
				Dialog.snd = "voice\SMSH\SMSH008";
				dialog.Text = "Tu vas le regretter !";
				Link.l1 = "Allons, allons !";
				Link.l1.go = "Exit_cancel";
			}
		break;

		case "GenQuestKillContraband_1":
			//счётчик подстав по "metro"...
			if(CheckAttribute(PChar, "GenQuest.contraTravel.active") && sti(PChar.GenQuest.contraTravel.active) == true)
			{
				Statistic_AddValue(PChar, "contr_TravelKill", 1);
				ChangeContrabandRelation(pchar, -20); //репу контры вниз
			}
			dialog.Text = "Tu vas nous rendre des comptes pour ce coup fourré !";
			Link.l1 = "Alors vous mourrez tous. J'ai des ordres clairs : en cas de résistance, pas de quartier !";
			Link.l1.go = "Exit_fight";
		break;

		case "SmuggleFreight_BayDone":
			int fGoods = makeint(pchar.CargoQuest.iTradeGoods);
			int fQty   = makeint(pchar.CargoQuest.iQuantityGoods);
			int fReward = makeint(pchar.CargoQuest.iMoney);
			if (CheckQuestAttribute("generate_trade_quest_progress", "failed")) fReward = makeint(fReward / 2); // overdue - half price
			else if (GetQuestPastDayParam("CargoQuest") * 2 < sti(pchar.CargoQuest.iDaysExpired)) fReward = makeint(fReward * 1.2); // early - bonus
			AddMoneyToCharacter(pchar, fReward);
			Freight_AddLoyalty(); // LEO: +1% к будущей премии выдавшего работодателя за выполненный контрабандный фрахт
			ChangeContrabandRelation(pchar, 3); // +contraband reputation
			if (!CheckAttribute(pchar, "contrabandmoneyback")) pchar.contrabandmoneyback = fReward; // counts toward the "Hardened Smuggler" perk
			else pchar.contrabandmoneyback = sti(pchar.contrabandmoneyback) + fReward;
			// опыт навыков как у обычного фрахта (Sailing=навигация, Leadership, Commerce); при просрочке - без бонуса за дни
			int fDaysMul = GetQuestPastDayParam("CargoQuest") + 1;
			if (CheckQuestAttribute("generate_trade_quest_progress", "failed")) fDaysMul = 1;
			AddCharacterExpToSkill(pchar, "Sailing", fDaysMul * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_I));
			AddCharacterExpToSkill(pchar, "Leadership", fDaysMul * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_C));
			AddCharacterExpToSkill(pchar, "Commerce", fDaysMul * sti(pchar.rank) * (GetCharacterSPECIALSimple(pchar, SPECIAL_C) + GetCharacterSPECIALSimple(pchar, SPECIAL_I)));
			RemoveCharacterGoods(pchar, fGoods, fQty);
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			AddQuestRecord("DELIVERY_TRADE_QUEST", "smug3");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(fGoods));
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			AchievementsCounter_genquests(1);
			RemoveSmugglersFromShore(); // лагерь с грузами сворачивается, как в обычной сделке (гард по quest.SmuggleFreight не даст закрыть "Сбыт контрабанды"; NPC стоят до выхода - благодарность за патруль работает)
			DeleteAttribute(pchar, "quest.SmuggleFreight");
			pchar.contratradedmoney = fReward; // patrol bribe is 10%+difficulty of this sum (same as a normal deal)
			// patrols just like a normal deal: land (on shore) + sea (patrol OR pirates)
			if (GetSummonSkillFromName(pchar, "Sneak") < Rand(120))
			{
				DoQuestCheckDelay("Rand_ContrabandInterruption", 0.1);
				ContrabandInterruptionSetStatus(true);
				Pchar.GenQuest.contraTravel.PatrolFight = true; // как в обычной сделке: за помощь в бою с патрулём смуглеры поблагодарят (один раз)
				DeleteAttribute(PChar, "GenQuest.contraTravel.PatrolBribed"); // новый патруль - мирный исход прошлого не в счёт
			}
			else
			{
				SmugRevenge_ArmDeathWatch(); // сухопутного патруля нет: вырежешь смуглеров - вместо нацпатруля придёт возмездие братства
			}
			if (GetSummonSkillFromNameToOld(pchar, SKILL_SNEAK) < dRand(12))
			{
				ArmContraFreightPursuit();
				SetTimerCondition("Rand_ContrabandInterruptionAtSeaEnded", 0, 0, 2, false);
				Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition.l1 = "MapEnter";
				Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition = "Rand_ContrabandAtSeaEnded";
			}
			DeleteAttribute(pchar, "quest.Contraband.active");
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

		case "SmuggleFreight_ScamFight":
			// кидалово, вариант "перебить всех": груз остаётся нам, заказ закрывается записью в журнале. Патрули не армим (как в Exit_fight обычной сделки)
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			// LEO: outcome record is NOT written here - the last scammer ALWAYS surrenders and pays (SmugScam_Surrender_Done),
			// the journal is filled BY FACT of surrender (smug6). smug5 was written prematurely on choosing "fight" and contradicted the outcome.
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			DeleteAttribute(pchar, "CargoQuest.SmuggleScam");
			DeleteAttribute(pchar, "quest.Contraband.active");
			AddSimpleRumourCity("Vous avez entendu ? On a trouvé toute une bande de receleurs contrebandiers dans la baie, massacrés jusqu'au dernier. On dit que ces imbéciles ont voulu rouler le mauvais capitaine : prendre la cargaison sans rien payer. Eh bien, ils ont payé, finalement : de leur sang.", Pchar.quest.contraband.City, 3, 5, "");
			LAi_group_FightGroups(LAI_GROUP_PLAYER, pchar.GenQuest.Smugglers_Group, true);
			SmuggleFreightScamHelp(); // 50% (общий дневной dRand): подмога смуглеров - сильные бойцы (как скелеты "Упокоения умерших")
			RemoveSmugglersFromShore();
			DeleteAttribute(pchar, "quest.SmuggleFreight"); // ПОСЛЕ RemoveSmugglersFromShore - флаг гасит лишнее закрытие "Сбыта контрабанды" внутри неё
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "SmuggleFreight_ScamGive":
			// кидалово, вариант "отдать груз": без оплаты, зато уходим ТИХО - ни сухопутного, ни морского патруля; +150 опыта в Везение и Скрытность
			dialog.text = "Un choix sage. Déchargez, et filez. Vous ne nous avez jamais vus, nous ne vous connaissons pas.";
			link.l1 = "Je me souviendrai de vous, les gars... Nous nous reverrons.";
			link.l1.go = "exit";
			AddSimpleRumourCity("On dit que les receleurs de la baie ont roulé un capitaine de passage : ils ont pris la cargaison et refusé de payer. Je ne les envie pas : sur ces rivages, ce genre d'affront ne se pardonne pas.", Pchar.quest.contraband.City, 3, 5, "");
			RemoveCharacterGoods(pchar, makeint(pchar.CargoQuest.iTradeGoods), makeint(pchar.CargoQuest.iQuantityGoods));
			AddCharacterExpToSkill(pchar, "Fortune", 150);
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			AddQuestRecord("DELIVERY_TRADE_QUEST", "smug4");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(makeint(pchar.CargoQuest.iTradeGoods)));
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			RemoveSmugglersFromShore(); // лагерь с грузами сворачивается (гард по quest.SmuggleFreight не даст закрыть "Сбыт контрабанды")
			DeleteAttribute(pchar, "quest.SmuggleFreight");
			DeleteAttribute(pchar, "CargoQuest.SmuggleScam");
			DeleteAttribute(pchar, "quest.Contraband.active");
			// если после кидалова нападём на шайку - они тоже призовут подмогу (детект по первому удару)
			DeleteAttribute(pchar, "quest.SmugScamGiveCalled");
			int ssgI;
			ref ssgM;
			for (ssgI = 1; ssgI <= 3 + makeint(MOD_SKILL_ENEMY_RATE * 3 / 2); ssgI++)
			{
				if (GetCharacterIndex("Rand_Smug0" + ssgI) == -1) continue;
				ssgM = CharacterFromID("Rand_Smug0" + ssgI);
				if (LAi_isDead(ssgM)) continue;
				LAi_SetCheckMinHP(ssgM, LAi_GetCharacterHP(ssgM) - 1, false, "SmugScamGive_Attacked");
			}
		break;

		case "SmugScam_Surrender": // последний выживший из шайки кидал: бой остановлен, сдаётся и расплачивается за груз
			LAi_SetStayTypeNoGroup(NPChar); // застывает на время разговора (как барыга при торговле), иначе бродит
			NPChar.actions.walk = "walk";   // подбегал бегом (walk=run) - возвращаем шаг
			LAi_SetFightMode(pchar, false); // страховка: все сабли в ножны
			LAi_SetFightModeForOfficers(false);
			dialog.text = "Arrêtez, arrêtez !.. Assez ! Vous avez gagné, que le diable vous emporte... Tenez, prenez : le paiement complet de la cargaison, comme convenu. Prenez-le et épargnez-moi.";
			link.l1 = "Voilà qui est mieux. Et souvenez-vous : avec moi, ce genre de tour finit mal.";
			link.l1.go = "SmugScam_Surrender_Done";
		break;

		case "SmugScam_Surrender_Done":
			dialog.text = "Une affaire vaut plus qu'une vie, je le vois maintenant... On s'en va, les gars... ah, c'est vrai... il ne reste plus personne pour s'en aller...";
			link.l1 = "";
			link.l1.go = "exit";
			AddSimpleRumourCity("Vous avez entendu parler du massacre de la baie ? Les receleurs pensaient rouler un capitaine pour sa cargaison, mais ils sont mal tombés. Un seul a survécu, et celui-là, dit-on, a payé le prix fort à genoux, jusqu'à la dernière piastre.", Pchar.quest.contraband.City, 3, 5, "");
			// расплата за груз: если груз ещё в трюме (исход "перебить всех") - передаём его, деньги в любом случае
			int ssGoods = makeint(pchar.CargoQuest.iTradeGoods);
			int ssQty   = makeint(pchar.CargoQuest.iQuantityGoods);
			bool ssHadCargo = (GetSquadronGoods(pchar, ssGoods) >= ssQty); // LEO: cargo still aboard = came from "kill them all"; gone = from "give cargo away"
			if (ssHadCargo) RemoveCharacterGoods(pchar, ssGoods, ssQty);
			AddMoneyToCharacter(pchar, makeint(pchar.CargoQuest.iMoney));
			// LEO: journal BY FACT - deal ended in peace (cargo handed over, payment received), record deferred here from ScamFight.
			// Only for the "kill them all" outcome (cargo was aboard): the "give cargo away" branch already wrote its own smug4 record.
			if (ssHadCargo)
			{
				AddQuestRecord("DELIVERY_TRADE_QUEST", "smug6");
				AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(ssGoods));
				CloseQuestHeader("DELIVERY_TRADE_QUEST");
			}
			// финализация НА ВЫХОДЕ из диалога (в ноде нельзя - уйдёт бродить, не договорив): бессмертный немой истукан
			AddDialogExitQuestFunction("SmugScamSurvivorRetire");
		break;

		case "SmugFreightPre_Surrender": // ГГ напал до передачи груза: последний выживший просит пощады и предлагает завершить сделку
			Diag.TempNode = "SmugFreightPre_Surrender";
			LAi_SetStayTypeNoGroup(NPChar); // застывает на время разговора (как барыга при торговле), иначе бродит
			NPChar.actions.walk = "walk";   // подбегал бегом (walk=run) - возвращаем шаг
			LAi_SetFightMode(pchar, false); // страховка: все сабли в ножны
			LAi_SetFightModeForOfficers(false);
			dialog.text = RandPhraseSimple(
				RandPhraseSimple(
					"Pitié !.. Assez de sang. Terminons simplement l'affaire : la cargaison pour nous, l'argent pour vous, comme convenu. Tuez-moi, et la confrérie apprendra qui a massacré les siens : un couteau vous attendra dans chaque port.",
					"Arrêtez, attendez ! Restons-en aux affaires : terminons le marché comme convenu, et chacun s'en va de son cכté. Sinon, NOS gens entendront parler de ce massacre, et commercer avec la cכte deviendra bien difficile pour vous."),
				"Assez, vous avez gagné !.. Mais réfléchissez bien : rompez le marché, et la Confrérie de la cכte n'oubliera pas l'affront. Terminons l'échange loyalement, et nous serons quittes.");
			link.l1 = "Vous avez gagné. Terminons l'affaire, et chacun s'en va de son cכté.";
			link.l1.go = "SmugFreightPre_Spare";
			link.l2 = "Non. Va rejoindre tes amis.";
			link.l2.go = "SmugFreightPre_Kill";
		break;

		case "SmugFreightPre_Spare": // пощада: сделка завершается под клинком, бонусы за милосердие
			dialog.text = "Voilà un bon capitaine... La cargaison à terre, et chacun suit son chemin. La confrérie n'a pas besoin de savoir ce qui s'est passé ici. Je n'ai rien vu.";
			link.l1 = "Adieu. Et fais de ton mieux pour oublier mon visage.";
			link.l1.go = "exit";
			AddSimpleRumourCity("On raconte qu'on en est venu aux lames entre contrebandiers, dans la baie : presque toute la bande a été taillée en pièces. Et le plus étrange, c'est que le dernier survivant et le capitaine de passage se sont serré la main, et que l'affaire s'est faite malgré tout. Quelles gens : d'abord ils se battent, ensuite ils commercent !", Pchar.quest.contraband.City, 3, 5, "");
			// завершение сделки: груз - смуглерам, деньги - нам
			int spGoods = makeint(pchar.CargoQuest.iTradeGoods);
			int spQty   = makeint(pchar.CargoQuest.iQuantityGoods);
			if (GetSquadronGoods(pchar, spGoods) >= spQty) RemoveCharacterGoods(pchar, spGoods, spQty);
			AddMoneyToCharacter(pchar, makeint(pchar.CargoQuest.iMoney));
			ChangeContrabandRelation(pchar, 5);               // контрабандисты ценят, что одумался
			ChangeCharacterReputation(pchar, 10);             // +репутация ГГ
			AddCharacterExpToSkill(pchar, "Leadership", 200); // +авторитет
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			AddQuestRecord("DELIVERY_TRADE_QUEST", "smug6");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(spGoods));
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			RemoveSmugglersFromShore(); // лагерь с грузами сворачивается (гард по quest.SmuggleFreight не даст закрыть "Сбыт контрабанды")
			DeleteAttribute(pchar, "quest.SmuggleFreight");
			// сделка СОСТОЯЛАСЬ (пусть и под клинком) - патрули как при обычной передаче: сухопутный + морской
			pchar.contratradedmoney = makeint(pchar.CargoQuest.iMoney); // откуп патрулю - 10%+сложность от этой суммы
			if (GetSummonSkillFromName(pchar, "Sneak") < Rand(120))
			{
				DoQuestCheckDelay("Rand_ContrabandInterruption", 0.1);
				ContrabandInterruptionSetStatus(true);
			}
			if (GetSummonSkillFromNameToOld(pchar, SKILL_SNEAK) < dRand(12))
			{
				ArmContraFreightPursuit();
				SetTimerCondition("Rand_ContrabandInterruptionAtSeaEnded", 0, 0, 2, false);
				Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition.l1 = "MapEnter";
				Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition = "Rand_ContrabandAtSeaEnded";
			}
			DeleteAttribute(pchar, "quest.Contraband.active");
			// финализация НА ВЫХОДЕ из диалога (в ноде нельзя - уйдёт бродить, не договорив): бессмертный немой истукан
			AddDialogExitQuestFunction("SmugScamSurvivorRetire");
		break;

		case "SmugFreightPre_Kill": // отказ: добиваем последнего, груз остаётся нам, отношение контрабандистов - в ноль
			dialog.text = "Soit... La Confrérie de la cכte n'oubliera pas ça. Maudit sois-tu...";
			link.l1 = "J'en tremble déjà. Va rejoindre les autres.";
			link.l1.go = "exit";
			AddSimpleRumourCity("Une chose affreuse dans la baie : toute la bande de receleurs massacrée jusqu'au dernier, même celui qui implorait grâce. On dit que la Confrérie de la cכte est furieuse. Je ne voudrais pas être dans la peau de ce boucher quand les contrebandiers découvriront qui a fait ça.", Pchar.quest.contraband.City, 3, 5, "");
			int pkRel = ChangeContrabandRelation(pchar, 0);
			if (pkRel > 0) ChangeContrabandRelation(pchar, -pkRel); // минусуем отношение контрабандистов в ноль
			ChangeCharacterReputation(pchar, -20); // добить молящего о пощаде - удар по репутации ГГ
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";
			AddQuestRecord("DELIVERY_TRADE_QUEST", "smug7");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(makeint(pchar.CargoQuest.iTradeGoods)));
			CloseQuestHeader("DELIVERY_TRADE_QUEST");
			RemoveSmugglersFromShore(); // лагерь с грузами сворачивается (гард по quest.SmuggleFreight не даст закрыть "Сбыт контрабанды")
			DeleteAttribute(pchar, "quest.SmuggleFreight");
			DeleteAttribute(pchar, "quest.Contraband.active");
			// возвращаем его в бой смертным на последнем издыхании - добить легко
			DeleteAttribute(pchar, "GenQuest.SmugScamSurvivorId"); // финализация пощады не понадобится
			// после его смерти снимаем боевую тревогу (врагов не останется)
			pchar.quest.SmugScamKillDone.win_condition.l1 = "NPC_Death";
			pchar.quest.SmugScamKillDone.win_condition.l1.character = NPChar.id;
			pchar.quest.SmugScamKillDone.win_condition = "SmugScamKillDone";
			LAi_SetImmortal(NPChar, false);
			LAi_SetWarriorType(NPChar);
			LAi_group_MoveCharacter(NPChar, pchar.GenQuest.Smugglers_Group);
			LAi_group_SetRelation(pchar.GenQuest.Smugglers_Group, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(LAI_GROUP_PLAYER, pchar.GenQuest.Smugglers_Group, true);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Exchange":
			// сама торговля -->
			if(FindFirstContrabandGoods(Pchar) == -1 && sti(Pchar.quest.Contraband.Counter) == 0)
			{
				dialog.Text = "Eh bien, qu'est-ce que tu fais ici ? Tu n'as rien à vendre ! Tout ce que tu as dans ta cale, on peut l'acheter en ville !";
				Link.l1 = "Pas de chance.";
				Link.l1.go = "Exit";
			}
			else
			{
				// установим окружение -->
				if (sti(Pchar.quest.Contraband.Counter) == 0) // не торговали ещё
				{
					if(drand(11) == 3)
					{
						dialog.Text = "Tiens, tiens... Je crois que nous allons prendre ta marchandise gratuitement. Tu ne vas guère te plaindre aux autorités.";
						Link.l1 = "Eh bien, essaie donc !";
						Link.l1.go = "Exit_fight";
										break;
					}
					// море и солдаты на суше НЕЗАВИСИМЫ!!!
					if(GetSummonSkillFromNameToOld(Pchar, SKILL_SNEAK) < dRand(12))
					{
						SetCoastalGuardPursuit();
					}
					// при убегании от патруля на карту - корабли трём
					SetTimerCondition("Rand_ContrabandInterruptionAtSeaEnded", 0, 0, 2, false);// если в порту сидим, спим, то 2 день

					Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition.l1 = "MapEnter";
					Pchar.quest.Rand_ContrabandAtSeaEnded.win_condition = "Rand_ContrabandAtSeaEnded";
				}
				// установим окружение <--
				dialog.Text = RandPhraseSimple("Alors, quelle cargaison veux-tu vendre ?",
																	"Qu'est-ce que tu vends ?");
				Link.l1 = "Eh bien, voyons ça.";
				Link.l1.go = "Exchange1";
				if (sti(Pchar.quest.Contraband.Counter) == 0)
				{
					Link.l99 = "Je crois que j'ai changé d'avis.";
					Link.l99.go = "Cancellation";
				}
			}
		break;

		case "Exchange1":
			NPChar.quest.meeting = NPC_Meeting;
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			LaunchContrabandTrade(CharacterFromId(pchar.GenQuest.Contraband.SmugglerId),  sti(pchar.FindContrabandGoods.StoreIdx));
		break;

		case "Finish_exit":
			// таможня на суше
			if(GetSummonSkillFromName(pchar, "Sneak") < Rand(120) && !CheckAttribute(pchar, "quest.Contraband.InterruptionGot"))
			{
				Pchar.GenQuest.contraTravel.PatrolFight = true;
				DeleteAttribute(PChar, "GenQuest.contraTravel.PatrolBribed"); // новый патруль - мирный исход прошлого не в счёт
				Pchar.quest.Contraband.InterruptionGot = true;
				DoQuestCheckDelay("Rand_ContrabandInterruption", 0.1);
				ContrabandInterruptionSetStatus(true);
			}
			else
			{
				SmugRevenge_ArmDeathWatch(); // сухопутного патруля нет: вырежешь смуглеров - вместо нацпатруля придёт возмездие братства
			}
			if (!CheckAttribute(pchar, "quest.Contraband.SneakGot"))
			{
				pchar.quest.Contraband.SneakGot = true;
				AddCharacterExpToSkill(Pchar, "Sneak", 100);
				SetTimerCondition("ContraСlearGot", 0, 0, 1, false);
			}
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			ChangeContrabandRelation(pchar, 15);
			OfficersReaction("bad");
			ChangeCharacterReputation(pchar, -1);

			CloseQuestHeader("Gen_Contraband");

			DeleteAttribute(Pchar, "quest.Contraband.active");
			DeleteAttribute(Pchar, "quest.Contraband.counter");
			DeleteAttribute(Pchar, "quest.Contraband.price1");
			DeleteAttribute(Pchar, "quest.Contraband.price2");
			DeleteAttribute(Pchar, "quest.Contraband.price3");
			DeleteAttribute(Pchar, "quest.Contraband.price4");
			DeleteAttribute(Pchar, "quest.Contraband.price5");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX1");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX2");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX3");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX4");
			DeleteAttribute(Pchar, "quest.Contraband.goodsIDX5");
			DeleteAttribute(Pchar, "quest.Contraband.sum");
			DeleteAttribute(Pchar, "quest.Contraband.ChooseGoodsQty");
			DeleteAttribute(Pchar, "quest.Contraband.ChooseGoodsID");

			Pchar.quest.Rand_Smuggling.over = "yes";
			RemoveSmugglersFromShore();
		break;
	}
}
