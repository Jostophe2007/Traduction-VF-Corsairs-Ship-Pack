//#include "DIALOGS\convoy_traider.h"
void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag;
	string NPC_Meeting;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Vous vouliez quelque chose, capitaine ?";
			Link.l1 = "Non, rien. Je vérifie juste que tout va bien.";
			link.l1.go = "exit";
		break;

		case "prepare_convoy_quest":
			if (isBadReputation(pchar, 40))
			{
				dialog.text = RandPhraseSimple("Oh, bon sang !! Je sais qui vous êtes ! Il faut être un parfait idiot pour vous engager comme escorte de son navire. Adieu !", "Ah, je sais qui vous êtes ! Vous engager comme escorte ?! Cherchez un autre imbécile...");
				link.l1 = RandPhraseSimple("Héhé, quel froussard...", "Que les gens sont devenus peureux !");
				link.l1.go = "convoy_refused";
			}
			else
			{
				dialog.text = TimeGreeting() + ", "+GetAddress_Form(NPChar) + " ! Je suis "+ GetFullName(NPChar) + ", marchand. J'ai entendu dire que vous cherchiez du travail ?";
				link.l1 = "Quelque chose comme ça. Et, à ce que j'ai entendu, vous cherchez un capitaine qui vous accompagnerait, vous et votre navire, jusqu'à destination ?";
				link.l1.go = "prepare_convoy_quest_2";
			}
		break;

		case "prepare_convoy_quest_2":
			dialog.text = "C'est exact. D'ailleurs, je pense que vous me conviendrez comme escorte. Qu'en dites-vous ?";
			link.l1 = "Je vous dirai : donnez-moi le montant, et nous trouverons peut-être un accord.";
			link.l1.go = "prepare_convoy_quest_3";
		break;

		case "prepare_convoy_quest_3":
			LookShipConvoy();
			GenerateConvoyQuest(npchar);
			dialog.text = "Il faut m'escorter jusqu'à " + XI_ConvertString("Colony" + pchar.quest.destination + "Gen") + " sur l'île de " + XI_ConvertString(GetIslandByCityName(pchar.quest.destination) + "Voc") +
				", dans un délai de " + FindRussianDaysString(sti(pchar.ConvoyQuest.iDay)) +", et pour cela, je vous paierai " + FindRussianMoneyString(sti(pchar.ConvoyQuest.convoymoney)) + ". Qu'en pensez-vous ?";
			link.l1 = "J'accepte.";
			link.l1.go = "convoy_agreeded";
			link.l2 = "Je ne pense pas que ça m'intéresse.";
			link.l2.go = "convoy_refused";
		break;

		case "convoy_refused":
			chrDisableReloadToLocation = false;
			npchar.LifeDay = 0;
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("convoy_refused");
		break;

		case "convoy_agreeded":
			chrDisableReloadToLocation = false;
		    pchar.convoy_quest = pchar.quest.destination;
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("convoy_agreeded");
		break;

		case "complete_convoy_quest":
			dialog.text = "Oh ! Merci. Je ne me suis jamais senti aussi tranquille que sous votre protection. Voici votre récompense.";
			Link.l1 = "Merci.";
			link.l1.go = "exit";
			//слухи
			AddSimpleRumour(LinkRandPhrase("Un certain capitaine marchand du nom de " + GetFullName(npchar) + " dit qu'on peut faire confiance à " + GetMainCharacterNameDat() + " pour escorter les navires marchands.",
				"Un marchand du nom de " + GetFullName(npchar) + " dit que le capitaine " + GetMainCharacterNameDat() + " est digne de confiance. "+ GetSexPhrase("Il a protégé son navire", "Elle a protégé son navire") +" de la meilleure façon qui soit pendant l'escorte jusqu'à " + XI_ConvertString("Colony" + pchar.quest.destination + "Gen") + ".",
				"J'ai entendu dire que vous tenez parole quand vous escortez les navires des capitaines marchands. Un certain marchand du nom de " + GetFullName(npchar) + " dit le plus grand bien de vous."), sti(npchar.nation), 40, 1);
			pchar.quest.generate_convoy_quest_progress = "completed";
			chrDisableReloadToLocation = false;
			npchar.LifeDay = 0;
			AddDialogExitQuest("convoy_refused");
		break;
	}
}

// boal 03.05.04 квест сопроводить торговца -->
void GenerateConvoyQuest(ref npchar)
{
	int iTradeMoney, iNation;

	DeleteAttribute(NPChar, "Ship");
    SetShipToFantom(NPChar, "trade", true);

	iNation = GetRelation2BaseNation(sti(npchar.nation)); //если привезти нужно во вражеский город
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(pchar.ConvoyQuest.City), GetArealByCityName(pchar.quest.destination));
	if (sti(daysQty) > 14) daysQty = 14;
	pchar.ConvoyQuest.iDay = makeint(sti(daysQty)*(frand(1.3)+0.7));
	iTradeMoney = (sti(daysQty)*600*sti(pchar.GenQuest.Convoy.Shipmod)+rand(100))*sti(daysQty)/sti(pchar.ConvoyQuest.iDay);
	if (iNation == RELATION_ENEMY && sti(npchar.nation != PIRATE)) iTradeMoney = makeint(iTradeMoney * 1.4); //то размер награды увеличивается
	pchar.ConvoyQuest.convoymoney = iTradeMoney;

	//Log_Info(FindRussianDaysString(sti(daysQty)));
	//Log_Info(pchar.quest.destination);
	//Log_Info(pchar.ConvoyQuest.City);
	SetTimerCondition("generate_convoy_quest_timer", 0, 0, sti(pchar.ConvoyQuest.iDay), false);

	pchar.quest.generate_convoy_quest_progress = "begin";

	pchar.quest.generate_convoy_quest_failed.win_condition.l1 = "NPC_Death";
	pchar.quest.generate_convoy_quest_failed.win_condition.l1.character = "QuestTrader";
	pchar.quest.generate_convoy_quest_failed.win_condition = "generate_convoy_quest_failed";
}

void LookShipConvoy()
{
	switch(makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)))
	{
		case 0:
			pchar.GenQuest.Convoy.Shipmod = 0.7;
		break;
		case 1:
			pchar.GenQuest.Convoy.Shipmod = 1;
		break;
		case 2:
			pchar.GenQuest.Convoy.Shipmod = 1.2;
		break;
		case 3:
			pchar.GenQuest.Convoy.Shipmod = 1.5;
		break;
		case 4:
			pchar.GenQuest.Convoy.Shipmod = 2.2;
		break;
		case 5:
			pchar.GenQuest.Convoy.Shipmod = 3;
		break;
		case 6:
			pchar.GenQuest.Convoy.Shipmod = 4.5;
		break;
	}
}
