// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr4SoleiRoyal_GoodWork")
			{
				dialog.text = "Je vous écoute, capitaine.";
				link.l1 = "Monsieur, le gouverneur général de Tortuga m'a chargé d'escorter le vaisseau de premier rang Soleil Royal jusqu'à l'île de la Dominique. L'escadre de la Guadeloupe devait m'y attendre, mais elle n'y était pas. Pourriez-vous m'éclairer sur la situation ?";
				link.l1.go = "Step_F4_1";
			}
			if (pchar.QuestTemp.TohmasPetit_Quest == "return_to_baster")
			{
				link.l2 = "Monsieur le gouverneur, Thomas Petit et Madeline LeBlanc sont dans ma cale. Ces fameux escrocs qui renseignaient des bandits et dévalisaient les capitaines de passage dans la jungle. Je les ai attrapés.";
				link.l2.go = "TohmasPetit_Gov_HandOver";
			}
		break;
		//************************** Фр.линкейка, квест №4. Солей Руаяль ************************
		case "Step_F4_1":
            dialog.text = "Le fait est que je n'ai reçu l'ordre de faire mouvement vers la Dominique avec l'escadre qu'hier : le courrier était très en retard. Je n'ai donc pas eu le temps de préparer l'escadre. Je suppose que vous venez de la Dominique...";
			link.l1 = "C'est exact. J'ai dמ affronter l'escadre espagnole d'un certain Juan Galeno. Il avait repéré le Soleil Royal et a tenté de s'en emparer.";
            link.l1.go = "Step_F4_2";
        break;
		case "Step_F4_2":
            dialog.text = "Et oם sont ce Juan Galeno et son escadre maintenant ?";
			link.l1 = "Par le fond, monsieur...";
            link.l1.go = "Step_F4_3";
        break;
		case "Step_F4_3":
			if (CheckCompanionInCharacter(pchar, "SoleiRoyalCaptain"))
			{
				dialog.text = "Haha, beau travail ! Eh bien, votre mission est accomplie : vous avez su mener le Soleil Royal à destination et faire face avec honneur à une situation difficile. Beau travail, capitaine. Je prends maintenant le commandement du Soleil Royal.";
				link.l1 = "Bien, monsieur. Je ne vous retiens pas : les affaires... Au revoir, monsieur.";
				link.l1.go = "exit";
				RemoveCharacterCompanion(pchar, characterFromId("SoleiRoyalCaptain"));
				pchar.questTemp.State = "Fr4SoleiRoyal_backTortuga";
				AddQuestRecord("Fra_Line_4_SoleiRoyal", "6");
			}
			else
			{
				dialog.text = "Mais vous n'avez pas su sauver le Soleil Royal ! C'est mauvais, "+ GetSexPhrase("monsieur", "mademoiselle") +", très mauvais... Vous devez maintenant rendre compte au gouverneur général de Tortuga de l'échec de votre mission. Adieu.";
				link.l1 = "Adieu, monsieur...";
				link.l1.go = "exit";
				pchar.questTemp.State = "Fr4SoleiRoyal_SoleiRoyalSunk";
				AddQuestRecord("Fra_Line_4_SoleiRoyal", "7");
			}
        break;
		//************************** Квестовые штрумы ************************
		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;
		//Квест Аскольда, штурм в обличие мумии
        case "Ascold_MummyAttack":
			dialog.text = "Aaah !!!";
			Link.l1 = "Arrête de hurler, idiot. Je suis ici pour affaires et je ne te ferai pas de mal.";
			Link.l1.go = "Step_Asc1";
			AfterTownBattle();
        break;
        case "Step_Asc1":
            dialog.text = "La momie parle !!! Aaah !!!";
			Link.l1 = "וcoute-moi, misérable lâche. Je sais que tu as quatre objets : trois crânes toltèques en cristal de couleurs différentes et un étrange objet indien qui ressemble à un hochet. Donne-moi ces objets, et nous quitterons la ville.";
			Link.l1.go = "Step_Asc2";
        break;
        case "Step_Asc2":
            dialog.text = "Ils sont dans l'armoire à ma gauche, dans l'un des tiroirs fermés. Voici la clé, vous pouvez tout prendre...";
			Link.l1 = "Comme si tu pouvais me l'interdire, vermisseau...";
			Link.l1.go = "exit";
			NextDiag.TempNode = "Cupture_after";
			Locations[FindLocation(pchar.location)].box1.items.sculMa1 = 1;
            Locations[FindLocation(pchar.location)].box1.items.sculMa2 = 1;
            Locations[FindLocation(pchar.location)].box1.items.sculMa3 = 1;
            Locations[FindLocation(pchar.location)].box1.items.indian22 = 1;
            pchar.questTemp.Ascold = "Ascold_MummyFoundItems";
			chrDisableReloadToLocation = false;
			SetReturn_Gover_Dialog_Exit(NPChar);
        break;
		
		case "TohmasPetit_Gov_HandOver":
			dialog.text = "Ah, Thomas Petit... Je me souviens, je me souviens. On a déposé tant de plaintes contre lui ici que je n'avais pas assez d'encre pour toutes les signer. Eh bien, c'est louable, capitaine.";
			link.l1 = "Je tiens aussi à vous informer que votre commandant n'a pas levé le petit doigt quand je lui ai demandé de l'aide ! Il a prétendu ne pas avoir d'hommes. Pendant que la garde se tournait les pouces, j'ai mené des recherches épuisantes, j'ai rattrapé les fugitifs en mer et j'ai eu bien du mal à convaincre le capitaine du sloop de me les livrer. Et tout ça pour récupérer mes 40 000 piastres que ce gredin m'a extorquées !";
			link.l1.go = "TohmasPetit_Gov_HandOver_Details";
		break;

		case "TohmasPetit_Gov_HandOver_Details":
			dialog.text = "Je réprimanderai le commandant à l'occasion, bien sמr, mais je ne le jugerai pas sévèrement. Il croule déjà sous le travail, avec des corsaires espagnols qui apparaissent sans cesse à l'horizon : attraper de simples escrocs ne fait pas partie de ses priorités. Ce sera tout : prenez les 15 000 piastres qui vous reviennent de droit, et vous pouvez disposer.";
			link.l1 = "Et c'est tout ?! 40 000 piastres volées, et vous me jetez quinze mille ? Cette aumכne de votre chancellerie est loin de compenser mes pertes ! J'exige une indemnisation complète sur les biens confisqués du voleur !";
			link.l1.go = "TohmasPetit_Gov_HandOver_Value";
		break;

		case "TohmasPetit_Gov_HandOver_Value":
			dialog.text = "Vous vous permettez beaucoup trop dans mon bureau, capitaine ! Estimez-vous heureux qu'on vous paie tout court. Quinze mille, c'est une récompense plus que généreuse pour les têtes de toute une bande d'égorgeurs de la jungle qui menacent directement la ville. Votre petit voleur n'est que du menu fretin à cכté d'eux. Prenez l'or et quittez la résidence.";
			link.l1 = "Ce fut un plaisir d'aider... la justice, Votre Excellence. Bonne journée.";
			link.l1.go = "TohmasPetit_Gov_HandOver_Complete";
		break;

		case "TohmasPetit_Gov_HandOver_Complete":
			DialogExit();
			// Log entry and quest closure
			AddQuestRecord("TohmasPetit", "TohmasPetit_GovComplete");
			CloseQuestHeader("TohmasPetit");
			AddDialogExitQuest("TohmasPetit_Gov_Reward");
			pchar.questdata.TohmasPetit = 1;
			TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

