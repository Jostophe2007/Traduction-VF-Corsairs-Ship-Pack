#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			//после драки, когда Сесил пытаются убить
			if (pchar.questTemp.LSC == "toKnowAboutMechanic")
			{
				dialog.text = "Vous les avez tués ! Merci !";
				link.l1 = "Hum, qui sont ces gens ?";
				link.l1.go = "AfterFight";
				break;
			}

			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					if (npchar.location == "AvaShipInside3") dialog.text = "Bienvenue dans mon humble demeure, capitaine. Comment vous en êtes-vous sorti dans la tempête ?";
					else dialog.text = "Salutations, capitaine. Comment vous en êtes-vous sorti dans la tempête ?";
					link.l1 = "Non sans mal, mais merci de vous en soucier. Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
				else
				{
					if (npchar.location == "AvaShipInside3") dialog.text = "Bienvenue dans mon humble demeure, capitaine. Comment êtes-vous arrivé jusqu'ici ?";
					else dialog.text = "Salutations, capitaine. Comment êtes-vous arrivé jusqu'ici ?";
					link.l1 = "Non sans mal, mais merci de vous en soucier. Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que vous faut-il encore ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Oh, j'écouterais volontiers les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de m'accompagner jusqu'au continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, vous vous prenez pour d'Artagnan, à courir partout en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand"+ GetSexPhrase(" des hommes", " des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		case "FS_1":
			dialog.text = GetFullName(npchar) + ", capitaine. Enchantée.";
			link.l1 = "Que faites-vous ici par un temps pareil ?";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "Sauf votre respect, capitaine, cela ne vous regarde pas.";
			link.l1 = "Je comprends. Nous avons tous quelque chose à cacher, n'est-ce pas ?";
			link.l1.go = "FS_3";
		break;
		case "FS_3":
			dialog.text = "Veuillez quitter ma maison !";
			link.l1 = "La Loi vous permet-elle de faire ça ?";
			link.l1.go = "FS_4";
		break;
		case "FS_4":
			dialog.text = "Si le visiteur est "+ GetSexPhrase("un rustre mal élevé", "une fille mal élevée") +", c'est amplement suffisant !";
			link.l1 = "Oh, merci du compliment...";
			link.l1.go = "exit";
		break;

		case "FT_1":
			dialog.text = GetFullName(npchar) + ", capitaine. Enchantée.";
			link.l1 = "Que faites-vous ici ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Sauf votre respect, capitaine, cela ne vous regarde pas.";
			link.l1 = "Je comprends. Nous avons tous quelque chose à cacher, n'est-ce pas ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Veuillez quitter ma maison !";
			link.l1 = "Ne vous emportez pas, je ne fais que m'habituer.";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Allez vous habituer ailleurs.";
			link.l1 = "Hum, je ne vous dérangerai pas.";
			link.l1.go = "exit";
		break;
		//ищем человека
		case "SeekCitizen":
			dialog.text = "Si je l'ai vu, je vous le dirai sans faute. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pense à quelqu'un d'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Que peut-on faire ici, à part se promener en s'apitoyant sur son sort ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Comment la vie est-elle organisée ? Les gens travaillent-ils ici ?";
				link.l2.go = "ansewer_2";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Quelle arrogance ! Vous feriez mieux d'oublier la puissance que vous aviez sur mer et sur terre. C'était peut-être le cas, bien sמr... Mais pas ici ! Ici, vous n'êtes personne, comme nous tous, et ce qui compte pour vous maintenant, c'est de gagner la faveur des gens de la Cité, et vous...";
			link.l1 = "Je ne voulais pas vous offenser, madame. Dites-moi simplement ce que l'on peut faire ici pendant ses loisirs. Quelque chose d'intéressant, hein ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "D'intéressant ? Vous aimez le risque, c'est ça ? Eh bien, essayez de rendre visite aux Narvals, par exemple...";
			link.l1 = "Vous parlez du clan des Narvals ?";
			link.l1.go = "ansewer_1_2";
		break;
		case "ansewer_1_2":
			dialog.text = "D'eux-mêmes. Vous aurez beaucoup d'émotions, je vous le promets.";
			link.l1 = "Hum, vous êtes une drכle de dame, à ce que je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Ha, si seulement ça avait un sens... ou un but. Mais ici, on ne peut pas se fixer de buts. Vous ne sortirez pas d'ici vivant, comme nous tous.";
			link.l1 = "Très encourageant...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		//квесты
		case "HelpMe":
			dialog.text = "Mon Dieu, aidez-moi !! Ne les laissez pas me tuer !!";
			link.l1 = "Que s'est-il passé ?";
			link.l1.go = "HelpMe_1";
		break;
		case "HelpMe_1":
			dialog.text = "Plus tard... Protégez-moi, je vous en prie !";
			link.l1 = "Hum, je ne vois encore personne.";
			link.l1.go = "exit";
			npchar.quest.meeting = "1";
			AddDialogExitQuestFunction("LSC_SaveSesilGalard_2");
		break;

		case "AfterFight":
			dialog.text = "Ce sont des « Caspers ».";
			link.l1 = "Ils ont déjà fait main basse sur ce navire ?";
			link.l1.go = "AfterFight_1";
		break;
		case "AfterFight_1":
			dialog.text = "Non, pas du tout. Ils sont juste venus me tuer.";
			link.l1 = "C'est aussi simple que ça ? Ils ont enfreint la Loi de la Cité, qui donne aux citoyens le droit à la vie !";
			link.l1.go = "AfterFight_2";
			npchar.greeting = "Gr_Woman_Citizen";
		break;
		case "AfterFight_2":
			dialog.text = ""+ GetSexPhrase("Jeune homme", "Jeune fille") +", je vais vous dire une chose... Je suis sans doute la plus ancienne habitante de cette île, et j'en ai vu, des choses de ce genre, ici.";
			link.l1 = "Vous viviez ici avant l'arrivée de Hill Brunner dans la Cité ?";
			link.l1.go = "AfterFight_3";
		break;
		case "AfterFight_3":
			dialog.text = "Je vis ici depuis environ dix ans. Quand la mer m'a rejetée sur l'île, il n'y vivait que cinq personnes, et Hill Brunner n'en faisait pas partie.";
			link.l1 = "דa alors... Vous savez, avant de mourir, Hill Brunner cherchait quelqu'un qui était arrivé sur l'île avant lui.";
			link.l1.go = "AfterFight_4";
		break;
		case "AfterFight_4":
			dialog.text = "Vous savez pourquoi ?";
			link.l1 = "Apparemment, pour poser des questions sur le Mécanicien.";
			link.l1.go = "AfterFight_5";
		break;
		case "AfterFight_5":
			dialog.text = "Hum, eh bien, ça alors... Vous savez, depuis qu'il est isolé, vous êtes la deuxième personne à qui je parle de lui. La première, c'était Teaser Dan.";
			link.l1 = "Teaser Dan ?! Bon sang, vous savez ce qui lui est arrivé ?";
			link.l1.go = "AfterFight_6";
		break;
		case "AfterFight_6":
			dialog.text = "On dit qu'il s'est noyé.";
			link.l1 = "Pas du tout. Il a atteint le continent !";
			link.l1.go = "AfterFight_7";
		break;
		case "AfterFight_7":
			dialog.text = "Alors il est vivant ?!";
			link.l1 = "Euh, plus maintenant... Il a été tué à Willemstad par des agents de la Compagnie néerlandaise des Indes orientales.";
			link.l1.go = "AfterFight_8";
		break;
		case "AfterFight_8":
			dialog.text = "Oh, quel dommage ! Il a réalisé son rêve, il est sorti d'ici, mais il n'a pas pu se sauver. C'est dommage...";
			link.l1 = "Oui, c'est dommage... Dites-moi, qui est donc ce Mécanicien ?";
			link.l1.go = "AfterFight_9";
		break;
		case "AfterFight_9":
			dialog.text = "Oh, c'est un homme légendaire, il s'appelle Henrik Wedeker. La grande majorité des citoyens de la Cité ne savent même pas qu'il vit parmi nous. Je n'ai plus vu le Mécanicien depuis que le clan des Caspers s'est installé sur la barque San Gabriel.";
			link.l1 = "Vous avez dit qu'il était isolé...";
			link.l1.go = "AfterFight_10";
		break;
		case "AfterFight_10":
			dialog.text = "Eh bien, comment l'appeler autrement ? Je pense que l'amiral tient délibérément Henrik à l'écart. Le fait est que le Mécanicien est une personne extraordinairement douée quand il s'agit de fabriquer quelque chose. א une époque, il s'est mis à parler d'un danger qui nous menaçait tous. Il disait que nous devions quitter la Cité avant qu'il ne soit trop tard\n"+
				"Mais vous savez, on ne prend pas les excentriques au sérieux, alors on n'a fait que rire de ses histoires. Et puis est arrivée la Loi interdisant la construction d'embarcations, et aussitכt, les « Caspers » ont occupé le San Gabriel. Bref, il est devenu malvenu de parler de notre excentrique, et dangereux aussi.";
			link.l1 = "Comment ça, dangereux ?";
			link.l1.go = "AfterFight_11";
		break;
		case "AfterFight_11":
			dialog.text = "Les gens qui connaissaient personnellement Henrik ont commencé à disparaître sans laisser de traces. Et j'aurais disparu aujourd'hui, moi aussi, sans vous...";
			link.l1 = "Vous voulez parler de cette tentative de meurtre ?";
			link.l1.go = "AfterFight_12";
		break;
		case "AfterFight_12":
			dialog.text = "Exactement. Il est devenu très facile de dissimuler les traces d'un crime. Le fait est qu'il y a d'affreuses créatures sous nous, dans les profondeurs. Si l'on jette un corps à l'eau, il ne remonte même pas à la surface ensuite...";
			link.l1 = "Oh... Et pourquoi a-t-on isolé le Mécanicien ? Ou peut-être l'a-t-on déjà tué ?";
			link.l1.go = "AfterFight_13";
		break;
		case "AfterFight_13":
			dialog.text = "Le Mécanicien est vivant parce que c'est un homme trop nécessaire. Après tout, c'est lui qui a trouvé le moyen d'attacher les navires les uns aux autres. Quand je suis arrivée ici, il n'y avait que quatre navires, et ils bougeaient sans cesse. Et Henrik a réussi à les fixer de façon qu'ils tiennent normalement.";
			link.l1 = "Ah, c'est donc ça...";
			link.l1.go = "AfterFight_14";
		break;
		case "AfterFight_14":
			dialog.text = "Et Chad l'a isolé après qu'il a commencé à semer la panique. Il disait que nous devions tous partir d'ici tant que nous en avions la possibilité...";
			link.l1 = "Compris. Je suppose que je devrais aller voir votre génie, Henrik, pour lui parler.";
			link.l1.go = "AfterFight_15";
		break;
		case "AfterFight_15":
			dialog.text = "Eh bien, allez-y. Bonne chance !";
			link.l1 = "Merci.";
			link.l1.go = "AfterFight_16";
		break;
		case "AfterFight_16":
			LAi_SetOwnerTypeNoGroup(npchar);
			pchar.questTemp.LSC = "toSeekMechanik";
			AddQuestRecord("ISS_MainLine", "31");
			pchar.quest.LSC_enterCasper.win_condition.l1 = "location";
			pchar.quest.LSC_enterCasper.win_condition.l1.location = "SanGabrielMechanic";
			pchar.quest.LSC_enterCasper.function = "LSC_enterCasper";
			sld = characterFromID("Casper_head");
			LAi_SetImmortal(sld, false);
			for (int i=1; i<=11; i++)
			{
				sld = characterFromID("Casper_"+i);
				LAi_SetImmortal(sld, false);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Proposition intéressante...",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "דa suffit, vous m'avez fatiguée...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, et elle tombe à pic. Une terrible tempête approche de la Cité.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Que dites-vous là ? Et qui vous a dit ça ?";
			link.l1 = "Nul autre que le célèbre Henrik Wedeker.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Hum... Vous savez, je vais tenter ma chance et rester ici. Je suis trop vieille pour les voyages en mer.";
			link.l1 = "Vous êtes sמre de votre décision ? Je ne vous ai pas sauvée des « Caspers » pour que vous risquiez bêtement votre vie.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Admettez, capitaine, que j'en ai le droit.";
			link.l1 = "Sans aucun doute.";
			link.l1.go = "SeekCrew_4";
		break;
		case "SeekCrew_4":
			dialog.text = "Alors, la conversation est terminée.";
			link.l1 = "Eh bien, c'est dommage.";
			link.l1.go = "exit";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
