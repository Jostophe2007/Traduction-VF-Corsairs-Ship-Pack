// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "RevengeMansfield_toTavern": //Голландская линейка, квест №6. Узнать инфу о губере.
                    link.l2 = "Comment vont les choses, au fait ? La ville prospère ?";
                    link.l2.go = "Step_H6_1";
                break;
                case "Fr7RockBras_toSeekPlace": //Фр. линейка, квест №7. Узнать инфу о Роке Бразильце.
					link.l1 = "J'ai entendu dire qu'un célèbre pirate, Rock le Brésilien, était tombé entre les mains de l'Inquisition...";
					link.l1.go = "Step_F7_1";
                break;
            }
            // <== Проверяем поле состояния квестов.
		break;
//**************************** Голл. линейка, квест №6. Узнать для Моргана инфу о губере Сантьяго ************************
 	 	case "Step_H6_1":
			dialog.text = "Louange à Dieu tout-puissant, nous nous portons bien. La ville prospère.";
			link.l1 = "Entouré d'ennemis, il est plutכt difficile de prospérer. Comment faites-vous ?";
			link.l1.go = "Step_H6_2";
        break;
 	 	case "Step_H6_2":
			dialog.text = "Notre gouverneur, José Sancho Jimenez, sait régler les problèmes. Il s'est récemment débarrassé de la colonie de boucaniers d'Hispaniola. Une belle affaire, je vous le dis !";
			link.l1 = "Eh bien ! Les boucaniers vous gênaient tant que ça ?";
			link.l1.go = "Step_H6_3";
        break;
 	 	case "Step_H6_3":
			dialog.text = "Non, pour moi, c'était plus pratique avec eux. J'avais toujours de la bonne viande fraîche pour ma cuisine. Et bon marché, en plus. Maintenant, c'est plus difficile, tout devient plus cher.";
			link.l1 = "Hum, alors pourquoi votre gouverneur a-t-il fait ça ?";
			link.l1.go = "Step_H6_4";
        break;
 	 	case "Step_H6_4":
			dialog.text = "Le diable seul le sait. Sans doute parce que c'étaient tous de sales Français. Hispaniola doit être espagnole !";
			link.l1 = "Eh bien, soit... וcoutez, je voudrais entrer au service de votre gouverneur. Que me conseillez-vous ? Est-il seulement en ville ?";
			link.l1.go = "Step_H6_5";
        break;
 	 	case "Step_H6_5":
			dialog.text = "Oui, il est ici en ce moment. Et vous pourrez facilement vous faire engager si vous vous adressez à lui en personne.";
			link.l1 = "Compris... Et il ne compte aller nulle part prochainement, vous ne savez pas ?";
			link.l1.go = "Step_H6_6";
        break;
 	 	case "Step_H6_6":
			dialog.text = "Oui, non, nulle part. Nous avons bientכt une fête en ville, il sera donc sמrement là... Hé, pourquoi avez-vous besoin de savoir ça ?";
			link.l1 = "Comme ça, pour rien...";
			link.l1.go = "Step_H6_7";
        break;
 	 	case "Step_H6_7":
			dialog.text = "Pour rien, mais pas pour rien. Si vous voulez un emploi, allez-y et faites-vous engager. Pourquoi avez-vous besoin de savoir oם sera le gouverneur ces prochains jours ?";
			link.l1 = "Pourquoi vous énervez-vous comme ça, je ne comprends pas ?! Restez là à faire rכtir votre viande et à vendre votre lard...";
			link.l1.go = "Step_H6_8";
        break;
 	 	case "Step_H6_8":
			dialog.text = "Vous êtes "+ GetSexPhrase("soupçonneux, señor", "soupçonneuse, chère señorita") +".\n"+
                          "Oh, officiers, vous tombez à pic ! Emparez-vous de "+ GetSexPhrase("cet homme", "cette femme") +" !";
			link.l1 = "Ah, diable !..";
			link.l1.go = "Step_H6_9";
        break;
 	 	case "Step_H6_9":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
            chrDisableReloadToLocation = true; // закрыть выход из локации.
            AddQuestRecord("Hol_Line_6_RevengeMansfield", "3");
            QuestSetCurrentNode("Henry Morgan", "HolLine6_fromSantiago");
            //==> потом вернуть
            LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
            //<== потом вернуть
            LAi_group_MoveCharacter(npchar, "SPAIN_CITIZENS");
            LAi_group_MoveCharacter(characterFromID("Santiago_waitress"), "SPAIN_CITIZENS");
            LAi_group_Delete("QuestGroup");
            SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY); //если флаг сменён.
            ref sld;
            for (int i=1; i<=2; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("Solder"+i, "off_spa_"+i, "man", "man", 30, SPAIN, 0, true));
                FantomMakeCoolFighter(sld, 30, 100, 80, "blade33", "pistol3", 120);

            	LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, "EnemyFight");
               	ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
            }
            LAi_group_SetLookRadius("EnemyFight", 100);
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "CannotFightCurLocation");
            DialogExit();
        break;
//**************************** Фр. линейка, квест №7. Узнать инфу о Роке Бразильце ************************
 	 	case "Step_F7_1":
			dialog.text = NPCStringReactionRepeat("C'est exact, il est chez les saints pères maintenant.", "Vous m'avez déjà interrogé sur le Brésilien.",
				          "Encore le Brésilien ?", "Eh bien, combien de temps allons-nous parler de ces pirates ? Parlons d'autre chose...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Hé, et quand vont-ils le pendre, maintenant ?", ""+ GetSexPhrase("Je vous l'ai demandé", "Je vous l'ai demandé") +" ? Eh bien, oui, sans doute...", "Oui, exactement, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +", désolé...", "On peut parler d'autre chose...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_F7_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_F7_2":
			dialog.text = "C'est à Antonio de Souza lui-même d'en décider maintenant ! C'est lui qui dirige les affaires de la Sainte Inquisition ici.";
			link.l1 = "Mais oם est l'Inquisition elle-même ?";
			link.l1.go = "Step_F7_3";
        break;
 	 	case "Step_F7_3":
			dialog.text = "Mais oם voulez-vous qu'elle soit ? Ici, en ville, "+ GetSexPhrase("señor", "señorita") +".\n"+
				          "En somme, "+ GetSexPhrase("señor", "señorita") +", nous ferions mieux de cesser ces conversations. Ce n'est pas bien d'évoquer les saints pères à tort et à travers...";
			link.l1 = "D'accord, porte-toi bien, aubergiste.";
			link.l1.go = "exit";
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

