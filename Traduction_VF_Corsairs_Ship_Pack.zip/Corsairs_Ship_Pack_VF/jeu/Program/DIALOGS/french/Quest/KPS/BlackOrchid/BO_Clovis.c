// Gregg: Clovis Dubois - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.
// Клови нанят Кендартом за 300 000 как соглядатай: две недели он смотрел за дочерью
// губернатора. Драки в городе не входили в его план и ему самому не нравятся.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: strictly by state. Without the gate any second approach replayed the meeting
			// on the beach and fired the march into town all over again.
			if (PChar.FindAndDestroy == "11")
			{
				dialog.text = "Clovis Dubois. Kendart a payé, j'ai fait le travail.";
				link.l1 = "Deux semaines pour trois cent mille. Qu'est-ce que ça a donné ?";
				link.l1.go = "1a";
			}
			else
			{
			// Gregg: a hint while the rags are being fetched. It is easy to carry one set out of
			// the chest instead of two, and then the quest condition simply stays silent.
			if (CheckAttribute(PChar, "FindAndDestroy.NeedSuits"))
			{
				dialog.text = "Prenez les deux tenues, capitaine. L'une est pour moi, et je n'entrerai pas dans cette salle en habit d'officier.";
				link.l1 = "Les deux, alors.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Je suis là. Dites un mot, et nous y allons.";
				link.l1 = "Nous attendons pour l'instant.";
				link.l1.go = "exit";
			}
			}
			NextDiag.TempNode = "First time";
		break;

		case "1a":
			dialog.text = "Deux semaines dans une maison louée près de la place, avec une longue-vue. J'ai vu la jeune fille vingt-trois fois, et les vingt-trois fois à la même fenêtre. Elle ne quitte pas l'hכtel de ville.";
			link.l1 = "La clé est sur elle ?";
			link.l1.go = "1b";
		break;

		case "1b":
			dialog.text = "א son cou, au bout d'un cordon. Elle ne l'enlève jamais, et à la voir, elle n'a aucune idée de ce que c'est. Son père, je ne l'ai pas vu une seule fois en deux semaines, et un gouverneur de Tortuga, capitaine, c'est un homme public.";
			link.l1 = "Oם est-il passé ?";
			link.l1.go = "1c";
		break;

		case "1c":
			dialog.text = "Nulle part. Il est dans la salle, il sort sur le balcon, il fait des signes de la main. Seulement, ce n'est pas lui. ...(un silence)... Je connais cet homme depuis douze ans, et je le regarde sans le reconnaître. Sa démarche n'est pas la bonne.";
			link.l1 = "Et vous êtes resté assis là-dessus pendant deux semaines ?";
			link.l1.go = "1d";
		break;

		case "1d":
			dialog.text = "J'écrivais à Kendart deux fois par semaine. Il m'a dit de vous attendre et de ne pas aller seul en ville. ...(il ramasse son sac)... Venez, je vous ferai le reste de mon rapport en chemin.";
			link.l1 = "Faites votre rapport en marchant.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToTortugaExitTown");
		break;

		case "9":
			dialog.text = "...(il s'arrête, chuchotant)... Halte. Douze à la porte.";
			link.l1 = "Et combien hier ?";
			link.l1.go = "9a";
		break;

		case "9a":
			dialog.text = "Quatre. Je les ai comptés tous les jours pendant quinze jours, et ils étaient quatre. ...(lentement)... Et ils regardent déjà par ici, capitaine. Une garnison ne regarde pas comme ça.";
			link.l1 = "Alors, il n'y aura pas de discussion.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyInTortugaExitTownBattle");
		break;

		case "12":
			dialog.text = "Douze. Et pas un n'a crié, appelé à l'aide ni ordonné de déposer les armes. Ils se sont battus en silence.";
			link.l1 = "Et vous n'aviez jamais remarqué ça en quinze jours ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "J'ai remarqué autre chose. Les gens de cette ville ont cessé de se saluer. J'ai mis ça sur le compte de la peur. ...(il essuie sa lame)... Je me suis trompé. Bon, entrons en ville ; restez près de moi et ne parlez à personne.";
			link.l1 = "Passez devant.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyInTortugaTown");
		break;

		case "16":
			dialog.text = "Sept. Capitaine, je connais de vue un homme sur deux ici. Pas un seul ne m'était familier.";
			link.l1 = "Et maintenant, oם ?";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "La maison du coin. Je l'ai louée pour la quinzaine et j'ai observé depuis là-bas. Ce qu'il nous faut pour entrer à l'hכtel de ville s'y trouve aussi.";
			link.l1 = "Continuez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToTortugaShelter");
		break;

		case "18":
			dialog.text = "Le coffre dans le coin. Ouvrez-le, il y a deux tenues.";
			link.l1 = "Deux tenues de quoi ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Des haillons. א l'hכtel de ville, on laisse entrer les officiers et les mendiants. Nous ne passerons pas pour les premiers, et là-bas, on ne compte pas les mendiants parmi les gens, alors personne ne les regarde de près.";
			link.l1 = "...(se dirige vers le coffre)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyFindClothes");
		break;

		case "20":
			dialog.text = "Vous les avez ? Changez-vous, et cachez votre lame. Laissez le mousquet : il n'y a pas de mendiants avec des mousquets.";
			link.l1 = "Je me change.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyDialogInShelter");
		break;

		case "21":
			dialog.text = "Parti. ...(il expire)... Capitaine, il vous a regardé plus longtemps que moi, et pas au visage, mais aux mains. דa ne me plaît pas.";
			link.l1 = "א l'hכtel de ville.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToTownhall");
		break;

		case "28":
			dialog.text = "C'est fait. ...(il regarde le corps)... Et voici une chose, capitaine. La jeune fille porte une clé au cou, je l'ai observée à la longue-vue pendant quinze jours. Celui-ci avait la même au sien.";
			link.l1 = "Nous demanderons à celui d'en haut. Allez à la porte et attendez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyTalkWithMayor");
		break;

		case "29":
			dialog.text = "La jeune fille n'y est pour rien, capitaine. Je l'ai observée pendant quinze jours : c'est elle qu'on garde ici, ce n'est pas elle qui garde.";
			link.l1 = "Je sais. Nous la faisons sortir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyRoomOfficers");
		break;

		case "30":
			dialog.text = "Oui. Seulement, pas par la porte : là-bas, ils sont au courant. Il y a un passage qui mène de la cave de l'hכtel de ville aux grottes. Je l'ai trouvé le quatrième jour, et pour être honnête, je ne pensais pas en avoir besoin.";
			link.l1 = "Faites-nous passer par la cave.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToDungeon");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
