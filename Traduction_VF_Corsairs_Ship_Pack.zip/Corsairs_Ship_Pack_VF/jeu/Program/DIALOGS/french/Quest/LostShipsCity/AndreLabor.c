#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bienvenue dans la Cité des navires abandonnés, capitaine. Je suis " + GetFullName(npchar) + ". Alors, comment trouvez-vous notre temps ? C'est amusant, n'est-ce pas ?!";
					link.l1 = "Amusant n'est pas le mot !.. " + GetFullName(pchar) + ", à votre service, monsieur " + npchar.lastname + ". דa vous arrive souvent ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bienvenue dans la Cité des navires abandonnés, capitaine. Je suis " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service, monsieur " + npchar.lastname + ". D'oם venez-vous ?";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				link.l4 = "Rien...";
				link.l4.go = "exit";
				if (pchar.questTemp.LSC == "toAndreLabor")
				{
					link.l5 = "L'ami, comment vas-tu, comment ça va ?";
					link.l5.go = "Tizer_1";
				}

			}
		break;
		case "FS_1":
			dialog.text = "דa arrive, "+ GetSexPhrase("monsieur", "mademoiselle") +"... Au début, je mourais tout simplement de peur ces jours-là, mais maintenant, j'y suis habitué.";
			link.l1 = "Compris... Dites-moi, d'oם venez-vous ?";
			link.l1.go = "FT_1";
		break;
		case "FT_1":
			dialog.text = "Autrefois, j'étais apprenti chez le propriétaire du chantier naval de Tortuga, et ensuite, j'ai servi comme charpentier à bord de la frégate Andromeda. Malheureusement, nous étions au mauvais endroit au mauvais moment.";
			link.l1 = "Que s'est-il passé ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Beaucoup de choses, "+ GetSexPhrase("monsieur", "mademoiselle") +", beaucoup. Et tout à la fois, imaginez ! D'abord, les esclaves se sont révoltés, et en pleine répression, nous avons été attaqués par des chasseurs de primes, parce que nous avions à bord... l'homme dont ils avaient besoin\n"+
				"Un abordage acharné, puis une tempête a éclaté, ou plutכt, c'était comme si nous avions été entraînés dans une sorte de zone de tempête. Ensuite, notre frégate a heurté des rochers ou des récifs, elle a pris l'eau et elle a coulé. J'ai attrapé un tonneau vide et j'ai réussi à m'y accrocher. דa m'a sauvé la vie. J'ai dérivé sur l'océan pendant une journée, puis j'ai été rejeté ici.";
			link.l1 = "Fameux...";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Vous voulez vraiment partir d'ici, n'est-ce pas ?";
			link.l1 = "Vous pensez que c'est possible ?";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Je ne sais pas, je n'en ai jamais entendu parler. Si on m'avait donné la possibilité de fabriquer quelque chose, j'aurais certainement essayé. Mais la Loi l'interdit...";
			link.l1 = "On pourrait essayer ensemble ?";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Non, "+ GetSexPhrase("l'ami", "mademoiselle") +", je passe mon tour. Avec notre amiral, on se retrouve au fond bien plus vite qu'on ne lève l'ancre.";
			link.l1 = "Oui... Eh bien, ce fut un plaisir de faire votre connaissance, " + npchar + ". Bonne journée.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! C'est "+ GetSexPhrase("lui", "elle") +", "+ GetSexPhrase("il", "elle") +" a enfreint la Loi !");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveux...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je préfère le chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "mademoiselle") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l5"))
			{
				link.l5 = "וcoutez, à quoi ces navires se tiennent-ils pendant une tempête ?";
				link.l5.go = "ansewer_5";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Pourquoi personne ne s'unit-il contre ces interdictions de la Loi ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "וcoutez, vous savez d'oם vient cette Cité ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Est-il déjà arrivé qu'un navire ou une escadre arrive ici sans avoir fait naufrage auparavant ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Des officiers de haut rang n'arrivent-ils pas ici ?";
				link.l4.go = "ansewer_4";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_5":
			dialog.text = "Je n'en ai aucune idée. Et je ne vous conseille pas de chercher à le savoir : c'est très dangereux.";
			link.l1 = "Pourquoi est-ce dangereux ?";
			link.l1.go = "ansewer_5_1";
		break;
		case "ansewer_5_1":
			dialog.text = "Hé, pour le savoir, il faut plonger sous les navires. Et celui qui plonge ne remonte pas...";
			link.l1 = "Je comprends maintenant.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_1":
			dialog.text = "Hum, s'unir ? Eh bien, essayez donc : bon vent dans votre dos voמté. Je... nous adorons les exécutions, nous aimons regarder les gens de votre espèce, dont la silhouette se dissout lentement dans les profondeurs de la mer.";
			link.l1 = "Je ne suis pas pressé de voir le monde depuis le fond de l'eau.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Le diable seul le sait ! Je suis un simple charpentier, j'ai du mal à parler des questions de sciences naturelles.";
			link.l1 = "Eh bien, vous avez une opinion, au moins ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Comme ça, dans les grandes lignes. Je pense qu'il y a sous la Cité des récifs qui retiennent tous ces navires. D'abord, l'un s'y est accroché, puis l'autre, et puis tout a grandi.";
			link.l1 = "Ha ! Une théorie intéressante...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Je ne m'en souviens pas.";
			link.l1 = "Mais est-ce possible ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Seulement si un miracle se produit. Jugez vous-même, il y a des rochers et des récifs tout autour...";
			link.l1 = "Hum, ça, c'est sמr.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Ils arrivent là oם ils veulent aller.";
			link.l1 = "Et alors ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Pourquoi ? Capper est un pirate !";
			link.l1 = "Il les tue ?";
			link.l1.go = "ansewer_4_2";
		break;
		case "ansewer_4_2":
			dialog.text = "Pas forcément. S'ils comprennent à temps quelle est leur place et dans quelle direction sont partis tous leurs privilèges, ils restent en vie.";
			link.l1 = "Amusant.";
			link.l1.go = "int_quests";
		break;
		//квестовые диалоги
		case "Tizer_1":
			dialog.text = "Oui, tout va bien.";
			link.l1 = "וcoutez, vous ne pourriez pas construire une sorte d'embarcation ? Un radeau, ou une barque...";
			link.l1.go = "Tizer_2";
		break;
		case "Tizer_2":
			dialog.text = "Hé, vous connaissez la Loi ? C'est interdit !";
			link.l1 = "Allons ! Vous avez aidé Teaser Dan, aidez les autres qui sont dans le besoin.";
			link.l1.go = "Tizer_3";
		break;
		case "Tizer_3":
			dialog.text = "Teaser Dan ? Oh !.. Vous m'étonnez beaucoup, "+ GetSexPhrase("l'ami", "ma belle") +". Teaser Dan est mort.";
			link.l1 = "En ce moment précis, oui. Mais pas avant. Héhé...";
			link.l1.go = "Tizer_4";
		break;
		case "Tizer_4":
			dialog.text = "Mmm, il y a quelque chose qui m'échappe... Vous savez quoi, parlons de cette affaire ailleurs. Vous savez oם se trouve la corvette Protector ? Allez-y et attendez-moi dans la cabine. Je vous suivrai, pour qu'on ne nous voie pas ensemble.";
			link.l1 = "Bonne idée ! Je vais vous annoncer une nouvelle qui, je pense, vous fera très plaisir. Alors ne me faites pas attendre.";
			link.l1.go = "Tizer_5";
		break;
		case "Tizer_5":
			dialog.text = "Pour rien au monde, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +" !";
			link.l1 = "D'accord, je vous attendrai au Protector.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "8");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC = "toProtector";
			pchar.quest.LSC_enterToProtector.win_condition.l1 = "location";
			pchar.quest.LSC_enterToProtector.win_condition.l1.location = "ProtectorFisher";
			pchar.quest.LSC_enterToProtector.function = "LSC_enterToProtector";
		break;

	}
	NextDiag.PrevNode = NodeName;
}
