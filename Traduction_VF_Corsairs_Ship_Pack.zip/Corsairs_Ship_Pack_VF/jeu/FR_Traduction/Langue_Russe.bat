@echo off
rem Remet le jeu en russe (language.ini -> russian).
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path '%~dp0' '..\RESOURCE\INI\texts\language.ini'; $t=[IO.File]::ReadAllText($p); $t=[regex]::Replace($t,'(?m)^defaultLanguage\s*=[^\r\n]*','defaultLanguage = russian'); [IO.File]::WriteAllText($p,$t,(New-Object Text.UTF8Encoding($false)))"
if errorlevel 1 (echo Echec de la modification de language.ini & pause & exit /b 1)
echo Langue du jeu : russe.
pause
