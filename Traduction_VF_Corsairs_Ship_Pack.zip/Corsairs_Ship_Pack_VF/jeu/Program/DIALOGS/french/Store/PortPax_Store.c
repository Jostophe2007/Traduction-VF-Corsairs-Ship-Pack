// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Demandez, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            if (CheckAttribute(pchar, "questTemp.Azzy.GiveRum"))
            {
        		Link.l1 = "וcoutez, l'ami, un certain Azzi m'a envoyé vers vous.";
        	    Link.l1.go = "Step_Az6";
                if (pchar.questTemp.Azzy.GiveRum == "OK")
                {
            		Link.l1 = "Je veux récupérer le rhum qui me revient.";
            	    Link.l1.go = "Step_Az8";
                }
            }
            if (pchar.questTemp.Azzy == "HowToKnowAzzy")
            {
    			Link.l2 = "וcoutez, je dois trouver Azzie de toute urgence !";
    			Link.l2.go = "Step_Az10";
            }
		break;
		//============================== Квест Аззи ===============================
 		case "Step_Az6":
        	dialog.text = "Oh, c'est le sieur Azzie qui vous envoie ?! Je suis ravi d'avoir de ses nouvelles : un homme si agréable et si sérieux en affaires ! Et que vous a-t-il dit ?";
    		link.l1 = "Un homme ?! Hum, bon, d'accord... Il m'a dit que je pouvais vous prendre du rhum gratuitement, autant que je voulais.";
    		link.l1.go = "Step_Az7";
		break;

 		case "Step_Az7":
        	dialog.text = "Pas tout à fait. Vous pouvez prendre 300 unités de mon rhum une fois par jour. Et gratuitement, bien sמr.";
    		link.l1 = "D'accord, ça me va. On procède ?";
    		link.l1.go = "Step_Az8";
    		pchar.questTemp.Azzy.GiveRum = "OK";
		break;

 		case "Step_Az8":
        	dialog.text = NPCStringReactionRepeat("Je peux vous donner 300 quintaux de rhum.",
                       "Vous avez déjà "+ GetSexPhrase("pris", "pris") +" le rhum qui vous revenait aujourd'hui.",
                       "Je vous dis que votre rhum du jour, vous l'avez déjà "+ GetSexPhrase("pris", "pris") +". Revenez demain.",
                       "Demain, revenez demain...", "block", 1, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("D'accord, je prends tout !!!", "C'est vrai, "+ GetSexPhrase("je l'ai pris", "je l'ai pris") +"...", "Pardon...", "Bon, à demain, alors.", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_Az9", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;

 		case "Step_Az9":
        	dialog.text = "Veuillez charger tout ça dans vos cales. Le rhum vous a été remis.";
    		link.l1 = "Très bien. Merci, l'ami.";
    		link.l1.go = "exit";
            AddCharacterGoods(Pchar, GOOD_RUM, 300);
		break;

 		case "Step_Az10":
        	dialog.text = NPCStringReactionRepeat("Je ne sais pas oם est Azzi. Je n'en ai pas la moindre idée.",
                                    "Je vous l'ai déjà dit, je ne sais pas oם il est.",
                                    "Je le répète, je ne sais pas oם est Azzie.",
                                    "Je vous le redis, je ne sais pas oם est Azzie. Et je ne veux pas le savoir.", "block", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Mais c'est bien de lui que vous recevez le rhum que je vous prends.", "Oui, je me souviens que vous l'avez dit", "Inutile de répéter, je m'en souviens.", "Désolée, vraiment désolée...", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_Az11", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;

 		case "Step_Az11":
        	dialog.text = "Je ne sais pas du tout comment votre rhum arrive chez moi. Je laisse simplement la grange de l'arrière-cour ouverte la nuit, et le matin, le rhum est déjà là. J'en garde un tiers pour moi, les deux tiers sont pour vous. Voilà toute l'affaire.";
    		link.l1 = "Diable... Il faut donc tendre une embuscade à ceux qui vous livrent le rhum la nuit !";
    		link.l1.go = "Step_Az12";
		break;

 		case "Step_Az12":
        	dialog.text = "Moi, je ne ferais pas ça. Mon commis a déjà été curieux : il s'est caché dans la grange pendant la journée, il voulait jeter un œil. Le matin, on l'a retrouvé à cכté du rhum, l'esprit dérangé ; maintenant, il reste assis toute la journée à baver et à marmonner\n"+
                          "Je ne sais pas qui est cet Azzi, mais le rhum gratuit ne me réjouit plus depuis longtemps. J'ai peur pour moi, voyez-vous\n"+
                          "Et vous ne verrez rien du tout. J'ai déjà fermé la grange à clé, je me disais que je me passerais de rhum. Et le matin, le rhum était quand même à sa place. Voilà, "+ GetSexPhrase("l'ami", "ma petite") +".";
    		link.l1 = "Oui, il est clair que je ne trouverai pas Azzi ici.";
    		link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);
}

