// boal 25/04/04 общий диалог мэры
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06

void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref aData;
	aref Link, NextDiag, arName;
	int enemyNation;
	string city2;

	DeleteAttribute(&Dialog,"Links");

	ref FortChref; // фортовый командер
	ref arItem;

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Mayor\" + NPChar.City + "_Mayor.c";
    if (!HasCityDialogFile("Mayor", NPChar.City, "_Mayor.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Mayor\DefaultCity_Mayor.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Mayor\DefaultCity_Mayor.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
    ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

    FortChref = GetFortCommander(NPChar.City); // будет или фортовик или сам губернатор

    ref offref;
    int i, cn, iRank, iDay;
    int qty;
    string attrLoc, QuestName, sTemp;
	bool   bOk;
	bool bOk2;

    if (CheckNPCQuestDate(npchar, "Card_date"))
	{
		SetNPCQuestDate(npchar, "Card_date");
		npchar.money = 5000 + (rand(10)+1) * makeint(100 * sti(PChar.rank) * (10.0 / MOD_SKILL_ENEMY_RATE*3));
	}
	// генератор ИДХ по кейсу -->
	attrLoc   = Dialog.CurrentNode;
  	if (findsubstr(attrLoc, "GetPrisonerIdx_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
	 	pchar.GenQuest.GetPrisonerIdx = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 	    Dialog.CurrentNode = "sell_prisoner_2";
 	}
 	// генератор ИДХ по кейсу <--
	// подставляем квестовую ноду при захвате города, если она есть
	/*if (LAi_IsCapturedLocation && CheckAttribute(NextDiag, "captureNode"))
	{
		Dialog.CurrentNode = NextDiag.captureNode;
		DeleteAttribute(NextDiag, "captureNode");
	}*/

	switch (Dialog.CurrentNode)
	{
		string sNationname = GetNationNameByType(sti(npchar.nation));
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOff");
		break;

		case "fight":
            Pchar.quest.ArestInResidenceEnd.win_condition.l1          = "ExitFromLocation";
		    Pchar.quest.ArestInResidenceEnd.win_condition.l1.location = Pchar.location;
		    Pchar.quest.ArestInResidenceEnd.win_condition             = "ArestInResidenceEnd";
		    Pchar.quest.ArestInResidenceEnd.ResidenceLocation = Pchar.location;
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;

			LAi_LockFightMode(Pchar, true); // ножками путь убегает
		    LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
		    LAi_group_Attack(NPChar, Pchar); // не работает на бессмертного мера :(
			i = GetCharIDXByParam("CityType", "location", Pchar.location); // фантом солдат
			if (i != -1)
			{
			    LAi_group_Attack(&Characters[i], Pchar);
			}
		break;

		case "First time":
            NextDiag.TempNode = "First time";
            // LEO: Fernando Torres (Des Moines mayor) recognizes the savior after the Enchanted City quest
            if (NPChar.id == "Fernando Torres")
            {
            	if (CheckAttribute(pchar, "questTemp.MC.DesMoines"))
            	{
            		dialog.text = "Vous... c'est vous ! Notre sauveur ! Sans vous, il n'y aurait plus ni cette ville ni moi-même. En quoi puis-je vous servir ?";
            		link.l1 = "Avez-vous du travail pour moi ?";
            		link.l1.go = "quests";
            		link.l2 = "Rien de particulier.";
            		link.l2.go = "exit";
            		break;
            	}
            }
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("Vous osez venir chez le gouverneur ?! Quelle audace...", "Comment ces fainéants ont-ils pu laisser l'ennemi entrer chez moi ?! C'est à n'y pas croire...", "Eh bien, ma sécurité ne vaut pas grand-chose, si "+ GetSexPhrase("un quelconque vagabond","une quelconque vagabonde") +" court partout dans ma résidence..."),
					LinkRandPhrase("Que voulez-vous, "+ GetSexPhrase("gredin","gredine") +" ?! Mes soldats sont déjà sur vos traces, vous n'irez pas loin"+ GetSexPhrase(" – sale pirate","") +" !", " Sale assassin, hors de ma résidence ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt au fort, vous n'irez pas loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Vos soldats ne valent pas grand-chose...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Je vais te dire une chose, mon vieux : reste tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			if (sti(NPChar.nation) == PIRATE)
            {
				if (CheckAttribute(pchar, "questTemp.mushket2x2") && !CheckCharacterItem(pchar, "mushket2x2"))
				{
					dialog.text = "Que voulez-vous ?";
					link.l1 = "J'ai besoin de vous parler de quelque chose.";
					link.l1.go = "quests";
					break;
				}
				if (CheckAttribute(pchar, "GenQuest.CaptainComission") && CheckAttribute(pchar, "GenQuest.CaptainComission.PiratesCity") && NPChar.city == pchar.GenQuest.CaptainComission.PiratesCity)
				{
					dialog.text = "Que voulez-vous ?";
					link.l1 = "J'ai besoin de vous parler de quelque chose.";
					link.l1.go = "quests";
					break;
				}
				bOk = CheckAttribute(pchar, "questTemp.silverfleet") && pchar.questTemp.silverfleet != "over" && pchar.questTemp.silverfleet != "ToHuber" && NPChar.id == "LeFransua_Mayor";
				bOk2 = !CheckAttribute(NPChar, "SilverFleetSeaCheck") || GetNpcQuestPastDayParam(NPChar, "SilverFleetSeaCheck") > 0;
		    		if (bOk && bOk2)
				{
					dialog.text = "Qu'est-ce que vous voulez ?";
					link.l1 = "J'ai besoin de vous parler d'une affaire.";
					link.l1.go = "quests";
					break;
				}
				else
				{
					dialog.text = "Nous n'avons rien à nous dire, je suis occupé.";
					link.l1 = "Eh bien, très bien.";
					link.l1.go = "Exit";

					if(!CheckAttribute(PChar, "questTemp.pirateStartQuest"))
					{
						link.l2 = "Pourriez-vous me trouver du travail ?";
						link.l2.go = "pirateStartQuest";
					}
					else
					{
						if(pchar.questTemp.pirateStartQuest == "3" && !CheckAttribute(PChar, "questTemp.pirateStartQuest.many") && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Je suis sur la piste, mais il me faut de l'argent : 30 000 piastres pour faire sortir le rat de son trou.";
							link.l2.go = "pirateStartQuest_many";
						}
						if(pchar.questTemp.pirateStartQuest == "3" && GetCharacterItem(pchar, "letter_open") > 0 && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Regardez quelle lettre j'ai trouvée sur le cadavre d'un des contrebandiers.";
							link.l2.go = "pirateStartQuest_info_1";
						}
						if(pchar.questTemp.pirateStartQuest == "5" && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Le travail est fait. Norman Vigo et sa baille sont partis chez le diable des mers.";
							link.l2.go = "pirateStartQuest_final";
						}
					}

					if(!CheckAttribute(PChar, "questTemp.pirateVikingQuest"))	//Квест Осколок Прошлого
					{
						if(sti(pchar.rank) >= 10)
						{
							link.l3 = "Avez-vous une affaire intéressante pour moi ?";
							link.l3.go = "pirateVikingQuest";
						}
					}
					else
					{
						if(pchar.questTemp.pirateVikingQuest == "7" && npchar.city == pchar.questTemp.pirateVikingQuest.City)
						{
							dialog.text = "Je vois que vous avez des nouvelles ?"
							link.l1 = "Oui, j'ai tué cet « homme du Nord » ; ah, qu'il était féroce. D'habitude, tous ont l'air de flairer la mort dès le début de la conversation, mais celui-là grognait et écumait de rage.";
							link.l1.go = "pirateVikingQuest_final";
						}
					}

					break;
				}
            }
			if (sti(NPChar.nation) != PIRATE && ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0) > 15)
            {
                dialog.text = "Oh ! " + GetFullName(pchar) + " ! Nous venons justement d'envoyer des chasseurs de primes vous chercher. Et vous savez, cela nous a déjà coמté une jolie somme.";
                if (sti(pchar.Money) >= ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0) * 6000)
                {
                    link.l1 = "Je veux juste régler nos différends.";
				    link.l1.go = "arestFree_1";
                }
				link.l2 = "Euh... Je crois que je vais y aller.";
				link.l2.go = "arest_1";
                /*if (CheckAttribute(NPChar, "NotHaveFort") && GetCharacterShipClass(PChar) <= 3) // to_do
                {
                    link.l3 = "Disagreements? Are you kidding? This is my city! Well, or almost mine. It will be mine soon...";
				    link.l3.go = "Town_Capture_1";
                } */
				break;
            }
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
    			dialog.text = "L'ennemi est dans la résidence ! Alerte !!";
				link.l1 = "Ah, diable !";
				link.l1.go = "fight";
				break;
			}


            // губернаторский (казённый) фрахт: вычисляем ОДИН раз до проверки знакомства (показываем и при первом контакте, и в обычном меню)
            bool bGovFreight = false;
            if (CheckAttribute(pchar, "CargoQuest.iOrderType") && sti(pchar.CargoQuest.iOrderType) == 6 && CheckAttribute(pchar, "CargoQuest.TraderID") && pchar.CargoQuest.iTradeColony == npchar.city)
            {
                if (CheckQuestAttribute("generate_trade_quest_progress", "begin") || CheckQuestAttribute("generate_trade_quest_progress", "failed")) bGovFreight = true;
            }

            if (npchar.quest.meeting == "0")
			{
				dialog.text = "J'ai entendu dire que vous aviez beaucoup insisté pour obtenir une audience. Je m'appelle " + GetFullName(npchar) +
                              ". Je suis le gouverneur de la ville de "+ GetCityName(NPChar.city) + ", sous le patronage de " + NationKingsName(npchar)+
                              ". Maintenant, veuillez m'indiquer le but de votre visite, " + GetAddress_Form(NPChar) + ".";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
				link.l1.go = "node_1";
				if (bGovFreight)
				{
					link.l6 = "J'ai une cargaison d'וtat pour vous, livrée comme convenu.";
					link.l6.go = "GovFreight_Deliver";
				}
				npchar.quest.meeting = "1";
			}
			else
			{
               	//ОСАДЫ homo
            if (CheckAttribute(Colonies[FindColony(npchar.City)],"Siege"))
                {

                    makearef(aData, NullCharacter.Siege);

                    if (CheckAttribute(aData, "HelpColony") && sti(aData.HelpColony) == true )
                    {
                        dialog.text = "Nous avons déjà tout réglé, n'est-ce pas ?";
                        link.l1 = "C'est exact, je ne vous retiens pas plus longtemps.";
                        link.l1.go = "exit";

                    }
                    else
                    {
                        dialog.text = "Je dois vous décevoir, mais je n'ai pas le temps de vous recevoir pour le moment. Comme vous le savez sans doute, notre colonie a été attaquée par "+NationNamePeople(sti(aData.nation))+". Et je dois organiser la défense de la ville.";
                        link.l1 = "C'est justement ce que je voulais : vous proposer mon aide pour défendre le fort.";
                        link.l1.go = "siege_task";
                        link.l2 = "Alors je ne vous retiens pas plus longtemps.";
            			link.l2.go = "exit";
                    }
                }
                else
                {//->
                    makearef(aData, NullCharacter.Siege);
                    if (CheckAttribute(aData, "PlayerHelpMayor") && sti(aData.PlayerHelpMayor) == true
                    && CheckAttribute(aData, "HelpColony") && sti(aData.HelpColony) == true )
                    {
                        // LEO: pay only for assault ships actually sank/captured (reward accrued in ShipDead/QuestShipCaptured), no freebie for watching
                        DeleteAttribute(aData, "PlayerHelpMayor");
                        DeleteAttribute(aData, "HelpColony");
                        if (sti(aData.PlayerSiegeKills) > 0)
                        {
                            AddMoneyToCharacter(Pchar, sti(aData.PlayerSiegeReward));
                            ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
                            ChangeCharacterReputation(PChar, 10);
                            AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 80);
                            AddCharacterExpToSkill(GetMainCharacter(), "Sailing", 100);
                            AddCharacterExpToSkill(GetMainCharacter(), "Accuracy", 100);
                            AddCharacterExpToSkill(GetMainCharacter(), "Cannons", 100);
                            SiegeRumour("Le bruit court que vous nous avez aidés à repousser l'escadre "+NationNameSK(sti(aData.nation))+" et à défendre notre colonie ! Nous vous en sommes si reconnaissants, "+ GetAddress_Form(NPChar)+".", aData.Colony, sti(aData.conation), -1, 15, 3);
                            dialog.text = "Ah, c'est vous, "+GetAddress_Form(NPChar)+" "+GetFullName(pchar)+", ravi de vous voir. Bonne nouvelle pour notre colonie : nous avons repoussé la flotte d'invasion "+NationNameSK(sti(aData.nation))+" - et c'est en grande partie grâce à vous : vous avez coulé ou capturé "+sti(aData.PlayerSiegeKills)+" navires ennemis. Le trésor vous verse "+sti(aData.PlayerSiegeReward)+" pièces d'or, comme promis. Veuillez les recevoir.";
                            link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + ". Un plaisir de faire affaire avec vous !";
                            link.l1.go = "exit";
                        }
                        else
                        {
                            // LEO: 0 sank/captured by player - a word of thanks, no gold
                            ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
                            dialog.text = "Ah, c'est vous, "+GetAddress_Form(NPChar)+" "+GetFullName(pchar)+". Eh bien, nous avons repoussé la flotte d'invasion "+NationNameSK(sti(aData.nation))+" - même si, pour être honnête, je n'ai pas vu votre main dans la bataille navale : vous n'avez coulé ni abordé aucun navire ennemi. Le trésor n'a rien à vous offrir en récompense, sans vouloir vous offenser. Mais merci de ne pas être resté à l'écart.";
                            link.l1 = "Je comprends, " + GetAddress_FormToNPC(NPChar) + ". La prochaine fois, je ferai mes preuves au combat.";
                            link.l1.go = "exit";
                        }
                    }
                    else
                    {
   						//--> дача квеста найти кольцо в борделе
						if (rand(1) && pchar.questTemp.different == "free" && GetNpcQuestPastDayWOInit(npchar, "questTakeRing") > 50 && sti(pchar.questTemp.HorseQty) > 5)
						{
							if (npchar.city == "Bridgetown" || npchar.city == "Charles" || npchar.city == "FortFrance" || npchar.city == "Marigo" || npchar.city == "Panama" || npchar.city == "PortRoyal" || npchar.city == "SantoDomingo" || npchar.city == "Tortuga" || npchar.city == "Nassau")
							{
        						dialog.text = "וcoutez, j'ai une affaire pour vous, hum... une commande inhabituelle.";
								link.l1 = "Je vous écoute attentivement.";
        						link.l1.go = "TakeRing_1";
								SaveCurrentNpcQuestDateParam(npchar, "questTakeRing");
								break;
							}
						}
						//<-- дача квеста найти кольцо в борделе
						dialog.text = RandPhraseSimple("Oh, c'est encore vous ? Quelle est l'affaire cette fois ?",
                                      "Vous me dérangez encore dans l'administration de la ville ? Que voulez-vous, " +GetAddress_Form(NPChar)+" ?");
        				link.l1 = "Je voudrais parler d'un travail au service de " + NationNameGenitive(sti(NPChar.nation))+".";
        				link.l1.go = "work";

        				link.l2 = "J'ai besoin de vous parler de quelque chose.";
						if(CheckAttribute(pchar,"questTemp.ReasonToFast") && !CheckAttribute(pchar,"questTemp.ReasonToFast.SpeakOther") && !CheckAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther") && (pchar.questTemp.ReasonToFast.city == NPChar.city))
						{
							link.l2.go = "ReasonToFast_Mayor1";
						}
						else
						{
							link.l2.go = "quests";   //(перессылка в файл города)
						}
						if(CheckAttribute(pchar,"GenQuest.CaptainComission") && (pchar.GenQuest.CaptainComission.variant == "A2") && (pchar.GenQuest.CaptainComission.City == NPChar.city))
						{
							if(pchar.GenQuest.CaptainComission == "Begin_1" && !CheckAttribute(pchar,"GenQuest.CaptainComission.SpeakMayor"))
							{
								link.l12 = "Vous avez à votre service un capitaine de patrouille sur " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " nommé " + pchar.GenQuest.CaptainComission.Name + " ; comment puis-je le voir ?";
								link.l12.go = "CapComission_Mayor1";
							}
							if(CheckAttribute(pchar,"GenQuest.CaptainComission.PrisonFree"))
							{
								link.l12 = "L'ancien capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " a accepté de vous montrer son trésor.";
								link.l12.go = "CapComission_Mayor9";
							}
							if(pchar.GenQuest.CaptainComission == "GetGoodsSuccess")
							{
								link.l12 = "L'ancien capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " m'a montré son trésor.";
								link.l12.go = "CapComission_Mayor13";
							}
						}
        				if (GetPrisonerQty() > 0)
        				{
                            link.l3 = "Je dois remettre le capitaine prisonnier aux autorités.";
        				    link.l3.go = "sell_prisoner";
        				}
        				if (npchar.Default  == npchar.location) // если не в тюрьме
        				{
        					if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
        					{
        						link.l4 = "J'ai besoin de régler avec vous quelques questions financières.";
        						link.l4.go = "LoanForAll";//(перессылка в кредитный генератор)
        					}
        				}
						//-->> сдача найденного в борделе кольца
						if (CheckCharacterItem(pchar, "MayorsRing"))
						{
							if (pchar.questTemp.different.TakeMayorsRing == "toBrothel")
							{
        						link.l5 = "J'ai réussi à retrouver votre bague. La voici.";
        						link.l5.go = "TakeRing_S1";
							}
							else
							{
        						link.l5 = "J'ai votre alliance. Il s'avère que vous l'avez offerte à l'une des filles du bordel.";
        						link.l5.go = "TakeRing_S3";
							}
						}
						//<<-- сдача найденного в борделе кольца
						if (npchar.id == "Santiago_Mayor" && CheckAttribute(pchar, "PGGWhisperLetter"))
						{
							link.lPGGWhisper = "Vous avez entendu, gouverneur ? Un navire appartenant à une certaine Whisper a jeté l'ancre à Puerto Príncipe. Ce ne serait pas la sorcière qui s'est échappée des griffes de l'Inquisition ?";
        					link.lPGGWhisper.go = "PGGWhisper";
						}
						// Gregg: the Jamaica office quest - the Fort Orange commandant is sceptical of the Company's venture (one-time branch)
						if (npchar.city == "FortOrange" && CheckAttribute(pchar, "GWIK.Jamaica.Stage") && !CheckAttribute(pchar, "GWIK.Jamaica.MayorOk"))
						{
							link.lGWIKJam = "On dit que les projets de la Compagnie des Indes occidentales pour votre ville ne vous enchantent guère.";
							link.lGWIKJam.go = "GWIKJam_Mayor";
						}

        				link.l7 = "J'aimerais savoir oם se trouve le gouverneur général de " + NationNameGenitive(sti(NPChar.nation)) + " en ce moment.";
        				link.l7.go = "Where_guber";
								// губернаторский (казённый) фрахт: сдача груза - он уходит в магазин этого города (incl. overdue)
								if (bGovFreight)
								{
									link.l6 = "J'ai une cargaison d'וtat pour vous, livrée comme convenu.";
									link.l6.go = "GovFreight_Deliver";
								}
        				link.l8 = "Vous voulez peut-être vous détendre un peu de vos importantes affaires ? Je peux vous proposer une partie.";
        			    link.l8.go = "Play_Game";
        				link.l10 = "Pardonnez-moi, mais j'ai à faire.";
        				link.l10.go = "exit";
                    }
                }//<-
			}
		break;

		case "GWIKJam_Mayor": // Gregg: the Jamaica office quest - sceptical commandant, the town gets a voice
			dialog.text = "« Ne m'enchantent guère », c'est peu dire, capitaine. Les compagnies vont et viennent, mais c'est la ville qui paiera leur audace : Port Royal ne nous pardonnera pas ce comptoir. Il me faut des garanties, pas les promesses de marchands de passage.";
			link.l1 = "Le comptoir, ce sont des entrepכts, des droits de douane et du travail pour les habitants. Je me porte garant de l'entreprise sur mon propre nom.";
			link.l1.go = "GWIKJam_Mayor_Talk";
			if (sti(pchar.money) >= 5000)
			{
				link.l2 = "Des garanties ? Cinq mille piastres dans les caisses de la ville, est-ce une garantie suffisante ?";
				link.l2.go = "GWIKJam_Mayor_Gold";
			}
			link.l3 = "C'est l'affaire de la Compagnie et du gouverneur de Curaçao. Bonne journée.";
			link.l3.go = "exit";
		break;

		case "GWIKJam_Mayor_Talk":
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) >= 25 + sti(pchar.rank)) // Gregg: Leadership skill 0-100 >= 25 + player rank (was hardcoded 6 - gate almost always open); a gold path exists for weak authority
			{
				pchar.GWIK.Jamaica.MayorOk = true;
				GWIK_AddRep(10);
				AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 60); // Gregg: leadership xp for successfully persuading the commandant (Leadership >= 25+rank check)
				dialog.text = "Hum... Votre nom a du poids, c'est vrai : on parle de vous dans tous les ports. Très bien, capitaine : la ville ne se mettra pas en travers du chemin de la Compagnie. Mais dites à vos marchands qu'ils répondent de la paix de Fort Orange autant que moi. Et dites à l'émissaire que le commandant a donné sa parole, et que par ici, elle compte.";
				link.l1 = "Je transmettrai mot pour mot.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Des mots, capitaine, des mots. On ne peut ni les classer dans les registres ni les verser au trésor. Revenez quand vous aurez quelque chose de plus solide à proposer.";
				link.l1 = "Alors nous trouverons un autre argument.";
				link.l1.go = "exit";
			}
		break;

		case "GWIKJam_Mayor_Gold":
			if (sti(pchar.money) < 5000)
			{
				dialog.text = "Je ne vois pas cinq mille, capitaine.";
				link.l1 = "J'ai dמ mal compter.";
				link.l1.go = "exit";
				break;
			}
			AddMoneyToCharacter(pchar, -5000);
			pchar.GWIK.Jamaica.MayorOk = true;
			GWIK_AddRep(10);
			PlayStereoSound("notebook");
			dialog.text = "Voilà qui est parler à la hollandaise : court et sonnant. Le trésor de la ville accepte votre contribution. Fort Orange ne se mettra pas en travers du chemin de la Compagnie, et j'espère ne pas le regretter. Dites à l'émissaire que le commandant a donné sa parole, et que par ici, elle compte.";
			link.l1 = "Vous ne le regretterez pas, commandant.";
			link.l1.go = "exit";
		break;

		case "GovEscort_Tell": // escort: captain reports the journey, reaction by losses/redirect
			dialog.text = "Je vous écoute, capitaine. Comment s'est passée la traversée ?";
			int teAlive = GovEscort_ShipsAlive();
			int teTotal = sti(pchar.CargoQuest.GovEscortShips);
			bool tePartial = (teAlive < teTotal);
			bool teRedir = CheckAttribute(pchar, "CargoQuest.GovEscortAgentMult");
			if (teRedir)
			{
				if (tePartial) link.l1 = "Une embuscade nous attendait près de l'île : quelqu'un avait fini par apprendre l'existence de la cargaison. Nous les avons repoussés, mais tous les navires n'ont pas survécu.";
				else link.l1 = "Une embuscade nous attendait près de l'île, comme vous le craigniez. Un combat acharné, mais j'ai ramené tous les navires.";
			}
			else
			{
				if (tePartial) link.l1 = "Des pirates nous ont interceptés en chemin. Certains navires n'ont pas pu être sauvés : nous nous sommes battus de notre mieux.";
				else link.l1 = "La route a été agitée, mais tous les navires sont arrivés intacts.";
			}
			link.l1.go = "GovEscort_Pay";
		break;
		case "GovEscort_Pay": // escort: closing + payment (reached with or without the report)
			int peAlive = GovEscort_ShipsAlive();
			int peTotal = sti(pchar.CargoQuest.GovEscortShips);
			bool pePartial = (peAlive < peTotal);
			float peMult = 1.0;
			if (CheckAttribute(pchar, "CargoQuest.GovEscortAgentMult")) peMult = stf(pchar.CargoQuest.GovEscortAgentMult);
			if (pePartial) dialog.text = "Des pertes... eh bien, ce n'est pas vous qui avez attiré cette embuscade. L'important, c'est que vous n'ayez pas abandonné la cargaison et que vous en ayez sauvé ce que vous pouviez. La Couronne apprécie la loyauté. Voici votre paie.";
			else { if (peMult > 1.5) dialog.text = "Pas un seul navire perdu ! Vous avez dépassé mes attentes, capitaine : mon messager ne s'était pas trompé sur votre compte. Prenez votre paie, quintuplée, comme convenu."; else dialog.text = "Tous les navires sont intacts, parfait. Le trésor vous remercie de vos services. Voici votre paie."; }
			link.l1 = "Heureux d'avoir pu servir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			GovEscort_Deliver(NPChar, peMult);
		break;
		case "GovFreight_Deliver":
			// казённый груз принимают с корабля, пришвартованного в ЭТОМ порту (не пешком и не с чужого причала)
			if (!CargoShipMooredInCity(npchar.city))
			{
				dialog.text = "Une cargaison d'וtat, dites-vous ? Mais votre navire n'est pas dans notre port, capitaine. Amarrez-le ici, et la cargaison sera reçue avec tous les honneurs.";
				link.l1 = "Je vais amener le navire au port.";
				link.l1.go = "exit";
				break;
			}
			// --- ESCORT (subtype 2): deliver what arrived (partial), pay proportional to surviving cargo ---
				if (CheckAttribute(pchar, "CargoQuest.GovEscortActive"))
				{
					int geAboard = GovEscort_CargoAboard();
					if (geAboard <= 0)
					{
						dialog.text = "Oם est la cargaison, capitaine ? Pas un seul navire de l'escorte n'est arrivé. Sans les marchandises, il n'y a rien à discuter.";
						link.l1 = "Je n'ai pas encore tout perdu.";
						link.l1.go = "exit";
						break;
					}
					int geAlive = GovEscort_ShipsAlive();
					int geTotal = sti(pchar.CargoQuest.GovEscortShips);
					bool gePartial = (geAlive < geTotal); // some ships lost on the way
					bool geRedir = CheckAttribute(pchar, "CargoQuest.GovEscortAgentMult");
					if (geRedir)
					{
						if (gePartial) dialog.text = "Capitaine ! Mon messager vous a donc trouvé à temps. Mais je vois que tous les navires ne sont pas arrivés... les pirates attendaient bel et bien. Les eaux sont mal famées ces temps-ci. Et pourtant, vous avez sauvé ce que vous pouviez : la Couronne ne l'oubliera pas. Paie quintuplée, comme convenu : pour le risque et pour la loyauté.";
						else dialog.text = "Tous les navires sont intacts ? Le ciel soit loué : mon messager avait donc de bonnes raisons de vous chercher, et vous avez suivi le conseil. La cargaison est sauve, capitaine. La Couronne tient parole : paie quintuplée.";
					}
					else
					{
						if (gePartial) dialog.text = "Tous les navires ne sont pas arrivés, capitaine... Une embuscade ? C'est ce que je craignais. Dommage que vous n'ayez pas pu tout sauver, mais vous serez payé en toute conscience pour ce que vous avez ramené. Merci pour cela, au moins.";
						else dialog.text = "L'escorte est arrivée, la cargaison a été reçue intacte. Le trésor vous remercie pour le convoi, capitaine : voici votre paie.";
					}
					link.l1 = "Permettez-moi de vous faire le récit de la traversée, " + GetAddress_FormToNPC(NPChar) + ".";
					link.l1.go = "GovEscort_Tell";
					link.l2 = "La cargaison est à vous. Je prendrai ce qui m'est dמ.";
					link.l2.go = "GovEscort_Pay";
					break;
				}
				int gfGoods = GovSwap_HoldGood(); // what's actually in the hold: cheap filler if swapped, else the real cargo
			int gfQty   = makeint(pchar.CargoQuest.iQuantityGoods);
			if (GetSquadronGoods(pchar, gfGoods) < gfQty)
			{
				dialog.text = "Oם est la cargaison, capitaine ? Votre cale n'est pas complète. Apportez tout, et ensuite nous réglerons nos comptes.";
				link.l1 = "Je livrerai jusqu'au dernier ballot.";
				link.l1.go = "exit";
				break;
			}
			// --- CARGO SWAP: customs inspection before settlement ---
				if (CheckAttribute(pchar, "CargoQuest.GovSwapDone"))
				{
					if (!CheckAttribute(pchar, "CargoQuest.GovSwapInspected"))
					{
						// first attempt to deliver the swapped cargo - the mayor demands an inspection
						pchar.CargoQuest.GovSwapMayorId = NPChar.id; // remember the mayor - after the inspection the word returns to him (GovSwap_AfterInspector)
							pchar.CargoQuest.GovSwapMayorType = NPChar.chr_ai.type; // snapshot the mayor's type (sit/huber...) - restore the ORIGINAL after the verdict
						if (!CheckAttribute(pchar, "CargoQuest.GovSwapInspectorId")) GovSwap_SpawnInspector(sti(NPChar.nation));
						dialog.text = RandPhraseSimple(
							"Une commande de l'וtat ? Très bien. Mais le règlement, c'est le règlement : un inspecteur des douanes va d'abord examiner la cargaison. (Son Excellence fait un signe, et un inspecteur des douanes se dirige vers vous depuis la porte.)",
							"Les marchandises de ma commande ? Excellent. Une simple formalité d'abord : mon inspecteur va examiner le lot. (Le gouverneur hoche la tête, et un homme muni d'un registre se dirige vers vous depuis la porte.)"
						);
						link.l1 = "Bien sמr, Votre Excellence.";
						link.l1.go = "exit";
						break;
					}
					if (pchar.CargoQuest.GovSwapInspected == "caught")
					{
						// the inspector exposed the swap - the governor announces a fine (GovSwap_CaughtPenalty)
						AddDialogExitQuestFunction("GovSwap_MayorReseat");
						dialog.text = RandPhraseSimple(
							"...Une substitution ?! Vous avez refilé au trésor de la camelote bon marché au lieu des marchandises commandées, et sous mon propre sceau ! Une amende de " + FindRussianMoneyString(GovSwap_FineAmount()) + ", et n'essayez pas de marchander. Confisquez la cargaison. Disparaissez tant que je suis encore clément.",
							"...C'est donc une contrefaçon ?! Vous pensiez que le trésor était aveugle ? Une amende de " + FindRussianMoneyString(GovSwap_FineAmount()) + ", et la cargaison est confisquée. Estimez-vous heureux que ce ne soit pas le cachot, capitaine. Le trésor a la mémoire longue."
						);
						link.l1 = "(partir en silence)";
						link.l1.go = "exit";
						GovSwap_CaughtPenalty(NPChar);
						break;
					}
					// GovSwapInspected == "passed" - the inspector missed it, settlement proceeds as usual (below)
				}
				// successful delivery (normal OR a swap that passed): payout/exp/cargo/close + withholding a past fine - in GovSwap_DeliverReward
			AddDialogExitQuestFunction("GovSwap_MayorReseat");
			bool gfLate = CheckQuestAttribute("generate_trade_quest_progress", "failed");
			if (gfLate) dialog.text = "Vous êtes en retard, capitaine. La cargaison n'est plus aussi nécessaire : le trésor en paiera la moitié.";
			else dialog.text = "Excellent, capitaine. La cargaison est arrivée intacte. Le trésor n'oublie pas un service rendu : voici votre récompense.";
			link.l1 = "Heureux d'avoir pu servir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			GovSwap_DeliverReward(NPChar);
		break;

		case "PGGWhisper":
			pchar.PGGWhisperLetterSent = true;
			DeleteAttribute(pchar, "PGGWhisperLetter");

			sTemp = npchar.city;
			if (CheckAttribute(pchar, "GenQuest.MayorQuestsList." + sTemp) && sti(pchar.GenQuest.MayorQuestsList.(sTemp)) > 2)
			{
				dialog.text = "En avez-vous parlé à quelqu'un d'autre ?";
				link.l1 = "Non, vous êtes le premier.";
				link.l1.go = "PGGWhisper_1";
			}
			else
			{
				pchar.PGGWhisperLetterSentFail = true;
				AddQuestRecord("PGGWhisper", "6");
				dialog.text = "Vraiment ? Je n'en ai pas entendu parler, alors que d'habitude j'apprends toutes les nouvelles avant le tavernier du coin. Et qui êtes-vous au juste ? Mes hommes vont vérifier votre renseignement, et en attendant, mes gardes vont vous interroger.";
				link.l1 = "Bon sang, je n'y croyais pas !";
				link.l1.go = "fight";
			}
		break;

		case "PGGWhisper_1":
			addMoneyToCharacter(pchar, 10000);
			dialog.text = "Excellent. Voilà une excellente nouvelle ! Si je la ramène ici enchaînée, la Sainte Inquisition sera ravie ! Tenez, prenez ceci : pour une telle information, vous méritez une récompense. Dites-moi, voulez-vous encore servir la Couronne d'Espagne ? Pourriez-vous capturer cette Whisper et me l'amener ?";
			link.l1 = "Avec plaisir, mais j'ai bien peur de devoir prendre la mer. Les délais de fret pressent, vous savez. Peut-être pourriez-vous confier cette affaire à vos soldats ?";
			link.l1.go = "PGGWhisper_2";
		break;

		case "PGGWhisper_2":
			dialog.text = "Vous savez, vous avez raison ! Je fais trop souvent appel à des capitaines étrangers, il est temps de m'en occuper moi-même. Je vais confier l'interception du navire à ma flotte de patrouille ; et puisque son navire est dans la baie, Whisper elle-même se cache peut-être quelque part dans la jungle ! Je pense qu'il faut aussi mettre la garnison du fort sur sa piste. Vous êtes encore là, capitaine ? Vous pouvez disposer, merci pour l'information.";
			link.l1 = "Au revoir, et bonne chance dans vos recherches.";
			link.l1.go = "exit";
			pchar.quest.QuestWhisper_Siege.win_condition.l1          = "location";
			pchar.quest.QuestWhisper_Siege.win_condition.l1.location = "Santiago_town";
			pchar.quest.QuestWhisper_Siege.function             = "QuestWhisper_Siege";
		break;

		//Blackthorn. Квест викинга
		case "pirateVikingQuest":
			dialog.text = "J'ai un travail pour vous. Il paraît que vous ne vous êtes pas seulement servi de votre épée, mais aussi de votre tête. וcoutez. Il y a quelques années, un Scandinave est apparu dans nos eaux, un Danois ou un Suédois, peu importe ; il se fait appeler Ragnar. Son navire est un vrai spectacle, et l'équipage n'est composé que de Normands. Et tout semble bien aller : il pirate un peu, gagne son pain, mais il ne verse pas sa part au pot commun, il est grossier avec les gouverneurs, et il revend ses prises on ne sait oם. Vous comprenez de quoi il est question ?";
			link.l1 = "Je comprends, vous voulez le punir pour faire un exemple. Seulement, ce n'est pas vraiment conforme aux lois des Frères de la Cכte. Bon, ce pirate est allé trop loin ; alors qu'on souffle aux autorités oם il se terre. Et personne ne pourra rien nous reprocher, à nous, honnêtes corsaires.";
			link.l1.go = "pirateVikingQuest_1";
			link.l2 = "Cette conversation ne me plaît pas. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateVikingQuest = "0";
		break;
		case "pirateVikingQuest_1":
			dialog.text = "Les lois des Frères de la Cכte, le Code, l'honneur pirate... Pfff... Des enfantillages. Rappelez-vous aussi la Libertalia que Sharp a essayé de bâtir. Ha ha ! Ici, il y a un équilibre des forces : les autorités ferment les yeux sur nos affaires tant que nous ne nous mêlons pas des leurs. Et si la paix était signée en Europe ? Les lettres de marque seraient révoquées, et tous les braves corsaires deviendraient des criminels en un instant. Et les escadres punitives arriveraient. Pour nous attraper, vous et moi. Et les capitaines comme ce Viking ternissent notre réputation à tous. Vous saisissez ?";
			link.l1 = "Je comprends, vous m'avez donné matière à réflexion. Oם puis-je trouver ce Viking ?";
			link.l1.go = "pirateVikingQuest_2";
		break;
		case "pirateVikingQuest_2":
			dialog.text = "Quelque part. Si je savais oם il se terre, j'irais moi-même en mer, malgré mes vieilles blessures et mon âge. Vous êtes quelqu'un de futé, vous trouverez bien. Une seule condition : ce Ragnar et tout son équipage doivent finir en nourriture pour les poissons, et je saurai me montrer généreux en or.";
			link.l1 = "Attendez les nouvelles. Et pour la révocation des lettres de marque, s'il y a du nouveau, prévenez-moi. א l'occasion, "+GetFullName(npchar)+".";
			link.l1.go = "exit";

			pchar.questTemp.pirateVikingQuest = "1";
			pchar.questTemp.pirateVikingQuest.City = npchar.city;
			pchar.questTemp.pirateVikingQuest.Areal = GetArealByCityName(pchar.questTemp.pirateVikingQuest.City);
			pchar.questTemp.pirateVikingQuest.Name = GetFullName(npchar);
			pchar.LastHearedViking = npchar.city;
			AddQuestRecord("pirateVikingQuest", "1");
			AddQuestUserData("pirateVikingQuest", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateVikingQuest.City + "Gen"));
			AddQuestUserData("pirateVikingQuest", "sName", pchar.questTemp.pirateVikingQuest.Name);
		break;
		case "pirateVikingQuest_final":
			CloseQuestHeader("pirateVikingQuest");
			pchar.questdata.OskolokProshlogo = 1;
			TakeNItems(pchar, "chest", 3);
			Log_Info("Vous avez reçu les coffres de crédit");
			dialog.text = "Oui, je l'ai lue autrefois. Un berserker en vue. Comme un fragment du passé. Tenez, prenez la récompense, vous la méritez.";
			pchar.questTemp.pirateVikingQuest = "end";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//zagolski. начальный квест за пирата ===================================
		case "pirateStartQuest":
			dialog.text = "Hum... un travail, dites-vous ? Et c'est même très bien que vous soyez venu me voir. J'ai justement besoin de quelqu'un d'extérieur. Je dois me renseigner sur quelque chose dans la colonie voisine, et là-bas, mes gars sont connus comme le loup blanc. Je ne vous promets pas beaucoup d'argent, mais vous y gagnerez quelque chose.";
			link.l1 = "Voilà qui est bien. De quoi s'agit-il ?";
			link.l1.go = "pirateStartQuest_1";
			link.l2 = "Désolé, je ne vais pas risquer un sou. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateStartQuest = "0";
		break;
		case "pirateStartQuest_1":
			dialog.text = "Voici l'affaire : il y a environ un mois, je me suis entendu avec le capitaine de la goélette Sentblue pour qu'il livre 200 esclaves, à revendre à un planteur de la colonie voisine. Les délais sont déjà serrés, le client s'impatiente, et hier on m'a informé qu'on avait vu cette goélette dans les eaux de l'île. Mais !.. Le capitaine ne s'est pas présenté. Et aujourd'hui, le planteur a exigé le remboursement de son acompte, en disant qu'on lui avait proposé les esclaves ailleurs : plus cher, certes, mais tout le lot d'un coup.";
			link.l1 = "Et alors ? Je dois vous trouver 200 esclaves en quelques jours, pour que vous ne perdiez pas l'acompte ? Et tout ça pour trois sous ?";
			link.l1.go = "pirateStartQuest_2";
		break;
		case "pirateStartQuest_2":
			dialog.text = "Non, bien sמr que non. J'ai l'air d'un idiot ? Je ne rembourserai l'acompte en aucun cas. Mais il me faut la preuve que les esclaves qu'on lui propose sont bien mon lot. Vous n'aurez qu'à trouver ceux qui lui ont proposé ce nouveau marché, et vous toucherez vos 10 000 piastres. Le reste, c'est mon affaire. Alors, vous êtes prêt ?";
			link.l1 = "J'accepte ! Et qui ça pourrait être ? Vous avez une idée ?";
			link.l1.go = "pirateStartQuest_3";
			link.l2 = "Non. On ne sait pas qui chercher, on ne sait pas oם, et pour seulement 10 000, désolé, je refuse.";
			link.l2.go = "exit";
		break;
		case "pirateStartQuest_3":
			dialog.text = "Si j'avais le moindre indice, je me serais passé de vos services. Ils serviraient déjà d'appât à calmars avant la nuit. Mais ce qui m'intéresse surtout, c'est autre chose : comment ont-ils appris l'existence de la cargaison du Sentblue et de mon client ? Tout s'est arrangé très vite pour eux. Vous saisissez ?";
			link.l1 = "Oui, c'est clair, quelqu'un vend des informations.";
			link.l1.go = "pirateStartQuest_4";

			pchar.questTemp.pirateStartQuest = "1";
			pchar.questTemp.pirateStartQuest.City = npchar.city;
			pchar.questTemp.pirateStartQuest.Areal = GetArealByCityName(pchar.questTemp.pirateStartQuest.City);
			pchar.questTemp.pirateStartQuest.Name = GetFullName(npchar);

			AddQuestRecord("pSQ", "1");
			AddQuestUserData("pSQ", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City + "Gen"));
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);
		break;
		case "pirateStartQuest_4":
			dialog.text = "Voilà ! C'est lui que je cherche. Donc, éliminer discrètement les concurrents et récupérer les esclaves, ce n'est pas le principal dans cette affaire. Il me faut l'informateur, ou plutכt, sa tête au bout d'une pique. Vous comprenez maintenant pourquoi aucun de mes hommes ne doit être au courant de cette mission ? Tant que je ne saurai pas qui vend les informations, je soupçonnerai tout le monde. Et je n'en ai vraiment pas envie...";
			link.l1 = "Compris... Donc, on agit discrètement et sans faire de vagues. Je pars à sa recherche.";
			link.l1.go = "exit";
		break;

		case "pirateStartQuest_many":
			dialog.text = "Trente mille, dites-vous ? C'est beaucoup d'argent... Je ne peux vous donner que 5 000 piastres, je n'en ai pas plus en ce moment. Mais si vous décidez de filer avec, je vous retrouverai et je vous pendrai à la première palissade venue ! Ce genre de plaisanterie ne marche pas avec moi.";
			link.l1 = "Donnez-moi les cinq mille...";
			link.l1.go = "pirateStartQuest_many_1";
		break;
		case "pirateStartQuest_many_1":
			dialog.text = "Tenez. J'attends les résultats de vos recherches.";
			link.l1 = "Tout ira bien.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 5000);
			pchar.questTemp.pirateStartQuest.many = "";
		break;

		//------------------------------------
		case "pirateStartQuest_info_1":
			dialog.text = "Ha ! Excellente nouvelle ! J'étais sמr que vous y arriveriez. J'ai obtenu des informations très intéressantes.";
			link.l1 = "J'ai fait mon travail. Je veux mes dix mille.";
			link.l1.go = "pirateStartQuest_info_2";
			TakeItemFromCharacter(pchar, "letter_open");
		break;
		case "pirateStartQuest_info_2":
			dialog.text = "Bien sמr, voici la récompense promise. Mais ne partez pas si vite, je veux vous confier une autre affaire. Pfiefer est un homme de l'équipage de Norman Vigo, qui navigue sur le cotre Normandie. Je suis sמr que Norman Vigo est l'informateur, même s'il est des nכtres. On l'a vu récemment dans les eaux de l'île ; votre travail consiste à envoyer ce rat chez le diable des mers. La première fois, vous ne m'avez pas déçu, alors je veux vous confier cette affaire. Je paierai 15 000 piastres. D'accord ?";
			link.l1 = "J'accepte ! Considérez que ce traître de Norman Vigo est déjà mort.";
			link.l1.go = "pirateStartQuest_info_3";
			link.l2 = "Vous savez quoi, je ne veux pas me mêler de ça... Et je n'ai pas le temps. Désolé, mais je passe mon tour.";
			link.l2.go = "pirateStartQuest_info_noex";
			AddMoneyToCharacter(pchar, 10000);
		break;
		case "pirateStartQuest_info_noex":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
		break;
		case "pirateStartQuest_info_3":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "4";

			AddQuestRecord("pSQ", "7");
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);

			pchar.quest.zpq_seaBattle.win_condition.l1 = "location";
			pchar.quest.zpq_seaBattle.win_condition.l1.location = pchar.questTemp.pirateStartQuest.Areal;
			pchar.quest.zpq_seaBattle.function = "pirateStartQuest_seaBattle";
		break;

		case "pirateStartQuest_final":
			dialog.text = "On sait, on sait. Mes hommes ont assisté au combat et m'ont déjà rapporté avec quel brio vous vous en êtes tiré. Eh bien, vous avez fait votre travail comme il faut, voici la récompense promise de 15 000 piastres. Et merci, vous m'avez beaucoup aidé.";
			link.l1 = "Tout va bien, ravi d'avoir pu aider ! Et maintenant, j'ai à faire. א plus tard !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 15000);
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
			group_DeleteGroup("pirateStartQuest_Smuggler_group");
		break;

		// ------------------------- Повод для спешки -----------------------------
		case "ReasonToFast_Mayor1":
			dialog.text = "Je vous écoute attentivement, capitaine.";
			link.l1 = "Je veux vous signaler un complot criminel entre un officier de votre garnison et des pirates (vous exposez les circonstances de l'affaire).";
			if(sti(pchar.reputation) < 40)
			{
				link.l1.go = "ReasonToFast_BMayor";
			}
			else
			{
				link.l1.go = "ReasonToFast_GMayor";
			}
			pchar.questTemp.ReasonToFast.SpeakOther = true;
			if(CheckAttribute(pchar,"GenQuest.CannotWait"))	DeleteAttribute(pchar, "GenQuest.CannotWait");
		break;

		case "ReasonToFast_GMayor":
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_1")
			{
				// вилка_А
				dialog.text = "Merci, "+ GetSexPhrase("monsieur","mademoiselle") +" ! Je vais immédiatement donner l'ordre d'arrêter ce gredin. Toutefois, vous avez beaucoup dépensé, et le trésor municipal est hélas vide...";
				link.l1 = "Votre Grâce ! Je ne l'ai pas fait pour l'argent...";
				link.l1.go = "ReasonToFast_GMayor_11";
				if(pchar.questTemp.ReasonToFast.chain == "A0") ReasonToFast_RemoveVictim();
				if(pchar.questTemp.ReasonToFast.chain == "A1") pchar.quest.ReasonToFast_ClearLakey.over = "yes";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_2")
			{
				// получена карта
				dialog.text = "Merci, "+ GetSexPhrase("monsieur","mademoiselle") +" ! Je vais immédiatement donner l'ordre d'arrêter ce gredin. Rendez-vous compte ! Nous voulions le récompenser d'une arme d'honneur pour ses états de service irréprochables. Heureusement que tout s'est éclairci et que nous avons évité cet embarras !";
				link.l2 = "Toujours heureux de servir la justice...";
				link.l2.go = "ReasonToFast_GMayor_21";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolDied")
			{
				// патруль перебит
				dialog.text = GetSexPhrase("Monsieur","Mademoiselle") +" ! Nous soupçonnions depuis longtemps cet officier et la racaille qui l'entoure de malhonnêteté, mais il me semble que vous avez agi imprudemment en réglant leur compte sans témoins.";
				link.l3 = "Votre Grâce ! Je défendais ma vie...";
				link.l3.go = "ReasonToFast_GMayor_31";
				pchar.questTemp.ReasonToFast.speakAfterPatrolDied = true;
				pchar.quest.ReasonToFast_SpeakMayor.over = "yes";
			}
		break;

		case "ReasonToFast_BMayor":
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_1")
			{
				dialog.text = "Capitaine, vous rendez-vous seulement compte de ce dans quoi vous vous mêlez ?!! Cela fait plus d'un mois que nous essayons de tendre ce piège ! Et pour vous amuser, vous avez fait échouer la rencontre de notre patrouille avec le messager " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN) + " et vous venez en plus vous en vanter chez moi ! Peut-être pourriez-vous maintenant me dire comment je vais justifier les dépenses publiques engagées pour organiser cette opération ?!!";
				link.l1 = "Votre Grâce ! Vous refusez de voir le fond de l'affaire...";
				link.l1.go = "ReasonToFast_BMayor_1";
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_A";
				if(pchar.questTemp.ReasonToFast.chain == "A0") ReasonToFast_RemoveVictim();
				if(pchar.questTemp.ReasonToFast.chain == "A1") pchar.quest.ReasonToFast_ClearLakey.over = "yes";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolSuccess_2")
			{
				// получена карта
				dialog.text = "Voyons cette carte... Vous vous moquez de moi ? Ce vieux bout de parchemin usé, une preuve ?";
				link.l2 = "Votre Grâce ! Vous refusez de voir le fond de l'affaire...";
				link.l2.go = "ReasonToFast_BMayor_1";
				TakeItemFromCharacter(pchar, "mapQuest");
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_B";
			}
			if(pchar.questTemp.ReasonToFast == "PatrolDied")
			{
				// патруль перебит
				dialog.text = "Une justification originale pour la mort de toute une patrouille. Enfin, en venant ici, vous nous avez au moins épargné la peine de chercher l'assassin.";
				link.l3 = "Votre Grâce ! Vous refusez de voir le fond de l'affaire...";
				link.l3.go = "ReasonToFast_BMayor_1";
				pchar.questTemp.ReasonToFast = "speakSuccess_chain_A";
				pchar.quest.ReasonToFast_SpeakMayor.over = "yes";
			}
		break;

		case "ReasonToFast_GMayor_11":
			dialog.text = "Néanmoins, je veux que vos efforts soient récompensés. Tenez, prenez cette carte trouvée dans les affaires d'un brigand des mers pendu récemment. Peut-être qu'avec l'aide du Seigneur, vous découvrirez vraiment ces trésors, même si j'en doute fort...";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			AddQuestRecord("ReasonToFast", "15");
			ChangeCharacterReputation(pchar, 1);
			GiveItem2Character(pchar, "mapQuest");
			arItem = ItemsFromID("mapQuest");
			ReasonToFast_GenerateTreasureMap(arItem);
			pchar.questTemp.ReasonToFast.state = "chain_A"; // вилка_А, наводки не генерим
			pchar.questTemp.ReasonToFast = "GetMap";
			ReasonToFast_SetHunterCoastal();
		break;

		case "ReasonToFast_GMayor_21":
			dialog.text = "Un zèle louable. Prenez cette lame en récompense. C'est bien le moins que je puisse vous donner ! Oui.. et gardez cette carte pour vous. Je suis sמr qu'il circule beaucoup de faux de ce genre dans l'archipel.";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			AddQuestRecord("ReasonToFast", "14");
			ChangeCharacterReputation(pchar, 1);
			GiveItem2Character(pchar, pchar.questTemp.ReasonToFast.p6);
			pchar.questTemp.ReasonToFast.state = "chain_B"; // была получена карта
			pchar.questTemp.ReasonToFast = "GetMap";
			ReasonToFast_SetHunterCoastal();
		break;
		case "ReasonToFast_GMayor_31":
			dialog.text = "Oui, peut-être, peut-être... Eh bien, je suis prêt à considérer que l'affaire a été réglée par le jugement de Dieu et selon Sa volonté.";
			link.l1 = "Merci, vous êtes très généreux !";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 1);
			AddQuestRecord("ReasonToFast", "16");
			CloseQuestHeader("ReasonToFast");
			DeleteAttribute(pchar,"ReasonToFast");
		break;

		case "ReasonToFast_BMayor_1":
			dialog.text = "Ne vous avisez pas de me faire la leçon ! Votre collusion avec ces escrocs est évidente ! Garde, emmenez "+ GetSexPhrase("ce « bienfaiteur »","cette « bienfaitrice »") +" !";
			link.l1 = "Pas question !";
			link.l1.go = "fight";

			pchar.quest.ReasonToFast_ExitFromTown.win_condition.l1			= "EnterToSea";
            pchar.quest.ReasonToFast_ExitFromTown.function    				= "ReasonToFast_ExitFromTownFight";
			pchar.questTemp.ReasonToFast.canSpeakSailor = true;
			pchar.TownEscape = true;
			Flag_Change(PIRATE);
		break;

		// ------------------------- Повод для спешки -----------------------------

		// --------------------------Операция 'Галеон'-----------------------------
		case "CapComission_Mayor1":
			dialog.text = "Ce n'est pas possible pour le moment. Il est aux arrêts et attend son procès.";
			link.l1 = "Vraiment ? Et de quoi est-il soupçonné ?";
			link.l1.go = "CapComission_Mayor2";
		break;

		case "CapComission_Mayor2":
			dialog.text = "Malheureusement, ce n'est pas un soupçon, mais un fait avéré. Nous avons appris que, sous couvert de patrouilles, il se livrait en réalité au brigandage maritime : il confisquait les marchandises des navires marchands de passage et les revendait en secret. Et dire que nous le considérions comme l'un des meilleurs capitaines de l'escadre de patrouille.";
			link.l1 = "Et qui a fourni les preuves ?";
			link.l1.go = "CapComission_Mayor3";
		break;

		case "CapComission_Mayor3":
			dialog.text = "L'une des victimes a envoyé un rapport détaillé de l'incident, avec la date, le nom du navire lésé et la quantité de marchandises confisquées. " +
				"Croyez-moi, les chiffres sont très solides. Ce jour-là, la patrouille sur " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name"))) + " du capitaine " + pchar.GenQuest.CaptainComission.Name + " était bien en service. Dans son rapport, le capitaine a décrit l'incident comme une escarmouche avec un navire pirate, mais n'a pas dit un mot de la cargaison.";
			link.l1 = "Y avait-il seulement une cargaison ?";
			link.l1.go = "CapComission_Mayor4";
			pchar.GenQuest.CaptainComission.SpeakMayor = true;
		break;

		case "CapComission_Mayor4":
			dialog.text = "Cela ne fait aucun doute, la victime est une personne bien trop connue pour s'abaisser à de mesquines calomnies. En ce moment même, des patrouilles recherchent la cachette du capitaine " + pchar.GenQuest.CaptainComission.Name + ". " +
				"Dès qu'on l'aura trouvée, le capitaine passera en jugement. Si vous nous aidez dans cette affaire, les autorités de la ville, en ma personne, vous en seront très reconnaissantes.";
			link.l1 = "Plutכt pas. Je ne connais pas assez bien les environs pour chercher une cachette. Excusez-moi, je dois y aller.";
			link.l1.go = "CapComission_Mayor5";
			link.l2 = "Je crois que je suis prêt. De combien de temps je dispose ?";
			link.l2.go = "CapComission_Mayor6";
		break;

		case "CapComission_Mayor5":
			AddQuestRecord("CaptainComission2", "49");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			ChangeCharacterReputation(pchar, -2);
			pchar.GenQuest.CaptainComission = "MayorTalkBad";
			CaptainComission_GenerateCaptainInPrison();
			DialogExit();
		break;

		case "CapComission_Mayor6":
			dialog.text = "Je pense que la patrouille trouvera la cachette en deux jours sans vous, alors je vous conseille de vous dépêcher.";
			link.l1 = "D'accord, je me charge de l'affaire. Mais il me faudra un entretien avec le capitaine " + pchar.GenQuest.CaptainComission.Name + ". Y a-t-il un moyen d'arranger ça ?";
			link.l1.go = "CapComission_Mayor7";
		break;

		case "CapComission_Mayor7":
			dialog.text = "Bien sמr, cela ne posera aucun problème, je préviendrai le commandant du fort de votre visite.";
			link.l1 = "Merci. Permettez-moi de prendre congé.";
			link.l1.go = "CapComission_Mayor8";
		break;

		case "CapComission_Mayor8":
			AddQuestRecord("CaptainComission2", "50");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			OfficersReaction("good");
			pchar.GenQuest.CaptainComission.MayorTalkGood = true;
			pchar.GenQuest.CaptainComission = "MayorTalkGood";
			pchar.quest.CaptainComission_TimeIsOver.over = "yes";
			SetFunctionTimerConditionParam("CaptainComission_GetSecretTimeIsOut", 0, 0, 2, MakeInt(24 - GetHour()), false);
			CaptainComission_GenerateCaptainInPrison();
			DialogExit();
		break;

		case "CapComission_Mayor9":
			dialog.text = "Parfait ! Et oם faut-il chercher ses trésors ?";
			link.l1 = "Je ne sais pas encore. Il ne m'a pas encore indiqué l'endroit exact.";
			link.l1.go = "CapComission_Mayor10";
		break;

		case "CapComission_Mayor10":
			dialog.text = "Hum, quelle coïncidence ! א moi non plus, il n'a pas « indiqué » l'endroit exact...";
			link.l1 = "Mais j'y travaille.";
			link.l1.go = "CapComission_Mayor11";
		break;

		case "CapComission_Mayor11":
			dialog.text = "Plus maintenant. Gardes !.. Ramenez le prisonnier au cachot. Vous êtes libre, " + GetFullName(pchar) + ".";
			link.l1 = "Mais, monsieur le gouverneur...";
			link.l1.go = "CapComission_Mayor12";
		break;

		case "CapComission_Mayor12":
			sld = CharacterFromID("CapComission_1");
			sld.lifeDay = 0;
			LAi_group_MoveCharacter(sld, "EnemyFight");
			LAi_SetActorType(sld);
            LAi_ActorRunToLocation(sld, "reload", "reload1_back", "none", "", "", "", -1);
			pchar.quest.CapComission_DeletePrisonGroup.win_condition.l1 = "ExitFromLocation";
            pchar.quest.CapComission_DeletePrisonGroup.win_condition.l1.location = pchar.location;
            pchar.quest.CapComission_DeletePrisonGroup.win_condition = "CaptainComission_DeletePrisonGroup";
			ChangeOfficersLoyality("bad_all", 1);
			ChangeCharacterReputation(pchar, -4);
			AddQuestRecord("CaptainComission2", "23");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("CaptainComission2");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;

		case "CapComission_Mayor13":
			pchar.quest.CaptainComission_SpeakMayorGoods.over = "yes";
			dialog.text = "Parfait ! Et oם faut-il chercher ses trésors ?";
			link.l1 = "א l'extrémité " + RandPhraseSimple(RandPhraseSimple("nord","ouest"),RandPhraseSimple("est","sud")) + " de " + XI_ConvertString(pchar.GenQuest.CaptainComission.ConvoyShore + "Gen") + " – au pied de la falaise, il y a une grande niche dont l'entrée est jonchée de pierres. C'est la cachette.";
			link.l1.go = "CapComission_Mayor14";
		break;

		case "CapComission_Mayor14":
			dialog.text = "Beau travail ! Et oם est donc " + pchar.GenQuest.CaptainComission.Name + " ? On m'a informé que vous l'aviez fait sortir des caves du fort.";
			link.l1 = "Malheureusement, il est mort dans une escarmouche avec des contrebandiers.";
			link.l1.go = "CapComission_Mayor15";
		break;

		case "CapComission_Mayor15":
			dialog.text = "C'est fâcheux... C'est très fâcheux, "+ GetSexPhrase("monsieur","mademoiselle") +" " + GetFullName(pchar) + ". Je voulais l'exécuter publiquement, pour l'exemple, pour ainsi dire, à l'intention des autres officiers. " +
				"Bon, de toute façon, il n'aurait pas échappé à la potence... Donc, puisque vous avez formellement enfreint la loi en libérant un prisonnier de votre propre chef, et que vous ne l'avez même pas sauvé, je ne peux que le consigner au procès-verbal. Vous ne recevrez donc aucune récompense... Mais j'aimerais vous remercier personnellement. Acceptez mon cadeau : un objet très utile pour un capitaine de combat.";
			link.l1 = "Merci. Toujours fier de servir.";
			link.l1.go = "CapComission_Mayor16";
		break;

		case "CapComission_Mayor16":
			AddQuestRecord("CaptainComission2", "30");
			AddQuestUserData("CaptainComission2", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			CloseQuestHeader("CaptainComission2");
			GiveItem2Character(pchar, pchar.GenQuest.CaptainComission.Prize);
			ChangeCharacterReputation(pchar, 4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 10);
			OfficersReaction("good");
			DeleteAttribute(pchar,"GenQuest.CaptainComission.MayorTalkGood");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			DialogExit();
		break;
		// --------------------------Операция 'Галеон'-----------------------------

		// ---------------------- найти кольцо в борделе ----------------------------
		case "TakeRing_1":
			dialog.text = "Je sais que vous êtes... comment dire... "+ GetSexPhrase("un habitué des bordels","une habituée des bordels") +". C'est pourquoi j'ai décidé de vous demander de l'aide\n"+
				"Vous savez, j'ai honte de l'avouer, mais j'y suis allé récemment...";
			link.l1 = "Hum, pourquoi en avoir honte ? C'est normal, l'attirance et tout ça...";
			link.l1.go = "TakeRing_2";
		break;
		case "TakeRing_2":
			dialog.text = "Hé, ce n'est pas de ça que j'ai honte. J'y ai trop bu, et j'ai perdu mon alliance !..";
			link.l1 = "Eh bien, voilà un sérieux problème, je compatis.";
			link.l1.go = "TakeRing_3";
		break;
		case "TakeRing_3":
			dialog.text = "Hum, je n'ai pas besoin de compassion. Il faut retrouver la bague. Retrouvez-la avant minuit, et en cas de succès, je serai très généreux. Et en cas d'échec, je suis fichu.";
			link.l1 = "Compris... Et oם exactement auriez-vous pu la perdre ? Pouvez-vous me dire quelque chose d'un peu précis ?";
			link.l1.go = "TakeRing_4";
		break;
		case "TakeRing_4":
			dialog.text = "Hélas, non. Je ne me souviens de rien...";
			link.l1 = "Compris. Eh bien, cherchons-la.";
			link.l1.go = "TakeRing_5";
			link.l2 = "Vous savez, " + GetAddress_FormToNPC(NPChar) + ", je crois que je vais renoncer à ce travail. Veuillez m'excuser...";
			link.l2.go = "TakeRing_6";
		break;
		case "TakeRing_5":
			dialog.text = "Très bien ! Mais n'oubliez pas, vous devez la retrouver avant minuit.";
			link.l1 = "Je m'en souviens. Attendez-moi avec les nouvelles.";
			link.l1.go = "exit";
			pchar.questTemp.different = "TakeMayorsRing";
			pchar.questTemp.different.TakeMayorsRing = "toBrothel";
			pchar.questTemp.different.TakeMayorsRing.Id = GetFullName(npchar);
			pchar.questTemp.different.TakeMayorsRing.city = npchar.city;
			pchar.questTemp.different.TakeMayorsRing.price = sti(pchar.rank)*100+1000;
			sld = ItemsFromID("MayorsRing");
			sld.CityName = XI_ConvertString("Colony" + npchar.city + "Gen");
			//ложим кольцо в итем
			if (rand(3) != 2)
			{
				switch (rand(2))
				{
					case 0: sTemp = "_Brothel_room";  break;
					case 1: sTemp = "_Brothel";  break;
					case 2: sTemp = "_SecBrRoom";  break;
				}
				sld.shown = true;
				sld.startLocation = pchar.questTemp.different.TakeMayorsRing.city + sTemp;
				sld.startLocator = "item" + (rand(4)+1);
				pchar.questTemp.different.TakeMayorsRing.item = true; //флаг кольцо валяется в итемах
				Log_QuestInfo("La bague se trouve à l'emplacement " + sld.startLocation + ", au locator " + sld.startLocator);
			}
			SetTimerFunction("TakeMayorsRing_null", 0, 0, 1); //освобождаем разрешалку на миниквесты
			ReOpenQuestHeader("SeekMayorsRing");
			AddQuestRecord("SeekMayorsRing", "1");
			AddQuestUserData("SeekMayorsRing", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("SeekMayorsRing", "sName", pchar.questTemp.different.TakeMayorsRing.Id);
		break;
		case "TakeRing_6":
			dialog.text = "Vraiment ? Hum, je ne m'y attendais pas, je ne m'y attendais pas... Eh bien, bonne journée, capitaine.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -2);
		break;

		case "TakeRing_S1":
			dialog.text = "Parfait, c'est bien elle !! Vous venez de me sauver la vie !";
			link.l1 = "Allons, voyons...";
			link.l1.go = "TakeRing_S2";
			TakeItemFromCharacter(pchar, "MayorsRing");
		break;
		case "TakeRing_S2":
			dialog.text = "Voici votre argent pour le travail accompli. Et sachez que je vous suis très reconnaissant !";
			link.l1 = "Hum, je m'en souviendrai...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 10);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			AddCharacterExpToSkill(pchar, "Fortune", 20);
			AddMoneyToCharacter(pchar, sti(pchar.questTemp.different.TakeMayorsRing.price));
			pchar.questTemp.different = "free";
			pchar.quest.TakeMayorsRing_null.over = "yes"; //снимаем таймер
			AddQuestRecord("SeekMayorsRing", "7");
			AddQuestUserData("SeekMayorsRing", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			CloseQuestHeader("SeekMayorsRing");

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.different.TakeMayorsRing");
		break;
		case "TakeRing_S3":
			dialog.text = "Eh bien !! Il faudrait boire moins...";
			link.l1 = "דa, c'est sמr ! Eh bien, voici votre bague.";
			link.l1.go = "TakeRing_S4";
		break;
		case "TakeRing_S4":
			dialog.text = "Oui, oui, merci beaucoup. Je suis votre débiteur ! Voici votre argent pour le travail accompli.";
			link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			TakeItemFromCharacter(pchar, "MayorsRing");
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 10);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			AddMoneyToCharacter(pchar, sti(pchar.questTemp.different.TakeMayorsRing.price));
			pchar.questTemp.different = "free";
			pchar.quest.TakeMayorsRing_null.over = "yes"; //снимаем таймер
			AddQuestRecord("SeekMayorsRing", "7");
			AddQuestUserData("SeekMayorsRing", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			CloseQuestHeader("SeekMayorsRing");

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.different.TakeMayorsRing");
		break;
		// ---------------------- найти кольцо в борделе ----------------------------

		case "node_1":
            //ОСАДЫ homo
			if (CheckAttribute(Colonies[FindColony(npchar.City)],"Siege"))
            {

                makearef(aData, NullCharacter.Siege);


                if (CheckAttribute(aData, "HelpColony") && sti(aData.HelpColony) == true )
                {
                    dialog.text = "Nous avons déjà tout réglé, n'est-ce pas ?";
                    link.l1 = "C'est exact, je ne vous retiens pas plus longtemps.";
                    link.l1.go = "exit";

                }
                else
                {
                    dialog.text = "Je dois vous décevoir, mais je n'ai pas le temps de vous recevoir pour le moment. Comme vous le savez sans doute, notre colonie a été attaquée par "+NationNamePeople(sti(aData.nation))+". Et je dois organiser la défense de la ville.";
                    link.l1 = "C'est justement ce que je voulais : vous proposer mon aide pour défendre le fort.";
                    link.l1.go = "siege_task";
                    link.l2 = "Alors je ne vous retiens pas plus longtemps.";
        			link.l2.go = "exit";
                }
            }
            else
            {//->
                makearef(aData, NullCharacter.Siege);
                if (CheckAttribute(aData, "PlayerHelpMayor") && sti(aData.PlayerHelpMayor) == true
                && CheckAttribute(aData, "HelpColony") && sti(aData.HelpColony) == true )
                {
                    // LEO: pay only for assault ships actually sank/captured (reward accrued by class), no freebie for watching
                    DeleteAttribute(aData, "PlayerHelpMayor");
                    DeleteAttribute(aData, "HelpColony");
                    if (sti(aData.PlayerSiegeKills) > 0)
                    {
                        AddMoneyToCharacter(Pchar, sti(aData.PlayerSiegeReward));
                        ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
                        ChangeCharacterReputation(PChar, 10);
                        AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 80);
                        AddCharacterExpToSkill(GetMainCharacter(), "Sailing", 100);
                        AddCharacterExpToSkill(GetMainCharacter(), "Accuracy", 100);
                        AddCharacterExpToSkill(GetMainCharacter(), "Cannons", 100);
                        SiegeRumour("Le bruit court que vous nous avez aidés à repousser l'escadre "+NationNameSK(sti(aData.nation))+" et à défendre notre colonie ! Nous vous en sommes si reconnaissants, "+ GetAddress_Form(NPChar)+".", aData.Colony, sti(aData.conation), -1, 15, 3);
                        dialog.text = "Ah, c'est vous, "+GetAddress_Form(NPChar)+" "+GetFullName(pchar)+", ravi de vous voir. Bonne nouvelle pour notre colonie : nous avons repoussé la flotte d'invasion "+NationNameSK(sti(aData.nation))+" - et c'est en grande partie grâce à vous : vous avez coulé ou capturé "+sti(aData.PlayerSiegeKills)+" navires ennemis. Le trésor vous verse "+sti(aData.PlayerSiegeReward)+" pièces d'or, comme promis. Veuillez les recevoir.";
                        link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + ". Un plaisir de faire affaire avec vous !";
                        link.l1.go = "exit";
                    }
                    else
                    {
                        // LEO: 0 sank/captured by player - a word of thanks, no gold
                        ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
                        dialog.text = "Ah, c'est vous, "+GetAddress_Form(NPChar)+" "+GetFullName(pchar)+". Eh bien, nous avons repoussé la flotte d'invasion "+NationNameSK(sti(aData.nation))+" - même si, pour être honnête, je n'ai pas vu votre main dans la bataille navale : vous n'avez coulé ni abordé aucun navire ennemi. Le trésor n'a rien à vous offrir en récompense, sans vouloir vous offenser. Mais merci de ne pas être resté à l'écart.";
                        link.l1 = "Je comprends, " + GetAddress_FormToNPC(NPChar) + ". La prochaine fois, je ferai mes preuves au combat.";
                        link.l1.go = "exit";
                    }
                }
                else
                {
                    if (CheckAttribute(aData, "PlayerHelpMayor")) DeleteAttribute(aData, "PlayerHelpMayor");
                    dialog.text = "Alors, quelle raison vous amène ici pour me distraire d'importantes affaires d'וtat ?";
        			link.l1 = "Je voudrais parler d'un travail au service de " + NationNameGenitive(sti(NPChar.nation))+".";
        			link.l1.go = "work";

        			link.l2 = "J'ai besoin de vous parler de quelque chose.";
					if(CheckAttribute(pchar,"questTemp.ReasonToFast") && !CheckAttribute(pchar,"questTemp.ReasonToFast.SpeakOther") && !CheckAttribute(pchar, "questTemp.ReasonToFast.cantSpeakOther") && (pchar.questTemp.ReasonToFast.city == NPChar.city))
					{
						link.l2.go = "ReasonToFast_Mayor1";
					}
					else
					{
						link.l2.go = "quests";
					}
					if(CheckAttribute(pchar,"GenQuest.CaptainComission") && (pchar.GenQuest.CaptainComission.variant == "A2") && (pchar.GenQuest.CaptainComission.City == NPChar.city))
					{
						if(pchar.GenQuest.CaptainComission == "Begin_1" && !CheckAttribute(pchar,"GenQuest.CaptainComission.SpeakMayor"))
						{
							link.l12 = "Vous avez à votre service un capitaine de patrouille sur " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " nommé " + pchar.GenQuest.CaptainComission.Name + " ; comment puis-je le voir ?";
							link.l12.go = "CapComission_Mayor1";
						}
						if(CheckAttribute(pchar,"GenQuest.CaptainComission.PrisonFree"))
						{
							link.l12 = "L'ancien capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " a accepté de vous montrer son trésor.";
							link.l12.go = "CapComission_Mayor9";
						}
						if(pchar.GenQuest.CaptainComission == "GetGoodsSuccess")
						{
							link.l12 = "L'ancien capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType),"Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " m'a montré son trésor.";
							link.l12.go = "CapComission_Mayor13";
						}
					}
        			if (GetPrisonerQty() > 0)
        			{
                        link.l3 = "Je dois remettre le capitaine prisonnier aux autorités.";
        			    link.l3.go = "sell_prisoner";
        			}
        			link.l4 = "J'aimerais savoir oם se trouve le gouverneur général de " + NationNameGenitive(sti(NPChar.nation)) + " en ce moment.";
        			link.l4.go = "Where_guber";
        			link.l5 = "Vous voulez peut-être vous détendre un peu de vos importantes affaires ?";
        			link.l5.go = "Play_Game";
        			link.l10 = "C'est juste une visite de courtoisie, rien de plus, " + GetAddress_FormToNPC(NPChar) + ".";
        			link.l10.go = "node_2";
                }
    		}//<-
		break;

		case "Play_Game":
			dialog.text = "Hum, et à quels jeux préférez-vous jouer ?";
			link.l1 = "Une partie de cartes pour un enjeu sérieux ?";
			link.l1.go = "Card_Game";
   			link.l2 = "Un coup de dés au poker-joker ?";
			link.l2.go = "Dice_Game";
			link.l10 = "Pardonnez-moi, mais j'ai à faire.";
			link.l10.go = "exit";
		break;

		//  карты -->
        case "Card_Game":
            if (!CheckNPCQuestDate(npchar, "Card_date_Yet") || sti(PChar.rank) < 4 || isBadReputation(pchar, 60) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < (2 + rand(2)) )
            {
                SetNPCQuestDate(npchar, "Card_date_Yet");
                dialog.text = "Je ne joue pas avec n'importe quels escrocs !";
    			link.l1 = "Comme vous voudrez.";
    			link.l1.go = "exit";
			}
			else
			{
				if (CheckNPCQuestDate(npchar, "Card_date_begin"))
				{
					dialog.text = "Allez ! Le jeu n'a jamais fait de mal à la santé... seulement à la bourse...";
	    			link.l1 = "Parfait.";
	    			link.l1.go = "Cards_begin";
	    			link.l2 = "Quelles sont les règles du jeu ?";
	    			link.l2.go = "Cards_Rule";
    			}
    			else
    			{
					dialog.text = "Non, j'en ai assez pour aujourd'hui. Les affaires m'attendent.";
	    			link.l1 = "Comme vous voudrez.";
	    			link.l1.go = "exit";
				}
			}
		break;

		case "Cards_Rule":
   			dialog.text = XI_ConvertString("CardsRules");
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Cards_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Cards_begin":
			dialog.text = "Fixons la mise.";
			link.l1 = "On joue 1000 pièces la carte.";
			link.l1.go = "Cards_Node_100";
			link.l2 = "Jouons 5000 pièces d'or la carte.";
			link.l2.go = "Cards_Node_500";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit";
		break;

		case "Cards_Node_100":
            if (!CheckCardsGameSmallRate())
		    {
                dialog.text = "Vous avez la réputation d'un tricheur hors pair. Je ne jouerai pas avec vous.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 3000)
		    {
                dialog.text = "Vous vous moquez de moi, " + GetAddress_Form(NPChar) + " ? Vous n'avez pas assez d'argent !";
                link.l1 = "דa arrive.";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 3000)
		    {
                dialog.text = "דa suffit ! Il faut arrêter les cartes, sinon on va nous accuser de détournement et me démettre de mes fonctions...";
                link.l1 = "Désolé.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "D'accord, jouons pour 1000 pièces.";
			link.l1 = "Commençons !";
			link.l1.go = "Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
            pchar.GenQuest.Cards.iRate     = 1000;
            pchar.GenQuest.Cards.SitType   = false;
		break;

		case "Cards_Node_500":
            if (!CheckCardsGameSmallRate())
		    {
                dialog.text = "Vous avez la réputation d'un tricheur hors pair. Je ne jouerai pas avec vous.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }
			if (!CheckCardsGameBigRate())
		    {
                dialog.text = "J'ai entendu dire que vous jouiez très bien. Je ne jouerai pas avec vous à des mises aussi élevées.";
                link.l1 = "Et si on misait moins ?";
			    link.l1.go = "Cards_Node_100";
				link.l2 = "Désolé, je dois y aller.";
			    link.l2.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 15000)
		    {
                dialog.text = "Vous vous moquez de moi, " + GetAddress_Form(npchar) + " ? Vous n'avez pas assez d'argent !";
                link.l1 = "J'en aurai !";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 15000)
		    {
                dialog.text = "Non, de telles mises ne feraient pas de bien au trésor de la ville.";
                link.l1 = "Peu importe.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "D'accord, on joue pour 5 000 pièces.";
			link.l1 = "Commençons !";
			link.l1.go = "Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
            pchar.GenQuest.Cards.iRate     = 5000;
            pchar.GenQuest.Cards.SitType   = false;
		break;

		case "Cards_begin_go":
            SetNPCQuestDate(npchar, "Card_date_begin");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
            LaunchCardsGame();
		break;
	    // карты <--

	    //  Dice -->
        case "Dice_Game":
            if (!CheckNPCQuestDate(npchar, "Dice_date_Yet") || sti(PChar.rank) < 4 || isBadReputation(pchar, 60) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < (2+rand(2)) )
            {
                SetNPCQuestDate(npchar, "Dice_date_Yet");
                dialog.text = "Je ne joue pas avec n'importe quels escrocs !";
    			link.l1 = "Comme vous voudrez.";
    			link.l1.go = "exit";
			}
			else
			{
				if (CheckNPCQuestDate(npchar, "Dice_date_begin"))
				{
					dialog.text = "Allez ! Le jeu n'a jamais fait de mal à la santé... seulement à la bourse...";
	    			link.l1 = "Parfait.";
	    			link.l1.go = "Dice_begin";
	    			link.l2 = "Quelles sont les règles du jeu ?";
	    			link.l2.go = "Dice_Rule";
    			}
    			else
    			{
					dialog.text = "Non, j'en ai assez pour aujourd'hui. Les affaires m'attendent.";
	    			link.l1 = "Comme vous voudrez.";
	    			link.l1.go = "exit";
				}
			}
		break;

		case "Dice_Rule":
   			dialog.text = XI_ConvertString("DiceRules");
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Dice_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Dice_begin":
			dialog.text = "Fixons la mise.";
			link.l1 = "On joue 500 pièces le coup de dés.";
			link.l1.go = "Dice_Node_100";
			link.l2 = "Jouons 2000 pièces d'or le coup de dés.";
			link.l2.go = "Dice_Node_500";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit";
		break;

		case "Dice_Node_100":
            if (!CheckDiceGameSmallRate())
		    {
                dialog.text = "Vous avez la réputation d'un tricheur hors pair. Je ne jouerai pas avec vous.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 3000)
		    {
                dialog.text = "Vous vous moquez de moi, " + GetAddress_Form(NPChar) + " ? Vous n'avez pas assez d'argent !";
                link.l1 = "דa arrive.";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 3000)
		    {
                dialog.text = "דa suffit ! Il faut arrêter de jouer, sinon on va m'accuser de détournement et me démettre de mes fonctions...";
                link.l1 = "Désolé.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "D'accord, jouons pour 500 pièces.";
			link.l1 = "Commençons !";
			link.l1.go = "Dice_begin_go";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
            pchar.GenQuest.Dice.iRate     = 500;
            pchar.GenQuest.Dice.SitType   = false;
		break;

		case "Dice_Node_500":
            if (!CheckDiceGameSmallRate())
		    {
                dialog.text = "Vous avez la réputation d'un tricheur hors pair. Je ne jouerai pas avec vous.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }
			if (!CheckDiceGameBigRate())
		    {
                dialog.text = "J'ai entendu dire que vous jouiez très bien. Je ne jouerai pas avec vous à des mises aussi élevées.";
                link.l1 = "Et si on misait moins ?";
			    link.l1.go = "Dice_Node_100";
				link.l2 = "Désolé, je dois y aller.";
			    link.l2.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 15000)
		    {
                dialog.text = "Vous vous moquez de moi, " + GetAddress_Form(NPChar) + " ? Vous n'avez pas assez d'argent !";
                link.l1 = "J'en aurai !";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 15000)
		    {
                dialog.text = "Non, de telles mises ne feraient pas de bien au trésor de la ville.";
                link.l1 = "Peu importe.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "D'accord, on joue 2000 pièces le coup.";
			link.l1 = "Commençons !";
			link.l1.go = "Dice_begin_go";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
            pchar.GenQuest.Dice.iRate     = 2000;
            pchar.GenQuest.Dice.SitType   = false;
		break;

		case "Dice_begin_go":
            SetNPCQuestDate(npchar, "Dice_date_begin");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
            LaunchDiceGame();
		break;
	    // Dice <--
		case "node_2":
			dialog.snd = "Voice\CHMA\CHMA004";
			dialog.text = "Dans ce cas, je vous prierai de quitter mon bureau et de ne plus gêner mon travail.";
			link.l1 = "Oui, oui, bien sמr, désolé de vous avoir dérangé.";
			link.l1.go = "exit";
		break;

		case "Where_guber":
            offref = characterFromID(NationShortName(sti(NPChar.nation))+"_guber");

            if (NPChar.location == offref.location)
            {
                dialog.text = "Ouvrez les yeux, ignorant !!! Son  " + RandPhraseSimple("Excellence", "Excellence") + " le gouverneur général de "+NationNameGenitive(sti(NPChar.nation))+ " " + GetFullName(offref)+
                              " est ici même, dans cette pièce";
    			link.l1 = "Merci. Pardonnez mon manque de tact.";
    			link.l1.go = "exit";
            }
            else
            {
                if (bBettaTestMode || GetSummonSkillFromNameToOld(Pchar, SKILL_LEADERSHIP) > rand(5) || CheckCharacterItem(Pchar, "patent_" + NationShortName(sti(NPChar.nation))))// когда патен всегда
                {
                    cn = FindLocation(offref.location);
                	if(cn < 0)
                    {
                        attrLoc = "error";
                        dialog.text = "Son " + RandPhraseSimple("Excellence", "Excellence") + " le gouverneur général de "+NationNameGenitive(sti(NPChar.nation))+ " " + GetFullName(offref)+
                                      " est parti pour l'Europe.";
                    }
                	else
                	{
                	    attrLoc = locations[cn].islandId;
                	    if (attrLoc == "Mein")
                	    {
        			    	dialog.text = "Son " + RandPhraseSimple("Excellence", "Excellence") + " le gouverneur général de "+NationNameGenitive(sti(NPChar.nation))+ " " + GetFullName(offref)+
                                  LinkRandPhrase(" se trouve actuellement sur le Continent ",
                                            " s'occupe d'importantes affaires publiques sur le Continent ",
                                            " est en visite sur le Continent ") + " dans la ville de " + GetConvertStr(locations[cn].fastreload + " Town", "LocLables.txt") + ".";
						}
						else
						{
						    dialog.text = "Son " + RandPhraseSimple("Excellence", "Excellence") + " le gouverneur général de "+NationNameGenitive(sti(NPChar.nation))+ " " + GetFullName(offref)+
                                  LinkRandPhrase(" se trouve actuellement sur l'île de ",
                                            " s'occupe d'importantes affaires publiques sur l'île de ",
                                            " est en visite sur l'île de ") + GetConvertStr(attrLoc, "LocLables.txt") + " dans la ville de " + GetConvertStr(locations[cn].fastreload + " Town", "LocLables.txt") + ".";
						}
                    }
        			link.l1 = "Merci beaucoup !";
        			link.l1.go = "exit";
    			}
    			else
    			{
                    dialog.text = "Pourquoi devrais-je vous révéler un important secret d'וtat ? Qui me dit que vous n'êtes pas un espion ?";
        			link.l1 = "Non, pas du tout. Je vous prie de m'excuser.";
        			link.l1.go = "exit";
    			}
			}
		break;
		//---------------------------- генератор квестов мэра -------------------------------
		case "work":
            dialog.text = "C'est un bug, signalez-le à Eddie.";
        	link.l1 = "D'accord, l'ami !";
        	link.l1.go = "exit";
        	// boal квесты от ВМЛ -->
            if (CheckAttribute(pchar, "GenQuest.GhostShipDone_" + NPChar.id))
			{
				dialog.text = "L'ennemi est anéanti. La ville est sauvée ! Voici votre récompense.";
				link.l1 = "Fier de vous servir.";
				link.l1.go = "GhostShipDone";
				break;
			}
			if (CheckAttribute(NPChar, "from_sea") && Pchar.location.from_sea == NPChar.from_sea)
            {
    			if (!CheckAttribute(pchar, "GenQuest.GhostShip.LastBattle") &&
                     CheckAttribute(pchar, "GenQuest.GhostShip.NeedCoins")  &&
                    GetNpcQuestPastDayWOInit(npchar, "GhostShipHelp") > 30  &&
                    !CheckAttribute(pchar, "GenQuest.GhostShipWorkId")      &&
                    dRand(2) == 1)
                {
                    dialog.text = "Oui, " + GetAddress_Form(NPChar) + RandPhraseSimple("Dépêchez-vous, sauvez notre ville !! Des morts-vivants se battent contre les défenseurs dans le port. Je ne sais pas quoi faire !",
                                                       ", vous tombez à pic ! On m'informe qu'une bataille fait rage dans le port. Des pirates prennent la ville d'assaut. Aidez-nous à les anéantir.");
    				link.l1 = RandPhraseSimple("Difficile, mais possible !",
                                               "Oh ! Voilà une affaire qui me convient parfaitement !");
    				link.l1.go = "GhostShipHelp_1";
    				break;
                }
            }
            // boal квесты от ВМЛ <--
			//==> взят ли какой-либо квест
			if (CheckAttribute(pchar, "GenQuest.questName"))
			{
				//--> Федот, да не тот
				QuestName = pchar.GenQuest.questName;
				if (pchar.GenQuest.(QuestName).MayorId != npchar.id)
				{
					dialog.text = RandPhraseSimple("Si je ne m'abuse, vous avez déjà une mission du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.(QuestName).MayorId)].city+"Gen") + ". Tant que vous n'aurez pas accompli vos missions précédentes, je ne vous en confierai pas de nouvelles.",
						"Hum, n'avez-vous pas accepté à " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.(QuestName).MayorId)].city+"Voc") + " certaines missions du gouverneur de là-bas ? Oui, c'est bien ça ! Tant que vous n'aurez pas rempli vos obligations, je ne vous confierai rien de nouveau.");
					link.l1 = RandPhraseSimple("Je vois...", "J'ai compris, "+ GetAddress_FormToNPC(NPChar) + ".");
					link.l1.go = "exit";
					break;
				}
				//<--Федот, да не тот
				//-------- взят квест уничтожения банды ---------->>
				if (QuestName == "DestroyGang")
				{
					switch (pchar.GenQuest.DestroyGang)
					{
						makearef(arName, pchar.GenQuest.DestroyGang);
						case "":
							dialog.text = LinkRandPhrase("La mission de rechercher le bandit nommé " + GetFullName(arName) + " vous a déjà été confiée. Exécutez-la !",
								"Vous avez déjà pour mission de rechercher un bandit nommé " + GetFullName(arName) + ". J'attends des résultats !",
								"Pendant que vous vous prélassez ici, dans ma résidence, " + GetFullName(arName) + " dévalise nos colons ! Exécutez immédiatement la mission qui vous a été confiée !");
							link.l1 = RandPhraseSimple("D'accord, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour trouver et éliminer le bandit est écoulé. Et que croyez-vous qu'on me rapporte ? Je vais vous le dire : " + GetFullName(arName) + " est toujours bien vivant ! Veuillez vous expliquer, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais qui vous ont été accordés pour éliminer ce gredin nommé " + GetFullName(arName) + " sont écoulés. Pourtant, on m'informe qu'il n'y a aucun progrès. Que se passe-t-il ?");
							link.l1 = "J'ai échoué dans votre mission, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me dire ? Avez-vous réussi à éliminer ce bandit ? " + GetFullName(arName) + " est-il enfin mort ?", "Dites-moi juste une chose : " + GetFullName(arName) + " est-il mort ou vivant ?");
							link.l1 = "Malheureusement, il est vivant, " + GetAddress_FormToNPC(NPChar) + ". J'ai réussi à le trouver, mais le rapport de forces était inégal et j'ai dמ battre en retraite. Désolé, ce bandit est trop coriace pour moi.";
							link.l1.go = "All_Found";
						break;
						case "Execute":
							if (CheckAttribute(pchar,"Kamikazi") && pchar.Kamikazi == "Meet")
							{
								dialog.text = "Quoi ? Vous êtes encore en vie, capitaine ?";
								link.l1 = "Vous saviez donc qu'un squelette rכdait dans la jungle, capable de faire sauter quiconque le croisait ? Espèce de salaud !";
								link.l1.go = "All_Execute_1";
								pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
								AddCharacterExpToSkill(PChar, "Leadership", 500);
								AddCharacterExpToSkill(PChar, "Sneak", 500);
							}
							else
							{
								dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me dire ? Avez-vous réussi à éliminer ce bandit ? " + GetFullName(arName) + " est-il enfin mort ?", "Dites-moi juste une chose : " + GetFullName(arName) + " est-il mort ou vivant ?");
								link.l1 = "Il est mort, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "All_Execute";
								AddCharacterExpToSkill(PChar, "Leadership", 60);
								AddCharacterExpToSkill(PChar, "Sneak", 20);
							}

						break;
					}
				}
				//------ поиска шпиона ------------>>
				if (QuestName == "SeekSpy")
				{
					switch (pchar.GenQuest.SeekSpy)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu la mission de rechercher un espion ennemi en ville. Exécutez-la !",
								"Vous avez déjà pour mission de trouver un agent ennemi en ville. J'attends des résultats !",
								"Pendant que vous vous prélassez ici, dans ma résidence, un espion ennemi a découvert un nouveau secret d'וtat ! Commencez immédiatement les recherches !");
							link.l1 = RandPhraseSimple("D'accord, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
							link.l2 = "Je n'ai pas réussi à trouver l'espion, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l2.go = "All_Late";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour rechercher l'espion est écoulé. Et je comprends que vous n'avez aucun résultat.",
								"Tous les délais qui vous ont été accordés pour démasquer l'agent ennemi sont écoulés. Pourtant, on m'informe qu'il n'y a aucun progrès. Que se passe-t-il ?");
							link.l1 = "Je n'ai pas réussi à trouver l'espion, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Avez-vous réussi à trouver l'espion ?", "Dites-moi, avez-vous trouvé l'agent ennemi ?");
							link.l1 = "Oui, je l'ai trouvé et je l'ai tué. Il se cachait dans l'une des maisons de la ville.";
							link.l1.go = "All_Execute";
							pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
							AddCharacterExpToSkill(PChar, "Leadership", 60);
							AddCharacterExpToSkill(PChar, "Sneak", 20);
						break;
						case "FoundSpy":
							dialog.text = RandPhraseSimple("Alors, capitaine, je suppose que la personne à cכté de vous est celle que nous recherchions ?", "Oui, apparemment, je peux envoyer sans hésiter la personne à cכté de vous en prison. C'est bien l'agent ennemi que nous recherchons ?");
							link.l1 = "Oui, et il est devant vous. Une bête rusée, je vous le dis, j'ai eu du mal à le trouver...";
							link.l1.go = "All_Execute";
							sld = characterFromId("MayorQuestSpy");
							sld.lifeDay = 0;
							ChangeCharacterAddress(sld, "none", "");
							LAi_SetStayType(sld);
							sTemp = npchar.city + "_town";
							LocatorReloadEnterDisable(sTemp, "gate_back", false);
							LocatorReloadEnterDisable(sTemp, "reload1_back", false);
							LocatorReloadEnterDisable(sTemp, "reload2_back", false);
							AddCharacterExpToSkill(PChar, "Leadership", 60);
							AddCharacterExpToSkill(PChar, "Sneak", 20);
						break;
					}
				}
				//------ проникновение во враждебный город ------------>>
				if (QuestName == "Intelligence")
				{
					switch (pchar.GenQuest.Intelligence)
					{
						case "":
							if (GetQuestPastDayParam("GenQuest.Intelligence") > sti(pchar.GenQuest.Intelligence.Terms))
							{
								dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour livrer la lettre est écoulé. Et je comprends que vous n'avez aucun résultat.",
									"Tous les délais qui vous ont été accordés pour livrer la lettre sont écoulés. Pourtant, à ce que je comprends, il n'y a aucun progrès. Que se passe-t-il ?");
								link.l1 = "Je n'ai pas réussi à accomplir votre mission, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "All_Late";
							}
							else
							{
								dialog.text = LinkRandPhrase("Vous avez déjà reçu la mission de me livrer la lettre. Exécutez-la !",
									"Vous avez déjà pour mission de me livrer la lettre en personne. J'attends des résultats, il me faut cette lettre au plus vite !",
									"Pendant que vous traînez ici, dans ma résidence, les informations dont j'ai besoin sont toujours entre les mains de celui qui doit les envoyer ! Commencez immédiatement la mission, livrez-moi la lettre !");
								link.l1 = RandPhraseSimple("D'accord, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe tout de suite, "+ GetAddress_FormToNPC(NPChar) + ".");
								link.l1.go = "exit";
							}
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Avez-vous livré la lettre que j'attendais ?", "Dites-moi vite, avez-vous le pli ?!");
							link.l1 = "Oui, j'ai tout fait. Comme convenu, je vous le remets en main propre.";
							if (GetQuestPastDayParam("GenQuest.Intelligence") > sti(pchar.GenQuest.Intelligence.Terms))
							{
								link.l1.go = "Intelligence_ExecuteLate";
								AddCharacterExpToSkill(PChar, "Sneak", 200);
							}
							else
							{
								link.l1.go = "All_Execute";
								AddCharacterExpToSkill(PChar, "Leadership", 100);
								AddCharacterExpToSkill(PChar, "Sneak", 200);
							}
							pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
							TakeItemFromCharacter(pchar, "sicretLetter");
							DeleteAttribute(ItemsFromID("sicretLetter"), "City");
							DeleteAttribute(ItemsFromID("sicretLetter"), "Mayor");
						break;
					}
				}
				//------ уничтожение контры ------------>>
				if (QuestName == "KillSmugglers")
				{
					switch (pchar.GenQuest.KillSmugglers)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu la mission d'éliminer les contrebandiers. Exécutez-la !",
								"Vous avez déjà pour mission de trouver et d'éliminer les contrebandiers. J'attends des résultats !",
								"Pendant que vous vous prélassez ici, dans ma résidence, les contrebandiers ont fait entrer en ville un nouveau lot de marchandises ! Remplissez immédiatement vos obligations !");
							link.l1 = RandPhraseSimple("D'accord, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour éliminer les contrebandiers est écoulé. Et je comprends que vous n'avez aucun résultat.",
								"Tous les délais qui vous ont été accordés pour rechercher et éliminer les contrebandiers sont écoulés. Pourtant, on m'informe qu'il n'y a aucun progrès. Que se passe-t-il ?");
							link.l1 = "J'avoue ne pas avoir tenu les délais. C'est vrai, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Execute":
							int lngFileID = LanguageOpenFile("LocLables.txt");
							sTemp = LanguageConvertString(lngFileID, pchar.GenQuest.KillSmugglers.shoreId);
							dialog.text = RandPhraseSimple("Avez-vous réussi à enrayer la contrebande ?", "Dites-moi, avez-vous éliminé les contrebandiers ?");
							link.l1 = "Oui, je les ai rattrapés à l'endroit nommé " + sTemp + " et je les ai tous tués.";
							link.l1.go = "All_Execute";
							pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
							AddCharacterExpToSkill(PChar, "Leadership", 50);
							AddCharacterExpToSkill(PChar, SKILL_SNEAK, 100);
						break;
					}
				}
				if (QuestName == "TakePirateship")
				{
					switch (pchar.GenQuest.TakePirateship)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu l'ordre d'éliminer ce pirate. Exécutez-le !",
								"Vous avez déjà pour mission de détruire ce navire pirate. J'attends votre rapport !",
								"Pendant que vous paressez ici, dans ma résidence, cet ignoble pirate traque sa prochaine victime ! Acquittez-vous immédiatement de la tâche qui vous a été confiée !");
							link.l1 = RandPhraseSimple("Très bien, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour trouver et détruire le pirate est écoulé. Et que croyez-vous qu'on me rapporte ? Que cet ignoble pirate continue de piller nos navires ! J'exige une explication, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais qui vous ont été accordés pour détruire le navire pirate sont écoulés. Aucun résultat. Que s'est-il passé ?");
							link.l1 = "Je n'ai pas pu"+ GetSexPhrase("","") +" accomplir la mission dans le délai imparti, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me rapporter ? Avez-vous détruit le navire pirate ?", "Dites-moi juste une chose : cet ignoble pirate est-il au fond de la mer ?");
							link.l1 = "Malheureusement, non, " + GetAddress_FormToNPC(NPChar) + ". J'ai réussi à retrouver ce gredin, mais je n'ai pas pu couler son navire.";
							link.l1.go = "All_Found";
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me rapporter ? Avez-vous détruit le navire pirate ?", "Dites-moi juste une chose : cet ignoble pirate est-il au fond de la mer ?");
							link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ". Ce gredin ne troublera plus jamais les paisibles navires de nos marchands.";
							link.l1.go = "All_Execute";
							AddCharacterExpToSkill(PChar, "Leadership", 150);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 50);
						break;
					}
				}
				//------ найти пирата в море ------------>>
				if (QuestName == "DestroyPirate")
				{
					switch (pchar.GenQuest.DestroyPirate)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu la mission de rechercher le navire pirate. Exécutez-la !",
								"Vous avez déjà pour mission de rechercher et de détruire un navire pirate. J'attends des résultats !",
								"Pendant que vous vous prélassez ici, dans ma résidence, les pirates ont dévalisé un autre navire marchand ! Remplissez immédiatement vos obligations !");
							link.l1 = RandPhraseSimple("D'accord, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour trouver et détruire le pirate est écoulé. Et je comprends que vous n'avez aucun résultat.",
								"Tous les délais qui vous ont été accordés pour rechercher et détruire le navire pirate sont écoulés. Pourtant, on m'informe qu'il n'y a aucun progrès. Que se passe-t-il ?");
							link.l1 = "Je l'avoue, je n'ai pas réussi à trouver le navire dans le délai imparti. C'est vrai, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Dites-moi juste une chose : ce maudit pirate est-il mort ou vivant ?", "Dites-moi, ce maudit pirate est-il encore en vie ?");
							link.l1 = "Lui et son équipage sont morts, et son navire est par le fond, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Execute";
							pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
							AddCharacterExpToSkill(PChar, "Leadership", 50);
							AddCharacterExpToSkill(PChar, SKILL_FORTUNE, 50);
							AddCharacterExpToSkill(PChar, SKILL_SNEAK, 50);
							//здесь снимаем торговцев
							for (i=0; i<5; i++)
							{
								Group_DeleteGroup("MQGroupAll_" + i);
							}
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me dire ? Avez-vous réussi à accomplir la mission ? Ce misérable pirate est-il enfin mort ?", "Dites-moi juste une chose : ce pirate est-il mort ou vivant ?");
							link.l1 = "Malheureusement, il est vivant, " + GetAddress_FormToNPC(NPChar) + ". J'ai réussi à trouver le navire, mais le rapport de forces était inégal et j'ai dמ battre en retraite. Désolé, ce pirate est trop fort pour moi.";
							link.l1.go = "All_Found";
						break;
						case "PirateIsOut":
							dialog.text = RandPhraseSimple("On m'a informé que vous aviez rattrapé un pirate et que vous l'aviez combattu. Quels sont les résultats ?", "J'ai appris que vous aviez livré bataille à un navire dans les eaux environnantes. Alors, que s'est-il passé ?");
							link.l1 = "J'ai retrouvé un navire pirate, et nous avons engagé le combat. Mais malheureusement, " + GetAddress_FormToNPC(NPChar) + ", les pirates ont réussi à s'enfuir. J'en suis vraiment navré...";
							link.l1.go = "All_Found";
						break;
					}
				}
				if (QuestName == "TakePostcureer")
				{
					switch (pchar.GenQuest.TakePostcureer)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu l'ordre de vous emparer du navire courrier. Partez et exécutez-le !",
								"Vous avez déjà pour mission de capturer ce navire courrier. J'attends des résultats, pas des bavardages !",
								"Pendant que vous paressez ici, dans ma résidence, les documents dont j'ai besoin filent droit entre les mains de l'ennemi ! Accomplissez immédiatement votre mission !");
							link.l1 = RandPhraseSimple("Très bien, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour trouver et capturer le navire courrier est écoulé. Et que croyez-vous qu'on me rapporte ? Les documents que j'attendais sont tombés entre les mains de l'ennemi ! J'exige une explication, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais qui vous ont été accordés pour saisir les documents du navire courrier sont écoulés. Aucun résultat. Que s'est-il passé ?");
							link.l1 = "Je n'ai pas pu"+ GetSexPhrase("","") +" accomplir la mission dans le délai imparti, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me rapporter ? Vous êtes-vous emparé du paquet de documents ?", "Dites-moi juste une chose : avez-vous la correspondance ?");
							link.l1 = "Malheureusement, non, " + GetAddress_FormToNPC(NPChar) + ". J'ai réussi à retrouver le navire, mais je n'ai pas pu m'emparer des documents.";
							link.l1.go = "All_Found";
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Alors, qu'avez-vous à me rapporter ? Vous êtes-vous emparé du paquet de documents ?", "Dites-moi juste une chose : avez-vous la correspondance ?");
							link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ". Je suis prêt à vous la remettre. La voici.";
							link.l1.go = "All_Execute";
							AddCharacterExpToSkill(PChar, "Leadership", 100);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 50);
							RemoveItems(pchar, "sicretLetter", 1);
						break;
					}
				}
				if (QuestName == "TakeArsenalship")
				{
					switch (pchar.GenQuest.TakeArsenalship)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu l'ordre de détruire le transport de munitions. Partez et exécutez-le !", 
								"Vous avez déjà pour mission de couler ce transport militaire. J'attends des résultats, pas des bavardages !", 
								"Pendant que vous paressez ici, dans ma résidence, la poudre et les munitions filent droit vers les canons ennemis ! Accomplissez immédiatement votre mission !");
							link.l1 = RandPhraseSimple("Très bien, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";		
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps qui vous était accordé pour trouver et détruire le transport de munitions est écoulé. Et que me rapportent mes éclaireurs ? Le convoi ennemi est arrivé à bon port ! J'attends une explication, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais pour détruire le transport de munitions ennemi sont écoulés. Aucun résultat. Que s'est-il passé ?");
							link.l1 = "Je n'ai pas pu"+ GetSexPhrase("","") +" accomplir la mission dans le délai imparti, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";		
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, quelles nouvelles ? Avez-vous coulé le transport de munitions ennemi ?", "Dites-moi juste une chose : l'arsenal ennemi est-il au fond de la mer ?");
							link.l1 = "Malheureusement, non, " + GetAddress_FormToNPC(NPChar) + ". J'ai réussi à retrouver le convoi, mais je n'ai pas pu envoyer le navire visé par le fond.";
							link.l1.go = "All_Found";		
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Alors, quelles nouvelles ? Avez-vous coulé le transport de munitions ennemi ?", "Dites-moi juste une chose : l'arsenal ennemi est-il au fond de la mer ?");
							link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ". Leur poudre et leurs munitions n'arriveront jamais entre les mains de l'ennemi.";
							link.l1.go = "All_Execute";		
							AddCharacterExpToSkill(PChar, "Leadership", 120);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 50);
						break;
					}
				}
				//-------- ОЗГ - пассажир ---------->>
				if (QuestName == "TakePassenger")
				{
					switch (pchar.GenQuest.TakePassenger)
					{
						case "":
							dialog.text = LinkRandPhrase("Vous avez déjà reçu l'ordre de traquer le criminel. Partez !", 
								"Vous avez déjà pour mission de retrouver ce gredin. J'attends votre rapport !", 
								"Pendant que vous perdez votre temps ici, cet ignoble coquin navigue en toute liberté ! Exécutez immédiatement votre mission !");
							link.l1 = RandPhraseSimple("Comme vous voudrez, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'occupe de l'affaire, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";		
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps accordé pour retrouver ce gredin est écoulé. Et savez-vous ce qu'on me rapporte ? Il a atteint sa destination sans encombre et il a disparu ! J'attends une explication, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais pour retrouver le criminel sont écoulés. Aucun résultat. Qu'est-ce que cela signifie ?");
							link.l1 = "Je n'ai pas réussi"+ GetSexPhrase("","") +" à accomplir votre mission dans le délai imparti, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";		
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, qu'en dites-vous ? Avez-vous capturé le scélérat ?", "Dites-moi juste une chose : ce misérable gredin est-il aux fers dans votre cale ?");
							link.l1 = "Malheureusement, non, " + GetAddress_FormToNPC(NPChar) + ". Je n'ai pas pu prendre ce coquin vivant. Il a sombré avec le navire à bord duquel il se trouvait.";
							link.l1.go = "All_Found";		
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Alors, qu'en dites-vous ? Avez-vous capturé le scélérat ?", "Dites-moi juste une chose : ce misérable gredin est-il aux fers dans votre cale ?");
							link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ". Envoyez vos soldats sur le quai, et je vous le livre à terre immédiatement.";
							link.l1.go = "All_Execute";		
							AddCharacterExpToSkill(PChar, "Leadership", 150);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 100);
							sld = &Characters[sti(Pchar.GenQuest.TakePassenger.PrisonerIDX)];
							ReleasePrisoner(sld); //освободили пленника
							sld.lifeday = 0;
						break;
					}
				}
				//-------- таможенный патруль ---------->>
				if (QuestName == "CustomPatrol")
				{
					switch (pchar.GenQuest.CustomPatrol)
					{
						case "":
							dialog.text = LinkRandPhrase("La mission de traquer les contrebandiers vous a déjà été confiée. Exécutez-la !", 
								"Vous avez déjà pour mission d'intercepter les contrebandiers. J'attends les résultats !", 
								"Pendant que vous vous prélassez ici, dans la résidence, ces contrebandiers préparent tranquillement leur marché ! Faites votre devoir immédiatement !");
							link.l1 = RandPhraseSimple("Très bien, " + GetAddress_FormToNPC(NPChar) + ".", "J'y travaille, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";		
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps accordé pour trouver les contrebandiers est écoulé. Et quelles nouvelles reçois-je ? Ils ont réussi à décharger leur cargaison ! Expliquez-vous, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais pour traquer les contrebandiers sont écoulés. Aucun résultat. Quelle est votre excuse ?");
							link.l1 = "Je n'ai pas pu"+ GetSexPhrase("","") +" à accomplir votre mission à temps, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";		
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors ? Vous êtes-vous occupé des contrebandiers ?", "Dites-moi juste une chose : le marché des contrebandiers a-t-il été déjoué ?");
							link.l1 = "Hélas, non, " + GetAddress_FormToNPC(NPChar) + ". Je n'ai pas pu arrêter ces gredins.";
							link.l1.go = "All_Found";		
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Alors ? Vous êtes-vous occupé des contrebandiers ?", "Dites-moi juste une chose : le marché des contrebandiers a-t-il été déjoué ?");
							link.l1 = "En effet, " + GetAddress_FormToNPC(NPChar) + ". J'ai intercepté leurs navires et je les ai envoyés tous les deux par le fond, le vendeur comme l'acheteur.";
							link.l1.go = "All_Execute";		
							AddCharacterExpToSkill(PChar, "Leadership", 100);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 200);
						break;
					}
				}
				//-------- Дезертир ---------->>
				if (QuestName == "FindFugitive")
				{
					switch (pchar.GenQuest.FindFugitive)
					{
						case "":
							dialog.text = LinkRandPhrase("Vos ordres pour retrouver le déserteur ont déjà été donnés. Exécutez-les !", 
								"Vous avez déjà pour mission de retrouver le déserteur. J'attends des résultats !", 
								"Pendant que vous paressez ici, ce déserteur est peut-être en train de vendre des secrets d'וtat ! Poursuivez immédiatement vos recherches !");
							link.l1 = RandPhraseSimple("Bien sמr, " + GetAddress_FormToNPC(NPChar) + ".", "Je m'en occupe, "+ GetAddress_FormToNPC(NPChar) + ".");
							link.l1.go = "exit";		
						break;
						case "Late":
							dialog.text = RandPhraseSimple("Le temps accordé pour les recherches est écoulé. Et quelles nouvelles ai-je ? Aucune ! Expliquez-vous, " + GetAddress_Form(NPChar) + ".",
								"Tous les délais pour retrouver le déserteur sont écoulés. Aucun résultat. Pourquoi avez-vous échoué ?");
							link.l1 = "Je n'ai pas pu"+ GetSexPhrase("","") +" à accomplir la mission dans le délai imparti, " + GetAddress_FormToNPC(NPChar) + ".";
							link.l1.go = "All_Late";		
						break;
						case "Found":
							dialog.text = RandPhraseSimple("Alors, quelles nouvelles ? Avez-vous capturé le déserteur ?", "Dites-moi juste une chose : ce fuyard est-il aux fers dans votre cale ?");
							link.l1 = "Malheureusement, non, " + GetAddress_FormToNPC(NPChar) + ". Je n'ai pas réussi à m'emparer de ce gredin. J'ai retrouvé sa trace à "+XI_ConvertString("Colony"+pchar.GenQuest.FindFugitive.City)+", mais un jour à peine avant mon arrivée, il s'est enfui sur un navire pirate vers une destination inconnue. Je crains qu'il n'ait rejoint les Frères de la Cכte...";
							link.l1.go = "All_Found";		
						break;
						case "Execute":
							dialog.text = RandPhraseSimple("Ah ah... voici donc notre "+pchar.GenQuest.FindFugitive.Name+"... Excellent travail, capitaine ! La chasse a-t-elle été difficile ?", "Oh, voyez donc quels invités nous avons ! Bonjour à vous, "+pchar.GenQuest.FindFugitive.Name+" ! Splendide travail, capitaine ! Les recherches vous ont-elles beaucoup épuisé ?");
							link.l1 = "Difficile à dire, " + GetAddress_FormToNPC(NPChar) + ". Quoi qu'il en soit, j'ai rempli votre mission.";
							link.l1.go = "All_Execute";		
							AddCharacterExpToSkill(PChar, "Leadership", 200);
							AddCharacterExpToSkill(PChar, "Fortune", 200);
							AddCharacterExpToSkill(PChar, "Sneak", 100);
							sld = &Characters[sti(Pchar.GenQuest.FindFugitive.PrisonerIDX)];
							ReleasePrisoner(sld); //освободили пленника
							LAi_SetActorType(sld);
							sld.lifeday = 0;
							pchar.quest.FindFugitive_Over.over = "yes"; //снимаем таймер
							chrDisableReloadToLocation = false;//открыть локацию
						break;
					}
				}
				//<<------ взятые квесты ------------
				break;
			}
			if (!CheckAttribute(npchar, "work_date") || GetNpcQuestPastDayParam(npchar, "work_date") > 2 || bBettaTestMode)
    		{
				SaveCurrentNpcQuestDateParam(npchar, "work_date");
				if (rand(10) > 9 && !bBettaTestMode)             // WW     с 20 процентов до 10 процентов   просто посылание  уменьшил
				{
					dialog.text = LinkRandPhrase("Je n'ai pas de travail pour vous en ce moment. Revenez demain, ou plus tard...",
						"Je n'ai pas de mission pour vous aujourd'hui. Revenez plus tard, dans un jour ou deux.",
						"Il n'y a rien aujourd'hui que je puisse vous confier. Je serai heureux de vous voir un autre jour.");
					link.l1 = "J'ai compris, " + GetAddress_FormToNPC(NPChar) + ".";
					link.l1.go = "exit";
				}
				else
				{
						if (npchar.city == "Panama") i = drand(6);
						else i = dRand(7);
                    //}
                    // boal <--
					switch (i)
					{
						//========== квест уничтожения банды ============
						case 0:
							pchar.GenQuest.DestroyGang.Terms = dRand(2) + 2; //сроки выполнения задания
							pchar.GenQuest.DestroyGang.Money = ((dRand(8) + 2) * 170) + (sti(pchar.rank) * 200 + 2000); //вознаграждение
							makearef(arName, pchar.GenQuest.DestroyGang);
							arName.nation = PIRATE;
							arName.sex = "man";
							SetRandomNameToCharacter(arName); //имя бандита в структуру квеста
							dialog.text = "J'ai justement une mission pour vous. Dans la jungle près de " + XI_ConvertString("Colony"+npchar.city+"Gen") + " une bande de brigands est apparue, et je sais que leur chef est un certain " + GetFullName(arName) + ". Trouvez et éliminez cette bande de brigands.";
							link.l1 = "Ai-je un délai à respecter ?";
							link.l1.go = "DestroyGang";
						break;
						//========== розыска лазутчика ============
						case 1:
							pchar.GenQuest.SeekSpy.Terms = dRand(2) + 3; //сроки выполнения задания
							pchar.GenQuest.SeekSpy.Money = ((dRand(8) + 2) * 150) + (sti(pchar.rank) * 200 + 2000); //вознаграждение
							dialog.text = "Oui, j'ai maintenant une mission de confiance pour vous. J'ai appris que se cachait à " + XI_ConvertString("Colony"+npchar.city+"Voc") + " un espion ennemi. Vous devez le trouver.";
							link.l1 = "Dites-moi, " + GetAddress_FormToNPC(NPChar) + ", l'information que vous avez reçue est-elle fiable ?";
							link.l1.go = "SeekSpy";
						break;
						//========== пробраться во вражеский город ============
						case 2:
							sTemp = GetSpyColony(npchar); //враждебная колония
							if (sTemp == "none")
							{
								dialog.text = LinkRandPhrase("Je n'ai pas de travail pour vous en ce moment. Revenez demain, ou plus tard...",
									"Je n'ai pas de mission pour vous aujourd'hui. Revenez plus tard, dans un jour ou deux.",
									"Il n'y a rien aujourd'hui que je puisse vous confier. Je serai heureux de vous voir un autre jour.");
								link.l1 = "J'ai compris, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "exit";
							}
							else
							{
								pchar.GenQuest.Intelligence.Terms = dRand(10) + (42 - MOD_SKILL_ENEMY_RATE*3); //сроки выполнения задания
								pchar.GenQuest.Intelligence.Money = ((dRand(4) + 6) * 1000) + (sti(pchar.rank) * 1000 + 10000); //вознаграждение
								pchar.GenQuest.Intelligence.City = sTemp;
								sTemp = ", sur l'île de " + XI_ConvertString(colonies[FindColony(pchar.GenQuest.Intelligence.City)].islandLable+"Voc");
								dialog.text = "J'ai pour vous une mission qui comporte de sérieux risques. Il faut que vous vous rendiez à " + XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Acc") + sTemp + ", que vous y rencontriez la personne indiquée et que vous me rapportiez ce qu'elle vous remettra.";
								link.l1 = "Euh, je ne dirais pas qu'à " + XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Voc") + " on sera ravi de me voir...";
								link.l1.go = "Intelligence";
							}
						break;
						//========== ОЗГ - охотник на пирата ============
						case 3:
							dialog.text = "En effet, j'ai pour vous une mission de la plus haute importance, qui mettra à l'épreuve tous vos talents de marin. Elle concerne la racaille pirate...";
							link.l1 = "Des pirates ? Puis-je connaître le détail de ce qu'on attend de moi ?";
							link.l1.go = "TakePirateship";
						break;	
						//========== контркурьер - отобрать почту ============
						case 4:
							pchar.GenQuest.TakePostcureer.City = SelectEnemyColony(npchar, &enemyNation, &city2, &enemyNation);
							if (pchar.GenQuest.TakePostcureer.City == "none")
							{
								dialog.text = LinkRandPhrase("Je n'ai pas de travail pour vous en ce moment. Revenez demain, ou plus tard...",
									"Je n'ai pas de mission pour vous aujourd'hui. Revenez plus tard, dans un jour ou deux.",
									"Il n'y a rien aujourd'hui que je puisse vous confier. Je serai heureux de vous voir un autre jour.");
								link.l1 = "J'ai compris, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "exit";
							}
							else
							{
								pchar.GenQuest.TakePostcureer.CityA = city2;
								pchar.GenQuest.TakePostcureer.Nation = enemyNation;
								dialog.text = "Oui, j'ai une mission qui exige la plus grande célérité ainsi qu'un vrai talent tactique au combat naval. זtes-vous prêt à faire vos preuves ?";
								link.l1 = "Votre Excellence, pourriez-vous préciser la nature de cette mission ?";
								link.l1.go = "TakePostcureer";
							}
						break;
						//========== контрфрахт - потопить корабль с боеприпасами ============
						case 5:
							pchar.GenQuest.TakeArsenalship.City = SelectEnemyColony(npchar, &enemyNation, &city2, &enemyNation);
							if (pchar.GenQuest.TakeArsenalship.City == "none")
							{
								dialog.text = LinkRandPhrase("Je n'ai pas de travail pour vous en ce moment. Revenez demain, ou plus tard...",
									"Je n'ai pas de mission pour vous aujourd'hui. Revenez plus tard, dans un jour ou deux.",
									"Il n'y a rien aujourd'hui que je puisse vous confier. Je serai heureux de vous voir un autre jour.");
								link.l1 = "J'ai compris, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "exit";
							}
							else
							{
								pchar.GenQuest.TakeArsenalship.CityA = city2;
								pchar.GenQuest.TakeArsenalship.Nation = enemyNation;//вражеская нация
								dialog.text = "En effet, j'ai une tâche qui exige un courage extraordinaire et une main de maître au combat naval. Vous sentez-vous prêt à vous distinguer ?";
								link.l1 = "Votre Excellence, pourriez-vous préciser la nature de cette mission ?";
								link.l1.go = "TakeArsenalship";
							}
						break;
						//========== ОЗГ - охотник на пассажира ============
						case 6:
							pchar.GenQuest.TakePassenger.City = SelectEnemyColony(npchar, &enemyNation, &city2, &enemyNation);
							if (pchar.GenQuest.TakePassenger.City == "none")
							{
								dialog.text = LinkRandPhrase("Je n'ai pas de travail pour vous en ce moment. Revenez demain, ou plus tard...",
									"Je n'ai pas de mission pour vous aujourd'hui. Revenez plus tard, dans un jour ou deux.",
									"Il n'y a rien aujourd'hui que je puisse vous confier. Je serai heureux de vous voir un autre jour.");
								link.l1 = "J'ai compris, " + GetAddress_FormToNPC(NPChar) + ".";
								link.l1.go = "exit";
							}
							else
							{
								pchar.GenQuest.TakePassenger.CityA = city2;
								pchar.GenQuest.TakePassenger.Nation = enemyNation;
								dialog.text = "Vous tombez à point nommé, monsieur. J'ai une affaire urgente que je crois pouvoir remettre entre vos mains. Il s'agit de poursuivre et de capturer un certain individu...";
								link.l1 = "Une chasse à l'homme ? Dites-m'en plus, je vous prie, sur ce que cette mission implique.";
								link.l1.go = "TakePassenger";
							}
						break;
						//========== замочить пирата, что грабит суда ============
						case 7:
							//--> генерим ранг
							iRank = GetQuestEnemyRank();
							//<-- генерим ранг
							LAi_group_Delete("MayorPirateGroup");
							sld = GetCharacter(NPC_GenerateCharacter("MQPirate", "", "man", "man", iRank, sti(npchar.nation), -1, true));
							SetCaptanModelByEncType(sld, "pirate");
							DeleteAttribute(sld, "Ship");
							SetShipToFantom(sld, "pirate", false);
							sld.Ship.Mode = "Pirate";
							//sld.ShipTaskLock = true; //лочим таск
							sld.dialog.filename = "MayorQuests_dialog.c";
							sld.dialog.currentnode = "DestroyPirate_Abordage";
							sld.DeckDialogNode = "DestroyPirate_Deck";
							sld.DontRansackCaptain = true;
							sld.DontCheckFlag = true;  // не проверять флаг ГГ
							sld.SaveItemsForDead = true; // сохранять на трупе вещи
							sld.DontClearDead = true; // не убирать труп через 200с
							sld.AlwaysSandbankManeuver = true;
							sld.WatchFort = true; //видеть форты
							sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
							sld.greeting = "pirat_common";
							LAi_group_MoveCharacter(sld, "MayorPirateGroup");
							dialog.text = "Oui, j'ai une mission pour vous. Le fait est que dans les eaux proches de " + XI_ConvertString("Colony"+npchar.city+"Gen") + " un navire pirate est apparu. Plusieurs navires marchands ont déjà été dévalisés. Le plus curieux, c'est que les victimes ne peuvent rien dire, ni du navire pirate ni de son capitaine. Elles ont peur, je suppose...";
							link.l1 = "Et que dois-je faire, " + GetAddress_FormToNPC(NPChar) + " ?";
							link.l1.go = "DestroyPirate";
						break;
					}
				}
			}
			else
			{
				dialog.text = LinkRandPhrase("Aujourd'hui, je ne peux plus rien vous proposer comme travail.", "Aujourd'hui, il n'y a plus de travail pour vous.", "C'est tout pour aujourd'hui, il n'y a plus de travail. Toutes les questions de travail, c'est pour demain.");
				link.l1 = RandPhraseSimple("Hélas...", "Hélas, "+ GetAddress_FormToNPC(NPChar) + ". ");
        		link.l1.go = "exit";
			}
		//---------------------------- генератор квестов мэра -------------------------------
		break;

		case "Patent_Doubt":
			dialog.text = "Joli boniment... Je devrais vous faire pendre rien que pour votre impertinence. On ne peut pas se fier à des pirates aussi notoires, mais les temps sont durs dans notre archipel et toute aide sera utile. Soit, je vais vous signer une lettre de marque,";
			link.l1 = "Vous ne le regretterez pas, " + GetAddress_FormToNPC(NPChar) + " !";
			link.l1.go = "Patent_Give";
			link.l2 = "Ha ! Vous y avez cru ! C'était une plaisanterie, je ne veux rien avoir à faire avec votre וtat de rien du tout.";
			link.l2.go = "arest_3";
		break;
		case "Patent_Give":
            pchar.PatentNation = NationShortName(sti(NPChar.nation));
            pchar.PatentPrice = 0;
			dialog.text = "Je vous en prie, j'espère que nous continuerons à collaborer. Vous pouvez maintenant rendre visite à notre gouverneur général. Il aura peut-être des missions plus importantes pour vous.";
			link.l1 = "Merci. Au revoir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			AddDialogExitQuest("any_patent_take");
			ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", -100);
		break;

		case "sell_prisoner":
            dialog.text = "Qui voulez-vous libérer contre rançon ?";

            qty = 1;
            for(i=0; i < GetPassengersQuantity(pchar); i++)
            {
                cn = GetPassenger(pchar,i);
                if(cn != -1)
                {
                    offref = GetCharacter(cn);
                    if(CheckAttribute(offref,"prisoned"))
                    {
        	            if(sti(offref.prisoned)==true && GetRemovable(offref)) // ставим только фантомов
        	            {
                            attrLoc = "l"+qty;
                            link.(attrLoc)    = GetFullName(offref) + " - " + NationNameMan(sti(offref.nation)) + ".";
                            link.(attrLoc).go = "GetPrisonerIdx_" + offref.index;
                            qty++;
                        }
                    }
                }
            }
			link.l99 = "Personne.";
			link.l99.go = "exit";
		break;

		case "sell_prisoner_2":
            offref = GetCharacter(sti(pchar.GenQuest.GetPrisonerIdx));
            attrLoc =  "Bien, il y a le capitaine " + GetFullName(offref) + ", " + NationNameMan(sti(offref.nation))+ ".";
            // цена зависит от губернатора
            qty = makeint(sti(offref.rank)*(800 + GetCharacterSPECIALSimple(NPChar, SPECIAL_L)*100) + GetCharacterSkillToOld(offref, "Leadership")*500 + GetCharacterSkillToOld(pchar, "commerce")*500);
            if (sti(offref.nation) == sti(NPChar.nation))
            {
                attrLoc = attrLoc + " Je suis prêt à racheter mon compatriote pour " + FindRussianMoneyString(qty) + ".";
            }
            else
            {
                if (sti(offref.nation) == PIRATE)
                {
                    qty = qty / 5;
                    attrLoc = attrLoc + " Je peux donner " + FindRussianMoneyString(qty) + " pour ce gibier de potence. Et nous exécuterons aussitכt ce scélérat.";
                    /*if (CheckAttribute(NPChar, "from_sea"))
                    {
                        link.l2 = "Execute? Can I look at it?";
			            link.l2.go = "sell_prisoner_DeathExec";
			        } */
                }
                else
                {
                    qty = qty / 2;
                    attrLoc = attrLoc + " Pour cet homme, je ne peux pas payer plus de " + FindRussianMoneyString(qty) + ".";
                }
            }
			dialog.text = attrLoc;
			pchar.PrisonerSellPrice =  qty;
			link.l1 = "Marché conclu, il est à vous, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "sell_prisoner_3";
			link.l3 = "Non. דa ne me convient pas.";
			link.l3.go = "exit";
		break;
		case "sell_prisoner_3":
			dialog.text = "Voilà qui est bien.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			OfficersReaction("bad");

			offref = GetCharacter(sti(pchar.GenQuest.GetPrisonerIdx));
			AddMoneyToCharacter(pchar, sti(pchar.PrisonerSellPrice));
			if (sti(offref.nation) == sti(NPChar.nation))
            {
                AddCharacterExpToSkill(pchar, "Commerce", 25);
            }
            else
            {
                if (sti(offref.nation) == PIRATE)
                {
                    ChangeCharacterReputation(pchar, -2);
                }
                else
                {
                    AddCharacterExpToSkill(pchar, "Commerce", 5);
                }
            }

        	offref.location = "";
        	ReleasePrisoner(offref); // освободили пленника
		break;
		////   CAPTURE //////////
		case "CAPTURE_Main":
            NextDiag.TempNode = "CAPTURE_Main";
			AfterTownBattle();  // все, все свободны

            // fix от грабежа 5 раз на дню -->
            if (!CheckNPCQuestDate(npchar, "GrabbingTownDate"))
			{
                dialog.Text = "Vous avez déjà tout pris. Que vous faut-il de plus ?";
                Link.l1 = "Oui, c'est vrai, je me suis trompé de ville.";
                Link.l1.go = "Exit_City";

                NPChar.NoGiveMoney = true;

            	ChangeCharacterHunterScore(GetMainCharacter(), NationShortName(sti(NPChar.nation)) + "hunter", 20);
                // вернём диалог после разговора и спрячем
                SetReturn_Gover_Dialog_Exit(NPChar);
				break;
			}
			SetNPCQuestDate(npchar, "GrabbingTownDate");
			// fix от грабежа 5 раз на дню <--

            if (CheckAttribute(FortChref, "Fort.Mode") && sti(FortChref.Fort.Mode) != FORT_DEAD)
            { // а форт-то ЖИВ, значит с суши прошли
                dialog.Text = "Quelle impudence inouïe ! Les renforts du fort vont bientכt arriver, et vous aurez des ennuis !";
                Link.l2 = "Je n'ai pas l'intention de traîner ici jusqu'à leur arrivée. Payez-moi et nous quitterons cette ville.";
                Link.l2.go = "Summ";
                Pchar.HalfOfPaymentByCity = true; // токо половина денег
            }
            else
            {
				dialog.Text = "Cette fois, vous l'avez prise, mais sachez que notre escadre va bientכt arriver, et il ne restera rien de vous.";
				if(npchar.id == "Santiago_mayor" && CheckAttribute(pchar, "PGGWhisperLetterSent"))
				{
					dialog.Text = GetFullName(pchar) + " ! J'aurais dמ me douter que votre nouvelle n'était qu'une ruse pour désarmer ma ville. Et je vous ai cru comme un enfant naïf. " + dialog.Text;

				}
	            if (!bWorldAlivePause || bBettaTestMode)
	            {
	                int iColony = FindColony(npchar.city);
					if (!CheckAttribute(&colonies[iColony], "notCaptured")) //незахватываемые города
					{
						if (CheckAttribute(FortChref, "Default.Prison"))
	    				{
	    					Link.l1 = "Cause toujours ! Cette ville m'appartient désormais, et j'enverrai ton escadre rendre visite au diable des mers. Hé, les gars, prenez ce cochon et jetez-le en prison.";
	    				}
	    				else
	    				{
	    					Link.l1 = "Cette ville m'appartient désormais, et je déciderai moi-même comment la protéger. Hé, les gars, mettez ce parvenu dehors.";
	    				}
	    				Link.l1.go = "City";
					}
				}
				if (!isCityHasFort(NPChar.City))
	            {
	                Link.l2 = "L'escadre de débarquement ? Hum... payez-moi et nous quitterons cette ville.";
				}
				else
				{
	            	Link.l2 = "L'escadre... Hum.. Payez-moi et nous quitterons cette ville.";
	            }
				Link.l2.go = "Summ";

                bOk = !bWorldAlivePause || bBettaTestMode;
	            if (isMainCharacterPatented() && bOk && !CheckAttribute(&colonies[iColony], "notCaptured")) //не даём захватить колонию
	            {
					// восстановим нацию патента
					PChar.nation = GetBaseHeroNation();

					dialog.Text = "C'est une audace inouïe ! Comment osez-vous attaquer une colonie appartenant à " + NationNameGenitive(sti(NPChar.nation)) + " ?! Vous paierez cher le sang que vous avez versé sans raison et les dommages causés à notre pays.";
	                Link.l1 = "Désormais, la colonie m'appartient, et si quelqu'un essaie d'en douter, il ira droit au paradis.";
	                Link.l1.go = "City_patent";
	                Link.l2 = "Je représente les intérêts de " + NationNameGenitive(sti(PChar.nation)) + " et je déclare officiellement que cette colonie appartient désormais à " + NationKingsCrown(PChar) + " !";
	                Link.l2.go = "City_nation";
	                Link.l3 = "Nous devrions discuter du montant de la rançon. Si vous vous entêtez, nous réduirons votre charmante ville en cendres, et nous vous pendrons sur la place publique.";
	                Link.l3.go = "Summ_patent";
	            }
            }
        break;

        case "City":
            ChangeCharacterHunterScore(GetMainCharacter(), NationShortName(sti(NPChar.nation)) + "hunter", 40);
            AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 300);

            Pchar.GenQuestFort.fortCharacterIdx = FortChref.index;
            AddDialogExitQuest("Residence_Captured_Any");

            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
            // ремонт
            RepairAllShips();
            Log_Info("Tous les navires ont été réparés.");
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
	        AddQuestRecord("Gen_CityCapture", "t3");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + NPChar.City));
			//  СЖ <--
            NextDiag.CurrentNode = "Prison";
			DialogExit();
        break;

        case "City_patent":
            ChangeCharacterReputation(GetMainCharacter(), -20); // пираты мы, но у нас патент
            dialog.Text = "Cette fois, vous l'avez prise, mais sachez que notre escadre va bientכt arriver, et il ne restera rien de vous.";
			Link.l1 = "Cause toujours ! Cette colonie m'appartient désormais, et j'enverrai ton escadre rendre visite au diable des mers. Hé, les gars, prenez ce cochon et jetez-le en prison.";
			Link.l1.go = "City";
        break;

        case "Exit_for_pay":
			dialog.Text = "Que voulez-vous encore de moi ?";
            Link.l1 = "Je vérifie si j'ai bien tout pris...";
            Link.l1.go = "exit";

            NextDiag.TempNode = "Exit_for_pay";
		break;

        case "Exit_City":
		    NextDiag.CurrentNode = "Exit_for_pay";
		    Pchar.GenQuestFort.fortCharacterIdx = FortChref.index;
		    if (sti(NPChar.NoGiveMoney) == false) // себе берём
		    {
				// вернём диалог после разговора и спрячем
				SetReturn_Gover_Dialog_Exit(NPChar);
				AddDialogExitQuestFunction("TWN_ExitForPay");
            }
            DialogExit();
        break;

        case "Summ":
            dialog.Text = "Je n'ai pas d'autre choix que d'accepter vos conditions. Prenez votre argent du sang et quittez immédiatement les eaux de notre colonie.";
            Link.l1 = "Permettez-moi de prendre congé.";
            Link.l1.go = "Exit_City";
            NPChar.NoGiveMoney = false;

            ChangeCharacterHunterScore(GetMainCharacter(), NationShortName(sti(NPChar.nation)) + "hunter", 30);
            AddCharacterExpToSkill(GetMainCharacter(), SKILL_FORTUNE, 200);
            AddCharacterExpToSkill(GetMainCharacter(), "Commerce", 200);

            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_GrabbingTown", 1);
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
	        AddQuestRecord("Gen_CityCapture", "t2");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + NPChar.City));
			//  СЖ <--
        break;

        case "Summ_patent":
            dialog.Text = "Bien, vous pouvez dicter vos conditions...";
            Link.l1 = "Oui, par le droit du vainqueur. Oם est mon argent ?";
            Link.l1.go = "Summ";
            ChangeCharacterReputation(GetMainCharacter(), -10); // не на службе
        break;

        case "City_nation":
			dialog.Text = "Eh bien, nous sommes à la merci des vainqueurs.";
			Link.l1 = "Je vous conseille de quitter la ville au plus vite, on ne sait pas encore comment les changements à venir affecteront votre santé. Au revoir.";
			Link.l1.go = "Exit_City";
			NPChar.NoGiveMoney = true;

            ChangeCharacterReputation(GetMainCharacter(), 5);
            AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 500);
            AddCharacterExpToSkill(GetMainCharacter(), "Sneak", 300);
            SetNationRelationBoth(sti(PChar.nation), sti(NPChar.nation), RELATION_ENEMY);

            PChar.questTemp.DontSetNewDialogToMayor = true; // иначе может сменить диалог и сбойнуть
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(NPChar.City, sti(PChar.nation));
            DeleteAttribute(PChar, "questTemp.DontSetNewDialogToMayor");
            AddDialogExitQuestFunction("LaunchColonyInfoScreen"); // табличка
            //  СЖ -->
	    	sTemp =  GetNationNameByType(sti(PChar.nation));
			ReOpenQuestHeader("Gen_CityCapture");
	        AddQuestRecord("Gen_CityCapture", "t1");
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + NPChar.City));
			AddQuestUserData("Gen_CityCapture", "sNation", XI_ConvertString(sTemp + "Gen"));
			//  СЖ <--
			AddTitleNextRate(sti(PChar.nation), 1);  // счётчик звания
            SetCharacterRelationBoth(sti(FortChref.index), GetMainCharacterIndex(), RELATION_FRIEND);// нечего не даёт, тк работает OtherChar - а это губер, но он и так друг
            UpdateRelations();

            // 22.03.05  fix вернём диалог после разговора и спрячем
            //  внутри диалога не работало
            SetReturn_Gover_Dialog_Exit(NPChar);

			/*   to_do
            ref rFortCh = FindSiegeFortCommander();
            if (rFortCh.id == FortChref.id)//это и есть форт обложенный эскадрой
            {
                if (sti(Characters[GetCharacterIndex("NatCapitan_1")].nation) == sti(rFortCh.nation)) //они этой же нации
                {
                    AddDialogExitQuest("CheckFortsEndSiege_02");
                }
            }
			  */
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
	    break;

	    case "Prison":
			dialog.Text = "Que voulez-vous encore de moi, gredin ?";
			/*Link.l1 = "Don't be impertinent to me, you fat brute.";
			Link.l1.go = "Strike";
			if (!CheckAttribute(NPChar, "NotHaveFort"))
			{
			    Link.l2 = "For resisting earlier, I decided to shoot you.";
			    Link.l2.go = "Death_Execution_1";
            }       */
            Link.l3 = "Je voulais voir comment allait Votre Excellence. Bon, maintenant, je dois y aller !";
            Link.l3.go = "exit";
            NextDiag.TempNode = "Prison";
		break;

		case "arestFree_1":
			dialog.text = "S'arranger ? Comment voyez-vous la chose ?";
            link.l1 = "Je pense que " + ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0) * 6000 + " piastres pourraient me sauver ?";
			link.l1.go = "arestFree_2";
			link.l2 = "Pas question, je dois y aller. Bonne journée.";
			link.l2.go = "arest_1";
		break;

		case "arestFree_2":
            if (GetCharacterSkillToOld(PChar, SKILL_FORTUNE) >= rand(7))
            {
    			dialog.text = "Nous pourrions peut-être régler notre différend de cette façon.";
    		    link.l1 = "Parfait !";
    		    link.l1.go = "Exit";
				int iTemp = ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0);
    		    AddMoneyToCharacter(pchar, -iTemp * 6000);
    		    ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", -iTemp);//За сколько заплатили, столько и снижаем. Ровно до нуля. 
    		    AddCharacterExpToSkill(pchar, SKILL_FORTUNE, 100);
            }
            else
            {
    			dialog.text = "Non ! Il n'y a qu'une seule façon d'expier vos méfaits. Gardes ! Emmenez "+ GetSexPhrase("lui", "elle") +" au fort.";
    		    link.l1 = "Attendez !";


    		    link.l1.go = "arest_2";
    		    AddCharacterExpToSkill(pchar, SKILL_FORTUNE, 10);
            }
		break;

		case "arest_1":
			dialog.text = "Bien sמr qu'il est temps, on va vous escorter. Gardes ! Emmenez "+ GetSexPhrase("lui", "elle") +" !";
		    //link.l1 = "Wait!";
		    //link.l1.go = "arest_2";
		    link.l1 = "Ah non, pas question !";
		    link.l1.go = "fight";
		break;

		case "arest_2":
			dialog.text = "Il fallait y penser avant ! Gardes !";
			link.l1 = "Ah non ! Vous ne m'aurez pas comme ça !";
		    link.l1.go = "fight";
/*
            Pchar.GenQuest.Death_Execution_location = NPChar.from_sea;
            DialogExit();
			NextDiag.CurrentNode = "First time";

			DeathExecutionStart(Pchar, sti(NPChar.nation));
*/
		break;

		case "arest_3":
			dialog.text = "Gardes ! Après "+ GetSexPhrase("lui", "elle") +" !";
			link.l1 = "Ah non ! Vous ne m'aurez pas comme ça !";
		    link.l1.go = "fight";
/*
*/
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Контрфрахт - уничтожить корабль с арсеналом
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "TakeArsenalship":

			pchar.GenQuest.questName = "TakeArsenalship"; //тип квеста
			pchar.GenQuest.TakeArsenalship.Terms1 = GetMaxDaysFromIsland2Island(Islands[GetCharacterCurrentIsland(PChar)].id, GetArealByCityName(pchar.GenQuest.TakeArsenalship.City));
			pchar.GenQuest.TakeArsenalship.Terms2 = GetMaxDaysFromIsland2Island(GetArealByCityName(pchar.GenQuest.TakeArsenalship.City), GetArealByCityName(pchar.GenQuest.TakeArsenalship.CityA))+1;
			pchar.GenQuest.TakeArsenalship.Terms = sti(pchar.GenQuest.TakeArsenalship.Terms1)+sti(pchar.GenQuest.TakeArsenalship.Terms2);
			pchar.GenQuest.TakeArsenalship.ShipName = GenerateRandomNameToShip(sti(pchar.GenQuest.TakeArsenalship.Nation));
			pchar.GenQuest.TakeArsenalship.Money = (15000 + (sti(pchar.rank) * 1100)) + (drand(5000 + (sti(pchar.rank) * 300)));
			dialog.text = "Certainement. Vous devez retrouver un transport militaire de " + NationNameGenitive(sti(pchar.GenQuest.TakeArsenalship.Nation)) + " chargé de poudre et de munitions, un navire nommé '" + pchar.GenQuest.TakeArsenalship.ShipName + "', et le détruire. Ce faisant, nous porterons un coup sérieux à la puissance militaire de l'ennemi.\nCe transport partira sous escorte dans " + FindRussianDaysString(pchar.GenQuest.TakeArsenalship.Terms1) + " de " + XI_ConvertString("Colony"+pchar.GenQuest.TakeArsenalship.City+"Gen") + ", à destination de " + XI_ConvertString("Colony"+pchar.GenQuest.TakeArsenalship.CityA+"Acc") + ", oם il devrait arriver dans " + FindRussianDaysString(pchar.GenQuest.TakeArsenalship.Terms) + ". Je vous paierai " + FindRussianMoneyString(sti(pchar.GenQuest.TakeArsenalship.Money)) + ". Vous devez vous hâter de l'intercepter.";
			link.l1 = "Très bien, j'accepte la mission. Dois-je couler le navire, ou puis-je le prendre comme prise ?";
		    link.l1.go = "TakeArsenalship_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
			break;

		case "TakeArsenalship_agree":
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.TakeArsenalship.MayorId = npchar.id; //Id мэра, чтобы знать, кто дал квест
			dialog.text = "Comme vous voudrez, cela m'est égal. La cargaison ne doit tout simplement pas arriver à destination. Si vous réussissez cette mission, je ne vous retiendrai pas plus longtemps, capitaine.";
			link.l1 = "J'espère que vous n'attendrez pas longtemps les nouvelles, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			SetFunctionTimerCondition("TakeArsenalship_CreateShip", 0, 0, sti(pchar.GenQuest.TakeArsenalship.Terms1), false);
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.TakeArsenalship.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "25");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.TakeArsenalship.City+"Gen"));
			AddQuestUserData("MayorsQuestsList", "sCityA", XI_ConvertString("Colony"+pchar.GenQuest.TakeArsenalship.CityA+"Acc"));
			AddQuestUserData("MayorsQuestsList", "sDay1", FindRussianDaysString(pchar.GenQuest.TakeArsenalship.Terms1));
			AddQuestUserData("MayorsQuestsList", "sDay2", FindRussianDaysString(pchar.GenQuest.TakeArsenalship.Terms));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.TakeArsenalship.Money)));
			AddQuestUserData("MayorsQuestsList", "sShipName", pchar.GenQuest.TakeArsenalship.ShipName);
			AddQuestUserData("MayorsQuestsList", "sNation", NationNameGenitive(sti(pchar.GenQuest.TakeArsenalship.Nation)));
		break;

		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	ОЗГ - захватить пассажира
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "TakePassenger":
			pchar.GenQuest.questName = "TakePassenger"; //тип квеста
			pchar.GenQuest.TakePassenger.Terms1 = GetMaxDaysFromIsland2Island(Islands[GetCharacterCurrentIsland(PChar)].id, GetArealByCityName(pchar.GenQuest.TakePassenger.City));
			pchar.GenQuest.TakePassenger.Terms2 = GetMaxDaysFromIsland2Island(GetArealByCityName(pchar.GenQuest.TakePassenger.City), GetArealByCityName(pchar.GenQuest.TakePassenger.CityA))+1;
			pchar.GenQuest.TakePassenger.Terms = sti(pchar.GenQuest.TakePassenger.Terms1)+sti(pchar.GenQuest.TakePassenger.Terms2);
			pchar.GenQuest.TakePassenger.ShipName = GenerateRandomNameToShip(sti(pchar.GenQuest.TakePassenger.Nation));
			pchar.GenQuest.TakePassenger.Name = GenerateRandomName(sti(pchar.GenQuest.TakePassenger.Nation), "man");
			pchar.GenQuest.TakePassenger.Money = (12000 + (sti(pchar.rank) * 800)) + (drand(3000));
			string sText = SelectPassText();
			dialog.text = "Sans aucun doute. Il s'agit d'un misérable nommé " + pchar.GenQuest.TakePassenger.Name + ". " + sText + " - je le traque depuis longtemps, et j'ai enfin obtenu des renseignements fiables. Il faut que vous m'ameniez cet homme vivant. J'ai l'intention de faire de lui un exemple sur la place de la ville. Je vous paierai " + FindRussianMoneyString(sti(pchar.GenQuest.TakePassenger.Money)) + ". זtes-vous prêt à vous lancer dans cette chasse à l'homme ?";
			link.l1 = "Je le suis, " + GetAddress_FormToNPC(NPChar) + ". Oם trouverai-je ce gredin ?";
		    link.l1.go = "TakePassenger_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
		break;
		
		case "TakePassenger_agree":
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.TakePassenger.MayorId = npchar.id; //Id мэра, чтобы знать, кто дал квест
			dialog.text = "Dans " + FindRussianDaysString(pchar.GenQuest.TakePassenger.Terms1) + "à peine, il partira comme passager à bord d'un navire nommé '" + pchar.GenQuest.TakePassenger.ShipName + "', au départ de " + XI_ConvertString("Colony"+pchar.GenQuest.TakePassenger.City+"Gen") + " et à destination de " + XI_ConvertString("Colony"+pchar.GenQuest.TakePassenger.CityA+"Acc") + ". Vous n'avez pas plus de " + FindRussianDaysString(pchar.GenQuest.TakePassenger.Terms) + " pour intercepter ce navire, l'aborder et vous emparer du scélérat. Bonne chance, capitaine !";
			link.l1 = "Je ne perdrai pas un instant, " + GetAddress_FormToNPC(NPChar) + " ! J'appareille immédiatement.";
			link.l1.go = "exit";
			SetFunctionTimerCondition("TakePassenger_CreateShip", 0, 0, sti(pchar.GenQuest.TakePassenger.Terms1), false);
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.TakePassenger.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "26");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.TakePassenger.City+"Gen"));
			AddQuestUserData("MayorsQuestsList", "sCityA", XI_ConvertString("Colony"+pchar.GenQuest.TakePassenger.CityA+"Acc"));
			AddQuestUserData("MayorsQuestsList", "sDay1", FindRussianDaysString(sti(pchar.GenQuest.TakePassenger.Terms1)));
			AddQuestUserData("MayorsQuestsList", "sDay2", FindRussianDaysString(sti(pchar.GenQuest.TakePassenger.Terms)));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.TakePassenger.Money)));
			AddQuestUserData("MayorsQuestsList", "sName", pchar.GenQuest.TakePassenger.Name);
			AddQuestUserData("MayorsQuestsList", "sShipName", pchar.GenQuest.TakePassenger.ShipName);
		break;

		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	ОЗГ - уничтожить корабль пиратов
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "TakePirateship":
			pchar.GenQuest.questName = "TakePirateship"; //тип квеста
			pchar.GenQuest.TakePirateship.City = SelectAnyColony(npchar.city);
			pchar.GenQuest.TakePirateship.island = GetArealByCityName(pchar.GenQuest.TakePirateship.City);
			pchar.GenQuest.TakePirateship.Terms = dRand(3) + (20 - MOD_SKILL_ENEMY_RATE*3);
			pchar.GenQuest.TakePirateship.ShipName = GenerateRandomNameToShip(PIRATE);
			pchar.GenQuest.TakePirateship.Name = GenerateRandomName(PIRATE, "man");
			pchar.GenQuest.TakePirateship.Money = (10000 + (sti(pchar.rank) * 500)) + (drand(2000 + (sti(pchar.rank) * 300)));
			dialog.text = "Bien sמr. Je suis ulcéré par les agissements effrontés d'un capitaine pirate nommé " + pchar.GenQuest.TakePirateship.Name + ". Ce gredin s'est mis à piller nos navires marchands, entravant gravement le commerce entre les colonies. L'heure du châtiment a sonné, car j'ai appris oם il se cache en ce moment. Pour cette mission, je suis prêt à vous payer " + FindRussianMoneyString(sti(pchar.GenQuest.TakePirateship.Money)) + ". זtes-vous prêt à prendre la mer et à éliminer cet ennemi de notre Couronne ?";
			link.l1 = "Ce serait un honneur ! Oם pourrais-je trouver ce renégat ?";
		    link.l1.go = "TakePirateship_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
		break;
		
		case "TakePirateship_agree":
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.TakePirateship.MayorId = npchar.id; //Id мэра, чтобы знать, кто дал квест
			dialog.text = "Dans les " + FindRussianDaysString(pchar.GenQuest.TakePirateship.Terms) + "qui viennent, son navire, le '" + pchar.GenQuest.TakePirateship.ShipName + "', croisera dans les eaux de " + XI_ConvertString("Colony"+pchar.GenQuest.TakePirateship.City+"Gen") + ". Trouvez-le et détruisez-le. Donnez-le en pâture aux requins avec son navire, ou prenez-le à l'abordage, peu m'importe, pourvu que ce maudit pirate cesse de souiller les Caraïbes de sa présence.\n Ne perdez pas de temps, capitaine : le coquin ne vous attendra pas éternellement. Allez, et que Dieu soit avec vous !";
			link.l1 = "Je lève l'ancre à l'instant même, " + GetAddress_FormToNPC(NPChar) + " ! Vous aurez bientכt des résultats !";
			link.l1.go = "exit";
			pchar.quest.TakePirateship.win_condition.l1 = "location";
			pchar.quest.TakePirateship.win_condition.l1.location = pchar.GenQuest.TakePirateship.island;
			pchar.quest.TakePirateship.function = "TakePirateship_CreateShip";
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.TakePirateship.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "23");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.TakePirateship.City+"Gen"));
			AddQuestUserData("MayorsQuestsList", "sDay", FindRussianDaysString(sti(pchar.GenQuest.TakePirateship.Terms)));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.TakePirateship.Money)));
			AddQuestUserData("MayorsQuestsList", "sName", pchar.GenQuest.TakePirateship.Name);
			AddQuestUserData("MayorsQuestsList", "sShipName", pchar.GenQuest.TakePirateship.ShipName);
		break;

		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Контркурьер
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "TakePostcureer":
			pchar.GenQuest.questName = "TakePostcureer"; //тип квеста
			pchar.GenQuest.TakePostcureer.Terms1 = GetMaxDaysFromIsland2Island(Islands[GetCharacterCurrentIsland(PChar)].id, GetArealByCityName(pchar.GenQuest.TakePostcureer.City));
			pchar.GenQuest.TakePostcureer.Terms2 = GetMaxDaysFromIsland2Island(GetArealByCityName(pchar.GenQuest.TakePostcureer.City), GetArealByCityName(pchar.GenQuest.TakePostcureer.CityA))+1;
			pchar.GenQuest.TakePostcureer.Terms = sti(pchar.GenQuest.TakePostcureer.Terms1)+sti(pchar.GenQuest.TakePostcureer.Terms2);
			pchar.GenQuest.TakePostcureer.ShipName = GenerateRandomNameToShip(sti(pchar.GenQuest.TakePostcureer.Nation));
			pchar.GenQuest.TakePostcureer.Name = GenerateRandomName(sti(pchar.GenQuest.TakePostcureer.Nation), "man");
			pchar.GenQuest.TakePostcureer.Money = (9000 + (sti(pchar.rank) * 500)) + (drand(2000 + (sti(pchar.rank) * 300)));
			dialog.text = "Certainement. Vous devez retrouver un navire courrier de " + NationNameGenitive(sti(pchar.GenQuest.TakePostcureer.Nation)) + " nommé '" + pchar.GenQuest.TakePostcureer.ShipName + "', l'aborder et me rapporter les papiers trouvés dans la cabine du capitaine. Le navire partira de " + XI_ConvertString("Colony"+pchar.GenQuest.TakePostcureer.City+"Gen") + " dans environ " + FindRussianDaysString(pchar.GenQuest.TakePostcureer.Terms1) + " et se dirigera vers " + XI_ConvertString("Colony"+pchar.GenQuest.TakePostcureer.CityA+"Acc") + ". Je vous paierai " + FindRussianMoneyString(sti(pchar.GenQuest.TakePostcureer.Money)) + ". Vous n'avez pas plus de " + FindRussianDaysString(pchar.GenQuest.TakePostcureer.Terms) + " : vous devrez l'intercepter sur cette route.";
			link.l1 = "Très bien, j'accepte la mission. Quel genre de papiers dois-je chercher ?";
		    link.l1.go = "TakePostcureer_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
		break;
		
		case "TakePostcureer_agree":
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.TakePostcureer.MayorId = npchar.id; //Id мэра, чтобы знать, кто дал квест
			dialog.text = "De la correspondance postale. Elle contient, entre autres, des documents d'une importance vitale pour mes intérêts. Inutile de les éplucher vous-même ; remettez-moi simplement tout le courrier.\nJe vous attendrai à ma résidence avec les résultats.";
			link.l1 = "J'espère que vous n'aurez pas à attendre longtemps, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			SetFunctionTimerCondition("TakePostcureer_CreateShip", 0, 0, sti(pchar.GenQuest.TakePostcureer.Terms1), false);
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.TakePostcureer.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "24");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.TakePostcureer.City+"Gen"));
			AddQuestUserData("MayorsQuestsList", "sCityA", XI_ConvertString("Colony"+pchar.GenQuest.TakePostcureer.CityA+"Acc"));
			AddQuestUserData("MayorsQuestsList", "sDay1", FindRussianDaysString(sti(pchar.GenQuest.TakePostcureer.Terms1)));
			AddQuestUserData("MayorsQuestsList", "sDay2", FindRussianDaysString(sti(pchar.GenQuest.TakePostcureer.Terms)));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.TakePostcureer.Money)));
			AddQuestUserData("MayorsQuestsList", "sName", pchar.GenQuest.TakePostcureer.Name);
			AddQuestUserData("MayorsQuestsList", "sShipName", pchar.GenQuest.TakePostcureer.ShipName);
			AddQuestUserData("MayorsQuestsList", "sNation", NationNameGenitive(sti(pchar.GenQuest.TakePostcureer.Nation)));
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Уничтожение банды
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "DestroyGang":
			dialog.text = "Naturellement. Pour accomplir cette mission, je vous accorde " + FindRussianDaysString(sti(pchar.GenQuest.DestroyGang.Terms)) + ", et votre récompense pour le travail accompli sera de " + FindRussianMoneyString(sti(pchar.GenQuest.DestroyGang.Money)) + ".";
			link.l1 = "D'accord, j'accepte cette mission.";
		    link.l1.go = "DestroyGang_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
		break;
		case "DestroyGang_agree":
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.questName = "DestroyGang"; //тип квеста
			pchar.GenQuest.DestroyGang.Location = GetGangLocation(npchar); //определяем локацию,где банда
			pchar.GenQuest.DestroyGang.MayorId  = npchar.id; //Id мэра, чтобы знать, кто дал квест
			if (pchar.GenQuest.DestroyGang.Location == "none") //на всякий случай
			{
				dialog.text = "Attendez, j'avais complètement oublié le rapport d'hier ! Le fait est que cette bande a déjà quitté notre île. J'annule donc la mission.";
				link.l1 = "Compris. Eh bien, c'est dommage.";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "GenQuest." + pchar.GenQuest.questName);
				DeleteAttribute(pchar, "GenQuest.questName");
			}
			else
			{
				dialog.text = "Eh bien, parfait ! Je vous attends à ma résidence avec les résultats de votre travail.";
				link.l1 = "Je pense que je ne vous ferai pas attendre longtemps, " + GetAddress_FormToNPC(NPChar) + ".";
				link.l1.go = "exit";
				pchar.quest.DestroyGang.win_condition.l1 = "location";
				pchar.quest.DestroyGang.win_condition.l1.location = pchar.GenQuest.DestroyGang.Location;
				if (!CheckAttribute(pchar,"Kamikazi") && rand(99)==0) pchar.quest.DestroyGang.win_condition = "Kamikazi";
				else pchar.quest.DestroyGang.win_condition = "DestroyGang_fight";
				pchar.quest.DestroyGang.again = true; //тупо дожидаться своего часа бандиты не будут
				SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.DestroyGang.Terms), false);
				//==> энкаунтеров в квестовой локации не будет
				locations[FindLocation(pchar.GenQuest.DestroyGang.Location)].DisableEncounters = true;
				ReOpenQuestHeader("MayorsQuestsList");
				AddQuestRecord("MayorsQuestsList", "1");
				AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
				AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
				makearef(arName, pchar.GenQuest.DestroyGang);
				AddQuestUserData("MayorsQuestsList", "GangName", GetFullName(arName));
				AddQuestUserData("MayorsQuestsList", "sDay", FindRussianDaysString(sti(pchar.GenQuest.DestroyGang.Terms)));
				AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.DestroyGang.Money)));
			}
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Поиски лазутчика
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "SeekSpy":
			dialog.text = "Oui, j'ai des raisons de m'y fier. Pour accomplir cette mission, je vous accorde " + FindRussianDaysString(sti(pchar.GenQuest.SeekSpy.Terms)) + ", et votre récompense pour le travail accompli sera de " + FindRussianMoneyString(sti(pchar.GenQuest.SeekSpy.Money)) + ".";
			link.l1 = "D'accord, j'accepte cette mission.";
		    link.l1.go = "SeekSpy_agree";
			link.l2 = "Hum... non, je crois que je vais refuser.";
		    link.l2.go = "All_disagree";
		break;
		case "SeekSpy_agree":
			//(rand(1))
			bool boko = (rand(36) < GetCharacterSPECIALSimple(PChar, SPECIAL_E) + GetCharacterSPECIALSimple(PChar, SPECIAL_S) + GetCharacterSPECIALSimple(PChar, SPECIAL_A))     //WW
			bool orange = false;
			if (npchar.city == "FortOrange") orange = true;
			if  (IsCharacterPerkOn(pchar, "Fencer") || IsCharacterPerkOn(pchar, "Grunt") || boko)   //WW
			{
				if (rand(100)<10 || orange)
				{//шпион гуляет по городу
					pchar.GenQuest.SeekSpy.Location = npchar.city + "_town"; //определяем локацию
					pchar.GenQuest.SeekSpy.City = rand(1); //флаг шпион в городе, ренд - кто будет подсказывать в таверне
				}
				else
				{//шпион в одной из общих локаций common
					pchar.GenQuest.SeekSpy.Location = GetSpyLocation(npchar); //определяем локацию
					Log_QuestInfo(pchar.GenQuest.SeekSpy.Location); //чит
				if (pchar.GenQuest.SeekSpy.Location == "none") //на всякий случай
				{
					dialog.text = "Attendez, je me souviens qu'une personne suspecte a été arrêtée hier ; apparemment, c'était justement l'espion. Vos services ne sont plus nécessaires.";
					link.l1 = "Compris. Eh bien, c'est dommage.";
					link.l1.go = "exit";
					DeleteAttribute(pchar, "GenQuest." + pchar.GenQuest.questName);
					break;
				}
				else
					{
						pchar.quest.SeekSpy_login.again = true; //на всякий случай
					}
				}
			}
			else
			{	//шпион гуляет по городу
				pchar.GenQuest.SeekSpy.Location = npchar.city + "_town"; //определяем локацию
				pchar.GenQuest.SeekSpy.City = rand(1); //флаг шпион в городе, ренд - кто будет подсказывать в таверне
			}
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
			pchar.GenQuest.questName = "SeekSpy"; //тип квеста
			dialog.text = "Eh bien, parfait ! Je vous attends à ma résidence avec les résultats des recherches.";
			link.l1 = "Je pense que je ne vous ferai pas attendre longtemps, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			pchar.GenQuest.SeekSpy.MayorId  = npchar.id; //Id мэра, чтобы знать, кто дал квест
			pchar.quest.SeekSpy.win_condition.l1 = "location";
			pchar.quest.SeekSpy.win_condition.l1.location = pchar.GenQuest.SeekSpy.Location;
			pchar.quest.SeekSpy.win_condition = "SeekSpy_login";
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.SeekSpy.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "3");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sDay", FindRussianDaysString(sti(pchar.GenQuest.SeekSpy.Terms)));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.SeekSpy.Money)));
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Проникновение во враждебный город
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "Intelligence":
			dialog.text = "Je comprends. Peut-être qu'une récompense de " + FindRussianMoneyString(sti(pchar.GenQuest.Intelligence.Money)) + " sera une bonne motivation pour vous.";
			link.l1 = "Oui, c'est une belle somme... J'accepte cette mission.";
		    link.l1.go = "Intelligence_agree";
			link.l2 = "Hum... non, je crois que je vais refuser : c'est trop dangereux.";
		    link.l2.go = "All_disagree";
		break;
		case "Intelligence_agree":
			if (pchar.GenQuest.Intelligence.City == "none" || isBadReputation(pchar, 30)) //на всякий случай
			{
				dialog.text = "Cela dit, je ne peux pas dire que j'aie entièrement confiance en vous... Je crois que je ne vous confierai pas cette mission.";
				link.l1 = "Oh, vraiment... Eh bien, c'est dommage.";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "GenQuest." + pchar.GenQuest.questName);
			}
			else
			{
				npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_complete";
				pchar.GenQuest.questName = "Intelligence"; //тип квеста
				sTemp = pchar.GenQuest.Intelligence.City;
				if(sTemp == "DesMoines") // В Дес-Мойнес нет верфи и ПУ
				{
					switch (rand(2))
					{
						case 0:    sTemp += "_Priest";     break;
						case 1:    sTemp += "_trader";     break;
						case 2:    sTemp += "_usurer";     break;
					}
				}
				else
				{
					switch (rand(4))
					{
						case 0:    sTemp += "_Priest";     break;
						case 1:    sTemp += "_trader";     break;
						case 2:    sTemp += "_shipyarder"; break;
						case 3:    sTemp += "_usurer";     break;
						case 4:    sTemp += "_PortMan";    break;
					}
				}
				pchar.GenQuest.Intelligence.SpyId = sTemp; //Id нашего шпиона в городе
				dialog.text = "Parfait ! Passons aux affaires. א " + XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Voc") + " vous devez trouver un homme du coin ( " + GetWorkTypeOfMan(&characters[GetCharacterIndex(sTemp)], "Gen") +
					"), qui s'appelle " + GetFullName(&characters[GetCharacterIndex(sTemp)]) + ". Vous lui donnerez mon nom et vous recevrez un paquet de documents. Pour me remettre ce paquet en main propre, je vous accorde " + FindRussianDaysString(sti(pchar.GenQuest.Intelligence.Terms)) + ". Et n'oubliez pas que tout doit se faire discrètement. Si on vous repère en ville, l'agent ne prendra aucun risque et n'établira pas le contact. C'est clair ?";
				link.l1 = "Oui, j'ai tout compris, " + GetAddress_FormToNPC(NPChar) + ". Je commence la mission immédiatement.";
				link.l1.go = "exit";
				pchar.GenQuest.Intelligence.MayorId  = npchar.id; //Id мэра, чтобы знать, кто дал квест
				SaveCurrentQuestDateParam("GenQuest.Intelligence"); //запись даты получения квеста
				ReOpenQuestHeader("MayorsQuestsList");
				AddQuestRecord("MayorsQuestsList", "6");
				AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
				AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
				AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Acc"));
				AddQuestUserData("MayorsQuestsList", "sIsland", XI_ConvertString(colonies[FindColony(pchar.GenQuest.Intelligence.City)].islandLable+"Voc"));
				AddQuestUserData("MayorsQuestsList", "sWho", GetWorkTypeOfMan(&characters[GetCharacterIndex(sTemp)], "Gen"));
				AddQuestUserData("MayorsQuestsList", "SpyName", GetFullName(&characters[GetCharacterIndex(sTemp)]));
				AddQuestUserData("MayorsQuestsList", "sDay", FindRussianDaysString(sti(pchar.GenQuest.Intelligence.Terms)));
				AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.Intelligence.Money)));
				AddQuestUserData("MayorsQuestsList", "sCity2", XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Voc"));
			}
		break;
		case "Intelligence_ExecuteLate":
			QuestName = pchar.GenQuest.questName;
			pchar.GenQuest.(QuestName).Money = sti(pchar.GenQuest.(QuestName).Money) / 2);
			dialog.text = RandPhraseSimple("Ce n'est pas mal. Cependant, vous n'avez pas respecté le délai, je dois donc réduire votre rémunération. Votre paie s'élève désormais à " + FindRussianMoneyString(sti(pchar.GenQuest.(QuestName).Money)) + ". Veuillez la recevoir.",
				"C'est bien. Cependant, vous n'avez pas respecté le délai imparti, et j'attendais cette lettre plus tכt. Vous avez bouleversé mes plans, je suis donc obligé de réduire votre rémunération. Je suis tout de même heureux de vous remettre la récompense due : " + FindRussianMoneyString(sti(pchar.GenQuest.(QuestName).Money))  + ". Veuillez la recevoir.");
			link.l1 = "Je ne dirais pas que j'en suis ravi, mais, au fond, les délais n'ont effectivement pas été respectés. Je n'ai donc rien à redire, " + GetAddress_FormToNPC(NPChar) + ".";
		    link.l1.go = "All_Execute_1";
			//--> слухи
			AddSimpleRumour(RandPhraseSimple("Vous savez, le gouverneur " + GetFullName(npchar) + " n'est pas très satisfait de la promptitude d'un certain capitaine " + GetMainCharacterNameGen() + ".",
				"Le gouverneur " + GetFullName(npchar) + " n'est pas très content du capitaine " + GetMainCharacterNameDat() + ". Le capitaine a exécuté les ordres du gouverneur, mais pas dans les temps..."), sti(npchar.nation), 5, 1);
			//<-- слухи
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Уничтожение контры
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "KillSmugglers":
			pchar.GenQuest.questName = "KillSmugglers"; //тип квеста
			pchar.GenQuest.KillSmugglers.Terms = rand(2) + 1; //сроки выполнения задания
			pchar.GenQuest.KillSmugglers.Money = ((rand(8) + 2) * 200) + (sti(pchar.rank) * 200); //вознаграждение
			dialog.text = "Trouver et éliminer ces contrebandiers, bien sמr. Pour accomplir cette mission, je vous accorde " + FindRussianDaysString(sti(pchar.GenQuest.KillSmugglers.Terms)) + ", et votre paie sera de " + FindRussianMoneyString(sti(pchar.GenQuest.KillSmugglers.Money)) + ". Vous acceptez l'affaire ?";
			link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ", j'accepte.";
		    link.l1.go = "KillSmugglers_agree";
			link.l2 = "Non, je ne veux pas m'en mêler...";
		    link.l2.go = "All_disagree";
		break;
		case "KillSmugglers_agree":
			dialog.text = "Bien. Dans ce cas, j'attends de bonnes nouvelles de votre part.";
			link.l1 = "Je crois qu'elles ne tarderont pas, " + GetAddress_FormToNPC(NPChar) + ".";
		    link.l1.go = "exit";
			pchar.GenQuest.KillSmugglers.MayorId  = npchar.id; //Id мэра, чтобы знать, кто дал квест
			pchar.GenQuest.KillSmugglers.Areal = GetArealByCityName(npchar.city); //ареал, где нужно поработать
			for(i=0; i<MAX_CHARACTERS; i++)
			{
				sld = &characters[i];
				if (sld.id == "Rand_Smug01" && pchar.GenQuest.KillSmugglers.Areal == GiveArealByLocation(&locations[FindLocation(sld.location)]))
				{
					pchar.quest.KillSmugglers.win_condition.l1 = "NPC_Death";
					pchar.quest.KillSmugglers.win_condition.l1.character = "Rand_Smug01";
					pchar.quest.KillSmugglers.win_condition.l2 = "NPC_Death";
					pchar.quest.KillSmugglers.win_condition.l2.character = "Rand_Smug02";
					pchar.quest.KillSmugglers.win_condition.l3 = "NPC_Death";
					pchar.quest.KillSmugglers.win_condition.l3.character = "Rand_Smug03";
					pchar.quest.KillSmugglers.win_condition = "KillSmugglers_after";
					break;
				}
			}
			SetTimerCondition("AllMayorsQuests_Late", 0, 0, sti(pchar.GenQuest.KillSmugglers.Terms), false);
			ReOpenQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "8");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
			AddQuestUserData("MayorsQuestsList", "sDay", FindRussianDaysString(sti(pchar.GenQuest.KillSmugglers.Terms)));
			AddQuestUserData("MayorsQuestsList", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.KillSmugglers.Money)));
		break;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//	Поиск и уничтожение пирата
		/////////////////////////////////////////////////////////////////////////////////////////////////
		case "DestroyPirate":
			pchar.GenQuest.questName = "DestroyPirate"; //тип квеста
			pchar.GenQuest.DestroyPirate.Terms = dRand(3) + (15 - MOD_SKILL_ENEMY_RATE*3); //сроки выполнения задания
			pchar.GenQuest.DestroyPirate.Money = ((dRand(5) + 5) * 500) + (sti(pchar.rank) * 200); //вознаграждение
			sld = characterFromId("MQPirate");
			dialog.text = "Il faut que vous retrouviez et détruisiez ce pirate. Coulez-le, prenez-le à l'abordage, peu m'importe. Il faut juste que ce maudit corsaire qui chasse dans ces eaux cesse d'entraver le commerce" + XI_ConvertString("Colony"+npchar.city+"Gen") +
				". Pour accomplir cette mission, je vous accorde " + FindRussianDaysString(sti(pchar.GenQuest.DestroyPirate.Terms)) + ", et votre récompense en cas de succès est fixée à " + FindRussianMoneyString(sti(pchar.GenQuest.DestroyPirate.Money)) + ". Alors, vous acceptez l'affaire ?";
			link.l1 = "Oui, " + GetAddress_FormToNPC(NPChar) + ", j'accepte.";
		    link.l1.go = "DestroyPirate_agree";
			link.l2 = "Non, plutכt pas. Je ne veux pas chasser les pirates...";
		    link.l2.go = "All_disagree";
		break;
		case "DestroyPirate_agree":
			dialog.text = "Bien. Bonne chance.";
			link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + ".";
		    link.l1.go = "exit";
			pchar.GenQuest.DestroyPirate.MayorId  = npchar.id; //Id мэра, чтобы знать, кто дал квест
			pchar.GenQuest.DestroyPirate.Areal = GetArealByCityName(npchar.city); //ареал, куда будем ставить пирата
			AddDialogExitQuest("DestroyPirate_Begin");
		break;
		// -------------- общий набор для всех квестов мэра ------------------
		case "All_disagree":
			dialog.text = "Vous me décevez !";
			link.l1 = "Désolé, " + GetAddress_FormToNPC(NPChar) + ", mais je ne peux pas accepter cette affaire.";
		    link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -2);

			if (CheckAttribute(pchar, "GenQuest.questName"))
			{
				QuestName = pchar.GenQuest.questName;
				DeleteAttribute(pchar, "GenQuest." + QuestName);
				DeleteAttribute(pchar, "GenQuest.questName");
			}
		break;
		case "All_Late":
			QuestName = pchar.GenQuest.questName;
			dialog.text = RandPhraseSimple("Eh bien, que dire, c'est très fâcheux. Je comptais sur vous, et finalement j'ai perdu mon temps. Je suis déçu.",
				"Eh bien, je dois l'avouer, vous me décevez énormément... Ma résidence est toujours pleine de gens prêts à accomplir ce genre de mission, et j'ai perdu mon temps avec vous. Mmm...");
			link.l1 = "Désolé, " + GetAddress_FormToNPC(NPChar) + ", j'ai fait tout ce que j'ai pu.";
		    link.l1.go = "exit";
			//--> слухи
			AddSimpleRumour(LinkRandPhrase("Vous savez, le gouverneur " + GetFullName(npchar) + " est très mécontent du capitaine " + GetMainCharacterNameDat() + ". Imaginez, il n'a pas eu le temps d'accomplir sa mission !",
				"Le gouverneur " + GetFullName(npchar) + " est quelque peu agacé qu'un certain capitaine " + GetFullName(pchar) + " se soit attelé à la tâche sans parvenir à la terminer à temps. Ce n'est pas bien...",
				"J'ai entendu dire que le gouverneur " + GetFullName(npchar) + " est très mécontent de vous, capitaine " + GetFullName(pchar) + ", car vous n'avez pas réussi à accomplir sa mission à temps."), sti(npchar.nation), 5, 1);
			//<-- слухи
			ChangeCharacterReputation(pchar, -4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			DeleteAttribute(pchar, "GenQuest." + QuestName);
			DeleteAttribute(pchar, "GenQuest.questName");
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_common"; //реплику вертаем
			SaveCurrentNpcQuestDateParam(npchar, "work_date"); //сразу ещё один не даём
			CloseQuestHeader("MayorsQuestsList");
		break;
		case "All_Found":
			QuestName = pchar.GenQuest.questName;
			dialog.text = RandPhraseSimple("Je suis tout simplement scandalisé ! Réussir à trouver la cible sans prendre soin de s'assurer la supériorité, c'est, voyez-vous, le comble de l'imprudence. Je suis déçu !",
				"Eh bien, je dois l'avouer, vous me décevez. Il ne suffit pas de trouver une cible, il faut savoir la détruire. J'ai assez de fiers-à-bras dans ma résidence, prêts à accomplir ce genre de mission. Pourquoi me suis-je adressé à vous ?");
			link.l1 = "Désolé, " + GetAddress_FormToNPC(NPChar) + ", mais je ne veux pas risquer ma vie aussi imprudemment.";
		    link.l1.go = "exit";
			//--> слухи
			AddSimpleRumour(LinkRandPhrase("Vous savez, le gouverneur " + GetFullName(npchar) + " est très mécontent du capitaine " + GetMainCharacterNameDat() + ". Imaginez, "+ GetSexPhrase("il s'est révélé n'être qu'un lâche","elle s'est révélée n'être qu'une lâche") +" !",
				"Le gouverneur " + GetFullName(npchar) + " est quelque peu agacé qu'un certain capitaine " + GetFullName(pchar) + " ait accepté la mission, puis échoué par indécision. Hi hi, en voilà des capitaines !",
				"J'ai entendu dire que le gouverneur " + GetFullName(npchar) + " est très mécontent de vous, capitaine " + GetFullName(pchar) + ". On dit que vous n'êtes qu'un lâche..."), sti(npchar.nation), 5, 1);
			//<-- слухи
			ChangeCharacterReputation(pchar, -6);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			DeleteAttribute(pchar, "GenQuest." + QuestName);
			DeleteAttribute(pchar, "GenQuest.questName");
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_common"; //реплику вертаем
			SaveCurrentNpcQuestDateParam(npchar, "work_date"); //сразу ещё один не даём
			CloseQuestHeader("MayorsQuestsList");
			AddQuestRecord("MayorsQuestsList", "21");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+npchar.city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(npchar));
		break;
		case "All_Execute":
			QuestName = pchar.GenQuest.questName;
			pchar.(sNationname).quest.mayor = sti(pchar.(sNationname).quest.mayor) + 1;
			dialog.text = RandPhraseSimple("Excellente nouvelle ! Eh bien, il est temps de faire les comptes. Votre paie s'élève à " + FindRussianMoneyString(sti(pchar.GenQuest.(QuestName).Money)) + ". Veuillez la recevoir.",
				"Parfait ! Ce sera mieux pour tout le monde... Je suis donc heureux de vous remettre la récompense due : " + FindRussianMoneyString(sti(pchar.GenQuest.(QuestName).Money))  + ". Veuillez la recevoir.");
			link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + ", " + RandPhraseSimple("ravi de faire affaire avec vous !", "Agréablement surpris par la clarté de nos comptes.");
		    link.l1.go = "All_Execute_1";
			//--> слухи
			AddSimpleRumour(LinkRandPhrase("Vous savez, le gouverneur " + GetFullName(npchar) + " ne tarit pas d'éloges sur l'efficacité de "+ GetSexPhrase("ce capitaine","cette fille") +" " + GetMainCharacterNameGen() + ".",
				"Le gouverneur " + GetFullName(npchar) + " fait l'éloge du capitaine " + GetMainCharacterNameGen() + ", qui"+ GetSexPhrase("","") +" exécute à la lettre toutes ses instructions. Une personne indispensable pour le gouverneur, je vous le dis...",
				"J'ai entendu dire que le gouverneur " + GetFullName(npchar) + " est très content de vous, capitaine " + GetFullName(pchar) + ". Il vous décrit comme un officier soigneux et efficace. דa fait plaisir à entendre, capitaine..."), sti(npchar.nation), 5, 1);
			//<-- слухи
		break;
		case "All_Execute_1":
			QuestName = pchar.GenQuest.questName;
			if (CheckAttribute(pchar,"Kamikazi") && pchar.Kamikazi == "Meet")
			{
				dialog.text =  "Estimez-vous heureux d'être encore en vie"+GetSexPhrase("","e")+". Ici, ce sont les Caraïbes, mon petit !";
				link.l1 = "Va te faire voir, pauvre type !";
				link.l1.go = "exit";
				pchar.Kamikazi = "Done";
				PlayStereoSound("notebook");
			}
			else
			{
				dialog.text = RandPhraseSimple("Eh bien, voilà qui est bien. Vous pouvez revenir me voir, je trouverai peut-être du travail pour vous.", "Eh bien, parfait ! Je vous proposerai peut-être un autre travail de ce genre.");
				link.l1 = RandPhraseSimple("Parfait.", "Parfait.");
				link.l1.go = "exit";
				PlayStereoSound("notebook");
			}

			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.(QuestName).Money));
			CloseQuestHeader("MayorsQuestsList");

			AchievementsCounter_genquests(1);

			ChangeCharacterReputation(pchar, 4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(PChar, "Leadership", 50);
			OfficersReaction("good");

			DeleteAttribute(pchar, "GenQuest." + QuestName);
			DeleteAttribute(pchar, "GenQuest.questName");
			npchar.greeting = NationShortName(sti(npchar.nation)) + "_gov_common"; //реплику вертаем
			SaveCurrentNpcQuestDateParam(npchar, "work_date"); //сразу ещё один не даём
			// инкремент в базу заданий мэров
			sTemp = npchar.City;
			if (!CheckAttribute(pchar, "GenQuest.MayorQuestsList." + sTemp)) pchar.GenQuest.MayorQuestsList.(sTemp) = 0;
			pchar.GenQuest.MayorQuestsList.(sTemp) = sti(pchar.GenQuest.MayorQuestsList.(sTemp)) + 1;

			if (sTemp == "Santiago")
			{
				if (CheckAttribute(pchar, "PGGWhisperLetter"))
				{
					if (sti(pchar.GenQuest.MayorQuestsList.(sTemp)) > 2)
					{
						AddQuestRecord("PGGWhisper", "3");
					}
					else
					{
						AddQuestRecord("PGGWhisper", "2");
					}
				}
			}

		break;
//<-- осады homo
		case "siege_task":
            makearef(aData, NullCharacter.Siege);
            aData.HelpColony = true;
			dialog.text = "En des temps si difficiles, toute aide nous est précieuse. Nous acceptons votre aide : aidez-nous à défendre la colonie, et vous serez récompensé.";
			link.l1 = "Alors ne perdons pas de temps.";
		    link.l1.go = "exit";
		break;
		//  boal из ВМЛ -->
		case "GhostShipDone":
            SaveCurrentNpcQuestDateParam(npchar, "GhostShipHelp");

			AddCharacterExpToSkill(pchar, "Leadership", 200);
			AddMoneyToCharacter(pchar, 5000 + rand(10) * 1000);
			ChangeCharacterReputation(pchar, 1);
			ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", -20);
			sTemp = npchar.City;
   			if (!CheckAttribute(pchar, "GenQuest.MayorQuestsList." + sTemp)) pchar.GenQuest.MayorQuestsList.(sTemp) = 0;
			pchar.GenQuest.MayorQuestsList.(sTemp) = sti(pchar.GenQuest.MayorQuestsList.(sTemp)) + 1;

            OfficersReaction("good");
			DeleteAttribute(pchar, "GenQuest.GhostShipWorkId");
			DeleteAttribute(pchar, "GenQuest.GhostShipDone_" + NPChar.id);

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

		break;

		case "GhostShipHelp_1":
            SaveCurrentNpcQuestDateParam(npchar, "GhostShipHelp");
			pchar.GenQuest.GhostShipWorkId = NPChar.id;

			bDisableFastReload              = true;

			SetLocationCapturedState(NPChar.Default, true);

			Pchar.quest.GhostShipHelp.win_condition.l1          = "location";
    	    Pchar.quest.GhostShipHelp.win_condition.l1.location = NPChar.from_sea;
    	    Pchar.quest.GhostShipHelp.win_condition             = "GhostShipHelp";

			Pchar.GenQuest.Hunter2Pause            = true;

			ReOpenQuestHeader("GhostShipQuest");
			AddQuestRecord("GhostShipQuest", "help_t1");
			AddQuestUserData("GhostShipQuest", "sCity", GetCityName(npchar.City));

   			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}

string GetGangLocation(ref npchar)
{
    int n;
	string island = GetArealByCityName(npchar.city);
	string LocationId, sAreal;
	int storeArray[MAX_LOCATIONS];
    int howStore = 0;

	for(n=0; n<MAX_LOCATIONS; n++)
	{
		if (GiveArealByLocation(&locations[n]) == island)
		{
			//==> на всякий случай
			if (CheckAttribute(&locations[n], "DisableEncounters") && locations[n].DisableEncounters == true) continue;
			LocationId = locations[n].id;
			if (findsubstr(LocationId, "jungle" , 0) != -1 || findsubstr(LocationId, "Shore" , 0) != -1 || findsubstr(LocationId, "CaveEntrance" , 0) != -1)
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
	}
	if (howStore == 0) return "none";
	n = storeArray[dRand(howStore-1)];
	return locations[n].id;
}

string GetSpyLocation(ref npchar)
{
    aref	arCommon, arRld, arRld2;
    int	i, n, Qty, Qty2;
	string LocId;
	string islandId, islandId2;
	string	storeArray [50];
	int howStore = 0;
	int locationId = FindLocation(npchar.city + "_town");
    makearef(arRld, Locations[locationId].reload);
	islandId = Locations[locationId].islandId;
	Qty = GetAttributesNum(arRld);
    if (CheckAttribute(pchar, "questTemp.jailCanMove.Deliver.locationId")) //если взят квест по доставке малявы
	{
		for (i=0; i<Qty; i++)
		{
    		arCommon = GetAttributeN(arRld, i);
			LocId = arCommon.go;
    		if (findsubstr(LocId, "Common" , 0) != -1 && LocId != pchar.questTemp.jailCanMove.Deliver.locationId)
    		{
				storeArray[howStore] = LocId;
				howStore++;
			}
			if (arCommon.label != "Sea")
			{
				makearef(arRld2, Locations[FindLocation(LocId)].reload);
				Qty2 = GetAttributesNum(arRld2);
				for (n=0; n<Qty2; n++)
				{
    				arCommon = GetAttributeN(arRld2, n);
					LocId = arCommon.go;
					if (findsubstr(LocId, "Common" , 0) != -1 && LocId != pchar.questTemp.jailCanMove.Deliver.locationId && LocId != "CommonPackhouse_1" && LocId != "CommonPackhouse_2")
    				{
						storeArray[howStore] = LocId;
						howStore++;
					}
				}
			}
		}
	}
	else
	{
		for (i=0; i<Qty; i++)
		{
    		arCommon = GetAttributeN(arRld, i);
			LocId = arCommon.go;
    		if (findsubstr(LocId, "Common" , 0) != -1)
    		{
				storeArray[howStore] = LocId;
				howStore++;
			}
			if (arCommon.label != "Sea")
			{
				int locationId2 = FindLocation(LocId);
				if (!CheckAttribute(Locations[locationId2],"reload") || !CheckAttribute(Locations[locationId2],"islandId")) continue;
				makearef(arRld2, Locations[locationId2].reload);
				islandId2 = Locations[locationId2].islandId;

				if (islandId == islandId2) {
					Qty2 = GetAttributesNum(arRld2);
					for (n = 0; n < Qty2; n++)
					{
						arCommon = GetAttributeN(arRld2, n);
						LocId = arCommon.go;
						if (findsubstr(LocId, "Common", 0) != -1 && LocId != "CommonPackhouse_1" && LocId != "CommonPackhouse_2")
						{
							storeArray[howStore] = LocId;
							howStore++;
						}
					}
				}
			}
		}
	}
	if (howStore == 0) return "none";
	LocId = storeArray[dRand(howStore-1)];
	SetOpenDoorCommonLoc(npchar.city, LocId); //открываем дверь
	for(n=0; n<MAX_CHARACTERS; n++)
	{
		if (CheckAttribute(&characters[n], "locations") && characters[n].locations == LocId)
		{
			characters[n].lifeDay = 0;
		}
	}
	return LocId;
}

string GetSpyColony(ref NPChar)
{
    int storeArray[MAX_COLONIES];
    int howStore = 0;
	string sChrId;

	for(int n=0; n<MAX_COLONIES; n++)
	{
		if (colonies[n].nation != "none" && sti(colonies[n].nation) != PIRATE && GetNationRelation(sti(colonies[n].nation), sti(NPChar.nation)) == RELATION_ENEMY && colonies[n].id != "Panama" && colonies[n].id != npchar.City)
		{
			storeArray[howStore] = n;
			howStore++;
		}
	}
	if (howStore == 0) return "none";
	return colonies[storeArray[Rand(howStore-1)]].id;
}
string SelectPassText()
{
	string sText;
	switch (drand(5))
	{
		case 0: sText = "Ce Judas, abusant de sa haute position, a vendu des secrets d'וtat vitaux à une puissance ennemie pour une poignée d'argent."; break;
		case 1: sText = "Ce scélérat a lâchement assassiné son propre parent, un homme de haut rang et de grand renom, pour un héritage."; break;
		case 2: sText = "Cette ignoble crapule a gravement insulté ma famille et ma personne."; break;
		case 3: sText = "Ce voleur s'est enfui avec une importante somme d'or du trésor de notre colonie."; break;
		case 4: sText = "Cet assassin est responsable de la mort de près d'une douzaine de nos honnêtes citoyens."; break;
		case 5: sText = "Cet escroc, usant de ses relations, s'est frauduleusement emparé d'un navire marchand, s'est enfui avec et l'a revendu à un chantier naval voisin."; break;
	}
	return sText;
}

string SelectFugitiveText()
{
	string sText;
	switch (drand(5))
	{
		case 0: sText = "un officier subalterne de notre garnison a abandonné son poste et s'est enfui de notre colonie à bord d'un navire marchand."; break;
		case 1: sText = "l'un de nos officiers supérieurs a déserté en plein service et s'est échappé sur un navire de contrebandiers."; break;
		case 2: sText = "l'un de nos officiers de marine, affecté à un brick de patrouille, a déserté pour des raisons inconnues, volé une chaloupe et disparu."; break;
		case 3: sText = "un gardien de prison a inexplicablement abandonné son service et s'est enfui de notre colonie sur un navire privé."; break;
		case 4: sText = "un soldat de notre garnison a déserté son poste pendant sa garde, a gagné la baie et a quitté ces rivages sur un navire non identifié."; break;
		case 5: sText = "un officier militaire, capitaine d'un lougre de patrouille, a abandonné son navire en mer et s'est enfui vers une destination inconnue à bord d'un bateau de pêche."; break;
	}
	return sText;
}
