// Gregg: the French soldiers and the commandant of Port-au-Prince - the "Black Orchid"
// trilogy (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// One file for three characters, as in the original:
//   1-2   - the street patrol, arrest for the murder of Bertrand Grenadier;
//   3-28  - the interrogation in the prison and the terms of release;
//   29-33 - the sentry at Brian George's house, demanding a written permit;
//   34-46, 50 - the commandant after the ambush on Tulip's band, hands over the permit;
//   51-54 - the sentry accepts the permit and unlocks the house.
// Nodes 47-49 of the original (the side quest about the beast near the fort) were not
// ported - that is a separate Damned Destiny quest we do not have.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.lastname;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Capitaine " + GetFullName(PChar) + " ! Vous êtes en état d'arrestation pour le meurtre de Bertrand Grenadier ! Tout ce que vous direz pourra être retenu contre vous. Suivez-nous !";
			link.l1 = "Tout ça était un coup monté ! Je suis innocent !";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Suivez-nous ! On tirera ça au clair à la prison.";
			link.l1 = "Bon sang.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxPrison");
		break;

		case "3":
			dialog.text = "Capitaine " + GetFullName(PChar) + " ! Nous allons maintenant procéder à l'interrogatoire. Bien que nous sachions avec certitude que vous avez tué le capitaine Bertrand Grenadier, j'aimerais entendre les motifs qui vous ont poussé à ce crime. Parlez.";
			link.l1 = "En sortant de la taverne, une femme en larmes a couru vers moi et m'a supplié de l'aider. Elle et son mari se reposaient dans la clairière au-delà des portes de la ville quand un capitaine ivre est arrivé et s'est mis à l'insulter. Son mari a défendu l'honneur de sa femme et a été abattu d'un coup de pistolet, après quoi ce capitaine a violé la femme. Je suis sorti de la ville, jusqu'à l'endroit oם c'était arrivé. Dès que j'ai franchi les portes, ce même Bertrand Grenadier m'a attaqué. Pour défendre ma propre vie, j'ai été contraint de le tuer.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Bertrand Grenadier vous a attaqué sans prévenir ?";
			link.l1 = "Oui, commandant. J'ai à peine eu le temps de dégainer mon épée et de parer son coup.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Capitaine " + sName + ", la femme qui vous a demandé de l'aide a-t-elle donné son nom ?";
			link.l1 = "Non, commandant.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Décrivez son apparence. Il est important pour nous de savoir à quoi elle ressemblait.";
			link.l1 = "Petite, vêtue d'une robe rouge aux manches bleues.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "דa suffira. Oui, tout concorde. L'interrogatoire est terminé, capitaine " + sName + ". Et maintenant, écoutez bien. Nous sommes prêts à vous libérer de cette prison, mais en échange, vous rendrez un service à la France. D'accord ?";
			link.l1 = "Et quel service serait-ce ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Vous devez trouver et tuer une personne indésirable aux yeux du gouvernement de la France. Vous n'avez pas le choix : ce travail est votre seule chance de sortir d'ici. D'accord ?";
			link.l1 = "Ma seule chance de sortir d'ici ? Je parierais que ce n'est pas la seule...";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Capitaine " + sName + ", vous avez tué Bertrand Grenadier, un héros de la France ! Le gouverneur a ordonné qu'on vous exécute sur-le-champ sur la place de la ville, sans interrogatoire ni enquête. La foule enragée a soif du sang de celui qui a tué son favori, et seule l'intervention opportune de Stefan Lanven, qui m'a convaincu de mener cet interrogatoire et de vous offrir la vie et la liberté, m'empêche de donner l'ordre à l'escorte.";
			link.l1 = "Stefan Lanven ? Qui est-ce ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "OUI ou NON, capitaine " + sName + " ?! Le temps se compte en secondes !";
			link.l1 = "Très bien, j'accepte ! Je promets d'accomplir cette mission.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Si vous aviez eu un peu plus de bon sens, vous auriez accepté tout de suite. Et maintenant, capitaine, préparez-vous à écouter. Je vais vous parler de Bertrand Grenadier, pour que vous compreniez enfin qui vous avez tué. Ne m'interrompez pas ; les questions après mon récit. C'est clair ?";
			link.l1 = "Oui, commandant.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Le capitaine Bertrand Grenadier est un héros de la France. Il y a quelques années, il a empêché une attaque contre la colonie française de Port-au-Prince en tuant Alvarez Istilochos, un capitaine espagnol, le pire ennemi de la France. Une prime record avait été mise sur la tête d'Istilochos : 299 999 piastres. En Espagne, Alvarez était un héros national, immensément populaire, et il accomplissait brillamment toutes les missions du gouverneur général Francisco Oregón y Gascón. \nPour vaincre Istilochos, Grenadier a dמ devenir agent double. Tout en restant un loyal sujet de la Couronne de France, il est entré au service de l'Espagne. Réussissant toutes les missions qu'on lui confiait, Grenadier s'est vite rendu célèbre, tandis qu'Istilochos tombait en disgrâce après avoir raté une mission importante. Alvarez, perdant rapidement la réputation qu'il avait si durement acquise, a été saisi de fureur et de haine envers Grenadier. \nCar c'était Grenadier qui était devenu le héros à sa place, Grenadier qui était au sommet de la popularité. Alvarez n'était pas habitué à la seconde place, ni à partager la gloire. Il a conçu un plan astucieux : retrouver ce qu'il avait perdu et se débarrasser en même temps de son rival. \nAlvarez a proposé à Grenadier d'attaquer Port-au-Prince, dont le fort était réputé l'un des plus solides des Caraïbes. Istilochos comptait bombarder le fort et, pendant l'assaut, tuer Grenadier d'un coup de pistolet sans être vu. Mais Bertrand n'était pas un imbécile non plus. De nuit, le vaisseau de ligne d'Istilochos, le Francis, et la frégate de Grenadier, l'Esthète, se sont approchés du phare de Port-au-Prince. \nUn conseil de guerre s'est réuni dans la cabine du Francis, en présence des officiers de tous les navires. א la même heure, selon le plan soigneusement préparé par Grenadier, on construisait un brמlot à bord de l'Esthète. Il a été assemblé en quelques minutes. א la faveur de l'obscurité, le brמlot, mené par une poignée de marins audacieux, est venu cogner sans encombre contre le flanc du vaisseau de ligne. \nAprès avoir amarré le brמlot, les marins y ont mis le feu et l'ont quitté. Les flammes ont aussitכt gagné le flanc du Francis, et quelques secondes plus tard, les barils de poudre ont sauté. L'explosion a été le signal pour Grenadier et ses officiers. Tirant l'épée, ils se sont jetés sur les hommes d'Istilochos. \nLa surprise a joué : l'ennemi, abasourdi, n'a pu opposer aucune résistance. Dès qu'Alvarez et ses hommes ont été abattus, Grenadier et ses officiers ont sauté par les fenêtres de poupe et ont nagé jusqu'à l'Esthète. Quand Bertrand a atteint le flanc de son propre navire, le Francis brמlait déjà vivement dans la brume de l'aube. Telle fut la fin d'Alvarez Istilochos. Des questions ?";
			link.l1 = "Oui, commandant. Comment pouviez-vous être sמr que Grenadier ne trahirait pas un beau jour la France pour devenir un loyal sujet de la Couronne d'Espagne ? Vous ne pouviez pas le contrכler pendant qu'il servait l'Espagne. Les agents doubles représentent un risque énorme ; on ne peut jamais être entièrement certain de quel cכté ils sont.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Bonne question, capitaine. Tout tenait à son père, Pierre. Sous les yeux de Bertrand, alors âgé de treize ans, Pierre Grenadier a été tué par des soldats espagnols pendant l'assaut de la Martinique. Bertrand a juré de se venger des Espagnols toute sa vie. D'autres questions ?";
			link.l1 = "Comment Bertrand a-t-il appris qu'Istilochos comptait le tuer pendant l'assaut ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "C'était évident dès le départ. Istilochos naviguait toujours seul, sans compagnons. On raconte l'histoire d'un certain capitaine qui naviguait avec lui quand Alvarez était encore inconnu. Ensemble, ils ont pillé une colonie française, et c'est Istilochos qui a fait tout le travail. \nPourtant, l'honneur et la gloire sont revenus non pas à lui, mais à son compagnon. Furieux, Alvarez a refusé de naviguer avec cet homme et a retiré son navire de l'escadre. Plus tard, son ancien compagnon a été retrouvé mort dans la cabine de son propre navire. Mais ce n'est qu'une légende, rien de plus. \nAlors, le simple fait qu'Istilochos ait proposé à Grenadier de s'associer était révélateur. Et le sixième sens de Bertrand lui disait qu'on le tuerait : Alvarez n'était pas du genre à partager la gloire. Des questions ?";
			link.l1 = "Comment l'équipage du vaisseau de ligne a-t-il pu ne pas remarquer l'approche d'un brמlot ? Oם étaient les vigies ? Et l'agitation à bord de l'Esthète pendant la construction du brמlot, ça ne passe pas inaperçu non plus.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "L'équipage du Francis ne pouvait pas voir la construction du brמlot, pour deux raisons. D'abord, il a été assemblé du cכté tribord, et seul le cכté bâbord était visible depuis le vaisseau de ligne. Ensuite, la nuit était très noire ; on ne distinguait rien à cinq pas. \nPour la même raison, ils n'ont pas vu le brמlot approcher. Et quand ils l'ont vu et ont compris, il était trop tard : le brמlot était en feu, et il ne restait que quelques secondes avant que la poudre saute. Voilà comment ça s'est passé. D'autres questions ?";
			link.l1 = "Y a-t-il eu des survivants du Francis ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Plusieurs dizaines d'hommes ont survécu. Ils ont tous été pendus.";
			link.l1 = "Tous ?!";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Tous ceux qu'on a pris. Nous, les Français, haïssions Istilochos, son navire et tous ceux qui naviguaient avec lui. Nous les avons pendus pour assouvir entièrement notre vengeance. Assez de questions, capitaine " + sName + ", venons-en aux affaires. D'abord, votre mission. La femme qui vous a demandé de l'aide est un agent espagnol. C'est elle que vous devez tuer.";
			link.l1 = "Quoi ?! C'est un agent espagnol ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Ne m'interrompez pas ! C'est un agent espagnol, et son but était la mort de Bertrand Grenadier. Par votre intermédiaire, elle l'a atteint.";
			link.l1 = "Elle m'a trompé ! Et c'est Grenadier qui m'a attaqué le premier.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Ne m'interrompez pas, capitaine " + sName + " ! Nous connaissons les circonstances de sa mort. Nous savons que la femme vous a trompé. Nous savons que Grenadier a frappé le premier. \nNous savons tout cela, mais n'oubliez pas que vous êtes le meurtrier de Bertrand, et que la plupart de mes compatriotes vous mettraient en pièces même si vous essayiez de vous justifier. Et pour la dernière fois, je vous demande de ne pas m'interrompre. C'est clair ?";
			link.l1 = "Oui, commandant. Une question, si vous permettez.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Posez-la.";
			link.l1 = "Au début de l'interrogatoire, vous avez laissé échapper ces mots : « Tout concorde ». Qu'est-ce que cela voulait dire ?";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Une femme en robe bleue a couru vers l'un des soldats qui maintenaient l'ordre dans les rues et lui a dit qu'un certain capitaine " + sName + " – c'est-à-dire vous – avait l'intention de tuer Bertrand Grenadier. Quand le soldat est arrivé aux portes, il vous a vu avec une épée ensanglantée et vous a arrêté.";
			link.l1 = "Mais comment avez-vous appris que c'était un agent espagnol ? Bon sang ! Pardonnez-moi, je vous ai interrompu.";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Nous appelons tous cette femme Matilda : personne ne connaît son vrai nom. Elle a une dizaine d'opérations de ce genre à son actif. Elle trouve sa victime en ville et lui dit que son mari a été tué et qu'elle-même a été violée. Puis elle le supplie de punir l'assassin, qui doit bientכt apparaître au-delà des portes. \nLe capitaine cède à ses supplications en larmes et attend dehors. Ensuite, Matilda trouve un autre capitaine et lui raconte la même histoire avec de légères variantes. Mais pourquoi vous dis-je cela : vous vous souvenez parfaitement de ce qu'elle vous a dit. Ensuite, tout se déroule selon le scénario que vous connaissez déjà : l'un meurt au-delà des portes, l'autre est arrêté par les soldats sur sa dénonciation.";
			link.l1 = "Quelle sorcière rusée !";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Diablement bien dit, capitaine. Bon, je vous en ai déjà dit plus que ne le demandait Stefan Lanven. Vous recevrez d'autres instructions de sa part ; il vous attendra à la résidence du gouverneur, à la Martinique. Tout est clair ?";
			link.l1 = "Oui, commandant. Je suis prêt.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Un conseil gratuit, capitaine " + sName + ". Stefan Lanven est un homme dur. Vous feriez bien de lui obéir sans discuter. Je sais que vous, les capitaines libres, aimez votre liberté et n'avez pas l'habitude qu'on vous commande, mais vous devez la vie à Lanven. Souvenez-vous-en, même si Stefan se montre grossier envers vous ou exige l'impossible.";
			link.l1 = "Dois-je me taire même s'il m'envoie à une mort certaine ?";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Beaucoup de capitaines ont travaillé pour Lanven, et aucun n'est mort. Et de toute façon, bien des hommes rêvent de travailler pour lui. Estimez-vous heureux. Et je vous le rappelle encore une fois : vous devez la vie à Lanven.";
			link.l1 = "Oui, je comprends, je comprends. Maintenant, laissez-moi sortir.";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Capitaine, ne vous avais-je pas prévenu ?";
			link.l1 = "De quoi ?";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Vous devez passer trois jours dans cette prison avant d'être libéré.";
			link.l1 = "Que le diable vous emporte, vous aviez promis de me libérer !";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "C'est vrai. Mais pas avant trois jours. C'est notre condition. J'espère que notre brouet sera à votre goמt. Bonne journée.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInPrisonTime");
		break;

		case "29":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "J'ai besoin d'entrer dans cette maison. J'agis sur ordre de Stefan Lanven.";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Interdit ! Le commandant a ordonné de ne laisser entrer personne. Si vous voulez passer, allez voir le commandant, obtenez un laissez-passer, montrez-le-moi, et je vous laisserai entrer.";
			link.l1 = "Et qu'est-ce qui s'est passé ici, d'ailleurs ? Pourquoi personne ne peut-il entrer ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Il y a eu un meurtre ici. Une enquête est en cours.";
			link.l1 = "Qui a été tué ? Jacques l'ivrogne ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Et en quoi ça vous regarde ?";
			link.l1 = "Je travaille pour Stefan Lanven, et je dois savoir ce qui s'est passé ici.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Allez voir le commandant pour un laissez-passer. Sans laissez-passer, vous ne passez pas. Un point c'est tout.";
			link.l1 = "Argh ! Très bien, vous l'aurez, votre laissez-passer.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxJailOff");
		break;

		case "34":
			dialog.text = "Bonjour, capitaine " + sName + ". Vivant, et sans blessure ?";
			link.l1 = "Je vais très bien. Pas une égratignure.";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Et qu'est-ce que vous avez au bras ?";
			link.l1 = "Rien ...(tirant la manche sur son bras)... Une égratignure, ça guérira.";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Capitaine, cette plaie doit être lavée et pansée, sinon elle va s'infecter.";
			link.l1 = "וcoutez, je sais ce dont j'ai besoin et ce dont je n'ai pas besoin. C'est clair ?";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "Tout à fait clair, capitaine. Hé, c'est la deuxième fois que je vous sauve la vie. Vous pourriez être un peu plus aimable.";
			link.l1 = "Et comment avez-vous appris l'attent... notre venue, au fait ?";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "Comment avons-nous appris l'attentat contre Lanven et le gouverneur ? Facilement. Un homme est venu en courant tout raconter à Lanven. \nStefan me l'a transmis : par chance, j'étais à la résidence à cette heure-là, en conversation avec le gouverneur. J'ai tendu une embuscade, et à peine étions-nous prêts que vous êtes apparu avec Clive et sa bande.";
			link.l1 = "Mais si vous saviez qu'un attentat se préparait, vous deviez aussi connaître mon rכle.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Nous connaissions votre rכle, capitaine. Ou plutכt, nous savions qu'on vous y avait contraint. Nous étions sמrs que vous étiez toujours de notre cכté. Comme vous le voyez, nous ne nous sommes pas trompés.";
			link.l1 = "...(sèchement)... Ils en étaient sמrs, tiens. Et qu'est-ce qui vous rendait si sמrs ?";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "Deux choses, capitaine. L'homme qui a informé Lanven a décrit votre comportement à la taverne de La Vega. Il a dit qu'en sortant, vous avez murmuré, comme pour vous-même : « Je dois les arrêter, je ne peux pas laisser faire ça ».";
			link.l1 = "Je ne me souviens pas d'avoir dit quoi que ce soit de ce genre.";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Vous l'avez dit sans y penser, et vous ne l'avez peut-être pas remarqué. Heureusement que Clive n'a pas l'ouïe aussi fine que notre informateur.";
			link.l1 = "Vous avez parlé de deux choses. Quelle est la seconde ?";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "L'autre, c'est votre dette, capitaine. Vous devez la vie à Lanven, et vous étiez donc tenu d'essayer d'empêcher l'attentat contre lui et contre le gouverneur.";
			link.l1 = "C'est vrai, j'ai essayé. Mais vous m'avez devancé.";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Très bien, capitaine. Dites à Lanven que l'opération a réussi et que j'attends l'argent qu'il m'a promis.";
			link.l1 = "L'argent qu'il vous a promis ?";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Je n'ai pas risqué ma vie et celle de mes hommes pour rien.";
			link.l1 = "Et combien Lanven vous a-t-il promis pour me sauver ?";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Mille piastres par mousquetaire et vingt-cinq mille pour moi. Trente mille en tout. Vous coמtez cher à Lanven, capitaine.";
			link.l1 = "Je suis prêt à payer cette somme à la place de Lanven, commandant.";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Non, non. Lanven a promis de me payer, alors il paiera : c'est son principe. Même si vous me donniez cent mille maintenant, il me remettrait quand même ses trente mille. Par principe : chose promise, chose due.";
			link.l1 = "Bon sang, j'ai complètement oublié le laissez-passer ! Vous devez m'autoriser à entrer dans la maison de Brian George. Sur ordre de Lanven, je dois la fouiller.";
			link.l1.go = "50";
		break;

		case "50":
			TakeNItems(PChar, "MysteriousArtefact_Notice_1", 1);
			dialog.text = "...(il sort un papier et y écrit quelque chose)... Voici votre laissez-passer.";
			link.l1 = "Je vous suis très obligé, commandant.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxExitTownBattleWithTulipBandaEnd");
		break;

		case "51":
			dialog.text = "Vous avez apporté le laissez-passer ?";
			link.l1 = "Oui. Tenez, prenez-le.";
			link.l1.go = "52";
		break;

		case "52":
			TakeNItems(PChar, "MysteriousArtefact_Notice_1", -1);
			dialog.text = "Parfait. Maintenant, apportez-moi un laissez-passer de Lanven, et je vous laisserai entrer.";
			link.l1 = "Quoi ?! Vous avez dit de n'apporter que le laissez-passer du commandant. Personne n'a parlé de Lanven.";
			link.l1.go = "53";
		break;

		case "53":
			dialog.text = "Les choses ont changé. Maintenant, il faut aussi un laissez-passer de Lanven.";
			link.l1 = "Très bien, j'en apporterai un de Lanven aussi.";
			link.l1.go = "54";
		break;

		case "54":
			dialog.text = "Capitaine, je plaisantais. Il ne faut rien de plus, vous pouvez passer ...(il tourne la clé dans la serrure)...";
			link.l1 = "Gardez vos plaisanteries pour vous. Soldat bouché.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactHouseGeorgeBryanOpen");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
