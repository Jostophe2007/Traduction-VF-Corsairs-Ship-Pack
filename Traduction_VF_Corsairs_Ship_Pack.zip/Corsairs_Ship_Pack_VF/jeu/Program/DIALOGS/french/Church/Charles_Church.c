// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils","ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils","ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils","ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils","ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(PChar.MysteriousIsland == "3" && NPChar.City == "Charles")	// Загадочный остров
			{
				link.l1 = "Voilà. Dans une taverne, j'ai rencontré un marin étrange, Jim Smith. Après les terribles événements qu'il a vécus, il est dans un très mauvais état d'esprit.";
				link.l1.go = "MysteriousIsland_1";
			}
		break;
		
		// Загадочный остров -->
		case "MysteriousIsland_1":
			dialog.text = "Je vois de qui vous parlez. Je l'ai invité chez moi il y a longtemps, parce que deux de ses anciens camarades, qui avaient eux aussi pris part aux événements dont vous parlez, vivaient auprès de notre église. Je les ai aidés autant que j'ai pu, mais je n'ai pas su guérir leur âme.";
			link.l1 = "Oם sont-ils maintenant ?";
			link.l1.go = "MysteriousIsland_2";
		break;
		
		case "MysteriousIsland_2":
			dialog.text = "Au cimetière de la ville, Dieu ait leur âme !";
			link.l1 = "Dites-moi, père " + npchar.name+", ces deux défunts vous ont-ils laissé quelque chose avant de mourir ?";
			link.l1.go = "MysteriousIsland_3";
		break;
		
		case "MysteriousIsland_3":
			dialog.text = "Vous parlez d'un morceau de carte, "+ GetSexPhrase("mon fils","ma fille") +" ? Je vais vous décevoir : ils n'ont rien laissé de tel. Et je vous conseille de tout cœur de ne pas vous mêler de cette histoire !";
			link.l1 = "Père " + npchar.name+", je veux comprendre ce qui s'est passé.";
			link.l1.go = "MysteriousIsland_4";
		break;
		
		case "MysteriousIsland_4":
			dialog.text = "Eh bien, je vois que je ne peux pas vous en dissuader. Soyez sur vos gardes, "+ GetSexPhrase("mon fils","ma fille") +", et n'oubliez pas notre Seigneur !";
			link.l1 = "Merci, saint père !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandToCharlesTown");
		break;
		// <-- Загадочный остров
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}



