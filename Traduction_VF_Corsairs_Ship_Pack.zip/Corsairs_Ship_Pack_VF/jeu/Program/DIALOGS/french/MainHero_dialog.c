void ProcessDialogEvent()
{
	ref NPChar, mc;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    ref chr, rShip;
    float  fTemp;
    bool bOk;
	int i, iTemp;
	string sAttr;

	float dmg_min, dmg_max, weight;

	// генератор ИДХ по кейсу -->
	sAttr = Dialog.CurrentNode;
  	if (findsubstr(sAttr, "CabinCompanionTalk_" , 0) != -1)
 	{
        i = findsubstr(sAttr, "_" , 0);
	 	PChar.GenQuest.CabinCompanionNum = strcut(sAttr, i+1, strlen(sAttr)-1); // индех в конце
 	    Dialog.CurrentNode = "Cabin_Companion_Talk";
 	}

// Вызов персонажей by xxxZohanxxx -->
  	if (findsubstr(sAttr, "CabinPassengerTalk_" , 0) != -1)
 	{
        i = findsubstr(sAttr, "_" , 0);
		PChar.GenQuest.CabinPassengerNum = strcut(sAttr, i+1, strlen(sAttr)-1); // индекс в конце
 	    Dialog.CurrentNode = "Cabin_Passenger_Talk";
 	}
// <-- Вызов персонажей by xxxZohanxxx
 	// генератор ИДХ по кейсу <--

	switch(Dialog.CurrentNode)
	{
        case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
		break;

		case "WhisperTownbattle_1":
				dialog.Text = "Intéressant, votre chapeau\n(Astuce : pour ramasser le reste des objets, appuyez sur la touche 1 au-dessus du cadavre)";
				Pchar.model="PGG_Whisper_0";
				pchar.Whisper.HatEnabled = true;
				TakeNItems(PChar, "hatWhisper", 1);
				EquipCharacterByItem(pchar, "hatWhisper");
				ChangeWhisperHeroModel();
				Link.l1 = "Pardon pour ce qui s'est passé, mon vieux. J'espère que tu ne m'en veux pas.";
				Link.l1.go = "exit_WhisperTownbattle";
		break;

		case "exit_WhisperTownbattle":
			NextDiag.CurrentNode = NextDiag.TempNode;
			WhisperPirateTownBattleMortality();
			DialogExit_Self();
		break;
		case "exit_WhisperIncq":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			DoQuestFunctionDelay("WhisperLine_WhisperHits_3", 3.00);
		break;
		case "exit_WhisperAddWidow":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();

			mc = GetMainCharacter();

			mc.Ship.Type = GenerateShipExt(SHIP_VEINARD, true, mc);
			mc.Ship.name="La Veuve noire";
			SetBaseShipData(mc);
			mc.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS10;
			SetCrewQuantityFull(mc);

            SetCharacterGoods(mc,GOOD_FOOD,200);
        	SetCharacterGoods(mc,GOOD_BALLS,300);//2000);
        	SetCharacterGoods(mc,GOOD_MEDICAMENT,300);//2000);
            SetCharacterGoods(mc,GOOD_GRAPES,300);//700);
            SetCharacterGoods(mc,GOOD_KNIPPELS,300);//700);
            SetCharacterGoods(mc,GOOD_BOMBS,300);//1500);
            SetCharacterGoods(mc,GOOD_POWDER,1000);
            SetCharacterGoods(mc,GOOD_PLANKS,50);
            SetCharacterGoods(mc,GOOD_SAILCLOTH,50);
            SetCharacterGoods(mc,GOOD_RUM,40);//600);
            SetCharacterGoods(mc,GOOD_WEAPON,200);//2000);
            SetCharacterGoods(mc,GOOD_EBONY,100);//2000);
		break;
		case "Exit_incq":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DoQuestFunctionDelay("WhisperLine_Inquisition", 2.0);
			WaitDate("", 0, 0, 3, 2, 30);
			DialogExit_Self();
		break;
		case "Exit_Special":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			pchar.SystemInfo.ChangePIRATES = true;
			LaunchCharacter(pchar);
		break;

		// LEO: start without a ship - a thought ashore, then character build (Exit_Special opens it)
		case "Tut_NoShipStart":
			NextDiag.TempNode = "TalkSelf_Main";
			Dialog.Text = "Me voilà donc à terre. Pas de navire, pas d'équipage sous la main : juste moi et ce que j'ai réussi à apprendre. Bon, il est temps de décider ce que je vaux.";
			Link.l1 = "(Répartir les caractéristiques)";
			Link.l1.go = "Exit_Special";
		break;

		case "First time":
	      	NextDiag.TempNode = "First time";

	        Dialog.Text = "Si vous lisez ces lignes, c'est qu'il y a manifestement un bug quelque part dans le code";
			Link.l1 = "Exit";
			Link.l1.go = "exit";

			//ОЗГ
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
	    		if (pchar.questTemp.Headhunter == "halen_room")
        		{
        		    dialog.text = "Bon, on peut se reposer pour l'instant. Il faut que je dorme bien cette nuit...";
        			link.l1 = "...";
        			link.l1.go = "exit";
		    		AddDialogExitQuestFunction("RatHunters_Sleep");
        		}
			}
 			//===> Квесты мэра, базар после боевки на палубе
			if (CheckAttribute(pchar, "quest.DestroyPirate_PirateIsOut") || CheckAttribute(pchar, "quest.CaptainComission_CapIsOut"))
			{
				dialog.text = "Il est temps de filer d'ici avant que Cap ne revienne avec le reste de l'équipe...";
				Link.l1 = "...";
    			Link.l1.go = "exit";
				pchar.quest.Munity = "Deads";
			}
			// ==> Английская линейка, квест №8: в поселении буканьеров
   	    	if (pchar.questTemp.State == "ToMansfield_GoOn")
    		{
    		    dialog.text = "Diable !!! Que s'est-il passé ici ? Il faut que j'essaie de trouver au moins quelqu'un de vivant...";
    			link.l1 = "...";
    			link.l1.go = "exit";
				chrDisableReloadToLocation = false;//снимаем блок перехода
    		}
            // ==> Исп. линейка, квест №4: в спальне донны Анны
            if (pchar.questTemp.State == "Sp4Detection_toMirderPlace")
    		{
    		    dialog.text = "Hum, une lettre étrange. Elle a été informée de l'arrivée d'un homme... Et qui a pu la prévenir ? Quelqu'un dont la visite n'attirerait pas l'attention des domestiques ! Ce ne peut être qu'un habitant du coin. Il faut que je trouve et que j'interroge l'habitant qui a prévenu Donna Anna.";
    			link.l1 = "...";
    			link.l1.go = "exit";
                pchar.questTemp.State = "Sp4Detection_FoundLetter";
                AddQuestRecord("Spa_Line_4_MirderDetection", "2");
				AddQuestUserData("Spa_Line_4_MirderDetection", "sSex", GetSexPhrase("", "e"));
    		}
            // ==> Французская линейка, квест №2: в таверне Тортуги
   	    	if (pchar.questTemp.State == "Fr2Letter_SeekProblems")
    		{
    		    dialog.text = "Un drכle de couple, tout de même... Il faudrait peut-être voir oם ils sont allés...";
    			link.l1 = "...";
    			link.l1.go = "exit";
				pchar.questTemp.Out = 1;
				SaveCurrentQuestDateParam("questTemp");
    		}
			// ==> Изабелла, нашли мёртвую служанку
   	    	if (pchar.RomanticQuest == "SeekIsabella" && pchar.location == "Beliz_ExitTown")
    		{
    		    dialog.text = "On dirait que c'est la servante de Rosita... Les affaires de Salvator sont faciles à reconnaître : des cadavres innocents partout. Je suis donc sur la bonne piste.";
    			link.l1 = "...";
    			link.l1.go = "exit";
				pchar.RomanticQuest = "FoundServantGirl";
				characters[GetCharacterIndex("ServantGirl")].LifeDay = 0;
    		}
			// ==> Квест Аскольда, обнаружение входа в пещеру к гробнице
			if (pchar.questTemp.Ascold == "Ascold_NotEnterFoundGrave")
			{
				dialog.text = "Oui, il y a clairement une entrée quelque part. Mais elle est cachée par un poêle. Impossible de passer.";
				link.l1 = "";
				link.l1.go = "exit";
			}
			//===> Квест Аскольда, попытка вскрыть лампу.
			if (pchar.questTemp.Azzy == "Azzy_IHaveLamp" && locations[reload_location_index].type == "shipyard")
			{
				dialog.text = "Oui, c'est ce qu'il me faut : un chalumeau, une broche, des cisailles à tכle... On peut commencer l'opération...";
				Link.l1 = "Utiliser les outils.";
    			Link.l1.go = "FreedomAzzy";
			}
			//===> шебека Синяя Птица
			if (pchar.questTemp.BlueBird == "seenCarriers")
			{
				dialog.text = "Tiens, j'entends du bruit. Je vais rester ici et voir ce qui se passe...";
				Link.l1 = "...";
    			Link.l1.go = "exit";
				AddDialogExitQuestFunction("BlueBird_endCaveDialog");
			}
			//Квест нежити на перерождение
			if (CheckAttribute(pchar, "questTemp.HellSpawn.Rebirth"))
			{
				dialog.Text = "(Sur l'un des adversaires abattus, vous trouvez un bout de papier couvert d'un texte, ainsi qu'une fiole au contenu étrange)\nOn dirait que, pour renaître, je dois boire la potion et lire ce texte à voix haute.";
				bMonstersGen = true;
				DeleteAttribute(pchar, "questTemp.HellSpawn.Rebirth");
				Link.l1 = "(accomplir le rituel)";
				Link.l1.go = "HellSpawn_Ritual";
				Link.l2 = "Non, ma forme actuelle me convient tout à fait.";
				Link.l2.go = "exit";
			}
			//Старт за Шарпов
			if (CheckAttribute(pchar, "questTemp.Sharp.Entered_Shore"))
			{
				dialog.Text = "D'après les indices de la carte, le trésor doit se trouver quelque part par ici.";
				bMonstersGen = true;
				DeleteAttribute(pchar, "questTemp.Sharp.Entered_Shore");
				Link.l1 = "Il faut trouver la grotte.";
				Link.l1.go = "Exit_Special";
			}
			//Старт за Мэри и Шарля
			if (CheckAttribute(pchar, "questTemp.SharleMary.Entered_Shore"))
			{
				dialog.Text = "Mère du Ciel, quelle tempête... Du sang... J'ai la tête fendue... Bon sang, tout est flou. "+GetSexPhrase("Mary ! Oם est Mary ?!", "Charles ! Oם est Charles ?!")+" Pas une planche sur le sable, pas un cadavre. La Fortune a coulé ou dérive quelque part en mer. Que le diable les emporte tous !";
				DeleteAttribute(pchar, "questTemp.SharleMary.Entered_Shore");
				Link.l1 = "Je dois retrouver "+GetSexPhrase("Mary.", "Charles.");
				Link.l1.go = "Exit_Special";
			}
			if (CheckAttribute(pchar, "questTemp.SharleMary.Death"))
			{
				dialog.Text = "Oh... "+GetSexPhrase("Pauvre Mary...", "Pauvre Charles...")+" Je n'ai pas pu te sauver.";
				chrDisableReloadToLocation = false;
				DeleteAttribute(pchar, "questTemp.SharleMary.Death");
				Link.l1 = "Je ne sais pas si je pourrai continuer à vivre après ça. Je vais aller sur la plage, peut-être que quelqu'un d'autre a survécu.";
				Link.l1.go = "Exit";
			}
			//Старт за нежить
			if (CheckAttribute(pchar, "questTemp.Undead.Leave_Crypt"))
			{
				dialog.Text = "Miktu... Meketlu... M... Qu'est-ce qui m'arrive ? Je sens que je dois quitter cet endroit. J'entends l'appel. Les autres. Ils attendent, enfermés. Je n'ai pas la force de résister. J'arrive, dieu des morts. J'arrive.";
				DeleteAttribute(pchar, "questTemp.Undead.Leave_Crypt");
				Link.l1 = "Il vaudrait mieux enfiler ces vêtements discrets avant de rendre visite au monde des vivants.";
				Link.l1.go = "Exit_Special";
			}
			//Линейка Виспер
			if (CheckAttribute(pchar, "questTemp.Whisper.Entered_Dungeon"))
			{
				dialog.Text = "Les coordonnées correspondent. Je crois que je suis en position\nOn dirait une sorte de galerie souterraine. C'est l'endroit idéal si on ne veut pas montrer son visage devant les caméras.";
				bMonstersGen = true;
				DeleteAttribute(pchar, "questTemp.Whisper.Entered_Dungeon");
				sld = characterFromId("AntonioDeSouza");
				sld.lifeday = 0;
				PChar.quest.PDM_ONV_Nachalo.over = "yes";	//квест "охота на ведьму" недоступна для Виспер
				DeleteAttribute(pchar, "questdata.OhotaNaVedmu");
				if (bBettaTestMode)
                {
			        link.l1 = "Bêta-test : passer et commencer la partie.";
			        link.l1.go = "Whisper_Finish";
					Link.l2 = "(relire le message du client)";
					Link.l2.go = "Whisper_mission_1";

                }
				else
				{
					Link.l1 = "(relire le message du client)";
					Link.l1.go = "Whisper_mission_1";
				}
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.Inside_Incquisition"))
			{
				dialog.Text = "Bon sang, quel boucan ! En plus, cette « arme » a volé en éclats après le tir. Oh, je donnerais n'importe quoi pour mon fidèle fusil à pompe en ce moment...";
				DeleteAttribute(pchar, "questTemp.Whisper.Inside_Incquisition");
				Link.l1 = "Il faut récupérer le sabre sur le cadavre avant que les autres gardes n'accourent. On dirait qu'on va devoir se frayer un chemin par la force.";
				Link.l1.go = "exit_WhisperIncq";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.Escaped_Incquisition"))
			{
				dialog.Text = "Je crois que j'ai semé mes poursuivants. J'ai dמ fuir la ville\nEntre autres choses, le geכlier avait une carte de l'île. Elle indiquait la colonie de Puerto Príncipe, qui se trouve près d'ici.";
				DeleteAttribute(pchar, "questTemp.Whisper.Escaped_Incquisition");
				Link.l1 = "דa vaut la peine d'y tenter ma chance.";
				Link.l1.go = "exit";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.Near_Chest"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.Near_Chest");

				dialog.Text = "Parfait, j'ai l'appareil. Maintenant, il est temps de filer d'ici.";
				Log_Info("Vous avez trouvé le redresseur d'horloge quantique.");
				Link.l1 = "...";
				Link.l1.go = "exit";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.HoldMonologue"))
			{
				string sTemp = ""
				DeleteAttribute(pchar, "questTemp.Whisper.HoldMonologue");
				if (CheckAttribute(pchar, "Whisper.Podralas"))
				{
					pchar.Whisper.PodralasCheck = true;
				}
				dialog.Text = "Bon sang ! Il ne manquait plus que ça : me voilà projeté dans le passé, la machine à remonter le temps est endommagée et se trouve, avec toutes mes affaires, entre les griffes de ces brutes crasseuses. En plus, je suis aux mains de mes geכliers, et dans les prochains jours, on va sמrement m'exécuter."+sTemp;
				Link.l1 = "Il faut que je me prépare. Je sortirai d'ici, tכt ou tard.";
				Link.l1.go = "exit_incq";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.GetHat"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.GetHat");
				dialog.Text = "Bon sang ! Les balles sifflent de partout !\nPardon, mon vieux, mais je t'emprunte tes affaires : j'en ai plus besoin que jamais en ce moment.";

				Link.l1 = "";
				Link.l1.go = "WhisperTownbattle_1";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.AfterTownBattle"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.AfterTownBattle");
				dialog.Text = "On dirait qu'on les a repoussés. Dommage que tant de gens soient morts\nIl disait qu'un navire l'attendait. דa vaut la peine d'essayer de monter à bord, car les Espagnols pourraient revenir ici à tout moment avec des renforts.";
				Link.l1 = "Il faut que je trouve une crique.";
				Link.l1.go = "exit_WhisperAddWidow";
				PChar.quest.WhisperPirateTownBattle.win_condition.l1 = "location";
				PChar.quest.WhisperPirateTownBattle.win_condition.l1.location = "PuertoPrincipe_Port";
				PChar.quest.WhisperPirateTownBattle.function = "WhisperMeetCrew";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.SmugPatrol"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.SmugPatrol");
				dialog.Text = "Je le savais ! Bien sמr que les patrouilles viennent ici : ce marchand m'a raconté des salades.";
				Link.l1 = "Il faut que je me dépêche de monter sur le pont avant que mon navire soit coulé.";
				Link.l1.go = "exit";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.Portman_Deck"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.Portman_Deck");
				dialog.Text = "Je ne pense pas apprendre quoi que ce soit en errant sur le pont, et on ne me laissera pas entrer dans la cabine.";
				Link.l1 = "Il n'y a qu'une solution : l'abordage.";
				Link.l1.go = "exit";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.KilledPortman"))
			{
				DeleteAttribute(pchar, "questTemp.Whisper.KilledPortman");
				AddQuestRecord("WhisperChardQuest", "7");
				pchar.Whisper.FoundPortmanJournal = true;
				dialog.Text = "Hum... Il y a aussi une sorte de chiffre dans le journal de bord. Je ne pense pas pouvoir le déchiffrer par moi-même.";
				Link.l1 = "Il faut l'apporter à Chard.";
				Link.l1.go = "exit";
			}
			if (CheckAttribute(pchar, "questTemp.Whisper.EngRevenge"))
			{
				AddQuestRecord("WhisperChardQuest", "9");
				CloseQuestHeader("WhisperChardQuest");
				DeleteAttribute(pchar, "questTemp.Whisper.EngRevenge");
				dialog.Text = "On dirait que la mort de Portman a mis les Anglais en colère. Je vois déjà des navires à l'horizon.";
				Link.l1 = "Il faut vite rejoindre la chaloupe.";
				Link.l1.go = "exit";
			}
			//Линейка Виспер
		break;
		// boal -->
		case "TalkSelf_Main":
	   		NextDiag.TempNode = "First time";
			// Gregg: "Two Sisters" - the barred hold door of the Cerebus. The items screen
			// is shut while in captivity, so the hairpin cannot be used from inventory;
			// this is the only way into the lockpicking.
			if (CheckAttribute(pchar, "TwoSisters.CanPickDoor"))
			{
				if (pchar.location == "Cerebus_Hold")
				{
					Dialog.Text = "La porte est barrée de l'extérieur. La serrure est une simple serrure d'entrepכt : on en met sur les réserves, pas sur les cellules. Une épingle à cheveux devrait suffire.";
					link.l1 = "Essayer de la crocheter.";
					link.l1.go = "TwoSisters_PickDoor";
					link.l2 = "Pas maintenant.";
					link.l2.go = "exit";
					break;
				}
			}
//navy --> after duel in tavern
			if (CheckAttribute(pchar, "questTemp.LocationClone"))
			{
				Dialog.Text = RandPhraseSimple("Quel combat acharné... Maintenant, on peut rappeler les lâches qui se sont enfuis.", "Ha ! C'était facile. Et ces rats de terre ont pris la fuite !");
				link.l1 = "...";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "questTemp.LocationClone");
				break;
			}
//navy <--
	        Dialog.Text = RandPhraseSimple("Hum... Qu'est-ce que j'aimerais faire maintenant ?", "Que voulez-vous faire ?");
		if(!bDisableMapEnter && !CheckAttribute(pchar, "GenQuest.CannotWait") && CheckSaveGameEnabled() == true) // 21.03.09 Warship fix Во время линейки Блада отдыхать нельзя
	    {
				if(PChar.Dozor != "0" && PChar.Dozor != "END")
				{
					if(sti(PChar.Dozor.Riddle.CanInterface) == 1)
					{
							link.l4 = "La tâche actuelle du mécachrome.";
							link.l4.go = "Dozor_MekaKhrom";
					}
				}
		}
	        if (!bDisableMapEnter && pchar.location == Get_My_Cabin())
	        {
	        	// Для отдыха теперь есть отдельный интерфейс
	            if (makeint(environment.time) >= 22.0 || makeint(environment.time) < 10.0)
	    		{
	    			link.l1 = "Se reposer jusqu'au matin.";
	    			link.l1.go = "TalkSelf_room_day";
	    		}
	    		else
	    		{
	    			link.l1 = "Se reposer jusqu'à la tombée de la nuit.";
	    			link.l1.go = "TalkSelf_room_night";
	    			link.l2 = "Se reposer jusqu'au lendemain matin.";
					link.l2.go = "TalkSelf_room_day";
	    		}
				//navy --> 13.02.08
				if (!bDisableMapEnter && pchar.location == Get_My_Cabin())
				{
// Вызов персонажей by xxxZohanxxx -->
					link.l3 = "Faire venir...";
					link.l3.go = "Cabin_PersonSelect";
// <-- Вызов персонажей by xxxZohanxxx
				}
				//navy <--
			}
			else
			{   //исп.линейка, квест №6, возможность переночевать в оплаченной комнате
				if (CheckAttribute(pchar, "questTemp.State.Open") && pchar.location == "Tortuga_tavern_upstairs")
				{
					if (makeint(environment.time) >= 22.0 || makeint(environment.time) < 10.0)
	    			{
	    				link.l1 = "Se reposer jusqu'au matin.";
	    				link.l1.go = "TalkSelf_room_day";
	    			}
	    			else
	    			{
	    				link.l1 = "Se reposer jusqu'à la tombée de la nuit.";
	    				link.l1.go = "TalkSelf_room_night";
	    				link.l2 = "Se reposer jusqu'au lendemain matin.";
						link.l2.go = "TalkSelf_room_day";
	    			}
				}
			}
	        if (!bDisableMapEnter)//боя в море нет
	        {
	            if (GetCargoGoods(pchar, GOOD_SLAVES) > 0)
	            {
	                Link.l5 = "Enrכler les esclaves dans l'équipage";
	        		Link.l5.go = "TalkSelf_SlavesToCrew";
	    		}
	        }
	        // захват города
	        if (GetCharIDXForTownAttack(pchar.location) != -1 && !CheckAttribute(Pchar, "GenQuestFort.StartAttack"))
	        {
	            Link.l6 = "Lancer la prise de la ville la plus proche.";
	    		Link.l6.go = "TalkSelf_TownAttack";
	        }

			if(PChar.ColonyBuilding.Stage != "0" && PChar.ColonyBuilding.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman")
					{
						Link.l18 = "Hum... Il faut nommer au plus vite un gouverneur pour la colonie '" + PChar.ColonyBuilding.ColonyName + "'. Peut-être que je peux m'en charger moi-même ?";
						Link.l18.go = "ColonyBuilding_Hovernor_1";
					}
				}
			}

			if(PChar.ColonyBuilding.Hovernor == PChar.id)
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman")
					{
						Link.l19 = "S'occuper des affaires de la colonie.";
						Link.l19.go = "ColonyBuilding_Hovernor";
					}
				}
			}

			if(PChar.Dozor != "0" && PChar.Dozor != "END")
			{
				if(sti(PChar.Dozor.Riddle.CanInterface) == 1)
				{
		    			link.l10 = "La tâche actuelle du mécachrome.";
		    			link.l10.go = "Dozor_MekaKhrom";
				}
			}

			if (!CheckAttribute(pchar, "questTemp.stels.sea")) pchar.questTemp.stels.sea = 0;
			bool isBloodPrologue = false;
			if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true) isBloodPrologue = true;
	        if (pchar.location != Get_My_Cabin() && !isBloodPrologue && !CheckAttribute(pchar, "DisableChangeFlagMode") && sti(pchar.questTemp.stels.sea) != GetDataDay() && CheckSaveGameEnabled() == true)
			{
				Link.l7 = "Donner l'ordre de changer de pavillon.";
				Link.l7.go = "TalkSelf_ChangeFlag";
			}
	        if(!bDisableMapEnter && !isBloodPrologue && PChar.location != "Deck_Near_Ship" && findsubstr(PChar.location, "_shipyard" , 0) == -1 && PChar.location != "CommonPackhouse_2" && !CheckAttribute(pchar, "GenQuest.CannotWait") && !CheckAttribute(pchar, "ContraInterruptWaiting")) // 21.03.09 Warship fix Во время линейки Блада отдыхать нельзя
	        {
	        	Link.l8 = "Je prendrais bien une pause...";
	    		Link.l8.go = "TalkSelf_StartWait";
	    	}
			if (!CheckAttribute(pchar, "bookreadtoday") && (GetCharacterEquipByGroup(pchar, BOOK_ITEM_TYPE)) != "" && !bDisableMapEnter && !isBloodPrologue && PChar.location != "Deck_Near_Ship" && findsubstr(PChar.location, "_shipyard" , 0) == -1 && PChar.location != "CommonPackhouse_2" && !CheckAttribute(pchar, "GenQuest.CannotWait")) // 21.03.09 Warship fix Во время линейки Блада отдыхать нельзя
	        {
	        	Link.l9 = "Lire un livre.";
	    		Link.l9.go = "ReadBook";
	    	}
			Link.l10 = "Définir la priorité d'utilisation des vivres.";
	    	Link.l10.go = "food_priority";
			if (pchar.location == Get_My_Cabin())
			{
				Link.l11 = "Utiliser les vivres automatiquement.";
				Link.l11.go = "autofood";
				if(CheckAttribute(pchar, "autofood"))
				{
					Link.l11 = "Arrêter l'utilisation automatique des vivres.";
					Link.l11.go = "autofood_stop";
				}
			}
			if (CheckAttribute(pchar, "usepotionbest"))
			{
				link.lpotion = "Retirer la priorité d'utilisation des meilleurs médicaments.";
				Link.lpotion.go = "potion_priority";
			}
			else
			{
				link.lpotion = "Donner la priorité à l'utilisation des meilleurs médicaments.";
				Link.lpotion.go = "potion_priority";
			}
			if (pchar.location == Get_My_Cabin())
			{
				link.lcompanioncapture = "Donner aux compagnons des instructions sur le sort des prises lors des abordages.";
				if (CheckAttribute(PChar, "CompanionsLeaveCapturesDrift"))
				{
					link.lcompanioncapture = link.lcompanioncapture + " Leur ordonner d'agir à l'ancienne : changer de navire si nécessaire, piller vite et couler la prise.";
				}
				else
				{
					link.lcompanioncapture = link.lcompanioncapture + " Leur ordonner de laisser le navire capturé à la dérive.";
				}
				link.lcompanioncapture.go = "companion_capture";
			}
			if (findsubstr(PChar.location, "_church" , 0) != -1)
            {
				Link.lfixbag = "Prier Dieu. (corriger des bugs)";
				Link.lfixbag.go = "fixbag";
            }
			if(startHeroType == 2)
			{
				if(CheckCharacterItem(pchar, "hatWhisper"))
				{
					if (!CheckAttribute(pchar, "Whisper.Equipped"))
					{
						Link.lWhisperHat = "Ne plus porter de chapeau.";
						Link.lWhisperHat.go = "WhisperHatUnequip";
					}
					else
					{
						Link.lWhisperHat = "Porter un chapeau.";
						Link.lWhisperHat.go = "WhisperHatEquip";
					}
				}
				if(CheckCharacterItem(pchar, "glasses"))
				{
					if (IsEquipCharacterByItem(pchar, "glasses"))
					{
						Link.lWhisperGlasses = "Ne plus porter de lunettes.";
						Link.lWhisperGlasses.go = "WhisperGlassesUnequip";
					}
					else
					{
						Link.lWhisperGlasses = "Porter des lunettes.";
						Link.lWhisperGlasses.go = "WhisperGlassesEquip";
					}
				}
				Link.lWhisperPortrait = "Changer de portrait.";
				Link.lWhisperPortrait.go = "WhisperPortrait";
			}

			if (bBettaTestMode)
			{
				Link.l12 = "Régler le temps sur la carte globale. (la valeur doit être un nombre décimal)";
				Link.l12.go = "WorldmapTime";

				Link.l13 = "Modifier la lame équipée.";
				Link.l13.go = "BladeModify";
			}

			Link.lSmugglingFlag = "Lors des transactions de contrebande, hisser automatiquement le pavillon pirate en cas d'attaque d'une patrouille.";
			Link.lSmugglingFlag.go = "SmugglingFlag";
			
			bool bOk2 = GetBaseHeroNation() == PIRATE || CheckOfficersPerk(pchar, "Builder");
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && Pchar.location.from_sea == loadedLocation.id && bOk2)
			{
				Link.selfrepair = "Commencer les réparations par nos propres moyens.";
				Link.selfrepair.go = "exitrepair";
			}
			
			if (CheckAttribute(pchar, "SmugglingFlag"))
			{
				Link.lSmugglingFlag = "Désactiver le changement automatique de pavillon lors des transactions de contrebande.";
				Link.lSmugglingFlag.go = "SmugglingFlag";
			}
			if (CheckAttribute(loadedLocation, "id"))
			{
				if (loadedLocation.id == "SanGabrielMechanic" && CheckAttribute(pchar, "VedekerDiscount"))
				{
					Link.lhenric = "Demander à Henrik de préparer le scaphandre pour une nouvelle plongée.";
					Link.lhenric.go = "RechargeCostume";
				}
			}
			Link.l14 = RandPhraseSimple("Pas maintenant. Pas le temps.", "Pas le temps. Des affaires m'attendent.");
			Link.l14.go = "exit";
		break;
				
		case "exitrepair":
			DialogExit();
			LaunchRepair(pchar);
		break;

		case "SmugglingFlag":
			if (CheckAttribute(pchar, "SmugglingFlag")) DeleteAttribute(pchar, "SmugglingFlag");
			else pchar.SmugglingFlag = true;
			Dialog.Text = "C'est fait.";
			Link.l12 = "On en a fini avec ça.";
			Link.l12.go = "exit";
		break;
// Вызов персонажей by xxxZohanxxx -->
		case "Cabin_PersonSelect":
				Dialog.Text = "Qui exactement ?";
				if (!bDisableMapEnter && GetCompanionQuantity(PChar) > 1)
				{
    				link.l1 = "Un compagnon.";
    				link.l1.go = "Cabin_CompanionSelect";
				}
				if (!bDisableMapEnter)
				{
					if (sti(pchar.Fellows.Passengers.navigator) != -1 || sti(pchar.Fellows.Passengers.boatswain) != -1 || sti(pchar.Fellows.Passengers.cannoner) != -1 || sti(pchar.Fellows.Passengers.doctor) != -1 || sti(pchar.Fellows.Passengers.treasurer) != -1 || sti(pchar.Fellows.Passengers.carpenter) != -1)
					{
					link.l2 = "Un officier.";
    				link.l2.go = "Cabin_OfficerSelect";
					}
				}
				if (!bDisableMapEnter)
				{
					link.l3 = "Un passager.";
    				link.l3.go = "Cabin_PassengerSelect";
				}
			link.l4 = "Une autre fois.";
			link.l4.go = "exit";
		break;
// <-- Вызов персонажей by xxxZohanxxx

		case "WorldmapTime":
			Dialog.Text = "וcrivez la valeur décimale sous la forme x.x, de préférence pas plus de 12.0, sinon il pourrait y avoir des problèmes et des bugs.";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "WorldmapTime_Change";
		break;

		case "WorldmapTime_Change":
			if (stf(GetStrSmallRegister(dialogEditStrings[1])) > 0.0 && stf(GetStrSmallRegister(dialogEditStrings[1])) < 12.1) pchar.wmtimechange = stf(GetStrSmallRegister(dialogEditStrings[1]));
			else pchar.wmtimechange = 0.5;
			if (stf(pchar.wmtimechange) != 0.5) Dialog.Text = "La vitesse de la carte globale est réglée sur "+pchar.wmtimechange+".";
			else Dialog.Text = "La valeur standard est réglée sur 0.5.";
			worldMap.date.hourPerSec = stf(pchar.wmtimechange);
			Link.l1 = "Parfait.";
			Link.l1.go = "exit";
		break;

		case "BladeModify":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			if (sAttr == "")
			{
				Dialog.Text = "Pourquoi faites-vous ça ? Vous savez bien que vous n'avez pas de lame équipée.";
				link.l1 = "Comme ça, je voulais casser le jeu...";
				link.l1.go = "exit";
			}

			sAttr = GetBladeParams(sAttr, &dmg_min, &dmg_max, &weight);
			iTemp = LanguageOpenFile("ItemsDescribe.txt");
			rShip = ItemsFromID(sAttr);

			Dialog.Text = "Votre lame : " + LanguageConvertString(iTemp, rShip.name) + ", dégâts " + dmg_min + "/" + dmg_max + ", poids " + weight + ". Choisissez une action : augmenter ou diminuer les caractéristiques de l'arme dans les limites autorisées, ou simplement générer une arme surpuissante.";
			link.l1 = "Réduire les dégâts minimum de 1.";
			link.l1.go = "BladeModifyDecMinDmg";
			link.l2 = "Augmenter les dégâts minimum de 1.";
			link.l2.go = "BladeModifyIncMinDmg";
			link.l3 = "Réduire les dégâts maximum de 1.";
			link.l3.go = "BladeModifyDecMaxDmg";
			link.l4 = "Augmenter les dégâts maximum de 1.";
			link.l4.go = "BladeModifyIncMaxDmg";
			link.l5 = "Réduire le poids de 0,05.";
			link.l5.go = "BladeModifyDecWeight";
			link.l6 = "Augmenter le poids de 0,05.";
			link.l6.go = "BladeModifyIncWeight";
			link.l7 = "Créer une super-arme.";
			link.l7.go = "BladeModifyCreateSuper";
			Link.l8 = "דa suffit.";
			Link.l8.go = "exit";

			LanguageCloseFile(iTemp);
		break;

		case "BladeModifyDecMinDmg":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, -1, 0, 0);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyIncMinDmg":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, 1, 0, 0);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyDecMaxDmg":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, 0, -1, 0);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyIncMaxDmg":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, 0, 1, 0);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyDecWeight":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, 0, 0, -0.05);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyIncWeight":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = ModifyGeneratedBlade(sAttr, 0, 0, 0.05);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "C'est fait.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "BladeModify";
		break;

		case "BladeModifyCreateSuper":
			sAttr = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sAttr);
			sAttr = GenerateBladeByParams(GetOriginalItem(sAttr), 200, 1000, 0.1);
			GiveItem2Character(PChar, sAttr);
			EquipCharacterByItem(PChar, sAttr);
			Dialog.Text = "Oh, vous ne devriez pas... Bon, voilà ce que vous avez commandé.";
			link.l1 = "Allez, donne, et ne discute pas avec Terminator.";
			link.l1.go = "BladeModify";
		break;

		case "HellSpawn_Ritual"://перерождение
			Dialog.Text = "(quelque chose a changé en vous).";
			pchar.Ritual.ModelChanged = false;
			pchar.faceid = "43";
			pchar.sex = "man";
			pchar.animation = "man";
			pchar.model = "PGG_Skeletman_0";
			pchar.HeroModel  = "PGG_Skeletman_0,PGG_Skeletman_1,PGG_Skeletman_2,PGG_Skeletman_3,PGG_Skeletman_4,PGG_Skeletman_5,PGG_Skeletman_6,PGG_Skeletman_7,PGG_Skeletman_8";
			pchar.Ritual.ModelChanged = true;
			SetNewModelToChar(pchar);
			link.l1 = "Je ne me sens pas bien. Je vais prendre l'air.";
			Link.l1.go = "exit";
		break

		case "autofood":
			Dialog.Text = "Entrez le pourcentage auquel l'énergie doit descendre avant de commencer à consommer des vivres (10-90).";
			//PChar.autofood_use
			link.l1 = "";
			Link.l1.edit = 3;
			Link.l1.go = "autofood_percentage";
		break

		case "autofood_stop":
			DeleteAttribute(pchar, "autofood");
			DeleteAttribute(pchar, "autofood_use");
			dialog.text = "L'utilisation automatique des vivres est désactivée.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "exit";
		break

		case "autofood_percentage":
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp < 10 || iTemp > 90)
			{
				dialog.text = "Je n'ai pas toute ma tête aujourd'hui... Une autre fois, peut-être.";
				link.l1 = "Diable !";
				link.l1.go = "exit";
				break;
			}
			PChar.autofood_use = iTemp;
			dialog.text = "L'utilisation automatique des vivres est activée.";
			pchar.autofood = true;
			link.l1 = "Parfait !";
			link.l1.go = "exit";
		break;

		case "food_priority":
			dialog.text = "Quels vivres dois-je utiliser en priorité ?";
			link.l1 = "Les moins nourrissants (fruits, pain)";
			link.l1.go = "autofood_finished";
			link.l2 = "Les plus nourrissants (poisson, viande)";
			link.l2.go = "autofood_finished_betterfood";
		break;

		case "potion_priority":
			if (CheckAttribute(pchar, "usepotionbest"))
			{
				dialog.text = "La priorité d'utilisation des meilleurs médicaments a été retirée.";
				link.l1 = "Parfait !";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "usepotionbest");
			}
			else
			{
				dialog.text = "La priorité d'utilisation des meilleurs médicaments a été définie.";
				link.l1 = "Parfait !";
				link.l1.go = "exit";
				pchar.usepotionbest = true;
			}
		break;

		case "autofood_finished":
			dialog.text = "La priorité des vivres est définie.";
			DeleteAttribute(pchar, "betterfood");
			link.l1 = "Parfait !";
			link.l1.go = "exit";
		break;

		case "autofood_finished_betterfood":
			dialog.text = "La priorité des vivres est définie.";
			PChar.betterfood = true;
			link.l1 = "Parfait !";
			link.l1.go = "exit";
		break;

		case "fixbag":
			dialog.text = "Quel bug allons-nous corriger ?";

			link.l99 = "Terminer la prière.";
			link.l99.go = "exit";
		break

		case "fixbagPP":
			dialog.text = "Le bug a été corrigé.";
			link.l1 = "Amen !";
			link.l1.go = "exit";
			pchar.molitva.bagPP = true;
			Islands[FindIsland("Cuba1")].reload.l5.emerge = "reload1";
		break;
		case "fixbagDMU":
			dialog.text = "Un usurier a été ajouté à Des Moines.";
			link.l1 = "Amen !";
			link.l1.go = "exit";
			pchar.molitva.bagDMU = true;

			ref rLoc = LocFromID("DesMoines_Hut2");//реинит домика
			DumpAttributes(rLoc);
			rLoc.id = "DesMoines_bank";
			rLoc.id.label = "Usurer House";
			rLoc.filespath.models = "locations\inside\Pirate_House";
			rLoc.image = "loading\jonny_load\inside\bank03.dds";
			rLoc.type = "shop";
			rLoc.fastreload = "DesMoines";
			rLoc.models.always.locators = "PirH_l";
			rLoc.models.always.tavern = "PirH";
			rLoc.models.always.tavern.level = 65538;
			rLoc.models.always.window = "PirH_w";
			rLoc.models.always.back.level = 65529;
			rLoc.models.day.charactersPatch = "PirH_p";
			rLoc.models.night.charactersPatch = "PirH_p";
			LAi_LocationFightDisable(&rLoc, true);
			DeleteAttribute(rLoc, "MustSetReloadBack");
			DeleteAttribute(rLoc, "models.day.locators");
			DeleteAttribute(rLoc, "models.night.locators");

			DeleteAttribute(rLoc, "models.always.smallhouse");
			DeleteAttribute(rLoc, "models.always.windows");
			rLoc.models.always.window.tech = "LocationWindows";
			rLoc.models.always.window.level = 65539;
			rLoc.locators_radius.soldiers = 0.5;
			rLoc.locators_radius.patrol = 0.5;
			rLoc.locators_radius.smugglers = 0.5;
			rLoc.locators_radius.monsters = 0.5;
			rLoc.locators_radius.prison = 0.5;

			rLoc = LocFromID("OutRHouse");
			rLoc.reload.l2.label = "ExitTown";

			rLoc = LocFromID("DesMoines_town");
			DeleteAttribute(rLoc, "reload.l15");
			rLoc.reload.l7.name = "reload9";
			rLoc.reload.l7.go = "DesMoines_bank";
			rLoc.reload.l7.emerge = "reload1";
			rLoc.reload.l7.autoreload = "0";
			rLoc.reload.l7.label = "Usurer House";
			rLoc.reload.l7.close_for_night = 1;

			ref sld = characterFromID("DesMoines_usurer");
			sld.model = "usurer_8";
			sld.UsurerDeposit = 5000;

		break;

		case "companion_capture":
			dialog.text = "Les instructions ont été transmises.";
			if (CheckAttribute(PChar, "CompanionsLeaveCapturesDrift"))
				DeleteAttribute(PChar, "CompanionsLeaveCapturesDrift");
			else
				PChar.CompanionsLeaveCapturesDrift = true;
			link.l1 = "Parfait !";
			link.l1.go = "exit";
		break;

		case "ReadBook":
			Dialog.Text = "Je peux lire pendant une heure ou deux...";
			WasteTime(4);
			TryReadBook();
			pchar.bookreadtoday = true;
			Link.l6 = "דa suffit pour aujourd'hui.";
			Link.l6.go = "exit";
		break

		case "TalkSelf_ChangeFlag":
			Dialog.Text = "De quel pavillon ai-je besoin en ce moment ? Le changer prendra 1 heure.";
			if (IsCharacterPerkOn(pchar, "FlagPir") && sti(pchar.nation) != 4) {Link.l1 = "Hisser le pavillon pirate."; Link.l1.go = "TalkSelf_ChangeFlagPir";}
			if (IsCharacterPerkOn(pchar, "FlagEng") && sti(pchar.nation) != 0) {Link.l2 = "Hisser le pavillon anglais."; Link.l2.go = "TalkSelf_ChangeFlagEng";}
			if (IsCharacterPerkOn(pchar, "FlagFra") && sti(pchar.nation) != 1) {Link.l3 = "Hisser le pavillon français."; Link.l3.go = "TalkSelf_ChangeFlagFra";}
			if (IsCharacterPerkOn(pchar, "FlagSpa") && sti(pchar.nation) != 2) {Link.l4 = "Hisser le pavillon espagnol."; Link.l4.go = "TalkSelf_ChangeFlagSpa";}
			if (IsCharacterPerkOn(pchar, "FlagHol") && sti(pchar.nation) != 3) {Link.l5 = "Hisser le pavillon hollandais."; Link.l5.go = "TalkSelf_ChangeFlagHol";}
			Link.l6 = RandPhraseSimple("Pas maintenant. Pas le temps.", "Pas le temps. Des affaires m'attendent.");
			Link.l6.go = "exit";
		break;

		case "TalkSelf_ChangeFlagPir":
			Log_Info("Le pavillon pirate est choisi");
			FlagsProcess1(4);
			DialogExit_Self();
		break;

		case "TalkSelf_ChangeFlagEng":
			Log_Info("Le pavillon anglais est choisi");
			FlagsProcess1(0);
			DialogExit_Self();
		break;

		case "TalkSelf_ChangeFlagFra":
			Log_Info("Le pavillon français a été choisi");
			FlagsProcess1(1);
			DialogExit_Self();
		break;

		case "TalkSelf_ChangeFlagSpa":
			Log_Info("Le pavillon espagnol a été choisi");
			FlagsProcess1(2);
			DialogExit_Self();
		break;

		case "TalkSelf_ChangeFlagHol":
			Log_Info("Le pavillon hollandais a été choisi");
			FlagsProcess1(3);
			DialogExit_Self();
		break;

		// Мекахром смотрим
		case "Dozor_MekaKhrom":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			LaunchMekakhrom();
		break;

		case "TalkSelf_StartWait":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			PChar.GenQuest.CallFunctionParam = "LaunchTavernWaitScreen";
			DoQuestCheckDelay("CallFunctionParam", 0.1); // Нужно с задержкой, иначе - ГГ начинает крутиться
		break;

		case "TalkSelf_room_night":
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate("wait_night");
			DialogExit_Self();
		break;

		case "TalkSelf_room_day":
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate("wait_day");
			DialogExit_Self();
		break;

		// Gregg: "Two Sisters" - picking the hold door. The mini-game starts after the
		// dialog closes: no interface will come up while a dialog is running.
		case "TwoSisters_PickDoor":
			NextDiag.CurrentNode = NextDiag.TempNode;
			Dialog.Text = "L'essentiel, c'est de ne pas la casser dans la serrure. Il n'y en aura pas d'autre.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestPickDoorStart");
		break;
		//  захват города
		case "TalkSelf_TownAttack":
            bOk = (GetPartyCrewQuantity(Pchar, true) >= 500) || bBettaTestMode;
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && bOk)
	        {
	            chr = GetCharacter(GetCharIDXForTownAttack(pchar.location));
				bool isntFortHere = colonies[FindColony(chr.city)].HasNoFort;
	            if (chr.from_sea == Pchar.location.from_sea && isntFortHere == false)
	            {
					Dialog.Text = "Bien sמr, on peut lancer l'assaut, mais le navire ne tiendra pas longtemps sous les salves du fort. Et nous n'aurons pas le temps de débarquer les troupes.";
	    			Link.l1 = "...";
	    			Link.l1.go = "exit";
	            }
	            else
	            {
	                if (pchar.location == "Santiago_ExitTown")
					{
						if (CheckAttribute(pchar, "PGGWhisperLetter") || CheckAttribute(pchar, "PGGWhisperLetterSent"))
						{
							Dialog.Text = "Le fort a assez de canons pour nous enterrer en pleine ville. Non, Whisper a raison : on ne peut prendre Santiago que par la mer.";
							Link.l1 = "...";
							Link.l1.go = "exit";
							break;
						}
					}
					if (pchar.location == "Panama_ExitTown")
					{
						Dialog.Text = "Non, je n'ai pas perdu la tête. C'est Panama ! IMPOSSIBLE de la prendre !!! Il faut filer d'ici, sinon c'est la marque noire assurée...";
	    				Link.l1 = "...";
	    				Link.l1.go = "exit";
						break;
					}
					if (CheckAttribute(chr, "Fort.Mode") && sti(chr.Fort.Mode) == FORT_DEAD)
					{
						Dialog.Text = "Il semble que la colonie de " + GetCityName(chr.City) + " ait été récemment attaquée et pillée. Il faut attendre que la ville reprenne vie.";
	    				Link.l1 = "...";
	    				Link.l1.go = "exit";
					}
					else
					{
						Dialog.Text = "Attaquer la ville de " + GetCityName(chr.City) + ".";
		    			Link.l1 = "Aux armes !";
		    			Link.l1.go = "TalkSelf_TownAttack_Start";
		    			Link.l2 = "Oui, c'est un ordre !";
		    			Link.l2.go = "exit";
					}
	    		}
	        }
	        else
	        {
				if(!CheckAttribute(Pchar, "GenQuestFort.StartAttack"))
				{
					Dialog.Text = "Eh ! L'équipage ne suffit pas, il faut au moins 500 hommes.";
					Link.l1 = "...";
					Link.l1.go = "exit";
				}
				else
				{
					Dialog.Text = "Ne vous dispersez pas ! On poursuit l'assaut !";
					Link.l2 = "...";
					Link.l2.go = "exit";
				}
			}
	    break;

		case "TalkSelf_TownAttack_Start":
	        NextDiag.CurrentNode = NextDiag.TempNode;

			Pchar.GenQuestFort.StartAttack = true;
		    Pchar.GenQuestFort.fortCharacterIdx = GetCharIDXForTownAttack(pchar.location);
		    DeleteQuestAttribute("Union_with_Escadra");
	        chr = GetCharacter(sti(Pchar.GenQuestFort.fortCharacterIdx));
			if (isCityHasFort(chr.City))
			{
	        	SetLocationCapturedState(chr.from_sea, true);
	        }
	        else
	        {
	            SetLocationCapturedState(chr.Default, true); // для сухопутных
	        }
	        AddDialogExitQuest("Capture_Forts");
	        Ship_NationAgressive(chr, chr);
			pchar.HalfOfPaymentByCity = true;
	        DialogExit_Self();
	    break;
	    // Зачислить рабов в команду  -->
		case "TalkSelf_SlavesToCrew":
	        if (GetCurCrewEscadr() >= GetMaxCrewAble())
	        {
	            Dialog.Text = "Aucun des esclaves ne veut rejoindre l'équipage.";
	            Link.l1 = "Eh bien, tant pis !";
	    		Link.l1.go = "exit";
	        }
	        else
	        {
	            if (GetCrewQuantity(pchar) >= GetMaxCrewQuantity(pchar))
	            {
	                Dialog.Text = "Il n'y a pas de place pour de nouveaux marins sur le navire.";
	                Link.l1 = "Eh ! Il faut transférer une partie de l'équipage sur un autre navire.";
	        		Link.l1.go = "exit";
	            }
	            else
	            {
	                if (GetFreeCrewQuantity(pchar) <= GetCargoGoods(pchar, GOOD_SLAVES))
	                {
	                    pchar.GenQuest.SlavesToCrew = GetFreeCrewQuantity(pchar);
	                }
	                else
	                {
	                    pchar.GenQuest.SlavesToCrew = GetCargoGoods(pchar, GOOD_SLAVES);
	                }
	                Dialog.Text = pchar.GenQuest.SlavesToCrew+ " esclaves veulent rejoindre l'équipage. Les prendre ?";
	                Link.l1 = "Oui.";
	        		Link.l1.go = "TalkSelf_SlavesToCrew_1";
	        		Link.l2 = "Non";
	        		Link.l2.go = "exit";
	    		}
			}
		break;

		case "TalkSelf_SlavesToCrew_1":
	        if (CheckOfficersPerk(pchar, "IronWill"))
	        {
	            AddCrewMorale(pchar, -makeint(sti(pchar.GenQuest.SlavesToCrew) / 5.0))
	        }
	        else
	        {
	            AddCrewMorale(pchar, -makeint(sti(pchar.GenQuest.SlavesToCrew) / 3.0))
	        }
	        // падение опыта -->
	        fTemp =  stf(GetCrewQuantity(pchar) + sti(pchar.GenQuest.SlavesToCrew));
	        pchar.Ship.Crew.Exp.Sailors   = (stf(pchar.Ship.Crew.Exp.Sailors)*GetCrewQuantity(pchar) +
			                                        stf(pchar.Ship.Crew.Exp.Sailors)*0.3*sti(pchar.GenQuest.SlavesToCrew)) / fTemp;
			pchar.Ship.Crew.Exp.Cannoners   = (stf(pchar.Ship.Crew.Exp.Cannoners)*GetCrewQuantity(pchar) +
			                                        stf(pchar.Ship.Crew.Exp.Cannoners)*0.3*sti(pchar.GenQuest.SlavesToCrew)) / fTemp;
			pchar.Ship.Crew.Exp.Soldiers   = (stf(pchar.Ship.Crew.Exp.Soldiers)*GetCrewQuantity(pchar) +
			                                        stf(pchar.Ship.Crew.Exp.Soldiers)*0.3*sti(pchar.GenQuest.SlavesToCrew)) / fTemp;
			// падение опыта <--
			pchar.Ship.Crew.Quantity = sti(pchar.Ship.Crew.Quantity) + sti(pchar.GenQuest.SlavesToCrew);
	        RemoveCharacterGoodsSelf(pchar, GOOD_SLAVES, sti(pchar.GenQuest.SlavesToCrew));

	        NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
		break;
		// Зачислить рабов в команду  <--
		// boal <--

//navy CONTRABAND METRO -->
		case "GenTravel_Main":
			NextDiag.TempNode = "First time";
			dialog.Text = "Maintenant, ce grand navire est à moi, et c'est moi le capitaine ici ! Dommage qu'il ait fallu massacrer tout l'équipage.";
			Link.l1 = "Il est temps de descendre à terre...";
			Link.l1.go = "exit";

			chr = CharacterFromID("Abracham_Gray");
			chr.location = "none";
			SeaExchangeCharactersShips(PChar, chr, false, false);
			SetCrewQuantity(PChar, 0);

			//грузим ГГ куда нужно...
			SetAnyReloadToLocation(pchar.GenQuest.contraTravel.destination.loc, pchar.GenQuest.contraTravel.destination.group, pchar.GenQuest.contraTravel.destination.locator, "", 0, 0, 0, 0);
			AddDialogExitQuest("AnyReloadToLocation");
            chrDisableReloadToLocation = false;

			CloseQuestHeader("Gen_ContrabandTravel");
			setCharacterShipLocation(PChar, pchar.GenQuest.contraTravel.destination.loc);
			setWDMPointXZ(pchar.GenQuest.contraTravel.destination.loc);

			//трём аттрибуты
			DeleteAttribute(PChar, "GenQuest.contraTravel");
			break;
//navy CONTRABAND METRO <--

//navy --> 13.02.08
		case "Cabin_CompanionSelect":
			Dialog.Text = "Lequel de mes compagnons dois-je appeler ?";
			// LEO: по ВСЕМ слотам эскадры, а не по их количеству - слоты бывают разрежены (см. CompanionSaveTasks),
			//   и компаньон из слота выше счётчика вообще не попадал в список вызова
			for (i = 1; i < COMPANION_MAX; i++)
			{
				iTemp = GetCompanionIndex(PChar, i);
				if (iTemp < 0) continue;
				chr = GetCharacter(iTemp);
				if (!CheckAttribute(chr, "Tasks.Clone") && sti(chr.Payment) == true)
				{
					sAttr = "l" + i;
					rShip = GetRealShip(sti(chr.Ship.Type));
					link.(sAttr) = GetFullName(chr) + " - " + xiStr(rShip.BaseName) + " '" + chr.Ship.Name + "'.";
					link.(sAttr).go = "CabinCompanionTalk_" + i;
				}
			}
			link.l9 = "Une autre fois.";
			link.l9.go = "exit";
			break;

// Вызов персонажей by xxxZohanxxx -->
		case "Cabin_OfficerSelect":
			Dialog.Text = "Quel officier dois-je appeler ?";
			if (sti(pchar.Fellows.Passengers.navigator) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.navigator));
				if (chr.location != Get_My_Cabin())
				{
				link.l1 = "Navigateur, " + GetFullName(chr) + ".";
				link.l1.go = "Cabin_navigator_Talk";
				}
			}
			if (sti(pchar.Fellows.Passengers.boatswain) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.boatswain));
				if (chr.location != Get_My_Cabin())
				{
				link.l2 = "Maître d'équipage, " + GetFullName(chr) + ".";
				link.l2.go = "Cabin_boatswain_Talk";
				}
			}
			if (sti(pchar.Fellows.Passengers.cannoner) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.cannoner));
				if (chr.location != Get_My_Cabin())
				{
				link.l3 = "Canonnier, " + GetFullName(chr) + ".";
				link.l3.go = "Cabin_cannoner_Talk";
				}
			}
			if (sti(pchar.Fellows.Passengers.doctor) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.doctor));
				if (chr.location != Get_My_Cabin())
				{
				link.l4 = "Médecin, " + GetFullName(chr) + ".";
				link.l4.go = "Cabin_doctor_Talk";
				}
			}
			if (sti(pchar.Fellows.Passengers.treasurer) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.treasurer));
				if (chr.location != Get_My_Cabin())
				{
				link.l5 = "Trésorier, " + GetFullName(chr) + ".";
				link.l5.go = "Cabin_treasurer_Talk";
				}
			}
			if (sti(pchar.Fellows.Passengers.carpenter) != -1)
			{
				chr = GetCharacter(sti(pchar.Fellows.Passengers.carpenter));
				if (chr.location != Get_My_Cabin())
				{
				link.l6 = "Charpentier, " + GetFullName(chr) + ".";
				link.l6.go = "Cabin_carpenter_Talk";
				}
			}
			link.l7 = "Une autre fois.";
			link.l7.go = "exit";
			break;

		case "Cabin_PassengerSelect":
			Dialog.Text = "Lequel des passagers dois-je appeler ?";
			for (i = 0; i < GetPassengersQuantity(PChar); i++)
			{
				chr = GetCharacter(GetPassenger(PChar,i));
					if (HasSubStr(chr.id, "ShipWreckSailor"))
					{
						LAi_SetCitizenType(chr);
						sAttr = "l" + i;
						link.(sAttr) = GetFullName(chr) + ".";
						link.(sAttr).go = "CabinPassengerTalk_" + i;
						continue;
					}
					if (!CheckAttribute(chr, "prisoned") && !IsOfficer(chr) && GetRemovable(chr) && chr.location != Get_My_Cabin() && !CheckAttribute(chr, "isfree")) // Чтобы в список не попадали квестовые, офицеры и пленники
					{
						sAttr = "l" + i;
						link.(sAttr) = GetFullName(chr) + ".";
						link.(sAttr).go = "CabinPassengerTalk_" + i;
					}
			}
			link.l99 = "Une autre fois.";
			link.l99.go = "exit";
			break;

		case "Cabin_navigator_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.navigator));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;
		case "Cabin_boatswain_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.boatswain));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;
		case "Cabin_cannoner_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.cannoner));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;
		case "Cabin_doctor_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.doctor));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;
		case "Cabin_treasurer_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.treasurer));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;
		case "Cabin_carpenter_Talk":
			chr = GetCharacter(sti(pchar.Fellows.Passengers.carpenter));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			DialogExit_Self();
		break;

		case "Cabin_Passenger_Talk":
			i = sti(PChar.GenQuest.CabinPassengerNum);
			chr = GetCharacter(GetPassenger(PChar,i));
			PlaceCharacter(chr, "rld", PChar.location);
			LAi_SetStayType(chr);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
		break;
// <-- Вызов персонажей by xxxZohanxxx

		case "Cabin_Companion_Talk":
			i = sti(PChar.GenQuest.CabinCompanionNum);
			PlaceCompanionCloneNearMChr(i, false);

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			break;
//navy <--

		// Квест Аскольда, освобождение Аззи.
		case "FreedomAzzy":
			chr = GetCharacter(NPC_GenerateCharacter("Azzy", "Azzy", "man", "man", 22, PIRATE, -1, false));
			chr.name = "Le démon";
			chr.lastname = "Azzie";
			chr.Dialog.Filename = "Quest\Azzy_dialog.c";
			GiveItem2Character(chr, "blade28");// сабля Моргана
			chr.equip.blade = "blade28";
			chr.rank 	= 100;
			chr.reputation = 0;
			SetSelfSkill(chr, 100, 100, 100, 100, 100);
			SetShipSkill(chr, 100, 100, 100, 100, 100, 100, 100, 100, 100);
			LAi_SetImmortal(chr, true);
			LAi_SetActorType(chr);
			LAi_SetLoginTime(chr, 0.0, 24.0);
			LAi_SetHP(chr, 10000.0, 10000.0);
			chr.greeting = "Gr_Azzy";
			ChangeCharacterAddressGroup(chr, pchar.location, "officers", "reload1_1");
			DoQuestCheckDelay("Ascold_AzzyIsFree", 4.0);
			pchar.questTemp.Azzy = "Azzy_Freedom";
			DialogExit();
		break;

		// Сами хотим колонией управлять.
		case "ColonyBuilding_Hovernor_1":
			dialog.Text = "Ou trouver un assistant ?";
			Link.l1 = "Je crois que je vais m'en occuper moi-même. J'en suis capable.";
			Link.l1.go = "ColonyBuilding_Hovernor_2";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
		break;
	        case "ColonyBuilding_Hovernor_2":
		        bQuestDisableMapEnter = true;
		        Log_SetStringToLog("Maintenant que vous êtes gouverneur, vous ne pouvez plus quitter l'île.");

			PChar.ColonyBuilding.Hovernor = PChar.id;
			DialogExit_Self();
	        break;

		case "ColonyBuilding_Hovernor":
			dialog.Text = "Examiner l'état actuel des affaires de la colonie " + PChar.ColonyBuilding.ColonyName + ".";
			Link.l1 = "Il faut étudier en détail l'état actuel des affaires.";
			Link.l1.go = "ColonyBuilding_Hovernor_3";
			Link.l2 = "Cette vie à terre ne me plaît pas.";
			Link.l2.go = "ColonyBuilding_Hovernor_4";
			Link.l3 = "Ne rien faire.";
			Link.l3.go = "Exit";
		break;

		case "ColonyBuilding_Hovernor_3":
			dialog.Text = "Hum... Sur quelles affaires dois-je me renseigner ?";
			Link.l1 = "L'état de la colonie et ses capacités financières.";
			Link.l1.go = "ColonyBuilding_Hovernor_3_1";
			Link.l2 = "L'état de préparation de la garnison et la santé des habitants.";
			Link.l2.go = "ColonyBuilding_Hovernor_3_2";
			Link.l3 = "Le nom de la colonie et l'apparence des soldats.";
			Link.l3.go = "ColonyBuilding_Hovernor_3_3";
			Link.l4 = "Ne rien faire.";
			Link.l4.go = "Exit";
		break;

		case "ColonyBuilding_Hovernor_3_1":
			DialogExit_Self();
			LaunchColony();
		break;

		case "ColonyBuilding_Hovernor_3_2":
			DialogExit_Self();
			LaunchColonyLandGuard();
		break;

		case "ColonyBuilding_Hovernor_3_3":
			DialogExit_Self();
			LaunchColonyBuilding(true, false);
		break;

		case "ColonyBuilding_Hovernor_4":
			dialog.Text = "Vous ne voulez vraiment pas diriger votre colonie ?";
			Link.l1 = "Oui.";
			Link.l1.go = "ColonyBuilding_Hovernor_5";
			Link.l2 = "Non, j'ai changé d'avis. Ma vocation, c'est d'être gouverneur !";
			Link.l2.go = "Exit";
		break;

		case "ColonyBuilding_Hovernor_5":
			PChar.ColonyBuilding.Hovernor = "";
		        bQuestDisableMapEnter = false;
		        Log_SetStringToLog("En cessant d'être gouverneur, vous retrouvez votre liberté de capitaine !");
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "...";
			Link.l1.go = "exit";
			NextDiag.TempNode = "TalkSelf_Main";
		break;

		// Мекахром смотрим
		case "Dozor_MekaKhrom":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			LaunchMekakhrom();
		break;

		case "Whisper_mission_1":
			dialog.Text = "'Chère Whisper, Omnitech vous souhaite la bienvenue ! Nous avons entendu dire que vous étiez la meilleure dans votre domaine, et nous voulons vous proposer un travail. Voici de quoi il s'agit : il existe un objet, un redresseur de particules quantiques. C'est un appareil dangereux : entre de mauvaises mains, il peut nuire à toute l'humanité. Et en ce moment, il est justement entre de telles mains.'";
			Link.l1.go = "Whisper_mission_2";
		break;
		case "Whisper_mission_2":
			dialog.Text = "'Nous vous avons envoyé les coordonnées du laboratoire du savant fou qui a mis au point cet appareil. Il s'est entouré d'une escouade de robots de combat, mais cela ne devrait pas être un gros obstacle pour vous. La rémunération sera à la hauteur, nous ne regarderons pas à la dépense. Nous savons qu'un prêt immobilier est enregistré à votre nom. Considérez-le comme déjà remboursé si vous acceptez cette affaire. Et dépêchez-vous : l'appareil peut être activé à tout moment !'";
			Link.l1 = "Eh bien, mettons-nous au travail...";
			DeleteAttribute(pchar, "questTemp.Whisper.Entered_Dungeon");
			Link.l1.go = "Exit_Special";
		break;
		case "Whisper_Finish":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit_Self();
			Pchar.BaseNation = FRANCE;
			Flag_Change(FRANCE);
			chrDisableReloadToLocation = false;
			bDisableCharacterMenu = false;
			InterfaceStates.DisFastTravel = false;
			pchar.Whisper.NanoCostume = true;
			DeleteAttribute(pchar, "questTemp.WhisperLine");
			pchar.Whisper.HatEnabled = false;

			TakeNItems(PChar, "hatWhisper", 1);
			TakeNItems(PChar, "glasses", 1);

			SetQuestHeader("WhisperContraband");
			AddQuestRecord("WhisperContraband", "1");
			pchar.Whisper.Contraband = true;
			pchar.Whisper.FindDesouza = true;
			SetTimerCondition("W_Smuggling", 0, 0, 60, false);

            mc = GetMainCharacter();

			mc.Ship.Type = GenerateShipExt(SHIP_VEINARD, true, mc);
			mc.Ship.name="La Veuve noire";
			SetBaseShipData(mc);
			mc.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS10;
			SetCrewQuantityFull(mc);

            SetCharacterGoods(mc,GOOD_FOOD,200);
        	SetCharacterGoods(mc,GOOD_BALLS,300);//2000);
        	SetCharacterGoods(mc,GOOD_MEDICAMENT,300);//2000);
            SetCharacterGoods(mc,GOOD_GRAPES,300);//700);
            SetCharacterGoods(mc,GOOD_KNIPPELS,300);//700);
            SetCharacterGoods(mc,GOOD_BOMBS,300);//1500);
            SetCharacterGoods(mc,GOOD_POWDER,1000);
            SetCharacterGoods(mc,GOOD_PLANKS,50);
            SetCharacterGoods(mc,GOOD_SAILCLOTH,50);
            SetCharacterGoods(mc,GOOD_RUM,40);//600);
            SetCharacterGoods(mc,GOOD_WEAPON,200);//2000);
            SetCharacterGoods(mc,GOOD_EBONY,100);//2000);
            DoReloadCharacterToLocation(Pchar.HeroParam.Location, Pchar.HeroParam.Group, Pchar.HeroParam.Locator);
		break;
		case "WhisperPortrait":
			dialog.Text = "Et de quoi vais-je avoir l'air aujourd'hui ?";
			Link.l1 = "Variante 1.";
			Link.l1.go = "portrait1";
			Link.l2 = "Variante 2.";
			Link.l2.go = "portrait2";
			Link.l3 = "Variante 3.";
			Link.l3.go = "portrait3";
			Link.l4 = "Variante 4.";
			Link.l4.go = "portrait4";
			Link.l5 = "Variante 5.";
			Link.l5.go = "portrait5";
			Link.l6 = "Variante 6.";
			Link.l6.go = "portrait6";
			Link.l7 = "Variante 7.";
			Link.l7.go = "portrait7";
			Link.l99 = "Je crois que je vais laisser comme c'est.";
			Link.l99.go = "Exit";
		break;
		case "portrait1":
			pchar.faceID = "543";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait2":
			pchar.faceID = "543_2";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait3":
			pchar.faceID = "543_3";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait4":
			pchar.faceID = "543_4";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait5":
			pchar.faceID = "543_5";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait6":
			pchar.faceID = "543_6";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "portrait7":
			pchar.faceID = "543_7";
			dialog.Text = "Beaucoup mieux.";
			Link.l1 = "דa suffit pour aujourd'hui.";
			Link.l1.go = "Exit";
		break;
		case "WhisperHatUnequip":
			dialog.Text = "Je vais le laisser dans la cabine, sinon j'ai la tête qui transpire.";
			ref hatRef = ItemsFromID("hatWhisper");
			string itmGroup = hatRef.groupID;
			RemoveCharacterEquip(pchar, itmGroup);
			ChangeWhisperHeroModel();
			Link.l1 = "C'est réglé.";
			Link.l1.go = "TalkSelf_Main";
		break;
		case "WhisperHatEquip":
			dialog.Text = "C'est beaucoup mieux.";
			EquipCharacterByItem(pchar, "hatWhisper");
			ChangeWhisperHeroModel();
			Link.l1 = "C'est réglé.";
			Link.l1.go = "TalkSelf_Main";
		break;
		case "WhisperGlassesUnequip":
			dialog.Text = "J'ai déjà mal aux yeux, je crois que je vais enlever mes lunettes.";
			ref glassesRef = ItemsFromID("glasses");
			string gItmGroup = glassesRef.groupID;
			RemoveCharacterEquip(pchar, gItmGroup);
			Link.l1 = "C'est réglé.";
			Link.l1.go = "TalkSelf_Main";
		break;
		case "WhisperGlassesEquip":
			dialog.Text = "C'est beaucoup mieux.";
			EquipCharacterByItem(pchar, "glasses");
			Link.l1 = "C'est réglé.";
			Link.l1.go = "TalkSelf_Main";
		break;
		case "PriestSurprise":
			dialog.Text = "Je vais vomir... Je ne m'attendais pas à ça en allant au bordel. Jouons, argh, à boucher les trous ! Il aurait fallu envoyer un prêtre dans la chambre des plaisirs. Pourvu qu'il n'y ait pas d'autres rumeurs.";
			Link.l1 = "Bon, on n'y peut rien, on continue.";
			Link.l1.go = "exit";
			NextDiag.TempNode = "TalkSelf_Main";
			chrDisableReloadToLocation = false;
		break;
		case "RechargeCostume":
			if (!CheckAttribute(pchar, "questTemp.LSC.immersions"))
			{
				dialog.Text = "Henrik dit que tout est prêt pour la plongée.";
				Link.l1 = "Voilà qui est parfait.";
				Link.l1.go = "exit";
				pchar.questTemp.LSC = "toUnderwater";
				pchar.questTemp.LSC.immersions = 0;
				pchar.questTemp.LSC.immersions.pay = true;
				SaveCurrentQuestDateParam("questTemp.LSC.immersions");
				WaitDate("", 0, 0, 0, 1, 0);
				break;
			}
			if (CheckAttribute(pchar, "questTemp.LSC.immersions") && pchar.questTemp.LSC.immersions.pay == true)
			{
				dialog.Text = "Le scaphandre est prêt, vous pouvez plonger.";
				Link.l1 = "Voilà qui est parfait.";
				Link.l1.go = "exit";
				break;
			}
			if (GetQuestPastDayParam("questTemp.LSC.immersions") > 1)
			{
				dialog.Text = "Henrik dit que tout est prêt pour la plongée.";
				Link.l1 = "Voilà qui est parfait.";
				Link.l1.go = "exit";
				pchar.questTemp.LSC = "toUnderwater";
				pchar.questTemp.LSC.immersions = 0;
				pchar.questTemp.LSC.immersions.pay = true;
				SaveCurrentQuestDateParam("questTemp.LSC.immersions");
				WaitDate("", 0, 0, 0, 1, 0);
			}
			else
			{
				dialog.Text = "Henrik dit que le scaphandre n'est pas prêt pour la plongée et demande de repasser demain.";
				Link.l1 = "Que puis-je y faire...";
				Link.l1.go = "exit";
			}
		break;

	}
}

void  DialogExit_Self()
{
    DialogExit();
	locCameraSleep(false); //boal
}


void FlagsProcess1(int nation)
{
	// boal 04.04.2004 -->
	bool bTmpBool = true;
	int i, cn;
	ref chref;

	Sea_ClearCheckFlag(); // сбросить всем в море проверку смотрения на флаг.
	Flag_Change(nation);
	DoQuestFunctionDelay("FreeChangeFlagMode", 15.0); // ролик + запас

	switch (nation)
	{
    	case ENGLAND:	EnglandProcess();	break;
    	case FRANCE:	FranceProcess();	break;
    	case SPAIN:		SpainProcess();		break;
    	case PIRATE:	PirateProcess();	break;
    	case HOLLAND:	HollandProcess();	break;
	}
}

void PirateProcess()
{
	pchar.DisableChangeFlagMode = true;
    PChar.GenQuest.VideoAVI        = "Pirate";
    PChar.GenQuest.VideoAfterQuest = "pir_flag_rise";

}

void EnglandProcess()
{
	pchar.DisableChangeFlagMode = true;
    PChar.GenQuest.VideoAVI        = "England";
    PChar.GenQuest.VideoAfterQuest = "eng_flag_rise";

}

void FranceProcess()
{
	pchar.DisableChangeFlagMode = true;
    PChar.GenQuest.VideoAVI        = "France";
    PChar.GenQuest.VideoAfterQuest = "fra_flag_rise";

}

void SpainProcess()
{
	pchar.DisableChangeFlagMode = true;
    PChar.GenQuest.VideoAVI        = "Spain";
    PChar.GenQuest.VideoAfterQuest = "spa_flag_rise";

}

void HollandProcess()
{
	pchar.DisableChangeFlagMode = true;
    PChar.GenQuest.VideoAVI        = "Holland";
    PChar.GenQuest.VideoAfterQuest = "hol_flag_rise";

}

