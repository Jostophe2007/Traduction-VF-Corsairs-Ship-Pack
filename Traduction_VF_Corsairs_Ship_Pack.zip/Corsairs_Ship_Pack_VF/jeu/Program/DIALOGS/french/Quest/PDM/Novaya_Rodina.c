
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Quel dommage, quel dommage. Oh, bon sang !";
			link.l1 = "Qu'est-ce que tu marmonnes tout seul ?";
			link.l1.go = "Nachalo_1";
			PlayVoice("Kopcapkz\Voices\PDM\Hugo Lumbermill.wav");
		break;

		case "Nachalo_1":
            dialog.text = "Je m'appelle Hugo. Hugo la Scierie. Je vois que tu es capitaine, toi aussi. Tu prendrais une heure pour écouter mon histoire ?";
            link.l1 = "דa ne me dérange pas.";
			link.l1.go = "Slushau_1";
			link.l2 = "Eh bien, non, en fait. Je préfère passer une heure ailleurs.";
			link.l2.go = "Ya_Ustal_Ya_Uhoju";
			NextDiag.TempNode = "Podhodim_SNOVA_Reactia";
		break;

		case "Slushau_1":
            dialog.text = "Tu es corsaire, n'est-ce pas ?";
			link.l1 = "Tu cherches à m'insulter ? Je suis pirate, et je ne dépends de personne !";
			link.l1.go = "Nelzya_Pomoch";
			if (sti(pchar.nation) != PIRATE)
			{
				link.l1 = "Non, les corsaires servent l'וtat, et moi, je suis capitaine libre de mon navire.";
				link.l1.go = "Nelzya_Pomoch";
			}
            if (CheckCharacterItem(Pchar, "patent_spa") || CheckCharacterItem(Pchar, "patent_fra") || CheckCharacterItem(Pchar, "patent_hol") || CheckCharacterItem(Pchar, "patent_eng"))
			{
				link.l1 = "Oui, je suis corsaire.";
				link.l1.go = "Korsar_1";
			}
		break;

		case "Nelzya_Pomoch":
            dialog.text = "Ah, alors tu ne peux pas m'aider. Je te souhaite bonne chance, adieu.";
			link.l1 = "Eh bien, oui, une conversation fructueuse, rien à dire. א plus tard.";
			link.l1.go = "Ya_Ustal_Ya_Uhoju";
            link.l2 = "Eh bien, tu peux au moins me raconter ton histoire.";
			link.l2.go = "Istoria_1";
			NextDiag.TempNode = "Podhodim_SNOVA_Reactia";
		break;

		case "Istoria_1":
            dialog.text = "Bon. וcoute : je suis devenu trop vieux pour mener la vie de pirate. Le pillage et la bagarre, c'est un jeu pour les jeunes, tu sais ? Et je ne veux plus risquer ma peau, je veux naviguer tranquillement, sans sursauter à la vue d'autres navires. Mais le problème, c'est que je n'ai nulle part oם aller. Tout le monde veut me pendre, tu sais ? Mais j'ai eu une idée, "+ GetSexPhrase("le gars", "la fille") +"\n"+
							"Je pense m'acheter une lettre de marque, gagner un peu d'or et graisser la patte à quelques fonctionnaires, mais ces maudits forts ouvrent le feu dès que j'approche d'un port, et je ne peux pas aller voir le gouverneur pour lui faire une offre. Les Anglais ou les Français me pendront dès qu'ils me tiendront : ils ont ordre de me tuer dès que je montre le bout de mon nez. Je pense que je pourrais entrer au service des Espagnols, mais je ne peux pas aller dans leurs maudits ports, ils ouvriraient le feu sur moi tout de suite !";
			link.l1 = "Pardon, Hugo, mais je ne peux rien faire pour toi. Je te souhaite bonne chance. Bon vent.";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "questTemp.PDM_NR_Pomoch"))
			{
				link.l2 = "Mais comment puis-je t'aider ?";
				link.l2.go = "Davai_Pomogu_NET";
			}
			if (!CheckAttribute(pchar, "questTemp.PDM_NR_Bratstvo"))
			{
				link.l3 = "Et les Frères de la Cכte ?";
				link.l3.go = "Davai_Pomogu_Bratstvo";
			}
			NextDiag.TempNode = "Podhodim_SNOVA_Reactia";
		break;

		case "Davai_Pomogu_NET":
            dialog.text = "Tu ne peux pas m'aider, "+ GetSexPhrase("le gars", "la fille") +". Tu es pirate, n'est-ce pas ? On te fera sauter la cervelle dès que tu approcheras à moins d'un mille d'une ville espagnole.";
			if (sti(pchar.nation) != PIRATE)
			{
				dialog.text = "Tu ne peux pas m'aider, "+ GetSexPhrase("le gars", "la fille") +". Tu n'es pas au service du gouverneur général espagnol, n'est-ce pas ? Ce qui veut dire que tu n'as pas non plus les bonnes relations.";
			}
			link.l1 = "Juste remarque. א plus tard, alors. Et je te souhaite bonne chance.";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "questTemp.PDM_NR_Bratstvo"))
			{
				link.l3 = "Et les Frères de la Cכte ?";
				link.l3.go = "Davai_Pomogu_Bratstvo";
			}
			NextDiag.TempNode = "Podhodim_SNOVA_Reactia";
			pchar.questTemp.PDM_NR_Pomoch = "PDM_NR_Pomoch";
			pchar.questTemp.PDM_NR_Bratstvo = "PDM_NR_Bratstvo";
		break;

		case "Davai_Pomogu_Bratstvo":
            dialog.text = "Les Frères de la Cכte ! Je n'en fais pas partie, et je n'en ferai jamais partie ! Ils fixent les règles de la piraterie : des règles, tu entends ? Des règles pour les pirates ! Je n'ai jamais entendu pareille bêtise. Je vais te dire franchement, "+ GetSexPhrase("le gars", "la fille") +", les Frères de la Cכte ne sont qu'une bande de crétins sans cervelle réunis pour mettre des bâtons dans les roues de nous autres, marins libres.";
            link.l1 = "Hum. Après tout, c'est ton avis. Bon, alors, j'ai bien peur de ne rien pouvoir te proposer d'autre. א plus tard.";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "questTemp.PDM_NR_Pomoch"))
			{
				link.l2 = "Mais comment puis-je t'aider ?";
				link.l2.go = "Davai_Pomogu_NET";
			}
			NextDiag.TempNode = "Podhodim_SNOVA_Reactia";
			pchar.questTemp.PDM_NR_Pomoch = "PDM_NR_Pomoch";
			pchar.questTemp.PDM_NR_Bratstvo = "PDM_NR_Bratstvo";
		break;

		case "Podhodim_SNOVA_Reactia":
			PlayVoice("Kopcapkz\Voices\PDM\Hugo Lumbermill.wav");
			if (CheckCharacterItem(Pchar, "patent_spa"))
			{
				dialog.text = "(boit du rhum)";
				link.l1 = "Bonjour, Hugo. Je suis maintenant "+ GetSexPhrase("corsaire au service de l'Espagne", "corsaire au service de l'Espagne") +", je peux t'aider ?";
				link.l1.go = "Ya_Ispania_1";
			}
			else
			{
				dialog.text = "Si tu n'es pas corsaire au service de l'Espagne, nous n'avons rien à nous dire.";
				link.l1 = "Bonne chance, alors.";
				link.l1.go = "exit";
				link.l2 = "Les Espagnols sont mes ennemis, souviens-toi de ça !";
				link.l2.go = "Ya_Ustal_Ya_Uhoju";
			}
		break;
		
		case "Ya_Ustal_Ya_Uhoju":
			DialogExit();
            npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
		break;

		case "Korsar_1":
			if (CheckCharacterItem(Pchar, "patent_eng"))
			{
				dialog.text = "C'est bien ce que je pensais. Et sous quel pavillon navigues-tu ?";
				link.l1 = "Je navigue sous pavillon anglais.";
				link.l1.go = "Nelzya_Pomoch_Korsar_2";
			}
			if (CheckCharacterItem(Pchar, "patent_fra"))
			{
				dialog.text = "C'est bien ce que je pensais. Et sous quel pavillon navigues-tu ?";
				link.l1 = "Je navigue sous pavillon français.";
				link.l1.go = "Nelzya_Pomoch_Korsar_2";
			}
			if (CheckCharacterItem(Pchar, "patent_spa"))
			{
				dialog.text = "C'est bien ce que je pensais. Et sous quel pavillon navigues-tu ?";
				link.l1 = "Je navigue sous pavillon espagnol.";
				link.l1.go = "Ya_Ispania_1";
			}
			if (CheckCharacterItem(Pchar, "patent_hol"))
			{
				dialog.text = "C'est bien ce que je pensais. Et sous quel pavillon navigues-tu ?";
				link.l1 = "Je navigue sous pavillon hollandais.";
				link.l1.go = "Nelzya_Pomoch_Korsar_2";
			}
		break;

		case "Nelzya_Pomoch_Korsar_2":
            dialog.text = "Ah, alors tu ne peux pas m'aider. Je te souhaite bonne chance, adieu.";
			link.l1 = "Eh bien, oui, une conversation fructueuse, rien à dire. א plus tard.";
			link.l1.go = "Ya_Ustal_Ya_Uhoju";
            link.l2 = "Eh bien, tu peux au moins me raconter ton histoire.";
			link.l2.go = "Istoria_Korsar_2";
			
		break;

		case "Istoria_Korsar_2":
            dialog.text = "Bon. וcoute : je suis devenu trop vieux pour mener la vie de pirate. Le pillage et la bagarre, c'est un jeu pour les jeunes, tu sais ? Et je ne veux plus risquer ma peau, je veux naviguer tranquillement, sans sursauter à la vue d'autres navires. Mais le problème, c'est que je n'ai nulle part oם aller. Tout le monde veut me pendre, tu sais ? Mais j'ai eu une idée, "+ GetSexPhrase("le gars", "la fille") +"\n"+
							"Je pense m'acheter une lettre de marque, gagner un peu d'or et graisser la patte à quelques fonctionnaires, mais ces maudits forts ouvrent le feu dès que j'approche d'un port, et je ne peux pas aller voir le gouverneur pour lui faire une offre. Les Anglais ou les Français me pendront dès qu'ils me tiendront : ils ont ordre de me tuer dès que je montre le bout de mon nez. Je pense que je pourrais entrer au service des Espagnols, mais je ne peux pas aller dans leurs maudits ports, ils ouvriraient le feu sur moi tout de suite !";
			link.l1 = "Pardon, Hugo, mais je ne peux rien faire pour toi. Je te souhaite bonne chance. Bon vent.";
			link.l1.go = "Ya_Ustal_Ya_Uhoju";
			link.l2 = "Mais comment puis-je t'aider ?";
			link.l2.go = "Davai_Pomogu_KORSAR_NET_2";
		break;

		case "Davai_Pomogu_KORSAR_NET_2":
            dialog.text = "Tu ne peux pas m'aider, "+ GetSexPhrase("le gars", "la fille") +". Tu sers les ennemis de l'Espagne, n'est-ce pas ? On te fera sauter la cervelle dès que tu approcheras à moins d'un mille d'une ville espagnole.";
            link.l1 = "Juste remarque. א plus tard, alors. Et je te souhaite bonne chance.";
			link.l1.go = "Ya_Ustal_Ya_Uhoju";
		break;

		case "Ya_Ispania_1":
            dialog.text = "Oh, alors tu es avec les Espagnols ! Tu pourrais vraiment m'aider !";
            link.l1 = "Que t'est-il arrivé ?";
			link.l1.go = "Ya_Ispania_2"
		break;

		case "Ya_Ispania_2":
            dialog.text = "Bon. וcoute : je suis devenu trop vieux pour mener la vie de pirate. Le pillage et la bagarre, c'est un jeu pour les jeunes, tu sais ? Et je ne veux plus risquer ma peau, je veux naviguer tranquillement, sans sursauter à la vue d'autres navires. Mais le problème, c'est que je n'ai nulle part oם aller. Tout le monde veut me pendre, tu sais ? Mais j'ai eu une idée, "+ GetSexPhrase("le gars", "la fille") +"\n"+
							"Je pense m'acheter une lettre de marque, gagner un peu d'or et graisser la patte à quelques fonctionnaires, mais ces maudits forts ouvrent le feu dès que j'approche d'un port, et je ne peux pas aller voir le gouverneur pour lui faire une offre. Les Anglais ou les Français me pendront dès qu'ils me tiendront : ils ont ordre de me tuer dès que je montre le bout de mon nez. Je pense que je pourrais entrer au service des Espagnols, mais je ne peux pas aller dans leurs maudits ports, ils ouvriraient le feu sur moi tout de suite !";
            link.l1 = "Et que dois-je faire ?";
			link.l1.go = "Ya_Ispania_3";
		break;

		case "Ya_Ispania_3":
            dialog.text = "Tu es corsaire, n'est-ce pas ? Tu peux entrer dans un port espagnol sans que les canons du fort ne coulent ton rafiot, pas vrai ? Alors, tu peux glisser un mot en ma faveur au gouverneur général de La Havane, pas vrai ? Dis-lui simplement que j'achèterais une lettre de marque pour dix mille pièces d'or, et que je suis prêt à jurer de le servir fidèlement.";
            link.l1 = "Je te plains, Hugo, mais je n'ai pas le temps pour ça en ce moment. א plus tard.";
			link.l1.go = "Otkazal";
			link.l2 = "En fait, je pourrais le faire, mais pour être honnête, qu'est-ce que j'y gagnerai ?";
			link.l2.go = "Ya_Ispania_4";
		break;

		case "Otkazal":
            dialog.text = "Comme tu voudras, "+ GetSexPhrase("le gars", "la fille") +". Je trouverai quelqu'un d'autre pour ce travail.";
            link.l1 = "א plus tard.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Obida";
			npchar.lifeday = 0;
		break;

		case "Obida":
            dialog.text = "Ha, "+ GetSexPhrase("l'ami", "ma fille") +", je ne joue pas comme ça. Tu as déjà "+ GetSexPhrase("refusé", "refusé") +" de m'aider une fois, et je ne te donnerai pas de seconde chance.";
            link.l1 = "C'est ton problème, grand-père. Alors, bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Obida";
		break;

		case "Ya_Ispania_4":
            dialog.text = "De l'argent, bien sמr ! Je peux te payer 8 000. Qu'en dis-tu ?";
            link.l1 = "דa me va. J'accepte. Je t'apporterai une lettre de marque espagnole contre de l'or.";
			link.l1.go = "Ya_Ispania_5";
			link.l2 = "Tu plaisantes. 8 000 pour une affaire aussi difficile et dangereuse ? דa ne marchera pas.";
			link.l2.go = "Otkazal";
		break;

		case "Ya_Ispania_5":
            dialog.text = "Voilà qui est bien ! Bon vent, capitaine. Je ne peux t'attendre ici que deux mois. Si tu ne reviens pas d'ici là, je serai sans doute déjà pendu à une potence française ou anglaise.";
            link.l1 = "א plus tard.";
			link.l1.go = "Havana_Cod_1";
			NextDiag.TempNode = "Jugo_PodhodimSnova";
		break;

		case "Jugo_PodhodimSnova":
			PlayVoice("Kopcapkz\Voices\PDM\Hugo Lumbermill.wav");
            dialog.text = "Alors, "+pchar.name+" – et oם est cette lettre de marque que tu as promis de m'apporter ?";
            link.l1 = "Pardon, Hugo, mais je ne l'ai pas encore.";
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_Novaya_Rodina.Patent") && pchar.questTemp.PDM_Novaya_Rodina.Patent == "Patent")
			{
				link.l2 = "Oh oui, ça a marché ! Don Francisco a dit qu'il t'inviterait à lui rendre visite à sa résidence au plus vite, avec tes dix mille, bien sמr. Et maintenant, je suppose que tu me dois 8 000, toi aussi ?";
				link.l2.go = "Ya_Ispania_Patent_1";
			}
		break;

		case "Havana_Cod_1":
            SetQuestHeader("PDM_Novaya_Rodina");
			AddQuestRecord("PDM_Novaya_Rodina", "1");
			AddQuestUserData("PDM_Novaya_Rodina", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PDM_Novaya_Rodina.Guber = "HugoLesopilka";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Ya_Ispania_Patent_1":
            dialog.text = "C'est une nouvelle incroyable, "+ GetSexPhrase("le gars", "la fille") +" ! Incroyable ! Voici ton or, et avec lui, accepte ma gratitude. Don Francisco, tu dis ? Je mets le cap dans cette direction immédiatement !";
            link.l1 = "Adieu, Hugo.";
			link.l1.go = "Ya_Ispania_Patent_Сod_1";
			AddMoneyToCharacter(pchar, 8001);
			TakeItemFromCharacter(pchar, "Patent_Espa_Lesopilka");
			NextDiag.TempNode = "Podhodim_SNOVA_vipemromu";
		break;

		case "Ya_Ispania_Patent_Сod_1":
			AddQuestRecord("PDM_Novaya_Rodina", "4");
			AddQuestUserData("PDM_Novaya_Rodina", "sSex", GetSexPhrase("", "e"));
			PChar.quest.PDM_HugoSeaHavana.win_condition.l1 = "EnterToSea"
			Pchar.quest.PDM_HugoSeaHavana.win_condition = "PDM_HugoSeaHavana";
			pchar.questTemp.PDM_Novaya_Rodina.Guber = "Lubopitno";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Podhodim_SNOVA_vipemromu":
            dialog.text = "Ah, "+ GetSexPhrase("le gars", "la fille") +" ! "+ GetSexPhrase("Encore toi", "Encore toi") +" par ici, hein ? Bon, je dois aller voir don Francisco... Enfin, après avoir bu une ou deux chopes à ta santé et à ma nouvelle patrie, l'Espagne !";
            link.l1 = "Merci pour tes gentilles paroles, Hugo. Je te laisse fêter ta nomination.";
			link.l1.go = "exit";
			PlayVoice("Kopcapkz\Voices\PDM\Hugo Lumbermill.wav");
			NextDiag.TempNode = "Podhodim_SNOVA_vipemromu";
		break;

		case "Novoe_Zadanie_1":
			PlayVoice("Kopcapkz\Voices\PDM\Timothy - Town Guard.wav");
            dialog.text = "Oh, c'est encore toi, capitaine "+pchar.name+" ! Content de te voir !";
            link.l1 = "Oh, ce vieux Hugo la Scierie ! Et alors, cette vie honnête ?";
			link.l1.go = "Novoe_Zadanie_2";
		break;

		case "Novoe_Zadanie_2":
            dialog.text = "Très bien, merci. Je te dirai qu'au début, les autres capitaines espagnols se méfiaient de moi, mais je leur ai montré quelques bottes de combat, et maintenant, nous sommes tous les meilleurs amis du monde\n"+
							"Ha ! וcoute, "+pchar.name+", en remerciement de ce que tu as fait pour moi, j'ai un bon conseil pour toi. Approche et écoute\n"+
							"Je sais oם tu peux te procurer une bonne marchandise, une très bonne marchandise. Vois-tu, "+pchar.name+", un de mes vieux, euh, amis, qui fait partie des pirates, tu vois... Eh bien, il m'a dit qu'un lourd galion anglais chargé de lingots d'or et d'argent avait été pris dans une violente tempête et qu'il était en réparation près de la Dominique.";
            link.l1 = "Et alors ?";
			link.l1.go = "Novoe_Zadanie_3";
		break;

		case "Novoe_Zadanie_3":
            dialog.text = "Quoi ? Qu'est-ce que tu as à te gratter la tête, "+pchar.name+" ? Il y a une fortune dans ce galion !";
            link.l1 = "Ah. Je comprends. Et... ?";
			link.l1.go = "Novoe_Zadanie_4";
		break;

		case "Novoe_Zadanie_4":
            dialog.text = "Eh bien, le navire est au mouillage près de la Dominique : tu la connais sמrement, une petite île entre la Guadeloupe et la Barbade. Mon ami a dit qu'il avait vu ce galion en réparation après une violente tempête : son gréement était endommagé, si l'on peut appeler ainsi son absence totale, et sa coque aussi. Il a dit que le navire pouvait à peine bouger. Sans chantier naval, la réparation risque de prendre du temps, alors il est coincé là-bas, pour ainsi dire, et n'attend plus qu'un capitaine vienne le capturer.";
            link.l1 = "Pourquoi ne le prends-tu pas toi-même ?";
			link.l1.go = "Novoe_Zadanie_5";
		break;

		case "Novoe_Zadanie_5":
            dialog.text = "Oh, tu crois que je t'attire dans un piège, hein ? Non, "+ GetSexPhrase("le gars", "la fille") +" : mon navire n'est pas assez puissant pour capturer un lourd galion, et je suis trop vieux pour changer de navire. Je connais chaque clou et chaque barre de ma Felicia, et je ne veux pas l'abandonner. Alors, "+ GetSexPhrase("le gars", "la fille") +", il est à toi si tu veux le prendre !";
            link.l1 = "Hmmm. Tu sais, je crois qu'on devrait aller y jeter un œil. Il est en rade de la Dominique, tu dis ? Eh bien, merci du conseil, Hugo. Adieu !";
			link.l1.go = "Novoe_Zadanie_Cod_1";
			NextDiag.TempNode = "Novoe_Zadanie_PodhodimSnova_1";
		break;

		case "Novoe_Zadanie_Cod_1":
			AddQuestRecord("PDM_Novaya_Rodina", "6");
			AddQuestUserData("PDM_Novaya_Rodina", "sSex", GetSexPhrase("", "e"));

			int Rank = sti(pchar.rank) - 3 + MOD_SKILL_ENEMY_RATE*3;
			if (Rank < 1) Rank = 1;
			sld = GetCharacter(NPC_GenerateCharacter("PDM_Lesopilka_Galeon", "off_eng_1", "man", "man", Rank, ENGLAND, -1, true));
			FantomMakeCoolSailor(sld, SHIP_GALEON_H, "Yummy", CANNON_TYPE_CANNON_LBS32, 20, 20, 50);
			FantomMakeCoolFighter(sld, Rank, 55, 55, "blade22", "pistol2", 120);
			SetCharacterPerk(sld, "Gunman");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "CriticalShoot");
			SetCharacterPerk(sld, "LongRangeShoot");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "SwordplayProfessional");
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "CriticalHit");
			SetCharacterPerk(sld, "Sliding");
			SetCharacterPerk(sld, "Energaiser");
			SetCharacterPerk(sld, "EnergyPlus");
			sld.equip.blade = "blade22";
			sld.equip.gun = "pistol2";
			AddItems(sld, "bullet", 10);
			AddItems(sld, "GunPowder", 10);
			EquipCharacterByItem(Pchar, "cirass1");
			AddCharacterGoodsSimple(sld, GOOD_GOLD, 800 + rand(400));
			AddCharacterGoodsSimple(sld, GOOD_SILVER, 800 + rand(400));
			AddCharacterGoodsSimple(sld, GOOD_WEAPON, 500);
			SetShipSkill(sld, 100, 80, 80, 80, 80, 80, 80, 80, 80);
			sld.ship.Crew.Morale = 100;
			sld.ship.masts.mast4 = 1;
			sld.ship.masts.mast3 = 1;
			sld.ship.masts.mast1 = 1;
			sld.ship.HP = sti(sld.ship.HP) / 3.5;
			sld.DontRansackCaptain = true;

			Group_FindOrCreateGroup("PDM_HUGO_GAL");
			Group_SetType("PDM_HUGO_GAL", "war");
			Group_AddCharacter("PDM_HUGO_GAL", "PDM_Lesopilka_Galeon");

			Group_SetGroupCommander("PDM_HUGO_GAL", "PDM_Lesopilka_Galeon");
			Group_SetTaskAttack("PDM_HUGO_GAL", PLAYER_GROUP);
			Group_SetAddress("PDM_HUGO_GAL", "Dominica", "quest_ships", "Quest_ship_2");
			Group_LockTask("PDM_HUGO_GAL");

			SetTimerCondition("PDM_Lesopilka_Vremy", 0, 0, 30, false);

			PChar.quest.PDM_Lesopilka_SJ.win_condition.l1 = "NPC_Death";
			PChar.quest.PDM_Lesopilka_SJ.win_condition.l1.character = "PDM_Lesopilka_Galeon";
			PChar.quest.PDM_Lesopilka_SJ.win_condition = "PDM_Lesopilka_SJ";

			PChar.quest.PDM_Lesopilka_SJNashel.win_condition.l1 = "item";
			PChar.quest.PDM_Lesopilka_SJNashel.win_condition.l1.item = "PDM_SJ_Angl_Gal";
			PChar.quest.PDM_Lesopilka_SJNashel.win_condition = "PDM_Lesopilka_SJNashel";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Novoe_Zadanie_PodhodimSnova_1":
            dialog.text = "Ah ! Tu boirais un coup avec moi, "+pchar.name+" ?";
            link.l1 = "Pas maintenant, Hugo. Mais merci !";
			link.l1.go = "Novoe_Zadanie_PodhodimSnova_2";
			PlayVoice("Kopcapkz\Voices\PDM\Hugo Lumbermill.wav");
		break;

		case "Novoe_Zadanie_PodhodimSnova_2":
            dialog.text = "Alors, pourquoi perds-tu ton temps ici, "+ GetSexPhrase("le gars", "la fille") +" ? Va prendre ce galion avant qu'il ne reprenne la mer !";
            link.l1 = "Tu as raison, Hugo. J'y vais. Adieu !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Novoe_Zadanie_PodhodimSnova_1";
		break;

		case "Novoe_Zadanie_ZaIspaniu":
            dialog.text = LinkRandPhrase("Je te suivrais à travers le feu et l'eau !", "Pour l'Espagne !", "Pour notre capitaine !");
            link.l1 = LinkRandPhrase("Continue comme ça, soldat !", "Bien joué !", "C'est bien, ma fille !");
			link.l1.go = "exit";
			NextDiag.TempNode = "Novoe_Zadanie_ZaIspaniu";
		break;

		case "Final_1":
            dialog.text = "Ha, "+ GetSexPhrase("le gars", "la fille")+", je savais que tu réussirais !";
            link.l1 = "Merci, Hugo. Je n'ai obtenu tous ces trésors que grâce à toi.";
			link.l1.go = "Final_2";
			PlayVoice("Kopcapkz\Voices\PDM\William Shakesbeer.wav");
		break;

		case "Final_2":
			dialog.text = "";
			if (sti(pchar.Money) >= 30000)
			{
				link.l1 = "Et je me suis dit que tu méritais ces 30 000 piastres.";
				link.l1.go = "Final_3";
				link.l2 = "Bon, Hugo, j'ai des choses à faire. א plus tard.";
				link.l2.go = "FinalPL_3";
				NextDiag.TempNode = "Final_Again";
			}
			else
			{
				link.l2 = "Bon, Hugo, j'ai des choses à faire. א plus tard.";
				link.l2.go = "FinalPL_3";
				NextDiag.TempNode = "Final_Again";
			}
		break;

		case "Final_3":
            dialog.text = "Oh-oh ! "+ GetSexPhrase("Mon garçon", "Ma fille")+", c'est très généreux de ta part, bien sמr que je prends cet argent ! On va boire un coup ?";
            link.l1 = "Pardon, Hugo, j'ai des affaires en cours, une autre fois peut-être. Adios !";
			link.l1.go = "Final_4";
			ChangeCharacterReputation(pchar, 5);
			NextDiag.TempNode = "Final_Again";
			AddMoneyToCharacter(pchar, -30000);
			AddCharacterExpToSkill(pchar, "Leadership", 70);
			AddCharacterExpToSkill(pchar, "Commerce", 70);
			AddCharacterExpToSkill(pchar, "Fortune", 70);
		break;

		case "Final_4":
			CloseQuestHeader("PDM_Novaya_Rodina");
			pchar.questdata.NovayaRodina = 1;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FinalPL_3":
			CloseQuestHeader("PDM_Novaya_Rodina");
			pchar.questdata.NovayaRodina = 1;
            sld = CharacterFromID("Hugo_Lesopilka");
			sld.lifeday = 0;
			ChangeCharacterReputation(pchar, -5);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Final_Again":
            dialog.text = "Ah ! Tu boirais un coup avec moi, "+pchar.name+" ?";
            link.l1 = "Pardon, Hugo, j'ai des affaires en cours, une autre fois peut-être. Adios !";
			link.l1.go = "exit";
			PlayVoice("Kopcapkz\Voices\PDM\William Shakesbeer.wav");
			NextDiag.TempNode = "Final_Again";
		break;


	}
}
