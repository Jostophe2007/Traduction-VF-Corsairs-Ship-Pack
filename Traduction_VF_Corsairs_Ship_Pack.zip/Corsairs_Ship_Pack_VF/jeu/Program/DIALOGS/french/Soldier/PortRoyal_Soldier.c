// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions avez-vous pour un soldat ?", "La vie de soldat est toute tracée : gardes, relèves... Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Il n'est pas convenable d'importuner un soldat avec des questions stupides, " + GetAddress_Form(NPChar) + "...", "Pour la troisième fois aujourd'hui, vous essayez de poser une question...",
                          "La part du soldat est déjà bien dure, et voilà que vous, "+ GetSexPhrase("espèce de gredin, ", "") +"venez m'énerver...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Ce n'est pas convenable...",
                      "Oui, c'est vraiment la troisième fois...", "Pardon...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			/*sld = characterFromId("eng_guber");
			if (npchar.location == "PortRoyal_townhall" && pchar.questTemp.State == "" && CheckAttribute(sld, "notQuestLine"))
			{
                dialog.text = "Key! Give me the key!!!";
				link.l1.edit = 7;
				link.l1 = "";
				link.l1.go = "ELOpenKey_1";
			}*/
		break;

		case "ELOpenKey_1":

			if (dialogEditStrings[7] == KEY_ENG_LINE)
			{
				dialog.text = "Vous savez de quoi il retourne, votre clé est acceptée. Je glisserai un mot en votre faveur à Madiford...";
				Link.l1 = "Très bien, l'ami. Merci...";
				Link.l1.go = "exit";
				sld = characterFromId("eng_guber");
				DeleteAttribute(sld, "notQuestLine");
			}
			else
			{
				dialog.text = "Vous ne savez pas de quoi il s'agit. Partez, ne me gênez pas dans mon service.";
				Link.l1 = "Hum, eh bien...";
				Link.l1.go = "exit";
			}
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

