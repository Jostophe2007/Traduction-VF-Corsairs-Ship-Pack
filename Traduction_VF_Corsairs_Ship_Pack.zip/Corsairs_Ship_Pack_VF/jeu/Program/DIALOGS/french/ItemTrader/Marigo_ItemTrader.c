// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Encore des questions, " + GetAddress_Form(NPChar) + "...", "Des questions, des questions... Et si on faisait plutכt du commerce, " + GetAddress_Form(NPChar) + " ?",
                          "וcoutez, combien de conversations creuses peut-on avoir ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Pas de questions...", "Je n'ai rien à dire pour le moment."), "Eh, encore...",
                      "Oui, il vaut vraiment mieux marchander...", "Hum, désolé, marchand...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Анжелика Тич: Портниха знатной дамы
			if(CheckAttribute(pchar, "questTemp.AT_PZD_Lavochniki") && !CheckAttribute(npchar, "AT_PZD_Vopros"))
			{
				link.l1 = "Pouvez-vous me dire oם je peux acheter une robe digne d'une sortie ?";
				link.l1.go = "AT_PZD_Lavochniki_1";
				DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki");
			}
            if(CheckAttribute(pchar, "questTemp.AT_PZD_Lavochniki_2") && !CheckAttribute(npchar, "AT_PZD_Vopros"))
            {
				link.l1 = "Il me faut une robe aussi belle que celle de l'épouse d'un banquier d'ici.";
				link.l1.go = "AT_PZD_Lavochniki_2";
				DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki_2");
			}
			if(CheckAttribute(pchar, "questTemp.AT_PZD_Lavochniki_3") && !CheckAttribute(npchar, "AT_PZD_Vopros"))
            {
				link.l1 = "Il me faut une robe, mais pas une robe ordinaire : une robe dans laquelle on n'aurait pas honte de paraître, même à une réception chez le roi de France en personne.";
				link.l1.go = "AT_PZD_Lavochniki_3";
				DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki_3");
			}
			// <== Анжелика Тич: Портниха знатной дамы
		break;
		
		//============ Анжелика Тич: Портниха знатной дамы
		case "AT_PZD_Lavochniki_1":
    		dialog.text = "Vous n'en trouverez guère au marché. Vous devriez trouver une bonne couturière. Malheureusement, je ne peux recommander personne..";
    		link.l1 = "D'accord...";
    		link.l1.go = "exit";
			pchar.questTemp.AT_PZD_Lavochniki_2 = true;
			npchar.AT_PZD_Vopros;
 		break;
		
		case "AT_PZD_Lavochniki_2":
    		dialog.text = "Non, madame, je n'ai pas ça en vente.";
    		link.l1 = "D'accord...";
    		link.l1.go = "exit";
			pchar.questTemp.AT_PZD_Lavochniki_3 = true;
			npchar.AT_PZD_Vopros;
 		break;
		
		case "AT_PZD_Lavochniki_3":
    		dialog.text = "Chez le tailleur du roi de France, oם d'autre. Et nous, nous sommes des gens simples, pas comme ces riches messieurs qui fréquentent le bordel d'ici.";
    		link.l1 = "Comme c'est intéressant, ces messieurs jouissent d'un statut particulier ? Ils ne vont sמrement pas voir les filles du port ?";
    		link.l1.go = "AT_PZD_Lavochniki_3_1";
 		break;
		
		case "AT_PZD_Lavochniki_3_1":
    		dialog.text = "Pardon, mais ce n'est pas mon genre de colporter des ragots. Allez-y et demandez, on vous proposera peut-être quelque chose de spécial, mais moi, ne me demandez rien. La patronne de là-bas est une dame en vue, elle achète son vin à mon cousin, c'est un excellent vigneron, et je n'ai aucune raison de dire du mal d'elle.";
    		link.l1 = "Je vous comprends. Eh bien, j'en prends note, et j'achèterai sמrement votre vin un de ces jours.";
    		link.l1.go = "exit";
 		break;
		

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

