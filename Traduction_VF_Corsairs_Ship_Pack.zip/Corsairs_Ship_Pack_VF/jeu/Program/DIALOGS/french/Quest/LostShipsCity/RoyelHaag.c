#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bonjour ! Comment vous trouvez-vous chez nous ? C'est une belle cité, n'est-ce pas ? Et par temps de tempête, c'est tout simplement magnifique !";
					link.l1 = "Absolument ! C'est moi seul qui ai réchappé de cette tempête ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bonjour ! Comment vous trouvez-vous chez nous ? C'est une belle cité, n'est-ce pas ?";
					link.l1 = "Absolument. Je m'appelle " + GetFullName(pchar) + ", j'étais...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("mynheer", "madame") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				link.l2.go = "int_quests";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoute, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "On dirait bien que oui. J'en suis vraiment désolé...";
			link.l1 = "C'est la vie... Oui, permettez-moi de me présenter. Je m'appelle " + GetFullName(pchar) + ", j'étais...";
			link.l1.go = "FT_1";
		break;
		case "FT_1":
			dialog.text = "Peu importe qui vous étiez. Je vous recommande cette construction : je n'emploie pas le mot « cité », ici. Bref, une nouvelle vie a commencé pour vous, et il n'y a pas de retour en arrière possible. Au fait, je suis " + GetFullName(npchar) + ".";
			link.l1 = "Et qu'est-ce qui vous rend si sמr de vous, mynheer " + npchar.lastname + " ? Pourquoi n'y aurait-il pas de retour possible ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Parce qu'en trois ans passés ici, j'ai vu plus d'une fois oם vont ceux qui tentent de repartir. Croyez-moi, il y fait froid et humide, et ils y resteront pour toujours. Je veux parler du purgatoire...";
			link.l1 = "J'ai compris. Hum, et qui les aide à trouver le nirvana ? Ce ne serait pas Capper ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Héhé héhé... Chad Capper est notre tout, et en même temps, il est notre rien. De toute façon, vous devrez suivre ses instructions. Alors, vous devriez faire attention à ce que vous dites.";
			link.l1 = "Faire attention ? Et si je n'ai pas envie de faire attention ?!";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Eh bien, dans ce cas, je prierai pour le repos de votre âme. Sans aucun doute, le sort de Leighton Dexter vous attend.";
			link.l1 = "Hum, et qu'est-il arrivé à ce Dexter ?";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Je ne veux pas en parler. Si vous voulez savoir quelque chose sur lui, demandez plutכt à Lea Toors.";
			link.l1 = "D'accord... Vous savez, l'espoir est une bonne chose, mynheer " + npchar.lastname + ". En vous persuadant que la situation est sans issue, vous la rendez telle vous-même.";
			link.l1.go = "FT_6";
			AddQuestRecord("LSC_findDekster", "2");
			AddQuestUserData("LSC_findDekster", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("LSC_findDekster", "sSex1", GetSexPhrase("", "e"));
		break;
		case "FT_6":
			dialog.text = "Peut-être, tout est possible. Mais ce n'est pas si terrible. Nous avons la Loi, nous avons notre propre vie, nous avons... de l'intérêt. Je dirais même que je me plais ici.";
			link.l1 = "Vous êtes un opportuniste !";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "Et alors ? א mon avis, c'est très bien, dans cette situation. D'ailleurs, je vous le conseille sincèrement à vous aussi.";
			link.l1 = "Eh bien, bonne chance à vous, mynheer " + npchar.lastname + ".";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, vous vous prenez pour d'Artagnan, à courir partout en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Je vais essayer de redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "madame") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Cette Loi... y a-t-il un moyen de la contourner ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Il n'y a qu'un seul pouvoir dans la Cité ? Il y a bien... des opposants à l'amiral ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Y a-t-il un endroit oם s'amuser ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l4 = "Dites-moi, depuis combien de temps vivez-vous ici ? Vous n'en avez pas assez ?";
				link.l4.go = "ansewer_4";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "On peut tout contourner, "+ GetSexPhrase("l'ami", "madame") +". Ce qui compte, c'est la façon dont ça finit. Je suis sמr que vous voulez parler de partir d'ici en bateau...";
			link.l1 = "C'est exactement de ça qu'il s'agit !";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Eh bien, c'est possible...";
			link.l1 = "Je suis tout ouïe.";
			link.l1.go = "ansewer_1_2";
		break;
		case "ansewer_1_2":
			dialog.text = "...dans un cercueil, ha ha ha !..";
			link.l1 = "Vous êtes un drכle de mynheer, vous savez...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Autant que vous voudrez. Cherchez sous les planches et au fond ce qu'il en reste... Nous avons des clans, mais ils vivent en paix avec l'amiral et les citoyens de la Cité. Du moins, tant que vous n'entrez pas dans leurs navires.";
			link.l1 = "Et que se passe-t-il si j'y entre ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Ils tueront sans aucun doute celui qui y sera entré.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "S'amuser ? Vous êtes venu ici pour vous amuser ?!";
			link.l1 = "Hum, pourquoi pas ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Vous vous amuserez quand vous serez sorti d'ici ! Hum, mais voilà le problème : c'est impossible ! Ha ha ha !";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Bien sמr que j'en ai assez. Mais oם aller ? Eh oui, nulle part.";
			link.l1 = "Eh oui... Hill Brunner était-il déjà là quand vous êtes arrivé ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Il était là, il régnait déjà en maître dans sa taverne. Oh, c'est dommage pour lui, c'était un bon aubergiste.";
			link.l1 = "דa, c'est sמr...";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Très bien. En quoi puis-je vous aider ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je cherche des bombes, de la mitraille, des vivres, des médicaments, de la poudre, des armes...",
				"Oui... Pardon, j'avais oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Je vois. Pour la poudre et les armes, mieux vaut s'adresser à l'amiral. Les bombes, la mitraille et autres munitions, ce sont les maîtresses de maison qui les ont. Et c'est le saint père qui a les médicaments.";
			link.l1 = "Je comprends. Merci beaucoup.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Pardon, quoi ?";
			link.l1 ="Je vous propose de venir comme matelot sur mon navire. Je pars bientכt.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "דa alors !.. Et comment avez-vous réussi ce coup-là ? La Loi l'interdit pourtant...";
			link.l1 = "Désolé, je n'ai pas le temps. Vous acceptez ?";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Bien sמr que j'accepte. Qu'y a-t-il à discuter ?";
			link.l1 = "Bien ! Alors, allez tout de suite au San Gabriel. Le Mécanicien vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, c'est ce que je vais faire. Je dois juste rassembler mes affaires.";
			link.l1 = "D'accord, mais ne traînez pas.";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
