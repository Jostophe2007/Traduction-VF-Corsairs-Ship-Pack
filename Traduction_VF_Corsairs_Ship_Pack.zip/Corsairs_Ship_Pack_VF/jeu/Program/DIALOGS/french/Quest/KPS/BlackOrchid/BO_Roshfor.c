// Gregg: Alan Rochefort, sailing master of the Anna - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Nous attendons vos ordres, capitaine.";
			link.l1 = "Nous restons pour l'instant.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Vous êtes venu pour Moris ? Vous arrivez trop tard. Il est descendu à terre il y a quatre jours et il n'est pas revenu.";
			link.l1 = "Et vous, qui êtes-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Alan Rochefort, maître de manœuvre. L'Anna est à lui, mais c'est moi qui la mène, car depuis deux ans, Moris ne regarde que dans une seule direction.";
			link.l1 = "Vers Bruce Fisher.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Exactement. Le père Fisher a pris le Seeker à Moris il y a une vingtaine d'années, et depuis, il n'a rien d'autre en tête. Quand Rick est mort, Moris s'en est pris au fils.";
			link.l1 = "Oם est-il descendu à terre ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "א la Dominique, sur la cכte d'en face. On lui avait dit que le Seeker y était en carénage. Il a pris un pistolet et une chaloupe, et il a interdit à quiconque de le suivre. Quatre jours, capitaine.";
			link.l1 = "Montrez-moi l'endroit.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToCaiman");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
