// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            if (CheckAttribute(pchar, "RomanticQuest.ShipToCumana"))
			{
    			link.l1 = "Savez-vous oם je peux trouver le capitaine du brick Cinq Plaies du Christ ?";
    			Link.l1.go = "RomanticQuest_1";
			}
			if (CheckAttribute(pchar, "RomanticQuest.ShipToCumanaTavenrn"))
			{
    			link.l1 = "Oם puis-je trouver le capitaine du brick « Cinq Plaies du Christ » ? On m'a dit qu'il était ici.";
    			Link.l1.go = "RomanticQuest_2";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_toCumana")
			{
				link.l1 = "Un certain capitaine de brick, nommé Edward Law, est-il venu chez vous ?";
				link.l1.go = "PL_Q3_1";
			}
		break;

		case "RomanticQuest_1":
			dialog.text = "Oui, ce capitaine passe par ici, il fait réparer son navire depuis quelque temps. Mais il n'est pas là en ce moment. Cherchez en ville.";
			link.l1 = "Merci !";
			link.l1.go = "exit";
		break;
		case "RomanticQuest_2":
			dialog.text = "Il est assis à une table ronde, et il boit du vin à n'en plus finir.";
			link.l1 = "Merci !";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "RomanticQuest.ShipToCumanaTavenrn");
		break;

		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Non. C'est la première fois que j'entends ce nom.",
				"J'ai déjà répondu à cette question.",
				"Nous avons déjà parlé de ce Law...",
                "Pour la dernière fois, je n'ai jamais entendu parler d'Edward Law !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, l'ami.",
				"Oui, oui, je m'en souviens...",
                "Oui, bien sמr...",
				"Compris.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

