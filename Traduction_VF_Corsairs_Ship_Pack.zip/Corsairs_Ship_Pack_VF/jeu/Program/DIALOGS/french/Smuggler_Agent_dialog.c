void ProcessDialogEvent()
{
	ref NPChar, her;
	aref Link, NextDiag;
	bool bOk = false;
    bool bOk2;

	int Sum, nRel, nDay, iChurchQuest2_Summ;
	ref sld;

	// Церковный квест № 2 -->
	if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_1") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Summ_To_Contra"))
	{
		iChurchQuest2_Summ = sti(PChar.rank)*100 + (rand(3)+1)*100;
		PChar.GenQuest.ChurchQuest_2.Summ_To_Contra = sti(iChurchQuest2_Summ);
	}
	// <-- Церковный квест № 2

	string sColony;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    string iDay, iMonth;
	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;

	if (!CheckAttribute(npchar, "quest.trade_date"))
    {
        npchar.quest.trade_date = "";
    }

	//тереть нафиг аттрибут при прошествии дней (navy fix)
	if (CheckAttribute(pchar, "GenQuest.contraTravel.days") && GetQuestPastDayParam("contraTravel") > sti(PChar.GenQuest.contraTravel.days))
	{
		DeleteAttribute(pchar, "GenQuest.contraTravel");
		CloseQuestHeader("Gen_ContrabandTravel");
	}

	switch(Dialog.CurrentNode)
	{
        case "Exit":
			DeleteAttribute(npchar, "pricevalue");
			DeleteAttribute(npchar, "pricev");
			DeleteAttribute(npchar, "itemtype");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Trade_exit":
            if (CheckNPCQuestDate(npchar, "Item_date"))
			{
				SetNPCQuestDate(npchar, "Item_date");
				GiveItemToSmuggler(npchar);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(npchar);
		break;

		case "Smuggling_exit":
			PChar.CurrentSmuggler = npchar.id;
			NextDiag.CurrentNode = NextDiag.TempNode;
			PlaceSmugglersOnShore(Pchar.quest.contraband.CurrentPlace);
			Pchar.quest.Contraband.active = true;
			pchar.GenQuest.Contraband.GuardNation = npchar.nation;
			pchar.GenQuest.Contraband.SmugglerId  = npchar.id;
			SetAllContraGoods(&Stores[sti(Pchar.GenQuest.Contraband.StoreIdx)], npchar);
			ReOpenQuestHeader("Gen_Contraband");
            if (GetIslandByCityName(npchar.city) == "Mein")
            {
            	AddQuestRecord("Gen_Contraband", "t1_1");
            }
            else
            {
	            AddQuestRecord("Gen_Contraband", "t1");
				AddQuestUserData("Gen_Contraband", "sIsland", XI_ConvertString(GetIslandByCityName(npchar.city)));
			}
			AddQuestUserData("Gen_Contraband", "sLoc", GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt"));

			DialogExit();
		break;

		case "First time":
		UpdateSmugglers();
		//ОЗГ
			if (CheckAttribute(pchar, "contrabandmoneyback") && sti(pchar.contrabandmoneyback) >= 1000000+(MOD_SKILL_ENEMY_RATE*1000000) && !CheckCharacterPerk(pchar, "UnlimitedContra"))
			{
				dialog.text = "Capitaine, vous êtes un client vraiment précieux pour toute la contrebande. Désormais, on vous fera les meilleures conditions.";
				link.l1 = "Merci de votre confiance.";
				link.l1.go = "First time";
				Log_info("La compétence « Contrebandier invétéré » est débloquée");
				SetCharacterPerk(pchar, "UnlimitedContra");
				NPChar.quest.meeting = "1";
				break;
			}
			int iCondottiereRankReq = 1;
			if (!bQuestsRank) iCondottiereRankReq = 10;	//Если стоит галочка, то убрать требования рангов у квестов
			if (!CheckAttribute(pchar, "questTemp.Headhunter") && sti(pchar.rank) >= iCondottiereRankReq)	//Квест Кондотьер
			{
				dialog.text = "Capitaine, j'aimerais vous parler d'une affaire. א ce que je vois, vous êtes un visage nouveau dans l'archipel, et les Frères de la Cכte ne vous connaissent pas encore... Vous êtes peut-être justement la personne qu'il nous faut.";
				link.l1 = "Hum... Intéressant. Exposez votre affaire.";
				link.l1.go = "Give_vector";
				break;
			}
			// contraband freight from the trader journal (shown both at first meeting and in the standard menu; disappears once the bay is set - no duplicate journal records)
			bool bSmugFreight = false;
			if (CheckAttribute(pchar, "CargoQuest.iOrderType") && sti(pchar.CargoQuest.iOrderType) == 5 && CheckAttribute(pchar, "CargoQuest.TraderID") && characters[GetCharacterIndex(pchar.CargoQuest.TraderID)].city == npchar.city && !CheckAttribute(pchar, "quest.SmuggleFreight.active"))
			{
				if (CheckQuestAttribute("generate_trade_quest_progress", "begin") || CheckQuestAttribute("generate_trade_quest_progress", "failed")) bSmugFreight = true;
			}

			if(NPChar.quest.meeting == "0")
			{
				Dialog.Text = "Que voulez-vous, capitaine ? Je ne connais pas votre nom, et je ne peux pas vous dire le mien.";
				Link.l1 = "Je suis le capitaine " + GetFullName(pchar) + ".";
				Link.l1.go = "meeting";
				if (bSmugFreight)
				{
					Link.l6 = "(à voix basse) Psst... J'ai une commande spéciale pour vous. Cette cargaison-là.";
					Link.l6.go = "SmuggleFreight_Deliver";
				}
				NPChar.quest.meeting = "1";
			}
			else
			{
				if(CheckAttribute(pchar, "GenQuest.CaptainComission.GetRumour") && GetQuestPastDayParam("GenQuest.CaptainComission.GetRumour") < 1)
				{
					if(!CheckAttribute(pchar, "GenQuest.CaptainComission.SpeakContra"))
					{
						pchar.GenQuest.CaptainComission.SpeakContra = true;
						dialog.text = "Il n'y aura pas d'affaires aujourd'hui. Toutes les baies grouillent de patrouilles : le gouverneur cherche une cargaison que le capitaine de la patrouille, " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + ", aurait soi-disant confisquée à un pirate avant de la cacher.";
						link.l1 = "Et oם est le capitaine lui-même ?" + pchar.GenQuest.CaptainComission.Name + " ?";
						link.l1.go = "CapComission_1";
						break;
					}
					else
					{
						dialog.text = "Il n'y aura pas d'affaires aujourd'hui.";
						link.l1 = "Je vois.";
						link.l1.go = "exit";
						break;
					}
				}

				if(pchar.questTemp.Slavetrader == "FindMayak" && Islands[GetCharacterCurrentIsland(pchar)].id == pchar.questTemp.Slavetrader.EsIsland)
				{
					dialog.text = "Il n'y aura pas d'affaires aujourd'hui.";
					link.l1 = "Je vois.";
					link.l1.go = "exit";
					break;
				}

				Dialog.Text = "Qu'avez-vous apporté cette fois, capitaine ?";
				if (LAi_group_GetPlayerAlarm() > 0)
				{
	       			Dialog.Text = RandPhraseSimple("Parle vite, "+ GetSexPhrase("l'ami", "ma petite") +", qu'est-ce qu'il te faut ? Tu sais bien qu'on te court après !", "Ne traîne pas, expose vite ton affaire ! Les soldats te courent après, ce n'est pas le moment des longues conversations, tu sais...");
				}
				if(FindFirstContrabandGoods(PChar) != -1)
				{
					Link.l1 = "J'ai apporté quelques objets à vendre.";
					Link.l1.go = "Meeting_3";
				}

				if (CheckAttribute(pchar, "GenQuest.contraTravel.active") && sti(pchar.GenQuest.contraTravel.active) == true)
					Link.l2 = "Au sujet du voyage...";
				else
					Link.l2 = "J'ai besoin de me rendre quelque part.";
				Link.l2.go = "Travel";
				if (CheckCharacterItem(pchar, "CaptainBook") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakSmuggler"))
				{
					if((pchar.questTemp.different.GiveShipLetters.city == npchar.city) && CheckAttribute(pchar, "questTemp.different.GiveShipLetters"))
					{
						link.l3 = "J'ai un objet « spécial », je pense que ça va t'intéresser. Jette un œil !";
						link.l3.go = "SM_ShipLetters_1";
					}
				}
				// Церковный генератор №2 -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_1") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					Link.l4 = "J'ai besoin de tirer quelque chose au clair, l'ami.";
					Link.l4.go = "Contra_GenQuest_Church_2_1";
				}

				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_2") && NPChar.location == PChar.GenQuest.ChurchQuest_2.Contra_Colony + "_tavern")
				{
					Link.l5 = "Votre collègue et mon bon ami de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_2.QuestTown + "Gen") + " m'a dit que vous étiez au courant d'une affaire.";
					Link.l5.go = "Contra_GenQuest_Church_2_Contra2_1";
				}
				// <-- Церковный генератор №2

		    	////////////////////////////////////////////////////////
		    	//zagolski. начальный квест пирата
		    	if(CheckAttribute(pchar, "questTemp.pirateStartQuest") && pchar.questTemp.pirateStartQuest == "2" && GetArealByCityName(npchar.city) == pchar.questTemp.pirateStartQuest.Areal && npchar.city != pchar.questTemp.pirateStartQuest.City)
		    	{
			    	link.l4 = "וcoute, j'ai désespérément besoin d'une centaine ou deux d'esclaves. Je ne sais plus à qui m'adresser.";
			    	link.l4.go = "pirateStartQuest_Smuggler";
			    }

				if (CheckAttribute(pchar, "contratrade.time"))
				{
					if (pchar.contratrade.time != GetDataDay() && ChangeContrabandRelation(pchar, 0) > 5)
					{
						Link.l17 = "(à voix basse) J'ai entendu dire qu'on pouvait t'acheter quelque chose d'intéressant.";
						Link.l17.go = "Trade";
					}
				}
				if (!CheckAttribute(pchar, "contratrade.time") && ChangeContrabandRelation(pchar, 0) > 5)
				{
					Link.l17 = "(à voix basse) J'ai entendu dire qu'on pouvait t'acheter quelque chose d'intéressant.";
					Link.l17.go = "Trade";
				}
				if (CheckAttribute(pchar, "RimalieGood") && npchar.id == "PortSpein_Smuggler" && ChangeContrabandRelation(pchar, 0) > 5)
				{
					Link.l18 = "J'aimerais parler d'un mousquetaire qui vit en ermite sur une île voisine.";
					Link.l18.go = "Rimalie";
				}

				if (bSmugFreight)
				{
					Link.l6 = "(à voix basse) Psst... J'ai une commande spéciale pour vous. Cette cargaison-là.";
					Link.l6.go = "SmuggleFreight_Deliver";
				}
				if (ContraBlock_Any())
				{
					Link.l8 = "(à mi-voix) Deux ou trois villes m'ont fermé leur porte dans notre branche. Tu pourrais arranger ça ?";
					Link.l8.go = "ContraUnblock_List";
				}
				Link.l7 = "Rien. א plus tard.";
				Link.l7.go = "Exit";
			}
		break;

		case "SmuggleFreight_Deliver":
			// неприметная эскадра обязательна и на сдаче (не больше 3 кораблей, каждый не мощнее 3 класса) - вдруг "подцепили" корабли по пути
			if (!CheckSmuggleFreightShips())
			{
				dialog.text = "(jetant un regard autour de lui) דa ne va pas, capitaine. Le marché, c'était de travailler discrètement : pas plus de trois voiles, et pas de navires puissants au-dessus du troisième rang. Avec une armada pareille, la moitié de la flotte de patrouille va vous suivre. Débarrassez-vous du surplus, et nous vous remettrons la cargaison.";
				link.l1 = "Compris. Je reviendrai sans les navires en trop.";
				link.l1.go = "exit";
				break;
			}
			int iSmF_Goods = makeint(pchar.CargoQuest.iTradeGoods);
			int iSmF_Qty   = makeint(pchar.CargoQuest.iQuantityGoods);
			if (GetSquadronGoods(pchar, iSmF_Goods) < iSmF_Qty)
			{
				dialog.text = "Oם est la cargaison ? Il en manque dans votre cale. Apportez jusqu'à la dernière caisse, et ensuite on parlera.";
				link.l1 = "Je vais chercher le reste et je reviens.";
				link.l1.go = "exit";
				break;
			}
			// arrange a bay meeting - just like a normal contraband deal (handover + land/sea patrol)
			Pchar.quest.contraband.CurrentPlace = SelectSmugglingLocation();
			PChar.CurrentSmuggler = npchar.id;
			PlaceSmugglersOnShore(Pchar.quest.contraband.CurrentPlace);
			Pchar.quest.Contraband.active = true;
			Pchar.quest.Contraband.Counter = 0;
			Pchar.quest.contraband.City = npchar.city;
			pchar.GenQuest.Contraband.GuardNation = npchar.nation;
			pchar.GenQuest.Contraband.SmugglerId  = npchar.id;
			pchar.quest.SmuggleFreight.active = true; // flag: the bay meeting is a freight handover, not regular trade
			// детект нападения ГГ на смуглеров ДО передачи груза (по первому удару) + чистка флагов сценария
			DeleteAttribute(pchar, "quest.SmugScamGiveCalled");
			DeleteAttribute(pchar, "quest.SmugScamSurrendered");
			int paI;
			ref paM;
			for (paI = 1; paI <= 3 + makeint(MOD_SKILL_ENEMY_RATE * 3 / 2); paI++)
			{
				if (GetCharacterIndex("Rand_Smug0" + paI) == -1) continue;
				paM = CharacterFromID("Rand_Smug0" + paI);
				if (LAi_isDead(paM)) continue;
				LAi_SetCheckMinHP(paM, LAi_GetCharacterHP(paM) - 1, false, "SmugFreightPre_Attacked");
			}
			AddQuestRecord("DELIVERY_TRADE_QUEST", "smug2");
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sLoc", GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt"));
			AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony", XI_ConvertString("Colony"+npchar.city+"Gen"));
			dialog.text = "Pas ici, capitaine. Amenez votre navire jusqu'à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + " : mes hommes y prendront la cargaison, de main en main. Et ouvrez l'œil : les gens comme vous ont tendance à se faire suivre.";
			link.l1 = "Compris. Je serai à la baie.";
			link.l1.go = "exit";
		break;

		// --- clearing a blacklisted (scammed) contraband city: list of blocked cities + price (goods +50%) ---
		case "ContraUnblock_List":
			if (!ContraBlock_Any())
			{
				dialog.text = "Aucune porte ne vous est fermée pour l'instant. Si vous faites une bêtise quelque part, venez me voir, j'arrangerai ça.";
				link.l1 = "Bien.";
				link.l1.go = "First time";
				break;
			}
			dialog.text = "J'ai les bonnes relations. Dites-moi oם l'on vous a fermé la porte dans notre branche : j'arrangerai ça, moyennant une part.";
			int iUB;
			string sUBCity, sUBLink;
			for (iUB = 0; iUB < 5; iUB++)
			{
				sUBCity = ContraBlock_CityByIndex(iUB);
				if (sUBCity == "") break;
				sUBLink = "l" + iUB;
				link.(sUBLink) = XI_ConvertString("Colony" + sUBCity + "Gen") + " (" + FindRussianMoneyString(ContraBlock_Fee(sUBCity)) + ")";
				link.(sUBLink).go = "ContraUnblock_" + sUBLink;
			}
			link.l9 = "Pas maintenant.";
			link.l9.go = "First time";
		break;

		case "ContraUnblock_l0":
			string sUB0 = ContraBlock_CityByIndex(0);
			if (sUB0 == "") { dialog.text = "Celle-là est déjà réglée. Autre chose ?"; link.l1 = "Montre-moi la liste."; link.l1.go = "ContraUnblock_List"; break; }
			if (sti(pchar.money) < ContraBlock_Fee(sUB0)) { dialog.text = "L'argent d'abord, "+ GetSexPhrase("l'ami","ma belle") +". Pas d'argent, pas d'affaire."; link.l1 = "Je reviendrai."; link.l1.go = "ContraUnblock_List"; break; }
			dialog.text = "Considérez que c'est fait. א "+ XI_ConvertString("Colony"+sUB0+"Gen") +" on répondra de nouveau de vous : acceptez du fret comme si de rien n'était.";
			ContraBlock_Unblock(sUB0);
			link.l1 = "Bien obligé.";
			link.l1.go = "ContraUnblock_List";
		break;

		case "ContraUnblock_l1":
			string sUB1 = ContraBlock_CityByIndex(1);
			if (sUB1 == "") { dialog.text = "Celle-là est déjà réglée. Autre chose ?"; link.l1 = "Montre-moi la liste."; link.l1.go = "ContraUnblock_List"; break; }
			if (sti(pchar.money) < ContraBlock_Fee(sUB1)) { dialog.text = "L'argent d'abord, "+ GetSexPhrase("l'ami","ma belle") +". Pas d'argent, pas d'affaire."; link.l1 = "Je reviendrai."; link.l1.go = "ContraUnblock_List"; break; }
			dialog.text = "Considérez que c'est fait. א "+ XI_ConvertString("Colony"+sUB1+"Gen") +" on répondra de nouveau de vous : acceptez du fret comme si de rien n'était.";
			ContraBlock_Unblock(sUB1);
			link.l1 = "Bien obligé.";
			link.l1.go = "ContraUnblock_List";
		break;

		case "ContraUnblock_l2":
			string sUB2 = ContraBlock_CityByIndex(2);
			if (sUB2 == "") { dialog.text = "Celle-là est déjà réglée. Autre chose ?"; link.l1 = "Montre-moi la liste."; link.l1.go = "ContraUnblock_List"; break; }
			if (sti(pchar.money) < ContraBlock_Fee(sUB2)) { dialog.text = "L'argent d'abord, "+ GetSexPhrase("l'ami","ma belle") +". Pas d'argent, pas d'affaire."; link.l1 = "Je reviendrai."; link.l1.go = "ContraUnblock_List"; break; }
			dialog.text = "Considérez que c'est fait. א "+ XI_ConvertString("Colony"+sUB2+"Gen") +" on répondra de nouveau de vous : acceptez du fret comme si de rien n'était.";
			ContraBlock_Unblock(sUB2);
			link.l1 = "Bien obligé.";
			link.l1.go = "ContraUnblock_List";
		break;

		case "ContraUnblock_l3":
			string sUB3 = ContraBlock_CityByIndex(3);
			if (sUB3 == "") { dialog.text = "Celle-là est déjà réglée. Autre chose ?"; link.l1 = "Montre-moi la liste."; link.l1.go = "ContraUnblock_List"; break; }
			if (sti(pchar.money) < ContraBlock_Fee(sUB3)) { dialog.text = "L'argent d'abord, "+ GetSexPhrase("l'ami","ma belle") +". Pas d'argent, pas d'affaire."; link.l1 = "Je reviendrai."; link.l1.go = "ContraUnblock_List"; break; }
			dialog.text = "Considérez que c'est fait. א "+ XI_ConvertString("Colony"+sUB3+"Gen") +" on répondra de nouveau de vous : acceptez du fret comme si de rien n'était.";
			ContraBlock_Unblock(sUB3);
			link.l1 = "Bien obligé.";
			link.l1.go = "ContraUnblock_List";
		break;

		case "ContraUnblock_l4":
			string sUB4 = ContraBlock_CityByIndex(4);
			if (sUB4 == "") { dialog.text = "Celle-là est déjà réglée. Autre chose ?"; link.l1 = "Montre-moi la liste."; link.l1.go = "ContraUnblock_List"; break; }
			if (sti(pchar.money) < ContraBlock_Fee(sUB4)) { dialog.text = "L'argent d'abord, "+ GetSexPhrase("l'ami","ma belle") +". Pas d'argent, pas d'affaire."; link.l1 = "Je reviendrai."; link.l1.go = "ContraUnblock_List"; break; }
			dialog.text = "Considérez que c'est fait. א "+ XI_ConvertString("Colony"+sUB4+"Gen") +" on répondra de nouveau de vous : acceptez du fret comme si de rien n'était.";
			ContraBlock_Unblock(sUB4);
			link.l1 = "Bien obligé.";
			link.l1.go = "ContraUnblock_List";
		break;

		case "Rimalie":
			if (!CheckAttribute(pchar, "RimalieWait"))
			{
				Dialog.Text = "Bien sמr, j'ai entendu parler de lui. Un de mes collègues a eu des ennuis à cause de lui. Il a fait échouer une affaire et volé une partie de la marchandise pendant que tout le monde avait le dos tourné.";
				Link.l1 = "Je pourrais peut-être compenser les pertes causées par son acte ?";
				Link.l1.go = "Rimalie_2";
			}
			else
			{
				Dialog.Text = "Encore lui... ? 50 000 piastres, tout de suite. Si vous payez, nous le laisserons tranquille.";
				if (sti(pchar.money) >= 50000)
				{
					Link.l1 = "Voilà.";
					Link.l1.go = "Rimalie_3";
				}
				Link.l2 = "Je reviendrai pour ça.";
				Link.l2.go = "exit";
			}
		break;

		case "Rimalie_2":
			if (ChangeContrabandRelation(pchar, 0) >= 70)
			{
				Dialog.Text = "Vous êtes un client assez respecté de notre organisation, et vous nous avez rapporté gros. Pour vous, nous sommes prêts à faire des concessions et à cesser immédiatement de le harceler. Vous tenez vraiment tant à lui ? Il court de bien mauvaises rumeurs sur Rimbaud. Vous n'avez pas peur ?";
				Link.l1 = "Pour un bon officier mousquetaire, ce n'est pas un péché de prendre un risque. Merci pour votre aide !";
				Link.l1.go = "exit";
				pchar.RimalieDone = true;
				DeleteAttribute(pchar, "RimalieGood");
				DeleteAttribute(pchar, "RimalieWait");
			}
			else
			{
				pchar.RimalieWait = true;
				Dialog.Text = "Pour les dommages, nous voulons... 50 000 piastres, tout de suite. Si vous payez, nous le laisserons tranquille.";
				if (sti(pchar.money) >= 50000)
				{
					Link.l1 = "Voilà.";
					Link.l1.go = "Rimalie_3";
				}
				Link.l2 = "Je reviendrai pour ça.";
				Link.l2.go = "exit";
			}
		break;


		case "Rimalie_3":
			AddMoneyToCharacter(pchar,-50000);
			Dialog.Text = "C'est un plaisir de traiter avec vous. Mais vous tenez vraiment tant à lui ? Il court de bien mauvaises rumeurs sur Rimbaud. Vous n'avez pas peur ?";
			Link.l1 = "Pour un bon officier mousquetaire, ce n'est pas un péché de prendre un risque. א plus tard !";
			Link.l1.go = "exit";
			pchar.RimalieDone = true;
			DeleteAttribute(pchar, "RimalieGood");
			DeleteAttribute(pchar, "RimalieWait");
			AddQuestRecord("Rimalie", "2");
		break;

		case "CapComission_1":
			if(pchar.GenQuest.CaptainComission.variant == "A2")
			{
				dialog.text = "Dans les caves du fort, oם voulez-vous qu'il soit ? Le capitaine peut à tout moment révéler aux autorités l'endroit oם il a caché la cargaison, et nous en serons pour nos frais. Alors, tant que toute cette agitation ne sera pas retombée, ne pensez même pas aux affaires.";
				link.l1 = "וcoute, tu connais chaque pierre de l'île. Tu ne connaîtrais pas la cachette du capitaine ? " + pchar.GenQuest.CaptainComission.Name + " ?";
				link.l1.go = "CapComission_4";
			}
			if(pchar.GenQuest.CaptainComission.variant == "A3")
			{
				dialog.text = "Au paradis, sans doute. Il a été exécuté récemment avec son équipage. Et le verdict ne disait pas que le navire était pirate.";
				link.l1 = "Et comment êtes-vous sמr que le navire appartenait à des pirates ?";
				link.l1.go = "CapComission_2";
			}
		break;

		case "CapComission_2":
			dialog.text = "Nous avons observé ce combat depuis la falaise jusqu'à la tombée de la nuit. א la longue-vue, on distinguait clairement : " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim), "Name"))) + " sous pavillon noir. Puis, environ cinq heures plus tard, nous n'avons plus vu qu'un éclair dans l'obscurité, comme si la sainte-barbe avait sauté. Pendant ce temps, on avait tout à fait le temps de débarquer la marchandise.";
			link.l1 = "Vous ne savez pas oם est la cachette du capitaine " + pchar.GenQuest.CaptainComission.Name +" ? Vous connaissez chaque pierre de l'île.";
			link.l1.go = "CapComission_3";
		break;

		case "CapComission_3":
			dialog.text = "Non. Nous le cherchons aussi, mais pas pour faire plaisir au gouverneur...";
			link.l1 = "Je vois... Eh bien, portez-vous bien.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission2", "38");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sShipTypeQuest", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipTypeVictim), "Name") + "Acc")));
		break;

		case "CapComission_4":
			dialog.text = "Non. Nous le cherchons aussi, mais pas pour faire plaisir au gouverneur, héhé...";
			link.l1 = "Je vois... Eh bien, portez-vous bien.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission2", "19");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
		break;

		case "SM_ShipLetters_1":
			pchar.questTemp.different.GiveShipLetters.speakSmuggler = true;
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Qu'est-ce qui vous fait croire ça ? Je suis un honnête caboteur. Cherchez un autre acheteur.";
				link.l1 = "Merci quand même....";
				link.l1.go = "exit";
			}
			else
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					dialog.text = "Comment dire ? Votre « marchandise » pourrait peut-être servir. Prenez " + sti(pchar.questTemp.different.GiveShipLetters.price2) + " pièces d'or, et n'en parlons plus.";
					link.l1 = "Plutכt pas.";
					link.l1.go = "SM_ShipLetters_2";
					link.l2 = "Oui, vous avez deviné, je commence déjà à oublier !";
					link.l2.go = "SM_ShipLetters_3";
				}
				else
				{
					if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 1)
					{
						dialog.text = "C'est ça ! Je ne suis plus simplement curieux. Je pense que si je vous paie "+ sti(pchar.questTemp.different.GiveShipLetters.price3) +" pièces d'or, vous ne serez plus du tout curieux de ce que contiennent ces papiers.";
						link.l1 = "Plutכt pas.";
						link.l1.go = "SM_ShipLetters_2";
						link.l2 = "Oui, vous avez deviné, je commence déjà à oublier !";
						link.l2.go = "SM_ShipLetters_3";
					}
					if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 2)
					{
						dialog.text = "Voilà une occasion de clouer le bec à un insolent ! C'est très, très intéressant. Faisons ainsi : je vous paie " + sti(pchar.questTemp.different.GiveShipLetters.price4) + ", et vous faites semblant d'avoir oublié les documents sur la table ?";
						link.l1 = "Plutכt pas.";
						link.l1.go = "SM_ShipLetters_2";
						link.l2 = "Oui, vous avez deviné, je commence déjà à oublier !";
						link.l2.go = "SM_ShipLetters_3";
					}
				}
			}
		break;

		case "SM_ShipLetters_2":
			dialog.text = "Allons, allons, ne nous faisons pas d'ennemis.";
			link.l1 = "Et n'oubliez pas de regarder derrière vous !";
			link.l1.go = "exit";
		break;

		case "SM_ShipLetters_3":
			TakeItemFromCharacter(pchar, "CaptainBook");
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 1)
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price2));
				}
				else
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price3));
				}
			}
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 2)
			{
				if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer_1"))
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price2));
				}
				else
				{
					addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price4));
				}
			}

			if((sti(pchar.questTemp.different.GiveShipLetters.variant) == 0) || (sti(pchar.questTemp.different.GiveShipLetters.variant) == 2))
			{
				ChangeCharacterReputation(pchar, -1);
				OfficersReaction("bad");
			}
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "7");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Meeting":
			if(CheckAttribute(pchar, "GenQuest.CaptainComission.GetRumour") && GetQuestPastDayParam("GenQuest.CaptainComission.GetRumour") < 2)
			{
				if(!CheckAttribute(pchar, "GenQuest.CaptainComission.SpeakContra"))
				{
					pchar.GenQuest.CaptainComission.SpeakContra = true;
					dialog.text = "Il n'y aura pas d'affaires aujourd'hui. Toutes les baies grouillent de patrouilles : le gouverneur cherche une cargaison que le capitaine de la patrouille, " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + ", aurait soi-disant confisquée à un pirate avant de la cacher.";
					link.l1 = "Et oם est le capitaine lui-même ?" + pchar.GenQuest.CaptainComission.Name + " ?";
					link.l1.go = "CapComission_1";
					break;
				}
				else
				{
					dialog.text = "Il n'y aura pas d'affaires aujourd'hui.";
					link.l1 = "Je vois.";
					link.l1.go = "exit";
					break;
				}
			}

			if(pchar.questTemp.Slavetrader == "FindMayak" && Islands[GetCharacterCurrentIsland(pchar)].id == pchar.questTemp.Slavetrader.EsIsland)
			{
				dialog.text = "Il n'y aura pas d'affaires aujourd'hui.";
				link.l1 = "Je vois.";
				link.l1.go = "exit";
				break;
			}

			Dialog.Text = "Que puis-je faire pour vous, capitaine ?";
			if(FindFirstContrabandGoods(PChar) != -1)
			{
				Link.l1 = "Je veux vendre quelque chose.";
				Link.l1.go = "Meeting_1";
			}
			Link.l2 = "J'ai besoin de me rendre quelque part.";
			Link.l2.go = "Travel";
			// Церковный генератор №2 -->
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_1") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
			{
				Link.l3 = "J'ai besoin de tirer quelque chose au clair, l'ami.";
				Link.l3.go = "Contra_GenQuest_Church_2_1";
			}

			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_2") && NPChar.location == PChar.GenQuest.ChurchQuest_2.Contra_Colony + "_tavern")
			{
				Link.l3 = "Votre collègue et mon bon ami de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_2.QuestTown + "Gen") + " m'a dit que vous étiez au courant d'une affaire.";
				Link.l3.go = "Contra_GenQuest_Church_2_Contra2_1";
			}
			// <-- Церковный генератор №2

			////////////////////////////////////////////////////////
			//zagolski. начальный квест пирата
			if(CheckAttribute(pchar, "questTemp.pirateStartQuest") && pchar.questTemp.pirateStartQuest == "2" && GetArealByCityName(npchar.city) == pchar.questTemp.pirateStartQuest.Areal && npchar.city != pchar.questTemp.pirateStartQuest.City)
			{
				link.l4 = "וcoute, j'ai désespérément besoin d'une centaine ou deux d'esclaves. Je ne sais plus à qui m'adresser.";
				link.l4.go = "pirateStartQuest_Smuggler";
			}

            if (CheckAttribute(pchar, "contratrade.time"))
			{
				if (pchar.contratrade.time != GetDataDay() && ChangeContrabandRelation(pchar, 0) > 5)
				{
					Link.l17 = "(à voix basse) J'ai entendu dire qu'on pouvait vous acheter quelque chose d'intéressant.";
					Link.l17.go = "Trade";
				}
			}
			if (!CheckAttribute(pchar, "contratrade.time") && ChangeContrabandRelation(pchar, 0) > 5)
			{
				Link.l17 = "(à voix basse) J'ai entendu dire qu'on pouvait vous acheter quelque chose d'intéressant.";
				Link.l17.go = "Trade";
			}
			if (CheckAttribute(pchar, "RimalieGood") && npchar.id == "PortSpein_Smuggler" && ChangeContrabandRelation(pchar, 0) > 5)
			{
				Link.l18 = "J'aimerais parler d'un mousquetaire qui vit en ermite sur une île voisine.";
				Link.l18.go = "Rimalie";
			}

			if (ContraBlock_Any())
			{
				Link.l8 = "(à mi-voix) Deux ou trois villes m'ont fermé leur porte dans notre branche. Tu pourrais arranger ça ?";
				Link.l8.go = "ContraUnblock_List";
			}
			Link.l5 = "Rien. Bonne chance !";
			Link.l5.go = "Exit";
		break;

		////////////////////////////////////////////////////////
		//zagolski. начальный квест пирата
		case "pirateStartQuest_Smuggler":
		if (!CheckAttribute(pchar, "GenQuest.contraTravel.active") && !CheckAttribute(Pchar, "quest.Contraband.Active"))
		{
			dialog.text = "Les esclaves sont très demandés de nos jours. Pour ce genre d'affaires, on s'adresse d'habitude aux pirates de la colonie voisine.";
			link.l1 = "Il n'y a pas d'esclaves là-bas, et mon affaire brמle. Il ne me reste plus du tout de temps.";
			link.l1.go = "pirateStartQuest_Smuggler_1";
		}
		else
		{
			dialog.text = "D'abord, l'ami, termine ce que tu as commencé. Ensuite, on en reparlera.";
			link.l1 = "Compris.";
			link.l1.go = "exit";
		}
		break;
		case "pirateStartQuest_Smuggler_1":
			dialog.text = "Que le diable m'emporte si je ne sais pas qui est ton client ! Eh bien, cette canaille aura son lot avec une belle marge, s'il décide de me mener par le bout du nez.";
			link.l1 = "Je ne sais pas de qui tu parles. Mon client est sur une autre île, alors je me dépêche tant que le vent est favorable.";
			link.l1.go = "pirateStartQuest_Smuggler_2";
		break;
		case "pirateStartQuest_Smuggler_2":
			dialog.text = "Et combien d'esclaves te faut-il ?";
			link.l1 = "Il me faut 100 esclaves. Je paierai bien !";
			link.l1.go = "pirateStartQuest_Smuggler_3";
		break;
		case "pirateStartQuest_Smuggler_3":
			dialog.text = "דa te coמtera 30 000 piastres, 300 par esclave. Tu as cette somme ?";
			link.l1 = "Marché conclu.";
			link.l1.go = "pirateStartQuest_Smuggler_4";
		break;
		case "pirateStartQuest_Smuggler_4":
			pchar.questTemp.pirateStartQuest.Shore = SelectQuestShoreLocation();
			dialog.text = "D'accord. Viens avec l'argent à l'endroit appelé " + XI_ConvertString(pchar.questTemp.pirateStartQuest.Shore) + ", on en parlera là-bas...";
			link.l1 = "D'accord, je viendrai. Seulement, n'essaie pas de me mener par le bout du nez : je n'ai pas le temps de jouer.";
			link.l1.go = "exit";

			pchar.questTemp.pirateStartQuest = "3";
			pchar.questTemp.pirateStartQuest.City2Nation = npchar.nation;
			AddQuestRecord("pSQ", "3");
			AddQuestUserData("pSQ", "sCity2", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City2 + "Gen"));
			AddQuestUserData("pSQ", "sShore", XI_ConvertString(pchar.questTemp.pirateStartQuest.Shore));

			pchar.quest.pirateStartQuest_Smuggler_fc.win_condition.l1 = "Location";
			pchar.quest.pirateStartQuest_Smuggler_fc.win_condition.l1.location = pchar.questTemp.pirateStartQuest.City2 + "_ExitTown";
			pchar.quest.pirateStartQuest_Smuggler_fc.function = "pirateStartQuest_Smuggler_fc";

			AddGeometryToLocation(pchar.questTemp.pirateStartQuest.Shore, "smg");
			pchar.quest.pirateStartQuest_Smuggler_fc2.win_condition.l1 = "Location";
			pchar.quest.pirateStartQuest_Smuggler_fc2.win_condition.l1.location = pchar.questTemp.pirateStartQuest.Shore;
			pchar.quest.pirateStartQuest_Smuggler_fc2.function = "pirateStartQuest_Smuggler_fc2";
		break;
		//--------------------------------------------------

		// Церковный генератор №2 -->
		case "Contra_GenQuest_Church_2_1":
			iChurchQuest2_Summ = PChar.GenQuest.ChurchQuest_2.Summ_To_Contra;
			dialog.text = "Je ne suis pas ton ami. Et apprendre certaines choses peut te coמter cher.";
				link.l1 = "Hum. J'ai besoin de savoir une chose qui ne coמte pas plus de " + FindRussianMoneyString(iChurchQuest2_Summ) + ".";
				link.l1.go = "Contra_GenQuest_Church_2_2";
			break;

		case "Contra_GenQuest_Church_2_2":
			iChurchQuest2_Summ = PChar.GenQuest.ChurchQuest_2.Summ_To_Contra;
			if(sti(PChar.money) >= iChurchQuest2_Summ)
			{
				dialog.text = "Donne-moi ton argent. Et sache que pour cette somme, tu n'apprendras pas grand-chose.";
				link.l1 = "Je n'ai pas besoin de grand-chose. Je suis arrivé en retard à un rendez-vous, et on ne m'a pas attendu...";
				link.l1.go = "Contra_GenQuest_Church_2_3";
				AddMOneyToCharacter(PChar, -iChurchQuest2_Summ);
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_1");
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.Summ_To_Contra");
			}
			else
			{
				dialog.text = "Hé, tu n'as pas d'argent ! Reviens quand tu seras riche...";
				link.l1 = "Exactement.";
				link.l1.go = "exit";
			}
			break;

		case "Contra_GenQuest_Church_2_3":
			dialog.text = "Qu'est-ce que j'ai à voir là-dedans ?";
				link.l1 = "Ils ne sont pas en ville, et ils n'avaient pas de navire à eux. Alors je me suis dit que l'un de vos partenaires leur avait peut-être rendu service...?";
				link.l1.go = "Contra_GenQuest_Church_2_4";
			break;

		case "Contra_GenQuest_Church_2_4":
			sColony = QuestGetColony(PChar.GenQuest.ChurchQuest_2.QuestTown);
			dialog.text = "C'est donc ça... Eh bien, il y a eu une affaire. Des gens sont venus et ont dit qu'ils devaient partir de toute urgence, peu importait oם. Dans ces cas-là, nous ne demandons pas les raisons, tant qu'on paie le prix. Nous avions une course pour " + XI_ConvertString("Colony" + sColony + "Acc") + " sur l'île de " + XI_ConvertString(locations[FindLocation(sColony + "_Town")].IslandID + "Dat") + ". C'est là qu'ils sont partis. Nous pouvons vous y emmener aussi, si nous nous entendons sur le prix.";
			link.l1 = "Merci, j'ai mes propres voiles.";
			link.l1.go = "exit";
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "8");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sCity", XI_ConvertString("Colony" + sColony + "Acc"));
			AddQuestUserData(sQuestTitle, "sIsland", XI_ConvertString(locations[FindLocation(sColony + "_Town")].IslandID + "Dat"));
			PChar.GenQuest.ChurchQuest_2.AskContra_2 = true;
			PChar.GenQuest.ChurchQuest_2.Contra_Colony = sColony;
			break;

		case "Contra_GenQuest_Church_2_Contra2_1":
			dialog.text = "Je n'ai encore jamais fait affaire avec vous.";
				link.l1 = "Eh bien, ce n'est qu'une question de temps. Il n'y a pas longtemps, vous avez amené ici des amis à moi, que j'ai manqués de peu.";
				link.l1.go = "Contra_GenQuest_Church_2_Contra2_2";
			break;

		case "Contra_GenQuest_Church_2_Contra2_2":
			string sGenLocation = IslandGetLocationFromType(locations[FindLocation(PChar.GenQuest.ChurchQuest_2.Contra_Colony + "_Town")].IslandID, "Shore");
			PChar.GenQuest.ChurchQuest_2.QuestGangShore = sGenLocation;
			PChar.GenQuest.ChurchQuest_2.BanditsInShore = true;
			dialog.text = "Hum, nous les avons déposés à cet endroit : " + XI_ConvertString(sGenLocation + "Dat") + "... Vous savez, il vaudrait mieux qu'ils soient vraiment vos amis, sinon je ne leur conseillerais pas de vous approcher.";
			link.l1 = "Merci de votre sollicitude, mais je suis armé et très charmant.";
			link.l1.go = "exit";
			SetFunctionLocationCondition("Church_GenQuest2_GenerateBandits", sGenLocation, false);
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "9");
			AddQuestUserData(sQuestTitle, "sShore", XI_ConvertString(sGenLocation + "Acc"));
			locations[FindLocation(sGenLocation)].DisableEncounters = true;
			SetFunctionTimerCondition("Church_GenQuest2_TimeIsLeft", 0, 0, 1, false);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskContra_2");
			break;
		// <-- Церковный генератор №2

		case "Meeting_1":
			Dialog.Text = "Hum... Qu'est-ce que j'ai à voir là-dedans ? Vous vous êtes trompé d'endroit, capitaine. Allez au magasin : ils seront ravis d'acheter ce que vous avez apporté.";
			Link.l1 = "Je crains que ce soit vous qu'il me faut.";
			Link.l1.go = "Meeting_2";
			Link.l2 = "Merci du conseil. Bonne journée.";
			Link.l2.go = "exit";
		break;

		case "Meeting_2":
			Dialog.Text = "Pourquoi donc ?";
			Link.l1 = "Je veux vendre quelque chose qu'aucun marchand de cette île n'achètera.";
			Link.l1.go = "Meeting_3";
		break;

		case "Meeting_3":
			if (sti(npchar.SmugglingMoney) < 200000)
			{
				Dialog.Text = "Je n'ai pas encore écoulé votre précédent lot. Je n'ai pas encore d'argent pour de nouvelles marchandises, revenez dans un mois ou deux.";
				Link.l1 = "Je peux trouver un autre client, vous savez... Bon, au revoir.";
            	Link.l1.go = "exit";
				break;
			}

			if (CheckCharacterPerk(pchar, "UnlimitedContra"))
			{
				if (npchar.quest.trade_date != lastspeak_date)
    			{
                    npchar.quest.trade_date = lastspeak_date;

                    if (ChangeContrabandRelation(pchar, 0) > 5)
                    {
                        Pchar.quest.contraband.CurrentPlace = SelectSmugglingLocation();
						Pchar.quest.contraband.City = NPChar.city;
                        if (Pchar.quest.contraband.CurrentPlace != "None" && !CheckAttribute(pchar, "Whisper.ContraSmuggler")&& !CheckAttribute(pchar, "Whisper.Contraband"))//boal fix
                        {
                            if (ChangeContrabandRelation(pchar, 0) >= 70)
                            {
                                Dialog.Text = "Je sais qu'on peut traiter avec vous. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
                            }
                            else
                            {
            				    Dialog.Text = "Hum... Il y aura peut-être un acheteur. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
            				}
            				Link.l1 = "Bien. א plus tard.";
            				Link.l1.go = "Smuggling_exit";
        				}
        				else
        				{   //boal fix
                            if(CheckAttribute(pchar, "Whisper.ContraSmuggler") || CheckAttribute(pchar, "Whisper.Contraband"))
							{
								Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
							}
							else
							{
								Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
							}
            				Link.l1 = "Bien.";
            				Link.l1.go = "Exit";
        				}
    				}
    				else
    				{
                        Dialog.Text = "Et après tout ça, vous croyez que quelqu'un voudra travailler avec vous ? Estimez-vous heureux que nous n'ayons pas encore envoyé de tueurs à vos trousses. Dehors !";
        				Link.l1 = "Eh... alors ce n'est pas mon destin de devenir contrebandier.";
        				Link.l1.go = "Exit";
    				}
				}
				else
				{
                    if(CheckAttribute(pchar, "Whisper.ContraSmuggler") || CheckAttribute(pchar, "Whisper.Contraband"))
					{
						Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
					}
					else
					{
						Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
					}
    				Link.l1 = "Bien.";
    				Link.l1.go = "Exit";
				}
				break;
			}
			if (GetCompanionQuantity(pchar) > 1 && GetBaseHeroNation() != PIRATE)
			{
				dialog.text = NPCStringReactionRepeat("Débarrassez-vous d'abord de votre escadre. Elle se remarque trop. Nous ne pouvons pas prendre ce risque. Venez sur un seul navire, et qu'il ne soit pas plus gros qu'un brick ou un galion.",
					"Je ne me suis pas fait comprendre ? Je le répète : pas d'escadre !",
					"Vous êtes bouché ? U-n, je vous dis, u-n navire, pas deux, pas trois, mais un seul ! Vous comprenez ?",
					"Oh, comment la terre peut-elle porter de tels imbéciles...", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Bon, compris. Un seul, va pour un seul.",
					"Tout est clair, je voulais juste m'en assurer.",
					"Non, je ne suis pas bouché, juste très gourmand. Je pensais que quelque chose avait peut-être changé, et qu'on pouvait venir directement en escadre...",
					"Eh bien, vous voyez, elle les porte, tant bien que mal...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
				break;
			}

		//редкостная хрень, но по-другому не работает-класс корабля ГГ считается отдельно от компаньонов, и всё тут
			int iClass, ipClass;
			ipClass = 4-sti(RealShips[sti(pchar.ship.type)].Class);
			iClass = 3;//т.к. не пройдёт по числу кораблей в любом случае
		if (GetBaseHeroNation() == PIRATE)
		{
			ipClass = sti(ipClass)-1;
			int iChIdx, i;
			// поиск старшего класса компаньона
			for (i=0; i<COMPANION_MAX; i++)
			{
				iChIdx = GetCompanionIndex(GetMainCharacter(), i);
				if (iChIdx>=0)
				{
					sld = GetCharacter(iChIdx);
					iClass = GetCharacterShipClass(sld);
				}
			}
		}
			if (sti(ipClass) > 0 || 3 - sti(iClass) > 0)
			{
				dialog.text = NPCStringReactionRepeat("Vous auriez dמ venir sur un vaisseau du roi, tant que vous y êtes. On voit votre navire à une lieue du fort. Nous ne risquerons pas nos têtes. Venez sur un navire plus petit, et un seul.",
					"Je ne me fais pas comprendre ? Trouvez-vous un navire plus petit, et revenez.",
					"Vous êtes sourd ou vous faites semblant ? Je vous dis de vous trouver une goélette, ou un brick à la rigueur, sinon l'affaire ne se fera pas.",
					"Oh, comment la terre peut-elle porter de tels imbéciles"+ GetSexPhrase("", "") +"...", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Bon, je vous comprends. Je reviendrai plus tard, dès que j'aurai changé de bateau.",
					"Oui, tout est clair, je voulais juste m'en assurer.",
					"Non, pas bouché, juste gourmand. Je pensais que quelque chose avait peut-être changé. J'aurais apporté deux ou trois cargaisons de plus...",
					"Eh bien, vous voyez, elle les porte, tant bien que mal...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
				break;
			}
			bOk  = CheckAttribute(pchar, "GenQuest.contraTravel.active") && (sti(pchar.GenQuest.contraTravel.active) == true);
			bOk2 = CheckAttribute(Pchar, "quest.Contraband.Active") && (sti(Pchar.quest.Contraband.Active) == true);
			bool bOk3 = CheckAttribute(Pchar, "questTemp.pirateStartQuest") && (Pchar.questTemp.pirateStartQuest == "3");
			if (bOk)
			{
			    if (GetQuestPastDayParam("contraTravel") > sti(PChar.GenQuest.contraTravel.days))
				{  // просрочка
					DeleteAttribute(PChar, "GenQuest.contraTravel");
					CloseQuestHeader("Gen_ContrabandTravel");
					bOk = false;
				}
			}

//navy --> PGG
			if (CheckFreeServiceForNPC(NPChar, "Smugglers") != -1)
			{
				if (makeint(environment.time) < 19.0)
				{
					Dialog.Text = "Désolé, nous avons déjà à faire. Revenez ce soir, après 19 heures, nous serons peut-être libres.";
					Log_Info(FloatToString(ChangeContrabandRelation(pchar, 0),1));
					if (ChangeContrabandRelation(pchar, 0) > 5 && sti(pchar.money) >= 1000 && !bOk && !bOk2 && !bOk3 && npchar.quest.trade_date != lastspeak_date)
					{
						Link.l1 = "Et pourquoi pas maintenant ? Contre une modeste récompense pour vous, en tant qu'agent ? 1000 piastres, par exemple.";
						Link.l1.go = "AntiPGGContra";
					}
					Link.l2 = "Dommage...";
					Link.l2.go = "Exit";
					break;
				}
				else
				{
					if (bOk || bOk2 || bOk3)
					{
						Dialog.Text = "Il faudrait peut-être terminer une affaire avant d'en commencer une autre ?";
						Link.l1 = "Je suppose que vous avez raison.";
						Link.l1.go = "Exit";
					}
					else
					{
						if (npchar.quest.trade_date != lastspeak_date)
						{
							npchar.quest.trade_date = lastspeak_date;

							if (ChangeContrabandRelation(pchar, 0) > 5)
							{
								Pchar.quest.contraband.CurrentPlace = SelectSmugglingLocation();
								Pchar.quest.contraband.City = NPChar.city;
								if (Pchar.quest.contraband.CurrentPlace != "None"  && !CheckAttribute(pchar, "Whisper.ContraSmuggler")&& !CheckAttribute(pchar, "Whisper.Contraband"))//boal fix
								{
									if (ChangeContrabandRelation(pchar, 0) >= 70)
									{
										Dialog.Text = "Je sais qu'on peut traiter avec vous. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
									}
									else
									{
										Dialog.Text = "Hum... Il y aura peut-être un acheteur. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
									}
									Link.l1 = "Bien. א plus tard.";
									Link.l1.go = "Smuggling_exit";
								}
								else
								{   //boal fix
									if(CheckAttribute(pchar, "Whisper.ContraSmuggler") || CheckAttribute(pchar, "Whisper.Contraband"))
									{
										Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
									}
									else
									{
										Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
									}
									Link.l1 = "Bien.";
									Link.l1.go = "Exit";
								}
							}
							else
							{
								Dialog.Text = "Et après tout ça, vous croyez que quelqu'un voudra travailler avec vous ? Estimez-vous heureux que nous n'ayons pas encore envoyé de tueurs à vos trousses. Dehors !";
								Link.l1 = "Eh... alors ce n'est pas mon destin de devenir contrebandier.";
								Link.l1.go = "Exit";
							}
						}
						else
						{
							if(CheckAttribute(pchar, "Whisper.ContraSmuggler")|| CheckAttribute(pchar, "Whisper.Contraband"))
							{
								Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
							}
							else
							{
								Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
							}
							Link.l1 = "Bien.";
							Link.l1.go = "Exit";
						}
					}
				}
			}
			else if (bOk || bOk2 || bOk3)
			{
				Dialog.Text = "Il faudrait peut-être terminer une affaire avant d'en commencer une autre ?";
				Link.l1 = "Je suppose que vous avez raison.";
				Link.l1.go = "Exit";
			}
			else
			{
                if (npchar.quest.trade_date != lastspeak_date)
    			{
                    npchar.quest.trade_date = lastspeak_date;

                    if (ChangeContrabandRelation(pchar, 0) > 5)
                    {
                        Pchar.quest.contraband.CurrentPlace = SelectSmugglingLocation();
						Pchar.quest.contraband.City = NPChar.city;
                        if (Pchar.quest.contraband.CurrentPlace != "None"  && !CheckAttribute(pchar, "Whisper.ContraSmuggler")&& !CheckAttribute(pchar, "Whisper.Contraband"))//boal fix
                        {
                            if (ChangeContrabandRelation(pchar, 0) >= 70)
                            {
                                Dialog.Text = "Je sais qu'on peut traiter avec vous. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
                            }
                            else
                            {
            				    Dialog.Text = "Hum... Il y aura peut-être un acheteur. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
            				}
            				Link.l1 = "Bien. א plus tard.";
            				Link.l1.go = "Smuggling_exit";
        				}
        				else
        				{   //boal fix
							if(CheckAttribute(pchar, "Whisper.ContraSmuggler") || CheckAttribute(pchar, "Whisper.Contraband"))
							{
								Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
							}
							else
							{
								Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
							}
            				Link.l1 = "Bien.";
            				Link.l1.go = "Exit";
        				}
    				}
    				else
    				{
                        Dialog.Text = "Et après tout ça, vous croyez que quelqu'un voudra travailler avec vous ? Estimez-vous heureux que nous n'ayons pas encore envoyé de tueurs à vos trousses. Dehors !";
        				Link.l1 = "Eh... alors ce n'est pas mon destin de devenir contrebandier.";
        				Link.l1.go = "Exit";
    				}
				}
				else
				{
                    if(CheckAttribute(pchar, "Whisper.ContraSmuggler")|| CheckAttribute(pchar, "Whisper.Contraband"))
					{
						Dialog.Text = "Il semble que vous ayez déjà une affaire prévue, avec quelqu'un à Tortuga. Revenez quand vous l'aurez réglée.";
					}
					else
					{
						Dialog.Text = "Il n'y aura plus d'affaires aujourd'hui. Revenez demain.";
					}
    				Link.l1 = "Bien.";
    				Link.l1.go = "Exit";
				}
			}
		break;

		case "AntiPGGContra":
			AddMoneyToCharacter(pchar,-1000);
			bool canDeal = GetCompanionQuantity(pchar) == 1 && sti(RealShips[sti(pchar.ship.type)].Class) > 2
			if (CheckCharacterPerk(pchar, "UnlimitedContra") || canDeal)
			{
				npchar.quest.trade_date = lastspeak_date;
				Pchar.quest.contraband.CurrentPlace = SelectSmugglingLocation();
				Pchar.quest.contraband.City = NPChar.city;
				if (Pchar.quest.contraband.CurrentPlace != "None")//boal fix
				{
					if (ChangeContrabandRelation(pchar, 0) >= 70)
					{
						Dialog.Text = "Je sais qu'on peut traiter avec vous. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
					}
					else
					{
						Dialog.Text = "Hum... Il y aura peut-être un acheteur. Nous vous attendrons à l'endroit appelé " + GetConvertStr(Pchar.quest.contraband.CurrentPlace, "LocLables.txt") + ".";
					}
					Link.l1 = "Bien. א plus tard.";
					Link.l1.go = "Smuggling_exit";
				}
			}
			else
			{
				Dialog.Text = "Attendez, ça ne va pas se passer comme ça ! Vous auriez dמ venir sur un vaisseau du roi, tant que vous y êtes. Venez sur un petit navire, et un seul, et alors nous parlerons. Et je prends votre argent, en paiement du conseil.";
				Link.l1 = RandSwear();
				Link.l1.go = "exit";
			}
		break;

		case "Trade"://торговля с контрами - Gregg
			int idLngFile = LanguageOpenFile("ItemsDescribe.txt");
			Dialog.Text = "(à voix basse) Hum... Oui, c'est vrai. ";
			switch (makeint(drand(7)))
			{
				case 0:
					npchar.itemtype = "Lockpick";//отмычки за драги
					npchar.pricev = "jewelry"+(drand2(3)+1);
					string type = npchar.pricev;
					Dialog.Text = dialog.text+ "J'ai aujourd'hui quelques passe-partout disponibles. דa vous intéresse ? Pour 3 pièces, je ne demande que 5 "+LanguageConvertString(idLngFile, "itmname_"+npchar.pricev)+"s.";
					LanguageCloseFile(idLngFile);
					if (GetCharacterItemWithCabin(pchar, npchar.pricev, true) >= 5)
					{
						Link.l1 = "Bien sמr que ça m'intéresse.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "Non, c'était juste par curiosité.";
					Link.l2.go = "Exit";
				break;
				case 1:
					npchar.itemtype = "Totem_"+(drand2(13)+1);//тотем, не шипе-топеку
					npchar.pricevalue = 30000+drand1(20000);
					Dialog.Text = dialog.text+ "J'ai aujourd'hui en stock : "+LanguageConvertString(idLngFile, "itmname_"+npchar.itemtype)+". דa vous intéresse ? J'en demande "+npchar.pricevalue+" piastres.";
					LanguageCloseFile(idLngFile);
					if(sti(pchar.money) >= sti(npchar.pricevalue))
					{
						Link.l1 = "Bien sמr que ça m'intéresse.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "Non, c'était juste par curiosité.";
					Link.l2.go = "Exit";
				break;
				/*case 2:
					npchar.itemtype = "sculMa"+(drand2(2)+1);//хрустальный череп
					npchar.pricevalue = 75000+drand1(25000);
					Dialog.Text = dialog.text+ "I have a real exclusive available today, "+LanguageConvertString(idLngFile, "itmname_"+npchar.itemtype)+". Are you interested? I'm asking for him."+npchar.pricevalue+"piastres.";
					LanguageCloseFile(idLngFile);
					if(sti(pchar.money) >= sti(npchar.pricevalue))
					{
						Link.l1 = "Of course I'm interested.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "No, it just got interesting.";
					Link.l2.go = "Exit";
				break;*/
				case 2:
					npchar.itemtype = "indian"+(drand2(21)+1);//индиан, не крысобог
					if (npchar.itemtype == "indian11") npchar.itemtype = "indian"+(22-drand1(2));
					aref ind;
					Items_FindItem(npchar.itemtype, &ind);
					npchar.pricevalue = sti(GetItemPrice(npchar.itemtype))*10;
					if (CheckAttribute(ind, "groupID") && sti(GetItemPrice(npchar.itemtype)) < 100) npchar.pricevalue = sti(npchar.pricevalue)*25;
					Dialog.Text = dialog.text+ "Aujourd'hui, j'ai en stock une babiole indigène, "+LanguageConvertString(idLngFile, "itmname_"+npchar.itemtype)+". דa vous intéresse ? J'en demande "+npchar.pricevalue+" piastres.";
					LanguageCloseFile(idLngFile);
					if(sti(pchar.money) >= sti(npchar.pricevalue))
					{
						Link.l1 = "Bien sמr que ça m'intéresse.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "Non, c'était juste par curiosité.";
					Link.l2.go = "Exit";
				break;
				case 3:
					npchar.itemtype = "jewelry"+(drand2(3)+1);//драги за бабки
					npchar.pricev = "j";
					npchar.pricevalue = 20000+drand1(5000);
					Dialog.Text = dialog.text+ "J'ai aujourd'hui en stock des pierres précieuses, des "+LanguageConvertString(idLngFile, "itmname_"+npchar.itemtype)+"s. דa vous intéresse ? Pour un lot de 25 pièces, je demande "+npchar.pricevalue+" piastres.";
					LanguageCloseFile(idLngFile);
					if(sti(pchar.money) >= sti(npchar.pricevalue))
					{
						Link.l1 = "Bien sמr que ça m'intéresse.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "Non, c'était juste par curiosité.";
					Link.l2.go = "Exit";
				break;
				case 4:
					npchar.itemtype = "Lockpick";//отмычки за драги
					npchar.pricev = "jewelry"+(drand2(3)+1);
					string type1 = npchar.pricev;
					Dialog.Text = dialog.text+ "J'ai aujourd'hui quelques passe-partout disponibles. דa vous intéresse ? Pour 3 pièces, je ne demande que 5 "+LanguageConvertString(idLngFile, "itmname_"+npchar.pricev)+"s.";
					LanguageCloseFile(idLngFile);
					if (GetCharacterItemWithCabin(pchar, npchar.pricev, true) >= 5)
					{
						Link.l1 = "Bien sמr que ça m'intéresse.";
						Link.l1.go = "Trade_2";
					}
					Link.l2 = "Non, c'était juste par curiosité.";
					Link.l2.go = "Exit";
				break;
				else
					Dialog.Text = "Hélas, je n'ai rien d'intéressant aujourd'hui.";
					Link.l2 = "Oh, quel dommage. Eh bien, à plus tard.";
					Link.l2.go = "Exit";
				break;
			}
			/*Dialog.Text = "(Softly) Hmm... Yes, it is. Do you want to buy something now?";
			Link.l1 = "Yes, show me your goods.";
			Link.l1.go = "Trade_exit";
			Link.l2 = "No, it just got interesting.";
			Link.l2.go = "Exit";*/
		break;

		case "Trade_2":
		{
			int idLngFile1 = LanguageOpenFile("ItemsDescribe.txt");
			if (CheckAttribute(npchar, "pricev"))
			{
				if (npchar.itemtype == "Lockpick")
				{
					Log_Info("Vous avez donné 5 "+LanguageConvertString(idLngFile1, "itmname_"+npchar.pricev)+"s.");
					Log_Info("Vous avez reçu 3 passe-partout.")
					TakeNItemsWithCabin(pchar, npchar.pricev, -5, false);
					TakeNItems(pchar, npchar.itemtype, 3);
				}
			}
			if (CheckAttribute(npchar, "pricevalue"))
			{
				if (npchar.itemtype != "Lockpick")
				{
					AddMoneyToCharacter(pchar, -sti(npchar.pricevalue));
					if (CheckAttribute(npchar, "pricev"))
					{
						TakeNItems(pchar, npchar.itemtype, 25);
						Log_Info("Vous avez reçu 25 "+LanguageConvertString(idLngFile1, "itmname_"+npchar.itemtype)+"s.");
					}
					else
					{
						GiveItem2Character(pchar, npchar.itemtype);
						Log_Info("Vous avez reçu : "+LanguageConvertString(idLngFile1, "itmname_"+npchar.itemtype)+".");
					}
				}
			}
			LanguageCloseFile(idLngFile1);
			DeleteAttribute(npchar, "pricevalue");
			DeleteAttribute(npchar, "pricev");
			DeleteAttribute(npchar, "itemtype");
			pchar.contratrade.time = GetDataDay();
			ChangeContrabandRelation(pchar, 5)
			Dialog.Text = "Voilà ! C'est un plaisir de traiter avec vous. Je suppose que nous nous reverrons.";
			Link.l2 = "Merci. א plus tard !";
			Link.l2.go = "Exit";
		}
		break;

////////////////////////////////////////////////////////////////////////////////
//	Корсарское метро
////////////////////////////////////////////////////////////////////////////////
		case "Travel":
			//если нет корабля у ГГ и нет компаньонов все ок
			if (sti(pchar.ship.type) == SHIP_NOTUSED && GetCompanionQuantity(pchar) == 1 && GetPassengersQuantity(pchar) == 0)
			{
				//случай если уже была инфа
				if (CheckAttribute(pchar, "GenQuest.contraTravel.active") && sti(pchar.GenQuest.contraTravel.active) == true)
				{
					//платил уже
					if (CheckAttribute(pchar, "GenQuest.contraTravel.payed") && sti(pchar.GenQuest.contraTravel.payed) == true)
					{
						Dialog.Text = "Je crois que nous sommes déjà d'accord ?";
						Link.l2 = "Oui, c'est ça !";
					}
					//не платил, значит можно запалатить пока не вышел срок.
					else
					{
						if(GetQuestPastDayParam("contraTravel") == sti(PChar.GenQuest.contraTravel.days))
						{
							Dialog.Text = "Vous avez apporté"+ GetSexPhrase("", "") +" l'argent ?";
							Link.l1 = "Oui.";
							Link.l1.go = "Travel_pay";
							Link.l3 = "J'ai changé d'avis....";
							Link.l3.go = "Travel_abort";
							Link.l2 = "Pas encore.";
						}
						else
						{
                            if (GetQuestPastDayParam("contraTravel") < sti(PChar.GenQuest.contraTravel.days))
							{
								Dialog.Text = "Je vous ai déjà tout dit.";
								Link.l2 = "Exactement.";
								Link.l1 = "J'ai changé d'avis....";
								Link.l1.go = "Travel_abort";
							}
							else // просрочка
							{
							    Dialog.Text = "Je ne peux pas vous aider aujourd'hui. Revenez dans deux ou trois jours, ça se fera peut-être.";
								Link.l2 = "Dommage.";
								DeleteAttribute(PChar, "GenQuest.contraTravel");
								CloseQuestHeader("Gen_ContrabandTravel");
							}
						}
					}
				}
				//если не было договора, обговариваем условия
				else
				{
					nRel = ChangeContrabandRelation(pchar, 0);
					//если нормальные отношения и количество подстав меньше 20, работаем....
					if (nRel > 0 && Statistic_AddValue(PChar, "contr_TravelKill", 0) < 20)
					{
						//бухта...
						pchar.GenQuest.contraTravel.CurrentPlace = SelectSmugglingLocation();
						aref arTmp; makearef(arTmp, pchar.GenQuest.contraTravel);
						SetSmugglersTravelDestination(arTmp);
						//за сколько доставят
						pchar.GenQuest.contraTravel.price = (sti(PChar.rank)*250 + (100 - nRel)*10 + rand(30)*20) + sti(arTmp.destination.days)*100;

						//если метро активно, и нет пассажиров у ГГ, и ещё сегодня не виделись, есть доступная бухта, и ранд ...
						bOk = !bPauseContrabandMetro && CheckNPCQuestDate(npchar, "Travel_Talk") &&
							Pchar.GenQuest.contraTravel.CurrentPlace != "None" && rand(50) < nRel;
                        bOk2 = CheckAttribute(Pchar, "quest.Contraband.Active") && (sti(Pchar.quest.Contraband.Active) == true);
						if (bOk && !bOk2)
						{
							nDay = 1 + rand(3);
							SetNPCQuestDate(npchar, "Travel_Talk");
							SaveCurrentQuestDateParam("contraTravel");

							Dialog.Text = "Eh bien, nous pouvons vous emmener jusqu'à " + GetConvertStr(locations[FindLocation(pchar.GenQuest.contraTravel.destination.loc)].id, "LocLables.txt") + " près de " +
								XI_ConvertString("Colony" + pchar.GenQuest.contraTravel.destination + "Gen") + " – pour " + pchar.GenQuest.contraTravel.price + " pièces d'or. Vous apporterez l'argent d'ici " +
								FindRussianDaysString(nDay) + ". Le navire vous attendra à l'endroit appelé " +
								GetConvertStr(locations[FindLocation(Pchar.GenQuest.contraTravel.CurrentPlace)].id, "LocLables.txt") + " pendant exactement un jour.";

							pchar.GenQuest.contraTravel.days = nDay;
							Link.l1 = "D'accord, ça me va.";
							Link.l1.go = "Travel_agree";
							Link.l2 = "Non, merci.";
						}
						else
						{
							Dialog.Text = "Je ne peux pas vous aider aujourd'hui. Revenez dans deux ou trois jours, il se passera peut-être quelque chose.";
							Link.l2 = "Dommage.";
						}
					}
					//нет, посылаем в сад
					else
					{
                        Dialog.Text = "Et après tout ça, vous croyez que quelqu'un voudra travailler avec vous ? Estimez-vous heureux que nous n'ayons pas encore envoyé de tueurs à vos trousses. Dehors !";
        				Link.l2 = "Eh... ce n'est donc pas le destin.";
					}

				}
			}
			//корабль есть, посылаем в сад...
			else
			{
				if(GetPassengersQuantity(pchar) != 0)
				{
					Dialog.Text = "Non, nous ne vous emmenons pas. Un seul passager.";
					Link.l2 = RandSwear() + "Et ce n'est pas la peine !";
				}
				else
				{
					Dialog.Text = "Et pourquoi avez-vous besoin de votre propre navire ? Non, nous ne faisons pas ça.";
					Link.l2 = "Ce n'est manifestement pas le destin...";
				}
			}
			Link.l2.go = "Exit";
			break;

		//отмена
		case "Travel_abort":
			ChangeContrabandRelation(pchar, -2);
			DeleteAttribute(PChar, "GenQuest.contraTravel");
			CloseQuestHeader("Gen_ContrabandTravel");
			Dialog.Text = "Eh bien, comme vous voudrez...";
			Link.l1 = "";
			Link.l1.go = "Exit";
			break;

		//ГГ согласен ехать
		case "Travel_agree":
			ReOpenQuestHeader("Gen_ContrabandTravel");
			AddQuestRecord("Gen_ContrabandTravel", "1");
			AddQuestUserData("Gen_ContrabandTravel", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_ContrabandTravel", "sLoc", GetConvertStr(pchar.GenQuest.contraTravel.CurrentPlace, "LocLables.txt"));
			AddQuestUserData("Gen_ContrabandTravel", "sLocTo", GetConvertStr(pchar.GenQuest.contraTravel.destination.loc, "LocLables.txt"));
			AddQuestUserData("Gen_ContrabandTravel", "sPlaceTo", XI_ConvertString("Colony" + pchar.GenQuest.contraTravel.destination + "Gen"));
			AddQuestUserData("Gen_ContrabandTravel", "sDays", FindRussianDaysString(sti(pchar.GenQuest.contraTravel.days)));
			AddQuestUserData("Gen_ContrabandTravel", "sPrice", pchar.GenQuest.contraTravel.price);

			//активируем квест
			pchar.GenQuest.contraTravel.active = true;
			pchar.GenQuest.contraTravel.GuardNation = npchar.nation;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			break;

		//ГГ согласен платить
		case "Travel_pay":
			//денег хватает?
			Sum = sti(pchar.GenQuest.contraTravel.price);
			if (sti(pchar.money) >= Sum)
			{
				AddMoneyToCharacter(pchar, -1*Sum);
				//ставим флаг оплаты
				pchar.GenQuest.contraTravel.payed = true;
				Dialog.Text = "C'est un plaisir de traiter avec vous. Le navire vous attend, ne soyez pas en retard.";
				Link.l1 = "Je vais essayer.";
				AddQuestRecord("Gen_ContrabandTravel", "2");
				AddQuestUserData("Gen_ContrabandTravel", "sSex", GetSexPhrase("", "e"));

				//ставим контру.
				PlaceSmugglersOnShore(PChar.GenQuest.contraTravel.CurrentPlace);
				//корабль на волнах в бухте....
				Sum = sti(pchar.GenQuest.contraTravel.destination.days);
				sld = GetCharacter(NPC_GenerateCharacter("Abracham_Gray", "pirate_6", "man", "man", 5, PIRATE, Sum + 2, true));
				//воскресим...
				sld.nation = PIRATE;
				SetRandomNameToCharacter(sld);
				SetMerchantShip(sld, rand(GOOD_SILVER));
				SetFantomParamHunter(sld);
				SetCaptanModelByEncType(sld, "pirate");
				SetCharacterShipLocation(sld, PChar.GenQuest.contraTravel.CurrentPlace);

				SetTimerCondition("RemoveTravelSmugglers", 0, 0, 1, false);
			}
			//нет, посылаем в сад...
			else
			{
				Dialog.Text = "On dirait que vous avez des problèmes d'argent."
				Link.l1 = "Dommage, je reviendrai plus tard.";
			}
			Link.l1.go = "Exit";
			break;

		case "Give_vector":
			dialog.text = "Mon vieil ami, Snakeman Young, un ancien pirate, tient une taverne au François. Il cherche un capitaine pirate peu connu des Frères de la Cכte. Je lui ai promis de l'aider à trouver un tel capitaine. Je vous propose donc d'aller en Martinique pour parler à mon ami. Pour autant que je le connaisse, vous ne serez certainement pas perdant.";
			link.l1 = "Et quel genre d'affaire veut-il proposer ? Vous ne savez pas ?";
			link.l1.go = "Give_vector_1";
		break;

		case "Give_vector_1":
			dialog.text = "Non. Il est devenu très secret ces derniers temps. Allez le voir : il vous expliquera tout lui-même.";
			link.l1 = "Eh bien, j'irai le voir sans faute.";
			link.l1.go = "Give_vector_2";
			link.l2 = "Hum... Vous savez, j'ai trop de problèmes à régler pour m'occuper aussi de ceux des autres. Aller au François sans même savoir ce que votre ami me veut exactement ? Désolé, mais ce n'est pas pour moi.";
			link.l2.go = "exit_quest";
		break;

		case "Give_vector_2":
			dialog.text = "Seulement, ne tardez pas trop à lui rendre visite, capitaine.";
			link.l1 = "Oui, bien sמr. Votre offre m'intrigue. Tous mes vœux et bonne chance à vous !";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "vector_barmen";
            AddQuestRecord("Headhunt", "1_1");
			AddQuestUserData("Headhunt", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
		break;

		case "exit_quest":
			dialog.text = "Alors oublions cette conversation. Au revoir.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "end_quest";
		break;

////////////////////////////////////////////////////////////////////////////////
//	END OF Корсарское метро
////////////////////////////////////////////////////////////////////////////////
	}
}
