void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "first time":
			dialog.text = "Je t'écoute, l'ami.";
			link.l1 = "Je n'ai pas pu faire ce que tu m'as demandé.";
			link.l1.go = "1";
		break;

		case "1":
			dialog.text = "Je n'aurais pas dמ m'adresser à toi. Tu n'es même pas capable de faire les tâches les plus simples. Maintenant, dehors ! Tu ne me reverras plus.";
			link.l1 = "Héhé, la vie nous le dira ! Et maintenant, adieu. J'espère que la vie t'aura appris quelque chose à toi aussi, l'ami !";
			link.l1.go = "exit";

			NextDiag.TempNode = "second time";
			AddDialogExitQuestFunction("LooserGenerator_TimeFailed");
		break;

		case "second time":
			dialog.text = LinkRandPhrase("Je me suis bien fait comprendre ? Dehors !", "Je ne veux pas te parler.", "Va-t'en, que je ne te voie plus.");
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "second time";
		break;

		case "quest":
			dialog.text = "Je t'écoute, l'ami.";
			link.l1 = "J'ai pris toutes les bourses, comme tu l'avais demandé. Alors, et la récompense ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "J'ai une chose inhabituelle pour toi. Grâce à elle, tu pourras gagner plus souvent aux jeux d'argent.";
			link.l1 = "Hein, et comment as-tu perdu tout ton argent avec une chose pareille ?";
			link.l1.go = "2.1";
			
			GiveItem2Character(PChar, "talisman20");
			Log_info("Vous avez reçu la carte à jouer Joker.");
			PlaySound("Interface\important_item.wav"); 
		break;
		
		case "2.1":
			dialog.text = "Elle ne fait qu'augmenter les chances de gagner, mais elle ne garantit pas la victoire. De toute façon, elle te sera plus utile qu'à moi.";
			link.l1 = "Merci pour ce cadeau, mais je dois maintenant prendre congé, à plus tard.";
			link.l1.go = "exit";

			AddDialogExitQuestFunction("LooserGenerator_Complette");
			NextDiag.TempNode = "3";
		break;

		case "3":
			dialog.text = LinkRandPhrase("Oh, c'est toi...", "Je pars bientכt, à plus tard.", "Nos chemins se croiseront peut-être à nouveau un jour...");
			link.l1 = "...";
			link.l1.go = "exit";

			NextDiag.TempNode = "3";
		break;

		case "Jdet_1":
			dialog.text = "Je t'écoute, l'ami.";
			link.l1 = "Je récupérerai bientכt ton argent, ne t'inquiète pas.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Jdet_1";
		break;

		case "exit":
			if (CheckAttribute(NextDiag, "TempNode")) NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
