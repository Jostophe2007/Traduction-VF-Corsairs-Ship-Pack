// "Gang and patrol skirmish" event dialog: thanks for help, rewards and battle stories
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			if (CheckAttribute(NPChar, "bGangLeader")) { DeleteAttribute(NPChar, "bGangLeader"); UnmarkCharacter(NPChar); } // remove the mini-boss mark after the talk
			LAi_SetCitizenTypeNoGroup(NPChar); // walks off after the talk
			DialogExit();
		break;

		// --- Patrol thanks (player helped the soldiers, officer survived) ---
		case "ThankPatrol":
			GangWar_RewardPatrol();
			switch (rand(4))
			{
				case 0: dialog.text = "Capitaine ! Sans votre aide, ces bandits nous auraient tous massacrés jusqu'au dernier. La Couronne n'oubliera pas ce service. Veuillez accepter notre sincère gratitude."; break;
				case 1: dialog.text = "Vous êtes arrivé juste à temps, capitaine. Un instant de plus, et mon escouade n'aurait plus été qu'un tas de cadavres. Je vous remercie au nom de la Couronne."; break;
				case 2: dialog.text = "Vaillamment combattu, capitaine ! Tout le monde ne risquerait pas de se battre au coude à coude avec une patrouille contre une bande d'égorgeurs. Cela ne restera pas sans récompense."; break;
				case 3: dialog.text = "Sans votre lame, nous étions perdus. Je ne manquerai pas de rapporter votre bravoure au gouverneur. Acceptez ma gratitude, capitaine."; break;
				case 4: dialog.text = "Dieu m'en est témoin, vous nous avez sauvé la vie. Les gens comme vous sont le pilier de la Couronne sur ces terres sauvages. Je ne sais guère comment vous remercier."; break;
			}
			link.l1 = RandPhraseSimple("Content d'avoir pu aider, officier.", "C'est le devoir de chacun d'aider la Couronne.");
			link.l1.go = "exit";
		break;

		// --- Bandits thanks (player helped the gang, leader survived) ---
		case "ThankBandits":
			GangWar_RewardBandits();
			if (CheckAttribute(pchar, "GangWar.bandWithhold")) // penalty - no reward
			{
				if (pchar.GangWar.bandWithhold == "betray") // last time slaughtered the gang after thanks
				{
					switch (rand(2))
					{
						case 0: dialog.text = "Attendez... Je vous connais. La dernière fois, vous avez accepté nos remerciements, puis vous avez abattu les survivants de sang-froid. Les nouvelles vont vite. J'accepte l'aide, mais n'espérez pas de part : les gars ne vous font pas confiance."; break;
						case 1: dialog.text = "Ah, c'est vous... Nous sommes au courant. Vous avez pris votre part la dernière fois, puis vous avez massacré ceux qui restaient. Estimez-vous heureux que je vous adresse la parole. Pas un sou pour vous, traître."; break;
						case 2: dialog.text = "On vous connaît déjà par ici, l'ami. Celui qui trahit les frères après une poignée de main n'a plus la confiance de personne. Merci pour le coup de main, mais je garde ma bourse."; break;
					}
				}
				else // last event helped the patrol/soldiers
				{
					switch (rand(2))
					{
						case 0: dialog.text = "Ah, c'est vous... On nous a dit que vous maniiez l'acier aux cכtés des soldats la dernière fois. Vous nous avez aidés aujourd'hui, c'est vrai, mais ici, on ne vous fait pas confiance. Merci pour le coup de main, mais n'espérez pas de part."; break;
						case 1: dialog.text = "J'accepte l'aide, mais je garde ma bourse. Celui qui léchait les bottes de la Couronne l'autre jour n'a pas notre confiance. Sans rancune, l'ami."; break;
						case 2: dialog.text = "On vous a vu avec la patrouille la dernière fois, l'ami. Aujourd'hui, vous êtes avec nous, et merci pour ça, mais nous ne partagerons pas notre butin avec quelqu'un qui était contre nous hier."; break;
					}
				}
				link.l1 = RandPhraseSimple("Comme vous voudrez.", "א vous de voir. Filez.");
			}
			else
			{
				switch (rand(4))
				{
					case 0: dialog.text = "Hé, vous maniez l'acier avec élégance ! Sans vous, ils nous auraient enterrés ici. Nous avons secoué quelques voyageurs : prenez votre part pour le coup de main. Filez, et que les soldats ne vous repèrent pas."; break;
					case 1: dialog.text = "Vous êtes une bête au combat, l'ami ! Ces soldats de plomb croyaient nous égorger comme des poulets. Tenez, prenez une part du pot commun : vous l'avez méritée."; break;
					case 2: dialog.text = "Vous êtes des nכtres, jusqu'au bout des ongles ! Vous ne nous avez pas laissés tomber. Prenez cet argent : nous partageons loyalement avec ceux qui nous soutiennent."; break;
					case 3: dialog.text = "Une belle bagarre, et vous n'avez pas flanché ! Voici pour votre peine : tout ça a été honnêtement secoué aux passants. Nous nous recroiserons sur quelque chemin étroit."; break;
					case 4: dialog.text = "Vous les avez joliment taillés en pièces ! Ce serait un péché de ne pas récompenser une telle aide. Prenez votre part sonnante, capitaine, et souvenez-vous : la bande n'oublie pas les siens."; break;
				}
				link.l1 = RandPhraseSimple("Pas de quoi. Bonne chance sur les routes.", "L'argent n'est jamais de trop. Filez.");
			}
			link.l1.go = "exit";
		break;

		// --- Battle story (player didn't intervene, can ask the winner) ---
		case "Story":
			switch (rand(4))
			{
				case 0:
					dialog.text = "Ce fut un massacre féroce, l'ami... L'acier résonnait si fort que les oiseaux tombaient des arbres. Nous avons perdu beaucoup des nכtres, mais peu d'entre eux sont repartis vivants.";
				break;
				case 1:
					dialog.text = "Vous auriez dמ nous voir nous affronter ! Les mousquets tonnaient, le sang giclait, les cris remplissaient tout le fourré. Nous avons eu bien du mal à tenir bon.";
				break;
				case 2:
					dialog.text = "Ils ont surgi de derrière les arbres, nous les avons accueillis à coups de lame. Nous nous sommes battus jusqu'au bout, la terre est devenue brune de sang. Mais nous les avons écrasés.";
				break;
				case 3:
					dialog.text = "Ces parages n'avaient pas vu un tel carnage depuis des lustres. Quelqu'un comptait tous nous régaler de poudre, mais ça n'a pas marché. Il ne reste que les plus coriaces et les plus chanceux.";
				break;
				case 4:
					dialog.text = "Nous nous sommes affrontés de front, sans reculer d'un pas. Les uns ont pris une balle, les autres une lame. Tout est calme dans la clairière maintenant... seuls les corbeaux tournoient.";
				break;
			}
			link.l1 = "Oui, une affaire chaude. Portez-vous bien.";
			link.l1.go = "exit";
		break;

		// --- Repeat talk after the reward ---
		case "AfterThanks":
			dialog.text = "Merci encore, capitaine. Allez en paix.";
			link.l1 = "Vous de même.";
			link.l1.go = "exit";
		break;
	}
}
