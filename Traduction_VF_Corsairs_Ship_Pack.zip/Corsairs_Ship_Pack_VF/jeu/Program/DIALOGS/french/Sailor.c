//Jason общий диалог уличных матросов
#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;
	int iTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	if (CheckAttribute(npchar, "City"))//фикс ошибок в логе. у наёмных скелетов в пещере нет города.
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Citizen\" + NPChar.City + "_Citizen.c";
		if (HasCityDialogFile("Citizen", NPChar.City, "_Citizen.c") && LoadSegment(NPChar.FileDialog2))// вызов диалога по городам <--
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);

	switch(Dialog.CurrentNode)
	{
		case "First time":
            if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
            {
                dialog.Text = "Salut, toubib.";
                Link.l1 = "Porte-toi bien, toi aussi.";
				Link.l1.go = "exit";
				break;
    		}

			if (npchar.quest.meeting == "0")
			{
				if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && CheckAttribute(npchar, "quest.crew"))//найм в команду
				{
					dialog.text = "Bonjour, "+GetAddress_Form(NPChar)+". א ce que je sais, vous êtes capitaine de votre propre navire. J'ai à vous parler affaires.";
					link.l1 = "Je vous écoute attentivement, "+GetAddress_FormToNPC(NPChar)+". De quoi s'agit-il ?";
					link.l1.go = "crew";
					link.l2 = "Désolé, "+GetAddress_FormToNPC(NPChar)+", mais je n'ai pas le temps.";
					link.l2.go = "exit";
					npchar.quest.meeting = "1";
					DeleteAttribute(npchar, "talker"); //снимаем говорилку
					if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
					{
						dialog.text = "Bienvenue dans notre douillette grotte ! Faites comme chez vous.";
						link.l1 = "Merci, mon frère. Je vais jeter un œil.";
						link.l1.go = "UP_Skelet_Vihod";
						if (!checkattribute(pchar, "questTemp.UP_SkeletyVPeshere"))//Sinistra Нежить
						{
							link.l2 = "J'ai une proposition à vous faire.";
							link.l2.go = "crew";
						}
					}
					break;
				}
				dialog.text = LinkRandPhrase("Salutations, capitaine ! Que voulez-vous d'un simple marin ?", "Bonjour, "+ GetSexPhrase("monsieur", "mademoiselle") +". Que puis-je faire pour vous ?", "Bonjour, mon cher. Vous vouliez quelque chose ?");
				link.l1 = "Bonjour, mon cher ! Je m'appelle " + GetFullName(pchar)+". Vous avez une minute pour bavarder ?";
				link.l1.go = "question";
				link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin d'informations sur les affaires de cette colonie.");
				link.l2.go = "quests";//(перессылка в файл города)
				link.l3 = "Je voulais juste vous saluer. Allez !";
				link.l3.go = "exit";
				npchar.quest.meeting = "1";
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")	//Sinistra Пролог Анжелика Тич
				{
					dialog.text = "Salutations, madame ! Que voulez-vous d'un simple marin ?";
					link.l1 = "Oui, je cherche le fiancé de ma sœur.";
					link.l1.go = "exit";
					DeleteAttribute(link, "l2");
					DeleteAttribute(link, "l3");
				}
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")//Sinistra Нежить
				{
					dialog.text = "Bienvenue dans notre douillette grotte ! Faites comme chez vous.";
					link.l1 = "Merci, mon frère. Je vais jeter un œil.";
					link.l1.go = "UP_Skelet_Vihod";
					DeleteAttribute(link, "l2");
					DeleteAttribute(link, "l3");
				}
			}
			else
			{
				dialog.text = "C'est encore vous, "+ GetSexPhrase("monsieur", "madame") +" ? Vous vouliez autre chose ?";
				link.l1 = "Vous avez une minute pour bavarder de choses et d'autres ?";
				link.l1.go = "question";
				link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin d'informations sur les affaires de cette colonie.");
				link.l2.go = "quests";//(перессылка в файл города)
				link.l3 = "Non, mon gars, rien. Bonne chance !";
				link.l3.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "question":
			dialog.text = NPCStringReactionRepeat(""+GetFullName(npchar)+"à votre service, ma chère ! Que vouliez-vous savoir ?",
				"Content de bavarder, capitaine !",
				"Eh bien, je crois que j'ai encore un peu de temps...",
                "Malheureusement, je dois y aller. Bonne journée !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous pouvez me raconter quelque chose d'intéressant ?",
				"Vous pouvez me raconter quelque chose d'intéressant ?",
                "Vous pouvez me raconter quelque chose d'intéressant ?",
				"Oui, bien sמr. Bonne chance à vous !", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("rumours_sailor", "rumours_sailor", "rumours_sailor", "exit", npchar, Dialog.CurrentNode);
		break;

		case "crew":
			switch (drand(2))
			{
				case 0: sTemp = "Quelques amis et moi avons été rayés des rכles après avoir été blessés. Maintenant, nous sommes rétablis et nous voulons de nouveau nous engager comme marins. Voulez-vous nous prendre dans votre équipage ?"; break;
				case 1: sTemp = "Moi et quelques gars avons récemment été débarqués d'un navire marchand : notre contrat avec l'armateur était arrivé à expiration. Nous sommes à quai depuis des jours et nous voulons nous engager comme marins. Vous n'auriez pas besoin de marins expérimentés dans votre équipage ?"; break;
				case 2: sTemp = "Mes amis et moi sommes rentrés d'un voyage il y a deux semaines ; l'armateur nous a payés, et nous avons bien fait la fête ces jours-ci. Mais le vent siffle dans la poche du marin, ce qui veut dire qu'il est temps de reprendre la mer. Vous nous engagez sur votre navire, capitaine ?"; break;
			}
			dialog.text = sTemp;
			link.l1 = "Eh bien, je suis prêt à examiner votre offre. Combien êtes-vous, et que savez-vous faire à bord d'un navire ?";
			link.l1.go = "crew_1";
			link.l2 = "Désolé, marin, mais mon équipage est au complet. Vous devrez chercher un autre capitaine.";
			link.l2.go = "exit";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = "Et que voulez-vous me proposer ?";
				link.l1 = "J'ai un navire, et je veux engager tes gars maigrichons dans mon équipage, qu'en dis-tu ?";
				link.l1.go = "crew_1";
				link.l2 = "Vous savez, j'ai changé d'avis.";
				link.l2.go = "UP_Skelet_Vihod";
			}
			if (pchar.sex == "Skeleton" && npchar.sex == "man")	//Sinistra Нежить
			{
				link.l1 = "Désolé de te décevoir, marin, mais... je n'ai pas besoin de « vivants » dans mon équipage. Héhé.";
				link.l1.go = "exit";
				DeleteAttribute(link, "l2");
			}
		break;

		case "crew_1":
			switch (sti(npchar.quest.crew.type))
			{
				case 0: sTemp = "Même si ce sont les voiles et le gréement que nous savons manier le mieux. Sans fausse modestie, je dirai que nous connaissons ça sur le bout des doigts : nous ne vous laisserons pas tomber, même dans la tempête la plus féroce !"; break;
				case 1: sTemp = "Cependant, c'est le pont des canons que nous préférons. Nous savons manier les canons comme personne dans votre équipage, je vous l'assure. Pendant une bataille acharnée, vous pourrez compter sur nous sans crainte !"; break;
				case 2: sTemp = "Mais notre élément, c'est l'abordage. L'éclat des sabres, l'odeur de la poudre et du sang : voilà notre vocation. Nous sommes des adversaires coriaces au combat ; en cas de danger, nos lames vous tireront d'affaire, capitaine !"; break;
			}
			dialog.text = "Nous sommes "+sti(npchar.quest.crew.qty)+" hommes, et nous n'entrerons en service qu'ensemble. Nous savons faire tout ce qu'un marin doit savoir faire. "+sTemp+"";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = "Nous sommes "+sti(npchar.quest.crew.qty)+" squelettes, et nous serons heureux de vous servir comme de fidèles serviteurs.";
			}
			if (GetFreeCrewQuantity(pchar) >= sti(npchar.quest.crew.qty))
			{
				link.l1 = "Très tentant. Combien voulez-vous d'avance ?";
				link.l1.go = "crew_2";
				link.l2 = "Désolé, marin, mais je comptais sur quelque chose de... différent. Vous devrez chercher un autre capitaine.";
				link.l2.go = "exit";
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
				{
					link.l1 = "Oui, ça me suffit. Et combien voulez-vous ?";
					link.l1.go = "crew_2";
					link.l2 = "Ce n'est pas assez, laissez tomber.";
					link.l2.go = "UP_Skelet_Vihod";
				}
			}
			else
			{
				if(GetCompanionQuantity(PChar) > 1)
				{
					ref rChar;
					for(int i = 1; i<GetCompanionQuantity(PChar); i++)
					{
						if (GetCompanionIndex(PChar,i)>-1)
						{
							rChar = &characters[GetCompanionIndex(PChar,i)];
							if(sti(rChar.index) != -1 && GetFreeCrewQuantity(rChar) >= sti(npchar.quest.crew.qty))
							{
								link.l1 = "Désolé, marin, mais je n'ai pas de place sur le navire pour vous tous. Vous devrez aller voir mon compagnon, il s'appelle " + GetFullName(rChar) + ".";
								link.l1.go = "crew_comp";
								pchar.addcrew.character = rChar.id;
								if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
								{
									link.l1 = "Désolé, mon frère, mais je n'ai pas de place sur le navire pour vous tous. Vous devrez aller voir mon compagnon, il s'appelle "+ GetFullName(rChar) + ".";
									link.l1.go = "crew_comp";
								}
								break;
							}
						}
						else
						{
							link.l1 = "Désolé, marin, mais je n'ai de place pour vous tous sur aucun navire. Vous devrez chercher un autre capitaine.";
							link.l1.go = "exit";
							if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
							{
								link.l1 = "Désolé, mon frère, mais je n'ai de place pour vous tous sur aucun navire. Restez ici, dans la grotte.";
								link.l1.go = "UP_Skelet_Vihod";
							}
						}

					}
				}
				else
				{
					link.l1 = "Désolé, marin, mais je n'ai de place pour vous tous sur aucun navire. Vous devrez chercher un autre capitaine.";
					link.l1.go = "exit";
				}
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
				{
					link.l1 = "Désolé, mon frère, mais je n'ai de place pour vous tous sur aucun navire. Restez ici, dans la grotte.";
					link.l1.go = "UP_Skelet_Vihod";
				}
				link.l2 = "Désolé, marin, mais je comptais sur quelque chose de... différent. Vous devrez chercher un autre capitaine.";
				link.l2.go = "exit";
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
				{
					DeleteAttribute(link, "l2");
				}
			}
		break;

		case "crew_comp":
			iTemp = sti(npchar.quest.crew.money)*sti(npchar.quest.crew.qty);
			dialog.text = ""+FindRussianMoneyString(sti(npchar.quest.crew.money))+" par tête. Ensuite, la solde habituelle d'un marin. Nous ne demandons pas trop, cap'taine.";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = ""+FindRussianMoneyString(sti(npchar.quest.crew.money))+" par squelette. Ensuite, la solde habituelle d'un marin. Nous ne demandons pas trop.";
			}
			if (sti(pchar.money) >= iTemp)
			{
				rChar = CharacterFromID(pchar.addcrew.character);
				link.l1 = "Marché conclu ! Voici la somme entière. Allez au navire qui s'appelle '"+rChar.ship.name+"' ; il est en rade. Le maître d'équipage vous donnera des places au gaillard d'avant et du travail.";
				link.l1.go = "crew_comp1";
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
				{
					link.l1 = "Marché conclu ! Maintenant, bougez vos carcasses et montez à bord du navire qui s'appelle '"+rChar.ship.name+"'. Que tout le monde soit à sa place dans une heure.";
					link.l1.go = "crew_comp1";
				}
			}
			link.l2 = "Malheureusement, je ne peux pas me permettre de payer vos services. Vous devrez chercher un autre capitaine.";
			link.l2.go = "exit";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				link.l2 = "Vous demandez trop, oublions ça.";
				link.l2.go = "UP_Skelet_Vihod";
			}	
		break;

		case "crew_comp1":
			iTemp = sti(npchar.quest.crew.money)*sti(npchar.quest.crew.qty);
			AddMoneyToCharacter(pchar, -iTemp);
			dialog.text = "On y va, capitaine ! Je rassemble les gars et nous montons à bord immédiatement !";
			link.l1 = "Allez, dépêchez-vous, je n'ai pas l'intention de rester ici longtemps.";
			link.l1.go = "crew_comp2";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = "Nous obéissons, nous obéissons, " + RandPhraseSimple("כ seigneur !", "seigneur des ténèbres !");
				link.l1 = "Voilà qui est mieux !";
				link.l1.go = "crew_comp2";
			}
		break;

		case "crew_comp2":
			DialogExit();
			rChar = CharacterFromID(pchar.addcrew.character);
			AddCharacterCrew(rChar, sti(npchar.quest.crew.qty));
			//увеличиваем опыт
			iTemp = makeint(sti(npchar.quest.crew.qty)*50/sti(rChar.ship.crew.quantity));
			switch (sti(npchar.quest.crew.type))
			{
				case 0: ChangeCrewExp(rChar, "Sailors", iTemp); break;
				case 1: ChangeCrewExp(rChar, "Cannoners", iTemp); break;
				case 2: ChangeCrewExp(rChar, "Soldiers", iTemp); break;
			}
			//увеличиваем мораль
			iTemp = makeint(sti(npchar.quest.crew.qty)/10)+1;
			AddCrewMorale(rChar, iTemp);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 20.0);
			npchar.lifeday = 0;
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				for (i=1; i<=15; i++)
				{
				sld = CharacterFromID("Skelet_Drug_"+i)
				LAi_SetActorType(sld);
				LAi_ActorRunToLocation(sld, "reload", "reload1_back", "none", "", "", "", 20.0);
				}
				pchar.questTemp.UP_SkeletyVPeshere = "SVP";
				SetTimerCondition("UP_SkeletyVPeshere_NanyatSnova", 0, 0, 2, false);	//Sinistra: скелетов можно будет нанимать через два дня!
			}
		break;

		case "crew_2":
			iTemp = sti(npchar.quest.crew.money)*sti(npchar.quest.crew.qty);
			dialog.text = ""+FindRussianMoneyString(sti(npchar.quest.crew.money))+" par tête. Ensuite, la solde habituelle d'un marin. Nous ne demandons pas trop, cap'taine.";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = ""+FindRussianMoneyString(sti(npchar.quest.crew.money))+" par squelette. Ensuite, la solde habituelle d'un marin. Nous ne demandons pas trop.";
			}
			if (sti(pchar.money) >= iTemp)
			{
				link.l1 = "Marché conclu ! Voici la somme entière. Allez à mon navire, il s'appelle '"+pchar.ship.name+"' ; il est en rade. Le maître d'équipage vous donnera des places au gaillard d'avant et du travail.";
				link.l1.go = "crew_3";
				if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
				{
					link.l1 = "Marché conclu ! Maintenant, bougez vos carcasses et montez à bord du navire qui s'appelle '"+pchar.ship.name+"'. Que tout le monde soit à sa place dans une heure.";
					link.l1.go = "crew_3";
				}
			}
			link.l2 = "Malheureusement, je ne peux pas me permettre de payer vos services. Vous devrez chercher un autre capitaine.";
			link.l2.go = "exit";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				link.l2 = "Vous demandez trop, oublions ça.";
				link.l2.go = "UP_Skelet_Vihod";
			}			
		break;

		case "crew_3":
			iTemp = sti(npchar.quest.crew.money)*sti(npchar.quest.crew.qty);
			AddMoneyToCharacter(pchar, -iTemp);
			dialog.text = "On y va, capitaine ! Je rassemble les gars et nous montons à bord immédiatement !";
			link.l1 = "Allez, dépêchez-vous, je n'ai pas l'intention de rester ici longtemps.";
			link.l1.go = "crew_4";
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				dialog.text = "Nous obéissons, nous obéissons, " + RandPhraseSimple("כ seigneur !", "seigneur des ténèbres !");
				link.l1 = "Voilà qui est mieux !";
				link.l1.go = "crew_4";
			}
		break;

		case "crew_4":
			DialogExit();
			AddCharacterCrew(pchar, sti(npchar.quest.crew.qty));
			//увеличиваем опыт
			iTemp = makeint(sti(npchar.quest.crew.qty)*50/sti(pchar.ship.crew.quantity));
			switch (sti(npchar.quest.crew.type))
			{
				case 0: ChangeCrewExp(pchar, "Sailors", iTemp); break;
				case 1: ChangeCrewExp(pchar, "Cannoners", iTemp); break;
				case 2: ChangeCrewExp(pchar, "Soldiers", iTemp); break;
			}
			//увеличиваем мораль
			iTemp = makeint(sti(npchar.quest.crew.qty)/10)+1;
			AddCrewMorale(pchar, iTemp);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 20.0);
			npchar.lifeday = 0;
			if (pchar.sex == "Skeleton" && npchar.sex == "Skeleton")
			{
				for (i=1; i<=15; i++)
				{
				sld = CharacterFromID("Skelet_Drug_"+i)
				LAi_SetActorType(sld);
				LAi_ActorRunToLocation(sld, "reload", "reload1_back", "none", "", "", "", 20.0);
				}
				pchar.questTemp.UP_SkeletyVPeshere = "SVP";
				SetTimerCondition("UP_SkeletyVPeshere_NanyatSnova", 0, 0, 2, false);	//Sinistra: скелетов можно будет нанимать через два дня!
			}
		break;

		//замечание по обнажённому оружию от персонажей типа citizen
		case "CitizenNotBlade":
			dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		// спайчекинг
		case "SeekSpy_Checking":
			dialog.text = "Oui, je vous le confirme, " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)], "c'est bien quelqu'un du coin.", "c'est bien quelqu'un du coin.");
			link.l1 = RandPhraseSimple("J'ai compris. Merci de votre aide.", "Tout est clair. Merci de votre aide.");
			link.l1.go = "SeekSpy_Checking_1";
		break;

		case "SeekSpy_Checking_1":
			switch (pchar.GenQuest.SeekSpy.Type)
			{
				case "guardian": LAi_SetGuardianTypeNoGroup(npchar); break;
				case "patrol":   LAi_SetPatrolTypeNoGroup(npchar);   break;
				case "citizen":  LAi_SetCitizenTypeNoGroup(npchar);  break;
				case "merchant": LAi_SetMerchantTypeNoGroup(npchar); break;
			}
			LAi_SetCitizenTypeNoGroup(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)]);
			NextDiag.CurrentNode = "First Time";
			DialogExit();
		break;
		
		case "UP_Skelet_Vihod":
			DialogExit();
			sld = CharacterFromID("Skelet_Drug")
			LAi_SetWarriorType(sld);
			LAi_CharacterDisableDialog(sld);
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
		break;
	}
}
