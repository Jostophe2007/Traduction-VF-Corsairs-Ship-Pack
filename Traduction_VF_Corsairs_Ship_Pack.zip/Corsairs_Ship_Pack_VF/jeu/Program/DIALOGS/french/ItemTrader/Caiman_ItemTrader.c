// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Encore des questions, " + GetAddress_Form(NPChar) + "...", "Des questions, des questions... Et si on faisait plutכt du commerce, " + GetAddress_Form(NPChar) + " ?",
                          "וcoutez, combien de conversations creuses peut-on avoir ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Pas de questions...", "Je n'ai rien à dire pour le moment."), "Eh, encore...",
                      "Oui, il vaut vraiment mieux marchander...", "Hum, désolé, marchand...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

