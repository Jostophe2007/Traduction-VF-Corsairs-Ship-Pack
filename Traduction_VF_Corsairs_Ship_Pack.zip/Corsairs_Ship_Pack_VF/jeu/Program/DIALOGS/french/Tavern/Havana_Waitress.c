// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	ref sld;
    float locx, locy, locz, fTemp;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
            if (pchar.questTemp.State == "Sp4Detection_FoundLetter")
            {
    		    dialog.text = "Je vous écoute, "+ GetSexPhrase("señor", "señorita") +".";
    			link.l1 = "וcoutez, "+ GetSexPhrase("ma belle", "ma jolie") +", avez-vous remarqué quelque chose d'inhabituel dans la taverne ces derniers temps ?";
    			link.l1.go = "Step_S4_1";
			}
            if (pchar.questTemp.State == "Fr3TakeAnna_toHavana")
            {
    		    dialog.text = "Je vous écoute, "+ GetSexPhrase("señor", "señorita") +".";
    			link.l1 = "Chère demoiselle, si votre âme est aussi angélique que votre apparence, vous ne refuserez certainement pas de m'aider.";
    			link.l1.go = "Step_F3_1";
			}
            if (pchar.questTemp.State == "Fr3TakeAnna_WaitOneDay")
            {
				if (GetQuestPastDayParam("questTemp") > 0)
				{
    				dialog.text = "Ah, vous voilà, "+ GetSexPhrase("señor", "señorita") +" ! Vous tombez à pic.";
    				link.l1 = "Oui, je vois que vous avez remis la bague...";
    				link.l1.go = "Step_F3_4";
				}
				else
				{
    				dialog.text = ""+ GetSexPhrase("Señor", "Señorita") +", je n'ai pas encore accompli votre mission. Patientez encore un peu, je vous en prie...";
    				link.l1 = "D'accord, ma chérie, j'attends...";
    				link.l1.go = "exit";
				}
			}
            // <== Проверяем поле состояния квестов.
		break;
//========================== Исп. линейка, квест №4. Расследование убийства ==================================
 	 	case "Step_S4_1":
			dialog.text = "Non, "+ GetSexPhrase("señor", "señorita") +", tout va bien.";
			link.l1 = "Avez-vous remarqué des gens étranges, quelque chose d'inhabituel ?";
			link.l1.go = "Step_S4_2";
        break;
 	 	case "Step_S4_2":
			dialog.text = "Il y a beaucoup de gens étranges dans notre taverne, on ne peut même pas tous les citer...";
			link.l1 = "Avez-vous vu des inconnus par ici ces derniers temps ?";
			link.l1.go = "Step_S4_3";
        break;
 	 	case "Step_S4_3":
			dialog.text = "Il y a toutes sortes de gens... וcoutez, "+ GetSexPhrase("señor", "señorita") +", je dois travailler. Ne me dérangez pas, je vous en prie.";
			link.l1 = "J'ai bien dמ vous déranger. Savez-vous quelque chose sur le meurtre commis dans la maison du commandant de La Havane, don José Ramirez de Leyva ?";
			link.l1.go = "Step_S4_4";
        break;
 	 	case "Step_S4_4":
			dialog.text = "(elle pâlit, un temps) Je sais...";
			link.l1 = "Bien, j'enquête sur cette affaire pour le compte du gouverneur général de La Havane. Je vois que vous savez quelque chose. Répondez-moi immédiatement, ou vous finirez en prison dès aujourd'hui !";
			link.l1.go = "Step_S4_5";
        break;
 	 	case "Step_S4_5":
			dialog.text = "D'accord, "+ GetSexPhrase("señor", "señorita") +", je vais tout vous dire ! Promettez-moi seulement de ne pas me faire de mal.";
			link.l1 = "Je vous promets que si vous n'êtes pas l'assassin, je ne vous ferai rien.";
			link.l1.go = "Step_S4_6";
        break;
 	 	case "Step_S4_6":
			dialog.text = "Je ne suis pas une meurtrière, "+ GetSexPhrase("señor", "señorita") +", bien sמr que non...";
			link.l1 = "Oui, ce n'est pas le travail d'une serveuse que de terrasser cinq grands gaillards en tenue de combat. Maintenant, racontez-moi tout ce que vous savez.";
			link.l1.go = "Step_S4_7";
        break;
 	 	case "Step_S4_7":
			dialog.text = ""+ GetSexPhrase("Señor", "Señorita") +", je crois que je connais l'homme qui a tué don José et enlevé doña Anna...";
			link.l1 = "Qui est-ce ?";
			link.l1.go = "Step_S4_8";
        break;
 	 	case "Step_S4_8":
			dialog.text = "Il est apparu à l'improviste, je ne me souviens pas de l'avoir vu avant. Bref, cet inconnu, un Français, à ce qu'il disait, m'a demandé de remettre une bague à doña Anna. Je me suis dit : qu'y a-t-il de mal à ça ? Doña Anna a reçu la bague, et pendant une minute, elle n'a rien dit, elle fixait le mur d'un regard vide. Puis elle m'a dit d'attendre, elle a écrit un mot et m'a demandé de le remettre au Français.\n"+
                          "Quand j'ai reçu le mot, j'ai senti que quelque chose n'allait pas. Mais je l'ai quand même remis au Français, parce qu'il est évident que c'est un homme terrible. Pour un homme pareil, envoyer quelqu'un rejoindre ses ancêtres est plus facile que de boire un verre de vin. Et ses yeux sont aussi acérés que la pointe d'une épée. C'est sans doute l'un de ces démons que nous appelons ladrones, et qui se font appeler flibustiers.";
			link.l1 = "Bon sang ! C'est donc vous qui avez prévenu doña Anna... Que savez-vous d'autre ?";
			link.l1.go = "Step_S4_9";
        break;
 	 	case "Step_S4_9":
			dialog.text = "Rien de plus, "+ GetSexPhrase("señor", "señorita") +". Cet homme a pris le mot et il est parti. Et le matin, la nouvelle s'est répandue en ville que don José était mort. C'est là que j'ai compris ce qui se passait. Seulement, je n'en ai parlé à personne, j'avais peur qu'on me prenne pour une complice du crime. "+ GetSexPhrase("Señor", "Señorita") +", vous m'avez promis de ne rien me faire de mal. Je vous en prie, tenez parole !";
			link.l1 = "Bon, je vous laisse en liberté. Même s'il est clair que c'est vous qui avez conduit l'assassin dans la maison de don José. Cependant, je crois que si ce n'était pas par vous, il aurait trouvé un autre moyen d'atteindre doña Anna. Alors vivez, pour l'instant...";
			link.l1.go = "Step_S4_10";
        break;
 	 	case "Step_S4_10":
			dialog.text = "Merci, "+ GetSexPhrase("señor", "señorita") +", que le Seigneur vous protège ! Je suis vraiment désolée que ce soit arrivé ainsi, mais je n'y suis pour rien !";
			link.l1 = "Si vous revoyez ce Français, appelez immédiatement la garde. Même s'il est peu probable qu'il revienne ici.";
			link.l1.go = "exit";
            pchar.questTemp.State = "Sp4Detection_toGovernor";
            AddQuestRecord("Spa_Line_4_MirderDetection", "3");
        break;
//========================== Фр. линейка, квест №3. Увезти донну Анну ==================================
 	 	case "Step_F3_1":
			dialog.text = "Eh bien, vraiment..."+ GetSexPhrase("Impossible de refuser quoi que ce soit à un si noble caballero !", "J'aiderai une femme aussi remarquable, bien sמr.") +"";
			link.l1 = "Il faut que vous portiez cette bague à doña Anna Ramirez de Leyva, la femme du commandant. Mais de telle façon que pas une âme ne le sache !";
			link.l1.go = "Step_F3_2";
        break;
 	 	case "Step_F3_2":
			dialog.text = "Oh, doña Anna a tant de belles bagues, pourquoi lui en faut-il une de plus ? Alors que la pauvre fille que je suis n'a rien...";
			link.l1 = "Je vois oם tu veux en venir ! Bon, garde ces 500 pièces, et tu en auras autant quand tu me rapporteras la réponse de doña Anna. Avec cet argent, tu pourras t'acheter tous les bijoux que tu voudras.";
			link.l1.go = "Step_F3_3";
			AddMoneyToCharacter(pchar, -500);
        break;
 	 	case "Step_F3_3":
			dialog.text = "Merci, "+ GetSexPhrase("señor", "señorita") +" ! Il faudra attendre un jour ou deux. Je dois finir mon service et trouver le temps d'aller chez la señora de Leyva. Et il me faut un bon prétexte : on ne peut pas se présenter chez eux comme ça...";
			link.l1 = "Très bien, ma chérie. Je t'attends...";
			link.l1.go = "exit";
			TakeItemFromCharacter(pchar, "DOjeronRing");
			pchar.questTemp.State = "Fr3TakeAnna_WaitOneDay";
			SaveCurrentQuestDateParam("questTemp");
			AddQuestRecord("Fra_Line_3_TakeAnna", "2");
        break;
 	 	case "Step_F3_4":
			dialog.text = "Oui, c'est fait.";
			link.l1 = "D'accord. Maintenant, dis-moi ce qu'elle t'a dit...";
			link.l1.go = "Step_F3_5";
        break;
 	 	case "Step_F3_5":
			dialog.text = "Est-ce que "+ GetSexPhrase("señor", "señorita") +" veut aider une pauvre fille ?\n"+
				          "Oh, "+ GetSexPhrase("señor", "señorita") +"Ne me serrez pas la main si fort, je vous en prie ! J'aurai des bleus à cause de vos doigts !";
			link.l1 = "D'accord... וcoute, je te demande de parler vite et d'aller droit au but. Ne tire pas la queue du chat, ma chérie : ce sera plus sמr pour toi...";
			link.l1.go = "Step_F3_6";
        break;
 	 	case "Step_F3_6":
			dialog.text = "D'accord, "+ GetSexPhrase("señor", "señorita") +"... Je lui ai remis votre bague. Et vous savez quoi ? Quand elle l'a vue, elle est devenue pâle comme un linge.";
			link.l1 = "Et alors ? Qu'a-t-elle dit ?";
			link.l1.go = "Step_F3_7";
        break;
 	 	case "Step_F3_7":
			dialog.text = "Rien de spécial. Elle m'a ordonné d'attendre, elle a aussitכt écrit un mot et me l'a remis.";
			link.l1 = "Donne-moi ce mot !";
			link.l1.go = "Step_F3_8";
        break;
 	 	case "Step_F3_8":
			dialog.text = "D'accord, "+ GetSexPhrase("señor", "señorita") +", ne me faites plus de mal, je vous en prie... Le voici, prenez-le.";
			link.l1 = "Bravo, brave fille. N'aie pas peur, prends encore un peu d'argent, achète-toi quelque chose... Et tiens ta langue, ma belle. Tu as compris ?";
			link.l1.go = "Step_F3_9";
        break;
 	 	case "Step_F3_9":
			dialog.text = "Compris, "+ GetSexPhrase("señor", "señorita") +", heureusement que je ne suis pas idiote.";
			link.l1 = "Eh bien, voilà qui est bien.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -500);
			AddQuestRecord("Fra_Line_3_TakeAnna", "3");
			AddQuestUserData("Fra_Line_3_TakeAnna", "sSex", GetSexPhrase("", "e"));
            ChangeItemDescribe("letter_open", "itmdescr_letter_open_FraLineQ3");
            GiveItem2Character(pchar, "letter_open");
			pchar.questTemp.State = "Fr3TakeAnna_WaitMidnight";
        break;
//========================== Тревога в таверне Гаваны ==================================
		case "Allarm":
    		dialog.text = "J'ai reconnu "+ GetSexPhrase("lui", "elle") +" ! Gardes ! Qu'on appelle la garde, il faut arrêter "+ GetSexPhrase("ce ladrón", "cette criminelle") +" !";
    		link.l1 = "Ah, caramba !!";
    		link.l1.go = "Step_F_Allarm";
			NextDiag.TempNode = "First time";
        break;
		case "Step_F_Allarm":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			chrDisableReloadToLocation = true; // закрыть выход из локации.
			GetCharacterPos(pchar, &locx, &locy, &locz);
            for (int i=1; i<=3; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("SpaGuard"+i, "sold_spa_"+(rand(7)+1), "man", "man", 20, SPAIN, 0, true));
				FantomMakeCoolFighter(sld, 20, 60, 50, BLADE_LONG, "pistol3", 30);
				LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, "EnemyFight");
                ChangeCharacterAddressGroup(sld, "Havana_tavern", "goto",   LAi_FindFarLocator("goto", locx, locy, locz));
            }
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "CannotFightCurLocation");
			SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY); //на всякий случай
			LAi_SetWaitressType(npchar);
			LAi_group_MoveCharacter(npchar, "SPAIN_CITIZENS");
			LAi_group_Attack(NPChar, Pchar);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

