// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> квест №6 англ.линейки, базар о пинасе
            if (pchar.questTemp.State == "MorrisWillams_SeekSpanishGoods")
            {
    			link.l1 = "וcoutez, avez-vous eu des Espagnols dans le port ces derniers temps ?";
    			link.l1.go = "Step_E6_1";
            }

			if (pchar.questTemp.Slavetrader == "FindRatJamaica")
            {
                link.l1 = "Bonjour. Le capitaine François Gontier, arrivé de Portobelo, s'est-il enregistré chez vous ? Il a une corvette nommée '" + pchar.questTemp.Slavetrader.ShipName + "'.";
                link.l1.go = "Jamaica_ratPP_1";
            }

		break;
//************************************* Диалоги по англ.линейке *******************************
		case "Step_E6_1":
            dialog.text = "Un Espagnol, c'est un visiteur rare ici. Mais il y en a bien un qui a mouillé ici tout récemment, et sous la protection des soldats de la garnison.";
			link.l1 = "דa alors ! Pourquoi des soldats anglais garderaient-ils un navire espagnol ?";
			link.l1.go = "Step_E6_2";
		break;

		case "Step_E6_2":
            dialog.text = "Le diable seul le sait, ce doit être un ordre du gouverneur général.";
			link.l1 = "Oם est cet Espagnol maintenant ? Et quel genre de navire est-ce ?";
			link.l1.go = "Step_E6_3";
		break;

		case "Step_E6_3":
            dialog.text = "La pinasse Santa Agueda ; elle est partie hier par vent favorable, cap sur San Juan. Que lui voulez-vous, à cet Espagnol ?";
			link.l1 = "Je veux voir son capitaine, il me doit...";
			link.l1.go = "Step_E6_4";
		break;

		case "Step_E6_4":
            dialog.text = "Hé, voilà qui est bien... Mais n'oubliez pas que le vent n'a pas tourné. Si vous voulez voir la poupe de la pinasse avant San Juan, il faut prendre la mer tout de suite. Et quant à savoir si vous la rattraperez, c'est une autre affaire...";
			link.l1 = "J'essaierai quand même. Au revoir, et portez-vous bien.";
			link.l1.go = "exit";
			AddQuestRecord("Eng_Line_6_MorrisWillams", "9");
			pchar.questTemp.State = "MorrisWillams_CatchUpPinnace";
            SaveCurrentQuestDateParam("questTemp");
			pchar.quest.MorrisWillams_CheckTimeForForward.win_condition.l1 = "location";
			pchar.quest.MorrisWillams_CheckTimeForForward.win_condition.l1.location = "Jamaica";
			pchar.quest.MorrisWillams_CheckTimeForForward.win_condition = "MorrisWillams_CheckTimeForForward";
		break;

		case "Jamaica_ratPP_1":
			dialog.text = NPCStringReactionRepeat("Non. François Gontier ne s'est pas enregistré, et la corvette '" + pchar.questTemp.Slavetrader.ShipName + "' n'est pas entrée dans le port de Port Royal.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Gontier.", "Je vous prie de ne pas me déranger dans mon travail !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je vois. Nous continuerons à chercher...", "Hum, eh bien, oui...", "Oui, c'est vrai, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

