// Gregg: the messenger from Bermudes - the "Black Orchid" trilogy (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// In the original these two nodes sat in the shared Pirates.c file as 8 and 9;
// here the messenger has his own file so we need not drag in a whole foreign dialogue.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Vous êtes le capitaine " + GetFullName(PChar) + " ?";
			link.l1 = "Oui. Que voulez-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "C'est " + GetFullName(CharacterFromID("Pirates_tavernkeeper")) + ", le tavernier des Bermudes, qui m'envoie. Il vous demande de passer le voir : il dit avoir des nouvelles qui vous intéresseront.";
			link.l1 = "Vraiment ? Bien, dites-lui que je lui rendrai visite.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactFirstToBermudes");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
