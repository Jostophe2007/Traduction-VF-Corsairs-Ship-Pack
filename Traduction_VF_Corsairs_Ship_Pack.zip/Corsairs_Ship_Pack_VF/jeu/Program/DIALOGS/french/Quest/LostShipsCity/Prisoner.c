
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp;
	float   locx, locy, locz;

	switch(Dialog.CurrentNode)
	{
		case "prisonerHead":
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Bonjour. Si je comprends bien, c'est vous "+ GetSexPhrase("le dernier citoyen arrivé ", "la dernière citoyenne arrivée ") +" ?";
				link.l1 = "C'est exact. Je m'appelle " + GetFullName(pchar) + ".";
				link.l1.go = "FTH_1";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = "Bonjour. Que venez-vous faire en prison ?";
				link.l1 = "Rien de spécial. Je passais juste par là.";
				link.l1.go = "Exit";
				//квест со скелетом Декстера
				if (CheckAttribute(pchar, "questTemp.LSC.lostDecster") && !CheckAttribute(npchar, "quest.decster"))
				{
					if (pchar.questTemp.LSC.lostDecster == "seekBox" || pchar.questTemp.LSC.lostDecster == "toAdmiral")
					{
						link.l6 = "Savez-vous qui dirigeait la prison avant vous ?";
						link.l6.go = "LostDecsterHead";
					}
				}
				//муж Элис Тейлор
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toElis")
				{
					link.l7 = "Pourriez-vous me dire pourquoi Maxim Taylor s'est retrouvé ici ?";
					link.l7.go = "ELTHusb_begin";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "seekFreeMotod")
				{
					link.l7 = "וcoutez, y a-t-il un moyen de faciliter la libération de cet ivrogne et bagarreur de Maxim Taylor ?";
					link.l7.go = "ELTHusb_SF";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toAdmiral")
				{
					link.l7 = "וcoutez, y a-t-il un moyen de faciliter la libération de cet ivrogne et bagarreur de Maxim Taylor ?";
					link.l7.go = "ELTHusb_SF";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "וcoutez, nous avons à parler sérieusement. Je recrute un équipage.";
					link.l8.go = "SeekCrew";
				}
			}
			NextDiag.TempNode = "prisonerHead";
		break;
		case "FTH_1":
			dialog.text = "Eh bien, toutes mes félicitations. Je suis le directeur de la prison de la Cité, je ne rends de comptes qu'à l'amiral. Je ne demande qu'à être en bons termes avec tout le monde, mais gardez à l'esprit que si vous vous retrouvez derrière les barreaux, l'amitié s'arrête là.";
			link.l1 = "Oui, oui, je comprends. Et vous voyez passer beaucoup de monde ?";
			link.l1.go = "FTH_2";
		break;
		case "FTH_2":
			dialog.text = "Non, malheureusement, il n'y a eu personne depuis longtemps. Les clans vivent leur vie, ils ne se font pas remarquer. Et les citoyens préfèrent ne pas faire de grabuge.";
			link.l1 = "Je vois. Eh bien, bon courage dans votre dur labeur de ne rien faire.";
			link.l1.go = "FTH_3";
		break;
		case "FTH_3":
			dialog.text = "Ne m'en parlez pas ! Parfois, je suis prêt à hurler à la lune d'ennui...";
			link.l1 = "Je comprends... Eh bien, bonne journée.";
			link.l1.go = "Exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "prisoner":
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Salutations. Je suis content que tu aies survécu et que tu sois maintenant parmi nous. Je suis geכlier, je m'appelle " + GetFullName(npchar) + ".";
				link.l1 = "C'est un plaisir. Et moi, je suis le capitaine " + GetFullName(pchar) + ".";
				link.l1.go = "FTP_1";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = "Si tu es ici pour affaires, je te prie de t'adresser au chef.";
				//квест со скелетом Декстера
				if (CheckAttribute(pchar, "questTemp.LSC.lostDecster") && npchar.chr_ai.type == LAI_TYPE_SIT && !CheckAttribute(npchar, "quest.decster"))
				{
					if (pchar.questTemp.LSC.lostDecster == "seekBox" || pchar.questTemp.LSC.lostDecster == "toAdmiral")
					{
						link.l1 = "Dis, tu sais qui est Leighton Dexter ?";
						link.l1.go = "LostDecster";
					}
				}
				//квест с вином от Доминика Легро
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "toTomasBoil" && CheckCharacterItem(pchar, "potionwine"))
				{
					link.l2 = "L'ami, je t'apporte"+ GetSexPhrase("", "") +" une bouteille de vin de la part de ton ami Dominic Legro. Bois un coup, détends-toi, au lieu de rester enfermé ici pour l'éternité...";
					link.l2.go = "WineLogro";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "toSecondToPrison")
				{
					link.l2 = "L'ami, c'est encore moi. Et toujours au sujet de Dominic Legro.";
					link.l2.go = "SecondLogro";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "to3ToPrison")
				{
					link.l2 = "L'ami, on dirait que Dominic n'a rien fait de répréhensible avec Armo.";
					link.l2.go = "LastLegro";
				}
				//помощь тюремщика в наезде на касперов, если Армо убита
				iTemp = GetCharacterIndex("LSCwaitress");
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "over" && CheckAttribute(pchar, "questTemp.LSC.LegroHelp.Armo") && iTemp != -1 && characters[iTemp].name != "Armo" && pchar.questTemp.LSC == "toSeekMechanik")
				{
					link.l3 = "L'ami, tu sais qu'Armo a été tuée ?";
					link.l3.go = "ArmoIsDead";
				}
				link.l10 = "D'accord, compris.";
				link.l10.go = "Exit";
			}
			NextDiag.TempNode = "prisoner";
		break;
		case "FTP_1":
			dialog.text = "Eh bien, voilà, nous avons fait connaissance. Si tu es ici pour affaires, il faut t'adresser à mon chef.";
			link.l1 = "Je vois.";
			link.l1.go = "exit";
		break;

		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Quel équipage ?",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "דa suffit, je suis fatigué...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Un équipage pour un navire. Je quitte la Cité.",
				"Oui... Pardon, ça m'était sorti de la tête.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Vous avez perdu la tête ? Vous ne connaissez pas les lois de la Cité ?";
			link.l1 = "Je sauve ma vie, c'est tout. Je vous propose de sauver la vכtre par la même occasion. Le fait est que la Cité sera détruite par cette tempête.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Je ne vous crois pas.";
			link.l1 = "Vous avez bien tort.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Héhé, vous faites "+ GetSexPhrase("un sacré devin", "une sacrée devineresse") +", ça me laisse pantois ! Je vous conseille de vous calmer.";
			link.l1 = "Eh bien, moi, je propose, c'est tout...";
			link.l1.go = "exit";
		break;

		//освободить мужа Элис Тейлор
		case "ELTHusb_begin":
			dialog.text = NPCStringReactionRepeat("Vous n'allez pas le croire ! Ce crétin s'est soמlé à la taverne et il est allé à la résidence réclamer ses droits à l'amiral.",
				"J'ai déjà répondu à votre question.",
				"Nous en avons déjà parlé !",
                "וcoutez, arrêtez tout de suite !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oh là là... Et qu'est-ce qu'il essayait d'exiger ?",
				"Oui, oui, je m'en souviens.",
                "Bien sמr.",
				"Bon, bon...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("ELTHusb_begin_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "ELTHusb_begin_1":
			dialog.text = "Allez savoir. En fait, Maxim est notre pensionnaire permanent, mais c'est la première fois qu'il s'en prend à Capper. Et il a eu bien tort, je vous le dis. Une fois ici, il s'en est très bien tiré...";
			link.l1 = "Que pouvait-il arriver de pire ?";
			link.l1.go = "ELTHusb_begin_2";
		break;
		case "ELTHusb_begin_2":
			dialog.text = "Eh bien, l'histoire ne s'écrit pas au conditionnel.";
			link.l1 = "En somme, c'est clair...";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "3");
		break;

		case "ELTHusb_SF":
			dialog.text = NPCStringReactionRepeat("Je vous demanderais de vous adresser à l'amiral pour cette question. C'est lui qui l'a mis ici, qu'il décide de son sort.",
				"Nous avons déjà parlé de ce sujet.",
				"Je vous répète encore une fois que nous avons déjà parlé de ce sujet.",
                "Vous le faites exprès ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Y a-t-il un moyen de m'arranger avec vous ?",
				"Oui, j'avais oublié...",
                "J'ai encore oublié.",
				"דa y ressemble fort...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("ELTHusb_SF_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "ELTHusb_SF_1":
			dialog.text = "Vous avez perdu la tête ! Allez voir Capper, c'est mon conseil.";
			link.l1 = "Merci du conseil.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "4");
		break;

		case "LostDecsterHead":
			dialog.text = "Non, je ne sais pas. Et je ne vous conseille pas de le savoir.";
			link.l1 = "Dans quel sens ?";
			link.l1.go = "LostDecsterHead_1";
		break;
		case "LostDecsterHead_1":
			dialog.text = "Au sens propre. Je ne vous conseille pas de savoir qui dirigeait la prison avant moi.";
			link.l1 = "Ou peut-être que c'est Leighton Dexter.";
			link.l1.go = "LostDecsterHead_2";
		break;
		case "LostDecsterHead_2":
			dialog.text = "Tout est possible... Et pourquoi ces questions ?";
			link.l1 = "Pour rien, simple curiosité.";
			link.l1.go = "LostDecsterHead_3";
		break;
		case "LostDecsterHead_3":
			dialog.text = "Ne la montrez plus. La curiosité, voyez-vous, est une propriété très dangereuse de l'organisme...";
			link.l1 = "Hum... Oui, oui, je comprends.";
			link.l1.go = "exit";
			npchar.quest.decster = true; //не повторять базар
		break;

		case "LostDecster":
			dialog.text = "L'ancien chef du Tartarus.";
			link.l1 = "Et oם est-il maintenant ?";
			link.l1.go = "LostDecster_1";
		break;
		case "LostDecster_1":
			dialog.text = "Héhé... Derrière la porte là-bas, à gauche de la dernière cellule de la rangée de droite. Mais pas un mot à quiconque !..";
			link.l1 = "Jamais !";
			link.l1.go = "exit";
			AddQuestRecord("LSC_findDekster", "4");
			npchar.quest.decster = true; //не повторять базар
		break;
		//вино от Доминика Легро
		case "WineLogro":
			dialog.text = "Une bouteille de vin de la part de Dominic Legro ?! Je la prends, soit. Mais dis à ce vaurien que je lui réglerai son compte !";
			link.l1 = "Je n'ai pas compris...";
			link.l1.go = "WineLogro_1";
		break;
		case "WineLogro_1":
			dialog.text = "Et tu n'as rien à comprendre. Dis-lui simplement que je lui couperai les oreilles à la première occasion.";
			link.l1 = "D'accord, je transmettrai... Et Dominic qui pensait que ça te ferait plaisir.";
			link.l1.go = "WineLogro_2";
			TakeItemFromCharacter(pchar, "potionwine");
		break;
		case "WineLogro_2":
			dialog.text = "דa me fait très plaisir... Bon, je n'ai pas le temps de faire la causette ici. Merci pour le vin, et dis à Dominic ce que je t'ai dit.";
			link.l1 = "D'accord, je transmettrai.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "toFackDominic";
			AddQuestRecord("TakeVineToPrisoner", "2");
			AddQuestUserData("TakeVineToPrisoner", "sSex", GetSexPhrase("", "e"));
		break;

		case "SecondLogro":
			dialog.text = "Qu'est-ce que tu en dis ?";
			link.l1 = "Je lui ai transmis tes paroles. Il a été très surpris et jure qu'il ne sait absolument pas ce qui se passe.";
			link.l1.go = "SecondLogro_1";
		break;
		case "SecondLogro_1":
			dialog.text = "Vraiment ?";
			link.l1 = "Il l'a juré.";
			link.l1.go = "SecondLogro_2";
		break;
		case "SecondLogro_2":
			iTemp = GetCharacterIndex("LSCwaitress");
			if (iTemp != -1 && characters[iTemp].name == "Armo")
			{
				dialog.text = "Et quand il a juré, il ne se serait pas souvenu, par hasard, de la façon dont il flirtait l'autre jour avec Armo Dulin, la serveuse de la taverne ?";
				link.l1 = "Je n'en ai aucune idée.";
				link.l1.go = "SecondLogro_3";
				pchar.questTemp.LSC.LegroHelp.Armo = true; //флаг на то, что квест пошёл с участием Армо
			}
			else
			{
				dialog.text = "Vraiment ? Hum, eh bien, alors, nous devrions peut-être nous réconcilier.";
				link.l1 = "Mais Dominic ne s'est jamais disputé avec toi.";
				link.l1.go = "LastLegroAdd";
			}
		break;
		case "SecondLogro_3":
			dialog.text = "Eh bien, demande-le-lui.";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "toArmoDominic";
			AddQuestRecord("TakeVineToPrisoner", "4");
		break;

		case "LastLegro":
			dialog.text = "Comment ça ?";
			link.l1 = "Il dit qu'il ne faisait que parler avec Armo, mais qu'il ne lui faisait absolument pas la cour.";
			link.l1.go = "LastLegro_1";
		break;
		case "LastLegro_1":
			dialog.text = "Mais on m'a dit...";
			link.l1 = "Ne te fie pas aux ragots dans tes relations avec tes amis.";
			link.l1.go = "LastLegro_2";
		break;
		case "LastLegro_2":
			dialog.text = "Oui, tu as raison. Bon, je crois Dominic. Dis-lui que je suis désolé. On dirait que je me suis conduit de manière indigne.";
			link.l1 = "Oui, en effet, ça en a tout l'air.";
			link.l1.go = "LastLegro_3";
		break;
		case "LastLegro_3":
			dialog.text = "Merci, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", d'avoir pris part à notre histoire avec Dominic.";
			link.l1 = "C'est toujours un plaisir d'aider.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "toKeyDominic";
			AddQuestRecord("TakeVineToPrisoner", "6");
		break;

		case "LastLegroAdd":
			dialog.text = "Oui, tu as raison... וcoute, dis à Dominic que tout va bien. Je ne lui en veux pas.";
			link.l1 = "Eh bien, parfait ! Bon, alors je crois que je vais y aller...";
			link.l1.go = "LastLegro_3";
		break;
		//если Армо убита, то тюремщик может помочь в наезде на касперов
		case "ArmoIsDead":
			dialog.text = "Je le sais.";
			link.l1 = "Tu sais qui a fait ça ?";
			link.l1.go = "ArmoIsDead_1";
		break;
		case "ArmoIsDead_1":
			dialog.text = "J'essaie de le découvrir. Dès que je le trouve, je lui arrache le cœur.";
			link.l1 = "C'est Juan Kobo qui l'a fait, l'un des « Caspers ».";
			link.l1.go = "ArmoIsDead_2";
		break;
		case "ArmoIsDead_2":
			dialog.text = "Comment le savez-vous ?";
			link.l1 = "C'est lui-même qui me l'a dit. Mais rien ne presse, je l'ai déjà tué.";
			link.l1.go = "ArmoIsDead_3";
		break;
		case "ArmoIsDead_3":
			dialog.text = "Désolé...";
			link.l1 = "Eh bien, je ne dirais pas ça.";
			link.l1.go = "ArmoIsDead_4";
		break;
		case "ArmoIsDead_4":
			dialog.text = "Que voulez-vous dire ?";
			link.l1 = "Je te propose de ne pas faire de cette vengeance une affaire personnelle, mais de te venger de tout le clan, car Kobo n'était qu'un exécutant. Tu sais aussi bien que moi qu'ils ne font pas un pas sans les ordres du chef du clan.";
			link.l1.go = "ArmoIsDead_5";
		break;
		case "ArmoIsDead_5":
			dialog.text = "C'est vrai...";
			link.l1 = "Je compte donner l'assaut au San Gabriel. Tu peux venir avec moi.";
			link.l1.go = "ArmoIsDead_6";
		break;
		case "ArmoIsDead_6":
			dialog.text = "Je suis prêt.";
			link.l1 = "Alors, en avant, ne remettons pas cette affaire à plus tard.";
			link.l1.go = "ArmoIsDead_7";
		break;
		case "ArmoIsDead_7":
			if (npchar.chr_ai.type == LAI_TYPE_SIT)
			{
				GetCharacterPos(npchar, &locx, &locy, &locz);
				ChangeCharacterAddressGroup(npchar, npchar.location, "goto", LAi_FindNearestFreeLocator("goto", locx, locy, locz));
			}
			//sld.dialog.currentnode = "AfterFightCasper";//фикс - sld - вообще рандомный непись, а диалог прописывается позже в квестреакциях
			LAi_SetActorType(npchar);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			AddQuestRecord("ISS_MainLine", "70");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "AfterFightCasper":
			dialog.text = "Eh bien, on dirait qu'on a réussi.";
			link.l1 = "C'est vrai. Merci pour ton aide, l'ami. Tu ne voudrais pas continuer à te lancer dans ce genre de pagaille avec moi ?";
			link.l1.go = "AfterFightCasper_1";
		break;
		case "AfterFightCasper_1":
			dialog.text = "Non. C'était une vengeance, pas une soif d'aventure. Je crois que je vais aller me soמler. C'est dur sans Armo...";
			link.l1 = "Et la prison ?";
			link.l1.go = "AfterFightCasper_2";
		break;
		case "AfterFightCasper_2":
			dialog.text = "Je me fiche de la prison, de l'amiral et même de toute cette maudite Cité ! Eh, la vie n'a plus de goמt pour moi sans Armo...";
			link.l1 = "Désolé pour toi, l'ami.";
			link.l1.go = "AfterFightCasper_3";
		break;
		case "AfterFightCasper_3":
			GetCharacterPos(NPChar, &locx, &locy, &locz);
			LAi_SetActorTypeNoGroup(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

	}
}
