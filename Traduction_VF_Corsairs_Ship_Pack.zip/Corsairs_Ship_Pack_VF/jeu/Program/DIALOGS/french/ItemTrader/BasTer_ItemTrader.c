// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Encore des questions, " + GetAddress_Form(NPChar) + "...", "Des questions, des questions... Et si on faisait plutכt du commerce, " + GetAddress_Form(NPChar) + " ?",
                          "וcoutez, combien de conversations creuses peut-on avoir ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Pas de questions...", "Je n'ai rien à dire pour le moment."), "Eh, encore...",
                      "Oui, il vaut vraiment mieux marchander...", "Hum, désolé, marchand...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.PDM_PK_UznatLichnost == "UznatLichnost")	// Квест "The Lost Ring"
            {
                link.l1 = "Parlez-moi d'une femme étrange qui a perdu sa bague. Vous la connaissez ?";
                link.l1.go = "PDM_PK_UznatLichnost";
            }
		break;

//**************************Квест "The Lost Ring"*******************************
		case "PDM_PK_UznatLichnost":
			int Phrase;
                Phrase = rand(4);
                if (Phrase == 0)
                {
					dialog.text = "Elle est simplement folle, ne faites pas attention à elle.";
					link.l1 = "D'accord.";
					link.l1.go = "exit";
				break;
				}
                if (Phrase == 1)
                {
					dialog.text = "Et pourquoi vous intéressez-vous à cette folle ? Achetez-moi plutכt quelque chose.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 2)
                {
					dialog.text = "Je "+ GetSexPhrase("suis marchand", "suis marchande") +", pas un colporteur de ragots.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 3)
                {
					dialog.text = "Je ne la connais pas, désolé.";
					link.l1 = "Bon, je vais demander à quelqu'un d'autre.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 4)
                {
					dialog.text = "Elle n'a pas simplement perdu une bague. C'est une terrible histoire. J'en ai le cœur brisé chaque fois que je la raconte. Elle s'appelle Josephine Lodet. Elle avait offert une magnifique bague à son fils la veille de son premier voyage. Pour lui porter chance, disait-elle. Il a pris part à l'attaque de Santo Domingo et il a été tué au premier combat. Quand la nouvelle de sa mort est arrivée sur nos rivages, la pauvre Josephine... Enfin, vous avez des yeux, vous avez vu ce qui lui est arrivé.";
					link.l1 = "Quel genre de bague était-ce ?";
					link.l1.go = "PDM_PK_UznatLichnost_2";
				break;
				}
        break;

		case "PDM_PK_UznatLichnost_2":
			dialog.text = "Un bijou très beau et très cher. Le plus beau saphir que j'aie jamais vu, serti dans de l'or. Son grand-père l'avait rapporté d'Europe. Je ne suis pas joaillier, mais il pouvait valoir dix... ou vingt mille ? Ah, une terrible histoire ! Bon, bonne chance à vous !";
			Link.l1 = "Merci, " + npchar.name+". Vous m'avez été d'une grande aide. Au revoir.";
			Link.l1.go = "exit";

			sld = CharacterFromID("Josephine_Lodet")
			sld.name = "Josephine";
			sld.lastname = "Lodet";

			AddQuestRecord("PDM_Poteryanoe_Koltso", "2");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));

			pchar.questTemp.PDM_PK_IshemKoltso = "IshemKoltso";
			DeleteAttribute(pchar, "questTemp.PDM_PK_UznatLichnost");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

