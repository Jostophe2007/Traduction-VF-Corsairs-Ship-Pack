
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";
//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            if (pchar.questTemp.Ascold == "SeekInformatorHavanna" || pchar.questTemp.Ascold == "2SeekInformatorHavanna")
            {
            	dialog.text = "Bonjour, qui êtes-vous et que voulez-vous ?";
        		link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je viens de la part d'Askold.";
        		link.l1.go = "Step_1";
            }
            if (pchar.questTemp.Ascold == "ReciveInformationManowar")
            {
				if (!CheckAttribute(pchar, "questTemp.Ascold.IKnowTheShip"))
				{
					dialog.text = "Que voulez-vous exactement ?";
					link.l1 = "וcoutez-moi : vous avez dit avoir dressé l'inventaire. Je serai très généreux si vous vous souvenez du capitaine et du navire...";
					link.l1.go = "Step_8";	
				}
				else
				{
            	dialog.text = "Je vais sans doute m'abstenir de traiter avec vous, vous ne me plaisez pas, même si vous êtes"+ GetSexPhrase("un ami", "une connaissance") +" d'Askold.";
        		link.l1 = "Comme vous voudrez...";
        		link.l1.go = "exit";
				}
            }
        break;

//<<<<<<<<<<<<======== Разброс диалогов по персонажам ======================
 		case "Step_1":
        	dialog.text = "Quel Askold ?";
    		link.l1 = "Un homme ordinaire qui vit à la Guadeloupe. Il n'y en a pas d'autre dans les Caraïbes.";
    		link.l1.go = "Step_2";
		break;

 		case "Step_2":
        	dialog.text = "Parlez plus bas, je vous comprends parfaitement. De quoi mon ami Askold a-t-il besoin ?";
    		link.l1 = "Il y a un problème. Il y a quelque temps, un vaisseau de ligne a quitté La Havane, chargé à ras bord d'objets de culte indiens.";
    		link.l1.go = "Step_3";
		break;

 		case "Step_3":
        	dialog.text = "Bon, à ras bord, c'est beaucoup dire. Il y avait des objets de culte indiens, mais pas tant que ça\n"+
                          "J'étais détaché à La Havane et j'ai personnellement dressé l'inventaire de la cargaison.";
    		link.l1 = "C'est ce dont Askold a besoin, de cet inventaire.";
    		link.l1.go = "Step_4";
		break;

 		case "Step_4":
        	dialog.text = "S'il avait su qu'il en avait besoin, il en aurait fait une copie. Bon, maintenant, je ne me souviens même pas de la moitié\n"+
                          "Maintenant, je ne sais même pas comment l'aider.";
    		link.l1 = "Je comprends. La seule chose que j'ai besoin de savoir, c'est oם est parti le vaisseau de ligne.";
    		link.l1.go = "Step_5";
		break;

 		case "Step_5":
        	dialog.text = "Il est parti pour la baie d'Amatique, au sud de Belize. Il doit faire escale aux Caïmans en chemin.";
    		link.l1 = "דa alors ! C'est un endroit étrange... Et il est parti seul ?";
    		link.l1.go = "Step_6";
		break;

 		case "Step_6":
        	dialog.text = "Oui, il est parti seul. Le fait est que les Caïmans sont le point de rassemblement d'autres navires des colonies espagnoles d'Amérique. Vous imaginez, à Amatique, on a trouvé un temple indien abandonné plus loin dans les terres de la Terre Ferme, et maintenant il y a là-bas une véritable extermination royale. Et une fois l'expédition terminée, l'escadre doit partir pour l'Ancien Monde\n"+
                          "Oui, il est parti seul. Le fait est que les Caïmans sont le point de rassemblement d'autres navires des colonies espagnoles d'Amérique. Imaginez, on a trouvé à Amatique un temple indien abandonné, plus loin dans la Terre Ferme, et maintenant, une expédition royale y travaille. Et une fois que l'expédition aura terminé son travail, l'escadre doit partir pour l'Ancien Monde.";
    		link.l1 = "דa suffit, merci, l'ami. Je saluerai Askold de ta part.";
    		link.l1.go = "Step_7";
		break;

 		case "Step_7":
        	dialog.text = "Hé, " + GetAddress_Form(pchar) + ", attendez ! Et l'argent ?"+ GetSexPhrase("", "") +" !";
    		link.l1 = "וcoute, je suis ton nouvel ami, et Askold, un vieil ami. Et l'argent, seuls les vieux amis en apportent. Alors adieu, et à la prochaine !";
    		link.l1.go = "exit";

			// Nathaniel (21.01.24): здесь делаю развилку на случай, если игрок захочет упростить себе задачу
			link.l2 = "וcoutez-moi : vous avez dit avoir dressé l'inventaire. Je serai très généreux si vous vous souvenez du capitaine et du navire...";
			link.l2.go = "Step_8";

			npchar.LifeDay = 5;
			SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
            AddQuestRecord("Ascold", "7");
            pchar.questTemp.Ascold = "ReciveInformationManowar";
            Pchar.quest.Ascold_AttackTenManowars.win_condition.l1 = "location";
            Pchar.quest.Ascold_AttackTenManowars.win_condition.l1.location = "Caiman";
            Pchar.quest.Ascold_AttackTenManowars.win_condition = "Ascold_AttackTenManowars";
		break;

        case "Step_8":
            dialog.text = "Hum, je ne m'attendais pas à ça de votre part, " + GetAddress_Form(pchar) + " " + pchar.name + ". Et combien pouvez-vous offrir ?";
            link.l1 = "Disons 250 000 piastres. Je suppose que c'est suffisant pour une information.";
            link.l1.go = "Step_9";
        break;

		case "Step_9":
			if (IsCharacterPerkOn(pchar, "Agent") || GetCharacterSkillNoBonus(pchar, SKILL_LEADERSHIP) > 70)
			{
				dialog.text = "Eh bien, marché conclu.";
				link.l1 = "Tenez ! Adieu, " + GetAddress_FormToNPC(npchar) + ".";
				link.l1.go = "Step_10";
			}
			else
			{
				dialog.text = "Qu'est-ce que vous racontez ?! Allez au diable !!!";
				link.l1 = "Ne vous énervez pas tant, " + GetAddress_FormToNPC(npchar) + "... Adieu...";
				link.l1.go = "exit";
			}
		break;

		case "Step_10":
			if (sti(pchar.money) < 250000)
			{
				dialog.text = "Vous vous moquez de moi ?! Oם sont les 250 000 piastres promises ? Oh, vous allez avoir des ennuis...";
				link.l1 = "Argh... J'ai oublié de demander au trésorier. Attendez-moi !";
				link.l1.go = "exit";
				NextDiag.TempNode = "IHaveNoMoney";
			}
			else
			{
				dialog.text = "Merci beaucoup, " + GetAddress_Form(pchar) + " " + pchar.name + ". Mais je ne peux que vous décrire ce navire... Bonne chance, mon ami...";
				link.l1 = "...";
				link.l1.go = "exit";
				AddMoneyToCharacter(pchar, -250000);
				
				// Nathaniel (21.01.24): признак того, что знаем корабль (пока не знаю, вдруг понадобится)
				pchar.questTemp.Ascold.IKnowTheShip = true;
				
				// Nathaniel (21.01.24): дополнительная запись в судовом журнале
				AddQuestRecord("Ascold", "7_1");
			}
		break;

		case "IHaveNoMoney":
			dialog.text = "Bon sang, " + GetAddress_FormToNPC(npchar) + ", oם étiez-vous donc ?!";
			link.l1 = "Prenez votre argent, " + GetAddress_FormToNPC(npchar) + ".";
			link.l1.go = "Step_10";
		break;

 		case "Exit":
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
    }
}
