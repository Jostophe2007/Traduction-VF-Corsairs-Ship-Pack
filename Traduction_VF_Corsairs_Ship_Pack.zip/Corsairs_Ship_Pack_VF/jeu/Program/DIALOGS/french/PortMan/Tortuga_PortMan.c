// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> квест №7 голл.линейки, догнать похитителей депеши
            if (pchar.questTemp.State == "DelivLettTortuga_toPortMan")
            {
    			link.l1 = "D'Ogeron m'envoie vers vous pour que vous me disiez immédiatement quel navire a quitté les eaux de Tortuga au cours des deux dernières heures !";
    			link.l1.go = "Step_H7_1";
            }
            if (pchar.questTemp.State == "Sp6TakeMess_toTotuga")
            {
                link.l1 = "J'ai l'honneur de vous présenter mes respects et de vous soumettre mes documents. Veuillez prendre connaissance de ma procuration commerciale de la Compagnie française des Indes orientales.";
                link.l1.go = "Step_S6_1";
            }
            if (pchar.questTemp.State == "Sp6TakeMess_waitMessanger")
            {
                link.l1 = "וcoutez, le navire hollandais que j'attendais est-il arrivé ?";
                link.l1.go = "Step_S6_6";
            }
            if (pchar.questTemp.State == "Fr4SoleiRoyal_toPortMan")
            {
                link.l1 = "Selon l'ordonnance de d'Ogeron, vous devez mettre à ma disposition le vaisseau de premier rang Soleil Royal.";
                link.l1.go = "Step_F4_1";
            }

			if (pchar.questTemp.Slavetrader == "FindRatTortuga")
            {
                link.l1 = "Bonjour. Je cherche François Gontier. Sa corvette '" + pchar.questTemp.Slavetrader.ShipName + "' devrait avoir mouillé dans votre port.";
                link.l1.go = "Tortuga_ratP_1";
            }

		break;

//************************************* Голл. линейка, квест №7, доставка депеши *******************************
		case "Step_H7_1":
            dialog.text = "Un seul : le brick La Rochelle. Il est parti pour Porto Rico, en direction de San Juan. Le représentant commercial de la Compagnie française des Indes orientales est parti avec lui.";
			link.l1 = "Quel représentant ?!";
			link.l1.go = "Step_H7_2";
		break;
		case "Step_H7_2":
            dialog.text = "Je vous le dis : un représentant de la Compagnie française des Indes orientales. Il est arrivé ici il y a quelques jours et a aussitכt présenté une procuration de la compagnie. Il avait réglé ses affaires et voulait aller directement d'ici chez vous, à Curaçao ; il cherchait pour cela un navire en partance. Je l'ai adressé à vous\n"+
                          "Mais au dernier moment, ses plans ont apparemment changé, et il est parti avec le brick sur lequel il était d'ailleurs venu à Tortuga.";
			link.l1 = "Bon sang, on dirait que c'est Antonio...";
			link.l1.go = "Step_H7_3";
		break;
		case "Step_H7_3":
            dialog.text = "C'est ça, Antonio de... de... Je ne m'en souviens plus.";
			link.l1 = "Je dois rattraper ce maudit brick immédiatement. C'est une question de vie ou de mort.";
			link.l1.go = "Step_H7_4";
		break;
		case "Step_H7_4":
            dialog.text = "Vraiment ? Eh bien, c'est possible. Dans ce cas, ne perdez pas de temps.";
			link.l1 = "Merci pour l'information, même si je n'éprouve aucune gratitude à l'idée de rencontrer Antonio...";
			link.l1.go = "exit";
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "5");
			pchar.questTemp.State = "DelivLettTortuga_NotFoundLetter";
            Pchar.quest.DelivLettTortuga_AttackBrig.win_condition.l1 = "location";
            Pchar.quest.DelivLettTortuga_AttackBrig.win_condition.l1.location = "PuertoRico";
            Pchar.quest.DelivLettTortuga_AttackBrig.win_condition = "DelivLettTortuga_AttackBrig";
            SetTimerCondition("DelivLettTortuga_BrigTimeOver", 0, 0, 5, false);
		break;
//************************************* Испанская линейка, квест №6, перехват вестового *******************************
		case "Step_S6_1":
            dialog.text = NPCStringReactionRepeat("Hum, je vois. Mais quel rapport avec moi ? Je ne fais pas de commerce...",
                          "Oui, oui, je suis déjà au courant...", "Quoi ? Encore vous ?", "Eh bien, combien de fois faudra-t-il ? Vous m'avez montré votre papier...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je le sais. J'ai une demande d'une autre nature... Le fait est que j'ai presque terminé ici les affaires pour lesquelles je suis venu. Ensuite, je dois me rendre à Willemstad, sur l'île de Curaçao. J'aimerais donc le faire sur un navire en partance. Pourriez-vous me dire s'il y a dans votre port des navires assez rapides en partance pour Curaçao ?",
                     "Ah, bon...", "Oui, je...", "Ah oui ? Très bien...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_S6_2", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;
 		case "Step_S6_2":
            dialog.text = "Hum, pas encore. Mais je suppose qu'il en viendra bientכt : les Hollandais de Willemstad viennent ici assez souvent.";
			link.l1 = "Des marchands ?";
			link.l1.go = "Step_S6_3";
		break;
 		case "Step_S6_3":
            dialog.text = "Il y a des marchands, mais je vous conseillerais d'attendre le navire qui amène un messager de Curaçao. Ils ne restent jamais longtemps ici : une heure ou deux à la résidence de notre gouverneur général, et aussitכt retour à Willemstad. Et pendant ce temps, notre gouverneur général ne reçoit personne...";
			link.l1 = "Oh, c'est parfait, ça me convient tout à fait. Auriez-vous l'amabilité de me prévenir quand un tel navire entrera dans le port de Tortuga ?";
			link.l1.go = "Step_S6_4";
		break;
 		case "Step_S6_4":
            dialog.text = "D'accord. Oם logez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "J'ai loué une chambre à la taverne.";
			link.l1.go = "Step_S6_5";
		break;
 		case "Step_S6_5":
            dialog.text = "Bien. Dès que le navire hollandais mouillera dans notre port, j'enverrai immédiatement un messager à votre taverne pour vous prévenir.";
			link.l1 = "Très bien. Merci beaucoup, monsieur. Vous avez rendu service à notre compagnie, nous ne l'oublierons pas.";
			link.l1.go = "exit";
            AddQuestRecord("Spa_Line_6_TakeMessangeer", "2");
            pchar.questTemp.State = "Sp6TakeMess_waitMessanger";
            if (CheckAttribute(pchar, "questTemp.State.Sp6Ok"))
            {
                SetTimerCondition("Sp6TakeMess_waitingBoy", 0, 0, rand(7)+1, false);
                DeleteAttribute(pchar, "questTemp.State.Sp6Ok");
            }
            else
            {
                pchar.questTemp.State.Sp6Ok = 1;
            }
		break;
 		case "Step_S6_6":
            dialog.text = "Non, pas encore. Je vous ai dit que j'enverrais un messager. Ne vous inquiétez pas, je ne vous oublie pas.";
			link.l1 = "Merci, monsieur. Et pardonnez-moi d'être si importun...";
			link.l1.go = "exit";
		break;
//************************************* Французская линейка, квест №4, Солей Руаяль *******************************
 		case "Step_F4_1":
    		if (GetCompanionQuantity(pchar) == 1)
            {
                dialog.text = "Oui, j'ai déjà été prévenu, "+ GetSexPhrase("monsieur", "mademoiselle") +". Prenez le commandement. א vrai dire, commander un tel navire serait un bonheur même pour un amiral...";
    			link.l1 = "Je suis tout à fait d'accord, monsieur... Et maintenant, permettez-moi de prendre congé : les affaires...";
    			link.l1.go = "Step_F4_2";
            }
            else
            {
                dialog.text = "Vous devez vous séparer des navires supplémentaires de votre escadre. Ensuite, vous pourrez prendre toutes les mesures que vous jugerez nécessaires, mais au moment du transfert du navire, vous devez être libre de tout autre engagement.";
    			link.l1 = "D'accord, je vais le faire.";
    			link.l1.go = "exit";
            }
		break;
 		case "Step_F4_2":
    		pchar.questTemp.State = "Fr4SoleiRoyal_toBasTer";
			SaveCurrentQuestDateParam("questTemp");
			AddQuestRecord("Fra_Line_4_SoleiRoyal", "2");
			ref sld = GetCharacter(NPC_GenerateCharacter("SoleiRoyalCaptain", "off_fra_2", "man", "man", 35, FRANCE, -1, true));
			sld.Ship.Name = "Soleil Royal";
			sld.Ship.Type = CreateBaseShip(SHIP_SOLEYRU);
			ResetShipCannonsDamages(sld);
			SetBaseShipData(sld);
			SetCrewQuantityFull(sld);
			Fantom_SetBalls(sld, "pirate");
			FantomMakeCoolFighter(sld, 35, 80, 70, BLADE_LONG, "pistol3", 100);

			sld.CompanionEnemyEnable = false;
			sld.Abordage.Enable = false; // НЕЛЬЗЯ!
			SetCompanionIndex(pchar, -1, sti(sld.index));
			SetShipRemovable(sld, false);

            Pchar.quest.Fr4SoleiRoyal_Fight.win_condition.l1 = "location";
            Pchar.quest.Fr4SoleiRoyal_Fight.win_condition.l1.location = "Dominica";
            Pchar.quest.Fr4SoleiRoyal_Fight.win_condition = "Fr4SoleiRoyal_Fight";
			DialogExit();
		break;

		case "Tortuga_ratP_1":
			dialog.text = NPCStringReactionRepeat("Hum... Je dois vous décevoir. La corvette '" + pchar.questTemp.Slavetrader.ShipName + "' n'est pas entrée dans notre port, et François Gontier ne s'est pas enregistré.", "Vous m'avez déjà posé la question à ce sujet, je vous ai répondu.", "Vous m'avez déjà posé la question au sujet de ce Gontier, je vous ai répondu.", "Je vous dis que vous me l'avez déjà demandé ! Je vous prie de ne pas me déranger dans mon travail !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("דa alors... Et oם est-il allé ? Bon, je vais me renseigner en ville.", "Hum, eh bien...", "Oui, c'est vrai, je l'ai demandé...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

