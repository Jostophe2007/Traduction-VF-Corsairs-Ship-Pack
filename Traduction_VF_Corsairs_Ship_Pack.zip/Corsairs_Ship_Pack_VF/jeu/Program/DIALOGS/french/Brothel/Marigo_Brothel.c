// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("jeune homme", "jeune demoiselle") +" ?", "Que voulez-vous, "+ GetSexPhrase("beau gosse", "ma jolie") +" ?"), "Encore des questions ?", "Hi hi, la troisième fois aujourd'hui, toujours la même chose : des questions...",
                          ""+ GetSexPhrase("Hum, vous ne voudriez pas vous choisir une beauté ? Parce que sinon, je commence à me faire une idée bien précise de vous...", "Hum, vous voulez peut-être vous choisir une beauté ? Nous n'avons pas de garçons, hi hi...") +"", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Hum, rien..."), "Non...",
                      "Ouais, c'est vraiment la troisième fois... Désolé.", "Pas maintenant... Une autre fois...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Анжелика Тич: Портниха знатной дамы
			if(CheckAttribute(pchar, "questTemp.AT_PZD_Bordel"))
			{
				DeleteAttribute(pchar, "questTemp.AT_PZD_Bordel")
				link.l1 = "Je viens vous voir avec une offre quelque peu inhabituelle. Pourriez-vous me vendre la plus belle robe de votre garde-robe ?";
				link.l1.go = "AT_PZD_Bordel_1";
				break;
			}
			if(CheckAttribute(pchar, "questTemp.AT_PZD_Bordel_2"))
			{
				DeleteAttribute(pchar, "questTemp.AT_PZD_Bordel_2")
				link.l1 = "Je reviens pour la robe.";
				link.l1.go = "AT_PZD_Bordel_6";
				break;
			}
			// <== Анжелика Тич: Портниха знатной дамы
			if (pchar.questTemp.Sharp == "seekSharp" && GetNpcQuestPastDayWOInit(npchar, "quest.SharpTime") > 7 && !LAi_IsDead(&characters[GetCharacterIndex("Sharp")]))
			{
				link.l1 = "וcoutez, " + npchar.name + ", je cherche Sharp. Vous savez oם il est ?";
				link.l1.go = "SharpPearl_1";
				SaveCurrentNpcQuestDateParam(npchar, "quest.SharpTime");
			}
		break;
		
		//============ Анжелика Тич: Портниха знатной дамы
		case "AT_PZD_Bordel_1":
    		dialog.text = "Vraiment inhabituelle. Je crains qu'un tel service ne vous coמte une fortune.";
    		link.l1 = "On pourrait peut-être la louer pour une soirée ou deux ?";
    		link.l1.go = "AT_PZD_Bordel_2";
 		break;
		case "AT_PZD_Bordel_2":
    		dialog.text = "Cela peut peut-être s'arranger. Disons 15 000 piastres, et la garantie qu'elle sera rendue à temps, saine et sauve.";
			link.l1 = "Sans la moindre tache... Et puisque nous nous sommes mises d'accord sur le prix, vous pourriez peut-être aussi me trouver un masque de carnaval adapté, qui couvre tout le visage ?";
    		link.l1.go = "AT_PZD_Bordel_3";
 		break;
		case "AT_PZD_Bordel_3":
    		dialog.text = "On va trouver quelque chose. Cinquante mille, et il est à vous.";
			link.l1 = "Quoi ?! Vous ne vous êtes pas trompée de prix, par hasard ?";
    		link.l1.go = "AT_PZD_Bordel_4";
 		break;
		case "AT_PZD_Bordel_4":
    		dialog.text = "Je suis sמre qu'il y a eu un simple malentendu entre nous. Vous m'avez sans doute prise pour une sotte incapable de comprendre que vous comptez entrer incognito dans la résidence d'ici. Cinquante mille pour mon silence, quinze mille pour la robe d'un soir, et le masque, je vous l'offre. Alors, qu'en dites-vous ?";
			if (sti(pchar.Money) >= 65000)
			{
				link.l1 = "Vous savez faire des affaires. Je ne semble pas avoir le choix. Voici votre argent. J'espère que le modèle ne me décevra pas.";
				link.l1.go = "AT_PZD_Bordel_5";
			}
			link.l2 = "Bon, je vais y réfléchir, et je reviendrai peut-être plus tard.";
    		link.l2.go = "AT_PZD_Bordel_4_1";
 		break;
		case "AT_PZD_Bordel_4_1":
    		DialogExit();
			pchar.questTemp.AT_PZD_Bordel_2 = true;
 		break;
		case "AT_PZD_Bordel_6":
    		dialog.text = "Alors, notre marché se fait ? (65 000)";
			if (sti(pchar.Money) >= 65000)
			{
				link.l1 = "Voici votre argent. J'espère que le modèle ne me décevra pas.";
				link.l1.go = "AT_PZD_Bordel_5";
			}
			link.l2 = "Je me demande encore si votre offre en vaut la peine.";
    		link.l2.go = "AT_PZD_Bordel_4_1";
 		break;		
		case "AT_PZD_Bordel_5":
			LAi_Fade("", "");
			Log_info("Vous portez un costume de carnaval");
			AddMoneyToCharacter(pchar, -65000);
			//PlaySound("Interface\important_item.wav");
			GiveItem2Character(PChar, "AT_PZD_KarnavalKostum");
    		dialog.text = "Serrez encore un peu ici, et je serai presque satisfaite du résultat. Dommage, Angelica, que vous n'ayez pas porté de corset dans votre jeunesse, il vous irait bien mieux. Votre taille trahit encore la roturière.";
			link.l1 = "Les soldats n'y feront pas attention, et après, je me débrouillerai.";
    		link.l1.go = "AT_PZD_Bordel_8";
 		break;
		case "AT_PZD_Bordel_8":
    		dialog.text = "Non, ce n'est pas mal, pas mal du tout. Je crois que j'ai même changé d'avis : vous n'avez pas besoin de me rendre la tenue, considérez-la comme achetée.";
			link.l1 = "Ce marché me plaît bien davantage. Je ne refuserai pas. Voilà, je dois me dépêcher, sinon je serai en retard !";
    		link.l1.go = "AT_PZD_Bordel_9";
 		break;
		case "AT_PZD_Bordel_9":
    		DialogExit();
			
			SetCurrentTime(22, 1);
			DoQuestReloadToLocation("Marigo_town", "goto", "goto19", "AT_PZD_IdemNaKarnaval");
 		break;
		
		// капитан Шарп, грабёж жемчужных промыслов
		case "SharpPearl_1":
			if (drand(1) || bBettaTestMode)
			{
				if (sti(pchar.questTemp.Sharp.brothelChance) < 9)
				{	//футболим геймера в город
					pchar.questTemp.Sharp.City = GetSharpCity();
					pchar.questTemp.Sharp.City.rumour = true; //флаг дачи слуха
					dialog.text = "א ma connaissance, le capitaine Sharp est parti pour " + XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc") + ".";
					link.l1 = "Hé ! Merci, " + npchar.name + ". Vous m'avez beaucoup aidé !";
					link.l1.go = "exit";
					pchar.questTemp.Sharp = "toSharp_going"; //в бордели больше не заходить
					pchar.questTemp.Sharp.count = 0; //счетчик нулим для след. раза
					pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
					pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
					ReOpenQuestHeader("SharpPearl");
					AddQuestRecord("SharpPearl", "1");
					AddQuestUserData("SharpPearl", "sCity", XI_ConvertString("Colony" + npchar.city + "Voc"));
					AddQuestUserData("SharpPearl", "sTarget", XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc"));
					if (GetIslandByCityName(pchar.questTemp.Sharp.City) != pchar.questTemp.Sharp.City)
					{
						AddQuestUserData("SharpPearl", "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(pchar.questTemp.Sharp.City) + "Voc"));
					}
					//запускаем энкаунтер Шарпа на карте
					group_DeleteGroup("Sharp_Group");
					sld = characterFromId("Sharp");
					string sGroup = "Sharp_Group";
					Group_FindOrCreateGroup(sGroup);
					Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
					Group_LockTask(sGroup);
					Group_AddCharacter(sGroup, sld.id);
					Group_SetGroupCommander(sGroup, sld.id);
					sld.mapEnc.type = "trade";
					sld.mapEnc.worldMapShip = "quest_ship";
					sld.mapEnc.Name = "Brick 'Sharp Bearer'";
					string sColony= SelectAnyColony(npchar.city); //колония, откуда плывёт Шарп
					int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sColony), GetArealByCityName(pchar.questTemp.Sharp.City)) + 1; //дней доехать даём с запасом
					Map_CreateTrader(sColony, pchar.questTemp.Sharp.City, sld.id, daysQty);
					Log_TestInfo("The sharp-bearer is installed from  " + sColony + " in " + pchar.questTemp.Sharp.City);
				}
				else
				{	//чудо, Шарп здесь, в борделе!
					dialog.text = "Je sais. Il se repose chez moi. Je peux appeler Sharp, si vous en avez besoin d'urgence.";
					link.l1 = "Rendez-moi ce service, " + npchar.name + "...";
					link.l1.go = "SharpPearl_2";
				}
			}
			else
			{
				dialog.text = "Je ne sais pas, il n'est pas venu depuis longtemps.";
				link.l1 = "Compris... Eh bien, merci, " + npchar.name + ".";
				link.l1.go = "exit";
			}
		break;
		case "SharpPearl_2":
			dialog.text = "Mon petit Bartholomew ! Viens ici, mon chou, quelqu'un te demande !";
			link.l1 = "Hé, vous tenez Sharp en haute estime, à ce que je vois...";
			link.l1.go = "SharpPearl_3";
		break;
		case "SharpPearl_3":
			chrDisableReloadToLocation = true;
			pchar.questTemp.Sharp.count = 0; //счётчик нулим для след. раза
			pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
			pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
			sld = &characters[GetCharacterIndex("Sharp")];
			sld.dialog.currentnode = "BrothelSharp";
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER_OWN);
			ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorDialog(sld, pchar, "", -1, 0);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

