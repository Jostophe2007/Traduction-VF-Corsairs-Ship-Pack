#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			//если Сесил Галард замочили, то это оставшийся шанс узнать о Механике
			if (pchar.questTemp.LSC == "SessilIsDead")
			{
				dialog.text = "Dites-moi, est-ce vrai que vous avez essayé de sauver Cecil Galard ?";
				link.l1 = "Oui, c'est vrai. Malheureusement, ça n'a pas marché...";
				link.l1.go = "SessilDead";
				npchar.quest.meeting = "1";
				break;
			}

			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					if (npchar.location == "FurieShipInside2") dialog.text = "Mon Dieu, quelle tempête !.. Bonjour, je m'appelle " + GetFullName(npchar) + ", je suis la propriétaire de cette maison.";
					else dialog.text = "Seigneur, quelle tempête !.. Bonjour, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "C'est un plaisir. Et moi, je suis le capitaine " + GetFullName(pchar) + ". Ou plutכt, ancien capitaine. Et tout ça à cause de cette tempête du diable !";
					link.l1.go = "FS_1";
				}
				else
				{
					if (npchar.location == "FurieShipInside2") dialog.text = "Bonjour, je m'appelle " + GetFullName(npchar) + ", je suis la propriétaire de cette maison.";
					else dialog.text = "Bonjour, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "C'est un plaisir. Et moi, je suis le capitaine " + GetFullName(pchar) + ". Ou plutכt, ancien capitaine...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que voulez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de venir avec moi sur le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "FS_1":
			dialog.text = "Ne parlez pas du Malin, sinon il va apparaître ! Et puisque vous êtes chez moi, je vous prie de ne pas jurer !";
			link.l1 = "Oh, pardonnez-moi...";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Allons, ne vous en faites pas tant. Après tout, vous êtes en vie, et c'est déjà très bien !";
			link.l1 = "Oui, vous avez raison. Je vous prie d'excuser ce moment de faiblesse"+ GetSexPhrase(", indigne d'un homme", "") +"...";
			link.l1.go = "exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez " + GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Je serai heureuse de vous aider si je le peux, bien sמr. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pense à quelqu'un d'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrées.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Depuis combien de temps êtes-vous ici ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Le pays natal ne vous manque pas ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l3 = "Dites-moi, êtes-vous arrivée ici avant Hill Brunner ?";
				link.l3.go = "ansewer_3";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Moi personnellement... Hum, je ne m'en souviens plus. Mais si vous vous demandez depuis combien de temps cette Cité se trouve ici, alors... depuis longtemps. Très longtemps.";
			link.l1 = "Je vois.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Mon pays natal ? Bien sמr que si... Mais il faut se faire aux circonstances. L'être humain sait s'adapter, et c'est ce qu'on attend de nous.";
			link.l1 = "Je n'en ai pas envie.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "Non, il tenait déjà la taverne d'ici.";
			link.l1 = "Compris... Dites-moi, le nom ou le surnom de Mécanicien vous dit-il quelque chose ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Hum... Je ne m'en souviens pas, je suis désolée. Vous savez, je suis un peu occupée en ce moment et je ne souhaite pas poursuivre cette conversation. Excusez-moi.";
			link.l1 = "Compris. Eh bien, merci.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "30");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;

		case "SessilDead":
			dialog.text = "Cecil était la plus ancienne habitante de la Cité... Savez-vous pourquoi on l'a tuée ?";
			link.l1 = "Non, mais comme Hill Brunner, je cherchais une personne qui pourrait répondre à ma question. Elle aurait sans doute pu.";
			link.l1.go = "SessilDead_1";
		break;
		case "SessilDead_1":
			dialog.text = "Et quelle est cette question ?";
			link.l1 = "Qui est le Mécanicien ?";
			link.l1.go = "SessilDead_2";
		break;
		case "SessilDead_2":
			dialog.text = "Je sais qui c'est. Je ne voulais pas en parler avant, parce que je pensais que de telles conversations étaient dangereuses. Mais la mort de Cecil m'a fait changer d'avis...";
			link.l1 = "Parlez, je vous écoute attentivement.";
			link.l1.go = "SessilDead_3";
		break;
		case "SessilDead_3":
			dialog.text = "Le Mécanicien s'appelle Henrik Wedeker. La plupart des citoyens de la Cité ne savent même pas qu'il vit parmi nous. Je n'ai plus vu le Mécanicien depuis que le clan des Caspers s'est installé sur la barque San Gabriel.";
			link.l1 = "Vous aussi, vous vivez dans la Cité depuis longtemps ?";
			link.l1.go = "SessilDead_4";
		break;
		case "SessilDead_4":
			dialog.text = "Pas depuis aussi longtemps que Cecil, mais depuis longtemps tout de même. J'ai vu le Mécanicien...";
			link.l1 = "Donc, vous dites que cet Henrik est sur la barque San Gabriel ?";
			link.l1.go = "SessilDead_5";
		break;
		case "SessilDead_5":
			dialog.text = "Oui. Je pense que l'amiral tient délibérément Henrik à l'écart, c'est pourquoi il a donné la barque San Gabriel au clan des Caspers. Le fait est que le Mécanicien est une personne extraordinairement douée. Quand il faut fabriquer quelque chose, il n'a pas d'égal. א une époque, il s'est mis à parler d'un danger qui nous menaçait tous. Il disait que nous devions quitter la Cité avant qu'il ne soit trop tard\n"+
				"Mais vous savez, on ne prend pas les excentriques au sérieux, alors on n'a fait que rire de ses histoires. Et puis est arrivée la Loi interdisant la construction d'embarcations, et aussitכt, les Caspers ont occupé le San Gabriel. Bref, il est devenu malvenu de parler de notre excentrique, et dangereux aussi.";
			link.l1 = "Vous êtes sמre qu'Henrik est toujours en vie ?";
			link.l1.go = "SessilDead_6";
		break;
		case "SessilDead_6":
			dialog.text = "J'en suis sמre. Le fait est qu'Henrik a inventé un moyen d'attacher les navires à l'île, et l'amiral en a besoin. Sinon, il n'y aura personne pour réparer la Cité des navires abandonnés.";
			link.l1 = "Voilà donc ce qu'il en est !.. Eh bien, merci beaucoup, Aurelie. Je crois qu'il faut que j'aille voir le Mécanicien pour lui parler.";
			link.l1.go = "SessilDead_7";
		break;
		case "SessilDead_7":
			dialog.text = "Eh bien, essayez. Je vous souhaite bonne chance.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toSeekMechanik";
			AddQuestRecord("ISS_MainLine", "32");
			pchar.quest.LSC_enterCasper.win_condition.l1 = "location";
			pchar.quest.LSC_enterCasper.win_condition.l1.location = "SanGabrielMechanic";
			pchar.quest.LSC_enterCasper.function = "LSC_enterCasper";
			sld = characterFromID("Casper_head");
			LAi_SetImmortal(sld, false);
			for (int i=1; i<=11; i++)
			{
				sld = characterFromID("Casper_"+i);
				LAi_SetImmortal(sld, false);
			}
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Que cherchez-vous exactement ?",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je cherche des boulets, des bombes, de la mitraille, des boulets ramés, des vivres, des médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Je peux vous aider pour les boulets ramés, même si je ne comprends pas pourquoi vous avez besoin de ce genre de choses.";
			link.l1 = "Moi, je le comprends. Vous savez, 100 de ces machins suffiront.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Très bien, vous pouvez les prendre.";
			link.l1 = "Bon sang, je ne pourrai jamais tout porter ! Pouvez-vous me dire qui pourrait se charger de la livraison jusqu'à la barque San Gabriel ?";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Demandez à Pablo Barades de ma part. Il doit vous aider.";
			link.l1 = "D'accord, je n'y manquerai pas. Merci !";
			link.l1.go = "exit";
			pchar.questTemp.LSC.additional.knippels = true;
			AddQuestRecord("ISS_MainLine", "51");
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Vraiment ? Intéressant... Vous avez vraiment un navire ?";
			link.l1 = "Oui.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Et il est en bon état ? Nous atteindrons le continent ?";
			link.l1 = "Absolument.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Alors, j'accepte.";
			link.l1 = "Bien. Allez au San Gabriel au plus vite. Henrik Wedeker vous emmènera sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Je vous ai compris. Je ferai tout comme vous l'avez dit.";
			link.l1 = "Je vous en prie, dépêchez-vous...";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
