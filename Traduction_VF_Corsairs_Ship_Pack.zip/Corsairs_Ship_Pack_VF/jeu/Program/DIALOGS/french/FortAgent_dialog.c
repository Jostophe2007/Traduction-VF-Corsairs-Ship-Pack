// Deck parley with the enemy-nation courier-agent (commandant convoy interception at sea).
// The encounter is created in Treasure.c (FortAgentOnMap); outcome logic is there too (FortAgent_HandOver/StartDeliver).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iBase = sti(pchar.CargoQuest.iMoney);

	switch (Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "First time":
			// сделка уже заключена ранее - предложений больше нет (фантом мог пересоздаться и потерять DontDeskTalk)
			if (CheckAttribute(pchar, "FortAgentResolved"))
			{
				dialog.text = "C'est dit, capitaine. Nous n'avons plus rien à nous dire.";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "exit";
				NextDiag.TempNode = "First time";
				break;
			}
			dialog.text = "Rengainez votre lame, capitaine, je viens pour parler, pas pour me battre. Je suis un homme de confiance au service de " + NationNameGenitive(sti(NPChar.nation)) + ", et la Couronne a des yeux et des oreilles partout. D'après nos renseignements, les cales de votre convoi transportent une cargaison de munitions destinée à un fort dont la nation est notre ennemie. Une telle cargaison n'a rien à faire dans l'arsenal de nos ennemis. Voici votre choix : livrez les navires du convoi à mes hommes, et je vous paierai le double de ce que la guilde vous a promis ; ou bien livrez vous-même la cargaison à notre fort, et l'on vous paiera cinq fois plus. Refusez, et nous réglerons ça en pleine mer.";
			link.l1 = "D'accord. Prenez le convoi. (" + FindRussianMoneyString(iBase * 2) + ")";
			link.l1.go = "FortAgent_Hand";
			link.l2 = "J'apporterai moi-même la cargaison à votre fort. (" + FindRussianMoneyString(iBase * 5) + ")";
			link.l2.go = "FortAgent_Deliver";
			link.l3 = "Je livre cette cargaison à son destinataire. וcartez-vous de mon chemin.";
			link.l3.go = "FortAgent_Refuse";
			NextDiag.TempNode = "First time";
		break;

		case "FortAgent_Hand":
			// convoy hand-off + agent departure happen ON DIALOG EXIT (otherwise softlock: despawn during the dialog)
			AddDialogExitQuestFunction("FortAgent_HandOver_OnExit");
			dialog.text = "Sage décision, capitaine. Mes hommes prendront les navires, le reste est notre affaire. Voici votre or, le double de ce que la guilde avait promis. Nos chemins se séparent, et oublions-nous l'un l'autre.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;

		case "FortAgent_Deliver":
			FortAgent_StartDeliver(NPChar);                          // deal/deadline/city now (needed for the text)
			AddDialogExitQuestFunction("FortAgent_Depart_OnExit");   // agent leaves ON EXIT (otherwise softlock)
			dialog.text = "Marché conclu, capitaine. Conduisez le convoi au fort de " + XI_ConvertString("Colony" + pchar.FortAgentDeliver.city + "Gen") + ". Tenez, prenez mon pavillon de reconnaissance et hissez-le en tête de mât : sous ce pavillon, les batteries cכtières comme la garde de la ville vous prendront pour l'un des nכtres, chargé d'une cargaison vitale pour la garnison, et ne lèveront pas le petit doigt contre vous. Son commandant attend les munitions et vous paiera cinq fois le prix de la guilde pour les lui livrer. Vous avez " + FindRussianDaysString(sti(pchar.FortAgentDeliver.days)) + " à compter de maintenant ; une marchandise en retard ne nous intéressera plus.";
			link.l1 = "La cargaison atteindra le fort.";
			link.l1.go = "exit";
		break;

		case "FortAgent_Refuse":
			dialog.text = "Dommage. Nous n'avons donc pas pu nous entendre. Alors, nous parlerons une autre langue, en pleine mer. Mettez à la voile, capitaine, et priez votre dieu.";
			link.l1 = "On verra bien à qui sourira la journée.";
			link.l1.go = "exit";
			// hostility goes on the REAL agent ON EXIT (the deck speaker may be a clone - hence "couldn't attack")
			AddDialogExitQuestFunction("FortAgent_Refuse_OnExit");
		break;
	}
}
