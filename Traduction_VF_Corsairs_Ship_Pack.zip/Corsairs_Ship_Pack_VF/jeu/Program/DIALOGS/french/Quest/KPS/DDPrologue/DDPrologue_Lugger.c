// Gregg: Tommi Fatman and his crew - alternative prologue "Desert Island"
// (ported from Damned Destiny). One file for three: Tommi (nodes 1-6),
// Walter Korten (7-13) and Johny Norton (14).
// Logic - Program\Quests\reaction_functions\ddprologue.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Adressez toutes vos questions au capitaine.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Salutations ! Je suis le capitaine Tommi Fatman. Que voulez-vous ?";
			link.l1 = "Capitaine " + GetFullName(PChar) + ". וcoute, Tommi, j'ai une affaire à te proposer, et tu peux m'aider.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Et de quelle affaire s'agit-il ?";
			link.l1 = "Nous voulons rejoindre le port anglais ou français le plus proche.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je veux bien vous emmener à la Martinique. דa vous va ?";
			link.l1 = "Parfait, ça nous convient.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Combien ? Annoncez votre somme.";
			link.l1 = "Mille cinq cents d'avance, et encore mille cinq cents à l'arrivée à la Martinique.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Marché conclu ! Donnez l'avance.";
			link.l1 = "Tiens, mille cinq cents, comme convenu. Quand pouvons-nous monter à bord ?";
			link.l1.go = "6";
		break;

		// Gregg: the money is taken here, and that is correct - the player already handed
		// it over with the reply in node 5
		case "6":
			AddMoneyToCharacter(PChar, -1500);
			dialog.text = "...(il rit)... Voilà le problème, capitaine Poisse : vous ne monterez pas à bord de sitכt, si jamais vous y montez avant de crever sur cette île. Ha ! Vous croyiez vraiment que j'allais vous emmener à la Martinique, pauvre naïf ? Fichez le camp tant que vous tenez à la vie, je suis encore de bonne humeur.";
			link.l1 = "Tu croyais me rouler, Fatman ? Oh non, je ne laisserai plus personne se moquer de moi. Défends-toi !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameLuggerCapBattle");
		break;

		case "7":
			dialog.text = "C'est vous qui nous commandez, maintenant, capitaine " + PChar.lastname + ".";
			link.l1 = "Je regrette d'avoir dמ tuer votre capitaine, mais il m'a trompé, et il l'a payé de sa vie.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Nous avons vu ce qui s'est passé, capitaine " + PChar.lastname + ", et nous sommes entièrement de votre cכté. Pour être honnêtes, nous vous sommes reconnaissants d'avoir tué ce bon à rien. Nous voulions depuis longtemps nous mutiner et élire un nouveau capitaine.";
			link.l1 = "...(sourit)... Alors je suis arrivé juste à temps.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "En quelque sorte, capitaine. Mais notre navire est en piteux état. Cet idiot s'est attaqué à un galion.";
			link.l1 = "Un lougre contre un galion ? Il avait toute sa tête ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "C'est bien ce que je dis. La première bordée du galion lui a remis les idées en place, nous avons viré de bord et nous avons fui le champ de bataille. Nous avons eu de la chance de semer nos poursuivants.";
			link.l1 = "Et pourquoi avez-vous jeté l'ancre au large de cette île ? Pour vous ravitailler ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "C'est ici que nous comptions achever ce salaud. Si vous étiez arrivé cinq minutes plus tard, nous aurions réglé son compte à Fatman nous-mêmes.";
			link.l1 = "Je vois. Bon, il n'y a pas de temps pour les discussions, il est temps de lever l'ancre et de filer d'ici.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Capitaine, nous avons une petite cargaison de cacao dans la cale, que nous transportons à la Barbade pour un certain Richard Tillman. Je suppose que vous reprenez l'engagement de l'ancien capitaine de livrer la cargaison ?";
			link.l1 = "Certainement. Cap sur la Barbade.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameHappyEnd");
		break;

		case "14":
			dialog.text = "א vos ordres, capitaine ?";
			link.l1 = "Repos.";
			link.l1.go = "exit";
			NextDiag.TempNode = "14";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
