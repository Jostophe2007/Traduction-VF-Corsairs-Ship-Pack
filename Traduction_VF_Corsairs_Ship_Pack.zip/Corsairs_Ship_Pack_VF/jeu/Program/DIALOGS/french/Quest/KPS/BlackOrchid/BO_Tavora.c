// Gregg: Jeronimo Tavora, inquisitor of Santiago - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: three exchanges: finding Raul, the Gospel and the cane. Split by state.
			// Gregg: a third exchange - for Esperanto cane
			// Gregg: не по состоянию "11" - оно ставится, когда Тавора согласился, то есть
			// ещё до спуска в подвал. Метку ставит сам Рауль, когда просит трость.
			if (CheckAttribute(PChar, "RaulEsperanto.Stick"))
			{
				dialog.text = "Il est toujours là ?";
				link.l1 = "Il ne peut pas marcher. On lui a pris sa canne lors de son arrestation.";
				link.l1.go = "30";
			}
			else
			{
			if (PChar.RaulEsperanto == "10")
			{
				dialog.text = "Vous êtes revenu plus tכt que je ne l'avais calculé.";
				link.l1 = "J'ai apporté ce que vous m'avez demandé.";
				link.l1.go = "1";
			}
			else
			{
			// Gregg: strictly by state. The else here was a hole: after the talk the state moves
			// to "7" and the branch played again, hanging the same journal record every time.
			if (PChar.RaulEsperanto == "6")
			{
				dialog.text = "La paix soit avec vous. Vous avez affaire ici, ou vous vous êtes perdu ?";
				link.l1 = "J'ai affaire. Il y a un vieil homme dans votre prison, Raul Esperanto.";
				link.l1.go = "20";
			}
			else
			{
				dialog.text = "La paix soit avec vous. J'ai mes devoirs, et vous, je suppose, avez les vכtres.";
				link.l1 = "Je ne vous retiendrai pas.";
				link.l1.go = "exit";
			}
			}
			}
			NextDiag.TempNode = "First time";
		break;

		case "20":
			dialog.text = "Il y en a un. L'Espagnol. Des expériences, de la poudre de momie, des lettres à un homme de la Guadeloupe que nous connaissons. Que lui voulez-vous ?";
			link.l1 = "Je le veux vivant, et dehors.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "...(sans surprise)... Tout le monde veut quelque chose. Moi aussi. Seulement, je ne peux pas le laisser partir : il n'est pas inscrit sous mon autorité.";
			link.l1 = "Alors qui donne les ordres ici, si ce n'est pas vous ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "א Santiago, c'est moi. Mais Esperanto est inscrit dans les registres du tribunal qui vient d'Europe, et le grand inquisiteur va débarquer d'un jour à l'autre. Si je relâche le vieillard moi-même, c'est à lui que je devrai en répondre.";
			link.l1 = "Et si je vous donnais une raison ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Une raison, c'est exactement ce qu'il me faut. א Saint-Martin vit un banquier du nom de Jan Beausing. Depuis douze ans, il garde une chose qui ne lui appartient pas.";
			link.l1 = "Quelle chose ?";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Un livre. Vous n'avez pas besoin d'en savoir plus, et je n'en dormirai que mieux. Amenez-moi Beausing, ou mieux encore le livre, et le vieillard sortira le jour même.";
			link.l1 = "Saint-Martin. Marigot. Compris.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoFindBeausing");
		break;

		case "1":
			dialog.text = "Je vous écoute.";
			link.l1 = "Jan Beausing. Je sais oם il est et ce qu'il gardait.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(il pose lentement sa plume)... Continuez.";
			link.l1 = "Il est à bord de mon navire. Et voici ce pour quoi vous le traquiez.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(il prend le livre, l'ouvre au milieu, lit quelques lignes, le referme)... C'est bien lui. Douze ans.";
			link.l1 = "Alors vous n'avez plus besoin de Beausing ?";
			link.l1.go = "4";
			TakeNItems(PChar, "RaulEsperanto_Evangelie", -1);
		break;

		case "4":
			dialog.text = "On n'avait besoin de Beausing que tant que le livre était chez lui. Le livre est ici. Il ne doit donc plus rien à personne.";
			link.l1 = "Alors je vais le ramener chez lui.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Ramenez-le. Et fixez votre prix, capitaine. Je n'aime pas avoir des dettes : une dette lie plus fort qu'un contrat.";
			link.l1 = "Il y a un vieil homme dans votre prison. Raul Esperanto.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "...(il vous regarde longuement)... L'Espagnol. Des expériences, de la poudre de momie, des lettres à un homme de la Guadeloupe que nous connaissons.";
			link.l1 = "Je le veux vivant, et dehors.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "J'avais besoin de lui pour avoir au moins quelque chose à présenter au tribunal. Maintenant, j'ai de quoi les recevoir, et cela vaut plus que le vieillard.";
			link.l1 = "C'est un oui ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "C'est un oui. Emmenez-le aujourd'hui, avant que je change d'avis et que les papiers partent pour Madrid. Et, capitaine...";
			link.l1 = "Oui ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Ne lui demandez pas ce qu'il a fabriqué pour Andersen. Il y a trente ans, j'ai posé cette question à un homme qui connaissait la réponse, et depuis, je cherche ce livre.";
			link.l1 = "...(se tait)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoTalkWithEsperanto");
		break;

		case "30":
			dialog.text = "Une canne ? ...(il ouvre un tiroir)... Oui, je l'ai. Tout est confisqué lors de l'arrestation, et en général, il ne reste plus personne à qui le rendre.";
			link.l1 = "Aujourd'hui, il y a quelqu'un.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "...(il pose la canne sur le bureau)... Prenez-la. Et dites-lui que je ne l'ai pas cassée. Cela comptera plus pour lui que sa liberté, vous verrez.";
			link.l1 = "Je le lui dirai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoGiveStick");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
