// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.Slavetrader == "FindRatJamaica")
            {
                link.l1 = "Un certain François Gontier est-il passé dans votre ville ? J'ai vraiment besoin de lui.";
                link.l1.go = "Jamaica_ratF_1";
            }
			//виспер
			if(CheckAttribute(pchar, "Whisper.FindDesouzaHol") && !CheckAttribute(npchar, "Whisper.FindDesouzaHol"))
			{
				npchar.Whisper.FindDesouzaHol = true;
				link.l1 = "Dites, des types à l'allure suspecte sont-ils venus vous voir ici ? Ils doivent aussi avoir une marque en forme de crucifix sur le bras.";
				link.l1.go = "FindDesouzaHol";
				break;
			}
			//виспер
			if(CheckAttribute(pchar, "BSUrka_Negril") && !CheckAttribute(npchar, "BSUrka_Negril"))
			{
				npchar.BSUrka_Negril = true;
				link.l1 = "Avez-vous entendu parler du brick qui a coulé près d'ici ? Le « Ranger ».";
				link.l1.go = "BSUrka_Negril";
				break;
			}
		break;

        case "BSUrka_Negril":
            dialog.text = "J'ai bien peur de ne pas pouvoir vous aider. La semaine dernière, j'ai failli rendre l'âme : j'avais attrapé je ne sais quelle saleté avec une catin anglaise. J'ai dמ garder le lit, je n'ai donc pas eu le temps de m'intéresser aux nouvelles du coin. Je viens juste de reprendre le travail aujourd'hui, mais demandez aux clients, quelqu'un aura sמrement vu quelque chose.";
            link.l2 = "C'est ce que je vais faire.";
            link.l2.go = "exit";
        break;

        case "DefenceOrange": //Голландская линейка, квест №4, защита форта Оранж.
            dialog.text = "Oui, je vous le dis, je n'ai jamais vu de ma vie un tel massacre...";
            link.l2 = "Bravo à ces chiens d'Anglais, hein ?";
            link.l2.go = "Step_H4_1";
        break;

        case "Step_H4_1":
			dialog.text = "Que dire, "+ GetSexPhrase("mynheer", "madame") +". Il n'y a pas de meilleur moyen. Merci beaucoup !";
			link.l1 = "Je vous en prie.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Jamaica_ratF_1":
			dialog.text = "Il est venu. Il m'a loué une chambre pour quelques jours. Un type des plus désagréables, je vous le dis. Et en plus, il avait la manie de la persécution : il regardait sans cesse autour de lui et avait peur de tout, comme un paranoïaque. Ce ne serait pas de vous qu'il avait si peur ?";
			link.l1 = "Non, pas de moi. En général, les corsaires ont beaucoup d'ennemis, vous savez. Alors, oם puis-je le trouver ? Nous avions convenu de travailler ensemble, mais il a disparu comme s'il avait été englouti par la terre !";
			link.l1.go = "Jamaica_ratF_2";
		break;

		case "Jamaica_ratF_2":
			dialog.text = "Il a pris la mer sur son navire. Mais je ne sais pas pour aller oם. Il ne m'a rien dit.";
			link.l1 = "Oh, quel dommage ! Oם vais-je le chercher maintenant ?";
			link.l1.go = "Jamaica_ratF_3";
		break;

		case "Jamaica_ratF_3":
			dialog.text = "Je ne sais pas, "+ GetSexPhrase("l'ami", "madame") +". Si je le savais, je vous le dirais.";
			link.l1 = "Bon, tout est clair. Je vais aller demander à quelqu'un d'autre...";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_4");
			pchar.questTemp.Slavetrader = "FindRatJamaica_H";
		break;
		case "FindDesouzaHol":
    		dialog.text = "Non, je ne les ai certainement pas vus ici.";
    		link.l1 = "D'accord, merci.";
			pchar.Whisper.FindDesouzaHolWaitress = true;
    		link.l1.go = "exit";
 		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
