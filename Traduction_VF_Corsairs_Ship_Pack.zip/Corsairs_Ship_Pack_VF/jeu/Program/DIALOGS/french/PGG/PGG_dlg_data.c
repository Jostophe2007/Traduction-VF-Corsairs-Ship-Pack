string PGG_Stories[MAX_PGG_STORIES] = {
	"...seuls le diable et moi connaissons cet endroit, et le dernier vivant emportera tout !..",
	"...et Maynard répondit : 'Je n'attends aucune pitié de ta part, et tu n'en auras pas de la mienne'.",
	"...Les grappins ont mordu la coque ! א vos postes ! Même le diable des mers ne tiendra pas !..",
	"...Dans la main droite, un sabre ! Dans la gauche, un pistolet ! Ensemble, nous en enverrons des centaines dans l'autre monde !..",
	"...On est plaqués contre le mât ! La fumée, c'est l'enfer ! Mieux vaut mourir au combat que d'être pendu au port !",
	"...un jour en mer, un peu éméché, il proposa : 'Créons notre propre enfer ici même, tout de suite, et voyons qui tiendra le plus longtemps'.",
	"...Et voici une histoire amusante, arrivée à un vieil ami à moi à Portobelo. On marchait dans les rues, le soir, du port vers le quartier chaud. Moi, j'étais déjà bien chargé jusqu'au gaillard d'avant, et mon compagnon avait pris un ris dans son hunier, quand deux brigantines sont venues à notre rencontre. Toutes deux parées au combat. Et dès qu'on s'est retrouvés bord à bord, voilà mon ami qui lâche une bordée des deux cכtés ! Ha ha ha ha...",
	"...Ha ha ha !.. Et à Santa Cruz, il y a eu un incident pendant l'amarrage. En criant 'Attention !', mon matelot lance l'attrape et touche un badaud du coin en plein front ! Le gars, boum ! s'effondre sans connaissance. Le matelot, effrayé, sans attendre la passerelle, saute sur le quai et se met à l'arroser avec le bout de l'amarre. Finalement, le gars revient à lui et dit au matelot : 'Quand tu lances l'attrape, il faut crier : Gare à la tête !'. Ha ha ha...",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues"
};

string PGG_QuestStories[MAX_PGG_QUEST_STORIES] = {
	"...Un jour, on s'est retrouvés coincés en Floride, à attendre la fin d'un calme plat. Quand la taverne a été à court de rhum, on a fini au bordel. Et là, bien éméché, j'ai visiblement parlé à une des filles de l'or que je gardais de cכté pour les mauvais jours. Alors imaginez : quand, un mois plus tard, je suis retourné à ma cachette, elle était aussi vide qu'une tête au lendemain d'une beuverie ! Qu'une sardine me morde si cette bavarde n'a pas tout raconté au premier gredin venu ! Alors, les femmes, je ne leur fais pas confiance pour un demi-peso !..\nMais voici qu'un vieux coureur de jupons expérimenté s'approche de notre table. Lui, il a sמrement une façon bien à lui de s'y prendre avec les dames. Ou je me trompe ? Qu'une sardine me morde, ha ha ha !..",
	"...et il lui dit en se moquant : 'Montons à l'étage. Avant de t'engager dans l'équipage, il faut vérifier de quoi tu es capable, comme officier.' Et la fille empoigne un couteau presque aussi grand qu'elle et lui dit : 'D'abord, voyons si tu as l'étoffe d'être mon capitaine !' Ha ha ha... Elle l'a poursuivi dans toute la taverne comme un requin poursuit une morue, et ça aurait été très drכle, messieurs, si elle n'avait pas tué le pauvre bougre en plein milieu de la salle, devant tout le monde. Que le Seigneur ait son âme... Mais depuis, aux Bermudes, je garde l'œil ouvert, au cas oם elle s'y montrerait aussi !\nOh, saluons le digne capitaine, qui trouverait sמrement le moyen de s'entendre avec cette furie ! Ha ha ha ha...",
	"TBD in InitDynamicValues"
}

string PGG_Meet_GoodRep[MAX_PGG_MEET_REP] = {
	"On rencontre rarement un capitaine convenable dans ces mers.",
	"La noblesse n'est plus à la mode de nos jours.",
	"Et voici un capitaine honnête, rien à voir avec vous autres, bandits ! Héhé !",
	"On rencontre rarement un capitaine convenable dans ces parages.",
	"Bon sang, la noblesse n'est plus à la mode de nos jours.",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues"
};

string PGG_Meet_BadRep[MAX_PGG_MEET_REP] = {
	"Voici venir un autre pirate !",
	"דa sent la poudre et le sang, un flibustier par tribord !",
	"Je sens l'odeur de la poudre... Messieurs, un autre glorieux corsaire nous a rejoints, qui aura certainement de quoi raconter à confesse. Ha ha ha",
	"דa sent la poudre et le sang par tribord !",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues",
	"TBD in InitDynamicValues"
};

string PGGQuestID = "Gen_PGGQuest1";
bool isSetSail = false; // флаг того, что поймали ПГГ на море
bool isPGGInitiative = false; // флаг того, что ПГГ сам подошел

void InitDynamicValues(ref NPChar) {
	isSetSail = CheckAttribute(NPChar, "PGGAi.Task.SetSail");
	isPGGInitiative = CheckAttribute(NPChar, "PGGAi.ActiveQuest");
	if (NPChar.sex == "woman") PGGQuestID = "Gen_PGGQuest1" + NPChar.sex;

	PGG_Stories[8] = "... Non, messieurs, tout ça, ce sont des blagues... Mais voici une histoire dont j'ai été non seulement le témoin, mais aussi, d'une certaine façon, un acteur. Un jour, je me rendais à la taverne de Charlestown, tout droit du bassin oם je regardais caréner son vieux Condor, et voilà que le capitaine Sharp en personne sort en titubant de la taverne et vient à ma rencontre ! Il essuie une tempête sans pitié, l'artimon est déjà complètement arraché, et il tente de manœuvrer pour monter les marches avec la seule civadière. א peine lui avais-je proposé mes services de pilote que la rambarde a cédé sous lui !!! Ho ho ho ho...\n",
	PGG_Stories[9] = "... Je ne peux rien dire du Hollandais volant. Ni moi ni aucun de mes marins ne l'avons jamais vu, Dieu merci... Mais il y a eu une affaire non moins mystérieuse. א l'est des Bermudes, nous avons croisé une brigantine toutes voiles dehors, mais qui suivait un cap étrange, une sorte de zigzag. Je n'avais rien prévu de tel, mais j'ai envoyé une chaloupe. Quelle n'a pas été notre surprise : pas une âme à bord !.. Et 1 700 barriques d'excellent vin dans la cale !.. Voilà ce que j'appelle de la chance ! Et sans tirer un seul coup de feu ! Ha ha ha..\n",
  	PGG_Stories[10] = "... Je suis tout de même enclin à penser, messieurs, que toutes ces histoires sur le Hollandais volant ne sont que de vaines inventions de marchands peureux, prêts à voir dans chaque voile à l'horizon un corsaire sanguinaire avec un monstre ivre sur la passerelle, et dans chaque lougre croisé un présage de malheur...\n";
	PGG_Stories[11] = "... Quelqu'un se souvient peut-être de cette fois, au sud de Key West, oם j'ai pris une poutre sur le crâne ? Rien de visible, mais deux mois au lit. " + NPCharSexPhrase(NPChar, "Et ma bien-aimée de l'époque m'a persuadé", "Et mon ami de l'époque m'a persuadée") + " d'aller me confesser. Soi-disant qu'avec l'aide de Dieu, les choses iraient mieux... Bref, j'y vais, et le prêtre me demande : 'As-tu tué beaucoup de gens, " + NPCharSexPhrase(NPChar, "mon fils", "ma fille") + " ? As-tu coulé beaucoup de navires ?' – 'Des ta-a-as !', que je lui réponds. Il ne se calme pas : 'Et des hommes, tu en as tués ?' C'est là que je lui dis : 'Padre, je ne suis pas là pour me vanter !' Ha ha ha...\n";

	// TODO: не подходят по контексту, надо бы заменить для женского ПГГ
	if (NPChar.sex == "woman") {
		PGG_QuestStories[0] = "... Dans ma main droite brille un sabre, dans la gauche luit un pistolet, ensemble nous les enverrons au-delà des rêves terrestres...";
		PGG_QuestStories[1] = "... On est cloués au mât ! La fumée, c'est l'enfer ! Mieux vaut mourir au combat que d'être pendu au port !";
	}
	PGG_QuestStories[2] = "...Je ne sais rien du Hollandais volant lui-même, mais j'ai vu un vaisseau fantכme de mes propres yeux, comme je vous vois, messieurs !.. Cette maudite frégate, noire comme la nuit, a surgi du brouillard et nous a abordés sans tirer un coup ! Je dois l'avouer, j'ai eu une sacrée peur, mais nous avons viré bâbord amures et nous nous préparions à lâcher une bordée de mitraille quand elle a disparu, aussi soudainement qu'elle était apparue ! Elle volait sur les vagues comme un oiseau ! J'ai seulement eu le temps de lire son nom : 'Queen'... Et là, la foudre m'est tombée dessus : le pont et les haubans de ce navire grouillaient de morts-vivants...\nQuel diable... Et qui n'aurait pas eu peur ? Et si le Diable des mers en personne tenait la barre ? Ho ho ho ! Du rhum pour tout le monde !",

  PGG_Meet_BadRep[4] = "Oh, messieurs, voici un corsaire chevronné qui a sמrement quelque chose à raconter entre amis autour d'une chope de rhum.. " + IfPhraseSimple(isSetSail, "", "Voulez-vous vous joindre à nous ?");
	PGG_Meet_BadRep[5] = "Messieurs, nous avons, je crois, un gentilhomme de fortune " + IfPhraseSimple(isSetSail, "sur notre pont", "à notre table") + ", si je ne m'abuse.";
	PGG_Meet_BadRep[6] = "Et voici encore " + GetSexPhrase("un favori de la Fortune", "une louve de mer") + " !";
	PGG_Meet_BadRep[7] = GetSexPhrase("Encore un gentilhomme de fortune", "Encore une conquérante des mers") + ", si je ne m'abuse.";

  PGG_Meet_GoodRep[5] = "Et voici encore un « grand capitaine » qui ne cherche pas la facilité..."
	PGG_Meet_GoodRep[6] = "Et voici une personnalité héroïque, j'ai déjà entendu parler de vous !";
	PGG_Meet_GoodRep[7] = "Messieurs, nous avons parmi nous un digne capitaine, qui n'a encore jamais connu pareille galère. Que nous direz-vous, respectable capitaine ?";
}

