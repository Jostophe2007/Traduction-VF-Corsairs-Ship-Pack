// Gregg: the stranger from Port-au-Prince, who is Matilda - the "Black Orchid" trilogy
// (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// Nodes 1-7 - the set-up in town, 8-9 - the same woman dying in the Santiago storeroom.
// The first part of the Meritor is handed over here.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";

			if (PChar.MysteriousArtefact == "8")
			{
				dialog.text = "Capitaine, avez-vous puni ce scélérat ?";
				link.l1 = "Je m'en occupe. Je vous promets que je le ferai.";
				link.l1.go = "exit";
			}
		break;

		case "1":
			dialog.text = "Capitaine, je vous en supplie, aidez-moi ! Vous m'aiderez ? Promettez-le-moi !";
			link.l1 = "Très bien, je vais vous aider. Que s'est-il passé ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(en pleurs)... C'est dur pour moi d'en parler, capitaine. Croyez-moi, très dur.";
			link.l1 = "Calmez-vous et racontez-moi tout dans l'ordre.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(fond en larmes)... Pardonnez-moi. Quand je m'en souviens, je ne peux pas retenir mes larmes.";
			link.l1 = "Ce n'est rien, je comprends. Vous me raconterez peut-être demain ? Ce sera plus facile demain, croyez-moi.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "...(s'essuie le visage avec un mouchoir)... Non. Je n'aurai pas de repos tant que ce scélérat ne sera pas envoyé dans l'autre monde. Je dois le raconter maintenant.";
			link.l1 = "Je suis tout ouïe.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Mon mari Louis Bourdeaux et moi vivions ici, à Port-au-Prince. Des gens respectables, nous n'avons jamais enfreint la loi. Aujourd'hui, nous sommes sortis de la ville pour nous reposer : il y a là-bas un endroit charmant, Louis et moi l'aimions beaucoup. Mais aujourd'hui... aujourd'hui... ...(pleure de nouveau)...";
			link.l1 = "Demain, peut-être, finalement ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Non, je vais continuer. Un capitaine ivre s'est approché de nous et s'est mis à m'insulter. Louis, mon brave Louis, a tiré sa lame pour défendre mon honneur, et l'homme a sorti un pistolet de sa ceinture et lui a tiré une balle dans le front. Et puis... puis il a abusé de moi. De la façon la plus ignoble ...(fond en larmes)...";
			link.l1 = "Ce capitaine est toujours au-delà des portes de la ville ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Oui. Vengez mon mari et moi, capitaine, je vous en supplie. Tuez ce scélérat ! Nous étions des gens aisés, je vous paierai généreusement. Je vous attendrai à l'église.";
			link.l1 = "Très bien. Je dois me dépêcher.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactPortPaxWomanHelp");
		break;

		case "8":
			TakeNItems(PChar, "MysteriousArtefact_MeritorChapter_1", 1);
			dialog.text = "...(faiblement)... Capitaine... prenez cette chose... prenez-la... elle vous aidera à trouver l'Orchidée...";
			link.l1 = "Mais comment ? Que dois-je en faire ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "...(d'une voix de plus en plus faible)... Prenez-la... le moment venu... vous comprendrez ce qu'il faut... faire...";
			link.l1 = "Matilda ! Matilda !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactMatildaIsDead");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
