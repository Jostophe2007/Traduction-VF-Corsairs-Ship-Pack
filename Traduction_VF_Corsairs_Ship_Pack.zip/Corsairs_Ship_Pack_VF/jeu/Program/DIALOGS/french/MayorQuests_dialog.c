void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, Diag;
	int i;
	string sTemp;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;
		//----------------- уничтожение банды ----------------------
		case "DestroyGang_begin":
			chrDisableReloadToLocation = false;
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false); //боевке можно
			DeleteAttribute(&locations[FindLocation(pchar.GenQuest.DestroyGang.Location)], "DisableEncounters"); //энкаунтеры можно
			for(i = 1; i <= 29; i++)
			{
				if (GetCharacterIndex("MayorQuestGang_" + i) == -1) continue;
				sld = CharacterFromID("MayorQuestGang_" + i);
				LAi_type_actor_Reset(sld);
				LAi_RemoveCheckMinHP(sld);
			}
			sTemp = GetFullName(&characters[GetCharacterIndex(pchar.GenQuest.DestroyGang.MayorId)]);
			dialog.text = LinkRandPhrase("L'argent sur le tonneau, "+ GetSexPhrase("l'ami","ma petite") +" ! Je m'appelle " + GetFullName(npchar) + ", et je ne tolère pas qu'on me contredise...",
				"Montre-moi le contenu de ta bourse, "+ GetSexPhrase("l'ami","ma petite") +", et vite ! Je m'appelle " + GetFullName(npchar) + ", et j'espère que tu as entendu parler de moi...",
				"Sors tout ce que tu as de valeur, je réquisitionne le contenu de ta bourse. Et dépêche-toi, car moi, " + GetFullName(npchar) + ", je ne suis pas très patient. Mais très sanguinaire, en revanche !");
			Link.l1 = LinkRandPhrase("Hé, alors c'est toi, " + GetFullName(npchar) + " ? Le gouverneur " + sTemp + " ne parle que de toi.",
				"Oh, alors c'est toi, le bandit que le gouverneur " + sTemp +" pourchasse ?!",
				"Ravi de vous voir, " + GetFullName(npchar) + ". Le gouverneur du coin, " + sTemp + ", ne parle que de vous...");
			Link.l1.go = "DestroyGang_1";
		break;
		case "DestroyGang_1":
			dialog.text = LinkRandPhrase("Oui, je suis célèbre dans les parages, héhé... Attends, tu ne serais pas encore un de ces chiens du gouverneur qui cherchent à me faire brמler ?",
				"Le gouverneur est mon grand ami, pourquoi le cacher ? Ha, tu ne serais pas encore un de ces héros venus chercher ma tête ?",
				"L'attitude « amicale » du gouverneur envers moi est un fait, héhé. Comment le sais-tu ? Ce ne serait pas lui qui t'envoie à mes trousses ?");
			Link.l1 = LinkRandPhrase("C'est ça, salaud. Prépare-toi à mourir !", "דa alors, que tu es malin. Bon, il est temps de passer à ta liquidation. On a assez parlé...", "Oui, c'est moi. Sors ton arme, l'ami ! Voyons de quelle couleur est ton sang.");
			Link.l1.go = "DestroyGang_ExitFight";
			Link.l2 = LinkRandPhrase("Non, vraiment ! Je n'ai pas du tout besoin de ces ennuis...", "Non, je ne m'occupe pas de ce genre de choses, les actes héroïques, très peu pour moi...", "Non, pas question ! Je n'ai pas besoin d'ennuis...");
			Link.l2.go = "DestroyGang_2";
		break;
		case "DestroyGang_2":
			dialog.text = LinkRandPhrase("Voilà qui est mieux, "+ GetSexPhrase("l'ami", "ma petite") +"... Maintenant, dégage !",
				"Et c'est la bonne décision : si tu savais combien de héros j'ai envoyés dans l'autre monde... Bon, assez de lyrisme. Dégage d'ici, "+ GetSexPhrase("sac à merde","traînée") +" !",
				"Bravo, je te félicite ! Une position très sage dans la vie : ne pas aller là oם on ne t'a rien demandé... Bon, file, "+ GetSexPhrase("l'ami","ma petite") +".");
			Link.l1 = "Adieu, je vous souhaite une bonne santé...";
			Link.l1.go = "DestroyGang_ExitAfraid";
		break;

		case "DestroyGang_ExitAfraid":
			pchar.GenQuest.DestroyGang = "Found"; //флаг нашёл, но струсил
			npchar.money = AddMoneyToCharacter(npchar, sti(pchar.money));
			pchar.money = 0;
			LAi_SetWarriorType(npchar);
			LAi_SetImmortal(npchar, false);
			LAi_SetCheckMinHP(npchar, LAi_GetCharacterHP(npchar)-1, false, "DestroyGang_SuddenAttack");
			for(i = 1; i < 30; i++)
			{
				if (GetCharacterIndex("MayorQuestGang_" + i) == -1) continue;
				sld = CharacterFromID("MayorQuestGang_" + i);
				LAi_SetActorType(sld);
				LAi_ActorFollow(sld, npchar, "", -1);
				LAi_SetImmortal(sld, true);
				LAi_SetCheckMinHP(sld, LAi_GetCharacterHP(sld)-1, false, "DestroyGang_SuddenAttack");
			}
			DialogExit();
		break;

		case "DestroyGang_ExitFight":
			for(i = 0; i < 30; i++)
			{
				if (GetCharacterIndex("MayorQuestGang_" + i) == -1) continue;
				sld = CharacterFromID("MayorQuestGang_" + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "DestroyGang_Afrer");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
						// ОЗГ - пассажир
		case "ContraPass_abordage":
			dialog.text = "Argh, gredin ! Comment oses-tu attaquer mon navire ?! Tu vas le payer cher !";
			link.l1 = "Payer ? Oh oui ! D'ailleurs, on me paie plutכt bien pour ça... Vous avez un homme à bord, " + pchar.GenQuest.TakePassenger.Name + " de son nom. C'est lui que je cherche.";
			link.l1.go = "ContraPass_abordage_1";
		break;
		
		case "ContraPass_abordage_1":
			dialog.text = "Je savais que ce gredin ne nous apporterait que des ennuis... Mais je ne me rendrai pas si facilement ! En garde, misérable pirate !";
			link.l1 = "Tiens bon et tâche de ne pas tomber trop lourdement, chien !";
			link.l1.go = "ContraPass_abordage_2";
		break;
		
		case "ContraPass_abordage_2":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("ContraPass_GivePrisoner");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
				
		case "Tempsailor":
			dialog.text = "Capitaine, nous avons fouillé les cabines et la cale comme vous l'aviez ordonné. Le misérable a essayé de se cacher, mais nous l'avons débusqué.";
			link.l1 = "Excellent ! Oם est-il maintenant ?";
			link.l1.go = "Tempsailor_1";
		break;
		
		case "Tempsailor_1":
			dialog.text = "Comme vous l'aviez ordonné : on l'a conduit à la cale et mis aux fers.";
			link.l1 = "Bien joué ! Maintenant, quittons ce rafiot. Il est temps de rentrer.";
			link.l1.go = "Tempsailor_2";
		break;
		
		case "Tempsailor_2":
			dialog.text = "א vos ordres, capitaine !";
			link.l1 = "...";
			link.l1.go = "Tempsailor_3";
		break;
		
		case "Tempsailor_3":
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "OpenTheDoors", 10.0);
			sld = GetCharacter(NPC_GenerateCharacter("ContraPass", "pirate_"+1+rand(9), "man", "man", 10, sti(pchar.GenQuest.TakePassenger.Nation), -1, true));
			sld.name = pchar.GenQuest.TakePassenger.Name;
			sld.lastname = "";
			pchar.GenQuest.LastQuestPrisonerIdx = SetCharToPrisoner(sld);
			SetCharacterRemovable(&characters[sti(pchar.GenQuest.LastQuestPrisonerIdx)], false);
			Pchar.GenQuest.TakePassenger.PrisonerIDX = sti(pchar.GenQuest.LastQuestPrisonerIdx);
		break;

		//----------------- поиски лазутчика в коммонах ----------------------
		case "SeekSpy_house":
			chrDisableReloadToLocation = false;
			dialog.text = "Que voulez-vous, " + GetAddress_Form(PChar) + " ?";
			Link.l1 = "Je dois savoir qui vous êtes. Dites-moi immédiatement qui vous êtes et ce que vous faites ici !";
			Link.l1.go = "SeekSpy_1";
		break;
		case "SeekSpy_1":
			dialog.text = "Et qui êtes-vous pour que je réponde à vos questions ?";
			Link.l1 = "J'agis pour le compte du gouverneur, je recherche un espion ennemi !";
			Link.l1.go = "SeekSpy_2";
		break;
		case "SeekSpy_2":
			dialog.text = "Et qu'est-ce que j'ai à voir là-dedans ?";
			Link.l1 = "Peut-être rien, mais allons d'abord à la commandanture. Là-bas, on tirera ça au clair...";
			Link.l1.go = "SeekSpy_3";
		break;
		case "SeekSpy_3":
			dialog.text = "Non, je ne vais pas à la commandanture. Considérez que vous avez trouvé l'espion. Eh bien, essayez donc de sortir d'ici maintenant.";
			Link.l1 = "Hé, j'y compte bien...";
			Link.l1.go = "SeekSpy_fight";
		break;
		case "SeekSpy_fight":
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "SeekSpy_Afrer");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "CitizenNotBlade":
			dialog.text = "Qui êtes-vous ?! Rangez vos armes, vite !";
			link.l1 = "Je voulais juste me vanter...";
			link.l1.go = "SeekSpy_house";
		break;
		//----------------- поиски лазутчика на улице ----------------------
		case "SeekSpy_street":
			Diag.TempNode = "SeekSpy_street";
            dialog.Text = NPCharRepPhrase(npchar,
		            PCharRepPhrase(LinkRandPhrase("Oh, c'est vous, " + GetFullName(Pchar)
                    +", "+ GetSexPhrase("vieux filou","tête brמlée") +"", ""+ GetSexPhrase("Content de vous revoir, vieux frère ","Content de vous revoir, ma belle ") +""
                    + Pchar.name, "Oh ! Capitaine "
                        +GetFullName(Pchar))
                                    +LinkRandPhrase(". Je croyais qu'on ne vous reverrait plus.", ". Et sans doute, comme toujours, "+ GetSexPhrase("ivre","ivre") +".", ". Et, à ce que je vois, toujours en liberté !")
                                    +LinkRandPhrase(" Dites-moi, que voulez-vous ?", " Que voulez-vous cette fois ?", " Vous venez encore me déranger pour rien ?"),
                                    LinkRandPhrase(TimeGreeting() + ", le capitaine ", "Bonjour, "+GetAddress_Form(NPChar)+" ", "Salutations, capitaine ")+GetFullName(Pchar)
                                    +LinkRandPhrase(". Qu'est-ce qui pourrait bien amener ici "+ GetSexPhrase("un homme aussi respectable","une fille aussi courageuse") +" ?", ". Pourquoi êtes-vous venu ?", ". Que voulez-vous savoir cette fois ?")
                                    ),

                    PCharRepPhrase(LinkRandPhrase("Bonjour, capitaine ", "Bonjour... Ah, c'est vous, "+GetAddress_Form(NPChar)+" ", "Ah, capitaine ")
                                    +GetFullName(Pchar)
                                    +LinkRandPhrase(" – je pensais qu'on ne se reverrait plus,",
                                                        ", je ne peux pas dire que ça me fasse plaisir de vous voir, mais", " – je vois que vous êtes toujours en vie, malheureusement. Alors,")
                                    +LinkRandPhrase(" que voulez-vous ?", " pourquoi êtes-vous ici ?", "  en quoi puis-je vous être "+NPCharSexPhrase(NPChar, " utile ?", " utile ?")),
                                    LinkRandPhrase(TimeGreeting() + ", le capitaine " + GetFullName(Pchar) + ". Comment puis-je vous aider ?",
                                    "Oh, c'est le capitaine " + GetFullName(Pchar) + " ! Que voulez-vous savoir cette fois ?",
                                    "Bonjour, " + GetAddress_Form(NPChar) + " " + Pchar.lastname + ". Vous avez besoin de quelque chose ?"))
                                    );

	   		link.l1 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien, je"+ GetSexPhrase(" vais juste"," vais juste") +" à la taverne."),
                                    RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			link.l1.go = "exit";
			link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
			link.l2.go = "exit";//(перессылка в файл города)
			// --> квестовый генератор мэра, поиск шпиёна на улице. eddy
			if (CheckAttribute(pchar, "GenQuest.SeekSpy.City") && pchar.location == (npchar.city + "_town"))
	        {
				link.l4 = NPCharSexPhrase(npchar, LinkRandPhrase("Attendez ! Dites-moi immédiatement qui vous êtes ?! Je recherche un espion ennemi pour le compte du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
					"Halte immédiatement ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
					"Halte, l'ami ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville."),
					LinkRandPhrase("Femme, halte ! Dites-moi immédiatement qui vous êtes ?! Je cherche un espion ennemi pour le compte du gouverneur " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
					"Femme, je dois vous retenir ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
					"Attendez, ma belle ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville..."));
				link.l4.go = "SitySpy";
			}
			// <-- квестовый генератор мэра, поиск шпиёна на улице
			link.l5 = PCharRepPhrase("Je veux apprendre quelque chose sur cette ville !", "Je veux apprendre quelque chose sur la ville.");
			link.l5.go = "new question";
		break;

		case "new question":
            dialog.text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Oh, oui, je serais ravi"+NPCharSexPhrase(NPChar, " ", "e ")+"de trinquer avec toi, demande ce que tu veux.", "Vous aimez bavarder, capitaine ? Eh bien, moi aussi... Surtout autour d'une chope de rhum.", "Oui, " + PChar.name + " ?"),
                                        LinkRandPhrase("Eh bien, que voulez-vous encore ?", "Je vois, capitaine "+PChar.name+", vous avez envie de bavarder ? ", "Vous m'avez épuisé avec vos questions, capitaine, il vaudrait mieux boire du rhum.")),
		                PCharRepPhrase(LinkRandPhrase("Que vouliez-vous savoir, "+ GetAddress_Form(NPChar) + " ?", "Je vous écoute, capitaine.", "Je dois y aller, alors posez vite vos questions, capitaine."),
                                        LinkRandPhrase("Je suis toujours ravi"+NPCharSexPhrase(NPChar, " ", "e ")+"de bavarder avec quelqu'un d'agréable, " + GetAddress_Form(NPChar) + " " + PChar.lastname + ". Parlez.",
                                                        "Oui, " + GetAddress_Form(NPChar) + " ?",
                                                        "Vous aimez bavarder, capitaine ? Eh bien, moi aussi..."))
                            );

            // homo 25/06/06
			link.l1 = LinkRandPhrase ("Quelles histoires raconte-t-on à la taverne, par ici ?",
                                    "Quoi de neuf dans le coin ?",
                                    "Comment va la vie à terre ?");
			link.l1.go = "rumours_citizen";
			link.l2 = LinkRandPhrase("Pouvez-vous m'indiquer le chemin ?", "Je n'arrive pas à trouver mon chemin...", "Indiquez-moi le chemin...");
			link.l2.go = "exit";  //(перессылка в файл города)
			link.l3 = "Parlez-moi de votre colonie.";
			link.l3.go = "colony";
            link.l4 = RandPhraseSimple("J'ai une affaire importante !", "J'ai une affaire pour vous.");
			link.l4.go = "exit";  //(перессылка в файл города)
			link.l5 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien, je"+ GetSexPhrase(" vais juste"," vais juste") +" à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			link.l5.go = "exit";
		break;

		case "colony":
			dialog.text = LinkRandPhrase("Pour être honnête, je n'en sais pas grand-chose. Mais je peux vous dire certaines choses.",
                           "Qu'est-ce qui vous intéresse dans notre colonie ?", "Je vous en prie. Que voulez-vous entendre ?");
            switch(Rand(1))
			{
				case 0:
					link.l1 = "Quel genre de ville est-ce ?";
					link.l1.go = "colony_town";
				break;

				case 1:
					link.l1 = "Que savez-vous du fort qui protège la ville ?";
					link.l1.go = "fort";
				break;
            }
			link.l2 = "Parlons d'autre chose.";
			link.l2.go = "new question";
		break;
	  // to_do
		case "colony_town":
            dialog.text = "Oh, vous vous moquez de moi ? Ou vous plaisantez ? Regardez dans le coin supérieur droit de l'écran.";
			link.l1 = "C'est vrai, je suis bête.";
		    link.l1.go = "exit";
		break;

		case "fort":
            dialog.text = "Je n'en sais rien.";
			link.l1 = "Désolé.";
		    link.l1.go = "exit";
		break;
		//==> поймал засланца
		case "SitySpy":
			dialog.text = "Et alors, qu'est-ce que j'ai à voir là-dedans ? Je suis d'ici !";
			link.l1 = "Qui peut confirmer vos dires ?";
		    link.l1.go = "SitySpy_1";
		break;
		case "SitySpy_1":
			dialog.text = "Tout le monde peut le confirmer, tout le monde !!!",
			link.l1 = "Qui ça, tout le monde ? Nommez au moins un habitant de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !";
			link.l1.go = "SitySpy_3";
		break;
		case "SitySpy_3":
            dialog.text = "Euh... Tout de suite... Mmm..";
			link.l1 = "C'est clair, l'ami, c'est bien toi que je cherche ! Suis-moi, ou je te tue sur place. Tu as bien compris ?!";
		    link.l1.go = "SitySpy_4";
		break;
		case "SitySpy_4":
            dialog.text = "Bon sang ! C'était si bête de me mêler de ça !.. C'est compris, je vous suis : je tiens encore à la vie...";
			link.l1 = "Eh bien, voilà qui est bien. Nous allons chez le gouverneur, il voulait te voir...";
		    link.l1.go = "SitySpy_5";
		break;
		case "SitySpy_5":
			sTemp = GetFullName(&characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)]);
			AddQuestRecord("MayorsQuestsList", "5");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", sTemp);
			// слухи
			AddSimpleRumour("Vous savez, le gouverneur " + sTemp + " a chargé "+ GetSexPhrase("un certain capitaine","une certaine capitaine") +" " + GetMainCharacterNameGen() + " de trouver un espion ennemi dans la ville. Et vous savez quoi ? "+ GetSexPhrase("Il l'a trouvé","Elle l'a trouvé") +" en pleine rue !", sti(characters[sti(pchar.GenQuest.SeekSpy.MayorId)].nation), 5, 1);
			AddSimpleRumourCity("Notre gouverneur a confié au capitaine " + GetMainCharacterNameGen() + " la mission de trouver un agent ennemi dans la ville. Et "+ GetSexPhrase("ce capitaine a démasqué","cette fille a démasqué") +" un espion parmi les habitants !", npchar.city, 5, 1, "");
			pchar.quest.AllMayorsQuests_Late.over = "yes"; //снимаем общий таймер
			pchar.GenQuest.SeekSpy = "FoundSpy"; //флаг нашёл шпиона
			DeleteAttribute(pchar, "GenQuest.SeekSpy.City"); //не опрашивать более в городе
			LocatorReloadEnterDisable(pchar.location, "gate_back", true);
			LocatorReloadEnterDisable(pchar.location, "reload1_back", true);
			LocatorReloadEnterDisable(pchar.location, "reload2_back", true);
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;
		//----------------- найти и уничтожить пирата в море ----------------------
		case "DestroyPirate_Abordage": //абордаж
			if (CheckAttribute(pchar, "GenQuest.DestroyPirate.wasTalkInDeck"))
			{
				dialog.text = "Encore toi...";
				Link.l1 = "Oui, j'avais oublié...";
				Link.l1.go = "DP_Abordage_1";
			}
			else
			{
				dialog.text = "Qui êtes-vous ?!";
				Link.l1 = "Je viens chercher ta tête, l'ami. Le gouverneur de " + XI_ConvertString("Colony"+pchar.GenQuest.DestroyPirate.MayorId+"Gen") + " veut la voir clouée à la porte de la ville.";
				Link.l1.go = "DP_Abordage_2";
			}
		break;
		case "DP_Abordage_1":
			dialog.text = "Et merde ! Je vais te tuer !";
			Link.l1 = "Essaie donc...";
			Link.l1.go = "DP_Abordage_fight";
		break;
		case "DP_Abordage_2":
			dialog.text = "Hé, je vois... Eh bien, je vais essayer de ne pas lui faire ce plaisir !";
			Link.l1 = "Essaie donc...";
			Link.l1.go = "DP_Abordage_fight";
		break;
 		case "DP_Abordage_fight":
			LAi_SetCurHP(npchar, rand(sti(npchar.chr_ai.hp_max)) + 5);
			LAi_GetCharacterMaxEnergy(npchar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
		break;
		//разговор на палубе
		case "DestroyPirate_Deck":
			pchar.GenQuest.DestroyPirate.wasTalkInDeck = true; //флаг на палубный базар
			dialog.text = "Qu'est-ce que tu fais ici, l'ami ?";
			Link.l1 = "J'agis pour le compte du gouverneur de " + XI_ConvertString("Colony"+pchar.GenQuest.DestroyPirate.MayorId+"Gen") + ", je recherche un pirate qui opère dans ces eaux ces derniers temps.";
			Link.l1.go = "DestroyPirate_1";
		break;
		case "DestroyPirate_1":
			dialog.text = "Je ne peux pas dire que ce soit une occupation digne d'un capitaine...";
			Link.l1 = "Qu'est-ce que ça veut dire ?!";
			Link.l1.go = "DestroyPirate_2";
		break;
		case "DestroyPirate_2":
			dialog.text = "Exactement ce que je te dis. Traquer des corsaires libres pour que le gouverneur du coin puisse ensuite pendre nos cadavres tout autour de la ville, c'est une occupation indigne d'un capitaine de navire.";
			Link.l1 = "Alors c'est vous, les pirates...";
			Link.l1.go = "DestroyPirate_3";
		break;
		case "DestroyPirate_3":
			dialog.text = "C'est ça, le toutou du gouverneur. Hé, tu es dans une position peu enviable : tu es seul... sur mon navire...";
			Link.l1 = "Et qu'est-ce que tu comptes faire, maintenant ?";
			Link.l1.go = "DestroyPirate_4";
		break;
		case "DestroyPirate_4":
			int lngFileID;
			if (pchar.GenQuest.DestroyPirate.fortPlace == "1")
			{
				pchar.GenQuest.DestroyPirate.outShoreId = GetIslandRandomShoreId(pchar.GenQuest.DestroyPirate.Areal);
				sld = characterFromId(pchar.GenQuest.DestroyPirate.MayorId);
				lngFileID = LanguageOpenFile("LocLables.txt");
				sTemp = LanguageConvertString(lngFileID, pchar.GenQuest.DestroyPirate.outShoreId);
				dialog.text = "Hum, ensuite... Je me suis trop approché du fort, alors je ne vais pas prendre de risques et je vais te garder ici un moment. Tu diras à tes amis que tu pars sur mon navire pour un endroit appelé " + sTemp + ", et qu'ils t'attendent à " + XI_ConvertString("Colony"+sld.city+"Dat") +
					". Dans ce cas, je te laisserai vivre. Sinon, on t'étripe ici même, sur le pont. Que dis-tu de ces perspectives ?";
				Link.l1 = "Je ne dirai pas qu'elles sont alléchantes. Comment savoir si tu tiendras parole quand le fort ne pourra plus t'atteindre ?";
				Link.l1.go = "DestroyPirate_5";
				break;
			}
			if (GetCompanionQuantity(pchar) == 1 && makeint(pchar.GenQuest.DestroyPirate.shipState) > 1)
			{
				dialog.text = "Je crois que je vais te laisser partir, "+ GetSexPhrase("chien du gouverneur","chienne du gouverneur") +". Tu paieras ma générosité de ton argent. Bref, file pendant que je suis de bonne humeur...";
				Link.l1 = "Merci quand même. Adieu...";
				Link.l1.go = "DP_WithoutFight";
				Link.l2 = "Tu sais quoi ? Je vais te trancher la gorge avant que tout ton équipage n'accoure...";
				Link.l2.go = "DP_FightInDeck";
			}
			else
			{
				pchar.GenQuest.DestroyPirate.outShoreId = GetIslandRandomShoreId(pchar.GenQuest.DestroyPirate.Areal);
				sld = characterFromId(pchar.GenQuest.DestroyPirate.MayorId);
				lngFileID = LanguageOpenFile("LocLables.txt");
				sTemp = LanguageConvertString(lngFileID, pchar.GenQuest.DestroyPirate.outShoreId);
				dialog.text = "Et ensuite, tu diras à tes amis que tu pars sur mon navire pour un endroit appelé " + sTemp + ", et qu'ils t'attendent à " + XI_ConvertString("Colony"+sld.city+"Dat") +
					". Dans ce cas, je te laisserai vivre. Sinon, on t'étripe ici même, sur le pont. Que dis-tu de ces perspectives ?";
				Link.l1 = "Je ne dirai pas qu'elles sont alléchantes. Comment savoir si tu tiendras parole, alors que je suis complètement seul ?";
				Link.l1.go = "DestroyPirate_5";
			}
		break;
		case "DestroyPirate_5":
			dialog.text = "Hé, tu ne peux pas le savoir, mais tu auras ma parole. Sinon, la mort t'attend tout de suite. Il me semble que le choix est évident...";
			Link.l1 = "Hum, bon, j'accepte. J'espère que tu tiendras parole...";
			Link.l1.go = "DP_toShore";
			Link.l2 = "Pour moi, c'est tout vu. Et mon choix, c'est le combat, ici et maintenant. Aux armes, canailles !";
			Link.l2.go = "DP_FightInDeck";
		break;

		case "DP_toShore":
			dialog.text = "Je la tiendrai, n'aie pas peur.";
			Link.l1 = "Alors, je suis prêt. Au travail.";
			Link.l1.go = "exit";
			AddDialogExitQuest("DestroyPirate_toShore");
		break;

		case "DP_WithoutFight":
			dialog.text = "Si je te revois, tu te balanceras au bout d'une vergue, tiens-le-toi pour dit...";
			Link.l1 = "Je vois...";
			Link.l1.go = "exit";
			Diag.TempNode = "DP_WithoutFight_again";
			AddDialogExitQuest("DestroyPirate_WithoutFight");
		break;
		case "DP_WithoutFight_again":
			dialog.text = "Tu es encore là ? א ta place, je ne traînerais pas ici...";
			Link.l1 = "Je m'en vais.";
			Link.l1.go = "exit";
			Diag.TempNode = "DP_WithoutFight_again";
		break;

		case "DP_FightInDeck":
			dialog.text = "דa alors, "+ GetSexPhrase("quel homme courageux","quelle fille courageuse") +" ! J'apprécie le courage, ce sera dommage de te tuer... Hé, sur le pont, attrapez-moi  "+ GetSexPhrase("ce blanc-bec","cette pimbêche") +" avec précaution, je vais préparer le navire au combat en attendant. Seulement, ne faites pas trop de bruit !";
			Link.l1 = "Dommage que tu nous quittes...";
			Link.l1.go = "DP_FightInDeck_1";
		break;
		case "DP_FightInDeck_1":
			pchar.GenQuest.DestroyPirate.FightAfterDeck = true; //после резни на палубе - драка в море
			float locx, locy, locz;
			GetCharacterPos(pchar, &locx, &locy, &locz);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", LAi_FindNearestFreeLocator("reload", locx, locy, locz), "none", "", "", "DestroyPirate_FightInDeck", 3.5);
			DialogExit();
		break;


	}
}
