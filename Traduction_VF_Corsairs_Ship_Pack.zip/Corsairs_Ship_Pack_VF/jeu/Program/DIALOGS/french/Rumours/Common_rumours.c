// Слухи - диалог по типажам

#define MAX_RUMOURS_ABOUT_OWNERS 7

void ProcessCommonDialogRumors(ref NPChar, aref Link, aref NextDiag);
{
    string strum;
    string srum;
	switch(Dialog.CurrentNode)
	{
	case "rumours_citizen":
		NextDiag.CurrentNode = "rumours";
		//------------- квестовые слухи горожан --------->>>>>>>>
		//жемчужный генератор Шарпа
		if(CheckAttribute(NPChar, "city") && pchar.questTemp.Sharp.City == npchar.city && sti(pchar.questTemp.Sharp.City.rumour))
		{
			pchar.questTemp.Sharp.City.rumour = false; //слух дан
			Dialog.Text = Sharp_choiceAction();
			link.l1 = "Hum, je vois... Quoi d'autre de neuf ?";
			link.l1.go = "new question";
			link.l2 = RandPhraseSimple("Merci, je prends congé.",
									"Bonne journée.");
			link.l2.go = "exit";
			break;
		}

		//квест шебеки Синяя Птица
		if (pchar.questTemp.BlueBird == "returnMoney" && pchar.questTemp.BlueBird.City != "" && CheckAttribute(NPChar, "city") && sti(pchar.questTemp.BlueBird.count)<7)
		{//после 7 флейтов перестаём пускать новые
			bool bConv = false;
			if (!CheckAttribute(pchar, "questTemp.BlueBird.ShipRumour")) pchar.questTemp.BlueBird.ShipRumour = true;
			if (!CheckAttribute(pchar, "questTemp.BlueBird.ColonyRumour")) pchar.questTemp.BlueBird.ColonyRumour = true;
			if (pchar.questTemp.BlueBird.ShipRumour == false && pchar.questTemp.BlueBird.ColonyRumour == false && !CheckAttribute(pchar, "quest.BlueBird_loginFleut")) BlueBurd_RumourUpdate();
			if (pchar.questTemp.BlueBird.City == npchar.city && pchar.questTemp.BlueBird.ShipRumour == true)
			{
				Dialog.Text = BlueBurd_setTradeShip();
				pchar.questTemp.BlueBird.ColonyRumour = false;
				pchar.questTemp.BlueBird.ShipRumour = false;
				bConv = true;
			}
			else
			{
				if (pchar.questTemp.BlueBird.ColonyRumour == true && rand(2) == 1)
				{
					pchar.questTemp.BlueBird.ColonyRumour = false;
					Dialog.Text = BlueBurd_GetColonyRumour();
					bConv = true;
				}
			}
			if (bConv)
			{
				link.l1 = "Oui, je vois... Quoi d'autre de neuf en ville ?";
				link.l1.go = "new question";
				link.l2 = RandPhraseSimple("Merci, je prends congé.", "Bonne journée.");
				link.l2.go = "exit";
				break;
			}
		}	

		if (pchar.questTemp.Slavetrader == "canTakeQuest" && rand(4) == 0)
		{
			sld = characterFromId(pchar.questTemp.Slavetrader.UsurerId);
			Dialog.Text = "On dit qu'un usurier de la colonie de "+ XI_ConvertString("Colony" + sld.city) +" cherche un capitaine qui ne rechigne pas à se salir les mains pour un travail lucratif...";
			link.l1 = "Oui, je vois... Quoi d'autre de neuf en ville ?";
			link.l1.go = "new question";
			link.l2 = RandPhraseSimple("Merci, je prends congé.",
									"Bonne journée.");
			link.l2.go = "exit";
			break;
		}

		if(pchar.questTemp.Ascold == "canTakeQuest" && rand(3) == 0)
		{
			sld = characterFromId(pchar.questTemp.Ascold.TraderId);
			Dialog.Text = "On dit que le marchand de la colonie de "+ XI_ConvertString("Colony" + sld.city) +" cherche une certaine poudre, et qu'il offre beaucoup d'argent pour ça...";
			link.l1 = "Oui, je vois... Quoi d'autre de neuf en ville ?";
			link.l1.go = "new question";
			link.l2 = RandPhraseSimple("Merci, je prends congé.",
									"Bonne journée.");
			link.l2.go = "exit";
			break;
		}

		//<<<<<-------- квестовые слухи горожан -----------------
		if (!CheckAttribute(NPChar, "quest.repeat.rumours_citizen") || NPChar.quest.repeat.rumours_citizen != 3 )
        srum = SelectRumourEx("citizen", NPChar);
        else srum = NO_RUMOUR_TEXT[rand(SIMPLE_RUMOUR_NUM - 1)]; // fix
        string posrep1, posrep2, answ1, answ2, answ3, answ4;
        if (RumourHasInformation(srum))
        {
            posrep1 = RandPhraseSimple(". Voilà comment vont les choses...", ". דa vous amusera peut-être.");
            posrep2 = " Capitaine, avez-vous des nouvelles pour notre colonie ?";
            answ1 = RandPhraseSimple(RandSwear() + "Ce que vous me racontez est intéressant, " + GetFullName(NPChar)+".",
                                 "Alors racontez-m'en plus...");
            answ2 = RandPhraseSimple(RandSwear() + "C'est très intéressant ! Je voulais vous demander...",
                                 "Encore une question.");
            answ3 = RandPhraseSimple("Tout arrive en ce monde. Désolé, mais je n'ai pas de nouvelles.",
                                 "Je suis un peu pressé, alors une autre fois.");
            answ4 = "";

        }
        else
        {
            posrep1 = " Il se passe rarement quelque chose chez nous. Mais quand il arrive quelque chose d'inhabituel, tout le monde en parle.";
            posrep2 = " Donc, pas de nouvelles. Mais peut-être que " + GetAddress_Form(NPChar) + " le capitaine sait quelque chose ?";
            answ1 = RandPhraseSimple("Alors racontez-moi plutכt...",
                                 RandSwear() + "Vous ne savez rien ! Je voulais vous demander...");
            answ2 = RandPhraseSimple("Vous dites que vous ne savez rien, bon, alors dites-moi...",
                                 "Oui, vous ne m'avez pas beaucoup aidé, mais vous savez peut-être autre chose ?");
            answ3 = RandPhraseSimple("Je ne crois pas savoir quoi que ce soit qui puisse vous intéresser.",
                                 "Je serai heureux de vous raconter quelque chose, mais une autre fois.");
            answ4 = "";

        }
		Dialog.Text = NPCStringReactionRepeat(srum,
                                                srum+posrep1,
                                                srum+posrep2,
                                                RandPhraseSimple("Malheureusement, je ne sais rien d'autre, laissez-moi partir.",
                                                                    "Vous m'avez épuisé avec vos questions, désolé, mais j'ai à faire."),
                                                "block", 1, npchar, Dialog.CurrentNode);
        link.l1 = HeroStringReactionRepeat(answ1,
                                            answ2,
                                            answ3,
                                            answ4,
                                            npchar, Dialog.CurrentNode);
		link.l1.go = "new question";
		link.l2 = RandPhraseSimple("Merci, je prends congé.",
                                 "Bonne journée.");
		link.l2.go = "exit";
	break;

	///////////////////////////////////////////---слухи матросов---////////////////////////////////////////////
	case "rumours_sailor":
		NextDiag.CurrentNode = "rumours";

		if (!CheckAttribute(NPChar, "quest.repeat.rumours_citizen") || NPChar.quest.repeat.rumours_citizen != 2) srum = SelectRumourEx("sailor", NPChar);
        else srum = NO_RUMOUR_TEXT[rand(SIMPLE_RUMOUR_NUM - 1)]; // fix
        if (RumourHasInformation(srum))
        {
            posrep1 = RandPhraseSimple(". Voilà comment vont les choses...", ". דa vous amusera peut-être.");
            posrep2 = " Et vous, capitaine, avez-vous des nouvelles pour notre colonie ?";
            answ1 = RandPhraseSimple(RandSwear() + "Ce que vous me racontez est intéressant, " + GetFullName(NPChar)+".",
"Alors racontez-m'en plus...");
            answ2 = RandPhraseSimple(RandSwear() + "C'est très intéressant ! Je voulais vous demander...", "Encore une question.");
            answ3 = RandPhraseSimple("Tout arrive en ce monde. Désolé, mais je n'ai pas de nouvelles. ", "Je suis un peu pressé, alors une autre fois.");
            answ4 = "";
        }
        else
        {
            posrep1 = " Il se passe rarement quelque chose chez nous. Mais quand il arrive quelque chose d'inhabituel, tout le monde en parle.";
            posrep2 = " Donc, pas de nouvelles. Mais peut-être que " + GetAddress_Form(NPChar) + " le capitaine sait quelque chose ?";
            answ1 = RandPhraseSimple("Alors racontez-moi plutכt...",RandSwear() + "Vous ne savez rien ! Je voulais vous demander...");
            answ2 = RandPhraseSimple("Vous dites que vous ne savez rien, bon, alors dites-moi...", "Oui, vous ne m'avez pas beaucoup aidé, mais vous savez peut-être autre chose ?");
            answ3 = RandPhraseSimple("Je ne crois pas savoir quoi que ce soit qui puisse vous intéresser.", "Je serai heureux de vous raconter quelque chose, mais une autre fois.");
            answ4 = "";
        }
		Dialog.Text = NPCStringReactionRepeat(srum,
            srum+posrep1,
            srum+posrep2,
            RandPhraseSimple("Malheureusement, je ne sais rien d'autre, laissez-moi partir.", "Vous m'avez épuisé avec vos questions, pardonnez-moi, mais j'ai à faire."), "block", 1, npchar, Dialog.CurrentNode);
        link.l1 = HeroStringReactionRepeat(answ1,
            answ2,
            answ3,
            answ4,
            npchar, Dialog.CurrentNode);
		link.l1.go = "question";
		link.l2 = RandPhraseSimple("Merci, je prends congé.", "Bonne journée.");
		link.l2.go = "exit";
	break;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	case "rumours_habitue":
		//Black Sails
		if (CheckAttribute(pchar, "BSUrka_Negril") && rand(10) > 5)
		{
			if (npchar.location == "PortRoyal_tavern" || npchar.location == "FortOrange_tavern")
			{
				PChar.quest.BSUrka_Negril.over = "yes";
				DeleteAttribute(pchar, "BSUrka_Negril");
				dialog.text = "Eh bien, à votre santé ! Ouh, il est bon, ce rhum. Si vous saviez ce qui s'est passé ici, dans la baie, il y a deux jours ! Un brick pirate, tout cabossé par les boulets, avec des voiles de vaisseau fantכme, a livré bataille à deux frégates espagnoles. Et puis, sortis de nulle part, trois pirates sur des corvettes ont surgi de derrière le cap ! On ne savait plus qui chassait qui. Les Espagnols sont passés bâbord amures et ont ouvert le feu par bordées entières. Une corvette a été transpercée de la proue à la poupe, quel vacarme ! On l'entendait jusqu'au fort ! Bref, celle qui avait été touchée a aussitכt donné de la bande et s'est mise à couler, et les deux autres, de leurs bordées, presque à bout portant, ont mis une frégate en pièces. Et le brick, qui fuyait les Espagnols, s'est soudain enhardi : il a jeté l'ancre à bâbord et viré sec autour de sa chaîne, au point d'en perdre un mât. Et il s'est mis à tirer sur le pirate par le flanc. Bref, ils ont coulé la deuxième corvette avec l'Espagnol survivant. Hé, j'ai la gorge sèche.";
				link.l1 = "Tiens, bois encore un coup. Et ensuite, que s'est-il passé ? Tu racontes une histoire passionnante ! J'ai l'impression de voir ce combat pour de vrai !";
				link.l1.go = "BS_NU_11";
				break;
			}
		}
		link.l1 = RandPhraseSimple(RandSwear() + "Il faut boire encore un verre pour ça...",
                                 "Bien. Allez, encore un.");
		link.l1.go = "sit_3";
		link.l2 = RandPhraseSimple("Merci, je prends congé.",
                                 "Oh, il est fort, ce rhum. Bon, je dois y aller, amuse-toi bien.");
		link.l2.go = "exit_sit";
		if (pchar.questTemp.piratesLine == "PL5Hunter_toFirst" && npchar.location == pchar.questTemp.piratesLine.Q5.city_1 + "_tavern")
		{
			dialog.text = "Imaginez, je suis assis sans embêter personne, quand cet Avory débarque et, sans rien demander, me frappe en pleine figure ! Il me dit que je dois de l'argent au croupier ?! Et ensuite, il dit qu'il s'est trompé. Il s'est trompé, et moi, je me retrouve avec une dent en moins ! Ah ! Qu'est-ce que vous en dites ?! Et, vous n'allez pas le croire, ça fait déjà une semaine, mais ça me fait encore mal. Une douleur pareille ! Peut-être une chope de bière... ?";
			link.l1 = "Eh bien, c'est possible...";
			link.l1.go = "sit_3";
			AddQuestRecord("Pir_Line_5_Hunter", "3");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_1 + "Gen"));
			pchar.questTemp.piratesLine = "PL5Hunter_toFirstUsurer";
			break;
		}
		if (pchar.questTemp.piratesLine == "PL5Hunter_toSecond" && npchar.location == pchar.questTemp.piratesLine.Q5.city_2 + "_tavern")
		{
			dialog.text = "Il y a environ cinq jours, un homme s'est assis à cכté de moi, tout comme vous maintenant. Il s'appelait, Dieu me garde... John Avory. Il m'a raconté comment il avait roulé un usurier d'ici, hé hé hé. C'est bien fait pour lui, ce maudit suceur de sang, il est assis sur son argent et il enfle, pendant que le travailleur n'a rien à manger...";
			link.l1 = "Oui, ces usuriers sont des gens immondes.";
			link.l1.go = "sit_3";
			AddQuestRecord("Pir_Line_5_Hunter", "5");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_2 + "Gen"));
			pchar.questTemp.piratesLine = "PL5Hunter_toSecondUsurer";
			break;
		}
		if (pchar.questTemp.piratesLine == "PL5Hunter_toThird" && npchar.location == pchar.questTemp.piratesLine.Q5.city_3 + "_tavern")
		{
			dialog.text = "Il y a eu une de ces bagarres il y a trois jours ! John Avory a surpris un tricheur. Il faut dire que le gars sait manier la ferraille. Paf, paf ! Et plus de tricheur. דa a crié, ça a fait du raffut. Mais John est un brave type, il a payé à boire à toute la taverne. Je te respecte !";
			link.l1 = "Eh bien ! Pas mal...";
			link.l1.go = "sit_3";
			AddQuestRecord("Pir_Line_5_Hunter", "7");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_3 + "Gen"));
			pchar.questTemp.piratesLine = "PPL5Hunter_toThirdUsurer";
			break;
		}
		//-->работорговец
		if (pchar.questTemp.Slavetrader == "FindRatJamaica_H" && npchar.location == "FortOrange_tavern")
        {
			dialog.text = "(il chante) Un jour, je suis tombé sur un rafiot de Hambourg. Des cloportes et des champignons sur les mâts, la coque pourrie, et des vers dans les vivres. Des punaises plein la merde, et la cambuse pleine de merde... Comment va la vie, marin, dis-moi, comment ça se passe en mer ?";
            link.l1 = "Oui, en mer, c'est toujours pareil : humide et salé. Dis-moi plutכt, tu sais oם est allé mon ami qui louait une chambre ici récemment ? Il s'appelle François Gontier.";
            link.l1.go = "Jamaica_ratH_1";
			break;
        }
		if (pchar.questTemp.Slavetrader == "EscapeSlaveVillemstad_H" && npchar.location == "Villemstad_tavern")
        {
			dialog.text = "(il chante) J'accusais le whisky de mon nez violet, et sur son conseil, j'ai envoyé son manteau au diable... Oh, sers-moi un verre, marin ! Je suis rentré de voyage hier seulement, je ne suis pas encore bien remis.";
            link.l1 = "Sers-toi, l'ami ! Alors, c'était comment en mer, qu'as-tu vu d'intéressant ?";
            link.l1.go = "EscapeSlave_Villemstad_H1";
			break;
        }
		//<--работорговец

		//ОЗГ, Крыса
		if(CheckAttribute(pchar, "questTemp.Headhunter"))
		{
    		if (pchar.questTemp.Headhunter == "Rat_Tavern" && npchar.location == pchar.questTemp.Headhunter.Ratrumcity + "_tavern")
            {
    			dialog.text = "(il chante) Le Hollandais volant, le Hollandais volant, file sur des mers inconnues... Eh, marin, buvons !";
                link.l1 = "וcoute, on m'a dit que des marins d'un navire, l'Adelaide, avaient tout saccagé en état d'ivresse...";
                link.l1.go = "Rat_Tavern_1";
				break;
            }
		}
		//<--ОЗГ, Крыса

		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskAlcash") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
	    {
			dialog.text = "Eh, " + GetAddress_Form(pchar) + " quelle vie on mène maintenant... Il n'y a plus rien de sacré chez les gens !";
			link.l1 = "De quoi parles-tu, l'ami ?";
			link.l1.go = "Alcogol_GenQuest_Church_2_1";
			break;
		}

		if(CheckAttribute(PChar, "HellSpawn.SeekRebirth"))
	    {
			//получим пещёру для чистки
			pchar.quest.HellSpawn.locationId = "DeckWithReefs"; //Id целевой пещёры
			sld = &locations[FindLocation(pchar.quest.HellSpawn.locationId)];
			npchar.quest.HellSpawn.label = GetConvertStr(sld.id.label, "LocLables.txt"); //тип подземелья для диалогов

			dialog.text = "Eh, " + GetAddress_Form(pchar) + " quelle vie on mène maintenant... J'ai entendu parler des choses terribles qui se passent sur le récif du Squelette. On dit que les morts-vivants se rassemblent dans la baie de là-bas pour une sorte de rituel de renaissance.";
			DeleteAttribute(PChar, "HellSpawn.SeekRebirth");
			SaveCurrentQuestDateParam("pchar.questTemp.HellSpawn.Rit");

			pchar.quest.HellSpawnRitual.win_condition.l1 = "location";
			pchar.quest.HellSpawnRitual.win_condition.l1.location = pchar.quest.HellSpawn.locationId;
			pchar.quest.HellSpawnRitual.function = "HellSpawnRitual";
			AddQuestRecordInfo("Important_rumours", "1");
			AddQuestUserData("Important_rumours", "sSex", GetSexPhrase("", "e"));
			break;
		}

		if(!CheckAttribute(pchar, "SalasarEventKnow") && rand(20)==0 && pchar.rank >= 20)
		{
			dialog.text = "Le bruit court que chaque année, le 3 mars à 3 heures, sur le récif du Squelette, dans le canyon du Diable, sur les ruines de la maison du gardien du cimetière, apparaît une lueur particulièrement vive et effrayante, qui sent l'horreur et le désespoir. J'aimerais bien voir ça de mes propres yeux, mais j'ai trop peur...";
			Log_Info("א retenir. Donc... le 3 mars, à 3 heures, chaque année.");
			pchar.SalasarEventKnow = true;
			AddQuestRecordInfo("Important_rumours", "2");
			AddQuestUserData("Important_rumours", "sSex", GetSexPhrase("", "e"));
			break;
		}
		if(CheckAttribute(pchar, "GiantEvilSkeleton") && rand(20)==0 && !CheckAttribute(pchar, "MalteseInfo"))
		{
			 if (pchar.name != "Whisper" && pchar.sex != "skeleton" && !CheckAttribute(pchar, "OrderHunter"))
			 {
				dialog.text = "Le bruit court que l'Inquisition espagnole recueille des informations sur le récif du Squelette. Dans quel but, on l'ignore, mais on promet une récompense à quiconque sait quelque chose...";
				Log_Info("א retenir. L'Inquisition espagnole et le récif du Squelette.");
				pchar.MalteseInfo = true;
				AddQuestRecordInfo("Important_rumours", "3");
				AddQuestUserData("Important_rumours", "sSex", GetSexPhrase("", "e"));
				break;
			 }
		}
		if(!CheckAttribute(pchar, "BlackBeardSpawn") && sti(pchar.rank)>=20)
		{
			AddQuestRecordInfo("Important_rumours", "4");
			AddQuestUserData("Important_rumours", "sSex", GetSexPhrase("", "e"));
			dialog.text = "On dit que le navire de Barbe-Noire lui-même a été aperçu dans l'archipel pour la première fois depuis des années. Le bruit court qu'il cherche le pirate le plus chanceux de l'archipel pour une étrange affaire.";
			Log_Info("א retenir. Edward Teach est apparu dans l'archipel.");
			pchar.BlackBeardSpawn = true;

			sld = GetCharacter(NPC_GenerateCharacter("BlackBeardNPC", "PGG_Tich_0", "man", "man", 60, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 60, 100, 100, "blackbeard_sword", "howdah", 100);
			sld.items.spyglass3 = 0;
			sld.items.spyglass5 = 1;
			EquipCharacterbyItem(sld, "spyglass5");
			sld.name = "Edward";
			sld.lastname = "(Barbe-Noire) Teach";
			sld.dialog.filename   = "Quest\BlackBeard.c";
			sld.dialog.currentnode   = "Greetings";
			sld.greeting = "";
			sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
			sld.items.GunEchin = 30;
			LAi_SetCharacterUseBullet(sld, "GunEchin");//зарядить патрики покруче
			FantomMakeCoolSailor(sld, SHIP_FRIGATEQUEEN, "Queen Anne's Revenge", CANNON_TYPE_CANNON_LBS36, 90, 90, 90);
			GiveItem2Character(sld, "cirass5");
			EquipCharacterbyItem(sld, "cirass5");

			DeleteAttribute(sld, "DontClearDead");
			DeleteAttribute(sld, "AboardToFinalDeck");
			DeleteAttribute(sld, "SinkTenPercent");
			DeleteAttribute(sld, "DontRansackCaptain");
			sld.AlwaysFriend = true;
			sld.AlwaysSandbankManeuver = true;
			sld.DontRansackCaptain = true; //не сдаваться

			SelAllPerksToNotPChar(sld);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "AgileMan"); // ловкач
			sld.SuperShooter  = true;
			SetSPECIAL(sld, 10,10,10,10,10,10,10); // SPECIAL (Сила, Восприятие, Выносливость, Лидерство, Обучаемость, Реакция, Удача)
			SetSelfSkill(sld, 100, 100, 100, 100, 100); //лёгкое, среднее, тяжёлое, пистолет, удача
			SetShipSkill(sld, 100, 100, 100, 100, 100, 100, 100, 100, 100); // лидерство, торговля, точность, пушки, навигация, ремонт, абордаж, защита, скрытность
			LAi_SetHP(sld,1500,1500);
			SetCharacterPerk(sld, "Grunt"); //рубака
			AddBonusEnergyToCharacter(sld, 50);
			TakeNItems(sld, "potion2",10);

			//в морскую группу кэпа
			sGroup = "BlackBeardGroup";
			Group_FindOrCreateGroup(sGroup);
			Group_AddCharacter(sGroup, sld.id);
			Group_SetGroupCommander(sGroup, sld.id);
			Group_SetType("BlackBeardGroup", "pirate");
			SetCharacterRelationBoth(sti(sld.index), GetMainCharacterIndex(), RELATION_FRIEND);
			SetRandGeraldSail(sld, sti(sld.Nation));
			sld.quest = "InMap"; //личный флаг искомого кэпа
			sld.city = "LaVega"; //определим колонию
			sld.cityShore = GetIslandRandomShoreId(GetArealByCityName(sld.city));
			sld.quest.targetCity = GetRandomPirateCity(); //определим колонию, в бухту которой он придёт
			sld.quest.targetShore = GetIslandRandomShoreId(GetArealByCityName(sld.quest.targetCity));
			Log_TestInfo("The frigate Queen Anne's Revenge left: " + sld.city + " and headed to: " + sld.quest.targetShore);
			//==> на карту
			sld.mapEnc.type = "trade";
			//выбор типа кораблика на карте
			sld.mapEnc.worldMapShip = "Tich_MKA"; // LEO: Сюда надо заюзать модельку МКА на глобалку, персональную.
			sld.mapEnc.Name = "La frégate 'Queen Anne's Revenge'";
			int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sld.quest.targetCity), GetArealByCityName(sld.city)) + 1; //дней доехать даём с запасом
			Map_CreateTrader(sld.cityShore, sld.quest.targetShore, sld.id, daysQty);
			//заносим Id кэпа в базу нпс-кэпов
			sTemp = sld.id;
			NullCharacter.capitainBase.(sTemp).quest = "BlackBeard"; //идентификатор квеста
			NullCharacter.capitainBase.(sTemp).questGiver = "none"; //запомним Id квестодателя для затирки в случае чего
			NullCharacter.capitainBase.(sTemp).Tilte1 = "BlackBeard"; //заголовок квестбука
			NullCharacter.capitainBase.(sTemp).Tilte2 = "BlackBeard"; //имя квеста в квестбуке
			NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
			NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
			NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
			NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
			break;
		}
		
		if (CheckAttribute(pchar,"questTemp.Slavetrader") && pchar.questTemp.Slavetrader == "wait_6" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_6") > 1 && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_6") < 7)
		{
			dialog.text = "Des marins du ''Mavrody'' sont passés récemment. Ils disaient qu'ils attendaient de partir d'un jour à l'autre. Le bruit court que le ''Mavrody'' est le navire de notre banquier, qu'il l'a acheté il n'y a pas si longtemps. C'est un peu bizarre, il n'avait pas quitté notre île depuis des années...";
			Log_Info("Oם va donc mon associé ? Je devrais peut-être aller voir ce ''Mavrody'' ?");
			pchar.questTemp.Slavetrader = "Mavrody";
			
			ref sld1 = characterFromId(pchar.questTemp.Slavetrader.UsurerId);
			sld = GetCharacter(NPC_GenerateCharacter("FakeSlaveTrader", sld1.model, "man", "man", 60, sld1.nation, -1, true));
			sld.name = sld1.name;
			sld.lastname = sld1.lastname;
			FantomMakeCoolFighter(sld, sti(PChar.rank), 90, 90, "blade20", "pistol5", 100);
			
			FantomMakeCoolSailor(sld, SHIP_FLEUTWAR, "Mavrody", CANNON_TYPE_CANNON_LBS24, 90, 90, 90);
			realships[sti(sld.ship.type)].SpeedRate = 16.9; //Увеличиваем скорость
			realships[sti(sld.ship.type)].TurnRate  = 24; //Увеличиваем маневренность
			realships[sti(sld.ship.type)].HP = 4000; //Фиксируем ХП
			realships[sti(sld.ship.type)].Capacity = 3600; //Фиксируем трюм
			realships[sti(sld.ship.type)].MastMultiplier = 1.3; //Упрочняем мачты
			realships[sti(sld.ship.type)].MaxCrew = 222;
			realships[sti(sld.ship.type)].MinCrew = 35;
			realships[sti(sld.ship.type)].OptCrew = 180;
			SetCrewQuantity(sld,GetMaxCrewQuantity(sld));
			
			DeleteAttribute(sld, "DontClearDead");
			DeleteAttribute(sld, "AboardToFinalDeck");
			DeleteAttribute(sld, "SinkTenPercent");
			DeleteAttribute(sld, "DontRansackCaptain");
			sld.AlwaysEnemy = true;
			sld.AlwaysSandbankManeuver = true;
			sld.DontRansackCaptain = true; //не сдаваться
			
			sld.quest = "InShore"; //флаг кэпа стоит в порту
			int iColony1 = FindColony(sld1.City);
			sGroup = "Slavetrader";
			group_DeleteGroup(sGroup);
			Group_AddCharacter(sGroup, sld.id);
			Group_SetGroupCommander(sGroup, sld.id);
			Group_SetAddress(sGroup, colonies[iColony1].island, "quest_ships", "Quest_ship_"+(rand(2)+3));
			Group_SetTaskRunaway(sGroup,PLAYER_GROUP);
			
			break;
		}

		if (!CheckAttribute(pchar, "PGG_killed_known")) pchar.PGG_killed_known = 0;
		if (CheckAttribute(pchar, "PGG_killed") && sti(pchar.PGG_killed) > 4 && pchar.PGG_killed != pchar.PGG_killed_known)
		{
			pchar.PGG_killed_known = pchar.PGG_killed;
			dialog.text = "On dit que dans nos eaux "+GetSexPhrase("s'est installé un chasseur d'honnêtes corsaires, ", "s'est installée une chasseuse d'honnêtes corsaires, ") + GetFullName(pchar) + ". Le nombre d'âmes que cette personne a envoyées dans l'autre monde atteint déjà " + pchar.PGG_killed + ". Toutes des gens respectés dans le coin. Brr... Je commence à me sentir mal. Est-ce le rhum, ou toute cette histoire...";
			break;
		}
		//Титаник
		if (CheckAttribute(pchar, "TitanicRumour") && rand(100) > 80)
		{
			AddQuestRecord("WhisperTitanic", 6);
			AddQuestUserData("WhisperTitanic", "sCity", XI_ConvertString("Colony" + pchar.TitanicCity));
			DeleteAttribute(pchar, "TitanicRumour");
			dialog.text = "דa, c'est du rhum ! Au fait, capitaine, je ne vous conseille pas d'aller à " + XI_ConvertString("Colony" + pchar.TitanicCity) + ". Il y a là-bas en ce moment une forteresse flottante anglaise. Le « Titanic », qu'elle s'appelle, il me semble...";
			break;
		}
		//BlackThorn викинг
		if (CheckAttribute(pchar, "questTemp.pirateVikingQuest") && rand(100) > 60)
		{
			if (CheckAttribute(pchar, "LastHearedViking") && pchar.LastHearedViking != npchar.city)
			{
				if (pchar.questTemp.pirateVikingQuest == "4")
				{
					if(ShipsTypes[sti(RealShips[sti(pchar.Ship.Type)].BaseType)].Type.Merchant == true && GetCompanionQuantity(pchar) == 1)
					{
						if (GetSquadronGoods(Pchar, GOOD_EBONY) >= 600 || GetSquadronGoods(Pchar, GOOD_SILK) >= 1000 || GetSquadronGoods(Pchar, GOOD_SILVER) >= 400)
						{
							dialog.text = "Je vois que vous êtes un marchand chevronné, capitaine, vous en avez vu de toutes les couleurs. Mais quand même, même si je ne suis pas marin moi-même, je vous donnerais un conseil : ne prenez pas la mer aujourd'hui. On a aperçu dans les eaux environnantes un chébec pirate qui chasse justement les gens comme vous.";
							link.l1 = "Ha ! On ne fait pas peur à un hérisson avec une aiguille. Si ce caillou me tombe sous la main, considère qu'il est déjà par le fond. Bon, au revoir.";
							link.l1.go = "exit_sit";
							AddQuestRecord("pirateVikingQuest", "6");
							//Можно будет вызвать повторно, если ещё не убили
							//pchar.questTemp.pirateVikingQuest = "5";
							pchar.LastHearedViking = npchar.city;

							if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("pirateVikingQuest_Captain", "OZG_3", "man", "man_fast", 20, PIRATE, -1, true)); // LEO: Превозмогаторам - страдать 01.12.2021
							else sld = GetCharacter(NPC_GenerateCharacter("pirateVikingQuest_Captain", "OZG_3", "man", "man", 20, PIRATE, -1, true));
							sld.mapEnc.worldMapShip = "quest_ship";
							sld.mapEnc.Name = "chébec 'Drakkar'";
							sld.mapEnc.type = "war";
							FantomMakeCoolFighter(sld, 20, 80, 80, "topor_viking", "pistol3", 100 * MOD_SKILL_ENEMY_RATE + 100);
							FantomMakeCoolestSailor(sld, SHIP_REQUIN, "Drakkar", CANNON_TYPE_CANNON_LBS24, 80, 80, 60);

							sld.name 	= "Ragnar";
							sld.lastname = "Lodbrok";
							sld.AlwaysSandbankManeuver = true;
							sld.DontRansackCaptain = true;
							sld.AnalizeShips = true;
							sld.Frenzy = true;
							AddBonusEnergyToCharacter(sld, MOD_SKILL_ENEMY_RATE*75);
							if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
							SetCharacterPerk(sld, "MusketsShoot");

							sld.ship.Crew.Morale = 100;
							ChangeCrewExp(sld, "Sailors", 80);
							ChangeCrewExp(sld, "Cannoners", 80);
							ChangeCrewExp(sld, "Soldiers", 60);

							GiveItem2Character(sld, "cirass3");
							EquipCharacterbyItem(sld, "cirass3");
							GiveItem2Character(sld, "talisman10");
							EquipCharacterbyItem(sld, "talisman10");
							GiveItem2Character(sld, "jewelry9");
							SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
							TakeNItems(sld, "Food5", 15);
							TakeNItems(sld, "potion2", 5);
							TakeNItems(sld, "StrangePotion", 1);
							sld.SaveItemsForDead = true;
							sld.DontClearDead = true;

							LAi_group_MoveCharacter(sld, "Vikings");
							string  sGroup = "Sea_" + sld.id;
							group_DeleteGroup(sGroup);
							Group_FindOrCreateGroup(sGroup);
							Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
							Group_LockTask(sGroup);
							Group_AddCharacter(sGroup, sld.id);
							Group_SetGroupCommander(sGroup, sld.id);
							Map_CreateWarrior("", sld.id, 8);
							SetFunctionNPCDeathCondition("PirateVikingQuest_Captain_Is_Dead", sld.id, false);
							pchar.questTemp.pirateVikingQuest.pcharShipType = pchar.Ship.Type;
							Pchar.quest.pirateVikingShipMapEnterCheck.win_condition.l1 = "MapEnter";
							Pchar.quest.pirateVikingShipMapEnterCheck.win_condition = "ReleaseCheck_pirateVikingShip";
							break;
						}
						else
						{
							dialog.text = "On dit qu'un navire pirate rכde dans les eaux environnantes. Mais vous n'avez rien à craindre, capitaine. Même si vous avez un navire marchand, ils ne voudront sans doute pas gaspiller leurs forces pour une cargaison aussi maigre.";
						}
					}
					else
					{
						dialog.text = "On dit qu'un navire pirate rכde dans les eaux environnantes. Mais vous n'avez rien à craindre, capitaine. Ils ne chassent que les navires marchands isolés.";
					}
				}
				if (pchar.questTemp.pirateVikingQuest == "3")
				{
					dialog.text = "On dit que le marchand d'ici va poursuivre en justice un malheureux capitaine. Il avait affrété son navire pour livrer une grosse cargaison de soie de Chine, mais le capitaine est arrivé la cale vide ! Vous savez, il y a beaucoup d'argent en jeu. Le capitaine accusé dit qu'il a été dévalisé par un chébec dont le capitaine est un blond aux yeux bleus. Tout l'équipage le confirme. Il y a même les dégâts du combat sur le navire, quelques bosses de boulets, une membrure endommagée, mais le marchand ne le croit toujours pas. Il répète à chaque fois que les preuves sont fabriquées, et que le capitaine et son équipage mentent. Mais moi, je me dis : pourquoi mentirait-il ? Il a transporté du fret plus d'une dizaine de fois, avec des cargaisons bien plus précieuses. S'il avait voulu voler, il l'aurait fait depuis longtemps.";
					AddQuestRecord("pirateVikingQuest", "4");
					AddQuestRecord("pirateVikingQuest", "5");
					pchar.questTemp.pirateVikingQuest = "4";
					pchar.LastHearedViking = npchar.city;
					break;
				}
				if (pchar.questTemp.pirateVikingQuest == "2")
				{
					dialog.text = "Je ne vous conseille pas de prendre la mer, capitaine. D'habitude, il n'y avait que des pirates, mais maintenant il y a aussi de vrais Vikings ! Un marchand n'a pas voulu leur céder l'argent de sa cale jusqu'au bout, en espérant naïvement pouvoir les repousser. Il l'a payé de la vie de son équipage. Avec l'épave de son navire, un pauvre marin miraculeusement rescapé s'est échoué récemment dans une baie d'ici. C'est lui qui m'a raconté cette histoire. Il dit avoir vu ces brutes de ses propres yeux. Ils sont grands, féroces, et ils parlent une langue incompréhensible !";
					AddQuestRecord("pirateVikingQuest", "3");
					pchar.questTemp.pirateVikingQuest = "3";
					pchar.LastHearedViking = npchar.city;
					break;
				}
				if (pchar.questTemp.pirateVikingQuest == "1")
				{
					dialog.text = "Vous avez entendu, capitaine ? Un marchand qui vend d'habitude de l'ébène est rentré récemment dans notre port. Seulement, cette fois, il est revenu la cale vide. On dit qu'il a été intercepté en mer par un navire appelé le Drakkar. Le capitaine a sagement hissé le pavillon blanc et a été épargné, mais il a été dépouillé jusqu'à l'os. Il est maintenant complètement ruiné et ne peut plus poursuivre ses affaires. Il compte retourner en Europe, auprès de sa famille.";
					AddQuestRecord("pirateVikingQuest", "2");
					pchar.questTemp.pirateVikingQuest = "2";
					pchar.LastHearedViking = npchar.city;
					break;
				}
			}
		}
		// "Gang and patrol skirmish": rumor about the player's deeds in the jungle (variety + betrayal)
		// затухание по времени: больше месяца - быль быльём поросла (иначе слух жил вечно, фикс 12.06.2026)
		if (CheckAttribute(pchar, "GangWarRumor"))
		{
			int gwAge = 999;
			if (CheckAttribute(pchar, "GangWarRumorDay")) gwAge = DateToInt(0) - sti(pchar.GangWarRumorDay);
			if (gwAge > 30)
			{
				DeleteAttribute(pchar, "GangWarRumor");
				DeleteAttribute(pchar, "GangWarRumorTold");
				DeleteAttribute(pchar, "GangWarRumorDay");
			}
		}
		if (CheckAttribute(pchar, "GangWarRumor") && rand(100) > 55)
		{
			string gwr = pchar.GangWarRumor;
			if (gwr == "patrol")
			{
				switch (rand(2))
				{
					case 0: dialog.text = "Vous avez entendu ce qui se passe dans la jungle ? On dit qu'un capitaine, peut-être "+ GetFullName(pchar) +", peut-être quelqu'un d'autre, s'est battu coude à coude avec une patrouille et a taillé en pièces toute une bande de bandits. La Couronne est toujours heureuse d'avoir de tels auxiliaires."; break;
					case 1: dialog.text = "Les gens disaient qu'une patrouille était tombée sur des bandits dans les fourrés, et qu'un hardi capitaine avait prêté main-forte aux soldats : il a mis en terre tous ces coupe-jarrets. C'est peut-être un mensonge, ou peut-être pas... Ressers-moi !"; break;
					case 2: dialog.text = "Ah, quelle époque... On dit qu'un marin a pris le parti des soldats dans la jungle et a aidé une patrouille à anéantir une bande. Un honnête homme, à ce qu'il paraît, qui défend l'ordre."; break;
				}
			}
			if (gwr == "bandits")
			{
				switch (rand(2))
				{
					case 0: dialog.text = "J'en ai entendu murmurer quelque chose... Il paraît qu'un capitaine s'est acoquiné avec les bandits de la jungle et les a aidés à massacrer toute une patrouille. Il a passé jusqu'au dernier soldat au fil de l'épée, dit-on. Brr..."; break;
					case 1: dialog.text = "Le bruit court qu'une bande a tendu une embuscade à des soldats dans les fourrés, et qu'un marin s'est rangé du cכté des brigands. Maintenant, cette bande le considère comme l'un des siens. Un mauvais sang, celui-là."; break;
					case 2: dialog.text = "De sombres affaires dans la jungle, l'ami. On dit qu'un capitaine a pris la défense des coupe-jarrets contre une patrouille royale. Mieux vaut ne pas avoir affaire à ce genre d'individu."; break;
				}
			}
			if (gwr == "betrayPatrol")
			{
				switch (rand(2))
				{
					case 0: dialog.text = "Une drכle d'histoire, je vous le jure ! D'abord, dit-on, un capitaine a taillé une bande en pièces, coude à coude avec une patrouille, et une fois les brigands éliminés, il s'est retourné contre les soldats eux-mêmes ! Un Judas, ni plus ni moins."; break;
					case 1: dialog.text = "Vous avez entendu ? Un marin a aidé les soldats dans la jungle, puis il leur a fait goמter sa propre lame. Pas de confiance pour ce genre d'individu : avec vous aujourd'hui, un couteau dans le dos demain."; break;
					case 2: dialog.text = "On dit que quelqu'un a aidé une patrouille à achever une bande, puis s'en est pris aux soldats ensuite. La Couronne n'oublie pas ce genre d'hommes, oh non..."; break;
				}
			}
			if (gwr == "betrayBandits")
			{
				switch (rand(2))
				{
					case 0: dialog.text = "Hé, vous connaissez l'histoire ? Un capitaine a aidé une bande à abattre une patrouille, il a reçu leurs remerciements, et ensuite il a lui-même envoyé ses frères dans l'autre monde. Même chez les brigands, ça ne se fait pas."; break;
					case 1: dialog.text = "On dit qu'un marin a prêté main-forte à une bande dans la jungle, et qu'une fois l'affaire faite, il les a tous massacrés. Audacieux, mais perfide. דa fait peur rien que de boire avec un type pareil."; break;
					case 2: dialog.text = "On murmurait que quelqu'un s'était acoquiné avec les brigands, les avait aidés, puis les avait lui-même abattus. Que de traîtrise, l'ami ! Sers-m'en un, tu veux."; break;
				}
			}
			if (gwr == "massacre")
			{
				switch (rand(2))
				{
					case 0: dialog.text = "Vous avez entendu ? Quelqu'un a fait un vrai carnage dans la jungle : patrouille et bande de bandits, tous abattus jusqu'au dernier ! Il ne faisait pas la différence entre amis et ennemis. Une brute sauvage, Dieu me pardonne."; break;
					case 1: dialog.text = "On dit qu'on a trouvé un tas de cadavres dans les fourrés : soldats et bandits, tous mélangés. Un capitaine les a tous mis en terre d'un coup. דa fait peur rien que de partager la route avec un type pareil."; break;
					case 2: dialog.text = "Drכles d'affaires... Il y a eu un combat dans la jungle, dit-on : une bande contre une patrouille. Puis un marin est arrivé et a abattu les deux camps. Ni amis ni ennemis n'ont survécu. Brr, sers-m'en un !"; break;
				}
			}
			// the news fades with time (a few retellings and it's forgotten)
			int gwTold = 0;
			if (CheckAttribute(pchar, "GangWarRumorTold")) gwTold = sti(pchar.GangWarRumorTold);
			gwTold++;
			pchar.GangWarRumorTold = gwTold;
			if (gwTold >= 4) { DeleteAttribute(pchar, "GangWarRumor"); DeleteAttribute(pchar, "GangWarRumorTold"); }
			break;
		}
		// "Laying the Dead to Rest" quest: rumor that the player cleared the graveyard of undead (variety)
		// затухание по времени: больше месяца - быль быльём поросла (иначе слух жил вечно, фикс 12.06.2026)
		if (CheckAttribute(pchar, "GraveyardRumor"))
		{
			int gyAge = 999;
			if (CheckAttribute(pchar, "GraveyardRumorDay")) gyAge = DateToInt(0) - sti(pchar.GraveyardRumorDay);
			if (gyAge > 30)
			{
				DeleteAttribute(pchar, "GraveyardRumor");
				DeleteAttribute(pchar, "GraveyardRumorTold");
				DeleteAttribute(pchar, "GraveyardRumorDay");
			}
		}
		if (CheckAttribute(pchar, "GraveyardRumor") && rand(100) > 55)
		{
			string gyCity = XI_ConvertString("Colony" + pchar.GraveyardRumor + "Gen");
			switch (rand(3))
			{
				case 0: dialog.text = "Vous avez entendu ? Les morts-vivants avaient envahi le cimetière de "+ gyCity +" : les morts sortaient de leurs tombes. Mais un hardi capitaine est passé par là et les a tous renvoyés au repos éternel. Ceux qui sont enterrés là-bas peuvent dormir tranquilles maintenant."; break;
				case 1: dialog.text = "On dit qu'il se passait des choses terribles au vieux cimetière de "+ gyCity +" : des squelettes erraient parmi les pierres tombales, et quelque chose de vraiment épouvantable rכdait dans le caveau et la crypte. Puis un marin y est allé et a tout nettoyé. Il faut du courage pour descendre dans une crypte."; break;
				case 2: dialog.text = "Les gens disent que quelqu'un a abattu toute une armée de morts au cimetière de "+ gyCity +". Moi, je ne crois pas trop à ces histoires... mais on dit que le gardien de là-bas est plus joyeux depuis. Sers-m'en un, tu veux."; break;
				case 3: dialog.text = "Buvons aux morts, l'ami ! C'est enfin calme au cimetière de "+ gyCity +" : une âme courageuse a renvoyé tous les morts-vivants au repos éternel. Il était temps, ils ne laissaient même pas les morts tranquilles."; break;
			}
			int gyTold = 0;
			if (CheckAttribute(pchar, "GraveyardRumorTold")) gyTold = sti(pchar.GraveyardRumorTold);
			gyTold++;
			pchar.GraveyardRumorTold = gyTold;
			if (gyTold >= 4) { DeleteAttribute(pchar, "GraveyardRumor"); DeleteAttribute(pchar, "GraveyardRumorTold"); } // the news fades
			break;
		}
		Dialog.Text = LinkRandPhrase("Eh bien... hic ! ", "Oh, quel rhum ! ", "Eh bien... ")+SelectRumourEx("habitue", NPChar);
	break;
//Black Sails
		case "BS_NU_11":
            dialog.text = "Eh bien. C'est bien passé, merci. Bref. Le pirate, sur la corvette survivante, a compris que ça tournait mal, il s'est mis vent arrière et a filé à l'horizon toutes voiles dehors ! Et sur le brick, on a coupé la chaîne de l'ancre et on s'est jeté contre le flanc de la frégate. Ils sont montés à l'abordage. Et ils ont vaincu les Espagnols ! La frégate a hissé le pavillon noir, a tiré une bordée sur le brick malmené et s'en est allée, quelque part vers le nord. Quelle bataille, on aurait dit un tableau ! Toute la cכte est jonchée de débris.";
            link.l1 = "Merci pour l'histoire. Avec un tel talent, tu devrais écrire des livres !";
			link.l1.go = "exit_sit";

			BSBons_SeaBattle(true);
			AddQuestRecord("BSUrka", "3");
			PChar.quest.BSUrka_Pirates_town.win_condition.l1 = "location";
			PChar.quest.BSUrka_Pirates_town.win_condition.l1.location = "Nassau_town";
			PChar.quest.BSUrka_Pirates_town.function = "BSUrka_Pirates_town";
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "rumours_trader":
            if (!CheckAttribute(NPChar, "quest.repeat.rumours_trader") || NPChar.quest.repeat.rumours_trader!= 3 )
            strum = SelectRumourEx("trader", NPChar);
            else strum = GetNoRumourText("trader"); // exclude self-referential [11] about the shop owner
			Dialog.Text =  NPCStringReactionRepeat(strum, strum+" Oui. Je ne me souviens de rien d'autre.",
                                                   strum+" Et maintenant, je dois retourner à mes affaires.",
                                                    RandPhraseSimple("Je vous ai déjà dit que je n'avais pas de temps pour les bavardages !",
                                                                        "Je suis quelqu'un d'occupé et je n'ai pas le temps de discuter de toutes sortes de ragots !"),
                                                                         "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(pcharrepphrase(RandSwear() + "C'est très intéressant ! Mais venons-en au fait", "Merci ; alors voici autre chose."),
                                                pcharrepphrase(""+ GetSexPhrase("Que je meure", "Mille tonnerres") +" ! Vous êtes un sacré menteur. Mais j'ai une autre question.",
                                                                "Alors ne perdons plus un temps précieux et passons aux affaires."),
                                                pcharrepphrase(RandSwear() +"Encore une chose, et je m'en vais", ". Vous avez raison, le temps, c'est de l'argent."),
                                                pcharrepphrase("Vous ne pensez qu'à votre intérêt. Bon, ne vous énervez pas.",
                                                                "Pardonnez-moi, je vous en prie. Passons aux affaires."),
                                                npchar, Dialog.CurrentNode);

			link.l1.go = "business";
			link.l2 = HeroStringReactionRepeat(NPCharRepPhrase(npchar,
			                                        pcharrepphrase("Salut, vieil ivrogne.",
													               "Bonne journée, "+GetAddress_FormToNPC(NPChar)+" " +GetFullName(npchar)+"."),
													pcharrepphrase("Caramba ! Ne bouge pas. Je reviendrai.",
													               "Ravi de vous voir, "+GetAddress_FormToNPC(NPChar)+" " +GetFullName(npchar)+" ! Au revoir !")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Larguez les amarres !",
													               "Au revoir, mon cher."),
													pcharrepphrase("Hé ! Qu'est-ce que tu caches là ? Du rhum ? Non ?! Bon, je vais aller me rincer le gosier.",
													               "Veuillez m'excuser, j'ai une affaire urgente en ville.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Hé ! א la prochaine !",
													               "Je dois y aller. Au revoir, "+GetAddress_FormToNPC(NPChar)+" " +GetFullName(npchar)+" !"),
													pcharrepphrase("Et ne t'avise pas de me contredire ! Je n'ai pas le temps de discuter avec toi !",
													               "Il vaudrait peut-être mieux aller voir comment ça se passe à bord. Au revoir, "+GetAddress_FormToNPC(NPChar)+" " +GetFullName(npchar)+" !")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Qu'est-ce qui t'arrive, vieux ? C'est moi, " +GetFullName(pchar)+ " ! Cuve ton vin, je reviendrai plus tard.",
													               "J'ai bien peur que ton foie ne t'achève avant que je repasse par ici."),
													pcharrepphrase("Compte tes piastres, canaille ! Je reviendrai.",
													               "Ravi de vous voir, " + GetAddress_FormToNPC(NPChar)+" " +GetFullName(npchar)+" !")),
											  npchar, Dialog.CurrentNode);
			link.l2.go = "Exit";
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        case "rumours_capitan":
			Dialog.Text = SelectRumourEx("capitan", NPChar);
			Link.l1 = RandPhraseSimple(RandSwear() + "C'est très intéressant ! Je voulais vous demander...",
                                     "Encore une question.");
			Link.l1.go = "quests";
			Link.l2 = RandPhraseSimple("Merci, merci, je prends congé.",
                                     "Bonne journée");
			Link.l2.go = "exit";
			NextDiag.TempNode = "quests";
            NPChar.talk_date =  lastspeakdate();
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "rumours_tavern":  // homo 03/08/06
                 Dialog.Text = NPCStringReactionRepeat(LinkRandPhrase("Toute information vaut de l'argent. Pour la modique somme de 1000 pièces, je vous dirai tout.",
                "J'ai presque tout oublié. Mais 1000 pièces m'aideront peut-être à me souvenir.",
                "Je suis prêt" + NPCharSexPhrase(NPChar, "", "e") + " à vous dire tout ce que je sais. Mais seulement pour 1000 pièces, pas moins" + NPCharSexPhrase(NPChar, "ous", "ous") + "."),
                "Je n'ai rien de plus à ajouter. Maintenant, si vous voulez bien m'excuser, les affaires n'attendent pas.",
                "", "", "block", 1, npchar, Dialog.CurrentNode);

    			link.l1 = HeroStringReactionRepeat(RandPhraseSimple(RandSwear() + "Payer pour des bavardages creux ? Non, cherchez quelqu'un d'autre.",
                                         "Pour une somme pareille, j'apprendrai tout moi-même."), "Parlons d'autre chose.", "Parlons d'autre chose.", "Parlons d'autre chose.", npchar, Dialog.CurrentNode);
                link.l1.go = HeroStringReactionRepeat("rumours_tavern_no", "first time", "first time", "first time", npchar, Dialog.CurrentNode);//"rumours_tavern_no";
                NextDiag.CurrentNode = NextDiag.TempNode;
    			if (makeint(pchar.money) >= 1000 )
    			{
    				link.l2 = HeroStringReactionRepeat(RandPhraseSimple("Vous les aurez si j'obtiens des informations vraiment précieuses.", "Je paierai, mais seulement si vous me dites quelque chose de vraiment important."),
                     "", "", "" , npchar, Dialog.CurrentNode);
    				link.l2.go = HeroStringReactionRepeat("rumours_tavern_yes", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
    			}
    			else
    			{
                    link.l2 =  HeroStringReactionRepeat("Je n'ai pas cette somme.", "", "", "", npchar, Dialog.CurrentNode);
    				link.l2.go = HeroStringReactionRepeat("rumours_tavern_no", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
    			}

		break;

		case "rumours_tavern_yes":

			//------------- квестовые слухи тавернщика --------->>>>>>>>
			//пиратка, квест №3
			if (pchar.questTemp.piratesLine == "KillLoy_toCumana")
			{
				Dialog.Text =  "Ces derniers temps, des navires disparaissent souvent, et, chose étrange, ce ne sont que des lougres courriers et des sloops. On parle de l'apparition d'un brick dans les eaux de Cumaná... Alors soyez prudent !";
				link.l1 = "Seulement des lougres courriers, dites-vous ? Très intéressant... Vous savez autre chose de remarquable ?";
				link.l1.go = "rumours_tavern";
				AddQuestRecord("Pir_Line_3_KillLoy", "14");
				AddQuestUserData("Pir_Line_3_KillLoy", "sSex", GetSexPhrase("", "e"));
				pchar.questTemp.piratesLine = "KillLoy_toCumana_2";
				break;
			}
			//ОЗГ, Крыса на Тортуге
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
	    		if (pchar.questTemp.Headhunter == "Rat_tortuga" && npchar.location == "Tortuga_tavern")
	    		{
	    			Dialog.Text =  "On dit que le capitaine et propriétaire de la pinasse Adelaide a conclu un marché avec d'Ogeron et qu'il appareille ces jours-ci. Tout son équipage traîne au bordel et dans ma taverne depuis une semaine. Dieu merci, ils vont enfin débarrasser le plancher, le plus tכt sera le mieux... Et le capitaine lui-même se repose chez moi en ce moment : vous voyez, il est assis là-bas, à une table ronde. Un marin remarquable...";
	    			link.l1 = "Très intéressant... Vous savez autre chose de remarquable ?";
	    			link.l1.go = "rumours_tavern";
	    			pchar.quest.Headhunter_PinasseTortugaOver.over = "yes";
	    			AddQuestRecord("Headhunt", "17");
	    			pchar.questTemp.Headhunter = "Rat_officer";
	    			FreeSitLocator("Tortuga_tavern", "sit1");
	    			SetFunctionTimerCondition("Headhunter_RatOfficerOver", 0, 0, 3, false);//таймер
	    			break;
	    		}
			}
			//ОЗГ, Крыса на Тортуге
			//<<<<<-------- квестовые слухи тавернщика -----------------

            string RumText = SelectRumourEx("tavern", NPChar); //fix
            //SelectRumour();

		    if(!RumourHasInformation(RumText))
            {
                Dialog.Text = NO_RUMOUR_TEXT[rand(SIMPLE_RUMOUR_NUM - 1)]; //fix
                link.l1 = RandPhraseSimple("Je ne paierai pas pour des ragots creux, au revoir.", "Vos informations ne valent pas un clou : vous n'aurez rien.");

			    link.l1.go = "Exit";
			    NextDiag.CurrentNode = NextDiag.TempNode;
            }
            else
            {

                AddMoneyToCharacter(pchar, -1000);

                Dialog.Text = RumText;

    			link.l1 = RandPhraseSimple("Merci, voici votre or. Vous vous souvenez d'autre chose ?", "Eh bien, vous avez mérité votre argent, tenez. Il y a autre chose ?");

    			link.l1.go = "rumours_tavern";
    			NextDiag.CurrentNode = NextDiag.TempNode;
            }

		break;

		case "rumours_tavern_no":
			Dialog.Text = "Ne vous méprenez pas, je dois nourrir ma famille.";
            link.l1 = "Parlons d'autre chose.";
			link.l1.go = "first time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			link.l2 = LinkRandPhrase("Merci, je prends congé.",
                                     "Bonne journée", "Au revoir.");
			link.l2.go = "Exit";
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        case "rumours_poor":
			if (!CheckAttribute(NPChar, "quest.repeat.rumours_poor") || NPChar.quest.repeat.rumours_poor <= 1)
			{
				Dialog.Text = SelectRumourEx("poor", NPChar);
				Link.l1 = RandPhraseSimple(RandSwear() + "Oui, c'est intéressant. J'ai une autre question...",
										"Je voulais vous demander...");
				Link.l1.go = "rumours_poor_2";
				Link.l2 = RandPhraseSimple("Eh bien, au revoir, filou.",
										"Bonne journée, l'ami.");
				Link.l2.go = "exit";
				NPChar.quest.repeat.rumours_poor = sti(NPChar.quest.repeat.rumours_poor) + 1;
			}
			else
			{
				Dialog.Text = RandPhraseSimple("Il n'y a plus rien à dire, j'ai déjà déballé tout ce que je savais.",
					"Je n'ai rien entendu d'autre, désolé...");
				Link.l1 = RandPhraseSimple("Je vois. Eh bien, bonne journée.",
										"Je vois. Eh bien, au revoir, l'ami...");
				Link.l1.go = "exit";
			}
            NPChar.talk_date = lastspeakdate();
		break;
        case "rumours_poor_2":
			if (NPChar.quest.repeat.rumours_poor <= 1)
			{
				Dialog.Text = SelectRumourEx("poor", NPChar);
				Link.l1 = RandPhraseSimple(RandSwear() + "Oui, c'est intéressant. J'ai une autre question...",
										"Je voulais vous demander...");
				Link.l1.go = "rumours_poor";
				Link.l2 = RandPhraseSimple("Eh bien, au revoir, filou.",
										"Bonne journée, l'ami.");
				Link.l2.go = "exit";
				NPChar.quest.repeat.rumours_poor = sti(NPChar.quest.repeat.rumours_poor) + 1;
			}
			else
			{
				Dialog.Text = RandPhraseSimple("Il n'y a plus rien à dire, j'ai déjà déballé tout ce que je savais.",
					"Je n'ai rien entendu d'autre, désolé...");
				Link.l1 = RandPhraseSimple("Je vois. Eh bien, bonne journée.",
										"Je vois. Eh bien, au revoir, l'ami...");
				Link.l1.go = "exit";
			}
			NPChar.talk_date = lastspeakdate();
		break;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        case "rumours_LSC":
			if (CheckNPCQuestDate(NPChar, "quest.repeat.rumours"))
			{
				Dialog.Text = SelectRumourExSpecial("LSC", NPChar);
				Link.l1 = RandPhraseSimple("Je vois...",
										"Je vois...");
				Link.l1.go = "exit";
				SetNPCQuestDate(NPChar, "quest.repeat.rumours");
			}
			else
			{
				Dialog.Text = NPCharSexPhrase(npchar, RandPhraseSimple("Il n'y a plus rien à dire, j'ai déjà déballé tout ce que je savais.", "Je n'ai rien entendu d'autre, désolé..."),
					RandPhraseSimple("Désolé, mais je vous ai déjà tout déballé.", "Je n'ai rien entendu d'autre, désolé..."));
				Link.l1 = RandPhraseSimple("J'ai compris.", "Eh bien, bonne journée.");
				Link.l1.go = "exit";
			}
		break;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Кредитный генератор Loan
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "LoanForAll": //пересылка в финансы для всех
			dialog.text = LinkRandPhrase("Des finances ? Hum, parlez, je vous écoute.", "Les questions financières sont toujours intéressantes. Parlez, je vous écoute.", "Eh bien, parlons finances.");
            if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
            {
                if (Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)].id == Npchar.id)
                {
                    dialog.text = LinkRandPhrase("Vous êtes sמr d'être au bon endroit, " + GetAddress_Form(NPChar) + " ? Je m'appelle " + GetFullName(npchar) + ". Que puis-je faire pour vous ?",
                             "Des finances, avec moi, " + GetAddress_Form(NPChar) + " ?! Je suis " + GetFullName(npchar) + ". Quelle affaire vous amène ?",
                             "Je vous écoute, " + GetAddress_Form(NPChar) + ". Que vouliez-vous ? Au fait, je m'appelle " + GetFullName(npchar) + ".");
                    link.l1 = NPCharRepPhrase(pchar, "Je viens de la part d'un usurier, débiteur ! L'argent sur la table !", "J'ai une question délicate à vous poser à propos de votre dette, " + GetAddress_FormToNPC(NPChar) + ".");
                    link.l1.go = "LoanFindCitizen_1";
				    NPChar.quest.LoanFindCitizenType = rand(2); // три типа
                    break;
                }
            }
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
            {
                link.l2 = "Je vous ai apporté votre crédit.";
                link.l2.go = "TakeChest_2";
            }
			link.l9 = RandPhraseSimple("Mmm, j'ai dמ me tromper. Je ne fais aucune affaire financière avec vous.", "Désolé, je n'ai pas de questions financières à vous poser.");
			link.l9.go = "exit";
		break;
		// вернуть долг ростовщику
		case "LoanFindCitizen_1":
            switch (sti(pchar.GenQuest.Loan.FindCitizenChance1))
            {
                case 0 :
                    dialog.text = "Oui, exactement. J'allais justement tout lui rendre.";
        			Link.l1 = "Eh bien, parfait ! Vous devez en tout " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ".";
        			Link.l1.go = "LoanFindCitizenType_0";
        			Link.l2 = "Parfait, alors prenez tout vous-même !";
        			Link.l2.go = "exit";
                break;

                case 1 :
                    dialog.text = "Non ! Je ne rendrai rien ! Si vous insistez, j'appelle la garde.";
                    Link.l1 = "Je n'en sais rien, j'en ai fini avec vous " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ". Sinon, on peut discuter autrement.";
        			Link.l1.go = "LoanFindCitizenType_1";
        			Link.l2 = "Oh, gredin ! Bon, tant pis, la Terre est ronde, on se reverra...";
        			Link.l2.go = "LoanFindCitizenType_1_1";
                break;

                case 2 :
                    dialog.text = "Malheureusement, je n'ai pas toute la somme.";
                    Link.l1 = "Je n'en sais rien, j'en ai fini avec vous " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ". Sinon, on peut discuter autrement.";
        			Link.l1.go = "LoanFindCitizen_1_1";
        			Link.l2 = "Combien avez-vous ?";
        			Link.l2.go = "LoanFindCitizenType_2";
        			//NPChar.quest.LoanFindCitizenType = rand(1);// первые 2 типа
                break;
			}
		break;

		case "LoanFindCitizen_1_1":
            switch (sti(pchar.GenQuest.Loan.FindCitizenChance2))
            {
                case 0 :
                    dialog.text = "Oui, exactement. J'allais justement tout lui rendre.";
        			Link.l1 = "Eh bien, parfait ! Vous devez en tout " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ".";
        			Link.l1.go = "LoanFindCitizenType_0";
        			Link.l2 = "Parfait, alors prenez tout vous-même !";
        			Link.l2.go = "exit";
                break;

                case 1 :
                    dialog.text = "Non ! Je ne rendrai rien ! Si vous insistez, j'appelle la garde.";
                    Link.l1 = "Je n'en sais rien, j'en ai fini avec vous " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ". Sinon, on peut discuter autrement.";
        			Link.l1.go = "LoanFindCitizenType_1";
        			Link.l2 = "Oh, gredin ! Bon, tant pis, la Terre est ronde, on se reverra...";
        			Link.l2.go = "LoanFindCitizenType_1_1";
                break;
			}
		break;

			case "LoanFindCitizen_1_2":
            switch (sti(pchar.GenQuest.Loan.FindCitizenChance3))
            {
                case 0 :
                    dialog.text = "Oui, exactement. J'allais justement tout lui rendre.";
        			Link.l1 = "Eh bien, parfait ! Vous devez en tout " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ".";
        			Link.l1.go = "LoanFindCitizenType_0";
        			Link.l2 = "Parfait, alors prenez tout vous-même !";
        			Link.l2.go = "exit";
                break;

                case 1 :
                    dialog.text = "Non ! Je ne rendrai rien ! Si vous insistez, j'appelle la garde.";
                    Link.l1 = "Je n'en sais rien, j'en ai fini avec vous " + FindRussianMoneyString(makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent))) + ". Sinon, on peut discuter autrement.";
        			Link.l1.go = "LoanFindCitizenType_1";
        			Link.l2 = "Oh, gredin ! Bon, tant pis, la Terre est ronde, on se reverra...";
        			Link.l2.go = "LoanFindCitizenType_1_1";
                break;
			}
		break;

		case "LoanFindCitizenType_0":
            dialog.text = "Voici toute la somme.";
			Link.l1 = "Merci de votre coopération !";
			Link.l1.go = "exit";
			pchar.GenQuest.Loan.FindCitizenDone = true;
        	addMoneyToCharacter(Pchar, (sti(pchar.GenQuest.Loan.FindCitizenMoney) + sti(pchar.GenQuest.Loan.FindCitizenPercent)));
        	SetTimerCondition("LoanFindCitizenTimer", 0, 0, 30, false);
        	Log_SetStringToLog("Vous avez 30 jours pour rendre compte à votre employeur et lui rapporter l'argent.");
        	AddCharacterExpToSkill(pchar, "COMMERCE", 100);
		AddCharacterExpToSkill(pchar, "Fortune", 50);
        	AddQuestRecord("Gen_LoanFindCitizen", "3");
			npchar.LifeDay = 0;
		break;

		case "LoanFindCitizenType_1_1":
            dialog.text = "Je suis heureux que nous soyons parvenus à un accord.";
			Link.l1 = "Vous vous souviendrez de moi plus tard !";
			Link.l1.go = "exit";
			pchar.GenQuest.Loan.FindCitizenFalied = true;
        	SetTimerCondition("LoanFindCitizenTimer", 0, 0, 30, false);
        	Log_SetStringToLog("Vous avez 30 jours pour annoncer à votre employeur l'échec de la mission.");
        	AddQuestRecord("Gen_LoanFindCitizen", "2");
			npchar.LifeDay = 0;
		break;

		case "LoanFindCitizenType_1":
            dialog.text = "Gardes !!! Au voleur !";
			Link.l1 = "La ferme !";
			Link.l1.go = "fight";
			pchar.GenQuest.Loan.FindCitizenFalied = true;
        	SetTimerCondition("LoanFindCitizenTimer", 0, 0, 30, false);
        	Log_SetStringToLog("Vous avez 30 jours pour annoncer à votre employeur l'échec de la mission.");
        	AddQuestRecord("Gen_LoanFindCitizen", "2");
			npchar.LifeDay = 0;
			AddCharacterExpToSkill(pchar, "Sneak", 150);
		break;

		case "LoanFindCitizenType_2":
            pchar.GenQuest.Loan.FindCitizenTempMoney = makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) - rand(sti(pchar.GenQuest.Loan.FindCitizenPercent)));
            dialog.text = "Seulement " + pchar.GenQuest.Loan.FindCitizenTempMoney + " pièces d'or.";
			Link.l1 = "Non. Il nous faut toute la somme !";
			Link.l1.go = "LoanFindCitizen_1_2";
			Link.l2 = "On a ce qu'on a. Je paierai le reste. Je suis de bonne humeur aujourd'hui.";
			Link.l2.go = "LoanFindCitizenType_2_1";
			//NPChar.quest.LoanFindCitizenType = rand(1);// первые 2 типа
		break;

		case "LoanFindCitizenType_2_1":
            dialog.text = "Vous êtes très bon ! Merci beaucoup !";
			Link.l1 = "Eh ! א chaque fois, je me mêle de tout.";
			Link.l1.go = "exit";
			pchar.GenQuest.Loan.FindCitizenDone = true;
        	addMoneyToCharacter(Pchar, sti(pchar.GenQuest.Loan.FindCitizenTempMoney));
        	SetTimerCondition("LoanFindCitizenTimer", 0, 0, 30, false);
        	Log_SetStringToLog("Vous avez 30 jours pour rendre compte à votre employeur et lui rapporter l'argent.");
        	OfficersReaction("good");
        	ChangeCharacterReputation(pchar, 3);
        	AddCharacterExpToSkill(pchar, "Leadership", 30);
        	AddQuestRecord("Gen_LoanFindCitizen", "3");
			npchar.LifeDay = 0;
		break;
		//доставка сундуков
        case "TakeChest_2":
            if (GetCharacterItem(pchar, "Chest") >= sti(pchar.GenQuest.LoanChest.Chest))
            {
                if (CheckAttribute(pchar, "GenQuest.LoanChest.Money.Discount"))
				{
					Dialog.Text = "Tout est en ordre, j'accepte votre or. Cependant, vous n'avez pas respecté le délai de livraison qui vous était imparti. Je dois donc réduire votre rémunération de " + pchar.GenQuest.LoanChest.Money.Discount + " pour cent. Je suis désolé, mais ce n'est pas négociable. Veuillez recevoir...";
					link.l1 = "Merci !";
    				link.l1.go = "exit";
					AddMoneyToCharacter(pchar, sti(pchar.GenQuest.LoanChest.Money)/100*sti(pchar.GenQuest.LoanChest.Money.Discount));
				}
				else
				{
					Dialog.Text = "Parfait ! Je l'attendais depuis longtemps. Voici votre récompense.";
					link.l1 = "Merci !";
    				link.l1.go = "exit";
					AddMoneyToCharacter(pchar, sti(pchar.GenQuest.LoanChest.Money));
				}
				ChangeCharacterReputation(pchar, 1);
                AddCharacterExpToSkill(pchar, "Sailing", 50);
				AddCharacterExpToSkill(pchar, "Leadership", 20);
				AddCharacterExpToSkill(pchar, "COMMERCE", 5);
                OfficersReaction("good");
    			TakeNItems(pchar, "Chest", -sti(pchar.GenQuest.LoanChest.Chest));
    			DeleteAttribute(pchar, "GenQuest.LoanChest");
    			DeleteAttribute(Pchar, "quest.LoanChestTimer");
    			AddQuestRecord("Gen_LoanTakeChest", "3");
                CloseQuestHeader("Gen_LoanTakeChest");

				AchievementsCounter_genquests(1);
			}
			else
			{
                Dialog.Text = "Parfait ! Mais oם sont tous les coffres d'or ?";
                link.l1 = "Vous pouvez accepter l'or sans les coffres ?";
    			link.l1.go = "TakeChest_3";
                link.l2 = "Je reviendrai plus tard.";
    			link.l2.go = "exit";
			}
		break;

		case "TakeChest_3":
            Dialog.Text = "Non ! Seulement dans les coffres !";
            link.l1 = "Dommage. Les rats les ont abîmés.";
			link.l1.go = "exit";
			//link.l2 = "Well, let's say the amount in " + FindRussianMoneyString(sti(pchar.GenQuest.LoanChest.Chest)*30000) + "will it cover the cost of the chests?";
			//link.l2.go = "TakeChest_4";
		break;

		/*case "TakeChest_4":
            Dialog.Text = "Yes, it's acceptable.";
            if (sti(pchar.Money) >= (sti(pchar.GenQuest.LoanChest.Chest)*30000))
            {
                link.l1 = "That's settled!";
    			link.l1.go = "TakeChest_5";
			}
			link.l2 = "That's just a lot for me.";
			link.l2.go = "exit";
		break;

		case "TakeChest_5":
            ChangeCharacterReputation(pchar, 1);
            AddCharacterExpToSkill(pchar, "Sailing", 30);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "COMMERCE", 30);
            OfficersReaction("good");
            Dialog.Text = "You can be dealt with!";
            link.l1 = "Thank you!";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -1*(sti(pchar.GenQuest.LoanChest.Chest)*30000));
			DeleteAttribute(pchar, "GenQuest.LoanChest");
			DeleteAttribute(Pchar, "quest.LoanChestTimer");
			AddQuestRecord("Gen_LoanTakeChest", "4");
            CloseQuestHeader("Gen_LoanTakeChest");
		break;
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Квесты мэра, проникновение во враждебный город
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "IntelligenceForAll":
            Dialog.Text = RandPhraseSimple("Eh bien, très bien. J'ai un paquet prêt pour vous, que vous devez remettre en main propre à l'homme que vous savez. Veuillez le recevoir. Ne vous approchez plus de moi et ne me parlez plus, cela pourrait paraître suspect. Soyez prudent...",
				"Hum, bien. Je vous remets un paquet, et souvenez-vous qu'il doit être remis en main propre à l'homme que vous avez nommé. Maintenant, adieu, et ne vous approchez plus de moi : c'est dangereux.");
            link.l1 = RandPhraseSimple("J'ai compris. Au revoir...", "Au revoir, et bonne chance.");
			link.l1.go = "exit";
			pchar.GenQuest.Intelligence = "Execute";
			GiveItem2Character(pchar, "sicretLetter");
			AddCharacterExpToSkill(pchar, "Sneak", 200);
			ref rItem = ItemsFromID("sicretLetter");
			rItem.City = XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.Intelligence.MayorId)].city+"Gen"));
			rItem.Mayor = GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId));
			AddQuestRecord("MayorsQuestsList", "7");
			AddQuestUserData("MayorsQuestsList", "ColonyName", XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.Intelligence.MayorId)].city+"Gen"));
			AddQuestUserData("MayorsQuestsList", "MayorName", GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)));
			AddQuestUserData("MayorsQuestsList", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.Intelligence.City+"Dat"));
			AddQuestUserData("MayorsQuestsList", "sWho", GetWorkTypeOfMan(&characters[GetCharacterIndex(pchar.GenQuest.Intelligence.SpyId)], "Gen"));
			AddQuestUserData("MayorsQuestsList", "SpyName", GetFullName(&characters[GetCharacterIndex(pchar.GenQuest.Intelligence.SpyId)]));
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Квест Асокольда, рендомные базары
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "AscoldTrader": //рендомный хозяин магаза
            dialog.Text = "Dites, vous avez trouvé la poudre de momie que je vous ai demandé de chercher ?";
            if (GetQuestPastDayParam("questTemp.Ascold") > 3)
			{
				Link.l1 = "Non, je n'en ai pas encore trouvé... וcoutez, les marchands ambulants semblent en avoir, mais ils tournent autour du pot...";
            	Link.l1.go = "AscoldTrader_6";
			}
			else
			{
				Link.l1 = "Non, je n'en ai pas encore trouvé... Mais je continue à chercher.";
            	Link.l1.go = "quests";
			}
		break;
        case "AscoldTrader_WasSeek":
            dialog.Text = "Dites, vous avez trouvé la poudre de momie que je vous ai demandé de chercher ?";
            Link.l2 = "Oui, j'en ai trouvé. Et combien allez-vous me la payer ?";
            Link.l2.go = "AscoldTrader_1";
        break;
		case "AscoldTrader_1":
        	dialog.text = "Moi, rien du tout. Mais je sais qui vous l'achètera.";
    		link.l1 = "Hum, je comptais recevoir de l'argent tout de suite.";
    		link.l1.go = "AscoldTrader_2";
		break;
 		case "AscoldTrader_2":
        	dialog.text = "Je pense que vous ne serez pas lésé. וcoutez bien\n"+
                          "Il y a un drכle de type en Guadeloupe, dans la ville de Basse-Terre : Askold.";
            if (Characters[GetCharacterIndex("Ascold")].quest.meeting == "0")
            {
                link.l1 = "Drכle de nom...";
                link.l1.go = "AscoldTrader_4";
            }
            else
            {
                link.l1 = "Je le connais, j'ai eu l'occasion de lui parler. Un insolent, je ne vous dis que ça...";
                link.l1.go = "AscoldTrader_3";
            }
		break;
 		case "AscoldTrader_3":
        	dialog.text = "Que s'est-il passé ? Il a testé son caractère sur vous ?";
    		link.l1 = "Oui, il m'a carrément jeté dehors comme un jouet !";
    		link.l1.go = "AscoldTrader_4";
		break;
 		case "AscoldTrader_4":
        	dialog.text = "Askold est un peu rude, mais c'est un homme bon et honnête. D'après les rumeurs, c'est un Moscovite : ce sont des gens qui vivent au nord de l'Ancien Monde, oם il neige toute l'année, et oם il n'y a que des forêts et des ours. D'oם son caractère rude, et il a assez de force dans les bras pour quatre gaillards\n"+
                          "Comment et quand il est arrivé ici, je ne le sais pas exactement, et je ne sais pas ce qu'il fait\n"+
                          "Mais il me fait confiance, parce que je fais des affaires avec lui\n"+
                          "Alors allez le voir, présentez-vous, dites-lui que vous venez de ma part, et tout ira bien. Il vous achètera cette marchandise, puisque c'est lui qui l'a commandée.";
    		link.l1 = "Et vous, qu'est-ce que vous y gagnez ?";
    		link.l1.go = "AscoldTrader_5";
		break;
 		case "AscoldTrader_5":
        	dialog.text = "Ne vous inquiétez pas pour moi, je prélèverai ma commission sur nos affaires courantes.";
    		link.l1 = "Compris. Eh bien, je passerai sans doute voir votre Askold à l'occasion.";
    		link.l1.go = "exit";
    	    pchar.questTemp.Ascold = "GoToAscold";
    	    QuestSetCurrentNode("Ascold", "HaveRecomendation");
            AddQuestRecord("Ascold", "2");
		break;
 		case "AscoldTrader_6":
        	dialog.text = "Ils vous menacent aussi de l'Inquisition ?";
    		link.l1 = "Exactement, ils menacent...";
    		link.l1.go = "AscoldTrader_7";
		break;
 		case "AscoldTrader_7":
        	dialog.text = "Eh bien, à quoi vous attendiez-vous ? Je vais vous dire une chose, "+ GetSexPhrase("l'ami", "ma petite") +": ils ont la poudre. Pas tous, bien sמr, mais quelqu'un en a, c'est certain. Alors vous devez insister davantage auprès d'eux, et vous finirez par arriver à vos fins.";
    		link.l1 = "Hé, eh bien, merci de votre aide.";
    		link.l1.go = "quests";
			SaveCurrentQuestDateParam("questTemp.Ascold");
		break;
        //==> Общий диалог для хозяев верфи, квест Аззи.
		case "AzzyTryTalk":
			dialog.Text = NPCStringReactionRepeat("Voyons votre boîte de fer-blanc. Ah non. Regardez-la, elle est couverte d'inscriptions étranges, ce doit être de la sorcellerie. Je vous conseille de porter cet objet à l'église, ils sauront quoi en faire.", "none", "none", "none", "block", 0, npchar, Dialog.CurrentNode);
  			Link.l1 = HeroStringReactionRepeat("Merci pour ce bon conseil.", "none", "none", "none", npchar, Dialog.CurrentNode);
			Link.l1.go = "Exit";
		break;
		case "AggryHelp":
			dialog.Text = NPCStringReactionRepeat("Il y a des outils sur la table : un chalumeau, une scie à métaux, des cisailles à tכle, et ainsi de suite. Prenez-les et ouvrez-la vous-même, mais je ne veux pas d'argent.", "none", "none", "none", "block", 0, npchar, Dialog.CurrentNode);
			Link.l10 = HeroStringReactionRepeat("Merci, " + npchar.name + ".", "none", "none", "none", npchar, Dialog.CurrentNode);
			Link.l10.go = "exit";
			items[GetItemIndex("Azzy_bottle")].shown = 0; //даём возможность вскрыть лампу
		break;
		//==> Общий диалог для церкви, квест Аззи.
        case "GiveLamp":
			dialog.text = "Vous avez bien fait, "+ GetSexPhrase("mon fils", "ah, ma fille") +". On ne sait pas ce qu'il y a dedans, mais il est clair qu'il faudra reconsacrer l'église dès demain\n"+
                          "Je ne veux pas savoir oם vous avez trouvé cela. Au nom du Sauveur, je vous pardonne vos péchés ! Allez en paix.";
			link.l1 = "Merci, saint père.";
			link.l1.go = "exit";
            ChangeCharacterReputation(pchar, 100);
            TakeItemFromCharacter(pchar, "Azzy_bottle");
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Грабёж среди бела дня, попытка залезть в сундуки
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        case "Man_FackYou":
			dialog.text = LinkRandPhrase("Un vol en plein jour !!! Qu'est-ce qui se passe ?! Attendez un peu, "+ GetSexPhrase("l'ami","ma petite") +"...", "Hé, qu'est-ce que vous faites là ?! Pas question, vous avez décidé de me voler ? Eh bien, vous êtes fini...", "Attendez, oם allez-vous ? Vous êtes un voleur ! Eh bien, considérez que vous êtes cuit, ordure...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "fight_owner";
		break;
		case "fight_owner":
			LAi_SetOwnerTypeNoGroup(NPChar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			NextDiag.CurrentNode = "First time";
			DialogExit();
		break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Квест получения Синей птицы
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "RBlueBird":
			dialog.text = "Eh, capitaine, ce n'est pas arrivé d'un coup, ça dure depuis longtemps. Nous autres marchands des Caraïbes sommes au bord de la ruine. Et c'est ce maudit « Oiseau bleu » qui est responsable de tout...";
			link.l1 = "L'« Oiseau bleu » ?";
			link.l1.go = "RBlueBird_1";
		break;
		case "RBlueBird_1":
			dialog.text = "Oui, c'est un maudit chébec, impossible de lui échapper en mer. Il ne dévalise que les navires marchands. Les grosses caravanes renforcées de navires de guerre, il n'y touche pas.";
			link.l1 = "Pourquoi dites-vous que les marchands se ruinent ? Après tout, les marchandises arrivent quand même ici avec ces caravanes.";
			link.l1.go = "RBlueBird_2";
		break;
		case "RBlueBird_2":
			dialog.text = "Oui, c'est vrai. Mais le fait est que, dans ces conditions, le commerce n'est plus rentable. Le mieux, c'est d'avoir son propre sloop ou sa propre flמte, d'acheter soi-même les marchandises dans l'Ancien Monde et de les ramener ici. דa, c'est du commerce ! Quand on achète les marchandises aux transporteurs, il n'y a plus de bénéfice, il ne s'agit plus que de survivre.";
			link.l1 = "Compris. Et dès que vos navires prennent la mer, le chébec les aborde...";
			link.l1.go = "RBlueBird_3";
		break;
		case "RBlueBird_3":
			dialog.text = "C'est exact. Presque tous les marchands ont déjà perdu leurs propres navires, maudit soit cet « Oiseau bleu » !";
			link.l1 = "Mmm, c'est bien triste pour vous... Bon, que voulez-vous de moi ?";
			link.l1.go = "RBlueBird_4";
		break;
		case "RBlueBird_4":
			dialog.text = "Nous voulons que vous anéantissiez ce rat musqué aux ailes bleues, que le diable l'emporte !!!";
			link.l1 = "Et qu'est-ce que j'y gagne ?";
			link.l1.go = "RBlueBird_5";
		break;
		case "RBlueBird_5":
			dialog.text = "Je réunirai auprès de tous mes collègues une belle rémunération pour ce travail. Je peux vous promettre cinquante mille piastres. Ce maudit chébec doit finir par le fond !";
			link.l1 = "Pour cette somme, l'ami, je ne lèverai pas le petit doigt. Cherchez un imbécile !";
			link.l1.go = "RBlueBird_close";
			link.l2 = "Hum, cette somme m'intéresse. Je suis prêt à me charger de l'affaire. Quels sont les délais ?";
			link.l2.go = "RBlueBird_6";
		break;
		case "RBlueBird_6":
			dialog.text = "Vous n'avez pas de délai. Je comprends parfaitement que ce ne sera pas facile, bon sang ! א vrai dire, nous avons déjà fait appel à des tueurs à gages dans cette affaire, nous voulions éliminer le capitaine. Sans résultat...";
			link.l1 = "Vraiment ? Vous pouvez m'en dire plus ?";
			link.l1.go = "RBlueBird_7";
		break;
		case "RBlueBird_7":
			dialog.text = "Eh bien, nous nous sommes cotisés et nous avons engagé quelqu'un pour retrouver le capitaine de ce chébec parmi les pirates. דa n'a pas marché : notre homme a écumé les Caraïbes pendant six mois, mais il n'a rien trouvé. Le diable sait oם ils ont leur base et oם ils écoulent leur butin...";
			link.l1 = "Bon, l'ami, c'est déjà quelque chose. Maintenant, écoute mes conditions.";
			link.l1.go = "RBlueBird_8";
		break;
		case "RBlueBird_8":
			dialog.text = "Je vous écoute attentivement, " + GetAddress_Form(NPChar) + "." ;
			link.l1 = "Cette affaire reste entre toi et moi : réunis l'argent comme tu veux, mais ne dis à personne que c'est moi qui m'en charge. Et deuxième chose. Tu as dit que PRESQUE tous les marchands avaient perdu leurs navires. Que veut dire « presque » ?";
			link.l1.go = "RBlueBird_9";
		break;
		case "RBlueBird_9":
			dialog.text = "Il reste une flמte à un marchand. Mais c'est un veinard, il n'est jamais tombé sur ce chébec. C'est notre seul espoir de garder pied ici, nous lui devons déjà tous de l'argent. S'il ne nous avait pas soutenus dans les moments difficiles, nous aurions tous fait faillite depuis longtemps. Il n'a jamais refusé de prêter de l'argent à qui que ce soit !";
			link.l1 = "Compris. Presque un saint ! Et comment s'appelle-t-il ?";
			link.l1.go = "RBlueBird_10";
		break;
		case "RBlueBird_10":
			dialog.text = "Pascal Voisier. Il tient une boutique aux Bermudes, dans la colonie pirate. Alors, vous acceptez l'affaire ?";
			link.l1 = "Acceptes-tu ma condition de silence ?";
			link.l1.go = "RBlueBird_11";
		break;
		case "RBlueBird_11":
			dialog.text = "Absolument !";
			link.l1 = "Alors j'accepte. Je commence les recherches dès aujourd'hui, j'espère en finir vite.";
			link.l1.go = "RBlueBird_12";
		break;
		case "RBlueBird_12":
			dialog.text = "Oh, que Dieu vous entende ! Eh bien, au travail. J'espère vraiment que tout se passera comme vous le dites.";
			link.l1 = "Ce sera le cas, vous pouvez en être sמr !";
			link.l1.go = "exit";
			pchar.questTemp.BlueBird = "toBermudes";
			pchar.questTemp.BlueBird.traiderId = npchar.id; //запомним Id торговца
			SetQuestHeader("Xebeca_BlueBird");
			AddQuestRecord("Xebeca_BlueBird", "1");
			AddQuestUserData("Xebeca_BlueBird", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("Xebeca_BlueBird", "sName", GetFullName(npchar));
		break;


		case "RBlueBird_close":
			dialog.text = "Eh bien, c'est dommage. Nous chercherons peut-être notre « imbécile » ailleurs...";
			link.l1 = "Hum...";
			link.l1.go = "exit";
			pchar.questTemp.BlueBird = "declined";//Блокировка ЧП
		break;
		case "RBlueBirdWon":
			dialog.text = "Excellente nouvelle, je vous le dis ! Nous allons enfin pouvoir faire du vrai commerce... Vous voulez recevoir l'argent tout de suite ?";
			link.l1 = "Oui, de préférence...";
			link.l1.go = "RBlueBirdWon_1";
			if (CheckShipOwned("XebekVML1"))
        	{
				dialog.text = "Hum, attendez... Si je ne m'abuse, vous avez réussi à rattraper le chébec, mais vous ne l'avez pas coulé ! Il est maintenant en votre possession.";
				link.l1 = "Oui, c'est vrai. Et alors, oם est le problème ?";
				link.l1.go = "RBlueBirdWon_10";
            }
		break;

		case "RBlueBirdWon_1":
			dialog.text = "Aucun problème, recevez-le, je vous prie. L'argent est dans les coffres. Il y a même un peu plus de cinquante mille.";
			link.l1 = "Merci, nous sommes quittes. Je vous souhaite le meilleur... Au fait, vous ne voulez pas savoir qui était derrière tout ça ?";
			link.l1.go = "RBlueBirdWon_2";
			TakeNItems(pchar, "chest", 4);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
		break;
		case "RBlueBirdWon_2":
			dialog.text = "Hum, ce sera très intéressant à savoir...";
			link.l1 = "C'est le marchand le plus « saint » des Caraïbes : Pascal Voisier.";
			link.l1.go = "RBlueBirdWon_3";
		break;
		case "RBlueBirdWon_3":
			dialog.text = "Ce n'est pas possible !..";
			link.l1 = "C'est possible. Malheureusement, je n'ai aucune preuve, mais gardez à l'esprit qui vous prête votre propre argent.";
			link.l1.go = "RBlueBirdWon_4";
		break;
		case "RBlueBirdWon_4":
			dialog.text = "Hum, il faut vérifier tout ça... Eh bien, merci pour votre travail et pour l'information.";
			link.l1 = "Je vous en prie, vous l'avez payé. Au revoir.";
			link.l1.go = "exit";
			CloseQuestHeader("Xebeca_BlueBird");
			pchar.questdata.SinyaPtitsa = 1;
			pchar.questTemp.BlueBird = "over";
		break;

		case "RBlueBirdWon_10":
			dialog.text = "Le problème, c'est que ce maudit navire est maintenant entre vos mains. Et vous êtes un pirate, vous aussi, soit dit en passant ! Et qui vous empêchera de dévaliser les marchands comme le faisait son ancien propriétaire ?";
			link.l1 = "Hum, la question est certes intéressante... Mais j'ai fait ce travail !";
			link.l1.go = "RBlueBirdWon_11";
		break;
		case "RBlueBirdWon_11":
			dialog.text = "Non, vous ne l'avez pas fait. Nous avions convenu de couler l'Oiseau bleu, pas de l'aborder.";
			link.l1 = "Hum, voilà donc comment c'est ! Bon, je vous comprends... Bonne continuation, transmettez mes plus chaleureuses salutations à vos collègues.";
			link.l1.go = "RBlueBirdWon_12";
		break;
		case "RBlueBirdWon_12":
			dialog.text = "Je n'y manquerai pas ! Adieu, menteur.";
			link.l1 = "D'accord... Mais je ne vous dis pas adieu...";
			link.l1.go = "exit";
			AddQuestRecord("Xebeca_BlueBird", "9");
			AddQuestUserData("Xebeca_BlueBird", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Xebeca_BlueBird", "sSex1", GetSexPhrase("", "e"));
			BlueBurd_RumourUpdate();
		break;

		case "RBlueBirdDieHard":
			dialog.text = "Je suis vraiment, vraiment désolé. Bah, vous n'êtes pas le premier à vous charger de cette affaire sans y parvenir. C'est fâcheux, nous allons devoir continuer à végéter...";
			link.l1 = "J'espère que tout finira par rentrer dans l'ordre...";
			link.l1.go = "RBlueBirdDieHard_1";
		break;
		case "RBlueBirdDieHard_1":
			dialog.text = "דa, c'est sמr. Nous vivons ici dans l'agitation, en croyant naïvement que la terre tourne autour de nous. Mais non, poussière nous sommes, et poussière nous retournerons... me voilà parti dans la poésie.";
			link.l1 = "דa arrive... Bon, au revoir.";
			link.l1.go = "exit";
			CloseQuestHeader("Xebeca_BlueBird");
			pchar.questdata.SinyaPtitsa = 1;
			pchar.questTemp.BlueBird = "over";
		break;

		case "RBlueBird_retMoney_1":
			dialog.text = "Oh, espèce de salaud ! Nos craintes étaient donc fondées !!";
			link.l1 = "Je ne vous aurais pas touchés si vous n'aviez pas commencé à tricher !";
			link.l1.go = "RBlueBird_retMoney_2";
		break;
		case "RBlueBird_retMoney_2":
			dialog.text = "Oh, merde ! Gardes, attrapez "+ GetSexPhrase("lui", "elle") +" !!! Tu n'iras pas loin, salaud...";
			link.l1 = "Vous feriez mieux de me rendre mon argent, fouines. Nous allons continuer à vous soigner...";
			link.l1.go = "fight";
		break;

		case "RBlueBird_retMoney_3":
			dialog.text = "Maudit sois-tu, salaud ! Comme je regrette de m'être adressé à toi !! Avant toi, l'Oiseau bleu ne nous avait jamais causé AUTANT d'ennuis !..";
			link.l1 = "Mes amis, c'est votre faute, vous auriez dמ respecter le contrat.";
			link.l1.go = "RBlueBird_retMoney_4";
		break;
		case "RBlueBird_retMoney_4":
			dialog.text = "Quel accord avons-nous avec vous ? Nous l'avons scrupuleusement respecté ! C'est vous qui l'avez violé en ne coulant pas le chébec !";
			link.l1 = "Mon cher, ne criez pas comme ça, c'est très mauvais pour les cordes vocales. Et si vous ne pouviez plus parler ensuite ? Bref, je suis prêt à vous parler, mais seulement sur un ton modéré...";
			link.l1.go = "RBlueBird_retMoney_5";
		break;
		case "RBlueBird_retMoney_5":
			dialog.text = "Bon, d'accord, même si le ton n'y est pour rien. C'est vous qui avez violé les termes du marché, pas nous : voilà le fond de l'affaire !";
			link.l1 = "Hé ! Vous autres marchands, vous êtes passés maîtres dans ce genre de subtilités contractuelles. Je connais vos ruses. Il suffit d'oublier une virgule quelque part, et le sens du texte change aussitכt.";
			link.l1.go = "RBlueBird_retMoney_6";
		break;
		case "RBlueBird_retMoney_6":
			dialog.text = "Qu'est-ce que les virgules viennent faire là-dedans ? Nous avions un accord oral, vous et moi.";
			link.l1 = "Eh bien, je parle au figuré. Le fait est que vous avez sauté sur l'occasion de me rouler, et vous l'avez fait. Et moi, je suis un pirate, je n'ai pas le temps de démêler les doubles sens de vos conditions.";
			link.l1.go = "RBlueBird_retMoney_7";
		break;
		case "RBlueBird_retMoney_7":
			dialog.text = "Quelles conditions ?";
			link.l1 = "Les termes de notre accord. L'« Oiseau bleu » vous gênait : j'ai réglé ce problème. Si vous m'aviez donné mon argent, je ne vous aurais pas touchés. Tous vos problèmes viennent donc de votre sagesse, pour ainsi dire...";
			link.l1.go = "RBlueBird_retMoney_8";
		break;
		case "RBlueBird_retMoney_8":
			dialog.text = "Bon, d'accord, prenez vos 50 000 et fichez le camp !";
			link.l1 = "Pas si vite, mon cher. Le fait est que j'ai eu des frais supplémentaires en essayant de vous faire entendre raison. Sans parler du préjudice moral. La somme a donc augmenté.";
			link.l1.go = "RBlueBird_retMoney_9";
		break;
		case "RBlueBird_retMoney_9":
			dialog.text = "Et quelle est cette nouvelle somme ? Dites-la.";
			link.l1 = "Quatre fois plus. 200 000, et je vous laisse tranquilles. Sinon, je vous ruinerai. Et ensuite, je vous tuerai. D'abord votre famille, puis vous...";
			link.l1.go = "RBlueBird_retMoney_10";
		break;
		case "RBlueBird_retMoney_10":
			dialog.text = "Vous êtes le diable !!";
			link.l1 = "Et un diable très, très en colère...";
			link.l1.go = "RBlueBird_retMoney_11";
		break;
		case "RBlueBird_retMoney_11":
			dialog.text = "Bon. Voici votre argent : quatorze coffres. Il y a même plus de deux cent mille. Maintenant, partez ! Et laissez-nous tranquilles !";
			link.l1 = "Absolument. Maintenant que vous avez réglé vos comptes avec moi, l'Oiseau bleu ne vous menace plus. Au revoir, et bonne chance dans vos affaires...";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.BlueBird");
			pchar.questTemp.BlueBird = "over"; //закрываем квест
			TakeNItems(pchar, "chest", 14);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("Xebeca_BlueBird", "14");
			AddQuestUserData("Xebeca_BlueBird", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Xebeca_BlueBird", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("Xebeca_BlueBird");
			pchar.questdata.SinyaPtitsa = 1;
		break;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Линейка острова погибших кораблей ISS
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "ISS_deposit":
			dialog.text = NPCStringReactionRepeat("C'est exact. Vous pourrez recevoir un million de piastres une minute après que j'aurai reçu la confirmation.",
				"Je vous l'ai déjà dit, " + GetAddress_Form(NPChar) + " – j'ai bien un dépכt. J'attends la confirmation de son versement.",
				"Ne vous inquiétez pas. Le dépכt est chez moi, j'attends seulement la confirmation de son versement.",
				"Hum, il me semble que vous vous inquiétez trop pour ce dépכt. Ma réputation est irréprochable, je ne peux donc que répéter ce que j'ai déjà dit. Le dépכt à votre nom est chez moi, vous pourrez le recevoir après confirmation du versement.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Compris. Eh bien, très bien. J'ai appris ce que je voulais.",
				"Oui, je vois...",
				"Je ne m'inquiète pas vraiment.",
				"Je vois... Merci, " + GetAddress_Form(NPChar) + ".", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
		case "ISS_takeDeposit":
			dialog.text = "Oui, oui, j'ai reçu l'autorisation d'effectuer cette opération financière. Veuillez recevoir, " + GetAddress_Form(NPChar) + ".";
			link.l1 = "Hé hé, très bien...";
			link.l1.go = "ISS_takeDeposit_1";
			AddMoneyToCharacter(pchar, 1000000);
			CloseQuestHeader("ISS_PoorsMurder");
			pchar.questdata.UbitVsehNishih = 1;
		break;
		case "ISS_takeDeposit_1":
			dialog.text = "Vous déciderez peut-être de placer cet argent à intérêt ? Je suis toujours à votre service, ma réputation...";
			link.l1 = "Je comprends. Merci beaucoup. Je vais y réfléchir.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "over"; //конец линейки ГПК
			CloseQuestHeader("ISS_PoorsMurder");
			pchar.questdata.UbitVsehNishih = 1;
		break;
		//механика арестовали, диалоги мужика
		case "MechanicIsPrison_man":
			dialog.text = "Ah, vous voilà enfin...";
			link.l1 = "Qu'est-ce qui se passe ? Pourquoi n'êtes-vous pas encore sur le clipper ? Oם est le Mécanicien ?";
			link.l1.go = "MechanicIsPrison_man_1";
		break;
		case "MechanicIsPrison_man_1":
			dialog.text = "Je ne sais pas oם il est maintenant. Quand j'étais sur le San Gabriel, la police était justement en train de l'emmener. Apparemment, il a été arrêté, et seul l'amiral a pu faire ça.";
			link.l1 = "Caramba !!! Que faire maintenant ?";
			link.l1.go = "MechanicIsPrison_man_2";
		break;
		case "MechanicIsPrison_man_2":
			dialog.text = "On ne peut pas se passer du Mécanicien ?";
			link.l1 = "Il nous faut Vedeker. Nous pouvons monter sur le clipper, mais nous ne pourrons pas le libérer sans Henrik.";
			link.l1.go = "MechanicIsPrison_man_3";
		break;
		case "MechanicIsPrison_man_3":
			dialog.text = "Alors il faut aller à la résidence de Capper et tirer le Mécanicien d'affaire. Malheureusement, je passe mon tour dans cette affaire : l'amiral me terrifie rien que par son allure...";
			link.l1 = "Hé, ça se comprend... Allez au navire, j'arriverai bientכt avec Vedeker. Le reste de l'équipage y est déjà, apparemment.";
			link.l1.go = "MechanicIsPrison_man_4";
		break;
		case "MechanicIsPrison_man_4":
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = "Ne paniquez pas là-bas sans moi. Tout ira bien.";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
			pchar.questTemp.LSC = "MechanicIsArrest_toResidence";
			SetCrewQuantity(pchar, GetMinCrewQuantity(pchar));
			bDisableFastReload = true;
			AddQuestRecord("ISS_MainLine", "64");
			pchar.quest.LSC_fightEnterResidence.win_condition.l1 = "location";
			pchar.quest.LSC_fightEnterResidence.win_condition.l1.location = "SanAugustineResidence";
			pchar.quest.LSC_fightEnterResidence.function = "LSC_fightEnterResidence";
		break;
		//механика арестовали, диалоги бабы
		case "MechanicIsPrison_woman":
			dialog.text = "Ah, vous voilà enfin...";
			link.l1 = "Qu'est-ce qui se passe ? Pourquoi n'êtes-vous pas encore sur le clipper ? Oם est le Mécanicien ?";
			link.l1.go = "MechanicIsPrison_man_1";
		break;
		case "MechanicIsPrison_woman_1":
			dialog.text = "Je ne sais pas oם il est maintenant. Quand je suis arrivée sur le San Gabriel, la police était justement en train de l'emmener. Apparemment, il a été arrêté, et seul l'amiral a pu faire ça.";
			link.l1 = "Caramba !!! Que faire maintenant ?";
			link.l1.go = "MechanicIsPrison_woman_2";
		break;
		case "MechanicIsPrison_woman_2":
			dialog.text = "On ne peut pas se passer du Mécanicien ?";
			link.l1 = "Il nous faut Vedeker. Nous pouvons monter sur le navire, mais nous ne pourrons pas le libérer sans Henrik.";
			link.l1.go = "MechanicIsPrison_man_3";
		break;
		case "MMechanicIsPrison_woman_3":
			dialog.text = "Alors il faut aller à la résidence de Capper et tirer le Mécanicien d'affaire. Malheureusement, en tant que femme, je ne peux pas vous aider dans cette affaire.";
			link.l1 = "C'est vrai... Allez au navire, j'arriverai bientכt avec Vedeker. Le reste de l'équipage y est déjà, apparemment.";
			link.l1.go = "MechanicIsPrison_man_4";
		break;
		case "MechanicIsPrison_woman_4":
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = "Ne paniquez pas là-bas sans moi. Tout ira bien.";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
			pchar.questTemp.LSC = "MechanicIsArrest_toResidence";
			SetCrewQuantity(pchar, GetMinCrewQuantity(pchar));
			bDisableFastReload = true;
			AddQuestRecord("ISS_MainLine", "64");
			pchar.quest.LSC_fightEnterResidence.win_condition.l1 = "location";
			pchar.quest.LSC_fightEnterResidence.win_condition.l1.location = "SanAugustineResidence";
			pchar.quest.LSC_fightEnterResidence.function = "LSC_fightEnterResidence";
		break;
		case "SeekCrew_all":
			pchar.questTemp.LSC.crew = sti(pchar.questTemp.LSC.crew) + 1;
			chrDisableReloadToLocation = true;
			float   locx, locy, locz;
			GetCharacterPos(pchar, &locx, &locy, &locz);
			if (sti(pchar.questTemp.LSC.crew) >= 15)
			{
				DeleteAttribute(pchar, "questTemp.LSC.crew");
				pchar.questTemp.LSC = "MechanicIsArrest";
				pchar.questTemp.LSC.lastManId = npchar.index; //сюда запишем индекс
				NextDiag.TempNode = "MechanicIsPrison_" + npchar.sex;
				AddQuestRecord("ISS_MainLine", "63");
				AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
				if (npchar.location.group == "sit")
				{
					ChangeCharacterAddressGroup(npchar, npchar.location, "goto", LAi_FindNearestLocator("goto", locx, locy, locz));
				}
				npchar.cityTape = "quest";  //чтобы не передвигался
				DeleteAttribute(npchar, "location.going"); //снять метку на перемещёние
				LAi_SetActorType(npchar);
				LAi_ActorRunToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 10.0);
				pchar.quest.LSC_afterArestMachanic.win_condition.l1 = "ExitFromLocation";
				pchar.quest.LSC_afterArestMachanic.win_condition.l1.location = pchar.location;
				pchar.quest.LSC_afterArestMachanic.function = "LSC_afterArestMachanic";
			}
			else
			{
				AddQuestRecord("ISS_MainLine", "62");
				AddQuestUserData("ISS_MainLine", "sName", GetFullName(npchar));
				AddQuestUserData("ISS_MainLine", "Sex", NPCharSexPhrase(npchar, "accepté", "accepté"));
				AddQuestUserData("ISS_MainLine", "iCrew", FindRussianPeoplesString(15-sti(pchar.questTemp.LSC.crew), "Acc"));
				npchar.lifeDay = 0;
				if (npchar.location.group == "sit")
				{
					ChangeCharacterAddressGroup(npchar, npchar.location, "goto", LAi_FindNearestLocator("goto", locx, locy, locz));
				}
				LAi_SetActorType(npchar);
				LAi_ActorRunToLocation(NPChar, "reload", LAi_FindNearestLocator("reload", locx, locy, locz), "none", "", "", "OpenTheDoors", 10.0);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}

string sRumourAboutOwners_CityRumour(string sCity, string sOwnerType) // Здесь идёт распределение по городам
{
	string sRetRumour = "Bug évident. Signalez-le à AT, pour Warship.";
	// флаг - PChar.QuestTemp.RumoursAboutOwners.(sOwner) - для проверок, какой вопрос выпал. Ножно будет юзать для квестов
	switch(sCity)
	{
		case "Tortuga":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 0, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 0;
		break;

		case "PortRoyal":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 1, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 1;
		break;

		case "FortOrange":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 2, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 2;
		break;

		case "Beliz":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 3, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 3;
		break;

		case "PortoBello":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 4, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 4;
		break;

		case "Cartahena":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 5, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 5;
		break;

		case "Maracaibo":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 6, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 6;
		break;

		case "Caracas":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 0, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 7;
		break;

		case "Cumana":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 1, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 8;
		break;

		case "SantaCatalina":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 2, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 9;
		break;

		case "SanJuan":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 3, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 10;
		break;

		case "Marigo":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 4, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 11;
		break;

		case "Charles":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 5, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 12;
		break;

		case "SentJons":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 6, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 13;
		break;

		case "FortFrance":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 0, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 14;
		break;

		case "BasTer":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 1, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 15;
		break;

		case "Bridgetown":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 2, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 16;
		break;

		case "PortSpein":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 3, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 17;
		break;

		case "Havana":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 4, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 18;
		break;

		case "Villemstad":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 5, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 19;
		break;

		case "Santiago":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 6, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 20;
		break;

		case "PortPax":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 0, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 21;
		break;

		case "SantoDomingo":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 1, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 22;
		break;
		
		case "Nassau":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 2, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 23;
		break;
		
		case "DesMoines":
			sRetRumour = sRumourAboutOwners_Init(sOwnerType, 3, sCity);
			PChar.QuestTemp.RumoursAboutOwners.(sOwnerType) = 24;
		break;
	}

	return sRetRumour;
}

string sRumourAboutOwners_Init(string sOwnerType, int iRumourNum, string sTown) // База слухов жителей. Можно менять без новой игры
{

	string STR_MAYOR[MAX_RUMOURS_ABOUT_OWNERS]; // Губернаторы
	STR_MAYOR[0] = "Oh, monsieur le gouverneur est un homme merveilleux. Il dirige notre colonie avec habileté : depuis sa fondation, nous n'avons pas connu un seul conflit majeur. Son seul défaut, c'est... mmm... qu'il est très économe. Encore que ce soit peut-être plutכt une qualité.";
	STR_MAYOR[1] = "Oh, monsieur le gouverneur est un homme merveilleux. Il dirige notre colonie avec habileté : depuis sa fondation, nous n'avons pas connu un seul conflit majeur. Son seul défaut, c'est... mmm... qu'il est très économe. Encore que ce soit peut-être plutכt une qualité.";
	STR_MAYOR[2] = "Hélas, notre monsieur le gouverneur est un brave homme... Mais il manque de caractère. S'il avait un peu plus de fermeté dans l'âme, nos marchands bénéficieraient de quelques allègements d'impכts... Et les subventions pour réparer le fort auraient dמ être accordées depuis longtemps.";
	STR_MAYOR[3] = "Hum... Il est devenu notre gouverneur récemment. Il est assez jeune et donc très entreprenant : notre colonie prospère sous son administration.";
	STR_MAYOR[4] = "Notre gouverneur est encore relativement jeune. On dit que c'est le fils cadet dévoyé d'un comte espagnol, envoyé loin de la cour pour cesser de faire honte à sa famille. Il a été nommé ici tout récemment, et il n'a encore rien fait de mémorable.";
	STR_MAYOR[5] = "Hum... Il est devenu notre gouverneur récemment. Il est assez jeune et donc très entreprenant : notre colonie prospère sous son administration.";
	STR_MAYOR[6] = "Euh... Rien... Je ne peux rien dire de mal sur lui.";

	string STR_TAVERNKEEPER[MAX_RUMOURS_ABOUT_OWNERS]; // Тавернщики
	STR_TAVERNKEEPER[0] = "Hum, je ne confierais pas mes biens à ce coquin. Ne vous méprenez pas, mais il me semble que c'est la personne la moins fiable de notre ville ; on dit qu'il traficote avec les contrebandiers et les pirates, et toute la racaille traîne en permanence dans sa taverne !";
	STR_TAVERNKEEPER[1] = "Que dire de lui ! Il est un peu lâche, et pas très malin. En plus, il est avide d'argent, c'est pourquoi il s'attire sans cesse toutes sortes d'ennuis ! Mais il est toujours au courant de toutes les nouvelles.";
	STR_TAVERNKEEPER[2] = "Un type plutכt sympathique. On se sent toujours bien dans sa taverne, et le patron a le sens de l'humour. Et surtout, il fait régner l'ordre dans la taverne et ne laisse pas les ivrognes importuner les citoyens respectables.";
	STR_TAVERNKEEPER[3] = "Un homme étonnant. Il ne devrait pas tenir une taverne, mais travailler comme indicateur pour la chancellerie secrète. On a parfois l'impression qu'il sait littéralement tout ce qui se passe dans notre ville. C'en est même inquiétant.";
	STR_TAVERNKEEPER[4] = "Je ne sais pas quoi vous dire sur lui. Un homme comme un autre. Il tient la taverne, et il est donc au courant de toutes les nouvelles de notre île.";
	STR_TAVERNKEEPER[5] = "On dit qu'on peut compter sur lui. D'un autre cכté, j'ai entendu dire qu'il n'aime pas les risques inutiles et qu'il mène toujours ses affaires avec prudence. Et il ne semble pas non plus mêlé à des affaires louches.";
	STR_TAVERNKEEPER[6] = "Il a hérité la taverne de son père. Son père tenait une taverne non loin d'ici, sur la petite île de Hyrok, dans un autre archipel. Puis le père est venu s'installer ici, il a construit une nouvelle taverne, et maintenant c'est son fils qui la tient.";

	string STR_SHIPYARDER[MAX_RUMOURS_ABOUT_OWNERS]; // Верфисты
	STR_SHIPYARDER[0] = "Il construit de bons navires... Quant à l'homme, difficile d'en dire quoi que ce soit : il vit tranquillement et paisiblement. Sans doute pas un mauvais bougre.";
	STR_SHIPYARDER[1] = "Il construit de bons navires... Quant à l'homme, difficile d'en dire quoi que ce soit : il vit tranquillement et paisiblement. Sans doute pas un mauvais bougre.";
	STR_SHIPYARDER[2] = "Ce n'est pas un mauvais homme, mais on dit qu'il est trop dur. Il réprimande sans cesse tous ses employés. C'est pourquoi ils changent souvent chez lui. Mais malgré cela, c'est un excellent constructeur de navires.";
	STR_SHIPYARDER[3] = "C'est un homme très instruit. On dit qu'il a étudié la construction navale en Angleterre, puis en Hollande. Et il a fini par échouer ici, loin de la métropole, dans un archipel perdu ; on dit qu'il ne s'entendait pas avec la Sainte Inquisition à l'époque, et qu'il a dמ fuir aux colonies.";
	STR_SHIPYARDER[4] = "Oui, ce vieillard n'est plus bon à rien. Il rêve sans cesse du temps passé, et il ronchonne dès qu'on lui commande autre chose qu'une caravelle ou un galion.";
	STR_SHIPYARDER[5] = "Un type formidable. Il est toujours prêt à aider, à tirer d'affaire. Je dois dire qu'il construit de très bons navires pour un trou pareil.";
	STR_SHIPYARDER[6] = "C'était un exilé dans notre colonie, jusqu'à ce qu'on découvre qu'il avait un talent pour la construction navale. Après que deux magnifiques bricks ont été construits sous sa direction dans les chantiers de notre colonie, ses péchés lui ont été pardonnés, et c'est maintenant un membre à part entière de notre société.";

	string STR_TRADER[MAX_RUMOURS_ABOUT_OWNERS]; // Магазинщики
	STR_TRADER[0] = "Je ne peux rien dire de particulièrement mauvais sur lui. Un habitant convenable, un paroissien assidu de notre église. Je n'ai jamais entendu dire que quelqu'un l'ait accusé de blasphème ou ait eu à se plaindre de lui.";
	STR_TRADER[1] = "C'est le principal fournisseur de notre gouverneur, ce qui lui rapporte de bons revenus. Mais il mène ses affaires honnêtement. Enfin, du moins, on ne l'a encore jamais pris en faute.";
	STR_TRADER[2] = "Ce gros bonhomme jouit d'un respect bien mérité dans notre ville. Ses marchandises sont toujours excellentes, et je ne me souviens pas qu'il ait jamais trompé qui que ce soit.";
	STR_TRADER[3] = "C'est un mauvais bougre. Il commerce, il commerce, mais rien n'en sort. Il manque tantכt une marchandise, tantכt une autre. Et lui-même n'arrive pas à sortir de ses dettes.";
	STR_TRADER[4] = "Ce n'est pas un homme bien, monsieur. On dit qu'il était l'assistant de Baldwin Coffier, mais qu'il l'a ruiné, puis lui a racheté le magasin. Je ne sais pas ce que valent les marchandises qu'il vend, mais en tant qu'homme, il m'est très antipathique.";
	STR_TRADER[5] = "Oh ! C'est un homme ignoble, je ne vous conseille pas d'avoir affaire à lui : il tient la moitié des habitants de notre ville endettés ! Et les marchandises qu'on vend dans sa boutique sont toujours de mauvaise qualité.";
	STR_TRADER[6] = "Personne ne sait vraiment rien de lui. Il s'est installé ici récemment, et il a aussitכt ouvert sa propre affaire. Il semble commercer honnêtement, il ne fait pas de contrebande.";

	string sTempMayor = STR_MAYOR[iRumourNum];
	string sTempTavernkeper = STR_TAVERNKEEPER[iRumourNum];
	string sTempShipyarder = STR_SHIPYARDER[iRumourNum];
	string sTempTrader = STR_TRADER[iRumourNum];

	if(sOwnerType == "Mayor") return sTempMayor;
	if(sOwnerType == "TavernKeeper") return sTempTavernkeper;
	if(sOwnerType == "ShipYarder") //если правильно понял, идёт прямая связь, конкретному городу один вариант прописывается, чтобы все жители одинаково говорили?
	{
		if (rand(4) == 4) sTempShipyarder = GetInfoShipYarder(sTown);//20%, что нам расскажут насколько хорош навык корабела, а не типовую фразу. 
		return sTempShipyarder;
	}
	if(sOwnerType == "Trader") return sTempTrader;
}

string GetInfoShipYarder(string _sTown)
{
	ref refNPCShipyard = CharacterFromID(_sTown+"_shipyarder");
	ref rChar;
	int iYardersSum = 0; 		//всего верфистов на архипелаге
	int iBetterYarders = 0; 	//верфистов с более высоким навыком
	int iBetterNationYarders = 0; 	//верфистов той же нации с более высоким навыком
	string sTemp = "On dit que c'est le pire constructeur de navires de ces eaux. C'est étrange que ses navires restent seulement à flot."; 
	string sBestInNation;
	int iBestInNation = sti(refNPCShipyard.reputation);

	if (sti(refNPCShipyard.reputation) > 19) sTemp = "On ne vante pas son savoir-faire. Il ne construit pas de navires remarquables.";
	if (sti(refNPCShipyard.reputation) > 39) sTemp = "C'est un maître tout à fait ordinaire. Il ne construit pas de navires remarquables, mais il n'en met pas non plus de très mauvais à l'eau.";
	if (sti(refNPCShipyard.reputation) > 59) sTemp = "On vante son savoir-faire. Son chantier produit de bons navires.";
	if (sti(refNPCShipyard.reputation) > 79) sTemp = "On vante beaucoup son savoir-faire. Si vous avez besoin d'un navire remarquable, n'hésitez pas à vous adresser à lui.";
	if (sti(refNPCShipyard.reputation) > 99) sTemp = "Il maîtrise parfaitement la construction navale. N'hésitez pas à vous adresser à lui si vous voulez le meilleur navire.";

	string sTemp2 = "On dit qu'il a les prix les plus bas pour les navires et les réparations.";
	if (stf(refNPCShipyard.shipCostRate) > 0.9) sTemp2 = "On dit qu'il a des prix bas pour les navires et les réparations."; 
	if (stf(refNPCShipyard.shipCostRate) > 1.0) sTemp2 = "On dit qu'il a des prix élevés pour les navires et les réparations."; 
	if (stf(refNPCShipyard.shipCostRate) > 1.1) sTemp2 = "On dit qu'il a des prix exorbitants pour les navires et les réparations."; 
	sTemp += sTemp2;

	for (int j=0; j< MAX_CHARACTERS; j++)
	{
        rChar = GetCharacter(j);
		if (hassubstr(rChar.id, "_shipyarder")) iYardersSum++; else continue;
		if (rChar.id != refNPCShipyard.id && sti(rChar.reputation)>sti(refNPCShipyard.reputation)) //TO DO добавить сюда инфу о том, насколько высокие у него цены
		{
			if (rChar.nation == refNPCShipyard.nation) 
			{
				iBetterNationYarders++; 
				if (sti(rChar.reputation)>iBestInNation) 
				{
					iBestInNation = sti(rChar.reputation);
					sBestInNation = XI_ConvertString("Colony" + rChar.city + "Voc");
				}
			}
			iBetterYarders++; 
		}
	}
	if (iBetterNationYarders == 0) sTemp += "Et le bruit court que c'est le meilleur constructeur de navires des colonies de " + NationNameGenitive(sti(refNPCShipyard.nation)) + ".";
		else sTemp += "Le bruit court aussi qu'à " + sBestInNation + " le constructeur de navires est plus habile, c'est pourquoi nos militaires y commandent leurs navires.";
	//if (iBetterYarders <= 1) sTemp += "There are also rumors that he is the best shipbuilder in the entire archipelago.";

	return sTemp;
}

string GetNationNameX(string snation)
{
	string sTemp;
	switch (snation)
	{
		case "0": sTemp = "anglais"; break;
		case "1": sTemp = "français"; break;// в французских...
		case "2": sTemp = "espagnols"; break;
		case "3": sTemp = "hollandais"; break;
		case "4": sTemp = "pirates"; break;
	}
	return sTemp;
}
