// Gregg: матрос с флагманского корабля, бухта Аматике - «Чёрная Орхидея», глава 5.
// Логика - Program\Quests\reaction_functions\blackorchid.c, DestinyGiftNeedKillFeregueyro.
// НАШЕГО сочинения, в К:ПС этого нет: там корабль просто оказывался у берега, и как
// команда нашла выброшенного на Мэйн капитана, не объяснялось никак. Объяснение -
// анонимное письмо через курьера; кто послал, не знает никто, и это намеренно.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Tout est prêt, capitaine. Nous attendons vos ordres.";
			link.l1 = "Nous appareillons bientכt.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Capitaine ! Vivant... דa fait plusieurs jours que nous fouillons toute la cכte pour vous retrouver, et nous avions presque perdu espoir.";
			link.l1 = "Comment avez-vous même su oם me chercher ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Une lettre est arrivée. א Belize, un coursier l'a fourrée dans les mains du maître d'équipage, sur le quai : votre capitaine est dans la baie d'Amatique, dépêchez-vous. Pas de signature, pas de nom. Le maître d'équipage l'a attrapé par le col : de la part de qui ? Et l'homme ne le savait pas lui-même : on l'avait payé d'avance et chargé de la remettre.";
			link.l1 = "Et vous avez cru un bout de papier sans signature ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(haussant les épaules)... Que nous restait-il d'autre, capitaine ? Nous n'avions aucune autre nouvelle de vous. Nous sommes venus, et vous voilà. Alors il ne mentait pas.";
			link.l1 = "Alors il ne mentait pas. Et le navire ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Réparé et avitaillé, tout est en ordre. Le charpentier a grogné, mais nous nous en sommes sortis. Nous n'attendons plus que vous, capitaine.";
			link.l1 = "Nous appareillons bientכt.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
