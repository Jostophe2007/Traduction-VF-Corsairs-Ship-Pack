
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First":
			dialog.text = "Tu n'as pas peur de te montrer ici à cette heure ? Mes respects.";
			link.l1 = "C'est donc de toi que parlaient les clients de la taverne ?";
			link.l1.go = "Meeting";
			if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_1_man");
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_1_woman");
		break;

		case "Meeting":
			dialog.text = "De qui d'autre ? Voici le jadis légendaire Armando Salazar, El Matador del Mar ! Cependant, les habitants me connaissent mieux sous le surnom de « Boucher des mers »... ";
			link.l1 = "Oui, j'ai entendu parler de toi. Un officier de la Marine royale espagnole, qui commandait la Maria Muette. On le connaît comme un chasseur de pirates implacable.";
			link.l1.go = "Meeting_2";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_2");
		break;

		case "Meeting_2":
			dialog.text = "Assez parlé, peut-être. Je suis dans ce monde depuis trop longtemps. Tue-moi ou meurs !";
			link.l1 = "Et pourquoi faut-il toujours que tout se termine par un banal combat...";
			link.l1.go = "exit";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_3");
		break;

		case "Exit":
			NextDiag.CurrentNode = "Meeting_2";
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "ReefAssholes");
			LAi_group_SetRelation("ReefAssholes", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_Attack(npchar, Pchar);
			LAi_group_SetLookRadius("ReefAssholes", 1000.0);
			SetNoRun(npchar); //инвалид
			LAi_fade("SalasarTeleport", "");
		break;

		case "Last":
			dialog.text = "Tu m'as impressionné ! Aucun de ceux qui ont osé venir ici avant toi n'a pu nous vaincre : ils sont tous restés ici pour toujours.";
			link.l1 = "C'était très dur. Toi et tes gars, vous m'avez bien fait suer. Et je ne me sens pas très bien non plus.";
			link.l1.go = "Last_2";
			if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_4_man");
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_4_woman");
		break;

		case "Last_2":
			dialog.text = "Ma malédiction voulait que je reste dans ce monde, dans cet état, jusqu'à ce qu'on me vainque au combat. Maintenant, elle est brisée, et je peux enfin trouver le repos éternel. Quant à ta santé, c'est l'effet de la malédiction. Avec ma mort définitive, tu te sentiras beaucoup mieux.";
			link.l1 = "Encourageant. Et maintenant ?";
			link.l1.go = "Last_3";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_5");
		break;

		case "Last_3":
			dialog.text = "Je ne veux pas te laisser sans cadeau. Tout ce que tu trouveras ici, dans ce cimetière, est désormais à ta disposition, c'est à toi. Et maintenant, adieu !";
			link.l1 = "Repose en paix, Boucher...";
			link.l1.go = "Last_exit";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Salazar_6");
		break;

		case "Last_exit":
			UnlockAchievement("AchSalazar", 3);
			pchar.questdata.Salazar = 1;
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.questdata.Salazar = 1;
			DialogExit();
			npchar.LifeDay = 0;
			ChangeCharacterAddressGroup(npchar, "none", "", "");
			AddCharacterHealth(pchar, 30);
			chrDisableReloadToLocation = false; //пока Салазар жив - хер, а не выход
			DeleteAttribute(loadedLocation, "box1.items");
			loadedLocation.box1.items.cirass5 = 1;
			loadedLocation.box1.items.pistol8 = 1;
			loadedLocation.box1.items.gold = 1000000;
			loadedLocation.box1.items.blade39 = 1;
			loadedLocation.box1.items.suit_3 = 1;
			loadedLocation.box1.items.chest = 5;
			loadedLocation.box1.items.icollection = 5;
			loadedLocation.box1.items.Ship_Print_1 = 1;
			LAi_LocationFightDisable(loadedLocation, false);
		break;
	}
}
