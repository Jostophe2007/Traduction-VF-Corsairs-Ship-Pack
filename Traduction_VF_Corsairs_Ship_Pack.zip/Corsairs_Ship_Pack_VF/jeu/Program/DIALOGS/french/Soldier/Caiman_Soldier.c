// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions avez-vous pour un soldat ?", "La vie de soldat est toute tracée : gardes, relèves... Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Il n'est pas convenable d'importuner un soldat avec des questions stupides, " + GetAddress_Form(NPChar) + "...", "Pour la troisième fois aujourd'hui, vous essayez de poser une question...",
                          "La part du soldat est déjà bien dure, et voilà que vous, espèce de gredin, vous venez m'énerver...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment."), "Ce n'est pas convenable...",
                      "Oui, c'est vraiment la troisième fois...", "Pardon...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

