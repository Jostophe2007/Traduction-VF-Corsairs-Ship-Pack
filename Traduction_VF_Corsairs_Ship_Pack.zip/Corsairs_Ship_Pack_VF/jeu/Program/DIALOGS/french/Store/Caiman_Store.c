// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	bool bGoldMine, bSilverMine, bIronMine;
	bGoldMine = false;
	bSilverMine = false;
	bIronMine = false;

	if(CheckAttribute(PChar, "ColonyBuilding.GoldMine.BuildingTime"))
	{
		bGoldMine = PChar.ColonyBuilding.GoldMine == true && PChar.ColonyBuilding.GoldMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.SilverMine.BuildingTime"))
	{
		bSilverMine = PChar.ColonyBuilding.SilverMine == true && PChar.ColonyBuilding.SilverMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.IronMine.BuildingTime"))
	{
		bIronMine = PChar.ColonyBuilding.IronMine == true && PChar.ColonyBuilding.IronMine.BuildingTime == false;
	}

	int iCost = 0;
	string sString = "";
	int iQty = 0;

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Je vous écoute, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, j'avais oublié...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";

			link.l2 = "J'aimerais parler de l'approvisionnement de la colonie en marchandises de première nécessité.";
			link.l2.go = "Colony_1";

			link.l3 = "Je voudrais vous parler de la vente automatique des minerais et des marchandises produits dans les mines et les plantations.";
			link.l3.go = "AutoSell_1";
		break;


		case "Colony_1":
			dialog.Text = "Ah, c'est de cela que vous parlez. Qu'est-ce qui vous intéresse exactement ?";
			Link.l1 = "Le coמt de l'approvisionnement de certains établissements.";
			Link.l1.go = "Cost";
			Link.l2 = "Parlez-m'en davantage.";
			Link.l2.go = "AutoPurchase";

			if(PChar.ColonyBuilding.Colony.AutoPurchase == false)
			{
				Link.l3 = "Je voudrais profiter de la possibilité d'approvisionner la colonie.";
				Link.l3.go = "Colony_AutoPurchase";
			}
			else
			{
				Link.l3 = "Il faut suspendre l'approvisionnement de la colonie.";
				Link.l3.go = "Colony_OffAutoPurchase";
			}

			if(bGoldMine || bSilverMine || bIronMine)
			{
				if(PChar.ColonyBuilding.Mines.AutoPurchase == false)
				{
					Link.l4 = "Je voudrais profiter de la possibilité d'approvisionner les mines.";
					Link.l4.go = "Mines_AutoPurchase";
				}
				else
				{
					Link.l4 = "Il faut suspendre l'approvisionnement des mines.";
					Link.l4.go = "Mines_OffAutoPurchase";
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.ColonyBuilding.Plantation.AutoPurchase == false)
				{
					Link.l5 = "Je voudrais profiter de la possibilité d'approvisionner la plantation.";
					Link.l5.go = "Plantation_AutoPurchase";
				}
				else
				{
					Link.l5 = "Il faut suspendre l'approvisionnement de la plantation.";
					Link.l5.go = "Plantation_OffAutoPurchase";
				}
			}

			Link.l6 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l6.go = "exit";
		break;

		case "Colony_AutoPurchase":
			dialog.Text = "Parfait, capitaine ! Soyez sans crainte : dès aujourd'hui, je m'en occupe sérieusement.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "Colony_AutoPurchase_Yes";
			Link.l2 = "Euh... J'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Colony_AutoPurchase_Yes":
			PChar.ColonyBuilding.Colony.AutoPurchase = true;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Mines_AutoPurchase":
			dialog.Text = "Parfait, capitaine ! Soyez sans crainte : dès aujourd'hui, je m'en occupe sérieusement.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "Mines_AutoPurchase_Yes";
			Link.l2 = "Euh... J'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Mines_AutoPurchase_Yes":
			PChar.ColonyBuilding.Mines.AutoPurchase = true;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Plantation_AutoPurchase":
			dialog.Text = "Parfait, capitaine ! Soyez sans crainte : dès aujourd'hui, je m'en occupe sérieusement.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "Plantation_AutoPurchase_Yes";
			Link.l2 = "Euh... J'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Plantation_AutoPurchase_Yes":
			PChar.ColonyBuilding.Plantation.AutoPurchase = true;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Colony_OffAutoPurchase":
			dialog.Text = "Vous êtes sמr, capitaine ?";
			Link.l1 = LinkRandPhrase("Bien sמr. C'est trop cher.", "Certain.", "Trop cher.");
			Link.l1.go = "Colony_OffAutoPurchase_Yes";
			Link.l2 = LinkRandPhrase("Euh... Vous avez raison, mieux vaut ne pas le faire.", "Hum... J'ai changé d'avis.", "Laissons cela !");
			Link.l2.go = "exit";
		break;

		case "Colony_OffAutoPurchase_Yes":
			PChar.ColonyBuilding.Colony.AutoPurchase = false;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Mines_OffAutoPurchase":
			dialog.Text = "Vous êtes sמr, capitaine ?";
			Link.l1 = LinkRandPhrase("Bien sמr. C'est trop cher.", "Certain.", "Trop cher.");
			Link.l1.go = "Mines_OffAutoPurchase_Yes";
			Link.l2 = LinkRandPhrase("Euh... Vous avez raison, mieux vaut ne pas le faire.", "Hum... J'ai changé d'avis.", "Laissons cela !");
			Link.l2.go = "exit";
		break;

		case "Mines_OffAutoPurchase_Yes":
			PChar.ColonyBuilding.Mines.AutoPurchase = false;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Plantation_OffAutoPurchase":
			dialog.Text = "Vous êtes sמr, capitaine ?";
			Link.l1 = LinkRandPhrase("Bien sמr. C'est trop cher.", "Certain.", "Trop cher.");
			Link.l1.go = "Plantation_OffAutoPurchase_Yes";
			Link.l2 = LinkRandPhrase("Euh... Vous avez raison, mieux vaut ne pas le faire.", "Hum... J'ai changé d'avis.", "Laissons cela !");
			Link.l2.go = "exit";
		break;

		case "Plantation_OffAutoPurchase_Yes":
			PChar.ColonyBuilding.Plantation.AutoPurchase = false;
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;

		case "Cost":
			dialog.Text = "De quels établissements parlez-vous ? Le coמt total, ou en tenant compte du remplissage actuel des entrepכts ?";
			Link.l1 = "Le coמt total de l'approvisionnement de la colonie.";
			Link.l1.go = "Cost_Colony_Full";
			Link.l2 = "Le coמt de l'approvisionnement de la colonie, compte tenu du remplissage actuel des entrepכts.";
			Link.l2.go = "Cost_Colony";

			if(bGoldMine || bSilverMine || bIronMine)
			{
				Link.l3 = "Le coמt total de l'approvisionnement des mines.";
				Link.l3.go = "Cost_Mines_Full";
				Link.l4 = "Le coמt de l'approvisionnement des mines, compte tenu du remplissage actuel des entrepכts.";
				Link.l4.go = "Cost_Mines";
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				Link.l5 = "Le coמt total de l'approvisionnement de la plantation.";
				Link.l5.go = "Cost_Plantation_Full";
				Link.l6 = "Le coמt de l'approvisionnement de la plantation, compte tenu du remplissage actuel des entrepכts.";
				Link.l6.go = "Cost_Plantation";
			}

			Link.l7 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l7.go = "exit";
		break;

		case "Cost_Colony_Full":
			iCost = GetSumAutoPurchaseColonyGoods("Colony", false);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt total de l'approvisionnement de la colonie s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "Cost_Colony":
			iCost = GetSumAutoPurchaseColonyGoods("Colony", true);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt de l'approvisionnement de la colonie, selon le remplissage actuel, s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "Cost_Mines_Full":
			iCost = GetSumAutoPurchaseColonyGoods("Mines", false);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt total de l'approvisionnement des mines s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "Cost_Mines":
			iCost = GetSumAutoPurchaseColonyGoods("Mines", true);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt de l'approvisionnement des mines, selon le remplissage actuel, s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "Cost_Plantation_Full":
			iCost = GetSumAutoPurchaseColonyGoods("Plantation", false);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt total de l'approvisionnement de la plantation s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "Cost_Plantation":
			iCost = GetSumAutoPurchaseColonyGoods("Plantation", true);
			dialog.Text = "א l'heure actuelle, compte tenu de la capacité des entrepכts, le coמt de l'approvisionnement de la plantation, selon le remplissage actuel, s'élève à : " + iCost + " piastres.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "quests";
		break;

		case "AutoPurchase":
			dialog.Text = "Approvisionner régulièrement la population, c'est remplir les entrepכts de la colonie et des autres bâtiments avec la quantité manquante de marchandises essentielles : vivres, médicaments, et même outils. Disposer de la quantité nécessaire de ces marchandises garantit une vie agréable dans la colonie. Réapprovisionner à temps les entrepכts de la ville et des autres établissements permet d'éviter les maladies et la famine. Par exemple, pour remplir en ce moment l'entrepכt de la colonie en vivres et en médicaments, il vous faudra " + GetSumAutoPurchaseColonyGoods("Colony", true) + " piastres. L'approvisionnement ne se limite pas à la colonie : il est possible d'approvisionner des établissements comme les mines et les plantations. Tous les quelques jours, les bâtiments que vous aurez choisis sont réapprovisionnés, et si le trésor de la colonie dispose de la somme nécessaire, tout se passera bien. De plus, comme c'est moi qui m'en charge, l'achat des marchandises vous coמtera bien moins cher que dans les autres colonies. Si vous voulez profiter de cette offre, dites-le-moi, tout simplement.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "exit";
		break;

		//////////////////////////////////////////////////////////////////////////
		// АВТО СБЫТ
		//////////////////////////////////////////////////////////////////////////
		case "AutoSell_1":
			dialog.text = "Que vouliez-vous savoir exactement à ce sujet, capitaine ?";
			link.l1 = "Je voudrais revoir les établissements concernés par la vente automatique.";
			link.l1.go = "AutoSell_SetAction";
			link.l2 = "Je veux fixer la quantité de marchandises mises en vente.";
			link.l2.go = "AutoSell_SetQty";
			link.l3 = "Les derniers prix auxquels les marchandises ont été vendues.";
			link.l3.go = "AutoSellCosts";
			link.l4 = "Je veux en savoir plus à ce sujet.";
			link.l4.go = "AutoSellInfo";
			link.l5 = "Désolé, j'ai beaucoup à faire.";
			link.l5.go = "exit";
		break;

		case "AutoSell_SetAction":
			dialog.text = "Hum, voyons voir. " + GetColonyAutoSellWork();

			if(PChar.Mines.GoldMine == true || PChar.Mines.SilverMine == true || PChar.Mines.IronMine == true)
			{
				if(PChar.ColonyBuilding.Mines.AutoSell == false)
				{
					link.l1 = "Je veux que les marchandises de l'entrepכt des mines soient mises en vente.";
					link.l1.go = "AutoSell_Mines_On_1";
				}
				else
				{
					link.l1 = "Je veux suspendre la vente des marchandises de l'entrepכt des mines.";
					link.l1.go = "AutoSell_Mines_Off_1";
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.ColonyBuilding.Plantation.AutoSell == false)
				{
					link.l2 = "Je veux que les marchandises de l'entrepכt de la plantation soient mises en vente.";
					link.l2.go = "AutoSell_Plantation_On_1";
				}
				else
				{
					link.l2 = "Je veux suspendre la vente des marchandises de l'entrepכt de la plantation.";
					link.l2.go = "AutoSell_Plantation_Off_1";
				}
			}

			link.l3 = "Je crois que j'ai changé d'avis.";
			link.l3.go = "exit";
		break;

		case "AutoSell_Mines_On_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "AutoSell_Mines_On_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "AutoSell_Mines_On_2":
			PChar.ColonyBuilding.Mines.AutoSell = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "AutoSell_Plantation_On_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "AutoSell_Plantation_On_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "AutoSell_Plantation_On_2":
			PChar.ColonyBuilding.Plantation.AutoSell = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "AutoSell_Mines_Off_1":
			dialog.text = "Voulez-vous vraiment suspendre la vente des minerais extraits ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "AutoSell_Mines_Off_2";
			link.l2 = LinkRandPhrase("Laissons cela !", "J'ai sans doute changé d'avis : il faut écouler la production en temps voulu.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "AutoSell_Mines_Off_2":
			PChar.ColonyBuilding.Mines.AutoSell = false;
			dialog.text = "Comme vous voudrez, capitaine. Dans ce cas, dès que vous déciderez de reprendre la vente des marchandises des mines, revenez me voir.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "AutoSell_Plantation_Off_1":
			dialog.text = "Voulez-vous vraiment suspendre la vente des marchandises produites sur la plantation ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "AutoSell_Plantation_Off_2";
			link.l2 = LinkRandPhrase("Laissons cela !", "J'ai sans doute changé d'avis : il faut écouler la production en temps voulu.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "AutoSell_Plantation_Off_2":
			PChar.ColonyBuilding.Plantation.AutoSell = false;
			dialog.text = "Comme vous voudrez, capitaine. Dans ce cas, dès que vous déciderez de reprendre la vente des marchandises de la plantation, revenez me voir.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "AutoSell_SetQty":
			if(PChar.ColonyBuilding.Mines.AutoSell == false && PChar.ColonyBuilding.Plantation.AutoSell == false)
			{
				dialog.text = "Capitaine, à l'heure actuelle, aucune vente automatique n'est effectuée, ni dans les mines ni sur la plantation.";
				link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
				link.l1.go = "exit";
				break;
			}

			dialog.text = "Quantité actuelle de marchandises mises en vente pour les mines : " + GetColonyAutoSellCurrentQty("Mines") + ", et pour la plantation : " + GetColonyAutoSellCurrentQty("Plantation") + ". La quantité maximale de marchandises mises en vente pour les mines est de " +AUTO_SELL_MINES_MAX+ ", et pour les plantations : " +AUTO_SELL_PLANTATION_MAX+ ".";

			if(PChar.ColonyBuilding.Mines.AutoSell == true)
			{
				link.l1 = "Il faut modifier la quantité de marchandises vendues aux mines.";
				link.l1.go = "AutoSell_SetQty_Mines_1";
			}

			if(PChar.ColonyBuilding.Plantation.AutoSell == true)
			{
				link.l2 = "Il faut modifier la quantité de marchandises vendues sur la plantation.";
				link.l2.go = "AutoSell_SetQty_Plantation_1";
			}

			link.l3 = "Je crois que j'ai changé d'avis.";
			link.l3.go = "exit";
		break;

		case "AutoSell_SetQty_Mines_1":
			dialog.text = "Alors, quelle quantité voulez-vous fixer pour la vente des marchandises des mines ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "AutoSell_SetQty_Mines_2";
		break;

		case "AutoSell_SetQty_Mines_2":
			sString = GetStrSmallRegister(dialogEditStrings[1]);
			iQty = sti(sString);

			if(iQty <= 0)
			{
				dialog.text = "Vous plaisantez ?";
				link.l1 = "Essayons encore...";
				link.l1.go = "AutoSell_SetQty_Mines_1";
				link.l2 = "J'ai changé d'avis.";
				link.l2.go = "exit";
				break;
			}

			if(iQty > AUTO_SELL_MINES_MAX)
			{
				dialog.text = iQty + " ? Capitaine, je vous ai prévenu : la quantité maximale pour la vente des marchandises produites aux mines est de " + AUTO_SELL_MINES_MAX + " unités.";
				link.l1 = "Essayons encore...";
				link.l1.go = "AutoSell_SetQty_Mines_1";
				link.l2 = "J'ai changé d'avis.";
				link.l2.go = "exit";
				break;
			}

			dialog.text = iQty + " ? Eh bien, c'est un chiffre acceptable. Vous êtes sמr de votre décision ?";
			link.l1 = "Oui, absolument.";
			link.l1.go = "AutoSell_SetQty_Mines_3";
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "exit";
		break;

		case "AutoSell_SetQty_Mines_3":
			sString = GetStrSmallRegister(dialogEditStrings[1]);
			iQty = sti(sString);

			PChar.ColonyBuilding.Mines.AutoSell.Qty = iQty;
			dialog.text = "Très bien, capitaine.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "AutoSell_SetQty_Plantation_1":
			dialog.text = "Alors, quelle quantité voulez-vous fixer pour la vente des marchandises de la plantation ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "AutoSell_SetQty_Plantation_2";
		break;

		case "AutoSell_SetQty_Plantation_2":
			sString = GetStrSmallRegister(dialogEditStrings[1]);
			iQty = sti(sString);

			if(iQty <= 0)
			{
				dialog.text = "Vous plaisantez ?";
				link.l1 = "Essayons encore...";
				link.l1.go = "AutoSell_SetQty_Plantation_1";
				link.l2 = "J'ai changé d'avis.";
				link.l2.go = "exit";
				break;
			}

			if(iQty > AUTO_SELL_PLANTATION_MAX)
			{
				dialog.text = iQty + " ? Capitaine, je vous ai prévenu : la quantité maximale pour la vente des marchandises produites sur la plantation est de " + AUTO_SELL_PLANTATION_MAX + " unités.";
				link.l1 = "Essayons encore...";
				link.l1.go = "AutoSell_SetQty_Plantation_1";
				link.l2 = "J'ai changé d'avis.";
				link.l2.go = "exit";
				break;
			}

			dialog.text = iQty + " ? Eh bien, c'est un chiffre acceptable. Vous êtes sמr de votre décision ?";
			link.l1 = "Oui, absolument.";
			link.l1.go = "AutoSell_SetQty_Plantation_3";
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "exit";
		break;

		case "AutoSell_SetQty_Plantation_3":
			sString = GetStrSmallRegister(dialogEditStrings[1]);
			iQty = sti(sString);

			PChar.ColonyBuilding.Plantation.AutoSell.Qty = iQty;
			dialog.text = "Très bien, capitaine.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "AutoSellCosts":
			dialog.text = "Or : " + GetCurrentGoodBaseCostForAutoSell(GOOD_GOLD) + " piastres ; argent : " + GetCurrentGoodBaseCostForAutoSell(GOOD_SILVER) + " piastres ; fer : " + GetCurrentGoodBaseCostForAutoSell(GOOD_IRON) + " piastres ; sucre : " + GetCurrentGoodBaseCostForAutoSell(GOOD_SUGAR) + " piastres ; café : " + GetCurrentGoodBaseCostForAutoSell(GOOD_COFFEE) + " piastres.";
			link.l1 = "Merci pour l'information. Parlons encore de la vente.";
			link.l1.go = "AutoSell_1";
			link.l2 = "Merci pour l'information. Je crois que je vais y aller.";
			link.l2.go = "exit";
		break;

		case "AutoSellInfo":
			dialog.text = "Pour que la plantation et les mines rapportent régulièrement des revenus à la colonie, vous pouvez recourir à la vente automatique des marchandises des entrepכts après chaque extraction de minerais et de marchandises.\nא chaque fois, le nombre d'unités que vous aurez indiqué sera prélevé dans les entrepכts pour être vendu. Il existe une quantité maximale de minerais et de marchandises par vente : vous ne pouvez vendre plus de " +AUTO_SELL_MINES_MAX+ " unités de chaque minerai des mines, ni plus de " +AUTO_SELL_PLANTATION_MAX+ " unités des marchandises produites sur la plantation.\nSi la quantité en stock est inférieure à celle que vous avez indiquée, toutes les marchandises disponibles de ce type sont mises en vente. Pour chaque vente effectuée de cette façon, vous recevrez une notification. Il faut noter que les minerais et les marchandises seront vendus à des prix inférieurs à ceux que vous obtiendriez en vendant vous-même, puisque je prends en charge tous les frais de recherche d'acheteurs et de transport.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;
	}

	UnloadSegment(NPChar.FileDialog2);
}

