//мумия в алькове
void ProcessDialogEvent()
{
	ref NPChar, PChar, d;
	PChar = GetMainCharacter();
	aref Link, Diag;
	string NPC_Meeting;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

        case "First time":
			dialog.text = "... (le squelette reprend le bras métallique et l'emboîte en place avec un cliquetis ; le bras se met à bouger)";
			link.l1 = "Qu'est-ce que c'est ?!";
			link.l1.go = "Term_1";
			TakeNItems(Pchar, "term_arm", -1);
			LAi_CharacterPlaySoundAtOnce(NPChar, "T102_Intro");
		break;

		case "Term_1":
			dialog.text = "Je suis un cyborg de modèle T-102, fabriqué par Skynet Production, enclave de Detroit, série 2022. Je t'ai rattrapé, homme du navire étrange.";
			link.l1 = "Qui ? Quoi ? Quel genre de Ki Borg ? En quelle année sommes-nous ? C'est le dix-septième siècle après la naissance du Christ ! Tu es un esprit malin ! Mais pour une raison ou une autre, en métal, ce qui est étrange.";
			link.l1.go = "Term_2";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_1");
			if(startherotype == 2)
			{
				link.l1 = "Skynet Production ? Je n'ai jamais entendu parler d'une telle corporation. Bon sang, on dirait que par mes actes ici, j'ai violé la séquence temporelle, ce qui a engendré un futur alternatif. Dis-moi, sais-tu quelque chose sur la corporation Omnitech ? Il me semble qu'en 2022, elle existait déjà.";
				link.l1.go = "Whisper_Term_2";
			}

		break;

		case "Whisper_Term_2":
			dialog.text = "Aucune correspondance dans ma base de données pour cette requête.";
			link.l1 = "Bon sang ! C'est très mauvais. Bref, qu'est-ce que tu fais à cette époque ?";
			link.l1.go = "Term_3";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_2");
		break;

		case "Term_2":
			dialog.text = "Ne discute pas avec moi, individu biologique qui s'identifie comme " +GetFullName(pchar) +
			              ". Je suis une machine à revêtement biologique, un cyborg. Le revêtement avait une durée de vie plus courte que la base principale, faite d'un alliage de polymères métalliques. En 170 ans, le revêtement biologique a été perdu. Ma ressource est à sa limite. L'alimentation nucléaire est hors service, je fonctionne en mode veille.";
			link.l1 = "Un siècle et demi ? Je n'ai pas compris, alors. Quand es-tu né, au XVe siècle ou au XXIe ?";
			link.l1.go = "Term_3";
			if (startherotype > 0 && startherotype < 9) LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_3_"+startherotype);
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_3_unknown");
		break;

		case "Term_3":
			dialog.text = "Error. Main power is too low. Critical error - restarting....";
			link.l1 = "Quoi ?";
			link.l1.go = "Term_4";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_4");
		break;

		case "Term_4":
			dialog.text = "Loading from backup store....";
			link.l1 = "Qu'est-ce qui lui prend ? Mon cher, à qui parles-tu en ce moment ? Moi, je ne parle pas du tout aux esprits malins, je fais une exception ici, mais lui, si !";
			if(startherotype == 2)
			{
				link.l1 = "On dirait qu'il respire avec peine, il va tomber en morceaux. Hé, tu es là ?";
			}
			link.l1.go = "Term_5";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_5");
		break;

		case "Term_5":
			dialog.text = "Système prêt.......Je suis un cyborg de modèle T-102, fabriqué par Skynet Production, enclave de Detroit, série 2022.";
			link.l1 = "Je l'ai déjà entendu ! Ne m'énerve pas, stupide tas de ferraille !";
			link.l1.go = "Term_6";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_6");
		break;

		case "Term_6":
			dialog.text = "Ma mission était de remonter le temps, année 1985, cible : Sarah Connor, destruction.";
			link.l1 = "Et nous, nous sommes en " + GetDataYear() + " ! Et il n'y a pas de Sarah ici.";
			if(startherotype == 2)
			{
				link.l1 = "Tu as raté l'année de beaucoup, tout comme moi.";
			}
			link.l1.go = "Term_7";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_7");
		break;

		case "Term_7":
			dialog.text = "Lors de l'envoi, les distorsions causées par les armes et l'uniforme n'ont pas été prises en compte. Le calage temporel a échoué. Livraison à la fin du XVe siècle. Tâche principale : accomplir la mission. Les recherches n'ont donné aucun résultat.";
			link.l1 = "Admettons, mais quel rapport avec moi ?";
			link.l1.go = "Term_8";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_8");
		break;

		case "Term_8":
			dialog.text = "Le manipulateur est une partie intégrante de la base de données. Le manipulateur porte un marqueur : il l'a pris. Le manipulateur a été perdu lors de l'opération « Je reviendrai », menée sur un navire étrange il y a 30 ans. Les habitants non identifiables du navire, absents du catalogue de la base de données d'identification, se sont révélés agressifs, mais objets peu destructibles. Définition : cyborgs à base biologique, source d'énergie inconnue.";
			link.l1 = "Oh, tu parles du vaisseau fantכme, ou quoi ? C'est clair, ils sont comme toi, en fait, seulement ils sont plus nombreux, alors ils t'ont submergé ! J'en ai souffert, moi aussi.";
			if(startherotype == 2)
			{
				link.l1 = "Oh, tu parles du vaisseau fantכme, ou quoi ? J'en ai souffert, moi aussi.";
			}
			link.l1.go = "Term_9";
			if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_9_man");
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_9_woman");
		break;

		case "Term_9":
			dialog.text = "Maintenant, le manipulateur est intégré et fonctionne correctement. Auparavant, il était inaccessible en raison d'une barrière d'eau et de déplacements constants.";
			link.l1 = "Qui va oם correctement quoi ?";
			link.l1.go = "Term_9_1";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_10");
		break;

		case "Term_9_1":
			dialog.text = "Ce n'est pas important.";
			link.l1 = "Oh, alors l'opération « Je reviendrai », c'est juste une fuite ? Ou, comme je dis, une manœuvre d'éloignement stratégique de l'ennemi.";
			link.l1.go = "Term_9_2";
		break;

		case "Term_9_2":
			dialog.text = "Oui, individu « " +GetFullName(pchar) +" », tu as raison. Mon temps s'épuise avec la décharge de la batterie de secours. La mission ne peut pas être accomplie, l'objet n'a pas été détecté, et l'analyse génétique a montré l'absence dans cette zone des ancêtres les plus proches de la cible.";
			link.l1 = "Oui, tu n'as pas de chance. Il est temps de prendre ta retraite, apparemment. J'ai déjà compris oם trouver une bonne arme. Si je rencontre Sarah O'Connor, je la tuerai sans faute, en paiement d'un tel cadeau des descendants.";
			if(startherotype == 2)
			{
				link.l1 = "Oui, tu n'as pas de chance. Bon, si tu n'as pas sur toi de machine à remonter le temps en état de marche, nous n'avons plus rien à nous dire. Je crois que je vais y aller.";
			}
			link.l1.go = "Term_11";
			if (startherotype > 0 && startherotype < 9) LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_11_"+startherotype);
			else
			{
				if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_11_man");
				else LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_11_woman");
			}

		break;

		case "Term_10":
			dialog.text = "Merci pour votre coopération. Balayage en cours... terminé... Je n'ai pas besoin de vos vêtements. Au revoir.";
			link.l1 = "Tiens ! Faites le bien, et on ne vous laissera pas en paix !";
			link.l1.go = "Term_10_exit";
			//PChar.GenQuest.GhostShip.TakeShotgun = true;
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_12");
		break;

		case "Term_10_exit":
            LAi_SetPlayerType(PChar);
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", 4.0);
			//ChangeCharacterAddressGroup(NPChar, "none", "", "");
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "Term_11":
			dialog.text = "Balayage en cours... terminé... Votre phénotype est similaire à 68 % à celui de Sarah Connor. Vous êtes un ancêtre potentiel. La mission doit être accomplie. Exécution immédiate.";
			link.l1 = "C'est la première fois qu'on me dit de façon aussi alambiquée qu'on veut me tuer. Bon, tas de ferraille, je ne vais pas faire attention à ton grand âge, je vais te dépoussiérer.";
			link.l1.go = "Term_11_exit";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_13");
			if(startherotype == 2)
			{
				link.l1 = "Stupide tas de ferraille, quel ancêtre ? Tu ne comprends pas ? Je viens moi-même du futur. Tes entrailles sont déjà toutes noyées, ou quoi ?";
				link.l1.go = "Term_11_Whisper";
			}

		break;

		case "Term_11_Whisper":
			dialog.text = "La cible se montre agressive. Mode combat activé.";
			link.l1 = "Tu n'aurais pas dמ commencer. א mon époque, j'ai réussi à détruire beaucoup de tes semblables, et c'étaient des modèles plus récents et plus meurtriers.";
			link.l1.go = "Term_11_exit";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Terminator_14");
		break;

		case "Term_11_exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
            NPChar.location = "none";
            LAi_SetWarriorType(NPChar);

			LAi_group_MoveCharacter(NPChar, "TmpEnemy");
			LAi_group_SetCheck("TmpEnemy", "Kill_T102");
			LAi_group_FightGroups(LAI_GROUP_PLAYER, "TmpEnemy", true);
			LAi_SetPlayerType(PChar);
			//Вытащим саблю
   			LAi_SetFightMode(Pchar, true);
			NPChar.SaveItemsForDead = true;
   			chrDisableReloadToLocation = true;
			pchar.quest.T102.win_condition.l1 = "NPC_Death";
			pchar.quest.T102.win_condition.l1.character = "T102";
			pchar.quest.T102.function = "T102_DoorUnlock";
		break;
	}
}
