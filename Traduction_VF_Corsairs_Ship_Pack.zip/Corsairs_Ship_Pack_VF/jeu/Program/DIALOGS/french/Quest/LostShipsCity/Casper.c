
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "";
			link.l1 = "";
			link.l1.go = "";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fightQuest":
			pchar.questTemp.LSC.Armo.checkCasper = npchar.index; //для обработки в АИ
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//первый каспер на разводе Армо
		case "Casper_1":
			dialog.text = "Hé, "+ GetSexPhrase("l'ami", "ma petite") +", fiche le camp d'ici ! Dégage le terrain.";
			link.l1 = "Qu'y a-t-il ?";
			link.l1.go = "Casper_1_1";
			NextDiag.TempNode = "Casper_12";
			DeleteAttribute(npchar, "checkChrDistance.node");
		break;
		case "Casper_1_1":
			dialog.text = "J'attends quelqu'un ici, un troisième serait de trop. Compris ?";
			link.l1 = "Tu attends Armo ? Alors c'est moi qui la remplace.";
			link.l1.go = "Casper_1_2";
			link.l2 = "Ah, je vois. Bon, d'accord...";
			link.l2.go = "exit";
		break;
		case "Casper_1_2":
			dialog.text = "Quoi ?!";
			link.l1 = "Tu ne comprends toujours pas ? Eh bien, tu vas comprendre...";
			link.l1.go = "fightQuest";
		break;

		case "Casper_12":
			dialog.text = "וcoute, je crois que je me suis bien fait comprendre. Fiche le camp d'ici, "+ GetSexPhrase("l'ami", "ma petite") +"...";
			link.l1 = "Tu n'attendrais pas Armo, mon ami ? Elle ne viendra pas, c'est moi qui la remplace.";
			link.l1.go = "Casper_12_1";
			link.l2 = "D'accord, d'accord...";
			link.l2.go = "exit";
			NextDiag.TempNode = "Casper_13";
		break;
		case "Casper_12_1":
			dialog.text = "Quoi ?!";
			link.l1 = "Tu ne comprends toujours pas ? Eh bien, tu vas comprendre...";
			link.l1.go = "fightQuest";
		break;

		case "Casper_13":
			dialog.text = "Bon, ça y est, tu m'as eu. דa ne s'arrange pas bien...";
			link.l1 = "Eh oui, je suis tenace !";
			link.l1.go = "fightQuest";
		break;
		//второй каспер на разводе Армо
		case "Casper_3":
			dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +", tu ferais mieux de filer d'ici...";
			link.l1 = "Laquelle ?";
			link.l1.go = "Casper_3_1";
			NextDiag.TempNode = "Casper_32";
			DeleteAttribute(npchar, "checkChrDistance.node");
		break;
		case "Casper_3_1":
			dialog.text = "Eh bien, vous savez, j'ai un rendez-vous ici. Alors votre présence est indésirable, pour le dire gentiment.";
			link.l1 = "Ce ne serait pas Armo que vous attendez, par hasard ?";
			link.l1.go = "Casper_3_2";
			link.l2 = "D'accord, l'ami.";
			link.l2.go = "exit";
		break;
		case "Casper_3_2":
			dialog.text = "Comment le savez-vous ?";
			link.l1 = "Il n'y aura pas d'Armo, c'est moi qui prendrai sa place.";
			link.l1.go = "fightQuest";
		break;

		case "Casper_32":
			dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +"Je vous en prie, ne soyez pas grossier.";
			link.l1 = "De la grossièreté ? Héhé, bon, ça suffit. Armo ne viendra pas, c'est moi qui la remplace.";
			link.l1.go = "Casper_32_1";
			link.l2 = "D'accord.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Casper_33";
		break;
		case "Casper_32_1":
			dialog.text = "Comment ça ?";
			link.l1 = "Comme tu veux, comprends...";
			link.l1.go = "fightQuest";
		break;

		case "Casper_33":
			dialog.text = "Je t'avais prévenu, "+ GetSexPhrase("l'ami", "ma fille") +". Maintenant, ne t'en prends qu'à toi-même !";
			link.l1 = "א qui dois-je m'en prendre ? Attends, je n'ai pas entendu...";
			link.l1.go = "fightQuest";
		break;
		//третий каспер на разводе Армо
		case "Casper_5":
			dialog.text = "Hé, fiche le camp d'ici tant que tu es en vie !";
			link.l1 = "Hum, et pourquoi ça ?";
			link.l1.go = "Casper_5_1";
			NextDiag.TempNode = "Casper_52";
			DeleteAttribute(npchar, "checkChrDistance.node");
		break;
		case "Casper_5_1":
			dialog.text = "Parce que je suis là ! J'ai un rendez-vous ici. Compris"+ GetSexPhrase(" ?", " ? Et pas avec toi.") +"";
			link.l1 = "Un rendez-vous avec Armo ? Eh bien, c'est pour rien...";
			link.l1.go = "Casper_5_2";
			link.l2 = "Compris...";
			link.l2.go = "exit";
		break;
		case "Casper_5_2":
			dialog.text = "Oui, avec Armo.";
			link.l1 = "Il n'y aura pas d'Armo, c'est avec moi que tu as rendez-vous.";
			link.l1.go = "fightQuest";
		break;

		case "Casper_52":
			dialog.text = "וcoute, je t'ai déjà dit de filer d'ici !";
			link.l1 = "Si tu l'attends, elle ne viendra pas. Tu vois, c'est avec moi que tu as rendez-vous.";
			link.l1.go = "Casper_52_1";
			link.l2 = "Oui, oui, je m'en vais déjà...";
			link.l2.go = "exit";
			NextDiag.TempNode = "Casper_53";
		break;
		case "Casper_52_1":
			dialog.text = "Quoi ?!";
			link.l1 = "Quel idiot !..";
			link.l1.go = "fightQuest";
		break;

		case "Casper_53":
			dialog.text = "דa suffit, j'en ai assez de te persuader...";
			link.l1 = "Oui, je crois que ça suffit.";
			link.l1.go = "fightQuest";
		break;
		//ГГ застукали за первым
		case "FackYou":
			dialog.text = "Ce n'est pas pour rien que je me méfiais. Trop des nכtres disparaissent...";
			link.l1 = ""+ GetSexPhrase("Oh... De quoi tu parles ?", "Que diable... De quoi tu parles ?") +"";
			link.l1.go = "FackYou_1";
		break;
		case "FackYou_1":
			dialog.text = "De cette garce d'Armo. Et de toi, bien sמr, "+ GetSexPhrase("l'ami", "ma petite") +". Qu'est-ce que tu fabriques, "+ GetSexPhrase("brute", "vaurienne") +" ?";
			link.l1 = ""+ GetSexPhrase("Je ne sais même pas comment le dire... Bon, en gros, je découpe les Caspers un par un.", "Tu m'as retrouvée, salaud... Oui, je vous découpe, vous, la racaille, un par un.") +"";
			link.l1.go = "FackYou_2";
		break;
		case "FackYou_2":
			dialog.text = "Compris... Eh bien, ce n'est pas pour rien que j'ai saigné Armo.";
			link.l1 = "Quoi ?!";
			link.l1.go = "FackYou_3";
		break;
		case "FackYou_3":
			dialog.text = "Oui, oui, "+ GetSexPhrase("l'ami", "ma petite") +". J'ai envoyé Armo rejoindre son patron, Hill Brunner. Et c'est juste : ils s'amusaient si bien ensemble...";
			link.l1 = ""+ GetSexPhrase("Tu vas me le payer !", "Oh, toi... C'en est fini de toi, salaud.") +"";
			link.l1.go = "FackYou_4";
		break;
		case "FackYou_4":
			dialog.text = "Quoi, tu me crois complètement idiot ? Hier, tout est devenu clair pour moi, même si ce n'étaient que des soupçons. Et maintenant, je ne suis pas seul.";
			link.l1 = ""+ GetSexPhrase("דa ne t'aidera pas...", "דa ne t'aidera pas ! Crève, salaud !!") +"";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("LSC_3CarperAttackArmo");
		break;

	}
}
