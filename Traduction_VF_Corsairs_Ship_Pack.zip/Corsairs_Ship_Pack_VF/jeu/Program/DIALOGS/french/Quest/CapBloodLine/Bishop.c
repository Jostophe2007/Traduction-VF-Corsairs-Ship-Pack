// Блад
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
    string sLocator;
    int iTime, n;
    string sTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

/*
	switch(Pchar.questTemp.CapBloodLine.stat)
    {
  		case "1":
            Dialog.CurrentNode = "First Bishop";
		break;

		case "2":
            Dialog.CurrentNode = "First Guard";
		break;

		case "3":
            Dialog.CurrentNode = "First Stid";
		break;

		case "4":
            Dialog.CurrentNode = "First MsStid";
		break;

    }
    */


	switch(Dialog.CurrentNode)
	{
	    // --> Бишоп
		// ----------------------------------- Диалог первый - первая встреча
		case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Exit_Away":

            LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorGoToLocation(npchar, "reload", Pchar.questTemp.CapBloodLine.sLocator, "none", "", "", "", sti(Pchar.questTemp.CapBloodLine.iTime));
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

        case "Exit_RunAway":

            LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorRunToLocation(npchar, "reload", Pchar.questTemp.CapBloodLine.sLocator, "none", "", "", "", sti(Pchar.questTemp.CapBloodLine.iTime));
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

        case "GFight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
            sld = &characters[GetCharacterIndex("Dragun_0")];
            LAi_SetCheckMinHP(sld, 1, true, "Dragun_0_CheckMinHP");
            LAi_SetImmortal(sld, false);
   	        LAi_SetWarriorTypeNoGroup(sld);//fix
   	        LAi_warrior_DialogEnable(sld, false);//fix
            LAi_group_MoveCharacter(sld, "TmpEnemy");
            //LAi_group_FightGroups("TmpEnemy", LAI_GROUP_PLAYER, true);
            LAi_group_Attack(sld, Pchar);
            LAi_group_SetRelation("TmpEnemy", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);//fix
            LAi_group_SetHearRadius("TmpEnemy", 3000.0); //fix
			AddDialogExitQuest("MainHeroFightModeOn");
			//LAi_ActorRunToLocation(NPChar, "goto", "goto6", "none", "", "", "", 20);
			LAi_ActorGoToLocator(NPChar, "goto", "goto6", "", -1);

		break;

        case "fight1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
   	        LAi_SetWarriorType(NPChar);
            LAi_group_MoveCharacter(NPChar, "TmpEnemy");
            LAi_group_FightGroups("TmpEnemy", LAI_GROUP_PLAYER, true)
			AddDialogExitQuest("MainHeroFightModeOn");
			Spain_spyDie("");
			AddQuestRecord("WeaponsForEscape", "5");

		break;

        case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
   	        LAi_SetWarriorType(NPChar);
            LAi_group_MoveCharacter(NPChar, "TmpEnemy");
            LAi_group_FightGroups("TmpEnemy", LAI_GROUP_PLAYER, true);
			AddDialogExitQuest("MainHeroFightModeOn");

		break;

		case "Finish":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			RestoreBridgetown();
			initMainCharacterItem();
            ref mc = GetMainCharacter();
            mc.Ship.Type = GenerateShipExt(SHIP_ARABELLA, true, mc);
            mc.Ship.name="Arabella";
            SetBaseShipData(mc);
            mc.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS32;
            SetCrewQuantityFull(mc);

            SetCharacterGoods(mc,GOOD_FOOD,2000);
        	SetCharacterGoods(mc,GOOD_BALLS,2000);//2000);
            SetCharacterGoods(mc,GOOD_GRAPES,300);//700);
            SetCharacterGoods(mc,GOOD_KNIPPELS,400);//700);
            SetCharacterGoods(mc,GOOD_BOMBS,2000);//1500);
            SetCharacterGoods(mc,GOOD_POWDER,2000);
            SetCharacterGoods(mc,GOOD_PLANKS,10);
            SetCharacterGoods(mc,GOOD_RUM,40);//600);
            SetCharacterGoods(mc,GOOD_WEAPON,2000);//2000);
            DoReloadCharacterToLocation(Pchar.HeroParam.Location, Pchar.HeroParam.Group, Pchar.HeroParam.Locator);
		break;

        case "Man_FackYou":
			dialog.text = LinkRandPhrase("Du vol en plein jour !!! Qu'est-ce que c'est que ces manières ?! Attends un peu, l'ami...", "Hé, qu'est-ce que tu fais là ?! Pas possible, tu essaies de me voler ? Eh bien, tu es fini...", "Attends, oם vas-tu ? Tu es donc un voleur ! Eh bien, considère que tu as fini de naviguer, mon cher...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "fight_owner";
		break;
		case "fight_owner":
			LAi_SetOwnerTypeNoGroup(NPChar);
			LAi_group_Attack(NPChar, Pchar);
			//if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NextQuest":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			Pchar.questTemp.CapBloodLine.stat = "";
            CapBloodLineInit("");
		break;







		case "First time":
        	dialog.text = "Erreur";
            link.l1 = "...";
            link.l1.go = "Exit";
            npchar.quest.meeting = "1";

            if (npchar.id == "Pitt")
            {
     			if (bBettaTestMode)
                {
			        link.l0 = "BetaTest : passer et commencer la partie.";
			        link.l0.go = "Finish";
                }

                if (Pchar.questTemp.CapBloodLine.stat == "Begining")
                {
                    dialog.text = "Lord Gildoy est grièvement blessé... il est ici, dans la maison... je l'y ai traîné... Il m'a envoyé vous chercher... Dépêchez-vous d'aller le voir ! Vite !";
            		link.l1 = "Merci, Pitt... Je vais aller le voir ; toi, reste ici, et si tu vois les dragons du roi arriver au galop, préviens-nous immédiatement.";
                    link.l1.go = "Exit_Away";
                    Pchar.questTemp.CapBloodLine.sLocator = "reload1";
                    Pchar.questTemp.CapBloodLine.iTime = -1;
           			if (bBettaTestMode)
                    {
				        link.l3 = "BetaTest : vers la deuxième quête.";
				        link.l3.go = "NextQuest";
                    }
            		break;
        		}

                if (Pchar.questTemp.CapBloodLine.stat == "CureMisStid")
                {
                    dialog.text = "Peter, le colonel Bishop te cherche depuis le début de la soirée : la femme du gouverneur a encore une crise. Tu dois te rendre d'urgence à la résidence du gouverneur Steed.";
            		link.l1 = "Merci, Pitt, il me l'a dit.";
            		link.l1.go = "Exit";
            		break;
        		}
                if (Pchar.questTemp.CapBloodLine.stat == "WakerOfferComplited")
                {
                    dialog.text = "Comment allez-vous, mon ami ?";
            		link.l1 = "Baissez la voix : c'est notre sort qui se joue, collègue.";
            		link.l1.go = "PStep_0";
            		break;
        		}

                dialog.text = "Désolé, Peter, je dois aller travailler.";
        		link.l1 = "D'accord, vas-y.";
        		link.l1.go = "Exit";

    		}

            if (npchar.id == "Beyns")
            {
                dialog.text = "Oh, bonjour, docteur Blood, comme c'est aimable à vous d'être venu. Lord Gildoy est grièvement blessé... Il est couché dans une chambre à l'étage, dans l'aile ouest de la maison...";
        		link.l1 = "Je suis venu aussi vite que j'ai pu. Je monte le voir tout de suite ; pendant ce temps, préparez de l'eau chaude et du linge propre.";
        		link.l1.go = "EBStep_0";
    		}

            if (npchar.id == "CapGobart")
            {
                dialog.text = "Je suis le capitaine Hobart, des dragons du colonel Kirke. Vous abritez des rebelles ? Qui est cet estropié couché à l'étage ?";
        		link.l1 = "Nous n'abritons pas de rebelles, monsieur. Ce gentilhomme est blessé...";
        		link.l1.go = "CGStep_1";
        		DragunInvansion4();
    		}

            if (npchar.id == "Bridgetown_Mayor" )
            {
                if( Pchar.questTemp.CapBloodLine.stat == "CureMisStid" )
                {
                    dialog.text = "J'étais sur le point d'envoyer chercher Wacker. Pourquoi avez-vous mis tant de temps ?";
            		link.l1 = "J'ai été retardé. Je suis désolé, monsieur le gouverneur.";
            		link.l1.go = "SStep_0";
            		link.l2 = "Vos gens m'ont retenu, gouverneur Steed. Il s'avère que vos ordres peuvent être discutés ; en outre, certaines personnes m'empêchent activement de soigner les soldats espagnols.";
            		link.l2.go = "SStep_1";
            		break;
                }

                if( Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape3" )
                {
                    dialog.text = "Salutations, docteur Blood. א quoi dois-je votre visite ?";
            		link.l1 = "Bonjour, monsieur le gouverneur. J'ai apporté un peu plus d'extrait préventif pour votre épouse, et j'aimerais pouvoir l'examiner.";
            		link.l1.go = "SStep_9";
            		break;
                }
                dialog.text = "Que voulez-vous, docteur Blood ?";
          		link.l1 = "Non, rien, désolé de vous avoir dérangé.";
          		link.l1.go = "Exit";
 		         NextDiag.TempNode = "First time";
    		}

    		if (npchar.id == "MisStid" && Pchar.questTemp.CapBloodLine.stat == "CureMisStid")
    		{
            	dialog.text = "Oh, docteur Blood ! Enfin... Je vous en prie, aidez-moi !";
        		link.l1 = "Bonsoir, madame Steed. Ne vous inquiétez pas, il faut vous calmer et cesser de plisser les yeux : soyez patiente et regardez-moi, j'ai besoin de voir vos yeux.";
        		link.l1.go = "MSStep_0";
    		}

    		if (npchar.id == "Nettl" ) // && Pchar.questTemp.CapBloodLine.stat == "CureMisStid"
    		{
            	dialog.text = "Hé, l'ami... J'ai toute ma tête et... et... bon. Quel bonjour... En bonne santé ? Ah, oui, sobre... Oui, sobre. Tu sais comment on fait ? Disparaître quelque part, et... et puis réapparaître quelque part... quelque part pas du tout à sa place... pas là oם on a disparu ?";
	            if( Pchar.questTemp.CapBloodLine.stat == "needMoney")
                {
                	link.l1 = "Je dois avouer que je ne connais qu'un seul tour de ce genre.";
                    link.l1.go = "NStep_6";
                }
                else
                {
            		link.l1 = "J'aimerais bien le savoir moi-même, mon vieux.";
            		link.l1.go = "NStep_0";
                }
    		}

    		if (npchar.id == "Waker")
    		{
                if(Pchar.questTemp.CapBloodLine.stat == "CureMisStid")
                {
                	dialog.text = "Docteur Blood, comme je suis content de vous voir ! Je vous ai cherché aujourd'hui, mais en vain : vous vous déplacez dans la ville comme un fantכme.";
            		link.l1 = "La vie me l'a appris. Oם puis-je trouver M. Dan ?" ;
            		link.l1.go = "WStep_0";
            		link.l2 = "Bonsoir. Oם puis-je trouver M. Dan ?";
            		link.l2.go = "WStep_1";
                }

                if(Pchar.questTemp.CapBloodLine.stat == "WakerOffer")
                {
                	dialog.text = "J'ai entendu dire que Mme Steed vous prenait beaucoup de temps. Eh oui, la jeunesse et la belle mine, docteur Blood ! La jeunesse et la beauté ! דa donne un énorme avantage à un médecin, surtout quand il soigne des dames !";
            		link.l1 = "Je crois deviner votre idée. Faites-en part non pas à moi, mais au gouverneur Steed. Peut-être que cela l'amusera. Si c'est tout ce que vous avez à me dire, alors, avec votre permission..." ;
            		link.l1.go = "WStep_3";

                }
    		}

    		if (npchar.id == "Den")
    		{
            	dialog.text = "Bonsoir, docteur Blood. Puis-je vous demander ce que vous faisiez chez moi ?";
        		link.l1 = "Mme Steed a une crise de migraine, on m'a appelé d'urgence auprès d'elle. Je l'ai examinée et j'ai dמ venir chez vous à une heure aussi tardive pour obtenir le remède nécessaire. Ne vous trouvant pas chez vous, j'ai décidé d'attendre, mais j'étais sur le point de partir." ;
        		link.l1.go = "DStep_0";
    			if (GetCharacterItem(pchar, "migraine_potion") > 0)
    			{
            			link.l2 = "Mme Steed a une crise de migraine, on m'a appelé d'urgence auprès d'elle. Je l'ai examinée et j'ai dמ venir chez vous à une heure aussi tardive pour obtenir le remède nécessaire. Ne vous ayant pas trouvé, je me suis permis de prendre le remède sans autorisation : la situation est extrêmement grave. Je vous prie de m'excuser.";
            			link.l2.go = "DStep_1";
    			}
        		link.l3 = "Je venais juste vous dire que le docteur Wacker vous cherchait, monsieur Dan.";
        		link.l3.go = "DStep_2";
    		}



    		if (npchar.id == "Griffin")
    		{
                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape1" && !CheckAttribute(pchar, "LockBloodWeaponsOptions"))
                {
                	dialog.text = "Qu'est-ce que vous avez à entrer sans frapper, que le diable vous emporte... Oh, c'est vous, docteur Blood !";
            		link.l1 = "Bonjour, monsieur Griffin. Pardonnez cette intrusion sans façons, mais j'ai une affaire urgente à traiter avec vous.";
            		link.l1.go = "GRStep_0";
            		break;
                }

                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape")
                {

                    dialog.text = "Qui diable êtes-vous ?!";
            		link.l1 = "Je suis le docteur Blood, le médecin de Bridgetown." ;
            		link.l1.go = "GRStep_10";
            		break;

                }

                dialog.text = "Qu'est-ce que vous faites ici, que le diable vous déchire ?!";
                link.l1 = "Je suis le docteur Blood, je m'en vais." ;
                link.l1.go = "Exit";
    		}

    		if (npchar.id == "Hells")
    		{
                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape1_1")
                {
                	dialog.text = "Qu'est-ce que vous me voulez tous, bon sang ?! En garde !..";
            		link.l1 = "Calmez-vous, je suis Peter Blood, le médecin de Bridgetown. Je ne vous veux aucun mal.";
            		link.l1.go = "HStep_0";
            		link.l2 = "Puisque vous le demandez...";
            		link.l2.go = "fight1";
            		break;
                }

                if(Pchar.questTemp.CapBloodLine.stat == "needMoney" && !CheckAttribute(Pchar, "questTemp.CapBloodLine.fishplace"))
                {
                	dialog.text = "Oh, c'est bien que vous soyez là...";
            		link.l1 = "Que puis-je faire pour vous ?";
            		link.l1.go = "HStep_5";
            		break;
                }

                dialog.text = "Qu'est-ce que vous faites ici, que le diable vous déchire ?!";
                link.l1 = "Je suis le docteur Blood, je m'en vais." ;
                link.l1.go = "Exit";
    		}

    		if (npchar.id == "Quest_Smuggler")
    		{
                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape" && sti(Pchar.reputation) > 55  && !CheckAttribute(pchar, "LockBloodWeaponsOptions"))
                {
                	dialog.text = "J'ai entendu parler de vous, docteur Blood. Vous êtes devenu, dans une certaine mesure, une célébrité parmi les esclaves du coin qui pourrissent dans les plantations. Que puis-je faire pour vous ?";
            		link.l1 = "Avec votre permission, nous parlerons à voix basse. Voilà : il me faut une arme...";
            		link.l1.go = "QSStep_0";
            		break;
                }

                dialog.text = "Bonjour, docteur Blood. Si on apprend que vous m'avez parlé, on vous enfermera jusqu'à la fin de vos jours. Alors, passez plutכt votre chemin.";
                link.l1 = "On peut me fouetter à mort sans ça... Mais vous avez raison : je dois partir." ;
                link.l1.go = "Exit";
    		}

    		if (npchar.id == "Spain_spy" )
    		{
            	dialog.text = "Hé, vous ! Attendez...";
        		link.l1 = "Que puis-je faire pour vous ?";
        		link.l1.go = "SSStep_0";
    		}

    		 if(npchar.id == "Volverston")
    		 {
                if(Pchar.questTemp.CapBloodLine.statcrew == "find")
                {
                    dialog.text = "Ah, Peter, content de te voir !";
                    link.l1 = "Que dirais-tu de nous tenir compagnie, à moi et à quelques-uns de nos frères d'infortune, demain soir, en route pour la colonie hollandaise de Curaçao ?";
                    link.l1.go = "VLStep_0";
              		break;
                }
                dialog.text = "Ah, Peter, content de te voir !.";
                link.l1 = "Bonjour, Wolverstone. Désolé, mais je dois partir.";
                link.l1.go = "Exit";

    		 }

    		 if(npchar.id == "Hugtorp")
    		 {
                if(Pchar.questTemp.CapBloodLine.statcrew == "find")
                {
                    dialog.text = "Je suis déjà au courant, Peter. Jeremy m'a fait un bref résumé, mais hélas, je dois refuser.";
                    link.l1 = "Mais pourquoi ? Tu as des doutes ?";
                    link.l1.go = "HTStep_1";
              		break;
                }
                dialog.text = "Salutations, Peter. La main que tu m'as soignée est complètement guérie, merci.";
                link.l1 = "Je suis content que tu ailles mieux.";
                link.l1.go = "Exit";

    		 }

    		 if(npchar.id == "Dieke")
    		 {
                if(Pchar.questTemp.CapBloodLine.statcrew == "find")
                {
                    dialog.text = "Que puis-je faire pour toi, docteur ?";
                    link.l1 = "Tu peux, tu peux vraiment, Nicholas. Pitt t'a dit ce que nous préparons ?";
                    link.l1.go = "DKStep_0";
              		break;
                }
                dialog.text = "Que puis-je faire pour toi, docteur ?";
                link.l1 = "Non, rien, je passais simplement.";
                link.l1.go = "Exit";
    		 }

    		 if(npchar.id == "Ogl")
    		 {
                if(Pchar.questTemp.CapBloodLine.statcrew == "find")
                {
                    dialog.text = TimeGreeting() + ", docteur Blood.";
                    link.l1 = "Que dirais-tu d'une affaire, Ogle ? Il y a encore de la vigueur dans ce vieux loup de mer ?";
                    link.l1.go = "OGLStep_0";
              		break;
                }
                dialog.text = TimeGreeting() + ", docteur Blood.";
                link.l1 = "Bonjour.";
                link.l1.go = "Exit";
    		 }



		break;


		case "First Bishop":
            if(NPChar.quest.meeting == "0")
            {
            	dialog.text = "La femme du gouverneur a encore une crise. Va immédiatement à la résidence de Steed et fais ce que tu as à faire. Quand tu auras fini, reviens directement ici... Et Dieu te garde de t'approcher des patients espagnols ! Demain, je te trouverai quelque chose de plus important pour t'occuper. Il y a...";
                link.l1 = "...il y a Wacker et Bronson, que vous pouvez toujours recommander au gouverneur en invoquant mon emploi extraordinaire à la plantation. Des médecins comme les autres, mais tout de même instruits et travailleurs. Sinon, si le gouverneur Steed exige un rapport sur l'état des blessés, je devrai lui répondre, puis aller voir ces malheureux et les examiner.";
                link.l1.go = "BStep_0";
                npchar.quest.meeting = "1";
            }
            else
            {
           	    dialog.text = "Fiche le camp d'ici, vaurien, ou je te fais mettre aux fers !";
                link.l1 = "Comme vous voudrez.";
                link.l1.go = "Exit";
            }
		break;

		case "BStep_0":
        	dialog.text = "Ne m'interromps pas, chien !\nSoigne la noble famille Steed, ou la bienveillance d'un malade envers toi fera place à la froide indifférence d'un politicien.\nAlors on verra si tu préfères biner la terre à la plantation plutכt que de te promener librement en ville ! Souviens-toi de ta place, esclave.";
    		link.l1 = "Je suppose que vous prenez un grand risque en me retenant, alors que Mme Steed a besoin de soins urgents.";
    		link.l1.go = "Bishop_Away";
            LAi_LockFightMode(pchar, false);
            chrDisableReloadToLocation = false;
            LAi_LocationFightDisable(loadedLocation, false);
            Pchar.questTemp.CapBloodLine.stat = "CureMisStid";
            NextDiag.TempNode = "First Bishop";

            //сроки 4 часа
            PChar.quest.CapBloodLineTimer_1.win_condition.l1            = "Timer";
            PChar.quest.CapBloodLineTimer_1.win_condition.l1.date.hour  = 4;
            PChar.quest.CapBloodLineTimer_1.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
            PChar.quest.CapBloodLineTimer_1.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
            PChar.quest.CapBloodLineTimer_1.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 0);
            PChar.quest.CapBloodLineTimer_1.function = "CapBloodLine_q1_Late";
            AddQuestRecord("CapBloodLine_q1", "1");

		break;

		case "BStep_1":
        	dialog.text = "Si tu fourres ton nez dans mes affaires, je vais devoir faire quelque chose, joli cœur, pour que tu ne fasses pas l'imbécile et n'abuses pas de la liberté qu'on t'a accordée. N'oublie pas que tu es un rebelle condamné !";
            link.l1 = "On me le rappelle sans cesse.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "BStep_1";
		break;

		case "BStep_2":
        	dialog.text = "Tu traînes toute la journée ! א ce que je sache, le gouverneur et sa femme vont bien. Ne faudrait-il pas t'interdire l'accès à la ville pour un temps ?";
            link.l1 = "Vous allez vendre Nicholas Dyke ?";
            link.l1.go = "BStep_3";
		break;

		case "BStep_3":
        	dialog.text = "... et puis, il y a déjà des rumeurs sur toi... quoi ? En quoi ces saletés te regardent-elles, chien ?";
            link.l1 = "Le fait est qu'il a... Hum, il présente les premiers signes de la lèpre...";
            link.l1.go = "BStep_4";
		break;


		case "BStep_4":
        	dialog.text = "Qu'est-ce que tu racontes ? Ne t'avise pas de te mêler de mes affaires, sinon je t'envoie biner, après t'avoir fouetté à moitié à mort !..";
            link.l1 = "La responsabilité de la vente retombera sur...";
            link.l1.go = "BStep_5";
		break;

		case "BStep_5":
        	dialog.text = "Silence ! J'ai une dette envers M. Westen, et cette affaire se fera ! Hors de ma vue !";
            link.l1 = "D'accord.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "BStep_1";
            sld = characterFromID("Quest_Habitue");
            sld.Dialog.CurrentNode = "QHStep_0";
            AddQuestRecord("DiekeQuest", "2");

		break;

		case "Bishop_Away":

            LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "houseSp1", "Plantation_Sp1", "goto", "goto1", "BishopOnHouse", -1);
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit()
		break;

		// -->Эндрю Бейнс

		case "EBStep_0":

            dialog.text = "J'apporterai tout ce que vous demanderez. Je vous en prie, dépêchez-vous, mon maître va vraiment mal !";
        	link.l1 = "Je ferai de mon mieux.";
            link.l1.go = "Exit_RunAway";
            DeleteAttribute(npchar, "talker");
            Pchar.questTemp.CapBloodLine.sLocator = "Reload5";
            Pchar.questTemp.CapBloodLine.iTime = -1;

		break;

		case "EBStep_1":

            dialog.text = "Docteur, j'ai préparé tout ce que vous avez demandé.";
        	link.l1 = "Merci, posez ça là.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "EBStep_2";
            AddDialogExitQuestFunction("CureLordMovie");

		break;

		case "EBStep_2":

            dialog.text = "Qu'a lord Gildoy ? Il survivra ?";
        	link.l1 = "Le pire est passé. J'ai soigné les blessures, je lui ai donné un remède ; il va se rétablir, mais il lui faut un repos complet...";
            link.l1.go = "Exit";
            NextDiag.TempNode = "EBStep_3";
            AddDialogExitQuestFunction("DragunInvansion");

		break;

		case "EBStep_3":

            dialog.text = "Je pense que tu devrais suivre le conseil de Jeremy Pitt et te procurer une arme.";
        	link.l1 = "D'accord, c'est ce que je vais faire.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "EBStep_3";

		break;

		//--> капитан Гобард

		case "CGStep_1":
        	dialog.text = "Pas besoin de mots ! Inutile de demander oם ce maudit rebelle a été blessé... Attrapez-le, les gars !";
    		link.l1 = "Au nom de l'humanité, monsieur ! Nous vivons en Angleterre, pas à Tanger. Cet homme est grièvement blessé, on ne peut pas le déplacer sans mettre sa vie en danger.";
    		link.l1.go = "CGStep_2";

		break;

		case "CGStep_2":
        	dialog.text = "Oh, alors je devrais encore me soucier de la santé des rebelles ! Bon sang ! Vous croyez qu'on va le soigner ? Il y a des potences tout le long de la route de Weston à Bridgewater, et il ira très bien sur n'importe laquelle. Le colonel Kirke va apprendre à ces imbéciles de protestants une chose dont leurs enfants, leurs petits-enfants et leurs arrière-petits-enfants se souviendront !";
    		link.l1 = "Très bien, mais si vous faites ça, j'ai peur que vous ne soyez pendu demain. Il n'appartient pas à la catégorie des gens qu'on peut pendre sans poser de questions. Il a le droit d'exiger un procès, un procès devant ses pairs.";
    		link.l1.go = "CGStep_3";

		break;

		case "CGStep_3":
        	dialog.text = "Un procès devant ses pairs ?";
    		link.l1 = "Bien sמr. N'importe qui, à moins d'être un idiot ou un sauvage, aurait demandé son nom avant d'envoyer un homme à la potence. Cet homme est lord Gildoy.";
    		link.l1.go = "CGStep_4";

		break;

		case "CGStep_4":
        	dialog.text = "Cet homme est un rebelle, et on va l'emmener à Bridgewater, en prison.";
    		link.l1 = "Il ne supportera pas ce voyage. On ne peut pas le déplacer maintenant.";
    		link.l1.go = "CGStep_5";

		break;

		case "CGStep_5":
        	dialog.text = "Tant pis pour lui. Mon travail, c'est d'arrêter les rebelles ! Et qui est ce type qui se cachait dans la cheminée ? Encore un grand seigneur ? Celui-là, je vais le pendre de mes propres mains.";
    		link.l1 = "Vous avez deviné, capitaine. C'est le vicomte Pitt, le cousin de sir Thomas Vernon, qui a épousé la belle Molly Kirke, la sœur de votre colonel.";
    		link.l1.go = "CGStep_6";

		break;

		case "CGStep_6":
        	dialog.text = "Vous mentez, n'est-ce pas ? Je le jure devant Dieu, il se moque de moi !";
    		link.l1 = "Si vous en êtes sמr, alors pendez-le, et vous verrez ce qu'on vous fera.";
    		link.l1.go = "CGStep_7";
		break;

		case "CGStep_7":
        	dialog.text = "Diable. Qui êtes-vous, bon sang ? Et comment vous êtes-vous retrouvé ici ?";
    		link.l1 = "Je m'appelle Peter Blood, je suis médecin, et on m'a amené ici pour soigner le blessé.";
    		link.l1.go = "CGStep_8";
		break;

		case "CGStep_8":
        	dialog.text = "Et qui vous a invité ? Les rebelles ? Prenez-le ! Ligotez ceux-là aussi. On va vous apprendre à abriter des rebelles !";
    		link.l1 = "Ah non, pas question. Je ne peux pas laisser faire ça !";
    		link.l1.go = "GFight";
    		NextDiag.TempNode = "CGStep_9";
			EndQuestMovie();
		break;

        case "CGStep_9":
			dialog.text = LinkRandPhrase("Le voilà, tenez-le !", "Attrapez-le, les gars !", "Halte-là !");
			link.l1 = LinkRandPhrase("Diable !!", "Tu parles !", "Oh, bon sang !");
			link.l1.go = "Exit";
			AddDialogExitQuestFunction("CapGobartAttack");
            NextDiag.TempNode = "CGStep_9";
		break;


		// -->Стражник на входе

		case "First Guard":
        	dialog.text = "Oם allez-vous ?";
    		link.l1 = "Je m'appelle Peter Blood, je suis ici sur ordre du colonel Bishop : on m'a ordonné de me présenter pour examiner et soigner l'épouse du gouverneur.";
    		link.l1.go = "GStep_0";

		break;

		case "GStep_0":

            dialog.text = "Oui, je me souviens de vous. Vous avez soigné mon frère et les autres du Pride of Devon, ainsi que toute cette racaille espagnole qui a miraculeusement survécu. Bronson est mon ami... et vous le ruinez, tout comme Wacker, en faisant tout, partout. Des petits malins comme vous, il y en a peu parmi les esclaves, et ils ne vivent pas longtemps.";
        	link.l1 = "Je suis désolé, mais l'épouse du gouverneur est souffrante en ce moment, et en me retenant, vous risquez de vous retrouver dans la même cage que la « racaille espagnole ».";
            link.l1.go = "Exit";
            LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);//отпираем резеденцию
            //LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);
            LocatorReloadEnterDisable("BridgeTown_town", "reloadR1", false);
            //солдата на место
            LAi_SetLoginTime(npchar, 6.0, 23.0);
            npchar.protector = false;
            npchar.protector.CheckAlways = 0;
            npchar.dialog.filename = "Quest\CapBloodLine\questNPC.c";

		break;

		case "GStep_1":

            dialog.text = "Oh, docteur Blood ! Je ne sais pas si le gouverneur Steed vous a fait appeler cette fois. De quoi avez-vous besoin ?";
            if (GetCharacterItem(pchar, "migraine_potion") > 0)
            {
       	        link.l1 = "J'ai entre les mains un remède pour prévenir les migraines. Ma mission est de le remettre à Mme Steed et de l'examiner. Vous pensez que c'est une bonne idée de me retenir à un tel moment ?";
                link.l1.go = "Exit";
                LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);//отпираем резеденцию
                //LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);
                LocatorReloadEnterDisable("BridgeTown_town", "reloadR1", false);
                //солдата на место
                npchar.protector = false;
                npchar.protector.CheckAlways = 0;
                npchar.dialog.filename = "Quest\CapBloodLine\questNPC.c";

            }
            else
            {
           	    link.l1 = "Puisque je suis ici, il est logique d'en conclure que j'ai besoin de voir le gouverneur.";
                link.l1.go = "GStep_2";
            }

		break;

 		case "GStep_2":

            dialog.text = "C'est ainsi. Mais puisque je vous ai arrêté, il est logique d'en conclure que vous ne pourrez pas franchir cette porte tant que je n'aurai pas eu connaissance de l'ordre correspondant donné par le gouverneur Steed.";
        	link.l1 = "Dans ce cas, je n'ose pas vous distraire plus longtemps.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "GStep_3";
            AddQuestRecord("WeaponsForEscape", "12");
		break;

		case "GStep_3":

            dialog.text = "Eh bien, quoi encore ?";
            if (GetCharacterItem(pchar, "migraine_potion") > 0)
            {
       	        link.l1 = "J'ai entre les mains un remède pour prévenir les migraines. Ma mission est de le remettre à Mme Steed et de l'examiner. Vous pensez que c'est une bonne idée de me retenir à un tel moment ?";
                link.l1.go = "Exit";
                LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);//отпираем резеденцию
                //LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", false);
                LocatorReloadEnterDisable("BridgeTown_town", "reloadR1", false);
                //солдата на место
                npchar.protector = false;
                npchar.protector.CheckAlways = 0;
                npchar.dialog.filename = "Quest\CapBloodLine\questNPC.c";
                NextDiag.TempNode = "First time";

            }
            else
            {
            	link.l1 = "Je suis venu voir si vous étiez encore en vie.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GStep_3";
            }

		break;

        // --> Стид


 		case "SStep_0":

            ChangeCharacterReputation(PChar, 5);
            dialog.text = "Quoi qu'il en soit, le plus important pour l'instant, c'est ma femme. Elle a de nouveau une crise de migraine, elle est surexcitée et refuse toutes les tentatives pour la mettre au lit !";
        	link.l1 = "Puis-je la voir ?";
            link.l1.go = "SStep_2";
		break;

 		case "SStep_1":

            dialog.text = "Quoi qu'il en soit, le plus important pour l'instant, c'est ma femme. Elle a de nouveau une crise de migraine, elle est surexcitée et refuse toutes les tentatives pour la mettre au lit !";
        	link.l1 = "Puis-je la voir ?";
            link.l1.go = "SStep_2";
		break;

 		case "SStep_2":

            dialog.text = "Oui, oui, bien sמr : elle est dans la chambre à l'étage. Il y a une porte sur votre droite, puis l'escalier. Entrez donc.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "SStep_3";

			sld = GetCharacter(NPC_GenerateCharacter("MisStid", "AnnaDeLeiva", "woman", "towngirl2", 10, ENGLAND, 3, false));
            sld.dialog.filename = "Quest\CapBloodLine\Bishop.c";
			sld.name = "Madame";
			sld.lastname = "Steed";
			sld.greeting = "Gr_Dama";
			sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(sld, sTemp);
			LAi_SetStayTypeNoGroup(sld);
			ChangeCharacterAddressGroup(sld, "CommonBedroom", "goto", "goto5");
			AddQuestRecord("CapBloodLine_q1", "2");
		break;


		case "SStep_3":

            sld = &characters[GetCharacterIndex("MisStid")];
            if (sld.quest.meeting != "1")
            {
                dialog.text = "Docteur Blood, allez voir ma femme au plus vite.";
                link.l1 = "Je suis en route.";
                link.l1.go = "Exit";
            }
            else
            {
                dialog.text = "Comment va-t-elle, docteur ? Vous...";
                link.l1 = "Tout ira bien, gouverneur Steed, mais je dois aller immédiatement chez l'apothicaire chercher les remèdes nécessaires. Je tenais simplement à vous prévenir.";
                link.l1.go = "SStep_4";

                link.l2 = "Tout ira bien, gouverneur Steed, si je trouve M. Dan chez lui et que je le réveille. Il faut des remèdes de toute urgence, et je vous demande de me donner de quoi les acheter.";
                link.l2.go = "SStep_5";
            }
		break;

		case "SStep_4":

            dialog.text = "Je vous en prie, dépêchez-vous !";
            link.l1 = "Je suis en route.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "SStep_4";

		break;

		case "SStep_5":

            dialog.text = "Oh, bien sמr, bien sמr... Combien vous faut-il ?";
            link.l1 = "500 piastres.";
            link.l1.go = "SStep_6";
            link.l2 = "1000 piastres.";
            link.l2.go = "SStep_7";
            link.l3 = "2500 piastres, monsieur. C'est un remède très cher et très rare.";
            link.l3.go = "SStep_8";

		break;

		case "SStep_6":

            AddMoneyToCharacter(pchar, 500);
            dialog.text = "Tenez, voici votre argent.";
            link.l1 = "Je dois me dépêcher.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "SStep_4";
            AddQuestRecord("CapBloodLine_q1", "4");
            AddQuestUserData("CapBloodLine_q1", "iMoney", 500);

		break;

		case "SStep_7":

            AddMoneyToCharacter(pchar, 1000);
            dialog.text = "Tenez, prenez ; j'espère que c'est bien pour M. Dan.";
            link.l1 = "Je dois me dépêcher.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "SStep_4";
            AddQuestRecord("CapBloodLine_q1", "4");
            AddQuestUserData("CapBloodLine_q1", "iMoney", 1000);

		break;

		case "SStep_8":

            AddMoneyToCharacter(pchar, 2500);
            dialog.text = "C'est beaucoup d'argent, docteur. Je vous le donne, mais je vous demande de m'en rendre compte : je vérifierai tout.";
            link.l1 = "Je dois me dépêcher.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "SStep_4";
            AddQuestRecord("CapBloodLine_q1", "5");


		break;

		case "SStep_9":

            dialog.text = "C'est bien dit ; bien sמr, je vous en donne l'occasion. Pensez-vous que nous devions craindre une nouvelle crise ?";
            link.l1 = "Je suis venu justement pour l'empêcher, monsieur. Avec votre permission...";
            link.l1.go = "Exit";
            NextDiag.TempNode = "First time";
            LocatorReloadEnterDisable("Bridgetown_Townhall", "reload3", false);
            LocatorReloadEnterDisable("BridgeTown_town", "reloadR1", false);
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape3_1";

		break;

        //--> Миссис Стид

        case "MSStep_0":

            dialog.text = "Pouvez-vous faire quelque chose, docteur ?";
        	link.l1 = "On dirait qu'on ne pourra pas se passer de remèdes, mais l'apothicairerie est fermée depuis longtemps. Je vais devoir aller chez M. Dan chercher tout ce qu'il me faut. Buvez un peu d'eau tiède et attendez-moi, je reviens dès que possible !";
            link.l1.go = "Exit";
            NextDiag.TempNode = "MSStep_1";

            sld = GetCharacter(NPC_GenerateCharacter("Waker", "usurer_5", "man", "man", 7, ENGLAND, 3, false));
            sld.dialog.filename = "Quest\CapBloodLine\Bishop.c";
            sld.name = "Le docteur";
            sld.lastname = "Wacker";
            sld.greeting 	=  "Gr_medic";
            sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(sld, sTemp);
			ChangeCharacterAddressGroup(sld, "CommonPirateHouse", "goto", "goto6");
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorDialog(sld, pchar, "", 2.0, 0);

            pchar.quest.CureMisStid.win_condition.l1 = "item";
			pchar.quest.CureMisStid.win_condition.l1.item= "migraine_potion";
			pchar.quest.CureMisStid.function = "CapBloodLine_q1_End";

			sld = ItemsFromID("migraine_potion");
			sld.shown = true;
			sld.startLocation = "CommonPirateHouse";
			sld.startLocator = "item1";

			AddQuestRecord("CapBloodLine_q1", "3");


		break;

        case "MSStep_1":

            dialog.text = "Vous avez apporté le remède, docteur ?";
            if(Pchar.questTemp.CapBloodLine.stat == "CureMisStid_Complite")
            {
                link.l1 = "Oui, il vous remettra vite sur pied.";
                link.l1.go = "MSStep_2";
                TakeItemFromCharacter(Pchar, "migraine_potion");

            }
            else
            {
                link.l1 = "Pas encore, j'allais justement le chercher.";
                link.l1.go = "Exit";
            }

		break;

        case "MSStep_2":

        NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		//Вывести экран в темноту, выполнить квест questFadeOut, вернуть всё обратно, выполнить квест questFadeIn
        //LAi_Fade("", "CapBloodLine_q1_Complited");
        CapBloodLine_q1_Complited("");

		break;

        case "MSStep_3":

            dialog.text = "Bonjour, docteur Blood. Je me sens beaucoup mieux, et on dirait que je suis vraiment en voie de guérison : tout cela grâce à vous.";
        	link.l1 = "Merci, madame Steed. Je suis ici pour...";
            link.l1.go = "MSStep_4";
            DeleteAttribute(npchar, "talker");

		break;

        case "MSStep_4":

            dialog.text = "Je vois que vous ne quittez pas cette petite bague des yeux... Elle est peut-être à vous ?";
        	link.l1 = "Mm... à moi ?";
            link.l1.go = "MSStep_5";
           	link.l1 = "Non, hélas, elle ne m'appartient pas.";
            link.l1.go = "MSStep_5";

		break;

        case "MSStep_5":

            dialog.text = "Le fait est qu'elle n'est pas à moi non plus. Hier encore, je n'avais pas de bague de ce genre, mais ce matin, je l'ai trouvée là oם elle est maintenant. Oh, si mon mari n'avait pas été sמr d'avoir été avec moi au moment oם la bague est apparue, et que personne n'ait pu entrer ici, il aurait...";
        	link.l1 = "Très intéressant.";
            link.l1.go = "MSStep_6";

		break;

        case "MSStep_6":

            dialog.text = "La bague est simple, sans fioritures. Ce n'est pas mon style, et... emportez-la, docteur Blood. א qui qu'elle soit, je n'en veux pas.";
        	link.l1 = "Que dites-vous là, madame Steed ! Je ne peux pas l'accepter... Mais je peux essayer de découvrir pour vous à qui elle appartient et comment elle est arrivée ici.";
            link.l1.go = "MSStep_7";

		break;

        case "MSStep_7":

            dialog.text = "Soit. Et maintenant, je dois vous demander de me laisser.";
        	link.l1 = "Tenez, je vous ai apporté encore un peu de cet extrait miraculeux, ce qui était le but premier de ma visite. Au revoir.";
            TakeItemFromCharacter(Pchar, "migraine_potion");
            AddQuestRecord("WeaponsForEscape", "15");
            link.l1.go = "Exit";
            NextDiag.TempNode = "MSStep_8";


		break;

        case "MSStep_8":

            dialog.text = "Au revoir, docteur Blood.";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "MSStep_8";
		break;




        //--> Нэтталл

        case "NStep_0":

            dialog.text = "Euh... Si tu découvres... si tu découvres le moyen, alors... Ne me laisse pas, je t'aiderai. Formidable... Vraiment.";
        	link.l1 = "Rentre chez toi, vieux loup de mer. Tu as besoin de dormir.";
            link.l1.go = "Nettl_Away";
            NextDiag.TempNode = "NStep_1";
            Pchar.questTemp.CapBloodLine.TalkWithNettl = true;
		break;

        case "NStep_1":

            dialog.text = "א ta santé, docteur ! Ehhh !";
            if( Pchar.questTemp.CapBloodLine.stat == "needMoney")
            {
                link.l1 = "J'ai à te parler.";
                link.l1.go = "NStep_2";
            }
            else
            {
                link.l1 = "Un conseil : rentre chez toi et cuve ton rhum.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "NStep_1";
            }
		break;

        case "NStep_2":

            dialog.text = "Je suis au courant, Jeremy Pitt m'en a déjà rebattu les oreilles...";
            if(makeint(pchar.money) >= 25000)
            {
                link.l1 = "Voici vingt-cinq mille pour toi. Occupe-toi de l'achat et de tout le reste immédiatement, mon ami. Ne me laisse pas tomber.";
                link.l1.go = "NStep_3";
            }
            else
            {
                link.l1 = "Tiens-toi prêt : dès que j'aurai réuni la somme nécessaire, tu t'occuperas d'acheter un sloop.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "NStep_5";
            }
		break;

        case "NStep_3":

            AddMoneyToCharacter(pchar, -25000);
            dialog.text = "Eh bien, je n'ai pas vraiment le choix... On dirait bien.";
        	link.l1 = "Dépêche-toi.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "NStep_4";
            NPChar.lifeDay = 0;
       		CloseQuestHeader("CapBloodLine_q2");
            CapBloodLine_q3_Complited();

		break;

        case "NStep_4":

            dialog.text = "Je finis mon rhum et je vais au chantier naval.";
        	link.l1 = "Dépêche-toi.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "NStep_4";
		break;

        case "NStep_5":

            dialog.text = "Tu as apporté l'argent ?";
            if(makeint(pchar.money) >= 25000)
            {
                link.l1 = "Voici vingt-cinq mille pour toi. Occupe-toi de l'achat et de tout le reste immédiatement, mon ami. Ne me laisse pas tomber.";
                link.l1.go = "NStep_3";
            }
            else
            {
               	link.l1 = "Pas encore.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "NStep_5";
            }
		break;

		case "Nettl_Away":

            LAi_SetActorTypeNoGroup(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload4_back", "none", "", "", "NettlOnTavern", -1);
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
		break;

        case "NStep_6":

            dialog.text = "Ir... Grand Dieu ! Et comment faire ça ?";
        	link.l1 = "Bon, en gros, je m'occupe de tout. Tu n'as qu'à aller au chantier naval et acheter un sloop, je t'apporterai l'argent. Va à la taverne, sinon on va nous remarquer, ici.";
            link.l1.go = "Nettl_Away";
            NextDiag.TempNode = "NStep_5";
            Pchar.questTemp.CapBloodLine.TalkWithNettl = true;
		break;

        //--> Вакер

        case "WStep_0":

            AddCharacterExpToSkill(pchar, "Sneak", 50);
            dialog.text = "J'aimerais bien savoir moi-même oם il est. Je l'attends ici depuis une heure, mais il n'est toujours pas là. Le pauvre homme aurait-il perdu la boule ? En attendant, j'ai à vous parler...";
        	link.l1 = "Je suis pressé, docteur Wacker, je dois trouver M. Dan au plus vite. La conversation devra attendre.";
            link.l1.go = "WStep_2";

		break;

        case "WStep_1":

            dialog.text = "J'aimerais bien savoir moi-même oם il est. Je l'attends ici depuis une heure, mais il n'est toujours pas là. Le pauvre bougre serait-il parti en beuverie ? En attendant, j'ai à vous parler...";
        	link.l1 = "Je suis pressé, docteur Wacker, je dois trouver M. Dan au plus vite. La conversation devra attendre.";
            link.l1.go = "WStep_2";

		break;

        case "WStep_2":

            dialog.text = "Bon, je ne suis moi-même pas d'humeur à discuter de tout ce qu'il y a à discuter, ici et maintenant. Je crois que je vais partir ; si vous voulez, attendez Dan. Nous parlerons demain. Dès que vous aurez une minute de libre, venez à la taverne. Je compte vraiment sur vous.";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit_Away";
            Pchar.questTemp.CapBloodLine.sLocator = "reload1";
            Pchar.questTemp.CapBloodLine.iTime = 5;

            sld = GetCharacter(NPC_GenerateCharacter("Den", "usurer_1", "man", "man", 7, ENGLAND, 3, false));
            sld.dialog.filename = "Quest\CapBloodLine\Bishop.c";
            sld.name = "Monsieur";
            sld.lastname = "Dan";
            sld.greeting 	=  "Gr_medic";
            sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(sld, sTemp);
			ChangeCharacterAddressGroup(sld, "BridgeTown_town", "goto", "goto3");
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorDialog(sld, pchar, "", 2.0, 0);
            AddQuestRecord("CapBloodLine_q2", "1");

		break;
		//Предложение Вакера - вторая встреча
        case "WStep_3":

            dialog.text = "Ne vous emportez pas, mon ami. Vous avez mal compris, je n'avais pas du tout de telles pensées. Je veux vous aider !";
        	link.l1 = "Quelle perspicacité !";
            link.l1.go = "WStep_4";

		break;

        case "WStep_4":

            dialog.text = "Je ne suis pas un imbécile, cher collègue. Je lis dans un homme comme dans un livre, et je peux même dire à quoi il pense.";
        	link.l1 = "Vous m'en convaincrez si vous me dites à quoi je pense.";
            link.l1.go = "WStep_5";

		break;

        case "WStep_5":

            dialog.text = "Je vous ai observé plus d'une fois, quand vous contempliez la mer avec mélancolie. Et vous croyez que je ne connais pas vos pensées ? Si vous parveniez à vous échapper de cet enfer, vous pourriez, en homme libre, vous consacrer entièrement, avec plaisir et profit, à votre profession, dont vous êtes un ornement. Le monde est vaste, et en dehors de l'Angleterre, il y a bien d'autres pays oם un homme comme vous sera toujours chaleureusement accueilli. En plus des colonies anglaises, il y en a d'autres. La colonie hollandaise de Curaçao n'est pas loin d'ici. א cette époque de l'année, on peut tout à fait y aller même en petite embarcation. Curaçao peut devenir un pont vers un vaste monde. Il s'ouvrira à vous dès que vous serez libéré de vos chaînes. Qu'en dites-vous ?";
        	link.l1 = "Je n'ai pas d'argent, et il en faudra beaucoup.";
            link.l1.go = "WStep_6";

		break;

        case "WStep_6":

            dialog.text = "Ne vous ai-je pas dit que je voulais être votre ami ?";
        	link.l1 = "Pourquoi ?";
            link.l1.go = "WStep_7";
           	link.l2 = "C'est très noble de votre part, collègue. C'est exactement ce que je ferais si j'avais une telle occasion.";
            link.l2.go = "WStep_8";

		break;

        case "WStep_7":

            dialog.text = "Vous ne pouvez pas imaginer à quel point mon cœur saigne à la vue d'un collègue qui languit en esclavage, privé de la possibilité de mettre en pratique ses merveilleux talents ! Pourquoi devriez-vous languir dans des chaînes, même invisibles, alors que vous pourriez partir vers l'horizon et rendre ce monde au moins un peu meilleur... Et nous laisser, à nous, notre travail à Bridgetown... N'est-ce pas ?";
        	link.l1 = "En plus du courage, il faut de l'argent pour s'évader. Un sloop coמtera sans doute vingt mille.";
            link.l1.go = "WStep_9";

		break;

        case "WStep_8":

            dialog.text = "Alors vous acceptez ?";
        	link.l1 = "En plus du courage, il faut de l'argent pour s'évader. Un sloop coמtera sans doute vingt mille.";
            link.l1.go = "WStep_9";

		break;

        case "WStep_9":

            dialog.text = "Vous aurez l'argent ! Ce sera un prêt que vous nous rendrez... que vous me rendrez quand vous pourrez.";
        	link.l1 = "Je dois me préparer, tout réfléchir et me concerter avec les bonnes personnes. Nous poursuivrons cette conversation demain. Vous m'avez ouvert les portes de l'espoir, collègue !";
            link.l1.go = "Exit";
            n = FindLocation("Bridgetown_tavern");
            locations[n].reload.l2.disable = true;
            Pchar.questTemp.CapBloodLine.stat = "WakerOfferComplited";
            AddQuestRecord("CapBloodLine_q2", "4");
            NextDiag.TempNode = "WStep_10";

		break;

        case "WStep_10":

            dialog.text = "א demain, collègue.";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "WStep_10";

		break;

		//Предложение Вакера - заключение

        case "WStep_11":

            dialog.text = "Bonjour, docteur Blood. Je vous attendais.";
        	link.l1 = "Bonjour, docteur Wacker. Eh bien, j'ai rassemblé les hommes et tout ce qu'il me faut. Je n'attends plus que l'argent promis.";
			npchar.LifeDay = 0;
            link.l1.go = "WStep_12";

		break;

        case "WStep_12":

            dialog.text = "Le fait est que je n'ai que 18 000 piastres sous la main, et il vous en faudra environ 25 000. Mais je suis sמr que vous arriverez à vous procurer le reste.";
        	link.l1 = "Ce sera difficile, mais je n'ai pas le choix. Et le sloop ? Aucun esclave ne pourra simplement se présenter au chantier naval et s'acheter un sloop, comme si de rien n'était.";
            link.l1.go = "WStep_13";
            AddMoneyToCharacter(pchar, 18000);

		break;

        case "WStep_13":

            dialog.text = "Hum, vous avez raison, comme toujours, docteur. Je n'y avais pas pensé...";
            if(Pchar.questTemp.CapBloodLine.TalkWithNettl == false)
            {
            	link.l1 = "Vous connaissez quelqu'un qui pourrait aider ?";
                link.l1.go = "WStep_14";
            }
            else
            {
            	link.l1 = "Il y a Nuttall, le charpentier. Je l'ai vu une fois en ville.";
                link.l1.go = "WStep_15";
            }

		break;

        case "WStep_14":

            dialog.text = "Il n'y a pas que des esclaves sur l'île, il y a aussi des exilés, des gens bannis pour dettes. Ils seront heureux de déployer leurs ailes. Je pense que n'importe lequel d'entre eux serait ravi de saisir l'occasion de partir.";
        	link.l1 = "Merci, collègue !";
            link.l1.go = "Exit";
            NextDiag.TempNode = "WStep_16";
            n = FindLocation("Bridgetown_tavern");
            locations[n].reload.l2.disable = true;
            Pchar.questTemp.CapBloodLine.stat = "needMoney";
            AddQuestRecord("CapBloodLine_q2", "7");

		break;

        case "WStep_15":

            dialog.text = "Nuttall... oui, le charpentier de marine peut vous aider. Il est peu probable qu'il ait la moindre raison de vous refuser. Allez, en route, docteur Blood. Et bonne chance !";
        	link.l1 = "Merci, collègue !";
            link.l1.go = "Exit";
            NextDiag.TempNode = "WStep_16";
            n = FindLocation("Bridgetown_tavern");
            locations[n].reload.l2.disable = true;
            Pchar.questTemp.CapBloodLine.stat = "needMoney";
            AddQuestRecord("CapBloodLine_q2", "7");

		break;

        case "WStep_16":

            dialog.text = "Bonne chance à vous !";
        	link.l1 = "Merci.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "WStep_16";

		break;

        //--> Мистер Дэн

        case "DStep_0":

            dialog.text = "Quel cauchemar ! Tenez, j'ai une bouteille sur moi, prenez-la. Ce n'est pas d'hier que je souffre, alors j'en garde toujours sur moi. Mais ne vous en faites pas, il m'en reste. Prenez-la gratuitement, docteur : c'est mon devoir de citoyen !";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit_Away";
            GiveItem2Character(Pchar, "migraine_potion");
            Pchar.questTemp.CapBloodLine.sLocator = "houseSp1";
            Pchar.questTemp.CapBloodLine.iTime = -1;

		break;

        case "DStep_1":

            dialog.text = "Que dites-vous là ! La santé de Mme Steed est en jeu : vous avez bien fait ! Dépêchez-vous !";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit_Away";
            ChangeCharacterReputation(PChar, 5);
            Pchar.questTemp.CapBloodLine.sLocator = "houseSp1";
            Pchar.questTemp.CapBloodLine.iTime = -1;

		break;

        case "DStep_2":

            dialog.text = "Hum... Je vois.";
        	link.l1 = "Au revoir.";
            link.l1.go = "Exit_Away";
            Pchar.questTemp.CapBloodLine.sLocator = "houseSp1";
            Pchar.questTemp.CapBloodLine.iTime = -1;

		break;

        case "DStep_3":

            dialog.text = "Bonjour, docteur Blood. Que puis-je faire pour vous ?";
        	link.l1 = "Bonjour, monsieur Dan. Je viens sur ordre de Son Excellence le gouverneur Steed. J'ai besoin de toute urgence de votre merveilleux extrait pour prévenir les migraines.";
            link.l1.go = "DStep_4";

		break;

        case "DStep_4":

            dialog.text = "Oh, bien sמr, tenez : il ne m'en reste plus beaucoup. Mes respects au gouverneur.";
        	link.l1 = "Merci. Permettez-moi de prendre congé.";
            link.l1.go = "Exit";
            GiveItem2Character(Pchar, "migraine_potion");
            NextDiag.TempNode = "DStep_5";
            AddQuestRecord("WeaponsForEscape", "13");

		break;

        case "DStep_5":

            dialog.text = "Vous avez besoin de quelque chose ?";
        	link.l1 = "Non, merci.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "DStep_5";

		break;

		//--> Джереми Питт

		 case "PStep_0":

            dialog.text = "Quoi ? De quoi tu parles ?";
        	link.l1 = "Je parle de la possibilité d'acheter demain matin un sloop au chantier naval, de rassembler des hommes de la plantation et de la ville, uniquement ceux à qui l'on peut se fier, bien sמr, et de partir vers l'horizon, au sud-ouest, vers la colonie hollandaise de Curaçao.";
            link.l1.go = "PStep_1";

		break;

        case "PStep_1":

            dialog.text = "Tu délires, docteur ? Nous n'avons ni argent, ni influence parmi les esclaves, ni contacts en ville, et nous ne pouvons rien avoir de tout ça.";
        	link.l1 = "וcoute-moi, Jeremy Pitt. Tu es le seul navigateur parmi nous. Je ne peux pas arriver au bon endroit sans toi, même si je rassemble les hommes et que nous prenons la mer sans encombre sur le sloop juste après minuit demain. J'ai besoin de toi maintenant, tout comme tu as eu besoin de moi au manoir d'Oglethorpe...";
        	link.l1.go = "PStep_2";  //(+ небольшой процент авторитета)
        	link.l2 = "Tu veux sortir d'ici, oui ou non ?";
        	link.l2.go = "PStep_3";

		break;

        case "PStep_2":

            dialog.text = "D'accord, j'ai compris, j'ai compris. Je ferai tout ce qui est en mon pouvoir pour aider...";
        	link.l1 = "N'oublie pas que si tu te trahis, tu ruineras tout : après tout, tu es le seul navigateur parmi nous, et l'évasion est impossible sans toi.";
            link.l1.go = "Exit";
            AddCharacterExpToSkill(pchar, "LeaderShip", 50);
            NextDiag.TempNode = "PStep_4";
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape";
            Pchar.questTemp.CapBloodLine.statcrew = "find";
            Pchar.questTemp.CapBloodLine.Officer = 0;
            AddQuestRecord("CapBloodLine_q2", "5");
            AddQuestRecord("WeaponsForEscape", "1");

		break;

        case "PStep_3":

            dialog.text = "D'accord, j'ai compris, j'ai compris. Je ferai tout ce qui est en mon pouvoir pour aider...";
        	link.l1 = "N'oublie pas que si tu te trahis, tu ruineras tout : après tout, tu es le seul navigateur parmi nous, et l'évasion est impossible sans toi.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "PStep_4";
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape";
            Pchar.questTemp.CapBloodLine.statcrew = "find";
            AddQuestRecord("CapBloodLine_q2", "5");
            AddQuestRecord("WeaponsForEscape", "1");
		break;

        case "PStep_4":

            if(CheckAttribute(Pchar, "questTemp.CapBloodLine.Officer") && Pchar.questTemp.CapBloodLine.Officer == 4 && Pchar.questTemp.CapBloodLine.stat == "ReadyToEscape")
            {
                dialog.text = "Quand partons-nous, Peter ?";
                link.l1 = "J'ai une arme et je me suis mis d'accord avec les gars. Il ne reste plus qu'à acheter un sloop. Demain soir, nous serons loin d'ici !";
                link.l1.go = "PStep_9";
                while (GetCharacterItem(pchar, "Weapon_for_escape") > 0)//homo fix 06/02/08 отбираем все квестовое оружие
                {
                    TakeItemFromCharacter(Pchar, "Weapon_for_escape");
                }
                //link.l10 = "Continue the game.";
                //link.l10.go = "finish";
                NextDiag.TempNode = "PStep_10";
                break;

            }
            dialog.text = "Recrute des hommes et prépare tout ce qu'il faut. Je t'attendrai ici.";
        	link.l1 = "א plus tard.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "PStep_4";
		break;

        case "PStep_5":

            dialog.text = "Peter, les dragons du régiment de Tanger arrivent au galop, ils recherchent les participants du soulèvement...";
        	link.l1 = "Je pense que nous n'avons rien à craindre, car nous vivons dans un pays chrétien, et les chrétiens ne font pas la guerre aux blessés ni à ceux qui les ont abrités. Mais Pitt devrait disparaître quelque part.";
            link.l1.go = "PStep_6";
            //NextDiag.TempNode = "SStep_4";

		break;

        case "PStep_6":

            dialog.text = "D'accord, je vais me cacher dans la cheminée, mais tu ne connais pas bien le colonel Kirke, c'est un vrai démon. Et tu n'as même pas d'épée pour te défendre. Prends la mienne, je l'ai cachée sur le balcon, dans un coffre. Et dépêche-toi, les dragons vont faire irruption dans le manoir.";
        	link.l1 = "Merci, je vais la chercher, mais j'espère que je n'en aurai pas besoin.";
            link.l1.go = "Exit_RunAway";
			//кладём ключ на стол
			sld = ItemsFromID("key3");
			sld.shown = true;
			sld.startLocation = "Estate";
			sld.startLocator = "item1";

            Pchar.questTemp.CapBloodLine.sLocator = "reload2";
            Pchar.questTemp.CapBloodLine.iTime = 5;
            AddDialogExitQuestFunction("DragunInvansion2");

		break;

        case "PStep_7":

            dialog.text = "Bonjour, Peter. Cela fait exactement un mois aujourd'hui que nous travaillons dans les plantations de canne à sucre du colonel Bishop. Parfois, il me semble qu'il aurait mieux valu qu'on nous exécute, tant c'est dur. Tout le monde est si épuisé qu'on tombe littéralement de fatigue. Pas plus tard qu'hier, l'ancien forgeron de Bridgewater a été fouetté à mort pour servir d'exemple aux autres, et il s'était seulement plaint de la sévérité du contremaître Kent. Il faut faire quelque chose, Peter, sinon nous ne verrons pas l'hiver.";
        	link.l1 = "J'y pense sans arrêt, mais s'enfuir d'ici, sans aucune aide extérieure, c'est trop risqué ; pense à ce pauvre bougre qui a osé s'enfuir il y a deux semaines et qui s'est fait prendre. On l'a fouetté, puis on lui a marqué au fer rouge les lettres « F.E. » sur le front, pour que tout le monde sache jusqu'à la fin de ses jours qu'il était un forçat évadé.";
            link.l1.go = "PStep_8";
        break;

        case "PStep_8":
            dialog.text = "Heureusement pour ce malheureux, il est mort sous les coups ; mais je ne suis pas venu me plaindre de nos misères, je suis venu te prévenir que Bishop te cherche, pour une raison ou une autre. Essaie de ne pas le mettre en colère, sinon nous risquons de nous retrouver privés de tes soins.";
        	link.l1 = "Merci, Pitt, alors je vais aller le voir, et je promets d'être doux comme un agneau.";
            link.l1.go = "Exit_Away";
            Pchar.questTemp.CapBloodLine.sLocator = "reload1";
            Pchar.questTemp.CapBloodLine.iTime = -1;
            NextDiag.TempNode = "First time";
            Pchar.questTemp.CapBloodLine.stat = "";
            chrDisableReloadToLocation = false;
            AddDialogExitQuestFunction("ChangePIRATES");
		break;

        case "PStep_9":

            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
            CapBloodLine_q2_Complited();

		break;

        case "PStep_10":

            dialog.text = "Peter, tu as réussi à acheter un sloop ?";
        	link.l1 = "Pas encore.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "PStep_10";

		break;

        case "PStep_11":

            dialog.text = "Désolé, Peter, ils... Ils m'ont retrouvé...";
        	link.l1 = "Calme-toi, Pitt, Hagthorpe m'a tout raconté. Tu as sans doute pensé qu'on pourrait se passer d'un navigateur, pour donner à cette ordure de Bishop une raison de te tuer à moitié ?";
            link.l1.go = "PStep_12";

		break;

        case "PStep_12":

            dialog.text = "Je ne pense pas que tu auras besoin d'un navigateur du tout, Peter.";
        	link.l1 = "Quoi, qu'y a-t-il ?";
            link.l1.go = "PStep_13";

		break;

        case "PStep_13":

            dialog.text = "Nuttall s'est enfui.";
        	link.l1 = "Au diable Nuttall ! Nous trouverons quelque chose. Nous volerons le sloop, après tout ! Hagthorpe et les autres nous attendent déjà en ville, il faut les prévenir avant qu'ils ne soient capturés !";
            link.l1.go = "PStep_14";

		break;

        case "PStep_14":

            dialog.text = "Alors cours en ville prévenir les autres, tu pourras revenir me chercher plus tard.";
        	link.l1 = "Attends-nous ici, Pitt.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "PStep_15";
            chrDisableReloadToLocation = false;
           	LAi_group_SetHearRadius("TmpEnemy", LAI_GROUP_GRD_HEAR - 3);
   	        LAi_group_SetSayRadius("TmpEnemy", LAI_GROUP_GRD_SAY - 1);
   	        LAi_group_SetLookRadius("TmpEnemy", LAI_GROUP_GRD_LOOK - 1);
            AddQuestRecord("EscapeFormBarbados", "2");

		break;

        case "PStep_15":

            dialog.text = "Cours en ville !";
        	link.l1 = "Nous viendrons te chercher.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "PStep_15";

		break;

        case "PStep_16":

            dialog.text = "Félicitations, Peter, les gars m'ont raconté le combat contre les Espagnols. J'aurais aimé être avec vous ! Mais le principal, c'est que nous nous soyons échappés de cette maudite île !";
        	link.l1 = "Content de te voir sur pied, mon vieux. Malheureusement, nous ne nous sommes pas encore échappés. Il faut encore prendre la mer et décider oם aller.";
            link.l1.go = "PStep_17";

		break;

        case "PStep_17":

            dialog.text = "Oui, nous ne pouvons pas retourner en Angleterre : on nous y pendrait aussitכt. Nous ne serions pas plus en sécurité en Espagne ou en Hollande. Il en va de même pour toutes leurs colonies. Il ne reste que les colonies françaises, ou les pirates.";
        	link.l1 = "Je pense que nous aurons le temps d'y réfléchir plus tard. Pour l'instant, il n'y a pas de temps à perdre : ceux qui sont restés à terre ne sont pas aveugles, ils ne sont pas morts, et ils vont vite comprendre que quelque chose cloche avec le navire. Il faut élire un capitaine et se préparer à la défense.";
            link.l1.go = "PStep_18";

		break;

        case "PStep_18":

            dialog.text = "Qu'y a-t-il à choisir ! Tout le monde veut que tu sois notre capitaine, Peter.";
			DeleteAttribute(pchar, "LockBloodWeaponsOptions");
        	link.l1 = "Eh bien, s'il n'y a pas d'objections, préparons le navire au combat. Tu seras le navigateur, Jeremy, puisque tu es le seul d'entre nous capable de diriger le navire.";
            link.l1.go = "PStep_19";

		break;

        case "PStep_19":

            dialog.text = "א vos ordres, capitaine.";
        	link.l1 = "";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.CapBloodLine.sLocator = "reloadShip";
            Pchar.questTemp.CapBloodLine.iTime = 3;

        	NPChar.Money   = 0;
        	NPChar.Payment = true;
       		NPChar.DontClearDead = true;

            AddPassenger(pchar, NPChar, false);

            Pchar.Ship.Type = GenerateShipExt(SHIP_ARABELLA, true, Pchar);
            Pchar.Ship.name="Cinco Llagas";
            SetBaseShipData(Pchar);
            Pchar.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS32;
            SetCrewQuantity(Pchar, GetMinCrewQuantity(Pchar));

            SetCharacterGoods(Pchar,GOOD_FOOD,70);
        	SetCharacterGoods(Pchar,GOOD_BALLS,300);//2000);
            SetCharacterGoods(Pchar,GOOD_GRAPES,100);//700);
            SetCharacterGoods(Pchar,GOOD_KNIPPELS,100);//700);
            SetCharacterGoods(Pchar,GOOD_BOMBS,200);//1500);
            SetCharacterGoods(Pchar,GOOD_POWDER,500);
//            SetCharacterGoods(Pchar,GOOD_PLANKS,10);
//            SetCharacterGoods(Pchar,GOOD_RUM,40);//600);
            SetCharacterGoods(Pchar,GOOD_WEAPON,50);//2000);

            n = FindLocation("Bridgetown_town");

            locations[n].reload.ship1.name = "reloadShip";
            locations[n].reload.ship1.go = "Barbados";
            locations[n].reload.ship1.emerge = "reload_1";
            locations[n].reload.ship1.autoreload = "1";
            locations[n].reload.ship1.label = "Sea";

            Pchar.location.from_sea = "Bridgetown_town";
            setWDMPointXZ("Bridgetown_town");

            string sQuest = "CapBloodLaspEpisode";
            pchar.quest.(sQuest).win_condition.l1 = "EnterToSea";
            pchar.quest.(sQuest).win_condition = "CapBloodLaspEpisode";
            pchar.quest.(sQuest).function = "CapBloodLaspEpisode";

            AddDialogExitQuestFunction("SpaCrewAtack");


		break;

		//-->оружейние Гриффин

        case "GRStep_0":

            dialog.text = "Avec tout le respect que vous méritez sans aucun doute, docteur... Au diable vos affaires urgentes !";
        	link.l1 = "Je suis désolé de ne pas vous trouver de bonne humeur. Peut-être puis-je vous aider en quelque chose, après quoi vous m'écouterez ?";
            link.l1.go = "GRStep_1";

		break;

        case "GRStep_1":

            dialog.text = "M'aider ? Vous ?! Comment un esclave insolent pourrait-il aider...";
        	link.l1 = "On dirait que vous me sous-estimez, monsieur Griffin. Eh bien, vous et bien d'autres allez encore le regretter !";
            link.l1.go = "GRStep_2";
        	link.l2 = "Pourquoi pas ? J'ai besoin de votre aide, et il semble que je ne puisse offrir qu'une aide mutuelle dans cette situation.";
            link.l2.go = "GRStep_3";
		break;

        case "GRStep_2":

            AddQuestRecord("WeaponsForEscape", "4");
            dialog.text = "Dehors, docteur !";
            link.l1.go = "Exit";
            pchar.quest.PrepareToEscape2.win_condition.l1          = "location";
            pchar.quest.PrepareToEscape2.win_condition.l1.location = "Bridgetown_town";
            pchar.quest.PrepareToEscape2.function                  = "LoginSpain_spy";
        	Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape2";

		break;
        case "GRStep_3":

            dialog.text = "Bon, voyons. Le fait est qu'un Espagnol est venu me voir aujourd'hui. Il n'a pas donné son nom, mais je voyais à ses yeux que cet homme était prêt à tout. Je ne sais pas d'oם il venait ni comment il était entré en ville, mais il lui fallait des armes. Oui, docteur, j'ai eu peur... C'est pour ça que je ne peux pas aller voir les autorités maintenant : j'aurais dמ le faire plus tכt. L'Espagnol a refusé d'attendre que je lui prépare une commande, et il a pris mes modèles au mur : plusieurs coutelas, un mousquet à canon long et une paire de pistolets. Maudit porc espagnol !";
        	link.l1 = "...Je sais, je sais : « que le diable des mers l'emporte ».";
            link.l1.go = "GRStep_2";
            NextDiag.TempNode = "GRStep_2";
           	link.l2 = "Il n'a pas payé les armes ?";
            link.l2.go = "GRStep_4";

		break;
        case "GRStep_4":

            dialog.text = "Au diable le paiement ! Mon nom est gravé sur les modèles ! S'il part au combat avec mes armes à la main, quelqu'un le remarquera forcément... Et on finira par me prendre sans combat ! La dernière chose que je veuille, c'est finir ma vie au bout d'une vergue.";
        	link.l1 = "Si vous me dites oם est allé l'Espagnol, j'essaierai de régler votre problème. En échange, je vous demande seulement de me donner ce que cet homme a pris.";
            link.l1.go = "GRStep_5";

		break;

        case "GRStep_5":

            dialog.text = "Une arme avec mon nom sur la lame entre les mains d'un Espagnol ou d'un esclave... Quelle différence, bon sang ?! Nous serons pendus ensemble sur la place centrale avant l'aube de demain !";
        	link.l1 = "Au diable, je ne crois pas. Bien. Je vous rendrai les armes, et en échange, d'ici ce soir, vous me préparerez plusieurs coutelas et pistolets sans vos marques. דa vous va ?";
            link.l1.go = "GRStep_6";

		break;

        case "GRStep_6":

            dialog.text = "Ce voyou espagnol va vous étriper, docteur. Mais ça ne me regarde pas. Rendez-moi les modèles, et je ferai pour vous ce que vous demandez. Pour mille cinq cents piastres. Il est allé au port, chez le pêcheur Hells, dont la maison n'est pas loin de celle de l'apothicaire Dan.";
        	link.l1 = "Je reviens bientכt, mon cher monsieur Griffin. Préparez tout ce qu'il faut.";
            link.l1.go = "GRStep_7_1";
           	link.l2 = "Vous ne demandez pas un peu trop ? Je risque déjà ma vie pour votre réputation. Mille, et pas un sou de plus.";
            link.l2.go = "GRStep_7_2";

            sld = GetCharacter(NPC_GenerateCharacter("Spain_spy", "shipowner_13", "man", "man", 7, ENGLAND, -1, false));
            sld.dialog.filename = "Quest\CapBloodLine\Bishop.c";
            sld.name = "";
            sld.lastname = "L'Espagnol";
            GiveItem2Character(sld, "Griffins_Weapon");
            sld.SaveItemsForDead = true; // сохранять на трупе вещи
            sld.DontClearDead = true;
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorSetLayMode(sld);
            LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "CommonRoom_MH2", "goto", "goto2");


            sld = &characters[GetCharacterIndex("Hells")];
            LAi_SetActorTypeNoGroup(sld);
            LAi_ActorDialog(sld, pchar, "", 1.0, 0);

		break;

        case "GRStep_7_1":

            dialog.text = "D'accord, dépêchez-vous.";
        	link.l1 = "Vous n'aurez pas à attendre longtemps.";
            link.l1.go = "Exit";
            Pchar.questTemp.CapBloodLine.iMoney = 1500;
            NextDiag.TempNode = "GRStep_8";
			Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1_1";
            AddQuestRecord("WeaponsForEscape", "3");
            AddQuestUserData("WeaponsForEscape", "iMoney", 1500);

		break;

        case "GRStep_7_2":

            dialog.text = "D'accord, dépêchez-vous.";
        	link.l1 = "Vous n'aurez pas à attendre longtemps.";
            link.l1.go = "Exit";
            Pchar.questTemp.CapBloodLine.iMoney = 1000;
            NextDiag.TempNode = "GRStep_8";
			Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1_1";
            AddQuestRecord("WeaponsForEscape", "3");
            AddQuestUserData("WeaponsForEscape", "iMoney", 1000);

		break;

        case "GRStep_8":

            dialog.text = "Vous êtes revenu plus tכt que je ne m'y attendais. Que s'est-il passé ?";
            if (GetCharacterItem(pchar, "Griffins_Weapon") > 0)
            {
            	link.l1 = "Voici vos modèles, monsieur Griffin, jusqu'au dernier. Le voyou espagnol n'est plus un danger.";
                link.l1.go = "GRStep_9";
                TakeItemFromCharacter(Pchar, "Griffins_Weapon");
            }
            else
            {
            	link.l1 = "Je suis juste passé voir comment vous alliez.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GRStep_8";
            }

		break;

        case "GRStep_9":

            dialog.text = "Hum... eh bien, je ne veux même pas savoir comment vous avez fait, ni combien vous en avez tué au passage. Aujourd'hui, dans une heure, le même lot sera prêt pour vous. Et maintenant, je vais vous demander de me laisser, après avoir, bien sמr, payé mon travail.";
            if (makeint(pchar.money) >= sti(Pchar.questTemp.CapBloodLine.iMoney))
            {
           	    link.l1 = "Oui, bien sמr, cher monsieur Griffin. Voici votre argent. Je passerai à l'heure convenue.";
                link.l1.go = "Exit";
                AddMoneyToCharacter(pchar, (-sti(Pchar.questTemp.CapBloodLine.iMoney)));
                Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1_3";
                NextDiag.TempNode = "GRStep_12";
            }
            else
            {
           	    link.l1 = "Je n'ai pas la somme nécessaire sur moi en ce moment, je reviendrai plus tard.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GRStep_13";
            }
            //Pchar.questTemp.CapBloodLine.GriffinTime = GetHour();
            SaveCurrentQuestDateParam("questTemp.CapBloodLine.GriffinTime");
            AddQuestRecord("WeaponsForEscape", "6");

		break;

        case "GRStep_10":

            dialog.text = "Oui, je me souviens de quelque chose. Mais qu'est-ce qu'il vous faut, au juste ?";
        	link.l1 = "א moi... Un peu de votre assortiment ne serait pas de refus.";
            link.l1.go = "GRStep_11";

		break;

        case "GRStep_11":

            dialog.text = "Quoi ?! Des armes... Vous ?! Vous êtes fou, diable des mers ! Dehors !";
        	link.l1 = "";
            link.l1.go = "Exit";
            pchar.quest.PrepareToEscape2.win_condition.l1          = "location";
            pchar.quest.PrepareToEscape2.win_condition.l1.location = "Bridgetown_town";
            pchar.quest.PrepareToEscape2.function                  = "LoginSpain_spy";
        	Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape2";


		break;

        case "GRStep_12":

            if (Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape1_3" && GetQuestPastTimeParam("questTemp.CapBloodLine.GriffinTime") >= 1)
            {
                dialog.text = "Tenez, prenez, mais souvenez-vous : je ne l'ai pas fait pour vous.";
                link.l1 = "Merci.";
                link.l1.go = "Exit";
                GiveItem2Character(Pchar, "Weapon_for_escape");
                NextDiag.TempNode = "First time";
          		CloseQuestHeader("WeaponsForEscape");
                Pchar.questTemp.CapBloodLine.stat = "ReadyToEscape";
            }
            else
            {
                dialog.text = "Les armes ne sont pas encore prêtes, revenez plus tard.";
                link.l1 = "Bien.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GRStep_12";

            }

		break;

        case "GRStep_13":

            dialog.text = "Tu as apporté l'argent ?";
            if (makeint(pchar.money) >= sti(Pchar.questTemp.CapBloodLine.iMoney))
            {
                link.l1 = "Oui, voici votre argent. Je passerai à l'heure convenue.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GRStep_12";
                AddMoneyToCharacter(pchar, (-sti(Pchar.questTemp.CapBloodLine.iMoney)));
                Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1_3";
            }
            else
            {
           	    link.l1 = "Je n'ai pas la somme nécessaire sur moi en ce moment, je reviendrai plus tard.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "GRStep_13";
            }


		break;

        case "GRStep_14":

            dialog.text = "Bonté divine !..";
        	link.l1 = "Pas vraiment. Néanmoins, je suis venu savoir... Vous avez peut-être changé d'avis ?";
            link.l1.go = "GRStep_15";

		break;

        case "GRStep_15":

            dialog.text = "C-chan... Changé d'avis ?";
        	link.l1 = "Des armes, cher monsieur Griffin. Il me faut des armes. Juste quelques coutelas et deux pistolets, si ce n'est pas trop vous demander.";
            link.l1.go = "GRStep_16";

		break;

        case "GRStep_16":

            dialog.text = "Je... Je ne peux pas, monsieur. Malgré toute ma bonne volonté, je... Ils vous pendront !";
        	link.l1 = "Calmez-vous, je n'ai pas du tout besoin que vous fassiez quoi que ce soit officiellement. Pas de gravures sur la garde, pas de papiers ni de rapports : tout se fera dans le calme et la discrétion. Personne ne saura jamais que cela a eu lieu.";
            link.l1.go = "GRStep_17";

		break;

        case "GRStep_17":

            dialog.text = "Mmm... D'accord, bien. J'ai tout ça ici, tenez. J'espère que ça suffira.";
        	link.l1 = "Plus qu'il n'en faut. Merci beaucoup.";
            link.l1.go = "Exit";

            GiveItem2Character(Pchar, "Weapon_for_escape");
            AddQuestRecord("WeaponsForEscape", "9");
       		CloseQuestHeader("WeaponsForEscape");
            Pchar.questTemp.CapBloodLine.stat = "ReadyToEscape";
            NextDiag.TempNode = "First time";

		break;


        //-->рыбак Хелльс

        case "HStep_0":

            dialog.text = "Docteur... Que voulez-vous ici ?";
        	link.l1 = "J'avais besoin de l'homme dont le corps sans vie gît maintenant à vos pieds.";
            link.l1.go = "HStep_1";

		break;

        case "HStep_1":

            dialog.text = "Tu veux venger ton salaud d'ami ? Vas-y, blanc-bec !";
        	link.l1 = "Vous êtes trop agressif, monsieur Hells. Je vais vous prescrire un calmant. Le fait est que je veux simplement vous remercier de m'avoir facilité la tâche. Je suis venu récupérer certains biens que ce défunt gentilhomme a eu l'audace de voler à M. Griffin.";
            link.l1.go = "HStep_2";

		break;

        case "HStep_2":

            dialog.text = "Je ne rendrai pas cet argent ! Ce salaud m'a attaqué, et vous, vous voulez juste...";
        	link.l1 = "... récupérer les armes dont il s'est sans doute servi pour vous attaquer. Rien d'autre. Son argent vous revient de droit.";
            link.l1.go = "HStep_3";

		break;

        case "HStep_3":

            dialog.text = "Vous pouvez les prendre, je ne pense pas qu'il en ait encore besoin.";
        	link.l1 = "Merci.";
            link.l1.go = "HStep_4";
            NextDiag.TempNode = "First time";
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1_2";
		break;

        case "HStep_4":

            NextDiag.CurrentNode = NextDiag.TempNode;
            sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(NPChar, sTemp);
            LAi_SetOwnerTypeNoGroup(NPChar);
            DialogExit();
            Spain_spyDie("");
		break;

        case "HStep_5":

            dialog.text = "J'ai du travail pour vous, si ça vous intéresse. Quoique, je suis sמr que c'est une question idiote. Vous avez tous besoin d'argent.";
        	link.l1 = "Combien ?";
            link.l1.go = "HStep_6";

		break;

        case "HStep_6":

            dialog.text = "Je suis prêt à vous payer deux mille pour une information. Le fait est qu'Arnold Summerlight, mon concurrent, a trouvé un endroit... un endroit très poissonneux. Il me ruine ! Découvrez à tout prix oם il fait ses prises, et je me séparerai volontiers de deux mille. דa vous va ?";
        	link.l1 = "דa marche.";
            link.l1.go = "HStep_7";
           	link.l2 = "Ce n'est pas pour moi.";
            link.l2.go = "Exit";
            NextDiag.TempNode = "HStep_8";
		break;

        case "HStep_7":

            AddQuestRecord("FishermanQuest", "1");
            sld = &characters[GetCharacterIndex("Fisherman")];
            sld.dialog.currentnode = "FStep_1";
            NextDiag.TempNode = "HStep_9";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

		break;

        case "HStep_8":

            dialog.text = "Alors vous ne m'aiderez pas ?";
        	link.l1 = "Je vais vous aider.";
            link.l1.go = "HStep_7";
           	link.l2 = "Non.";
            link.l2.go = "Exit";
            NextDiag.TempNode = "HStep_8";

		break;

        case "HStep_9":

            dialog.text = "Alors ?";
            if(CheckAttribute(Pchar, "questTemp.CapBloodLine.fishplace"))
            {
            	link.l1 = "J'ai tout découvert, monsieur Hells.";
                link.l1.go = "HStep_10";
            }
            else
            {
            	link.l1 = "Pas encore de nouvelles.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "HStep_9";
            }

		break;

        case "HStep_10":

            dialog.text = "Ce n'est pas possible ! Oם ? Oם est-ce qu'il prend son poisson ?";
        	link.l1 = "Il jette ses filets au cap Ragged Point.";//+Pchar.questTemp.CapBloodLine.fishplace;
            link.l1.go = "HStep_11";

		break;

        case "HStep_11":

            dialog.text = "Bon sang, comment n'y ai-je pas pensé plus tכt !.. Bon, voici votre argent.";
        	link.l1 = "Merci.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "First time";
            AddMoneyToCharacter(pchar, 2000);
       		CloseQuestHeader("FishermanQuest");
		break;


        //-->Испанский шпион

        case "SSStep_0":

            dialog.text = "Il me faut un armurier. Oם est l'armurier ?";
        	link.l1 = "Sa maison est tout près. Il y est, en principe.";
            link.l1.go = "SSStep_1";
           	link.l2 = "Pourquoi vous montrerais-je le chemin ? Que voulez-vous à un armurier ?";
            link.l2.go = "SSStep_2";
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape2_1";
            chrDisableReloadToLocation = false;
            LocatorReloadEnterDisable("BridgeTown_town", "houseSp2", true);

		break;

        case "SSStep_1":

            dialog.text = "*rire rauque*";
        	link.l1 = "";
            link.l1.go = "Exit_Away";
            Pchar.questTemp.CapBloodLine.sLocator = "houseSp2";
            Pchar.questTemp.CapBloodLine.iTime = 20;
            AddQuestRecord("WeaponsForEscape", "7");

		break;

        case "SSStep_2":

            dialog.text = "Alors fiche le camp avant que je ne t'étripe.";
        	link.l1 = "Ce serait problématique.";
            link.l1.go = "Exit_Away";
            Pchar.questTemp.CapBloodLine.sLocator = "houseSp2";
            Pchar.questTemp.CapBloodLine.iTime = 20;
            AddQuestRecord("WeaponsForEscape", "7");

		break;

        case "SSStep_3":

            dialog.text = "(à Griffin) : Chien d'Anglais !.. Je vais tuer tout le monde dans cette ville, et je vais commencer par toi, vieux têtu ! Tu ne comprends pas, le Cinco Llagas va bientכt... Et toi, qu'est-ce que TU fais ici ?!";
        	link.l1 = "Permettez-moi de vous interrompre.";
            link.l1.go = "SSStep_4";
		break;

        case "SSStep_4":

            dialog.text = "Eh bien, puisque tu es venu... Tu es le suivant !";
        	link.l1 = "Non, je crois que je serai plutכt le précédent...";
            link.l1.go = "fight";
            sld = &characters[GetCharacterIndex("Griffin")];
            sld.dialog.currentnode = "GRStep_14";

		break;

		//--> Контрабандист

        case "QSStep_0":

            dialog.text = "Halte, halte, halte... Demander une telle faveur, ce n'est guère mieux que de me demander de vous emmener loin d'ici. D'ailleurs, je ne risquerai pas de vous emmener loin de ces terres, au péril de ma vie, car si on l'apprenait, je mourrais bien plus douloureusement ; mais des armes ! Il faut être un homme assez audacieux et un peu fou pour en demander dans une taverne, quand on est un esclave privilégié. Et il faut être encore plus fou pour accepter de vous aider...";
        	link.l1 = "Puisque vous êtes si bavard, c'est que vous y avez un intérêt ; il ne reste plus qu'à convenir du prix.";
            link.l1.go = "QSStep_1";
		break;

        case "QSStep_1":

            dialog.text = "Vous êtes très perspicace, docteur. Eh bien, je ne vais pas le cacher : vous avez raison. Quelque chose m'intéresse, mais j'ai bien peur que vous n'osiez pas prendre le risque...";
        	link.l1 = "De quoi s'agit-il ?";
            link.l1.go = "QSStep_2";
		break;

        case "QSStep_2":

            dialog.text = "Je sais que vous avez accès au domaine du gouverneur...";
        	link.l1 = "Inutile de continuer. Je suis pressé, et la probabilité que le gouverneur ou sa femme aille plus mal en ce moment est négligeable. Sinon, la route du domaine m'est fermée.";
            link.l1.go = "QSStep_3";

		break;

        case "QSStep_3":

            dialog.text = "Je suis sמr que pour une douzaine de coutelas et quelques mousquets que j'ai, par un heureux hasard, sur moi, ainsi que, disons, trois mille pièces bien brillantes, vous trouverez un moyen d'aller chez le gouverneur.";
        	link.l1 = "Qu'attend-on de moi ?";
            link.l1.go = "QSStep_4";

		break;

        case "QSStep_4":

            dialog.text = "Une petite bague. C'est tout.";
        	link.l1 = "Une bague ? Elle est au doigt de sa femme, je suppose. Et je dois la lui retirer et vous la rapporter ?";
            link.l1.go = "QSStep_5";

		break;

        case "QSStep_5":

            dialog.text = "Je ne pense pas qu'elle la porte, mon cher docteur. Néanmoins, elle l'a. Une petite bague en or, toute simple, qui ne vaut pas trois piastres, mais diablement importante pour moi. Un acheteur vous en donnerait à peine le cinquième de ce que je vous offre. Seulement, ne me demandez pas pourquoi. Contentez-vous de répondre.";
			pchar.LockBloodWeaponsOptions = true;
        	link.l1 = "Je reviens dès que possible. Préparez l'argent et la marchandise.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "QSStep_6";

            sld = &characters[GetCharacterbyLocation("Bridgetown_town", "soldiers", "soldier2")];
            sld.dialog.filename = "Quest\CapBloodLine\Bishop.c";
            sld.Dialog.CurrentNode = "GStep_1";
            sld.protector = true;
            sld.protector.CheckAlways = 1 ;
            LocatorReloadEnterDisable("BridgeTown_town", "reload3_back", true);
            LocatorReloadEnterDisable("Bridgetown_Townhall", "reload3", true);
            LocatorReloadEnterDisable("BridgeTown_town", "reloadR1", true);

            sld = characterFromID("MisStid");
            sld.Dialog.CurrentNode = "MSStep_3";
        	sld.talker = 10;
            ChangeCharacterAddressGroup(sld, "Bridgetown_TownhallRoom", "barmen", "bar1");

            sld = characterFromID("Den");
            LAi_SetCitizenTypeNoGroup(sld);
            //LAi_SetStayTypeNoGroup(sld);
            LAi_SetOwnerTypeNoGroup(sld);
            sld.Dialog.CurrentNode = "DStep_3";
			ChangeCharacterAddressGroup(sld, "CommonPirateHouse", "goto", "goto6");

            sld = ItemsFromID("MsStid_ring");
			sld.shown = true;
			sld.startLocation = "Bridgetown_TownhallRoom";
			sld.startLocator = "item1";

            pchar.quest.PrepareToEscape3.win_condition.l1          = "location";
            pchar.quest.PrepareToEscape3.win_condition.l1.location = "Bridgetown_TownhallRoom";
            pchar.quest.PrepareToEscape3.function                  = "FindMsStid_ring";
			AddQuestRecord("WeaponsForEscape", "11");
            Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape3";

		break;


        case "QSStep_6":

            if (GetCharacterItem(pchar, "MsStid_ring") > 0)
			{
                dialog.text = "Le docteur est de retour ! Merveilleux !";
                link.l1 = "Comment avez-vous appris l'existence de cette bague ?";
    			link.l1.go = "QSStep_7";
                link.l2 = "Voici votre bien. Alors, et l'or et les armes ?";
    			link.l2.go = "QSStep_12";
			}
			else
			{
                dialog.text = "Autre chose ?";
            	link.l1 = "Non.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "QSStep_6";
            }

		break;

        case "QSStep_7":

            dialog.text = "Vous avez découvert ? Cher docteur, je ne me doutais de rien.";
        	link.l1 = "Votre réponse me laisse quelque peu perplexe. Quelle est cette bague ? D'oם vient-elle ?";
            link.l1.go = "QSStep_8";

		break;

        case "QSStep_8":

            dialog.text = "Cette bague est extrêmement importante pour moi, mais elle ne vous sert à rien. J'ai de la chance de l'avoir retrouvée, et je suis donc prêt à remplir ma part du marché et à vous donner tout ce que je vous ai promis.";
        	link.l1 = "Ou peut-être, puisque vous ne saviez rien de cette bague, devrais-je aller me renseigner auprès de quelqu'un d'autre ? On me le dira peut-être sur la place du marché ? Regardez-moi ça... comme elle brille de façon séduisante.";
            link.l1.go = "QSStep_10";

		break;

        case "QSStep_10":

            dialog.text = "*rit* L'arrogant capitaine Blood a déjà retrouvé le goמt de vivre avec une vigueur nouvelle... donnez-la-moi !";
        	link.l1 = "Je pense, monsieur, que vous feriez mieux de me rendre cette bague et de m'expliquer pourquoi vous m'avez appelé capitaine.";
            link.l1.go = "QSStep_11";
            TakeItemFromCharacter(Pchar, "MsStid_ring");

		break;

        case "QSStep_11":

            dialog.text = "Ne perdez pas votre précieux temps avec ça, Peter Blood. Voici votre argent et vos armes, dépêchez-vous. Qui sait, peut-être que le destin nous a réunis pour une raison.";
        	link.l1 = "Bon, d'accord.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "First time";
            GiveItem2Character(Pchar, "Weapon_for_escape");
            NextDiag.TempNode = "First time";
       		CloseQuestHeader("WeaponsForEscape");
            AddMoneyToCharacter(pchar, 3000);
            AddQuestRecord("WeaponsForEscape", "16");
            CloseQuestHeader("WeaponsForEscape");
            Pchar.questTemp.CapBloodLine.stat = "ReadyToEscape";

		break;

        case "QSStep_12":

            dialog.text = "Merci beaucoup. Voici votre argent et tout ce qu'il vous faut. Au revoir.";
        	link.l1 = "Portez-vous bien.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "First time";
            GiveItem2Character(Pchar, "Weapon_for_escape");
            NextDiag.TempNode = "First time";
       		CloseQuestHeader("WeaponsForEscape");
            AddMoneyToCharacter(pchar, 3000);
            TakeItemFromCharacter(Pchar, "MsStid_ring");
            AddQuestRecord("WeaponsForEscape", "16");
            CloseQuestHeader("WeaponsForEscape");
            Pchar.questTemp.CapBloodLine.stat = "ReadyToEscape";

		break;

		  //--> Волверстон

        case "VLStep_0":
            dialog.text = "J'aimerais bien, mais j'ai peur de ne pas être d'une grande utilité.";
        	link.l1 = "Pourquoi donc ?";
            link.l1.go = "VLStep_0_1";
            NextDiag.TempNode = "VLStep_1";
		break;

		case "VLStep_0_1":
            dialog.text = "Pendant ces longs mois de travaux forcés, je n'ai pas bu une goutte, mais quand je suis sobre, j'ai l'esprit très lent. Tu pourrais m'apporter une bouteille de rhum ?";
			SetQuestHeader("VolversonRum");
			AddQuestRecord("VolversonRum", "1");
			pchar.SeekVolverstonRum = true;
        	link.l1 = "On dirait que je n'ai pas le choix. Sans toi, l'évasion, on peut l'oublier.";
            link.l1.go = "exit";
            NextDiag.TempNode = "VLStep_0_2";
		break

		case "VLStep_0_2":
            dialog.text = "Tu as apporté ce que je t'ai demandé ?";
			if(CheckCharacterItem(pchar, "potionrum"))
			{
				link.l1 = "Voilà.";
				link.l1.go = "VLStep_0_3";
			}
			link.l2 = "Pas encore.";
            link.l2.go = "exit";
            NextDiag.TempNode = "VLStep_0_2";

		break;

		case "VLStep_0_3":
            dialog.text = "(Il vide la bouteille jusqu'à la dernière goutte en quelques instants) Oh... C'est beaucoup mieux comme ça. Tu parlais de t'évader ? J'en suis.";
			RemoveItems(PChar, "potionrum", 1);
			AddQuestRecord("VolversonRum", "2");
			CloseQuestHeader("VolversonRum");
			DeleteAttribute(pchar, "SeekVolverstonRum")
        	link.l1 = "Pitt te donnera tous les détails. J'espère que tu ne vas pas tomber ivre mort maintenant et rater toute la fête.";
            link.l1.go = "exit";
            NextDiag.TempNode = "VLStep_1";
            //Pchar.questTemp.CapBloodLine.Volverston = true;
            Pchar.questTemp.CapBloodLine.Officer = sti(Pchar.questTemp.CapBloodLine.Officer)+1;
		break;

        case "VLStep_1":

            dialog.text = "Diable, quand est-ce qu'elle arrive, cette maudite nuit ?!";
        	link.l1 = "Un peu de patience, mon ami. Nous allons quitter cette maudite île très bientכt.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "VLStep_1";

		break;

		 case "VLStep_11":

            dialog.text = "Je me suis bien dégourdi les bras ! Dommage que la plupart de ces chiens de lâches d'Espagnols soient à terre en ce moment : je me serais bien amusé, héhé !";
        	link.l1 = "S'ils étaient tous ici, à bord, je ne pense pas que nous nous serions amusés, mon ami.";
            link.l1.go = "VLStep_12";

		break;

        case "VLStep_12":

            dialog.text = "Oui, Peter, tu as sans doute raison, comme toujours.";
        	link.l1 = "Mais ce n'est pas de ça que je voulais te parler. Wolverstone, tu es un bon combattant, peu de gens peuvent rivaliser avec toi en force, et je pense qu'avec un peu de navigation, tu deviendras un excellent second. Veux-tu servir sous mes ordres comme officier ?";
            link.l1.go = "VLStep_13";

		break;

        case "VLStep_13":

            dialog.text = "Hisser le Jolly Roger, devenir un pirate libre, passer plus de temps en mer qu'à terre, risquer sa vie tous les jours, l'odeur de la poudre, l'or, le rhum ? Avec grand plaisir !";
        	link.l1 = "Je savais que tu accepterais.";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.CapBloodLine.sLocator = "reloadShip";
            Pchar.questTemp.CapBloodLine.iTime = 3;

        	NPChar.Money   = 0;
        	NPChar.Payment = true;
       		NPChar.DontClearDead = true;

            AddPassenger(pchar, NPChar, false);
            AddDialogExitQuestFunction("VolverstonAdd");

		break;
        //--> Натаниэль Хагторп

        case "HTStep_0":

            dialog.text = "Cette bague est extrêmement importante pour moi, mais elle ne vous sert à rien. J'ai de la chance de l'avoir retrouvée, et je suis donc prêt à remplir ma part du marché et à vous donner tout ce que je vous ai promis.";
        	link.l1 = "Ou peut-être, puisque vous ne saviez rien de cette bague, devrais-je aller me renseigner auprès de quelqu'un d'autre ? On me le dira peut-être sur la place du marché ? Regardez-moi ça... comme elle brille de façon séduisante.";
            link.l1.go = "HTStep_1";

		break;

        case "HTStep_1":

            dialog.text = "J'ai ici... une affaire à terminer, mon ami.";
        	link.l1 = "Alors tu vas la terminer immédiatement, avec mon aide. J'aurai besoin de toi pendant ce voyage, et je ne peux pas te laisser rester, vieux loup de mer.";
            link.l1.go = "HTStep_2";

		break;

        case "HTStep_2":

            dialog.text = "*rit* Je te respecte énormément, tu sais. Mais c'est une question d'honneur, je dois finir ce que j'ai commencé.";
        	link.l1 = "Alors je te demande de m'en faire part. De quoi s'agit-il, et comment puis-je t'aider ?";
            link.l1.go = "HTStep_3";

		break;

        case "HTStep_3":

            dialog.text = "Un homme du nom de Stuart Winterwood est arrivé ici récemment. Je ne sais pas si tu vas me comprendre, mais c'est mon ennemi juré. א cause de lui, j'ai tout perdu : ma famille, mon honneur, ma vie. C'est à cause de lui que je suis ici !..";
        	link.l1 = "Que s'est-il passé ?";
            link.l1.go = "HTStep_4";

		break;

        case "HTStep_4":

            dialog.text = "Au diable le passé ! דa n'a plus d'importance. Je croyais que je ne reverrais jamais son visage, que ce sourire moqueur serait mon dernier souvenir de cet homme... Mais tu sais quel souvenir je voudrais avoir ? Son visage tordu de douleur, sur sa tête tranchée, bon sang !";
        	link.l1 = "Bon, soit. Comment le trouver ?";
            link.l1.go = "HTStep_5";

		break;

        case "HTStep_5":

            dialog.text = "La taverne, le bordel... Il est quelque part par là, le diable ! א s'amuser, à boire, à jouer aux cartes ! Mon alliance est à sa main, MA femme l'attend à la maison ! Rapporte-moi la bague... avec le doigt.";
        	link.l1 = "Si tu veux, je peux aussi te rapporter sa tête.";
            link.l1.go = "HTStep_13";
            NextDiag.TempNode = "HTStep_10";
        	link.l2 = "Tu es sמr de vouloir faire ça, Hagthorpe ? Sa mort n'apaisera pas ton tourment.";
            link.l2.go = "HTStep_6";
		break;

        case "HTStep_6":

            dialog.text = "Si je doutais un seul instant de vouloir sa mort, je n'en parlerais pas avec autant d'assurance.";
        	link.l1 = "Tu pourrais pourtant te tromper. Réfléchis : vaut-il la peine de le tuer maintenant, en risquant tout ? Nous pourrions...";
            link.l1.go = "HTStep_7";

		break;

        case "HTStep_7":

            dialog.text = "Que le diable t'emporte, Blood ! C'est une question d'honneur, je te l'ai dit ! Tu as peur de prendre des risques, tu n'oses pas m'aider : ne le fais pas ! Tu iras au diable sans moi !";
        	link.l1 = "Très bien, Hagthorpe. Je vais le tuer.";
            link.l1.go = "HTStep_13";
           	link.l2 = "Sans toi ? Difficilement, mais avec un peu d'habileté... וcoute-moi. Nous pouvons prendre la mer maintenant et commencer une nouvelle vie, et tכt ou tard, tu croiseras ce maudit Winterwood et tu te vengeras comme tu voudras, sans risquer ta peau. Tu le pendras à la grand-vergue, après lui avoir coupé chaque doigt s'il le faut !";
            link.l2.go = "HTStep_8";
            NextDiag.TempNode = "HTStep_10";

		break;

        case "HTStep_8":

            dialog.text = "Tu... Tu essaies de m'en dissuader alors que ce monstre est sous mon nez ?!";
            if(Pchar.SPECIAL.Charisma >= 5)
            {
            	link.l0 = "Eh bien... oui, c'est comme ça.";
                link.l0.go = "HTStep_9";
            }
            else
            {
                AddCharacterExpToSkill(pchar, "LeaderShip", 50);
            }
           	link.l1 = "Très bien, Hagthorpe. Je vais le tuer.";
            link.l1.go = "HTStep_13";

		break;

        case "HTStep_9":

            dialog.text = "D'accord, j'accepte ! Au diable Winterwood, pour l'instant. Je me joins à toi.";
        	link.l1 = "Marché conclu.";
            link.l1.go = "Exit";
            AddCharacterExpToSkill(pchar, "LeaderShip", 150);
            NextDiag.TempNode = "HTStep_12";
            Pchar.questTemp.CapBloodLine.Hugtorp = true;
            Pchar.questTemp.CapBloodLine.Officer = sti(Pchar.questTemp.CapBloodLine.Officer)+1;
			Pchar.HugtorpQuestFinish = true;
            AddQuestRecord("HugtorpTrouble", "2");
            CloseQuestHeader("HugtorpTrouble");

		break;
        case "HTStep_10":

            dialog.text = "Tu es déjà revenu ? Il est mort ?";
            if (GetCharacterItem(pchar, "DOjeronRing") > 0)
            {
                link.l1 = "On ne peut plus mort. Voici ce que tu m'as demandé.";
                link.l1.go = "HTStep_11";
                TakeItemFromCharacter(Pchar, "DOjeronRing");
                ref itm = ItemsFromID("DOjeronRing"); //возвращаем все как было
                BackItemName("DOjeronRing");
                BackItemDescribe("DOjeronRing");
                itm.picIndex = 2;
                itm.picTexture = "ITEMS_9";
            }
            else
            {
                link.l1 = "Non, je voulais juste voir si tu avais changé d'avis : apparemment non.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "HTStep_10";
            }
		break;

        case "HTStep_11":

            dialog.text = "Eh bien... enfin... Je me joins à ton évasion, Blood. Et merci.";
        	link.l1 = "Marché conclu.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "HTStep_12";
            Pchar.questTemp.CapBloodLine.Hugtorp = true;
            Pchar.questTemp.CapBloodLine.Officer = sti(Pchar.questTemp.CapBloodLine.Officer)+1;
			Pchar.HugtorpQuestFinish = true;
            AddQuestRecord("HugtorpTrouble", "4");
            CloseQuestHeader("HugtorpTrouble");

		break;

        case "HTStep_12":

            dialog.text = "Tout est prêt ? Qu'attend-on de moi ?";
        	link.l1 = "Pas encore, je te préviendrai le moment venu.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "HTStep_12";

		break;

        case "HTStep_13":

            LoginWinterwood();
			Pchar.HugtorpQuestStart = true;
            AddQuestRecord("HugtorpTrouble", "1");
            NextDiag.CurrentNode = "HTStep_10";
			DialogExit();

		break;

        case "HTStep_14":

            dialog.text = "Peter, mauvaise nouvelle : les hommes du colonel Bishop ont surpris Jeremy Pitt au moment même oם il cachait des provisions pour l'évasion. Il a juste eu le temps de me dire qu'il avait réussi à cacher quelques armes dans un coffre, entre les planches, au bord de la plantation.";
        	link.l1 = "Qu'est-il arrivé à Pitt ?";
            link.l1.go = "HTStep_15";
            chrDisableReloadToLocation = false;

		break;

        case "HTStep_15":

            dialog.text = "Ce porc de Bishop l'a fouetté à moitié à mort et a ordonné qu'on ne lui donne ni à boire ni à manger tant qu'il n'aura pas livré ses complices.";
        	link.l1 = "C'est mauvais. Bishop m'a fait revenir de la ville pour une raison ou une autre ; peut-être que je suis soupçonné, moi aussi...";
            link.l1.go = "HTStep_16";



		break;

        case "HTStep_16":

            dialog.text = "Pitt tient bon, mais tu ferais mieux de ne pas aller voir le colonel, il pourrait te faire enfermer. Mieux vaut ne rien faire pour l'instant : nous attendrons la nuit. Et dès qu'il fera noir, nous sortirons les armes et nous libérerons Jeremy.";
        	link.l1 = "Oui, c'est ce que nous allons faire : je m'occupe de libérer Pitt, et toi, tu emmènes les hommes en ville à la faveur de la confusion. Tu t'en sens capable ?";
            link.l1.go = "HTStep_17";

		break;

        case "HTStep_17":

            dialog.text = "Oui, Peter, nous t'attendrons au chantier naval. Et méfie-toi des patrouilles : les hommes de Bishop attrapent tout le monde sans distinction en ce moment.";
        	link.l1 = "Je ferai attention.";
            link.l1.go = "Exit";
            AddDialogExitQuestFunction("ReturnToPlantation3");
            AddQuestRecord("EscapeFormBarbados", "1");

		break;

        case "HTStep_18":

            dialog.text = "Mauvaise nouvelle, Peter...";
            if(Pchar.questTemp.CapBloodLine.SpainInBridgetown == false)
            {
               	link.l1 = "Que s'est-il passé ?";
                link.l1.go = "HTStep_19";
            }
            else
            {
               	link.l1 = "Je suis déjà au courant.";
                link.l1.go = "HTStep_20";
            }
		break;

        case "HTStep_19":

            dialog.text = "Les Espagnols ont pris Bridgetown. Aujourd'hui, un grand navire est entré dans notre port sous un faux pavillon. C'était un corsaire espagnol. Sa ruse du pavillon est restée si bien inaperçue que, sans éveiller le moindre soupçon, il est entré tranquillement dans la baie et a salué le fort, à bout portant, d'une bordée de vingt canons.";
        	link.l1 = "Voilà ce qu'on appelle l'intervention opportune du destin. Même si le diable seul sait ce qu'il en sortira !";
            link.l1.go = "HTStep_20";
            AddQuestRecord("EscapeFormBarbados", "3");

		break;

        case "HTStep_20":

            dialog.text = "Et notre plan d'évasion ? Nuttall s'est enfui, le sloop a disparu...";
        	link.l1 = "Le plan change : nous allons nous emparer d'un autre navire.";
            link.l1.go = "HTStep_21";

		break;

        case "HTStep_21":

            dialog.text = "Lequel ?";
        	link.l1 = "Celui qui est en rade en ce moment. Je pense que la plupart de l'équipage est en train de faire des ravages à terre, alors nous pourrons facilement nous en emparer.";
            link.l1.go = "HTStep_22";

		break;

        case "HTStep_22":

            dialog.text = "Alors plutכt mourir en combattant les Espagnols que pourrir dans les plantations de Bishop ! Montre-nous le chemin, Peter !";
        	link.l1 = "Essayons d'approcher sans être vus...";
            link.l1.go = "Exit";
            AddDialogExitQuestFunction("CapBloodOfficers");
            AddQuestRecord("EscapeFormBarbados", "4");
            NextDiag.TempNode = "HTStep_22b";

		break;

        case "HTStep_22b":

            dialog.text = "Quels sont tes ordres, Peter ?";
        	link.l1 = "Suivez-moi, nous passons à l'assaut.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "HTStep_22b";
            AddDialogExitQuestFunction("CapBloodOfficers");

		break;

        case "HTStep_23":

            dialog.text = "Lequel ?";
        	link.l1 = "Celui qui est en rade en ce moment. Je pense que la plupart de l'équipage est en train de faire des ravages à terre, alors nous pourrons facilement nous en emparer.";
            link.l1.go = "HTStep_22";

		break;

        case "HTStep_24":

            dialog.text = "Tu avais raison, Peter. Tout s'est passé comme tu l'avais dit : nous avons pris ce beau navire presque sans pertes.";
        	link.l1 = "Oui, Hagthorpe, mais j'ai bien peur que ce ne soit qu'un début. Je pense que tu es un excellent marin. Veux-tu servir sous mes ordres comme officier ?";
            link.l1.go = "HTStep_25";

		break;

        case "HTStep_25":

            dialog.text = "Peter, tu es un homme bon et compatissant, le mot « honneur » n'est pas un vain mot pour toi, tu es un merveilleux médecin, un capitaine talentueux et un excellent chef. S'il le faut, je donnerai ma vie pour toi.";
        	link.l1 = "Merci, Nathaniel, mais tu auras encore le temps de donner ta vie pour moi ; pour l'instant, il faut encore nous échapper de cet enfer.";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.CapBloodLine.sLocator = "reloadShip";
            Pchar.questTemp.CapBloodLine.iTime = 3;

        	NPChar.Money   = 0;
        	NPChar.Payment = true;
       		NPChar.DontClearDead = true;

            AddPassenger(pchar, NPChar, false);
            AddDialogExitQuestFunction("HugtorpAdd");
		break;

        //--> Николас Дайк

        case "DKStep_0":

            dialog.text = "Non, hélas, je ne sais rien. Il ne l'a peut-être pas encore fait... mais ça n'a plus d'importance.";
        	link.l1 = "Plus d'importance ? Que s'est-il passé ?";
            link.l1.go = "DKStep_1";

		break;

        case "DKStep_1":

            dialog.text = "Le colonel Bishop me vend. Hier, un acheteur est arrivé en ville : il lui faut un esclave qui connaisse bien les choses de la mer. J'ai bien peur qu'on ne puisse plus rien y faire...";
        	link.l1 = "Vraiment ? Hum. Eh bien, on verra.";
            link.l1.go = "exit";
            NextDiag.TempNode = "DKStep_2";
            sld = characterFromID("Bishop");
            sld.Dialog.CurrentNode = "BStep_2";
            AddQuestRecord("DiekeQuest", "1");
		break;

        case "DKStep_2":

            dialog.text = "Je suis désolé de ce qui s'est passé.";
        	link.l1 = "Tout n'est pas encore perdu, Nick.";
            link.l1.go = "exit";
            NextDiag.TempNode = "DKStep_2";
		break;

        case "DKStep_3":

            dialog.text = "Récemment, un médecin est venu de la part de l'acheteur, il m'a examiné... On dirait que l'affaire va se faire.";
        	link.l1 = "Calme-toi, Nicholas. L'or destiné à ton achat m'est déjà échu en héritage. Tu viens avec nous demain soir.";
            link.l1.go = "exit";
            Pchar.questTemp.CapBloodLine.Dieke = true;
            Pchar.questTemp.CapBloodLine.Officer = sti(Pchar.questTemp.CapBloodLine.Officer)+1;
            NextDiag.TempNode = "DKStep_4";
            CloseQuestHeader("DiekeQuest");

		break;

        case "DKStep_4":

            dialog.text = "J'ai hâte d'être à demain soir !";
        	link.l1 = "Moi aussi, Nick.";
            link.l1.go = "exit";
            NextDiag.TempNode = "DKStep_4";

		break;

        case "DKStep_5":

            dialog.text = "Je ne pensais pas qu'il faudrait verser autant de sang sur le chemin de la liberté.";
        	link.l1 = "Nicholas, tu es un brave garçon, tu feras un officier intelligent. Viens-tu avec nous ?";
            link.l1.go = "DKStep_6";

		break;

        case "DKStep_6":

            dialog.text = "Pour être honnête, je ne sais même pas quoi faire... Je voulais quitter la mer, m'installer à terre, trouver une épouse convenable et vivre tranquillement. Maintenant, il n'y a plus de retour possible en Angleterre, c'est la même chose avec l'Espagne et la Hollande ; il ne reste que la France, mais il n'y a rien là-bas qui me retienne, personne qui m'aiderait à survivre dans ce monde cruel. Dans les plantations, je me suis fait des amis : toi, Pitt et d'autres esclaves. J'entrerai à ton service, mais quand le moment sera venu et que je déciderai de m'installer à terre, ne me retiens pas.";
        	link.l1 = "D'accord, j'en tiendrai compte. Maintenant, va te préparer : nous ne sommes pas encore libres.";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.CapBloodLine.sLocator = "reloadShip";
            Pchar.questTemp.CapBloodLine.iTime = 3;

        	NPChar.Money   = 0;
        	NPChar.Payment = true;
       		NPChar.DontClearDead = true;
			NPChar.model = "PBLine_Daik_0";
			FaceMaker(NPChar);

            AddPassenger(pchar, NPChar, false);
            AddDialogExitQuestFunction("DiekeAdd");
		break;

        //--> Нед Огл

        case "OGLStep_0":

            dialog.text = "De quoi diable parles-tu ?";
        	link.l1 = "Je parle de la merveilleuse occasion de mettre le cap sur Curaçao demain soir.";
            link.l1.go = "OGLStep_1";

		break;

        case "OGLStep_1":

            dialog.text = "וchapper à Bishop ? Tu crois que c'est si simple ? Ce n'est pas seulement un planteur sadique, c'est aussi, à ses heures, le commandant de la milice de la Barbade...";
        	link.l1 = "Je sais tout ça. Mais je sais aussi que quelqu'un veut vraiment nous aider. Il le veut tellement qu'il va même fournir l'argent pour le sloop.";
            link.l1.go = "OGLStep_2";
		break;

        case "OGLStep_2":

            dialog.text = "Eh bien, alors je ne peux que vous envier, toi et tes complices...";
        	link.l1 = "Courage, mon ami borgne. Je suis venu t'inviter à venir avec nous.";
            link.l1.go = "OGLStep_3";
		break;

        case "OGLStep_3":

            dialog.text = "Peter, j'aimerais bien, mais je ne peux pas.";
        	link.l1 = "Quel est le problème ?";
            link.l1.go = "OGLStep_4";
		break;

        case "OGLStep_4":

            dialog.text = "Ehhh... le problème, c'est l'argent.";
        	link.l1 = "L'argent ? Mais...";
            link.l1.go = "OGLStep_5";
		break;

        case "OGLStep_5":

            dialog.text = "J'ai emprunté de l'argent il y a quelque temps. L'usurier a eu pitié de moi, et j'en avais vraiment besoin. Il m'a aidé, et je n'ai plus l'âge d'être si insouciant : je ne veux pas laisser de dettes derrière moi.";
        	link.l1 = "Mais comment es-tu sorti du domaine ?";
            link.l1.go = "OGLStep_6";
		break;


        case "OGLStep_6":

            dialog.text = "Je n'en suis pas sorti, c'est lui qui est venu ici : il venait voir le colonel pour une raison ou une autre.";
        	link.l1 = "Bon, bon... Je ne peux pas partir sans canonnier, et à part toi, je n'en trouverai pas ici. Combien dois-tu ?";
            link.l1.go = "OGLStep_7";
		break;

        case "OGLStep_7":

            dialog.text = "Je dois cinq mille, alors oublie ça, mon ami. Tu n'auras pas besoin de canonnier pour aller à Curaçao.";
        	link.l1 = "Eh bien, voyons ça.";
            link.l1.go = "Exit";
            NextDiag.TempNode = "OGLStep_8";
            Pchar.questTemp.CapBloodLine.Ogl = false;
            AddQuestRecord("OglQuest", "1");

		break;

        case "OGLStep_8":

            if(CheckAttribute(Pchar, "questTemp.CapBloodLine.Ogl") && Pchar.questTemp.CapBloodLine.Ogl == true)
            {
                dialog.text = "Oui, Peter ?";
            	link.l1 = "Ta dette est réglée, Ogle. Maintenant, je n'accepterai pas de refus.";
                link.l1.go = "OGLStep_9";
            }
            else
            {
                NextDiag.TempNode = "OGLStep_8";
                dialog.text = "Oui, Peter ?";
            	link.l1 = "Non, je m'en vais déjà.";
                link.l1.go = "Exit";
                NextDiag.TempNode = "OGLStep_8";
            }
		break;

        case "OGLStep_9":

            dialog.text = "Quoi ? Tu as donné l'argent pour moi ?";
        	link.l1 = "Attends mes ordres d'ici demain soir.";
            link.l1.go = "exit";
            Pchar.questTemp.CapBloodLine.Ogl = true;
            Pchar.questTemp.CapBloodLine.Officer = sti(Pchar.questTemp.CapBloodLine.Officer)+1;
            NextDiag.TempNode = "OGLStep_10";
            AddQuestRecord("OglQuest", "3");
            CloseQuestHeader("OglQuest");

		break;

        case "OGLStep_10":

            dialog.text = "Quels sont vos ordres ?";
        	link.l1 = "Aucun pour l'instant, Ned.";
            link.l1.go = "exit";
            NextDiag.TempNode = "OGLStep_10";

		break;

        case "OGLStep_11":

            dialog.text = "C'était un combat acharné, capitaine. דa faisait longtemps que je ne m'étais pas battu comme aujourd'hui.";
        	link.l1 = "Ned, si je ne me trompe pas, tu as été canonnier dans la Marine royale ?";
            link.l1.go = "OGLStep_12";

		break;

        case "OGLStep_12":

            dialog.text = "Pendant quinze ans, j'ai été le meilleur canonnier de toute la flotte de Sa Majesté !";
        	link.l1 = "Alors, puisque je suis le capitaine de ce navire, veux-tu servir sous mes ordres comme maître canonnier ?";
            link.l1.go = "OGLStep_13";

		break;

        case "OGLStep_13":
            dialog.text = "Pour être honnête, je ne sais même pas quoi faire... Je voulais quitter la mer, m'installer à terre, trouver une épouse convenable et vivre tranquillement. Maintenant, il n'y a plus de retour possible en Angleterre, c'est la même chose avec l'Espagne et la Hollande ; il ne reste que la France, mais rien ne m'y retient, personne ne m'aiderait à survivre dans ce monde cruel. Dans les plantations, je me suis fait des amis : toi, Pitt et d'autres esclaves. J'entrerai à ton service, mais quand le moment sera venu et que je déciderai de m'installer à terre, ne me retiens pas.";
        	link.l1 = "D'accord, j'en tiendrai compte. Maintenant, va te préparer : nous ne sommes pas encore libres.";
            link.l1.go = "Exit_RunAway";
            Pchar.questTemp.CapBloodLine.sLocator = "reloadShip";
            Pchar.questTemp.CapBloodLine.iTime = 3;

        	NPChar.Money   = 0;
        	NPChar.Payment = true;
       		NPChar.DontClearDead = true;

            AddPassenger(pchar, NPChar, false);
            AddDialogExitQuestFunction("OglAdd");

		break;

	}
}
