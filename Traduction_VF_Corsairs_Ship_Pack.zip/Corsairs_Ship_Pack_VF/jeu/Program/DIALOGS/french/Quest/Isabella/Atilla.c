
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
	if (PChar.sex != "woman")
	{
		dialog.text = "Que je crève ! Ce vieux " + GetFullName(PChar) + " !";
		link.l1 = "Atilla ! Salut, vieux diable des mers !";
		link.l1.go = "port_1";
	}
	else
	{
		dialog.text = "Ma belle " + GetFullName(PChar) + " ! Comme je suis content de te voir !";
		link.l1 = "Mais moi, je ne suis pas content de te voir, Attila. Nous n'avons rien à nous dire. Ou tu crois que j'ai oublié comment tu m'as piégé à Caracas ? Fiche le camp.";
		link.l1.go = "W_exit";
		if (startherotype == 2)
		{
			dialog.text = RandPhraseSimple("Que voulez-vous ? Passez votre chemin.", "Arrêtez de me barrer la route, dégagez.");
			link.l1 = RandPhraseSimple("Vous savez quoi ? N'aboyez pas !", "Modérez votre ardeur. Sinon, je vais vite la refroidir !");
			link.l1.go = "exit";
			NextDiag.TempNode = "W_exit";
		}
	}
			NextDiag.TempNode = "First time";
			DeleteAttribute(npchar, "talker"); //снимаем говорилку
		break;

	case "W_exit":
		npchar.lifeDay = 1;
	LAi_CharacterDisableDialog(npchar);
    DialogExit();
	break;

	case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = "" + PChar.name + ", qu'est-ce que c'est que ces bêtises ? Range ton arme immédiatement !";
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		case "port_1":
		    sld = characterFromID("Atilla");
			dialog.text = "Regarde-moi ça, tu t'es habillé comme un don ! Le vent ne doit pas siffler dans tes poches non plus ! Tu offrirais à boire à un vieil ami ?";
			if (pchar.RomanticQuest == "")
			{
			    link.l1 = "Je suis sacrément content de te voir, mais je ne peux pas maintenant, mon vieux. Une autre fois...";
				link.l1.go = "Exit";
			}
			else
			{
				link.l1 = "Ha ha ha ! Ce serait un péché de ne pas s'envoyer une chope de bon rhum de la Jamaïque pour une telle rencontre !";
				link.l1.go = "port_1_1";
			}
		break;

		case "port_1_1":
			dialog.text = "Que ma rate éclate, il faut arroser une telle rencontre ! א la taverne, et tout de suite...";
			link.l1 = "D'accord : à la taverne !";
			link.l1.go = "port_toTavern";
		break;

		case "port_toTavern":
			DialogExit();
			NextDiag.CurrentNode = "Tavern_1";
			chrDisableReloadToLocation = true;
			bDisableFastReload = true;
			FreeSitLocator("Pirates_tavern", "sit3");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload4_back", "Pirates_tavern", "sit", "sit3", "Romantic_Pirat_toTavern", -1);
		break;

		case "Tavern_1":
			LAi_SetSitType(Pchar);
			dialog.text = "Bon sang, " + GetFullName(PChar)+" ! Toi et moi, on a fait du beau travail à Caracas, cette fois-là, que le diable m'emporte !";
			link.l1 = "Oui... Tu as envoyé bien des diables catalans rejoindre leurs ancêtres dans cette bataille. Pour cette fameuse boucherie, on t'a donné ce surnom : Attila... Je vois que tu n'as pas eu beaucoup de chance depuis.";
			link.l1.go = "Tavern_2";
		break;

		case "Tavern_2":
			dialog.text = "Arrgh ! Je vais te dire une chose : ne fais jamais confiance à ces dons catalans ! J'en ai fréquenté un. Une fois, nous avons pris un navire français. Il y avait un joaillier parmi les passagers. Je me fiche de ses lettres de change, mais les babioles, je m'y connais. Mère de Dieu, elles valaient tant qu'on aurait pu acheter la moitié d'Hispaniola et la maison du gouverneur, gouverneur compris. Bref, nous avons tout partagé honnêtement, trouvé cinq tonneaux de rhum dans la cale, et nous nous sommes soמlés de joie...";
			link.l1 = "Hé, comme toujours...";
			link.l1.go = "Tavern_3";
		break;

		case "Tavern_3":
			dialog.text = "C'est ça, mais le lendemain matin, il s'est avéré que mon ami n'était pas un imbécile. Il a détaché l'esquif dans la nuit, il a pris tout le butin, et il a filé.";
			link.l1 = "Et tu l'as laissé s'en tirer comme ça ? Que le requin m'avale ! Moi, je...";
			link.l1.go = "Tavern_4";
		break;

		case "Tavern_4":
			dialog.text = "Qu'est-ce que tu ferais, bleu ?! Il s'est enfui sur une île espagnole. Et moi, je n'ai pas le droit d'y aller. Bon, que Dieu le garde. Il aurait pu simplement me trancher la gorge, à moi, l'ivrogne idiot, et personne n'aurait rien dit.";
			link.l1 = "Hum, tu es devenu affreusement mélancolique, mon ami.";
			link.l1.go = "Tavern_5";
		break;

		case "Tavern_5":
			dialog.text = "Le temps passe, et je vieillis. Ce n'est plus si facile pour moi d'envoyer un homme dans l'autre monde... et Salvator, à ce qu'on dit, s'est marié avec mon argent. Il vit à San Juan, maintenant...";
			link.l1 = "Que le diable m'emporte ! Atilla, mon ami, et si j'allais visiter ce paisible nid familial ? Tu vois, dans le coffret à bijoux de sa femme, on retrouvera peut-être tes babioles, hein ?";
			link.l1.go = "Tavern_6";
		break;

		case "Tavern_6":
			dialog.text = "Ha ha ha ! Il me semble que ce n'est pas pour des babioles que tu as décidé de te glisser dans sa chambre ! Non, mon ami, puisque la proie m'a filé entre les doigts, c'est que ça devait être ainsi... Bon, il est temps pour moi. Si Dieu le veut, nous nous reverrons.";
			link.l1 = "Adieu, Atilla.";
			link.l1.go = "Tavern_Out";
		break;

		case "Tavern_Out":
			NextDiag.CurrentNode = "Tavern_Bye";
			DialogExit();
			AddDialogExitQuest("Romantic_Pirat_toTavern_end");
		break;

		case "Tavern_Bye":
            NextDiag.TempNode = "Tavern_Bye";
			dialog.text = "Je finis mon verre et je retourne au navire...";
			link.l1 = "Je ne vous dérangerai pas.";
			link.l1.go = "exit";
		break;
		//доводим новости до сведения Атиллы
		case "TalkingNews":
			dialog.text = "Oh, qui vois-je !? " + GetFullName(pchar) + ", en personne !";
			link.l1 = "Salut, Atilla ! On dirait que les choses s'arrangent peu à peu pour toi : tu t'es acheté une maison...";
			link.l1.go = "TalkingNews_1";
		break;
		case "TalkingNews_1":
			dialog.text = "L'argent est arrivé, alors j'ai décidé d'investir dans la pierre. Même si, pour être honnête, une maison ici, c'est loin de valoir une maison à Tortuga...";
			link.l1 = "Bah, c'est toujours un toit.";
			link.l1.go = "TalkingNews_2";
		break;
		case "TalkingNews_2":
			dialog.text = "Hum, c'est vrai ! Alors, dis-moi, pourquoi es-tu venu me voir ?";
			link.l1 = "Oui, tu sais, il y a une chose qu'on ne peut pas raconter en deux mots... Bref, j'ai rendu visite à ton ami Salvator Olevares.";
			link.l1.go = "TalkingNews_3";
		break;
		case "TalkingNews_3":
			dialog.text = "Hé, en voilà une nouvelle ! Comment va cet escroc ? C'est vrai qu'il s'est marié ?";
			link.l1 = "Oui, c'est vrai. Sa femme, Isabella, est une très belle femme... Et honnête, en plus.";
			link.l1.go = "TalkingNews_4";
		break;
		case "TalkingNews_4":
			dialog.text = "Hé, qu'est-ce qui te fait croire ça ? Les femmes sont un peuple perfide, et un grand mal peut se cacher derrière une belle apparence.";
			link.l1 = "Le mal, c'est Salvator ! Je ne t'ai pas raconté ce qui s'est passé, alors écoute bien.";
			link.l1.go = "TalkingNews_5";
		break;
		case "TalkingNews_5":
			dialog.text = "Avec plaisir...";
			link.l1 = "Bref, je suis arrivé à San Juan après notre conversation et j'ai commencé à démêler l'affaire. Il s'est passé bien des choses là-bas, mais finalement, il s'est avéré que Salvator avait dépouillé sa femme et qu'il a tué son frère sous mes yeux.";
			link.l1.go = "TalkingNews_6";
		break;
		case "TalkingNews_6":
			dialog.text = "Ouais, il est allé loin, ce salaud...";
			link.l1 = "Il m'a calomnié et a essayé de me faire arrêter... Quand j'ai réussi à me sortir de cette situation tant bien que mal, Salvator s'est volatilisé. Et Isabella s'est enfermée chez elle, elle ne laisse entrer personne...";
			link.l1.go = "TalkingNews_7";
		break;
		case "TalkingNews_7":
			dialog.text = "Eh bien, mon ami, merci d'avoir essayé de rétablir la justice. Que comptes-tu faire maintenant ?";
			link.l1 = "Je pense retrouver Salvator et l'étriper. Je dois aussi m'expliquer avec Isabella... Elle croit que c'est moi qui ai tué son frère.";
			link.l1.go = "TalkingNews_8";
		break;
		case "TalkingNews_8":
			dialog.text = "דa alors, mon vieux, elle compte pour toi ?";
			link.l1 = "Non, Atilla, plus maintenant...";
			link.l1.go = "TalkingNews_9";
		break;
		case "TalkingNews_9":
			dialog.text = "L'amour... Qu'y faire ?";
			link.l1 = "Quoi ?";
			link.l1.go = "TalkingNews_10";
		break;
		case "TalkingNews_10":
			dialog.text = "C'est du français... Rien, ce n'est rien.\n"+
				          "Et oם comptes-tu chercher ?";
			link.l1 = "Je ne sais pas, je n'arrive pas à trouver.";
			link.l1.go = "TalkingNews_11";
		break;
		case "TalkingNews_11":
			dialog.text = "וcoute, tu as débusqué Salvator de San Juan, et c'est très bien. Maintenant, je peux me joindre aux recherches.";
			link.l1 = "Et tu pourras le trouver ?";
			link.l1.go = "TalkingNews_12";
		break;
		case "TalkingNews_12":
			dialog.text = "Je pense que oui. Tu n'es pas le seul à respecter Attila, ce pirate a aussi des amis...";
			link.l1 = "Eh bien, ce serait formidable. Que dois-je faire ?";
			link.l1.go = "TalkingNews_13";
		break;
		case "TalkingNews_13":
			dialog.text = "Occupe-toi de tes affaires pour l'instant, moi, je me mets tout de suite aux recherches. Tu ne peux m'aider en rien, tu ne ferais que me gêner. Retrouvons-nous ici dans deux mois, chez moi. Je te dirai alors tout ce que j'aurai appris.";
			link.l1 = "D'accord, Atilla. Eh bien, bonne chance.";
			link.l1.go = "TalkingNews_14";
		break;
		case "TalkingNews_14":
			SetTimerCondition("Romantic_AtillaToHouse", 0, 2, 0, false);
			AddQuestRecord("Romantic_Line", "11");
            LAi_SetActorType(npchar);
			ChangeCharacterAddressGroup(npchar, pchar.location, "goto", "goto2");
            LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", 3.0);
			//открываем дом Сальватора и убираем Изабеллу, ставим наёмных убийц в дом.
			LocatorReloadEnterDisable("SanJuan_town", "houseSp6", false);
			LocatorReloadEnterDisable("SanJuan_houseSp6", "reload2", false);
			ChangeCharacterAddress(characterFromId("Isabella"), "none", "");
            Pchar.quest.Romantic_AmbushInHouse.win_condition.l1 = "location";
            Pchar.quest.Romantic_AmbushInHouse.win_condition.l1.location = "SanJuan_houseSp6";
            Pchar.quest.Romantic_AmbushInHouse.win_condition = "Romantic_AmbushInHouse";
			DialogExit();
		break;
		//через два месяца по завершению поисков
		case "AtillaInHouse":
			dialog.text = "Ah, vous voilà, " + GetFullName(pchar) + ". Entre, ça fait plaisir de te voir.";
			link.l1 = "Atilla, comment ça va ? Tu as appris quelque chose de nouveau sur notre grand ami ?";
			link.l1.go = "AtillaInHouse_1";
		break;
		case "AtillaInHouse_1":
			dialog.text = "Bien sמr que oui, " + pchar.name + ", comment veux-tu que ce soit autrement ? Bref, tu as bien secoué Salvator. Il ne tient plus en place, il se déplace sans cesse.";
			link.l1 = "Et comment l'attraper, maintenant ?";
			link.l1.go = "AtillaInHouse_2";
		break;
		case "AtillaInHouse_2":
			dialog.text = "Il faut que je réfléchisse...";
			link.l1 = "וcoute, tu sais quelque chose sur Isabella ?";
			link.l1.go = "AtillaInHouse_3";
		break;
		case "AtillaInHouse_3":
			dialog.text = "Oui, mon vieux. On dirait que Salvator l'a attirée hors de San Juan. Il a envoyé le brick pirate l'Enthousiaste la chercher, et d'après les rumeurs, le capitaine a mis le cap sur Portobelo.";
			link.l1 = "Et pourquoi a-t-il besoin d'elle ? Il l'a déjà ruinée...";
			link.l1.go = "AtillaInHouse_4";
		break;
		case "AtillaInHouse_4":
			dialog.text = "Pour effacer ses traces, je suppose, mon vieux. Ton Isabella ne vivra pas si elle tombe entre les mains de Salvator.";
			link.l1 = "Argh, quand le brick a-t-il quitté San Juan ? Je dois l'intercepter à temps !";
			link.l1.go = "AtillaInHouse_5";
		break;
		case "AtillaInHouse_5":
			dialog.text = "Si tu veux revoir Isabella vivante, oui. Le brick a quitté San Juan il y a trois jours. D'après mes calculs, il sera à Portobelo dans quinze ou seize jours, pas plus.";
			link.l1 = "Alors je dois me dépêcher... Merci, Atilla !";
			link.l1.go = "AtillaInHouse_6";
		break;
		case "AtillaInHouse_6":
			dialog.text = "Mon vieux, n'oublie pas un petit détail : Salvator lui-même doit se trouver quelque part à Portobelo. Il y attend Isabella.";
			link.l1 = "Hé, c'est vrai ! Attila, je dois me dépêcher. Si tout se passe bien, je te rendrai les bijoux perdus.";
			link.l1.go = "AtillaInHouse_7";
		break;
		case "AtillaInHouse_7":
			dialog.text = "D'accord, " + pchar.name + ". Bonne chance à vous !";
			link.l1 = "Merci, Atilla.";
			link.l1.go = "exit";
			NextDiag.TempNode = "AtillaInHouse_Again";
			AddQuestRecord("Romantic_Line", "13");
			pchar.RomanticQuest = "AttackBrig"; //флаг для кэпа на абордаже брига
            Pchar.quest.Romantic_AttackBrig.win_condition.l1 = "location";
            Pchar.quest.Romantic_AttackBrig.win_condition.l1.location = "PortoBello";
            Pchar.quest.Romantic_AttackBrig.win_condition = "Romantic_AttackBrig";
			SetTimerCondition("Romantic_BrigTimeOver", 0, 0, 16, false);
		break;
		case "AtillaInHouse_Again":
			dialog.text = "Alors, oם en es-tu ?";
			link.l1 = "Toujours rien...";
			link.l1.go = "exit";
		break;
		// после погони за бригом Восторженный, если не догнал его вообще
		case "Brig_Late":
			dialog.text = "Alors, raconte, oם en es-tu ?";
			link.l1 = "דa ne va pas... Je n'ai pas réussi à rattraper ce brick, je n'ai même pas aperçu sa poupe...";
			link.l1.go = "Brig_Late_1";
		break;
		case "Brig_Late_1":
			dialog.text = "Hum, c'est mauvais... On dirait qu'Isabella n'est plus de ce monde...";
			link.l1 = "Tu as sans doute raison. Quand j'y pense, j'ai le cœur qui se brise...";
			link.l1.go = "Brig_Late_2";
		break;
		case "Brig_Late_2":
			dialog.text = "Les larmes de chagrin n'y peuvent rien, à quoi bon maintenant ? Cette aventure est terminée pour toi, il faut aller de l'avant.";
			link.l1 = "Tu as raison, Atilla. Merci pour ton soutien. Adieu...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Last_Talk";
			CloseQuestHeader("Romantic_Line");
			pchar.questdata.IstoriyaIzabely = 1;
			DeleteAttribute(pchar, "RomanticQuest");
		break;
		case "Last_Talk":
			dialog.text = "Bientכt, je vais devoir reprendre la mer moi aussi : il faut bien vivre de quelque chose...";
			link.l1 = "Bonne chance à toi, Atilla.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Last_Talk";
		break;
		// если догнал бриг свалил или ГГ ушёл на карту
		case "Brig_DieHard":
			dialog.text = "Alors, mon vieux, quelles nouvelles ?";
			link.l1 = "De mauvaises nouvelles. J'ai rattrapé le brick à Portobelo, mais je n'ai pas réussi à l'aborder...";
			link.l1.go = "Brig_DieHard_1";
		break;
		case "Brig_DieHard_1":
			dialog.text = "Mmm, c'est très mauvais. Isabella est sans doute déjà morte...";
			link.l1 = "Caramba ! Apparemment, c'est ainsi... Je ne peux pas y penser sans pleurer...";
			link.l1.go = "Brig_Late_2";
		break;
		// если догнал бриг, но утопил его
		case "Brig_Sunk":
			dialog.text = "Alors, raconte, oם en es-tu ?";
			link.l1 = "דa ne va pas... J'ai rattrapé le brick à Portobelo, mais je n'ai pas pu l'aborder : il a coulé pendant le combat. Il n'y a eu aucun survivant...";
			link.l1.go = "Brig_Sunk_1";
		break;
		case "Brig_Sunk_1":
			dialog.text = "Ouais, mon vieux, c'est terrible... On ne t'envie pas : tu as perdu la femme qui te plaisait...";
			link.l1 = "Je ne peux pas en parler : j'ai le cœur qui se brise...";
			link.l1.go = "Brig_Late_2";
		break;
		// если Изабелла утонула с бригом, нет векселей
		case "Isabella_Sink":
			dialog.text = "Alors, raconte, oם en es-tu ?";
			link.l1 = "דa ne va pas... J'ai rattrapé le brick à Portobelo et je l'ai abordé.";
			link.l1.go = "Isabella_Sink_1";
		break;
		case "Isabella_Sink_1":
			dialog.text = "Quoi, ton Isabella n'était pas là ?";
			link.l1 = "Elle y était, mais elle ne m'a pas cru. Et je n'ai pas pu la faire quitter le navire en perdition : elle a préféré sombrer avec le brick. Voilà, Attila...";
			link.l1.go = "Brig_Late_2";
		break;
		// узнать что-нибудь новое о Сальватора
		case "SalvatorNews":
			dialog.text = "Qui vois-je ?! " + GetFullName(pchar) + ", en personne !";
			link.l1 = "Salut, Atilla ! Comment ça va, mon vieux ?";
			link.l1.go = "SalvatorNews_1";
		break;
		case "SalvatorNews_1":
			dialog.text = "דa va bien. Et toi, comment vas-tu ?";
			link.l1 = "Avec plus ou moins de succès. Je n'arrive pas à trouver Salvator, je ne tombe que sur ses sbires.";
			link.l1.go = "SalvatorNews_2";
		break;
		case "SalvatorNews_2":
			dialog.text = "Je vois...";
			link.l1 = "וcoute, tu as entendu parler de lui, toi ?";
			link.l1.go = "SalvatorNews_3";
		break;
		case "SalvatorNews_3":
			dialog.text = "Pas grand-chose de concret. Il engage toute la racaille des bouges, il la paie pour son travail, mais lui, il disparaît. C'est difficile de l'attraper.";
			link.l1 = "Hum, oui... Je ne sais pas quoi faire.";
			link.l1.go = "SalvatorNews_4";
		break;
		case "SalvatorNews_4":
			dialog.text = "Va à Belize et cherche-le là-bas.";
			link.l1 = "Pourquoi Belize ?";
			link.l1.go = "SalvatorNews_5";
		break;
		case "SalvatorNews_5":
			dialog.text = "Parce que Salvator est allé là-bas. C'est la dernière chose que j'ai apprise sur lui, il y a à peine deux jours.";
			link.l1 = "Diable ! J'ai emmené Isabella à Belize !!!";
			link.l1.go = "SalvatorNews_6";
		break;
		case "SalvatorNews_6":
			dialog.text = "Ah, eh bien, maintenant on comprend ce qu'il y cherchait. Si j'étais toi, je ne perdrais pas de temps...";
			link.l1 = "Je n'en perdrai pas... Adieu, Atilla, merci pour ton aide !";
			link.l1.go = "exit";
			NextDiag.TempNode = "AtillaInHouse_Again";
			AddQuestRecord("Romantic_Line", "20");
			ChangeCharacterAddress(characterFromId("Isabella"), "none", "");
			QuestSetCurrentNode("Rosita", "BackRosita");
			//Изабеллу в шахту
			sld = characterFromId("Isabella");
			LAi_SetStayType(sld);
			ChangeCharacterAddressGroup(sld, "Beliz_Cave_2", "goto", "goto5");
			sld.dialog.currentnode = "IsabellaInCave";
		break;
		//Изабелла убита в церкви.
		case "IsabellaIsDead":
			dialog.text = "Oh, capitaine " + GetFullName(pchar) + ". Comment ça va, mon vieux ?";
			link.l1 = "Attila, j'ai perdu Isabella...";
			link.l1.go = "IsabellaIsDead_1";
		break;
		case "IsabellaIsDead_1":
			dialog.text = "Que s'est-il passé ?";
			link.l1 = "J'ai tué Salvator, et Isabella et moi devions nous marier à San Juan. Pendant la cérémonie, une foule de voyous a fait irruption dans l'église, et ils l'ont tuée... C'est Salvator qui les avait engagés, de son vivant.";
			link.l1.go = "IsabellaIsDead_2";
		break;
		case "IsabellaIsDead_2":
			dialog.text = "Mmm, je suis désolé. Mais qu'y faire ? Il faut bien continuer à vivre...";
			link.l1 = "Oui, Atilla, c'est vrai...";
			link.l1.go = "exit";
			npchar.LifeDay = 0;
			NextDiag.TempNode = "IsabellaIsDead_after";
			CloseQuestHeader("Romantic_Line");
			pchar.questdata.IstoriyaIzabely = 1;
		break;
		case "IsabellaIsDead_after":
			dialog.text = "Oh, Atilla, comme c'est dur pour moi...";
			link.l1 = "Je comprends, mon vieux...";
			link.l1.go = "exit";
			NextDiag.TempNode = "IsabellaIsDead_after";
			npchar.lifeDay = 0;
		break;
		//если ГГ отбился в церкви
		case "IsabellaIsMyWife":
			dialog.text = "Salut, mon vieux ! Comment ça va ?";
			link.l1 = "La vie est belle, Atilla ! Tout va à merveille ! Isabella et moi nous sommes mariés, me voilà un homme marié.";
			link.l1.go = "IsabellaIsMyWife_1";
			npchar.lifeDay = 0;
		break;
		case "IsabellaIsMyWife_1":
			dialog.text = "Félicitations, c'est une bonne chose. Sinon, la vie d'un pirate n'est pas bien longue, il faut savoir s'arrêter à temps...";
			link.l1 = "Oui, c'est vrai. Isabella a accepté de m'épouser à condition que j'abandonne la course.";
			link.l1.go = "IsabellaIsMyWife_2";
		break;
		case "IsabellaIsMyWife_2":
			dialog.text = "Eh bien, c'est peut-être juste, mon vieux...";
			link.l1 = "Sans doute, oui, Atilla. Bon, adieu...";
			link.l1.go = "exit";
			link.l2 = "Atilla, voilà l'affaire... Je veux te remercier pour tout.";
			link.l2.go = "IsabellaIsMyWife_3";
			NextDiag.TempNode = "IsabellaIsMyWife_after";
			pchar.RomanticQuest.Atilla = "YouAreBaster";
			npchar.LifeDay = 0;
		break;
		case "IsabellaIsMyWife_after":
			dialog.text = "Voilà encore le capitaine " + pchar.name + " qui débarque. Qu'est-ce que tu veux à Attila, cette fois ?";
			link.l1 = "Rien de spécial, je passais juste, mon vieux...";
			link.l1.go = "exit";
			NextDiag.TempNode = "IsabellaIsMyWife_after";
		break;
		case "IsabellaIsMyWife_3":
			dialog.text = "Pour quoi exactement ?";
			link.l1 = "Eh bien, pour ton aide : combien de fois m'as-tu tiré d'affaire ! Et puis, c'est grâce à ton tuyau que j'ai rencontré Isabella, pour ainsi dire...";
			link.l1.go = "IsabellaIsMyWife_4";
		break;
		case "IsabellaIsMyWife_4":
			dialog.text = "Hé, je ne refuserai pas, mon vieux...";
			if (sti(pchar.money) >= 1000)
			{
				link.l1 = "Eh bien, alors accepte mille pièces, Atilla !";
				link.l1.go = "AddRepa_1";
			}
			if (sti(pchar.money) >= 70000)
			{
				link.l2 = "Je t'ai préparé 70 000 pièces.";
				link.l2.go = "AddRepa_2";
			}
			if (sti(pchar.money) >= 150000)
			{
				link.l3 = "Ta part dans cette affaire, c'est 150 000 pièces.";
				link.l3.go = "AddRepa_3";
			}
			if (sti(pchar.money) >= 300000)
			{
				link.l4 = "Ta part dans cette affaire, c'est 300 000 pièces.";
				link.l4.go = "AddRepa_4";
			}
		break;
		case "AddRepa_1":
			dialog.text = "Tu m'étonnes, " + pchar.name + "... Enfin, merci quand même. א cheval donné, on ne regarde pas les dents, comme on dit...";
			link.l1 = "Il n'y a pas de quoi, mon vieux ! Porte-toi bien...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -1000);
			ChangeCharacterReputation(pchar, -10);
		break;
		case "AddRepa_2":
			dialog.text = "Eh bien, c'est formidable ! Je te suis reconnaissant, " + GetFullName(pchar) + ".";
			link.l1 = "Ce n'est rien, Atilla. Porte-toi bien...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -70000);
			pchar.RomanticQuest.Atilla = "YouAreNormal";
			ChangeCharacterReputation(pchar, 5);
		break;
		case "AddRepa_3":
			dialog.text = "Oh, formidable ! Même si je ne me suis pas vraiment foulé...";
			link.l1 = "Atilla, tu ne t'es peut-être pas trop foulé, mais tous tes efforts ont été très utiles ! Porte-toi bien...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -150000);
			pchar.RomanticQuest.Atilla = "YouAreNormal";
			ChangeCharacterReputation(pchar, 15);
		break;
		case "AddRepa_4":
			dialog.text = "Oh, que le diable m'emporte !! C'est beaucoup d'argent !"+
				          "Eh bien, merci, mon vieux : quand je me fais un ami, c'est pour de bon. Je vais m'acheter une plus belle niche, maintenant... Non, je vais sans doute retourner dans l'Ancien Monde, je suis resté ici trop longtemps...";
			link.l1 = "Fais comme tu veux, mon vieux ! Porte-toi bien...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -300000);
			pchar.RomanticQuest.Atilla = "YouAreGood";
			ChangeCharacterReputation(pchar, 30);
		break;
	}
}
