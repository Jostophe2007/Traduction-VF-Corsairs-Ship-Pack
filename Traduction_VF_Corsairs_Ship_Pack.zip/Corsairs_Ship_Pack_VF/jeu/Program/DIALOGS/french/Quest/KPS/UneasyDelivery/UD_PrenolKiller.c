// Gregg: John and Nils, Jacque Prenol's creditors - quest "Goods for Richard Tillman"
// (ported from Damned Destiny). The scene is overheard: the player stands aside, and both
// sides of the exchange are the creditors talking to Prenol and then to each other.
// Nodes 1-5 are led by John, 6-10 by Nils.
// Logic - Program\Quests\reaction_functions\uneasydelivery.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "John : Eh bien, Prenol, les dettes, ça se paie. Nous t'avions donné un dernier délai, jusqu'à ce soir, et maintenant, nous attendons notre argent.";
			link.l1 = "Jacque Prenol : Je n'ai pas pu l'apporter ici, John, je...";
			link.l1.go = "2";
		break;

		// Gregg: in Damned Destiny the debt was "two hundred and fifty thousand", a quarter
		// of a million. The sums of the quest are cut by a factor of ten, so here it is
		// twenty-five thousand: exactly what the hoard holds over and above Shon's debt,
		// and the figures agree with one another.
		case "2":
			dialog.text = "John : Quoi ?! Prenol, on ne t'avait pas prévenu, hein ?";
			link.l1 = "Jacque Prenol : Mais je ne suis pas assez fou pour apporter vingt-cinq mille ici, aux Bermudes. Ici, on est prêt à s'égorger pour deux cents piastres ! Et qu'est-ce qu'on m'aurait fait pendant les deux semaines oם je vous ai attendus, si on avait appris que je transportais une telle somme ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "John : Alors tu ne nous as pas apporté l'argent, Prenol ?";
			link.l1 = "Jacque Prenol : Je l'ai caché près du phare. Voici la carte. Vous n'avez qu'à y aller et le prendre.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "John : Jacque, nous te l'avions dit : si tu n'apportes pas l'argent ici, tu es fini !";
			link.l1 = "Jacque Prenol : Non ! Ne me tue pas, John, je t'ai expliqué pourquoi je ne l'ai pas apporté ici.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "John : דa ne nous intéresse pas. Nous t'avions dit que l'argent devait être ici aujourd'hui. Au lieu de ça, tu nous envoies à je ne sais quel phare. Non, Prenol, nous te connaissons bien trop pour croire que tu as vraiment caché l'argent là-bas.";
			link.l1 = "Jacque Prenol : Non ! Non, John, ne me tue pas ! Non, je t'en supplie...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryPrenolKill");
		break;

		case "6":
			dialog.text = "John : Quel idiot. Je lui avais dit : n'apporte pas l'argent, et je te tue, que le diable m'emporte.";
			link.l1 = "Nils : Et si on allait vérifier ce trésor près du phare ? Qui sait, il l'y a peut-être vraiment caché.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "John : Et tu l'as cru ? Tu as cru ce qu'il nous a raconté ici sur le phare et l'argent ?";
			link.l1 = "Nils : Et si c'était vrai ? Qu'est-ce que ça nous coמte de vérifier ? Nous avons la carte, et le temps.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "John : Hum. Et tu as raison, bon sang !";
			link.l1 = "Nils : Alors, mettons les voiles tout de suite, pourquoi perdre du temps.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "John : Hé, et qui est ce type ?";
			link.l1 = "Nils : De qui tu parles ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "John : Là-bas, celui qui se tient là, les yeux brillants.";
			link.l1 = "Nils : Il nous écoutait. Il nous a vus tuer Prenol. Achevons-le.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryBattleWithPrenolKillers");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
