// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//ОЗГ, Крыса
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
    			if (pchar.questTemp.Headhunter == "Rat" && pchar.questTemp.Headhunter.countC == 0)
	    		{
		    		link.l1 = "J'ai entendu dire qu'il n'y a pas si longtemps, un navire marchand avait disparu après avoir quitté votre port. Pouvez-vous m'en dire davantage ?";
			    	link.l1.go = "Rat_portmanC";
	    		}
			}
		break;

		//ОЗГ, Крыса
		case "Rat_portmanC":
			dialog.text = "Qu'y a-t-il à raconter ? Notre flמte Happy Bride a été chargée de santal à ras bord, elle a pris la mer, mais elle n'est jamais arrivée au port de destination. J'ai vu bien des histoires de ce genre au cours de mon service, et ça ne m'étonne plus.";
			link.l1 = "Pouvez-vous me dire quels navires, en dehors de la Happy Bride, ont quitté le port au même moment ?";
			link.l1.go = "Rat_portmanC_1";
		break;

		case "Rat_portmanC_1":
			dialog.text = "Je vais vous le dire, bien sמr. Voyons les registres... Le galion San Juan Nepomacedo et la pinasse Adelaide.";
			link.l1 = "Merci !";
			link.l1.go = "CheckC";
			pchar.questTemp.Headhunter.count = sti(pchar.questTemp.Headhunter.count) + 1;
			pchar.questTemp.Headhunter.countC = 1;
		break;

		case "CheckC":
			if(pchar.questTemp.Headhunter.count == 3)
			{
				pchar.questTemp.Headhunter = "Rat_Tavern";
				pchar.questTemp.Headhunter.Ratrumcity = npchar.city;
				AddQuestRecord("Headhunt", "13");
			}
			else
			{
				AddQuestRecord("Headhunt", "12_1");
			}
			DialogExit();
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}


