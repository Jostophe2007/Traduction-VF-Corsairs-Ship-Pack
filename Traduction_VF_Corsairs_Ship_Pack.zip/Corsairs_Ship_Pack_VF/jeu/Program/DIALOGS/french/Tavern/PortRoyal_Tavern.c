// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, j'avais oublié...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> Шестой квест английки, Моррис Уильямс
            if (pchar.questTemp.State == "MorrisWillams_ArrestedSeekInfo")
			{
                link.l1 = "Dites, quel genre d'homme est l'usurier d'ici ?";
                link.l1.go = "Step_E6_1";
			}
            // ==> Восьмой квест фр.линейки, отговорить трёх корсаров
            if (pchar.questTemp.State == "Fr8ThreeCorsairs_toSeek")
			{
                link.l1 = "Oם puis-je trouver le capitaine Gay ? J'ai une affaire importante à régler avec lui.";
                link.l1.go = "Step_F8_1";
			}
			if (pchar.questTemp.Slavetrader == "FindRatJamaica")
            {
                link.l1 = "Savez-vous oם je peux trouver François Gontier ?";
                link.l1.go = "Jamaica_ratP_1";
            }
		break;
        //********************** Английская линейка **********************
        case "Step_E6_1":
			dialog.text = "C'est un usurier, il n'y a pas de braves gens parmi eux.";
			link.l1 = "Avez-vous entendu quelque chose d'intéressant sur lui ?";
			link.l1.go = "Step_E6_2";
		break;
        case "Step_E6_2":
			dialog.text = "Non, rien de spécial.";
			link.l1 = "Et qui le connaît bien en ville ?";
			link.l1.go = "Step_E6_3";
		break;
        case "Step_E6_3":
			dialog.text = "Il ne fréquente pas vraiment personne, je ne peux rien vous dire.";
			link.l1 = "Eh bien, merci quand même.";
			link.l1.go = "exit";
			pchar.questTemp.State = "MorrisWillams_ArrestedSeekInfoFather";
		break;
		//********************** Французская линейка **********************
        case "Step_F8_1":
			dialog.text = NPCStringReactionRepeat("Le capitaine Gay ? Rien de plus facile. Il me loue une chambre, et il n'est pas encore sorti aujourd'hui, vous le trouverez donc sמrement là-haut.",
				          "J'ai déjà tout dit...", "Il n'y a rien à dire...", ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", laissez-moi faire mon travail !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, l'ami...", "Compris, désolé...", "Oui, c'est vrai...", "Oui, oui, désolé, l'ami...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
        break;

		case "Jamaica_ratP_1":
			dialog.text = NPCStringReactionRepeat("Aucune idée. C'est la première fois que j'entends ce nom.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Gontier.", "וcoutez, reculez et ne m'embêtez pas ! Vous avez perdu la boule ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Bon, jetons un œil.", "Eh bien...", "Oui, c'est vrai, je vous l'ai demandé...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

