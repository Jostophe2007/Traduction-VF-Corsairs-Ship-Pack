
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp;

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;
	if (CheckAttribute(pchar, "ReturnToLSC") && !CheckAttribute(NPChar, "MetAgain"))
	{
		NPChar.MetAgain = true;
		dialog.text = "Capitaine, vous avez donc survécu ? Je n'en crois pas mes yeux !";
		link.l1 = "Comme vous le voyez, padre."
		link.l1.go = "MetAgain1";
		return;
	}

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Rendez grâce à notre Seigneur Jésus-Christ pour votre salut ! Tant que la tempête n'est pas passée...";
					link.l1 = "Je rends grâce, padre, et je vous remercie de l'honneur qui m'est fait de prolonger ma misérable existence sur cette terre mortelle... Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
				else
				{
					dialog.text = "Louons notre Seigneur !";
					link.l1 = "Je rends grâce, padre, et je vous remercie de l'honneur qui m'est fait de prolonger ma misérable existence sur cette terre mortelle... Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que voulez-vous, "+ GetSexPhrase("mon fils", "ma fille") +" ?";
    			link.l1 = RandPhraseSimple("Je veux faire un don à la paroisse de la Cité, saint père.", "Je voudrais faire une offrande à la paroisse de la Cité, padre.");
    			link.l1.go = "donation";
				link.l2 = "Padre, je dois trouver un citoyen. Savez-vous oם il est en ce moment ?";
				link.l2.go = "SeekCitizen";
				link.l3 = "Je voudrais vous poser une question, saint père.";
				link.l3.go = "int_quests";
				квесты
				if (pchar.questTemp.LSC != "AdmiralIsWaiting" && !CheckAttribute(npchar, "quest.takeCandles"))
				{
					link.l4 = "Padre, puis-je faire quelque chose pour aider votre paroisse ?";
					link.l4.go = "askCandles";
				}
				if (CheckAttribute(npchar, "quest.takeCandles") && npchar.quest.takeCandles == "seek" && CheckCharacterItem(pchar, "mineral3"))
				{
					link.l4 = "Padre, je veux vous remettre les cierges.";
					link.l4.go = "takeCandles";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && !CheckAttribute(npchar, "quest.takeCandles"))
				{
					link.l8 = "Saint père, je voudrais savoir si je peux vous acheter certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(npchar, "quest.takeCandles") && npchar.quest.takeCandles == "seek")
				{
					link.l8 = "Saint père, je voudrais savoir si je peux vous acheter certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(npchar, "quest.takeCandles") && npchar.quest.takeCandles == "found")
				{
					link.l8 = "Saint père, je voudrais vous demander des médicaments.";
					link.l8.go = "FSeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Saint père, j'ai une proposition sérieuse à vous faire.";
					link.l8.go = "SeekCrew";
				}
				if (CheckAttribute(pchar, "ReturnToLSC"))
				{
					if (CheckAttribute(pchar, "Ship.Cargo.Goods.Medicament") && sti(pchar.Ship.Cargo.Goods.Medicament) > 0)
					{
						link.l9 = "Padre, j'ai apporté des médicaments : "+pchar.Ship.Cargo.Goods.Medicament+" unités";
						link.l9.go = "TradeMed";
					}
					if (CheckAttribute(pchar, "Ship.Cargo.Goods.Clothes") && sti(pchar.Ship.Cargo.Goods.Clothes) > 0)
					{
						link.l10 = "Padre, j'ai apporté des vêtements : "+pchar.Ship.Cargo.Goods.Clothes+" unités";
						link.l10.go = "TradeCloth";
					}
				}
				link.l11 = "Rien...";
				link.l11.go = "exit";
			}
		break;

		case "FT_1":
			dialog.text = "Je vois, "+ GetSexPhrase("mon fils", "ma fille") +", que votre âme est inquiète. Car on ne peut pas rejeter sur le Seigneur la faute de ses propres malheurs...";
			Link.l1 = "Saint père, expliquez-moi une chose toute simple. Nous remercions notre Seigneur pour tous les heureux tournants de la vie, mais nous n'avons pas le droit de lui reprocher nos malheurs. Comment est-ce possible, padre ?";
			Link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", êtes-vous sans péché ?";
			link.l1 = "Il n'y a pas d'homme sans péché !";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "C'est vrai. Notre berger mène son troupeau au milieu de nombreux filets. Dites-moi, observez-vous ses commandements ?";
			link.l1 = "Euh, je ne dirais pas ça...";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Alors pourquoi en voulez-vous au Seigneur, s'Il vous dit : « Fais ceci ! » et que vous ne le faites pas ? S'Il vous demande : « Ne fais pas cela ! », que faites-vous ?"+
				"Son troupeau est comme de jeunes fils désobéissant à leur père : chacun pense qu'il sait tout sur tout. Louez le Seigneur pour les bienfaits qui vous ont été accordés !";
			link.l1 = "Vous avez raison, mon père. Je remercie notre Seigneur pour mon salut.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Bien. Et ne blasphémez plus désormais !";
			link.l1 = "Je ne le ferai plus, padre.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! On vole !!! Arrêtez-le, il a enfreint la Loi !");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("Rangez votre arme, "+ GetSexPhrase("mon fils", "ma fille") +". דa rend un peu nerveux...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Rangez votre arme, cela ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je préfère chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Laissez-moi essayer de redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vu depuis un bon moment, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici : " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, saint père.", "Merci, padre !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, saint père.", "Merci, padre !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("mon fils", "ma fille") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Dites-moi, padre, comment êtes-vous arrivé ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l3 = "Dites-moi, padre, vous vivez ici depuis longtemps ?";
				link.l3.go = "ansewer_3";
			}
			link.l10 = "Pas de questions. Pardonnez-moi, mon père...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés. Je suis le seul ecclésiastique ici, et ma mission est de guider les citoyens de la Cité sur le droit chemin.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "J'ai quitté l'Ancien Monde pour prêcher la Parole de Dieu sur le nouveau continent, parmi les païens. Mais le Seigneur en a jugé autrement...";
			link.l1 = "Vous aussi, vous avez survécu au naufrage ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Hélas, oui. Les voies du Seigneur sont impénétrables.";
			link.l1 = "C'est exact.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Non, pas depuis très longtemps.";
			link.l1 = "Je vois... Connaissez-vous des anciens ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Peu m'importe quand un paroissien est arrivé ici. L'essentiel, c'est que tous les citoyens sont maintenant ici, dans mon troupeau.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
		break;
		//Исповедь
		case "donation":
			if (startherotype != 2 || IsEquipCharacterByItem(pchar, "glasses"))
			{
			dialog.Text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +". Combien voulez-vous donner pour expier vos péchés ?";
			Link.l1 = "Pardonnez-moi, mon père, j'ai changé d'avis. Je suis un peu à court d'argent...";
			Link.l1.go = "No donation";
			Link.l2 = "Laissez-moi réfléchir...";
			link.l2.go = "donate_input";
			}
			else
			{
				dialog.Text = "Inutile. Votre seule présence ici vaut déjà plus que n'importe quelle somme.";
				Link.l1 = "Comme vous voudrez. Alors, une autre question...";
				Link.l1.go = "First time";

			}
		break;

		case "No donation":
			dialog.Text = "Hum, les paroissiens de la Cité n'en seront pas ravis...";
			Link.l1 = "Bon, ce n'est rien. Excusez-moi, mon père, je dois y aller.";
			Link.l1.go = "First time";
			Link.l2 = "Pardon, saint père, je dois y aller.";
			Link.l2.go = "exit";
		break;

		case "donate_input":
			dialog.Text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +". Combien voulez-vous donner pour expier vos péchés ?";
			Link.l1.edit = 1;
			link.l1 = " ";
			link.l1.go = "donation_thank_you";
		break;

		case "donation_thank_you":
			int iDonation = sti(dialogEditStrings[1]);
			if(iDonation > sti(pchar.money) || iDonation <= 0)
			{
				dialog.text = "Oh, " + GetSexPhrase("mon fils", "ma fille") + ", je vois que vous n'avez pas assez d'argent...";
				link.l1 = "Vous avez raison, mon père, je vais changer la somme."
				link.l1.go = "donate_input";
				link.l2 = "Vous savez, j'ai changé d'avis.";
				link.l2.go = "exit";
			}
			else
			{
				dialog.Text = "Au nom de la Sainte וglise, merci, "+ GetSexPhrase("mon fils", "ma fille") +", pour votre don.";
				int iRepIncr = iDonation / 5000;
				ChangeCharacterReputation(pchar, iRepIncr);
				AddMoneyToCharacter(pchar, -iDonation);
				Link.l1 = "J'ai besoin de vous parler, mon père.";
				Link.l1.go = "First time";
				Link.l2 = "Excusez-moi, mon père, je dois y aller.";
				Link.l2.go = "exit";
			}
		break;

		//достать свечки
		case "askCandles":
			dialog.text = "Oui, "+ GetSexPhrase("mon fils", "ma fille") +". La paroisse a besoin de cierges, et cela fait longtemps que notre Cité n'en a pas reçu. Aidez-moi, apportez-moi 400 cierges.";
			link.l1 = "Et oם puis-je en trouver ?";
			link.l1.go = "askCandles_1";
		break;
		case "askCandles_1":
			dialog.text = "Si je savais oם en trouver, j'irais les chercher moi-même. Cherchez, "+ GetSexPhrase("mon fils", "ma fille") +".";
			link.l1 = "Hum... Bon, d'accord, saint père, je vais chercher...";
			link.l1.go = "askCandles_2";
		break;
		case "askCandles_2":
			dialog.text = "Cherchez avec zèle, "+ GetSexPhrase("mon fils", "ma fille") +", la récompense sera à la hauteur.";
			link.l1 = "Je comprends, padre. Tout sera fait.";
			link.l1.go = "exit";
			npchar.quest.takeCandles = "seek";
			npchar.quest.takeCandles.Qty = 0; //кол-во свечей
			AddQuestRecord("ISS_takeCandles", "1");
		break;

		case "takeCandles":
			iTemp = GetCharacterItem(pchar, "mineral3");
			npchar.quest.takeCandles.Qty = sti(npchar.quest.takeCandles.Qty) + iTemp;
			DeleteAttribute(pchar, "items.mineral3");
			if (sti(npchar.quest.takeCandles.Qty) < 400)
			{
				dialog.text = "Bon, voyons. Cette fois, vous en avez apporté"+ GetSexPhrase("", "") +" " + FindRussianQtyString(iTemp) + " cierges. En tout, vous en avez apporté"+ GetSexPhrase("", "") +" " + FindRussianQtyString(sti(npchar.quest.takeCandles.Qty)) + " cierges. Il vous en reste encore à apporter " + FindRussianQtyString(400 - sti(npchar.quest.takeCandles.Qty)) + ".";
				link.l1 = "Compris. Eh bien, je vais continuer à chercher, mon père.";
				link.l1.go = "exit";
				AddQuestRecord("ISS_takeCandles", "2");
				AddQuestUserData("ISS_takeCandles", "iQty", 400 - sti(npchar.quest.takeCandles.Qty));
			}
			else
			{
				dialog.text = "Parfait, vous avez accompli la tâche, "+ GetSexPhrase("mon fils", "ma fille") +". Nous avons maintenant assez de cierges pour les offices pour longtemps.";
				link.l1 = "C'est une joie d'avoir pu aider la paroisse. Saint père, et la récompense pour mes efforts ?";
				link.l1.go = "takeCandles_ok";
			}
		break;
		case "takeCandles_ok":
			dialog.text = "Oui, bien sמr, comme promis. Je pense que ce livre sur Dame Fortune vous sera plus utile qu'à moi. Allez, "+ GetSexPhrase("mon fils", "ma fille") +".";
			link.l1 = "Oui, padre, merci. Même si on ne voit pas bien pourquoi...";
			link.l1.go = "exit";
			TakeNItems(pchar, "book3_6",1);
			log_info("De quoi parlez-vous, ");
			npchar.quest.takeCandles = "found";
			AddQuestRecord("ISS_takeCandles", "3");
			CloseQuestHeader("ISS_takeCandles");
		break;
		//поиск товаров на корвет не принеся свечи
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("De quoi parlez-vous, "+ GetSexPhrase("mon fils", "ma fille") +" ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                ""+ GetSexPhrase("Mon fils", "Ma fille") +", ça suffit...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de boulets, de boulets ramés, de vivres, de poudre, d'armes, de médicaments...",
				"Oui... Pardon, ça m'était sorti de la tête.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Des médicaments ? Vous souffrez ?";
			link.l1 = "Non, saint père... J'ai besoin de médicaments, de beaucoup de médicaments pour des gens.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Hum, j'ai des médicaments. Seulement, pour commencer, rendez-moi un service, "+ GetSexPhrase("mon fils", "ma fille") +". Je parle des cierges.";
			link.l1 = "Des cierges ?";
			link.l1.go = "askCandles";
		break;
		//поиск товаров на корвет не принеся свечи
		case "FSeekGoods":
			dialog.text = NPCStringReactionRepeat("Combien ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                ""+ GetSexPhrase("Mon fils", "Ma fille") +", ça suffit...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("50 paquets devraient suffire.",
				"Oui... Pardon, j'avais oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("FSeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "FSeekGoods_1":
			dialog.text = "Que voulez-vous, "+ GetSexPhrase("mon fils", "ma fille") +" ?";
			link.l1 = "Hélas, saint père, je ne peux pas encore le dire.";
			link.l1.go = "FSeekGoods_2";
		break;
		case "FSeekGoods_2":
			dialog.text = "Bon, je ne suis pas curieux, car c'est un péché... Vous pouvez prendre chez moi le lot de médicaments dont vous avez besoin. Vous m'avez aidé autrefois, maintenant, c'est moi qui vous aide.";
			link.l1 = "Merci, padre ! C'est peut-être trop demander, mais ne pourriez-vous pas faire livrer ces médicaments au San Gabriel ?";
			link.l1.go = "FSeekGoods_3";
		break;
		case "FSeekGoods_3":
			dialog.text = "D'accord. Allez en paix, "+ GetSexPhrase("mon fils", "ma fille") +". Les paroissiens feront tout.";
			link.l1 = "Merci beaucoup, saint père !";
			link.l1.go = "exit";
			AddCharacterGoods(pchar, GOOD_MEDICAMENT, 50);
			AddQuestRecord("ISS_MainLine", "47");
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("De quoi s'agit-il, "+ GetSexPhrase("mon fils", "ma fille") +" ?",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois, "+ GetSexPhrase("mon fils", "ma fille") +".",
                "Oh, "+ GetSexPhrase("mon fils", "ma fille") +", vous me fatiguez...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je recrute un équipage pour mon navire et je vous invite à vous joindre à moi.",
				"D'accord...",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Hum, vraiment ? Merci pour la proposition, mais je ne peux pas abandonner les fidèles de la Cité.";
			link.l1 = "Saint père, il ne restera bientכt plus rien de la Cité.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Que Dieu vous garde, "+ GetSexPhrase("mon fils", "ma fille") +". Moi, je reste.";
			link.l1 = "Eh bien, comme vous voudrez, saint père.";
			link.l1.go = "exit";
		break;
		case "MetAgain1":
			dialog.text = "La Providence divine, il n'y a pas d'autre explication. Ce lieu lui-même a décidé de vous laisser partir, vous et ceux qui ont choisi de vous suivre.";
			link.l1 = "Je mettrais tout ça sur le compte de la chance, padre, mais je ne vais pas discuter avec vous.";
			link.l1.go = "MetAgain2";
		break;
		case "MetAgain2":
			dialog.text = "Au fait, pourquoi avez-vous décidé de revenir, capitaine ?";
			link.l1 = "Sachant que l'île est isolée et que peu de gens connaissent son existence, j'ai décidé de vous proposer mes services pour l'importation de marchandises de première nécessité, et d'autres moins nécessaires. Par exemple, des médicaments, des vivres et des vêtements.";
			link.l1.go = "MetAgain3";
		break;
		case "MetAgain3":
			dialog.text = "C'est une bonne idée. Pour les vivres, vous feriez mieux d'aller à notre taverne, sur le Fleuron. Mais les médicaments et les vêtements ne seront pas de trop.";
			link.l1 = "Bon, maintenant, je sais ce que je peux vous apporter. א bientכt !";
			link.l1.go = "exit";
		break;
		case "TradeMed":
			dialog.text = "Quelle quantité nous en avez-vous apporté ?";
			Link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "TradeMed2";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeMed2":
			npchar.amount = GetStrSmallRegister(dialogEditStrings[1]);
			npchar.amount = func_min((sti(npchar.amount),sti(pchar.Ship.Cargo.Goods.Medicament));//фикс, нельзя продать больше, чем привёз
			npchar.amount = func_max((sti(npchar.amount),1);
			NPChar.sumtotal = sti(npchar.amount)*10;
			dialog.text = "Je prends les médicaments à 10 pièces l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
			link.l1 = "Oui.";
			link.l1.go = "TradeMed3";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeMed3":
			pchar.Ship.Cargo.Goods.Medicament = sti(pchar.Ship.Cargo.Goods.Medicament)-sti(npchar.amount);
			dialog.text = "Merci, capitaine !";
			AddCharacterExpToSkill(pchar, "Commerce", sti(NPChar.sumtotal) / 2000.0);
			ChangeCharacterReputation(pchar, sti(NPChar.sumtotal) / 10000.0);
			AddMoneyToCharacter(pchar, sti(NPChar.sumtotal));
			link.l1 = "Avec plaisir. א bientכt !";
			link.l1.go = "exit";
		break;
		case "TradeCloth":
			dialog.text = "Quelle quantité nous en avez-vous apporté ?";
			Link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "TradeCloth2";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeCloth2":
			npchar.amount = GetStrSmallRegister(dialogEditStrings[1]);
			npchar.amount = func_min((sti(npchar.amount),sti(pchar.Ship.Cargo.Goods.Clothes));//фикс, нельзя продать больше, чем привёз
			npchar.amount = func_max((sti(npchar.amount),1);
			NPChar.sumtotal = sti(npchar.amount)*5;
			dialog.text = "Je prends les vêtements à 5 pièces l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
			link.l1 = "Oui.";
			link.l1.go = "TradeCloth3";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeCloth3":
			pchar.Ship.Cargo.Goods.Clothes = sti(pchar.Ship.Cargo.Goods.Clothes)-sti(npchar.amount);
			dialog.text = "Merci, capitaine !";
			AddCharacterExpToSkill(pchar, "Commerce", sti(NPChar.sumtotal) / 2000.0);
			ChangeCharacterReputation(pchar, sti(NPChar.sumtotal) / 10000.0);
			AddMoneyToCharacter(pchar, sti(NPChar.sumtotal));
			link.l1 = "Avec plaisir. א bientכt !";
			link.l1.go = "exit";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
