
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	int z;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//Багамы. На выходе с глобалки запись в СЖ «‘Морж’ и «Рейнджер» стоят на рейде, подойду к ним и вышлю шлюпку». Собственно поставить туда Моржа и Рейнджера. Не забыть про чёрный флаг иначе файт со всеми и провал квеста.
		//Высаживаемся. Сильвер, Флинт, Вейн, Рекхэм, Бонни

		case "BS_PN_shipF":	//Флинт
			NextDiag.TempNode = "BS_PN_shipF";
			dialog.text = "Vous voilà enfin. Accostons ici, dans la baie des Corsaires. Nous poursuivrons cette conversation à terre.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;

		case "BS_PN_shipV":	//Вейн
			NextDiag.TempNode = "BS_PN_shipV";
			dialog.text = "Je vois que tu es déjà là. Flint a convoqué une réunion sur la plage, dans la baie des Corsaires ; on se retrouve là-bas.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;

		case "BS_PN_1":	//Флинт
			dialog.text = "M. Vane nous a brièvement raconté vos aventures.";
			link.l1 = "Oui, la rencontre a été mouvementée !";
			link.l1.go = "BS_PN_1_1";
		break;

		case "BS_PN_1_1":	//Флинт
			dialog.text = "John, mets-toi au déchiffrement, le temps presse.";
			link.l1 = "...";
			link.l1.go = "BS_PN_2exit";
		break;

		case "BS_PN_2exit":
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", 10);
			sld = CharacterFromID("BS_Vein");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_2";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		//Сильвер уходит в таверну 6.04.2023

		case "BS_PN_2":	//Вейн
			dialog.text = "Je vous présente mes compagnons. Jack Rackham et Anne Bonny. Un couple inséparable. Jack est un garçon malin, et j'insiste pour qu'il aide M. Silver à déchiffrer. La jolie Anne et ses poignards resteront avec nous.";
			link.l1 = "...";
			link.l1.go = "BS_PN_3exit";
		break;

		case "BS_PN_3exit":
			sld = CharacterFromID("BS_Bony");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_3";
			DialogExit();
			DoQuestFunctionDelay("BonySpeech", 0);
		break;

		case "BS_PN_3":	//Энн
			dialog.text = "Traite-moi encore une fois de jolie, Charles, et ne t'étonne pas si tu trouves un couteau planté dans ton dos.";
			link.l1 = "...";
			link.l1.go = "BS_PN_4exit";
		break;

		case "BS_PN_4exit":
			sld = CharacterFromID("BS_Vein");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_4";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_4":	//Вейн
			dialog.text = "Ne t'énerve pas, ma belle. Passons aux affaires.";
			link.l1 = "...";
			link.l1.go = "BS_PN_5exit";
		break;

		case "BS_PN_5exit":
			sld = CharacterFromID("BS_Rakham");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_5";
			DialogExit();
			DoQuestFunctionDelay("RakhamSpeech", 0);
		break;

		case "BS_PN_5":	//Рекхэм
			dialog.text = "Oui, sois sage pendant mon absence.";
			link.l1 = "...";
			link.l1.go = "BS_PN_6exit";
		break;

		case "BS_PN_6exit":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", 10);
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_6";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		//Рекхэм уходит таверну 6.04.2023

		case "BS_PN_6":	//Флинт
			dialog.text = "La rencontre avec la patrouille anglaise près de Nassau n'était pas un hasard. J'ai encore été attaqué deux fois par des militaires anglais avant d'arriver ici.";
			link.l1 = "...";
			link.l1.go = "BS_PN_7exit";
		break;

		case "BS_PN_7exit":
			sld = CharacterFromID("BS_Vein");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_7";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_7":	//Вейн
			dialog.text = "Nous aussi, une frégate nous a pris en chasse près de la Dominique, mais le Ranger l'a facilement semée.";
			link.l1 = "Moi, je n'ai pas croisé d'Anglais.";
			link.l1.go = "BS_PN_8exit";
		break;

		case "BS_PN_8exit":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_8";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_8":	//Флинт
			dialog.text = "Je soupçonne que mon second, Billy Bones, aurait pu éclaircir la situation, mais il a disparu comme par enchantement pendant son quart.";
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_17_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
			else
			{
				link.l1 = "Qu'est-ce que... ?!";
				link.l1.go = "BS_PN_9exit";
			}
		break;

		case "BS_PN_8_1":	//Флинт
			link.l1 = "Qu'est-ce que... ?!";
			link.l1.go = "BS_PN_9exit";
		break;

		//Аларм «К оружию!» Нападает толпа англичан из перехода в джунгли. Файт 6.04.23

		//По окончанию

		case "BS_PN_9exit":
			DialogExit();
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			sld = CharacterFromID("BS_Vein");
			LAi_SetWarriorTypeNoGroup(sld);
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			sld = CharacterFromID("BS_Bony");
			LAi_SetWarriorTypeNoGroup(sld);
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			BSChaseBegun_shore_fight();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "BS_PN_9":	//Вейн
			dialog.text = "Qu'est-ce que c'est que ça ? Encore les Anglais ! D'oם diable sortent-ils ?!";
			link.l1 = "...";
			link.l1.go = "BS_PN_10exit";
		break;

		case "BS_PN_10exit":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_10";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_10":	//Флинт
			dialog.text = "Ce n'est plus une patrouille ordinaire ! Ils ont débarqué dans l'une des criques.";
			link.l1 = "...";
			link.l1.go = "BS_PN_11exit";
		break;

		case "BS_PN_11exit":
			sld = CharacterFromID("BS_Vein");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_11";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_11":	//Вейн
			dialog.text = "Alors nous allons ratisser la jungle et les criques.";
			link.l1 = "Et il faut que quelqu'un trouve leur navire, ou leurs navires : ils ne se sont quand même pas cachés dans des grottes pendant tout ce temps !";
			link.l1.go = "BS_PN_12exit";
			NextDiag.TempNode = "BS_PN_11_loop";
			NextDiag.CurrentNode = "BS_PN_11_loop";
		break;

		case "BS_PN_12exit":
			NextDiag.TempNode = "BS_PN_11_loop";
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_12";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_12":	//Флинт
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable("Shore69", "reload1_back", true);
			InterfaceStates.Buttons.Save.enable = true;
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Flint", pchar.location, false);
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Vein", pchar.location, false);
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Silver", pchar.location, false);
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Bony", pchar.location, false);
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Rakham", pchar.location, false);
			AddQuestRecord("BSChaseBegun", "2");
			dialog.text = "Je prends le Walrus et je bloque le port. Vane, prends tes hommes et ratisse la jungle autour de la ville.\n"+
							""+pchar.name+", prends la mer et trouve leurs transports. Coule-les ou aborde-les. א toi de voir !";
			link.l1 = "א vos ordres, j'y vais !";
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_PN_12_loop";
		break;

		case "BS_PN_12_loop":	//Флинт
			dialog.text = "Pas de temps à perdre. Donne l'ordre de hisser les voiles !";
			link.l1 = "D'accord, j'arrive.";
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_PN_12_loop";
		break;

		case "BS_PN_11_loop":	//Флинт
			dialog.text = "Laisse-moi une minute pour reprendre mon souffle, rassembler mes hommes, et j'y vais.";
			link.l1 = "Moi aussi.";
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_PN_11_loop";
		break;

		//Запись в СЖ «Встреча компаньонов закончилась резнёй. Целая рота английских солдат ворвалась в город. Флинт раздал команды, моя задача потопить корабль или корабли, которые привезли этих солдат. За дело! 6.04.2023

		//часть с Алексусом и подземкой уже не нужна. вырезаем всё это
		//ставим напротив бухты Приватиров что-нибудь большое и пару корветов охранения. морской файт 6.04.2023

		case "BS_PN_13_1":
			dialog.text = RandPhraseSimple("Arrêtez de me barrer la route, dégagez.", "Vous savez quoi ? N'aboyez pas !");
			link.l1 = RandPhraseSimple("Modérez votre ardeur. Sinon, je vais vite la refroidir !", "Capitaine ! Vous tombez bien ! Regardez, j'ai inventé une nouvelle façon de fixer la voile d'étai ! דa va faire sensation chez les constructeurs de navires !");
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_PN_13_1";
		break;

		case "BS_PN_13":	//Алексус
			dialog.text = "Pardon, maître, ce n'est pas le moment pour les voiles d'étai. Qu'est-ce qui se passe ici ? Les hommes de Jackman tirent sur tout ce qui bouge !";
			link.l1 = "Ce qui se passe ? Il y a toujours quelqu'un qui tire sur quelqu'un, ici. Pas moyen d'avoir la paix, pour un vieil homme ! Regardez, je peux revoir le système de poulies de la corne, et on pourra la manœuvrer littéralement d'une seule main !";
			link.l1.go = "BS_PN_14";
		break;

		case "BS_PN_14":
			AddQuestRecord("BSChaseBegun", "3");
			LocatorReloadEnterDisable("Pirates_Shipyard", "reload1_back", false);
			dialog.text = "Plus tard, maître. Nous ne vous dérangerons pas plus longtemps !";
			link.l1 = "דa, c'est une affaire ! Juste ce qu'il me faut !";
			link.l1.go = "BS_PN_14_1";

			NPChar.Dialog.Filename = "Common_Shipyard.c";
			NPChar.Dialog.CurrentNode = "Second time";

			PChar.quest.BSChaseBegun_town.win_condition.l1 = "location";
			PChar.quest.BSChaseBegun_town.win_condition.l1.location = "Pirates_Town";
			PChar.quest.BSChaseBegun_town.function = "BSChaseBegun_town";
		break;

		case "BS_PN_14_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_19_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;

		//Запись в СЖ: «Транспорты и сопровождени англичан потопленны. Пора на берег» 6.04.2023

		//Причаливаем. Бой окончен. На земле горы трупов в разнобой англичане и пираты. Флинт, Вейн, Бонни - стоят напротив дома Гатри. бродят несколько «наших» пиратов.6.04.2023

		case "BS_PN_15":	//Вейн
			chrDisableReloadToLocation = false
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "BS_PN_15_1";
		break;

		case "BS_PN_15_1":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_16";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_16":	//Флинт
			dialog.text = "La maison est barricadée, nous nous préparons à l'assaut.";
			link.l1 = "...";
			link.l1.go = "BS_PN_16_1";
		break;

		case "BS_PN_16_1":
			sld = CharacterFromID("BS_Bony");
			LAi_SetStayTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_16_2";
			DialogExit();
			DoQuestFunctionDelay("BonySpeech", 0);
		break;

		case "BS_PN_16_2":
			dialog.text = "Attends, on dirait qu'ils ouvrent la porte.";
			link.l1 = "...";
			link.l1.go = "BS_PN_16exit";
		break;

		case "BS_PN_16exit":
			DialogExit();
			sld = CharacterFromID("gatri_home_grunt1");
			ChangeCharacterAddressGroup(sld, "Nassau_town", "officers", "houseS1_3");
			LAi_ActorTurnToCharacter(sld, PChar);
			sld = CharacterFromID("Gatri_temp");
			ChangeCharacterAddressGroup(sld, "Nassau_town", "reload", "houseS1");
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_17";
			LAi_SetStayTypeNoGroup(sld);
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		//Идём к резиденции, из неё выходит Гатри и несколько мушкетчиков.

		case "BS_PN_17":	//Гатри
			dialog.text = "James ! Et Charles... Eh bien, vous arrivez à point nommé. Les Anglais ont décidé de me chasser de mon île ! Il faut que j'écrive une ou deux lettres à mon grand-père, ils ne s'en tireront pas comme ça ! Ils ne savent pas encore à qui ils ont affaire !";
			link.l1 = "...";
			link.l1.go = "BS_PN_17_1";
		break;

		case "BS_PN_17_1":
			sld = CharacterFromID("Flint");
			LAi_SetStayTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_18";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_18":	//Флинт
			dialog.text = "Nous avons la page chiffrée avec l'itinéraire, et Silver et Rackham sont occupés à la déchiffrer. Nous devons régler les problèmes du moment. Les Anglais se mêlent obstinément de nos affaires, et ça n'a rien à voir avec ton île, Eleanor ! Je sais comment opère la marine, et ce ne sont pas ses méthodes. Et ça me met hors de moi de ne pas encore savoir qui est derrière tout ça.";
			link.l1 = "...";
			link.l1.go = "BS_PN_18_1";
		break;

		case "BS_PN_18_1":
			sld = CharacterFromID("BS_Vein");
			LAi_SetStayTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_19";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_19":	//Вейн
			dialog.text = "Il y a sמrement des survivants. Je peux les interroger, à ma manière.";
			link.l1 = "...";
			link.l1.go = "BS_PN_19_1";
		break;

		case "BS_PN_19_1":
			sld = CharacterFromID("gatri_temp");
			LAi_SetStayTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_20";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_PN_20":	//Гатри
			dialog.text = "דa peut attendre. Il faut faire le ménage ici. Nous parlerons plus tard, à ma résidence.";
			link.l1 = "...";
			link.l1.go = "BS_PN_20exit";
		break;

		case "BS_PN_20exit":	//Гатри
			DialogExit();
			LAi_MethodDelay("BSChaseBegun_FewDeaysLater",0.1);
			PChar.quest.BSChaseBegun_townhall.win_condition.l1 = "location";
			PChar.quest.BSChaseBegun_townhall.win_condition.l1.location = "Nassau_OfisGatri";
			PChar.quest.BSChaseBegun_townhall.function = "BSChaseBegun_townhall";
		break;

		//Картинка «На следующий день» убираем трупы, перемещаем ГГ, Флинта, Вейна, Гатри, Сильвера и Рекхэма в дом Гатри. 6.04.2023

		case "BS_PN_21":	//Сильвер
			dialog.text = "Alors, messieurs, l'Urca de Lima, à en juger par le déchiffrement, est déjà à La Havane. Là, elle embarquera deux compagnies d'infanterie de marine et, escortée de quatre navires de guerre, elle fera voile vers Porto Rico, oם deux autres navires d'escorte rejoindront l'escadre. Après quoi, toute l'armada partira pour l'Europe.";
			link.l1 = "...";
			link.l1.go = "BS_PN_21_1";
		break;

		case "BS_PN_21_1":
			sld = CharacterFromID("Flint");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_22";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_22":	//Флинт
			dialog.text = "Quel itinéraire l'escadre prendra-t-elle depuis La Havane ?";
			link.l1 = "...";
			link.l1.go = "BS_PN_22_1";
		break;

		case "BS_PN_22_1":
			sld = CharacterFromID("BS_Silver");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_23";
			DialogExit();
			DoQuestFunctionDelay("SilverSpeech", 0);
		break;

		case "BS_PN_23":	//Сильвер
			dialog.text = "Celui du sud. Vers le cap San Antonio, et de là vers l'est, en évitant les eaux françaises. Aucune escale n'est prévue à Santo Domingo, mais on ne peut pas l'exclure. Il y a des notes à ce sujet dans le texte. En cas de tempête ou d'autres ennuis. Ensuite vers San Juan, puis Saint-Martin, et l'océan.";
			link.l1 = "...";
			link.l1.go = "BS_PN_23_1";
		break;

		case "BS_PN_23_1":
			sld = CharacterFromID("gatri_temp");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_24";
			DialogExit();
			DoQuestFunctionDelay("GatriSpeech", 0);
		break;

		case "BS_PN_24":	//Гатри
			dialog.text = "Des contrebandiers ont signalé que la peste sévit à Santo Domingo ; l'escadre espagnole passera très probablement devant la ville sans s'arrêter.";
			link.l1 = "...";
			link.l1.go = "BS_PN_24_1";
		break;

		case "BS_PN_24_1":
			sld = CharacterFromID("Flint");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_25";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_25":	//Флинт
			dialog.text = "Alors, droit sur San Juan. Vane, j'ai un travail pour toi. Trouve, ici ou à Puerto Príncipe, quelques coupe-jarrets cinglés avec deux ou trois sloops, et filez sans perdre une minute vers la cכte nord des Caïmans. Mission : croiser près du cap San Antonio et, dès que vous repérerez le mouvement de l'escadre, attaquer les navires d'escorte. Ne pas engager le combat, mais fuir à toutes voiles.";
			link.l1 = "...";
			link.l1.go = "BS_PN_25_1";
		break;

		case "BS_PN_25_1":
			sld = CharacterFromID("BS_Vein");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_26";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_26":	//Вейн
			dialog.text = "Je comprends. Les belliqueux Espagnols voudront jouer les fiers-à-bras et me prendront en chasse.";
			link.l1 = "...";
			link.l1.go = "BS_PN_26_1";
		break;

		case "BS_PN_26_1":
			sld = CharacterFromID("Flint");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_27";
			DialogExit();
			DoQuestFunctionDelay("FlintSpeech", 0);
		break;

		case "BS_PN_27":	//Флинт
			dialog.text = "Exactement, et tu attireras la poursuite jusqu'au récif du Squelette, oם leurs navires se fracasseront sur les rochers, après quoi ils retourneront à La Havane pour réparer.";
			link.l1 = "Et pendant ce temps, nous attaquons l'Urca ? Oם ?";
			link.l1.go = "BS_PN_27_2";
		break;

		case "BS_PN_27_2":	//Флинт
			npchar.nation = PIRATE;
			dialog.text = "Juste sous les yeux de la garnison de Santo Domingo, mais hors de portée de ses canons ! א cause de la quarantaine, ils ne pourront rien faire pour aider l'Urca.";
			link.l1 = "...";
			link.l1.go = "BS_PN_27_1";
		break;

		case "BS_PN_27_1":
			sld = CharacterFromID("BS_Vein");
			LAi_SetSitTypeNoGroup(sld);
			LAi_SetImmortal(sld, true);
			sld.dialog.filename = "Quest\BlackSails\Pogonya_Nachalas.c";
			sld.dialog.currentnode = "BS_PN_28";
			DialogExit();
			DoQuestFunctionDelay("VeinSpeech", 0);
		break;

		case "BS_PN_28":	//Вейн
			AddQuestRecord("BSChaseBegun", "4");
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable(pchar.location.from_sea, "boat", false);
			dialog.text = "J'y serai. Après avoir envoyé les garde-cכtes sur les récifs.";
			link.l1 = "Alors, au travail !";
			link.l1.go = "BS_PN_28exit";
		break;

		case "BS_PN_28exit":		
			PChar.quest.BSChaseBegun_lock_townhall.win_condition.l1 = "location";
			PChar.quest.BSChaseBegun_lock_townhall.win_condition.l1.location = "Nassau_town";
			PChar.quest.BSChaseBegun_lock_townhall.function = "BSChaseBegun_lock_townhall";
			DeleteAttribute(PChar, "currentsoundtrack");
			DeleteAttribute(PChar, "BS_permanentblackflag");
			Flag_Change(PIRATE);
			LAi_SetPlayerType(PChar);
			DoReloadCharacterToLocation("Nassau_town", "reload", "houseS1");
			DialogExit();
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;

		//Запись в СЖ: 'Самоубийственный план, как по мне. Но больше возможностей взять золотишко не будет. Выдвигаюсь, как только буду готов(ва). Вейн займётся выманиванием охраны, Флинт выдвинется раньше и станет вне видимости форта на якорь. Дело за мной'.

		//Двигаем в локацию Санто-Доминго. Морж уже там далеко от форта. На всякий убрать сторожей местных и мелочь, чтоб не было содомии. Подходим к Моржу, спаун испанцев. Урки среди них нет. Штук 8 военных. Мясо.

		//Запись в СЖ: 'Где чёртов галеон? Нужно поговорить с Флинтом на его корабле! Вейна тоже невидно, что–то пошло не так.'

		//Высылаем шлюпу на Моржа. Говорим с Флинтом

		case "BS_PN_30_seabattle":	//Флинт
			PChar.quest.BSChaseBegun_EndQuest.win_condition.l1 = "location";
			PChar.quest.BSChaseBegun_EndQuest.win_condition.l1.location = "Nassau_Town";
			PChar.quest.BSChaseBegun_EndQuest.function = "BSChaseBegun_EndQuest";
			if (Group_isDead("BSChaseBegun_SeaBattle"))
			{
				if (!CheckCompanionInCharacter(pchar, npchar.id)){BS_ChaseBegun_WithFlintToNassau();}
				dialog.text = "C'est trop dangereux de rester ici. Nous parlerons à Nassau.";
				link.l1 = "Vous avez raison. Suivez mon navire.";
			}
			else
			{
				dialog.text = "Nous parlerons plus tard ! D'abord, aide-moi à en finir avec les Espagnols.";
				link.l1 = "דa peut se faire !";
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_PN_30_seabattle";
			Flag_Change(PIRATE);
		break;

		case "BS_PN_30":	//Флинт
			dialog.text = "...";
			link.l1 = "On dirait que le plan a échoué ! Soit Silver a menti, soit les Espagnols ont été plus malins !";
			link.l1.go = "BS_PN_31";
		break;

		case "BS_PN_31":
			AddQuestRecord("BSChaseBegun", "6");
			LAi_SetImmortal(npchar, true);
			DeleteAttribute(Colonies[FindColony("SantoDomingo")], "DontSetShipInPort");
			DeleteAttribute(Colonies[FindColony("SantoDomingo")], "BSChaseBegun");
			dialog.text = "Je parlerai à Silver. Pour l'instant, nous devons nous faire oublier. Rendez-vous aux Bahamas. Cherche des pistes par tes propres canaux, je chercherai par les miens. Mon instinct me dit que l'Urca est toujours dans les Caraïbes. La question est : oם ?";
			link.l1 = "J'ai une petite colombe en vue, je vais voir ce qu'elle me chantera.";
			link.l1.go = "BS_PN_32";
		break;

		case "BS_PN_32":
			chrDisableReloadToLocation = false;
			LAi_SetActorTypeNoGroup(npchar);
			dialog.text = "Nous devrions nous séparer pour l'instant ; nous parlerons plus tard.";
			link.l1 = "Bien d'accord.";
			link.l1.go = "BS_PN_32exit";
		break;

		case "BS_PN_32exit":
			DialogExit();
			LAi_ActorGoToLocation(npchar, "reload", "reload3_back", "none", "", "", "", 20);
			BS_ReplaceHostessWithMaks();
			sld = CharacterFromID("PortRoyal_hostess");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode = "BS_NU_1";
			BSBons_SeaBattle(false);
			SetFunctionExitFromLocationCondition("BS_EmptyAdress_Flint", pchar.location, false);
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_1_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;

		//Запись в СЖ: «Любой план летит к чертям, как только возьмёшься за его реализацию. Но ещё не всё потерянно! Навещу-ка я Максин в Порт Рояле, портовые девки много чего знают, а эта мне обязана. Долг - платежом красен».

	}
}
