# -*- coding: utf-8 -*-
"""Parser/writer for Storm-engine font ini files (fonts_eng.ini ...)."""
import re
from collections import OrderedDict

SEC_RE = re.compile(r'^\s*\[(.+?)\]\s*$')
CHAR_RE = re.compile(r'^\s*char_(.+?)\s*=\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)')
KV_RE = re.compile(r'^\s*([A-Za-z_]+)\s*=\s*([^;]*)')


def key_to_char(k):
    """'a_' -> 'a', 'A' -> 'A', 'equ' -> '=' ; others unchanged."""
    if len(k) == 2 and k.endswith('_') and k[0].isalpha() and k[0].islower():
        return k[0]
    if k == 'equ':
        return '='
    return k


def char_to_key(c):
    if len(c) == 1 and 'a' <= c <= 'z':
        return c + '_'
    if c == '=':
        return 'equ'
    return c


class Section:
    def __init__(self, name):
        self.name = name
        self.lines = []          # raw lines (without the [header])
        self.props = {}
        self.chars = OrderedDict()  # char (real) -> (x,y,w,h)

    def prop(self, k, default=None):
        return self.props.get(k.lower(), default)


class FontIni:
    def __init__(self, path):
        self.path = path
        raw = open(path, 'rb').read().decode('utf-8-sig')
        self.head = []
        self.sections = OrderedDict()
        cur = None
        for line in raw.splitlines():
            m = SEC_RE.match(line)
            if m:
                cur = Section(m.group(1))
                self.sections[cur.name] = cur
                continue
            if cur is None:
                self.head.append(line)
                continue
            cur.lines.append(line)
            s = line.strip()
            if s.startswith(';'):
                continue
            m = CHAR_RE.match(line)
            if m:
                cur.chars[key_to_char(m.group(1))] = tuple(int(v) for v in m.groups()[1:])
                continue
            m = KV_RE.match(line)
            if m:
                cur.props[m.group(1).lower()] = m.group(2).strip()

    def write(self, path, extra=None, prop_override=None):
        """extra: {section: [(char, (x,y,w,h)), ...]} appended; prop_override: {section: {prop: value}}"""
        extra = extra or {}
        prop_override = prop_override or {}
        out = list(self.head)
        for name, sec in self.sections.items():
            out.append('[%s]' % name)
            ov = {k.lower(): v for k, v in prop_override.get(name, {}).items()}
            body = []
            for line in sec.lines:
                m = KV_RE.match(line)
                if m and not line.strip().startswith(';') and m.group(1).lower() in ov and not CHAR_RE.match(line):
                    tabs = line[:line.index('=')]
                    body.append('%s= %s' % (tabs, ov[m.group(1).lower()]))
                    continue
                body.append(line)
            # strip trailing blank lines, append extra chars, then a blank line
            while body and not body[-1].strip():
                body.pop()
            if name in extra and extra[name]:
                body.append('; --- glyphes FR (generes par FR_Traduction) ---')
                for c, (x, y, w, h) in extra[name]:
                    body.append('char_%s = %d,%d,%d,%d' % (char_to_key(c), x, y, w, h))
            body.append('')
            out.extend(body)
        open(path, 'wb').write(('\r\n'.join(out) + '\r\n').encode('utf-8'))
