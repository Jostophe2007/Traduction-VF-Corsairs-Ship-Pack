
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	int iTermsValidity;

	int iNation;
	int LicenceValidity;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sTemp;

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "exit_over":
			npchar.lifeDay = 0;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "SCQ_exit":
			npchar.lifeDay = 0;
			LAi_SetActorType(npchar);
			LAi_CharacterDisableDialog(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
			UnmarkCharacter(npchar);
			DialogExit();
		break;
		case "good_all":
			dialog.text = NPCStringReactionRepeat("Content" + NPCharSexPhrase(npchar, "", "a") + " de vous revoir. Vous vouliez autre chose ?",
				"Oh, encore vous ? Nous avons déjà parlé aujourd'hui. Quelque chose a changé ?",
				"Hum, vous pourriez arrêter de m'importuner sans raison ?!",
                "Brrr, rien que votre tête me donne la nausée...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Non, rien de tel...",
				"Non, ça va.",
                "Oui, bien sמr, excusez-moi...",
				"Hum, eh bien, vous vous trompez, j'ai une bonne tête. Je l'aime bien, moi, ma tête !", npchar, Dialog.CurrentNode);
			link.l1.go = "Exit";
			NextDiag.TempNode = "good_all";
		break;
		case "All_disagree":
			npchar.lifeDay = 0;
			NextDiag.TempNode = "All_bye";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "All_bye":
			dialog.text = "Je ne veux pas vous parler, adieu.";
			link.l1 = "Hé, eh bien, ne le faites pas.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "All_bye";
		break;
		//================================== в Порт оф Спейне ======================================
		case "PortSpein":
			NextDiag.TempNode = "PortSpein";
			dialog.text = "Bonjour, capitaine. Vous ne voulez pas parler de quelque chose qui vous intéresse sans aucun doute ?";
			link.l1 = "Non, je ne veux pas.";
			link.l1.go = "exit_over";
			link.l2 = "Comment savez-vous ce qui pourrait m'intéresser ?";
			link.l2.go = "PortSpein_1";
			DeleteAttribute(npchar, "talker");
			npchar.LifeDay = 20;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;
		case "PortSpein_1":
			dialog.text = "Les rumeurs, " +  GetAddress_Form(NPChar) + "La terre est pleine de rumeurs...";
			link.l1 = "Hé, allez, parlons.";
			if (GetCharacterItem(pchar, "map_full") == 0 && GetCharacterItem(pchar, "map_part1") == 0 && GetCharacterItem(pchar, "map_part2") == 0)
			{
				link.l1.go = "PortSpein_2";
			}
			else
			{
				link.l1.go = "PortSpein_2_pistol";
			}
		break;
		case "PortSpein_2":
			dialog.text = "Je pense qu'une... chose, pour ainsi dire, vous intéressera.";
			link.l1 = "Sans aucun doute.";
			link.l1.go = "PortSpein_3";
		break;

		case "PortSpein_2_pistol":
			dialog.text = "Je pense que des informations sur l'emplacement d'une chose très utile vous intéresseront.";
			link.l1 = "Sans aucun doute.";
			link.l1.go = "PortSpein_3_pistol";
		break;

		case "PortSpein_3":
			dialog.text = "Très bien. Mais je dois être sמr que cette chose ira à quelqu'un qui saura s'en servir correctement : je l'ai promis à une certaine personne. Je vous propose donc de répondre à une question, pour que je comprenne si vous êtes bien celui qu'il me faut. Vous êtes d'accord ?";
			link.l1 = "Hé... Bon, d'accord.";
			link.l1.go = "PortSpein_4";
			link.l2 = "Cherchez quelqu'un d'autre et soyez sמr de lui. Je passe mon tour.";
			link.l2.go = "All_disagree";
		break;

		case "PortSpein_3_pistol":
			dialog.text = "Très bien. Mais je dois être sמr que cette chose ira à quelqu'un qui saura s'en servir correctement : je l'ai promis à une certaine personne. Je vous propose donc de répondre à une question, pour que je comprenne si vous êtes bien celui qu'il me faut. Vous êtes d'accord ?";
			link.l1 = "Hé... Bon, d'accord.";
			link.l1.go = "PortSpein_4";
			link.l2 = "Cherchez quelqu'un d'autre et soyez sמr de lui. Je passe mon tour.";
			link.l2.go = "All_disagree";
		break;

		case "PortSpein_4":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Dans ce cas, écoutez la question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "PortSpein_check";
		break;
		case "PortSpein_check":
			sTemp = "a" + npchar.quest.numQuestion;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.questions.(sTemp)))
			{
				dialog.text = "Bonne réponse ! Vous êtes vraiment "+ GetSexPhrase("un capitaine savant", "une fille qui s'y connaît en navigation") +".";
				link.l1 = "Hé, bien sמr ! Dites-moi ce que vous avez.";
				if (GetCharacterItem(pchar, "map_full") == 0 && GetCharacterItem(pchar, "map_part1") == 0 && GetCharacterItem(pchar, "map_part2") == 0)
				{
					link.l1.go = "PortSpein_ok";
				}
				else
				{
					link.l1.go = "PortSpein_ok_pistol";
				}
			}
			else
			{
				dialog.text = "La réponse est fausse. Vous allez peut-être réfléchir et me donner la bonne réponse ?";
				link.l1 = "Oui, je vais réessayer.";
				link.l1.go = "PortSpein_5";
				link.l2 = "Non, je ne connais pas la réponse à cette question.";
				link.l2.go = "PortSpein_6";
			}
		break;
		case "PortSpein_ok":
			dialog.text = "C'est une vieille carte au trésor. On dit qu'il a été caché par sir Walter Raleigh lui-même. Je vous la donne, selon le vœu que j'ai fait : la transmettre de main en main à un marin expérimenté. Bonne chance dans vos recherches !";
			link.l1 = "Bon, je vous ai compris. On cherchera !";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
			GiveItem2Character(pchar, "map_full");
			ReOpenQuestHeader("QuestionsMessages");
			AddQuestRecord("QuestionsMessages", "1");
			AddQuestUserData("QuestionsMessages", "sName", GetFullName(npchar));
			CloseQuestHeader("QuestionsMessages");
		break;

		case "PortSpein_ok_pistol":
			dialog.text = "C'est un excellent mousquet à mèche ! Mais je ne l'ai pas, je sais seulement oם le trouver. Dans la colonie pirate de La Vega, il faut aller derrière la maison à gauche du portail : l'arme y est cachée dans le sol. Bonne chance !";
			link.l1 = "Bon, je vous ai compris. On cherchera !";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
 			pchar.GenQuestRandItem.LaVega_town = true;
			pchar.GenQuestRandItem.LaVega_town.randitem4 = "mushket";
			ReOpenQuestHeader("QuestionsMessages");
			AddQuestRecord("QuestionsMessages", "1_1");
			AddQuestUserData("QuestionsMessages", "sName", GetFullName(npchar));
			CloseQuestHeader("QuestionsMessages");
		break;

		case "PortSpein_5":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Très bien ! Alors je répète ma question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "PortSpein_check";
		break;
		case "PortSpein_6":
			dialog.text = "Dommage, mais dans ce cas, je ne peux pas vous donner ce qui est destiné à un bon capitaine. Mais je suis prêt à écouter votre réponse une autre fois, si vous arrivez à me trouver. Je resterai en ville un peu plus d'une semaine.";
			link.l1 = "Bon, si je trouve la réponse, je réessaierai.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PortSpein_again";
		break;
		case "PortSpein_again":
			dialog.text = "Ah, vous revoilà. Vous avez trouvé la réponse ?";
			link.l1 = "Je crois que oui.";
			link.l1.go = "PortSpein_5";
		break;
		//================================== Виллемстад: Найти пропавшего торговца ======================================
		case "Villemstad":
			NextDiag.TempNode = "Villemstad";
			dialog.text = "Bonjour, capitaine. Je voulais vous demander un service.";
			link.l1 = RandPhraseSimple("Qu'est-ce qui vous arrive, " + GetAddress_FormToNPC(NPChar) + " ?", "Exposez votre problème, " + GetAddress_FormToNPC(NPChar) + ". J'essaierai de vous aider.");
			link.l1.go = "SCQ_Hasband";
			link.l2 = RandPhraseSimple("Pas le temps, ma belle, pas aujourd'hui !", "Désolé, " + GetAddress_FormToNPC(NPChar) + ", mais je n'ai pas le temps en ce moment...");
			link.l2.go = "exit";
		break;
		case "SCQ_Hasband":
			dialog.text = "Mon mari fait du commerce : il livre des marchandises aux marchands de toute la région. Eh bien, il a pris la mer il y a plus de trois mois, et il n'est toujours pas revenu !";
			link.l1 = "Vous pensez qu'il lui est arrivé quelque chose ?";
			link.l1.go = "SCQ_Hasband_0";
		break;
		case "SCQ_Hasband_0":
			dialog.text = "Je ne sais pas, mais j'espère vraiment qu'il est juste occupé par son travail. Il aurait pu envoyer un message, il sait que je m'inquiète !";
			link.l1 = "La mer est agitée en ce moment, tout peut arriver...";
			link.l1.go = "SCQ_Hasband_1";
		break;
		case "SCQ_Hasband_1":
			dialog.text = "Voilà ! Vous voyez de quoi je parle. א votre allure, "+ GetSexPhrase("vous êtes un capitaine courageux", "vous êtes une fille courageuse") +", c'est pourquoi je voulais vous demander de retrouver mon mari. Je suis prête à vous payer 5 000 piastres et à vous donner mes bijoux.";
			link.l1 = "D'accord. Si je croise votre mari en mer ou ailleurs, je l'informerai de votre inquiétude. Dites-moi, comment s'appelle votre mari et quel navire a-t-il ?";
			link.l1.go = "SCQ_Hasband_2";
			link.l2 = "Une telle somme ne m'intéresse pas. Malheureusement, je dois refuser...";
			link.l2.go = "exit";
		break;
		case "SCQ_Hasband_2":
			dialog.text = "Il s'appelle Maurits Groen. Et il travaille sur une flמte nommée 'Louise'. Son navire a été vu pour la dernière fois au sud de la Terre Ferme.";
			link.l1 = "Compris. Bon, maintenant, patientez. Et tâchez de rester surtout à l'église, pour que je n'aie pas à vous chercher en ville...";
			link.l1.go = "exit";
			npchar.quest.SeekCap = "womanHasband"; //личный флаг ситизена на квест
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_womanResult";
			SetQuestHeader("SCQ_womanHasband");
			AddQuestRecord("SCQ_womanHasband", "1");
			
			sld = GetCharacter(NPC_GenerateCharacter("QuetionsVillemstad_MuzhTorgovets", "GrunMaurits", "man", "man", sti(PChar.rank), HOLLAND, -1, true));
			FantomMakeCoolSailor(sld, SHIP_SHNYAVA, "Louise", CANNON_TYPE_CULVERINE_LBS12, 30, 30, 30);
			sld.name = "Maurits";
			sld.lastname = "Groen";
			sld.dialog.filename   = "Quest\Questions.c";
			sld.DeckDialogNode = "HasbandCap_inDeck";
			sld.Ship.Mode = "trade";
			Group_FindOrCreateGroup("QuetionsVillemstad_MuzhTorgovets_Ship");
			Group_SetType("QuetionsVillemstad_MuzhTorgovets_Ship", "pirate");
			Group_AddCharacter("QuetionsVillemstad_MuzhTorgovets_Ship", "QuetionsVillemstad_MuzhTorgovets");
			Group_SetGroupCommander("QuetionsVillemstad_MuzhTorgovets_Ship", "QuetionsVillemstad_MuzhTorgovets");
			int RandomLuiza;
			RandomLuiza = rand(2);
			if (RandomLuiza == 0)
			{ 
				Group_SetAddress("QuetionsVillemstad_MuzhTorgovets_Ship", "Maracaibo", "quest_ships", "Quest_ship_6");
			break;
			}
			if (RandomLuiza == 1)
			{ 
				Group_SetAddress("QuetionsVillemstad_MuzhTorgovets_Ship", "Caracas", "quest_ships", "Quest_ship_5");
			break;
			}
			if (RandomLuiza == 2)
			{ 
				Group_SetAddress("QuetionsVillemstad_MuzhTorgovets_Ship", "Cumana", "quest_ships", "Quest_ship_5");
			break;
			}
		break;
		case "HasbandCap_inDeck":
			dialog.text = "Bonjour. א quoi dois-je l'honneur de vous voir sur mon navire ?";
			link.l1 = "Vous vous appelez Maurits Groen, n'est-ce pas ?";
			link.l1.go = "HasbandCap_inDeck_1";
		break;
		case "HasbandCap_inDeck_1":
			dialog.text = "Oui, c'est moi.";
			link.l1 = "דa paraît bête, bien sמr, mais votre femme m'a demandé de vous dire qu'elle s'inquiète beaucoup pour vous.";
			link.l1.go = "HasbandCap_inDeck_2";
		break;
		case "HasbandCap_inDeck_2":
			dialog.text = "Ouf, bon sang ! Et pour être honnête, j'ai eu peur : je croyais que c'était le célèbre chasseur de primes, Steed Hunter le Borgne, qui me suivait. Eh bien, heureusement que je me suis trompé. Vous savez, je suis tellement pris par le travail que je n'ai pas la tête à ça en ce moment. Les offres lucratives se succèdent, je ne peux pas laisser passer un bénéfice possible juste parce que ma femme s'inquiète.";			
			link.l1 = "C'est sמr, mais vous pourriez au moins lui écrire que tout va bien.";
			link.l1.go = "HasbandCap_inDeck_3";
		break;
		case "HasbandCap_inDeck_3":
			dialog.text = "Oui, vous avez raison. Je le ferai sans faute au premier port de déchargement... Merci infiniment de vous intéresser à nos affaires de famille !";
			link.l1 = "Je vous en prie, l'ami. J'y vais, alors.";
			link.l1.go = "HasbandCap_inDeck_4";			
		break;
		case "HasbandCap_inDeck_4":
			dialog.text = "Attendez, je veux vous confier quelque chose. Le fait est que ma femme et moi avons vécu un temps à Puerto Príncipe, mais ensuite, nous avons dמ déménager à Willemstad. Et je vous le dis, c'était une des meilleures décisions de ma vie. Je ne remettrai plus jamais les pieds dans ce trou !";
			link.l1 = "Continuez...";
			link.l1.go = "HasbandCap_inDeck_5";			
		break;
		case "HasbandCap_inDeck_5":
			dialog.text = "Bref, j'y ai encore quelques affaires, et l'une d'elles sera sמrement utile "+ GetSexPhrase("à un capitaine", "à une capitaine aussi courageuse") +" comme vous.";
			link.l1 = "Quelle chose pourrait bien m'être utile là-bas ?";
			link.l1.go = "HasbandCap_inDeck_6";			
		break;
		case "HasbandCap_inDeck_6":
			dialog.text = "Une assez bonne longue-vue. Elle est enterrée sous la fenêtre de notre ancienne maison, à Puerto Príncipe, à gauche de la taverne.";
			link.l1 = "Compris. Eh bien, merci et adieu.";
			link.l1.go = "exit";
			npchar.lifeday = 0;
			npchar.dialog.filename   = "Quest\Questions.c";
			npchar.DeckDialogNode = "HasbandCap_inDeck_exit";
			AddQuestRecord("SCQ_womanHasband", "2");
			sld = characterFromId("QuetionsVillemstad");
			sld.dialog.filename = "Quest\Questions.c";
			sld.dialog.currentnode = "womanHasbandover";
			pchar.GenQuestRandItem.PuertoPrincipe_town = true;
			pchar.GenQuestRandItem.PuertoPrincipe_town.randitem1 = "spyglass3";
			PChar.quest.SCQ_Hasband_Truba.win_condition.l1 = "locator";
			PChar.quest.SCQ_Hasband_Truba.win_condition.l1.location = "PuertoPrincipe_town";
			PChar.quest.SCQ_Hasband_Truba.win_condition.l1.locator_group = "randitem";
			PChar.quest.SCQ_Hasband_Truba.win_condition.l1.locator = "randitem1";
			PChar.quest.SCQ_Hasband_Truba.win_condition = "SCQ_Hasband_Truba";
			DeleteAttribute(pchar, "questTemp.SCQ_Hasband_Luiza");
		break;
		case "HasbandCap_inDeck_exit":
			dialog.text = "Encore une fois, merci...";
			link.l1 = "Ce n'est rien, ce n'est pas la peine.";
			link.l1.go = "exit";
			NextDiag.TempNode = "HasbandCap_inDeck_exit";
		break;
		
		//================================== Порт-о-Принс: Вызволение из плена мужа горожанки ======================================
		case "PortPax":
			NextDiag.TempNode = "PortPax";
			dialog.text = "Capitaine, aidez-moi, je vous en supplie ! Mon mari est tombé entre les mains de pirates ! Vous pouvez le sauver ?";		
			link.l1 = "Attendez, je ne comprends pas bien qui est tombé entre les mains de qui...");
			link.l1.go = "SCQ_Pirates";
			DeleteAttribute(npchar, "talker");
		break;
		case "SCQ_Pirates":
			dialog.text = "Je vais vous expliquer. Le fait est que mon mari, un homme tout à fait ordinaire, a été capturé par des pirates ! Ils ont tué tout le monde, n'ont épargné personne...";
			link.l1 = "C'est donc que le capitaine a osé résister. S'ils s'étaient rendus, personne n'aurait été blessé.";
			link.l1.go = "SCQ_Pirates_1";
		break;
		case "SCQ_Pirates_1":
			dialog.text = "Peut-être, mais mon mari n'y est absolument pour rien. Il n'était qu'un passager sur ce navire. Alors, pour sauver sa vie, il a dמ dire qu'il était fabuleusement riche. Les pirates l'ont épargné, et ne l'ont même pas jeté dans la cale.";
			link.l1 = "Comment le savez-vous ?";
			link.l1.go = "SCQ_Pirates_2";
		break;
		case "SCQ_Pirates_2":
			dialog.text = "Mon mari a réussi à m'envoyer une lettre oם il dit que tout va bien pour lui. On le garde dans une cabine, pas comme les autres prisonniers.";
			link.l1 = "Et que comptez-vous faire ? דa ne peut pas durer longtemps. Tכt ou tard, les pirates finiront par le démasquer.";
			link.l1.go = "SCQ_Pirates_3";
		break;
		case "SCQ_Pirates_3":
			dialog.text = "Vous êtes pirate, vous aussi, n'est-ce pas ? Oui, oui, je sais... Je vous en supplie, aidez-nous, sauvez mon mari ! Dans sa lettre, il a décrit le navire pirate et donné le nom du capitaine. Vous le trouverez assez facilement !";
			link.l1 = "Ce n'est pas aussi simple que vous le croyez. Tous les prisonniers sont la prise légitime du capitaine qui a capturé le navire. Et je ne peux pas faire ça en peu de temps.";
			link.l1.go = "SCQ_Pirates_4";
		break;
		case "SCQ_Pirates_4":
			dialog.text = "Mais vous pouvez essayer ! D'ailleurs, il y a du temps pour les recherches. Mon mari est loin d'être bête : il s'est fait passer pour un marchand de l'Ancien Monde, alors les pirates n'exigent pas tout de suite de l'argent pour lui, c'est trop loin pour aller le chercher. Si vous le libérez, je vous donnerai tout ce que j'ai !";
			link.l1 = "Et qu'avez-vous ?";
			link.l1.go = "SCQ_Pirates_5";
		break;
		case "SCQ_Pirates_5":
			npchar.quest.SeekCap = "womanPirates"; //личный флаг ситизена на квест
			dialog.text = "Un petit peu : 5 000 piastres et tous mes bijoux... mais je prierai pour votre âme jusqu'à la fin de mes jours !";
			link.l1 = "Oui, vraiment un petit peu... Bon, soit, je suis prêt à vous aider à l'occasion.";
			link.l1.go = "SCQ_Pirates_6";
			link.l2 = "Désolé, mais c'est trop peu pour que j'attaque un collègue, un membre de la Confrérie.";
			link.l2.go = "exit";
		break;
		case "SCQ_Pirates_6":
			dialog.text = "Merci, merci !!";
			link.l1 = "Si tout s'arrange, vous me remercierez ; pour l'instant, ce n'est pas la peine. Dites-moi le nom de votre mari et tout ce que vous savez sur ces pirates.";
			link.l1.go = "SCQ_Pirates_7";
		break;
		case "SCQ_Pirates_7":
			dialog.text = "Mon mari s'appelle Vincent Labbe. Le capitaine pirate s'appelle Corey Ball, il sévit sur une goélette nommée Colossus. Il a été vu pour la dernière fois près de l'île déserte des Turques.";
			link.l1 = "Compris. Bon, maintenant, attendez et espérez que j'arriverai à l'attraper. Tâchez de rester à l'église, pour que je puisse vous y trouver.";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";			
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_womanResult";
			SetQuestHeader("SCQ_womanPirates");
			AddQuestRecord("SCQ_womanPirates", "1");

			sld = GetCharacter(NPC_GenerateCharacter("QuetionsPortPax_KoriBoll", "officer_17", "man", "man", sti(PChar.rank), PIRATE, -1, true));
			FantomMakeCoolSailor(sld, SHIP_SCHOONERWAR, "Colossus", CANNON_TYPE_CULVERINE_LBS12, 30, 30, 30);
			sld.name = "Cory";
			sld.lastname = "Ball";
			sld.dialog.filename   = "Quest\Questions.c";
			sld.dialog.currentnode = "PiratesCap_Board";
			sld.AlwaysEnemy = true;
			sld.DontRansackCaptain = true;
			Group_FindOrCreateGroup("QuetionsPortPax_KoriBoll_Ship");
			Group_SetType("QuetionsPortPax_KoriBoll_Ship", "pirate");
			Group_AddCharacter("QuetionsPortPax_KoriBoll_Ship", "QuetionsPortPax_KoriBoll");
			Group_SetGroupCommander("QuetionsPortPax_KoriBoll_Ship", "QuetionsPortPax_KoriBoll");
			Group_SetAddress("QuetionsPortPax_KoriBoll_Ship", "Terks", "quest_ships", "Quest_ship_3");
			
			PChar.quest.SCQ_womanPirates_Potunul.win_condition.l1 = "Character_sink";
			PChar.quest.SCQ_womanPirates_Potunul.win_condition.l1.character = "QuetionsPortPax_KoriBoll";
			PChar.quest.SCQ_womanPirates_Potunul.win_condition = "SCQ_womanPirates_Potunul";
			PChar.quest.SCQ_womanPirates_Nashli.win_condition.l1 = "location";
			PChar.quest.SCQ_womanPirates_Nashli.win_condition.l1.location = "Terks";
			PChar.quest.SCQ_womanPirates_Nashli.win_condition = "SCQ_womanPirates_Nashli";
		break;
		case "PiratesCap_Board":
			dialog.text = "Diable ! Qu'est-ce que ça veut dire, bon sang ?!!";
			link.l1 = "J'ai besoin de votre prisonnier, du nom de Vincent Labbe.";
			link.l1.go = "PiratesCap_Board_1";
		break;
		case "PiratesCap_Board_1":
			dialog.text = "Ha ! Eh bien, non, seulement sur mon cadavre...";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "PiratesCap_Board_2";
		break;
		case "PiratesCap_Board_2":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("SCQ_womanPirates_afterCabinFight");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "womanPirates_Board":
			dialog.text = "Qui êtes-vous ?";
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ". N'ayez pas peur, je viens vous chercher pour vous ramener auprès de votre femme.";
			link.l1.go = "womanPirates_Board_1";
		break;
		case "womanPirates_Board_1":
			dialog.text = "Bon sang, ce n'est pas un rêve ?!";
			link.l1 = "Je vous assure, ce n'est pas un rêve... Bon, c'est fait, maintenant filons d'ici.";
			link.l1.go = "exit";
			//уберем мужа из каюты
			npchar.location = "none";
			npchar.location.locator = "";
			LAi_SetPlayerType(pchar);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			sld = characterFromId("QuetionsPortPax");
			sld.dialog.filename = "Quest\Questions.c";
			sld.dialog.currentnode = "womanPiratesover";
			AddQuestRecord("SCQ_womanPirates", "4");
		break;
		//================================== Сан-Хуан ======================================
		case "SanJuan":
			NextDiag.TempNode = "SanJuan";
			dialog.text = "Salutations, capitaine. Je veux vous proposer quelque chose.";
			link.l1 = "Non, ça ne m'intéresse pas.";
			link.l1.go = "exit_over";
			link.l2 = "Je vous écoute attentivement, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l2.go = "SanJuan_1";
			DeleteAttribute(npchar, "talker");
			npchar.LifeDay = 20;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;
		case "SanJuan_1":
			dialog.text = "J'ai une chose très utile pour les capitaines, qui vous intéressera sans aucun doute.";
			link.l1 = "Je vous écoute encore plus attentivement. Quelle est cette chose ?";
			link.l1.go = "SanJuan_2";
		break;
		case "SanJuan_2":
			dialog.text = "Ce document, dirais-je, m'est parvenu à l'occasion et à certaines conditions. Je dois le remettre au plus vite à un capitaine qui en a vraiment besoin et qui le mérite.";
			link.l1 = "Ah oui ? Et quel est ce mystérieux document ?";
			link.l1.go = "SanJuan_3";
		break;
		case "SanJuan_3":
			dialog.text = "Je ne pourrai vous le dire qu'après que vous aurez répondu à une question.";
			link.l1 = "Quelle autre question ?";
			link.l1.go = "SanJuan_4";
		break;
		case "SanJuan_4":
			dialog.text = "Une question de culture générale pour capitaines. Je dois savoir clairement à qui j'ai affaire.";
			link.l1 = "Bon, posez votre question de culture générale.";
			link.l1.go = "SanJuan_5";
			link.l2 = "Je ne veux répondre à aucune question stupide.";
			link.l2.go = "All_disagree";
		break;
		case "SanJuan_5":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Très bien. Alors, capitaine, voici ma question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "SanJuan_check";
		break;
		case "SanJuan_check":
			sTemp = "a" + npchar.quest.numQuestion;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.questions.(sTemp)))
			{
				dialog.text = "Parfait, "+ GetSexPhrase("capitaine", "mademoiselle") +" ! C'est tout à fait juste !";
				link.l1 = "Eh bien !.. Alors, quel est ce mystérieux document ?";
				link.l1.go = "SanJuan_ok";
			}
			else
			{
				dialog.text = "Non, "+ GetSexPhrase("capitaine", "mademoiselle") +", la réponse est fausse. Je vous propose quand même de donner la bonne réponse.";
				link.l1 = "Répétez...";
				link.l1.go = "SanJuan_6";
				link.l2 = "Non, j'en ai assez des questions.";
				link.l2.go = "SanJuan_7";
			}
		break;
		case "SanJuan_ok":
			LicenceValidity = 20;
			GiveUniLicence(LicenceValidity); // universal GWIK trade license (adds time to the current one)

			dialog.text = "C'est une licence commerciale universelle de la Compagnie néerlandaise des Indes occidentales, valable " + LicenceValidity + " jours ! Je suis heureux de vous l'offrir.";
			link.l1 = "דa alors, un document plutכt coמteux ! Eh bien, merci, " + GetAddress_FormToNPC(NPChar) + ", pour ce service. Adieu.";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
		break;
		case "SanJuan_6":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Bien. Je considère qu'il est de mon devoir de vous rappeler la question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "SanJuan_check";
		break;
		case "SanJuan_7":
			dialog.text = "Bon, ça suffit, ça suffit. Adieu, "+ GetSexPhrase("capitaine", "mademoiselle") +"...";
			link.l1 = "Je vous souhaite tout le meilleur.";
			link.l1.go = "exit";
			NextDiag.TempNode = "SanJuan_again";
		break;
		case "SanJuan_again":
			dialog.text = "Je vous écoute attentivement, capitaine. Vous avez vraiment décidé de réessayer de répondre à la question qu'on vous a posée ?";
			link.l1 = "Oui, je crois connaître la bonne réponse.";
			link.l1.go = "SanJuan_6";
		break;
		//================================== Кумана ======================================
		case "Cumana":
			NextDiag.TempNode = "Cumana";
			dialog.text = "Salutations, capitaine ! J'ai une petite affaire pour vous. דa vous ennuierait de m'accorder une minute ?";
			link.l1 = "Non, pas question.";
			link.l1.go = "exit_over";
			link.l2 = "Oui, pas de problème, la minute est à vous.";
			link.l2.go = "Cumana_1";
			DeleteAttribute(npchar, "talker");
			npchar.LifeDay = 20;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;
		case "Cumana_1":
			dialog.text = "Très bien. Je voulais vous proposer un petit marché. J'ai un objet qui pourrait vous intéresser.";
			link.l1 = "Dites-moi quel est cet objet, et donnez votre prix.";
			link.l1.go = "Cumana_2";
		break;
		case "Cumana_2":
			dialog.text = "Je ne prendrai pas d'argent pour lui : vous devrez répondre à une question. Si la réponse est juste, l'objet est à vous.";
			link.l1 = "Très étrange. Vous n'avez pas besoin d'argent ?";
			link.l1.go = "Cumana_3";
		break;
		case "Cumana_3":
			dialog.text = "Hé, tout le monde a besoin d'argent, mais dans ce marché, tout se décide par vos connaissances. Je ne veux pas expliquer davantage les raisons de ma conduite, dites simplement oui ou non.";
			link.l1 = "Hum, je suppose que oui. דa devient intéressant.";
			link.l1.go = "Cumana_4";
			link.l2 = "Non, non et encore non. Adieu.";
			link.l2.go = "All_disagree";
		break;
		case "Cumana_4":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Hé, vous avez déjà répondu correctement à une question. Et maintenant, l'événement du jour ! וcoutez la question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Cumana_check";
		break;
		case "Cumana_check":
			sTemp = "a" + npchar.quest.numQuestion;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.questions.(sTemp)))
			{
				dialog.text = "Parfait ! C'est la bonne réponse !";
				link.l1 = "C'est clair... Alors, quelle est cette chose qui m'appartient désormais ?";
				link.l1.go = "Cumana_ok";
			}
			else
			{
				dialog.text = "Je suis navré, "+ GetSexPhrase("capitaine", "mademoiselle") +". Vraiment désolé... La réponse est fausse ! Vous voulez réessayer ?";
				link.l1 = "Je vais essayer !";
				link.l1.go = "Cumana_6";
				link.l2 = "Non, plutכt pas...";
				link.l2.go = "Cumana_7";
			}
		break;
		case "Cumana_ok":
			dialog.text = "C'est une statuette qui offre la possibilité extraordinaire de mieux réparer le navire. Elle est cachée dans une baie près de Portobelo. Cette baie s'appelle la lagune de Chiriquí. Inspectez soigneusement tout l'endroit, et n'ayez pas peur de vous mouiller les pieds. Bonne chance, capitaine !";
			link.l1 = "Vous savez, c'est une chose vraiment utile pour un capitaine. Merci.";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
 			pchar.GenQuestRandItem.Shore46 = true;
			pchar.GenQuestRandItem.Shore46.randitem1 = "STATUE1";
			ReOpenQuestHeader("QuestionsMessages");
			AddQuestRecord("QuestionsMessages", "4");
			AddQuestUserData("QuestionsMessages", "sName", GetFullName(npchar));
			CloseQuestHeader("QuestionsMessages");
		break;
		case "Cumana_6":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Eh bien, alors je vous rappelle la question ! " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Cumana_check";
		break;
		case "Cumana_7":
			dialog.text = "Bon, si vous ne voulez pas, comme vous voudrez. Adieu, capitaine Je-ne-sais-rien...";
			link.l1 = "Quoi ?";
			link.l1.go = "exit";
			NextDiag.TempNode = "Cumana_again";
		break;
		case "Cumana_again":
			dialog.text = "Et que me voulez-vous ?";
			link.l1 = "Je veux essayer de répondre encore une fois à votre énigme.";
			link.l1.go = "Cumana_6";
		break;
		//================================== Порт Рояль ======================================
		case "PortRoyal":
			NextDiag.TempNode = "PortRoyal";
			dialog.text = "Bonjour, capitaine. וcoutez, il me semble que vous êtes exactement celui qu'il me faut...";
			link.l1 = "Moi, je ne crois pas.";
			link.l1.go = "exit_over";
			link.l2 = "De quoi s'agit-il, " + GetAddress_FormToNPC(NPChar) + " ?";
			link.l2.go = "PortRoyal_1";
			DeleteAttribute(npchar, "talker");
			npchar.LifeDay = 20;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;
		case "PortRoyal_1":
			dialog.text = "Je veux vous proposer un échange. Le fait est que j'ai une chose dont je n'ai absolument pas besoin, mais dont vous aurez sמrement besoin.";
			link.l1 = "Et que voulez-vous en échange ?";
			link.l1.go = "PortRoyal_2";
		break;
		case "PortRoyal_2":
			dialog.text = "Rien de spécial. Je veux savoir que cette chose est en de bonnes mains.";
			link.l1 = "Eh bien, sachez qu'elle sera vraiment en de bonnes mains. Vous pouvez en être sמr.";
			link.l1.go = "PortRoyal_3";
		break;
		case "PortRoyal_3":
			dialog.text = "Je le crois volontiers, mais je vais quand même vérifier. Répondez à une de mes questions, et la chose est à vous.";
			link.l1 = "Posez votre question, rien de plus facile !";
			link.l1.go = "PortRoyal_4";
			link.l2 = "Je me débrouillerai bien sans...";
			link.l2.go = "All_disagree";
		break;
		case "PortRoyal_4":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Eh bien, la question est assez simple. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "PortRoyal_check";
		break;
		case "PortRoyal_check":
			sTemp = "a" + npchar.quest.numQuestion;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.questions.(sTemp)))
			{
				dialog.text = "Je n'ai même pas douté que vous répondriez correctement.";
				link.l1 = "Bien sמr, il ne pouvait en être autrement. Alors, quelle est cette chose qui est déjà à moi ?";
				link.l1.go = "PortRoyal_ok";
			}
			else
			{
				dialog.text = "La réponse est fausse, "+ GetSexPhrase("capitaine", "mademoiselle") +". Il me faut la bonne réponse. Vous voulez réessayer ?";
				link.l1 = "Oui, je vais réessayer !";
				link.l1.go = "PortRoyal_6";
				link.l2 = "Non, je ne veux pas jouer aux devinettes.";
				link.l2.go = "PortRoyal_7";
			}
		break;
		case "PortRoyal_ok":
			dialog.text = "C'est une cuirasse de garde. Vous la trouverez en Jamaïque, dans la baie de Portland.";
			link.l1 = "Oui, c'est une chose indispensable au combat, "+ GetSexPhrase("elle me sera bien utile", "elle me sera certainement utile") +". Merci.";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
 			pchar.GenQuestRandItem.Shore36 = true;
			pchar.GenQuestRandItem.Shore36.randitem2 = "cirass3";
			ReOpenQuestHeader("QuestionsMessages");
			AddQuestRecord("QuestionsMessages", "5");
			AddQuestUserData("QuestionsMessages", "sName", GetFullName(npchar));
			CloseQuestHeader("QuestionsMessages");
		break;
		case "PortRoyal_6":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Bon. Je suppose que je dois vous rappeler la question. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "PortRoyal_check";
		break;
		case "PortRoyal_7":
			dialog.text = "Si vous ne voulez pas, comme vous voudrez. Hum, et pourtant, on dirait "+ GetSexPhrase("un capitaine si solide", "une fille si combative") +"...";
			link.l1 = "Que voulez-vous dire par là ?";
			link.l1.go = "exit";
			NextDiag.TempNode = "PortRoyal_again";
		break;
		case "PortRoyal_again":
			dialog.text = "Je n'ai pas compris ! Que vous faut-il encore ?";
			link.l1 = "Je veux essayer de répondre encore une fois à votre énigme.";
			link.l1.go = "PortRoyal_6";
		break;
		//================================== Сантьяго ======================================
		case "Santiago":
			NextDiag.TempNode = "Santiago";
			dialog.text = "Bienvenue à Santiago, capitaine ! Je voulais vous parler d'une petite affaire. דa ne vous dérange pas ?";
			link.l1 = "Je ne veux pas parler.";
			link.l1.go = "exit_over";
			link.l2 = "Pas du tout. Je suis à votre service.";
			link.l2.go = "Santiago_1";
			DeleteAttribute(npchar, "talker");
			npchar.LifeDay = 20;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;
		case "Santiago_1":
			dialog.text = "Parfait ! Alors, commençons. L'affaire en question consiste essentiellement en un marché, ou un échange, si vous voulez...";
			link.l1 = "Je veux, je veux un échange ! וchangeons.";
			link.l1.go = "Santiago_2";
		break;
		case "Santiago_2":
			dialog.text = "Kh-hé, bon, allons-y. Donc, je peux vous offrir un objet dont vous avez sans doute besoin. En échange, je ne vous demande rien, je veux juste obtenir une réponse à une question que je vous poserai.";
			link.l1 = "Et quelle est cette question ?";
			link.l1.go = "Santiago_3";
		break;
		case "Santiago_3":
			dialog.text = "D'ordre général, selon votre spécialité. Vous voyez, je veux juste vérifier le niveau de vos connaissances. C'est une condition indispensable. Vous êtes d'accord ?";
			link.l1 = "Hum, même si je ne comprends pas pourquoi vous avez besoin de ça, j'accepte quand même.";
			link.l1.go = "Santiago_4";
			link.l2 = "Hé, voilà un examinateur ! Fichez le camp avant qu'il ne soit trop tard...";
			link.l2.go = "All_disagree";
		break;
		case "Santiago_4":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Merveilleux ! Alors, écoutez ma question, je vous prie. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Santiago_check";
		break;
		case "Santiago_check":
			sTemp = "a" + npchar.quest.numQuestion;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.questions.(sTemp)))
			{
				dialog.text = "Parfait, c'est la bonne réponse ! Félicitations.";
				link.l1 = "Merci pour les félicitations, ça me fait très plaisir. Et pour que mon plaisir soit double, laissez-moi en entendre un peu plus sur l'objet de notre marché...";
				link.l1.go = "Santiago_ok";
			}
			else
			{
				dialog.text = "Hum, "+ GetSexPhrase("capitaine", "mademoiselle") +", cette réponse ne peut pas me convenir. Elle est fausse ! Réessayez, je vous prie...";
				link.l1 = "Bien sמr que je vais réessayer.";
				link.l1.go = "Santiago_6";
				link.l2 = "Non, je renonce. J'en ai assez.";
				link.l2.go = "Santiago_7";
			}
		break;
		case "Santiago_ok":
			sTemp = GetConvertStr("itmname_pistol6", "ItemsDescribe.txt");
			dialog.text = "C'est " + sTemp + " ! Vous trouverez l'objet dans une grotte à Cuba ; pour y aller, il faut sortir de la ville et traverser la jungle. Mais vous conviendrez qu'une telle arme est une chose dont on a besoin au plus haut point.";
			link.l1 = "Oui, on ne peut pas dire le contraire. Bon, il va falloir aller se promener. Merci, et bonne journée.";
			link.l1.go = "exit_over";
			NextDiag.TempNode = "good_all";
 			pchar.GenQuestRandItem.Cuba_Grot = true;
			pchar.GenQuestRandItem.Cuba_Grot.randitem1 = "pistol6";
			ReOpenQuestHeader("QuestionsMessages");
			AddQuestRecord("QuestionsMessages", "6");
			AddQuestUserData("QuestionsMessages", "sName", GetFullName(npchar));
			AddQuestUserData("QuestionsMessages", "sBladeName", sTemp);
			CloseQuestHeader("QuestionsMessages");
		break;
		case "Santiago_6":
			sTemp = "q" + npchar.quest.numQuestion;
			dialog.text = "Parfait ! Dans ce cas, je vais vous la rappeler. " + NullCharacter.questions.(sTemp);
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Santiago_check";
		break;
		case "Santiago_7":
			dialog.text = "Vous refusez ? Vous en avez assez ?! Hum, mais l'objet de la question, c'est votre métier ! Enfin, ça m'est égal, adieu...";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Santiago_again";
		break;
		case "Santiago_again":
			dialog.text = "Que puis-je faire pour vous ?";
			link.l1 = "Je veux répondre à votre question.";
			link.l1.go = "Santiago_6";
		break;
		// --- результаты женских квестов ---
		case "SCQ_womanResult":
			dialog.text = "Oh, capitaine, je suis si heureuse de vous voir ! Dites-moi vite, qu'avez-vous appris sur mon affaire ?";
			link.l1 = "Hum, rappelez-moi, " + GetAddress_FormToNPC(NPChar) + ", de quelle affaire parlons-nous ?";
			link.l1.go = "SCQ_womanResult_exit";
		break;
		case "SCQ_womanResult_exit":
			switch (npchar.quest.SeekCap)
			{
				case "womanHasband":
					dialog.text = "Vous avez oublié que vous m'aviez promis de retrouver mon mari ? Il s'appelle Maurits Groen !";
					link.l1 = "Oh, oui, bien sמr... Je n'ai rien oublié, je n'ai simplement pas encore réussi à le trouver.";
					link.l1.go = "exit";
				break;
				case "womanRevenge":
					dialog.text = "Je n'ai pas bien compris ! Vous avez oublié que vous devez envoyer dans l'autre monde mon offenseur, un capitaine nommé " + npchar.quest.SeekCap.capName + " ?!";
					link.l1 = "Allons, " + GetAddress_FormToNPC(NPChar) + ", pas du tout. Votre commande est en cours, patientez...";
					link.l1.go = "exit";
				break;
				case "womanPirates":
					dialog.text = "Mon Dieu, capitaine, vous avez oublié que vous m'aviez promis de délivrer mon mari ?!";
					link.l1 = "Je n'ai rien oublié. Je m'en occupe. Patientez, " + GetAddress_FormToNPC(NPChar) + " " + npchar.lastname + ".";
					link.l1.go = "exit";
				break;
			}
		break;
		case "womanHasbandover":
			dialog.text = "Ah, capitaine, j'ai reçu une lettre de mon mari ! Il y écrit que vous l'avez retrouvé.";
			link.l1 = "Oui, c'est vrai, " + GetAddress_FormToNPC(NPChar) + ". Votre mari, Maurits Groen, est vivant et en bonne santé. Il était juste très occupé, pour ainsi dire...";
			link.l1.go = "SCQR_womanHasband";
		break;
		case "womanRevengeover":
			dialog.text = "Qu'en dites-vous, capitaine ? Avez-vous fait ce que je vous ai demandé ? Le capitaine " + npchar.quest.SeekCap.capName + " est mort ?";
			link.l1 = "Oui, il est mort, " + GetAddress_FormToNPC(NPChar) + ". Avant de mourir, il a appris qui avait causé sa perte. La dernière chose qu'il a entendue en ce monde, c'est votre nom.";
			link.l1.go = "SCQR_womanRevenge";
		break;
		case "womanPiratesover":
			dialog.text = "Vous avez finalement libéré mon mari ! Je vous en supplie, dites-moi, c'est vrai ?!!";
			link.l1 = "Oui, il est sur mon navire en ce moment. Vous pouvez le reprendre, si Vincent Labbe est bien votre mari...";
			link.l1.go = "SCQR_womanPirates";
		break;

		case "SCQR_womanHasband":
			dialog.text = "Mon Dieu, comme je vous suis reconnaissante ! Au fait, voici vos 5 000 piastres et 10 émeraudes. Et merci encore !";
			link.l1 = "Hum, je vous en prie...";
			link.l1.go = "SCQ_exit";
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, 5000);
			TakeNItems(PChar, "jewelry4", 10);
			pchar.questTemp.womanHasband_Nagrada = true;
			if (CheckAttribute(pchar, "questTemp.womanHasband_Nagrada") && CheckAttribute(pchar, "questTemp.womanHasband_Truba"))
			{
				CloseQuestHeader("SCQ_womanHasband");
				AddGoodDeed("SCQ_womanHasband", 3); // Gregg: доброе дело
				pchar.questdata.NaitiTorgovtsa = 1;
				DeleteAttribute(pchar, "questTemp.womanHasband_Nagrada");
				DeleteAttribute(pchar, "questTemp.womanHasband_Truba");
			}
		break;
		case "SCQR_womanPirates":
			dialog.text = "Bien sמr que c'est lui !!! Mon Dieu, capitaine, comme je vous suis reconnaissante ! Je prierai pour vous chaque jour de ma vie !";
			link.l1 = "C'est gentil, priez...";
			link.l1.go = "SCQR_womanPirates_2";
		break;		
		case "SCQR_womanPirates_2":
			dialog.text = "Voici les 5 000 piastres promises et 10 saphirs. Mais ce n'est pas tout. Le fait est que je connais un objet caché qui vous serait utile.";
			link.l1 = "Et quel est cet objet ?";
			link.l1.go = "SCQR_womanPirates_3";
			AddMoneyToCharacter(pchar, 5000);
			TakeNItems(PChar, "jewelry1", 10);
		break;
		case "SCQR_womanPirates_3":
			dialog.text = "C'est un magnifique costume, à la dernière mode européenne ! Il est caché dans un souterrain sous Tortuga, dans l'un des culs-de-sac. Il faudra le chercher.";
			link.l1 = "Cherchons-le. Une apparence présentable est très importante pour un capitaine. Merci.";
			link.l1.go = "SCQ_exit";
			sld = characterFromId("QuetionsPortPax_MuzhPassajir");
			RemovePassenger(pchar, sld);
			sld.lifeDay = 0;
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddQuestRecord("SCQ_womanPirates", "5");
			AddGoodDeed("SCQ_womanPirates", 3); // Gregg: доброе дело
			// LEO: квест окончен - гасим оба взведённых условия, иначе они висят вечно.
			//   ProcessCondition (quests_check.c) при первой же проверке резолвит id персонажа в НОМЕР СЛОТА
			//   и удаляет сам id, а самоудаляется условие только когда сработает. Слот фантома Кори Болла
			//   потом переиспользуется под другого генерённого капитана - и его потопление (морской патруль)
			//   переоткрывало давно закрытый квест записью 2. То же и с Nashli: заход на Тёркс - записью 3.
			PChar.quest.SCQ_womanPirates_Potunul.over = "yes";
			PChar.quest.SCQ_womanPirates_Nashli.over = "yes";
			AddQuestUserData("SCQ_womanPirates", "sSex", GetSexPhrase("", "e"));
			
			pchar.GenQuestRandItem.Tortuga_Cave = true;
			pchar.GenQuestRandItem.Tortuga_Cave.randitem1 = "suit_2";
			PChar.quest.SCQ_Pirates_Kostum.win_condition.l1 = "locator";
			PChar.quest.SCQ_Pirates_Kostum.win_condition.l1.location = "Tortuga_Cave";
			PChar.quest.SCQ_Pirates_Kostum.win_condition.l1.locator_group = "randitem";
			PChar.quest.SCQ_Pirates_Kostum.win_condition.l1.locator = "randitem1";
			PChar.quest.SCQ_Pirates_Kostum.win_condition = "SCQ_Pirates_Kostum";
		break;
	}
}
