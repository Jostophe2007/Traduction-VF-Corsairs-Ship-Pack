// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Il y a quelque temps, dans mon magasin, vous avez essayé de me poser une question...", "C'est la troisième question aujourd'hui. Je dois faire du commerce, pas dire des bêtises...",
                          "Encore des questions ? Et si on faisait plutכt des affaires ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Oui, exactement...",
                      "Oui, c'est vraiment la troisième fois...", "Hum, faisons peut-être des affaires...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "TakeFoodCuracao_toOrangeStore": //Голландская линейка, квест №2, доставка продовольствия из форта Оранж.
                    link.l2 = "J'ai pour vous un ordre du commandant du fort.";
                    link.l2.go = "Step_H2_1";
                break;

            }
             // <== Проверяем поле состояния квестов.
		break;

        case "Step_H2_1":
			dialog.text = NPCStringReactionRepeat("C'est exact, j'ai bien reçu cet ordre. Entendons-nous sur les prix dont nous avons parlé, "+ GetSexPhrase("mynheer", "madame") +".",
                         "Encore vous, très bien. Poursuivons notre marché spécial.",
                         "Revoilà notre brave capitaine ! Très bien. Attendons...",
                         "Capitaine, je suis content de vous voir pour la même affaire. Eh bien, poursuivons le commerce de ce lot spécial de marchandises.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Commençons à commercer.", "Continuons...",
                      "Au revoir.", "Oh, pas d'ironie, je vous en prie. "+ GetSexPhrase("Vous savez,", "Vous savez,") +" j'en ai moi-même par-dessus la tête de tout ça..." , npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

         case "DefenceOrange": //Голландская линейка, квест №4, защита форта Оранж.
            dialog.text = "Kof, kof, content de vous voir en bonne santé, capitaine. Et même après un tel massacre !";
            link.l2 = "Hum, oui, c'était une belle pagaille...";
            link.l2.go = "Step_H4_1";
        break;

        case "Step_H4_1":
			dialog.text = "J'ai fait des affaires avec vous, capitaine, et je vois maintenant que vous n'êtes pas seulement doué pour le commerce. Et ces Anglais ne s'approcheront plus de nous avant longtemps... Merci, "+ GetSexPhrase("mynheer", "madame") +", merci du fond du cœur.";
			link.l1 = "Je vous en prie, continuez votre commerce.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;


	}
	UnloadSegment(NPChar.FileDialog2);
}

