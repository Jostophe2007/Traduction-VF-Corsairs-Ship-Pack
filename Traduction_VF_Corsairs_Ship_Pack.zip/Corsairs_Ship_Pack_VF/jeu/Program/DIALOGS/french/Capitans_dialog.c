// разговор с капитаном на палубе  Boal
//homo 25/06/06
#include "DIALOGS\french\Rumours\Common_rumours.c"

string coolstory1[6] = {"charleston", "charlestown", "charles town", "charles-town", "charleston", "charlestown"};
string coolstory2[4] = {"hornigold", "benjamin hornigold", "ben hornigold", "hornigold"};

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, Diag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);
    //homo Осады
    aref aData;
    makearef(aData, NullCharacter.Siege);
    string sCap, sGroup;
    string fort;
	string coolstories = "";
	int questionsstate = 0;

    if (CheckAttribute(aData, "nation"))
    {
	    sCap = NationShortName(sti(aData.nation))+"SiegeCap_";
	    sGroup = "Sea_"+sCap+"1";

	   // string myships  = GetCompanionQuantity(PChar);
       // string escships = Group_GetCharactersNum(sGroup);

        switch(sti(aData.conation))
        {
            case 0:  fort = "le fort anglais"; break;
            case 1:  fort = "le fort français"; break;
            case 2:  fort = "le fort espagnol"; break;
            case 3:  fort = "le fort hollandais"; break;
            case 4:  fort = "le fort pirate"; break;
        }
        int ifortPower = sti(colonies[FindColony(aData.colony)].FortValue);
        int fortDamage = CheckFortInjuri();
        int SquadronDamage = CheckSquadronInjuri();

    }

    int iMoney;
	ref sld;

    if (CheckNPCQuestDate(npchar, "Card_date"))
	{
		SetNPCQuestDate(npchar, "Card_date");
		npchar.money = 3000 + rand(10) * makeint(100 * sti(PChar.rank) * (10.0 / MOD_SKILL_ENEMY_RATE*3));
	}
    //homo 26/06/06
	ProcessCommonDialogRumors(NPChar, Link, Diag);
	if (npchar.id == "BlackBeardNPC" && CheckAttribute(npchar, "met") && Dialog.CurrentNode == "First time") Dialog.CurrentNode = "Titch_7";
	switch(Dialog.CurrentNode)
	{
        case "Exit":
			DialogExit();
			Diag.CurrentNode = Diag.TempNode;
		break;

		case "First time":
			if (!bDisableMapEnter)
			{
				if (npchar.id == "BlackBeardNPC")
				{
					dialog.text = "Qu'est-ce que vous voulez, bon sang ? (sort un pistolet)";
					link.l1 = "Du calme, l'ancien ! Je m'appelle " + GetFullName(Pchar) + ". J'ai entendu dire que vous cherchiez un capitaine chanceux.";
					link.l1.go = "Titch_1";
					link.l2 = "Hé, hé ! Je m'en vais déjà, du calme !";
					link.l2.go = "exit";
					if (pchar.questTemp.AnjelikaTichPrologue9_BlackBeard == "ATP9")	//Sinistra Анжелика Тич и Эдвард Тич (в будущем поменяем)
					{
						link.l1 = "Du calme, l'ancien ! Je m'appelle Angelica. J'ai entendu dire que vous cherchiez un capitaine chanceux.";
						link.l1.go = "AnjelikaTitch_1";
					}
					break;
				}
                if (CheckAttribute(NPChar, "EncType")  && NPChar.EncType == "war")
                {
Dialog.text = TimeGreeting() + ", "+ GetAddress_Form(NPChar)+" ! Je suis "+ GetFullName(NPChar) +" – capitaine de la marine de "+NationKingsName(NPChar)+". Qu'est-ce qui vous amène à bord de mon navire ?";
    			}
    			else
                {
Dialog.text = TimeGreeting() + ", "+ GetAddress_Form(NPChar)+" ! Je suis le capitaine " + GetFullName(NPChar)+". Qu'est-ce qui vous amène à bord de mon navire ?";
    			}
    			link.l1 = "Je m'appelle " + GetFullName(Pchar) + ". J'ai une affaire à vous proposer !";
    			link.l1.go = "quests";
                link.l2 = "Rien de spécial, je passais juste vous saluer !";
    			link.l2.go = "exit";
            }
            else
            {
Dialog.text = "Vous avez remarqué, " + GetAddress_Form(NPChar) + ", qu'une bataille fait rage ? Nous n'avons pas le temps de parler maintenant !";
    			link.l1 = "Vous avez raison ! Je retourne à mon navire.";
    			link.l1.go = "exit";
            }
			if (npchar.id == "TohmasPetit_TomasShip" && CheckAttribute(npchar, "TohmasPetit_Talked"))
			{
				dialog.text = "Capitaine, je n'ai plus d'affaires avec vous. Je dois vous prier de quitter mon navire.";
				link.l1 = "Très bien, capitaine. Adieu.";
				link.l1.go = "exit";
				link.l2 = "D'accord, d'accord, ne vous mettez pas dans tous vos états. Je m'en vais déjà.";
				link.l2.go = "exit";
				npchar.dialog.currentnode = "First time";
				Diag.TempNode = "First time"; // Борода: без этого case "Exit" перезатирает CurrentNode старым TempNode
				break;
			}
			Diag.TempNode = "first time";
 		break;

        case "quests":
            if (!CheckAttribute(NPChar, "MainCaptanId")  || NPChar.MainCaptanId == pchar.GenQuest.CaptainId)
            {
Dialog.text = "Je vous écoute attentivement, " + GetAddress_Form(NPChar)+".";
                link.l1 = "Je voulais connaître les dernières nouvelles de l'archipel.";
                //homo 25/06/06
                link.l1.go = "rumours_capitan";
                //
                if (CheckAttribute(NPChar, "EncGroupName")) // только для фантомов грабёж
                {
                    link.l2 = RandPhraseSimple("Vous savez qui je suis ? Je crois qu'il est clair que les canons de mon navire peuvent transformer votre rafiot en passoire. Réglons ça à l'amiable. Une rançon me conviendra parfaitement.",
                                               "La mer... Et nous sommes seuls... Et si on apaisait un peu mes gars, pour votre sécurité ?");
                    link.l2.go = "Talk_board";
                }
                if (CheckAttribute(NPChar, "Ship.Mode") && NPChar.Ship.Mode == "Trade")
                {
	           		link.l3 = "D'oם venez-vous ?";
	    			link.l3.go = "price_1";
	    				link.l4 = "On fait du commerce ?";
	    				if (SeaTrade_RepTooLow()) link.l4.go = "Trade_RepBad"; // LEO: плохая репутация ГГ -> отказ в торговле
	    				else link.l4.go = "Trade_1";
    			}
				//--> квест мэра, поиски пирата
				if (CheckAttribute(pchar, "GenQuest.DestroyPirate"))
				{
	    			link.l6 = "Je cherche un navire pirate qui opère dans ces eaux. Avez-vous vu quelque chose de suspect ?";
	    			link.l6.go = "MQ_step_1";
				}
				//<-- квест мэра, поиски пирата
				//--> Квест ***Клан Ламбрини*** Sinistra
				if (CheckAttribute(pchar, "questTemp.PDM_CL_Ishem") && npchar.name == "Antonio" && npchar.lastname == "de Galvez")
				{
	    			link.l10 = "La famille Lambrini vous salue ! (attaquer)";
	    			link.l10.go = "Antonio_Bitva";
					link.l11 = "Quelqu'un veut vous tuer. (trahir Lambrini)";
	    			link.l11.go = "Antonio_1_4";
				}
				//<-- Квест ***Клан Ламбрини*** Sinistra
				//--> Квест ***Странные вещи творятся на архипелаге*** Sinistra
				if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_SprositKapitanov_v_more"))
				{
	    			link.l10 = "Je m'intéresse à la frégate noire qui a quitté le port la nuit dernière. Savez-vous quelque chose à son sujet ?";
	    			link.l10.go = "PKM_SvtvA_Deti_Plachut";
				}
				//<-- Квест ***Странные вещи творятся на архипелаге*** Sinistra
    			link.l5 = "Vous voulez vous détendre ?";
			    link.l5.go = "Play_Game";
				if (npchar.id == "TohmasPetit_TomasShip")
				{
					link.l12 = "Salutations, capitaine. Ma visite est strictement professionnelle. Le bruit court qu'un certain Thomas Petit et sa compagne Madeline LeBlanc sont passagers sur votre sloop. J'ai besoin que vous me les livriez.";
					link.l12.go = "TohmasPetit_Ship_Exposition";
				}
                link.l9 = "Je crois que je dois y aller !";
    			link.l9.go = "exit";
			}
			else
			{
Dialog.text = "Je ne suis pas habilité à régler des affaires avec vous, adressez-vous au commandant de notre escadre. Il s'appelle " + GetFullName(characterFromID(NPChar.MainCaptanId))+
                              ", son navire : " + XI_ConvertString(RealShips[sti(characters[GetCharacterIndex(NPChar.MainCaptanId)].Ship.Type)].BaseName) + " '" + characters[GetCharacterIndex(NPChar.MainCaptanId)].Ship.Name + "'.";
                link.l1 = "Merci. C'est ce que je vais faire.";
                link.l1.go = "exit";
                Diag.TempNode = "Go_away_Good";
			}
        break;
		//--> Квест ***Странные вещи творятся на архипелаге*** Sinistra
		case "PKM_SvtvA_Deti_Plachut":
			dialog.text = "Je n'en ai aucune idée... mais plusieurs de mes hommes, qui l'observaient, m'ont assuré que, lorsque ce navire a levé l'ancre, ils ont entendu un enfant pleurer sur le pont.";
			link.l1 = "Compris. Bon, je dois y aller maintenant.";
			link.l1.go = "PKM_SvtvA_Deti_Plachut_2";
		break;
		case "PKM_SvtvA_Deti_Plachut_2":
			DialogExit();
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_SprositKapitanov_v_more");
			AddQuestRecord("PKM_Animists", "5");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
		break;
		//<-- Квест ***Странные вещи творятся на архипелаге*** Sinistra
		//--> Квест ***Клан Ламбрини*** Sinistra
		case "Antonio_Bitva":
			bDisableFastReload = true;
			chrDisableReloadToLocation = true;
			LAi_LocationFightDisable(loadedLocation, false);
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_SetRelation("", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("", "PDM_CL_Lodka");
			DialogExit();
		break;

		case "Antonio_1_4":
			dialog.text = "Et alors ? Si vous vouliez me surprendre, c'est raté. Lambrini veut ma mort, comme tous les autres contrebandiers d'ailleurs.";
			link.l1 = "J'ai une proposition à vous faire. Que diriez-vous si je vous donnais l'occasion de capturer ou de couler le navire de Lambrini ?";
			link.l1.go = "Antonio_1_6";
			link.l2 = "Eh bien, dans ce cas, adieu.";
			link.l2.go = "exit";
		break;

		case "Antonio_1_6":
			dialog.text = "Je donnerais ma main droite pour ça. Mais hélas, c'est impossible. Il a déjà acheté, semble-t-il, tous les douaniers des Caraïbes. Que puis-je faire seul ?";
			link.l1 = "Lambrini m'a proposé de l'aider à se débarrasser de vous. Il est sמr de ne pas pouvoir venir à bout de vous tout seul...";
			link.l1.go = "Antonio_1_7";
		break;

		case "Antonio_1_7":
			dialog.text = "Si vous travaillez pour les contrebandiers, nous n'avons rien à nous dire, "+ GetSexPhrase("señor", "señorita") +"...";
			link.l1 = "Euh, attendez, vous ne m'avez même pas laissé parler. Je peux dire à Lambrini que j'ai coulé votre navire. Après ça, tכt ou tard, il viendra ici, pensant qu'il n'est plus en danger. Et vous pourrez lui tendre une embuscade dans la baie, ou près de là.";
			link.l1.go = "Antonio_1_8";
		break;

		case "Antonio_1_8":
			dialog.text = "Intéressant... Ce plan pourrait marcher, "+ GetSexPhrase("señor", "señorita") +" "+pchar.name+". Et s'il réussit, je veillerai à ce que le señor gouverneur vous récompense généreusement !";
			link.l1 = "Et combien pensez-vous que pourrait valoir la tête de Lambrini ?";
			link.l1.go = "Antonio_1_9";
		break;

		case "Antonio_1_9":
			int Bonus = sti(pchar.rank);
			if (Bonus <= 6) Bonus = 1;
			if (Bonus >= 7 && Bonus <= 12) Bonus = 1.2;
			if (Bonus >= 13) Bonus = 1.5;
			int Plata2 = 20000 + 2000 * sti(pchar.rank) * Bonus;
			dialog.text = "Je dirais environ " + Plata2 + ". Nos revenus ont beaucoup baissé ces derniers temps, à cause des contrebandiers.";
			link.l1 = "Je pense que " + Plata2 + " est une rétribution suffisante. Donc, je dirai à Octavio Lambrini que vous êtes fini... Quand il arrivera, nous le capturerons ici. Quoi de plus simple ?";
			link.l1.go = "Antonio_1_10";
		break;

		case "Antonio_1_10":
			dialog.text = "Dès que vous aurez dit à Lambrini que je suis mort, revenez me voir immédiatement : je vous attendrai à l'église de 9 heures à 13 heures. Nous verrons ensuite ce qu'il faut faire.";
			link.l1 = "Prenez soin de vous, señor. Bonne chance !";
			link.l1.go = "Antonio_1_11";
		break;

		case "Antonio_1_11":
			sld = CharacterFromID("PDM_Octavio_Lambrini")
			sld.Dialog.Filename = "Quest\PDM\Clan_Lambrini.c";
			sld.dialog.currentnode   = "Octavio_3_1";
			DeleteAttribute(pchar, "questTemp.PDM_CL_Ishem");
			PChar.quest.PDM_CL_Antonio_Ubit.over = "yes";
			AddQuestRecord("PDM_Clan_Lambrini", "4");
			AddQuestUserData("PDM_Clan_Lambrini", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PDM_Clan_Lambrini", "sSex2", GetSexPhrase("", "e"));

			DialogExit();
		break;
		//<-- Квест ***Клан Ламбрини*** Sinistra
        case "Trade_RepBad":
			dialog.text = "Commercer ? Avec vous ? Votre sinistre réputation vous précède dans tout l'archipel. Les honnêtes gens ne veulent pas avoir affaire à vos semblables. Allez-vous-en.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "quests";
        break;

        case "Trade_1":
			dialog.text = "Pourquoi pas ?";
			link.l1 = "Allons voir la marchandise.";
			link.l1.go = "Trade_2";
			link.l2 = "J'ai changé d'avis.";
			link.l2.go = "exit";
		break;

		case "Trade_2":
			FillShipStore(NPChar);
	    	pchar.shiptrade.character = NPChar.id;
   			Diag.CurrentNode = Diag.TempNode;
		    DialogExit();
		    DeleteAttribute(pchar, "PriceList.StoreManIdx"); // не вести лог по кораблям
		    LaunchStore(SHIP_STORE);
		break;

        case "Play_Game":
			dialog.text = "Que proposez-vous ?";
			link.l1 = "Une partie de cartes pour un enjeu sérieux ?";
			link.l1.go = "Card_Game";
   			link.l2 = "Un coup de dés au poker-joker ?";
			link.l2.go = "Dice_Game";
			link.l10 = "Désolé, mais j'ai à faire.";
			link.l10.go = "exit";
		break;
        // карты -->
        case "Card_Game":
            if (!CheckNPCQuestDate(npchar, "Card_date_Yet") || isBadReputation(pchar, 30) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < 1+rand(2))
            {
                SetNPCQuestDate(npchar, "Card_date_Yet");
                dialog.text = "Je ne joue pas avec n'importe quels escrocs !";
    			link.l1 = "Comme vous voudrez.";
    			link.l1.go = "exit";
			}
			else
			{
                dialog.text = "Allons-y ! Je vais faire une petite pause dans les affaires du bord...";
    			link.l1 = "Parfait.";
    			link.l1.go = "Cards_begin";
    			link.l2 = "Quelles sont les règles du jeu ?";
    			link.l2.go = "Cards_Rule";
			}
		break;

		case "Cards_Rule":
   			dialog.text = XI_ConvertString("CardsRules")
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Cards_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Cards_begin":
Dialog.text = "Fixons la mise.";
			link.l1 = "Jouons à 100 pièces d'or la carte.";
			link.l1.go = "Cards_Node_100";
			link.l2 = "Jouons à 500 pièces d'or la carte.";
			link.l2.go = "Cards_Node_500";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit";
		break;

		case "Cards_Node_100":
		    if (sti(pchar.Money) < 300)
		    {
                dialog.text = "Vous plaisantez ? Vous n'avez pas un sou !";
                link.l1 = "דa arrive.";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 300)
		    {
                dialog.text = "דa me suffit, sinon il ne restera plus assez pour l'entretien du navire...";
                link.l1 = "Désolé.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "Bon, jouons à 100 piastres.";
			link.l1 = "Commençons !";
			link.l1.go = "Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
            pchar.GenQuest.Cards.iRate     = 100;
            pchar.GenQuest.Cards.SitType   = false;
		break;

		case "Cards_Node_500":
		    if (sti(pchar.Money) < 1500)
		    {
                dialog.text = "Vous n'avez pas assez d'argent !";
                link.l1 = "J'en aurai !";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 1500)
		    {
                dialog.text = "Non, de telles mises ne mènent à rien de bon.";
                link.l1 = "Peu importe.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "Bon, jouons à 500 piastres.";
			link.l1 = "Commençons !";
			link.l1.go = "Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
            pchar.GenQuest.Cards.iRate     = 500;
            pchar.GenQuest.Cards.SitType   = false;
		break;

		case "Cards_begin_go":
            Diag.CurrentNode = Diag.TempNode;
			DialogExit();
            LaunchCardsGame();
		break;
	    // карты <--
	    //  Dice -->
        case "Dice_Game":
            if (!CheckNPCQuestDate(npchar, "Dice_date_Yet") || isBadReputation(pchar, 30) || GetCharacterSkillToOld(pchar, SKILL_LEADERSHIP) < 1+rand(2))
            {
                SetNPCQuestDate(npchar, "Dice_date_Yet");
                dialog.text = "Je ne joue pas avec n'importe quels escrocs !";
    			link.l1 = "Comme vous voudrez.";
    			link.l1.go = "exit";
			}
			else
			{
				if (CheckNPCQuestDate(npchar, "Dice_date_begin"))
				{
					dialog.text = "Allez ! Le jeu n'a jamais fait de mal à la santé... seulement à la bourse...";
	    			link.l1 = "Parfait.";
	    			link.l1.go = "Dice_begin";
	    			link.l2 = "Quelles sont les règles du jeu ?";
	    			link.l2.go = "Dice_Rule";
    			}
    			else
    			{
					dialog.text = "Non, j'en ai assez pour aujourd'hui. Les affaires m'attendent.";
	    			link.l1 = "Comme vous voudrez.";
	    			link.l1.go = "exit";
				}
			}
		break;

		case "Dice_Rule":
   			dialog.text = XI_ConvertString("DiceRules");
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Dice_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Dice_begin":
Dialog.text = "Fixons la mise.";
			link.l1 = "Jouons à 50 pièces d'or le coup de dés.";
			link.l1.go = "Dice_Node_100";
			link.l2 = "Jouons à 200 pièces le coup de dés.";
			link.l2.go = "Dice_Node_500";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit";
		break;

		case "Dice_Node_100":
            if (!CheckDiceGameSmallRate())
		    {
                dialog.text = "Tout le monde sait que vous trichez. Je ne jouerai pas aux dés avec vous, un point c'est tout.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 300)
		    {
                dialog.text = "Vous plaisantez ? Vous n'avez pas un sou !";
                link.l1 = "דa arrive.";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 300)
		    {
                dialog.text = "Assez ! Il faut arrêter de jouer, sinon on va nous accuser de détournement et nous débarquer...";
                link.l1 = "Désolé.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "Bon, jouons à 50 pièces.";
			link.l1 = "Commençons !";
			link.l1.go = "Dice_begin_go";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
            pchar.GenQuest.Dice.iRate     = 50;
            pchar.GenQuest.Dice.SitType   = false;
		break;

		case "Dice_Node_500":
            if (!CheckDiceGameSmallRate())
		    {
                dialog.text = "Tout le monde sait que vous trichez. Je ne jouerai pas aux dés avec vous, un point c'est tout.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit";
			    break;
		    }
			if (!CheckDiceGameBigRate())
		    {
                dialog.text = "J'ai entendu dire que vous jouiez très bien. Je ne jouerai pas avec vous à des mises aussi élevées.";
                link.l1 = "Et si on misait moins ?";
			    link.l1.go = "Dice_Node_100";
				link.l2 = "Désolé, je dois y aller.";
			    link.l2.go = "exit";
			    break;
		    }

			if (sti(pchar.Money) < 1500)
		    {
                dialog.text = "Vous vous moquez de moi ? Vous n'avez pas assez d'argent !";
                link.l1 = "J'en aurai !";
			    link.l1.go = "exit";
			    break;
		    }
		    if (sti(npchar.Money) < 1500)
		    {
                dialog.text = "Non, de telles mises ne mènent à rien de bon.";
                link.l1 = "Peu importe.";
			    link.l1.go = "exit";
			    break;
		    }
   			dialog.text = "Bon, jouons à 200 pièces.";
			link.l1 = "Commençons !";
			link.l1.go = "Dice_begin_go";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
            pchar.GenQuest.Dice.iRate     = 200;
            pchar.GenQuest.Dice.SitType   = false;
		break;

		case "Dice_begin_go":
            SetNPCQuestDate(npchar, "Dice_date_begin");
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
            LaunchDiceGame();
		break;
	    // Dice <--
        case "price_1":
			if (CheckNPCQuestDate(npchar, "trade_date"))
			{
                SetNPCQuestDate(npchar, "trade_date");
				iMoney = findPriceStoreMan(NPChar);
	            if (iMoney == -1)
	            {
	                Dialog.Text = "Pourquoi voulez-vous savoir ça ? C'est mon affaire personnelle.";
					Link.l1 = "Comme vous voudrez.";
					Link.l1.go = "exit";
	            }
	            else
	            {
                    sld = &Characters[iMoney];
                    pchar.PriceList.ShipStoreIdx = iMoney;

					Dialog.Text = "Je viens de la ville de " + GetCityName(sld.City) + ".";
					Link.l1 = "Quels sont les prix des marchandises au magasin du coin ?";
					Link.l1.go = "price_2";
					Link.l9 = "Je dois y aller maintenant.";
					Link.l9.go = "exit";
				}
			}
			else
			{
                Dialog.Text = "Je vous ai déjà tout dit. Ne m'ennuyez pas avec des broutilles.";
				Link.l1 = "Oui, vous avez raison. Au revoir.";
				Link.l1.go = "exit";
            }
		break;

		case "price_2":
            sld = &Characters[sti(pchar.PriceList.ShipStoreIdx)];
			SetPriceListByStoreMan(&Colonies[FindColony(sld.City)]);
			Dialog.Text = "Les voici... (vous avez reçu un résumé des prix des marchandises).";
			Link.l1 = "Merci beaucoup !";
			Link.l1.go = "exit";
			PlaySound("interface\important_item.wav");
		break;

        case "Talk_board":
            if ((Group_GetCharactersNum(NPChar.EncGroupName) - Group_GetDeadCharactersNum(NPChar.EncGroupName)) > GetCompanionQuantity(PChar) && rand(11) > GetCharacterSkillToOld(PChar, SKILL_FORTUNE))
            {
Dialog.text = "Ha ha ! Elle est bonne, celle-là. D'autant plus que j'ai plus de navires que vous. Remontez sur votre navire et coulez avec lui.";
                link.l1 = "Plus nombreux ne veut pas dire plus puissant...";
                link.l1.go = "Boarding";
            }
            else
            {
                if(rand(21) > (GetSummonSkillFromNameToOld(PChar, SKILL_GRAPPLING) + GetSummonSkillFromNameToOld(PChar, SKILL_LEADERSHIP)) )
                {
Dialog.text = "Vous n'auriez pas dמ commencer vos sales affaires à bord de mon navire, capitaine. Je vais faire preuve de clémence et vous laisser retourner à votre navire pour couler avec lui.";
                    link.l1 = "On verra bien qui ira nourrir les requins aujourd'hui !";
                    link.l1.go = "Boarding";
                }
                else
                {
                    Pchar.GenQuest.MoneyForCaptureShip = makeint(100 + (Group_GetCharactersNum(NPChar.EncGroupName) - Group_GetDeadCharactersNum(NPChar.EncGroupName))*(7 - sti(RealShips[sti(NPChar.Ship.Type)].Class))*(1+rand(10))*500);
Dialog.text = RandSwear() + "Oui, j'ai beaucoup entendu parler de vos exactions. Comme vous voudrez, mais souvenez-vous-en : " +
                                  XI_ConvertString(NationShortName(sti(NPChar.nation))+"hunter") + " ne vous le pardonnera pas !";
                    link.l1 = "Parfait. Une somme de "+Pchar.GenQuest.MoneyForCaptureShip+" pièces d'or me convient, "+GetAddress_FormToNPC(NPChar)+".";
                    link.l1.go = "Capture";
                    link.l2 = "Oh. Allons. Je plaisantais !";
                    link.l2.go = "exit";
                }
            }
            // тут нужен учёт запрета повторного наезда
            Diag.TempNode = "Go_away";
			sld = characterFromId(pchar.GenQuest.CaptainId);
            sld.talk_date_Go_away =  lastspeakdate(); // boal злопамятность :)
        break;

        case "rumours":
			Dialog.Text = SelectRumour(); // to_do
			Link.l1 = RandPhraseSimple(RandSwear() + "C'est très intéressant. Une autre question ?",
                                     "Encore une chose.");
			Link.l1.go = "quests";
			Link.l2 = RandPhraseSimple("Merci, je dois prendre congé.",
                                     "Bonne journée.");
			Link.l2.go = "exit";
			Diag.TempNode = "quests";
		break;

		case "Go_away":
			Dialog.Text = "Descendez de mon navire !";
			Link.l1 = "Je m'en vais.";
			Link.l1.go = "exit";
			Diag.TempNode = "Go_away";
		break;

		case "Go_away_Good":
			Dialog.Text = "Notre conversation est terminée. Je ne vous apprendrai rien de nouveau, "+GetAddress_Form(NPChar)+".";
			Link.l1 = "Je vois. א bientכt en mer !";
			Link.l1.go = "exit";
			Diag.TempNode = "Go_away_Good";
		break;

        case "Capture":
            Diag.TempNode = "Go_away";
            Dialog.Text = "Prenez ! Et maintenant, dehors !";
			Link.l1 = "Parfait !";
			Link.l1.go = "exit";
			AddMoneyToCharacter(pchar, sti(Pchar.GenQuest.MoneyForCaptureShip));
			ChangeCharacterReputation(pchar, -5);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			ChangeCharacterHunterScore(pchar, NationShortName(sti(NPChar.nation)) + "hunter", 7 + rand(10));
        break;

        case "Boarding":
            if (CheckAttribute(NPChar, "MainCaptanId"))
            {
                PChar.StartBattleAfterDeck = true;
                PChar.StartBattleMainCaptanId = NPChar.MainCaptanId;
                PChar.StartBattleEncGroupName = NPChar.EncGroupName;
            }
            DialogExit();
            Diag.CurrentNode = Diag.TempNode;
        break;

        case "QuestAboardCabinDialog":  // тестовый диалог, в игре не работает, для метода SetQuestAboardCabinDialog
			Diag.TempNode = "QuestAboardCabinDialog";
            Dialog.Text = "Attendez, vous allez me tuer comme ça. Que voulez-vous de moi ?";
			Link.l1 = "Tuer !";
			Link.l1.go = "QuestAboardCabinDialog_1";
			Link.l2 = "Capturer.";
			Link.l2.go = "QuestAboardCabinDialog_2";
			Link.l3 = "Donne-nous la carte, Billy (c)";  // предмет, далее не ясно или  QuestAboardCabinDialog_1 или QuestAboardCabinDialog_2
			Link.l3.go = "QuestAboardCabinDialog_3";  // можно закодить покидание корабля, но экипаж уже вырезан и тп...
        break;

        case "ContraHunterCabin":  // captain of the contraband-freight pirate hunters surrenders in his cabin
			Diag.TempNode = "ContraHunterCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				"Arrêtez, ne me tuez pas ! Vous avez gagné... Et moi qui espérais une proie facile. Je chasse les gens de votre espèce, ceux qui transportent la cargaison des autres.",
				"Assez, je me rends ! Bon sang... vous transportiez une belle prise. Je guettais les messagers comme vous : de l'argent facile, je pensais...");
			Link.l1 = "Une proie facile, hein ? וtouffe-toi avec !";
			Link.l1.go = "QuestAboardCabinDialog_Finish"; // finish off the wounded captain (fight, no heal)
			Link.l2 = "Estimez-vous heureux d'être encore en vie aujourd'hui. Rendez-vous.";
			Link.l2.go = "ContraHunterCabin_Spare"; // mercy - leadership & sneak bonus
		break;

        case "ContraHunterCabin_Spare":  // sparing the hunter captain: reward for mercy
			Dialog.Text = "D'accord, vous avez gagné ! Ne me tuez pas...";
			Link.l1 = "Vis, alors. Considère que tu t'es acheté un jour de plus.";
			Link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 150); // +leadership for mercy
			AddCharacterExpToSkill(pchar, "Sneak", 100);      // +sneak
			AddDialogExitQuestFunction("QuestAboardCabinDialogSurrender");
		break;

        case "GentlemenHunterCabin":  // captain of the governor-freight interceptors surrenders in his cabin (several variants, lore - hired to intercept the cargo)
			Diag.TempNode = "GentlemenHunterCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				RandPhraseSimple(
					"Arrêtez, ne me tuez pas ! Vous avez gagné... On nous avait envoyés intercepter votre cargaison : ce doit être un fret précieux, vu ce qu'on nous payait. דa n'a pas marché.",
					"Assez, je me rends ! Bon sang... Tout ce qu'on m'a dit, c'est de guetter le navire à la cargaison spéciale et de m'en emparer. On dirait que je me suis trompé de proie."),
				RandPhraseSimple(
					"Attendez, doucement ! Je l'admets, vous avez gagné. Ce n'est pas de mon plein gré que je me suis lancé à vos trousses : on m'a payé pour que votre cargaison n'arrive pas à destination.",
					"דa suffit, vous avez gagné ! Ne me tuez pas... J'avais un contrat : intercepter une cargaison importante. Ne me demandez pas qui m'a engagé ; ces noms-là ne se prononcent pas à voix haute."));
			Link.l1 = "Tu pensais intercepter ma cargaison ? Va au diable !";
			Link.l1.go = "QuestAboardCabinDialog_Finish"; // finish off the wounded captain (fight, no heal)
			Link.l2 = "Estimez-vous heureux d'être encore en vie aujourd'hui. Rendez-vous.";
			Link.l2.go = "GentlemenHunterCabin_Spare"; // mercy - prisoner + exp
		break;

        case "GentlemenHunterCabin_Spare":  // sparing the interceptor captain: take prisoner + exp for mercy
			Dialog.Text = RandPhraseSimple(
				"D'accord, vous avez gagné ! Ne me tuez pas...",
				"Merci de m'avoir laissé la vie, capitaine. Considérez que je suis votre obligé.");
			Link.l1 = "Vis, alors. Considère que tu t'es acheté un jour de plus.";
			Link.l1.go = "exit";
			int ghRew = 100; // escort interceptors (GovEscortHalfReward) give half - 50; set in SetQuestAboardCabinDialog
			if (CheckAttribute(pchar, "GenQuest.GentlemenReward")) ghRew = sti(pchar.GenQuest.GentlemenReward);
			AddCharacterExpToSkill(pchar, "Sneak", ghRew);      // +sneak for mercy
			AddCharacterExpToSkill(pchar, "Leadership", ghRew); // +leadership for mercy
			AddDialogExitQuestFunction("QuestAboardCabinDialogSurrender");
		break;

        case "FortHunterCabin":  // privateer (commandant-freight interceptor) surrenders in his cabin; lore - letter of marque and war
			Diag.TempNode = "FortHunterCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				RandPhraseSimple(
					"Arrêtez, rengainez votre lame ! Vous avez gagné... J'ai une lettre de marque : intercepter les cargaisons militaires de l'ennemi. Pas de chance d'être tombé sur vous.",
					"Assez, je me rends ! L'Amirauté paie de belles pièces pour chaque cargaison militaire saisie... On dirait que cet argent ira à quelqu'un d'autre maintenant."),
				RandPhraseSimple(
					"Attendez, ne frappez pas ! J'admets ma défaite. C'est la guerre, capitaine : vos munitions ne devaient jamais atteindre ce fort. Je ne faisais qu'obéir aux ordres.",
					"דa y est, vous avez gagné ! Nous suivons votre cargaison depuis le port : la garnison ennemie ne devait pas recevoir un seul tonnelet de poudre. דa n'a pas marché."));
			Link.l1 = "Alors, tu chassais ma cargaison ? La guerre, c'est la guerre. Va au diable !";
			Link.l1.go = "QuestAboardCabinDialog_Finish"; // finish off the wounded captain (fight, no heal)
			Link.l2 = "Estimez-vous heureux d'être encore en vie aujourd'hui. Rendez-vous.";
			Link.l2.go = "FortHunterCabin_Spare"; // mercy - prisoner + exp (same as ContraHunter)
		break;

        case "GuildEnforcerCabin":  // captain of the Guthrie Trading House (freight forfeit collection) surrenders in his cabin
			Diag.TempNode = "GuildEnforcerCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				"Arrêtez, ne frappez pas !.. Vous avez gagné. Vous avez contrarié la Maison de commerce Guthrie, et Dieu sait que vous auriez mieux fait de simplement payer.",
				"Assez, je me rends ! Nous ne sommes pas des pirates : nous naviguons sous le fanion des Guthrie. Le commerce de tout l'archipel repose sur cette famille, et elle n'a pas l'habitude de pardonner aux débiteurs. Payez, et plus aucun des nכtres ne se dressera sur votre route.");
			Link.l1 = "Dis à la guilde que je rembourserai tout dans un mois. Tu as ma parole.";
			Link.l1.go = "GuildEnforcerCabin_Word";
			Link.l2 = "Estimez-vous heureux d'être encore en vie aujourd'hui. Rendez-vous.";
			Link.l2.go = "GuildEnforcerCabin_Spare";
			Link.l3 = "Une dette ? Quelle dette ? Va toucher ta paie au fond de la mer !";
			Link.l3.go = "QuestAboardCabinDialog_Finish"; // finish off the wounded captain (fight, no heal), the debt remains
		break;

        case "GuildEnforcerCabin_Word":  // gave the word to repay within a month: the captain leaves by longboat to deliver it, the squadron is recalled
			Dialog.Text = "La parole d'un capitaine n'est pas un vain mot : la Maison Guthrie l'acceptera. Le navire est à vous, par droit d'abordage ; laissez-moi la chaloupe, et je transmettrai votre parole. Un mois, " + GetAddress_FormToNPC(NPChar) + ". Pas un jour de plus. Si vous ne remboursez pas, il n'y aura aucune pitié : ni pour vous, ni pour votre parole.";
			Link.l1 = "Entendu. La chaloupe est à toi : c'est toi qui rameras.";
			Link.l1.go = "exit";
			GuildDebt_GiveWord();
			AddDialogExitQuestFunction("QuestAboardCabinDialogNotBattle"); // капитан НЕ пленник: ушёл на шлюпке с твоим словом
		break;

        case "GuildEnforcerCabin_Spare":  // mercy without the word: prisoner, but the debt and the waves remain
			Dialog.Text = "D'accord, vous avez gagné ! Ne me tuez pas... Mais sachez-le : la Maison Guthrie en enverra d'autres. Une dette est une dette.";
			Link.l1 = "Qu'ils viennent. Vis.";
			Link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 100); // +leadership for mercy
			AddDialogExitQuestFunction("QuestAboardCabinDialogSurrender");
		break;

        case "FortHunterCabin_Spare":  // sparing the privateer captain: take prisoner + exp for mercy
			Dialog.Text = RandPhraseSimple(
				"D'accord, vous avez gagné ! Ne me tuez pas...",
				"Merci, capitaine. La guerre est la guerre, mais je me souviendrai de cette dette d'honneur.");
			Link.l1 = "Vis, alors. Considère que tu t'es acheté un jour de plus.";
			Link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 50); // +leadership for mercy
			AddCharacterExpToSkill(pchar, "Sneak", 50);      // +sneak
			AddDialogExitQuestFunction("QuestAboardCabinDialogSurrender");
		break;

        case "GWIK_MutineerCabin":  // Gregg: the runaway GWIC captain (mutiny 'threaten' branch), boarded at sea - the player decides his fate
			Diag.TempNode = "GWIK_MutineerCabin";
			Dialog.Text = "Retenez votre lame !.. Vous avez gagné, le Hollandais. Alors, c'est la Compagnie qui vous envoie pour me ramener ? Allez-y : mettez-moi aux fers et traînez-moi devant eux comme un chien, ou transpercez-moi ici, qu'on en finisse.";
			Link.l1 = "Tu rendras des comptes à la Compagnie. Rends-toi : tu es mon prisonnier.";
			Link.l1.go = "GWIK_MutineerCabin_Prisoner";
			Link.l2 = "Une fin de traître pour un traître. Meurs.";
			Link.l2.go = "GWIK_MutineerCabin_Kill";
		break;

        case "GWIK_MutineerCabin_Prisoner":  // Gregg: take him alive - delivered as a passenger to any GWIC office
			Dialog.Text = "...Soit. Une cellule vaut mieux que les profondeurs. Passez devant.";
			Link.l1 = "Aux fers. Avance.";
			Link.l1.go = "exit";
			pchar.GWIK.Job.MutinyFate = "prisoner"; // read in GWIK_RansomBoarded (utils.c)
			AddCharacterExpToSkill(pchar, "Leadership", 100); // command xp for taking the runaway alive
			AddDialogExitQuestFunction("QuestAboardCabinDialogQuestSurrender"); // Gregg: quest capture - takes the ONE real captain (stores GenQuest.LastQuestPrisonerIdx) + sets DontRansackCaptain so the ransack form won't produce a SECOND prisoner; caught by NPC_Death -> GWIK_RansomBoarded
		break;

        case "GWIK_MutineerCabin_Kill":  // Gregg: cut him down - no prisoner; report the execution at a GWIC office for a bounty
			Dialog.Text = "Alors, réglons ça à la manière des marins !";
			Link.l1 = "C'est ce que nous allons faire.";
			Link.l1.go = "exit";
			pchar.GWIK.Job.MutinyFate = "killed"; // read in GWIK_RansomBoarded (utils.c) - no prisoner spawned
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattle"); // no heal - resumes the fight at ~10 HP and dies on the next blow
		break;

        case "FortAgentCabin":  // enemy-nation courier whose offers were refused, then boarded: bargains for the convoy
			Diag.TempNode = "FortAgentCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				"Retenez votre lame ! Vous avez gagné... mais nous savons tous les deux que vous ne livrerez pas cette cargaison en paix. Faisons autrement : rendez-moi les navires du convoi et laissez-moi une poignée de vos marins pour les manœuvrer, et je vous paierai cinq fois le prix de la guilde, ici et maintenant.",
				"Assez, je me rends ! Voici le marché : le convoi est à moi, avec quelques-uns de vos hommes pour le manœuvrer. L'or est à vous, cinq fois ce que la guilde a promis. Nous nous séparons, chacun avec son dמ.");
			Link.l1 = "Marché conclu. Prenez le convoi et les hommes. (" + FindRussianMoneyString(sti(pchar.CargoQuest.iMoney) * 5) + ")";
			Link.l1.go = "FortAgentCabin_Deal";
			Link.l2 = "Non. Cette cargaison arrivera à destination, et toi, tu vas rencontrer ton Créateur.";
			Link.l2.go = "QuestAboardCabinDialog_Finish"; // kill - fight, the convoy stays with the player
		break;

        case "FortAgentCabin_Deal":  // accepted: x5 + convoy + a handful of crew to the agent, he leaves; no exp / no nation rep
			Dialog.Text = "Sage décision, capitaine. Mes hommes vont prendre les navires, et voici l'or : cinq fois plus, comme convenu. Vos marins, je vous les rendrai une fois à terre... peut-être. Adieu.";
			Link.l1 = "Dehors.";
			Link.l1.go = "exit";
			AddDialogExitQuestFunction("FortAgent_CabinDeal");             // x5 + convoy + crew + agent keeps his ship and sails off (no exp/rep, NO capture form)
		break;

        case "SmugRevengeCabin":  // мститель берегового братства (за вырезанных смуглеров после откупа от патруля): пощады нет
			Diag.TempNode = "SmugRevengeCabin";
			Dialog.Text = RandSwear() + RandPhraseSimple(
				RandPhraseSimple(
					"Vous n'auriez pas dמ commencer, capitaine... La Confrérie de la Cכte ne pardonne pas le massacre des siens. Aujourd'hui, vous gagnez, mais d'autres viendront après nous. Encore et encore, jusqu'à ce que la mer vous engloutisse.",
					"Kh-he... Vous pensiez massacrer cette bande dans la baie et que l'eau cacherait tout ? La Confrérie a le bras long et la mémoire longue. Vous n'auriez pas dמ commencer..."),
				RandPhraseSimple(
					"Maudit sois-tu... Ces gars sur le rivage commerçaient honnêtement avec toi, et tu les as égorgés comme des moutons. Tu n'aurais pas dמ commencer, capitaine.",
					"Attendez... laissez-moi parler. Nous sommes venus réclamer votre sang pour nos frères du rivage. Si ce n'est pas nous, d'autres viendront se faire payer. Vous n'auriez pas dמ commencer, oh non..."));
			Link.l1 = "Salue la Confrérie de ma part. Au fond de la mer."; // пощады нет - ни ему, ни тебе
			Link.l1.go = "SmugRevengeCabin_1";
		break;

        case "SmugRevengeCabin_1":  // возмездие без пощады: добиваем, -10 к отношению контрабандистов за каждого капитана
			Dialog.Text = "Eh bien, on verra bien !";
			Link.l1 = "Qu'y a-t-il à voir ?";
			Link.l1.go = "exit";
			ChangeContrabandRelation(pchar, -10);
			ChangeCharacterReputation(pchar, -5); // добить сдавшегося - удар по репутации ГГ
			AddCharacterExpToSkill(pchar, "Leadership", 100); // +авторитет: одолеть аса братства дорогого стоит
			AddCharacterExpToSkill(pchar, "Sneak", 200);      // +скрытность: концы мстителей - в воду
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattle");
		break;

        case "QuestAboardCabinDialog_1":
			Dialog.Text = "Eh bien, on verra bien !";
			Link.l1 = "Qu'y a-t-il à voir ?";
			Link.l1.go = "exit";
			// тут можно восстановить НР противника (NPChar) или добавить парочку гардов против ГГ
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattle"); // тут ругань обратно
		break;

        case "QuestAboardCabinDialog_Finish":  // LEO: finish off the wounded captain - fight WITHOUT restoring HP (unlike _1 with LAi_SetCurHPMax). Captain stays near death - one hit finishes him. For freight hunters: "if you don't want to take him prisoner".
			Dialog.Text = "Eh bien, on verra bien !";
			Link.l1 = "Qu'y a-t-il à voir ?";
			Link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattle"); // no heal - captain resumes the fight at ~10 HP
		break;

		case "QuestAboardCabinDialog_2":
			Dialog.Text = "D'accord, tu l'as cherché !";
			Link.l1 = "Il fallait le dire tout de suite !";
			Link.l1.go = "exit";
			AddDialogExitQuestFunction("QuestAboardCabinDialogSurrender");
		break;

		case "QuestAboardCabinDialog_3":
			Dialog.Text = "Oui, prends !";
			Link.l1 = "Voilà qui est bien, maintenant rends-toi.";
			if (rand(1) == 1)  // пример!!!
			{
				Link.l1.go = "QuestAboardCabinDialog_2";
			}
			else
			{
			    Link.l1.go = "QuestAboardCabinDialog_3_1";
			}
			TakeNItems(NPChar, "Chest", -1);
			TakeNItems(pchar, "Chest", 1);
		break;

		case "QuestAboardCabinDialog_3_1":
			Dialog.Text = ""+ "Tu es venu, tu as tout sali autour de toi, tu as tout pris, et maintenant tu veux faire de moi un esclave ? Va te faire voir !";
			Link.l1 = "Alors prépare-toi pour ton dernier voyage.";
			Link.l1.go = "QuestAboardCabinDialog_1";
		break;
		//eddy. квест мэра, поиски пирата
		case "MQ_step_1":
			Dialog.Text = "Non, je n'ai vu aucun navire suspect qui ressemble à un pirate.";
			Link.l1 = "Je vois.";
			Link.l1.go = "exit";
		break;

		//homo Наводка на купца
		case "MerchantTrap_Abordage":

			Dialog.Text = "Au nom de "+NationKingsName(NPChar)+" : rendez-vous, "+ GetSexPhrase("pirate sournois", "scélérate sournoise") +" ! On vous laissera la vie sauve jusqu'à un procès équitable, oם vous répondrez de chaque prise "+NationNameSK(sti(NPChar.nation))+" que vous avez pillée.";
			Link.l1 = "Quoi qu'il en soit, rendez-vous plutכt vous-même.";
			Link.l1.go = "exit";
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam"); // тут ругань обратно
		break;

		case "Siegehelp":

            ref rchar = Group_GetGroupCommander(sGroup);
            if (NPChar.id == rchar.id)
            {

    			dialog.text = "Je vous écoute, mais exposez vite le but de votre visite : nous combattons " + fort +
                          " et je dois diriger la bataille !";
                link.l1 = "C'est justement pour ça que je suis là, " + GetAddress_FormToNPC(NPChar) + ".";
                link.l1.go = "attack_fort";

                link.l2 = "Dans ce cas, je ne vous retiens pas plus longtemps. Au revoir, "+ GetAddress_FormToNPC(NPChar) + ".";
                link.l2.go = "exit";

            }
            else
            {
Dialog.text = "Je ne suis pas habilité à régler des affaires avec vous, adressez-vous au commandant de notre escadre. Il s'appelle " + GetFullName(rchar)+
                              ", son navire : " + XI_ConvertString(RealShips[sti(rchar.Ship.Type)].BaseName) + " '" + rchar.Ship.Name + "'.";
                link.l1 = "Merci. C'est ce que je vais faire.";
                link.l1.go = "exit";

            }
            Diag.TempNode = "Siegehelp";

		break;

		case "attack_fort":
                dialog.text = "Et de quoi s'agit-il ?";
                link.l1 = "Je peux vous aider à vaincre le fort de la colonie de " +GetConvertStr(aData.Colony+" Town", "LocLables.txt")+ " et à prendre la ville ; quant au butin obtenu en cas de succès, nous le partagerons entre nous.";
                link.l1.go = "Siegehelp_1";
                link.l2 = "En fait, mon affaire ne mérite guère votre attention. Au revoir, "+ GetAddress_FormToNPC(NPChar) + ".";
                link.l2.go = "exit";
                Diag.TempNode = "Siegehelp_0";
		break;

		case "Siegehelp_0":
Dialog.text = "Encore vous ? Je croyais que nous avions déjà tout réglé ?";
            link.l1 = "Vous avez raison, j'avais oublié.";
			link.l1.go = "exit";
			NPChar.DeckDialogNode = "Siegehelp_0";
            Diag.TempNode = "Siegehelp_0";

		break;

		case "Siegehelp_1":
            SiegeResult("");
            if (sti(aData.win)==0)
            {
                dialog.text = "Et quelle part du butin comptez-vous recevoir ?";
                link.l1 = "La moitié.";
                link.l1.go = "Big_part";
                link.l2 = "Un tiers.";
                link.l2.go = "Middle_part";
                link.l3 = "Un quart.";
                link.l3.go = "Small_part";
            }
            else
            {
                dialog.text = "Je n'ai pas besoin de vos services, capitaine ! Je n'ai besoin de l'aide de personne, car je vais m'emparer de cette colonie de toute façon.";
                link.l1 = "Comment pouvez-vous en être si sמr, " + GetAddress_FormToNPC(NPChar) + ", l'échec peut frapper n'importe qui.";
                link.l1.go = "attack_fort_03";
                link.l2 = "Dans ce cas, je ne vous retiens pas plus longtemps, " + GetAddress_FormToNPC(NPChar) + ". Au revoir !";
                link.l2.go = "exit";
            }
			Diag.TempNode = "Siegehelp_0";

		break;

		case "attack_fort_03":


            if((sti(aData.iSquadronPower)*SquadronDamage - (ifortPower)*fortDamage) < 4000 || bBettaTestMode) // LEO: беттатест — 100% согласие
            {
                dialog.text = "D'un autre cכté, mes navires ont déjà été bien malmenés dans cette bataille, et des renforts ne seraient pas de trop. Si vous acceptez " + GetPart(4) + ", je pense que nous pourrons nous entendre.";
                link.l1 = "דa me convient, " + GetAddress_FormToNPC(NPChar) + ". Je vais tenter de prendre le fort d'assaut, et vous, de votre cכté, vous nous soutiendrez par le feu des canons de vos navires.";
                link.l1.go = "attack_fort_04";
                aData.PartAttaksFort = 4;
                link.l2 = "Je ne suis pas si bon marché, " + GetAddress_FormToNPC(NPChar) + ". Désolé d'avoir interrompu vos importantes affaires. Au revoir.";
                link.l2.go = "exit";
            }else{
                dialog.text = "Il y a assez de navires dans mon escadre pour réduire ce fort en miettes, ce n'est qu'une question de temps. Et maintenant, daignez quitter mon navire : la victoire m'attend !";
                link.l1 = "Eh bien, dans ce cas, " + GetAddress_FormToNPC(NPChar) + ", permettez-moi de prendre congé. Au revoir !";
                link.l1.go = "exit";
            }
		    Diag.TempNode = "Siegehelp_0";
		break;
		case "Big_part":
            if( (sti(aData.iSquadronPower)*SquadronDamage - (ifortPower)*fortDamage) <= -1500 || bBettaTestMode) // LEO: беттатест — 100% согласие
            {
                dialog.text = "Les canons du fort ont gravement endommagé les navires de mon escadre, et l'issue de cette bataille pourrait ne pas tourner en notre faveur. J'accepte vos conditions et votre aide.";
                link.l1 = "Parfait, " + GetAddress_FormToNPC(NPChar) + ", dans ce cas, nous prendrons le fort d'assaut, et vous nous soutiendrez par le feu des canons de vos navires.";
                link.l1.go = "attack_fort_04";
                aData.PartAttaksFort = 2;
            }
            else
            {
                dialog.text = "Vous ne trouvez pas que c'est un peu beaucoup, capitaine ? De votre cכté : " + GetNumShips(GetCompanionQuantity(PChar)) +
                              ", dans mon escadre : " + GetNumShips(Group_GetCharactersNum(sGroup)) + ". Je peux vous offrir " + GetPart(4) +
                              ". Et je pense que c'est juste.";
                aData.PartAttaksFort = 4;
                link.l1 = "Je suis d'accord, " + GetAddress_FormToNPC(NPChar) + ", dans ce cas, je me charge de la prise du fort, et vous nous soutiendrez par le feu des canons de vos navires.";
                link.l1.go = "attack_fort_04";
                link.l2 = "Malheureusement, je ne pense pas, " + GetAddress_FormToNPC(NPChar) + ". Nous n'avons plus rien à nous dire. Au revoir.";
                link.l2.go = "exit";
            }
            Diag.TempNode = "Siegehelp_0";
        break;

        case "attack_fort_04":
            dialog.text = "Dès que le fort sera pris, nous commencerons immédiatement à débarquer des troupes sur le rivage, puis nous poursuivrons la bataille dans la ville même, oם j'espère vous retrouver.";
            link.l1 = "Restons-en là. א bientכt, " + GetAddress_FormToNPC(NPChar) + " !";
            link.l1.go = "exit";
            Diag.TempNode = "Siegehelp_0";
            PChar.quest.Union_with_Escadra = "Yes";
        break;

        case "Middle_part":
            if((sti(aData.iSquadronPower)*SquadronDamage - (ifortPower)*fortDamage) <= -600 || bBettaTestMode) // LEO: беттатест — 100% согласие
            {
                dialog.text = "Je crois que je vais accepter vos conditions. Une opération commune augmente mes chances de remporter cette bataille. Si l'affaire réussit, vous recevrez votre part du butin.";
                link.l1 = "Eh bien, c'est parfait, nous sommes d'accord, " + GetAddress_FormToNPC(NPChar) + ". Je vais immédiatement ordonner à mes hommes d'attaquer le fort.";
                link.l1.go = "attack_fort_04";
                aData.PartAttaksFort = 3;
            }else{
                dialog.text = "Vous ne trouvez pas que c'est un peu beaucoup, capitaine ? De votre cכté : " + GetNumShips(GetCompanionQuantity(PChar)) + ", dans mon escadre : " + GetNumShips(Group_GetCharactersNum(sGroup)) + ". Je peux vous offrir " + GetPart(4) + ". Et je pense que c'est juste.";
                link.l1 = "Je suis d'accord, " + GetAddress_FormToNPC(NPChar) + ", dans ce cas, je me charge de l'assaut du fort, et vous nous soutiendrez par le feu des canons de vos navires.";
                link.l1.go = "attack_fort_04";
                aData.PartAttaksFort = 4;
                link.l2 = "Malheureusement, je ne pense pas, " + GetAddress_FormToNPC(NPChar) + ". Nous n'avons plus rien à nous dire. Au revoir.";
                link.l2.go = "exit";
            }
            Diag.TempNode = "Siegehelp_0";
        break;

        case "Small_part":
            dialog.text = "Les navires de mon escadre sont épuisés par la bataille, des forces fraîches ne seront donc pas de trop. J'accepte ces conditions et votre proposition.";
            link.l1 = "Je me réjouis que nous ayons pu nous entendre, " + GetAddress_FormToNPC(NPChar) + ". Je vais immédiatement ordonner à mes hommes d'engager le combat et de lancer l'assaut sur le fort.";
            link.l1.go = "attack_fort_04";
            aData.PartAttaksFort = 4;
            Diag.TempNode = "Siegehelp_0";
        break;

		case "Talk_Capture_City":
            AfterTownBattle();  // все, все свободны
            LAi_LoginInCaptureTown(NPChar, false);
            aData.win = 1;
            EndOfTheSiege("End");
            NPChar.location = "";
            int ilt = makeint(sti(aData.loot)/sti(aData.PartAttaksFort));
            dialog.text = "Bonjour, capitaine ! La bataille a été rude, mais nous avons quand même réussi à briser la résistance acharnée des défenseurs de la ville. Le butin s'élève à " + sti(aData.loot)+
                          " pièces d'or. Et selon notre accord, vous recevez "+ilt+
                          ". Voici votre argent, vous l'avez bien mérité. Et maintenant, si vous voulez bien m'excuser, j'ai à faire.";
            link.l1 = "Dans ce cas, permettez-moi de prendre congé, " + GetAddress_FormToNPC(NPChar) + ". Au revoir !";
            link.l1.go = "exit";
            //AddDialogExitQuest("End_Siege_and_Attaks_City");

            Diag.TempNode = "no_return_02";
            AddMoneyToCharacter(PChar, ilt);
            ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
            ChangeCharacterReputation(PChar, 10);
            AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 80);
            AddCharacterExpToSkill(GetMainCharacter(), "Sailing", 100);
            AddCharacterExpToSkill(GetMainCharacter(), "Defence", 100);
            AddCharacterExpToSkill(GetMainCharacter(), "Accuracy", 100);
            AddCharacterExpToSkill(GetMainCharacter(), "Cannons", 100);
            AddCharacterExpToSkill(GetMainCharacter(), "Fortune", 80);
            aData.loot = sti(aData.loot) - ilt;
            if (CheckAttribute(PChar, "quest.LeaveTown")) Pchar.quest.LeaveTown.over = "yes";
            //--> слухи
            SiegeRumour("Le bruit court que vous avez aidé notre escadre lors de l'assaut d'une colonie "+NationNameSK(sti(aData.conation))+" : "+GetConvertStr(aData.Colony+" Town", "LocLables.txt")+" ! Nous vous en sommes si reconnaissants, "+ GetAddress_Form(NPChar)+".", "", sti(aData.nation), -1, 30, 3);
            //<-- слухи
		break;

        case "no_return_02":
            dialog.text = "Salutations, capitaine ! Vous avez affaire à moi ?";
            link.l1 = "Aucune, " + GetAddress_FormToNPC(NPChar) + ". Au revoir !";
            link.l1.go = "exit";
            Diag.TempNode = "no_return_02";
		break;

		case "GoldSquadron":
            ref rch = Group_GetGroupCommander("Sea_Head_of_Gold_Squadron");
            if (NPChar.id == rch.id)
            {
    			dialog.text = "Je vous écoute, mais exposez au plus vite le but de votre visite, je suis pressé. On m'a confié une mission importante et secrète, et de plus, j'ai ordre de couler en haute mer tous les navires suspects qui pourraient menacer notre convoi.";

                link.l1 = "Dans ce cas, je ne vous retiens pas plus longtemps. Au revoir, "+ GetAddress_FormToNPC(NPChar) + ".";
                link.l1.go = "exit";

            }
            else
            {
Dialog.text = "Je ne suis pas habilité à régler des affaires avec vous, adressez-vous au commandant de notre escadre. Il s'appelle " + GetFullName(rch)+
                              ", son navire : " + XI_ConvertString(RealShips[sti(rch.Ship.Type)].BaseName) + " '" + rch.Ship.Name + "'.";
                link.l1 = "Merci. C'est ce que je vais faire.";
                link.l1.go = "exit";

            }
            Diag.TempNode = "GoldSquadron";
		break;
		
		case "AnjelikaTitch_1":		//Sinistra Анжелика Тич и Эдвард Тич
Dialog.text = "Angelica ? J'avais une fille, Angelica. Sa mère, une dévergondée, m'a enlevé ma petite sous mon nez. Elle s'est enfuie avec un salaud... Et, bon sang, si j'avais réussi à les retrouver à l'époque, je les aurais fait passer tous les deux sous la quille.";
			link.l1 = "J'ai entendu une tout autre histoire.";
			link.l1.go = "AnjelikaTitch_2";
		break;
		
		case "AnjelikaTitch_2":
Dialog.text = "Ce qu'on raconte sur moi m'est égal. Vous êtes là pour affaires ? Alors écoutez : il est temps pour moi de me retirer dignement et de transmettre mon savoir et mes talents à un successeur. Mais je dois m'assurer qu'il le mérite.";
			link.l1 = "Votre successeur ? Et quels sont les critères de dignité ?";
			link.l1.go = "Titch_2";
			DeleteAttribute(pchar, "questTemp.AnjelikaTichPrologue9_BlackBeard");
		break;

		case "Titch_1":
Dialog.text = "Il y a de ça. Il est temps pour moi de me retirer dignement et de transmettre mon savoir et mes talents à un successeur. Mais je dois m'assurer qu'il le mérite.";
			link.l1 = "Votre successeur ? Et quels sont les critères de dignité ?";
			link.l1.go = "Titch_2";
		break;

		case "Titch_2":
Dialog.text = "Dans mes meilleures années, comme pirate, je n'avais pas d'égal : mon successeur ne doit donc pas être moins bon.";
			link.l1 = "Je vous écoute...";
			link.l1.go = "Titch_3";
		break;

		case "Titch_3":
			if (!CheckAttribute(pchar, "ShipsSurr")) pchar.ShipsSurr = 0;
Dialog.text = "Vous devez aborder 5 navires marchands et les forcer à se rendre, de sorte que leurs capitaines vous supplient de les épargner. Dès qu'ils voyaient mon fanion, mes adversaires se rendaient généralement sans combattre. Du moins, après que je suis devenu célèbre dans ces eaux.";
			link.l1 = "Ce sera rapide, ou très difficile. En tout cas, je ferai supplier les riches d'avoir pitié ! Vous verrez !";
			link.l1.go = "Titch_4";
		break;

		case "Titch_4":
Dialog.text = "Je dois vérifier votre niveau d'escrime, car c'est la base de tout pirate ou corsaire qui se respecte. Et si la chance vous a mordu les fesses, je veux vérifier en personne s'il en est bien ainsi. Jouons au vingt-et-un. Si vous perdez, mon pistolet vous mordra pour...";
			link.l1 = "Je comprends... Quelqu'un m'a vraiment mordu les fesses. Vous allez vérifier ? Et l'escrime, c'est mon affaire... J'écraserai n'importe qui ! Mais seulement dans un duel loyal. J'espère qu'il le sera.";
			link.l1.go = "Titch_5";
		break;

		case "Titch_5":
Dialog.text = "Pour qu'on raconte des légendes sur vous, il faut savoir les composer. Je veux entendre ce que vous savez de moi. Un vrai corsaire doit avoir l'esprit vif et la tête froide.";
			link.l1 = "Eh bien... J'ai beaucoup entendu parler de vous. Si c'est vrai ou non, vous me le confirmerez vous-même.";
			link.l1.go = "Titch_6";
		break;

		case "Titch_6":
Dialog.text = "Et enfin, la bataille navale. Personne ne vous aidera ni ne viendra à votre secours. Nous nous battrons à mort !";
			link.l1 = "Vous avez une frégate très impressionnante... דa ne s'annonce vraiment pas simple.";
			link.l1.go = "Titch_7";
		break;

		case "Titch_7":
			npchar.met = true;
Dialog.text = "Alors ?! Qu'en dites-vous ?";
			if (!CheckAttribute(npchar, "Duel"))
			{
				link.l1 = "Je pense avoir la force de laisser sur votre corps toute une histoire de coupures et de bleus. Oם et quand nous battrons-nous ?";
				link.l1.go = "Titch_duel";
			}
			if (!CheckAttribute(npchar, "Cards"))
			{
				link.l2 = "On joue aux cartes ?";
				link.l2.go = "Titch_cards";
			}
			if (!CheckAttribute(npchar, "questions"))
			{
				link.l3 = "Testez mes connaissances sur vous. Pourvu que ce ne soient pas des devinettes d'enfant.";
				link.l3.go = "Titch_questions";
			}
			if (!CheckAttribute(npchar, "ships_sur") && CheckAttribute(pchar, "ShipsSurr") && sti(pchar.ShipsSurr) >= 5)
			{
				link.l4 = "J'ai fait supplier cinq navires marchands.";
				link.l4.go = "Titch_ships_sur";
			}
			if (CheckAttribute(npchar, "Duel") && CheckAttribute(npchar, "Cards") && CheckAttribute(npchar, "questions") && CheckAttribute(npchar, "ships_sur") && !CheckAttribute(pchar, "Titch_seabattle") && !CheckAttribute(pchar, "questTemp.BlackBeardRaidStarted"))
			{
				link.l5 = "Il ne reste que la bataille en mer. Je suis prêt !";
				link.l5.go = "Titch_seabattle";
			}
			link.l6 = "Rien pour l'instant.";
			link.l6.go = "exit";
			if (bBettaTestMode)
			{
				link.l7 = "[BזTA] Bataille navale";
				link.l7.go = "Titch_seabattle";
			}
			
		break;

		case "Titch_seabattle":
			if (GetCompanionQuantity(PChar) >= COMPANION_MAX)
			{
				Dialog.text = "Pas maintenant. Libérez une place dans votre escadre, et nous partirons pour ce raid.";
				link.l1 = "Compris.";
				link.l1.go = "exit";
			}
			else
			{
				if (!CheckAttribute(pchar, "questTemp.BlackBeardRaidStartIsland") || !BlackBeard_IsGoodRaidIsland(pchar.questTemp.BlackBeardRaidStartIsland)) pchar.questTemp.BlackBeardRaidStartIsland = BlackBeard_GetRandomUninhabitedIsland();
				Dialog.text = "Puisque vous avez rempli toutes mes conditions, j'ai encore un travail pour vous. Un convoi chargé d'or tourne autour de l'île déserte de " + BlackBeard_GetRaidIslandName(pchar.questTemp.BlackBeardRaidStartIsland) + ". Prenons-le avec mon escadre, et ensuite, nous parlerons de la part du pirate.";
				link.l1 = "J'en suis. Montrez le chemin.";
				link.l1.go = "Titch_seabattle_7days";
				link.l2 = "Pas maintenant.";
				link.l2.go = "exit";
			}
		break;

		case "Titch_seabattle_7days":
			Dialog.text = "Mais ne traînez pas ! Nous avons exactement 7 jours. Si vous n'atteignez pas l'île à temps, le convoi gagnera la haute mer, et ce sera fini.";
			link.l1 = "Compris. Nous partons immédiatement.";
			link.l1.go = "Titch_seabattle_exit";
		break;

		case "Titch_seabattle_exit":
			DialogExit();
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("BlackBeard_StartGoldRaid");
		break;

		case "Titch_Seabattle_won":
			Dialog.text = "Eh bien, on dirait que c'est la fin. Vous êtes venu à bout du convoi, et moi, j'ai mal jaugé les cartes.";
			link.l1 = "C'est donc pour ça que vous vous êtes retourné contre nous ?";
			link.l1.go = "Titch_Seabattle_won_2";
		break;

		case "Titch_Seabattle_won_2":
			Dialog.text = "Tel est le lot du pirate. Aujourd'hui, on est allié, demain, on est la proie. Ne le prenez pas trop mal.";
			link.l1 = "Ainsi va la vie...";
			link.l1.go = "Titch_Seabattle_won_3";
		break;

		case "Titch_Seabattle_won_3":
Dialog.text = "Dites-moi simplement une des caractéristiques, ne posez pas de questions stupides.";
			if (AddSPECIALValue(pchar, SPECIAL_S, 0) != SPECIAL_MAX)
			{
				Link.l1 = "La force";
				Link.l1.go = "Strength";
			}
			if (AddSPECIALValue(pchar, SPECIAL_P, 0) != SPECIAL_MAX)
			{
				Link.l2 = "Intuition";
				Link.l2.go = "Perception";
			}
			if (AddSPECIALValue(pchar, SPECIAL_A, 0) != SPECIAL_MAX)
			{
				Link.l3 = "La réactivité";
				Link.l3.go = "Agility";
			}
			if (AddSPECIALValue(pchar, SPECIAL_C, 0) != SPECIAL_MAX)
			{
				Link.l4 = "Ascendant";
				Link.l4.go = "Charisma";
			}
			if (AddSPECIALValue(pchar, SPECIAL_I, 0) != SPECIAL_MAX)
			{
				Link.l5 = "Talent";
				Link.l5.go = "Intellect";
			}
			if (AddSPECIALValue(pchar, SPECIAL_E, 0) != SPECIAL_MAX)
			{
			Link.l6 = "Endurance";
			Link.l6.go = "Endurance";
			}
			if (AddSPECIALValue(pchar, SPECIAL_L, 0) != SPECIAL_MAX)
			{
				Link.l7 = "Succès";
				Link.l7.go = "Luck";
			}
			Link.l8 = "Tout me convient tel quel. Et maintenant ?";
			Link.l8.go = "Titch_Seabattle_won_4";
		break;

		case "Strength":
			dialog.text =  "La Puissance, bon choix. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_S, 1);
		break;
        case "Perception":
			dialog.text =  "L'Intuition, très bien. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_P, 1);
		break;
        case "Endurance":
			dialog.text =  "L'Endurance, bien. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_E, 1);
		break;
        case "Charisma":
			dialog.text =  "L'Ascendant ? Hum, un bon choix. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_C, 1);
		break;
        case "Intellect":
			dialog.text =  "Le Talent, c'est un bon choix. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_I, 1);
		break;
        case "Agility":
			dialog.text =  "Les Réflexes, bien. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_A, 1);
		break;
        case "Luck":
			dialog.text =  "Vous voulez être un pirate chanceux ? Bon choix. C'est fait ! Vous remarquerez bientכt la différence.";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "Titch_Seabattle_won_4";
			AddSPECIALValue(pchar, SPECIAL_L, 1);
		break;

		case "Titch_Seabattle_won_4":
Dialog.text = "Pour vous, la vie continue. Mais moi, je dois partir. Et maintenant, adieu pour toujours ! (Tout dépend de la façon dont on se présente ! Faire le pitre pour s'amuser ne convaincra que les imbéciles. Mais si vous êtes le diable, tout le monde se soumettra.)";
			link.l1 = "Je n'ai rien compris, mais adieu, Edward Teach !";
			link.l1.go = "Titch_Seabattle_won_exit";
		break;

		case "Titch_Seabattle_won_exit":
			LAi_LocationFightDisable(loadedLocation, false);
			DeleteAttribute(&NullCharacter, "capitainBase.BlackBeardNPC");
			DeleteAttribute(pchar, "questTemp.BlackBeardRaidStarted");
			DeleteAttribute(pchar, "questTemp.BlackBeardRaidStartIsland");
			PostEvent("csmEvent_RefreshReload", 100);
			BattleInterface.LAi_ActivateReload = true;
			SetEventHandler("Control Activation", "LAi_ActivateReload",1);
			Log_SetActiveAction("Reload");
			ChangeCharacterAddress(npchar, "none", "");
            DialogExit();
			UnlockAchievement("AchTich", 3);
			pchar.questdata.ChernayaBoroda = 1;
		break;

		case "Titch_duel":
Dialog.text = "Ho ho ! Eh bien, vous êtes "+ GetSexPhrase("un vrai loup de mer", "une vraie lionne des mers") +" ! Ici et maintenant ! Je n'aime pas les courbettes.";
			link.l1 = "Doucement, l'ancien..!";
			link.l1.go = "Titch_duel_start";
		break;

		case "Titch_duel_start":
			DialogExit();
			chrDisableReloadToLocation = true;
			Diag.CurrentNode = Diag.TempNode;
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_LocationFightDisable(loadedLocation, false);
			AddDialogExitQuest("MainHeroFightModeOn");

			for(int i=0;i<MAX_CHARACTERS;i++)
			{
				sld = &characters[i];
				if (CheckAttribute(sld, "location") && sld.location == loadedLocation.id && sld.id != "BlackBeardNPC" && sld.id != "Blaze")
				{
					LAi_SetActorType(sld);
					LAi_ActorRunToLocation(sld, "reload", "reload1", "", "", "", "", -1);
				}
			}

			LAi_SetCheckMinHP(npchar, 5.0, true, "Titch_duel");
		break;

		case "DuelWon":
Dialog.text = "Je vous respecte, mon ami, bravo.";
			link.l1 = "א vrai dire, ce n'était pas facile (c'est ça, le vieux duel loyal, l'honneur... Oui, oui...). Et ensuite ?";
			link.l1.go = "Titch_7";
			npchar.Duel = true;
			DeleteAttribute(npchar, "chr_ai.poison");
			DeleteAttribute(npchar, "chr_ai.Blooding");
			LAi_SetImmortal(npchar,false);
			LAi_SetCitizenType(npchar);
		break;

		case "Titch_cards":
Dialog.text = "Aux cartes ? Sachez que la mise est de 50 000 piastres, et pas moins. Alors, si vos poches sont vides, allez vous promener. Et ne vous dérangez même pas avec moins de 500 000. Alors, prêt ?";
			if (sti(pchar.money) >= 500000)
			{
				link.l1 = "Si je suis prêt ? Quelle question stupide, bien sמr !";
				link.l1.go = "Titch_cards_go";
			}
			link.l2 = "Plus tard.";
			link.l2.go = "exit";
		break;

		case "Titch_cards_go":
			npchar.money = 1000000;
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
            pchar.GenQuest.Cards.iRate     = 50000;
            pchar.GenQuest.Cards.SitType   = false;
            Diag.CurrentNode = Diag.TempNode;
			DialogExit();
            LaunchCardsGame();
		break;

		case "Titch_questions":
			npchar.coolstories = "Charleston";
			npchar.questionsstate = 1;
Dialog.text = "Bon, écoutez bien. Puisque vous avez fouillé mon passé et réussi à me trouver, vous connaissez sans doute mon plus grand coup. Quelle ville ai-je assiégée et forcée à me payer une coquette somme ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Titch_check";
			link.l2 = "Plus tard.";
			link.l2.go = "exit";
		break;
		case "Titch_check":
			if (npchar.questionsstate == 1)
			{
				bool check1 = false;
				for(int x=0;x<=5;x++)
				{
					if (coolstory1[x] == GetStrSmallRegister(dialogEditStrings[1])) check1 = true;
				}
				if (check1)
				{
					npchar.coolstories = "hornigold";
					npchar.questionsstate = 2;
Dialog.text = "C'est exact ! Excellente connaissance, respect. וcoutez la question suivante ! (Je veux juste qu'on se souvienne de moi...)";
					Link.l1 = "Allez-y.";
					Link.l1.go = "Titch_q2";
					break;
				}
			}
			if (npchar.questionsstate == 2)
			{
				bool check2 = false;
				for(int y=0;y<=3;y++)
				{
					if (coolstory2[y] == GetStrSmallRegister(dialogEditStrings[1])) check2 = true;
				}
				if (check2)
				{
					npchar.coolstories = "Concord";
					npchar.questionsstate = 3;
Dialog.text = "Bravo ! Je commence à vous apprécier pour votre charisme. Et voici la dernière question.";
					Link.l1 = "Et ?";
					Link.l1.go = "Titch_q3";
					break;
				}
			}
			if (npchar.questionsstate == 3 && (GetStrSmallRegister(npchar.coolstories) == GetStrSmallRegister(dialogEditStrings[1]) || GetStrSmallRegister(dialogEditStrings[1]) == "concorde" || GetStrSmallRegister(dialogEditStrings[1]) == "la concorde"))
			{
Dialog.text = "וtonnant, vous êtes arrivé jusqu'ici ! Je n'ai plus de questions pour vous.";
				Link.l1 = "Parfait !";
				Link.l1.go = "Titch_7";
				npchar.questions = true;
				break;
			}
			else
			{
Dialog.text = "Faux, réessayez.";
				if (npchar.questionsstate == 1)
				{
					Link.l1 = "Encore une fois.";
					Link.l1.go = "Titch_questions";
				}
				if (npchar.questionsstate == 2)
				{
					Link.l1 = "Encore une fois.";
					Link.l1.go = "Titch_q2";
				}
				if (npchar.questionsstate == 3)
				{
					Link.l1 = "Encore une fois.";
					Link.l1.go = "Titch_q3";
				}
				link.l2 = "Plus tard.";
				link.l2.go = "exit";
			}
		break;
		case "Titch_q2":
Dialog.text = "Sous les ordres de qui ai-je navigué avant de devenir Barbe Noire ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Titch_check";
			link.l2 = "Plus tard.";
			link.l2.go = "exit";
		break;
		case "Titch_q3":
Dialog.text = "Comment s'appelait autrefois le navire Queen Anne's Revenge ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Titch_check";
			link.l2 = "Plus tard.";
			link.l2.go = "exit";
		break;

		case "Titch_ships_sur":
Dialog.text = "Très bien ! L'archipel va encore trembler. (Effrayez votre victime, créez-vous une image effrayante, tout droit sortie d'un délire fiévreux, et tout le monde tombera à genoux en implorant la pitié de son Dieu.)";
			Link.l1 = "Merci !";
			Link.l1.go = "Titch_7";
			npchar.ships_sur = true;
			DeleteAttribute(pchar, "ShipsSurr");
		break;
		
		case "TohmasPetit_Ship_Exposition":
			dialog.text = "Monsieur Petit et sa dame ? Oui, ils se sont présentés sur mon pont littéralement au dernier moment avant que nous levions l'ancre. Le garçon a sorti une telle somme en or pour le passage qu'il aurait été franchement stupide de refuser. J'avoue qu'il m'a paru suspect dès le début : sur les nerfs, nerveux comme un chat. Nous avons pu bavarder un peu pendant que les marins arrimaient le gréement, et ce n'est qu'ensuite que j'ai accepté de les prendre à bord. Mais pourquoi exigez-vous si instamment qu'on vous les livre ?";
			link.l1 = "Parce que cet homme est un fugitif et un voleur.";
			link.l1.go = "TohmasPetit_Ship_MainCheck";
		break;
		
		case "TohmasPetit_Ship_MainCheck":
			npchar.TohmasPetit_Talked = true;
			
			bool bAuth = false;
			if (sti(pchar.SPECIAL.Charisma) > 6) 
			{
				bAuth = true;
			}
			if (sti(pchar.skill.LeaderShip) >= 50) 
			{
				bAuth = true;
			}
			bool bNoKills = !CheckAttribute(pchar, "QuestTemp.TohmasPetit_KilledAnyone");
			bool bGoodRep = (sti(pchar.reputation) >= 50);
			bool bBloody = (sti(pchar.reputation) <= 10);

			if (bNoKills)
			{
				if (bAuth && bGoodRep) 
				{
					dialog.text = "J'ai entendu parler de vous comme d'une personne honnête et respectée, capitaine. Personne n'oserait contester votre autorité dans ces eaux. Puisque vous êtes venu chercher ce garçon en personne, vous devez avoir un sérieux compte à régler avec lui. Je n'ai aucune envie de me faire un ennemi de vous pour un passager de hasard.";
					link.l1 = "Je suis content que nous nous comprenions. Comment procédons-nous avec eux ?";
					link.l1.go = "TohmasPetit_Cap_Peace_1";
				} 
				else 
				{
					dialog.text = "Pourquoi diable devrais-je vous croire sur parole et livrer des gens ? N'importe qui peut raconter n'importe quoi sur les quais. D'ailleurs, je ne vois aucune preuve. Vous ne m'avez pas convaincu, je dois donc vous prier de quitter mon navire.";
					link.l1 = "Réfléchissez bien, capitaine. Vous protégez quelqu'un qui n'en vaut pas la peine. Cela pourrait vous coמter cher.";
					link.l1.go = "TohmasPetit_Cap_FailNoKills_1";
				}
			}
			else
			{
				if (bBloody) 
				{
					dialog.text = "Je... Je sais qui vous êtes. Vous êtes un pirate, et votre réputation d'assassin sanguinaire, dont on chuchote les atrocités dans toutes les tavernes de la Terre Ferme... Personne n'est jamais reparti vivant de chez vous...";
					link.l1 = "Je suis content que ma réputation me précède. Puisque vous savez qui je suis, vous savez que je ne suis pas d'humeur à jouer. Oם est Thomas ?";
					link.l1.go = "TohmasPetit_Cap_Bloody_1";
				} 
				else 
				{
					dialog.text = "Thomas m'a raconté que vous avez semé un vrai carnage en le traquant ! Vous êtes un boucher et un assassin, je ne vous livrerai pas ce garçon et sa fiancée pour que vous les massacriez. Quittez mon navire !";
					link.l1 = "Vous ne connaissez pas toute l'histoire, capitaine. Ce gredin mérite tout ce qui lui arrive.";
					link.l1.go = "TohmasPetit_Cap_FailKills_1";
				}
			}
		break;

		case "TohmasPetit_Cap_Peace_1":
			dialog.text = "Je vais ordonner aux marins de les faire monter sur le pont. Qu'ils rassemblent leurs affaires et passent sur votre navire.";
			link.l1 = "Une sage décision, capitaine. Je suis content que nous ayons réglé ça sans échanger de boulets. Adieu.";
			link.l1.go = "TohmasPetit_Cap_Peace_GoodExit";
		break;

		case "TohmasPetit_Cap_FailNoKills_1":
			dialog.text = "Assez de menaces sur ma propre dunette ! Sur l''Atlantica', c'est moi la loi. La conversation est terminée, retournez à votre navire avant que je n'ordonne à l'équipage de prendre les armes !";
			link.l1 = "Eh bien, comme vous voudrez. Bonne journée, capitaine.";
			link.l1.go = "TohmasPetit_Cap_Attack_NoKillsExit";
		break;

		case "TohmasPetit_Cap_Bloody_1":
			dialog.text = "Prenez-les ! Prenez le garçon et sa garce de Madeline, mais épargnez mon équipage et ne touchez pas au navire ! Ils sont dans la cale, je vais tout de suite les faire descendre dans une chaloupe pour qu'on les remette à vos hommes.";
			link.l1 = "Un choix judicieux. Débarquez-les plus vite, et peut-être que votre navire restera à flot aujourd'hui.";
			link.l1.go = "TohmasPetit_Cap_Peace_FearExit";
		break;

		case "TohmasPetit_Cap_FailKills_1":
			dialog.text = "Il me suffit amplement que du sang ait déjà coulé à cause de votre chasse. Je ne deviendrai pas le complice d'un bourreau. Quittez mon navire sur-le-champ, ou nous vous donnerons aux requins ici même !";
			link.l1 = "Votre entêtement vous perdra. Adieu.";
			link.l1.go = "TohmasPetit_Cap_Attack_KillsExit";
		break;
		
		// --- Исходы диалогов ---

		case "TohmasPetit_Cap_Peace_GoodExit":
			DialogExit();
			NPChar.dialog.currentnode = "First time";
			AddQuestRecord("TohmasPetit", "TohmasPetit_CapPeaceGood");
			pchar.QuestTemp.TohmasPetit_Quest = "talk_in_hold";
			pchar.QuestTemp.TohmasPetit_SecuredPeacefully = true;
			AddDialogExitQuest("TohmasPetit_MoveToHold");

			pchar.quest.TohmasPetit_ClearShip_Case.win_condition.l1 = "ExitFromSea";
			pchar.quest.TohmasPetit_ClearShip_Case.win_condition = "TohmasPetit_ClearShip_Case";
			TohmasPetit_ReleaseShipEncounter(); // судьба судна решена - метку с глобалки снимаем сразу
		break;

		case "TohmasPetit_Cap_Peace_FearExit":
			DialogExit();
			NPChar.dialog.currentnode = "First time";
			AddQuestRecord("TohmasPetit", "TohmasPetit_CapPeaceFear");
			pchar.QuestTemp.TohmasPetit_Quest = "talk_in_hold";
			pchar.QuestTemp.TohmasPetit_SecuredPeacefully = true;
			AddDialogExitQuest("TohmasPetit_MoveToHold");
			pchar.QuestTemp.TohmasPetit_bloodytake = true; // LEO: flag "captives taken by intimidation (bloody reputation)" - statement was incomplete, never set

			pchar.quest.TohmasPetit_ClearShip_Case.win_condition.l1 = "ExitFromSea";
			pchar.quest.TohmasPetit_ClearShip_Case.win_condition = "TohmasPetit_ClearShip_Case";
			TohmasPetit_ReleaseShipEncounter(); // судьба судна решена - метку с глобалки снимаем сразу
		break;

		case "TohmasPetit_Cap_Attack_NoKillsExit":
			DialogExit();
			NPChar.dialog.currentnode = "First time";
			AddQuestRecord("TohmasPetit", "TohmasPetit_CapAttackNoKills");
			pchar.QuestTemp.TohmasPetit_CapTalked = "failed"; 
			
			pchar.quest.TohmasPetit_LetThemGo.win_condition.l1 = "ExitFromSea";
			pchar.quest.TohmasPetit_LetThemGo.win_condition = "TohmasPetit_LetThemGo";
			TohmasPetit_ReleaseShipEncounter(); // судьба судна решена - метку с глобалки снимаем сразу
		break;

		case "TohmasPetit_Cap_Attack_KillsExit":
			DialogExit();
			NPChar.dialog.currentnode = "First time";
			AddQuestRecord("TohmasPetit", "TohmasPetit_CapAttackKills");
			pchar.QuestTemp.TohmasPetit_CapTalked = "failed"; 
			
			pchar.quest.TohmasPetit_LetThemGo.win_condition.l1 = "ExitFromSea";
			pchar.quest.TohmasPetit_LetThemGo.win_condition = "TohmasPetit_LetThemGo";
			TohmasPetit_ReleaseShipEncounter(); // судьба судна решена - метку с глобалки снимаем сразу
		break;

		// Stub after talking to the "Atlantica" captain, so re-opening the dialog isn't empty and doesn't hang
		case "TohmasPetit_Cap_Deck_Stub":
			dialog.text = "Capitaine, je n'ai plus d'affaires avec vous. Je dois vous prier de quitter mon navire.";
			link.l1 = "Très bien, capitaine. Adieu.";
			link.l1.go = "exit";
			link.l2 = "D'accord, d'accord, ne vous mettez pas dans tous vos états. Je m'en vais déjà.";
			link.l2.go = "exit";
		break;
	}
}

string GetNumShips(int ship)
{
    string numships;
    switch(ship)
    {
       case 0: numships = "pas un seul navire"; break;
       case 1: numships = "un navire";      break;
       case 2: numships = "deux navires";       break;
       case 3: numships = "trois navires";       break;
       case 4: numships = "quatre navires";    break;
       case 5: numships = "cinq navires";     break;
       case 6: numships = "six navires";    break;
    }
    return numships;
}

string GetPart(int part)
{
    string numpart;
    switch(part)
    {
       case 0: numpart = ""; break;
       case 1: numpart = "tout le butin"; break;
       case 2: numpart = "la moitié du butin"; break;
       case 3: numpart = "un tiers du butin"; break;
       case 4: numpart = "un quart du butin";      break;

    }
    return numpart;
}

int findPriceStoreMan(ref NPChar)
{
    ref ch;
	int n;
    int storeArray[40];
    int howStore = 0;

	for(n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(ch,Characters[n]);
		if (CheckAttribute(ch, "Dialog.Filename") && ch.Dialog.Filename == "Common_Store.c") // магазин
		{
            //if (sti(ch.nation) !=  sti(NPChar.nation)) continue;
            if (ch.location == "none") continue;
			if (ch.City == "Caiman") continue;			// фикс для новых, невидимых до поры островов
            storeArray[howStore] = n;
            howStore++;

            // homo 05/09/06
            if ( CheckAttribute(NPChar, "FromColony") && NPChar.FromColony == ch.City ) return n;
            //
		}
    }
    if (howStore == 0)
    {
        return -1;
    }
    else
    {
        return storeArray[rand(howStore-1)];
    }
}
