// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Dans mon chantier naval, et dans toute la ville d'ailleurs, je n'ai jamais vu de gens aussi obstinément curieux.",
                          "Eh bien, quelles questions ? Mon métier, c'est de construire des navires, alors allons-y.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Hum, tout de même...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.Slavetrader == "FindRatPortobello")
            {
                link.l1 = "וcoutez, avez-vous eu affaire à un corsaire nommé François Gontier ? Il était à Portobelo récemment, j'en suis sמr.";
                link.l1.go = "Portobello_ratS_1";
            }
		break;

		case "Portobello_ratS_1":
			dialog.text = "Oui. Il m'a acheté une corvette et a bientכt pris la mer.";
			link.l1 = "Merci ! Vous ne sauriez pas oם il est allé, par hasard ?";
			link.l1.go = "Portobello_ratS_2";
		break;

		case "Portobello_ratS_2":
			dialog.text = "Non, "+ GetSexPhrase("l'ami", "ma petite") +", je n'en ai pas la moindre idée. Je répare et je vends des navires, je ne surveille pas qui va oם. דa m'est bien égal.";
			link.l1 = "Eh bien, je vais me renseigner...";
			link.l1.go = "exit";
			pchar.questTemp.Slavetrader = "FindRatPortobello_1";
			AddQuestRecord("Slavetrader", "21_2");
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

