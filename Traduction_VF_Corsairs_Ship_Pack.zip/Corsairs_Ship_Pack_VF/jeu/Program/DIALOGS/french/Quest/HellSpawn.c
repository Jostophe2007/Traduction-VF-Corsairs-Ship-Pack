void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;

	bool hungry = true;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Frère dans la non-vie, que voulais-tu à l'entrée de l'église ?";
            link.l1 = "Et toi, d'oם sors-tu ?";
            link.l1.go = "HS_1";
			link.l2 = "דa ne te regarde pas. Ne m'embête pas.";
            link.l2.go = "HS_2";
			link.l3 = "On m'a demandé d'apporter une offrande.";
            link.l3.go = "HS_2";
		break;

		case "HS_1":
			dialog.text = "Nous t'avons à l'œil depuis longtemps. Et ce que nous voyons ne nous plaît pas vraiment.";
			link.l1 = "Et qu'avez-vous vu ?";
			link.l1.go = "HS_2";
		break;
		case "HS_2":
			dialog.text = "Tu sers les mortels ! Tu exauces leurs caprices abjects, sans même rien exiger en retour ! Nous ne pouvons pas supporter ce spectacle. La course pour la tenancière du bordel a été la goutte d'eau qui fait déborder le vase. Tu crois qu'en agissant ainsi, tu pourras te rapprocher de leur vie normale ? Renaître ? Cela n'arrivera pas ! Il existe un rituel, mais par tes actes, tu t'en es rendu indigne, même aux yeux des pitoyables mortels ; maintenant, tu vas voir cette ville brמler avec eux.";
			link.l1 = "Je ne laisserai pas faire ça.";
			link.l1.go = "HS_fight";
		break;

		case "HS_fight":
			DialogExit();
			Lai_SetPlayerType(pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
			//LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_SetImmortal(NPChar, false);
			//LocatorReloadEnterDisable(pchar.HellSpawnLocation, "reload7_back", false);

			string cnd;
			for (int i = 1; i<15; i++)
			{
				cnd = "l" + i;
				sld = characterFromID("HellSpawn"+i);
				LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
				PChar.quest.HellSpawnFinish.win_condition.(cnd) = "NPC_Death";
				PChar.quest.HellSpawnFinish.win_condition.(cnd).character = sld.id;
			}
			pchar.quest.HellSpawnFinish.function = "HellSpawnFinish";
		break;

		case "Ritual":
			dialog.text = "Pourquoi es-tu venu ici ? Tu veux interrompre notre rituel de renaissance ?";
			link.l1 = "Au contraire. Je veux me joindre à vous.";
			link.l1.go = "Ritual_1";
			link.l2 = "Oui. Les gens comme vous ne méritent pas le don de la vie.";
			link.l2.go = "Ritual_fight";
		break;

		case "Ritual_1":
			dialog.text = "Beaucoup attendent leur tour depuis des centaines d'années. Tu n'en es pas encore digne.";
			link.l1 = "On va voir maintenant qui mérite quoi ici.";
			link.l1.go = "Ritual_fight";
		break;

		case "Ritual_fight":
			DialogExit();
			Lai_SetPlayerType(pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_SetImmortal(NPChar, false);
			ref RitualLocLoad = &locations[reload_location_index];
			cnd;
			for (i = 1; i<sti(pchar.Hellspawn.num); i++)
			{
				cnd = "l" + i;
				sld = characterFromID("HellSpawnR"+i);
				LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
				PChar.quest.HellSpawnRitualFinish.win_condition.(cnd) = "NPC_Death";
				PChar.quest.HellSpawnRitualFinish.win_condition.(cnd).character = sld.id;
			}
			pchar.quest.HellSpawnRitualFinish.function = "HellSpawnRitualFinish";

		break;
	}
}
