# -*- coding: utf-8 -*-
"""Tokenizer for Storm-engine script files (.c/.h).
Returns string literals with spans; ignores comments. No escape sequences in Storm strings."""
import re

def scan_literals(src):
    """Yield (start, end, value, in_comment=False) for each string literal (start/end include quotes)."""
    i, n = 0, len(src)
    out = []
    while i < n:
        c = src[i]
        if c == '"':
            j = src.find('"', i + 1)
            if j < 0:
                break
            # strings cannot span lines in practice; if newline inside, still accept
            out.append((i, j + 1, src[i + 1:j]))
            i = j + 1
        elif c == '/' and i + 1 < n and src[i + 1] == '/':
            j = src.find('\n', i)
            i = n if j < 0 else j
        elif c == '/' and i + 1 < n and src[i + 1] == '*':
            j = src.find('*/', i + 2)
            i = n if j < 0 else j + 2
        else:
            i += 1
    return out

def line_context(src, start):
    """Code on the same line before the literal (with previous line if the statement continues)."""
    ls = src.rfind('\n', 0, start) + 1
    return src[ls:start]

CYR = re.compile('[Ѐ-ӿ]')
LETTERS = re.compile('[A-Za-zÀ-ɏЀ-ӿ]')
