// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
            dialog.text = "Parlez, je vous écoute.";
			link.l1 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Adieu.";
			link.l1.go = "Exit";
			if (CheckAttribute(pchar, "questTemp.Tichingitu") && pchar.questTemp.Tichingitu == "true")
            {
                link.l1 = "Vous détenez un Indien capturé par Askold. Puis-je le voir ?";
                link.l1.go = "Tichingitu";
            }
			if (CheckAttribute(pchar, "questTemp.Tichingitu") && pchar.questTemp.Tichingitu == "commandante")
            {
                link.l1 = "Dites-moi, allez-vous vraiment pendre cet Indien ? La punition n'est-elle pas trop sévère pour un délit aussi mineur ?";
                link.l1.go = "Tichingitu_3";
            }
			if (CheckAttribute(pchar, "questTemp.Tichingitu") && pchar.questTemp.Tichingitu == "pay")
            {
                link.l1 = "C'est encore moi, commandant. Askold a rédigé une demande de grâce pour l'Indien. La voici.";
                link.l1.go = "Tichingitu_6";
            }
		break;

		case "Tichingitu":
			dialog.text = "Ah, Askold vous a raconté son histoire, à vous aussi ? Je ne vois aucune raison de vous en empêcher. Vous n'êtes pas le premier à venir voir ce Peau-Rouge. D'ailleurs, dans dix jours, tous les habitants de notre ville pourront l'admirer, quand nous le pendrons pour qu'il sèche au soleil...";
			link.l1 = "Alors, je peux aller aux casemates ?";
			link.l1.go = "Tichingitu_1";
		break;

		case "Tichingitu_1":
			dialog.text = "Je vous le dis, je ne vois aucune raison de refuser. Entrez.";
			link.l1 = "Merci !";
			link.l1.go = "Tichingitu_2";
		break;

		case "Tichingitu_2":
			DialogExit();
			pchar.questTemp.Tichingitu = "wait";
			pchar.questTemp.jailCanMove = true;
		break;

		case "Tichingitu_3":
			dialog.text = "Vous ne comprenez pas la situation dans nos colonies. Cette exécution servira de leçon à toutes les autres canailles à peau rouge qui oseraient s'en prendre aux biens des colons français. De plus, Askold y tient, et c'est un homme très respecté dans notre ville, un ami proche du gouverneur.";
			link.l1 = "N'y a-t-il vraiment aucun moyen d'atténuer la peine ? Je la trouve toujours injustement sévère...";
			link.l1.go = "Tichingitu_4";
		break;

		case "Tichingitu_4":
			dialog.text = "Oh, "+ GetSexPhrase("jeune homme", "madame") +", ne vous lancez pas dans la philosophie ! Si cette question vous tient tant à cœur, allez voir Askold et demandez-lui l'Indien. S'il rédige une demande de grâce, nous l'accorderons.";
			link.l1 = "Je comprends tout, officier. J'y vais.";
			link.l1.go = "Tichingitu_5";
		break;

		case "Tichingitu_5":
			DialogExit();
			pchar.questTemp.Tichingitu = "ascold";
			AddQuestRecord("Ascold", "3_2");
		break;

		case "Tichingitu_6":
			RemoveItems(pchar, "letter_A", 1);
			dialog.text = "(lit) Hum... Cet Askold est bien étrange : d'abord, il exige une exécution exemplaire, et maintenant, il demande qu'on relâche l'Indien... Bon, apparemment, tous les amis du gouverneur ont ce genre de lubies. Très bien, vous pouvez aller à la cellule et emmener ce Peau-Rouge.";
			link.l1 = "Merci, officier !";
			link.l1.go = "Tichingitu_7";
		break;

		case "Tichingitu_7":
			DialogExit();
			pchar.questTemp.Tichingitu = "wait";
			pchar.questTemp.jailCanMove = true;
			sld = characterFromId("Tichingitu");
			sld.dialog.currentnode = "Tichingitu_6";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
