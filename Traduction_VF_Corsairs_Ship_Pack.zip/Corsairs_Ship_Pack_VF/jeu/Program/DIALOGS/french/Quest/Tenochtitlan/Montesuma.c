
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Oh, encore un Blanc qui arrive. Qu'est-ce qui t'amène à Tenochtitlan ?";
			link.l1 = "Voir ce qu'il en est. "+ GetSexPhrase("Je suis comme ça", "Je suis comme ça") +" : je veux tout savoir.";
			link.l1.go = "FT_1";
			if (pchar.questTemp.Teno == "takeFire")
			{
				dialog.text = "Bonjour, "+ GetSexPhrase("homme blanc", "squaw blanche") +". Pourquoi es-tu ici ?";
				link.l1 = "Voir ce qu'il en est. "+ GetSexPhrase("Je suis comme ça", "Je suis comme ça") +" : je veux tout savoir. Je suppose que tu es un Aztèque, l'ami.";
				link.l1.go = "FTS_1";
			}
		break;
		case "FT_1":
			dialog.text = "Je vois... Mais sais-tu au moins oם tu as mis les pieds ?";
			link.l1 = "Je sais que cette ville est la capitale indienne. Et que Cortés lui-même l'a parcourue par le fer et par le feu.";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Oui, c'est ça. Cette ville s'appelle Tenochtitlan, et le peuple qui y a vécu pendant des siècles s'appelait les Aztèques.";
			link.l1 = "Clair. Et toi aussi, tu es un Aztèque, je suppose ?";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Oui, je suis un Aztèque, tu as deviné. Je m'appelle Montezuma. Comment puis-je t'appeler ?";
			link.l1 = "On m'appelle capitaine " + GetFullName(pchar) + ". Montezuma... Je crois que c'était le nom du chef indien.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Je porte son nom. Dis-moi, "+ GetSexPhrase("capitaine blanc", "belle squaw") +" " + GetFullName(pchar) + ", que comptes-tu faire maintenant ?";
			link.l1 = "Je veux entrer dans la ville.";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Tu as sans doute compris que ce n'est pas si facile. La digue qui mène à la ville est solidement protégée par un sortilège de feu. Tout récemment, il y avait beaucoup de Blancs ici. Ils ont tous brמlé...";
			link.l1 = "Eh bien, pas tous. א ce que je sais, tu as fendu le crâne de quelqu'un.";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "C'est vrai, mais ils sont eux-mêmes responsables de leur mort. Ils n'auraient pas dמ toucher à Montezuma.";
			link.l1 = "Bon, n'en parlons plus. Dis-moi plutכt ce qu'il y a d'intéressant dans la ville. Quelqu'un y vit-il, ou non ? Et que fais-tu ici, sur cette rive ?";
			link.l1.go = "FT_8";
		break;
		case "FT_8":
			dialog.text = "Oh, c'est une longue histoire. Prépare-toi à écouter, "+ GetSexPhrase("capitaine blanc", "belle squaw") +"\n"+
				"Mes ancêtres sont arrivés sur les rives de ce lac appelé Texcoco il y a bien des siècles. On les appelait alors les Mexicas. Les rives du lac étaient peuplées d'autres tribus hostiles aux nouveaux venus. Mais notre dieu suprême, Huitzilopochtli, leur ordonna de rester ici. Alors, le chef des Mexicas, Tenoch, décida de s'installer sur les rives du Texcoco, et les Mexicas prirent le nom de Tenochcas\n"+
				"Coxcoxtli, le chef de la puissante cité de Culhuacán, complota pour exterminer les Tenochcas. Alors, mes ancêtres quittèrent la rive et allèrent vivre sur une île marécageuse au milieu du lac. Le temps passa, et les Tenochcas réussirent à consolider l'île et même à construire une digue jusqu'à la rive. Et quand les Tenochcas choisirent Itzcoatl pour chef, une confédération de tribus fut créée, et les peuples de la confédération prirent le nom d'Aztèques\n"+
				"Ce furent des temps bénis : les Aztèques régnaient sur le monde. Toutes les tribus payaient tribut aux Aztèques, fournissaient vivres, esclaves et concubines. Le sang des sacrifices, nourriture de nos dieux, rendait rouges les eaux du Texcoco. Les nobles guerriers étaient sacrifiés à Tezcatlipoca, protecteur des prêtres, et les guerriers ordinaires étaient brמlés en l'honneur de Camaxtli. Les femmes donnaient leur sang à la déesse Mayahuel, et les enfants au dieu de la fertilité, Tlaloc\n"+
				"Il en fut ainsi pendant plus de cent ans. Mais ensuite, les Espagnols arrivèrent, et Tenochtitlan fut assiégée. Et nos héros tombèrent, menés par Cuauhtémoc\n"+
				"Tenochtitlan est maintenant gouvernée par le dieu du royaume des morts, Mictlantecuhtli.";
			link.l1 = "Alors, la ville est inhabitée ?";
			link.l1.go = "FT_9";
		break;
		case "FT_9":
			dialog.text = "Elle est habitée. Des vivants et des morts y vivent.";
			link.l1 = "Quoi ?";
			link.l1.go = "FT_10";
		break;
		case "FT_10":
			dialog.text = "Mictlantecuhtli a le pouvoir de ressusciter les gens. Mictlantecuhtli a ramené des guerriers à la vie pour garder les temples des dieux, et il y a aussi des Aztèques vivants.";
			link.l1 = "Pourquoi ne vis-tu pas à Tenochtitlan ?";
			link.l1.go = "FT_11";
		break;
		case "FT_11":
			dialog.text = "J'ai été chassé par Mictlantecuhtli. Tant que son pouvoir est illimité, je ne peux pas revenir. וcoute-moi, "+ GetSexPhrase("capitaine blanc", "belle squaw") +". Je vais maintenant te proposer un marché, celui que je propose à tous ceux qui viennent ici.";
			link.l1 = "Je t'écoute, Montezuma.";
			link.l1.go = "FT_12";
		break;
		case "FT_12":
			dialog.text = "Si tu parviens à réduire le pouvoir de Mictlantecuhtli, je t'aiderai à acquérir de la puissance. Il y a dans le temple des Dieux Blancs une arme qui n'a pas d'égale et n'en aura jamais. Tu pourras la garder.";
			link.l1 = "Que voulez-vous ?";
			link.l1.go = "FT_13";
		break;
		case "FT_13":
			dialog.text = "Le crâne de jade de Mictlantecuhtli. Il se trouve dans le temple de la Grande Force de Vie.";
			link.l1 = "Je comprends que ce ne sera pas facile d'y entrer.";
			link.l1.go = "FT_14";
		break;
		case "FT_14":
			dialog.text = "Je vais te donner quelques conseils.";
			link.l1 = "Pourquoi ne viens-tu pas en ville avec moi ? Tu brandirais ta massue, tu fendrais des crânes...";
			link.l1.go = "FT_15";
		break;
		case "FT_15":
			dialog.text = "Une massue ?! La massue, c'est toi ! C'est l'épée d'obsidienne, le macuahuitl ! Sais-tu que nos lances et nos épées d'obsidienne terrifiaient les Espagnols plus que celles de fer ?";
			link.l1 = "Pardonne-moi la question, Montezuma, mais alors, pourquoi avez-vous perdu la guerre ?";
			link.l1.go = "FT_16";
		break;
		case "FT_16":
			dialog.text = "Nos dieux se sont détournés de nous...";
			link.l1 = "Encore les dieux...";
			link.l1.go = "FT_17";
		break;
		case "FT_17":
			dialog.text = "Ce sont les dieux qui décident de tout, pas les hommes. L'un de mes ancêtres a essayé de tout décider à la place des dieux, et il s'est trompé. Le prix qu'il a payé pour cette erreur fut exorbitant. Bon, parlons du marché. Acceptes-tu de te faufiler dans Tenochtitlan et de m'apporter le crâne de jade ?";
			link.l1 = "Je veux bien essayer.";
			link.l1.go = "FT_18";
		break;
		case "FT_18":
			dialog.text = "Bien. Alors, avant tout, il faut lever le sortilège de feu de la digue qui mène à la ville.";
			link.l1 = "Et comment je fais ça ? Qui a pu organiser une chose pareille ?";
			link.l1.go = "FT_19";
		break;
		case "FT_19":
			dialog.text = "Mictlantecuhtli, qui d'autre ? Par le pouvoir de Camaxtli, dieu de la guerre et du destin, il a jeté un sortilège de feu sur la digue. Car Camaxtli est le créateur du feu.";
			link.l1 = "Compris... Bon, comment je lève ce feu ?";
			link.l1.go = "FT_20";
		break;
		case "FT_20":
			dialog.text = "Il y a deux moyens. Le premier, c'est de trouver le totem de Camaxtli, de traverser le feu jusqu'à la ville et d'insérer ce totem dans la pierre sacrificielle qui se trouve près de l'entrée de la ville.";
			link.l1 = "Traverser le feu ? Mais je vais brמler !";
			link.l1.go = "FT_21";
		break;
		case "FT_21":
			dialog.text = "Il n'y a pas de feu sur l'isthme de bois de la digue. Tu pourras t'y reposer.";
			link.l1 = "Clair... Et le deuxième moyen ?";
			link.l1.go = "FT_22";
		break;
		case "FT_22":
			dialog.text = "Trouver deux totems : celui de la déesse Tlazolteotl, la mangeuse de souillures, et celui du dieu du ciel et du soleil, Tonatiuh. Puis les insérer dans les pierres sacrificielles qui se trouvent sur la rive, devant la digue. Alors, le sortilège sera levé, et tu pourras aller sans crainte à Tenochtitlan.";
			link.l1 = "Compris. Et oם trouver ces totems ?";
			link.l1.go = "FT_23";
		break;
		case "FT_23":
			dialog.text = "Je ne peux pas te le dire, sinon notre marché perdrait son sens, mais je peux te donner un indice...";
			link.l1 = "Eh bien, donne-moi un indice.";
			link.l1.go = "FT_24";
		break;
		case "FT_24":
			dialog.text = "Le totem de Camaxtli est plus proche que tu ne le penses. Le totem de Tlazolteotl se trouve tout près, dans l'herbe. Et le totem de Tonatiuh est abandonné dans la jungle entre deux villes espagnoles situées sur l'isthme entre les continents.";
			link.l1 = "Bon sang ! On ne peut pas être plus précis ?";
			link.l1.go = "FT_25";
		break;
		case "FT_25":
			dialog.text = "Rien du tout. Cherche, "+ GetSexPhrase("capitaine blanc", "belle squaw") +". J'ai tout dit, maintenant, c'est à toi de jouer.";
			link.l1 = "D'accord, je vais chercher...";
			link.l1.go = "exit";
			npchar.location.locator = "quest1";
			NextDiag.TempNode = "Fire";
			AddDialogExitQuestFunction("Teno_MontesumaGoQuest1");
		break;
		//--------------
		case "FTS_1":
			dialog.text = "Oui, je suis un Aztèque, tu as deviné. Je m'appelle Montezuma. Comment puis-je t'appeler ?";
			link.l1 = "On m'appelle capitaine " + GetFullName(pchar) + ". Montezuma... Je crois que c'était le nom du chef indien.";
			link.l1.go = "FTS_2";
		break;
		case "FTS_2":
			dialog.text = "Je porte son nom. Dis-moi, "+ GetSexPhrase("capitaine blanc", "belle squaw") +" " + GetFullName(pchar) + ", que vas-tu faire maintenant ? Tu as réussi à lever le sortilège de feu !";
			link.l1 = "Je vais fouiller la ville comme il faut. Je trouverai peut-être quelque chose qui en vaille la peine.";
			link.l1.go = "FTS_3";
		break;
		case "FTS_3":
			dialog.text = "Je veux te faire une proposition, capitaine blanc.";
			link.l1 = "Je t'écoute, Montezuma.";
			link.l1.go = "FTS_4";
		break;
		case "FTS_4":
			dialog.text = "Bien. וcoute attentivement, "+ GetSexPhrase("capitaine blanc", "belle squaw") +"\n"+
				"Mes ancêtres sont arrivés sur les rives de ce lac, appelé Texcoco, il y a bien des siècles. On les appelait alors les Mexicas. Les rives du lac étaient peuplées d'autres tribus hostiles aux nouveaux venus. Mais notre dieu suprême, Huitzilopochtli, leur ordonna de rester ici. Alors, le chef des Mexicas, Tenoch, décida de s'installer sur les rives du Texcoco, et les Mexicas prirent le nom de Tenochcas\n"+
				"Coxcoxtli, le chef de la puissante cité de Culhuacán, complota pour exterminer les Tenochcas. Alors, mes ancêtres quittèrent la rive et allèrent vivre sur une île marécageuse au milieu du lac. Le temps passa, et les Tenochcas réussirent à consolider l'île, à bâtir une cité de pierre et même une digue jusqu'à la rive. Et quand les Tenochcas choisirent Itzcoatl pour chef, une confédération de tribus fut créée, et les peuples de la confédération prirent le nom d'Aztèques\n"+
				"Ce furent des temps bénis : les Aztèques régnaient sur le monde. Toutes les tribus payaient tribut aux Aztèques, fournissaient vivres, esclaves et concubines. Le sang des sacrifices, nourriture de nos dieux, rendait rouges les eaux du Texcoco. Les nobles guerriers étaient sacrifiés à Tezcatlipoca, protecteur des prêtres, et les guerriers ordinaires étaient brמlés en l'honneur de Camaxtli. Les femmes donnaient leur sang à la déesse Mayahuel, et les enfants au dieu de la fertilité, Tlaloc\n"+
				"Il en fut ainsi pendant plus de cent ans. Mais ensuite, les Espagnols arrivèrent, et Tenochtitlan fut assiégée. Et nos héros tombèrent, menés par Cuauhtémoc\n"+
				"Tenochtitlan est maintenant gouvernée par le dieu du royaume des morts, Mictlantecuhtli.";
			link.l1 = "Alors, la ville est inhabitée ?";
			link.l1.go = "FTS_5";
		break;
		case "FTS_5":
			dialog.text = "Elle est habitée. Des vivants et des morts y vivent.";
			link.l1 = "Quoi ?";
			link.l1.go = "FTS_6";
		break;
		case "FTS_6":
			dialog.text = "Mictlantecuhtli a le pouvoir de ressusciter les gens. Mictlantecuhtli a ramené des guerriers à la vie pour garder les temples des dieux, et il y a aussi des Aztèques vivants.";
			link.l1 = "Pourquoi ne vis-tu pas à Tenochtitlan ?";
			link.l1.go = "FTS_7";
		break;
		case "FTS_7":
			dialog.text = "J'ai été chassé par Mictlantecuhtli. Tant que son pouvoir est illimité, je ne peux pas revenir. וcoute-moi, "+ GetSexPhrase("capitaine blanc", "belle squaw") +". Je vais maintenant te proposer un marché, celui que je propose à tous ceux qui viennent ici.";
			link.l1 = "Je t'écoute, Montezuma.";
			link.l1.go = "FTS_8";
		break;
		case "FTS_8":
			dialog.text = "Si tu parviens à réduire le pouvoir de Mictlantecuhtli, je t'aiderai à acquérir de la puissance. Il y a dans le temple des Dieux Blancs une arme qui n'a pas d'égale et n'en aura jamais. Tu pourras la garder.";
			link.l1 = "Que voulez-vous ?";
			link.l1.go = "FTS_9";
		break;
		case "FTS_9":
			dialog.text = "Le crâne de jade de Mictlantecuhtli. Il se trouve dans le temple de la Grande Force de Vie.";
			link.l1 = "Je comprends que ce ne sera pas facile d'y entrer.";
			link.l1.go = "FTS_10";
		break;
		case "FTS_10":
			dialog.text = "Je vais te donner quelques conseils.";
			link.l1 = "Pourquoi ne viens-tu pas en ville avec moi ? Tu brandirais ta massue, tu fendrais des crânes...";
			link.l1.go = "FTS_11";
		break;
		case "FTS_11":
			dialog.text = "Une massue ?! La massue, c'est toi ! C'est l'épée d'obsidienne, le macuahuitl ! Sais-tu que nos lances et nos épées d'obsidienne terrifiaient les Espagnols plus que celles de fer ?";
			link.l1 = "Pardonne-moi la question, Montezuma, mais alors, pourquoi avez-vous perdu la guerre ?";
			link.l1.go = "FTS_12";
		break;
		case "FTS_12":
			dialog.text = "Nos dieux se sont détournés de nous...";
			link.l1 = "Encore les dieux...";
			link.l1.go = "FTS_13";
		break;
		case "FTS_13":
			dialog.text = "Ce sont les dieux qui décident de tout, pas les hommes. L'un de mes ancêtres a essayé de tout décider à la place des dieux, et il s'est trompé. Le prix qu'il a payé pour cette erreur fut exorbitant. Bon, parlons du marché. Acceptes-tu de te faufiler dans Tenochtitlan et de m'apporter le crâne de jade ?";
			link.l1 = "Je veux bien essayer.";
			link.l1.go = "FTS_14";
		break;
		case "FTS_14":
			dialog.text = "Bien. Maintenant, écoute ce que tu dois faire.";
			link.l1 = "Je t'écoute, Montezuma.";
			link.l1.go = "Fire_1";
		break;
		//после снятия огня
		case "Fire":
			if (CheckAttribute(loadedLocation, "gotoFire"))
			{
				dialog.text = "Le sortilège de feu n'a pas encore été levé de la digue.";
				link.l1 = "Pas encore, mais je m'en occupe.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Tu as réussi à lever le sortilège de feu, c'est bien. Maintenant, écoute ce que tu dois faire ensuite.";
				link.l1 = "Je t'écoute attentivement, Montezuma.";
				link.l1.go = "Fire_1";
			}
		break;
		case "Fire_1":
			dialog.text = "Tu as accès à Tenochtitlan et tu peux entrer dans les temples des dieux. Le crâne de jade dont j'ai besoin se trouve dans le temple de la Grande Force de Vie. Pour y avoir accès, tu dois rassembler 10 totems de dieux et les placer sur les pierres sacrificielles de 10 temples.";
			link.l1 = "Et oם se trouvent ces temples ?";
			link.l1.go = "Fire_2";
		break;
		case "Fire_2":
			dialog.text = "Cinq dans la pyramide à gauche du temple de la Grande Force de Vie, cinq à sa droite. Les petites pyramides ont cinq entrées, chacune menant au temple de son dieu. Au-dessus de chaque entrée, tu peux voir l'image du dieu à qui appartient ce temple. Mieux vaut regarder à midi, pour ne pas te tromper d'entrée, car à chacune de tes visites, la force des gardiens du temple augmentera.";
			link.l1 = "Il y a aussi des gardiens dans le temple ?";
			link.l1.go = "Fire_3";
		break;
		case "Fire_3":
			dialog.text = "Oui, les guerriers aztèques ressuscités par Mictlantecuhtli. Tu devras les combattre. Tu ne pourras pas emmener d'aides à l'intérieur des temples, alors tu devras tout faire toi-même.";
			link.l1 = "Oui, mauvaise nouvelle... Quels sont ces 10 totems que je dois trouver ?";
			link.l1.go = "Fire_4";
		break;
		case "Fire_4":
			dialog.text = "Tu dois trouver les totems suivants : Xochiquetzal, déesse des fleurs et de l'amour. Mictlantecuhtli, dieu des morts que tu connais déjà. Quetzalcoatl, dieu de l'étoile du matin, seigneur des éléments. Mixcoatl, dieu de la chasse. Tezcatlipoca, protecteur des prêtres. Chalchiuhtlicue, déesse de la mer et des lacs. Huitzilopochtli, dieu du ciel bleu et clair. Tlaloc, dieu du tonnerre et de la pluie. Mayahuel, déesse de la fertilité. Tonacatecuhtli, dieu créateur qui donne la nourriture aux hommes.";
			link.l1 = "Compris. Maintenant, dis-moi oם trouver ces totems.";
			link.l1.go = "Fire_5";
		break;
		case "Fire_5":
			dialog.text = "Non, je ne peux pas faire ça. Cherche-les toi-même à travers le monde.";
			link.l1 = "Excellente nouvelle ! Dis donc, tu n'as pas besoin du crâne de jade ? Tu ne montres pas beaucoup de zèle dans cette affaire.";
			link.l1.go = "Fire_6";
		break;
		case "Fire_6":
			dialog.text = "C'est tout ce que je peux faire. Il y a une raison à tout ce que je fais, crois-moi.";
			link.l1 = "Compris... Bon, alors, attends que j'aie trouvé ces totems, que j'aie pénétré dans le temple et que je t'aie rapporté le crâne. J'ai bien peur que l'attente soit longue.";
			link.l1.go = "Fire_7";
		break;
		case "Fire_7":
			dialog.text = "J'attendrai, "+ GetSexPhrase("capitaine blanc", "belle squaw") +". C'est la seule chose qui me reste...";
			link.l1 = "Bon, à plus tard, alors.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Totem";
			pchar.questTemp.Teno = "openTenTemples";
			AddQuestRecord("Tenochtitlan", "3");
			AddQuestUserData("Tenochtitlan", "sSex", GetSexPhrase("", "e"));
		break;

		case "Totem":
			dialog.text = "Tu n'as pas le crâne de jade ! J'attends que tu me l'apportes, "+ GetSexPhrase("capitaine blanc", "belle squaw") +".";
			link.l1 = "Je m'en occupe, Montezuma.";
			link.l1.go = "exit";
		break;

        //после драки с
		case "AfterGTemple":
			if (CheckCharacterItem(pchar, "SkullAztec")) //череп найден
			{
				dialog.text = "Tu as le crâne de jade de Mictlantecuhtli ! Donne-le-moi !!!";
				if (CheckCharacterItem(pchar, "pistol7"))
				{
					link.l1 = "Et qu'est-ce que j'y gagne ? Je ne l'ai pas eu facilement, tu sais...";
					link.l1.go = "Skull_1";
				}
				else
				{
					link.l1 = "Pas si vite, l'ami ! Tu m'as promis une sorte d'arme puissante. Je n'ai toujours rien trouvé.";
					link.l1.go = "NotShootgun_1";
				}
			}
			else
			{
				dialog.text = "Tu as pénétré dans le temple de la Grande Force de Vie. Mais tu n'as pas le crâne de jade sur toi. Pourquoi ne l'as-tu pas pris ?";
				link.l1 = "Je ne l'ai pas trouvé.";
				link.l1.go = "NotSkull";
			}
		break;
		//с собой нет черепа
		case "NotSkull":
			dialog.text = "Tu mens, "+ GetSexPhrase("capitaine blanc", "squaw blanche") +". Montezuma te punira pour ça !";
			link.l1 = "Eh bien, essaie...";
			link.l1.go = "NotSkull_1";
		break;
		case "NotSkull_1":
			chrDisableReloadToLocation = true;
			LAi_group_SetRelation("MontesumaGroup", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("MontesumaGroup", LAI_GROUP_PLAYER, true);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NotShootgun_1":
			dialog.text = "L'arme se trouve dans le temple des Dieux Blancs, je te l'ai dit !";
			link.l1 = "Il est fermé.";
			link.l1.go = "NotShootgun_2";
		break;
		case "NotShootgun_2":
			dialog.text = "Le temple s'ouvre avec un couteau d'obsidienne, celui dont les prêtres se servent pour ouvrir le cœur des victimes. Trouve-le, et tu pourras ouvrir le temple.";
			link.l1 = "Oם puis-je le trouver ?";
			link.l1.go = "NotShootgun_3";
		break;
		case "NotShootgun_3":
			dialog.text = "Dans le temple de la Grande Force de Vie ; maintenant, donne-moi le crâne !";
			link.l1 = "Une simple indication que l'arme se trouve dans un temple quelconque ne me suffit pas. Et que puis-je obtenir d'autre de valeur ? דa n'a pas été facile d'avoir ce crâne, tu sais...";
			link.l1.go = "Skull_1";
		break;

		case "Skull_1":
			dialog.text = "Tu oses me contredire, imbécile ?! Tu ne sais pas à qui tu parles !";
			link.l1 = "Je le sais. Tu es Montezuma II, le dernier souverain des Aztèques. Mictlantecuhtli me l'a dit.";
			link.l1.go = "Skull_2";
		break;
		case "Skull_2":
			dialog.text = "C'est la dernière fois que je te demande de me donner le crâne de jade. Je t'ai aidé à l'obtenir, nous avons un marché !";
			link.l1 = "Pourquoi en avez-vous besoin ?";
			link.l1.go = "Skull_3";
		break;
		case "Skull_3":
			dialog.text = "Grâce à lui, je ramènerai mon peuple à la vie. Tenochtitlan retrouvera sa puissance, et l'empire aztèque conquerra les nations !";
			link.l1 = "Tes dieux ont tourné le dos aux Aztèques. Et ton peuple n'est plus.";
			link.l1.go = "Skull_4";
		break;
		case "Skull_4":
			dialog.text = "Je relèverai mon peuple de ses tombes grâce au crâne de jade ! Et nous nous trouverons de nouveaux dieux, nous les apaiserons avec le sang des esclaves. Les Aztèques retrouveront leur puissance, mais cette fois, nous aurons de l'expérience. Je ne répéterai pas les erreurs du passé, et les Blancs paieront leur traîtrise !";
			link.l1 = "Je ne te donnerai pas le crâne, Montezuma. Le tableau que tu viens de peindre ne me plaît pas.";
			link.l1.go = "Skull_5";
		break;
		case "Skull_5":
			dialog.text = "Alors, prépare-toi à mourir.";
			link.l1 = "Prépare-toi, toi aussi. J'ai tenu tête à Mictlantecuhtli en personne, et je vais t'envoyer sans faute rejoindre ta demeure permanente.";
			link.l1.go = "Skull_6";
		break;
		case "Skull_6":
			dialog.text = "Je ne peux pas mourir une seconde fois, "+ GetSexPhrase("capitaine blanc", "squaw blanche") +" !";
			link.l1 = "J'ai le crâne de jade, et il donne du pouvoir sur les morts. Alors, il en a aussi sur toi. Je crois que ça change tout.";
			link.l1.go = "Skull_7";
		break;
		case "Skull_7":
			AddQuestRecord("Tenochtitlan", "5");
			AddQuestUserData("Tenochtitlan", "sSex", GetSexPhrase("", "e"));
			LAi_SetImmortal(npchar, false);
			LocatorReloadEnterDisable("Tenochtitlan", "reload1_back", false);
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "MontesumaGroup");
			LAi_group_SetRelation("MontesumaGroup", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("MontesumaGroup", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("MontesumaGroup", "OpenTheDoors");
			pchar.quest.Teno_clearGroups.win_condition.l1 = "ExitFromLocation";
			pchar.quest.Teno_clearGroups.win_condition.l1.location = pchar.location;
			pchar.quest.Teno_clearGroups.function = "Teno_clearGroups";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

	}
}
