// LEO: Hired privateer at the bay - hand over the prize. Pay the rest, pick an officer to captain her.
// Logic - scripts/HiredPirate.c. Officer picker uses the "assign_<slot>" node-suffix trick (see Common_Governor.c).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	int i;
	int n;
	int oidx;
	int slot;
	string attr;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iRest = 0;
	if (CheckAttribute(pchar, "GenQuest.HiredPirate.Rest")) iRest = sti(pchar.GenQuest.HiredPirate.Rest);

	// выбор офицера: узел "assign_<slot>" -> достаём slot, идём в "assign"
	attr = Dialog.CurrentNode;
	if (findsubstr(attr, "assign_", 0) != -1)
	{
		i = findsubstr(attr, "_", 0);
		pchar.GenQuest.HiredPirate.PickSlot = strcut(attr, i + 1, strlen(attr) - 1);
		Dialog.CurrentNode = "assign";
	}

	switch (Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
		break;

		case "First time":
			// квест уже закрыт (приз забран/провал) - ничего не предлагаем (страховка от повторной выдачи за 0)
			if (!HiredPirate_IsActive())
			{
				dialog.text = "Notre affaire est conclue, capitaine. Bon vent.";
				link.l1 = "Bon vent.";
				link.l1.go = "exit";
				break;
			}
			// нет свободного слота корабля в эскадре
			if (GetCompanionQuantity(pchar) >= COMPANION_MAX)
			{
				dialog.text = "La voilà, capitaine : une belle prise. Mais votre flotte est complète. Libérez une place et revenez la chercher.";
				link.l1 = "Je vais faire de la place.";
				link.l1.go = "exit";
				break;
			}
			// нет денег на остаток
			if (sti(pchar.money) < iRest)
			{
				dialog.text = "La voilà. Le reste de mes honoraires s'élève à " + FindRussianMoneyString(iRest) + " , et il vous manque de l'argent. Revenez avec la somme.";
				link.l1 = "Je vais réunir la somme.";
				link.l1.go = "exit";
				break;
			}
			// список офицеров свиты
			dialog.text = "Ah, vous voilà. Votre navire est au mouillage dans la baie, capitaine : il est à vous dès que vous aurez réglé votre dמ. Le reste de mes honoraires : " + FindRussianMoneyString(iRest) + ". Qui en prendra le commandement ? Désignez l'un de vos officiers.";
			n = 0;
			for (i = 1; i <= MAX_NUM_FIGHTERS; i++)
			{
				oidx = GetOfficersIndex(pchar, i);
				if (oidx < 0) continue;
				attr = "l" + i;
				link.(attr) = GetFullName(&characters[oidx]) + " (" + FindRussianMoneyString(iRest) + ")";
				link.(attr).go = "assign_" + i;
				n++;
			}
			if (n == 0)
			{
				dialog.text = "La voilà, capitaine, mais vous n'avez aucun officier disponible à bord pour la commander. Revenez avec un officier dans votre suite.";
				link.l1 = "J'en amènerai un.";
				link.l1.go = "exit";
				break;
			}
			link.l90 = "Donnez-moi un instant.";
			link.l90.go = "exit";
		break;

		case "assign":
			slot = sti(pchar.GenQuest.HiredPirate.PickSlot);
			oidx = GetOfficersIndex(pchar, slot);
			if (oidx < 0) { dialog.text = "Celui-là n'est pas avec vous. Choisissez-en un autre."; link.l1 = "..."; link.l1.go = "First time"; break; }
			HiredPirate_GiveShip(oidx);
			dialog.text = "C'est fait. Ses papiers sont déjà à votre nom, tout est en règle, aucun rat de port n'y trouvera à redire. Le navire appartient désormais à votre officier, qu'il en prenne bien soin. Notre affaire est réglée, capitaine. Bon vent.";
			link.l1 = "Bon vent.";
			link.l1.go = "exit";
		break;
	}
}
