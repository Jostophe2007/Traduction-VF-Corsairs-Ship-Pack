// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//ОЗГ, Крыса
			if (checkattribute(pchar, "questTemp.Headhunter") && pchar.questTemp.Headhunter == "Rat" && pchar.questTemp.Headhunter.countP == 0)
			{
				link.l1 = "On dit qu'il n'y a pas si longtemps, un navire marchand a disparu après avoir quitté votre port. Pouvez-vous m'en dire davantage ?";
				link.l1.go = "Rat_portmanP";
			}
		break;

		//ОЗГ, Крыса
		case "Rat_portmanP":
			dialog.text = "Oui, une sale histoire, je m'en souviens comme si c'était hier : toute une pinasse chargée d'acajou presque à ras bord. Son capitaine était si content de sa bonne affaire qu'il a passé toute la soirée, la veille du départ, à faire la noce à la taverne et à se vanter. Et puis la nouvelle est arrivée : il n'avait jamais atteint le port oם il se rendait. On dit qu'il a été intercepté par des pirates.";
			link.l1 = "Oui, ce ne sont pas les gaillards de ce genre qui manquent dans nos eaux. Dites-moi, pourriez-vous voir quels navires se trouvaient dans votre port en même temps que cette malheureuse pinasse ?";
			link.l1.go = "Rat_portmanP_1";
		break;

		case "Rat_portmanP_1":
			dialog.text = "Voyons voir. Alors... voilà. Il y avait : la goélette Jenny, la corvette Swift et la pinasse Adelaide.";
			link.l1 = "Merci !";
			link.l1.go = "CheckP";
			pchar.questTemp.Headhunter.count = sti(pchar.questTemp.Headhunter.count) + 1;
			pchar.questTemp.Headhunter.countP = 1;
		break;

		case "CheckP":
			if(pchar.questTemp.Headhunter.count == 3)
			{
				pchar.questTemp.Headhunter = "Rat_Tavern";
				pchar.questTemp.Headhunter.Ratrumcity = npchar.city;
				AddQuestRecord("Headhunt", "13");
			}
			else
			{
				AddQuestRecord("Headhunt", "12_2");
			}
			DialogExit();
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}


