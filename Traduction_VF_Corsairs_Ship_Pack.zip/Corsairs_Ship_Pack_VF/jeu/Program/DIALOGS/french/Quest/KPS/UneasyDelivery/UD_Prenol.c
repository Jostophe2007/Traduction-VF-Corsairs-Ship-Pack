// Gregg: Jacque Prenol - quest "Goods for Richard Tillman" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\uneasydelivery.c
//
// Prenol's catchphrase "That is fine, that is good" (nodes 9 and 18) is not decoration:
// later it turns out to be the key phrase for the contact at the pearl fishery.
// It must read identically here, in Shon's node 20 and in Charly's check.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (sti(PChar.UneasyDelivery) > 3)
			{
				dialog.text = "Comment avance l'affaire que je vous ai confiée ?";
				link.l1 = "Je m'en occupe.";
				link.l1.go = "exit";
				break;
			}
			if (PChar.UneasyDelivery == "3")
			{
				dialog.text = "Il n'y a pas de travail aujourd'hui, revenez demain.";
				link.l1 = "Très bien, je reviendrai demain sans faute.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Salutations, je suis " + GetFullName(NPChar) + " ! Vous auriez besoin d'un lot d'excellente cannelle ou de paprika ? Ou bien souhaitez-vous acheter un peu de marchandise vivante ? Le capitaine désire peut-être acquérir du bois d'ébène ou de l'acajou de la plus haute qualité ?";
			link.l1 = "Je n'ai besoin de rien. Je vous ai apporté un lot de porcelaine de la part de Richard Tillman.";
			link.l1.go = "2";
		break;

		case "2":
			// Gregg: mistaking the player for Fatman only fits after the prologue, where the
			// player really did bring his lugger. Via the innkeeper Prenol simply expects
			// a man sent by Tillman.
			if (CheckAttribute(PChar, "UneasyDelivery.NoCocoa"))
			{
				dialog.text = "Ah ! C'est donc Richard qui vous envoie ?";
				link.l1 = "Capitaine " + GetFullName(PChar) + ". Voici la lettre de Richard Tillman, il y explique tout.";
			}
			else
			{
				dialog.text = "Ah ! Vous êtes le capitaine Tommi, dit Fatman, n'est-ce pas ?";
				link.l1 = "Non, je suis le capitaine " + GetFullName(PChar) + ". C'est moi qui remplace Fatman, maintenant. Voici la lettre de Richard Tillman, il y explique tout.";
			}
			link.l1.go = "3";
		break;

		case "3":
			TakeNItems(PChar, "RichardTillmanNotice", -1);
			// Gregg: praise for killing Fatman only fits after the prologue.
			// Coming through the innkeeper, the player never laid eyes on Fatman.
			if (CheckAttribute(PChar, "UneasyDelivery.NoCocoa"))
			{
				dialog.text = "...(il lit la lettre)... Bon, bon. Richard écrit qu'on peut compter sur vous. Eh bien, nous verrons.";
			}
			else
			{
				dialog.text = "...(il lit la lettre)... דa alors ! Richard dit que vous avez tué Fatman en personne. Bravo, je vous tire mon chapeau.";
			}
			link.l1 = "וcoutez, monsieur Prenol, et si nous parlions affaires ? Vous attendez votre porcelaine, j'attends ma récompense. Finissons-en enfin.";
			link.l1.go = "4";
		break;

		case "4":
			AddMoneyToCharacter(PChar, 6000);
			TakeNItems(PChar, "UneasyDeliveryPorcelain", -25);
			dialog.text = "Ah oui, voici vos 6000. Pardonnez-moi, je n'ai jamais payé personne davantage pour une livraison.";
			link.l1 = "Nous étions convenus de sept mille. Six ne me conviennent pas du tout.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Nous ne sommes convenus de rien, monsieur " + PChar.lastname + ". C'est Tillman qui vous a menti en disant que je paierais sept mille. Si vous voulez, réclamez votre millier à Tillman. Je n'ai pas plus d'argent.";
			link.l1 = "Non, c'est vous qui allez me payer, " + NPChar.lastname + " ! On m'a prévenu que vous essayez constamment de rouler ceux avec qui vous travaillez. Avec moi, ça ne passera pas. Donnez-moi le millier tout de suite, sinon... sinon, je ne réponds plus de moi, " + NPChar.lastname + ". Je vous aurai prévenu.";
			link.l1.go = "6";
		break;

		case "6":
			AddMoneyToCharacter(PChar, 1000);
			dialog.text = "Bon, bon, voici votre millier. Vous êtes calmé, maintenant ?";
			link.l1 = "Je devrais vous en coller une ou deux, pour vous apprendre.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Il faut bien survivre. Je dois souvent travailler avec des gens qui ne savent pas ou ne veulent pas se battre pour leur argent. Il est difficile de ne pas saisir l'occasion d'essayer de rouler quelqu'un de deux ou trois mille. Mais vous, vous me plaisez ! Vous savez obtenir ce que vous voulez. Et j'ai du travail pour vous. Ou plutכt, j'en aurai.";
			link.l1 = "Seulement si vous essayez encore une fois de...";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "...(l'interrompant)... Non, bien sמr que non, plus jamais. Passez dans la semaine, et vous aurez une excellente mission. Vous viendrez ?";
			link.l1 = "Soit, je passerai.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "C'est très bien, c'est parfait ! Je vous attendrai.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryTimer");
		break;

		case "10":
			dialog.text = PChar.name + ", ce sont des bandits, ils veulent me tuer, au secours !";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryPrenolExit");
		break;

		case "11":
			dialog.text = "Vous les avez tués, " + PChar.name + " ? Tous ?";
			link.l1 = "Oui, les bandits sont morts.";
			link.l1.go = "12";
		break;

		case "12":
			AddMoneyToCharacter(PChar, 5000);
			dialog.text = "Dieu merci ! Tenez, prenez 5000 piastres pour votre aide. Sans vous, je ne serais plus là.";
			link.l1 = "Alors c'était ça, le travail que vous comptiez me confier ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Non, non, je voulais vous demander de transporter une cargaison. Mais ces voyous sont arrivés et se sont mis à exiger mes économies. Je savais que vous viendriez me voir, et j'ai délibérément gagné du temps en attendant votre arrivée.";
			link.l1 = "Vous auriez au moins pu rester m'aider ! א deux contre trois, c'est bien mieux que seul.";
			link.l1.go = "14";
		break;

		case "14":
			if (CheckAttribute(PChar, "UneasyDelivery.NoCocoa"))
			{
				dialog.text = "Je ne sais pas du tout tenir une épée, " + PChar.name + ". Mais vous, vous êtes un vrai combattant, ça se voit au premier coup d'œil, et j'étais certain que vous viendriez à bout de ces trois-là. Merci.";
			}
			else
			{
				dialog.text = "Je ne sais pas du tout tenir une épée, " + PChar.name + ". Mais vous, vous êtes un vrai combattant, vous avez tué Fatman, et j'étais certain que vous viendriez à bout de ces trois-là. Merci.";
			}
			link.l1 = "Ce n'est rien. Vous m'avez payé, je suis content. Et le travail ? Vous aviez une cargaison à livrer ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Je confierai la cargaison à un autre, mais à vous, je veux proposer une commission. Je sais qui a envoyé ces trois-là, et je veux régler mes comptes avec lui. C'est un vieux rival qui a essayé plus d'une fois de me nuire. Je veux que vous le tuiez. Vous acceptez ?";
			link.l1 = "Combien paierez-vous ?";
			link.l1.go = "16";
		break;

		// Gregg: Damned Destiny promised 20,000. The sums of the quest are cut by a factor
		// of ten - see the header of uneasydelivery.c; the same division here, otherwise
		// Prenol's promise would exceed the whole debt Shon later speaks of.
		case "16":
			dialog.text = "Dans le coffre de sa maison, vous trouverez 15 000 piastres et une collection d'armes uniques. Il a commencé à la rassembler dans sa jeunesse. Alors, vous acceptez ?";
			link.l1 = "Parfait. Son nom, et oם il habite.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Il s'appelle Shon Stablovski, il habite sur l'île d'Antigua. Quand vous le trouverez, tuez-le sans discuter.";
			link.l1 = "Très bien, je comprends.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "C'est très bien, c'est parfait ! Je vous attendrai chez moi. Bon voyage.";
			link.l1 = "Bonne journée, Jacque.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryJacquePrenolBackToHouse");
		break;

		// Gregg: player caught stealing - the short local variant, see UD_Tillman.c
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur ! La garde, arrêtez le voleur !!!", "דa alors ! Je détourne les yeux un instant, et vous voilà la tête la première dans le coffre ! Au voleur !!!", "La garde ! Au vol !!! Arrêtez le voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
