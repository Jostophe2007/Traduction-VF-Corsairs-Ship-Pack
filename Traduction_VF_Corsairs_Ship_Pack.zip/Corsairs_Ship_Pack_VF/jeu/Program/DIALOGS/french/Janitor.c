
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First":
			dialog.text = RandPhraseSimple("Ils se promènent ici, ils piétinent tout, et après, c'est moi qui nettoie...", "Et qu'est-ce qui t'amène"+GetSexPhrase(" ici ? La résidence a besoin d'être nettoyée, et lui, il traîne de la boue partout.", " ici ? La résidence a besoin d'être nettoyée, et elle, elle traîne de la boue partout."));
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
