// Герцог Альбермаль и другие
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            // ==> Боцман Морриса Уильямса
            if (pchar.questTemp.State == "MorrisWillams_ModifordGood5000" && npchar.id == "Bocman_Willams")// перехват на посыльного Морриса Уильямса
            {
    			dialog.text = "Hé, capitaine, on dirait que vous prenez la mer ?";
    			link.l1 = "Oui, je pars. Qu'est-ce que ça peut vous faire, et qui êtes-vous ?";
    			link.l1.go = "Step_E6_1";
            }
            if (pchar.questTemp.State == "MorrisWillams_GoToHimselfBussines" && npchar.id == "Bocman_Willams")// перехват на посыльного Морриса Уильямса второй раз
            {
    			dialog.text = "Capitaine, bonjour. C'est encore moi, le maître d'équipage du Favorit.";
    			link.l1 = "Qu'avez-vous à me dire, cette fois ?";
    			link.l1.go = "Step_E6_4";
            }
			// ==> Джилиан Эттербери.
			if (pchar.questTemp.State == "MorrisWillams_ArrestedSeekInfoWomen" && npchar.id == "Gillian Atterbury") // англ.линейка квест №6, разговор с Джиллиан Эттербери
            {
    			dialog.text = "Que me voulez-vous ?";
                link.l2 = "וcoutez, le saint père m'a conseillé de m'adresser à vous.";
                link.l2.go = "Step_E6_25";
            }
			if (pchar.questTemp.State == "MorrisWillams_SeekHusband" && npchar.id == "Gillian Atterbury") // англ.линейка квест №6, разговор с Джиллиан Эттербери после дачи задания
            {
    			dialog.text = "Avez-vous appris quelque chose sur mon mari, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
    			link.l1 = "Pas encore, mais je m'en occupe. Je ferai de mon mieux pour le retrouver.";
    			link.l1.go = "exit";
            }
			if (npchar.id == "Gillian Atterbury" && CheckAttribute(npchar, "TempQuest.SavedHusband")) // разговор с Джиллиан Эттербери, если мы спасли её мужа
            {
                dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Monsieur", "Mademoiselle") +", je n'oublierai jamais ce que vous avez fait pour nous. Vous avez sauvé la vie de mon mari et délivré notre famille de ses dettes. Nous donnerons votre nom à notre enfant.",
                         "C'est encore vous, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je suis si contente de vous voir !", ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", nous vous voyons pour la énième fois aujourd'hui. C'est tout simplement merveilleux !",
                         ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", peu importe combien de fois vous venez me voir, sachez que je suis toujours contente de vous voir.", "block", 1, npchar, Dialog.CurrentNode);
    			link.l1 = HeroStringReactionRepeat("Allons, ce n'est rien... Mais vous savez, ça fait quand même plaisir...",
                                               "Eh bien...",
                                               "Je le pense aussi...",
                                               "Hum, comme c'est gentil ! Merci.", npchar, Dialog.CurrentNode);
    			link.l1.go = "exit";
    			//ChangeCharacterReputation(pchar, 1); // чит, но вряд ли кто-то найдёт TO_DO eddy
            }
            // ==> Один из бандитов в пещере, удерживающий мужа Джилиан
            if (pchar.questTemp.State == "MorrisWillams_SeekHusband" && npchar.id == "Bandit3")   // базар в пещере перед боевкой
            {
    			dialog.text = "Bon sang...";
    			link.l1 = "Qui êtes-vous, et que faites-vous ici ?!!";
    			link.l1.go = "Step_E6_30";
            }
            // ==> Муж Джилиан
            if (pchar.questTemp.State == "MorrisWillams_AfterFight" && npchar.id == "Jillians_Husband")   // базар в пещере с мужем, англ.линейка, квест №6
            {
    			dialog.text = "Vous m'avez sauvé la vie ! Merci !";
    			link.l1 = "Les remerciements, ce sera pour plus tard. Vous vous appelez bien Tom Ettrebury ?";
    			link.l1.go = "Step_E6_32";
            }
            // ==> Спасишийся перец в поселении буканьеров
            if (pchar.questTemp.State == "ToMansfield_GoOn")   // разговор со спасшимся перцем, анл.линейка, квест №8
            {
    			dialog.text = "Un corsaire anglais ! Le Seigneur soit loué !";
    			link.l1 = "Que s'est-il passé ici ?";
    			link.l1.go = "Step_E8_1";
            }
            if (pchar.questTemp.State == "ToMansfield_CatchToPardal")   // остаточный разговор со спасшимся перцем
            {
    			dialog.text = "Il faut vous dépêcher. Les galions sont partis il y a presque une journée, vous risquez de ne pas les rattraper.";
    			link.l1 = "Oui, je sais. En effet, il faut se dépêcher...";
    			link.l1.go = "exit";
            }


        break;

        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//*************************************** Диалог боцмана Морриса Уильямса *********************************
 		case "Step_E6_1":
			dialog.text = "Je suis le maître d'équipage de la frégate Favorit. Il n'y a pas longtemps, je vous ai vu sur notre pont, vous parliez au capitaine...";
			link.l1 = "C'est exact, continuez.";
			link.l1.go = "Step_E6_2";
		break;

 		case "Step_E6_2":
			dialog.text = "Notre capitaine est à la taverne, il a déjà bu tout un tonneau de rhum. Il m'a envoyé vous chercher. Il vous attend, c'est urgent.";
			link.l1 = "D'accord, j'y vais immédiatement.";
			link.l1.go = "Step_E6_3";
		break;

 		case "Step_E6_3":
			chrDisableReloadToLocation = false;
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 40.0);
            LAi_SetPlayerType(pchar);
            sld = characterFromID("Morris_Willams");
            LAi_SetHuberTypeNoGroup(sld);
			FreeSitLocator("PortRoyal_tavern", "sit10");
            ChangeCharacterAddressGroup(sld, "PortRoyal_tavern", "sit", "sit10");
            LocatorReloadEnterDisable("PortRoyal_town", "gate_back", true); //на всякий случай, чтобы геймер не слинял.
            LocatorReloadEnterDisable("PortRoyal_town", "reload1_back", true);
            NextDiag.TempNode = "First time";
            DialogExit();
		break;

 		case "Step_E6_4":
			dialog.text = "Il n'y a pas grand-chose de bon, ou plutכt rien du tout. Notre capitaine Williams vient d'être arrêté en sortant de la taverne\n"+
                          "Une dizaine de soldats l'ont encerclé, le commandant lui a montré un papier, et on a emmené le capitaine.";
			link.l1 = "Et vous n'avez pas pris sa défense ? Oם est votre équipage ?";
			link.l1.go = "Step_E6_5";
		break;

 		case "Step_E6_5":
			dialog.text = "Il n'y a plus d'équipage, capitaine, tout le monde s'est enfui. Il ne reste que quelques hommes à bord. Et le navire a été saisi, lui aussi..\n"+
                          "Bref, les choses vont mal, très mal...";
			link.l1 = "Je vais voir le commandant pour savoir de quoi il retourne. Ne vous laissez pas abattre, retournez à votre chaloupe et maintenez l'ordre. Je ferai sortir votre capitaine, vous pouvez en être sמr.";
			link.l1.go = "Step_E6_6";
		break;

 		case "Step_E6_6":
			chrDisableReloadToLocation = false;
    	    npchar.LifeDay = 1; // уберём нпс на след.день.
    	    SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			pchar.questTemp.State = "MorrisWillams_ArrestedToPrison";
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 40.0);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "15");
            ref sld = characterFromID("Morris_Willams");
			LAi_SetStayType(sld);
            ChangeCharacterAddressGroup(sld, "PortRoyal_prison", "goto", "goto9");
            RemoveCharacterEquip(sld, BLADE_ITEM_TYPE);
            RemoveCharacterEquip(sld, GUN_ITEM_TYPE);
            LAi_SetPlayerType(pchar);
			DialogExit();
		break;

//*********************************** Диалоги Джиллиан Эттербери *************************************
		case "Step_E6_25":
			dialog.text = "De quoi s'agit-il, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "N'ayez pas peur, je ne vous ferai aucun mal. J'ai juste un compte à régler avec un usurier. Si je comprends bien, nous avons des intérêts communs.";
			link.l1.go = "Step_E6_26";
		break;

        case "Step_E6_26":
			dialog.text = "(en pleurs) "+ GetSexPhrase("Monsieur", "Mademoiselle") +", c'est terrible. Mon mari Tom a disparu.";
			link.l1 = "Calmez-vous et racontez-moi tout en détail, je vous en prie.";
			link.l1.go = "Step_E6_27";
		break;

        case "Step_E6_27":
			dialog.text = "Nous devions de l'argent à l'usurier et nous n'avons pas remboursé la dette à temps. Alors il est venu chez nous et a dit à mon mari qu'il le ferait jeter en prison si nous ne remboursions pas la dette avec les intérêts dans la semaine\n"+
                     "Nous avons donné tout ce que nous avions, mais cela ne couvrait pas les intérêts accumulés sur un an\n"+
                     "Mon mari lui a demandé un délai de paiement, mais n'a obtenu qu'une semaine de plus pour rembourser le reste\n"+
                     "Alors mon mari est parti chercher de l'argent. Il n'en a pas trouvé, mais il a appris quelque chose qui, selon lui, nous permettra de ne pas avoir peur de la prison\n"+
                     "Hier, il a passé toute la journée en ville, puis il est passé une minute à la maison, a fait son sac et il est reparti dans la nuit. Il n'est toujours pas revenu. J'ai très peur !";
			link.l1 = "Oם est-il allé ? Il a dit quelque chose ?";
			link.l1.go = "Step_E6_28";
		break;

        case "Step_E6_28":
			dialog.text = "Il a seulement dit qu'il sortait de la ville. Rien d'autre, il était pressé (en pleurs). "+ GetSexPhrase("Monsieur", "Mademoiselle") +", je vous en supplie, aidez-moi à retrouver mon mari !";
			link.l1 = "Je ferai de mon mieux.";
			link.l1.go = "exit";
			pchar.questTemp.State = "MorrisWillams_SeekHusband";
			AddQuestRecord("Eng_Line_6_MorrisWillams", "20");
            Pchar.quest.MorrisWillams_HusbandInCave.win_condition.l1 = "location";
            Pchar.quest.MorrisWillams_HusbandInCave.win_condition.l1.location = "Jamaica_Grot";
            Pchar.quest.MorrisWillams_HusbandInCave.win_condition = "MorrisWillams_HusbandInCave";
		break;



//**************************** Диалоги бандита в пещере, поиски мужа Джиллиан ****************************
 		case "Step_E6_30":
			dialog.text = "Finissons-en avec "+ GetSexPhrase("lui", "elle") +", pas besoin de témoins...";
			link.l1 = "Hum...";
			link.l1.go = "Step_E6_31";
		break;

 		case "Step_E6_31":
            LAi_SetPlayerType(pchar);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "MorrisWillams_AftreFightingInCave");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

//************************************** Диалоги мужа Джиллиан ***********************************
 		case "Step_E6_32":
			dialog.text = "Oui, mais comment le savez-vous ? Enfin, peu m'importe, je suis plus content de vous voir que de voir l'archange Gabriel !";
			link.l1 = "Racontez-moi ce qui s'est passé.";
			link.l1.go = "Step_E6_33";
		break;

 		case "Step_E6_33":
			dialog.text = "Je ne sais même pas par oם commencer... Il y a environ un an, nous avons emprunté de l'argent à un usurier...";
			link.l1 = "Je sais tout ça, racontez-moi à partir du moment oם vous avez quitté la ville cette nuit. Qu'avez-vous découvert sur l'usurier ?";
			link.l1.go = "Step_E6_34";
		break;

 		case "Step_E6_34":
			dialog.text = "Ce démon est de mèche avec des contrebandiers ! Hier, j'ai remarqué qu'un étrange inconnu entrait chez lui par la porte de derrière. J'ai attendu qu'il ressorte et je l'ai suivi\n"+
                          "J'ai réussi à le suivre presque jusqu'ici quand je suis tombé dans une embuscade. Ils m'ont attrapé et traîné ici. Ils voulaient me tuer, mais ils ont décidé de découvrir d'abord qui j'étais, et peut-être de tirer de l'argent de ma capture\n"+
                          "Vous êtes arrivé à temps, "+ GetSexPhrase("monsieur", "mademoiselle") +". Merci du fond du cœur !";
			link.l1 = "Tout est clair. Maintenant, courez en ville retrouver votre femme, votre disparition l'a beaucoup effrayée. Considérez que votre dette envers l'usurier n'existe plus. Mais ne parlez de cette affaire à personne, et il vaudrait mieux quitter la ville.";
			link.l1.go = "Step_E6_35";
		break;

 		case "Step_E6_35":
			Characters[GetCharacterIndex("Gillian Atterbury")].TempQuest.SavedHusband = 1; // чтоб Джиллиан помнила об услуге...
            AddQuestRecord("Eng_Line_6_MorrisWillams", "21");
            LAi_SetPlayerType(pchar);
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 5.0);
            //ChangeCharacterReputation(pchar, 5); TO_DO eddy
            pchar.questTemp.State = "MorrisWillams_AfterFightGoRedmond";
			DialogExit();
		break;

//************************************** Диалоги спасшегося буканьера ***********************************
  		case "Step_E8_1":
			dialog.text = "Des Espagnols sur trois galions se sont approchés de la baie, ont débarqué et ont pris notre colonie d'assaut.";
			link.l1 = "Bon sang ! Oם est Mansfield ?";
			link.l1.go = "Step_E8_2";
		break;

   		case "Step_E8_2":
			dialog.text = "Tué, comme beaucoup d'autres. Environ la moitié des boucaniers ont réussi à se replier hors de la colonie. Et heureusement qu'ils sont partis, sinon ç'aurait été la fin pour tout le monde.";
			link.l1 = "Je ne reconnais pas là les boucaniers. Depuis quand reculent-ils devant les Espagnols ?";
			link.l1.go = "Step_E8_3";
		break;

   		case "Step_E8_3":
			dialog.text = "Ils étaient très nombreux, et armés jusqu'aux dents\n"+
                          "Ils ont débarqué les couleuvrines des navires et nous ont tout simplement fusillés, alors que nos mousquets ne pouvaient pas les atteindre\n"+
                          "Nous avons lancé un raid contre la batterie espagnole, mais ils ont anéanti tout le groupe d'assaut en trois salves de mousquets\n"+
                          "Aucun des gars n'a survécu : ces démons ont aussitכt contre-attaqué, et ils ont achevé les blessés au passage...";
			link.l1 = "Bon sang ! Je suis venu voir Mansfield de la part de Madiford. Je dois récupérer l'or préparé pour lui.";
			link.l1.go = "Step_E8_4";
		break;

   		case "Step_E8_4":
			dialog.text = "Les Espagnols ont tout pris. Mansfield est mort.";
			link.l1 = "Que pouvez-vous me dire d'autre ?";
			link.l1.go = "Step_E8_5";
		break;

   		case "Step_E8_5":
			dialog.text = "Je sais qu'ils sont partis pour Cuba, à Santiago.";
			link.l1 = "Comment le savez-vous ?";
			link.l1.go = "Step_E8_6";
		break;

   		case "Step_E8_6":
			dialog.text = "Quand les Espagnols ont fait irruption ici, j'ai fait le mort et je suis resté étendu là, à l'écart\n"+
                          "Je comprends un peu l'espagnol, et j'ai entendu parler leur capitaine ; ils l'appelaient Manoel\n"+
                          "Ils ont fouillé la colonie, chargé tout ce qu'ils ont trouvé sur leurs navires et sont partis pour Santiago. De toute façon, nous nous y préparions. D'après la conversation, ils venaient de Santiago.";
			link.l1 = "Manoel... Ce ne serait pas Manoel Rivero Pardal ? Le seul corsaire espagnol dans ces eaux ? Hum... Bon, merci. Vos camarades vont bientכt revenir. Dites-leur que je les vengerai.";
			link.l1.go = "Step_E8_7";
		break;

   		case "Step_E8_7":
			dialog.text = "Merci. Si vous voulez rattraper les Espagnols en chemin, dépêchez-vous.";
			link.l1 = "Ne vous inquiétez pas, je rattraperai les galions.";
			link.l1.go = "exit";
			pchar.questTemp.State = "ToMansfield_CatchToPardal";
			AddQuestRecord("Eng_Line_8_ToMansfield", "2");
			
			Pchar.quest.ToMansfield_OutFromFort.win_condition.l1 = "location";
			Pchar.quest.ToMansfield_OutFromFort.win_condition.l1.location = "LaVega_town";
			Pchar.quest.ToMansfield_OutFromFort.win_condition = "ToMansfield_OutFromFort";
		break;

        case "You_baster":
            dialog.text = "Je n'aurais jamais imaginé que vous me feriez ça...";
            link.l1 = "Je vous cite, monsieur : « Je n'ai plus rien à vous dire. La politique gouverne le destin des וtats, inutile de penser au destin de quelques... gouverneurs généraux. » Adieu.";
            link.l1.go = "exit";
            NextDiag.TempNode = "You_baster";
			pchar.questTemp.jailCanMove = true;
        break;
    }
}
