# -*- coding: utf-8 -*-
"""Quick sanity check of a translation file against work/batch.txt before importing:
flags missing ids and lines whose leading/trailing punctuation differs from the english
(a shifted numbering shows up as a long run of such warnings).

usage: python -X utf8 align_check.py <file.fr.txt>
"""
import os
import re
import sys

WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'work')
P = set(',.;:!?\')-')


def edge(s):
    s = s.strip().replace('␣', '')
    if s.startswith('SEXE[') and s.endswith(']'):
        s = s[5:-1]
    return (s[:1] in P, s[-1:] in P) if s else (None, None)


def main(path):
    en = {}
    for line in open(os.path.join(WORK, 'batch.txt'), encoding='utf-8'):
        m = re.match(r'^(\d+)(?:\[\w\]|\s\([^)]*\))?\t(.*)$', line.rstrip('\n'))
        if m:
            en[m.group(1)] = m.group(2)
    fr = {}
    for line in open(path, encoding='utf-8'):
        if '\t' in line:
            i, t = line.rstrip('\n').split('\t', 1)
            fr[i.strip()] = t
    missing = [i for i in en if i not in fr]
    extra = [i for i in fr if i not in en]
    warn = []
    for i, e in en.items():
        f = fr.get(i)
        if f is None or f.strip() == '=':
            continue
        a, b = edge(e), edge(f)
        if a[0] is not None and b[0] is not None and a[0] != b[0]:
            warn.append(i)
    print('ids: %d anglais, %d traduits ; manquants %s ; en trop %s' % (len(en), len(fr), missing[:10], extra[:10]))
    if warn:
        print('ponctuation initiale differente :', ', '.join(warn[:40]))


if __name__ == '__main__':
    main(sys.argv[1])
