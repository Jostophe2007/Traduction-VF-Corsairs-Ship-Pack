// Gregg: Фернандо Эстикос - трилогия «Чёрная Орхидея», глава 5 (перенос из К:ПС).
// Логика - Program\Quests\reaction_functions\blackorchid.c
// Спившийся компаньон Бернальдинио Торангеры, сидит в таверне Портобелло:
//   1     - зовёт выпить, ГГ подсаживается (DestinyGiftInPortoBelloTavern);
//   2-7   - что случилось со «Стервятником» и где видели его остов;
//   7     - выход, задание найти остов (DestinyGiftFindBernaldinioShip).
// Узлы 1 и 2 выставляет логика, остальные идут по цепочке.
// Gregg: в оригинале капитан видел остов «где-то на Мэйне» без подробностей, и игрока
// отправляли обыскивать всё побережье. У нас бухта с остовом доступна только пешком,
// с моря к ней не подойти, поэтому Фернандо называет место: мыс Несбывшихся Надежд,
// за Дес-Мойнесом. Иначе игрок ушёл бы искать точку на глобальной карте, которой нет.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Bonne chance à toi, cap'taine !";
			link.l1 = "Et bonne santé à toi. Et arrête donc de boire.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Tu veux boire un coup avec moi ? Assieds-toi, alors, qu'est-ce que tu fais planté là !";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftInPortoBelloTavern");
		break;

		case "2":
			dialog.text = "Tavernier ! Du rhum ! Et à quoi on boit, cap'taine ?";
			link.l1 = "On a toujours le temps de se soמler, Fernando. Dis-moi plutכt ce qu'est devenu ton associé, Bernaldinio Toranger.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je ne sais pas, cap'taine. Pendant notre dernier voyage ensemble, une tempête d'une force effroyable s'est levée et nous a séparés. J'ai continué seul, et Bernaldinio n'est jamais arrivé au port. Ni lui, ni le Vautour. Quoique...";
			link.l1 = "Quoique quoi ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "J'ai entendu quelque chose de la bouche d'un marchand, à la taverne de Porto Rico. Il dit avoir vu la carcasse pourrie du Vautour sur le rivage du continent. Donc, ce jour maudit, le navire a été jeté sur les rochers. Seulement, moi, je n'y crois pas.";
			link.l1 = "Pourquoi ? Des navires plus solides que le sien ont été jetés à la cכte par des tempêtes.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Je sais. Mais Bernaldinio savait mener un navire à travers les pires tempêtes. Il ne se serait jamais laissé jeter sur une plage.";
			link.l1 = "Et oם exactement ce marchand a-t-il vu le Vautour ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Sur la cכte du continent, près du cap des Espoirs déçus. Un endroit isolé : on ne peut pas l'approcher par la mer, seulement par la terre, à travers la jungle au-delà de Des Moines. Et en quoi ça te regarde ? Tu tiens à retrouver son navire ?";
			link.l1 = "Oui. Bernaldinio avait une certaine chose dont j'ai besoin, et la carcasse du Vautour est ma seule piste.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Alors bon vent à toi, cap'taine.";
			link.l1 = "Et bon vent à toi, Fernando.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFindBernaldinioShip");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
