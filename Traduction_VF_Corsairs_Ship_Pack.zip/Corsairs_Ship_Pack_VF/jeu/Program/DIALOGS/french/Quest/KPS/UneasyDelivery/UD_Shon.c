// Gregg: Shon Stablovski - quest "Goods for Richard Tillman" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\uneasydelivery.c
//
// The sums are cut by a factor of ten along with the whole quest: Prenol's debt is 20,000
// instead of 200,000, Tillman's half is ten thousand instead of a hundred, and the earlier
// deals "never above three thousand". The wait is shortened from three months to two weeks.
// The money is taken and the blade given by the DIALOG itself (nodes 25 and 27) - the logic
// does not repeat it, otherwise it would be charged twice.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (PChar.UneasyDelivery == "END")
			{
				dialog.text = "Ah, c'est vous, capitaine " + GetFullName(PChar) + ". Comment allez-vous ?";
				link.l1 = "Mieux que la plupart. Portez-vous bien, Shon.";
				link.l1.go = "exit";
				break;
			}
			if (PChar.UneasyDelivery == "16")
			{
				dialog.text = "Alors, oם en sont les choses, " + PChar.name + " ?";
				link.l1 = "C'est une longue histoire. En bref, Jacque Prenol est mort, mais je n'ai pas pu récupérer votre argent.";
				link.l1.go = "22";
				if (sti(PChar.money) >= 30000)
				{
					link.l2 = "Tout est en ordre. Prenol est dans l'autre monde, et j'ai réussi à récupérer vos trente mille. Les voici.";
					link.l2.go = "25";
				}
				break;
			}
			if (sti(PChar.UneasyDelivery) >= 11)
			{
				dialog.text = "Ah, c'est vous, " + GetFullName(PChar) + ". Comment avance le travail sur notre ami commun ?";
				link.l1 = "Je m'en occupe, n'en doutez pas.";
				link.l1.go = "exit";
				break;
			}
			if (PChar.UneasyDelivery == "10")
			{
				dialog.text = "Ah, c'est vous, " + GetFullName(PChar) + ". Il n'y a encore rien, je n'ai rien pu apprendre.";
				link.l1 = "Mais moi, j'ai appris quelque chose. Jacque Prenol était de mèche avec Richard Tillman...";
				link.l1.go = "18";
				break;
			}
			if (PChar.UneasyDelivery == "8")
			{
				dialog.text = "Ah, c'est vous, " + GetFullName(PChar) + ". Il n'y a encore rien, je n'ai rien pu apprendre.";
				link.l1 = "Très bien, je repasserai plus tard.";
				link.l1.go = "exit";
				break;
			}
			if (PChar.UneasyDelivery == "6")
			{
				dialog.text = "Je vous prierais de me libérer de votre présence.";
				link.l1 = "Hum... Comme vous voudrez.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Qu'y a-t-il pour votre service ?";
			link.l1 = "Hé-hé. Il faut que nous parlions...";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Asseyez-vous, parlons.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryShonFirstSitDialog");
		break;

		case "3":
			dialog.text = "Alors, qu'y a-t-il pour votre service ?";
			link.l1 = "Vos coupe-jarrets sont morts, " + NPChar.name + ".";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Quels coupe-jarrets ? De quoi parlez-vous ?";
			link.l1 = "Ne faites pas semblant de n'y être pour rien.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Pardonnez-moi, mais je ne comprends vraiment pas de quoi vous parlez. Pourriez-vous me raconter plus en détail, car je n'y comprends rien ?";
			link.l1 = "Le nom de Jacque Prenol vous dit quelque chose ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Bien sמr, nous sommes associés depuis longtemps, et...";
			link.l1 = "Assez de mensonges ! Il y a quelques jours, trois tueurs ont essayé d'achever Prenol dans sa propre maison. C'est vous qui les avez envoyés, ils agissaient sur votre ordre, et vous...";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "...(l'interrompant)... Quoi ? וcoutez, quelles sottises racontez-vous ?! Quels tueurs, bon sang ? Je suis un honnête négociant, je travaille depuis longtemps avec Jacque Prenol, et... Attendez, vous avez dit qu'il y avait trois tueurs ?";
			link.l1 = "Oui, trois. Vous vous en souvenez, enfin ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Argh ! Le maudit scélérat ! Il m'a trompé. Je n'arrive pas à y croire, bon sang de bon sang.";
			link.l1 = "Trompé ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "וcoutez-moi bien. Ces trois que vous avez achevés dans la maison de Prenol étaient mes représentants commerciaux : ils apportaient à Prenol les arrhes d'un gros contrat de bois de santal, 30 000 piastres. Mais Jacque m'a trompé ! Visiblement, il a joué la victime que trois coupe-jarrets cherchaient soi-disant à tuer. \n Et une fois que vous les avez achevés, il vous a envoyé me tuer, moi, son prétendu client, pendant que lui filait avec l'argent. Vous êtes sans doute surpris que j'en sache autant sur ce qui s'est passé là-bas ? Il n'y a rien de surprenant : c'est la deuxième fois que Prenol utilise ce stratagème. Seulement, je ne pensais pas qu'il oserait l'utiliser contre moi.";
			link.l1 = "Mais... vous avez dit que vous travailliez depuis longtemps avec Prenol ? Alors pourquoi tuerait-il vos représentants ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Pour prendre les arrhes, ces mêmes 30 000. Le contrat entier se montait à cent bons milliers, mais les arrhes suffisaient à Jacque : jusque-là, il n'avait jamais tenu trois mille d'un coup. Alors il a décidé de les voler, la somme étant si grosse.";
			link.l1 = "Alors il m'a trompé, moi aussi !";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Non, vous, il s'est servi de vous comme d'une arme du crime, mais moi, il m'a trompé ! Je n'aurais jamais cru qu'il aurait ce culot. Le scélérat !";
			link.l1 = "En effet, il n'y a rien de pire que la trahison.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "וcoutez, voulez-vous m'aider à me venger de Prenol ? Vous avez l'air solide, et vous semblez avoir la tête sur les épaules.";
			link.l1 = "J'accepte. Que faut-il faire ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Rien pour l'instant. Occupez-vous de vos propres affaires, mais dans deux semaines, je vous attendrai ici, dans cette taverne. J'espère que d'ici là, mes gars auront déniché quelque chose sur Prenol.";
			link.l1 = "Et si je passais chez lui, à Port-au-Prince ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Et qu'espérez-vous y trouver ? Prenol n'y sera certainement pas, je vous le dis avec une certitude absolue.";
			link.l1 = "Je vais quand même y jeter un coup d'œil, à Port-au-Prince ; j'apprendrai peut-être quelque chose.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Très bien, faites comme bon vous semble, mais dans deux semaines, soyez ici à l'heure dite, compris ?";
			link.l1 = "Compris, compris : dans deux semaines, dans cette taverne.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Et une dernière chose : comment vous appelez-vous ? J'ai complètement oublié de vous le demander.";
			link.l1 = GetFullName(PChar) + ". Capitaine " + GetFullName(PChar) + ".";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Eh bien, portez-vous bien, capitaine " + GetFullName(PChar) + ".";
			link.l1 = "א bientכt.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryShonDialogExit");
		break;

		case "18":
			dialog.text = "...(l'interrompant)... Encore un scélérat ! Je ne voulais pas vous interrompre, continuez.";
			link.l1 = "Prenol devait donner la moitié de l'argent à Tillman, quinze mille, mais il a préféré le tuer plutכt que de payer. Quand je suis passé chez Tillman, il était déjà mort. J'ai réussi à abattre les tueurs, et sur l'un d'eux, j'ai trouvé une lettre. Tenez, lisez-la.";
			link.l1.go = "19";
		break;

		case "19":
			TakeNItems(PChar, "RichardTillmanNotice", -1);
			TakeNItems(PChar, "TillmanKillersNotice", -1);
			dialog.text = "...(il lit)... « Et n'oublie pas de dire la phrase clé ».";
			link.l1 = "Il faut découvrir cette phrase. Si je trouve l'homme et que je la lui dis, je pourrai peut-être apprendre oם est Prenol.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Hum ? Vous savez, " + PChar.name + ", j'ai une idée. Prenol aimait beaucoup répéter cette phrase : « C'est très bien, c'est parfait ». Il vous l'a peut-être dite plus d'une fois, à vous aussi. Ce serait peut-être la phrase clé ?";
			link.l1 = "Oui, je me souviens qu'il m'a dit quelque chose comme ça. דa vaut la peine d'essayer.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Bonne chance, " + PChar.name + ".";
			link.l1 = "א vous aussi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryShonReadNotice");
		break;

		case "22":
			dialog.text = "Quelle malchance ! Et moi qui comptais tant sur votre aide. Maintenant, je vais devoir vendre ma collection d'armes. Ah, c'est dommage de m'en séparer, mais il faut bien vivre.";
			link.l1 = "Tout ira bien. Vous vous relèverez et vous rassemblerez une nouvelle collection.";
			link.l1.go = "23";
		break;

		// Gregg: the original had "Alex" here - the name of the Damned Destiny protagonist,
		// leaked into the line
		case "23":
			dialog.text = "Ce n'est pas mon destin, " + PChar.name + ", ce n'est pas mon destin. Je n'ai plus la même poigne, il me reste peu de relations, et personne sur qui m'appuyer. Après cette affaire, je comptais quitter le métier. Et maintenant... Je vais devoir vendre les armes. J'en tirerai une vingtaine de milliers, si je ne les brade pas, et ensuite, le repos.";
			link.l1 = "Très bien, Shon, je dois partir. Pardonnez-moi de ne pas avoir récupéré votre argent. Je n'avais aucune chance.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Je ne vous en veux pas, " + PChar.name + ". Au fond, c'est moi qui me suis fourvoyé avec Prenol, et vous n'étiez pas obligé de m'aider. Mais en tout cas, merci pour tout.";
			link.l1 = "Portez-vous bien, Shon.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryShonCancelMoney");
		break;

		case "25":
			AddMoneyToCharacter(PChar, -30000);
			dialog.text = "Merci infiniment, " + PChar.name + ", je pensais déjà à vendre ma collection d'armes.";
			link.l1 = "La prochaine fois, méfiez-vous davantage des gens comme Prenol.";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Je le ferai, n'en doutez pas. וcoutez, " + PChar.name + ", pour votre aide, je veux vous faire un cadeau. C'est l'une des plus belles pièces de ma collection. Elle est à vous, maintenant.";
			link.l1 = "Une arme digne de ce nom. Je vois qu'elle a connu plus d'un combat.";
			link.l1.go = "27";
		break;

		case "27":
			UD_GiveShonReward();
			// Gregg: the gift is picked by the player's strongest weapon skill, so it may well
			// be a firearm - the line follows the fact, not the other way round
			if (PChar.UneasyDelivery.RewardGun == true)
			{
				dialog.text = "Oui, elle a une riche histoire. C'est ce qui fait sa valeur. On dit que cette arme a tué l'un des meilleurs capitaines espagnols, le favori du gouverneur général d'Espagne : Alvarez Istilochos.";
			}
			else
			{
				dialog.text = "Oui, elle a une riche histoire. C'est ce qui fait sa valeur. On dit que cette lame a tué l'un des meilleurs capitaines espagnols, le favori du gouverneur général d'Espagne : Alvarez Istilochos.";
			}
			link.l1 = "Qui est-ce ?";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Vous ne le connaissez donc pas ? Retenez ce nom, " + PChar.name + ", vous l'entendrez encore plus d'une fois.";
			link.l1 = "Je m'en souviendrai, soit. Très bien, Shon, merci pour le cadeau.";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Merci à vous. Eh bien, adieu, " + PChar.name + ". Peut-être nous reverrons-nous un jour.";
			link.l1 = "Peut-être. Dans ce cas, à bientכt.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryShonYesMoney");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
