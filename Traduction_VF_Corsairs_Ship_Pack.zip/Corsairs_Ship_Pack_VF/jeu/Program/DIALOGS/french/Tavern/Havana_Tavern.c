// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
			{
				dialog.text = "Posez vos questions, "+ GetSexPhrase("señor", "señorita") +".";
				link.l1 = "J'ai entendu dire qu'on avait réussi récemment à capturer Rock le Brésilien, ce pirate !";
				link.l1.go = "Step_F7_1";
				break;
			}
			Link.l1.go = "exit";
            if (pchar.questTemp.Ascold == "ToHavanna") // квест Аскольда
            {
    			Link.l1 = "Dites, la ville est étrangement calme aujourd'hui. Pas d'agitation, tout est tranquille... Pourquoi donc ?";
    			Link.l1.go = "Step_A1";
            }
			if (pchar.questTemp.Slavetrader == "FindRatHavana")
            {
                link.l1 = "Dites, François Gontier est-il apparu dans votre ville ? D'ailleurs, il a une corvette, la '" + pchar.questTemp.Slavetrader.ShipName+ "'... ";
                link.l1.go = "Havana_ratT_1";
            }
		break;
//******************** Фр.линейка, квест №7. Спасение Рока Бразильца ******************
 	 	case "Step_F7_1":
			dialog.text = NPCStringReactionRepeat("Oui, c'est vrai, c'est arrivé. Une chance inouïe, je vous le dis, "+ GetSexPhrase("señor", "señorita") +".", "Vous m'avez déjà interrogé sur le Brésilien.",
				          "Encore le Brésilien ?", "Eh bien, combien de temps allons-nous parler de ces pirates ? Parlons d'autre chose...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("C'est vrai, c'est vrai... Et qu'est-ce qu'on lui a fait ? On l'a sans doute étranglé sur place.", ""+ GetSexPhrase("Je vous l'ai demandé", "Je vous l'ai demandé") +" ? Eh bien, oui, sans doute...", "Oui, exactement, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +", désolé...", "On peut parler d'autre chose...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_F7_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_F7_2":
			dialog.text = "Mais que dites-vous là, "+ GetSexPhrase("señor", "señorita") +". On l'a amené et montré à tout le monde. Puis on l'a remis aux saints pères...";
			link.l1 = "Et pourquoi les saints pères en ont-ils besoin ?";
			link.l1.go = "Step_F7_3";
        break;
 	 	case "Step_F7_3":
			dialog.text = "Hé, "+ GetSexPhrase("señor", "señorita") +", ce ne sont pas des confesseurs. Ces saints pères-là sont des moines militants ! L'Inquisition...";
			link.l1 = "Ah, l'affaire est claire. Eh bien, merci, l'ami.";
			link.l1.go = "exit";
        break;
//******************** Квест Аскольда, узнаем о мановарах с ипанским добром ******************
		case "Step_A1":
			dialog.text = "Hé, oui. Les gens sont épuisés, ils n'ont plus la force de s'agiter comme d'habitude. Et tout ça parce que ce n'est qu'avant-hier qu'on a enfin envoyé le Man...";
			Link.l1 = "Quel Man ?";
			Link.l1.go = "Step_A2";
		break;

		case "Step_A2":
			dialog.text = "Eh bien, un navire chargé de toutes sortes de bric-à-brac. Le gouverneur général Oregon y Gascón en personne a ordonné à tous les habitants de participer au chargement. Ils ont porté toutes sortes de babioles : des mosaïques, des cruches, toutes sortes de dieux indiens, pouah !";
			Link.l1 = "דa alors ! Et pourquoi donc ? Les Espagnols faisaient tout fondre en lingots, avant, et maintenant, quel caprice ?";
			Link.l1.go = "Step_A3";
		break;

		case "Step_A3":
			dialog.text = "Et alors, qu'est-ce que vous croyez, qu'elles étaient en or, ces idoles ? Tu parles, de la pierre et du bois...";
			Link.l1 = "La Marianne est devenue complètement folle. Et oם est parti ce Man ?";
			Link.l1.go = "Step_A4";
		break;

		case "Step_A4":
			dialog.text = "Parlez, mais ne parlez pas trop : la reine mère est respectée chez nous. Et qui êtes-vous ? Et pourquoi avez-vous besoin de savoir oם est parti le Man ?";
			Link.l1 = "Pour rien, je demandais... Désolé pour la grossièreté, je ne voulais offenser personne.";
			Link.l1.go = "Step_A5";
		break;

		case "Step_A5":
			dialog.text = "Très bien, si vous ne le vouliez pas. Mais attention, ne fourrez pas votre nez oם il ne faut pas : vous pourriez vous retrouver derrière les barreaux sans le vouloir.";
			Link.l1 = "D'accord... Qu'est-ce que je vous ai fait ? Je crois que je vais y aller...";
			Link.l1.go = "exit";
			pchar.questTemp.Ascold = "SeekInformatorHavanna";
			AddQuestRecord("Ascold", "6");
            ref sld = GetCharacter(NPC_GenerateCharacter("FernandoGonsales", "off_spa_1", "man", "man", 28, SPAIN, -1, true));
            FantomMakeCoolFighter(sld, 28, 90, 70, BLADE_LONG, "pistol3", 10);
            LAi_SetStayType(sld);
           	sld.name 	= "Fernando";
			sld.lastname 	= "Gonzalez";
			sld.Dialog.Filename = "Quest\AscoldNpc.c";
			ChangeCharacterAddressGroup(sld, "Santiago_houseSp2", "goto", "goto2");
            LAi_LocationFightDisable(&Locations[FindLocation("Santiago_houseSp2")], true);
		break;

		case "Havana_ratT_1":
			dialog.text = "Ah, ce type ténébreux ? Oui, il est passé chez moi. Je vais vous confier un secret : il est allé à un rendez-vous avec Oregon y Gascón en personne. Il demandait une lettre de marque. Mais quelque chose n'a pas marché, et il est reparti.";
			Link.l1 = "Et savez-vous oם il est allé ? Je le poursuis depuis Portobelo, mais je n'arrive toujours pas à le trouver.";
			Link.l1.go = "Havana_ratT_2";
		break;

		case "Havana_ratT_2":
			dialog.text = "Pourquoi avez-vous besoin de lui ? Il a peur des inconnus : il se cache toujours de tout le monde, et dès qu'il voit un inconnu armé, il porte la main à son épée. Il ne se promène qu'accompagné de quatre gardes. Ce ne serait pas de vous qu'il se méfie tant ?";
			Link.l1 = "Mon Dieu, quelle punition ! J'ai l'air d'un assassin ? C'est mon ami, je suis pressé de lui annoncer une nouvelle qui le rendra très, très heureux : il n'a plus besoin de se cacher, personne ne le cherche.";
			Link.l1.go = "Havana_ratT_3";
		break;

		case "Havana_ratT_3":
			dialog.text = "Personne ? Ha ha ha ! Oui, la veille même de son départ de La Havane, toute une bande de va-nu-pieds l'a attaqué dans la jungle... Mais lui et ses hommes les ont hachés menu en un éclair. Et vous dites...";
			Link.l1 = "Allons. Les bandits du coin ont sans doute convoité sa bourse. Vous savez combien de racaille rכde dans la jungle en ce moment. Alors, oם est-il allé ?";
			Link.l1.go = "Havana_ratT_4";
		break;

		case "Havana_ratT_4":
			dialog.text = "Eh bien, après qu'on l'a éconduit chez nous, il a marmonné qu'il irait chez les mangeurs de grenouilles, ses compatriotes. Il est parti pour Tortuga, chez d'Ogeron... Il a aussi marmonné quelque chose à propos de sa maîtresse, mais je n'ai pas bien compris.";
			Link.l1 = "א Tortuga, donc ? Parfait ! J'espère au moins l'y rattraper. Merci, " + npchar.name + ", vous m'avez beaucoup aidé. Au revoir.";
			Link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_7");
			pchar.questTemp.Slavetrader = "FindRatTortuga";
			pchar.quest.Slavetrader_findTortugaRat.win_condition.l1 = "location";
            pchar.quest.Slavetrader_findTortugaRat.win_condition.l1.location = "Tortuga_HouseHut";
            pchar.quest.Slavetrader_findTortugaRat.win_condition = "Slavetrader_findTortugaRat";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

