/// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(PChar.MysteriousIsland == "5" && NPChar.City == "SantoDomingo")
			{
				link.l1 = "Je m'intéresse au sort du marin Diego Marquez.";
				link.l1.go = "MysteriousIsland_1";
			}
			if(PChar.MysteriousIsland == "5" && NPChar.City == "SantoDomingo" && PChar.MysteriousIsland.FirstNoneMoney == true)
			{
				link.l1 = "C'est encore au sujet de Diego Marquez.";
				link.l1.go = "MysteriousIsland_6";
			}		
			if(PChar.MysteriousIsland == "9" && NPChar.City == "SantoDomingo")
			{
				Link.l1 = "Bonjour, monsieur " + NPChar.lastname + ". Je me souviens que vous avez mentionné le nom du capitaine Davy Forser lors de ma dernière visite. Avez-vous d'autres informations sur cet homme ?";
				Link.l1.go = "MysteriousIsland_7";
			}
		break;
		
		// ЗАГАДОЧНЫЙ ОСТРОВ -->
		case "MysteriousIsland_1":
			dialog.text = "דa alors ! Cet homme me devait une grosse somme : 100000 pièces. Et maintenant, il est détenu dans la prison d'ici. Il ne cessait de dire qu'il allait avoir beaucoup d'argent, et je l'ai cru ; en vain, comme il s'est avéré. Il m'a brièvement raconté ses aventures. D'ailleurs, son capitaine, Davy Forser, est passé chez moi, mais je ne les avais jamais vus auparavant.";
			if(sti(PChar.money) >= 100000)
			{
				link.l1 = "Je suis prêt à vous payer la somme indiquée. Il me faut Diego Marquez libre.";
				link.l1.go = "MysteriousIsland_2";	
			}			
			link.l2 = "C'est beaucoup d'argent ! Et comment a-t-il réussi à s'endetter à ce point ? Quoi qu'il en soit, merci pour l'information, permettez-moi de prendre congé.";
			link.l2.go = "MysteriousIsland_3";
		break;

		case "MysteriousIsland_2":
			AddMoneyToCharacter(PChar, -100000);
			PChar.MysteriousIsland.FirstNoneMoney = false;
			dialog.text = "Parfait ! Dans ce cas, je me charge moi-même de toutes les formalités. Revenez demain : Diego Marquez vous attendra ici.";
			link.l1 = "Excellent. Au revoir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandWaitDiegoMarkes");
		break;

		case "MysteriousIsland_3":
			PChar.MysteriousIsland.FirstNoneMoney = true;
			dialog.text = "Bonne journée, capitaine !";
			link.l1 = "...";
			link.l1.go = "exit";
		break;
		
		case "MysteriousIsland_4":
			dialog.text = "Voyez-vous, capitaine, le secret des dépכts est l'un des principes fondamentaux de mon travail avec les clients. Cependant, pour 2000 pièces, je suis prêt à partager mes informations avec vous.";
			if(sti(PChar.money) >= 2000)
			{
				AddMoneyToCharacter(PChar, -2000);
				link.l1 = "Prenez l'argent, señor " + NPChar.lastname + ". Alors, que savez-vous ?";
				link.l1.go = "MysteriousIsland_5";
			}
			else
			{
				link.l1 = "Quoi donc ? Il ne m'en coמterait rien de vous transpercer de mon épée. Dites-moi tout, et sans plaisanter !";
				link.l1.go = "MysteriousIsland_5";		
			}
		break;
		
		case "MysteriousIsland_5":
			dialog.text = "Bon... Le fait est que Davy Forser n'est plus mon client, sinon je ne vous parlerais tout simplement pas. Hier, il a retiré tout son argent, une très, très grosse somme.";
			link.l1 = "Hier ?! Diable, nous nous sommes manqués de peu ! Il faut se dépêcher ! Au revoir, monsieur " + NPChar.lastname + " !";
			link.l1.go = "exit";
		break;
		
		case "MysteriousIsland_6":
			dialog.text = "זtes-vous prêt à payer la dette de Diego ?";
			if(sti(PChar.money) >= 100000)
			{
				link.l1 = "Oui. Voici l'argent.";
				link.l1.go = "MysteriousIsland_2";
			}
		
			link.l2 = "Euh... Sans doute pas. Au revoir.";
			link.l2.go = "exit";
		break;
		
		case "MysteriousIsland_7":
			dialog.text = "Voyez-vous, capitaine, le secret des dépכts est l'un des principes fondamentaux de mon travail avec les clients. Cependant, pour 2000 pièces, je suis prêt à partager mes informations avec vous.";
			if(sti(PChar.money) >= 2000)
			{
				AddMoneyToCharacter(PChar, -2000);
				link.l1 = "Prenez l'argent, señor " + NPChar.lastname + ". Alors, que savez-vous ?";
				link.l1.go = "MysteriousIsland_8";
			}
			else
			{
				link.l1 = "Comment ça ? Il ne m'en coמterait rien de vous transpercer de mon épée. Dites-moi tout, et sans plaisanter !";
				link.l1.go = "MysteriousIsland_8";		
			}
		break;
		
		case "MysteriousIsland_8":
			dialog.text = "Bon... Le fait est que Davy Forser n'est plus mon client, sinon je ne vous parlerais tout simplement pas. Hier, il a retiré tout son argent, une très, très grosse somme.";
			link.l1 = "Hier ?! Diable, nous nous sommes manqués de peu ! Il faut se dépêcher ! Au revoir, monsieur " + NPChar.lastname + " !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandFindDavyForser");
		break;
		// <-- ЗАГАДОЧНЫЙ ОСТРОВ
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

