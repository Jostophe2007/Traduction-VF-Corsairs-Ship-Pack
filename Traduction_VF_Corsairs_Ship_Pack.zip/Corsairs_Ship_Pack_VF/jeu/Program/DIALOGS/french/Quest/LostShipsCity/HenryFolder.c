#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text =  TimeGreeting() + ", capitaine " + pchar.name + ". Félicitations pour votre arrivée dans la Cité ! La tempête va bientכt se calmer, et vous pourrez mieux vous habituer à tout.";
					link.l1 = "Pourquoi pensez-vous qu'elle va bientכt se calmer ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = TimeGreeting() + ", capitaine " + pchar.name + ".";
					link.l1 = "Nous nous connaissons ?";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Comment puis-je vous aider, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de venir avec moi.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "Hum, eh bien, ce n'est pas ma première tempête ici, dans la Cité. Alors je peux dire assez précisément que la tempête se calmera d'ici demain soir. " + GetFullName(npchar) + " à votre service !";
			link.l1 = "Merci. Dites-moi, mon ami, si ce n'est pas un secret, comment êtes-vous arrivé ici ?";
			link.l1.go = "FT_5";
		break;
		case "FT_1":
			dialog.text = "Non, pas du tout. C'est simplement que j'ai déjà entendu parler de vous.";
			link.l1 = "Mais moi, hélas, je n'ai jamais entendu parler de vous.";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Rien d'étonnant ! " + GetFullName(npchar) + " à votre service. Comment puis-je vous aider ?";
			link.l1 = "Oui, je fais connaissance avec les gens, je m'adapte... Je me renseigne sur la Cité.";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Sur la Cité, hum... Et comment trouvez-vous la Cité ?";
			link.l1 = "Eh bien, la Cité est assez intéressante.";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Ce n'est pas le mot, capitaine ! Cette cité est unique.";
			link.l1 = "Comment êtes-vous arrivée ici ?";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Mon histoire est sans doute la plus ennuyeuse de toutes. C'est peut-être parce que j'ai la flemme de l'enjoliver. Et puis, personne ne me croit.";
			link.l1 = "Alors, que s'est-il passé ?";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Je suis littéralement venu ici de moi-même, capitaine. C'est tout.";
			link.l1 = "De vous-même ? Vous êtes venu ici exprès ?! Alors nous sommes collègues ! Et qu'est-ce qui vous a amené ici ?";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "La rumeur a couru, capitaine. J'ai été le premier à comprendre que ce n'était pas une simple histoire d'ivrogne, et j'ai décidé de venir ici. J'ai engagé un capitaine et un équipage, j'ai rassemblé toutes les informations et je me suis procuré une carte douteuse... mais ça s'est révélé bien plus simple\n"+
				"La nuit, sans raison, sans tempête ni grain, le vent nous a poussés jusqu'à vingt nœuds, si je me souviens bien des paroles du capitaine ; moi, je ne suis pas du tout navigateur. Nous avons été contents un moment, puis nous nous sommes fracassés contre cette cité à pleine vitesse...";
			link.l1 = "Fracassés ?!";
			link.l1.go = "FT_8";
		break;
		case "FT_8":
			dialog.text = "Oui, c'est bien ça : notre navire est tout près, il est devenu une partie de cette cité. En plus, beaucoup de gens ont survécu, ce qui est très rare. Vous n'imaginez pas la tête qu'a faite Capper en nous voyant ; je le jure devant Dieu, cette secousse l'a même fait sauter du lit et enfiler ses culottes !";
			link.l1 = "Je ne dirais pas que cette histoire est ennuyeuse.";
			link.l1.go = "FT_9";
		break;
		case "FT_9":
			dialog.text = "Chacun son goמt, mais moi, j'aurais préféré une tempête plutכt qu'un naufrage aussi stupide.";
			link.l1 = "Eh bien, je suis content de vous connaître. Merci pour l'histoire.";
			link.l1.go = "FT_10";
		break;
		case "FT_10":
			dialog.text = "Il n'y a pas de quoi, capitaine. Faisons connaissance.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je préfère chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "mademoiselle") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Et quel temps fait-il ici, en général ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Pourquoi cet endroit n'intéresse-t-il pas les autorités des puissances nationales ? Appartient-il à quelqu'un ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Pouvez-vous me dire oם cacher des marchandises pour un temps ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Tout le monde connaît-il la Loi et la respecte-t-il à la lettre ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l5 = "וcoutez, depuis combien de temps êtes-vous ici ?";
				link.l5.go = "ansewer_5";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_4":
			dialog.text = "Oui, ça va. Les tempêtes sont un phénomène assez rare, il fait surtout beau et sans vent ici.";
			link.l1 = "דa fait plaisir.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_1":
			dialog.text = "C'est drכle, hein, vraiment... à personne.";
			link.l1 = "Et personne n'a essayé de s'emparer de la Cité ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Bien sמr que non. Personne n'en sait rien sur le continent. Seules des rumeurs circulent parmi les mendiants à propos de l'טle de la Justice... Mais qui prendrait ça au sérieux ?";
			link.l1 = "C'est exact.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Des coffres, "+ GetSexPhrase("l'ami", "mademoiselle") +", des coffres... Il n'en manque pas ici. Mais vous ne devriez pas toucher à ceux des autres : ouvrez seulement ceux qui sont communs, si vous le pouvez, bien sמr.";
			link.l1 = "Comment ça ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Il n'y a pas de coffres sans clé ici, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Tout ne s'ouvre qu'avec des clés. Et gardez à l'esprit qu'en plus de vous, beaucoup de gens ont ces clés. Si vous voulez cacher quelque chose en lieu sמr, il faut chercher un coffre quelque part hors de la Cité, là oם il faut aller en bateau...";
			link.l1 = "Oui, je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Ha, peu importe qu'ils la connaissent ou non !.. Les infractions sont sévèrement punies, et Capper se moque de savoir si vous avez retenu notre Loi du premier coup.";
			link.l1 = "Oui, je m'en doutais.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_5":
			dialog.text = "Déjà un bon moment, pour ainsi dire...";
			link.l1 = "Combien ?";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Environ cinq ans.";
			link.l1 = "Ha, vous êtes un ancien ! Vous êtes sans doute devenu citoyen de la Cité avant même le défunt Hill Brunner.";
			link.l1.go = "ansewer_5_2";
		break;
		case "ansewer_5_2":
			dialog.text = "Non, pas avant lui.";
			link.l1 = "Je vois... écoutez, vous connaissez d'autres anciens de la Cité ?";
			link.l1.go = "ansewer_5_3";
		break;
		case "ansewer_5_3":
			dialog.text = "Pourquoi en avez-vous besoin ?";
			link.l1 = "Oui, j'en ai besoin pour une petite affaire...";
			link.l1.go = "ansewer_5_4";
		break;
		case "ansewer_5_4":
			dialog.text = "Eh bien, si vous ne voulez pas en parler, n'en parlez pas. Et pour répondre à votre question : cherchez les anciens...";
			link.l1 = "Comment ça ?";
			link.l1.go = "ansewer_5_5";
		break;
		case "ansewer_5_5":
			dialog.text = "Comprenez-le comme vous voudrez.";
			link.l1 = "Oh... Eh bien, merci quand même.";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Pardonnez-moi, je ne comprends pas de quoi vous parlez.",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de bombes, de mitraille, de vivres, de médicaments, de poudre, d'armes...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Compris, compris...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Ah, je vois... Je ne peux vous aider en rien. Quoique...";
			link.l1 = "Quoi ?";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Les bombes et la mitraille, on peut les chercher chez les maîtresses de maison. Ce sont loin d'être les objets les plus précieux de la Cité.";
			link.l1 = "D'accord, merci.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Venir avec vous ? En voilà une proposition !",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "דa suffit, je suis fatigué...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'attends une réponse.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Je crois que je vais refuser. Je me plais ici !";
			link.l1 = "Pas encore fatigué ?";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Non, je n'en ai pas assez. Tout ce qu'il faut pour vivre est ici. Et tout s'obtient sans effort.";
			link.l1 = "La tempête qui approche vous ramènera peut-être à la raison ? Le fait est qu'elle va détruire la Cité.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Comment le savez-vous ?";
			link.l1 = "Je le sais avec certitude, croyez-moi.";
			link.l1.go = "SeekCrew_4";
		break;
		case "SeekCrew_4":
			dialog.text = "Pardonnez-moi, je ne vous crois pas...";
			link.l1 = "Eh bien, comme vous voudrez.";
			link.l1.go = "exit";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
