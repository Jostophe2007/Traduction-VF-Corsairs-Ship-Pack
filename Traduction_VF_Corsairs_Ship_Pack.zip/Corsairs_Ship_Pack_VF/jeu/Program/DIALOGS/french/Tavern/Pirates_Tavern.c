// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 7 - why the residence is shut
			if (CheckAttribute(PChar, "SmallMongrel"))
			{
				if (PChar.SmallMongrel == "2")
				{
					link.l30 = "Dites-moi, pourquoi plus personne ne peut-il approcher Jackman ?";
					link.l30.go = "BO_SM_Pir_1";
				}
			}
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
            if (pchar.questTemp.State == "SeekBible_toBermudes")
			{
                link.l1 = HeroStringReactionRepeat("Dites, je cherche un pirate qui a vendu ici une sorte de Bible étrange. Vous n'avez pas entendu parler de cette affaire ?",
                "Je parle de la Bible... nous en avons déjà parlé, désolé.", "Oui, c'est vrai...", "Ah, nous avons déjà réglé ça, désolé...", npchar, Dialog.CurrentNode);
                link.l1.go = DialogGoNodeRepeat("Step_H8_1", "", "", "", npchar, Dialog.CurrentNode);
            }
            if (pchar.RomanticQuest == "BrotherIsDead")
			{
                link.l1 = HeroStringReactionRepeat("Dites, savez-vous oם est Atilla en ce moment ?",
                "Oh, oui, nous avons déjà parlé d'Atilla...", "Oui, c'est vrai...", "Désolé, j'avais oublié...", npchar, Dialog.CurrentNode);
                link.l1.go = DialogGoNodeRepeat("Step_Romantic_1", "", "", "", npchar, Dialog.CurrentNode);
            }
			if (pchar.questTemp.BlueBird == "toBermudes")
			{
				link.l1 = "Dis-moi, l'ami, as-tu entendu quelque chose d'intéressant à la taverne sur le chébec Oiseau bleu ?";
				link.l1.go = "BlueBird_1";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_toBermudes")
			{
				link.l1 = "Edward Law serait-il passé par ici ?";
				link.l1.go = "PL_Q3_1";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_toTavernAgain" || pchar.questTemp.piratesLine == "KillLoy_2toTavernAgain")
			{
				link.l1 = "Je cherche Edward Law.";
				link.l1.go = "PL_Q3_2";
			}
			if (pchar.questTemp.piratesLine == "PL5Hunter_toBermudes")
			{
				link.l1 = "John Avory est-il passé dans votre taverne ?";
				link.l1.go = "StepPL5Berm_1";
			}
			if (CheckAttribute(PChar, "questTemp.BSPrologue.WaitingForNassauSiege") && Colonies[FindColony("Nassau")].nation == ENGLAND)
			{
				link.l1 = "Mme Guthrie est-elle ici ?";
				link.l1.go = "GatrisBarman";
			}
            // <== Проверяем поле состояния квестов.
			// Gregg: "Goods for Richard Tillman" - asking about Prenol on Bermuda
			// Gregg: the attribute is checked in a separate if - a hero who never took the
			// quest has none, and a bare comparison raises a RUNTIME ERROR. It cannot be
			// folded into one condition with && : there is no short-circuit evaluation.
			if (CheckAttribute(PChar, "UneasyDelivery"))
			{
				if (PChar.UneasyDelivery == "12")
				{
					link.l8 = "וcoutez, " + NPChar.name + ", je cherche un homme, il s'appelle Jacque Prenol. Est-il passé par ici ?";
					link.l8.go = "UneasyDelivery_1";
				}
			}

			// Gregg: "The Treachery of Grifo Sajfus" (ported from Damned Destiny) -->
			// The quest attribute is checked for existence BEFORE any comparison: a hero
			// who took neither the alternative prologue nor the innkeeper branch has none.
			int iSajfusRankReq = 1;
			if (!bQuestsRank) iSajfusRankReq = 5;
			if (!CheckAttribute(PChar, "TreacheryOfGrifoSajfus"))
			{
				// Entry for those who did not take the alternative prologue, where the quest
				// is granted by the prologue itself. Here the innkeeper tells the tale of
				// Sajfus's execution and the player hunts the missing xebec as a legend.
				if (sti(pchar.rank) >= iSajfusRankReq)
				{
					link.l11 = "Quelles nouvelles dans nos eaux, " + NPChar.name + " ?";
					link.l11.go = "TreacheryOfGrifoSajfus_0";
				}
			}
			else
			{
				if (PChar.TreacheryOfGrifoSajfus == "1")
				{
					link.l11 = "Content de te voir, " + NPChar.name + " !";
					link.l11.go = "TreacheryOfGrifoSajfus_1";
					// Gregg: if the talk was broken off midway, send the player back to their
					// OWN branch - node 1 speaks for the alternative prologue hero
					if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha")) link.l11.go = "TreacheryOfGrifoSajfus_2";
				}
				if (PChar.TreacheryOfGrifoSajfus == "2")
				{
					link.l12 = "Des nouvelles du chébec ?";
					link.l12.go = "TreacheryOfGrifoSajfus_9";
				}
				if (PChar.TreacheryOfGrifoSajfus == "3")
				{
					link.l13 = "Des nouvelles du chébec ?";
					link.l13.go = "TreacheryOfGrifoSajfus_10";
				}
				if (PChar.TreacheryOfGrifoSajfus == "6")
				{
					link.l14 = "J'ai trouvé ce chébec. Et ce n'est pas le ''Piranha''.";
					link.l14.go = "TreacheryOfGrifoSajfus_17";
				}
				if (PChar.TreacheryOfGrifoSajfus == "7")
				{
					link.l15 = "Des nouvelles du ''Piranha'' ?";
					link.l15.go = "TreacheryOfGrifoSajfus_9";
				}
				if (PChar.TreacheryOfGrifoSajfus == "8")
				{
					link.l16 = "Des nouvelles du ''Piranha'' ?";
					link.l16.go = "TreacheryOfGrifoSajfus_20";
				}
				if (PChar.TreacheryOfGrifoSajfus == "14")
				{
					link.l17 = "J'ai appris ce qu'il est advenu du ''Piranha''.";
					link.l17.go = "TreacheryOfGrifoSajfus_28";
				}
			}
			// Gregg: "The Treachery of Grifo Sajfus" <--
			// Gregg: the "Black Orchid" (ported from Damned Destiny) - the tavernkeeper
			// holds word from Frederik Levinson. The branch is opened by the messenger in
			// port, whose node 2 sets MysteriousArtefact to "CanTake" and later to "1".
			if (CheckAttribute(PChar, "MysteriousArtefact"))
			{
				if (PChar.MysteriousArtefact == "CanTake")
				{
					link.l20 = "J'ai entendu dire que tu me cherchais.";
					link.l20.go = "MysteriousArtefact_1";
				}
			}
			// Gregg: the "Black Orchid", chapter 5 - the fourth piece of the Meritor is with
			// Levinson. A hero who never reached chapter five simply has no DestinyGift
			// attribute, so its existence is checked in a separate nested if: Storm has no
			// short-circuit evaluation and this cannot be folded into one && condition.
			if (CheckAttribute(PChar, "DestinyGift"))
			{
				if (PChar.DestinyGift == "20")
				{
					link.l21 = "וcoutez, " + NPChar.name + ", j'ai besoin de Frederik Levinson. S'est-il montré par ici ?";
					link.l21.go = "BO_Levinson_1";
				}
			}

		break;

		case "UneasyDelivery_1":
			dialog.text = "Hum. Laissez-moi réfléchir. Non, je ne m'en souviens pas. Il est peut-être passé, mais comment voulez-vous que je connaisse chaque client de ma taverne ? Ils ne se présentent pas quand ils demandent du rhum.";
			link.l1 = "C'est vrai. Très bien, " + NPChar.name + ", je vais chercher.";
			link.l1.go = "UneasyDelivery_2";
		break;

		case "UneasyDelivery_2":
			dialog.text = "Et pourquoi lui voulez-vous ?";
			link.l1 = "Nous avons de vieux comptes à régler, lui et moi.";
			link.l1.go = "UneasyDelivery_3";
		break;

		case "UneasyDelivery_3":
			dialog.text = "De vieux comptes, dites-vous ? Eh bien, si vous le trouvez, réglez-les comme il faut.";
			link.l1 = "דa, je sais faire. Très bien, à la prochaine.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryDialogWithBermudesBarmen");
		break;

		// Gregg: THE TREACHERY OF GRIFO SAJFUS (ported from Damned Destiny) -->
		// Node 0 - entry via the tavern, node 1 - entry from the alternative prologue.
		case "TreacheryOfGrifoSajfus_0":
			TreacheryOfGrifoSajfusStartFromTavern();
			dialog.text = "Il y a une histoire toute fraîche, juste ce qu'il te faut. Il y a cinq jours environ, Grifo Sajfus a fait escale dans notre port. Un invité rare dans ces eaux, comme tu sais. Bref, l'un de ses marins s'est soמlé et a laissé échapper ce que Sajfus avait fait au large de la Dominique.";
			link.l1 = "Et qu'a-t-il fait ?";
			link.l1.go = "TreacheryOfGrifoSajfus_2";
		break;

		case "TreacheryOfGrifoSajfus_1":
			dialog.text = PChar.name + " ! Tu es vivant, que le diable t'emporte, vivant ! Et nous qui t'avions déjà enterré ici, toute la colonie : nous pensions que c'en était fini de toi, resté dans cet enfer au large de la Dominique.";
			link.l1 = "Vivant, comme tu vois ! Et comment as-tu appris ce qui s'est passé au large de la Dominique ?";
			link.l1.go = "TreacheryOfGrifoSajfus_2";
		break;

		case "TreacheryOfGrifoSajfus_2":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Il a attiré à la Dominique un de ses camarades, un capitaine avec qui il naviguait depuis des années, et il l'a abattu là-bas avec tout son équipage. Et il a pris le navire pour lui.";
				link.l1 = "Pour un navire ? Un bel ami.";
			}
			else
			{
				dialog.text = "Il y a cinq jours environ, Grifo Sajfus a fait escale dans notre port. C'est un invité rare dans ces eaux, comme tu sais. Bref, l'un de ses marins s'est soמlé et a laissé échapper ce que Sajfus avait fait au large de la Dominique.";
				link.l1 = "Et que s'est-il passé ensuite ?";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_3";
		break;

		case "TreacheryOfGrifoSajfus_3":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Nous avons collé Grifo au mur et nous l'avons interrogé. D'abord, il a nié, mais au bout de deux heures, il a avoué. Nous l'avons fusillé sur place pour trahison.";
				link.l1 = "Il ne l'a pas volé. Et quel navire était-ce ?";
			}
			else
			{
				dialog.text = "Nous avons collé Grifo au mur et nous l'avons interrogé. D'abord, il a nié, il disait que ce n'était pas vrai, comment aurait-il pu te tuer, toi, son vieil ami. Mais au bout de deux heures, il a avoué, et nous l'avons fusillé sur place pour trahison. Nous avons vengé ta mort. Nous pensions alors que tu n'étais plus.";
				link.l1 = "Bon sang, et moi qui voulais l'égorger de mes propres mains.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_4";
		break;

		case "TreacheryOfGrifoSajfus_4":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Le chébec ''Piranha''. Un navire célèbre, il n'y en avait pas d'autre comme lui aux Caraïbes. Il en avait toujours rêvé, c'est pour ça qu'il est devenu un traître.";
				link.l1 = "Et oם est-il maintenant ?";
			}
			else
			{
				dialog.text = "Si nous avions su que tu étais vivant, nous te l'aurions laissé. Mais comme ça...";
				link.l1 = "Je comprends. Il n'y a qu'une chose que je ne saisis pas : pourquoi m'a-t-il trahi ? Pour quoi faire ? Tant d'années d'amitié, et puis ça...";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_5";
		break;

		case "TreacheryOfGrifoSajfus_5":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "C'est bien là le mystère. Grifo est arrivé aux Bermudes sur un vieux sloop pourri, pas sur lui. Et oם il l'a mis, il ne l'a jamais avoué, malgré tous nos efforts.";
				link.l1 = "Un navire comme celui-là, ce n'est pas une aiguille. Tכt ou tard, il refera surface.";
			}
			else
			{
				dialog.text = "דa, c'est assez clair. C'était ton chébec. Il voulait ton ''Piranha'', il en avait toujours rêvé, c'est pour ça qu'il est devenu un traître. Il l'a avoué lui-même pendant l'interrogatoire.";
				link.l1 = "La vermine ! Me trahir pour un navire !";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_6";
		break;

		case "TreacheryOfGrifoSajfus_6":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "C'est bien ce que je pense. Un chébec célèbre, il n'y en avait pas d'autre comme lui aux Caraïbes. Si quelqu'un l'a pris, nous l'apprendrons aussitכt.";
				link.l1 = "Et si on l'avait envoyé par le fond ? Grifo savait à peine manœuvrer un navire, et une beauté pareille l'aurait complètement dépassé.";
			}
			else
			{
				dialog.text = "Seulement, il y a quelque chose qui ne colle pas. Il est arrivé aux Bermudes sur un vieux sloop pourri, pas sur ta beauté. Et oם il l'a mise, il ne l'a jamais avoué, malgré tous nos efforts. Mais nous le saurons bientכt. Ton chébec était célèbre, il n'y en avait pas d'autre comme lui aux Caraïbes. Si quelqu'un l'a pris, nous l'apprendrons aussitכt.";
				link.l1 = "א moins qu'on ne l'ait envoyé par le fond. Grifo savait à peine manœuvrer un navire, et le ''Piranha'' l'aurait complètement dépassé. On a donc très bien pu le couler.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_7";
		break;

		case "TreacheryOfGrifoSajfus_7":
			dialog.text = "Personne de sensé ne coulerait un navire pareil. On le prendrait, c'est tout. Réfléchis : tu vois en mer une beauté, une coque unique par ses qualités, qu'est-ce que tu en fais ? Tu essaies de la prendre, bien sמr.";
			link.l1 = "C'est vrai. Mais si Sajfus a été attaqué de nuit, on a pu ne pas voir quel navire on avait devant soi et l'envoyer par le fond. C'est possible aussi.";
			link.l1.go = "TreacheryOfGrifoSajfus_8";
		break;

		case "TreacheryOfGrifoSajfus_8":
			dialog.text = "Mais à quoi bon faire des suppositions ? L'avenir le dira. Passe me voir de temps en temps, et s'il y a des rumeurs sur lui, je ne manquerai pas de te les transmettre.";
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				link.l1 = "D'accord. Un navire comme celui-là vaut la peine qu'on le poursuive.";
			}
			else
			{
				link.l1 = "D'accord, je passerai de temps en temps.";
			}
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusPiratesBarmenDialogEnd");
		break;

		case "TreacheryOfGrifoSajfus_9":
			dialog.text = "Rien à signaler pour l'instant.";
			link.l1 = "Dommage.";
			link.l1.go = "exit";
		break;

		// Gregg: the convoy moved from Cuba to Puerto Rico - see the head of grifosajfus.c
		case "TreacheryOfGrifoSajfus_10":
			dialog.text = "Oui, il y a du nouveau. Hier, un capitaine a débarqué dans ma taverne ; je ne connais pas son nom, mais il avait l'air nouveau dans le coin. Il s'est mis à raconter qu'au large de Porto Rico, il avait croisé un convoi marchand espagnol de quatre galions et un chébec. Il a décidé de ne pas s'y frotter, étant lui-même sur un sloop léger, et il a donc viré de bord. Les galions ont gardé leur cap, mais le chébec l'a pris en chasse. Et d'après lui, il a rattrapé son sloop en quelques minutes, alors que la distance entre eux était considérable.";
			link.l1 = "Et ensuite ? Un abordage ?";
			link.l1.go = "TreacheryOfGrifoSajfus_11";
		break;

		case "TreacheryOfGrifoSajfus_11":
			dialog.text = "Ensuite, un miracle. Ses canonniers ont réussi à abattre deux mâts d'une seule bordée de boulets ramés ! Ils en ont été eux-mêmes stupéfaits en voyant ce que cette bordée avait fait. Bref, le chébec a aussitכt perdu son erre, et ils ont filé en vitesse.";
			link.l1 = "Tu penses que c'est le ''Piranha'' ?";
			link.l1.go = "TreacheryOfGrifoSajfus_12";
		break;

		case "TreacheryOfGrifoSajfus_12":
			dialog.text = "דa y ressemble beaucoup. Ce capitaine disait que c'était le navire le plus rapide qu'il ait jamais rencontré.";
			link.l1 = "Hum. Ses réparations vont traîner longtemps, j'en suis sמr. Ce chébec est donc à San Juan en ce moment. Ce capitaine a-t-il dit vers quel port se dirigeait le convoi ?";
			link.l1.go = "TreacheryOfGrifoSajfus_13";
		break;

		case "TreacheryOfGrifoSajfus_13":
			dialog.text = "San Juan, je crois. Mais je ne peux pas l'affirmer. Que comptes-tu faire ?";
			link.l1 = "Je vais faire voile vers Porto Rico et examiner ce navire. Si ce chébec est vraiment le ''Piranha'', je l'aborderai.";
			link.l1.go = "TreacheryOfGrifoSajfus_14";
		break;

		case "TreacheryOfGrifoSajfus_14":
			dialog.text = "Et si ses mâts ne sont pas encore remontés ?";
			link.l1 = "On verra. D'abord, je dois m'assurer que c'est bien lui.";
			link.l1.go = "TreacheryOfGrifoSajfus_15";
		break;

		case "TreacheryOfGrifoSajfus_15":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Eh bien, bon vent, " + PChar.name + ", et fais attention à toi. Ce qu'on raconte sur ce chébec dépasse ce que bien des capitaines peuvent avaler.";
				link.l1 = "On raconte toutes sortes de choses. Nous verrons bien ce qu'il vaut le moment venu.";
			}
			else
			{
				dialog.text = "Eh bien, bon vent, " + PChar.name + ", et fais attention à toi si tu dois affronter le ''Piranha''. Tu sais de quoi il est capable...";
				link.l1 = "...entre les mains d'un capitaine habile. Rares sont ceux qui peuvent le maîtriser, à part moi.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_16";
		break;

		case "TreacheryOfGrifoSajfus_16":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Attention qu'on ne te tanne pas le cuir, là-bas, mon héros.";
				link.l1 = "Eh... On s'en passera.";
			}
			else
			{
				dialog.text = "Attention qu'on ne te tanne pas le cuir une deuxième fois, mon héros.";
				link.l1 = "Eh... Il n'y aura pas de deuxième fois.";
			}
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusXebecNewsInCuba");
		break;

		case "TreacheryOfGrifoSajfus_17":
			dialog.text = "Et ? Alors ?";
			if (PChar.TreacheryOfGrifoSajfus.ChameleonSink == false)
			{
				// Gregg: without the prologue the player never laid eyes on the Piranha -
				// they judge by hearsay, not by familiar cabin fittings
				if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
				{
					link.l1 = "Mais dès que je l'ai pris, c'était évident. On disait que ce chébec pouvait distancer n'importe quel navire, et celui-ci se traîne à peine. C'est simplement un navire qui lui ressemble beaucoup.";
				}
				else
				{
					link.l1 = "Mais dès que je l'ai pris, j'ai compris que ce n'était pas lui. Les aménagements ne sont pas les mêmes, ni les canons, ni les qualités. C'est simplement un navire qui lui ressemble beaucoup.";
				}
			}
			else
			{
				link.l1 = "Mais dès que je l'ai engagé, j'ai compris que ce n'était pas lui. Il se comportait de façon bien trop étrange, même pour un capitaine inexpérimenté. C'est simplement un navire qui lui ressemble beaucoup.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_18";
		break;

		case "TreacheryOfGrifoSajfus_18":
			dialog.text = "Tu en es sמr ?";
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				link.l1 = "Tout à fait. Contre le vent, il file deux fois moins vite qu'on ne le dit du ''Piranha'', il manœuvre très mal, il n'a aucune vitesse. Ce n'est pas lui.";
			}
			else
			{
				link.l1 = "Tout à fait. Contre le vent, il file deux fois moins vite que le ''Piranha'', il manœuvre très mal, il n'a aucune vitesse. Ce n'est pas le ''Piranha''.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_19";
		break;

		case "TreacheryOfGrifoSajfus_19":
			dialog.text = "Alors nous continuerons à chercher. Passe de temps en temps, j'apprendrai peut-être quelque chose.";
			link.l1 = "Très bien, " + NPChar.name + ".";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusItIsNotShip");
		break;

		case "TreacheryOfGrifoSajfus_20":
			dialog.text = "Aucune rumeur. Rien de nouveau ne s'est passé aux Caraïbes ces derniers temps. Mais écoute ce que je vais te raconter. Hier, j'ai acheté pour pas cher deux diamants à un colporteur de passage, un cadeau pour ma femme. Que le diable m'emporte, si tu avais vu ces diamants ! Un éclat, une qualité de premier ordre ! Le colporteur dit qu'il les a rapportés d'Afrique.";
			link.l1 = "D'Afrique ? Tu as dit d'Afrique ?";
			link.l1.go = "TreacheryOfGrifoSajfus_21";
		break;

		case "TreacheryOfGrifoSajfus_21":
			dialog.text = "Oui. Et alors ? Tu n'en as jamais entendu parler ?";
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				link.l1 = "Tu as dit toi-même que Sajfus se rendait à la Dominique à la poursuite d'un navire chargé de diamants africains. C'est là qu'il a abattu son camarade, et là qu'il a pris le navire.";
			}
			else
			{
				link.l1 = "Sajfus m'avait proposé d'attaquer un navire qui transportait, disait-on, des diamants africains. Nous avions convenu de nous retrouver à la Dominique, et c'est là qu'il m'a pris mon navire.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_22";
		break;

		case "TreacheryOfGrifoSajfus_22":
			dialog.text = "Et alors ? Je ne vois pas oם tu veux en venir.";
			link.l1 = "Ce colporteur qui t'a vendu les diamants a dit qu'ils venaient d'Afrique, c'est ça ?";
			link.l1.go = "TreacheryOfGrifoSajfus_23";
		break;

		case "TreacheryOfGrifoSajfus_23":
			dialog.text = "Oui, c'est ça.";
			link.l1 = "Je parierais que ces diamants viennent du navire que Sajfus voulait attaquer.";
			link.l1.go = "TreacheryOfGrifoSajfus_24";
		break;

		case "TreacheryOfGrifoSajfus_24":
			dialog.text = "Et ?";
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				link.l1 = "א bord du ''Piranha'', Grifo a très bien pu aborder ce navire chargé de diamants. Ce qui s'est passé ensuite, personne ne le sait. Et voilà qu'un marchand se présente avec des diamants africains. Tu comprends ? Il est mêlé à cette histoire d'une façon ou d'une autre, et si j'apprends oם il s'est procuré ces pierres, j'apprendrai peut-être aussi ce qu'il est advenu du chébec.";
			}
			else
			{
				link.l1 = "א bord de mon ''Piranha'', Grifo a très bien pu aborder ce navire chargé de diamants. Ce qui s'est passé ensuite, personne ne le sait. Et voilà qu'un marchand se présente avec des diamants africains. Tu comprends ? Ce colporteur est mêlé à cette histoire d'une façon ou d'une autre, et peut-être au ''Piranha'' aussi ; et si j'apprends oם il s'est procuré ces diamants, j'apprendrai peut-être ce qu'il est advenu de mon chébec.";
			}
			link.l1.go = "TreacheryOfGrifoSajfus_25";
		break;

		case "TreacheryOfGrifoSajfus_25":
			dialog.text = "C'est absurde. Comment vas-tu l'apprendre ?";
			link.l1 = "Je ne vois pas encore comment moi-même, mais je suis sמr qu'il y a un lien. Tu ne saurais pas par hasard oם est allé ce marchand ?";
			link.l1.go = "TreacheryOfGrifoSajfus_26";
		break;

		case "TreacheryOfGrifoSajfus_26":
			dialog.text = "Il traîne sans doute encore aux Bermudes, à essayer de vendre le reste de ses diamants. Cherche-le, tu le trouveras peut-être quelque part.";
			link.l1 = "Compris.";
			link.l1.go = "TreacheryOfGrifoSajfus_27";
		break;

		case "TreacheryOfGrifoSajfus_27":
			dialog.text = "Hé, " + PChar.name + ", quand tu sauras ce qu'il est advenu du ''Piranha'', passe me voir. Je suis moi-même curieux de savoir oם il est passé.";
			link.l1 = "D'accord, " + NPChar.name + ", je te le dirai quand je saurai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusNeedTrader");
		break;

		case "TreacheryOfGrifoSajfus_28":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Ne me fais pas attendre. Oם est-il ?";
			}
			else
			{
				dialog.text = "Que le diable l'emporte ! Je suis désolé pour ta beauté, " + PChar.name + ", vraiment désolé. Et que s'est-il passé, qui l'a envoyé par le fond ?";
			}

			if (PChar.TreacheryOfGrifoSajfus.MarlinSink == false)
			{
				link.l1 = "Au fond de la mer, au large des îles Turques. Mais il y a aussi une excellente nouvelle : j'ai pris un autre navire, bien meilleur que le ''Piranha'' !";
				link.l1.go = "TreacheryOfGrifoSajfus_29";
			}
			else
			{
				link.l1 = "Au fond de la mer, au large des îles Turques. Qui l'a envoyé là-bas, je n'ai pas pu le découvrir.";
				link.l1.go = "TreacheryOfGrifoSajfus_31";
			}
		break;

		case "TreacheryOfGrifoSajfus_29":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Meilleur que le ''Piranha'' ? J'aimerais bien voir ça.";
			}
			else
			{
				dialog.text = "Hum, c'est vraiment toi, " + PChar.name + " ? Je n'arrive pas à croire que tu prétendes qu'un navire puisse être meilleur que ton ''Piranha''.";
			}
			link.l1 = "Ce n'est pas un navire, c'est une œuvre d'art. Une manœuvrabilité splendide, une vitesse magnifique, des canons exactement comme il faut.";
			link.l1.go = "TreacheryOfGrifoSajfus_30";
		break;

		case "TreacheryOfGrifoSajfus_30":
			dialog.text = "דa s'arrose.";
			link.l1 = "Sers donc !..";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusEnd");
		break;

		case "TreacheryOfGrifoSajfus_31":
			dialog.text = "Bah. C'était un bon navire.";
			link.l1 = "Un navire superbe.";
			link.l1.go = "TreacheryOfGrifoSajfus_32";
		break;

		case "TreacheryOfGrifoSajfus_32":
			dialog.text = "Quoi, " + PChar.name + ", tu ne m'as pas entendu ?";
			link.l1 = "Ce n'était pas un bon navire, c'était un navire superbe.";
			link.l1.go = "TreacheryOfGrifoSajfus_33";
		break;

		case "TreacheryOfGrifoSajfus_33":
			dialog.text = "C'est vrai. Mais assez de chagrin. Finis ton rhum, oublie le ''Piranha'' et occupe-toi d'une autre affaire.";
			link.l1 = "Je ne suis là pour personne aujourd'hui. Ressers-moi un peu de rhum...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusEnd");
		break;
		// Gregg: THE TREACHERY OF GRIFO SAJFUS <--

		//шебека Синяя Птица
		case "BlueBird_1":
			dialog.text = NPCStringReactionRepeat("J'en entends beaucoup. On dit surtout que ce navire est très rapide. On a essayé de l'attraper, mais en vain.",
				"Nous en avons déjà parlé.",
				"Encore ? Nous avons déjà tout éclairci.",
                "Désolé, si vous n'avez besoin de rien d'autre, je vais m'occuper des autres clients.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Qui a essayé de l'attraper ?",
				"Oui, c'est vrai...",
                "Hum, c'est vrai.",
				"D'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("BlueBird_2", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
		break;

		case "BlueBird_2":
			dialog.text = "Beaucoup ont essayé, mais ils se sont cassé les dents, ha ha !!";
			link.l1 = "Vous savez quelque chose d'utile ? Oם on le voit souvent, par exemple.";
			link.l1.go = "BlueBird_3";
		break;
		case "BlueBird_3":
			dialog.text = "On le voit par ici, près des Bermudes. L'Oiseau bleu n'a pas son pareil pour naviguer entre nos récifs ; des galions et des frégates se sont lancés plus d'une fois à sa poursuite, et droit par le fond !";
			link.l1 = "Voilà donc... Bon, cherchons-le. Dis-moi, quel genre d'homme est le marchand d'ici ?";
			link.l1.go = "BlueBird_4";
		break;
		case "BlueBird_4":
			dialog.text = "Très honorable, respecté parmi les marchands.";
			link.l1 = "Compris... Y a-t-il quelqu'un qui ne soit pas en très bons termes avec lui ?";
			link.l1.go = "BlueBird_5";
		break;
		case "BlueBird_5":
			dialog.text = "Il n'a pas d'ennemis déclarés. Mais l'ancien propriétaire du magasin, je crois, lui garde rancune, hé hé...";
			link.l1 = "Aurais-tu l'amabilité de me dire son nom, mon cher ?";
			link.l1.go = "BlueBird_6";
		break;
		case "BlueBird_6":
			dialog.text = "Il s'appelle John Norton. Vous ne le trouverez plus aux Bermudes. J'ai entendu dire qu'il s'était installé à Puerto Príncipe, qu'il y commerce en sous-main et qu'il ne se fait remarquer nulle part.";
			link.l1 = "Merci beaucoup, l'ami. Tu es un bon aubergiste.";
			link.l1.go = "BlueBird_7";
		break;
		case "BlueBird_7":
			dialog.text = "Merci, " + GetAddress_Form(NPChar) + ". Bonne chance !";
			link.l1 = "Bonne journée à toi aussi, l'ami.";
			link.l1.go = "exit";
			AddQuestRecord("Xebeca_BlueBird", "3");
			pchar.questTemp.BlueBird = "toPuertoPrincipe";
		break;

		//голл. линейка, квест №8
 		case "Step_H8_1":
    		dialog.text = "Non, je n'en ai pas entendu parler.";
    		link.l1 = "דa a pourtant l'air d'être une histoire connue, on me l'a racontée à Curaçao.";
    		link.l1.go = "Step_H8_2";
 		break;
 		case "Step_H8_2":
    		dialog.text = "Je n'en sais rien, ça ne s'est pas passé dans ma taverne.";
    		link.l1 = "Merci de votre aide.";
    		link.l1.go = "exit";
 		break;
		//Изабелла, ищем Атиллу
 		case "Step_Romantic_1":
    		dialog.text = "Je sais, il s'est acheté une maison ici, en ville. C'est donc là qu'il doit être.";
    		link.l1 = "Merci, l'ami...";
    		link.l1.go = "exit";
 		break;
		//Пиратка, квест №3, поиски Лоу
		case "PL_Q3_1":
			dialog.text = "Il s'est montré. Il n'arrêtait pas de rכder, de fouiner. Il s'accrochait à l'un, puis à l'autre... Il semblait s'intéresser à notre chantier naval.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "9");
			pchar.questTemp.piratesLine = "KillLoy_toAlexus";
		break;

		case "PL_Q3_2":
			dialog.text = "Vous m'avez déjà interrogé à son sujet.";
			link.l1 = "Vous vous êtes peut-être souvenu de quelque chose ?";
			link.l1.go = "PL_Q3_3";
		break;
		case "PL_Q3_3":
			dialog.text = "Oui, qu'y a-t-il à se rappeler ? Il posait des questions sur le chantier naval, il s'asseyait avec différentes personnes. D'ailleurs, le capitaine Goodley est assis là-bas : il a parlé avec Law.";
			link.l1 = "Le capitaine Goodley ?! Merci, c'est déjà quelque chose.";
			link.l1.go = "exit";
			pchar.questTemp.piratesLine = "KillLoy_toGoogly";
		break;
		//Пиратка, квест №5, ОЗГ
		case "StepPL5Berm_1":
			dialog.text = "Oui, il vient juste de passer. Il a demandé oם habitait Orrie Bruce et il est reparti.";
			link.l1 = "Et oם habite cet Orry Bruce ?";
			link.l1.go = "StepPL5Berm_2";
		break;
		case "StepPL5Berm_2":
			dialog.text = "Eh bien, il habite une maison en pierre à deux étages. Dès que vous sortez de la taverne, c'est la première maison à gauche. C'est là qu'il habite...";
			link.l1 = "Merci, vous m'avez beaucoup aidé !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "10");
			pchar.questTemp.piratesLine = "PL5Hunter_toOrryHouse";
		break;

		case "GatrisBarman":
			dialog.text = "Oui, elle est dans sa chambre. Vous voulez être reçu ?";
			link.l1 = "Oui.";
			link.l1.go = "GatrisBarmanIndoor";
			link.l2 = "Une autre fois.";
			link.l2.go = "exit";
		break;
		
		case "GatrisBarmanIndoor":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
            DoReloadCharacterToLocation("Pirates_tavern_upstairs","goto", "goto1");
		break;	

		// Gregg: THE BLACK ORCHID (ported from Damned Destiny) -->
		case "MysteriousArtefact_1":
			dialog.text = "Oui, capitaine, oui. Une vieille connaissance à vous s'est présentée ici, aux Bermudes : Frederik Levinson. Vous vous souvenez de lui ?";
			link.l1 = "Levinson ? Bien sמr que je m'en souviens. Il est parti pour l'Europe en jurant qu'il ne reviendrait jamais.";
			link.l1.go = "MysteriousArtefact_2";
		break;

		case "MysteriousArtefact_2":
			dialog.text = "Il est revenu, comme vous voyez. Il a demandé de vos nouvelles, puis il est parti en courant quelque part dans la jungle, et on ne l'a plus revu depuis. דa ne me plaît pas, capitaine. Vous feriez mieux de partir à sa recherche.";
			link.l1 = "J'y vais. Merci, mon vieil ami.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactStart");
		break;

		// Gregg: chapter 5 - the tavernkeeper points the way to Levinson. He is paid for
		// his silence and never asked the lodger's name, so he cannot connect the man to
		// Jackman's bounty until the player names him.
		case "BO_Levinson_1":
			dialog.text = "Levinson ? Votre ami, celui qui s'asseyait justement à cette table ? Il n'est plus là, capitaine. Dès que vous avez pris la mer, on ne l'a plus revu. Mais j'ai un locataire à l'étage : un homme tranquille, qui paie d'avance et qui ne quitte presque jamais sa chambre. דa fait des mois qu'il est là. Je ne lui ai jamais demandé son nom : c'est justement pour ça qu'il me paie un supplément.";
			link.l1 = "Des mois sans quitter sa chambre ? Vous avez un drכle de locataire.";
			link.l1.go = "BO_Levinson_2";
		break;

		case "BO_Levinson_2":
			dialog.text = "La moitié de cette ville se cache de quelqu'un, c'est l'usage. Jackman lui-même en cherche un : dix mille sur sa tête. On dit qu'il y a trois ans, cet homme a vendu ses propres corsaires aux Espagnols. Pas un navire, pas une part de butin : les hommes avec qui il naviguait. Ici, on ne pardonne pas ça.";
			link.l1 = "J'ai entendu cette histoire. Et je la connais de plus près que je ne le voudrais : l'un de ces corsaires était un ami à moi.";
			link.l1.go = "BO_Levinson_3";
		break;

		case "BO_Levinson_3":
			dialog.text = "...(après un silence)... Alors vous comprenez pourquoi on a mis une telle somme sur sa tête. Seulement, il n'y a personne pour la toucher : on a ratissé la jungle, fouillé les grottes, retourné la colonie de fond en comble, et rien. On a décidé qu'il avait quitté les Bermudes... ...(il s'interrompt)... Capitaine. Capitaine, oם voulez-vous en venir ?";
			link.l1 = "Au fait qu'on fouillait les buissons pendant que lui restait assis à l'étage de votre propre taverne. Taisez-vous, mon vieil ami, je ne dirai rien à Jackman : j'ai mes propres comptes à régler avec votre locataire.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFindLevinson");
		break;
		// Gregg: THE BLACK ORCHID <--

		// Gregg: The Black Orchid, chapter 7 -->
		case "BO_SM_Pir_1":
			dialog.text = "Vous n'êtes pas au courant ? Eh bien, en voilà une.";
			link.l1 = "Non. Racontez-moi.";
			link.l1.go = "BO_SM_Pir_2";
		break;

		case "BO_SM_Pir_2":
			dialog.text = "Quelqu'un a tiré sur Jackman. Depuis, il ne laisse entrer personne. Toutes les Bermudes ne parlent que de ça, et vous n'en avez pas eu vent.";
			link.l1 = "Il faut que je le voie. Aujourd'hui.";
			link.l1.go = "BO_SM_Pir_3";
		break;

		case "BO_SM_Pir_3":
			dialog.text = "Alors ce n'est pas moi qu'il vous faut, c'est Alan Barret. C'est lui qui garde cette porte. Dites-lui que vous voulez voir Jackman, et il vous expliquera comment ça se passe.";
			link.l1 = "Et oם trouver Barret ?";
			link.l1.go = "BO_SM_Pir_4";
		break;

		case "BO_SM_Pir_4":
			dialog.text = "א la baie de l'וpave, là oם gît la vieille carcasse. Il y est presque toujours : c'est tranquille, et pas d'yeux indiscrets. Seulement, ne lui tenez pas la jambe, il n'aime pas ça.";
			link.l1 = "C'est noté. Je n'ai rien contre les hommes silencieux, ils causent moins d'ennuis.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelFindBarret");
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
