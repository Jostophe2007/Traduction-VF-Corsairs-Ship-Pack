void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	ref _location;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		
////////////////////////////////////////////////////////////////////////////////////////////////
// Анжелика Тич: "The dressmaker of a noble lady"			Авторы: Nikk и Sinistra
////////////////////////////////////////////////////////////////////////////////////////////////		
		
		case "First time":
			dialog.text = "Signalez ce bug à Sinistra";
			link.l1 = "";
			link.l1.go = "exit";
		break;
		
		case "AT_PZD_Pilar_1_1":
			dialog.text = "";
			link.l1 = "Rebecca ?";
			link.l1.go = "AT_PZD_Pilar_1_2";
			DeleteAttribute(npchar, "talker");
		break;

		case "AT_PZD_Pilar_1_2":
			dialog.text = "Je vous demande pardon ?";
			link.l1 = "Comment... Je crois que je me suis trompée. Je vous ai confondue avec une de mes amies.";
			link.l1.go = "AT_PZD_Pilar_1_3";
		break;

		case "AT_PZD_Pilar_1_3":
			dialog.text = "Et je l'ai déjà parfaitement compris. Maintenant, je vous prie de vous écarter de moi.";
			link.l1 = "Bien sמr, bien sמr. Mais j'aimerais juste savoir qui a fait votre robe ? C'est à cause d'elle qu'il m'a semblé que vous étiez cette fille.";
			link.l1.go = "AT_PZD_Pilar_1_4";
		break;

		case "AT_PZD_Pilar_1_4":
			dialog.text = "Sottises.";
			link.l1 = "";
			link.l1.go = "AT_PZD_Pilar_1_5";
		break;

		case "AT_PZD_Pilar_1_5":
			dialog.text = "Garbird, qu'est-ce que tu fais planté là ?";
			link.l1 = "";
			link.l1.go = "AT_PZD_Pilar_1_6";
			LAi_SetActorType(npchar);
			LAi_ActorTurnToCharacter(npchar, CharacterFromID("AT_PZD_Herineldo"));
		break;

		case "AT_PZD_Pilar_1_6":
			DialogExit();
			StartInstantDialog("AT_PZD_Herineldo", "AT_PZD_Pilar_1_7", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
			sld = CharacterFromID("AT_PZD_Pilar");
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);			
		break;

		case "AT_PZD_Pilar_1_7":
			dialog.text = "Señorita, je dois insister.";
			link.l1 = "Ne vous dérangez pas !";
			link.l1.go = "AT_PZD_Pilar_1_8";
		break;

		case "AT_PZD_Pilar_1_8":
			DialogExit();
			
			sld = CharacterFromID("AT_PZD_Pilar");
			LAi_SetCitizenType(sld);
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
			
			sld = CharacterFromID("AT_PZD_Herineldo");
			LAi_SetActorType(sld);
			LAi_ActorFollow(sld, CharacterFromID("AT_PZD_Pilar"), "", -1);
			sld.lifeday = 0;
			
			sld = CharacterFromID("AT_PZD_R1");
			LAi_SetActorType(sld);
			LAi_ActorFollow(sld, CharacterFromID("AT_PZD_Pilar"), "", -1);
			sld.lifeday = 0;
			
			SetQuestHeader("AT_PZD");
			AddQuestRecord("AT_PZD", "1");
			pchar.questTemp.AT_PZD_InProgress = true; // LEO: костёр рассказчиков уступает Мариго на время линейки Тич
			LocatorReloadEnterDisable("Marigo_town", "reload3_back", true);
			LocatorReloadEnterDisable("Marigo_town", "reloadR2", true);
			
			PChar.quest.AT_PZD_ProvalMissii.win_condition.l1 = "MapEnter";
			PChar.quest.AT_PZD_ProvalMissii.win_condition = "AT_PZD_ProvalMissii";
			
			pchar.questTemp.AT_PZD_taverna = true;
			pchar.questTemp.AT_PZD_PU = true;
		break;
		
		case "AT_PZD_MatrosUKostra_1":
			locCameraFromToPos(43.47, 3.58, -6.19, true, 32.50, 0.20, 0.00);
			TeleportCharacterToPosAy(pchar, 39.58, 0.02, -4.80, -0.40);
			dialog.text = "... (sans nous remarquer)... Et je lui dis que c'est un pauvre naïf, s'il croit ces rumeurs selon lesquelles j'aurais pris un ours noir dans mes bras... Mais il n'y a rien eu de tel, que voulez-vous ?";
			link.l1 = "Vous vous reposez, les travailleurs ? J'ai à vous parler.";
			link.l1.go = "AT_PZD_MatrosUKostra_2";
		break;
		
		case "AT_PZD_MatrosUKostra_2":
			dialog.text = "Vous avez bien vu, mademoiselle. On se repose. Si vous voulez proposer un travail, revenez demain... Ou non, plutכt dans 2 jours. On a déjà un employeur pour demain, ou alors proposez un bon prix.";
			link.l1 = "J'en ai besoin maintenant. 2 000 pièces pour une simple conversation, ça vous va ?";
			link.l1.go = "AT_PZD_MatrosUKostra_3";
		break;
		
		case "AT_PZD_MatrosUKostra_3":
			dialog.text = "Marché conclu. Allongez la monnaie, seulement l'argent d'avance, et on vous dira ce qu'on sait.";
			if (sti(pchar.Money) >= 2000)
			{
				link.l1 = "Voilà.";
				link.l1.go = "AT_PZD_MatrosUKostra_4";
			}
			link.l2 = "J'ai laissé ma bourse dans la cabine, je reviens vite.";
			link.l2.go = "AT_PZD_MatrosUKostra_3_0";
		break;
		
		case "AT_PZD_MatrosUKostra_3_0":
			DialogExit();
			
			for (i=1; i<=3; i++)
			{
				sld = CharacterFromID("AT_PZD_Matros"+i);
				sld.dialog.filename = "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c";
				sld.dialog.currentnode = "AT_PZD_MatrosUKostra_3_1";
			}
		break;
		
		case "AT_PZD_MatrosUKostra_3_1":
			dialog.text = "Hé, mademoiselle ! Vous avez les 2 000 piastres ?";
			if (sti(pchar.Money) >= 2000)
			{
				link.l1 = "Voilà.";
				link.l1.go = "AT_PZD_MatrosUKostra_4";
			}
			link.l2 = "Pas encore, je reviens vite.";
			link.l2.go = "exit";
			NextDiag.TempNode = "AT_PZD_MatrosUKostra_3_1";
		break;
		
		case "AT_PZD_MatrosUKostra_4":
			dialog.text = "Parfait, alors qu'est-ce que vous vouliez savoir ?";
			link.l1 = "Je m'intéresse à une aristocrate qui est descendue d'un des navires espagnols. Elle se promenait récemment sur le quai, escortée de soldats, elle portait un chapeau à larges bords, difficile de ne pas la remarquer.";
			link.l1.go = "AT_PZD_MatrosUKostra_5";
		break;
		
		case "AT_PZD_MatrosUKostra_5":
			dialog.text = "Sa Seigneurie a dמ daigner se promener sur le pavé, mais nous, on trime au port de l'aube au crépuscule. Il faut aller voir le gouverneur, matelot, avec ce genre de questions, mais il ne reçoit pas les gens comme vous.";
			link.l1 = "Je suis capitaine de mon propre navire, il me recevra par devoir.";
			link.l1.go = "AT_PZD_MatrosUKostra_6";
		break;
		
		case "AT_PZD_MatrosUKostra_6":
			dialog.text = "C'est ça. Ils ont des bals masqués là-bas tous les soirs, pas le temps pour les affaires de l'וtat. Les nobles invités viennent chez lui, mais personne d'autre n'est admis.";
			link.l1 = "Des bals masqués ?";
			link.l1.go = "AT_PZD_MatrosUKostra_7";
		break;
		case "AT_PZD_MatrosUKostra_7":
			dialog.text = "Comme je vous le dis. Hier, je passais devant la résidence, j'ai vu dans le jardin un épouvantail avec un grand nez, je me suis déjà signé, et c'était un don qui portait un masque et restait planté là, à regarder la statue. Oh, j'ai bien ri, alors.";
			link.l1 = "Eh bien, au moins, il y a une piste. Comment pourrais-je bien me rendre à cette réception ?";
			link.l1.go = "AT_PZD_MatrosUKostra_8";
		break;
		case "AT_PZD_MatrosUKostra_8":
			dialog.text = "C'est encore aux mauvaises personnes que vous posez des questions, matelot.";
			link.l1 = "Je sais, et merci pour ça.";
			link.l1.go = "AT_PZD_MatrosUKostra_9";
		break;
		case "AT_PZD_MatrosUKostra_9":
			DialogExit();
			
			AddQuestRecord("AT_PZD", "4");
			
			pchar.questTemp.AT_PZD_Rostovshik = true;
			pchar.questTemp.AT_PZD_Lavochniki = true;
			pchar.questTemp.AT_PZD_Bordel = true;
			
			for (i=1; i<=4; i++)
			{
				sld = CharacterFromID("AT_PZD_Matros"+i);
				sld.lifeday = 0;
				LAi_CharacterDisableDialog(sld);
			}
		break;
		
		case "AT_PZD_ManBal5":
			dialog.text = "Et oם est passé l'hכte de la soirée ? Il m'avait promis une partie de poker.";
			link.l1 = "Il n'est pas dans le jardin.";
			link.l1.go = "AT_PZD_ManBal5_2";
		break;
		case "AT_PZD_ManBal5_2":
			dialog.text = "Si vous le croisez, dites-lui, je vous prie, que je l'attends ici.";
			link.l1 = "Je le ferai.";
			link.l1.go = "exit";
			NextDiag.TempNode = "AT_PZD_ManBal5";
		break;
		
		case "AT_PZD_WomanBal1":
			dialog.text = "Si Mme Sharp, au fond de son cœur, a décidé de conquérir ce dandy obèse, je ne pense pas que nous ayons le droit de la condamner de quelque façon que ce soit, car la tâche d'attraper des prétendants est d'ordinaire confiée, avec la pudeur qui convient, par les jeunes gens à leurs mères ; mais souvenez-vous que Mme Sharp n'a pas de parent aimant, et si elle ne se trouve pas elle-même un mari, il n'y aura personne au monde pour lui rendre ce service.";
			link.l1 = "";
			link.l1.go = "AT_PZD_WomanBal2";
			sld = CharacterFromID("AT_PZD_WomanBal1");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest1");
		break;
		
		case "AT_PZD_WomanBal2":
			DialogExit();
			StartInstantDialog("AT_PZD_WomanBal2", "AT_PZD_WomanBal3", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_WomanBal3":
			dialog.text = "Je ne peux qu'être d'accord. C'est autre chose pour Mme Pilar, qui a amené son grand dadais de fils à la présentation. Le pauvre garçon doit brמler de honte.";
			link.l1 = "";
			link.l1.go = "AT_PZD_WomanBal4";
			sld = CharacterFromID("AT_PZD_WomanBal2");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest2");
		break;
		
		case "AT_PZD_WomanBal4":
			DialogExit();
			StartInstantDialog("AT_PZD_WomanBal1", "AT_PZD_WomanBal5", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_WomanBal5":
			dialog.text = "Les parents auraient pu régler l'affaire sans la présence de leur progéniture, je ne pense pas qu'une seule des sœurs prête la moindre attention à ce jeune homme.";
			link.l1 = "";
			link.l1.go = "AT_PZD_WomanBal6";
			sld = CharacterFromID("AT_PZD_WomanBal1");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest1");
		break;
		
		case "AT_PZD_WomanBal6":
			DialogExit();
			StartInstantDialog("AT_PZD_WomanBal2", "AT_PZD_WomanBal7", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_WomanBal7":
			dialog.text = "Il me paraît plutכt gentil, mais qu'en pensez-vous, mynheer Andres ?";
			link.l1 = "";
			link.l1.go = "AT_PZD_WomanBal8";
			sld = CharacterFromID("AT_PZD_WomanBal2");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest2");
		break;
		
		case "AT_PZD_WomanBal8":
			DialogExit();
			StartInstantDialog("AT_PZD_ManBal4", "AT_PZD_WomanBal9", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_WomanBal9":
			dialog.text = "La famille Turner fait des affaires dans la Compagnie des Indes occidentales, le garçon a un bel avenir, il serait imprudent de le laisser partir sans fiancée...";
			link.l1 = "";
			link.l1.go = "exit";
			sld = CharacterFromID("AT_PZD_ManBal4");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest3");
			
			AddQuestRecord("AT_PZD", "6");
		break;
		
		case "AT_PZD_DochGubera":
			dialog.text = "...";
			link.l1 = "";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(npchar);
			
			AddQuestRecord("AT_PZD", "7");
		break;

		case "AT_PZD_MujikBoltun_1":
			dialog.text = "Je t'ai prévenu mille fois. Je ne peux plus t'aider. Tout mon argent est placé jusqu'au dernier shilling.";
			link.l1 = "";
			link.l1.go = "AT_PZD_MujikBoltun_2";
			sld = CharacterFromID("AT_PZD_MujikBoltun1");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest5");
		break;
		
		case "AT_PZD_MujikBoltun_2":
			DialogExit();
			StartInstantDialog("AT_PZD_MujikBoltun2", "AT_PZD_MujikBoltun_3", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_MujikBoltun_3":
			dialog.text = "Je ne veux pas parler de moi. Peu importe ce qui m'arrive...";
			link.l1 = "";
			link.l1.go = "AT_PZD_MujikBoltun_4";
			sld = CharacterFromID("AT_PZD_MujikBoltun2");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest6");
		break;
		
		case "AT_PZD_MujikBoltun_4":
			DialogExit();
			StartInstantDialog("AT_PZD_MujikBoltun1", "AT_PZD_MujikBoltun_5", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_MujikBoltun_5":
			dialog.text = "Alors, qu'y a-t-il ?";
			link.l1 = "";
			link.l1.go = "AT_PZD_MujikBoltun_6";
			sld = CharacterFromID("AT_PZD_MujikBoltun1");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest5");
		break;
		
		case "AT_PZD_MujikBoltun_6":
			DialogExit();
			StartInstantDialog("AT_PZD_MujikBoltun2", "AT_PZD_MujikBoltun_7", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_MujikBoltun_7":
			dialog.text = "Tu sais que je devais toucher l'argent de Mme Crowley. Je ne m'en sortais pas mal au régiment, la solde couvrait toutes mes dépenses. Et tu sais pourquoi l'héritage m'a filé sous le nez, et qui l'a touché...";
			link.l1 = "";
			link.l1.go = "AT_PZD_MujikBoltun_8";
			sld = CharacterFromID("AT_PZD_MujikBoltun2");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest6");
		break;
		
		case "AT_PZD_MujikBoltun_8":
			DialogExit();
			StartInstantDialog("AT_PZD_MujikBoltun1", "AT_PZD_MujikBoltun_9", "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c");
		break;
		
		case "AT_PZD_MujikBoltun_9":
			dialog.text = "Ne hausse pas le ton, ce n'est ni le moment ni l'endroit ; mais oם sont-ils tous passés ? Pas de maître, pas de domestiques... Dieu sait que la prochaine fois, j'apporterai une bouteille de vin.";
			link.l1 = "";
			link.l1.go = "exit";
			sld = CharacterFromID("AT_PZD_MujikBoltun1");
			LAi_SetActorType(sld);
			LAi_ActorTurnByLocator(sld, "quest", "quest5");
		break;
		
		case "AT_PZD_GabrielDeSeguensa_1":
			dialog.text = "Vous vous sentez mal à l'aise dans une compagnie inconnue ?";
			link.l1 = "Vous n'avez pas idée à quel point.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_2";
			sld = CharacterFromID("AT_PZD_GabrielDeSeguensa");
			LAi_ActorTurnByLocator(sld, "quest", "quest9");
			LAi_ActorAnimation(sld, "barman_look_around", "", 2.9);
			locCameraFromToPos(-0.74, 8.81, 42.94, true, 2.00, 7.20, 42.00);
			ChangeCharacterAddressGroup(pchar, "Marigo_hall", "quest", "quest17");
		break;
		
		case "AT_PZD_GabrielDeSeguensa_2":
			dialog.text = "Oh, vous êtes espagnole ? Il est terriblement regrettable que nous ne nous rencontrions que maintenant, alors que la soirée touche à sa fin. Je vous aurais volontiers invitée à danser.";
			link.l1 = "דa n'aurait rien donné, je ne sais pas danser la valse.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_3";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_3":
			dialog.text = "Une dame de votre rang n'a pu qu'être initiée à cet art. C'est cela, vous refusez même de me laisser espérer par avance...";
			link.l1 = "א vrai dire, je suis ici même sans invitation. J'ai profité du fait que tous les invités portaient des masques, et j'ai compté sur leur courtoisie, puisque la veille, nous nous serions déjà présentés. Au fait, oם est votre masque ?";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_4";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_4":
			dialog.text = "Il m'irritait l'arête du nez. Permettez-moi donc d'être impoli.";
			link.l1 = "Je m'appelle Angelica Remedios, la fille aînée du commandant du fort de La Vega.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_5";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_5":
			dialog.text = "Gabriel de Seguenza, arrivé aux Caraïbes au nom de la Couronne d'Espagne pour régler le problème de la piraterie dans les eaux cubaines. J'ai récemment été détaché de l'Ancien Monde, mais j'ai déjà entendu parler du triste sort du fort. Pourquoi ne m'avez-vous pas encore dit un mot de vérité ? Vous jouez avec moi comme avec un chaton.";
			link.l1 = "Vous connaissez le dicton : la meilleure façon de cacher la vérité, c'est de la dire ; et puisque vous êtes dans la confidence de mon petit secret, puis-je vous demander une petite faveur ?";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_6";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_6":
			dialog.text = "Eh bien, j'accepte les règles de votre jeu.";
			link.l1 = "La nuit oם La Vega a été mise à sac, les pirates m'ont séparée de ma sœur. Elle avait disparu, et j'avais déjà accepté l'idée de sa mort, jusqu'à ce que je rencontre une femme vêtue d'une robe exactement pareille à celle que portait la pauvre Becky la dernière fois que nous nous sommes vues. Son visage était caché par un immense chapeau, et pendant un instant, j'ai même cru que c'était vraiment Rebecca, mais cette arrogante a refusé de me parler. Me voici donc cachée derrière un masque, dans l'espoir de la retrouver et de découvrir l'histoire de sa tenue.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_7";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_7":
			dialog.text = "Mauvais caractère, large chapeau : la señora Turner Pilar. Elle n'est pas présente à la soirée, mais je viens de croiser son fils dans la cour.";
			link.l1 = "Vous me rendriez un service inestimable en nous mettant en présence.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_8";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_8":
			dialog.text = "Je vais le chercher et lui parler. Angelica, tâchez de ne pas trop attirer l'attention pour l'instant, vous m'aiderez en même temps. Vous voyez ce monsieur assis à la table là-bas ? C'est le commandant de la garnison, je pense que vous trouverez un terrain d'entente. Dites-lui que Gabriel vous a demandé de lui tenir compagnie, et au bout d'un moment, sortez par la porte derrière la scène, sur le quai.";
			link.l1 = "D'accord, compris.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_9";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_9":
			DialogExit();
			
			AddQuestRecord("AT_PZD", "8");
			
			sld = CharacterFromID("AT_PZD_GabrielDeSeguensa");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "reload2_back", "", "", "", "", -1);
			
			sld = CharacterFromID("AT_PZD_ManBal5");
			sld.dialog.filename = "Quest\AngelikaTichLine\PortnihaZnatnoyDamy.c";
			sld.dialog.currentnode = "AT_PZD_IgraVKosti";
		break;
		
		case "AT_PZD_IgraVKosti":
			dialog.text = "";
			link.l1 = "Vous invitez la dame à votre table ?";
			link.l1.go = "AT_PZD_IgraVKosti_2";
		break;
		
		case "AT_PZD_IgraVKosti_2":
			dialog.text = "Je ne veux pas manquer de tact, j'attends un partenaire de dés.";
			link.l1 = "Donnez-moi mes dés.";
			link.l1.go = "AT_PZD_IgraVKosti_3";
		break;
		
		case "AT_PZD_IgraVKosti_3":
			dialog.text = "Les règles sont très simples : nous lançons les dés à tour de rכle...";
			link.l1 = "Les dés !";
			link.l1.go = "AT_PZD_IgraVKosti_4";
		break;
		
		case "AT_PZD_IgraVKosti_4":
			dialog.text = "Dieu m'est témoin, je parierais mon pistolet d'honneur si au moins une femme pouvait me battre. א ma honte, je l'ai mis en gage la semaine dernière.";
			link.l1 = "Je joue pour le plaisir, j'ai juste besoin de tuer le temps.";
			link.l1.go = "AT_PZD_IgraVKosti_5";
			npchar.money = 10000;
			
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
			pchar.GenQuest.Dice.iRate     = 0;
            pchar.GenQuest.Dice.SitType   = true;			
			//pchar.GenQuest.Cards.npcharIdx = npchar.index;
            //pchar.GenQuest.Cards.iRate     = 0;
			//pchar.GenQuest.Cards.SitType   = true;
		break;
		
		case "AT_PZD_IgraVKosti_5":
			DialogExit();
			LaunchDiceGame();
			//LaunchCardsGame();
			
			LAi_CharacterDisableDialog(npchar);
			DoQuestCheckDelay("AT_PZD_UbiliVremya", 60.0);
		break;
		
		case "AT_PZD_GabrielDeSeguensa_11":
			dialog.text = "";
			link.l1 = "Vous avez réussi à trouver le garçon ?";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_12";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_12":
			dialog.text = "Oui, le voilà, sur la balustrade. Le jeune homme n'est pas d'humeur à de longues conversations, du moins pas en ma compagnie, mais quelle merveilleuse soirée tout de même, vous ne trouvez pas ?";
			link.l1 = "Je ne peux pas être d'accord, j'ai d'autres choses en tête en ce moment.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_13";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_13":
			dialog.text = "J'ai réussi à savoir oם séjourne Mlle Pilar. Mieux vaut ne pas avoir affaire à elle, mais parlez à sa servante : qui sait, elle a peut-être amené sa propre couturière. Permettez-moi de vous raccompagner.";
			link.l1 = "Bien sמr, allons-y.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_14";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_14":
			DialogExit();
			
			DoQuestReloadToLocation("Marigo_town", "goto", "goto29", "AT_PZD_VGorod");
		break;
		
		case "AT_PZD_GabrielDeSeguensa_15":
			dialog.text = "Ici. En haut de l'escalier.";
			link.l1 = "Vous montez avec moi ?";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_16";
			Log_info(GetConvertStrWithReplace("Variable_quests_reaction_160", "Logs.txt", "#space#", " "));
		break;
		
		case "AT_PZD_GabrielDeSeguensa_16":
			dialog.text = "Il est temps pour moi de retourner à La Havane. Sa Grâce Oregón y Gascón attend mes rapports. Bonne chance, Angelica.";
			link.l1 = "Prenez soin de vous. La chasse aux pirates est une activité très dangereuse.";
			link.l1.go = "AT_PZD_GabrielDeSeguensa_17";
		break;
		
		case "AT_PZD_GabrielDeSeguensa_17":
			DialogExit();
			
			sld = CharacterFromID("AT_PZD_GabrielDeSeguensa");
			LAi_SetCitizenType(sld);
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
		break;
		
		case "AT_PZD_Sofia_1":
			dialog.text = "";
			link.l1 = "Toi ?! Alors c'est ça, ton travail ?";
			link.l1.go = "AT_PZD_Sofia_2";
		break;
		
		case "AT_PZD_Sofia_2":
			dialog.text = "Oh, mon Dieu ! Señorita, je ne vous ai pas entendue entrer. Les maîtres logent en bas, ces pièces sont désormais réservées aux domestiques. Mais j'ai bien peur qu'ils soient encore...";
			link.l1 = "Sofia, tu ne me reconnais pas ? La Vega, la veille du siège.";
			link.l1.go = "AT_PZD_Sofia_3";
		break;
		
		case "AT_PZD_Sofia_3":
			dialog.text = "Aïe... Vous êtes la fille du marché qui voulait m'aider d'une manière ou d'une autre ? Vous savez, j'ai tellement honte, j'étais submergée par les problèmes qui s'accumulaient, et puis, j'étais fascinée par la coupe inhabituelle de la tenue de votre compagnon, alors je ne me suis pas du tout souvenue de votre visage.";
			link.l1 = "Comment as-tu réussi à t'échapper, alors ?";
			link.l1.go = "AT_PZD_Sofia_4";
		break;
		
		case "AT_PZD_Sofia_4":
			dialog.text = "On disait qu'avant que les pirates ne commencent à tirer sur la ville, ils sont montés sur notre navire et ont jeté tous les barils de poudre à la mer. Les officiers sont allés négocier avec eux, et à leur retour, le capitaine a ordonné à tous les passagers de monter dans les chaloupes, et nous sommes partis.";
			link.l1 = "Ils nous ont tout simplement abandonnés !";
			link.l1.go = "AT_PZD_Sofia_5";
		break;
		
		case "AT_PZD_Sofia_5":
			dialog.text = "C'est si terrible, je n'ai appris que récemment ce qui s'était passé là-bas.";
			link.l1 = "Pourquoi n'es-tu pas retournée en Europe ?";
			link.l1.go = "AT_PZD_Sofia_6";
		break;
		
		case "AT_PZD_Sofia_6":
			dialog.text = "Le navire n'est pas revenu, j'ai dמ chercher du travail. Heureusement, Mlle Pilar a été si généreuse, et vous savez, je n'ai pas envie de retourner sur le domaine de mon père. Je vous l'ai déjà dit ? Elle n'est pas ici.";
			link.l1 = "Bon, je reviendrai une autre fois. Je suis contente que tu aies surmonté tes difficultés.";
			link.l1.go = "AT_PZD_Sofia_7";
		break;
		
		case "AT_PZD_Sofia_7":
			dialog.text = "Merci, señorita.";
			link.l1 = "Bonne chance, Sofia.";
			link.l1.go = "AT_PZD_Sofia_8";
		break;
		
		case "AT_PZD_Sofia_8":
			DialogExit();
			
			sld = CharacterFromID("AT_PZD_Sofia");
			LAi_SetActorType(sld);
			
			AddQuestRecord("AT_PZD", "10");
			CloseQuestHeader("AT_PZD");
			DeleteAttribute(pchar, "questTemp.AT_PZD_InProgress"); // LEO: квест завершён - костёр снова может появляться
			PChar.quest.AT_PZD_ProvalMissii.over = "yes";
			
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
			bDisableOfficers = false;
			LocatorReloadEnterDisable("Marigo_town", "reload3_back", false);
			LocatorReloadEnterDisable("Marigo_town", "reloadR2", false);			
			DeleteAttribute(pchar, "questTemp.AT_PZD_Bordel")
			DeleteAttribute(pchar, "questTemp.AT_PZD_Bordel_2")
			DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki");
			DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki_2");
			DeleteAttribute(pchar, "questTemp.AT_PZD_Lavochniki_3");
			DeleteAttribute(pchar, "questTemp.AT_PZD_taverna")
			DeleteAttribute(pchar, "questTemp.AT_PZD_PU")
			DeleteAttribute(pchar, "questTemp.AT_PZD_Rostovshik")
			InterfaceStates.Buttons.Save.enable = true;
			DeleteAttribute(pchar, "Cirgnore");
			locations[FindLocation("Marigo_hall")].models.always.l1 = "residence06";
			//locations[FindLocation("Marigo_hall")].models.always.l1 = "residence06_quest";
			locations[FindLocation("Marigo_hall")].models.always.locators = "residence06_locators";
			//locations[FindLocation("Marigo_hall")].models.always.locators = "residence06_quest_locators";
			locations[FindLocation("Marigo_hall")].models.day.charactersPatch = "residence06_patch";
			//locations[FindLocation("Marigo_hall")].models.day.charactersPatch = "residence06_quest_patch";
			locations[FindLocation("Marigo_hall")].models.night.charactersPatch = "residence06_patch";
			//locations[FindLocation("Marigo_hall")].models.night.charactersPatch = "residence06_quest_patch";
			
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Sneak", 150);
		break;

	}
}
