
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp, i;

	string NodeName = Dialog.CurrentNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.location == "SanAugustineResidence")
			{
				dialog.text = "Qu'est-ce que tu veux ? Ne me retiens pas pour des bêtises, je suis occupé.";
				link.l1 = "Pardon, je passais juste te voir.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Quand je ne suis pas à ma résidence, je ne suis pas contre une petite conversation, en principe... Qu'est-ce que tu veux ?";
				link.l1 = "Je voulais juste savoir si tout allait bien dans la Cité.";
				link.l1.go = "NRes_1";
			}
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				pchar.questTemp.LSC = "AdmiralFoundHero";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Ah, te voilà. C'est bien que tu viennes me voir de toi-même. Je n'aime pas qu'on me fuie, surtout par une tempête pareille...";
					link.l1 = "Je n'ai l'intention de fuir personne. Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
					PChar.quest.LSC_admiralOwnFind.over = "yes";
				}
				else
				{
					dialog.text = "Ah, te voilà. J'attendais que tu viennes me voir.";
					link.l1 = "Salutations. Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
				break;
			}
			//квестовые ноды по главной линейке
			if (pchar.questTemp.LSC == "toAdmNarvalRing" && CheckCharacterItem(pchar, "DOjeronRing"))
			{
				link.l4 = "Amiral, j'ai des informations importantes pour toi. Hum, enfin, il me semble...";
				link.l4.go = "NarvalRing_1";
			}
			if (pchar.questTemp.LSC == "NarvalDestroyed")
			{
				link.l4 = "J'ai tout fait, le clan des Narvals a été anéanti. Je les ai tous taillés en pièces jusqu'au dernier, personne n'en a réchappé !";
				link.l4.go = "DestrNarval_1";
			}
			if (pchar.questTemp.LSC == "toAdmiralBarmenDead")
			{
				link.l4 = "Amiral, je voulais parler du meurtre de Hill Brunner.";
				link.l4.go = "BarmenDead_1";
			}
			if (pchar.questTemp.LSC == "fromMechanicToAdmiral")
			{
				link.l4 = "Amiral, je voulais te parler.";
				link.l4.go = "CasperDead_1";
			}
			//дополнительные квестовые ноды
			//муж Элис Тейлор
			if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC != "AdmiralIsWaiting" && pchar.questTemp.LSC.ElisHusband == "toElis")
			{
				link.l5 = "Amiral, dis-moi, s'il te plaît, qu'a donc fait Maxim Taylor ici ?";
				link.l5.go = "ELTHusb_begin";
			}
			if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toAdmiral")
			{
				link.l5 = "Amiral, je voudrais aider Maxim Taylor.";
				link.l5.go = "ELTHusb_SF";
			}
			if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toAdmiralGood")
			{
				link.l5 = "Amiral, j'ai appris quelque chose sur les circonstances de cette affaire Taylor.";
				link.l5.go = "ELTHusb_good";
			}
			//квест со скелетом Декстера
			if (CheckAttribute(pchar, "questTemp.LSC.lostDecster") && pchar.questTemp.LSC != "AdmiralIsWaiting" && pchar.questTemp.LSC.lostDecster == "toAdmiral")
			{
				link.l6 = "Amiral, j'ai une petite question pour toi au sujet de Leighton Dexter.";
				link.l6.go = "LostDecster";
			}
			//поиск товаров на корвет
			if (pchar.questTemp.LSC == "toSeekGoods")
			{
				link.l8 = "וcoute, je cherche certaines marchandises. Tu pourrais me dépanner ?";
				link.l8.go = "SeekGoods";
			}
			//найм команды
			if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
			{
				link.l8 = "Amiral, une tempête approche...";
				link.l8.go = "SeekCrew";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NRes_1":
			dialog.text = "Oui, tout va bien. Je suis content que notre Cité te tienne autant à cœur. Tu es "+ GetSexPhrase("un bon citoyen", "une bonne citoyenne") +".";
			link.l1 = "Toujours à ton service, amiral !";
			link.l1.go = "exit";
		break;

		case "FT_1":
			dialog.text = "Très bien, "+ GetSexPhrase("l'ami", "ma petite") +", c'est tout simplement parfait... Et moi, je m'appelle " + GetFullName(npchar) + ", je suis l'amiral de cette Cité des navires abandonnés !";
			link.l1 = "Ha, mais j'ai entendu parler de toi ! Tu es le capitaine pirate qui est parti chasser une prise sur la « Terreur du Main » et qui a disparu. Alors c'est là que tu as atterri !";
			link.l1.go = "FT_1_1";
		break;
		case "FT_1_1":
			dialog.text = "Oui, on se souvient encore de moi dans les Caraïbes... Tu vois comment ça a tourné. Pendant deux jours, nous avons poursuivi un galion espagnol, et dans la nuit du troisième jour, nous nous sommes retrouvés ici... Bon sang, tout mon équipage a sombré, seuls Workman, Faure et moi avons pu nous en sortir.";
			link.l1 = "Pardon...";
			link.l1.go = "FT_1_2";
		break;
		case "FT_1_2":
			dialog.text = "א vrai dire, c'était un équipage de merde, à l'époque. Alors pas la peine de trop pleurer, d'autant que c'est de l'histoire ancienne... Bon, ce n'est pas de ça qu'on parle en ce moment !";
			link.l1 = "Dis-moi ce qu'il te faut. Je t'écoute attentivement, " + npchar.name + ".";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Bon, voilà ! Dès l'instant oם tu as mis le pied sur le pont de notre île en sortant de la mer, tu as acquis la citoyenneté, et désormais, la Loi de la Cité s'applique à toi. Tu comprends ?";
			link.l1 = "Tout à fait. Et c'est quoi, cette Loi, comment puis-je en prendre connaissance ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "C'est moi qui te présente la Loi, en ce moment précis. Elle n'est pas gravée sur des tables, vu qu'on manque de pierre, haha... Et la Loi se résume essentiellement aux points suivants. "+
				"Tous les citoyens de la Cité des navires abandonnés ont droit à la vie. Ce droit est garanti par la garnison de la milice, qui est à la disposition de l'amiral, c'est-à-dire à ma disposition... Au fait, tu ne voudrais pas entrer dans la police ?";
			link.l1 = "On verra. D'abord, il faut que je m'installe, que je m'organise ici d'une manière ou d'une autre, et ensuite seulement, je réglerai ce genre de questions.";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Tu as l'air "+ GetSexPhrase("d'un sacré costaud", "d'une sacrée battante") +". Qu'est-ce que tu faisais, dans le vaste monde ?";
			link.l1 = "Oh, tu sais, j'ai roulé ma bosse... J'étais capitaine libre, comme toi, en somme.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Je vois... Mais à présent, à vrai dire, je m'en fiche. Avant d'arriver ici, tu pouvais bien venir d'Espagne ou de France, être un ange ou un démon : ici, tout le monde est égal. Maintenant, tu fais partie des citoyens de la Cité, avec tes propres droits, dont le plus important est le droit à la vie !";
			link.l1 = "Oui, pas mal. La justice universelle. Au fait, dans les Caraïbes, il court des rumeurs sur une certaine טle de la Justice. Je suppose que c'est votre Cité.";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Non, impossible. Il n'y a pas moyen de partir d'ici... Bon, continuons. Voilà pour les droits, maintenant, tes devoirs. Premièrement : tu ne peux pas attenter à la vie des citoyens de la Cité. Si tu tues quelqu'un, je te tue. C'est clair ?";
			link.l1 = "Hum, je vois...";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "Une petite nuance. Nous avons ici, dans la Cité, deux communautés, les clans dits des Narvals et des Caspers. En gros, s'y sont rassemblés des gens à qui la vie d'une personne honnête reste en travers de la gorge. Nous leur avons attribué deux navires en résidence permanente : la barque San Gabriel et le galion Velasco. Ces navires sont isolés, pour que les clans ne perturbent pas la vie de la Cité\n"+
				"Donc, les citoyens ne doivent pas pénétrer à l'intérieur de ces navires : c'est dangereux pour leur vie. L'intérieur de ces navires a été cédé en propriété aux clans, et sur ce territoire, ils ont leurs propres lois. Alors n'y entre pas, ou ne t'en prends qu'à toi-même. C'est clair ?";
			link.l1 = "Compris.";
			link.l1.go = "FT_7_1";
		break;
		case "FT_7_1":
			dialog.text = "Continuons. Deuxièmement : il est interdit de construire des navires, des radeaux et autres embarcations. De toute façon, il est impossible de sortir d'ici, et on ne peut pas détruire la Cité.";
			link.l1 = "דa aussi, c'est compréhensible.";
			link.l1.go = "FT_7_2";
		break;
		case "FT_7_2":
			dialog.text = "Troisièmement : le vol est puni de mort dans la Cité. Si l'on te surprend"+ GetSexPhrase(" à fouiller", " à fouiller") +" dans le coffre d'un autre, tu perds automatiquement ta citoyenneté et tu deviens hors-la-loi. Et ça veut dire que tu n'as plus le droit de vivre...";
			link.l1 = "דa a l'air tentant... Bon, c'est clair. Et ensuite ?";
			link.l1.go = "FT_8";
		break;
		case "FT_8":
			dialog.text = "Et quatrièmement : toutes les ressources matérielles arrivées dans la Cité appartiennent à la Cité.";
			link.l1 = "Hum, sur ce point-là, j'aimerais plus de détails, s'il te plaît.";
			link.l1.go = "FT_9";
		break;
		case "FT_9":
			dialog.text = "Héhé, qu'est-ce qui n'est pas clair ? Par exemple, toi, en tant que personne physique, tu as débarqué dans la Cité. Et remarque bien : tu as aussitכt acquis la citoyenneté ! Eh bien, tes biens, en tant qu'actifs matériels, deviennent la propriété de la Cité. Donc tout ce qui est à toi est désormais à nous tous !";
			link.l1 = "Minute ! Je ne suis pas d'accord avec cet arrangement !";
			link.l1.go = "FT_10";
		break;
		case "FT_10":
			if (pchar.questTemp.LSC == "AdmiralFoundHero")
			{
				dialog.text = "En voilà"+ GetSexPhrase(" un drכle de type", " une drכle de fille") +" ! Ton consentement n'est pas nécessaire, on prend, c'est tout... Mais j'ai aussi une bonne nouvelle. En tant que membre de plein droit de la Cité, tu reçois une part de 1/50 !";
				link.l1 = "Sur mes propres biens !!";
				link.l1.go = "FT_11";
				pchar.money = makeint(sti(pchar.money) / 50);
			}
			else
			{
				dialog.text = "Et personne ne te demande ton consentement. En fait, la Loi oblige à inclure l'ancien propriétaire des biens parmi les bénéficiaires du partage. Mais comme tu as enfreint la Loi, à savoir que tu ne m'as pas rendu visite dès ton arrivée dans la Cité, ce point de la Loi perd sa force à ton égard. Autrement dit, tu ne reçois rien.";
				link.l1 = "Tout ça ne me plaît pas du tout !";
				link.l1.go = "FT_12";
				pchar.money = 0;
			}
		break;
		case "FT_11":
			dialog.text = "Exactement ! Bon, tu commences à comprendre... En fait, tu n'as pas besoin de tout ce bazar ici, mais nous, ça nous fera plaisir à tous...";
			link.l1 = "Tout ça ne me plaît pas du tout !";
			link.l1.go = "FT_12";
		break;
		case "FT_12":
			dialog.text = "דa ne plaît à personne au début, "+ GetSexPhrase("l'ami", "ma petite") +". Mais crois-moi, tout ça est dans ton intérêt. Plus vite tu te débarrasseras de tout ce qui te lie au vaste monde, plus vite tu rejoindras notre vie paisible. Sinon, on peut devenir fou, ça arrive. Et je te le dis, on ne fait pas de manières avec ces gens-là : un boulet au cou, et au fond !";
			link.l1 = "Oui, la justice déborde de partout...";
			link.l1.go = "FT_13";
		break;
		case "FT_13":
			dialog.text = "Pour ta grossièreté, je te prive de tes armes, et d'ailleurs, je vais vider tes poches ! Et garde bien à l'esprit que la prochaine fois, si tu ne me plais pas, je te tuerai, tout simplement.";
			link.l1 = "Hum... Bon, il va falloir s'y faire. On dirait que je n'ai pas d'autre choix.";
			link.l1.go = "FT_14";
		break;
		case "FT_14":
			dialog.text = "C'est exact. Et je ne te conseille pas de chercher une issue, c'est interdit par la Loi !";
			link.l1 = "Je m'en souviens...";
			link.l1.go = "FT_15";
		break;
		case "FT_15":
			dialog.text = "Eh bien, parfait... Et maintenant, tu es libre et tu peux circuler dans la Cité comme bon te semble. Fais ce que tu veux, profite de la vie dans la Cité.";
			link.l1 = "C'est ce que je vais faire, Chad.";
			link.l1.go = "FT_16";
		break;
		case "FT_16":
			if (npchar.chr_ai.type == LAI_TYPE_ACTOR) LAi_SetLSCoutTypeNoGroup(npchar);
			AddDialogExitQuestFunction("LSC_admiralTakeAll");
			NextDiag.TempNode = "First time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//базар с ГГ, если сам не пришёл к адмиралу
		case "FoundHero":
			npchar.quest.meeting = "1";
			NextDiag.TempNode = "First time";
			pchar.questTemp.LSC = "AdmiralNotFoundHero";
			dialog.text = "Ah, c'est donc toi qui as survécu à la dernière tempête. Dis-moi, "+ GetSexPhrase("l'ami", "ma petite") +", pourquoi diable devrais-je te chercher dans toute la Cité ? Tu ne connais pas nos règles ?";
			link.l1 = "Salutations. Quelles règles ?";
			link.l1.go = "FoundHero_1";
		break;
		case "FoundHero_1":
			dialog.text = "Tu veux dire que tu ne savais pas qu'il faut venir me voir dès qu'on arrive dans la Cité ?";
			link.l1 = "Je ne savais pas...";
			link.l1.go = "FoundHero_2";
		break;
		case "FoundHero_2":
			dialog.text = "Nul n'est censé ignorer la Loi ! Maintenant, dis-moi qui tu es.";
			link.l1 = "Je te prie de m'excuser pour ce retard, je n'ai pas encore étudié les Lois de la Cité. J'espère que ça ira mieux désormais... Je m'appelle " + GetFullName(pchar) + ".";
			link.l1.go = "FT_1";
		break;

		//ГГ принёс амулет нарвалов
		case "NarvalRing_1":
			dialog.text = "Je suis tout ouïe.";
			link.l1 = "J'ai récemment fouillé la cabine de la corvette « Protector », et j'y ai trouvé tout à fait par hasard un objet intéressant...";
			link.l1.go = "NarvalRing_2";
		break;
		case "NarvalRing_2":
			dialog.text = "Quel objet ? Parle vite, ne traîne pas !";
			link.l1 = "C'est un anneau. Le voici, regarde.";
			link.l1.go = "NarvalRing_3";
		break;
		case "NarvalRing_3":
			dialog.text = "Oh, oh, c'est une amulette des Narvals ! Alors, oם l'as-tu trouvée ?";
			link.l1 = "Dans la cabine du « Protector ».";
			link.l1.go = "NarvalRing_4";
			TakeItemFromCharacter(pchar, "DOjeronRing");
			BackItemName("DOjeronRing");
			BackItemDescribe("DOjeronRing");
			ref itm;
			itm = ItemsFromID("DOjeronRing");
			itm.picIndex = 2;
			itm.picTexture = "ITEMS_9";
		break;
		case "NarvalRing_3":
			dialog.text = "Sais-tu que c'est là qu'a été commis le meurtre du policier et charpentier André Labor ?";
			link.l1 = "J'en ai entendu parler...";
			link.l1.go = "NarvalRing_4";
		break;
		case "NarvalRing_4":
			dialog.text = "Bon, ta trouvaille montre clairement qui a fait ça... Et tu connais les « Narvals » ?";
			link.l1 = "Non, Chad. Ils ne laissent entrer personne chez eux. א la moindre occasion, ils attaquent sans discuter.";
			link.l1.go = "NarvalRing_5";
		break;
		case "NarvalRing_5":
			dialog.text = "Oui, c'est vrai. Sur leur territoire, ils peuvent faire ce qu'ils veulent. Ils ont leurs propres lois, là-bas. Sais-tu comment se sont formés les clans ?";
			link.l1 = "Raconte-moi, s'il te plaît. J'écoute avec plaisir.";
			link.l1.go = "NarvalRing_6";
		break;
		case "NarvalRing_6":
			dialog.text = "Hum, bien... Le fait est qu'en plus des gens ordinaires, toutes sortes de racailles échouent dans la Cité. Ils ne peuvent pas vivre en paix avec les autres, c'est pourquoi on a décidé de donner à ces gens deux navires en propriété. א ce moment-là, deux bandes de voyous s'étaient formées, et elles ont constitué les clans des Narvals et des Caspers.";
			link.l1 = "Compris... Que dois-je faire maintenant ? Car au bout du compte, il s'avère que les Narvals sont impliqués dans le meurtre d'un représentant officiel des autorités !";
			link.l1.go = "NarvalRing_7";
		break;
		case "NarvalRing_7":
			dialog.text = "Il est temps de se débarrasser du clan des Narvals, ils m'ont fatigué avec leur sauvagerie.";
			link.l1 = "Sage décision, amiral !";
			link.l1.go = "NarvalRing_8";
		break;
		case "NarvalRing_8":
			dialog.text = "Sans aucun doute ! Et c'est à toi que je confie la tâche.";
			link.l1 = "Hum, qu'est-ce que tu me confies ?";
			link.l1.go = "NarvalRing_9";
		break;
		case "NarvalRing_9":
			dialog.text = "L'anéantissement des « Narvals », "+ GetSexPhrase("l'ami", "ma petite") +". Qui d'autre que toi pourrait mieux s'acquitter de ce travail ? C'est grâce à toi que nous avons découvert la vérité !";
			link.l1 = "Bon sang ! Je ne m'attendais pas du tout à un tel rebondissement...";
			link.l1.go = "NarvalRing_10";
		break;
		case "NarvalRing_10":
			dialog.text = "Allons bon, tu as la frousse ? Tu es capitaine pirate, qu'est-ce qui t'arrive ?!";
			link.l1 = "Ils sont nombreux. Et même si j'ai été capitaine pirate, je ne suis pas suicidaire.";
			link.l1.go = "NarvalRing_11";
		break;
		case "NarvalRing_11":
			dialog.text = "Ah, ça, on va le régler. Je te donne trois de mes hommes pour t'aider.";
			link.l1 = "Bon, ça change tout. J'accepte.";
			link.l1.go = "NarvalRing_12";
		break;
		case "NarvalRing_12":
			dialog.text = "Parfait ! Alors, va tout de suite sur le Velasco et fais du bon travail là-bas. Mes hommes t'attendront sur le Velasco.";
			link.l1 = "D'accord, Chad, je ferai tout au mieux.";
			link.l1.go = "NarvalRing_13";
		break;
		case "NarvalRing_13":
			AddQuestRecord("ISS_MainLine", "12");
			pchar.questTemp.LSC = "toDestoyAllNarval";
			int idxMent;
			pchar.questTemp.LSC.qtyOfficers = 0;
			string sOffName;
			for (i=1 ; i<=3; i++)
			{
				idxMent = GetCharacterIndex("Ment_" + i);
				if (idxMent != -1)
				{
					ChangeCharacterAddressGroup(&characters[idxMent], "LostShipsCity_town", "officers", "officer_"+i);
					characters[idxMent].Dialog.CurrentNode = "OffNarval";
					characters[idxMent].cityTape = "quest"; //тип нпс
					LAi_SetStayTypeNoGroup(&characters[idxMent]);
					pchar.questTemp.LSC.qtyOfficers = sti(pchar.questTemp.LSC.qtyOfficers) + 1;
				}
			}
			pchar.quest.NavalEnterOfficers.win_condition.l1 = "location";
			pchar.quest.NavalEnterOfficers.win_condition.l1.location = "VelascoShipInside1";
			pchar.quest.NavalEnterOfficers.function = "NavalEnterOfficers";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//клан Нарвал уничтожен
		case "DestrNarval_1":
			dialog.text = "Eh bien, c'est bien. Et mes hommes, comment vont-ils ?";
			iTemp = 0;
			for (i=1 ; i<=3; i++)
			{
				if (GetCharacterIndex("Ment_" + i) != -1)
				{
					iTemp++;
				}
			}
			if (iTemp == 0)
			{
				link.l1 = "Ils sont tous morts, malheureusement. Je le regrette vraiment...";
				link.l1.go = "DestrNarval_Bad";
			}
			else
			{
				if (iTemp == sti(pchar.questTemp.LSC.qtyOfficers))
				{
					link.l1 = "Oui, tout va bien. Ils sont tous sains et saufs, je te les rends en un seul morceau.";
					link.l1.go = "DestrNarval_Ok";
				}
				else
				{
					link.l1 = "Il y a des pertes, mais tous n'ont pas été tués. Je te rends les survivants.";
					link.l1.go = "DestrNarval_BadOk";
				}
				DeleteAttribute(pchar, "questTemp.LSC.qtyOfficers");
			}
		break;
		case "DestrNarval_Bad":
			dialog.text = "Oui, c'est triste... Cependant, la mission est accomplie, les Narvals sont anéantis, et c'est l'essentiel. Donc tout va bien.";
			link.l1 = "Eh oui, tout baigne, comme on dit...";
			link.l1.go = "DestrNarval_Bad1";
		break;
		case "DestrNarval_Bad1":
			dialog.text = "Bon, parfait. Je ne te retiens plus, tu peux y aller.";
			link.l1 = "Hum... Eh bien, merci, amiral...";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toTavernNarvalDestroyed";
			AddQuestRecord("ISS_MainLine", "16");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;
		case "DestrNarval_Ok":
			dialog.text = "Parfait ! Pour un travail bien fait, je vais te donner un peu d'argent. Cent mille pièces d'or ! Prends-les, elles sont à toi.";
			link.l1 = "Hum, je n'ai pas encore besoin d'argent ici, mais merci quand même.";
			link.l1.go = "DestrNarval_Ok1";
			AddQuestRecord("ISS_MainLine", "14");
			AddMoneyToCharacter(pchar, 100000);
		break;
		case "DestrNarval_Ok1":
			dialog.text = "De rien ! Bon, je ne te retiens plus, tu peux vaquer tranquillement à tes affaires.";
			link.l1 = "Hum... D'accord.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toTavernNarvalDestroyed";
		break;
		case "DestrNarval_BadOk":
			dialog.text = "Oui, c'est un peu désagréable... Bon, de toute façon, c'était un massacre, pas une petite promenade sur le pont. Dans l'ensemble, je suis content que tout se soit bien terminé. Je veux te donner un peu d'argent pour ton travail. Dix mille pièces d'or !";
			link.l1 = "Bon, on n'a pas vraiment besoin d'argent ici... Mais merci quand même.";
			link.l1.go = "DestrNarval_Ok1";
			AddQuestRecord("ISS_MainLine", "15");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			AddMoneyToCharacter(pchar, 10000);
		break;
		//подслушивание в погребке
		case "Interception":
			sld = characterFromId("Blaze");
			bool bOk = false;
			float fAng;
			GetCharacterAy(sld, &fAng);
			if (fAng > -1.35 && fAng < -0.28) bOk = true;
			if (fAng > 1.8 && fAng < 2.9) bOk = true;
			if (sti(sld.questTemp.LSC.itemState) && bOk)
			{
				dialog.text = "Content de te voir, amiral.";
				link.l1 = "Comment va le clan des Caspers ?";
				link.l1.go = "Interception_1";
				sld.questTemp.LSC = "InterceptionOk";
				sld.questTemp.LSC.knowMechanic = true; //флаг ГГ знает о Механике
			}
			else
			{
				dialog.text = "Content de te voir, amiral.";
				link.l1 = "Silence... On dirait qu'il y a quelqu'un derrière les barreaux. On parlera ailleurs.";
				link.l1.go = "exit";
				sld.questTemp.LSC = "InterceptionYouSeen";
				AddDialogExitQuestFunction("LCS_EndScriptInterception");
			}
		break;
		case "Interception_1":
			sld = characterFromId("Blaze");
			dialog.text = "Pas mal. Surtout depuis que tu as écrasé la concurrence.";
			link.l1 = "Héhé... Tu sais, tout s'est fait tout seul. Je les ai juste montrés du doigt, pour ainsi dire, "+ NPCharSexPhrase(sld, "à cet idiot", "à cette petite insolente") +"...";
			link.l1.go = "Interception_2";
		break;
		case "Interception_2":
			sld = characterFromId("Blaze");
			dialog.text = ""+ NPCharSexPhrase(sld, "Quel idiot ", "Quelle petite insolente ") +" ?";
			link.l1 = "א cette nouvelle recrue, " + GetFullName(sld) + ". Tu as sans doute entendu dire qu'un policier et notre charpentier avaient été tués. Eh bien, cette recrue m'a apporté une amulette des Narvals en me disant l'avoir trouvée sur le lieu du crime. Même si c'était cousu de fil blanc, je ne me suis pas attardé sur cette affaire, car l'occasion se présentait de mettre à exécution mon plan de longue date sans éveiller les soupçons. J'ai envoyé ce « héros » régler leur compte aux Narvals, et quelques policiers avec "+ NPCharSexPhrase(sld, "lui", "lui") +" en renfort.";
			link.l1.go = "Interception_4";
		break;
		case "Interception_4":
		sld = characterFromId("Blaze");
			dialog.text = "Eh bien, que ce « héros » ait travaillé pour toi, c'est parfait. Mais j'espère que tu ne t'es pas confié à "+ NPCharSexPhrase(sld, "lui", "lui") +" au sujet de nos affaires ?";
			link.l1 = "Non, je ne me fie pas à "+ NPCharSexPhrase(sld, "lui", "lui") +". Sur le continent, c'était un capitaine corsaire, et les gens de cette espèce, il faut toujours s'en méfier. C'est une chose de se servir de "+ NPCharSexPhrase(sld, "lui", "lui") +" dans notre intérêt, c'en est une autre de l'associer à nos affaires.";
			link.l1.go = "Interception_5";
		break;
		case "Interception_5":
			dialog.text = "Au fait, à propos de notre affaire. On a déjà amassé beaucoup de choses, mes gars ont hâte de dépenser leur part dans les bordels des Caraïbes. Quand allons-nous commencer les préparatifs pour quitter ce fichu endroit ?";
			link.l1 = "C'est trop tכt, je n'ai pas encore réuni assez d'argent.";
			link.l1.go = "Interception_6";
		break;
		case "Interception_6":
			dialog.text = "Caramba, mes coffres débordent d'argent et d'objets de valeur ! Et ça ne te suffit toujours pas ?!!";
			link.l1 = "N'élève pas la voix avec moi, ou je t'arrache la pomme d'Adam !..";
			link.l1.go = "Interception_7";
		break;
		case "Interception_7":
			dialog.text = "Pardon, amiral, ça ne se reproduira plus...";
			link.l1 = "Tu as intérêt ! Maintenant, écoute bien. L'argent suffit peut-être pour aller au bordel et s'acheter une cabane quelconque, mais j'ai de tout autres projets sur le continent. Je veux devenir gouverneur, et pour ça, je dois aller à Londres et distribuer de l'argent à droite et à gauche sans compter ! Tu comprends maintenant ?";
			link.l1.go = "Interception_8";
		break;
		case "Interception_8":
			dialog.text = "Compris. Mais toi aussi, comprends-nous. דa fait si longtemps qu'on travaille avec toi, qu'on amasse des objets de valeur et de l'argent, et nous n'avons même pas encore commencé à construire un navire ! J'ai du mal à tenir mes hommes.";
			link.l1 = "Et nous ne pourrons pas commencer la construction, car notre charpentier a été tué. Tu peux le dire à tes hommes.";
			link.l1.go = "Interception_9";
		break;
		case "Interception_9":
			dialog.text = "Oui, eh bien, et ils m'ont rassemblé des plans de navires et des outils pour la construction... Et maintenant, que faire ? On devrait peut-être forcer le Mécanicien ?";
			link.l1 = "Je suis contre. Ce fou n'est pas fiable, et avec ses discours délirants, il embrouillerait la cervelle de n'importe qui. Au fait, tes hommes ne communiquent pas avec lui ?";
			link.l1.go = "Interception_10";
		break;
		case "Interception_10":
			dialog.text = "Non, j'y veille strictement. Le Mécanicien ne sort pas de son chenil.";
			link.l1 = "Bien... Alors tu diras à tes hommes que nous commencerons à construire le navire dès qu'un nouveau charpentier arrivera. Héhé, le prochain bמcheron aura de la chance...";
			link.l1.go = "Interception_11";
		break;
		case "Interception_11":
			dialog.text = "Tu lui laisseras la vie ?";
			link.l1 = "Je la lui laisserai, puisque c'est la Loi ! Ha ha ! Bon, je pense que c'est ainsi que nous réglerons les problèmes du moment.";
			link.l1.go = "Interception_12";
		break;
		case "Interception_12":
			dialog.text = "Je pense que tout ira bien.";
			link.l1 = "Parfait. Retourne au clan et garde un œil sur tout.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("LCS_EndScriptInterception");
		break;

		case "BarmenDead_1":
			dialog.text = "Je suis tout ouïe.";
			link.l1 = "Je pense qu'il faudrait mener une enquête.";
			link.l1.go = "BarmenDead_2";
		break;
		case "BarmenDead_2":
			dialog.text = "Hum, bonne idée. Peut-être que tu pourrais aller dès maintenant sur le lieu du meurtre et trouver quelque chose qui nous mettra sur la piste du coupable ? דa ne te dit pas ?";
			link.l1 = "Peut-être bien que j'irai !";
			link.l1.go = "BarmenDead_3";
		break;
		case "BarmenDead_3":
			dialog.text = "Va, "+ GetSexPhrase("mon ami", "ma belle") +", et cherche comme il faut. Seulement, cette fois, je ne serai pas aussi crédule... Tu me comprends ?";
			link.l1 = "Hum, pas vraiment...";
			link.l1.go = "BarmenDead_4";
		break;
		case "BarmenDead_4":
			dialog.text = "Désormais, avant de décider de punir quelqu'un, je mènerai ma propre enquête.";
			link.l1 = "Ah, je comprends maintenant. Une enquête, c'est justement ce que je veux. Tu me tiendras au courant de l'avancée des investigations ?";
			link.l1.go = "BarmenDead_5";
		break;
		case "BarmenDead_5":
			dialog.text = "דa m'étonnerait. Et d'ailleurs, je ne comprends pas bien ton zèle. Vous étiez amis, Hill et toi ? Qu'est-ce qui vous lie ?";
			link.l1 = "Rien de spécial. On discutait, c'est tout...";
			link.l1.go = "BarmenDead_6";
		break;
		case "BarmenDead_6":
			dialog.text = "Si c'est le cas, alors ne t'en mêle pas. Tu n'es rien dans la Cité. Ne te charge pas de trop, tu pourrais te briser les reins. C'est clair ?";
			link.l1 = "Compris, amiral.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toSeekOldCitizen";
			AddQuestRecord("ISS_MainLine", "27");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_MainLine", "sSex2", GetSexPhrase("", "e"));
			pchar.quest.LSC_SaveSesilGalard.win_condition.l1          = "location";
			pchar.quest.LSC_SaveSesilGalard.win_condition.l1.location = "AvaShipInside3";
			pchar.quest.LSC_SaveSesilGalard.function                  = "LSC_SaveSesilGalard";
		break;
		//замочили касперов
		case "CasperDead_1":
			dialog.text = "Quelle coïncidence ! Bon, raconte, que s'est-il passé sur le San Gabriel ?";
			link.l1 = "Eh bien, tu te souviens, tu m'avais dit d'enquêter moi-même sur le meurtre de Hill Brunner ?";
			link.l1.go = "CasperDead_2";
		break;
		case "CasperDead_2":
			dialog.text = "J'ai dit ça, moi ? Tu as perdu la tête ?!";
			link.l1 = "Bon, tu ne m'en as pas chargé, mais tu ne me l'as pas interdit non plus. Alors, avec ta permission, j'ai cherché des preuves. Et j'ai fait un tour sur le « San Gabriel ».";
			link.l1.go = "CasperDead_3";
		break;
		case "CasperDead_3":
			dialog.text = ""+ GetSexPhrase("Imbécile", "Nom d'un chien") +" ! Je ne t'avais pas dit de ne pas y mettre les pieds ?";
			link.l1 = "Non, tu as dit qu'ils avaient leurs propres lois sur le San Gabriel. Je ne savais pas que ces lois étaient si sanguinaires ! Bref, ils se sont jetés sur moi, alors j'ai dמ me défendre...";
			link.l1.go = "CasperDead_4";
		break;
		case "CasperDead_4":
			dialog.text = "Et alors ?";
			link.l1 = "J'ai riposté. Le clan des Caspers n'existe plus... Tout comme le clan des Narvals, d'ailleurs. La Cité est désormais débarrassée des crapules de tout poil !";
			link.l1.go = "CasperDead_5";
		break;
		case "CasperDead_5":
			dialog.text = "Je n'arrive pas à y croire...";
			link.l1 = "Pourquoi y croire ? Tu peux vérifier.";
			link.l1.go = "CasperDead_6";
		break;
		case "CasperDead_6":
			dialog.text = "Mais tu es "+ GetSexPhrase("un vrai diable", "une vraie diablesse") +" ! Tu as massacré deux clans !";
			link.l1 = "J'ose faire remarquer que l'un d'eux, c'était sur ton ordre direct.";
			link.l1.go = "CasperDead_7";
		break;
		case "CasperDead_7":
			dialog.text = "Hum... Tu as trouvé quelqu'un sur le San Gabriel ? א part les Caspers, bien sמr.";
			link.l1 = "Oui. Un homme du nom de Henrik Wedeker t'envoie ses salutations.";
			link.l1.go = "CasperDead_8";
		break;
		case "CasperDead_8":
			dialog.text = "Alors, le Mécanicien est vivant...";
			link.l1 = "Que voulais-tu qu'il lui arrive ? Il ne s'en est pas pris à moi, alors je ne l'ai pas touché...";
			link.l1.go = "CasperDead_9";
		break;
		case "CasperDead_9":
			dialog.text = "Hum, pas touché... וcoute-moi bien, "+ GetSexPhrase("« gros dur »", "ma petite dure à cuire") +" ! Tu m'as vraiment épuisé avec tes frasques. Je suis très en colère contre toi en ce moment et je songe à t'envoyer par le fond, un boulet au cou !";
			link.l1 = ""+ GetSexPhrase("Amiral, je ne le ferai plus !..", "En fait, je faisais le travail de tes policiers fainéants. Les « Caspers » sont des criminels, et moi...") +"";
			link.l1.go = "CasperDead_10";
		break;
		case "CasperDead_10":
			dialog.text = "Tais-toi, "+ GetSexPhrase("abruti", "petite effrontée") +" ! Si tu es encore en vie, c'est uniquement parce que je veux en finir avec cette série de meurtres. Quel que soit le coupable, je ne veux plus mener d'enquête. Admettons que les Caspers soient responsables de tout, et n'en parlons plus. C'est clair ?";
			link.l1 = "Oui, amiral.";
			link.l1.go = "CasperDead_11";
		break;
		case "CasperDead_11":
			dialog.text = "Bien. Tu dois comprendre que désormais, il n'y a plus d'exceptions dans la Cité. Il n'y a plus de clans, donc il n'y a plus de territoires qui échappent à la Loi de la Cité. C'est clair ?";
			link.l1 = "Oui, amiral.";
			link.l1.go = "CasperDead_12";
		break;
		case "CasperDead_12":
			dialog.text = "Si tu touches encore à quelqu'un, ne serait-ce que du bout du doigt...";
			link.l1 = "Amiral, je connais la Loi. Le droit à la vie des citoyens, c'est très juste.";
			link.l1.go = "CasperDead_13";
		break;
		case "CasperDead_13":
			dialog.text = "Gare à toi !.. Dis à Wedeker de rester sur le San Gabriel et de se tenir tranquille. S'il traîne dans la Cité et effraie les gens avec ses sornettes, je le jette derrière les barreaux ! De toute façon, je ferais mieux de lui envoyer quelqu'un de la police. Tu peux disposer.";
			link.l1 = "Merci, amiral ! Honnêtement, je voulais bien faire...";
			link.l1.go = "CasperDead_14";
		break;
		case "CasperDead_14":
			dialog.text = "Dehors !!";
			link.l1 = "Au revoir, Chad.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "seekMillionAndHalf";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Voyons. De quelles marchandises s'agit-il ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de poudre et d'armes.",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Pourquoi ?";
			link.l1 = "Il le faut, amiral...";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Tes manigances avec Wedeker ne te mèneront à rien de bon ! Tu dois respecter les dispositions de la Loi de la Cité.";
			link.l1 = "Je les respecte. Il n'y a rien dans la Loi qui interdise de chercher des armes ou de la poudre.";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Je confisque toutes les armes et la poudre des navires qui arrivent. Tout est dans mon entrepכt, à la résidence.";
			link.l1 = "Tu pourrais peut-être partager ?..";
			link.l1.go = "SeekGoods_4";
		break;
		case "SeekGoods_4":
			dialog.text = "Et pourquoi donc ? Quand je t'ai demandé pourquoi tu en avais besoin, tu n'as pas répondu. Et si tu voulais placer un tonneau de poudre quelque part pour ensuite le faire sauter ?";
			link.l1 = "Allons, amiral, je n'ai pas perdu la raison.";
			link.l1.go = "SeekGoods_5";
		break;
		case "SeekGoods_5":
			dialog.text = "Pour la sécurité de la Cité, je confisque la poudre et les armes. Tu n'auras rien.";
			link.l1 = "Je vois...";
			link.l1.go = "SeekGoods_6";
		break;
		case "SeekGoods_6":
			dialog.text = "Tu sais, les citoyens t'apprécient beaucoup. Sans ça, je crois que j'aurais fait de toi le repas des créatures qui grouillent sous la Cité.";
			link.l1 = "Tu les as vues, ces créatures ?";
			link.l1.go = "SeekGoods_7";
		break;
		case "SeekGoods_7":
			dialog.text = "Personne ne les a vues. Et ceux qui les ont vues les ont regardées pour la dernière fois de leur vie.";
			link.l1 = "Moi, je les ai vues, amiral...";
			link.l1.go = "SeekGoods_8";
		break;
		case "SeekGoods_8":
			dialog.text = "Ah oui ? Oם ça ?";
			link.l1 = "Au fond.";
			link.l1.go = "SeekGoods_9";
		break;
		case "SeekGoods_9":
			dialog.text = "Hum... Maintenant, je sais avec certitude que tu ne dois même pas t'approcher de la poudre. Fréquenter le Mécanicien a un effet néfaste sur ton esprit. Je t'ai à l'œil. Et garde bien en tête qu'à la moindre erreur, je t'enverrai au Tartarus, en prison. Tu me comprends ?";
			link.l1 = "Compris, amiral...";
			link.l1.go = "SeekGoods_10";
		break;
		case "SeekGoods_10":
			dialog.text = "Maintenant, va-t'en, je ne te retiens pas.";
			link.l1 = "D'accord, Chad. Mais tu as tort de réagir ainsi...";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "57");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC.additional.powder = true; //флаг на дачу квеста ментом
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Et alors ?",
				"Nous en avons déjà parlé.",
				"Je ne veux plus rien entendre à ce sujet !",
                "Dehors !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Il y a des raisons de penser que cette tempête sera très violente. Amiral, la Cité risque de s'effondrer.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, bon...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Décidément, tu as perdu la tête...";
			link.l1 = "J'ai toute ma raison, Chad. Mais toi, tu devrais ouvrir les yeux et admettre, d'abord à toi-même, que les choses vont mal.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Quoi ?!!";
			link.l1 = "Tu sais mieux que la plupart des gens ce qu'est la Cité. Elle tient à on ne sait quoi ! Tu mets en danger la vie des gens en leur interdisant d'essayer de partir d'ici.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Tu vas encore me parler de la Cité ! Le Mécanicien est quelqu'un de compétent, mais c'est un lâche et un alarmiste. On a vu tellement de tempêtes ici que ses théories sont devenues ridicules. Je lui ai dit de garder ses idées pour lui...";
			link.l1 = "Et il les garde... וcoute-moi, Chad, ce n'est pas une simple tempête qui arrive ici, c'est un véritable ouragan...";
			link.l1.go = "SeekCrew_4";
		break;
		case "SeekCrew_4":
			dialog.text = "Comment le savez-vous ?";
			link.l1 = "C'est Henrik qui l'a dit. Il a un appareil qui prédit les tempêtes.";
			link.l1.go = "SeekCrew_5";
		break;
		case "SeekCrew_5":
			dialog.text = "J'en ai assez entendu, de ces sornettes du Mécanicien. וcoute bien ce que je vais te dire, "+ GetSexPhrase("l'ami", "ma petite") +". Et je te conseille de bien t'en souvenir, car c'est la dernière fois que je te préviens. Puisque c'est moi l'amiral ici, c'est moi qui déciderai quand nous quitterons la Cité. C'est clair ?";
			link.l1 = "Chad, je ne prétends pas être amiral. Je ne le cacherai pas, autrefois, j'en avais envie... Mais maintenant, c'est une question de vie ou de mort.";
			link.l1.go = "SeekCrew_6";
		break;
		case "SeekCrew_6":
			dialog.text = "Autrefois, tu en avais envie ? Hum, je savais bien que tu ne te calmerais pas...";
			link.l1 = "Amiral, ce n'est pas de ça qu'il s'agit. Il faut sauver notre peau, et il existe un moyen ! Tous tes plans resteront lettre morte si Wedeker a raison.";
			link.l1.go = "SeekCrew_7";
		break;
		case "SeekCrew_7":
			dialog.text = "Héhé, viens encore me parler de mes plans ! Bon, merci pour cette conversation instructive. Et maintenant, tu peux disposer. Et ne t'avise pas d'effrayer les citoyens, sinon je te dévisse la tête ! Garde bien à l'esprit que je ne vais plus te tolérer.";
			link.l1 = "Bon, j'ai fait tout ce que j'ai pu. C'est dommage que tu ne m'écoutes pas...";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "60");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;
		//финальный диалог
		case "fightTalking":
			dialog.text = "Ton temps est écoulé. L'heure de mourir a sonné.";
			link.l1 = "Euh... à vrai dire, je ne m'y attendais pas vraiment...";
			link.l1.go = "fightTalking_1";
		break;
		case "fightTalking_1":
			dialog.text = "Il te reste quelques secondes.";
			link.l1 = "Oם est Wedeker ?";
			link.l1.go = "fightTalking_2";
		break;
		case "fightTalking_2":
			dialog.text = "Tu les as mal utilisées.";
			link.l1 = "Oh, quel dommage...";
			link.l1.go = "fightTalking_3";
		break;
		case "fightTalking_3":
			LAi_LocationFightDisable(loadedLocation, false);
			npchar.SaveItemsForDead = true;
			LAi_SetWarriorTypeNoGroup(NPChar);
			//LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuestFunction("LSC_figtInResidence");
            DialogExit();
		break;

		//освободить мужа Элис Тейлор
		case "ELTHusb_begin":
			dialog.text = NPCStringReactionRepeat("Qu'est-ce que ça peut te faire ?",
				"J'ai déjà tout dit.",
				"Il me semble que nous avons tout éclairci.",
                "Ce que tu peux être bête, "+ GetSexPhrase("l'ami", "ma petite") +" !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Hum... Eh bien, ça m'intéresse.",
				"Oui, oui, je m'en souviens.",
                "Bien sמr.",
				"C'est vrai, c'est idiot de ma part. Pourquoi je redemande la même chose, je ne sais pas...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("ELTHusb_begin_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "ELTHusb_begin_1":
			dialog.text = "Ne t'y intéresse plus. Ce ne sont pas tes affaires.";
			link.l1 = "Eh bien, je fais partie des citoyens de la Cité, pour ainsi dire...";
			link.l1.go = "ELTHusb_begin_2";
		break;
		case "ELTHusb_begin_2":
			dialog.text = "C'est tout. Je ne veux plus parler de ce crétin !";
			link.l1 = "D'accord, amiral, comme tu voudras.";
			link.l1.go = "exit";
		break;

		case "ELTHusb_SF":
			dialog.text = "Eh bien, apporte-lui donc une bouteille de vin...";
			link.l1 = "Héhé, ça, je peux le faire. Il n'y a que moi qui veuille aider à le libérer.";
			link.l1.go = "ELTHusb_SF_1";
		break;
		case "ELTHusb_SF_1":
			dialog.text = "Non, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", ça n'arrivera pas ! דa suffit, toute la Cité en a déjà assez de lui. Il pourrira dans sa cage.";
			link.l1 = "Tu as décidé de le tuer ?";
			link.l1.go = "ELTHusb_SF_2";
		break;
		case "ELTHusb_SF_2":
			dialog.text = "J'en ai le droit ! Mais non, il a simplement écopé de la perpétuité.";
			link.l1 = "Bon sang, qu'est-ce qu'il a fait ? Amiral, dis-le-moi, s'il te plaît.";
			link.l1.go = "ELTHusb_SF_3";
		break;
		case "ELTHusb_SF_3":
			dialog.text = "D'accord, je vais te le dire. Même si je ne comprends pas pourquoi ça t'intéresse. Ce courageux m'a mis un couteau sous la gorge et a exigé qu'on le laisse rentrer immédiatement chez lui, à Plymouth.";
			link.l1 = "וcoute, il était ivre et ne se souvient de rien. Tu ne veux pas te mettre à sa place et lui pardonner ?";
			link.l1.go = "ELTHusb_SF_4";
		break;
		case "ELTHusb_SF_4":
			dialog.text = "Non, n'y compte pas. Et d'ailleurs, j'ai prévenu sa femme, Alice. Un ivrogne et un bagarreur, ça doit être en prison ! Le cure-dent qu'il agitait ici ne m'inquiète pas.";
			link.l1 = "Hum, je pense moi aussi que son couteau, c'est comme une piqמre de moustique pour toi.";
			link.l1.go = "ELTHusb_SF_5";
		break;
		case "ELTHusb_SF_5":
			dialog.text = "Mais ce qui me tracasse, c'est qu'il ne se contrכle pas quand il a bu. Et si demain, après un énième passage à la taverne, il décidait de mettre le feu à un navire ? Bref, Taylor doit être isolé de la société.";
			link.l1 = "Bon sang, on dirait que tu as raison...";
			link.l1.go = "exit";
			pchar.questTemp.LSC.ElisHusband = "toWaitress";
			AddQuestRecord("ISS_ElisHusband", "7");
		break;

		case "ELTHusb_good":
			dialog.text = "Tu commences à me fatiguer...";
			link.l1 = "וcoute, c'est Gilles Barou qui a envoyé Taylor te voir pour une conversation à cœur ouvert.";
			link.l1.go = "ELTHusb_good_1";
		break;
		case "ELTHusb_good_1":
			dialog.text = "Vraiment ?";
			link.l1 = "Oui. Gilles Barou m'a promis de venir te parler et de s'excuser pour cette mauvaise plaisanterie.";
			link.l1.go = "ELTHusb_good_2";
		break;
		case "ELTHusb_good_2":
			dialog.text = "Bon, ça change un peu les choses. Soit, je vais donner à Taylor une nouvelle chance de se ranger.";
			link.l1 = "Amiral, je pense que c'est une très bonne décision.";
			link.l1.go = "ELTHusb_good_3";
		break;
		case "ELTHusb_good_3":
			dialog.text = "J'envoie un policier au Tartarus, et toi, tu peux aller voir Alice et lui dire que je libère Maxim.";
			link.l1 = "Parfait ! C'est ce que je vais faire. Merci, amiral...";
			link.l1.go = "exit";
			pchar.questTemp.LSC.ElisHusband = "toElisGood";
			AddQuestRecord("ISS_ElisHusband", "10");
			sld = characterFromId("MaximTailor");
			ChangeCharacterAddress(sld, "none", "");
		break;
		//квест со скелетом Декстера
		case "LostDecster":
			dialog.text = "Sur qui ?!";
			link.l1 = "Leighton Dexter.";
			link.l1.go = "LostDecster_1";
		break;
		case "LostDecster_1":
			dialog.text = "Hum... Bon, pose ta question.";
			link.l1 = "Oם est-il passé ? Personne ne le sait. Et vous aviez l'air d'être amis...";
			link.l1.go = "LostDecster_2";
		break;
		case "LostDecster_2":
			dialog.text = "Bon, je vais te le dire. Leighton Dexter s'est révélé être un homme très cupide. Il a eu les yeux plus gros que le ventre. C'est pour ça qu'il est puni.";
			link.l1 = "Comment ça, puni ? Oם est-il maintenant ?";
			link.l1.go = "LostDecster_3";
		break;
		case "LostDecster_3":
			dialog.text = "Il garde mon argent.";
			link.l1 = "C'est ça, une punition ?";
			link.l1.go = "LostDecster_4";
		break;
		case "LostDecster_4":
			dialog.text = "Ai-je satisfait ta curiosité, d'une certaine façon ?";
			link.l1 = "Hum... Eh bien, d'une certaine façon.";
			link.l1.go = "LostDecster_5";
		break;
		case "LostDecster_5":
			dialog.text = "Bien. Et maintenant, satisfais la mienne. Pourquoi poses-tu des questions sur Leighton ?";
			link.l1 = "Amiral, rien de spécial. Simple curiosité, rien de plus. J'explore la Cité, je fais connaissance avec les gens...";
			link.l1.go = "LostDecster_6";
		break;
		case "LostDecster_6":
			dialog.text = "Compris. Pour ce qui est de Dexter, j'espère que tu comprends qu'il est occupé. Donc, inutile de le chercher pour faire sa connaissance.";
			link.l1 = "D'accord, amiral, comme tu voudras. Merci pour la conversation.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.lostDecster = "seekBox";
			AddQuestRecord("LSC_findDekster", "5");
		break;

	}
}
