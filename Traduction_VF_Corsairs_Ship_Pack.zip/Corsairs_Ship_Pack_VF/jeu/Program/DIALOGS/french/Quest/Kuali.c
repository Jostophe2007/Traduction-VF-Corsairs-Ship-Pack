
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Авторы Nikk и Sinistra
			dialog.text = "Ishik pas pêcher perles ?";
			link.l1 = "C'est à moi que tu parles ?";
			link.l1.go = "Знакомство_1";
		break;
		
		case "Знакомство_1":
			dialog.text = "Kuali était bon guerrier, pas guerrier stupide.";
			link.l1 = "Il n'y a pas d'imbéciles ici, que me veux-tu ?";
			link.l1.go = "Знакомство_2";
		break;
		
		case "Знакомство_2":
			dialog.text = "Kuali donner son macuahuitl à homme tunaku qui pêche perles, macuahuitl vouloir retour.";
			link.l1 = "Attends, Kuali, c'est toi, et le macuahuitl, c'est ton arme ; et pourquoi l'as-tu donnée ?";
			link.l1.go = "Знакомство_3";
		break;
		
		case "Знакомство_3":
			dialog.text = "Bon guerrier, pas guerrier stupide. Homme tunaku pêcher perles, porter fusil.";
			link.l1 = "Il avait un fusil, donc pas de flèches qui font le tonnerre. Bien sמr, il y avait ici un homme des pêcheries de perles, il t'a menacé d'un fusil et tu lui as donné ton maku-u... Ouf, bon sang, comment ça s'appelle ? Ton arme, et maintenant tu veux que je te la rapporte.";
			link.l1.go = "Знакомство_4";
		break;
		
		case "Знакомство_4":
			dialog.text = "Mali-mali ! Rapporter retour.";
			link.l1 = "Un guerrier pas stupide devrait comprendre que j'ai besoin de quelque chose en échange.";
			link.l1.go = "Знакомство_5";
		break;
		
		case "Знакомство_5":
			dialog.text = "Donner vie.";
			link.l1 = "Tu me laisseras la vie ? דa ne ressemble pas à une menace, dans ta situation ; alors tu donneras la tienne ?";
			link.l1.go = "Знакомство_6";
		break;
		
		case "Знакомство_6":
			dialog.text = "Vie d'Ishik Malov.";
			link.l1 = "Bon, je vais essayer de chercher ton arme, peut-être que tu me donneras vraiment quelque chose de précieux.";
			link.l1.go = "Согласие";
			link.l2 = "Je ne te comprends pas. Courir la jungle pour acheter chat en poche, à chercher je ne sais quel bâton. Non, Kuali, je ne m'en charge pas.";
			link.l2.go = "Отказ";
		break;
		
		case "Отказ":
			DialogExit();
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
			
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
		break;
		
		case "Согласие":
			DialogExit();
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
			
			SetQuestHeader("Kuali");
			AddQuestRecord("Kuali", "1");
			AddQuestUserData("Kuali", "sSex", GetSexPhrase("", "e"));
			
			sld = CharacterFromID("Kuali");
			sld.dialog.filename = "Quest\Kuali.c";
			sld.dialog.currentnode = "ЕщёРаз_1";
			
			pchar.questTemp.Kuali_1 = true;
		break;
		
		case "ЕщёРаз_1":
			dialog.text = "Ishik trouver mon macuahuitl ?";
			link.l1 = "Non.";
			link.l1.go = "exit";
			NextDiag.TempNode = "ЕщёРаз_1";
		break;
		
		case "ВозвращаемПалку_1":
			if (CheckCharacterItem(pchar, "toporAZ"))
			{
				dialog.text = "Nit ola ishik. Je l'ai rapporté, je l'ai rapporté !";
				link.l2 = "Oui, prends-le, et donne-moi ce que tu m'as promis en échange.";
				link.l2.go = "ВозвращаемПалку_2";
				TakeItemFromCharacter(pchar, "toporAZ");
				Log_info("Vous avez remis le macuahuitl");
			}
			else
			{
				dialog.text = "Ishik trouver mon macuahuitl ?";
				link.l1 = "Non.";
				link.l1.go = "exit";
				NextDiag.TempNode = "ВозвращаемПалку_1";
			}
		break;
		case "ВозвращаемПалку_2":
			dialog.text = "Kuali honnête. Donner vie. Toi être compté.";
			link.l1 = "C'est donc ça, tu voulais dire « la santé ». דa fera l'affaire. C'est peut-être un échange honnête. Bonne chance, Kuali.";
			link.l1.go = "ВозвращаемПалку_3";
			
			AddItems(pchar, "talisman15", 1);
			AddItems(pchar, "potion2", 3);
			Log_info("Vous avez reçu l'amulette indienne");
			Log_info("et 3 élixirs de santé");
			PlaySound("Interface\important_item.wav");
			AddCharacterExpToSkill(pchar, "Leadership", 100);
		break;
		case "ВозвращаемПалку_3":
			DialogExit();
			
			PChar.quest.Kuali_EtoNashaPalka.over = "yes";
			AddQuestRecord("Kuali", "6");
			CloseQuestHeader("Kuali");
			pchar.questdata.Kuali = 1;
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
		break;
		
		
	}
}
