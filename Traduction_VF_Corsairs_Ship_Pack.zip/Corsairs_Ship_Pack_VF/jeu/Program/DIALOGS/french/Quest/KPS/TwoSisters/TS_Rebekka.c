// Gregg: the Lus sisters and everything that follows them - "Two Sisters", main branch.
// One file for seven speakers: Rebekka, the onlooker at the door, Hanno Groot, Meril
// Kreno, Muhachi, Mishel and Terry Lorto.
// Logic - Program\Quests\reaction_functions\twosisters.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Autre chose, capitaine ?";
			link.l1 = "Non.";
			link.l1.go = "exit";
		break;

		// The Tortuga brothel
		case "1":
			dialog.text = "Capitaine, ça vous dirait de gagner un peu d'argent ?";
			link.l1 = "דa dépend du travail.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "On a enlevé ma sœur. Mishel Lus, on la connaît ici. Je paierai celui qui la retrouvera.";
			link.l1 = "Vous êtes Rebekka Lus ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Oui. Vous me connaissez ?";
			link.l1 = "On m'a donné deux noms, tous deux Lus. Je suis venu pour vous deux.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "...(méfiante)... Pour nous ? Parlez clairement.";
			link.l1 = "Une maison ouvre à San Juan. On a besoin de quatre femmes. Vous et votre sœur êtes deux d'entre elles.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "On nous l'a déjà proposé, et nous avons refusé. Maintenant, j'accepterais n'importe quoi pour retrouver Mishel. Seule, je n'irai nulle part sans elle.";
			link.l1 = "Racontez-moi tout, dans l'ordre.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Il y a trois nuits, elle est sortie de la maison et n'est jamais revenue. Une voisine l'a vue se faire traîner vers les catacombes.";
			link.l1 = "Traîner par qui ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Deux hommes en longues robes. C'est ainsi qu'elle les a décrits : sans visage, et ils marchaient en silence.";
			link.l1 = "Et personne ne les a suivis ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Dans les catacombes ? ...(avec un sourire sans joie)... Personne ne descend là-dedans, ici, même pour de l'argent. Tout le monde n'en revient pas, et pas toujours en étant resté lui-même.";
			link.l1 = "J'y suis déjà descendu.";
			link.l1.go = "9";
			link.l2 = "Qu'y a-t-il, là-dessous ?";
			link.l2.go = "10";
		break;

		case "9":
			dialog.text = "Alors vous savez. Et vous demandez encore pourquoi personne ne l'a suivie ?";
			link.l1 = "C'est juste. Qu'y a-t-il, là-dessous ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "De vieilles voמtes et des ossements. Un passage vers la plage de l'Œil-de-Poisson, que les contrebandiers empruntent. Et ces hommes en robe aussi.";
			link.l1 = "Quelqu'un a-t-il rendu visite à Mishel ces derniers temps ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Oui. Des gens du même genre, en robe. Elle parlait avec eux pendant des heures, et elle ne m'a jamais dit de quoi.";
			link.l1 = "Alors ce sont les siens qui l'ont emmenée.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "...(doucement)... Les siens. Drכles de siens.";
			link.l1 = "Je vais descendre dans les catacombes.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Si vous la trouvez morte, dites-le-moi tout de suite. Ne m'épargnez pas, je ne survivrai pas à une seconde attente.";
			link.l1 = "Je vous dirai les choses telles qu'elles sont.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Alors allez-y, capitaine. Je serai ici.";
			link.l1 = "...(partir)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestToDungeon");
		break;

		// After the catacombs
		case "15":
			dialog.text = "...(se lève pour vous accueillir)... Alors ? Vous l'avez trouvée ?";
			link.l1 = "J'ai trouvé ceci. Près de la sortie vers la plage de l'Œil-de-Poisson.";
			link.l1.go = "16";
		break;

		case "16":
			TakeNItems(PChar, "TwoSisters_Medallion", -1);
			dialog.text = "...(elle prend le médaillon)... Le sien. Elle ne l'enlevait jamais. C'est donc par là qu'ils l'ont emmenée.";
			link.l1 = "Je n'ai pas trouvé de corps.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Alors elle est vivante. ...(vivement)... Leur navire a quitté l'Œil-de-Poisson la nuit même, je me suis renseignée. Il faut savoir à qui il appartenait.";
			link.l1 = "Comment allez-vous l'apprendre ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Je vais faire le tour de tous ceux qui étaient sur ce rivage. Personne ici ne me refuse rien, capitaine, je suis des leurs.";
			link.l1 = "Combien de temps vous faut-il ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Trois jours. Attendez dans la chambre au-dessus de la taverne, je viendrai vous y trouver.";
			link.l1 = "Trois jours, je les ai.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Merci, capitaine.";
			link.l1 = "Pas encore, il n'y a rien à remercier.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestToTavernRoom");
		break;

		// The tavern room, three days later
		case "24":
			dialog.text = "Capitaine ! Vite, venez avec moi !";
			link.l1 = "Vous avez appris quelque chose sur le navire ?";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Pas sur le navire. L'un d'eux est assis dans ma maison. Je suis entrée, et il fouillait mon coffre.";
			link.l1 = "Et vous l'avez laissé seul là-bas ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "J'ai fermé la porte à clé de l'extérieur. Et j'ai appelé du monde, la moitié de la rue est là maintenant.";
			link.l1 = "Allons-y.";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "La maison est derrière la taverne, en remontant la rue, à gauche. Un petit escalier, et vous tombez droit sur la porte. Je vous rattraperai.";
			link.l1 = "...(y aller)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusToTortugaTown");
		break;

		// The onlooker at the door
		case "28":
			dialog.text = "...(à mi-voix)... Je n'entrerais pas là-dedans, capitaine. Deux y sont déjà entrés.";
			link.l1 = "Et que leur est-il arrivé ?";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Rien du tout. Ils sont entrés, et ils ne sont pas ressortis. דa fait dix minutes.";
			link.l1 = "וcartez-vous de la porte.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestToHouse");
		break;

		// The upstairs room: Hanno Groot over a body
		case "30":
			dialog.text = "...(haletant, appuyé à la table)... Il est fichu. Coriace, que le diable l'emporte.";
			link.l1 = "Qui est fichu ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Celui en robe. Olsen et moi sommes entrés, il s'est détourné du coffre pour nous faire face. Olsen est tombé aussitכt, et moi, il m'a seulement touché.";
			link.l1 = "Vous l'avez tué ?";
			link.l1.go = "32";
		break;

		case "32":
			TakeNItems(PChar, "TwoSisters_AnimistMedallion", 1);
			dialog.text = "Oui. ...(il vous le tend)... Je lui ai pris ça. Un médaillon, lourd. דa vous servira peut-être, à moi, ça ne servira à rien.";
			link.l1 = "Asseyez-vous et ne bougez pas, laissez-moi voir la blessure.";
			link.l1.go = "33";
		break;

		case "33":
			TwoSistersLusQuestToRoomSetAnimist();
			dialog.text = "...(regardant derrière vous)... Capitaine. Derrière vous.";
			link.l1 = "...(se retourner)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestRoomFightWithAnimist");
		break;

		// Five days later, downstairs
		case "34":
			dialog.text = "...(en vous voyant)... Debout. Le chirurgien avait dit une semaine.";
			link.l1 = "Combien de temps suis-je resté à terre ?";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Trois jours. Nous vous avons trouvé à l'étage, à cכté de deux capitaines morts.";
			link.l1 = "Deux ? Et le troisième ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Il n'y avait pas de troisième. De la fumée s'est mise à sortir à flots par la porte, âcre comme celle d'une forge, et quand elle s'est dissipée, il n'y avait plus que vous et ces deux-là.";
			link.l1 = "Vous êtes la seule à avoir vu la fumée ?";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "Toute la rue l'a vue. Et les soldats qui sont accourus aussi.";
			link.l1 = "Il y avait un homme en robe dans cette pièce. Il était étendu par terre avec ma lame plantée en lui.";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "...(secoue la tête)... Il n'y avait personne en robe. Ni vivant, ni mort.";
			link.l1 = "J'ai pris ce médaillon sur lui.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Le médaillon était dans votre main, c'est vrai. Le corps n'y était pas.";
			link.l1 = "Alors il est sorti tout seul.";
			link.l1.go = "40";
			link.l2 = "Alors quelqu'un l'a emporté.";
			link.l2.go = "40";
		break;

		case "40":
			dialog.text = "Ou il a fait le mort et il est parti à la faveur de la fumée. Je le croirais bien, capitaine, sans une chose.";
			link.l1 = "Quelle chose ?";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Hanno Groot l'a frappé deux fois. Je l'ai entendu d'en bas. Après le second coup, on ne se relève pas.";
			link.l1 = "...(se taire)...";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "Rangez cette chose, capitaine. Je ne peux pas la regarder.";
			link.l1 = "Et le navire, vous n'avez rien appris ?";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Rien. Personne n'a rien vu cette nuit-là, et ceux qui ont vu se taisent.";
			link.l1 = "Alors j'irai là oם l'on sait des choses sur ce genre de médaillons.";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Vous devriez rester couché encore une semaine.";
			link.l1 = "Pas le temps.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestNeedMedallionInfo");
		break;

		// Meril Kreno's house in Beliz
		case "56":
			dialog.text = "...(sans se retourner)... Enfin, Casander ! דa fait trois jours que je t'attends !";
			link.l1 = "Je ne suis pas Casander.";
			link.l1.go = "58";
		break;

		case "58":
			dialog.text = "...(il se retourne)... Vraiment ? Et que faites-vous dans ma maison ?";
			link.l1 = "On m'a dit que vous saviez qui porte des médaillons comme celui-ci.";
			link.l1.go = "59";
		break;

		case "59":
			dialog.text = "Qui vous l'a dit ? Peu importe. Je n'ai pas le temps, je prends la mer.";
			link.l1 = "Je paierai pour la conversation.";
			link.l1.go = "60";
		break;

		case "60":
			dialog.text = "J'ai mon propre argent. ...(il fait un geste de la main)... Allez, capitaine, allez.";
			link.l1 = "...(montrer le médaillon)...";
			link.l1.go = "62";
		break;

		case "62":
			dialog.text = "...(il se tait et prend le médaillon)...";
			link.l1 = "Alors, vous savez ou non ?";
			link.l1.go = "63";
		break;

		case "63":
			TwoSistersLusQuestSetCasanderToKrenoHouse();
			dialog.text = "...(lentement)... Je sais. Mais pas ici. Je vous le dirai à bord, en chemin.";
			link.l1 = "א bord de quoi ?";
			link.l1.go = "64";
		break;

		case "64":
			SetCameraDialogMode(CharacterFromID("Captain Casander"));
			dialog.text = "Capitaine Casander : Mes excuses, señor Kreno. Un grain nous a retardés. Nous sommes prêts à appareiller.";
			link.l1 = "...(se retourner)...";
			link.l1.go = "65";
		break;

		case "65":
			SetCameraDialogMode(NPChar);
			dialog.text = "Le voilà. Casander, le capitaine " + GetFullName(PChar) + " part avec nous.";
			link.l1 = "Je n'ai jamais dit que je partais avec vous.";
			link.l1.go = "66";
		break;

		case "66":
			locCameraFollow();
			dialog.text = "Vous le ferez, si vous voulez votre réponse. Le navire est dans la baie de Chetumal ; prenez la route de la jungle, c'est plus court. Je vous rattraperai.";
			link.l1 = "Je serai dans la baie.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestToBelizShore");
		break;

		// Chetumal Bay
		case "67":
			dialog.text = "Et voici le capitaine " + GetFullName(PChar) + ". Venez, la chaloupe est prête.";
			link.l1 = "...(s'approcher)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestCasanderShotPrepare");
		break;

		// The hold of the Cerebus
		case "68":
			dialog.text = "Bienvenue à bord, capitaine " + GetFullName(PChar) + ". Vous avez mal à la tête, j'imagine ?";
			link.l1 = "Vous m'avez tiré dans le dos.";
			link.l1.go = "69";
		break;

		case "69":
			dialog.text = "C'est Casander qui vous a tiré dessus. Je ne l'ai simplement pas arrêté.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "70";
		break;

		case "70":
			dialog.text = "Pas pourquoi, mais dans quel but. Vous rapporterez une rançon. Le propriétaire d'une colonie, ce n'est pas une marchandise bon marché.";
			link.l1 = "Vous savez des choses sur les médaillons. Parlez.";
			link.l1.go = "71";
		break;

		case "71":
			dialog.text = "...(il s'assoit sur un tonneau)... Pourquoi pas. Il n'y a personne ici à qui le répéter.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "72";
		break;

		case "72":
			dialog.text = "Belize est ma ville. J'y ai grandi, et je comptais bien en rester le maître. Pour ça, il fallait de l'argent et des hommes, et des hommes se sont trouvés.";
			link.l1 = "Des hommes en robe.";
			link.l1.go = "73";
		break;

		case "73":
			dialog.text = "Ceux-là mêmes. Ils payaient bien et demandaient peu : ne pas s'en mêler. Alors je ne m'en suis pas mêlé.";
			link.l1 = "Ne pas se mêler de quoi, exactement ?";
			link.l1.go = "74";
		break;

		case "74":
			dialog.text = "De ce qu'ils font aux gens qu'ils emmènent. Je ne l'ai jamais demandé. Il me suffisait qu'on les prenne ailleurs.";
			link.l1 = "Mishel Lus a été enlevée à Tortuga.";
			link.l1.go = "75";
		break;

		case "75":
			dialog.text = "Et elle a fini sur ma liste. Vous savez ce qu'elle avait fait de mal ? Rien. Elle avait simplement une certaine babiole, et cette babiole, on la voulait.";
			link.l1 = "Elle est vivante ?";
			link.l1.go = "76";
		break;

		case "76":
			dialog.text = "Pour l'instant. J'avais besoin d'elle en bonne santé, pas morte.";
			link.l1 = "Et votre conscience est tranquille.";
			link.l1.go = "77";
		break;

		case "77":
			dialog.text = "Tout à fait tranquille. Je n'en transporte pas, comme je ne transporte pas de lest inutile.";
			link.l1 = "Oם va ce navire ?";
			link.l1.go = "78";
		break;

		case "78":
			dialog.text = "דa, je ne vous le dirai pas. ...(il se lève)... Reposez-vous, capitaine. La route est longue.";
			link.l1 = "Vous reviendrez.";
			link.l1.go = "79";
		break;

		case "79":
			dialog.text = "Bien sמr que je reviendrai. Il faut encore que je touche votre rançon.";
			link.l1 = "...(le regarder partir)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestMainHeroStandUpPrepare");
		break;

		// Second anchorage, Kreno comes down again
		case "89":
			dialog.text = "Nous sommes arrivés, capitaine. Une demi-journée au mouillage, puis nous repartons. ...(il regarde la cale autour de lui)... Et je vois que vous n'avez pas perdu votre temps.";
			link.l1 = "Il n'y a rien à faire ici.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestKrenoExitFromShip");
		break;

		// Muhachi
		case "90":
			dialog.text = "Halte, visage pâle. Dis ton nom.";
			link.l1 = "" + GetFullName(PChar) + ". Je ne suis pas avec eux.";
			link.l1.go = "91";
		break;

		case "91":
			dialog.text = "Muhachi sait avec qui tu es. Nous t'avons vu descendre de leur navire, seul et une lame à la main.";
			link.l1 = "Qui êtes-vous ?";
			link.l1.go = "92";
		break;

		case "92":
			dialog.text = "Je suis Muhachi. Voici ma tribu. Notre village se trouve au-delà de la rivière, et des affaires de la tribu, je ne parle pas avec les visages pâles.";
			link.l1 = "Alors de quoi parlons-nous ?";
			link.l1.go = "93";
		break;

		case "93":
			dialog.text = "De ceux qui sont entrés dans la grotte Kretu. Elle est à nous, et maintenant, il y a des hommes en robes noires à l'intérieur.";
			link.l1 = "Ce sont eux que je cherche.";
			link.l1.go = "94";
		break;

		case "94":
			dialog.text = "Alors notre chemin est le même. Aide-nous à les chasser, et Muhachi ne l'oubliera pas.";
			link.l1 = "Ils retiennent une prisonnière qui m'importe. Une femme.";
			link.l1.go = "95";
		break;

		case "95":
			dialog.text = "Ils ont une femme, je l'ai vue. Vivante.";
			link.l1 = "J'accepte.";
			link.l1.go = "96";
		break;

		case "96":
			TakeNItems(PChar, "TwoSisters_MuhachiAmulet", 1);
			dialog.text = "Alors prends ceci. Porte-le jusqu'à la fin du combat.";
			link.l1 = "Laquelle ?";
			link.l1.go = "97";
		break;

		case "97":
			dialog.text = "Un talisman. Il rend leurs médaillons vides.";
			link.l1 = "Que leur donnent ces médaillons ?";
			link.l1.go = "98";
		break;

		case "98":
			dialog.text = "Une protection. Il est difficile de tuer un homme qui en porte un. Plus il le porte longtemps, plus c'est difficile.";
			link.l1 = "J'ai pris un tel médaillon sur un cadavre. Il ne m'a rien donné.";
			link.l1.go = "99";
		break;

		case "99":
			TwoSistersLusQuestMessageIndsar();
			dialog.text = "Et il ne te donnera rien. Tu l'as porté quelques jours. Celui à qui tu l'as pris l'a porté des années.";
			link.l1 = "Alors, on pourrait le porter et devenir intouchable ?";
			link.l1.go = "100";
		break;

		case "100":
			dialog.text = "Non. Le médaillon se fait payer. D'abord la fatigue après le combat, puis la fatigue sans combat, puis l'homme ne se relève plus du tout.";
			link.l1 = "Et ils le savent ?";
			link.l1.go = "101";
		break;

		case "101":
			dialog.text = "Ils le savent. C'est pour ça qu'ils en cherchent de nouveaux quand les anciens ne se relèvent plus.";
			link.l1 = "...(comprenant)... Voilà donc pourquoi ils ont besoin de gens.";
			link.l1.go = "102";
		break;

		case "102":
			SetCameraDialogMode(NPChar);
			dialog.text = "Un homme de la tribu : Muhachi ! Ils arrivent !";
			link.l1 = "Combien ?";
			link.l1.go = "103";
		break;

		case "103":
			locCameraFollow();
			dialog.text = "Beaucoup. Reste près de mes hommes, visage pâle.";
			link.l1 = "Ne touchez pas à la femme.";
			link.l1.go = "104";
		break;

		case "104":
			dialog.text = "Mes hommes ne la toucheront pas. Pour les autres mains, je ne réponds de rien.";
			link.l1 = "...(se préparer)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestFightInJungle");
		break;

		// After the fight
		case "109":
			dialog.text = "Tu t'es bien battu, visage pâle. Muhachi tient parole.";
			link.l1 = "Je n'ai besoin de rien.";
			link.l1.go = "110";
			link.l2 = "Qu'as-tu promis ?";
			link.l2.go = "110";
		break;

		case "110":
			dialog.text = "Que tu en aies besoin ou non, tu le prendras. Nous avons une chose dont nous ne savons que faire.";
			link.l1 = "Quelle chose ?";
			link.l1.go = "111";
		break;

		case "111":
			dialog.text = "Une arme. Longue, lourde, le canon creusé de rainures à l'intérieur. Prise à un visage pâle qui s'était trop approché du village.";
			link.l1 = "Un mousquet rayé.";
			link.l1.go = "112";
		break;

		case "112":
			TakeNItems(PChar, "mushket_Shtuzer", 1);
			dialog.text = "Appelle-le comme tu veux. Mes hommes ne savent pas s'en servir, et toi, tu sauras, si tu sais comment faire. Ce n'est pas pour toutes les mains.";
			link.l1 = "Je sais comment faire.";
			link.l1.go = "113";
		break;

		case "113":
			dialog.text = "Alors prends-le. Et rends-moi mon talisman, visage pâle.";
			link.l1 = "...(à regret)... Je ne peux pas le garder ?";
			link.l1.go = "114";
		break;

		case "114":
			TwoSistersLusQuestRemoveAllAmulets();
			dialog.text = "Non. Il n'est pas à toi, il appartient à la tribu.";
			link.l1 = "Dommage.";
			link.l1.go = "115";
		break;

		case "115":
			TakeNItems(PChar, "MuhachiAmulet", 1);
			dialog.text = "...(avec un rire bref)... Prends celui-ci. Plus faible, mais il ne demande rien en échange. Tes hommes auront la tâche plus facile sous les canons.";
			link.l1 = "Merci, Muhachi.";
			link.l1.go = "116";
		break;

		case "116":
			dialog.text = "Et souviens-toi : n'entre pas dans la grotte Kretu. Ni seul, ni avec tes hommes.";
			link.l1 = "Je n'en avais pas l'intention.";
			link.l1.go = "117";
		break;

		case "117":
			dialog.text = "Si tu en avais eu l'intention, je ne te l'aurais pas dit. ...(il lève la main)... Va, la femme t'attend.";
			link.l1 = "Adieu.";
			link.l1.go = "118";
		break;

		case "118":
			dialog.text = "Ce n'est pas un adieu. Nous nous reverrons, visage pâle, je le sais.";
			link.l1 = "...(partir)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestWaitInJungle");
		break;

		// Mishel Lus
		case "120":
			dialog.text = "...(reculant)... Qui êtes-vous ?";
			link.l1 = "Vous êtes en sécurité. Je vous raconterai le reste à bord, le navire est tout près.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestReturnToCerebus");
		break;

		case "121":
			dialog.text = "Alors, qui êtes-vous ?";
			link.l1 = "Capitaine " + GetFullName(PChar) + ". C'est votre sœur qui m'envoie.";
			link.l1.go = "122";
		break;

		case "122":
			dialog.text = "Rebekka... ...(elle s'assoit par terre)... Alors elle m'a cherchée, finalement.";
			link.l1 = "Pendant trois semaines, elle vous a cherchée. Pourquoi vous a-t-on enlevée ?";
			link.l1.go = "123";
		break;

		case "123":
			dialog.text = "Pour une babiole. Un médaillon, une chose lourde, que l'un d'eux m'avait laissé en gage d'une dette.";
			link.l1 = "Et vous ne l'avez pas rendu.";
			link.l1.go = "124";
		break;

		case "124":
			dialog.text = "Il y a une demi-livre d'or dedans, et ils m'en offraient trente pesos. Bien sמr que non, je ne l'ai pas rendu.";
			link.l1 = "Pour trente pesos, ils ont failli vous tuer.";
			link.l1.go = "125";
		break;

		case "125":
			dialog.text = "...(avec un sourire en coin)... Et vous, vous vendriez votre navire pour deux mille parce que quelqu'un vous l'a demandé poliment ?";
			link.l1 = "Non.";
			link.l1.go = "126";
		break;

		case "126":
			dialog.text = "Vous voyez. ...(plus bas)... Seulement, je croyais qu'ils laisseraient tomber. Au lieu de ça, ils sont venus de nuit, à quatre.";
			link.l1 = "Oם vous emmenait-on ?";
			link.l1.go = "127";
		break;

		case "127":
			dialog.text = "Dans une grotte, pas loin d'ici. Ils m'y ont gardée trois jours, et puis vous êtes arrivé, avec ces hommes armés de lances.";
			link.l1 = "Venez. Un navire nous attend.";
			link.l1.go = "128";
		break;

		case "128":
			dialog.text = "Pour aller oם ? Pas à Belize, je vous en supplie.";
			link.l1 = "א Tortuga, chez votre sœur. Mais d'abord Belize : le brick de Casander et les hommes restés à son bord ont besoin d'un mouillage.";
			link.l1.go = "129";
		break;

		case "129":
			dialog.text = "...(soupire)... Très bien. S'il faut aller à Belize, allons à Belize.";
			link.l1 = "Reposez-vous. La traversée n'est pas longue.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestReturnToBeliz");
		break;

		// The Cerebus cabin
		case "130":
			dialog.text = "...(en voyant sa sœur)... Mishel...";
			link.l1 = "...(s'écarter)...";
			link.l1.go = "131";
		break;

		case "131":
			dialog.text = "Capitaine, je ne sais pas comment vous payer pour ça.";
			link.l1 = "Vous partez toutes les deux pour San Juan. C'est un paiement suffisant.";
			link.l1.go = "132";
		break;

		case "132":
			dialog.text = "Nous partons. ...(fermement)... Et aujourd'hui même, avant que je pense à avoir peur.";
			link.l1 = "Alors préparez-vous.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestComplete");
		break;

		// Terry Lorto in Beliz - the captured brig
		case "133":
			dialog.text = "Capitaine ! ...(fait un signe de la main)... Terry Lorto, canonnier. Casander m'a fait ramer pendant quinze jours.";
			link.l1 = "C'est vous qui avez ramené son brick ?";
			link.l1.go = "134";
		break;

		case "134":
			dialog.text = "Oui. Nous sommes sept restés à bord, tous du même genre. Nous l'avons amené à Belize et nous avons mouillé en rade.";
			link.l1 = "Il est en bon état ?";
			link.l1.go = "135";
		break;

		case "135":
			dialog.text = "Assez bon, seulement il n'y a pas d'équipage pour lui. Sept hommes, ce n'est pas un équipage, c'est une honte.";
			link.l1 = "Vous voulez naviguer sous mes ordres ? Le brick est à vous, vous en serez le capitaine.";
			link.l1.go = "136";
			link.l2 = "Vendez-le ici et partagez l'argent avec les autres.";
			link.l2.go = "137";
		break;

		case "136":
			dialog.text = "...(se redressant)... Oui, capitaine. Et les sept avec moi. Je trouverai des bras ici, à Belize : il y a bien assez d'hommes affamés en rade, et ils viendront pour une part.";
			link.l1 = "Alors rattrapez-moi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestCerebusToSquadron");
		break;

		case "137":
			dialog.text = "Comme vous voudrez. Un navire comme celui-là rapportera quarante-cinq mille, pas plus, il est bien abîmé. Voici votre part.";
			link.l1 = "Prenez le reste et vivez-en.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestCerebusToMoney");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
