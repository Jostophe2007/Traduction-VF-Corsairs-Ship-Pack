// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.mushket2x2") && !CheckCharacterItem(pchar, "mushket2x2"))
			{
				link.l2 = "וcoutez, Rogers, le mot « Arrow » vous dit-il quelque chose ? Il y a peut-être ici un pirate surnommé « Arrow », ou bien un navire pirate de ce nom est venu dans votre port ?";
				link.l2.go = "Mushket";
			}
			if (CheckAttribute(pchar, "GenQuest.CaptainComission") && NPChar.city == pchar.GenQuest.CaptainComission.PiratesCity)
			{
				if(CheckAttribute(pchar, "GenQuest.CaptainComission.toMayor"))
				{
					link.l3 = "Je viens au sujet de votre prisonnier.";
					link.l3.go = "CapComission1";
				}
				if(CheckAttribute(pchar, "GenQuest.CaptainComission.PirateShips"))
				{
					link.l3 = "Bonjour, " + NPChar.name + ", je viens pour votre mission.";
					link.l3.go = "CapComission3";
				}
				if(CheckAttribute(pchar, "GenQuest.CaptainComission.RepeatSpeak"))
				{
					link.l3 = "Je viens au sujet de votre prisonnier.";
					link.l3.go = "CapComission6";
				}
			}
			if (CheckAttribute(pchar, "questTemp.silverfleet") && pchar.questTemp.silverfleet != "over" && pchar.questTemp.silverfleet != "ToHuber" && NPChar.id == "LeFransua_Mayor")
			{
				if(!CheckAttribute(NPChar, "SilverFleetSeaCheck"))
				{
					link.l4 = "Bonjour. Vous avez dמ être prévenu de ma venue. Je viens pour une cargaison de la Barbade vers la Jamaïque...";
					link.l4.go = "SF_LeFransuaBeginning";
				}
				if (GetNpcQuestPastDayParam(NPChar, "SilverFleetSeaCheck") > 0)
				{
					link.l4 = "Au sujet du convoi...";
					link.l4.go = "SF_LeFransuaSeaCheck";
				}
			}
		break;

		case "Mushket":
			dialog.text = "Ah, ce crétin vous a aussi marché sur la queue. Ce navire d'Albert Sievert est un très bon brick, peut-être le meilleur de l'archipel. Pas étonnant que Jackman n'ait pas pu s'en emparer lui-même. Pourquoi en avez-vous besoin ?";
			link.l1 = "Oui, il y a une chose... J'aimerais trouver ce Sievert.";
			link.l1.go = "Mushket_1";
			DeleteAttribute(pchar, "questTemp.mushket2x2");
		break;
		case "Mushket_1":
			dialog.text = "Mais comment allez-vous le trouver ? Il travaille pour son compte, pour personne d'autre, il ne verse sa part à personne, il n'entre pas lui-même dans les ports pirates, pour qu'on ne l'oblige pas à partager, et on ne le laisse pas entrer dans les ports des colonies. Enfin, si, on l'y attend, bien sמr, pour lui passer la corde au cou, mais il ne prendra pas de risques : ce n'est pas son genre.";
			link.l1 = "Ouais... Vous pouvez me conseiller quelque chose ?";
			link.l1.go = "Mushket_2";
		break;
		case "Mushket_2":
			dialog.text = "Il y a un homme qui faisait équipe avec ce Sievert. Mais ça n'a pas collé : soit Sievert l'a laissé par-dessus bord, soit l'inverse. Ils sont tous les deux du même tonneau, sinon ils ne se seraient sans doute pas associés. Ce gars tient maintenant une taverne à Portobelo ; il s'appelle Rolando Pizarro, ou tout simplement le Renard. Il connaît peut-être ses mouillages. Et puis, cherchez ce brick en mer, vous ne le confondrez avec aucun autre. Faites juste attention : il est vraiment fou...";
			link.l1 = "Je vois. Eh bien, merci, Bartholomew.";
			link.l1.go = "exit";
			pchar.questTemp.mushket2x2_stid = true;
			AddQuestRecord("SeekDoubleMushket", "2");
		break;

		case "CapComission1":
			dialog.text = "Ho ho. Vous croyez que je n'ai qu'un seul prisonnier ? Dites-moi qui exactement vous avez en tête.";
			link.l1 = pchar.GenQuest.CaptainComission.SlaveName + ". Il est chez vous ?";
			link.l1.go = "CapComission2";
		break;

		case "CapComission2":
			DeleteAttribute(pchar, "GenQuest.CaptainComission.toMayor");
			if(CheckAttribute(pchar, "GenQuest.CaptainComission.DaysLeft"))
			{
				dialog.text = "Il y était. Je l'ai vendu à ce maudit planteur de la Barbade, le colonel Bishop, qui est passé la semaine dernière.";
				link.l1 = "Bon sang...";
				link.l1.go = "CapComission2_1";
			}
			else
			{
				pchar.quest.CaptainComission_SellSlave.over = "yes";
				dialog.text = "Ah, enfin. Je pensais le vendre à ce maudit planteur de la Barbade, il doit passer d'ici une ou deux semaines... Vous avez apporté la rançon ?";
				link.l1 = "וcoutez, "+ NPChar.name +", voilà l'affaire... En somme, je n'ai pas assez d'argent. Mais je suis prêt à payer de ma personne.";
				link.l1.go = "CapComission2_2";
				if(makeint(pchar.money) > 150000)
				{
					link.l2 = "Heureusement que vous ne l'avez pas fait. Voici 150000 pièces d'or. Oם puis-je le récupérer ?"
					link.l2.go = "CapComission2_3";
				}
			}
		break;

		case "CapComission2_1":
			dialog.text = "Vous avez parlé trop longtemps... Au fait, quel lien avez-vous avec cet esclave ? Je me souviens avoir demandé une rançon à sa famille.";
			link.l1 = "Oui, je viens de la part de sa famille.";
			link.l1.go = "CapComission2_11";
		break;

		case "CapComission2_11":
			dialog.text = "Eh bien, vous arrivez trop tard, que voulez-vous que j'y fasse ?";
			link.l1 = "Dites-moi, combien l'avez-vous vendu, si ce n'est pas un secret ?";
			link.l1.go = "CapComission2_12";
		break;

		case "CapComission2_12":
			dialog.text = "Euh, ce n'est pas un secret, bien sמr, mais je ne vous le dirai pas. Sinon, vous allez rire, ha ha ha ha... Bon, salut.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission1", "10");
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			CaptainComission_GenerateManager();
		break;

		case "CapComission2_2":
			if(rand(1) == 0)
			{
				dialog.text = "Hum hum... J'ai bien une affaire... Je ne sais même pas par oם commencer... En somme, il faut couler un pirate arrogant.";
				link.l1 = "On ne pourrait pas le supprimer dans la jungle ?";
				link.l1.go = "CapComission2_2_1";
			}
			else
			{
				dialog.text = "Alors, " + pchar.name + ", vous savez bien que ce n'est pas comme ça qu'on fait. Revenez avec l'argent, et vous aurez votre petit protégé, héhé.";
				link.l1 = "Eh bien, à plus tard.";
				link.l1.go = "exit";
				if(!CheckAttribute(pchar, "GenQuest.CaptainComission.RepeatSpeak"))
				{
					AddQuestRecord("CaptainComission1", "31");
					AddQuestUserData("CaptainComission1", "sName",  pchar.GenQuest.CaptainComission.PirateName);
				}
				pchar.GenQuest.CaptainComission.RepeatSpeak = true;
			}
		break;

		case "CapComission2_2_1":
			dialog.text = "Eh bien, vous savez, ce n'est pas comme ça qu'on règle les affaires sérieuses... Je n'ai pas besoin de sa mort, je dois décourager les trop zélés de lorgner ma part du butin. Quoique, s'il finit chez les poulpes, je n'en serai pas chagriné.";
			link.l1 = "Pourquoi n'envoyez-vous pas vos hommes à ses trousses ?";
			link.l1.go = "CapComission2_2_2";
		break;

		case "CapComission2_2_2":
			CaptainComission_GetRandomShore();
			pchar.GenQuest.CaptainComission.ShipName1 = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.GenQuest.CaptainComission.ShipName2 = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.GenQuest.CaptainComission.UnknownPirateName = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			string sLoc = XI_ConvertString(pchar.GenQuest.CaptainComission.Island + "Abl");
			dialog.text = "Hum... En somme, un certain " + GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.UnknownPirateName, NAME_NOM) + " a convaincu quelques pirates que dans notre cachette, près de " + XI_ConvertString(pchar.GenQuest.CaptainComission.Island.Shore + "Gen") + " se trouve aussi leur part. Ils ont récemment levé l'ancre sur deux navires, '" + pchar.GenQuest.CaptainComission.ShipName1 + "' et '" + pchar.GenQuest.CaptainComission.ShipName2 + "', cap sur " + sLoc + ". Vous comprenez maintenant pourquoi je ne peux pas confier cette affaire à mes hommes ?";
			link.l1 = "Compris. Et de combien de temps est-ce que je dispose ?";
			link.l1.go = "CapComission2_2_3";
		break;

		case "CapComission2_2_3":
			dialog.text = "Je pense 12 à 15 jours, pas plus. Il m'importe qu'ils n'aient pas le temps d'atteindre la cachette, sinon il n'y aura plus aucun intérêt à les couler avec une cargaison de valeur à bord. Mieux vaut qu'ils l'amènent ici.";
			link.l1 = "D'accord, je prends cette affaire. Je vais essayer d'arriver à temps.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission1", "24");
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.PirateName);
			AddQuestUserData("CaptainComission1", "sShipName1", pchar.GenQuest.CaptainComission.ShipName1);
			AddQuestUserData("CaptainComission1", "sShipName2", pchar.GenQuest.CaptainComission.ShipName2);
			AddQuestUserData("CaptainComission1", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.Island.Shore + "Abl"));
			AddQuestUserData("CaptainComission1", "sShoreType", XI_ConvertString(GetIslandByArealName(pchar.GenQuest.CaptainComission.Island) + "Voc"));
			pchar.quest.CapComission_PirateAttack.win_condition.l1 = "location";
            pchar.quest.CapComission_PirateAttack.win_condition.l1.location = pchar.GenQuest.CaptainComission.Island;
            pchar.quest.CapComission_PirateAttack.function = "CaptainComission_GeneratePirateShips";
			SetFunctionTimerCondition("CaptainComission_PirateShipsOver", 0, 0, 15, false);
			pchar.GenQuest.CaptainComission.PirateShips = "goaway";
		break;

		case "CapComission2_3":
			dialog.text = "Ne vous inquiétez pas. Mes hommes vous l'amèneront à bord... Qui est-il pour vous ?";
			link.l1 = "Personne. Je rends service à un membre de sa famille.";
			link.l1.go = "CapComission2_31";
		break;

		case "CapComission2_31":
			dialog.text = "Ah, très bien. J'étais déjà contrarié d'avoir bradé votre homme à si bas prix. Ha ha ha ha... Bon, salut.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission1", "9");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City));
			addMoneyToCharacter(pchar, -150000);
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission3":
			dialog.text = "Alors, " + GetFullName(pchar) + ", vous avez envoyé mon ami par le fond ? Hé hé hé...";
			if(pchar.GenQuest.CaptainComission.PirateShips == "goaway")
			{
				link.l1 = "Non. Je n'ai pas eu le temps de les rattraper. Et je ne les ai pas croisés sur le chemin du retour.";
				link.l1.go = "CapComission4";
			}
			else
			{
				if(pchar.GenQuest.CaptainComission.PirateShips == "died")
				{
					link.l1 = "Oui, comme convenu : je l'ai envoyé nourrir les requins.";
					link.l1.go = "CapComission5";
				}
			}
			DeleteAttribute(pchar, "GenQuest.CaptainComission.PirateShips");
		break;

		case "CapComission4":
			dialog.text = "Bon sang ! Rattrapés ou pas, quelle différence maintenant ? Alors, que proposez-vous ensuite ?";
			link.l1 = "Vous n'auriez pas une mission plus simple ?";
			link.l1.go = "CapComission4_1";
			link.l2 = "וcoutez, " + npchar.name + ", cédez-moi ce prisonnier moins cher...";
			link.l2.go = "CapComission4_2";
		break;

		case "CapComission4_1":
			dialog.text = "Non.";
			link.l1 = "...Eh bien, alors, portez-vous bien...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -2);
			AddQuestRecord("CaptainComission1", "27");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_DAT));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar, "GenQuest.CaptainComission.PirateShips");
		break;

		case "CapComission4_2":
			dialog.text = "Moins cher ?!! C'est à cause de votre lenteur que j'ai perdu ma cachette ! Et maintenant, je peux le céder plus cher !! Prenez-le pour 200 000 si vous voulez.";
			link.l1 = "C'est cher... Au revoir...";
			link.l1.go = "CapComission4_4";
			if(sti(pchar.money) >= 200000)
			{
				link.l2 = "Bon sang, tenez, voilà votre argent.";
				link.l2.go = "CapComission4_5";
			}
		break;

		case "CapComission4_4":
			ChangeCharacterReputation(pchar, -2);
			AddQuestRecord("CaptainComission1", "28");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar, "GenQuest.CaptainComission.PirateShips");
			DialogExit();
		break;

		case "CapComission4_5":
			dialog.text = "Vous pouvez emmener le crève-la-faim...";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			addMoneyToCharacter(pchar, -200000);
			AddQuestRecord("CaptainComission1", "29");
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar, "GenQuest.CaptainComission.PirateShips");
			pchar.GenQuest.CaptainComission.SlaveAddMoney = true;
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission5":
			dialog.text = "Ho ho ! Voilà du travail ! Prenez votre petit protégé et portez-vous bien.";
			link.l1 = "Merci. Portez-vous bien.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission1", "34");
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar, "GenQuest.CaptainComission.PirateShips");
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission6":
			dialog.text = "Vous avez apporté la rançon ? Je ne plaisantais pas quand j'ai dit que je le vendrais aux planteurs.";
			link.l1 = "וcoutez, "+ NPChar.name +", voilà l'affaire... En somme, je n'ai pas assez d'argent. Mais je suis prêt à payer de ma personne.";
			link.l1.go = "CapComission2_2";
			if(makeint(pchar.money) > 150000)
			{
				link.l2 = "Heureusement que vous ne l'avez pas fait. Voici 150 000 pièces d'or. Oם puis-je le récupérer ?"
				link.l2.go = "CapComission2_3";
			}
		break;
		case "SF_LeFransuaBeginning":
			dialog.text = "Oui, oui, on m'a prévenu. Mais je ne vous dirai pas grand-chose. Mes supérieurs directs s'intéressent à ce convoi... Je ne vous donnerai donc pas de tuyau détaillé, mais je vous donnerai quelques informations.";
			link.l1 = "Merci pour ça. Alors, qu'avez-vous à dire ?";
			link.l1.go = "SF_LeFransuaSeaCheck";
			pchar.questTemp.silverfleet.lefransuamayorspeak = true;
		break;

		case "SF_LeFransuaSeaCheck":
			dialog.text = "En ce moment, le Convoi d'argent n'est pas en route. Il y aura peut-être de nouvelles informations demain.";
			if (CheckExistQuestEncounter("Head_of_Silver_Squadron")) dialog.text = "En ce moment, le Convoi d'argent fait route vers la Jamaïque. Je ne peux pas être plus précis, désolé. Il y aura peut-être plus d'informations demain.";
			if (GetNpcQuestPastDayWOInit(pchar, "SilverFleetGo") < 3) dialog.text = "Tout récemment, le « Convoi d'argent » a été aperçu près de la Barbade. Vous savez oם il se dirigeait.";
			link.l1 = "Compris. Merci.";
			link.l1.go = "exit";
			SaveCurrentNpcQuestDateParam(NPChar, "SilverFleetSeaCheck");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
