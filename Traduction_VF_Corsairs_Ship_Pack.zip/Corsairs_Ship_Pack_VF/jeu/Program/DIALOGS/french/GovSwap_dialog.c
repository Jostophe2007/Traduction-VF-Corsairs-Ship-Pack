// Cargo swap - governor freight fork. Dealer in the origin port ("First time") offers the swap;
// the customs inspector at delivery ("Inspector_Check") checks the cargo, then WITHOUT a re-click
// the word passes to the governor (GovSwap_AfterInspector -> Common_Mayor.c node GovFreight_SwapResult).
// Logic - scripts/GovSwap.c. Rolls are baked at take-time (quests_reaction.c).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		//============ THE DEALER (origin port) ============
		case "First time":
			dialog.text = RandPhraseSimple(
				"(à voix basse, en vous rattrapant) Un mot, capitaine. Vous transportez une commande d'וtat pour Son Excellence ? C'est une mine d'or, et vous ne le savez même pas. Voici le marché : la vraie marchandise me revient, et vous remettez à la résidence une camelote bon marché sous le même manifeste. Le commis du gouverneur n'y verra que du feu.",
				RandPhraseSimple(
					"(se met à marcher à votre cכté, à voix basse) Ne vous retournez pas, capitaine, écoutez seulement. Vous avez une cargaison d'וtat dans votre cale, je le sais. Cédez-la-moi, et livrez au gouverneur quelque chose de moins cher sous le même sceau. Les papiers concorderont, personne ne regardera.",
					"(crache, baisse la voix) Capitaine, il y a de l'argent à se faire. La commande de Son Excellence, c'est de l'or pur. La vraie marchandise pour moi, un ersatz bon marché pour la résidence. Le vieux commis ne fait plus la différence sous un sceau d'וtat depuis des années."
				)
			) + " Pour votre peine, je vous paie " + FindRussianMoneyString(GovSwap_Bonus()) + " tout de suite. Marché conclu ?";
			link.l1 = "Marché conclu. Prenez la marchandise. (" + FindRussianMoneyString(GovSwap_Bonus()) + ")";
			link.l1.go = "GovSwap_Accept";
			link.l2 = "Non. Je livrerai la cargaison d'וtat telle quelle.";
			link.l2.go = "GovSwap_Decline";
			NextDiag.TempNode = "First time";
		break;

		case "GovSwap_Accept":
			GovSwap_DoSwap();
			AddDialogExitQuestFunction("GovSwap_DealerLeave");
			dialog.text = RandPhraseSimple(
				"Voilà qui est parlé ! Mes hommes récupéreront la marchandise cette nuit, et vous recevrez des marchandises ordinaires, moins chères, sous le sceau d'וtat. Remettez-les sans crainte : si la douane ne fourre pas son nez dedans, personne n'en saura rien. Bon vent, capitaine.",
				"Sage décision, capitaine. Au matin, un ersatz sera à la place de votre cargaison : impossible à distinguer, tant que personne ne l'ouvre. Et il y a peu de chances qu'on le fasse. Voici la somme convenue ; maintenant, filez."
			);
			link.l1 = "א la revoyure.";
			link.l1.go = "exit";
		break;

		case "GovSwap_Decline":
			AddDialogExitQuestFunction("GovSwap_DealerLeave");
			dialog.text = RandPhraseSimple(
				"L'honnêteté coמte cher de nos jours... dommage. Enfin, c'est votre choix, capitaine. Il y avait un profit à faire, mais comme vous voudrez.",
				"Comme vous voulez. Seulement, ne vous en mordez pas les doigts plus tard, capitaine : des commandes pareilles ne se présentent pas deux fois. Bon voyage."
			);
			link.l1 = "Adieu.";
			link.l1.go = "exit";
		break;

		//============ THE CUSTOMS INSPECTOR (check at delivery) ============
		// after this dialog the word passes to the governor (GovSwap_AfterInspector) - no need to re-click the mayor
		case "Inspector_Check":
			AddDialogExitQuestFunction("GovSwap_AfterInspector");
			if (CheckAttribute(pchar, "CargoQuest.GovSwapCaught"))
			{
				pchar.CargoQuest.GovSwapInspected = "caught";
				dialog.text = RandPhraseSimple(
					"(examine attentivement la cargaison, compare les cachets et le poids avec le manifeste, et fronce les sourcils) ...Et ceci, capitaine, ne correspond pas à ce qu'indique le manifeste de Son Excellence. Une substitution.",
					"(fait le tour de la cargaison, la tapote, vérifie le registre et secoue la tête) Les cachets ne sont pas les bons, le poids ne correspond pas. Ce n'est pas la cargaison d'וtat, capitaine. Une substitution, et grossière."
				) + " Vous vous expliquerez, non pas devant moi, mais devant le gouverneur.";
				link.l1 = "(ne rien dire)";
				link.l1.go = "exit";
			}
			else
			{
				pchar.CargoQuest.GovSwapInspected = "passed";
				dialog.text = RandPhraseSimple(
					"(jette un coup d'œil à la cargaison, vérifie son papier) Hum... tout est en ordre, la marchandise correspond. Allez voir Son Excellence pour votre paiement, capitaine.",
					"(longe la cargaison, vérifie deux ou trois cachets, hoche la tête) Tout est conforme au registre, capitaine. Allez chercher votre paiement auprès de Son Excellence."
				);
				link.l1 = "Merci pour votre zèle.";
				link.l1.go = "exit";
			}
		break;
	}
}
