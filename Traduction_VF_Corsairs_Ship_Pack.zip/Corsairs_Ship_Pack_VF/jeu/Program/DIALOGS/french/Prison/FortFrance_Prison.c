// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
            dialog.text = "Parlez, je vous écoute.";
			link.l1 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Adieu.";
			link.l1.go = "Exit";
			if (CheckAttribute(pchar, "questTemp.PDM_PJ_SS"))
			{
				link.l1 = "J'ai une affaire pour vous, officier. Je pense qu'elle vous intéressera. L'un de vos soldats, Jory, a essayé d'acheter du vin en ville par mon intermédiaire. Connaissant vos habitudes...";
				link.l1.go = "PDM_PJ_SS_1";
			}
		break;
		
		case "PDM_PJ_SS_1":
			dialog.text = "Quoi ?! J'ai strictement interdit de boire dans les installations stratégiques ! Eh bien, il va le payer. Pour votre vigilance, je vous récompense de 5 000 pièces d'or, et Jory ira trois jours au cachot.";
			link.l1 = "Merci, " + GetFullName(NPChar)+". Il est de notre devoir commun de mettre fin à de telles infractions.";
			link.l1.go = "PDM_PJ_SS_2";
			DeleteAttribute(pchar, "questTemp.PDM_PJ_SS");
			DeleteAttribute(pchar, "questTemp.PDM_PJ_KV");
			AddMoneyToCharacter(pchar, 5000);
		break;
		
		case "PDM_PJ_SS_2":
			DialogExit();
			sld = CharacterFromID("PDM_PJ_Strajnik_1")
			LAi_SetLoginTime(sld, 0.0, 24.0);
			sld = CharacterFromID("PDM_PJ_Strajnik_2")
			LAi_SetLoginTime(sld, 0.0, 24.0);
			bDisableFastReload = true;
			chrDisableReloadToLocation = true;
			LAi_SetActorType(pchar);
			DoQuestReloadToLocation("FortFrance_town", "goto", "goto2", "PDM_PJ_Arest_0");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
