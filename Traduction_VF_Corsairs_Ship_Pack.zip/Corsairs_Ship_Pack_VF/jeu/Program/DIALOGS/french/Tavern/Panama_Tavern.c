// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> проверка на квесты
			if (CheckAttribute(pchar, "questTemp.State.Store"))
            {
                link.l1 = "Dites, savez-vous quelque chose sur un marchand hollandais nommé Jacob Lopez de Fonseca ?";
                link.l1.go = "Step_S2_1";
            }
			if (pchar.questTemp.Slavetrader == "FindRatPanama")
            {
                link.l1 = "Dites, on dit qu'il y avait un corsaire en ville, François Gontier. Savez-vous oם je peux le trouver ?";
                link.l1.go = "Panama_rat_1";
            }
            // <== проверка на квесты
		break;
//*************************** Квест №2 испанки, задание Инквизиции ***************************
 		case "Step_S2_1":
			dialog.text = NPCStringReactionRepeat("Non, je n'ai rien vu ni entendu de tel ici.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Yakov.", "וcoutez, reculez et ne me gênez pas ! Vous avez perdu la boule ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Eh bien, merci.", "Hum, en effet...", "Oui, exactement, "+ GetSexPhrase("posé la question", "posé la question") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
		//-->работорговец
		case "Panama_rat_1":
			dialog.text = NPCStringReactionRepeat("Oui, nous avions ce type en ville. Il se cachait dans les coins sombres... Puis des amis sont venus le voir, de vraies têtes de brutes, et il a quitté la ville avec eux.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Gontier.", "וcoutez, reculez et ne me barrez pas la route ! Vous avez perdu la boule ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez oם il est allé ?", "Hum, en effet...", "Oui, exactement, "+ GetSexPhrase("posé la question", "posé la question") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "Panama_rat_2";
		break;

		case "Panama_rat_2":
			dialog.text = "Eh bien, d'ici, il n'y a qu'une seule route à pied : vers Portobelo. Et il est parti à pied. Alors cherchez-le là-bas.";
			link.l1 = "Merci, vous m'avez beaucoup aidé !";
			link.l1.go = "exit";
			pchar.questTemp.Slavetrader = "FindRatPortobello";
			AddQuestRecord("Slavetrader", "21_1");
		break;
		//<--работорговец


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

