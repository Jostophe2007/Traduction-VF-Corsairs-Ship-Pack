// Gregg: диалоги квеста "Легенда о призрачном свете" (перенос из К:ПС).
// Клейн на Бермудах, его связной в Бас-Тере, Адам Кромвель, Фрэнсис Айво,
// Джейк Смитт и Педро Карлос в гроте Невиса.
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: у каждого свой отбой. Гард по MoonStone тут не нужен - узел
			// достижим только пока квест идёт, но проверку id оставляем как в оригинале.
			if (NPChar.id == "Adam Kromvel")
			{
				dialog.text = "Ne me dérangez pas.";
				if (pchar.MoonStone == "3") dialog.text = "Je vous attendrai hors de la ville. N'oubliez pas de vous confesser.";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "exit";
				break;
			}
			if (NPChar.id == "Klein Man")
			{
				dialog.text = "Vous avez fait votre travail ? Non ? Alors allez le faire.";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "exit";
				break;
			}
			if (NPChar.id == "Klein")
			{
				dialog.text = "Vous n'avez pas compris ? Prenez la mer et mettez le cap sur la Martinique.";
				link.l1 = "...";
				link.l1.go = "exit";
				break;
			}
			NextDiag.TempNode = "First time";
		break;

		case "Adam_Kromvel_1":
			dialog.text = "Qui diable êtes-vous ?! Sortez d'ici !";
			link.l1 = "Oh, voilà que vous m'avez insulté deux fois. Je vous provoque en duel !";
			link.l1.go = "Adam_Kromvel_2";
		break;

		case "Adam_Kromvel_2":
			dialog.text = "Euh... hum... J'accepte le défi. Mais quelle est la deuxième raison ?";
			link.l1 = "Vous avez regardé ma femme d'une manière déplacée. Je vous attendrai hors de la ville.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			AddDialogExitQuestFunction("MoonStoneToSentJonsExit");
		break;

		case "Adam_Kromvel_3":
			dialog.text = "Ah, vous êtes venu. On commence ?";
			link.l1 = "Un instant. Je suis curieux : qui avez-vous offensé au point qu'on envoie un assassin ?";
			link.l1.go = "Adam_Kromvel_4";
		break;

		case "Adam_Kromvel_4":
			dialog.text = "Alors tu es l'un de ces porcs ?! Meurs !";
			link.l1 = "Eh bien...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneFightWithKromvel");
		break;

		case "Francis_Ayvo_1":
			dialog.text = "Et toi, apparemment, tu es le tueur à gages ? Meurs !";
			link.l1 = "Attendez !..";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneFightWithAjvoGardian");
		break;

		case "Francis_Ayvo_2":
			dialog.text = "Aaah, vous l'avez tué !";
			link.l1 = "Taisez-vous, ou vous serez le suivant.";
			link.l1.go = "Francis_Ayvo_3";
		break;

		case "Francis_Ayvo_3":
			dialog.text = "D'accord... j-je me tais. M-mais qui êtes-vous ?";
			link.l1 = "Peu importe. Dites-moi plutכt qui vous avez offensé.";
			link.l1.go = "Francis_Ayvo_4";
		break;

		case "Francis_Ayvo_4":
			dialog.text = "N-n'importe qui. Vous d-devez mieux le savoir : vous êtes venu me t-tuer.";
			link.l1 = "Arrêtez de bégayer. Je veux votre version.";
			link.l1.go = "Francis_Ayvo_5";
		break;

		case "Francis_Ayvo_5":
			dialog.text = "Je b-bégaie depuis ma naissance. Et seule cette c-confrérie d'assassins pouvait vouloir ma m-mort...";
			link.l1 = "א partir de là, plus en détail.";
			link.l1.go = "Francis_Ayvo_6";
		break;

		case "Francis_Ayvo_6":
			dialog.text = "Tout a c-commencé quand cette c-confrérie est arrivée aux Caraïbes. Ils t-tuent pour de l'argent et n'épargnent p-personne.";
			link.l1 = "Et vous savez quelque chose sur Jake Smitt ?";
			link.l1.go = "Francis_Ayvo_7";
		break;

		case "Francis_Ayvo_7":
			dialog.text = "C-c'est leur chef.";
			link.l1 = "Très bien. Maintenant, parlez-moi plutכt de la pierre de lune.";
			link.l1.go = "Francis_Ayvo_8";
		break;

		case "Francis_Ayvo_8":
			dialog.text = "N-non ! Je préférerais m-mourir !";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneFightWithAjvo");
		break;

		case "Claine_0":
			MoonStoneToBermudesTavernTalk();
			dialog.text = "Et vous, qui êtes-vous ? Puis-je connaître votre nom ?";
			link.l1 = "Nathan Rich. ...(montre l'amulette)...";
			link.l1.go = "Claine_2";
		break;

		case "Claine_1":
			dialog.text = "Et vous, qui êtes-vous ? Puis-je connaître votre nom ?";
			link.l1 = "Nathan Rich. ...(montre l'amulette)...";
			link.l1.go = "Claine_2";
		break;

		case "Claine_2":
			dialog.text = "Je vous attendais. Oם étiez-vous passé ?";
			link.l1 = "Pardonnez-moi. Une affaire urgente s'est présentée.";
			link.l1.go = "Claine_3";
		break;

		case "Claine_3":
			dialog.text = "Très bien. Mes excuses de ne pas avoir mis vos amis dans la confidence tout de suite. Oם sont-ils, d'ailleurs ?";
			link.l1 = "Eux aussi ont eu une affaire urgente, et ils ne se joindront pas à nous. Venons-en au fait.";
			link.l1.go = "Claine_4";
		break;

		case "Claine_4":
			dialog.text = "Au fait, donc. Je dois me rendre à Fort-de-France.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			AddDialogExitQuestFunction("MoonStoneToFortFrance");
		break;

		case "Claine_5":
			dialog.text = "Ce n'est pas pour rien qu'on vous disait bon capitaine.";
			link.l1 = "Vous me flattez.";
			link.l1.go = "Claine_6";
		break;

		case "Claine_6":
			dialog.text = "Assez. Aux affaires. Réglez vos affaires, et dans une semaine, soyez à Basse-Terre, oם vous logez. Notre homme viendra vous dire la suite. Il dira « le bonjour de Klein », et vous lui montrerez votre amulette en réponse. Ne le faites pas attendre.";
			link.l1 = "Très bien, dans une semaine, je serai chez moi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneExitFortFrance");
		break;

		case "Claine_7":
			dialog.text = "Le bonjour de Klein.";
			link.l1 = "...(montre l'amulette)...";
			link.l1.go = "Claine_8";
		break;

		case "Claine_8":
			dialog.text = "Je vous attendais, et j'allais partir. Klein m'avait pourtant prévenu de votre manque de ponctualité.";
			link.l1 = "Pardonnez ce retard. Vous avez quelque chose pour moi ?";
			link.l1.go = "Claine_9";
		break;

		case "Claine_9":
			dialog.text = "Oui. Il y a aux Caraïbes un homme qui nous gêne beaucoup.";
			link.l1 = "J'aimerais d'abord savoir...";
			link.l1.go = "Claine_10";
		break;

		case "Claine_10":
			dialog.text = "Vous poserez vos questions quand le travail sera fait. Donc : un Anglais, qui vit à St. John's, du nom d'Adam Cromwell. Faites en sorte qu'il cesse d'exister. Comment, cela ne m'intéresse pas. La récompense est de vingt-cinq mille.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneToSentJons");
		break;

		case "Claine_11":
			dialog.text = "Vous voilà. Alors, vous avez réussi ?";
			link.l1 = "Oui. Mais il y a autre chose.";
			link.l1.go = "Claine_12";
		break;

		case "Claine_12":
			dialog.text = "Il s'est passé quelque chose ?";
			link.l1 = "Pas grand-chose. א part cette lettre.";
			link.l1.go = "Claine_13";
		break;

		case "Claine_13":
			TakeNItems(pchar, "HelpSacredInquisition_Letter3", -1);
			dialog.text = "Tiens, tiens. Intéressant. Vous l'avez lue, bien sמr ? J'ai un nouveau travail pour vous, et c'est urgent.";
			link.l1 = "Vous aviez promis de répondre à mes questions.";
			link.l1.go = "Claine_14";
		break;

		case "Claine_14":
			AddMoneyToCharacter(pchar, 25000);
			dialog.text = "Plus tard. Pour l'instant, faites voile vers Niévès. Trouvez-y Francis Ivo et éliminez-le. La récompense est la même : vingt-cinq mille. Je vous attendrai de nouveau ici. Et voici votre argent pour Cromwell.";
			link.l1 = "Compris.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneToNevis");
		break;

		case "Claine_15":
			dialog.text = "Puisque vous êtes là, puis-je considérer que le travail est fait ?";
			link.l1 = "Entièrement. Vous aviez promis de répondre à mes questions.";
			link.l1.go = "Claine_16";
		break;

		case "Claine_16":
			dialog.text = "Demandez.";
			link.l1 = "Qu'est-ce que cette pierre de lune ?";
			link.l1.go = "Claine_17";
		break;

		case "Claine_17":
			dialog.text = "Je savais que vous finiriez par le demander. Que voulez-vous savoir exactement ? Je suppose que vous savez déjà quelque chose.";
			link.l1 = "Si c'est un morceau de lune, comment est-elle arrivée ici ?";
			link.l1.go = "Claine_18";
		break;

		case "Claine_18":
			dialog.text = "Nous savons une chose : le Seigneur lui-même l'a donnée à une ancienne civilisation. Il l'a prise sur la lune et la leur a donnée.";
			link.l1 = "Aux Atlantes, donc. Pourquoi croyez-vous que c'est vrai ? Et quel pouvoir détient cette pierre ?";
			link.l1.go = "Claine_19";
		break;

		case "Claine_19":
			dialog.text = "Tiens, tiens. Vous êtes allé loin dans cette affaire : vous savez même à qui elle appartenait. Et son pouvoir... Son pouvoir est grand. Infiniment grand.";
			link.l1 = "Si je comprends bien, vous ne l'avez pas encore trouvée ?";
			link.l1.go = "Claine_20";
		break;

		case "Claine_20":
			dialog.text = "C'est vrai, mais nous approchons. Seulement vous, mon ami, ne serez pas invité à partager le fruit de nos recherches.";
			link.l1 = "Je l'avais compris lors de notre dernière conversation.";
			link.l1.go = "Claine_21";
		break;

		case "Claine_21":
			dialog.text = "Vous savez... Klein et moi avons vraiment cru que vous étiez Nathan Rich. C'est Jake Smitt qui nous a fait voir notre erreur. Vous mentez avec un véritable art : avec un tel talent, vous devriez être gouverneur. J'avais même préparé l'argent pour Francis, mais j'ai bien peur de le garder. Dommage que vous ayez sמrement dépensé ce que vous avez reçu pour Cromwell : je l'aurais repris aussi. Et rendez-moi les lettres que vous avez trouvées ici. Et le journal. Je sais que vous les avez.";
			link.l1 = "Alors je suis un homme mort. Dites-moi au moins, avant la fin : qui est Jake Smitt ?";
			link.l1.go = "Claine_22";
		break;

		case "Claine_22":
			dialog.text = "Il est tout pour nous. Sans lui, nous n'existerions pas. Assez parlé, ou je vais rater ma traversée pour la Martinique. Je vous conseille de ne pas résister : ainsi, vous ne sentirez aucune douleur.";
			link.l1 = "Nous verrons bien. Attendez donc.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneFightWithKleinMan");
		break;

		case "Claine_23":
			dialog.text = "Je ne pensais pas que vous viendriez. Vous avez tué l'un des meilleurs mercenaires !";
			link.l1 = "J'en ai vu de meilleurs.";
			link.l1.go = "Claine_24";
		break;

		case "Claine_24":
			dialog.text = "Attendez, ne me tuez pas ! Je peux vous être utile.";
			link.l1 = "Peut-être. דa dépend de ce que vous savez.";
			link.l1.go = "Claine_25";
		break;

		case "Claine_25":
			dialog.text = "Que voulez-vous savoir ?";
			link.l1 = "Que savez-vous de la pierre, et de Jake Smitt ?";
			link.l1.go = "Claine_26";
		break;

		case "Claine_26":
			dialog.text = "De la pierre, je sais peu de chose, et Jake est un homme énigmatique. Un tueur à gages au talent rare. Toujours un pas en avance.";
			link.l1 = "Pourquoi êtes-vous venu aux Caraïbes ?";
			link.l1.go = "Claine_27";
		break;

		case "Claine_27":
			dialog.text = "Pour régler certaines affaires avec le gouverneur espagnol. Et pour trouver un savant pour Jake Smitt.";
			link.l1 = "Parlez-moi plus du savant.";
			link.l1.go = "Claine_28";
		break;

		case "Claine_28":
			dialog.text = "Il y a ici un fauteur de troubles. Je l'ai trouvé tout de suite. Je ne me souvenais même pas du nom.";
			link.l1 = "Oם puis-je le trouver ?";
			link.l1.go = "Claine_29";
		break;

		case "Claine_29":
			dialog.text = "Je ne sais pas. Je peux vous dire oם est Jake, mais je vous déconseille fortement de vous approcher de lui.";
			link.l1 = "Je ne vous ai pas demandé de conseil. Oם est-il ?";
			link.l1.go = "Claine_30";
		break;

		case "Claine_30":
			dialog.text = "Il doit être quelque part à Niévès, sur l'île même. Mais réfléchissez avant de prendre la mer. Et encore une chose : ne dites pas à Jake que nous nous sommes rencontrés. Je tiens à la vie, j'ai une famille.";
			link.l1 = "Vous auriez dמ penser à votre famille plus tכt.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneToNevisIsland");
		break;

		case "Jack_Smitt_1":
			dialog.text = "Tu es un vrai héros, " + GetFullName(pchar) + ". Tu m'as débarrassé de tous ceux avec qui j'aurais dמ partager.";
			link.l1 = "Et toi, tu es un individu remarquablement ignoble et cupide.";
			link.l1.go = "Jack_Smitt_2";
		break;

		case "Jack_Smitt_2":
			dialog.text = "Tu es venu chercher la clé ?";
			link.l1 = "La clé ?";
			link.l1.go = "Jack_Smitt_3";
		break;

		case "Jack_Smitt_3":
			dialog.text = "Enfin, qu'importe. Tire ta lame, j'aime les combats loyaux.";
			link.l1 = "Dis ça à Dieu. Si tu le rencontres.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneFightWithJackSmitt");
		break;

		case "Pedro_Carlos_1":
			AddMoneyToCharacter(pchar, 10000);
			dialog.text = "Vous êtes mon sauveur ! Cet idiot me retenait ici de force. Ne vous inquiétez pas : pour un tel meurtre, on ne pourra que vous remercier, et puis c'était un Anglais, et on ne les aime pas ici. Je vais même vous récompenser.";
			link.l1 = "Je le cherchais depuis longtemps. Dommage que nous n'ayons jamais parlé : j'avais beaucoup de questions à lui poser.";
			link.l1.go = "Pedro_Carlos_2";
		break;

		case "Pedro_Carlos_2":
			dialog.text = "Alors posez-les-moi. Je vous dirai tout ce que je sais.";
			link.l1 = "Je voulais en savoir plus sur la pierre de lune.";
			link.l1.go = "Pedro_Carlos_3";
		break;

		case "Pedro_Carlos_3":
			dialog.text = "Ah, celle qui donne le pouvoir de Dieu... Eh bien, je peux vous assurer que c'est une invention du début à la fin.";
			link.l1 = "Une invention ? Mais il y a tant de preuves !";
			link.l1.go = "Pedro_Carlos_4";
		break;

		case "Pedro_Carlos_4":
			dialog.text = "C'est peut-être un morceau de lune, même si j'en doute. Mais elle ne donne pas le pouvoir de Dieu. Vous savez comment on l'appelle ? La légende de la pierre de lune à la lumière fantomatique. Et vous savez pourquoi fantomatique ?";
			link.l1 = "Non. Pourquoi ?";
			link.l1.go = "Pedro_Carlos_5";
		break;

		case "Pedro_Carlos_5":
			dialog.text = "Le sens est dans le nom lui-même. Il y a en elle autant de pouvoir que de lumière, c'est-à-dire aucun. Même si je n'exclus pas qu'elle donne quelque chose à son possesseur. Mais certainement pas le pouvoir de Dieu.";
			link.l1 = "Bon sang... Alors, que donne-t-elle ?";
			link.l1.go = "Pedro_Carlos_6";
		break;

		case "Pedro_Carlos_6":
			dialog.text = "Je ne sais pas. Une lumière qui n'existe pas, peut-être. Je ne le sais pas et je ne veux pas le savoir : je n'aime pas perdre mon temps.";
			link.l1 = "Attendez. Jake a parlé d'une certaine clé.";
			link.l1.go = "Pedro_Carlos_7";
		break;

		case "Pedro_Carlos_7":
			dialog.text = "Ah, oui. Jake parlait d'une carte. De l'endroit oם se trouve la pierre, plutכt. D'après ce que j'ai compris, quelque part ici, sur l'île.";
			link.l1 = "Curieux.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneCarlosToExit");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
