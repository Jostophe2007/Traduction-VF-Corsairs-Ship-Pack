// Gregg: Lukash de Grassi and his men - the "Black Orchid" trilogy (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// The player's companion from the second half of chapter 4:
//   First time - the stock line of de Grassi's sailors;
//   1-29  - the Bay of Doom: recruitment, refusal, bargain and the decision to storm Santiago;
//   30-34 - cape Camaguey, the scouting before the assault;
//   35-45 - the corsairs have upset the plan; a new one is born;
//   46-49 - Matthew refused, we go in without him;
//   50-51 - the town is taken, de Grassi launches his frigate;
//   52-58 - the trap: a squadron from the sea, guns in the jungle;
//   59-60 - the breakout.
// Merkes's squadron is three heavy frigates here, not ships of the line (see the block
// in MysteriousArtefactPreExitSantiagoEnd), so the text says frigates too.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.lastname;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Adressez toutes vos questions à Lukash.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Et voici le capitaine " + sName + " : faisons-lui bon accueil ! Oh, j'ai complètement oublié de me présenter. Lukash de Grassi, enchanté de faire votre connaissance.";
			link.l1 = "Vous n'avez pas l'air enchanté, de Grassi. Vous travaillez pour Matilda, n'est-ce pas ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Oui, et je n'ai pas le choix. Et Matilda avait raison de vous attendre ici. Elle savait que les espions de Lanven avaient eu vent de notre expédition et qu'il vous enverrait.";
			link.l1 = "Et votre mission est de me tuer ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(il éclate d'un sourire)... Capitaine, vous imaginez vraiment que nous voulons votre mort ? Vous, l'un des chercheurs les plus heureux, qui êtes allé plus loin dans la quête de l'Orchidée que tous les autres réunis ? Vous n'êtes pas seulement une source de précieuses connaissances, mais aussi un excellent capitaine, capable de mener brillamment n'importe quelle mission. \nVous avez réussi à trouver la clé du coffre de Brian George, alors que les imbéciles qui travaillaient pour Matilda l'ont cherchée pendant deux mois. Quand on lui a dit que la clé était à vous, elle a compris que vous étiez exactement la personne qui lui manquait. Vous voyez oם je veux en venir ?";
			link.l1 = "Je vois. Mais il se trouve que je travaille pour Stefan Lanven, et je n'ai pas oublié comment Matilda a failli me faire exécuter.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Le monde est cruel, capitaine " + sName + ". Les hommes se servent d'autres hommes pour atteindre leurs propres buts. Seulement, le plus souvent, ces « autres » ne s'en doutent pas. Vous, par exemple, vous travaillez pour Lanven, alors qu'il est clair qu'il se sert de vous. Il ne vous paie même pas.";
			link.l1 = "Lanven m'a sauvé la vie deux fois ! Contrairement à Matilda, qui a failli me faire tuer en se servant de moi pour ses propres fins. Et vous vous trompez lourdement si vous croyez que Lanven ne paie pas mon travail.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(il réfléchit)... Hum... Vous avez raison, capitaine, j'avoue que je n'ai pas été très juste envers Lanven. Mais croyez-moi : il se sert de vous. Nous le savons.";
			link.l1 = "Alors prouvez-le !";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Volontiers, capitaine. La preuve a été terriblement difficile à obtenir, mais Lanven n'est pas le seul à avoir des espions ...(il sourit d'un air rusé)... Ce jour oם vous avez donné à Lanven la bonne combinaison du cadenas, vous vous en souvenez ?";
			link.l1 = "Bien sמr que je m'en souviens.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Lanven vous a ordonné d'attendre quatre jours. Soi-disant le temps qu'il lui fallait pour lire le livre. Mais réfléchissez, capitaine : quatre jours ! Il y a à peine plus de cinquante pages. Combien de temps faut-il pour les lire ? Une personne ordinaire mettrait environ cinq heures. Et Lanven vous a dit d'attendre quatre jours. Pourquoi ? Je vais vous le dire. Le bruit courait que le chercheur Brian George avait trouvé la cachette de l'Orchidée et l'avait consignée dans son livre. \nLanven pensait qu'avec le livre, il la trouverait enfin. Dès que vous le lui avez remis, il lui fallait un prétexte pour se débarrasser de vous pour un bon moment. Vous ne lui serviez plus à rien. Alors il vous a dit d'attendre quatre jours. Dès votre départ, le navire de Lanven a levé l'ancre avec lui à bord et a pris la mer. Mais il n'a pas trouvé dans le livre ce qu'il cherchait, et il a dמ faire demi-tour. Six ou sept heures après avoir quitté la Martinique, son navire était de nouveau au port.";
			link.l1 = "דa ne me paraît pas particulièrement convaincant.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Croyez-le ou non, à votre guise. דa n'a plus d'importance, car vous ne travaillez plus pour Lanven.";
			link.l1 = "C'est à moi d'en décider !";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Hum... Je ne vous l'ai pas dit ? On a retrouvé Lanven mort trois jours après votre départ de la Martinique. Et je vous le dis tout de suite : ce n'est pas nous, ni les Espagnols. Car deux de nos propres espions ont été tués avec lui.";
			link.l1 = "...(avec colère)... Bien sמr, et je devrais vous croire, ordure. C'est vous qui avez tué Lanven, c'est votre œuvre. Et maintenant, vous me dites qu'il se servait de moi, pour que je passe du cכté de Matilda.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Mais capitaine...";
			link.l1 = "Taisez-vous et écoutez, de Grassi. Je refuse de travailler pour Matilda. Elle me veut pour la même chose que Levinson, Lanven et Tulipe : pour courir partout faire leurs commissions. C'est clair ? N'essayez pas de me forcer, c'est mon dernier mot.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Capitaine " + sName + ", nous n'avons pas l'intention de vous forcer. Vous êtes libre de refuser, et je vous assure que nous vous laisserons partir. Mais réfléchissez encore. Nous vous proposons une association d'égal à égal. Avec Matilda, vos chances de trouver l'Orchidée sont meilleures.";
			link.l1 = "Une correction, de Grassi ! Avec moi, ce sont les chances de Matilda de trouver l'Orchidée qui sont meilleures. Et moi, comme toujours, j'ai l'honneur de jouer les garçons de courses.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Très bien, capitaine " + sName + ", je vois qu'on ne vous convaincra pas.";
			link.l1 = "Exactement. Bonne journée.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "...(suppliant)... Capitaine, attendez ! Ayez pitié ! Mes hommes et moi sommes dans une situation désespérée. Je vous en supplie, écoutez-moi !";
			link.l1 = "...(décontenancé)... Bon, parlez. Je vous écoute.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Il y a un an, j'étais un capitaine prospère et prometteur, à la tête d'une belle frégate. Je rêvais naïvement de devenir un jour amiral d'Espagne. Mais le destin en a décidé autrement. On m'a affecté, avec mon navire et mon équipage, au service de cette mégère de Matilda. L'année oם j'ai travaillé pour elle a été un véritable enfer. Elle donnait des missions impossibles et payait des clopinettes. En un an, j'ai perdu plus de trois cents hommes ; mon navire tombe en ruine, car l'argent couvre à peine les vivres, la poudre et les boulets. \nCes trois derniers mois, elle est devenue complètement folle. Imaginez : elle nous a ordonné de prendre d'assaut le fort de Marigot avec une frégate à moitié morte, un équipage de cent soixante-dix hommes et une vingtaine de canons, dont la moitié ne tiraient plus. Par miracle, j'ai brisé le fort et écrasé la résistance de la garnison. Et savez-vous combien elle nous a payés pour ça ?";
			link.l1 = "Vingt mille piastres ?";
			link.l1.go = "15";
			link.l2 = "Vingt-cinq mille ?";
			link.l2.go = "15";
			link.l3 = "Trente-cinq mille ?";
			link.l3.go = "15";
			link.l4 = "Cinquante mille ?";
			link.l4.go = "15";
		break;

		case "15":
			dialog.text = "J'aurais été heureux qu'elle paie autant. Mais je n'ai reçu que sept mille piastres. Sept mille !";
			link.l1 = "א votre place, je serais devenu pirate plutכt que d'avaler une telle humiliation.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Nous nous y étions résolus il y a deux mois, mais Matilda a appris que nous préparions quelque chose et a interdit à mon navire de quitter le port de Santiago. Et il y a une semaine, moi et les quatre survivants de mon équipage avons été amenés ici, dans la baie de la Perdition, à bord de deux frégates. Notre mission était simple : vous persuader de travailler pour Matilda. Elle avait promis de nous payer et de nous libérer de son service. Mais ça s'est révélé bien plus difficile que prévu.";
			link.l1 = "Donc, ces frégates vont bientכt revenir vous chercher, c'est bien ça ?";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Non, capitaine. Elles ne reviendront jamais nous chercher. Matilda se moque de ce qu'il adviendra de nous. Notre seule chance, c'est de vous persuader de nous emmener.";
			link.l1 = "Mais nous sommes sur le continent, vous pouvez rejoindre la civilisation à travers la jungle.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Ce n'est pas une jungle, c'est un mur. Impossible de la traverser. Et même si nous parvenions à nous enfoncer de quelques milles, les Indiens nous tueraient. C'est pour ça qu'on l'appelle la baie de la Perdition. On ne peut pas la quitter sans navire. Alors vous étiez notre seul espoir.";
			link.l1 = "Laissez-moi réfléchir. J'accepte de vous emmener. Mais en échange, vous m'aiderez à trouver Matilda et à la tuer. Marché conclu ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Bien sמr que j'accepte, capitaine !";
			link.l1 = "Parfait ! Alors, dites-moi tout ce que vous savez, ici et maintenant.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Ici et maintenant ? Capitaine, mes hommes et moi n'avons pas mangé depuis deux jours. Et nous sommes très fatigués. Peut-être pourriez-vous d'abord nous nourrir et nous laisser nous reposer un peu. Je promets de vous dire tout ce que je sais ensuite.";
			link.l1 = "Non, de Grassi, dites-le maintenant. Vous vous reposerez plus tard.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Comme vous voudrez, capitaine. Je commencerai par dire que Matilda est une chercheuse extraordinairement chanceuse. La bande de Clive, sur les ordres de Tulipe, a tenté plusieurs fois d'en finir avec elle, en vain : elle s'en est sortie au dernier moment à chaque fois. Une fois, Clive et ses hommes l'ont acculée près des grottes de Santo Domingo. \nComprenant qu'un combat contre une meute de pirates enragés était perdu d'avance, elle est descendue dans la grotte. Clive et ses gars, huit ou neuf à l'époque, l'y ont suivie. Ce qui s'est passé en bas, personne ne le sait, mais Matilda s'en est sortie, et seuls trois hommes de la bande de Clive en sont ressortis vivants. Elle a toujours eu une chance du diable, capitaine.";
			link.l1 = "Venez-en au fait, de Grassi. Oם peut-on la trouver ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Sa base est à Cuba, à Santiago. Elle est gardée aussi bien que le gouverneur lui-même, et en plus, elle a un garde du corps. Il s'appelle Verstehohlsten, une véritable armoire à glace, de près de sept pieds, d'une endurance monstrueuse. \nPersonne n'a jamais battu Verstehohlsten. Il épuise son adversaire jusqu'à ce que celui-ci ne puisse plus tenir son épée, puis il lui brise la nuque à mains nues. Alors, avant d'atteindre Matilda, vous devrez passer sur son corps.";
			link.l1 = "Et ce... comment s'appelle-t-il... Verstehohlsten, il est toujours à ses cכtés ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Oui, capitaine. Ces derniers temps, Matilda ne quitte pas la résidence. Et Verstehohlsten est toujours à cכté d'elle, sauf, bien sמr, pendant les heures oם elle dort. Pour prévenir votre question : il est impossible aussi de pénétrer dans sa chambre.";
			link.l1 = "Vous savez, de Grassi, une excellente idée m'est venue. Nous allons prendre Santiago d'assaut !";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "D'assaut ? Mais pourquoi ? Risquer le navire, l'équipage, votre propre vie, alors que tout peut se faire discrètement ?";
			link.l1 = "Non, nous attaquerons par la terre, et à un moment oם il n'y aura aucun navire dans le port de Santiago. Une fois la garnison du fort brisée, ainsi que les habitants, s'il y en a qui résistent, nous prendrons la résidence. Matilda ne s'échappera pas : pas de navire au port, et nos gars tiendront la porte. Et tuer Verstehohlsten, ce n'est pas bien compliqué.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "א mon avis, il vaudrait mieux élaborer un plan et nous passer d'assaut.";
			link.l1 = "...(avec mépris)... Un plan, un plan. Les plans échouent toujours. Ce sera comme à Porto Rico, quand Levinson et moi avons enlevé la fille du gouverneur. Tout s'est passé selon le plan, nous touchions au but... mais c'est une longue histoire. Ce qui compte, c'est que tout avait été pensé dans les moindres détails, et que nous avons quand même donné l'alarme. Alors c'est décidé. Nous prenons Santiago d'assaut !";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Mais capitaine " + sName + ", des gens paisibles vont mourir, des Espagnols, mes propres compatriotes. Pourquoi tuer des centaines d'innocents ? Et tout ça pour atteindre Matilda.";
			link.l1 = "Vous ne les défendez que parce que ce sont vos compatriotes. S'il s'agissait d'une autre colonie, française ou hollandaise, vous n'auriez pas dit un mot sur les habitants. Mais vous avez raison : beaucoup vont mourir à cause de la seule Matilda.";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Peut-être pourrions-nous quand même élaborer un plan ?";
			link.l1 = "Voici ce que nous allons faire, de Grassi. Nous allons envoyer au gouverneur de Santiago un ultimatum exigeant qu'il nous livre Matilda. S'il refuse, nous prenons la ville d'assaut.";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Ce n'est pas une solution. Le gouverneur a reçu l'ordre de protéger Matilda par tous les moyens. Pour lui, la vie de Matilda vaut plus que celle de tous les habitants de Santiago. Il n'acceptera pas. Et nous perdrons l'effet de surprise.";
			link.l1 = "Alors l'assaut est inévitable. C'est ma décision définitive, et elle n'est pas à discuter. Votre mission est de découvrir quand il n'y aura aucun navire dans le port de Santiago. Sinon, Matilda nous filera entre les doigts. Vous en êtes capable ?";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Oui, capitaine.";
			link.l1 = "Alors, cap sur Cuba, au cap Camagןey. Nous débarquerons là-bas.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToSantiagoShore");
		break;

		case "30":
			dialog.text = "Capitaine, j'ai deux nouvelles pour vous, une bonne et une mauvaise. Laquelle d'abord ?";
			link.l1 = "La bonne, selon la tradition.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Il n'y a qu'un seul navire dans le port de Santiago : la flמte marchande Philippe, et elle appareille demain matin !";
			link.l1 = "Parfait. Et la mauvaise ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Dans trois jours, une escadre de trois frégates lourdes sous les ordres de l'amiral Merkes arrivera à Santiago. Elle multipliera plusieurs fois les défenses de la colonie. Ce qui veut dire que nous n'avons que deux jours pour l'assaut.";
			link.l1 = "Deux jours suffiront. Mais comment l'avez-vous appris si vite ? Nous venons à peine de débarquer.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Il y avait des pêcheurs qui posaient leurs filets tout près, et je leur ai demandé. N'ayez crainte, capitaine, on peut leur faire confiance : ils traînent souvent à la taverne et n'en savent pas moins que les taverniers eux-mêmes.";
			link.l1 = "Parfait. Il n'y a pas de temps à perdre : demain matin, nous lançons l'assaut sur Santiago ! Et vous êtes sמr que les pêcheurs ne laisseront pas échapper ce que vous leur avez demandé ?";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Tout à fait sמr, capitaine. Ils ne raconteront plus jamais rien à personne ...(il sourit)...";
			link.l1 = "Hum... C'est peut-être mieux ainsi. Très bien, de Grassi, demain sera une rude journée ; maintenant, reposons-nous.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInSantiagoShoreTime");
		break;

		case "35":
			dialog.text = "Capitaine, nous avons de mauvaises nouvelles.";
			link.l1 = "Que s'est-il passé ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Ce sont les corsaires. La nuit dernière, une centaine d'entre eux ont attaqué le fort de Santiago. Ils ont essayé de forcer la prison pour libérer leur chef, Jason, mais les Espagnols les ont repoussés. Maintenant, ils rassemblent une nouvelle troupe pour une seconde tentative. Seulement, ça ne donnera rien, que le diable les emporte : les Espagnols se sont repris et se sont préparés. \nPlusieurs canons du fort sont braqués sur la route, et la garnison a été fortement renforcée depuis Santiago. Matthew, le chef des corsaires, à qui j'ai parlé ce matin, nous demande de l'aide. Il promet de bien payer si nous l'aidons à libérer Jason.";
			link.l1 = "Eh bien, combien, « bien » ?";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "Il n'a pas donné de somme exacte, mais il dit que cela couvrira toutes nos pertes, et plus encore. Seulement, capitaine, ces maudits pirates ont ruiné nos plans : maintenant, les Espagnols s'attendent à une attaque, et nous avons perdu l'effet de surprise.";
			link.l1 = "Je pense le contraire, de Grassi. Réfléchissez : les Espagnols s'attendent à une attaque contre le fort, pas contre la colonie, et leurs forces principales y ont été concentrées. Nous, avec les corsaires derrière nous, frappons la ville, nous frayons un chemin jusqu'à la résidence et nous nous emparons du gouverneur et de Matilda. Et c'est tout. Avec des otages en main, nous ordonnons aux Espagnols du fort de déposer les armes et de libérer Jason. Et nous ne perdons pas du tout l'effet de surprise : personne ne s'attend à une attaque contre la ville.";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "Capitaine, vous êtes sמr que les Espagnols déposeront les armes plutכt que d'essayer de reprendre Santiago ?";
			link.l1 = "Mais Matilda sera entre nos mains. Vous l'avez dit vous-même : pour les Espagnols, la garder en vie compte plus que tout.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "C'est bien là le problème, capitaine " + sName + ". Les Espagnols sont très méfiants. Ils ne croiront pas que vous laisserez Matilda en vie s'ils se rendent : le risque est trop grand. Le plus probable, c'est qu'ils prendront la ville d'assaut.";
			link.l1 = "Alors nous en finirons avec Matilda et le gouverneur. Ces porcs regretteront d'avoir lancé l'assaut.";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "Mais ça ne nous aidera pas, capitaine. Les Espagnols n'en seront que plus furieux, ils amèneront leurs canons jusqu'aux portes et fermeront toutes les routes. Et dans deux jours, l'escadre de Merkes arrivera et nous achèvera pour de bon. Si nous sommes encore en vie d'ici là.";
			link.l1 = "Bon sang ! Il faut trouver une issue. Des idées ?";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Oui ! Il y a un moyen, capitaine ! Ma frégate est en réparation dans les docks. Si nous arrivons à la remettre à flot avant que les Espagnols ne prennent la ville d'assaut, nous pourrons partir à son bord !";
			link.l1 = "Votre frégate ? Vous avez dit vous-même que c'était une vieille épave qui...";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "...(l'interrompant)... ...peut encore naviguer. En tout cas, elle nous mènera jusqu'à Camagןey. Et là, nous monterons à bord de votre navire et nous ferons route vers Hispaniola.";
			link.l1 = "Vous en êtes certain ? Elle tiendra vraiment le coup ?";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Je ne peux pas en être certain, capitaine. Mais si elle n'atteint pas Camagןey, nous débarquerons à Puerto Príncipe. Et de là, nous rejoindrons le cap par voie de terre.";
			link.l1 = "Alors il ne reste plus qu'à obtenir le soutien des pirates. Oם puis-je trouver leur chef ?";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Ils campent non loin de Santiago, en attendant notre réponse. Mais, capitaine, si les Espagnols refusent de déposer les armes et prennent la ville d'assaut, nous ne pourrons pas libérer leur chef Jason.";
			link.l1 = "Et s'ils se jettent sur le fort, leurs chances de libérer Jason sont nulles : la mitraille les balaiera tout simplement. En attaquant la ville avec nous, ils ont au moins l'espoir que la garnison se rende. Avec nous, leurs chances sont meilleures.";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Il ne nous reste qu'à les persuader de venir avec nous. Leur chef, Matthew, est têtu ; ce ne sera pas facile.";
			link.l1 = "Alors je vais mettre à l'épreuve mon pouvoir de persuasion. Allons-y.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToSantiagoJungle");
		break;

		case "46":
			dialog.text = "Alors, capitaine " + sName + ", vous avez convaincu Matthew ?";
			link.l1 = "...(avec colère)... Non. C'est sans espoir, cet homme est une vraie tête de mule. J'aimerais bien voir comment il va prendre ce fort d'assaut.";
			link.l1.go = "47";
		break;

		case "47":
			dialog.text = "Gardez votre colère pour les Espagnols. Discutons du plan d'action, capitaine.";
			link.l1 = "Qu'y a-t-il à discuter ? Nous prenons la ville d'assaut, nous forçons la résidence, nous tuons les soldats, nous faisons prisonniers Matilda et le gouverneur. Qu'est-ce qui n'est pas clair ?";
			link.l1.go = "48";
		break;

		case "48":
			dialog.text = "Et ensuite, capitaine ?";
			link.l1 = "...(furieux)... De Grassi, nous avons déjà tout passé en revue, que voulez-vous de plus ?! Si les Espagnols du fort se rendent, parfait. S'ils ne se rendent pas, nous tuons Matilda et le gouverneur et nous partons sur la frégate. Quoi d'autre ?!";
			link.l1.go = "49";
		break;

		case "49":
			dialog.text = "Aucune question, capitaine.";
			link.l1 = "Alors, en avant !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactPreBattleInSantiagoExitTown");
		break;

		case "50":
			dialog.text = "Beau travail, capitaine ! Vous vous êtes battu à merveille !";
			link.l1 = "Souvenez-vous du proverbe, de Grassi : ne dites pas « hourra » avant d'avoir sauté. Nous n'avons fait que la moitié du travail. Donc : prenez les hommes, allez aux docks et remettez votre frégate à flot. S'il y a des voies d'eau, colmatez-les vite : il nous suffit d'atteindre Puerto Príncipe. Et moi, je vais nettoyer la résidence. C'est clair ?";
			link.l1.go = "51";
		break;

		case "51":
			dialog.text = "Aucune question, tout est clair.";
			link.l1 = "Quand j'en aurai fini à la résidence, je vous retrouverai et nous déciderons de la suite. Allez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToSantiagoTownhall");
		break;

		case "52":
			dialog.text = "דa se présente mal, capitaine. On dirait que nous sommes pris au piège. L'escadre de Merkes arrive par la mer, et la route de la jungle est bloquée : des Espagnols et des canons.";
			link.l1 = "Je sais, de Grassi. Votre frégate est à flot ?";
			link.l1.go = "53";
		break;

		case "53":
			dialog.text = "Oui, mais... Elle nous portera jusqu'à Puerto Príncipe, mais affronter trois navires de Merkes... Vous comprenez, capitaine, c'est perdu d'avance. Première bordée, et nous servons de nourriture aux poissons.";
			link.l1 = "Alors il faut forcer le passage vers la jungle.";
			link.l1.go = "54";
		break;

		case "54":
			dialog.text = "Hors de question. Les Espagnols ont une douzaine de canons royaux chargés à mitraille, des mousquets, et le nombre. C'est du suicide.";
			link.l1 = "Bon sang ! Il y a d'autres moyens de sortir de la ville ? Un passage souterrain, comme dans les châteaux du vieux pays.";
			link.l1.go = "55";
		break;

		case "55":
			dialog.text = "Même s'il y en a, nous n'avons pas le temps de les chercher, capitaine. L'escadre sera là dans quatre heures environ. Et si nous essayions de nous retrancher dans la résidence du gouverneur ? Nous avons assez d'hommes pour repousser un assaut.";
			link.l1 = "Vous délirez, de Grassi ?! Mille cinq cents Espagnols débarqueront en ville d'ici cinq heures. Et les Espagnols de la jungle, vous les avez oubliés ? Ils amèneront deux canons devant la résidence et la réduiront en ruines.";
			link.l1.go = "56";
		break;

		case "56":
			dialog.text = "Oui, vous avez raison, capitaine. Mais alors, nous n'avons tout simplement aucune issue.";
			link.l1 = "Voici ce que nous allons faire, de Grassi : préparez la frégate à prendre la mer, nous allons essayer de forcer le passage.";
			link.l1.go = "57";
		break;

		case "57":
			dialog.text = "Avec cette épave ?!";
			link.l1 = "Vous avez une autre proposition ? Si oui, je vous écoute.";
			link.l1.go = "58";
		break;

		case "58":
			dialog.text = "...(tête basse)... Non, capitaine.";
			link.l1 = "Exactement. Rassemblez tous les hommes et soyez prêts à prendre la mer ; pendant ce temps, je vais trouver Matilda : elle se cache quelque part en ville.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToSantiagoStore");
		break;

		case "59":
			dialog.text = "...(d'un air sombre)... Ma frégate est toujours dans les docks, capitaine. Impossible de sortir de la baie : les canons du fort tiennent le goulet, et Merkes approche par la mer.";
			link.l1 = "Alors nous partirons par la terre. Notre escadre nous attend à Camagןey : nous la rejoindrons en longeant la cכte.";
			link.l1.go = "60";
		break;

		case "60":
			dialog.text = "...(plus sombre encore)... Une demi-journée de marche, et encore, si les Espagnols ne nous poursuivent pas. Et ils le feront : Merkes n'est pas un imbécile, il enverra des navires le long de la cכte pour nous couper du cap.";
			link.l1 = "Qu'il les envoie. L'essentiel est d'atteindre nos ponts : ensuite, on verra bien qui coupe qui.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToSantiagoSea");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
