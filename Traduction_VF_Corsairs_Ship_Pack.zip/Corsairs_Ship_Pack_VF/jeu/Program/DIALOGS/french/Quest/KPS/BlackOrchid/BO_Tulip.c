// Gregg: Clive's band and their chief, Tulip Banda - the "Black Orchid" trilogy
// (ported from Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// One file for four characters, as in the original:
//   1-5   - "MA Banda 1" (Clive) dressing down his men outside Port-au-Prince;
//   6-19  - Clive holds the player at gunpoint; either death or the road to Tulip;
//   20-43 - Tulip himself in the La Vega tavern, the bargain and the contract on Lanven;
//   44-57 - Clive lays out the plan of the assassination;
//   58    - Clive realises he has been betrayed and orders the attack.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.lastname;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Clive : Bon, nous y sommes. וcoutez-moi bien, bande d'imbéciles. Nous traversons la ville tranquillement, sans nous presser. C'est moi qui parle aux soldats, et toi, Vincent, tu la boucles. Dis un seul mot sans mon ordre, comme la dernière fois, et je t'abats sur place. Compris ?";
			link.l1 = "Vincent : Compris, chef.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Clive : Bien. Maintenant toi, Jacky. Garde ce flingue à ta ceinture jusqu'à ce que je te dise de le sortir. Tu m'as compris ?";
			link.l1 = "Jacky : Chef, cette fouine voulait filer, je l'ai vu de mes yeux. J'ai tiré, qu'est-ce que je pouvais faire d'autre ? Il se serait enfui si je ne lui avais pas logé une balle !";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Clive : Jacky, c'était un cul-de-sac ! Il n'allait nulle part ; nous l'aurions acculé et achevé discrètement. Au lieu de ça, tu as déclenché une fusillade, et la moitié de la garnison de Port Royal était à nos trousses.";
			link.l1 = "Jacky : Mais chef, avoue que je l'ai bien descendu. Je lui ai fait éclater la tête en lambeaux, la cervelle à trois mètres dans la rue, je l'ai vu de mes yeux. Et Tulipe était content.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Clive : Alors maintenant, tu en es fier ?! Donne-moi ce pistolet ! Tout de suite !";
			link.l1 = "Jacky : Chef, du calme, j'ai compris. Le flingue à la ceinture jusqu'à ce que tu le dises. Pas de problème.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Clive : דa suffit, en route !";
			link.l1 = "Vincent : Hé, chef, on a de la compagnie.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactDialogWithBandaInPortPaxExit");
		break;

		case "6":
			dialog.text = "Clive : Regardez qui voilà. Jacky, sors ton flingue, tu vas pouvoir t'exercer au tir.";
			link.l1 = "Jacky : Avec plaisir, chef. Fais de beaux rêves !";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Jacky, arrête ! Doucement. ...(il scrute le visage)... Tu es le capitaine " + GetFullName(PChar) + ", n'est-ce pas ?";
			link.l1 = "Oui.";
			link.l1.go = "8";
			link.l2 = "Et alors ?";
			link.l2.go = "8";
			link.l3 = "Non, tu me prends pour quelqu'un d'autre.";
			link.l3.go = "11";
		break;

		case "8":
			dialog.text = "Parfait, pas besoin d'aller chercher : un autre chercheur, juste devant nous. Eh bien, " + sName + ", c'est la fin pour toi. Tu veux mourir vite et sans souffrir ? Alors dis-nous tout ce que tu sais sur l'Orchidée noire.";
			link.l1 = "Tu es Clive, n'est-ce pas ? Ce même Clive qui a fait la peau au gouverneur de Maracaibo il y a deux mois ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Oui, je suis Clive, l'un des meilleurs tueurs à gages des Caraïbes. Et toi, " + sName + ", tu es dans de sales draps. Ta tête est mise à prix. Tu comprends ? Impossible de t'en tirer : Jacky te tient en joue, et si tu cours, il te fera sauter la tête. Pas vrai, Jacky ?";
			link.l1 = "Jacky : Tu n'as qu'un mot à dire, chef.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Tu vois, " + sName + ", tu as entendu Jacky. Dis-nous tout et tu mourras vite : tu ne sentiras même rien. Tais-toi, et ce sera pire pour toi. Vincent est un maître du métier ; il connaît une foule de moyens de faire parler un homme.";
			link.l1 = "...(pour lui-même : je dois m'en sortir par la parole)... Maintenant, écoute-moi, Clive. וcoute-moi bien. Je ne parlerai qu'à ton chef, à Tulipe. C'est clair ?";
			link.l1.go = "11";
			link.l2 = "...(pour lui-même : je dois m'en sortir par la parole)... וcoute, Clive, j'ai une proposition d'affaires à te faire.";
			link.l2.go = "12";
		break;

		case "11":
			dialog.text = "C'est clair ! Jacky, vas-y.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInPortPaxExitTownDead");
		break;

		case "12":
			dialog.text = "L'argent ne m'intéresse pas, " + sName + ".";
			link.l1 = "Je n'allais pas t'offrir de l'argent. Ma proposition est d'un autre genre. Je veux depuis longtemps travailler pour ton chef, pour Tulipe.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "וcoutez-le, celui-là. Pas mal essayé, dommage que ça n'ait pas marché. Tulipe a mis ta tête à prix, et je vais exécuter le contrat. Rien ne m'arrêtera.";
			link.l1 = "Tulipe te paiera bien plus si tu m'amènes vivant à lui. Je sais beaucoup de choses qui l'intéresseront.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "J'en doute très fort.";
			link.l1 = "Tu doutes de quoi ? Que Tulipe paiera plus ? Ou que ce que je sais l'intéressera ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Des deux. Tulipe ne paie jamais plus que ce qu'il a promis, même si je t'amène vivant. Et il n'y a rien en ce monde qui soit capable de l'intéresser.";
			link.l1 = "Très bien, alors faisons autrement. Si ce que je dis à Tulipe ne l'intéresse pas et qu'il ordonne ma mort, tu me tues et tu prends ton argent. S'il me laisse en vie, je te paie le double de ce qu'il a promis. Dans tous les cas, tu ne perds rien.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Le double de ce que Tulipe a promis, ça fait cinq millions.";
			link.l1 = "Cinq millions ? Alors Tulipe m'estime à deux millions et demi de piastres.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Exactement, " + sName + ". Tu as une telle somme ?";
			link.l1 = "L'argent sera là. Je te le promets. Alors ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Laisse-moi réfléchir ...(il marmonne quelque chose)... D'accord, " + sName + ", suis-moi et ne pense même pas à filer. Jacky, tiens-le en joue.";
			link.l1 = "Oם allons-nous ? Tulipe est à Hispaniola ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "C'est ça, il est ici. Suis-moi et ne traîne pas.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToLaVegaTavern");
		break;

		case "20":
			dialog.text = "Dites-moi ce que vous savez de l'Orchidée noire.";
			link.l1 = "Que voulez-vous que je vous dise, exactement ? Je peux vous parler des sept chercheurs de l'Orchidée noire.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "דa, je le sais déjà. Quoi d'autre ?";
			link.l1 = "Des renseignements sur ceux qui ont autrefois possédé l'Orchidée vous intéresseraient-ils ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Non, je connais parfaitement les légendes des six possesseurs.";
			link.l1 = "Ils étaient sept, en fait. Nommez ceux que vous connaissez, et je vous nommerai le septième.";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Le docker Giancarlo, le mendiant Jack Strbeton, Alvarez Istilochos, Bertrand Grenadier, l'amiral don Pedro de la Encantario, Alejon Kendart.";
			link.l1 = "Il vous manque Stefan Lanven.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "...(d'un ton moqueur)... Stefan Lanven. Lanven n'a jamais possédé l'Orchidée.";
			link.l1 = "Mais il l'a vue.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "...(il rit)... Voulez-vous que je vous raconte dans quelles circonstances Lanven et moi avons vu l'Orchidée ?";
			link.l1 = "Vous et Lanven ?!";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Oui. J'avais appris que l'Orchidée noire était chez Bertrand Grenadier et je me suis mis à sa recherche. Grenadier fréquente les bordels, alors toute la recherche se résumait à une chose : le chercher dans les bordels des colonies françaises. Je l'ai vite trouvé à Tortuga. \nC'était la nuit. J'ai tendu une embuscade à gauche de la porte du bordel et j'ai attendu. Quand Grenadier est sorti, j'ai visé, et j'allais tirer quand, sorti de nulle part, Lanven lui est tombé dessus.";
			link.l1 = "Tombé dessus ? Comment faut-il l'entendre ?";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Comme je le dis. Cet idiot sans cervelle a sauté sur Grenadier et a essayé de l'étrangler. Grenadier l'a simplement jeté à terre et l'a assommé d'un seul coup de poing. א ce moment-là, j'ai tiré... Bon sang...";
			link.l1 = "Et ensuite ?";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Je l'ai manqué. La balle lui est passée au-dessus de la tête et lui a fait tomber son chapeau. Une seconde plus tard, Grenadier avait disparu, et à sa place, il ne restait qu'une faible lueur argentée : le signe que laisse l'Orchidée noire. Des voix et des bruits de pas de soldats se sont rapprochés, et je me suis enfui. Je m'en suis tiré ; ce qu'est devenu Lanven, je l'ignore. \nDeux mois après, l'Escadre insaisissable est arrivée aux Caraïbes. Et, comme vous le savez déjà, le possesseur de l'Orchidée noire est devenu l'amiral don Pedro de la Encantario. Bon sang, sans Lanven, j'aurais abattu Grenadier et pris l'Orchidée !";
			link.l1 = "Je comprends maintenant pourquoi Lanven ne m'en a jamais parlé.";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Aux affaires, " + sName + ". Ce n'est pas à moi de vous parler de l'Orchidée noire, mais à vous de m'en parler. Et assez bavardé sur les chercheurs et les possesseurs. Savez-vous quelque chose sur l'endroit oם se trouve l'Orchidée maintenant ? Quoi que ce soit ?";
			link.l1 = "Je sais que l'Orchidée noire est désormais à sa véritable place.";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Sa véritable place ? Et oם serait-ce ?";
			link.l1 = "Personne ne le sait. Mais je pense que c'est là oם elle a été créée. Là oם était l'Orchidée au commencement. Sait-on quelque chose de son origine ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Non, rien. Le premier à l'avoir trouvée, c'est le docker Giancarlo.";
			link.l1 = "Alors, c'est peut-être là sa véritable place ? Et si nous cherchions ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Et comment chercheriez-vous, hein, " + sName + " ? Personne ne connaît même le nom de la colonie, encore moins l'endroit. Et il serait stupide de cacher un tel trésor là-bas. Un homme l'a trouvée, un autre la trouverait aussi. Non, le vieux Kendart n'était pas un imbécile.";
			link.l1 = "Et Kendart, maintenant ? Oם est-il ?";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Trouvez l'Orchidée, et vous trouverez Kendart. Ou le cadavre de Kendart.";
			link.l1 = "Alors peut-être devrions-nous chercher Kendart plutכt que l'Orchidée ? Trouvons-le, et nous la trouverons.";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Voyez-vous ça, vous parlez comme si nous étions déjà associés, à chercher l'Orchidée ensemble. Alors que je n'ai qu'un mot à dire pour que Clive vous achève. Ne l'oubliez pas.";
			link.l1 = "Mais ce que je vous ai dit était utile, et en plus...";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "...(avec mépris)... Utile ? ...(l'imitant)... « L'Orchidée est à sa véritable place ». Rien ne saurait être plus utile. Et comment saurais-je que vous ne mentez pas ? Vous avez peut-être tout inventé pour sauver votre peau.";
			link.l1 = "C'est Kendart lui-même qui a parlé de la véritable place.";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Et c'est là que vous vous trahissez, capitaine. C'est Kendart lui-même qui le lui a dit. Vous entendez seulement ce que vous dites ?";
			link.l1 = "Pas à moi : à un ami. Un ancien ami. Et il m'a répété ces mots.";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "Et qui est cet ancien ami ?";
			link.l1 = "L'un des chercheurs de l'Orchidée, Frederick Levinson.";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "Alors vous connaissez Levinson.";
			link.l1 = "Oui, et depuis longtemps.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Parfait, alors vous savez oם il est maintenant.";
			link.l1 = "Oui. Mais...";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "Splendide. Voici ce qu'il en est, capitaine : désormais, vous travaillez pour moi, compris ? Si vous refusez, je vous tue. Votre première mission est de tuer Stefan Lanven. Vous avez accès à la résidence du gouverneur, n'est-ce pas ?";
			link.l1 = "Oui.";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Parfait. Il ne vous en coמtera rien d'envoyer cet idiot sans cervelle dans l'autre monde. Clive et sa bande surveilleront votre travail et vous couvriront si nécessaire.";
			link.l1 = "Je comprends, Tulipe.";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "...(entre ses dents)... Mais si vous songez à me doubler, capitaine, si Clive soupçonne que vous voulez filer, si...";
			link.l1 = "Je comprends, je comprends, je serai bien sage.";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Splendide. Allez-y. Clive et ses gars vous accompagneront.";
			link.l1 = "Très bien. J'y vais.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactInLaVegaTavernTalkWithClive");
		break;

		case "44":
			dialog.text = "וcoute-moi bien, " + sName + ". Désormais, tu travailles avec moi, avec Clive, la meilleure lame à gages des Caraïbes.";
			link.l1 = "...(à mi-voix)... Bel honneur, de travailler avec une brute comme toi.";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Qu'est-ce que tu marmonnes, là ?";
			link.l1 = "Je dis que c'est un grand honneur de travailler avec un professionnel tel que toi.";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Voilà qui est mieux, " + sName + ". Maintenant, aux affaires. C'est moi qui commande cette opération, compris ?";
			link.l1 = "Compris.";
			link.l1.go = "47";
		break;

		case "47":
			dialog.text = "Voilà comment ça va se passer, " + sName + ", écoute bien, je ne le répéterai pas. Maintenant, nous allons en ville, à la résidence du gouverneur. Toi et moi, nous entrons et nous allons droit sur Lanven. Tu dis aux petits soldats que je suis avec toi. C'est clair ?";
			link.l1 = "Oui, c'est clair.";
			link.l1.go = "48";
		break;

		case "48":
			dialog.text = "Alors répète ce que j'ai dit.";
			link.l1 = "Toi et moi, nous entrons dans la résidence et nous allons droit sur Lanven. Je dois dire aux soldats que tu es avec moi.";
			link.l1.go = "49";
		break;

		case "49":
			dialog.text = "Parfait, " + sName + ". Nous arrivons à la résidence, tu me présentes, et ensuite, tu fais parler Lanven. Compris ?";
			link.l1 = "Pas tout à fait. Comment dois-je te présenter ?";
			link.l1.go = "50";
		break;

		case "50":
			dialog.text = "דa, c'est ton affaire, pas la mienne. Dis que je suis un ami à toi, ou quelque chose comme ça. Invente quelque chose. Ensuite, fais-le parler de l'Orchidée : dis-lui, par exemple, que tu en as trouvé des traces dans une grotte sur le continent.";
			link.l1 = "Comme s'il allait me croire.";
			link.l1.go = "51";
		break;

		case "51":
			dialog.text = "Fais en sorte qu'il te croie, sinon je t'achève en même temps que Lanven.";
			link.l1 = "Bon, je m'en sortirai. Et comment comptes-tu tuer Lanven ?";
			link.l1.go = "52";
		break;

		case "52":
			dialog.text = "Regarde, " + sName + ", tu vois ça ? ...(il montre des plaques de métal rondes et dentelées)... On les a inventées au Japon, une chose mortelle. Bien lancée, l'une d'elles fend le crâne d'un homme.";
			link.l1 = "Je vois. Et le gouverneur et les soldats ?";
			link.l1.go = "53";
		break;

		case "53":
			dialog.text = "Qu'est-ce que le gouverneur et les soldats viennent faire là-dedans ? Nous tuons Lanven seul et nous filons par la porte de derrière. Jacky et Vincent nous y attendront pour nous couvrir si nécessaire.";
			link.l1 = "Les soldats et le gouverneur seront dans la même pièce que Lanven. Cette résidence n'a ni pièces séparées ni porte de derrière.";
			link.l1.go = "54";
		break;

		case "54":
			dialog.text = "Espèce d'idiot, " + sName + " ! Pourquoi tu ne l'as pas dit tout de suite ?";
			link.l1 = "Tu ne me l'as pas demandé. Je pensais que tu le savais.";
			link.l1.go = "55";
		break;

		case "55":
			dialog.text = "On change de plan. Jacky et Vincent viennent avec nous. Dès que nous entrons dans la résidence, ils abattent les soldats et j'achève Lanven. Ta cible, " + sName + ", c'est le gouverneur. Fais-lui son affaire au pistolet, peu importe le bruit.";
			link.l1 = "Et après ? Comment nous sauvons-nous ?";
			link.l1.go = "56";
		break;

		case "56":
			dialog.text = "On verra, " + sName + ", on verra sur place. דa suffit, en route !";
			link.l1 = "...(à mi-voix)... Le plan le plus stupide qu'on puisse imaginer.";
			link.l1.go = "57";
		break;

		case "57":
			dialog.text = "Qu'est-ce que tu marmonnes encore ?";
			link.l1 = "Je dis que c'est un plan magnifique, Clive, il n'y en a pas de meilleur !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxExitTown");
		break;

		case "58":
			dialog.text = "C'est " + sName + " ! Il nous a trahis ! Il a prévenu les Français ! Tuez-le !";
			link.l1 = "Bon sang !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToPortPaxExitTownBattleWithTulipBandaBegin");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
