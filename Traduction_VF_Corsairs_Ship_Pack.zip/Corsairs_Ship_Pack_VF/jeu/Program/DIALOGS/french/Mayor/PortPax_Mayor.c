// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr9GuardPP_GoodWork")
			{
				dialog.text = "Capitaine, toute la ville vous sera redevable jusqu'à la fin de vos jours ! Vous venez de nous sauver...";
				link.l1 = ""+ GetSexPhrase("Baron", "Baronne") +", monsieur. Je suis "+ GetSexPhrase("baron", "baronne") +", pas simplement capitaine !.. Eh bien, en l'occurrence, oui, je vous ai sauvés, et c'est une grande joie pour moi...";
				link.l1.go = "exit";
			}
			// Gregg: the "Black Orchid" (ported from Damned Destiny) - the hint about
			// where Lanven went. The attribute may not exist at all, hence a separate
			// check: Storm has no short-circuit, the conditions cannot be merged.
			if (CheckAttribute(PChar, "MysteriousArtefact"))
			{
				if (PChar.MysteriousArtefact == "13")
				{
					link.l2 = "Pardonnez-moi de vous arracher à vos affaires, mais j'ai une question. Savez-vous oם se trouve Stefan Lanven en ce moment ?";
					link.l2.go = "MysteriousArtefact_1";
				}
			}
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;

        //==> Двенадцатый квест исп.линейки: захват Порт-о-Принса.
        case "SpaLine12Quest_PortPax":
			dialog.text = "Nous nous rendons, "+ GetSexPhrase("maudit Castillan", "maudite Espagnole") +"...";
			link.l1 = "Voilà qui est bien : vous avez sauvé vos vies.";
			link.l1.go = "Step_S12_1";
			AfterTownBattle();
        break;
        case "Step_S12_1":
			dialog.text = "C'est une colonie française, que diable...";
			link.l1 = "C'est désormais une colonie espagnole, une fois pour toutes. Bon, je ne vous retiens pas, monsieur l'ancien gouverneur...";
			link.l1.go = "exit";
            AddQuestRecord("Spa_Line_12_OccupyPortPax", "2");
			pchar.questTemp.State = "OccupyPortPax_WeWin";
            NextDiag.TempNode = "Cupture_after";
			PChar.questTemp.DontSetNewDialogToMayor = true; // иначе может сменить диалог и сбойнуть
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(NPChar.City, sti(PChar.nation));
            DeleteAttribute(PChar, "questTemp.DontSetNewDialogToMayor");
            UpdateRelations();
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
            SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
            AddDialogExitQuestFunction("LaunchColonyInfoScreen"); // табличка
        break;
		//==> Gregg: the Black Orchid - a mysterious artefact
		case "MysteriousArtefact_1":
			dialog.text = "Stefan Lanven est parti pour la Martinique pour affaires.";
			link.l1 = "Merci.";
			link.l1.go = "MysteriousArtefact_2";
		break;

		case "MysteriousArtefact_2":
			dialog.text = "Hé, attendez ! Un espion ennemi se promène en liberté dans ma ville. Vous ne voudriez pas l'attraper pour moi ?";
			link.l1 = "Pas le temps. Confiez ce travail à quelqu'un d'autre.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactTalkWithMayor");
		break;
		//<== Gregg: the Black Orchid

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

