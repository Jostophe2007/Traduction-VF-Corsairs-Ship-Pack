
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sBlade;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Capitaine, c'est une chance de vous avoir rencontré ! Pouvez-vous m'aider ?";
			link.l1 = "Qu'y a-t-il ?";
			link.l1.go = "1";
			UnmarkCharacter(npchar);
			
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Je me rendais à Niévès, mais une violente tempête a bouleversé tous mes plans. א cause d'une erreur de navigation, nous nous sommes retrouvés près du récif du Squelette, et le navire s'est échoué sur les rochers. J'ai eu la chance d'atteindre cette colonie dans la seule chaloupe restée intacte... Je vous en supplie, sauvez la précieuse cargaison et mon équipage !";
			link.l1 = "Le récif du Squelette n'est pas loin d'ici... Je ne me souviens plus... De quelle récompense parliez-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je vous donnerai la moitié de la valeur des marchandises, mais il faut vous dépêcher. Mes hommes n'ont plus que deux semaines de vivres, au mieux.";
			link.l1 = "Hum, et oם exactement votre navire s'est-il échoué ?";
			link.l1.go = "3";
			link.l2 = "Non, capitaine, j'ai mes propres affaires. Débrouillez-vous sans moi.";
			link.l2.go = "2.5";
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
		break;
		
		case "2.5":
			sld = CharacterFromID("KSM_Alloka")
			LAi_CharacterDisableDialog(sld);
			sld.lifeday = 0;
		
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "3":
			dialog.text = "א peu près au sud-est du rocher central en forme de haute arche. Difficile de se tromper.";
			link.l1 = "Marché conclu, essayons de retrouver vos biens.";
			link.l1.go = "Exit1";
		break;

		case "REEFS":
			dialog.text = "Vous avez fait du beau travail, capitaine. Il est temps de vous rendre la pareille.";
			link.l1 = "De quoi parlez-vous ? Et votre équipage affamé, la précieuse cargaison qui pourrit dans la cale ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Vous n'avez pas encore compris ? Comme vous êtes crédule. Mon navire s'est vraiment fracassé sur ces rochers, et il n'y avait qu'un seul moyen d'en obtenir un nouveau...";
			link.l1 = "Prendre au piège "+ GetSexPhrase("un simplet crédule", "une naïve crédule") +".";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "C'est exact, capitaine, et à ma grande joie, il s'est avéré que c'était vous. Adieu...";
			link.l1 = "C'est une embuscade ! Aux armes !";
			link.l1.go = "Exit2";
		break;

		case "Piers":
			dialog.text = "Capitaine, votre lenteur va vous coמter la vie !";
			link.l1 = "Oui, je comprends... א vrai dire, je n'avais pas la tête à sauver vos hommes...";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Mes hommes ? Au diable mes hommes. Vous n'êtes pas tombé dans le piège, vous n'avez pas laissé prendre votre navire ! Oh, vous allez me le payer !";
			link.l1 = "Maudit intrigant !";
			link.l1.go = "Exit3";
		break;
		
		
		case "Exit1":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("KSM_Snr_EndloosTraider");
		break;

        case "Exit2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("KSM_Snr_EndloosTraiderKill");
		break;
	}
}
