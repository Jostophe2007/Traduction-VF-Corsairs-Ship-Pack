// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 7 - a false trail, the tavern keeper knows nothing
			if (CheckAttribute(PChar, "SmallMongrel"))
			{
				if (PChar.SmallMongrel == "7")
				{
					link.l30 = "Une frégate lourde a-t-elle mouillé dans votre baie ?";
					link.l30.go = "BO_SM_LT_1";
				}
			}
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "BlackLabel_toLaVega")
			{
				link.l1 = "Dis-moi, l'ami, Edward Law habite-t-il dans ta ville ?";
				link.l1.go = "PL_Q2_1";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_toSeek")
			{
				link.l1 = "L'ami, je reviens te voir... Dis-moi, oם est allé Edward Law ? J'ai besoin de lui de toute urgence...";
				link.l1.go = "PL_Q3_1";
			}
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_LeFrancuaTaverna_1")) //Квест "Strange things are happening in the archipelago"
			{
				link.l1 = "J'aimerais savoir si une frégate noire nommée « Mephisto » est entrée dans la baie ?";
				link.l1.go = "PKM_SvtvA_1";
			}

			//-->ОЗГ
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
	    		if (pchar.questTemp.Headhunter == "vector_barmen")
				{
					link.l1 = "Bonjour. C'est votre ami, l'un des contrebandiers, qui m'envoie. Il m'a dit que vous cherchiez quelqu'un pour une certaine mission.";
					link.l1.go = "Barmen_check";
					break;
				}

				if (npchar.city == "LeFransua" && pchar.questTemp.Headhunter == "barmen_wait")
				{
					link.l1 = "Bonjour, " + npchar.name + ". C'est encore moi. Qu'en est-il de votre mission ?";
					link.l1.go = "Barmen_check";
					break;
				}
				if (pchar.questTemp.Headhunter == "hunt_carlos_yes")
				{
					link.l1 = "Bonjour, " + npchar.name + ". J'ai de bonnes nouvelles. Carlos le Caissier est éliminé.";
					link.l1.go = "Endtaskhunt_1";
				}
				if(pchar.questTemp.Headhunter == "next_task_2" && GetQuestPastDayParam("pchar.questTemp.Headhunter_next_task_2") > 9)
				{
					link.l1 = "Bonjour, " + npchar.name + ". Me voilà, comme convenu. Avez-vous obtenu des informations utiles ?";
					link.l1.go = "Givetaskhunt_2";
				}
				if (pchar.questTemp.Headhunter == "hunt_houm_yes")
				{
					link.l1 = "Bonjour, " + npchar.name + ". J'ai réussi à envoyer Hannibal Holm nourrir les poissons, même si ça n'a pas été facile.";
					link.l1.go = "Endtaskhunt_2";
				}
				if(pchar.questTemp.Headhunter == "next_task_3" && GetQuestPastDayParam("pchar.questTemp.Headhunter_next_task_3") > 14)
				{
					link.l1 = "Bonjour, " + npchar.name + ". J'espère que je suis à l'heure ?";
					link.l1.go = "Givetaskhunt_3";
				}
				if (pchar.questTemp.Headhunter == "hunt_rat_yes1")
				{
					link.l1 = "J'arrive avec de bonnes nouvelles, " + npchar.name + ". J'ai réussi à faire sortir le Rat de son trou. J'ai rattrapé son navire, et je l'ai envoyé lui-même chez Davy Jones.";
					link.l1.go = "Endtaskhunt_3";
				}
				if (pchar.questTemp.Headhunter == "hunt_rat_yes2")
				{
					link.l1 = "J'arrive avec de bonnes nouvelles, " + npchar.name + ". J'ai réussi à faire sortir le Rat de son trou. Je l'ai envoyé chez Davy Jones avec son navire.";
					link.l1.go = "Endtaskhunt_3";
				}
				if(pchar.questTemp.Headhunter == "next_task_4" && GetQuestPastDayParam("pchar.questTemp.Headhunter_next_task_4") > 17)
				{
					link.l1 = "Mes salutations, " + npchar.name + ". Me voilà. Quelles sont les nouvelles ?";
					link.l1.go = "Givetaskhunt_4";
				}
				if (pchar.questTemp.Headhunter == "hunt_halen_yes")
				{
					link.l1 = "Martin van Halen ne troublera plus la paix des habitants du François, " + npchar.name + ".";
					link.l1.go = "Endtaskhunt_4";
				}
				if(pchar.questTemp.Headhunter == "hunt_ja_yes")
				{
					link.l1 = "Bonjour, " + npchar.name + ". Il est vraiment de bonne humeur aujourd'hui. La bande de Ja Preston, c'est fini pour de bon.";
					link.l1.go = "Endtaskhunt_5";
				}
			}
		break;
		//Квест "Strange things are happening in the archipelago"
		case "PKM_SvtvA_1":
			dialog.text = "Ces fous ? Oui, ils étaient ici, mais je ne vous conseille pas d'avoir affaire à eux. Ces lascars se sont battus ici avec un type, et en un instant ils lui ont dessiné un nouveau sourire, je n'ai même pas eu le temps de cligner des yeux.";
			link.l1 = "Merci de l'avertissement, mais je dois les trouver.";
			link.l1.go = "PKM_SvtvA_2";
		break;
		case "PKM_SvtvA_2":
			dialog.text = "Je ne peux pas vous aider : ces gars sont partis quelque part. Mais j'ai entendu dire que l'église de Fort-de-France s'intéressait à ces types en robe rouge. Vous devriez y aller et vous renseigner sur place.";
			link.l1 = "C'est ce que je vais faire. Merci, mon ami !";
			link.l1.go = "exit";
			AddQuestRecord("PKM_Animists", "7");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_LeFrancuaTaverna_1");
			pchar.questTemp.PKM_SvtvA_FortFranceChurch_1 = "Church1";
		break;
		
		//пиратка, квест №2, чёрная метка для Лоу
		case "PL_Q2_1":
			dialog.text = NPCStringReactionRepeat("Comment ça, s'il habite ici ? Il y habite, et comment.",
				"Je vous ai déjà dit qu'il habite ici.",
				"Il habite ici, il habite ici...",
                ""+ GetSexPhrase("Vous me fatiguez", "Vous me fatiguez") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Comment le trouver, vous pouvez me le dire ?",
				"Oui, oui, je comprends...",
                "Compris.",
				"...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q2_2", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q2_2":
			dialog.text = "Pourquoi pas ? Je vais vous le dire, "+ GetSexPhrase("à une brave personne", "à une si jolie fille") +" - ça fait plaisir de rendre service. C'est très facile à trouver. Sortez de la taverne, tournez à droite et allez tout droit jusqu'au bout. La maison en planches, c'est celle d'Edward Law.";
			link.l1 = "Merci, l'ami !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_2_BlackLabel", "2");
		break;
		//пиратка, квест №3, поиски Лоу
		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Euh, "+ GetSexPhrase("vous arrivez trop tard, l'ami", "vous arrivez trop tard, ma belle") +". Il est parti de la ville, parti pour de bon.",
				"Je vous ai déjà dit que Law avait quitté la ville.",
				"Il est parti, il est parti...",
                "Oh, ce que vous êtes"+ GetSexPhrase(" agaçant", " agaçante") +" !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oם est-il allé ?",
				"Oui, je m'en souviens.",
                "Oui, "+ GetSexPhrase("J'ai oublié", "J'ai oublié") +"...",
				"Je comprends, je m'en vais...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q3_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q3_2":
			dialog.text = "Qui sait ? Il a tout vendu en vitesse et il est parti... Le pire, c'est qu'il n'a pas pris le tonneau, alors qu'il l'avait demandé. « Mets-moi de cכté un tonneau de rhum de la Jamaïque », qu'il me dit. Il devait être pressé. Bah, tant pis, j'ai déjà casé le tonneau...";
			link.l1 = "Attends un peu avec ton tonneau. Dis-moi plutכt oם je dois le chercher maintenant ?";
			link.l1.go = "PL_Q3_3";
		break;
		case "PL_Q3_3":
			dialog.text = "Oh, je ne sais pas... On dit qu'il est parti acheter un navire. Demandez aux gens, quelqu'un a peut-être vu quelque chose, quelqu'un sait peut-être quelque chose. Moi, je n'en sais rien, puisqu'il n'est pas venu chercher son tonneau. Et c'était un bon tonneau...";
			link.l1 = "Compris... Merci, mon ami.";
			link.l1.go = "exit";
		break;

		case "Barmen_check":
			if (IsEquipCharacterByItem(Pchar, "patent_eng") || IsEquipCharacterByItem(Pchar, "patent_fra") || IsEquipCharacterByItem(Pchar, "patent_spa") || IsEquipCharacterByItem(Pchar, "patent_hol"))
			{
				dialog.text = "Vous n'appartenez pas aux Frères de la Cכte : vous êtes un corsaire muni d'une lettre de marque. Je ne peux pas vous faire confiance, désolé.";
				link.l1 = "Oh, quel dommage !";
				link.l1.go = "exit";
				CloseQuestHeader("Headhunt");
				pchar.questdata.Kondotier = 1;
				pchar.questTemp.Headhunter = "end_quest";
				break;
			}
			if (sti(Pchar.Rank) < 5)
			{
				dialog.text = "Hum... J'ai un travail, mais j'ai bien peur que vous ne soyez pas capable de le faire. Ne vous vexez pas, je ne veux simplement pas que vous mouriez pour rien. Revenez plus tard, quand vous aurez plus d'expérience.";
				link.l1 = "Compris. Bon, je repasserai plus tard.";
				link.l1.go = "exit";
				pchar.questTemp.Headhunter = "barmen_wait";
				break;
			}
			/* if (sti(Pchar.Rank) > 12)
			{
				dialog.text = "Um... I'm sorry, but I've already found someone to do this job. So don't blame me, Captain.";
				link.l1 = "Clear. So it's not fate. Goodbye.";
				link.l1.go = "exit";
				pchar.questTemp.Headhunter = "end_quest";
				break;
			} */
			dialog.text = "Vous tombez à pic ! J'ai besoin d'un capitaine comme vous. Laissez-moi vous exposer le fond du problème, puis nous passerons directement à la mission.";
			link.l1 = "Je vous écoute attentivement, "+ npchar.name +".";
			link.l1.go = "barmen_history";
		break;

		case "barmen_history":
			dialog.text = "En somme, l'histoire est la suivante. Comme vous le savez sans doute, chaque colonie de chasseurs et de boucaniers a son propre chef. Edward Mansfield dirige La Vega, Sawkins dirige Puerto Príncipe, le bras droit de Morgan, Jackman, dirige les Bermudes, et Bartholomew Rogers dirige la nכtre. Chaque chef de colonie est connu et respecté chez les Frères de la Cכte et occupe son poste depuis longtemps, mais tout a un début et une fin. L'existence paisible de notre colonie a elle aussi pris fin. Une bande de gredins et de brutes notoires a décidé de profiter de la situation pour prendre Le François en main. Non seulement ils intimident les pêcheurs et les colons en leur imposant un tribut, mais ils forcent aussi des gens plus... respectables à leur reverser une part de leurs bénéfices ! Ces honnêtes gens ne peuvent rien faire... Vous comprenez, capitaine ? Et notre chef, Bartholomew Rogers, soit ne voit rien, soit préfère ne rien voir, je ne sais pas, mais il est bien évident que, malgré les plaintes reçues, il n'a pris aucune mesure. Pire, il a accusé les mécontents de chercher à obtenir une réduction de leurs versements au trésor des Frères de la Cכte. Morgan est loin et occupé par ses intrigues politiques à Port Royal, Mansfield ne s'intéresse qu'à ses boucaniers, Sawkins est embourbé dans les querelles internes des Frères de la Cכte, et Jackman se moque de tout, sauf de remplir sa bourse ! Ainsi, nous avons tous été livrés en pâture à une bande de sales escrocs.\n Pire encore, ces honnêtes gens sont convaincus que tout ce qui se passe n'est qu'un début, le premier pas vers un nouveau partage de l'influence en Martinique. La prochaine étape sera l'éviction de Rogers lui-même, et ensuite, on ne sait pas.";
			link.l1 = "Hum... Et pourquoi ces honnêtes gens dont vous parlez n'envoient-ils pas un messager à Morgan pour informer l'amiral des abus qui se passent ici ?";
			link.l1.go = "barmen_history_1";
		break;

		case "barmen_history_1":
			dialog.text = "Eh, "+ GetSexPhrase("monsieur", "mademoiselle") +", si seulement c'était aussi simple. Morgan se moque de ce qui se passe en ce moment dans notre colonie perdue. On a essayé plus d'une fois d'attirer son attention, sans résultat ; alors les gens respectables, opprimés par ces gredins, ont décidé d'agir par eux-mêmes. Ils cherchent un homme, un pirate sans renommée chez les Frères de la Cכte, et ils sont prêts à le payer comme il se doit.";
			link.l1 = "Si je comprends bien, nous en venons directement à mon rכle dans la campagne prévue ?";
			link.l1.go = "barmen_history_2";
		break;

		case "barmen_history_2":
			dialog.text = "Oui, c'est exact. Puisque les chefs pirates ne font rien et qu'on ne peut plus supporter la situation actuelle, il a été décidé de répondre aux gredins dans leur propre langage. Retrouver et éliminer toute la bande un par un : c'est pour cela que je cherche la bonne personne. זtes-vous prêt à vous lancer dans cette affaire ? Le paiement sera généreux, je vous le garantis.";
			link.l1 = "Autrement dit, si je comprends bien, je dois jouer les chasseurs de primes ?";
			link.l1.go = "barmen_history_3";
		break;

		case "barmen_history_3":
			dialog.text = "C'est exact. La vue du sang ne vous fait pas peur, n'est-ce pas ? Surtout si ce sang est entièrement payé, et pas seulement en or.";
			link.l1 = "Puis-je connaître le montant de la récompense avant de donner mon accord ?";
			link.l1.go = "barmen_history_4";
		break;

		case "barmen_history_4":
			dialog.text = "Absolument. Ces chers et honnêtes gens dont je vous parle depuis si longtemps offrent, à qui traquera et enverra en enfer tous ces gredins, une somme de cent mille piastres et un magnifique ensemble d'armes et d'équipement, comprenant un Thanat, un mousquet, une longue-vue exceptionnelle, une cuirasse d'officier et un dieu-rat. Qu'en dites-vous ?";
			link.l1 = "Oui, la récompense est conséquente. Je crois que je vais accepter cette affaire.";
			link.l1.go = "barmen_history_5";
			link.l2 = "C'est tout ? Vous voulez que j'affronte une bande qui s'est emparée de toute une colonie, pour trois sous et quelques breloques pitoyables ?! Cherchez l'imbécile ailleurs.";
			link.l2.go = "exit_quest";
		break;

		case "exit_quest":
			dialog.text = "Désolé. On dirait que je me suis trompé sur votre compte. Alors oublions cette conversation.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "end_quest";
			pchar.questdata.Kondotier = 1;
			CloseQuestHeader("Headhunt");
		break;

		case "barmen_history_5":
			dialog.text = "Parfait ! Je suis très content que vous ayez accepté. En plus de la rémunération déjà mentionnée pour l'ensemble du travail, je dois vous verser une récompense pour chacun des membres de la bande, afin de compenser au moins en partie vos frais ; les gars se réunissent rarement, et les attaquer ensemble serait trop risqué. Vous les traquerez donc un par un.";
			link.l1 = "Eh bien, passons aux affaires. Racontez-nous plus en détail ce que vous savez de cette bande. Il y aura peut-être des indices ?";
			link.l1.go = "barmen_history_6";
		break;

		case "barmen_history_6":
			dialog.text = "Bien sמr. Il sera extrêmement difficile et dangereux d'en venir à bout, même de cette façon, c'est pourquoi on vous apportera toute l'aide possible en matière d'informations. Par mon humble intermédiaire, vous recevrez des renseignements sur l'endroit oם se trouvent les scélérats et vous les éliminerez séparément : non seulement des mercenaires et des capitaines pirates, mais aussi des personnages tout à fait étranges qui font commerce de leurs sombres actions dans nos eaux troubles. Ils sont menés par un certain Ja Preston. Le bruit court qu'il est le capitaine de l'insaisissable frégate Acheron, le fléau des marchands des Caraïbes dont tout le monde parle ces derniers temps. Et j'ai toutes les raisons de croire que c'est bien le cas.";
			link.l1 = "Il s'avère que la liste des victimes sera longue...";
			link.l1.go = "barmen_history_7";
		break;

		case "barmen_history_7":
			dialog.text = "Oui. En fait, elle est même plus longue : après tout, beaucoup ont leurs propres navires, avec des équipages complets de brutes désespérées, et l'un d'eux, dont le nom ne vous dira encore rien, est même une personne proche des autorités, avec des relations très, très sérieuses. Mais, encore une fois, on peut les attraper un par un. Ces lascars se déplacent sans cesse à travers les Caraïbes, il n'est donc pas facile de les retrouver. Mais il y a beaucoup de marins et beaucoup de rhum dans ma taverne, ce qui veut dire beaucoup de marins ivres et bavards, hé hé... Je pourrai donc vous aider en quelque chose.";
			link.l1 = "Eh bien, pour l'instant, tout est clair pour moi. Inutile de nommer vos « honnêtes gens », ce sont mes futures victimes qui m'intéressent bien davantage.";
			link.l1.go = "Givetaskhunt_1";
		break;

		case "Givetaskhunt_1":
			SelectCarlosCity();
			dialog.text = "Eh bien, commençons. La première personne que vous devez retrouver est Carlos Cashier : c'est un mercenaire, et pour autant que je sache, il est actuellement en ville. " + pchar.questTemp.Headhunter.Cityname + ". Je suis prêt à parier ma taverne contre un chapeau troué : vous trouverez facilement ce gredin à la taverne ou au bordel ; il doit être en train de dépenser l'argent volé en tord-boyaux et en filles. Il a tué un homme qui refusait de le payer, ici, dans la colonie, et ça a été, soit dit en passant, la goutte qui a fait déborder le vase. Quand vous le rencontrerez, essayez de faire en sorte que ça ressemble à un duel : vous ne voulez pas d'ennuis avec les autorités, n'est-ce pas ? Pour sauver sa peau, le Caissier est prêt à tout ; mais jouez sur sa fierté, insultez-le et forcez-le à accepter le défi, sans révéler vos intentions : si vous l'effrayez une fois, vous ne le retrouverez plus. Il manie bien la lame, mais souvenez-vous : quoi que vous fassiez, n'attendez pas de lui un combat loyal, c'est un mercenaire, pas un gentilhomme.";
			link.l1 = "Eh bien, je ne vais pas perdre de temps. J'y vais !";
			link.l1.go = "Givetaskhunt_1_1";
			pchar.questTemp.Headhunter = "hunt_carlos";
			pchar.questTemp.Headhunter.Chance = rand(1);
			CreateCarlos();
		break;

		case "Givetaskhunt_1_1":
			dialog.text = "Je vous souhaite bonne chance. Et autre chose : pour toute question liée à cette affaire, adressez-vous uniquement à moi. Les gens respectables... que nous aidons, vous et moi, aimeraient garder leur nom secret, en cas d'imprévu.";
			link.l1 = "Compris. א bientכt, " + npchar.name + " !";
			link.l1.go = "exit";
            AddQuestRecord("Headhunt", "1");
			AddQuestUserData("Headhunt", "sCity", pchar.questTemp.Headhunter.Cityname);
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
		break;

		case "Endtaskhunt_1":
			dialog.text = "Parfait ! Il y a un gredin de moins en ce monde. Nous avons préparé un dédommagement pour vos efforts. Prenez cinq mille en espèces et ce coffre d'or. Revenez dans dix jours : je devrais avoir des informations qui vous aideront à trouver le gredin suivant.";
			link.l1 = "Merci pour l'or ! Et à dans dix jours.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "next_task_2";
			SaveCurrentQuestDateParam("pchar.questTemp.Headhunter_next_task_2");
			AddMoneyToCharacter(pchar, 5000);
			TakeNItems(pchar, "chest", 1);
			Log_Info("Vous avez reçu un coffre de crédit");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("Headhunt", "3");
		break;

		case "Givetaskhunt_2":
			if (IsEquipCharacterByItem(Pchar, "patent_eng") || IsEquipCharacterByItem(Pchar, "patent_fra") || IsEquipCharacterByItem(Pchar, "patent_spa") || IsEquipCharacterByItem(Pchar, "patent_hol"))
			{
				dialog.text = "Vous n'appartenez plus aux Frères de la Cכte : vous êtes désormais un corsaire muni d'une lettre de marque. Je ne peux pas vous faire confiance, désolé.";
				link.l1 = "Oh, quel dommage !";
				link.l1.go = "exit";
				CloseQuestHeader("Headhunt");
				pchar.questdata.Kondotier = 1;
				pchar.questTemp.Headhunter = "end_quest";
				break;
			}
			pchar.questTemp.Headhunter.Chance = rand(4);
			pchar.questTemp.Headhunter.Chance1 = rand(1);
			SelectHoumCity();
			dialog.text = "Oui. Comme je vous l'ai dit, on peut tout apprendre des marins ivres. J'ai récemment appris quelque chose sur Hannibal Holm. C'est un ancien esclave, rusé, perfide et impitoyable. On dit qu'il mange le cœur de ses ennemis selon les coutumes sauvages de sa tribu... brr. Bref. Il a récemment attaqué une caravane marchande hollandaise qui transportait de l'argent. Bien des braves Yankees se sont présentés devant le Seigneur lors de ce combat acharné. Et maintenant, il se cache des Hollandais dans les colonies anglaises. Plus précisément, hélas, je ne peux pas vous dire : renseignez-vous dans les ports sur son navire, le « Deadhead ». C'est un navire costaud et remarquable, je suis sמr qu'il sera difficile de le manquer. Je pense que Hill s'est déjà acheté une place au soleil chez les Anglais avec l'argent capturé, alors les autorités le couvriront : soyez prêt.";
			link.l1 = "La mission est claire. Je lève l'ancre !";
			link.l1.go = "Givetaskhunt_2_1";
		break;

		case "Givetaskhunt_2_1":
			pchar.questTemp.Headhunter = "Houm";
			AddQuestRecord("Headhunt", "4");
			//Log_Info("Home in is in "+pchar.questTemp.Headhunter.Cityname+"");
			DialogExit();
		break;


		case "Endtaskhunt_2":
			dialog.text = "Excellent. Je suis heureux de ne pas m'être trompé sur votre compte. Voici votre récompense. Revenez me voir dans deux semaines : mes collègues et moi sommes en train de réunir des informations sur le troisième gredin.";
			link.l1 = "D'accord. Je serai là dans deux semaines.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "next_task_3";
			SaveCurrentQuestDateParam("pchar.questTemp.Headhunter_next_task_3");
			AddMoneyToCharacter(pchar, 10000);
			TakeNItems(pchar, "chest", 2);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("Headhunt", "9");
		break;

		case "Givetaskhunt_3":
			dialog.text = "Ravi de vous voir, " + pchar.name + ". L'affaire suivante est dangereuse, de toute façon. De plus, il vous faudra agir davantage par la ruse que par l'épée.";
			link.l1 = "Eh bien, je ne dirais pas que les deux « affaires » précédentes étaient une simple promenade... Je vous écoute attentivement.";
			link.l1.go = "Givetaskhunt_3_1";
		break;

		case "Givetaskhunt_3_1":
			if (IsEquipCharacterByItem(Pchar, "patent_eng") || IsEquipCharacterByItem(Pchar, "patent_fra") || IsEquipCharacterByItem(Pchar, "patent_spa") || IsEquipCharacterByItem(Pchar, "patent_hol"))
			{
				dialog.text = "Vous n'appartenez plus aux Frères de la Cכte : vous êtes désormais un corsaire muni d'une lettre de marque. Je ne peux pas vous faire confiance, désolé.";
				link.l1 = "Oh, quel dommage !";
				link.l1.go = "exit";
				CloseQuestHeader("Headhunt");
				pchar.questdata.Kondotier = 1;
				pchar.questTemp.Headhunter = "end_quest";
				break;
			}
			dialog.text = "Le client suivant est Mathias Green, plus connu sous le nom du Rat. C'est un sale type, il a l'air d'un marchand inoffensif, mais il a déjà des dizaines de navires disparus sur la conscience. Ils disparaissent tout simplement, puis des rumeurs se répandent dans les tavernes, selon lesquelles c'est ce fameux « Rat » qui les a eus. Et ce sont des rumeurs avec une description précise de la cargaison ; les navires eux-mêmes, ce gredin les cache parfaitement, mais il n'oublie jamais de faire courir des rumeurs sur ses exploits, il est vaniteux, le gredin. Seuls ceux qui sont montés à bord et ont vu les cales de leurs propres yeux peuvent connaître avec autant de détails la quantité de cargaison et la description des navires disparus... Vous voyez oם je veux en venir ? Et en plus, il ne laisse aucun témoin vivant.";
			link.l1 = "Pouvez-vous me dire quelque chose sur l'endroit oם se trouve ce... ce rat ?";
			link.l1.go = "Givetaskhunt_3_2";
		break;

		case "Givetaskhunt_3_2":
			dialog.text = "Malheureusement, pas grand-chose. Je ne peux même pas vous dire sur quel navire il se trouve : le Rat change souvent de navire pour brouiller les pistes. Je peux seulement vous nommer les ports d'oם sont partis les trois derniers navires disparus, dont nous pensons que le Rat est responsable de la disparition ; il vaudrait peut-être la peine d'en savoir plus sur les circonstances qui ont précédé ces tristes événements dans ces villes : Willemstad, à Curaçao, Carthagène, sur le Continent, et Port-d'Espagne, sur l'île de la Trinité.";
			link.l1 = "C'est déjà quelque chose ! Je crois qu'il est temps que je me mette en route.";
			link.l1.go = "Givetaskhunt_3_3";
		break;

		case "Givetaskhunt_3_3":
			dialog.text = "Prenez ces vêtements discrets : ils vous aideront à vous déplacer sans vous faire remarquer dans les villes ennemies. Et avant votre départ, je veux vous donner quelques conseils. Mathias est une bête rusée : essayez de le comprendre, de voir quoi et comment il chasse. Laissez le Rat jouer son coup quand vous l'aurez rattrapé. Si vous faites preuve d'agressivité, les autorités pourraient considérer vos actes comme une attaque gratuite, car cette créature ne navigue sans doute pas ouvertement sous le Jolly Roger. Attirez-le avec ce qui l'intéresse, et frappez quand il sera sמr d'avoir gagné ; mais souvenez-vous d'une chose : un rat, même acculé, peut être mortel. C'est sans doute tout, capitaine. Bonne chasse.";
			link.l1 = "Merci pour ces explications. Attendez-moi avec de bonnes nouvelles.";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "Rat";
			pchar.questTemp.Headhunter.count = 0;
			pchar.questTemp.Headhunter.countC = 0;
			pchar.questTemp.Headhunter.countV = 0;
			pchar.questTemp.Headhunter.countP = 0;
			AddQuestRecord("Headhunt", "11");
			TakeNItems(pchar, "suit_1", 1);
			Log_Info("Vous avez reçu les haillons");
			PlaySound("interface\important_item.wav");
		break;

		case "Endtaskhunt_3":
			dialog.text = "Excellent travail, " + pchar.name + ". Je vous admire sincèrement. Non seulement vous savez vous battre, mais vous êtes aussi très rusé. Tromper le Rat est une tâche plus que difficile. Et pourtant, vous y êtes arrivé. Voici votre argent et un petit cadeau ; revenez dans quinze ou vingt jours : je pense qu'on aura alors réuni assez d'informations sur l'endroit oם se trouve un autre gredin.";
			link.l1 = "Merci ! Je serai là au moment dit. Bonne chance !";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "next_task_4";
			SaveCurrentQuestDateParam("pchar.questTemp.Headhunter_next_task_4");
			AddMoneyToCharacter(pchar, 20000);
			TakeNItems(pchar, "chest", 2);
			TakeNItems(pchar, "Totem_"+(rand(9)+1), 1);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			AddQuestRecord("Headhunt", "25");
		break;

		case "Givetaskhunt_4":
			if (IsEquipCharacterByItem(Pchar, "patent_eng") || IsEquipCharacterByItem(Pchar, "patent_fra") || IsEquipCharacterByItem(Pchar, "patent_spa") || IsEquipCharacterByItem(Pchar, "patent_hol"))
			{
				dialog.text = "Vous n'appartenez plus aux Frères de la Cכte : vous êtes désormais un corsaire muni d'une lettre de marque. Je ne peux pas vous faire confiance, désolé.";
				link.l1 = "Oh, quel dommage !";
				link.l1.go = "exit";
				CloseQuestHeader("Headhunt");
				pchar.questdata.Kondotier = 1;
				pchar.questTemp.Headhunter = "end_quest";
				break;
			}
			dialog.text = "Il y a du nouveau. Cette fois, d'ailleurs, les informations sont très claires. Nous avons appris oם se trouvera prochainement le quatrième membre de la bande, le Hollandais Martin van Halen. Il doit arriver à Willemstad d'ici une semaine, au retour d'une nouvelle razzia pirate. Il faut vous rendre à Curaçao...";
			link.l1 = "Eh bien, je n'aurai pas à perdre mon temps à errer dans l'archipel comme la dernière fois. C'est bien.";
			link.l1.go = "Givetaskhunt_4_1";
		break;

		case "Givetaskhunt_4_1":
			dialog.text = "Attendez, capitaine, ce n'est pas tout. Martin van Halen n'est pas un simple pirate, mais un corsaire au service de la Hollande ; de plus, c'est un proche de Stuyvesant lui-même. Il couvre les autres gredins et leur fournit des relations dans les plus hautes sphères. Ce jouvenceau est arrogant et hautain, mais en même temps très prudent. Je ne pense pas qu'il se laisse prendre à la moindre ruse ; dans ce cas, il faudra peut-être agir par la force brute. Mais attention : si vous attaquez van Halen à découvert, vous devrez combattre toute la garnison de Willemstad.";
			link.l1 = "D'accord, j'en tiendrai compte. א plus tard, " + npchar.name + ".";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "hunt_halen";
			AddQuestRecord("Headhunt", "26");
			SetFunctionTimerCondition("Headhunter_HalenOver", 0, 0, 10, false);
		break;

		case "Endtaskhunt_4":
			dialog.text = "Je suis heureux. Bon sang, je suis heureux que vous ayez accepté de nous aider. Vous êtes vraiment une personne irremplaçable, " + pchar.name + ". Voici votre récompense : de l'argent et un cadeau. Et...";
			link.l1 = "Attendez, " + npchar.name + ". Nous avons des problèmes. Plus précisément, j'ai des problèmes. Pour l'instant, il n'y a que moi. Ja Preston a appris d'une façon ou d'une autre QUI éliminait ses hommes. א Willemstad, des tueurs envoyés par lui ont essayé de m'assassiner.";
			link.l1.go = "Endtaskhunt_4_1";
			AddMoneyToCharacter(pchar, 25000);
			TakeNItems(pchar, "chest", 2);
			TakeNItems(pchar, "Totem_"+(rand(9)+1), 1);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
		break;

		case "Endtaskhunt_4_1":
			dialog.text = "Oh mon Dieu, vraiment... Il l'a appris ? C'en est fini, alors, nous sommes perdus. Ces... Les tueurs venaient de Ja ? Comment savez-vous que c'est lui qui les a envoyés ? א quoi ressemblaient-ils ?";
			link.l1 = "Hé... Avant de m'attaquer, ils m'ont transmis les salutations... de Ja Preston. א quoi ils ressemblaient ? Tout en noir, avec des chapeaux et des foulards sur le visage.";
			link.l1.go = "Endtaskhunt_4_2";
		break;

		case "Endtaskhunt_4_2":
			dialog.text = "Oui. Ce sont ses hommes. Il n'y a aucun doute. Et moi qui commençais à espérer...";
			link.l1 = "" + npchar.name + ", calmez-vous. Pour l'instant, Ja ne les a envoyés qu'après mon âme, et je suis tout à fait capable de me défendre. Le fait que vous soyez encore en vie signifie qu'il ne sait pas encore que vous êtes mêlé à l'affaire, ni ces fameux « honnêtes gens » dont vous parliez.";
			link.l1.go = "Endtaskhunt_4_3";
		break;

		case "Endtaskhunt_4_3":
			dialog.text = "Ce ne sera pas long.";
			link.l1 = "Sans aucun doute. Il va découvrir qui était derrière tout ça. Il faut lancer une attaque préventive immédiatement. Il est temps d'en finir : arrêtons de courir après les sous-fifres, c'est Ja lui-même qu'il faut viser, sinon nos chances de survie tombent au ras de la ligne de flottaison. Il nous faut juste atteindre Preston !";
			link.l1.go = "Endtaskhunt_4_4";
		break;

		case "Endtaskhunt_4_4":
			dialog.text = "J'ai des informations sur un certain Miko Pistollero : c'est un métis indien, le bras droit de Ja. Impossible de réunir des renseignements précis, mais on l'a vu pour la dernière fois sur la cכte ouest du Continent. Je suppose qu'il se trouve maintenant dans l'un des villages de pêcheurs de perles, c'est tout ce que je sais. Vous en apprendrez peut-être davantage de Pistolero lui-même quand vous le trouverez. Quant à Ja Preston, il est insaisissable, comme d'habitude.";
			link.l1 = "C'est suffisant comme informations. Je me mets en route immédiatement. Et vous, " + npchar.name + ", je vous conseille d'être extrêmement prudent, de bien fermer portes et fenêtres la nuit et de ne pas sortir des portes de la ville. Je détesterais vraiment perdre mon employeur... avant le paiement promis.";
			link.l1.go = "Givetaskhunt_5";
		break;

		case "Givetaskhunt_5":
			dialog.text = "Merci de votre sollicitude... Je suivrai vos recommandations. Quant à Pistolero : ce n'est pas une fine lame, mais c'est un excellent tireur. Il ne se sépare jamais de son pistolet à quatre canons. C'est sa maîtrise de cette arme qui lui a valu son surnom. Soyez prudent : il peut vous transformer en passoire avant que vous ayez eu le temps de tirer votre lame.";
			link.l1 = "J'en ai vu de plus menaçants... Attendez mon retour et prenez soin de vous, " + npchar.name + " !";
			link.l1.go = "exit";
			pchar.questTemp.Headhunter = "hunt_miko";
			AddQuestRecord("Headhunt", "33");
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
			CreateMiko();
		break;

		case "Endtaskhunt_5":
			dialog.text = "Ouf... Enfin, on peut respirer. " + pchar.name + ", moi et tous les habitants du François n'oublierons jamais ce que vous avez fait pour nous. Sachez que vous serez toujours le bienvenu ici. Acceptez cet argent et cet ensemble d'équipement, comme convenu, et merci encore infiniment. Vous n'avez pas idée de ce que vous avez fait pour nous. Venez me voir plus souvent : j'aurai toujours le meilleur rhum pour vous.";
			link.l1 = "Allons, voyons, " + npchar.name + ", vous allez me faire rougir ! Je n'ai fait que remplir les termes de notre accord... Et merci pour l'équipement, il me sera très utile. Et pour l'argent aussi, bien sמr.";
			link.l1.go = "Endtaskhunt_5_1";
			AddMoneyToCharacter(pchar, 100000);
			TakeNItems(pchar, "blade28", 1);
			TakeNItems(pchar, "mushket", 1);
			TakeNItems(pchar, "spyglass5", 1);
			TakeNItems(pchar, "cirass4", 1);
			TakeNItems(pchar, "indian11", 1);
		break;

		case "Endtaskhunt_5_1":
			dialog.text = "Bonne chance à vous, " + pchar.name + ". Que le vent vous soit toujours favorable ! J'espère que vous n'oublierez pas le vieil aubergiste et que vous passerez au moins de temps en temps.";
			link.l1 = "Absolument, " + npchar.name + " ! Nous nous reverrons. א plus tard !";
			link.l1.go = "exit";
			AddQuestRecord("Headhunt", "39");
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Headhunt");
			pchar.questdata.Kondotier = 1;
			pchar.questTemp.Headhunter = "end_quest_full";
		break;
		//<--ОЗГ

		// Gregg: The Black Orchid, chapter 7 -->
		case "BO_SM_LT_1":
			dialog.text = "...(il imite)... « Une frégate a-t-elle mouillé ». Vous croyez que je reste sur le rivage à compter les navires ?";
			link.l1 = "Vous ne les comptez pas. Mais qui a bu à votre comptoir hier soir, vous vous en souvenez assez bien.";
			link.l1.go = "BO_SM_LT_2";
		break;

		case "BO_SM_LT_2":
			dialog.text = "Non, c'est vrai. Moi, je sers à boire. Pour savoir qui mouille dans la baie, demandez au magasin, les débardeurs y passent.";
			link.l1 = "Va pour le magasin. Servez les autres, je ne vous retiens pas.";
			link.l1.go = "exit";
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

