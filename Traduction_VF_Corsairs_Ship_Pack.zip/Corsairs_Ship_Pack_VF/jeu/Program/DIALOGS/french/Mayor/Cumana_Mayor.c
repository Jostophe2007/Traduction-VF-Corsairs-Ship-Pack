// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	ref sld;
	int i;
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Sp8SaveCumana_GoodWork")//квест №8 испанки.
			{
				dialog.text = RandPhraseSimple(""+ GetSexPhrase("Señor", "Señorita") +", toute la ville vous en sera reconnaissante jusqu'à la fin de ses jours. Sans vous, on n'ose même pas imaginer ce qui aurait pu arriver...", "Toute la ville a regardé le combat : c'était une grande bataille. Nous vous sommes très reconnaissants de nous avoir sauvés de ces sales pirates.");
				link.l1 = RandPhraseSimple("Oui, il ne faut pas attendre de pitié de la part des ladrones...", "Ces ladrones doivent être exterminés partout...");
				link.l1.go = "exit";
			}
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;
		//************************** Квестовые штрумы ************************
        //==> Одиннадцатый квест англ.линейки: захват Каракаса и Куманы.
        case "EngLine11Quest_OccupyMein":
			dialog.text = "Voilà, nous avons cessé de résister. La ville est à vous. Que va-t-il se passer maintenant ?";
			link.l1 = "En vertu des pouvoirs qui m'ont été conférés par le gouverneur général de la Jamaïque, je déclare cette ville possession de Charles II Stuart.";
			link.l1.go = "Step_E10_1";
			AfterTownBattle();
        break;
        case "Step_E10_1":
			dialog.text = "Bon...";
			link.l1 = "Désormais, la ville de Cumaná est sous le protectorat de l'Angleterre. Tous les impכts, droits de commerce et autres taxes devront être versés à la nouvelle administration anglaise.";
			link.l1.go = "exit";
            AddQuestRecord("Eng_Line_11_OccupyMein", "3");
            pchar.questTemp.Q11_Cumana = 1;
            NextDiag.TempNode = "Cupture_after";
			PChar.questTemp.DontSetNewDialogToMayor = true; // иначе может сменить диалог и сбойнуть
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(NPChar.City, sti(PChar.nation));
            DeleteAttribute(PChar, "questTemp.DontSetNewDialogToMayor");
            UpdateRelations();
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
			SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
            AddDialogExitQuestFunction("LaunchColonyInfoScreen"); // табличка
        break;
        //==> Шестой квест фр.линейки: захват Куманы с Олоне.
 		case "FraLine6Quest_Attack":
			dialog.text = "Notre ville est tombée... Je suis prêt à écouter vos exigences.";
			link.l1 = "Nous avons appris qu'il y a 200 000 réaux à Cumaná... Nous sommes venus pour cet argent.";
			link.l1.go = "Step_F6_1";
			group_DeleteGroup("Spa_Attack");
			AfterTownBattle();
		break;
		case "Step_F6_1":
            dialog.text = "Hum, je vois... Et si je vous dis qu'il n'y a pas d'argent ?";
			link.l1 = "וcoutez, señor, savez-vous qui est François l'Olonnais ?";
            link.l1.go = "Step_F6_2";
        break;
		case "Step_F6_2":
            dialog.text = "J'ai entendu le nom de ce suppכt du diable...";
			link.l1 = "Eh bien, l'Olonnais est mon compagnon, il a pris la ville avec moi. Et croyez-moi, si vous vous obstinez, la moitié des habitants de votre ville perdront la tête. Et l'Olonnais leur coupera la tête de ses propres mains, devant les autres. Que pensez-vous de cette perspective ?";
            link.l1.go = "Step_F6_3";
        break;
		case "Step_F6_3":
			if (GetQuestPastDayParam("questTemp") < 14)
			{
				dialog.text = "J'ai entendu dire qu'il l'avait déjà fait... Eh bien, je ne jouerai pas les héros, d'autant que des gens parfaitement innocents en pâtiraient... Tous les réaux sont dans la pièce voisine, dans le secrétaire. Prenez-les, et soyez maudits !";
				link.l1 = "Alors nous allons torturer la population de la ville...";
				link.l1.go = "Step_F6_exit";
         		pchar.GenQuestBox.Cumana_TownhallRoom = true;
				pchar.GenQuestBox.Cumana_TownhallRoom.box1.money = 200000;
				LocatorReloadEnterDisable("Cumana_townhall", "reload2", false);
				pchar.questTemp.State = "Fr5Olone_FoundMoney";
			}
			else
			{
				dialog.text = "Faites attention à ce que vous dites, monsieur. Je ne suis peut-être pas l'Olonnais, mais je vous couperai volontiers votre sale langue...";
				link.l1 = "J'ai entendu dire qu'il l'avait déjà fait, et je ne doute pas qu'il en soit encore capable. Mais il n'y a pas d'argent, c'est vrai. Il y a cinq jours, une escadre est venue le chercher. L'argent est en route vers l'Ancien Monde.";
				link.l1.go = "Step_F6_4";
			}
        break;
		case "Step_F6_4":
            dialog.text = GetSexPhrase("Señor", "Señorita") +", il est bien clair que nous sommes en votre pouvoir. En tant que gouverneur de cette ville, j'ai parfaitement conscience de la situation dans laquelle nous nous trouvons. Prenez tout ce que vous trouverez, mais l'argent pour lequel vous êtes venus n'est plus là. Vous arrivez trop tard...";
			link.l1 = "Caramba ! Je dois discuter du sort de la ville avec mes associés !";
            link.l1.go = "Step_F6_exit";
			pchar.questTemp.State = "Fr5Olone_WeLate";
        break;
		case "Step_F6_exit":
			for (i=0; i<3; i++)
			{
				if (i==0)	sld = characterFromID("Olone");
				else	sld = characterFromID("Captain_"+i);
				RemoveCharacterCompanion(pchar, sld);
				sld.dialog.currentnode = "First time";
				LAi_SetStayType(sld);
				LAi_SetCurHPMax(sld);
				LAi_LoginInCaptureTown(sld, true);
			}
			Pchar.quest.Fr6Olone_TalkWithOlone.win_condition.l1 = "location";
			Pchar.quest.Fr6Olone_TalkWithOlone.win_condition.l1.location = "Cumana_town";
			Pchar.quest.Fr6Olone_TalkWithOlone.win_condition = "Fr6Olone_TalkWithOlone";
			LAi_LocationDisableOfficersGen("Cumana_town", true); //офицеров не пускать
			chrDisableReloadToLocation = false;
			NextDiag.CurrentNode = "Cupture_after";
			SetReturn_Gover_Dialog_Exit(NPChar);
			DialogExit();
        break;

	}
    UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

