void ProcessDialogEvent()
{
    ref NPChar;
    aref Link, NextDiag;
    int i;

    DeleteAttribute(&Dialog, "Links");

    makeref(NPChar, CharacterRef);
    makearef(Link, Dialog.Links);
    makearef(NextDiag, NPChar.Dialog);

    switch (Dialog.CurrentNode)
    {
    case "Exit":
        NextDiag.CurrentNode = NextDiag.TempNode;
        DialogExit();
    break;
    case "First Time":
        dialog.text = "Chut, "+GetSexPhrase("l'ami.", "ma belle.") + " Tu cherches Luke, c'est ça ? Inutile de répondre. Je t'attends à minuit sur la plage du cap Isabela. Viens" + GetSexPhrase(" seul.", " seule.");
        link.l1 = "Hum... D'accord, j'y serai.";
        link.l1.go = "exit";
		AddDialogExitQuest("PirateGoOut");
		NextDiag.TempNode = "Isabella_1";
    break;
	case "Isabella_1":
		Pchar.quest.PirateComeToIsabellaLoose.over = "yes";
		dialog.text = "Ah, te voilà. Bon, vas-y, pourquoi as-tu besoin de Luke ?";
		link.l1 = "Et qui êtes-vous pour que je réponde à vos questions ?";
		link.l1.go = "PrepareFight";
		if (Pchar.Luke.Info == "Peace")
		{
			link.l2 = "Luke est un vieil ami. J'ai rempli sa demande. א mon retour, il n'était plus nulle part. דa m'a inquiété."
			link.l2.go = "PeaceDial";
		}
		DeleteAttribute(pchar, "Luke.Info");
	break;
	case "PrepareFight":
		dialog.text = "Tu sais au moins qui est Luke ? C'est un agent, et il n'est pas dit qu'il serve une seule nation. Qu'est-ce que tu en dis ?";
		link.l1 = "Argh ! Je n'aurais jamais pu l'imaginer ! Qu'est-ce que tu as à voir avec lui ?!";
		link.l1.go = "PrepareFight_1";
	break;
	case "PrepareFight_1":
		dialog.text = "דa ne te regarde absolument pas ! Tout ce qu'il me faut de toi, c'est ton navire.";
		link.l1 = "Ai-je bien entendu" + GetSexPhrase(" ?!", " ?!") + " Tu veux mon navire ?! Pour quoi faire ?";
		link.l1.go = "PrepareFight_2";
	break;
	case "PrepareFight_2":
		dialog.text = "Tu sais, je veux régler mes comptes avec Luke, mais on ne peut pas aller à pied jusqu'à " + XI_ConvertString("Colony" + Pchar.Luke.City + "Gen") + " ! Défends-toi !";
		link.l1 = "En garde, salaud !";
		link.l1.go = "exit";
		AddDialogExitQuest("PrepareFightAnri");
	break;
	case "PeaceDial":
		dialog.text = "Hum... Je vois. Alors, tu t'es fait avoir, toi aussi. Qu'est-ce que tu vas faire ?";
		link.l1 = "Ce serait bien de le retrouver d'abord, et ensuite, je verrai ce que je fais.";
		link.l1.go = "PeaceDial_1";
	break;
	case "PeaceDial_1":
		dialog.text = "Tu sais, je vais t'aider. Je vais te dire oם il est. Je ne peux pas l'atteindre moi-même, je n'ai pas de navire, et les colonies de " + NationNameGenitive(sti(Colonies[FindColony(Pchar.Luke.City)].nation)) + " me sont interdites.";
		link.l1 = "D'accord, j'accepte" + GetSexPhrase(".", ".") + " Dis-moi tout ce que tu sais.";
		link.l1.go = "PeaceDial_2";
	break;
	case "PeaceDial_2":
		dialog.text = "Il est à " + XI_ConvertString("Colony" + Pchar.Luke.City + "Gen") + " en ce moment. Il se cache très probablement quelque part ; regarde bien et fais attention, il est très rusé.";
		link.l1 = "";
		link.l1.go = "PeaceDial_3";
	break;
	case "PeaceDial_3":
		dialog.text = "Bonne chance à toi, et prends ces livres. Ils t'aideront à anticiper ses ruses. Adieu.";
		link.l1 = "Merci. Au revoir.";
		link.l1.go = "exit";
		AddDialogExitQuest("PirateGoOut1");
	break;
    }
}
