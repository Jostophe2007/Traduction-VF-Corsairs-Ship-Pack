
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je n'ai rien à te dire, désolé...";
			link.l1 = "Compris.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "exit_hl":
			NextDiag.TempNode = "PiratesManNew1";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		// -------------------------------------- квест №1 -------------------------------------------------
		//первая встреча с посыльным Моргана в Пуэрто Принсипе
		case "PiratesMan1":
			if (pchar.questTemp.State == "" || sti(pchar.questTemp.CurQuestNumber) > 8 || sti(pchar.questTemp.NationQuest) == SPAIN)
			{
				if(CheckAttribute(pchar, "QuestTemp.AndreAbelQuest") || CheckAttribute(pchar, "questTemp.WhisperTutorial"))
				{
					dialog.text = RandPhraseSimple("Que voulez-vous ? Passez votre chemin.", "Arrêtez de me barrer la route, dégagez.");
					link.l1 = RandPhraseSimple("Vous savez quoi ? N'aboyez pas !", "Modérez votre ardeur. Sinon, je vais vite la refroidir !");
					link.l1.go = "exit";
					NextDiag.TempNode = "PiratesMan1";
				}
				else
				{
					dialog.text = GetSexPhrase("Mon garçon", "Ma fille") +" ! Qu'est-ce que tu as à me fixer comme ça ?";
					link.l1 = "Je passais juste.";
					link.l1.go = "exit_hl";
					link.l2 = "Tu ne serais pas le capitaine Goodley, par hasard ?";
					link.l2.go = "PiratesMan1_1";
					if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue8_Gudli"))	//Sinistra Пролог Анжелика тич
					{
						dialog.text = "La fille a l'air solide... C'est toi, la propriétaire du navire qui a jeté l'ancre dans notre charmante baie ?";
						link.l1 = "C'est moi qui le commande.";
						link.l1.go = "ATpr_F1";
						DeleteAttribute(link, "l2");
					}
				}
			}
			else
			{
				dialog.text = "Parfait, "+ GetSexPhrase("le gars", "la fille") +". Oh, diable !! Dommage que je ne puisse pas te faire confiance, dommage...";
				link.l1 = "Qu'y a-t-il ? J'ai perdu la face aux yeux des Frères de la Cכte ?";
				link.l1.go = "PiratesManNot_1";
				npchar.talker = 2; //начать диалог
				NextDiag.TempNode = "PiratesManNew1";
			}
		break;
		//Sinistra Пролог Анжелика тич ==>
		case "ATpr_F1":
			dialog.text = "Tu mens ? Non... Laisse-moi deviner : tu as derrière toi des protecteurs très sérieux, si la meute de ton navire est prête à suivre tes ordres.";
			link.l1 = "Angelica Teach, pour vous servir.";
			link.l1.go = "ATpr_F2";
		break;
		case "ATpr_F2":
			dialog.text = "Pas possible ! C'est la petite Angelica ? Tu ne te souviens sans doute pas de moi, je suis Goodley. J'ai servi avec Edward Teach, pas longtemps, d'ailleurs : j'étais jeune et ambitieux, et j'ai eu mon propre rafiot assez vite.";
			link.l1 = "Le capitaine Goodley ? C'est justement toi que je cherche. Jackman m'a envoyée parce que tu as besoin d'aide.";
			link.l1.go = "ATpr_F3";
		break;
		case "ATpr_F3":
			dialog.text = "J'ai besoin de rendre service à Henry Morgan. Viens à la taverne, nous en discuterons là-bas.";
			link.l1 = "א Morgan, tu dis ? Hum, d'accord.";
			link.l1.go = "PiratesMan1_2";
			link.l2 = "Je n'ai pas le temps en ce moment, faisons ça plus tard.";
			link.l2.go = "ATpr_F4_exit";
		break;
		case "ATpr_F4_exit":
			NextDiag.TempNode = "ATpr_F5";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "ATpr_F5":
			dialog.text = "Bonjour, Angelica ! Alors, tu as changé d'avis ? J'ai besoin de rendre service à Henry Morgan.";
			link.l1 = "Oui, discutons-en à la taverne.";
			link.l1.go = "PiratesMan1_2";
			link.l2 = "Je n'ai pas le temps en ce moment, faisons ça plus tard.";
			link.l2.go = "ATpr_F4_exit";
		break;
		//<== Sinistra Пролог Анжелика тич
		case "PiratesMan1_1":
			dialog.text = "Oui, c'est moi. Que voulais-tu ?";
			link.l1 = "C'est Jackman qui m'envoie. Il a dit que tu avais besoin d'aide.";
			link.l1.go = "PiratesMan1_2";
		break;
		case "PiratesMan1_2":
			dialog.text = "J'ai besoin de rendre service à Henry Morgan. Viens à la taverne, nous en discuterons là-bas.";
			link.l1 = "Hum, d'accord.";
			link.l1.go = "PiratesMan1_3";
		break;
		case "PiratesMan1_3":
			DialogExit();
			NextDiag.CurrentNode = "Tavern_1";
			//LockQuestLine(characterFromId("eng_guber")); // лочим английскую линейку
			chrDisableReloadToLocation = true;
			bDisableFastReload = true;
			FreeSitLocator("PuertoPrincipe_tavern", "sit3");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload5", "PuertoPrincipe_tavern", "sit", "sit3", "PiratesLine_toTavern", -1);
		break;

		case "PiratesManNot_1":
			dialog.text = "Non, ce n'est pas ça. Tu travailles pour " + NationNameGenitive(sti(pchar.questTemp.NationQuest)) + ". C'est un problème pour moi en ce moment.";
			link.l1 = "C'est bien dommage...";
			link.l1.go = "PiratesManNot_2";
		break;
		case "PiratesManNot_2":
			dialog.text = "וcoute, reviens me voir plus tard, quand ton service touchera à sa fin. Je pense qu'alors, je pourrai être honnête avec toi.";
			link.l1 = "D'accord. Je m'en souviendrai.";
			link.l1.go = "exit";
            SetQuestHeader("Pir_Line_0_Waiting");
            AddQuestRecord("Pir_Line_0_Waiting", "1");
			AddQuestUserData("Pir_Line_0_Waiting", "sNation", NationNameAblative(sti(pchar.questTemp.NationQuest)));
		break;

		case "PiratesManNew1":
			if (pchar.questTemp.State == "" || sti(pchar.questTemp.CurQuestNumber) > 8 || sti(pchar.questTemp.NationQuest) == SPAIN)
			{
				dialog.text = GetSexPhrase("Mon garçon", "Ma fille") +" ! Qu'est-ce que tu as à me fixer comme ça ?";
				link.l1 = "Je passais juste.";
				link.l1.go = "exit_hl";
				link.l2 = "Tu ne serais pas le capitaine Goodley, par hasard ?";
				link.l2.go = "PiratesMan1_1";
			}
			else
			{
				dialog.text = "Ah, on se revoit. Mais ce n'est pas encore le moment, "+ GetSexPhrase("l'ami", "ma petite") +". Plus tard...";
				link.l1 = "Peut-être, mais qu'attend-on de moi ?";
				link.l1.go = "exit";
				npchar.talker = 2; //начать диалог
				NextDiag.TempNode = "PiratesManNew1";
			}
		break;
		//разговор в таверне Пуэрто Принсипе
		case "Tavern_1":
			LAi_SetSitType(pchar);
			dialog.text = "Alors, qu'en dis-tu ? Tu acceptes d'aider Morgan ?";
			link.l1 = "Morgan ?! Si c'est le même Morgan, l'amiral des Frères de la Cכte, alors j'en suis... et que dois-je faire ?";
			link.l1.go = "Tavern_2";
			npchar.lifeDay = 0;
		break;
		case "Tavern_2":
			dialog.text = "Oui, c'est simple. Tu prends un petit bonhomme à bord, Morgan l'attend déjà, et direction Port Royal. Et Morgan te recevra là-bas... et il te paiera sur place. Comme tu vois, rien de compliqué. Et n'oublie pas que tu rends un grand service à Morgan. Alors, tu acceptes ?";
			link.l1 = "Hum, le service est mince... Quel genre de personne est-ce ?";
			link.l1.go = "Tavern_3";
			link.l2 = "Morgan est un pirate célèbre, bien sמr, mais j'ai d'autres affaires et je n'ai pas l'intention de tout laisser tomber. Et d'ailleurs, je ne suis pas capitaine d'une chaloupe de courrier !";
			link.l2.go = "Tavern_over";
		break;
		case "Tavern_3":
			dialog.text = "Rien de spécial. Il s'appelle John Bolton, il t'attendra dans la baie. Seulement, tiens ta langue !";
			link.l1 = "Je sais tenir ma langue. Je dois craindre quelque chose ?";
			link.l1.go = "Tavern_4";
		break;
		case "Tavern_4":
			dialog.text = "Craindre ? Eh bien, non. C'est juste que Morgan n'aime pas ça... Alors, tu acceptes ?";
			link.l1 = "J'accepte.";
			link.l1.go = "Tavern_5";
		break;
		case "Tavern_5":
			dialog.text = "Parfait ! Eh bien, bonne journée, "+ GetSexPhrase("l'ami", "ma petite") +". Porte-toi bien !";
			if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue8_Gudli"))	//Sinistra Пролог Анжелика тич
			{
				dialog.text = "Parfait ! Eh bien, bonne journée, fille de Barbe Noire. Porte-toi bien !";
				DeleteAttribute(pchar, "questTemp.AnjelikaTichPrologue8_Gudli");
			}
			link.l1 = "א vous de même...";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			NextDiag.TempNode = "Tavern_again";
            SetQuestHeader("Pir_Line_1_JohnBolton");
            AddQuestRecord("Pir_Line_1_JohnBolton", "1");
			CloseQuestHeader("Pir_Line_0_Waiting");
			pchar.questTemp.piratesLine = "toJohnBolton";
			sld = GetCharacter(NPC_GenerateCharacter("QuestPirate2", "officer_4", "man", "man", 20, PIRATE, -1, true));
			sld.name = "John";
			sld.lastname = "Bolton";
			sld.city = "PuertoPrincipe";
			sld.location	= "PuertoPrincipe_port";
			sld.location.group = "goto";
			sld.location.locator = "goto14";
			sld.dialog.filename   = "Quest\PiratesLine_dialog.c";
			sld.dialog.currentnode   = "JohnBolton";
			sld.greeting = "Gr_MiddPirate";
			sld.talker = 8; //начать диалог
			LAi_SetLoginTime(sld, 6.0, 21.99);
			LAi_SetCitizenType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			AddDialogExitQuestFunction("PiratesLine_q1_tavernEnd");
		break;

		case "Tavern_again":
			dialog.text = "John t'attend dans la baie de Puerto Príncipe. Ne tarde pas !";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Tavern_again";
		break;
		case "Tavern_over":
			dialog.text = "Hum... Bon, comme tu veux, "+ GetSexPhrase("l'ami", "ma petite") +". א nous de proposer, à toi de refuser. Salut...";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			pchar.questTemp.piratesLine = "over";
			LAi_CharacterDisableDialog(npchar);
			AddDialogExitQuestFunction("PiratesLine_q1_tavernEnd");
		break;
		//базар с Джоном Болтоном в порту Пуэрто Принсипе
		case "JohnBolton":
			dialog.text = "Bonjour. Dites-moi, êtes-vous le capitaine " + GetFullName(pchar) + " ?";
			link.l1 = "Oui. Et vous devez être John Bolton ?";
			link.l1.go = "JohnBolton_1";
		break;
		case "JohnBolton_1":
			dialog.text = "Oui, oui. Et je dois aller à Port Royal, et de préférence vite.";
			link.l1 = "Je sais, montez dans la chaloupe, le navire est prêt.";
			link.l1.go = "JohnBolton_2";
		break;
		case "JohnBolton_2":
			AddQuestRecord("Pir_Line_1_JohnBolton", "2");
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			pchar.quest.PiratesLine_q1_arrest.win_condition.l1 = "locator";
			pchar.quest.PiratesLine_q1_arrest.win_condition.l1.location = "PortRoyal_town";
			pchar.quest.PiratesLine_q1_arrest.win_condition.l1.locator_group = "quest";
			pchar.quest.PiratesLine_q1_arrest.win_condition.l1.locator = "detector_PQ1";
			pchar.quest.PiratesLine_q1_arrest.function = "PiratesLine_q1_arrest";
			NextDiag.TempNode = "JohnBolton_inWay";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "sea", "none", "", "", "", 5.0);
		break;
		case "JohnBolton_inWay":
			dialog.text = "Nous ne sommes pas encore arrivés à Port Royal, mais je suis pressé, "+ GetSexPhrase("l'ami", "ma petite") +"...";
			link.l1 = "Nous y allons, ne vous inquiétez pas.";
			link.l1.go = "exit";
			NextDiag.TempNode = "JohnBolton_inWay";
		break;
		//базар с арестовывающими солдерами
		case "ArrestInPR":
			dialog.text = "On nous a signalé que vous aviez à bord un criminel, John Bolton... Bah ! Oui, le voilà ! Vous êtes en état d'arrestation !";
			link.l1 = "Hé, l'ami, tu ne te trompes pas ? J'ai amené cet homme de la part d'Henry Morgan !";
			link.l1.go = "ArrestInPR_1";
		break;
		case "ArrestInPR_1":
			dialog.text = "Le commandant décidera oם est l'erreur et oם elle n'est pas. Suivez-moi !";
			link.l1 = "Bon sang...";
			link.l1.go = "ArrestInPR_2";
		break;
		case "ArrestInPR_2":
			AddQuestRecord("Pir_Line_1_JohnBolton", "3");
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
			LocatorReloadEnterDisable("Portroyal_town", "houseS1", false); //закроем дом Моргана
			DialogExit();
			AddDialogExitQuestFunction("PiratesLine_q1_toPrison");
		break;
		// -------------------------------------- квест №2 -------------------------------------------------
		case "EdwardLoy":
			dialog.text = "Tu as besoin de moi, "+ GetSexPhrase("l'ami", "ma petite") +" ? א quoi dois-je ça ?";
			link.l1 = "Henry Morgan te salue.";
			link.l1.go = "EdwardLoy_1";
		break;
		case "EdwardLoy_1":
			dialog.text = "...Henry Morgan ? Et que me veut Henry Morgan ?";
			link.l1 = "Henry s'ennuie beaucoup de toi, il te demande de passer le voir à l'occasion.";
			link.l1.go = "EdwardLoy_2";
		break;
		case "EdwardLoy_2":
			dialog.text = "...Pourquoi donc ?";
			link.l1 = "Je ne sais pas. Il a peut-être décidé de te mettre dans son testament. Et pour que tu ne doutes pas de sa sincérité, il m'a chargé de te remettre quelque chose. Il a dit que tu l'attendais depuis longtemps, mais que je n'avais pas trouvé le temps de te faire plaisir.";
			link.l1.go = "EdwardLoy_3";
			RemoveItems(PChar, "BlackLabel", 1);
		break;
		case "EdwardLoy_3":
			dialog.text = "Diable ! Une marque noire. Je le savais... Et si je ne la prends pas ?";
			link.l1 = "Et si tu ne la prends pas, je te la fourre dans la gorge.";
			link.l1.go = "EdwardLoy_4";
		break;
		case "EdwardLoy_4":
			dialog.text = "Assez ! Tu as fait ta sale besogne, maintenant, fiche le camp d'ici !";
			link.l1 = "Bonne journée, Law... Et si tu tiens à la vie, va voir Morgan.";
			link.l1.go = "exit";
			NextDiag.TempNode = "EdwardLoy_again";
			QuestSetCurrentNode("Henry Morgan", "PL_Q2_away_1");
			AddQuestRecord("Pir_Line_2_BlackLabel", "3");
			AddQuestUserData("Pir_Line_2_BlackLabel", "sSex", GetSexPhrase("", "e"));
		break;
		case "EdwardLoy_again":
			dialog.text = "Tu es encore là ?";
			link.l1 = "Je m'en vais déjà...";
			link.l1.go = "exit";
			NextDiag.TempNode = "EdwardLoy_again";
		break;
		// -------------------------------------- квест №3 -------------------------------------------------
		case "CapGoodly":
			dialog.text = "Oh ! Parfait, "+ GetSexPhrase("le gars", "la fille") +" ! Nous revoilà. Assieds-toi, buvons un coup.";
			link.l1 = "Salut, Goodley ! Le tavernier m'a dit que tu avais parlé avec Law.";
			link.l1.go = "CapGoodly_1";
		break;
		case "CapGoodly_1":
			dialog.text = "C'est vrai, je lui ai parlé. Il m'a dit qu'il travaillait sur une mission secrète de Morgan.";
			link.l1 = "Ah oui, si secrète que Morgan le cherche dans toutes les Caraïbes... Il t'a dit oם il allait ?";
			link.l1.go = "CapGoodly_2";
		break;
		case "CapGoodly_2":
			dialog.text = "Morgan le cherche, dis-tu ? Non, il ne m'a rien dit de tel... Nous étions juste assis à bavarder de la vie.";
			link.l1 = "J'ai l'impression, ami Goodley, que, comme dans l'histoire avec Bolton, tu caches encore quelque chose. Tu calcules déjà combien Morgan paiera pour la tête de Law ? Alors sache-le : je serai juste derrière toi. Et quand tu m'auras mené jusqu'à Law, je t'achèverai le premier, pour que tu ne me gênes pas.";
			link.l1.go = "CapGoodly_3";
		break;
		case "CapGoodly_3":
			dialog.text = "Allons ! Quels malentendus peut-il y avoir entre amis ? Je rentre juste de Cumaná, j'y escortais les galions. Eh bien, il a posé une ou deux questions... Mais je n'en suis pas sמr.";
			link.l1 = "Bon, ne te vexe pas, je plaisantais. Bon, il est temps que j'y aille. Si je trouve Law, je partagerai avec toi, salut.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "13");
			pchar.questTemp.piratesLine = "KillLoy_toCumana";
			npchar.lifeDay = 0;
			pchar.quest.PiratesLine_q3_loginSeaWolf.win_condition.l1 = "location";
			pchar.quest.PiratesLine_q3_loginSeaWolf.win_condition.l1.location = "Cumana";
			pchar.quest.PiratesLine_q3_loginSeaWolf.function = "PiratesLine_q3_loginSeaWolf";
		break;
		//Эдвард Лоу в каюте Морского Волка
		case "SeaWolf":
			dialog.text = "Diable ! Tu m'as quand même eu !";
			link.l1 = "Comment aurait-il pu en être autrement ?!";
			link.l1.go = "SeaWolf_1";
		break;
		case "SeaWolf_1":
			dialog.text = "Pour qui te prends-tu ?! Tu crois que tout t'est permis ?! Tu n'es que le messager de Morgan, rien de plus !";
			link.l1 = "Oh, Law, l'homme est fait pour le bonheur, mais il doit travailler tout le temps. Et aujourd'hui, mon travail, c'est toi.";
			link.l1.go = "SeaWolf_2";
		break;
		case "SeaWolf_2":
			dialog.text = "Bien sמr ! Combien Morgan t'a-t-il promis pour moi ? Je te paierai le double... Le triple !";
			link.l1 = "Si ça peut flatter ton ego avant de mourir, Morgan a mis cinquante mille sur ta tête.";
			link.l1.go = "SeaWolf_3";
		break;
		case "SeaWolf_3":
			dialog.text = "וcoute, " + GetFullName(pchar) + ", je te donnerai deux cent mille, laisse-moi seulement partir.";
			link.l1 = "Law, voilà pourquoi Morgan t'en veut. Avec ta nature pourrie, tu ne peux pas comprendre qu'un gros morceau aujourd'hui peut être la cause de la famine demain.";
			link.l1.go = "SeaWolf_4";
		break;
		case "SeaWolf_4":
			dialog.text = "Quoi ?! Morgan m'en veut ?! Tu sais combien de pirates lui en veulent, à lui ?! Qui l'a choisi ?! Toi ?!" +
				"Morgan m'en veut ! Ha ha ha ! Je l'ai roulé comme un chiot ! C'est ce qu'il ne peut pas me pardonner ! Cet imposteur enrage parce que je lui ai dit un jour que personne ne l'avait choisi, et que je ne lui léchais pas les bottes comme vous tous ! Il te jettera comme un chaton, ou te noiera dans une flaque de ta propre urine dès que tu ne lui serviras plus à rien !";
			link.l1 = "Tais-toi, Law ! Je réglerai moi-même mes affaires avec Morgan, le moment venu. Et ce n'est pas pour cinquante mille que tu vas mourir. Tu vas mourir pour ta bassesse. Jackman m'a demandé de le faire gratuitement... Ai-je la moindre raison de te laisser vivre ?";
			link.l1.go = "SeaWolf_5";
		break;
		case "SeaWolf_5":
			dialog.text = "Ha ! J'imagine la tête de Jackman quand il a appris que son brick avait fait pfuit...";
			link.l1 = "Tu l'imagines ? Eh bien, que Dieu soit avec toi, alors...";
			link.l1.go = "SeaWolf_6";
		break;
		case "SeaWolf_6":
			LAi_SetCurHPMax(npchar);
            QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		// -------------------------------------- квест №5 -------------------------------------------------
		case "PQ5CapGoodly":
			dialog.text = "Parfait, "+ GetSexPhrase("l'ami", "ma petite") +" ! Tu tombes bien ! Si tu as un moment, parlons. J'ai encore une affaire pour toi, dépanne-moi.";
			link.l1 = "Parfait. Je reconnais bien le vieux Goodley : toujours des problèmes. Bon, raconte, de quoi s'agit-il ?";
			link.l1.go = "PQ5CapGoodly_1";
		break;
		case "PQ5CapGoodly_1":
			dialog.text = "Je ne vais pas tourner autour du pot, voilà mon affaire. Comme tu le sais, je travaille pour Morgan. Mais en plus de ce travail, j'en ai un autre, le principal. Je suis chasseur de primes. Jusqu'à présent, j'arrivais à concilier les affaires de Morgan et mon travail principal, mais maintenant, hélas, ça n'a pas marché. Un homme à qui je ne peux rien refuser m'a passé une commande...";
			link.l1 = "Tu ne peux pas repousser, reporter ? Qu'est-ce qui presse ? Tu vois, un homme vivrait un peu plus longtemps, ha ha ha...";
			link.l1.go = "PQ5CapGoodly_3";
		break;
		case "PQ5CapGoodly_3":
			dialog.text = "Si tout se réglait aussi simplement, je ne te le demanderais pas. Décide-toi. Tu garderas pour toi toute la récompense du client.";
			link.l1 = "Hum, ce n'est pas une mauvaise motivation. On pourrait peut-être s'entendre. Allez, quelle est la commande ?";
			link.l1.go = "PQ5CapGoodly_4";
		break;
		case "PQ5CapGoodly_4":
			dialog.text = "Il faut éliminer un homme du nom de John Avory. Il travaille dur à recouvrer des dettes pour des usuriers. Un bon combattant, un bon tireur. Une brute insolente, ce qui ne l'empêche pas de trouver des clients. "+
				"On l'a vu pour la dernière fois à Willemstad. Je ne sais pas oם il a croisé le chemin du client, mais celui-ci a mis sur la tête de John une prime de 15 000.";
			link.l1 = "Goodley, tu crois que je vais faire le travail d'un autre pour une telle misère ?! Soit tu as décidé d'empocher plus de la moitié de la prime, soit ton client est une brute rare. Dis-moi qui il est, et je lui arracherai d'autres conditions.";
			link.l1.go = "PQ5CapGoodly_5";
		break;
		case "PQ5CapGoodly_5":
			dialog.text = "Désolé, "+ GetSexPhrase("l'ami", "ma petite") +", ça, je ne te le dirai pas. Le client n'aimerait pas ça.";
			link.l1 = "Dis-moi, Goodley, c'est quoi, ces manières ? Encore une « personne », « je ne peux pas refuser », « le client n'aimerait pas ça »... Tu me prends pour un bleu ?";
			link.l1.go = "PQ5CapGoodly_6";
		break;
		case "PQ5CapGoodly_6":
			dialog.text = "Ne t'emballe pas encore ! Si tu veux savoir, quand il s'est agi de livrer Bolton, c'est Morgan lui-même qui m'a demandé de ne pas donner tous les détails au nouveau venu. Il cherchait quelqu'un de fiable... et comme tu vois, je l'ai trouvé... Alors, tu prends ma commande ?";
			link.l1 = "Tu sais flatter, toi. Mais garde à l'esprit : uniquement pour toi, et uniquement pour cinquante mille. ";
			link.l1.go = "PQ5CapGoodly_7";
		break;
		case "PQ5CapGoodly_7":
			dialog.text = "Que le diable t'emporte. Je paierai de ma poche. Je ne peux tout simplement rien refuser à cet homme. Je te souhaite bonne chance. Je t'attendrai en ville.";
			link.l1 = "Héhé. Non, pour parler franchement : " + PChar.Name + ", c'est à MOI d'éliminer Avory. Mais non, tu as inventé une sorte de client. Et, Goodley, si tu essaies de me rouler, tu seras le prochain... Bon séjour !";
			link.l1.go = "PQ5CapGoodly_8";
		break;
		case "PQ5CapGoodly_8":
			chrDisableReloadToLocation = false;
			pchar.questTemp.piratesLine = "PL5Hunter_toVillemstad";
			SetQuestHeader("Pir_Line_5_Hunter");
			AddQuestRecord("Pir_Line_5_Hunter", "1");
			AddQuestUserData("Pir_Line_5_Hunter", "sSex", GetSexPhrase("", "e"));
			LAi_SetActorTypeNoGroup(NPChar);
            LAi_ActorGoToLocation(NPChar, "reload", "houseS1", "none", "", "", "", -1.0);
			DialogExit();
		break;
		//Эйвори вместо ГГ
		case "PQ5Hero":
			dialog.text = "...L'argent ! Et soyons gentils, sinon mon coutelas va goמter ton sang !";
			link.l1 = "Ha ! Tu veux le prendre ?!! Des clous ! C'est ma proie !!!";
			link.l1.go = "PQ5Hero_1";
		break;
		case "PQ5Hero_1":
            DialogExit();
			AddDialogExitQuestFunction("PQ5_afterChangeMainHero");
		break;
		//Эйвори в доме Шарп-Тауна
		case "PQ5Aivory":
			dialog.text = "On ne t'a pas invité ! Fiche le camp tant que je te laisse partir !";
			link.l1 = "Messieurs, vous allez peut-être être surpris, mais j'ai une commande pour vous deux. Alors, présentez vos arguments.";
			link.l1.go = "PQ5Aivory_1";
		break;
		case "PQ5Aivory_1":
			dialog.text = "Ha !! Et on dit que c'est moi l'insolent. Bon, voyons maintenant qui tu es...";
			link.l1 = "Voyons voir...";
			link.l1.go = "PQ5Aivory_2";
		break;
		case "PQ5Aivory_2":
            DialogExit();
			AddDialogExitQuestFunction("PQ5_afterChangeMainHero2");
		break;
		//Гудли в таверне Порт Рояля
		case "PQ5CapGoodlyEnd":
			dialog.text = "Qui vois-je, " + GetFullName(pchar) + " ! Te revoilà ! Et je dois avouer que je t'attendais...";
			link.l1 = "Oui, les recherches ont pris un peu plus de temps que prévu. Mais elles se sont bien terminées !";
			link.l1.go = "PQ5CapGoodlyEnd_1";
		break;
		case "PQ5CapGoodlyEnd_1":
			dialog.text = "Ha ! Tu me rends incroyablement heureux ! C'est un poids en moins. Pardon, je n'ai pas encore réuni tout l'argent, seulement 15 000 pour l'instant, je paierai le reste plus tard... Sois tranquille, je ne te roulerai pas, je n'ai pas besoin d'un ennemi comme toi.";
			link.l1 = "C'est bien que tu le comprennes. Bon, donne-moi ce que tu as, et rassemble le reste.";
			link.l1.go = "PQ5CapGoodlyEnd_2";
			AddMoneyToCharacter(pchar, 15000);
		break;
		case "PQ5CapGoodlyEnd_2":
			dialog.text = "Je le rassemblerai, ne t'inquiète pas. Mais une telle affaire va beaucoup accroître ta popularité parmi les pirates, héhé...";
			link.l1 = "Hum, et pourquoi donc ? D'ailleurs, Goodley, pourquoi diable es-tu si content ?";
			link.l1.go = "PQ5CapGoodlyEnd_3";
		break;
		case "PQ5CapGoodlyEnd_3":
			dialog.text = "Pourquoi ? Abattre un combattant comme Avory n'est pas une mince affaire. Et pourquoi ne serais-je pas content si ma commande est remplie ? Ah oui, j'allais oublier : Morgan voulait te voir. Alors, dépêche-toi.";
			link.l1 = "Morgan ? Et pourquoi a-t-il besoin de moi, tu ne sais pas ?";
			link.l1.go = "PQ5CapGoodlyEnd_4";
		break;
		case "PQ5CapGoodlyEnd_4":
			dialog.text = "Non, je ne sais pas. Il ne me rend pas de comptes. Alors, pour toutes les réponses, va le voir.";
			link.l1 = "Hum, bon, j'y vais... Et pourquoi souris-tu encore comme un dément ?";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "12");
			sld = characterFromId("Henry Morgan");
			LAi_SetHuberTypeNoGroup(sld);
			ChangeCharacterAddressGroup(sld, "PortRoyal_houseS1", "sit", "sit2");
			QuestSetCurrentNode("Henry Morgan", "PL_Q5_begin");
		break;
		// -------------------------------------- квест №6 -------------------------------------------------
		case "JohnLids":
			dialog.text = "Salutations à un membre des Frères de la Cכte ! א quoi dois-je le plaisir de vous voir sur mon pont ?";
			link.l1 = "Bonjour, John. C'est Jackman qui m'envoie.";
			link.l1.go = "JohnLids_1";
		break;
		case "JohnLids_1":
			dialog.text = "Très bien. Et quel est ton nom complet ?";
			link.l1 = GetFullName(pchar) + ".";
			link.l1.go = "JohnLids_2";
		break;
		case "JohnLids_2":
			dialog.text = "Ha !! Pas possible ! Et alors, qui avons-nous coincé dans cette baie ?";
			link.l1 = "Je n'en ai aucune idée. C'est bien moi, " + GetFullName(PChar) +  ". Pourquoi tournes-tu autour du pot ? Dis-moi ce qui se passe. Qui avez-vous coincé ?";
			link.l1.go = "JohnLids_3";
		break;
		case "JohnLids_3":
			dialog.text = "Tout a commencé quand la goélette du pauvre Sid Bonnet a été capturée par un certain corsaire du nom de " + GetFullName(pchar) + ", sur une corvette. C'est peut-être "+ GetSexPhrase("ton frère", "ta sœur") +", je ne sais pas. "+
				"Notre Bonnet a été livré aux Espagnols, qui l'ont aussitכt pendu sur la place de La Havane. En somme, une triste fin pour un pirate, on ne la souhaite à personne...";
			link.l1 = "Bon, et la suite, avec mon homonyme ?";
			link.l1.go = "JohnLids_4";
		break;
		case "JohnLids_4":
			dialog.text = "Nous sommes tombés sur "+ GetSexPhrase("lui", "elle") +" juste ici. La corvette a été envoyée par le fond, mais l'équipage du navire en perdition a réussi à débarquer. On ne peut pas régler la question en envoyant simplement des abordeurs : ces diables sont bien armés et nombreux, et débarquer tout l'équipage dans cette baie est très peu commode. Et mes gars ne sont pas très chauds pour se battre : on ne fera pas revenir Sid, et il n'y a rien à gagner avec ces terriens. Tu sais, personne ne veut mourir pour rien.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "JohnLids_5";
		break;
		case "JohnLids_5":
			dialog.text = "Bon, il me semble que c'est à toi de régler le cas de ton propre parent. Sinon, tu vois, tu auras de plus en plus de problèmes. Le fait est qu'il y a dans mon équipage des gens qui te connaissent de vue. Alors, ils sont fermement convaincus que c'est toi qui es sur la corvette... Voilà, "+ GetSexPhrase("l'ami", "ma petite") +" !";
			link.l1 = "Oui, ça ne s'arrange pas d'heure en heure. Mais tu pourrais peut-être quand même m'aider avec des hommes ?";
			link.l1.go = "JohnLids_6";
		break;
		case "JohnLids_6":
			dialog.text = "Tout juste ; je garderai cette bande ici, si tu dois aller quelque part.";
			link.l1 = "Bon, je crois que je vais devoir m'en charger moi-même.";
			link.l1.go = "JohnLids_7";
		break;
		case "JohnLids_7":
			dialog.text = "Eh bien, c'est bien. Au travail, "+ GetSexPhrase("l'ami", "ma petite") +". Je suis très curieux de voir comment ça va finir...";
			link.l1 = "Héhé, tu vas rire, mais moi aussi.";
			link.l1.go = "exit";
			NextDiag.TempNode = "JohnLids_again";
			SetQuestHeader("Pir_Line_6_Jackman");
			AddQuestRecord("Pir_Line_6_Jackman", "3");
			AddQuestUserData("Pir_Line_6_Jackman", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Pir_Line_6_Jackman", "sSex1", GetSexPhrase("", "e"));
			Pchar.quest.PQ6_ShoreBattle.win_condition.l1 = "location";
			Pchar.quest.PQ6_ShoreBattle.win_condition.l1.location = "Shore7";
			Pchar.quest.PQ6_ShoreBattle.function = "PQ6_ShoreBattle";
		break;
		case "JohnLids_again":
			dialog.text = "Tu n'en as pas encore fini avec "+ GetSexPhrase("ton « frère »", "ta « sœur »") +" et je ne t'attendrai pas éternellement...";
			link.l1 = "Compris, John...";
			link.l1.go = "exit";
			NextDiag.TempNode = "JohnLids_again";
		break;
		//двойник ГГ
		case "QuestPirateHead":
			dialog.text = "Ha, alors c'est toi, " + GetFullName(pchar) + " ! Quel plaisir de te voir, "+ GetSexPhrase("frère", "sœur") +"...";
			link.l1 = GetSexPhrase("Frère", "Sœur") +" ?!";
			link.l1.go = "QuestPirateHead_1";
		break;
		case "QuestPirateHead_1":
			dialog.text = "Bon, c'est juste moi, en toute amitié... Et alors ? Tu as quand même décidé de te débarrasser de moi ?";
			link.l1 = "Allez, raconte. Qui es-tu, d'oם viens-tu...";
			link.l1.go = "QuestPirateHead_2";
		break;
		case "QuestPirateHead_2":
			dialog.text = "Tu vas nous laisser partir ?";
			link.l1 = "Bien sמr ! Alors, allons-y main dans la main, comme "+ GetSexPhrase("deux frères !", "deux sœurs !") +"";
			link.l1.go = "QuestPirateHead_3";
		break;
		case "QuestPirateHead_3":
			dialog.text = "Hum, tu plaisantes. Alors, à quoi bon parler ?";
			link.l1 = "Argh !! Bon, puisque tu tiens à en découdre...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("PQ6_JungleBattle");
		break;
		// -------------------------------------- квест №7 -------------------------------------------------
		case "FriendLinney":
			dialog.text = "Content de vous voir sur mon pont.";
			link.l1 = "Je cherche Steve Linnaeus ; on dit que vous êtes amis, on vous a vus ensemble à la taverne.";
			link.l1.go = "FriendLinney_1";
		break;
		case "FriendLinney_1":
			dialog.text = "Hum, peut-être bien que nous sommes amis...";
			link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je suis en mission pour Morgan. Steve n'est pas revenu depuis longtemps, et comme il recueillait des informations pour Morgan, Henry veut que je découvre ce qu'il est devenu.";
			link.l1.go = "FriendLinney_2";
		break;
		case "FriendLinney_2":
			dialog.text = "Ah, il fallait le dire tout de suite. Je connais Steve depuis longtemps, et il m'a parlé de la mission de Morgan. Bref, il n'a rien appris à La Vega. Il devait rencontrer ici un homme qui, paraît-il, savait quelque chose, mais l'homme n'est pas venu au rendez-vous. Steve s'apprêtait déjà à partir pour une autre ville, mais le soir, deux inconnus l'ont abordé. Ils ont parlé, et Steve est parti avec eux. Vous comprenez, ça n'aurait rien d'anormal. On ne sait jamais, il avait peut-être trouvé de nouveaux informateurs, mais hier, j'ai appris par hasard que sa goélette, la Swallow, était en vente au chantier naval de Santo Domingo. Or Steve aimait beaucoup sa Swallow et ne l'aurait jamais vendue lui-même. Alors, je me suis dit qu'il était temps de quitter La Vega, pour éviter les ennuis. Sinon, on pourrait bien venir me chercher aussi.";
			link.l1 = "Je vois. Il l'a peut-être vendue quand même ? Quoique, tout ça est bien étrange...";
			link.l1.go = "FriendLinney_3";
		break;
		case "FriendLinney_3":
			dialog.text = "Non, il ne l'aurait pas vendue. Vous ne le connaissez pas... Je m'étais porté volontaire pour l'aider, mais maintenant, je ne sais pas quoi faire.";
			link.l1 = "Bon, j'ai compris. Merci pour les informations, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "FriendLinney_again";
			pchar.questTemp.piratesLine = "Soukins_toSantoDomingo";
			AddQuestRecord("Pir_Line_7_Soukins", "5");
		break;
		case "FriendLinney_again":
			dialog.text = "Nous avons déjà parlé de Steve, je ne sais rien de plus...";
			link.l1 = "Oui, oui, bien sמr.";
			link.l1.go = "exit";
			NextDiag.TempNode = "FriendLinney_again";
		break;
		//кэп, продавшие шлюп Ласточку
		case "LeonCapitain":
			dialog.text = "Qu'est-ce que tu me veux ?";
			link.l1 = "Oם est le capitaine de la Swallow ?!";
			link.l1.go = "LeonCapitain_1";
		break;
		case "LeonCapitain_1":
			dialog.text = "Le capitaine de la Swallow est déjà au fond, il était maladivement curieux. Ha ha ha !";
			link.l1 = "Diable !!! Pour qui travailles-tu ?! Qui t'a ordonné d'éliminer Linnaeus ?!";
			link.l1.go = "LeonCapitain_2";
		break;
		case "LeonCapitain_2":
			dialog.text = "Je travaille pour l'amiral des Frères de la Cכte. Pas pour cet imposteur de Morgan, mais pour notre amiral, Richard Sawkins ! Rejoins-nous si tu ne veux pas suivre Linnaeus.";
			link.l1 = "Je n'ai aucune raison de ne pas considérer Henry Morgan comme l'amiral.";
			link.l1.go = "LeonCapitain_3";
		break;
		case "LeonCapitain_3":
			dialog.text = "Et qui l'a choisi ? Peut-être toi ?!";
			link.l1 = "Mais je n'ai pas choisi non plus ton amiral Putois !";
			link.l1.go = "LeonCapitain_4";
		break;
		case "LeonCapitain_4":
			dialog.text = "Nous sommes tous les deux pirates, et ni l'un ni l'autre n'avons choisi Morgan comme amiral. Réfléchis. Et Morgan va trop vite en besogne, et il est loin d'être aussi honnête avec nous qu'on le pense.";
			link.l1 = "Je me fiche de tes raisonnements ! Ton honnête Sawkins a déjà essayé deux fois de m'éliminer par la main d'un autre ! Et quand il a compris qu'il n'arriverait pas à me régler mon compte, il a décidé de me débaucher ? Ce n'est qu'un vulgaire rat, un petit intrigant qui se prend pour un amiral !";
			link.l1.go = "LeonCapitain_5";
		break;
		case "LeonCapitain_5":
			dialog.text = ""+ GetSexPhrase("Idiot", "Idiote") +" ! Tu regretteras ta bêtise...";
			link.l1 = "Ce n'est pas à toi de juger ma bêtise !..";
			link.l1.go = "LeonCapitain_6";
		break;
		case "LeonCapitain_6":
			Map_ReleaseQuestEncounter("LeonCapitain");
			pchar.questTemp.piratesLine = "Soukins_toMorgan";
			QuestSetCurrentNode("Henry Morgan", "PL_Q7_afterLeon");
			AddQuestRecord("Pir_Line_7_Soukins", "7");
			AddQuestUserData("Pir_Line_7_Soukins", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Pir_Line_7_Soukins", "sSex1", GetSexPhrase("", "e"));
			LAi_SetCurHPMax(npchar);
            QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//поход на Панаму, пираты в городе
		case "PQ8_PirInPan":
			dialog.text = "Tu sais, " + pchar.name + ", ce n'est pas pour rien que je me suis engagé dans ton équipage. Au bout du compte, je suis vivant, et en plus dans Panama conquise ! Qui l'aurait cru... ?";
			link.l1 = "Oui, nous devrions tirer un joli profit de cette affaire.";
			link.l1.go = "PQ8_PirInPan_1";
		break;
		case "PQ8_PirInPan_1":
			dialog.text = "On cherche déjà quelque chose à rafler !";
			link.l1 = "Et vous avez bien raison.";
			link.l1.go = "exit";
		break;
		case "PQ8_RsPirInPan":
			dialog.text = "Oh, quel dommage que notre capitaine soit mort ! Richard Sawkins était un homme bien...";
			link.l1 = "Vous croyez ?";
			link.l1.go = "PQ8_RsPirInPan_1";
		break;
		case "PQ8_RsPirInPan_1":
			dialog.text = "Bien sמr ! J'ai servi sous ses ordres pendant plus d'un an. C'était un homme juste !";
			link.l1 = "Hum, je vois...";
			link.l1.go = "exit";
		break;
		case "PQ8_MPirInPan":
			dialog.text = "J'ai entendu dire que vous en aviez bavé, vous aussi ! Morgan et moi, nous sommes venus de Portobelo jusqu'à Panama.";
			link.l1 = "Oui, des embuscades espagnoles nous attendaient à chaque tournant.";
			link.l1.go = "PQ8_MPirInPan_1";
		break;
		case "PQ8_MPirInPan_1":
			dialog.text = "Pour nous, c'était pareil, un véritable enfer...";
			link.l1 = "Mais l'essentiel, c'est que nous nous en soyons sortis et que nous soyons en vie. Alors, ne faites pas cette tête !";
			link.l1.go = "exit";
		break;
		//фантом мэра Панамы
		case "PQ8_Mayor":
			dialog.text = "Que me voulez-vous ?";
			link.l1 = "Bonjour, mon cher. Si je comprends bien, vous êtes le gouverneur de Panama...";
			link.l1.go = "PQ8_Mayor_1";
		break;
		case "PQ8_Mayor_1":
			dialog.text = "C'est exact.";
			link.l1 = "Je veux que vous me donniez l'or de l'Escurial. Je sais que vous l'avez.";
			link.l1.go = "PQ8_Mayor_2";
		break;
		case "PQ8_Mayor_2":
			dialog.text = "Hum, eh bien, voyez-vous...";
			link.l1 = "Vous jouez avec le feu ! Henry Morgan a pris Panama, et toute la fine fleur de la piraterie des Caraïbes s'est réunie ici. Vous imaginez ce qui va vous arriver ?";
			link.l1.go = "PQ8_Mayor_3";
		break;
		case "PQ8_Mayor_3":
			dialog.text = "J'imagine. Mais je ne peux rien faire pour vous de toute façon. Le fait est que je n'ai pas la clé du coffre qui pourrait contenir quelque chose... Je parle de l'un des coffres de ce bureau.";
			link.l1 = "Et oם est cette clé ?";
			link.l1.go = "PQ8_Mayor_4";
		break;
		case "PQ8_Mayor_4":
			dialog.text = "Elle est toujours chez le commandant. Ce coffre a toujours été sous le contrכle des militaires, et non des autorités civiles de la ville.";
			link.l1 = "Oם est le commandant maintenant ?";
			link.l1.go = "PQ8_Mayor_5";
		break;
		case "PQ8_Mayor_5":
			dialog.text = "Je n'en ai aucune idée. Il dirigeait la défense de la ville. Pour autant que je sache, il devait attaquer les « ladrones » depuis le fort. Il fallait empêcher la prise de Panama, alors personne n'a défendu le fort\n"+
				"Alors, il a peut-être été tué, ou il est peut-être dans son fort.";
			link.l1 = "Gardez bien à l'esprit que votre vie dépend de l'ouverture de ce coffre.";
			link.l1.go = "PQ8_Mayor_6";
		break;
		case "PQ8_Mayor_6":
			dialog.text = "Je comprends. Mais je ne peux qu'espérer avoir de la chance.";
			link.l1 = "Je vais chercher la clé. Et je vous recommande de faire un effort de mémoire : vous vous souviendrez peut-être d'autre chose...";
			link.l1.go = "PQ8_Mayor_7";
		break;
		case "PQ8_Mayor_7":
			dialog.text = "Si quelque chose me revient, vous le saurez sans faute. C'est dans mon intérêt.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_8_Panama", "11");
			pchar.quest.PQ8_MorganInPanama_1.win_condition.l1 = "location";
			pchar.quest.PQ8_MorganInPanama_1.win_condition.l1.location = "Panama_town";
			pchar.quest.PQ8_MorganInPanama_1.function = "PQ8_MorganInPanama_1";
		break;
		//обманутые пиратусы в Панаме
		case "PQ8_FackMorgan":
			dialog.text = LinkRandPhrase("Diable, Henry nous a roulés !", "Tu as entendu ce qu'a fait Morgan ?! C'est tout simplement ahurissant...", "Maintenant, nous sommes fichus ici, il faut trouver un moyen de partir. Maintenant, c'est chacun pour soi...");
			link.l1 = LinkRandPhrase("Oui, j'ai entendu...", "Bon sang !!!", "Mille tonnerres !");
			link.l1.go = "exit";
		break;
		//первый подбегающий пират
		case "PL_Q8_QFackMorgan":
			dialog.text = "Tu tombes à pic, capitaine ! Dommage que tu n'aies pas été là un peu plus tכt...";
			link.l1 = "Que s'est-il passé ?";
			link.l1.go = "PL_Q8_QFackMorgan_1";
		break;
		case "PL_Q8_QFackMorgan_1":
			dialog.text = "Ha !! Je vais te faire tellement plaisir que tu vas en perdre la tête de joie !";
			link.l1 = "Va droit au but, ne fais pas traîner.";
			link.l1.go = "PL_Q8_QFackMorgan_2";
		break;
		case "PL_Q8_QFackMorgan_2":
			dialog.text = "Notre amiral, Henry Morgan, a récolté le butin de nous tous ! Il a rassemblé les pirates et a été le premier à vider ses poches dans le pot commun !";
			link.l1 = "Et alors, je le savais. Qu'y a-t-il d'extraordinaire là-dedans ?";
			link.l1.go = "PL_Q8_QFackMorgan_3";
		break;
		case "PL_Q8_QFackMorgan_3":
			dialog.text = "Rien, mais ce n'est pas tout... Nous avons tous vidé nos bourses et nous sommes retournés à nos affaires, en attendant qu'Henry partage tout selon la loi des Frères de la Cכte. Pendant ce temps, notre vaillant et très honnête amiral s'est discrètement embarqué sur un galion espagnol et a filé.";
			link.l1 = "Comment ? Et l'argent ?!";
			link.l1.go = "PL_Q8_QFackMorgan_4";
		break;
		case "PL_Q8_QFackMorgan_4":
			dialog.text = "Notre argent est parti avec Morgan, lui aussi ! C'est ce que je te dis : Henry a pris tout le butin et nous a laissés ici, dans ce maudit Panama !";
			link.l1 = "Ce n'est pas possible... Mais ce n'est tout simplement pas possible !..";
			link.l1.go = "PL_Q8_QFackMorgan_5";
		break;
		case "PL_Q8_QFackMorgan_5":
			dialog.text = "Ha ! C'est un fait, capitaine ! Que faire maintenant ?";
			link.l1 = "Diable !! Bien sמr, je me doutais que Morgan n'était pas aussi honnête qu'il voulait le paraître, mais laisser ainsi son armée dans une ville vide, sans butin ni vivres !..";
			link.l1.go = "PL_Q8_QFackMorgan_6";
		break;
		case "PL_Q8_QFackMorgan_6":
			dialog.text = "Oh, si Sawkins était vivant, rien de tel ne serait arrivé, c'est sמr ! Quel capitaine c'était, un véritable amiral ! Dieu, combien de fois Richard a-t-il dit que Morgan nous trahirait. Et nous n'avons pas écouté, nous avons traîné...";
			link.l1 = "Comment ça, vous avez traîné ?";
			link.l1.go = "PL_Q8_QFackMorgan_7";
		break;
		case "PL_Q8_QFackMorgan_7":
			dialog.text = "C'est bien ce que ça veut dire ! Sawkins briguait le poste d'amiral des Frères de la Cכte, mais nous l'avons persuadé de ne pas précipiter l'élection. Caramba, comme nous avions tort !";
			link.l1 = "Ton Sawkins et notre Morgan, l'un valait bien l'autre...";
			link.l1.go = "PL_Q8_QFackMorgan_8";
		break;
		case "PL_Q8_QFackMorgan_8":
			dialog.text = "Oui, Morgan et toi, vous étiez comme cul et chemise. Je ne pensais pas qu'il te laisserait ici, toi aussi...";
			link.l1 = "Eh bien, on verra ça !! Comment s'appelait le galion sur lequel Morgan est parti ?";
			link.l1.go = "PL_Q8_QFackMorgan_9";
		break;
		case "PL_Q8_QFackMorgan_9":
			dialog.text = "Je ne m'en souviens pas. « Fortune » ou « Roue de la Fortune »... Allons, tu ne le trouveras pas. Il est sמrement parti pour l'Europe, voire pour les Indes..\nBon, plus d'amiral, plus d'argent, plus de Frères de la Cכte !";
			link.l1 = "Caramba !! Il ne sert à rien de traîner ici, de toute façon. Il faut rassembler les gens, partager la poudre, les balles et les vivres, et traverser la jungle jusqu'à la baie de Darién pour rejoindre nos navires.";
			link.l1.go = "PL_Q8_QFackMorgan_10";
		break;
		case "PL_Q8_QFackMorgan_10":
			dialog.text = "Encore à travers la jungle ? Non, je ne survivrai pas à une deuxième marche pareille. Et personne ne partira avec toi : "+ GetSexPhrase("Tu es l'ami de Morgan !", "Tout le monde est sמr que tu es la... la... euh, la bonne amie de Morgan.")+  " Et si tu parles de rassembler quoi que ce soit, je suis sמr que tu recevras aussitכt une balle dans le front ! C'est chacun pour soi maintenant, capitaine... Bon, je n'ai pas le temps de traîner ici avec toi. Je vais à la taverne, j'espère qu'il reste encore du rhum...";
			link.l1 = "Vas-y, va. Je n'ai aucune raison de m'attarder.";
			link.l1.go = "PL_Q8_QFackMorgan_11";
		break;
		case "PL_Q8_QFackMorgan_11":
			chrDisableReloadToLocation = false;
			LAi_LocationFightDisable(&Locations[FindLocation("PortRoyal_houseS1")], true);
			SetTimerFunction("PQ8_openPanama_2", 0, 0, 30);
			pchar.questTemp.piratesLine = "Panama_backToShip";
			AddQuestRecord("Pir_Line_8_Panama", "13");
			CloseQuestHeader("Pir_Line_8_Panama");
			Pchar.quest.PL_Q8_backFight_1.win_condition.l1 = "location";
			Pchar.quest.PL_Q8_backFight_1.win_condition.l1.location = "Panama_jungle_04";
			Pchar.quest.PL_Q8_backFight_1.function = "PL_Q8_backFight_1";
			LAi_SetActorType(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "reload4", "none", "", "", "", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
