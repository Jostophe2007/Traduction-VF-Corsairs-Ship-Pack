// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "KillLoy_toSeek")
			{
				link.l1 = "Je cherche Edward Law, est-il passé chez vous ?";
				link.l1.go = "PL_Q3_1";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_noMoney")
			{
				link.l1 = "J'ai trouvé l'argent !";
				link.l1.go = "PL_Q3_7";
			}
		break;
		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Edward Law ? Il est venu ; à ce moment-là, j'avais un corsaire français au port, alors il a demandé à embarquer avec lui comme passager.",
				"Nous avons déjà parlé de ce sujet !",
				"Cessez immédiatement de répéter la même chose.",
                "Hum, je suis fatigué...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Savez-vous oם allait ce corsaire ?",
				"Oui, je m'en souviens.",
                "Eh bien...",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q3_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q3_2":
			dialog.text = "Je le sais, mais vous comprenez bien que je n'ai pas le droit de divulguer ce genre d'informations...";
			link.l1 = "Mais je dois absolument le retrouver ! J'ai une affaire de la plus haute importance pour lui !";
			link.l1.go = "PL_Q3_out";
			link.l2 = "Le fait est qu'Edward Law et moi sommes parents éloignés, et je dois de toute urgence l'informer de la maladie de sa mère. Vous qui êtes un homme convenable, vous ne permettrez pas qu'un fils ne puisse pas dire adieu à une mourante à cause d'un règlement bureaucratique...";
			link.l2.go = "PL_Q3_3";
		break;

		case "PL_Q3_out":
			dialog.text = "Cherchez...";
			link.l1 = "Ah, diable !..";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "6");
			AddQuestUserData("Pir_Line_3_KillLoy", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.piratesLine = "KillLoy_notFound";
			QuestSetCurrentNode("Henry Morgan", "PL_Q3_notFound");
		break;
		case "PL_Q3_3":
			if (GetCharacterSkill(pchar, "Sneak") >= 60 || GetCharacterSPECIAL(pchar, "Charisma") > 6)
			{
				dialog.text = "Oui, c'est une grande tragédie, je vais vous aider. Le corsaire se dirigeait vers les Bermudes.";
				link.l1 = "Merci infiniment ! Vous n'imaginez pas ce que vous avez fait pour moi ! Merci.";
				link.l1.go = "exit";
				AddQuestRecord("Pir_Line_3_KillLoy", "7");
				pchar.questTemp.piratesLine = "KillLoy_toBermudes";
			}
			else
			{
				dialog.text = "Eh bien, oui, bien sמr. Tout le monde ici me raconte des histoires de pauvres parents, de mères mourantes, et je devrais croire tout le monde ! Non, trouvez autre chose.";
				link.l1 = "Peut-être qu'un petit don au fonds de rénovation de la capitainerie nous aiderait à contourner ce point fâcheux de votre règlement ?";
				link.l1.go = "PL_Q3_4";
			}
		break;
		case "PL_Q3_4":
			dialog.text = "Mm-hmm... eh bien, puisque vous insistez pour que 15 000 compensent le risque moral que je prends en enfreignant les règles...";
			if (sti(pchar.money) >= 15000)
			{
				link.l1 = "Oם est le problème ?! Voici votre rétribution.";
				link.l1.go = "PL_Q3_5";
			}
			else
			{
				link.l1 = "Hum, je n'ai pas cette somme sur moi pour l'instant !";
				link.l1.go = "PL_Q3_6";
			}
		break;
		case "PL_Q3_5":
			dialog.text = "Ce corsaire est parti pour les Bermudes...";
			link.l1 = "Je comprends. Merci de compatir si sincèrement à nos problèmes de famille. Au revoir.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "7_1");
			pchar.questTemp.piratesLine = "KillLoy_toBermudes";
			AddMoneyToCharacter(pchar, -15000);
		break;
		case "PL_Q3_6":
			dialog.text = "Alors il faudra vous la procurer. Ne vous inquiétez pas, j'attendrai...";
			link.l1 = "Euh, d'accord. Je vais trouver l'argent !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "8");
			pchar.questTemp.piratesLine = "KillLoy_noMoney";
		break;
		case "PL_Q3_7":
			if (sti(pchar.money) >= 15000)
			{
				dialog.text = "Très bien !";
				link.l1 = "Voici vos 15 mille. Dites ce que vous savez.";
				link.l1.go = "PL_Q3_5";
			}
			else
			{
				dialog.text = "Euh, vous me prenez pour un idiot ? Allez chercher l'argent !";
				link.l1 = "Diable !!";
				link.l1.go = "exit";
			}
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

