
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp;
	string sTemp;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Bonjour ! Alors c'est vous "+ GetSexPhrase("le héros qui a réussi", "l'héroïne qui a réussi") +" à arriver jusqu'à moi ?";
			link.l1 = "Oui, c'est bien moi.";
			link.l1.go = "FT_1";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! C'est "+ GetSexPhrase("lui, il a enfreint", "elle, elle a enfreint") +" la Loi !");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		case "FT_1":
			dialog.text = "Bien, très bien... Présentez-vous, je vous prie, "+ GetSexPhrase("mon estimé ami", "belle amazone") +".";
			link.l1 = "On m'appelle capitaine " + GetFullName(pchar) + ". Et vous, si je ne m'abuse, vous êtes Henrik Wedeker, surnommé le Mécanicien.";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "C'est exact !.. Et d'oם me connaissez-vous ?";
			link.l1 = "Oh, mieux vaut ne pas demander, c'est une longue histoire...";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "J'aimerais tout de même l'entendre. Voyez-vous, j'ai longtemps été privé de toute conversation avec des gens normaux. Les « Caspers »... eux évitaient de me parler. Au fait, à propos du clan des Caspers. Vous les avez tous éliminés ?";
			link.l1 = "Jusqu'au dernier. Et avant ça, j'ai exterminé tout le clan des Narvals.";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Héhé, alors la Cité est désormais débarrassée de ses brigands ? Eh bien, chapeau bas, comme on dit, et maintenant, dites-moi, je vous prie, pourquoi vous avez accompli ces exploits impressionnants.";
			link.l1 = "Comment vous dire... Voyez-vous, j'ai échoué sur cette île en enquêtant sur la mort de Teaser Dan. Et maintenant, je veux sortir d'ici.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Teaser Dan ? Vous connaissiez Teaser ?";
			link.l1 = "Je n'ai pas eu l'occasion de le rencontrer en personne, mais je peux vous dire qu'il a atteint le continent sain et sauf. Malheureusement, il a été tué par des agents de la Compagnie néerlandaise des Indes occidentales.";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Quel malheur. Vous savez, c'est moi qui lui ai construit le radeau sur lequel il est parti d'ici vers l'océan.";
			link.l1 = "Ah oui ?! Et comment est-il parvenu jusqu'à vous en passant par les Caspers ?";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "Il nageait souvent jusqu'au « Fernando Diffindur ». Au cours d'une de ces baignades, j'étais sur ma plateforme, en train de préparer une plongée...";
			link.l1 = "Une plongée ?";
			link.l1.go = "FT_8";
		break;
		case "FT_8":
			dialog.text = "Oui... Je vous expliquerai plus tard. Bref, nous avons fait connaissance, nous avons discuté, et j'ai tout fait pour qu'il parte d'ici et parle de cette île aux gens.";
			link.l1 = "Il a beau avoir atteint son but, ce sont justement ses récits sur la Cité qui ont causé sa mort. La Compagnie néerlandaise des Indes occidentales croit que d'immenses richesses sont concentrées dans la Cité, et que leur apparition soudaine sur le marché pourrait faire s'effondrer les prix. Dans ce cas, le commerce irait au diable.";
			link.l1.go = "FT_9";
		break;
		case "FT_9":
			dialog.text = "Je vois. Alors, Teaser a tenu sa promesse envers moi jusqu'au bout, malgré la menace qui pesait sur sa vie. Bon sang, quel dommage qu'il soit mort !";
			link.l1 = "C'est dommage, bien sמr. Vous savez, tant de braves gens sont morts ces derniers temps que je n'ai même plus la force de les regretter...";
			link.l1.go = "FT_10";
		break;
		case "FT_10":
			dialog.text = "Bon, ne parlons pas de choses tristes. Vous savez, votre compagnie néerlandaise a raison au sujet des richesses de la Cité. Il y a beaucoup de choses ici. Et encore plus sous l'eau...";
			link.l1 = "Sérieusement ? Et comment le savez-vous ?";
			link.l1.go = "FT_11";
		break;
		case "FT_11":
			dialog.text = "Je l'ai vu de mes propres yeux... Bon, ça aussi, ce sera pour plus tard. Maintenant, dites-moi, "+ GetSexPhrase("mon ami", "chère demoiselle") +", ce qui se passe dans la Cité et ce qui vous amène chez moi.";
			link.l1 = "L'amiral Chad Capper dirige la Cité. Les citoyens vivent selon les dispositions de la Loi, dont l'une interdit la construction de toute embarcation. Eh bien, j'ai appris par hasard l'existence du Mécanicien et j'ai décidé de vous parler à tout prix. C'est tout, en fait...";
			link.l1.go = "FT_12";
		break;
		case "FT_12":
			dialog.text = "Chad Capper tient fermement les rênes de la Cité, comme avant...";
			link.l1 = "Eh bien, je ne dirais pas fermement. Deux clans ont été anéantis l'un après l'autre, et des citoyens se font tuer. Les gens sont mécontents de l'amiral et de sa milice, car c'est à eux d'assurer la sécurité !";
			link.l1.go = "FT_13";
		break;
		case "FT_13":
			dialog.text = "Vous savez, "+ GetSexPhrase("mon ami", "ma chère") +", je ne serais pas du tout surpris qu'il s'avère que l'amiral est derrière tout ce qui se passe dans la Cité, de toute façon.";
			link.l1 = "Eh bien, pas vraiment. Maintenant, c'est moi qui mène ma partie. Et la preuve, c'est l'absence du clan des Caspers sur la barque San Gabriel.";
			link.l1.go = "FT_14";
		break;
		case "FT_14":
			dialog.text = "Hum, les « Caspers » agissaient de concert avec Capper, alors je dois bien vous donner raison... Eh bien, grâce à vous, la vie dans la Cité a beaucoup changé...";
			link.l1 = "Exactement ! Et maintenant, je propose l'élection d'un amiral. Je veux me présenter à ce poste.";
			link.l1.go = "FT_15";
		break;
		case "FT_15":
			dialog.text = "Quelles élections, "+ GetSexPhrase("mon ami", "ma chère") +" ! Il faut sauver nos vies avant qu'il ne soit trop tard...";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "FT_16";
		break;
		case "FT_16":
			dialog.text = "Savez-vous pourquoi on m'appelle le Mécanicien ?";
			link.l1 = "Je le sais. Vous avez inventé un moyen d'attacher les navires de la Cité les uns aux autres. En tout cas, d'après ce que j'ai entendu, fabriquer ce genre de chose n'est pas un problème pour vous.";
			link.l1.go = "FT_17";
		break;
		case "FT_17":
			dialog.text = "Bien. Vous vous doutez sans doute que je connais la Cité mieux que n'importe quel autre habitant. De plus, à présent, je ne fais pas de suppositions, je dis tout avec une précision absolue, puisque j'ai étudié sous l'eau la structure de la Cité des navires abandonnés.";
			link.l1 = "Sous l'eau ?";
			link.l1.go = "FT_18";
		break;
		case "FT_18":
			dialog.text = "Oui. Il y a quelques années, j'ai fabriqué un scaphandre pour respirer sous l'eau. Je suis descendu sous l'eau dans ce scaphandre à de nombreuses reprises, tant que j'en avais la possibilité. Et je vais vous dire une chose : la Cité sera forcément détruite par une forte tempête.";
			link.l1 = "Pour autant que je sache, les tempêtes ne sont pas rares ici...";
			link.l1.go = "FT_19";
		break;
		case "FT_19":
			dialog.text = "Vous aussi ! Ne discutez pas avec moi, c'est une question de vie ou de mort !";
			link.l1 = "Bien, bien... Alors, que disiez-vous à propos de respirer sous l'eau ?";
			link.l1.go = "FT_20";
		break;
		case "FT_20":
			dialog.text = "Je suis descendu sous l'eau, j'ai étudié les récifs. Eh bien, la Cité ne repose que sur trois navires accrochés aux récifs. Les autres navires sont simplement reliés à ces trois-là ! Vous comprenez ce que ça signifie ?";
			link.l1 = "Eh bien, ce n'est pas agréable de s'en rendre compte... Et que se passera-t-il si la Cité se détache ? Nous allons dériver ?";
			link.l1.go = "FT_21";
		break;
		case "FT_21":
			dialog.text = "Rien de tel ! Tout va couler, car les navires de la Cité ne flottent plus. Personne ne survivra, puisque la destruction de la Cité aura lieu pendant une tempête, et une tempête très violente.";
			link.l1 = "Une sorte d'apocalypse... Et quand cela arrivera-t-il ?";
			link.l1.go = "FT_22";
		break;
		case "FT_22":
			dialog.text = "Je n'en sais rien. Je suis un savant, pas un médium, ça peut arriver à n'importe quelle tempête.";
			link.l1 = "Hum... Et que dois-je faire ?";
			link.l1.go = "FT_23";
		break;
		case "FT_23":
			dialog.text = "Je peux vous aider si vous m'aidez.";
			link.l1 = "Proposition intéressante. Dites-m'en plus, je vous prie.";
			link.l1.go = "FT_24";
		break;
		case "FT_24":
			dialog.text = "Le fait est que j'ai un navire à flot. Il y a quelques années, un navire d'une conception sans précédent a été rejeté vers la Cité par une tempête ; il porte une inscription intéressante : « Chantiers navals de Baltimore », mais c'est absurde, Baltimore n'est qu'un village délabré au bord de la mer ! D'oם viendraient des chantiers navals ? La conception et les caractéristiques techniques du navire sont tout simplement incroyables ! J'ai appris par des fragments du journal de bord qu'il s'agissait du clipper Ariel, port d'attache Boston. J'y suis allé, c'est un port de commerce animé, et je n'y ai jamais vu de tels navires. Il y avait quelques petites brèches et du gréement cassé, rien de grave. Nous avons réussi à le réparer assez vite. Tant que j'en avais la possibilité...";
			link.l1 = "Il se passe beaucoup de choses étranges ici, dans le Nouveau Monde. Des morts-vivants, d'anciens dieux indiens, des visiteurs venus d'autres époques... C'en est peut-être une. Vous avez déjà mentionné plusieurs fois une certaine possibilité perdue...";
			link.l1.go = "FT_25";
		break;
		case "FT_25":
			dialog.text = "Ah, eh bien, c'est la possibilité de descendre sous l'eau dans mon scaphandre. Le fait est que sous l'eau, il y a d'énormes créatures qui marchent sur le fond et mangent tout ce qu'elles peuvent. Alors, je ne prends plus le risque de descendre. Je suis un savant, pas un combattant...";
			link.l1 = "Compris. Donc, c'est à moi de le faire ?";
			link.l1.go = "FT_26";
		break;
		case "FT_26":
			dialog.text = "D'abord, vous devez m'acheter le clipper. Ensuite, rapporter du fond une chose sans laquelle nous ne pourrons pas dégager le navire des épaves qui l'enserrent.";
			link.l1 = "L'acheter ?! Hum, vous n'avez donc pas intérêt à sortir d'ici et à sauver votre peau ? Car en cas d'apocalypse, comme vous le prédisez, vous mourrez aussi !";
			link.l1.go = "FT_27";
		break;
		case "FT_27":
			dialog.text = "Eh bien, je ne sais pas exactement quand la catastrophe aura lieu. Et puis, je vois que vous êtes "+ GetSexPhrase("un homme courageux et entreprenant", "une fille courageuse et entreprenante") +", et vous serez tout à fait capable de remplir mes conditions. De plus, je ne demande pas grand-chose : seulement un million et demi pour le clipper, et la possibilité de descendre une fois sous l'eau.";
			link.l1 = "Un million et demi ?! Ai-je bien entendu ?";
			link.l1.go = "FT_28";
		break;
		case "FT_28":
			dialog.text = "Vous avez bien entendu.";
			link.l1 = "Mais je n'ai pas assez d'argent !";
			link.l1.go = "FT_29";
		break;
		case "FT_29":
			dialog.text = "Bah, l'argent n'est pas un problème ici, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +". Cherchez, et je pense que vous trouverez facilement la somme qu'il me faut, puisque la Cité regorge littéralement d'objets de valeur. En outre, vous pouvez emprunter à Augusto Brahms, il prête volontiers jusqu'à un million de pièces.";
			link.l1 = "Héhé, il court toutes sortes de mauvaises rumeurs à son sujet... On dit que c'est un sorcier.";
			link.l1.go = "FT_30";
		break;
		case "FT_30":
			dialog.text = "Allons bon, vous aussi. וcoutez, je suis un savant, l'obscurantisme m'est étranger... Bref, je vous donnerai la possibilité de descendre sous l'eau, et là, il y a encore plus d'argent !";
			link.l1 = "Oui, mais il y vit aussi des créatures !";
			link.l1.go = "FT_30_1";
		break;
		case "FT_30_1":
			dialog.text = "Mais vous avez eu raison des Caspers, vous saurez régler ce problème aussi... Allons, pourquoi cette timidité ?! Comme si ce n'était pas vous qui veniez d'abattre toute une horde de voyous...";
			link.l1 = "D'accord, j'accepte.";
			link.l1.go = "FT_31";
		break;
		case "FT_31":
			dialog.text = "Eh bien, parfait ! Je vous attends avec l'argent, "+ GetSexPhrase("mon ami", "madame") +", et ce n'est que la première question. Maintenant, vous devez aller voir Chad Capper, lui dire que je suis libre, pour ainsi dire... Mais pas d'élections ! Sinon, il vous tuera.";
			link.l1 = "J'ai compris que les élections n'en valent pas la peine.";
			link.l1.go = "FT_32";
		break;
		case "FT_32":
			dialog.text = "Elles n'auront tout simplement pas lieu, voilà tout... Bref, saluez Chad de ma part, informez-le de l'anéantissement des « Caspers ». Je ne pense pas qu'il en sera ravi, mais il faut le faire.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "FT_33";
		break;
		case "FT_33":
			dialog.text = "De toute façon, il l'apprendra, s'il ne l'a pas déjà appris. Il serait donc bon de l'en informer de la bouche du héros du jour, pour ainsi dire. Il faut être très prudent avec Chad, sinon...";
			link.l1 = "Sinon quoi ?";
			link.l1.go = "FT_34";
		break;
		case "FT_34":
			dialog.text = "Sinon, il vous tuera, "+ GetSexPhrase("mon ami", "ma chère") +". Il ne faut pas mettre l'amiral en colère, et c'est ce que vous avez fait. Chad avait des affaires avec les Caspers, et j'ai entendu dans des conversations qu'il se préparait à quitter la Cité avec eux.";
			link.l1 = "Intéressant... Pourquoi ne laisse-t-il pas partir les autres ?";
			link.l1.go = "FT_35";
		break;
		case "FT_35":
			dialog.text = "Pour que personne n'apprenne l'existence de la Cité avant la date fixée par Chad.";
			link.l1 = "Compris... Bon, j'ai tout saisi. Au revoir.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CheckMillion";
			pchar.questTemp.LSC = "fromMechanicToAdmiral";
			Npchar.quest.money = 0; //счётчик бабла, отданного Механику
			AddQuestRecord("ISS_MainLine", "40");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_MainLine", "sSex2", GetSexPhrase("", "e"));
		break;

		//проверка миллиона
		case "CheckMillion":
			dialog.text = "Eh bien, oם en êtes-vous avec mon argent ?";
			if (sti(pchar.money) < 20000)
			{
				link.l1 = "Je ne l'ai pas encore réuni.";
				link.l1.go = "CheckMillion_noMoney";
			}
			else
			{
				link.l1 = "J'ai quelque chose. Je peux vous remettre une certaine somme.";
				link.l1.go = "OffM_GiveMoney";
			}
			NextDiag.TempNode = "CheckMillion";
		break;
		case "CheckMillion_noMoney":
			dialog.text = "Eh bien, faites des efforts, je pense que vous y arriverez.";
			link.l1 = "Je le pense aussi.";
			link.l1.go = "exit";
		break;
		case "OffM_GiveMoney":
			dialog.text = "Combien ?";
			link.l1 = "";
			Link.l1.edit = 6;
			link.l1.go = "OffM_GiveMoney_1";
		break;
		case "OffM_GiveMoney_1":
			iTemp = sti(dialogEditStrings[6]);
			if (iTemp <= 0)
			{
				dialog.text = "Vous plaisantez ?";
				link.l1 = "Hum, pardon, j'ai fait erreur..";
				link.l1.go = "exit";
				break;
			}
			if (iTemp > sti(pchar.money))
			{
				dialog.text = "Hum, vous n'avez malheureusement pas assez d'argent sur vous. Ne faisons pas les idiots...";
				link.l1 = "Euh... D'accord.";
				link.l1.go = "exit";
				break;
			}
			Npchar.quest.money = sti(Npchar.quest.money) + iTemp;
			AddMoneyToCharacter(pchar, -iTemp);
			if (sti(Npchar.quest.money) < 1500000)
			{
				dialog.text = "Parfait ! Vous venez de me remettre " + FindRussianMoneyString(iTemp) + ", en tout, vous m'avez apporté " + FindRussianMoneyString(sti(Npchar.quest.money)) + ". Il ne vous reste plus qu'à trouver encore " + FindRussianMoneyString(1500000 - sti(Npchar.quest.money)) + ".";
				link.l1 = "Je vais continuer à chercher.";
				link.l1.go = "exit";
				AddQuestRecord("ISS_MainLine", "41");
				AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("ISS_MainLine", "iMoney1", sti(Npchar.quest.money));
				AddQuestUserData("ISS_MainLine", "iMoney2", 1500000 - sti(Npchar.quest.money));
			}
			else
			{
				dialog.text = "Eh bien, c'est fait. J'ai reçu la somme requise, le clipper est à vous.";
				link.l1 = "Très bien. Et ensuite ?";
				link.l1.go = "FreeCorvett";
			}
		break;
		//освобождние корвета
		case "FreeCorvett":
			dialog.text = "Maintenant, il faut dégager le navire. Le fait est qu'il se trouve sur l'anneau extérieur de l'amas d'épaves de l'île et qu'il est enserré de tous cכtés par des débris.";
			link.l1 = "Et comment dois-je m'y prendre ?";
			link.l1.go = "FreeCorvett_1";
		break;
		case "FreeCorvett_1":
			dialog.text = "J'ai déjà tout préparé. J'ai un treuil sur la plateforme, auquel j'ai attaché les débris autour du clipper. Il suffit donc d'actionner le mécanisme, et voilà, le navire est libre !";
			link.l1 = "דa a l'air parfait. Oם est le piège ?";
			link.l1.go = "FreeCorvett_2";
		break;
		case "FreeCorvett_2":
			dialog.text = "Oui, il y a effectivement un piège. J'ai laissé tomber à l'eau l'engrenage du mécanisme du treuil. Il faut récupérer cet engrenage au fond.";
			link.l1 = "Bon... Si ma mémoire est bonne, vous avez dit que vous aviez un scaphandre pour respirer sous l'eau. C'est avec ça que je vais descendre au fond ?";
			link.l1.go = "FreeCorvett_3";
		break;
		case "FreeCorvett_3":
			dialog.text = "Oui, c'est bien ça. Je l'aurais fait moi-même depuis longtemps, mais j'ai très peur. Il y a ces énormes créatures, là-bas !..";
			link.l1 = "Vous les avez vues ?";
			link.l1.go = "FreeCorvett_4";
		break;
		case "FreeCorvett_4":
			dialog.text = "Je les ai vues, et, pour être honnête, j'en ai mouillé mon pantalon de peur... Alors je ne les ai pas vues en détail. De manière générale, bien sמr, il n'y a rien d'étonnant à ce que cette population vorace existe sous la Cité.";
			link.l1 = "Eh bien, elles sont peut-être inoffensives ? Comment savez-vous qu'elles sont voraces ?";
			link.l1.go = "FreeCorvett_5";
		break;
		case "FreeCorvett_5":
			dialog.text = "Mais elles vivent de ce que les habitants de la Cité jettent par-dessus bord ! C'est la seule raison pour laquelle ces créatures se sont installées ici.";
			link.l1 = "Compris... Bon, allons-y.";
			link.l1.go = "FreeCorvett_6";
		break;
		case "FreeCorvett_6":
			dialog.text = "Alors, laissez-moi vous expliquer comment utiliser le scaphandre. Le scaphandre est alimenté par l'air comprimé que vous respirez. L'air dure 6 minutes de respiration ininterrompue sous l'eau. Pendant ce temps, vous devez avoir le temps de remonter à la surface. Sinon, c'en est fini de vous. C'est clair ?";
			link.l1 = "Ce qui est clair, c'est que mon temps sous l'eau est limité. Le reste ne l'est pas.";
			link.l1.go = "FreeCorvett_7";
		break;
		case "FreeCorvett_7":
			dialog.text = "Et c'est l'essentiel dont vous devez vous souvenir. Maintenant, vous pouvez aller sur la plateforme, le scaphandre y est, rempli d'air pour une plongée. Je pense que vous trouverez facilement comment l'enfiler. N'oubliez pas que vous ne pouvez plonger que pendant la journée, de dix heures à dix-neuf heures. Après usage, remettez le scaphandre là oם vous l'avez pris. Bonne chance dans le monde sous-marin !";
			link.l1 = "Merci...";
			link.l1.go = "exit";
			NextDiag.TempNode = "takeArmor";
			pchar.questTemp.LSC = "toUnderwater";
			pchar.questTemp.LSC.immersions = 0; //количество совершенных погружений
			pchar.questTemp.LSC.immersions.model = pchar.model; //запомним модельку ГГ
			pchar.questTemp.LSC.immersions.animation = pchar.model.animation;
			pchar.questTemp.LSC.immersions.pay = true; //оплачено
			pchar.questTemp.LSC.immersions.pinion = false; //флаг найденной шестерёнки
			AddQuestRecord("ISS_MainLine", "42");
			pchar.Ship.Type = GenerateShipExt(SHIP_CLIPPER, false, pchar);
			SetBaseShipData(pchar);
			pchar.Ship.name = "Ariel";
			pchar.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS24;
			SetCharacterGoods(pchar, GOOD_BALLS, 0);
			SetCharacterGoods(pchar, GOOD_GRAPES, 0);
			SetCharacterGoods(pchar, GOOD_KNIPPELS, 0);
			SetCharacterGoods(pchar, GOOD_BOMBS, 0);
			SetCharacterGoods(pchar, GOOD_SAILCLOTH, 0);
			SetCharacterGoods(pchar, GOOD_PLANKS, 0);
			SetCharacterGoods(pchar, GOOD_POWDER, 0);
			SetCharacterGoods(pchar, GOOD_FOOD, 0);
			SetCharacterGoods(pchar, GOOD_WEAPON, 0);
			SetCharacterGoods(pchar, GOOD_MEDICAMENT, 0);
			SetCrewQuantity(pchar, 0);
			AddSimpleRumourCityTip("Vous savez, un Mécanicien est apparu dans la Cité. Et on dit que c'est le plus ancien habitant ! דa alors...", "LostShipsCity", 10, 1, "LSC", "");
			AddSimpleRumourCityTip("Vous avez entendu parler d'Henrik Wedeker ? C'est incroyable ! Il s'avère qu'il était enfermé sur le San Gabriel depuis des années.", "LostShipsCity", 10, 1, "LSC", "");
			AddSimpleRumourCityTip("On dit que le nouvel ancien habitant de la Cité, un certain Henrik Wedeker, est quelqu'un de très doué.", "LostShipsCity", 10, 1, "LSC", "");
			AddSimpleRumourCityTip("Et moi, je ne crois pas que ce Mécanicien soit si important pour la Cité. Nous avons vécu si longtemps sans lui, nous vivrons encore plus longtemps...", "LostShipsCity", 10, 1, "LSC", "");
			// нулим предметы в каюте
			ref loc;
			int n;
			if (Pchar.SystemInfo.CabinType != "")
			{
				loc = &locations[FindLocation(Pchar.SystemInfo.CabinType)]; //"My_Cabin"

				for (n = 1; n <= 4; n++)
				{
					sTemp = "box" + n;
					DeleteAttribute(loc, sTemp + ".items");
					loc.(sTemp).items = "";
					loc.(sTemp) = Items_MakeTime(0, 0, 1, 2003);
					loc.(sTemp).money = 0;
				}
			}
			loc = &locations[FindLocation("My_Deck")];
			for (n = 1; n <= 4; n++)
			{
				sTemp = "box" + n;
				DeleteAttribute(loc, sTemp + ".items");
				loc.(sTemp).items = "";
				loc.(sTemp) = Items_MakeTime(0, 0, 1, 2003);
				loc.(sTemp).money = 0;
			}
		break;
		//
		case "takeArmor":
			dialog.text = "Alors, oם en es-tu ?";
			if (sti(pchar.questTemp.LSC.immersions.pay))
			{
				link.l1 = "Je me prépare à plonger. Je vous dirai plus tard comment ça s'est passé.";
				link.l1.go = "exit";
			}
			else
			{
				link.l1 = "Je dois redescendre au fond. Je n'ai pas eu le temps de faire tout ce que je voulais.";
				link.l1.go = "DeepAgain";
				if (CheckCharacterItem(pchar, "Pinion"))
				{
					link.l2 = "J'ai trouvé l'engrenage, le voici !";
					link.l2.go = "FoundPinion";
				}
			}
		break;

		case "DeepAgain":
			dialog.text = "Je n'y vois pas d'inconvénient, le scaphandre est toujours à votre disposition. Seulement, pour chaque plongée, je dois vous facturer 30 000 piastres. Alors, l'argent d'abord.";
			link.l1 = "Encore de l'argent ? Je vous ai apporté un million et demi !";
			link.l1.go = "DeepAgain_1";
		break;
		case "DeepAgain_1":
			dialog.text = "Cet argent, c'est le paiement du navire et d'une plongée. Je ne vous ai pas promis de vous vendre le scaphandre, je le garde. Je vous le loue. L'amortissement, et tout ça...";
			link.l1 = "C'est quoi, l'amortissement ?";
			link.l1.go = "DeepAgain_2";
		break;
		case "DeepAgain_2":
			dialog.text = "L'usure du matériel, vous ne le saviez pas ? Bref, il est inutile de discuter. Trente mille, et en route pour un rendez-vous avec le diable des mers. Pas d'argent, pas de plongée.";
			link.l1 = "Eh bien, pas mal...";
			link.l1.go = "DeepAgain_3";
		break;
		case "DeepAgain_3":
			dialog.text = "Je ne comprends pas de quoi vous vous plaignez. Je vous donne la possibilité de gagner beaucoup plus. Après tout, il y a beaucoup d'objets de valeur au fond. Si vous vous contentez d'y faire une promenade, alors excusez-moi... Bref, il faut être plus efficace, là-bas, au fond.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			NextDiag.TempNode = "takeArmor2";
		break;

		case "takeArmor2":
			dialog.text = "Alors, comment allez-vous ?";
			if (sti(pchar.questTemp.LSC.immersions.pay))
			{
				link.l1 = "Je reprends des forces avant une autre plongée.";
				link.l1.go = "exit";
			}
			else
			{
				link.l1 = "Je veux redescendre au fond.";
				link.l1.go = "DeepAgain2";
				if (CheckCharacterItem(pchar, "Pinion"))
				{
					link.l2 = "J'ai trouvé l'engrenage, le voici !";
					link.l2.go = "FoundPinion";
				}
			}
			if (sti(pchar.questTemp.LSC.immersions.pinion))
			{
				link.l3 = "C'est fini, j'en ai assez des plongées. Le royaume sous-marin ne m'intéresse plus.";
				link.l3.go = "endImmersion";
			}
		break;

		case "DeepAgain2":
			dialog.text = "Vous avez préparé l'argent ?";
			if (sti(pchar.money) >= 30000)
			{
				link.l1 = "Oui, voici l'argent.";
				link.l1.go = "DeepAgain2_1";
			}
			else
			{
				link.l1 = "Pas encore... Mais je vais forcément le trouver.";
				link.l1.go = "exit";
			}
		break;
		case "DeepAgain2_1":
			dialog.text = "Parfait ! Revenez demain, je préparerai le scaphandre.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -30000);
			SaveCurrentQuestDateParam("questTemp.LSC.immersions");
			NextDiag.TempNode = "readyArmor";
		break;
		case "readyArmor":
			if (GetQuestPastDayParam("questTemp.LSC.immersions") > 0)
			{
				dialog.text = "Tout va bien, le scaphandre est en état de marche et rempli d'air. Bref, tout est prêt pour la plongée. Bonne chance.";
				link.l1 = "Merci.";
				link.l1.go = "exit";
				pchar.questTemp.LSC.immersions.pay = true; //оплачено
				NextDiag.TempNode = "takeArmor2";
			}
			else
			{
				dialog.text = "Le scaphandre n'est pas prêt. Revenez demain.";
				link.l1 = "D'accord.";
				link.l1.go = "exit";
			}
		break;

		case "FoundPinion":
			dialog.text = "Parfait ! Donnez-le-moi vite...";
			link.l1 = "Oui, bien sמr.";
			link.l1.go = "FoundPinion_1";
		break;
		case "FoundPinion_1":
			dialog.text = "Bon, maintenant, je peux m'occuper de la remise en état du mécanisme du treuil. Dites-moi, vous allez encore plonger ?";
			link.l1 = "Oui, je veux explorer le fond plus en détail.";
			link.l1.go = "FoundPinion_deep";
			link.l2 = "Non, le royaume sous-marin ne m'intéresse plus.";
			link.l2.go = "endImmersion";
			TakeItemFromCharacter(pchar, "Pinion");
			pchar.questTemp.LSC.immersions.pinion = true; //нашёл шестерёнку
			AddQuestRecord("ISS_MainLine", "44");
		break;
		case "FoundPinion_deep":
			dialog.text = "Eh bien, voilà une idée sensée. Vous connaissez mes conditions : 30 000 pièces par plongée. Allez-y.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			NextDiag.TempNode = "takeArmor2";
		break;

		case "endImmersion":
			dialog.text = "Bon, comme vous voudrez. Alors, je range le scaphandre.";
			link.l1 = "Comme tu voudras.";
			link.l1.go = "endImmersion_1";
		break;
		case "endImmersion_1":
			dialog.text = "Maintenant que j'ai tout ce qu'il me faut, je vais réparer le mécanisme du treuil qui libérera votre clipper. Cela va me prendre un certain temps. Vous ne devez pas encore vous reposer sur vos lauriers : il faut mener à bien un certain nombre de préparatifs importants.";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "endImmersion_2";
		break;
		case "endImmersion_2":
			dialog.text = "D'abord, procurez au navire tout ce qu'il lui faut. Tout l'assortiment de munitions, des vivres, des armes... Bon, ce n'est pas à moi de vous apprendre. Apportez tout ce que vous trouverez au San Gabriel, et je me chargerai moi-même de transférer tout ça sur le navire.";
			link.l1 = "J'ai compris, je vais essayer de tout faire.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.LSC.immersions");
			AddQuestRecord("ISS_MainLine", "45");
			pchar.questTemp.LSC = "toSeekGoods";
			NextDiag.TempNode = "takeGoods";
		break;
		//комплектование корвета товарами
		case "takeGoods":
			NextDiag.TempNode = "takeGoods";
			dialog.text = "Salutations. Alors, oם en êtes-vous avec le remplissage de la cale du clipper ?";
			npchar.quest.LSC.Balls = false;
			npchar.quest.LSC.Grapes = false;
			npchar.quest.LSC.Knippels = false;
			npchar.quest.LSC.Bombs = false;
			npchar.quest.LSC.Sailcloth = false; //магазин
			npchar.quest.LSC.Planks = false; //магазин
			npchar.quest.LSC.Powder = false;
			npchar.quest.LSC.Food = false; //магазин
			npchar.quest.LSC.Weapon = false;
			npchar.quest.LSC.Medicament = false;
			iTemp = 0;
			npchar.quest.LSC.s0 = "";
			npchar.quest.LSC.s1 = "";
			if (GetCargoGoods(pchar , GOOD_BALLS) >= 100)
			{
				npchar.quest.LSC.Balls = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Balls;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " boulets, ";
			if (GetCargoGoods(pchar , GOOD_GRAPES) >= 100)
			{
				npchar.quest.LSC.Grapes = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Grapes;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " mitraille, ";
			if (GetCargoGoods(pchar , GOOD_KNIPPELS) >= 100)
			{
				npchar.quest.LSC.Knippels = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Knippels;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " boulets ramés, ";
			if (GetCargoGoods(pchar , GOOD_BOMBS) >= 100)
			{
				npchar.quest.LSC.Bombs = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Bombs;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " bombes, ";
			if (GetCargoGoods(pchar , GOOD_SAILCLOTH) >= 50)
			{
				npchar.quest.LSC.Sailcloth = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Sailcloth;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " toile, ";
			if (GetCargoGoods(pchar , GOOD_PLANKS) >= 50)
			{
				npchar.quest.LSC.Planks = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Planks;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " planches, ";
			if (GetCargoGoods(pchar , GOOD_POWDER) >= 200)
			{
				npchar.quest.LSC.Powder = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Powder;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " poudre, ";
			if (GetCargoGoods(pchar , GOOD_FOOD) >= 200)
			{
				npchar.quest.LSC.Food = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Food;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " vivres, ";
			if (GetCargoGoods(pchar , GOOD_WEAPON) >= 50)
			{
				npchar.quest.LSC.Weapon = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Weapon;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " armes, ";
			if (GetCargoGoods(pchar , GOOD_MEDICAMENT) >= 50)
			{
				npchar.quest.LSC.Medicament = true;
				iTemp++;
			}
			sTemp = "s" + npchar.quest.LSC.Medicament;
			npchar.quest.LSC.(sTemp) = npchar.quest.LSC.(sTemp) + " médicaments, ";
			if (iTemp < 10)
			{
				if (iTemp == 0)
				{
					link.l1 = "Je n'ai encore rien obtenu, mais j'essaie.";
				}
				else
				{
					sTemp = npchar.quest.LSC.s0;
					npchar.quest.LSC.s0 = strcut(sTemp, 0, (strlen(sTemp)-2));
					sTemp = npchar.quest.LSC.s1;
					npchar.quest.LSC.s1 = strcut(sTemp, 0, (strlen(sTemp)-2));
					link.l1 = "J'ai déjà quelque chose. J'ai réussi à obtenir : " + npchar.quest.LSC.s1 + ". Il me reste à trouver : " + npchar.quest.LSC.s0 + ".";
				}
				link.l1.go = "takeGoods_again";
			}
			else
			{
				link.l1 = "Tout ce qu'il faut pour prendre la mer est dans ma cale.";
				link.l1.go = "TakeCrew";
				DeleteAttribute(pchar, "questTemp.LSC.Balls");
				DeleteAttribute(pchar, "questTemp.LSC.Grapes");
				DeleteAttribute(pchar, "questTemp.LSC.Knippels");
				DeleteAttribute(pchar, "questTemp.LSC.Bombs");
				DeleteAttribute(pchar, "questTemp.LSC.Sailcloth");
				DeleteAttribute(pchar, "questTemp.LSC.Planks");
				DeleteAttribute(pchar, "questTemp.LSC.Powder");
				DeleteAttribute(pchar, "questTemp.LSC.Food");
				DeleteAttribute(pchar, "questTemp.LSC.Weapon");
				DeleteAttribute(pchar, "questTemp.LSC.Medicament");
				DeleteAttribute(pchar, "questTemp.LSC.additional");
			}
		break;
		case "takeGoods_again":
			dialog.text = "Eh bien, bonne chance. Et tâchez de ne pas faire traîner cette affaire.";
			link.l1 = "C'est dans mon intérêt.";
			link.l1.go = "exit";
		break;
		//Набор команды
		case "TakeCrew":
			dialog.text = "Très bien, "+ GetSexPhrase("mon ami", "ma chère") +", tout est déjà chargé dans la cale de votre clipper. Maintenant, vous devez recruter un équipage parmi les habitants de la Cité. Vous savez, nous ne pourrons pas manœuvrer le navire seuls.";
			link.l1 = "Héhé, vous ne pouviez pas le dire plus tכt ? J'ai couru toute la Cité à la recherche de marchandises pour le navire, j'aurais pu recruter un équipage en même temps.";
			link.l1.go = "TakeCrew_1";
		break;
		case "TakeCrew_1":
			dialog.text = "Eh bien, premièrement, ça n'aurait guère plu à l'amiral. Et deuxièmement, je n'étais pas pressé. Mais maintenant, les choses prennent un très mauvais tour.";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "TakeCrew_2";
		break;
		case "TakeCrew_2":
			dialog.text = "Voyez-vous, cela fait tant d'années que je vis dans l'attente de la tempête qui détruira la Cité que j'en ai assez d'attendre dans l'ignorance. Il n'y a pas si longtemps, j'ai fabriqué un appareil qui indique l'approche des tempêtes. Je l'ai appelé le « tempêtomètre » ! C'est une chose intéressante, vous savez...";
			link.l1 = "Comme tout ce que vous faites... Alors, et ce mauvais tour des choses ?";
			link.l1.go = "TakeCrew_3";
		break;
		case "TakeCrew_3":
			dialog.text = "Ah, oui... Eh bien, mon tempêtomètre indique que ce n'est pas une simple tempête qui se dirige vers la Cité, mais un véritable ouragan. Je ne sais même pas quelle est sa puissance : l'aiguille de l'appareil est bloquée en butée.";
			link.l1 = "Il s'avère que l'heure est venue ?";
			link.l1.go = "TakeCrew_4";
		break;
		case "TakeCrew_4":
			dialog.text = "C'est vrai, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +". Je peux affirmer avec une très forte probabilité que la Cité va être détruite cette fois-ci. Alors dépêchez-vous.";
			link.l1 = "D'accord, c'est ce que je vais faire. Au fait, avez-vous réussi à dégager le clipper ?";
			link.l1.go = "TakeCrew_5";
		break;
		case "TakeCrew_5":
			dialog.text = "Pas encore, mais j'ai essayé le treuil, il est tout à fait prêt. Mettez-vous d'accord avec les gens, qu'ils viennent ici, et je les ferai passer sur le navire. Il nous faut au moins quinze personnes pour prendre la mer. Dès que vous aurez réuni le nombre requis, accourez ici immédiatement. א votre arrivée sur le San Gabriel, nous actionnerons le treuil et libérerons le clipper.";
			link.l1 = "D'accord, je vous ai compris. Je vais commencer à négocier.";
			link.l1.go = "exit";
			NextDiag.TempNode = "TakeCrewNew";
			AddQuestRecord("ISS_MainLine", "59");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC = "toSeekPeopleInCrew";
			pchar.questTemp.LSC.crew = 0; //количество уговорённых людей.
			AddDialogExitQuestFunction("LSC_SmallStormIsBegin");
		break;
		//приём народа в команду
		case "TakeCrewNew":
			if (sti(pchar.questTemp.LSC.crew) > 0)
			{
				dialog.text = "Vous n'avez pas encore recruté assez de monde pour prendre la mer. Au total, j'ai vu arriver " + FindRussianPeoplesString(sti(pchar.questTemp.LSC.crew), "Acc") + ". Continuez, et je vous en prie, faites vite...";
			}
			else
			{
				dialog.text = "Vous n'avez encore convaincu personne de rejoindre votre équipage. Dépêchez-vous !";
			}
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;
		//разговор в тюрьме
		case "inPrison":
			dialog.text = "Ah, vous voilà !";
			link.l1 = "C'est ça ! Je viens vous délivrer.";
			link.l1.go = "inPrison_1";
		break;
		case "inPrison_1":
			dialog.text = "Eh bien, merci, je ne m'y attendais pas... Mais tout cela est inutile.";
			link.l1 = "Comment ça ?";
			link.l1.go = "inPrison_2";
		break;
		case "inPrison_2":
			dialog.text = "Je suis enfermé dans cette cellule, et les gardes ont apporté la clé à l'amiral. C'était son ordre au commandant. Je ne peux pas sortir de cette cage.";
			if (CheckCharacterItem(pchar, "key_mechanic"))
			{
				link.l1 = "L'amiral n'est plus, je l'ai abattu. Il avait cette clé sur lui. C'est celle-là ?";
				link.l1.go = "inPrison_3_alt";
			}
			link.l2 = "L'amiral n'est plus, je l'ai abattu. Mais je n'ai trouvé aucune clé... Je vais revenir la chercher !";
			link.l2.go = "inPrison_3";
		break;
		case "inPrison_3":
			dialog.text = "Trop tard, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +". La tempête prend de la force.";
			link.l1 = "J'y arriverai !";
			link.l1.go = "inPrison_4";
		break;
		case "inPrison_4":
			dialog.text = "Non, c'est peu probable. Et il ne faut pas risquer le clipper et la vie de tous ces gens qui sont déjà à bord. וcoutez ce que vous devez faire...";
			link.l1 = "Henrik, j'arriverai à temps et je vous libérerai.";
			link.l1.go = "inPrison_5";
		break;
		case "inPrison_5":
			dialog.text = "J'ai décidé de rester. Je vérifierai, comme on dit, de mes propres yeux, la justesse de ma théorie. C'est important pour un savant de voir de ses propres yeux la réalisation de ses prédictions. D'ailleurs, je me suis peut-être trompé, et la Cité résistera à l'assaut des éléments. Alors, ceux qui resteront ici commenceront une nouvelle vie, sans les clans ni l'amiral.";
			link.l1 = "Vous êtes sמr ?";
			link.l1.go = "inPrison_6";
		break;
		case "inPrison_6":
			dialog.text = "Oui, j'en ai décidé ainsi. Maintenant, écoutez ce que vous devez faire pour rejoindre votre clipper.";
			link.l1 = "Je vous écoute.";
			link.l1.go = "inPrison_7";
		break;
		case "inPrison_7":
			dialog.text = "Allez au deuxième mât du « Fernando Diffindur », de là, le navire est à deux pas. J'ai réussi à utiliser le treuil avant mon arrestation et j'ai écarté les navires qui entouraient le clipper. Maintenant, vous pouvez facilement vous détacher de la Cité. La tempête prend de la force, j'ai bien peur que ce ne soit pas facile pour vous en ce moment... En sortant du Tartarus, vous devez savoir précisément oם aller : à droite d'ici. Sinon, vous périrez dans ce chaos. Je vous répète encore une fois que vous devez vous diriger vers le deuxième mât du « Fernando Diffindur ».";
			link.l1 = "J'ai compris, merci... On ne devrait pas quand même essayer d'ouvrir cette maudite cage ?";
			link.l1.go = "inPrison_8";
		break;
		case "inPrison_8":
			dialog.text = "Adieu, ce fut un plaisir de faire affaire avec vous. Désormais, mon sort ne vous concerne plus...";
			link.l1 = "Adieu, Henrik Wedeker. Je vous souhaite de survivre à cette tempête.";
			link.l1.go = "exit";
			chrDisableReloadToLocation = false;
			LAi_CharacterDisableDialog(npchar);
			AddQuestRecord("ISS_MainLine", "67");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			AddDialogExitQuestFunction("LSC_BigStormIsBegin");
		break;
		case "inPrison_3_alt":
			dialog.text = "C'est celle-là. Donnez-la-moi vite.";
			TakeItemFromCharacter(pchar, "key_mechanic");
			link.l1 = "Attendez. Et ensuite ?";
			link.l1.go = "inPrison_4_alt";
		break;
		case "inPrison_4_alt":
			dialog.text = "Allez au deuxième mât du « Fernando Diffindur », de là, le navire est à deux pas. J'ai réussi à utiliser le treuil avant mon arrestation et j'ai écarté les navires qui entouraient le clipper. Maintenant, vous pouvez facilement vous détacher de la Cité. La tempête prend de la force, j'ai bien peur que ce ne soit pas facile pour vous en ce moment... En sortant du Tartarus, vous devez savoir précisément oם aller : à droite d'ici. Sinon, vous périrez dans ce chaos. Je vous répète encore une fois que vous devez vous diriger vers le deuxième mât du « Fernando Diffindur ».";
			link.l1 = "J'ai compris. Merci.";
			link.l1.go = "inPrison_5_alt";
		break;
		case "inPrison_5_alt":
			dialog.text = "Je vous suis de près. J'espère que nous ne nous noierons pas.";
			link.l1 = "Moi aussi... Moi aussi...";
			link.l1.go = "exit";
			chrDisableReloadToLocation = false;
			LAi_CharacterDisableDialog(npchar);
			AddQuestRecord("ISS_MainLine", "71");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			//офицер
			ref sld = GetCharacter(NPC_GenerateCharacter("Mechanic1", "CCS_Mechanic", "man", "man", 30, SPAIN, -1, true));
			sld.name = "Henrik";
			sld.lastname = "Wedeker";
			sld.greeting = "Gr_questOfficer";
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			// Прописка всех моделей для кирас. -->
         	sld.HeroModel = "CCS_Mechanic,CCS_Mechanic_1,CCS_Mechanic_2,CCS_Mechanic_3,CCS_Mechanic_4,CCS_Mechanic_5,CCS_Mechanic,CCS_Mechanic,CCS_Mechanic";
        	// Прописка всех моделей для кирас. <--
			sld.quest.meeting = true;
			SetSelfSkill(sld, 30, 30, 30, 30, 99);
			SetShipSkill(sld, 55, 50, 60, 45, 65, 100, 50, 90, 50);
			SetSPECIAL(sld, 6, 10, 9, 10, 10, 8, 10);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "BasicBattleState");
			SetCharacterPerk(sld, "AdvancedBattleState");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "LightRepair");
			SetCharacterPerk(sld, "InstantRepair");
			SetCharacterPerk(sld, "ShipTurnRateUp");
			SetCharacterPerk(sld, "ShipSpeedUp");
			SetCharacterPerk(sld, "StormProfessional");
			SetCharacterPerk(sld, "Carpenter");
			SetCharacterPerk(sld, "Builder");
			SetCharacterPerk(sld, "WindCatcher");
			SetCharacterPerk(sld, "SailsMan");
			SetCharacterPerk(sld, "Doctor1");
			SetCharacterPerk(sld, "Doctor2");
			TakeNItems(sld, "talisman7", 1);
			EquipCharacterbyItem(sld, "talisman7");
			sld.quest.OfficerPrice = sti(pchar.rank)*350;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.HalfImmortal = true;  // Контузия
			sld.loyality = MAX_LOYALITY;
			pchar.VedekerDiscount = true;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			AddDialogExitQuestFunction("LSC_BigStormIsBegin");
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; перк растущей жизни докладывает Sync внутри
		break;
	}
}
