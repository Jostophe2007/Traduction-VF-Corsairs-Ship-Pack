// Gregg: Jorge de Maranha - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			if (PChar.RaulEsperanto == "3")
			{
				dialog.text = "Encore vous. Alors ?";
				if (sti(PChar.money) >= BO_RE_BRIBE)
				{
					link.l1 = "J'ai l'argent.";
					link.l1.go = "4";
				}
				link.l2 = "Pas mal.";
				link.l2.go = "exit";
			}
			else
			{
				dialog.text = "Ce passage est fermé. Passez votre chemin.";
				link.l1 = "J'y vais.";
				link.l1.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Quittez ce terrain immédiatement. Personne n'a le droit d'être ici.";
			link.l1 = "Que s'est-il passé ici ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "דa ne vous regarde pas. Allez-vous-en.";
			link.l1 = "Cinq mille piastres.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(il se retourne)... Combien ?";
			// Gregg: if the coin is on him, pay here and now - sending the player away for what
			// is already in his purse is silly.
			if (sti(PChar.money) >= BO_RE_BRIBE)
			{
				link.l1 = "Cinq mille. Pour quelques réponses. Les voici, comptez-les.";
				link.l1.go = "4";
			}
			else
			{
				link.l1 = "Cinq mille. Pour quelques réponses. Je ne les ai pas sur moi pour l'instant.";
				link.l1.go = "REPLY";
			}
		break;

		case "REPLY":
			dialog.text = "Alors il n'y a pas de conversation. Apportez-les, et nous parlerons, je ne vais nulle part.";
			link.l1 = "Je les apporterai.";
			link.l1.go = "exit";
			PChar.RaulEsperanto = "3";
			// Gregg: the quest opened this dialogue, so Khorkhe was left an actor. Until he is
			// put back to stay he will not speak on the next approach, he just stands there.
			LAi_SetStayType(NPChar);
			LAi_SetPlayerType(PChar);
		break;

		case "4":
			dialog.text = "Voilà qui est mieux. Demandez.";
			link.l1 = "Pourquoi personne ne peut-il entrer dans la maison ?";
			link.l1.go = "5";
			AddMoneyToCharacter(PChar, -BO_RE_BRIBE);
			LAi_SetStayType(NPChar);
		break;

		case "5":
			dialog.text = "C'est le gouverneur général qui l'a ordonné. Raul Esperanto menait des expériences là-dedans, il y a eu une explosion, des gens ont été blessés dans la rue.";
			link.l1 = "Et oם est Esperanto lui-même ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Arrêté sur ordre du gouverneur général.";
			link.l1 = "Je vous ai demandé oם il était, pas ce qui lui est arrivé.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Pour ça, capitaine, cinq mille ne suffisent pas. Ni dix mille. Je ne suis pas avide, je compte ce que je risque.";
			link.l1 = "Alors fixez une condition au lieu d'un prix.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Une condition. Dans six jours, un navire de guerre pirate mouillera au large de Tortuga. Abordez-le, tuez son capitaine, prenez la clé sur son corps et ouvrez le coffre de la cabine. Ce qu'il contient, vous me l'apporterez au cap San Antonio.";
			link.l1 = "Et que contient-il ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Vous verrez en l'ouvrant.";
			link.l1 = "Très bien. Le cap San Antonio.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Six jours, capitaine. Si vous êtes en retard, il appareille, et notre conversation est terminée.";
			link.l1 = "Je ne serai pas en retard.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoToTortuga");
		break;

		case "12":
			dialog.text = "Vous l'avez ?";
			link.l1 = "Le voici. Comment saviez-vous que le mousquet serait à bord ?";
			link.l1.go = "13";
		break;

		case "13":
			// Gregg: the questbook uses @<sPrison>, but placeholders do not work inside a
			// dialogue line - the colony name is assembled at runtime.
			string sPrisonKey = "Colony" + PChar.RaulEsperanto.Prison + "Gen";
			dialog.text = "J'ai surpris une conversation que je n'étais pas censé entendre. Passons aux affaires. Esperanto est détenu dans la prison de " + XI_ConvertString(sPrisonKey) + ".";
			link.l1 = "Pourquoi là, justement ?";
			link.l1.go = "14";
			TakeNItems(PChar, "RaulEsperanto_Musket", -1);
			TakeNItems(PChar, "RaulEsperanto_Key", -1);
		break;

		case "14":
			dialog.text = "Parce que le grand inquisiteur y vient d'Europe, et c'est lui qui le jugera. Esperanto a passé des années à travailler sur la poudre de momie égyptienne, et il entretient des relations avec Askold. Vous connaissez Askold ?";
			link.l1 = "J'en ai entendu parler. La Guadeloupe.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "C'est bien lui. L'Inquisition a Askold sur ses listes depuis des années. Le mois oם elle a appris qu'Esperanto lui écrivait, elle l'a arrêté. Il était à portée de main.";
			link.l1 = "Et c'est là-bas aussi qu'on va le juger ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Comme je l'ai dit : l'inquisiteur s'y rend. Personne ne trimballe un prisonnier à travers la moitié de l'archipel. Et dépêchez-vous, il va débarquer d'un jour à l'autre.";
			link.l1 = "Merci, Jorge.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoToNeedPrison");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
