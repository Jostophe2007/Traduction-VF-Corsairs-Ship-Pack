// Philippe, de AoP1
#define MAX_STORY_EVENTS	100;

object HistoryEvents[MAX_STORY_EVENTS];

void ActivateHistoryEvents()
{
	FillHistoryEvents();
	//RechargeHistoryEvents();

	string sQuest = "";
	int iday, imonth, iyear;
	for(int i = 0; i<MAX_STORY_EVENTS; i++)
	{
		if (CheckAttribute(&HistoryEvents[i], "text"))
		{
			sQuest = "history_event" + "_" + i;
			iday = sti(HistoryEvents[i].day);
			imonth = sti(HistoryEvents[i].month);
			iyear = sti(HistoryEvents[i].year);

			pchar.quest.(sQuest).win_condition.l1 = "timer";
			pchar.quest.(sQuest).win_condition.l1.date.day = iday;
			pchar.quest.(sQuest).win_condition.l1.date.month = imonth;
			pchar.quest.(sQuest).win_condition.l1.date.year = iyear;
			pchar.quest.(sQuest).win_condition.l1.date.hour = rand(23);
			pchar.quest.(sQuest).win_condition = "Historical_event";
			pchar.quest.(sQuest).number = i;
		}
	}
}

void CheckHistoryEvent(string sQuest)
{
	int iNumber = sti(pchar.quest.(sQuest).number);
	//GenerateRumour("history_event", iNumber, 0, 0);//<<== Rumours.c
    GenerateRumour();
}

void FillHistoryEvents()
{
	int n = 0;

	HistoryEvents[n].text = FrS("In England, at Edgigil, the first battle took place, which initiated the civil war.", "En Angleterre, à Edgehill, a eu lieu la première bataille de la guerre civile.");
	HistoryEvents[n].day = 23;
	HistoryEvents[n].month = 10;
	HistoryEvents[n].year = 1642;
	n++;

	HistoryEvents[n].text = FrS("In France, Cardinal Richelieu died (Arman Jean du Plesi).", "En France, le cardinal de Richelieu (Armand Jean du Plessis) est mort.");
	HistoryEvents[n].day = 4;
	HistoryEvents[n].month = 12;
	HistoryEvents[n].year = 1642;
	n++;

	HistoryEvents[n].text = FrS("In France, King Louis XIII died. Giulio Raimondo Mazarin is appointed first minister and regent under the young Louis XIV.", "En France, le roi Louis XIII est mort. Jules Mazarin est nommé principal ministre et gouverne pendant la régence du jeune Louis XIV.");
	HistoryEvents[n].day = 14;
	HistoryEvents[n].month = 5;
	HistoryEvents[n].year = 1643;
	n++;

	HistoryEvents[n].text = FrS("In the Battle of Nesby, the final defeat of the armies of the English King Charles I.", "א la bataille de Naseby, les armées du roi d'Angleterre Charles Ier subissent une défaite décisive.");
	HistoryEvents[n].day = 14;
	HistoryEvents[n].month = 6;
	HistoryEvents[n].year = 1645;
	n++;

	HistoryEvents[n].text = FrS("The troops of the parliament entered Oxford and Charles I was forced to flee to Scotland.", "Les troupes du Parlement sont entrées dans Oxford ; Charles Ier a dמ s'enfuir en וcosse.");
	HistoryEvents[n].day = 23;
	HistoryEvents[n].month = 6;
	HistoryEvents[n].year = 1646;
	n++;

	HistoryEvents[n].text = FrS("In the battle near Preston, Oliver Cromwell defeated the army of Scots and captured Charles I.", "א la bataille de Preston, Oliver Cromwell a écrasé l'armée écossaise et capturé Charles Ier.");
	HistoryEvents[n].day = 17;
	HistoryEvents[n].month = 8;
	HistoryEvents[n].year = 1648;
	n++;

	HistoryEvents[n].text = FrS("Conclusion of the Treaty of Westphalia, which put an end to the Thirty Years' War.", "Signature des traités de Westphalie, qui mettent fin à la guerre de Trente Ans.");
	HistoryEvents[n].day = 24;
	HistoryEvents[n].month = 10;
	HistoryEvents[n].year = 1648;
	n++;

	HistoryEvents[n].text = FrS("On the verdict of the court in England, King Charles I was executed. England was proclaimed a republic.", "En Angleterre, sur sentence d'un tribunal, le roi Charles Ier a été exécuté. L'Angleterre est proclamée république.");
	HistoryEvents[n].day = 30;
	HistoryEvents[n].month = 1;
	HistoryEvents[n].year = 1649;
	n++;

	HistoryEvents[n].text = FrS("Oliver Cromwell dispelled the English Parliament and the Council of State.", "Oliver Cromwell a dissous le Parlement anglais et le Conseil d'וtat.");
	HistoryEvents[n].day = 20;
	HistoryEvents[n].month = 4;
	HistoryEvents[n].year = 1652;
	n++;

	HistoryEvents[n].text = FrS("England started the war with Holland.", "L'Angleterre est entrée en guerre contre la Hollande.");
	HistoryEvents[n].day = 29;
	HistoryEvents[n].month = 5;
	HistoryEvents[n].year = 1652;
	n++;

	HistoryEvents[n].text = FrS("England signed the world by Holland.", "L'Angleterre a signé la paix avec la Hollande.");
	HistoryEvents[n].day = 20;
	HistoryEvents[n].month = 4;
	HistoryEvents[n].year = 1654;
	n++;

	HistoryEvents[n].text = FrS("In Westminster Palace, a solemn ceremony of 'introduction' of Cromwell in the post of Lord Protector.", "Au palais de Westminster, Cromwell a été solennellement installé dans la charge de lord-protecteur.");
	HistoryEvents[n].day = 16;
	HistoryEvents[n].month = 2;
	HistoryEvents[n].year = 1654;
	n++;

	HistoryEvents[n].text = FrS("Coronation of Louis XIV.", "Sacre de Louis XIV.");
	HistoryEvents[n].day = 7;
	HistoryEvents[n].month = 6;
	HistoryEvents[n].year = 1654;
	n++;

	HistoryEvents[n].text = FrS("As a result of disease, Oliver Cromwell died.", "Oliver Cromwell est mort de maladie.");
	HistoryEvents[n].day = 3;
	HistoryEvents[n].month = 9;
	HistoryEvents[n].year = 1658;
	n++;

	HistoryEvents[n].text = FrS("On the Fasagne Island on the border river Bidassoa, the Pyrenean Peace between France and Spain was signed.", "Sur l'île des Faisans, au milieu de la Bidassoa qui marque la frontière, la France et l'Espagne ont signé la paix des Pyrénées.");
	HistoryEvents[n].day = 7;
	HistoryEvents[n].month = 11;
	HistoryEvents[n].year = 1659;
	n++;

	HistoryEvents[n].text = FrS("General George Monk enters the troops in London and proclaims King Charles II.", "Le général George Monck est entré dans Londres avec ses troupes et a fait proclamer le roi Charles II.");
	HistoryEvents[n].day = 29;
	HistoryEvents[n].month = 5;
	HistoryEvents[n].year = 1660;
	n++;

	HistoryEvents[n].text = FrS("In Fuenterabia, Louis XIV was considered to be a marriage to the Spanish infanta Maria Theresa.", "א Fontarabie, Louis XIV a épousé par procuration l'infante d'Espagne Marie-Thérèse.");
	HistoryEvents[n].day = 3;
	HistoryEvents[n].month = 6;
	HistoryEvents[n].year = 1660;
	n++;

	HistoryEvents[n].text = FrS("In France, Cardinal Giulio Raimondo Mazarin died. Louis XIV takes the reins in his own hands.", "En France, le cardinal Mazarin est mort. Louis XIV prend seul les rênes du pouvoir.");
	HistoryEvents[n].day = 9;
	HistoryEvents[n].month = 3;
	HistoryEvents[n].year = 1661;
	n++;

	HistoryEvents[n].text = FrS("The plague came to London.", "La peste frappe Londres.");
	HistoryEvents[n].day = 10;
	HistoryEvents[n].month = 4;
	HistoryEvents[n].year = 1665;
	n++;

	HistoryEvents[n].text = FrS("Charles II becomes King of Spain.", "Charles II devient roi d'Espagne.");
	HistoryEvents[n].day = 1;
	HistoryEvents[n].month = 1;
	HistoryEvents[n].year = 1665;
	n++;

}
