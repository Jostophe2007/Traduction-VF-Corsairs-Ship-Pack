
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if(CheckAttribute(PChar, "Arena.Mode"))
			{
				if(PChar.Arena.Mode == "Duel")
				{
					if(sti(PChar.Arena.Duel.BiletCount) == 1)
					{
						dialog.text = "Ah, c'est vous, capitaine " + GetFullName(pchar) + " ? Entrez donc !";
						link.l1 = "...";
						link.l1.go = "exit";
						AddDialogExitQuestFunction("PrepareArenaDuelEnd");
						NextDiag.TempNode = "Second Time";
						break;
					}
				}

				if(PChar.Arena.Mode == "Etaps")
				{
					if(sti(PChar.Arena.Etaps.BiletCount) == 1)
					{
						dialog.text = "Ah, c'est vous, capitaine " + GetFullName(pchar) + " ? Vous avez décidé d'affronter toutes sortes de créatures impies ?";
						link.l1 = "Ouais... Allez, laisse-moi passer.";
						link.l1.go = "exit";
						AddDialogExitQuestFunction("PrepareArenaEtapsEnd");
						NextDiag.TempNode = "Second Time";
						break;
					}
				}

				if(PChar.Arena.Mode == "Tournament")
				{
					if(sti(PChar.Arena.Tournament.BiletCount) == 1)
					{
						dialog.text = "Ah, c'est vous, capitaine " + GetFullName(pchar) + " ? Tous les participants du tournoi sont déjà réunis ! Les combats s'annoncent très violents. Bonne chance à vous, capitaine...";
						link.l1 = "Merci...";
						link.l1.go = "exit";
						AddDialogExitQuestFunction("PrepareArenaTournamentEnd");
						NextDiag.TempNode = "Second Time";
						break;
					}
				}

				if(PChar.Arena.Mode == "Odds")
				{
					if(sti(PChar.Arena.Odds.BiletCount) == 1)
					{
						dialog.text = "Ah, c'est vous, capitaine " + GetFullName(pchar) + " ? J'ai entendu dire que vous aviez fait un pari et décidé de tenter votre chance en misant sur l'un des duellistes ? Je vous souhaite bonne chance !";
						link.l1 = "Merci...";
						link.l1.go = "exit";
						AddDialogExitQuestFunction("PrepareArenaOddsEnd");
						NextDiag.TempNode = "Second Time";
						break;
					}
				}

				if(PChar.Arena.Mode.NotOdd == true)
				{
					dialog.text = "Halte ! Qui es-tu, toi ? Montre ton billet, sinon j'appelle la garde !";

					if(GetCharacterItem(PChar, "ArenaBilet"))
					{
						link.l1 = "Voici mon billet. Maintenant, ouvre !";
						link.l1.go = "Bilet_Action";
					}
					link.l2 = "Euh... Je reviendrai plus tard.";
					link.l2.go = "exit";
					AddDialogExitQuestFunction("PrepareArenaOddsBilet");
				}
			}

			NextDiag.TempNode = "First time";
		break;

		case "Bilet_Action":
			TakeItemFromCharacter(PChar, "ArenaBilet");
			dialog.text = "Euh... Bon, bon... Maintenant, vous pouvez passer.";
			link.l1 = "Voilà qui est mieux.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("PrepareArenaOddsEnd");
			NextDiag.TempNode = "Second Time";
		break;


		case "Second Time":
			dialog.text = "Voulez-vous acheter des élixirs et de la nourriture ? Ils vous seront très utiles au combat !";
			link.l1 = "Oui.";
			link.l1.go = "Trade_exit";
			link.l2 = "Non.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Second Time";
		break;

		case "Trade_exit":
            		if(CheckNPCQuestDate(NPChar, "Item_date"))
			{
				SetNPCQuestDate(NPChar, "Item_date");
				ArenaBileterGiveItems(NPChar);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(NPChar);
		break;


		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "":
			dialog.text = NPCStringReactionRepeat("",
				"",
				"",
                "", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("",
				"",
                "",
				"", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
		break;

		case "":
			dialog.text = "";
			link.l1 = "";
			link.l1.go = "_1";
		break;
		case "_1":
			dialog.text = "";
			link.l1 = "";
			link.l1.go = "_2";
		break;
		case "_2":
			dialog.text = "";
			link.l1 = "";
			link.l1.go = "_3";
		break;
		case "_4":
			dialog.text = "";
			link.l1 = "";
			link.l1.go = "_5";
		break;
	}
}
