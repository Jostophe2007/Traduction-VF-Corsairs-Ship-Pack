#define DIPLOMAT_SUM 80000

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iSumm = 0;
	string s1;

	if (!CheckAttribute(npchar, "PatentPrice"))
    {
		if (IsCharacterPerkOn(pchar, "Adventurer")) npchar.PatentPrice = (6000 + rand(4) * 500);
        else npchar.PatentPrice = (8000 + rand(6) * 1000);
    }
    int i;
    string attrLoc;
	ref    sld;

    attrLoc   = Dialog.CurrentNode;

    if (findsubstr(attrLoc, "SetNationPatent_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.nation = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 	    Dialog.CurrentNode = "patent_2";
 	}

 	if (findsubstr(attrLoc, "SetNationLicence_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.LicenceNation = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 	    Dialog.CurrentNode = "NationLicenceType";
 	}

 	if (findsubstr(attrLoc, "NationLicenceType_" , 0) != -1)
 	{
	 	NPChar.LicenceType = GetStrSmallRegister(dialogEditStrings[3]);
		if (sti(NPChar.LicenceType) < 10) NPChar.LicenceType = 10;
 	    Dialog.CurrentNode = "NationLicenceType2";
 	}

 	if (findsubstr(attrLoc, "RelationTo_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
        npchar.quest.relation      = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
		// проверка на уже договор
		attrLoc = "RelationAgent" + GetNationNameByType(sti(npchar.quest.relation));
		if (CheckAttribute(Pchar, "GenQuest." + attrLoc) && sti(Pchar.GenQuest.(attrLoc)) == true)
		{
		    Dialog.CurrentNode = "RelationYet";
		}
		else
		{
 	    	Dialog.CurrentNode = "RelationAny_Done";
 	    	npchar.quest.relation.summ = CalculateRelationSum(sti(npchar.quest.relation)) * MOD_SKILL_ENEMY_RATE*3;
 	    }
 	}

 	if (findsubstr(attrLoc, "CityPay_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.quest.CityIdx = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 	    Dialog.CurrentNode = "CityInfo";
 	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Content de vous revoir.";
			link.l1 = "J'ai de nouveau besoin de vos services.";
			link.l1.go = "relation";
			link.l2 = "Je m'en vais déjà.";
			link.l2.go = "exit";
			//линейка ГПК, поиски торгашей -->
			if (pchar.questTemp.LSC == "toLicencer")
			{
				link.l3 = "J'ai une question pour vous au sujet de la Compagnie néerlandaise des Indes occidentales.";
				link.l3.go = "SeekHVIC";
			}
			if (pchar.questTemp.LSC == "toLicencer_2")
			{
				link.l3 = "Hum, pardonnez ma tête de linotte. Je reviens sur la Compagnie néerlandaise des Indes occidentales.";
				link.l3.go = "SeekHVIC_3";
			}
			// генератор  "Найденные документы"
			if ((pchar.questTemp.different == "GiveShipLetters") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakAgent"))
			{
				link.l4 = "Je veux vous proposer une affaire."
				link.l4.go = "D_ShipLetters_1";
				pchar.questTemp.different.GiveShipLetters.speakAgent = true;
			}
			//<-- линейка ГПК, поиски торгашей
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Permettez-moi de me présenter : je suis la personne qui peut glisser un bon mot pour vous à tel ou tel gouverneur. Moyennant finance, bien sמr, mais croyez-moi, mes services sont de la plus haute qualité, et vous ne regretterez pas d'avoir fait appel à mes talents.";
				if (CheckAttribute(pchar, "Whisper.BuyDocuments"))
				{
					link.l1 = "On m'a dit que vous pourriez m'aider à obtenir la citoyenneté de l'une des nations.";
					link.l1.go = "WhisperDocuments";
					break;
				}
				link.l1 = "Très intéressant, continuez.";
				link.l1.go = "relation";
				link.l2 = "Une autre fois, peut-être.";
				link.l2.go = "exit";
				npchar.quest.meeting = "1";
			}

			NextDiag.TempNode = "First time";
		break;

		//*************************** Линейка Виспер **************
		case "WhisperDocuments":
			dialog.text = "Très bien. Ce service vous coמtera 1000 pièces. Quelle citoyenneté voulez-vous obtenir ?";
			DeleteAttribute(Pchar, "perks.list.FlagSpa");
			DeleteAttribute(Pchar, "Whisper.BuyDocuments");
			if(makeint(Pchar.money) >= 1000)
            {
				link.l1 = "L'Angleterre.";
				link.l1.go = "WhisperEng";
				link.l2 = "La France.";
				link.l2.go = "WhisperFra";
				link.l3 = "La Hollande.";
				link.l3.go = "WhisperHol";
			}
			link.l4 = "Vous savez, je préfère devenir corsaire libre.";
			link.l4.go = "Whisper_exit";
		break;

		case "WhisperEng":
			dialog.text = "Bien. Il ne reste plus qu'à signer ici, et vous avez officiellement la citoyenneté anglaise.";
			Pchar.BaseNation = ENGLAND;
			SetCharacterPerk(Pchar, "FlagEng");
			AddMoneyToCharacter(pchar, -1000);
			Flag_Change(ENGLAND);
			pchar.Whisper.GotCitizenship = true; // Gregg: метка «оформила гражданство» — чтобы узел Whisper_exit не сбросил её обратно в корсары
			link.l1 = "C'est fait.";
			link.l1.go = "Whisper_exit";
		break;
		case "WhisperFra":
			dialog.text = "Bien. Il ne reste plus qu'à signer ici, et vous avez officiellement la citoyenneté française.";
			Pchar.BaseNation = FRANCE;
			SetCharacterPerk(Pchar, "FlagFra");
			AddMoneyToCharacter(pchar, -1000);
			Flag_Change(FRANCE);
			pchar.Whisper.GotCitizenship = true; // Gregg: метка «оформила гражданство» — чтобы узел Whisper_exit не сбросил её обратно в корсары
			link.l1 = "C'est fait.";
			link.l1.go = "Whisper_exit";
		break;
		case "WhisperHol":
			dialog.text = "Bien. Il ne reste plus qu'à signer ici, et vous avez officiellement la citoyenneté hollandaise.";
			AddMoneyToCharacter(pchar, -1000);
			Pchar.BaseNation = HOLLAND;
			SetCharacterPerk(pchar, "FlagHol");
			Flag_Change(HOLLAND);
			pchar.Whisper.GotCitizenship = true; // Gregg: метка «оформила гражданство» — чтобы узел Whisper_exit не сбросил её обратно в корсары
			link.l1 = "C'est fait.";
			link.l1.go = "Whisper_exit";
		break;
		case "Whisper_exit":
			dialog.text = "Voici vos papiers, ne les perdez pas. Soufflez un peu sur l'encre pour la sécher, sinon elle va baver.\nBonne continuation.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "Whisper.GotCitizenship")) // Gregg: гражданство в этом диалоге не оформлено => выбран путь «вольной корсарки» (надёжнее, чем сверять BaseNation)
			{
				dialog.text = "Dans ce cas, je vous prie de ne pas me distraire.";
				Pchar.BaseNation = PIRATE;
				Flag_Change(PIRATE);
			}
			DeleteAttribute(pchar, "Whisper.GotCitizenship"); // Gregg: снять метку, чтобы повторный визит трактовался корректно
			PChar.quest.WhisperPirateTownGetHat.win_condition.l1 = "location";
			PChar.quest.WhisperPirateTownGetHat.win_condition.l1.location = "PuertoPrincipe_town";
			PChar.quest.WhisperPirateTownGetHat.function = "WhisperPirateTownGetHat";
			PChar.quest.WhisperPirateTownBattle.win_condition.l1 = "location";
			PChar.quest.WhisperPirateTownBattle.win_condition.l1.location = "PuertoPrincipe_ExitTown";
			PChar.quest.WhisperPirateTownBattle.function = "WhisperPirateTownBattle";
			SetLocationCapturedState("PuertoPrincipe_town", true);
		break;
		//*************************** Генератор - "Found ship's documents" **************
		case "D_ShipLetters_1":
			dialog.text = "Exposez vos conditions.";
			s1 = "Par un heureux hasard, je me suis retrouvé avec un jeu de documents de bord parfaitement légal, qui n'est pas encore sur la liste des avis de recherche.";
			s1 = s1 + "Le navire est à flot et n'a pas été rayé du registre, ne vous inquiétez pas. C'est juste que son propriétaire a réussi à égarer ces papiers...";
			link.l1 = s1;
			link.l1.go = "D_ShipLetters_2";
		break;
		case "D_ShipLetters_2":
			s1 = "Voyons voir ! En effet, les cachets sont tout frais. Eh bien, la chance vous sourit, "+ GetSexPhrase("monsieur","madame") +" ! ";
			s1 = s1 + "Il me fallait justement un tel jeu, et je vous offre en échange " + sti(pchar.questTemp.different.GiveShipLetters.price5) + " piastres. Qu'en dites-vous ?";
			dialog.text = s1;
			link.l1 = "Une générosité vraiment royale ! Bien sמr que je suis "+ GetSexPhrase("d'accord","d'accord") +" !";
			link.l1.go = "D_ShipLetters_3";
			link.l2 = "Plutכt pas.";
			link.l2.go = "exit";
		break;
		case "D_ShipLetters_3":
			TakeItemFromCharacter(pchar, "CaptainBook");
			addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price5));
			ChangeCharacterReputation(pchar, -1);
			OfficersReaction("bad");
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "9");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "relation":
			dialog.text = "Voyons comment je peux vous aider.";
            //#20200219-01
			int charNat = sti(pchar.nation);
			bool bCheck = false;
            if(GetNationRelation2MainCharacter(ENGLAND) > GetNationRelation(charNat, ENGLAND))
                bCheck = true;
            if (ChangeCharacterNationReputation(pchar, ENGLAND, 0) < 0 || bCheck)
			{
				link.l3 = "Je veux faire la paix avec l'Angleterre.";
				link.l3.go = "RelationTo_0";
			}
			if (ChangeCharacterNationReputation(pchar, FRANCE, 0) < 0 || bCheck)
			{
				link.l1 = "Je veux faire la paix avec la France.";
				link.l1.go = "RelationTo_1";
			}
			if (ChangeCharacterNationReputation(pchar, SPAIN, 0) < 0 || bCheck)
			{
				link.l2 = "Je veux faire la paix avec l'Espagne.";
				link.l2.go = "RelationTo_2";
			}
			if (ChangeCharacterNationReputation(pchar, HOLLAND, 0) < 0 || bCheck)
			{
				link.l4 = "Je veux faire la paix avec la Hollande.";
				link.l4.go = "RelationTo_3";
			}
			if (ChangeContrabandRelation(pchar, 0) <= 5)
            {
                Link.l5 = "Je veux faire la paix avec les contrebandiers.";
				Link.l5.go = "Contraband";
            }
			
            Link.l8 = "J'ai besoin d'une lettre de marque.";
			Link.l8.go = "patent_0";

			Link.l9 = "Avez-vous des licences de commerce ?";
			Link.l9.go = "Licence";

			if (isHeroOwnCity(true))
			{
				Link.l10 = "J'ai une question concernant l'appartenance des colonies.";
				Link.l10.go = "City_Buy";
			}

			Link.l11 = "J'ai eu un différend avec un corsaire, et je voudrais améliorer nos relations. Pouvez-vous arranger ça ?";
			Link.l11.go = "PGG_peace";

			link.l99 = "Vous savez, je crois que je vais me débrouiller par moi-même.";
			link.l99.go = "exit";
		break;

		case "PGG_peace":
			dialog.text = "De quelle personne parlons-nous ?";
			for(i=1; i<=PsHeroQty; i++)
			{
				sld = CharacterFromID("PsHero_"+i);
				if (PGG_ChangeRelation2MainCharacter(sld, 0) < 41 && !LAi_IsDead(sld) && sld.PGGAi.location != "Dead" && !IsCompanion(sld) && !IsOfficer(sld))
				{
					string attr = sld.ID;
					string linkPGG = "l" + i;
					NPChar.Temp.(attr) = attr;
					Link.(linkPGG) = GetFullName(sld);
					Link.(linkPGG).go = "PGG_make_peace_with_" + attr;
				}
				else
				{
					NPChar.Temp.(attr) = "";
				}
			}
			link.lexit = "Laisse tomber.";
			link.lexit.go = "exit";
		break;

		int nFind = findSubStr(Dialog.CurrentNode, "PGG_make_peace_with_", 0);
		string idxVal;
		string nodName;
		if(nFind == 0)
		{
            npchar.PGGSelected = strcut(Dialog.CurrentNode, 20, strlen(Dialog.CurrentNode)-1);
			sld = CharacterFromID(npchar.PGGSelected);
			npchar.PGGPeaceMoney = ((sti(sld.rank) + sti(pchar.rank))/4 + (60 - PGG_ChangeRelation2MainCharacter(sld, 0))) * 1000;
			dialog.Text = "Oui, j'ai entendu dire que " + GetFullName(CharacterFromID(npchar.PGGSelected)) +" souhaite votre mort de toute " + NPCharSexPhrase(sld, "son","son") + " âme. Je pense pouvoir trouver un cadeau approprié pour " + NPCharSexPhrase(sld, "lui","lui") + " afin de vous attirer ses bonnes grâces. Mais ce service vous coמtera "+ npchar.PGGPeaceMoney +" piastres.";
			if (sti(pchar.money) >= sti(npchar.PGGPeaceMoney))
			{

				Link.l1 ="J'accepte, mettez-vous au travail.";
				Link.l1.go = "PGG_peace_made";
			}
			Link.l2 = "J'ai changé d'avis, pardon.";
            Link.l2.go = "exit";
            break;
        }

		case "PGG_peace_made":
			sld = CharacterFromID(npchar.PGGSelected);
			int addPGGrelation = 60 - PGG_ChangeRelation2MainCharacter(sld, 0);
			PGG_ChangeRelation2MainCharacter(sld, addPGGrelation);
			addMoneyToCharacter(pchar, -sti(npchar.PGGPeaceMoney));

			// LEO: мира одним числом мало - иначе оплаченный мир был на бумаге: в таверне ПГГ звал
			//   на дело, а в море шёл в атаку по AlwaysEnemy. Плавание проверяем ДО замирения
			//   (оно распускает флот), город берём ПОСЛЕ - там уже настоящая нация, не пиратская.
			bool bPGGWasAtSea = CheckAttribute(sld, "PGGAi.Task.SetSail");
			PGG_MakePeace(sld);
			if (bPGGWasAtSea) sld.PGGAi.location.town = PGG_FindRandomTownByNation(sti(sld.nation));

			dialog.Text = "Considérez que tout est déjà réglé. Toute traque que "+ GetFullName(sld) +" pourrait mener contre vous devrait bientכt cesser."
			Link.l1 ="J'espère que vous avez raison.";
			Link.l1.go = "exit";
		break;

		case "Licence":
			dialog.text = "Hélas, je ne m'occupe plus des licences de commerce. Seule la Compagnie néerlandaise des Indes occidentales les délivre désormais : adressez-vous à ses représentants à Marigot ou à Willemstad. Ils ont une licence universelle, valable pour toutes les nations.";
			link.l9 = "Je vois, merci du conseil.";
			link.l9.go = "exit";
		break;

		case "NationLicenceType":
        	dialog.text = "Pour quelle durée (en jours) ? Les licences ne sont pas délivrées pour moins de 10 jours.";
			link.l1.edit = 3;
		    link.l1 = "10 jours";
			link.l1.go = "NationLicenceType_10";
			link.l9 = "J'ai changé d'avis.";
			link.l9.go = "exit";
		break;

		case "NationLicenceType2":
			if (IsCharacterPerkOn(pchar, "Agent") || IsCharacterPerkOn(pchar, "Trader"))  iSumm = sti(npchar.LicenceType) * 1000 + (sti(PChar.rank) * 2500);
			else iSumm = iSumm = sti(npchar.LicenceType) * 1000 + (sti(PChar.rank) * 5000);
        	dialog.text = "Donc, licence : " + XI_ConvertString(Nations[sti(npchar.LicenceNation)].Name + "Gen") + " , pour " + sti(npchar.LicenceType) + " jours, coמt : " + FindRussianMoneyString(iSumm) + ".";
		    link.l1 = "דa me va.";
		    if(makeint(Pchar.money) < iSumm)
            {
				Link.l1.go = "No_money";
			}
            else
			{
				link.l1.go = "NationLicenceType3";
			}
			link.l9 = "J'ai changé d'avis.";
			link.l9.go = "exit";
		break;

		case "NationLicenceType3":
			if (IsCharacterPerkOn(pchar, "Agent") || IsCharacterPerkOn(pchar, "Trader"))  iSumm = sti(npchar.LicenceType) * 1000 + (sti(PChar.rank) * 2500);
			else iSumm = iSumm = sti(npchar.LicenceType) * 1000 + (sti(PChar.rank) * 5000);
			dialog.text = "Voici votre document. Vous devez entrer au port sous un pavillon ami. Souvenez-vous, la patrouille peut vérifier si la licence a expiré.";
			link.l9 = "Merci.";
			link.l9.go = "exit";
			AddMoneyToCharacter(pchar, -iSumm);
			GiveNationLicence(sti(npchar.LicenceNation), sti(npchar.LicenceType));
		break;

        case "No_money":
			dialog.text = "Parfait ! Revenez me voir quand vous aurez la somme nécessaire.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
		break;

        case "patent_0":
			dialog.text = "Parfait ! Pour cela, vous devez prouver votre loyauté envers l'וtat" +
                          " par un service irréprochable. Allez voir n'importe quel gouverneur" + //NationNameGenitive(sti(NPChar.nation)) +
                          " et accomplissez plusieurs de ses missions. Il vous accordera alors une lettre de marque.";
			link.l1 = "Dites-moi, "+GetAddress_FormToNPC(NPChar) + ", y a-t-il un moyen de contourner cette formalité ?";
			link.l1.go = "patent_1";
			link.l2 = "Au revoir, "+GetAddress_FormToNPC(NPChar);
			link.l2.go = "exit";
		break;

		case "patent_1":
			dialog.text = "Vous voulez dire soudoyer un fonctionnaire !? Vous voulez que je vous délivre moi-même une lettre de marque ?";
			link.l1 = "Exactement !";
			if (pchar.questTemp.piratesLine == "begin" || pchar.questTemp.piratesLine == "over" || pchar.questTemp.piratesLine == "waiting_Q8")
			{
				if (GetCharacterSkillToOld(PChar, SKILL_FORTUNE) > rand(11) || bBettaTestMode)
				{
					link.l1.go = "patent_2_give";
				}
				else
				{
					link.l1.go = "patent_2_none";
				}
			}
			else link.l1.go = "patent_2_none2";
			link.l2 = "Non. Bonne journée, "+GetAddress_FormToNPC(NPChar);
			link.l2.go = "exit";
		break;

		case "patent_2_none":
			dialog.text = "Pour le moment, je n'ai pas les relations nécessaires pour obtenir un formulaire vierge de lettre de marque avec tous les sceaux et toutes les signatures.";
            link.l1 = "Dommage. Au revoir, "+GetAddress_FormToNPC(NPChar);
			link.l1.go = "exit";
		break;

		case "patent_2_none2":
			dialog.text = "D'après ce que je sais, vous travaillez pour les Frères de la Cכte, et donc, même une lettre de marque ne vous permettra pas d'entrer au service d'un gouverneur général.";
            link.l1 = "Dommage. Au revoir, "+GetAddress_FormToNPC(NPChar);
			link.l1.go = "exit";
		break;

		case "patent_2_give":
			dialog.text = "Bien, je peux arranger ça. Quelle lettre de marque vous faut-il ?";
			if (GetPatentNation() != ENGLAND)
			{
			    link.l1 = "Angleterre";
				link.l1.go = "SetNationPatent_0";
			}
			if (GetPatentNation() != FRANCE)
			{
			    link.l2 = "France";
				link.l2.go = "SetNationPatent_1";
			}
			if (GetPatentNation() != SPAIN)
			{
			    link.l3 = "Espagne";
				link.l3.go = "SetNationPatent_2";
			}
			if (GetPatentNation() != HOLLAND)
			{
			    link.l4 = "Hollande";
				link.l4.go = "SetNationPatent_3";
			}
			link.l9 = "Vous savez, je crois que je vais me débrouiller par moi-même.";
			link.l9.go = "exit";
		break;

		case "patent_2":
			if (IsCharacterPerkOn(pchar, "Agent")) pchar.PatentPrice = 100000 * MOD_SKILL_ENEMY_RATE*3 - (GetSummonSkillFromName(PChar, SKILL_LEADERSHIP)) * 5000 + 35000 + (sti(PChar.rank)*5000);
			else pchar.PatentPrice = 150000 * MOD_SKILL_ENEMY_RATE*3 - (GetSummonSkillFromName(PChar, SKILL_LEADERSHIP)) * 5000 + 500000 + (sti(PChar.rank)*5000);
            switch (sti(NPChar.nation))
            {
			    case PIRATE :
                    dialog.text = "Bogue manifeste ; si vous voyez ce message, signalez-le à ALexusB.";
                    link.l1 = "Pas une mauvaise perspective. J'accepte vos conditions !";
                    break;
                case HOLLAND :
                    dialog.text = "La Hollande est un pays presque pacifique : vous aurez beaucoup d'amis et peu d'ennemis. Et la lettre de marque elle-même ne vous coמtera que "+pchar.PatentPrice+" pièces d'or.";
                    link.l1 = "Pas une mauvaise perspective. J'accepte vos conditions !";
                    break;
                case FRANCE :
                    dialog.text = "Les amis et les ennemis de la France deviendront les vכtres. Vous pourrez couler les navires ennemis. Et la lettre de marque elle-même ne vous coמtera que "+pchar.PatentPrice+" pièces d'or.";
                    link.l1 = "Superbe perspective ! Peu m'importe qui je sers ! Je servirai aussi les Français !";
                    break;
                case SPAIN :
                    dialog.text = "L'Espagne a beaucoup d'ennemis, et ils deviendront aussitכt les vכtres ! Les Espagnols sont une nation de guerriers de la mer. La lettre de marque ne vous coמtera que "+pchar.PatentPrice+" pièces d'or.";
                    link.l1 = "Vous êtes le seul à me proposer quelque chose qui en vaille la peine ! Prenez ces malheureux sous, pour le romantisme des batailles sanglantes et de nouvelles missions confiées par de hauts personnages !";
                    break;
                case ENGLAND :
                    dialog.text = "Pour être honnête, c'est comme ça que le gouverneur général d'Angleterre se remplit les poches. Et la lettre de marque elle-même ne vous coמtera que "+pchar.PatentPrice+" pièces d'or. ";
                    link.l1 = "J'accepte de vous donner mon argent durement gagné par la contrebande et les abordages !!";
                    break;
			}

            if(makeint(Pchar.money) < makeint(pchar.PatentPrice))
            {
				Link.l1.go = "No_money";
			}
            else
			{
				link.l1.go = "patent_3";
			}

			link.l2 = "Non, ce n'est pas pour moi !";
			link.l2.go = "exit";
		break;

		case "patent_3":
            pchar.PatentNation = NationShortName(sti(NPChar.nation));
			dialog.text = "Je suis content que nous soyons d'accord. Marché conclu.";
			link.l1 = "Au revoir, "+GetAddress_FormToNPC(NPChar);
			link.l1.go = "exit";
			AddDialogExitQuest("any_patent_take");
		break;

		case "Contraband":
			if (IsCharacterPerkOn(pchar, "Agent")) Pchar.questTemp.Relations.sum = makeint(0.3 * stf(Pchar.rank)/stf(Pchar.reputation)*DIPLOMAT_SUM);
			else Pchar.questTemp.Relations.sum = makeint(0.1 * stf(Pchar.rank)/stf(Pchar.reputation)*DIPLOMAT_SUM);
			dialog.Text = "Bien. Cela coמtera " + Pchar.questTemp.Relations.sum + " pièces d'or.";
			Link.l1 = "J'accepte.";
			if(makeint(Pchar.money) < makeint(Pchar.questTemp.Relations.sum))
			{
				Link.l1.go = "No_money";
			}
			else
			{
				Link.l1.go = "Contraband_Agreed";
			}
			Link.l2 = "Je crois que j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Contraband_Agreed":
			dialog.Text = "Parfait, je m'en occupe. On s'occupera de vous.";
			Link.l99 = "Merci.";
			Link.l99.go = "exit";
			ChangeContrabandRelation(pchar, 25);
			AddMoneyToCharacter(pchar, -sti(Pchar.questTemp.Relations.sum));
		break;
        // boal <--
		case "RelationAny_Done":
			iSumm = sti(npchar.quest.relation.summ);
			dialog.text = "Hum... Je ne sais même pas quoi dire. Je pourrai certainement satisfaire votre demande de réconciliation avec "+ NationNameGenitive(sti(npchar.quest.relation)) +", mais cela vous coמtera " + FindRussianMoneyString(iSumm) + ".";
			if(sti(pchar.money) >= iSumm)
			{
				link.l1 = "Je crois que je n'ai pas le choix, de toute façon. Alors, voici votre argent.";
				link.l1.go = "relation3";
			}
			link.l2 = "Non, c'est trop d'argent. Au revoir.";
			link.l2.go = "exit";
		break;

		case "relation3":
			dialog.text = "Parfait ! On traite facilement avec vous, c'est étonnant. Vous pouvez être tranquille : dans 15 jours au plus, vos affaires seront réglées.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(npchar.quest.relation.summ));
			ChangeNationRelationFromRelationAgent(npchar);
			attrLoc = "RelationAgent" + GetNationNameByType(sti(npchar.quest.relation));
            Pchar.GenQuest.(attrLoc) = true;
		break;

		case "RelationYet":
			dialog.Text = "Une requête a déjà été envoyée pour vous. Patientez, ces choses-là ne se font pas si vite.";
			Link.l99 = "Merci.";
			Link.l99.go = "exit";
		break;

		case "City_Buy":
			dialog.Text = "De quelle colonie voulez-vous parler ?";
			for (i=0; i<MAX_COLONIES; i++)
			{
				if (sti(colonies[i].HeroOwn) == true && sti(colonies[i].isBought) == false)
				{
					sld = GetFortCommander(colonies[i].id);
					attrLoc = "l" + i;
					Link.(attrLoc) = GetCityName(colonies[i].id) + " - " + XI_ConvertString(GetNationNameByType(sti(sld.Default.nation)));
					Link.(attrLoc).go = "CityPay_" + i;
				}
			}
			Link.l99 = "Non. Rien.";
			Link.l99.go = "exit";
		break;

		case "CityInfo":
            i = sti(NPChar.quest.CityIdx);
            sld = GetFortCommander(colonies[i].id);
            iSumm = TWN_CityCost(colonies[i].id);
			dialog.Text = "La ville de " + GetCityName(colonies[i].id) + " (ancienne possession : " + XI_ConvertString(GetNationNameByType(sti(sld.Default.nation)) + "Gen") + ") : le montant de la rançon pour mettre fin aux tentatives de reprise de la colonie sera de " + FindRussianMoneyString(iSumm) + ".";
   			if(sti(pchar.money) >= iSumm)
			{
			    Link.l1 = "Oui, ça me va.";
				Link.l1.go = "City_Buy_End";
			}
			Link.l99 = "Non, merci. דa ne m'intéresse pas.";
			Link.l99.go = "exit";
		break;

		case "City_Buy_End":
            i = sti(NPChar.quest.CityIdx);
            TWN_RealeseForMoney(colonies[i].id, true);
			dialog.Text = "Bien, l'information sur l'accord a été transmise. Il n'y aura plus aucune tentative de reprise de la ville de " + GetCityName(colonies[i].id) + " désormais.";
			Link.l2 = "Merci. Bonne journée.";
			Link.l2.go = "exit";
			Link.l3 = "Encore une question.";
			Link.l3.go = "relation";
		break;
		//линейка ГПК
		case "SeekHVIC":
			dialog.text = "Hum, voyez-vous ça... Capitaine, qu'est-ce qui vous intéresse tant dans ce bureau ?";
			link.l1 = "J'exécute une commande pour eux, et j'ai des questions.";
			link.l1.go = "SeekHVIC_1";
		break;
		case "SeekHVIC_1":
			dialog.text = "Qu'est-ce qui vous fait croire que je sais oם ils sont ?";
			link.l1 = "Bon, arrêtez de faire l'imbécile ! Oם est-ce que vous obtenez les licences de cette compagnie ?";
			link.l1.go = "SeekHVIC_2";
		break;
		case "SeekHVIC_2":
			dialog.text = "Chez le représentant de la Compagnie ici, dans les Caraïbes. D'ailleurs, comment s'appelle-t-il ? Si vous traitez avec lui, vous devriez le savoir.";
			Link.l1.edit = 6;
			link.l1 = "";
			link.l1.go = "SeekHVIC_res";
		break;
		case "SeekHVIC_res":
			attrLoc = GetStrSmallRegister(dialogEditStrings[6]);
			if (findsubstr(attrLoc, "oliver" , 0) != -1 && findsubstr(attrLoc, "trust" , 0) != -1)
			{
				dialog.text = "Hum, c'est juste... Eh bien, vous le trouverez à Saint-Martin, à Marigot. Il a un bureau dans la représentation de la Compagnie, un grand bâtiment administratif gardé, difficile à manquer. Ne dites pas que c'est moi qui vous envoie. On ne sait jamais...";
				link.l1 = "Pas de problème.";
				link.l1.go = "exit";
				pchar.questTemp.LSC = "toOliverTrast";
				AddQuestRecord("ISS_PoorsMurder", "10");
				LocatorReloadEnterDisable("Marigo_town", "houseH2", false);
				if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("PoorKillSponsor", "smuggler_boss", "man", "man_fast", 30, PIRATE, -1, true)); // LEO: Страдать превозмогаторам 07.12.2021
				else sld = GetCharacter(NPC_GenerateCharacter("PoorKillSponsor", "smuggler_boss", "man", "man", 30, PIRATE, -1, true));
				sld.name = "Oliver";
				sld.lastname = "Trust";
				FantomMakeCoolFighter(sld, 40, 90, 90, "blade26", "pistol3", 100);
				sld.SaveItemsForDead = true;
				AddItems(sld, "talisman5", 1);
				if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
				sld.Dialog.Filename = "Quest\ForAll_dialog.c";
				sld.dialog.currentnode = "Begin_PoorKill";
				sld.nation = HOLLAND;
				sld.city = "Marigo_town";
				sld.location = "Marigo_houseH2";
				sld.location.group = "sit";
				sld.location.locator = "sit1";
				sld.dialog.currentnode = "PKInMarigo";
				sld.items.letter_LSC = 1;
				LAi_CharacterEnableDialog(sld);
				LAi_RemoveLoginTime(sld);
				sld.standUp = true; //вставать и нападать на врага
				LAi_SetHuberType(sld);
				ChangeItemName("letter_LSC", "itmname_letter_LSC_1");
				ChangeItemDescribe("letter_LSC", "itmdescr_letter_LSC_1");
                pchar.restoreLSCTrustLetter = "letter_LSC";
			}
			else
			{
				dialog.text = "Vous ne connaissez personne, alors dehors !";
				link.l1 = "Bon sang, ça m'est sorti de la tête...";
				link.l1.go = "exit";
				pchar.questTemp.LSC = "toLicencer_2";
			}
		break;
		case "SeekHVIC_3":
			dialog.text = "Eh bien, que me voulez-vous encore ?";
			link.l1 = "Le nom du représentant de la Compagnie néerlandaise des Indes occidentales m'est revenu !";
			link.l1.go = "SeekHVIC_4";
		break;
		case "SeekHVIC_4":
			dialog.text = "Oui ?! Eh bien, comment s'appelle-t-il ?";
			Link.l1.edit = 6;
			link.l1 = "";
			link.l1.go = "SeekHVIC_res";
		break;
	}
}

