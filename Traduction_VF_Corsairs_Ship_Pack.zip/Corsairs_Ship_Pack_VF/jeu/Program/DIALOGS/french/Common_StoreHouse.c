
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = LinkRandPhrase("Bonjour ! Ce n'est pas facile d'être magasinier...", "Oh, on s'ennuie à mourir ici !", "Oh, bon sang, que voulez-vous faire ?");
			link.l1 = LinkRandPhrase("Bien sמr !", "Je comprends...", "Oui, vous avez de sérieux problèmes...");
			link.l1.go = "exit";
			link.l2 = "Bonjour, " + npchar.name + ". Je compte m'intéresser aux affaires de l'entrepכt, et peut-être y laisser quelque chose en dépכt.";
			link.l2.go = "StoreHouse_Details";
			link.l3 = "Et rien ne disparaîtra d'ici, si je décide d'y laisser quelque chose de personnel ?";
			link.l3.go = "StoreHouse_Details2";

		break;

		case "StoreHouse_Details":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchStorage(STORE_HOUSE);
		break;

		case "StoreHouse_Details2":
			dialog.text = "Je vous garantis sur ma tête que rien de ce qui vous appartient ne disparaîtra d'ici. Vous pouvez y laisser tout ce que vous voulez, "+GetSexPhrase("monsieur !", "madame !");
			link.l1 = "Parfait ! Alors, à plus tard.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

	}
}
