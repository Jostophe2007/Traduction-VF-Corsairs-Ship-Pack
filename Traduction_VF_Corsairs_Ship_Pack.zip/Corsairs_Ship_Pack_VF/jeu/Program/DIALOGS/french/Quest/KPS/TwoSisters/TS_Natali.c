// Gregg: Natali Remis and Ortodokse Malkin - "Two Sisters", the Bermudas branch.
// Logic - Program\Quests\reaction_functions\twosisters.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		// Malkin quarrels with Natali in the street - the hero walks in on the noise
		case "1":
			SetCameraDialogMode(NPChar);
			dialog.text = "...(sans remarquer le nouveau venu)... Qui a besoin de toi, imbécile ? Il y en a dix comme toi sur chaque quai, et tous plus faciles à vivre.";
			link.l1 = "...(s'arrêter)...";
			link.l1.go = "2";
		break;

		case "2":
			SetCameraDialogMode(CharacterFromID("Natali Remis"));
			LAi_ActorTurnToCharacter(CharacterFromID("Natali Remis"), CharacterFromID("Ortodokse Malkin"));
			dialog.text = "Natali Remis : Dix, vraiment ? Et qui dormait devant ma porte le mois dernier en pleurnichant pour que je le laisse entrer ?";
			link.l1 = "...(écouter)...";
			link.l1.go = "3";
		break;

		case "3":
			SetCameraDialogMode(NPChar);
			dialog.text = "Tais-toi.";
			link.l1 = "...(écouter)...";
			link.l1.go = "4";
		break;

		case "4":
			SetCameraDialogMode(CharacterFromID("Natali Remis"));
			dialog.text = "Natali Remis : Je ne me tairai pas. Tu ne me laisseras pas partir d'ici, n'est-ce pas ? Ni sur un navire, ni à l'église, nulle part.";
			link.l1 = "...(écouter)...";
			link.l1.go = "5";
		break;

		case "5":
			SetCameraDialogMode(NPChar);
			dialog.text = "Tu es à moi. Je t'ai payée, et plus d'une fois.";
			link.l1 = "...(écouter)...";
			link.l1.go = "6";
		break;

		case "6":
			SetCameraDialogMode(CharacterFromID("Natali Remis"));
			dialog.text = "Natali Remis : Payée, qu'il dit. Paie ton vin. Moi, ça ne marche plus.";
			link.l1 = "...(écouter)...";
			link.l1.go = "7";
		break;

		case "7":
			SetCameraDialogMode(NPChar);
			dialog.text = "...(doucement)... Bien. Tu viens avec moi maintenant. Sur tes deux jambes.";
			link.l1 = "וcarte-toi d'elle.";
			link.l1.go = "8";
		break;

		case "8":
			SetCameraDialogMode(NPChar);
			dialog.text = "...(il se retourne)... Et qui es-tu pour me donner des ordres ? Passe ton chemin tant que tu le peux encore.";
			link.l1 = "Je ne passerai pas mon chemin.";
			link.l1.go = "9";
			link.l2 = "Je suis venu pour elle. Elle part pour San Juan.";
			link.l2.go = "9";
		break;

		case "9":
			SetCameraDialogMode(NPChar);
			dialog.text = "Alors je vous enterrerai tous les deux.";
			link.l1 = "...(dégainer votre arme)...";
			link.l1.go = "10";
		break;

		case "10":
			locCameraFollow();
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersRemisFightWithMalkin");
		break;

		// After the fight
		case "11":
			dialog.text = "...(après un instant)... Merci. Je croyais qu'il finirait par m'emmener avec lui.";
			link.l1 = "Il n'emmènera plus personne nulle part.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Il a trois des siens sur le brick. Ils savent tout sur moi. Dès qu'ils descendront à terre, ça recommencera.";
			link.l1 = "Alors ils ne descendront pas à terre.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "...(vous regarde, peu convaincue)... Vous aborderiez le navire d'un inconnu pour moi ? Pourquoi ?";
			link.l1 = "J'ai besoin de quatre femmes pour San Juan. Vous êtes la quatrième.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "C'est donc ça. Et moi qui m'imaginais Dieu sait quoi. ...(avec un sourire en coin)... San Juan fera l'affaire. Rien ne me retient ici, de toute façon.";
			link.l1 = "Alors préparez-vous.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Je vais le faire. Mais le brick d'abord, sinon je n'arriverai même pas jusqu'au quai.";
			link.l1 = "Quel genre d'hommes sont-ils ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Trois. Malkin les a tirés d'une chaîne de forçats, et depuis, ils se feraient pendre pour lui. Forts comme des bœufs, et à peu près aussi malins.";
			link.l1 = "Oם est le brick ?";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Tout droit après le mכle, la chaloupe est près des rochers. L'un est dans la cabine, un autre au carré, le troisième dans la cale : ils ne vont jamais ensemble, même à terre.";
			link.l1 = "Attendez-moi ici.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersRemisToShip");
		break;

		// Malkin's men aboard the brig
		case "22":
			dialog.text = "...(se levant)... Tu n'es pas des nכtres. Les nכtres frappent.";
			link.l1 = "Ton maître est mort.";
			link.l1.go = "25";
		break;

		case "23":
			dialog.text = "Tu as entendu le bruit en bas ? Moi aussi. ...(il saisit son couteau)...";
			link.l1 = "En bas, c'était plus calme.";
			link.l1.go = "25";
		break;

		case "24":
			dialog.text = "...(plissant les yeux dans l'obscurité)... Déjà deux, alors. Je suis le troisième et le dernier, il n'y a personne après moi.";
			link.l1 = "Le dernier, donc.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "exit";
			if (NPChar.id == "Malkin Sailor 1")
			{
				AddDialogExitQuestFunction("TwoSistersRemisFightWithFirstSailor");
			}
			if (NPChar.id == "Malkin Sailor 2")
			{
				AddDialogExitQuestFunction("TwoSistersRemisFightWithSecondSailor");
			}
			if (NPChar.id == "Malkin Sailor 3")
			{
				AddDialogExitQuestFunction("TwoSistersRemisFightWithThirdSailor");
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
