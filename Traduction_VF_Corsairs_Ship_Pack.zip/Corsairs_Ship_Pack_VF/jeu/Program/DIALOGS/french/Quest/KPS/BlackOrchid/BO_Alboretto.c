// Gregg: Эмилио Альборетто - «Чёрная Орхидея», глава 6 «Испанская щедрость» (перенос из К:ПС).
// Логика - Program\Quests\reaction_functions\blackorchid.c
// Оригинал - DamnedDestiny\SpanishGenerosity\Emilio Alboretto.c.
//   1-6   - таверна Сантьяго, первый торг, ГГ отказывается продавать;
//   20-25 - второй заход: цена названа - Сан-Хуан и двадцать пять миллионов;
//   30-34 - палуба «Андромеды» после отбитой засады;
//   40-44 - ратуша Сантьяго: колония очищена, задаток на руки.
//
// Gregg: ОТСТУПЛЕНИЯ. Лестница торга оригинала (5 -> 10 -> ГГ просит 200 -> 25) сжата:
// двести миллионов и «да вы охренели что ли» из оригинала выброшены, торг идёт короче
// и суше. Двадцать пять миллионов остаются в реплике, но платят из них только задаток -
// см. BO_SG_DEPOSIT в логике. Модель - PGG_Espinosa_0 (решение пользователя).

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sLastName = PChar.lastname;


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Tout ce dont nous sommes convenus tient toujours, capitaine. Je n'ai rien à ajouter.";
			link.l1 = "Moi non plus.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(il se lève pour vous accueillir)... Capitaine " + sLastName + ". Emilio Alboretto, à votre service. Asseyez-vous, je vous en prie. Mon affaire est brève, mais ce n'est pas le genre d'affaire qu'on traite debout.";
			link.l1 = "Pour le compte de qui êtes-vous ici, señor Alboretto ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "De la Couronne espagnole. Ne jouons pas à cache-cache, capitaine : nous savons que l'Orchidée noire est à vous. La Couronne souhaite l'acheter.";
			link.l1 = "Et si je vous dis que je ne vois pas de quoi vous parlez ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Alors je vous demanderai pardon et je partirai. Mais vous ne le direz pas, sinon vous ne vous seriez pas assis à cette table.";
			link.l1 = "...(avec un sourire en coin)... Admettons. Combien ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Cinq millions de piastres. En or, là oם il vous plaira.";
			link.l1 = "Cinq millions. Pour la chose que la moitié des Caraïbes traque depuis six mois.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(sans la moindre pause)... Dix. Et ce n'est pas mon dernier mot, capitaine, c'est mon deuxième.";
			link.l1 = "Señor Alboretto, je vois qu'on vous a ordonné de rapporter l'Orchidée à n'importe quel prix. Ce qui rend cette conversation inutile.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Fixez le prix vous-même. N'importe quel prix.";
			link.l1 = "Pas aujourd'hui. L'Orchidée n'est pas à vendre. Bonne journée, señor.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityExitFromTavern");
		break;

		case "20":
			dialog.text = "...(il se lève lentement)... Capitaine. J'avoue que je ne m'attendais pas à vous voir.";
			link.l1 = "J'ai changé d'avis, señor Alboretto. L'Orchidée est à vendre.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "...(il se rassoit)... Je vous écoute avec la plus grande attention.";
			link.l1 = "Vingt-cinq millions de piastres. Et la colonie de San Juan, en ma possession personnelle.";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "...(un long silence)... L'argent est une question qui peut se régler. Mais une colonie, capitaine ? Vous demandez à la Couronne un morceau de la Couronne.";
			link.l1 = "Je demande une chose dont le monde ne possède qu'un exemplaire. Je ne marchanderai pas : il n'y a qu'un prix, et il est entier.";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Vous comprenez que San Juan ne doit pas seulement être cédée, mais évacuée ? La garnison, les fonctionnaires, la flotte : tout.";
			link.l1 = "Je comprends. Et d'ici là, vous n'aurez pas la pierre.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "...(il se frotte l'arête du nez)... J'ai écrit à Séville avant même notre première conversation, capitaine : je savais comment finirait le marchandage. La réponse m'attendra à bord de l'Andromeda, au large de Santa Catalina. Venez-y, et vous l'entendrez le premier.";
			link.l1 = "Et pourquoi pas ici, à cette table ?";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Parce que, capitaine, je ne suis pas le seul dans cette taverne à connaître votre Orchidée. En mer, c'est plus tranquille. Du moins, il me semble.";
			link.l1 = "Au large de Santa Catalina, donc. J'y serai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityAlborettoInShore");
		break;

		case "30":
			dialog.text = "...(haletant, appuyé au bastingage)... Je vous dois la vie, capitaine. Un quart d'heure de plus, et l'Andromeda aurait été réduite en planches.";
			link.l1 = "Ce n'étaient pas des Espagnols, señor.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Non. C'étaient des hommes qui veulent l'Orchidée autant que la Couronne, et qui n'avaient aucune intention de payer. Je vous avais bien dit que je n'étais pas le seul à savoir.";
			link.l1 = "Avez-vous apporté la réponse de Séville ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Oui. La Couronne accepte. San Juan et vingt-cinq millions : à vos conditions, intégralement.";
			link.l1 = "Je ne pensais pas qu'ils accepteraient si facilement.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "...(il détourne les yeux)... Ils n'acceptent facilement, capitaine, que ce qu'ils comptent bien récupérer. Ne m'en demandez pas plus ; j'en ai déjà trop dit. L'évacuation de la ville prendra trois semaines.";
			link.l1 = "Oם nous retrouvons-nous ?";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "א l'hכtel de ville de Santiago, dans trois semaines. D'ici là, il ne restera plus un seul de nos soldats à Porto Rico.";
			link.l1 = "Dans trois semaines, señor Alboretto.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityPreSecondTimer");
		break;

		case "40":
			dialog.text = "San Juan est vide, capitaine. La garnison, les fonctionnaires, les deux navires de garde : tous sont partis hier avec la marée du matin. La ville est à vous.";
			link.l1 = "Vous avez fait vite. Et l'argent ?";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "L'acompte, un million, ici même, par billet. Les vingt-quatre restants vous seront versés par virement, par l'intermédiaire d'une maison de banque de Séville : de telles sommes ne sont pas conservées dans un trésor colonial, et ne l'ont jamais été.";
			link.l1 = "Un virement. Autrement dit, du papier.";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "Du papier de la Couronne espagnole, capitaine. Il vaut plus que l'or, sinon l'Europe ferait la guerre depuis longtemps avec des charrettes de pièces.";
			link.l1 = "...(ramassant le billet)... Très bien. Et la pierre ?";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Laissez-la dans une cache à terre et envoyez-moi l'emplacement. Je n'y toucherai pas avant que le dernier de nos soldats n'ait mis pied à terre à La Havane. Parole d'Alboretto.";
			link.l1 = "Vous aurez l'emplacement. Bonne journée, señor.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityDealDone");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
