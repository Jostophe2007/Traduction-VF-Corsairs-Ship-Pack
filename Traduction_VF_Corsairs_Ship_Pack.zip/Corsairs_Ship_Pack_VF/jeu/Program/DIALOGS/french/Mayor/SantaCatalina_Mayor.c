// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;

        //********************** Фр.линейка. Квест №11. Захват Санта Каталины ************************
		case "FraLine11Quest_OccupySC":
            dialog.text = "C'est la deuxième attaque ces derniers temps ! Les Français risquent fort de s'attirer pleinement le courroux de l'Escurial.";
			link.l1 = "Hé, voyez-vous ça ! Que la reine mère se fâche, nous sommes en guerre, mon ami.";
            link.l1.go = "Step_F11_1";
			AfterTownBattle();
        break;
		case "Step_F11_1":
            dialog.text = "Et que comptez-vous faire ensuite ?";
			link.l1 = "J'ai l'intention de vous destituer, de faire prêter serment aux habitants envers Louis XIV et de confier l'administration de la ville aux autorités françaises. Vous y voyez un inconvénient ?";
			link.l1.go = "Step_F11_2";
        break;
		case "Step_F11_2":
            dialog.text = "Eh bien, vous ironisez, "+ GetSexPhrase("señor", "señorita") +" ?";
			link.l1 = "...";
			link.l1.go = "exit";
			pchar.questTemp.State = "Fr11OccupySC_toWeWon";
            AddQuestRecord("Fra_Line_11_OccupySantaCatalina", "2");
            NextDiag.TempNode = "Cupture_after";
			PChar.questTemp.DontSetNewDialogToMayor = true; // иначе может сменить диалог и сбойнуть
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(NPChar.City, sti(PChar.nation));
            DeleteAttribute(PChar, "questTemp.DontSetNewDialogToMayor");
            UpdateRelations();
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
            SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
            AddDialogExitQuestFunction("LaunchColonyInfoScreen"); // табличка
        break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

