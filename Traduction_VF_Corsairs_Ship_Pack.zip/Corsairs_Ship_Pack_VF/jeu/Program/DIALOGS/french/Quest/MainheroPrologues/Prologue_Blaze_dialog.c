void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	ref _location;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			pchar.quest.SharpAfterTreasure.win_condition.l1          = "location";
			pchar.quest.SharpAfterTreasure.win_condition.l1.location = "Shore57";
			pchar.quest.SharpAfterTreasure.function                  = "SharpAfterTreasure";
			dialog.text = "Alors c'est toi, le voleur qui m'a pris ma carte.";
			link.l1 = "Quoi... !? De quoi parles-tu ? C'est la première fois que je te vois, comment aurais-je pu te voler quoi que ce soit ?";
			link.l1.go = "2";

			NextDiag.TempNode = "First time";
		break;

		case "2":
			dialog.text = "Bien sמr. Elle traînait sur la route, et tu l'as ramassée. Et l'autre moitié aussi, à en juger par ta présence ici. C'est ça, je te crois.";
			link.l1 = "וcoute, je n'ai aucune idée de la raison pour laquelle tu crois que j'ai volé ta carte, mais tu te trompes. D'ailleurs, comment as-tu trouvé cet endroit, toi ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je te suis, tout simplement, depuis que j'ai appris que tu m'avais volé.";
			link.l1 = "Comment as-tu su que j'avais volé la carte ? Simple curiosité.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Assez ! Je comptais t'étriper, pas bavarder, et c'est ce que je vais faire !";
			link.l1 = "Bon sang...";
			link.l1.go = "Exit_fight";
		break;

//grotto - dialog 2

		case "5":
			LAi_SetCurHPMax(npchar);
			LAi_SetPlayerType(PChar);
			dialog.text = "Tu es une sacrée petite diablesse. Pourquoi t'es-tu arrêtée ? Finissons-en !";
			link.l1 = "Si je voulais te tuer, je l'aurais déjà fait. Ce que je veux vraiment savoir, c'est pourquoi tu as cru que j'avais volé ta carte. Et qu'est-ce qui te fait croire qu'elle est à toi, d'abord ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "D'accord, je vais répondre. Il n'y a pas longtemps, j'ai rencontré un homme étrange qui m'a donné la moitié de cette maudite carte, en m'expliquant qu'il l'avait promis à mon père. Un matin, peu après, quelqu'un m'a volé ma carte pendant que je luttais contre une gueule de bois dans une taverne minable. J'ai interrogé les gens du coin de façon très musclée, et j'ai fini par trouver un homme qui m'a dit t'avoir vue parler à l'aubergiste en agitant quelque chose qui ressemblait fort à un morceau de carte. J'ai cru que tu m'avais volé ma carte, et que tu cherchais maintenant l'autre moitié. Alors j'ai décidé de te laisser la trouver et de voir oם elle te mènerait.";
			link.l1 = "Astucieux. Mais tu fais erreur sur un point : même si je cherchais vraiment l'autre moitié de la carte, c'était, si je comprends bien, ta moitié à toi. J'avais déjà reçu la mienne à ce moment-là, et de la même façon que toi. En fait, j'ai acheté ta moitié à cet aubergiste, pour une somme complètement folle, d'ailleurs. Rappelle-moi de le remercier du fond du cœur d'avoir vendu de la marchandise volée sans le moindre rabais.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Mais si c'est vrai, alors ça veut dire que tu es...";
			link.l1 = "Elle-même. א ton service, cher frère. Dommage que nous nous soyons rencontrés à cause d'une coïncidence aussi stupide, mais je suis contente de te voir quand même.";
			link.l1.go = "8";
			link.l2 = "Ta sœur. J'ai bien peur de devoir te tuer maintenant : je n'ai aucune envie de partager mes trésors avec qui que ce soit d'autre que moi, et encore moi. Il est temps de mettre fin à nos retrouvailles familiales.";
			link.l2.go = "Exit kill";
		break;

		case "8":
			dialog.text = "Hum... En fait, quand on y pense, rien de tout ça ne ressemble à une coïncidence. Je pense que c'est exactement ce que notre père avait prévu : que nous devions nous trouver l'un l'autre pour arriver ici. Il n'avait sans doute pas prévu le vol ni la bagarre, mais pour le reste, tout concorde. Surtout le fait qu'il ait laissé à chacun de nous la moitié d'une carte avec le nom de l'autre dessus.";
			link.l1 = "Oui, on dirait que tu as raison. Je me demande s'il voulait que nous fassions quelque chose de particulier avec tout cet or. Il est peu probable qu'il nous l'ait simplement laissé pour le dilapider, même si c'est aussi possible...";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Je ne sais pas, peut-être qu'il voulait... Mais je sais pourquoi lui-même a amassé cette fortune. Tu vois, l'homme qui m'a donné ma moitié de carte m'a aussi remis le journal de notre père. Il semble que notre père avait un rêve : créer un nouvel וtat dans les Caraïbes, libéré des petites guerres et des gouverneurs cupides de l'Ancien Monde, capable de bâtir un avenir meilleur pour ses citoyens. Il l'appelait Libertania. Cet argent était destiné à sa création.";
			link.l1 = "Libertania, tu dis... Un beau rêve. Je me demande s'il s'est approché de sa réalisation ? א part réunir un sacré tas d'argent, bien sמr.";
			link.l1.go = "10";
			link.l2 = "Cet argent, comme tout l'argent de ce monde, est destiné à ma bourse. Quiconque pense autrement s'écarte de mon chemin ou meurt. Comme il est peu probable que tu t'écartes, je vais devoir te tuer.";
			link.l2.go = "Exit kill";
		break;

		case "10":
			dialog.text = "Il ne s'en est pas seulement approché, il y est presque parvenu, mais ses ennemis ont fait en sorte qu'on l'oublie. Il y a 20 ans, il a rassemblé une puissante flotte pour s'emparer des colonies, mais un de ses hommes a livré tous ses plans à l'ennemi.\nLa flotte de notre père a été interceptée par les forces réunies de l'Angleterre, de la France et de la Hollande, et détruite au terme de durs combats. Notre père est mort dans cette bataille, et les puissances coloniales se sont donné beaucoup de mal pour le faire passer pour un simple pirate justement puni. Mais il semble qu'il l'avait prévu, et il a fait en sorte que toi et moi grandissions en sécurité, loin l'un de l'autre, et que nous héritions de son trésor et de ses rêves une fois adultes et ses affaires bien oubliées.";
			link.l1 = "Oui, ces canailles ont fait du bon travail. Toute ma vie, j'ai cru que mon père n'était qu'un pirate célèbre... Attends, tu as dit « hériter de ses rêves » : tu crois qu'il voulait que nous...";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Bien sמr ! Il s'est donné tant de mal pour que nous nous rencontrions ici et trouvions ses trésors et son journal : il voulait sמrement que nous achevions ce qu'il a commencé, que nous réalisions son rêve. Et ce rêve en vaut la peine ! Je ne sais pas si j'en suis capable, je ne sais même pas si c'est possible, mais je vais sacrément essayer ! Et toi ?";
			link.l1 = "Libertania... דa sonne bien, même si c'est une folie impossible. Je suis avec toi, frérot ! On se retrouve en mer. Je prends juste ma moitié du trésor.";
			link.l1.go = "Exit grotto continue";
			link.l2 = "Tu n'espères tout de même pas sérieusement chasser de l'archipel les autorités coloniales, avec tout leur argent, leurs navires et leur influence ? Non, je ne veux prendre aucune part à cette folie. Dilapide ta moitié du trésor comme bon te semble, je prends la mienne.";
			link.l2.go = "Exit half";
			link.l3 = "J'aurais dמ te tuer tout de suite, je n'aurais pas eu à écouter ces bêtises. Il est temps de réparer cette erreur !";
			link.l3.go = "Exit kill";
		break;

//grotto - dialog 3

		case "12":
			dialog.text = "Tu sais, c'est agréable de découvrir soudain qu'on a une famille...";
			link.l1 = "Oui... écoute, comment crée-t-on de nouveaux pays, en général ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Honnêtement, je n'en ai aucune idée... Mais je connais quelqu'un qui s'y connaît. Dans son journal, notre père mentionne souvent un certain Robert Staffordshire : il semble avoir été son principal conseiller pour les affaires d'וtat. J'ai pris des renseignements sur lui : il est toujours en bonne santé, et vit à Isla Mona. Je ne sais pas s'il nous aidera, mais c'est notre meilleure chance. Je pense que nous devrions le rencontrer.";
			link.l1 = "D'accord. S'il a aidé notre père, il nous aidera peut-être aussi.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Alors je pars devant pour organiser une rencontre. Nous t'attendrons à la taverne d'Isla Mona.";
			link.l1 = "D'accord.";
			link.l1.go = "Exit grotto end";
		break;

//after advisor quest done

		case "16":
			dialog.text = "Il a raison, tu sais mieux t'y prendre que moi avec les capitaines. Moi, je m'entendrai à merveille avec les marchands et les usuriers, j'ai souvent eu affaire à eux.";
			link.l1 = "D'accord, je fais confiance à ton expérience.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Alors je commence à préparer le départ tout de suite. Nous avons encore beaucoup à faire. Je reviendrai dans deux semaines, mais il peut y avoir des retards.";
			link.l1 = "Prends soin de toi. Je détesterais vraiment te perdre.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Comme c'est gentil, Beatrice. Je ne pensais pas que ça comptait tant pour toi...";
			link.l1 = "דa compte, et plus que tu ne le crois. Bonne chance.";
			link.l1.go = "Exit";
		break;

//boss killed rant

		case "19":
			dialog.text = "C'est moi qui commande ici, désormais. Des objections ?";
			link.l1 = "...";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "...Non ? C'est bien ce que je pensais. Maintenant, écoutez bien, et répétez-le aux autres. Je convoque un conseil des capitaines libres ici, dans ma nouvelle résidence, dans deux semaines. Je garde la raison pour moi pour l'instant, mais croyez-moi, c'est vraiment important.";
			link.l1 = "...";
			link.l1.go = "Exit";
		break;

//at pirate meeting - autodialog 2

		case "21":
			dialog.text = "Vous êtes là, parfait. Je ne suis pas une grande oratrice, et je ne vais pas vous torturer avec de longs discours.\nComme vous le savez sans doute, mon père, Nicholas Sharp, a tenté il y a 20 ans de créer Libertania sur ces îles : un nouvel וtat, libre. Libre des exploiteurs cupides de l'Ancien Monde, libre de leurs petites guerres, dont le seul but est d'apporter à un roi un peu de gloire et d'or. Comme vous le savez peut-être aussi, mon père a été vaincu : un de ses compagnons l'a trahi, et sa flotte a été détruite. Mais ce que vous ignorez sans doute, c'est à quel point il était près de réussir. Je suis tout aussi près de réaliser son rêve, et j'ai pris toutes les précautions pour ne pas répéter ses erreurs, mais je ne peux pas y arriver seule.\nJ'ai besoin de vous, hommes libres, avec vos navires, pour combattre ceux qui osent vous commander, vous imposer leurs lois et leurs guerres. Je ne vous demande pas de mourir sous le feu de leurs forts : non, ce que j'attends de vous est bien moins dangereux, mais tout aussi important pour la victoire. J'ai besoin que vous perturbiez leur commerce, que vous couliez leurs convois, que vous attaquiez leurs patrouilles. J'ai besoin que vous deveniez les corsaires de la liberté.\nJe vous demande beaucoup, mais la récompense, la liberté que vous pouvez obtenir, n'a vraiment pas de prix. Alors je vous le demande : suivez-moi dans le beau monde nouveau que nous allons créer !";
			link.l1 = "...";
			link.l1.go = "Exit";
		break;

//at pirate meeting

		case "22":
			dialog.text = "Vous doutez de Beatrice, de la réalité de ses rêves. Je vous le dis : s'il y a quelqu'un dans cette salle capable de réaliser des rêves, c'est elle. Vous hésitez. Je vous comprends : de telles décisions ne sont pas faciles à prendre. Mais pensez à ceci : la chance de changer le monde est sacrément rare. Très peu de gens l'obtiennent un jour, et personne ne l'obtient deux fois. Tout ça, ici et maintenant, c'est notre chance. Ce que vous en ferez ne dépend que de vous. Mais je sais une chose : je ne laisserai pas passer ma chance, même pour tout l'or du monde ! J'ai fait mon choix, maintenant, c'est à vous !";
			link.l1 = "...";
			link.l1.go = "Exit";
		break;

//at pirate meeting - autodialog 2

		case "23":
			dialog.text = "Messieurs, vous ne regretterez pas votre décision. Maintenant, écoutez, nous avons beaucoup à discuter...";
			link.l1 = "...";
			link.l1.go = "23_exit";
		break;

		case "23_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("captains_long_speak");
		break;

		case "24":
			dialog.text = "(Plusieurs heures ont passé) ...Maintenant, vous savez quoi faire, messieurs. Faites-le, et la victoire sera nכtre. Vous pouvez disposer.";
			link.l1 = "...";
			link.l1.go = "Exit";
		break;

//after pirate meeting

		case "25":
			dialog.text = "Eh bien, eh bien, Beatrice. Tu as vraiment réussi ! Félicitations !";
			link.l1 = "Nous avons réussi, Blaze, nous avons réussi. Sans ton magnifique discours, ils ne m'auraient pas suivie.";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Eh bien, si tu insistes. Alors... Que proposes-tu de faire maintenant, chère demi-sœur ?";
			link.l1 = "En fait, j'ai deux ou trois idées intéressantes, si tu n'es pas trop occupée...";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Je serai ravie de discuter de ces idées. En privé...";
			link.l1 = "Ha, c'est ça, monsieur ! Dans ma cabine ou dans la tienne ?";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Quelque chose me dit que cette résidence, qui, d'ailleurs, est désormais la tienne, doit bien avoir au moins une chambre à coucher.";
			link.l1 = "C'est vrai ! Je propose que nous la trouvions immédiatement et que nous l'utilisions selon sa destination !";
			link.l1.go = "Exit";
		break;
//exits

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit_fight":
			NextDiag.CurrentNode = "5";
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_SetCheckMinHP(NPChar, 1, true, "Sharp_Prologue_CheckHP");
			LAi_SetImmortal(NPChar, false);
			DialogExit();
		break;

		case "Exit grotto continue":
			NextDiag.CurrentNode = "hired";
			DialogExit();
			//pchar.questTemp.HiringOfficerIDX = NPChar.index;
			SetCompanionIndex(pchar, -1, sti(NPChar.index));
			Npchar.CanTakeMushket = true;
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.HoldEquip = true;
			sld.HalfImmortal = true;  // Контузия
			LAi_SetImmortal(NPChar, false);
			sld.greeting = "Gr_Officer";
			sld.rank = 5;
			SetSelfSkill(sld, 20, 20, 20, 20, 20);
			SetShipSkill(sld, 20, 20, 20, 25, 20, 20, 20, 20, 20);
			SetSPECIAL(sld, 6, 6, 8, 5, 8, 8, 8);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			sld.quest.meeting = true;
			NPChar.Payment = true;

			_location = &locations[reload_location_index];
			//DeleteAttribute(_location, "box1");
			_location.box1.money = 50000;
			//_location.box1.items.icollection = 1;
			//_location.box1.items.indian1 = 1;
			_location.box1.items.indian7 = 1;
			//_location.box1.items.chest = 1;
			_location.box1.items.jewelry1 = 10+rand(5);
			_location.box1.items.jewelry2 = 10+rand(5);
			_location.box1.items.jewelry3 = 10+rand(5);
			_location.box1.items.jewelry4 = 5+rand(5);
			_location.box1.items.jewelry6 = rand(25);
			_location.box1.items.jewelry7 = rand(50);
			_location.box1.items.jewelry10 = rand(25);
			_location.box1.items.jewelry14 = rand(25);
			_location.box1.items.jewelry15 = rand(5);
			_location.box1.items.jewelry18 = rand(50);
			chrDisableReloadToLocation = false;

			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 8);
		break;

		case "Exit kill":
			LAi_SetWarriorType(NPChar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetPlayerType(PChar);
			LAi_SetImmortal(NPChar, false);
			DialogExit();

			_location = &locations[reload_location_index];
			//DeleteAttribute(_location, "box1");
			_location.box1.money = 150000;
			_location.box1.items.icollection = 1;
			_location.box1.items.indian1 = 1;
			_location.box1.items.indian7 = 1;
			_location.box1.items.chest = 1;
			_location.box1.items.jewelry1 = 20+rand(5);
			_location.box1.items.jewelry2 = 20+rand(5);
			_location.box1.items.jewelry3 = 20+rand(5);
			_location.box1.items.jewelry4 = 11+rand(5);
			_location.box1.items.jewelry6 = rand(50);
			_location.box1.items.jewelry7 = rand(100);
			_location.box1.items.jewelry10 = rand(50);
			_location.box1.items.jewelry14 = rand(50);
			_location.box1.items.jewelry15 = rand(10);
			_location.box1.items.jewelry18 = rand(100);

			pchar.quest.sharpxitFromCave.win_condition.l1 = "NPC_Death";
			pchar.quest.sharpxitFromCave.win_condition.l1.character ="Sharp_Sibling";
			pchar.quest.sharpxitFromCave.function = "sharpxitFromCave";

		break;

		case "Exit half":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			_location = &locations[reload_location_index];
			//DeleteAttribute(_location, "box1");
			_location.box1.money = 70000;
			//_location.box1.items.icollection = 1;
			_location.box1.items.indian1 = 1;
			_location.box1.items.indian7 = 1;
			_location.box1.items.chest = 1;
			_location.box1.items.jewelry1 = 10+rand(5);
			_location.box1.items.jewelry2 = 10+rand(5);
			_location.box1.items.jewelry3 = 10+rand(5);
			_location.box1.items.jewelry4 = 5+rand(5);
			_location.box1.items.jewelry6 = rand(25);
			_location.box1.items.jewelry7 = rand(50);
			_location.box1.items.jewelry10 = rand(25);
			_location.box1.items.jewelry14 = rand(25);
			_location.box1.items.jewelry15 = rand(5);
			_location.box1.items.jewelry18 = rand(50);

			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 8);
			chrDisableReloadToLocation = false;
		break;

		case "Exit grotto end":
			AddDialogExitQuest("Grotto end");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
