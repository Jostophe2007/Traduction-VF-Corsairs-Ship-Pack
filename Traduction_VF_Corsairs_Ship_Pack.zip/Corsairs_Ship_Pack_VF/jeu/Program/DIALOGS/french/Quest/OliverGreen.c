// Секретать Моргана и актёр для сложных диалогов с действиями.
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    sld = characterFromID("Henry Morgan");

	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
            if (sld.location == pchar.location && bWorldAlivePause)
            {
    			dialog.text = "Si tu vas voir l'amiral, avance encore un peu. Il est à la résidence en ce moment.";
    			link.l1 = "D'accord, je vais aller lui parler.";
            }
            else
            {
    			if (pchar.questTemp.piratesLine == "Panama_inEngland" || pchar.questTemp.piratesLine == "Panama_backToShip")
				{
					dialog.text = "L'amiral est parti pour Londres. Il ne sera pas là avant au moins deux mois.";
    				link.l1 = "Je vois...";
				}
				else
				{
					dialog.text = "L'amiral n'est pas là, il est absent pour affaires. Et maintenant, ne m'embête pas, je suis très occupé.";
    				link.l1 = "Si Morgan n'est pas là, je n'ai rien à faire dans cette maison.";
				}
            }
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";

			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Je m'appelle " + GetFullName(npchar) + ". Je suis le secrétaire d'Henry Morgan.";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
				link.l1.go = "First time";
				npchar.quest.meeting = "1";
			}
            //============>>>>>>>>> перехват квестовых диалогов
            if (pchar.questTemp.State == "WormEnglPlans_toMorgan")  // HolLine_3, переадресовка в Антигуа.
            {
    			link.l1 = "וcoute, j'ai besoin de Morgan, et de toute urgence.";
    			link.l1.go = "Step_H3_1";
            }
            if (pchar.questTemp.State == "Fr8ThreeCorsairs_toSeek")  // FraLine_8, переадресовка в Антигуа.
            {
    			link.l1 = "Monsieur, je voudrais parler à Henry Morgan. Oם puis-je le trouver ?";
    			link.l1.go = "Step_F8_1";
            }
            // квест Аскольда. Пасхалка на получение индейских предметов.
            if (pchar.questTemp.Ascold == "SeekThreeObject" && !CheckAttribute(pchar, "questTemp.Ascold.Oliver"))
            {
    			link.l2 = "וcoute, c'est toi qui gères les affaires de Morgan. Tu n'aurais pas croisé des objets indiens dans les registres des prises ?";
    			link.l2.go = "Step_As_1";
            }
            if (pchar.questTemp.Ascold == "SeekThreeObject" && CheckAttribute(pchar, "questTemp.Ascold.Oliver"))
            {
    			link.l2 = "Oliver, tu as peut-être changé d'avis sur le prix de ces objets indiens dont je t'ai parlé ?";
    			link.l2.go = "Step_As_7";
            }
            if (pchar.questTemp.Azzy == "DestrContract" || pchar.questTemp.Azzy == "2DestrContract")
            {
                if (!CheckAttribute(pchar, "questTemp.Azzy.Oliver"))
                {
        			link.l2 = "Oliver, écoute, je voudrais te demander de l'aide. J'ai vraiment besoin de babioles indiennes. Il s'agit de trois crânes de cristal toltèques et d'un objet étrange qui ressemble à un hochet.";
        			link.l2.go = "Step_As_9";
        		}
            }
            //============>>>>>>>>> перехват квестовых диалогов
        break;

        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;
		//********************* Голландская линейка *********************
        case "Step_H3_1":
            dialog.text = "Qui es-tu, et pourquoi as-tu besoin d'Henry ?";
            link.l1 = "Je m'appelle " + GetFullName(pchar) + ". C'est Edward Mansfield qui m'envoie auprès de Morgan.";
            link.l1.go = "Step_H3_2";
        break;
        case "Step_H3_2":
            dialog.text = "De Hollande ?.. Tu viens de Hollande ?";
            link.l1 = "Qu'est-ce que ça peut te faire, de quelle nation je suis ? J'ai affaire à Morgan de la part de Mansfield, qu'est-ce que tu ne comprends pas ?";
            link.l1.go = "Step_H3_3";
        break;
        case "Step_H3_3":
            dialog.text = "Ne t'énerve pas, "+ GetSexPhrase("mynheer", "madame") +", tout va bien. Il y a beaucoup de Hollandais parmi les pirates, mais il n'est pas prudent pour toi de rester à Port Royal en ce moment\n"+
                          "Alors, je vais te dire une chose : Morgan est à Antigua, chez lui. Fais attention là-bas aussi : si moi, j'ai deviné que tu venais de Hollande, ce ne sera pas un secret pour les autres non plus\n"+
                          "Et puis, ce n'est pas si facile d'entrer chez Morgan, la porte ne s'ouvre que pour sortir, héhé... Cherche le souterrain sous St. John's, il te mènera jusqu'à Henry...";
            link.l1 = "Merci, Oliver.";
            link.l1.go = "exit";
            pchar.questTemp.State = "WormEnglPlans_toMorganAntigua";
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "3");
			AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex", GetSexPhrase("", "e"));
        break;
		//********************* Французская линейка *********************
 	 	case "Step_F8_1":
			dialog.text = NPCStringReactionRepeat("Qui êtes-vous"+ GetSexPhrase(", monsieur ", ", mademoiselle ") +" ?", "Je vous ai déjà répondu...",
				          "Je le répète, j'ai déjà répondu à cette question.", "Vous ne devriez pas me déranger, je n'en dirai pas plus.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je m'appelle " + GetFullName(pchar) + ". J'agis au nom du gouvernement français.", "Oui, c'est vrai...", "Oui, je m'en souviens...", "D'accord.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_F8_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
        case "Step_F8_2":
            dialog.text = "Et pour quelle affaire le gouvernement français a-t-il besoin d'Henry Morgan ?";
            link.l1 = "וcoute, mon brave, tu ne trouves pas que tu es trop bavard pour un secrétaire ?";
            link.l1.go = "Step_F8_3";
        break;
        case "Step_F8_3":
            dialog.text = "D'accord, d'accord, "+ GetSexPhrase("monsieur", "mademoiselle") +"... Morgan est en ce moment chez lui, à Antigua.";
            link.l1 = "Eh bien, c'est parfait. J'y vais immédiatement !";
            link.l1.go = "Step_F8_4";
        break;
        case "Step_F8_4":
            dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", gardez à l'esprit qu'il n'est pas si facile d'entrer dans la maison de Morgan à St. John's, la porte y est toujours fermée. On y entre par le souterrain...";
            link.l1 = "On verra bien...";
            link.l1.go = "exit";
        break;
		//********************* Квест Асокльда *********************
   		case "Step_As_1":
			dialog.text = "Qu'est-ce que c'est que ces questions bizarres ?! J'en ai peut-être vu, mais pourquoi devrais-je te le dire ?";
			link.l1 = "Ne t'énerve pas. Le fait est que je cherche trois objets du culte indien. Pour les acheter. De toute façon, ces trucs, vous les jetez ou vous les vendez pour trois fois rien. Je paierai grassement ces objets, si tu les as.";
			link.l1.go = "Step_As_2";
		break;
   		case "Step_As_2":
			dialog.text = "Quel genre d'objets ?";
			link.l1 = "Une statuette indienne de Tlaloc, un vase de cérémonie et un couteau de cérémonie.";
			link.l1.go = "Step_As_3";
		break;
   		case "Step_As_3":
			dialog.text = "Héhé, tous ces objets sont en métaux précieux. Nous les fondons en lingots et les envoyons aux joailliers d'Europe pour qu'ils les travaillent. La demande est forte, tu sais, et les prix sont bons...";
			link.l1 = "Je comprends. Je veux bien payer le double du prix pour ces babioles indiennes, seulement non fondues, pour ainsi dire... Tu as vraiment ces objets ? Ou est-ce qu'on a une conversation idiote ?";
			link.l1.go = "Step_As_4";
		break;
   		case "Step_As_4":
			dialog.text = "J'ai ces objets. Et en principe, je serais prêt à te les vendre. Mais le double du prix, ce n'est pas un sujet de conversation sérieux. C'est trop peu.";
			link.l1 = "Combien voulez-vous ?";
			link.l1.go = "Step_As_5";
		break;
   		case "Step_As_5":
			dialog.text = "Un million.";
			link.l1 = "Quoi ?!!! Tu es fou ?!";
			link.l1.go = "Step_As_6";
		break;
   		case "Step_As_6":
			dialog.text = "Pas du tout. Tu crois que pour un malheureux double prix, dans les trois mille, je vais soustraire quelque chose aux prises de Morgan ? Tu as perdu la tête, "+ GetSexPhrase("mon ami", "ma belle") +", si tu ne sais pas comment ça pourrait finir pour moi. Si ça ne te plaît pas, va dans les boutiques et essaie d'acheter là-bas.";
			link.l1 = "Bon sang, Oliver !";
			link.l1.go = "Step_As_7";
			pchar.questTemp.Ascold.Oliver = 1;
		break;
   		case "Step_As_7":
			dialog.text = "Bon, assez parlé. Tu prends ou pas ?";
			link.l1 = RandPhraseSimple("Pas question ! Pour une somme pareille, je m'achète tout Port Royal !", "Un million ? Oh, allons ! Non, bien sמr que non.");
			link.l1.go = "exit";
            if (sti(pchar.money) >= 1000000)
            {
    			link.l2 = "Oh, je prends ! Et emballe-les-moi dans un paquet cadeau !";
    			link.l2.go = "Step_As_8";
            }
            else
            {
    			link.l2 = "Je prendrais bien, mais je n'ai pas une telle somme. Je vais y aller, je gagnerai peut-être plus...";
    			link.l2.go = "exit";
            }
		break;
   		case "Step_As_8":
			dialog.text = GetFullName(pchar) + ", c'est un plaisir de faire affaire avec toi. Prends tes inestimables artefacts ! J'espère qu'ils te porteront chance, puisque tu acceptes de payer une telle somme pour eux...";
			link.l1 = "Je l'espère aussi, Oliver.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -1000000);
			DeleteAttribute(pchar, "questTemp.Ascold.Oliver");
			pchar.questTemp.Ascold = "SoughtThreeObject";
    		GiveItem2Character(pchar, "indian19");
    		GiveItem2Character(pchar, "indian20");
    		GiveItem2Character(pchar, "indian21");
		break;
   		case "Step_As_9":
			dialog.text = "J'ai ces objets. Cinq millions, et ils sont à toi.";
			link.l1 = RandPhraseSimple("Cinq millions ?!!", "Cinq millions... Une jolie somme !");
			link.l1.go = "exit";
            if (sti(pchar.money) >= 5000000)
            {
    			link.l2 = "On dirait que je n'ai pas le choix. Il faut les prendre. Prends l'argent et donne-moi les objets au plus vite !";
    			link.l2.go = "Step_As_10";
            }
            else
            {
    			link.l2 = "J'en ai vraiment besoin, mais je n'ai pas assez d'argent...";
    			link.l2.go = "exit";
            }
		break;
   		case "Step_As_10":
			dialog.text = GetFullName(pchar) + ", c'est un plaisir de faire affaire avec toi. Prends tes inestimables artefacts !";
			link.l1 = "Merci, Oliver ! Tu m'as littéralement sauvé la vie...";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -5000000);
    		GiveItem2Character(pchar, "sculMa1");
    		GiveItem2Character(pchar, "sculMa2");
    		GiveItem2Character(pchar, "sculMa3");
    		GiveItem2Character(pchar, "indian22");
    		pchar.questTemp.Azzy.Oliver = 1;
		break;

		case "PL_Q8_over":
			dialog.text = "Mes salutations, capitaine " + GetFullName(pchar) + ".";
			link.l1 = "וcoute, Oliver, j'ai besoin de Morgan !";
			link.l1.go = "PL_Q8_over_1";
		break;
		case "PL_Q8_over_1":
			dialog.text = "Mais il n'est pas là, il est parti pour Panama sans toi. Et on m'a chargé de te dire que tu pouvais aller bronzer sur les plages.";
			link.l1 = "Quoi ?!";
			link.l1.go = "PL_Q8_over_2";
		break;
		case "PL_Q8_over_2":
			dialog.text = "Voilà ! Je te le traduis exprès pour toi : tu n'as pas respecté le délai, et maintenant, on n'a plus besoin de toi. Désolé...";
			link.l1 = "Diable !!! Allez, c'est ta faute...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;
	}
}


