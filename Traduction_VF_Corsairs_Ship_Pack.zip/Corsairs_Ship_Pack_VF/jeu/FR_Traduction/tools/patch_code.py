# -*- coding: utf-8 -*-
"""Adds a french branch to the script helpers that return hard-coded english words
(nation names, nationalities, european towns...).

The english and russian behaviour is untouched: a block
    if (LanguageGetLanguage() == "french") // FR_PATCH
    { switch(...) { case X: return "..."; break; ... } }
is inserted at the top of each function. Running it again replaces the previous block.
An untouched copy of every patched file is kept in FR_Traduction/backup/code/.

usage: python -X utf8 patch_code.py          (apply)
       python -X utf8 patch_code.py --undo   (restore the backups)
"""
import os
import re
import shutil
import sys

from frenc import to_game

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(BASE, '..', '..'))
BACKUP = os.path.abspath(os.path.join(BASE, '..', 'backup', 'code'))

NAT = ('ENGLAND', 'FRANCE', 'SPAIN', 'HOLLAND', 'PIRATE')

# function -> (file, {case: french})
PATCHES = {
    'NationNameNominative': ('Program/Dialog_func.c', dict(zip(NAT, (
        "l'Angleterre", 'la France', "l'Espagne", 'la Hollande', 'les Frères de la Côte')))),
    'NationNameGenitive': ('Program/Dialog_func.c', dict(zip(NAT, (
        "l'Angleterre", 'la France', "l'Espagne", 'la Hollande', 'la Confrérie de la Côte')))),
    'NationNameAblative': ('Program/Dialog_func.c', dict(zip(NAT, (
        "l'Angleterre", 'la France', "l'Espagne", 'la Hollande', 'les pirates')))),
    'NationNamePeople': ('Program/Dialog_func.c', dict(zip(NAT, (
        'les Anglais', 'les Français', 'les Espagnols', 'les Hollandais', 'les pirates')))),
    'NationNamePeopleAcc': ('Program/Dialog_func.c', dict(zip(NAT, (
        'les Anglais', 'les Français', 'les Espagnols', 'les Hollandais', 'les pirates')))),
    'NationNameMan': ('Program/Dialog_func.c', dict(zip(NAT, (
        'Anglais', 'Français', 'Espagnol', 'Hollandais', 'pirate')))),
    'NationEuropaTown': ('Program/Dialog_func.c', dict(zip(NAT, (
        'Londres', 'La Rochelle', 'Séville', 'Amsterdam', 'Tortuga')))),
    'NationNameSK': ('Program/scripts/Siege.c', dict(zip(NAT, (
        'anglaise', 'française', 'espagnole', 'hollandaise', 'pirate')))),
    'NationKingsCrown': ('Program/Dialog_func.c', dict(zip(NAT, (
        "le trône d'Angleterre", 'la Couronne de France', "la Couronne d'Espagne", 'le royaume des Pays-Bas',
        'la Confrérie de la Côte')))),
    'NationKingsName': ('Program/Dialog_func.c', dict(zip(NAT, (
        'Sa Majesté Charles II Stuart', 'Sa Majesté Louis XIV', 'Sa Majesté Catholique Charles II de Habsbourg',
        "Sa Majesté Guillaume III d'Orange", 'la Confrérie de la Côte')))),
}

MARK = '// FR_PATCH'

# file -> [(original text, french-aware text)] : plain in-line replacements.
# Quest log: AddQuestUserData() drops every "...Sex..." placeholder value outside russian, so the
# french feminine endings (@<sSex>, @<sSex1>...) would never show. In french, they get "" / "e".
LINE_PATCHES = {
    'Program/Quests/quests.c': [
        ('\tif(LanguageGetLanguage() != "russian" && findsubstr(strID, "Sex", 0) != -1) return;',
         '\tstring sFrData = strData; ' + MARK + '\r\n'
         '\tif(LanguageGetLanguage() == "french" && findsubstr(strID, "Sex", 0) != -1) sFrData = GetSexPhrase("", "e"); ' + MARK + '\r\n'
         '\telse { if(LanguageGetLanguage() != "russian" && findsubstr(strID, "Sex", 0) != -1) return; } ' + MARK),
        ('\tarCur.UserData = tmpStr + "@<"+strID+">" + strData;',
         '\tarCur.UserData = tmpStr + "@<"+strID+">" + sFrData; ' + MARK),
        # every new record (normal and info pages) gets the three endings, even when the code
        # never sets them (the french text may need an agreement where the russian one does not)
        ('\t\tpchar.QuestInfo.(idQuest).Text.(sTextLbl) = "@"+idReferenceQuest+"@"+GetQuestBookData()+"@"+idText;\r\n'
         '\t\tpchar.QuestInfo.(idQuest).idRef = idReferenceQuest;',
         '\t\tpchar.QuestInfo.(idQuest).Text.(sTextLbl) = "@"+idReferenceQuest+"@"+GetQuestBookData()+"@"+idText;\r\n'
         '\t\tif (LanguageGetLanguage() == "french") pchar.QuestInfo.(idQuest).Text.(sTextLbl).UserData = "@<sSex>" + GetSexPhrase("", "e") + "@<sSex1>" + GetSexPhrase("", "e") + "@<sSex2>" + GetSexPhrase("", "e"); ' + MARK + '\r\n'
         '\t\tpchar.QuestInfo.(idQuest).idRef = idReferenceQuest;'),
        ('\t\telse pchar.QuestInfo.(idQuest).Text.(sTextLbl) = "@"+idReferenceQuest+"@  @"+idText;',
         '\t\telse pchar.QuestInfo.(idQuest).Text.(sTextLbl) = "@"+idReferenceQuest+"@  @"+idText;\r\n'
         '\t\tif (LanguageGetLanguage() == "french") pchar.QuestInfo.(idQuest).Text.(sTextLbl).UserData = "@<sSex>" + GetSexPhrase("", "e") + "@<sSex1>" + GetSexPhrase("", "e") + "@<sSex2>" + GetSexPhrase("", "e"); ' + MARK),
    ],
}

# slave trader quest: places written in english in the non-russian branch (quest log @<sAreal>)
SLAVETRADER_AREAL = {
    'from Caracas': 'de Caracas', 'from Cumana': 'de Cumaná',
    'off the coast of Barbados': 'au large de la Barbade', 'off the coast of Guadeloupe': 'au large de la Guadeloupe',
    'near Santiago': 'près de Santiago', 'near Havana': 'près de La Havane',
    'off the coast of Tortuga': 'au large de Tortuga', 'off the coast of Trinidad': 'au large de la Trinité',
    'off the coast of Nevis': 'au large de Niévès', 'near Santo Domingo': 'près de Santo Domingo',
    'near Port-au-Prince': 'près de Port-au-Prince', 'near Cartagena': 'près de Carthagène',
}
LINE_PATCHES['Program/Quests/reaction_functions/slavetrader.c'] = [
    ('pchar.questTemp.SlavetraderAreal.add = "%s";' % en,
     'pchar.questTemp.SlavetraderAreal.add = "%s"; if (LanguageGetLanguage() == "french") '
     'pchar.questTemp.SlavetraderAreal.add = "%s"; %s' % (en, to_game(fr), MARK))
    for en, fr in SLAVETRADER_AREAL.items()]

# "La Veille" (Dozor): the riddles are written in Program/Addons/Quests.c (english branch for every
# non-russian language). French riddles (ciphers and acrostics redone on the french words) and
# several accepted answers separated by "|", checked by DozorAnswerOk() in INTERFACE/Mekakhrom.c
# (identical to the original == test when there is no "|": english and russian are unchanged).
# The key phrases are the ones the french dialogs make the player say.
DOZOR_FR = r'''// FR_PATCH : a typed answer is right when it is one of the "|"-separated answers of sBase
bool DozorAnswerOk(string sAnswer, string sBase)
{
	string sList = "|" + sBase + "|";
	string sTry = "|" + sAnswer + "|";
	if (findsubstr(sList, sTry, 0) != -1) return true;
	return false;
}

// FR_PATCH : riddles of "La Veille" in french
void DozorSetRiddleQuestionFr(int iType)
{
	string sString = "";
	switch(iType)
	{
		case 1:
			sString = "- Capitaine, le navire des contrebandiers est pris ! On a trouvé un billet bien étrange dans la cabine !";
			sString += newStr() + "- Montrez-le-moi tout de suite !";
			sString += newStr() + "- Le voici, capitaine !";
			sString += newStr() + "16 12 1 7 5";
			sString += newStr() + "4 5";
			sString += newStr() + "6 1 10 1 18 4 15";
			sString += newStr() + "- On dirait le lieu de rendez-vous des contrebandiers, chiffré.";
			sString += newStr() + "- Vous croyez ?";
			sString += newStr() + "- Ça ne peut être que ça !";
			PChar.Dozor.Riddle.Type_1.Question = sString;
			PChar.Dozor.Riddle.Type_1.Answer_1 = "plage de fajardo|la plage de fajardo|plage fajardo|fajardo|fajardo beach";
			PChar.Dozor.Riddle.Type_1.KeyPhrase = "L'Escadre insaisissable est apparue dans les eaux de la mer des Caraïbes.";
		break;

		case 2:
			sString = "Tu connais sans doute la vieille histoire de l'archipel des Caraïbes ? D'ordinaire, ce sont les cartographes qui la racontent. Non ? Alors écoute. Si tu pars vers le nord depuis le centre même de l'archipel, tu verras un monstre féroce, le plus terrible qu'on puisse trouver de par le monde. Si tu terrasses ce monstre et poursuis ta route dans la même direction, tu rencontreras la bête la plus longue qui soit. Une fois ce suppôt de l'enfer vaincu, tourne vers l'est. À l'est, tu verras une bête cuirassée, que les Espagnols et les Français appellent la tortue. Si tu as vaincu ce monstre, ta route mène au nord-est, où tu trouveras le repos et la chaleur.";
			PChar.Dozor.Riddle.Type_2.Question = sString;
			PChar.Dozor.Riddle.Type_2.Answer_1 = "les turques|turques|iles turques|îles turques|les iles turques|les îles turques|turks";
			PChar.Dozor.Riddle.Type_2.Answer_2 = "golfe du sud|le golfe du sud|golfe sud|south gulf";
			PChar.Dozor.Riddle.Type_2.KeyPhrase = "Le brave capitaine cherche l'Escadre insaisissable.";
		break;

		case 3:
			sString = "- Il faut toujours prêter attention au premier navire d'un convoi, capitaine. C'est le plus souvent lui qu'on attaque en premier. C'est compris ?";
			sString += newStr() + "- À vos ordres, amiral ! Le premier navire !";
			sString += newStr() + "- Très bien ! Et maintenant, capitaine, jetez un œil à ce message et essayez de comprendre ce qui y est écrit :";
			sString += newStr() + "...Toujours obéir. Rendez-vous tard, une goélette attend...";
			sString += newStr() + "...Tous armés, venez en renfort, nous embarquons !...";
			sString += newStr() + "- Je n'y comprends rien, amiral. Qu'est-ce que c'est que ce charabia ?";
			sString += newStr() + "- Patience, capitaine, patience. Avec un peu d'application, vous verrez que même le délire cache parfois un sens. Repos, capitaine.";
			PChar.Dozor.Riddle.Type_3.Question = sString;
			PChar.Dozor.Riddle.Type_3.Answer_1 = "tortuga|la tortue|ile de la tortue|île de la tortue";
			PChar.Dozor.Riddle.Type_3.Answer_2 = "taverne|la taverne|tavern";
			PChar.Dozor.Riddle.Type_3.KeyPhrase = "Le brave capitaine est sur la piste de l'Escadre insaisissable.";
		break;

		case 4:
			PChar.Dozor.Riddle.Type_4.Question = "picture";
			PChar.Dozor.Riddle.Type_4.Answer_1 = "willemstad|curacao|curaçao";
			PChar.Dozor.Riddle.Type_4.Answer_2 = "magasin|le magasin|boutique|store";
			PChar.Dozor.Riddle.Type_4.KeyPhrase = "Le brave capitaine a engagé le combat avec l'Escadre insaisissable.";
		break;

		case 5:
			sString = "D'abord, ils sont allés à Port Royal, en Jamaïque, puis ils ont fait irruption à Hispaniola, dans la ville espagnole de Santo Domingo, ensuite ils sont passés à San Juan, à Porto Rico, après quoi ils ont fait irruption dans l'anglaise Charlestown, sur l'île de Niévès. Après Niévès, ils ont visité la colonie anglaise d'Antigua, puis l'avant-dernière île : la Martinique, au repaire pirate du François. Mais ils n'ont pas su résoudre la dernière énigme, vous imaginez ? Ils sont tombés sur une énigme vraiment inaccessible.";
			PChar.Dozor.Riddle.Type_5.Question = sString;
			PChar.Dozor.Riddle.Type_5.Answer_1 = "marie-galante|marie galante|maria galante";
			PChar.Dozor.Riddle.Type_5.Answer_2 = "cap inaccessible|le cap inaccessible|cape inaccessible";
			PChar.Dozor.Riddle.Type_5.KeyPhrase = "Le brave capitaine a engagé le combat avec l'Escadre insaisissable.";
		break;

		case 6:
			PChar.Dozor.Riddle.Type_6.Question = "text";
			PChar.Dozor.Riddle.Type_6.Answer_1 = "golfe de la perdition|le golfe de la perdition|gulf of doom";
			PChar.Dozor.Riddle.Type_6.KeyPhrase = "L'Escadre insaisissable a perdu son vaisseau amiral.";
		break;

		case 7:
			sString = "- Capitaine ! Deux petits navires pirates droit devant !";
			sString += newStr() + "- Combien de canons ont-ils chacun ? Au rapport !";
			sString += newStr() + "- L'un a 10 canons, l'autre 15 !";
			sString += newStr() + "- Paré au combat !";
			sString += newStr() + "A - 1.2 2.3 2.9";
			sString += newStr() + "D - 2.6";
			sString += newStr() + "E - 1.10 2.5 2.11";
			sString += newStr() + "G - 2.4";
			sString += newStr() + "I - 1.5 1.7 2.14";
			sString += newStr() + "L - 2.2 2.8";
			sString += newStr() + "M - 1.1 2.10";
			sString += newStr() + "N - 1.6 2.12 2.15";
			sString += newStr() + "P - 2.1";
			sString += newStr() + "Q - 1.8";
			sString += newStr() + "R - 1.3";
			sString += newStr() + "T - 1.4 2.13";
			sString += newStr() + "U - 1.9 2.7";
			PChar.Dozor.Riddle.Type_7.Question = sString;
			PChar.Dozor.Riddle.Type_7.Answer_1 = "martinique|la martinique";
			PChar.Dozor.Riddle.Type_7.Answer_2 = "plage du lamentin|la plage du lamentin|plage lamentin|lamentin|plage du lamantin|lamentin beach|la manten beach";
			PChar.Dozor.Riddle.Type_7.KeyPhrase = "L'Escadre insaisissable a été vaincue.";
		break;

		case 8:
			sString = "Voici la fin de ton parcours, " + GetSexPhrase("veilleur", "veilleuse") + " ! Derrière ces portes t'attend une maison, et dans cette maison, dans un coffre fermé à clé, t'attend ta récompense ! Si tu sais où elles se trouvent, rends-toi là-bas sans tarder ; sinon, je te conseille d'ouvrir l'œil et de regarder plus souvent autour de toi pour trouver le bon endroit.";
			PChar.Dozor.Riddle.Type_8.Question = sString;
		break;
	}
}

'''
# transition screens written in quest code (english branch): french text added in front
_FRAMES = [
    ('"You safely reached the bay and lay low. After an hour of waiting, your ship appeared on the horizon, '
     'and a longboat set out from it...", "Reload_To_Location", 0.1, 2.0);',
     '"Vous avez gagné la crique sans encombre pour vous y mettre à l\'abri des regards. Au bout d\'une heure '
     'd\'attente, votre navire est apparu à l\'horizon, et une chaloupe s\'en est détachée..."'),
    ('"You tried to break through the main checkpoint, but the guards reacted instantly. You were surrounded, '
     'disarmed, and killed for the escape attempt...", "TohmasPetit_GameOver", 0.0, 10.0);',
     '"Vous avez tenté de forcer le poste principal, mais les gardes ont réagi aussitôt. Vous avez été encerclé" + '
     'GetSexPhrase("", "e") + ", désarmé" + GetSexPhrase("", "e") + " et tué" + GetSexPhrase("", "e") + '
     '" pour tentative d\'évasion..."'),
]
LINE_PATCHES['Program/Quests/quests_reaction.c'] = [
    ('else SetLaunchFrameFormParam(' + en,
     'else { if (LanguageGetLanguage() == "french") SetLaunchFrameFormParam(' + to_game(fr) + en[en.index('", "') + 1:]
     + ' else SetLaunchFrameFormParam(' + en + ' } ' + MARK)
    for en, fr in _FRAMES]

# --------------------------------------------------------------------------------------------
# english messages written directly in script files (notifications, infirmary, history news, curses...):
# tm/code_strings.json maps, per file, an english literal to its french text. Each occurrence of
# "english" becomes FrS("english", "french") (FrS, added to Program/utils.c, returns the french text
# only when the game language is french). Comparisons (== != case) are never touched.
FRS_FUNC = ('// FR_PATCH : text of the french version (english/russian behaviour unchanged)\r\n'
            'string FrS(string sEn, string sFr)\r\n{\r\n'
            '\tif (LanguageGetLanguage() == "french") return sFr;\r\n\treturn sEn;\r\n}\r\n\r\n')
_UTILS_ANCHOR = '#event_handler(PARSE_STRING, "ParseString");\r\n'
LINE_PATCHES['Program/utils.c'] = [(_UTILS_ANCHOR, _UTILS_ANCHOR + '\r\n' + FRS_FUNC)]
CODE_TM_PATH = os.path.abspath(os.path.join(BASE, '..', 'tm', 'code_strings.json'))
# whole expressions (a gender ending or a closing quote sits between the english pieces)
LINE_PATCHES.setdefault('Program/characters/QuestsUtilite.c', []).extend([
    ('"You made me pretty angry"+ GetSexPhrase("","a") +", no more communication.");',
     'FrS("You made me pretty angry"+ GetSexPhrase("","a") +", no more communication.", "%s")); %s'
     % (to_game('Vous avez épuisé ma patience, je ne vous parle plus.'), MARK)),
    ('"I blurted it out"+ GetSexPhrase("","a") +", sorry...");',
     'FrS("I blurted it out"+ GetSexPhrase("","a") +", sorry...", "%s")); %s'
     % (to_game("J'ai trop parlé, pardon..."), MARK)),
])
LINE_PATCHES.setdefault('Program/Addons/utils.c', []).extend([
    ('else return "the book \'" + sBookName + "\'";',
     'else return FrS("the book \'" + sBookName + "\'", "%s" + sBookName + "%s"); %s'
     % (to_game('le livre « '), to_game(' »'), MARK)),
    ('sld.mapEnc.Name = "Ship \'" + sld.Ship.Name + "\'";',
     'sld.mapEnc.Name = FrS("Ship \'" + sld.Ship.Name + "\'", "%s" + sld.Ship.Name + "%s"); %s'
     % (to_game('Navire « '), to_game(' »'), MARK)),
])


def load_code_tm():
    import json
    if not os.path.exists(CODE_TM_PATH):
        return {}
    return json.load(open(CODE_TM_PATH, encoding='utf-8'))


def wrap_literals(src, mapping, f):
    """"english" -> FrS("english", "french") for every literal of mapping (comparisons excepted)."""
    for en, frt in mapping.items():
        lit = '"' + en + '"'
        frg = to_game(frt).replace('"', "'")
        out, pos, n, done = [], 0, 0, 0
        while True:
            i = src.find(lit, pos)
            if i < 0:
                break
            before = src[max(0, i - 40):i].rstrip()
            if before.endswith('FrS('):
                done += 1
            elif re.search(r'(==|!=|\bcase)$', before):
                pass
            else:
                out.append(src[pos:i])
                out.append('FrS(%s, "%s")' % (lit, frg))
                pos = i + len(lit)
                n += 1
                continue
            out.append(src[pos:i + len(lit)])
            pos = i + len(lit)
        out.append(src[pos:])
        src = ''.join(out)
        if n + done == 0:
            raise SystemExit('texte introuvable dans %s : %s' % (f, en))
    return src


# captain's commission quest: the speciality of the freed prisoner is hard-coded in russian
# (english shows it in russian too). French: "spécialiste en artillerie", "le spécialiste @<sSpeciality>".
LINE_PATCHES['Program/scripts/GenQuests_CaptainComission.c'] = [
    ('\tpchar.GenQuest.CaptainComission.SlaveSpeciality = Speciality;',
     '\tif (LanguageGetLanguage() == "french") { if (Spec == 0) Speciality = "en construction navale"; '
     'if (Spec == 1) Speciality = "en artillerie"; if (Spec == 2) Speciality = "en navigation"; } ' + MARK + '\r\n'
     '\tpchar.GenQuest.CaptainComission.SlaveSpeciality = Speciality;'),
]

# nautical quiz (tavern quiz master: NullCharacter.questions, pirate shipwright: NullCharacter.SeaQuestions).
# The english questions are the same in both files; the answers are typed by the player, so the french
# branch accepts several spellings ("|"-separated, checked with DozorAnswerOk via fixups.txt).
QUIZ_FR = [
    ("Comment appelle-t-on l'ensemble de petits cordages fixés au bord avant de la hune, qui passent par une moque sur l'étai ? Un indice : il empêche les huniers de frotter contre les étais et de s'accrocher aux hunes.",
     "araignée|araignee|araignée de hune|araignee de hune|araignées|araignees|slab line"),
    ("En mer, difficile de garder des vivres frais. Mais ce biscuit-là se conserve des années, pourvu qu'on le garde au sec. Comment l'appelle-t-on ?",
     "biscuit de mer|biscuit|biscuits|galette|galette de mer|pain de mer|hardtack"),
    ("Comment appelle-t-on la brosse cylindrique montée sur une hampe de bois, qui sert à nettoyer l'âme d'un canon des résidus de poudre ?",
     "écouvillon|ecouvillon|cleaning rod"),
    ("Comment appelle-t-on la virure renforcée du bordé extérieur de la coque, juste au-dessus de la ligne de flottaison ?",
     "préceinte|preceinte|préceintes|preceintes|rubbing strake"),
    ("Comment appelle-t-on le bout de cordage gainé de cuir qui maintient une vergue ou une corne contre le mât ou le mât de hune ?",
     "racage|racages|parral"),
    ("Comment appelle-t-on la ligature de deux cordages au moyen d'un fil ou d'un petit cordage ?",
     "amarrage|genope|genopes|liure|aiguillette|seizing"),
    ("Comment appelle-t-on la cloison transversale qui ferme l'avant d'un voilier ?",
     "fronteau|cloison d'éperon|cloison d'eperon|éperon|eperon|beakhead"),
    ("Comment appelle-t-on les pièces transversales qui soutiennent les ponts, relient les deux branches opposées des couples et donnent au navire sa solidité dans le sens de la largeur ?",
     "barrots|barrot|baux|bau|beams"),
    ("Comment s'appelait ce navire de guerre antique, mû par deux rangs de rames ?",
     "birème|bireme|birèmes|biremes"),
    ("Comment appelle-t-on le gros poteau de bois fixé sur le pont, qui sert à amarrer les cordages ?",
     "bitte|bittes|bitt"),
    ("Comment appelle-t-on le petit mât dressé sur le beaupré, qui porte une vergue avec une voile carrée ?",
     "perroquet de beaupré|perroquet de beaupre|mât de perroquet de beaupré|mat de perroquet de beaupre|tourmentin|spirit topmast"),
    ("Quel est le nom de la voile que l'on établit sous le beaupré ?",
     "civadière|civadiere|blindsail"),
    ("Comment appelle-t-on ces espars horizontaux qui ne sont fixés que par une extrémité ? Un indice : ils servent à porter une voile hors du bord, à écarter le gréement et à suspendre les embarcations.",
     "bossoirs|bossoir|bouts-dehors|bout-dehors|bouts dehors|bout dehors|boute-hors|arcs-boutants|arc-boutant|minots|boomkins"),
    ("Comment appelle-t-on l'espar qui prolonge le mât de hune ?",
     "mât de perroquet|mat de perroquet|perroquet|topgallant mast"),
    ("Comment appelle-t-on la manœuvre courante qui sert à orienter une vergue dans le plan horizontal ?",
     "bras|bras de vergue|brace"),
    ("Comment appelle-t-on l'appareil à axe horizontal qui sert à hisser les ancres et les charges ?",
     "guindeau|windlass"),
    ("Quand on tire au canon, le recul est terrible. Comment appelle-t-on le gros cordage qui retient la pièce et en amortit le recul ?",
     "brague|bragues|breeching"),
    ("Comment appelle-t-on la voile supplémentaire que l'on lace directement à la voile principale ?",
     "bonnette maillée|bonnette maillee|bonnette|bonnettes|bonnet"),
    ("Comment appelle-t-on le cordage qui tire vers l'avant la chute d'une voile carrée quand le navire navigue au plus près du vent ?",
     "bouline|boulines|bowline"),
    ("Comment appelle-t-on la troisième voile carrée en partant du bas du mât, établie entre la vergue de perroquet et la vergue de hune ?",
     "perroquet|perroquets|voile de perroquet|grand perroquet|petit perroquet|topgallant sail|topgallant"),
    ("Comment appelle-t-on les gros cordages du gréement dormant qui maintiennent les mâts sur les côtés ?",
     "haubans|hauban|shrouds"),
    ("Comment appelle-t-on l'amarrage en cordage qui relie le beaupré à l'étrave ?",
     "liure|liures|liure de beaupré|liure de beaupre|liures de beaupré|liures de beaupre|gammoning"),
    ("Comment appelle-t-on l'ancre auxiliaire qui sert à déséchouer un navire resté sur un haut-fond ?",
     "ancre à jet|ancre a jet|ancre de jet|ancre de touée|ancre de touee|kedge"),
    ("Comment appelle-t-on la saillie arrondie à l'arrière de la culasse d'un canon ?",
     "bouton de culasse|bouton|cascabel"),
    ("Comment appelle-t-on les petits cordages tendus en travers des haubans, qui servent d'échelons pour grimper dans les mâts ?",
     "enfléchures|enflechures|enfléchure|enflechure|ratlines"),
    ("Comment appelle-t-on le crochet de métal fixé au bout d'un cordage, qui sert à hisser les canots, les marchandises et bien d'autres choses ?",
     "croc|crocs|crochet|croc de palan|hook"),
    ("Comment appelle-t-on la partie haute et plate de l'arrière du navire, où sont installés les fanaux de poupe ?",
     "couronnement|lisse de couronnement|tableau|tableau arrière|tableau arriere|taffrail"),
    ("Comment appelle-t-on la manœuvre courante qui tire vers l'avant le coin inférieur d'une voile ?",
     "amure|amures|tack"),
    ("Comment appelle-t-on l'espar incliné qui porte le bord supérieur d'une voile trapézoïdale ?",
     "corne|cornes|gaff"),
    ("Quelle mesure de longueur vaut un dixième de mille marin ?",
     "encablure|encablures|une encablure|câble|cable"),
    ("Comment appelle-t-on le petit sac de toile qui contient une charge de poudre ?",
     "gargousse|gargousses|powder bag"),
    ("Comment appelle-t-on la partie surélevée du pont supérieur, à l'arrière du navire ?",
     "dunette|gaillard d'arrière|gaillard d'arriere|gaillard arrière|gaillard arriere|quarterdeck"),
    ("Comment appelle-t-on la petite pièce de bois dur en forme de cône que l'on passe dans un nœud pour l'empêcher de se serrer ?",
     "cabillot|cabillots|toggle"),
    ("Comment appelle-t-on la voile triangulaire établie sur l'étai qui va du mât au beaupré ?",
     "foc|focs|clinfoc|grand foc|petit foc|jib"),
    ("Comment appelle-t-on l'ouverture pratiquée dans la muraille du navire pour le passage du câble de l'ancre ? Attention, maintenant...",
     "écubier|ecubier|écubiers|ecubiers|hawse-hole|hawse hole"),
    ("Comment appelle-t-on la voile de hune du mât d'artimon ?",
     "perroquet de fougue|hunier d'artimon|mizzen topsail"),
    ("Comment appelle-t-on la voile supplémentaire en forme de trapèze que l'on établit sur le côté extérieur d'une voile carrée ?",
     "bonnette|bonnettes|bonnette de hunier|bonnette basse|studsail|studding sail"),
    ("Comment appelle-t-on le cordage souple cousu le long des bords d'une voile ?",
     "ralingue|ralingues|boltrope"),
    ("Comment appelle-t-on le poids qui sert à mesurer la profondeur ?",
     "plomb de sonde|plomb|le plomb|sonde|la sonde|lead"),
    ("Comment appelle-t-on l'homme qui sonde les fonds au plomb et connaît donc parfaitement la côte ?",
     "pilote|pilote côtier|pilote cotier|lamaneur|pilot"),
    ("Comment appelle-t-on le trou rond, bordé de points, que l'on pratique dans une voile ?",
     "œillet|oeillet|œillets|oeillets|glut"),
    ("Comment appelle-t-on la deuxième voile carrée en partant du bas du mât, établie entre la vergue de hune et la basse vergue ?",
     "hunier|huniers|grand hunier|petit hunier|square topsail|topsail"),
    ("Comment appelle-t-on un clou de bois ?",
     "gournable|gournables|cheville|chevilles|cheville de bois|peg"),
    ("Comment appelle-t-on le petit meuble de bois où l'on range le compas, la lampe et le sablier ?",
     "habitacle|binnacle"),
    ("Comment appelle-t-on les cordages sur lesquels les matelots se tiennent quand ils travaillent sur les vergues ?",
     "marchepieds|marchepied|marche-pieds|marche-pied|footropes"),
    ("Comment appelle-t-on la pièce de bois qui couronne le pavois d'un navire ponté ?",
     "plat-bord|plat bord|platbord|lisse de plat-bord|lisse de pavois|gunwale"),
    ("Comment appelle-t-on la rangée horizontale de petits cordages passés dans une voile, qui permet d'en réduire la surface ?",
     "ris|les ris|bande de ris|bandes de ris|garcettes de ris|garcettes|reef"),
    ("Comment appelle-t-on l'anneau de l'ancre auquel on attache le câble ?",
     "organeau|organeaux|cigale|eye"),
    ("Comment appelle-t-on le cadre de pièces de bois, posé en tête de mât, qui sert à assembler les parties d'un mât ?",
     "barres|barres de hune|barres de perroquet|barres de flèche|barres de fleche|élongis|elongis|crosstrees"),
    ("Comment appelle-t-on l'encastrement dans lequel on fixe le pied d'un mât ?",
     "emplanture|emplantures|carlingue|step"),
    ("Comment appelle-t-on l'espar qui prolonge le bas-mât ?",
     "mât de hune|mat de hune|mâts de hune|mats de hune|topmast"),
    ("Comment appelle-t-on la voile longitudinale, triangulaire ou parfois trapézoïdale, que l'on établit sur un étai ?",
     "voile d'étai|voile d'etai|voiles d'étai|voiles d'etai|trinquette|staysail"),
    ("Avec quoi enduit-on les œuvres vives d'un navire pour les protéger des tarets ?",
     "goudron|brai|courée|couree|suif|poix|tar"),
    ("Comment appelle-t-on la voile longitudinale trapézoïdale dont le bord supérieur est lacé à une corne et le bord inférieur tendu le long d'un gui ?",
     "brigantine|voile aurique|voile à corne|voile a corne|goélette|goelette|voile goélette|voile goelette|trysail|trisail"),
    ("Comment s'appelait ce navire de guerre de la Grèce antique, mû par trois rangs de rames et armé d'un éperon ?",
     "trière|triere|trières|trieres|trier"),
    ("Comment s'appelait ce navire de guerre de la Rome antique, à trois rangs de rames ?",
     "trirème|trireme|trirèmes|triremes"),
    ("Comment appelle-t-on l'espar qui prolonge le beaupré ?",
     "bâton de foc|baton de foc|boute-hors de foc|bout-dehors de foc|jib boom"),
    ("Quel est le nom du cordage qui sert à hisser certaines vergues, les voiles, les pavillons de signaux et bien d'autres choses ?",
     "drisse|drisses|halyard"),
    ("Comment appelle-t-on le prolongement de la muraille du navire au-dessus du pont supérieur découvert ?",
     "pavois|bastingage|bastingages|bulwark"),
    ("Comment appelle-t-on les saillies cylindriques qui permettent de régler la hausse d'un canon ?",
     "tourillons|tourillon|trunnions"),
    ("Comment appelle-t-on le pont supérieur à l'arrière d'un voilier, où se tiennent les officiers de quart et où sont installés les compas ?",
     "gaillard d'arrière|gaillard d'arriere|gaillard arrière|gaillard arriere|gaillards|plage arrière|plage arriere|dunette|quarterdeck"),
    ("Comment appelle-t-on les larges planches posées à l'horizontale le long des bords, qui permettent de passer du gaillard d'avant au gaillard d'arrière ?",
     "passavant|passavants|passe-avant|passe-avants|embelle|waist"),
    ("Comment appelle-t-on la manœuvre qui tire vers l'arrière le coin inférieur d'une voile et la maintient dans la position voulue ?",
     "écoute|ecoute|écoutes|ecoutes|sheet"),
    ("Comment appelle-t-on la pièce transversale qui forme une côte de la coque du navire ?",
     "couple|couples|membrure|membrures|frame"),
    ("Comment appelle-t-on la boucle que forme un cordage quand on le passe autour d'un objet ?",
     "tour|un tour|tour mort|un tour mort|tours morts|round turn"),
    ("Comment appelle-t-on la grande cuillère cylindrique qui sert à décharger un canon, c'est-à-dire à en retirer le boulet et la gargousse ?",
     "lanterne|cuillère|cuillere|cuiller|tire-bourre|tire bourre|lantern"),
    ("Comment appelle-t-on la pièce de bois percée de deux trous qui sert à réunir les parties d'un mât ?",
     "chouquet|chouquets|mast cap"),
    ("Comment appelle-t-on ces poulies rondes en bois, sans réa, percées de trois trous, qui servent à raidir les étais et les haubans ?",
     "caps de mouton|cap de mouton|caps-de-mouton|cap-de-mouton|deadeyes|deadeye"),
    ("Quel était le principal produit exporté des Caraïbes, au début et au milieu de ce siècle ?",
     "sucre|le sucre|canne à sucre|canne a sucre|sugar"),
    ("Quelle était la principale « marchandise » importée dans les Caraïbes, au début et au milieu de ce siècle ?",
     "esclaves|les esclaves|des esclaves|slaves"),
    ("Quel est le nom complet du premier navigateur hollandais qui fit le tour du monde ?",
     "olivier van noort|oliver van noort|van noort"),
    ("La Compagnie néerlandaise des Indes occidentales fonda son premier comptoir en Amérique en 1626. Comment s'appelait-il ?",
     "la nouvelle-amsterdam|nouvelle-amsterdam|nouvelle amsterdam|la nouvelle amsterdam|new amsterdam|nieuw amsterdam"),
    ("Jouons à un petit jeu. Je suis un poète, pirate et capitaine anglais. J'ai colonisé la Virginie et joui des faveurs de la reine Élisabeth Ire. J'ai aussi été décapité en 1618. Qui suis-je ?",
     "sir walter raleigh|walter raleigh|raleigh|sir walter ralegh|walter ralegh"),
    ("Qui fut le premier pirate à hisser le Jolly Roger, le pavillon à tête de mort ?",
     "emanuel wynne|emmanuel wynne|wynne"),
]
assert len(QUIZ_FR) == 74


def _quiz_func():
    lines = ['// FR_PATCH : nautical quiz in french (accepted answers separated by "|", see DozorAnswerOk)',
             'void FrFillQuestions(string sAttr)', '{',
             '\tNullCharacter.(sAttr) = %d;' % (len(QUIZ_FR) - 1)]
    for i, (q, a) in enumerate(QUIZ_FR):
        assert '"' not in q + a and a == a.lower()
        lines.append('\tNullCharacter.(sAttr).q%d = "%s";' % (i, to_game(q)))
        lines.append('\tNullCharacter.(sAttr).a%d = "%s";' % (i, a))     # typed text: no PUA conversion
    lines += ['}', '', '']
    return '\r\n'.join(lines)


LINE_PATCHES['Program/characters/Questions.c'] = [
    ('void InitQuestions()\r\n{\r\n',
     _quiz_func() + 'void InitQuestions()\r\n{\r\n'
     '\tif (LanguageGetLanguage() == "french") { FrFillQuestions("questions"); return; } ' + MARK + '\r\n')]
LINE_PATCHES['Program/characters/SeaQuestions.c'] = [
    ('void SeaQuestionsInit()\r\n{\r\n',
     'void SeaQuestionsInit()\r\n{\r\n'
     '\tif (LanguageGetLanguage() == "french") { FrFillQuestions("SeaQuestions"); return; } ' + MARK + '\r\n')]

_DOZOR_HEAD = 'void DozorSetRiddleQuestion(int iType)\r\n{\r\n\tstring sString = "";\r\n'
LINE_PATCHES['Program/Addons/Quests.c'] = [
    (_DOZOR_HEAD,
     to_game(DOZOR_FR).replace('\r\n', '\n').replace('\n', '\r\n') + _DOZOR_HEAD +
     '\tif (LanguageGetLanguage() == "french") { DozorSetRiddleQuestionFr(iType); return; } ' + MARK + '\r\n'),
]
_DOZOR_TEST = '\tif(sAnswer == sAnswerBase && sAnswer2 == sAnswerBase2)\r\n\t{\r\n\t\tstring sKeyPhrase = PChar.Dozor.Riddle.Type_%d.KeyPhrase;'
LINE_PATCHES['Program/INTERFACE/Mekakhrom.c'] = [
    ('\tif(sAnswer == sAnswerBase)\r\n',
     '\tif(DozorAnswerOk(sAnswer, sAnswerBase)) ' + MARK + '\r\n')] + [
    (_DOZOR_TEST % n,
     _DOZOR_TEST.replace('sAnswer == sAnswerBase && sAnswer2 == sAnswerBase2',
                         'DozorAnswerOk(sAnswer, sAnswerBase) && DozorAnswerOk(sAnswer2, sAnswerBase2)')
     .replace(')\r\n', ') ' + MARK + '\r\n', 1) % n)
    for n in (2, 3, 4, 7)]


def rd(p):
    return open(p, 'rb').read().decode('utf-8')


def wr(p, s):
    open(p, 'wb').write(s.encode('utf-8'))


def strip_old(body):
    """removes a previous FR_PATCH block (from the marker line to its closing brace)."""
    first = body.split('\n', 1)[0]
    if MARK not in first:           # only a block sitting right at the top of this function
        return body
    i = body.find(MARK)
    start = body.rfind('\n', 0, i) + 1
    j = body.index('{', i)
    depth, k = 0, j
    while True:
        if body[k] == '{':
            depth += 1
        elif body[k] == '}':
            depth -= 1
            if depth == 0:
                break
        k += 1
    end = body.index('\n', k) + 1
    return body[:start] + body[end:]


def patch_func(src, name, cases):
    m = re.search(r'(?m)^string\s+%s\s*\(\s*(int|ref)\s+(\w+)\s*\)[^\n]*\n\{[^\n]*\n' % name, src)
    if not m:
        raise SystemExit('fonction introuvable : ' + name)
    var = m.group(2) if m.group(1) == 'int' else 'sti(%s.nation)' % m.group(2)
    head_end = m.end()
    src = src[:head_end] + strip_old(src[head_end:])
    case_lines = ''.join('\t\t\tcase %s: return "%s"; break;\n' % (c, to_game(v)) for c, v in cases.items())
    block = ('\tif (LanguageGetLanguage() == "french") %s\n\t{\n\t\tswitch(%s)\n\t\t{\n%s\t\t}\n\t}\n'
             % (MARK, var, case_lines))
    if '\r\n' in src:
        block = block.replace('\n', '\r\n')
    return src[:head_end] + block + src[head_end:]


def patch_lines(src, pairs, f):
    for old, new in pairs:
        if new in src:
            continue
        if old not in src:
            raise SystemExit('ligne introuvable dans %s : %s' % (f, old.strip()))
        src = src.replace(old, new, 1)
    return src


def main(undo=False):
    code_tm = load_code_tm()
    files = sorted({f for f, _ in PATCHES.values()} | set(LINE_PATCHES) | set(code_tm))
    os.makedirs(BACKUP, exist_ok=True)
    for f in files:
        p = os.path.join(ROOT, f)
        b = os.path.join(BACKUP, f.replace('/', '__'))
        if undo:
            if os.path.exists(b):
                shutil.copy2(b, p)
                print('restaure :', f)
            continue
        src = rd(p)
        if MARK not in src and 'FrS(' not in src:
            shutil.copy2(p, b)          # pristine copy (refreshed after a game update)
        for name, (ff, cases) in PATCHES.items():
            if ff == f:
                src = patch_func(src, name, cases)
        if f in LINE_PATCHES:
            src = patch_lines(src, LINE_PATCHES[f], f)
        if f in code_tm:
            src = wrap_literals(src, code_tm[f], f)
        wr(p, src)
        print('patche :', f)


if __name__ == '__main__':
    main('--undo' in sys.argv)
