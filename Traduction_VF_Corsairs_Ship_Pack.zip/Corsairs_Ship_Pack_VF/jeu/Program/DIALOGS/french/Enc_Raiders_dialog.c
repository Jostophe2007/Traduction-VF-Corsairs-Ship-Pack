void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, Diag;
	int i;
	string sGroup;
	bool bOk, bOk1;
	int iMoney;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);
	int iTemp = sti(npchar.EncQty);
	string sTemp = "Gang" + locations[FindLocation(npchar.location)].index + "_";

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "exit_Robbed":
			ChangeCharacterReputation(pchar, -1);
			//int iMoney = makeint(makeint(Pchar.money)/20)*10;
			iMoney = sti(NPChar.moneyfee);
			AddMoneyToCharacter(pchar, -iMoney);
			AddMoneyToCharacter(npchar, iMoney);
			AddCharacterExpToSkill(pchar, "Leadership", sti(NPChar.EncQty)*10);
			npchar.SaveItemsForDead   = true; // сохранять на трупе вещи
			npchar.DontClearDead = true;  // не убирать труп через 200с
			AddSimpleRumour(LinkRandPhrase("Vous avez entendu ? Le brigand du coin, " + GetFullName(npchar) + ", a fait une nouvelle victime. Un capitaine a pris peur et a payé. On dit qu'il s'est délesté de " + FindRussianMoneyString(iMoney) + ", hi hi...",
				"Oui, capitaine " + GetFullName(pchar) + ", j'ai déjà entendu dire que vous avez dמ lâcher " + FindRussianMoneyString(iMoney) + " pour acheter votre tranquillité à un brigand du coin, " + GetFullName(npchar) + ". Que dire ? Pas de chance ! Ha ha ha !",
				"Vous savez que des brigands du coin ont attaqué un capitaine ? Eh bien, ils l'ont délesté de la coquette somme de " + FindRussianMoneyString(iMoney) + " !"), sti(npchar.nation), 5, 1);
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				sld.LifeDay = 0;
				LAi_SetWarriorTypeNoGroup(sld);
				sld.Dialog.CurrentNode = "OnceAgain";
				LAi_SetCheckMinHP(sld, LAi_GetCharacterHP(sld)-1, false, "LandEnc_RaidersBeforeDialog");
			}
			DialogExit();
		break;

		case "exit_fight":
			sGroup = "RaidersGroup_" + locations[FindLocation(npchar.location)].index;
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_SetWarriorTypeNoGroup(sld);
				LAi_group_MoveCharacter(sld, sGroup);
				LAi_RemoveCheckMinHP(sld);
				LAi_SetImmortal(sld, false);
			}
			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "LandEnc_RaidersAfrer");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "exit_RunFight":
			AddSimpleRumour(LinkRandPhrase(RandPhraseSimple("Vous avez entendu ? Ce brigand, " + GetFullName(npchar) + ", a enfin trouvé à qui parler. Lui et ses compères voulaient détrousser "+ GetSexPhrase("un capitaine, mais il s'est révélé", "une aventurière, mais elle s'est révélée") +" bien trop coriace pour eux. Résultat : notre vaillant brigand en a fait dans son pantalon, ha ha ! Bien fait pour lui : ça lui apprendra à racketter les fermiers du coin pour quelques sous.",
				"Merci infiniment, capitaine " + GetFullName(pchar) + ", vous avez enfin mis en déroute la bande de " + GetFullName(npchar) + ". Ces gredins nous rendaient la vie impossible. On n'osait même plus envoyer un gamin à la ferme chercher du lait : ils l'attendaient au passage et lui prenaient l'argent."),
				"Vous avez entendu ? "+ GetSexPhrase("Un capitaine a enfin donné", "Une aventurière a donné") +" une bonne leçon à ce voyou, " + GetFullName(npchar) + ", qui sévissait dans la jungle et terrorisait les fermiers du coin. Je me demande pour combien de temps ça leur כtera l'envie de détrousser les gens.",
				"Vous n'avez pas entendu dire que le brigand " + GetFullName(npchar) + " et ses sbires ont voulu détrousser "+ GetSexPhrase("un capitaine", "une femme capitaine") +" ? Peine perdue : le capitaine s'est révélé un trop gros morceau pour eux. On dit que ces brigands rכdent dans la jungle comme un requin dans un banc de sardines. Dieu merci, il reste des gens capables de nous défendre, pendant que les autorités se tournent les pouces, trop occupées par leurs propres affaires..."), sti(npchar.nation), 5, 1);
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_type_actor_Reset(sld);
				LAi_ActorAfraid(sld, Pchar, true);
				sld.Dialog.CurrentNode = "GetTheHellOut";
			}
			DialogExit();
		break;

		case "exit_noFight":
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				sld.LifeDay = 0;
				LAi_SetWarriorTypeNoGroup(sld);
				LAi_SetCitizenTypeNoGroup(sld);
				//#20200315-01
                sld.chr_ai.type.checkFight = 999999.0;
				sld.Dialog.CurrentNode = "GetLost";
				LAi_SetCheckMinHP(sld, LAi_GetCharacterHP(sld)-1, true, "LandEnc_RaidersBeforeDialog");
			}
			DialogExit();
		break;

		case "First Time":
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_type_actor_Reset(sld);
				LAi_RemoveCheckMinHP(sld);
				LAi_SetImmortal(sld, false);
			}
			bool bRape = GetOfficersQuantity(pchar) == 0 || rand(4) == 0;
			if (pchar.sex == "woman" && bRape)
			{
				dialog.text = RandPhraseSimple(LinkRandPhrase("Eh bien, ça alors, quelle beauté se promène dans la jungle ! ",
				"Quelle chance j'ai aujourd'hui, je vais enfin pouvoir m'offrir une femme ! ",
				"Pas si vite, ma jolie, tu as encore une petite chose à faire ! ")+
				LinkRandPhrase("J'espère que ça ne te dérange pas qu'on s'amuse un peu ? Je te préviens tout de suite : je n'accepte pas les refus.",
				"Faisons ça gentiment : tu te déshabilles, tu fais ce qu'on te demande, et tu reprends ta route.",
				"Tu ne pensais quand même pas passer devant moi comme ça ? Il va d'abord falloir faire la connaissance de mon petit camarade !"),

				LinkRandPhrase("דa alors, j'en crois pas mes yeux ! Ma petite dame, vous savez que vous vous mariez aujourd'hui ? Par hasard, et pour pas longtemps...",
				"Attends, ma mignonne, inutile de te presser, tu as déjà trouvé ton destin. Tu as plu à mon ami, et si tu n'es pas bête, tu me plairas aussi... Jette ta ferraille, et faisons plus ample connaissance, ma belle.",
				"Alors, ma poulette, on s'ennuyait toute seule dans la forêt ? On va te distraire, nous ! Les gars, faites la queue !"))

				Link.l1 = "Très bien, fais ce que tu as à faire, ordure."
				Link.l1.go = "Rape";
				if (GetOfficersQuantity(pchar) > 0)
				{
					Link.l1 = LinkRandPhrase("Eh bien non, je ne me donnerai pas à toi, et mes gardes ne le permettront pas. ",
					"Tu ferais mieux d'oublier ces idées sales : de toute façon, mes hommes d'abordage ne laisseront personne me manquer de respect. ",
					"Tu pourrais essayer de me prendre, mais réfléchis : est-ce que ça vaut la peine de risquer ta vie face à mes officiers ? ")+
					LinkRandPhrase("Laisse-moi te payer, et nous nous quitterons sans effusion de sang.",
					"En échange, que dirais-tu d'une petite somme d'argent pour nous quitter en paix ?",
					"Combien veux-tu pour nous laisser passer ?")
					Link.l1.go = "Node_2_woman";
				}
				Link.l2 = RandPhraseSimple("Tu t'es attaqué à la mauvaise personne, ordure. Je ne suis pas une fille fragile, je sais me défendre.",
				"Répète ça devant le canon de mon pistolet, babouin en rut !",
				"Alors, tu veux absolument entrer dans la danse, mais quelque chose te retient ? Approche, ma lame va régler ça en un instant.");
				Link.l2.go = "CheckSkills";
				break;
			}
			dialog.text = LinkRandPhrase(LinkRandPhrase("Halte ! Pose ton arme ! Sors ton or, ou tu meurs sur place !",
				"Pas un geste, "+ GetSexPhrase("voyageur", "ma belle") +" ! Ne touche pas à ton arme et n'essaie pas de faire le malin si tu tiens à la vie !",
				"Attendez, "+ GetSexPhrase("voyageur", "ma belle") +" ! Ici, c'est une route à péage ! Pour passer, il faut payer."),
				LinkRandPhrase("Hé, "+ GetSexPhrase("l'ami", "ma petite") +" ! Pas si vite ! Je veux voir si ta bourse n'est pas trop lourde.",
				"Approche, approche. Je veux entendre l'or tinter dans ta bourse.",
				"Un instant, "+ GetSexPhrase("l'ami", "ma petite") +". Mes amis et moi, on se demandait combien d'or pouvait tenir dans ta bourse. Il faut vérifier avant que ça tourne à la bagarre."),
				"Prenez votre temps, "+ GetSexPhrase("passant", "ma jolie") +" ! J'aimerais avoir une petite conversation à cœur ouvert avec vous.");
			Link.l1 = LinkRandPhrase(LinkRandPhrase("De quoi parlez-vous ?", "Qu'y a-t-il ?", "De quoi parlez-vous ?"), "Que voulez-vous dire ?", "De quoi parlez-vous ?");
			Link.l1.go = "Node_2";

			Link.l2 = LinkRandPhrase(LinkRandPhrase("Ah, des brigands ?! Vous allez bientכt vous reposer pour de bon !",
				"Des brigands, c'est ça ?! Vous fuyez la justice, je suppose ? Eh bien, la justice est venue à vous d'elle-même...",
				"On ne t'a pas appris qu'il n'est pas bien d'importuner les gens ? Je vais devoir te donner une leçon..."),
				LinkRandPhrase("Oh, quel insolent ! J'espère que ta lame est aussi affמtée que ta langue.",
				"Je vois que tu as la langue bien pendue. J'espère que tu manies la lame aussi bien ?",
				"Ah, les brigands ! On a beau vous pendre et vous pendre, vous ne vous calmez toujours pas..."),
				LinkRandPhrase(RandPhraseSimple("Ah, les brigands ! Avec les gens comme vous, je ne fais pas de longs discours !",
				"Quel effronté ! Tu pues à un mille à la ronde, mais tu parles bien trop pour t'adresser à "+ GetSexPhrase("un honnête homme", "une honnête femme") +"."),
				"D'habitude, c'est mon pistolet qui parle aux gens comme toi !",
				"Encore des brigands ! Bon, je ne vous promets pas la potence, mais je peux vous faire deux ou trois trous dans le ventre !"));
			Link.l2.go = "CheckSkills";
			Link.l3 = LinkRandPhrase("Tu sais qu'une patrouille me suit ? Il me suffit de siffler, et tu es mort.",
				RandPhraseSimple("Tu n'as pas peur que j'appelle la patrouille ? Elle te cherche justement par ici.",
				"Une patrouille a déjà été envoyée à vos trousses, elle sera là d'une minute à l'autre : vous prenez un gros risque."),
				RandPhraseSimple("Vous feriez mieux de déguerpir vite. Une patrouille arrive par ici, je viens de parler avec son officier.",
				"J'adorerais poursuivre la conversation, mais je crains que la patrouille que je viens de croiser ne laisse pas notre rencontre se changer en franche amitié."));
			Link.l3.go = "Node_3";
		break;

		case "Node_2":
			iMoney = 100*MOD_SKILL_ENEMY_RATE*3*sti(NPChar.EncQty)+makeint(100 * sti(PChar.rank))+makeint(100 * sti(NPChar.rank)*sti(NPChar.EncQty));
			NPChar.moneyfee = iMoney;
			dialog.text = LinkRandPhrase(LinkRandPhrase("Arrête de faire semblant de ne pas comprendre ! Sors ton or, et peut-être que je te laisserai partir !",
				"Tu n'as jamais entendu parler des frais de route ? Si tu ne te sépares pas de ton or, tu te sépareras de ta tête !",
				"Hé, c'est un simple péage qui va te coמter ta bourse... Et encore, si je ne me fâche pas."),
				RandPhraseSimple("C'est très simple : soit tu nous donnes ton or de plein gré et tu repars, soit tu restes ici et c'est nous qui repartons avec ton or, mais la deuxième option ne te plaira sמrement pas, héhé.",
				"On dirait que tu ne comprends pas. Délie ta bourse ! א moins que tu ne veuilles que je la prenne sur ton cadavre !"),
				"Je t'explique, puisque tu as la comprenette difficile. Donne-moi tout ton argent si tu veux vivre !");
				dialog.text = dialog.text+ "\nJe ne crois pas que tu te ruineras en lâchant "+iMoney+" piastres. Soit environ "+makeint(iMoney/sti(NPChar.EncQty))+" par compère.";
			//Link.l1 = "Damn it! You bastard! I only have with me " + makeint(makeint(Pchar.money)/20)*10 + "piastres.";
			if(sti(pchar.money) >= sti(NPChar.moneyfee))
			{
				Link.l1 = "Bon sang ! Ordure ! Prends ton argent !";
			}
			else
			{
				Link.l1 = "Je n'ai pas autant d'argent.";
			}
			Link.l1.go = "CheckMoney";
			Link.l2 = LinkRandPhrase((LinkRandPhrase("Tu veux de l'argent ? Viens donc le chercher, et on verra combien de sous tu vaux.",
				"Comment oses-tu, ignorant ! Je vais devoir te donner une leçon de bonnes manières !",
				"Quelle arrogance ! Eh bien, voyons si les rats de terre viendront à bout du loup de mer !")),
				LinkRandPhrase("On devrait te fouetter pour une telle insolence !",
				"Oh, bande de gredins ! Eh bien, priez donc vos démons !",
				"Gibiers de potence, on devrait vous pendre sur la grand-place ! Allez, il va falloir salir mon épée !"),
				RandPhraseSimple("Qu'est-ce qui te fait croire que je vais secouer ma bourse devant toi ?",
				"דa ne te gêne pas que j'aie de quoi me défendre ?"+" Et que je ne me promène pas dans la jungle en dormant debout ?"));
			Link.l2.go = "CheckSkills";
		break;

		case "Node_2_woman":
			iMoney = 100*MOD_SKILL_ENEMY_RATE*3*sti(NPChar.EncQty)+makeint(100 * sti(PChar.rank))+makeint(100 * sti(NPChar.rank)*sti(NPChar.EncQty));
			NPChar.moneyfee = iMoney;
			dialog.text = "Je ne crois pas que tu te ruineras en lâchant "+iMoney+" piastres. Soit environ "+makeint(iMoney/sti(NPChar.EncQty))+" par compère.";
			//Link.l1 = "Damn it! You bastard! I only have with me " + makeint(makeint(Pchar.money)/20)*10 + "piastres.";
			if(sti(pchar.money) >= sti(NPChar.moneyfee))
			{
				Link.l1 = "Bon sang ! Ordure ! Prends ton argent !";
			}
			else
			{
				Link.l1 = "Je n'ai pas autant d'argent.";
			}
			Link.l1.go = "CheckMoney";
			Link.l2 = RandPhraseSimple("Combien ? Quelle arrogance, il va falloir te donner une leçon pour ça.",
				"Et moi qui comptais sur ta discrétion. א ces prix-là, il est bien plus simple de vous tuer !");
			Link.l2.go = "CheckSkills";
		break;

		case "Node_3":
			bOk = makeint(pchar.reputation) < 10 || makeint(pchar.reputation) > 90;
			if(bOk || GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) == 100 || CheckCharacterPerk(pchar, "Trustworthy") || CheckOfficersPerk(pchar, "SeaDogProfessional"))
			{
				dialog.text = RandPhraseSimple("Bon sang ! Bon, salut. Et pas d'histoires.",
					"Tu as de la chance cette fois, mais la prochaine fois, tu me devras le double ! N'oublie pas de me le rappeler, héhé.");
				Link.l1 = RandPhraseSimple("Comment pourrais-je l'oublier ?", "Allez, allez, filez tant que vous êtes encore entiers.");
				Link.l1.go = "Exit_NoFight";
			}
			else
			{
				bOk1 = makeint(pchar.reputation) < 61 && makeint(pchar.reputation) > 39;
				if(!bOk || GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 35)
				{
					dialog.text = RandPhraseSimple("Et nous, on va te découper en silence, tu n'auras même pas le temps de crier.",
						"Bon sang ! Il va falloir te découper vite fait, sans faire de bruit.");
					Link.l1 = "Comme vous voudrez. Je vous aurai prévenus.";
					Link.l1.go = "Exit_Fight";
				}
				else
				{
					dialog.text = RandPhraseSimple("Qu'est-ce que j'en ai à faire, de ta patrouille ? Tout est à moi ici, et j'ai tout payé. Alors vide ta bourse et retiens ta langue.",
						"Qui essaies-tu d'effrayer ?! La patrouille de cette forêt, pour les gens comme toi, c'est moi. Personne n'est encore reparti sans payer !");
					Link.l1 = "Bon sang ! Ordure ! Je n'ai que " + makeint(makeint(Pchar.money)/20)*10 + " piastres sur moi.";
					Link.l1.go = "CheckMoney";
					Link.l2 = RandPhraseSimple(LinkRandPhrase("Hum, ce n'est pas à toi de me donner des ordres.",
						"Pour une telle audace, je vais te faire deux ou trois trous dans la tête. Pour t'aérer les idées.",
						"Une telle insolence ne peut rester impunie !"),
						"Eh, tu t'es trompé de métier...");
					Link.l2.go = "CheckSkills";
				}
			}
		break;

		case "CheckSkills":
			bool z_ok = (GetCharacterSkillToOld(Pchar, "Fencing") >= 7) && (makeint(Pchar.Rank) >= 8) && (Makeint(PChar.reputation) < 30);
			if (z_ok || CheckOfficersPerk(pchar, "SeaDogProfessional"))
			{
				Diag.TempNode = "GetLost";
				dialog.text = LinkRandPhrase(RandPhraseSimple("Hé, ne t'énerve pas comme ça, "+ GetSexPhrase("l'ami", "ma petite") +" ! Je plaisantais ! Passe ton chemin !",
					"Bon, j'ai changé d'avis. Tu peux passer, puisque c'est comme ça."),
					"Quoi, "+ GetSexPhrase("encore toi, le « brave capitaine »", "encore toi, la « guerrière »") +" ? Bon, va en paix...",
					"Du calme, "+ GetSexPhrase("l'ami", "ma petite") +". Tu ne vois pas qu'on s'est trompés ? Passe ton chemin, ça vaut mieux pour toi.");
				Link.l1 = LinkRandPhrase(LinkRandPhrase("Eh bien, à la prochaine !",
					"Tu devrais abandonner ce métier tant que tu as la peau intacte.",
					"Bon, fais attention à ne plus croiser mon chemin."),
					RandPhraseSimple("La prochaine fois, fais attention à qui tu ouvres ta bouche.",
					"Remercie Dieu que je sois de bonne humeur aujourd'hui."),
					RandPhraseSimple("Un tel commerce ne te mènera à rien de bon. Adieu.",
					"Eh bien, c'est une sage décision. Bonne continuation !"));
				Link.l1.go = "Exit_NoFight";
				Link.l99 = LinkRandPhrase("Pas question, l'ami. Je vais devoir t'apprendre les bonnes manières.",
					"Tu as eu peur ?! Mais il faut assumer ses actes ! Pas vrai ?",
					"Pas question ! Maintenant, je n'aurai de repos qu'une fois ta peau trouée !");
				Link.l99.go = "GetTheHellOut";
			}
			else
			{
				dialog.text = LinkRandPhrase("Et moi qui voulais repartir en paix ! Maintenant, ne t'en prends qu'à toi-même !",
								"Tu n'aurais pas dמ commencer. Vaurien ! Maintenant, tu vas crever comme un chien !",
								"Je vais te mettre en pièces ! Je vais t'arracher le foie et le donner aux chiens !");
				Link.l1 = RandPhraseSimple("Je vais te faire ravaler tes paroles !", "Qui menaces-tu, ordure ?!");
				Link.l1.go = "Exit_Fight";
			}
		break;

		case "CheckMoney":
			if(sti(pchar.money) >= sti(NPChar.moneyfee))
			{
				Diag.TempNode = "OnceAgain";
				dialog.text = LinkRandPhrase(RandPhraseSimple("Bien ! Donne-les-moi et dégage !",
					"Ce n'est pas grand-chose, mais c'est mieux que rien. C'est agréable de traiter avec une personne intelligente ! Tu peux partir, maintenant."),
					"Voilà qui est mieux ! Comme disait un de mes amis, c'est agréable d'écouter une personne intelligente, mais on peut aussi parler à un imbécile, héhé.",
					"En échange de ton or, je vais te donner un conseil : ne te promène pas dans la jungle, "+ GetSexPhrase("si tu es une telle mauviette ! Reste plutכt à la taverne du port à boire ton rhum : ce sera meilleur pour ta santé", "ma jolie. Sinon, on pourrait te faire bien pire que te voler") +".");
				Link.l1 = "Maudits gibiers de potence !";
				Link.l1.go = "Exit_Robbed";
			}
			else
			{
				dialog.text = "Je crois que tu essaies de me rouler ! Mais peu importe, je vais te chatouiller un peu : on verra bien ce qui tombe.";
				Link.l1 = "Bon sang !";
				Link.l1.go = "Exit_Fight";
			}
		break;

		case "Rape":
			AddCharacterExpToSkill(pchar, "Leadership", -100);
            AddCharacterExpToSkill(pchar, "Fencing", 50);
            AddCharacterExpToSkill(pchar, "Pistol", 50);
            AddCharacterHealth(pchar, -10);
			Diag.TempNode = "OnceAgainRape";
			AddDialogExitQuest("PlaySex_1");
			for(i = 0; i < iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				sld.LifeDay = 0;
				LAi_SetWarriorTypeNoGroup(sld);
				sld.Dialog.CurrentNode = "OnceAgainRape";
				LAi_SetCheckMinHP(sld, LAi_GetCharacterHP(sld)-1, true, "LandEnc_RaidersBeforeDialog");
			}
			DialogExit();
		break;

		case "OnceAgainRape":
			Diag.TempNode = "OnceAgainRape";
			dialog.text = LinkRandPhrase("On en a fini, tu peux aller oם tu allais.",
				"J'espère qu'on se reverra, héhé. En attendant, tu peux partir.",
				"Si tu ne veux pas passer une deuxième fois à la caisse, tu ferais mieux de déguerpir.");
			Link.l1 = "Je m'en vais.";
			Link.l1.go = "Exit";
			Link.l2 = "Pas question, je ne partirai qu'après ta mort, salopard !";
			Link.l2.go = "Exit_Fight";
		break;

		case "OnceAgain":
			Diag.TempNode = "OnceAgain";
			dialog.text = LinkRandPhrase("Encore toi ? Allez, file chez ta maman ! Sinon, je pourrais me fâcher.",
				"Quoi ? Tu n'as pas encore donné tout ton or ? Ha ha ha !",
				"וcoutez, "+ GetSexPhrase("l'ami", "ma petite") +", vous me fatiguez ! Disparaissez de ma vue tant que vous êtes en vie !");
			Link.l1 = "Oui, je m'en vais.";
			Link.l1.go = "Exit";
			Link.l2 = "Je me suis dit que ce serait injuste. Tiens, j'ai décidé de rééquilibrer les comptes...";
			Link.l2.go = "Exit_Fight";
		break;

		case "GetLost":
			Diag.TempNode = "GetLost";
			dialog.text = LinkRandPhrase("Qu'est-ce que tu veux ? On était d'accord que tu partais !",
				"Laissez-moi tranquille, "+ GetSexPhrase("le gars", "la fille") +". J'ai mes affaires, vous avez les vכtres, inutile de prolonger les présentations !",
				"Va-t'en, "+ GetSexPhrase("l'ami", "ma petite") +" ! Bon sang, tu tiens vraiment à donner ton argent, finalement ?");
			Link.l1 = "Oui, je m'en vais.";
			Link.l1.go = "Exit";
			Link.l2 = "Il me revient que tu ne m'as pas dit au revoir ! Alors vas-y... Fais tes adieux !";
			Link.l2.go = "Exit_Fight";
		break;
        //#20200315-01
        case "CitizenNotBlade":
            npchar.chr_ai.type.checkFight = 999999.0;
            Diag.TempNode = "GetTheHellOut";
			dialog.text = LinkRandPhrase("J'ai décidé de te punir pour tes méfaits !",
				"Laisse-moi ! Va-t'en ! Je veux vivre !",
				"Au secours ! "+ GetSexPhrase("C'est un fou furieux", "C'est une folle furieuse") +" ! Ne me tuez pas !");
			Link.l1 = "Pitié ! Je ne suis qu'un pauvre brigand ! Je suis trop jeune pour mourir !";
			Link.l1.go = "Exit";
        break;
		case "GetTheHellOut":
			Diag.TempNode = "GetTheHellOut";
			dialog.text = LinkRandPhrase("Laisse-moi ! Va-t'en ! Je veux vivre !",
				"Au secours ! "+ GetSexPhrase("C'est un fou furieux", "C'est une folle furieuse") +" ! Ne me tuez pas !",
				"Pitié ! Je ne suis qu'un pauvre brigand ! Je suis trop jeune pour mourir !");
			Link.l1 = LinkRandPhrase(LinkRandPhrase("Si j'étais resté chez moi, j'aurais vécu plus longtemps !",
				"Tu aurais dמ y penser avant !",
				"Tu savais ce que tu faisais !"),
				"דa devait arriver tכt ou tard.",
				"Trop tard pour te repentir, défends-toi !");
			Link.l1.go = "exit_Fight";
		break;
	}
}
