# -*- coding: utf-8 -*-
"""Shows the code context of the fragment units of the current batch.

For every unit of work/batch_map.json that looks like a fragment (edge space,
no final punctuation, SEXE pair...), prints the statement of the English
source where it first appears.  Literals of the statement are shown as:
  [[id]]   the unit itself / another unit of this batch
  «fr»     already translated (French from the TM)
  "en"     untranslated English literal
Each statement is printed once.

usage: python -X utf8 ctx.py [maxlen]
"""
import json
import os
import re
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(BASE, '..', '..'))
WORK = os.path.join(BASE, '..', 'work')
TM = os.path.join(BASE, '..', 'tm', 'dialogs.json')
SRC = os.path.join(ROOT, 'Program', 'DIALOGS', 'english')

LIT_RE = re.compile(r'"((?:[^"\\\n]|\\.)*)"')
SEXE_RE = re.compile(r'(?:NPC)?(?:Char)?SexPhrase\s*\(\s*(?:[A-Za-z_][\w\.\[\]]*\s*,\s*)?"((?:[^"\\]|\\.)*)"\s*,\s*"((?:[^"\\]|\\.)*)"\s*\)')


def is_fragment(k):
    if k.startswith('⚥'):
        return True
    if not k:
        return False
    if k[0] in ' ,.;:!?\'' or k[-1] in ' ,\'':
        return True
    if k[-1] not in '.!?…")*]>':
        return True
    return False


def statement(src, pos):
    i = pos
    in_str = False
    while i > 0:
        c = src[i - 1]
        if c == '"':
            in_str = not in_str
        elif not in_str and c in ';{}':
            break
        i -= 1
    j = pos
    in_str = False
    while j < len(src):
        c = src[j]
        if c == '"':
            in_str = not in_str
        elif not in_str and c == ';':
            break
        j += 1
    return i, j


def main():
    maxlen = int(sys.argv[1]) if len(sys.argv) > 1 else 420
    mp = json.load(open(os.path.join(WORK, 'batch_map.json'), encoding='utf-8'))
    tm = json.load(open(TM, encoding='utf-8'))
    by_key = {}
    for uid, (dom, f, k) in mp.items():
        by_key.setdefault((f, k), uid)
    cache = {}
    seen = set()
    for uid in sorted(mp, key=lambda x: int(x)):
        dom, f, k = mp[uid]
        if dom != 'dialogs' or not is_fragment(k):
            continue
        p = os.path.join(SRC, f.replace('/', os.sep))
        if p not in cache:
            try:
                cache[p] = open(p, 'rb').read().decode('utf-8', 'replace')
            except OSError:
                cache[p] = ''
        src = cache[p]
        if k.startswith('⚥'):
            a, b = k[1:].split('|', 1)
            m = None
            for mm in SEXE_RE.finditer(src):
                if mm.group(1) == a and mm.group(2) == b:
                    m = mm
                    break
            pos = m.start() if m else -1
        else:
            pos = src.find('"' + k + '"')
        if pos < 0:
            print('%s\t(?) %r' % (uid, k[:80]))
            continue
        s, e = statement(src, pos)
        if (p, s) in seen:
            continue
        seen.add((p, s))
        st = src[s:e]
        # SEXE pairs first
        def sexe_sub(mm):
            kk = '⚥%s|%s' % (mm.group(1), mm.group(2))
            if (f, kk) in by_key:
                return '[[%s]]' % by_key[(f, kk)]
            if kk in tm:
                return '«%s»' % tm[kk]
            return 'SEXE("%s"|"%s")' % (mm.group(1), mm.group(2))
        st = SEXE_RE.sub(sexe_sub, st)

        def lit_sub(mm):
            v = mm.group(1)
            if (f, v) in by_key:
                return '[[%s]]' % by_key[(f, v)]
            if v in tm:
                return '«%s»' % tm[v]
            return '"%s"' % v
        st = LIT_RE.sub(lit_sub, st)
        st = re.sub(r'\s+', ' ', st).strip()
        st = re.sub(r'GetStrSmallRegister\(XI_ConvertString\(GetBaseShipParamFromType\([^)]*\)\s*,\s*"Name"\)\s*(\+\s*"\w+")?\)\)', 'SHIPTYPE', st)
        st = st.replace('pchar.GenQuest.', 'GQ.').replace('PChar.GenQuest.', 'GQ.')
        if len(st) > maxlen:
            # keep the part around the unit marker
            mk = st.find('[[%s]]' % uid)
            a = max(0, mk - maxlen // 2)
            st = ('…' if a else '') + st[a:a + maxlen] + '…'
        print('%s\t%s' % (uid, st))


if __name__ == '__main__':
    main()
