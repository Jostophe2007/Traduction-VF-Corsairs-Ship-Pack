// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Demandez, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.BlueBird == "toPuertoPrincipe")
			{
				link.l1 = "John, je viens vous voir au sujet de Pascal Voisier.";
				link.l1.go = "BlueBird_1";
			}
		break;
		case "BlueBird_1":
			if (isBadReputation(pchar, 10))
			{
				dialog.text = NPCStringReactionRepeat("Je ne parlerai pas de Pascal avec quelqu'un qui a votre réputation. Je veux bien commercer avec vous, rien de plus.",
					"Je vous ai déjà tout dit.",
					"Nous avons déjà parlé de ce sujet.",
					"Je n'ai rien à ajouter à ce qui a été dit.", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Mais j'ai vraiment besoin de vous parler, essayez de comprendre...",
					"Hum...",
					"Oui, c'est vrai...",
					"Je vois...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("BlueBird_close", "", "", "", npchar, Dialog.CurrentNode);
			}
			else
			{
				dialog.text = "Hum, je ne sais même pas quoi dire... Et de quelle affaire s'agit-il ?";
				link.l1 = "Eh bien... Voilà, bon sang, maintenant je ne sais plus quoi dire.";
				link.l1.go = "BlueBird_2";
			}
		break;

		case "BlueBird_close":
			dialog.text = "Pensez plutכt à votre réputation... Je n'ai rien de plus à vous dire.";
			link.l1 = "Hé !..";
			link.l1.go = "exit";
		break;

		case "BlueBird_2":
			dialog.text = "Commencez par l'essentiel.";
			link.l1 = "C'est ce que je vais faire, je crois. Je soupçonne Pascal Voisier de ne pas être un simple marchand. On m'a dit que vous étiez, comment dire, ennemis. C'est pour ça que je suis ici : je veux en savoir le plus possible sur cet homme.";
			link.l1.go = "BlueBird_3";
		break;
		case "BlueBird_3":
			dialog.text = "Ha ! Quelqu'un dans les Caraïbes aurait-il enfin ouvert les yeux ? "+ GetSexPhrase("Mon ami", "Ma fille") +", Pascal Voisier n'est vraiment pas un simple marchand. C'est une vraie canaille, mais il sait faire les choses en douce, alors il s'en tire toujours...";
			link.l1 = "De quoi s'agit-il ? De quoi s'en tire-t-il ?";
			link.l1.go = "BlueBird_4";
		break;
		case "BlueBird_4":
			dialog.text = "Commençons par la façon dont ce salaud m'a pris mon magasin. Il m'a privé de marchandises : même les pirates d'ici ne me vendaient plus rien, il leur achetait tout !";
			link.l1 = "Eh bien, il a une poigne de loup !";
			link.l1.go = "BlueBird_5";
		break;
		case "BlueBird_5":
			dialog.text = "De chacal, voilà le mot juste ! Et imaginez-vous que tout le monde du négoce des Caraïbes le tient pour un homme respectable ! Moi, je pense que tous les malheurs des marchands sont son œuvre.";
			link.l1 = "Vous croyez ?";
			link.l1.go = "BlueBird_6";
		break;
		case "BlueBird_6":
			dialog.text = "J'en suis sמr. Mais personne ne m'écoute, tout le monde croit que je lui en veux pour l'affaire perdue aux Bermudes. Il y a de ça, bien sמr, mais pas à ce point ! Ensuite, j'ai cessé de dire quoi que ce soit : de bonnes âmes m'ont fait comprendre que je ferais mieux de me calmer...";
			link.l1 = "Oh... Vous savez, je cherche en ce moment le chébec Oiseau bleu. C'est ce navire qui pille les bâtiments des marchands.";
			link.l1.go = "BlueBird_7";
		break;
		case "BlueBird_7":
			dialog.text = "Je pense que ce chébec agit au minimum sur les tuyaux de ce salaud de Pascal. Et il se peut très bien que ce soit carrément son navire. Voyez un peu quel homme rusé : il dépouille les marchands, puis il leur prête leur propre argent !";
			link.l1 = "Oh, les mots me manquent... וcoutez, comment puis-je attraper ce chébec ?";
			link.l1.go = "BlueBird_8";
		break;
		case "BlueBird_8":
			dialog.text = "Je ne sais pas... Mais voici ce que je vous conseille. Réfléchissez à la façon dont il fait venir les marchandises dans son magasin. Son chébec ne doit guère accoster au port.";
			link.l1 = "Il n'y accoste pas, c'est certain, je me suis renseigné.";
			link.l1.go = "BlueBird_9";
		break;
		case "BlueBird_9":
			dialog.text = "Eh bien, alors mon raisonnement est juste... Vous savez, aux Bermudes, il y a un passage souterrain qui mène du chantier naval directement à la baie. Bref, suivez la moindre piste, "+ GetSexPhrase("l'ami", "ma petite") +". Que la force soit avec vous !";
			link.l1 = "Merci, vous m'avez beaucoup aidé !";
			link.l1.go = "exit";
			pchar.questTemp.BlueBird = "toSeekBermudes";
			AddQuestRecord("Xebeca_BlueBird", "4");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);
}

