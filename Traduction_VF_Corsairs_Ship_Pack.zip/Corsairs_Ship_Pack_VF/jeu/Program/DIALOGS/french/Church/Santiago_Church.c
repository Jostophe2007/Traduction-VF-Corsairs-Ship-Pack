// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils", "ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils", "ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Inquisition_toDeSouza")
            {
                link.l1 = "Mon père, dites-moi, oם puis-je trouver le señor Antonio de Souza ?";
                link.l1.go = "Step_S2_1";
            }
			if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
            {
                link.l1 = "Mon père, dites-moi, oם se trouve l'Inquisition ici ?";
                link.l1.go = "Step_F7_1";
            }
		break;
        case "Step_S2_1":
			dialog.text = NPCStringReactionRepeat("Savez-vous, "+ GetSexPhrase("mon fils", "ma fille") +", qui est cet homme ?", ""+ GetSexPhrase("Mon fils", "Ma fille") +", je vous ai déjà tout dit.", "Vous me reposez la même question ? Je vous ai déjà répondu...", "Encore ? Bon, l'entrée de l'Inquisition se trouve juste sous l'escalier qui mène à l'église...",  "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Bien sמr, c'est un inquisiteur de haut rang.", "Pardon, padre, je ne comprends pas bien... Bon...", "Oui, mais je n'ai pas compris... Hum, pardon, padre...", "Euh, merci, padre...", npchar, Dialog.CurrentNode);
			link.l1.go = "Step_S2_2";
		break;
        case "Step_S2_2":
			dialog.text = "C'est vrai... Eh bien, il se trouve à sa résidence.";
			link.l1 = "Excusez-moi, padre, mais oם est-elle, la résidence de l'Inquisition ?";
			link.l1.go = "Step_S2_3";
		break;
        case "Step_S2_3":
			dialog.text = "Juste sous l'église.";
			link.l1 = "Comment ça ?";
			link.l1.go = "Step_S2_4";
		break;
        case "Step_S2_4":
			dialog.text = "Comme ça... Allez, "+ GetSexPhrase("mon fils", "ma fille") +", allez. Rares sont ceux qui se rendent de leur plein gré à la Sainte Inquisition...";
			link.l1 = "Ah, bon...";
			link.l1.go = "exit";
		break;

        case "Step_F7_1":
			dialog.text = NPCStringReactionRepeat("Juste sous l'église, "+ GetSexPhrase("mon fils", "ma fille") +".", "Juste sous notre église, "+ GetSexPhrase("mon fils", "ma fille") +". L'entrée est sous l'escalier.", "Vous êtes complètement "+ GetSexPhrase("dur d'oreille, mon fils", "dure d'oreille, ma fille") +". Oh, il faudrait vous soigner...",
                          "Humilité...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, padre.", "Merci encore, padre.",
                      "Absolument !", "Quoi ?", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

