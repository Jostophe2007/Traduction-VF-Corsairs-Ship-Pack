// Gregg: a rival agent - intercepting the GWIC "hot parcel" on the town streets.
// Spawned when the player enters the office's town (GWIK_MailAgentArrive), walks up to the PC.
// Style - conspiratorial, low-voiced, unlike the prim office manager.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int i;
	int cash;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (!CheckAttribute(pchar, "GWIK.Job") || pchar.GWIK.Job != "mail" || !CheckAttribute(pchar, "GWIK.Job.Hot") || CheckAttribute(pchar, "GWIK.Job.HotResolved"))
			{
				dialog.text = "Je me suis trompé. Passez votre chemin.";
				link.l1 = "...";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Ne vous retournez pas brusquement, capitaine, écoutez simplement. Ce paquet scellé qu'on vous a glissé au comptoir vaut bien plus que le salaire d'un coursier. Je le paierai bien, ou du moins pour laisser mon commis en faire une copie. Si vous rechignez, eh bien, c'est votre enterrement, mais ne venez pas pleurer après.";
			// Gregg: we missed each other - he walked out of town mid-approach. The agent brings it up (counter kept by GWIK_MailAgentLeft)
			if (CheckAttribute(pchar, "GWIK.Job.HotDodge")) dialog.text = "Vous avez le pied leste, capitaine. La dernière fois, vous avez filé avant que j'aie fini : vous pensiez que j'allais perdre tout intérêt ? Même discours : ce paquet scellé du comptoir vaut plus que le salaire d'un coursier. Un bon prix, ou au moins une copie. Et sinon, vous savez comment ça se passe.";
			link.l1 = "Quel est votre prix pour le paquet ?";
			link.l1.go = "sell";
			link.l2 = "Une copie, alors, mais le paquet reste avec moi.";
			link.l2.go = "copy";
			link.l3 = "Bas les pattes, ce sont des papiers de la Compagnie.";
			link.l3.go = "refuse";
		break;

		case "sell": // sell the parcel - assignment failed, a bribe, reputation loss
			cash = makeint(sti(pchar.GWIK.Job.Pay) * 2);
			AddMoneyToCharacter(pchar, cash);
			GWIK_AddRep(-15);
			AddQuestRecord("GWIK_MailJob", "5");
			AddQuestUserData("GWIK_MailJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_MailJob");
			pchar.GWIK.Job.HotResolved = true;
			DeleteAttribute(pchar, "GWIK.Job");
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Raisonnable. Voici votre or, "+ FindRussianMoneyString(cash) +", et nous ne nous sommes jamais vus. Je m'occupe du paquet moi-même. Au plaisir, capitaine.";
			link.l1 = "C'est fait.";
			link.l1.go = "exit";
		break;

		case "copy": // let him copy it - intel (archipelago price list), reputation loss, you still deliver the parcel
			for (i = 0; i < MAX_COLONIES; i++)
			{
				ref rcolony = &Colonies[i];
				if (rcolony.id != "Caiman" && rcolony.id != "Panama" && rcolony.nation != "none") SetPriceListByStoreMan(rcolony);
			}
			PlayStereoSound("notebook");
			GWIK_AddRep(-5);
			AddQuestRecord("GWIK_MailJob", "6");
			pchar.GWIK.Job.HotResolved = true;
			dialog.text = "Voilà une bonne affaire. Pendant que le commis le recopie, jetez-y un œil vous-même : les prix les plus frais de tout l'archipel, ils vous seront utiles. Le paquet est à vous, continuez votre route. Ce fut un plaisir.";
			link.l1 = "Intéressant. Adieu.";
			link.l1.go = "exit";
		break;

		case "refuse": // Gregg: refusing is no longer free - the agent whistles up his men and demands the packet by force
			dialog.text = "Mauvais choix, capitaine. דa, c'était la demande polie... (il siffle brièvement, et des hommes armés de couteaux sortent nonchalamment des ruelles) Le paquet. Ici. Ou on le prend sur votre cadavre : pour nous, c'est pareil.";
			link.l1 = "Prenez-le. Les papiers d'un autre ne valent pas mon sang.";
			link.l1.go = "hand_over";
			link.l2 = "Venez donc le prendre.";
			link.l2.go = "GWIK_MailFight";
		break;

		case "hand_over": // handed over under threat - packet lost, no money, reputation down
			pchar.GWIK.Job.HotResolved = true;
			GWIK_AddRep(-10);
			AddQuestRecord("GWIK_MailJob", "7");
			CloseQuestHeader("GWIK_MailJob");
			DeleteAttribute(pchar, "GWIK.Job");
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Raisonnable. (le paquet disparaît dans son manteau) Passez votre chemin, capitaine. Et à votre place, je n'irais pas me plaindre aux Hollandais : ça vous coמterait plus cher.";
			link.l1 = "...";
			link.l1.go = "exit";
		break;

		case "GWIK_MailFight": // Gregg: the brawl. Backup is 1 + the player's officers; no leaving the location until the whole gang is dead (GWIK_MailAgentFightStart)
			pchar.GWIK.Job.HotResolved = true;
			AddDialogExitQuestFunction("GWIK_MailAgentFightStart"); // the fight starts AFTER the dialog closes
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit":
			GWIK_MailAgentDismiss(NPChar); // the agent leaves (as an actor, BEFORE DialogExit - otherwise "Invalid function call")
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
