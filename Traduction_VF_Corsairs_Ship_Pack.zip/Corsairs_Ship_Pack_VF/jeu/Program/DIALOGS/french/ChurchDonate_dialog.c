// Диалог жертвователя (церковный квест №2 "Сбор пожертвований на храм")
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sTitle;
	int iBase;

	switch(Dialog.CurrentNode)
	{
		case "ChurchDonate_Donor_Start":
			// донор лишь здоровается - деньги даст, только когда ГГ попросит
			if (rand(1) == 0)
			{
				dialog.text = "Que puis-je pour vous, "+ GetSexPhrase("monsieur","madame") +" ?";
			}
			else
			{
				dialog.text = "Vous vouliez quelque chose ?";
			}
			link.l1 = "Le révérend père fait une quête pour restaurer l'église. Auriez-vous une pièce à donner ?";
			link.l1.go = "ChurchDonate_Donor_Ask";
			link.l2 = "Une personne de votre condition ne refusera sמrement pas un don généreux à la paroisse.";
			link.l2.go = "ChurchDonate_Donor_Persuade";
			link.l3 = "Pardonnez mon intrusion.";
			link.l3.go = "exit";
		break;

		case "ChurchDonate_Donor_Ask":
			iBase = 300 + rand(500) + sti(pchar.rank) * 100;
			if (sti(PChar.reputation) > REPUTATION_NEUTRAL) iBase = iBase + 200 + rand(300);
			PChar.GenQuest.ChurchDonate.PendingGift = iBase;
			dialog.text = "Pour l'église, c'est une œuvre pieuse. Tenez, je vous le donne de bon cœur.";
			link.l1 = "Merci. Le Seigneur récompensera votre générosité.";
			link.l1.go = "ChurchDonate_Donor_Give";
		break;

		case "ChurchDonate_Donor_Persuade":
			iBase = 300 + rand(500) + sti(pchar.rank) * 100;
			if (sti(PChar.reputation) > REPUTATION_NEUTRAL) iBase = iBase + 200 + rand(300);
			if (rand(100) < 20 + sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)))
			{
				PChar.GenQuest.ChurchDonate.PendingGift = iBase + makeint(iBase/2); // уговорил - щедрее
				dialog.text = "Vous savez, c'est vrai qu'il ne faut pas être avare quand il s'agit de l'œuvre du Seigneur ! Soit, tenez, ça ne me manquera pas.";
			}
			else
			{
				PChar.GenQuest.ChurchDonate.PendingGift = iBase - makeint(iBase/5); // не убедил - даёт меньше, с обидой
				dialog.text = "Hmph, je connais mon devoir envers Dieu sans que vous ayez à me le rappeler. Je donnerai ce que je peux : tenez.";
			}
			link.l1 = "Merci. Le Seigneur récompensera votre générosité.";
			link.l1.go = "ChurchDonate_Donor_Give";
		break;

		case "ChurchDonate_Donor_Give":
			DialogExit();
			NextDiag.CurrentNode = "ChurchDonate_Donor_Done"; // на повторный клик - валидный узел с выходом
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchDonate.PendingGift)); // деньги реально передаются ГГ
			PChar.GenQuest.ChurchDonate.Collected = sti(PChar.GenQuest.ChurchDonate.Collected) + sti(PChar.GenQuest.ChurchDonate.PendingGift);
			PChar.GenQuest.ChurchDonate.DonorsDone = sti(PChar.GenQuest.ChurchDonate.DonorsDone) + 1;
			characters[GetCharacterIndex(NPChar.id)].LifeDay = 0; // жертвователь уходит
			if (sti(PChar.GenQuest.ChurchDonate.DonorsDone) >= sti(PChar.GenQuest.ChurchDonate.DonorsTotal))
			{
				DeleteAttribute(PChar, "GenQuest.ChurchDonate.DonorsInTown");
				sTitle = PChar.GenQuest.ChurchDonate.QuestTown + "ChurchDonate";
				AddQuestRecordEx(sTitle, "ChurchDonate", "2"); AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
				AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchDonate.QuestTown + "Gen"));
			}
		break;

		case "ChurchDonate_Donor_Done":
			dialog.text = "J'ai déjà apporté mon obole pour l'église. Bonne journée à vous.";
			link.l1 = "Bonne journée à vous aussi.";
			link.l1.go = "exit";
		break;

		case "exit":
			DialogExit();
		break;
	}
}
