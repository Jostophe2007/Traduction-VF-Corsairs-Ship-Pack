
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//------------------------ Мешитли ------------------------
		case "AztecFT":
			dialog.text = "Oh, l'homme blanc est revenu chez nous ? "+ GetSexPhrase("", "Une femme ? ") +" Je t'ai vu passer par la digue.";
			link.l1 = "Salut à l'indigène ! Je m'appelle capitaine " + GetFullName(pchar) + ". Comment vous appelez-vous ?";
			link.l1.go = "AztecFT_1";
		break;
		case "AztecFT_1":
			dialog.text = "Meshitli.";
			link.l1 = "Tu vis ici, Meshitli ? Qui d'autre y a-t-il ici à part toi ?";
			link.l1.go = "AztecFT_2";
		break;
		case "AztecFT_2":
			dialog.text = "Mon frère Auisotl.";
			link.l1 = "Héhé, oui, je vois que tu es un Aztèque tout à fait normal. J'ai honte de le dire, mais un Indien peinturluré et accoutré m'a raconté de ces choses ! Il y a un homme qui se tient sur la rive, Montezuma, il s'appelle...";
			link.l1.go = "AztecFT_3";
		break;
		case "AztecFT_3":
			dialog.text = "Silence ! C'est celui dont on ne parle pas ici ! Si tu te promènes dans Tenochtitlan en parlant de celui dont on ne peut prononcer le nom, Mictlantecuhtli se fâchera et fera de toi son serviteur avant l'heure !";
			link.l1 = "Mict... Miktla... Oh, je n'arrive pas à le prononcer ! Bref, c'est votre dieu qui ressuscite les morts ?";
			link.l1.go = "AztecFT_4";
		break;
		case "AztecFT_4":
			dialog.text = "C'est lui. Et je te conseille de le traiter avec respect. Et le mieux, c'est de lui offrir un sacrifice.";
			link.l1 = "Quel sacrifice ?";
			link.l1.go = "AztecFT_5";
		break;
		case "AztecFT_5":
			dialog.text = "Comme d'habitude, le sang des guerriers que tu as capturés. Amène-les ici, puis va avec eux au temple des sacrifices. Tu dois arracher le cœur du guerrier tant qu'il est encore vivant, et asperger de sang la pierre sacrificielle de Mictlantecuhtli.";
			link.l1 = "Je n'en ai pas vraiment envie...";
			link.l1.go = "AztecFT_6";
		break;
		case "AztecFT_6":
			dialog.text = "Ah, eh bien, alors bonne chance pour ne pas le voir ici. Mictlantecuhtli veillera sur toi et te prendra.";
			link.l1 = "Eh bien, on verra... Combien de guerriers sacrifiez-vous ? J'ai entendu dire que vous aviez beaucoup de dieux...";
			link.l1.go = "AztecFT_7";
		break;
		case "AztecFT_7":
			dialog.text = "Il y en avait beaucoup, mais maintenant, nous ne servons plus que Mictlantecuhtli. Mon frère et moi ne capturons pas de guerriers et ne faisons pas de sacrifices, car Mictlantecuhtli nous a promis sa protection et la vie après la mort. Alors, nous faisons de petits travaux dans la ville, nous ne gardons même pas d'armes.";
			link.l1 = "Tu as vraiment parlé à Mictlantecuhtli comme à une personne ? Héhé, vous étiez des sauvages, et vous l'êtes restés. Le dandy sur la rive dont on ne prononce pas le nom, toi et ton frère ici... Voilà comme je crois à votre Mictlantecuhtli. Dis-moi plutכt ce qu'il y a d'intéressant dans votre Tenochtitlan.";
			link.l1.go = "AztecFT_8";
		break;
		case "AztecFT_8":
			dialog.text = "Rien de spécial. Le temple de la Grande Force de Vie est le plus grand édifice. Dans les pyramides de chaque cכté se trouvent les temples de 10 dieux. Le temple des Dieux Blancs est une pyramide avec une tour ronde, juste devant le temple de la Grande Force de Vie. Le lieu des bains...";
			link.l1 = "Dis-moi, comment pourrais-je entrer dans ce Grand Temple ?";
			link.l1.go = "AztecFT_9";
		break;
		case "AztecFT_9":
			dialog.text = "Tu ne devrais pas. Mon frère et moi ne t'en empêcherons pas, mais Mictlantecuhtli peut facilement envoyer ses guerriers à tes trousses. Sans parler des temples, gardés par ses serviteurs, les grands guerriers du passé.";
			link.l1 = "Compris... Bon, porte-toi bien, Meshitli. Je reparlerai à ton frère à l'occasion.";
			link.l1.go = "AztecFT_10";
		break;
		case "AztecFT_10":
			dialog.text = "Il sera très content. Il ne reste plus personne de vivant à Tenochtitlan à part nous, alors les étrangers nous intéressent."+ GetSexPhrase("", " Surtout quand elles sont si belles.") +"";
			link.l1 = ""+ GetSexPhrase("Hum, je vois.", "דa alors, tu sais aussi faire des compliments !") +"";
			link.l1.go = "AztecFT_11";
		break;
		case "AztecFT_11":
			LAi_SetImmortal(sld, false);
			LAi_SetCitizenType(npchar);
			NextDiag.TempNode = "Aztec1";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Aztec1":
			dialog.text = "Mes salutations, "+ GetSexPhrase("capitaine", "belle squaw") +" " + GetFullName(pchar) + ".";
			link.l1 = "Salut à toi aussi, Meshitli";
			link.l1.go = "exit";
		break;

		case "Aztec1AF":
			dialog.text = ""+ GetSexPhrase("Le capitaine blanc est allé", "La belle squaw est allée") +" au temple de la Grande Force de Vie et a survécu ? Je suis très surpris...";
			link.l1 = "Tu ne pensais pas me revoir en vie ?";
			link.l1.go = "Aztec1AF_1";
		break;
		case "Aztec1AF_1":
			dialog.text = "Non. Mon frère et moi avions parié sur le moment oם Mictlantecuhtli te prendrait. Personne n'a gagné : tu es en vie.";
			link.l1 = "J'ai parlé à votre Mictlantecuhtli. Très instructif.";
			link.l1.go = "Aztec1AF_2";
		break;
		case "Aztec1AF_2":
			dialog.text = "Tu as de la chance, "+ GetSexPhrase("capitaine blanc", "belle squaw") +". Mictlantecuhtli lui-même t'a parlé et t'a laissé partir !";
			link.l1 = "Il m'a aussi donné un crâne de jade.";
			link.l1.go = "Aztec1AF_3";
		break;
		case "Aztec1AF_3":
			dialog.text = "Ce crâne a du pouvoir sur les morts, sache-le ! Tu as beaucoup de chance, "+ GetSexPhrase("capitaine blanc", "belle squaw") +".";
			link.l1 = "Je sais. Bon, allez, Meshitli.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Aztec1";
		break;


		//------------------------ Ауисотль ------------------------
		case "AztecFT2":
			dialog.text = "Oh, un homme blanc à Tenochtitlan ! "+ GetSexPhrase("", "Et une si belle squaw ! ") +"Très intéressant...";
			link.l1 = "Salut, l'Aztèque. Si je comprends bien, tu t'appelles Auisotl.";
			link.l1.go = "AztecFT2_1";
		break;

		case "AztecFT2_1":
			dialog.text = "Oui, c'est ça. Et toi, qui es-tu ?";
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ". C'est un plaisir de rencontrer, pour ainsi dire, un habitant du coin. Nous avons déjà parlé avec ton frère, Meshitli.";
			link.l1.go = "AztecFT2_2";
		break;
		case "AztecFT2_2":
			dialog.text = "C'est bien. Dis-moi, "+ GetSexPhrase("capitaine blanc", "belle squaw") +", que veux-tu dans notre ville ?";
			link.l1 = "Je cherche quelque chose. Dis-moi, tu sais comment entrer dans le temple de la Grande Force de Vie ? Et il faut aussi que j'aille au temple des Dieux Blancs...";
			link.l1.go = "AztecFT2_3";
		break;
		case "AztecFT2_3":
			dialog.text = "Tu as perdu la raison, "+ GetSexPhrase("capitaine blanc", "belle squaw") +" ? Mictlantecuhtli dévorera ton corps et ton âme !";
			link.l1 = "Je n'ai pas peur. Si tu sais quelque chose, dis-le-moi.";
			link.l1.go = "AztecFT2_4";
		break;
		case "AztecFT2_4":
			dialog.text = "Tu es "+ GetSexPhrase("un homme stupide, capitaine blanc", "très belle, squaw blanche, mais aussi très stupide") +". Tu devrais aller parier avec mon frère sur le temps qu'il te reste à vivre...";
			link.l1 = "C'est tout ce que tu as à dire ?";
			link.l1.go = "AztecFT2_5";
		break;
		case "AztecFT2_5":
			dialog.text = "Mon frère et moi sommes les serviteurs du grand Mictlantecuhtli, que voulais-tu entendre de nous ? Tu me plais"+ GetSexPhrase(", capitaine blanc, même si tu es stupide", ", squaw blanche, même si tu es stupide") +". Et je vais te dire que l'on peut accéder au temple de la Grande Force de Vie pas seulement par l'entrée au sommet de la pyramide...";
			link.l1 = "Eh bien, merci pour ça, Auisotl.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Aztec2";
		break;

		case "Aztec2":
			dialog.text = "Tu es encore "+ GetSexPhrase("en vie, capitaine blanc ", "en vie, belle squaw ") +" ?";
			link.l1 = "Comme tu vois, Auisotl.";
			link.l1.go = "exit";
		break;

		case "Aztec2AF":
			dialog.text = ""+ GetSexPhrase("Capitaine blanc, tu es allé", "Belle squaw, tu es allée") +" voir Mictlantecuhtli ?";
			link.l1 = "C'est fait.";
			link.l1.go = "Aztec2AF_1";
		break;
		case "Aztec2AF_1":
			dialog.text = "Et il n'a pas fait de toi son serviteur ?";
			link.l1 = "Non. Comme tu vois, je suis toujours en vie, Auisotl.";
			link.l1.go = "Aztec2AF_2";
		break;
		case "Aztec2AF_2":
			dialog.text = "Oh, tu dois être quelqu'un de grand si Mictlantecuhtli lui-même t'a laissé partir !";
			link.l1 = "Il m'a laissé partir, et il m'a même donné le crâne de jade !";
			link.l1.go = "Aztec2AF_3";
		break;
		case "Aztec2AF_3":
			dialog.text = "Le crâne de la Résurrection ?! Je n'arrive pas à y croire. Auisotl te souhaite bonne chance. Adieu, "+ GetSexPhrase("capitaine blanc", "belle squaw") +".";
			link.l1 = "Adieu, Auisotl.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Aztec2AF_4";
		break;

		case "Aztec2AF_4":
			dialog.text = "Mon frère et moi "+ GetSexPhrase("nous souviendrons de toi, capitaine blanc", "regretterons ton départ, belle squaw") +".";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
		break;
	}
}
