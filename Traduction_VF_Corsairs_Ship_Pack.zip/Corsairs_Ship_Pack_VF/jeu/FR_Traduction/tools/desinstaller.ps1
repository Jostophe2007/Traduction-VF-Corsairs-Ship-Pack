﻿# Désinstalle la version française de Corsairs Ship Pack installée par INSTALLER_VF.bat :
# restaure les fichiers d'origine sauvegardés, supprime les fichiers ajoutés, retire le lien des voix.
#   -GameDir <dossier>  dossier du jeu (par défaut : le dossier parent de FR_Traduction)
#   -Yes                ne demande pas de confirmation
#   -NoPause            ne demande pas d'appuyer sur Entrée à la fin
param([string]$GameDir = '', [switch]$Yes, [switch]$NoPause)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path          # ...\FR_Traduction\tools

function Wait-End {
    if (-not $NoPause) { Write-Host ''; Read-Host 'Appuyez sur Entrée pour fermer' | Out-Null }
}

try {
    if (-not $GameDir) { $GameDir = Split-Path -Parent (Split-Path -Parent $here) }
    $GameDir = (Resolve-Path -LiteralPath $GameDir).Path
    $frt = Join-Path $GameDir 'FR_Traduction'
    $bk = Join-Path $frt 'backup\avant_installation'
    $logPath = Join-Path $frt 'backup\installation.json'
    if (-not (Test-Path -LiteralPath $logPath)) {
        Write-Host "Aucune installation de la version française n'a été trouvée (FR_Traduction\backup\installation.json absent)." -ForegroundColor Yellow
        Wait-End; exit 1
    }
    $log = Get-Content -LiteralPath $logPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host "Dossier du jeu : $GameDir"
    if (-not $Yes) {
        $r = Read-Host "Désinstaller la version française et restaurer les fichiers d'origine ? (O/N)"
        if ($r -notmatch '^\s*[oOyY]') { Write-Host 'Rien n''a été modifié.'; Wait-End; exit 2 }
    }

    # 1. fichiers d'origine
    $nRest = 0
    foreach ($p in @($log.replaced)) {
        if (-not $p) { continue }
        $b = Join-Path $bk $p
        $t = Join-Path $GameDir $p
        if (Test-Path -LiteralPath $b) { Copy-Item -LiteralPath $b -Destination $t -Force; $nRest++ }
    }

    # 2. fichiers ajoutés (le dossier FR_Traduction reste, avec les sauvegardes)
    $nDel = 0
    $dirs = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($p in @($log.added)) {
        if (-not $p -or $p -like 'FR_Traduction\*') { continue }
        $t = Join-Path $GameDir $p
        if (Test-Path -LiteralPath $t) { Remove-Item -LiteralPath $t -Force; $nDel++ }
        [void]$dirs.Add((Split-Path -Parent $t))
    }
    foreach ($d in @($dirs | Sort-Object { $_.Length } -Descending)) {
        $cur = $d
        while ($cur -and $cur.Length -gt $GameDir.Length -and (Test-Path -LiteralPath $cur) -and
               -not (Get-ChildItem -LiteralPath $cur -Force | Select-Object -First 1)) {
            Remove-Item -LiteralPath $cur -Force
            $cur = Split-Path -Parent $cur
        }
    }

    # 3. lien des voix (supprime le lien seulement, jamais les voix anglaises)
    if ($log.junction) {
        $vf = Join-Path $GameDir 'RESOURCE\Sounds\Voice\French'
        $item = Get-Item -LiteralPath $vf -Force -ErrorAction SilentlyContinue
        if ($item -and ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) { [System.IO.Directory]::Delete($vf) }
    }

    Move-Item -LiteralPath $logPath -Destination (Join-Path $frt 'backup\installation_desinstallee.json') -Force
    Write-Host ''
    Write-Host ("Version française désinstallée : {0} fichiers d'origine restaurés, {1} fichiers supprimés." -f $nRest, $nDel) -ForegroundColor Green
    Write-Host 'Le dossier FR_Traduction (outils et sauvegardes) peut maintenant être supprimé à la main.'
    Wait-End
    exit 0
}
catch {
    $err = $_
    Write-Host ''
    Write-Host ("Erreur pendant la désinstallation : {0}" -f $err.Exception.Message) -ForegroundColor Red
    Wait-End
    exit 3
}
