
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;
	bool bOk;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Il n'y a rien à dire !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		// ==> глава поселения
		case "HeadMan":
			NextDiag.TempNode = "HeadMan";
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Bienvenue dans notre pêcherie. Je suis heureux de voir un sujet de " + NationNameGenitive(sti(npchar.nation)) + ". Puis-je connaître votre nom ?";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je suis capitaine de mon propre navire.";
				link.l1.go = "HeadMan_1";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = NPCStringReactionRepeat("Heureux de vous revoir chez moi. Vous venez pour affaires ?",
					"Encore vous ? Nous en avons déjà parlé, capitaine.",
					"Capitaine, vous avez besoin d'autre chose ?",
					"Capitaine, je vous prie de ne pas me distraire !", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Non, " + GetAddress_FormToNPC(NPChar) + ", je passais juste vous voir...",
					"Oui, bien sמr.",
					"Non, " + GetAddress_Form(NPChar) + "Pardon...",
					"D'accord...", npchar, Dialog.CurrentNode);
				link.l1.go = "exit";
			}
			//-------- жемчужный генератор Шарпа ------------
			if (pchar.questTemp.Sharp != "begin" && pchar.questTemp.Sharp != "over" && pchar.questTemp.Sharp.SeekSpy == "begin")
			{
				link.l2 = "Dites-moi, les pêcheurs de perles qui pêchent dans les Caraïbes sont-ils sous vos ordres ?";
				link.l2.go = "SharpSeekSpy";
			}
			if (pchar.questTemp.Sharp.SeekSpy == "alwaysKnow")
			{
				link.l2 = "Je viens chercher la récompense, señor.";
				link.l2.go = "SharpSeekSpy_10";
			}
		break;
		// <------- жемчужный генератор Шарпа
		case "SharpSeekSpy":
			dialog.text = "Sous les nכtres. Pourquoi cette question ?";
			link.l1 = "Ce doit être dur pour eux, avec une piraterie aussi débridée. Un certain capitaine Sharp est connu parmi les corsaires...";
			link.l1.go = "SharpSeekSpy_1";
		break;
		case "SharpSeekSpy_1":
			dialog.text = "Il est aussi connu des pêcheurs de perles, "+ GetSexPhrase("mon ami","ma chère") +". C'est un véritable fléau pour nous ! On dirait qu'il n'a rien d'autre à faire que de pourchasser nos tartanes ! Et je ne sais comment, ce scélérat découvre qui pêche oם.";
			link.l1 = "Oui, il en sait long sur les pêcheurs, c'est un fait...";
			link.l1.go = "SharpSeekSpy_2";
		break;
		case "SharpSeekSpy_2":
			dialog.text = "Nous prenons toutes les précautions, mais c'est inutile. Apparemment, quelqu'un l'informe de nos projets. וcoutez, vous n'avez pas lancé cette conversation par hasard. Vous savez quelque chose sur cette affaire.";
			link.l1 = "Seulement ce que je viens de dire. Tout le monde dans les Caraïbes connaît le capitaine Sharp...";
			link.l1.go = "SharpSeekSpy_3";
		break;
		case "SharpSeekSpy_3":
			dialog.text = "Je vois. Eh bien, je veux vous proposer un travail, puisque vous êtes au courant de nos malheurs.";
			link.l1 = "Quel genre de travail ? וliminer Sharp ?";
			link.l1.go = "SharpSeekSpy_4";
		break;
		case "SharpSeekSpy_4":
			dialog.text = "Non, ce serait trop facile. Et puis, ce serait inefficace. Après tout, le scélérat qui divulgue les informations sur nos zones de pêche trouvera simplement un autre « Sharp », et nos tartanes se feront de nouveau piller.";
			link.l1 = "C'est logique.";
			link.l1.go = "SharpSeekSpy_5";
		break;
		case "SharpSeekSpy_5":
			dialog.text = "Je veux que vous trouviez ce rat parmi nous.";
			link.l1 = "Compris. Maintenant, parlons de la rémunération...";
			link.l1.go = "SharpSeekSpy_6";
		break;
		case "SharpSeekSpy_6":
			dialog.text = "Hum, eh bien, parlons-en. Alors, je pourrais vous offrir des perles et de l'argent, mais je vais vous proposer quelque chose de plus intéressant pour vous, à mon avis. C'est un ensemble d'armes. Il comprend un pistolet breton, une rapière espagnole, un marteau de guerre de reître et une cuirasse d'officier ! Croyez-moi, la cuirasse à elle seule vaut une fortune !";
			link.l1 = "Héhé, comme tout cela est tentant...";
			link.l1.go = "SharpSeekSpy_7";
		break;
		case "SharpSeekSpy_7":
			dialog.text = "Et ajoutez-y le Dieu des rats que je vais vous donner tout de suite, en avance : acceptez !";
			link.l1 = "Sacrebleu ! Bien sמr que j'accepte !";
			link.l1.go = "SharpSeekSpy_8";
			link.l2 = "Non, je crois que je vais refuser.";
			link.l2.go = "SharpSeekSpy_8over";
		break;

		case "SharpSeekSpy_8":
			dialog.text = "Alors, j'attends de bonnes nouvelles de votre part, capitaine ! Vous pourrez faire votre rapport et recevoir la récompense promise auprès de n'importe lequel des anciens des deux villages de pêcheurs de perles, ils seront au courant de notre accord.";
			link.l1 = "Compris. Je commence les recherches immédiatement.";
			link.l1.go = "SharpSeekSpy_9";
		break;
		case "SharpSeekSpy_9":
			GiveItem2Character(pchar, "indian11");
			pchar.questTemp.Sharp.SeekSpy = "seekSpy";
            SetQuestHeader("SharpPearl_SeekSpy");
            AddQuestRecord("SharpPearl_SeekSpy", "1");
			AddQuestUserData("SharpPearl_SeekSpy", "sSex", GetSexPhrase("", "e"));
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "SharpSeekSpy_8over":
			dialog.text = "וtrange. Vous venez me voir, vous me parlez de Sharp, et puis vous refusez le travail. Tout cela est suspect, j'ai bien peur de ne pas pouvoir vous laisser partir.";
			link.l1 = "Quoi ?!..";
			link.l1.go = "SharpSeekSpy_8fight";
		break;
		case "SharpSeekSpy_8fight":
			pchar.questTemp.Sharp.SeekSpy = "over";
			LAi_group_Attack(npchar, pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "SharpSeekSpy_10":
			dialog.text = "Eh bien, je sais qui vous êtes. Alors, dites-moi ce que vous avez réussi à découvrir.";
			link.l1 = "J'ai trouvé la personne de chez vous qui renseignait Sharp sur vos tartanes. C'est Emilio Garcia.";
			link.l1.go = "SharpSeekSpy_11";
		break;
		case "SharpSeekSpy_11":
			dialog.text = "Vous pouvez le prouver ?";
			link.l1 = "Oui. J'ai réussi à le suivre et à le rattraper dans la grotte de la baie de San Juan del Norte, juste au moment de sa conversation avec l'homme de confiance de Sharp. Je les ai tués tous les deux.";
			link.l1.go = "SharpSeekSpy_12";
		break;
		case "SharpSeekSpy_12":
			dialog.text = "Je vois... Eh bien, je vous crois. Votre récompense pour le travail accompli est un ensemble d'équipement de combat. C'est bien ça ?";
			link.l1 = "Exactement, señor.";
			link.l1.go = "SharpSeekSpy_13";
		break;
		case "SharpSeekSpy_13":
			dialog.text = "Alors, prenez-le, je vous prie. Tout est à vous désormais.";
			link.l1 = "C'est un plaisir d'avoir pu vous être utile. Au revoir, señor.";
			link.l1.go = "exit";
			GiveItem2Character(pchar, "blade22");
			GiveItem2Character(pchar, "pistol5");
			GiveItem2Character(pchar, "cirass4");
			GiveItem2Character(pchar, "topor2");
			pchar.questTemp.Sharp.SeekSpy = "over";
            AddQuestRecord("SharpPearl_SeekSpy", "5");
			AddQuestUserData("SharpPearl_SeekSpy", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("SharpPearl_SeekSpy");

			//zagolski. битва в бухте
			pchar.quest.sharp_pre.win_condition.l1 = "location";
			if (pchar.curIslandId == "Beliz") pchar.quest.sharp_pre.win_condition.l1.location = "Shore9";
			else pchar.quest.sharp_pre.win_condition.l1.location = "Shore55";			
			pchar.quest.sharp_pre.function = "sharp_pre";

		break;
		// >------- жемчужный генератор Шарпа
		case "HeadMan_1":
			dialog.text = "Puis-je savoir ce que vous faites dans ce coin perdu ?";
			link.l1 = "J'explore les territoires, ces connaissances me seront peut-être utiles à l'avenir.";
			link.l1.go = "HeadMan_2";
		break;
		case "HeadMan_2":
			dialog.text = "Vous explorez, donc. Eh bien, parfait. Je veux vous mettre au courant de la situation actuelle.";
			link.l1 = "Je vous écoute attentivement.";
			link.l1.go = "HeadMan_3";
		break;
		case "HeadMan_3":
			dialog.text = "Les pêcheries de perles appartiennent actuellement à " + NationNameGenitive(sti(npchar.nation)) + ", donc personne ne peut acheter ni vendre de perles ici.";
			link.l1 = "Compris.";
			link.l1.go = "HeadMan_4";
		break;
		case "HeadMan_4":
			dialog.text = "Si vous essayez de forcer mes coffres, le châtiment vous frappera immédiatement.";
			link.l1 = "דa aussi, c'est compréhensible.";
			link.l1.go = "HeadMan_5";
		break;
		case "HeadMan_5":
			dialog.text = "Eh bien, c'est parfait. Veuillez accepter l'assurance de ma sincère sympathie, " + GetAddress_Form(NPChar) + ".";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;
		// ==> часовой у поселения
		case "GuardMan":
			NextDiag.TempNode = "GuardMan";
			dialog.text = NPCStringReactionRepeat("Bonjour ! Permettez-moi de me présenter, je m'appelle " + GetFullName(npchar) + ". Ma tâche est d'avertir le village de pêcheurs de perles d'une éventuelle attaque. Les pirates, vous savez... Et vous, qui êtes-vous ?",
				"Salutations encore !",
				"Je reste ici tout seul toute la journée, c'est ennuyeux, il n'y a personne à qui parler...",
                "Oh, bon sang, voilà une agréable distraction !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je m'appelle " + GetFullName(pchar) + ". Je suis capitaine, j'inspecte ces terres.",
				"Et moi aussi, vous me plaisez...",
                "Je comprends.",
				"Hé...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("GuardMan_1", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
		break;

		case "GuardMan_1":
			dialog.text = "Si vous êtes dans notre village, alors, bienvenue.";
			link.l1 = "Merci, l'ami.";
			link.l1.go = "GuardMan_2";
		break;
		case "GuardMan_2":
			chrDisableReloadToLocation = false;
			npchar.quest.TalkOk = true; //флаг разговор состоялся, все ОК.
			LAi_SetCitizenTypeNoGroup(npchar);
			DialogExit();
		break;

		case "GuardManAllarm":
			dialog.text = "Alerte !! C'est un pirate !!!";
			link.l1 = "Diable ! J'aurais dמ te tuer...";
			link.l1.go = "GuardManAllarm_1";
		break;
		case "GuardManAllarm_1":
			chrDisableReloadToLocation = false;
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			DialogExit();
		break;
		// ==> пиплы в поселении
		case "PearlMan":
			NextDiag.TempNode = "PearlMan";
			dialog.text = NPCStringReactionRepeat("Salutations ! Je m'appelle " + GetFullName(npchar) + ". Comment puis-je vous aider ?",
				"Salutations encore !",
				"Dans notre coin perdu, les visiteurs sont très rares...",
                "Eh, ça fait du bien de bavarder avec quelqu'un de nouveau ! Sinon, ces trognes me donnent déjà la nausée.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Rien de spécial...",
				"Et moi aussi, vous me plaisez...",
                "Je comprends.",
				"Hé...", npchar, Dialog.CurrentNode);
			link.l1.go = "PearlMan_1";
			if (pchar.questTemp.Sharp.SeekSpy == "seekSpy")
			{
				link.l2 = LinkRandPhrase("וcoute, ton chef m'a confié une tâche ici... Bref, tu sais si quelqu'un fréquente des pirates, par ici ?",
					"Tu sais, l'ami, qui a des liens avec les pirates, ici ?",
					"J'ai une question pour toi, mon ami. Qui as-tu remarqué ici en relation avec les pirates ?");
				link.l2.go = "PearlMan_Sharp_1";
			}
			if (CheckAttribute(pchar, "questTemp.Kuali_1") && PChar.location == "Pearl_town_2")
			{
				link.l2 = "L'ami, je cherche quelqu'un qui fréquentait les indigènes du coin, ceux de leur village.");
				link.l2.go = "Kuali_Poiski_1";
			}
		break;
		case "Kuali_Poiski_1":
			dialog.text = "Oui, nous les fréquentons tous, ils travaillent pour nous, ceux qui ont eu assez de jugeote pour ne pas se prendre pour de grands guerriers.";
			link.l1 = "Justement, l'un de ces guerriers m'a demandé de lui rapporter sa massue, elle doit avoir beaucoup de valeur pour lui. Pas en tant qu'arme : il aurait pu se fabriquer un nouveau bâton.";
			link.l1.go = "Kuali_Poiski_2";
		break;
		case "Kuali_Poiski_2":
			dialog.text = "Ah, c'est pour Perez que vous venez, mais vous arrivez trop tard, nous l'avons chassé.";
			link.l1 = "Il est parti de ces parages ?";
			link.l1.go = "Kuali_Poiski_3";
		break;
		case "Kuali_Poiski_3":
			dialog.text = "Peu probable : personne ne voudrait le prendre à bord d'un navire, j'avais même peur de l'approcher. Il faisait beaucoup d'affaires avec ces Indiens. Il a pris à l'un d'eux un objet de grande valeur. Vous l'avez bien compris : pour les gens du coin, ce n'est pas une simple massue. Et puis, il s'est vanté d'avoir séduit l'épouse de la tribu, vous imaginez ?";
			link.l1 = "Qui est l'épouse de la tribu ?";
			link.l1.go = "Kuali_Poiski_4";
		break;
		case "Kuali_Poiski_4":
			dialog.text = "Leur femme, vous l'avez sמrement vue si vous avez mis les pieds là-bas. Elle est couverte de plumes et de babioles. C'est l'épouse de tous les jeunes hommes, jusqu'à ce qu'ils trouvent une compagne digne d'eux. De merveilleuses traditions, qu'y peut-on.";
			link.l1 = "C'est une prostituée ?";
			link.l1.go = "Kuali_Poiski_5";
		break;
		case "Kuali_Poiski_5":
			dialog.text = "Non, non. Une épouse, tout simplement. On ne l'approche pas comme ça. Alors, on pensait que Perez mentait en disant qu'elle était comme ci et comme ça, et puis il s'est mis à se couvrir de croמtes comme un pestiféré et à pourrir vivant. Ses maris lui ont jeté un sort, il n'y a pas d'autre explication. Nous l'avons chassé. Le diable sait si l'infection ne va pas se répandre à tout le monde ; on n'approchait même plus son serviteur.";
			link.l1 = "Il a encore une maison ici ?";
			link.l1.go = "Kuali_Poiski_6";
		break;
		case "Kuali_Poiski_6":
			dialog.text = "Je ne vous conseille pas d'y aller. J'aimerais bien la brמler, mais le commandant a peur que le feu gagne son toit.";
			link.l1 = "Je vais essayer. L'Indien m'a promis une sorte de protection pour la vie, c'est peut-être un talisman contre ce genre de malheur.";
			link.l1.go = "Kuali_Poiski_7";
		break;
		case "Kuali_Poiski_7":
			dialog.text = "Héhé. Seulement, ne vous approchez plus de moi une fois que vous aurez mis les pieds là-bas.";
			link.l1 = "D'accord, je ne le ferai pas.";
			link.l1.go = "exit";
			
			DeleteAttribute(pchar, "questTemp.Kuali_1");
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.mineral6 = 15;
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.jewelry11 = 1;
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.jewelry12 = 10;
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.bullet = 8;
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.GunPowder = 8;
			pchar.GenQuestBox.PearlTown2_Hut1.box1.items.indian2 = 1;
			
			pchar.GenQuestRandItem.PearlTown2_Hut1.randitem1 = "Peres_Kluch";
			
			PChar.quest.Peres_Kluch.win_condition.l1 = "item";
			PChar.quest.Peres_Kluch.win_condition.l1.item = "Peres_Kluch";
			PChar.quest.Peres_Kluch.win_condition = "Peres_Kluch";
			AddQuestRecord("Kuali", "2");
		break;
		
		case "PearlMan_1":
			dialog.text = "Nous pêchons des perles, au service de " + NationNameGenitive(sti(npchar.nation)) + ", c'est tout...";
			link.l1 = "Oui, je suis au courant...";
			link.l1.go = "exit";
			link.l2 = "וcoute, est-ce qu'on peut acheter quelques-unes de ces babioles directement au producteur, pour ainsi dire, hein ?";
			link.l2.go = "PearlMan_2";
		break;
		case "PearlMan_2":
			if (rand(10) < 9)
			{
				dialog.text = "Non, pas question !!! Pour le vol ne serait-ce que d'une petite perle, c'est la mort !";
				link.l1 = "Héhé, les règles sont cruelles, ici...";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Chez nous, c'est du sérieux, on peut facilement y laisser sa tête. Moi, je ne fais pas ça, mais je peux vous conseiller de vous adresser aux Indiens du coin qui travaillent avec nous. Eux ont oם fuir en cas de pépin, ils seront plus audacieux que nous...";
				link.l1 = "Je vois, eh bien, merci.";
				link.l1.go = "exit";
			}
		break;
		case "PearlMan_Sharp_1":
			dialog.text = LinkRandPhrase("Qu'est-ce que tu as, tu es "+ GetSexPhrase("malade de la tête ? Fiche le camp d'ici, abruti","malade de la tête ? Fiche le camp d'ici, idiote") +" !",
				""+ GetSexPhrase("Quoi ?!! Tu as mangé trop de jusquiame, crétin","Quoi ?!! Tu as mangé trop de jusquiame, idiote") +" ?! Fiche le camp d'ici avec tes questions...",
				""+ GetSexPhrase("Tu as perdu la tête, mon cher ? Quels pirates ?! Chez nous ?!! Tu ferais mieux de déguerpir, petit imbécile","Tu as perdu la tête, ma chère ? Quels pirates ?! Chez nous ?!! Tu ferais mieux de déguerpir, ma jolie") +"...");
			link.l1 = RandPhraseSimple("Pas d'insolence...", "C'est quoi, ces manières ?!");
			link.l1.go = "exit";
		break;

		// ==> индейцы в поселении
		case "IndPearlMan":
			NextDiag.TempNode = "IndPearlMan";
			dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Visage pâle","Squaw blanche") +" veut parler ?",
				"Encore toi, "+ GetSexPhrase("visage pâle","squaw blanche") +".",
				""+ GetSexPhrase("Visage pâle aime parler. Il ressemble à une squaw.","Squaw blanche aime parler.") +"",
                "Les esprits m'amènent un visage pâle, "+ GetSexPhrase("mon frère","ma sœur") +".", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui.",
				"Oui, c'est encore moi.",
                "Très poétique.",
				"דa me fait plaisir aussi de te voir.", npchar, Dialog.CurrentNode);
			link.l1.go = "IndPearlMan_1";
		break;
		case "IndPearlMan_1":
			dialog.text = "Dis-moi ce qui t'amène.";
			link.l1 = "Rien de spécial, je voulais juste t'écouter...";
			link.l1.go = "exit";
			link.l2 = "Tu as des perles à vendre ?";
			link.l2.go = "IndPearlMan_2";
			if (pchar.questTemp.Sharp.SeekSpy == "seekSpy")
			{
				link.l3 = "וcoute, mon ami à la peau rouge ! Je cherche un homme parmi les pêcheurs de perles d'ici. Tu vas m'aider ?";
				link.l3.go = "IndPearlMan_Sharp_1";
			}
		break;
		//жемчужный генератор Шарпа, поиски осведомителя
		case "IndPearlMan_Sharp_1":
			dialog.text = "Que cherche le visage pâle ? Dis-moi...";
			link.l1 = "Oui, vois-tu, on soupçonne quelqu'un de chez vous de dire à quelqu'un oם vous allez pêcher dans la mer des Caraïbes.";
			link.l1.go = "IndPearlMan_Sharp_2";
		break;
		case "IndPearlMan_Sharp_2":
			dialog.text = "Moi savoir ce que vouloir"+ GetSexPhrase("visage pâle","squaw blanche") +"...";
			link.l1 = "Quoi ?";
			link.l1.go = "IndPearlMan_Sharp_3";
		break;
		case "IndPearlMan_Sharp_3":
			dialog.text = "וcoute-moi, "+ GetSexPhrase("frère visage pâle","squaw blanche") +", moi pas en dire beaucoup. Il y a ici un homme, son nom être Emilio Garcia. On l'avoir vu dans une grotte, dans une baie.";
			link.l1 = "Quelle baie ?";
			link.l1.go = "IndPearlMan_Sharp_4";
		break;
		case "IndPearlMan_Sharp_4":
			dialog.text = "Vous l'appeler la baie de San Juan del Norte. Emilio y aller souvent la nuit, là il parler avec un homme blanc dont personne ne connaît le nom, et ses yeux être comme ceux d'un serpent à sonnettes.";
			link.l1 = "Pourquoi personne ne connaît son nom ?";
			link.l1.go = "IndPearlMan_Sharp_5";
		break;
		case "IndPearlMan_Sharp_5":
			dialog.text = "Parce que lui pas l'avoir dit.";
			link.l1 = "Ah, je vois. Eh bien, merci, mon frère à la peau rouge.";
			link.l1.go = "IndPearlMan_Sharp_6";
		break;
		case "IndPearlMan_Sharp_6":
			dialog.text = "Que ton chemin soit droit.";
			link.l1 = "Merci quand même. Adieu...";
			link.l1.go = "exit";
			pchar.questTemp.Sharp.SeekSpy = "toLaVega";
            AddQuestRecord("SharpPearl_SeekSpy", "2");
			AddQuestUserData("SharpPearl_SeekSpy", "sName", npchar.name);
			pchar.quest.SharpSeekSpy_loginSpy.win_condition.l1 = "location";
			pchar.quest.SharpSeekSpy_loginSpy.win_condition.l1.location = "Shore55";
			pchar.quest.SharpSeekSpy_loginSpy.function = "SharpSeekSpy_loginSpy";
		break;
		//продажа жемчуга
		case "IndPearlMan_2":
			if (!CheckAttribute(npchar, "quest.pearl")) npchar.quest.pearl = rand(1);
			if (sti(npchar.quest.pearl) == 0 || CheckAttribute(pchar, "quest.PearlToShore_ForSale.id"))
			{
				dialog.text = "Pourquoi moi délier ma langue devant "+ GetSexPhrase("visage pâle","visage pâle") +" ? Non.";
				link.l1 = "Tu as quelque chose à dire ? Bon, comme tu veux...";
				link.l1.go = "exit";
			}
			else
			{
				bOk = false;
				int num = FindNearCharacters(npchar, 5.0, -1.0, -1.0, 1.0, false, true);
				if(num > 0)
				{
					for(int i = 0; i < num; i++)
					{
						iTemp = chrFindNearCharacters[i].index;
						if (iTemp == GetMainCharacterIndex()) continue;
						sTemp = characters[iTemp].id;
						if (findsubstr(sTemp, "FightMan" , 0) != -1)
						{
							bOk = true;
							break;
						}
					}
				}
				if (bOk)
				{
					dialog.text = "Moi avoir des larmes des dieux. Mais l'homme visage pâle aboyer comme un chien, tout le monde entendre, tout le monde vouloir donner un coup de pied. Moi partir...";
					link.l1 = "Quoi ?";
					link.l1.go = "IndPearlMan_4";
				}
				else
				{
					dialog.text = "Moi avoir des larmes des dieux. Viens à la grande eau tout près, moi être là jusqu'à la première lune.";
					link.l1 = "Compris. La baie la plus proche, avant minuit. Je viendrai sans faute.";
					link.l1.go = "IndPearlMan_3";
				}
			}
		break;
		case "IndPearlMan_3":
			npchar.LifeDay = 1;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
            NextDiag.CurrentNode = "IndPearlMan_Sale";
			LAi_SetActorTypeNoGroup(NPChar);
			if (npchar.location == "Pearl_town_2")
			{
				LAi_ActorRunToLocation(NPChar, "reload", "reload1", "Shore51", "goto", "goto1", "PearlToShore_ForSale", 10.0);
			}
			else
			{
				LAi_ActorRunToLocation(NPChar, "reload", "reload1", "Shore49", "goto", "goto1", "PearlToShore_ForSale", 10.0);
			}
			pchar.quest.PearlToShore_ForSale.idx = npchar.index;
			npchar.quest.Pearl.bigQty = rand(30) + 10;
			npchar.quest.Pearl.smallQty = rand(60) + 20;
			chrDisableReloadToLocation = true;
			DialogExit();
		break;
		case "IndPearlMan_4":
			npchar.LifeDay = 0;
			LAi_group_Attack(NPChar, Pchar);
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			LAi_SetActorType(NPChar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 10.0);
			DialogExit();
		break;

		case "IndPearlMan_Sale":
			dialog.text = "Vous êtes "+ GetSexPhrase("suis venu","suis venue") +"...";
			link.l1 = "Oui, bon, mais quel est le prix ?";
			link.l1.go = "IndPearlMan_Sale_1";
		break;
		case "IndPearlMan_Sale_1":
			dialog.text = "Dix pour une grosse larme, cinq pour une petite.";
			link.l1 = "Je les prends, combien en as-tu ?";
			link.l1.go = "IndPearlMan_Sale_2";
			link.l2 = "Non, je ne les prends pas, j'ai changé d'avis.";
			link.l2.go = "IndPearlMan_Sale_Out";
		break;
		case "IndPearlMan_Sale_2":
			dialog.text = npchar.quest.Pearl.bigQty + " grosses, " + npchar.quest.Pearl.smallQty + " petites.";
			link.l1 = "D'accord, je prends tout !";
			link.l1.go = "IndPearlMan_Sale_3";
		break;
		case "IndPearlMan_Sale_3":
			int iTemp = (sti(npchar.quest.Pearl.bigQty)*10) + (sti(npchar.quest.Pearl.smallQty)*5);
			if (sti(pchar.money) >= iTemp)
			{
				dialog.text = "Les esprits m'avoir souri, moi être heureux...";
				link.l1 = "Au revoir, l'ami...";
				AddMoneyToCharacter(pchar, -iTemp);
				TakeNItems(pchar, "jewelry11", sti(npchar.quest.Pearl.bigQty));
				TakeNItems(pchar, "jewelry12", sti(npchar.quest.Pearl.smallQty));
			}
			else
			{
				dialog.text = "Toi devoir"+ GetSexPhrase("","") +" à moi " + iTemp + " pièces. Toi pas avoir d'argent, moi pas avoir de larmes des dieux. Adieu.";
				link.l1 = "Oh, quel dommage...";
			}
			link.l1.go = "IndPearlMan_Sale_Out";
		break;
		case "IndPearlMan_Sale_Out":
			chrDisableReloadToLocation = true;
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], true);
			DialogExit();
			LAi_SetActorType(NPChar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "CanFightCurLocation", -1);
		break;

		case "CitizenNotBlade":
			dialog.text = "Capitaine, quelle sottise ! Rangez vos armes avant de provoquer des ennuis !";
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			link.l1.go = "exit";
		break;
	}
}
