// boal 25/04/04 общий диалог горожан
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 16/06/06
    int iTest, iTemp;
    iTest = FindColony(NPChar.City); // город
    ref rColony;
    string sTemp, sCity;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}

	String attrLoc = Dialog.CurrentNode;

	if(HasSubStr(attrLoc, "RumourAboutOwners_"))
	{
		NPChar.RumourOwnerType = FindStringAfterChar(attrLoc, "_");
		Dialog.CurrentNode = "RumourAboutOwners_TakeRumour";
	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
            LAi_group_Attack(NPChar, Pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":

            /*if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
				dialog.text = RandPhraseSimple("Spy? Guards!!!!!", "Guard! There is an enemy in the city!");
				link.l1 = "Shut up! I'm already leaving.";
				link.l1.go = "fight";
				break;
			}*/

            if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";

                // homo 05/08/06
				dialog.Text =NPCharRepPhrase(npchar,
                                LinkRandPhrase("Je m'appelle ", "Je m'appelle ", "Vous pouvez m'appeler ")
                                +GetFullName(npchar)
                                +LinkRandPhrase(". Que voulez-vous ?", ". Votre visage ne m'est pas familier. "
                                +"Qui êtes-vous ?", ". Qui êtes-vous, et que me voulez-vous ?"),

        		                LinkRandPhrase("Mes salutations, " + GetAddress_Form(NPChar) + ". Je m'appelle " + GetFullName(npchar) + ". Comment vous appelez-vous ?",
                                 "Bonjour, " + GetAddress_Form(NPChar) + " ! Je suis " + GetFullName(npchar) + ". Puis-je connaître votre nom ?",
                                 "Oui, " + GetAddress_Form(NPChar) + ". Que vouliez-vous ? Au fait, je m'appelle " + GetFullName(npchar) + ". Et vous ?"));

				Link.l1 = pcharrepphrase(
                                LinkRandPhrase("Sacrebleu ! ", "Mille diables ! ", "Que le diable t'emporte ! ") + "Oui, je suis le capitaine "+ GetFullName(Pchar)+ LinkRandPhrase(", vous n'avez pas entendu parler de moi"+NPCharSexPhrase(NPChar,", canaille ?","?"), " et "+ GetSexPhrase("le plus célèbre pirate","la plus célèbre pirate") +" de ces eaux ! ", " et que je sois damné si ce n'est pas vrai !"),
                                LinkRandPhrase("Je suis " + GetFullName(Pchar) + ", capitaine.", "Je m'appelle " + GetFullName(Pchar) + ".", "Appelez-moi capitaine " + GetFullName(Pchar) + "."));

                //LinkRandPhrase("I " + GetFullName(Pchar) + ", Captain.", "My name is " + GetFullName(Pchar) + ".", "You can call me Captain " + GetFullName(Pchar));
				Link.l1.go = "Meeting";
				if (pchar.sex == "Skeleton")	//Проверка на скелета
				{
					if	(GetCharacterEquipSuitID(pchar) == "suit_1")
					{
						dialog.text = "Même sous ces haillons, vous ne trompez pas mes vieux yeux...";
						link.l1 = "Mon déguisement est vraiment si mauvais ?",
						link.l1.go = "UndeadObuchenie_2";
					}
					else
					{
						dialog.text = "א en juger par votre démarche ridicule, on dirait que vous sortez tout juste de la tombe. Mais n'ayez pas peur de moi, je ne vous ferai pas de mal.";
						link.l1 = "Chose étonnante, c'est VOUS qui devriez avoir peur de MOI, et pas l'inverse !";
						link.l1.go = "UndeadObuchenie_11";
					}
				}
			}
			else
			{
// Graveyard keeper quest "Laying the Dead to Rest" (first branch) -->
				if (CheckAttribute(pchar, "GenQuest.GraveyardQuest") && pchar.GenQuest.GraveyardQuest.Town == NPChar.City)
				{
					if (pchar.GenQuest.GraveyardQuest.Stage == "reward")
					{
						link.lgrave = LinkRandPhrase("J'ai rendu le repos à tous les morts de votre cimetière, comme vous me l'aviez demandé.", "C'est fait, grand-père. Votre cimetière est de nouveau en paix.", "Le cimetière, le caveau et la crypte sont tous débarrassés des morts-vivants.");
						link.lgrave.go = "GraveyardQuest_Reward";
						// easter egg: ask the watcher about the chapel skeleton (only if the player has already seen it)
						if (CheckAttribute(pchar, "GenQuest.GraveyardQuest.ChapelSkelMet") && !CheckAttribute(pchar, "GenQuest.GraveyardQuest.SkelAsked"))
						{
							link.lskel = "Attendez. Il y a un squelette qui parle, assis dans la chapelle de votre cimetière. D'oם sort-il ?";
							link.lskel.go = "GraveyardQuest_AskSkel";
						}
					}
					else
					{
						link.lgrave = LinkRandPhrase("Je n'en ai pas encore fini avec votre cimetière.", "Donnez-moi encore un peu de temps, grand-père.", "Tous les morts-vivants de votre cimetière n'ont pas encore été rendus au repos.");
						link.lgrave.go = "GraveyardQuest_Busy";
					}
				}
				else
				{
					if (GraveyardQuest_IsAvailable(NPChar))
					{
						link.lgrave = LinkRandPhrase("Vous avez besoin d'aide avec les morts-vivants du cimetière ?", "Grand-père, je vois que quelque chose vous tracasse ?", "En venant jusqu'à votre cabane, j'ai entendu du bruit dans le cimetière : que se passe-t-il là-bas ?");
						link.lgrave.go = "GraveyardQuest_Offer";
					}
				}
				// <-- Graveyard keeper quest
				link.l1 = PCharRepPhrase("J'aimerais savoir quelque chose sur la ville des environs !", "Je voudrais me renseigner sur la ville qui se trouve non loin d'ici.");
				link.l1.go = "new question";
				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskPeople") && !CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.AskedPeople") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_town")
	            {
					link.l2 = LinkRandPhrase("Vous savez", "Vous savez", "Vous savez quelque chose sur le fait") + " que l'église du coin a été volée récemment ?");
					link.l2.go = "Citiz_GenQuest_Church_2_1";
				}
				// <-- Квестовый генератор священника. Квест №2.

                dialog.Text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Oh, c'est vous, "+GetFullName(Pchar)
                        +" "+ GetSexPhrase("– mon ami","– mon amie") +"", "Ravi de vous voir, "+ GetSexPhrase("vieux frère","ma belle") +" "
                        + Pchar.name, "Ah, mais voilà "+ GetSexPhrase("notre capitaine en personne :","notre capitaine en personne :") +" "
                         +GetFullName(Pchar))
                                        +LinkRandPhrase(". Je pensais que vous étiez déjà six pieds sous terre !", ". Et sans doute "+ GetSexPhrase("ivre mort. ","déjà un peu pompette. ") +"", ". Et toujours en liberté, à ce que je vois !")
                                        +LinkRandPhrase(" Dites-moi, que voulez-vous ?", " Que voulez-vous cette fois ?", " Vous venez encore me déranger pour rien ?"),
                                        LinkRandPhrase(TimeGreeting() + ", le capitaine ", "Bonjour, "+GetAddress_Form(NPChar)+" ", "Salutations, capitaine ")+GetFullName(Pchar)
                                        +LinkRandPhrase(". Qu'est-ce qui vous intéresse ?", ". Pourquoi es-tu ici ?", ". Que voulez-vous savoir cette fois ?")

                                        ),

                        PCharRepPhrase(LinkRandPhrase("Bonjour, capitaine ", "Bonjour, oh, c'est vous, "+GetAddress_Form(NPChar)+" ", "Ah, capitaine ")
                                        +GetFullName(Pchar)
                                        +LinkRandPhrase(", je pensais qu'on ne se reverrait plus,",
                                                         ", je ne dirais pas que ça me fait plaisir de vous voir, mais", " - toujours en vie, à ce que je vois, dommage, hein...")
                                        +LinkRandPhrase(" que voulez-vous ?", " pourquoi êtes-vous ici ?", " en quoi puis-je vous être utile ?"),
                                        LinkRandPhrase(TimeGreeting() + ", le capitaine " + GetFullName(Pchar) + ". En quoi puis-je vous aider ?",
                                        "Oh, capitaine " + GetFullName(Pchar) + " ! Que voulez-vous savoir cette fois ?",
                                        "Mes salutations, " + GetAddress_Form(NPChar) + " " + Pchar.lastname + ". Vous vouliez quelque chose ?"))
                                        );
	   			link.l3 = "Rien, j'ai changé d'avis" + GetSexPhrase(".",".");
				link.l3.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;
		case "Meeting":
		    dialog.Text  = NPCharRepPhrase(npchar, LinkRandPhrase("Vous ne mentez pas, capitaine " + GetFullName(Pchar)+" ?",
                                                                    "Et alors, " + PChar.name+" ?",
                                                                    "Je me souviendrai de vous, " + GetFullName(Pchar)+".")
                                                                     + " Maintenant, dites-moi ce que vous voulez.",
                                                    LinkRandPhrase("Ravi de vous rencontrer, capitaine " + PChar.name,
                                                                    "Ravi de faire votre connaissance, " + GetAddress_Form(NPChar) + " " + PChar.lastname,
                                                                     "C'est un plaisir, capitaine " + PChar.name) + ". Mais vous ne vouliez sans doute pas seulement connaître mon nom, n'est-ce pas ?");

// Graveyard keeper quest "Laying the Dead to Rest" (first branch) -->
				if (CheckAttribute(pchar, "GenQuest.GraveyardQuest") && pchar.GenQuest.GraveyardQuest.Town == NPChar.City)
				{
					if (pchar.GenQuest.GraveyardQuest.Stage == "reward")
					{
						link.lgrave = LinkRandPhrase("J'ai rendu le repos à tous les morts de votre cimetière, comme vous me l'aviez demandé.", "C'est fait, grand-père. Votre cimetière est de nouveau en paix.", "Le cimetière, le caveau et la crypte sont tous débarrassés des morts-vivants.");
						link.lgrave.go = "GraveyardQuest_Reward";
						// easter egg: ask the watcher about the chapel skeleton (only if the player has already seen it)
						if (CheckAttribute(pchar, "GenQuest.GraveyardQuest.ChapelSkelMet") && !CheckAttribute(pchar, "GenQuest.GraveyardQuest.SkelAsked"))
						{
							link.lskel = "Attendez. Il y a un squelette qui parle, assis dans la chapelle de votre cimetière. D'oם sort-il ?";
							link.lskel.go = "GraveyardQuest_AskSkel";
						}
					}
					else
					{
						link.lgrave = LinkRandPhrase("Je n'en ai pas encore fini avec votre cimetière.", "Donnez-moi encore un peu de temps, grand-père.", "Tous les morts-vivants de votre cimetière n'ont pas encore été rendus au repos.");
						link.lgrave.go = "GraveyardQuest_Busy";
					}
				}
				else
				{
					if (GraveyardQuest_IsAvailable(NPChar))
					{
						link.lgrave = LinkRandPhrase("Vous avez besoin d'aide avec les morts-vivants du cimetière ?", "Grand-père, je vois que quelque chose vous tracasse ?", "En venant jusqu'à votre cabane, j'ai entendu du bruit dans le cimetière : que se passe-t-il là-bas ?");
						link.lgrave.go = "GraveyardQuest_Offer";
					}
				}
				// <-- Graveyard keeper quest
            link.l1 = PCharRepPhrase("Je veux apprendre quelque chose sur cette ville !", "Je veux apprendre quelque chose sur la ville.");
			link.l1.go = "new question";
			// Квестовый генератор священника. Квест №2. Warship -->
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskPeople") && !CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.AskedPeople") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_town")
	        {
				link.l2 = LinkRandPhrase("Vous savez", "Vous savez quelque chose sur le fait", "Vous savez quelque chose sur le fait") + " que l'église du coin a été volée récemment ?");
				link.l2.go = "Citiz_GenQuest_Church_2_1";
			}
			// <-- Квестовый генератор священника. Квест №2.

			link.l3 = "Rien, j'ai changé d'avis" + GetSexPhrase(".",".");
			Link.l3.go = "exit";
		break;

		case "new question":
            dialog.text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Oh, oui, je vous demanderais volontiers ce que vous voulez boire.", "Vous aimez bavarder, capitaine ? Eh bien, moi aussi... Surtout autour d'une chope de rhum.", "Oui, " + PChar.name + " ?"),
                                        LinkRandPhrase("Eh bien, que voulez-vous encore ?", "Je vois, capitaine "+PChar.name+", vous avez envie de bavarder ? ", "Vous m'avez épuisé avec vos questions, capitaine, il vaudrait mieux boire du rhum.")),
		                PCharRepPhrase(LinkRandPhrase("Que vouliez-vous savoir, "+ GetAddress_Form(NPChar) + " ?", "Je vous écoute, capitaine.", "Je dois y aller, alors posez vite vos questions, capitaine."),
                                        LinkRandPhrase("Une conversation agréable, ça me fait toujours plaisir, " + GetAddress_Form(NPChar) + " " + PChar.lastname + ". Parlez.",
                                                        "Oui, " + GetAddress_Form(NPChar) + " ?",
                                                        "Vous aimez bavarder, capitaine ? Eh bien, moi aussi..."))
                            );

            // homo 25/06/06
			link.l1 = LinkRandPhrase ("Quelles histoires raconte-t-on à la taverne, par ici ?",
                                    "Quoi de neuf dans le coin ?",
                                    "Comment va la vie à terre ?");
			link.l1.go = "rumours_citizen";
			link.l2 = "Rien, j'ai changé d'avis" + GetSexPhrase(".",".");
			link.l2.go = "exit";
		break;

		case "RumourAboutOwners_TakeRumour":
			sTemp = sRumourAboutOwners_CityRumour(NPChar.City, NPChar.RumourOwnerType);
			Dialog.Text = sTemp;
			link.l1 = "Merci.";
			link.l1.go = "exit";
			// Здесь можно делать проверка по квестам, какой слух выпал
			DeleteAttribute(PChar, "QuestTemp.RumoursAboutOwners");
			break;
		//=================== ноды квеста священника. поиск грабителей (квест №2)==================
		case "Citiz_GenQuest_Church_2_1":
			if(rand(3) != 1)
			{
				dialog.text = LinkRandPhrase("Non, je ne sais rien à ce sujet.", "Je ne sais rien sur cette question.", "Je ne sais rien.");
					link.l1 = LinkRandPhrase("D'accord, bien.", "D'accord, merci.", "D'accord, désolé.");
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Je ne sais rien à ce sujet, mais vous pouvez demander aux habitués de la taverne : ils vous diront sמrement quelque chose.", "Je ne peux rien vous dire, demandez plutכt à quelqu'un à la taverne.", "Je ne sais rien de précis, mais j'ai entendu qu'on en parlait à la taverne.");
				link.l1 = "Merci quand même.";
				link.l1.go = "exit";
			}

			NPChar.GenQuest.ChurchQuest_2.AskedPeople = true;
		break;

		//замечение по обнажённому оружию
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami","ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas que "+ GetSexPhrase("des hommes","toutes sortes de gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais vous êtes "+ GetSexPhrase("un voleur, mon cher ! Gardes, retenez-le","une voleuse ! Gardes, retenez-la") +" !!!", "דa alors ! א peine j'ai tourné la tête que vous plongez dans le coffre ! Arrêtez ce voleur !!!", "Gardes ! On vole !!! Arrêtez ce voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		
		case "UndeadObuchenie_2":
			dialog.text = "J'ai vécu dans ce cimetière presque toute ma vie. Et je n'ai aucun mal à reconnaître qui se tient devant moi, un homme ou un mort-vivant. Mais ce ne sont pas vos vêtements qui trahissent le mort-vivant en vous, c'est votre DוMARCHE. Regardez comme vous vous tenez : de travers ; on voit tout de suite que vous avez quitté la tombe depuis peu. Bref, vous débutez.";
			link.l1 = "Oui, on voit ce monde d'une tout autre façon avec des yeux morts. Et ça me fait tanguer d'un cכté à l'autre.",
			link.l1.go = "UndeadObuchenie_3";
		break;
		
		case "UndeadObuchenie_3":
			dialog.text = "Vous n'avez rien à craindre, c'est juste moi qui ai l'œil aussi perçant. Les autres habitants de cette île ne remarqueront même pas la supercherie, et ils vous prendront pour l'un des leurs, c'est-à-dire pour une personne vivante. Mais dès que vous כterez votre déguisement, les gens vous seront hostiles. C'est clair pour vous, n'est-ce pas ?";
			link.l1 = "C'est désagréable. Mais... J'ai des alliés ?",
			link.l1.go = "UndeadObuchenie_13";
		break;
		
		case "UndeadObuchenie_11":
			dialog.text = "Héhé, non ! J'ai l'habitude des gens comme vous. J'entretiens même de bonnes relations avec certains morts-vivants. Mais je suis l'exception qui confirme la règle. Il vous faut de la prudence, car les autres habitants de cette île auront peur de vous et... chercheront à vous détruire.";
			link.l1 = "C'est fâcheux... Mais alors, que dois-je faire ?",
			link.l1.go = "UndeadObuchenie_12";
		break;
		
		case "UndeadObuchenie_12":
			dialog.text = "Il vous faut un déguisement. Trouvez des haillons et promenez-vous parmi les gens comme si vous étiez l'un des leurs.";
			link.l1 = "J'ai des alliés ?",
			link.l1.go = "UndeadObuchenie_13";
		break;
		
		case "UndeadObuchenie_13":
			dialog.text = "Bien sמr, presque tous les morts-vivants sont vos amis. Vous pouvez chercher vos semblables dans les grottes : ils rejoindront volontiers l'équipage de votre navire.";
			link.l1 = "דa m'a fait du bien de passer vous voir. Je vais continuer à explorer ce monde, dans ce corps maudit. Au revoir.",
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		//=================== Graveyard keeper quest "Laying the Dead to Rest" ===================
		case "GraveyardQuest_Offer":
			dialog.text = RandPhraseSimple("Vous tombez à pic. Il n'y a plus de paix dans mon cimetière : les morts se sont mis à sortir de leurs tombes, à errer parmi les pierres tombales, et les plus immondes se sont terrés dans le caveau et dans la crypte sous le cimetière. Un vieil homme comme moi ne peut pas s'en occuper. Rendez-les tous au repos, dans le cimetière, dans le caveau et dans la crypte, et je ne vous laisserai pas sans récompense.", "Heureusement que vous êtes là. J'ai des ennuis : les morts ne veulent pas rester dans leurs tombes, ils errent toute la nuit parmi les pierres tombales, et dans le caveau et la crypte se cache quelque chose de trop effroyable pour qu'on y pense. Je suis trop vieux pour manier une lame. Rendez le repos aux morts-vivants, au cimetière et en dessous, et vous ne le regretterez pas.");
			link.l1 = LinkRandPhrase("J'accepte. Oם dois-je chercher les morts-vivants ?", "Je vais vous aider. Oם dois-je aller ?", "D'accord. Oם se terrent les morts-vivants ?");
			link.l1.go = "GraveyardQuest_Accept";
			link.l2 = RandPhraseSimple("Excusez-moi, j'ai d'autres affaires en ce moment.", "Pas maintenant, j'ai des choses plus importantes à faire.");
			link.l2.go = "exit";
		break;

		case "GraveyardQuest_Accept":
			dialog.text = RandPhraseSimple("Ici même, dans le cimetière. Débarrassez-vous d'abord de ceux qui errent entre les tombes. Ensuite, descendez dans le caveau et la crypte : c'est là que nichent les plus puissants. Revenez me voir quand vous les aurez tous rendus au repos, jusqu'au dernier.", "Ici, dans le cimetière et en dessous. Rendez d'abord le repos à ceux qui errent à la surface, puis descendez dans le caveau et la crypte : les plus forts s'y cachent. Revenez quand vous en aurez fini avec eux tous.");
			link.l1 = LinkRandPhrase("Je vais m'en occuper.", "Considérez que les morts-vivants ne sont déjà plus là.", "Ce sera fait, grand-père.");
			link.l1.go = "exit";
			GraveyardQuest_Start(NPChar);
		break;

		case "GraveyardQuest_Busy":
			dialog.text = RandPhraseSimple("Les morts-vivants ne vont pas se rendre le repos tout seuls. Terminez le travail : nettoyez le cimetière, le caveau et la crypte.", "Vous revenez trop tכt. Tant qu'un seul mort marche encore, au cimetière, dans le caveau ou dans la crypte, le travail n'est pas fini.");
			link.l1 = RandPhraseSimple("Je reviens bientכt.", "Je m'en occupe déjà.");
			link.l1.go = "exit";
		break;

		case "GraveyardQuest_Reward":
			dialog.text = RandPhraseSimple("Enfin, mon cimetière est de nouveau tranquille. Vous avez tenu parole, et je tiendrai la mienne. Prenez ces livres : ils contiennent beaucoup de sagesse, ils vous seront utiles. Et acceptez ma gratitude.", "La paix règne de nouveau sur mon cimetière... Je suis votre débiteur. Prenez ces livres : ils renferment une sagesse que l'or ne peut acheter. Et ma gratitude vous accompagne.");
			link.l1 = LinkRandPhrase("Merci. Si les morts-vivants se relèvent, vous savez oם me trouver.", "Ce fut un plaisir d'aider. Portez-vous bien, grand-père.", "Il n'y a pas de quoi. Portez-vous bien.");
			link.l1.go = "exit";
			GraveyardQuest_GiveReward(NPChar);
		break;

		// easter egg: the watcher's account of the talking skeleton in the chapel (5 variants)
		case "GraveyardQuest_AskSkel":
			switch (rand(4))
			{
				case 0: dialog.text = "Ah, celui-là... Il est assis dans la chapelle depuis plus longtemps que je ne suis ici. Calme, inoffensif : il n'a jamais fait de mal à une mouche, ni de son vivant ni après. Je ne le dérange pas, et il ne me dérange pas. Parfois, il est de meilleure compagnie que la moitié des vivants du coin."; break;
				case 1: dialog.text = "C'est le vieux gardien qui s'occupait de cet endroit avant moi. Il s'était tellement attaché à son cimetière que même la mort n'a pas pu l'en chasser. Il s'est relevé et s'est installé dans la chapelle, pour monter la garde, comme il l'a toujours fait. Je ne lèverai pas la main sur lui : il connaît son métier mieux que n'importe quel vivant."; break;
				case 2: dialog.text = "Quand les morts-vivants ont commencé à se relever, il s'est relevé lui aussi. Mais lui seul a gardé ses esprits : il ne s'est pas jeté sur les gens pour les tuer, il s'est juste assis dans la chapelle et il a parlé. Je n'ai pas eu le cœur de lui rendre le repos. Qu'il reste assis, du moment qu'il ne fait de mal à personne."; break;
				case 3: dialog.text = "C'est un moine, qui priait ici à l'époque oם la chapelle était neuve. C'était une âme juste, alors il ne s'est pas relevé en créature malfaisante, mais en créature douce. Il marmonne ses prières et raconte ses histoires. Laissez-le tranquille : à qui fait-il du tort ?"; break;
				case 4: dialog.text = "Honnêtement, je ne sais pas moi-même d'oם il vient. Un jour, il était simplement là, dans la chapelle, et il me parlait comme un homme. Depuis, nous sommes voisins. Il semble que la mort ne transforme pas tout le monde en monstre. Certains restent humains, même réduits à l'état d'os."; break;
			}
			pchar.GenQuest.GraveyardQuest.SkelAsked = true; // the skeleton has been asked about - don't offer again (until the next easter egg)
			link.l1 = RandPhraseSimple("Curieux. Bon, à la prochaine, grand-père.", "Voilà donc ce qu'il en est... Merci de me l'avoir dit.");
			link.l1.go = "exit";
		break;
		//=================== <-- Graveyard keeper quest ===================
	}
}
