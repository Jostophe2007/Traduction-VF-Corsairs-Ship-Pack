// Gregg: The headman of the pearl divers' village (HeadMan_1) - the "Black Orchid"
// trilogy, chapter 5 "The Gift of Destiny" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\blackorchid.c
// The village stands on the coast of the Main, by Amatike Bay; the fishery itself
// belongs to Santa Catalina. The player lies up here after the rout
// at Santiago and works off what the headman knows about Alejon Kendart:
//   First time - the dispatcher on PChar.DestinyGift (states 2-19);
//   1-17  - waking up, the bargaining and the agreement to work for the village;
//   18-25 - the first task: kill the two thieves;
//   26-31 - the talk about the missing pearls, the second task;
//   32-39 - the payment (850 piastres for 4 pearls) and the tale of Kendart;
//   40-46 - Feregueyro is back, the player is sent after Cristobal Maul;
//   47-52 - the village is saved, one last favour - kill Feregueyro;
//   53-60 - there is no reward, the third part of the Meritor instead, farewell.
// Nodes 1 and 47 are set by the logic (chr.Dialog.CurrentNode), every other entry
// goes through the First time dispatcher.
// Gregg: TempNode = "First time" is set BEFORE the switch. The original set it only
// at the very tail of the First time node, so after any branch that ended with
// AddDialogExitQuestFunction the dialog fell into an empty node.
// Gregg: the squadron at Santiago is three heavy frigates, not ships of the line
// (see BO_Grassi); node 3 has been brought in line with that.
// Gregg: place names taken from LocLables - Nikoya Bay (Shore50), Amatike Bay
// (Shore9), Karataska Lagoon (Shore10).

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sBro = GetSexPhrase("frère", "sœur");

	string sChief = NPChar.name;

	string sState = "";
	if (CheckAttribute(PChar, "DestinyGift")) sState = PChar.DestinyGift;


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";

			if (sState == "2")
			{
				dialog.text = "Reposez-vous encore un jour, " + sBro + ", puis venez me voir.";
				link.l1 = "Très bien.";
				link.l1.go = "exit";
			}

			if (sState == "3")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Vous tombez à pic. Acceptez-vous de travailler pour le bien du village ?";
				link.l1 = "Je suis ici, donc je suis prêt. Que dois-je faire ?";
				link.l1.go = "18";
			}

			if (sState == "4")
			{
				dialog.text = "Avez-vous tué ces voleurs, " + sBro + " ?";
				link.l1 = "Euh... Pas encore.";
				link.l1.go = "exit";
			}

			if (sState == "5")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Le travail est fait ?";
				link.l1 = "C'est fait, ils sont morts. J'attends mes cinq cents piastres. Et l'histoire de Kendart.";
				link.l1.go = "26";
			}

			if (sState == "6")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Vous avez apporté les perles ?";
				link.l1 = "Je les cherche, " + sChief + ".";
				link.l1.go = "exit";
			}

			if (sState == "7")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Vous avez apporté les perles ?";
				link.l1 = "Je les cherche, " + sChief + ".";
				link.l1.go = "exit";
			}

			if (sState == "9")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Vous avez apporté les perles ?";
				link.l1 = "Oui. Voici les quatre perles, comme convenu.";
				link.l1.go = "32";
			}

			if (sState == "10")
			{
				dialog.text = "Laissez-moi me reposer, " + sBro + ". Revenez plus tard.";
				link.l1 = "Comme vous voudrez...";
				link.l1.go = "exit";
			}

			if (sState == "11")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Qu'est-ce qui vous amène ?";
				link.l1 = "Quoi d'autre ? Le travail, bien sמr.";
				link.l1.go = "40";
			}

			if (sState == "12")
			{
				dialog.text = "Ah, " + sBro + " ! Allez donc vous promener un peu le long des baies, regardez la mer. Il n'y a pas de travail pour vous.";
				link.l1 = "Très bien, j'y vais.";
				link.l1.go = "exit";
			}

			if (sState == "13")
			{
				dialog.text = "Mes salutations, " + sBro + ". Il n'y a pas encore de travail, revenez plus tard.";
				link.l1 = "Ce n'est pas pour ça que je suis venu. Je reviens tout juste de la baie de Nicoya, et là-bas...";
				link.l1.go = "41";
			}

			if (sState == "14")
			{
				dialog.text = "Qu'est-ce que vous attendez, bon sang ?!";
				link.l1 = "Ne me criez pas dessus. J'y vais déjà.";
				link.l1.go = "exit";
			}

			if (sState == "15")
			{
				dialog.text = "Amenez Cristobal au village ! Chaque minute compte.";
				link.l1 = "Nous arrivons. Ce n'est plus très loin.";
				link.l1.go = "exit";
			}

			if (sState == "16")
			{
				dialog.text = "J'ai entendu dire qu'on se battait dans la jungle. Ne traînez pas : ils vont tomber sur le village d'un moment à l'autre.";
				link.l1 = "Je sais. Nous sommes en route.";
				link.l1.go = "exit";
			}

			if (sState == "17")
			{
				dialog.text = "Venez me voir à l'hכtel de ville. Nous parlerons là-bas.";
				link.l1 = "J'y serai sous peu.";
				link.l1.go = "exit";
			}

			if (sState == "18")
			{
				dialog.text = "Avez-vous tué Feregueyro ?";
				link.l1 = "Je pars à sa poursuite.";
				link.l1.go = "exit";
			}

			if (sState == "19")
			{
				dialog.text = "Mes salutations, " + sBro + " ! Je le vois dans vos yeux : vous en avez fini avec Feregueyro.";
				// Gregg: без «sloop» - класс корабля Ферегуэйро считается от флагмана игрока
				link.l1 = "Oui. Je l'ai rattrapé, je l'ai abordé, et j'ai achevé Feregueyro moi-même.";
				link.l1.go = "53";
			}
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Oh ! Enfin réveillé. Comment vous sentez-vous ?";
			link.l1 = "En vie, apparemment. Seulement, mon bras gauche me brמle comme le feu. Bon sang, je ne me souviens de rien. Oם suis-je ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Au village des pêcheurs de perles, " + sBro + ". On vous a trouvé sur le rivage de la baie d'Amatique, sans connaissance, couvert de coupures et de bleus. Nous vous avons porté dans une maison vide et soigné comme nous avons pu : c'est là que vous êtes revenu à vous.";
			link.l1 = "Et depuis combien de temps suis-je ici ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Un jour et un peu plus. Nous commencions à croire que vous ne reviendriez jamais à vous. Dites-moi, " + sBro + ", vous vous souvenez de quelque chose ? Que vous est-il arrivé ?";
			link.l1 = "La dernière chose dont je me souviens, c'est Santiago. Trois frégates lourdes avaient encerclé notre navire. Puis le pont s'est dérobé sous mes pieds, je me suis retrouvé à l'eau, et après... après, plus rien.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Santiago, dites-vous. Non, impossible. La mer n'aurait pas pu vous porter aussi longtemps. De Santiago à Amatique, la route n'est pas courte, vous seriez mort. Vous vous souvenez peut-être d'autre chose ?";
			link.l1 = "Non, de rien. Après ce combat, ma mémoire s'arrête tout simplement.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Alors voici ce que je pense, " + sBro + ". Le plus probable, c'est qu'un marchand passant près de Cuba vous a repêché. Vous êtes resté sans connaissance dans sa cabine pendant quelques jours, des pirates l'ont attaqué au large d'Amatique, vous êtes de nouveau tombé à l'eau, et les vagues vous ont rejeté jusqu'à nous. Alors ? Cela vous paraît plausible ?";
			link.l1 = "C'est possible. Et vous avez trouvé quelqu'un d'autre que moi ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Vous étiez seul.";
			link.l1 = "Et oם sont mes affaires ? Et mon argent ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Vos affaires sont dans le coffre, dans cette même maison, jusqu'à la dernière piastre. Personne n'y a touché.";
			link.l1 = "Personne ? Les pêcheurs qui m'ont repêché, pas un seul n'a été tenté ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Je le jure sur l'Orchidée noire, " + sBro + " : pas un seul d'entre eux ! Pas une seule piastre n'a été prise !";
			link.l1 = "Qu'avez-vous dit ? Vous jurez sur l'Orchidée noire ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "C'est ce que j'ai dit. Il y avait un vieil homme ici qui aimait jurer sur elle. Quoi qu'on lui demande, c'était toujours « je le jure sur l'Orchidée noire ». Alors, ça m'est resté. Et pourquoi vous êtes-vous redressé comme ça ? Calmez-vous, " + sBro + ", ce qu'il vous faut maintenant, c'est du repos.";
			link.l1 = "Et ce vieil homme, il ne s'appelait pas Alejon Kendart ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Lui-même. Un drכle de bonhomme, je vous le dis. Tous les soirs, il racontait des histoires de son passé, et tout le village venait l'écouter. Et comment le connaissez-vous ?";
			link.l1 = "Oם est Kendart, maintenant ? Oם est-il, répondez-moi !";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Doucement, " + sBro + ", doucement. Kendart nous a quittés. Il a acheté une chaloupe il y a deux mois et il est parti. Oם, il ne l'a pas dit. Et que voulez-vous à ce vieil homme ?";
			link.l1 = "Vous devez tout me dire sur Kendart. Quand il est arrivé, quand il est parti, oם il vivait, ce qu'il faisait, qui il fréquentait. Tout.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Retenez bien ce que je vais vous dire, " + sBro + " : ici, personne ne vous doit rien. Et personne ne fera rien pour vous gratuitement. Pas même moi.";
			link.l1 = "Je vous demande seulement de me parler de Kendart, rien de plus. Est-ce donc tant demander ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Faut-il que je le répète ? Je ne vous dirai rien gratuitement. Vous avez de l'argent, je le vois bien, mais à quoi me servirait-il ? Il n'y a rien à acheter ici, de toute façon. Travaillez pour moi et pour le bien du village en échange de ce que je sais. Travaillez bien, et je vous dirai tout.";
			link.l1 = "Que le diable l'emporte, je n'ai pas le temps de travailler pour vous. Je dois partir d'ici et trouver Kendart.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Et comment comptez-vous y arriver ? Vous n'avez pas de navire, et il n'y en a pas à trouver ici : tout le village ne possède que des esquifs et des barques à fond plat, et aucun ne va au-delà des hauts-fonds. Secouez votre bourse tant que vous voudrez : personne ne vous emmènera loin de cette cכte. Alors il ne vous reste qu'une voie : travailler pour moi. Il n'y en a pas d'autre.";
			link.l1 = "Et si je paie ? Si je paie grassement, quelqu'un acceptera bien de m'emmener.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Gardez vos piastres, " + sBro + ". Ici, elles ne vous achèteront ni navire ni bon vent : il n'y a pas d'amateurs, et il n'y en aura pas. Faisons comme je l'ai dit, et tout ira bien : vous apprendrez ce que vous voulez sur Kendart, et moi, je réglerai les problèmes de mon village.";
			link.l1 = "Très bien. Et que dois-je faire ? Pêcher des perles avec les autres ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Non, ce serait bien trop simple. Le travail sera d'un autre genre. Mais ce sera pour demain ; pour l'instant, reposez-vous une journée et reprenez des forces. Ah, et encore une chose : la maison oם vous avez été soigné était celle de Kendart, juste en face de la mienne. Restez-y. Et ne nous en veuillez pas, " + sBro + ", c'est ainsi que les choses se font ici depuis longtemps.";
			link.l1 = "Je comprends. Et merci de m'avoir ramené de l'autre monde.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Assez parlé. Allez vous reposer. Passez me voir dans trois jours environ : il y aura du travail.";
			link.l1 = "J'y passerai. Et merci encore.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftRestTimer");
		break;

		case "18":
			dialog.text = "Envoyez dans l'autre monde deux gredins qui ne nous laissent pas vivre. Il n'y a pas plus de deux mois, on les a accusés d'avoir volé quatre grosses perles. On n'a pas trouvé de preuve solide, mais on leur a retiré le droit de plonger. Depuis, ils attaquent le village et les sentinelles quand l'envie leur en prend.";
			link.l1 = "Et vous êtes certain que ce sont eux qui les ont volées ? Si leur culpabilité n'a jamais été prouvée, alors ils sont innocents.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Il n'y avait pas de preuve directe, mais il y en avait une charretée d'autres, et toutes les désignaient. On les a épargnés et relâchés, alors que selon la loi du village, ils auraient dמ être fusillés. Et maintenant, nous récoltons les fruits de notre clémence, " + sBro + ".";
			link.l1 = "Alors j'ai deux questions. Oם dois-je les chercher, et que vais-je gagner pour ce travail ?";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Les chercher ? N'importe oם. Pensez surtout aux grottes et aux cavernes. Pour ce travail, je vous paierai cinq cents piastres.";
			link.l1 = "Cinq cents piastres ? C'est une misère !";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Plus ce que je sais de Kendart, si vous ne l'avez pas oublié. Et ici, cinq cents piastres, c'est beaucoup d'argent. Bien des pêcheurs gagnent cent cinquante par sortie.";
			link.l1 = "Je comprends maintenant pourquoi ces deux-là sont devenus voleurs. Avec cent cinquante misérables piastres, j'aurais moi-même chipé cinq perles.";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Et vous l'auriez payé de votre tête, " + sBro + ". La loi est surveillée de près, ici. Personne n'a encore jamais emporté une perle sans être vu.";
			link.l1 = "Et pourquoi les gens acceptent-ils un tel travail ? Un labeur digne d'une galère, un salaire de mendiant, interdiction de voler, et une balle à la première erreur.";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Pour la beauté, " + sBro + " ! Pour voir une perle briller au creux de sa main.";
			link.l1 = "Rien de plus simple : achetez une douzaine de perles à n'importe quel marchand et contemplez-les jusqu'à en avoir mal aux yeux.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Non, " + sBro + ". דa, vous ne le comprendrez jamais.";
			link.l1 = "Bien sמr que non. Comment un simple mortel comme moi le pourrait-il ?";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "וcoutez, " + sBro + ", allez travailler ! Vous m'avez épuisé à force de parler.";
			link.l1 = "Préparez l'argent, je reviens bientכt.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFirstTask");
		break;

		case "26":
			dialog.text = "Attendez, ne me pressez pas. Répondez-moi plutכt : avez-vous fouillé les corps ?";
			link.l1 = "Bien sמr, je le fais toujours.";
			link.l1.go = "27";
			link.l2 = "Non. Il n'en était pas question dans la mission.";
			link.l2.go = "31";
		break;

		case "27":
			PChar.DestinyGift.FirstTalk = true;
			dialog.text = "Et vous n'avez pas trouvé quatre perles sur eux ?";
			link.l1 = "Non, ils n'avaient aucune perle. Ils auraient dמ en avoir ?";
			link.l1.go = "28";
		break;

		case "28":
			dialog.text = "Nous avons eu la preuve que ces deux-là ont bien volé quatre grosses perles.";
			link.l1 = "Et maintenant, je dois les retrouver ?";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Oui, " + sBro + ", c'est votre prochaine mission. Retrouvez-les, et je vous promets trois cents piastres de plus.";
			link.l1 = "Je doute qu'ils aient gardé les perles sur eux : trop de risques de les perdre. Ils les ont donc cachées quelque part. Nous allons chercher.";
			if (CheckAttribute(PChar, "DestinyGift.FirstTalk"))
			{
				if (PChar.DestinyGift.FirstTalk == true)
				{
					link.l1 = "Si les perles n'étaient pas sur eux, c'est qu'ils les ont cachées quelque part. Nous allons chercher.";
				}
			}
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Fouillez les grottes et les cavernes, la cachette s'y trouve très probablement.";
			link.l1 = "Très bien, je vais chercher.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftToSeachPearl");
		break;

		case "31":
			PChar.DestinyGift.FirstTalk = false;
			dialog.text = "Bon sang. C'est très mauvais.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "29";
		break;

		case "32":
			AddMoneyToCharacter(PChar, 850);
			TakeNItems(PChar, "DestinyGiftPearl", -4);
			dialog.text = "Parfait. Voici huit cent cinquante piastres. Honnêtement gagnées.";
			link.l1 = "Et maintenant, parlez-moi d'Alejon Kendart.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Bon. Alejon Kendart est arrivé ici il y a sept ou huit mois. Un vieil homme de taille moyenne, sec comme un bâton, mais qui se tenait comme si le monde entier lui arrivait au genou. Il est venu me voir et m'a dit qu'il espérait trouver une vie tranquille dans notre village. Au début, je voulais le renvoyer, mais il m'a promis mille cinq cents piastres pour la maison. Et là, je n'ai pas pu résister.";
			link.l1 = "C'est compréhensible, quand on sait ce que vous gagnez ici.";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Pendant les quinze premiers jours, Kendart n'a pas mis une seule fois le nez dehors. Et puis, il est devenu un autre homme : dehors toute la journée, à faire la connaissance de tout le monde, à parler avec tout le monde. En un mois et demi, il était devenu le chouchou du village : chaque soir, il racontait des histoires de son passé.";
			link.l1 = "Et il n'a jamais parlé de l'Orchidée noire ?";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Non, il jurait seulement sur elle. Nous lui avons bien demandé de quelle orchidée il s'agissait, et il s'est tu. Et pour dire la vérité, ça nous était bien égal. Puis un jour, un type est arrivé ici, il s'appelait Murdok, je crois.";
			link.l1 = "Murdoch ? Sir Andrew Murdoch ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Oui, c'est ça, Andrew Murdoch. Il s'est mis à me poser des questions sur Alejon Kendart, et il savait de façon certaine que Kendart vivait ici. Au début, j'ai refusé, puis il m'a offert de l'argent, et je...";
			link.l1 = "Je vois, vous avez accepté. Et ensuite ?";
			link.l1.go = "37";
		break;

		case "37":
			dialog.text = "Je lui ai dit oם vivait Kendart, et ensuite...";
			link.l1 = "Et ensuite quoi ?";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "C'est la fin de l'histoire, " + sBro + ". Faites encore deux ou trois courses pour moi, et je vous dirai la suite.";
			link.l1 = "Que le diable vous emporte ! Très bien, vous avez gagné. Quelles courses ?";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Revenez dans deux ou trois jours, et il y aura du travail pour vous.";
			link.l1 = "Très bien, je reviendrai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftNextTimer");
		break;

		case "40":
			dialog.text = "Je n'ai pas encore de travail pour vous. Ne le prenez pas mal, " + sBro + ", c'est comme ça. Et puisque vous n'avez rien à faire, promenez-vous dans les environs du village, regardez la mer depuis la baie, explorez les grottes.";
			link.l1 = "Très bien, je vais faire un tour.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftNoneTask");
		break;

		case "41":
			dialog.text = "...(l'interrompant)... Je sais, je sais, on a une belle vue sur la mer de là-bas.";
			link.l1 = "Non, il y a un homme en robe là-bas ! Un homme très étrange.";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "...(pâlit)... Un homme en robe ? Qu'a-t-il dit ?";
			link.l1 = "Que tous seraient tués et que personne ne survivrait. Que Feregueyro serait vengé et la malédiction levée.";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "...(pâlit encore davantage)... Feregueyro est revenu. Non ! Pas ça ! Pas maintenant !";
			link.l1 = "Hé, " + sChief + " ! " + sChief + ", cessez de crier. Calmez-vous !";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Malheur, " + sBro + " ! Malheur ! Feregueyro est revenu sur nos cכtes.";
			link.l1 = "Et qui est ce Feregueyro ? Pourquoi le craignez-vous tant ? Expliquez-vous, enfin !";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Il n'y a pas le temps d'expliquer, " + sBro + ". Il faut alerter le village et le préparer à se défendre : un combat contre les serviteurs de Feregueyro est inévitable. Alors voici votre prochaine mission : trouvez un homme du nom de Cristobal Kuvalda et amenez-le ici, au village. Dans une bagarre, il n'a pas de prix.";
			link.l1 = "Oם dois-je le chercher ?";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Je ne sais pas, " + sBro + ". Quelque part dans la jungle, près des grottes peut-être. L'essentiel est de le trouver et de l'amener ici. Et dépêchez-vous, il n'y a plus de temps : les serviteurs de Feregueyro vont nous tomber dessus d'une heure à l'autre.";
			link.l1 = "J'y vais !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftSearchKuvalda");
		break;

		case "47":
			dialog.text = "Diable, oם étiez-vous passé, " + sBro + " ? Pourquoi avez-vous mis tant de temps à trouver Cristobal ?";
			link.l1 = "Nous avons dמ combattre deux fois les serviteurs de Feregueyro avant d'atteindre le village ! Et vous, pourquoi restiez-vous dans votre maison au lieu de vous battre dans la rue avec les autres ?";
			link.l1.go = "48";
		break;

		case "48":
			dialog.text = "Mon devoir est de rester auprès des perles en permanence ! Je suis le dernier rempart de nos richesses.";
			link.l1 = "Je vois. Vous avez de drכles de coutumes, ici. Bon : le village est sauvé, l'attaque repoussée. Je suppose que cela vaut bien qu'on me laisse enfin partir.";
			link.l1.go = "49";
		break;

		case "49":
			dialog.text = "Nous sommes vos débiteurs, " + sBro + " ! Mais rendez d'abord un dernier service au village.";
			link.l1 = "Il se trouve que je suis plutכt fatigué.";
			link.l1.go = "50";
		break;

		case "50":
			dialog.text = "Vous sauverez beaucoup de vies si vous acceptez.";
			link.l1 = "Très bien. Que dois-je faire ?";
			link.l1.go = "51";
		break;

		case "51":
			// Gregg: в оригинале тут дарили люггер «Броненосец». У нас возвращается свой
			// корабль - см. BO_RestockFlagship в blackorchid.c. Класс корабля Ферегуэйро
			// тоже не фиксирован, поэтому «шлюп» заменён на нейтральное.
			dialog.text = "Tuer Feregueyro ! Nous avons appris qu'il s'apprête à quitter la lagune de Caratasca. Rattrapez-le et tuez-le. Vengez notre peuple, notre village, tout le mal qu'il nous a fait. Nous ne vous laisserons pas sans récompense, " + sBro + ", je vous le promets. Et encore une chose. Pendant que vous étiez dans la jungle, deux hommes sont venus ici : ils se disaient de votre équipage et vous cherchaient. Ils ne vous ont pas trouvé et sont retournés à la baie d'Amatique. Le navire est réparé et avitaillé, disent-ils. Ils vous attendent.";
			link.l1 = "Très bien, je vais vous aider.";
			link.l1.go = "52";
		break;

		case "52":
			dialog.text = "Et encore une chose. Ne le coulez pas, " + sBro + ". Prenez-le à l'abordage et faites-le monter vivant sur le pont. Ceux des nכtres qui l'ont vu de près disent qu'il porte une babiole au bout d'un cordon et qu'il ne l'enlève même pas au combat. Un talisman, sans doute. S'il se noie, la babiole sombrera avec lui, et j'aimerais bien voir quel talisman protégeait un tel homme.";
			link.l1 = "Mm...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftNeedKillFeregueyro");
		break;

		case "53":
			dialog.text = "A-t-il demandé grâce ? Vous a-t-il supplié ?";
			link.l1 = "Non, il est mort dignement. Je pense qu'il est temps de parler de la récompense.";
			link.l1.go = "54";
		break;

		case "54":
			dialog.text = "Mmm... Vous savez, " + sBro + ", il n'y aura pas de récompense.";
			link.l1 = "Je ne comprends pas. Comment ça, pas de récompense ?";
			link.l1.go = "55";
		break;

		case "55":
			dialog.text = "Après la dernière attaque, toutes nos économies, toutes nos perles, ont disparu. Il ne nous reste que cette chose-là : nous l'avons trouvée dans la maison oם vivait Kendart. Peut-être l'accepterez-vous comme récompense ? Vous demandiez des nouvelles de Kendart et de tout ce qui le concernait.";
			link.l1 = "Que le diable m'emporte, c'est la troisième partie du Meritor !";
			link.l1.go = "56";
		break;

		case "56":
			dialog.text = "La troisième partie de quoi ?";
			link.l1 = "Peu importe. Je la prends.";
			link.l1.go = "57";
		break;

		case "57":
			TakeNItems(PChar, "MysteriousArtefact_MeritorChapter_3", 1);
			dialog.text = "Bien. Prenez-la, et j'espère qu'elle vous servira.";
			link.l1 = "N'en doutez pas. Maintenant, je dois partir.";
			link.l1.go = "58";
		break;

		case "58":
			dialog.text = "Attendez, " + sBro + ". Il y avait encore une chose que je voulais vous dire.";
			link.l1 = "Faites vite.";
			link.l1.go = "59";
		break;

		case "59":
			dialog.text = "Merci pour tout ! Les gens de notre village vous sont reconnaissants pour ce que vous avez fait pour eux. Nous ne l'oublierons jamais. Merci !";
			link.l1 = "...(gêné)... Je n'ai rien fait d'extraordinaire.";
			link.l1.go = "60";
		break;

		case "60":
			dialog.text = "Adieu, " + sBro + ". Et bonne chance.";
			link.l1 = "Bonne chance à vous aussi. Et à tous les gens du village. Adieu.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftExitPearlVillage");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
