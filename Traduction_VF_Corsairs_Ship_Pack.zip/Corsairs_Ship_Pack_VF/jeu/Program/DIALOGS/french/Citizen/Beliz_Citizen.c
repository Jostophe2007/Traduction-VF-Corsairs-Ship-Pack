// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			// ==> Квест "Witch Hunt"
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz") && npchar.sex == "man" && !CheckAttribute(npchar, "PDM_ONV_Vopros"))
			{
				link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
				link.l1.go = "PDM_ONV_MAN";
			}
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz") && npchar.sex == "man" && !CheckAttribute(npchar, "PDM_ONV_Vopros") && CheckAttribute(pchar, "questTemp.PDM_ONV_MAN_1"))
			{
				link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
				link.l1.go = "PDM_ONV_MAN_2";
				DeleteAttribute(pchar, "questTemp.PDM_ONV_MAN_1");
			}
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz") && npchar.sex == "man" && !CheckAttribute(npchar, "PDM_ONV_Vopros") && CheckAttribute(pchar, "questTemp.PDM_ONV_MAN_2"))
			{
				link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
				link.l1.go = "PDM_ONV_MAN_3";
				DeleteAttribute(pchar, "questTemp.PDM_ONV_MAN_2");
			}
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz") && npchar.sex == "man" && !CheckAttribute(npchar, "PDM_ONV_Vopros") && CheckAttribute(pchar, "questTemp.PDM_ONV_MAN_3"))
			{
				link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
				link.l1.go = "PDM_ONV_MAN_4";
			}
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz") && npchar.sex == "woman" && !CheckAttribute(npchar, "PDM_ONV_Vopros"))
			{
				link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
				link.l1.go = "PDM_ONV_WOMAN";
			}
			// <== Квест "Witch Hunt"
		break;

		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Que voulez-vous que je vous dise ? Je ne sais pas. Je ne sais rien.";

            link.l1 = "Quel imbécile ! Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;
		
//**************************Квест "Witch Hunt"*******************************

		case "PDM_ONV_WOMAN":
			dialog.text = RandPhraseSimple("Je ne connais aucune Maria.", "Qui c'est encore, cette Maria ?", "Je ne vois pas de qui vous parlez.", "Qui, qui ? C'est la première fois que j'entends parler d'une fille pareille.", "Nous n'avons jamais eu de fille pareille ici.");
			link.l1 = "Désolé.";
			link.l1.go = "exit";
			npchar.PDM_ONV_Vopros;
		break;

		case "PDM_ONV_MAN":
			dialog.text = "Pardon, mais je n'ai pas le temps.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			npchar.PDM_ONV_Vopros;
			pchar.questTemp.PDM_ONV_MAN_1 = true;
		break;
		
		case "PDM_ONV_MAN_2":
			dialog.text = "Laissez-moi tranquille, "+ GetSexPhrase("señor", "señorita") +".";
			link.l1 = "Désolé.";
			link.l1.go = "exit";
			npchar.PDM_ONV_Vopros;
			pchar.questTemp.PDM_ONV_MAN_2 = true;
		break;
		
		case "PDM_ONV_MAN_3":
			dialog.text = "Passez votre chemin, amig"+ GetSexPhrase("o", "a") +".";
			link.l1 = "Désolé.";
			link.l1.go = "exit";
			npchar.PDM_ONV_Vopros;
			pchar.questTemp.PDM_ONV_MAN_3 = true;
		break;
		
		case "PDM_ONV_MAN_4":
			dialog.text = "Je vous le dis, "+ GetSexPhrase("señor", "señorita") +" : cette sorcière de Maria a ensorcelé toute la ville ! Tous les honnêtes gens devraient aller tout droit chez le gouverneur et lui dire que c'est une méchante sorcière et qu'il faut la brמler à petit feu !";
			link.l1 = "Maria ? Que savez-vous d'elle ?";
			link.l1.go = "PDM_ONV_MAN_4_1";
		break;

		case "PDM_ONV_MAN_4_1":
			dialog.text = "Moi ? Je sais qu'elle est une source de péché mortel pour tous les hommes de cette ville ! Il faut mettre fin à cette débauche !");
			link.l1 = "Tiens donc. Vous êtes donc le seul homme de la ville à ne pas profiter des services de Maria ? Oh, le pauvre ! On comprend maintenant pourquoi vous n'avez pas le sens de l'humour. Ha ha. Mais je dois interrompre notre conversation : au revoir.";
			link.l1.go = "exit";
			link.l2 = "Le gouverneur m'a ordonné de capturer cette sorcière : il veut l'interroger personnellement. Savez-vous oם je peux la trouver ?";
			link.l2.go = "PDM_ONV_MAN_4_2";
		break;

		case "PDM_ONV_MAN_4_2":
			dialog.text = "Elle amène généralement ses victimes à la taverne. Que Dieu vous bénisse, capitaine ! Allez-y et faites sortir ce serpent de son nid ! Vous êtes "+ GetSexPhrase("un homme courageux, señor", "une femme courageuse, señorita") +". Que cette sorcière se promène ici et fasse tout ce qu'elle veut, c'est une honte pour notre ville !");
			link.l1 = "Nous allons nous occuper de cette sorcière, n'en doutez pas.";
			link.l1.go = "exit";
			AddQuestRecord("PDM_Ohota_na_vedmu", "7");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Oficiantka_Beliz");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_MAN_3");
			pchar.questTemp.PDM_ONV_Detectiv_Tavern_Da = true;
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

