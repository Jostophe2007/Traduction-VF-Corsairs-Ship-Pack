#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
string sProf;

void ProcessDialogEvent()
{
	int license_price = sti(PChar.rank) * (2500) * (0.01 * (120 - GetSummonSkillFromName(PChar, SKILL_COMMERCE)));;
	int license_expires = rand(2);

	ref NPChar, sld;
	aref Link, NextDiag, arCapBase, arCapLocal;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// доп повека
	if (!CheckAttribute(NPChar, "Portman")) NPChar.Portman = 0;
	if (!CheckAttribute(NPChar, "PortManPrice")) NPChar.PortManPrice = (0.06 + frnd()*0.1);

	// вызов диалога по городам -->
	NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\PortMan\" + NPChar.City + "_PortMan.c";
	if (!HasCityDialogFile("PortMan", NPChar.City, "_PortMan.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\PortMan\DefaultCity_PortMan.c";
	if (LoadSegment(NPChar.FileDialog2))
	{
		ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\PortMan\DefaultCity_PortMan.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
	// вызов диалога по городам <--
	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	int i, cn;
	ref chref, compref;
	ref rRealShip;
	string attrL, sTitle, sCapitainId, s1;
	string sColony;

	String sLastSpeakDate = LastSpeakDate();

	// Warship 25.07.09 Генер "The burnt-out ship.". Даты отказа ГГ - если отказал, то предложит снова только на след сутки
	if(CheckAttribute(NPChar, "Quest.BurntShip.LastQuestDate") && NPChar.Quest.BurntShip.LastQuestDate != sLastSpeakDate)
	{
		DeleteAttribute(NPChar, "Quest.BurntShip");
	}
	bool ok, ok2;
	int iTest = FindColony(NPChar.City); // город магазина
	ref rColony;
	string sFrom_sea = "";
	npchar.quest.qty = CheckCapitainsList(npchar); //для списка кэпов

	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
		sFrom_sea = rColony.from_sea;
	}

	attrL = Dialog.CurrentNode;

	if(HasSubStr(attrL, "ShipStockManBack11_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.StoreWithOff = 1;
		NPChar.ShipToStoreIdx = strcut(attrL, i+1, strlen(attrL)-1); // индех в конце
		Dialog.CurrentNode = "ShipStockManBack";
	}

	if(HasSubStr(attrL, "ShipStockManBack22_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.StoreWithOff = 0;
		NPChar.ShipToStoreIdx = strcut(attrL, i+1, strlen(attrL)-1); // индех в конце
		Dialog.CurrentNode = "ShipStockManBack";
	}

	if(HasSubStr(attrL, "ShipStockManBack2_"))
	{
		i = findsubstr(attrL, "_" , 0);
		AddMoneyToCharacter(Pchar, -sti(NPChar.MoneyForShip));

		chref = GetCharacter(sti(NPChar.ShipToStoreIdx));//сторож

		DownCrewExp(chref,GetNpcQuestPastDayParam(chref, "ShipInStockMan.Date"));

        int iChar = GetPassenger(PChar, sti(strcut(attrL, i+1, strlen(attrL)-1))); //выбранный пассажир
		compref = GetCharacter(iChar);

		DeleteAttribute(compref, "ship");//зачем-то стираем корабль офицера, хотя его там и не должно быть
		compref.ship = "";

		aref    arTo, arFrom;

		makearef(arTo, compref.ship);
		makearef(arFrom, chref.Ship);
		CopyAttributes(arTo, arFrom);

		// снимем пассажира -->
		CheckForReleaseOfficer(iChar);//увольнение офицера с должностей, если он не просто пассажир
		RemovePassenger(pchar, compref);
		// снимем пассажира <--
		SetCompanionIndex(pchar, -1, iChar);
		DelBakSkill(compref);
		DeleteAttribute(chref, "ShipInStockMan");
		chref.id = "ShipInStockMan";//сбрасываем индекс к стандартному, чтобы этот номер массива в следующий раз можно было занять
		DeleteAttribute(chref, "ship");//затираем данные корабля у сторожа
		chref.ship = "";
		LAi_SetCurHP(chref, 0.0);//ещё и убивать непися, чтоб точно очистился из массива?

		NPChar.Portman	= sti(NPChar.Portman) - 1;
		pchar.ShipInStock = sti(pchar.ShipInStock) - 1;
		Dialog.CurrentNode = "exit";//закрываем диалог, ещё одно подтверждение уже не справшиваем
	}

	if(HasSubStr(attrL, "ShipStockMan11_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.StoreWithOff = 1;
		NPChar.ShipToStoreIdx = GetCompanionIndex(PChar, sti(strcut(attrL, i+1, strlen(attrL)-1))); // индех в конце
		Dialog.CurrentNode = "ShipStock_Choose";
	}

	if(HasSubStr(attrL, "ShipStockMan22_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.StoreWithOff = 0;
		NPChar.ShipToStoreIdx = GetCompanionIndex(PChar, sti(strcut(attrL, i+1, strlen(attrL)-1))); // индех в конце
		Dialog.CurrentNode = "ShipStock_Choose";
	}

	if(attrL == "ShipStock_3_Unlim") // indefinite storage for triple price
	{
		NPChar.StoreUnlimited = 1;
		Dialog.CurrentNode = "ShipStock_3";
	}

	if(HasSubStr(attrL, "BurntShip19_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.Quest.BurntShip.ShipCompanionIndex = strcut(attrL, i + 1, strlen(attrL) - 1); // индех в конце
		Dialog.CurrentNode = "BurntShip19";
	}
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;
		case "First time":
			NextDiag.TempNode = "First time";
			if (LAi_grp_playeralarm > 0)
			{
	  			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vous parlerai pas !", "Fuyez, "+ GetSexPhrase("l'ami", "ma petite") +" avant que les soldats ne vous transforment en passoire..."),
					LinkRandPhrase("Que voulez-vous, "+ GetSexPhrase("gredin", "gredine") +" ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin"+ GetSexPhrase(", sale pirate", "") +" !", " Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + ", et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			//homo
			//homo Линейка Блада
			if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
			{
				dialog.Text = LinkRandPhrase("Tiens, docteur Blood ! " + TimeGreeting() + ".",
									"Ravie de vous voir, Peter Blood.",
									"C'est gentil de passer me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
				Link.l1 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l1.go = "exit";
				break;
			}
			//homo
			if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";
				dialog.text = "Mes salutations, " + GetAddress_Form(NPChar) + ". Il me semble que nous ne nous connaissons pas. Je suis "  + GetFullName(npchar)+ " – le capitaine du port.";
				Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je suis " + GetFullName(PChar) + ", capitaine du navire '" + PChar.ship.name + "'.";
			}
			else
			{
				dialog.text = LinkRandPhrase("Mes salutations, " + GetAddress_Form(NPChar) + ". Vous êtes ici pour affaires ?",
									"Bonjour, " + GetFullName(Pchar) + ". J'ai vu votre navire entrer au port, et j'étais sמr que vous viendriez me voir.",
									"Ah, capitaine " + GetFullName(Pchar) + ". Qu'est-ce qui vous amène ?");
				Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je voudrais vous parler.";
			}
			Link.l1.go = "node_2";
		break;
		case "node_2":
			// Церковный генератор 1
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.AskPortMan") && PChar.GenQuest.ChurchQuest_1.AskPortMan_InColony == NPChar.city)
			{
				dialog.text = "Très bien. Je suis à votre service, " + GetFullName(PChar) + ".";
				if(!CheckAttribute(PChar, "GenQuest.ChurchQuest_1.CapFullInfo"))	// Получаем полную инфу
				{
					if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NoMoneyToPortMan"))
					{
						dialog.text = "Alors, et l'argent ? Vous m'avez apporté au moins 1000 piastres ?";
						if(sti(PChar.Money) >= 1000)
						{
							link.l1 = "Oui, je les ai apport"+ GetSexPhrase("ées", "ées") +". Voici exactement mille pièces d'or. Maintenant, les informations !";
							link.l1.go = "Church_GenQuest1_Node_FillFullInfo_3";
						}
						else
						{
							link.l1 = LinkRandPhrase("Non, pas encore"+ GetSexPhrase("", "") +"...", "Pas encore...", "Pas encore"+ GetSexPhrase("", "") +", mais je les apporterai bientכt...");
							link.l1.go = "exit";
						}
					}
					else
					{
						link.l1 = "Laissez-moi vous exposer le fond de l'affaire. J'ai manqué un vieil ami de quelques heures seulement, et j'ai une affaire urgente à régler avec lui. Je dois maintenant le rattraper, mais malheureusement, je ne sais pas dans quelle direction il est parti.";
						link.l1.go = "Church_GenQuest1_Node_FillFullInfo";
					}
				}
				else	// Полная инфа уже есть
				{
					link.l1 = "Monsieur le capitaine du port, j'ai besoin de renseignements sur le navire '" + PChar.GenQuest.ChurchQuest_1.CapShipName + "', dont le capitaine s'appelle " + PChar.GenQuest.ChurchQuest_1.CapFullName + ".";
					if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NextColonyIsLast")) // Он здесь, в этой колонии!
						link.l1.go = "Church_GenQuest1_Node_CapOnThisColony_1";
					else // Отправляет в рандомную колонию
						link.l1.go = "Church_GenQuest1_Node_FillInfoOfCapColony_1";
				}
				break;
			}
			//========================  Квест "Strange things are happening in the archipelago" ==>
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_NevisPortMan_1"))
			{
				link.l1 = "J'aimerais savoir si une frégate noire est entrée au port.";
				link.l1.go = "PKM_BlackFregat";
			}
			//========================  Квест "Strange things are happening in the archipelago" <==

			dialog.text = "Très bien. Je suis à votre service, " + GetFullName(PChar) + ".";
			if(NPChar.city != "Pirates")
			{
				Link.l2 = "Peut-on trouver du travail ici ? Ou un contrat ?";
				Link.l2.go = "node_4";
				Link.l13 = LinkRandPhrase("Les marchands qui cherchent une escorte pour leurs navires s'adressent sans doute à vous. Y en a-t-il aujourd'hui ?", "Avez-vous des passagers qui veulent se rendre dans une autre colonie ?", "J'ai un excellent navire, et je voudrais gagner un peu plus en escortant des marchands ou en transportant des passagers. Vous en avez ?"));
				Link.l13.go = "work_PU";
			}
				Link.l3 = "Je viens pour le stationnement d'un navire.";
				Link.l3.go = "PortStock_UI";
				Link.l14 = "J'aimerais vendre un navire aux enchères."; // LEO: аукцион в ПУ
				Link.l14.go = "PortAuction_UI";
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
			{
				link.l5 = "Je viens pour des questions financières.";
				link.l5.go = "LoanForAll";//(перессылка в кредитный генератор)
			}
 			if (CheckAttribute(pchar, "GenQuest.Intelligence") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "") //квест мэра - на связь с нашим шпионом
			{
				link.l7 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
					GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chercher quelque chose...");
				link.l7.go = "IntelligenceForAll";
			}
			link.l6 = "Je m'intéresse aux capitaines inscrits auprès de votre capitainerie.";
			link.l6.go = "CapitainList";
			if (bBribeSoldiers ==true && GetNationRelation(sti(NPChar.nation), GetBaseHeroNation()) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
				{
				if (!CheckNationLicence(sti(npchar.nation)))
				{
					link.l77 = "Vous n'auriez pas une licence de commerce de courte durée ? Peut-être laissée par un capitaine ?";
					link.l77.go = "BuyLicense";
				}
				}
			//ОЗГ
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
				if (pchar.questTemp.Headhunter == "Houm" && npchar.nation == ENGLAND)
				{
					link.l12 = "Pouvez-vous me dire si le navire Deadhead, du capitaine Hannibal Holm, a fait escale chez vous ?";
					link.l12.go = "Houm_portman_1";
				}
			}

			link.l8 = "Je viens pour une autre affaire.";
			// Warship 26.07.09 Генер "The burnt-out ship"
			if(CheckAttribute(NPChar, "Quest.BurntShip") && !CheckAttribute(NPChar, "Quest.BurntShip.LastQuestDate"))
			{
				if(CheckAttribute(NPChar, "Quest.BurntShip.TimeIsOver")) // Просрочено
				{
					link.l8.go = "BurntShip10";
				}
				else
				{
					if(CheckAttribute(NPChar, "Quest.BurntShip.TwoDaysWait"))
					{
						if(GetNpcQuestPastDayParam(NPChar, "Quest.BurntShip.TwoDaysWait") >= 2)
						{
							link.l8.go = "BurntShip17";
						}
						else
						{
							link.l8.go = "quests";
						}
					}
					else
					{
						link.l8.go = "BurntShip12";
					}
				}
			}
			else
			{
				link.l8.go = "quests";
			}
			if(CheckAttribute(pchar, "GenQuest.EncGirl"))
			{
				if(pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "portman_keeper" && pchar.GenQuest.EncGirl.LoverCity == npchar.city)
				{
					link.l9 = "Bonjour, je viens à l'invitation de votre fils.";
					link.l9.go = "EncGirl_4";
					pchar.quest.EncGirl_GetLoverFather.over = "yes";
				}
				if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
				{
					if(pchar.GenQuest.EncGirl.Father == "portman_keeper" && npchar.city == pchar.GenQuest.EncGirl.city)
					{
						link.l9 = "C'est au sujet de votre fille...";
						link.l9.go = "EncGirl_1";
					}
				}
			}
			if (CheckCharacterItem(pchar, "CaptainBook"))
			{
				if(pchar.questTemp.different == "free")
				{
					link.l10 = "Il se trouve que j'ai trouvé ce paquet de documents de bord.";
					link.l10.go = "ShipLetters_out1";
				}
				else
				{
					if(pchar.questTemp.different.GiveShipLetters.city == npchar.city)
					{
						link.l10 = "Il se trouve que j'ai trouvé un paquet de documents de bord, sans doute oublié par quelqu'un.";
						if(!CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakPortman"))
						{
							link.l10.go = "ShipLetters_Portman1_1";
						}
						else
						{
							link.l10.go = "ShipLetters_Portman2";
						}
					}
				}
			}
			if (CheckAttribute(pchar, "Whisper.ActiveChardQuest") && !CheckAttribute(pchar, "Whisper.PortmanAtSea") && GetNpcQuestPastDayWOInit(npchar, "Whisper.LastSeenPortman") > 7 && GetNpcQuestPastDayWOInit(pchar, "Whisper.LastSeenPortman") > 7)
			{
				Link.l11 = "Je cherche un capitaine nommé Ralph Portman. Avez-vous quelqu'un de ce nom dans votre registre ?";
				Link.l11.go = "Whisper_chard_quest";
			}
			if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_Search.PortOffice") && pchar.QuestTemp.TohmasPetit_Search.PortOffice == "active" && npchar.location == "BasTer_PortOffice")
			{
				link.l12 = "Mon brave, il y a environ une heure, un homme nommé Thomas Petit a dמ venir ici avec une jeune demoiselle. J'ai besoin de savoir oם ils se dirigeaient.";
				link.l12.go = "TohmasPetit_PortOfficeTalk";
			}
			Link.l15 = "Merci. Au revoir.";
			Link.l15.go = "exit";
		break;
		
		//========================  Квест "Strange things are happening in the archipelago" ==>
		case "PKM_BlackFregat":
			dialog.text = "Une frégate noire ? Le navire a-t-il un nom ? Que voulez-vous que je vous réponde, alors que mon registre répertorie tous les navires par leur nom, et non par la couleur de leur coque ? Je ne peux rien vous dire de plus.";
			link.l1 = "Désolé, je vais continuer à chercher.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_NevisPortMan_1");
		break;
		//========================  Квест "Strange things are happening in the archipelago" <==	

		case "Whisper_chard_quest":
			SaveCurrentNpcQuestDateParam(npchar, "Whisper.LastSeenPortman");
			if (!CheckAttribute(pchar, "Whisper.PortmanTries"))
			{
				pchar.Whisper.PortmanTries = 0;
			}
			pchar.Whisper.PortmanTries = sti(pchar.Whisper.PortmanTries)+1;
			if (npchar.nation != HOLLAND && npchar.nation != SPAIN)
			{
				if (sti(pchar.Whisper.PortmanTries) > 2)
				{
					WhisperSpawnPortman(npchar);
					SaveCurrentNpcQuestDateParam(pchar, "Whisper.LastSeenPortman");
					//SaveCurrentQuestDateParam("Whisper.LastSeenPortman");
					dialog.text = "Il y en avait un. Il vient de quitter le port. Il semble être parti pour la colonie de "+XI_ConvertString("Colony" + pchar.Whisper.PortmanTargetCity)+". Si vous vous dépêchez, vous pourrez peut-être encore le rattraper.";
					link.l1 = "Merci, j'y vais. Au revoir.";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Hum... Non, je n'en ai pas encore eu.";
					link.l1 = "Merci pour l'information, j'y vais. Au revoir.";
					link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "Qui ? Si c'est un Anglais, c'est peu probable. Nous ne les laissons entrer au port que dans des cas exceptionnels.";
				link.l1 = "Merci, c'est tout, j'y vais. Au revoir.";
				link.l1.go = "exit";
			}
		break;

		case "Church_GenQuest1_Node_FillFullInfo":
			dialog.text = "Votre problème se résout facilement. Adressez-vous à n'importe quel fonctionnaire du service de navigation, et vous obtiendrez toutes les informations disponibles sur la route du navire de votre ami.";
			link.l1 = "Malheureusement, ce n'est pas si simple. C'est justement dans votre port que mon ami, le capitaine " + PChar.GenQuest.ChurchQuest_1.CapFullName + " a changé le nom de son navire... pour des raisons religieuses.";
			link.l1.go = "Church_GenQuest1_Node_FillFullInfo_2";
		break;

		case "Church_GenQuest1_Node_FillFullInfo_2":
			dialog.text = "Bon. Voilà qui est plus compliqué. Je dois ressortir les inscriptions du registre des navires, cela prendra du temps. Et de nos jours, comme vous le savez, le temps, c'est de l'argent...";
			if(sti(pchar.money) >= 1000)
			{
				link.l1 = "Je le comprends parfaitement, " + GetFullName(NPChar) + ", et je suis prêt à payer pour votre temps... 1 000 pièces d'or, disons.";
				link.l1.go = "Church_GenQuest1_Node_FillFullInfo_3";
			}
			else
			{
				DeleteAttribute(pchar, "GenQuest.ChurchQuest_1.CurPortManColony"); // Можно будет спросить.
				link.l1 = "Oh... Et je n'ai pas d'argent... Je reviendrai plus tard...";
				link.l1.go = "exit";
			}
		break;

		case "Church_GenQuest1_Node_FillFullInfo_3":
			sColony = GetColonyExpect2Colonies(NPChar.city, PChar.GenQuest.ChurchQuest_1.QuestTown);
			PChar.GenQuest.ChurchQuest_1.CapGoToColony = sColony;
			if(CheckAttribute(pchar, "GenQuest.ChurchQuest_1.NoMoneyToPortMan"))
			{
				dialog.text = "Parfait ! Voyons ce que nous avons... Un instant... bien... Voilà. Le changement de nom est noté dans le registre des navires, et le navire, qui s'appelle désormais '" + PChar.GenQuest.ChurchQuest_1.CapShipName + "', est parti aujourd'hui en direction de " + XI_ConvertString("Colony" + sColony + "Gen") + ".";
				DeleteAttribute(pchar, "GenQuest.ChurchQuest_1.NoMoneyToPortMan");
			}
			else
				dialog.text = "Oh oh oh !... Je veux dire, oui, vous avez bien fait d'apprécier mon temps, car je suis quelqu'un de très, très occupé. Un instant... bien... Voilà. Le changement de nom est noté dans le registre des navires. Le navire, qui s'appelle désormais '" + PChar.GenQuest.ChurchQuest_1.CapShipName + "', est parti aujourd'hui en direction de " + XI_ConvertString("Colony" + sColony + "Gen") + ".";
				link.l1 = "Merci, monsieur, vous m'avez vraiment rendu un grand service.";
				link.l1.go = "Church_GenQuest1_Node_FillFullInfo_4";
				AddMoneyToCharacter(pchar, -1000);
		break;

		case "Church_GenQuest1_Node_FillFullInfo_4":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "4");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.CapGoToColony + "Gen"));
			AddQuestUserData(sQuestTitle, "sShipName", PChar.GenQuest.ChurchQuest_1.CapShipName);
			PChar.GenQuest.ChurchQuest_1.AskPortMan_InColony = PChar.GenQuest.ChurchQuest_1.CapGoToColony;
			PChar.GenQuest.ChurchQuest_1.CapFullInfo = true;
		break;

		case "Church_GenQuest1_Node_FillInfoOfCapColony_1":
			dialog.text = "Que voulez-vous savoir exactement ?";
			link.l1 = "Dites-moi, le navire de ce capitaine est-il entré dans votre port ?";
			link.l1.go = "Church_GenQuest1_Node_FillInfoOfCapColony_2";
		break;

		case "Church_GenQuest1_Node_FillInfoOfCapColony_2":
			PChar.GenQuest.ChurchQuest_1.CapGoToColony = GetColonyExpect2Colonies(NPChar.city, PChar.GenQuest.ChurchQuest_1.QuestTown);
			dialog.text = "Hum... Puis-je vous demander pourquoi vous le cherchez ?";
			link.l1 = "J'ai affaire à lui. S'il n'est pas passé par votre port, ou si vous ne...";
			link.l1.go = "Church_GenQuest1_Node_FillInfoOfCapColony_3";
		break;

		case "Church_GenQuest1_Node_FillInfoOfCapColony_3":
			dialog.text = "Il est venu. Mais, Dieu merci, ce matin même, il nous a enfin miséricordieusement délivrés, pauvres pécheurs, de sa compagnie, et il est parti pour " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.CapGoToColony + "Acc") + ". Et je dois l'avouer, je plains sincèrement quiconque aura affaire à lui.";
			link.l1 = "Dans ce cas, souhaitez-moi bonne chance, et merci de votre aide.";
			link.l1.go = "Church_GenQuest1_Node_FillInfoOfCapColony_4";
		break;

		case "Church_GenQuest1_Node_FillInfoOfCapColony_4":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "5");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.CapGoToColony + "Voc"));
			AddQuestUserData(sQuestTitle, "sName", PChar.GenQuest.ChurchQuest_1.CapFullName);
			PChar.GenQuest.ChurchQuest_1.AskPortMan_InColony = PChar.GenQuest.ChurchQuest_1.CapGoToColony; // Спрашиваем портмана в колонии, куда отправился кэп.
			if(rand(2) == 1)
			{
				Log_TestInfo("The next colony is the last");
				PChar.GenQuest.ChurchQuest_1.NextColonyIsLast = true; // Флаг - следующая колония будет последней
			}
		break;

		case "Church_GenQuest1_Node_CapOnThisColony_1":
			dialog.text = "Qu'est-ce qui vous intéresse exactement, "+ GetSexPhrase("monsieur", "mademoiselle") +" " + GetFullName(PChar) + " ?";
			link.l1 = "Dites-moi, ce capitaine est-il entré dans votre port ?";
			link.l1.go = "Church_GenQuest1_Node_CapOnThisColony_2";
		break;

		case "Church_GenQuest1_Node_CapOnThisColony_2":
			dialog.text = "Hum, pour être entré, il est entré... Il est si bien entré que j'attends avec impatience qu'il quitte mon malheureux port.";
			link.l1 = "Alors ce navire est toujours ici ?";
			link.l1.go = "Church_GenQuest1_Node_CapOnThisColony_3";
		break;

		case "Church_GenQuest1_Node_CapOnThisColony_3":
			dialog.text = "Oui, "+ GetSexPhrase("monseigneur", "madame") +". Tout le port, du dernier des débardeurs au chef du service de pilotage, prie pour son départ rapide et sans encombre. Le navire vient de sortir de la cale sèche, oם il a subi les réparations nécessaires, et son vaillant capitaine a réussi à se disputer avec chaque charpentier, et il a refusé trois lots de planches de choix pour le bordage. Mais demain, le Seigneur qui voit tout et qui est infiniment miséricordieux nous délivrera de ce... de ce fléau, de ce fléau à visage humain !";
			link.l1 = "Calmez-vous, monsieur " + npchar.name + ", et pensez que quelqu'un va passer un moment bien plus difficile que vous. Vous avez déjà traversé cette épreuve, alors que moi, je m'apprête à rencontrer ce capitaine... Permettez-moi de prendre congé.";
			link.l1.go = "Church_GenQuest1_Node_CapOnThisColony_4";
		break;

		case "Church_GenQuest1_Node_CapOnThisColony_4":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "6");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown));
//			PChar.GenQuest.ChurchQuest_1.NeedToDialogWithSailors = true; // Спрашиваем моряков
			PChar.GenQuest.ChurchQuest_1.NeedToDialogWithCap = true; // Говорим с капитаном
//			SetFunctionLocationCondition("Church_GenQuest1_ChangeCapitanLocation", "Deck_Near_Ship", true);
			PChar.GenQuest.ChurchQuest_1.CurPortManColony = NPChar.city;
			Group_SetAddress("ChurchGenQuest1_CapGroup", colonies[FindColony(NPChar.City)].Island, "IslandShips1", "Ship_1"); // Ставим кэпа в порту колонии
			Characters[GetCharacterIndex("ChurchGenQuest1_Cap")].Nation = sti(NPChar.Nation); // Сменим нацию, чтоб вражды не было
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.AskPortMan"); // Больше не спрашиваем
//			if(rand(1) == 0) PChar.GenQuest.ChurchQuest_1.CapWaitOnTavern = true;
			sld = CharacterFromID("ChurchGenQuest1_Cap");
			sld.DeckDialogNode = "ChurchGenQuest_1_DeckDialog_1";
		break;

		case "ShipLetters_out1":
			dialog.text = "Voyons voir ! Oui, ce lot est noté comme invalide dans mes documents. C'est très aimable à vous d'avoir pris le temps de passer me remettre ces papiers. Bon vent, capitaine !";
			link.l1 = "Merci !";
			link.l1.go = "exit";
			TakeItemFromCharacter(pchar, "CaptainBook");
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "10");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ShipLetters_Portman1_1":
			pchar.questTemp.different.GiveShipLetters.speakPortman = true;
			s1 = "Voyons voir ! Oui, ce navire et son propriétaire figurent bien dans mes documents.";
			s1 = s1 + "Votre conscience professionnelle vous honore, capitaine ! Bien sמr, vos efforts doivent être récompensés.";
			dialog.text = s1 + "Disons " + sti(pchar.questTemp.different.GiveShipLetters.price1) + " - ça vous va ?";
			link.l1 = "Bien sמr que non !";
			link.l1.go = "exit";
			link.l2 = "Eh bien, une somme bien modeste, mais le service ne l'est pas moins. Oui, j'accepte votre offre, "  + npchar.name +" .";
			link.l2.go = "ShipLetters_Portman1_2";
		break;

		case "ShipLetters_Portman1_2" :
			TakeItemFromCharacter(pchar, "CaptainBook");
			addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price1));
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "5");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ShipLetters_Portman2":
			dialog.text = "Acceptez-vous mon offre ?";
			link.l1 = "Bien sמr que non !";
			link.l1.go = "exit";
			link.l2 = "Peut-être. Même si je suis sמr que ces papiers valent plus cher.";
			link.l2.go = "ShipLetters_Portman2_1";
		break;

		case "ShipLetters_Portman2_1":
			TakeItemFromCharacter(pchar, "CaptainBook");
			addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price1));
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "6");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Je vous ai ramené votre fugitive.";
			link.l1.go = "EncGirl_2";
		break;

		case "EncGirl_2":
			dialog.text = "Ah, capitaine, merci beaucoup ! Comment va-t-elle ? Elle est en bonne santé, elle n'est pas blessée ? דa fait un jour qu'elle s'est enfuie, la malheureuse. Est-ce que je lui veux du mal ? Je veux la marier... Le fiancé est riche, jeune, et pas laid du tout, il ne faut pas faire la fine bouche. Mais non ! Elle n'en fait qu'à sa tête, tout comme sa mère, que le diable l'emporte... Et elle ne serait même pas née si sa mère ne s'était pas enfuie à l'époque avec un benêt entreprenant... Enfin, à quoi bon se souvenir... La jeunesse est naïve, sotte... et cruelle.";
			link.l1 = "Bien sמr, vous êtes son père et c'est à vous de décider, mais à votre place, je ne précipiterais pas un mariage heureux...";
			link.l1.go = "EncGirl_3";
		break;

		case "EncGirl_3":
			dialog.text = "Qu'est-ce que vous y comprenez ? Vous avez des enfants ? Non ? Alors, quand vous en aurez, revenez me voir, et on en reparlera... oui... J'ai promis une récompense à qui me la ramènerait : veuillez l'accepter.";
			link.l1 = "Merci. Et tenez-la bien. Quelque chose me dit qu'elle ne va pas s'arrêter là.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirl_ToLoverParentsExit");
		break;

		case "EncGirl_4":
			if(sti(pchar.GenQuest.EncGirl.LoverFatherAngry) == 0)
			{
				dialog.text = "Ah, c'est donc vous "+ GetSexPhrase("le capitaine qui a ramené", "la fille qui a ramené") +" mon fils prodigue avec sa jeune fiancée ?";
				link.l1 = "Oui, je les ai aidés à s'enfuir.";
				link.l1.go = "EncGirl_5";
			}
			else
			{
				dialog.text = "Ah, vous voilà enfin,"+ GetSexPhrase(" mon bienfaiteur", " ma bienfaitrice") +". Vous attendez une récompense ?";
				link.l1 = "Eh bien, pas forcément une récompense, mais un peu de gratitude ferait plaisir.";
				link.l1.go = "EncGirl_6";
			}
		break;

		case "EncGirl_5":
			dialog.text = "Je vous suis très reconnaissant de ne pas avoir abandonné mon enfant dans l'embarras et de l'avoir aidé à se tirer avec honneur d'une situation aussi délicate. Permettez-moi de vous remercier comme je le peux. Acceptez cette modeste somme et un cadeau de ma part.";
			link.l1 = "Merci, ce fut un plaisir d'aider ces jeunes gens.";
			link.l1.go = "EncGirl_5_1";
		break;

		case "EncGirl_6":
			dialog.text = "Quelle gratitude ?! De la gratitude pour quoi ?! Non seulement ce benêt traîne sans travail depuis six mois, mais en plus il a trouvé le temps de s'amouracher ! Moi, à son âge, je dirigeais déjà ma propre affaire. Et voyez-moi ça, il est parti à la chasse ! Le gouverneur a une fille à marier, et celui-ci nous ramène une traînée sans feu ni lieu, Dieu me pardonne, et il demande la bénédiction paternelle !";
			link.l1 = "Hum, vous ne croyez donc pas aux sentiments sincères ?";
			link.l1.go = "EncGirl_6_1";
		break;

		case "EncGirl_5_1":
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.EncGirl.sum));
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "18");
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_6_1":
			dialog.text = "De quels sentiments parlez-vous ?! Quels sentiments ? Un adulte, une personne comme il faut, et puis voilà... Des sentiments ! Vous devriez avoir honte, vous les jeunes, de vous livrer à de telles choses, et de jouer les entremetteurs. La fille a été arrachée au nid de ses parents et la vie de mon nigaud est ruinée. Vous n'aurez aucune gratitude de ma part. Au revoir.";
			link.l1 = "Eh bien, portez-vous bien, vous aussi...";
			link.l1.go = "EncGirl_6_2";
		break;

		case "EncGirl_6_2":
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("JungleGirl", "19");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "node_4":
			//--> проверка миниквестов начальника порта.
			if (npchar.quest == "PortmansJornal") //взят квест на судовой журнал
			{
				dialog.text = "Vous deviez trouver un capitaine nommé " + npchar.quest.PortmansJornal.capName + " et lui rendre son journal de bord. L'avez-vous fait ?";
				link.l1 = "Non, ça n'a pas encore marché...";
				link.l1.go = "PortmanQuest_NF";
				break;
			}
			if (npchar.quest == "PortmansSeekShip" || npchar.quest == "SeekShip_sink") //взят квест на поиски украденного корабля
			{
				dialog.text = "Vous êtes en train de rechercher le navire volé : " + GetStrSmallRegister(XI_ConvertString(npchar.quest.PortmansSeekShip.shipTapeName)) + " '" + npchar.quest.PortmansSeekShip.shipName + "'. Tant que vous n'aurez pas accompli cette mission, il n'est pas question de vous en confier d'autres.";
				link.l1 = "Je vais poursuivre les recherches, patientez.";
				link.l1.go = "exit";
				link.l2 = "Je veux annuler votre mission.";
				link.l2.go = "SeekShip_break";
				break;
			}
			if (npchar.quest == "SeekShip_success") //украденный корабль взят на абордаж
			{
				dialog.text = "Vous m'aviez promis de retrouver le navire volé : " + GetStrSmallRegister(XI_ConvertString(npchar.quest.PortmansSeekShip.shipTapeName)) + " '" + npchar.quest.PortmansSeekShip.shipName + "'. L'avez-vous fait ?";
				bool bOk = false;
				for (i=0; i<=COMPANION_MAX; i++)
				{
					cn = GetCompanionIndex(pchar, i);
					if(cn != -1)
					{
						sld = &characters[cn];
						if (sld.ship.name == npchar.quest.PortmansSeekShip.shipName &&
							RealShips[sti(sld.ship.type)].BaseName == npchar.quest.PortmansSeekShip.shipTapeName &&
							RealShips[sti(sld.Ship.Type)].basetype == npchar.quest.PortmansSeekShip.shipTape)
						{
							if (i == 0)
							{	//если нужный корабль - у ГГ
								sld.Ship.Type = GenerateShip(SHIP_LEUDO, true);
								SetBaseShipData(sld);
								SetCrewQuantityFull(sld);
							}
							else
							{
								RemoveCharacterCompanion(pchar, sld);
								AddPassenger(pchar, sld, false);
							}
							bOk = true;
						}
					}
				}
				if (bOk)
				{
					link.l1 = "Oui, je l'ai retrouvé, il mouille en rade dans le port. Vous pouvez le reprendre.";
					link.l1.go = "SeekShip_good";
				}
				else
				{
					link.l1 = "Je vais poursuivre les recherches, patientez.";
					link.l1.go = "exit";
				}
				link.l2 = "Je veux annuler votre mission.";
				link.l2.go = "SeekShip_break";
				break;
			}
			//<-- проверка миниквестов начальника порта.

			//--> дача миниквестов начальника порта.
			if (rand(2) < 2 && pchar.questTemp.different == "free" && GetNpcQuestPastDayWOInit(npchar, "quest.meeting") > 7)
			{
				dialog.text = LinkRandPhrase("Oui, bon sang ! J'ai un travail pour vous !",
					"Ha ! Vous tombez à pic ! J'ai un problème à régler.",
					"Bien sמr ! Bien sמr que j'ai du travail ! Les problèmes, vous savez, m'écrasent...");
				link.l1 = "Venez-en au fait, " + GetAddress_FormToNPC(NPChar) + ".";
				link.l1.go = "PortmanQuest";
				SaveCurrentNpcQuestDateParam(npchar, "quest.meeting");
				break;
			}

			// Warship 25.07.09 Генер "The burnt-out ship"
			if(dRand(4) == 2 && !CheckAttribute(NPChar, "Quest.BurntShip"))
			{
				dialog.text = "Mon Dieu ! Capitaine " + GetFullName(PChar) + ", vous tombez à pic ! Un tel malheur est arrivé, un tel malheur... Un navire confié à la capitainerie a brמlé dans notre rade ! Par la négligence de l'équipe de garde, il a brמlé... jusqu'à la ligne de flottaison.. " +
					"Seigneur, pourquoi suis-je ainsi puni ? Après tant d'années de bons et loyaux services...";
				link.l1 = "Hum, c'est inouï, un navire qui brמle. Et à quoi servent les contrats d'assurance ? Ou bien vous ne l'aviez pas assuré ? Pour faire des économies, pour ainsi dire. Et maintenant, on s'en mord les doigts, hein...";
				link.l1.go = "BurntShip4";
				link.l2 = "Pour ce genre de questions, il faut demander de l'aide au chantier naval, pas à moi. En quelques mois, on vous restaurera l'ancien, ou on vous en construira un neuf. Je ne suis pas constructeur de navires"+ GetSexPhrase("", "") +", alors désolé, vous vous trompez d'adresse...";
				link.l2.go = "BurntShip2";
				break;
			}
			//<-- дача миниквестов начальника порта.

			dialog.text = "Le gouverneur se soucie du bien-être de la ville : il a toujours du travail. Ensuite, il peut y avoir des marchands intéressés à la taverne, et le magasin affrète parfois des capitaines.";
			Link.l1 = "Encore une question.";
			Link.l1.go = "node_2";
			Link.l2 = "Merci. Au revoir.";
			Link.l2.go = "exit";
		break;


		/////////////////////////////////////////////////////////==========================/////////////////////////////////////////////////////
		//эскорт-пассажиры
		case "work_PU":
		if (iTest != -1)
		{
			rColony = GetColonyByIndex(iTest);
		}
		ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
		if(sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
		{
			if (sti(NPChar.nation) != PIRATE && GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY)
			{
				dialog.text = RandPhraseSimple("Il n'y a pas de travail ici pour ceux qui naviguent sous le pavillon de " + NationNameGenitive(sti(pchar.nation)) + " ! Quittez immédiatement mon bureau !", "Je n'ai pas l'intention de coopérer avec " + NationNameAblative(sti(pchar.nation)) + ". Fichez le camp !");
				link.l1 = RandPhraseSimple("Hum, vous avez raison...", "Eh bien, comme vous voudrez...");
				link.l1.go = "exit";
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				dialog.text = RandPhraseSimple("J'ai dans mon registre toute une liste de passagers qui attendent des navires de passage. Mais j'ai bien peur qu'il n'y ait pas parmi eux un seul idiot qui accepterait de voyager sous vos ordres. La réputation, voyez-vous, c'est une chose délicate, et une mauvaise réputation se propage dans les Caraïbes comme les ronds dans l'eau...", "On vient sans cesse me voir, des marchands qui ont besoin d'une escorte. Mais une escorte, c'est une protection, pas le risque de se faire dévaliser par sa propre escorte. Vu la réputation qui vous suit, aucun marchand ne prendrait un tel risque.");
				link.l1 = LinkRandPhrase("Quoi ?! Mais les gens mentent tous.", "Tout le monde a vraiment peur de moi ?! Oui, on dirait qu'il y a de quoi.", "Quelles gens on trouve de nos jours ! Dès qu'il n'y a personne sur qui cracher, ils courent se plaindre !");
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Je reçois des demandes de marchands et de passagers de toute la colonie, qui me demandent de leur trouver une escorte ou un navire de passage vers les différentes parties de l'archipel. Si vous cherchez quelque chose de précis, vous pouvez jeter un œil.";
			link.l1 = "Je prendrai volontiers une escorte, si c'est sur ma route.";
			link.l1.go = "work_PU_1";
			link.l2 = "Il y a beaucoup de passagers ? J'ai justement quelques cabines libres.";
			link.l2.go = "work_PU_2";
		}
		else
		{
			dialog.text = "Oם est votre navire ? Vous comptez transporter des passagers sur votre dos ?";
			link.l1 = "Hum, c'est vrai...";
			link.l1.go = "exit";
		}
		break;

		case "work_PU_1":
			if (!CheckAttribute(npchar, "work_date_PU") || GetNpcQuestPastDayParam(npchar, "work_date_PU") >= 2 || bBettaTestMode)
			{
				if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 5 || makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)) < 1)//при низком авторитете и на 7 класс не даём
				{
				dialog.text = "Désolé, mais je n'ai personne qui souhaite voyager avec vous.";
				link.l1 = "Compris. Comme vous voudrez.";
				link.l1.go = "exit";
				break;
				}
				//конвой
				if (!CheckQuestAttribute("generate_convoy_quest_progress", "begin"))
				{
					if (GetCompanionQuantity(PChar) == COMPANION_MAX)
					{
						dialog.text = "Mais votre escadre est trop grande pour une escorte. Les marchands ne voudront pas d'une telle caravane, qui risque à elle seule d'attirer une attention indésirable.";
						link.l1 = "C'est vrai, je n'y avais pas pensé. Bon, je reviendrai plus tard, si l'envie m'en prend.";
						link.l1.go = "exit";
					}
					else
					{
						if (drand(6) > 1)
						{
							dialog.text = "Je ne sais pas si ce sera sur votre route, mais j'ai justement eu un marchand qui cherchait une escorte... Ah, le voilà qui revient !";
							link.l1 = RandPhraseSimple("Vous le connaissez bien ? C'est un monsieur aisé ou un escroc ?", "Et qui est-ce ? Vaut-il la peine de traiter avec lui ?");
							link.l1.go = "ConvoyAreYouSure_PU";

						}
						else
						{
									dialog.text = "D'habitude, j'ai beaucoup de marchands qui ont besoin d'une escorte, mais en ce moment, malheureusement, il n'y a personne. Vous aurez peut-être plus de chance un autre jour.";
							link.l1 = RandPhraseSimple("D'accord, tant pis.", "Oui, pas de chance... Eh bien, au revoir.");
							link.l1.go = "exit";
						}
					}
			  	}
				else
				{
					dialog.text = "Mais vous escortez déjà quelqu'un. En cas d'attaque, vous ne pourrez pas protéger plusieurs navires à la fois : il faudra en sacrifier un. Aucun marchand n'acceptera ça. Alors terminez d'abord ce que vous avez commencé, puis revenez.";
					link.l1 = RandPhraseSimple("Quels marchands peureux on trouve de nos jours. Et dire qu'ils devraient traverser l'Atlantique tout seuls... Enfin bref, au revoir.", "Pas de chance... Bon, bonne journée.");
					link.l1.go = "exit";
					}
				}
				else
				{
				dialog.text = "Il n'y a personne aujourd'hui. Revenez dans quelques jours.";
					link.l1 = "D'accord. Comme vous voudrez.";
								link.l1.go = "exit";
				}
		break;

		case "work_PU_2":
			if (!CheckAttribute(npchar, "work_date_PU") || GetNpcQuestPastDayParam(npchar, "work_date_PU") >= 2 || bBettaTestMode)
			{
				if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 5 || makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)) < 1)//при низком авторитете и на 7 класс не даём
				{
				dialog.text = "Désolé, mais je n'ai personne qui souhaite voyager avec vous.";
				link.l1 = "Compris. Comme vous voudrez.";
				link.l1.go = "exit";
				break;
				}
				 // пассажир
				if (drand(6) > 1)
				{
					dialog.Text = "Beaucoup, pas beaucoup, mais un type est déjà venu plusieurs fois aujourd'hui, à la recherche d'un navire de passage. Tiens, le revoilà !";
					link.l1 = RandPhraseSimple("Vous pensez que ça vaut la peine de le prendre à bord ?", "Et quel genre de personne est-ce ? Vaut-il la peine de traiter avec lui ?");
					Link.l1.go = "PassangerAreYouSure_PU";
				}
				else
				{
					dialog.text = "Malheureusement, il n'y a pas de passagers aujourd'hui. Alors ne m'en voulez pas...";
					link.l1 = RandPhraseSimple("Eh bien non, ce n'est pas ça. Qu'est-ce qu'il y a là...", "Oui, pas de chance... Eh bien, au revoir.");
					link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "Il n'y a personne aujourd'hui. Revenez dans quelques jours.";
				link.l1 = "D'accord. Comme vous voudrez.";
				link.l1.go = "exit";
			}
		break;

		case "ConvoyAreYouSure_PU":
			dialog.text = RandPhraseSimple("Oui, un monsieur tout à fait respectable. Pour le prix, entendez-vous entre vous, je ne vous serai d'aucune aide.", "Dieu vous garde, je ne conseille personne. Pourvu que vous vous entendiez sur le prix.");
			Link.l1 = "Je vois. Voyons maintenant oם il doit aller.";
			Link.l1.go = "exit";
			pchar.quest.destination = findTraderCity_PU(npchar);
			pchar.ConvoyQuest.City = npchar.city;
			AddDialogExitQuest("prepare_for_convoy_quest");
			SaveCurrentNpcQuestDateParam(npchar, "work_date_PU");
		break;

		case "PassangerAreYouSure_PU":
			dialog.text = RandPhraseSimple("Oui, un passager tout à fait normal.", "Pourquoi pas ? Un monsieur plutכt aisé.");
			Link.l1 = "Merci, je vais lui parler tout de suite.";
			Link.l1.go = "exit";
			sGlobalTemp = findPassangerCity_PU(npchar);
			pchar.GenQuest.GetPassenger_City = npchar.city;
			AddDialogExitQuest("prepare_for_passenger_quest");
			SaveCurrentNpcQuestDateParam(npchar, "work_date_PU");
		break;


		case "PortmanQuest_NF":
			dialog.text = "Hum, c'est fâcheux. Dans ce cas, il n'est pas question pour moi de vous confier un nouveau travail.";
			link.l1 = "Compris. C'est ce que je voulais dire...";
			link.l1.go = "node_2";
		break;

		case "TohmasPetit_PortOfficeTalk":
			dialog.text = "Monsieur Petit ? Oui, il est bien venu, trépignant d'impatience et regardant sans cesse vers la porte. Mademoiselle LeBlanc l'accompagnait. Il m'a lancé une lourde bourse d'or en me suppliant de lui trouver au plus vite un navire sמr à destination de l'Ancien Monde.";
			link.l1 = "Et quel navire lui avez-vous recommandé ? Parlez, monsieur.";
			link.l1.go = "TohmasPetit_PortOfficeTalk_2";
		break;

		case "TohmasPetit_PortOfficeTalk_2":
			dialog.text = "Je savais que le sloop militaire « Atlantica » achevait ses derniers préparatifs pour une traversée océanique, en rade extérieure. Pour une belle somme, le capitaine a accepté de prendre des passagers. Ils ont engagé un batelier en hâte et sont montés à bord. Le sloop a déjà levé l'ancre et pris la mer, mais si peu de temps s'est écoulé qu'ils n'ont certainement pas encore quitté les eaux de l'île.";
			link.l1 = "Je vois. Merci de votre aide, monsieur, je file !";
			link.l1.go = "TohmasPetit_PortOfficeEnd";
		break;
		
		case "TohmasPetit_PortOfficeEnd":
			DialogExit();
			AddQuestRecord("TohmasPetit", "TohmasPetit_PortOfficeFound");
			DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search.PortOffice");
			AddDialogExitQuest("TohmasPetit_SpawnShipOnBattleMap"); 
			pchar.QuestTemp.TohmasPetit_Quest = "search_ship";
		break;

		// Warship 25.07.09 Генер "The burnt-out ship"
		/*case "BurntShip1":
			dialog.text = "You're right, Captain, but the thing is, there's little hope of help... A ship burned down in our raid, left in the care of the port authority! By an oversight of the security team, it burned down... up to the waterline" +
				"Lord, why am I being punished like this? After all, so many years of faith and truth...";
			link.l1 = "Okay, my dear, let's do everything in order, otherwise we won't agree on anything.";
			link.l1.go = "BurntShip3";
			link.l2 = "With such questions, you need to go to the shipyard for help, not to me. In a couple of months, at least the old will be restored, at least a new one will be built. I am not a shipbuilder"+ GetSexPhrase("", "nice") +", so sorry, wrong address...";
			link.l2.go = "BurntShip2";
		break;*/

		case "BurntShip2":
			dialog.text = "Je suis navré, capitaine... Dommage que vous ne vouliez pas m'aider.";
			link.l1 = "Ce n'est pas une question d'envie, mon cher. Vous le comprenez bien... Au revoir...";
			link.l1.go = "exit";
			NPChar.Quest.BurntShip.LastQuestDate = sLastSpeakDate;
		break;

		/*case "BurntShip3":
			dialog.text = "Yes, yes, Captain. In general, the misfortune is terrible... Nothing like this has happened in my long career. Only Providence and your good will can save us.";
			link.l1 = "Hmm, this is unprecedented - the ship burned down. And what are the insurance contracts for? Or have you not insured it? in order to save money, so to speak. And now we'd like to bite your elbow, yes...";
			link.l1.go = "BurntShip4";
		break;*/

		case "BurntShip4":
			dialog.text = "Que dites-vous là, capitaine ?! Craignez Dieu !.. Comment pouvez-vous ?! Je connais bien mon métier, je sers ici depuis tant d'années. Et il y a des contrats d'assurance, et la compagnie d'assurance est prête à payer, et la somme assurée est considérable, je vous l'assure.";
			link.l1 = "Mon cher, alors quel est votre problème ? La soute aux poudres a explosé dans l'incendie, des gens ont été blessés, et on vous poursuit pour négligence ?";
			link.l1.go = "BurntShip5";
		break;

		case "BurntShip5":
			sCapitainId = GenerateRandomName(sti(NPChar.nation), "man");

			dialog.text = "Eh bien, ce qui n'est pas arrivé n'est pas arrivé : le Seigneur a été miséricordieux, sinon on m'aurait fait sauter la tête. La cale était vide, Dieu merci, et la Sainte Vierge Marie !" +
				"Et tout le problème, c'est que le navire appartient à quelqu'un... ou plutכt, il appartenait à un gentilhomme bien connu des Caraïbes, " + sCapitainId + ". Et il avait été construit en Europe sur commande spéciale, avec des caractéristiques extraordinaires. " +
				"Et le propriétaire était très fier de ce navire, il s'en vantait partout oם il allait, une sorte d'imbécile, Dieu me pardonne... Qu'est-ce que je vais lui dire maintenant ? Il n'y a plus qu'à se passer la corde au cou, par Dieu...";
			link.l1 = "Oh, je vois que vous êtes dans de beaux draps. Et qu'avait-il de spécial, comparé à tous les autres navires ? Autrement dit, de quoi ce gentilhomme était-il si fier, dans son bateau ?";
			link.l1.go = "BurntShip6";

			NPChar.Quest.BurntShip.ShipOwnerName = sCapitainId;
		break;

		case "BurntShip6":
			BurntShipQuest_FillStartParams(NPChar);

			attrL = NPChar.Quest.BurntShip.ShipAttribute;
			iTest = sti(NPChar.Quest.BurntShip.ShipType);

			switch(attrL)
			{
				case "speedrate":
					attrL = "" + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].Name + "Gen")) + ", sa vitesse dépassait " + NPChar.Quest.BurntShip.ShipNeededValue + " nœuds. Pour un corsaire, c'était sa plus grande fierté... Il dit déjà à ses gars de me pendre à la vergue ! C'est le diable qui l'a amené dans notre port avec sa baille de pirate...";
				break;

				case "turnrate":
					attrL = "" + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].Name + "Gen")) + ", sa maniabilité dépassait " + NPChar.Quest.BurntShip.ShipNeededValue + " unités. Pour un militaire, c'était sa plus grande fierté... Il parle de me faire passer par les verges ! C'est le diable qui lui a soufflé de me confier son navire...";
				break;

				case "capacity":
					attrL = "" + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].Name + "Gen")) + ", son port en lourd dépassait " + NPChar.Quest.BurntShip.ShipNeededValue + " unités de déplacement. Pour un marchand, c'était sa plus grande fierté... Il va m'écarteler sans procès. C'est le diable qui l'a poussé à me confier sa baille !";
				break;
			}

			dialog.text = attrL;
			link.l1 = "Que dit-on au chantier naval ? C'est vraiment impossible d'en construire un pareil ici ?";
			link.l1.go = "BurntShip7";
		break;

		case "BurntShip7":
			dialog.text = "Personne ne veut s'en charger. Je suis même allé supplier sur l'île voisine. On dit qu'il y a un maître de renom aux Bermudes. Mais nous sommes ici, et les Bermudes sont loin. Il ne reste plus qu'à compter sur l'aide de capitaines indépendants comme vous. Après tout, vous coulez ces bailles par dizaines. Il ne vous sera peut-être pas difficile de me trouver un bateau semblable. Et nous le retoucherons ici, nous l'arrangerons pour que le propriétaire n'ait pas à se plaindre " +
				"Je vous remercierai généreusement, et la compagnie d'assurance ne sera pas avare. C'est une affaire hors du commun, vous savez. Qui voudrait tomber en disgrâce auprès d'un gentilhomme aussi influent ?";
			link.l1 = "Oui, ce n'est pas simple. De combien de temps je dispose ?";
			link.l1.go = "BurntShip8";
			link.l2 = "Non, mon cher, je ne vais pas m'en charger. Et personne ne peut garantir qu'il existe un navire aux caractéristiques semblables. Ne l'oubliez pas...";
			link.l2.go = "BurntShip2";
		break;

		case "BurntShip8":
			dialog.text = "Dieu merci, nous avons le temps. Le propriétaire est parti pour l'Europe et ne reviendra pas avant six mois.";
			link.l1 = "Bon, j'accepte. Je vous livrerai un navire semblable. Mais n'oubliez pas : si vous commencez à faire le radin et à marchander, je le brמle sous vos yeux !";
			link.l1.go = "BurntShip9";
		break;

		case "BurntShip9":
			dialog.text = "Que dites-vous là, capitaine ? Comment pourrais-je ? Je comprends bien que ce n'est pas une baille qu'on repêche dans la première flaque venue, cela prendra du temps... Amenez seulement le navire, et nous serons quittes. Soyez tranquille...";
			link.l1 = "Je l'espère... Attendez-moi avec de bonnes nouvelles. Au revoir.";
			link.l1.go = "BurntShip9_exit";
		break;

		case "BurntShip9_exit":
			attrL = "BurntShipQuest_TimeIsOver_" + NPChar.Id;
			PChar.Quest.(attrL).win_condition.l1 = "Timer";
			PChar.Quest.(attrL).win_condition.l1.date.day = GetAddingDataDay(0, 120, 0);
			PChar.Quest.(attrL).win_condition.l1.date.month = GetAddingDataMonth(0, 120, 0);
			PChar.Quest.(attrL).win_condition.l1.date.year = GetAddingDataYear(0, 120, 0);
			PChar.Quest.(attrL).function = "BurntShipQuest_TimeIsOver";
			PChar.Quest.(attrL).PortmanId = NPChar.id;

			attrL = NPChar.Quest.BurntShip.ShipAttribute;

			iTest = sti(NPChar.Quest.BurntShip.ShipType);

			switch(attrL)
			{
				case "speedrate":
					attrL = "vitesse. Le navire de type " + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].name + "Gen")) + " doit atteindre une vitesse d'au moins " + NPChar.Quest.BurntShip.ShipNeededValue;
				break;

				case "turnrate":
					attrL = "maniabilité. Le navire de type " + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].name + "Gen")) + " doit avoir une maniabilité d'au moins " + NPChar.Quest.BurntShip.ShipNeededValue;
				break;

				case "capacity":
					attrL = "cale. Le navire de type " + GetStrSmallRegister(XI_ConvertString(ShipsTypes[iTest].name + "Gen")) + " doit avoir une cale d'au moins " + NPChar.Quest.BurntShip.ShipNeededValue;
				break;
			}

			sTitle = "BurntShipQuest" + NPChar.location;
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "BurntShipQuest", "1");
			AddQuestUserDataForTitle(sTitle, "cityName", XI_ConvertString("Colony" + NPChar.city + "Voc"));
			AddQuestUserData(sTitle, "portmanName", GetFullName(NPChar));
			AddQuestUserData(sTitle, "cityName", XI_ConvertString("Colony" + NPChar.city + "Gen"));
			AddQuestUserData(sTitle, "text", attrL);

			NPChar.Quest.BurntShip.LastPortmanName = GetFullName(NPChar); // Запомнм имя

			DialogExit();
		break;

		// Вариант, когда не уложились в сроки
		case "BurntShip10":
			dialog.text = "De quoi vouliez-vous parler ?";
			link.l1 = "Oם est l'ancien capitaine du port, monsieur " + NPChar.Quest.BurntShip.LastPortmanName + " ? J'ai affaire à lui.";
			link.l1.go = "BurntShip11";
		break;

		case "BurntShip11":
			dialog.text = "Mais il n'est plus là... Vous imaginez ? Il a brמlé le navire d'un gentilhomme célèbre et empoché l'argent de l'assurance. Le temps que les autorités comprennent ce qui se passait, il avait déjà démissionné et filé en Europe. Quelle canaille, hein ?";
			link.l1 = "Oui, je connais cette histoire. Excusez-moi, je dois y aller...";
			link.l1.go = "BurntShip11_exit";
		break;

		case "BurntShip11_exit":
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "Fortune", 100);
			sTitle = "BurntShipQuest" + NPChar.location;
			AddQuestRecordEx(sTitle, "BurntShipQuest", "2");
			AddQuestUserData(sTitle, "portmanName", NPChar.Quest.BurntShip.LastPortmanName);
			CloseQuestHeader(sTitle);

			DeleteAttribute(NPChar, "Quest.BurntShip");
			NPChar.Quest.BurntShip.LastQuestDate = sLastSpeakDate;

			DialogExit();
		break;

		// Не просрочено - проверяем корабль
		case "BurntShip12":
			dialog.text = "De quoi vouliez-vous parler ?";
			link.l1 = "J'ai amené un navire aux caractéristiques extraordinaires. J'attends la récompense promise.";
			link.l1.go = "BurntShip14";
			link.l2 = "Vous savez, " + GetFullName(NPChar) + ", je ne vois aucun navire ayant les caractéristiques que vous avez commandées. Je crois que je vais renoncer à cette mission. Désolé si je vous déçois...";
			link.l2.go = "BurntShip13";
		break;

		case "BurntShip13":
			dialog.text = "Je suis navré, capitaine... Dommage que vous ne vouliez pas m'aider.";
			link.l1 = "Ce n'est pas une question d'envie, mon cher. Vous le comprenez bien... Au revoir...";
			link.l1.go = "BurntShip13_exit";
		break;

		case "BurntShip13_exit":
			sTitle = "BurntShipQuest" + NPChar.location;
			CloseQuestHeader(sTitle);

			ChangeCharacterReputation(PChar, -5);
			DeleteAttribute(NPChar, "Quest.BurntShip");
			NPChar.Quest.BurntShip.LastQuestDate = sLastSpeakDate;

			DialogExit();
		break;

		case "BurntShip14":
			dialog.text = "Voilà qui est bien ! Et comment s'appelle notre nouveau navire ?";

			sTitle = NPChar.Quest.BurntShip.ShipAttribute;

			ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);

			if(sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				for(i = 1; i < COMPANION_MAX; i++)
				{
					cn = GetCompanionIndex(PChar, i);

					if(cn > 0)
					{
						chref = GetCharacter(cn);

						sld = &RealShips[sti(chref.ship.type)];

						if(GetRemovable(chref) && sti(sld.basetype) == sti(NPchar.Quest.BurntShip.ShipType) &&
							stf(sld.(sTitle)) >= stf(NPChar.Quest.BurntShip.ShipNeededValue))
						{
							attrL = "l" + i;
							Link.(attrL) = chref.Ship.Name;
							Link.(attrL).go = "BurntShip15";
						}
					}
				}
			}

			link.l99 = "Désolé, je reviendrai plus tard.";
			link.l99.go = "exit";
		break;

		case "BurntShip15":
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "Fortune", 100);
			dialog.text = "Ah, capitaine, je suis heureux de ne pas m'être trompé sur votre compte ! Vous avez fait du beau travail, vous venez de me sauver la vie... Revenez chercher l'argent dans deux jours, je vous prie. Il faut régler les formalités, vous savez, pour toucher l'argent de l'assurance... En attendant, remettez le navire en état. Les voiles à changer, les trous à colmater, un carénage, encore une fois, ne fera pas de mal...";
			link.l99 = "Vous avez oublié ce que je vous ai promis exactement, en cas de retard de paiement ?";
			link.l99.go = "BurntShip16";
		break;

		case "BurntShip16":
			dialog.text = "Non, non, Dieu m'en garde ! Je tiendrai parole, ne vous inquiétez pas. C'est simplement que, sachant qu'il y aurait encore des frais pour, pour ainsi dire, maquiller le navire, j'ai placé l'argent de l'assurance à intérêt. Ne vous méprenez pas...";
			link.l1 = "Je vous comprendrai quand les piastres seront dans mon coffre. א plus tard.";
			link.l1.go = "BurntShip16_exit";
		break;

		case "BurntShip16_exit":
			sTitle = "BurntShipQuest" + NPChar.location;
			AddQuestRecordEx(sTitle, "BurntShipQuest", "3");

			NPChar.Quest.BurntShip.TwoDaysWait = true;
			SaveCurrentNpcQuestDateParam(NPChar, "Quest.BurntShip.TwoDaysWait"); // Запомним дату

			sTitle = "BurntShipQuest" + NPChar.Id;
			PChar.Quest.(sTitle).over = "yes"; // Завершаем прерывание на время

			DialogExit();
		break;

		case "BurntShip17":
			dialog.text = "De quoi vouliez-vous parler ?";
			link.l1 = "Je viens chercher ma récompense. J'ai toujours le navire qu'il vous faut.";
			link.l1.go = "BurntShip18";
		break;

		case "BurntShip18":
			dialog.text = "Rappelez-moi son nom, je vous prie. Avec tous ces tracas, voyez-vous, je n'ai plus du tout de mémoire.";

			sTitle = NPChar.Quest.BurntShip.ShipAttribute;
			ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);

			if(sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				for(i = 1; i < COMPANION_MAX; i++)
				{
					cn = GetCompanionIndex(PChar, i);

					if(cn > 0)
					{
						chref = GetCharacter(cn);

						sld = &RealShips[sti(chref.ship.type)];

						if(GetRemovable(chref) && sti(sld.basetype) == sti(NPchar.Quest.BurntShip.ShipType) &&
							stf(sld.(sTitle)) >= stf(NPChar.Quest.BurntShip.ShipNeededValue))
						{
							attrL = "l" + i;
							Link.(attrL) = chref.Ship.Name;
							Link.(attrL).go = "BurntShip19_" + i;
						}
					}
				}
			}

			link.l99 = "Désolé, je reviendrai plus tard.";
			link.l99.go = "exit";
		break;

		case "BurntShip19":
			sld = &Characters[GetCompanionIndex(PChar, sti(NPChar.Quest.BurntShip.ShipCompanionIndex))];
			cn = GetShipSellPrice(sld, CharacterFromID(NPChar.city + "_shipyarder")) * 1.2;
			rRealShip = GetRealShip(GetCharacterShipType(sld));//почему считается цена привезенного корабля, а не цена сгоревшего? :)
			if (sti(rRealShip.Stolen)) cn *= 2;//"ворованные" компенсируются
			dialog.text = "Oui, parfait ! Je suis prêt à vous verser votre récompense, " + FindRussianMoneyString(cn) + ". C'est à ce montant que la compagnie d'assurance a estimé le navire brמlé. L'assurance a été payée en coffres de crédit : il n'y a pas d'argent liquide, désolé.";
			link.l1 = "Ah non, cette somme ne me convient pas. Je suis sמr que ce navire vaut bien plus cher.";
			link.l1.go = "BurntShip21";
			link.l2 = "דa, c'est une tout autre affaire. C'est une joie d'avoir pu vous aider. א plus tard.";
			link.l2.go = "BurntShip20_exit";

			NPChar.Quest.BurntShip.Money = cn;

			//sTitle = "BurntShipQuest" + NPChar.location;
			//PChar.Quest.(sTitle).over = "yes"; // Завершаем прерывание на время
		break;

		case "BurntShip20_exit":
			//AddMoneyToCharacter(PChar, sti(NPChar.Quest.BurntShip.Money));
			TakeNItems(pchar, "chest", makeint((sti(NPChar.Quest.BurntShip.Money) + 7500)/15000));
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			sTitle = "BurntShipQuest" + NPChar.location;
			AddQuestRecordEx(sTitle, "BurntShipQuest", "4");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "money", NPChar.Quest.BurntShip.Money);
			CloseQuestHeader(sTitle);

			ChangeCharacterReputation(PChar, 3);

			sld = &Characters[GetCompanionIndex(PChar, sti(NPChar.Quest.BurntShip.ShipCompanionIndex))];
			RemoveCharacterCompanion(PChar, sld);
			AddPassenger(PChar, sld, false);

			DeleteAttribute(NPChar, "Quest.BurntShip");
			NPChar.Quest.BurntShip.LastQuestDate = sLastSpeakDate;

			DialogExit();
		break;

		case "BurntShip21":
			dialog.text = "Allons, capitaine, que dites-vous là ?! Croyez-moi, je sais de quoi je parle. Avec une somme pareille, on pourrait acheter deux navires semblables !";
			link.l1 = "Je préfère le garder pour moi. Il m'a vraiment plu... Au revoir.";
			link.l1.go = "BurntShip21_exit";
		break;

		case "BurntShip21_exit":
			ChangeCharacterReputation(PChar, -5);

			sTitle = "BurntShipQuest" + NPChar.location;
			AddQuestRecordEx(sTitle, "BurntShipQuest", "5");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "money", NPChar.Quest.BurntShip.Money);
			CloseQuestHeader(sTitle);

			DeleteAttribute(NPChar, "Quest.BurntShip");
			NPChar.Quest.BurntShip.LastQuestDate = sLastSpeakDate;

			DialogExit();
		break;

		//--> миниквесты портмана
		case "PortmanQuest":
			if (cRand(2) == 2)
			{	//квест догнать и передать судовой журнал
				dialog.text = "Un capitaine a oublié son journal de bord chez moi. Comment peut-on être aussi distrait !.. Bref, il faut le rattraper et lui rendre son bien.";
				link.l1 = "Oui, c'est possible... J'accepte ce travail !";
				link.l1.go = "PortmanQuest_1";
				link.l2 = "Non, je ne veux pas m'en occuper. Ce sont ses problèmes, après tout...";
				link.l2.go = "node_2";
			}
			else
			{	//квест разыскать украденный корабль
				dialog.text = "On a volé un navire dans mon parc de stationnement. Je veux que vous le retrouviez et que vous me le rameniez.";
				link.l1 = "Hum, eh bien, je suis prêt à me lancer dans les recherches.";
				link.l1.go = "SeekShip_1";
				link.l2 = "Désolé, mais je ne cherche pas de navires.";
				link.l2.go = "node_2";
			}
		break;
		// -------------------------------- квест доставки судового журнала до рассеяного кэпа --------------------------
		case "PortmanQuest_1":
			dialog.text = "Parfait, voici son journal de bord... Ouf, quel soulagement ! La perte d'un journal de bord est une chose désagréable, je m'inquiète pour ce genre de capitaines.";
			link.l1 = "דa, c'est sמr, il y a de quoi s'inquiéter ! Eh bien, parlez-moi un peu plus de ce capitaine distrait.";
			link.l1.go = "PortmanQuest_2";
			pchar.questTemp.different = "PortmansJornal";
			SetTimerFunction("SmallQuests_free", 0, 0, 0); //освобождаем разрешалку на миниквесты
			SetJornalCapParam(npchar);
			GiveItem2Character(pchar, "PortmansBook");
			pchar.questTemp.PortmansJornal.gem = GenQuestPortman_GenerateGem();
		break;
		case "PortmanQuest_2":
			dialog.text = "Oui, bien sמr ! Il s'appelle " + npchar.quest.PortmansJornal.capName + " - il commande un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.PortmansJornal.shipTapeName + "Gen")) + " nommé '" + npchar.quest.PortmansJornal.shipName + "'. Il a pris la mer récemment, en direction de " + XI_ConvertString("Colony" + npchar.quest.PortmansJornal.city + "Acc") + ".";
			link.l1 = "Compris. Eh bien, je le trouverai, c'est certain. Et pour la rémunération ?";
			link.l1.go = "PortmanQuest_3";
		break;
		case "PortmanQuest_3":
			dialog.text = npchar.quest.PortmansJornal.capName + " réglera ses comptes avec vous, c'est dans son intérêt. Essayez seulement de le trouver vite, et tout ira bien.";
			link.l1 = "Compris. Eh bien, au revoir...";
			link.l1.go = "exit";
			sTitle = npchar.id + "PortmansBook_Delivery";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "PortmansBook_Delivery", "1");
			AddQuestUserDataForTitle(sTitle, "sCapName", npchar.quest.PortmansJornal.capName);
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.PortmansJornal.shipTapeName + "Acc")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.PortmansJornal.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.PortmansJornal.capName);
			AddQuestUserData(sTitle, "sCapName2", npchar.quest.PortmansJornal.capName);
			AddQuestUserData(sTitle, "sTargetCity", XI_ConvertString("Colony" + npchar.quest.PortmansJornal.city + "Acc"));
			if (GetIslandByCityName(npchar.quest.PortmansJornal.city) != npchar.quest.PortmansJornal.city)
			{
				AddQuestUserData(sTitle, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(npchar.quest.PortmansJornal.city) + "Voc"));
			}
		break;
		// -------------------------------- квест розыска украденного корабля ----------------------------------
		case "SeekShip_1":
			dialog.text = "Parfait ! Vous savez, le navire volé n'appartient pas à n'importe qui, c'est donc très important pour moi. Je paierai bien pour ce travail...";
			link.l1 = "Compris. Racontez-nous plus en détail de quel navire il s'agissait, et dans quelles circonstances il a été volé.";
			link.l1.go = "SeekShip_2";
			pchar.questTemp.different = "PortmansSeekShip";
			SetTimerFunction("SmallQuests_free", 0, 0, 0); //освобождаем разрешалку на миниквесты
			SetSeekShipCapParam(npchar);
		break;
		case "SeekShip_2":
			dialog.text = XI_ConvertString(npchar.quest.PortmansSeekShip.shipTapeName) + " nommé '" + npchar.quest.PortmansSeekShip.shipName + "'. Il a été volé de nuit, il y a " + FindRussianDaysString(rand(5)+10) + " de cela. Le gardien a été tué.";
			link.l1 = "Hum, ils ont déjà dמ partir bien loin. En tout cas, on ne peut plus parler de piste fraîche...";
			link.l1.go = "SeekShip_3";
			link.l2 = LinkRandPhrase("Désolé, mais je ne peux pas accomplir cette mission de confiance...", "Non, ça ne me convient pas...", "Malheureusement, je dois renoncer aux recherches...");
			link.l2.go = "SeekShip_Icantfindship";
		break;
		case "SeekShip_Icantfindship":
			dialog.text = "Je suis navré, " + GetAddress_Form(npchar) + "... Je comptais beaucoup sur vous...";
			link.l1 = "Encore désolé... Au revoir.";
			link.l1.go = "exit";
			sTemp = "SeekShip_checkAbordage" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание на абордаж
			cn = GetCharacterIndex("SeekCap_" + npchar.index);
			//если кэп-вор ещё жив - убираем его
			if (cn > 0)
			{
				characters[cn].LifeDay = 0;
				Map_ReleaseQuestEncounter(characters[cn].id);
				group_DeleteGroup("SeekCapShip_" + characters[cn].index);
			}
			DeleteAttribute(npchar, "quest.PortmansSeekShip");
			npchar.quest = ""; //освобождаем личный флаг квеста для портмана

			ChangeCharacterReputation(pchar, -2);
		break;
		case "SeekShip_3":
			dialog.text = "Oui, c'est exact. Mais ça ne servait à rien que je sème la panique tout de suite. Si les militaires le rattrapent, ils réduiront le navire en miettes, et ce n'est pas vraiment ce qu'il me faut.";
			link.l1 = "Compris. Bon, je commence les recherches. J'espère avoir de la chance.";
			link.l1.go = "exit";
			sTitle = npchar.id + "Portmans_SeekShip";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "Portmans_SeekShip", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.PortmansSeekShip.shipTapeName)));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.PortmansSeekShip.shipName);
		break;
		case "SeekShip_break":
			dialog.text = "Hum, eh bien, c'est dommage. Même s'il était difficile de compter sur un succès...";
			link.l1 = "Oui, trop de temps a passé depuis le vol.";
			link.l1.go = "SeekShip_break_1";
		break;
		case "SeekShip_break_1":
			dialog.text = "Eh bien, merci de votre aide, même si elle n'a pas abouti.";
			link.l1 = "Je vous en prie...";
			link.l1.go = "exit";
			sTemp = "SeekShip_checkAbordage" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание на абордаж
			cn = GetCharacterIndex("SeekCap_" + npchar.index);
			//если кэп-вор ещё жив - убираем его
			if (cn > 0)
			{
				characters[cn].LifeDay = 0;
				Map_ReleaseQuestEncounter(characters[cn].id);
				group_DeleteGroup("SeekCapShip_" + characters[cn].index);
			}
			sTitle = npchar.id + "Portmans_SeekShip";
			AddQuestRecordEx(sTitle, "Portmans_SeekShip", "7");
			CloseQuestHeader(sTitle);
			DeleteAttribute(npchar, "quest.PortmansSeekShip");
			npchar.quest = ""; //освобождаем личный флаг квеста для портмана
			ChangeCharacterReputation(pchar, -7);
		break;
		case "SeekShip_good":
			if (npchar.quest == "SeekShip_sink")
			{
				dialog.text = "Parfait ! Cela dit, je crois que ce n'est pas tout à fait le navire qui a été volé... Encore que, au fond, peu importe ! Je vous le prends.";
				link.l1 = "Oui, en effet...";
				//npchar.quest.money = makeint(sti(npchar.quest.money) / 4); //снижаем оплату
				ChangeCharacterReputation(pchar, 5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 10);
				AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 10);
				AddCharacterExpToSkill(GetMainCharacter(), "Sailing", 10);
				AddCharacterExpToSkill(GetMainCharacter(), "Commerce", 50);
				AddCharacterExpToSkill(GetMainCharacter(), "Cannons", 20);
			}
			else
			{
				dialog.text = "Excellent ! Vous m'avez été d'une grande aide. J'imagine combien ça a dמ être difficile.";
				link.l1 = "Oui, en effet...";
				ChangeCharacterReputation(pchar, 10);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
				AddCharacterExpToSkill(GetMainCharacter(), "Leadership", 100);
				AddCharacterExpToSkill(GetMainCharacter(), "Sailing", 150);
				AddCharacterExpToSkill(GetMainCharacter(), "Grappling", 100);
			}
			link.l1.go = "SeekShip_good_1";
		break;
		case "SeekShip_good_1":
			dialog.text = "Je suis prêt à vous verser une récompense. Elle s'élève à " + FindRussianMoneyString(makeint(sti(npchar.quest.chest)*15000)) + " en coffres. Malheureusement, je ne peux pas payer plus.";
			link.l1 = "Eh bien, c'est suffisant. Merci, et bonne journée.";
			link.l1.go = "exit";
			//AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, "chest", sti(npchar.quest.chest));
			sTitle = npchar.id + "Portmans_SeekShip";
			AddQuestRecordEx(sTitle, "Portmans_SeekShip", "6");
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			DeleteAttribute(npchar, "quest.PortmansSeekShip");
			npchar.quest = ""; //освобождаем личный флаг квеста для портмана
		break;

		//------------------------------> инфа по базе квествых кэпов
		//ВНИМАНИЕ. в квестбук должна заносится типовая строка по примеру   PortmansBook_Delivery  #TEXT   5
		//в список портмана заносим тайтл, заголовок и номер строки из quest_text.txt
		//ПРИМЕР: в конце метода  void SetCapitainFromCityToSea(string qName)
		case "BuyLicense":
				dialog.text = "Non, capitaine, je ne m'occupe pas de ce genre de papiers. Pour une licence de commerce, adressez-vous à la Compagnie néerlandaise des Indes occidentales : ses représentants sont à Marigot et à Willemstad. Ils ont même une licence universelle, valable pour toutes les nations.";
				link.l1 = "Je vois. Merci du tuyau.";
				link.l1.go = "exit";
		break;
		case "CapitainList":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) > 0)
			{
				dialog.text = "Il y a des capitaines inscrits. Lequel vous intéresse ?";
				for (i=0; i<GetAttributesNum(arCapBase); i++)
				{
					arCapLocal = GetAttributeN(arCapBase, i);
					sCapitainId = GetAttributeName(arCapLocal);
					sld = characterFromId(sCapitainId);
					attrL = "l" + i;
					link.(attrL) = GetFullName(sld) + ", capitaine d'un navire de type " + GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Gen")) + " '" + sld.Ship.name + "'.";
					link.(attrL).go = "CapList_"+attrL;
				}
			}
			else
			{
				dialog.text = "Je n'ai sur ma liste aucun capitaine susceptible de vous intéresser.";
				link.l1 = "Compris. Merci pour l'information.";
				link.l1.go = "node_2";
			}
		break;
		case "CapList_l0":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) <= 0) {
				trace("ERROR: capitainsList is empty")
				link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
				link.l2.go = "node_2";
				break;
			}
			arCapLocal = GetAttributeN(arCapBase,  0);
			sCapitainId = GetAttributeName(arCapLocal);
			sld = characterFromId(sCapitainId);
			dialog.text = LinkRandPhrase("Oui, voyons voir... Oui, il y en a un ! ", "Bon, bon... oui, je l'ai trouvé !", "Alors voilà. ") +
				"Capitaine " + GetFullName(sld) + ", le " + arCapLocal.date + ", a quitté notre port pour " + XI_ConvertString("Colony" + arCapLocal + "Acc") + ".";
			link.l1 = "Merci. J'aimerais voir la suite de la liste...";
			link.l1.go = "CapitainList";
			link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
			link.l2.go = "node_2";
			//заносим запись в СЖ
			AddQuestRecordEx(arCapLocal.QBString1, arCapLocal.QBString2, arCapLocal.QBQty);
			AddQuestUserData(arCapLocal.QBString1, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(arCapLocal.QBString1, "sCapName", GetFullName(sld));
			AddQuestUserData(arCapLocal.QBString1, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Voc")));
			AddQuestUserData(arCapLocal.QBString1, "sShipName", sld.Ship.name);
			AddQuestUserData(arCapLocal.QBString1, "sDate", arCapLocal.date);
			AddQuestUserData(arCapLocal.QBString1, "sTargetCity", XI_ConvertString("Colony" + arCapLocal + "Acc"));
			if (GetIslandByCityName(arCapBase.(sCapitainId)) != arCapBase.(sCapitainId))
			{
				AddQuestUserData(arCapLocal.QBString1, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(arCapBase.(sCapitainId)) + "Voc"));
			}
			//убираем из списка
			DeleteAttribute(arCapBase, sCapitainId);
		break;
		case "CapList_l1":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) <= 1) {
				trace("ERROR: capitainsList is empty")
				link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
				link.l2.go = "node_2";
				break;
			}
			arCapLocal = GetAttributeN(arCapBase,  1);
			sCapitainId = GetAttributeName(arCapLocal);
			sld = characterFromId(sCapitainId);
			dialog.text = LinkRandPhrase("Oui, jetons un œil... Oui, il y en a un ! ", "Bon, bon... oui, je l'ai trouvé !", "Alors voilà. ") +
				"Capitaine " + GetFullName(sld) + ", le " + arCapLocal.date + ", a quitté notre port pour " + XI_ConvertString("Colony" + arCapLocal + "Acc") + ".";
			link.l1 = "Merci. J'aimerais voir la suite de la liste...";
			link.l1.go = "CapitainList";
			link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
			link.l2.go = "node_2";
			//заносим запись в СЖ
			AddQuestRecordEx(arCapLocal.QBString1, arCapLocal.QBString2, arCapLocal.QBQty);
			AddQuestUserData(arCapLocal.QBString1, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(arCapLocal.QBString1, "sCapName", GetFullName(sld));
			AddQuestUserData(arCapLocal.QBString1, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Voc")));
			AddQuestUserData(arCapLocal.QBString1, "sShipName", sld.Ship.name);
			AddQuestUserData(arCapLocal.QBString1, "sDate", arCapLocal.date);
			AddQuestUserData(arCapLocal.QBString1, "sTargetCity", XI_ConvertString("Colony" + arCapLocal + "Acc"));
			if (GetIslandByCityName(arCapBase.(sCapitainId)) != arCapBase.(sCapitainId))
			{
				AddQuestUserData(arCapLocal.QBString1, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(arCapBase.(sCapitainId)) + "Voc"));
			}
			//убираем из списка
			DeleteAttribute(arCapBase, sCapitainId);
		break;
		case "CapList_l2":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) <= 2) {
				trace("ERROR: capitainsList is empty")
				link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
				link.l2.go = "node_2";
				break;
			}
			arCapLocal = GetAttributeN(arCapBase,  2);
			sCapitainId = GetAttributeName(arCapLocal);
			sld = characterFromId(sCapitainId);
			dialog.text = LinkRandPhrase("Oui, voyons voir... Oui, il y en a un ! ", "Bon, bon... oui, je l'ai trouvé !", "Alors voilà. ") +
				"Capitaine " + GetFullName(sld) + ", le " + arCapLocal.date + ", a quitté notre port pour " + XI_ConvertString("Colony" + arCapLocal + "Acc") + ".";
			link.l1 = "Merci. J'aimerais voir la suite de la liste...";
			link.l1.go = "CapitainList";
			link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
			link.l2.go = "node_2";
			//заносим запись в СЖ
			AddQuestRecordEx(arCapLocal.QBString1, arCapLocal.QBString2, arCapLocal.QBQty);
			AddQuestUserData(arCapLocal.QBString1, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(arCapLocal.QBString1, "sCapName", GetFullName(sld));
			AddQuestUserData(arCapLocal.QBString1, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Voc")));
			AddQuestUserData(arCapLocal.QBString1, "sShipName", sld.Ship.name);
			AddQuestUserData(arCapLocal.QBString1, "sDate", arCapLocal.date);
			AddQuestUserData(arCapLocal.QBString1, "sTargetCity", XI_ConvertString("Colony" + arCapLocal + "Acc"));
			if (GetIslandByCityName(arCapBase.(sCapitainId)) != arCapBase.(sCapitainId))
			{
				AddQuestUserData(arCapLocal.QBString1, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(arCapBase.(sCapitainId)) + "Voc"));
			}
			//убираем из списка
			DeleteAttribute(arCapBase, sCapitainId);
		break;
		case "CapList_l3":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) <= 3) {
				trace("ERROR: capitainsList is empty")
				link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
				link.l2.go = "node_2";
				break;
			}
			arCapLocal = GetAttributeN(arCapBase,  3);
			sCapitainId = GetAttributeName(arCapLocal);
			sld = characterFromId(sCapitainId);
			dialog.text = LinkRandPhrase("Oui, jetons un œil... Oui, il y en a un ! ", "Bon, bon... oui, je l'ai trouvé !", "Alors voilà. ") +
				"Capitaine " + GetFullName(sld) + ", le " + arCapLocal.date + ", a quitté notre port pour " + XI_ConvertString("Colony" + arCapLocal + "Acc") + ".";
			link.l1 = "Merci. J'aimerais voir la suite de la liste...";
			link.l1.go = "CapitainList";
			link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
			link.l2.go = "node_2";
			//заносим запись в СЖ
			AddQuestRecordEx(arCapLocal.QBString1, arCapLocal.QBString2, arCapLocal.QBQty);
			AddQuestUserData(arCapLocal.QBString1, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(arCapLocal.QBString1, "sCapName", GetFullName(sld));
			AddQuestUserData(arCapLocal.QBString1, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Voc")));
			AddQuestUserData(arCapLocal.QBString1, "sShipName", sld.Ship.name);
			AddQuestUserData(arCapLocal.QBString1, "sDate", arCapLocal.date);
			AddQuestUserData(arCapLocal.QBString1, "sTargetCity", XI_ConvertString("Colony" + arCapLocal + "Acc"));
			if (GetIslandByCityName(arCapBase.(sCapitainId)) != arCapBase.(sCapitainId))
			{
				AddQuestUserData(arCapLocal.QBString1, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(arCapBase.(sCapitainId)) + "Voc"));
			}
			//убираем из списка
			DeleteAttribute(arCapBase, sCapitainId);
		break;
		case "CapList_l4":
			makearef(arCapBase, npchar.quest.capitainsList);
			if (GetAttributesNum(arCapBase) <= 4) {
				trace("ERROR: capitainsList is empty")
				link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
				link.l2.go = "node_2";
				break;
			}
			arCapLocal = GetAttributeN(arCapBase,  4);
			sCapitainId = GetAttributeName(arCapLocal);
			sld = characterFromId(sCapitainId);
			dialog.text = LinkRandPhrase("Oui, jetons un œil... Oui, il y en a un ! ", "Bon, bon... oui, je l'ai trouvé !", "Alors voilà. ") +
				"Capitaine " + GetFullName(sld) + ", le " + arCapLocal.date + ", a quitté notre port pour " + XI_ConvertString("Colony" + arCapLocal + "Acc") + ".";
			link.l1 = "Merci. J'aimerais voir la suite de la liste...";
			link.l1.go = "CapitainList";
			link.l2 = "C'est tout, les capitaines ne m'intéressent plus.";
			link.l2.go = "node_2";
			//заносим запись в СЖ
			AddQuestRecordEx(arCapLocal.QBString1, arCapLocal.QBString2, arCapLocal.QBQty);
			AddQuestUserData(arCapLocal.QBString1, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(arCapLocal.QBString1, "sCapName", GetFullName(sld));
			AddQuestUserData(arCapLocal.QBString1, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(sld.Ship.Type)].BaseName + "Voc")));
			AddQuestUserData(arCapLocal.QBString1, "sShipName", sld.Ship.name);
			AddQuestUserData(arCapLocal.QBString1, "sDate", arCapLocal.date);
			AddQuestUserData(arCapLocal.QBString1, "sTargetCity", XI_ConvertString("Colony" + arCapLocal + "Acc"));
			if (GetIslandByCityName(arCapBase.(sCapitainId)) != arCapBase.(sCapitainId))
			{
				AddQuestUserData(arCapLocal.QBString1, "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(arCapBase.(sCapitainId)) + "Voc"));
			}
			//убираем из списка
			DeleteAttribute(arCapBase, sCapitainId);
		break;
		//<--------------------------- инфа по базе квествых кэпов

		case "PortStock_UI": // стоянка кораблей через интерфейс portstock
				ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);
				if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
				{
					NextDiag.CurrentNode = NextDiag.TempNode;
					DialogExit();
					LaunchPortStock(NPChar);
				}
				else
				{
					dialog.text = "Hum. Je ne vois pas vos navires au port.";
					Link.l1 = "Oui, je voulais juste me renseigner sur les possibilités de stationnement.";
					Link.l1.go = "exit";
				}
		break;

		case "PortAuction_UI": // LEO: аукцион (продажа корабля) через интерфейс portauction
				ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);
				if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
				{
					NextDiag.CurrentNode = NextDiag.TempNode;
					DialogExit();
					LaunchPortAuction(NPChar);
				}
				else
				{
					dialog.text = "Hum. Je ne vois pas vos navires au port.";
					Link.l1 = "Oui, je voulais juste me renseigner sur la vente aux enchères.";
					Link.l1.go = "exit";
				}
		break;

		case "ShipStock_1":
				ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);
				if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
				{
					dialog.text = "Quel navire voulez-vous laisser, exactement ?";
					for(i=1; i<COMPANION_MAX; i++)//почему нельзя свой единственный корабль сдать?
					{
						cn = GetCompanionIndex(PChar, i);
						if(cn > 0)
						{
							chref = GetCharacter(cn);
							if (!GetRemovable(chref)) continue;
							if(RealShips[sti(chref.Ship.Type)].BaseName == SHIP_SOLEYRU) continue; //Отрубаем хитрость на получение Солея

							attrL = "l"+i;
							Link.(attrL)	= XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "'. Je pense laisser avec lui le capitaine " + GetFullName(chref) + ".";
							Link.(attrL).go = "ShipStockMan11_" + i;
							attrL = "l"+i+COMPANION_MAX;
							Link.(attrL)	= XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "' sans officier.";
							Link.(attrL).go = "ShipStockMan22_" + i;

						}
					}
					Link.l17 = "Merci, ce n'est pas nécessaire.";
					Link.l17.go = "exit";
				}
				else
				{
					dialog.text = "Hum. Je ne vois pas vos navires au port.";
					Link.l1 = "Je voulais juste me renseigner sur les possibilités de stationnement.";
					Link.l1.go = "exit";
				}
		break;

		case "ShipStock_Choose":
			dialog.text = "Voyons de quel navire il s'agit.";
			Link.l1 = "Bien.";
			Link.l1.go = "ShipStock_2";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "ShipStock_2":
			chref = GetCharacter(sti(NPChar.ShipToStoreIdx));
			NPChar.StoreUnlimited = 0; // monthly storage by default
			if (pchar.location != "Caiman_PortOffice")  NPChar.MoneyForShip = GetPortManPriceExt(NPChar, chref);
			else NPChar.MoneyForShip = 0;
			if (pchar.location != "Caiman_PortOffice")
			{
				dialog.Text = XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "', classe " + RealShips[sti(chref.Ship.Type)].Class +
					 ", coמt du stationnement : " + FindRussianMoneyString(sti(NPChar.MoneyForShip)) + " par mois, payables d'avance. Ou bien un mouillage définitif pour un versement unique de " + FindRussianMoneyString(sti(NPChar.MoneyForShip)*6) + " – et vous n'aurez plus jamais à payer.";
			}
			else
			{
				dialog.Text = XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "', classe " + RealShips[sti(chref.Ship.Type)].Class +
					 ", le stationnement est gratuit.";
			}
			Link.l1 = "Oui, au mois. דa me convient.";
			if (sti(Pchar.Money) >= sti(NPChar.MoneyForShip))
			{
				Link.l1.go = "ShipStock_3";
			}
			else
			{
				Link.l1.go = "ShipStock_NoMoney";
			}
			if (pchar.location != "Caiman_PortOffice")
			{
				Link.l2 = "Je le laisse pour une durée illimitée, au sextuple du prix.";
				if (sti(Pchar.Money) >= sti(NPChar.MoneyForShip)*3)
				{
					Link.l2.go = "ShipStock_3_Unlim";
				}
				else
				{
					Link.l2.go = "ShipStock_NoMoney";
				}
			}
			Link.l3 = "Non, j'ai changé d'avis.";
			Link.l3.go = "exit";
		break;

		case "ShipStock_NoMoney":
			dialog.text = "Tout me conviendra aussi, si vous avez la somme qu'il faut.";
			Link.l1 = "Oups... Je reviendrai plus tard.";
			Link.l1.go = "exit";
		break;

		case "ShipStock_3":
			if (sti(NPChar.StoreUnlimited)) AddMoneyToCharacter(pchar, -makeint(NPChar.MoneyForShip)*6); // indefinite - triple price, one time
			else AddMoneyToCharacter(pchar, -makeint(NPChar.MoneyForShip));
			if (sti(NPChar.StoreWithOff))
			{
			chref = GetCharacter(sti(NPChar.ShipToStoreIdx));
			chref.ShipInStockMan = NPChar.id;
			// Warship 22.03.09 fix Не перенеслось с КВЛ 1.2.3
			chref.ShipInStockMan.MoneyForShip = NPChar.MoneyForShip;
			chref.ShipInStockMan.AltDate = GetQuestBookDataDigit(); // для печати
			SaveCurrentNpcQuestDateParam(chref, "ShipInStockMan.Date"); // для расчёта
			//chref.Ship.Crew.Quantity  = 0;
			RemoveCharacterCompanion(pchar, chref);
			}
			else
			{
			chref = GetCharacter(NPC_GenerateCharacter("ShipInStockMan", "PKM_rab_"+(rand(3)+1), "man", "man", rand(5)+1, NPChar.nation, -1, false));
			chref.id = chref.id + "_" + chref.index; //меняем ID на оригинальный
			chref.reputation = 10 + rand(80);
			chref.lastname = chref.name;//"watchman Ivan" лучше чем "watchman Ivanov"?
			chref.name = "le gardien";
			DeleteAttribute(chref, "ship");
			chref.ship = "";

			chref.ShipInStockMan = NPChar.id;
			chref.ShipInStockMan.MoneyForShip = NPChar.MoneyForShip;
			chref.ShipInStockMan.AltDate = GetQuestBookDataDigit(); // для печати
			SaveCurrentNpcQuestDateParam(chref, "ShipInStockMan.Date"); // для расчёта

			compref = GetCharacter(sti(NPChar.ShipToStoreIdx));//компаньон, у которого надо забрать корабль

			makearef(arTo, chref.ship);
			makearef(arFrom, compref.Ship);
			CopyAttributes(arTo, arFrom);

			compref.ship.type = SHIP_NOTUSED;
			RemoveCharacterCompanion(pchar, compref);
			AddPassenger(pchar, compref, false);
			DelBakSkill(compref);
			}

			if (sti(NPChar.StoreUnlimited)) chref.ShipInStockMan.Unlimited = true; // indefinite storage - no fee on retrieval

			chref.location = "";
			chref.location.group = "";
			chref.location.locator = "";
			NPChar.Portman	= sti(NPChar.Portman) + 1;
			pchar.ShipInStock = sti(pchar.ShipInStock) + 1;//разобраться - что это. не могу найти, где оно используется.

			dialog.text = "D'accord. Vous pourrez le récupérer quand vous en aurez besoin.";
			Link.l1 = "Merci.";
			Link.l1.go = "exit";
		break;

		case "ShipStockReturn_1":
			ok = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				if (GetCompanionQuantity(pchar) < COMPANION_MAX)
				{
					dialog.text = "Quel navire ?";
					cn = 1;
					for(i=1; i<MAX_CHARACTERS; i++)
					{
						makeref(chref, Characters[i]);
						if (CheckAttribute(chref, "ShipInStockMan"))
						{
							if (chref.ShipInStockMan == NPChar.id)
							{
								attrL = "l"+cn;
								if(HasSubStr(chref.id, "ShipInStockMan_"))
								{
								Link.(attrL)	= XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "'.";
								Link.(attrL).go = "ShipStockManBack22_" + i;
								}
								else
								{
								Link.(attrL)	= XI_ConvertString(RealShips[sti(chref.Ship.Type)].BaseName) + " '" + chref.Ship.Name + "' et l'officier " + GetFullName(chref) + ".";
								Link.(attrL).go = "ShipStockManBack11_" + i;
								}
								cn++;
							}
						}
					}

					Link.l99 = "Non, j'ai changé d'avis.";
					Link.l99.go = "exit";
				}
				else
				{
					dialog.text = "Votre escadre est trop grande. Il n'y a plus assez de place pour vos navires dans la rade.";
					Link.l1 = "Oui, c'est vrai. Je le récupérerai une autre fois.";
					Link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "Hum. Je ne vois pas votre navire amiral au port. Et vous ne pouvez récupérer vos navires qu'ici.";
				Link.l1 = "D'accord, je reviendrai les chercher plus tard.";
				Link.l1.go = "exit";
			}
		break;
	  	case "ShipStockManBack":
			chref = GetCharacter(sti(NPChar.ShipToStoreIdx));
			NPChar.MoneyForShip =  GetNpcQuestPastMonthParam(chref, "ShipInStockMan.Date") * sti(chref.ShipInStockMan.MoneyForShip);
			if (CheckAttribute(chref, "ShipInStockMan.Unlimited")) NPChar.MoneyForShip = 0; // indefinite storage already paid for

			//if (sti(NPChar.StoreWithOff)) string sTextAdd = ""; else string sTextAdd = "And which of your officers will take him away?";

			if (sti(NPChar.MoneyForShip) > 0)
			{
				dialog.Text = "Vous le reprenez ? Il vous reste à payer pour le stationnement " + FindRussianMoneyString(sti(NPChar.MoneyForShip)) + ".";
			}
			else
			{
				dialog.Text = "Vous le reprenez ?";
			}
			if (sti(NPChar.MoneyForShip) <= sti(pchar.Money))
			{
				Link.l1 = "Oui.";
				Link.l1.go = "ShipStockManBack2";
			}
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "ShipStockManBack2":
			if (sti(NPChar.StoreWithOff))
			{
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

			AddMoneyToCharacter(Pchar, -sti(NPChar.MoneyForShip));
			chref = GetCharacter(sti(NPChar.ShipToStoreIdx));
			DownCrewExp(chref,GetNpcQuestPastDayParam(chref, "ShipInStockMan.Date"));
			DeleteAttribute(chref, "ShipInStockMan");
			SetCompanionIndex(pchar, -1, sti(NPChar.ShipToStoreIdx));

			NPChar.Portman	= sti(NPChar.Portman) - 1;
			pchar.ShipInStock = sti(pchar.ShipInStock) - 1;
			}
			else
			{
			dialog.Text = "א lequel de vos officiers dois-je le confier ?";
			int _curCharIdx;
			int q = 0;
			int nListSize = GetPassengersQuantity(pchar);
			for(i=0; i<nListSize; i++)
				{
				_curCharIdx = GetPassenger(pchar,i);
				sld = GetCharacter(_curCharIdx);
					if (_curCharIdx!=-1)
					{
						ok = CheckAttribute(&characters[_curCharIdx], "prisoned") && sti(characters[_curCharIdx].prisoned) == true;
						if (!CheckAttribute(sld,"HPminusDaysNeedtoRestore"))
						{
							if (!ok && GetRemovable(&characters[_curCharIdx]) && characters[_curCharIdx].id != "pet_crab")
							{
								attrL = "l"+i;
								sProf = "";
								if (IsOfficer(sld)) sProf += " (combattant)";
								if (sti(pchar.Fellows.Passengers.navigator) == sti(sld.index)) sProf += " (navigateur)";
								if (sti(pchar.Fellows.Passengers.boatswain) == sti(sld.index)) sProf += " (maître d'équipage)";
								if (sti(pchar.Fellows.Passengers.cannoner) == sti(sld.index)) sProf += " (canonnier)";
								if (sti(pchar.Fellows.Passengers.doctor) == sti(sld.index)) sProf += " (médecin)";
								if (sti(pchar.Fellows.Passengers.carpenter) == sti(sld.index)) sProf += " (charpentier)";
							    if (sti(pchar.Fellows.Passengers.treasurer) == sti(sld.index)) sProf += " (trésorier)";
								Link.(attrL)	= GetFullName(&characters[_curCharIdx]) + sProf;
								Link.(attrL).go = "ShipStockManBack2_" + i;
								q++;
							}
						}
					}
				}
			attrL = "l"+nListSize;
			if (q == 0)
				{
				Link.(attrL) = RandSwear() + "J'ai oublié d'amener un capitaine pour ce navire.";
				Link.(attrL).go = "exit";
				}
			else
				{
				Link.(attrL) = "Non, j'ai changé d'avis.";
				Link.(attrL).go = "exit";
				}
			}
		break;

		//ОЗГ, Хоум
		case "Houm_portman_1":
			if (pchar.questTemp.Headhunter.City == npchar.city)
			{
				dialog.text = "Oui, il a fait escale. Vous pouvez trouver le capitaine qui vous intéresse en ville.";
				link.l1 = "Merci ! Vous m'avez beaucoup aidé.";
				link.l1.go = "Houm_portman_yes";
			}
			else
			{
				dialog.text = "Non, c'est la première fois que j'en entends parler.";
				link.l1 = "Hum... D'accord, nous continuerons à chercher.";
				link.l1.go = "exit";
			}
		break;

		case "Houm_portman_yes":
			pchar.questTemp.Headhunter = "houm_tavern";
			CreateHoum();
			AddQuestRecord("Headhunt", "5");
			AddQuestUserData("Headhunt", "sCity", pchar.questTemp.Headhunter.Cityname);
			DialogExit();
		break;
		//ОЗГ, Хоум
	}
}

float BurntShipQuest_GetMaxNeededValue(int iShipType, string _param)
{
	float NeededValue = makefloat(GetBaseShipParamFromType(iShipType, _param));
	switch (_param)
	{
		case "speedrate":
			NeededValue += ((0.33 + frandSmall(0.27)) * (NeededValue/10.0));
		break;
		case "turnrate":
			NeededValue += ((0.33 + frandSmall(0.28)) * (NeededValue/10.0));
		break;
		case "capacity":
			NeededValue += ((0.33 + frandSmall(0.28)) * (NeededValue/8.0));
		break;
	}
	return NeededValue;
}


// Warship 25.07.09 Генер "The burnt-out ship.". Начальные иниты для портмана - тип разыскиваемого судна, выдающаяся характеристика и т.д.
void BurntShipQuest_FillStartParams(ref _npchar)
{
	int rank = sti(PChar.rank);
	int shipType, temp;
	float neededValue;
	String shipAttribute;
	ref rBaseShip;

	// TODO Пересмотреть зависимость от ранга
	if (rank < 5) temp = 6;
	if (rank >= 5 && rank < 10) temp = 5;
	if (rank >= 10 && rank < 15) temp = 4;
	if (rank >= 15 && rank < 20) temp = 3;
	if (rank >= 20 && rank < 30) temp = 2;
	if (rank >= 30) temp = 1;
	shipType = GetShipTypeExtNotNation(temp, temp, "", sti(_npchar.Nation));
	rBaseShip = GetShipByType(shipType);
	temp = 0;
	if (rBaseShip.Type.Merchant == true) temp++;//для торговых и универсальных рандом от 1 до 2, для военных от 0 до 1
	switch(temp+rand(1))
	{
		case 0: shipAttribute = "turnrate"; break;
		case 1: shipAttribute = "speedrate"; break;
		case 2: shipAttribute = "capacity"; break;
	}

	neededValue = BurntShipQuest_GetMaxNeededValue(shipType, shipAttribute);

	Log_TestInfo("shipType == " + shipType);
	Log_TestInfo("ShipAttribute == " + shipAttribute);
	Log_TestInfo("ShipNeededValue == " + neededValue);

	_npchar.Quest.BurntShip.ShipType = shipType;
	_npchar.Quest.BurntShip.ShipAttribute = shipAttribute;

	if(shipAttribute != "capacity") // Чтобы трюм с десятичными не писался
	{
		_npchar.Quest.BurntShip.ShipNeededValue = FloatToString(neededValue, 2);
	}
	else
	{
		_npchar.Quest.BurntShip.ShipNeededValue = MakeInt(neededValue);
	}
}


void SetJornalCapParam(ref npchar)
{
	//созадем рассеянного кэпа
	int iNation = sti(npchar.nation);
	if (iNation == PIRATE) iNation = rand(3);//если берем этот квест у пиратов, заменяем нацию капитана на другую, чтоб было возможно мирно поговорить
	ref sld = GetCharacter(NPC_GenerateCharacter("PortmansCap_" + npchar.index, "", "man", "man", 20, iNation, -1, true));
	SetCaptanModelByEncType(sld, "trade");
	SetShipToFantom(sld, "trade", true);
	sld.Ship.Mode = "trade";
	sld.dialog.filename = "Quest\ForAll_dialog.c";
	sld.dialog.currentnode = "PortmansCap";
	sld.DeckDialogNode = "PortmansCap_inDeck";
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER_OWN);
	//в морскую группу кэпа
	string sGroup = "PorpmansShip_" + sld.index;
	Group_FindOrCreateGroup(sGroup);
	Group_SetType(sGroup, "trade");
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	//записываем данные в структуры портмана и кэпа
	npchar.quest = "PortmansJornal"; //личный флаг квеста для портмана
	npchar.quest.PortmansJornal.capName = GetFullName(sld); //имя кэпа
	npchar.quest.PortmansJornal.shipName = sld.Ship.name; //имя корабля
	npchar.quest.PortmansJornal.shipTapeName = RealShips[sti(sld.Ship.Type)].BaseName; //название корабля
	npchar.quest.PortmansJornal.city = SelectNotEnemyColony(sld); //определим колонию, куда ушёл кэп
	sld.quest = "InMap"; //личный флаг рассеянного кэпа
	sld.quest.targetCity = npchar.quest.PortmansJornal.city; //продублируем колонию-цель в структуру кэпа
	sld.quest.firstCity = npchar.city; //капитану знать откуда вышел в самом начале
	sld.quest.stepsQty = 1; //количество выходов в море
	sld.quest.money = ((sti(RealShips[sti(sld.Ship.Type)].basetype)+1) * 150) + (sti(pchar.rank)*150); //вознаграждение
	Log_TestInfo("The Absent-minded Cap " + sld.id + " headed to: " + sld.quest.targetCity);
	//определим бухту, куда ставить энкаунтер. чтобы сразу не генерился перед ГГ у города
	string sTemp = GetArealByCityName(npchar.city);
	sld.quest.baseShore = GetIslandRandomShoreId(sTemp);
	//на карту
	sld.mapEnc.type = "trade";
	sld.mapEnc.worldMapShip = "Galleon_red"; //стояла модель кораблекрушенца
	sld.mapEnc.Name = XI_ConvertString(npchar.quest.PortmansJornal.shipTapeName) + " '" + npchar.quest.PortmansJornal.shipName + "'";
	int daysQty = GetMaxDaysFromIsland2Island(sTemp, GetArealByCityName(sld.quest.targetCity)) + 1; //дней доехать даём с запасом
	Map_CreateTrader(sld.quest.baseShore, sld.quest.targetCity, sld.id, daysQty);
	//заносим Id кэпа в базу нпс-кэпов
	sTemp = sld.id;
	NullCharacter.capitainBase.(sTemp).quest = "jornal"; //идентификатор квеста
	NullCharacter.capitainBase.(sTemp).questGiver = "none"; //запомним Id квестодателя для затирки в случае чего
	NullCharacter.capitainBase.(sTemp).Tilte1 = npchar.id + "PortmansBook_Delivery"; //заголовок квестбука
	NullCharacter.capitainBase.(sTemp).Tilte2 = "PortmansBook_Delivery"; //имя квеста в квестбуке
	NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
	NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
	NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
	NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
}
//проверить список отметившихся квестовых кэпов
int CheckCapitainsList(ref npchar)
{
	int bResult = 0;
	if (!CheckAttribute(npchar, "quest.capitainsList")) return bResult;
	aref arCapBase, arCapLocal;
	makearef(arCapBase, npchar.quest.capitainsList);
	int	Qty = GetAttributesNum(arCapBase);
	if (Qty < 1) return bResult;
	string sCapitainId;
	for (int i=0; i<Qty; i++)
	{
		arCapLocal = GetAttributeN(arCapBase, i);
		sCapitainId = GetAttributeName(arCapLocal);
		if (GetCharacterIndex(sCapitainId) > 0) //если ещё жив
		{
			bResult++;
		}
		else
		{
			DeleteAttribute(arCapBase, sCapitainId);
			i--;
			Qty--;
		}
	}
	if (bResult > 5) bResult = 5;
	return bResult;
}

void SetSeekShipCapParam(ref npchar)
{
	//создаём кэпа-вора
	int Rank = sti(pchar.rank) + 5;
	if (Rank > 30) Rank = 30;
	ref sld = GetCharacter(NPC_GenerateCharacter("SeekCap_" + npchar.index, "", "man", "man", Rank, PIRATE, -1, true));
	SetCaptanModelByEncType(sld, "pirate");
	SetShipToFantom(sld, "pirate", true);
	sld.Ship.Mode = "pirate";
	sld.dialog.filename = "Quest\ForAll_dialog.c";
	sld.dialog.currentnode = "SeekCap";
	sld.DeckDialogNode = "SeekCap_inDeck";
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	SetCharacterPerk(sld, "FastReload");
	SetCharacterPerk(sld, "HullDamageUp");
	SetCharacterPerk(sld, "SailsDamageUp");
	SetCharacterPerk(sld, "CrewDamageUp");
	SetCharacterPerk(sld, "CriticalShoot");
	SetCharacterPerk(sld, "LongRangeShoot");
	SetCharacterPerk(sld, "CannonProfessional");
	SetCharacterPerk(sld, "ShipDefenseProfessional");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "StormProfessional");
	SetCharacterPerk(sld, "SwordplayProfessional");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "CriticalHit");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "Tireless");
	SetCharacterPerk(sld, "HardHitter");
	SetCharacterPerk(sld, "GunProfessional");
	//в морскую группу кэпа
	string sGroup = "SeekCapShip_" + sld.index;
	Group_FindOrCreateGroup(sGroup);
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	//записываем данные в структуры портмана и кэпа
	npchar.quest = "PortmansSeekShip"; //личный флаг квеста для портмана
	npchar.quest.PortmansSeekShip.capName = GetFullName(sld); //имя кэпа-вора
	npchar.quest.PortmansSeekShip.shipName = sld.Ship.name; //имя украденного корабля
	npchar.quest.PortmansSeekShip.shipTapeName = RealShips[sti(sld.Ship.Type)].BaseName; //название украденного корабля
	npchar.quest.PortmansSeekShip.shipTape = RealShips[sti(sld.Ship.Type)].basetype; //тип украденного корабля
	//npchar.quest.money = ((sti(RealShips[sti(sld.Ship.Type)].basetype)+1) * 1000) + (sti(pchar.rank)*500); //вознаграждение
	npchar.quest.chest = 7-sti(RealShips[sti(sld.Ship.Type)].Class); //в сундуках
	sld.quest = "InMap"; //личный флаг кэпа-вора
	sld.city = SelectAnyColony(npchar.city); //определим колонию, откуда кэп-вор выйдет
	sld.quest.targetCity = SelectAnyColony2(npchar.city, sld.city); //определим колонию, куда он придёт
	Log_TestInfo("Cap Thief " + sld.id + " exited: " + sld.city + " and headed to: " + sld.quest.targetCity);
	sld.quest.cribCity = npchar.city; //город, откуда кэп-вор спёр корабль
	//на карту
	sld.mapEnc.type = "trade";
	sld.mapEnc.worldMapShip = "Galleon_red";
	sld.mapEnc.Name = XI_ConvertString(npchar.quest.PortmansSeekShip.shipTapeName) + " '" + npchar.quest.PortmansSeekShip.shipName + "'";
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sld.quest.targetCity), GetArealByCityName(sld.city)) + 1; //дней доехать даём с запасом
	Map_CreateTrader(sld.city, sld.quest.targetCity, sld.id, daysQty);
	//прерывание на абордаж
	string sTemp = "SeekShip_checkAbordage" + npchar.index;
	pchar.quest.(sTemp).win_condition.l1 = "Character_Capture";
	pchar.quest.(sTemp).win_condition.l1.character = sld.id;
	pchar.quest.(sTemp).function = "SeekShip_checkAbordage";
	pchar.quest.(sTemp).CapId = sld.id;
	//прерывание на потопление без абордажа
	sTemp = "SeekShip_checkSink" + npchar.index;
	pchar.quest.(sTemp).win_condition.l1 = "Character_sink";
	pchar.quest.(sTemp).win_condition.l1.character = sld.id;
	pchar.quest.(sTemp).function = "SeekShip_checkSink";
	pchar.quest.(sTemp).CapId = sld.id;
	//заносим Id кэпа в базу нпс-кэпов
	sTemp = sld.id;
	NullCharacter.capitainBase.(sTemp).quest = "robber"; //идентификатор квеста
	NullCharacter.capitainBase.(sTemp).questGiver = "none"; //запомним Id квестодателя для затирки в случае чего
	NullCharacter.capitainBase.(sTemp).Tilte1 = npchar.id + "Portmans_SeekShip"; //заголовок квестбука
	NullCharacter.capitainBase.(sTemp).Tilte2 = "Portmans_SeekShip"; //имя квеста в квестбуке
	NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
	NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
	NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
	NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
}

string GenQuestPortman_GenerateGem() // камни
{
	string itemID;
	switch(rand(5))
	{
		case 0:
			itemID = "jewelry1";
		break;
		case 1:
			itemID = "jewelry2";
		break;
		case 2:
			itemID = "jewelry3";
		break;
		case 3:
			itemID = "jewelry3";
		break;
		case 4:
			itemID = "jewelry5";
		break;
		case 5:
			itemID = "jewelry17";
		break;
	}
	return itemID;
}

string findTraderCity_PU(ref NPChar)
{
	int n, nation;
	int storeArray[MAX_COLONIES];
	int howStore = 0;

	for(n=0; n<MAX_COLONIES; n++)
	{
		if (colonies[n].id != "Panama" && colonies[n].nation != "none" && GetIslandByCityName(npchar.city) != colonies[n].islandLable) //на свой остров
		{
			nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
			if(nation != RELATION_ENEMY)
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
	}
	if (howStore == 0) return "none";
	nation = storeArray[cRand(howStore-1)];
	return colonies[nation].id;
}

string findPassangerCity_PU(ref NPChar)
{
	int n, nation;
	int storeArray[MAX_COLONIES];
	int howStore = 0;

	for(n=0; n<MAX_COLONIES; n++)
	{
		nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
		if (nation != RELATION_ENEMY && colonies[n].nation != "none" && colonies[n].id != "Panama" && GetIslandByCityName(npchar.city) != colonies[n].islandLable) //на свой остров
		{
			storeArray[howStore] = n;
			howStore++;
		}
	}
	if (howStore == 0) return "none";
	nation = storeArray[cRand(howStore-1)];
	return colonies[nation].id;
}

void DelBakSkill(ref _compref)
{
	DelBakSkillAttr(pchar);
	ClearCharacterExpRate(pchar);
	RefreshCharacterSkillExpRate(pchar);
	SetEnergyToCharacter(pchar);

	DelBakSkillAttr(_compref);
	ClearCharacterExpRate(_compref);
	RefreshCharacterSkillExpRate(_compref);
	SetEnergyToCharacter(_compref);
}
