# -*- coding: utf-8 -*-
"""French localisation pipeline for Corsairs Ship Pack (Storm engine).

  python fr.py status                 progress per domain / file
  python fr.py next [maxchars] [filter]   writes work/batch.txt (untranslated units, priority order) and prints it
  python fr.py import <file>          imports "id<TAB>french" lines into the translation memories (tm/)
  python fr.py build                  (re)generates every French game file from the English ones + tm/

Translation memories (tm/):
  tm/dialogs.json               english literal (or GetSexPhrase pair) -> french   (all .c script files)
  tm/texts/<file>.json          key -> french          (RESOURCE/INI/texts/english/*.txt, common.ini)
  tm/questbook/<file>.json      "QUEST|TEXT" -> french (Program/questbook/english/*.txt)
"""
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from cparse import scan_literals, CYR, LETTERS  # noqa: E402
from frenc import to_game                        # noqa: E402

BASE = os.path.abspath(os.path.join(HERE, '..'))           # FR_Traduction
ROOT = os.path.abspath(os.path.join(BASE, '..'))           # game root
TM_DIR = os.path.join(BASE, 'tm')
WORK = os.path.join(BASE, 'work')

P_TEXTS_EN = os.path.join(ROOT, 'RESOURCE', 'INI', 'texts', 'english')
P_TEXTS_FR = os.path.join(ROOT, 'RESOURCE', 'INI', 'texts', 'french')
P_DLG_EN = os.path.join(ROOT, 'Program', 'DIALOGS', 'english')
P_DLG_RU = os.path.join(ROOT, 'Program', 'DIALOGS', 'russian')
P_DLG_FR = os.path.join(ROOT, 'Program', 'DIALOGS', 'french')
P_QB_EN = os.path.join(ROOT, 'Program', 'questbook', 'english')
P_QB_FR = os.path.join(ROOT, 'Program', 'questbook', 'french')

NL = '¶'   # newline marker in batch files
TAB = '⇥'

# files of RESOURCE/INI/texts that hold settings, not text
TEXT_SKIP = {'partitionsettings.txt', 'mods_on_off_file.txt'}

# --------------------------------------------------------------------------- utils

def rd(p):
    return open(p, 'rb').read().decode('utf-8-sig', 'replace')


def wr(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(s.encode('utf-8'))


def jload(p, default=None):
    if os.path.exists(p):
        return json.load(open(p, encoding='utf-8'))
    return {} if default is None else default


def jsave(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=0, sort_keys=False)
    os.replace(tmp, p)


def rel(p, base):
    return os.path.relpath(p, base).replace(os.sep, '/')

# --------------------------------------------------------------------------- dialogs (.c)

ID_CTX_RE = re.compile(
    r'(\.go\s*=\s*$|CurrentNode\s*=\s*$|TempNode\s*=\s*$|==\s*$|!=\s*$|\bcase\s*$|#include\s*$|'
    r'\.(id|model|location|group|locator|ani|sex|city|nation|from|to|Dialog\.Filename|FileDialog2?)\s*=\s*$)',
    re.I)
ID_FUNCS = {
    'checkattribute', 'deleteattribute', 'characterfromid', 'getcharacterindex', 'changecharacteraddressgroup',
    'changecharacteraddress', 'playsound', 'playvoice', 'playstereosound', 'setquestheader', 'closequestheader',
    'takeitemfromcharacter', 'giveitem2character', 'takenitems', 'checkcharacteritem', 'getcharacteritem',
    'removecharacterequip', 'equipcharacterbyitem', 'setcharacterperk', 'checkcharacterperk', 'dialogexit',
    'npc_generatecharacter', 'getcharacter', 'setfunctiontimercondition', 'settimercondition',
    'setfunctionlocationcondition', 'doquestcheckdelay', 'doquestfunctiondelay', 'locatorreloadenterdisable',
    'findlocation', 'xi_convertstring', 'getconvertstr', 'languageconvertstring', 'itemsfromid', 'getitembyid',
    'loadsegment', 'unloadsegment', 'setmusic', 'setsoundscheme', 'addcharacterexptoskill', 'getcharacterskill',
    'setfunctionexitfromlocationcondition', 'setfunctionnpcdeathcondition', 'lai_group_moveto', 'lai_actorgoto',
    'lai_setactortype', 'lai_actorturntocharacter', 'lai_group_setrelation', 'lai_group_fightgroups',
    'lai_setcheck', 'lai_group_setcheck', 'lai_actorrunto', 'lai_actorgotolocation', 'lai_actorrunToLocation',
    'lai_setcitizentype', 'lai_setwarriortype', 'lai_group_movecharacter', 'lai_setstaytype', 'lai_setloginreload',
    'lai_actorsetstaymode', 'lai_actordialog', 'lai_actordialognow', 'lai_actorwaitdialog', 'lai_actorfollow',
    'lai_actorfollowEverywhere', 'lai_actoranimation', 'lai_setofficertype', 'lai_setimmortal',
    'addcharacterlocatorgroup', 'pchar_checkonlocation', 'getattributevalue', 'getattributename',
    'setcharacterremovable', 'addpassenger', 'removepassenger', 'setcompanionindex', 'removecharactercompanion',
    'addquestrecordinfo', 'addquestrecord', 'addquestuserdata', 'addquestuserdataforTitle', 'questsetcurrentnode',
    'setcurrenttime', 'waitdate', 'reloadfromworldmaptolocation', 'dolocationreload', 'doreloadcharactertolocation',
    'setlaunchframeformparam', 'launchframeform', 'setnationrelation2maincharacter', 'changecharacternationreputation',
    'savecurrentquestdatetime', 'getquestpastdaysparam', 'getnpcquestpastdaysparam', 'savecurrentnpcqueststateParam',
    'checknpcquestdate', 'savecurrentnpcquestdatetime', 'lai_settemporaryreversegroupoffighting',
    'changeitemdescribe', 'changeitemname', 'baseitem_setparam', 'setshipremovable', 'chrdisablereloadtolocation',
    'createentity', 'deleteentity', 'event', 'postevent', 'seteventhandler', 'deleventhandler', 'sendmessage',
    'findsubstr', 'strcut', 'getsymbol', 'isentity', 'setnewmodeltochar', 'startinstantdialog', 'startinstantdialognoType',
    'setlocationcapturestate', 'locationinitquestlocators', 'trace', 'log_testinfo', 'lai_group_attack',
    'pchar_quest', 'lai_group_setalarmreaction', 'lai_group_setlookradius', 'lai_group_sethearradius',
    'group_findorcreategroup', 'group_addcharacter', 'group_setgroupcommander', 'group_settaskattack',
    'group_settaskmove', 'group_lockTask', 'group_setaddress', 'group_deletegroup', 'group_settasknone',
    'setcharacterrelationboth', 'setcharactertask_none', 'updaterelations', 'refreshbattleinterface',
    'setmapdisableaccess', 'map_createwarrior', 'map_createtrader', 'map_releasequestencounter',
    'setcharactershipLocation', 'createcharacterinlocation', 'gethovercharacter', 'getcityfrom_sea',
    'getislandbycityname', 'getcolonybyindex', 'findcolony', 'getnationbytype', 'setrandselfskill',
    'setselfskill', 'setshipskill', 'setfantomparamfortunehunter', 'setfantomparamhunter',
    'fantomMakeCoolFighter', 'fantommakecoolsailor', 'lai_setheroimmortal', 'setlocationcapturestate',
    'addmoneytocharacter', 'givenationlicence', 'changecharactercompaniontype', 'setcrewquantityfull',
    'setcharactergoods', 'getcargogoods', 'addcharactergoods', 'removecharactergoods',
    'setspyglassdata', 'pchar_setcompanion',
}
ID_FUNCS = {f.lower() for f in ID_FUNCS}
# functions whose arguments are text (with optional arg-index restriction)
TEXT_ARG_FUNCS = {'addquestuserdata': {2}, 'addquestuserdatafortitle': {2}, 'addquestrecordinfo': None,
                  'setlaunchframeformparam': {0}}   # text shown on the black transition screen
PATH_RE = re.compile(r'(\\|/)[^ ]*$|\.(wav|ogg|mp3|tga|dds|c|h|txt|ini|gm|ani)$', re.I)
IDENT_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_.]*$')


def statement_prefix(src, pos):
    """code of the current statement before pos (stops at ; { } outside literals)."""
    i = pos - 1
    depth_str = False
    while i >= 0:
        c = src[i]
        if c == '"':
            depth_str = not depth_str
        elif not depth_str and c in ';{}':
            break
        i -= 1
    return src[i + 1:pos]


def enclosing_call(prefix):
    """(function name lower, argument index) of the innermost open call in prefix, or (None, -1)."""
    depth = 0
    argi = 0
    in_str = False
    i = len(prefix) - 1
    while i >= 0:
        c = prefix[i]
        if c == '"':
            in_str = not in_str
        elif not in_str:
            if c == ')':
                depth += 1
            elif c == '(':
                if depth == 0:
                    m = re.search(r'([A-Za-z_][A-Za-z0-9_]*)\s*$', prefix[:i])
                    return (m.group(1).lower() if m else None), argi
                depth -= 1
            elif c == ',' and depth == 0:
                argi += 1
        i -= 1
    return None, -1


def strip_code(prefix):
    return re.sub(r'"[^"]*"', '""', prefix)


def classify_tag(stmt):
    s = stmt.strip().lower()
    if re.match(r'^(npchar\.|pchar\.)?dialog\.text\b', s) or s.startswith('dialog.text'):
        return 'T'
    if re.match(r'^link\.l[\w]*\s*=', s) and '.go' not in s.split('=')[0]:
        return 'L'
    if 'log_info' in s or 'log_setstringtolog' in s or 'log_setactiveaction' in s or 'notification' in s:
        return 'M'
    if re.search(r'\.(name|lastname|fullname|ship\.name)\s*=', s):
        return 'N'
    if 'addquestuserdata' in s:
        return 'Q'
    return ''


class Lit:
    __slots__ = ('s', 'e', 'v', 'tag', 'pair', 'translatable', 'key', 'fn', 'ai', 'stmt')

    def __init__(self, s, e, v):
        self.s, self.e, self.v = s, e, v
        self.tag = ''
        self.pair = None
        self.translatable = False
        self.key = None
        self.fn, self.ai, self.stmt = None, -1, ''


SSEX_RE = re.compile(r'"sSex\d*"\s*,\s*GetSexPhrase\s*\(\s*$', re.I)


def analyse_c(src, ru_literals=None):
    """returns list of Lit with .translatable/.key set. Keys: literal text, or '⚥A|B' for GetSexPhrase pairs."""
    lits = [Lit(s, e, v) for s, e, v in scan_literals(src)]
    for L in lits:
        v = L.v
        stmt = statement_prefix(src, L.s)
        L.stmt = stmt
        code = strip_code(stmt)
        L.tag = classify_tag(stmt)
        L.fn, L.ai = enclosing_call(code)
        if not LETTERS.search(v):
            continue
        has_cyr = bool(CYR.search(v))
        if ru_literals is not None and v in ru_literals and not has_cyr:
            continue
        if ID_CTX_RE.search(code.rstrip()):
            continue
        if L.fn in ID_FUNCS:
            allowed = TEXT_ARG_FUNCS.get(L.fn, set())
            if allowed is not None and L.ai not in allowed:
                continue
        if PATH_RE.search(v) and ' ' not in v.strip():
            continue
        L.translatable = True
        L.key = v
    # GetSexPhrase("A","B") literal pairs are translated as one unit
    for i in range(len(lits) - 1):
        a, b = lits[i], lits[i + 1]
        if not (a.fn == 'getsexphrase' and b.fn == 'getsexphrase' and a.ai == 0 and b.ai == 1):
            continue
        if not re.fullmatch(r'\s*,\s*', src[a.e:b.s]):
            continue
        if SSEX_RE.search(strip_code(a.stmt)):
            # quest-log gender suffix: handled automatically at build time
            a.translatable = b.translatable = False
            continue
        if not (a.translatable or b.translatable):
            continue
        k = '⚥' + a.v + '|' + b.v
        a.key = b.key = k
        a.translatable = b.translatable = True
        a.pair, b.pair = ('A', k), ('B', k)
    return lits


def dialog_units(path_en, path_ru):
    src = rd(path_en)
    ru = None
    if path_ru and os.path.exists(path_ru):
        ru = {v for _, _, v in scan_literals(rd(path_ru))}
    lits = analyse_c(src, ru)
    units = []
    seen = set()
    for L in lits:
        if not L.translatable or L.key in seen:
            continue
        seen.add(L.key)
        units.append((L.key, L.tag))
    return units


def build_c_file(path_en, path_ru, tm, stats):
    src = rd(path_en)
    ru = None
    if path_ru and os.path.exists(path_ru):
        ru = {v for _, _, v in scan_literals(rd(path_ru))}
    lits = analyse_c(src, ru)
    out = []
    pos = 0
    for L in lits:
        new = None
        if L.translatable and L.key in tm:
            fr = tm[L.key]
            if isinstance(L.pair, tuple):
                parts = fr.split('|', 1) if '|' in fr else [fr, fr]
                new = parts[0] if L.pair[0] == 'A' else parts[1]
            else:
                new = fr
            new = to_game(new).replace('"', "'")
            stats['tr'] += 1
        elif L.translatable:
            stats['miss'] += 1
        # include paths / language folders
        if new is None and re.search(r'dialogs\\english\\', L.v, re.I):
            new = re.sub(r'(?i)(dialogs\\)english(\\)', r'\1french\2', L.v)
        if new is not None:
            out.append(src[pos:L.s + 1])
            out.append(new)
            pos = L.e - 1
    out.append(src[pos:])
    res = ''.join(out)
    # quest-log gender suffix values -> French feminine agreement
    res = re.sub(r'(AddQuestUserData\w*\s*\([^;]*?"sSex\d*"\s*,\s*GetSexPhrase\(\s*)"[^"]*"\s*,\s*"[^"]*"',
                 r'\1"", "e"', res)
    # hand-written fixes of the french source (junctions the english got wrong), see ../fixups.txt
    name = rel(path_en, P_DLG_EN)
    for fname, a, b in load_fixups():
        if fname == name:
            if a in res:
                res = res.replace(a, b)
            else:
                stats.setdefault('fixups_missed', []).append('%s: %s' % (fname, a[:50]))
    return space_punct(res)


# French typography: "?" / "!" glued to a name or a variable  ->  x + "?"  becomes  x + " ?"
_PUNCT_LIT = re.compile(r'(\+\s*)"([?!][^"\\]*)"')


def space_punct(src):
    out, pos = [], 0
    for m in _PUNCT_LIT.finditer(src):
        j = m.start() - 1
        while j >= 0 and src[j] in ' \t':
            j -= 1
        if j >= 1 and src[j] == '"' and src[j - 1] == ' ':      # "text " + "?" : already spaced
            continue
        out.append(src[pos:m.start()])
        out.append('%s" %s"' % (m.group(1), m.group(2)))
        pos = m.end()
    out.append(src[pos:])
    return ''.join(out)


_FIXUPS = None


def load_fixups():
    """lines '<dialog file relative to DIALOGS/english><TAB><french source text><TAB><replacement>'."""
    global _FIXUPS
    if _FIXUPS is None:
        _FIXUPS = []
        p = os.path.join(BASE, 'fixups.txt')
        if os.path.exists(p):
            for line in open(p, encoding='utf-8'):
                line = line.rstrip('\r\n')
                if line and not line.startswith('#') and line.count('\t') >= 2:
                    f, a, b = line.split('\t', 2)
                    _FIXUPS.append((f.replace('\\', '/'), to_game(a), to_game(b)))
    return _FIXUPS

# --------------------------------------------------------------------------- texts (.txt key {value})

TXT_RE = re.compile(r'([^{}]*)\{([^{}]*)\}', re.S)


def parse_txt(src):
    """yields (key, value_start, value_end, value) ; keys deduplicated with #n"""
    out = []
    count = {}
    for m in TXT_RE.finditer(src):
        rawkey = m.group(1)
        # key = last non-comment line(s) of the chunk before '{'
        lines = [l for l in rawkey.split('\n')]
        keyline = ''
        for l in reversed(lines):
            t = l.strip()
            if t and not t.startswith('//') and not t.startswith(';'):
                keyline = t
                break
            if t:
                continue
        k = keyline
        n = count.get(k, 0)
        count[k] = n + 1
        kk = k if n == 0 else '%s#%d' % (k, n)
        out.append((kk, m.start(2), m.end(2), m.group(2)))
    return out


COMMON_RE = re.compile(r'^(\s*string\s*=\s*)([^,]+?)(\s*,\s*")(.*)("\s*)$')


def parse_common(src):
    out = []
    count = {}
    pos = 0
    for line in src.splitlines(True):
        m = COMMON_RE.match(line.rstrip('\r\n'))
        if m:
            k = m.group(2).strip()
            n = count.get(k, 0)
            count[k] = n + 1
            kk = k if n == 0 else '%s#%d' % (k, n)
            vs = pos + m.start(4)
            out.append((kk, vs, vs + len(m.group(4)), m.group(4)))
        pos += len(line)
    return out


def text_units(fname):
    p = os.path.join(P_TEXTS_EN, fname)
    src = rd(p)
    items = parse_common(src) if fname.lower().endswith('.ini') else parse_txt(src)
    res = []
    for k, s, e, v in items:
        if not LETTERS.search(v):
            continue
        res.append((k, v))
    return res

# --------------------------------------------------------------------------- questbook

QB_HDR = re.compile(r'^#(QUEST|TEXT)[ \t]+(\S+)[^\n]*$', re.M)


def parse_qb(src):
    """returns list of (key, start, end, text) for title & texts (stripped spans)."""
    hdrs = list(QB_HDR.finditer(src))
    out = []
    quest = None
    count = {}
    for i, h in enumerate(hdrs):
        kind, ident = h.group(1), h.group(2)
        body_s = h.end()
        body_e = hdrs[i + 1].start() if i + 1 < len(hdrs) else len(src)
        body = src[body_s:body_e]
        if kind == 'QUEST':
            quest = ident
            k = quest + '|'
        else:
            k = '%s|%s' % (quest, ident)
        n = count.get(k, 0)
        count[k] = n + 1
        if n:
            k += '#%d' % n
        st = body.strip()
        if not st:
            continue
        s = body_s + body.index(st)
        out.append((k, s, s + len(st), st))
    return out

# --------------------------------------------------------------------------- domains / priority

def dialog_files():
    files = []
    for dp, dn, fn in os.walk(P_DLG_EN):
        for f in fn:
            if f.lower().endswith(('.c', '.h')):
                files.append(rel(os.path.join(dp, f), P_DLG_EN))
    return sorted(files)


DIALOG_PRIORITY = [
    'Common_', 'Rumours/', 'Tavern/', 'Store/', 'Shipyard/', 'Usurer/', 'Church/', 'PortMan/', 'Mayor/',
    'Governor/', 'Soldier/', 'Fort/', 'Prison/', 'Citizen/', 'Brothel/', 'ItemTrader/', 'Habitue', 'Waitress',
    'Sailor', 'Smuggler', 'Officer', 'Enc_', 'MainHero', 'PGG', 'Capitans', 'Hunter', 'Ransack', 'Prop_',
    'GenQuests', 'MayorQuests', 'Quest/ForAll', 'Quest/Questions', 'Quest/MainheroPrologues', 'Quest/',
]


def dialog_rank(f):
    for i, p in enumerate(DIALOG_PRIORITY):
        if f.startswith(p) or ('/' not in p and f.split('/')[-1].startswith(p)):
            return i
    return len(DIALOG_PRIORITY)


TEXT_PRIORITY = ['common.ini', 'Interface.txt', 'interface_strings.txt', 'ControlsNames.txt', 'commands_name.txt',
                 'Battle_Interface.txt', 'SeaSection.txt', 'save_load.txt', 'Frames.txt', 'HelpSectionTitles.txt',
                 'CreateCharacter.txt', 'globals.txt', 'LocLables.txt', 'MapDescribe.txt', 'BuildingsInformation.txt',
                 'ShipEatGood.txt', 'activemap_ru.txt', 'QuestBookStrings.txt', 'Logs.txt', 'Quests.txt',
                 'RPGDescribe.txt', 'AbilityDescribe.txt', 'GoodsDescribe.txt', 'ShipsDescribe.txt',
                 'ShipsUpgrades.txt', 'Hints.txt', 'ItemsDescribe.txt', 'HeroDescribe.txt', 'AchievementsDescr.txt',
                 'RumourTexts.txt', 'AddRumours.txt', 'SiegeRumours.txt', 'Names.txt', 'ShipNames.txt']
QB_PRIORITY = ['QuestBook1_Generic.txt', 'QuestBook2_Lines.txt', 'QuestBook4.txt', 'QuestBook0_Info.txt',
               'QuestBook3_Changelog.txt']


def all_text_files():
    fs = [f for f in os.listdir(P_TEXTS_EN) if f.lower().endswith(('.txt', '.ini')) and f.lower() not in TEXT_SKIP]
    return sorted(fs, key=lambda f: (TEXT_PRIORITY.index(f) if f in TEXT_PRIORITY else 99, f))

# --------------------------------------------------------------------------- tm access

def tm_dialogs():
    return jload(os.path.join(TM_DIR, 'dialogs.json'))


def tm_text(fname):
    return jload(os.path.join(TM_DIR, 'texts', fname + '.json'))


def tm_qb(fname):
    return jload(os.path.join(TM_DIR, 'questbook', fname + '.json'))

# --------------------------------------------------------------------------- work items

def iter_units(order):
    """yields (domain, file, key, english, tag) in the requested order of domains."""
    for dom in order:
        if dom == 'texts':
            for f in all_text_files():
                for k, v in text_units(f):
                    yield ('texts', f, k, v, '')
        elif dom == 'questbook':
            for f in QB_PRIORITY:
                p = os.path.join(P_QB_EN, f)
                if os.path.exists(p):
                    for k, s, e, v in parse_qb(rd(p)):
                        if LETTERS.search(v):
                            yield ('questbook', f, k, v, '')
        elif dom == 'dialogs':
            for f in sorted(dialog_files(), key=lambda x: (dialog_rank(x), x)):
                for k, tag in dialog_units(os.path.join(P_DLG_EN, f), os.path.join(P_DLG_RU, f)):
                    yield ('dialogs', f, k, k, tag)


def enc(s):
    return s.replace('\r\n', '\n').replace('\n', NL).replace('\t', TAB)


def dec(s):
    return s.replace(NL, '\r\n').replace(TAB, '\t')


def known_text_pairs():
    """english -> french from every translated text/questbook unit: {file: {en: fr}}, {en: fr} (long ones)"""
    per_file, glob = {}, {}
    for f in all_text_files():
        tm = tm_text(f)
        if not tm:
            continue
        d = per_file.setdefault(f, {})
        for k, v in text_units(f):
            if k in tm:
                d.setdefault(v, tm[k])
                if len(v.split()) >= 4:
                    glob.setdefault(v, tm[k])
    return per_file, glob


def cmd_next(maxchars=24000, filt=None, order=('texts', 'dialogs', 'questbook')):
    os.makedirs(WORK, exist_ok=True)
    tmd = tm_dialogs()
    tcache, qcache = {}, {}
    batch, mp = [], {}
    size = 0
    seen = set()
    cur_file = None
    n = 0
    per_file, glob = known_text_pairs() if 'texts' in order else ({}, {})
    auto = 0
    first_of = {}   # (dom, file, english) -> batch id (duplicates are filled on import)
    for dom, f, k, v, tag in iter_units(order):
        if filt and filt not in (dom + ':' + f):
            continue
        if dom == 'dialogs':
            if k in tmd or k in seen:
                continue
            seen.add(k)
        elif dom == 'texts':
            if f not in tcache:
                tcache[f] = tm_text(f)
            if k in tcache[f]:
                continue
            reuse = per_file.get(f, {}).get(v) or glob.get(v)
            if reuse is not None:
                tcache[f][k] = reuse
                auto += 1
                continue
            dk = (dom, f, v)
            if dk in first_of:
                mp.setdefault('dups', {}).setdefault(first_of[dk], []).append([dom, f, k])
                continue
        else:
            if f not in qcache:
                qcache[f] = tm_qb(f)
            if k in qcache[f]:
                continue
        if size and size + len(v) > maxchars:
            break
        n += 1
        bid = str(n)
        mp[bid] = [dom, f, k]
        if dom == 'texts':
            first_of[(dom, f, v)] = bid
        if (dom, f) != cur_file:
            batch.append('## %s %s' % (dom, f))
            cur_file = (dom, f)
        shown = v
        if dom == 'dialogs' and v.startswith('⚥'):
            shown = 'SEXE[' + v[1:] + ']'
        label = bid + (('[' + tag + ']') if tag else '')
        if dom == 'texts':
            label += ' (' + k.split('#')[0][:40] + ')'
        batch.append('%s\t%s' % (label, enc(shown)))
        size += len(v)
    for f, d in tcache.items():
        if auto:
            jsave(os.path.join(TM_DIR, 'texts', f + '.json'), d)
    jsave(os.path.join(WORK, 'batch_map.json'), mp)
    txt = '\n'.join(batch) + '\n'
    wr(os.path.join(WORK, 'batch.txt'), txt)
    sys.stdout.write(txt)
    sys.stdout.write('### %d unites, %d caracteres (%d reprises auto)\n' % (n, size, auto))


PH_RE = re.compile(r'#[A-Za-z_][A-Za-z0-9_.]*#|@<[^>]+>|%[sd]|\$[A-Za-z_]+')


def check(en, fr, dom):
    warns = []
    a = sorted(PH_RE.findall(en))
    b = sorted(PH_RE.findall(fr))
    if dom == 'questbook':
        a = [x for x in a if not x.startswith('@<sSex')]
        b = [x for x in b if not x.startswith('@<sSex')]
    if a != b:
        warns.append('balises %s -> %s' % (a, b))
    if dom in ('dialogs',) or (dom == 'texts'):
        if '"' in fr and dom == 'dialogs':
            warns.append('guillemet " interdit')
    if dom == 'texts' and ('{' in fr or '}' in fr):
        warns.append('accolade interdite')
    return warns


def fix_ws(en, fr):
    """keep the leading/trailing whitespace of the english string."""
    lead = en[:len(en) - len(en.lstrip())]
    trail = en[len(en.rstrip()):]
    core = fr.strip()
    return lead + core + trail if core else fr


def cmd_import(path):
    mp = jload(os.path.join(WORK, 'batch_map.json'))
    tmd = tm_dialogs()
    tms = {}
    n = 0
    problems = []
    for raw in open(path, encoding='utf-8').read().split('\n'):
        line = raw.rstrip('\r')
        if not line.strip() or line.startswith('##'):
            continue
        if '\t' not in line:
            problems.append('ligne sans tabulation: ' + line[:60])
            continue
        bid, fr = line.split('\t', 1)
        bid = re.match(r'\s*(\d+)', bid)
        if not bid or bid.group(1) not in mp:
            problems.append('id inconnu: ' + line[:40])
            continue
        dom, f, k = mp[bid.group(1)]
        fr = dec(fr)
        keep = fr.strip() == '='   # "=" : keep the english text unchanged (ids, names, data fields)
        if keep:
            if dom == 'dialogs':
                fr = k[1:] if k.startswith('⚥') else k
            elif dom == 'texts':
                fr = dict(text_units(f)).get(k, '')
            else:
                fr = {kk: v for kk, s, e, v in parse_qb(rd(os.path.join(P_QB_EN, f)))}.get(k, '')
        if dom == 'dialogs':
            en = k
            if en.startswith('⚥'):
                frc = fr
                if frc.startswith('SEXE[') and frc.endswith(']'):
                    frc = frc[5:-1]
                if '|' not in frc:
                    problems.append('%s: paire SEXE sans |' % bid.group(1))
                    continue
                a, b = frc.split('|', 1)
                ea, eb = en[1:].split('|', 1)
                fr = fix_ws(ea, a) + '|' + fix_ws(eb, b)
            else:
                fr = fix_ws(en, fr)
            fr = fr.replace('␣', ' ')   # '␣' (open box) = space forced at a fragment edge
            w = check(en, fr, dom)
            if w:
                problems.append('%s (%s): %s' % (bid.group(1), f, '; '.join(w)))
            tmd[k] = fr.replace('"', "'")
        else:
            key = (dom, f)
            if key not in tms:
                tms[key] = tm_text(f) if dom == 'texts' else tm_qb(f)
            if dom == 'texts':
                en = dict(text_units(f)).get(k, '')
            else:
                en = {kk: v for kk, s, e, v in parse_qb(rd(os.path.join(P_QB_EN, f)))}.get(k, '')
            if dom == 'texts':
                fr = fix_ws(en, fr)
            fr = fr.replace('␣', ' ')
            w = check(en, fr, dom)
            if w:
                problems.append('%s (%s %s): %s' % (bid.group(1), f, k, '; '.join(w)))
            if dom == 'texts':
                fr = fr.replace('{', '(').replace('}', ')')
                if f.lower().endswith('.ini'):
                    fr = fr.replace('"', "'")
            tms[key][k] = fr
            for ddom, df, dk in mp.get('dups', {}).get(bid.group(1), []):
                dkey = (ddom, df)
                if dkey not in tms:
                    tms[dkey] = tm_text(df) if ddom == 'texts' else tm_qb(df)
                tms[dkey][dk] = fr
                n += 1
        n += 1
    jsave(os.path.join(TM_DIR, 'dialogs.json'), tmd)
    for (dom, f), d in tms.items():
        jsave(os.path.join(TM_DIR, 'texts' if dom == 'texts' else 'questbook', f + '.json'), d)
    print('importe: %d' % n)
    for p in problems:
        print('  !', p)

# --------------------------------------------------------------------------- status

def cmd_status(verbose=False):
    tmd = tm_dialogs()
    tot = {}
    per = []
    for dom, f, k, v, tag in iter_units(('texts', 'questbook', 'dialogs')):
        if dom == 'dialogs':
            done = k in tmd
        elif dom == 'texts':
            done = k in tm_text_cached(f)
        else:
            done = k in tm_qb_cached(f)
        t = tot.setdefault(dom, [0, 0, 0, 0])
        t[0] += 1; t[1] += done; t[2] += len(v); t[3] += len(v) if done else 0
        per.append((dom, f, done, len(v)))
    for dom, (n, d, c, cd) in tot.items():
        print('%-10s %6d/%6d unites  %8d/%8d car. (%.1f%%)' % (dom, d, n, cd, c, 100.0 * cd / max(1, c)))
    if verbose:
        agg = {}
        for dom, f, done, ln in per:
            a = agg.setdefault((dom, f), [0, 0])
            a[0] += ln; a[1] += ln if done else 0
        for (dom, f), (c, cd) in agg.items():
            if cd < c:
                print('   %-9s %-55s %7d/%7d' % (dom, f, cd, c))


_tcache, _qcache = {}, {}


def tm_text_cached(f):
    if f not in _tcache:
        _tcache[f] = tm_text(f)
    return _tcache[f]


def tm_qb_cached(f):
    if f not in _qcache:
        _qcache[f] = tm_qb(f)
    return _qcache[f]

# --------------------------------------------------------------------------- build

def build_texts():
    os.makedirs(P_TEXTS_FR, exist_ok=True)
    n_tr = n_all = 0
    for f in os.listdir(P_TEXTS_EN):
        src_p = os.path.join(P_TEXTS_EN, f)
        dst_p = os.path.join(P_TEXTS_FR, f)
        if os.path.isdir(src_p):
            continue
        if f.lower() in TEXT_SKIP or not f.lower().endswith(('.txt', '.ini')):
            shutil.copyfile(src_p, dst_p)
            continue
        src = rd(src_p)
        tm = tm_text(f)
        items = parse_common(src) if f.lower().endswith('.ini') else parse_txt(src)
        out, pos = [], 0
        for k, s, e, v in items:
            if k in tm and LETTERS.search(v):
                fr = to_game(tm[k])
                if f.lower().endswith('.ini'):
                    fr = fr.replace('"', "'")
                else:
                    fr = fr.replace('{', '(').replace('}', ')')
                out.append(src[pos:s]); out.append(fr); pos = e
                n_tr += 1
            if LETTERS.search(v):
                n_all += 1
        out.append(src[pos:])
        wr(dst_p, ''.join(out))
    return n_tr, n_all


def build_questbook():
    os.makedirs(P_QB_FR, exist_ok=True)
    n_tr = n_all = 0
    for f in os.listdir(P_QB_EN):
        src = rd(os.path.join(P_QB_EN, f))
        tm = tm_qb(f)
        out, pos = [], 0
        for k, s, e, v in parse_qb(src):
            n_all += 1
            if k in tm:
                out.append(src[pos:s]); out.append(to_game(tm[k]).replace('\r\n', '\n').replace('\n', '\r\n')); pos = e
                n_tr += 1
        out.append(src[pos:])
        wr(os.path.join(P_QB_FR, f), ''.join(out))
    return n_tr, n_all


def build_dialogs():
    tm = tm_dialogs()
    stats = {'tr': 0, 'miss': 0}
    for f in dialog_files():
        res = build_c_file(os.path.join(P_DLG_EN, f), os.path.join(P_DLG_RU, f), tm, stats)
        wr(os.path.join(P_DLG_FR, f.replace('/', os.sep)), res)
    for m in stats.get('fixups_missed', []):
        print('  ! fixup non applique :', m)
    return stats['tr'], stats['tr'] + stats['miss']


def copy_tree(src, dst):
    if os.path.isdir(dst):
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


def build_misc():
    msgs = []
    # names (proper names stay as they are)
    for sub in ('characters', 'Ships'):
        copy_tree(os.path.join(ROOT, 'Program', sub, 'english'), os.path.join(ROOT, 'Program', sub, 'french'))
    # sound aliases
    copy_tree(os.path.join(ROOT, 'RESOURCE', 'INI', 'aliases', 'english'),
              os.path.join(ROOT, 'RESOURCE', 'INI', 'aliases', 'french'))
    # main menu textures (french text textures from FR_Traduction/assets if present)
    mm_en = os.path.join(ROOT, 'RESOURCE', 'Textures', 'MainMenu', 'English')
    mm_fr = os.path.join(ROOT, 'RESOURCE', 'Textures', 'MainMenu', 'French')
    copy_tree(mm_en, mm_fr)
    assets = os.path.join(BASE, 'assets', 'MainMenu')
    if os.path.isdir(assets):
        for f in os.listdir(assets):
            shutil.copyfile(os.path.join(assets, f), os.path.join(mm_fr, f))
    # interface voice samples English_*.wav -> French_*.wav
    si = os.path.join(ROOT, 'RESOURCE', 'Sounds', 'Interface')
    k = 0
    for f in os.listdir(si):
        if f.lower().startswith('english_'):
            d = os.path.join(si, 'French_' + f[8:])
            if not os.path.exists(d):
                shutil.copyfile(os.path.join(si, f), d)
                k += 1
    msgs.append('sons interface copies: %d' % k)
    # voices: directory junction Voice\French -> Voice\English (no disk space used)
    v_en = os.path.join(ROOT, 'RESOURCE', 'Sounds', 'Voice', 'English')
    v_fr = os.path.join(ROOT, 'RESOURCE', 'Sounds', 'Voice', 'French')
    if not os.path.exists(v_fr):
        r = os.system('cmd /c mklink /J "%s" "%s" >nul' % (v_fr, v_en))
        if r != 0:
            shutil.copytree(v_en, v_fr)
            msgs.append('voix copiees')
        else:
            msgs.append('jonction Voice\\French -> English creee')
    return msgs


def set_language_ini(lang='french'):
    p = os.path.join(ROOT, 'RESOURCE', 'INI', 'texts', 'language.ini')
    s = rd(p)
    s = re.sub(r'(?m)^defaultLanguage\s*=.*$', 'defaultLanguage = %s' % lang, s, count=1)
    s = re.sub(r'(?m)^French\s*=\s*fonts\.ini\s*$', 'French = fonts_fra.ini', s)
    open(p, 'wb').write(s.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8'))


def cmd_build(only=None):
    if not only or 'texts' in only:
        print('textes interface : %d/%d' % build_texts())
    if not only or 'questbook' in only:
        print('journal de quetes : %d/%d' % build_questbook())
    if not only or 'dialogs' in only:
        print('dialogues (litteraux) : %d/%d' % build_dialogs())
    if not only or 'misc' in only:
        for m in build_misc():
            print(m)
    if not only or 'lang' in only:
        set_language_ini('french')
        print('language.ini -> french')


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == 'status':
        cmd_status('-v' in a)
    elif a[0] == 'next':
        mx = int(a[1]) if len(a) > 1 and a[1].isdigit() else 24000
        filt = a[2] if len(a) > 2 else None
        order = ('texts', 'dialogs', 'questbook')
        if len(a) > 3:
            order = tuple(a[3].split(','))
        cmd_next(mx, filt, order)
    elif a[0] == 'import':
        cmd_import(a[1])
    elif a[0] == 'build':
        cmd_build(a[1].split(',') if len(a) > 1 else None)
    else:
        print(__doc__)
