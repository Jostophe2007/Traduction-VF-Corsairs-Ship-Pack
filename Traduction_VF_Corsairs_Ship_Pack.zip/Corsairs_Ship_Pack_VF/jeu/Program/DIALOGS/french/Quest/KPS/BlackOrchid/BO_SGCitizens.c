// Gregg: посланцы главы 6 «Испанская щедрость» - «Чёрная Орхидея» (перенос из К:ПС).
// Логика - Program\Quests\reaction_functions\blackorchid.c
// Оригинал - DamnedDestiny\SpanishGenerosity\Characters.c, узлы 5-14.
// Четыре одноразовых горожанина, каждый со своим узлом:
//   1 - человек Альборетто, зовёт в Сантьяго       (Alboretto Man 1);
//   2 - человек Кендарта, зовёт в Ле-Франсуа       (Kendart Man 1);
//   3 - человек Кендарта с письмом: Сан-Хуан наш   (Kendart Man 2);
//   4 - человек Кендарта: эскадра на подходе       (Kendart Man 3).
// Все четверо бессмертны на время реплики и уходят своим ходом - см. логику.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sLastName = PChar.lastname;


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "...(détourne les yeux)... Pardon, capitaine, je vous ai pris pour un autre.";
			link.l1 = "דa arrive.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Capitaine " + sLastName + " ? On m'a demandé de vous transmettre un message. Un certain señor de Santiago aimerait vous parler. Il a une affaire à vous proposer, et on dit qu'elle est importante.";
			link.l1 = "Quel señor ? Votre affaire a-t-elle un nom ?";
			link.l1.go = "1a";
		break;

		case "1a":
			dialog.text = "Emilio Alboretto. Il vous attend à la taverne de Santiago, et il m'a demandé de vous dire qu'il est prêt à attendre longtemps.";
			link.l1 = "Dites-lui que je viendrai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityFirstToSantiago");
		break;

		case "2":
			dialog.text = "Capitaine " + sLastName + ", on m'a demandé de vous transmettre ceci de vive voix, sans lettre. Alejon Kendart vous attend dans la chambre à l'étage de la taverne de la colonie pirate du François, à la Martinique.";
			link.l1 = "Kendart ? Mais il... Hé, attendez !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityToLeFransua");
		break;

		case "3":
			dialog.text = "Capitaine " + sLastName + ". Alejon Kendart m'a demandé de vous remettre ceci, et de vous dire que la chose est faite.";
			link.l1 = "...(dépliant la lettre)... Donnez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityToSanJuan");
		break;

		case "4":
			dialog.text = "Capitaine ! Des nouvelles du cap : des voiles. Quatre, qui font route droit sur San Juan, et pas pour commercer.";
			link.l1 = "Alors ça y est. Aux navires.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityPrepareFinalBattle");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
