// Тичингиту - индеец-офицер
void ProcessDialogEvent()
{
	ref NPChar, sld, rItm, rItem;
	aref Link, NextDiag, rType;
	int i;
	string 	sAttr, sGun, sBullet, attrL;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	sAttr = Dialog.CurrentNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Vous vouliez quelque chose ?";
			link.l1 = "Non, rien.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Tichingitu":
			dialog.text = "Que veux-tu, visage pâle ? Tichingitu n'a pas de mots pour toi.";
			link.l1 = "Tu t'appelles Tichingitu ? Hum. וcoute, guerrier, je ne suis pas là pour te dévisager, mais pour te demander pourquoi tu t'es introduit dans la maison de cet Askold.";
			link.l1.go = "Tichingitu_1";
		break;

		case "Tichingitu_1":
			dialog.text = "";
			link.l1 = "Tu te tais ? C'est idiot. On te pendra pour vol, et voilà tout. Dis-moi pourquoi tu as fait ça, je pourrai peut-être t'aider.";
			link.l1.go = "Tichingitu_2";
		break;

		case "Tichingitu_2":
			dialog.text = "Tichingitu venir dans la ville des visages pâles par beaucoup, beaucoup de chemins, par un grand fleuve, d'un pays de grandes forêts et de marais. Tichingitu être fatigué et vouloir manger. Tichingitu mourir de faim. Personne ne vouloir aider Tichingitu, crier : dehors, chien rouge. L'aubergiste chasser l'Indien comme un chien galeux. Tichingitu vouloir manger.";
			link.l1 = "Bon sang, mais alors, pourquoi es-tu venu dans cette colonie depuis... ta forêt ?";
			link.l1.go = "Tichingitu_3";
		break;

		case "Tichingitu_3":
			dialog.text = "Chasser Tichingitu de sa tribu natale. Tichingitu se disputer avec chaman de la tribu, chaman parler au chef, chaman maudire Tichingitu : Tichingitu quitter la tribu, loin, loin du campement natal. Tichingitu n'avoir plus de maison, plus d'armes, plus rien.";
			link.l1 = "Oui, tu n'as pas de chance. Et pourquoi t'es-tu disputé avec les tiens ?";
			link.l1.go = "Tichingitu_4";
		break;

		case "Tichingitu_4":
			dialog.text = "Le chaman de notre tribu être un homme mauvais. Lui dire : ma femme être possédée par un mauvais esprit, ma femme devoir mourir. Ma femme être juste malade, l'esprit pas entrer en elle. Moi soigner ma femme, chaman tuer ma femme. Tichingitu se dresser contre le chaman, tous se dresser contre Tichingitu, Tichingitu partir.";
			link.l1 = "Tu as essayé de sauver ta femme ? C'est pour ça qu'on t'a chassé du village ?";
			link.l1.go = "Tichingitu_5";
		break;

		case "Tichingitu_5":
			dialog.text = "Alors, visage pâle, Tichingitu n'avoir pas le choix : voler ou mourir de faim...";
			link.l1 = "Voilà le problème... Pendre un homme pour un morceau de nourriture valant quelques misérables pièces... Tichingitu, je vais essayer de t'aider. Je connais Askold, celui dont tu as forcé la maison. Je peux peut-être faire quelque chose... Je vais parler au commandant tout de suite.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Tichingitu_wait";
			pchar.questTemp.Tichingitu = "commandante";
			AddQuestRecord("Ascold", "3_1");
			AddQuestUserData("Ascold", "sSex", GetSexPhrase("", "e"));
		break;

		case "Tichingitu_wait":
			dialog.text = "Tichingitu attendre. Un Indien ne pas avoir peur de la mort. Le chaman maudire Tichingitu : Tichingitu devoir mourir.";
			link.l1 = "Tout n'est pas encore perdu. J'essaie de t'aider...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Tichingitu_wait";
		break;

		case "Tichingitu_6":
			dialog.text = "Tichingitu attendre. Un Indien ne pas avoir peur de la mort. Le chaman maudire Tichingitu : Tichingitu devoir mourir.";
			link.l1 = "Ne sois pas si pessimiste. Ton calvaire est terminé. J'ai obtenu ta libération.";
			link.l1.go = "Tichingitu_7";
		break;

		case "Tichingitu_7":
			dialog.text = "Visage pâle plaisanter ? Tichingitu être libre ?";
			link.l1 = "Je ne plaisante pas. On va ouvrir ta cellule et te laisser sortir. Suis-moi, je vais te faire sortir de prison.";
			link.l1.go = "Tichingitu_8";
		break;

		case "Tichingitu_8":
			DialogExit();
			chrDisableReloadToLocation = false;//открыть локацию
			DoQuestReloadToLocation("BasTer_exittown", "rld", "aloc9", "TichingituFree"); // 170712
			pchar.quest.FreeTichingituOver.over = "yes"; //снять таймер
		break;

		case "Tichingitu_9":
			dialog.text = "";
			link.l1 = "Te voilà de nouveau libre. Va te promener, Tichingitu, fais attention, ne vole plus et ne te fais plus prendre ! Tu ferais mieux de trouver un village indien et de vivre parmi les tiens : je ne pense pas qu'ils refuseront de t'accueillir.";
			link.l1.go = "Tichingitu_10";
		break;

		case "Tichingitu_10":
			dialog.text = "Tichingitu ne pas partir. Maître sauver la vie de Tichingitu. Tichingitu rester. La vie de Tichingitu appartenir au maître.";
			link.l1 = "Quoi ? Qu'est-ce que tu racontes ? Je ne suis pas un maître ! Tu n'as pas compris ? Tu es libre ! Va !";
			link.l1.go = "Tichingitu_11";
		break;

		case "Tichingitu_11":
			dialog.text = "L'Indien avoir une dette, maître blanc. Tichingitu te servir fidèlement. Tichingitu savoir se battre. Tichingitu mourir au combat pour"+GetSexPhrase(" son maître", " sa maîtresse")+". Lui rester.";
			link.l1 = "Ah, diable... Je ne suis pas ton maître, Tichingitu. Je t'ai aidé par bonté, pas pour faire de toi un esclave.";
			link.l1.go = "Tichingitu_12";
		break;

		case "Tichingitu_12":
			dialog.text = "Tichingitu n'être pas esclave, "+ GetSexPhrase("homme blanc", "femme blanche")+". Tichingitu être un Indien libre. Tichingitu vouloir te servir. Un Indien savoir se battre : n'importe quel chien mourir avant d'approcher de"+ GetSexPhrase(" mon maître", " ma maîtresse")+". Tichingitu savoir nettoyer et charger un mousquet. Tichingitu savoir tirer au mousquet.";
			link.l1 = "Quoique... Tu sais, Tichingitu, ce n'est pas une mauvaise idée. J'ai besoin de gens de valeur, et tu m'as l'air d'un brave homme. Et tu sais tirer au mousquet. Et que vas-tu faire tout seul ? Si on te reprend à voler, on te pendra à coup sמr... Bon, reste. Mais garde à l'esprit : avec moi, il n'y aura pas de vie tranquille.";
			link.l1.go = "Tichingitu_13";
			link.l2 = "דa suffit. Va en paix, frère à la peau rouge. Que tes dieux te protègent !";
			link.l2.go = "Tichingitu_exit";
		break;

		case "Tichingitu_exit":
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload2_back", "none", "", "", "", 10.0);
			npchar.lifeday = 0;
			DeleteAttribute(pchar, "questTemp.Tichingitu");
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			ChangeCharacterReputation(pchar, 1);
			AddQuestRecord("Ascold", "3_5");
			AddQuestUserData("Ascold", "sSex", GetSexPhrase("", "e"));
		break;

		case "Tichingitu_13":
			dialog.text = "Tichingitu n'avoir peur de rien, "+GetSexPhrase("homme blanc", "femme blanche")+". Tichingitu être heureux de te servir. Tichingitu être fidèle au capitaine jusqu'à son dernier souffle.";
			link.l1 = "Bien. Bienvenue dans l'équipage, Tichingitu !";
			link.l1.go = "Tichingitu_hire";
		break;

		case "Tichingitu_hire":
			DialogExit();
			npchar.HalfImmortal = true;
			DeleteAttribute(npchar, "LifeDay");
			LAi_SetImmortal(npchar, false);
			npchar.quest.OfficerPrice = sti(pchar.rank)*20;
			npchar.OfficerWantToGo.DontGo = true;
			npchar.loyality = MAX_LOYALITY;
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, true);
			npchar.Payment = true;
			npchar.CanTakeMushket = true;
			LAi_SetOfficerType(npchar);
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			NextDiag.CurrentNode = "hired";
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			SaveCurrentNpcQuestDateParam(npchar, "HiredDate");
			DeleteAttribute(pchar, "questTemp.Tichingitu");
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			ChangeCharacterReputation(pchar, 1);
			AddQuestRecord("Ascold", "3_4");
		break;

	//--> ----------------------------------- офицерский блок ------------------------------------------
		case "Tichingitu_officer":
			dialog.text = "Tichingitu t'écouter, capitaine "+pchar.name+" !";
			Link.l1 = "וcoute mon ordre !";
            Link.l1.go = "stay_follow";
			link.l2 = "Rien pour l'instant. Repos !";
			link.l2.go = "exit";
			NextDiag.TempNode = "Tichingitu_officer";
		break;

		case "stay_follow":
            dialog.Text = "Quels sont vos ordres ?";
			if (CheckAttribute(npchar, "IsMushketer"))
			{
				Link.l3 = "Je veux que vous gardiez une certaine distance avec la cible.";
				Link.l3.go = "TargetDistance";
			}
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";
			if (!CheckAttribute(npchar, "AboardRestriction"))
			{
				Link.l4 = "Je vous demande de ne pas participer aux abordages. Prenez soin de vous.";
				Link.l4.go = "AboardRestriction";
			}
			else
			{
				Link.l4 = "J'ai changé d'avis, vous pouvez participer aux abordages.";
				Link.l4.go = "AboardAllowed";
			}
		break;

		case "AboardRestriction":
			npchar.AboardRestriction = true;
			dialog.text = "א vos ordres, capitaine. Je ne participerai pas aux abordages tant que vous ne me l'aurez pas de nouveau permis.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

		case "AboardAllowed":
			DeleteAttribute(npchar, "AboardRestriction");
			dialog.text = "א vos ordres, capitaine. Désormais, je participerai aux abordages.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

        case "Boal_Stay":
            Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
            AddDialogExitQuestFunction("LandEnc_OfficerStay");
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
            Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
        break;

        case "Boal_Follow":
            SetCharacterTask_FollowCharacter(Npchar, PChar);
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
        break;

		//--> задать дистанцию стрельбы
		case "TargetDistance":
			dialog.text = "Laquelle exactement, capitaine ? Indique à Tichingitu la distance en yards, mais pas plus de vingt.";
			link.l1 = "";
			Link.l1.edit = 3;
			link.l1.go = "TargetDistance_1";
		break;

		case "TargetDistance_1":
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp < 0)
			{
				dialog.text = "Capitaine, pardonne à Tichingitu, mais moi ne pas te comprendre.";
				link.l1 = "Pardon, je me suis trompé...";
				link.l1.go = "exit";
				break;
			}
			if (iTemp == 0)
			{
				dialog.text = "Tichingitu devoir rester immobile, ne bouger nulle part. C'est ce que tu veux, capitaine ?";
				link.l1 = "Oui, c'est exactement ce qu'on attend de vous.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 0;
				break;
			}
			if (iTemp > 20)
			{
				dialog.text = "Tichingitu ne pas pouvoir s'éloigner de la cible de plus de vingt yards. Sinon, lui manquer.";
				link.l1 = "D'accord, alors, reste à vingt yards.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 20.0;
				break;
			}
			dialog.text = "Tichingitu tout comprendre. Tichingitu prendre position à la distance indiquée.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			npchar.MusketerDistance = iTemp;
		break;
		//<-- задать дистанцию стрельбы

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
