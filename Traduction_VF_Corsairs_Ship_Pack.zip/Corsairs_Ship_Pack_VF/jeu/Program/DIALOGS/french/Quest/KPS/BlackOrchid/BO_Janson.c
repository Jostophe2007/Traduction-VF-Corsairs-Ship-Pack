// Gregg: Janson and Frank, dock hands out of Le Fransua - «Чёрная Орхидея», глава 7 «Маленький ублюдок».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Bonjour, cap'taine.";
			link.l1 = "Bonjour.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Cap'taine ! Cap'taine, attendez ! C'est une question de vie ou de mort, parole d'honneur !";
			link.l1 = "Parle.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Frank est un imbécile.";
			link.l1 = "Je le vois bien sans toi. Et alors ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je n'avais pas fini ! Frank est un imbécile, il est descendu dans la crypte et il n'est pas ressorti. Il y a des squelettes là-dedans, cap'taine. דa fait trois heures qu'il y est.";
			link.l1 = "Trois heures. Alors il ne ressortira pas.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Si ! Je l'entends d'ici, il chante. Il est vivant, cap'taine, vivant, seulement personne ne veut aller le chercher.";
			link.l1 = "Et qu'est-ce qui l'a poussé à descendre là-dedans ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "La boisson. Nous avons fini le chargement ce matin, et il s'y est mis. Cap'taine, je vous en supplie. Je me mettrai à genoux s'il le faut.";
			link.l1 = "Ce n'est pas la peine. Montre-moi le chemin.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToDungeon");
		break;

		case "6":
			dialog.text = "Hah. Un homme. Hic.";
			link.l1 = "Tu t'appelles Frank ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Frank, c'est moi. Hic. Et toi, t'es qui.";
			link.l1 = "Celui qui est venu te sortir de là.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Pas besoin. On est bien ici. C'est tranquille.";
			link.l1 = "Il y a des squelettes ici.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Hah ! Des squelettes. Je vais leur couper les os. Hic. א tous.";
			link.l1 = "...(sourit)... Tu ne tiens même pas debout.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Si. Pousse-moi un peu.";
			link.l1 = "וcoute, Frank. Il y a du rhum, là-haut.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "...(se tait aussitכt)... Oם ça.";
			link.l1 = "א l'entrée de la grotte. Je l'y ai laissé.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Et pourquoi tu ne l'as pas dit tout de suite. Hic.";
			link.l1 = "On y va, oui ou non ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "On y va. Passe devant, il fait noir ici.";
			link.l1 = "Vers la sortie.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelFromDungeon");
		break;

		case "14":
			dialog.text = "Cap'taine, je... Merci. Je ne sais même pas comment vous rendre ça.";
			link.l1 = "Tu n'as rien à rendre.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Il y a eu un capitaine avant vous. Je lui ai demandé, à lui aussi. Il m'a écouté jusqu'au bout et il a passé son chemin.";
			link.l1 = "דa arrive.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "דa arrive, cap'taine, seulement moi, je m'en souviendrai. Vous vous asseyez avec nous ? Pour fêter le retour de Frank.";
			link.l1 = "Je ne peux pas. J'ai une affaire, et elle n'attendra pas.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Quelle affaire ? On peut peut-être aider.";
			link.l1 = "J'en doute.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Essayez toujours. Nous vous devons quelque chose, et moi, je tiens le compte de mes dettes.";
			link.l1 = "Je cherche une frégate lourde. Elle a fait escale au François pour se ravitailler, puis elle est repartie.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "...(s'illumine)... Mais c'est Frank qui l'a chargée ! Il doit savoir.";
			link.l1 = "Frank ? Un docker du François ?";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Nous le sommes tous les deux. Ce jour-là, il a chargé seul, j'avais mal au dos.";
			link.l1 = "Et il a vu oם elle est allée ?";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Pour voir, il a vu, mais pour le dire, il ne le dira pas, pas aujourd'hui. Il inventera n'importe quoi. Passez au magasin dans deux jours, il sera redevenu un homme d'ici là.";
			link.l1 = "Je vais quand même lui demander maintenant.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelTalkWithFrank");
		break;

		case "22":
			dialog.text = "Oם est le rhum. Tu as dit du rhum.";
			link.l1 = "Quelqu'un l'a pris. J'en rachèterai. Frank, tu as chargé des provisions sur cette frégate ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "J'ai chargé. Hic. Chargé de la viande. Chargé du poisson. Chargé de l'eau, l'eau, c'est lourd.";
			link.l1 = "Pour quel port est-elle partie ?";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Moi, je suis parti pour la taverne.";
			link.l1 = "Pas toi. La frégate.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Ah. Elle est partie chercher du rhum.";
			link.l1 = "Quel rhum, Frank ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Le rhum ordinaire. Hic. Celui de la taverne. Du bon rhum.";
			link.l1 = "...(pour lui-même : un dernier essai)... Oם. Est-elle. Allée.";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Au port. Les navires vont de port en port. Tu ne le savais pas ?";
			link.l1 = "Je le savais. J'attendrai deux jours.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelSecondTalkWithJanson");
		break;

		case "28":
			dialog.text = "Alors, vous lui avez tiré les vers du nez ?";
			link.l1 = "Non. Il m'a parlé de rhum.";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Je vous avais prévenu. Passez au magasin du François dans deux jours. Et apportez du rhum, trois bouteilles.";
			link.l1 = "Je l'ai sorti d'une grotte, et il veut que je lui apporte du rhum ?";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Ce n'est pas lui qui le demande, c'est moi qui vous préviens. Je vais lui expliquer qui vous êtes, ce ne sera peut-être pas nécessaire.";
			link.l1 = "Très bien. J'en apporterai.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Parfait. Dans deux jours, cap'taine.";
			link.l1 = "א bientכt, Frank.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelLeFransuaStoreTimer");
		break;

		case "32":
			dialog.text = "...(se lève, sans vous regarder dans les yeux)... Capitaine. Janson m'a tout raconté.";
			link.l1 = "Je ne suis pas venu pour des excuses.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Je vais quand même les faire. Tant que je suis sobre. Dans une heure, j'aurai de nouveau oublié votre nom.";
			link.l1 = "C'est oublié. J'ai besoin de la réponse à une question.";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Je sais laquelle. La frégate est partie pour Puerto Príncipe. J'ai bavardé avec un de ses matelots pendant le chargement, et il me l'a dit.";
			link.l1 = "Vous en êtes certain ?";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Certain, capitaine. Vous m'avez sauvé la vie. Je ne vous mentirais pas.";
			link.l1 = "Merci, Frank.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToPuertoPrincipe");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
