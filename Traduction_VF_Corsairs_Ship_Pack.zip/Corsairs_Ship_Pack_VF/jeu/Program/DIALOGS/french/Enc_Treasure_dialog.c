//navy
#include "DIALOGS\french\Common_Duel.c"
// boal 29.05.04 даём карту клада
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, Diag;
	string NPC_Meeting;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	string iDay, iMonth;
	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;

	aref   item;
	bool   ok;

	if (!CheckAttribute(npchar, "quest.trade_date"))
    {
        npchar.quest.trade_date = "";
    }

	ProcessDuelDialog(NPChar, link, Diag); //navy

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

        case "Map_NotBuy":
            dialog.Text = "Quand tu seras riche, je te l'emballerai dans un chiffon, et même dans un mouchoir.";
			Link.l1 = "Reste là, je reviens en un éclair !";
			Link.l1.go = "exit";
		break;

		case "First time":
			Diag.TempNode = "First time";

			dialog.Text = "Psst... écoute. J'ai quelque chose pour toi...";
			Link.l1 = "Que voulez-vous dire ?";
			Link.l1.go = "map_treasure_1";
		break;

		case "map_treasure_1":
            ok = (GetCharacterItem(Pchar, "map_part1")>0)  && (GetCharacterItem(Pchar, "map_part2")>0);
            if (GetCharacterItem(Pchar, "map_full") > 0 || ok)
            {
                dialog.Text = "C'est à boire !! Et-hic... Bois un coup avec moi !";
    			Link.l1 = "Oh, laisse tomber. Je croyais que c'était sérieux.";
    			Link.l1.go = "exit";
            }
            else
            {
                dialog.Text = "J'ai quelque chose de spécial pour toi, à un prix raisonnable.";
    			Link.l1 = "Et de quoi s'agit-il ?";
    			Link.l1.go = "map_treasure_2";
    			Link.l2 = "Oh, laisse tomber. Je n'ai pas le temps.";
    			Link.l2.go = "exit";
			}
		break;

		case "map_treasure_2":
            dialog.Text = "C'est une carte formidable. Tu n'en trouveras pas de pareille en boutique. Elle montre oם sont enterrés des trésors ! Je ne peux pas y aller moi-même, mais la carte est authentique, c'est sמr. Je le jure.";
			Link.l1 = "C'est très intéressant. Combien en demandes-tu ?";
			Link.l1.go = "map_treasure_3";
			Link.l2 = "Oh, laisse tomber. Je n'ai pas le temps.";
			Link.l2.go = "exit";
		break;

		case "map_treasure_3":
		    if (npchar.quest.trade_date != lastspeak_date)
		    {
                npchar.quest.trade_date      = lastspeak_date;
            }
            dialog.Text = "La modeste somme de "+Pchar.GenQuest.TreasureMoney+" piastres.";
			Link.l1 = "Allez, emballe-la-moi dans un joli tissu.";
			if (sti(Pchar.Money) >= sti(Pchar.GenQuest.TreasureMoney))
			{
			   Link.l1.go = "map_treasure_buy";
			}
			else
			{
			   Link.l1.go = "Map_NotBuy";
			}
			Link.l2 = "C'est trop cher. Pas besoin.";
			Link.l2.go = "exit";
		break;

		case "map_treasure_buy":
            dialog.Text = "Prends-la. Maintenant, tu vas devenir riche, c'est sמr !";
			Link.l1 = "Merci !";
			Link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(Pchar.GenQuest.TreasureMoney));
			GiveItem2Character(pchar, "map_full");
			AddMoneyToCharacter(NPChar, sti(Pchar.GenQuest.TreasureMoney));
			Items_FindItem("map_full", &item);
			if ( sti(item.MapTypeIdx) == -1 ) npchar.fakemap = 1; else npchar.fakemap = 0;
			//FillMapForTreasure(item);
			Diag.TempNode = "Temp_treasure";
			npchar.LifeDay = 0; // продал и свалил, если дуэль, то продлится у него жизнь
		break;

		case "Temp_treasure":
            dialog.Text = "On boit un coup ? Et-hic... Le rhum est bon ici !";
			Link.l1 = "Pas le temps !";
			Link.l1.go = "exit";
            if (npchar.fakemap == "1")
            {
    			Link.l2 = "Tu m'as vendu un faux !!";
    			Link.l2.go = "Temp_treasure_1";
			}
			Diag.TempNode = "Temp_treasure";
		break;

		case "Temp_treasure_1":
			NPChar.SaveItemsForDead = true;
            dialog.Text = "Et toi, t'es qui ? Et-hic... Je ne te connais pas et je ne veux plus te connaître.";
			Link.l1 = "Eh bien, tant pis !";
			Link.l1.go = "exit";
			Link.l2 = "Tu m'as vendu ce faux !!! Je vais te...";
//			Link.l2.go = "tavern_keeper";
//			Diag.TempNode = "Temp_treasure";
			Link.l2.go = "outraged"; //navy -- дуэли!!!
			Diag.TempNode = "let_s_duel";
			npchar.LifeDay = 1; // чтоб не слетел на выходе
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;

		case "tavern_keeper":
            Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("tavern_keeper");
		break;
	}
}
