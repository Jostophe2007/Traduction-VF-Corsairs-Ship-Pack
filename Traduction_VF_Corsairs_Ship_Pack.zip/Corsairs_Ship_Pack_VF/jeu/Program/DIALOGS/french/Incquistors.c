
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY)
			{
					dialog.text = RandPhraseSimple("Mes frères, il y a un ennemi dans l'Inquisition !!!", "Donnez l'alarme, mes frères !!!");
					link.l1 = "Oui, les ennemis de l'Inquisition ne dorment pas...";
					link.l1.go = "fight";
			}
			else
			{
				dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Bonjour, "+ GetSexPhrase("mon fils","ma fille") +". Quel bon vent vous amène ?", "Heureux de vous voir dans notre monastère, "+ GetSexPhrase("mon fils","ma fille") +". Pourquoi êtes-vous venu ?"),
							""+ GetSexPhrase("Mon fils","Ma fille") +", nous avons déjà parlé aujourd'hui. Avez-vous besoin d'autre chose ?", ""+ GetSexPhrase("Mon fils","Ma fille") +", les novices de notre ordre ne brillent pas par leur patience. Je vous le redemande : avez-vous besoin de quelque chose ?",
							RandPhraseSimple("Il n'est pas bon d'être soi-même oisif et de distraire les autres de leur travail. Je ne dirai plus un mot...", ""+ GetSexPhrase("Mon fils","Ma fille") +", je ne veux pas de conversations vaines. Je ne vous dirai plus un mot."), "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Je passais juste, saint père...", "Le travail, padre. Je m'active comme une abeille,"+ GetSexPhrase("tout entier","toute entière") +" à mes affaires..."),
							"Non, saint père...", "Non, padre, je voulais juste bavarder...", RandPhraseSimple("Hum...", "Eh bien, comme vous le savez, saint père..."), npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("exit", "none", "none", "NoMoreTalkExit", npchar, Dialog.CurrentNode);

				// Gregg: --> "Помощь святой инквизиции" (перенос из К:ПС)
				// Выдача перебивает приветствие намеренно: это завязка, а не пункт меню.
				if (!CheckAttribute(pchar, "HelpSacredInquisition"))
				{
					dialog.text = "J'ai peine à le croire : un capitaine est arrivé en ville il n'y a pas longtemps, un hérétique notoire ! Si vous saviez à quel point cela trouble la Sainte Inquisition.";
					link.l1 = "Hum... Et qu'a-t-il fait, au juste ?";
					link.l1.go = "HelpSacredInquisition_1";
					link.l2 = "Pardonnez-moi, je n'ai pas le temps.";
					link.l2.go = "exit";
					break;
				}
				if (pchar.HelpSacredInquisition == "Good")
				{
					link.l2 = "Nathan Rich a eu ce qu'il méritait, mon père. Et un aller simple pour l'enfer.";
					link.l2.go = "HelpSacredInquisition_6";
				}
				// Gregg: <-- "Помощь святой инквизиции"
				if (CheckAttribute(pchar,"GiantEvilSkeleton") && CheckAttribute(pchar,"MalteseInfo") && !CheckAttribute(pchar,"MalteseOrder"))
				{
					link.l2 = "Saint père, je voulais vous informer que j'ai visité le récif du Squelette et que j'y ai détruit les morts-vivants. Peut-être devrais-je recevoir une récompense ?";
					link.l2.go = "Maltese";
					if (CheckAttribute(pchar,"MalteseOrderOnHold"))
					{
						link.l2 = "Je veux encore parler du récif du Squelette.";
						link.l2.go = "Maltese_5";
					}
				}
			}
			if (CheckAttribute(npchar, "protector.CheckAlways")) //гарды на камерах
			{
				if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY)
				{
					dialog.text = "Bon sang, c'est un espion ! Arrêtez-le !!!";
					link.l1 = "Caramba !!";
					link.l1.go = "fight";
					StartIncquisitioAttack();
				}
				else
				{
					dialog.text = LinkRandPhrase("C'est une cellule sous haute garde, l'entrée y est strictement interdite !!!", "N'y pensez même pas : entrer ici est passible de mort.", "Un pas dans cette cellule, et c'en est fini de vous...");
					link.l1 = RandPhraseSimple("Je vois, soldat.", "Je vois...");
					link.l1.go = "exit";
				}
			}
			if (findsubstr(npchar.id, "Prisoner", 0) != -1) //заключённые
			{
				if (LAi_group_IsActivePlayerAlarm())
				{
					dialog.text = LinkRandPhrase("Ho ho, quel plaisir de voir ces « saints » filer droit en enfer !", "Mon Dieu, quelqu'un a osé les défier !!", "Je ne suis plus de ce monde : la torture... Mais vous m'avez offert le dernier plaisir de ma vie. Merci...");
					link.l1 = RandPhraseSimple("Hé !", "Argh...");
					link.l1.go = "exit";
					//==> квест №7, базар о Роке Бразильце.
					if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
					{
						link.l1 = "וcoute, tu connais ici un certain Rock le Brésilien ?";
						link.l1.go = "Step_F7_2";
					}
					//<== квест №7, базар о Роке Бразильце.
				}
				else
				{
					dialog.text = LinkRandPhrase("Il n'y a rien d'humain chez ces « saints ». Retenez bien mes paroles : qu'ils brמlent en enfer pour nos tourments...", "Des tortures et encore des tortures, tous les jours ! Mais je ne suis coupable de rien devant le Seigneur !!!", "Mon compagnon de cellule est mort hier, ils l'ont torturé sur le chevalet pendant deux jours... Et moi, combien de temps me reste-t-il ?");
					link.l1 = RandPhraseSimple("Hum... Eh bien, je ne sais pas...", "Bon, je comprends...");
					link.l1.go = "exit";
					//==> квест №7, базар о Роке Бразильце.
					if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
					{
						link.l1 = "וcoute, tu connais ici un certain Rock le Brésilien ?";
						link.l1.go = "Step_F7_1";
					}
					//<== квест №7, базар о Роке Бразильце.
				}
			}
		break;

		// Gregg: --> "Помощь святой инквизиции"
		case "HelpSacredInquisition_1":
			dialog.text = "Comment ? Vous ne le savez pas ? Il a répandu l'idée que n'importe quel homme peut détenir la puissance de Dieu.";
			link.l1 = "Une affirmation audacieuse.";
			link.l1.go = "HelpSacredInquisition_2";
		break;

		case "HelpSacredInquisition_2":
			dialog.text = "Vous arrivez au bon moment. Au nom de toute la Sainte Inquisition, je vous demande votre aide.";
			link.l1 = "Vous voulez...";
			link.l1.go = "HelpSacredInquisition_3";
		break;

		case "HelpSacredInquisition_3":
			dialog.text = "Trouvez-le et châtiez-le ! Nous vous pardonnerons tous les péchés que vous devrez commettre pour que justice soit faite. Et nous vous récompenserons, bien sמr.";
			link.l1 = "Non. זtre la main de Dieu, ce n'est pas pour moi.";
			link.l1.go = "HelpSacredInquisition_4";
			link.l2 = "Très bien. Son nom ? Et avez-vous une idée de l'endroit oם le chercher ?";
			link.l2.go = "HelpSacredInquisition_5";
		break;

		// Gregg: отказ. Ставим "END" - предложение больше не всплывёт.
		case "HelpSacredInquisition_4":
			pchar.HelpSacredInquisition = "END";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "HelpSacredInquisition_5":
			dialog.text = "Si seulement je savais oם chercher. Il a sמrement pris la mer pour quelque part. Il s'appelle Nathan Rich.";
			link.l1 = "Alors, je me mets à sa recherche. א bientכt, mon père.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionStart");
		break;

		case "HelpSacredInquisition_6":
			dialog.text = "La Sainte Inquisition vous remercie, capitaine " + GetFullName(pchar) + ".";
			link.l1 = "Merci, mon père.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionEnd");
		break;
		// Gregg: <-- "Помощь святой инквизиции"

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NoMoreTalkExit":
			LAi_CharacterDisableDialog(npchar);
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

//**************************** Фр. линейка. Квест №7, спасение Рока Бразильца ********************************
 		case "Step_F7_1":
			dialog.text = "Je sais, il est dans la dernière cellule, gardée par ce soldat, là-bas. Une place spéciale...";
			link.l1 = "Merci !";
			link.l1.go = "exit";
		break;
 		case "Step_F7_2":
			dialog.text = "Dans la dernière cellule à droite de l'entrée, là oם se tenait la sentinelle avant que vous ne la tuiez...";
			link.l1 = "Oui, je vois... Merci.";
			link.l1.go = "exit";
		break;

//**************************** запил Капитула ********************************
		case "Maltese":
			dialog.text = "C'est une très bonne nouvelle, "+ GetSexPhrase("mon fils","ma fille") +", l'Inquisition voulait depuis longtemps créer une nouvelle base quelque part dans l'archipel. Et cette île abandonnée et mal famée est parfaite pour cela.";
			link.l1 = "Alors, ai-je droit à une récompense ?";
			link.l1.go = "Maltese_2";
		break;

		case "Maltese_2":
			dialog.text = "Nous pouvons vous verser un million de piastres en récompense. Mais nous avons une autre proposition. Voulez-vous l'écouter ?";
			link.l1 = "Et de quoi s'agit-il ?";
			link.l1.go = "Maltese_3";
		break;

		case "Maltese_3":
			dialog.text = "Si vous payez vous-même la construction, nous vous nommerons à la tête de cet ouvrage. Et nous fournirons nos spécialistes pour l'instruction des hommes du rang et des officiers.";
			link.l1 = "Quelles seront mes responsabilités ?";
			link.l1.go = "Maltese_4";
		break;
		case "Maltese_4":
			dialog.text = "Votre but sera de veiller à ce que la base ne soit pas attaquée par les morts-vivants. Et si cela arrive, de la protéger.";
			link.l1 = "C'est tentant... Mais je suppose que le prix de l'affaire est d'un million de piastres ?";
			link.l1.go = "Maltese_5";
		break;

		case "Maltese_5":
			if (!CheckAttribute(pchar,"MalteseOrderOnHold")) dialog.text = "Exactement. Alors, qu'en dites-vous ?";
			else dialog.text = "Et qu'en dites-vous ?";
			if (sti(pchar.money)>=1000000)
			{
				link.l1 = "De toute façon, je ne sais plus oם mettre mon or, et les conditions me conviennent. Tenez, voici un million de piastres.";
				link.l1.go = "Maltese_6";
			}
			link.l2 = "Je n'ai pas cette somme en ce moment.";
			link.l2.go = "Maltese_51";
			link.l3 = "Je préfère ne pas prendre une telle responsabilité. Je prendrai le million de piastres.";
			link.l3.go = "Maltese_no";
		break;

		case "Maltese_6":
			AddMoneyToCharacter(pchar, -1000000);
			dialog.text = "Je suis heureux que vous ayez accepté. La construction de la maison du Chapitre (c'est ainsi que s'appellera cet ouvrage) sera achevée dans un mois environ. Le moment venu, rendez-vous à la crique du Diable et cherchez-y l'entrée.";
			link.l1 = "Le moment venu, je le ferai.";
			link.l1.go = "Maltese_build";
		break;

		case "Maltese_build":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.MalteseOrder = true;
			SetTimerFunction("BuildMalteseOrder", 0, 0, 30);
		break;

		case "Maltese_no":
			AddMoneyToCharacter(pchar, 1000000);
			dialog.text = "C'est votre droit. Tenez, voici votre million.";
			link.l1 = "Merci. Je dois y aller.";
			link.l1.go = "Maltese_nofix";
		break;

		case "Maltese_nofix":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.MalteseOrder = true;
		break;

		case "Maltese_51":
			dialog.text = "Bien. Dès que vous aurez réuni la somme nécessaire ou pris une autre décision, parlez à n'importe lequel d'entre nous.";
			link.l1 = "Je dois y aller.";
			link.l1.go = "Maltese_52";
		break;

		case "Maltese_52":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.MalteseOrderOnHold = true;
		break;
	}
}
