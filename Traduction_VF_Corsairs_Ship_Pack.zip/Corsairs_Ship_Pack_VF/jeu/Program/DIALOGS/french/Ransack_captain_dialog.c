// BOAL диалог пленников - в трюме
void ProcessDialogEvent()
{
	ref NPChar;
	ref rColony;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref offref;
    int i, cn;
    int qty;
    string attrLoc, sTmp;

	// LEO: гарантируем NPChar.EncType — без него ветки `if(NPChar.EncType == ...)` падают (RUNTIME ERROR "missed attribute:
	//   enctype") и НЕ ставят dialog.text -> у пленника пустой диалог (особенно при повторном заходе, где текст только в этих
	//   ветках). Восстанавливаем тип из сохранённого режима корабля (Back.Ship.Mode), иначе военный по умолчанию.
	if (!CheckAttribute(NPChar, "EncType"))
	{
		if (CheckAttribute(NPChar, "Back.Ship.Mode")) NPChar.EncType = NPChar.Back.Ship.Mode;
		else NPChar.EncType = "war";
	}

	switch(Dialog.CurrentNode)
	{
		// -----------------------------------Диалог первый - первая встреча
		case "First time":
			if (sti(NPChar.nation) == PIRATE)
			{
				dialog.text = RandSwear() + "Je suis votre prisonnier, " + GetAddress_Form(NPChar) + ". Mais je dois dire que " + NationNameNominative(sti(NPChar.nation)) + " ne rachète jamais les siens : chacun pour soi.";
				link.l1 = "Hum... La seule façon de gagner de l'argent avec toi, c'est de te livrer comme criminel dans un port contre une prime.";
				link.l1.go = "offender";
				if (FindFreeRandomOfficer() > 0)
				{
					link.l2 = "וcoute, tu n'es pas un mauvais combattant, et il me faut justement des coupe-jarrets prêts à tout. דa te dirait de servir comme officier chez moi ?";
					link.l2.go = "free_to_officer";
					if (pchar.sex == "Skeleton")
					{
						DeleteAttribute(link, "l2");
					}
				}
			}
			else
			{
				dialog.text = RandSwear() + "Je suis votre prisonnier, " + GetAddress_Form(NPChar) + ". " + NationNameNominative(sti(NPChar.nation)) + " paiera une bonne somme pour ma liberté.";
				if(NPChar.EncType == "trade" && FindFreeRandomOfficer() > 0 && CheckAttribute(NPChar, "Back.Ship.Mode") && NPChar.Back.Ship.Mode == "trade")
				{
					link.l1 = "וcoute, tu es un bon marin, et j'ai besoin de marins expérimentés. דa te dirait de servir sous mes ordres ?";
					link.l1.go = "free_to_officer_trader";
					if (pchar.sex == "Skeleton")
					{
						DeleteAttribute(link, "l1");
					}
				}
			}
			attrLoc = Sea_FindNearColony();
			if (attrLoc != "none" && FindColony(attrLoc) != -1)
			{
				rColony = GetColonyByIndex(FindColony(attrLoc));
                link.l3 = "Nous sommes près de la ville de " + GetConvertStr(attrLoc +" Town", "LocLables.txt") + ". Je pourrais vous débarquer ici.";
			    link.l3.go = "free_withoutFee";
			}
			else
			{
                link.l3 = "Allez voir le maître d'équipage, dites-lui de vous attribuer un coffre sur le gaillard d'avant. Vous descendrez à terre dans la baie la plus proche.";
			    link.l3.go = "free_withoutFee_2";
			}
			link.l4 = "Je pense que vous ferez un excellent esclave : solide et obéissant.";
			link.l4.go = "Slave_1";
			link.l5 = "Vous avez ignoré l'ordre de mettre en panne et opposé une résistance : pour cela, vous serez exécuté. Le maître d'équipage a déjà reçu les ordres nécessaires.";
			link.l5.go = "PunishmentAction";
			link.l99 = "Je sais.";
			link.l99.go = "exit";
			NextDiag.TempNode = "second time";
			// pirate captain hunting contraband runners (the contraband-freight sea hazard)
			if (CheckAttribute(NPChar, "ContraHunter"))
				dialog.text = RandSwear() + RandPhraseSimple(
					"Je te tiens, contrebandier ! Je chasse les gens de ton espèce, ceux qui transportent des cargaisons qui valent une proie facile. Ce n'est pas ton jour, hein ?",
					"Tiens, tiens... encore un messager des contrebandiers. Je guettais les gens comme toi. Tu croyais passer inaperçu avec la cargaison d'un autre ?");
		break;

		case "second time":
			if(CheckAttribute(NPChar, "Hold_GenQuest") && !CheckAttribute(pchar, "GenQuest.Hold_GenQuest"))
			{
				switch(sti(NPChar.Hold_GenQuest.variant))
				{
					case 0: // "tip-off"
						dialog.text = RandPhraseSimple("Capitaine, trouveriez-vous impertinent que je vous propose une solution plutכt avantageuse pour ma libération ?",
							"Je comprends qu'il est mal venu de marchander dans ma situation, mais accepteriez-vous d'écouter une proposition d'affaires, pour ainsi dire ?");
						link.l1 = "Hum, bon, exposez votre proposition.";
						link.l1.go = "free_tip_off";
					break;

					case 1:
						dialog.text = "Capitaine, laissez-moi partir. א quoi je vous sers maintenant ? Bon, vendez-moi aux négriers : vous en tirerez peut-être une poignée de piastres, mais vous y gagnerez une réputation de cruauté.";
						link.l1 = "Si je vous laisse partir, je ne gagnerai rien du tout...";
						link.l1.go = "free_by_hoard";
						attrLoc = Sea_FindNearColony();
						if (attrLoc != "none")
						{
							link.l2 = "Vous avez ignoré l'ordre de mettre en panne et opposé une résistance : pour cela, vous serez exécuté. Le maître d'équipage a déjà reçu les ordres nécessaires.";
							link.l2.go = "PunishmentAction";
						}
						else
						{
							link.l2 = "Vous insistez tant pour être libéré que je suis prêt à faire un pas vers vous. Vous êtes libre de quitter le navire.";
							link.l2.go = "free_in_sea";
						}
						link.l3 = LinkRandPhrase("Ne mettez pas ma patience à l'épreuve. Vous avez déjà de la chance d'être en vie.",
							"J'ai d'autres projets pour vous.", "Je crois que j'aurai encore besoin de vous.");
						link.l3.go = "exit";
					break;

					case 2: // "ransom"
						dialog.text = "Capitaine, l'incertitude est des plus pénibles. Puis-je vous demander ce que vous comptez faire de moi ?";
						link.l1 = "Vous avez des suggestions précises ?";
						link.l1.go = "free_buyout";
						link.l2 = RandPhraseSimple(RandPhraseSimple("Je n'ai pas encore décidé ce que je vais faire de vous.", "Vous le saurez le moment venu."),
							RandPhraseSimple("Quels projets ? Un boulet au cou, et hop... Je plaisante, je plaisante.", "Vous êtes mon prisonnier, et j'ai le droit de faire de vous ce que bon me semble, sans tenir compte ni de votre avis ni de vos désirs."));
						link.l2.go = "exit";
					break;
				}
				NextDiag.TempNode = "second time";
			}
			else
			{
				if (sti(NPChar.nation) == PIRATE)
				{
					dialog.text = "Capitaine, laissez-moi partir gentiment, sans rancune. De quoi pouvez-vous m'accuser ? Après tout, ce n'est pas par plaisir que je me suis lancé dans le brigandage : je ne sais rien faire d'autre. Je pensais mettre un peu d'argent de cכté pour mes vieux jours, mais voilà comment ça a tourné.";
					if (FindFreeRandomOfficer() > 0)
					{
						link.l2 = "וcoute, tu n'es pas un mauvais combattant, et il me faut justement des coupe-jarrets prêts à tout. דa te dirait de servir comme officier chez moi ?";
						link.l2.go = "free_to_officer";
						if (pchar.sex == "Skeleton")
						{
							DeleteAttribute(link, "l2");
						}
					}
					link.l3 = LinkRandPhrase("N'attendez aucune pitié. Il y en a beaucoup comme vous qui rכdent en mer, il y en aura un de moins.",
						"Qu'est-ce que tu pleurniches, 'terreur des mers' ? Tu t'es fait prendre, alors assume.",
						"Tant va la cruche à l'eau qu'à la fin elle se casse. Je vais vous livrer aux autorités, pour que les autres ne soient plus lésés.");
					link.l3.go = "exit";
				}
				else
				{
					if(NPChar.EncType == "trade")
					{
						dialog.text = "Capitaine, je vous en prie par tous les saints, laissez-moi partir en paix. J'ai une famille à la maison, des petits enfants : que vont-ils devenir sans soutien de famille ? Ils m'ont sans doute déjà enterré...";
						if (FindFreeRandomOfficer() > 0 && CheckAttribute(NPChar, "Back.Ship.Mode") && NPChar.Back.Ship.Mode == "trade")
						{
							link.l2 = "וcoute, tu es un bon marin, et j'ai besoin de marins expérimentés. דa te dirait de servir sous mes ordres ?";
							link.l2.go = "free_to_officer_trader";
							if (pchar.sex == "Skeleton")
							{
								DeleteAttribute(link, "l2");
							}
						}
						link.l3 = LinkRandPhrase("J'ai d'autres projets pour vous.", "Je pense que vous me serez encore utile.", "Capitaine, j'ai perdu ma bataille et je veux vous demander de l'indulgence. En personne généreuse, laissez-moi partir, pour la gloire de la miséricorde. De toute façon, je n'échapperai pas à la punition : je serai dégradé pour avoir rendu le navire. Alors au moins, ne me privez pas de ma liberté...");
						link.l3.go = "exit";
					}
					if(NPChar.EncType == "war")
					{
						dialog.text = RandPhraseSimple("Capitaine, je fais appel à votre générosité ! Je comprends qu'il est inutile d'exiger que vous me traitiez en prisonnier de guerre, alors je vous demande de me relâcher. Je vous donne ma parole d'officier que j'éviterai de vous croiser à l'avenir.",
							"Ne mettez pas ma patience à l'épreuve. Vous avez déjà de la chance d'être en vie.");
						link.l2 = LinkRandPhrase("J'ai d'autres projets pour vous.",
							RandPhraseSimple("Je crois que j'aurai encore besoin de vous.", "Vous êtes mon prisonnier, et j'ai le droit de faire de vous ce que bon me semble, sans tenir compte ni de votre avis ni de vos désirs."),
							RandPhraseSimple("Vous êtes capitaine d'un navire de guerre et vous saviez ce que vous faisiez. Inutile de jouer les saints maintenant.",
							"וcoute, tu n'es pas un mauvais combattant, et il me faut justement des coupe-jarrets prêts à tout. דa te dirait de servir comme officier chez moi ?"));
						link.l2.go = "exit";
						if (isMainCharacterPatented() && sti(Items[sti(pchar.EquipedPatentId)].TitulCur) > 1)
						{
							if(sti(Items[sti(pchar.EquipedPatentId)].Nation) == sti(NPChar.nation) && FindFreeRandomOfficer() > 0)
							{
								link.l3 = "וcoute, tu n'es pas un mauvais combattant, et il me faut justement des coupe-jarrets prêts à tout. דa te dirait de servir comme officier chez moi ?";
								link.l3.go = "free_to_officer";
							}
						}
					}
				}
				attrLoc = Sea_FindNearColony();
				if (attrLoc != "none" && FindColony(attrLoc) != -1)
				{
					rColony = GetColonyByIndex(FindColony(attrLoc));
					link.l4 = "Nous sommes près de la ville de " + GetConvertStr(attrLoc +" Town", "LocLables.txt") + ". Je pourrais"+ GetSexPhrase(" vous débarquer près d'ici. ", " vous débarquer près d'ici. ") +"Allez voir le maître d'équipage, dites-lui de vous attribuer un coffre sur le gaillard d'avant. Vous descendrez à terre dans la baie la plus proche.";
					link.l4.go = "free_withoutFee";
				}
				else
				{
					if(NPChar.EncType == "trade" || NPChar.EncType == "pirate")
					{
						link.l4 = "Au diable ! Allez voir le maître d'équipage, il recevra les ordres nécessaires : on vous débarquera dans la baie la plus proche. Et souvenez-vous : notre prochaine rencontre sera la dernière.";
						link.l4.go = "free_withoutFee_4";
					}
					else
					{
						link.l4 = "Vous avez ignoré l'ordre de mettre en panne et opposé une résistance : pour cela, vous serez exécuté. Le maître d'équipage a déjà reçu les ordres nécessaires.";
						link.l4.go = "free_withoutFee_4";
					}
				}
				link.l5 = "Vous avez ignoré l'ordre de mettre en panne et opposé une résistance : pour cela, vous serez exécuté. Le maître d'équipage a déjà reçu les ordres nécessaires.";
				link.l5.go = "PunishmentAction";
				NextDiag.TempNode = "second time";
			}
		break;

		case "offender":
			dialog.text = "Un criminel ? Vous plaisantez sans doute, " + GetAddress_Form(NPChar) + " !";
			link.l1 = "Quelles plaisanteries ? Un pirate est un pirate.";
			link.l1.go = "exit";
		break;

		case "free_to_officer":
			// captains who surrendered under pressure and quest hunters (gentlemen of fortune etc.) won't serve
			if (CheckAttribute(NPChar, "NoOfficerHire"))
			{
				dialog.text = "Vous servir ? Jamais. Faites de moi ce que vous voudrez, mais je ne recevrai pas d'ordres de vous.";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "exit";
				break;
			}
			if ((GetSummonSkillFromName(pchar, "Leadership") + 20) <= GetSummonSkillFromName(npchar, "Leadership"))
			{
				dialog.text = "Vous servir ? Non, mieux vaut nourrir les requins !";
				link.l1 = "Tiens ta langue, ou c'est moi qui m'en chargerai.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Officier, " + GetAddress_Form(NPChar) + " ? Je ne refuserai pas. Je connais le métier, et je sais combien de temps on peut traîner l'ancre en attendant de rencontrer la corde.";
				link.l1 = "Voilà qui est réglé ! Va prendre tes fonctions.";
				link.l1.go = "free_to_officer_Hire";
				link.l2 = "Attends, j'ai changé d'avis. Avoir un ancien pirate comme officier, ça coמte trop cher.";
				link.l2.go = "exit";
			}
		break;

		case "free_to_officer_trader":
			if (CheckAttribute(NPChar, "NoOfficerHire"))
			{
				dialog.text = "Pardonnez-moi, capitaine, mais je ne vous servirai pas. Après tout ça, épargnez-moi.";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "exit";
				break;
			}
			if (GetSummonSkillFromName(pchar, "Leadership") <= GetSummonSkillFromName(npchar, "Leadership"))
			{
				dialog.text = LinkRandPhrase("C'est certes une proposition flatteuse, mais je dois refuser... pour des raisons idéologiques, pour ainsi dire.",
					"Hélas, après ce que vous avez fait à mes camarades, ce n'est guère possible...",
					"Non, capitaine, après toute cette horreur, je ne peux plus. J'ai fait le vœu que, si la Sainte Vierge entendait mes prières et m'accordait la liberté, je ne remettrais plus jamais les pieds en mer.");
				link.l1 = "Eh bien, comme vous voudrez. Je ne vais pas supplier.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Pourquoi ne pas servir ? Je n'ai pas fait un bon capitaine, j'ai ruiné mon affaire : qu'est-ce qui m'attend à terre, à part des lettres de change et des reconnaissances de dettes ? Un marin reste un marin.";
				link.l1 = "Voilà qui est réglé ! Va voir le maître d'équipage, qu'il t'inscrive au rכle. Ensuite, je déciderai de ton poste.";
				link.l1.go = "free_to_officer_Hire";
				link.l2 = "Attends, j'ai changé d'avis. Un navire n'est quand même pas un moulin.";
				link.l2.go = "exit";
			}
		break;

		case "free_to_officer_Hire":
            NPChar.Dialog.Filename = "Enc_Officer_dialog.c";
            NPChar.greeting = "Gr_Officer";
            NPChar.loyality = 5 + rand(10);
		    if (sti(NPChar.reputation) >= 40)
		    {
		        NPChar.alignment = "good";
		    }
		    else
		    {
		        NPChar.alignment = "bad";
		    }
            ReleasePrisoner(NPChar); // освободили пленника
            DeleteAttribute(NPChar, "LifeDay") // постоянный
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			// тут трём накопивщиеся сабли и корабли 290704 BOAL -->
			DeleteAttribute(Npchar, "Ship");
			Npchar.Ship.Type = SHIP_NOTUSED;
            DeleteAttribute(Npchar, "Fellows"); // его офицеры
            Npchar.Fellows.Passengers.id0 = Npchar.index; // свой пассажир

			Npchar.Fellows.Passengers.boatswain = "-1";
			Npchar.Fellows.Passengers.navigator = "-1";
			Npchar.Fellows.Passengers.doctor = "-1";
			Npchar.Fellows.Passengers.cannoner = "-1";
			Npchar.Fellows.Passengers.treasurer = "-1";
			Npchar.Fellows.Passengers.carpenter = "-1";

			if(CheckAttribute(NPChar, "Hold_GenQuest")) DeleteAttribute(NPChar, "Hold_GenQuest");

			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			DialogExit();
        break;

		case "Slave_1":
			dialog.text = "Mais, " + GetAddress_Form(NPChar) + ", vous ne pouvez pas faire ça ! Je me suis rendu à votre merci pendant le combat.";
            link.l1 = "Assez de discussions ! Mettez-le aux fers.";
			link.l1.go = "Slave_2";
			link.l99 = "Bon, d'accord, je vais y réfléchir, restez assis pour l'instant...";
			link.l99.go = "exit";
		break;

		case "Slave_2":
			OfficersReaction("bad");
			ChangeCharacterReputation(pchar, -2);
            if (rand(5) == 1)
            {
    			dialog.text = "Pas question !.. Je préfère me tuer plutכt que de devenir esclave !";
                link.l1 = "Arrête ! Je te l'ordonne !.. Maître d'équipage ! Nettoyez la cale...";
    			link.l1.go = "free_in_sea_4";
			}
			else
			{
                if (rand(1) == 1)
                {
                    if (GetPrisonerQty() > 1)
                    {
                        dialog.text = "Oh, bourreau ! Frères, on ne meurt qu'une fois !";
                        link.l1 = "Vous n'auriez pas dמ faire ça. Je mate les tentatives de rébellion de ma propre main et sans délai...";
            			link.l1.go = "free_in_sea_battle_all";
                    }
					else
					{
						dialog.text = "Non ! Mieux vaut mourir au combat !";
						link.l1 = "Comme vous voudrez...";
						link.l1.go = "free_in_sea_battle_1";
					}
    			}
    			else
    			{
					dialog.text = "D'accord, j'accepte. Je n'ai tout simplement pas d'autre choix...";
                    link.l1 = "Voilà qui est bien. Mieux vaut un esclave vivant qu'un héros mort.";
        			link.l1.go = "Slave_3";
    			}
			}
		break;

		case "Slave_3":
            ReleasePrisoner(NPChar); //  пленника в рабы
        	LAi_SetActorType(NPChar);
        	LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 4.0);
        	ChangeCharacterReputation(pchar, -6);
        	DialogExit();
        	AddCharacterGoodsSimple(pchar, GOOD_SLAVES, 1);
        break;

		case "free_withoutFee":
			dialog.text = "Oh, " + GetAddress_Form(NPChar) + "Seriez-vous assez bon pour me laisser partir sans rançon ?";
            link.l1 = "Oui, je vous laisse partir. Vous êtes libre, " + GetFullName(NPChar);
			link.l1.go = "free_withoutFee_2";
			link.l99 = "Hum... oui, vous avez raison ! Je vais y réfléchir...";
			link.l99.go = "exit";
		break;

		case "free_withoutFee_2":
			dialog.text = "Merci, " + GetFullName(PChar) + " ! Je prierai pour vous.";
            link.l1 = "D'accord, partez, avant que je change d'avis.";
			link.l1.go = "free_withoutFee_3";
			OfficersReaction("good");
		break;

		case "free_withoutFee_3":
            ReleasePrisoner(NPChar); // освободили пленника
        	LAi_SetActorType(NPChar);
        	LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 4.0);
        	ChangeCharacterReputation(pchar, 2);
        	AddGoodDeed("FreePrisonerCaptain", 1); // Gregg: доброе дело - отпустил пленного
        	DialogExit();
        break;

		case "free_withoutFee_4":
			switch(NPChar.EncType)
			{
				case "pirate":
					dialog.text = RandPhraseSimple("Merci, capitaine. Je n'oublierai jamais votre bonté. Je vais abandonner ce métier et trouver du travail à réparer des chaloupes. C'est ce que je sais faire...",
						"Merci, capitaine. Ma propre mère n'aurait pas su me réconforter ainsi. Je vous le jure sur la croix : j'abandonne ce métier ingrat, je vais devenir pêcheur.");
					link.l1 = "J'aimerais le croire...";
				break;
				case "trade":
					dialog.text = "Je ne sais même pas comment vous remercier, capitaine. Je ne m'attendais pas à être délivré. Je raconterai votre générosité à tout le monde. Et je le jure, j'allumerai un cierge pour vous, pourvu que j'arrive jusqu'à l'église !";
					link.l1 = "Adieu, et à l'avenir, n'essayez pas de résister. Votre premier coup de feu, c'est un arrêt de mort pour vous et pour l'équipage.";
				break;
				case "war":
					dialog.text = "Merci, capitaine. Je prierai pour vous.";
					link.l1 = "Retenez bien pour l'avenir que la prochaine fois, je pourrais être moins indulgent.";
				break;
			}
			link.l1.go = "free_withoutFee_3";
		break;

		case "free_in_sea_battle_1":
            ReleasePrisoner(NPChar); // освободили пленника
        	LAi_LocationFightDisable(&Locations[FindLocation("My_Deck")], false);
            LAi_SetFightMode(Pchar, true);
            LAi_SetWarriorType(NPChar);
            LAi_group_MoveCharacter(NPChar, LAI_GROUP_TmpEnemy);
            LAi_group_SetHearRadius(LAI_GROUP_TmpEnemy, 100.0);
            LAi_group_FightGroupsEx(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
            LAi_group_SetRelation(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_SetCheck(LAI_GROUP_TmpEnemy, "My_Deck_Battle_End");
            LAi_group_SetRelation(LAI_GROUP_TmpEnemy, "Prisoner", LAI_GROUP_NEITRAL);
        	DialogExit();
        break;

		case "free_in_sea_battle_all":
			//ugeen --> привет Сиварду !!! после релиза пленников кол-во пассажиров уменьшается и цикл нихрена дальше не срабатывал
			for(int j = GetPassengersQuantity(pchar) - 1; j > -1; j--)
            {
                cn = GetPassenger(pchar, j);
                if(cn != -1)
                {
                    offref = GetCharacter(cn);
                    if (CheckAttribute(offref, "prisoned"))
                    {
        	            if(sti(offref.prisoned)==true && GetRemovable(offref)) // ставим только фантомов
        	            {
                        	ReleasePrisoner(offref); // освободили пленника
							LAi_SetWarriorType(offref);
							LAi_warrior_DialogEnable(offref, false);
                            LAi_group_MoveCharacter(offref, LAI_GROUP_TmpEnemy);
                        }
                    }
                }
            }
            LAi_LocationFightDisable(&Locations[FindLocation("My_Deck")], false);
            LAi_SetFightMode(Pchar, true);
			LAi_group_SetHearRadius(LAI_GROUP_TmpEnemy, 100.0);
            LAi_group_FightGroupsEx(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
            LAi_group_SetRelation(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_SetCheck(LAI_GROUP_TmpEnemy, "My_Deck_Battle_End");
        	DialogExit();
        break;

		case "free_in_sea_4":
        	ReleasePrisoner(NPChar); // освободили пленника
            NPChar.location = "";
	        LAi_KillCharacter(NPChar);
        	DialogExit();
        break;

		case "PunishmentAction":
			dialog.text = "Mais, " + GetAddress_Form(NPChar) + ", vous ne pouvez pas faire ça ! Je me suis rendu à votre merci pendant le combat.";
			link.l1 = "Après la mort des gens que vous venez de trahir... Maître d'équipage ! Au travail.";
			link.l1.go = "PunishmentAction1";
			link.l2 = "Bon, d'accord, je vais y réfléchir, restez assis pour l'instant...";
			link.l2.go = "exit";
        break;

		case "PunishmentAction1":
			OfficersReaction("bad");
			ChangeCharacterReputation(pchar, -2);
			AddCharacterExpToSkill(Pchar, "Leadership", -150);
			if (rand(1) == 1)
            {
                if (GetPrisonerQty() > 1)
                {
                    dialog.text = "Oh, bourreau ! Frères, on ne meurt qu'une fois !";
                    link.l1 = "Vous n'auriez pas dמ faire ça. Je mate les tentatives de rébellion de ma propre main et sans délai...";
					link.l1.go = "free_in_sea_battle_all";
                }
				else
				{
					dialog.text = "Non ! Mieux vaut mourir au combat !";
					link.l1 = "Comme vous voudrez...";
					link.l1.go = "free_in_sea_battle_1";
				}
    		}
			else
    		{
				dialog.text = "Laissez-moi au moins prier avant de mourir...";
                link.l1 = "Priez...";
        		link.l1.go = "PunishmentAction2";
    		}
		break;

		case "PunishmentAction2":
        	ReleasePrisoner(NPChar); // освободили пленника
            NPChar.location = "";
			NPChar.LifeDay = 0;
			LAi_CharacterDisableDialog(NPChar);
			DialogExit();
		break;

		case "free_tip_off":
			dialog.text = "J'ai une information qui, vu la nature de vos affaires, pourrait vous intéresser. Mais j'aimerais avoir la garantie d'obtenir ma liberté en échange.";
			link.l1 = "Comment puis-je vous garantir quoi que ce soit, si je ne sais pas de quoi il s'agit ? Votre information ne vaut sמrement pas un clou.";
			link.l1.go = "free_tip_off_0";
			link.l2 = "Quelles garanties attendez-vous, à part ma parole d'honneur ?";
			link.l2.go = "free_tip_off_1";
		break;

		case "free_tip_off_0":
			ChangeCharacterReputation(pchar, -2);
			DeleteAttribute(NPChar, "Hold_GenQuest");
			DialogExit();
		break;

		case "free_tip_off_1":
			switch(NPChar.EncType)
			{
				case "trade":
					sTmp = "Je voulais moi aussi affréter son navire, mais il était trop gourmand sur le prix : j'ai refusé.";
				break;
				case "war":
					sTmp = "J'ai dמ l'accompagner plusieurs fois comme capitaine d'escorte.";
				break;
				case "pirate":
					sTmp = "J'ai pensé à le dépouiller une fois, mais je n'en ai pas eu l'occasion.";
				break;
			}
			dialog.text = "Bien. דa suffit. Venons-en au fait : à " + XI_ConvertString("Colony" + NPChar.Hold_GenQuest.City + "Voc") + " vit un riche marchand, " + NPChar.Hold_GenQuest.Name + ". " +
				"Il a fait sa fortune considérable avec son navire, le '" + NPChar.Hold_GenQuest.ShipName + "', qui transporte " + GetStrSmallRegister(XI_ConvertString(Goods[sti(NPChar.Hold_GenQuest.Goods)].Name + "Acc")) + " sur la route " + XI_ConvertString("Colony" + NPChar.Hold_GenQuest.FromCity) + " - " + XI_ConvertString("Colony" + NPChar.Hold_GenQuest.ToCity) +". " +
				"Quand une cargaison est trop grosse pour sa cale, il engage une escorte. " + sTmp + " Je suis sמr que cette information vaut bien plus pour vous que la liberté d'un prisonnier.";
			link.l1 = "Je ne pense pas qu'elle puisse m'être utile. Je ne chasserai pas de paisibles marchands.";
			link.l1.go = "free_tip_off_0";
			link.l2 = "Je ne sais pas si votre information me sera utile, mais, selon notre accord, vous êtes libre. Le maître d'équipage vous placera avec l'équipage, et vous débarquera au port le plus proche.";
			link.l2.go = "free_tip_off_2";
		break;

		case "free_tip_off_2":
			dialog.text = "Merci, capitaine ! Je n'ai pas douté une seconde de votre honnêteté !";
			link.l1 = RandPhraseSimple(RandPhraseSimple("J'aimerais penser la même chose de vous", "Malheureusement, je ne peux pas en dire autant de vous."),
				RandPhraseSimple("Retenez bien pour l'avenir que la prochaine fois, je pourrais être moins indulgent.", "Partez, et ne vous laissez plus prendre. Une autre fois, je ne serai pas si crédule."));
			link.l1.go = "free_tip_off_3";
		break;

		case "free_tip_off_3":
			pchar.GenQuest.Hold_GenQuest.Goods 			= NPChar.Hold_GenQuest.Goods;
			pchar.GenQuest.Hold_GenQuest.Nation 		= NPChar.Hold_GenQuest.Nation;
			pchar.GenQuest.Hold_GenQuest.Name 			= NPChar.Hold_GenQuest.Name;
			pchar.GenQuest.Hold_GenQuest.ToCity 		= NPChar.Hold_GenQuest.ToCity;
			pchar.GenQuest.Hold_GenQuest.FromCity 		= NPChar.Hold_GenQuest.FromCity;
			pchar.GenQuest.Hold_GenQuest.ShipName 		= NPChar.Hold_GenQuest.ShipName;
			pchar.GenQuest.Hold_GenQuest.City 			= NPChar.Hold_GenQuest.City;
			pchar.GenQuest.Hold_GenQuest.CapName		= GetFullName(NPChar);
			pchar.GenQuest.Hold_GenQuest.Island			= GetArealByCityName(pchar.GenQuest.Hold_GenQuest.City);
			pchar.GenQuest.Hold_GenQuest.Speak_Tavern 	= true;

			ReOpenQuestHeader("HoldQuest");
			AddQuestRecord("HoldQuest", "1");
			AddQuestUserData("HoldQuest", "sName", GetFullName(NPChar));
			AddQuestUserData("HoldQuest", "sGoods", GetStrSmallRegister(XI_ConvertString(Goods[sti(pchar.GenQuest.Hold_GenQuest.Goods)].Name + "Acc")));
			AddQuestUserData("HoldQuest", "sCityFrom", XI_ConvertString("Colony" + pchar.GenQuest.Hold_GenQuest.FromCity));
			AddQuestUserData("HoldQuest", "sCityTo", XI_ConvertString("Colony" + pchar.GenQuest.Hold_GenQuest.ToCity));
			AddQuestUserData("HoldQuest", "sShipName", pchar.GenQuest.Hold_GenQuest.ShipName);

			SetFunctionTimerCondition("Hold_GenQuest_SetMerchant_pre", 0, 0, 1+rand(2), false);
			SetFunctionTimerCondition("Hold_GenQuest_MerchantOver", 0, 0, 30, false);

            ReleasePrisoner(NPChar); // освободили пленника
        	LAi_SetActorType(NPChar);
			NPChar.LifeDay = 0;
        	LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 4.0);
        	DialogExit();
		break;

		case "free_buyout":
			dialog.text = "C'est juste, j'ai une proposition. א " + XI_ConvertString("Colony" + NPChar.Hold_GenQuest.City + "Voc") + " vit un bon ami à moi, " + NPChar.Hold_GenQuest.Name + " de son nom ; nous avons commencé les affaires ensemble. " +
				"Si nous passons par là-bas, trouvez-le. Je suis sמr qu'il ne sera pas pingre : il vous paiera une bonne rançon. Et moi, je le rembourserai à ma façon... D'ailleurs, il me doit un service.";
			link.l1 = "Un camarade, vous dites ? Eh bien, rendons visite à votre ami...";
			link.l1.go = "free_buyout1";
			link.l2 = "Je ne vais sמrement pas chercher votre camarade, alors que le premier gouverneur venu peut me payer une rançon pour vous.";
			link.l2.go = "free_tip_off_0";
		break;

		case "free_buyout1":
			LAi_CharacterDisableDialog(NPChar);

			pchar.GenQuest.Hold_GenQuest.City 		= NPChar.Hold_GenQuest.City;
			pchar.GenQuest.Hold_GenQuest.Nation 	= NPChar.Hold_GenQuest.Nation;
			pchar.GenQuest.Hold_GenQuest.Name 		= NPChar.Hold_GenQuest.Name;
			pchar.GenQuest.Hold_GenQuest.CapName	= GetFullName(NPChar);
			pchar.GenQuest.Hold_GenQuest.CapId		= NPChar.Id;
			pchar.GenQuest.Hold_GenQuest.TavernVariant = rand(1);
			pchar.GenQuest.Hold_GenQuest.Speak_Tavern = false;

			ReOpenQuestHeader("HoldQuest");
			AddQuestRecord("HoldQuest", "6");
			AddQuestUserData("HoldQuest", "sName", GetFullName(NPChar));
			AddQuestUserData("HoldQuest", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.Hold_GenQuest.City + "Voc"));
			AddQuestUserData("HoldQuest", "sNameChar", NPChar.Hold_GenQuest.Name);
			DialogExit();
		break;

		case "free_by_hoard":
			dialog.text = "Euh, ne m'en parlez pas... Je connais quelqu'un qui possède un énorme trésor, mais qui, par lâcheté, n'ose pas s'en servir.";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "free_by_hoard1";
			link.l2 = "Laissez vos histoires, c'est le moment de penser à votre âme.";
			link.l2.go = "free_tip_off_0";
		break;

		case "free_by_hoard1":
			dialog.text = "Je vais vous raconter cette histoire, qui mène tout droit à des richesses inouïes... Donnez-moi seulement votre parole que vous me relâcherez à la première crique.";
			link.l1 = "C'est moi qui déciderai quoi faire de vous, et quand. Cela ne dépendra pas de vos inventions.";
			link.l1.go = "free_tip_off_0";
			link.l2 = "Bon, racontez votre histoire. Je vous donne ma parole...";
			link.l2.go = "free_by_hoard2";
		break;

		case "free_by_hoard2":
			dialog.text = "Je crois un noble cœur ! Si vous avez donné votre parole, alors ho ho ho... Les diables peuvent bien danser tout autour, " +GetSexPhrase("il", "elle")+ " tiendra parole ! N'est-ce pas, capitaine " + GetFullName(pchar) + " ?";
			link.l1 = "Soit vous parlez, soit je vous relâche tout de suite... par-dessus bord.";
			link.l1.go = "free_by_hoard4";
		break;

		case "free_by_hoard4":
			dialog.text = "Héhé, elle est bonne, héhé... Et voici l'histoire. א " + XI_ConvertString("Colony" + NPChar.Hold_GenQuest.City + "Voc") + " vit un homme "+
				"du nom de " + NPChar.Hold_GenQuest.Name + ", qui, dans sa jeunesse, était un vrai casse-cou ; il en a fait tellement que ça fait peur rien que d'y penser... " +
				"Bref, un jour, autour d'une bouteille de rhum, ce bonhomme m'a raconté qu'alors qu'il naviguait dans la bande de " + GetName( NAMETYPE_VIP, NPChar.Hold_GenQuest.PirateName, NAME_ACC) + ", il avait assisté à l'enfouissement d'un trésor par les pirates." +
				"\nCinq de ses camarades ont été tués par " + GetName( NAMETYPE_VIP, NPChar.Hold_GenQuest.PirateName, NAME_NOM) + " juste à cכté de ce trésor... Puis le bruit a couru que " + GetName( NAMETYPE_VIP, NPChar.Hold_GenQuest.PirateName, NAME_ACC) + " avait été pris et pendu, et " + NPChar.Hold_GenQuest.Name + " a depuis raccroché, " +
				" s'est rangé, a fondé une famille. Mais il se souvenait bien de l'endroit du trésor, il en a même griffonné une carte. Il m'a proposé d'aller chercher le trésor avec lui. Il dit qu'il a peur : ce trésor a été abondamment arrosé de sang, et c'est un homme superstitieux. Je dois avouer que je n'ai pas osé non plus. " +
				"Il était prêt à vendre la carte, mais à quoi bon pour moi : je ne vais pas me lancer seul dans cette affaire... Voilà mon histoire... Je pense que cette carte vous irait parfaitement, à vous qui avez du courage... Il vous la cédera pour pas cher.";
			link.l1 = "Et vous espérez vraiment que je vais croire ces sornettes ? L'accord est annulé, votre histoire ne tient pas debout.";
			link.l1.go = "free_tip_off_0";
			link.l2 = "Hum... C'est une histoire intéressante, même si elle est difficile à croire. Bon, puisque j'ai donné ma parole, allez dire au maître d'équipage de vous attribuer un coffre sur le gaillard d'avant. Vous descendrez à terre dans la première baie.";
			link.l2.go = "free_by_hoard5";
		break;

		case "free_by_hoard5":
			dialog.text = "Merci, capitaine ! Voilà ce que vaut la parole d' "+ GetSexPhrase("un gentilhomme", "une dame") + " !";
			link.l1 = "Partez, et ne vous laissez plus prendre. Une autre fois, je ne serai pas si bon.";
			link.l1.go = "free_by_hoard6";
		break;

		case "free_by_hoard6":
			pchar.GenQuest.Hold_GenQuest.City 		= NPChar.Hold_GenQuest.City;
			pchar.GenQuest.Hold_GenQuest.Nation 	= NPChar.Hold_GenQuest.Nation;
			pchar.GenQuest.Hold_GenQuest.Name 		= NPChar.Hold_GenQuest.Name;
			pchar.GenQuest.Hold_GenQuest.PirateName	= NPChar.Hold_GenQuest.PirateName;
			pchar.GenQuest.Hold_GenQuest.CapName	= GetFullName(NPChar);
			pchar.GenQuest.Hold_GenQuest.TavernVariant = rand(1) + 2;
			pchar.GenQuest.Hold_GenQuest.Sum		= 10000 + rand(10000);
			pchar.GenQuest.Hold_GenQuest.Treasure	= rand(1);
			pchar.GenQuest.Hold_GenQuest.Speak_Tavern = false;

			ReOpenQuestHeader("HoldQuest");
			AddQuestRecord("HoldQuest", "12");
			AddQuestUserData("HoldQuest", "sName", GetFullName(NPChar));
			AddQuestUserData("HoldQuest", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.Hold_GenQuest.City + "Voc"));
			AddQuestUserData("HoldQuest", "sNameChar", pchar.GenQuest.Hold_GenQuest.Name);
			AddQuestUserData("HoldQuest", "sPirateName", GetName( NAMETYPE_VIP, pchar.GenQuest.Hold_GenQuest.PirateName, NAME_ACC));

            ReleasePrisoner(NPChar); // освободили пленника
        	LAi_SetActorType(NPChar);
			NPChar.LifeDay = 0;
        	LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "", 4.0);
        	DialogExit();
		break;

		case "free_in_sea":
			dialog.text = "Mais, " + GetAddress_Form(NPChar) + ", nous sommes en pleine mer ! דa équivaut à m'exécuter !!!";
			link.l1 = "Mais c'est exactement ce que vous vouliez : alors adieu. Le maître d'équipage veillera à l'exécution de mes ordres.";
			link.l1.go = "PunishmentAction1";
			link.l2 = "D'accord, je vais y réfléchir...";
			link.l2.go = "exit";
		break;

		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

	}
}
