// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			switch(pchar.questTemp.State)
            {
                case "TakeFoodCuracao_toOrangeMayor": //Голландская линейка, квест №2, доставка продовольствия из Форт Оранжа.
                    link.l2 = "Je viens sur ordre de Peter Stuyvesant. Vous avez un lot de marchandises préparé pour Curaçao, je dois l'acheter et le livrer. Je vous prie de prendre connaissance des documents accordant des prix spéciaux.";
                    link.l2.go = "Step_H2_1";
                break;

            }
             // <== Проверяем поле состояния квестов.
		break;

        case "Step_H2_1":
			dialog.text = "Voyons, lisons ça... Bon, les papiers sont en ordre. Vous pouvez retirer tout le lot de marchandises au magasin d'ici, je vais immédiatement ordonner qu'on vous le remette\n"+
                          "Le lot se compose de café, d'ébène, d'acajou et de santal. Le poids total du lot préparé pour l'expédition est de 5 600 quintaux. Réglez au magasin, et vous pourrez commencer le chargement.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
            TakeItemFromCharacter(pchar, "Trust");
            BackItemDescribe("Trust");
            AddQuestRecord("Hol_Line_2_TakeFoodCuracao", "2");
			pchar.questTemp.State = "TakeFoodCuracao_toOrangeStore";
        	pchar.GenQuest.StoreGoods.StoreIdx = FortOrange_STORE;
        	pchar.GenQuest.StoreGoods.HL2_DiscountPrices = true;
		break;

        case "DefenceOrange": //Голландская линейка, квест №4, защита Форт Оранжа.
            dialog.text = "Comme je suis content de vous voir, comme je suis content !...";
            link.l2 = "Je viens de la part de Stuyvesant. Il semble que nous ayons réussi à...";
            link.l2.go = "Step_H4_1";
        break;

        case "Step_H4_1":
			dialog.text = "Bon sang, vous n'avez pas seulement réussi, vous nous avez sauvés ! Fort Orange vous remercie du fond du cœur ! Mes compliments à Peter Stuyvesant.";
			link.l1 = "Je transmettrai, sans faute. Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

