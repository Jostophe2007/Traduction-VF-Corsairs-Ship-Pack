
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":								//Автор Sinistra
			dialog.text = "Regardez qui voilà ! La terreur des mers et des océans ! Seulement, bon sang, j'ai oublié ton nom ! Tu sais qui je suis ? Je suis James Callow ! J'ai pillé la colonie espagnole de San Juan et pris d'abordage le vaisseau amiral de l'escadre française ! Je ne suis pas un monstre, peut-être ? Tu ne trembles pas en me voyant ?";
			link.l1 = "Non. Moi non plus, je n'ai rien d'un ange, et il m'est arrivé de piller pas mal de choses en mon temps.";
			link.l1.go = "Vstrecha_2";
			link.l2 = "א vrai dire, je suis d'une nature douce et paisible. Pardon, mais je préfère prendre la fuite pour l'instant.";
			link.l2.go = "exit";
			if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")
			{
				dialog.text = "Je bois l'écume... la vague...";
				link.l1 = "...";
				link.l1.go = "Slushat_Pesnu_1";
				DeleteAttribute(link, "l2");
			}
			if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP" &&
					CheckAttribute(pchar, "questTemp.ATPNapelsy") && pchar.questTemp.ATPNapelsy == "Napelsy")
			{
				dialog.text = "Il m'a ouvert le ventre... Récif de corail... La-la-la-la-la !";
				link.l1 = "";
				link.l1.go = "exit";
				DeleteAttribute(link, "l2");
			}
		break;

		case "Vstrecha_2":
            dialog.text = "Parfait ! Tu sais, "+ GetSexPhrase("garçon","fille") +", j'ai "+ GetSexPhrase("besoin de quelqu'un","besoin de quelqu'un") +" comme toi. Je prépare une aventure dans laquelle je ne veux pas me lancer seul. D'après ce que j'ai entendu dire de toi, j'en conclus que c'est justement de toi que j'ai "+ GetSexPhrase("besoin","besoin") +". Qu'en dis-tu, "+ pchar.name +" ?";
            link.l1 = "Quelle aventure prépares-tu, Jimmy ?";
			link.l1.go = "Vstrecha_3";
		break;

		case "Vstrecha_3":
            dialog.text = "Tu crois aux fantכmes, "+ GetSexPhrase("l'ami","ma petite") +" ? Tu crois aux esprits malfaisants qui portent malheur ?";
			link.l1 = "Je ne crois pas à ces bêtises. Seuls les enfants et les vieillards croient que les esprits peuvent se mêler de la vie des hommes.";
			link.l1.go = "Ne_Veru_1";
            link.l2 = "J'ai entendu des histoires d'esprits et de fantכmes.";
			link.l2.go = "Vstrecha_4";
		break;

		case "Ne_Veru_1":
            dialog.text = "Tu es trop jeune pour comprendre ces choses-là, "+ GetSexPhrase("garçon","fille") +". Si tu avais plus d'expérience de la vie, tu comprendrais que parfois, les histoires qu'on raconte dans les tavernes ne sont pas que des inventions et des vantardises. Dans certains cas, elles ne sont même que trop vraies.";
			link.l1 = "Tu sais, on dirait que tu n'as pas toute ta tête, James. Je préfère te laisser là. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "VstrechNetAgain_1";
			npchar.lifeday = 0;
		break;

		case "Vstrecha_4":
			DialogExit();
			
			sld = CharacterFromID("James_Callow");
			sld.dialog.filename = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode = "Vstrecha_4_1";
			LAi_Fade("PDM_Callow_sadis_na_stul", "");
		break;
		
		case "Vstrecha_4_1":
            dialog.text = "Eh bien, je vais te le dire : toutes ces histoires sont vraies. Il y a des choses que je ne peux expliquer autrement. J'ai trouvé un objet, et je jure qu'il est maudit !";
            link.l1 = "Vraiment ? Et qu'est-ce qui te le fait croire ? Tu sens cet esprit ? Ou bien cette malédiction t'apparaît la nuit pour te jurer sa propre malveillance ?";
			link.l1.go = "Vstrecha_5";
			LAi_CharacterPlaySound(NPChar, "GR_Jamescallow_FirstTime");
		break;

		case "Vstrecha_5":
            dialog.text = "Il n'y a pas de quoi rire, "+ pchar.name +". Depuis que j'ai mis la main sur cette maudite idole, ma chance m'a abandonné. D'abord, j'ai été pris dans une tempête près de Cuba. Ensuite, j'ai abordé un galion espagnol. Et tu sais ce que j'ai trouvé dans la cale ? Des sacs. Des sacs vides. Pas d'or, pas d'argent, rien que ces maudits sacs ! Des cales pleines de sacs !";
            link.l1 = "Ha ! Une bien maigre prise. Et ensuite ?";
			link.l1.go = "Vstrecha_6";
		break;

		case "Vstrecha_6":
            dialog.text = "Le lendemain, Armando de Mutil, un célèbre chasseur de primes, a repéré mon navire et a essayé de me capturer. Ce fut son dernier jour sur cette terre, mais mon navire a été gravement endommagé au combat. Je suis allé aux Bermudes pour le réparer, mais les malheurs me poursuivaient toujours.\n"+
							"Au large de la cכte anglaise, les garde-cכtes ont aperçu ma voile à l'horizon, et j'ai dמ donner tout mon or au capitaine du brick pour acheter ma liberté. C'est seulement alors que j'ai compris la raison de tous ces malheurs.";
            link.l1 = "Et de quoi s'agit-il ?";
			link.l1.go = "Vstrecha_7";
		break;

		case "Vstrecha_7":
            dialog.text = "Il y a un mois, j'ai rencontré un pauvre vieil Indien. Nous prenions de l'eau douce à une source, sur un minuscule îlot. Il est sorti des arbres. Il marmonnait quelque chose à propos d'une offense faite au grand Huruk'tseli'oli et de la vengeance qui allait suivre. Tout en marmonnant, il agitait cette idole païenne.\n"+
							"Quand j'ai vu que la statuette était en or pur et ornée d'une grosse émeraude, je l'ai arrachée des mains de l'Indien.\n"+
							"Non, je ne suis pas aussi mauvais que tu le crois... Je lui ai donné quelques pièces en échange. Mais il ne les a pas prises. Il a dit que l'idole ne pouvait être qu'un cadeau. Puis il a dit qu'il me donnait l'idole « avec le mal dans son cœur », et un autre cadeau.\n"+
							"L'Indien a dit que puisque je voulais tellement cette idole, elle serait à moi pour toujours, et que je ne pourrais jamais m'en débarrasser. Je lui ai ri au nez et je lui ai coupé la tête. Je ne crains ni Dieu ni diable, mais maintenant, j'ai peur, "+ GetSexPhrase("l'ami","ma petite") +".";
            link.l1 = "Tu coupes la tête des vieux Indiens ? Tu as peur ? Bon, arrête de me faire tourner la tête ! Ha ! Jette simplement ce truc à la mer !";
			link.l1.go = "Vstrecha_8";
		break;

		case "Vstrecha_8":
            dialog.text = "וcoute, "+ GetSexPhrase("l'ami","ma petite") +". J'ai essayé de la vendre. J'ai essayé de la perdre. Rien à faire. La maudite idole revient dans ma cabine, dans mon sac, dans mon placard : elle revient à moi oם que je sois. Ce maudit truc me suit ! C'est une sorte de malédiction ! Tu dis que tu ne crois pas aux malédictions ; alors, tu peux m'aider ?";
            link.l1 = "Hmmm... Peut-être. Pourquoi ne la donnes-tu pas tout simplement à quelqu'un ? L'Indien a dit qu'une idole ne pouvait qu'être offerte.";
			link.l1.go = "Vstrecha_9";
		break;

		case "Vstrecha_9":
            dialog.text = "Parce que je ne peux pas la donner ! דa n'a aucun sens, mais... Ce chaman indien a, je ne sais comment... il a accru ma cupidité... Je ne peux tout simplement... pas. Je pense que ça fait partie de cette sournoise malédiction. Je ne peux pas la donner ! Penser que je donnerais une telle chose sans en tirer profit... c'est tout simplement... C'est insupportable ! Je crois que je me pendrais si je faisais ça. Mais j'ai un plan...";
            link.l1 = "Quel est ce plan ?";
			link.l1.go = "Vstrecha_10"
		break;

		case "Vstrecha_10":
            dialog.text = "Je connais un homme qui voudra cette idole dès qu'il la verra. C'est mon ennemi le plus dangereux. Et ce ne sera pas, bien sמr, une affaire sans profit ! Si je sais que Rogers a ce truc entre les mains, ce sera la plus grande joie de ma vie. Mais je ne peux pas le faire moi-même. Rogers me connaît trop bien. Je suis sמr qu'il ne se doutera de rien si le cadeau vient de toi.";
            link.l1 = "Et qu'est-ce que j'y gagne ?";
			link.l1.go = "Vstrecha_11";
		break;

		case "Vstrecha_11":
            dialog.text = "Ma reconnaissance. Et je t'accompagnerai dans tous tes voyages... du moins pendant un temps. Celui à qui tu dois offrir l'idole, c'est Bortolomew Rogers, le chef de la colonie du François, en Martinique. Tu vas m'aider, "+ GetSexPhrase("l'ami","ma petite") +" ?";
			link.l1 = "Oui. Je vais t'aider.";
			link.l1.go = "VstrechaDa_1";
            link.l2 = "Non, ce serait une perte de temps.";
			link.l2.go = "VstrechaNet_1";
			LAi_SetSitType(npchar);
		break;

		case "VstrechaDa_1":
            dialog.text = "Merci, "+ GetSexPhrase("frère","sœur") +". Tiens, prends cette idole, non pas comme un cadeau, mais au contraire en échange de ta promesse de la donner à mon pire ennemi, Bortolomew Rogers. Brrr... J'espère que ça marchera et que je ne trouverai pas l'idole sous mon oreiller demain. Apporte-la vite à Rogers, sinon, qui sait ? ";
            link.l1 = "א plus tard, frère.";
			link.l1.go = "CodDa_1";
			GiveItem2Character(PChar, "Cursed_idol");
			PlaySound("Interface\important_item.wav");
			Log_info("James vous a remis une idole");
			NextDiag.TempNode = "VstrechDaAgain_1";
		break;

		case "VstrechaNet_1":
			dialog.text = "Dans ce cas, sois maudit. Que ton corps aille aux requins, et ton âme au diable !";
            link.l1 = "דa m'étonnerait. Bon, ne t'ennuie pas. Et attention, prends bien soin de ta petite idole. Adieu.";
			link.l1.go = "CodNet_1";
			NextDiag.TempNode = "VstrechNetAgain_1";
			npchar.lifeday = 0;
		break;

		case "CodDa_1":
			LAi_Fade("PDM_Callow_vstaem", "");
			
			SetQuestHeader("PDM_Cursed_Idol");
			AddQuestRecord("PDM_Cursed_Idol", "1");
			AddQuestUserData("PDM_Cursed_Idol", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PDM_Cursed_Idol", "sSex1", GetSexPhrase("", "e"));

			sld = CharacterFromID("LeFransua_Mayor");   //ссылается на персонажа
			ChangeCharacterAddressGroup(sld, "LeFransua_town", "none", "");

			sld = GetCharacter(NPC_GenerateCharacter("PDM_LeFransua_Mayor_Klon", "huber_fra", "man", "man", 30, PIRATE, -1, false));   //ссылается на клона
			sld.name	= "Bartholomew";
			sld.lastname	= "Rogers";
			sld.nation = PIRATE;
			LAi_SetSitType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			LAi_SetImmortal(sld, true);
			GiveItem2Character(sld, GUN_COMMON);
			GiveItem2Character(sld, BLADE_LONG);
			LAi_SetHuberType(sld);
			SetRandSPECIAL(sld);
			SetSelfSkill(sld, 90, 90, 90, 60, 70);
			sld.standUp = true; //вставать и нападать на врага
			ChangeCharacterAddressGroup(sld, "LeFransua_townhall", "sit", "sit1");
			sld.Dialog.Filename = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode = "Rodjer_1";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "CodNet_1":
            LAi_Fade("PDM_Callow_vstaem", "");
			
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "VstrechDaAgain_1":
			dialog.text = "Arrhh ! Pourquoi perds-tu ton temps ? Apporte l'idole à Rogers avant qu'elle ne te porte malheur. Je ne veux pas être la cause de tes malheurs.";
            link.l1 = "Ne t'inquiète pas, frère. Rogers aura très bientכt ton petit cadeau.";
			link.l1.go = "exit";
		break;

		case "VstrechNetAgain_1":
			dialog.text = "Arrgh ! C'est toi ! Fiche le camp avant que je ne t'arrache la tête !";
            link.l1 = "Patience, patience, Jimmy. Tu te mets dans tous tes états.";
			link.l1.go = "exit";
		break;

		case "Rodjer_1":
			dialog.text = "Hé ! Tu es sur mon territoire, "+ GetSexPhrase("garçon","fille") +", alors tiens-toi tranquille ici, ou tu te tairas pour toujours. Tu me comprends ?";
            link.l1 = "Du calme, Rogers. Je sais oם je suis.";
			link.l1.go = "Rodjer_2";
			LAi_CharacterPlaySound(NPChar, "GR_Prikusi_Yazik");
		break;

		case "Rodjer_2":
			dialog.text = "Bien, ne l'oublie pas. Qu'est-ce qu'il te faut, mon petit ?";
            link.l1 = "J'ai un cadeau pour toi.";
			link.l1.go = "Rodjer_3";
		break;

		case "Rodjer_3":
			dialog.text = "Un cadeau ? Montre-le-moi.";
            link.l1 = "C'est une idole indienne. Tiens, regarde. C'est un joli bibelot, n'est-ce pas ?";
			link.l1.go = "Rodjer_4";
		break;

		case "Rodjer_4":
			dialog.text = "Qui t'envoie ?";
            link.l1 = "Personne. J'ai juste décidé de faire un cadeau à celui qui a le pouvoir au François.";
			link.l1.go = "RodjerDa_1";
			link.l2 = "Un de tes vieux amis. Il voulait te faire plaisir avec ce cadeau.";
			link.l2.go = "RodjerPodozren_1";
		break;

		case "RodjerPodozren_1":
			dialog.text = "Je ne te crois pas, "+ GetSexPhrase("le gars","la fille") +". Je n'ai pas d'amis qui puissent m'envoyer un cadeau. Mais j'ai beaucoup d'ennemis prêts à m'envoyer quelque chose de dangereux. Alors, tu maintiens que c'est le cadeau d'un vieil ami ?";
            link.l1 = "Oui, parce que c'est la vérité.";
			link.l1.go = "RodjerPodozren_2";
			link.l2 = "Non... Mais je veux que tu prennes ce bibelot.";
			link.l2.go = "RodjerDa_2";
		break;

		case "RodjerPodozren_2":
			dialog.text = "Tu es "+ GetSexPhrase("insolent","insolente") +", "+ GetSexPhrase("blanc-bec","gamine") +". Fiche le camp d'ici et emporte ton cadeau avec toi. Tu peux l'offrir aux putains de la taverne. Reviens me voir quand tu sauras parler à l'homme qui tient cette ville dans son poing.";
            link.l1 = "...";
			link.l1.go = "RodjerCod_2";
			NextDiag.TempNode = "RodjerPokapoka_1";
			ChangeCharacterReputation(pchar, -4);
		break;

		case "RodjerDa_1":
			dialog.text = "Ha ! Tu as compris qui commande dans cette petite ville. Et tu as décidé de me flatter avec ce cadeau... דa me plaît !";
            link.l1 = "דa alors ! Tu lis littéralement dans mes pensées. Mais tu accepteras un cadeau de ma part ?";
			link.l1.go = "RodjerDa_2";
		break;

		case "RodjerDa_2":
			dialog.text = "Approche... Arrgh ! Quelle belle chose ! Oui, elle me plaît ! Que veux-tu en échange de ton cadeau ? Dis-le-moi, et je le ferai ! Mais avant de demander, réfléchis bien.";
			//link.l1 = "I know that pirates often leave captured ships here. I want to take one of them, and I need your permission. At the same time, can you tell me which one is in decent condition?";
			//link.l1.go = "RodjerVar_1";
			link.l1 = "Je n'ai besoin de rien.";
			link.l1.go = "RodjerVar_2";
			Log_info("Vous avez remis l'idole à Rogers");
			TakeItemFromCharacter(pchar, "Cursed_idol");
		break;

		/*case "RodjerVar_1":
			dialog.text = "Unfortunately, "+ GetSexPhrase("guy","girl") +", I have nothing to offer you. But I'll take your trinket. Now, goodbye.";
			link.l1 = "Uh... See you later.";
			link.l1.go = "RodjerCod_1";
			NextDiag.TempNode = "RodjerPokapoka_1";
			ChangeCharacterReputation(pchar, -2);
		break;*/

		case "RodjerVar_2":
			dialog.text = "Je ne te crois pas, "+ GetSexPhrase("le gars","la fille") +". On ne fait pas de tels cadeaux pour rien... Reprends-la et fiche le camp d'ici. Tu es trop "+ GetSexPhrase("bête","bête") +" pour me rouler. Dehors !";
			link.l1 = "Mais...";
			link.l1.go = "RodjerCod_2";
			GiveItem2Character(PChar, "Cursed_idol");
			Log_info("Rogers vous a rendu l'idole");
			NextDiag.TempNode = "RodjerPokapoka_1";
			ChangeCharacterReputation(pchar, 4);
		break;

		case "RodjerPokapoka_1":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Rien, je m'en vais.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RodjerPokapoka_1";
		break;

		/*case "RodjerCod_1":
			Pchar.quest.PDM_Callow_RodjerFin.win_condition.l1           = "Location";
        	Pchar.quest.PDM_Callow_RodjerFin.win_condition.l1.location  = "LaVega_Tavern";
        	Pchar.quest.PDM_Callow_RodjerFin.win_condition              = "PDM_Callow_RodjerFin";
			Pchar.quest.PDM_Callow_RodjerVozvrat.win_condition.l1           = "ExitFromLocation";
        	Pchar.quest.PDM_Callow_RodjerVozvrat.win_condition.l1.location  = PChar.location;
        	Pchar.quest.PDM_Callow_RodjerVozvrat.win_condition              = "PDM_Callow_RodjerVozvrat";
			AddQuestRecord("PDM_Cursed_Idol", "2");
			AddQuestUserData("PDM_Cursed_Idol", "sSex", GetSexPhrase("", "e"));
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;*/

		case "RodjerCod_2":
			Pchar.quest.PDM_Callow_RodjerProdolg.win_condition.l1           = "Location";
			Pchar.quest.PDM_Callow_RodjerProdolg.win_condition.l1.location  = "LeFransua_town";
			pchar.quest.PDM_Callow_RodjerProdolg.function = "PDM_Callow_RodjerProdolg";
			AddQuestRecord("PDM_Cursed_Idol", "4");
			AddQuestUserData("PDM_Cursed_Idol", "sSex1", GetSexPhrase("", "e"));
			bDisableFastReload = true;
			LAi_LocationFightDisable(&Locations[FindLocation("LeFransua_town")], true);
			SetLocationCapturedState("LeFransua_town", true);
			SetCurrentTime(24, 0);

			sld = GetCharacter(NPC_GenerateCharacter("Pablo_Loco_Idol", "indsar1", "man", "man", 10, PIRATE, -1, false));
			sld.name = "Keruk";
			sld.lastname = "";
			sld.talker = 7;
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			LAi_SetStayType(sld);
			sld.dialog.filename   = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode   = "Pablo_Loco_Idol";
			LAi_LoginInCaptureTown(sld, true);
			ChangeCharacterAddressGroup(sld,"LeFransua_town","goto","goto7");
			
			pchar.questTemp.PDM_PI_Skelety_v_more = true;

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Pablo_Loco_Idol":
			dialog.text = "Moi sentir magie maléfique en toi...";
			link.l1 = "Qu'est-ce que ça a à voir avec moi ? Peut-être... Cette statuette en or t'intéresserait-elle ?";
			link.l1.go = "Pablo_Loco_Idol_2";
		break;

		case "Pablo_Loco_Idol_2":
			dialog.text = "Jette-la ! Jette-la ! Ne touche jamais cette chose, jamais ! Ces mangeurs d'or, ceux qui vivaient sur Emuno, ce sont eux qui ont fait cette chose ! Ne la touche jamais ! La colère de Huruk est très grande, c'est l'esprit de la montagne qui fume. Lui qui jette des pierres sur la tête de son propre peuple te détruira aussi. Débarrasse-toi de cette chose maléfique avant qu'elle ne te tue !";
			link.l1 = "Quel cauchemar... Dans quoi ai-je mis les pieds ?";
			link.l1.go = "Pablo_Loco_Idol_3";
			npchar.lifeday = 0;
		break;

		case "Pablo_Loco_Idol_3":
			DialogExit();
			
			sld = CharacterFromID("Pablo_Loco_Idol");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "houseK4", "none", "", "", "", -1);
			
			sld = GetCharacter(NPC_GenerateCharacter("PDM_Pinki_Skelet", "skel3", "skeleton", "skeleton", sti(pchar.rank), PIRATE, -1, true));
			sld.name = "Pinkamina";
			sld.lastname = "Pie";
			FantomMakeCoolFighter(sld, sti(pchar.rank), 30, 30, "blade36", "", 25 + MOD_SKILL_ENEMY_RATE * 4);
			sld.SaveItemsForDead = true;
			sld.DontChangeBlade = true;
			sld.DeleteFood = true;
			LAi_LoginInCaptureTown(sld, true);
			AddMoneyToCharacter(sld, 5000);
			AddItems(sld, "jewelry2", 10);
			AddItems(sld, "jewelry5", 10);
			AddItems(sld, "jewelry17", 10);
			AddItems(sld, "mineral5", 3);
			sld.dialog.filename   = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode   = "FraOff_1";
			ChangeCharacterAddressGroup(sld, "LeFransua_town", "reload",  "houseH7");
			LAi_SetActorType(sld);
			LAi_ActorDialog(sld, pchar, "", -1, 0);
			
			for (i=4; i<=5; i++)
			{
				sTemp = "skel_"+(rand(3)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_skel_"+i, sTemp, "skeleton", "skeleton", sti(pchar.rank), PIRATE, -1, true));
				LAi_SetActorType(sld);
				LAi_LoginInCaptureTown(sld, true);
				sld.lifeday = 1;
				SaveCurrentNpcQuestDateParam(sld, "LifeTimeCreate")
				ChangeCharacterAddressGroup(sld, "LeFransua_town", "goto",  "goto"+i);
			}		
			for (i=10; i<=11; i++)
			{
				sTemp = "skel_"+(rand(3)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_skel_"+i, sTemp, "skeleton", "skeleton", sti(pchar.rank), PIRATE, -1, true));
				LAi_SetActorType(sld);
				LAi_LoginInCaptureTown(sld, true);
				sld.lifeday = 1;
				SaveCurrentNpcQuestDateParam(sld, "LifeTimeCreate")
				ChangeCharacterAddressGroup(sld, "LeFransua_town", "goto",  "goto"+i);
			}
			for (i=14; i<=17; i++)
			{
				sTemp = "skel_"+(rand(3)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_skel_"+i, sTemp, "skeleton", "skeleton", sti(pchar.rank), PIRATE, -1, true));
				LAi_SetActorType(sld);
				LAi_LoginInCaptureTown(sld, true);
				sld.lifeday = 1;
				SaveCurrentNpcQuestDateParam(sld, "LifeTimeCreate")
				ChangeCharacterAddressGroup(sld, "LeFransua_town", "goto",  "goto"+i);
			}
		break;

		case "FraOff_1":
			dialog.text = RandPhraseSimple("J'aime jouer avec la viande ambulante. Surtout quand cette viande gicle en une fontaine écarlate.", "Je me suis presque cousu un beau pourpoint en peau humaine, il ne manque que deux ou trois pièces, la tienne fera parfaitement l'affaire.");
			link.l1 = RandPhraseSimple("Tu as fait une erreur, mon ami.", "Oh, maudite ordure, dégage !");
			link.l1.go = "FraOff_Bitva_1";
		break;

		case "FraOff_Bitva_1":
			LAi_LocationFightDisable(loadedLocation, false); //Разрешаем оружие
			LAi_SetPlayerType(pchar);
			LAi_SetFightMode(pchar, true);
			sld = CharacterFromID("PDM_Pinki_Skelet");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "PDM_PI_Skelety");
			
			for (i=4; i<=5; i++)
			{
				sld = CharacterFromID("PDM_PI_skel_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_PI_Skelety");
			}		
			for (i=10; i<=11; i++)
			{
				sld = CharacterFromID("PDM_PI_skel_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_PI_Skelety");
			}			
			for (i=14; i<=17; i++)
			{
				sld = CharacterFromID("PDM_PI_skel_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "PDM_PI_Skelety");
			}
			
			PChar.quest.PDM_PI_PinkiSkelet.win_condition.l1 = "NPC_Death";
			PChar.quest.PDM_PI_PinkiSkelet.win_condition.l1.character = "PDM_Pinki_Skelet";
			PChar.quest.PDM_PI_PinkiSkelet.win_condition = "PDM_FraOff_Bitva_1_Posle";
			LAi_group_SetRelation("PDM_PI_Skelety", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("PDM_PI_Skelety", LAI_GROUP_PLAYER, false);
			LAi_group_SetLookRadius("PDM_PI_Skelety", 7.0);
			LAi_group_SetHearRadius("PDM_PI_Skelety", 2.0);
			LAi_group_SetSayRadius("PDM_PI_Skelety", 4.0);
			DialogExit();
		break;

		case "CollowNeRad_1":
			dialog.text = "Ah ! Te voilà enfin "+ GetSexPhrase("revenu","revenue") +". Alors ? Tu l'as fait ?";
			link.l1 = "J'ai une mauvaise nouvelle pour toi. Rogers a refusé de prendre l'idole.";
			link.l1.go = "CollowNeRad_2";
			LAi_CharacterPlaySound(NPChar, "GR_Jamescallow_FirstTime");
		break;
		
		case "CollowNeRad_2":
			DialogExit();
			
			sld = CharacterFromID("James_Callow");
			sld.dialog.filename = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode = "CollowNeRad_2_1";
			LAi_Fade("PDM_Callow_sadis_na_stul", "");
		break;

		case "CollowNeRad_2_1":
			dialog.text = "Diable ! Que le diable l'emporte ! Pourquoi a-t-il refusé de la prendre ? Je savais que je n'aurais pas dמ faire confiance à "+ GetSexPhrase("un blanc-bec","une sotte") +" comme toi ! Tout ça, c'est à cause de ta bêtise, "+ GetSexPhrase("le gars","la fille") +" !";
			link.l1 = "Je ne vais pas encaisser les insultes, James. Et je ne suis pas d'un naturel patient.";
			link.l1.go = "CollowNeRad_3";
		break;

		case "CollowNeRad_3":
			dialog.text = "Arrgh ! Tu as raison. Qu'est-ce que tu vas faire maintenant ? Je ne reprends pas ce maudit truc. Et si on donnait l'idole à quelqu'un d'autre ?";
			link.l1 = "Bonne idée... Mais qui allons-nous choisir comme victime ?";
			link.l1.go = "CollowNeRad_4";
			LAi_SetSitType(npchar);
		break;

		case "CollowNeRad_4":
			dialog.text = "On dit que l'usurier de Tortuga est fou d'or et de pierres précieuses... Notre truc lui plaira peut-être ? Qu'en penses-tu ?";
			//link.l1 = "No, I have a better idea - you just take your fucking idol and leave me alone. I'm already sick of this nonsense!";
			//link.l1.go = "CollowOchenNeRad_1";
			link.l1 = "Parfait ! On va lui refiler cette maudite statue, tout simplement.";
			link.l1.go = "CollowNeRad_5";
		break;

		case "CollowNeRad_5":
			dialog.text = "Tu devras de nouveau la présenter comme un cadeau... J'espère qu'il est plus cupide que Rogers. Je parie qu'il mordra à l'hameçon.";
			link.l1 = "Ne t'inquiète pas, tout ira bien cette fois. Je vais d'abord lui laisser voir la statue, et ensuite je parlerai affaires avec lui. L'éclat de l'or va l'éblouir. Après ça, il achètera l'idole à n'importe quel prix.";
			link.l1.go = "CollowNeRad_6";
		break;

		case "CollowNeRad_6":
			if (CheckCharacterItem(Pchar, "patent_fra"))
			{
				dialog.text = "C'est exactement ce que je pense. Mais sois "+ GetSexPhrase("prudent","prudente") +". Si quelque chose tourne mal, tu devras te frayer un chemin à travers une foule de gardes pour sortir de là.";
				link.l1 = "J'espère qu'on n'en arrivera pas là.";
				link.l1.go = "CollowNeRad_7";
			}
			else
			{
				dialog.text = "C'est exactement ce que je pense. Mais sois "+ GetSexPhrase("prudent","prudente") +". Si quelque chose tourne mal, tu devras te frayer un chemin à travers une foule de gardes pour sortir de là.";
				link.l1 = "Je m'en occuperai. Et s'il faut tuer un ou deux gardes, ce ne sera pas la première fois.";
				link.l1.go = "CollowNeRad_7";
			}
		break;

		case "CollowNeRad_7":
			dialog.text = "Alors, va, "+ GetSexPhrase("frère","sœur") +". Bonne chance à toi.";
			link.l1 = "א plus tard, frère. Je reviens bientכt.";
			link.l1.go = "CollowNeRad_8";
			NextDiag.TempNode = "VstrechEsheAgain_2";
		break;

		case "CollowNeRad_8":
			LAi_Fade("PDM_Callow_vstaem", "");

			pchar.questTemp.PDM_PI_Rostov = "PDM_PI_Rostov";

			AddQuestRecord("PDM_Cursed_Idol", "8");
			AddQuestUserData("PDM_Cursed_Idol", "sSex", GetSexPhrase("", "e"));

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "VstrechEsheAgain_2":
			dialog.text = "Arrhh ! Pourquoi perds-tu ton temps ? Apporte l'idole à l'usurier de Tortuga avant qu'elle ne te porte malheur. Je ne veux pas être la cause de tes malheurs.";
            link.l1 = "Ne t'inquiète pas, frère. Ton petit cadeau sera très bientכt à Tortuga.";
			link.l1.go = "exit";
			NextDiag.TempNode = "VstrechEsheAgain_2";
		break;

		case "Rostovshik_Fra_Off_1":
			dialog.text = "Quelle surprise, notre usurier n'est pas aussi pauvre qu'il nous le disait !";
			link.l1 = "";
			link.l1.go = "Rostovshik_Fra_Off_1a";
		break;

		case "Rostovshik_Fra_Off_1a":
			DialogExit();
			StartInstantDialog("Tortuga_usurer", "Rostovshik_Fra_Off_1b", "Quest\PDM\Cursed_Idol.c");
		break;

		case "Rostovshik_Fra_Off_1b":
			dialog.text = "Je rembourserai tout, j'aurai l'argent la semaine prochaine. Je le jure sur ma mère !";
            link.l1 = "Bon, tes affaires ne me regardent pas.";
			link.l1.go = "Rostovshik_Fra_Off_1с";
		break;

		case "Rostovshik_Fra_Off_1с":
			DialogExit();
			StartInstantDialog("PDM_PI_Bandit_1", "Rostovshik_Fra_Off_1_1", "Quest\PDM\Cursed_Idol.c");
		break;

		case "Rostovshik_Fra_Off_1_1":
			dialog.text = "Halte ! L'argent sur le tonneau. Si tu ne comptes rien donner, nous le prendrons nous-mêmes. Hé, LES GARS, venez ici.";
            link.l1 = "On verra bien !";
			link.l1.go = "Rostovshik_Mochilovo_1";
			pchar.questTemp.PDM_CI_RostBlago = "PDM_CI_RostBlago";
		break;

		case "Rostovshik_Fra_Off_3":
			dialog.text = "Tu m'as manqué.";
			link.l1 = "Lequel ???";
			link.l1.go = "Rostovshik_Fra_Off_3_1";
		break;

		case "Rostovshik_Fra_Off_3_1":
			sld = characterFromID("Tortuga_usurer");
			ChangeCharacterAddressGroup(sld, "Tortuga_Town", "none", "");

			sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_Skel_Rostov", "skel_2", "skeleton", "skeleton", 2, PIRATE, -1, true));
			sld.name = "L'usurier";
			sld.lastname = "";
			ChangeCharacterAddressGroup(sld, "Tortuga_Bank", "barmen", "stay");
			sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_Bandity_2", "skel4", "skeleton", "skeleton", 2, PIRATE, -1, true));
			ChangeCharacterAddressGroup(sld, "Tortuga_Bank", "reload", "reload2");

			DialogExit();
			StartInstantDialog("PDM_PI_Skel_Rostov", "Rostovshik_Fra_Off_3_2", "Quest\PDM\Cursed_Idol.c");
		break;

		case "Rostovshik_Fra_Off_3_2":
			dialog.text = "On n'échappe pas à l'idole maudite.";
			link.l1 = "AAAAA !!!";
			link.l1.go = "Rostovshik_Mochilovo_3";
		break;

		case "Rostovshik_Mochilovo_1":
			LAi_LocationFightDisable(loadedLocation, false); //Разрешаем оружие
			LAi_SetPlayerType(pchar);
			LAi_SetFightMode(pchar, true);
			sld = CharacterFromID("PDM_PI_Bandit_1");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "EnemyFight");
			for (i=1; i<=2; i++)
			{
				sTemp = "pirate_"+(rand(24)+1);
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_Bandity_"+i, sTemp, "man", "man", 2, PIRATE, -1, true));
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);		//стравливаем
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PDM_Callow_poradomoy");
			chrDisableReloadToLocation = true;
			LAi_SetFightMode(pchar, true);
			DialogExit();
		break;

		case "Rostovshik_Mochilovo_3":
			LAi_LocationFightDisable(loadedLocation, false); //Разрешаем оружие
			LAi_SetPlayerType(pchar);
			LAi_SetFightMode(pchar, true);
			sld = CharacterFromID("PDM_PI_Bandit_1");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "EnemyFight");
			sld = CharacterFromID("PDM_PI_Skel_Rostov");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "EnemyFight");
			sld = CharacterFromID("PDM_PI_Bandity_2");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);		//стравливаем
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "PDM_Callow_poradomoy");
			chrDisableReloadToLocation = true;
			LAi_SetFightMode(pchar, true);
			DialogExit();
		break;

		case "Callow_POBEDA_1":
			dialog.text = "Ah ! Te voilà enfin "+ GetSexPhrase("revenu","revenue") +". Alors ? Tu l'as fait ?";
            link.l1 = "Tout s'est bien passé cette fois. L'usurier a pris l'idole.";
			link.l1.go = "Callow_POBEDA_2";
			LAi_CharacterPlaySound(NPChar, "GR_Jamescallow_FirstTime");
		break;
		
		case "Callow_POBEDA_2":
			DialogExit();
			
			sld = CharacterFromID("James_Callow");
			sld.dialog.filename = "Quest\PDM\Cursed_Idol.c";
			sld.dialog.currentnode = "Callow_POBEDA_2_1";
			LAi_Fade("PDM_Callow_sadis_na_stul", "");
		break;

		case "Callow_POBEDA_2_1":
			dialog.text = "Aaargh ! Quel soulagement ! Tu ne peux pas imaginer quel fardeau c'était pour moi.";
            link.l1 = "Maintenant, son influence ne pèse plus sur toi. Mais je me souviens que tu m'avais promis de devenir mon officier... Qu'en est-il ?";
			link.l1.go = "Callow_POBEDA_3";
			AddCharacterExpToSkill(pchar, "Leadership", 150);   	//добавить опыт к авторитету
			AddCharacterExpToSkill(pchar, "Fortune", 100);			//добавить опыт к удаче
			sld = CharacterFromID("Tortuga_usurer");   //возвращаем ростовщика, если на скелетах убили
			ChangeCharacterAddressGroup(sld, "Tortuga_Bank", "barmen", "stay");
		break;

		case "Callow_POBEDA_3":
			dialog.text = "Je tiens ma promesse. Désormais, je navigue avec toi, "+ GetSexPhrase("frère","sœur") +".";
            link.l1 = "א bientכt en mer, frère.";
			link.l1.go = "Callow_POBEDA_4";
		break;

		case "Callow_POBEDA_4":
			dialog.text = "";
			link.l1 = "(finit le rhum)";
			link.l1.go = "FINAL";
			sld = CharacterFromID("James_Callow");
			AddPassenger(pchar, sld, false);
			SetCharacterRemovable(sld, true);
			sld.rank = 15;
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "SailsDamageUp");
			SetCharacterPerk(sld, "LongRangeShoot");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "SwordplayProfessional");
			SetCharacterPerk(sld, "BasicDefense");
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "CriticalHit");
			SetCharacterPerk(sld, "Sliding");
			SetCharacterPerk(sld, "Energaiser");
			SetCharacterPerk(sld, "ByWorker");
			LAi_SetHP(sld, 270.0, 270.0);
			SetSPECIAL(sld, 9,8,10,4,6,7,9);		//(Сила, Воспр, Выносл, Лидер, Обуч, Реак, Удача)
			SetSelfSkill(sld, 52, 60, 46, 38, 57);		//(ЛО, СО, ТО, пистолеты, фортуна)
			SetShipSkill(sld, 20, 10, 45, 40, 32, 10, 15, 16, 43);	//(лидер, торг, точн, пушки, навиг, ремонт, аборд, защита, скрыт)
			sld.greeting = "GR_Jamescallow";
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.Payment = true;										//Оплата труда
			sld.quest.OfficerPrice = sti(pchar.rank)*500
			sld.OfficerWantToGo.DontGo = true;
			sld.reputation = 15;
			LAi_SetImmortal(sld, false);
			sld.HalfImmortal = true; 							    //Контузия
			sld.loyality = MAX_LOYALITY;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			LAi_SetActorType(npchar);   //делает нпс актёром
			ChangeCharacterAddressGroup(npchar, "LaVega_tavern", "tables", "stay1");
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 3);  // идёт в определённый локатор.
		break;

		case "FINAL":
			LAi_Fade("PDM_Callow_vstaem", "");
		
			AddQuestRecord("PDM_Cursed_Idol", "10");
			CloseQuestHeader("PDM_Cursed_Idol");
			pchar.questdata.ProklyatyIdol = 1;
			sld = CharacterFromID("James_Callow");
			ChangeCharacterAddressGroup(sld, "LaVega_town", "none", "");
			AddSimpleRumourToAllNations("א Tortuga, on a retrouvé l'usurier mort dans l'arrière-boutique ; le médecin de la garnison a dit qu'il était mort de peur. Incroyable ! Et les murs sont tout barbouillés d'images d'une idole païenne.", 30, 1);
			DeleteAttribute(pchar, "questTemp.PDM_CI_RostBlago");
			
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		
		case "Matros_preduprejdaet":
			dialog.text = "Capitaine ! Les morts attaquent !!!";
            link.l1 = "Diable !";
			link.l1.go = "exit";
			AddDialogExitQuest("PDM_PI_Skelety_on_Ship_3");
		break;
	}
}
