// boal 27.03.2004 Муж Изабелы Армани

void ProcessDialogEvent()
{
	ref NPChar, d, sld;
	aref Link, NextDiag;
	string NPC_Meeting;
	int i;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(NextDiag, NPChar.Dialog);

	string iDay, iMonth;
	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;

	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
		break;

		case "Good_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = NPC_Meeting;
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocator(npchar, "goto", "goto1", "RP_talkWithHusbandIsOver", 0);
		break;

		case "First time":
			NextDiag.TempNode = "first time";
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
			if (CheckAttribute(pchar, "quest.wasInBeedroom"))
			{
	            if (CheckAttribute(NPChar, "quest.NiceMeet"))
				{
					dialog.text = "Hum, vous vous permettez beaucoup, tout de même : entrer dans la chambre sans la permission du maître de maison...";
					link.l1 = "Pardon, l'ami, je me suis juste perdu...";
					link.l1.go = "Good_exit";
				}
				else
				{
					dialog.text = "Qu'est-ce que vous faites à rכder autour de ma maison, bon sang ? En garde, salaud !";
					link.l1 = "Très bien...";
					link.l1.go = "Romantic_Battle_in_Bedroom_2";
				}
				DeleteAttribute(pchar, "quest.wasInBeedroom");
			}
			else
			{
				dialog.text = "Salutations, étranger ! Puis-je vous demander qui vous êtes et à quoi je dois l'honneur de vous voir chez moi ?";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ", je suis capitaine.";
				link.l1.go = "Next_1";
				link.l2 = "Pardonnez-moi. Je me suis trompé d'adresse.";
				link.l2.go = "Good_exit";
			}
		break;

        case "Next_1":
            NextDiag.TempNode = "Usual_1";
			dialog.text = "Capitaine, ou plutכt corsaire ? א en juger par votre allure, señor, c'est plutכt la seconde option. Enfin, de nos jours, plus d'un honorable don a amassé une jolie fortune de cette façon. Et je ne fais pas exception.";
			link.l1 = "Vous avez été corsaire ?!";
			link.l1.go = "Next_2";
			link.l2 = "Pardonnez-moi... les affaires !";
			link.l2.go = "Good_exit";
		break;

		case "Next_2":
		    NextDiag.TempNode = "Usual_1";
			dialog.text = "Qu'y a-t-il de si étonnant ? C'est un moyen très rapide et très sמr de s'enrichir. Mais après un heureux mariage, j'ai décidé de me ranger, ce que je vous souhaite aussi.";
			link.l1 = "Compris. Merci du conseil. Je ne manquerai pas de le suivre à l'occasion...";
			link.l1.go = "Good_exit";
			NPChar.quest.NiceMeet = true;
		break;

		case "Usual_1":
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
		    NextDiag.TempNode = "Usual_1";
			dialog.text = "Ravi de vous revoir. Qu'est-ce qui vous amène chez moi, cette fois ?";
			link.l1 = "Rien de spécial. Je suis juste venu en visite.";
			link.l1.go = "Good_exit";
			if (CheckAttribute(pchar, "quest.VisitStep"))
			{
				if (sti(pchar.quest.VisitStep)>2 && !CheckAttribute(pchar, "quest.wasInBeedroom"))
				{
					dialog.text = "Oh, "+ GetFullName(pchar)+" en personne chez moi ! Eh bien, ça fait plaisir de vous revoir. Qu'est-ce qui vous amène ?";
					link.l1 = "Salvator, je voudrais parler à votre femme. Je peux ?";
					link.l1.go = "Step_2";
				}
				if (sti(pchar.quest.VisitStep)>2 && CheckAttribute(pchar, "quest.wasInBeedroom"))
				{
					if (!CheckAttribute(pchar, "quest.already"))
					{
						dialog.text = "Vous ne rendez pas un peu trop souvent visite à ma femme, l'ami ?";
						link.l1 = "Oui, ce n'est rien, ami Salvator. Je connais sa famille, alors ne vous inquiétez pas.";
						link.l1.go = "Step_1";
					}
					else
					{
						dialog.text = "Vous avez transmis tout ce qu'il fallait ?";
						link.l1 = "Oui, Salvator, tout va bien.";
						link.l1.go = "Good_exit";
						LocatorReloadEnterDisable("SanJuan_houseSp6", "reload2", true);
					}
					DeleteAttribute(pchar, "quest.wasInBeedroom");
				}
			}
		break;
		case "Step_1":
			dialog.text = "Tout cela est très bien, mais désormais, je vous prie de demander la permission de lui rendre visite, comme cela se fait dans les maisons respectables.";
			link.l1 = "D'accord, Salvator, comme vous voudrez.";
			link.l1.go = "Good_exit";
			LocatorReloadEnterDisable("SanJuan_houseSp6", "reload2", true);
			pchar.quest.already = true;
		break;
		case "Step_2":
			dialog.text = "Pourquoi en as-tu besoin ?";
			link.l1 = "Je voudrais lui transmettre un message de sa famille.";
			link.l1.go = "Step_3";
		break;
		case "Step_3":
			dialog.text = "D'accord, je vous y autorise.";
			link.l1 = "Merci, Salvator. J'y vais tout de suite.";
			link.l1.go = "Good_exit";
			if (pchar.RomanticQuest == "DelivMigel")
			{
				dialog.text = "Vous avez tiré son frère Miguel de Cumaná, alors vous êtes en quelque sorte un ami de la famille, maintenant. Entrez donc, aucun problème.";
				link.l1 = "Hum, je comprends, Salvator. Merci.";
			}
			LocatorReloadEnterDisable("SanJuan_houseSp6", "reload2", false);
		break;

		case "Romantic_Battle_in_Bedroom":
		    if (CheckAttribute(NPChar, "quest.NiceMeet"))
		    {
			    dialog.text = "" + GetFullName(pchar) +", vous avez déjà fait la connaissance de ma femme, " + Characters[GetCharacterIndex("Isabella")].Name + " ? S'il n'y a pas d'objection, je retourne à mes affaires. Je vous attends en bas...";
			    link.l1 = "Oh, oui. Maintenant, je vois votre conseil d'un autre œil.";
			    link.l1.go = "Romantic_Battle_in_Bedroom_3";
			}
			else
			{
			    dialog.text = "Quoi ! Vous ! Vous osez ! Dans la chambre de ma femme ?!";
			    link.l1 = "Je... Je suis entré ici par erreur... Je n'en avais aucune idée...";
			    link.l1.go = "Romantic_Battle_in_Bedroom_1";
			}
		break;

		case "Romantic_Battle_in_Bedroom_1":
			dialog.text = "En garde, imbécile, tu vas mourir !";
			link.l1 = "Quoi ??? Eh bien, c'est ce qu'on va voir !";
			link.l1.go = "Romantic_Battle_in_Bedroom_2";
		break;

		case "Romantic_Battle_in_Bedroom_2":
			DialogExit();
			AddDialogExitQuest("Romantic_Battle_in_Bedroom_3");
		break;

		case "Romantic_Battle_in_Bedroom_3":
		    NextDiag.CurrentNode = "Usual_1";
            Pchar.RomanticQuest.TalkInShop = true;// обошлось все мирно - до встречи в магазине
			DialogExit();
			AddDialogExitQuest("Romantic_Battle_in_Bedroom_4");
		break;

		case "WeWaitYouTonight":
			NextDiag.CurrentNode = "WeWaitYouTonight";
			dialog.text = "Ma femme et moi serons heureux de vous recevoir ce soir, capitaine.";
			link.l1 = "J'y serai sans faute, Salvator.";
			link.l1.go = "exit";
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
		break;

		case "SeenMainHero":
			dialog.text = "Hé, vous tombez à pic, " + GetFullName(pchar) + "... Tuez ce sale porc. Que tout le monde croie qu'ils se sont entretués.";
			link.l1 = "...";
			link.l1.go = "SeenMainHero_1";
		break;
		case "SeenMainHero_1":
			AddQuestRecord("Romantic_Line", "9");
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "houseSp6", "SanJuan_houseSp6", "goto", "goto1", "Romantic_DeadBrother_3", 2.0);
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			NextDiag.CurrentNode = "ArrestInHome_1";
			DialogExit();
		break;

		case "ArrestInHome_1":
			dialog.text = "Oui, vous voilà\n"+
				          "Officier, cet homme a tué le malheureux don Miguel de Valdez ! Et maintenant, il s'apprêtait sans doute à nous tuer, ma femme et moi ! Regardez ! Ses mains sont couvertes de sang !";
			link.l1 = "Menteur sournois ! C'est toi qui as tué don Miguel de Valdez !";
			link.l1.go = "ArrestInHome_2";
		break;
		case "ArrestInHome_2":
			AddDialogExitQuest("Romantic_ArrestInHouse");
			NextDiag.CurrentNode = "Romantic_Battle_in_Bedroom_1";
			DialogExit();
		break;
		//базар в пещере
		case "TalkInCave":
			dialog.text = "Oh, oh, voyez-moi ces tourtereaux qui roucoulent ! Je dérange ?";
			link.l1 = "Au contraire, Salvator, tu tombes à pic ! Si tu savais comme je suis content de te voir !";
			link.l1.go = "TalkInCave_1";
		break;
		case "TalkInCave_1":
			dialog.text = "Vraiment ?";
			link.l1 = "Oui, oui, n'en doute pas. Je te cherche dans toutes les Caraïbes... Tu as apporté le brasero ?";
			link.l1.go = "TalkInCave_2";
		break;
		case "TalkInCave_2":
			dialog.text = "Pas encore, plus tard...";
			link.l1 = "J'ai bien peur que tu n'aies pas d'autre occasion de faire griller quoi que ce soit, l'ami. Il est temps que la señora Isabella devienne veuve.";
			link.l1.go = "TalkInCave_3";
		break;
		case "TalkInCave_3":
			dialog.text = "Et ce ne serait pas toi, ce héros ?";
			link.l1 = "Moi, Salvator, moi...";
			link.l1.go = "TalkInCave_4";
		break;
		case "TalkInCave_4":
			dialog.text = "Alors, commençons ! Bienvenue en enfer, " + GetFullName(pchar) + " !";
			link.l1 = "Je crois que je vais te laisser passer devant... Ah, et ta femme me plaît beaucoup, Salvator. Elle pourrait se dispenser de porter le deuil après ta mort ? Nous sommes pressés de nous marier...";
			link.l1.go = "TalkInCave_5";
		break;
		case "TalkInCave_5":
			dialog.text = "Ah, je vais envoyer ce salaud te rejoindre !";
			link.l1 = "Ce n'est pas bien de parler ainsi de sa propre femme...";
			link.l1.go = "TalkInCave_6";
		break;
		case "TalkInCave_6":
			sld = CharacterFromID("Isabella");
			LAi_SetActorType(sld);
			LAi_ActorRunToLocator(sld, "goto", "goto5", "", -1);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "Romantic_SalvatorIsDead");
			DialogExit();
		break;
	}
}
