// диалоговый файл №1 на голландку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            if (npchar.id == "Bandit2" && pchar.questTemp.State == "SeekChumakeiro_ToAaronHouse")// перехват на бандитов, грябящих Аарона
            {
    			dialog.text = "Fiche le camp tant que tu es entier...";
    			link.l1 = "Je m'appelle "+ GetFullName(pchar) +". Je cherche Aaron Mendes Chumaceiro.";
    			link.l1.go = "Step_H1_1";
            }// Аарон собственной персоной, после драки с грабителями
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekChumakeiro_ToAaronHouse")
            {
    			dialog.text = "On dirait que vous m'avez sauvé la peau ! Qui êtes-vous, et que faites-vous ici ?";
    			link.l1 = "Je m'appelle "+ GetFullName(pchar) +". Je cherche Aaron Mendes Chumaceiro.";
    			link.l1.go = "Step_H1_3";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekChumakeiro_GoToVillemstad")
            {
    			dialog.text = "Je vous suis reconnaissant pour ce voyage réussi. Et doublement reconnaissant d'être arrivé à Saint-Martin à temps. J'espère que nous nous reverrons.";
    			link.l1 = "Avec plaisir.";
    			link.l1.go = "Step_H1_6";
            }// Квест №3, лейтенант в тюрьме.
            if (npchar.id == "Alan_MacLine" && pchar.questTemp.State == "WormEnglPlans_SaveOfficer")
            {
    			dialog.text = "Hum, c'est la première fois que je vous vois... Qui êtes-vous ?";
    			link.l1 = "Je suis là pour vous libérer !";
    			link.l1.go = "Step_H3_1";
            } // Квест №5, базар в Ла Веге о гибели Мэнсфилда
            if (npchar.id == "Talker" && pchar.questTemp.State == "ThreeFleutes_toLaVega")
            {
    			dialog.text = "Oh, vous arrivez en de tristes circonstances... Mansfield est mort.";
    			link.l1 = "Comment a-t-il été tué ?!";
    			link.l1.go = "Step_H5_1";
            } // Квест №7, незнакомец на Тортуге
            if (npchar.id == "Stranger_HL7" && pchar.questTemp.State == "DelivLettTortuga_SnapMeeting")
            {
    			dialog.text = "Dites-moi, ne seriez-vous pas le messager du gouverneur général de Curaçao ?";
    			link.l1 = "Que vouliez-vous ?";
    			link.l1.go = "Step_H7_1";
            } // Квест №7, Антонио в комнате таверны
            if (npchar.id == "AntonioDeBarras" && pchar.questTemp.State == "DelivLettTortuga_toStranger")
            {
    			dialog.text = "Ah, vous voilà enfin...";
    			link.l1 = "Vous vouliez me voir ? Qui êtes-vous ?";
    			link.l1.go = "Step_H7_4";
            }
            if (pchar.questTemp.State == "DelivLettTortuga_NotFoundLetter")
            {
    			dialog.text = "Bon sang ! Je ne pensais pas vous revoir, et encore moins si vite...";
    			link.l1 = "Bonjour, Antonio. Poursuivons notre divertissante conversation. Seulement, cette fois, tout se passera selon mes règles.";
    			link.l1.go = "Step_H7_6";
            } // Квест №8, Аарон даёт задание
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_toAaron")
            {
    			dialog.text = "Ravi de vous voir, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +". Pourquoi êtes-vous venu ?";
    			link.l1 = "Mynheer, Peter Stuyvesant m'a détaché à votre service.";
    			link.l1.go = "Step_H8_1";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_toBermudes")
            {
    			dialog.text = "J'attends votre rapport sur les recherches.";
    			link.l1 = "Je m'en occupe, il y aura des résultats...";
    			link.l1.go = "exit";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_DeGrafIsDead")
            {
    			dialog.text = "J'attends votre rapport sur les recherches.";
    			link.l1 = "Mynheer, j'ai réussi à découvrir qui vendait le livre chrétien que je cherchais. Ce flibustier s'appelle Laurent de Graaf. Ou plutכt s'appelait, puisqu'il est mort. Quand je l'ai rejoint, au large de Carthagène, il livrait bataille à une très puissante escadre espagnole. Je n'ai pas pu sauver sa frégate, et Laurent lui-même a sombré avec son navire. J'ai bien peur que ce soit tout : il est tout simplement impossible de retrouver le livre maintenant.";
    			link.l1.go = "Step_H8_12";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_DeGrafDieHard")
            {
    			dialog.text = "J'attends votre rapport sur les recherches.";
    			link.l1 = "Mynheer, j'ai réussi à découvrir qui vendait le livre chrétien que je cherchais. Ce flibustier s'appelle Laurent de Graaf. Je l'ai trouvé près de Carthagène, il se battait contre une très puissante escadre espagnole. Je n'ai pas pu aider de Graaf, les forces étaient trop inégales. J'ai dמ quitter le champ de bataille.";
    			link.l1.go = "Step_H8_12";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_BadResult")
            {
    			dialog.text = "Je n'ai plus rien à vous dire. Allez voir Stuyvesant.";
    			link.l1 = "Bien, mynheer.";
    			link.l1.go = "exit";
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_WeWon")
            {
    			dialog.text = "J'attends votre rapport sur les recherches.";
    			link.l1 = "Je n'ai rien pu trouver. Je suis contraint d'abandonner les recherches.";
    			link.l1.go = "Step_H8_12";
    			link.l2 = "Je ne cesse de chercher, de me battre, de couler des Espagnols... Mais je n'ai pas encore trouvé le livre... Cependant, je vais continuer à chercher...";
    			link.l2.go = "exit";
			}
			if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_IHaveMap")
            {
                dialog.text = "J'attends votre rapport sur les recherches.";
    			link.l1 = "Je n'ai rien pu trouver. Je suis contraint d'abandonner les recherches.";
    			link.l1.go = "Step_H8_12";
				if (CheckCharacterItem(pchar, "Bible"))
				{
           			link.l2 = "J'ai réussi à me procurer un livre. Je ne sais pas si c'est ce que vous cherchez, mais il y a bien une croix sur la couverture.";
        			link.l2.go = "Step_H8_13";
                }
                else
                {
        			link.l2 = "Je n'ai pas encore réussi à trouver le livre, mais je le cherche. Il va falloir patienter...";
        			link.l2.go = "exit";
                }
            }
            if (npchar.id == "Chumakeiro" && pchar.questTemp.State == "SeekBible_GoodResult")
            {
    			dialog.text = "Moi et toute notre communauté prions pour vous...";
    			link.l1 = "Hé, merci...";
    			link.l1.go = "exit";
            }

        break;

//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Дилоги бандитов, грабящих Аарона. Квест №1 **********************************
 		case "Step_H1_1":
			dialog.text = "Je t'ai dit de dégager, ou je t'étripe.";
			link.l1 = "En fait, je ne suis pas pour cette méthode, je tiens beaucoup à mes tripes. Mais on dirait qu'il est temps de jeter un coup d'œil aux tiennes...";
			link.l1.go = "Step_H1_2";
		break;
 		case "Step_H1_2":
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
 		case "Step_H1_3":
			dialog.text = "C'est moi.";
			link.l1 = "Peter Stuyvesant m'a envoyé vous chercher, je dois vous conduire à Curaçao. Et que faisaient ces malotrus chez vous ?";
			link.l1.go = "Step_H1_4";
		break;
 		case "Step_H1_4":
			dialog.text = "On dirait qu'ils m'ont dévalisé. Le fait est que j'attends depuis trois jours un homme de Peter, et quand on a frappé à la porte, je n'ai même pas demandé qui c'était avant d'ouvrir. En une minute, on m'a ligoté et jeté dans cette pièce, et les brigands eux-mêmes se sont mis à fouiller activement mes affaires personnelles.";
			link.l1 = "Eh bien, tout est bien qui finit bien. Faites vos bagages et bienvenue à bord de mon voilier. Stuyvesant vous attend, nous partons immédiatement.";
			link.l1.go = "Step_H1_5";
		break;
 		case "Step_H1_5":
            AddQuestRecord("Hol_Line_1_Chumakeiro", "2");
			AddQuestUserData("Hol_Line_1_Chumakeiro", "sSex", GetSexPhrase("", "e"));
	AddQuestUserData("Hol_Line_1_Chumakeiro", "sSex1", GetSexPhrase("", "e"));
		    pchar.questTemp.State = "SeekChumakeiro_GoToVillemstad";
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", 2.0);
            //ChangeCharacterReputation(pchar, 5); TO_DO eddy
            AddPassenger(pchar, npchar, false);
            SetCharacterRemovable(npchar, false);
            Pchar.quest.SeekChumakeiro_intoResidence.win_condition.l1 = "location";
            Pchar.quest.SeekChumakeiro_intoResidence.win_condition.l1.location = "Villemstad_townhall";
            Pchar.quest.SeekChumakeiro_intoResidence.win_condition = "SeekChumakeiro_intoResidence";
			DialogExit();
		break;
 		case "Step_H1_6":
			dialog.text = "Maintenant, j'aimerais que vous acceptiez une petite récompense de ma part : 30 000 piastres.";
			link.l1 = "Je ne refuserai pas, merci.";
			link.l1.go = "Step_H1_7";
		break;
 		case "Step_H1_7":
            LAi_SetPlayerType(pchar);
			AddMoneyToCharacter(pchar, 30000);
			RemovePassenger(pchar, npchar);
			AddQuestRecord("Hol_Line_1_Chumakeiro", "3");
			AddQuestUserData("Hol_Line_1_Chumakeiro", "sSex", GetSexPhrase("", "e"));
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload2", "none", "", "", "", 10.0);
			DialogExit();
		break;

//********************************* Дилоги лейтенанта в тюрьме. Квест №3 **********************************
 		case "Step_H3_1":
			dialog.text = "דa alors, c'est formidable ! א quoi dois-je une telle attention à ma personne, et un tel intérêt pour mon sort ?";
			link.l1 = "J'ai besoin d'apprendre quelque chose de vous.";
			link.l1.go = "Step_H3_2";
		break;
 		case "Step_H3_2":
			dialog.text = "Je suis tout à votre service. Mais d'abord, choisissons un endroit plus paisible pour une conversation aussi divertissante.";
			link.l1 = "Je promets de vous libérer. Mais d'abord, je dois obtenir les informations dont j'ai besoin. Je veux savoir oם Madiford prépare le débarquement.";
			link.l1.go = "Step_H3_3";
		break;
 		case "Step_H3_3":
			dialog.text = "Le fort hollandais d'Orange sera pris et détruit.";
			link.l1 = "Bon sang, tout le laissait penser ! Je tiens parole : vous êtes libre d'aller oם vous voulez. Adieu.";
			link.l1.go = "Step_H3_4";
		break;
 		case "Step_H3_4":
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "PortRoyal_houseS1", "sit", "sit2");
            LAi_SetHuberType(characterFromId("Henry Morgan"));
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "14");
			AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex", GetSexPhrase("", "e"));
 		    pchar.questTemp.State = "WormEnglPlans_GoodRusultWorm";
            ChangeCharacterAddressGroup(npchar, "SentJons_prison", "goto", "goto23");
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "", 15.0);
            DialogExit();
		break;

//********************************* Базар в Ла Веге о гибели Мэнсфилда. Квест №5 **********************************
  		case "Step_H5_1":
			dialog.text = "Les Espagnols nous ont attaqués. Une bonne moitié des gens sont morts.";
			link.l1 = "דa alors ! Dommage pour Edward, c'était un brave vieil homme.";
			link.l1.go = "Step_H5_2";
		break;
 		case "Step_H5_2":
			chrDisableReloadToLocation = false;
 		    AddQuestRecord("Hol_Line_5_ThreeFleutes", "2");
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 5.0);
            Pchar.quest.ThreeFleutes_BackToCuracao.win_condition.l1 = "location";
            Pchar.quest.ThreeFleutes_BackToCuracao.win_condition.l1.location = "Hispaniola1";
            Pchar.quest.ThreeFleutes_BackToCuracao.win_condition = "ThreeFleutes_BackToCuracao";
            DialogExit();
		break;

//********************************* Базар с незнакомцем на Тортуге. Квест №7 **********************************
  		case "Step_H7_1":
			dialog.text = "L'homme de confiance de Stuyvesant vous attend à la taverne.";
			link.l1 = "Et que me veut cette personne ?";
			link.l1.go = "Step_H7_2";
		break;
  		case "Step_H7_2":
			dialog.text = "Un ordre urgent du gouverneur général, vous devez le lire immédiatement.";
			link.l1 = "Hum... bon, d'accord.";
			link.l1.go = "Step_H7_3";
		break;
  		case "Step_H7_3":
			chrDisableReloadToLocation = false;
			pchar.questTemp.State = "DelivLettTortuga_toStranger";
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "gate_back", "none", "", "", "", 40.0);
            LAi_SetPlayerType(pchar);
            sld = GetCharacter(NPC_GenerateCharacter("AntonioDeBarras", "officer_9", "man", "man", 40, SPAIN, -1, true));
            sld.Dialog.Filename = "Quest\HolLineNpc_1.c";
        	sld.name 	= "Antonio";
        	sld.lastname = "de Barras";
        	LAi_SetStayTypeNoGroup(sld);
            FantomMakeCoolSailor(sld, SHIP_INGERMANLAND, "Isabella", CANNON_TYPE_CULVERINE_LBS32, 100, 100, 100);
            FantomMakeCoolFighter(sld, 40, 100, 100, "blade32", "pistol5", 150);
          	ChangeCharacterAddressGroup(sld, "Tortuga_tavern_upstairs", "goto", "goto1");
            DialogExit();
		break;

        case "Step_H7_4":
			dialog.text = "Je m'appelle Antonio, mais ça s'arrête là, d'ailleurs. En attendant, "+
                          "Tiens, tiens ! Regardez qui nous rend visite !";
			link.l1 = "Hein ?";
			link.l1.go = "Step_H7_5";
		break;
  		case "Step_H7_5":
            LocatorReloadEnterDisable("Tortuga_town", "gate_back", false);
            LocatorReloadEnterDisable("Tortuga_town", "reload1_back", false);
            LocatorReloadEnterDisable("Tortuga_town", "reload2_back", false);
            LocatorReloadEnterDisable("Tortuga_tavern", "reload2_back", true);
            LAi_SetActorType(npchar);
            LAi_SetActorType(pchar);
            LAi_ActorTurnToLocator(pchar, "reload", "reload1_back");
            DoQuestFunctionDelay("DelivLettTortuga_Digress", 1.0);
            DialogExit();
		break;

        case "Step_H7_6":
			dialog.text = "Et quelles seront ces règles ?";
			link.l1 = "Tu répondras aux questions ; pour chaque mauvaise réponse, je te couperai un doigt. Dix mauvaises réponses, et tu n'auras plus de doigts. Les règles sont claires ?";
			link.l1.go = "Step_H7_7";
		break;
        case "Step_H7_7":
			dialog.text = "Hum... Vous savez, en ce moment précis, je tiens beaucoup à mes membres. Alors posez vos questions, je vous dirai tout.";
			link.l1 = "Question numéro un : qui es-tu, et que faisais-tu à Tortuga ?";
			link.l1.go = "Step_H7_8";
		break;
        case "Step_H7_8":
			dialog.text = "Je m'appelle Antonio de Barras, je suis un agent espagnol. Ce n'est pas vous que j'attendais à Tortuga, j'attendais simplement un messager de Stuyvesant. Ce n'est pas difficile de repérer un navire hollandais qui entre au port. Et quand vous êtes allé tout droit chez d'Ogeron, tout est devenu clair.";
			link.l1 = "Bien... Question numéro deux : oם est la dépêche ?";
			link.l1.go = "Step_H7_9";
		break;
        case "Step_H7_9":
			dialog.text = "Je l'ai. Je vous en prie, prenez-la...";
			link.l1 = "Très bien, je suis content pour tes doigts... Bon, ça suffit pour l'instant, le reste se passera à Willemstad. J'espère que vous me ferez la faveur, señor Antonio, de visiter cette glorieuse ville hollandaise ?";
			link.l1.go = "Step_H7_10";
            GiveItem2Character(pchar, "letter_1");
		break;
        case "Step_H7_10":
			dialog.text = "J'ai bien peur qu'en l'occurrence, mon souhait ne soit pas pris en compte...";
			link.l1 = "Il ne le sera pas, señor Antonio, c'est exact.";
			link.l1.go = "Step_H7_11";
		break;
        case "Step_H7_11":
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "11");
            pchar.questTemp.State = "DelivLettTortuga_LetterFound";
            pchar.quest.DelivLettTortuga_WarshipDieHard.over = "yes";
            pchar.quest.DelivLettTortuga_AfterWarshipSunk.over = "yes";
            Island_SetReloadEnableGlobal("SantaCatalina", true);
            QuestAboardCabinDialogSurrender();
            DialogExit();
		break;

//********************************* Поиски Библии. Квест №8 **********************************
        case "Step_H8_1":
			dialog.text = "Oh, c'est formidable que ce soit vous qui m'aidiez dans mes recherches. Je vous ai déjà vu à l'œuvre.";
			link.l1 = "De quelles recherches parle-t-on ? Stuyvesant ne m'a rien dit de précis...";
			link.l1.go = "Step_H8_2";
		break;
        case "Step_H8_2":
			dialog.text = "C'est vrai, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +"

. Mais chaque chose en son temps.\n"+
                          "Samuel Kohano a été le premier janséniste à fuir l'Europe pour Curaçao, il y a une vingtaine d'années. C'était un homme très riche, et un jour, il a réussi à acheter, pour une somme fabuleuse, un document très, très mystérieux au tribunal de l'Inquisition de Séville. Il s'agit d'un autre וvangile.\n"+
                          "En bon chrétien, vous avez sans doute lu l'Ancien et le Nouveau Testament ?";
			link.l1 = "Que dire, ce serait difficile autrement...";
			link.l1.go = "Step_H8_3";
		break;
        case "Step_H8_3":
			dialog.text = "Saviez-vous que les textes bibliques dont nous disposons aujourd'hui ne sont pas des sources originales, pour ainsi dire...";
			link.l1 = "Qu'est-ce que cela veut dire ?";
			link.l1.go = "Step_H8_4";
		break;
        case "Step_H8_4":
			dialog.text = "Le fait est que la Bible n'a pas été écrite immédiatement après la Résurrection du Christ. Il a fallu assez longtemps avant que l'וglise, renforcée, se soucie de rassembler et de classer les écrits chrétiens afin d'unifier la foi autour de dogmes communs\n"+
                          "C'est alors qu'a eu lieu une révision détaillée de tout ce que l'וglise avait entre les mains à l'époque. Une fois les informations rassemblées et analysées, il s'est avéré que certaines choses se contredisaient directement. On a alors réuni un concile au plus haut niveau, oם l'on a décidé si tel ou tel document pouvait être considéré comme authentique.";
			link.l1 = "Très intéressant. Mais quel rapport avec ma mission ?";
			link.l1.go = "Step_H8_5";
		break;
        case "Step_H8_5":
			dialog.text = "Patience, mon ami, et tout va s'éclaircir pour vous.\n"+ 
                          "Donc, beaucoup de choses ont été déclarées hérétiques et ont été soit détruites, soit cachées si profondément et si sמrement qu'il n'a pas été possible de les ramener à la lumière du jour. Mais Samuel y est parvenu ! Pour une somme astronomique, il a réussi à soudoyer un archiviste jésuite, qui a volé dans les caves secrètes de l'Inquisition un וvangile inconnu jusqu'alors !\n"+
                          "Samuel a aussitכt fui l'Ancien Monde, mais les malheurs l'ont poursuivi littéralement à chaque pas. Finalement, cet homme si riche et si digne a tout perdu, a été vendu comme esclave et est mort dans des plantations de canne à sucre, quelque part ici, dans les colonies anglaises.";
			link.l1 = "Je dois trouver le lieu de sa mort ?";
			link.l1.go = "Step_H8_6";
		break;
        case "Step_H8_6":
			dialog.text = "Non, cela n'a aucun sens. Vous devez retrouver le traité disparu.";
			link.l1 = "Je n'imagine même pas à quoi l'on peut se raccrocher, par oם commencer les recherches...";
			link.l1.go = "Step_H8_7";
		break;
        case "Step_H8_7":
			dialog.text = "Il y a une piste : c'est elle qui m'a poussé à vous demander à Stuyvesant.";
			link.l1 = "Je vous écoute attentivement, Aaron.";
			link.l1.go = "Step_H8_8";
		break;
        case "Step_H8_8":
			dialog.text = "J'ai entendu dire qu'un corsaire anglais de la colonie pirate des Bermudes avait l'intention de vendre un vieux livre chrétien, écrit dans une langue qu'il ne connaissait pas.";
			link.l1 = "Hum, mais si la langue lui est inconnue, comment a-t-il déterminé que le livre était chrétien ?";
			link.l1.go = "Step_H8_9";
		break;
        case "Step_H8_9":
			dialog.text = "Grâce aux images de la crucifixion sur le livre, mon ami.";
			link.l1 = "Compris... Bon, comment s'appelle ce pirate ?";
			link.l1.go = "Step_H8_10";
		break;
        case "Step_H8_10":
			dialog.text = "Je l'ignore.";
			link.l1 = "Je vois... Bon, je suppose que je peux découvrir son nom et oם se trouve ce livre maintenant.";
			link.l1.go = "Step_H8_11";
		break;
        case "Step_H8_11":
			dialog.text = "J'en suis presque sמr à cent pour cent. Mettez-vous au travail, "+ GetSexPhrase("mon ami", "" + pchar.name + "") +". En cas de succès, la récompense sera très élevée.";
			link.l1 = "Cette nouvelle encourageante me donnera sans aucun doute du zèle. א bientכt, Aaron, je me mets à chercher immédiatement.";
			link.l1.go = "exit";
            pchar.questTemp.State = "SeekBible_toBermudes";
            AddQuestRecord("Hol_Line_8_SeekBible", "2");
            QuestSetCurrentNode("Jackman", "HolLine8_quest");
		break;
        case "Step_H8_12":
			dialog.text = "C'est très, très mauvais... Bon, je n'ai plus besoin de vous. Retournez voir Stuyvesant.";
			link.l1 = "Bien, mynheer.";
			link.l1.go = "exit";
            pchar.questTemp.State = "SeekBible_BadResult";
            NPChar.LifeDay = 0;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
		break;
        case "Step_H8_13":
			dialog.text = "Voyons voir... Oui, c'est exactement ce que nous avions perdu ! Vous avez retrouvé le trésor perdu de Samuel Cohen ! Mon Dieu, merci !!!";
			link.l1 = "Maintenant et toujours, et pour les siècles des siècles. Amen.";
			link.l1.go = "Step_H8_14";
			TakeItemFromCharacter(pchar, "Bible");
		break;
        case "Step_H8_14":
			dialog.text = GetFullName(pchar) + ", je vous avais promis que votre récompense serait très élevée. א combien estimez-vous votre travail ?";
			link.l1 = "Eh bien, j'ai eu des frais : j'ai dépensé 235 000 pour l'achat. Tout ce que vous m'offrirez au-delà de cette somme sera une récompense.";
			link.l1.go = "Step_H8_15";
		break;
        case "Step_H8_15":
			dialog.text = "En plus de cela, je vous offre un million. Et le respect infini de notre communauté jusqu'à la fin des temps, qui, d'ailleurs, arrivera bientכt...";
			link.l1 = "Hé, un million, ce n'est pas mal, c'est même très bien ! Pourquoi parlez-vous de la fin du monde ?";
			link.l1.go = "Step_H8_16";
		break;
        case "Step_H8_16":
			dialog.text = "L'existence mortelle de l'humanité sur cette terre est une tragédie. Mais bientכt, tout redeviendra comme avant, comme au commencement...";
			link.l1 = "Vous êtes sérieux ? Bon sang, ça m'a gâché tout le plaisir de recevoir une somme aussi importante. Bon, d'accord... Vous, vous attendez peut-être le dénouement de votre tragédie, et moi, je vais m'occuper de choses plus prosaïques : vanité des vanités. Avec une telle somme en poche, la tragédie personnelle de mon existence va me procurer bien des moments agréables.";
			link.l1.go = "Step_H8_17";
		break;
        case "Step_H8_17":
			dialog.text = "Adieu, et que le Seigneur vous protège !";
			link.l1 = "Portez-vous bien, vous aussi. Adieu.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 1235000);
            pchar.questTemp.State = "SeekBible_GoodResult";
            AddQuestRecord("Hol_Line_8_SeekBible", "10");
			AddQuestUserData("Hol_Line_8_SeekBible", "sSex", GetSexPhrase("", "e"));
            NPChar.LifeDay = 0;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
		break;
    }
}
