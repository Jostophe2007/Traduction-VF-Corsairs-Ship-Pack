// диалоговый файл №1 на испанку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            //Квест №1, спасение трёх горожан.
            if (npchar.id == "SpaPrisoner1" || npchar.id == "SpaPrisoner2" || npchar.id == "SpaPrisoner3")
            {
    			if (pchar.questTemp.State == "SaveFromMorgan_toPrison")
    			{
                    dialog.text = ""+ GetSexPhrase("Señor", "Señorita") +", qui êtes-vous ?";
        			link.l1 = "Au diable les discours, je vais vous libérer, et nous allons filer d'ici. א moins que vous n'aimiez la tambouille anglaise ? Dispersez-vous et dirigez-vous vers mon navire sans attirer l'attention. Votre tâche, c'est d'atteindre mon navire vivants. Dans un moment, je vais semer un peu de pagaille pour détourner l'attention, ce sera plus facile pour vous. J'espère que vous avez tout compris ?";
        			link.l1.go = "Step_S1_1";
                }
                else
                {
                    dialog.text = LinkRandPhrase("Le Seigneur a entendu nos prières !", "Si vous saviez comme nous sommes heureux de vous voir...", "Merci au gouverneur général, il ne nous a pas oubliés...");
        			link.l1 = "Oui, oui... Mais je vous en prie, ne parlez pas tant que nous ne sommes pas sortis d'ici...";
        			link.l1.go = "exit";
                }
            }
            if (pchar.questTemp.State == "TakeRockBras_toNearestMaracaibo")// квест №3, Рок Бриазилец в каюте на абордаже
            {
    			dialog.text = "Vous êtes "+ GetSexPhrase("le vainqueur, maudit Castillan", "la gagnante, maudite Espagnole") +".";
    			link.l1 = "C'est très bien que vous ayez décidé de vous rendre. Je viens vous voir avec une proposition.";
    			link.l1.go = "Step_S3_1";
            }
            if (npchar.id == "ServantDEstre" && pchar.questTemp.State == "Sp4Detection_toTortuga")// квест №4, базар со слугой д'Эстре предварительный.
            {
    			dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ? Le maître n'est pas à la maison.";
    			link.l1 = "Je vois...";
    			link.l1.go = "exit";
            }
            if (npchar.id == "ServantDEstre" && pchar.questTemp.State == "Sp4Detection_toDEstre")// квест №4, базар со слугой д'Эстре
            {
    			dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
    			link.l1 = "J'ai besoin de voir votre maître, Henri d'Estre.";
    			link.l1.go = "Step_S4_1";
            }
            if (npchar.id == "ServantDEstre" && pchar.questTemp.State == "Sp4Detection_toDEstre_1")// квест №4, базар со слугой д'Эстре
            {
    			dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", vous devez vous dépêcher !";
    			link.l1 = "Oui, compris.";
    			link.l1.go = "exit";
            }
            if (npchar.id == "AnryDEstre")// квест №4, базар с самим д'Эстре
            {
    			dialog.text = "Bon sang, expliquez-moi immédiatement pourquoi vous me suivez !!!";
    			link.l1 = "Je devais vous parler de toute urgence, veuillez m'excuser, monsieur...";
    			link.l1.go = "Step_S4_2";
            }
            if (npchar.id == "LaVega_Comendant") // ==>  квест №5, фантом Мэнсфилада при штурме Ла Веги
            {
    			dialog.text = "Alors, qu'en dis-tu, bête catalane ?";
    			link.l1 = "Aujourd'hui, nous allons mettre fin à un vieux différend avec les boucaniers. Vous serez tous anéantis, et Hispaniola ne sera plus peuplée que de colons espagnols !";
    			link.l1.go = "Step_S5_1";
            }
            if (npchar.id == "Boozer") // ==>  квест №6, базар с алкашом в таверне
            {
    			dialog.text = "Hein ? Qu'est-ce qu'il vous faut ?!";
    			link.l1 = "Rien de spécial. Je voulais juste vous donner quelques pièces : vous souffrez, ça vous remettra d'aplomb...";
    			link.l1.go = "Step_S6_1";
            }
            if (npchar.id == "Messanger" && pchar.questTemp.State == "Sp6TakeMess_waitMessanger") //квест №6, базар с голландским вестовым
            {
    			dialog.text = "Que voulez-vous ?";
    			link.l1 = "J'agis pour le compte du gouverneur général de Curaçao. Je dois vous parler. Allons à la taverne, bavardons un peu...";
    			link.l1.go = "Step_S6_8";
    			link.l2 = "Je veux que vous me remettiez la correspondance diplomatique. Et faisons ça discrètement, sinon je vous étripe...";
    			link.l2.go = "Step_S6_11";
            }
            if (npchar.id == "Messanger" && pchar.questTemp.State == "Sp6TakeMess_Action") //квест №6, базар с голландским вестовым
            {
    			dialog.text = "On m'a dit que l'homme de confiance de Stuyvesant m'attendait ici. Qui êtes-vous et que voulez-vous ?";
    			link.l1 = "Peu importe qui je suis, mais j'ai besoin de vos papiers.";
    			link.l1.go = "Step_S6_13";
			}
            if (npchar.id == "OurCaptain_1") //квест №7, базар с Пардалем его на корабле до битвы
            {
    			dialog.text = "Bon sang, ce n'est pas le moment de faire de la politique ! Les ladrones m'attaquent, aidez-moi !!!";
    			link.l1 = "D'accord.";
    			link.l1.go = "Exit";
			}
            if (npchar.id == "OurCaptain_1" && pchar.questTemp.State == "Sp7SavePardal_GoodWork") //квест №7, базар с Пардалем его на корабле
            {
    			dialog.text = "Diable, vous tombez à pic ! Je ne sais même pas ce que j'aurais fait sans votre aide... Dites-moi, à qui dois-je mon salut ?";
    			link.l1 = "Je m'appelle " + GetFullName(pchar) +". Et c'est Francisco Oregon y Gascón qui m'envoie à votre secours. Il a appris qu'une escadre de bandits français était partie tout exprès pour vous affronter.";
    			link.l1.go = "Step_S7_1";
			}
            if (npchar.id == "OurCaptain_1" && pchar.questTemp.State == "Sp7SavePardal_2GoodWork") //квест №7, базар с Пардалем его на корабле
            {
    			dialog.text = "Nous avons parlé, et ça suffit...";
    			link.l1 = "J'en conviens...";
    			link.l1.go = "exit";
			}
            if (npchar.id == "SpaTalkOfficer" && pchar.questTemp.State == "Sp10Maracaibo_TalkWithOfficer") //квест №10, базар c оффом на выходе
            {
    			dialog.text = "Place !!!";
    			link.l1 = "Doucement, mon cher ! Oם courez-vous comme ça ?";
    			link.l1.go = "Step_S10_1";
			}

		break;
//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Спасение трёх горожан. Квест №1 **********************************
 		case "Step_S1_1":
			dialog.text = "Oui, "+ GetSexPhrase("señor", "señorita") +". Merci, et que le Seigneur vous protège !";
			link.l1 = "Amen ! Maintenant, dépêchez-vous...";
			link.l1.go = "Step_S1_2";
		break;
 		case "Step_S1_2":
            AddQuestRecord("Spa_Line_1_SaveCitizens", "2");
			pchar.questTemp.State = "SaveFromMorgan_OutOfPrison";
            for (i=1; i<=3; i++)
            {
                sld = characterFromId("SpaPrisoner"+i);
                ChangeCharacterAddressGroup(sld, "PortRoyal_Prison", "goto", "goto12");
                LAi_SetActorType(sld);
                LAi_ActorRunToLocation(sld, "reload", "reload1", "none", "", "", "", 10.0);
                AddPassenger(pchar, sld, false);
                SetCharacterRemovable(sld, false);
            }
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
		break;
//********************************* Работа на инквизицию. Квест №3 **********************************
 		case "Step_S3_1":
			dialog.text = "Quelle est cette proposition ?";
			link.l1 = "La proposition d'une rencontre avec Monseigneur Antonio de Souza.";
			link.l1.go = "Step_S3_2";
		break;
 		case "Step_S3_2":
			dialog.text = "Je ne sais pas qui c'est ?";
			link.l1 = "Une personne très importante de la Sainte Inquisition, un gros bonnet. Alors, vous avez de la chance.";
			link.l1.go = "Step_S3_3";
		break;
 		case "Step_S3_3":
			dialog.text = "Bon sang, je regrette de m'être rendu. J'aurais mieux fait de mourir au combat que de souffrir...";
			link.l1 = "Peut-être. Bon, maintenant, il faut y aller, on nous attend avec impatience à Santiago.";
			link.l1.go = "Step_S3_4";
		break;
 		case "Step_S3_4":
 		    pchar.questTemp.State = "TakeRockBras_RockTaken";
            AddQuestRecord("Spa_Line_3_RockBrasilian", "5");
            pchar.quest.TakeRockBras_DieHard.over = "yes";
            Island_SetReloadEnableGlobal("Maracaibo", true);
		    QuestAboardCabinDialogQuestSurrender();
			Group_DeleteGroup("Pirate_Attack");
            DialogExit();
		break;
//********************************* Расследование убийства. Квест №4 **********************************
 		case "Step_S4_1":
			dialog.text = "Il est dans la rue, juste à cכté de la maison. Il était pressé d'aller quelque part, mais un flibustier de sa connaissance l'a arrêté pour lui parler il y a une minute. Il va vite finir sa conversation et filer à ses affaires. Alors, si vous voulez l'attraper, dépêchez-vous.";
			link.l1 = "D'accord, je me dépêche...";
			link.l1.go = "exit";
			pchar.questTemp.State = "Sp4Detection_toDEstre_1";
			pchar.quest.Sp4Detection_Race_1.win_condition.l1 = "location";
			pchar.quest.Sp4Detection_Race_1.win_condition.l1.location = "Tortuga_town";
			pchar.quest.Sp4Detection_Race_1.win_condition = "Sp4Detection_Race_1";
    	    NPChar.LifeDay = 0;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
		break;
 		case "Step_S4_2":
			dialog.text = "Bon, je vous demande pardon... א qui ai-je l'honneur de parler ?";
			link.l1 = "Je m'appelle " + GetFullName(pchar) + ". J'aimerais savoir qui est cette doña Anna que vous avez amenée à monsieur d'Ogeron ?";
			link.l1.go = "Step_S4_3";
		break;
 		case "Step_S4_3":
			dialog.text = "Vous, "+ GetSexPhrase("monsieur", "mademoiselle") +", vous fourrez votre nez là oם il ne faut pas. דa pourrait très mal finir pour vous...";
			link.l1 = "Je le sais. Mais je vous le redemande néanmoins : doña Anna est-elle l'épouse, et désormais la veuve, du commandant de La Havane, don Juan Ramírez de Leyva ?";
			link.l1.go = "Step_S4_4";
		break;
 		case "Step_S4_4":
			dialog.text = "Et si c'est le cas, alors quoi ?";
			link.l1 = "Alors, monsieur, je dois vous tuer.";
			link.l1.go = "Step_S4_5";
		break;
 		case "Step_S4_5":
			dialog.text = "Une déclaration bien directe. Mais pourquoi tout de suite me tuer ? Personnellement, si je me souviens bien, je ne vous ai causé aucun tort. Ne croyez pas que j'aie peur, j'ai juste besoin de comprendre la raison de votre présence ici.";
			link.l1 = "La raison est simple : les lois de l'honneur. Vous avez porté atteinte à ce qui ne vous appartient pas : la femme d'un autre. Et en même temps, cinq personnes ont été tuées !";
			link.l1.go = "Step_S4_6";
		break;
 		case "Step_S4_6":
			dialog.text = "Oh oh, vous êtes bien au courant de cette aventure, vous savez même combien de diables d'Espagnols j'ai envoyés dans l'autre monde... Je suis impressionné. Alors, qui êtes-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
			link.l1 = "Je suis corsaire au service de l'Espagne, et j'enquête en ce moment sur le meurtre du commandant de La Havane et la disparition de sa veuve. Oui, j'oubliais : au nom du gouverneur général de La Havane, don Francisco Oregon y Gascón.";
			link.l1.go = "Step_S4_7";
		break;
 		case "Step_S4_7":
			dialog.text = "Bon, maintenant, tout est clair, et je peux sans scrupule vous envoyer dans l'autre monde. En garde, "+ GetSexPhrase("señor", "señorita") +" !";
			link.l1 = "Parfaitement, monsieur !";
			link.l1.go = "Step_S4_8";
		break;
 		case "Step_S4_8":
            LAi_SetPlayerType(pchar);
			pchar.questTemp.State = "Sp4Detection_toDEstre_2";
            LAi_SetHP(npchar, 300, 300);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "Sp4Detection_YouWin");
    	    NPChar.LifeDay = 0;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Уничтожение Ла Веги. Квест №5 **********************************
 		case "Step_S5_1":
			dialog.text = "Argh, "+ GetSexPhrase("chien d'Espagnol", "ordure d'Espagnole") +" ! Le vieux boucanier vendra chèrement sa peau...";
			link.l1 = "Oui, il est temps d'en finir...";
			link.l1.go = "Step_S5_2";
			AfterTownBattle();
		break;
 		case "Step_S5_2":
            LAi_SetPlayerType(pchar);
            LAi_group_MoveCharacter(npchar, LAI_GROUP_TmpEnemy);
            LAi_group_SetRelation(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups(LAI_GROUP_TmpEnemy, LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck(LAI_GROUP_TmpEnemy, "Sp5LaVegaAttack_AfterFight");
    	    NPChar.LifeDay = 0;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
			SetReturn_Gover_Dialog_Exit(NPChar);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Перехват посыльного Сювесанта. Квест №6 **********************************
 		case "Step_S6_1": //алкаш
			dialog.text = "Oh, voilà qui est bien ! Donnez-moi l'argent...";
			link.l1 = "Rendez-moi d'abord un service, ensuite vous aurez votre argent.";
			link.l1.go = "Step_S6_2";
		break;
 		case "Step_S6_2":
			dialog.text = "Kh-hé, et moi qui me réjouissais... Que dois-je faire ?";
			link.l1 = "Dans un moment, un Hollandais va sortir de la résidence et se diriger vers le port, vers son navire. Vous devez lui dire que la personne de confiance du gouverneur général Stuyvesant l'attend dans la chambre de la taverne, à l'étage.";
			link.l1.go = "Step_S6_3";
		break;
 		case "Step_S6_3":
			dialog.text = "Et combien vous me donnerez ?";
			link.l1 = "Hum, eh bien, vous pouvez compter sur une centaine.";
			link.l1.go = "Step_S6_4";
		break;
 		case "Step_S6_4":
			dialog.text = "Cent pièces maintenant, et je le fais. Sinon, je ne peux pas bouger d'ici : j'ai une gueule de bois terrible...";
			link.l1 = "Gardez votre argent. Et au travail, j'attends.";
			link.l1.go = "Step_S6_5";
		break;
 		case "Step_S6_5":
			dialog.text = "Ne vous inquiétez pas, je bois un coup et tout ira bien...";
			link.l1 = "Dépêchez-vous de boire, ne ratez pas le messager. Et souvenez-vous : j'attends le Hollandais dans la chambre de la taverne, à l'étage !";
			link.l1.go = "Step_S6_6";
            AddMoneyToCharacter(pchar, -100);
		break;
 		case "Step_S6_6":
			pchar.questTemp.State = "Sp6TakeMess_Action";
			AddQuestRecord("Spa_Line_6_TakeMessangeer", "4");
			GetCharacterPos(pchar, &locx, &locy, &locz);
         	ChangeCharacterAddressGroup(npchar, "Tortuga_tavern", "tables", LAi_FindNearestFreeLocator("tables", locx, locy, locz));
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
            Pchar.quest.Sp6TakeMess_WaitMessanger.win_condition.l1 = "location";
            Pchar.quest.Sp6TakeMess_WaitMessanger.win_condition.l1.location = "Tortuga_tavern_upstairs";
            Pchar.quest.Sp6TakeMess_WaitMessanger.win_condition = "Sp6TakeMess_WaitMessanger";
			pchar.quest.Sp6TakeMess_Interception.over = "yes";
			LocatorReloadEnterDisable("Tortuga_tavern", "reload1_back", true);
            DialogExit();
		break;
		//=====>>> вестовой при попытке взять его в городе.
		case "Step_S6_11":
			dialog.text = "Hum, allez, essayez...";
			link.l1 = "Argh !";
			link.l1.go = "Step_S6_7";
		break;
 		case "Step_S6_7":
			LAi_RemoveCheckMinHP(sld);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "FRANCE_CITIZENS");
			LAi_group_Attack(NPChar, Pchar);
			SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
            DialogExit();
		break;
 		case "Step_S6_8":
			dialog.text = NPCStringReactionRepeat("Si vous voulez me dire quelque chose, dites-le immédiatement, et ici.",
                          "Encore vous ? Je vous ai dit que je n'irais nulle part !", "דa suffit, vous m'avez épuisé... Gardes, attention à "+ GetSexPhrase("lui", "elle") +" ! On a affaire à un espion !", "none", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Allons à la taverne...", "וcoute...", "Oh, quoi ?!", "none", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_S6_9", "Step_S6_12", "Step_S6_7", "none", npchar, Dialog.CurrentNode);
		break;
 		case "Step_S6_9":
			dialog.text = "Je n'irai dans aucune taverne. Dites-moi, qu'avez-vous pour moi ?";
			link.l1 = "Vous savez... euh...";
			link.l1.go = "Step_S6_10";
		break;
 		case "Step_S6_10":
			dialog.text = "Je comprends... Je vais sans doute signaler vos agissements étranges au port... J'imagine qu'il ne vous sera plus si facile de quitter cette ville.";
			link.l1 = "Hum...";
			link.l1.go = "Step_S6_12";
		break;
 		case "Step_S6_12":
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload2_back", "none", "", "", "Sp6TakeMess_MessengerOut", -1);
            LAi_Actor2WaitDialog(npchar, pchar);
            DialogExit();
		break;
		//=====>>> вестовой захвате в комнате таверны.
 		case "Step_S6_13":
			dialog.text = "Il s'agit de correspondance diplomatique, vous prenez un gros risque...";
			link.l1 = "Je le sais, mais si vous ne me la remettez pas de votre plein gré, je devrai la prendre sur votre cadavre. Choisissez : la vie ou les papiers.";
			link.l1.go = "Step_S6_14";
		break;
 		case "Step_S6_14":
			dialog.text = "La vie et les papiers ! Je ferais peut-être mieux de voir la couleur de votre sang...";
			link.l1 = "Hum, eh bien, comme vous voudrez...";
			link.l1.go = "Step_S6_15";
		break;
		case "Step_S6_15":
			bDisableFastReload = false; // открыть переходы.
			LocatorReloadEnterDisable("Tortuga_tavern", "reload1_back", false);
			LAi_SetPlayerType(pchar);
            LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Спасение Пардаля. Квест №7 **********************************
 		case "Step_S7_1":
			dialog.text = "Alors, je lui dois autant qu'à vous. Très bien, j'aurai l'occasion de le remercier.";
			link.l1 = "Excellent. Bon, je dois retourner à La Havane auprès du gouverneur général. Il faut lui faire rapport de l'heureux dénouement de l'affaire.";
			link.l1.go = "Step_S7_2";
		break;
 		case "Step_S7_2":
			dialog.text = "Je vais sans doute rester dans ces eaux un moment. J'aurai peut-être de la chance...";
			link.l1 = "Je vous souhaite bonne chance, Manoel. Adieu.";
			link.l1.go = "exit";
			pchar.questTemp.State = "Sp7SavePardal_2GoodWork";
		break;
//********************************* Спасение Пардаля. Квест №7 **********************************
 		case "Step_S10_1":
			dialog.text = "Les Anglais !!";
			link.l1 = "Qu'avez-vous dit ?";
			link.l1.go = "Step_S10_2";
		break;
 		case "Step_S10_2":
			dialog.text = "J'ai dit qu'une escadre de pirates anglais se dirige vers la ville ! Bon sang, ça va chauffer ! Ce n'est pas pour rien que nous nous préparions ces derniers temps...";
			link.l1 = "On dirait que j'arrive à point nommé...";
			link.l1.go = "Step_S10_3";
		break;
 		case "Step_S10_3":
			dialog.text = "Quoi ? Ah, laissez-moi passer, "+ GetSexPhrase("señor", "señorita") +", je dois prévenir le gouverneur général...";
			link.l1 = "Entrez, officier.";
			link.l1.go = "Step_S10_4";
		break;
 		case "Step_S10_4":
			pchar.questTemp.State = "Sp10Maracaibo_toGovernor";
			AddQuestRecord("Spa_Line_10_Maracaibo", "2");
			AddQuestUserData("Spa_Line_10_Maracaibo", "sSex", GetSexPhrase("", "e"));
			LocatorReloadEnterDisable("Maracaibo_town", "gate_back", true);
			LocatorReloadEnterDisable("Maracaibo_town", "reload1_back", true);
			LAi_SetPlayerType(pchar);
			LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload3_back", "none", "", "", "", -1);
            DialogExit();
		break;




    }
}
