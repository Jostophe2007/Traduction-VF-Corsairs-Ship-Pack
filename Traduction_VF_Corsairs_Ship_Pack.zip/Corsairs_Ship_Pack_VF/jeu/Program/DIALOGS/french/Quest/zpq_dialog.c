void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je ne veux pas parler.";
			link.l1 = "Hum, je vois...";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "zpq_sld2":
			dialog.text = "Un instant, "+ GetSexPhrase("señor", "señorita") +". Ne seriez-vous pas "+ GetFullName (pchar) +" ?";
			link.l1 = "Oui, c'est bien moi. Que puis-je faire pour vous ?";
			link.l1.go = "zpq_sld2_1";
		break;
		case "zpq_sld2_1":
			dialog.text = "C'est vous qu'il nous faut. Ou plutכt, votre or. Et n'essayez pas de vous obstiner, je ne suis pas d'humeur aujourd'hui : je pourrais me fâcher sans le vouloir.";
			link.l1 = "Pour l'amour du ciel, quel or ? Vous ne pensez tout de même pas que je transporte le trésor sur moi.";
			link.l1.go = "zpq_sld2_2";
		break;
		case "zpq_sld2_2":
			dialog.text = "Ne nous menez pas en bateau. Rendez simplement l'argent que vous venez de recevoir : " + FindRussianMoneyString(sti(pchar.questTemp.zpq.sum)) + ", et passez votre chemin. Sinon, nous le prendrons de force.";
			if (pchar.questTemp.zpq == "failed")
			{
				link.l1 = "Vous ne travailleriez pas pour ce rat de prison, par hasard ? Alors, j'ai de quoi vous réjouir : je l'ai envoyé rejoindre ses ancêtres. Filez donc, avant que je vous fasse subir le même sort.";
				link.l1.go = "zpq_sld2_3_1";
			}
			else
			{
				link.l1 = "Vous ne travailleriez pas pour ce rat de prison, par hasard ? Dites-lui que l'or est en de bonnes mains, et qu'il l'oublie !";
			link.l1.go = "zpq_sld2_3";
			}
			if(makeint(Pchar.money) >= sti(pchar.questTemp.zpq.sum))
			{
				link.l2 = "D'accord, prenez votre sale argent, ordures !";
				link.l2.go = "zpq_sld2_6";
			}
			else
			{
				link.l2 = "Je ne les ai pas...";
				link.l2.go = "zpq_sld2_3";
			}
		break;
		case "zpq_sld2_3":
			dialog.text = "Eh bien, voilà ton destin : mourir à la fleur de l'âge par cupidité, car maintenant, c'est trop dangereux de te laisser en vie.";
			link.l1 = "Quelle assurance.";
			link.l1.go = "zpq_sld2_4";
		break;
		case "zpq_sld2_3_1":
			dialog.text = "Héhé, voilà donc son destin : mourir de cupidité. Mais ça nous arrange : maintenant, on n'aura à partager avec personne.";
			link.l1 = "C'est la cupidité qui vous perdra...";
			link.l1.go = "zpq_sld2_4";
		break;
		case "zpq_sld2_4":
			dialog.text = "Hé, les gars !! Enfilez-lui un sac sur "+ GetSexPhrase("la", "la") +" tête !";
			link.l1 = "Eh bien, tu l'auras voulu...";
			link.l1.go = "zpq_sld2_5";
		break;
		case "zpq_sld2_5":
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetFightMode(PChar, true);

			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			AddQuestRecord("zpq", "7");

			pchar.quest.zpq_seaBattle.win_condition.l1 = "location";
			pchar.quest.zpq_seaBattle.win_condition.l1.location = "Cumana";
			pchar.quest.zpq_seaBattle.function = "zpq_seaBattle";
		break;
		case "zpq_sld2_6":
			dialog.text = "Parfait. Donne-les-moi et dégage, capitaine !";
			link.l1 = "Kof...";
			link.l1.go = "zpq_sld2_7";
			AddMoneyToCharacter(Pchar, -makeint(pchar.questTemp.zpq.sum));
			ChangeCharacterReputation(pchar, -5);
			AddQuestRecord("zpq", "8");
			AddQuestUserData("zpq", "sSex", GetSexPhrase("", "e"));
		break;
		case "zpq_sld2_7":
			DialogExit();
			LAi_LocationFightDisable(loadedLocation, false);
			for(int i = 1; i <= 3; i++)

			{

				sld = CharacterFromID("qp2_" +i);
				LAi_SetImmortal(sld, true);
				LAi_type_actor_Reset(sld);
				LAi_ActorGoToLocation(sld, "reload", "reload1_back", "none", "", "", "", 6.0);
			}
		break;
	}
}





