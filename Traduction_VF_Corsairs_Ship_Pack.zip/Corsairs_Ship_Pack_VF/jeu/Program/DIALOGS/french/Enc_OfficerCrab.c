// BOAL новый диалог офицера и компаньона 21/06/06

void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

	ref    sld;
	string attr, attrLoc;
	int    iTemp, iTax, iFortValue;

	switch(Dialog.CurrentNode)
	{
        case "hired":

			dialog.text = "(Votre fidèle ami vous examine attentivement, attendant un ordre)";
			if (isOfficer(Npchar)) // проверка для кампуса, где слотовые офы
			{
	            Link.l2 = "וcoute mon ordre !";
	            Link.l2.go = "stay_follow";
            }
			Link.l4 = "Il est temps de nous séparer, mon vieux. Retourne à l'océan, auprès des tiens.";
			Link.l4.go = "AsYouWish";

            Link.l9 = "Rien. Repos.";
            Link.l9.go = "exit";
			Diag.TempNode = "hired";
        break;

		case "exit":
			Diag.TempNode = "hired";
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "AsYouWish":
			dialog.text = "(Le crabe tapote pitoyablement le sol de ses pinces.)";
			if (isOfficer(Npchar)) // проверка для кампуса, где слотовые офы
	            Link.l2 = "Désolé, c'est ma décision définitive. Toutes ces aventures en mer sont trop dangereuses pour toi.";
	            Link.l2.go = "exit_fire";
			Link.l4 = "Pardon, j'ai changé d'avis. Je ne sais pas ce qui m'a pris...";
			Link.l4.go = "exit";
			Diag.TempNode = "hired";
        break;

		case "exit_fire":
			//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}
			//navy <--
			Diag.TempNode = "Fired";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");

			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;

			DialogExit();
		break;

        // boal 05.09.03 offecer need to go to abordage -->
        case "stay_follow":
            dialog.text = "(Le crabe émet un cliquetis pour montrer qu'il vous écoute attentivement.)";
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";

		break;

        // boal 05.09.03 offecer need to go to abordage -->
	      case "Boal_Stay":
             //SetCharacterTask_Stay(Characters[Npchar.index]); // it's a mistic but here doesn't work :(
             //Log_SetStringToLog(Npchar.id +" "+Npchar.index);
              Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
              AddDialogExitQuestFunction("LandEnc_OfficerStay");
		      Diag.TempNode = "hired";
		      dialog.text = "(On voit bien qu'il désapprouve votre décision, mais il ne va pas contester l'ordre.)";
		      Link.l1 = "Repos.";
		      Link.l1.go = "Exit";
		      Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
	      break;

	      case "Boal_Follow":
		      SetCharacterTask_FollowCharacter(Npchar, PChar); // it works here!!!
		      Diag.TempNode = "hired";
		      dialog.text = "(Le crabe claque des pinces en signe d'approbation.)";
		      Link.l1 = "Repos.";
		      Link.l1.go = "Exit";
	      break;

		  case "Fired":
		      SetCharacterTask_FollowCharacter(Npchar, PChar); // it works here!!!
			  Diag.TempNode = "Fired";
		      dialog.text = "(Le crabe claque des pinces rageusement derrière vous.)";
		      Link.l1 = "Avec le temps, tu comprendras pourquoi j'ai fait ça.";
		      Link.l1.go = "Exit";
	      break;
        // boal 05.09.03 offecer need to go to abordage <--
		// <-- Самостоятельное плавание компаньона
	}
}
