// LEO: tavern doctor - paid healing of the whole fleet's wounded (summoned from the tavernkeeper dialog: call_doctor -> spawn_tavern_doctor).
// The doctor walks up to the player himself (LAi_ActorDialog). Payment -> flag pchar.Ship.Crew.woundedTavernHeal -> the whole fleet heals on the next day change (food.c).
void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "doctor_greet":
			if (Wounded_FleetTotal(pchar) < 1 || CheckAttribute(pchar, "Ship.Crew.woundedTavernHeal"))
			{
				dialog.text = "On m'a dit que vous aviez des blessés... mais je vois que tout est déjà arrangé. Je ne vous dérangerai donc pas, capitaine.";
				link.l1 = "En effet. Adieu, docteur.";
				link.l1.go = "exit";
			}
			else
			{
				int iDocCost = Wounded_TavernCost(pchar);
				dialog.text = "Le tavernier dit que vous avez des blessés, capitaine. Je suis médecin, je connais mon métier. Pour " + iDocCost + " piastres, je passerai sur vos navires ce soir même : demain matin, vos " + Wounded_FleetTotal(pchar) + " blessés seront de nouveau sur pied. Marché conclu ?";
				if (sti(pchar.money) >= iDocCost)
				{
					link.l1 = "Marché conclu, voici l'argent.";
					link.l1.go = "doctor_deal";
				}
				else
				{
					link.l1 = "Je n'ai pas autant en ce moment...";
					link.l1.go = "exit";
				}
				link.l2 = "Je m'en passerai.";
				link.l2.go = "exit";
			}
		break;

		case "doctor_deal":
			int iDocCost2 = Wounded_TavernCost(pchar);
			AddMoneyToCharacter(pchar, -iDocCost2);
			pchar.Ship.Crew.woundedTavernHeal = "1"; // flag: heal the whole fleet on the next day change
			dialog.text = "Excellent. Je m'occupe de vos hommes ce soir même. Demain matin, ils seront comme neufs. Bon vent, capitaine.";
			link.l1 = "Merci, docteur.";
			link.l1.go = "exit";
		break;
	}
}
