#include "DIALOGS\french\Common_Duel.c"

#define MAX_PGG_STORIES 		12
#define MAX_PGG_QUEST_STORIES 	3
#define MAX_PGG_MEET_REP 		8

#include "DIALOGS\french\PGG\PGG_dlg_data.c"
#include "DIALOGS\french\PGG\PGG_dlg_process.c"
#include "DIALOGS\french\PGG\PGG_dlg_helpers.c"
