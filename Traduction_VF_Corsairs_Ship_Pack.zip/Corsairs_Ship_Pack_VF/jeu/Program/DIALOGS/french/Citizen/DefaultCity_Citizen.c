// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
		break;

		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Que voulez-vous que je vous dise ? Je ne sais pas. Je ne sais rien.";

            link.l1 = "Quel imbécile ! Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

