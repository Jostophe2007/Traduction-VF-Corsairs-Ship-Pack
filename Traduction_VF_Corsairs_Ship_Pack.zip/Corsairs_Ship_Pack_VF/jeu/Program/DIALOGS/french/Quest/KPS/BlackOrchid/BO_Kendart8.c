// Gregg: Alehon Kendart - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je travaille. Repassez plus tard.";
			link.l1 = "Je ne vous dérangerai pas.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Je me suis souvenu. Pendant trente ans, c'est resté dans ma tête, hors de portée, et maintenant, tout est revenu d'un coup, en entier. Asseyez-vous.";
			link.l1 = "Oם avez-vous vu ce symbole ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Sur une voile. J'avais trente ans, j'arrivais tout juste aux Caraïbes, plein d'intentions d'expliquer cet endroit. Notre brigantin faisait route vers Niévès, et un vaisseau de ligne est venu à notre rencontre. Sur sa misaine, il y avait un crâne dans un anneau d'os.";
			link.l1 = "Le même symbole que sur le sablier.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Le même. Ce navire appartenait à Tony Andersen. On l'appelait l'Impitoyable, et pas pour sa prose.";
			link.l1 = "Andersen. Celui qui a canonné La Havane ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Lui-même. Une seule bordée, pour presser les Espagnols de payer la rançon. Notre capitaine a livré bataille, et ce fut la dernière chose qu'il fit. Andersen a fait passer tous les survivants au fil de l'épée.";
			link.l1 = "Tous, sauf vous.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Sauf moi. J'ai cru que c'était grâce à mes lunettes et à ma mine. En fait, il voulait un homme qui sache lire. On m'a amené dans sa cabine et on m'a expliqué que j'allais fabriquer une arme.";
			link.l1 = "Une arme. Le sablier.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "On dirait bien. Et je ne devais pas travailler seul, mais avec un Espagnol du nom de Raul Esperanto. Et voici ce qui compte, capitaine. Je ne comprenais pas un mot de ce qu'il faisait. Il aurait pu le dire à Andersen dès le premier jour.";
			link.l1 = "Mais il ne l'a pas fait.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Non. Pendant six mois, il a fait mon travail à ma place, sans rien dire. Puis il y a eu le brouillard, les Anglais, l'abordage. On m'a emporté sans connaissance.";
			link.l1 = "Et Andersen ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Tué. Raul a été emmené sur le même navire que moi, mais on ne nous laissait pas parler : il était espagnol et prisonnier. Nous avons échangé deux phrases pendant tout le voyage, et je me souviens encore de l'une d'elles.";
			link.l1 = "Laquelle ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Il a dit : si jamais on le retrouve, ne le brise pas. Je ne l'ai pas compris à l'époque. Maintenant, il y a sur ma table une chose qui porte la marque d'Andersen, et je commence à comprendre.";
			link.l1 = "Avez-vous essayé de le briser ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "...(détournant les yeux)... Oui. Il ne se brise pas, ne se démonte pas et ne coule pas. J'ai honte de le dire, j'ai même essayé de le jeter dans la baie. Il est revenu sur ma table.";
			link.l1 = "Revenu ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Je ne veux pas en parler. Il nous faut Raul. C'est le seul homme qui sache tout de ce sablier. Trouvez-le et interrogez-le, ou mieux encore, amenez-le ici.";
			link.l1 = "Oם dois-je chercher ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "א Niévès. On l'a jeté dans la prison de Charlestown dès son débarquement. Je sais que trente ans, c'est trente ans, et que nous ne trouverons très probablement qu'une ligne dans un registre. Mais il n'y a rien d'autre.";
			link.l1 = "א Niévès, donc.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoStart");
		break;

		case "13":
			dialog.text = "...(se lève)... Vivant. Vous l'avez vraiment amené. דa a été long ?";
			link.l1 = "Plus long que je ne l'avais calculé. Mais je n'ai jamais douté qu'il soit en vie.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Et vous aviez raison. Bon, vous me raconterez tout dans l'ordre plus tard, mais pour l'instant...";
			link.l1 = "Attendez. En chemin, j'ai rencontré quelqu'un qui n'aurait pas dמ être là.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Qui donc ?";
			link.l1 = "Il y a un fantכme dans la prison de Charlestown. Joe Newman, un ancien prisonnier. Mort depuis cinquante ans.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Je n'en ai jamais entendu parler. Et ce fantכme ?";
			link.l1 = "Il ne voulait pas parler. J'ai dמ le persuader à la lame.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "...(il se rassoit lentement)... Vous vous êtes battu contre un fantכme. Et vous avez gagné.";
			link.l1 = "דa a été rude, mais oui.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "C'est impossible. Les fantכmes ne meurent pas. C'est ce qui fait d'eux des fantכmes.";
			link.l1 = "Le mien, si. J'ai vérifié.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "...(un long silence)... Très bien. Et ensuite ?";
			link.l1 = "Il m'a parlé de Raul et il a disparu. C'est tout.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Alors, soit on peut tuer les fantכmes, soit ce n'en était pas un. Je préfère la seconde hypothèse, même si elle explique moins de choses.";
			link.l1 = "Le sablier d'abord, les fantכmes ensuite.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Le sablier devra attendre. Raul a besoin de calme : d'abord l'Inquisition, puis une longue traversée qui l'a laissé plus mal en point qu'avant.";
			link.l1 = "Combien de temps ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Six semaines. Et encore une chose, capitaine. Pendant trente ans, j'ai cru que j'étais en vie grâce à mes lunettes. Il s'avère que je suis en vie parce qu'un inconnu a tenu sa langue pendant six mois.";
			link.l1 = "Maintenant, vous savez à qui vous le devez. Je repasserai dans six semaines.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
