// Эдвард Мэнсфилд, глава буканьеров и авторитетный пират, английская линейка
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
            switch (npchar.angry.kind) //сюда расписываем реакцию ангри. В npchar.angry.name пробелы удалены!!!
            {
                case "repeat":
                    if (npchar.angry.name == "Firsttime") Dialog.CurrentNode = "AngryRepeat_1";
                break;
            }
        }
    }
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================
	switch(Dialog.CurrentNode)
	{
		case "First time":
            NextDiag.TempNode = "First time";
            if (CheckAttribute(npchar, "Sp5LaVegaAttackDone"))
            {
            	if (NPChar.quest.meeting == "0")
				{
					dialog.Text = TimeGreeting() + " ! Je suis "+ GetFullName(NPChar) + ", le nouveau vice-roi de ce trou infernal. Malheureusement, il est assez difficile de ramener la canaille locale à l'ordre, mais elle ne menacera plus les colonies espagnoles.";
					Link.l1 = "Bonjour à vous. Je suis le capitaine " + GetFullName(Pchar) + ". Je dois y aller maintenant.";
					Link.l1.go = "exit";
					NPChar.quest.meeting = "1";
				}
				else
				{
					dialog.Text = TimeGreeting() + ". Je suis occupé, j'ai beaucoup à faire. Je dois surveiller l'humeur de la population locale pour mettre fin à la menace qui pèse sur les colonies espagnoles.";
					Link.l1 = "Je ne vous dérangerai pas.";
					Link.l1.go = "exit";
				}
            }
            else
            {
				dialog.text = NPCStringReactionRepeat("Vous avez une affaire pour moi ? Non ? Alors "+ GetSexPhrase("fichez le camp !","ne me distrayez pas, je vous prie.") +"",
	                         "Je crois avoir été clair...", "J'ai pourtant été clair, mais vous continuez à me distraire !",
	                         "Hum, vous êtes un peu "+ GetSexPhrase("insolent, mon cher","effrontée, ma fille") +"...", "repeat", 3, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Je m'en vais déjà.",
	                                               "Oui, " + npchar.name + ", c'est parfaitement clair.",
	                                               "Désolé, " + npchar.name + "...",
	                                               "Aïe, aïe...", npchar, Dialog.CurrentNode);
				link.l1.go = "exit";
			}


					if(!CheckAttribute(PChar, "questTemp.pirateStartQuest"))
					{
						link.l2 = "Pourriez-vous me trouver du travail ?";
						link.l2.go = "pirateStartQuest";
					}
					else
					{
						if(pchar.questTemp.pirateStartQuest == "3" && !CheckAttribute(PChar, "questTemp.pirateStartQuest.many") && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Je suis sur la piste, mais il me faut de l'argent : 30 000 piastres pour faire sortir le rat de son trou.";
							link.l2.go = "pirateStartQuest_many";
						}
						if(pchar.questTemp.pirateStartQuest == "3" && GetCharacterItem(pchar, "letter_open") > 0 && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Regardez quelle lettre j'ai trouvée sur le cadavre d'un des contrebandiers.";
							link.l2.go = "pirateStartQuest_info_1";
						}
						if(pchar.questTemp.pirateStartQuest == "5" && npchar.city == pchar.questTemp.pirateStartQuest.City)
						{
							link.l2 = "Le travail est fait. Norman Vigo et sa baille sont partis chez le diable des mers.";
							link.l2.go = "pirateStartQuest_final";
						}
					}
					if(sti(pchar.rank) >= 10 && !CheckAttribute(PChar, "questTemp.pirateVikingQuest"))
					{
						link.l3 = "Avez-vous une affaire intéressante pour moi ?";
						link.l3.go = "pirateVikingQuest";
					}
					else
					{
						if(pchar.questTemp.pirateVikingQuest == "7" && npchar.city == pchar.questTemp.pirateVikingQuest.City)
						{
							dialog.text = "Je vois que vous avez des nouvelles ?"
							link.l1 = "Oui, j'ai tué ce Viking, et il était féroce, croyez-moi. D'habitude, quand ils sentent la mort, ils se mettent tous à parlementer, mais celui-là grognait, l'écume aux lèvres.";
							link.l1.go = "pirateVikingQuest_final";
						}
					}
		break;

 		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		//Blackthorn. Квест викинга
		case "pirateVikingQuest":
			dialog.text = "J'ai un travail pour vous. Il paraît que vous ne vous êtes pas seulement servi de votre épée, mais aussi de votre tête. וcoutez. Il y a quelques années, un Scandinave est apparu dans nos eaux, un Danois ou un Suédois, peu importe ; il se fait appeler Ragnar. Son navire est un vrai spectacle, et l'équipage n'est composé que de Normands. Et tout semble bien aller : il pirate un peu, gagne son pain, mais il ne verse pas sa part au pot commun, il est grossier avec les gouverneurs, et il revend ses prises on ne sait oם. Vous comprenez de quoi il est question ?";
			link.l1 = "Je comprends, il faut le punir pour en faire un exemple. Seulement, ce n'est pas conforme aux lois des Frères de la Cכte. Bon, ce pirate est allé trop loin, alors qu'on souffle aux autorités oם il se terre. Et personne n'aura rien à nous reprocher, à nous, honnêtes corsaires.";
			link.l1.go = "pirateVikingQuest_1";
			link.l2 = "Cette conversation ne me plaît pas. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateVikingQuest = "0";
		break;
		case "pirateVikingQuest_1":
			dialog.text = "Les lois des Frères, le Code, l'honneur pirate... Pff... Ce sont des enfantillages. Rappelez-vous aussi la Libertalia que Sharp a essayé de bâtir. Ha ha ! Ici, nous avons un équilibre des forces : les autorités ferment les yeux sur nos affaires, tant que nous ne gênons pas les leurs. Et si la paix est signée en Europe ? Alors les lettres de marque seront révoquées, et tous les braves corsaires deviendront des criminels en un instant. Et les escadres punitives arriveront. Pour nous attraper, vous et moi. Et des capitaines comme ce Viking ternissent la réputation de nous tous. Vous saisissez ?";
			link.l1 = "Je comprends, vous m'avez donné matière à réflexion. Oם puis-je trouver ce Viking ?";
			link.l1.go = "pirateVikingQuest_2";
		break;
		case "pirateVikingQuest_2":
			dialog.text = "Quelque part. Si je savais oם il se terre, j'irais moi-même en mer, malgré mes vieilles blessures et mon âge. Vous êtes quelqu'un de futé, vous trouverez bien. Une seule condition : ce Ragnar et tout son équipage doivent finir en nourriture pour les poissons, et je saurai me montrer généreux en or.";
			link.l1 = "Attendez les nouvelles. Et pour la révocation des lettres de marque, s'il y a du nouveau, prévenez-moi. א l'occasion, " + GetFullName(npchar)+".";
			link.l1.go = "exit";

			pchar.questTemp.pirateVikingQuest = "1";
			pchar.questTemp.pirateVikingQuest.City = npchar.city;
			pchar.questTemp.pirateVikingQuest.Areal = GetArealByCityName(pchar.questTemp.pirateVikingQuest.City);
			pchar.questTemp.pirateVikingQuest.Name = GetFullName(npchar);
			pchar.LastHearedViking = npchar.city;
			AddQuestRecord("pirateVikingQuest", "1");
			AddQuestUserData("pirateVikingQuest", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateVikingQuest.City + "Gen"));
			AddQuestUserData("pirateVikingQuest", "sName", pchar.questTemp.pirateVikingQuest.Name);
		break;
		case "pirateVikingQuest_final":
			CloseQuestHeader("pirateVikingQuest");
			pchar.questdata.OskolokProshlogo = 1;
			TakeNItems(pchar, "chest", 3);
			Log_Info("Vous avez reçu les coffres de crédit");
			dialog.text = "Oui, j'en ai entendu parler une fois. Un vrai berserker. Comme un vestige du passé. Tenez, prenez la récompense, vous l'avez méritée.";
			pchar.questTemp.pirateVikingQuest = "end";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//zagolski. начальный квест за пирата ===================================
		case "pirateStartQuest":
			dialog.text = "Hum... du travail, dites-vous ? C'est même très bien que vous soyez venu me voir. Il me faut justement quelqu'un d'extérieur. Je dois me renseigner sur quelque chose dans la colonie voisine, et mes gars y sont connus comme le loup blanc. Je ne promets pas beaucoup d'argent, mais il y aura bien quelque chose à gratter.";
			link.l1 = "Voilà qui est bien. De quoi s'agit-il ?";
			link.l1.go = "pirateStartQuest_1";
			link.l2 = "Désolé, je ne vais pas risquer un sou. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateStartQuest = "0";
		break;
		case "pirateStartQuest_1":
			dialog.text = "Voici l'affaire : il y a environ un mois, je me suis entendu avec le capitaine de la goélette Sentblue pour qu'il livre 200 esclaves, à revendre à un planteur de la colonie voisine. Les délais sont déjà serrés, le client s'impatiente, et hier on m'a informé qu'on avait vu cette goélette dans les eaux de l'île. Mais !.. Le capitaine ne s'est pas présenté. Et aujourd'hui, le planteur a exigé le remboursement de son acompte, en disant qu'on lui avait proposé les esclaves ailleurs : plus cher, certes, mais tout le lot d'un coup.";
			link.l1 = "Et alors ? Je dois vous trouver 200 esclaves en quelques jours, pour que vous ne perdiez pas l'acompte ? Et tout ça pour trois sous ?";
			link.l1.go = "pirateStartQuest_2";
		break;
		case "pirateStartQuest_2":
			dialog.text = "Non, bien sמr que non. J'ai l'air d'un idiot ? Je ne rembourserai l'acompte en aucun cas. Mais il me faut la preuve que les esclaves qu'on lui propose sont bien mon lot. Vous n'aurez qu'à trouver ceux qui lui ont proposé ce nouveau marché, et vous toucherez vos 10 000 piastres. Le reste, c'est mon affaire. Alors, vous êtes prêt ?";
			link.l1 = "J'accepte ! Et qui ça pourrait être ? Vous avez une idée ?";
			link.l1.go = "pirateStartQuest_3";
			link.l2 = "Non. On ne sait pas qui chercher, on ne sait pas oם, et pour seulement 10 000, désolé, je refuse.";
			link.l2.go = "exit";
		break;
		case "pirateStartQuest_3":
			dialog.text = "Si j'avais le moindre indice, je me serais passé de vos services. Ils serviraient déjà d'appât à calmars avant la nuit. Mais ce qui m'intéresse surtout, c'est autre chose : comment ont-ils appris l'existence de la cargaison du Sentblue et de mon client ? Tout s'est arrangé très vite pour eux. Vous saisissez ?";
			link.l1 = "Oui, c'est clair, quelqu'un vend des informations.";
			link.l1.go = "pirateStartQuest_4";

			pchar.questTemp.pirateStartQuest = "1";
			pchar.questTemp.pirateStartQuest.City = npchar.city;
			pchar.questTemp.pirateStartQuest.Areal = GetArealByCityName(pchar.questTemp.pirateStartQuest.City);
			pchar.questTemp.pirateStartQuest.Name = GetFullName(npchar);

			AddQuestRecord("pSQ", "1");
			AddQuestUserData("pSQ", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City + "Gen"));
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);
		break;
		case "pirateStartQuest_4":
			dialog.text = "Voilà ! C'est lui que je cherche. Donc, éliminer discrètement les concurrents et récupérer les esclaves, ce n'est pas le principal dans cette affaire. Il me faut l'informateur, ou plutכt, sa tête au bout d'une pique. Vous comprenez maintenant pourquoi aucun de mes hommes ne doit être au courant de cette mission ? Tant que je ne saurai pas qui vend les informations, je soupçonnerai tout le monde. Et je n'en ai vraiment pas envie...";
			link.l1 = "Compris... Donc, on agit discrètement et sans faire de vagues. Je pars à sa recherche.";
			link.l1.go = "exit";
		break;

		case "pirateStartQuest_many":
			dialog.text = "Trente mille, dites-vous ? C'est beaucoup d'argent... Je ne peux vous donner que 5 000 piastres, je n'en ai pas plus en ce moment. Mais si vous décidez de filer avec, je vous retrouverai et je vous pendrai à la première palissade venue ! Ce genre de plaisanterie ne marche pas avec moi.";
			link.l1 = "Donnez-moi les cinq mille...";
			link.l1.go = "pirateStartQuest_many_1";
		break;
		case "pirateStartQuest_many_1":
			dialog.text = "Tenez. J'attends les résultats de vos recherches.";
			link.l1 = "Tout ira bien.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 5000);
			pchar.questTemp.pirateStartQuest.many = "";
		break;

		//------------------------------------
		case "pirateStartQuest_info_1":
			dialog.text = "Ha ! Excellente nouvelle ! J'étais sמr que vous y arriveriez. J'ai obtenu des informations très intéressantes.";
			link.l1 = "J'ai fait mon travail. Je veux mes dix mille.";
			link.l1.go = "pirateStartQuest_info_2";
			TakeItemFromCharacter(pchar, "letter_open");
		break;
		case "pirateStartQuest_info_2":
			dialog.text = "Bien sמr, voici la récompense promise. Mais ne vous pressez pas, je veux vous confier une autre affaire. Pfiefer est un homme de l'équipage de Norman Vigo, qui navigue sur le cotre Normandy. Je suis sמr que Norman Vigo est l'informateur, même s'il est des nכtres. On l'a vu récemment dans les eaux de l'île : votre mission est d'envoyer ce rat au diable des mers. La première fois, vous ne m'avez pas déçu, alors je veux maintenant vous confier cette affaire. Je paierai 15 000 piastres. D'accord ?";
			link.l1 = "J'accepte ! Considérez que ce traître de Norman Vigo est déjà mort.";
			link.l1.go = "pirateStartQuest_info_3";
			link.l2 = "Vous savez quoi, je ne veux pas me mêler de ça... Et je n'ai pas le temps. Désolé, mais je passe mon tour.";
			link.l2.go = "pirateStartQuest_info_noex";
			AddMoneyToCharacter(pchar, 10000);
		break;
		case "pirateStartQuest_info_noex":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
		break;
		case "pirateStartQuest_info_3":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "4";

			AddQuestRecord("pSQ", "7");
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);

			pchar.quest.zpq_seaBattle.win_condition.l1 = "location";
			pchar.quest.zpq_seaBattle.win_condition.l1.location = pchar.questTemp.pirateStartQuest.Areal;
			pchar.quest.zpq_seaBattle.function = "pirateStartQuest_seaBattle";
		break;

		case "pirateStartQuest_final":
			dialog.text = "On sait, on sait. Mes hommes ont assisté au combat et m'ont déjà rapporté avec quel brio vous vous en êtes tiré. Eh bien, vous avez fait votre travail comme il faut, voici la récompense promise de 15 000 piastres. Et merci, vous m'avez beaucoup aidé.";
			link.l1 = "Tout va bien, ça me fait plaisir d'aider ! Et maintenant, j'ai à faire, je me suis déjà attardé ici. א plus tard !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 15000);
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
			group_DeleteGroup("pirateStartQuest_Smuggler_group");
		break;

		//********************* Английская линейка *********************
 		case "EngLine_quests":
			dialog.text = "Je vous écoute, capitaine.";
			link.l1 = "Je viens vous voir de la part du gouverneur général de la Jamaïque, sir Thomas Madiford.";
			link.l1.go = "Step_1";
  		break;
 		case "Step_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Sir Thomas Madiford vous demande de réunir une escadre de corsaires, d'en prendre la tête et d'attaquer l'avant-poste hollandais des Caraïbes : la ville de Curaçao.";
			link.l1.go = "Step_2";
  		break;
 		case "Step_2":
			dialog.text = "Hum... Et quelle est la raison de cette décision ? J'avoue que cela paraît étrange. Les Anglais n'attaquent pas les Hollandais. Certes, les deux וtats ont des différends dans leur expansion commerciale, mais ils concernent l'océan Indien. Ici, c'est le Nouveau Monde.";
			link.l1 = "Monsieur, une nouvelle guerre commerciale a éclaté entre l'Angleterre et la Hollande. De plus, la marine anglaise a attaqué les Hollandais au large des cכtes d'Europe, mais elle a été repoussée.";
			link.l1.go = "Step_3";
  		break;
 		case "Step_3":
			dialog.text = "Compris. Merci pour l'information. Je n'étais pas au courant.";
			link.l1 = "J'attends donc votre accord pour l'expédition.";
			link.l1.go = "Step_4";
  		break;
 		case "Step_4":
			dialog.text = ""+ GetSexPhrase("Mon ami, je","Je") +" ne peux pas donner de réponse favorable à la demande du gouverneur général de la Jamaïque.";
			link.l1 = "Voilà une réponse qui me paraît bien étrange.";
			link.l1.go = "Step_5";
  		break;
 		case "Step_5":
			dialog.text = "Rien d'étrange. Mon vrai nom est Edward Mansvelt. Je suis hollandais.";
			link.l1 = "Mais vous êtes un corsaire anglais, et vous jouissez de la protection de sir Thomas Madiford. Il me paraît déraisonnable de refuser sa demande aussi catégoriquement.";
			link.l1.go = "Step_6";
  		break;
 		case "Step_6":
			dialog.text = "Il peut vous paraître bien des choses. J'ai bien une lettre de marque anglaise, mais cela ne veut pas dire que je vais égorger mes compatriotes. Le choix de mes actes m'appartient toujours. Je vous ai répondu, je n'ai rien à ajouter. Adieu.";
			link.l1 = "Eh bien, si vous n'avez rien à ajouter, adieu.";
			link.l1.go = "exit";
            NextDiag.TempNode = "First time";
            AddQuestRecord("Eng_Line_2_Talking", "3");

            pchar.questTemp.Count = makeint(sti(pchar.questTemp.Count) + 1);
            if (pchar.questTemp.Count == "4")
			{
				pchar.questTemp.State = "after_talks_with_pirates";
			}
  		break;
 		case "No_Mansfield_first_time":
			dialog.text = "Bonjour, je m'appelle Alistair Goode. Après la mort de Mansfield, j'ai été choisi pour mener les boucaniers.";
			link.l1 = "Faisons connaissance, Alistair.";
			link.l1.go = "exit";
			NextDiag.TempNode = "No_Mansfield";
  		break;
 		case "No_Mansfield":
			dialog.text = "Je n'ai pas le temps de vous parler pour l'instant. Revenez plus tard.";
			link.l1 = "Je m'en vais déjà.";
			link.l1.go = "exit";
  		break;
		//********************* Голландская линейка *********************
  		case "HolLine3_WormEngPlans":
			dialog.text = "Qu'est-ce qui vous amène ?";
			link.l1 = "Je viens vous voir de la part du gouverneur général de Curaçao, Peter Stuyvesant.";
			link.l1.go = "Step_H3_1";
        break;
 		case "Step_H3_1":
			dialog.text = "Très bien. Que me veut le gouverneur général Stuyvesant ?";
			link.l1 = "Edward, les Anglais ont attaqué les Pays-Bas, une nouvelle guerre commerciale a commencé.";
			link.l1.go = "Step_H3_2";
  		break;
 		case "Step_H3_2":
			dialog.text = "Triste nouvelle, j'ai des affaires à Port Royal...";
			link.l1 = "Voici le pli de Stuyvesant, veuillez le lire.";
			link.l1.go = "Step_H3_3";
  		break;
 		case "Step_H3_3":
			dialog.text = "Voyons voir... Hum, il me demande de l'informer de ce que Madiford compte faire dans les Caraïbes dans le cadre de cette guerre.";
			link.l1 = "C'est exact. Le savoir est d'une nécessité vitale pour les colonies hollandaises.";
			link.l1.go = "Step_H3_4";
            TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
  		break;
 		case "Step_H3_4":
			dialog.text = "Le fait est que je ne sais rien des plans de Madiford pour cette guerre. J'ai d'autres affaires avec lui, la politique n'a rien à y voir.";
			link.l1 = "Et que dois-je dire à Stuyvesant ? Que vous ne savez rien et que vous ne pouvez pas aider votre patrie à l'heure de l'épreuve ?";
			link.l1.go = "Step_H3_5";
  		break;
 		case "Step_H3_5":
			dialog.text = "Pas besoin de grandes phrases, "+ GetSexPhrase("jeune homme","ma fille") +", je sais qui je suis. Mais je ne sais vraiment rien des plans de Madiford. Cependant, voici ce que je vais vous dire. "+
                          "Pas plus tard que la semaine dernière, un certain messager de Madiford est venu me voir et a essayé de me convaincre d'organiser une expédition contre Curaçao. Naturellement, j'ai refusé. Morgan, Jackman et John Morris ont refusé aussi. "+
                          "Il se trouve que le fameux coquin Thomas Madiford a tenté d'ouvrir les hostilités contre les Pays-Bas avec l'aide des pirates. Un rusé, que dire de plus...";
			link.l1 = "Il se trouve donc que Madiford projette d'attaquer Curaçao ?";
			link.l1.go = "Step_H3_6";
  		break;
 		case "Step_H3_6":
			dialog.text = "Il peut projeter une attaque contre Curaçao, mais il est peu probable qu'il la mène à bien. Il n'a pas assez de forces pour une telle opération : ce n'est pas par plaisir qu'il cherchait à attirer des corsaires. "+
                          "Et d'ailleurs, la protection la plus sמre de Port Royal contre ces mêmes Espagnols, c'est la présence constante d'un certain nombre de pirates en rade de la Jamaïque. Donc non, Curaçao est un trop gros morceau pour lui en ce moment.";
			link.l1 = "Eh bien, tout est clair, il n'y a pas à craindre d'attaque...";
			link.l1.go = "Step_H3_7";
  		break;
 		case "Step_H3_7":
			dialog.text = "Je ne serais pas aussi catégorique. Le fait est que, puisqu'il y a eu une tentative d'attirer des corsaires pour cette attaque, c'est que Madiford a bel et bien l'ordre d'ouvrir les hostilités. Il n'y aura donc certainement pas de paix ici entre l'Angleterre et la Hollande. "+
                          "Voici ce que je vous propose : rendez-vous immédiatement à Port Royal, chez Henry Morgan.";
			link.l1 = "Chez Henry Morgan, l'amiral des corsaires ?";
			link.l1.go = "Step_H3_8";
  		break;
 		case "Step_H3_8":
			dialog.text = "Oui, c'est cela. Et ne vous inquiétez pas, il n'est pas devenu amiral sans moi. Pour être précis, c'est moi qui lui ai donné ce titre. Demandez-lui de vous aider de ma part.";
			link.l1 = "Et ça marchera ?";
			link.l1.go = "Step_H3_9";
  		break;
 		case "Step_H3_9":
			dialog.text = "S'il peut aider, il le fera.";
			link.l1 = "Edward, pourriez-vous m'écrire une lettre pour Morgan, afin qu'il croie mes paroles ?";
			link.l1.go = "Step_H3_10";
  		break;
 		case "Step_H3_10":
			dialog.text = "Non, ce n'est pas nécessaire. Il est peu probable que quelqu'un de sensé essaie de tromper Morgan : un tel homme ne vivrait pas longtemps. Il vous croira.";
			link.l1 = "Edward Mansveld, vous êtes un vrai fils de votre patrie. Merci pour votre aide !";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
    		pchar.questTemp.State = "WormEnglPlans_toMorgan";
    		AddQuestRecord("Hol_Line_3_WormEnglishPlans", "2");
    		QuestSetCurrentNode("Henry Morgan", "HolLine3_fromMansfield");
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "SentJons_HouseF3", "goto", "goto1");
            LAi_SetHuberStayType(characterFromId("Henry Morgan"));
          break;


// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		case "AngryRepeat_1":
            dialog.text = RandPhraseSimple(""+ GetSexPhrase("Fichez","Fichez") +" le camp d'ici !", "Sortez de chez moi !");
			link.l1 = "Oh oh oh...";
		    link.l1.go = "AngryExitAgainWithOut";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся с Мэнсфилдом через 30 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Vous ne devriez pas me déranger, souvenez-vous-en.";
        			link.l1 = "Compris, Edward, je ne le ferai plus.";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
            }
    	break;
		case "AngryExitAgain":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
		break;
		case "AngryExitAgainWithOut":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
            DoReloadCharacterToLocation("LaVega_town","reload","reload6");
		break;
// <<<<<<<<<<<<============= блок нод angry =============================
	}
}
