// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.MC == "toMaracaibo")
			{
				link.l1 = "Je voudrais savoir quelque chose.";
				link.l1.go = "MCTavernMar";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_ONV_Maracaibo"))	//Квест "Witch Hunt"
            {
                link.l1 = "Le nom de Maria Carle vous dit-il quelque chose ?";
                link.l1.go = "PDM_ONV_MB_1";
            }
		break;
		//зачарованный город
		case "MCTavernMar":
			dialog.text = "Qu'est-ce qui vous intéresse exactement ?";
			link.l1 = "On dit que Maracaibo est frappée d'une sorte de malédiction. Que s'est-il passé ici ?";
			link.l1.go = "MCTavernMar_1";
		break;
		case "MCTavernMar_1":
			dialog.text = "Maracaibo ? Comme vous le voyez, tout va bien chez nous. Il y a bien Des Moines, mais c'est un trou si perdu qu'il ne s'y passe jamais rien. C'est étrange, pourtant : d'habitude, j'ai deux ou trois pêcheurs de là-bas dans ma taverne, mais personne ne s'est montré ici depuis longtemps.";
			link.l1 = "Eh bien, ce n'est pas beaucoup d'informations, mais merci quand même.";
			link.l1.go = "exit";
			pchar.questTemp.MC = "toDesMoines";
		break;
		//Квест ***Охота на ведьму***
		case "PDM_ONV_MB_1":
			dialog.text = "Ce nom ne me dit rien. Mais vous avez de la chance : cet homme, à la table, a prononcé ce nom plus d'une fois en avalant son rhum avec une rage folle.";
			link.l1 = "Vous m'avez bien aidé. Merci !";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_Maracaibo");
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld = CharacterFromID("PDM_ONV_Viktor_Martos");
				sld.quest.questflag.model = "questionmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

