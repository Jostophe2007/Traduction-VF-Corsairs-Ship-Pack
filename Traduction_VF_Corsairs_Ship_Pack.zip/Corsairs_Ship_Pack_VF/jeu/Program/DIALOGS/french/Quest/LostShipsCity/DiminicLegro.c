#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Félicitations au nouveau venu, et juste à temps. Je suis " + GetFullName(npchar) + ", ici, on m'appelle aussi le Veinard.";
					link.l1 = "Eh bien, bonjour, " + npchar.name + ". Je m'appelle " + GetFullName(pchar) + ", faisons connaissance. Que veut dire « juste à temps » ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Félicitations au nouveau venu. Je suis " + GetFullName(npchar) + ", ici, on m'appelle aussi le Veinard.";
					link.l1 = "Eh bien, bonjour, " + npchar.name + ". Je m'appelle " + GetFullName(pchar) + ", faisons connaissance.";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				//квест отнести бутылочку вина тюремщику. дача квеста
				if (!CheckActiveQuest("TakeVineToPrisoner") && !CheckAttribute(pchar, "questTemp.LSC.LegroHelp"))
				{
					dialog.text = "Hé, "+ GetSexPhrase("l'ami", "ma petite") +"J'ai une affaire avec vous.";
					link.l1 = "Crache le morceau.";
					link.l1.go = "GiveVineBottle";
					break;
				}
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//квест доставки вина тюремщику. после разговора с Бойлом
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "toFackDominic")
				{
					link.l7 = "Tu sais, je vais apporter une bouteille de vin à Thomas Boyle.";
					link.l7.go = "FackDominic";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "toArmoDominic")
				{
					link.l7 = "L'ami, tu ne flirtais pas avec Armo Dulin l'autre jour ?";
					link.l7.go = "ArmoDominic";
				}
				if (CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "toKeyDominic")
				{
					link.l7 = "Bon, j'ai tout arrangé avec Thomas Boyle.";
					link.l7.go = "KeyDominic";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de venir avec moi.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "La tempête se calme, et tous les veinards sortent de l'eau en rampant.";
			link.l1 = "Compris. Eh bien, tu en fais partie, toi aussi !";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "C'est vrai, mais moi, je suis un veinard absolu. Le fait est que mon navire s'est fracassé au plus fort de la tempête !";
			link.l1 = "דa alors, ça alors ! Raconte, je t'en prie.";
			link.l1.go = "FT_3";
		break;
		case "FT_1":
			dialog.text = "Eh bien, c'est très agréable.";
			link.l1 = "Pourquoi t'appelle-t-on le Veinard ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Les raisons ne manquent pas. J'ai réchappé d'un naufrage, comme la plupart des gens d'ici, mais mon naufrage était spécial...";
			link.l1 = "Et qu'avait-il de spécial, ton naufrage ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Ha, c'était un sacré naufrage, bon sang ! La foudre a frappé notre frégate, un incendie s'est déclaré instantanément, puis le feu, je ne sais comment, a très vite gagné la sainte-barbe\n"+
				"Imagine un peu ! En quelques minutes, le navire s'est transformé en un tas de débris en flammes, et moi, je n'ai même pas été brמlé ! Plus encore, je n'étais pas loin de la cale au moment du désastre, et je ne suis pas du tout arrivé les mains vides dans la Cité : j'avais des bijoux, de l'argent, des objets rares...";
			link.l1 = "Et l'amiral a tout confisqué ?";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "L'amiral est un salaud cupide extrêmement malin, mais moi, je peux rouler n'importe quelle crapule. On m'avait prévenu à l'avance de la rencontre avec Capper, et j'ai réussi à prendre des mesures, pour ainsi dire. Même si, pourquoi j'ai apporté ces babioles ici, je ne le comprends pas moi-même...";
			link.l1 = "Hum... écoute, quelles mesures as-tu prises ? דa m'intéresse beaucoup...";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "Je ne le dirai pas, "+ GetSexPhrase("l'ami", "ma petite") +" ! Désolé. Mon bonheur n'appartient qu'à moi, j'ai peur de le perdre. Je suis superstitieux.";
			link.l1 = "Oui, ça, c'est sמr. Que fais-tu ici ?";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Rien ! Il n'y a pas de retour possible, alors je ne veux pas le chercher. Je vis au jour le jour... et j'adore ça, bon sang !";
			link.l1 = "Eh bien, c'est aussi une façon de voir. Merci pour la conversation... écoute, tu changeras peut-être d'avis et tu me parleras de ces mesures ?";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "Désolé, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", c'est absolument impossible. Je peux seulement te laisser entendre qu'il faut tout mettre quelque part avant de rencontrer Chad... C'est tout.";
			link.l1 = "Compris... Eh bien, merci quand même.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveux...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Je comprends que les tempêtes sont fréquentes ici.";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Est-ce possible, ici ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Comment règle-t-on les problèmes personnels dans la Cité ? Les gens sont-ils si respectueux de la loi qu'ils ne se battent pas et ne s'entretuent pas ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Y a-t-il une chance de partir en bateau... quelque part ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l5 = "וcoute, tu es ici depuis longtemps ?";
				link.l5.go = "ansewer_5";
			}
			link.l10 = "Pas de questions. Désolé, l'ami...";
			link.l10.go = "exit";
		break;
		case "ansewer_4":
			dialog.text = "Oui, je ne dirais pas ça. C'est simplement que, quelle que soit la tempête, c'est un véritable enfer ! Tout grince et tout tangue... C'est un peu effrayant, en somme.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_1":
			dialog.text = "On peut faire tout ce qui n'est pas interdit par la Loi. Peut-être... Sois simplement prudent.";
			link.l1 = "J'en tiendrai compte.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Tout arrive, bien sמr. Chad et sa milice peuvent calmer n'importe qui. On annonce simplement que le citoyen est devenu fou, et c'est tout.";
			link.l1 = "Pas mal... דa fait vraiment perdre la tête aux gens ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "דa arrive...";
			link.l1 = "Compris. Et comment les autres s'arrangent-ils entre eux ?";
			link.l1.go = "ansewer_2_2";
		break;
		case "ansewer_2_2":
			dialog.text = "En douce. Parfois, certains disparaissent sans laisser de trace, on accuse les clans... Bref, pas vu, pas pris.";
			link.l1 = "Ah ah, je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Bien sמr"+ GetSexPhrase(", l'ami", "") +" ! Droit en enfer !";
			link.l1 = "Merci.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_5":
			dialog.text = "Eh bien, c'est vite dit. Pour certains, un an ici, c'est une éternité...";
			link.l1 = "Alors tu vis ici depuis un an ?";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Non, plus. Je parlais de l'année au sens figuré.";
			link.l1 = "Compris. Hill Brunner était-il déjà là ?";
			link.l1.go = "ansewer_5_2";
		break;
		case "ansewer_5_2":
			dialog.text = "Oui. C'est dommage pour Hill, c'était un bon tavernier. Quoi qu'on vienne lui demander, il avait tout en stock. Oh, c'est dommage...";
			link.l1 = "Bon, porte-toi bien.";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Quel genre de marchandises ?",
				"Vous m'avez déjà posé la question.",
				"Tu l'as déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de boulets, de bombes, de boulets ramés, de vivres, de médicaments, de poudre, d'armes...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Bon, les boulets, on peut les demander aux maîtresses de maison. Elles ont beaucoup de marchandises de ce genre qui traînent. Pour les médicaments, je te conseille de t'adresser à notre saint père. Mais les armes et la poudre, c'est l'affaire de l'amiral...";
			link.l1 = "Comment ça ?";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Eh bien, il rassemble les armes et la poudre de tous les navires. Alors c'est lui qui a toutes les réserves.";
			link.l1 = "Je comprends, merci.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Hum... Tu m'as sidéré, quand même...";
			link.l1 = "Je comprends. Mais décide-toi vite. Si tu acceptes, il faut te rendre sur mon navire tout de suite.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Tout de suite ?";
			link.l1 = "Oui. Une tempête approche de la Cité, qui va très probablement détruire l'île. Il faut se dépêcher.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Hé, j'ai encore de la chance ! J'accepte.";
			link.l1 = "Parfait. Maintenant, va sur le San Gabriel, oם le Mécanicien organisera ton transfert sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord. Je passe juste prendre mes affaires.";
			link.l1 = "Ne soyez pas en retard.";
			link.l1.go = "SeekCrew_all";
		break;
		//отнести бутылку вина тюремщику
		case "GiveVineBottle":
			dialog.text = "J'ai un ami, Thomas Boyle, un geכlier. Il passe toute la journée sur ce maudit Tartarus, comme s'il était lui-même derrière les barreaux. Je veux lui faire plaisir.";
			link.l1 = "Parfait. Comment puis-je t'aider ?";
			link.l1.go = "GiveVineBottle_1";
		break;
		case "GiveVineBottle_1":
			dialog.text = "וcoute, trouve une bouteille de vin quelque part et apporte-la-lui de ma part. Thomas sera surpris !";
			link.l1 = "L'ami, tu es fou ? Tu me prends pour quoi, "+ GetSexPhrase("garçon", "fille") +"de courses ?";
			link.l1.go = "GiveVineBottle_not";
			link.l2 = "D'accord, je vais le faire.";
			link.l2.go = "GiveVineBottle_2";
		break;
		case "GiveVineBottle_not":
			dialog.text = "Ne t'énerve pas comme ça. Si tu ne veux pas, ne le fais pas...";
			link.l1 = "Ne m'embête plus désormais avec des propositions aussi idiotes !";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "over";
			CloseQuestHeader("TakeVineToPrisoner");
		break;
		case "GiveVineBottle_2":
			dialog.text = "Eh bien, merci, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Thomas va être si content !..";
			link.l1 = "Je l'espère.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "toTomasBoil";
			AddQuestRecord("TakeVineToPrisoner", "1");
		break;

		case "FackDominic":
			dialog.text = "Formidable ! J'imagine comme il était content...";
			link.l1 = "Le vin lui a plu, mais il m'a demandé de te dire qu'il te couperait les oreilles à la première occasion. Il te les coupera.";
			link.l1.go = "FackDominic_1";
		break;
		case "FackDominic_1":
			dialog.text = "א moi ? Pourquoi ?!!";
			link.l1 = "Je n'en ai aucune idée. Mais il est très en colère contre toi.";
			link.l1.go = "FackDominic_2";
		break;
		case "FackDominic_2":
			dialog.text = "דa alors ! וcoute, va le voir encore une fois, je t'en prie. Découvre ce qui s'est passé !";
			link.l1 = "Va le découvrir toi-même.";
			link.l1.go = "FackDominic_3";
		break;
		case "FackDominic_3":
			dialog.text = "Bon sang, j'ai peur. Je pense qu'il va d'abord me passer un savon, et ensuite seulement, il cherchera à comprendre. Va lui demander ce qui se passe, je t'en supplie !";
			link.l1 = "D'accord, soit, je vais lui demander.";
			link.l1.go = "FackDominic_4";
			link.l2 = "Au diable ! Tu me prends pour quoi, "+ GetSexPhrase("garçon", "fille") +"de courses ?";
			link.l2.go = "GiveVineBottle_not";
		break;
		case "FackDominic_4":
			dialog.text = "Merci, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +" ! Je jure que je n'ai absolument aucune idée de ce qui se passe.";
			link.l1 = "Je te crois.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "toSecondToPrison";
			AddQuestRecord("TakeVineToPrisoner", "3");
		break;

		case "ArmoDominic":
			dialog.text = "Bon, je lui ai parlé l'autre jour. Pas question de flirt ! Comme si je ne savais pas de qui elle est la dulcinée.";
			link.l1 = "De qui est-elle la dulcinée ?";
			link.l1.go = "ArmoDominic_1";
		break;
		case "ArmoDominic_1":
			dialog.text = "De Thomas Boyle, bien sמr. Je ne suis pas assez idiot pour tourner autour de sa bonne amie sous le nez de mon ami !";
			link.l1 = "Je suppose que non. Ce serait manifestement exagéré...";
			link.l1.go = "ArmoDominic_2";
		break;
		case "ArmoDominic_2":
			dialog.text = ""+ GetSexPhrase("L'ami", "" + pchar.name + "") +", rends-moi encore un service.";
			link.l1 = "Encore ?";
			link.l1.go = "ArmoDominic_3";
		break;
		case "ArmoDominic_3":
			dialog.text = "Hum, eh bien, oui... Va encore voir Thomas, convaincs-le qu'on m'a calomnié.";
			link.l1 = "Au fait, qui aurait pu faire ça ?";
			link.l1.go = "ArmoDominic_4";
		break;
		case "ArmoDominic_4":
			dialog.text = "N'importe qui à la taverne ! Quand je parlais avec Armo, la moitié de la Cité était assise là.";
			link.l1 = "Oh... Bon, alors, je vais essayer de convaincre Thomas de ton innocence.";
			link.l1.go = "ArmoDominic_5";
		break;
		case "ArmoDominic_5":
			dialog.text = "Merci"+ GetSexPhrase(", l'ami", "") +" !";
			link.l1 = "Je vous en prie.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.LegroHelp = "to3ToPrison";
			AddQuestRecord("TakeVineToPrisoner", "5");
		break;

		case "KeyDominic":
			dialog.text = "Parfait ! Qu'a-t-il dit ?";
			link.l1 = "Il te présente ses excuses pour son comportement déplacé.";
			link.l1.go = "KeyDominic_1";
		break;
		case "KeyDominic_1":
			dialog.text = "C'est bien Thomas, je reconnais là mon ami. "+ GetSexPhrase("L'ami", "" + pchar.name + "") +", je te suis éternellement reconnaissant !";
			link.l1 = "וcoute, cette gratitude éternelle, on ne pourrait pas la convertir en quelque chose de plus tangible ?";
			link.l1.go = "KeyDominic_2";
		break;
		case "KeyDominic_2":
			dialog.text = "Je ne sais même pas ce que je pourrais te donner, voilà ! Je te donne la clé des coffres. Je pense qu'elle te sera utile.";
			link.l1 = "Je suppose que oui.";
			link.l1.go = "KeyDominic_3";
		break;
		case "KeyDominic_3":
			dialog.text = "Eh bien, c'est formidable ! Merci encore.";
			link.l1 = "Il n'y a pas de quoi, voyons...";
			link.l1.go = "exit";
			GiveItem2Character(pchar, "key1");
			pchar.questTemp.LSC.LegroHelp = "over";
			AddQuestRecord("TakeVineToPrisoner", "7");
			AddQuestUserData("TakeVineToPrisoner", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("TakeVineToPrisoner");
		break;
	}
	NextDiag.PrevNode = NodeName;
}
