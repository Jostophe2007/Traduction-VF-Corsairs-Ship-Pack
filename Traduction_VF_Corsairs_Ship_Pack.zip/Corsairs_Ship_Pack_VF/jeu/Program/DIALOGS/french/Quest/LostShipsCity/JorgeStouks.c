#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				dialog.text = "De nouveaux visages ! C'est bien, car à part ces terribles tempêtes, il n'y a pas grand-chose pour se distraire. Je m'appelle " + GetFullName(npchar) + " et je suis heureux d'être le premier à vous accueillir dans la Cité !";
				link.l1 = "Merci pour ce chaleureux accueil, même si mon arrivée a été quelque peu agitée !.. Je suis le capitaine " + GetFullName(pchar) + ".";
				link.l1.go = "FT_1";
			}
			else
			{
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de venir avec moi.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FT_1":
			dialog.text = "Capitaine, on dirait que vous êtes le seul survivant de cette tempête. J'en suis vraiment désolé...";
			link.l1 = "Moi aussi... Quel est cet endroit, mon ami ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "C'est la Cité des navires abandonnés.";
			link.l1 = "Et pas l'טle de la Justice ?";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Hum, non... Même si, vous savez, on dit qu'autrefois, elle portait ce nom. Mais je n'ai pas connu cette époque.";
			link.l1 = "Je vois...";
			link.l1.go = "FT_4";
		break;
		case "FT_4":
			dialog.text = "Eh bien, je considère qu'il est de mon devoir, pour ainsi dire, de vous éclairer sur notre Cité.";
			link.l1 = "J'écouterai avec plaisir et gratitude tout ce que vous aurez à me dire.";
			link.l1.go = "FT_5";
		break;
		case "FT_5":
			dialog.text = "La première chose à faire en arrivant ici, c'est d'obtenir la citoyenneté de la Cité. Pour cela, il faut vous présenter à l'amiral de la Cité, Chad Capper.";
			link.l1 = "א Chad Capper ? Ce nom me dit quelque chose.";
			link.l1.go = "FT_6";
		break;
		case "FT_6":
			dialog.text = "Vous vous en souviendrez plus tard, écoutez d'abord la suite... Donc, Chad Capper est le chef de la Cité. C'est une fonction élective, alors il est arrivé au pouvoir démocratiquement, pour ainsi dire. Ses devoirs comprennent la surveillance de l'application de la Loi...";
			link.l1 = "...la levée des impכts...";
			link.l1.go = "FT_7";
		break;
		case "FT_7":
			dialog.text = "Quels impכts ? Il n'y a pas d'impכts ici, personne ne lui paie rien, à part le versement initial...";
			link.l1 = "Pas d'impכts ?!! Oh, mon Dieu ! Mais c'est vraiment l'טle de la Justice...";
			link.l1.go = "FT_8";
		break;
		case "FT_8":
			dialog.text = "Eh bien, c'est possible... Je continue. Vous devez vous présenter à l'amiral pour être enregistré au plus vite. Il y a une tempête en ce moment, alors il n'y a pas grand monde sur les ponts. Mais dès qu'elle sera finie, Capper vous trouvera de toute façon. Et je vous conseille de ne pas tarder à vous faire enregistrer.";
			link.l1 = "D'accord, j'ai compris. Et quand pensez-vous que cette tempête va finir ?";
			link.l1.go = "FT_9";
		break;
		case "FT_9":
			dialog.text = "Tout sera certainement calme d'ici demain soir. La tempête s'est déjà apaisée.";
			link.l1 = "Compris. Que dois-je savoir d'autre ?";
			link.l1.go = "FT_10";
		break;
		case "FT_10":
			dialog.text = "L'amiral vous parlera plus en détail de la Loi selon laquelle nous vivons tous, mais je peux vous en décrire les grands principes en quelques mots.";
			link.l1 = "Très intéressant !";
			link.l1.go = "FT_11";
		break;
		case "FT_11":
			dialog.text = "Donc, il est interdit de tuer les citoyens, de les voler, de démonter les navires pour construire de quoi partir d'ici...";
			link.l1 = "Halte ! דa veut dire que je ne peux pas partir d'ici ?!";
			link.l1.go = "FT_12";
		break;
		case "FT_12":
			dialog.text = "Bien sמr que non ! C'est interdit par la Loi !.. Vous savez, je préférerais ne pas aborder ces sujets, ce ne sont pas mes affaires. Allez voir l'amiral, il vous expliquera tout.";
			link.l1 = "Et oם se trouve-t-il ?";
			link.l1.go = "FT_13";
		break;
		case "FT_13":
			dialog.text = "Sur le navire « San Augustine ». C'est assez loin d'ici, une passerelle mène au vaisseau de guerre... Désolé, mais je ne peux pas vous l'expliquer plus précisément, puisque vous ne connaissez pas encore les repères. Cherchez le « San Augustine » !";
			link.l1 = "Compris... Dites-moi, connaissiez-vous un certain Teaser Dan ?";
			link.l1.go = "FT_14";
		break;
		case "FT_14":
			dialog.text = "Non, ce nom ne me dit rien.";
			link.l1 = "Oui, je vois... Eh bien, merci pour les renseignements.";
			link.l1.go = "FT_15";
		break;
		case "FT_15":
			dialog.text = "De rien. Je suis toujours à votre service, "+ GetSexPhrase("monsieur", "mademoiselle") +"... Attendez, j'ai failli oublier une information d'une importance vitale !";
			link.l1 = "C'est très aimable à vous.";
			link.l1.go = "FT_16";
		break;
		case "FT_16":
			dialog.text = "N'entrez jamais à l'intérieur de la barque « San Gabriel » ni du galion « Velasco » ! Le galion Velasco, c'est le navire sur lequel nous nous trouvons en ce moment...";
			link.l1 = "Pourquoi ?";
			link.l1.go = "FT_17";
		break;
		case "FT_17":
			dialog.text = "On vous tuera. Ces navires appartiennent aux clans des Narvals et des Caspers. Vous pouvez marcher sur leurs ponts, mais vous ne pouvez pas descendre à l'intérieur !";
			link.l1 = "Hum, eh bien, je vois. J'en tiendrai compte. Merci encore pour ce chaleureux accueil.";
			link.l1.go = "FT_18";
		break;
		case "FT_18":
			AddQuestRecord("ISS_MainLine", "1");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
			pchar.JustGotIntoLSC = true;
			LAi_SetLSCoutTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez " + GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "mademoiselle") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Cette Cité... D'oם vient-elle ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Et vous, vous vivez ici depuis longtemps ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Beaucoup de gens meurent ici ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4") && CheckCharacterItem(pchar, "keyQuestLSC"))
			{
				link.l4 = "וcoutez, vous savez ce qu'est le Diffindur ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5"))
			{
				link.l5 = "Qu'y a-t-il d'intéressant dans votre Cité ? א part la résidence de Chad Capper, bien sמr...";
				link.l5.go = "ansewer_5";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l6"))
			{
				link.l6 = "Comment pourrais-je m'orienter ici ?";
				link.l6.go = "ansewer_6";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Certains disent que c'est une formation naturelle qui attire étrangement les navires, d'autres sont sמrs que cet endroit est maudit et qu'il ne fera que grandir avec de plus en plus d'épaves... Difficile à dire, difficile de démêler la vérité de la masse des ragots et des fantasmes.";
			link.l1 = "Et vous, qu'en pensez-vous ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Mon opinion a-t-elle de l'importance ? Bien sמr, ni plus ni moins que celle des autres.";
			link.l1 = "Et pourtant... ?";
			link.l1.go = "ansewer_1_2";
		break;
		case "ansewer_1_2":
			dialog.text = "Regardez autour de vous, écoutez... Vous pouvez entendre leurs voix : les gémissements et les cris de milliers de marins morts résonnent en vous, en chacun de nous. En marchant sur le pont, on peut saisir des sons à peine perceptibles, mais si l'on y prête l'attention qu'il faut, on comprend que ce ne sont rien d'autre que des échos de l'époque oם le navire sillonnait les mers.";
			link.l1 = "Qu'est-ce que ça veut dire ?";
			link.l1.go = "ansewer_1_3";
		break;
		case "ansewer_1_3":
			dialog.text = "La Cité ne fait pas que nous retenir, capitaine. Elle capture les âmes et le temps, elle peut tromper l'éternité.";
			link.l1 = "Et moi qui croyais bêtement que c'était Chad Capper qui nous retenait...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Non, environ trois mois. Il y a eu un combat de nuit contre des pirates qui s'étaient emparés d'un énorme vaisseau de guerre. Notre capitaine était de ces fous désespérés, et c'est pourquoi il s'est lancé avec son brick dans une bataille perdue d'avance. Bien sמr, dès la première bordée, le vaisseau de ligne a balayé de notre pont tout ce qui vivait, et le reste avec, y compris le capitaine et la moitié des officiers\n"+
				"Je n'avais jamais rien vécu de pareil, je me suis précipité sur le pont et j'ai à peine pu m'y frayer un chemin à travers les débris de la mâture et les lambeaux du gréement... C'est un spectacle incomparable, capitaine. Même si vous savez sans doute mieux que moi ce que c'est. "+
				"Bref, ne voulant pas attendre la bordée suivante, qui nous aurait sans aucun doute envoyés par le fond, moi, les matelots restants et le navire tout entier, je me suis jeté par-dessus bord et, après avoir nagé jusqu'à la plus proche épave d'une taille suffisante, je m'y suis agrippé. Ensuite, j'ai dמ perdre connaissance – je ne m'en souviens pas, mais... au matin, j'étais ici.";
			link.l1 = "Palpitant...";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Je pense bien ! J'en ai eu le souffle coupé au point de presque faire dans ma culotte... Mais tout ça est derrière moi maintenant, et je me plais vraiment ici. C'est calme, tranquille, intéressant.";
			link.l1 = "Je vois que vous n'êtes pas le seul dans ce cas.";
			link.l1.go = "ansewer_2_2";
		break;
		case "ansewer_2_2":
			dialog.text = "Bien sמr. Pourquoi résister ? Au début, oui, tout semble hostile, on a envie de fuir ce maudit endroit, mais... ensuite, tout s'arrange, croyez-moi. Vous vous y habituerez, comme nous tous.";
			link.l1 = "Cette idée d'accoutumance ne me plaît pas trop.";
			link.l1.go = "ansewer_2_3";
		break;
		case "ansewer_2_3":
			dialog.text = "Et moi, je ne suis pas sמr qu'on vous demande votre avis. Je ne suis ni le premier ni le dernier à vous dire qu'il vaut mieux oublier tout de suite ce qui vous est arrivé avant. Commencez une nouvelle vie ! Vous verrez, on est très bien ici.";
			link.l1 = "Merci pour le conseil, monsieur " + npchar.lastname + ".";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Plus qu'assez. Mais il en arrive encore davantage ces derniers temps.";
			link.l1 = "Ces derniers temps ? Pourquoi ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Je n'en sais rien avec certitude, mais il semble que la Cité soit devenue connue dans le vaste monde.";
			link.l1 = "Hum, j'ai entendu plus d'une fois des rumeurs sur une certaine טle de la Justice. Il s'agissait sans doute de la Cité...";
			link.l1.go = "ansewer_3_2";
		break;
		case "ansewer_3_2":
			dialog.text = "Peut-être. Mais si c'est le cas, comment ces rumeurs sont-elles parvenues jusqu'aux villes du continent ?";
			link.l1 = "Héhé, je n'en sais rien. Mais j'aimerais vraiment le savoir...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Diffindur ? Hum... Ce ne serait pas l'un des navires d'ici, la flמte « Fernando Diffindur » ?";
			link.l1 = "Quelle flמte ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Un navire à moitié coulé, il s'est brisé en deux et tient miraculeusement sur le récif. Personne n'y vit : c'est trop dangereux.";
			link.l1 = "Oם se trouve-t-il ?";
			link.l1.go = "ansewer_4_2";
		break;
		case "ansewer_4_2":
			dialog.text = "Exactement de l'autre cכté de la Cité. De manière générale, je vous conseille d'en parler au tavernier, il sait tout ici.";
			link.l1 = "Vous avez aussi une taverne ?";
			link.l1.go = "ansewer_4_3";
		break;
		case "ansewer_4_3":
			dialog.text = "La taverne, l'église et la boutique, tout comme les gens d'une ville ordinaire ! Il y a aussi un usurier, Augusto Brahms, mais vous devriez vous méfier de lui...";
			link.l1 = "Oh, voilà qui est mieux !";
			link.l1.go = "int_quests";
			//AddQuestRecord("ISS_MainLine", "2");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;
		case "ansewer_5":
			dialog.text = "Tout ce qu'il y a dans une ville ordinaire se trouve ici : une église, une taverne, une boutique. Il y a quelqu'un qui prête de l'argent. Mais je vous le dis, c'est la chose la plus stupide qu'on puisse faire ici.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Il y a tellement d'or dans la Cité qu'il n'a aucune valeur pratique. Les gens l'amassent par habitude plutכt que dans l'espoir de s'en servir.";
			link.l1 = "Je ne comprends pas, quelqu'un a besoin d'argent, ici ?";
			link.l1.go = "ansewer_5_2";
		break;
		case "ansewer_5_2":
			dialog.text = "Mais oui, pourquoi pas ? L'argent reste l'argent, ici aussi. Mais il n'est pas aussi nécessaire que sur le continent... Bref, vous comprendrez plus tard.";
			link.l1 = "Hum, je ne comprends pas encore, mais j'espère que ça viendra...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_6":
			dialog.text = "Ce sera difficile au début, mais vous comprendrez vite comment ça marche.";
			link.l1 = "Eh bien, oui, voilà qui est encourageant... Alors, existe-t-il une carte de la Cité ?";
			link.l1.go = "ansewer_6_1";
			NextDiag.(NodePrevName).l6 = true;
		break;
		case "ansewer_6_1":
			dialog.text = "Il en existe une, j'en ai même vu une.";
			link.l1 = "Tiens ! Et oם l'avez-vous vue ?";
			link.l1.go = "ansewer_6_2";
		break;
		case "ansewer_6_2":
			dialog.text = "Dans la boutique d'Eric Yost, sur le galion « Esmeralda ».";
			link.l1 = "Je comprends, merci.";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Quoi exactement, si je puis me permettre ?",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Des bombes, de la mitraille, des vivres, des médicaments, de la poudre, des armes...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Compris. On ne voit pas bien pourquoi vous avez besoin de tout ça. Bon, d'accord, pour les bombes, mieux vaut demander aux maîtresses de maison des navires, elles ont beaucoup de ce genre de choses. Mais c'est l'amiral qui a les armes et la poudre.";
			link.l1 = "Et il voudra bien les donner ?";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Je n'en sais rien. Demandez-le-lui.";
			link.l1 = "Compris. Merci beaucoup.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Un équipage pour un navire ?";
			link.l1 ="Oui.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Et alors, vous l'avez vraiment, ce navire ?";
			link.l1 = "Je l'ai.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "דa, c'est une nouvelle... J'accepte !";
			link.l1 = "Parfait ! Alors, allez immédiatement sur le San Gabriel. Henrik Wedeker vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, c'est ce que je vais faire. Je fais vite mes bagages et je peux partir.";
			link.l1 = "Ne traînez pas.";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
