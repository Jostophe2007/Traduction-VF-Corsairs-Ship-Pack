// диалоговый файл №2 на голландку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            if (pchar.questTemp.State == "DelivLettTortuga_NotFoundLetter")// кэп пиратов, вывезший де Барраса из Тортуги
            {
    			dialog.text = "Vous avez gagné ! Je me rends...";
    			link.l1 = "Je veux savoir oם diable est passé Antonio ?! Réponds !!!";
    			link.l1.go = "Step_H7_1";
            }
            if (npchar.id == "LoranDeGraf")// Лоран де Граф, квест №8
            {
    			dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", ce n'est pas le moment de parler ! On se bat.";
    			link.l1 = "Oui, oui, je sais...";
    			link.l1.go = "exit";
            }
			if (pchar.questTemp.State == "SeekBible_WeWon" && npchar.id == "LoranDeGraf")// Лоран де Граф, квест №8
            {
    			dialog.text = "Je vous suis extrêmement reconnaissant de votre aide, "+ GetSexPhrase("monsieur", "mademoiselle") +". Vous êtes arrivé juste à temps. Permettez-moi de me présenter, je m'appelle Laurent de Graaf.";
    			link.l1 = "Je sais, c'est justement vous que je cherchais. D'abord aux Bermudes, puis à Tortuga.";
    			link.l1.go = "Step_H8_10";
            }
            if (pchar.questTemp.State == "SeekBible_IHaveMap")
            {
    			dialog.text = "Il me semble que notre transaction est terminée, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
    			link.l1 = "C'est exact, terminée.";
    			link.l1.go = "exit";
            }
            if (pchar.questTemp.State == "SeekBible_SeekMoney")
            {
    			dialog.text = "Vous avez trouvé l'argent,"+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
                if (sti(pchar.money) >= 235000)
                {
                    link.l1 = "Oui. Et je suis prêt à vous le remettre...";
        			link.l1.go = "Step_H8_13";
                }
                else
                {
                    link.l1 = "Pas encore, je le cherche...";
        			link.l1.go = "exit";
                }
            }
        break;

//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Диалоги кэпа, который увёз де Барраса из Тортуги **********************************
 		case "Step_H7_1":
			dialog.text = "Antonio de Barras ? Je l'ai déposé en chemin sur un galion de guerre espagnol.";
			link.l1 = "Diable ! Comment s'appelait ce galion, et oם allait-il ?";
			link.l1.go = "Step_H7_2";
		break;
  		case "Step_H7_2":
			dialog.text = "Le galion Isabella, à destination de Santa Catalina, sur le continent. Antonio m'a dit qu'il devait absolument et de toute urgence s'y rendre.";
			link.l1 = "Ah, bon sang ! וcoute, tu es pirate, pourquoi diable te mêles-tu des affaires des Espagnols ?!";
			link.l1.go = "Step_H7_3";
		break;
  		case "Step_H7_3":
			dialog.text = "Ce ne sont pas tes foutues affaires, caramba..\n"+
                          "Hé, vous tombez à pic, les gars ! Descendez "+ GetSexPhrase("ce dandy, il me tape sur les nerfs", "cette garce, elle me tape sur les nerfs") +" !..";
			link.l1 = "Argh...";
			link.l1.go = "Step_H7_4";
		break;
  		case "Step_H7_4":
            GetCharacterPos(pchar, &locx, &locy, &locz);
            for (int i=1; i<=2; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("Pirate"+i, "officer_"+i, "man", "man", 25, PIRATE, 0, true));
                FantomMakeCoolFighter(sld, 25, 100, 100, BLADE_LONG, "pistol3", 50);
            	LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, LAI_GROUP_BRDENEMY);
               	ChangeCharacterAddressGroup(sld, pchar.location, "rld", LAi_FindFarLocator("rld", locx, locy, locz));
            }
            LAi_group_SetRelation(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, true);
            QuestAboardCabinDialogExitWithBattle("");
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "8");
	    AddQuestUserData("Hol_Line_7_DelivLettTortuga", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State.KingResult = "BrigAborded"; //флаг бриг взят на абордаж
            pchar.quest.DelivLettTortuga_BrigDieHard.over = "yes";
            pchar.quest.DelivLettTortuga_AfterBrigSunk.over = "yes";
            Island_SetReloadEnableGlobal("PuertoRico", true);
            Pchar.quest.DelivLettTortuga_AttackWarship.win_condition.l1 = "location";
            Pchar.quest.DelivLettTortuga_AttackWarship.win_condition.l1.location = "SantaCatalina";
            Pchar.quest.DelivLettTortuga_AttackWarship.win_condition = "DelivLettTortuga_AttackWarship";
            SetTimerCondition("DelivLettTortuga_WarshipTimeOver", 0, 0, 12, false);
            DialogExit();
		break;

		case "Step_H8_10":
			dialog.text = "Qui êtes-vous, et que puis-je pour vous ?";
			link.l1 = "Je m'appelle " + GetFullName(pchar) + ", je voulais vous acheter le livre que vous aviez mis en vente chez les gens de Jackman.";
			link.l1.go = "Step_H8_11";
    	break;
		case "Step_H8_11":
			dialog.text = "Ah-ah, c'est donc ça ? Eh bien, ça peut s'arranger. Je n'ai pas réussi à vendre le livre, et je l'ai en fait caché en lieu sמr. Le marché est le suivant : vous me payez 235 000 piastres, et je vous donne une carte de l'endroit oם se trouve le livre.";
			link.l1 = "Ce n'est pas un peu beaucoup, 235 000 ?";
			link.l1.go = "Step_H8_12";
    	break;
		case "Step_H8_12":
			dialog.text = "Non. Le fait est qu'il y a autre chose dans cette cache. C'est donc le prix de l'ensemble, de tout le trésor.";
            if (sti(pchar.money) >= 235000)
            {
                link.l1 = "Marché conclu, monsieur. Voici votre argent !";
    			link.l1.go = "Step_H8_13";
    			AddMoneyToCharacter(pchar, -235000);
            }
            else
            {
                link.l1 = "Je n'ai pas assez d'argent en ce moment. Je devrai revenir vous voir plus tard.";
    			link.l1.go = "Step_H8_15";
            }
    	break;
		case "Step_H8_13":
			dialog.text = "Je vous en prie, prenez la carte. Voyez-vous, je suis content d'avoir enfin réussi à vendre cette chose inutile pour moi. Mais dites-moi, pourquoi en avez-vous besoin ?";
			link.l1 = "J'agis pour le compte des autorités hollandaises, je n'ai donc pas à me perdre en conjectures.";
			link.l1.go = "Step_H8_14";
            GiveItem2Character(pchar, "LegransMap");
    	break;
		case "Step_H8_14":
			dialog.text = "Ah, compris. Eh bien, une bonne affaire pour nous deux.";
			link.l1 = "C'est exact. Je vous suis reconnaissant, Laurent de Graaf. J'espère vous revoir.";
			link.l1.go = "exit";
            AddQuestRecord("Hol_Line_8_SeekBible", "9");
            NPChar.LifeDay = 2;
    	    SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
    	    pchar.questTemp.State = "SeekBible_IHaveMap";
         	pchar.GenQuestBox.Terks_Grot = true;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry5 = 200;
			pchar.GenQuestBox.Terks_Grot.box1.items.jewelry17 = 300;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade33 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade28 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade34 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade32 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade23 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.pistol5 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.pistol4 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.pistol6 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.potion2 = 5;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian18 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry7 = 5;
            pchar.GenQuestBox.Terks_Grot.box1.items.blade5 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.potion2 = 10;
            pchar.GenQuestBox.Terks_Grot.box1.items.potionwine = 3;
			pchar.GenQuestBox.Terks_Grot.box1.items.jewelry1 = 110;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry2 = 60;
			pchar.GenQuestBox.Terks_Grot.box1.items.jewelry3 = 80;
			pchar.GenQuestBox.Terks_Grot.box1.items.jewelry4 = 35;
			pchar.GenQuestBox.Terks_Grot.box1.items.chest = 5;
			pchar.GenQuestBox.Terks_Grot.box1.items.icollection = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.jewelry14= 10;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian6 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian11 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian15 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian12 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.indian18 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.cirass5 = 1;
            pchar.GenQuestBox.Terks_Grot.box1.items.Bible = 1;
        break;
		case "Step_H8_15":
			dialog.text = "Très bien, "+ GetSexPhrase("monsieur", "mademoiselle") +". Vous me trouverez à la taverne de Tortuga.";
			link.l1 = "D'accord, je viens vous voir bientכt, attendez-moi.";
			link.l1.go = "exit";
			pchar.questTemp.State = "SeekBible_SeekMoney";
			pchar.quest.SeekBible_DeGrafToTavern.win_condition.l1 = "MapEnter";
            pchar.quest.SeekBible_DeGrafToTavern.win_condition = "SeekBible_DeGrafToTavern";
    	break;


    }
}
