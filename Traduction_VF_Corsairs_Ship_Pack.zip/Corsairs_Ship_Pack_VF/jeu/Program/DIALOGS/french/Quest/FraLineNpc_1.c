// диалоговый файл №1 на фр. линейку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i, iTemp;
    float locx, locy, locz;
	string sTemp, attrName;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            //Квест №1, сопровождение Леграна.
            if (pchar.questTemp.State == "Fr1Legran_toTavern")// квест №1, Легран в таверне
            {
    			dialog.text = "Je vous écoute, que voulez-vous ?";
    			link.l1 = "Monsieur, à ce que je sais, vous êtes Pierre Legrand.";
    			link.l1.go = "Step_F1_1";
            }
            if (pchar.questTemp.State == "Fr1Legran_afterFightBand")// квест №1, Легаран после боя.
            {
    			dialog.text = "Je dois me dépêcher, je n'ai pas le temps...";
    			link.l1 = "Monsieur, je vous ai conduit jusqu'à la baie, ma mission est accomplie...";
    			link.l1.go = "Step_F1_3";
    			link.l2 = "Et nous voilà arrivés ! J'ai décidé que votre argent serait à moi, il me sera bien utile.";
    			link.l2.go = "Step_F1_5";
            }
            //Квест №2, доставка письма на Тортугу
			if (pchar.questTemp.State == "Fr2Letter_SeekProblems")// квест №2, странные типы в таверне
            {
    			dialog.text = "...à Palm Beach.";
				link.l1 = "(à part) bon, bon, Palm Beach...";
    			link.l1.go = "Step_F2_1";
            }
			if (pchar.questTemp.State == "Fr2Letter_SeekProblems" && pchar.location == "Shore22")// квест №2, странные типы в бухте
            {
    			dialog.text = "...Notre galion devrait déjà être là.";
				link.l1 = "(à part) tiens, tiens, un galion...";
    			link.l1.go = "Step_F2_5";
            }
			if (npchar.id == "DeLeiva")// квест №3, база с мужем донны Анны
            {
    			dialog.text = "Eh bien, nous avons attendu notre visite. Bienvenue à table, "+ GetSexPhrase("monsieur","mademoiselle") +". Le plat de résistance pour vous aujourd'hui, c'est du bon acier de Tolède !";
				link.l1 = "En voilà une rencontre ! Que se passe-t-il ?!";
    			link.l1.go = "Step_F3_1";
            }
			if (npchar.id == "AnnaDeLeiva" && pchar.questTemp.State == "Fr5AnnaHant_toAnna")// квест №5, донна Анна в резиденции Тортуги
            {
    			dialog.text = "C'est le señor d'Ogeron qui vous envoie ?";
    			link.l1 = "Oui, madame. Que puis-je faire pour vous ?";
    			link.l1.go = "Step_F5_1";
            }
			if (npchar.id == "AnnaDeLeiva" && pchar.questTemp.State == "Fr5AnnaHant_toHavana")
            {
    			dialog.text = "Dites-moi, "+ GetSexPhrase("señor","señorita") +", qu'avez-vous appris ?";
    			link.l1 = "Rien pour l'instant. Mais je m'en occupe, ne vous inquiétez pas, madame...";
    			link.l1.go = "exit";
            }
			if (npchar.id == "AnnaDeLeiva" && pchar.questTemp.State == "Fr5AnnaHant_SeekHoseBrothers")
            {
    			dialog.text = "Dites-moi, "+ GetSexPhrase("señor","señorita") +", qu'avez-vous appris ?";
    			link.l1 = "Rien pour l'instant. Mais je m'en occupe, ne vous inquiétez pas, madame...";
    			link.l1.go = "exit";
            }
			if (npchar.id == "DeLeivaBrother_1" || npchar.id == "DeLeivaBrother_2")// квест №5, братья де Лейва
            {
    			dialog.text = "Que voulez-vous ici ?";
    			link.l1 = "Señora, ne seriez-vous pas parente de don José Ramírez de Leyva ?";
    			link.l1.go = "Step_F5_2";
            }
			if (npchar.id == "AnnaDeLeiva" && pchar.questTemp.State == "Fr5AnnaHant_GoodWork")// квест №5, донна Анна после выполнения задачи
            {
				dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Señor","Señorita") +"C'est la deuxième fois que vous me sauvez la vie. Sachez que vous avez trouvé en moi une véritable amie.",
					         "Rebonjour, capitaine. Je suis contente de vous voir.", "Et rebonjour, capitaine...", "Encore une fois dans la journée : bonjour, capitaine...", "block", 0, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Señora, tout à fait par hasard, près de La Havane, j'ai rencontré deux nobles castillans, et vous devriez savoir comment ils parlaient de vous... Il semble, doña Anna, que l'on chérisse votre souvenir en Castille.",
					      "Et moi aussi, je suis heureux de vous voir.", "Et une fois de plus, heureux de vous voir...", "Bonjour, señora...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("Step_F5_8", "none", "none", "none", npchar, Dialog.CurrentNode);

            }
			if (npchar.id == "AnnaDeLeiva" && pchar.questTemp.State == "empty")// квест №5, донна Анна после выполнения задачи
            {
				dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Señor","Señorita") +"C'est la deuxième fois que vous me sauvez la vie. Sachez que vous avez trouvé en moi une véritable amie.",
					         "Rebonjour, capitaine. Je suis contente de vous voir.", "Et rebonjour, capitaine...", "Encore une fois dans la journée : bonjour, capitaine...", "block", 0, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Señora, tout à fait par hasard, près de La Havane, j'ai rencontré deux nobles castillans, et vous devriez savoir comment ils parlaient de vous... Il semble, doña Anna, que l'on chérisse votre souvenir en Castille.",
					      "Et moi aussi, je suis heureux de vous voir.", "Et une fois de plus, heureux de vous voir...", "Bonjour, señora...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("Step_F5_8", "none", "none", "none", npchar, Dialog.CurrentNode);
            }
			if (npchar.id == "Olone" && pchar.questTemp.State == "Fr5Olone_toGuadeloupe")// квест №6, базар в доме Олоне
            {
				dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Monsieur","Mademoiselle") +", faut-il vous apprendre les bonnes manières ?! Personne n'entre chez moi sans y être invité !",
					         "Nous avons, me semble-t-il, tout réglé...", "Autre chose ?", "Encore la même chose, combien de fois faudra-t-il que je le répète ?!", "block", 0, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("J'ai mon invitation sur moi. La voici : c'est un pli urgent du gouverneur général d'Ogeron.",
					      "Oui, c'est vrai...", "Non, ce n'est rien...", "Allons, ne vous énervez pas...", npchar, Dialog.CurrentNode);
				link.l1.go = DialogGoNodeRepeat("Step_F6_1", "none", "none", "none", npchar, Dialog.CurrentNode);
            }
			if (npchar.id == "Olone" && pchar.questTemp.State == "Fr5Olone_FoundMoney") //успели к деньгам
            {
    			dialog.text = "Vous avez trouvé nos réaux ?";
    			link.l1 = "Oui, tout va bien. Par chance, nous sommes arrivés à temps : j'ai l'argent.";
    			link.l1.go = "Step_F6_14";
				LAi_LocationDisableOfficersGen("Cumana_town", false); //офицеров пускать
            }
			if (npchar.id == "Olone" && pchar.questTemp.State == "Fr5Olone_WeLate") //деньги ушли
            {
    			dialog.text = "Vous avez trouvé nos réaux ?";
    			link.l1 = "Non, François...";
    			link.l1.go = "Step_F6_10";
				LAi_LocationDisableOfficersGen("Cumana_town", false); //офицеров пускать
            }
			if (npchar.id == "Bonrepo" && pchar.questTemp.State == "Fr8ThreeCorsairs_toBonrepo") //Квест №8. Маркиз Бонрепо в Бас-Тере
            {
    			dialog.text = "א qui ai-je l'honneur ?";
    			link.l1 = "Capitaine " + GetFullName(pchar) + ". Je viens vous voir sur ordre du gouverneur général d'Ogeron.";
    			link.l1.go = "Step_F8_1";
            }
			if (npchar.id == "Bonrepo" && pchar.questTemp.State == "Fr8ThreeCorsairs_toSeek")
            {
    			dialog.text = "Alors, votre mission avance-t-elle bien ?";
    			if (sti(pchar.questTemp.Count) == 3)
				{
					link.l1 = "C'est fait. Aucun des trois ne participera à la guerre aux cכtés de l'Angleterre.";
    				link.l1.go = "Step_F8_9";
				}
				else
				{
					link.l1 = "Je n'ai pas encore pu les rencontrer tous, mais je m'en occupe.";
    				link.l1.go = "exit";
				}
            }
			if (npchar.id == "Bonrepo" && pchar.questTemp.State == "Fr12EndWar_toBorepo")
            {
    			dialog.text = "Ah, "+ GetSexPhrase("Baron","Baronne") +" ! Je suis ravi de vous voir. Je dirai même plus : je vous attendais...";
    			link.l1 = "Moi aussi, je suis ravi de vous voir, marquis.";
    			link.l1.go = "Step_F12_1";
            }
			if (npchar.id == "Bonrepo" && pchar.questTemp.State == "EndOfQuestLine")
            {
    			dialog.text = "Voilà, "+ GetSexPhrase("Baron","Baronne") +", je ne vous retiens pas plus longtemps. Au revoir...";
    			link.l1 = "Au revoir, marquis...";
    			link.l1.go = "exit";
            }
		break;
//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Доставка Леграна до Мартиники. Квест №1 **********************************
 		case "Step_F1_1":
			dialog.text = "Oui, c'est ça.";
			link.l1 = "Je m'appelle "+ GetFullName(pchar) +". C'est le gouverneur général d'Ogeron qui m'envoie. J'ai pour mission de vous conduire discrètement, sans attirer l'attention, à la Martinique, dans la baie du Marin.";
			link.l1.go = "Step_F1_2";
		break;
 		case "Step_F1_2":
			dialog.text = "Si le gouverneur général vous fait confiance, moi aussi. Quand partons-nous ?";
			link.l1 = "Dès que possible. Attendez-moi sur mon navire.";
			link.l1.go = "Step_F1_exit";
		break;
 		case "Step_F1_exit":
			locations[FindLocation("Shore39")].DisableEncounters = true; //энкаунтеры закроем
    		pchar.questTemp.State = "Fr1Legran_toLeMaren";
            AddQuestRecord("Fra_Line_1_LegranDis", "2");
			LAi_SetStayType(npchar);
            GetCharacterPos(pchar, &locx, &locy, &locz);
         	ChangeCharacterAddressGroup(npchar, "Tortuga_tavern", "tables", LAi_FindNearestFreeLocator("tables", locx, locy, locz));
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 8);
			Pchar.quest.Fr1Legran_intoLeMaren.win_condition.l1 = "location";
            Pchar.quest.Fr1Legran_intoLeMaren.win_condition.l1.location = "Shore39";
            Pchar.quest.Fr1Legran_intoLeMaren.win_condition = "Fr1Legran_intoLeMaren";
            AddPassenger(pchar, npchar, false);
            SetCharacterRemovable(npchar, false);
            DialogExit();
		break;
 		case "Step_F1_3":
			dialog.text = "Oui, oui, sans aucun doute, vous avez pleinement rempli vos obligations. Permettez-moi de vous remercier comme il se doit : la somme de 20 000 pièces d'or me semble tout à fait convenable, n'est-ce pas ?";
			link.l1 = "Tout à fait...";
			link.l1.go = "Step_F1_4";
		break;
 		case "Step_F1_4":
			dialog.text = "Cet argent est à vous, si vous le voulez bien.\n"+
				          "Adieu, et portez-vous bien, "+ GetSexPhrase("monsieur","mademoiselle") +".";
			link.l1 = "Adieu, monsieur. Je vous souhaite un bon retour en France... Adieu !";
			link.l1.go = "Step_F1_4_exit";
		break;
		case "Step_F1_4_exit":
			pchar.questTemp.State = "Fr1Legran_backGovernor";
			AddQuestRecord("Fra_Line_1_LegranDis", "3");
			AddMoneyToCharacter(pchar, 20000);
			LAi_SetPlayerType(pchar);
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "CanFightCurLocation", 10.0);
			LAi_LocationFightDisable(&Locations[FindLocation("Shore39")], true);
			NPChar.LifeDay = 0;
			RemovePassenger(pchar, npchar);
            DialogExit();
		break;
 		case "Step_F1_5":
			dialog.text = "Ah, misérable ! Je vais faire savoir au gouverneur général quel"+ GetSexPhrase(" gredin s'est glissé","le gredine s'est glissée") +" dans sa confiance !";
			link.l1 = "Reste d'abord en vie, mollasson !";
			link.l1.go = "Step_F1_6";
		break;
 		case "Step_F1_6":
			LAi_SetPlayerType(pchar);
            LAi_SetActorType(npchar);
			AddQuestRecord("Fra_Line_1_LegranDis", "4");
			pchar.questTemp.State = "Fr1Legran_LegranKilled";
			LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Арест ГГ у Стэвезанта. Квест №2 **********************************
 		case "Step_F2_1":
			dialog.text = "Hé, qu'est-ce que tu veux ici, qu'est-ce que tu manigances ? On ne t'a pas invité à boire.";
			link.l1 = "On m'appelle capitaine " + GetFullName(pchar) + ", j'arrive tout juste de Tortuga... Vous voulez rejoindre mon équipage ?";
    		link.l1.go = "Step_F2_2";
		break;
 		case "Step_F2_2":
			dialog.text = "Non, on ne veut pas !";
			link.l1 = "J'offre de bonnes conditions, réfléchissez... On boit un coup ? Laissez-moi m'asseoir avec vous...";
			link.l1.go = "Step_F2_3";
		break;
 		case "Step_F2_3":
			dialog.text = "Asseyez-vous et buvez un coup, capitaine. Bon, nous devons y aller.";
			link.l1 = "Ah, bon...";
			link.l1.go = "Step_F2_4";
		break;
 		case "Step_F2_4":
			chrDisableReloadToLocation = true;
            GetCharacterPos(pchar, &locx, &locy, &locz);
            for (i=1; i<=2; i++)
            {
				sld = characterFromId("Bandit_"+i);
				LAi_SetStayType(sld);
				if (i==2) ChangeCharacterAddressGroup(sld, "Villemstad_tavern", "tables", "stay2");
				else ChangeCharacterAddressGroup(sld, "Villemstad_tavern", "goto", "goto3");
				LAi_SetActorType(sld);
				LAi_ActorRunToLocation(sld, "reload", "reload1_back", "none", "", "", "Fr2Letter_OutTavern_1", 10);
			}
			Pchar.quest.Fr2Letter_OutTavern_2.win_condition.l1 = "location";
            Pchar.quest.Fr2Letter_OutTavern_2.win_condition.l1.location = "Villemstad_town";
            Pchar.quest.Fr2Letter_OutTavern_2.win_condition = "Fr2Letter_OutTavern_2";
			locations[FindLocation("Shore22")].DisableEncounters = true; //энкаутеры уберём временно
			LAi_SetPlayerType(pchar);
            DialogExit();
		break;

 		case "Step_F2_5":
			dialog.text = "Encore vous ? Et qu'est-ce que vous faites ici ?";
			link.l1 = "Je veux savoir une chose. Vous parliez d'un galion qui serait à vous...";
    		link.l1.go = "Step_F2_6";
		break;
 		case "Step_F2_6":
			dialog.text = "Vous avez l'ouïe fine. De bonnes oreilles...";
			link.l1 = "J'attends une réponse !";
    		link.l1.go = "Step_F2_7";
		break;
 		case "Step_F2_7":
			dialog.text = "Qui êtes-vous pour exiger une réponse ?";
			link.l1 = "Je me suis déjà présenté, si j'ai bonne mémoire. Ou vous ne savez pas ce qu'est Tortuga et qui sont les flibustiers ?!";
    		link.l1.go = "Step_F2_8";
		break;
 		case "Step_F2_8":
			dialog.text = "Nous savons qui sont les flibustiers. Nous, nous vous appelons les Ladrones.";
			link.l1 = "Il n'y a que les Espagnols pour nous appeler ainsi...";
    		link.l1.go = "Step_F2_9";
		break;
 		case "Step_F2_9":
			dialog.text = "C'est vrai... Amigo, saint Antoine nous donne l'occasion de faire communier le capitaine des Ladrones ; heureusement, "+ GetSexPhrase("il est seul","elle est seule") +". Ne perdons pas de temps...";
			link.l1 = "Ce sont des Espagnols ! Et votre galion, vous n'avez pas répondu !";
    		link.l1.go = "Step_F2_10";
		break;
 		case "Step_F2_10":
			dialog.text = "Nous attendons notre galion ici, il va jeter l'ancre d'un instant à l'autre. Maintenant, vous savez tout, mais ce savoir ne vous servira à rien...";
			link.l1 = "Eh bien, c'est vite dit. Il est peut-être temps de voir de quelle couleur est le sang castillan...";
    		link.l1.go = "Step_F2_11";
		break;
 		case "Step_F2_11":
			DeleteAttribute(&locations[FindLocation("Shore22")], "DisableEncounters"); //энкаутеры вернём
			chrDisableReloadToLocation = true;
			Pchar.quest.Fr2Letter_FightWithGaleon.win_condition.l1 = "location";
			Pchar.quest.Fr2Letter_FightWithGaleon.win_condition.l1.location = "Curacao";
			Pchar.quest.Fr2Letter_FightWithGaleon.win_condition = "Fr2Letter_FightWithGaleon";
			AddQuestRecord("Fra_Line_2_DelivLetter", "4");
            for (i=1; i<=2; i++)
            {
				sld = characterFromId("Bandit_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				LAi_RemoveCheckMinHP(sld);
				LAi_SetHP(sld, 200, 200);
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			LAi_SetPlayerType(pchar);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Драка с мужем де Лейва. Квест №3 **********************************
 		case "Step_F3_1":
			dialog.text = "Non, mais vraiment... Il y a "+ GetSexPhrase("un type","une drכle de fille") +" qui s'introduit chez les autres en pleine nuit, et qui demande ensuite : « Qu'est-ce qui se passe ?! »\n"+
				          "Cessez de jouer la comédie ! Ma femme est enfermée, j'ai trouvé sur elle cette maudite bague de d'Ogeron.";
			link.l1 = "Tout est clair... Eh bien, je ferai de mon mieux pour vous servir le plat que vous m'avez préparé aujourd'hui.";
    		link.l1.go = "Step_F3_2";
		break;
 		case "Step_F3_2":
			dialog.text = "Passons à table !";
			link.l1 = "Passons à table, en effet...";
    		link.l1.go = "Step_F3_3";
		break;
 		case "Step_F3_3":
			LAi_LocationFightDisable(loadedLocation, false);
			SetNationRelation2MainCharacter(SPAIN, RELATION_ENEMY);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			LAi_SetPlayerType(pchar);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Месть Анне де Лейва. Квест №5 **********************************
 		case "Step_F5_1":
			dialog.text = "J'ai reçu une lettre de La Havane, de mon amie Inés de las Sierras. Le gouverneur général de La Havane a ouvert une enquête sur la mort de mon mari, et il est convaincu que j'en suis responsable. Oh, c'est bien le cas ! Mais mes compatriotes préparent leur vengeance, je risque la mort ou l'enlèvement, et je ne sais pas ce qui est pire.\n"+
				          ""+ GetSexPhrase("Monsieur","Mademoiselle") +", je vous demande d'aller à La Havane pour découvrir à quel point c'est sérieux.";
			link.l1 = "Madame, vous pouvez compter sur moi.";
    		link.l1.go = "exit";
    		pchar.questTemp.State = "Fr5AnnaHant_toHavana";
			AddQuestRecord("Fra_Line_5_KillAnnaHanters", "2");
			sld = GetCharacter(NPC_GenerateCharacter("InesDeLasCierras", "girl_8", "woman", "towngirl", 10, SPAIN, -1, false));
			sld.Dialog.Filename = "Quest\FraLineNpc_2.c";
			sld.name = "Ines";
			sld.lastname = "de Las Sierras";
			sld.greeting = "Gr_Dama";
			LAi_SetStayType(sld);
			ChangeCharacterAddressGroup(sld, "Havana_houseSp2", "goto","goto2");
		break;
 		case "Step_F5_2":
			dialog.text = "Qu'est-ce que ça peut te faire ?";
			link.l1 = "Si cela m'était égal, je ne vous le demanderais pas, croyez-moi...";
    		link.l1.go = "Step_F5_3";
		break;
 		case "Step_F5_3":
			dialog.text = "Peut-être. Et que nous voulez-vous ?";
			link.l1 = "Si je comprends bien, vous projetez de venger don José ?";
    		link.l1.go = "Step_F5_4";
		break;
 		case "Step_F5_4":
			dialog.text = "Dites-moi immédiatement qui vous êtes. Sinon, je vous coupe votre longue langue.";
			link.l1 = "C'est moi qui ai envoyé ce cher don José dans l'autre monde. Ses serviteurs l'y ont suivi, à la suite de leur maître.";
    		link.l1.go = "Step_F5_5";
		break;
 		case "Step_F5_5":
			dialog.text = "Argh, la chance est avec nous aujourd'hui ! La moitié du travail est faite, mon frère, il ne reste plus qu'à trouver cette bête d'Anna, et nous pourrons rentrer chez nous.";
			link.l1 = "Et moi, alors ?!";
    		link.l1.go = "Step_F5_6";
		break;
 		case "Step_F5_6":
			dialog.text = "Et toi, tu es fini... Allez, mon frère, débarrassons-nous de "+ GetSexPhrase("ce salaud","cette ordure") +" !";
			link.l1 = "Je ne suis pas d'accord avec cette description de ma personne ! Eh bien, commençons...";
    		link.l1.go = "Step_F5_7";
		break;
 		case "Step_F5_7":
			LAi_LocationDisableOfficersGen("Mayak10", false); //офицеров пускать
			pchar.questTemp.State = "Fr5AnnaHant_GoodWork";
			LAi_LocationFightDisable(&Locations[FindLocation("Mayak10")], false);
			LAi_group_Delete("EnemyFight");
			for (i=1; i<=2; i++)
            {
				LAi_group_MoveCharacter(characterFromId("DeLeivaBrother_"+i), "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
 		case "Step_F5_8":
			dialog.text = "Je me passerais volontiers de ce genre d'égards.";
			link.l1 = "Vous n'êtes plus en danger, croyez-moi. J'ai réussi à convaincre ces braves Castillans...";
    		link.l1.go = "Step_F5_9";
		break;
 		case "Step_F5_9":
			dialog.text = "Ah, "+ GetSexPhrase("señor","señorita") +" " + pchar.name + ", comment puis-je vous remercier ?";
			link.l1 = "Doña Anna, je vous demande de prendre soin de monsieur d'Ogeron, il le mérite.";
    		link.l1.go = "Step_F5_10";
		break;
 		case "Step_F5_10":
			dialog.text = "Je ne manquerai pas d'exaucer votre demande, vous n'avez plus à vous inquiéter pour la santé morale de Bertrand.";
			link.l1 = "Madame, vous avez rendu un grand service à tous les flibustiers. Je pense que nous sommes quittes.";
			Pchar.quest.Fr3_AfterAnna_IKnowYou.over = "yes";
    		link.l1.go = "exit";
			npchar.LifeDay = 0;
		break;
//********************************* Франсуа Олоне. Квест №6 **********************************
 		case "Step_F6_1":
			dialog.text = "A-a-ah ! Eh bien, ça change tout. Installez-vous confortablement pendant que je lis la lettre.";
			link.l1 = "Au fait, monsieur, je tiens à vous informer que les Espagnols s'intéressaient énormément à cette lettre. Ils ont même envoyé un navire de guerre pour intercepter mon navire.";
    		link.l1.go = "Step_F6_2";
            TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
		break;
 		case "Step_F6_2":
			dialog.text = "Je suppose que puisque vous êtes ici, les Espagnols ne reverront pas de sitכt leur navire de guerre, haha ! Oui, ils rêvent de prouver les liens du gouverneur général français avec les flibustiers. Donc, en livrant la lettre intacte, vous nous avez rendu un grand service, à moi et à monsieur d'Ogeron. La récompense sera à la hauteur. Au fait, comment la voudriez-vous ?";
			link.l1 = "Dans quel sens ?";
    		link.l1.go = "Step_F6_3";
		break;
 		case "Step_F6_3":
			dialog.text = "Je peux vous donner un sac d'or. Et je peux vous proposer de participer à une affaire intéressante. Dans cette lettre, le gouverneur général m'informe qu'il y a en ce moment au fort de Cumaná de l'or pour au moins deux cent mille réaux. Ma flottille compte trois navires, et leurs capitaines sont mes compagnons. Joignez-vous à nous et, selon les lois de la Confrérie, nous partagerons le butin en quatre. Alors, qu'en dites-vous ?";
			link.l1 = "Je préfère la première option.";
    		link.l1.go = "Step_F6_WantMoney";
			link.l2 = "Quel corsaire refuserait une affaire brמlante, mais profitable ! Bien sמr que j'en suis !";
    		link.l2.go = "Step_F6_4";
			SaveCurrentQuestDateParam("questTemp");
		break;
 		case "Step_F6_WantMoney":
			dialog.text = "Comme vous voudrez. Voici votre récompense.";
			link.l1 = "Merci, François. Bon, je crois que je vais repartir pour Tortuga...";
    		link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			AddMoneyToCharacter(pchar, 10000);
			pchar.questTemp.State = "Fr6Olone_TakeMoney";
			AddQuestRecord("Fra_Line_6_Olone", "2");
			AddQuestUserData("Fra_Line_6_Olone", "sSex", GetSexPhrase("", "e"));
		break;
 		case "Step_F6_4":
            if (GetCompanionQuantity(pchar) == 1)   // Заставляем геймера избавиться от взятых кубиков.
            {
				if (GetQuestPastDayParam("questTemp") < 6)
				{
					dialog.text = "Eh bien, vous voilà prêt à prendre place dans notre escadre. Bienvenue, et en avant sur Cumaná !";
					link.l1 = "Très bien ! François, quel est le plan d'action pour cette campagne ?";
    				link.l1.go = "Step_F6_5";
				}
				else
				{
					dialog.text = "Eh bien, oם étiez-vous passé pendant tout ce temps ?";
					link.l1 = "Je me débarrassais des navires, comme vous me l'avez dit.";
    				link.l1.go = "Step_F6_7";
				}
            }
            else
            {
				dialog.text = "Collègue, je ne peux vous prendre dans cette affaire que seul, à condition que votre part soit d'un quart. Je n'ai pas besoin d'autres compagnons. Alors débarrassez-vous des navires en trop si vous voulez participer. Et dépêchez-vous !";
				link.l1 = "D'accord, François, je reviens vite.";
    			link.l1.go = "exit";
				link.l2 = "Non, je n'accepte pas cet arrangement. Je crois donc que je préfère prendre mon argent...";
    			link.l2.go = "Step_F6_WantMoney";
				NextDiag.TempNode = "Step_F6_4";
             }
		break;
 		case "Step_F6_5":
			dialog.text = "Le plan est très simple. Nous y allons et nous prenons Cumaná d'assaut. Ensuite, nous trouvons l'or, nous le partageons, et chacun retourne à ses affaires.";
			link.l1 = "Excellent. Eh bien, je suis prêt.";
    		link.l1.go = "Step_F6_6";
		break;
 		case "Step_F6_6":
			dialog.text = "Alors allez à Cumaná, et au plus vite !";
			link.l1 = "Très bien, allons-y...";
    		link.l1.go = "Step_F6_GoOn";
		break;
		case "Step_F6_GoOn":
			//==> формируем эскадру
            LAi_SetActorType(NPChar);
            LAi_ActorSetStayMode(NPChar);
			CharacterIntoCompanionAndGoOut(pchar, npchar, "reload", "reload1", 5, false);
			for (i=1; i<=2; i++)
			{
                sld = GetCharacter(NPC_GenerateCharacter("Captain_"+i, "officer_"+(rand(42)+1), "man", "man", 20, FRANCE, -1, true));
                FantomMakeCoolSailor(sld, SHIP_CORVETTE, "", CANNON_TYPE_CANNON_LBS24, 70, 80, 40);
                FantomMakeCoolFighter(sld, 20, 90, 70, BLADE_LONG, "pistol4", 120);
				sld.Dialog.Filename = "Quest\FraLineNpc_2.c";
				sld.CompanionEnemyEnable = false;
				sld.Abordage.Enable = false; // НЕЛЬЗЯ!
				sld.RebirthPhantom = true;
                SetCompanionIndex(pchar, -1, sti(sld.index));
				sld.DeckDialogNode = "HaveHotBussines";
				SetCharacterRemovable(sld, false);
				LAi_LoginInCaptureTown(sld, true);
			}
            // ==> текущая дата, у генерал-губернатора Куманы потом сверим
            SaveCurrentQuestDateParam("questTemp");
            pchar.TempPerks.QuestTroopers = true; //перк квестового десанта
            // ==> капитулянтская нода губернатору Куманы
			characters[GetCharacterIndex("Cumana_Mayor")].dialog.captureNode = "FraLine6Quest_Attack";
			npchar.DeckDialogNode = "HaveHotBussines";
			AddQuestRecord("Fra_Line_6_Olone", "3");
			AddQuestUserData("Fra_Line_6_Olone", "sSex", GetSexPhrase("", "e"));
			DialogExit();
		break;
		case "Step_F6_7":
			dialog.text = "Vous vous en êtes débarrassé ?";
			link.l1 = "Oui, bien sמr.";
    		link.l1.go = "Step_F6_8";
		break;
 		case "Step_F6_8":
			dialog.text = "Je vous félicite d'y être parvenu, mais il n'y aura pas d'expédition sur Cumaná.";
			link.l1 = "Comment ça, il n'y en aura pas ?!";
    		link.l1.go = "Step_F6_9";
		break;
 		case "Step_F6_9":
			dialog.text = "C'est très simple, "+ GetSexPhrase("mon cher","ma chère") +". Il n'y a plus d'or à Cumaná, on l'a emporté. Dans notre affaire, le temps perdu nous a coמté 200 000 réaux. Voilà...";
			link.l1 = "Bon sang, c'est rageant... Eh bien, alors je vais prendre l'argent qui m'est dמ pour la livraison de la lettre.";
    		link.l1.go = "Step_F6_WantMoney";
		break;
 		case "HaveHotBussines":
			dialog.text = "Capitaine, nous n'avons pas de temps à perdre, nous devons prendre Cumaná d'urgence, avant que l'or ne s'évapore.";
			link.l1 = "Oui, François, nous y arriverons, c'est certain...";
    		link.l1.go = "exit";
		break;
 		case "Step_F6_10":
			dialog.text = "Ta réponse ne me plaît pas, " + pchar.name + ".";
			link.l1 = "Nous arrivons trop tard, François. Le fait est que l'argent est déjà parti pour l'Ancien Monde il y a environ une semaine. Tout cela n'a servi à rien...";
    		link.l1.go = "Step_F6_11";
		break;
 		case "Step_F6_11":
			dialog.text = "Je ne crois pas, "+ GetSexPhrase("mon cher","ma chère") +". Et je pense que c'est à cause de toi que nous ne sommes pas arrivés à temps !";
			link.l1 = "Une affirmation discutable, ami l'Olonnais. Très discutable...";
    		link.l1.go = "Step_F6_12";
		break;
 		case "Step_F6_12":
			dialog.text = "Je pense qu'il est temps de régler tous nos différends. Aux armes, "+ GetSexPhrase("monsieur","mademoiselle") +" ! Voyons de quelle couleur est ton sang...";
			link.l1 = "Dieu m'est témoin, je ne veux pas me battre avec toi !";
    		link.l1.go = "Step_F6_13";
		break;
 		case "Step_F6_13":
			dialog.text = "Alors je vais te tuer comme un chien de lâche ! Dernière chance : prends les armes.";
			link.l1 = "Très bien, François, ou quel que soit ton nom... Tu l'auras voulu.";
    		link.l1.go = "Step_F6_fight";
			LAi_group_Delete("EnemyFight");
			AddQuestRecord("Fra_Line_6_Olone", "4");
		break;
 		case "Step_F6_fight":
			NPChar.LifeDay = 0;
			DeleteAttribute(NPChar, "RebirthPhantom");
			for (i=1; i<=2; i++)
			{
				sld = characterFromId("Captain_"+i);
				sld.LifeDay = 0;
				DeleteAttribute(sld, "RebirthPhantom");
			}
			chrDisableReloadToLocation = true;
			pchar.questTemp.State = "Fr6Olone_OloneIsDead";
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
 		case "Step_F6_14":
			if (sti(pchar.money) >= 200000)
			{
				dialog.text = "Excellent, compagnon ! Partageons l'argent et rentrons chez nous.";
				link.l1 = "Adieu, l'Olonnais. J'ai encore un peu à faire en ville...";
    			link.l1.go = "Step_F6_15";
				link.l2 = "Mais je pense que je n'ai pas à partager avec toi. C'est moi qui ai fait tout le travail !";
    			link.l2.go = "Step_F6_20";
			}
			else
			{
				dialog.text = "Tu as trouvé l'argent, et tu ne l'as pas sur toi. Tu as essayé de me rouler ?!";
				link.l1 = "Qu'est-ce qui te prend, François ?!";
    			link.l1.go = "Step_F6_17";
			}
		break;
 		case "Step_F6_15":
			dialog.text = "Prends soin de toi, mais ne traîne pas trop : il pourrait y avoir des Espagnols dans les parages.";
			link.l1 = "D'accord, François. Porte-toi bien...";
    		link.l1.go = "Step_F6_16";
			AddMoneyToCharacter(pchar, -150000);
		break;
 		case "Step_F6_16":
			chrDisableReloadToLocation = true;
			NPChar.LifeDay = 0;
			DeleteAttribute(NPChar, "RebirthPhantom");
			for (i=1; i<=2; i++)
			{
				iTemp = GetCharacterIndex("Captain_"+i)
				if (iTemp > 0)
				{
					sld = &characters[iTemp];
					sld.LifeDay = 0;
					DeleteAttribute(sld, "RebirthPhantom");
				}
			}
			AddQuestRecord("Fra_Line_6_Olone", "5");
			pchar.questTemp.State = "Fr6Olone_OloneIsLive";
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1_back", "none", "", "", "CanFightCurLocation", -1);
			LAi_LocationFightDisable(&Locations[FindLocation("Cumana_town")], true);
            DialogExit();
		break;
 		case "Step_F6_17":
			dialog.text = "Et moi, je pense que tu es en train de me rouler, "+ GetSexPhrase("l'ami","ma petite") +"... Mais il y a un moyen de le savoir : sors ta lame.";
			link.l1 = "Un combat ?";
    		link.l1.go = "Step_F6_18";
		break;
 		case "Step_F6_18":
			dialog.text = "Exactement. Le rat doit être puni...";
			link.l1 = "D'accord, tu l'auras voulu.";
    		link.l1.go = "Step_F6_fight";
			LAi_group_Delete("EnemyFight");
			AddQuestRecord("Fra_Line_6_Olone", "6");
			LAi_LocationFightDisable(&Locations[FindLocation("Cumana_town")], false);
			//==> кэпов в подмогу Олоне, пенальти за попытку сшустрить.
			for (i=1; i<=2; i++)
			{
				iTemp = GetCharacterIndex("Captain_"+i)
				if (iTemp > 0)
				{
					sld = &characters[iTemp];
					LAi_SetWarriorType(sld);
					ChangeCharacterAddress(sld, "Cumana_town", LAi_FindRandomLocator("goto"));
					LAi_group_MoveCharacter(sld, "EnemyFight");
				}
			}
		break;
 		case "Step_F6_20":
			dialog.text = "Ah, c'est comme ça ?! Eh bien, prépare-toi au pire...";
			link.l1 = "Toujours prêt, François...";
    		link.l1.go = "Step_F6_21";
		break;
 		case "Step_F6_21":
			NPChar.LifeDay = 0;
			LAi_group_Delete("EnemyFight");
			AddQuestRecord("Fra_Line_6_Olone", "8");
			AddQuestUserData("Fra_Line_6_Olone", "sSex", GetSexPhrase("", "e"));
			LAi_LocationFightDisable(&Locations[FindLocation("Cumana_town")], false);
			//==> кэпов в подмогу Олоне, пенальти за попытку сшустрить.
			for (i=1; i<=2; i++)
			{
				iTemp = GetCharacterIndex("Captain_"+i)
				if (iTemp > 0)
				{
					sld = &characters[iTemp];
					sld.LifeDay = 0;
					DeleteAttribute(sld, "RebirthPhantom");
					LAi_SetWarriorType(sld);
					ChangeCharacterAddress(sld, "Cumana_town", LAi_FindRandomLocator("goto"));
					LAi_group_MoveCharacter(sld, "EnemyFight");
				}
			}
			chrDisableReloadToLocation = true;
			pchar.questTemp.State = "Fr6Olone_OloneIsDead";
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Маркиз Бонрепо. Квест №8 **********************************
 		case "Step_F8_1":
			dialog.text = "Ah, enfin ! Je commençais à m'inquiéter. Le gouverneur général d'Ogeron m'a dit beaucoup de choses flatteuses sur vous. J'espère que vous justifierez pleinement sa confiance et la mienne. Et gardez à l'esprit que tout ce que vous entendrez ici ne doit jamais être connu de personne d'autre que vous.";
			link.l1 = "J'avais été prévenu...";
    		link.l1.go = "Step_F8_2";
		break;
 		case "Step_F8_2":
			dialog.text = "Parfait ! Alors, venons-en au fait\n"+
				          "La situation actuelle de la politique européenne est très difficile. Une nouvelle guerre commerciale se prépare entre l'Angleterre et la Hollande, et notre grand Roi-Soleil Louis XIV entame une guerre de Dévolution contre l'Espagne.";
			link.l1 = "Pardonnez-moi, marquis... Quelle guerre ? De révolution ?!";
    		link.l1.go = "Step_F8_3";
		break;
 		case "Step_F8_3":
			dialog.text = "Hum... oui, un simple corsaire ne saurait pas cela.\n"+
				          "La guerre de Dévolution est une guerre pour des droits héréditaires sur certains territoires. Pour la France, il s'agit sans aucun doute d'une partie de la Flandre et de la Bourgogne, aujourd'hui sous domination espagnole. C'est une bonne cause, car les Hollandais cherchent depuis cent ans à secouer le joug de ces démons d'Espagnols en habits d'église.\n"+
						  "Pour mener cette guerre à bien, nous avons cruellement besoin de l'argent hollandais ; il faut donc empêcher les Anglais d'attaquer leurs colonies. Cette mission est supervisée personnellement par Jean-Baptiste Colbert ; j'espère que vous savez qui c'est...";
			link.l1 = "Comment dois-je m'y prendre ?";
    		link.l1.go = "Step_F8_4";
		break;
 		case "Step_F8_4":
			dialog.text = "Les Hollandais sont capables de se défendre si le gouverneur général de la Jamaïque, sir Thomas Madiford, ne reçoit pas de renforts. Et dans ces eaux, ils ne peuvent compter que sur l'aide de corsaires célèbres, qui ont du poids et de l'autorité au sein de la Confrérie de la Cכte.\n"+
				          "Il n'y a que trois hommes qui pourraient sérieusement influer sur le cours de la guerre : Henry Morgan à la Jamaïque, Jackman dans la colonie pirate des Bermudes et John Morris à la Trinité. Votre mission est de les rencontrer chacun et de les convaincre de n'attaquer en aucun cas les colonies et les navires hollandais. Pour ces gens-là, l'essentiel, c'est le profit, alors ne lésinez pas sur les dépenses !";
			link.l1 = "Et oם dois-je prendre ces fonds ?";
    		link.l1.go = "Step_F8_5";
		break;
 		case "Step_F8_5":
			dialog.text = "J'avoue que vous m'étonnez. On vous a recommandé à moi comme quelqu'un d'extrêmement intelligent et débrouillard ! Si j'avais ces fonds, pourquoi aurais-je besoin de votre aide ? Cependant, vous avez le droit de refuser, mais...";
			link.l1 = "Mais alors quoi ?";
    		link.l1.go = "Step_F8_6";
		break;
 		case "Step_F8_6":
			dialog.text = "Alors je devrai vous envoyer en prison. Après tout, vous êtes désormais dépositaire de secrets d'וtat ! Avec de telles connaissances, les gens déloyaux ne restent pas en liberté.";
			link.l1 = "Il faudra d'abord m'arrêter, et ce n'est pas si facile !";
    		link.l1.go = "Step_F8_Fight";
			link.l2 = "Eh bien, si le roi ne peut se passer de mes piastres, soit, je l'aiderai !";
    		link.l2.go = "Step_F8_7";
		break;
 		case "Step_F8_Fight":
			CloseQuestHeader("Fra_Line_8_ThreeCorsairs");
			SetNationRelation2MainCharacter(FRANCE, RELATION_ENEMY);
            for (i=1; i<=4; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("Guard_"+i, "Sold_fra_"+(rand(7)+1), "man", "man", 30, FRANCE, 0, true));
				FantomMakeCoolFighter(sld, 30, 65, 50, BLADE_LONG, "pistol3", 40);
            	LAi_SetWarriorType(sld);
                LAi_group_MoveCharacter(sld, "FRANCE_CITIZENS");
               	ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
            }
			LAi_group_AttackGroup("FRANCE_CITIZENS", LAI_GROUP_PLAYER);
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(NPChar, "reload", "reload1", "none", "", "", "CanFightCurLocation", 10.0);
			NPChar.LifeDay = 0;
			pchar.questTemp.State = "QuestLineBreake";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "2");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
 		case "Step_F8_7":
			dialog.text = "C'est parfait ! D'Ogeron ne s'était pas trompé sur vous. Bien, j'attends votre retour avec de bonnes nouvelles.";
			link.l1 = "Je ferai tout, marquis.";
    		link.l1.go = "exit";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "3");
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.State = "Fr8ThreeCorsairs_toSeek";
			SaveCurrentQuestDateParam("questTemp");
            // ==>  Помещаем Моргана на Антигуа и даём ноду доступа к квестам
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "SentJons_HouseF3", "goto", "goto1");
            QuestSetCurrentNode("Henry Morgan", "FraLine8_talk");
            sld = characterFromID("Henry Morgan");
            LAi_SetHuberStayType(sld);
			LAi_group_MoveCharacter(sld, "PeaceGroup");
            LAi_SetLoginTime(sld, 0.0, 24.0);
            // ==>  Генерим и помещаем Джона Морриса в Бриджтаун и даём ноду доступа к квестам
            sld = GetCharacter(NPC_GenerateCharacter("John Morris", "bocman", "man", "man", 38, PIRATE, -1, false));
        	sld.name 	= "John";
        	sld.lastname = "Morris";
            sld.Dialog.Filename = "Quest\JohnMorris.c";
			sld.greeting = "Gr_HeadPirates";
           	LAi_SetHuberType(sld);
			LAi_group_MoveCharacter(sld, "PeaceGroup");
        	LAi_SetLoginTime(sld, 0.0, 24.0);
            ChangeCharacterAddressGroup(sld, "PortSpein_houseF2", "sit", "sit1");
            LAi_LocationFightDisable(&Locations[FindLocation("PortSpein_houseF2")], true);
            // ==>  Даём ноду доступа к квестам Джону Моррису
            QuestSetCurrentNode("John Morris", "FraLine8_talk");
            // ==>  Даём ноду доступа к квестам Джекмену
            QuestSetCurrentNode("Jackman", "FraLine8_talk");
            // ==>  Оформляем счётчик посещения корсаров, в итоге должен == 3
            pchar.questTemp.Count = "0";
		break;
 		case "Step_F8_9":
			dialog.text = "Je dois dire que c'était l'une des missions diplomatiques les plus difficiles que j'aie jamais confiées à quelqu'un. Une personne qui s'acquitte si brillamment de telles affaires ne devrait tout simplement pas rester roturière. Par bonheur, j'ai reçu le pouvoir de vous conférer "+ GetSexPhrase("le titre de baron","le titre de baronne") +" ! La France a besoin de gens comme vous !";
			link.l1 = "Euh... ah... "+ GetSexPhrase("Le titre de baron","Le titre de baronne") +" ? Et qu'en est-il des dépenses que j'ai engagées pour cela ?";
    		link.l1.go = "Step_F8_10";
		break;
 		case "Step_F8_10":
			dialog.text = "Un pirate restera toujours un pirate ! Ha ha !\n"+
				          "Croyez-moi, "+ GetSexPhrase("mon très cher","ma chère") +", je vous donne bien plus qu'un vil métal ! Je vous donne l'honneur et le respect du roi lui-même ! Et maintenant, je n'ose pas vous retenir : le gouverneur général d'Ogeron vous attend. Il semble qu'il ait de nouveau une affaire importante pour vous... Au revoir.";
			link.l1 = "Au revoir, intendant Bonrepos...";
    		link.l1.go = "Step_F8_11";
		break;
 		case "Step_F8_11":
			pchar.questTemp.State = "Fr8ThreeCorsairs_backGovernor";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "8");
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("Fra_Line_8_ThreeCorsairs", "sSex2", GetSexPhrase("", "e"));
            LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "", 6.0);
			if (PChar.sex == "woman")
			{
			pchar.name = "Baronne " + pchar.name;
			}
			else
			{
			pchar.name = "Baron " + pchar.name;
			}
            DialogExit();
		break;
//********************************* Конец войне. Квест №12 **********************************
 		case "Step_F12_1":
			dialog.text = "Alors, comme vous le savez déjà, la guerre de Dévolution contre l'Espagne est terminée. L'Espagne est vaincue !";
			link.l1 = "Oui, marquis, c'est une excellente nouvelle.";
    		link.l1.go = "Step_F12_2";
		break;
 		case "Step_F12_2":
			dialog.text = "Vos mérites ont été appréciés : Louis lui-même connaît votre nom, désormais...";
			link.l1 = "Marquis, pour être honnête, j'aimerais une appréciation un peu différente de mes services rendus à la France.";
    		link.l1.go = "Step_F12_3";
		break;
 		case "Step_F12_3":
			dialog.text = "Que voulez-vous dire ?";
			link.l1 = "Je parle d'une compensation financière pour mes dépenses dans cette guerre. J'ai porté seul le fardeau de la lutte contre les Espagnols, et je souhaite être dédommagé.";
    		link.l1.go = "Step_F12_4";
		break;
 		case "Step_F12_4":
			dialog.text = "וcoutez, vous avez été "+ GetSexPhrase("anobli","anoblie") +" ! On vous connaît au Louvre ! Cela ne vous suffit pas ?!";
			link.l1 = "Pour mon amour-propre, c'est plus que suffisant. Mais je vous parle d'autre chose : d'argent...";
    		link.l1.go = "Step_F12_5";
		break;
 		case "Step_F12_5":
			dialog.text = ""+ GetSexPhrase("Baron","Baronne") +", ne me prenez pas pour un imbécile, je ne vous demande pas de rendre compte des trophées pris dans les villes. Ce sont là vos honoraires.";
			link.l1 = "Hum, maintenant, c'est clair...";
    		link.l1.go = "Step_F12_6";
		break;
 		case "Step_F12_6":
			dialog.text = "C'est très bien que nous ayons éclairci toutes les nuances, "+ GetSexPhrase("Baron","Baronne") +". Et maintenant, venons-en au fait : le Soleil Royal est retiré de votre escadre.";
			link.l1 = "Je vois...";
    		link.l1.go = "Step_F12_7";
		break;
 		case "Step_F12_7":
			dialog.text = "Dans un mois, j'envoie ce magnifique navire dans l'Ancien Monde. Je vous suis donc reconnaissant de l'avoir maintenu en bon état.";
			link.l1 = "Merci pour votre gratitude, marquis...";
    		link.l1.go = "Step_F12_8";
		break;
 		case "Step_F12_8":
			dialog.text = "Je vous en prie, "+ GetSexPhrase("Baron","Baronne") +"... Bon, je n'ose pas vous retenir plus longtemps, au revoir.";
			link.l1 = "Bonne journée, marquis.";
    		link.l1.go = "exit";
			npchar.LifeDay = 0;
			pchar.questTemp.State = "EndOfQuestLine";
			bWorldAlivePause   = false; // Конец линейки
			AddQuestRecord("Fra_Line_12_EndOfWar", "2");
			AddQuestUserData("Fra_Line_12_EndOfWar", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Fra_Line_12_EndOfWar", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("Fra_Line_12_EndOfWar");
            DeleteAttribute(pchar, "questTemp.Waiting_time");
			//==> в течение месяца Солей Руаяль можно взять себе.
			sld = characterFromId("SoleiRoyalCaptain");
			RemoveCharacterCompanion(pchar, sld);
			SetCrewQuantityFull(sld);
			Fantom_SetBalls(sld, "pirate");
			Group_SetType("SoleiRoyal", "war");
			Group_AddCharacter("SoleiRoyal", "SoleiRoyalCaptain");
			Group_SetGroupCommander("SoleiRoyal", "SoleiRoyalCaptain");
			Group_SetAddress("SoleiRoyal", "Guadeloupe", "Quest_ships", "quest_ship_1");
			SetTimerCondition("Fr12EndOfWar_TakeOutShip", 0, 0, 30, false);
			AddTitleNextRate(sti(NPChar.nation), 5);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
			AddCharacterExpToSkill(pchar, "Repair", 630);
			AddCharacterExpToSkill(pchar, "Sneak", 490);
			AddCharacterExpToSkill(pchar, "FencingLight", 530);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 530);
			AddCharacterExpToSkill(pchar, "Fencing", 530);
			AddCharacterExpToSkill(pchar, "Pistol", 530);
			AddCharacterExpToSkill(pchar, "Fortune", 660);
			AddCharacterExpToSkill(pchar, "Accuracy", 520);
			AddCharacterExpToSkill(pchar, "Grappling", 750);
			//слухи
			AddSimpleRumour("On dit que vous êtes désormais "+ GetSexPhrase("Baron","Baronne") +" ! Le destin vous sourit, capitaine...", sti(npchar.nation), 5, 1);
		break;
    }
}
