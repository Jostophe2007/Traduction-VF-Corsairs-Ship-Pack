// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_PK_UznatLichnost"))	// Квест "The Lost Ring"
            {
                link.l1 = "Parlez-moi d'une femme étrange qui a perdu sa bague. Vous la connaissez ?";
                link.l1.go = "PDM_PK_UznatLichnost";
            }
		break;
//******************** квест "The Lost Ring" ******************
		case "PDM_PK_UznatLichnost":
			dialog.text = "Elle n'a pas simplement perdu une bague. C'est une terrible histoire. J'en ai le cœur brisé chaque fois que je la raconte. Elle s'appelle Josephine Lodet. Elle avait offert une magnifique bague à son fils la veille de son premier voyage. Pour lui porter chance, disait-elle. Il a pris part à l'attaque de Santo Domingo et il a été tué au premier combat. Quand la nouvelle de sa mort est arrivée sur nos rivages, la pauvre Josephine... Enfin, vous avez des yeux, vous avez vu ce qui lui est arrivé.",
			link.l1 = "Quel genre de bague était-ce ?";
			link.l1.go = "PDM_PK_UznatLichnost_2";
        break;

		case "PDM_PK_UznatLichnost_2":
			dialog.text = "Un bijou très beau et très cher. Le plus beau saphir que j'aie jamais vu, serti dans de l'or. C'est son grand-père qui l'avait apporté d'Europe. Je ne suis pas joaillier, mais il pouvait valoir dix... ou vingt mille ? Ah, quelle terrible histoire ! Parlons d'autre chose. Ou bien vous voulez boire quelque chose ?";
			Link.l1 = "Je ferais mieux de partir, " + npchar.name+". Nous parlerons une autre fois.";
			Link.l1.go = "exit";

			sld = CharacterFromID("Josephine_Lodet")
			sld.name = "Josephine";
			sld.lastname = "Lodet";

			AddQuestRecord("PDM_Poteryanoe_Koltso", "2");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));

			pchar.questTemp.PDM_PK_IshemKoltso = "IshemKoltso";
			DeleteAttribute(pchar, "questTemp.PDM_PK_UznatLichnost");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

