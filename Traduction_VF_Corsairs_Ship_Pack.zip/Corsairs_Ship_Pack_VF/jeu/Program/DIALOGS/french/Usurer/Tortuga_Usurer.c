// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
			if (CheckAttribute(pchar, "questTemp.PDM_PI_Rostov"))	//Квест 'Проклятый Идол'
			{
    			link.l1 = "Je veux vous faire un cadeau. J'ai entendu dire que vous vous intéressiez aux pierres précieuses... Que dites-vous de cette idole ?";
				link.l1.go = "PDM_PI_Rostov_2";
			}
			switch(pchar.questTemp.State)
            {
                case "WormEnglPlans_WormPicarder": //Голландская линейка, квест №3. узнаем о Пеьере Пикардийце.
                    link.l2 = "וcoutez, j'aimerais vous proposer une opération financière...";
                    link.l2.go = "Step_H3_1";
                break;

            }
             // <== Проверяем поле состояния квестов.
		break;

		//Квест 'Проклятый Идол'
		case "PDM_PI_Rostov_2":
			dialog.text = "Oh oh oh ! Oh, mon Dieu ! "+ GetSexPhrase("Monsieur", "Mademoiselle") +" "+pchar.name+" ! Quelle merveille ! C'est formidable ! Oui, cette idole peut racheter les dix péchés capitaux !";
			link.l1 = "Elle a l'air de vous plaire. Elle est à vous.";
			link.l1.go = "PDM_PI_Rostov_3";
        break;

		case "PDM_PI_Rostov_3":
			dialog.text = "Vous m'avez fait un cadeau inestimable, "+ GetSexPhrase("monsieur", "mademoiselle") +" "+pchar.name+". Je vous en suis extrêmement reconnaissant. Je vous récompense de 45 000 pièces d'or : personne ne dira que je suis un avare ! D'ailleurs, "+ GetSexPhrase("monsieur", "mademoiselle") +" "+pchar.name+", je crois que je vais envoyer cette idole à Sa Majesté ! J'ai entendu dire qu'il raffolait justement de ce genre de curiosités.";
			link.l1 = "Je suis très heureux que mon cadeau se soit révélé si utile.";
			link.l1.go = "PDM_PI_Rostov_4";
			AddMoneyToCharacter(pchar, 45000);
			Log_info("Vous avez offert une idole à un usurier");
			TakeItemFromCharacter(pchar, "Cursed_idol");
        break;

		case "PDM_PI_Rostov_4":
			dialog.text = "Oui, oui, votre cadeau tombait à point. Mais je dois vous demander de partir. Je veux admirer... euh, je veux dire, je veux réfléchir à la façon d'envoyer cette idole à Sa Majesté.";
            link.l1 = "(une porte s'ouvre derrière vous)";
			link.l1.go = "Rostovshik_5";
			bDisableFastReload = true;
			DeleteAttribute(pchar, "questTemp.PDM_PI_Rostov");
			DeleteAttribute(pchar, "questTemp.PDM_PI_Skelety_v_more");
        break;

		case "Rostovshik_5":
			DialogExit();
			int Phrase;
			Phrase = rand(4);
			if (Phrase == 0)
            {
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_Bandit_1", "skel1", "skeleton", "skeleton", sti(pchar.rank), PIRATE, -1, true));
				FantomMakeCoolFighter(sld, sti(pchar.rank), 15 + MOD_SKILL_ENEMY_RATE * 5, 15 + MOD_SKILL_ENEMY_RATE* 5, "blade19", "", 20);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1");
				LAi_SetActorType(sld);
				sld.dialog.filename   = "Quest\PDM\Cursed_Idol.c";
				sld.dialog.currentnode   = "Rostovshik_Fra_Off_3";
				LAi_ActorDialog(sld, pchar, "", -1, 0);
				sld.SaveItemsForDead = true;
				sld.DontChangeBlade = true;
				sld.DeleteFood = true;
				AddMoneyToCharacter(sld, 7000);
				AddItems(sld, "jewelry1", 25);
				AddItems(sld, "jewelry7", 10);
				AddItems(sld, "compcraft_copper", 20);
				AddItems(sld, "compcraft_grindstone", 20);
			break;
			}
			else
            {
				sld = GetCharacter(NPC_GenerateCharacter("PDM_PI_Bandit_1", "pirate_22", "man", "man", sti(pchar.rank), PIRATE, -1, true));
				FantomMakeCoolFighter(sld, sti(pchar.rank), 15 + MOD_SKILL_ENEMY_RATE * 5, 15 + MOD_SKILL_ENEMY_RATE* 5, "blade19", "", 20);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1");
				LAi_SetActorType(sld);
				sld.dialog.filename   = "Quest\PDM\Cursed_Idol.c";
				sld.dialog.currentnode   = "Rostovshik_Fra_Off_1";
				LAi_ActorDialog(sld, pchar, "", -1, 0);
				sld.SaveItemsForDead = true;
				sld.DontChangeBlade = true;
				sld.DeleteFood = true;
				AddMoneyToCharacter(sld, 7000);
				AddItems(sld, "jewelry1", 25);
				AddItems(sld, "jewelry7", 10);
				AddItems(sld, "compcraft_copper", 20);
				AddItems(sld, "compcraft_grindstone", 20);
			break;
			}
		break;

		//Голландская линейка, квест №3
 	 	case "Step_H3_1":
			dialog.text = NPCStringReactionRepeat("Je vous préviens tout de suite : je n'accepte pas de dépכts. Mais pour emprunter, je vous en prie.", "Encore la même opération financière ?", "On vient encore me proposer de l'argent ?", "Occupons-nous d'affaires sérieuses, au lieu de bavarder.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Pourquoi donc ?", "Oui, encore la même chose...", "Encore...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H3_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H3_2":
			dialog.text = "Pierre Picardy m'a confié une somme considérable, j'aimerais faire fructifier cet argent. Alors, vous le prenez ?";
			link.l1 = "Non, je voulais juste vous donner l'argent.";
			link.l1.go = "exit";
            pchar.questTemp.Talks.Usurer = true;
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "10");
        break;



	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

