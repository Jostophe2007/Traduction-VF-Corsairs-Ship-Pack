// Gregg: Charly Grand Pipiska, the contact at the pearl fishery - quest
// "Goods for Richard Tillman" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\uneasydelivery.c
//
// Node 1 requires the key phrase to be typed in. The correct one is
// "That is fine, that is good" - Prenol's catchphrase, which Shon points out
// after reading the letter taken from Tillman's killer. It must match the wording
// in UD_Prenol.c (nodes 9 and 18) and UD_Shon.c (node 20).

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Toi être celui qui traite avec Cœur de Lion ? Dire phrase clé.";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "2";
			NextDiag.TempNode = "1";
		break;

		case "2":
			string sString = GetStrSmallRegister(dialogEditStrings[1]);
			// Gregg: a homogeneous chain of || - mixing it with && in one if is not allowed
			if (DozorAnswerOk(sString, "c'est très bien, c'est parfait|c'est tres bien, c'est parfait|c'est très bien c'est parfait|c'est tres bien c'est parfait|c'est très bien, c'est parfait !|c'est tres bien, c'est parfait !|c'est très bien, c'est parfait!|c'est tres bien, c'est parfait!|that is fine, that is good|that is fine that is good"))
			{
				// Gregg: Damned Destiny had Charly hand over 25,000 - the killers' fee. The sums of the quest
				// are cut by a factor of ten (the hoard is 50,000 instead of 300,000),
				// and this one by the same, for consistency.
				AddMoneyToCharacter(PChar, 10000);
				dialog.text = "Voilà ton argent.";
				link.l1 = "וcoute, Charly, mes hommes et moi ne sommes pas contents de notre part du gâteau, ils en veulent plus. Je dois voir Prenol pour lui réclamer plus d'argent. Oם peut-on le trouver ?";
				link.l1.go = "3";
			}
			else
			{
				dialog.text = "Phrase clé fausse. Charly plus faire affaire avec Frère Blanc.";
				link.l1 = "Argh !..";
				link.l1.go = "exit";
				AddDialogExitQuestFunction("UneasyDeliveryDialogWithCharlyFailed");
			}
		break;

		case "3":
			dialog.text = "Charly pas savoir oם être Prenol. Charly seulement remettre argent. Charly rien faire de plus.";
			link.l1 = "Charly, tu ne veux pas d'ennuis, n'est-ce pas ? Non ? Dis-moi oם est Prenol et tu n'en auras pas.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Charly pas comprendre ce que Frère Blanc dire. Charly pas comprendre.";
			link.l1 = "Tu comprends très bien. Je vais le redire une fois. Toi pas dire oם est Prenol, ennuis, mauvais pour Charly. Toi dire oם est Prenol, pas d'ennuis, bon pour Charly.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Charly rien savoir, Charly seulement faire son travail, remettre argent.";
			link.l1 = "Alors ce sont des ennuis, Charly. Très bien, je vais t'en arranger quelques-uns...";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Non ! Non ! Charly dire, Charly dire ! Chercher Prenol sur île Bermudes, sur île Bermudes, Prenol être là-bas, Charly savoir pour sמr.";
			link.l1 = "Merci.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Frère Blanc ! Pas dire à Prenol que Charly dire ça à toi, pas trahir Charly, Charly juste pas vouloir de mal.";
			link.l1 = "Très bien, je ne dirai rien.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Charly pas coupable, Charly pas vouloir de mal. Toi pas trahir Charly ?";
			link.l1 = "Je ne te trahirai pas. Maintenant, laisse-moi tranquille.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryDialogWithCharlyGood");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
