// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "KillLoy_toSeek")
			{
				link.l1 = "On dit qu'Edward Law devait s'adresser à vous, je le cherche.";
				link.l1.go = "PL_Q3_1";
			}
		break;
		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Il est venu me voir, il m'a demandé de l'argent. Je ne lui en ai pas donné. Un gars très glissant, le regard fuyant, qui avait manifestement l'intention de filer. Je crois pouvoir dire que je sais juger les gens.",
				"J'ai déjà tout dit à ce sujet, cherchez par vous-même.",
				"Encore ?",
                "Fichez le camp !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oם ça...",
				"Je vois.",
                "Oui, désolé...",
				"Je vois, je m'en vais.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q3_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q3_2":
			dialog.text = "Et je n'ai aucune idée de l'endroit oם il a pu aller.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "5");
			AddQuestUserData("Pir_Line_3_KillLoy", "sSex", GetSexPhrase("", "e"));
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

