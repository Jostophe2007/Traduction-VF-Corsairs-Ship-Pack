# Traduction française — Corsairs Ship Pack

Ce dossier contient tout ce qui sert à produire la version française du jeu
(langue `french` du moteur Storm). Les fichiers de langue anglais et russes ne sont pas modifiés.
Quelques scripts communs à toutes les langues reçoivent une branche française (voir plus bas) :
leur comportement en anglais et en russe reste identique.

## Ce qui est installé dans le jeu
| Élément | Emplacement |
|---|---|
| Textes d'interface | `RESOURCE\INI\texts\french\` |
| Dialogues | `Program\DIALOGS\french\` |
| Journal de quêtes | `Program\questbook\french\` |
| Noms (persos, navires) | `Program\characters\french\`, `Program\Ships\french\` |
| Polices avec accents | `RESOURCE\INI\fonts_fra.ini` + `RESOURCE\Textures\fonts\* fr.tga.tx` |
| Panneaux du menu principal | `RESOURCE\Textures\MainMenu\French\` (Text01/Text02 en français) |
| Voix / sons | `RESOURCE\Sounds\Voice\French` (jonction vers English), `RESOURCE\Sounds\Interface\French_*.wav`, `RESOURCE\INI\aliases\french\` |
| Langue active | `RESOURCE\INI\texts\language.ini` → `defaultLanguage = french` |

L'original de `language.ini` est sauvegardé dans `backup\`.

## Ce qui reste en anglais
- L'historique des versions du mod (journal de quêtes › Aide › « Liste complète des modifications »,
  environ 210 000 caractères destinés aux développeurs).
- Les messages de débogage et de triche (console, mode Dieu…), ainsi que les rares textes de scripts
  qui n'ont pas été repérés.

## Installer sur un autre PC
`tools\make_package.py` crée `Traduction_VF_Corsairs_Ship_Pack.zip` dans le dossier du jeu. Sur l'autre PC :
décompresser, lancer `INSTALLER_VF.bat`, choisir le dossier du jeu. L'installateur vérifie la version des
scripts du jeu, sauvegarde les originaux (`FR_Traduction\backup\avant_installation`) et règle la langue.
`FR_Traduction\Desinstaller_VF.bat` annule l'installation. Sources de l'installateur : `tools\installer\`.

## Changer de langue
- `Langue_Francais.bat` / `Langue_Anglais.bat` / `Langue_Russe.bat` (dans ce dossier).
- Attention : les boutons RU/EN du lanceur réécrivent `language.ini` ; relancez `Langue_Francais.bat` si besoin.

## Après une mise à jour du jeu
Relancer `Regenerer_FR.bat` (Python 3 requis) : les fichiers français sont reconstruits à partir des fichiers
anglais à jour et des mémoires de traduction (`tm\`), puis les correctifs de scripts sont réappliqués.
Les phrases nouvelles ou modifiées restent en anglais jusqu'à leur traduction.

## Scripts du jeu modifiés (`tools\patch_code.py`)
Copie intacte de chaque fichier dans `backup\code\` ; `python -X utf8 patch_code.py --undo` les restaure.
Chaque ajout est marqué `// FR_PATCH` ou passe par la fonction `FrS("anglais", "français")`.
- Noms de nations, couronnes et souverains (`Dialog_func.c`, `scripts\Siege.c`).
- Journal de quêtes : accords féminins `@<sSex>` (`Quests\quests.c`), lieux du marchand d'esclaves
  (`slavetrader.c`), spécialité du savant prisonnier (`GenQuests_CaptainComission.c`).
- Énigmes de « La Veille » (`Addons\Quests.c`, `INTERFACE\Mekakhrom.c`) : chiffrages et acrostiches refaits
  en français ; plusieurs réponses acceptées, avec ou sans accents.
- Quiz maritime (taverne et chantier naval pirate, `characters\Questions.c`, `SeaQuestions.c`) : 74 questions
  avec les termes de marine français (réponses alternatives acceptées).
- Messages écrits en dur dans les scripts (`tm\code_strings.json`) : Compagnie des Indes occidentales (GWIC),
  infirmerie, santé, réputation auprès des nations, nouvelles historiques, jurons, salutations,
  répliques d'agacement des PNJ, écrans de transition, embuscades…

## Outils (`tools\`)
- `fr.py status` — avancement ; `fr.py next` — lot à traduire ; `fr.py import` — import d'un lot ; `fr.py build` — génération.
- `patch_code.py` — branche française des scripts communs (voir ci-dessus).
- `make_package.py` — crée le .zip d'installation pour un autre PC (à relancer après chaque modification).
- `build_fonts.py` — génère les glyphes accentués (é è à ç ê œ « » …) dans de nouvelles textures de police.
- `make_menu_textures.py` — génère les panneaux du menu principal en français.
- `..\fixups.txt` — corrections ponctuelles du code français généré (jointures de phrases, réponses d'énigmes).

### Particularité des polices
La police d'interface `INTERFACE_NORMAL` utilise certaines lettres (À É Ç ô ù û…) comme **icônes**.
Dans les fichiers français générés, ces 16 lettres sont donc écrites avec des codes de remplacement
(U+05D0 à U+05DF, lettres hébraïques que le jeu n'utilise jamais) que `fonts_fra.ini` affiche comme
des lettres accentuées. Ces codes doivent rester sous la limite de la table des polices du moteur
(les polices d'origine s'arrêtent à U+2039) : les codes privés U+E0xx des premières versions la
dépassaient et provoquaient des plantages aléatoires (astuces du menu principal). Dans les mémoires `tm\`, le texte reste normal ;
la notation `⟦X⟧` force un caractère-icône à rester tel quel. Les réponses que le joueur tape
(énigmes, quiz) ne sont **pas** converties.
