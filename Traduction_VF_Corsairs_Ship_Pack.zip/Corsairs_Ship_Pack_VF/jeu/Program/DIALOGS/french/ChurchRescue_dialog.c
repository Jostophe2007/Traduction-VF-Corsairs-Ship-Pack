// Диалог главаря похитителей (церковный квест №4 "Вызволение монаха")
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref rChar;
	int i, iCaptors;
	string sTitle;

	switch(Dialog.CurrentNode)
	{
		case "ChurchRescue_Captor_Start":
			dialog.text = "Halte ! Pas un pas de plus. Ce petit saint homme est notre marchandise, maintenant. Donne " + FindRussianMoneyString(sti(PChar.GenQuest.ChurchRescue.Ransom)) + " et emmène-le. Ou couche-toi ici, à cכté de lui.";
			if (sti(PChar.money) >= sti(PChar.GenQuest.ChurchRescue.Ransom))
			{
				link.l1 = "Voici la rançon. Libérez le frère, et nous nous quitterons en paix.";
				link.l1.go = "ChurchRescue_Captor_Pay";
			}
			link.l2 = "Avec les coupe-jarrets, je ne parle que par l'acier. Défendez-vous !";
			link.l2.go = "ChurchRescue_Captor_Fight";
				link.l3 = "וcoutez bien : la Sainte Inquisition protège ce moine. Touchez-y, et vous brמlerez à petit feu. Laissez-le partir tranquillement.";
				link.l3.go = "ChurchRescue_Captor_Deceive";
				link.l4 = "Savez-vous seulement qui se tient devant vous ? Un mot de moi, et il ne restera rien de votre bande. Livrez-moi le moine tant que vous le pouvez encore.";
				link.l4.go = "ChurchRescue_Captor_Threaten";
		break;

		case "ChurchRescue_Captor_Deceive":
			if (rand(100) < 40 + GetCharacterSkill(pchar, "Sneak")) // обман - хитрость (Sneak), лёгкий порог
			{
				PChar.GenQuest.ChurchRescue.Freed = "deceive";
				dialog.text = "L'Inquisition ?! Bon sang... Un bמcher, c'est bien la dernière chose qu'il nous faut. Prends ton saint homme et décampez, tous les deux, avant que je change d'avis !";
				link.l1 = "Venez, mon frère. Vous êtes libre.";
				link.l1.go = "ChurchRescue_Captor_TalkWin";
			}
			else
			{
				dialog.text = "L'Inquisition, tu dis ? Joli mensonge, mais on n'est pas nés d'hier. Allez, les gars, on va lui faire passer l'envie de mentir !";
				link.l1 = "Soit, ce sera la manière forte !";
				link.l1.go = "ChurchRescue_Captor_Fight";
			}
		break;

		case "ChurchRescue_Captor_Threaten":
			if (rand(100) < 40 + sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP))) // запугать - авторитет (Leadership), лёгкий порог
			{
				PChar.GenQuest.ChurchRescue.Freed = "threaten";
				dialog.text = "Ouais, à la réflexion... Inutile de chercher des noises à quelqu'un comme toi. Bon, prends le moine. Ma peau vaut plus cher que celle d'un curé.";
				link.l1 = "Venez, mon frère. Vous êtes libre.";
				link.l1.go = "ChurchRescue_Captor_TalkWin";
			}
			else
			{
				dialog.text = "Ha ! דa croit nous faire peur ! On est plus nombreux, et nos lames sont bien affמtées. Sus, les gars !";
				link.l1 = "Alors, ce sera par la force !";
				link.l1.go = "ChurchRescue_Captor_Fight";
			}
		break;

		case "ChurchRescue_Captor_TalkWin":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			iCaptors = sti(PChar.GenQuest.ChurchRescue.CaptorsCount);
			for(i=0; i<iCaptors; i++)
			{
				rChar = CharacterFromID("ChurchRescue_Captor_" + i);
				LAi_CharacterDisableDialog(rChar);
				rChar.LifeDay = 0;
			}
			LAi_LocationFightDisable(LoadedLocation, false);
			DeleteAttribute(LoadedLocation, "DisableEncounters");
			chrDisableReloadToLocation = false;
			DeleteAttribute(PChar, "GenQuest.ChurchRescue.CaptorsInCave");
			DeleteAttribute(PChar, "quest.ChurchRescue_SpawnCaptors");
			sTitle = PChar.GenQuest.ChurchRescue.QuestTown + "ChurchRescue";
			AddQuestRecordEx(sTitle, "ChurchRescue", "2");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRescue.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRescue.QuestTown + "Gen"));
			ChurchRescue_SpawnMonk(); // освобождённый монах выходит поблагодарить
		break;

		case "ChurchRescue_Captor_Pay":
			dialog.text = "Sage décision. L'argent d'abord... Hé, amenez le moine ici ! Et toi, décampe, et ne te retourne pas.";
			link.l1 = "Venez, mon frère. Vous êtes libre.";
			link.l1.go = "ChurchRescue_Captor_PayDone";
		break;

		case "ChurchRescue_Captor_PayDone":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddMoneyToCharacter(PChar, -sti(PChar.GenQuest.ChurchRescue.Ransom));
			iCaptors = sti(PChar.GenQuest.ChurchRescue.CaptorsCount);
			for(i=0; i<iCaptors; i++)
			{
				rChar = CharacterFromID("ChurchRescue_Captor_" + i);
				LAi_CharacterDisableDialog(rChar);
				rChar.LifeDay = 0;
			}
			LAi_LocationFightDisable(LoadedLocation, false); // вернуть возможность боя (SpawnCaptors её запретил)
			DeleteAttribute(LoadedLocation, "DisableEncounters");
			chrDisableReloadToLocation = false;
			PChar.GenQuest.ChurchRescue.Freed = "pay";
			DeleteAttribute(PChar, "GenQuest.ChurchRescue.CaptorsInCave");
			DeleteAttribute(PChar, "quest.ChurchRescue_SpawnCaptors");
			sTitle = PChar.GenQuest.ChurchRescue.QuestTown + "ChurchRescue";
			AddQuestRecordEx(sTitle, "ChurchRescue", "2");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRescue.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRescue.QuestTown + "Gen"));
			ChurchRescue_SpawnMonk(); // освобождённый монах выходит поблагодарить
		break;

		case "ChurchRescue_Captor_Fight":
			LAi_LocationFightDisable(LoadedLocation, false); // снова разрешаем бой (SpawnCaptors его запретил)
			AddDialogExitQuest("ChurchRescue_CaptorsEnemies");
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "ChurchRescue_Monk_Thanks":
			dialog.text = "Que Dieu vous bénisse, vous qui m'avez sauvé ! J'avais perdu l'espoir de revoir un jour la lumière de Dieu... Hâtez-vous d'aller voir le père " + PChar.GenQuest.ChurchRescue.PriestName + "; il doit se faire un sang d'encre en attendant de bonnes nouvelles. Je regagnerai le cloître par mes propres moyens.";
			link.l1 = "Allez en paix, frère " + PChar.GenQuest.ChurchRescue.MonkName + ".";
			link.l1.go = "ChurchRescue_Monk_Leave";
		break;

		case "ChurchRescue_Monk_Leave":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			rChar = CharacterFromID("ChurchRescue_Monk");
			LAi_CharacterDisableDialog(rChar);
			rChar.LifeDay = 0; // монах уходит в обитель
		break;
	}
}
