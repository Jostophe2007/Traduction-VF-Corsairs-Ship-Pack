// boal 25/04/04 общий диалог церковь
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Church\" + NPChar.City + "_Church.c";
    if (!HasCityDialogFile("Church", NPChar.City, "_Church.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Church\DefaultCity_Church.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Church\DefaultCity_Church.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 16/06/06

    string iDay, iMonth, lastspeak_date;
    string sTemp, sTitle;

	iDay           = environment.date.day;
	iMonth         = environment.date.month;
	lastspeak_date = iday + " " + iMonth;
	int iMoneyToCharacter;

	if (!CheckAttribute(npchar, "quest.HealthMonth"))
    {
        npchar.quest.HealthMonth = "";
    }

	if (!CheckAttribute(npchar, "quest.IndulgenceMonth"))
    {
        npchar.quest.IndulgenceMonth = "";
    }

    if (!CheckAttribute(npchar, "quest.BadMeeting"))
    {
        npchar.quest.BadMeeting = "";
    }
	if (!CheckAttribute(npchar, "quest.Fooled"))
    {
        npchar.quest.Fooled = "";
    }
    if (!CheckAttribute(npchar, "quest.GhostShipMonth"))
    {
        npchar.quest.GhostShipMonth = "";
    }

	if (!CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = "";
	}

	if(!CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.GiveQuestDay"))
	{
		NPChar.GenQuest.ChurchQuest_2.GiveQuestDay = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchQuest_1.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchQuest_1.GiveQuestDateParam = "";
	}

	if(!CheckAttribute(NPChar, "GenQuest.ChurchQuest_1.GiveQuestDay"))
	{
		NPChar.GenQuest.ChurchQuest_1.GiveQuestDay = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchProvision.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchProvision.GiveQuestDateParam = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchRelic.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchRelic.GiveQuestDateParam = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchRescue.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchRescue.GiveQuestDateParam = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchRunaway.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchRunaway.GiveQuestDateParam = "";
	}

	if (!CheckAttribute(NPChar, "GenQuest.ChurchDonate.GiveQuestDateParam"))
	{
		NPChar.GenQuest.ChurchDonate.GiveQuestDateParam = "";
	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "First time":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase(""+ GetSexPhrase("Mon fils", "Ma fille") +"Malheureusement, je ne peux pas vous donner asile. Fuyez !", "Toute la garde de la ville ratisse les rues à votre recherche, "+ GetSexPhrase("mon fils", "ma fille") +". L'église est ouverte à ceux qui souffrent, mais je ne peux pas vous offrir d'asile...", ""+ GetSexPhrase("Mon fils", "Ma fille") +", vous devez fuir ! Je vous en prie, ne tardez pas !"),
					LinkRandPhrase("Que faites-vous à l'église, âme déchue ? J'exige que vous sortiez immédiatement, avant que les soldats n'entrent et ne commencent un massacre ici !", "Quittez immédiatement le temple, impie ! Je ne resterai pas aux cכtés d'un être comme vous !", "Quittez immédiatement le temple de Dieu ! Je ne veux pas de meurtres ici !!"));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Allons, padre...", "Je n'ai pas besoin de votre aide..."),
					LinkRandPhrase("Saint père, mieux vaut ne pas vous mettre en travers de mon chemin...", "Je vais partir, ne vous inquiétez pas...", "Padre, ne vous agitez pas, ce n'est pas votre affaire, par Dieu"));
				link.l1.go = "fight";
				break;
			}
			if (pchar.questTemp.MC == "toCaracasPadre" && npchar.city == "Caracas")
			{
				Dialog.Text = "Bienvenue sous le toit de ce saint monastère, "+ GetSexPhrase("mon fils", "ma fille") +".";
				link.l1 = "Padre, la taverne est assiégée par une foule de citadins éméchés. Ils prétendent qu'il y a un loup-garou là-dedans, mais je n'ai vu qu'un homme apeuré. Il veut se confesser !";
				link.l1.go = "MC_CaracasChirch";
				Link.l2 = "Je dois y aller.";
				Link.l2.go = "exit";
				break;
			}
			if (IsEquipCharactersByItem(pchar, "DHGlove") && npchar.quest.BadMeeting != lastspeak_date)
			{
				Dialog.Text = "Vous... vous êtes un sorcier ! Comment osez-vous, impie immonde, venir dans le temple de Dieu ?! Démon de l'enfer, que la colère du Seigneur s'abatte sur vous !";
				Link.l1 = "Un sorcier, dites-vous... Et pourquoi donc un sorcier ?";
				Link.l1.go = "DHreaction";
				break;
			}
			if (startherotype == 2 && npchar.quest.BadMeeting != lastspeak_date && npchar.quest.Fooled != lastspeak_date && !IsEquipCharacterByItem(pchar, "glasses") && 80 > sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)))
			{
				Dialog.Text = "Vos yeux... Quittez le temple du Seigneur, démon de l'enfer ! Nous n'avons rien à nous dire !";
				Link.l2 = "Vous vous trompez, saint père. Je suis un ange descendu du ciel, venu sur terre accomplir la mission du Seigneur.";
				Link.l2.go = "fool_priest";
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit";
				break;
			}

			if (pchar.sex == "Skeleton" && GetCharacterEquipSuitID(pchar)!= "suit_1")
			{
				Dialog.Text = "Quittez le temple du Seigneur, démon de l'enfer ! Nous n'avons rien à nous dire !";
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit";
				Link.l2 = "Je me fiche bien de vous et de votre dieu !";
				Link.l2.go = "exit";
				break;
			}

            if (npchar.quest.BadMeeting != lastspeak_date )
			{
				if(!CheckAttribute(Pchar, "questTemp.CapBloodLine") || Pchar.questTemp.CapBloodLine == false)
				{					
					if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.QuestTown") && PChar.GenQuest.ChurchQuest_2.QuestTown == NPChar.city && CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete"))
					{
						Dialog.Text = ""+ GetSexPhrase("Mon fils", "Ma fille") +"Je suis heureux de vous revoir !";
						link.l1 = "Et moi, je suis heureux de vous voir en bonne santé, père " + npchar.name + "...";
						link.l1.go = "GenQuest_Church_2_Finally_Complete_1";
						break;
					}

					if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.QuestTown") && PChar.GenQuest.ChurchQuest_1.QuestTown == NPChar.city && CheckAttribute(PChar, "GenQuest.ChurchQuest_1.Complete"))
					{
						Dialog.Text = ""+ GetSexPhrase("Mon fils", "Ma fille") +" ! Je suis heureux de vous revoir en bonne santé et de bonne humeur. Apparemment, Dieu a favorisé l'heureuse conclusion de notre affaire ?";
						link.l1 = "Oui, " + RandPhraseSimple("padre", "saint père") + ", même si le vent ne soufflait pas toujours en poupe et que j'y ai consacré un peu plus de temps, d'efforts et d'argent que prévu, votre mission est finalement accomplie.";
						link.l1.go = "GenQuest_Church_1_Complete_1";
						break;
					}
				}
				Dialog.Text = "Bienvenue sous le toit de ce saint monastère, "+ GetSexPhrase("mon fils", "ma fille") +".";
				link.l1 = "Bonjour, saint père.";
				link.l1.go = "node_3";
				Link.l2 = "Vous n'êtes pas mon père, et ne vous avisez plus de me traiter ainsi.";
				Link.l2.go = "node_2";

				if (startherotype == 2 && !IsEquipCharacterByItem(pchar, "glasses"))
				{
					Dialog.Text = "Mon ange ! Comment puis-je vous aider ?";
					Link.l2 = "Rien, je m'en vais déjà.";
					Link.l2.go = "exit";
				}
			}
			if (npchar.quest.BadMeeting == lastspeak_date)
			{
				Dialog.Text = "Quittez le temple du Seigneur, blasphémateur ! Nous n'avons rien à nous dire !";
				if (pchar.sex == "Skeleton" || startherotype == 2)
				{
					Dialog.Text = "Quittez le temple du Seigneur, esprits du mal ! Nous n'avons rien à nous dire !";
				}
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit";
			}

			NextDiag.TempNode = "First time";
		break;

		case "DHreaction":
			dialog.text = "Dehors ! Je n'ai rien à vous dire !";
			link.l1 = "Je n'en avais pas vraiment envie.";
			link.l1.go = "exit";
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -5);
			npchar.quest.BadMeeting = lastspeak_date;
		break;

		case "fool_priest":
			if (drand(80) > sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)))
			{
				dialog.text = "On ne me la fait pas ! Sortez d'ici, et ne souillez pas le temple de Dieu de votre présence !";
				link.l1 = "Diable !";
				link.l1.go = "exit";
				AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 5 + 5 * sti(pchar.rank));
				ChangeCharacterReputation(pchar, -1);
				npchar.quest.BadMeeting = lastspeak_date;
			}
			else
			{
				dialog.text = "Je suis vraiment désolé, je ne vous avais pas reconnu. Comment un simple prêtre peut-il servir une créature céleste comme vous ?";
				link.l1 = "J'ai une question.";
				AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 50 + 10 * sti(pchar.rank));
				link.l1.go = "node_3";
				npchar.quest.Fooled = lastspeak_date;

			}
		break;

		case "node_2":
			dialog.text = "Oh, blasphémateur ! Sortez d'ici, et ne profanez pas le temple de Dieu de votre présence !";
			link.l1 = "Je n'en avais pas envie, de toute façon.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -0.25);
			npchar.quest.BadMeeting = lastspeak_date;
		break;

		case "node_3":
			dialog.text = "Que le Seigneur vous bénisse, vous et vos actions... זtes-vous venu me voir dans un but précis ?";
			if (startherotype == 2 && !IsEquipCharacterByItem(pchar, "glasses"))
			{
				dialog.text = "Je suis à votre service.";
			}
			//зачарованный город -->
  			if (pchar.questTemp.MC == "toCaracasPadre" && npchar.city == "Caracas")
			{
				link.l1 = "Padre, la taverne est assiégée par une foule de citadins éméchés. Ils prétendent qu'il y a un loup-garou là-dedans, mais je n'ai vu qu'un homme terrifié. Il veut se confesser !";
				link.l1.go = "MC_CaracasChirch";
				break;
			}
  			if (pchar.questTemp.MC == "toCaracasTavern" && npchar.city == "Caracas")
			{
				dialog.text = "Amenez-moi cette personne. Je la confesserai ici, à l'église.";
				link.l1 = "Compris, padre.";
				link.l1.go = "exit";
				break;
			}
			//<-- зачарованный город
			//homo Линейка Блада
            if (!CheckAttribute(Pchar, "questTemp.CapBloodLine") || Pchar.questTemp.CapBloodLine == false)
            {
    			link.l1 = RandPhraseSimple("Je veux faire un don.", "Je veux faire un don pour une bonne cause.");
    			link.l1.go = "donation";
				if (startherotype !=2)
				{
					link.l2 = RandPhraseSimple("Je crois qu'il est temps de me confesser.", "J'ai besoin de me repentir, "+RandPhraseSimple("padre.", "saint père."));
					link.l2.go = "ispoved";
				}
    			link.l3 = RandPhraseSimple("J'ai à faire avec vous, " + RandPhraseSimple("padre.", "saint père."),
                                           "Je viens pour affaires, " + RandPhraseSimple("padre.", "saint père."));
    			link.l3.go = "work";//"quest lines";
            }

			link.l6 = "Excusez-moi, je dois y aller.";
			link.l6.go = "exit";
		break;

		//Ограбление церкви -->
		case "GenQuest_Church_2_Start_2":
			dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +", un terrible blasphème a été commis, le plus honteux des crimes ! Voler l'église !!! C'est comme mettre ses pattes sales directement dans la poche du Seigneur !";
				link.l1 = "Oh, voilà donc !.. Et comment est-ce arrivé ?";
				link.l1.go = "GenQuest_Church_2_Start_3";
				link.l2 = LinkRandPhrase("Tout cela est bien triste, bien sמr, mais je crois que je vais y aller...", "Je suis désolé, padre, mais je dois y aller...", "Vous vous êtes sans doute trop reposé sur le Seigneur, vous auriez dמ mettre des serrures plus solides. Je crois que je vais y aller...");
				link.l2.go = "exit";
			break;

		case "GenQuest_Church_2_Start_3":
			dialog.text = "Des gredins ont emporté, à la faveur de la nuit, tout ce que les fidèles avaient réuni ! Et ils ont pris le calice, les mécréants !";
				link.l1 = "Oui, quelle époque... Mais j'espère que vous avez pris des mesures ? א chaud, pour ainsi dire.";
				link.l1.go = "GenQuest_Church_2_Start_4";
			break;

		case "GenQuest_Church_2_Start_4":
			dialog.text = "Oh oui ! Bien sמr !! J'ai excommunié ces voleurs impies ! Et maintenant, je jette l'anathème sur leurs âmes.";
				link.l1 = "Je ne doute pas que ce soit la mesure la plus efficace. Mais je pensais à quelque chose de plus concret. Organiser une poursuite, par exemple.";
				link.l1.go = "GenQuest_Church_2_Start_5";
			break;

		case "GenQuest_Church_2_Start_5":
			dialog.text = "Ah, "+ GetSexPhrase("mon fils", "ma fille") +", que peut faire un simple prêtre, lié par un vœu de non-résistance au mal ? Ces gredins sont sמrement déjà loin d'ici : ils boivent le fruit de leur vol dans les tavernes, ou se livrent à la débauche dans les bras des catins ! J'espère que c'est là qu'ils finiront !";
				link.l1 = RandPhraseSimple("Hum, je suis sמr qu'une telle fin est bien plus attirante que de se balancer au bout d'une vergue. Mais je ne vais pas vous déranger plus longtemps. Bonne continuation.", "Hum, eh bien, puisque nous sommes tous destinés à rejoindre nos ancêtres tכt ou tard, je ne refuserais pas une telle fin. Mais je dois y aller maintenant. Je vous souhaite bonne chance dans votre dure tâche.");
				link.l1.go = "exit";
				link.l2 = LinkRandPhrase("Saint père", "Padre", "Mon père") + ", mais moi, je ne suis lié par aucun vœu, et j'aiderai volontiers le Seigneur à rapprocher l'heure du châtiment.";
				link.l2.go = "GenQuest_Church_2_Start_5_1";
			break;
		case "GenQuest_Church_2_Start_5_1": //выше - выход из диалога без подтверждения - странно, однако
			dialog.text = "Je prierai pour vous, " + GetSexPhrase("mon fils", "ma fille") + " ! Allez, et donnez à ces escrocs ce qu'ils méritent !";
				link.l1 = "Vous pouvez en être sמr, " + RandPhraseSimple("padre.", "saint père.");
				link.l1.go = "GenQuest_Church_2_Start_6";
			break;

		case "GenQuest_Church_2_Start_6":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchQuest_2.StartQuest = true;
			PChar.GenQuest.ChurchQuest_2.QuestTown = NPChar.City;	// Город, в котором спрашиваем
			PChar.GenQuest.ChurchQuest_2.QuestTown.PriestName = NPChar.name;
			PChar.GenQuest.ChurchQuest_2.IslandId = locations[FindLocation(NPChar.location)].islandId; // На каком острове опрашиваем бандюков
			PChar.GenQuest.ChurchQuest_2.Nation = sti(NPChar.nation);
			PChar.GenQuest.ChurchQuest_2.AskPeople = true;
			PChar.GenQuest.ChurchQuest_2.AskBarmen = true;
			PChar.GenQuest.ChurchQuest_2.AskAlcash = true;
			PChar.GenQuest.ChurchQuest_2.MoneyCount = (sti(pchar.rank)+8)*543+3210;
			PChar.GenQuest.ChurchQuest_2.MoneyToCharacter = makeint(sti(PChar.GenQuest.ChurchQuest_2.MoneyCount)/3);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			ReOpenQuestHeader(sQuestTitle);
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "1");
			AddQuestUserDataForTitle(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
		//	AddQuestUserData(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			break;

		case "GenQuest_Church_2_Thief_2":
			dialog.text = "Eh bien, que le Créateur infiniment bon envoie la peste et la joie à ses enfants insensés pour les punir de leurs graves péchés...";
				link.l1 = "Par exemple, pour l'orgueil, ou, disons, la cupidité... Pourquoi êtes-vous si pâle, padre ?";
				link.l1.go = "GenQuest_Church_2_Thief_3";
			break;

		case "GenQuest_Church_2_Thief_3":
			if(rand(1) == 0) // Священник искренне раскаивается...
			{
				dialog.text = "Jésus-Christ... Ayez pitié de moi, pauvre pécheur... Vous les avez trouvés... Les voleurs ? Vous les avez tués ?";
					link.l1 = "Ou prenons les dix commandements, que tout bon chrétien connaît depuis l'enfance : tu ne tueras point, tu ne voleras point, tu ne porteras point de faux témoignage contre ton prochain. Comment un homme qui craint Dieu peut-il les enfreindre ? Et à plus forte raison un pasteur des âmes ?!..";
					link.l1.go = "GenQuest_Church_2_Thief_4_1_1";
			}
			else
			{
				dialog.text = "On étouffe ici... Alors, vous avez trouvé les voleurs ? Vous les avez tués ?";
					link.l1 = "Ou prenez les dix commandements, que tout bon chrétien connaît depuis l'enfance : tu ne tueras point, tu ne voleras point, tu ne porteras point de faux témoignage contre ton prochain. Comment un homme qui craint Dieu peut-il les enfreindre ? Et à plus forte raison un pasteur des âmes ?!..";
					link.l1.go = "GenQuest_Church_2_Thief_4_2_1";
			}
			break;

		case "GenQuest_Church_2_Thief_4_1_1":
			dialog.text = ""+ GetSexPhrase("Mon fils, monsieur", "Ma fille, madame") +"... Que Dieu me pardonne... tant d'argent, une telle tentation... L'homme est faible, faible ! Je n'ai pas pu résister... Je ne trouvais plus le repos... Je n'ai cessé de prier, de faire pénitence et d'observer un jeמne sévère... j'ai mortifié ma chair et, indigne que je suis, je n'ai demandé au ciel qu'une seule chose : que ces malheureux que j'avais entraînés dans le péché, poussé par la cupidité, restent en vie...";
				link.l1 = LinkRandPhrase("Saint père", "Padre", "Mon père") + ", calmez-vous. L'essentiel, c'est qu'ils n'aient rien dit à personne... et ils ne diront rien. D'ailleurs, ils m'ont remis de leur plein gré le calice, que je vous ai rapporté.";
				link.l1.go = "GenQuest_Church_2_Thief_4_1_2";
			break;

		case "GenQuest_Church_2_Thief_4_1_2":
			dialog.text = "Merci, mon Dieu ! Les prières d'un serviteur indigne, d'un pécheur qui a trébuché, embourbé dans la fange et le vice, ont été entendues...";
				link.l1 = "Tout le monde peut trébucher... Cependant, voyant votre repentir sincère, je vous dirai ceci : vous n'êtes pas un mauvais homme, et vous êtes un bon prêtre. Si vous passez en jugement, cela ne profitera à personne. Quant à rester ou non au service du Seigneur, vous en déciderez vous-même dans vos conversations avec Lui...";
				link.l1.go = "GenQuest_Church_2_Thief_4_1_3";
			break;

		case "GenQuest_Church_2_Thief_4_1_3":
			iMoneyToCharacter = sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter);
			if(rand(1) == 0) // Священник хочет всучить ГГ бабло
			{
				dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +"... C'est avec des larmes de remords et de gratitude que je reçois de vous ce calice. La pureté et la noblesse de votre âme m'ont bouleversé. Je vous bénis de tout cœur et vous supplie d'accepter cette modeste récompense, d'un montant de " + FindRussianMoneyString(iMoneyToCharacter) + "... J'espère qu'elle couvrira vos dépenses ?";
					// ГГ не берет деньги. Плюсанем репу
					link.l1 = "C'est inutile, père " + npchar.name + ". Je ne suis pas digne d'utiliser cet argent, qui doit servir à vos paroissiens.";
					link.l1.go = "GenQuest_Church_2_Thief_4_1_4";
					// ГГ берет деньги
					link.l2 = "Merci, " + LinkRandPhrase("saint père", "padre", "Mon père") + ", c'est bien assez.";
					link.l2.go = "GenQuest_Church_2_Thief_4_1_5";
			}
			else
			{
				dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +"... C'est avec des larmes de remords et de gratitude que je reçois de vous ce calice, en signe de la miséricorde et du pardon de Dieu. La pureté et la noblesse de votre âme m'ont bouleversé. Je vous bénis du fond du cœur !";
					link.l1 = "Merci pour la bénédiction, " + LinkRandPhrase("padre", "mon père") + ".";
					link.l1.go = "GenQuest_Church_2_Thief_4_1_4";
					link.l2 = "Une bénédiction, c'est nécessaire, bien sמr, mais il serait bon de l'appuyer par quelque chose de plus matériel, puisque j'ai eu en chemin"+ GetSexPhrase("", "") +" des frais considérables...";
					link.l2.go = "GenQuest_Church_2_Thief_4_1_6";
			}

			// Если будет чаша - здесь её отбирать!
			ChurchGenQuest2_RemoveCup();
			break;

		case "GenQuest_Church_2_Thief_4_1_4":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, 3);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_1");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_1_5":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter));
			ChangeCharacterReputation(PChar, -2);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_2");
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_1_6":
			iMoneyToCharacter = sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter);
			dialog.text = "Oh, mon enfant, j'avais complètement oublié... J'espère que cette modeste contribution, d'un montant de " + FindRussianMoneyString(iMoneyToCharacter) + " couvrira vos dépenses.";
				link.l1 = "Oui, " + LinkRandPhrase("padre", "Mon père") + "Merci.";
				link.l1.go = "GenQuest_Church_2_Thief_4_1_6_1";
			break;

		case "GenQuest_Church_2_Thief_4_1_6_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -2);
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter));
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_3");
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_2_1":
			dialog.text = "Je ne comprends pas vos allusions, "+ GetSexPhrase("mon fils", "ma fille") +", de quoi parlez-vous ?!";
				link.l1 = "Je parle des choses terribles que la cupidité peut faire à un homme. Et de ce calice que j'ai récupéré auprès de ces va-nu-pieds qui auraient soi-disant volé votre église... Vous vouliez dire quelque chose ?";
				link.l1.go = "GenQuest_Church_2_Thief_4_2_2";
			break;

		case "GenQuest_Church_2_Thief_4_2_2":
			dialog.text = "Je vous dirai, mon enfant, que vous êtes très irrespectueux envers un homme d'וglise, et que vous pourriez le regretter. Et ce calice, je le vois pour la première fois, mais si vous voulez en faire don à la paroisse, alors...";
				link.l1 = "Doucement, padre, vous ne l'aurez pas tant que vous ne vous serez pas expliqué.";
				link.l1.go = "GenQuest_Church_2_Thief_4_2_3";
			break;

		case "GenQuest_Church_2_Thief_4_2_3":
			if(rand(1) == 0) // Просто несколько разные варианты диалога
			{
				dialog.text = "Que devrais-je vous expliquer ?! Vous êtes "+ GetSexPhrase("un homme intelligent", "une femme intelligente") +", vous devriez comprendre vous-même : tout ce que ces escrocs ont raconté, que je les aurais soi-disant engagés, n'est qu'un mensonge éhonté ! Le Seigneur punira ces impies non seulement pour leur blasphème, mais aussi pour leur parjure !";
					link.l1 = "Laissez le Seigneur tranquille ! Comment savez-vous ce que m'ont raconté ces misérables que vous avez lancés sur moi ? Peut-être les ai-je tués avant qu'ils aient eu le temps de me parler de vos méfaits ?";
					link.l1.go = "GenQuest_Church_2_Thief_4_2_4_1";
			}
			else
			{
				dialog.text = "Je n'ai rien à vous dire : vous n'avez pas rempli l'engagement que vous aviez pris devant le Seigneur, vous jurez dans le temple, vous essayez de faire chanter un prêtre en agitant des objets du culte obtenus on ne sait comment ! Et remerciez Dieu que je n'appelle pas les novices pour vous prendre la main dans le sac !";
					link.l1 = "Eh bien... Je vois que vous êtes si enfoncé dans le péché que vous ne craignez pas le jugement des hommes. Mais il y a un Tribunal suprême, devant lequel nous comparaîtrons tous tכt ou tard. Prenez vos « objets du culte » et demandez-vous si vous êtes digne d'y toucher, père " + npchar.name + ".";
					link.l1.go = "GenQuest_Church_2_Thief_4_2_4_2_1";
					link.l2 = "Pardonnez mes doutes, saint père, car le cœur humain est faible et l'âme est troublée. Prenez ce calice et bénissez-moi.";
					link.l2.go = "GenQuest_Church_2_Thief_4_2_4_2_2";
			}
			break;

		case "GenQuest_Church_2_Thief_4_2_4_1":
			iMoneyToCharacter = sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter);
			dialog.text = "Euh... "+ GetSexPhrase("Mon fils... Monsieur... Monsieur", "Ma fille... Madame... Madame") +" " + PChar.name + "... Je suis prêt à faire un pas vers vous... à oublier nos différends.... à vous dédommager de vos frais de voyage par cette modeste somme de " + FindRussianMoneyString(iMoneyToCharacter) + "... à condition, bien sמr, que vous ne mêliez pas d'étrangers à cette affaire...";
			// При этом варианте репу плюсуем
			link.l1 = "Je n'ai l'intention de mêler personne à cette affaire. Prenez ce calice ! Et ne croyez pas que je vais prendre l'or que vous volez en cachette dans les poches de vos paroissiens !";
			link.l1.go = "GenQuest_Church_2_Thief_4_2_4_1_1";
			// При этом - минусуем
			link.l2 = "Je n'ai l'intention de mêler personne à cette affaire. Prenez ce calice ! Je ne prends cet or que parce que j'ai dépensé trop de temps et d'argent, mais rien ne compensera la profonde déception que vous m'inspirez !";
			link.l2.go = "GenQuest_Church_2_Thief_4_2_4_1_2";

			// Если будет чаша - здесь её отбирать!
			break;

		case "GenQuest_Church_2_Thief_4_2_4_1_1":
			DialogExit();
			iMoneyToCharacter = PChar.GenQuest.ChurchQuest_2.MoneyToCharacter;
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -2);
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter));
			ChurchGenQuest2_RemoveCup();
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_5");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sSex2", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			AddQuestUserData(sQuestTitle, "sMoney", FindRussianMoneyString(iMoneyToCharacter));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_2_4_1_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, 3);
			ChurchGenQuest2_RemoveCup();
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_4");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_2_4_2_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChurchGenQuest2_RemoveCup();
			ChangeCharacterReputation(PChar, 3);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_6");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Thief_4_2_4_2_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChurchGenQuest2_RemoveCup();
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_7");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1":

		// ничего не принесли священнику.
		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete.Without_All"))
		{
			link.l1 = "De mauvaises nouvelles, " + LinkRandPhrase("saint père", "padre", "Mon père") + ": les voleurs se sont montrés si perfides et si ingénieux que je n'ai pas pu récupérer l'or de l'église...";
			link.l1.go = "GenQuest_Church_2_Finally_Complete_1_1_1";
			break;
		}

		// Принесли священнику только чашу.
		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete.Only_With_Cup"))
		{
			link.l1 = "De mauvaises nouvelles, " + LinkRandPhrase("saint père", "padre", "Mon père") + ": j'ai réussi à rattraper les voleurs, mais mon seul trophée a été ce calice.";
			link.l1.go = "GenQuest_Church_2_Finally_Complete_1_4_1";
			ChurchGenQuest2_RemoveCup();
			break;
		}

		// Принесли священнику и деньги и чашу.
		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete.With_All"))
		{
			if(sti(PChar.money) >= sti(PChar.GenQuest.ChurchQuest_2.MoneyCount))
			{
				link.l1 = "Je suis sמr que la nouvelle vous fera plaisir : j'ai durement puni les voleurs et je leur ai repris l'argent de la paroisse, ainsi que ce calice.";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_2_1";
			}

			// Деньги можно заныкать.
			link.l2 = LinkRandPhrase("Saint père", "Padre", "Mon père") + ", j'apporte de mauvaises nouvelles... J'ai dמ dépenser beaucoup de temps, d'efforts et d'argent pour retrouver ces gredins, mais quand je les ai enfin attrapés, il s'est avéré qu'ils avaient déjà tout bu et dilapidé, sauf ce calice...";
			link.l2.go = "GenQuest_Church_2_Finally_Complete_1_3_1";
			ChurchGenQuest2_RemoveCup();
			break;
		}

		// Священник - вор.
		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete.PriestIsThief"))
		{
			dialog.text = "Ah, "+ GetSexPhrase("mon fils", "ma fille") +", que pouvait-il m'arriver ? C'est votre chemin qui est plein de dangers et de soucis, alors que ma paisible cellule est le domaine des pensées et des prières, comme une île tranquille dans l'océan déchaîné des passions humaines...";
				link.l1 = "Rien ne peut donc troubler la paix de votre bienheureuse solitude ?";
				link.l1.go = "GenQuest_Church_2_Thief_2";
			break;
		}

		// Короткий вариант прохождения квеста.
		if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.Complete.Short_With_Mon"))
		{
			if(sti(PChar.money) >= sti(PChar.GenQuest.ChurchQuest_2.MoneyCount))
			{
				link.l1 = "Je suis sמr que la nouvelle vous fera plaisir : j'ai durement puni les voleurs et je leur ai repris l'argent de la paroisse.";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_2_1";
			}

			// Деньги можно заныкать.
			link.l2 = LinkRandPhrase("Saint père", "Padre", "Mon père") + "... Je dois vous attrister. J'ai poursuivi les voleurs à travers tout l'archipel, surmonté bien des dangers et des obstacles, et j'ai fini par les attraper, mais hélas... Ils avaient déjà dilapidé l'argent de l'église.";
			link.l2.go = "GenQuest_Church_2_Finally_Complete_1_3_1";
		}

		break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1": // ГГ решил заныкать деньги...
		if(rand(1) == 0)	// Священник верит ГГ но не даёт денег...
		{
			if(rand(4) == 3) // Более "soft" исход событий.
			{
				dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +". Vos paroles me plongent dans une profonde tristesse, mais pas dans le désespoir, car le désespoir est un péché mortel ! Le Seigneur nous envoie une nouvelle épreuve pour affermir notre foi.";
					link.l1 = "Amen, saint père...";
					link.l1.go = "exit";
					sQuestTitle = NPChar.City + "ChurchGenQuest2";
					AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_9");
					AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
					CloseQuestHeader(sQuestTitle);
					ChangeCharacterReputation(PChar, -2);
					DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
					NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			}
			else
			{
				dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +"ne mentez pas à votre pasteur spirituel.";
					link.l1 = "Je suis désolé, mon père, mais par tous les saints, je dis la vérité...";
					link.l1.go = "GenQuest_Church_2_Finally_Complete_1_3_1_3";
			}
		}
		else
		{
			// Священник даёт деньги ГГ...
			iMoneyToCharacter = sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter);
			dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +". Vos paroles me plongent dans une profonde tristesse, mais pas dans le désespoir, car le désespoir est un péché mortel ! Le Seigneur nous envoie une nouvelle épreuve pour affermir notre foi. Cependant, vos efforts et vos dépenses doivent être récompensés, même s'ils n'ont pas porté leurs fruits. Prenez cette petite somme : " + FindRussianMoneyString(iMoneyToCharacter) + " – et poursuivez votre chemin dans la justice !";
				link.l1 = "Euh-hum !... Merci, padre, je consacrerai cet argent à une œuvre de charité.";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_3_1_1";
				link.l2 = LinkRandPhrase("Saint père", "Padre", "Mon père") + "... vous me mettez dans une situation gênante. Je ne peux pas accepter de récompense pour un travail que je n'ai pas fait ; servez-vous plutכt de cet argent pour restaurer l'autel.";
				link.l2.go = "GenQuest_Church_2_Finally_Complete_1_3_1_2";
		}
		break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1_3":
		if(rand(6) == 3)
		{
			dialog.text = "D'accord, je vous crois, "+ GetSexPhrase("mon fils", "ma fille") +". Le Seigneur nous soumet à une nouvelle épreuve pour affermir notre foi.";
				link.l1 = "Amen...";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_3_1_3_1"
			break;
		}
			dialog.text = "Misérable, vous pensiez vraiment tromper notre Seigneur ? Soyez maudit ! Sortez, et souvenez-vous que cet argent ne vous portera pas bonheur !";
				link.l1 = "Allons !.. Padre !..";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_3_1_3_2";
			break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1_3_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "5");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			AddCharacterExpToSkill(PChar, "Sneak", 20);
			ChangeCharacterReputation(PChar, -3);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1_3_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "6");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			ChangeCharacterReputation(PChar, -6);
			AddCharacterExpToSkill(PChar, "Leadership", -50);
			AddCharacterExpToSkill(PChar, "Fortune", -70);
			AddCharacterExpToSkill(PChar, "Sneak", 20);
			DeleteAttribute(PCHar, "GenQuest.ChurchQuest_2");
			npchar.quest.BadMeeting = lastspeak_date;
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_4_1":
			if(rand(1) == 0) // Поверил.
			{
				dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +". Vos paroles me plongent dans une profonde tristesse, mais pas dans le désespoir, car le désespoir est un péché mortel ! Le Seigneur nous envoie une nouvelle épreuve pour affermir notre foi.";
					link.l1 = "Amen, saint père...";
					link.l1.go = "GenQuest_Church_2_Finally_Complete_1_1_2"; // Переход сюда, т.к. одно и тоже.
			}
			else
			{
				dialog.text = "Oui, c'est bien le calice qui a disparu avec l'argent... mais... Si vous l'avez récupéré, pourquoi n'avez-vous pas rendu l'argent ? C'était une somme considérable, et de simples escrocs n'auraient pas pu la dépenser si vite... "+ GetSexPhrase("Mon fils", "Ma fille") +", souvenez-vous qu'il n'y a pas de pire péché que de mentir à son pasteur spirituel, et encore moins de se parjurer dans le temple, devant la face du Seigneur !!";
					link.l1 = "Mon père, " + npchar.name + ", j'ai failli y laisser la vie pour récupérer ce vase, je pensais vous faire plaisir, sinon avec des pièces, du moins avec un objet du culte. Et je ne parle même plus de mes dépenses pour cette entreprise !";
					link.l1.go = "GenQuest_Church_2_Finally_Complete_1_4_1_2";
			}
			break;

		case "GenQuest_Church_2_Finally_Complete_1_4_1_2":
			dialog.text = "Partez, mon ami, et remerciez le Créateur qui m'a doté d'un cœur tendre, car c'est la seule raison pour laquelle on ne vous a pas encore déclaré voleur !";
				link.l1 = "Comment ça ?! " + LinkRandPhrase("Saint père", "Padre", "Mon père") + " !..";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_4_1_2_1";
			break;

		case "GenQuest_Church_2_Finally_Complete_1_4_1_2_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -5);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_12");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2");
			NPChar.quest.BadMeeting = lastspeak_date;
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1_1":
			DialogExit();
			iMoneyToCharacter = PChar.GenQuest.ChurchQuest_2.MoneyToCharacter;
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -2);
			AddMoneyToCharacter(PChar, iMoneyToCharacter);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_10");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_3_1_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -1);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_11");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_1_1":
			dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +". Vos paroles me plongent dans une profonde tristesse, mais pas dans le désespoir, car le désespoir est un péché mortel ! Le Seigneur nous envoie une nouvelle épreuve pour affermir notre foi.";
				link.l1 = "Amen, saint père...";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_1_2";
			break;

		case "GenQuest_Church_2_Finally_Complete_1_1_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, -2);
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "12_8");
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

		case "GenQuest_Church_2_Finally_Complete_1_2_1":
			dialog.text = "Mon Dieu, merci ! Vous avez été l'instrument du Seigneur, mon enfant ! Je savais que notre Père céleste vous guiderait sur la bonne voie et ne vous priverait pas de Son aide ! J'ai prié sans cesse, et voilà...";
				link.l1 = "En fait, dans ce genre d'affaires, les armes sont plus utiles que les prières, padre. Mais apparemment, Dieu a vraiment entendu vos prières.";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_2_2";
			break;

		case "GenQuest_Church_2_Finally_Complete_1_2_2":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", je veux vous récompenser dignement"+ GetSexPhrase(", en vrai chevalier de notre Sainte Mère l'וglise,", ",") +" vous avez fait de votre mieux pour nous et tout surmonté...";
				link.l1 = "Saint père, vous exagérez beaucoup mes humbles mérites. Je vous laisse rendre grâce au Seigneur...";
				link.l1.go = "GenQuest_Church_2_Finally_Complete_1_2_3";
			break;

		case "GenQuest_Church_2_Finally_Complete_1_2_3":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterReputation(PChar, 5);
			AddMoneyToCharacter(PChar, -sti(PChar.GenQuest.ChurchQuest_2.MoneyCount));
			AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchQuest_2.MoneyToCharacter));
			sQuestTitle = NPChar.City + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "4");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sQuestTitle);
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2");
			NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth;
			break;

	//================================================================================================================


		case "donation":
			if (startherotype != 2 || IsEquipCharacterByItem(pchar, "glasses"))
			{
				dialog.Text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +". Combien voulez-vous donner à la Sainte וglise ?";
				Link.l1 = "Je suis désolé, mon père, mais il n'y aura pas de don.";
				Link.l1.go = "No donation";
				Link.l2 = "Laissez-moi réfléchir...";
				link.l2.go = "donate_input";
			}
			else
			{
				dialog.Text = "Ce n'est pas nécessaire. Votre seule présence ici vaut déjà plus que n'importe quelle somme.";
				Link.l1 = "Comme vous voudrez. Alors j'ai une autre question...";
				Link.l1.go = "node_3";

			}
			//-->> квест пожертвования хозяйки борделя
			if(pchar.questTemp.different == "HostessChurch_toChurch" && pchar.questTemp.different.HostessChurch.city == npchar.city && sti(pchar.money) >= sti(pchar.questTemp.different.HostessChurch.money))
			{
				Link.l5 = "Saint père, je ne veux pas faire un don de ma propre initiative. Je le fais pour le compte de quelqu'un.";
				Link.l5.go = "HostessChurch";
			}
			//<<-- квест пожертвования хозяйки борделя
		break;

		case "No donation":
			dialog.Text = "Hum... C'est votre décision, et vous avez le droit d'en changer. Mais n'oubliez pas que cela vous sera reproché au Jugement dernier.";
			Link.l1 = "Et pas seulement ça. Changeons de sujet.";
			Link.l1.go = "node_3";
			Link.l2 = "Excusez-moi, mon père, je dois y aller.";
			Link.l2.go = "exit";
		break;

		case "donate_input":
			dialog.Text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +". Combien voulez-vous donner à la Sainte וglise ?";
			Link.l1.edit = 1;
			link.l1 = " ";
			link.l1.go = "donation_thank_you";
		break;

		case "donation_thank_you":
			int iDonation = sti(dialogEditStrings[1]);
			if(iDonation > sti(pchar.money) || iDonation <= 0)
			{
				if(iDonation <= 0)
				{
					dialog.text = "Un don à la Sainte וglise doit venir d'un cœur pur, "+ GetSexPhrase("mon fils", "ma fille") +". Nommez la somme que vous souhaitez donner.";
				}
				else
				{
					dialog.text = "Oh, " + GetSexPhrase("mon fils", "ma fille") + ", je vois que vous n'avez pas assez d'argent...";
				}
				link.l1 = "Vous avez raison, mon père, je vais changer la somme."
				link.l1.go = "donate_input";
				link.l2 = "Vous savez, j'ai changé d'avis.";
				link.l2.go = "exit";
			}
			else
			{
				dialog.Text = "Au nom de la Sainte וglise, merci, "+ GetSexPhrase("mon fils", "ma fille") +", pour votre don.";
				int iRepIncr = iDonation / 5000;
				ChangeCharacterReputation(pchar, iRepIncr);
				AddMoneyToCharacter(pchar, -iDonation);
				Link.l1 = "J'ai besoin de vous parler, mon père.";
				Link.l1.go = "node_3";
				Link.l2 = "Excusez-moi, mon père, je dois y aller.";
				Link.l2.go = "exit";
			}
		break;

		case "ispoved":
			dialog.text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +"Je vous écoute.";
			link.l1 = "J'ai changé d'avis. Une autre fois, peut-être.";
			link.l1.go = "exit";
			link.l2 = "J'ai tant péché, saint père. Il ne faudra pas moins d'une journée entière pour énumérer tous mes péchés...";
			link.l2.go = "ispoved_1";
			// Indulgence: atone for hostility with the priest's nation through a generous donation -->
			/* if (sti(NPChar.nation) != PIRATE && ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 0) < 0)
			{
				if (npchar.quest.IndulgenceMonth != iMonth)
				{
					link.l3 = "Holy Father, the wrath of " + NationNameGenitive(sti(NPChar.nation)) + " lies upon me. May I atone for my guilt with a generous donation to the church?";
					link.l3.go = "Indulgence_1";
				}
				else
				{
					link.l3 = "Holy Father, I would like to atone for my guilt before " + NationNameAblative(sti(NPChar.nation)) + ".";
					link.l3.go = "Indulgence_wait";
				}
			} */
			// <-- Indulgence
		break;

		case "ispoved_1":
			dialog.text = "Nous sommes tous pécheurs, mon enfant...";
			link.l1 = "Oui, mais j'ai sur la conscience le poids de milliers de morts. J'ai pillé et coulé des navires...";
			link.l1.go = "ispoved_2";
		break;

		case "ispoved_2":
			dialog.text = "J'espère qu'il n'y en avait aucun qui naviguait sous le pavillon de " + NationNameGenitive(sti(NPChar.nation)) + " ?";
			link.l1 = "Non, bien sמr que non, saint père.";
			link.l1.go = "ispoved_3";
			link.l2 = "Il y avait de tout, saint père... de tout.";
			link.l2.go = "ispoved_4";
		break;

		case "ispoved_3":
			dialog.text = "Alors le Seigneur vous pardonnera ces péchés. Car notre époque est cruelle, et en anéantissant les ennemis de votre souverain, vous sauvez la vie de ses fidèles sujets.";
			link.l1 = "Merci, saint père, vous m'avez beaucoup réconforté... Je vais y aller.";
			link.l1.go = "exit";
		break;

		case "ispoved_4":
			dialog.text = "Le Seigneur ne pardonnera jamais un tel péché ! Priez et repentez-vous, repentez-vous et priez ! Il ne vous reste qu'un seul chemin : le monastère !";
			link.l1 = "Le monastère attendra. Pas dans cette vie, en tout cas. Au revoir...";
			link.l1.go = "exit";
			npchar.quest.BadMeeting = lastspeak_date;
		break;

		// Indulgence -->
		case "Indulgence_1":
			int iIndRel = ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 0); // current relation (<0 - hostile)
			int iIndRestore = 10;
			if (iIndRel + iIndRestore > 0) iIndRestore = -iIndRel; // do not raise above neutral
			int iIndCost = iIndRestore * (1500 + sti(pchar.rank) * 500);
			npchar.quest.IndulgenceRestore = iIndRestore;
			npchar.quest.IndulgenceCost = iIndCost;
			dialog.text = "La colère de " + NationNameGenitive(sti(NPChar.nation)) + " est un lourd fardeau, "+ GetSexPhrase("mon fils", "ma fille") +". Mais la miséricorde du Seigneur est sans bornes pour celui qui vient avec un repentir sincère et un don généreux. Donnez " + FindRussianMoneyString(iIndCost) + " pour les besoins de la Sainte וglise, et je dirai un mot en votre faveur aux gouverneurs de la couronne.";
			link.l1 = "C'est un juste prix pour la paix de l'âme. Voici l'argent, saint père.";
			link.l1.go = "Indulgence_pay";
			link.l2 = "Bien cher pour expier ses péchés. J'y réfléchirai.";
			link.l2.go = "exit";
		break;

		case "Indulgence_pay":
			if (sti(pchar.money) < sti(npchar.quest.IndulgenceCost))
			{
				dialog.text = "Vous n'avez pas les moyens d'un don aussi généreux, "+ GetSexPhrase("mon fils", "ma fille") +". Revenez quand vous aurez réuni la somme nécessaire.";
				link.l1 = "Je reviendrai, saint père.";
				link.l1.go = "exit";
				break;
			}
			AddMoneyToCharacter(pchar, -sti(npchar.quest.IndulgenceCost));
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), sti(npchar.quest.IndulgenceRestore));
			npchar.quest.IndulgenceMonth = iMonth;
			dialog.text = "Que vos fautes vous soient pardonnées. J'enverrai une supplique aux gouverneurs, et la colère de " + NationNameGenitive(sti(NPChar.nation)) + " s'apaisera. Allez en paix, et ne péchez plus.";
			link.l1 = "Merci, saint père.";
			link.l1.go = "exit";
		break;

		case "Indulgence_wait":
			dialog.text = "Patience, "+ GetSexPhrase("mon fils", "ma fille") +". J'ai déjà envoyé une supplique en votre faveur et je prie pour votre âme. Il ne convient pas d'importuner les gouverneurs avant qu'un mois se soit écoulé.";
			link.l1 = "Je comprends, saint père. Je reviendrai plus tard.";
			link.l1.go = "exit";
		break;
		// <-- Indulgence

        case "work":
        	if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.AskOwner") && NPChar.location == PChar.GenQuest.ChurchQuest_1.ToColony + "_church")
        	{
        		dialog.text = "Désolé, "+ GetSexPhrase("mon fils", "ma fille") +", mais tous les confessionnaux sont occupés pour le moment. Je serai heureux d'entendre votre repentir d'ici une demi-heure au moins.";
				link.l1 = "Désolé, " + RandPhraseSimple("padre", "saint père") + ", cette affaire est d'une nature un peu différente. Le père " + PChar.GenQuest.ChurchQuest_1.PriestName + " de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen") + " vous a jadis confié de précieux trésors de sa bibliothèque théologique, et il m'a maintenant chargé de les récupérer si j'en avais l'occasion.";
				link.l1.go = "GenQuest_Church_1_Dialog_1";
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.AskOwner");
				break;
        	}
			dialog.text = "Quelle affaire vous amène, "+ GetSexPhrase("mon fils", "ma fille") +" ?";
			link.l1 = "Je voulais vous poser une question, padre...";
			link.l1.go = "quests"; // ссылка к НПС
            link.l2 = RandPhraseSimple("Je voudrais parler d'un travail au service de l'וglise de " + NationNameGenitive(sti(NPChar.nation)) + ".",
                                        "Comment vont les choses dans la paroisse, avez-vous besoin d'aide ?");
			link.l2.go = "prihod";
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
			{
	            link.l3 = RandPhraseSimple("Saint père", "Padre") + ", je voulais vous parler de questions financières."; //(пересылка в кредиты)
	            link.l3.go = "LoanForAll";
            }
			// -->
            if (stf(pchar.Health.HP) < 60.0)
            {
                link.l4 = "J'ai besoin de soins.";
                link.l4.go = "healthAdd_1";
				//Lipsar квест История давней дружбы
				if(CheckAttribute(PChar, "Luke.BadPoison"))
				{
						link.l4 = "Padre, aidez-moi. On m'a empoisonné avec un poison très puissant, que dois-je faire ?";
						link.l4.go = "LukePoison";
				}
            }
			// BlackThorn - Нежданное наследство
			if (CheckAttribute(PChar, "UnexpectedInheritance"))
            {
				if(!CheckAttribute(pchar, "UnexpectedInheritance_translator"))
				{
					link.l10 = "Saint père, j'ai mis la main sur un texte intéressant. Il est en latin. Puis-je vous demander de le traduire ?";
					link.l10.go = "UnexpectedInheritance_translate";
				}
				else
				{
					if(npchar.id == pchar.UnexpectedInheritance_translator && GetNpcQuestPastDayWOInit(npchar, "UnexpectedInheritance_translate") > 0 && sti(pchar.money) >= 1000)
					{
						link.l10 = "Saint père, je viens pour la traduction. Et voici, prenez ceci pour les besoins de la paroisse.";
						link.l10.go = "UnexpectedInheritance_translate_end";
					}
				}
            }
            //==> Вставка Эдди, квест Аззи, возможность сдачи лампы.
            if (CheckCharacterItem(pchar, "Azzy_bottle"))
            {
                link.l6 = "Saint père, j'ai quelque chose que je voudrais vous donner. C'est un étrange récipient en fer-blanc, regardez.";
                link.l6.go = "GiveLamp";
            }
			//<== Вставка Эдди, квест Аззи возможность сдачи лампы.
			//квест мэра - на связь с нашим шпионом
			if (CheckAttribute(pchar, "GenQuest.Intelligence") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "")
			{
	            link.l7 = RandPhraseSimple("Saint père", "Padre") + ", je viens de la part de quelqu'un : le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".";
	            link.l7.go = "IntelligenceForAll";
            }
			//==> успокоить нечисть в пещерах
			if (CheckAttribute(npchar, "quest.DestroyGhost") && npchar.quest.DestroyGhost == "GoodResult")
			{
				switch (npchar.quest.DestroyGhost.label)
				{
					case "Cave": sTemp = "la caverne est purgée"; break;
					case "cave": sTemp = "la caverne est purgée"; break;
					case "Grotto": sTemp = "la grotte est purgée"; break;
					case "grotto": sTemp = "la grotte est purgée"; break;
					case "Dungeon": sTemp = "le souterrain est purgé"; break;
					case "dungeon": sTemp = "le souterrain est purgé"; break;
				}
				link.l5 = "Saint père, " + sTemp + " des esprits malins. C'est fait, désormais plus personne n'importunera les habitants.";
                link.l5.go = "GhostShip_S1";
			}
			//==> ночной сторож в церкви
			if (CheckAttribute(pchar, "questTemp.different.Church_NightGuard") && pchar.questTemp.different.Church_NightGuard == npchar.location)
			{
	            link.l8 = RandPhraseSimple("Saint père", "Padre") + ", je viens vous rendre compte de ma mission de gardien de nuit.";
	            link.l8.go = "NightGuard_result";
            }
			//<== ночной сторож в церкви
			//==> провизия для прихода
			if (CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && PChar.GenQuest.ChurchProvision.QuestTown == NPChar.City)
			{
				if (GetCargoGoods(pchar, sti(PChar.GenQuest.ChurchProvision.GoodId)) >= sti(PChar.GenQuest.ChurchProvision.Qty))
				{
					link.l11 = "Saint père, j'ai apporté des vivres pour les pauvres de la paroisse.";
					link.l11.go = "Church_Provision_Deliver";
				}
				else
				{
					link.l11 = "Saint père, je n'ai pas encore réuni tous les vivres pour la paroisse.";
					link.l11.go = "Church_Provision_NotYet";
				}
			}
			//<== провизия для прихода
			//==> доставка реликвии (сдача в целевой церкви)
			if (CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && PChar.GenQuest.ChurchRelic.ToColony == NPChar.City && CheckCharacterItem(pchar, "Bible"))
			{
				link.l12 = "Saint père, je vous ai apporté une relique de la paroisse de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchRelic.QuestTown + "Gen") + ".";
				link.l12.go = "ChurchRelic_Deliver_1";
			}
			//<== доставка реликвии
			//==> вызволение монаха - доклад священнику после освобождения
			if (CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && PChar.GenQuest.ChurchRescue.QuestTown == NPChar.City && CheckAttribute(PChar, "GenQuest.ChurchRescue.Freed"))
			{
				link.l13 = "Saint père, c'est fait : frère " + PChar.GenQuest.ChurchRescue.MonkName + " est libre.";
				link.l13.go = "ChurchRescue_Report";
			}
			//<== вызволение монаха
			//==> беглый монах - доклад священнику
			if (CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && PChar.GenQuest.ChurchRunaway.QuestTown == NPChar.City && CheckAttribute(PChar, "GenQuest.ChurchRunaway.Outcome"))
			{
				link.l14 = "Saint père, j'ai retrouvé frère " + PChar.GenQuest.ChurchRunaway.MonkName + ".";
				link.l14.go = "ChurchRunaway_Report";
			}
			//<== беглый монах
			//==> сбор пожертвований - доклад священнику
			if (CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && PChar.GenQuest.ChurchDonate.QuestTown == NPChar.City && sti(PChar.GenQuest.ChurchDonate.DonorsDone) >= sti(PChar.GenQuest.ChurchDonate.DonorsTotal))
			{
				link.l15 = "Saint père, j'ai réuni les dons pour le temple.";
				link.l15.go = "ChurchDonate_Report";
			}
			//<== сбор пожертвований
			link.l99 = "J'ai changé d'avis, j'ai à faire.";
			link.l99.go = "exit";
		break;

		case "UnexpectedInheritance_translate":
			dialog.text = "Je suis désolé, mais je ne rends ce genre de services qu'à mes amis et aux vrais croyants. Je ne peux vous compter ni parmi les uns ni parmi les autres.";
			link.l1 = "Je le regrette vivement.";
			link.l1.go = "exit";
			if (sti(pchar.reputation) > (REPUTATION_NEUTRAL + 10))  // кибальчиш
			{
				dialog.text = "D'accord, je vais y jeter un œil. Revenez demain, "+GetSexPhrase("mon fils", "ma fille")+" et n'oubliez pas ceux qui sont dans le besoin.";
				SaveCurrentNpcQuestDateParam(npchar, "UnexpectedInheritance_translate");
				pchar.UnexpectedInheritance_translator = npchar.id;
				link.l1 = "Merci, saint père.";
				link.l1.go = "exit";
			}

		break;

		case "UnexpectedInheritance_translate_end":
			dialog.text = "Que Dieu vous bénisse. Voilà ce que j'ai trouvé.";
			link.l1 = "Merci, mon père.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -1000);
			UnexpectedInheritanceTranslatePart(pchar.UnexpectedInheritance);
			DeleteAttribute(pchar, "UnexpectedInheritance_translator");
			DeleteAttribute(pchar, "UnexpectedInheritance");

		break;

		case "prihod":
			//Ограбление церкви
			if(!CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "Oh, "+ GetSexPhrase("mon fils", "ma fille") +", un terrible blasphème a été commis, le plus honteux des crimes ! Voler l'église !!! C'est comme mettre ses pattes sales directement dans la poche du Seigneur !";
				link.l1 = "Oh, voilà donc !.. Et comment est-ce arrivé ?";
				link.l1.go = "GenQuest_Church_2_Start_3";
				NPChar.GenQuest.ChurchQuest_2.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			//упокоение нечисти
			if (rand(2)==1 && pchar.questTemp.different == "free" && !CheckAttribute(npchar, "quest.DestroyGhost") && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && GetNpcQuestPastDayWOInit(npchar, "Ghost") > 7 && NPChar.location != "Caiman_church")
			{
                dialog.text = "Il ne m'est pas très commode d'en parler, mais je n'ai pas le choix. Il n'y a pas de hasard dans la vie. Et la volonté du Tout-Puissant est en toute chose. Peut-être êtes-vous l'arme du Seigneur dont nous avons besoin pour anéantir les esprits malins qui souillent notre terre.";
        		link.l1 = RandPhraseSimple("Je ne comprends pas bien, saint père, ce qui vous a tant effrayé. Qu'est-ce qui cause cette peur ?",
                                            "Je vous en prie, continuez, saint père.");
        		link.l1.go = "DestroyGhost_1";
				SaveCurrentNpcQuestDateParam(npchar, "Ghost");
				npchar.quest.add = true;
				break;
			}
			//караулить церковь ночью
			if (!CheckAttribute(npchar, "quest.add") && rand(4)==1 && pchar.questTemp.different == "free" && !CheckAttribute(npchar, "quest.GuardNightChurch") && !CheckAttribute(pchar, "questTemp.different.Church_NightGuard") && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && GetNpcQuestPastDayWOInit(npchar, "NightChurch") > 60 && GetHour() < 23)
			{
                dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", j'ai une mission simple pour vous. Il nous faut un gardien de nuit, mais pas un vieillard avec un maillet, ni un paroissien sans défense. Le fait est que les « frères » sont un peu nerveux ces derniers temps. Des types étranges se sont mis à entrer dans l'église, mais ils ne prient pas, ils ne font que regarder autour d'eux...";
        		link.l1 = "Et cela vous inquiète, mon père ?";
				link.l1.go = "NightChurch_1";
				SaveCurrentNpcQuestDateParam(npchar, "NightChurch");
				break;
			}
			//провизия для бедняков прихода
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && NPChar.GenQuest.ChurchProvision.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "Le malheur frappe la paroisse, "+ GetSexPhrase("mon fils", "ma fille") +". Les mauvaises récoltes et les maladies ont poussé les pauvres au bord du gouffre, tandis que les marchands de la ville ont augmenté le prix des vivres. Les gens meurent de faim, et je n'ai rien pour les aider...";
				link.l1 = "Comment puis-je vous aider, saint père ?";
				link.l1.go = "Church_Provision_1";
				link.l2 = "Je compatis, mon père, mais ce n'est pas mon affaire.";
				link.l2.go = "exit";
				NPChar.GenQuest.ChurchProvision.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			//доставка реликвии в другую церковь
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckCharacterItem(pchar, "Bible") && NPChar.GenQuest.ChurchRelic.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "J'ai une mission délicate pour vous, "+ GetSexPhrase("mon fils", "ma fille") +". Une sainte relique est tombée entre les mains de notre paroisse, mais sa place est dans un autre temple, oם elle est particulièrement vénérée. La route par mer est longue et dangereuse...";
				link.l1 = "Quelle est cette relique, saint père, et oם faut-il la livrer ?";
				link.l1.go = "ChurchRelic_1";
				link.l2 = "Trouvez quelqu'un d'autre, mon père.";
				link.l2.go = "exit";
				NPChar.GenQuest.ChurchRelic.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			//вызволение захваченного монаха
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && NPChar.GenQuest.ChurchRescue.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "Nous sommes frappés par le malheur, "+ GetSexPhrase("mon fils", "ma fille") +". Un frère de notre couvent a été enlevé par des brigands qui le retiennent contre rançon, et la paroisse n'a pas une telle somme. Accepteriez-vous de libérer cette pauvre âme ?";
				link.l1 = "Dites-m'en plus, saint père.";
				link.l1.go = "ChurchRescue_1";
				link.l2 = "Je compatis, mon père, mais ce n'est pas mon affaire.";
				link.l2.go = "exit";
				NPChar.GenQuest.ChurchRescue.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			//беглый послушник в таверне
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && NPChar.GenQuest.ChurchRunaway.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "Il y a un autre chagrin, "+ GetSexPhrase("mon fils", "ma fille") +". Un jeune novice de notre couvent s'est lâchement enfui, incapable de supporter le fardeau monastique. On dit qu'il se cache quelque part en ville...";
				link.l1 = "Dites-m'en plus, saint père.";
				link.l1.go = "ChurchRunaway_1";
				link.l2 = "Ce n'est pas mon affaire, mon père.";
				link.l2.go = "exit";
				NPChar.GenQuest.ChurchRunaway.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			//сбор пожертвований на восстановление храма
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && NPChar.GenQuest.ChurchDonate.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && NPChar.location != "Caiman_church" && rand(4) == 1)
			{
				dialog.text = "Notre temple tombe en ruine, "+ GetSexPhrase("mon fils", "ma fille") +" : le toit fuit, l'autel est fissuré, et les caisses de la paroisse sont vides. Nous ne pouvons pas nous en sortir sans l'aide de bonnes âmes...";
				link.l1 = "Comment puis-je vous aider, saint père ?";
				link.l1.go = "ChurchDonate_1";
				link.l2 = "Je compatis, mon père, mais ce n'est pas mon affaire.";
				link.l2.go = "exit";
				NPChar.GenQuest.ChurchDonate.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
			}
			if(sti(NPChar.nation) != PIRATE && !CheckAttribute(PChar, "GenQuest.ChurchQuest_1.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchQuest_2.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchProvision.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRelic.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRescue.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchRunaway.StartQuest") && !CheckAttribute(PChar, "GenQuest.ChurchDonate.StartQuest") && NPChar.GenQuest.ChurchQuest_1.GiveQuestDateParam != iMonth && NPChar.GenQuest.ChurchQuest_1.GiveQuestDay != lastspeak_date && NPChar.location != "Panama_church" && rand(5) == 1)
		    {
		        	dialog.text = "C'est beau. Mais en ces jours difficiles, "+ GetSexPhrase("mon fils", "ma fille") +" tous ceux qui viennent au temple ne sont pas en mesure de servir notre Mère l'וglise.";
				link.l1 = LinkRandPhrase("Padre", "Saint père", "Mon père") + ", je suis de vraie foi chrétienne, et mes intentions de servir notre Mère l'וglise sont sincères."+ GetSexPhrase("Qui la soutiendra, sinon de loyaux chevaliers comme moi ?", "") +"";
				link.l1.go = "GenQuest_Church_1_Start_1";
				NPChar.GenQuest.ChurchQuest_1.GiveQuestDateParam = iMonth; // Предлагает квест не чаще раза в месяц
				break;
		    }
            dialog.text = "Tout est calme dans notre paroisse, "+ GetSexPhrase("mon fils", "ma fille") +". Merci de votre proposition.";
    		link.l2 = "Eh bien, puisque tout va bien, je vais vaquer à mes affaires.";
    		link.l2.go = "exit";
			DeleteAttribute(npchar, "quest.add");
			NPChar.GenQuest.ChurchQuest_1.GiveQuestDay = lastspeak_date;	// Если не дал сегодня, то токо на след день.
		break;

		// Провизия для бедняков прихода -->
		case "Church_Provision_1":
			int iProvGood; string sProvGood;
			switch(rand(3))
			{
				case "0": iProvGood = GOOD_WHEAT;  sProvGood = "blé"; break;
				case "1": iProvGood = GOOD_FRUITS; sProvGood = "fruits"; break;
				case "2": iProvGood = GOOD_SUGAR;  sProvGood = "sucre"; break;
				case "3": iProvGood = GOOD_FOOD;   sProvGood = "vivres"; break;
			}
			int iProvQty = 100 + sti(pchar.rank) * 10;
			PChar.GenQuest.ChurchProvision.GoodId = iProvGood;
			PChar.GenQuest.ChurchProvision.Qty = iProvQty;
			PChar.GenQuest.ChurchProvision.GoodName = sProvGood;
			dialog.text = "Apportez-moi " + iProvQty + " unités de " + sProvGood + " à distribuer aux nécessiteux, "+ GetSexPhrase("mon fils", "ma fille") +". Je ne peux pas vous offrir d'argent pour cela, mais le Seigneur n'oubliera pas votre bonté, et la considération de " + NationNameGenitive(sti(NPChar.nation)) + " à votre égard grandira.";
			link.l1 = "Je vais vous aider, saint père. J'apporterai les vivres.";
			link.l1.go = "Church_Provision_Start";
			link.l2 = "Je n'ai pas de temps pour la charité.";
			link.l2.go = "exit";
		break;

		case "Church_Provision_Start":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchProvision.StartQuest = true;
			PChar.GenQuest.ChurchProvision.QuestTown = NPChar.City;
			PChar.GenQuest.ChurchProvision.PriestName = NPChar.name;
			PChar.GenQuest.ChurchProvision.Nation = sti(NPChar.nation);
			sTitle = NPChar.City + "ChurchProvision";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "ChurchProvision", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sTitle, "sQty", PChar.GenQuest.ChurchProvision.Qty);
			AddQuestUserData(sTitle, "sGood", PChar.GenQuest.ChurchProvision.GoodName);
		break;

		case "Church_Provision_NotYet":
			dialog.text = "Hâtez-vous, "+ GetSexPhrase("mon fils", "ma fille") +". Chaque jour de retard coמte la vie à quelqu'un. Il me faut " + PChar.GenQuest.ChurchProvision.Qty + " unités de " + PChar.GenQuest.ChurchProvision.GoodName + ".";
			link.l1 = "Je comprends, saint père. Je reviendrai vite.";
			link.l1.go = "exit";
		break;

		case "Church_Provision_Deliver":
			dialog.text = "Que le Seigneur vous bénisse, "+ GetSexPhrase("mon fils", "ma fille") +" ! Les pauvres de la paroisse prieront pour vous. Sachez que la considération de " + NationNameGenitive(sti(NPChar.nation)) + " à votre égard va s'améliorer.";
			link.l1 = "J'ai été heureux d'aider, saint père.";
			link.l1.go = "exit";
			RemoveCharacterGoods(pchar, sti(PChar.GenQuest.ChurchProvision.GoodId), sti(PChar.GenQuest.ChurchProvision.Qty));
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			OfficersReaction("good");
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous avez apporté des vivres pour les pauvres de notre paroisse. Une bonne action, que le Seigneur vous garde...",
				"Vous avez entendu ? Quelqu'un a donné des vivres à la paroisse pour ceux qui meurent de faim. Quelle charité !",
				"Notre saint père, " + GetFullName(npchar) + ", vous remercie d'avoir aidé les paroissiens affamés."), npchar.city, 10, 1, "");
			AchievementsCounter_genquests(1);
			sTitle = NPChar.City + "ChurchProvision";
			AddQuestRecordEx(sTitle, "ChurchProvision", "2");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - провиант для прихода
			DeleteAttribute(PChar, "GenQuest.ChurchProvision");
			NPChar.GenQuest.ChurchProvision.GiveQuestDateParam = iMonth;
		break;
		// <-- Провизия для бедняков прихода

		// Доставка реликвии -->
		case "ChurchRelic_1":
			string sRelicColony = SelectNotEnemyColony(NPChar);
			int iRelicVariant = rand(2);
			string sRelicName;
			switch(iRelicVariant)
			{
				case "0": sRelicName = "un calice d'argent"; break;
				case "1": sRelicName = "un crucifix de bronze"; break;
				case "2": sRelicName = "une croix-reliquaire dorée"; break;
			}
			PChar.GenQuest.ChurchRelic.ToColony = sRelicColony;
			PChar.GenQuest.ChurchRelic.ToName = characters[GetCharacterIndex(sRelicColony + "_Priest")].Name;
			PChar.GenQuest.ChurchRelic.Variant = iRelicVariant;
			PChar.GenQuest.ChurchRelic.RelicName = sRelicName;
			dialog.text = "Il s'agit d' " + sRelicName + ", "+ GetSexPhrase("mon fils", "ma fille") +". Portez cet objet sacré au père " + PChar.GenQuest.ChurchRelic.ToName + " à " + XI_ConvertString("Colony" + sRelicColony + "Acc") + " – et remettez-le-lui en main propre. Gardez bien la relique en chemin : les méchants pourraient la convoiter.";
			link.l1 = "Je la livrerai saine et sauve, saint père.";
			link.l1.go = "ChurchRelic_Start";
			link.l2 = "C'est trop de tracas. Adieu.";
			link.l2.go = "exit";
		break;

		case "ChurchRelic_Start":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchRelic.StartQuest = true;
			PChar.GenQuest.ChurchRelic.QuestTown = NPChar.City;
			PChar.GenQuest.ChurchRelic.PriestName = NPChar.name;
			PChar.GenQuest.ChurchRelic.Nation = sti(NPChar.nation);
			// переодеваем шаблон Bible в реликвию ДО выдачи, чтобы всплывашка показала название реликвии
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchRelic.ToColony + "Gen");
			switch(sti(PChar.GenQuest.ChurchRelic.Variant))
			{
				case "0": // серебряный потир
					items[FindItem("Bible")].Name = "itmname_ChurchRelicCup";
					items[FindItem("Bible")].Weight = 5.0;
					items[FindItem("Bible")].picIndex = 9;
					items[FindItem("Bible")].picTexture = "ITEMS_7";
					ChangeItemDescribe("Bible", "itmdescr_ChurchRelicCup");
				break;
				case "1": // бронзовое распятие
					items[FindItem("Bible")].Name = "itmname_ChurchRelicCross";
					items[FindItem("Bible")].Weight = 3.0;
					items[FindItem("Bible")].picIndex = 9;
					items[FindItem("Bible")].picTexture = "ITEMS_2";
					ChangeItemDescribe("Bible", "itmdescr_ChurchRelicCross");
				break;
				case "2": // золочёный крест-мощевик
					items[FindItem("Bible")].Name = "itmname_ChurchRelicReliquary";
					items[FindItem("Bible")].Weight = 3.0;
					items[FindItem("Bible")].picIndex = 5;
					items[FindItem("Bible")].picTexture = "ITEMS_12";
					ChangeItemDescribe("Bible", "itmdescr_ChurchRelicReliquary");
				break;
			}
			AddItems(PChar, "Bible", 1);
			PlaySound("interface\important_item.wav");
			sTitle = NPChar.City + "ChurchRelic";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "ChurchRelic", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRelic.ToColony + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchRelic.ToColony + "Gen"));
			AddQuestUserData(sTitle, "sName", PChar.GenQuest.ChurchRelic.ToName);
			AddQuestUserData(sTitle, "sRelic", PChar.GenQuest.ChurchRelic.RelicName);
		break;

		case "ChurchRelic_Deliver_1":
			dialog.text = "Loué soit le Seigneur ! Cet objet sacré était attendu depuis longtemps dans notre temple. Au nom de la paroisse de " + XI_ConvertString("Colony" + NPChar.City + "Gen") + " – je vous remercie, "+ GetSexPhrase("mon fils", "ma fille") +". Acceptez une modeste récompense en signe de gratitude.";
			link.l1 = "Merci, saint père. Que cet argent serve à la gloire de Dieu : gardez-le pour la paroisse.";
			link.l1.go = "ChurchRelic_Deliver_Refuse";
			link.l2 = "Merci, saint père. La route n'a pas été facile.";
			link.l2.go = "ChurchRelic_Deliver_TakeMoney";
		break;

		case "ChurchRelic_Deliver_TakeMoney":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			// возвращаем Bible исходный вид (инлайн)
			RemoveItems(PChar, "Bible", 1);
			items[FindItem("Bible")].Name = "itmname_bible";
			items[FindItem("Bible")].Weight = 2;
			items[FindItem("Bible")].picIndex = 6;
			items[FindItem("Bible")].picTexture = "ITEMS_9";
			DeleteAttribute(items[FindItem("Bible")], "City");
			BackItemDescribe("Bible");
			AddMoneyToCharacter(pchar, (sti(pchar.rank) + 5) * 1000);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			AddCharacterExpToSkill(pchar, "Fortune", 30);
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			sTitle = PChar.GenQuest.ChurchRelic.QuestTown + "ChurchRelic";
			AddQuestRecordEx(sTitle, "ChurchRelic", "2");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - вернул реликвию
			DeleteAttribute(PChar, "GenQuest.ChurchRelic");
		break;

		case "ChurchRelic_Deliver_Refuse":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			// возвращаем Bible исходный вид (инлайн)
			RemoveItems(PChar, "Bible", 1);
			items[FindItem("Bible")].Name = "itmname_bible";
			items[FindItem("Bible")].Weight = 2;
			items[FindItem("Bible")].picIndex = 6;
			items[FindItem("Bible")].picTexture = "ITEMS_9";
			DeleteAttribute(items[FindItem("Bible")], "City");
			BackItemDescribe("Bible");
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			AddCharacterExpToSkill(pchar, "Leadership", 40);
			AddCharacterExpToSkill(pchar, "Fortune", 30);
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous avez apporté une sainte relique à notre temple sans prendre une seule pièce en échange. Une action pieuse !",
				"Vous avez entendu ? Quelqu'un a apporté un objet sacré à notre paroisse et a refusé toute récompense. Voilà ce qu'est la vraie foi !",
				"Notre saint père vous remercie pour la relique que vous avez livrée et pour votre générosité désintéressée."), npchar.city, 10, 1, "");
			sTitle = PChar.GenQuest.ChurchRelic.QuestTown + "ChurchRelic";
			AddQuestRecordEx(sTitle, "ChurchRelic", "3");
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - вернул реликвию и отказался от награды
			DeleteAttribute(PChar, "GenQuest.ChurchRelic");
		break;
		// <-- Доставка реликвии

		// Вызволение монаха -->
		case "ChurchRescue_1":
			string sMonk;
			switch(rand(3))
			{
				case "0": sMonk = "Ignacio"; break;
				case "1": sMonk = "Bartholomew"; break;
				case "2": sMonk = "Dominic"; break;
				case "3": sMonk = "Anselmo"; break;
			}
			int iRansom = (sti(pchar.rank) + 3) * 2000;
			PChar.GenQuest.ChurchRescue.MonkName = sMonk;
			PChar.GenQuest.ChurchRescue.Ransom = iRansom;
			dialog.text = "Frère " + sMonk + " a été enlevé par des brigands qui le retiennent dans leur repaire, une grotte. Pour sa liberté, ils exigent une rançon : " + FindRussianMoneyString(iRansom) + ". Rejoignez leur repaire et libérez le frère : payez la rançon ou abattez ses ravisseurs, comme bon vous semblera.";
			link.l1 = "Je m'en charge, saint père.";
			link.l1.go = "ChurchRescue_Start";
			link.l2 = "Trop dangereux. Adieu.";
			link.l2.go = "exit";
		break;

		case "ChurchRescue_Start":
			// похитители ждут у входа в пещеру на острове прихода (локация CaveEntrance)
			PChar.GenQuest.ChurchRescue.CaveId = ChurchRescue_FindCaveEntrance(NPChar.location);
			if (PChar.GenQuest.ChurchRescue.CaveId == "none")
			{
				dialog.text = "Attendez, "+ GetSexPhrase("mon fils", "ma fille") +"... Un messager vient d'arriver : le frère a réussi à s'échapper seul et il est déjà sur le chemin du retour. Loué soit le Seigneur ! Pardonnez-moi de vous avoir dérangé pour rien.";
				link.l1 = "Heureux de l'apprendre, saint père.";
				link.l1.go = "exit";
				DeleteAttribute(PChar, "GenQuest.ChurchRescue");
				break;
			}
			PChar.GenQuest.ChurchRescue.StartQuest = true;
			PChar.GenQuest.ChurchRescue.QuestTown = NPChar.City;
			PChar.GenQuest.ChurchRescue.PriestName = NPChar.name;
			PChar.GenQuest.ChurchRescue.Nation = sti(NPChar.nation);
			SetFunctionLocationCondition("ChurchRescue_SpawnCaptors", PChar.GenQuest.ChurchRescue.CaveId, false);
			sTitle = NPChar.City + "ChurchRescue";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "ChurchRescue", "1");
			AddQuestUserDataForTitle(sTitle, "sMonk", PChar.GenQuest.ChurchRescue.MonkName);
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRescue.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sTitle, "sLocation", "dans leur repaire, une grotte");
			AddQuestUserData(sTitle, "sMoney", FindRussianMoneyString(sti(PChar.GenQuest.ChurchRescue.Ransom)));
			dialog.text = "Que Dieu vous bénisse, "+ GetSexPhrase("mon fils", "ma fille") +". Allez, et que la main du Seigneur vous guide. Revenez me voir avec des nouvelles de frère " + PChar.GenQuest.ChurchRescue.MonkName + ".";
			link.l1 = "Je trouverai l'endroit, saint père.";
			link.l1.go = "exit";
		break;

		case "ChurchRescue_Report":
			sTitle = NPChar.City + "ChurchRescue";
			if (PChar.GenQuest.ChurchRescue.Freed == "fight")
			{
				dialog.text = "Gloire à Dieu, vous avez ramené frère " + PChar.GenQuest.ChurchRescue.MonkName + " ! Et vous avez puni ces misérables, bon débarras. Acceptez nos remerciements chaleureux et ce modeste présent de la paroisse.";
				ChangeCharacterReputation(pchar, 5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
				AddCharacterExpToSkill(pchar, "Leadership", 60);
				AddCharacterExpToSkill(pchar, "Fortune", 40);
				AddMoneyToCharacter(pchar, (sti(pchar.rank) + 3) * 800);
			}
			else
			{
				dialog.text = "Gloire à Dieu, frère " + PChar.GenQuest.ChurchRescue.MonkName + " est libre ! Vous avez agi avec sagesse, sans verser le sang. La paroisse vous remboursera une partie de vos frais, et le Seigneur vous comptera cette bonne action.";
				ChangeCharacterReputation(pchar, 3);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
				if (PChar.GenQuest.ChurchRescue.Freed == "threaten") AddCharacterExpToSkill(pchar, "Leadership", 50);
				else AddCharacterExpToSkill(pchar, "Sneak", 50);
				if (PChar.GenQuest.ChurchRescue.Freed == "pay") AddMoneyToCharacter(pchar, makeint(sti(PChar.GenQuest.ChurchRescue.Ransom)/2)); // вернул часть выкупа
				else AddMoneyToCharacter(pchar, (sti(pchar.rank) + 2) * 300); // обман/запугивание - скромная лепта от прихода
			}
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous avez libéré frère " + PChar.GenQuest.ChurchRescue.MonkName + " de sa captivité. Une action pieuse !",
				"Vous avez entendu ? Frère " + PChar.GenQuest.ChurchRescue.MonkName + " est de retour au couvent : on l'a libéré d'un repaire de brigands.",
				"Notre saint père vous remercie d'avoir sauvé frère " + PChar.GenQuest.ChurchRescue.MonkName + "."), npchar.city, 10, 1, "");
			AddQuestRecordEx(sTitle, "ChurchRescue", "3");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRescue.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - вызволил монаха
			link.l1 = "J'ai été heureux d'aider, saint père.";
			link.l1.go = "exit";
			DeleteAttribute(PChar, "GenQuest.ChurchRescue");
		break;
		// <-- Вызволение монаха

		// Беглый монах -->
		case "ChurchRunaway_1":
			string sRunMonk;
			switch(rand(3))
			{
				case "0": sRunMonk = "Benedict"; break;
				case "1": sRunMonk = "Sylvester"; break;
				case "2": sRunMonk = "Matteo"; break;
				case "3": sRunMonk = "Lorenzo"; break;
			}
			PChar.GenQuest.ChurchRunaway.MonkName = sRunMonk;
			dialog.text = "Frère " + sRunMonk + " - c'est ainsi qu'il s'appelle. Il est très jeune, et la peur de prononcer ses vœux l'a submergé. Cherchez-le dans la taverne de notre ville et décidez de ce que vous ferez de lui : le raisonner et le ramener au couvent, ou agir selon votre conscience. Je vous en supplie seulement : ne lui faites pas de mal inutilement.";
			link.l1 = "Je le trouverai, saint père.";
			link.l1.go = "ChurchRunaway_Start";
			link.l2 = "Je n'ai pas de temps pour ça. Adieu.";
			link.l2.go = "exit";
		break;

		case "ChurchRunaway_Start":
			if (FindLocation(NPChar.City + "_tavern") == -1)
			{
				dialog.text = "Mais... attendez. On me dit que le frère est revenu de lui-même au couvent, repentant. Loué soit le Seigneur ! Pardonnez-moi de vous avoir dérangé.";
				link.l1 = "Heureux de l'apprendre, saint père.";
				link.l1.go = "exit";
				DeleteAttribute(PChar, "GenQuest.ChurchRunaway");
				break;
			}
			PChar.GenQuest.ChurchRunaway.StartQuest = true;
			PChar.GenQuest.ChurchRunaway.QuestTown = NPChar.City;
			PChar.GenQuest.ChurchRunaway.PriestName = NPChar.name;
			PChar.GenQuest.ChurchRunaway.Nation = sti(NPChar.nation);
			SetFunctionLocationCondition("ChurchRunaway_SpawnMonk", NPChar.City + "_tavern", false);
			sTitle = NPChar.City + "ChurchRunaway";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "ChurchRunaway", "1");
			AddQuestUserDataForTitle(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			dialog.text = "Que Dieu vous bénisse. Cherchez frère " + PChar.GenQuest.ChurchRunaway.MonkName + " dans la taverne de " + XI_ConvertString("Colony" + NPChar.City + "Gen") + ". Et je vous en prie, soyez doux avec lui : il est encore si jeune et si effrayé.";
			link.l1 = "Je comprends, saint père.";
			link.l1.go = "exit";
		break;

		case "ChurchRunaway_Report":
			sTitle = NPChar.City + "ChurchRunaway";
			if (PChar.GenQuest.ChurchRunaway.Outcome == "persuade")
			{
				dialog.text = "Vous avez ramené une âme égarée à la raison et remis frère " + PChar.GenQuest.ChurchRunaway.MonkName + " sur le chemin du Seigneur ! C'est une grande bénédiction. Acceptez notre sincère gratitude et cette modeste offrande.";
				ChangeCharacterReputation(pchar, 5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
				AddCharacterExpToSkill(pchar, "Leadership", 50);
				AddMoneyToCharacter(pchar, (sti(pchar.rank) + 3) * 600);
			}
			if (PChar.GenQuest.ChurchRunaway.Outcome == "force")
			{
				dialog.text = "Frère " + PChar.GenQuest.ChurchRunaway.MonkName + " est de retour au couvent, même s'il y a été ramené de force... Eh bien, le corps est revenu, et nous sauverons l'âme par la prière. Merci tout de même.";
				ChangeCharacterReputation(pchar, -1);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
				AddCharacterExpToSkill(pchar, "Leadership", 20);
				AddMoneyToCharacter(pchar, (sti(pchar.rank) + 3) * 300);
			}
			if (PChar.GenQuest.ChurchRunaway.Outcome == "release")
			{
				dialog.text = "Vous l'avez donc laissé partir... Il est dommage de perdre un frère, mais c'est peut-être la volonté du Seigneur : tout le monde n'est pas fait pour la vie monastique. Vous avez fait preuve de miséricorde, et cela vous sera compté.";
				ChangeCharacterReputation(pchar, 3);
				AddCharacterExpToSkill(pchar, "Fortune", 40);
			}
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			AddQuestRecordEx(sTitle, "ChurchRunaway", "3");
			AddQuestUserData(sTitle, "sMonk", PChar.GenQuest.ChurchRunaway.MonkName);
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - помог беглецу
			link.l1 = "Adieu, saint père.";
			link.l1.go = "exit";
			DeleteAttribute(PChar, "GenQuest.ChurchRunaway");
		break;
		// <-- Беглый монах

		// Сбор пожертвований -->
		case "ChurchDonate_1":
			dialog.text = "Le toit du temple fuit et l'autel est délabré, "+ GetSexPhrase("mon fils", "ma fille") +", et il n'y a pas d'argent pour les réparations. Faites le tour des bourgeois aisés sur la place : ils ne refuseront pas une contribution à quelqu'un de connu comme vous. Une fois la somme réunie, revenez me voir.";
			link.l1 = "Je vais réunir les dons, saint père.";
			link.l1.go = "ChurchDonate_Start";
			link.l2 = "Je n'ai pas de temps pour ça. Adieu.";
			link.l2.go = "exit";
		break;

		case "ChurchDonate_Start":
			if (FindLocation(NPChar.City + "_town") == -1)
			{
				dialog.text = "Mais... attendez. Les paroissiens, en apprenant notre détresse, ont déjà apporté leurs contributions au temple. Loué soit le Seigneur ! Pardonnez-moi de vous avoir dérangé.";
				link.l1 = "Heureux de l'apprendre, saint père.";
				link.l1.go = "exit";
				DeleteAttribute(PChar, "GenQuest.ChurchDonate");
				break;
			}
			PChar.GenQuest.ChurchDonate.StartQuest = true;
			PChar.GenQuest.ChurchDonate.QuestTown = NPChar.City;
			PChar.GenQuest.ChurchDonate.PriestName = NPChar.name;
			PChar.GenQuest.ChurchDonate.Nation = sti(NPChar.nation);
			PChar.GenQuest.ChurchDonate.Collected = 0;
			PChar.GenQuest.ChurchDonate.DonorsDone = 0;
			PChar.GenQuest.ChurchDonate.DonorsTotal = 3;
			SetFunctionLocationCondition("ChurchDonate_SpawnDonors", NPChar.City + "_town", false);
			sTitle = NPChar.City + "ChurchDonate";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "ChurchDonate", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			dialog.text = "Que Dieu vous bénisse. Cherchez les bourgeois généreux sur la place de " + XI_ConvertString("Colony" + NPChar.City + "Gen") + ", et revenez me voir avec ce que vous aurez réuni.";
			link.l1 = "Je comprends, saint père.";
			link.l1.go = "exit";
		break;

		case "ChurchDonate_Report":
			dialog.text = "Alors, "+ GetSexPhrase("mon fils", "ma fille") +", nos bourgeois se sont-ils montrés généreux ?";
			link.l1 = "Voici jusqu'à la dernière pièce, saint père : " + FindRussianMoneyString(sti(PChar.GenQuest.ChurchDonate.Collected)) + ".";
			link.l1.go = "ChurchDonate_GiveAll";
			link.l2 = "Voici les dons des paroissiens, saint père.";
			link.l2.go = "ChurchDonate_Skim";
		break;

		case "ChurchDonate_GiveAll":
			sTitle = NPChar.City + "ChurchDonate";
			dialog.text = "Que le Seigneur vous récompense, "+ GetSexPhrase("mon fils", "ma fille") +" ! Avec de tels moyens, le temple sera restauré. Acceptez-en une petite part en remerciement de votre peine, ainsi que notre bénédiction.";
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			AddMoneyToCharacter(pchar, makeint(sti(PChar.GenQuest.ChurchDonate.Collected)/10) - sti(PChar.GenQuest.ChurchDonate.Collected));
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous avez réuni des dons pour restaurer notre temple. Une action pieuse !",
				"Vous avez entendu ? Le temple sera bientכt réparé : quelqu'un a réuni de généreux dons pour la paroisse.",
				"Notre saint père vous remercie du soin que vous prenez de la maison de Dieu."), npchar.city, 10, 1, "");
			AddQuestRecordEx(sTitle, "ChurchDonate", "3");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sTitle);
			link.l1 = "J'ai été heureux d'aider, saint père.";
			link.l1.go = "exit";
			DeleteAttribute(PChar, "GenQuest.ChurchDonate");
		break;

		case "ChurchDonate_Skim":
			sTitle = NPChar.City + "ChurchDonate";
			if (rand(100) < 30 + GetCharacterSkill(pchar, "Sneak"))
			{
				int iSkim = makeint(sti(PChar.GenQuest.ChurchDonate.Collected)/3);
				AddMoneyToCharacter(pchar, iSkim - sti(PChar.GenQuest.ChurchDonate.Collected)); // отдаём всё, оставляя себе треть
				dialog.text = "Merci de votre zèle, "+ GetSexPhrase("mon fils", "ma fille") +". Ces fonds serviront au bien de la paroisse. Allez en paix.";
				ChangeCharacterReputation(pchar, -1);
				AddCharacterExpToSkill(pchar, "Sneak", 40);
				AddQuestRecordEx(sTitle, "ChurchDonate", "4");
			}
			else
			{
				dialog.text = "Attendez... c'est moins que ce que mes ouailles ont donné. Je connais mes paroissiens, "+ GetSexPhrase("mon fils", "ma fille") +", et leur générosité. Auriez-vous empoché une partie de l'argent du temple ?! Honte à vous ! Je ne veux plus vous revoir.";
				ChangeCharacterReputation(pchar, -5);
				ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -5);
				npchar.quest.BadMeeting = lastspeak_date;
				AddMoneyToCharacter(pchar, -sti(PChar.GenQuest.ChurchDonate.Collected)); AddQuestRecordEx(sTitle, "ChurchDonate", "5"); // уличённый отдаёт всё собранное
			}
			OfficersReaction("good");
			AchievementsCounter_genquests(1);
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			CloseQuestHeader(sTitle);
			link.l1 = "...";
			link.l1.go = "exit";
			DeleteAttribute(PChar, "GenQuest.ChurchDonate");
		break;
		// <-- Сбор пожертвований

		// Вернуть рукописи священника -->
		case "GenQuest_Church_1_Start_1":
			dialog.text = "Eh bien, j'ai une mission délicate, qui exigera non seulement la pureté des pensées, mais aussi un courage considérable et une grande finesse d'esprit...";
				link.l1 = LinkRandPhrase("Padre", "Saint père", "Mon père") + ", je serai heureux de vous rendre n'importe quel service, même s'il me faut descendre en enfer pour cela ! Soit dit sans offenser l'וglise.";
				link.l1.go = "GenQuest_Church_1_Start_2";
			break;

		case "GenQuest_Church_1_Start_2":
			PChar.GenQuest.ChurchQuest_1.QuestTown = NPChar.City;
			Church_GenQuest1_InitStartParam(NPChar);
			dialog.text = "Voilà qui est bien ! C'est bien... Mais l'affaire est extrêmement délicate... Il y a quelque temps, le recteur de l'église de " + PChar.GenQuest.ChurchQuest_1.ToName + " de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Gen") + ", sur l'île de " + XI_ConvertString(PChar.GenQuest.ChurchQuest_1.ToIsland + "Voc") + " m'a demandé de lui prêter pour un temps quelques ouvrages théologiques et des manuscrits anciens de la bibliothèque de l'église. Comme la demande était appuyée par l'exigence de l'archevêque de ne pas entraver la diffusion de la bienfaisante lumière du savoir, je n'ai pas pu refuser, tout en me doutant que les difficultés des voyages en mer ne lui permettraient pas de rendre les manuscrits à temps... Pourriez-vous aider à régler ce problème ?";
			link.l1 = "J'ai bien peur," + LinkRandPhrase("padre", "saint père", " mon père, ") + "de ne pas être digne de votre confiance. L'affaire est trop délicate, il faut être un bon diplomate pour la régler.";
			link.l1.go = "exit";
			link.l2 = LinkRandPhrase("Padre", "Saint père", "Mon père") + ", votre mission ne me paraît pas difficile. Je me mets en route dès aujourd'hui.";
			link.l2.go = "GenQuest_Church_1_Start_3";
			break;

		case "GenQuest_Church_1_Start_3":	// Квест взят
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchQuest_1.StartQuest = true;
			PChar.GenQuest.ChurchQuest_1.PriestName = NPChar.name;
			PChar.GenQuest.ChurchQuest_1.Nation = sti(NPChar.nation);
			PChar.GenQuest.ChurchQuest_1.AskOwner = true;
			sQuestTitle = NPChar.City + "ChurchGenQuest1";
			ReOpenQuestHeader(sQuestTitle);
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "1");
			AddQuestUserDataForTitle(sQuestTitle, "sCity", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sName", NPChar.name);
			AddQuestUserData(sQuestTitle, "sOwnerCity", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Gen"));
			break;

		case "GenQuest_Church_1_Dialog_1":
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.2A_Scene"))	// Сцена 2а
			{
				dialog.text = "Oh !.. Oui... En effet, je m'en souviens... Mais, "+ GetSexPhrase("mon fils", "ma fille") +" : ces trésors sont plus spirituels que matériels, ils ont apporté un bienfait inestimable à mes paroissiens et pourraient encore leur en apporter à l'avenir !";
				link.l1 = "Cependant, " + LinkRandPhrase("padre", "saint père", " mon père, ") + ", les âmes des paroissiens du père " + PChar.GenQuest.ChurchQuest_1.PriestName + " ont elles aussi besoin d'être sauvées, et sans ces ouvrages, il est privé du soutien des piliers de la théosophie et de l'inspiration pour ses sermons.";
				link.l1.go = "GenQuest_Church_1_Dialog_1_1";
			}
			else	// Сцена 2б-а и 2б-б
			{
				dialog.text = "Oh, oui !.. En effet... "+ GetSexPhrase("Mon fils", "Ma fille") +"ces trésors sont plus spirituels que matériels, ils ont apporté tant de bienfaits à mes paroissiens que, à ma grande honte, j'ai quelque peu tardé à les rendre à leur propriétaire...";
				link.l1 = "Exactement, " + RandPhraseSimple("padre", "saint père") + " exactement. C'est pourquoi le père " + PChar.GenQuest.ChurchQuest_1.PriestName + " m'a chargé de lui remettre ces livres en main propre.";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2";
			}
		break;

		case "GenQuest_Church_1_Dialog_1_1": // Сцена 2а
			dialog.text = "Je comprends, mon enfant, mais ne prions-nous pas le Seigneur chaque jour : « Pardonne-nous nos offenses, comme nous pardonnons à ceux qui nous ont offensés » ? Or l'église de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.ToColony + "Gen") + " est infiniment plus riche que ma modeste paroisse.";
			link.l1 = "Oui, saint père, vous avez raison, mais d'autres paroles me sont venues à l'esprit : « Ne cherche pas les chemins faciles, car le Diable nous y attend, et sa voix est d'autant plus insinuante, et la tentation d'autant plus forte, que le chemin est aisé ! » Et le padre " + PChar.GenQuest.ChurchQuest_1.PriestName + " avait déjà l'intention de signaler votre négligence à l'archevêque, mais je l'en ai dissuadé en lui proposant mon aide.";
			link.l1.go = "GenQuest_Church_1_Dialog_1_1_1";
		break;

		case "GenQuest_Church_1_Dialog_1_1_1":
			dialog.text = "א-à-à l'archevêque ?! Pour une si petite chose !.. Mais pourquoi, pourquoi ? Je voulais moi-même depuis longtemps envoyer ces ouvrages à mon cher frère en Christ, mais je n'ai jamais trouvé d'occasion sמre. Mais en vous, "+ GetSexPhrase("mon fils", "ma fille") +", j'ai vu un digne serviteur de Dieu. Tenez, je vous remets les livres et les manuscrits ; remettez-les au père " + PChar.GenQuest.ChurchQuest_1.PriestName + " sains et saufs, en y joignant mes plus profonds remerciements.";
			link.l1 = "Je n'y manquerai pas, " + LinkRandPhrase("padre", "saint père", "mon père") + ". Absolument.";
			link.l1.go = "GenQuest_Church_1_Dialog_1_1_2";
		break;

		case "GenQuest_Church_1_Dialog_1_1_2":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchQuest_1.Complete.Short = true;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "2");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown));
			// Предмет "the manuscript" -->
			AddItems(PChar, "Bible", 1);	// Даём рукописи
			items[FindItem("Bible")].Name = "itmname_ChurchGenQuest1Bible";	// Меняем имя. Потом поменять обратно!
			ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest1Bible"); // Меняем дескрайб. Потом поменять обратно!
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"); // Переменная. Потом удалить!
			// <-- Предмет "the manuscript"
			break;

		case "GenQuest_Church_1_Dialog_1_2":	// Сцена 2б-а и 2б-б
			// Генерим кэпа -->
			sld = GetCharacter(NPC_GenerateCharacter("ChurchGenQuest1_Cap", "officer_" + (rand(42)+1), "man", "man", 15, NPChar.nation, -1, true));
			FantomMakeCoolFighter(sld, 35, 40, 35, "blade24", "pistol3", 30);
			FantomMakeCoolSailor(sld, 7 + rand(2), "", CANNON_TYPE_CANNON_LBS24, 75, 70, 65);
			sld.Abordage.Enable = false;
			sld.ShipEnemyDisable  = true; // флаг не обижаться на выстрелы
			LAi_SetImmortal(sld, true);
			sld.Dialog.FileName = "GenQuests_Dialog.c";
		//	sld.DeckDialogNode = "ChurchGenQuest_1_DeckDialog_1"; // Выставляем ноду диалога на палубе корабля
			sld.Dialog.CurrentNode = "ChurchGenQuest_1_DeckDialog_1";
			Group_FindOrCreateGroup("ChurchGenQuest1_CapGroup");
			Group_AddCharacter("ChurchGenQuest1_CapGroup", "ChurchGenQuest1_Cap");
			Group_SetType("ChurchGenQuest1_CapGroup", "trade");
			Group_SetGroupCommander("ChurchGenQuest1_CapGroup", "ChurchGenQuest1_Cap");
			Group_SetTaskNone("ChurchGenQuest1_CapGroup");
			Group_LockTask("ChurchGenQuest1_CapGroup");
			PChar.GenQuest.ChurchQuest_1.AskPortMan = true;
			PChar.GenQuest.ChurchQuest_1.CurPortManColony = "";
			PChar.GenQuest.ChurchQuest_1.CapFullName = GetFullname(sld);
			PChar.GenQuest.ChurchQuest_1.CapShipName = sld.Ship.Name;
			PChar.GenQuest.ChurchQuest_1.NoCapColony = NPChar.city;
			PChar.GenQuest.ChurchQuest_1.CapColony = GetColonyExpect2Colonies(NPChar.city, PChar.GenQuest.ChurchQuest_1.QuestTown);
			// <-- Генерим кэпа

			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.2BA_Scene")) // Сцена 2б-а
			{
				dialog.text = "Mais, "+ GetSexPhrase("mon fils", "ma fille") +"... Le fait est que la semaine dernière, j'ai eu l'occasion de rencontrer le capitaine du navire '" + sld.Ship.Name + "', oם l'on m'avait appelé pour donner la communion à un marin mourant. א ma grande joie, le capitaine " + GetFullName(sld) + " m'a annoncé qu'il se rendait à " + XI_ConvertString("Colony" + GetColonyExpect2Colonies(NPChar.city, PChar.GenQuest.ChurchQuest_1.QuestTown)) + ". Et même s'il ne garantissait pas les délais, il a accepté de rendre service, en m'assurant qu'il ferait sans faute escale au port de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen") + " - c'est certain. Bien sמr, j'ai saisi l'occasion : j'ai confié les livres à cet homme aimable et remis leur sort entre les mains du Seigneur.";
					link.l1 = "Hum, êtes-vous sמr de pouvoir faire confiance à ce capitaine ? A-t-il bien compris la valeur des ouvrages qui lui ont été confiés et l'importance de la tâche ?";
					link.l1.go = "GenQuest_Church_1_Dialog_1_2_1";
			}
			else // Сцена 2б-б
			{
				dialog.text = "Ah, "+ GetSexPhrase("mon fils", "ma fille") +" ! Vous arrivez littéralement avec quelques heures de retard ! J'ai déjà envoyé les livres du père " + PChar.GenQuest.ChurchQuest_1.PriestName + ". Ce matin, le capitaine " + PChar.GenQuest.ChurchQuest_1.CapFullName + " est venu se confesser et a mentionné que son navire partait pour " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.CapColony) + ". Et même s'il ne garantissait pas les délais, il a accepté de rendre service, en m'assurant qu'il ferait sans faute escale au port de " + XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen") + ".";
					link.l1 = LinkRandPhrase("Padre", "Saint père", "Mon père") + "... êtes-vous sמr qu'on peut faire confiance à ce capitaine ? Et j'aimerais aussi connaître le nom de son navire.";
					link.l1.go = "GenQuest_Church_1_Dialog_1_2_2_1";
			}
			break;

		case "GenQuest_Church_1_Dialog_1_2_1":	// 2б-а
			dialog.text = "Je crois aux gens, "+ GetSexPhrase("mon fils", "ma fille") +" car nous sommes tous créés à Son image et à Sa ressemblance, et dans chaque âme il y a une étincelle divine !";
				link.l1 = "Oh. Voilà un argument valable. Eh bien... bénissez-moi, saint père, et souhaitez-moi bonne chance pour retrouver ce capitaine.";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2_1_1";
			break;

		case "GenQuest_Church_1_Dialog_1_2_1_1":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchQuest_1.AskPortMan = true;
			PChar.GenQuest.ChurchQuest_1.AskPortMan_InColony = NPChar.city;
			PChar.GenQuest.ChurchQuest_1.CapFullInfo = true; // Полная инфа о кэпе
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "3_1");
			AddQuestUserData(sQuestTitle, "sCapName", PChar.GenQuest.ChurchQuest_1.CapFullName);
			AddQuestUserData(sQuestTitle, "sShipName", PChar.GenQuest.ChurchQuest_1.CapShipName);
			break;

		case "GenQuest_Church_1_Dialog_1_2_2_1":
			dialog.text = "Il faut faire confiance aux gens, "+ GetSexPhrase("mon fils", "ma fille") +". Malheureusement, je ne peux rien vous dire sur le navire.";
				link.l1 = "Et vous avez confié de précieux manuscrits à un capitaine sans même prendre la peine de connaître le nom de son navire ?!!";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2_2_2";
			break;

		case "GenQuest_Church_1_Dialog_1_2_2_2":
			dialog.text = "Voyez-vous, "+ GetSexPhrase("mon fils", "ma fille") +", le capitaine " + PChar.GenQuest.ChurchQuest_1.CapFullName + " est un homme qui craint beaucoup Dieu...";
				link.l1 = "Je l'ai déjà entendu, " + LinkRandPhrase("padre", "saint père", "mon père") + ".";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2_2_3";
			break;

		case "GenQuest_Church_1_Dialog_1_2_2_3":
			dialog.text = "Patience, "+ GetSexPhrase("jeune homme", "ma fille") +" ! Le capitaine " + PChar.GenQuest.ChurchQuest_1.CapFullName + " craint beaucoup Dieu, et son navire portait jusqu'à aujourd'hui un nom qu'un homme d'וglise ne doit même pas prononcer en pensée ! Aujourd'hui, en confession, j'ai signalé cette faute à cette âme égarée. Car selon la Bible, nous autres pécheurs devons veiller à la pureté de l'esprit plus encore qu'à celle du corps, car notre Seigneur a fermé aux blasphémateurs le chemin du royaume des cieux...";
				link.l1 = "Je comprends, " + LinkRandPhrase("padre", "saint père", "Mon père") + " ! Le capitaine qui craint tant Dieu, " + PChar.GenQuest.ChurchQuest_1.CapFullName + ", joueur et ivrogne connu dans toutes les Caraïbes, a donc décidé, sur votre conseil, de rebaptiser sa baille ?";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2_2_4";
			break;

		case "GenQuest_Church_1_Dialog_1_2_2_4":
			dialog.text = "Vous êtes très perspicace, "+ GetSexPhrase("mon fils", "ma fille") +". Je ne connais pas le nouveau nom du navire, mais ce sera sans aucun doute quelque chose de sublime.";
				link.l1 = "Oh, " + RandPhraseSimple("padre", "saint père") + "... merci pour tout. Et priez pour mon âme pécheresse...";
				link.l1.go = "GenQuest_Church_1_Dialog_1_2_2_5";
			break;

		case "GenQuest_Church_1_Dialog_1_2_2_5":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			PChar.GenQuest.ChurchQuest_1.AskPortMan = true;
			PChar.GenQuest.ChurchQuest_1.AskPortMan_InColony = NPChar.city;
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "3_2");
			AddQuestUserData(sQuestTitle, "sCapName", PChar.GenQuest.ChurchQuest_1.CapFullName);
			break;

		case "GenQuest_Church_1_Complete_1":
			dialog.text = "Oh, mon enfant ! J'ai prié avec ferveur, et maintenant tout s'est arrangé pour le mieux ! Pour votre aide et votre zèle, "+ GetSexPhrase("mon fils", "ma fille") +" le paradis et le ciel des anges vous attendent sans aucun doute...";
				link.l1 = RandPhraseSimple("Padre", "Mon père") + ", je n'ai pas encore rendez-vous avec saint Pierre, Dieu merci. Et les vivants, outre les promesses de la grâce céleste, ont besoin de bien des choses matérielles...";
				link.l1.go = "GenQuest_Church_1_Complete_2";
			break;

		case "GenQuest_Church_1_Complete_2":
			dialog.text = "Oui, oui, "+ GetSexPhrase("mon fils", "ma fille") +", oui, oui. Je vais vous récompenser comme il se doit. Tenez, prenez ceci, et souvenez-vous que Dieu punit les insensés qui se soucient trop des biens terrestres et adorent le veau d'or !";
				link.l1 = "Merci, " + LinkRandPhrase("padre", "saint père", " mon père, ") + ". Prenez vos livres et manuscrits tant attendus, et priez pour mon âme pécheresse... Adieu";
				link.l1.go = "GenQuest_Church_1_Complete_3";
			break;

		case "GenQuest_Church_1_Complete_3":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			//PChar.GenQuest.ChurchQuest_1.AwardSumm = (rand(8) + 2) * 500;
			RemoveItems(PChar, "Bible", 1);
			items[FindItem("Bible")].Name = "itmname_bible";
			BackItemDescribe("Bible");
			DeleteAttribute(items[FindItem("Bible")], "City");
			ChangeCharacterReputation(PChar, 5);
			AddCharacterExpToSkill(PChar, "Leadership", 50); // Бонус в авторитет
			AddCharacterExpToSkill(PChar, "Fortune", 50); // Бонус в удачу
			//AddMoneyToCharacter(PChar, sti(PChar.GenQuest.ChurchQuest_1.AwardSumm));
			TakeNItems(pchar, "chest", 3+drand(1));
			PlaySound("interface\important_item.wav");
			sQuestTitle = NPChar.City + "ChurchGenQuest1";
			characters[GetCharacterIndex("ChurchGenQuest1_Cap")].LifeDay = 0;
			Group_DeleteGroup("ChurchGenQuest1_CapGroup"); // Трём кэпа
			PChar.Quest.Church_GenQuest1_ChangeCapitanLocation.over = true; // Завершаем, если вдруг осталось
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "7");
			AddQuestUserData(sQuestTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + NPChar.City + "Gen"));
			AddQuestUserData(sQuestTitle, "sSumm", FindRussianMoneyString(sti(PChar.GenQuest.ChurchQuest_1.AwardSumm)));
			CloseQuestHeader(sQuestTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - поручение церкви выполнено
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1");
			NPChar.GenQuest.ChurchQuest_1.GiveQuestDateParam = iMonth;
			break;
		// <-- Вернуть рукописи священника

		//--->> успокоить нечисть
		case "DestroyGhost_1":
			npchar.quest.DestroyGhost = "toCave"; //личный флаг священника на взятый квест
			//получим пещеру для чистки
			sTemp = GetArealByCityName(npchar.city);
			if (sTemp == "Cuba2") sTemp = "Cuba1";
			if (sTemp == "Hispaniola2") sTemp = "Hispaniola1";
			aref aPlace, aPlace_2;
			makearef(aPlace, NullCharacter.TravelMap.Islands.(sTemp).Treasure);
			int iQty = GetAttributesNum(aPlace)-1;
			aPlace_2 = GetAttributeN(aPlace, rand(iQty));
			npchar.quest.DestroyGhost.locationId = GetAttributeName(aPlace_2); //Id целевой пещеры
			sld = &locations[FindLocation(npchar.quest.DestroyGhost.locationId)];
			npchar.quest.DestroyGhost.label = GetConvertStr(sld.id.label, "LocLables.txt"); //тип подземелья для диалогов
			switch (npchar.quest.DestroyGhost.label)
			{
				case "cave": sTemp = "Le fait est que la caverne qui se trouve près de notre ville est devenue un repaire d'esprits malins !"; break;
				case "Cave": sTemp = "Le fait est que la caverne qui se trouve près de notre ville est devenue un repaire d'esprits malins !"; break;
				case "grotto": sTemp = "Le fait est que la grotte qui se trouve près de notre ville est devenue un repaire d'esprits malins !"; break;
				case "Grotto": sTemp = "Le fait est que la grotte qui se trouve près de notre ville est devenue un repaire d'esprits malins !"; break;
				case "dungeon": sTemp = "Le fait est que le souterrain qui se trouve près de notre ville est devenu un repaire d'esprits malins !"; break;
				case "Dungeon": sTemp = "Le fait est que le souterrain qui se trouve près de notre ville est devenu un repaire d'esprits malins !"; break;
			}
			dialog.text = "On parle de plus en plus d'incidents terribles. " + sTemp + " De là sortent à la lumière de Dieu des créatures qu'on ne verrait pas même dans un cauchemar. Les gens ont peur, la terreur s'insinue dans leurs cœurs...";
			link.l1 = "Comment puis-je vous aider, saint père ?";
			link.l1.go = "DestroyGhost_2";
		break;
		case "DestroyGhost_2":
			dialog.text = "Vous êtes"+ GetSexPhrase("un homme courageux", "une fille courageuse") +". Devenez l'instrument du Seigneur entre mes mains ! Anéantissez les esprits malins ! Et vous obtiendrez la rémission de vos péchés...";
			link.l1 = "Je suis prêt, padre !";
			link.l1.go = "DestroyGhost_3";
			link.l2 = "Saint père, je ne peux pas accepter votre offre. Une autre fois.";
			link.l2.go = "DestroyGhost_out";
		break;
		case "DestroyGhost_out":
			dialog.text = "C'est fâcheux, "+ GetSexPhrase("mon fils", "ma fille") +", très fâcheux. Je comptais sur vous !";
			link.l1 = "Je pense que tout s'arrangera avec le temps...";
			link.l1.go = "exit";
			DeleteAttribute(npchar, "quest.DestroyGhost");
			ChangeCharacterReputation(pchar, -3);
		break;
		case "DestroyGhost_3":
			dialog.text = "Très bien, "+ GetSexPhrase("mon fils", "ma fille") +". Allez-y, et que la force soit avec vous !";
			link.l1 = "Tout ira bien, mon père.";
			link.l1.go = "exit";
			pchar.questTemp.different = "DestroyGhost";
			SetTimerFunction("SmallQuests_free", 0, 0, 1); //освобождаем разрешалку на миниквесты
			//флаг квеста на локацию, сюда же пишем индекс дающего священника
			sld = &locations[FindLocation(npchar.quest.DestroyGhost.locationId)];
			sld.DestroyGhost = npchar.index;
			LAi_LocationResetMonGenTimer(sld.id);
			sTitle = sld.id + "Church_DestroyGhost";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "Church_DestroyGhost", "1");
			switch (npchar.quest.DestroyGhost.label)
			{
				case "Cave": sTemp = "la caverne"; break;
				case "cave": sTemp = "la caverne"; break;
				case "Grotto": sTemp = "la grotte"; break;
				case "grotto": sTemp = "la grotte"; break;
				case "Dungeon": sTemp = "le souterrain"; break;
				case "dungeon": sTemp = "le souterrain"; break;
			}
			AddQuestUserDataForTitle(sTitle, "sLocation", sTemp);
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sLocation", sTemp);
		break;

		case "GhostShip_S1":
			dialog.text = "Parfait, "+ GetSexPhrase("mon fils", "ma fille") +" ! Vous avez accompli une action pieuse. Sachez que l'attitude de " + NationNameGenitive(sti(NPChar.nation)) + " à votre égard va s'améliorer.";
			link.l1 = "J'en suis heureux, padre...";
			link.l1.go = "GhostShip_S2";
		break;
		case "GhostShip_S2":
			dialog.text = "Je prierai pour vous. Allez, "+ GetSexPhrase("mon fils", "ma fille") +", et restez honnête devant votre conscience et devant notre Seigneur.";
			link.l1 = "Bien, saint père.";
			link.l1.go = "exit";
			switch (npchar.quest.DestroyGhost.label)
			{
				case "Cave": sTemp = "la caverne"; break;
				case "cave": sTemp = "la caverne"; break;
				case "Grotto": sTemp = "la grotte"; break;
				case "grotto": sTemp = "la grotte"; break;
				case "Dungeon": sTemp = "le souterrain"; break;
				case "dungeon": sTemp = "le souterrain"; break;
			}
			AddSimpleRumourCity(LinkRandPhrase("Notre saint père, " + GetFullName(npchar) + ", nous a raconté que vous aviez purgé des esprits malins " + sTemp + " près de notre ville. C'est une œuvre agréable à Dieu, je vous le dis...",
				"Vous avez entendu, "+ GetSexPhrase("un certain capitaine", "une certaine fille") +" – à la demande de notre saint père, a purgé de ses démons " + sTemp + " près de notre ville."+ GetSexPhrase("Quel homme courageux !", "") +"",
				""+ GetSexPhrase("Capitaine", "Ma fille") +", avez-vous purgé des esprits malins " + sTemp + " près de notre ville ? Sachez que nous vous en sommes tous très reconnaissants !"), npchar.city, 10, 1, "");
			ChangeCharacterReputation(pchar, 5);
			OfficersReaction("good");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 15);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			sld = &locations[FindLocation(npchar.quest.DestroyGhost.locationId)];
			sTitle = sld.id + "Church_DestroyGhost";
			AddQuestRecordEx(sTitle, "Church_DestroyGhost", "3");
			AddGoodDeedRepeat(1); // Gregg: доброе дело - очистил место от нечисти
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			DeleteAttribute(npchar, "quest.DestroyGhost");
			//#20170727-01 Bug fix church skeleton quest infinite reputation
			//Attribute set in SetSkeletonsToLocation, QuestsUtilite.c
			DeleteAttribute(npchar, "DestroyGhost");
		break;
        //<<--- успокоить нечисть
		//--->> ночной сторож
		case "NightChurch_1":
			dialog.text = "C'est exact. Et croyez-moi, ce n'est pas pour rien. Quand ce genre de choses arrive, c'est le signe certain d'un vol imminent. Apparemment, quelqu'un a jeté son dévolu sur les objets du culte. J'espère que vous accepterez de passer quelques nuits à l'église ?";
			link.l1 = "Non, je crois que je vais refuser, saint père. Veuillez m'excuser.";
			link.l1.go = "exit";
			link.l2 = "En principe, je suis d'accord. Mais combien de nuits devrai-je garder l'église ? Peut-être que personne ne se montrera, et que vos types étranges ne sont que de simples voyous qui n'osent pas montrer leurs sentiments religieux en public.";
			link.l2.go = "NightChurch_2";
		break;
		case "NightChurch_2":
			dialog.text = "Hum, c'est possible, mais peu probable. En somme, il vous faudra rester ici trois nuits. Si personne ne se montre, nous considérerons que votre travail a été accompli avec succès.";
			link.l1 = "Eh bien, ça me convient. J'accepte !";
			link.l1.go = "NightChurch_3";
		break;
		case "NightChurch_3":
			dialog.text = "Alors commencez dès cette nuit. Et n'oubliez pas que vous devez rester dans l'église sans interruption, de minuit à six heures du matin.";
			link.l1 = "Compris, saint père. Vous pouvez être tranquille pour vos objets du culte pendant trois nuits.";
			link.l1.go = "exit";
			pchar.questTemp.different = "Church_NightGuard";
			SetTimerFunction("SmallQuests_free", 0, 0, 1); //освобождаем разрешалку на миниквесты
			pchar.questTemp.different.Church_NightGuard = npchar.location; //флаг срабатывания нуля часов
			pchar.questTemp.different.Church_NightGuard.NightQty = 0; //кол-вот отработанных ночей
			pchar.questTemp.different.Church_NightGuard.chance = rand(3); //рендом на появление грабителей
			pchar.questTemp.different.Church_NightGuard.fight = false; //флаг боевки
			SaveCurrentQuestDateParam("questTemp.different.Church_NightGuard"); //запишем дату
			sTitle = npchar.location + "Church_NightGuard";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "Church_NightGuard", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
		break;

		case "NightGuard_result":
			if (sti(pchar.questTemp.different.Church_NightGuard.NightQty) == 0)
			{
				dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", vous n'avez pas veillé une seule nuit. Allez faire votre travail, ne me dérangez pas...";
				link.l1 = "Bien, saint père.";
				link.l1.go = "exit";
			}
			if (sti(pchar.questTemp.different.Church_NightGuard.NightQty) > 0 && sti(pchar.questTemp.different.Church_NightGuard.NightQty) < 3)
			{
				dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", vous n'avez pas mené votre travail à son terme, nous avions convenu de trois nuits...";
				link.l1 = "Oui, je m'en souviens... Je monterai la garde.";
				link.l1.go = "exit";
			}
			if (sti(pchar.questTemp.different.Church_NightGuard.NightQty) >= 3)
			{
				if (sti(pchar.questTemp.different.Church_NightGuard.fight))
				{
					dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", je sais déjà que vous avez attrapé les voleurs de l'église. Et même si un meurtre entre les murs du temple du Seigneur est un péché, le Seigneur vous le pardonnera.";
					link.l1 = "Merci, saint père...";
					link.l1.go = "NightGuard_fight";
				}
				else
				{
					dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", vous étiez à l'église cette nuit. Avez-vous vu quelque chose d'étrange ?";
					link.l1 = "Non, saint père, tout était calme. Je n'ai vu personne.";
					link.l1.go = "NightGuard_noLook";
				}
			}
		break;

		case "NightGuard_noLook":
			dialog.text = "Hum, on dirait que nous nous étions trompés... Eh bien, voilà un résultat merveilleux ! En récompense, je ne vous offre pas d'argent, mais je peux vous dire que vos péchés devant notre Seigneur et devant " + NationNameAblative(sti(npchar.nation)) + " seront allégés.";
			link.l1 = "Merci, saint père.";
			link.l1.go = "exit";
			sTitle = pchar.questTemp.different.Church_NightGuard + "Church_NightGuard";
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - ночное дежурство в церкви

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.different.Church_NightGuard");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			OfficersReaction("good");
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous montez la garde de nuit dans notre église...",
				"Monter la garde de nuit à l'église est une œuvre agréable à Dieu. Merci.",
				"Notre saint père, " + GetFullName(npchar) + ", a mentionné que vous aviez monté la garde de nuit dans notre église."), npchar.city, 10, 1, "");
		break;
		case "NightGuard_fight":
			int iGuardReward = 5000 + sti(pchar.rank) * 2000;
			dialog.text = "De plus, je peux alléger vos péchés devant " + NationNameAblative(sti(npchar.nation)) + ", ce que je ferai. Je prierai aussi pour votre santé, et je crois que vous sentirez bientכt la force guérisseuse de la prière à notre Seigneur ! Et les paroissiens reconnaissants ont réuni une modeste offrande pour vous : acceptez-la de bon cœur.";
			link.l1 = "Merci beaucoup, saint père !";
			link.l1.go = "exit";
			sTitle = pchar.questTemp.different.Church_NightGuard + "Church_NightGuard";
			CloseQuestHeader(sTitle);
			AddGoodDeedRepeat(1); // Gregg: доброе дело - поймал воров в церкви

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.different.Church_NightGuard");
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
			OfficersReaction("good");
			AddCharacterMaxHealth(pchar, 2);
			AddMoneyToCharacter(pchar, iGuardReward);
			AddSimpleRumourCity(LinkRandPhrase("On dit que vous avez attrapé des bandits dans notre église, la nuit ! Merci infiniment !",
				"Vous savez, tous les habitants de la ville vous sont reconnaissants de ne pas avoir laissé piller notre église. Merci !",
				"Notre saint père, " + GetFullName(npchar) + ", ne parle que de la façon dont vous avez sauvé les objets du culte de notre église cette nuit-là..."), npchar.city, 10, 1, "");
		break;

		//<<--- ночной сторож
		//Lipsar квест История давней дружбы
		case "LukePoison":
			dialog.text = GetSexPhrase("Mon fils", "Ma fille") +"Laissez-moi vous examiner... Seigneur, ayez pitié ! Je ne connais pas ce poison, je ne l'ai jamais rencontré. Vous devez trouver de toute urgence quelqu'un qui pourra vous aider, sinon votre santé ne s'améliorera jamais !";
			link.l1 = "Je regrette, padre, que vous ne puissiez pas m'aider.";
			link.l1.go = "exit";
			if (NPChar.City == "Bridgetown")
			{
				dialog.text = GetSexPhrase("Mon fils", "Ma fille") +", laissez-moi vous examiner... Seigneur, ayez pitié ! Je sais de quel poison il s'agit ! Il est très dangereux, il faut commencer le traitement immédiatement ! Je vais vous aider.";
				link.l1 = "Qu'attendons-nous ?! J'accepte volontiers votre aide !";
				link.l1.go = "exit";
				AddDialogExitQuest("HealingPoison");
			}
		break;
        case "healthAdd_1":
            if (stf(pchar.Health.HP) >= 57.0) // отлично
            {
                dialog.text = "Votre santé est " + GetHealthNameMaxSmall(pchar) + " – et vos blessures guériront d'elles-mêmes. Il vous suffit d'éviter les effusions de sang et de prendre soin de votre santé.";
    			link.l1 = "Merci, vous me rassurez. J'essaierai de ne pas me battre pendant quelque temps.";
    			link.l1.go = "exit";
            }
            else
            {
    			dialog.text = "Votre santé est " + GetHealthNameMaxSmall(pchar) + ", et même si les blessures guériront d'elles-mêmes, il ne vous ferait pas de mal d'y remédier.";
    			link.l1 = "Que faut-il pour cela ?";
    			link.l1.go = "healthAdd_2";
			}
			link.l2 = "Et pourquoi donc ma santé se dégrade-t-elle ?";
    		link.l2.go = "healthAdd_info";
		break;

		case "healthAdd_info":
			dialog.text = "C'est très simple, "+ GetSexPhrase("mon fils", "ma fille") +", vous subissez des dommages quand vous êtes blessé. Cela ne passe pas sans laisser de traces : chaque blessure mine votre santé, et vous finissez par vous affaiblir au point de ne plus pouvoir manier l'épée. Votre équipage, voyant la faiblesse de son chef, perd le respect qu'il vous doit. Mais d'un autre cכté, vous devenez plus prudent, et votre capacité à vous protéger augmente temporairement. Un repos opportun et le moins de blessures possible vous aideront à rester toujours plein d'énergie.";
			link.l1 = "Merci, vous m'avez éclairé.";
			link.l1.go = "exit";
		break;

		case "healthAdd_2":
			dialog.text = "La prière et la non-violence, "+ GetSexPhrase("mon fils", "ma fille") +". Alors le Seigneur vous rendra ce que vous avez perdu.";
			link.l1 = "Pourriez-vous prier pour moi ?";
			link.l1.go = "healthAdd_3";
			link.l2 = "C'est-à-dire qu'il n'y a aucun moyen ? Hum.. Vous m'avez rassuré, merci.";
			link.l2.go = "exit";
		break;

		case "healthAdd_3":
            if (npchar.quest.HealthMonth != iMonth)
            {
    			dialog.text = "Moi ? C'est peut-être possible. Mais il vous faudra faire l'aumכne à notre paroisse.";
    			link.l1 = pcharrepphrase("Combien ?", "Avec plaisir ! De quel montant ?");
    			link.l1.go = "healthAdd_4";
    			link.l2 = "Je me débrouillerai tout seul, d'une façon ou d'une autre...";
    			link.l2.go = "exit";
			}
			else
			{
                dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", je prie déjà pour votre bien-être. Les prières occuperont tout mon temps jusqu'à la fin du mois.";
    			link.l1    = "Merci, "+RandPhraseSimple("padre.", "saint père.");
    			link.l1.go = "exit";
			}
		break;

		case "healthAdd_4":
			int iHealCost = 40000 + sti(pchar.rank) * 8000;
			npchar.quest.HealCost = iHealCost;
			dialog.text = "Un don de " + FindRussianMoneyString(iHealCost) + " sera un prix tout à fait suffisant pour un miracle de guérison.";
			link.l1 = pcharrepphrase("Combien !!! Vous avez perdu la tête ?! Je paierai cette somme quand j'aurai pillé deux ou trois églises.", "C'est trop pour moi. On voit bien qu'on dit vrai : la santé ne s'achète pas.");
			link.l1.go = "exit";
            if (sti(pchar.Money) >= iHealCost)
            {
    			link.l2 = "J'accepte !";
    			link.l2.go = "healthAdd_5";
			}
		break;

		case "healthAdd_5":
            AddMoneyToCharacter(pchar, -sti(npchar.quest.HealCost));
            AddCharacterMaxHealth(pchar, 4); // можно не проверять, тк явно меньше 51
            npchar.quest.HealthMonth = iMonth;
			dialog.text = "Bien. Votre santé va s'améliorer un peu. Mais il vous faut éviter les bagarres et prendre soin de vous, sinon l'effet sera réduit à néant. Je dois passer tout un mois à prier pour votre corps mortel.";
			link.l1 = "Merci. Je reviendrai dans un mois, si besoin. .";
			link.l1.go = "exit";
		break;
		// диалог для капелата из тюряги
		case "Prison_Temp":
            NextDiag.TempNode = "Prison_Temp";
			dialog.text = "Nous n'avons plus rien à nous dire.";
			link.l1 = "Oui, et ce n'est pas nécessaire.";
			link.l1.go = "Exit";
		break;

		case "Prison_Cell":
            NextDiag.TempNode = "Prison_Temp";
			dialog.text = "בme perdue, veux-tu te repentir de tes péchés, purifier ton âme et alléger ton sort ?";
			link.l1 = "Qui êtes-vous, au juste ?";
			link.l1.go = "Prison_Cell_Info";
			link.l2 = "Avec empressement et humilité, padre.";
			link.l2.go = "Prison_Cell_Talk";
			link.l3 = "Dégagez, saint homme.";
			link.l3.go = "Prison_Cell_None";
		break;

		case "Prison_Cell_Info":
			dialog.text = "Je suis l'aumכnier d'ici : j'adoucis le sort des prisonniers, je les confesse avant l'exécution de la sentence de mort et je chante l'office funèbre après, ou bien je leur fais mes adieux avant le long voyage vers les mines.";
			link.l1 = "Y a-t-il un autre choix que le bagne et l'exécution ?";
			link.l1.go = "Prison_Cell_Info_2";
			link.l2 = "Je suis prêt à me repentir, padre.";
			link.l2.go = "Prison_Cell_Talk";
			link.l3 = "Je ne suis absolument pas coupable. Je n'ai besoin de rien de tout ça.";
			link.l3.go = "Prison_Cell_None";
		break;

		case "Prison_Cell_Info_2":
			dialog.text = "Bien sמr, "+ GetSexPhrase("mon fils", "ma fille") +", tout le monde ne vit pas jusqu'à la sentence, beaucoup trouvent dans les cachots leur dernière demeure. זtes-vous prêt à me parler de vos péchés ?";
			link.l2 = "Je suis prêt à me repentir, padre.";
			link.l2.go = "Prison_Cell_Talk";
			link.l3 = "Je ne suis absolument pas coupable. Je n'ai besoin de rien de tout ça.";
			link.l3.go = "Prison_Cell_None";
		break;

		case "Prison_Cell_None":
			dialog.text = "S'obstiner dans l'hérésie et l'apostasie ne vous mènera jamais au Royaume de Dieu. Humiliez-vous et repentez-vous !";
			link.l1 = "J'insiste, je n'en ai pas besoin. Partez !";
			link.l1.go = "Prison_Cell_death";//"Exit";
			//AddDialogExitQuest("MoveToPrison_Cell");
		break;

		case "Prison_Cell_Talk":
			dialog.text = "Je vous écoute, "+ GetSexPhrase("mon fils", "ma fille") +".";
			link.l2 = "Je suis un pécheur, padre, j'ai bien des atrocités à mon actif, j'ai volé et tué des innocents, mais je n'étais pas seul. Des compagnons fidèles m'aidaient. Pourriez-vous leur transmettre un message de ma part ?";
			link.l2.go = "Prison_Cell_Talk_2";
			link.l3 = "J'ai changé d'avis. Laissez-moi tranquille.";
			link.l3.go = "Prison_Cell_None";
		break;

		case "Prison_Cell_Talk_2":
			dialog.text = "Vous êtes donc aussi le meneur d'une bande de criminels ? Et vous me demandez de vous aider dans vos desseins perfides ? Il n'en est pas question ! Je vais immédiatement exiger votre condamnation.";
			link.l1 = "Quel imbécile vous faites, et vous portez une soutane, en plus !";
			link.l1.go = "Prison_Cell_death";
		break;

		case "Prison_Cell_death":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
   			sld = &Characters[sti(PChar.GenQuest.ToPrisonCmdIdx)];
			// to_do DeathExecutionStart(Pchar, sti(sld.nation));
		break;
		//квест пожертвования хозяйки борделя
		case "HostessChurch":
			dialog.text = "Et qui est cette bonne âme qui fait ce don ?";
			link.l1 = "Hum... C'est la patronne du bordel d'ici.";
			link.l1.go = "HostessChurch_call";
			link.l2 = "Je préférerais ne pas citer de noms. Un don anonyme, ça existe !";
			link.l2.go = "HostessChurch_notCall";
			pchar.questTemp.different = "HostessChurch_return"; //флаг на возвращение
		break;
		case "HostessChurch_call":
			if (sti(pchar.reputation) < 10)
			{
				if (rand(100) < GetCharacterSkill(pchar, "Fortune")) //рендом вешаем на удачу
				{
					dialog.text = "Vous intercédez pour une pécheresse ? Elle a pensé à son âme. C'est merveilleux, car nous comparaîtrons tous devant le Seigneur !";
					link.l1 = "C'est exact. J'espère que le Seigneur sera miséricordieux envers moi... Alors, et ce don ?";
					link.l1.go = "HostessChurch_ok";
				}
				else
				{
					dialog.text = "Arrière, Satan !!! Reprenez votre argent impie et sortez d'ici !";
					link.l1 = "Saint père, comment ça ?! Nous venons à vous de tout notre cœur, et vous...";
					link.l1.go = "HostessChurch_bad";
				}
			}
			else
			{
				if (rand(10) < GetCharacterSPECIAL(pchar, "Charisma")) //рендом вешаем на харизму
				{
					dialog.text = "Je suis heureux que vous aidiez les pécheurs à trouver le chemin de notre Seigneur. Vous en serez récompensé au ciel !";
					link.l1 = "Ce serait parfait ! Alors, et ce don ?";
					link.l1.go = "HostessChurch_ok";
				}
				else
				{
					dialog.text = "Je ne peux pas accepter de l'argent gagné dans le péché. Rendez-le à cette catin, "+ GetSexPhrase("mon fils", "ma fille") +". On ne trouve pas le chemin du Seigneur avec de l'argent.";
					link.l1 = "Dommage que vous le refusiez. Dommage...";
					link.l1.go = "HostessChurch_bad_1";
				}
			}
		break;
		case "HostessChurch_notCall":
			if (rand(10) < GetCharacterSPECIAL(pchar, "Charisma"))
			{
				dialog.text = "Prendre cet argent sans même savoir de qui il vient...";
				link.l1 = "Oui, padre, c'est exact. Acceptez ce don de tout cœur !";
				link.l1.go = "HostessChurch_ok_1";
			}
			else
			{
				dialog.text = "Prendre cet argent sans même savoir de qui il vient ? Vous êtes fou ?! Et s'il y avait du sang sur cet argent !!";
				link.l1 = "Saint père, il y a du sang sur tout l'argent du monde...";
				link.l1.go = "HostessChurch_bad_2";
			}
		break;

		case "HostessChurch_ok":
			dialog.text = "Je l'accepte, "+ GetSexPhrase("mon fils", "ma fille") +". Allez, vous pouvez le dire à la pécheresse.";
			link.l1 = "Bien, padre. Merci.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.different.HostessChurch.money));
			AddCharacterExpToSkill(pchar, "Fortune", 20);
			//флаг удачная или неудачная попытка дачи
			characters[GetCharacterIndex(pchar.questTemp.different.HostessChurch.city + "_Hostess")].questChurch = "yes";
		break;
		case "HostessChurch_ok_1":
			dialog.text = "Je l'accepte, "+ GetSexPhrase("mon fils", "ma fille") +". Vous pouvez le dire à la pécheresse.";
			link.l1 = "Bien, padre. Merci.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.different.HostessChurch.money));
			AddCharacterExpToSkill(pchar, "Fortune", 20);
			//флаг удачная или неудачная попытка дачи
			characters[GetCharacterIndex(pchar.questTemp.different.HostessChurch.city + "_Hostess")].questChurch = "yes";
		break;
		case "HostessChurch_bad":
			dialog.text = "Dehors, démon de l'enfer !!! Et ne vous avisez plus de vous montrer devant moi !";
			link.l1 = "Hé, d'accord.";
			link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 50);
			npchar.quest.BadMeeting = lastspeak_date;
			//флаг удачная или неудачная попытка дачи
			characters[GetCharacterIndex(pchar.questTemp.different.HostessChurch.city + "_Hostess")].questChurch = "no";
		break;
		case "HostessChurch_bad_1":
			dialog.text = "C'est ma décision. Allez en paix, "+ GetSexPhrase("mon fils", "ma fille") +".";
			link.l1 = "Au revoir, padre.";
			link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			//флаг удачная или неудачная попытка дачи
			characters[GetCharacterIndex(pchar.questTemp.different.HostessChurch.city + "_Hostess")].questChurch = "no";
		break;
		case "HostessChurch_bad_2":
			dialog.text = "C'est ce que vous croyez, mécréant ! Sortez du temple et ne vous montrez plus devant moi !";
			link.l1 = "Ah oui ? Eh bien, je m'en vais, je vous en prie...";
			link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Leadership", 40);
			npchar.quest.BadMeeting = lastspeak_date;
			//флаг удачная или неудачная попытка дачи
			characters[GetCharacterIndex(pchar.questTemp.different.HostessChurch.city + "_Hostess")].questChurch = "no";
		break;
		//зачарованный город. базар падре в Каракасе
		case "MC_CaracasChirch":
			dialog.text = ""+ GetSexPhrase("Mon fils", "Ma fille") +", l'וglise sauve les égarés. Les loups-garous, les sorcières et les sorciers sont remis sur le droit chemin par la Sainte Inquisition. Ou par de simples citoyens, si le Seigneur les choisit comme instrument. Qui sommes-nous pour nous en mêler ?";
			link.l1 = "Et s'il est vraiment innocent ? וtrange : c'est à moi"+ GetSexPhrase(", un corsaire, ", "") +" de faire appel à la conscience d'un prêtre !";
			link.l1.go = "MC_CaracasChirch_1";
		break;
		case "MC_CaracasChirch_1":
			dialog.text = "Ne vous emportez pas, "+ GetSexPhrase("mon fils", "ma fille") +". Si son âme est innocente, elle ira au paradis ! Mais si c'est un suppכt de Satan, il y a un moyen de le vérifier. Un rejeton du diable ne pourra pas entrer dans le temple de Dieu. Si vous l'amenez ici et que le châtiment du ciel ne le frappe pas, je ne lui refuserai bien sמr pas la confession.";
			link.l1 = "Je vais l'amener !";
			link.l1.go = "exit";
			pchar.questTemp.MC = "toCaracasTavern";
			for (i=1; i<=12; i++)
			{
				sld = characterFromId("CaracasCit_"+i);
				sld.lifeDay = 0;
			}
			//дым от костра
			locations[FindLocation("Caracas_town")].hidden_effects = true;
		break;

	}
}

void ChurchGenQuest2_RemoveCup()
{
	RemoveItems(PChar, "Bible", 1);
	ref rItem = ItemsFromID("Bible");
	DeleteAttribute(rItem, "City");
	rItem.Weight = 2;
	rItem.Name = "itmname_Bible";
	rItem.picIndex = 6;
	rItem.picTexture = "ITEMS_9";
	BackItemDescribe("Bible");
}


void Church_GenQuest1_InitStartParam(ref chr)
{
	string sColony = SelectNotEnemyColony(chr);
	//string sColony = FindNonEnemyColonyForAdventure(GetCityNation(PChar.GenQuest.ChurchQuest_1.QuestTown), PChar.GenQuest.ChurchQuest_1.QuestTown, true);
	PChar.GenQuest.ChurchQuest_1.IslandId = colonies[FindColony(PChar.GenQuest.ChurchQuest_1.QuestTown)].Island;
	PChar.GenQuest.ChurchQuest_1.ToColony = sColony;
	PChar.GenQuest.ChurchQuest_1.ToIsland = colonies[FindColony(sColony)].IslandLable;
	PChar.GenQuest.ChurchQuest_1.ToName = characters[GetCharacterIndex(sColony + "_Priest")].Name;

	// Чтоб жизнь мёдом не казалась... Какие сцены будут в квесте, определяем в самом начале.
	int iRand = Rand(2);
	switch(iRand)
	{
		case "0":
			PChar.GenQuest.ChurchQuest_1.2A_Scene = true;
			Log_TestInfo("Church Generator 1: Key scene - 2A (just take the manuscripts from the priest).");
		break;

		case "1":
			PChar.GenQuest.ChurchQuest_1.2BA_Scene = true;
			Log_TestInfo("Church Generator 1: Key Scene - 2B-A (cap search. There is complete information about him).");
		break;

		case "2": // Этот флаг уже не проверяем, т.к. если нет тех, что выше, по-любому есть этот
			PChar.GenQuest.ChurchQuest_1.2BB_Scene = true;
			Log_TestInfo("Church Generator 1: Key Scene - 2B-B (cap search. The name of the spike is unknown.)");
		break;
	}
}
