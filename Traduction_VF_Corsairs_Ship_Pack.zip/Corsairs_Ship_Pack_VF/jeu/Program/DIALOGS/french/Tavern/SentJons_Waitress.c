// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(PChar, "BSSentJonsWaitress"))
			{			
				link.l1 = "Ma chérie, tu n'aurais pas vu mon ami par ici ? Un grand pêcheur, nous avons bu un verre ici il y a quelque temps ?";
				link.l1.go = "BS_F3_24";
			}
		break;
		
		case "BS_F3_24":
			DeleteAttribute(PChar, "BSSentJonsWaitress");
			AddMoneyToCharacter(pchar, -500);
			SetFunctionLocationCondition("BS_BonsDominicaMeeting", "Dominica", false);
			AddQuestRecord("BSHangover", "62");
			dialog.text = "Il chasse le gros poisson ? Il m'a dit de vous dire qu'un autre pêcheur vous attendrait dans les eaux de la Dominique, au large de la plage de Castle Brush.";
			link.l1 = "Merci. Tiens, voilà pour, euh, quelque chose de joli !"; //Отдаём 500 рублей
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
