void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref PChar;
	PChar = GetMainCharacter();

    string ret;

	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.Tempnode;
			DialogExit();
		break;

		case "start":
			dialog.text = "Réveille-toi, " + Pchar.name + " ! Nous voilà enfin arrivés à "+ Pchar.HeroParam.Land +" après toutes ces tempêtes !"+
                          "Qu'est-ce que tu vas faire ? Tu n'as plus de navire.";
			link.l1 = "Ce n'est pas la première fois ! La chance, c'est capricieux.";
			link.l1.go = "start1";
			link.l2 = "Tu veux me proposer du travail, Abraham ?";
			link.l2.go = "start2";
		break;

		case "start1":
			dialog.text = "J'espère que tu auras plus de chance qu'avec le Mercury. Adieu.";
			link.l1 = "Je n'en doute pas. Adieu, capitaine !";
			link.l1.go = "game_begin";
		break;

		case "start2":
            ret = Pchar.name + "Je suis contrebandier, pas gouverneur de la ville. Quel travail veux-tu que j'aie pour toi ?";
            if (sti(Pchar.nation) == PIRATE)
            {
                dialog.text = ret + "Passe à la taverne d'Inez. Elle connaît tout le monde sur cette île\n"+
                              "Va voir Yurksen, c'est lui qui commande les pirates ici, à la place d'un gouverneur. Mais parle d'abord aux pirates ordinaires.";
            }
            else
            {
                dialog.text = ret + "Emprunte de l'argent quelque part, vends quelque chose. Ce n'est pas à moi de t'apprendre.";
            }
            link.l1 = "Bon, merci du conseil. Adieu.";
			link.l1.go = "game_begin";
			link.l2 = "Tu sais, Abraham, je crois que je vais réquisitionner ton navire. Il me plaît vraiment !";
			link.l2.go = "start3";
		break;

		case "game_begin":
			DialogExit();
            addDialogExitQuest("Tut_SkipTutorialOnShip");
		break;

		case "start3":
			dialog.text = "Tu plaisantes mal, l'ami.";
			link.l1 = "Laisse tomber, vieil homme. Adieu !";
			link.l1.go = "game_begin";
			link.l2 = "Qui a dit que je plaisantais ? Tu diras à l'équipage que tu m'as vendu ton bateau. Et je te laisserai la vie. Marché conclu ?";
			link.l2.go = "start4";
		break;

		case "start4":
			dialog.text = "On disait que tu avais tué ton maître, Malcolm Hutcher, pour un méchant sabre. Je ne le croyais pas, mais j'avais tort. Aujourd'hui, tu vas nourrir les poissons. Tu n'as aucune chance, l'ami.";
			link.l1 = "Vraiment ?!";
			link.l1.go = "exit";
			addDialogExitQuest("Tut_KillOnShip");
		break;

		case "First time":
			dialog.text = "";
			Link.l1 = "Oups...";
			Link.l1.go = "exit";
		break;

////////////////////////////////////////////////////////////////////////////////
//	Корсарское метро
////////////////////////////////////////////////////////////////////////////////
		case "Travel_talkStart":
            NPChar.location = "none"; // чтоб на палубе не болтался
			//Шанс на то что продадут на рудники.
			int iRnd = (rand(100) == 30);
			if (iRnd)
			{
				dialog.text = "On se disait qu'on pourrait peut-être te vendre aux mines. Ha... l'argent n'est jamais de trop.";
				link.l1 = "Qu'est-ce que tu racontes ?";
				//заглушка, пока нет рудников.
				link.l1.go = "Travel_fight";
				//"Travel_mine"; //Собственно тоже можно боевку организовать, ГГ сопротивляется.
			}
			else
			{
				dialog.text = "Nous sommes arrivés, adieu.";
				link.l1 = "Au revoir.";
				link.l1.go = "Travel_end";
				link.l2 = "Je me disais que ton navire me plaît. Je veux le garder pour moi.";
				link.l2.go = "Travel_fight";
			}
		break;

		case "Travel_fight":
			ChangeContrabandRelation(pchar, -60);

			LAi_group_MoveCharacter(NPChar, "TmpEnemy");
			LAi_group_SetCheck("TmpEnemy", "Travel_AfterDeckFight");
			LAi_group_FightGroups(LAI_GROUP_PLAYER, "TmpEnemy", true);
			LAi_SetPlayerType(PChar);
			//Вытащим саблю
   			LAi_SetFightMode(Pchar, true);

			NextDiag.CurrentNode = NextDiag.Tempnode;
			DialogExit();
			LAi_SetWarriorTypeNoGroup(NPChar);
		break;

		case "Travel_end":
			NextDiag.CurrentNode = NextDiag.Tempnode;
			DialogExit();
			//Квест бук
			AddQuestRecord("Gen_ContrabandTravel", "4");
			AddQuestUserData("Gen_ContrabandTravel", "sLocTo", GetConvertStr(pchar.GenQuest.contraTravel.destination.loc, "LocLables.txt")));


			LAi_SetPlayerType(PChar);
			//грузим ГГ куда нужно....
			setWDMPointXZ(pchar.GenQuest.contraTravel.destination.loc);
			SetAnyReloadToLocation(pchar.GenQuest.contraTravel.destination.loc,
									pchar.GenQuest.contraTravel.destination.group,
									pchar.GenQuest.contraTravel.destination.locator, "", 0, 0, 0, 0);
			AddDialogExitQuest("AnyReloadToLocation");
            chrDisableReloadToLocation = false;
			CloseQuestHeader("Gen_ContrabandTravel");
			//трём аттрибуты
			DeleteAttribute(PChar, "GenQuest.contraTravel");
		break;
	}
}
