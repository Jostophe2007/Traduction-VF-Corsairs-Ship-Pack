﻿# Installe la version française de Corsairs Ship Pack (voir LISEZMOI_INSTALLATION.txt).
#   -GameDir <dossier>  dossier du jeu (sinon : détection, puis fenêtre de choix)
#   -Force              n'arrête pas l'installation si des scripts du jeu ont une autre version
#   -NoPause            ne demande pas d'appuyer sur Entrée à la fin
param([string]$GameDir = '', [switch]$Force, [switch]$NoPause)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkg = Split-Path -Parent $here
$src = Join-Path $pkg 'jeu'

function Wait-End {
    if (-not $NoPause) { Write-Host ''; Read-Host 'Appuyez sur Entrée pour fermer' | Out-Null }
}

function Test-Game([string]$d) {
    if (-not $d) { return $false }
    return (Test-Path -LiteralPath (Join-Path $d 'engine.exe')) -and (Test-Path -LiteralPath (Join-Path $d 'Program'))
}

function New-ParentDir([string]$p) {
    $d = Split-Path -Parent $p
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
}

function Save-InstallLog {
    if (-not $script:logPath -or $null -eq $script:added) { return }
    New-ParentDir $script:logPath
    $log = [ordered]@{
        traduction = $script:manifest.date
        version_jeu = $script:manifest.version_jeu
        added = @($script:added | Sort-Object)
        replaced = @($script:replaced | Sort-Object)
        junction = $script:junction
    }
    $log | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $script:logPath -Encoding UTF8
}

try {
    Write-Host '=== Version française de Corsairs Ship Pack ===' -ForegroundColor Cyan

    # ---------------------------------------------------------------- dossier du jeu
    if (-not (Test-Game $GameDir)) {
        foreach ($c in @((Split-Path -Parent $pkg), $pkg)) { if (Test-Game $c) { $GameDir = $c; break } }
    }
    if (-not (Test-Game $GameDir)) {
        Write-Host 'Choisissez le dossier du jeu (celui qui contient engine.exe)...'
        try {
            Add-Type -AssemblyName System.Windows.Forms
            $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
            $dlg.Description = 'Dossier du jeu Corsairs Ship Pack (celui qui contient engine.exe)'
            $dlg.ShowNewFolderButton = $false
            if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $GameDir = $dlg.SelectedPath }
        } catch { }
    }
    if (-not (Test-Game $GameDir)) {
        $GameDir = (Read-Host 'Chemin du dossier du jeu').Trim().Trim('"')
    }
    if (-not (Test-Game $GameDir)) {
        Write-Host 'Dossier du jeu introuvable (engine.exe absent) : installation annulée.' -ForegroundColor Red
        Wait-End; exit 1
    }
    $GameDir = (Resolve-Path -LiteralPath $GameDir).Path
    Write-Host "Dossier du jeu : $GameDir"

    $manifest = Get-Content -LiteralPath (Join-Path $here 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $files = @($manifest.files)

    # ---------------------------------------------------------------- version des scripts du jeu
    $diff = @()
    foreach ($f in $files) {
        if (-not $f.orig) { continue }
        $t = Join-Path $GameDir $f.path
        if (-not (Test-Path -LiteralPath $t)) { $diff += $f.path; continue }
        $h = (Get-FileHash -LiteralPath $t -Algorithm SHA256).Hash
        if ($h -ne $f.orig -and $h -ne $f.sha) { $diff += $f.path }
    }
    if ($diff.Count -gt 0 -and -not $Force) {
        Write-Host ''
        Write-Host ("Attention : {0} script(s) du jeu ne correspondent pas à la version prévue ({1}) :" -f $diff.Count, $manifest.version_jeu) -ForegroundColor Yellow
        $diff | ForEach-Object { Write-Host "   $_" }
        Write-Host 'Les remplacer pourrait casser le jeu si votre version est différente.'
        $r = Read-Host 'Continuer quand même ? (O/N)'
        if ($r -notmatch '^\s*[oOyY]') {
            Write-Host "Installation annulée : rien n'a été modifié."
            Wait-End; exit 2
        }
    }

    # ---------------------------------------------------------------- copie (avec sauvegarde des originaux)
    $frt = Join-Path $GameDir 'FR_Traduction'
    $bk = Join-Path $frt 'backup\avant_installation'
    $bkCode = Join-Path $frt 'backup\code'
    $logPath = Join-Path $frt 'backup\installation.json'
    $cmp = [System.StringComparer]::OrdinalIgnoreCase
    $added = New-Object 'System.Collections.Generic.HashSet[string]' ($cmp)
    $replaced = New-Object 'System.Collections.Generic.HashSet[string]' ($cmp)
    $junction = $false
    if (Test-Path -LiteralPath $logPath) {          # réinstallation : on garde le premier état d'origine
        $old = Get-Content -LiteralPath $logPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in @($old.added)) { if ($p) { [void]$added.Add($p) } }
        foreach ($p in @($old.replaced)) { if ($p) { [void]$replaced.Add($p) } }
        $junction = [bool]$old.junction
    }

    function Save-Original([string]$rel, [string]$target) {
        $b = Join-Path $bk $rel
        if (-not (Test-Path -LiteralPath $b)) { New-ParentDir $b; Copy-Item -LiteralPath $target -Destination $b }
    }

    $n = 0; $nNew = 0; $nRep = 0; $nSame = 0
    foreach ($f in $files) {
        $n++
        if ($n % 100 -eq 0) {
            Write-Progress -Activity 'Copie de la version française' -Status ("{0} / {1}" -f $n, $files.Count) -PercentComplete (100 * $n / $files.Count)
        }
        $s = Join-Path $src $f.path
        $t = Join-Path $GameDir $f.path
        if (Test-Path -LiteralPath $t) {
            $h = (Get-FileHash -LiteralPath $t -Algorithm SHA256).Hash
            if ($h -eq $f.sha) { $nSame++; continue }
            if (-not $added.Contains($f.path)) {
                Save-Original $f.path $t
                [void]$replaced.Add($f.path)
                if ($f.orig -and $h -eq $f.orig) {   # pour « patch_code.py --undo »
                    $c = Join-Path $bkCode ($f.path -replace '\\', '__')
                    if (-not (Test-Path -LiteralPath $c)) { New-ParentDir $c; Copy-Item -LiteralPath $t -Destination $c }
                }
            }
            $nRep++
        } else {
            New-ParentDir $t
            [void]$added.Add($f.path)
            $nNew++
        }
        Copy-Item -LiteralPath $s -Destination $t -Force
    }
    Write-Progress -Activity 'Copie de la version française' -Completed

    # ---------------------------------------------------------------- voix : les voix anglaises servent en français
    $vf = Join-Path $GameDir 'RESOURCE\Sounds\Voice\French'
    $ve = Join-Path $GameDir 'RESOURCE\Sounds\Voice\English'
    if (-not (Test-Path -LiteralPath $vf) -and (Test-Path -LiteralPath $ve)) {
        New-Item -ItemType Junction -Path $vf -Target $ve | Out-Null
        $junction = $true
    }

    # ---------------------------------------------------------------- langue du jeu
    $liRel = 'RESOURCE\INI\texts\language.ini'
    $li = Join-Path $GameDir $liRel
    if (Test-Path -LiteralPath $li) {
        if (-not $added.Contains($liRel)) { Save-Original $liRel $li; [void]$replaced.Add($liRel) }
        $txt = [System.IO.File]::ReadAllText($li)
        $txt = [regex]::Replace($txt, '(?m)^defaultLanguage\s*=[^\r\n]*', 'defaultLanguage = french')
        $txt = [regex]::Replace($txt, '(?m)^French\s*=\s*fonts[^\r\n]*', 'French = fonts_fra.ini')
        [System.IO.File]::WriteAllText($li, $txt, (New-Object System.Text.UTF8Encoding($false)))
    } else {
        Write-Host "language.ini introuvable : réglez la langue avec FR_Traduction\Langue_Francais.bat." -ForegroundColor Yellow
    }

    Save-InstallLog
    Write-Host ''
    Write-Host ("Installation terminée : {0} fichiers ajoutés, {1} remplacés, {2} déjà à jour." -f $nNew, $nRep, $nSame) -ForegroundColor Green
    Write-Host 'Les fichiers remplacés sont sauvegardés dans FR_Traduction\backup\avant_installation.'
    Write-Host 'Le jeu est réglé en français.'
    Write-Host '  Changer de langue : FR_Traduction\Langue_Francais.bat / Langue_Anglais.bat / Langue_Russe.bat'
    Write-Host '  Désinstaller      : FR_Traduction\Desinstaller_VF.bat'
    Wait-End
    exit 0
}
catch {
    $err = $_
    try { Save-InstallLog } catch { }
    Write-Host ''
    Write-Host ("Erreur pendant l'installation : {0}" -f $err.Exception.Message) -ForegroundColor Red
    Write-Host 'Les fichiers déjà remplacés ont leur original dans FR_Traduction\backup\avant_installation.'
    Wait-End
    exit 3
}
