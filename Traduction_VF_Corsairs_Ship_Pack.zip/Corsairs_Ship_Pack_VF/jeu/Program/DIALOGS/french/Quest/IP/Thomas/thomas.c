
void ProcessDialogEvent()
{
	ref NPChar, sld, chr;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "TohmasPetit_1":
			dialog.text = "Bonjour, "+GetSexPhrase("monsieur","madame")+". Je vois que vous portez une arme, et vous avez tout l'air "+GetSexPhrase("d'un fin bretteur","d'une fine bretteuse")+".";
			link.l1 = "Oui, vous ne vous trompez pas.";
			link.l1.go = "TohmasPetit_2";
		break;
		
		case "TohmasPetit_2":
			dialog.text = "J'ai besoin de toute urgence de l'aide de quelqu'un comme vous !";
			link.l1 = "Racontez-moi ce qui s'est passé.";
			link.l1.go = "TohmasPetit_3";
		break;
		
		case "TohmasPetit_3":
			dialog.text = "Des voyous du coin nous ont attaqués, ma fiancée et moi, juste devant les portes de la ville, et l'ont traînée dans la jungle ! Je manie mal l'épée, je ne peux pas m'en sortir seul. Je vous en prie, aidez-moi. Mon père est un marchand respecté en ville. Si vous nous aidez à la sauver, nous vous paierons très généreusement !";
			link.l1 = "D'accord, je vais t'aider. Montre-moi le chemin, mon garçon.";
			link.l1.go = "TohmasPetit_ChooseYes";
			link.l2 = "Débrouille-toi avec tes problèmes. J'ai bien assez de mes propres affaires.";
			link.l2.go = "TohmasPetit_ChooseNo";
		break;

		case "TohmasPetit_ChooseNo":
			NextDiag.CurrentNode = "TohmasPetit_5";
			pchar.questdata.TohmasPetit = 1;
			TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
			npchar.lifeday = 5;
			DialogExit();
		break;

		case "TohmasPetit_5":
			dialog.text = "Ah, c'est vous. Je n'ai pas le temps pour ça !";
			link.l1 = "...";
			link.l1.go = "Exit";
			NextDiag.TempNode = "TohmasPetit_5";
		break;

		case "TohmasPetit_ChooseYes":
			DialogExit();
			NextDiag.CurrentNode = "TohmasPetit_6";
			SetQuestHeader("TohmasPetit");
			AddQuestRecord("TohmasPetit", "QuestTaken");
			DoQuestCheckDelay("TohmasPetit_yes", 0.1);
		break;
		
		case "TohmasPetit_6":
			if (GetOfficersQuantity(pchar) > 0)
			{
				dialog.text = "Capitaine, avant d'aller plus loin, je dois vous demander de faire attendre vos officiers en ville. Si les bandits voient une foule, ils risquent de tuer ma fiancée et de s'enfuir, et je n'y survivrais pas.";
				link.l1 = "Très bien, ne t'inquiète pas.";
				link.l1.go = "TohmasPetit_ProcessGoFurther1";
				link.l2 = "Et pourquoi ne l'as-tu pas dit plus tכt, mon garçon ? Tout cela me paraît très suspect.";
				link.l2.go = "TohmasPetit_8";
			}
			else
			{
				dialog.text = "Parfait, capitaine, nous n'avons pas une minute à perdre. Ces gredins ont entraîné ma fiancée plus loin dans la jungle. Il faut se dépêcher avant qu'ils ne fassent du mal à ma Leblanc. Suivez-moi !";
				link.l1 = "Bon, passe devant.";
				link.l1.go = "TohmasPetit_ProcessGoFurther";
			}
		break;

		case "TohmasPetit_8":
			dialog.text = "Capitaine ! Rien de tel, je vous assure. Je vous en prie, capitaine, dépêchons-nous avant que ces ordures ne fassent du mal à ma fiancée.";
			link.l1 = "D'accord, je te crois. Je vais ordonner à mes hommes d'attendre en ville.";
			link.l1.go = "TohmasPetit_ProcessGoFurther1";
			link.l2 = "Non, je pense que tu me caches quelque chose, Thomas. Alors j'ai changé d'avis : va sauver ta fiancée toi-même.";
			link.l2.go = "TohmasPetit_9";
			NextDiag.TempNode = "TohmasPetit_5";
		break;
		
		case "TohmasPetit_9":
			dialog.text = "C'est très bas de votre part ! Toute la ville saura que vous êtes un lâche !";
			link.l1 = "Oui, oui. Fiche le camp.";
			link.l1.go = "TohmasPetit_ProcessCancel";
		break;
		
		case "TohmasPetit_10":
			dialog.text = "Capitaine, les voilà, et ma fiancée est avec eux ! Je vais aller les voir, leur dire que j'ai apporté l'or, et essayer de détourner leur attention. Je ne veux pas qu'ils fassent du mal à ma fiancée. Attendez ici, je vais essayer de les occuper, et ensuite, vous me suivrez.";
			link.l1 = "Bon plan, vas-y.";
			link.l1.go = "TohmasPetit_ubejal";
		break;
		
		case "TohmasPetit_ubejal":
			AddDialogExitQuest("TohmasPetit_Rastanovka");
			DialogExit();
		break;
		
		case "TohmasPetit_ProcessCancel":
			AddDialogExitQuest("TohmasPetit_konec");
			AddQuestRecord("TohmasPetit", "QuestRefused");
			CloseQuestHeader("TohmasPetit");
			DialogExit();
			pchar.questdata.TohmasPetit = 1;
			TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
		break;

		case "TohmasPetit_ProcessGoFurther1":
			DeleteAllOfficersFromLocation();
			AddQuestRecord("TohmasPetit", "SuspiciousRequest");
			AddDialogExitQuest("TohmasPetit_to_jungle");
			NextDiag.CurrentNode = "TohmasPetit_10";
			DialogExit();
		break;
		
		case "TohmasPetit_ProcessGoFurther":
			AddQuestRecord("TohmasPetit", "SuspiciousRequest");
			AddDialogExitQuest("TohmasPetit_to_jungle");
			NextDiag.CurrentNode = "TohmasPetit_10";
			DialogExit();
		break;

		case "exit":
			if (CheckAttribute(NextDiag,"TempNode")) NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}	
}
