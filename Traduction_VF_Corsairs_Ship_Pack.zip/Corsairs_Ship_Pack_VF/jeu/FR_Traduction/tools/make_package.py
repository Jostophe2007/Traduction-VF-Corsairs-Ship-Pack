# -*- coding: utf-8 -*-
"""Builds the zip that installs the French version on another PC.

usage: python -X utf8 make_package.py [output.zip]

Layout of the zip:
    Corsairs_Ship_Pack_VF/INSTALLER_VF.bat           -> runs _install/installer.ps1
    Corsairs_Ship_Pack_VF/LISEZMOI_INSTALLATION.txt
    Corsairs_Ship_Pack_VF/_install/installer.ps1, manifest.json
    Corsairs_Ship_Pack_VF/jeu/...                     -> files copied into the game folder
The uninstaller (FR_Traduction/Desinstaller_VF.bat + tools/desinstaller.ps1) is installed with the rest.
Sources of the installer: tools/installer/.
"""
import hashlib
import json
import os
import sys
import zipfile
from datetime import date

BASE = os.path.dirname(os.path.abspath(__file__))
FRT = os.path.abspath(os.path.join(BASE, '..'))
ROOT = os.path.abspath(os.path.join(FRT, '..'))
INST = os.path.join(BASE, 'installer')
PKG = 'Corsairs_Ship_Pack_VF'
GAME_VERSION = 'v2.4.8.0 (02.09.2026)'

# whole folders of the French version
FOLDERS = [
    'Program/DIALOGS/french',
    'Program/questbook/french',
    'Program/characters/french',
    'Program/Ships/french',
    'RESOURCE/INI/texts/french',
    'RESOURCE/INI/aliases/french',
    'RESOURCE/Textures/MainMenu/French',
]
# FR_Traduction content shipped (language switch, uninstall, regeneration, docs); work/ and backup/ stay here
FRT_ITEMS = ['Langue_Francais.bat', 'Langue_Anglais.bat', 'Langue_Russe.bat', 'Regenerer_FR.bat',
             'Desinstaller_VF.bat', 'LISEZMOI.md', 'GLOSSAIRE.md', 'fixups.txt', 'tools', 'tm', 'assets']
SKIP_DIRS = {'__pycache__', 'installer'}


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest().upper()


def crlf(text):
    return text.replace('\r\n', '\n').replace('\n', '\r\n')


def ps1_bytes(text):
    """Windows PowerShell 5.1 reads accented UTF-8 only with a BOM."""
    return b'\xef\xbb\xbf' + crlf(text.lstrip('﻿')).encode('utf-8')


def write_if_changed(p, data):
    if not os.path.exists(p) or open(p, 'rb').read() != data:
        open(p, 'wb').write(data)


def prepare_frt():
    """installs the uninstaller in FR_Traduction and gives every .bat CRLF line ends."""
    write_if_changed(os.path.join(FRT, 'Desinstaller_VF.bat'),
                     crlf(open(os.path.join(INST, 'Desinstaller_VF.bat'), encoding='ascii').read()).encode('ascii'))
    write_if_changed(os.path.join(BASE, 'desinstaller.ps1'),
                     ps1_bytes(open(os.path.join(INST, 'desinstaller.ps1'), encoding='utf-8').read()))
    for f in os.listdir(FRT):
        if f.lower().endswith('.bat'):
            p = os.path.join(FRT, f)
            write_if_changed(p, crlf(open(p, encoding='ascii').read()).encode('ascii'))


def walk(rel):
    p = os.path.join(ROOT, rel)
    if os.path.isfile(p):
        yield rel
        return
    for dp, ds, fs in os.walk(p):
        ds[:] = [d for d in ds if d not in SKIP_DIRS]
        for f in fs:
            yield os.path.relpath(os.path.join(dp, f), ROOT).replace(os.sep, '/')


def collect():
    files = {}
    for rel in FOLDERS:
        for r in walk(rel):
            files[r] = None
    files['RESOURCE/INI/fonts_fra.ini'] = None
    for f in os.listdir(os.path.join(ROOT, 'RESOURCE/Textures/fonts')):
        if f.lower().endswith(' fr.tga.tx'):
            files['RESOURCE/Textures/fonts/' + f] = None
    for f in os.listdir(os.path.join(ROOT, 'RESOURCE/Sounds/Interface')):
        if f.startswith('French_'):
            files['RESOURCE/Sounds/Interface/' + f] = None
    # game scripts changed by patch_code.py: shipped patched, with the hash of the original
    bk = os.path.join(FRT, 'backup', 'code')
    for b in os.listdir(bk):
        files[b.replace('__', '/')] = sha(os.path.join(bk, b))
    for item in FRT_ITEMS:
        for r in walk('FR_Traduction/' + item):
            files[r] = None
    return files


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'Traduction_VF_Corsairs_Ship_Pack.zip')
    prepare_frt()
    files = collect()
    missing = [r for r in files if not os.path.isfile(os.path.join(ROOT, r))]
    if missing:
        raise SystemExit('fichiers absents : %s' % missing[:5])
    today = date.today()
    manifest = {'version_jeu': GAME_VERSION, 'date': today.isoformat(), 'files': []}
    for r in sorted(files):
        e = {'path': r.replace('/', '\\'), 'sha': sha(os.path.join(ROOT, r))}
        if files[r]:
            e['orig'] = files[r]
        manifest['files'].append(e)
    readme = open(os.path.join(INST, 'LISEZMOI_INSTALLATION.txt'), encoding='utf-8').read()
    readme = readme.replace('{VERSION}', GAME_VERSION).replace('{DATE}', today.strftime('%d/%m/%Y'))
    tmp = out + '.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr(PKG + '/INSTALLER_VF.bat',
                   crlf(open(os.path.join(INST, 'INSTALLER_VF.bat'), encoding='ascii').read()).encode('ascii'))
        z.writestr(PKG + '/LISEZMOI_INSTALLATION.txt', b'\xef\xbb\xbf' + crlf(readme).encode('utf-8'))
        z.writestr(PKG + '/_install/installer.ps1',
                   ps1_bytes(open(os.path.join(INST, 'installer.ps1'), encoding='utf-8').read()))
        z.writestr(PKG + '/_install/manifest.json', json.dumps(manifest, ensure_ascii=False, indent=1).encode('utf-8'))
        for r in sorted(files):
            z.write(os.path.join(ROOT, r), PKG + '/jeu/' + r)
    os.replace(tmp, out)
    print('%d fichiers (dont %d scripts du jeu avec empreinte d\'origine) -> %s (%.1f Mo)'
          % (len(files), sum(1 for v in files.values() if v), out, os.path.getsize(out) / 1e6))


if __name__ == '__main__':
    main()
