// Gregg: Bob McCain, a drunkard in the pirate tavern - quest "Goods for Richard Tillman"
// (ported from Damned Destiny). Sells the place and time of Prenol's meeting for 5000.
// Logic - Program\Quests\reaction_functions\uneasydelivery.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			// Gregg: read through CheckAttribute - in Storm, touching a missing attribute
			// is a runtime error, not "false", and the function plays on with garbage
			if (CheckAttribute(PChar, "UneasyDelivery.CancelMoneyForBobMcCain"))
			{
				if (PChar.UneasyDelivery.CancelMoneyForBobMcCain == true)
				{
					dialog.text = "Alors ?";
					if (sti(PChar.money) >= 5000)
					{
						link.l1 = "Voici votre argent.";
						link.l1.go = "8";
					}
					else
					{
						link.l1 = "Je n'ai pas encore la somme.";
						link.l1.go = "11";
					}
					link.l2 = "Rien pour l'instant.";
					link.l2.go = "11";
					break;
				}
			}
			dialog.text = "Cap'taine, assieds-toi, viens boire un coup avec moi !";
			link.l1 = "Je n'ai pas le temps.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Hé, cap'taine, ça te dirait de boire un coup ?";
			link.l1 = "Pas envie. Et je suis occupé.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "א ta place, je boirais. Tu pourrais apprendre des choses utiles. Alors, tu t'assieds ?";
			link.l1 = "Hum...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryDialogWithMcCain");
		break;

		case "4":
			dialog.text = "Voilà qui est mieux !";
			link.l1 = "Bon, vas-y, qu'est-ce que tu as ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Pas si vite, cap'taine, réglons d'abord une chose. L'information n'est pas gratuite, comme tu le comprends, alors il va falloir payer. Cinq mille piastres sonnantes, et je te dirai oם chercher Prenol.";
			link.l1 = "Comment sais-tu que je le cherche ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je t'ai entendu jacasser sur Prenol avec le tavernier.";
			link.l1 = "Faisons comme ça : je te paierai, mais seulement si ton information se révèle utile.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Non, cap'taine, ce n'est pas comme ça qu'on fait des affaires. D'abord, tu me verses cinq mille dans la poche, et seulement ensuite, je te dis tout. Sinon, pas d'argent, pas d'information.";
			if (sti(PChar.money) >= 5000)
			{
				link.l1 = "Très bien, voici l'argent. Maintenant, dis-moi oם est Prenol.";
				link.l1.go = "8";
			}
			else
			{
				link.l1 = "Je reviendrai quand j'aurai l'argent.";
				link.l1.go = "11";
			}
			link.l2 = "Si je me décide, je viendrai te demander de l'aide.";
			link.l2.go = "11";
		break;

		case "8":
			AddMoneyToCharacter(PChar, -5000);
			PChar.UneasyDelivery.CancelMoneyForBobMcCain = false;
			dialog.text = "Alors, cap'taine, écoute bien, je n'aime pas me répéter. J'étais assis aujourd'hui comme d'habitude devant une chope de rhum, et j'ai entendu trois hommes parler. L'un d'eux était ce Prenol que tu cherches. \n Eh bien, les deux qui parlaient avec Prenol lui ont donné rendez-vous à deux heures du matin, dans la baie de l'Auge brisée.";
			link.l1 = "Et comment sais-tu que l'un d'eux était Prenol ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Les deux autres ne l'appelaient pas autrement que Prenol. Alors sois tranquille, c'est bien l'homme que tu cherches.";
			link.l1 = "Très bien, je te crois. Mais si tu m'as menti et qu'il n'y a personne là-bas cette nuit, je te retrouverai et...";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Je réponds de l'information, cap'taine. Sois tranquille, elle est exacte.";
			link.l1 = "J'y compte bien. Si tu t'es moqué de moi, je te retrouverai et je t'enterrerai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("UneasyDeliveryDialogWithMcCainEnd");
		break;

		case "11":
			ChangeCharacterAddressGroup(PChar, "Pirates_tavern", "goto", "goto2");
			LAi_SetPlayerType(PChar);
			LAi_SetSitType(CharacterFromID("Bob McCain"));
			PChar.UneasyDelivery.CancelMoneyForBobMcCain = true;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
