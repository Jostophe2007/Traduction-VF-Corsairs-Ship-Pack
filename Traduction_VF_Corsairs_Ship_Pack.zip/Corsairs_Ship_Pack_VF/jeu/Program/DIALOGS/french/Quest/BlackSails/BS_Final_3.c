
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//Скипаем с отравления три дня. ГГ приходит в себя в комнате таверны. Запись в СЖ: «Неожиданно. Но предсказуемо. Флинт поимел нас всех. Кто бы мог подумать. Хорошо, что жив(ва) остался(лась)! Нужно разобраться в происходящем. Дьявол, как же мутит то!»

		//Далее, Вейна нет на Багамах. Спускаемся в таверну. Подходит Макс

		case "BS_F3_1":	//Максин
			LAi_SetActorType(npchar);
			dialog.text = "Enfin, tu reviens à toi ! Tu as été dans les vapes plus longtemps que tous les autres.";
			link.l1 = "Tout le monde est vivant ? Quoi de neuf ?";
			link.l1.go = "BS_F3_2";
		break;

		case "BS_F3_2": //Максин
			dialog.text = "Tout le monde est vivant, il avait mis de la belladone dans le vin. Inès nous a tous fait boire du charbon de bois et Dieu sait quoi encore. On a vomi partout, mais on a survécu.";
			link.l1 = "Il faudra que je la remercie d'une façon ou d'une autre. Alors, quelles nouvelles ? Flint ? L'or ?";
			link.l1.go = "BS_F3_3";
		break;

		case "BS_F3_3":	//Максин
			dialog.text = "Ni Flint, ni or. Il n'y a qu'un coffre de doublons dans l'entrepכt, environ cinquante mille par tête. Et un mot : « Pardonnez-moi, partagez ceci et oubliez l'Urca et Flint. C'est ce qu'il faut faire. De toute façon, vous ne comprendriez pas. F. »";
			link.l1 = "Maudit hypocrite ! Et moi qui croyais presque à son « amitié ». Oם sont les autres ?";
			link.l1.go = "BS_F3_4";
			AddMoneyToCharacter(PChar, 50000);
		break;

		case "BS_F3_4":	//Максин
			dialog.text = "Eleanor est chez elle, avec Rackham et Bonny ; tous les trois sont furieux comme des diables. Ils n'arrêtent pas de casser des choses et de se hurler dessus. Vane, dès qu'il a tenu debout, a hissé les voiles et il est parti on ne sait oם.";
			link.l1 = "Je pense qu'il vaut mieux ne pas mettre les pieds à la résidence pour l'instant. Je vais prendre l'air.";
			link.l1.go = "BS_F1_9exit";
		break;
		
		case "BS_F1_9exit":	//Максин
			DialogExit();
			PChar.quest.BS_SentJonsTavernAgentDialugue.win_condition.l1 = "location";
			PChar.quest.BS_SentJonsTavernAgentDialugue.win_condition.l1.location = "SentJons_tavern";
			PChar.quest.BS_SentJonsTavernAgentDialugue.function = "BS_SentJonsTavernAgentDialugue";
			pchar.BSLookingForAgentDialugue = true;
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			AddQuestRecord("BSHangover", "21");
		break;

		//Запись в СЖ: «Трудно думать, когда тебя постоянно тошнит. Но нужно что-то делать. Попробую подключить разведку. Какой там пароль? На Антигуа! В путь».

		//В таверну Сен Джонса посадить непися, который отзовётся на пароль

		//На Антигуа, идём в таверну и начинаем донимать нпс паролем «Рыбалка удалась». Ответы в духе: «Пойди проспись!», «Закусывать надо!», «Что? О чем вы?».

		//Нужный непись:

		case "BS_F3_5":	//Агент
			dialog.text = RandPhraseSimple(RandPhraseSimple("Ne me cache pas la lumière, je ne vois plus les mouches dans ma chope !", "Que voulez-vous ?"), RandPhraseSimple("Pas question de dessoמler, tu ne m'en empêcheras pas !", "T'as quelque chose à boire ?"));
			link.l1 = "La pêche a été bonne.";
			link.l1.go = "BS_F3_6";
		break;

		case "BS_F3_6":	//Агент
			dialog.text = "Et la prise, elle est... ?";
			link.l1 = "Pas de prise, le saumon s'est sauvé, ou l'anguille. Le thon ? Au diable vos jeux ! Il faut qu'on parle !";
			link.l1.go = "BS_F3_7";
		break;

		case "BS_F3_7":	//Агент
			dialog.text = "Hum. Eh bien, euh. Je vous écoute.";
			link.l1 = "Organisez-moi une rencontre avec vos supérieurs. C'est urgent. Le poisson pourrait me glisser entre les doigts, si vous voyez ce que je veux dire !";
			link.l1.go = "BS_F3_8";
		break;

		case "BS_F3_8":	//Агент
			dialog.text = "Je n'ai pas ce pouvoir, mais je transmettrai l'information. Comment puis-je vous contacter ?";
			link.l1 = "Je passerai à cette taverne de temps en temps.";
			link.l1.go = "BS_F3_9";
		break;

		case "BS_F3_9":	//Агент
			npchar.location = "none";
			LAi_CharacterDisableDialog(npchar);
			DeleteAttribute(PChar, "BSLookingForAgentDialugue");
			AddQuestRecord("BSHangover", "22");
			pchar.quest.BS_AfterAgentMeeting.win_condition.l1          = "location";
			pchar.quest.BS_AfterAgentMeeting.win_condition.l1.location = "Nassau_OfisGatri";
			pchar.quest.BS_AfterAgentMeeting.function             = "BS_AfterAgentMeeting";
			LocatorReloadEnterDisable("Nassau_town", "houseS1", false);
			dialog.text = "Parfait ; si vous ne me trouvez pas ici, adressez-vous à la serveuse.";
			link.l1 = "D'accord, mais dites-lui que le temps presse. Portez-vous bien !";
			link.l1.go = "exit";
		break;

		//Запись в СЖ: "Весточку отправил(ла). Нужно вернуться на Багамы и поискать Вейна. Как бы он дров не наломал".
		//Плывём на Багамы. В резиденции Гатри, Бонни, Рекхэм.


		case "BS_F3_10":	//Гатри начинает диалог.
			dialog.text = "Tu as trouvé Vane ?";
			link.l1 = "Non. Une idée de l'endroit oם il a filé ?";
			link.l1.go = "BS_F3_10_1";
		break;
		
		case "BS_F3_10_1":
			StartInstantDialogNoType("BS_Rakham", "BS_F3_11", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_11":	//Рэкхэм.
			dialog.text = "Il a dit qu'il allait faire rendre l'âme à ces sales trognes noires, il m'a fait un œil au beurre noir, et il a filé.";
			link.l1 = "Des sales trognes ? דa devient de plus en plus intéressant !";
			link.l1.go = "BS_F3_11_1";
		break;
		
		case "BS_F3_11_1":
			StartInstantDialogNoType("BS_Bony", "BS_F3_12", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_12":	//Бонни.
			dialog.text = "Flint faisait des affaires avec des esclaves en fuite. Il est peut-être chez eux en ce moment.";
			link.l1 = "Y a-t-il seulement quelqu'un ici avec qui il n'a pas de liens ni d'affaires ?";
			link.l1.go = "BS_F3_12_1";
		break;
		
		case "BS_F3_12_1":
			StartInstantDialog("gatri_temp", "BS_F3_13", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_13":	//Гатри.
			dialog.text = "Il leur a bourré le crâne avec l'idée d'un וtat libre dans le Nouveau Monde. L'égalité des droits, pas de maîtres, la paix et le bonheur. En réalité, il se sert d'eux comme de chair à canon\n Vous ai-je dit que Flint était un homme cruel et calculateur ? C'est un idéaliste, et tous ceux qui croient à ses discours enflammés deviendront un instrument, rien de plus.";
			link.l1 = "(א part) Je pense qu'il vaut mieux ne pas encore leur parler de mon pacte avec Bones. (א tous) Jack, Anne. Vous êtes restés à terre ? Je vous propose une place dans mon équipage. Nous retrouverons Charles, nous réglerons l'affaire des esclaves et nous chercherons les traces de Flint dans leurs cachettes.";
			link.l1.go = "BS_F3_13_1";
		break;
		
		case "BS_F3_13_1":
			Lai_SetActorTypeNoGroup(npchar);
			StartInstantDialogNoType("BS_Rakham", "BS_F3_14", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_14":	//Рэкхэм.
			dialog.text = "Nous aimerions bien, mais Anne est enceinte. J'ai acheté ici une vieille goélette pour trois fois rien. Bref, nous avons décidé de nous retirer des affaires pour un moment. Nous allons nous installer à Charlestown, chez le père d'Anne. Je ferai du cabotage et quelques petits boulots.";
			link.l1 = "Tenez, voilà un petit quelque chose. Pour la jeune famille, pour ainsi dire. Hum. Et n'osez pas refuser ! Eh bien. Bonne chance à vous trois. Donnez de vos nouvelles."; //отдаём 35к 7.04.2023
			link.l1.go = "BS_F3_14_1";
		break;
		
		case "BS_F3_14_1":
			AddMoneyToCharacter(PChar, -35000);
			StartInstantDialog("gatri_temp", "BS_F3_15", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_15":	//Гатри.
			dialog.text = "Un noble geste ! Mais venons-en au fait. Les esclaves sont des fugitifs qui se cachent dans la jungle et que les boucaniers nourrissent. Ce qui veut dire qu'il faut les chercher à Cuba ou à Hispaniola. Mais que veux-tu à Vane ? La fraternité pirate ? Moi, je regarderais plutכt du cכté de la Compagnie néerlandaise des Indes occidentales.";
			link.l1 = "Vane et moi, nous avons une affaire à régler. Pas de sentimentalisme. Qu'est-ce que les marchands hollandais viennent faire là-dedans ?";
			link.l1.go = "BS_F3_16";
		break;

		case "BS_F3_16":	//Гатри.
			dialog.text = "Flint a un navire reconnaissable et plusieurs tonnes d'or espagnol. Il serait logique de diviser la cargaison et de l'envoyer par lots sur des galions marchands sous escorte militaire, n'importe oם. Dans les Carolines, par exemple, ou même à Boston. דa ne m'étonnerait pas que mon très cher papa soit dans le coup.";
			link.l1 = "דa vaut aussi la peine d'être vérifié. Merci. Autre chose ?";
			link.l1.go = "BS_F3_17";
		break;

		case "BS_F3_17":	//Гатри.
			SetFunctionLocationCondition("BS_AfterAgentMeetingExit", "Nassau_tavern", false);
			LocatorReloadEnterDisable("Nassau_town", "houseS1", true);
			AddQuestRecord("BSHangover", "23");
			Lai_SetActorTypeNoGroup(npchar);
			dialog.text = "Maxine. Emmène-la loin d'ici. S'il le faut, de force !";
			link.l1 = "C'est tout ? Bon, d'accord. Je vais me mettre à chercher. Dans quelle direction, je n'en ai aucune idée. Trop d'inconnues. א plus tard.";
			link.l1.go = "BS_F3_17exit";
		break;

		//Запись в СЖ: "Возможное участие отца Элеоноры? Вест-Индская торговая компания? Джек и Энн – благочестивые плантаторы? Беглые рабы и ссора Элеоноры с Макс. Ах да, ещё британская военная разведка. Не хватает только мстительных испанцев, проклятого сокровища и древнего бога местных дикарей! Ну, начнём с простого. Макс. Проверю таверну"
		//Идём в таверну. Говорим с Макс.
		
		case "BS_F3_17exit":	//Гатри.
			DialogExit();
			sld = CharacterFromID("BS_Rakham");
			LAi_CharacterDisableDialog(sld);
			sld = CharacterFromID("BS_Bony");
			LAi_CharacterDisableDialog(sld);
			LAi_SetPlayerType(PChar);
			ChangeCharacterAddressGroup(PChar, "Nassau_OfisGatri", "goto", "goto5");
		break;
		
		case "BS_F3_18":	//Максин.
			dialog.text = "Elle exige que je quitte son île ! Après tout ce que nous avons vécu ! Je...";
			link.l1 = "Chut. Je ne veux pas savoir ce qui s'est passé entre vous. Je pars à la recherche de notre argent, et j'aurai besoin de tes talents pour recueillir des informations. Alors, à bord ! Pas de discussion !";
			link.l1.go = "BS_F3_18_exit";
		break;
		
		case "BS_F3_18_exit":	//Максин.
			DialogExit();
			AddQuestRecord("BSHangover", "24");
			Lai_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			SetFunctionLocationCondition("BS_HangoverMaksPortRoyalArriving", "PortRoyal_town", false);
		break;

		//Макс в пассажиры. Выходим в море.
		//Запись в СЖ: "Доставлю Максин в Порт Рояль, пусть собирает слухи. А после решу, что делать дальше"
		//Отвозим Макс в ПР. Диалог на причале.

		case "BS_F3_19":	//Максин. Вариант с отказом от секаса.
			SetFunctionLocationCondition("BS_HangoverToAntigua", "Antigua", false);
			dialog.text = "Tu sais, nous avons traversé tant de choses ensemble, et nous n'avons jamais appris à nous connaître. Et si nous laissions tout de cכté ce soir pour le passer autour d'une bonne bouteille de vin ?";
			link.l1 = "Le vin me resterait en travers de la gorge, si tu vois ce que je veux dire. Le travail d'abord, le plaisir ensuite ! Sans rancune.";
			link.l1.go = "BS_F3_20";
			link.l2 = "C'est une proposition tentante ! Mais le vin me donne la nausée, si tu vois ce que je veux dire. Que dirais-tu d'un peu de rhum ?";
			link.l2.go = "BS_F3_21";
		break;

		case "BS_F3_20":	//Максин.
			dialog.text = "Sans rancune. Au revoir, capitaine !";
			link.l1 = "(א part) Et si... ? Non ! Le temps presse !";
			link.l1.go = "BS_F3_20exit";
		break;
		
		case "BS_F3_20exit":	//Максин.
			DialogExit();
			chrDisableReloadToLocation = false;
			BS_ReplaceHostessWithMaks();
			LAi_ActorGoToLocation(npchar, "reload", "reload9_back", "none", "", "", "", 2.3);
			AddQuestRecord("BSHangover", "25");
		break;

		case "BS_F3_21":	//Максин. Вариант с секасом.
			dialog.text = "Va pour le rhum ! Allons-y !";
			link.l1 = "Allons-y ! J'ai justement deux ou trois bouteilles sur moi !";
			link.l1.go = "BS_F3_21_exit";
		break;
		
		case "BS_F3_21_exit":	//Максин. Вариант с секасом.
			DialogExit();
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload9_back", "none", "", "", "", 2.3);
			PChar.quest.BS_IntimWithMaks.win_condition.l1 = "locator";
			PChar.quest.BS_IntimWithMaks.win_condition.l1.location = "PortRoyal_town";
			PChar.quest.BS_IntimWithMaks.win_condition.l1.locator_group = "reload";
			PChar.quest.BS_IntimWithMaks.win_condition.l1.locator = "reload9_back";
			PChar.quest.BS_IntimWithMaks.function = "BS_IntimWithMaks";
		break;

		//В обоих вариантах запись в СЖ: "Итак, я на перепутье. Искать Вейна и лагеря беглых рабов? Или узнать, чем может помочь британский флот? Или стоит проверить версию Элеоноры с торгашами? Распыляться не стоит, банально не хватит времени на всё сразу. Отмету голландцев сразу, пусть и логично звучит, но у Компании своя разведка есть, и Флинт немало им крови попортил. Значит поиски Вейна или помощь флота. Вейн большой мальчик, думаю, что справится и без меня, значит на Антигуа!" 7.04.2023 // так как выбора уже и нет, то не забыть потереть лишее из СЖ финала_2
		//Ниже вариант помощи разведке и Бонсу.
		//Плывём на Антигуа, в локации острова запись в СЖ: "Вейн – большой мальчик, надеюсь, дров не наломает. Проверю таверну. Агент говорил, что если его не будет на месте, спросить разносчицу."

		case "BS_F3_23":	//Офицантка.
			dialog.text = "Je vous apporte quelque chose, capitaine ?";
			link.l1 = "Non. Dis-moi, ma jolie, tu n'aurais pas vu un ami à moi par ici ? Un grand amateur de pêche ; nous avons bu un verre ici il n'y a pas si longtemps ?";
			link.l1.go = "BS_F3_24";
		break;


		case "BS_F3_24":	//Офицантка.
			dialog.text = "Il chasse le gros poisson ? Il m'a dit de vous dire qu'un autre pêcheur vous attendrait dans les eaux de la Dominique, au large de la plage de Castle Brush.";
			link.l1 = "Merci. Tiens, voilà pour, euh, quelque chose de joli !"; //Отдаём 500 рублей
			link.l1.go = "exit";
		break;

		//Запись в СЖ: "Сбор рыбаков у Доминики. Нужно поспешить".
		//У пляжа стоит фрегат Бонса. Если решим пострелять - провал линейки. Высылаем шлюпку, разговор с Бонсом на борту.

		case "BS_F3_25":	//Бонс.
			dialog.text = "Vous devriez exercer votre mémoire, capitaine. Le bon mot de passe peut parfois sauver une vie !";
			link.l1 = "Je me fiche de vos jeux de mots de passe et de rendez-vous secrets. Je suis là pour affaires ! Flint a disparu ! Avec le navire et l'or. Nous avons survécu par miracle ! Par mes propres réseaux, je n'ai aucune piste. Dis-moi ce que tu as. On pourra peut-être attraper ton poisson ensemble. Et ensuite, chacun suivra sa route !";
			link.l1.go = "BS_F3_26";
		break;


		case "BS_F3_26":	//Бонс.
			dialog.text = "Et les honneurs ? La récompense ? Le pardon, enfin ?";
			link.l1 = "Avec l'or de l'Urca, je pourrai au moins m'acheter un titre. Et la faveur de la Couronne, ça s'achète aussi. Ne me fais pas languir, Billy. דa me démange de planter quelqu'un !";
			link.l1.go = "BS_F3_27";
		break;

		case "BS_F3_27":	//Бонс.
			dialog.text = "Je vais commencer par le commencement. Le Scarborough et le reste de l'escadre ne sont pas seulement là pour capturer Flint et intimider les pirates. La priorité absolue est d'empêcher l'or de l'Urca d'arriver en Europe. Avec cet or, l'Espagne rembourserait aisément une partie de ses dettes, et elle échapperait ainsi à l'influence de ses créanciers. De plus, une telle quantité de pièces déjà frappées dévaluerait celles qui circulent déjà. Donc, si l'or disparaît dans les Caraïbes, c'est encore mieux. Autrement dit, personne en Europe ne le cherchera, et personne n'y prétendra non plus.";
			link.l1 = "Je comprends. La politique, les intrigues, les complots. La vieille Europe n'en finit jamais.";
			link.l1.go = "BS_F3_28";
		break;

		case "BS_F3_28":	//Бонс.
			dialog.text = "Mon commandant en titre, sir Francis Newm, capitaine du Scarborough, est un imbécile pompeux, fils de quelque petit lord. Il distribue à tort et à travers lettres de marque et pardons, il recrute des partisans. Il cherche ce que tu cherches, et je soupçonne que mes échecs sont son œuvre. J'ai toutes les raisons de croire qu'il est après l'or.";
			link.l1 = "Je perds le fil, Bill. Flint, l'or. Que peux-tu faire pour moi ?";
			link.l1.go = "BS_F3_29";
		break;

		case "BS_F3_29":	//Бонс.
			dialog.text = "Il y a des informations non vérifiées sur les mouillages du Walrus dans différentes baies. Je n'ai pas les moyens de les vérifier rapidement. Alors, séparons-nous. J'irai au cap Catoche et je descendrai vers le sud sous pavillon espagnol. Toi, va jusqu'au rivage de Boca de la Sierpe et pars de là vers l'ouest, en inspectant chaque crique. Nous nous retrouverons à la lagune de Chiriquí. N'entrez pas dans les ports, évitez les affrontements. א partir d'aujourd'hui, deux semaines devraient suffire.";
			link.l1 = "Tu as dit que tu avais des informations précises sur les mouillages ! Il faudrait inspecter chaque crique !";
			link.l1.go = "BS_F3_30";
		break;

		case "BS_F3_30":	//Бонс.
			dialog.text = "L'informateur n'était pas très précis dans ses descriptions, et il est mort vite. Newm n'est pas seulement un crétin, c'est aussi un sadique.";
			link.l1 = "Alors Newm cherche lui aussi les mouillages ?";
			link.l1.go = "BS_F3_31";
		break;

		case "BS_F3_31":	//Бонс.		
			SetFunctionExitFromLocationCondition("BS_BonsDominicaNone", "Dominica", false);
			SetFunctionLocationCondition("BS_ShoreSeeking", "Shore18", false);
			AddQuestRecord("BSHangover", "63");
			dialog.text = "Il va bientכt s'y mettre. Un brick courrier de la métropole est arrivé l'autre jour, et le Scarborough a levé l'ancre. Quels ordres Newm a reçus, je l'ignore. Mais ça nous donne de l'avance.";
			link.l1 = "Alors ne perdons pas de temps !";
			link.l1.go = "BS_F3_31exit";
		break;
		
		case "BS_F3_31exit":
			DialogExit();
			npchar.dialog.filename = "Quest\BlackSails\BS_Final_3.c";
			npchar.dialog.currentnode = "BS_F3_31_loop";
		break;
		
		case "BS_F3_31_loop":	//Бонс.
			dialog.text = "Il faut se dépêcher !";
			link.l1 = "Alors ne perdons pas de temps !";
			link.l1.go = "BS_F3_31exit";
		break;

		//Запись в СЖ: "От Бонса-Блэкхема проку немного, нужно исследовать большой кусок побережья Мэйна. Но это хоть что-то. Начну с бухты Бока де ла Сьерпе"
		//В бухте Бока де ла Сьерпэ, на берегу пусто. Запись в СЖ: "Пусто. Продолжу поиски. Нужно исключить бухты, которые находятся в виду фортов, Флинт не стал бы так рисковать. Сверюсь с картой. Ага, остаются: Пляж Лос Текес, бухта Гуахира, бухта Ковеньяс, залив Москитос. Что же, в путь."
		//В Лос Текес – пара агрессивных английских фрегатов. Бой. Высадка. На берегу штук 30 военных – файт. Запись в СЖ: "Похоже люди Ньюма. Ищут зацепки на месте гибели 'Урки'. Нужно быть настороже". //игрок может и не высадиться в бухте. нужна принудиловка ! 7.04.2023
		//Москитос. На берегу подбегает матрос.

		case "BS_F3_32":	//Матрос.
			dialog.text = "Capitaine " + GetFullName(pchar) + " ? Je viens de la part d'un ami pêcheur !";
			link.l1 = "Billy n'a toujours pas fini de jouer ? Qu'est-ce que tu as pour moi ?";
			link.l1.go = "BS_F3_33";
		break;

		case "BS_F3_33":	//Матрос.
			dialog.text = "Rendez-vous immédiatement à Bridgetown ! Les recherches peuvent attendre. C'est ce qu'il a dit.";
			link.l1 = "C'est tout ? Pourquoi tant d'urgence ?";
			link.l1.go = "BS_F3_34";
		break;


		case "BS_F3_34":	//Матрос.
			dialog.text = "Je n'en ai aucune idée, "+ GetSexPhrase("monsieur","madame") +", je ne suis qu'un messager !" ;
			link.l1 = "D'accord, compris.";
			link.l1.go = "BS_F3_34exit";
		break;
		
		case "BS_F3_34exit":	//Матрос.
			AddQuestRecord("BSHangover", "66");
			chrDisableReloadToLocation = false;
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "", "", "", "", 3.0);
			SetFunctionLocationCondition("BS_BridgetownBonsAlarm", "Bridgetown_town", false);
			DialogExit();
		break;

		//Запись в СЖ: "Что-то произошло. Бонс требует срочно прибыть в Бриджтаун."
		//Плывём на Барбадос. В городе подходит Бонс.

		case "BS_F3_35":	//Бонс.
			dialog.text = "Tu es là. Bien. Les autorités de la Barbade demandent de l'aide : leur garnison n'est toujours pas au complet depuis le raid espagnol. Et le Scarborough est on ne sait oם.";
			link.l1 = "Qu'est-ce qui se passe ? Au fait, sur la plage de Los Teques, j'ai croisé des hommes de Newm. Ils fouillaient l'épave de l'Urca.";
			link.l1.go = "BS_F3_36";
		break;

		case "BS_F3_36":	//Бонс.
			dialog.text = "Ils n'y trouveront pas grand-chose. Une attaque contre les plantations de l'île se prépare. Aujourd'hui, demain, bientכt. Et celui qui la mènera, tu ne vas pas le croire : Flint lui-même !";
			link.l1 = "Pourquoi diable voudrait-il faire ça ?";
			link.l1.go = "BS_F3_37";
		break;

		case "BS_F3_37":	//Бонс.	
			dialog.text = "Quelque part dans les colonies, il se constitue une armée de forçats et d'esclaves en fuite, et ici, il y a le bagne du roi. Des coupe-jarrets de tout poil : on les arme, et c'est prêt. Voilà à quoi lui sert l'or espagnol. Et il n'a aucune intention de le partager. La garnison locale n'est faite que de recrues et de miliciens coloniaux. Ils se disperseront aux premières salves. Mais si nous unissons nos équipages, nous pourrons le repousser et, si Dieu le veut, le capturer lui-même !";
			link.l1 = "Une embuscade ? Eh bien, ça pourrait marcher. Rassemble tes hommes, rendez-vous à la plantation !";
			link.l1.go = "BS_F3_37exit";
		break;
		
		case "BS_F3_37exit":
			AddQuestRecord("BSHangover", "67");
			LAi_SetActorType(npchar);
			ChangeCharacterAddressGroup(npchar, "none", "", "");
			SetFunctionLocationCondition("BS_BridgetownPlantationPrepare", "Bridgetown_Plantation", false);
			pchar.BS_PlantationBattle = true;
			PChar.quest.BS_ReloadToPlantation.win_condition.l1 = "locator";
			PChar.quest.BS_ReloadToPlantation.win_condition.l1.location = "Bridgetown_town";
			PChar.quest.BS_ReloadToPlantation.win_condition.l1.locator_group = "reload";
			PChar.quest.BS_ReloadToPlantation.win_condition.l1.locator = "gate1_back";
			PChar.quest.BS_ReloadToPlantation.function = "BS_ReloadToPlantation";
			LAi_MethodDelay("BS_BridgetownPlantationOrders",0.1);
			DialogExit();
		break;

		//Запись в СЖ: "Предстоит жаркое дельце. Флинт собирается освободить каторжан для своей армии. Отличная возможность прихлопнуть ублюдка. Но, всё же стоит помнить, с кем мы имеем дело. Устроим засаду на плантации".
		//Идём на плантацию. Там бродят наши в перемешку с английскими солдатами, заходим за калитку плантации. Вывести лог «Засада организована! Всем быть на готове!» Начинаем спаунить пиратов от ворот. В три-четыре волны.
		//Перебили всех, Бонс орёт : «Они с полей прут, ещё больше! Стрелки, к бою!»
		
		case "BS_F3_PlantOfficer":
			dialog.text = "Capitaine, l'embuscade a été organisée selon vos ordres.";
			link.l1 = "Bien.";
			link.l1.go = "BS_F3_PlantOfficerexit";
		break;
		
		case "BS_F3_PlantOfficerexit":	
			LAi_SetWarriorType(npchar);
			LAi_warrior_DialogEnable(npchar, false);
			Group_AddCharacter(LAI_GROUP_PLAYER, npchar.id);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			DoQuestFunctionDelay("BS_BridgetownPlantationBattleStart", 30.0);
			DialogExit();
		break;	
		
		case "BS_F3_38":	//Бонс.
			dialog.text = "Ils arrivent des champs, encore plus nombreux ! Tireurs, au combat !";
			link.l1 = "Suivez-moi !";
			link.l1.go = "BS_F3_38tobattle";
		break;
		
		case "BS_F3_38tobattle":	//Бонс.
			BS_BridgetownPlantationReinforcement_2();
			AddDialogExitQuest("MainHeroFightModeOn");
			DialogExit();
		break;
		
		//Спауним пиратов прям на плантации. Перебили.

		case "BS_F3_39":	//Бонс.
			dialog.text = "Oם est ce maudit Flint ?";
			link.l1 = "Ce n'est pas fini ! Tu entends ? Les canons tirent ! א terre !";
			link.l1.go = "exit";
		break;

		//Нужна пара взрывов где-нибудь. От ворот ещё толпа пиратов. С ними Флинт и Вейн. Пока живы их пираты - Ф и В бессмернтые. Как только полегли все пираты Флинт начинает диалог.

		case "BS_F3_40Flint_1":	//Флинт.
			dialog.text = "Vane ! Repli, des renforts arrivent du fort !";
			link.l1 = ""; //Вейн
			link.l1.go = "BS_F3_40Vein_1";
		break;
		
		case "BS_F3_40Vein_1":
			StartInstantDialog("BS_Vein", "BS_F3_40Vein_2", "Quest\BlackSails\BS_Final_3.c");
		break;
		
		case "BS_F3_40Vein_2":	//Флинт.
			dialog.text = "Je te couvre, file !";
			link.l1 = ""; //Вейн
			link.l1.go = "BS_F3_40Bons_1";
		break;
		
		case "BS_F3_40Bons_1":	//Флинт.
			StartInstantDialog("BSBons", "BS_F3_40Bons_2", "Quest\BlackSails\BS_Final_3.c");
		break;


		case "BS_F3_40Bons_2":	//Флинт.
			dialog.text = "Je comprends. "+pchar.name+", tu te bats du mauvais cכté ! Mais c'est ton choix." ; //Убегает.
			link.l1 = "Je pars à la poursuite de Flint. Nous ne pouvons pas le laisser filer !"; //Бонс. Убегает.
			link.l1.go = "BS_F3_40Vein_3";
		break;
		
		case "BS_F3_40Vein_3":
			sld = CharacterFromID("Flint");
			Group_AddCharacter(LAI_GROUP_NEITRAL, sld.id);
			LAi_group_MoveCharacter(sld, LAI_GROUP_NEITRAL);
			Lai_SetActorTypeNoGroup(sld);
			LAi_ActorRunToLocation(sld, "reload", "reload2_back", "none", "", "", "", 10.0);
			StartInstantDialog("BS_Vein", "BS_F3_40Vein_4", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_40Vein_4":	//Вейн.
			sld = CharacterFromID("BSBons");
			ChangeCharacterAddressGroup(sld, "none", "", "");
			dialog.text = "Alors ? Rien que toi et moi ?!";
			link.l1 = "Qu'est-ce qui te prend, Charles ? Nous avions un accord !";
			link.l1.go = "BS_F3_42";
		break;

		case "BS_F3_42":	//Вейн.
			dialog.text = "Tu changes trop souvent de camp. Et tes nouveaux amis ont tué Eleanor !";
			link.l1 = "Comment ?! Quand ?";
			link.l1.go = "BS_F3_43";
		break;

		case "BS_F3_43":	//Вейн.
			dialog.text = "Le Scarborough est venu aux Bahamas pendant que je cherchais Flint, et il a fait le ménage. Eleanor a été emmenée enchaînée à Port Royal et pendue sur le port. Maxine est en prison, et elle sera bientכt pendue aussi. Jack est dans la prison de Charlestown, mais il s'en sortira. Anne a été graciée. Un tribunal plein d'humanité a jugé que pendre une femme enceinte, même pirate, c'était excessif. Et toi, tu joues les chiens de chasse qui flairent l'or espagnol pour le renseignement anglais.";
			link.l1 = "C'est Flint qui t'a raconté ça ? Il sait manipuler les esprits !";
			link.l1.go = "BS_F3_44";
		break;

		case "BS_F3_44":	//Вейн.
			dialog.text = "J'ai vu son corps. Ils l'ont mise dans une cage pour qu'elle ne tombe pas en morceaux en se décomposant. Elle est toujours pendue près du quai. Assez parlé ! Un seul d'entre nous sortira d'ici !";
			link.l1 = "Ce n'est pas ma faute, Charles. Mais je ne te ferai pas changer d'avis. Commence quand tu seras prêt !";
			link.l1.go = "BS_F3_44VeinFight";
		break;
		
		case "BS_F3_44VeinFight":	//Вейн.
			DialogExit();
			BS_RestoreMaksHostess();
			BS_QuestCleaning(false);
			DoQuestFunctionDelay("BS_BridgetownPlantationVeinFight", 5.0);
		break;
		
		//Рубимся с Вейном. Убиваем. Страдаем, какой автор гнида. Идём в город. Подбегает Сильвер.

		case "BS_F3_45":	//Сильвер.
			dialog.text = "Hé, "+pchar.name+", tu fais une de ces têtes ! Qu'est-ce qui s'est passé ? C'est Flint ?";
			link.l1 = "Tais-toi, John. Comment es-tu arrivé ici ?";
			link.l1.go = "BS_F3_46";
		break;

		case "BS_F3_46":	//Сильвер.
			dialog.text = "Je me suis sauvé de chez Flint quand il s'est mis à effacer ses traces. Il a massacré tout l'ancien équipage !";
			link.l1 = "Je pense le rattraper en mer. Tu viens avec moi ?";
			link.l1.go = "BS_F3_47";
		break;

		case "BS_F3_47":	//Сильвер.
			dialog.text = "Flint ?! Non ! Si ! Oui ! Oui, je pense que je serai plus en sécurité avec toi. דa fait une semaine que je me cache sous les jupons des catins !";
			link.l1 = "Alors, en mer !";
			link.l1.go = "BS_F3_47exit";
		break;
		
		case "BS_F3_47exit":	//Сильвер.
			DialogExit();
			chrDisableReloadToLocation = false;
			AddQuestRecord("BSHangover", "68");
			Lai_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload2_back", "none", "", "", "", 5.0);
			SetFunctionLocationCondition("BS_Hangover_BarbadosRangerSeaBattle", "Barbados", false);
			Pchar.BonsFlintRunning = true;
			SetFunctionTimerConditionParam("BS_Hangover_CapeCatocheBattle", 0, 0, 5, 0, false);
			SetFunctionTimerConditionParam("BS_SecondFinalEndingTimeOutFail", 0, 0, 14, 0, false);
			BS_Hangover_ChaseFromBarbados();		
		break;

		//Запись в СЖ: "Вейн. Чёрт тебя дери. Ты был мне другом! И Бонс, чёртов Бонс. Пока я искал(ла) непойми что, англичане устроили зачистку. Гатри мертва. Всё катиться в бездну! Осталось поквитаться с Флинтом и плевать, что будет дальше!"
		//Выходим в море, нас атакует «Рейнджер». Топим. Выходим на глобалку. От нас по съёбам удирает квестовик-энка (типо Флинт с Бонсом). Нужно скорости им накрутить, чтоб мы только-только угнаться могли. Энка пиздует к мысу Каточе и там исчезает. Выходим на локалку. Там фрегат Бонса гасится с Моржом (Бонс зелёненький). Берём Моржа на абордаж. В каюте рубилово с Флинтом. Нулим Флинта. Диалог
		//Диалог после боя в каюте Моржа, ниже 7.04.2023																	   


		case "BS_F3_48":	//Флинт.
			dialog.text = "Vane est mort ? Dommage, mais il était trop émotif. Et toi, tu as accepté l'offre des autorités anglaises ? Le pardon, une lettre de marque, les faveurs royales ? Tu sais bien qu'ils font des promesses facilement et qu'ils les reprennent tout aussi facilement. J'ai été l'un d'eux !";
			link.l1 = "...";
			link.l1.go = "BS_F3_49";
		break;

		case "BS_F3_49":	//Флинт.
			dialog.text = "Inutile de me fusiller du regard. דa ne marche pas avec moi. Il y a d'autres moyens de tout arranger. Nous capturons la frégate de Bones, puis, sous pavillon anglais et grâce à son livre des signaux, nous attirons le Scarborough dans un piège. Ainsi, nous serons débarrassés du renseignement militaire, qui a déjà bien assez à faire sans nous. Ensuite...";
			link.l1 = "C'est comme ça que fonctionne ta tête ? Des plans dans des plans ? Pas d'amis, pas d'ennemis. Seulement des instruments et des obstacles. Es-tu seulement humain ?";
			link.l1.go = "BS_F3_50";
		break;

		case "BS_F3_50":	//Флинт.
			dialog.text = "Les émotions sont déplacées, la morale est un signe de faiblesse, le compromis est le chemin de la médiocrité. Mon but, c'est un monde nouveau. Et pour en bâtir un nouveau, il faut briser l'ancien. Tu aurais pu être un instrument utile, mais je vois en toi des sentiments irrationnels qui nuiront à ton efficacité. Soit. Ce sera un peu plus difficile, mais rien n'est impossible !";
			link.l1 = "Tais-toi et crève !";
			link.l1.go = "BS_F3_50exit";
		break;

		case "BS_F3_50exit":	//Флинт.
			LAi_KillCharacter(NPChar);
			LAi_SetPlayerType(pchar);
			LAi_EnableReload();
			Log_SetActiveAction("Reload");
			SetFunctionExitFromLocationCondition("BS_Hangover_CapeCatocheBattleOver", pchar.location, false);
			SetFunctionLocationCondition("BS_Hangover_CapeCatocheDialogue", "Shore6", false);
			Log_Info("Un livre attire votre attention : les « Pensées pour moi-même » de Marc Aurèle. Vous le prenez, ainsi que le journal de bord de Flint.");
		break;

			
		//Файт. На трупе Нарвал, книга Марк Аврелий «Размышления». В сундуке 5кк денег, судовой журнал Флинта (зашифрованый).
		//Как только закрываем окно захвата корабля - СЮРПРИЗ. Спаун "Скарборо" с парой фрегатов. Бой, без диалогов в случае захвата. 7.04.2023 //если не получится такой спавн, то по старинке - спавн на глобалке
		//После победы ТП на берег. Скотс Хэд или второй пляж - не важно 7.04.2023 Фрегат Бонса удаляем, он потонул. На берегу Бонс, Сильвер, ГГ.
		
		case "BS_F3_50BonsDeck":	//Флинт.
			dialog.text = "Réglons enfin son compte à ce salaud !";
			link.l1 = " ! Oui !";
			link.l1.go = "BS_F3_50BonsDeckexit";
		break;
		
		case "BS_F3_50BonsDeckexit":
			DialogExit();
			npchar.dialog.filename = "Quest\BlackSails\BS_Final_3.c";
			npchar.dialog.currentnode = "BS_F3_50BonsDeck_loop";
		break;
		
		case "BS_F3_50BonsDeck_loop":	//Бонс.
			dialog.text = "Réglons enfin son compte à ce salaud !";
			link.l1 = " ! Oui !";
			link.l1.go = "BS_F3_50BonsDeckexit";
		break;
		
		case "BS_F3_51":	//Сильвер.
			dialog.text = "Flint est mort ?";
			link.l1 = "Mort.";
			link.l1.go = "BS_F3_52_1";
		break;
		
		case "BS_F3_52_1":
			LAi_SetStayTypeNoGroup(npchar);
			npchar.dialog.filename = "Quest\BlackSails\BS_Final_3.c";
			npchar.dialog.currentnode = "BS_F3_54";
			StartInstantDialog("BSBons", "BS_F3_52", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_52":	//Бонс.
			dialog.text = "Hé. Dommage. On aurait été ravi de le voir vivant à Londres.";
			link.l1 = "Après tout ce qui s'est passé, je pense qu'on sera ravi de TE voir à Londres, toi aussi !";
			link.l1.go = "BS_F3_53";
		break;

		case "BS_F3_53":	//Бонс.
			dialog.text = "Je crois, oui. Francis Newm, esquire, est mort en héros, et un obscur commandant a survécu. Je n'ai pas du tout envie de répondre aux questions qui vont se poser !";
			link.l1 = "Vous deux ! Voici les papiers de Flint, chiffrés. Vous arriverez à vous en sortir ? Moi, je vais m'allonger ici et me reposer. J'en ai assez de tuer."; //Отдаём книгу, журнал.
			link.l1.go = "BS_F3_53exit";
		break;
		
		case "BS_F3_53exit":	//Бонс.
			DialogExit();
			Lai_SetActorTypeNoGroup(npchar);
			WaitDate("",0,0,0,10,0);
			AddQuestRecord("BSHangover", "69");
			SetLaunchFrameFormParam("Dix heures ont passé", "", 0.1, 3.0);
			DoQuestFunctionDelay("SilverSpeech", 3.0);
			LaunchFrameForm();
		break;

		//Запись в СЖ: "Где-то на этом пути я сделал(ла) неправильный выбор. Какой момент стал поворотным? Элеонора, Чарльз. Как бы сложились их судьбы, прими я другие решения? Стал(ла) бы я бездушной машиной под руководством Флинта? Чёрт, как голова болит! Нужно отдохнуть".
		//Ставим табличку "Прошло десять часов", мотаем время.

		case "BS_F3_54":	//Сильвер.
			dialog.text = "Hé ! Tu es en vie ? Tu es un champion du ronflement !";
			link.l1 = "Quoi ? Alors, ça avance ?";
			link.l1.go = "BS_F3_55_1";
		break;
		
		case "BS_F3_55_1":
			StartInstantDialog("BSBons", "BS_F3_55", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_55":	//Бонс.
			dialog.text = "Deux feuilles de coordonnées. Latitude, longitude. C'est tout. Pas de « Sept pas depuis l'arbre mort », rien !";
			link.l1 = "Comment pensait ce démon, comment fonctionnait sa tête, ça dépasse l'entendement.";
			link.l1.go = "BS_F3_56";
		break;

		case "BS_F3_56":	//Бонс.
			dialog.text = "C'est peut-être un itinéraire ? Mais oם sont le début et la fin ? Il y a des centaines de points sur la carte ! Il doit y avoir un lien ! Forcément ! Il suffit de réfléchir, de relire ce satané livre, il doit bien y avoir quelque chose !";
			link.l1 = "Oם dois-je vous déposer ?";
			link.l1.go = "BS_F3_57_1";
		break;
		
		case "BS_F3_57_1":
			StartInstantDialog("BS_Silver", "BS_F3_57", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_57":	//Сильвер.
			dialog.text = "Quoi ? Tu abandonnes ?";
			link.l1 = "Puerto Príncipe ? Nous ne sommes pas loin de Cuba.";
			link.l1.go = "BS_F3_58_1";
		break;
		
		case "BS_F3_58_1":
			StartInstantDialog("BSBons", "BS_F3_58", "Quest\BlackSails\BS_Final_3.c");
		break;

		case "BS_F3_58":	//Бонс.
			dialog.text = "Oui, Puerto Príncipe, ça me va. J'y ai une petite cachette. דa suffira pour un moment.";
			link.l1 = "Alors, en route.";
			link.l1.go = "BS_F3_58exit";
		break;
		
		case "BS_F3_58exit":	//Бонс.
			DialogExit();
			DeleteAttribute(pchar, "BSBonsAccept");
			DeleteAttribute(pchar, "BonsFlintRunning");
			chrDisableReloadToLocation = false;
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", -1);			
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
			pchar.BSBonsSpawned = true;
			BSBons_SeaBattle(true);
			SetFunctionLocationCondition("BS_CubaSilverOut", "PuertoPrincipe_port", false);
			DeleteAttribute(PChar, "currentsoundtrack");
			string shore = "Shore6";
			Locations[FindLocation(shore)].DisableEncounters = false;
			LAi_LocationFightDisable(&Locations[FindLocation(shore)], false);
			LAi_LocationDisableOfficersGen(shore, false);
		break;

		//Везём братву на Кубу. В бухте Ла Франсуа подходит Сильвер.

		case "BS_F3_59":	//Сильвер.
			dialog.text = "Je vais garder un œil sur Billy, j'ai l'impression qu'il n'a plus toute sa tête. Et toi, oם vas-tu ?";
			link.l1 = "Je vais essayer de sauver Max. Je vais passer à la prison. Au moins, j'aurai fait une chose bien. Bonne chance, John !";
			link.l1.go = "BS_F3_59exit";
		break;
		
		case "BS_F3_59exit":	//Сильвер.
			DialogExit();
			chrDisableReloadToLocation = false;
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "goto", "goto6", "none", "", "", "", -1);
			pchar.ToHelpMaksInPortRoyal = true;
		break;

		//Плывём в Порт Рояль, идём в тюрягу, комендант.

		case "BS_F3_60":	//Комендант.
			dialog.text = "C'est à quel sujet ?";
			link.l1 = "Je voulais m'enquérir du sort d'une certaine personne. Maxine.";
			link.l1.go = "BS_F3_61";
		break;

		case "BS_F3_61":	//Комендант.
			dialog.text = "Ah, madame ! Elle va bien. On l'a gardée en cage deux ou trois jours, puis un messager est venu de la part du gouverneur lui-même avec une grâce. Et on l'a laissée partir, à la grâce de Dieu !";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//Идём в бордель. Комната мадам.

		case "BS_F3_62":	//ГГ
			dialog.text = "" ;
			link.l1 = "Je n'espérais plus te revoir vivante !";
			link.l1.go = "BS_F3_63";
		break;
		
		case "BS_F3_63":	//ГГ
			dialog.text = "Mon capitaine ! Tant que mes filles recueillent des rumeurs, je ne risque rien. Je les partage généreusement avec les autorités comme avec les corsaires. Tout le monde est prêt à prendre ma défense.";
			link.l1 = "Eh bien. Alors ma mission est accomplie. Voici ta part, associée. C'est tout ce que nous avons pu retrouver de l'or de l'Urca.";
			link.l1.go = "BS_F3_64";			
		break;

		case "BS_F3_64":	//ГГ.
			dialog.text = "Je ne vais pas refuser. D'autant que j'ai des dépenses à prévoir. J'ai obtenu la permission d'offrir à Eleanor une sépulture décente. Et j'enverrai de l'argent à Anne. Tu as entendu parler de Jack ?";
			link.l1 = "Oui. Flint est mort, Vane est mort.";
			link.l1.go = "BS_F3_65";
			if (sti(pchar.money) >= 1000000)
			{
				pchar.makslover = true;
				SaveCurrentQuestDateParam("MaksLoverDateDay");
			}
			AddMoneyToCharacter(PChar, -1000000);
		break;

		case "BS_F3_65":	//ГГ.
			dialog.text = "L'histoire est terminée ?";
			link.l1 = "Cette histoire-là, oui. Il reste bien d'autres histoires à raconter. Adieu, Max !";
			link.l1.go = "BS_F3_66";
		break;

		case "BS_F3_66":	//ГГ.
			dialog.text = "Viens me voir, capitaine, de temps en temps.";
			link.l1 = "Sans faute !";
			link.l1.go = "BS_F3_66exit";
		break;
		
		case "BS_F3_66exit":	//ГГ.
			DialogExit();
			SetFunctionLocationCondition("BS_PortRoyalSilver", "PortRoyal_town", false);
			RestoreOldDialog(npchar);
		break;

		//Уходим в закат. Макс – остаётся в роли мадам, с бесплатными потрахушками. Можно ей добавить слухов по «Лёгкой добыче».
		//На выходе из борделя – подбегает Сильвер


		case "BS_F3_67":	//Сильвер.
			dialog.text = "Bones a trouvé le lien ! Ce sont vraiment des points d'itinéraire ! Et lui seul a la carte !";
			link.l1 = "La carte de l'île au trésor du capitaine Flint ?";
			link.l1.go = "BS_F3_68";
		break;


		case "BS_F3_68":	//Сильвер.
			dialog.text = "Oui ! Mais il a filé. Il s'est volatilisé. Disparu avec la carte ! Il faut le retrouver !";
			link.l1 = "דa, c'est ton histoire, John. Tiens, voilà un peu d'argent. Achète-toi une coquille de noix et poursuis Billy Bones jusqu'en Angleterre s'il le faut !"; //отдаём 25к
			link.l1.go = "BS_F3_69";
		break;

		case "BS_F3_69":	//Сильвер.
			dialog.text = "Mais... Tu ne plaisantes pas ?! Je vois que non. Je te retrouverai, c'est promis ! Oh, on va faire la fête avec l'argent de Flint !";
			link.l1 = "Fiche le camp, Silver !";
			link.l1.go = "BS_F3_69exit";
			AddMoneyToCharacter(PChar, -25000);
		break;
		
		case "BS_F3_69exit":	//Сильвер.
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "goto", "goto4", "none", "", "", "", 2.0);
			DoQuestFunctionDelay("BS_SecondFinalEndingQuest", 3.0);
			SetMusic("Theme_from_Black_Sails");
		break;

		//Квест уходит в архив.
	}
}
