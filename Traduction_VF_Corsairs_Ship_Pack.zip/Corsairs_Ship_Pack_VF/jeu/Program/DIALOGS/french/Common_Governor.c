// boal 25/04/04 общий диалог Governor
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Governor\" + NationShortName(sti(NPChar.nation)) + "_Governor.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}

	int Matheria1 = 4000;//шёлк
	int Matheria2 = 3000;//красное
	int Matheria3 = 2000;//чёрное
	int BuildPrice = 3000000;

    // вызов диалога по городам <--

    ref offref, sld;
    int i, cn;
    int qty;
    int iSumm;
    string attrLoc;

    /// выкуп колонии
    ref CaptGovenor, FortColony;
    int f, colony_money;

    int k = 1000;
    if (CheckAttribute(Nations[sti(NPChar.nation)], "Fort"))
    {
        k = (300 - sti(Nations[sti(NPChar.nation)].Fort)*10);
    }
	bool ok;

	attrLoc = Dialog.CurrentNode;
	if (findsubstr(attrLoc, "CityGive_" , 0) != -1)
 	{
        i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.quest.CityIdx = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 	    Dialog.CurrentNode = "ColonyGive";
 	}

	switch (Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOff");
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "arest":
			dialog.text = "Gardes ! Après "+ GetSexPhrase("lui", "elle") +" !";
			link.l1 = "Ah non ! Vous ne m'aurez pas comme ça !";
		    link.l1.go = "fight";
		break;

		case "Patent_Doubt":
			dialog.text = "Joli boniment... Je devrais vous faire pendre rien que pour votre impertinence. On ne peut pas se fier à des pirates aussi notoires, mais les temps sont durs dans notre archipel et toute aide sera utile. Soit, je vais vous signer une lettre de marque, ainsi qu'une grâce. Ne me le faites pas regretter.";
			link.l1 = "Vous ne le regretterez pas, " + GetAddress_FormToNPC(NPChar) + " !";
			link.l1.go = "Patent_Give";
			link.l2 = "Ha ! Vous y avez cru ! C'était une plaisanterie, je ne veux rien avoir à faire avec votre וtat de rien du tout.";
			link.l2.go = "arest_3";
		break;
		case "Patent_Give":
            pchar.PatentNation = NationShortName(sti(NPChar.nation));
            pchar.PatentPrice = 0;
			dialog.text = "Je vous en prie, j'espère que nous continuerons à collaborer. Passez me voir de temps en temps. J'aurai peut-être des missions importantes pour vous.";
			link.l1 = "Merci. Au revoir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			AddDialogExitQuest("any_patent_take");
			ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", -100);
		break;

		case "First time":
            NextDiag.TempNode = "First time";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("Vous osez venir chez le gouverneur général ?! Quelle audace...", "Comment ces fainéants ont-ils pu laisser l'ennemi entrer chez moi ?! C'est à n'y pas croire...", "Eh bien, ma sécurité ne vaut pas grand-chose, si "+ GetSexPhrase("un quelconque vagabond","une quelconque vagabonde") +" court partout dans ma résidence..."),
					LinkRandPhrase("Que voulez-vous, "+ GetSexPhrase("gredin","gredine") +" ?! Mes soldats sont déjà sur vos traces, vous n'irez pas loin, sale pirate !", "Sale assassin, hors de ma résidence ! Gardes !!", "Je n'ai pas peur de vous, gredin ! On vous pendra bientכt au fort, vous n'irez pas loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Vos soldats ne valent pas grand-chose...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, mon vieux, ou je t'arrache ta sale langue !", "Je vais te dire une chose, mon vieux : reste tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			if (sti(NPChar.nation) != PIRATE && ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0) > 15)
            {
                dialog.text = "Oh ! " + GetFullName(pchar) + " ! Nous venons justement d'envoyer des chasseurs de primes vous chercher. Et vous savez, cela nous a déjà coמté une jolie somme.";
                if (sti(NPChar.nation) != PIRATE && ChangeCharacterHunterScore(Pchar, NationShortName(sti(NPChar.nation)) + "hunter", 0) == 100 && !isMainCharacterPatented())
				{
				link.l3 = "Vous avez vu ce que je fais de mes ennemis ; imaginez maintenant les services que je peux rendre à votre pays en tant qu'allié. Je ne le propose qu'une fois, ici et maintenant : donnez-moi une lettre de marque, et tous vos ennemis deviendront les miens.";
				link.l3.go = "Patent_Doubt";
				}
				link.l2 = "Euh... Je crois que je vais y aller.";
				link.l2.go = "arest";
				break;
            }
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
    			dialog.text = "L'ennemi est dans la résidence ! Alerte !!";
				link.l1 = "Ah, diable !";
				link.l1.go = "fight";
				break;
			}

			if (npchar.quest.meeting == "0")
			{
				dialog.text = "J'ai entendu dire que vous aviez beaucoup insisté pour obtenir une audience. Je m'appelle " + GetFullName(npchar) +
                              ". Je suis le gouverneur général des colonies de " + NationNameGenitive(sti(NPChar.nation))+ " et le vice-roi de " + NationKingsName(npchar)+
                              " dans ces eaux. Maintenant, veuillez m'informer du but de votre visite, " + GetAddress_Form(NPChar) + ".";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
				link.l1.go = "node_1";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = RandPhraseSimple("Oh, c'est encore vous ? Pour quelle affaire aviez-vous besoin du gouverneur général de " + NationNameGenitive(sti(NPChar.nation))+ " cette fois ?",
                              "Vous me dérangez encore dans d'importantes affaires d'וtat ? Que voulez-vous, " +GetAddress_Form(NPChar)+" ?");
				link.l1 = "Je voudrais parler d'un travail au service de " + NationNameGenitive(sti(NPChar.nation)) + ".";
				link.l1.go = "work";
				link.l2 = "J'ai besoin de vous parler de quelque chose.";
				link.l2.go = "quests"; // файл нации
				link.l10 = "Désolé, mais j'ai à faire.";
				link.l10.go = "exit";

				// Gregg: постройка копии «Солей Руаяль» - ветку ведёт тот губернатор, что принял заказ:
				// quest.answer_1 - заказ принят, Tuning - материалы ещё не сданы, quest.Gave_Ship - корабль уже выдан.
				if (sti(npchar.nation) == FRANCE && CheckAttribute(npchar, "quest.answer_1") && !CheckAttribute(npchar, "quest.Gave_Ship"))
				{
					if (CheckAttribute(npchar, "Tuning"))
					{
						Link.l15 = "א propos des matériaux pour le vaisseau de guerre.";
						link.l15.go = "check_material";
					}
					else
					{
						if (GetQuestPastDayParam("pchar.questTemp.buildSoley") >= 60)
						{
							Link.l15 = "Alors, le vaisseau de guerre est-il prêt ?";
							link.l15.go = "get_ship";
						}
						else
						{
							Link.l15 = "Comment avance la construction ?";
							link.l15.go = "build_ship_wait";
						}
					}
				}
			}
			if(CheckAttribute(npchar,"patent.othertime") && FindCharacterItemByGroup(Pchar, PATENT_ITEM_TYPE) == "")
			{
				link.l16 = "Mes salutations, " + GetFullName(npchar) + ". J'aimerais revenir sur la question de la lettre de marque.";
				link.l16.go = "Other time patent";
			}
		break;

		case "build_ship":
			dialog.Text = "Une idée sensée, même si le trésor n'a pas un sou pour cela. Mais si les matériaux viennent de vous et que vous payez les charpentiers, je m'occuperai du reste.";
			Link.l1 = "D'accord. Que dois-je apporter, et en quelle quantité ?";
			Link.l1.go = "build_ship_1";
			Link.l2 = "Je n'ai ni le temps ni l'argent pour cela.";
			Link.l2.go = "exit";
		break;

		case "build_ship_1":
			dialog.Text = "Pour un vaisseau de guerre royal, il nous faudra "+Matheria2+" unités d'acajou, "+Matheria3+" d'ébène et "+Matheria1+" de soie. La toile et le bordage, nos colonies les fourniront. De votre part : "+BuildPrice+" pièces d'or d'avance, pour les achats, l'embauche et tout le reste.";

			if(makeint(Pchar.money) >= BuildPrice)
			{
				Link.l1 = "D'accord. Voici l'argent ; le reste, je l'apporterai.";
				Link.l1.go = "build_ship_2";
			}
			Link.l2 = "C'est cher. Je m'en passerai.";
			Link.l2.go = "exit";
		break;

		case "build_ship_2":
			AddMoneyToCharacter(Pchar, -BuildPrice);
			dialog.Text = "Alors nous posons la quille. Nous vous attendrons avec la cargaison.";
			npchar.quest.answer_1 = "true";

			NPChar.Tuning.Matherial1 = Matheria1;
			NPChar.Tuning.Matherial2 = Matheria2;
			NPChar.Tuning.Matherial3 = Matheria3;
			// Gregg: TempNode на check_material тут не ставим - иначе до конца сдачи материалов
			// губернатор умеет только спрашивать про них. Вход в ветку - ссылкой из узла "First time".
			AddQuestRecord("Fra_Line_13_BuildSoley", "1");
			AddQuestUserData("Fra_Line_13_BuildSoley", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Fra_Line_13_BuildSoley", "sGoods", "acajou : " + Matheria2 + ", ébène : " + Matheria3 + ", soie : " + Matheria1);
			Link.l1 = "Au revoir.";
			Link.l1.go = "exit";
		break;

		// Gregg: заглушка на срок постройки, чтобы ссылка из "First time" не вела в пустоту
		case "build_ship_wait":
			dialog.Text = "La quille est posée, le reste est l'affaire du chantier. La coque ne sera pas mise à l'eau avant l'heure, quelle que soit notre impatience à tous les deux.";
			link.l1 = "Alors je repasserai plus tard.";
			link.l1.go = "exit";
		break;

		case "check_material":
			// Gregg: расклинивает старые сейвы, где build_ship_2 успел записать сюда TempNode
			// и губернатор больше ни о чём другом говорить не мог.
			NextDiag.TempNode = "First time";
			dialog.Text = "Le chantier est à l'arrêt. Avez-vous apporté ce que je vous ai demandé ?";
			Link.l1 = "Oui, j'ai réussi à en trouver une partie.";
			Link.l1.go = "check_material_1";
			Link.l2 = "Non, j'y travaille encore.";
			Link.l2.go = "Exit";
		break;

		case "check_material_1":

			checkSoleyMatherial(Pchar, NPChar, GOOD_SILK, GOOD_MAHOGANY, GOOD_EBONY);

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");

				dialog.text = "Tout, jusqu'à la dernière planche. Revenez dans quelques mois : la coque ne sera pas mise à l'eau plus tכt.";
				SaveCurrentQuestDateParam("pchar.questTemp.buildSoley");
				NextDiag.TempNode = "First time";
				AddQuestRecord("Fra_Line_13_BuildSoley", "2");
			    link.l1 = "J'attendrai.";
			    link.l1.go = "exit";

			}
			else
			{
				dialog.Text = "Il vous reste encore à apporter : acajou : "+ sti(NPChar.Tuning.Matherial2) + ", ébène : "+ sti(NPChar.Tuning.Matherial3) + ", soie : "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Très bien.";
				link.l1.go = "Exit";
			}
		break;

		case "get_ship":
			// Gregg: без свободного места в эскадре SetCompanionIndex молча вернёт -1, и оплаченный
			// корабль пропадёт. Слот 0 занят самим ГГ, потому сравнение именно с COMPANION_MAX.
			if (GetCompanionQuantity(pchar) >= COMPANION_MAX)
			{
				dialog.text = "Il est prêt et mouille en rade. Seulement, personne ne peut le prendre : votre escadre n'a plus une seule place de libre. Libérez-en une et revenez.";
				link.l1 = "Je m'en occupe.";
				link.l1.go = "Exit";
				break;
			}
			dialog.text = "Il est prêt, en effet. Nous l'avons même essayé contre une escadre pirate. Je l'avoue, je vous envie : il n'y a pas d'autre coque comme celle-là dans ces eaux. Il arbore déjà vos couleurs ; prenez aussi l'officier avec lui : il l'a amené du chantier et le connaît mieux que ceux qui l'ont construit.";
			NextDiag.TempNode = "First time";
			npchar.quest.Gave_Ship = "true";
			AddQuestRecord("Fra_Line_13_BuildSoley", "3");
			CloseQuestHeader("Fra_Line_13_BuildSoley");
			sld = GetCharacter(NPC_GenerateCharacter("SoleiRoyalCaptain1", "off_fra_2", "man", "man", 35, FRANCE, -1, true));
			sld.Ship.Name = "Soleil Royal";
			sld.Ship.Type = GenerateShipExt(SHIP_SOLEYRU, true, sld);
			ResetShipCannonsDamages(sld);
			SetBaseShipData(sld);
			SetCrewQuantityFull(sld);
			SetShipSkill(sld, 50, 60, 70, 55, 95, 55, 50, 55, 50);
			Fantom_SetBalls(sld, "pirate");
			FantomMakeCoolFighter(sld, 35, 80, 70, BLADE_LONG, "pistol3", 100);

			sld.Dialog.TempNode = "hired";
			sld.Dialog.FileName = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			SetBaseShipData(sld);
			sld.CompanionEnemyEnable = false;
			SetCompanionIndex(pchar, -1, sti(sld.index));

			// Gregg: SetBaseShipData выше зовёт SetGoodsInitNull и набивает трюм на своё усмотрение,
			// поэтому команду и припасы королевского мановара выставляем строго после него.
			sld.Ship.Crew.Exp.Sailors   = 95;	// порог "морских волков" в GetExpName() - 90
			sld.Ship.Crew.Exp.Cannoners = 95;
			sld.Ship.Crew.Exp.Soldiers  = 95;
			sld.Ship.Crew.Morale = MORALE_MAX;
			SetCharacterGoods(sld, GOOD_BALLS,      1000);
			SetCharacterGoods(sld, GOOD_GRAPES,     1000);
			SetCharacterGoods(sld, GOOD_KNIPPELS,   1000);
			SetCharacterGoods(sld, GOOD_BOMBS,      1000);
			SetCharacterGoods(sld, GOOD_POWDER,     4000);
			SetCharacterGoods(sld, GOOD_FOOD,       2000);
			SetCharacterGoods(sld, GOOD_WEAPON,     1500);
			SetCharacterGoods(sld, GOOD_MEDICAMENT, 3000);
			SetCharacterGoods(sld, GOOD_RUM,        1000);

			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			//AddDialogExitQuestFunction("LandEnc_OfficerHired");


			link.l1 = "Merci. Je vais l'essayer tout de suite.";
			link.l1.go = "Exit";
		break;

		case "node_1":
			dialog.text = "Alors, quelle raison vous amène ici pour me distraire d'importantes affaires d'וtat ?";
			link.l1 = "Je voudrais parler d'un travail au service de " + NationNameGenitive(sti(NPChar.nation));
			link.l1.go = "work";
			link.l2 = "J'ai besoin de vous parler de quelque chose.";
			link.l2.go = "quests";
			link.l10 = "C'est juste une visite de courtoisie, rien de plus, "+GetAddress_FormToNPC(NPChar);
			link.l10.go = "node_2";
		break;

		case "node_2":
			dialog.text = "Dans ce cas, je vous prierai de quitter mon bureau et de ne pas gêner mon travail.";
			link.l1 = "Oui, oui, bien sמr, désolé de vous avoir dérangé.";
			link.l1.go = "exit";
		break;

		case "work":
            if (!CheckCharacterItem(Pchar, "patent_" + NationShortName(sti(NPChar.nation))) || !CheckAttribute(pchar, "EquipedPatentId"))
			{
    			dialog.text = "Je ne vous connais absolument pas, " + GetAddress_Form(NPChar) + ". Quittez mon bureau. Je ne traite qu'avec les gens qui sont au service de " + NationKingsName(npchar) + ".";
    			link.l1 = "Pardon pour le dérangement. Il me faut d'abord une lettre de marque de "+NationNameGenitive(sti(NPChar.nation))+". Je reviendrai.";
    			link.l1.go = "exit";
			}
			else
			{// даём задание
                // звание подрасло
                if (isReadyToNextTitle(sti(NPChar.nation)))
                {
                    Items[sti(pchar.EquipedPatentId)].TitulCurNext = 0;
                    Items[sti(pchar.EquipedPatentId)].TitulCur = sti(Items[sti(pchar.EquipedPatentId)].TitulCur) + 1;

                    dialog.text = "J'ai une bonne nouvelle pour vous"+ ", " + GetAddress_Form(NPChar)+". La demande de votre promotion a été signée dans le cabinet de " + NationKingsName(npchar) +
                                ". Vous avez reçu le grade de " + GetAddress_FormTitle(sti(NPChar.nation), sti(Items[sti(pchar.EquipedPatentId)].TitulCur)) +
                                " de la marine de " + NationNameGenitive(sti(NPChar.nation)) +".";
        			link.l1 = "Merci ! Je promets de continuer à servir avec honneur "+NationKingsCrown(npchar) + ".";
        			link.l1.go = "exit";
        			break
                }
                // даём задание
                dialog.text = LinkRandPhrase("Avez-vous des questions pour moi, "+GetAddress_FormTitle(sti(NPChar.nation), sti(Items[sti(pchar.EquipedPatentId)].TitulCur))+" ?",
                                             "Je vous écoute, " + GetAddress_Form(NPChar)+".",
                                             "Parlez, je suis tout ouïe.");

				if (pchar.questTemp.NationQuest == "")
                {
	    			if (pchar.questTemp.piratesLine == "begin" || pchar.questTemp.piratesLine == "over" || pchar.questTemp.piratesLine == "waiting_Q8" || pchar.questTemp.LSC == "over")
					{
						link.l1 = "Y a-t-il du travail pour un corsaire muni d'une lettre de marque ?";
	    				link.l1.go = "work_1";
						if (!bWorldAlivePause && pchar.questTemp.State == "") //eddy. только, если не проходил линейку.
						{
							link.l1.go = "onlyGenWork_Alter";
						}
					}
					else
					{
						link.l1 = "Y aurait-il du travail pour un corsaire muni d'une lettre de marque ?";
	    				link.l1.go = "onlyGenWork_2";
					}
    			}
    			else
    			{
    			    if (pchar.questTemp.NationQuest == NPChar.nation)
	                {
		    			link.l1 = RandPhraseSimple("Je viens pour une affaire en rapport direct avec vos missions.", "א propos de vos missions...");
		    			link.l1.go = "work_1";
	    			}
	    			else
	    			{// линейкам - фиг
	    			    link.l1 = "Y a-t-il du travail pour un corsaire muni d'une lettre de marque ?";
	    				link.l1.go = "onlyGenWork_1";
	    			}
    			}

                // Сдача города -->
				if (isHeroOwnCity(false))
				{
				    Link.l2 = "Je souhaite placer sous l'autorité de la Couronne la ville que j'ai prise, au nom de "+ XI_ConvertString(GetNationNameByType(sti(NPChar.nation)) + "Gen") +".";
					Link.l2.go = "colony_capture";
				}
                // Сдача города <--
                link.l9 = RandPhraseSimple("Désolé, je reviendrai plus tard.",
                                           "Rien de grave, "+GetAddress_FormToNPC(NPChar)+". Juste une visite de courtoisie.");
    			link.l9.go = "exit";
			}
		break;

		case "onlyGenWork_1":
			dialog.text = "Hum... J'ai entendu dire que vous accomplissiez des missions secrètes pour "+ NationNameGenitive(sti(pchar.questTemp.NationQuest)) +", je ne pourrai donc plus vous confier quoi que ce soit de secret.";
			link.l1 = "Je le regrette vivement.";
			link.l1.go = "exit";
		break;

		case "onlyGenWork_2":
			dialog.text = "Le bruit court que vous êtes très proche des chefs des Frères de la Cכte. Je ne pense donc pas pouvoir vous confier de travail au profit de " + NationNameGenitive(sti(npchar.nation)) + ".";
			link.l1 = "Hum... Eh bien, c'est dommage.";
			link.l1.go = "exit";
		break;

		case "onlyGenWork_Alter":
   			dialog.text = "Malheureusement pour vous, et heureusement pour moi, je n'ai pas de missions de corsaire risquées et bien payées en ce moment.";
			link.l1 = "Bon, je reviendrai plus tard.";
			link.l1.go = "exit";
		break;

		/////Награда за захваченную колонию.
		case "colony_capture":
   			dialog.text = "De quelle ville parlons-nous ?";
   			for (i=0; i<MAX_COLONIES; i++)
			{
				if (sti(colonies[i].HeroOwn) == true && colonies[i].id != "Caiman")
				{
					sld = GetFortCommander(colonies[i].id);
					attrLoc = "l" + i;
					Link.(attrLoc) = GetCityName(colonies[i].id);
					Link.(attrLoc).go = "CityGive_" + i;
				}
			}
			link.l99 = "Je me suis trompé, il s'agissait d'autre chose.";
			link.l99.go = "exit";
		break;

        case "ColonyGive":
            i = sti(NPChar.quest.CityIdx);
            sld = GetFortCommander(colonies[i].id);
            colony_money = TWN_CityCost(colonies[i].id) / 50;  // те *1000 в итоге
            TWN_RealeseForMoney(colonies[i].id, false);
            dialog.text = "Excellente nouvelle pour vous, "+GetAddress_FormTitle(sti(NPChar.nation), sti(Items[sti(pchar.EquipedPatentId)].TitulCur))+
                          " ! Votre zèle ne passera pas inaperçu, et vous serez bien sמr récompensé. Voici " + colony_money +
                          " pièces d'or en récompense de vos services rendus à "+NationNameAblative(sti(NPChar.nation))+
                          ". Maintenant, si vous voulez bien m'excuser, j'ai beaucoup à faire.";
            link.l1 = "Dans ce cas, " + GetAddress_FormToNPC(NPChar) + ", je ne vous retiens pas plus longtemps. Bonne continuation.";
            link.l1.go = "exit";

            ReOpenQuestHeader("Gen_CityCapture");
		    AddQuestRecord("Gen_CityCapture", "t8");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", GetCityName(colonies[i].id));
			AddQuestUserData("Gen_CityCapture", "sNation", XI_ConvertString(GetNationNameByType(sti(NPChar.nation)) + "Gen"));

            AddMoneyToCharacter(PChar, colony_money);
            AddTitleNextRate(sti(NPChar.nation), 1);  // счётчик звания
            ChangeCharacterNationReputation(Pchar, sti(NPChar.nation), 10);
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(colonies[i].id, sti(NPChar.nation));
        break;

		//*************************** Квест "Orion fluyt accompaniment"Орион"" **********************
        case "Andre_Abel_Quest_Hol_Gov_Node_1":
			//if (GetCityNameByIsland(Pchar.curIslandId) == "Villemstad")
			if (pchar.location == "Villemstad_townhall")
			{
			dialog.text = "Je vous écoute, capitaine.";
			link.l1 = "Je viens de la part d'Henry Morgan, avec pour instruction de vous remettre cette lettre...";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_2";
			TakeItemFromCharacter(PChar, "letter_1");
			Log_TestInfo("The letter has been given to the Governor-General of Curacao.");
			PChar.Quest.Andre_Abel_Quest_Curasao_10Days_Left.over = "yes";
			}
			else
			{
			dialog.text = "Vous me dérangez dans d'importantes affaires d'וtat ? Que voulez-vous, " +GetAddress_Form(NPChar)+" ?";
			link.l1 = "C'est juste une visite de courtoisie, rien de plus, "+GetAddress_FormToNPC(NPChar)".";
			link.l1.go = "exit";
			NextDiag.TempNode = "Andre_Abel_Quest_Hol_Gov_Node_1";
			}
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_2":
			dialog.text = "Hum... de la part de Morgan ? Pourtant... Bon, donnez-moi votre lettre d'Henry Morgan.";
			link.l1 = "Tenez...";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_3";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_3":
			dialog.text = "Quoi ?! Quitter Fort Orange ?! Ah, chiens d'Anglais ! Port Royal ne leur suffit pas, il leur faut l'île entière ! Emparez-vous de "+ GetSexPhrase("ce gredin","cette gredine") +" !";
			link.l1 = "Mynheer ! Je ne suis que "+ GetSexPhrase("le messager","la messagère") +", je ne suis pas responsable du contenu de la lettre !..";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_4";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_4":
			dialog.text = "Vous êtes un homme de Morgan, et vous êtes "+ GetSexPhrase("anglais","anglaise") +". דa suffit !.. Emmenez "+ GetSexPhrase("lui","elle") +" au cachot !";
			link.l1 = "Il faudrait soigner vos nerfs !!!";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_5";
			link.l2 = "Bon, je me plie aux autorités ! Mais je le répète, j'ai la conscience tranquille, et je n'ai rien fait ni rien projeté contre la Hollande qui puisse me valoir des poursuites !";
			link.l2.go = "Andre_Abel_Quest_Hol_Gov_Node_7";
			link.l3 = "Monsieur le gouverneur général, pourquoi m'envoyer directement en prison ?! Je suis sמr que nous pourrions très bien nous arranger...";
			link.l3.go = "Andre_Abel_Quest_Hol_Gov_Node_9";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_5":
			dialog.text = "Comment osez-vous, gredin ! Tuez "+ GetSexPhrase("lui","elle") +", immédiatement !!!";
			link.l1 = "Eh bien, les gardes, accrochez-vous !..";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_6";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_6":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetFightMode(PChar, true);
			Flag_Change(PIRATE);
			LAi_SetImmortal(CharacterFromID("Andre_Abel_Quest_Officer_1"), false);
			sTemp = "hol_guard";
			LAi_group_MoveCharacter(CharacterFromID("Andre_Abel_Quest_Officer_1"), sTemp);
			LAi_group_SetRelation(sTemp, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sTemp, LAI_GROUP_PLAYER, true);
			QuestSetCurrentNode("Henry Morgan", "Andre_Abel_Quest_Morgan_Dialog_16");
			LAi_Group_Attack(PChar, CharacterFromID("hol_guber"));
			AddQuestRecord("Andre_Abel_Quest", "16");
			AddQuestUserData("Andre_Abel_Quest", "sText", "Heureusement, une fois de plus, mon habileté à l'escrime m'a sauvé la mise");
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_7":
			//pchar.questTemp.OrionCity = GetCityNameByIsland(Pchar.curIslandId);
			dialog.text = "Que votre conscience soit tranquille ou non, nous verrons ça plus tard... Emmenez "+ GetSexPhrase("lui","elle") +" !";
			link.l1 = "Voyez ça, mais ne traînez pas. Je n'ai pas beaucoup de temps...";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_8";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_8":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_LocationDisableOfficersGen("Villemstad_prison",true);
			LAi_LocationDisableOfficersGen("Villemstad_fort",true);
			LAi_LocationDisableOfficersGen("Villemstad_ExitTown",true);
			DoFunctionReloadToLocation("Villemstad_prison", "goto", "goto9", "Andre_Abel_Quest_In_Prison");
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_9":
			iSumm = sti(PChar.rank)*20000;
			dialog.text = "S'arranger ? Hum... eh bien, s'il est question d'une somme de " + iSumm + " piastres, je suis prêt à poursuivre la discussion.";
			if(sti(PChar.money) >= iSumm)
			{
				link.l1 = "Parfait ! Je vous avais bien dit que ce serait facile.";
				link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_10";
			}
			link.l2 = "Quoi ?! Vous avez perdu la tête ?! Pour une somme pareille, je ne suis pas comme vos gardes !.. Je vais massacrer tout Curaçao, avec les chevaux du port et les singes de la jungle !!!";
			link.l2.go = "Andre_Abel_Quest_Hol_Gov_Node_5";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_10":
			iSumm = sti(PChar.rank)*20000;
			AddMoneyToCharacter(PChar, -iSumm);
			dialog.text = "Eh bien, c'est parfait. Vous pouvez partir... Mais ne me tombez plus dessus avec ce genre de commission ! Ma générosité n'est pas infinie.";
			link.l1 = "Bien sמr ! Bon séjour...";
			link.l1.go = "Andre_Abel_Quest_Hol_Gov_Node_11";
		break;

		case "Andre_Abel_Quest_Hol_Gov_Node_11":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			QuestSetCurrentNode("Henry Morgan", "Andre_Abel_Quest_Morgan_Dialog_16");
			AddQuestRecord("Andre_Abel_Quest", "16");
			AddQuestUserData("Andre_Abel_Quest", "sText", "Heureusement, une fois de plus, l'argent m'a tiré d'affaire");
		break;
		case "GivePatent":
			dialog.text = "Oh, vous voilà, " + GetFullName(pchar) + ". Je vous attendais !";
			link.l1 = "Mes salutations, cher " + GetFullName(npchar) + ". Merci pour cet accueil si chaleureux. א quoi dois-je cet honneur ?";
			link.l1.go = "Give Money";
			npchar.quest.meeting = "1";//флаг знакомства с губером
		break;
		case "Give Money":
			dialog.text = "Vous avez beaucoup travaillé pour le bien de notre וtat. Je veux vous proposer de devenir corsaire au service de " + NationNameGenitive(sti(NPChar.nation))+".";
			link.l1 = "J'accepte volontiers votre offre.";
			link.l2 = "Désolé, mais je dois refuser."
			link.l1.go = "Accept";
			link.l2.go = "Refuse";
		break;
		case "Accept":
			dialog.text = "Parfait ! Voici votre lettre de marque, j'espère que votre service vous apportera encore plus de victoires et de gloire !";
			link.l1 = "";
			link.l1.go = "Exit";
			pchar.PatentNation = NationShortName(sti(npchar.nation));
			GiveItem2Character(pchar, "patent_" + pchar.PatentNation);
			EquipCharacterbyItem(pchar, "patent_" + pchar.PatentNation);
			if(CheckAttribute(npchar,"patent.othertime")) DeleteAttribute(npchar,"patent.othertime"));
		break;
		case "Refuse":
			dialog.text = "Quel dommage, quel dommage... Mais ce n'est rien, je suis sמr que vous trouverez votre voie ailleurs ! Vous pourrez revenir me voir si vous changez d'avis, souvenez-vous-en.";
			link.l1 = "Merci, je garderai cette possibilité à l'esprit.";
			link.l1.go = "Exit";
			npchar.patent.othertime = true;
		break;
		case "Other time patent":
			dialog.text = "Oh, vous voilà de retour. Vous avez décidé que vous vouliez quand même une lettre de marque ?";
			link.l1 = "Oui, j'ai décidé d'accepter votre offre.";
			link.l2 = "Je vais encore y réfléchir, au revoir.";
			link.l1.go = "Accept";
			link.l2.go = "Refuse";
		break;
	}
}

void checkSoleyMatherial(ref Pchar, ref NPChar, int good1, int good2, int good3)
{
    int amount;

    amount = GetSquadronGoods(Pchar, good1) - sti(NPChar.Tuning.Matherial1);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial1);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial1);
    }
    RemoveCharacterGoods(Pchar, good1, amount);
    NPChar.Tuning.Matherial1 = sti(NPChar.Tuning.Matherial1) - amount;

    amount = GetSquadronGoods(Pchar, good2) - sti(NPChar.Tuning.Matherial2);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial2);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial2);
    }
    RemoveCharacterGoods(Pchar, good2, amount);
    NPChar.Tuning.Matherial2 = sti(NPChar.Tuning.Matherial2) - amount;


    amount = GetSquadronGoods(Pchar, good3) - sti(NPChar.Tuning.Matherial3);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial3);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial3);
    }
    RemoveCharacterGoods(Pchar, good3, amount);
    NPChar.Tuning.Matherial3 = sti(NPChar.Tuning.Matherial3) - amount;

}
