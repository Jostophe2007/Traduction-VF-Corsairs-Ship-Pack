#include "scripts\utils.c"

// boal -->
#define MAX_TITLENEXTRATE   13 // счетчик для званий
#define MAX_TITLE           5
// boal <--

object Address_Form;

void Set_inDialog_Attributes()
{
	ref The_Character_is;
	The_Character_is = GetMainCharacter();
	if (LanguageGetLanguage() != "russian")
	{
		if (!CheckAttribute(The_Character_is, "sex") || The_Character_is.sex == "man" || The_Character_is.sex == "skeleton")
		{
			Address_Form.Spa = "senor";
			Address_Form.Fra = "monsieur";
			Address_Form.Eng = "sir";
			Address_Form.Hol = "mynheer";
			Address_Form.Pir = "sir";
    	}
    	else
    	{
			Address_Form.Spa = "senorita";
			Address_Form.Fra = "mademoiselle";
			Address_Form.Eng = "miss";
			Address_Form.Hol = "mefrau";
			Address_Form.Pir = "miss";
		}
		Address_Form.Spa.Title1 = "Corsair";
		Address_Form.Fra.Title1 = "Privateer";
		Address_Form.Eng.Title1 = "Caper";
		Address_Form.Hol.Title1 = "Filibuster";
		Address_Form.Pir.Title1 = "Pirate";

    	Address_Form.Spa.Title2 = "Commander";
		Address_Form.Fra.Title2 = "Commander";
		Address_Form.Eng.Title2 = "Commander";
		Address_Form.Hol.Title2 = "Commander";
		Address_Form.Pir.Title2 = "Commander";

		Address_Form.Spa.Title3 = "Captain";
		Address_Form.Fra.Title3 = "Captain";
		Address_Form.Eng.Title3 = "Captain";
		Address_Form.Hol.Title3 = "Captain";
		Address_Form.Pir.Title3 = "Captain";

		Address_Form.Spa.Title4 = "Commodore";
		Address_Form.Fra.Title4 = "Commodore";
		Address_Form.Eng.Title4 = "Commodore";
		Address_Form.Hol.Title4 = "Commodore";
		Address_Form.Pir.Title4 = "Commodore";

		Address_Form.Spa.Title5 = "Admiral";
		Address_Form.Fra.Title5 = "Admiral";
		Address_Form.Eng.Title5 = "Admiral";
		Address_Form.Hol.Title5 = "Admiral";
		Address_Form.Pir.Title5 = "Admiral";

		Address_Form.Spa.woman = "senora";
		Address_Form.Fra.woman = "madam";
		Address_Form.Eng.woman = "missis";
		Address_Form.Hol.woman = "frau";
		Address_Form.Pir.woman = "missis";

		Address_Form.Spa.man = "senor";
		Address_Form.Fra.man = "monsieur";
		Address_Form.Eng.man = "sir";
		Address_Form.Hol.man = "mynheer";
		Address_Form.Pir.man = "sir";
	}
	else
	{

    	if (!CheckAttribute(The_Character_is, "sex") || The_Character_is.sex == "man" || The_Character_is.sex == "skeleton")
		{
			Address_Form.Spa = "сеньор";
			Address_Form.Fra = "месье";
			Address_Form.Eng = "сэр";
			Address_Form.Hol = "минхер";
			Address_Form.Pir = "сэр";
    	}
    	else
    	{
			Address_Form.Spa = "сеньорита";
			Address_Form.Fra = "мадмуазэль";
			Address_Form.Eng = "мисс";
			Address_Form.Hol = "мефрау";
			Address_Form.Pir = "мисс";
		}
		Address_Form.Spa.Title1 = "Корсар";
		Address_Form.Fra.Title1 = "Приватир";
		Address_Form.Eng.Title1 = "Капер";
		Address_Form.Hol.Title1 = "Флибустьер";
		Address_Form.Pir.Title1 = "Пират";

    	Address_Form.Spa.Title2 = "Коммандер";
		Address_Form.Fra.Title2 = "Коммандер";
		Address_Form.Eng.Title2 = "Коммандер";
		Address_Form.Hol.Title2 = "Коммандер";
		Address_Form.Pir.Title2 = "Коммандер";

		Address_Form.Spa.Title3 = "Капитан";
		Address_Form.Fra.Title3 = "Капитан";
		Address_Form.Eng.Title3 = "Капитан";
		Address_Form.Hol.Title3 = "Капитан";
		Address_Form.Pir.Title3 = "Капитан";

		Address_Form.Spa.Title4 = "Коммодор";
		Address_Form.Fra.Title4 = "Коммодор";
		Address_Form.Eng.Title4 = "Коммодор";
		Address_Form.Hol.Title4 = "Коммодор";
		Address_Form.Pir.Title4 = "Коммодор";

		Address_Form.Spa.Title5 = "Адмирал";
		Address_Form.Fra.Title5 = "Адмирал";
		Address_Form.Eng.Title5 = "Адмирал";
		Address_Form.Hol.Title5 = "Адмирал";
		Address_Form.Pir.Title5 = "Адмирал";

		Address_Form.Spa.woman = "сеньора";
		Address_Form.Fra.woman = "мадам";
		Address_Form.Eng.woman = "миссис";
		Address_Form.Hol.woman = "мефрау";
		Address_Form.Pir.woman = "миссис";

		Address_Form.Spa.man = "сеньор";
		Address_Form.Fra.man = "месье";
		Address_Form.Eng.man = "сэр";
		Address_Form.Hol.man = "минхер";
		Address_Form.Pir.man = "сэр";
	}
}

// boal -->

string RandSwear()
{
	if (LanguageGetLanguage() != "russian")
	{
		switch (rand(14))
		{
			case 0:
				return FrS("Karamba! ", "Caramba ! ");
			break;

			case 1:
				return FrS("Damn it! ", "Bon sang ! ");
			break;

			case 2:
				return FrS("Devil! ", "Diable ! ");
			break;

			case 3:
				return FrS("Damn! ", "Sacrebleu ! ");
			break;

			case 4:
				return FrS("Anchor me in the the... ", "Nom d'une ancre rouillée... ");
			break;

			case 5:
				return FrS("A thousand sharks! ", "Mille requins ! ");
			break;

			case 6:
				return FrS("Argkh!!! ", "Argh !!! ");
			break;

			case 7:
				return FrS("A thousand devils! ", "Mille diables ! ");
			break;

			case 8:
				return FrS("Alle Hagel! ", "Mille sabords ! "); // the campдартное пиратское "твою мать"
			break;
			case 9:
				return FrS("Thunder blast me! ", "Tonnerre de Brest ! ");
			break;

			case 10:
				return FrS("Ar-g, your mizzen! ", "Argh, par l'artimon ! ");
			break;

			case 11:
				return FrS("Oh, damn you... ", "Oh, maudit sois-tu... ");
			break;

			case 12:
				return FrS("A dozen sharks! ", "Par douze requins ! ");
			break;

			case 13:
				return FrS("Bite me herring! ", "Hareng saur ! ");
			break;

			case 14:
				return FrS("Three thousand devils! ", "Trois mille diables ! ");
			break;
		}
	}
	else
	{
		switch (rand(14))
		{
			case 0:
				return "Карамба! ";
			break;

			case 1:
				return "Проклятье! ";
			break;

			case 2:
				return "Дьявол! ";
			break;

			case 3:
				return "Чёрт! ";
			break;

			case 4:
				return "Якорь мне в ... ";
			break;

			case 5:
				return "Тысяча акул! ";
			break;

			case 6:
				return "Аргкх!!! ";
			break;

			case 7:
				return "Тысяча чертей! ";
			break;

			case 8:
				return "Алле Хагель! ";	// стандартное пиратское "твою мать"
			break;
			case 9:
				return "Разрази меня гром! ";
			break;

			case 10:
				return "Ар-х, твою бизань! ";
			break;

			case 11:
				return "А, чтоб тебя... ";
			break;

			case 12:
				return "Дюжина акул! ";
			break;

			case 13:
				return "Укуси меня селёдка! ";
			break;

			case 14:
				return "Три тысячи чертей! ";
			break;
		}
	}
}

//navy --> вынес простые восклицания,
//т.к. "О, Боже!!! Я вырежу тебе сердце" звучит мягко говоря странно :)
string RandExclamation()
{
	if (LanguageGetLanguage() != "russian")
	{
		switch(rand(2))
		{
			case 0:
				return FrS("Oh, my God!! ", "Oh, mon Dieu !! ");
			break;

			case 1:
				return FrS("Oh, heavens! ", "Ciel ! ");
			break;

			case 2:
				return FrS("Holy Madonna! ", "Sainte Madone ! ");
			break;
		}
	}
	else
	{
		switch(rand(2))
		{
			case 0:
				return "О, Боже!! ";
			break;

			case 1:
				return "О, Небеса! ";
			break;

			case 2:
				return "Святая Мадонна! ";
			break;
		}
	}
}
//navy <--
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                Выбор фраз для диалога
////////////////////////////////////////////////////////////////////////////////////////////////////////
// boal 13.03.2004 -->
string IfPhraseSimple(bool cond, string v1, string v2)
{
	if (cond) return v1;
	else return v2;
}

string RandPhraseSimple(string Var1, string Var2);
{
	int RandP;
	RandP = Rand(1);
	switch(RandP)
	{
		case 0:
			return Var1;
		break;

		case 1:
			return Var2;
		break;
	}
	return "ERROR";
}
// выбор фразы из трёх
string LinkRandPhrase (string Var1, string Var2, string Var3)
{
	int RandP;
	RandP = Rand(2);
	switch(RandP)
	{
		case 0:

			return Var1;

		break;

		case 1:

			return Var2;

		break;

		case 2:

			return Var3;

		break;
	}
	return "ERROR";
}

string LinkRandArrayPhrase (int z)
{
	return rand_arr[prand(z)];
}

string NationKingsCrown(ref Character)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(sti(Character.nation))
		{
			case ENGLAND: return "le trכne d'Angleterre"; break;
			case FRANCE: return "la Couronne de France"; break;
			case SPAIN: return "la Couronne d'Espagne"; break;
			case HOLLAND: return "le royaume des Pays-Bas"; break;
			case PIRATE: return "la Confrérie de la Cכte"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(sti(Character.nation))
		{
			case ENGLAND:
        	    return "the English Throne";
			break;
			case FRANCE:
        	    return "the French Crown";
			break;
			case SPAIN:
        	    return "the Spanish Crown";
			break;
			case HOLLAND:
				return "the Kingdom of the Netherlands";
			break;
			case PIRATE:
				return "the Brethren";
			break;
		}
	}
	else
	{
    	switch(sti(Character.nation))
		{
			case ENGLAND:
    	        return "Английскому престолу";
			break;
			case FRANCE:
    	        return "Французской короне";
			break;
			case SPAIN:
    	        return "Испанской короне";
			break;
			case HOLLAND:
				return "Королевству Нидерланды";
			break;
			case PIRATE:
				return "Береговому братству";
			break;
		}
	}
}
string NationKingsName(ref NPChar)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(sti(NPChar.nation))
		{
			case ENGLAND: return "Sa Majesté Charles II Stuart"; break;
			case FRANCE: return "Sa Majesté Louis XIV"; break;
			case SPAIN: return "Sa Majesté Catholique Charles II de Habsbourg"; break;
			case HOLLAND: return "Sa Majesté Guillaume III d'Orange"; break;
			case PIRATE: return "la Confrérie de la Cכte"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(sti(NPChar.nation))
		{
			case ENGLAND:
    	        return "His Majesty Charles II Stuart";
			break;
			case FRANCE:
    	        return "His Majesty Louis XIV";
			break;
			case SPAIN:
    	        return "His Catholic Majesty Charles II of Habsburg";
			break;
			case HOLLAND:
				return "His Majesty William III of Orange";
			break;
			case PIRATE:
				return "Brethren";
			break;
		}
	}
	else
	{
    	switch(sti(NPChar.nation))
		{
			case ENGLAND:
    	        return "Его Величества Карла II Стюарта";
			break;
			case FRANCE:
    	        return "Его Величества Людовика XIV";
			break;
			case SPAIN:
    	        return "Его Католического Величества Карла II Габсбурга";
			break;
			case HOLLAND:
				return "Его Величества Вильгельма III Оранского";
			break;
			case PIRATE:
				return "берегового пиратского братства";
			break;
		}
	}
}

string NationNameMan(int pNation)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(pNation)
		{
			case ENGLAND: return "Anglais"; break;
			case FRANCE: return "Français"; break;
			case SPAIN: return "Espagnol"; break;
			case HOLLAND: return "Hollandais"; break;
			case PIRATE: return "pirate"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(pNation)
		{
			case ENGLAND:
    		    return "englishman";
			break;
			case FRANCE:
    		    return "franchman";
			break;
			case SPAIN:
    		    return "spainman";
			break;
			case HOLLAND:
				return "dutchman";
			break;
			case PIRATE:
				return "pirate";
			break;
		}
	}
	else
	{
		switch(pNation)
		{
			case ENGLAND:
    	        return "англичанин";
			break;
			case FRANCE:
    	        return "француз";
			break;
			case SPAIN:
    	        return "испанец";
			break;
			case HOLLAND:
				return "голландец";
			break;
			case PIRATE:
				return "пират";
			break;
		}
	}
}
// boal 13.03.2004 <--
string NationNamePeople(int pNation)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(pNation)
		{
			case ENGLAND: return "les Anglais"; break;
			case FRANCE: return "les Français"; break;
			case SPAIN: return "les Espagnols"; break;
			case HOLLAND: return "les Hollandais"; break;
			case PIRATE: return "les pirates"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(pNation)
		{
			case ENGLAND:
    	        return "englishmen";
			break;
			case FRANCE:
    	        return "franchmen";
			break;
			case SPAIN:
    	        return "spainmen";
			break;
			case HOLLAND:
				return "dutchmen";
			break;
			case PIRATE:
				return "pirates";
			break;
		}
	}
	else
	{
		switch(pNation)
		{
			case ENGLAND:
    	        return "англичане";
			break;
			case FRANCE:
    	        return "французы";
			break;
			case SPAIN:
    	        return "испанцы";
			break;
			case HOLLAND:
				return "голландцы";
			break;
			case PIRATE:
				return "пираты";
			break;
		}
	}
}

string NationNamePeopleAcc(int pNation)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(pNation)
		{
			case ENGLAND: return "les Anglais"; break;
			case FRANCE: return "les Français"; break;
			case SPAIN: return "les Espagnols"; break;
			case HOLLAND: return "les Hollandais"; break;
			case PIRATE: return "les pirates"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(pNation)
		{
			case ENGLAND:
    	        return "englishmen";
			break;
			case FRANCE:
    	        return "franchmen";
			break;
			case SPAIN:
    	        return "spainmen";
			break;
			case HOLLAND:
				return "dutchmen";
			break;
			case PIRATE:
				return "pirates";
			break;
		}
	}
	else
	{
		switch(pNation)
		{
			case ENGLAND:
    	        return "англичанами";
			break;
			case FRANCE:
    	        return "французами";
			break;
			case SPAIN:
    	        return "испанцами";
			break;
			case HOLLAND:
				return "голландцами";
			break;
			case PIRATE:
				return "паратами";
			break;
		}
	}
}

string NationNameAblative(int iNation) //творительный падеж
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(iNation)
		{
			case ENGLAND: return "l'Angleterre"; break;
			case FRANCE: return "la France"; break;
			case SPAIN: return "l'Espagne"; break;
			case HOLLAND: return "la Hollande"; break;
			case PIRATE: return "les pirates"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "England";
			break;
			case FRANCE:
    	        return "France";
			break;
			case SPAIN:
    	        return "Spain";
			break;
			case HOLLAND:
				return "Holland";
			break;
			case PIRATE:
				return "pirates";
			break;
		}
	}
	else
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "Англией";
			break;
			case FRANCE:
    	        return "Францией";
			break;
			case SPAIN:
    	        return "Испанией";
			break;
			case HOLLAND:
				return "Голландией";
			break;
			case PIRATE:
				return "пиратами";
			break;
		}
	}
}

string NationNameNominative(int iNation) //именительный падеж
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(iNation)
		{
			case ENGLAND: return "l'Angleterre"; break;
			case FRANCE: return "la France"; break;
			case SPAIN: return "l'Espagne"; break;
			case HOLLAND: return "la Hollande"; break;
			case PIRATE: return "les Frères de la Cכte"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "England";
			break;
			case FRANCE:
    	        return "France";
			break;
			case SPAIN:
    	        return "Spain";
			break;
			case HOLLAND:
				return "Holland";
			break;
			case PIRATE:
				return "Brethren";
			break;
		}
	}
	else
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "Англия";
			break;
			case FRANCE:
    	        return "Франция";
			break;
			case SPAIN:
    	        return "Испания";
			break;
			case HOLLAND:
				return "Голландия";
			break;
			case PIRATE:
				return "Береговое братство";
			break;
		}
	}
}

string NationNameGenitive(int iNation) // родительный падеж
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(iNation)
		{
			case ENGLAND: return "l'Angleterre"; break;
			case FRANCE: return "la France"; break;
			case SPAIN: return "l'Espagne"; break;
			case HOLLAND: return "la Hollande"; break;
			case PIRATE: return "la Confrérie de la Cכte"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "England";
			break;
			case FRANCE:
    	        return "France";
			break;
			case SPAIN:
    	        return "Spain";
			break;
			case HOLLAND:
				return "Holland";
			break;
			case PIRATE:
				return "pirates";
			break;
		}
	}
	else
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "Англии";
			break;
			case FRANCE:
    	        return "Франции";
			break;
			case SPAIN:
    	        return "Испании";
			break;
			case HOLLAND:
				return "Голландии";
			break;
			case PIRATE:
				return "пиратов";
			break;
		}
	}
}

///////Часто будет использоваться поэтому заношу сюда
string NationEuropaTown(int iNation)
{
	if (LanguageGetLanguage() == "french") // FR_PATCH
	{
		switch(iNation)
		{
			case ENGLAND: return "Londres"; break;
			case FRANCE: return "La Rochelle"; break;
			case SPAIN: return "Séville"; break;
			case HOLLAND: return "Amsterdam"; break;
			case PIRATE: return "Tortuga"; break;
		}
	}
	if (LanguageGetLanguage() != "russian")
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "London";
			break;
			case FRANCE:
    	        return "La Roshel";
			break;
			case SPAIN:
    	        return "Seville";
			break;
    	    case PIRATE:
		    	return "Tortuga";
			break;
			case HOLLAND:
		    	return "Amsterdam";
			break;
		}
	}
	else
	{
		switch(iNation)
		{
			case ENGLAND:
    	        return "Лондон";
			break;
			case FRANCE:
    	        return "Ля Рошель";
			break;
			case SPAIN:
    	        return "Севилью";
			break;
    	    case PIRATE:
		    	return "Тортугу";
			break;
			case HOLLAND:
		    	return "Амстердам";
			break;
		}
	}

}
string GetCityName(string city) // имена городов по аттрибуту char.city
{
    string ret;
    int nFile = LanguageOpenFile("LocLables.txt");

	ret = LanguageConvertString(nFile, city + " Town")
	LanguageCloseFile( nFile );

	return  ret;
}

string GetPortByCityName(string city) // имена портов по городов по аттрибуту char.city
{
    switch(city)
	{
		case "Bridgetown":
            return "Bridgetown_town";
		break;
		case "SanJuan":
            return "SanJuan_town";
		break;
		case "Santiago":
            return "Santiago_town";
		break;
		case "PuertoPrincipe":
            return "PuertoPrincipe_port";
		break;
		case "SentJons":
            return "SentJons_town";
		break;
		case "PortRoyal":
            return "PortRoyal_town";
		break;
		case "FortOrange":
            return "FortOrange_port";
		break;
		case "Villemstad":
            return "Villemstad_town";
		break;
		case "BasTer":
            return "BasTer_town";
		break;
		case "LaVega":
            return "LaVega_town";
		break;
		case "Bridgetown":
            return "Bridgetown_town";
		break;
		case "SantoDomingo":
            return "SantoDomingo_town";
		break;
		case "PortPax":
            return "PortPax_town";
		break;
		case "Pirates":
            return "Pirates_town";
        break;
		case "FortFrance":
            return "FortFrance_town";
		break;
		case "LeFransua":
            return "LeFransua_town";
		break;
		case "Havana":
            return "Havana_town";
		break;
		case "Charles":
            return "Charles_town";
		break;
		case "PortoBello":
            return "PortoBello_town";
		break;
		case "PortSpein":
            return "PortSpein_town";
		break;
		case "Tortuga":
            return "Tortuga_town";
		break;
		case "Marigo":
            return "Marigo_town";
		break;
		case "Panama":
            return "Panama_town";
		break;
		case "Cartahena":
            return "Cartahena_town";
		break;
		case "Maracaibo":
            return "Maracaibo_town";
		break;
		case "DesMoines":
            return "DesMoines_port";
		break;
		case "Caracas":
            return "Caracas_town";
		break;
		case "Cumana":
            return "Cumana_town";
		break;
		case "SantaCatalina":
            return "SantaCatalina_town";
		break;
		case "Beliz":
            return "Beliz_town";
		break;
		case "Nassau":
            return "Nassau_town";
		break;
	}
	return "";
}

string GetMayakByCityName(string city) // получить id маяка по названию города
{
    switch(city)
	{
		case "Bridgetown":
			return "Mayak2";
		break;
		case "Santiago":
			return "Mayak9";
		break;
		case "PortRoyal":
            return "Mayak3";
		break;
		case "BasTer":
            return "Mayak4";
		break;
		case "SantoDomingo":
            return "Mayak8";
		break;
		case "PortPax":
            return "Mayak7";
		break;
		case "Havana":
            return "Mayak10";
		break;
		case "Charles":
            return "Mayak5";
		break;
		case "PortSpein":
            return "Mayak1";
		break;
		case "Tortuga":
            return "Mayak6";
		break;
		case "Cartahena":
            return "Mayak11";
		break;
	}
	return "";
}

string GetCityNameByMayak(string mayak) // получить id города по маяку
{
    switch(mayak)
	{
		case "Mayak1":
            return "PortSpein";
		break;
		case "Mayak2":
			return "Bridgetown";
		break;
		case "Mayak3":
            return "PortRoyal";
		break;
		case "Mayak4":
            return "BasTer";
		break;
		case "Mayak5":
            return "Charles";
		break;
		case "Mayak6":
            return "Tortuga";
		break;
		case "Mayak7":
            return "PortPax";
		break;
		case "Mayak8":
            return "SantoDomingo";
		break;
		case "Mayak9":
			return "Santiago";
		break;
		case "Mayak10":
            return "Havana";
		break;
		case "Mayak11":
            return "Cartahena";
		break;
	}
	return "";
}

string GetIslandByArealName(string areal)
{
	string sAreal = areal;
	if(areal == "PortoBello" || areal == "Panama" || areal == "Cartahena" ||
		areal == "Maracaibo" || areal == "Caracas" || areal == "Cumana" || areal == "SantaCatalina" ||
		areal == "Beliz" || areal == "DesMoines" || areal == "Tenotchitlan")
	{
		sAreal = "Mein";
	}
	return sAreal;
}

string GetIslandByCityName(string city) // имена острова по городу по аттрибуту char.city
{
    switch(city)
	{
		case "Bridgetown":
            return "Barbados";
		break;
		case "SanJuan":
            return "PuertoRico";
		break;
		case "Santiago":
            return "Cuba";
		break;
		case "PuertoPrincipe":
            return "Cuba";
		break;
		case "SentJons":
            return "Antigua";
		break;
		case "PortRoyal":
            return "Jamaica";
		break;
		case "FortOrange":
            return "Jamaica";
		break;
		case "Villemstad":
            return "Curacao";
		break;
		case "BasTer":
            return "Guadeloupe";
		break;
		case "LaVega":
            return "Hispaniola";
		break;
		case "SantoDomingo":
            return "Hispaniola";
		break;
		case "PortPax":
            return "Hispaniola";
		break;
		case "Pirates":
            return "Bermudes";
        break;
		case "FortFrance":
            return "Martinique";
		break;
		case "LeFransua":
            return "Martinique";
		break;
		case "Havana":
            return "Cuba";
		break;
		case "Charles":
            return "Nevis";
		break;
		case "PortoBello":
            return "Mein";
		break;
		case "PortSpein":
            return "Trinidad";
		break;
		case "Tortuga":
            return "Tortuga";
		break;
		case "Marigo":
            return "SentMartin";
		break;
		case "Panama":
            return "Mein";
		break;
		case "Cartahena":
            return "Mein";
		break;
		case "Maracaibo":
            return "Mein";
		break;
		case "DesMoines":
            return "Mein";
		break;
		case "Caracas":
            return "Mein";
		break;
		case "Cumana":
            return "Mein";
		break;
		case "SantaCatalina":
            return "Mein";
		break;
		case "Beliz":
            return "Mein";
		break;
		case "Tenotchitlan":
            return "Mein";
		break;
		case "Nassau":
            return "Bahames";
		break;
	}
	return "";
}

string GetArealByCityName(string city) // ареал по городу по аттрибуту char.city
{
    switch(city)
	{
		case "Bridgetown":
            return "Barbados";
		break;
		case "SanJuan":
            return "PuertoRico";
		break;
		case "Santiago":
            return "Cuba1";
		break;
		case "PuertoPrincipe":
            return "Cuba1";
		break;
		case "SentJons":
            return "Antigua";
		break;
		case "PortRoyal":
            return "Jamaica";
		break;
		case "FortOrange":
            return "Jamaica";
		break;
		case "Villemstad":
            return "Curacao";
		break;
		case "BasTer":
            return "Guadeloupe";
		break;
		case "LaVega":
            return "Hispaniola1";
		break;
		case "SantoDomingo":
            return "Hispaniola1";
		break;
		case "PortPax":
            return "Hispaniola2";
		break;
		case "Pirates":
            return "Bermudes";
        break;
		case "FortFrance":
            return "Martinique";
		break;
		case "LeFransua":
            return "Martinique";
		break;
		case "Havana":
            return "Cuba2";
		break;
		case "Charles":
            return "Nevis";
		break;
		case "PortoBello":
            return "PortoBello";
		break;
		case "PortSpein":
            return "Trinidad";
		break;
		case "Tortuga":
            return "Tortuga";
		break;
		case "Marigo":
            return "SentMartin";
		break;
		case "Panama":
            return "Panama";
		break;
		case "Cartahena":
            return "Cartahena";
		break;
		case "Maracaibo":
            return "Maracaibo";
		break;
		case "DesMoines":
            return "Maracaibo";
		break;
		case "Caracas":
            return "Caracas";
		break;
		case "Cumana":
            return "Cumana";
		break;
		case "SantaCatalina":
            return "SantaCatalina";
		break;
		case "Beliz":
            return "Beliz";
		break;
		case "Tenotchitlan":
            return "Tenotchitlan";
		break;
		case "Nassau":
            return "Bahames";
		break;
		case "Caiman":
            return "Caiman";
		break;
	}
	return "";
}

string GiveArealByLocation(ref location)
{
	string sAreal;
	if (CheckAttribute(location, "MustSetReloadBack")) return "none";
	if (CheckAttribute(location, "fastreload"))
	{
		sAreal = GetArealByCityName(location.fastreload);
		return sAreal;
	}
	if (CheckAttribute(location, "parent_colony"))
	{
		sAreal = GetArealByCityName(location.parent_colony);
		return sAreal;
	}
	if (!CheckAttribute(location, "islandId")) return "none";
	if (location.islandId == "Cuba" || location.islandId == "Hispaniola" || location.islandId == "Mein")
	{
		if (!CheckAttribute(location, "islandIdAreal")) return "none";
		sAreal = location.islandIdAreal;
	}
	else sAreal = location.islandId;
	return sAreal;
}

// выбор куда идти  по острову даем город (главный город острова с портом)
string GetCityNameByIsland(string CurIslandId)
{
	string TargetLocation;

	TargetLocation = "None";

	switch (CurIslandId)
	{
    	case "Antigua":
			TargetLocation = "SentJons";
		break;
		case "Bahames":
            TargetLocation = "Nassau";
        break;
		case "Bermudes":
			TargetLocation = "Pirates";
		break;
		case "Barbados":
			TargetLocation = "Bridgetown";
		break;
		case "Beliz":
			TargetLocation = "Beliz";
		break;
		case "Cuba1":
			TargetLocation = "Santiago";
		break;
		case "Cuba2":
			TargetLocation = "Havana";
		break;
		case "Cumana":
			TargetLocation = "Cumana";
		break;
		case "Caracas":
			TargetLocation = "Caracas";
		break;
		case "Curacao":
			TargetLocation = "Villemstad";
		break;
		case "Cartahena":
			TargetLocation = "Cartahena";
		break;
		case "Guadeloupe":
			TargetLocation = "BasTer";
		break;
		case "MariaGalante": 
			TargetLocation = "BasTer";
		break;
		case "Hispaniola1":
			TargetLocation = "SantoDomingo";
		break;
		case "Hispaniola2":
			TargetLocation = "PortPax";
		break;
		case "Jamaica":
			TargetLocation = "PortRoyal";
		break;
		case "Maracaibo":
			TargetLocation = "Maracaibo";
		break;
		case "Martinique":
			TargetLocation = "FortFrance";
		break;
		case "SentMartin":
			TargetLocation = "Marigo";
		break;
		case "Nevis":
			TargetLocation = "Charles";
		break;
		case "PuertoRico":
			TargetLocation = "SanJuan";
		break;
		case "PortoBello":
			TargetLocation = "PortoBello";
		break;
		case "Pearl":
			TargetLocation = "none";
		break;
		case "Panama":
			TargetLocation = "Panama";
		break;
		case "SantaCatalina":
			TargetLocation = "SantaCatalina";
		break;
		case "Terks":
			TargetLocation = "none";
		break;
		case "StLucia":
			TargetLocation = "none";
		break;
		case "Dominica":
			TargetLocation = "none";
		break;
		case "Caiman":
			TargetLocation = "none";
		break;
		case "Tortuga":
			TargetLocation = "Tortuga";
		break;
		case "Trinidad":
			TargetLocation = "PortSpein";
		break;
		case "Tobago": 
			TargetLocation = "none";
		break;
		case "Tenotchitlan":
			TargetLocation = "none";
		break;
	}
    return TargetLocation;
}

string TimeGreeting()
{
    if (GetHour() >= 18 && GetHour() < 23)
    {
		if (LanguageGetLanguage() != "russian")
			return FrS("Good evening", "Bonsoir");
		else
			return "Добрый вечер";
    }
    if (GetHour() >= 6 && GetHour() < 12)
    {
		if (LanguageGetLanguage() != "russian")
			return FrS("Good morning", "Bonjour");
		else
       		return "Доброе утро";
    }
    if (GetHour() >= 12 && GetHour() < 18)
    {
		if (LanguageGetLanguage() != "russian")
			return FrS("Good afternoon", "Bonjour");
		else
       		return "Добрый день";
    }
    if (GetHour() >= 23 || GetHour() < 6)
    {
		if (LanguageGetLanguage() != "russian")
			return FrS("Good night", "Bonsoir");
		else
       		return "Доброй ночи";
    }
	if (LanguageGetLanguage() != "russian")
		return "Hi";
	else
    	return "Здрасте";
}

// выбор фразы от репутации
string PCharRepPhrase (string bad, string good)
{
	return NPCharRepPhrase(pchar, bad, good);
}
// boal для НПС
string NPCharRepPhrase(ref _pchar, string bad, string good)
{
	if(makeint(_pchar.reputation) < 40)
	{
		return bad;
	}
	else
	{
		return good;
	}
}

////////// поиск нужного перса для диалога
string GetCharIDByParam(string attrPresent1, string attr2, string val2)
{
    ref rCharacter; //ищем
	int n = GetCharIDXByParam(attrPresent1, attr2, val2);

    if (n > 0)
    {
        makeref(rCharacter,Characters[n]);
        return  rCharacter.id;
    }
    return  "";
}
int GetCharIDXByParam(string attrPresent1, string attr2, string val2)
{
    ref rCharacter; //ищем
	int n;

	for(n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(rCharacter,Characters[n]);
		if (CheckAttribute(rCharacter, attrPresent1))
		{
            if (rCharacter.(attr2) == val2)
                return  n;
		}
    }
    return  -1;
}
int GetCharIDXForTownAttack(string attrPresent1)
{
    ref   rColony; //ищем
	int   n;
	bool  ok;

	for (n=0; n<MAX_COLONIES; n++)
	{
		makeref(rColony, colonies[n]);
		ok = false;
		if (CheckAttribute(rColony, "Default.BoardLocation2") && rColony.Default.BoardLocation2 == attrPresent1)
		{
		    ok = true;
		}
		if (rColony.Default.BoardLocation == attrPresent1 || ok)
        {
			if (rColony.HeroOwn == true)
			{
			    return  -1;
			}

			return GetFortCommanderIdx(rColony.id);
		}
    }
    return  -1;
}
// обращение НПС к ГГ, зависит от нации НПС
string GetAddress_Form(ref NPChar)
{
    string attr = NationShortName(sti(NPChar.nation));
    return address_form.(attr);
}
// обращение ГГ к НПС, зависит от нации НПС и его пола
string GetAddress_FormToNPC(ref NPChar)
{
    string attr  = NationShortName(sti(NPChar.nation));
    string attr2 = NPChar.sex;
    // проверка на скелетов
    if (attr2 != "woman")
    {
        attr2 = "man";
    }
    return address_form.(attr).(attr2);
}
string GetAddress_FormTitle(int nation, int num)
{
    string attr  =  NationShortName(nation);
    string attr2 =  "Title" + num;
	string ret;
	if (LanguageGetLanguage() != "russian")
		ret = "no title";
	else
    	ret = "нет звания";
    if (CheckAttribute(address_form, attr + "." + attr2))
    {
        ret = address_form.(attr).(attr2);
    }
    return ret;
}

bool isCityHasFort(string _city)
{
    int iTest = FindColony(_city); // город
    ref rColony;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
		if (!CheckAttribute(rColony, "HasNoFort")) return true;
	}
	return false;
}

string GetCityFrom_Sea(string _city)
{
    int iTest = FindColony(_city); // город
    ref rColony;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
		return rColony.from_sea;
	}
	return "";
}
// boal <--

// eddy. кто по профессии (только для типовых статиков, не фантомов). sPrefix - приставка для падежей: Gen, Dat..
string GetWorkTypeOfMan(ref NPChar, string sPrefix)
{
	string sCity, sTemp;
	sTemp = "unknown";
	if (CheckAttribute(NPChar, "City"))
	{
		sCity = NPChar.City;
		sTemp = NPChar.id;
		sTemp = strcut(sTemp, strlen(sCity)+1, strlen(sTemp)-1);
	}
	return XI_ConvertString("Who" + sTemp + sPrefix);
}
// Warship 07.08.09 -->
// Количество имен в группе
int GetNamesCount(String _nameType)
{
	aref typeNames;
	makearef(typeNames, Names.Pirates.(_nameType));

	return GetAttributesNum(typeNames);
}

// Случайное имя из определённой группы в определённом падеже
String GetRandName(String _nameType, String _case)
{
	String nameId;

	nameId = "l" + rand(GetNamesCount(_nameType) - 1);

	return GetName(_nameType, nameId, _case);
}

// Вернёт имя из группы с указаным Id и в указанном падеже
String GetName(String _nameType, String _nameId, String _nameCase)
{
	return Names.Pirates.(_nameType).(_nameId).(_nameCase);
}

// Вернёт указанное имя в другом падеже, поиск по именам группы _nameType
String ChangeNameCaseEx(String _nameType, String _name, String _fromCase, String _toCase)
{
	aref typeNames;
	String nameId;

	makearef(typeNames, Names.Pirates.(_nameType));

	for(int i = 0; i < GetAttributesNum(typeNames); i++)
	{
		nameId = "l" + i;

		if(GetName(_nameType, nameId, _fromCase) == _name)
		{
			return GetName(_nameType, nameId, _toCase);
		}
	}

	return "";
}

// Тоже самое, что и выше, только меньше параметров - ищет само
String ChangeNameCase(String _nameType, String _name, String _toCase)
{
	aref typeNames;
	String nameId;

	makearef(typeNames, Names.Pirates.(_nameType));

	for(int i = 0; i < GetAttributesNum(typeNames); i++)
	{
		nameId = "l" + i;

		if(GetName(_nameType, nameId, NAME_NOM) == _name || GetName(_nameType, nameId, NAME_GEN) == _name || GetName(_nameType, nameId, NAME_DAT) == _name ||
			GetName(_nameType, nameId, NAME_ACC) == _name || GetName(_nameType, nameId, NAME_ABL) == _name || GetName(_nameType, nameId, NAME_VOC) == _name)
		{
			return GetName(_nameType, nameId, _toCase);
		}
	}

	return "";
}
// <-- Warship 07.08.09
string GetIndianName(int Sex) //Jason имена индейцев
{
	string nameid;
	
	if (Sex == MAN) nameid = "l" + rand(99);
	else nameid = "l" + (100+rand(68));

	return Names.Indian.(nameId);
}
