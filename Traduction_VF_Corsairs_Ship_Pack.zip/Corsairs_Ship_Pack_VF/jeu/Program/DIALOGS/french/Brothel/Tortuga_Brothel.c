// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("jeune homme", "jeune demoiselle") +" ?", "Que voulez-vous, "+ GetSexPhrase("beau gosse", "ma jolie") +" ?"), "Encore des questions ?", "Hi hi, la troisième fois aujourd'hui, toujours la même chose : des questions...",
                          ""+ GetSexPhrase("Hum, vous ne voudriez pas vous choisir une beauté ? Parce que sinon, je commence à me faire une idée bien précise de vous...", "Hum, vous voulez peut-être vous choisir une beauté ? Nous n'avons pas de garçons, hi hi...") +"", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Hum, rien..."), "Non...",
                      "Ouais, c'est vraiment la troisième fois... Désolé.", "Pas maintenant... Une autre fois...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//==> Голл. №3, узнаем о Пеьере Пикардийце.
            if (pchar.questTemp.State == "WormEnglPlans_WormPicarder")
            {
                link.l1 = "וcoutez, vous n'auriez pas Pierre Picardy dans votre établissement ?";
                link.l1.go = "Step_H3_1";
			}
            // ==> квест Аззи.
            if (CheckAttribute(pchar, "questTemp.Azzy.AddSpecial"))
            {
                dialog.text = "Que voulez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
    			Link.l1 = "C'est Azzi qui m'envoie. Il m'a dit...";
    			Link.l1.go = "Step_1";
            }
            if (pchar.questTemp.Azzy == "HowToKnowAzzy" && !CheckAttribute(pchar, "questTemp.Azzy.AddSpecial"))
            {
                dialog.text = NPCStringReactionRepeat("Que voulez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?", "Encore vous ?", "Encore pour la même affaire ?", "Eh bien, quoi encore ?", "block", 0, npchar, Dialog.CurrentNode);
    			Link.l1 = HeroStringReactionRepeat("וcoutez, je dois trouver Azzie de toute urgence !", "Oui, c'est encore moi ! J'ai besoin d'Azzie.", "Encore pour la même affaire.", "La même chose. J'ai besoin d'Azzi.", npchar, Dialog.CurrentNode);
    			Link.l1.go = DialogGoNodeRepeat("Step_15", "none", "none", "none", npchar, Dialog.CurrentNode);
            }
            if (pchar.questTemp.Azzy == "DestrContract")
            {
                dialog.text = "Oh, qui vois-je ?!";
    			Link.l1 = "Moi, Margarita. Mais cette fois, je viens avec une offre précise.";
    			Link.l1.go = "Step_17";
            }
            if (pchar.questTemp.Azzy == "2DestrContract")
            {
                dialog.text = "Encore vous ?";
    			Link.l1 = "Encore moi. Et si vous appeliez Azzie ?";
    			Link.l1.go = "Step_20";
            }
			//жемчужный генератор Шарпа
			if (pchar.questTemp.Sharp == "seekSharp" && GetNpcQuestPastDayWOInit(npchar, "quest.SharpTime") > 7 && !LAi_IsDead(&characters[GetCharacterIndex("Sharp")]))
			{
				link.l1 = "וcoutez, " + npchar.name + ", je cherche Sharp. Vous savez oם il est ?";
				link.l1.go = "SharpPearl_1";
				SaveCurrentNpcQuestDateParam(npchar, "quest.SharpTime");
			}
            // <== Проверяем поле состояния квестов.
		break;
		//==>Голландская линейка, квест №3.
 	 	case "Step_H3_1":
			dialog.text = NPCStringReactionRepeat("Pas maintenant, mais aujourd'hui, c'est sמr.", ""+ GetSexPhrase("beau gosse", "ma jolie") +", vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de Pierre", "C'est encore au sujet de Pierre ?", "וcoutez, "+ GetSexPhrase("mon chéri", "ma chérie") +", arrêtez donc de parler de Pierre. Regardez autour de vous, amusez-vous...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Comment le savez-vous ?", "Oui, exactement...", "Hum, encore...", "C'est obligatoire, mais malheureusement, pas maintenant...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H3_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H3_2":
			dialog.text = ""+ GetSexPhrase("Mon chéri", "Ma chérie") +", comment ne le saurais-je pas ?! Depuis son retour, il n'y a pas eu un jour sans qu'il se montre chez moi. Et chaque jour, il prend une nouvelle fille, même si je double les tarifs pour une telle inconstance. Alors si vous voulez l'attraper, attendez, tout simplement.";
			link.l1 = "Merci, mais je crois que je vais filer.";
			link.l1.go = "exit";
            pchar.questTemp.Talks.Brothel = true;
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "11");
        break;
		//==> Квест Аззи
        case "Step_1":
			dialog.text = "Pardon de vous interrompre... Dites-moi votre nom.";
			Link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
			Link.l1.go = "Step_2";
		break;
        case "Step_2":
			dialog.text = "Je vous attendais, "+ GetSexPhrase("beau gosse", "ma jolie") +". Azzie m'a prévenue que je devais faire quelque chose pour vous.";
			Link.l1 = "Oui, c'est ça. Je ne sais même pas comment dire ce « quelque chose »...";
			Link.l1.go = "Step_3";
		break;
        case "Step_3":
			dialog.text = "Pourquoi un tel embarras ? Vous savez qui je suis. Vous savez qui est Azzie.";
			Link.l1 = "Azzie a dit que vous étiez une sorcière !";
			Link.l1.go = "Step_4";
		break;
        case "Step_4":
			dialog.text = "Et plutכt douée, je peux l'avouer... Et qui êtes-vous pour Azzie, qu'il se soucie tant de vous ?";
			Link.l1 = ""+ GetSexPhrase("Une simple connaissance", "Une simple connaissance") +", voilà tout...";
			Link.l1.go = "Step_5";
		break;
        case "Step_5":
			dialog.text = "Ah, je vois... Je vous croyais quelqu'un d'important dans notre hiérarchie. Et vous n'êtes qu'une personne "+ GetSexPhrase("de passage", "de passage") +"\n"+
                     "Passons aux affaires, "+ GetSexPhrase("beau gosse", "ma jolie") +". Azzie a dit que je devais modifier votre corps pour certains besoins. Que voulez-vous ?";
			Link.l1 = ""+ GetSexPhrase("Hum, vous savez, pour commencer, je vous inviterais bien à la taverne pour un verre... Vous êtes libre ce soir ?", "Hum, je veux beaucoup de choses... Tout, et le plus possible !") +"";
			Link.l1.go = "Step_6";
		break;
        case "Step_6":
			dialog.text = ""+ GetSexPhrase("N'y songez même pas, vous ne m'intéressez pas. Je ne ferai des folies avec mon ami Azzi que lorsque Azzi sera là EN PERSONNE", "« Beaucoup », ce n'est pas une réponse") +"\n"+
                     "Bref, soyons rapides et allons droit au but. Je peux augmenter votre force, votre agilité, votre perception, votre charme, votre endurance ou votre intelligence\n"+
                     "Alors, comment dois-je changer votre corps ?";
			Link.l1 = "Plus de force, d'agilité, de perception, de charisme, d'intelligence : bref, je veux tout l'ensemble.";
			Link.l1.go = "Step_7";
		break;
        case "Step_7":
			dialog.text = "Tout l'ensemble, ça ne marchera pas.";
			Link.l1 = "Comment ça, ça ne marchera pas ?! "+ GetSexPhrase("Non seulement elle n'a pas chauffé l'étuve pour le brave gaillard, ni ne l'a mis au lit, mais en plus elle triche ! Azzi a dit...", "Azzi a dit...") +"";
			Link.l1.go = "Step_8";
		break;
        case "Step_8":
			dialog.text = "וcoutez-moi bien, "+ GetSexPhrase("mon brave", "ma chérie") +" ! Pour augmenter votre force, je dois greffer de nouveaux gros muscles à votre corps\n"+
                     "Pour augmenter votre agilité, je dois remplacer vos tendons par d'autres, plus élastiques\n"+
                     "Pour augmenter votre endurance, je dois remplacer vos ligaments par d'autres, très solides\n"+
                     "Et ainsi de suite pour chaque point. Si l'on fait tout à la fois, rien ne marchera vraiment. L'exception, c'est la chance : ce n'est qu'une combinaison raisonnable de différentes caractéristiques du corps, qui permet de se tirer avec honneur de diverses situations difficiles. Autrement dit, d'avoir de la chance\n"+
                     "Alors ne faites pas l'idiot, choisissez une seule chose. Tant que je suis de bonne humeur...";
			Link.l1 = "Je vois, alors je "+ GetSexPhrase("dois", "dois") +" choisir ?";
			Link.l1.go = "Step_9";
		break;
        case "Step_9":
			dialog.text = "Exactement. Dites-moi, quelle caractéristique de votre corps faut-il augmenter ?";
            Link.l1 = "La force";
			Link.l1.go = "Strength";
            Link.l2 = "Perception";
			Link.l2.go = "Perception";
            Link.l3 = "La réactivité";
			Link.l3.go = "Agility";
            Link.l4 = "Le commandement";
			Link.l4.go = "Charisma";
            Link.l5 = "La faculté d'apprendre";
			Link.l5.go = "Intellect";
			Link.l6 = "Endurance";
			Link.l6.go = "Endurance";
            Link.l7 = "Luck";
			Link.l7.go = "Luck";
		break;
        case "Strength":
			dialog.text =  "La force, bon choix. Eh bien, nous préparons les muscles, et nous allons les changer. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_S, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_S, 1);
			}
		break;
        case "Perception":
			dialog.text =  "La perception, très bien. Eh bien, nous préparons de nouveaux organes des sens, et nous allons les changer. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_P, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_P, 1);
			}
		break;
        case "Endurance":
			dialog.text =  "L'endurance, bien. Eh bien, nous préparons des ligaments ultra-résistants, et nous allons les changer. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_E, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_E, 1);
			}
		break;
        case "Charisma":
			dialog.text =  "Le charme ? Hum, bon choix, "+ GetSexPhrase("beau gosse", "ma jolie") +" ! Eh bien, nous préparons un joli visage aux traits "+ GetSexPhrase("virils", "irrésistibles") +" ; on va vous le greffer. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_C, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_C, 1);
			}
		break;
        case "Intellect":
			dialog.text =  "L'intelligence, bon choix. Eh bien, nous préparons de bons cerveaux tout neufs, et nous allons les changer. N'ayez pas peur, vous garderez votre mémoire. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_I, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_I, 1);
			}
		break;
        case "Agility":
			dialog.text =  "L'agilité, bien. Eh bien, nous préparons de nouveaux ligaments superélastiques, et nous allons les changer. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_A, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_A, 1);
			}
		break;
        case "Luck":
			dialog.text =  "Vous voulez être "+ GetSexPhrase("un pirate chanceux", "une pirate chanceuse") +" ? Vous avez raison. Eh bien, nous préparons tout du neuf : muscles, ligaments, tendons, yeux, oreilles, bref, tout. Rien d'exceptionnel en particulier, mais le tout est très honnête. Je pense qu'il n'y a pas de raison d'attendre, commençons tout de suite.";
			Link.l1 = "Commencer quoi ?";
			Link.l1.go = "Step_10";
			if (AddSPECIALValue(pchar, SPECIAL_L, 0) == SPECIAL_MAX)
			{
                Link.l1.go = "NotPosblAdd";
			}
			else
			{
			    AddSPECIALValue(pchar, SPECIAL_L, 1);
			}
		break;
        case "Step_10":
			dialog.text =  "Comment ça, à quoi ? א l'opération, "+ GetSexPhrase("beau gosse", "ma jolie") +". On va vous découper ! Ha ha ha !!";
			Link.l1 = "Tout ça ne me plaît pas...";
			Link.l1.go = "Step_11";
		break;
        case "Step_11":
			dialog.text =  "N'ayez pas peur, vous n'aurez pas mal. Bon, on va vite vous changer le foie, raboter les plis...";
			Link.l1 = "Et quoi, il faudrait que je regarde ça ? Je le "+ GetSexPhrase("dois", "dois") +" ?!";
			Link.l1.go = "Step_12";
		break;
        case "Step_12":
			dialog.text =  ""+ GetSexPhrase("Quel corsaire hypocrite vous faites", "Quelle pirate hypocrite vous faites") +". Tant de gens, vous les avez "+ GetSexPhrase("envoyés", "envoyés") +" dans l'autre monde, et vous avez peur de votre propre sang.";
			Link.l1 = "וcoute, sorcière, je n'ai peur de rien ni de personne ! Alors fais attention à ce que tu dis. Et je crains pour ma raison : on peut devenir fou à regarder de telles choses !";
			Link.l1.go = "Step_13";
		break;
        case "Step_13":
			dialog.text =  "Bon, faisons tout sous anesthésie, ha ha ha ! Tenez, buvez cette infusion. Vous vous réveillerez dans deux jours exactement : votre commande sera exécutée. Et sachez que désormais, je ne vous connais pas.";
			Link.l1 = "Eh, advienne que pourra ! Donnez-moi votre poison. Et soyez délicate avec moi...";
			Link.l1.go = "exit";
			AddDialogExitQuest("Azzy_PlusSkill");
		break;
        case "NotPosblAdd":
			dialog.text =  "Voyons ce que vous avez... Non, "+ GetSexPhrase("beau gosse", "ma jolie") +", je n'ai pas de remplacement digne de ce nom. Désolée, les stocks sont limités, et vous auriez tort de vous plaindre de ce que vous avez... Choisissez autre chose.";
			Link.l1 = "Hum, je suis "+ GetSexPhrase("flatté", "flattée") +"... Alors, je peux réfléchir de nouveau à mon choix ?";
			Link.l1.go = "Step_9";
		break;
        case "Step_15":
			dialog.text =  "Je ne sais pas de qui vous parlez.";
			Link.l1 = "Arrêtez de vous moquer de moi ! J'ai besoin d'Azzie. Comment puis-je le trouver ?";
			Link.l1.go = "Step_16";
		break;
        case "Step_16":
			dialog.text =  "Ne criez pas à travers toute la ville, "+ GetSexPhrase("monsieur", "madame") +" ! On ne peut pas trouver Azzi ; moi-même, je ne pourrai le voir que la nuit de Walpurgis. Je ne peux rien pour vous.";
			Link.l1 = "Maudite sorcière !";
			Link.l1.go = "exit";
		break;
        case "Step_17":
			dialog.text =  "Voilà qui est intéressant.";
			Link.l1 = "Je vous propose d'invoquer Azzi à l'aide des trois crânes de cristal toltèques.";
			Link.l1.go = "Step_18";
		break;
        case "Step_18":
			dialog.text =  "Hum, j'ai entendu parler de ces choses. Les Toltèques s'en servent pour des rituels mystiques. Mais pour invoquer un démon, il faut un autre objet : une chose étrange.";
			Link.l1 = "Je suis au courant. Alors, êtes-vous prête à accomplir le rituel ?";
			Link.l1.go = "Step_19";
		break;
        case "Step_19":
			dialog.text =  "Je peux le faire si vous avez ces objets. Mais je garderai ensuite ces objets en paiement de mon travail. De plus, les démons n'aiment pas qu'on les dérange pour autre chose. Vous pourriez donc disparaître à jamais...";
			Link.l1 = "Ne vous inquiétez pas pour Azzie, j'ai sa promesse de ne pas me toucher s'il est appelé. Et je vous laisse les objets.";
			Link.l1.go = "Step_20";
		break;
        case "Step_20":
			dialog.text =  "Je suis prête à accomplir le rituel. Avez-vous les objets ?";
            if (CheckCharacterItem(pchar, "sculMa1") && CheckCharacterItem(pchar, "sculMa2") && CheckCharacterItem(pchar, "sculMa3") && CheckCharacterItem(pchar, "indian22"))
            {
    			Link.l1 = "Oui, je les ai. Commencez tout de suite !";
    			Link.l1.go = "Step_22";
            }
            else
            {
    			Link.l1 = "Non, je les cherche.";
    			Link.l1.go = "Step_21";
            }
		break;
        case "Step_21":
			dialog.text =  "Si vous les trouvez, revenez, et nous ferons tout.";
			Link.l1 = "Compris, je vais chercher.";
			Link.l1.go = "exit";
			pchar.questTemp.Azzy = "2DestrContract";
		break;
        case "Step_22":
			dialog.text =  "Alors, commençons ! Ha ha ha (psalmodie une incantation)";
			Link.l1 = "Eh, quelle langue barbare...";
			Link.l1.go = "Step_23";
		break;
        case "Step_23":
            TakeItemFromCharacter(pchar, "sculMa1");
            TakeItemFromCharacter(pchar, "sculMa2");
            TakeItemFromCharacter(pchar, "sculMa3");
            TakeItemFromCharacter(pchar, "indian22");
            pchar.questTemp.Azzy = "3DestrContract";
            DeleteAttribute(pchar, "questTemp.Azzy.Oliver")
            ChangeCharacterAddressGroup(characterFromId("Azzy"), pchar.location, "goto", "goto2");
            DoQuestCheckDelay("Azzy_IsFree", 2.0);
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
		break;
		// капитан Шарп, грабёж жемчужных промыслов
		case "SharpPearl_1":
			if (drand(1) || bBettaTestMode)
			{
				if (sti(pchar.questTemp.Sharp.brothelChance) < 9)
				{	//футболим геймера в город
					pchar.questTemp.Sharp.City = GetSharpCity();
					pchar.questTemp.Sharp.City.rumour = true; //флаг дачи слуха
					dialog.text = "א ma connaissance, le capitaine Sharp est parti pour " + XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc") + ".";
					link.l1 = "Hé ! Merci, " + npchar.name + ". Vous m'avez beaucoup aidé !";
					link.l1.go = "exit";
					pchar.questTemp.Sharp = "toSharp_going"; //в бордели больше не заходить
					pchar.questTemp.Sharp.count = 0; //счетчик нулим для след. раза
					pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
					pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
					ReOpenQuestHeader("SharpPearl");
					AddQuestRecord("SharpPearl", "1");
					AddQuestUserData("SharpPearl", "sCity", XI_ConvertString("Colony" + npchar.city + "Voc"));
					AddQuestUserData("SharpPearl", "sTarget", XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc"));
					if (GetIslandByCityName(pchar.questTemp.Sharp.City) != pchar.questTemp.Sharp.City)
					{
						AddQuestUserData("SharpPearl", "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(pchar.questTemp.Sharp.City) + "Voc"));
					}
					//запускаем энкаунтер Шарпа на карте
					group_DeleteGroup("Sharp_Group");
					sld = characterFromId("Sharp");
					string sGroup = "Sharp_Group";
					Group_FindOrCreateGroup(sGroup);
					Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
					Group_LockTask(sGroup);
					Group_AddCharacter(sGroup, sld.id);
					Group_SetGroupCommander(sGroup, sld.id);
					sld.mapEnc.type = "trade";
					sld.mapEnc.worldMapShip = "quest_ship";
					sld.mapEnc.Name = "Brick 'Sharp Bearer'";
					string sColony= SelectAnyColony(npchar.city); //колония, откуда плывёт Шарп
					int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sColony), GetArealByCityName(pchar.questTemp.Sharp.City)) + 1; //дней доехать даём с запасом
					Map_CreateTrader(sColony, pchar.questTemp.Sharp.City, sld.id, daysQty);
					Log_TestInfo("The sharp-bearer is installed from  " + sColony + " in " + pchar.questTemp.Sharp.City);
				}
				else
				{	//чудо, Шарп здесь, в борделе!
					dialog.text = "Je sais. Il se repose chez moi. Je peux appeler Sharp, si vous en avez besoin d'urgence.";
					link.l1 = "Rendez-moi ce service, " + npchar.name + "...";
					link.l1.go = "SharpPearl_2";
				}
			}
			else
			{
				dialog.text = "Je ne sais pas, il n'est pas venu depuis longtemps.";
				link.l1 = "Compris... Eh bien, merci, " + npchar.name + ".";
				link.l1.go = "exit";
			}
		break;
		case "SharpPearl_2":
			dialog.text = "Mon petit Bartholomew ! Viens ici, mon chou, quelqu'un te demande !";
			link.l1 = "Hé, vous tenez Sharp en haute estime, à ce que je vois...";
			link.l1.go = "SharpPearl_3";
		break;
		case "SharpPearl_3":
			chrDisableReloadToLocation = true;
			pchar.questTemp.Sharp.count = 0; //счётчик нулим для след. раза
			pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
			pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
			sld = &characters[GetCharacterIndex("Sharp")];
			sld.dialog.currentnode = "BrothelSharp";
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER_OWN);
			ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorDialog(sld, pchar, "", -1, 0);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

