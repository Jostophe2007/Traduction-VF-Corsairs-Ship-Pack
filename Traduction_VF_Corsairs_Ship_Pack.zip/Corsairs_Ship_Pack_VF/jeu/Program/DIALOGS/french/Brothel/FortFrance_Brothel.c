// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("jeune homme", "jeune demoiselle") +" ?", "Que voulez-vous, "+ GetSexPhrase("beau gosse", "ma jolie") +" ? Posez vos questions..."), "Encore des questions ?", "Hi hi, la troisième fois aujourd'hui, toujours la même chose : des questions...",
                          ""+ GetSexPhrase("Hum, vous ne voudriez pas vous choisir une beauté ? Parce que sinon, je commence à me faire une idée bien précise de vous...", "Hum, vous voulez peut-être vous choisir une beauté ? Nous n'avons pas de garçons, hi hi...") +"", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Hum, rien..."), "Non...",
                      "Ouais, c'est vraiment la troisième fois... Désolé.", "Pas maintenant... Une autre fois...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Проверяем поле состояния квестов.
            if (pchar.questTemp.State == "SeekBible_toFFBrothel" && npchar.id == "FortFrance_Hostess") //Голландская линейка, квест №8. узнаем о пирате, который о Библии базарил.
			{
                link.l1 = "וcoutez, il y a quelque temps, Jackman a fait la fête chez vous en compagnie de corsaires...";
                link.l1.go = "Step_H8_1";
			}
			if (pchar.questTemp.Sharp == "seekSharp" && GetNpcQuestPastDayWOInit(npchar, "quest.SharpTime") > 7 && !LAi_IsDead(&characters[GetCharacterIndex("Sharp")]))
			{
				link.l1 = "וcoutez, " + npchar.name + ", je cherche Sharp. Vous savez oם il est ?";
				link.l1.go = "SharpPearl_1";
				SaveCurrentNpcQuestDateParam(npchar, "quest.SharpTime");
			}
            // <== Проверяем поле состояния квестов.
		break;

        case "Step_H8_1":
            dialog.text = ""+ GetSexPhrase("Jeune homme", "Mademoiselle") +", chez nous, on fait la fête en compagnie de filles, pas entre hommes ! Faites attention à ce que vous dites...";
            link.l1 = "Eh bien, ils faisaient la fête en grande compagnie...";
            link.l1.go = "Step_H8_2";
        break;
        case "Step_H8_2":
            dialog.text = "Une grande compagnie, en effet, il y avait beaucoup de monde. Je me souviendrai longtemps de cette fête...";
            link.l1 = "Pourquoi donc, si je puis me permettre ?";
            link.l1.go = "Step_H8_3";
        break;
        case "Step_H8_3":
            dialog.text = "Parce que tout mon établissement a travaillé pour eux cette nuit-là. C'était terrible !";
            link.l1 = "Je vois... Dites, vous n'auriez pas entendu parler de ceci : quelqu'un a essayé de vendre un livre, une sorte de Bible...";
            link.l1.go = "Step_H8_4";
        break;
        case "Step_H8_4":
            dialog.text = "Non, je n'en ai pas entendu parler.";
            link.l1 = "Vos filles pourraient peut-être me le dire ?";
            link.l1.go = "Step_H8_5";
        break;
        case "Step_H8_5":
            dialog.text = "Elles vous le diront peut-être. Mais moi, ça m'est égal ; demandez-leur "+ GetSexPhrase("vous-même", "vous-même") +".";
            link.l1 = "Et à qui ? Qui était là cette nuit-là ?";
            link.l1.go = "Step_H8_6";
        break;
        case "Step_H8_6":
            dialog.text = "Tout le monde ! Toutes sans exception ! Demandez à chacune. Quelqu'un s'en souviendra peut-être vraiment...";
            link.l1 = "Merci, je vais demander...";
            link.l1.go = "exit";
            pchar.questTemp.State = "SeekBible_toGirl";
        break;
		// капитан Шарп, грабёж жемчужных промыслов
		case "SharpPearl_1":
			if (drand(1) || bBettaTestMode)
			{
				if (sti(pchar.questTemp.Sharp.brothelChance) < 9)
				{	//футболим геймера в город
					pchar.questTemp.Sharp.City = GetSharpCity();
					pchar.questTemp.Sharp.City.rumour = true; //флаг дачи слуха
					dialog.text = "א ma connaissance, le capitaine Sharp est parti pour " + XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc") + ".";
					link.l1 = "Hé ! Merci, " + npchar.name + ". Vous m'avez beaucoup aidé !";
					link.l1.go = "exit";
					pchar.questTemp.Sharp = "toSharp_going"; //в бордели больше не заходить
					pchar.questTemp.Sharp.count = 0; //счетчик нулим для след. раза
					pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
					pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
					ReOpenQuestHeader("SharpPearl");
					AddQuestRecord("SharpPearl", "1");
					AddQuestUserData("SharpPearl", "sCity", XI_ConvertString("Colony" + npchar.city + "Voc"));
					AddQuestUserData("SharpPearl", "sTarget", XI_ConvertString("Colony" + pchar.questTemp.Sharp.City + "Acc"));
					if (GetIslandByCityName(pchar.questTemp.Sharp.City) != pchar.questTemp.Sharp.City)
					{
						AddQuestUserData("SharpPearl", "sAreal", ", sur l'île de " + XI_ConvertString(GetIslandByCityName(pchar.questTemp.Sharp.City) + "Voc"));
					}
					//запускаем энкаунтер Шарпа на карте
					group_DeleteGroup("Sharp_Group");
					sld = characterFromId("Sharp");
					string sGroup = "Sharp_Group";
					Group_FindOrCreateGroup(sGroup);
					Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
					Group_LockTask(sGroup);
					Group_AddCharacter(sGroup, sld.id);
					Group_SetGroupCommander(sGroup, sld.id);
					sld.mapEnc.type = "trade";
					sld.mapEnc.worldMapShip = "quest_ship";
					sld.mapEnc.Name = "Brick 'Sharp Bearer'";
					string sColony= SelectAnyColony(npchar.city); //колония, откуда плывёт Шарп
					int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sColony), GetArealByCityName(pchar.questTemp.Sharp.City)) + 1; //дней доехать даём с запасом
					Map_CreateTrader(sColony, pchar.questTemp.Sharp.City, sld.id, daysQty);
					Log_TestInfo("The sharp-bearer is installed from  " + sColony + " in " + pchar.questTemp.Sharp.City);
				}
				else
				{	//чудо, Шарп здесь, в борделе!
					dialog.text = "Je sais. Il se repose chez moi. Je peux appeler Sharp, si vous en avez besoin d'urgence.";
					link.l1 = "Rendez-moi ce service, " + npchar.name + "...";
					link.l1.go = "SharpPearl_2";
				}
			}
			else
			{
				dialog.text = "Je ne sais pas, il n'est pas venu depuis longtemps.";
				link.l1 = "Compris... Eh bien, merci, " + npchar.name + ".";
				link.l1.go = "exit";
			}
		break;
		case "SharpPearl_2":
			dialog.text = "Mon petit Bartholomew ! Viens ici, mon chou, quelqu'un te demande !";
			link.l1 = "Hé, vous tenez Sharp en haute estime, à ce que je vois...";
			link.l1.go = "SharpPearl_3";
		break;
		case "SharpPearl_3":
			chrDisableReloadToLocation = true;
			pchar.questTemp.Sharp.count = 0; //счётчик нулим для след. раза
			pchar.questTemp.Sharp.price = 5000+rand(20)*1000; //цена за наводку
			pchar.questTemp.Sharp.price.evil = rand(1); //добрый или злой, для скидки
			sld = &characters[GetCharacterIndex("Sharp")];
			sld.dialog.currentnode = "BrothelSharp";
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER_OWN);
			ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorDialog(sld, pchar, "", -1, 0);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

