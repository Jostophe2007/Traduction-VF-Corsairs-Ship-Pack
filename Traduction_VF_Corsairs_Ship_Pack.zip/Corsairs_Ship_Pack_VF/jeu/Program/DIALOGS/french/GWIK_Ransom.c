// Pirate go-between: ransom of the captured GWIC captain (office assignment)

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iRansom = 0;
	if (CheckAttribute(pchar, "GWIK.Job.Ransom")) iRansom = sti(pchar.GWIK.Job.Ransom);
	if (CheckAttribute(pchar, "GWIK.Job.RansomActual")) iRansom = sti(pchar.GWIK.Job.RansomActual); // price after haggling
	int comSkill, nomRansom, leadSkill;
	bool ok;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			ok = false;
			if (CheckAttribute(pchar, "GWIK.Job") && pchar.GWIK.Job == "ransom") ok = true;
			if (CheckAttribute(pchar, "GWIK.Job.Rescued")) ok = false;
			if (!ok)
			{
				dialog.text = "Qu'est-ce que tu regardes ? Circule tant que tu as encore tous tes membres.";
				link.l1 = "Je m'en vais...";
				link.l1.go = "exit";
				break;
			}
			if (CheckAttribute(pchar, "GWIK.Job.CaptiveDead")) // Gregg: rare outcome - the captive got himself killed. The pirate only INFORMS you (no coin - why would he); the token compensation for the trouble is paid by the COMPANY when you report at an office (node GWIK_RansomDeadReport)
			{
				if (!CheckAttribute(pchar, "GWIK.Job.CaptiveDeadKnown"))
				{
					pchar.GWIK.Job.CaptiveDeadKnown = true; // now report the death at a GWIC office
					AddQuestRecord("GWIK_RansomJob", "10");
					dialog.text = "Trop tard, le Hollandais. Ton capitaine avait la langue trop bien pendue : les gars ont perdu patience et l'ont saigné. Va, annonce la nouvelle à tes maîtres : ce n'est pas mon affaire.";
				}
				else
				{
					dialog.text = "Je te l'ai déjà dit : ton capitaine nourrit les crabes au fond de l'eau. Va voir tes maîtres, il n'y a plus rien pour toi ici.";
				}
				link.l1 = "Bon sang...";
				link.l1.go = "exit";
				break;
			}
			if (CheckAttribute(pchar, "GWIK.Job.Force")) // chose force - the sloop is already at sea, nothing to haggle
			{
				dialog.text = "Tu as fait ton choix, le Hollandais. Le navire « "+ pchar.GWIK.Job.ForceShipName +" » est en mer au large des Bermudes : ton capitaine est à bord. Va l'attraper, si tu en as le cran.";
				link.l1 = "J'y vais.";
				link.l1.go = "exit";
				break;
			}
			if (CheckAttribute(pchar, "GWIK.Job.Mutiny")) // Gregg: rare go-between twist - there's no one to ransom: the Company's captain mutinied and turned pirate himself. He's the one sitting before you
			{
				if (CheckAttribute(pchar, "GWIK.Job.MutinyReturnedSelf")) // already persuaded - the runaway left for an office on his own, nothing more to do here (safety net if the deferred departure didn't fire)
				{
					dialog.text = "Nous nous sommes mis d'accord sur tout, le Hollandais. Va au comptoir, on se verra là-bas.";
					link.l1 = "א tout à l'heure, là-bas.";
					link.l1.go = "exit";
					break;
				}
				if (!CheckAttribute(pchar, "GWIK.Job.MutinyMet"))
				{
					pchar.GWIK.Job.MutinyMet = true;
					AddQuestRecord("GWIK_RansomJob", "12"); // reveal: no captive - the captain turned coat
					dialog.text = "Une rançon ? Ha ha ha ! Regarde autour de toi, le Hollandais : ton capitaine, c'est moi, en chair et en os. J'en ai eu assez de me casser le dos pour la Compagnie pour une misère : maintenant, je suis mon propre maître sous le pavillon noir. Alors, va donc égayer tes maîtres : il n'y a personne à racheter.";
				}
				else
				{
					dialog.text = "Encore toi ? J'ai dit ce que j'avais à dire : tu ne me ferais pas revenir à la Compagnie avec tout l'or de Carthagène.";
				}
				if (!CheckAttribute(pchar, "GWIK.Job.MutinyRefused")) // first - an attempt to persuade (Leadership); refusal opens the 'report' and 'take by force' paths
				{
					link.l1 = "Reviens à la raison. Tu es un bon capitaine : la Compagnie te pardonnera et te reprendra. Reviens par la voie pacifique.";
					link.l1.go = "Mutiny_Persuade";
					link.l2 = "Eh bien, c'est ton choix. Il faut que j'y réfléchisse.";
					link.l2.go = "exit";
				}
				else
				{
					link.l1 = "Si tu ne viens pas de ton plein gré, la Compagnie apprendra que tu es un traître. (dénoncer)";
					link.l1.go = "Mutiny_Report";
					link.l2 = "Tu ne veux pas venir par la manière douce ? Alors, je te prendrai de force. Prends la mer, nous réglerons ça là-bas.";
					link.l2.go = "Mutiny_Threaten";
					link.l3 = "Il faut que j'y réfléchisse.";
					link.l3.go = "exit";
				}
				break;
			}
			dialog.text = "Ah, tu viens de la part des Hollandais, pour leur capitaine ? L'argent d'abord : "+ FindRussianMoneyString(iRansom) +" , et tu peux l'emmener tout de suite.";
			if (CheckAttribute(pchar, "GWIK.Job.Bargained")) dialog.text = "Alors, ta décision est prise ? Le prix reste le même : "+ FindRussianMoneyString(iRansom) +", et le capitaine est à toi.";
			if (sti(pchar.money) >= iRansom)
			{
				link.l1 = "Voici la rançon. Oם est le capitaine ?";
				link.l1.go = "pay";
			}
			else
			{
				link.l1 = "Je n'ai pas autant sur moi...";
				link.l1.go = "exit";
			}
			if (!CheckAttribute(pchar, "GWIK.Job.Bargained")) // haggle - once only
			{
				link.l2 = "Pour l'amour de Dieu, il ne vaut pas ce prix. Baisse un peu.";
				link.l2.go = "bargain";
			}
			link.l3 = "Payer des pirates ? Certainement pas. J'irai chercher le capitaine moi-même.";
			link.l3.go = "force_warn";
			link.l4 = "Je vais y réfléchir.";
			link.l4.go = "exit";
		break;

		case "bargain": // Gregg: haggling - Commerce check; the office reimburses the NOMINAL, the saving stays with the player
			pchar.GWIK.Job.Bargained = true;
			comSkill = GetSummonSkillFromName(pchar, SKILL_COMMERCE);
			nomRansom = sti(pchar.GWIK.Job.Ransom);
			if (comSkill >= 60) // Gregg: Commerce skill 0-100 (was hardcoded 8 - fired almost always)
			{
				pchar.GWIK.Job.RansomActual = makeint(nomRansom * 75 / 100);
				AddCharacterExpToSkill(pchar, SKILL_COMMERCE, 30); // Gregg: trade xp for a successful haggle (knocked a quarter off)
				dialog.text = "Bah, tu sais compter, âme hollandaise... Bon, "+ sti(pchar.GWIK.Job.RansomActual) +" piastres, et marché conclu, pourvu que je ne revoie jamais ta figure.";
			}
			else
			{
				if (comSkill >= 35)
				{
					pchar.GWIK.Job.RansomActual = makeint(nomRansom * 85 / 100);
					AddCharacterExpToSkill(pchar, SKILL_COMMERCE, 20); // Gregg: trade xp for a haggle (knocked part of the price off)
					dialog.text = "Hmph, tu marchandes aussi bien que nous... Je baisse un peu : "+ sti(pchar.GWIK.Job.RansomActual) +" piastres, et pas une de moins.";
				}
				else
				{
					pchar.GWIK.Job.RansomActual = makeint(nomRansom * 110 / 100);
					dialog.text = "Tu me prends pour un imbécile ?! Pour ce culot, j'augmente le prix. Maintenant, c'est "+ sti(pchar.GWIK.Job.RansomActual) +" piastres, et réjouis-toi que ce ne soit pas le double.";
				}
			}
			link.l1 = "Marché conclu.";
			link.l1.go = "First time";
		break;

		case "force_warn": // Gregg: force path - the go-between sneers and spirits the captain onto a sloop
			dialog.text = "Le prendre toi-même, c'est ça ? Ha ! וcoute un peu : pendant que tu joues les héros, le capitaine est déjà à bord d'un navire qui lève l'ancre. Rattrape-le en mer, et le prisonnier est à toi, de bonne guerre. Mais envoie-le par le fond, et les Hollandais ne te remercieront pas pour un noyé. Alors, tu veux toujours faire à ta façon ?";
			link.l1 = "Oui. Qu'il prenne la mer : j'ai déjà repêché des hommes bien plus précieux.";
			link.l1.go = "force_go";
			link.l2 = "א la réflexion, passons-nous du sang. Revenons aux affaires.";
			link.l2.go = "First time";
		break;

		case "force_go":
			if (!GWIK_RansomForceSpawn("Pirates")) // the sloop didn't put out - don't dead-end; patrol anchored off Bermuda (mediator text says "off Bermuda")
			{
				dialog.text = "Hmph, le navire est déjà parti, et oם, je n'en ai pas la moindre idée. Repasse plus tard, je flairerai la piste.";
				link.l1 = "Je reviendrai.";
				link.l1.go = "exit";
				break;
			}
			AddQuestRecord("GWIK_RansomJob", "5");
			AddQuestUserData("GWIK_RansomJob", "sShip", pchar.GWIK.Job.ForceShipName); // strictly after AddQuestRecord
			AddQuestUserData("GWIK_RansomJob", "sCap", pchar.GWIK.Job.ForceCapName);
			dialog.text = "Tant pis pour toi, tête brמlée. Le navire « "+ pchar.GWIK.Job.ForceShipName +" » du capitaine "+ pchar.GWIK.Job.ForceCapName +" est déjà en mer au large des Bermudes, avec le captif dans sa cale. Va l'attraper, et souviens-toi de ce que j'ai dit à propos du fond.";
			link.l1 = "Je le trouverai, et je libérerai le captif.";
			link.l1.go = "exit";
		break;

		case "pay":
			AddMoneyToCharacter(pchar, -iRansom);
			GWIK_RansomPay();
			AddQuestRecord("GWIK_RansomJob", "2");
			dialog.text = "Et voilà. Le capitaine est déjà sur ton navire : mes gars l'ont vu monter à bord. Et dis aux Hollandais : s'ils continuent à payer aussi vite, on capturera leurs gens plus souvent, hé hé.";
			link.l1 = "Drכle de sens de l'humour...";
			link.l1.go = "exit";
		break;

		case "Mutiny_Persuade": // Gregg: attempt to talk the runaway captain into returning peacefully (Leadership check)
			leadSkill = GetSummonSkillFromName(pchar, SKILL_LEADERSHIP);
			if (leadSkill >= 25 + sti(pchar.rank)) // Gregg: threshold = Leadership skill (0-100 scale, NOT the 1-10 attribute) >= 25 + player rank - scales with the player; the captain's authority won out, the runaway agrees to return
			{
				pchar.GWIK.Job.MutinyReturnedSelf = true; // he sails back on his own - NO passenger spawned (collect the reward by reporting at an office, node GWIK_MutinyReturnReport)
				AddDialogExitQuestFunction("GWIK_MutineerDepart"); // after the dialog closes the runaway leaves the tavern (deferred - nulling an interlocutor's location is only safe post-close; officer-hire pattern)
				AddQuestRecord("GWIK_RansomJob", "14");
				dialog.text = "...Ah, au diable tout ça. Tu as raison : je ne tiendrai pas longtemps sous ce pavillon, et la Compagnie, au moins, paie à l'heure. Bon, le Hollandais, tu as gagné. Je rejoindrai un comptoir par mes propres moyens et j'avouerai tout ; on se verra là-bas.";
				link.l1 = "Sage décision. Je t'attendrai au comptoir.";
				link.l1.go = "exit";
			}
			else
			{
				pchar.GWIK.Job.MutinyRefused = true; // the peaceful path is closed - now only report or take by force
				dialog.text = "Belles paroles, le Hollandais, mais tu ne me convaincras pas. Ma décision est prise. Soit tu déguerpis tant que tu le peux, soit tu me prends de force, mais ne t'attends pas à une proie facile.";
				link.l1 = "Soit : la Compagnie apprendra que tu es un traître. (dénoncer)";
				link.l1.go = "Mutiny_Report";
				link.l2 = "Tu ne veux pas venir par la manière douce ? Alors, je te prendrai de force. Prends la mer.";
				link.l2.go = "Mutiny_Threaten";
				link.l3 = "Il faut que j'y réfléchisse.";
				link.l3.go = "exit";
			}
		break;

		case "Mutiny_Threaten": // Gregg: threaten to take him - the runaway puts to sea hostile (force path; capture = captain recovered, sinking = failure)
			DeleteAttribute(pchar, "GWIK.Job.MutinyReportReady"); // changed his mind about reporting - going the force route
			if (!GWIK_RansomForceSpawn("Pirates")) // his ship puts out to sea off Bermuda (Force=true)
			{
				dialog.text = "Mes gars sont plongés dans leurs chopes en ce moment, le navire n'est pas en état de naviguer. Repasse plus tard : on réglera ça à la manière des marins.";
				link.l1 = "Je reviendrai.";
				link.l1.go = "exit";
				break;
			}
			AddQuestRecord("GWIK_RansomJob", "13");
			AddQuestUserData("GWIK_RansomJob", "sShip", pchar.GWIK.Job.ForceShipName); // strictly after AddQuestRecord
			AddQuestUserData("GWIK_RansomJob", "sType", pchar.GWIK.Job.ForceShipType); // Gregg: ship type instead of the captain's name - @<sCap> here is the PIRATE (random name), not the runaway; was misleading
			dialog.text = "Ha ! Tu n'es pas un lâche, hein. Très bien, prends la mer, le Hollandais : mon équipage est déjà à bord du « "+ pchar.GWIK.Job.ForceShipName +" ». Rattrape-le et aborde-le, et tu as gagné. Sinon, tu nourriras les poissons. Mais souviens-toi : si tu l'envoies par le fond, tu me noies aussi, et mort, je ne sers plus à rien à la Compagnie.";
			link.l1 = "Prends la mer. Je te retrouverai là-bas.";
			link.l1.go = "exit";
		break;

		case "Mutiny_Report": // Gregg: give up and report to the Company that the captain turned coat (a token compensation at the office)
			pchar.GWIK.Job.MutinyReportReady = true; // report at a GWIC office (node GWIK_MutinyReport)
			AddQuestRecord("GWIK_RansomJob", "15");
			dialog.text = "File donc, rapporteur. Seulement, ta Compagnie n'est plus ma maîtresse : je suis un homme libre. Déguerpis tant que tu as encore tous tes os.";
			link.l1 = "Tu le regretteras.";
			link.l1.go = "exit";
		break;

		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
