// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Encore des questions, " + GetAddress_Form(NPChar) + "...", "Des questions, des questions... Et si on faisait plutכt du commerce, " + GetAddress_Form(NPChar) + " ?",
                          "וcoutez, combien de conversations creuses peut-on avoir ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Pas de questions...", "Je n'ai rien à dire pour le moment."), "Eh, encore...",
                      "Oui, il vaut vraiment mieux marchander...", "Hum, désolé, marchand...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(CheckAttribute(pchar, "questTemp.PDM_ONV_Detectiv_Jiteli_Beliz"))	// Квест "Witch Hunt"
            {
    			link.l1 = RandPhraseSimple("Excusez-moi, vous n'auriez pas vu Maria ?", "Savez-vous oם est Maria ?");
    			link.l1.go = "PDM_ONV_Prodavec";
			}
		break;
		
//**************************Квест "Witch Hunt"*******************************
		case "PDM_ONV_Prodavec":
			dialog.text = dialog.text = RandPhraseSimple("Je "+ GetSexPhrase("suis marchand", "suis marchande") +", et non un fournisseur de ragots.", "Vous achetez, ou vous venez juste faire marcher votre langue ?", "Maria ? Non, moi, je vends des fruits. Achetez un fruit, de préférence deux.");
			link.l1 = "Désolé.";
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

