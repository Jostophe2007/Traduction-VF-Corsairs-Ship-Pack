
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag, arChestItems;
	string sBlade;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je ne veux pas parler.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//должок ростовщика ГПК
		case "ClimeUsurer":
			dialog.text = "Tu as une dette envers mon adepte nommé Augusto Brahms !";
			link.l1 = "Moi ? Ah, eh bien, oui, il y a eu une histoire... Hum, mais je ne savais pas que c'était ton adepte.";
			link.l1.go = "ClimeUsurer_1";
		break;
		case "ClimeUsurer_1":
			dialog.text = "Il n'empêche que c'est ainsi. Tu dois me remettre " + FindRussianMoneyString(sti(pchar.questTemp.LSC_climeUsurer.qtyMoney )) + " immédiatement. As-tu assez d'argent ?";
			if (sti(pchar.money) >= sti(pchar.questTemp.LSC_climeUsurer.qtyMoney))
			{
				link.l1 = "Euh, oui...";
				link.l1.go = "ClimeUsurer_yes";
			}
			else
			{
				link.l1 = "Tout ça est un peu inattendu... Je ne savais pas que je devrais rembourser si vite.";
				link.l1.go = "ClimeUsurer_no";
			}
		break;
		case "ClimeUsurer_yes":
			dialog.text = "Bien. Alors, je te laisse partir.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.LSC_climeUsurer.qtyMoney));
			LAi_CharacterDisableDialog(npchar);
			AddDialogExitQuestFunction("ClimeUsurer_haveMoney");
		break;
		case "ClimeUsurer_no":
			dialog.text = "Tu ne savais pas ?!! Alors tu resteras pour toujours dans le temple du Sacrifice ! Un crâne de plus, un de moins...";
			link.l1 = "Comment ça ?!";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ClimeUsurer_noMoney");
		break;

		//в большом храме разговор перед боевкой
		case "InGreateTemple":
			dialog.text = "Comment oses-tu, mortel ?!!";
			link.l1 = "דa alors !.. Si je ne m'abuse, tu es le dieu des morts.";
			link.l1.go = "InGreateTemple_1";
		break;
		case "InGreateTemple_1":
			dialog.text = "C'est exact, je t'observe depuis longtemps, tes errances dans Tenochtitlan m'ont bien diverti. Mais maintenant, tu as pris l'objet de mon culte, et ce n'est plus drכle...";
			link.l1 = "Vois-tu, cher dieu, cet objet m'a été commandé par un certain Aztèque, dont on ne prononce pas le nom ici.";
			link.l1.go = "InGreateTemple_2";
		break;
		case "InGreateTemple_2":
			dialog.text = "Montezuma ? Haha, il ne se calmera donc jamais. Quoique, il ne peut pas en être autrement.. Bon, tu as touché au crâne de jade, et c'est un crime. Mais tu as réussi à neutraliser la garde, composée de héros du passé : les Aztèques vénéraient la valeur militaire plus que tout au monde. Tu as montré que tu étais un bon guerrier, "+ GetSexPhrase(""," bien que tu sois une femme,") +" c'est pourquoi je vais te donner une chance de survivre. Prouve que tu es un grand guerrier, et tu pourras sortir d'ici.";
			link.l1 = "Que dois-je faire ?";
			link.l1.go = "InGreateTemple_3";
		break;
		case "InGreateTemple_3":
			dialog.text = "Bats-toi contre moi. Commençons !";
			link.l1 = "Pas le choix...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("Teno_fightInTemple");
		break;

		//в большом храме разговор после боевки
		case "WinInTemple":
			dialog.text = "Bien, tu as prouvé que tu le méritais. Maintenant, tu peux sortir d'ici en vie.";
			link.l1 = "Ouf... Si tu veux, je remets le crâne à sa place.";
			link.l1.go = "WinInTemple_1";
		break;
		case "WinInTemple_1":
			dialog.text = "Inutile, j'en ai beaucoup. Tu peux garder le crâne, tu l'as mérité.";
			link.l1 = "Merci, cher dieu.";
			link.l1.go = "WinInTemple_2";
		break;
		case "WinInTemple_2":
			dialog.text = "Avant que tu ne partes, je veux te dire qui est Montezuma.";
			link.l1 = "Je t'écoute avec grand intérêt.";
			link.l1.go = "WinInTemple_3";
		break;
		case "WinInTemple_3":
			dialog.text = "C'est Montezuma II, le dernier souverain de l'Empire aztèque. Il y a 150 ans, il a trahi les dieux de son peuple en tentant de négocier avec les missionnaires espagnols pour se convertir au christianisme\n"+
				"Nous, les dieux aztèques, ne lui avons pas pardonné sa trahison et avons maudit Montezuma, même si, au bout du compte, presque tous les dieux ont dמ partir dans les limbes. Je suis le seul à être resté ici.";
			link.l1 = "Pardon, partir oם ? Dans les limbes ?";
			link.l1.go = "WinInTemple_4";
		break;
		case "WinInTemple_4":
			dialog.text = "Les dieux ne vivent que tant que les hommes les vénèrent. Si l'on oublie les dieux, ils doivent partir dans les limbes, le monde de l'oubli. Je ne suis resté sur Terre que parce que tout le peuple aztèque m'appartient désormais, car tous les Aztèques ont été exterminés par les Espagnols, privés de notre aide.\n"+
				"J'ai le pouvoir de faire vivre aux corps morts une nouvelle vie. Devenu le maître de Tenochtitlan, je relève les défunts dont j'ai besoin pour me servir.\n"+
				"Montezuma est maudit, le passage vers le royaume des morts lui est fermé, et il est condamné à errer éternellement sur les rives du lac Texcoco en pleurant le sort de son peuple.";
			link.l1 = "C'est donc un fantכme ?!";
			link.l1.go = "WinInTemple_5";
		break;
		case "WinInTemple_5":
			dialog.text = "On peut dire ça. Maintenant, tu sais qui est l'Aztèque des rives du Texcoco. Et sache que le crâne de jade a du pouvoir sur les morts, et qu'il peut aussi aider les vivants maudits. Adieu, guerrier.";
			link.l1 = "Adieu, cher Mitklan... Mictlan...";
			link.l1.go = "WinInTemple_6";
		break;
		case "WinInTemple_6":
			chrDisableReloadToLocation = false;
			ChangeCharacterAddress(npchar, "none", "");
			AddQuestRecord("Tenochtitlan", "4");
			AddQuestUserData("Tenochtitlan", "sSex", GetSexPhrase("", "e"));
			DialogExit();
		break;

		case "Samil":
			dialog.text = "Tu m'as impressionné, mortel. Personne n'avait jamais réussi à vaincre mon incarnation terrestre. Sache que tu vois devant toi Yum Cimil en personne !";
			link.l1 = "Yum... qui ça ? Je suis entré dans ce temple pour y trouver des objets de valeur, mais je n'y ai absolument rien trouvé, à part toute une armée de morts-vivants.";
			link.l1.go = "Samil_2";
			if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_1_man");
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_1_woman");
		break;

		case "Samil_2":
			dialog.text = "Combien d'années ont passé pour que les mortels aient déjà oublié mon nom...";
			link.l1 = "Je pense que ça fait beaucoup, beaucoup d'années. Je n'ai jamais entendu parler de toi.";
			link.l1.go = "Samil_3";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_2");
		break;

		case "Samil_3":
			dialog.text = "Je crois que c'est le sort de tous les dieux des civilisations aujourd'hui disparues. Ils sont oubliés dans le vide et perdent leur force, faute d'un afflux de force venu des croyants...";
			link.l1 = "...";
			link.l1.go = "Samil_4";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_3");
		break;

		case "Samil_4":
			dialog.text = "Bon, ne parlons pas de choses tristes. Tu m'as battu et tu mérites une récompense. Je pense que cette lame d'un précédent visiteur te sera utile.";
			link.l1 = "Merci, Yum Cimil.";
			link.l1.go = "Samil_5";
			RemoveCharacterEquip(npchar, BLADE_ITEM_TYPE);
			log_info("Vous avez reçu de Yum Cimil une flamberge à une main et demie");
			UnlockAchievement("AchUmSamil", 3);
			TakeNItems(pchar,"blade48",1);
			TakeNItems(pchar,"pistol9",1);
			TakeNItems(pchar,"talisman18",1);
			if (pchar.sex != "woman") LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_4_man");
			else LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_4_woman");
		break;

		case "Samil_5":
			dialog.text = "Je crois qu'il est temps de se dire adieu. Parle de cette rencontre aux gens. Je ne veux pas être oublié pour toujours comme tous les autres... Je ne peux pas non plus te demander de me vénérer, nos cultures sont trop différentes. Adieu, guerrier.";
			link.l1 = "Je promets de ne jamais oublier notre rencontre. Adieu !";
			link.l1.go = "Samil_6";
			LAi_CharacterPlaySoundAtOnce(NPChar, "Samil_5");
		break;

		case "Samil_6":
			chrDisableReloadToLocation = false;
			ChangeCharacterAddress(npchar, "none", "");
			// Gregg: возврат из сокровищницы делаем сами, а не ждём, пока игрок снова наступит на
			// teleport6 - он на нём и так стоит, и перевзвод портала по занятому локатору багует.
			// Запускаем штатную цепочку выхода: затемнение, возврат на teleport5, recharge_portals.
			// Стоп-флаг questTemp.UmSamilRoom НЕ снимаем: игрок приземлится прямо на teleport5, и
			// перевзвод отбросил бы его обратно в сокровищницу. Эта пара порталов отработала.
			LAi_QuestDelay("treasure_portal", 0.5);
			DialogExit();
		break;

		case "Uicilopochtli_F_0":
			dialog.text = "Salutations, mortel" + GetSexPhrase(".","le.");
			link.l1 = "Hum... Bonjour, Mictlan... Mictlan...";
			link.l1.go = "Uicilopochtli_F_1";
		break;

		case "Uicilopochtli_F_1":
			dialog.text = "Quoi ?! Comment oses-tu ! Je suis Huitzilopochtli, le dieu de la guerre, le plus puissant guerrier parmi les hommes et les dieux, et Mictlantecuhtli ne m'arrive pas à la cheville en force et en endurance. Tu m'as insulté, et pour cela, tu vas souffrir d'une mort douloureuse. Prépare-toi à voir ce que vaut Huitzilopochtli au combat !";
			link.l1 = "Oh, bon sang...";
			link.l1.go = "Uicilopochtli_F_2";
		break;

		case "Uicilopochtli_F_2":
			dialog.text = "Haha, tu trembles ? Alors comme ça, on ne peut même plus plaisanter ? Ha ha ha ! Calme-toi, je ne vais pas me jeter sur toi parce que tu as touché à la dalle. Ha ha ha !";
			link.l1 = "Ouf, merci. א vrai dire, le combat contre Mictlantecuhtli m'a suffi...";
			link.l1.go = "Uicilopochtli_F_3";
		break;

		case "Uicilopochtli_F_3":
			dialog.text = "Oui, Miklukha est égal à lui-même... Il t'a sans doute raconté que le crâne est un objet de culte auquel on ne doit pas toucher ? Ah oui, et comment compte-t-il célébrer ses rituels sans toucher au crâne ? Sache que ce personnage voulait simplement t'ajouter à sa collection. Il adore les âmes des guerriers tombés, et voilà que " + GetSexPhrase("s'est présenté un tel virtuose de l'épée","s'est présentée une telle virtuose de l'épée") + " comme toi.";
			link.l1 = "Heureusement que j'ai réussi à me tirer de ce pétrin. Je n'aimerais pas devenir pour toujours le gardien de Tenochtitlan.";
			link.l1.go = "Uicilopochtli_F_4";
		break;

		case "Uicilopochtli_F_4":
			dialog.text = "Ne m'en parle pas : tu serais " + GetSexPhrase("mort","morte") + " d'ennui, haha ! Et il était grand temps de rabattre le caquet au « dieu mort » : il est devenu si prétentieux depuis la chute des Aztèques... Pendant que tout le monde s'ennuie dans les limbes, lui se promène ici avec ses jouets et n'est jamais venu nous voir. Il n'a même pas rendu visite à Mictecacihuatl, la pauvre est restée complètement privée d'attentions masculines, tu imagines ? Et pourtant, je lui avais proposé : tu as toute une armée ici, je lui dis, organisons un massacre entre eux, amusons-nous, dégourdissons-nous les os ! Mais lui, toujours non : il est occupé, tu comprends, il faut garder Tenochtitlan. Eh bien, à force de monter la garde, voilà que tu " + GetSexPhrase("es venu massacrer toute sa garde","es venue massacrer toute sa garde") + ", ha ha !";
			link.l1 = "C'est donc ça... Au fait... Sans vouloir te manquer de respect, cher dieu, si tous les dieux sauf Mictlantecuhtli sont dans les limbes, comment se fait-il que tu sois ici ?";
			link.l1.go = "Uicilopochtli_F_5";
		break;

		case "Uicilopochtli_F_5":
			dialog.text = "Je ne te le reprocherai pas, " + GetSexPhrase("l'ami","ma chérie") + ". Oui, je suis resté coincé très longtemps dans les limbes, sans pouvoir en sortir. Mais ensuite, tu " + GetSexPhrase("as déclenché", "as déclenché") + " une sacrée bagarre avec les esprits des guerriers aztèques, et cela a tiré la gloire militaire aztèque de l'oubli et renforcé ma puissance de dieu de la guerre. א un moment donné, j'ai senti que je pouvais venir ici, et j'ai décidé de ne pas laisser passer l'occasion, car tu " + GetSexPhrase("m'as rendu","m'as rendu") + " un service qui mérite une récompense. Désormais, je t'autorise à accomplir le rituel d'adoration de Huitzilopochtli !";
			link.l1 = "Hum, merci...";
			link.l1.go = "Uicilopochtli_F_6";
		break;

		case "Uicilopochtli_F_6":
			dialog.text = "דa n'a pas l'air de te réjouir, hein ? Ce n'est rien, je vais tout t'expliquer. Le rituel d'adoration consiste à faire un sacrifice et à demander qu'on te donne de la force pour les batailles à venir. Et si tu fais tout correctement, tu obtiens cette force : ta lame devient meilleure.";
			link.l1 = "Ah, donc tu peux améliorer mon arme ?";
			link.l1.go = "Uicilopochtli_F_7";
		break;

		case "Uicilopochtli_F_7":
			dialog.text = "Oui, je le peux, si tu accomplis le rituel. Tu ne croyais tout de même pas que c'était Mictlantecuhtli qui rendait les macuahuitl si meurtriers ? Mais laisse-moi juste énoncer quelques limites. Premièrement, je n'améliorerai pas l'arme au-delà de ses possibilités techniques. Je le pourrais, mais elle deviendrait alors une arme magique des dieux, et... eh bien, une telle lame entre des mains humaines n'a jamais rien apporté de bon. Mais je suis sמr que tu sentiras quand même l'amélioration. Deuxièmement, je ne peux améliorer qu'une seule caractéristique à la fois : réduire le poids, ou augmenter les dégâts minimaux ou maximaux. Tu ne pourras choisir ni la caractéristique ni l'ampleur de l'amélioration : après tout, l'adoration d'un dieu n'est pas une science exacte. Mais tu pourras accomplir de nombreux rituels sur la même lame, et au bout d'un certain nombre, ton arme atteindra la perfection.";
			link.l1 = "דa a l'air bien. Et les victimes ? Il te faudra beaucoup de prisonniers ?";
			link.l1.go = "Uicilopochtli_F_8";
		break;

		case "Uicilopochtli_F_8":
			dialog.text = "Non, je n'ai pas besoin de tes prisonniers. Je n'ai jamais aimé ces coutumes. Des cris, encore des cris : ils sont bons quand l'ennemi les pousse dans une bataille loyale, pas quand il est attaché à l'autel. J'ai longtemps essayé d'expliquer aux Aztèques que les sacrifices humains, c'était l'affaire de Mictlantecuhtli, mais rien à faire : ils adoraient vraiment découper les gens. Le rituel doit comporter deux parties. La première, ce sont les armes des ennemis vaincus. Pour un rituel, il te faudra trois autres lames de la même qualité que ton arme. La seconde, c'est de l'or, pour un montant équivalent à trois fois la valeur de la lame. Je n'en ai pas vraiment besoin, c'est juste une tradition, et on ne peut pas s'en passer. Il y a des chamanes chez ton peuple ? Ils ne te parleront sans doute même pas sans or, n'est-ce pas ?";
			link.l1 = "Héhé, oui, on ne peut pas dire le contraire.";
			link.l1.go = "Uicilopochtli_F_9";
		break;

		case "Uicilopochtli_F_9":
			dialog.text = "Alors, j'essaie de ne pas passer pour un mouton noir... Bref, tu rassembles tout ça, tu le poses sur l'autel, tu t'adresses à moi, et si tout va bien, je prends l'offrande et j'améliore la lame que tu as équipée. Et ne t'inquiète pas : si quelque chose cloche, par exemple si l'offrande posée sur l'autel ne suffit pas ou si ta lame ne peut plus être améliorée, je ne tricherai pas, je te dirai tout tel quel, et tout ce qui est sur l'autel te restera.";
			link.l1 = "Compris. Et comment dois-je m'adresser à toi ?";
			link.l1.go = "Uicilopochtli_F_10";
		break;

		case "Uicilopochtli_F_10":
			dialog.text = "Eh bien, demande simplement du fond du cœur, haha ! Au bout du compte, c'est un marché profitable pour nous deux : toi, tu obtiens de meilleures armes, et moi, l'adoration qui nourrit mes pouvoirs divins. Alors viens, ne sois pas timide."
			link.l1 = "Eh bien, merci pour cette possibilité, cher dieu. Je passerai à l'occasion.";
			link.l1.go = "Uicilopochtli_exit";
			LAi_SetStayType(NPChar);
		break;

		case "Uicilopochtli_exit":
			NPChar.dialog.currentnode = "Uicilopochtli_default";
			DialogExit();
		break;

		case "Uicilopochtli_default":
			dialog.text = "Salutations, mortel" + GetSexPhrase(".","le.");
			link.l1 = "Ô grand dieu de la guerre Huitzilopochtli ! Je t'offre en présent les armes des ennemis que j'ai vaincus et je te demande de me donner de la force pour les batailles à venir !";
			link.l1.go = "Uicilopochtli_improve";

			if (CheckAttribute(pchar,"ScamFanActive") && CheckAttribute(pchar,"KnowScam") && !CheckAttribute(pchar,"ScamDestroyed"))
			{
				link.l2 = "Bonjour, Huitzilopochtli. Pardon de te déranger, mais j'ai un problème...";
				link.l2.go = "Uicilopochtli_fan_1";
			}

			link.l3 = "Bonjour, Huitzilopochtli. Je suis juste " + GetSexPhrase("passé te saluer...", "passée te saluer...");
			link.l3.go = "Uicilopochtli_exit";
		break;

		case "Uicilopochtli_improve":
			sBlade = GetCharacterEquipByGroup(PChar, BLADE_ITEM_TYPE);
			if (sBlade == "")
			{
				dialog.text = "Je ne demanderais pas mieux, mais tu n'as pas équipé de lame" + GetSexPhrase(".",".");
				link.l1 = "C'est vrai ! Je règle ça tout de suite.";
				link.l1.go = "Uicilopochtli_exit";
				break;
			}

			if (BladeIsPerfect(sBlade))
			{
				dialog.text = "Merci pour les présents, mais le fait est que ta lame a déjà atteint ses limites de perfection, alors je ne peux pas l'améliorer davantage, désolé.";
				link.l1 = "Ah bon ? D'accord.";
				link.l1.go = "Uicilopochtli_exit";
				break;
			}

			makearef(arChestItems, Locations[FindLocation(PChar.location)].box1);
			if (!TryTakeSacrificeForBladeImprovement(arChestItems, sBlade))
			{
				dialog.text = "Ton sacrifice ne suffit pas. Je te rappelle qu'il te faut trois lames d'une qualité équivalente à la tienne et de l'or pour un montant équivalent à trois fois la valeur de ta lame.";
				link.l1 = "D'accord, comme vous voudrez.";
				link.l1.go = "Uicilopochtli_exit";
				break;
			}

			RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			TakeItemFromCharacter(PChar, sBlade);
			sBlade = ImproveGeneratedBlade(sBlade, 0.25);
			GiveItem2Character(PChar, sBlade);
			EquipCharacterByItem(PChar, sBlade);
			Dialog.Text = "Merci, mortel" + GetSexPhrase(".","le.");
			link.l1 = "Merci à toi aussi, cher dieu.";
			link.l1.go = "Uicilopochtli_exit";
		break;

		case "Uicilopochtli_fan_1":
			dialog.text = "Un problème ?"
			link.l1 = "Oui. Tu vois cet épouvantail qui court derrière moi ? Je veux m'en débarrasser, mais je n'y arrive pas. J'ai déjà essayé : ni la rapière, ni le ciseau, ni le mousquet n'en viennent à bout. Et ce ne serait rien, mais il est tellement agaçant que je vais bientכt perdre la tête.";
			link.l1.go = "Uicilopochtli_fan_2";
		break;

		case "Uicilopochtli_fan_2":
			dialog.text = "Voilà donc ce qu'il en est. Attends une minute... Mais c'est l'imbécile que Mictlantecuhtli a rendu immortel, haha ! Je n'arrive pas à croire que tu n'aies pas encore perdu la tête : ce type est capable de faire fondre la cervelle de n'importe qui."
			link.l1 = "On dirait qu'encore un peu et ma cervelle va fondre... Tu peux faire quelque chose ?";
			link.l1.go = "Uicilopochtli_fan_3";
		break;

		case "Uicilopochtli_fan_3":
			dialog.text = "Oui, je vais l'emmener dans les limbes. Camaxtli n'a pas chassé depuis longtemps, ça va amuser le vieux... Bon, tu mérites une récompense. Tiens, je te donne une lame d'une valeur égale à ce personnage, haha ! Ne me remercie pas, ha ha ha !"
			link.l1 = "Merci, Huitzilopochtli ! Tu m'as épargné la folie, et tu m'as donné une arme...";
			link.l1.go = "Uicilopochtli_exit";

			ref rChar = CharacterFromID("ScamCharacter");
			rChar.LifeDay = 0;
			ChangeCharacterAddressGroup(rChar, "none", "", "");
			pchar.ScamDestroyed = true;
			Log_info("Scam Games, le fan le plus dévoué du champion de l'arène, vous laisse tranquille pour de bon.");

			GiveItem2Character(PChar, GenerateBladeByParams("blade28", 1, 1, 25));
		break;
	}
}

bool TryTakeSacrificeForBladeImprovement(aref arChestItems, string sBlade)
{
	int price = GetItemPrice(sBlade) * 3;
	if (sti(arChestItems.money) < price)
	{
		return false;
	}

	object bladesToTake;
	aref arBlades, arItem;
	makearef(arBlades, arChestItems.Items);
	string sCurrBlade, sCurrBladeQuality;
	string sBladeQuality = ItemsFromID(sBlade).quality;
	int bladesCount = 3;
	int i, num;
	for (i = 0; (i < GetAttributesNum(arBlades)) && (bladesCount > 0); i++)
	{
		arItem = GetAttributeN(arBlades, i);
		sCurrBlade = GetAttributeName(arItem);
		num = sti(GetAttributeValue(arItem));

		if (!IsBlade(sCurrBlade))
		{
			continue;
		}

		sCurrBladeQuality = ItemsFromID(sCurrBlade).quality;
		if (sCurrBladeQuality == sBladeQuality)
		{
			num = func_min(num, bladesCount);
			bladesToTake.(sCurrBlade) = num;
			bladesCount = bladesCount - num;
		}
	}

	if (bladesCount > 0)
	{
		return false;
	}

	arChestItems.money = sti(arChestItems.money) - price;
	makearef(arBlades, bladesToTake);
	for (i = 0; i < GetAttributesNum(arBlades); i++)
	{
		arItem = GetAttributeN(arBlades, i);
		sCurrBlade = GetAttributeName(arItem);
		num = sti(GetAttributeValue(arItem));
		TakeNItems(arChestItems, sCurrBlade, -num);
	}
	return true;
}
