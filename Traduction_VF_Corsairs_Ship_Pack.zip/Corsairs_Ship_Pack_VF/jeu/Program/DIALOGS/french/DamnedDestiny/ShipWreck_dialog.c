
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = GetFullName(PChar);
	string sCharacter = "";

	int iShip = 0;
	int iCrew = 0;
	int iShipSP = 0;
	int iShipHP = 0;

	string sShipName = "";

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Merci encore pour ce service.";
			link.l1 = "Il n'y a pas de quoi.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Merci, Seigneur !!!";
			link.l1 = "Je m'appelle " + GetFullName(PChar) + " ! Je suis capitaine du navire « " + PChar.Ship.Name + " ». Que vous est-il arrivé ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je me présente : capitaine " + GetFullName(NPChar) + ". Nous avons été pris dans une tempête il y a une semaine.";
			link.l1 = "Bon sang ! דa devait être une tornade !";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "C'était la tempête la plus terrible et la plus violente que j'aie jamais vue dans cet archipel. Et j'en ai vu beaucoup, croyez-moi. Pendant trois jours, nous avons été ballottés dans ce chaos, et à la fin du quatrième jour, alors que la tempête s'était déjà calmée, deux mâts se sont brisés d'un coup. Les matelots n'ont même pas eu le temps de les retenir : tout a été emporté par-dessus bord en un instant. Quand cette horreur a pris fin, mon second a constaté qu'il manquait plus de la moitié de notre équipage ! Nous dérivons dans ces eaux depuis plusieurs jours. Vous êtes les premiers que nous croisons.";
			link.l1 = "Je compatis sincèrement ! Si je peux vous aider en quoi que ce soit...";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Voyez-vous, capitaine, nous pourrions partir avec vous ; je pense qu'il y aurait assez de place sur votre navire. Mais le fait est que dans la cale de mon navire se trouve une cargaison que je dois livrer à destination. Je ne veux pas trop vous déranger, je vous demande seulement de prendre mon homme à bord et de le déposer dans la colonie la plus proche...";
			link.l1 = "Bien sמr.";
			link.l1.go = "YesYes";
			link.l2 = "Excusez-moi, mais je ne peux pas vous aider...";
			link.l2.go = "NotNot";
		break;

		case "YesYes":
			ShipWreckInSeaWait();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "NotNot":
			ShipWreckInSeaCancel();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "5":
			sCharacter = PChar.GenerateShipWreck.CharacterID;
			SetCameraDialogMode(CharacterFromID(sCharacter));
			dialog.text = GetFullName(CharacterFromID(sCharacter)) + ": " + npchar.name + ", tu ouvriras ce paquet une fois à terre. Pas avant. Il contient des instructions supplémentaires.";
			link.l1 = GetFullName(NPChar) + " : Compris, capitaine.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckInSeaWaitEnd");
		break;

		case "6":
			dialog.text = "Vous êtes capitaine depuis longtemps ?";
			link.l1 = "Oh, c'est une longue histoire.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Alors, vous comprenez ce que je ressens en ce moment. Pendant quinze ans, j'ai navigué sur ce navire, et en trois jours seulement, il s'est changé en baille en lambeaux. Il n'y a pas la moindre chance de le réparer. Quand le navire viendra nous chercher, je devrai saborder le mien. Je n'y survivrai pas...";
			link.l1 = "Tenez bon, " + GetAddress_FormToNPC(NPChar) + ". Il arrive des choses bien pires dans la vie.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Bon, assez de sentiments. א l'arrivée, mon homme vous remettra " + sti(PChar.GenerateShipWreck.Money) + " pièces d'or. C'est tout ce que je peux faire pour vous récompenser de votre aide.";
			link.l1 = "Vraiment, il ne fallait pas !";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Bonne route. Bonne chance, " + GetFullName(PChar) + " !";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckInSeaWaitEndToSea");
		break;

		case "10":
			dialog.text = "Ah, capitaine. Merci encore de nous avoir pris à bord.";
			link.l1 = "Il n'y a pas de quoi.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Puis-je vous demander oם nous allons ?";
			link.l1 = "Je ne peux pas... Bon sang, je ne peux pas !!!";
			link.l1.go = "12";
			link.l2 = "J'ai une affaire à te proposer. J'ai entendu dire qu'il y a une cargaison de valeur dans la cale de ton navire...";
			link.l2.go = "14";
		break;

		case "12":
			dialog.text = "Vous allez bien ? Il s'est passé quelque chose ?";
			link.l1 = "Mon navigateur vous informera de notre cap. Le déjeuner sera servi à midi. On viendra vous chercher.";
			link.l1.go = "exit";
			NextDiag.TempNode = "13";
		break;

		case "13":
			dialog.text = "Ah, capitaine. Merci encore de nous avoir pris à bord.";
			link.l1 = "Il n'y a pas de quoi.";
			link.l1.go = "exit";
			NextDiag.TempNode = "13";
		break;

		case "14":
			dialog.text = "Qu'est-ce que vous insinuez ?!";
			link.l1 = "J'aimerais savoir de quelle cargaison il s'agit. Et tu vas m'y aider. Ou bien...";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Ou bien ?";
			link.l1 = "Ou bien tu meurs, ici et maintenant.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Sale hypocrite ! Défends-toi, charogne !";
			link.l1 = "Eh...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBattleWithSailor");
		break;

		case "17":
			dialog.text = "Ordure ! Qu'est-ce qu'il te faut ?";
			link.l1 = "Juste votre or, " + GetAddress_FormToNPC(NPChar) + " " + GetFullName(NPChar) + ".";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Prends-le. Et fiche le camp !";
			link.l1 = "Je vais aussi prendre votre vie : vous savez bien que les morts ne parlent pas ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Quelle vipère j'ai réchauffée à bord de mon navire !";
			link.l1 = "...";
			link.l1.go = "exit";
			PChar.GenerateShipWreck.State = "none";
			LAi_SetCurHPMax(NPChar);
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;

		case "20":
			dialog.text = "Nous y voilà. Merci, capitaine, je me débrouillerai pour la suite.";
			link.l1 = "Eh bien. Bonne chance à toi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckInTownSuccess");
		break;

		case "21":
			dialog.text = "Qui êtes-vous ?";
			link.l1 = "J'ai exactement la même question.";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Je n'aime pas attendre.";
			link.l1 = "Du calme. Je suis le capitaine " + GetFullName(PChar) + ".";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Et qu'est-ce que tu viens faire à bord de ce navire ?";
			link.l1 = "Moi non plus, je n'aime pas attendre. Parfois, ça m'agace au plus haut point, et je risque alors de prendre une mauvaise décision à ton sujet.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Sacrebleu ! Je suis le navigateur de ce navire : " + GetFullName(NPChar) + ". Alors, qu'est-ce que vous voulez ici ?";
			link.l1 = "Je veux parler au capitaine.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "Le capitaine est malade. Pendant la tempête, il a été pris d'un accès de fièvre. Je le remplace pour l'instant.";
			link.l1 = "Vraiment ? Et ce sang sur le pont, c'est quoi ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Demande à notre coq. Il aime découper le poisson directement sur le pont, pour respirer l'air frais.";
			link.l1 = "Compris. Eh bien, messieurs, je ne vous retiens pas. Bonne traversée.";
			link.l1.go = "27";
			link.l2 = "וcoutez-moi bien, misérables va-nu-pieds...";
			link.l2.go = "36";
			link.l3 = "Tu te fiches de moi ?";
			link.l3.go = "45";
			link.l4 = "Je ne suis pas la patrouille maritime, mais je hais les traîtres. Alors, mieux vaut pour vous mourir : je ferai personnellement pendre les survivants à ce mât, là-bas. Aux armes, canailles !";
			link.l4.go = "41";
		break;

		case "27":
			dialog.text = "Attends. Comme tu vois, notre navire a essuyé une tempête. De la toile solide et une pile de planches ne nous feraient pas de mal. Qu'en dis-tu ?";

			if(GetCargoGoods(PChar, GOOD_PLANKS) > 0 || GetCargoGoods(PChar, GOOD_SAILCLOTH) > 0)
			{
				link.l1 = "Gratuit, c'est seulement au paradis.";
				link.l1.go = "28";
			}

			link.l2 = "Je te l'ai déjà dit : au revoir.";
			link.l2.go = "35";
		break;

		case "28":
			sCharacter = PChar.GenerateShipWreck.ValodyaID;
			SetCameraDialogMode(CharacterFromID(sCharacter));
			dialog.text = "" + characters[GetCharacterIndex(sCharacter)].name + ", cours voir le capitaine et emprunte-lui sa bourse.";
			link.l1 = "...";
			link.l1.go = "29";
			ShipWreckBandValodyaToMoney();
		break;

		case "29":
			SetCameraDialogMode(NPChar);
			dialog.text = "Tu veux un échange contre des marchandises ? Nous avons justement dans la cale une cargaison qui se vend bien.";
			link.l1 = "Je préfère les espèces sonnantes et trébuchantes.";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "Héhé.";
			link.l1 = "...";
			link.l1.go = "31";
		break;

		case "31":
			ShipWreckBandValodyaReturnWithMoney();
			dialog.text = "De l'or, va pour l'or. Combien peux-tu nous en céder ?";
			link.l1 = "Voyons voir.";
			link.l1.go = "32";
		break;

		case "32":
			PChar.GenerateShipWreck.GoodsChange = true;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchQuicklyTrade();
		break;

		case "33":
			dialog.text = "Tu as fini ?";
			link.l1 = "Tout à fait. La cargaison sera livrée par chaloupes. Et, navigateur, je te conseillerais de te trouver un autre titre à bord, et de remettre le coq dans sa cambuse. La patrouille de Sa Majesté pourrait ne pas comprendre.";
			link.l1.go = "34";
		break;

		case "34":
			PChar.GenerateShipWreck.GoodsChange.Yes = true;
			dialog.text = "Haha.";
			link.l1 = "Bonne traversée.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsOneTypeEnd");
		break;

		case "35":
			PChar.GenerateShipWreck.GoodsChange.Yes = false;
			ShipWreckBanditsOneTypeEnd();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "36":
			dialog.text = "Comment tu me parles, chien ?";
			link.l1 = "Je sais encore reconnaître le sang humain. Vous n'avez essuyé aucune tempête. Je ne sais pas lequel d'entre vous a abattu les mâts et déchiré les voiles. Il a aussi mis le feu à ces barils de poudre, mais il avait clairement perdu la tête. Vous direz à la patrouille navale que votre capitaine est malade, elle montera à votre bord et vous pendra comme des mutins à ce mât unique, là-bas. Alors, sales rats, vous voulez vivre ?";
			link.l1.go = "37";
		break;

		case "37":
			sCharacter = PChar.GenerateShipWreck.ValodyaID;
			dialog.text = "Pour de telles paroles, je vais t'ouvrir le ventre moi-même.";

			if(sti(PChar.GenerateShipWreck.ToSquadron) == 1)
			{
				SetCameraDialogMode(CharacterFromID(sCharacter));
				link.l1 = GetFullName(CharacterFromID(sCharacter)) + " : Du calme, " + npchar.name + ". Il a plus d'hommes que nous, et tout un navire.";
				link.l1.go = "38";
			}
			else
			{
				link.l1 = "Eh bien, essaie, enfoiré !";
				link.l1.go = "41";
			}
		break;

		case "38":
			SetCameraDialogMode(NPChar);
			dialog.text = RandSwear();
			link.l1 = "Pour cette fois, je te pardonne, espèce de merde. Mais si j'entends encore quelque chose de ce genre, je te jette aux requins.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Vous voulez naviguer sous mes ordres ?";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "Bon sang, bien sמr ! J'ai entendu parler de vous.";
			link.l1 = "J'ai deux conditions. Premièrement, vous paierez un droit d'entrée pour passer sous mon commandement. Et deuxièmement, vous achèverez tous les prisonniers de l'ancien équipage.";
			link.l1.go = "42";
			link.l2 = "Vous devrez achever tous les prisonniers de l'ancien équipage.";
			link.l2.go = "43";
			link.l3 = "Ha ha, je plaisantais. Bonne traversée !";
			link.l3.go = "35";
		break;

		case "41":
			ShipWreckBanditsStartBattle();
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "42":
			if(sti(PChar.GenerateShipWreck.ToSquadronWithMoney) == 1)
			{
				sCharacter = PChar.GenerateShipWreck.ValodyaID;
				PChar.GenerateShipWreck.ValodyaToMoney = true;
				SetCameraDialogMode(CharacterFromID(sCharacter));
				dialog.text = "Nous sommes d'accord. " + characters[GetCharacterIndex(sCharacter)].name + ", tu sais ce qu'il te reste à faire.";
				link.l1 = "Je comprends.";
				link.l1.go = "exit";
				AddDialogExitQuestFunction("ShipWreckBandValodyaToMoney");
			}
			else
			{
				dialog.text = "Mais nous n'avons pas d'argent.";
				link.l1 = "Dans ce cas, filez. Bonne journée.";
				link.l1.go = "35";
				link.l2 = "Alors, préparez-vous à mourir, chiens !";
				link.l2.go = "41";
				link.l3 = "Soit, je vous prends.";
				link.l3.go = "43";
			}
		break;

		case "43":
			PChar.GenerateShipWreck.AddBandaShip = true;
			sCharacter = PChar.GenerateShipWreck.ValodyaID;
			dialog.text = "Nous sommes d'accord. " + characters[GetCharacterIndex(sCharacter)].name + ", tu sais ce qu'il te reste à faire.";
			link.l1 = "Parfait. Maintenant, au travail !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsOneTypeEnd");
		break;

		case "44":
			PChar.GenerateShipWreck.AddBandaShip = true;
			AddMoneyToCharacter(PChar, sti(PChar.GenerateShipWreck.Money));
			dialog.text = "Capitaine, voici l'argent. Il y a exactement " + sti(PChar.GenerateShipWreck.Money) + " piastres.";
			link.l1 = "Considérez-vous comme faisant partie de mon équipage. Et maintenant, nettoyez-moi ce rafiot. ET QUE דA SAUTE !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsOneTypeEnd");
		break;

		case "45":
			dialog.text = "De quoi parlez-vous ?";
			link.l1 = "Vous voyez ce navire, là-bas ? Eh bien, en un clin d'œil, il balaiera tous les culs de ce rafiot s'il m'arrive quelque chose. Maintenant, écoute-moi bien, espèce de merde. Tu es un mutin, et selon la loi, tu seras pendu à ce mât, là-bas. Et tout l'équipage avec toi. Alors, pour sauver vos âmes misérables, vous allez me payer. Si je ne vois pas cet argent dans cinq minutes, vous pourrez prier Dieu de loin pour obtenir sa miséricorde. Mais vous, les gars, vous n'irez clairement pas au paradis. Le compte à rebours commence.";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Tu oublies que tu es ici, et pas dans la cabine de ton navire. Je n'aurai aucun mal à t'embrocher.";
			link.l1 = "Je suis l'une des meilleures lames de cet archipel. Et j'ai avec moi une troupe d'abordage de combattants aguerris. Tu n'auras pas le temps de sortir ton coutelas rouillé que ta tête roulera déjà sur le pont. Compris ?";
			link.l1.go = "48";
		break;

		case "47":
			sCharacter = PChar.GenerateShipWreck.ValodyaID;
			dialog.text = "Pour de telles paroles, je vais t'ouvrir le ventre moi-même.";

			if(sti(PChar.GenerateShipWreck.ToSquadronWithMoney) == 1)
			{
				SetCameraDialogMode(CharacterFromID(sCharacter));
				link.l1 = GetFullName(CharacterFromID(sCharacter)) + " : Voici l'argent, " + npchar.name + ", nous n'avons pas le choix.";
				link.l1.go = "49";
			}
			else
			{
				link.l1 = "Eh bien, essaie, enfoiré !";
				link.l1.go = "41";
			}
		break;

		case "48":
			dialog.text = "...";
			link.l1 = "Trois minutes se sont écoulées. J'attends.";
			link.l1.go = "47";
		break;

		case "49":
			AddQuestRecord("ShipWreck", "8");
			AddMoneyToCharacter(PChar, sti(PChar.GenerateShipWreck.Money));
			SetCameraDialogMode(NPChar);
			dialog.text = "...";
			link.l1 = "Bien, vous avez sauvé votre peau. Je vous conseille de remplacer ce bon à rien, il n'a pas vraiment l'air d'un capitaine. Adieu. Et priez Dieu que je ne vous revoie pas.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsOneTypeEnd");
		break;

		case "NewCap_1":
			dialog.text = "Vous nous avez sauvés !";
			link.l1 = "Que s'est-il passé ici ?";
			link.l1.go = "NewCap_2";
		break;

		case "NewCap_2":
			dialog.text = "Je m'appelle " + GetFullName(NPChar) + " – je suis le vrai capitaine de ce navire. Il y a environ un mois, un navire pirate m'a abordé. Je ne serais pas en train de vous parler si la patrouille militaire n'était pas arrivée à temps. Nous avons réussi à les repousser tant bien que mal, et le navire ennemi a pris le large toutes voiles dehors. La patrouille n'a pas pu le rattraper. Je suis marchand, je transporte sans cesse des marchandises. J'ai dמ recruter un nouvel équipage dans l'un des ports. Il ne restait pas plus de trente hommes de l'ancien... Et maintenant, il n'en reste que " + sti(PChar.GenerateShipWreck.PrisonedCrew) + " hommes. Il y a une semaine, j'ai compris que j'avais engagé des canailles invétérées. Une nuit, ivres de rhum, ils ont fait sauter le cadenas de l'armurerie et se sont armés, puis ils se sont mis à saccager le navire en tuant tous ceux qu'ils croisaient. Je ne sais pas comment c'est arrivé, mais ils ont abattu eux-mêmes les mâts et fait sauter plusieurs barils de poudre. Heureusement, les brèches étaient petites. Une fois dessoמlés, ils nous ont enfermés dans cette cabine. La suite, vous la connaissez.";
			link.l1 = "Oui, vos chances de vivre un jour de plus étaient nulles.";
			link.l1.go = "NewCap_3";
		break;

		case "NewCap_3":
			dialog.text = "Comment vous appelez-vous ?";
			link.l1 = GetFullName(PChar) + ", capitaine du navire '" + PChar.Ship.Name + "'.";
			link.l1.go = "NewCap_4";
		break;

		case "NewCap_4":
			AddMoneyToCharacter(PChar, sti(PChar.GenerateShipWreck.Money));
			dialog.text = PChar.name + ", je vous remercie de m'avoir sauvé. Prenez cet or, en signe de grand respect.";
			link.l1 = "Je l'ai fait pour de nobles raisons. Dites-moi, qu'allez-vous faire maintenant ?";
			link.l1.go = "NewCap_5";
		break;

		case "NewCap_5":
			if(sti(PChar.GenerateShipWreck.ToSquadron) == 1)
			{
				dialog.text = "Je vous propose de prendre mon navire dans votre escadre. Vous avez prouvé votre honnêteté.";

				if(GetCompanionQuantity(PChar) < 5)
				{
					link.l1 = "Pourquoi pas. Avec plaisir.";
					link.l1.go = "NewCap_6";
				}

				link.l2 = "Malheureusement, je ne peux pas vous prendre dans mon escadre. Bonne chance à vous.";
				link.l2.go = "NewCap_7";
			}
			else
			{
				dialog.text = "La colonie la plus proche n'est pas si loin : nous y arriverons par nos propres moyens. Merci encore, capitaine.";
				link.l1 = "Au revoir.";
				link.l1.go = "exit";
				AddDialogExitQuestFunction("ShipWreckBanditsNewCapNoAdd");
			}
		break;

		case "NewCap_6":
			dialog.text = "Merci, capitaine. J'espère que nous pourrons travailler ensemble.";
			link.l1 = "Je n'en doute pas.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsNewCapAdd");
		break;

		case "NewCap_7":
			dialog.text = "Dommage. Alors, nous devrons y arriver par nos propres moyens.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ShipWreckBanditsNewCapNoAdd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
