// 03.02.08 перенос из ВМЛ

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref    sld;
	string attr, attrLoc;
	int    iTemp, iTax, iFortValue;

    Pchar.quest.FreeRandomOfficerIdx = NPChar.index;

	switch(Dialog.CurrentNode)
	{
		// -----------------------------------Диалог первый - первая встреча
		case "First time":

            NextDiag.TempNode = "First time";
			dialog.text = RandPhraseSimple("Salutations, capitaine ! Vous n'auriez pas besoin d'une femme officier sur votre baille ?",
                          "Vous avez besoin d'un nouvel officier, très compétent ?");
			link.l1 = ""+ GetSexPhrase("Une fille ? Un officier ? C'est très étrange... Et à quoi êtes-vous bonne ?", "Il y a déjà une femme à bord, et à quoi pourriez-vous servir ?") +"";
			link.l1.go = "Node_2";
            link.l2 = ""+ GetSexPhrase("Non, ma jolie, j'ai déjà mon effectif complet.", "Avec une allure pareille, allez plutכt voir les hommes... officier, tiens...") +"";
			link.l2.go = "exit";
		break;

		case "CitizenNotBlade":
			dialog.text = "Capitaine, quelle sottise ! Rangez vos armes avant de provoquer des ennuis !";
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			link.l1.go = "exit";
		break;

		case "Node_2":
            if (NPChar.alignment == "good" && sti(pchar.reputation) <= 70)
            {
                dialog.text = "Je suis bonne à bien des choses, mais nous ne travaillerons pas ensemble. Votre réputation n'est pas assez bonne. Je crois que je ne rejoindrai pas votre équipage.";
    			link.l1 = "Avec de telles exigences, vous resterez longtemps sans travail !";
    			link.l1.go = "exit";
    			break;
            }

            if (NPChar.alignment == "bad" && sti(pchar.reputation) >= 30)
            {
                dialog.text = "Je sais faire bien des choses, mais pas pour des saints comme vous, "+ GetSexPhrase("beau gosse", "ma belle") +". Je crois que je ne rejoindrai pas votre équipage.";
    			link.l1 = "Avec de telles exigences, vous resterez longtemps sans travail !";
    			link.l1.go = "exit";
    			break;
            }
			dialog.text = "Prenez-moi comme garde du corps, et votre dos sera toujours couvert par mon épée. L'agilité et la rapidité sont mes atouts.";
			link.l1 = "Un garde du corps personnel, mmm..."+ GetSexPhrase("", "en plus une fille...") +" Combien voulez-vous pour ce service ?";
			link.l1.go = "price";
            link.l2 = "Merci, je me débrouillerai.";
			link.l2.go = "exit";
			NextDiag.TempNode = "OnceAgain";
		break;

        case "OnceAgain":
            NextDiag.TempNode = "OnceAgain";
            if (NPChar.alignment == "good" && sti(pchar.reputation) <= 70)
            {
                dialog.text = "Je suis bonne à bien des choses, mais nous ne travaillerons pas ensemble. Votre réputation n'est pas assez bonne. Je crois que je ne rejoindrai pas votre équipage.";
    			link.l1 = "Avec de telles exigences, vous resterez longtemps sans travail !";
    			link.l1.go = "exit";
    			break;
            }

            if (NPChar.alignment == "bad" && sti(pchar.reputation) >= 30)
            {
                dialog.text = "Je sais faire bien des choses, mais pas pour des saints comme vous, "+ GetSexPhrase("beau gosse", "ma belle") +". Je crois que je ne rejoindrai pas votre équipage.";
    			link.l1 = "Avec de telles exigences, vous resterez longtemps sans travail !";
    			link.l1.go = "exit";
    			break;
            }
			dialog.text = "Vous avez changé d'avis, capitaine ? Vous avez décidé qu'un nouveau garde du corps, et une fille de surcroît, ne vous gênerait pas ?";
			link.l1 = "Peut-être bien. Combien voulez-vous ?";
			link.l1.go = "price";
            link.l2 = "Vous vous trompez. Portez-vous bien.";
			link.l2.go = "exit";
		break;

		case "price":
            if (FindFreeRandomOfficer() == -1)
            {
                dialog.text = "Hum. Votre effectif est complet. Nous parlerons du prix quand vous pourrez me donner un poste.";
    			link.l1 = "D'accord.";
    			link.l1.go = "exit";
    			break;
            }
			dialog.text = "Je pense que nous pouvons nous entendre sur 50 000 piastres.";
			link.l1 = "D'accord, ma jolie. Considérez-vous comme enrכlée dans l'équipage.";
			link.l1.go = "hire";
            link.l2 = "Vous ne valez pas cet argent. Au revoir.";
			link.l2.go = "exit";
		break;

        case "hire":
			if(makeint(Pchar.money) >= 50000)
			{
				AddMoneyToCharacter(Pchar, -50000);
                dialog.text = "Je ne vous remercierai pas, capitaine. Vous savez très bien que vous avez fait un bon placement.";
			    link.l1 = "J'aime à le croire.";
			    link.l1.go = "Exit_hire";
			}
			else
			{
				NextDiag.TempNode = "OnceAgain";
                dialog.text = "Hé, on dirait que vous avez des problèmes d'argent ! Désolée, capitaine, mais je ne travaille pas à crédit.";
				link.l1 = "Oh, bon sang !";
				link.l1.go = "Exit";
			}
		break;

        case "hired":
			NextDiag.TempNode = "Hired";
			dialog.text = ""+ GetSexPhrase("Que veut mon précieux capitaine ?", "Quels sont les ordres ?") +"";
			link.l2 = "Vous êtes renvoyée. Je me passerai de vos services !";
			link.l2.go = "AsYouWish";

			if (bHalfImmortalPGG)
			{
				if (!CheckAttribute(pchar, "Option_ImmortalOfficers"))
				{
					pchar.Option_ImmortalOfficers = "0";
				}
				if (sti(pchar.Option_ImmortalOfficers) < makeint(GetCharacterSPECIAL(pchar, "Charisma")*2) && !CheckAttribute(npchar, "ImmortalOfficer"))
				{
					Link.l6 = "J'ai une proposition à vous faire.";
					Link.l6.go = "contract";
				}
			}

			//Расторжение контракта
			
			if (CheckAttribute(npchar, "ImmortalOfficer"))
			{
				Link.l6 = "Je veux résilier le contrat qui nous lie.";
				Link.l6.go = "cancelcontract1";
			}

			// приколы -->
            if (PChar.location == Get_My_Cabin())
            {
    			if (PChar.sex != "woman")
    			{
					Link.l3 = RandPhraseSimple("Puisque nous sommes dans la cabine, et si nous... hein ? Regarde, il y a un lit ici... si moelleux...",
	                                           "Regarde le grand lit de ma cabine. Tu ne voudrais pas le partager avec moi ?");
	                if (sti(pchar.GenQuest.BrothelCount) > 4+rand(3))
	                {
	                    Link.l3.go = "Love_Sex_Yes";
	                }
	                else
	                {
	                    Link.l3.go = "Love_Sex";
	                }
                }
                if (CheckAttribute(pchar , "questTemp.FUNY_SHIP_FIND") && PChar.questTemp.FUNY_SHIP_FIND == true && GetCharacterItem(PChar, "mineral4") >= 25)
                {
                    Link.l4 = "Regarde la collection intéressante que j'ai réunie !";
            		Link.l4.go = "FUNY_SHIP_1";
                }
            }
            else
            {
                if (PChar.sex != "woman")
                {
					Link.l3 = RandPhraseSimple("Une garde du corps, c'est bien, bien sמr, mais pourrions-nous essayer de nous rapprocher ?",
	                                           "Et pour les services hors règlement ?");
	                Link.l3.go = "Love_Sex";
                }
            }
            Link.l5 = "וcoute mon ordre !";
            Link.l5.go = "stay_follow";

			// по тёк локации определим можно ли тут приказать  -->
			if (IsEntity(loadedLocation))
            {
                if (CheckAttribute(loadedLocation, "fastreload"))
                {
                    iTemp = FindColony(loadedLocation.fastreload);
                    if (iTemp != -1)
                    {
                        sld = GetColonyByIndex(iTemp);
                        if (sti(sld.HeroOwn) == true && !CheckAttribute(sld, "OfficerIdx"))
                        {
							if(Locations[FindLocation(PChar.location)].islandId != "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
							{
								NPChar.ColonyIdx = iTemp;
								Link.l7 = "Je vous nomme gouverneur de cette ville !";
								Link.l7.go = "Gover_Hire";
							}
                        }
                    }
                }
            }
			if(PChar.ColonyBuilding.Stage != "0" && PChar.ColonyBuilding.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l8 = "Je veux vous nommer gouverneur de la colonie '" + PChar.ColonyBuilding.ColonyName + "', que nous avons bâtie sur l'île des Caïmans.";
						Link.l8.go = "ColonyBuilding_Hovernor_1";
					}
				}
			}

            link.l9 = ""+ GetSexPhrase("Repos, ma jolie, repos", "Rien. Repos") +".";
			link.l9.go = "exit";
        break;

        case "FUNY_SHIP_1":
		    dialog.text = "Oh, quelle horreur ! Capitaine, éloignez ça de moi, quelle puanteur insupportable... Vous croyez à toutes ces sornettes de la vieille légende sur l'obtention d'un combattant invincible ?";
   			Link.l1 = "Non, bien sמr, pardon. Je vais jeter toute cette masse puante par-dessus bord.";
            Link.l1.go = "exit";
            Link.l2 = "Oui, j'y crois ! Et je vais même vérifier. Allez, approchez-vous !";
            Link.l2.go = "FUNY_SHIP_2";
        break;

        case "FUNY_SHIP_2":
		    dialog.text = "Quelle puanteur ! Pouah... Mais ça marche, je me sens plus forte et même, euh, plus belle.";
   			Link.l1 = "Voilà ! Et vous aviez peur, votre jupe n'est même pas froissée. Lavez-vous les mains, maintenant.";
            Link.l1.go = "FUNY_SHIP_3";
        break;

        case "FUNY_SHIP_3":
            PChar.questTemp.FUNY_SHIP_FIND = false;
            DialogExit();
			NextDiag.CurrentNode = "Hired";

			TakeNItems(pchar, "mineral4", -25);
			AddSPECIALValue(Npchar, SPECIAL_S, 1);
			AddSPECIALValue(Npchar, SPECIAL_P, 1);
			AddSPECIALValue(Npchar, SPECIAL_E, 1);
			AddSPECIALValue(Npchar, SPECIAL_C, 1);
			AddSPECIALValue(Npchar, SPECIAL_I, 1);
			AddSPECIALValue(Npchar, SPECIAL_A, 1);
			AddSPECIALValue(Npchar, SPECIAL_L, 1);
        break;

		case "contract":
			dialog.text = "Je vous écoute attentivement, capitaine.";
			Link.l1 = "Vous êtes un bon officier et vous me convenez parfaitement. Je veux vous proposer de signer un contrat avec moi.";
			Link.l1.go = "contract2";
		break;

		case "contract2":
			dialog.text = "Merci pour ces aimables paroles, capitaine. Et quelles sont les conditions du contrat ?";
			Link.l1 = "Une grosse prime unique. Un meilleur équipement, "+ NPCharSexPhrase(NPChar, "vous le comprenez", "vous le comprenez") +" bien. La durée du contrat est de 10 ans. Vous pourrez partir à la fin du terme et, si tout nous convient à tous les deux, nous le prolongerons.";
			Link.l1.go = "contract3";
		break;

		case "contract3":
			NPChar.contractMoney = makeint(sti(NPChar.rank)*MOD_SKILL_ENEMY_RATE*3*1000);
			dialog.text = "Une offre tentante, on ne peut pas dire. De quoi mettre un peu d'argent de cכté pour une vieillesse tranquille. Et pour les petites primes du personnel permanent ?";
			if (sti(Pchar.money) >= sti(NPChar.contractMoney))
			{
				Link.l1 = "Je n'ai rien contre ; est-ce que " + sti(NPChar.contractMoney) + " pièces d'or vous conviendraient tout de suite ?";
				Link.l1.go = "contract4";
			}
			Link.l2 = "Je n'ai rien contre, mais reparlons-en plus tard.";
			Link.l2.go = "Exit";
		break;

		case "contract4":
			dialog.text = "Tout à fait, capitaine. J'accepte" + GetSexPhrase(".", ".");
			AddMoneyToCharacter(Pchar, -sti(NPChar.contractMoney));
			SetCharacterPerk(NPChar, "EnergyPlus");
			SetCharacterPerk(NPChar, "HPPlus");
			NPChar.OfficerWantToGo.DontGo = true;
			NPChar.loyality = MAX_LOYALITY;
			NPChar.Reputation = REPUTATION_NEUTRAL;
			DeleteAttribute(NPChar, "alignment");
			if (bHalfImmortalPGG)
			{
				if (!CheckAttribute(pchar, "Option_ImmortalOfficers"))
				{
					pchar.Option_ImmortalOfficers = "1";
				}
				else
				{
					pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) + 1);
				}
				NPChar.ImmortalOfficer = true;
				NPChar.HalfImmortal = true;  // Контузия
			}
			Link.l1 = "Parfait ! Marché conclu";
			Link.l1.go = "Exit";
		break;

		case "cancelcontract1":
			dialog.text = "Voilà qui est inattendu, capitaine. Et de quoi suis-je " + NPCharSexPhrase(NPChar, "coupable ?", "coupable ?");
			Link.l1 = "Oubliez ça, je me suis trompé" + GetSexPhrase(".", "e.");
			Link.l1.go = "Exit";
			Link.l2 = "Vos compétences ne me satisfont pas.";
			Link.l2.go = "cancelcontract2";
		break;
			
		case "cancelcontract2":
			NPChar.contractMoney = makeint(sti(NPChar.rank)*MOD_SKILL_ENEMY_RATE*3*1000);
			dialog.text = "Voilà donc... Eh bien, si vous payez le dédit prévu par le contrat, je n'aurai rien à redire.";
			if (sti(Pchar.money) >= sti(NPChar.contractMoney))
			{
				Link.l1 = "Comme vous voudrez ; est-ce que " + sti(NPChar.contractMoney) + " pièces d'or vous conviendraient tout de suite ?";
				Link.l1.go = "cancelcontract3";
			}
			Link.l2 = "J'ai des problèmes d'argent en ce moment, nous reparlerons de tout ça plus tard.";
			Link.l2.go = "Exit";
		break;
			
		case "cancelcontract3":
			dialog.text = "Tout à fait, capitaine. J'accepte" + NPCharSexPhrase(NPChar, ".", ".");
			AddMoneyToCharacter(Pchar, -sti(NPChar.contractMoney));
			pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) - 1);
			NPChar.OfficerWantToGo.DontGo = false;
			NPChar.HalfImmortal = false;
			NPchar.loyalty = MAX_LOYALITY / 2;
			DeleteAttribute(npchar, "ImmortalOfficer");
			if (rand(sti(pchar.reputation)) >= 50)
			{
				NPchar.alignment  = "good";
				NPchar.reputation = 61 + rand(29);
			}
			else
			{
				NPchar.alignment = "bad";
				NPchar.reputation = 39 - rand(29);
			}
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "Exit";
		break;

        case "Love_Sex_Yes":
		    dialog.text = RandPhraseSimple("Je pourrais peut-être céder à un tel bourreau des cœurs.",
                                           "Eh bien, c'est mieux que de dépenser son argent avec des filles des rues.");
            link.l1 = RandPhraseSimple("Oh, Yes!", "Futée, la fille ! Je ne peux pas aller au bordel quand j'ai une beauté comme toi à mes cכtés !");
			link.l1.go = "Love_Sex_Yes_2";
        break;

        case "Love_Sex_Yes_2":
            pchar.GenQuest.BrothelCount = 0;
            AddCharacterExpToSkill(pchar, "Leadership", 100);
            AddCharacterExpToSkill(pchar, "Fencing", -50);// утрахала
            AddCharacterExpToSkill(pchar, "Pistol", -50);
            AddCharacterHealth(pchar, 10);

   			AddDialogExitQuest("PlaySex_1");
			NextDiag.CurrentNode = "After_sex";
			DialogExit();
        break;

        case "After_sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Hum.. C'est étrange, je vous croyais capable de mieux...",
                                           "Capitaine, vous pouvez de nouveau réfléchir avec votre tête, et non avec... ? Revenons à nos affaires.");
            link.l1 = RandPhraseSimple("Comment parles-tu à ton supérieur !", "Je suis capable de beaucoup si je rassemble mes esprits.");
			link.l1.go = "exit";
        break;

        case "Love_Sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Quoi !!!?? Capitaine, ça fait longtemps que vous n'êtes pas descendu à terre ou allé au bordel ?", "Je ne comprends pas de quoi vous parlez ?");
            link.l1 = RandPhraseSimple("Eh bien, réfléchis.. tu es une telle beauté, et sous mes ordres, en plus", "Eh bien, je ne peux pas aller au bordel quand tu es à mes cכtés !");
			link.l1.go = "Love_Sex_2";
			link.l2 = RandPhraseSimple("Pardon, ma belle, c'était très difficile de ne pas proposer..", "Eh.. Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Love_Sex_2":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Capitaine ! Tenez-vous, et si vous n'y arrivez pas tout seul, appelez les matelots", "Le fait que je sois officier et que je vous obéisse en principe, capitaine, ne veut rien dire !");
            link.l1 = RandPhraseSimple("Ma belle, ne résiste pas. Je ne peux plus me retenir. Allons-y..", "Je suis ton capitaine ! Et je te l'ordonne !");
			link.l1.go = "Love_Sex_3";
			link.l2 = RandPhraseSimple("Pardon, ma belle, c'était très difficile de ne pas proposer..", "Eh.. Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Love_Sex_3":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("דa suffit ! Vous allez le payer ! Et tout de suite !", "Rouler sur le lit avec vous ? Eh bien, voyons maintenant qui est capable de quoi..");
            link.l1 = "Euh... de quoi tu parles ?";
			link.l1.go = "Love_Sex_4";
        break;

        case "Love_Sex_4":
            ChangeCharacterReputation(pchar, -15);
            CheckForReleaseOfficer(GetCharacterIndex(Npchar.id));
			RemovePassenger(Pchar, Npchar);
            LAi_SetWarriorType(Npchar);
            LAi_group_MoveCharacter(Npchar, "TmpEnemy");
            LAi_group_SetHearRadius("TmpEnemy", 100.0);
            LAi_group_FightGroupsEx("TmpEnemy", LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
			DeleteAttribute(Npchar, "HalfImmortal");
			Npchar.LifeDay = 0;
			if (PChar.location == Get_My_Cabin() || findsubstr(PChar.location, "_tavern" , 0) != -1)
            {
				LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
                LAi_group_SetCheck("TmpEnemy", "CannotFightCurLocation");
				LAi_group_SetCheck("TmpEnemy", "MainHeroFightModeOff");
            }
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;
        // приколы <--

        case "AsYouWish":
			dialog.text = "Comme vous voudrez, capitaine, c'est à vous de décider.";
			link.l1 = "Je crois que j'ai changé d'avis. J'ai encore besoin de vous.";
			link.l1.go = "exit";
			link.l2 = "Excellent. Vous pouvez aller au diable.";
			link.l2.go = "Exit_Fire";
		break;

        case "Exit_hire":
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			npchar.Dialog.FileName = "Enc_Officer_dialog.c";
			NPChar.Dialog.TempNode = "hired";
			Npchar.CanTakeMushket = true;
			npchar.HalfImmortal = true;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_fire":
   			NextDiag.TempNode = "Fired";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Fired":
		      NextDiag.TempNode = "Fired";
		      dialog.text = "Je vous avais prévenu, capitaine, que je ne reviendrais pas sur votre navire. J'ai ma fierté.";
		      Link.l1 = "Je n'ai pas besoin de vous !";
		      Link.l1.go = "Exit";
	    break;
		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "stay_follow":
            dialog.Text = "Quels sont vos ordres ?";
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";
			if (!CheckAttribute(npchar, "AboardRestriction"))
			{
				Link.l4 = "Je vous demande de ne pas participer aux abordages. Prenez soin de vous.";
				Link.l4.go = "AboardRestriction";
			}
			else
			{
				Link.l4 = "J'ai changé d'avis, vous pouvez participer aux abordages.";
				Link.l4.go = "AboardAllowed";
			}
        break;

		case "AboardRestriction":
			npchar.AboardRestriction = true;
			dialog.text = "א vos ordres, capitaine. Je ne participerai pas aux abordages tant que vous ne me l'aurez pas de nouveau permis.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

		case "AboardAllowed":
			DeleteAttribute(npchar, "AboardRestriction");
			dialog.text = "א vos ordres, capitaine. Désormais, je participerai aux abordages.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

        case "Boal_Stay":
            Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
            AddDialogExitQuestFunction("LandEnc_OfficerStay");
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
            Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
        break;

        case "Boal_Follow":
            SetCharacterTask_FollowCharacter(Npchar, PChar); // it works!!!
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
        break;

		//////////////////////////////    офицер-наместник -->
		case "Gover_Hire":
            dialog.Text = "Ce serait un honneur !";
            Link.l1 = "Veillez à l'ordre et à la prospérité de la ville ; je viendrai de temps en temps percevoir le tribut.";
			Link.l1.go = "Exit_Gover_Hire";
            Link.l2 = "J'ai changé d'avis.";
            Link.l2.go = "Exit";
            NextDiag.TempNode = "Hired";
        break;

        case "Exit_Gover_Hire":
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            attr = sld.id + "_townhall";

            // снимем пассажира -->
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			// снимем пассажира <--
		    sld.OfficerIdx = sti(NPChar.index);
			ChangeCharacterAddressGroup(NPChar, attr, "sit", "sit1");
			LAi_SetHuberTypeNoGroup(NPChar);
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
            LAi_LoginInCaptureTown(NPChar, true);
			//  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_1");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
			NextDiag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Main":
            iTemp = GetNpcQuestPastDayParam(NPChar, "GoverTalkDate");
            if (iTemp > 0)
            {
				dialog.Text = "Quels sont vos ordres ? Votre dernière visite remonte à " + FindRussianDaysString(iTemp) + " déjà.";
			}
			else
			{
			    dialog.Text = "Quels sont vos ordres ?";
			}

            Link.l1 = "Combien d'impכts avez-vous perçus ?";
        	Link.l1.go = "Gover_Tax";
            Link.l8 = "On a besoin de vous sur le navire, je vous relève de vos fonctions en ville.";
            Link.l8.go = "Gover_Fire";
			Link.l9 = "Bonne journée.";
            Link.l9.go = "Exit";
            NextDiag.TempNode = "Gover_Main";
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
        break;

        case "Gover_Tax":
            iTemp = GetNpcQuestPastDayParam(NPChar, "StartTaxDate");
            iTax  = makeint((GetCharacterSkillSimple(NPChar, SKILL_COMMERCE) + GetCharacterSkillSimple(NPChar, SKILL_LEADERSHIP)) / 2);
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
			if (CheckAttribute(sld, "FortValue"))
			{
			    iFortValue = sti(sld.FortValue);
			}
			else
			{
			    iFortValue = 20;
			}
			NPChar.Gover_Tax_Sum = iFortValue*iTax*iTemp;
			dialog.Text = "Mes compétences me permettent de percevoir " + FindRussianMoneyString(iFortValue*iTax) + " par jour. En " + FindRussianDaysString(iTemp) + " j'ai perçu " + FindRussianMoneyString(sti(NPChar.Gover_Tax_Sum)) + ".";
			if (sti(NPChar.Gover_Tax_Sum) > 0)
			{
			    Link.l1 = "Je veux percevoir la totalité des impכts.";
            	Link.l1.go = "Gover_Tax_Get";
			}
			Link.l2 = "Merci pour vos services !";
            Link.l2.go = "Exit";
        break;

        case "Gover_Tax_Get":
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            AddMoneyToCharacter(Pchar, sti(NPChar.Gover_Tax_Sum));

			NextDiag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Fire":
            dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
            Link.l8 = "Voilà qui est bien.";
            Link.l8.go = "exit_hire";
            NextDiag.TempNode = "Hired";
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            DeleteAttribute(sld, "OfficerIdx");
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_2");
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
        break;
        //////////////////////////////    офицер-наместник <--

		//Указания для компаньона 19.02.08 -->
		case "Companion_Tasks":
			dialog.Text = "Je vous écoute attentivement.";
			Link.l1 = "Il s'agit de l'abordage.";
			Link.l1.go = "Companion_TaskBoarding";
			Link.l2 = "Il s'agit de votre navire.";
			Link.l2.go = "Companion_TaskChange";
			if(bBettaTestMode) // Только при бета-тесте
			{
			    Link.l3 = "Je veux que vous quittiez mon escadre pour un temps et que vous naviguiez par vos propres moyens.";
			    Link.l3.go = "CompanionTravel";
			}
			Link.l8 = "Rien pour l'instant.";
			Link.l8.go = "exit";
		break;

		case "Companion_TaskBoarding":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je veux que vous n'abordiez pas les navires ennemis. Prenez soin de vous et de votre équipage.";
			Link.l1.go = "Companion_TaskBoardingNo";
			Link.l2 = "J'ai besoin que vous abordiez les navires ennemis.";
			Link.l2.go = "Companion_TaskBoardingYes";
		break;

		case "Companion_TaskChange":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je ne veux pas que vous soyez tenté"+ NPCharSexPhrase(NPChar, "", "e") +" de changer de navire après un abordage. Il a trop de valeur.";
			Link.l1.go = "Companion_TaskChangeNo";
			Link.l2 = "Quand vous abordez vos ennemis, regardez s'il y a un bateau convenable, et prenez-le pour vous.";
			Link.l2.go = "Companion_TaskChangeYes";
		break;

		case "Companion_TaskBoardingNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = false;
		break;

		case "Companion_TaskBoardingYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = true;
		break;

		case "Companion_TaskChangeNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = false;
		break;

		case "Companion_TaskChangeYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = true;
		break;
		//<--
		case "exit_spec":
			DialogExit();
		break;
		//Йока
		case "Yoko_meet":
			if (sti(pchar.reputation) > 70)
			{
				dialog.Text = "Salutations, capitaine. Je suis Yoko Diaz, lame libre.";
				Link.l1 = "Vous avez l'air un peu mal en point. Vous cherchez du travail ?";
				Link.l1.go = "Yoko";
			}
			else
			{
				dialog.Text = "Je ne pense pas que nous ayons grand-chose à nous dire, capitaine.";
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit_spec";
				NextDiag.TempNode = "Yoko_meet";
			}
		break;

		case "Yoko":
			dialog.Text = "J'en cherche, mais je ne vous serais guère utile pour l'instant.";
			Link.l1 = "Pourquoi donc ?";
			Link.l1.go = "Yoko_1";
		break;

		case "Yoko_1":
			ref locLoad = &locations[FindLocation("Shore_ship1")];
			string blade = GetGeneratedItem("Blade15");
			locLoad.box1.items.(blade) = 1;
			npchar.stortaid = blade;
			locLoad.box1.money = 7461;
			locLoad.box1.notouch = true;

			dialog.Text = "Hier soir, je suis allée faire la fête dans une taverne d'ici, et le matin, il s'est avéré que tout mon argent et ma storta avaient disparu. Si vous pouvez me les rendre, je rejoindrai votre équipage.";
			Link.l1 = "Retrouver une épée précise sur une grande île... C'est un peu un défi, mais je peux essayer.";
			Link.l1.go = "Yoko_2";
		break;

		case "Yoko_2":
			dialog.Text = "Je vous attendrai, capitaine.";
			Link.l1 = "א plus tard, Yoko !";
			Link.l1.go = "exit_spec";
			NextDiag.currentnode = "Yoko_wait";
			NextDiag.TempNode = "Yoko_wait";
		break;

		case "Yoko_wait":
			dialog.Text = "Alors, oם en êtes-vous, capitaine ?";
			if (GetCharacterFreeItem(pchar,npchar.stortaid))
			{
				Link.l1 = "J'ai réussi à retrouver votre storta. Tenez.";
				Link.l1.go = "Yoko_nowait";
			}
			Link.l2 = "Désolé, rien pour l'instant.";
			Link.l2.go = "Yoko_2";
		break;

		case "Yoko_nowait":
			TakeNItems(pchar,npchar.stortaid,-1);
			GiveItem2Character(NPChar, npchar.stortaid);
			EquipCharacterbyItem(NPChar, npchar.stortaid);
			dialog.Text = "Merci !";
			Link.l1 = "Et maintenant ?";
			Link.l1.go = "price";
			DeleteAttribute(NPChar, "Dialog.CurrentNode");
			NextDiag.TempNode = "OnceAgain";
		break;
		//Элен
		case "Helen_meet":
			if (pchar.name == "Charles" || pchar.name == "Mary")
			{
				if(npchar.id == "Beatrice")
				{
					dialog.text = "Vous avez le culot de venir ici après ce qui s'est passé ? Disparaissez de ma vue avant que je ne vous taille en pièces !";
					link.l1 = "Pardon, Helen...";
					link.l1.go = "exit";
					NextDiag.TempNode = "Helen_meet";
					break;
				}
			}
			if (sti(pchar.reputation) > 70)
			{
				if (CheckAttribute(npchar, "MetWhisper"))
				{
					dialog.Text = "J'ai entendu dire que vous aviez déjà votre propre navire. Vous montez vite ! Nous ne nous sommes pas présentés, n'est-ce pas ? ";
				}
				else dialog.Text = "Salutations, capitaine.";
				dialog.Text = dialog.Text + "Je suis Helen McArthur ; par la volonté du destin, je me suis retrouvée à terre, et je cherche maintenant une place d'officier.";
				Link.l1 = "Vous étiez capitaine auparavant ? Alors vous devez vous y connaître au moins un peu en tout, n'est-ce pas ?";
				Link.l1.go = "Helen";
			}
			else
			{
				dialog.Text = "Je ne pense pas que nous ayons grand-chose à nous dire, capitaine.";
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit_spec";
				NextDiag.TempNode = "Helen_meet";
			}
		break;
		case "Helen":
			dialog.Text = "C'est exact. Je m'y connais aussi bien en navigation qu'en tir.";
			Link.l1 = "Si vous êtes si douée, pourquoi ne vous a-t-on pas encore engagée ?";
			Link.l1.go = "Helen_1";
		break;
		case "Helen_1":
			dialog.Text = "Il y a ici, à Puerto Príncipe, une canaille, je ne sais même pas pourquoi tout le monde le tolère. Il répand sur moi toutes sortes de rumeurs ignobles, c'est pourquoi personne ne veut me prendre.";
			Link.l1 = "Vous avez essayé de lui clouer le bec avec de l'acier ?";
			Link.l1.go = "Helen_2";
		break;
		case "Helen_2":
			dialog.Text = "Pourquoi croyez-vous que je sois encore ici ? J'ai déjà essayé : il m'a tailladée et m'a épargnée, la première fois.";
			Link.l1 = "Et vous voulez que je vous aide ? Et ensuite, vous me rejoindrez ?";
			Link.l1.go = "Helen_3";
		break;
		case "Helen_3":
			dialog.Text = "Bien sמr. Et même pour une modeste prime.";
			Link.l1 = "Je vais essayer de vous aider, Helen.";
			Link.l1.go = "Helen_wait";

			sld = GetCharacter(NPC_GenerateCharacter("HelenBastard", "pirate_1", "man", "man", 30, PIRATE, -1, false));
			sld.name 	= "Julius";
			sld.lastname = "Brin";
			SetSPECIAL(sld, 9,8,7,6,7,8,9);
			FantomMakeCoolFighter(sld, 30, 90, 50, "blade21", "pistol10", 300);
			SelAllPerksToNotPchar(sld);
			sld.location	= "PuertoPrincipe_port";
			sld.location.group = "goto";
			sld.location.locator = "goto7";
			sld.dialog.filename   = "Enc_OfficerGirl.c";
			sld.dialog.currentnode = "Helen_Bastard";
			sld.perks.list.BasicDefense = true;
			sld.perks.list.AdvancedDefense = true;
			sld.perks.list.SwordplayProfessional = true;
			sld.perks.list.CriticalHit = true;
			sld.perks.list.Gunman = true;
			sld.perks.list.GunProfessional = true;
			sld.perks.list.Energaiser = true;
			sld.perks.list.ByWorker = true;
			sld.perks.list.ShipEscape = true;
			sld.perks.list.Ciras = true;
			LAi_SetWarriorType(sld);
			LAi_warrior_DialogEnable(sld, true);
			LAi_SetImmortal(sld,true);
			DeleteAttribute(sld, "lifeDay");
			LAi_group_MoveCharacter(sld, "player");
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld.quest.questflag.model = "questionmarkB";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
			LAi_LoginInCaptureTown(sld, true);
			bDisableFastReload = true;
			LocatorReloadEnterDisable("PuertoPrincipe_ExitTown", "reload1_back", true);
			
			PChar.quest.Raznoe_Pomosh_Elen.win_condition.l1 = "locator";
			PChar.quest.Raznoe_Pomosh_Elen.win_condition.l1.location = "PuertoPrincipe_ExitTown";
			PChar.quest.Raznoe_Pomosh_Elen.win_condition.l1.locator_group = "reload";
			PChar.quest.Raznoe_Pomosh_Elen.win_condition.l1.locator = "reload2_back";
			PChar.quest.Raznoe_Pomosh_Elen.win_condition = "Raznoe_Pomosh_Elen";
			
			SetQuestHeader("PomoshElen");
			AddQuestRecord("PomoshElen", "1");
			AddQuestUserData("PomoshElen", "sSex", GetSexPhrase("", "e"));
		break;
		case "Helen_wait":
			if (!CheckAttribute(pchar, "HelenMet"))
			{
				dialog.Text = "Je vous attendrai, capitaine. Bonne chance !";
				pchar.HelenMet = true;
			}
			else
			{
				dialog.Text = "Alors, oם en êtes-vous, capitaine ?";
			}
			Link.l1 = "Bien. Au revoir, Helen.";
			Link.l1.go = "exit_spec";
			if (CheckAttribute(pchar, "HelenQuest"))
			{
				Link.l1 = "Il est fini, plus personne ne répandra de rumeurs sur vous.";
				Link.l1.go = "Helen_nowait";
			}
			NextDiag.currentnode = "Helen_wait";
			NextDiag.TempNode = "Helen_wait";
		break;
		case "Helen_Bastard":
			dialog.Text = "Qui êtes-vous ? Encore "+ GetSexPhrase("un idiot", "une idiote") +" qui veut engager Helen comme officier ? Je vais vous raconter sur elle des choses à vous faire dresser les cheveux sur la tête.";
			Link.l1 = "דa ne m'intéresse pas. Je vous propose un marché. Vous quittez Puerto Príncipe dans l'heure, ou vous mourez ici même, tout de suite. Qu'en dites-vous ?";
			Link.l1.go = "Helen_Bastard_2";
			UnmarkCharacter(npchar);
		break;

		case "Helen_Bastard_2":
			dialog.Text = "Vous osez me menacer ? Eh bien, c'est votre problème. Défendez-vous, capitaine !";
			Link.l1 = "Je pensais bien que vous ne demanderiez pas...";
			Link.l1.go = "Helen_Bastard_exit";
		break;
		case "Helen_Bastard_exit":
			pchar.HelenQuest = 1;
			AddDialogExitQuest("MainHeroFightModeOn");
			DialogExit();
			LAi_SetImmortal(NPChar,false);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			chrDisableReloadToLocation = true;
			pchar.quest.HelenBastard.win_condition.l1 = "NPC_Death";
			pchar.quest.HelenBastard.win_condition.l1.character = "HelenBastard";
			pchar.quest.HelenBastard.win_condition = "Helen_Bastard_Dead";
			LocatorReloadEnterDisable("PuertoPrincipe_ExitTown", "reload1_back", false);
		break;
		case "Helen_nowait":
			dialog.Text = "Merci, capitaine ! Maintenant, parlons de ma rétribution...";
			Link.l1 = "Je vous en prie ! Eh bien, combien ?";
			Link.l1.go = "price";
			DeleteAttribute(pchar, "HelenMet");
			DeleteAttribute(pchar, "HelenQuest");
			DeleteAttribute(NPChar, "Dialog.CurrentNode");
			NextDiag.TempNode = "OnceAgain";
			AddQuestRecord("PomoshElen", "2");
			CloseQuestHeader("PomoshElen");
			AddGoodDeed("PomoshElen", 3); // Gregg: доброе дело
			pchar.questdata.PomoshElen = 1;
		break;
		//Анжелика
		case "Angellica_meet":
			if (startherotype == 4 || startherotype == 5)
			{
				if(npchar.id == "Angellica")
				{
					dialog.text = "Qui avons-nous là ? Encore un fruit de l'amour irrépressible de mon père pour le beau sexe ? Je ne suis pas d'humeur à tuer de la famille aujourd'hui. Passez votre chemin !";
					link.l1 = "Oh, nous aurions pu réaliser ensemble le rêve de notre père. Eh bien, comme tu voudras, Angelica, adieu.";
					link.l1.go = "exit";
					// LEO: закрепляем узел и в ветке отказа родственнику - иначе следующий разговор
					// заходил мимо проверки на родство, и Анжелика спокойно нанималась к Шарпу
					NextDiag.TempNode = "Angellica_meet";
					break;
				}
			}
			if (NPChar.alignment == "bad" && sti(pchar.reputation) < 30)
			{
				dialog.Text = "Hé, capitaine ! Vous avez l'honneur de pouvoir engager comme second la propre fille de Nicholas Sharp ! Vous en êtes capable ?"+ GetSexPhrase(" ", " ") +"Bien sמr !";
				Link.l1 = "Quelle arrogance ! Et vous êtes sמre que quelqu'un prendra une personne avec de telles idées ?";
				Link.l1.go = "Angellica";
			}
			else
			{
				dialog.Text = "Je ne pense pas que nous ayons grand-chose à nous dire, capitaine.";
				Link.l1 = "Je n'en avais pas vraiment envie.";
				Link.l1.go = "exit_spec";
				NextDiag.TempNode = "Angellica_meet";
			}
		break;
		case "Angellica":
			dialog.Text = "Croyez-moi, il y aura des amateurs. Vous voulez tenter votre chance ?";
			Link.l1 = "Et qu'est-ce qui, pour vous, prouve qu'on en est digne ?";
			Link.l1.go = "Angellica_2";
		break;

		case "Angellica_2":
			if (!CheckAttribute(pchar, "AngellicaDuelInfo")) {dialog.Text = "Battez-moi en duel, et pour une modeste rétribution, je vous rejoindrai."; pchar.AngellicaDuelInfo = true;}
			else dialog.Text = "Alors, c'est décidé ?";
			Link.l1 = "Je suis prêt !";
			Link.l1.go = "Angellica_duel_exit";
			Link.l2 = "Peut-être plus tard.";
			Link.l2.go = "exit_spec";
			NextDiag.currentnode = "Angellica_2";
			NextDiag.TempNode = "Angellica_2";
		break;

		case "Angellica_duel_exit":
			DialogExit();
			NextDiag.currentnode = "Angellica_duel_won";
			NextDiag.TempNode = "Angellica_duel_won";
			ChangeCharacterAddressGroup(NPChar, "LeFransua_ExitTown", "enc01", "enc01_04");
			LAi_SetCheckMinHP(NPChar, 5, true, "AngellicaDialog");
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_SetHP(npchar, 500, 500);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			// LEO: 1-on-1 duel — only the hero goes out of town, boarders stripped (like the duelist quest). bDisableOfficers keeps them off across save/load, Save off — anti-savescam. Restored on win (AngellicaDialog).
			DeleteAllOfficersFromLocation();
			bDisableOfficers = true;
			InterfaceStates.Buttons.Save.enable = false;
			DoQuestReloadToLocation("LeFransua_ExitTown", "reload", "reload3", "");
			chrDisableReloadToLocation = true;
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
		break;
		case "Angellica_duel_won":
			dialog.Text = "וtonnant ! Personne d'ici n'avait encore réussi à me battre...";
			Link.l1 = "Vous m'avez fait transpirer, vous aussi.";
			Link.l1.go = "Angellica_duel_won_exit";
			LAi_SetHP(npchar, 150, 150);
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "AngellicaDuelInfo");
			LAi_SetImmortal(NPChar,false);
			LAi_RemoveCheckMinHP (npchar);
		break;
		case "Angellica_duel_won_exit":
			DialogExit();
			LAi_SetWarriorType(NPChar);
			LAi_warrior_DialogEnable(NPChar, true);
			NextDiag.currentnode = "Angellica_duel_won_2";
			NextDiag.TempNode = "Angellica_duel_won_2";
		break;
		case "Angellica_duel_won_2":
			dialog.Text = "Je suis prête à vous rejoindre maintenant, capitaine.";
			Link.l1 = "Et pour combien ?";
			Link.l1.go = "price";
			DeleteAttribute(NPChar, "Dialog.CurrentNode");
			NextDiag.TempNode = "OnceAgain";
		break;
	}
}

void FireImmortalOfficer(ref chr)
{
	if (CheckAttribute(chr, "ImmortalOfficer"))
	{
		DeleteAttribute(chr, "ImmortalOfficer")
		pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) - 1);
	}
}
