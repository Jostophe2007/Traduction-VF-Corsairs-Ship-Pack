// Gregg: The messenger and Paul Strongfield - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(depuis le seuil, la voix brisée)... Un navire ! Un navire à l'horizon !";
			link.l1 = "Reprenez d'abord votre souffle.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "J'étais à la boutique. Il a fait noir en plein jour, les gens se sont mis à crier dans la rue. Je suis sorti en courant, et il y avait en mer une tempête qui n'existait pas une minute plus tכt, et quelque chose qui faisait route vers la colonie.";
			link.l1 = "Qui faisait route comme quoi ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je ne l'ai pas vu moi-même. Ils criaient : un vaisseau de ligne noir, immense, et pas une lumière à bord. On m'a dit de vous prévenir.";
			link.l1 = "Compris. Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyTalkWithKendart");
		break;

		case "4":
			dialog.text = "Capitaine. Et maître Kendart aussi. Je vous remercie tous les deux du fond du cœur.";
			link.l1 = "Qui êtes-vous ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Il y a trente ans, je commandais une caravelle. J'avais une femme, des enfants, de quoi vivre, et tout cela me contentait. Pendant un voyage, une tempête nous a emportés deux jours durant, et le troisième, nous sommes tombés sur un navire qui n'avait rien à faire là. Vide, à la dérive. Je suis monté à bord le premier.";
			link.l1 = "Et vous avez trouvé le sablier.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je l'ai trouvé. Le sable coulait sans jamais s'épuiser : le bulbe du haut ne se vidait jamais, celui du bas ne se remplissait jamais. Je le regardais sans pouvoir détacher les yeux, puis je l'ai pris dans mes mains. Ensuite, la douleur, et je me suis réveillé dans la même cabine, sauf que plus personne ne pouvait me voir.";
			link.l1 = "...(se tait)...";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Tant que personne ne touchait le sablier, je n'étais tout simplement rien. Mais dès qu'une autre main se posait sur le bulbe, la chose en moi se réveillait. Et je tuais. Tout le monde à bord, jusqu'au dernier.";
			link.l1 = "Trente-deux pendus aux vergues. C'était vous.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "C'était moi. Et ceux qu'on a fusillés et entassés dans la cale, c'était moi aussi. Ils ne pouvaient pas me voir, alors ils ne résistaient pas.";
			link.l1 = "Et pendant que le sablier était chez Kendart, à San Juan ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Je priais pour que personne n'y touche. Si quelqu'un l'avait pris, j'aurais massacré toute la ville sans rien pouvoir y faire. Vous deux, Dieu merci, saviez ce que vous maniiez.";
			link.l1 = "Et ce navire ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Je ne sais pas. Il est apparu en même temps que moi quand on a ouvert le sablier, et je suis aussi étranger à son bord que vous.";
			link.l1 = "Alors quittons-le ensemble.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Non. Il y a trop de morts derrière moi pour que je continue à vivre. Je vous demande de me tuer.";
			link.l1 = "Ce n'était pas votre faute.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "C'étaient mes mains. Et je m'en souviens moi-même. J'ai fait mon choix il y a longtemps, capitaine. Jusqu'à aujourd'hui, je n'arrivais même pas à le faire.";
			link.l1 = "Vous en êtes certain ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Absolument.";
			link.l1 = "...(lève le pistolet)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyManowarShot");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
