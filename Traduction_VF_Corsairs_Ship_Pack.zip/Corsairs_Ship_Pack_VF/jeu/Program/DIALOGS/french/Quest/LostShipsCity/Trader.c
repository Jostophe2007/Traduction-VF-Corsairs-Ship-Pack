
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Maudite tempête ! Même si elle a déjà commencé à faiblir... Si je comprends bien, tu es notre "+ GetSexPhrase("nouveau citoyen", "nouvelle citoyenne") +" ?";
					link.l1 = "Capitaine " + GetFullName(pchar) + ", en personne. Et la tempête, peu importe !";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Ah, eh bien, te voilà chez moi. Si je comprends bien, tu es notre "+ GetSexPhrase("nouveau citoyen", "nouvelle citoyenne") +" ?";
					link.l1 = "Capitaine " + GetFullName(pchar) + ", en personne.";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Tu veux acheter ou vendre quelque chose ?";
				link.l1 = "Montrez-moi ce que vous avez là.";
				link.l1.go = "Trade_exit";
				//квест получения карты -->
				if (!CheckAttribute(npchar, "quest.takeMap"))
				{
					link.l2 = "L'ami, j'ai entendu dire que tu avais une carte de la Cité. Tu sais, elle me serait bien utile en ce moment. Parce que je cours partout ici comme un chaton aveugle...";
					link.l2.go = "tekeMap_begin";
				}
				if (CheckAttribute(npchar, "quest.takeMap") && npchar.quest.takeMap == "mapIsToken" && !CheckCharacterItem(pchar, "map_LSC"))
				{
					link.l2 = "L'ami, tu serais devenu fou, par hasard ? Une somme pareille pour un méchant bout de papier qu'on appelle fièrement une carte de la Cité ?";
					link.l2.go = "tekeMap_off";
				}
				if (CheckAttribute(npchar, "quest.takeMap") && npchar.quest.takeMap == "discount")
				{
					link.l2 = "וcoute, l'ami, " + npchar.quest.takeMap.name + " m'a demandé de te reparler de la carte de la Cité.";
					link.l2.go = "tekeMap_on";
				}
				//<-- квест получения карты
				link.l3 = "Merci, ça ne m'intéresse pas.";
				link.l3.go = "exit";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && !CheckAttribute(pchar, "questTemp.LSC.goods.trader"))
				{
					link.l8 = "וcoute, je voudrais t'acheter quelque chose de spécial.";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(pchar, "questTemp.LSC.goods.trader") && sti(pchar.questTemp.LSC.goods.trader))
				{
					link.l8 = "Je suis prêt à acheter les marchandises que tu m'as promises.";
					link.l8.go = "SeekGoodsOk";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "וcoutez, nous avons à parler sérieusement. Je recrute un équipage.";
					link.l8.go = "SeekCrew";
				}
				NextDiag.TempNode = "First time";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FS_1":
			dialog.text = "Qu'est-ce que tu en sais, de ce qui va et de ce qui ne va pas ? Bon, je suis de mauvaise humeur aujourd'hui. Je m'appelle " + GetFullName(npchar) + ", je suis le propriétaire de cette boutique. Faisons connaissance.";
			link.l1 = "C'est ce que nous allons faire.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Parfait ! Et moi, je m'appelle " + GetFullName(npchar) + ", je suis le propriétaire de cette boutique. Faisons connaissance.";
			link.l1 = "C'est ce que nous allons faire.";
			link.l1.go = "exit";
		break;

		case "Trade_exit":
            if (CheckNPCQuestDate(npchar, "Item_date") || npchar.quest.takeMap == "changePrice")
			{
				SetNPCQuestDate(npchar, "Item_date");
				GiveItemToTrader(npchar);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(npchar);
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Qu'est-ce que tu fiches dans mon coffre ! Tu ne connais pas la Loi de la Cité ? Eh bien, tu vas l'apprendre...", "Hé, citoyen, qu'est-ce que tu fais ? La Loi interdit de faire ça ! Je vais te punir...", "Attends, oם tu vas comme ça ? Il y a un voleur dans la Cité !! Eh bien, tiens-toi bien...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, vous vous prenez pour d'Artagnan, à courir partout en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = "Toujours à ton service, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Commande !";
			link.l1 = "וcoute, je n'ai pas encore vu ces marchandises dans ton assortiment. Ce sont des bombes, des boulets ramés, de la poudre, des vivres, de la toile, des planches, des médicaments...";
			link.l1.go = "SeekGoods_1";
		break;
		case "SeekGoods_1":
			dialog.text = "Eh bien, de ce que tu as cité, seuls les vivres, la toile, les planches et les médicaments ont de la valeur ici. Le reste, personne n'en a besoin.";
			link.l1 = "Tu as quelque chose ?";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Je peux te vendre des vivres. C'est assez cher.";
			link.l1 = "Il me faut 20 quintaux. Combien ça va coמter ?";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Trente-cinq mille pièces.";
			link.l1 = "Combien ?! Et avec une remise ?";
			link.l1.go = "SeekGoods_4";
		break;
		case "SeekGoods_4":
			dialog.text = "Désolé, mais il n'y a pas de remise. Je t'ajoute la toile et les planches pour 5 000 pièces d'or. En tout, si tu veux acheter tout ça, prépare 40 000.";
			if (sti(pchar.money) >= 40000)
			{
				link.l1 = "Je peux payer.";
				link.l1.go = "SeekGoods_5";
			}
			else
			{
				link.l1 = "Je n'ai pas assez d'argent.";
				link.l1.go = "SeekGoods_notMoney";
			}
		break;
		case "SeekGoods_notMoney":
			dialog.text = "Bon, reviens quand tu les auras.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.goods.trader = true;
		break;

		case "SeekGoods_5":
			dialog.text = "Parfait, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Oם veux-tu qu'on décharge tout ça ?";
			link.l1 = "וcoute, envoie tout au San Gabriel. Les Caspers n'y sont plus, si tu ne le savais pas...";
			link.l1.go = "SeekGoods_6";
		break;
		case "SeekGoods_6":
			dialog.text = "Je suis au courant. Je m'occupe de tout.";
			link.l1 = "Merci, l'ami.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "46");
			AddMoneyToCharacter(pchar, -40000);
			AddCharacterGoods(pchar, GOOD_FOOD, 200);
			AddCharacterGoods(pchar, GOOD_PLANKS, 50);
			AddCharacterGoods(pchar, GOOD_SAILCLOTH, 50);
			pchar.questTemp.LSC.goods.trader = false;
		break;

		case "SeekGoodsOk":
			dialog.text = "Tu as l'argent ?";
			if (sti(pchar.money) >= 40000)
			{
				link.l1 = "Oui. Et je peux payer.";
				link.l1.go = "SeekGoods_5";
			}
			else
			{
				link.l1 = "Pas encore...";
				link.l1.go = "SeekGoods_notMoney";
			}
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Quel équipage ?",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "דa suffit, je suis fatigué...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Pour mon navire. Je quitte la Cité.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Héhé, tu vas loin, toi... Tu sais que tu enfreins la Loi de la Cité, n'est-ce pas ?";
			link.l1 = "Je sais. Mais je sauve ma vie. Le fait est que la Cité va être détruite par la tempête qui approche.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Allons bon, pas besoin d'aller voir une diseuse de bonne aventure...";
			link.l1 = "Tu ne me crois pas ?";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Non, je n'y crois pas. Et je ne veux plus en parler.";
			link.l1 = "Hum... Comme tu voudras.";
			link.l1.go = "exit";
		break;
		//квест получения карты Города
		case "tekeMap_begin":
			dialog.text = "Je comprends, c'est toujours comme ça avec les nouveaux citoyens...";
			link.l1 = "Alors, tu as une carte ?";
			link.l1.go = "tekeMap_begin_1";
		break;
		case "tekeMap_begin_1":
			dialog.text = "Oui, on ne t'a pas menti.";
			link.l1 = "L'ami, j'en ai besoin.";
			link.l1.go = "tekeMap_begin_2";
		break;
		case "tekeMap_begin_2":
			dialog.text = "Eh bien, achète-la. Comme d'habitude, elle est disponible parmi les autres marchandises.";
			link.l1 = "Je comprends !";
			link.l1.go = "First time";
			npchar.quest.takeMap = "firstGiveMap";
		break;
		case "tekeMap_off":
			dialog.text = "Tu n'as pas compris. Ce n'est pas le papier qu'on paie, mais ce qui est dessiné dessus. Bref, si ça ne te plaît pas, ne l'achète pas. Oם est le problème ?";
			link.l1 = "J'ai besoin de cette carte. Mais elle est trop chère !!!";
			link.l1.go = "tekeMap_off_1";
		break;
		case "tekeMap_off_1":
			dialog.text = "Mon cher, je ne marchande pas. Tu veux courir dans la Cité comme une âme en peine ? Si tu ne veux pas, donne-moi l'argent. Je n'ai rien de plus à te dire à ce sujet.";
			link.l1 = "Mais j'ai vraiment besoin de cette carte ! S'il te plaît, baisse le prix.";
			link.l1.go = "tekeMap_off_2";
		break;
		case "tekeMap_off_2":
			dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +", la charité, c'est à l'église ; moi, je fais du commerce. Alors, inutile de demander, ça ne sert à rien.";
			link.l1 = "Oh, merde !..";
			link.l1.go = "exit";
			npchar.quest.takeMap = "notTrade"; //поговорили о том, что не торгуется
		break;
		case "tekeMap_on":
            if (CheckNPCQuestDate(npchar, "Item_date"))
			{
				dialog.text = "D'accord, je vais baisser le prix, soit...";
				link.l1 = "Merci ! Et combien en demandes-tu maintenant ?";
				link.l1.go = "tekeMap_on_1";
			}
			else
			{
				dialog.text = "Je ne suis pas au courant. " + npchar.quest.takeMap.name + " ne m'a encore rien dit.";
				link.l1 = "Elle n'a sans doute pas encore eu le temps. Je reviendrai plus tard, et nous en reparlerons.";
				link.l1.go = "exit";
			}
		break;
		case "tekeMap_on_1":
			dialog.text = "Procédons à la vente dans les formes indiquées. Je n'aime pas les initiatives personnelles.";
			link.l1 = "D'accord, comme vous voudrez.";
			link.l1.go = "exit";
			npchar.quest.takeMap = "changePrice"; //снизить цену
		break;

	}
}
