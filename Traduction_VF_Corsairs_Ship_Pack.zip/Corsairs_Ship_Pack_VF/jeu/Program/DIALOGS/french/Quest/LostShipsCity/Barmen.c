#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;
	if (CheckAttribute(pchar, "ReturnToLSC") && !CheckAttribute(NPChar, "MetAgain"))
	{
		NPChar.MetAgain = true;
		dialog.text = "Capitaine, vous avez survécu ? Je n'en crois pas mes yeux !";
		link.l1 = "Comme vous le voyez..."
		link.l1.go = "MetAgain1";
		return;
	}
	if (HasSubStr(NodeName, "TradeGoods_"))
	{
		npchar.GoodType = strcut(NodeName, findsubstr(NodeName, "_" , 0)+1, strlen(NodeName)-1);
		Dialog.CurrentNode = "TradeCheck";
	}

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = "Je ne veux pas vous parler ! Vous avez attaqué mes concitoyens !";
				link.l1 = "Comme vous voudrez..."
				link.l1.go = "exit";
				break;
			}

			if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "C'est votre navire qui s'est échoué le dernier ? Eh bien, bienvenue ! Je tiens une taverne ici, je m'appelle " + GetFullName(npchar) + ". Vous avez beaucoup de chance, "+ GetSexPhrase("l'ami", "ma petite") +" !";
					link.l1 = "Oui, j'ai eu une chance fatale !.. Je m'appelle " + GetFullName(pchar) + ". J'étais capitaine...";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.Text = "Ah, c'est donc votre navire qui s'est échoué le dernier ? Eh bien, bienvenue ! Je tiens une taverne ici, je m'appelle " + GetFullName(npchar) + ". Alors, entrez donc, si vous avez besoin de quoi que ce soit...";
					Link.l1 = "D'accord, " + npchar.name + ". Heureuse rencontre, pour ainsi dire... Et moi, je m'appelle " + GetFullName(pchar) + ".";
					Link.l1.go = "First time";
				}
			}
			else
			{
				//базар в винном погребе
				if (pchar.questTemp.LSC == "toWineCellarGone" && npchar.location.locator == "stay1")
				{
					dialog.Text = "Ah, vous voilà !";
					link.l4 = "Exactement ! Maintenant, j'aimerais vous écouter.";
					link.l4.go = "TizerCellar";
					PChar.quest.LSC_returnBarmen.over = "yes"; //снимаем таймер на опоздание, разговор состоялся
					break;
				}
				//после завала Хилла Брюннера
				if (pchar.questTemp.LSC == "barmenIsDead" && !CheckAttribute(npchar, "quest.HillNB_1"))
				{
					dialog.Text = "Je vous écoute attentivement.";
					link.l4 = "Que diable faites-vous ici ? Oם est Brunner ?";
					link.l4.go = "NB_1";
					pchar.questTemp.LSC = "barmenIsDeadYouKnow";
					break;
				}
				if (pchar.questTemp.LSC == "barmenIsDeadYouKnow" || pchar.questTemp.LSC == "toAdmiralBarmenDead")
				{
					if (!CheckAttribute(npchar, "quest.HillNBB_1"))
					{
						dialog.Text = "Je vous écoute attentivement.";
						link.l4 = "Eh bien, on dirait que Hill est vraiment mort...";
						link.l4.go = "NBB_1";
						break;
					}
				}
				//убийство Армо
				sld = characterFromId("LSCwaitress");
				if (sld.lastname == "Prescott" && !CheckAttribute(npchar, "quest.Armo"))
				{
					dialog.Text = "Armo a été tuée... D'abord Hill Brunner, maintenant Armo. Cette taverne est un endroit funeste.";
					link.l4 = "Vous n'auriez rien pu faire pour l'empêcher ?";
					link.l4.go = "ADied_1";
					npchar.quest.Armo = true;
					break;
				}
				//==> штатый диалог
				dialog.Text = LinkRandPhrase("Hé, " + GetAddress_Form(NPChar) + " ! " + PChar.name + " ! " + TimeGreeting() + ".",
                                    "Oh, je suis content de voir un nouveau citoyen dans notre Cité...",
                                    "Content de vous voir dans ma taverne. Qu'est-ce qui vous amène ?");
				Link.l1 = "J'espère que vous pourrez répondre à quelques questions.";
				Link.l1.go = "int_quests";
				link.l2 = "J'ai besoin de passer la nuit.";
				link.l2.go = "room";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				if (CheckAttribute(pchar, "ReturnToLSC"))
				{
					link.l4 = "J'ai apporté des marchandises. Vous voulez jeter un coup d'œil ?"
					link.l4.go = "TradeGoods";
				}
				Link.l99 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l99.go = "exit";
				//==>> квесты
				if (pchar.questTemp.LSC == "AfterAdmiral" && GetQuestPastDayParam("questTemp.LSC") > 3)
				{
					link.l4 = "L'ami, nous étions convenus que vous réfléchiriez à Teaser Dan...";
					link.l4.go = "Tizer";
				}
				if (pchar.questTemp.LSC == "toWineCellarLate")
				{
					link.l4 = "וcoutez, je n'ai pas encore trouvé cette cave à vin...";
					link.l4.go = "TizerCellarLate";
				}
				if (pchar.questTemp.LSC == "toDiffindoor" && CheckCharacterItem(pchar, "letter_LSC"))
				{
					link.l4 = "J'ai examiné le « Diffindur » et j'y ai trouvé un coffre de Teaser. Entre autres, il y avait aussi une lettre très intéressante...";
					link.l4.go = "TizerCellarOk_1";
				}
				if (pchar.questTemp.LSC == "afterFightInProtector")
				{
					link.l4 = "וcoutez, voilà l'affaire...";
					link.l4.go = "AfterProtector_1";
				}
				if (pchar.questTemp.LSC == "toAdmNarvalRing" && CheckCharacterItem(pchar, "DOjeronRing"))
				{
					link.l4 = "J'ai fait comme vous l'avez dit. J'ai l'anneau des Narvals.";
					link.l4.go = "NarvalRing_1";
				}
				if (pchar.questTemp.LSC == "toTavernNarvalDestroyed")
				{
					link.l4 = "Vous savez, ça a marché !";
					link.l4.go = "AfterNarvalDesrt_1";
				}
				if (pchar.questTemp.LSC == "waitInterception" && GetQuestPastDayParam("questTemp.LSC") > 2 && GetHour() < 20)
				{
					link.l4 = "Alors, comment ça va ? Vous avez découvert ce que vous comptiez découvrir ?";
					link.l4.go = "Interception";
				}
				if (pchar.questTemp.LSC == "InterceptionLate")
				{
					link.l4 = "וcoutez, je n'ai pas pu entrer dans votre cave avant minuit. Alors je n'ai vu personne et je n'ai rien entendu.";
					link.l4.go = "InterceptionLate";
				}
				if (pchar.questTemp.LSC == "InterceptionYouSeen")
				{
					link.l4 = "Vous savez, à minuit pile, j'étais dans votre cave. L'amiral et un autre type allaient parler, mais ils m'ont remarqué et ils sont partis. Alors je n'ai rien entendu.";
					link.l4.go = "InterceptionYouSeen";
				}
				if (pchar.questTemp.LSC == "waitInterceptionResult")
				{
					link.l4 = "L'ami, vous avez appris quelque chose sur notre affaire ?";
					link.l4.go = "Result";
				}
				if (pchar.questTemp.LSC == "InterceptionOk")
				{
					link.l4 = "Vous savez, votre cave est vraiment un bon endroit pour surprendre des conversations. J'ai attendu Chad.";
					link.l4.go = "InterceptionOk";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "וcoutez, nous avons à parler sérieusement. Je recrute un équipage.";
					link.l8.go = "SeekCrew";
				}
			}
		break;

		case "FS_1":
			dialog.text = "Vous avez de la chance, "+ GetSexPhrase("le gars", "la fille") +", capitaine, simplement, vous ne le comprenez pas encore. Si vous étiez arrivé dans la Cité il y a environ cinq heures, vous n'auriez jamais pu sortir de l'eau.";
			link.l1 = "Je suis marin, je nage bien...";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "דa ne veut rien dire quand il s'agit des eaux autour de la Cité ! C'est simplement que la tempête s'est calmée, et c'est ce qui vous a donné une chance.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//крутим время
		case "room":
   			if (chrDisableReloadToLocation) //кто-то должен подойти к ГГ.
			{
				dialog.text = "Je ne pense pas que vous devriez dormir maintenant. Croyez-moi...";
				link.l1 = "D'accord.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Vous pouvez dormir sur le lit qui se trouve à l'étage supérieur. Quand dois-je vous réveiller ?";
			if(!isDay())
			{
				link.l1 = "Le matin.";
				link.l1.go = "hall_day_wait";
			}
			else
			{
				link.l1 = "א la tombée de la nuit.";
				link.l1.go = "hall_night_wait";
				link.l2 = "Demain matin.";
				link.l2.go = "hall_day_wait";
			}
			link.l3 = "J'ai changé d'avis. Je me passerai de sommeil.";
			link.l3.go = "exit";
		break;
		case "hall_night_wait":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate_LSC("wait_night");
		break;
		case "hall_day_wait":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			TavernWaitDate_LSC("wait_day");
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l5"))
			{
				link.l5 = "וvidemment, votre temps est tout simplement extraordinaire !!";
				link.l5.go = "ansewer_5";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Comment suis-je arrivé ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Est-ce vraiment impossible de partir d'ici ? Il y a tant de navires autour, n'est-il vraiment pas possible d'en assembler un entier ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Comment diable vivez-vous ici ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l6"))
			{
				link.l6 = "וcoutez, vous connaissiez Teaser Dan ?";
				link.l6.go = "ansewer_6";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l7") && pchar.questTemp.LSC == "AdmiralIsWaiting" && CheckCharacterItem(pchar, "keyQuestLSC"))
			{
				link.l7 = "וcoutez, vous savez ce qu'est le Diffindur ?";
				link.l7.go = "ansewer_7";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l8"))
			{
				link.l8 = "Quels clans vivent dans la Cité ?";
				link.l8.go = "ansewer_8";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l9"))
			{
				link.l9 = "וcoutez, tous les coffres sont fermés à clé. Oם puis-je en trouver au moins une ?";
				link.l9.go = "ansewer_9";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l10"))
			{
				link.l10 = "Et qui est Augusto Brahms ?";
				link.l10.go = "ansewer_10";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l11"))
			{
				link.l11 = "Je n'arrive pas à m'habituer à la Cité. Il n'y a pas une sorte de carte, ou quelque chose ?";
				link.l11.go = "ansewer_11";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l12") && CheckActiveQuest("LSC_findDekster"))
			{
				link.l12 = "וcoutez, vous savez qui est Leighton Dexter ?";
				link.l12.go = "ansewer_12";
			}
			link.l20 = "Pas de questions. Désolé, l'ami...";
			link.l20.go = "exit";
		break;
		case "ansewer_5":
			dialog.text = "Ce n'est rien ! Il y a eu pire. Les tempêtes sont fréquentes ici.";
			link.l1 = "Je vois...";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Cette tempête se terminera demain soir. Nous sommes censés nous présenter à l'amiral dès notre arrivée, alors si vous ne vous présentez pas avant la fin de la tempête, il vous trouvera lui-même.";
			link.l1 = "L'amiral ?";
			link.l1.go = "ansewer_5_2";
		break;
		case "ansewer_5_2":
			dialog.text = "Chad Capper, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Ne vous mêlez pas de cette affaire, c'est un conseil !";
			link.l1 = "Je vois.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés, "+ GetSexPhrase("l'ami", "ma petite") +". Si vous êtes arrivé ici, alors oubliez tout ce que vous avez vécu avant. On ne peut pas partir d'ici, malheureusement...";
			link.l1 = "Diable !!";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Je ne sais pas, c'est plutכt à vous qu'il faut demander comment vous êtes arrivé ici. C'est vous le capitaine, vous qui commandez votre navire. Moi, je ne sais rien, j'étais assis dans ma cabine, et soudain, il y a eu des cris, puis le craquement de la coque... C'est tout.";
			link.l1 = "Et vous n'avez rien vu ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Ensuite, j'ai vu, bien sמr, ce paysage marin, pour ainsi dire. Mais comment notre capitaine a réussi à venir ici, je n'en ai aucune idée. Il est mort. En fait, peu de gens réchappent d'un naufrage, alors vous avez de la chance.";
			link.l1 = "Oui...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Ha !!! Et pourquoi êtes-vous si malin ? Il y a eu des tentatives, mais toutes ont échoué. Il se trouve que les gens prennent des matériaux et ne font que les gâcher. La Cité en souffre sérieusement, car cela réduit sa stabilité. Si vous détachez un navire, l'île se met à bouger, tous les passages se brisent, les cabines se déplacent, bref, tout va de travers. C'est pourquoi c'est désormais interdit par notre Loi. Et depuis longtemps !";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_4":
			dialog.text = "Oui, ça va. Même si, vous savez, j'en ai plus qu'assez de tout... Bref, la Cité vit selon la Loi. Vous feriez mieux de vous renseigner sur ses principaux points auprès de l'amiral Capper.";
			link.l1 = "Qui est cet amiral ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "C'est, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", le soi-disant chef du gouvernement local, il s'appelle Chad Capper. On dit qu'il était pirate, alors vous ne devriez pas le provoquer sans raison.";
			link.l1 = "Personne n'en a l'intention... Vous avez vraiment des élections, et les citoyens choisissent un amiral ?";
			link.l1.go = "ansewer_4_2";
		break;
		case "ansewer_4_2":
			dialog.text = "Eh bien, il y a eu des élections autrefois, mais maintenant, ce n'est plus d'actualité. Chad fait du bon travail, personne ne veut rien changer. Plus personne ne le veut...";
			link.l1 = "Que veut dire « plus personne » ?";
			link.l1.go = "ansewer_4_3";
		break;
		case "ansewer_4_3":
			dialog.text = "Avant, il y avait des citoyens qui voulaient devenir amiral. Mais maintenant, ils ne sont plus parmi nous.";
			link.l1 = "Ils sont partis d'ici en bateau ?";
			link.l1.go = "ansewer_4_4";
		break;
		case "ansewer_4_4":
			dialog.text = "Eh bien, on pourrait dire qu'ils sont partis par le fond...";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_6":
			dialog.text = "Je le connaissais. Il a vécu chez nous plusieurs mois, puis il est mort. C'est dommage, c'était un brave gars.";
			link.l1 = "Ce n'est pas ça !";
			link.l1.go = "ansewer_6_1";
			NextDiag.(NodePrevName).l6 = true;
		break;
		case "ansewer_6_1":
			dialog.text = "C'était un mauvais gars ?";
			link.l1 = "Ce n'est pas ce que je veux dire ! On dirait qu'il a réussi, je ne sais comment, à rejoindre le continent...";
			link.l1.go = "ansewer_6_2";
		break;
		case "ansewer_6_2":
			dialog.text = "Diable !!! Ce n'est pas possible !..";
			link.l1 = "Peut-être. Mais en fin de compte, ça ne lui a pas apporté le bonheur, il est devenu mendiant...";
			link.l1.go = "ansewer_6_3";
		break;
		case "ansewer_6_3":
			dialog.text = "Bon sang ! Sacrebleu !! Sacrebleu !!! Est-ce vraiment possible... ?";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "ansewer_6_4";
		break;
		case "ansewer_6_4":
			dialog.text = "Vous savez quoi, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", ne parlez de ça à personne ! Si l'amiral apprend que quelqu'un a enfreint la Loi, et qu'il y est même parvenu... Bref, ce messager-là ne s'en portera pas bien.";
			link.l1 = "Hum, je ne comprends pas...";
			link.l1.go = "ansewer_6_5";
		break;
		case "ansewer_6_5":
			dialog.text = "Vous comprendrez plus tard. En attendant, pour votre propre bien, faites ce que je dis. Ne prononcez pas le nom de Teaser ! Compris ?";
			link.l1 = "Compris.";
			link.l1.go = "ansewer_6_6";
		break;
		case "ansewer_6_6":
			dialog.text = "D'accord. En attendant, je vais réfléchir à votre nouvelle...";
			link.l1 = "Très bien, jetez un coup d'œil.";
			link.l1.go = "int_quests";
			AddQuestRecord("ISS_MainLine", "4");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			SaveCurrentQuestDateParam("questTemp.LSC"); //запомним дату базара
		break;
		case "ansewer_7":
			dialog.text = "C'est la flמte « Fernando Diffindur », un endroit perdu.";
			link.l1 = "Expliquez-vous, je vous prie...";
			link.l1.go = "ansewer_7_1";
			NextDiag.(NodePrevName).l7 = true;
		break;
		case "ansewer_7_1":
			dialog.text = "Cette flמte aurait dמ couler : elle est littéralement fendue en deux. Pourtant, elle reste à la surface, on ne sait comment, elle semble accrochée aux récifs. Bref, ce navire est isolé, personne n'y vit et personne n'y vivra.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "ansewer_7_2";
		break;
		case "ansewer_7_2":
			dialog.text = "Ces navires-là, quand ils commencent à quitter l'eau, coulent en quelques secondes. Alors il faut être fou pour y passer du temps.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_8":
			dialog.text = "Il y en a dans notre Cité. Vous savez, il y a toujours des gens qui ne peuvent pas vivre en paix. Voilà ce qu'ils sont, les clans...";
			link.l1 = "Hum, comment faut-il le comprendre ?";
			link.l1.go = "ansewer_8_1";
			NextDiag.(NodePrevName).l8 = true;
		break;
		case "ansewer_8_1":
			dialog.text = "Eh bien, des forçats et des pirates se rassemblent dans ces clans... Bref, des éléments criminels, la lie de la société.";
			link.l1 = "Comment ça, vous me prenez pour de la racaille ? Je suis pirate !";
			link.l1.go = "ansewer_8_2";
		break;
		case "ansewer_8_2":
			dialog.text = "Non, vous n'êtes pas un pirate ordinaire, vous êtes un capitaine pirate. Dites, il ne vous manquait pas de crapules de tout poil dans votre équipage ?";
			link.l1 = "Eh bien, il y en avait assez, pour être honnête.";
			link.l1.go = "ansewer_8_3";
		break;
		case "ansewer_8_3":
			dialog.text = "C'est bien ce que je veux dire... Bref, nous leur avons donné deux navires pour qu'ils y restent et ne gênent pas le reste des citoyens. L'amiral et sa milice les tiennent en respect, sinon ce serait un vrai cauchemar ici.";
			link.l1 = "Et il y a des conflits avec eux ?";
			link.l1.go = "ansewer_8_4";
		break;
		case "ansewer_8_4":
			dialog.text = "Il y en a eu, bien sמr, mais maintenant, tout est calme. Mais gardez à l'esprit que vous ne devez pas entrer dans leurs navires !";
			link.l1 = "Compris. Eh bien, merci pour l'information.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_9":
			dialog.text = "Portez-la oם vous voulez. C'est l'affaire de chacun, personne ne vous aidera là-dessus.";
			link.l1 = "Oh, voilà qui est bien expliqué, je n'ai pas de mots...";
			link.l1.go = "ansewer_9_1";
			NextDiag.(NodePrevName).l9 = true;
		break;
		case "ansewer_9_1":
			dialog.text = "Eh bien, que puis-je vous dire ? Tous les coffres sont fermés par des serrures de trois niveaux de difficulté. Si une clé simple peut se trouver même dans la rue, les autres sont bien plus difficiles à obtenir. Après tout, c'est dans les coffres à bonne serrure que les gens cachent les choses vraiment précieuses\n"+
				"Même si vous obtenez les clés, gardez à l'esprit que d'autres ont aussi ces clés. Si vous voulez cacher quelque chose en lieu sמr, il vaut mieux chercher des coffres plus loin, hors de la Cité.";
			link.l1 = "Eh bien, c'est déjà plus ou moins clair. Merci.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_10":
			dialog.text = "Ha ! Si je savais, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", qui est Augusto Brahms... En fait, je ne veux même pas le savoir.";
			link.l1 = "Expliquez-vous, je vous prie.";
			link.l1.go = "ansewer_10_1";
			NextDiag.(NodePrevName).l10 = true;
		break;
		case "ansewer_10_1":
			dialog.text = "Hum, personne ne sait même comment il est arrivé ici, et vous voulez que je vous explique quelque chose. Il prête de l'argent, mais mieux vaut se tenir loin de lui"+ GetSexPhrase(", l'ami", "") +".";
			link.l1 = "Je n'ai rien compris...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_11":
			dialog.text = "Demandez à Eric Yost, au magasin. Il doit en avoir une.";
			link.l1 = "Merci, l'ami.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l11 = true;
		break;
		case "ansewer_12":
			dialog.text = "Je sais, mais pourquoi en avez-vous besoin ?";
			link.l1 = "Hum, c'est simplement intéressant...";
			link.l1.go = "ansewer_12_1";
			NextDiag.(NodePrevName).l12 = true;
		break;
		case "ansewer_12_1":
			dialog.text = "Vous ne devriez pas fouiller dans cette affaire, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", croyez-moi.";
			link.l1 = "Dites-le-moi, mon ami. Nous verrons bien si ça en vaut la peine ou non.";
			link.l1.go = "ansewer_12_2";
		break;
		case "ansewer_12_2":
			dialog.text = "Bon, d'accord... Bref, Dexter était pirate avant d'arriver dans la Cité. Tout comme Capper, d'ailleurs. Et leurs relations n'ont pas marché dès le début. Dexter a vite disparu. C'est tout ce que je peux vous dire.";
			link.l1 = "Oui, ce n'est pas grand-chose... Mais merci quand même, " + npchar.name + ".";
			link.l1.go = "int_quests";
		break;

		// ------------------ квесты ------------------
		//бармен забивает стрелу в винном погребе
		case "Tizer":
			dialog.text = "Oui, oui, j'ai réfléchi. Mais je ne peux pas en parler ici. Retrouvons-nous dans ma cave à vin après minuit.";
			link.l1 = "Oם se trouve votre cave à vin ?";
			link.l1.go = "Tizer_1";
		break;
		case "Tizer_1":
			dialog.text = "Eh bien, je l'appelle la cave par habitude, mais en fait, c'est l'une des cabines d'ici. Il faut aller sur le pont principal du Fleuron et entrer dans la dunette par là.";
			link.l1 = "Compris. Eh bien, c'est réglé.";
			link.l1.go = "Tizer_2";
		break;
		case "Tizer_2":
			dialog.text = "Ne traînez pas trop, je ne pourrai pas vous attendre longtemps.";
			link.l1 = "Compris. J'y serai sans faute.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toWineCellar";
			AddQuestRecord("ISS_MainLine", "5");
		break;
		//бармен ругается, что ГГ не пришёл в погреб
		case "TizerCellarLate":
			dialog.text = "Je le sais bien, puisque je vous y ai attendu une heure ! Bon sang, on ne peut pas être aussi léger dans une affaire aussi sérieuse !";
			link.l1 = "Laquelle est si sérieuse ?";
			link.l1.go = "TizerCellarLate_1";
		break;
		case "TizerCellarLate_1":
			dialog.text = "Je vous répète que je ne peux pas parler de cette affaire avec vous en public ! C'est de la folie !";
			link.l1 = "D'accord, ne vous énervez pas. Essayons de nous retrouver encore une fois, puisque c'est si nécessaire.";
			link.l1.go = "TizerCellarLate_2";
		break;
		case "TizerCellarLate_2":
			dialog.text = "Bon, d'accord. Je vous attendrai là-bas, dans la cave, après minuit, cette nuit. Mais cette fois, je vous en prie, venez.";
			link.l1 = "D'accord, j'y serai sans faute.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toWineCellar";
		break;
		//базар с барменом в погребе
		case "TizerCellar":
			dialog.text = "J'espère que vous n'avez parlé de Teaser Dan à personne pendant ce temps ?";
			link.l1 = "Non, comme convenu.";
			link.l1.go = "TizerCellar_1";
			LAi_CharacterDisableDialog(npchar);
			pchar.quest.LSC_returnBarmen_2.win_condition.l1 = "ExitFromLocation";
			pchar.quest.LSC_returnBarmen_2.win_condition.l1.location = pchar.location;
			pchar.quest.LSC_returnBarmen_2.function = "LSC_returnBarmen_2";
		break;
		case "TizerCellar_1":
			dialog.text = "C'est bien. Alors, laissez-moi vous exposer le fruit de mes réflexions sur cette affaire.";
			link.l1 = "Je vous écoute avec plaisir.";
			link.l1.go = "TizerCellar_2";
		break;
		case "TizerCellar_2":
			dialog.text = "Vous savez sans doute déjà que la Loi de la Cité interdit de construire quoi que ce soit qui permettrait de partir d'ici. Alors, je n'arrive tout simplement pas à imaginer comment Teaser a pu construire en douce une sorte de baquet, et en plus rejoindre le continent avec.";
			link.l1 = "Malheureusement, je n'ai pas pu voir Teaser en personne, sinon, sans aucun doute, j'aurais appris tous les détails de cette affaire.";
			link.l1.go = "TizerCellar_3";
		break;
		case "TizerCellar_3":
			dialog.text = "Oui, c'est dommage... Bon, voyons ce que nous avons. Et nous avons un mystère qu'il faut résoudre au plus vite. Avant de faire quoi que ce soit, il faut comprendre en détail comment Teaser a pu partir d'ici.";
			link.l1 = "Et ensuite quoi ?";
			link.l1.go = "TizerCellar_4";
		break;
		case "TizerCellar_4":
			dialog.text = "Si les citoyens apprennent que Teaser a atteint le continent, alors, sans aucun doute, beaucoup voudront suivre son exemple. Mais avant de dire quoi que ce soit sur Teaser Dan, il faut avoir des preuves de ce qu'on avance.";
			link.l1 = "Mais je...";
			link.l1.go = "TizerCellar_5";
		break;
		case "TizerCellar_5":
			dialog.text = "Votre seule parole ne suffit pas, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", voilà ce que je pense. Vous devriez aller sur la flמte « Fernando Diffindur ». Cet endroit est extrêmement dangereux : le navire est fendu en deux, et on ne comprend pas comment il reste à la surface. Pourtant, c'est là que Teaser Dan passait beaucoup de temps. Je pense que c'est là que nous trouverons la clé du mystère de Teaser.";
			link.l1 = "Comment y aller ?";
			link.l1.go = "TizerCellar_6";
		break;
		case "TizerCellar_6":
			dialog.text = "א la nage, la flמte n'est pas directement reliée à la Cité. Le plus proche du « Diffindur », c'est le San Gabriel, mais n'y entrez pas. Cette barque appartient au clan des Caspers !";
			link.l1 = "Compris. וcoutez, pouvez-vous nous donner une idée approximative de ce que nous cherchons sur le Diffindur ?";
			link.l1.go = "TizerCellar_7";
		break;
		case "TizerCellar_7":
			dialog.text = "Si seulement je le savais ! Je vous rappelle que nous cherchons des preuves que ce malheureux Teaser Dan a réussi à rejoindre le continent.";
			if (CheckCharacterItem(pchar, "letter_LSC"))
			{
				link.l1 = "Hum, vous savez, je suis déjà allé sur le « Diffindur ». Et j'y ai trouvé un coffre de Teaser. Entre autres, il y avait aussi une lettre très intéressante...";
				link.l1.go = "TizerCellarOk_1";
			}
			else
			{
				link.l1 = "Vous savez, j'ai une clé que l'ami de Teaser m'a donnée sur le continent. Dan avait ordonné de donner cette clé de Teaser à celui qui partirait à la recherche de l'טle de la Justice, c'est-à-dire de la Cité des navires abandonnés.";
				link.l1.go = "TizerCellar_8";
			}
		break;
		case "TizerCellar_8":
			dialog.text = "Intéressant, très intéressant... Cependant, encore une fois, ça ne prouve rien. Capper vous écoutera, puis il vous tuera devant les autres citoyens comme fauteur de troubles. Et personne ne lui dira rien. La clé ? Oui, il y a plein de clés dans la Cité, presque chaque coffre est fermé à clé.";
			link.l1 = "Oui, c'est vrai aussi.";
			link.l1.go = "TizerCellar_9";
		break;
		case "TizerCellar_9":
			dialog.text = "Cependant, la clé, c'est déjà quelque chose. Qu'a dit l'ami de Teaser à son sujet ?";
			link.l1 = "Que c'est la clé du « Diffindur ».";
			link.l1.go = "TizerCellar_10";
		break;
		case "TizerCellar_10":
			dialog.text = "Exactement ! Nous sommes sur la bonne piste ! Allez sur le Diffindur. Je pense que vous y trouverez un objet auquel cette clé ira. Teaser, même s'il me semblait un homme un peu bizarre, était loin d'être un imbécile, apparemment...";
			link.l1 = "Oh, c'est possible. Mais qu'il était un brave homme, c'est un fait.";
			link.l1.go = "TizerCellar_11";
		break;
		case "TizerCellar_11":
			dialog.text = "Je suis d'accord ! Bon, ne perdons pas de temps. J'attends les résultats de l'examen de la flמte.";
			link.l1 = "J'y serai bientכt, l'ami. Attendez-moi.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "6");
			pchar.questTemp.LSC = "toDiffindoor"; //флаг линейки ГПК
		break;

		case "TizerCellarOk_1":
			dialog.text = "Quelle est cette lettre ?";
			link.l1 = "Lisez-la vous-même. Tenez.";
			link.l1.go = "TizerCellarOk_2";
			TakeItemFromCharacter(pchar, "letter_LSC");
		break;
		case "TizerCellarOk_2":
			dialog.text = "Tiens, tiens, très intéressant... Il écrit : « ...car nous nous préparions depuis longtemps et très sérieusement. » Alors il n'était pas seul...";
			link.l1 = "Oui, apparemment, vous avez raison.";
			link.l1.go = "TizerCellarOk_3";
		break;
		case "TizerCellarOk_3":
			dialog.text = "Héhé, sans aucun doute ! Je connaissais assez bien Teaser, il n'aurait été capable de construire un radeau percé pour rien au monde : il avait deux mains gauches. Mais puisqu'il a réussi à rejoindre le continent, c'est que son assistant, bien sמr, est un spécialiste de la construction navale ! Mais c'est notre charpentier, André Labor !! Voilà ce qu'il faut faire, "+ GetSexPhrase("l'ami", "capitaine") +" : allez le voir. Parlez-lui calmement et tranquillement, racontez-lui l'histoire de Teaser Dan. Sinon, il ne sait même pas que ce vagabond a fini par atteindre le continent !";
			link.l1 = "Est-ce nécessaire ? Après tout, la lettre de Teaser est déjà une preuve de ce que je dis.";
			link.l1.go = "TizerCellarOk_4";
		break;
		case "TizerCellarOk_4":
			dialog.text = "C'est déjà mieux, mais on ne comprend toujours pas comment Teaser a réussi à faire une chose pareille. Je ne pense pas que nous devions exiger l'abrogation d'un article de la Loi sans avoir une proposition concrète en échange.";
			link.l1 = "Pourquoi ? Dès que nous lèverons l'interdiction de construire des navires, nous le ferons tout de suite. Là, nous déciderons quoi construire et comment.";
			link.l1.go = "TizerCellarOk_5";
		break;
		case "TizerCellarOk_5":
			dialog.text = "Ce n'est pas si simple, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Nous devons donner aux gens de l'espoir et un but, pas le droit de détruire la Cité comme bon leur semble. En abrogeant cet article de la Loi, nous devons immédiatement en adopter un nouveau : la construction d'UN navire pour TOUS !";
			link.l1 = "Hum, vous avez peut-être raison...";
			link.l1.go = "TizerCellarOk_6";
		break;
		case "TizerCellarOk_6":
			dialog.text = "Et il faut aussi se rappeler que l'amiral ne va sans doute pas rester planté là à vous écouter en se grattant la tête d'un air perplexe. Exiger l'abrogation d'un article de la Loi que Capper a introduit et qu'il fait appliquer avec zèle, c'est un gros risque. Nous devons convaincre l'amiral que nous avons raison, et ce ne sera pas facile, je pense.";
			link.l1 = "Pourquoi ce ne sera pas facile ?";
			link.l1.go = "TizerCellarOk_7";
		break;
		case "TizerCellarOk_7":
			dialog.text = "Hum, comment vous dire... Il m'arrive de me surprendre à penser que l'amiral n'a pas vraiment envie de partir d'ici.";
			link.l1 = "Hum, intéressant...";
			link.l1.go = "TizerCellarOk_8";
		break;
		case "TizerCellarOk_8":
			dialog.text = "Bref, ce ne sont que des suppositions, nous y reviendrons plus tard. Maintenant, trouvez André Labor et découvrez prudemment tout ce qu'il sait sur l'affaire de Teaser.";
			link.l1 = "D'accord, c'est ce que je vais faire.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toAndreLabor"; //флаг линейки ГПК
			AddQuestRecord("ISS_MainLine", "7");
			pchar.questTemp.LSC.checkBoxes = true; //шмалять по открытым сундукам ежесуточно
		break;

		case "AfterProtector_1":
			dialog.text = "Que s'est-il passé ?";
			link.l1 = "Hum... Bon, en gros, j'ai parlé au charpentier, cet André Labor, et il m'a demandé d'aller dans la cabine de la corvette « Protector ». J'y suis allé, bon, je l'ai attendu, je ne me doutais de rien... Et cet André a amené un policier pour me parler ! J'ai dמ envoyer tout le monde dans l'autre monde.";
			link.l1.go = "AfterProtector_2";
		break;
		case "AfterProtector_2":
			dialog.text = "Diable ! Il fallait s'y attendre ! Eh bien, maintenant, vous êtes fichu... écoutez, ayez la bonté de ne pas dire que c'est moi qui vous ai poussé à le faire. Ils vous tueront de toute façon, mais moi, je peux encore vivre...";
			link.l1 = "Comportez-vous en homme ! Personne ne me tuera, car personne ne sait que c'est moi qui l'ai fait. Ils n'ont pas eu le temps de parler de moi à l'amiral.";
			link.l1.go = "AfterProtector_3";
		break;
		case "AfterProtector_3":
			dialog.text = "Vous en êtes sמr ?";
			link.l1 = "C'est le policier lui-même qui l'a dit.";
			link.l1.go = "AfterProtector_4";
		break;
		case "AfterProtector_4":
			dialog.text = "דa va mieux, même si je ne vois aucune raison de me calmer. L'amiral est loin d'être un imbécile, il vous démasquera.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "AfterProtector_5";
		break;
		case "AfterProtector_5":
			dialog.text = "Hum, je pense que nous devrions tout mettre sur le dos de l'un des clans.";
			link.l1 = "Laquelle ?";
			link.l1.go = "AfterProtector_6";
		break;
		case "AfterProtector_6":
			dialog.text = "Sur celui des Narvals, ils sont plus faibles.";
			link.l1 = "Comment faire ? Je ne peux pas aller voir Chad et lui dire : « Ce n'est pas moi, ce sont les Narvals ! »";
			link.l1.go = "AfterProtector_7";
		break;
		case "AfterProtector_7":
			dialog.text = "Tous les membres du clan des Narvals portent une amulette à l'image d'une étoile à cinq branches renversée. Procurez-vous cette amulette et apportez-la à l'amiral. Dites-lui que vous l'avez trouvée sur le lieu du meurtre du policier et du charpentier.";
			link.l1 = "Et comment trouver cet anneau ?";
			link.l1.go = "AfterProtector_8";
		break;
		case "AfterProtector_8":
			dialog.text = "א la proue du galion Velasco, il y a une cabine oם les Narvals entreposent toutes sortes de bricoles. C'est une sorte d'arrière-boutique pour eux. Attendez-y l'un d'eux, et quand le Narval apparaîtra, tuez-le.";
			link.l1 = "Compris. Eh bien, c'est ce que je vais faire.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "10");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC = "toKillOneNarval";
			pchar.quest.LSC_KillOneNarval.win_condition.l1 = "locator";
			pchar.quest.LSC_KillOneNarval.win_condition.l1.location = "VelascoShipInside1";
			pchar.quest.LSC_KillOneNarval.win_condition.l1.locator_group = "reload";
			pchar.quest.LSC_KillOneNarval.win_condition.l1.locator = "reload2";
			pchar.quest.LSC_KillOneNarval.function = "LSC_KillOneNarval";
		break;

		case "NarvalRing_1":
			dialog.text = NPCStringReactionRepeat("Parfait ! Maintenant, allez voir l'amiral et dites-lui que vous l'avez trouvée dans la cabine du « Protector ».",
				"J'ai compris. Ce n'est pas à moi, mais à l'amiral qu'il faut la montrer.",
				"וcoutez, ça ne m'amuse plus. Allez voir l'amiral !",
                "Vous êtes bouché, quand même...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Compris.",
				"Oui, bien sמr...",
                "Oui, c'est sמr !",
				"Oui, bien bouché. Je fais toujours la même chose. Sur quoi je compte, on ne le sait pas...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "", "", "", npchar, Dialog.CurrentNode);
		break;

		case "AfterNarvalDesrt_1":
			dialog.text = "Allons donc !";
			link.l1 = "Exactement ! Grâce à l'amulette, j'ai réussi à prouver à Capper que les Narvals avaient commis le meurtre du policier. L'amiral m'a cru et m'a envoyé les exterminer tous. Ce que j'ai fait.";
			link.l1.go = "AfterNarvalDesrt_2";
		break;
		case "AfterNarvalDesrt_2":
			dialog.text = "Eh bien, c'est formidable... Bon, "+ GetSexPhrase("frère", "sœur") +", vous méritez une médaille. Même si, à bien y réfléchir, votre acte a fait plus de mal que de bien.";
			link.l1 = "Comment ça ?";
			link.l1.go = "AfterNarvalDesrt_3";
		break;
		case "AfterNarvalDesrt_3":
			dialog.text = "Voyez-vous, avant votre « exploit », il y avait un équilibre dans la Cité : les « Caspers » étaient contrebalancés par les « Narvals ». C'est du passé maintenant...";
			link.l1 = "Hé, c'est vous qui avez eu l'idée de faire porter le chapeau aux Narvals, et maintenant, vous n'êtes pas content.";
			link.l1.go = "AfterNarvalDesrt_4";
		break;
		case "AfterNarvalDesrt_4":
			dialog.text = "Bon, je ne suis pas mécontent, j'exprime simplement mes pensées. Et puis, j'avais assez peur à ce moment-là, je l'avoue...";
			link.l1 = "Hé, oui, ça se voyait.";
			link.l1.go = "AfterNarvalDesrt_5";
		break;
		case "AfterNarvalDesrt_5":
			dialog.text = "Que comptez-vous faire maintenant ? Vous êtes un héros, maintenant.";
			link.l1 = "Je ne sais pas. On dirait que j'ai gagné le respect de Chad. En fait, je commence à me plaire ici. Peut-être que je vais m'engager dans la police...";
			link.l1.go = "AfterNarvalDesrt_6";
		break;
		case "AfterNarvalDesrt_6":
			dialog.text = "Je vais vous dire, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +", allez donc vous promener pour l'instant, mais n'oubliez pas de passer me voir. Je vais essayer de découvrir quelque chose ici...";
			link.l1 = "Quoi donc ?";
			link.l1.go = "AfterNarvalDesrt_7";
		break;
		case "AfterNarvalDesrt_7":
			dialog.text = "C'est trop tכt pour en parler.";
			link.l1 = "D'accord, je viendrai vous voir.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "waitInterception";
			SaveCurrentQuestDateParam("questTemp.LSC"); //запомним дату базара
			AddQuestRecord("ISS_MainLine", "17");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;

		case "Interception":
			dialog.text = "Vous savez, il se passe beaucoup de choses étranges dans ma taverne. Parfois, je pense qu'en réalité, rien n'est comme il paraît...";
			link.l1 = "Quoi ?";
			link.l1.go = "Interception_1";
		break;
		case "Interception_1":
			dialog.text = "Je suis devenu philosophe, en quelque sorte, vous savez... Bref, je vous propose de faire quelque chose. Vous vous souvenez oם est ma cave à vin ?";
			link.l1 = "Je m'en souviens, bien sמr.";
			link.l1.go = "Interception_2";
		break;
		case "Interception_2":
			dialog.text = "Alors, soyez-y avant minuit ce soir, tenez-vous près de la grille, derrière la colonne, et attendez. Tournez-vous simplement de façon à ce que vos épaules ne dépassent pas de la colonne. Vous pourrez peut-être surprendre une conversation très intéressante, qui influencera votre décision sur la suite.";
			link.l1 = "La conversation de qui ?";
			link.l1.go = "Interception_3";
		break;
		case "Interception_3":
			dialog.text = "De l'amiral et d'une autre personne. Je me demande depuis longtemps de quoi ils parlent là-bas de temps en temps... Bref, faites-le, et je pense que la situation s'éclaircira à bien des égards.";
			link.l1 = "D'accord, comme vous voudrez.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toInterception";
			pchar.questTemp.LSC.itemState = false; //флаг нахождения в локаторе итем в таверне
			AddQuestRecord("ISS_MainLine", "18");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;

		case "InterceptionLate":
			dialog.text = "Oui, ce n'est pas assez bien, comme on dit... Bon, maintenant, faites ce que vous voulez et vivez comme bon vous semble.";
			link.l1 = "Hum, je vois... Et qui était la personne que l'amiral devait rencontrer ?";
			link.l1.go = "InterceptionBadWork_1";
		break;
		case "InterceptionYouSeen":
			dialog.text = "Oui, ce n'est pas assez bien, comme on dit... Bon, maintenant, faites ce que vous voulez et vivez comme bon vous semble.";
			link.l1 = "Hum, je vois... Et qui était l'homme qui parlait avec l'amiral ?";
			link.l1.go = "InterceptionBadWork_1";
		break;
		case "InterceptionBadWork_1":
			dialog.text = "C'est le chef du clan des Caspers, Casper Longman.";
			link.l1 = "Héhé, ça alors !..";
			link.l1.go = "InterceptionBadWork_2";
		break;
		case "InterceptionBadWork_2":
			dialog.text = "Un jour, je suis tombé sur eux par hasard, près de la grille de la cave, pendant qu'ils parlaient. Je me suis mis à les surveiller et j'ai compris qu'ils se retrouvaient secrètement ici de temps en temps. J'aimerais bien entendre de quoi ils parlent...";
			link.l1 = "Eh bien, il n'est peut-être pas trop tard ? Attendons leur prochaine rencontre.";
			link.l1.go = "InterceptionBadWork_3";
		break;
		case "InterceptionBadWork_3":
			dialog.text = "Nous attendrons, bien sמr, mais maintenant, je ferai tout moi-même. Ce serait intéressant d'entendre leur conversation en ce moment, après le massacre des Narvals que vous avez orchestré. Et maintenant, il va falloir attendre...";
			link.l1 = "Hum, je vois. Et combien de temps attendre ?";
			link.l1.go = "InterceptionBadWork_4";
		break;
		case "InterceptionBadWork_4":
			dialog.text = "דa dépendra.";
			link.l1 = "Compris. Eh bien, d'accord. Je passerai vous voir de temps en temps.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "waitInterceptionResult";
			AddQuestRecord("ISS_MainLine", "21");
			SetTimerFunction("LSC_changeBarmen", 0, 0, 15);
		break;

		case "Result":
			dialog.text = NPCStringReactionRepeat("Pas encore, mais j'essaie. Attendez.",
				"Je vous ai déjà dit de continuer à attendre. Rien de nouveau pour l'instant.",
				"Pour la troisième fois, je répète : attendez.",
                "Pas encore fatigué ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Bien.",
				"Oui, oui, je comprends.",
                "Je comprends, j'attendrai.",
				"Non, je suis tenace.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

		case "InterceptionOk":
			sld = characterFromId("LSCMayor");
			if (sld.location == "FleuronTavern")
				dialog.text = "Parlez plus bas, "+ GetSexPhrase("l'ami", "ma petite") +" ! J'ai l'amiral ici même, qui se détend... Alors, vous avez réussi à entendre la conversation ?";
			else
				dialog.text = "Vous avez surpris la conversation ?";
			link.l1 = "Oui. Il s'avère que l'amiral compte quitter la Cité lui-même !";
			link.l1.go = "InterceptionOk_1";
		break;
		case "InterceptionOk_1":
			dialog.text = "Ce n'est pas possible ! C'est lui-même qui a fait adopter l'article de la Loi qui interdit même de construire des navires !";
			link.l1 = "Eh bien, il ne l'a pas encore construit, il compte seulement le faire.";
			link.l1.go = "InterceptionOk_2";
		break;
		case "InterceptionOk_2":
			dialog.text = "Impossible de le faire à l'insu des autres citoyens !";
			link.l1 = "C'est possible. Le clan des Caspers travaille pour l'amiral. De toute façon, inutile d'aller chercher loin un vrai exemple : Teaser Dan y est bien parvenu.";
			link.l1.go = "InterceptionOk_4";
		break;
		case "InterceptionOk_4":
			dialog.text = "Oui, en effet... Eh bien, je vous avais dit que ce serait important !";
			link.l1 = "Mmm, ça ne pourrait pas être plus important... וcoutez, l'amiral a parlé d'un certain Mécanicien. Qui est-ce ?";
			link.l1.go = "InterceptionOk_5";
		break;
		case "InterceptionOk_5":
			dialog.text = "Hum, je ne sais pas...";
			link.l1 = "Que diable !.. וcoutez, vous vivez ici depuis longtemps, vous devriez connaître tout le monde.";
			link.l1.go = "InterceptionOk_6";
		break;
		case "InterceptionOk_6":
			dialog.text = "Qu'est-ce qui vous fait croire que votre Mécanicien existe ? Vous avez peut-être mal compris ce qu'a dit l'amiral ?";
			link.l1 = "C'est possible, mais peu probable... וcoutez, y a-t-il un citoyen qui vivait déjà ici avant votre arrivée dans la Cité ?";
			link.l1.go = "InterceptionOk_7";
		break;
		case "InterceptionOk_7":
			dialog.text = "J'ai du mal à répondre. Il me semble qu'il n'y en a plus aucun de vivant...";
			link.l1 = "Vous en êtes sמr ? Réfléchissez bien.";
			link.l1.go = "InterceptionOk_8";
		break;
		case "InterceptionOk_8":
			dialog.text = "D'accord, je vais y réfléchir, mais pas maintenant. Je dois travailler, alors revenez demain.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "waitInterceptionResult";
			AddQuestRecord("ISS_MainLine", "23");
			SetTimerFunction("LSC_changeBarmen", 0, 0, 3);
		break;
		//смерть Брюннера
		case "NB_1":
			dialog.text = "Vous ne savez donc rien ? Brunner n'est plus...";
			link.l1 = "Comment ça ?";
			link.l1.go = "NB_2";
			npchar.quest.HillNB_1 = true;
		break;
		case "NB_2":
			dialog.text = "On l'a trouvé mort dans la cave à vin de la taverne. Vous connaissez cette cabine à l'arrière, oם sont les tonneaux de vin ? C'est là qu'on l'a trouvé...";
			link.l1 = "דa alors ! Vous avez vu quelqu'un ? A-t-on trouvé l'assassin ?";
			link.l1.go = "NB_3";
		break;
		case "NB_3":
			dialog.text = "Non, personne n'a rien vu. Armo, notre serveuse, l'a trouvé déjà mort. Elle est allée à la cave parce que Hill y restait longtemps, et voilà...";
			link.l1 = "Bon sang !.. C'est vous le tavernier maintenant, si je comprends bien.";
			link.l1.go = "NB_4";
		break;
		case "NB_4":
			dialog.text = "Oui. Dès que tout s'est su, l'amiral m'a appelé et m'a demandé de reprendre l'affaire de Brunner. Sans taverne, voyez-vous, il n'y a pas de vie...";
			link.l1 = "C'est vrai... Eh bien, bonne chance dans votre nouvelle place.";
			link.l1.go = "exit";
			if (pchar.questTemp.LSC == "barmenIsDeadYouKnow")
			{
				pchar.questTemp.LSC = "toArmo_BrunnerDead";
			}
			AddQuestRecord("ISS_MainLine", "24");
		break;

		case "NBB_1":
			dialog.text = "On ne peut plus morte, "+ GetSexPhrase("l'ami", "ma petite") +".";
			link.l1 = "Comment est-ce arrivé ?";
			link.l1.go = "NBB_2";
			npchar.quest.HillNBB_1 = true;
		break;
		case "NBB_2":
			dialog.text = "On l'a trouvé mort dans la cave à vin de la taverne. Vous connaissez cette cabine à l'arrière, oם sont les tonneaux de vin ? C'est là qu'on l'a trouvé...";
			link.l1 = "Vous avez vu quelqu'un ? A-t-on trouvé l'assassin ?";
			link.l1.go = "NB_3";
		break;
		//базар по убийству Армо
		case "ADied_1":
			dialog.text = "Vous parlez ! Personne n'a même vu ce qui s'est passé. Elle est allée faire le ménage à l'avant de la taverne, oם il y a un lit. Soudain, nous l'avons entendue crier. Et c'est tout...";
			link.l1 = "Et ensuite ?";
			link.l1.go = "ADied_2";
		break;
		case "ADied_2":
			dialog.text = "Tout le monde a couru là-bas, et elle était étendue, la gorge tranchée. C'est tout, que voulez-vous faire ?";
			link.l1 = "Il n'y a rien à faire ici. Vous avez vu qui c'était ? Mais je le sais. C'est l'un des « Caspers ».";
			link.l1.go = "ADied_3";
		break;
		case "ADied_3":
			dialog.text = "Alors ils sont devenus incontrכlables, finalement. Eh oui... Et pourquoi l'ont-ils tuée ?";
			link.l1 = "Tout ça, c'est à cause de moi. Diable, je ne me le pardonnerai jamais !";
			link.l1.go = "exit";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Quoi donc ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de bombes, de boulets ramés, de vivres, de poudre, d'armes, de médicaments...",
				"Oui... Pardonnez-moi, j'avais oublié.",
                "Ah, oui.",
				"Compris...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Désolé, nous n'en avons pas.";
			link.l1 = "Je comprends, merci.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Quel équipage ?",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "דa suffit, je suis fatigué...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Au navire. Je quitte la Cité.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Et sur quoi, au juste ?";
			link.l1 = "Oui. Sinon, je ne vous aurais pas appelé.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Oui... Vous savez, je crois que je vais refuser. J'attendrai l'autorisation, et que l'amiral rassemble tout le monde.";
			link.l1 = "Vous prenez un gros risque en restant. Une forte tempête approche de la Cité.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Bah, ce ne sera pas la première fois...";
			link.l1 = "Hum... Eh bien, comme vous voudrez.";
			link.l1.go = "exit";
		break;
		case "MetAgain1":
			dialog.text = "La tempête a été si violente, pour la première fois depuis des années ! Nous pensions que toute la Cité allait être arrachée des rochers et engloutie dans l'abîme.";
			link.l1 = "J'ai eu de la chance, en gros, je suis parti en pleine tempête. J'ai eu du mal à rejoindre le navire.";
			link.l1.go = "MetAgain2";
		break;
		case "MetAgain2":
			dialog.text = "Je ne sais pas combien de temps a passé, mais la tempête s'est soudain calmée... Et un calme plat, sans le moindre souffle de vent.";
			link.l1 = "Et comment ça se passe ici maintenant, sans pouvoir, sans amiral ?";
			link.l1.go = "MetAgain3";
		break;
		case "MetAgain3":
			dialog.text = "Vous savez, pas grand-chose n'a changé, si ce n'est que presque tous les anciens clients ne sont plus là.";
			link.l1 = "Je peux vous aider en quelque chose ? Après tout, c'est en grande partie à cause de moi que les choses ont tourné ainsi.";
			link.l1.go = "MetAgain4";
		break;
		case "MetAgain4":
			dialog.text = "Bon, des marchandises, il y en a assez, bien sמr, mais un apport de l'extérieur ne ferait pas de mal. Je ne refuserais pas d'acheter des vivres, du vin, de la bière ou du rhum. Bref, il ne serait pas mauvais d'avoir un repas normal ici aussi, sinon c'est toujours du poisson... Nous ne vous léserons pas sur le prix, vous savez. Il y en avait bien assez à la résidence, et la cache des Caspers, ce n'est pas rien non plus.";
			link.l1 = "Je vous aiderai autant que je pourrai. Si je passe près de l'île, je viendrai sans faute vendre quelque chose.";
			link.l1.go = "MetAgain5";
		break;
		case "MetAgain5":
			dialog.text = "Merci, capitaine.";
			link.l1 = "Je vous en prie.";
			link.l1.go = "exit";
		break;
		case "TradeGoods":
			dialog.text = "Alors, qu'avez-vous apporté, capitaine ? Il y a de la place dans les entrepכts.";
			if (CheckAttribute(pchar, "Ship.Cargo.Goods.Food") && sti(pchar.Ship.Cargo.Goods.Food) > 0)
			{
				link.l1 = "Vivres : "+pchar.Ship.Cargo.Goods.Food+" unités";
				link.l1.go = "TradeGoods_1";
			}
			if (CheckAttribute(pchar, "Ship.Cargo.Goods.Wine") && sti(pchar.Ship.Cargo.Goods.Wine) > 0)
			{
				link.l2 = "Vin : "+pchar.Ship.Cargo.Goods.Wine+" unités";
				link.l2.go = "TradeGoods_2";
			}
			if (CheckAttribute(pchar, "Ship.Cargo.Goods.Ale") && sti(pchar.Ship.Cargo.Goods.Ale) > 0)
			{
				link.l3 = "Bière : "+pchar.Ship.Cargo.Goods.Ale+" unités";
				link.l3.go = "TradeGoods_3";
			}
			if (CheckAttribute(pchar, "Ship.Cargo.Goods.Rum") && sti(pchar.Ship.Cargo.Goods.Rum) > 0)
			{
				link.l4 = "Rhum : "+pchar.Ship.Cargo.Goods.Rum+" unités";
				link.l4.go = "TradeGoods_4";
			}
			if (CheckAttribute(pchar, "Ship.Cargo.Goods.Fruits") && sti(pchar.Ship.Cargo.Goods.Fruits) > 0)
			{
				link.l5 = "Fruits : "+pchar.Ship.Cargo.Goods.Fruits+" unités";
				link.l5.go = "TradeGoods_5";
			}
			link.l99 = "Je dois y réfléchir.";
			link.l99.go = "exit";
		break;
		case "TradeCheck":
			switch (sti(npchar.GoodType))
			{
				case 1: dialog.text = "Des vivres ? Et combien en vendez-vous ?"; break;
				case 2: dialog.text = "Du vin ? Et combien en vendez-vous ?"; break;
				case 3: dialog.text = "De la bière ? Et combien en vendez-vous ?"; break;
				case 4: dialog.text = "Du rhum ? Et combien en vendez-vous ?"; break;
				case 5: dialog.text = "Des fruits ? Et combien en vendez-vous ?"; break;
			}
			Link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "TradeCheck2";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeCheck2":
			npchar.amount = GetStrSmallRegister(dialogEditStrings[1]);
			string sGoodX
			switch (sti(npchar.GoodType))
			{
				case 1:	sGoodX = "Food"; break;
				case 2:	sGoodX = "Wine"; break;
				case 3:	sGoodX = "Ale"; break;
				case 4:	sGoodX = "Rum"; break;
				case 5:	sGoodX = "Fruits"; break;
			}
			npchar.amount = func_min(sti(npchar.amount), sti(pchar.Ship.Cargo.Goods.(sGoodX))); //фикс, нельзя продать больше, чем привёз
			npchar.amount = func_max(sti(npchar.amount),1);
			switch (sti(npchar.GoodType))
			{
				case 1:
					NPChar.sumtotal = sti(npchar.amount)*10;
					dialog.text = "Je prends les vivres à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?"; 
				break;
				case 2: 
					NPChar.sumtotal = sti(npchar.amount)*150;
					dialog.text = "Je prends le vin à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?"; 
				break;
				case 3: 
					NPChar.sumtotal = sti(npchar.amount)*40;
					dialog.text = "Je prends la bière à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
				break;
				case 4: 
					NPChar.sumtotal = sti(npchar.amount)*20;
					dialog.text = "Je prends le rhum à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
				break;
				case 4: 
					NPChar.sumtotal = sti(npchar.amount)*20;
					dialog.text = "Je prends le rhum à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
				break;
				case 5: 
					NPChar.sumtotal = sti(npchar.amount)*50;
					dialog.text = "Je prends les fruits à 50 l'unité. Au total, "+NPChar.sumtotal+" pièces d'or pour "+npchar.amount+" unités. L'offre vous convient-elle ?";
				break;
			}
			link.l1 = "Oui. Marché conclu !";
			link.l1.go = "TradeCheck3";
			link.l2 = "Je dois y réfléchir.";
			link.l2.go = "exit";
		break;
		case "TradeCheck3":
			switch (sti(npchar.GoodType))
			{
				case 1:
					pchar.Ship.Cargo.Goods.Food = sti(pchar.Ship.Cargo.Goods.Food)-sti(npchar.amount);
				break;
				case 2: 
					pchar.Ship.Cargo.Goods.Wine = sti(pchar.Ship.Cargo.Goods.Wine)-sti(npchar.amount);
				break;
				case 3: 
					pchar.Ship.Cargo.Goods.Ale = sti(pchar.Ship.Cargo.Goods.Ale)-sti(npchar.amount);
				break;
				case 4: 
					pchar.Ship.Cargo.Goods.Rum = sti(pchar.Ship.Cargo.Goods.Rum)-sti(npchar.amount);
				break;
				case 5: 
					pchar.Ship.Cargo.Goods.Fruits = sti(pchar.Ship.Cargo.Goods.Fruits)-sti(npchar.amount);
				break;
			}
			dialog.text = "C'est un plaisir de faire affaire avec vous. Prenez, et signez ici !";
			AddCharacterExpToSkill(pchar, "Commerce", sti(NPChar.sumtotal) / 2500.0);
			/*if (sti(NPChar.sumtotal) >= 15000)
			{
				int chestsamount = makeint(sti(NPChar.sumtotal)/15000);
				TakenItems(pchar, "Chest",chestsamount);
				NPChar.sumtotal = sti(NPChar.sumtotal)-(15000*chestsamount);
				log_info("Received credit chest in the amount of "+chestsamount+"pcs.");
			}*/
			AddMoneyToCharacter(pchar, sti(NPChar.sumtotal));
			link.l1 = "Avec vous aussi. א bientכt !";
			link.l1.go = "exit";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
