// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je demanderai plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//==> Проверка на стейт квестов
			if (pchar.questTemp.State == "Sp10Maracaibo_toMaracaibo")
			{
				dialog.text = "Je vous écoute...";
				link.l1 = "Señor, je suis venu vous voir pour remplir une mission de confiance : protéger Maracaibo d'une menace extérieure. Je suis détaché à votre disposition par le gouverneur de La Havane, Francisco Oregon y Gascon.";
				link.l1.go = "Step_S10_1";
			}
			if (pchar.questTemp.State == "Sp10Maracaibo_toGovernor")
			{
				dialog.text = "Eh bien, vous tombez à pic. Nous n'avons pas encore eu le temps de nous installer ni de placer un équipage en ville, et déjà, au combat !";
				link.l1 = "C'est exact !";
				link.l1.go = "Step_S10_4";
			}
			if (pchar.questTemp.State == "Sp10Maracaibo_toBattle")
			{
				dialog.text = "Vous êtes encore là ? Je crois qu'il est temps pour vous d'aller au combat.";
				link.l1 = "C'est exact, señor. Je ne ferai pas attendre les ladrones...";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.State == "Sp10Maracaibo_GoodWork")
			{
				dialog.text = "Excellent travail, "+ GetSexPhrase("mon ami","señorita") +". Don Francisco m'a envoyé un capitaine très brave et très intelligent !";
				link.l1 = "Merci, señor...";
				link.l1.go = "Step_S10_5";
			}
			//<== Проверка на стейт квестов
		break;
		//************************** Квестовые штрумы ************************
		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;

        //==> Двенадцатый квест голл. линейки. Захват Маракайбо.
        case "HolLine12Quest_Occupy":
			dialog.text = "Voilà, nous avons cessé de résister. La ville est à vous. Que va-t-il se passer maintenant ?";
			link.l1 = "Cette ville appartient désormais à la République des Provinces-Unies. L'administration hollandaise y est établie et les lois hollandaises y entrent en vigueur.";
			link.l1.go = "Step_H12_1";
			AfterTownBattle();
        break;
        case "Step_H12_1":
			dialog.text = "Vous êtes plus forts pour le moment. Mais nous verrons ce qui se passera dans quelque temps. Apparemment, le Portugal dans l'océan Indien ne vous a pas beaucoup inquiétés, puisque vous avez décidé de faire un pas aussi audacieux.";
			link.l1 = "Ce pas est une réponse logique aux attaques des escadres espagnoles.";
			link.l1.go = "Step_H12_2";
        break;
        case "Step_H12_2":
			dialog.text = "Si vous n'aviez pas fourni de l'argent à la France, rien de tout cela ne serait arrivé !";
			link.l1 = "Je crois qu'il est trop tard pour discuter de quoi que ce soit maintenant. Cette ville est devenue hollandaise, et ensuite, nous verrons.";
			link.l1.go = "exit";
            AddQuestRecord("Hol_Line_12_OccupyMaracaibo", "2");
            pchar.questTemp.State = "OccupyMaracaibo_toWeWon";
            NextDiag.TempNode = "Cupture_after";
			PChar.questTemp.DontSetNewDialogToMayor = true; // иначе может сменить диалог и сбойнуть
            PChar.questTemp.DontNullDeposit = true;    // чтоб не нулили ростовщика
            SetCaptureTownByNation(NPChar.City, sti(PChar.nation));
            DeleteAttribute(PChar, "questTemp.DontSetNewDialogToMayor");
            UpdateRelations();
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
            SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
            AddDialogExitQuestFunction("LaunchColonyInfoScreen"); // табличка
        break;
        //==> Десятый квест испанки. Защита Маракайбо.
        case "Step_S10_1":
			dialog.text = "Excellent, ma demande de renforcer l'escadre et la garnison a été satisfaite !";
			link.l1 = "Oui, c'est cela. Pourriez-vous me dire ce que vous craignez ?";
			link.l1.go = "Step_S10_2";
        break;
        case "Step_S10_2":
			dialog.text = "Bien sמr, capitaine. Voilà : j'ai des informations selon lesquelles une nouvelle bande de brigands anglais de Port Royal s'apprête à s'emparer de Maracaibo. Ces informations ne méritent pas une confiance absolue, mais j'ai néanmoins demandé de l'aide au señor Francisco Oregon y Gascon.";
			link.l1 = "Compris. Que dois-je faire maintenant ?";
			link.l1.go = "Step_S10_3";
        break;
        case "Step_S10_3":
			dialog.text = "En fait, rien. Restez simplement sur le qui-vive.";
			link.l1 = "Mon équipage et moi le sommes toujours... Bon, si vous n'avez pas besoin de moi, je vais sans doute faire un tour en ville pour mes propres affaires.";
			link.l1.go = "exit";
			pchar.questTemp.State = "Sp10Maracaibo_TalkWithOfficer";
            Pchar.quest.Sp10Maracaibo_TalkWithOfficer.win_condition.l1 = "location";
            Pchar.quest.Sp10Maracaibo_TalkWithOfficer.win_condition.l1.location = "Maracaibo_town";
            Pchar.quest.Sp10Maracaibo_TalkWithOfficer.win_condition = "Sp10Maracaibo_TalkWithOfficer";
		break;
        case "Step_S10_4":
			dialog.text = "Je vous prie de procéder à votre mission. Il faut détruire l'escadre pirate anglaise !";
			link.l1 = "Très bien, señor.";
			link.l1.go = "exit";
			LocatorReloadEnterDisable("Maracaibo_town", "gate_back", false);
			LocatorReloadEnterDisable("Maracaibo_town", "reload1_back", false);
			pchar.questTemp.State = "Sp10Maracaibo_toBattle";
            Pchar.quest.Sp10Maracaibo_Battle.win_condition.l1 = "location";
            Pchar.quest.Sp10Maracaibo_Battle.win_condition.l1.location = "Maracaibo";
            Pchar.quest.Sp10Maracaibo_Battle.win_condition = "Sp10Maracaibo_Battle";
        break;
        case "Step_S10_5":
			dialog.text = "Pour avoir repoussé avec succès l'attaque anglaise, la ville est prête à vous verser 70 000 pièces d'or. Veuillez les recevoir, capitaine.";
			link.l1 = "Très bien.";
			link.l1.go = "Step_S10_6";
        break;
        case "Step_S10_6":
			dialog.text = "Votre mission est donc accomplie ici, je n'ose pas vous retenir plus longtemps. Transmettez mes sincères remerciements au gouverneur général Oregon y Gascon.";
			link.l1 = "Sans faute, señor. Au revoir.";
			link.l1.go = "exit";
			pchar.questTemp.State = "Sp10Maracaibo_2GoodWork";
			AddMoneyToCharacter(pchar, 70000);
        break;



	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

