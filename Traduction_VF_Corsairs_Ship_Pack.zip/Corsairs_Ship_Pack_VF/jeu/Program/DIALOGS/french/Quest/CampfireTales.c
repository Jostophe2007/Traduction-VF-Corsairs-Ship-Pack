// LEO: Campfire storytellers in Marigo. FOUR sailors/officers, each spins ONE yarn per evening (a monologue).
// The player listens to each in turn, the dialog never breaks; the camera switches to the speaker (node tale_next).
// Spawn/tale-pick/seating logic is in scripts\CampfireTales.c. Tale nodes S<n>_1..S<n>_3 (one teller's monologue).
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iIdx, iTale;
	ref rT, rHost;
	string sNum, sHostName;

	switch(Dialog.CurrentNode)
	{
		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "first time":
			NextDiag.TempNode = "first time";
			// LEO: not the chief teller - send them to the host (slot 0)
			if (!CheckAttribute(NPChar, "campHost"))
			{
				sHostName = "celui qui est là-bas";
				rHost = CharacterFromID(Campfire_GetTeller(0));
				if (CheckAttribute(rHost, "name")) sHostName = rHost.name;
				dialog.text = "Il vous faut " + sHostName + ", capitaine : ce soir, c'est notre conteur en chef.";
				link.l1 = "Bien.";
				link.l1.go = "exit";
				break;
			}
			// LEO: all the evening's yarns are already told (Idx reached Target)
			if (CheckAttribute(pchar, "CampfireTales.Idx") && CheckAttribute(pchar, "CampfireTales.Target"))
			{
				if (sti(pchar.CampfireTales.Idx) >= sti(pchar.CampfireTales.Target))
				{
					dialog.text = "C'est tout pour ce soir, capitaine. Nos langues ne veulent plus tourner. Repassez un autre soir.";
					link.l1 = "Bonne nuit.";
					link.l1.go = "exit";
					break;
				}
			}
			SetCameraDialogMode(NPChar);
			dialog.text = "Bonsoir, capitaine. Asseyez-vous près du feu : on se raconte des histoires. Vous voulez en entendre une ou deux ?";
			link.l1 = "Avec plaisir.";
			link.l1.go = "begin_listen";
			link.l2 = "Une autre fois.";
			link.l2.go = "exit";
		break;

		case "begin_listen":
			dialog.text = "Alors installez-vous, posez-vous : inutile de rester debout.";
			LAi_Fade("", "");
			DoQuestFunctionDelay("Campfire_SeatPlayer", 0.5);
			link.l1 = "(וcouter)";
			link.l1.go = "tale_next";
		break;

		// LEO: dispatcher - sets the camera on the next teller and leads to HIS yarn; ends the evening after the 4th.
		case "tale_next":
			iIdx = sti(pchar.CampfireTales.Idx);
			if (iIdx >= sti(pchar.CampfireTales.Target))
			{
				SetCameraDialogMode(NPChar);
				dialog.text = "Et c'est fini pour les histoires de ce soir, capitaine. Bonne nuit au coin du feu.";
				link.l1 = "Merci pour les histoires.";
				link.l1.go = "end_tales";
				break;
			}
			rT = CharacterFromID(Campfire_GetTeller(iIdx));
			if (CheckAttribute(rT, "id")) SetCameraDialogMode(rT);
			iTale = Campfire_GetTale(iIdx);
			pchar.CampfireTales.Idx = iIdx + 1;
			if      (iIdx == 0) dialog.text = "Eh bien, capitaine, écoutez ça : voilà ce qui m'est arrivé une fois...";
			else if (iIdx == 1) dialog.text = "א mon tour, maintenant. Un jour...";
			else if (iIdx == 2) dialog.text = "Et voici ce que j'ai vu une fois, capitaine...";
			else                dialog.text = "Et la mienne pour finir. וcoutez...";
			sNum = "" + iTale;
			link.l1 = "(וcouter)";
			link.l1.go = "S" + sNum + "_1";
		break;

		// ===================== YARNS (one teller's monologue, camera set in tale_next) =====================
		// --- S1 ---
		case "S1_1":
			dialog.text = "Une fois, au large de la Guadeloupe, j'ai cru avoir ferré une baleine. La ligne a failli m'arracher les bras : on a halé la moitié de la nuit, tout le quart s'y est mis.";
			link.l1 = "...";
			link.l1.go = "S1_2";
		break;
		case "S1_2":
			dialog.text = "Et qu'est-ce qui remonte ? Une vieille ancre, prise dans le filet déchiré de quelqu'un. Mais dans ce filet se débattait un poisson long comme mon bras : le cuistot en a nourri tout l'équipage pendant une semaine.";
			link.l1 = "...";
			link.l1.go = "S1_3";
		break;
		case "S1_3":
			dialog.text = "Remarquez, j'ai sauté par-dessus bord moi-même dès que l'ancre s'est montrée. Mais c'est moi qui l'ai serrée dans mes bras le premier. Ha ha !";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S2 ---
		case "S2_1":
			dialog.text = "On avait un maître d'équipage, Magnus le Tordu, paix à son âme. Il sifflait si fort que les mouettes tombaient du ciel, raides mortes.";
			link.l1 = "...";
			link.l1.go = "S2_2";
		break;
		case "S2_2":
			dialog.text = "Une fois, en plein calme plat, il a sifflé le branle-bas : l'équipage a déboulé sur le pont, pas un souffle de vent, les voiles pendaient comme des chiffons. Il a gueulé contre le ciel une heure entière, comme si le ciel lui devait de l'argent.";
			link.l1 = "...";
			link.l1.go = "S2_3";
		break;
		case "S2_3":
			dialog.text = "Et au matin, ça soufflait ! Il bluffait, bien sמr : il lisait simplement le baromètre mieux que bien des capitaines. N'empêche, avec lui à bord, jamais un quart n'a manqué l'appel.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S3 ---
		case "S3_1":
			dialog.text = "Ce trésor sur la petite île sans nom... Je n'arrive toujours pas à croire qu'on l'ait trouvé.";
			link.l1 = "...";
			link.l1.go = "S3_2";
		break;
		case "S3_2":
			dialog.text = "La carte mentait à chaque pas : « vingt pas depuis le palmier », et il y avait toute une palmeraie. On a creusé trois jours ; je croyais que le capitaine avait perdu la raison.";
			link.l1 = "...";
			link.l1.go = "S3_3";
		break;
		case "S3_3":
			dialog.text = "Et le quatrième jour, un coffre : des doublons, des perles et une croix d'or pur. On en a flambé la moitié dans le premier port, imbéciles que nous étions. N'empêche, ça fait de quoi se souvenir au coin du feu.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S4 ---
		case "S4_1":
			dialog.text = "Sur le continent, un vieil Indien m'a parlé de Mictlantecuhtli, le seigneur des morts, celui à qui l'on portait de l'or dans les temples.";
			link.l1 = "...";
			link.l1.go = "S4_2";
		break;
		case "S4_2":
			dialog.text = "Il jurait que celui qui prend l'or du temple, le dieu le marque : une ombre dans son dos, des murmures dans la nuit. J'ai vu de mes yeux un homme sortir une idole de la jungle : en un mois, il a blanchi et disparu sans laisser de trace.";
			link.l1 = "...";
			link.l1.go = "S4_3";
		break;
		case "S4_3":
			dialog.text = "Leurs dieux sont cruels et affamés, pas comme le nכtre. C'est pour ça que je ne mettrai jamais les pieds dans ces temples : que l'or reste oם il est.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S5 ---
		case "S5_1":
			dialog.text = "Il y avait un galion espagnol au large de Campeche. On s'est accolés bord contre bord, la fumée faisait comme un mur.";
			link.l1 = "...";
			link.l1.go = "S5_2";
		break;
		case "S5_2":
			dialog.text = "J'ai sauté de l'autre cכté le premier, et j'ai aussitכt glissé sur le sang de quelqu'un : j'ai traversé la moitié du pont sur le dos. Les Espagnols étaient si sidérés que la moitié a pris la fuite : ils m'ont pris pour un berserker.";
			link.l1 = "...";
			link.l1.go = "S5_3";
		break;
		case "S5_3":
			dialog.text = "Un berserker ! Je n'arrivais tout simplement pas à me relever. Mais j'y ai gagné un surnom pour des années : depuis, on m'appelle l'Anguille. Et grand bien leur fasse, tant que la part est honnête.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S6 ---
		case "S6_1":
			dialog.text = "Et sur cette île oם on faisait de l'eau, des hommes d'os sont sortis du sable au lever de la lune. Avec des coutelas, dans des uniformes pourris.";
			link.l1 = "...";
			link.l1.go = "S6_2";
		break;
		case "S6_2":
			dialog.text = "J'ai mis ça sur le compte du rhum, jusqu'à ce que l'un d'eux me lance un coup de lame à une longueur de bras. Tu en abats un, il tombe en poussière, et au matin, il se dresse de nouveau, entier, dans le ressac.";
			link.l1 = "...";
			link.l1.go = "S6_3";
		break;
		case "S6_3":
			dialog.text = "Le capitaine nous a ordonné de partir avant la tombée de la nuit. Personne n'y est retourné une seconde fois. Paix aux morts, et les vivants feraient mieux de s'en tenir loin.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S7 ---
		case "S7_1":
			dialog.text = "א la Dominique, chaque saison, des lames venues de toutes les mers se rassemblent : un tournoi d'escrimeurs. Les prix sont si riches que certains n'en pillent pas autant en un an.";
			link.l1 = "...";
			link.l1.go = "S7_2";
		break;
		case "S7_2":
			dialog.text = "J'en ai vu un, là-bas, éteindre une bougie avec sa rapière sans toucher la mèche, trois fois de suite. Et les perdants ? Du sang sur le sable, le chirurgien n'arrive pas à les panser assez vite.";
			link.l1 = "...";
			link.l1.go = "S7_3";
		break;
		case "S7_3":
			dialog.text = "Les malins parient sur les lames des autres et s'enrichissent sans une égratignure. דa, c'est pour moi : un sage se bat avec sa bourse.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S8 ---
		case "S8_1":
			dialog.text = "L'homme le plus malin que la mer ait jamais porté, c'était le capitaine James Flint. On avait peur de prononcer son nom à voix haute.";
			link.l1 = "...";
			link.l1.go = "S8_2";
		break;
		case "S8_2":
			dialog.text = "Il jouait avec les grandes puissances comme nous jouons aux dés : il dressait les gouverneurs les uns contre les autres, menait des flottes entières par le bout du nez. Et son trésor n'a jamais été retrouvé à ce jour : il a si bien caché la carte que le mort se moque de nous tous.";
			link.l1 = "...";
			link.l1.go = "S8_3";
		break;
		case "S8_3":
			dialog.text = "Diablement malin, et seul à cause de ça : un grand esprit est un lourd fardeau. C'est pour ça que nous, on boit plus simplement : moins d'esprit, meilleur sommeil.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S9 ---
		case "S9_1":
			dialog.text = "Au large de Tortuga, un requin-marteau a filé avec notre nasse appâtée, tonnelet compris ! On l'a poursuivi une demi-journée dans le youyou.";
			link.l1 = "...";
			link.l1.go = "S9_2";
		break;
		case "S9_2":
			dialog.text = "On l'a rattrapé, et il était déjà mort, empêtré dans sa propre queue. Le cuistot a dit que la viande était coriace, tout juste bonne pour des semelles.";
			link.l1 = "...";
			link.l1.go = "S9_3";
		break;
		case "S9_3":
			dialog.text = "Alors on en a fait des semelles. J'ai marché deux ans avec ces bottes, et les coquines n'ont jamais laissé passer une goutte d'eau.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S10 ---
		case "S10_1":
			dialog.text = "Une fois, la mer s'est mise à briller le long du bord, comme si des étoiles étaient tombées à l'eau.";
			link.l1 = "...";
			link.l1.go = "S10_2";
		break;
		case "S10_2":
			dialog.text = "J'ai cru que les âmes des noyés étaient remontées pour faire leurs adieux, j'ai marmonné des prières pendant tout le quart. Et ce n'était que du plancton, des petites bestioles qui luisaient.";
			link.l1 = "...";
			link.l1.go = "S10_3";
		break;
		case "S10_3":
			dialog.text = "Qui l'eמt cru. Mais c'était beau, je ne vais pas mentir : je n'ai jamais revu une chose pareille nulle part.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S11 ---
		case "S11_1":
			dialog.text = "Une fois, des poissons volants ont atterri en plein sur le pont, une douzaine d'un coup : le souper a sauté tout seul dans la marmite, le cuistot en a presque pleuré de joie.";
			link.l1 = "...";
			link.l1.go = "S11_2";
		break;
		case "S11_2":
			dialog.text = "L'un d'eux m'a frappé en plein front, je suis tombé du banc cul par-dessus tête. Mais après, je l'ai mangé avec un plaisir particulier, par dépit.";
			link.l1 = "...";
			link.l1.go = "S11_3";
		break;
		case "S11_3":
			dialog.text = "La mer vous nourrit d'elle-même, parfois, si vous vivez selon votre conscience. Ou si vous ouvrez simplement le bec assez grand.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S12 ---
		case "S12_1":
			dialog.text = "On avait un cuistot qui faisait de la soupe avec tout ce qui remuait. Un jour, un rat est tombé dans la marmite : il n'a même pas cillé.";
			link.l1 = "...";
			link.l1.go = "S12_2";
		break;
		case "S12_2":
			dialog.text = "« La viande, c'est de la viande », qu'il dit, et il continue à touiller. L'équipage a mangé et lui a fait des compliments, jusqu'à ce qu'il apprenne la vérité.";
			link.l1 = "...";
			link.l1.go = "S12_3";
		break;
		case "S12_3":
			dialog.text = "Et quand ils l'ont apprise, ils ont failli le mettre lui-même dans la marmite. Il a filé au premier port : il avait le pied leste, le coquin.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S13 ---
		case "S13_1":
			dialog.text = "On avait un mousse, Pierrot, qui avait peur de tout : de la mer, du capitaine. Et pourtant, dans la tempête, c'est lui qui a grimpé le premier au mât, quand les vieux loups flanchaient.";
			link.l1 = "...";
			link.l1.go = "S13_2";
		break;
		case "S13_2":
			dialog.text = "Il a serré la voile, il est redescendu blanc comme un linge, et il est tombé dans les pommes. Le capitaine lui a donné sa propre ration de rhum, devant tout le monde.";
			link.l1 = "...";
			link.l1.go = "S13_3";
		break;
		case "S13_3":
			dialog.text = "א partir de ce jour, Pierrot a été un autre garçon, il est devenu un bon marin. La peur n'est pas un vice : le vice, c'est de s'y abandonner.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S14 ---
		case "S14_1":
			dialog.text = "Notre second trafiquait les cartes mieux que le navigateur ne traçait une route : il a plumé tout l'équipage jusqu'au caleçon.";
			link.l1 = "...";
			link.l1.go = "S14_2";
		break;
		case "S14_2":
			dialog.text = "Un jour, il en a trop fait : il a perdu son propre coffre au profit du capitaine. Et dans le coffre, la part du capitaine en personne, qu'il lui avait chipée !";
			link.l1 = "...";
			link.l1.go = "S14_3";
		break;
		case "S14_3":
			dialog.text = "Quelle rigolade : le capitaine a ri à s'en tenir les cכtes. Et il lui a pardonné : il a dit qu'un tel culot valait bien ça.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S15 ---
		case "S15_1":
			dialog.text = "Une fois, on a acheté une carte à un ivrogne dans une taverne, pour une bouteille : on croyait avoir roulé l'imbécile. Et la carte s'est révélée vraie.";
			link.l1 = "...";
			link.l1.go = "S15_2";
		break;
		case "S15_2":
			dialog.text = "Elle menait à une grotte, et là-dedans, des tonneaux, tous vides. Tous sauf un : il y avait dedans de quoi vivre trois vies.";
			link.l1 = "...";
			link.l1.go = "S15_3";
		break;
		case "S15_3":
			dialog.text = "Cet ivrogne n'a sans doute jamais su ce qu'il avait vendu. Ou bien il le savait, et il pensait qu'on n'y arriverait jamais.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S16 ---
		case "S16_1":
			dialog.text = "Le capitaine sentait l'or comme un chien de chasse sent le gibier. Il a trouvé une cache sous une vieille dalle, là oם tout le monde était passé sans rien voir.";
			link.l1 = "...";
			link.l1.go = "S16_2";
		break;
		case "S16_2":
			dialog.text = "Il a dit que la pierre n'était pas posée comme il faut, qu'une autre main l'avait mise là. On aurait piétiné là une éternité, et lui, un geste, et il l'a fendue.";
			link.l1 = "...";
			link.l1.go = "S16_3";
		break;
		case "S16_3":
			dialog.text = "Un flair pareil, c'est un don : celui qui l'a a la richesse. Et celui qui ne l'a pas marche sur ses talons pour une part.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S17 ---
		case "S17_1":
			dialog.text = "Un coffre, on l'a sorti de la vase en trois jours, juste au bord du récif. Il est remonté : pas d'or, mais les os de quelqu'un, dans des fers.";
			link.l1 = "...";
			link.l1.go = "S17_2";
		break;
		case "S17_2":
			dialog.text = "Un esclave, sans doute, jeté par-dessus bord avec la cargaison pour éviter un partage. Le capitaine nous a ordonné de mettre les os en terre, comme il faut.";
			link.l1 = "...";
			link.l1.go = "S17_3";
		break;
		case "S17_3":
			dialog.text = "Et le lendemain matin, sous ce même endroit, on a trouvé un autre coffre, plein de pièces. Les morts paient les vivants pour leur bonté, de temps en temps.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S18 ---
		case "S18_1":
			dialog.text = "Dans le sud, on a vu un temple tout sculpté : des serpents et des crânes. Quetzalcóatl, le serpent à plumes : les prêtres lui offraient des cœurs.";
			link.l1 = "...";
			link.l1.go = "S18_2";
		break;
		case "S18_2":
			dialog.text = "La pierre de la cour était sombre, comme imbibée de sang. Je ne m'en suis jamais approché : je sentais que c'était un mauvais endroit.";
			link.l1 = "...";
			link.l1.go = "S18_3";
		break;
		case "S18_3":
			dialog.text = "Et l'un des nכtres a craché sur l'autel, il a bien rigolé. Une semaine plus tard, il s'est noyé par calme plat. Par calme plat, vous entendez ?";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S19 ---
		case "S19_1":
			dialog.text = "Un chaman du village m'a lu l'avenir dans les braises du feu. Il a dit que je ne mourrais ni par la lame ni par la balle.";
			link.l1 = "...";
			link.l1.go = "S19_2";
		break;
		case "S19_2":
			dialog.text = "J'étais content : je me suis dit, dans mon lit, alors. Et puis il a ajouté : par l'eau.";
			link.l1 = "...";
			link.l1.go = "S19_3";
		break;
		case "S19_3":
			dialog.text = "Depuis, je n'aime pas nager. Un marin qui a peur de l'eau : les dieux savent plaisanter.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S20 ---
		case "S20_1":
			dialog.text = "Une idole de jade, qu'on avait prise dans une cité en ruine : verte, des yeux de pierre, lourde comme un péché.";
			link.l1 = "...";
			link.l1.go = "S20_2";
		break;
		case "S20_2":
			dialog.text = "Pendant tout le trajet jusqu'au navire, il a plu, alors que le ciel était dégagé. Le capitaine n'a eu qu'à y jeter un coup d'œil : il nous a ordonné de la remettre en place.";
			link.l1 = "...";
			link.l1.go = "S20_3";
		break;
		case "S20_3":
			dialog.text = "On l'a fait, et la pluie s'est arrêtée d'un coup, vous le croyez ? Il y a de l'or qui coמte plus cher que ce qu'il rapporte.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S21 ---
		case "S21_1":
			dialog.text = "On a pris le brick d'un négrier, tous noirs de fureur. J'ai été le premier à descendre dans la cale, pour couper les chaînes, libérer les esclaves.";
			link.l1 = "...";
			link.l1.go = "S21_2";
		break;
		case "S21_2":
			dialog.text = "Et ils nous ont pris pour leurs nouveaux maîtres, ils se sont jetés sur nous à coups de poing. דa a été dur de leur faire comprendre : amis, liberté.";
			link.l1 = "...";
			link.l1.go = "S21_3";
		break;
		case "S21_3":
			dialog.text = "La moitié d'entre eux ont rejoint notre équipage, ensuite. Les meilleurs combattants : ils défendaient leur liberté bec et ongles.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S22 ---
		case "S22_1":
			dialog.text = "Un marchand a amené ses couleurs sans combattre, dès qu'il a aperçu le pavillon. Et dans la cale : poivre, clous de girofle, soie. Une fortune.";
			link.l1 = "...";
			link.l1.go = "S22_2";
		break;
		case "S22_2":
			dialog.text = "Le capitaine ne l'a pas touché, il l'a même invité à souper. « Un marchand mort, qu'il dit, ne revient plus jamais. »";
			link.l1 = "...";
			link.l1.go = "S22_3";
		break;
		case "S22_3":
			dialog.text = "Et il est revenu ! Un an plus tard, il est venu nous chercher lui-même, avec une cargaison. Le pillage intelligent, c'est quand on est content de vous revoir.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S23 ---
		case "S23_1":
			dialog.text = "Une frégate nous a pourchassés pendant deux jours, impossible de la semer. Le capitaine a ordonné de jeter des tonneaux vides par-dessus bord, un par un.";
			link.l1 = "...";
			link.l1.go = "S23_2";
		break;
		case "S23_2":
			dialog.text = "Le poursuivant a cru qu'on coulait, qu'on perdait le butin, et il a ralenti. Et nous, au vent, et envolés comme de la fumée.";
			link.l1 = "...";
			link.l1.go = "S23_3";
		break;
		case "S23_3":
			dialog.text = "La ruse sauve là oם les canons ne peuvent rien. Et on économise la poudre : la poudre, ça coמte de l'argent.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S24 ---
		case "S24_1":
			dialog.text = "Sur l'Isla de Muertos, à ce qu'on dit, les morts gardent un trésor : celui qui prend l'or devient lui-même un mort.";
			link.l1 = "...";
			link.l1.go = "S24_2";
		break;
		case "S24_2":
			dialog.text = "Un gaillard audacieux a emporté une pièce. Il est revenu, et il n'avait plus d'ombre, et plus rien dans le miroir. Vivant, et pourtant comme s'il ne l'était pas.";
			link.l1 = "...";
			link.l1.go = "S24_3";
		break;
		case "S24_3":
			dialog.text = "Il a porté cette pièce jusqu'à ce qu'il la remette en place. Il l'a remise, et son ombre est revenue. Plus jamais il n'a rien pris.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S25 ---
		case "S25_1":
			dialog.text = "Un vaisseau fantכme, on l'a vu dans le brouillard au large du cap : voiles en lambeaux, pas une âme sur le pont, et il naviguait contre le vent.";
			link.l1 = "...";
			link.l1.go = "S25_2";
		break;
		case "S25_2":
			dialog.text = "On l'a hélé : silence. Il nous a traversés comme de la fumée. Le capitaine nous a interdit d'en parler avant d'avoir touché terre.";
			link.l1 = "...";
			link.l1.go = "S25_3";
		break;
		case "S25_3":
			dialog.text = "Il a dit que celui qui jacasse sur une chose pareille, elle vient le prendre. Alors on chuchote : il ne faut pas parler fort des morts.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S26 ---
		case "S26_1":
			dialog.text = "Une fois, à Tortuga, on a pendu un pirate devant tout le monde. Et avant la corde, il a juré qu'il reviendrait.";
			link.l1 = "...";
			link.l1.go = "S26_2";
		break;
		case "S26_2":
			dialog.text = "Un an plus tard, on l'a vu dans cette même taverne, à cette même table. Je lui ai servi le rhum moi-même, et sa main était froide comme le fer en décembre.";
			link.l1 = "...";
			link.l1.go = "S26_3";
		break;
		case "S26_3":
			dialog.text = "Il a bu, il a hoché la tête, et il est parti. On ne l'a plus jamais revu.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S27 ---
		case "S27_1":
			dialog.text = "א la Dominique, un Espagnol se battait si vite qu'on ne voyait pas sa lame. On disait qu'il avait appris auprès du maître de Tolède en personne.";
			link.l1 = "...";
			link.l1.go = "S27_2";
		break;
		case "S27_2":
			dialog.text = "Contre lui est allé notre maître d'équipage, soמl comme un lord. Et il l'a touché ! Le diable lui-même protège les ivrognes.";
			link.l1 = "...";
			link.l1.go = "S27_3";
		break;
		case "S27_3":
			dialog.text = "L'Espagnol a été si vexé qu'il a quitté le tournoi et mis les voiles. Et le maître d'équipage, le lendemain matin, ne se rappelait plus comment il avait gagné.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S28 ---
		case "S28_1":
			dialog.text = "J'ai vu une femme avec une lame, au tournoi : elle se battait comme une furie, en a mis trois à terre d'affilée sans même reprendre son souffle.";
			link.l1 = "...";
			link.l1.go = "S28_2";
		break;
		case "S28_2":
			dialog.text = "Après ça, les hommes refusaient de l'affronter : honte de perdre. Et elle, elle se contentait de sourire en affמtant son sabre.";
			link.l1 = "...";
			link.l1.go = "S28_3";
		break;
		case "S28_3":
			dialog.text = "On dit qu'elle prenait un baiser à chaque homme vaincu. Voilà un prix pour lequel je m'avancerais moi-même, hein.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S29 ---
		case "S29_1":
			dialog.text = "Un freluquet s'est présenté au tournoi, en dentelles, avec un mouchoir parfumé. Tout le monde s'est moqué de lui, jusqu'à ce qu'il dégaine sa rapière.";
			link.l1 = "...";
			link.l1.go = "S29_2";
		break;
		case "S29_2":
			dialog.text = "Six combattants, et pas une égratignure sur ses dentelles. Il s'est tamponné le front avec son mouchoir et il a salué, comme au théâtre.";
			link.l1 = "...";
			link.l1.go = "S29_3";
		break;
		case "S29_3":
			dialog.text = "Voilà pour le freluquet : ne juge pas l'oiseau à son plumage. Depuis, je ne me moque plus des dandys, on ne sait jamais.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S30 ---
		case "S30_1":
			dialog.text = "On dit que Flint avait un quartier-maître : une seule jambe, et un perroquet. Silver, je crois, plus rusé que Flint lui-même.";
			link.l1 = "...";
			link.l1.go = "S30_2";
		break;
		case "S30_2":
			dialog.text = "Il a si bien caché son argent qu'il n'a pas pu le retrouver ensuite. Mais il s'en est tiré vivant : et combien se sont tirés vivants des griffes de Flint ?";
			link.l1 = "...";
			link.l1.go = "S30_3";
		break;
		case "S30_3":
			dialog.text = "Lui seul, sans doute. Les malins vivent longtemps. Ou ceux qui comprennent à temps quand il faut filer.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S31 ---
		case "S31_1":
			dialog.text = "Barbe Noire tressait des mèches dans sa barbe et les allumait pendant le combat : fumée, étincelles, le diable en personne qui sort de l'enfer.";
			link.l1 = "...";
			link.l1.go = "S31_2";
		break;
		case "S31_2":
			dialog.text = "Ses ennemis jetaient les armes avant même l'abordage. La moitié de ses victoires, il les a remportées rien que par son allure.";
			link.l1 = "...";
			link.l1.go = "S31_3";
		break;
		case "S31_3":
			dialog.text = "א la fin, on lui a tranché la tête : il se battait encore avec neuf blessures. La peur est une arme, mais contre la peur aussi, il y a du plomb.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S32 ---
		case "S32_1":
			dialog.text = "Bartholomew Roberts buvait de l'eau, pas du rhum. Un drכle de type, hein ? Mais il a pris quatre cents navires : sobre, c'est plus commode.";
			link.l1 = "...";
			link.l1.go = "S32_2";
		break;
		case "S32_2":
			dialog.text = "Habillé comme un lord : un habit cramoisi, une plume au chapeau. Il est mort habillé comme ça, d'ailleurs, sur le pont, d'une charge de mitraille.";
			link.l1 = "...";
			link.l1.go = "S32_3";
		break;
		case "S32_3":
			dialog.text = "Il a vécu en beauté, et il est tombé en beauté. Mieux vaut ça que pourrir enchaîné au gibet.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S33 ---
		case "S33_1":
			dialog.text = "Une fois, une pieuvre s'est agrippée à notre gouvernail, tout au fond : un monstre, avec un bras aussi épais que la grand-vergue.";
			link.l1 = "...";
			link.l1.go = "S33_2";
		break;
		case "S33_2":
			dialog.text = "Notre plongeur est descendu, et il est remonté comme une flèche, sans son couteau. Il a laissé la lame à la pieuvre en souvenir, ha !";
			link.l1 = "...";
			link.l1.go = "S33_3";
		break;
		case "S33_3":
			dialog.text = "Elle a lâché prise toute seule quand la nuit est tombée : elles n'aiment pas le bruit. Et le gouvernail a pué l'encre pendant une semaine.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S34 ---
		case "S34_1":
			dialog.text = "On avait un navigateur qui lisait les étoiles comme un livre. Avec l'âge, il est devenu aveugle : alors il naviguait de mémoire.";
			link.l1 = "...";
			link.l1.go = "S34_2";
		break;
		case "S34_2":
			dialog.text = "Et il ne s'est jamais trompé, tant qu'il voyait encore une étincelle dans le ciel. Et quand il est devenu complètement aveugle, il est descendu à terre, en pleurant.";
			link.l1 = "...";
			link.l1.go = "S34_3";
		break;
		case "S34_3":
			dialog.text = "On ne traverse pas la mer sans yeux, même avec une telle mémoire. Il est mort gardien de phare : de la lumière, au moins, et près de la mer.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S35 ---
		case "S35_1":
			dialog.text = "Notre capitaine détestait les mouettes plus que la tempête. Une fois, l'une d'elles lui a arraché son chapeau de la tête, devant tout le monde.";
			link.l1 = "...";
			link.l1.go = "S35_2";
		break;
		case "S35_2":
			dialog.text = "Il l'a pourchassée sur toute la longueur du pont, sabre au clair : l'équipage dégringolait des haubans à force de rire.";
			link.l1 = "...";
			link.l1.go = "S35_3";
		break;
		case "S35_3":
			dialog.text = "La mouette a lâché le chapeau dans la mer, vexée. Et le capitaine est resté tête nue ensuite, par principe.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S36 ---
		case "S36_1":
			dialog.text = "On a enterré notre part sur un îlot, on a gravé une croix. On est revenus un an plus tard, et l'îlot était sous l'eau !";
			link.l1 = "...";
			link.l1.go = "S36_2";
		break;
		case "S36_2":
			dialog.text = "La marée, un haut-fond... On est restés plantés comme des idiots au-dessus des vagues. Le capitaine a dit que la mer avait pris sa part.";
			link.l1 = "...";
			link.l1.go = "S36_3";
		break;
		case "S36_3":
			dialog.text = "Depuis, on ne cache les trésors qu'au sec et en hauteur. Et on met une croix : la mer respecte les croix, jusqu'ici.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S37 ---
		case "S37_1":
			dialog.text = "Un vieil homme sur son lit de mort m'a glissé une carte dans la main. Je l'ai suivie jusqu'à un puits vide et un billet : « la richesse, c'est la vie ».";
			link.l1 = "...";
			link.l1.go = "S37_2";
		break;
		case "S37_2":
			dialog.text = "Quel vieux filou : il est mort avec le sourire, je parie. Et je porte ce billet sur moi jusqu'à ce jour.";
			link.l1 = "...";
			link.l1.go = "S37_3";
		break;
		case "S37_3":
			dialog.text = "Peut-être que ce n'était pas un idiot. Peut-être que les idiots, c'est nous, à courir après l'or toute notre vie.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S38 ---
		case "S38_1":
			dialog.text = "Dans la jungle se dressait une idole, tournée vers le soleil levant, toute couverte de mousse. Les gens du coin lui apportaient du maïs et des fleurs une fois par an.";
			link.l1 = "...";
			link.l1.go = "S38_2";
		break;
		case "S38_2":
			dialog.text = "Ils disaient qu'elle dort, et qu'il ne faut surtout pas la réveiller. Et ce qui se passe si on la réveille, ils ne le savent pas eux-mêmes.";
			link.l1 = "...";
			link.l1.go = "S38_3";
		break;
		case "S38_3":
			dialog.text = "Bizarrement, il ne s'est trouvé aucun volontaire pour le découvrir. Et c'est bien : mieux vaut ne pas toucher aux dieux endormis.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S39 ---
		case "S39_1":
			dialog.text = "On a pris une goélette chargée de barils de poudre à ras bord. Une étincelle, et on montait tous au ciel d'un coup.";
			link.l1 = "...";
			link.l1.go = "S39_2";
		break;
		case "S39_2":
			dialog.text = "On se battait sur la pointe des pieds, on jurait presque à voix basse. Une vraie rigolade : un abordage plus silencieux qu'une messe.";
			link.l1 = "...";
			link.l1.go = "S39_3";
		break;
		case "S39_3":
			dialog.text = "Mais on l'a prise proprement, sans un coup de feu. Le silence est pire que les canons, parfois.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S40 ---
		case "S40_1":
			dialog.text = "Le capitaine ennemi s'est révélé être un vieux débiteur à nous : celui qui avait perdu son navire aux dés contre le nכtre, autrefois.";
			link.l1 = "...";
			link.l1.go = "S40_2";
		break;
		case "S40_2":
			dialog.text = "Il est devenu blanc comme un linceul en nous voyant. Et le nכtre n'a pris que la dette : la dette et les intérêts.";
			link.l1 = "...";
			link.l1.go = "S40_3";
		break;
		case "S40_3":
			dialog.text = "L'honneur, qu'il dit, vaut plus que le butin. C'est pour ça qu'on le suivrait dans le feu : pour l'honneur.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S41 ---
		case "S41_1":
			dialog.text = "Au cimetière près du fort, à ce qu'on dit, des lumières se promènent la nuit : les âmes de ceux qu'on a enterrés sans les rites.";
			link.l1 = "...";
			link.l1.go = "S41_2";
		break;
		case "S41_2":
			dialog.text = "Une fois, j'y ai dormi, comme un idiot, sur un pari. Une petite flamme s'est approchée, est restée un moment près de moi, et s'est éteinte doucement.";
			link.l1 = "...";
			link.l1.go = "S41_3";
		break;
		case "S41_3":
			dialog.text = "Je n'ai pas blanchi, comme vous voyez. Peut-être qu'elle voulait dire adieu : elles aussi se sentent seules.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S42 ---
		case "S42_1":
			dialog.text = "Un vieil homme s'est présenté au tournoi, soixante-dix ans bien sonnés. Tout le monde a cru à une blague, et il a mis à terre trois jeunes coqs.";
			link.l1 = "...";
			link.l1.go = "S42_2";
		break;
		case "S42_2":
			dialog.text = "Pas par la force, par la ruse : là oם il se tient, là va la lame. La jeunesse frappe, la vieillesse vise.";
			link.l1 = "...";
			link.l1.go = "S42_3";
		break;
		case "S42_3":
			dialog.text = "Il a pris le prix, il a salué, et il est parti sans un mot. Si seulement je pouvais en faire autant : tenir une lame jusqu'à mes cheveux blancs.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S43 ---
		case "S43_1":
			dialog.text = "On dit que Flint, à l'article de la mort, n'arrêtait pas de crier à propos d'un chien noir : il délirait, sans doute. Ou bien sa conscience l'a rattrapé à la dernière heure.";
			link.l1 = "...";
			link.l1.go = "S43_2";
		break;
		case "S43_2":
			dialog.text = "Il en a emmené six avec lui dans la tombe, ceux qui avaient caché le trésor, pour qu'ils ne jacassent pas. Les morts savent mieux se taire que les vivants.";
			link.l1 = "...";
			link.l1.go = "S43_3";
		break;
		case "S43_3":
			dialog.text = "C'est pour ça que personne n'a trouvé sa carte jusqu'à ce jour. Et personne ne la trouvera : Flint a laissé des morts en sentinelles.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S44 ---
		case "S44_1":
			dialog.text = "Mary Read s'habillait en homme, jusqu'à devenir capitaine. Elle se battait mieux que bien des hommes, à ce qu'on m'a dit.";
			link.l1 = "...";
			link.l1.go = "S44_2";
		break;
		case "S44_2":
			dialog.text = "Elle est allée au combat enceinte, et n'a demandé aucune grâce. Elle est morte en prison, sans que l'enfant soit jamais né.";
			link.l1 = "...";
			link.l1.go = "S44_3";
		break;
		case "S44_3":
			dialog.text = "Elle a vécu libre : ça n'est pas donné à tout le monde. Et la liberté, c'est ce qui coמte le plus cher.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S45 ---
		case "S45_1":
			dialog.text = "Une fois, une baleine a fait surface sous notre bord, grosse comme un bel îlot. Le navire a roulé : la moitié de l'équipage a failli passer par-dessus bord.";
			link.l1 = "...";
			link.l1.go = "S45_2";
		break;
		case "S45_2":
			dialog.text = "Elle nous a regardés d'un œil, sage comme celui d'un homme, et elle est redescendue dans les profondeurs sans nous toucher.";
			link.l1 = "...";
			link.l1.go = "S45_3";
		break;
		case "S45_3":
			dialog.text = "Le capitaine a dit qu'elle avait béni le navire. Et c'est vrai que pendant tout le voyage, on a eu de la chance. Allez comprendre.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S46 ---
		case "S46_1":
			dialog.text = "Notre perroquet jurait plus salement que le maître d'équipage : il appelait le capitaine par son nom et ajoutait un petit mot.";
			link.l1 = "...";
			link.l1.go = "S46_2";
		break;
		case "S46_2":
			dialog.text = "Un invité de marque a failli tomber de son tabouret, et le capitaine a rugi de rire : on ne rééduque pas un oiseau, qu'il a dit.";
			link.l1 = "...";
			link.l1.go = "S46_3";
		break;
		case "S46_3":
			dialog.text = "Quand le perroquet est mort, tout l'équipage l'a veillé. On pleure parfois un oiseau plus qu'un homme.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S47 ---
		case "S47_1":
			dialog.text = "Une fois, on a acheté des perles aux plongeurs, pour une bouchée de pain. Et dans une coquille, une perle grosse comme un œuf de pigeon.";
			link.l1 = "...";
			link.l1.go = "S47_2";
		break;
		case "S47_2":
			dialog.text = "On l'a vendue à un grand d'Espagne pour une vraie fortune : avec cet argent, la moitié de l'équipage s'est acheté une maison.";
			link.l1 = "...";
			link.l1.go = "S47_3";
		break;
		case "S47_3":
			dialog.text = "Et les plongeurs sont restés dans la misère, comme avant. La chance est aveugle : à l'un la coquille, à l'autre l'œuf qu'elle contient.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S48 ---
		case "S48_1":
			dialog.text = "Sur une île fumait un volcan, et les gens du coin lui faisaient des offrandes : ils jetaient de l'or dans le cratère pour que la montagne ne se mette pas en colère.";
			link.l1 = "...";
			link.l1.go = "S48_2";
		break;
		case "S48_2":
			dialog.text = "L'un des nכtres est allé de nuit récupérer cet or. La montagne s'est réveillée la nuit même : on a eu du mal à s'en tirer.";
			link.l1 = "...";
			link.l1.go = "S48_3";
		break;
		case "S48_3":
			dialog.text = "Alors il ne s'est pas enrichi avec. Les dieux n'aiment pas qu'on reprenne ce qui leur appartient.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S49 ---
		case "S49_1":
			dialog.text = "Une fois, on a pris un navire, et son capitaine n'était qu'un gamin : le père était mort, le fils avait pris la barre, mais il n'y arrivait pas.";
			link.l1 = "...";
			link.l1.go = "S49_2";
		break;
		case "S49_2":
			dialog.text = "Notre capitaine ne l'a pas touché, il lui a appris à tenir son cap et l'a laissé partir avec sa cargaison : il a dit, laissez-le grandir.";
			link.l1 = "...";
			link.l1.go = "S49_3";
		break;
		case "S49_3":
			dialog.text = "Des années plus tard, ce gamin nous a sauvé la vie, dans une tempête. Le bien fait le tour de la mer en cercles, comme une vague.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;
		// --- S50 ---
		case "S50_1":
			dialog.text = "On dit que le trésor de Flint se trouve sur une île qui dérive dans le brouillard. Celui qui met le cap dessus, le brouillard le fait tourner en rond et le ramène en pleine mer.";
			link.l1 = "...";
			link.l1.go = "S50_2";
		break;
		case "S50_2":
			dialog.text = "Beaucoup ont aperçu l'île. Y ont mis le pied : personne. Peut-être que cette île n'existe pas du tout, peut-être que ce n'est qu'un conte.";
			link.l1 = "...";
			link.l1.go = "S50_3";
		break;
		case "S50_3":
			dialog.text = "Ou peut-être que Flint l'a voulu ainsi : qu'on cherche éternellement. La meilleure garde pour un trésor, c'est la cupidité humaine et le brouillard.";
			link.l1 = "(Hocher la tête)";
			link.l1.go = "tale_next";
		break;

		case "end_tales":
			NextDiag.CurrentNode = "first time";
			AddDialogExitQuestFunction("Campfire_End");
			DialogExit();
		break;
	}
}
