void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if(NPChar.id == "Andre_Abel_Quest_Officer_1") // Офицер в резиденции Кюрасао. Сопровождение флейта "Orion"
			{
				dialog.text = LinkRandPhrase("Soyez poli avec monsieur le gouverneur général.", "Ne vous avisez pas de me déranger !", "Gardez à l'esprit que le gouverneur général a très peu de temps !");
				link.l1 = "Oui, je sais, je sais...";
				link.l1.go = "exit";
			}

			if(NPChar.id == "Martin_Bleker")	// Мартин Блэкер
			{
				dialog.text = GetSexPhrase("Alors, voilà à quoi ressemble le « messager de Morgan »...","Ah... Alors c'est toi qu'ils ont amenée...") + " Eh bien, bienvenue dans nos appartements.";
				link.l2 = "Les nouvelles vont vite, chez vous... Merci pour l'hospitalité, mais je ne suis pas là pour longtemps.";
				link.l2.go = "Andre_Abel_Quest_In_Prison_1";
			}
			break;

		// Мартин Блэкер. Квест "Accompaniment of the Orion fluyt" -->
		case "Andre_Abel_Quest_In_Prison_Wrong_Way_1":
			dialog.text = "Tu ne devrais pas dire ça... Mais c'est ton droit... Demain après-midi, nos corps sans vie feront rire le public...";
			link.l1 = "Je sortirai bientכt d'ici... Tu verras...";
			link.l1.go = "Andre_Abel_Quest_In_Prison_Wrong_Way_2";
			link.l2 = "Oui... Si c'est comme tu le dis, il faut sortir d'ici au plus vite...";
			link.l2.go = "Andre_Abel_Quest_In_Prison_2";
			break;

		case "Andre_Abel_Quest_In_Prison_Wrong_Way_2":
			dialog.text = "Je l'espère...";
			link.l1 = "Moi aussi.";
			link.l1.go = "Andre_Abel_Quest_In_Prison_Wrong_Way_3";
			break;

		case "Andre_Abel_Quest_In_Prison_Wrong_Way_3":
			DialogExit();
			SetLaunchFrameFormParam("Deux jours ont passé...", "", 5, 3);
			LaunchFrameForm();
			break;

		case "Andre_Abel_Quest_In_Prison_1":
			dialog.text = "C'est vrai, pas pour longtemps... J'ai entendu les gardes parler, c'est d'ailleurs par eux que j'ai entendu parler du « messager »... Ils disaient qu'on te pendrait demain.";
			link.l1 = "Diable !.. Ton Stuyvesant est bien prompt. Il ne m'a laissé aucun temps pour réfléchir...";
			link.l1.go = "Andre_Abel_Quest_In_Prison_2";
			break;

		case "Andre_Abel_Quest_In_Prison_2":
			dialog.text = "א quoi bon réfléchir ? S'ils vont te pendre demain, il faut s'enfuir aujourd'hui.";
			link.l1 = "Oh ! Tu serais de sa famille, par hasard ? Lui aussi, il prend vite ses décisions.";
			link.l1.go = "Andre_Abel_Quest_In_Prison_3";
			break;

		case "Andre_Abel_Quest_In_Prison_3":
			dialog.text = "Rapide, tu parles ?! דa fait un an que je suis ici, et j'ai déjà préparé des crochets et des lames. Je ne peux pas passer les gardes tout seul, alors j'attends un compagnon de route. Et toi, tu es "+ GetSexPhrase("un gars costaud","une fille qui n'a pas froid aux yeux") +", et tu sais manier l'épée, à en juger par ta façon de te tenir... Et Dieu lui-même te commande de t'enfuir. Alors, je ne trouverai pas mieux pour m'accompagner. Héhé...";
			link.l1 = "Oui, j'ai vraiment eu de la chance avec mon compagnon de cellule. Tes crochets ne vont pas te lâcher ?";
			link.l1.go = "Andre_Abel_Quest_In_Prison_4";
			break;

		case "Andre_Abel_Quest_In_Prison_4":
			dialog.text = "Tu plaisantes ? J'ouvre la porte de la cellule presque toutes les nuits, je graisse les gonds. Au début, je me promenais même dans les couloirs, mais c'est trop dangereux... Alors, ça va.";
			link.l1 = "Eh bien, si c'est comme ça, alors on y va ? Advienne que pourra !.. Au fait, comment tu t'appelles ?";
			link.l1.go = "Andre_Abel_Quest_In_Prison_5";
			break;

		case "Andre_Abel_Quest_In_Prison_5":
			dialog.text = "Quoi ? Comment je m'appelle ? Je m'appelle Martin Blacker... Allume un cierge pour le repos de mon âme si je ne sors pas d'ici vivant, sinon, ce n'est pas convenable, sans les derniers sacrements... Je vais ouvrir, tiens la lame... Enroule la poignée dans un mouchoir, tu vois bien que la lame n'a pas de poignée ?";
			link.l1 = "Euh, ce n'est pas une flamberge, bien sמr, mais on fera avec ce qu'on a... Au cas oם, je m'appelle " + GetFullName(pchar) + "... Allez, à la grâce de Dieu.";
			link.l1.go = "Andre_Abel_Quest_In_Prison_6";
			break;

		case "Andre_Abel_Quest_In_Prison_6":
			DialogExit();
			NextDiag.CurrentNode = "Andre_Abel_Quest_In_Prison_7";
			LAi_SetCitizenType(NPChar);
			PChar.items.blade7 = 1;
			PChar.equip.blade = "blade7";
			NPChar.items.blade7 = 1;
			NPChar.equip.blade = "blade7";
			SetFunctionLocationCondition("Andre_Abel_Quest_Liberty", "Villemstad_ExitTown", false);
			SetFunctionNPCDeathCondition("Andre_Abel_Quest_Martin_Bleker_Is_Dead", "Martin_Bleker", false);
			ChangeCharacterAddressGroup(NPChar, "Villemstad_prison", "goto", "goto12");
			DoFunctionReloadToLocation("Villemstad_prison", "goto", "goto23", "Andre_Abel_Quest_Runaway_From_Prison");
			break;

		case "Andre_Abel_Quest_In_Prison_7":
			dialog.text = RandPhraseSimple("Il faut se dépêcher.", "Vite, avant que les gardes ne donnent l'alerte.");
			link.l1 = "Ne t'agite pas. On s'est sortis de pires pétrins...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Andre_Abel_Quest_In_Prison_7";
			break;

		case "Andre_Abel_Quest_In_Liberty_1":
			dialog.text = "J'attendais ce moment depuis plus d'un an ! Merci, capitaine. Il me restait encore sept ans à tirer.";
			link.l1 = "Merci à toi aussi. Je ne sais pas comment j'aurais pu m'évader sans tes crochets et tes lames.";
			link.l1.go = "Andre_Abel_Quest_In_Liberty_2";
			chrDisableReloadToLocation = false;
			break;

		case "Andre_Abel_Quest_In_Liberty_2":
			dialog.text = "Eh bien ? On s'est échappés ? Adieu, et bonne chance.";
			link.l1 = "Au revoir...";
			link.l1.go = "Andre_Abel_Quest_In_Liberty_3";
			link.l2 = "Attends. Tu es un gars malin, tu ne voudrais pas rejoindre mon équipage comme abordeur ?";
			link.l2.go = "Andre_Abel_Quest_In_Liberty_4";
			break;

		case "Andre_Abel_Quest_In_Liberty_3":
			DialogExit();
			NPChar.LifeDay = 0;
			LAi_ActorRunToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", -1);
			break;

		case "Andre_Abel_Quest_In_Liberty_4":
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) > 24 && GetSummonSkillFromName(pchar, SKILL_FORTUNE) > 29)
			{
				dialog.text = "Officier ? Hum, pourquoi pas, si on s'entend sur le prix.";
				link.l1 = "Ne t'inquiète pas pour ça. Je ne te léserai pas sur l'argent.";
				link.l1.go = "Andre_Abel_Quest_In_Liberty_5";
			}
			else
			{
				dialog.text = "Non, capitaine... Ne m'en veux pas, mais je suis un homme d'un métier un peu différent. Le service, ce n'est pas pour moi.";
				link.l1 = "D'accord, tant pis. Bonne chance à toi.";
				link.l1.go = "Andre_Abel_Quest_In_Liberty_3";
			}
			break;

		case "Andre_Abel_Quest_In_Liberty_5":
			dialog.text = "Alors, j'accepte !";
			link.l1 = "Parfait. Bienvenue dans l'équipage !";
			link.l1.go = "Andre_Abel_Quest_In_Liberty_6";
			break;

		case "Andre_Abel_Quest_In_Liberty_6":
			dialog.text = "Merci, capitaine. Je ferai de mon mieux.";
			link.l1 = "Je n'en doute pas.";
			link.l1.go = "Andre_Abel_Quest_In_Liberty_7";
			break;

		case "Andre_Abel_Quest_In_Liberty_7":
			DialogExit();
			NPChar.Dialog.FileName = "Enc_Officer_dialog.c";
			NPChar.Dialog.CurrentNode = "hired";
			LAi_SetStayType(NPChar);
			NPChar.Greeting = "Gr_Officer";
			NPChar.Money   = 0;
			NPChar.Payment = true;
			NPChar.DontClearDead = true;
			AddPassenger(PChar, NPChar, false);
			NPChar.OfficerWantToGo.DontGo = true;
			NPChar.HalfImmortal = true;  // Контузия
			NPChar.HeroModel = "OffOrion,OffOrion_1,OffOrion_2,OffOrion_3,OffOrion_4,OffOrion_5";
			NPChar.loyality = MAX_LOYALITY;
			AddQuestRecord("Andre_Abel_Quest", "19");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			SetFunctionExitFromLocationCondition("Andre_Abel_Quest_Delete_Martin", PChar.location, false);
			break;
        	// <-- Мартин Блэкер. Квест "Accompaniment of the Orion fluyt"

		//--> работорговец, пинас
		case "TakeShoreCap":
    		dialog.text = "Coquin ! Tu ne t'y attendais pas, hein ?";
    		link.l1 = "א quoi donc ?";
    		link.l1.go = "Node_1";
		break;

		case "Node_1":
			dialog.text = "Haha ! Il n'y a pas d'esclaves ici ! Tu croyais qu'on allait te les montrer ?";
			link.l1 = "Ah, toi... Et moi qui me demandais d'oם venaient les soldats sur une pinasse marchande, et en si grand nombre... Un piège !!";
			link.l1.go = "Node_2";
		break;

 		case "Node_2":
			dialog.text = "Oui, salaud, c'est un piège. Et je ne suis pas un marchand, mais un officier de combat ! Et même si tu as gagné le combat, tu n'échapperas pas à la justice.";
			link.l1 = "Et pourquoi donc ? Je vais en finir avec toi tout de suite, envoyer ton rafiot par le fond, et personne n'en saura rien.";
			link.l1.go = "Node_3";
		break;

 		case "Node_3":
			dialog.text = "Tu te trompes. Tes affaires louches avec un usurier du coin ont été découvertes. Le gouverneur général l'apprendra bientכt, et tu n'échapperas pas à la potence. Bon, je vais faire en sorte que tu ne vives pas jusque-là.";
			link.l1 = "Essaie donc, chien de garde du gouverneur !";
			link.l1.go = "Node_4";
		break;

 		case "Node_4":
 		    pchar.questTemp.Slavetrader = "TakeShoreCap_end"; //это состояние квеста для проверки у квестодателя
            AddQuestRecord("Slavetrader", "13");
			AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetrader.ShipName);
            pchar.quest.Slavetrader_DieHard.over = "yes";
			pchar.quest.Slavetrader_AfterBattle.over = "yes";
			pchar.quest.Slavetrader_ShoreShipsOver.over = "yes";
            Island_SetReloadEnableGlobal(pchar.questTemp.Slavetrader.Island, true);
		    LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Slave_arest":
			dialog.text = "" + GetFullName(pchar) + ", au nom de la loi, vous êtes en état d'arrestation ! Remettez immédiatement vos armes et suivez-nous !";
			link.l1 = "Qu'est-ce que ça signifie, officier ? Sur quel fondement ?";
			link.l1.go = "Slave_arest_1";
		break;

		case "Slave_arest_1":
			dialog.text = "Inutile de jouer les agneaux, capitaine ! Vos sales affaires sont dévoilées. Et pour le massacre que vous avez commis, et pour le navire de " + NationNameGenitive(sti(npchar.nation)) + " que vous avez coulé, vous finirez au bout d'une vergue !";
			link.l1 = "Eh bien, si c'est comme ça... Alors, je n'ai plus rien à perdre, n'est-ce pas ? Tenez-vous bien, chiens !";
			link.l1.go = "Slave_arest_2";
		break;

		case "Slave_arest_2":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			LAi_SetWarriorTypeNoGroup(npchar);
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//<--работорговец пинас

		//--> работорговец, крыса в доме
		case "Rat_bandos":
			dialog.text = "Hé ! Qu'est-ce que tu as oublié ici ? Allez, fiche le camp !";
    		link.l1 = "Tu n'es pas très aimable, ma chère. Ce ne serait pas là que se cache ce rat de Gontier, hein ?";
    		link.l1.go = "Node_rat_1";
		break;

		case "Node_rat_1":
			dialog.text = "Il n'y a pas de Gontier ici ! Si c'est tout ce que tu voulais savoir, dehors !";
			link.l1 = "J'ai l'impression que tu mens. Nous allons fouiller la maison, et on verra bien...";
			link.l1.go = "Node_rat_2";
		break;

 		case "Node_rat_2":
			dialog.text = "Hé ! François ! Sauve-toi ! Les gars, à l'aide !";
			link.l1 = "Espèce de vipère !";
			link.l1.go = "Node_rat_3";
		break;

		case "Node_rat_3":
            LAi_SetPlayerType(pchar);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "Slavetrader_findTortugaRat1");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Rat_lover":
			dialog.text = "Aïe ! Ne me touche pas !";
    		link.l1 = "Oם est François Gontier ? Réponds, petite garce, ou tu suivras tes amis !";
    		link.l1.go = "Rat_lover_1";
		break;

		case "Rat_lover_1":
			dialog.text = "Non, non, je vais tout dire ! Il a sauté par la fenêtre et s'est enfui, sans doute vers son navire.";
    		link.l1 = "Quel navire ? Son navire n'est pas au port, je le sais. Ne me mens pas, ma belle, ça va mal finir...";
    		link.l1.go = "Rat_lover_2";
		break;

		case "Rat_lover_2":
			dialog.text = "Je ne mens pas, je le jure ! Il a dit qu'il avait mouillé près d'une petite île avec un phare, et qu'il était venu en ville en chaloupe... Il est là-bas ! Ne me touche pas !";
    		link.l1 = "Bon, on dirait que tu ne mens pas. Reste tranquille et ne bouge pas. De manière générale, il faut choisir ses amis avec discernement. Quoique, quel discernement tu as, je le vois dans tes yeux : tu es une idiote.";
    		link.l1.go = "Rat_lover_3";
			pchar.quest.Slavetrader_RatAttack.win_condition.l1 = "location";
            pchar.quest.Slavetrader_RatAttack.win_condition.l1.location = "Tortuga";//отправляем в локацию
            pchar.quest.Slavetrader_RatAttack.function = "Slavetrader_RatCorvette";//создание корвета
			SetFunctionTimerCondition("Slavetrader_RatCorvetteOver", 0, 0, 1, false);
		break;

		case "Rat_lover_3":
 		    LAi_SetPlayerType(pchar);
            SetCharacterRemovable(npchar, false);
            LAi_SetActorType(npchar);
			npchar.lifeday = 0;
			AddQuestRecord("Slavetrader", "21_9");
            DialogExit();
		break;
		//<--работорговец крыса в доме

		//--> работорговец, беглые рабы
		case "Slave_woman":
			dialog.text = "וpargnez-nous ! Pitié ! Nous nous rendons !";
    		link.l1 = "Vraiment ? Allez, tout le monde, sur le navire et dans les cales ! Quiconque fera un geste de travers sera abattu sur-le-champ !";
    		link.l1.go = "exit";
			AddDialogExitQuestFunction("Slavetrader_Slavewoman");
		break;
		//<--работорговец беглые рабы

		//ОЗГ, Карлос Кассир
		case "Carlos":
            dialog.text = "Dégage, qui que tu sois. Tu vois bien que je suis occupé.";
            link.l1 = "Je devrais peut-être vraiment revenir plus tard... דa pue trop ici en ce moment. Je ne savais vraiment pas qu'on laissait entrer les porcs dans ce genre d'établissement.";
            link.l1.go = "Carlos_7";
        break;

       	case "Carlos_3":
			Dialog.Text = "Non mais, regardez-moi ça ! Prends garde de ne pas le regretter, capitaine : personne ne traite Carlos le Caissier de lâche impunément ! On se retrouve devant les portes de la ville dans une heure, et on poursuivra notre conversation là-bas, pour ne pas salir les planchers de cet établissement avec tes tripes. J'espère que ton courage ne te quittera pas, et je te ferai ravaler tes paroles...";
			link.l1 = "דa suffit, mon cher. Garde ton ardeur pour confirmer tes paroles. J'y serai dans une heure, et si je ne t'y trouve pas, sois sמr que la réputation de lâcheté du condottiere Caissier te suivra partout, quelle que soit la fissure oם tu te cacheras.";
			link.l1.go = "Carlos_4";
			pchar.questTemp.Headhunter = "hunt_carlos_fight";
        break;

		case "Carlos_4":
			LAi_LocationDisableOfficersGen(pchar.questTemp.Headhunter.City + "_ExitTown", true);//офицеров не пускать
			locations[FindLocation(pchar.questTemp.Headhunter.City + "_ExitTown")].DisableEncounters = true; //энкаутеры закроем
			AddQuestRecord("Headhunt", "2_1");
			pchar.quest.HeadhunterTimer.win_condition.l1 = "Timer";
			pchar.quest.HeadhunterTimer.win_condition.l1.date.hour  = sti(GetTime() + 1);
			pchar.quest.HeadhunterTimer.win_condition.l1.date.day   = GetAddingDataDay(0, 0, 0);
			pchar.quest.HeadhunterTimer.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
			pchar.quest.HeadhunterTimer.win_condition.l1.date.year  = GetAddingDataYear(0, 0, 0);
			pchar.quest.HeadhunterTimer.function = "CarlosDuel";
			SetFunctionTimerCondition("CarlosDuelOver", 0, 0, 2, false);
			NextDiag.CurrentNode = "Carlos_5";
			DialogExit();
		break;

		case "Carlos_5":
			Dialog.Text = "Eh bien, que voulez-vous encore ?";
			link.l1 = "Je voulais juste te rappeler notre rendez-vous.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "Carlos_5";
        break;

		case "talk_off_town_Carlos":
			Dialog.Text = "Eh bien, voilà, "+ GetSexPhrase("petit roquet bavard","petite garce bavarde") +" ! Maintenant, tu vas regretter d'avoir vu le jour !";
			link.l1 = "Je vois que tu as amené de la compagnie, chien ? Tant mieux : tu ne seras pas seul en enfer. En garde !";
			link.l1.go = "Carlos_6";
			chrDisableReloadToLocation = true;
		break;

		case "Carlos_6":
			LAi_SetPlayerType(pchar);
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "CarlosDie");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Carlos_7":
			dialog.text = "Une minute, "+ GetSexPhrase("le gars","la fille") +"... Je n'aime pas ton ton. Tu sais à qui tu parles, au moins ?";
			link.l1 = "Je parle à un porc ivre qui a pris la place oם je comptais passer la soirée. Et maintenant, tout pue ici sans espoir, comme dans une étable : quel dommage, n'est-ce pas ?";
			link.l1.go = "Carlos_8";
		break;

		case "Carlos_8":
			dialog.text = "Tu es "+ GetSexPhrase("un chiot bien hardi","une fille bien hardie") +", à ce que je vois... Je suis Carlos le Caissier : tout le monde dans cette ville et dans bien d'autres connaît mon nom, et mon épée a déjà fait taire cinquante beaux parleurs arrogants. Je te conseille de filer d'ici avant que je ne te coupe la langue. Je ne veux pas gâcher une bonne soirée.";
			link.l1 = "Pour un porc, tu es étonnamment poli. Ou, plus probablement, c'est de la lâcheté... C'est vraiment dommage.";
			link.l1.go = "Carlos_3";
			int n = FindLocation(pchar.questTemp.Headhunter.City + "_Brothel");
			locations[n].reload.l2.disable = true;
		break;
		//ОЗГ, Карлос Кассир

		//ОЗГ, Ганнибал Хоум
		case "Houm":
            dialog.text = "Va-t'en, homme de la mer. Tu te tiens sur le chemin du lion noir.";
        	link.l1 = "La politesse est le propre des hommes, pas des bêtes : je vois que tu ne la connais pas.";
            link.l1.go = "Houm_1";
        break;

		case "Houm_1":
            dialog.text = "La souris de bord essaie d'agacer le lion ? Audacieux, mais stupide : le lion ne remarque pas ceux qui rampent dans la poussière à ses pieds.";
        	link.l1 = "Tu remarqueras peut-être mon épée, seigneur « lion » ?";
            link.l1.go = "Houm_2";
        break;

		case "Houm_2":
            dialog.text = "Brave petite souris... Ce sont les chacals hollandais qui t'ont payée, hein ? Ils veulent avoir le lion qui les a blessés par les mains d'un autre, et ils promettent de l'or à celui qui n'aura pas peur. Je sais que seul l'or vous fait oublier la peur, à vous, les Blancs. Souviens-t'en avant que le lion ne se fâche vraiment.";
        	link.l1 = "Assez de raisonnements, sale gueule noire. Laissons là la diplomatie et parlons franchement.";
            link.l1.go = "Houm_3";
        break;

		case "Houm_3":
            dialog.text = "Le lion noir écoutera, mais sois bref, mercenaire hollandais.";
        	link.l1 = "Je ne travaille pas pour les autorités, chien noir. Mon frère était sur le navire hollandais que tu as coulé. Et je veux que tu répondes de sa mort.";
            link.l1.go = "Houm_4";
        break;

		case "Houm_4":
            dialog.text = "Ha, le lion est surpris. Devant lui, il n'y a pas une souris qui se prend pour une chasseuse de pièces hollandaises, mais un loup qui veut venger son frère ? Le lion accepte ton défi avec dignité. Ne trouble pas la paix de cette ville : le lion attendra le chasseur en mer. Bats-toi comme il se doit, et meurs comme un guerrier, et le lion dévorera ton cœur, et le courage du chasseur continuera de vivre après "+ GetSexPhrase("sa","sa") +" mort.";
        	link.l1 = "Va sur ton navire, ordure, et prépare-toi à couler avec lui !";
            link.l1.go = "Houm_5";
			AddQuestRecord("Headhunt", "6");
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
			pchar.quest.Headhunter_HoumAttack.win_condition.l1 = "location";
            pchar.quest.Headhunter_HoumAttack.win_condition.l1.location = pchar.questTemp.Headhunter.Island;//отправляем в локацию
            pchar.quest.Headhunter_HoumAttack.function = "Headhunter_CreateHoumShips";//создание кораблей
        break;

		case "Houm_5":
			if (findsubstr(PChar.location, "_tavern" , 0) != -1)
			{
				DialogExit();
				NextDiag.CurrentNode = "Houm_6";
			}
			else
			{
				LAi_SetActorType(npchar);
				LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 15.0);
			}
			DialogExit();
        break;

		case "Houm_6":
			Dialog.Text = "Eh bien, que voulez-vous encore ?";
			link.l1 = "Je voulais juste te rappeler notre rendez-vous.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "Houm_6";
        break;

		case "RatOfficer":
			int iGoods1 = 400 - GetSquadronGoods(Pchar, GOOD_EBONY);
			int iGoods2 = 500 - GetSquadronGoods(Pchar, GOOD_MAHOGANY);
			int iGoods3 = 670 - GetSquadronGoods(Pchar, GOOD_SANDAL);
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
	    		if(pchar.questTemp.Headhunter == "Rat_officer" && GetCompanionQuantity(pchar) == 1 && 3-sti(RealShips[sti(pchar.ship.type)].Class) <= 0)
				{

					if(iGoods1 < 1 || iGoods2 < 1 || iGoods3 < 1)
					{
						dialog.text = "Bon, qu'est-ce que tu veux ? Fiche le camp, je ne suis pas d'humeur à bavarder.";
						link.l1 = "Je viens de débarquer... J'ai envie de boire un coup, mais pas en solitaire. Tu me tiens compagnie ? C'est moi qui paie !";
						link.l1.go = "RatOfficer_1";
					}
					else
					{
						dialog.text = "Bon, qu'est-ce que tu veux ? Fiche le camp, je ne suis pas d'humeur à bavarder.";
						link.l1 = "Je n'ai pas envie de bavarder avec toi. Bon repos.";
						link.l1.go = "exit";
						NextDiag.TempNode = "RatOfficer";
					}
					break;
				}
			}
			dialog.text = "Qu'est-ce que tu veux ? Fiche le camp, je ne suis pas d'humeur à bavarder.";
			link.l1 = "Je n'ai pas envie de bavarder avec toi. Bon repos.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RatOfficer";
		break;

		case "RatOfficer_1":
			dialog.text = "Ah, bon, alors c'est autre chose. Assieds-toi.";
			link.l1 = "Tiens ! Toi, tu es un vrai marin !";
			link.l1.go = "RatOfficer_1_sit";
		break;

		case "RatOfficer_1_sit":
			NextDiag.CurrentNode = "RatOfficer_2";
			LAi_SetActorType(npchar);
			LAi_ActorSetSitMode(npchar);
			LAi_ActorDialogDelay(npchar, pchar, "", 1.5);
			DoQuestReloadToLocation("Tortuga_tavern", "sit", "sit1", "");
			LAi_SetSitType(Pchar);
			DialogExit();
		break;

		case "RatOfficer_2":
			dialog.text = "Verse, "+ GetSexPhrase("le gars","la fille") +" ! Je vois que tu n'es rien de moins qu'un capitaine ! D'oם viens-tu ?";
			link.l1 = "Argh, quel rhum ! Quoi ? Ah, on vient de la Martinique, de la Martinique. On fait du commerce, tout doucement.";
			link.l1.go = "RatOfficer_3";
		break;

		case "RatOfficer_3":
			dialog.text = "Vous faites du commerce ? Eh bien, c'est une bonne chose. Nous aussi, on est marchands : tu as vu la pinasse au port ?";
			link.l1 = "Oui, le commerce, c'est une bonne chose, seulement les pirates, que le diable les emporte, ne nous laissent pas vivre... Ils attaquent même les convois, alors les navires isolés, n'en parlons pas. Et mon patron, que le diable l'emporte, a acheté une cale pleine de bois précieux... hic !";
			link.l1.go = "RatOfficer_4";
		break;

		case "RatOfficer_4":
			dialog.text = "Il est riche, ton patron, peut-être ?";
			link.l1 = "Il n'est pas pauvre. Mais très radin. Je lui ai dit d'équiper une escorte, d'engager un navire de protection, ou au moins de trouver un compagnon de route... Mais non, il regrette son argent ! Je vais devoir faire tout le trajet jusqu'à Belize sans escorte.";
			link.l1.go = "RatOfficer_5";
		break;

		case "RatOfficer_5":
			dialog.text = "Oui, la mer n'est pas sמre ces temps-ci. Et tous ces maudits boucaniers... hic ! Des chasseurs ! Tu parles de chasseurs ! Ce sont d'honnêtes marchands comme toi et moi qu'ils chassent...";
			link.l1 = "Oui, tu as sacrément raison ! Tout ça, c'est à cause d'eux, ces renégats. Eh, et comment veux-tu aller de Tortuga à Belize sans escorte ? Et en plus, en chemin, il faut faire escale dans le golfe de la Perdition : le patron m'a ordonné de traiter avec les Indiens de là-bas, de leur acheter des pierres précieuses pour une bouchée de pain, et de refaire les réserves d'eau douce... Dis, tu ne vas pas dans cette direction, par hasard ? Peut-être que...";
			link.l1.go = "RatOfficer_6";
		break;

		case "RatOfficer_6":
			dialog.text = "Non, nous, on va... hic ! On va dans une tout autre direction.";
			link.l1 = "Oh, dommage. Bon, prions le Tout-Puissant de nous protéger en route... On ne peut guère compter sur les canons : la marchandise prend toute la place dans la cale, il ne reste presque plus de place pour les boulets et la poudre... Voilà ce que c'est, la cupidité humaine !";
			link.l1.go = "RatOfficer_7";
		break;

		case "RatOfficer_7":
			dialog.text = "La cupidité... La cupidité, c'est... hic, c'est mal. Ils comptent chaque peso, ils sont prêts à se pendre pour une pièce d'or. Ils ne voient pas la lumière de Dieu derrière leur bourse et ne laissent pas vivre les autres. J'ai raison, capitaine ?";
			link.l1 = "Tu as cent fois raison, mon ami ! Quand les pirates attaqueront, je n'aurai même pas de quoi riposter. Il y a deux bordées de charges dans les canons, et l'équipe d'abordage, c'est trois éclopés et deux bleus... Oh, notre sort, notre sort...";
			link.l1.go = "RatOfficer_8";
		break;

		case "RatOfficer_8":
			dialog.text = "Ne t'en fais pas ! C'est la première fois, ou quoi ? Buvons encore un coup, sinon il est temps pour moi de retourner sur mon rafiot.";
			link.l1 = "Bon, encore un, et je file aussi... Ils étaient soixante-quinze, et pas un n'est revenu, oh-oh, ils ont sombré dans les profondeurs de la mer... Adieu, mon ami...";
			link.l1.go = "RatOfficer_9";
			pchar.quest.Headhunter_Ratgulf.win_condition.l1 = "location";
            pchar.quest.Headhunter_Ratgulf.win_condition.l1.location = "Shore_ship2";//отправляем в локацию
            pchar.quest.Headhunter_Ratgulf.function = "Headhunter_Ratgulf";
			SetFunctionTimerCondition("Headhunter_RatgulfOver", 0, 0, 15, false);//таймер
		break;

		case "RatOfficer_9":
			pchar.quest.Headhunter_RatOfficerOver.over = "yes";
			LAI_SetPlayerType(pchar);
			LAI_SetSitType(npchar);
            DoQuestReloadToLocation("Tortuga_tavern", "goto", "goto2", "");
			AddQuestRecord("Headhunt", "18");
			pchar.questTemp.Headhunter = "Rat_gulf";
			NextDiag.CurrentNode = "RatOfficer_10";
			npchar.lifeDay = 0;
			DialogExit();
		break;

		case "RatOfficer_10":
			dialog.text = "Quinze marins sur le coffre du mort... hic !";
			link.l1 = "Compris.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RatOfficer_10";
		break;

		//ОЗГ, кэп-Крыса
		case "Rat_talk":
			dialog.text = "Argh ! Alors, tu n'es pas un marchand ?";
			link.l1 = "Non, le Rat. Cette fois, tu t'es trompé. Au lieu de bois précieux, c'est l'acier froid et le plomb brמlant qui t'attendent. Tes aventures finiront ici, dans cette baie.";
			link.l1.go = "Rat_talk_1";
		break;

		case "Rat_talk_1":
			dialog.text = "Je ne me rendrai pas si facilement, même si l'abordage est déjà perdu. Tu vas apprendre ce qu'il en coמte de se frotter au Rat ! Ja Preston me vengera !";
			link.l1 = "Tu iras raconter tes fables aux diables de l'enfer. En garde, salaud !";
			link.l1.go = "Rat_talk_exit";
		break;

		case "Rat_talk_exit":
 		    pchar.questTemp.Headhunter = "hunt_rat_yes1";
            AddQuestRecord("Headhunt", "23");
			AddQuestUserData("Headhunt", "sSex", GetSexPhrase("", "e"));
            pchar.quest.Headhunter_DieHard.over = "yes";
			pchar.quest.Headhunter_AfterBattle.over = "yes";
            Island_SetReloadEnableGlobal("Beliz", true);
		    LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "RatHunters":
			link.l1 = "Hein ?! Quoi ? Qu'est-ce que tu fiches ici, bon sang ? Qui t'a laissé entrer ?";
			link.l1.go = "RatHunters_1";
		break;

		case "RatHunters_1":
			dialog.text = "Ja Preston te salue...";
			link.l1 = "Quoi ? Oh, diable !";
			link.l1.go = "RatHunters_2";
		break;

		case "RatHunters_2":
			LAi_SetFightMode(pchar, true);
			LAi_LockFightMode(pchar, false);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "RatHunters_Dead");
			if (startHeroType == 2)
			{
				if(CheckAttribute(pchar,"Whisper.EsFriendTown") && pchar.Whisper.EsFriendTown == "Villemstad")
				{
					ref sldd = CharacterFromID("W_Chard");
					ChangeCharacterAddressGroup(sldd, "Villemstad_tavern", "reload", "reload1");
					LAi_LocationFightDisable(loadedLocation, false);
				}

			}
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Halen":
			dialog.text = "Vous m'avez bousculé, "+ GetSexPhrase("mon brave","ma brave") +" ! C'était voulu, ou c'est un malentendu ?";
			link.l1 = "Vous êtes Martin Van Halen ?";
			link.l1.go = "Halen_1";
		break;

		case "Halen_1":
			dialog.text = "Oui, c'est mon nom, mais vous ne m'avez toujours pas dit le vכtre ? Ayez l'obligeance d'expliquer ce que vous voulez, ou sortez. Ne mettez pas ma patience à l'épreuve : je n'ai aucune envie de perdre mon temps à parler avec la racaille.";
			link.l1 = "Oui... Un banal petit-maître, couvert de faveurs par les autorités. L'excès de politesse ne vous tuera pas. Mais l'excès d'arrogance, c'est possible. On ne vous a pas dit que les crétins arrogants ne s'attardent pas en ce monde, même s'ils sont bien reçus par les dignitaires ?";
			link.l1.go = "Halen_2";
			link.l2 = "Hum... je voulais juste rencontrer le célèbre corsaire hollandais.";
			link.l2.go = "Halen_3";
		break;

		case "Halen_2":
			dialog.text = "Argh ! Je n'ai jamais entendu pareille insolence ! Ne prends pas la peine de répondre : je vois bien que tu parles à peine. T'insulter, je crois que je n'y arriverai pas : toutes les épithètes ne seraient que des flatteries pour toi ! Dégaine ton épée, "+ GetSexPhrase("vermisseau","catin") +", si tu sais la tenir ! J'exige réparation immédiatement. Sinon, je vais t'embrocher comme un porc !";
			link.l1 = "En garde, salaud !";
			link.l1.go = "Halen_fight";
		break;

		case "Halen_fight":
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "HOLLAND_CITIZENS");
			LAi_group_Attack(NPChar, Pchar);
			SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");

		break;

		case "Halen_3":
			dialog.text = "Satisfait"+ GetSexPhrase("","e") +" de cette rencontre ? Et maintenant, va-t'en au diable et cesse de m'offusquer la vue, espèce de plouc !";
			link.l1 = "Hum...";
			link.l1.go = "exit_halen";
		break;

		case "Halen_4":
			dialog.text = "Encore toi ? Fais-moi la politesse d'aller enfin "+ GetSexPhrase("à la taverne, sous la table, avec les restes et autres ordures","au bordel, distraire les matelots ivres") +". C'est là qu'est ta place.";
			link.l1 = "Hum...";
			link.l1.go = "exit_halen";
			link.l2 = "Je vais t'apprendre la politesse, moi, porc de Hollandais arrogant !";
			link.l2.go = "Halen_2";
			NextDiag.CurrentNode = "Halen_4";
		break;

		case "exit_halen":
			LAi_SetActorType(npchar);
            LAi_ActorGoToLocation(npchar, "reload", "reload2_back", "none", "", "", "Headhunter_HalenOut", -1);
            LAi_Actor2WaitDialog(npchar, pchar);
			NextDiag.CurrentNode = "Halen_4";
            DialogExit();
		break;

		case "Miko":
			dialog.text = "Que me voulez-vous ?";
			link.l1 = "Alors... c'est toi, Miko Pistoliero ?";
			link.l1.go = "Miko_1";
		break;

		case "Miko_1":
			dialog.text = "Oui, c'est moi. א quoi dois-je ce plaisir ?";
			link.l1 = "Je dois te parler de Ja Preston. J'ai très envie de le rencontrer.";
			link.l1.go = "Miko_2";
		break;

		case "Miko_2":
			dialog.text = "Ah... Bon. C'est donc ça. Alors, c'est toi "+ GetSexPhrase("le type","la fille") +" que nous cherchons... Te voilà... Eh bien, ça facilite beaucoup ma tâche. Je ne pense pas que tu repartiras d'ici comme ça.";
			link.l1 = "Oui, c'est moi. Dis-moi oם est Preston, et tu auras la vie sauve.";
			link.l1.go = "Miko_3";
		break;

		case "Miko_3":
			dialog.text = "Tu me menaces, "+ GetSexPhrase("l'ami","ma fille") +" ? Tu as tort. Tu n'es pas d'ici, et nous allons tous te mettre en pièces. Quant à mon patron, il n'est pas loin. Beaucoup plus près que tu ne le penses. Mais tu ne trouveras jamais Ja, parce que c'est MOI que tu as trouvé, ha ha ha !!";
			link.l1 = "Eh bien, salaud, tu as choisi ton sort...";
			link.l1.go = "Miko_fight";
			pchar.questTemp.Headhunter = "miko_mustdie";
			pchar.quest.Headhunter_Miko_mustdie.win_condition.l1 = "NPC_Death";
			pchar.quest.Headhunter_Miko_mustdie.win_condition.l1.character = "Miko";
			pchar.quest.Headhunter_Miko_mustdie.function = "Miko_die";
		break;

		case "Miko_fight":
			chrDisableReloadToLocation = true;
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "Pearlgroup_2");
			LAi_group_Attack(NPChar, Pchar);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			AddQuestRecord("Headhunt", "34");
		break;

		case "JaHunters":
			dialog.text = "Et voici "+ GetSexPhrase("notre ami ","notre amie ") +" !";
			link.l1 = "Mon Dieu... Encore !";
			link.l1.go = "JaHunters_1";
		break;

		case "JaHunters_1":
			dialog.text = "Ja Preston m'a demandé de te saluer...";
			link.l1 = "Ah-ah !!";
			link.l1.go = "JaHunters_2";
		break;

		case "JaHunters_2":
			LAi_SetImmortal(npchar, false);
			pchar.quest.Headhunter_Find_Ja.win_condition.l1 = "location";
			pchar.quest.Headhunter_Find_Ja.win_condition.l1.location = "SantaCatalina";
			pchar.quest.Headhunter_Find_Ja.function = "Create_Ja";
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "FindJa");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Ja_talk":
			dialog.text = "Alors, nous voilà enfin face à face... Bon, on s'entretue, ou on discute ?";
			link.l1 = "Enfin ! Je commençais à en avoir assez de toutes ces salutations... Lève ta lame, Preston, je veux en finir avec toi une fois pour toutes.";
			link.l1.go = "Ja_talk_1";
			link.l2 = "Discutons, puisque tu le proposes. Tu ne t'enfuiras pas d'ici... De quoi pourrait-on parler, je me demande ?";
			link.l2.go = "Ja_talk_3";
		break;

		case "Ja_talk_1":
			dialog.text = "Bon... Alors, continuons !";
			link.l1 = "Argh ! Tiens bon !";
			link.l1.go = "Ja_talk_exit";
		break;

		case "Ja_talk_exit":
 		    pchar.questTemp.Headhunter = "hunt_ja_yes";
            bQuestDisableMapEnter = false;
		    LAi_SetCurHPMax(NPChar);
			LAi_GetCharacterMaxEnergy(NPChar);
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "Ja_talk_3":
			dialog.text = "Pourquoi diable me traques-tu ? Pourquoi as-tu tué tous mes hommes ?";
			link.l1 = "Argh ! Je crois que c'est toi qui me traquais ! Quant à ta question, ta bande a tellement empoisonné la vie des gens du François. Alors, nous avons décidé de nous débarrasser de toi...";
			link.l1.go = "Ja_talk_4";
		break;

		case "Ja_talk_4":
			dialog.text = "Diable ! Rogers a eu vent de ce que nous préparions... J'aurais dמ être plus prudent.";
			link.l1 = "C'est trop tard maintenant, Ja. Il est temps de mettre fin à cette conversation : je crois que tu as appris tout ce que tu voulais savoir. Je n'ai plus rien à te dire.";
			link.l1.go = "Ja_talk_5";
		break;

		case "Ja_talk_5":
			dialog.text = "Attends... écoute, je vais te faire une autre proposition. Tu es "+ GetSexPhrase("un corsaire audacieux et intelligent","une fille audacieuse et intelligente") +" et moi... j'ai perdu la partie. Je n'ai plus d'hommes ni de navire : tu as gagné l'abordage. Même si je parviens à te tuer maintenant, la fin sera la même. Pourquoi ne pas unir nos forces ? Je propose de remplacer l'hostilité par la paix, et je suis prêt à travailler avec toi, sous tes ordres.";
			link.l1 = "Non, Ja. Je ne te crois pas. Aujourd'hui, tu es mon officier, et demain, tu me plantes un couteau dans le dos ? Il est temps d'en finir avec notre affrontement !";
			link.l1.go = "Ja_talk_1";
			link.l2 = "Ha ! Voilà qui est intéressant ! Et tu sais, Ja, j'accepte. Un officier comme toi, ça ne se trouve pas facilement. Mais attention : si tu fais des blagues, je t'envoie par-dessus bord en un clin d'œil !";
			link.l2.go = "Ja_talk_6";
		break;

		case "Ja_talk_6":
			dialog.text = "L'avertissement est inutile, capitaine. Pour moi, désormais, l'endroit le plus sמr de l'archipel, c'est ton navire. Tu peux avoir confiance en moi. Je suis content que nous nous soyons entendus.";
			link.l1 = "Bienvenue dans l'équipage, corsaire !";
			link.l1.go = "Ja_hired";
			pchar.quest.Headhunter_AfterBattleJa.over = "yes";
		break;

		case "Ja_hired":
			bQuestDisableMapEnter = false;
			characters[GetCharacterIndex("Jafar")].lifeDay = 0;
			pchar.questTemp.Headhunter = "end_quest_full";
			AddQuestRecord("Headhunt", "38");
			CloseQuestHeader("Headhunt");
			pchar.questdata.Kondotier = 1;
			sld = GetCharacter(NPC_GenerateCharacter("Jafarry", "QuestCaptain", "man", "man", 25, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 25, 70, 70, "blade14", "pistol6", 100);
			sld.name = "Ja";
			sld.lastname = "Preston";
			sld.greeting = "Gr_Officer";
			sld.rank = 25;
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			sld.HoldEquip = true;
			SetSelfSkill(sld, 80, 80, 75, 80, 80);
			SetShipSkill(sld, 60, 50, 60, 60, 65, 70, 60, 60, 60);
			SetSPECIAL(sld, 9, 9, 10, 10, 8, 10, 10);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "ByWorker");
			SetCharacterPerk(sld, "Ciras");
			SetCharacterPerk(sld, "Gunman");
			SetCharacterPerk(sld, "Sliding");
			SetCharacterPerk(sld, "CriticalHit");
			SetCharacterPerk(sld, "IronWill");
			SetCharacterPerk(sld, "BladeDancer");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "FastReload");
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "SailsDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "MusketsShoot");
			SetCharacterPerk(sld, "AdvancedBattleState");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "LongRangeShoot");
			SetCharacterPerk(sld, "SwordplayProfessional");
			SetCharacterPerk(sld, "ShipTurnRateUp");
			SetCharacterPerk(sld, "ShipSpeedUp");
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.HalfImmortal = true;  // Контузия
			sld.HeroModel = "QuestCaptain,QuestCaptain_1,QuestCaptain_2,QuestCaptain_3,QuestCaptain_4,QuestCaptain_5";
			sld.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			AddDialogExitQuestFunction("Pascal_Escape");
			QuestAboardCabinDialogNotBattle();
            DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
				
		case "AscoldSpainCapitain":
			pchar.questTemp.Ascold.SpainCapitainDialogue = true;
			dialog.text = "Assez ! Je vous en prie, arrêtez !";
			link.l1 = "Qu'y a-t-il ? L'Espagne s'est confiée à un lâche ?";
			link.l1.go = "AscoldSpainCapitain_offer_1";
		break;	
		
		case "AscoldSpainCapitain_offer_1":
			dialog.text = "Je ne sais pas ce qu'il vous faut, je vous propose un marché..";
			link.l1 = "Vous avez la liste d'inventaire ?!";
			link.l1.go = "AscoldSpainCapitain_offer_2";
		break;
		
		case "AscoldSpainCapitain_offer_2":
			dialog.text = "Je n'ai aucune liste. D'ailleurs, pendant cette bataille, la liste aurait pu finir au fond de la mer...";
			link.l1 = "Ah... Vous savez oם elle est ! Dites-le-moi tout de suite !";
			link.l1.go = "AscoldSpainCapitain_offer_3";
		break;
		
		case "AscoldSpainCapitain_offer_3":
			dialog.text = "Je vous le dirai ! Mais promettez-moi de me laisser partir avec mes affaires et 250 000 piastres ! Et laissez-moi aussi quitter votre bord dans un endroit sמr pour moi !";
			if (sti(pchar.money) < 250000)
			{
			link.l1 = "Je n'ai pas une telle somme. Et d'ailleurs, je n'ai pas l'intention de vous laisser vivre !";
			link.l1.go = "AscoldSpainCapitain_fight";
			}
			else
			{
			link.l1 = "Vous avez ma parole. Nous n'avons plus de temps. Oם est la liste ?!";
			link.l1.go = "AscoldSpainCapitain_offer_accepted";			
			link.l2 = "Au diable tout ça ! Je me débrouillerai sans vous !";
			link.l2.go = "AscoldSpainCapitain_fight";
			}
		break;
	
		case "AscoldSpainCapitain_offer_accepted":
			AddMoneyToCharacter(Pchar, - 250000);
			AddMoneyToCharacter(NPchar, 250000);
			dialog.text = "La liste est à bord : " + GetStrSmallRegister(XI_ConvertString(pchar.questTemp.Ascold.ShipType)) +" '"+pchar.questTemp.Ascold.ShipName+"'.";
			if (CheckAttribute(PChar, "questTemp.Ascold.Ship.foundcheck") && !CheckCharacterItem(pchar, "ShipsJournal"))
			{
				link.l1 = "Merde ! J'ai déjà vérifié, et je n'ai trouvé absolument rien du tout ! Crève !";
				link.l1.go = "AscoldSpainCapitain_fight";	
			}
			else if (LAi_IsDead(CharacterFromID(pchar.questTemp.Ascold.Ship)))
			{
			link.l1 = "Merde ! Je n'y trouve déjà plus rien... Alors, notre marché ne tient plus ! Crève !";
			link.l1.go = "AscoldSpainCapitain_fight";
			}
			else 
			{
				link.l1 = "Parfait !";
				link.l1.go = "AscoldSpainCapitain_agreed";
			}
		break;
		
		case "AscoldSpainCapitain_fight":
			QuestAboardCabinDialogExitWithBattle("");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		
		case "AscoldSpainCapitain_agreed":
			NPChar.LifeDay = 0;
			QuestAboardCabinDialogNotBattle();
			DialogExit();
		break;

			
		// СФ -->
		
		case "SF_InvitingOfficer":
			SaveCurrentQuestDateParam("InvitingOfficerDialogue");
			dialog.text = "Bonjour, " + GetAddress_Form(pchar) + ". Votre nom est bien " + pchar.name + " ?";
			link.l1 = "Oui, c'est exact.";
			link.l1.go = "SF_InvitingOfficerToHuber";
		break;
		
		case "SF_InvitingOfficerToHuber":
			dialog.text = "Son Excellence le gouverneur général de Port Royal, sir Thomas Madiford, souhaite vous voir. Dès que vous aurez terminé vos affaires au port, veuillez vous présenter immédiatement à sa résidence.";
			link.l1 = "Je suis un capitaine libre. Je n'ai aucun intérêt à traîner dans les salons cirés d'un palais de gouverneur.";
			link.l1.go = "SF_InvitingOfficerToHuberFirstCancel";
			link.l2 = "D'accord, j'y serai.";
			link.l2.go = "SF_InvitingOfficerToHuberTaken";
		break;
		
		case "SF_InvitingOfficerToHuberFirstCancel":
			dialog.text = "Vraiment ? Quand vous changerez d'avis, je suis sמr que Son Excellence n'aura plus besoin de vous...";
			link.l1 = "Bon, c'est d'accord, j'y serai.";
			link.l1.go = "SF_InvitingOfficerToHuberTaken";
			link.l2 = "C'est tout réfléchi.";
			link.l2.go = "SF_InvitingOfficerToHuberCancelConfirmation";
		break;
		
		case "SF_InvitingOfficerToHuberTaken":
			dialog.text = "Il vous attendra. Au revoir, " + GetAddress_Form(pchar) + ".";
			link.l1 = "Au revoir.";
			link.l1.go = "SF_InvitingOfficerToHuberExit";
			pchar.questTemp.silverfleet = "ToHuber";
		break;
		
		case "SF_InvitingOfficerToHuberCancelConfirmation":
			dialog.text = "Refuser est votre droit. Au revoir, " + GetAddress_Form(pchar) + ".";
			link.l1 = "Au revoir.";
			link.l1.go = "SF_InvitingOfficerToHuberExit";
		break;
		
		case "SF_InvitingOfficerToHuberExit":
			LAi_SetCitizenTypeNoGroup(NPchar);
			NextDiag.TempNode = "SF_InvitingOfficerToHuberWaiting";
    			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		
		case "SF_InvitingOfficerToHuberWaiting":
			dialog.text = "Je n'ai pas l'ordre de vous escorter jusqu'à Son Excellence, " + GetAddress_Form(pchar) + ".";
			link.l1 = "Bon, bon.";
			link.l1.go = "SF_InvitingOfficerToHuberExit";
		break;
		
		case "SilverSurferCaptain":
			dialog.text = "Hum... Hum... Euh...";
			link.l1 = "Toujours en vie ? J'ai hâte que tu craches ton dernier mot.";
			link.l1.go = "SilverSurferCaptainThreat";
			pchar.questTemp.silverfleet.silversurfercaptainspeak = true;
		break;
		
		case "SilverSurferCaptainThreat":
			dialog.text = "Tu ne sortiras pas d'ici... Hum. J'ai tout prévu. Mes hommes vont te capturer, et nous t'emmènerons loin de cette bataille sur mon navire. Ne fais pas l'idiot, sinon tu mourras ici, tout simplement.";
			link.l1 = "Eh bien, toi d'abord, tu vas mourir !";
			link.l1.go = "SilverSurferCaptainDead";
		break;
		
		case "SilverSurferCaptainDead":
			QuestAboardCabinDialogFree();
			LAi_KillCharacter(NPChar);
			DoQuestFunctionDelay("SF_CabinOfficer", 1.0);
		break;

		case "SilverSurferCaptainTrap":
			dialog.text = "Capitaine ! C'est un piège ! Ils attendaient que nous soyons assez loin pour sortir de leurs trous. Des forces impressionnantes, sans doute leurs meilleurs combattants, nous ont bloqués ici. דa va chauffer !";
			link.l1 = "Tenez bon ! On va s'en sortir ! On va tous les tuer !";
			link.l1.go = "SilverSurferCaptainTrapBattle";	
		break;

		case "SilverSurferCaptainTrapBattle":
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(NPChar, "reload", "reload1", "none", "", "", "OpenTheDoors", -1);
			LAi_LockFightMode(pchar, false);
			DialogExit();
		break;
		
		// <-- СФ
	}
}
