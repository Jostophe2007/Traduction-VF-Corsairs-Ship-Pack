// диалоговый файл №2 на фр. линейку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i;
	float locx, locy, locz;
	string sTemp;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    switch (Dialog.CurrentNode)
    {
        case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
            link.l1.go = "exit";

//>>>>>>>>>>>>========= Разброс диалогов по персонажам =====================
            //Квест №1, сопровождение Леграна.
            if (pchar.questTemp.State == "Fr1Legran_toLeMaren")// квест №1, базар с бандиами
            {
    			dialog.text = "Hé, "+ GetSexPhrase("l'ami","ma petite") +" ! Il faut qu'on parle à ton copain. וcarte-toi et ne t'en mêle pas, ce sera meilleur pour ta santé...";
    			link.l1 = "Hum, je crois qu'il vaut mieux que vous dégagiez le passage. Et prenez soin de vos oreilles !";
    			link.l1.go = "Step_F1_1";
            }
            //Квест №2, доставка письма в Кюрасао.
            if (pchar.questTemp.State == "Fr2Letter_Arrest")// квест №2, базар с охраной при аресте
            {
    			dialog.text = "Rendez vos armes ! Et n'essayez pas de résister !";
    			link.l1 = "Eh bien, comme vous voudrez. Et uniquement parce que Curaçao est en bons termes avec Tortuga...";
    			link.l1.go = "Step_F2_1";
            }
            if (pchar.questTemp.State == "Fr2Letter_PrisonTalk")// квест №2, базар с тюремщиком
            {
    			dialog.text = "Alors, on nourrit les punaises ? Demain, on te nourrira comme un roi, comme tout condamné à la potence, et elle est déjà en construction, héhé !";
    			link.l1 = "Eh bien, ça m'étonnerait que vous y gagniez quoi que ce soit...";
    			link.l1.go = "Step_F2_2";
            }
            if (pchar.questTemp.State == "Fr2Letter_VisitGovernor")// квест №2, базар с фантомом губера в тюрьме
            {
    			dialog.text = "Bonjour, capitaine.";
    			link.l1 = "Monsieur Stuyvesant... Quel bon vent vous amène ?!";
    			link.l1.go = "Step_F2_8";
            }
            if (pchar.questTemp.State == "Fr2Letter_SeekProblems")// квест №2, базар с кэпом галеона, абордаж
            {
    			dialog.text = ""+ GetSexPhrase("Maudit ladrón","Maudite garce") +" !";
    			link.l1 = "Silence, chien d'Espagnol ! Je vais te poser quelques questions. Si tu dis la vérité, tu vivras.";
    			link.l1.go = "Step_F2_12";
            }
			if (npchar.id == "AnnaDeLeiva")// квест №3, донна Анна в спальне
            {
    			dialog.text = "Mon Dieu ! Que s'est-il passé ? Vous venez de la part de Bertrand ? Qu'était-ce que ce bruit ?";
    			link.l1 = "Madame, j'ignore si c'est une triste nouvelle pour vous ou non, mais j'ai été contraint de tuer votre époux. Nous n'avons pas le temps de nous inquiéter ni de nous évanouir, il faut fuir immédiatement ! Le gouverneur général de Tortuga, Bertrand d'Ogeron, vous attend.";
    			link.l1.go = "Step_F3_1";
            }
			if (npchar.id == "InesDeLasCierras" && pchar.questTemp.State == "Fr5AnnaHant_toHavana")// квест №5, Инесс
            {
    			dialog.text = ""+ GetSexPhrase("Señor","Señorita") +", qui êtes-vous ? Et que faites-vous dans ma maison ?";
    			link.l1 = "Señora, je viens de la part de doña Anna, votre amie. א ce que je sais, vous l'avez avertie d'un certain danger...";
    			link.l1.go = "Step_F5_1";
            }
			if (npchar.id == "InesDeLasCierras" && pchar.questTemp.State == "Fr5AnnaHant_SeekHoseBrothers")
            {
    			dialog.text = "Dépêchez-vous, "+ GetSexPhrase("señor","señorita") +". Je vous assure que la vie de doña Anna ne tient qu'à un fil...";
    			link.l1 = "Tout ira bien, chère Inés, ne vous inquiétez pas.";
    			link.l1.go = "exit";
            }
			if (npchar.id == "InesDeLasCierras" && pchar.questTemp.State == "Fr5AnnaHant_GoodWork")
            {
    			dialog.text = "Alors, capitaine, quelles nouvelles ?";
    			link.l1 = "Tout va bien, il n'y a plus de problème avec les parents de doña Anna...";
    			link.l1.go = "Step_F5_4";
            }
			if (npchar.id == "Captain_1" || npchar.id == "Captain_2")//квест №6, базар с кэпами
            {
    			dialog.text = ""+ GetSexPhrase("Monsieur","Mademoiselle") +", nous devons faire voile vers Cumaná. Si, Dieu nous en garde, nous arrivons en retard, il n'y aura plus un seul réal ! Vous ne connaissez pas notre capitaine...";
    			link.l1 = "Hum, qui ne connaît pas François l'Olonnais ? Le célèbre flibustier...";
    			link.l1.go = "exit";
            }
			if (npchar.id == "RockBrasilian" && pchar.questTemp.State == "Fr7RockBras_toSeekPlace")//квест №7, базар с Бразильцем.
            {
    			dialog.text = NPCStringReactionRepeat("דa alors ! Qui a osé faire une chose pareille ?!", "Bon, poursuivons notre conversation. Alors, qui êtes-vous, héros de notre temps ?", "On continue ? Alors, qui êtes-vous ?", "Hum, finissons-en avec cette conversation. Qui êtes-vous ?", "block", 0, npchar, Dialog.CurrentNode);
    			if (LAi_group_GetTarget(pchar) <= 0)
				{
					link.l1 = HeroStringReactionRepeat("C'est moi qui ai osé. Je m'appelle " + GetFullName(pchar)+". Je suis là pour vous sortir d'ici.", "Continuons... Je m'appelle " + GetFullName(pchar)+", c'est vous que je viens chercher.", "Je m'appelle "+GetFullName(pchar)+", je suis ici pour vous.", "Finissons-en, aucun problème. Je m'appelle " + GetFullName(pchar)+", c'est vous que je viens chercher.", npchar, Dialog.CurrentNode);
    				link.l1.go = "Step_F7_1";
				}
				else
				{
					link.l1 = "Ce n'est pas le moment de parler, il faut se débarrasser de tout le monde ici !";
    				link.l1.go = "Step_F7_Late";
				}
				// --> типа опоздал...
				if (GetQuestPastDayParam("questTemp") > 8)
				{
    				dialog.text = "Qui êtes-vous... ?";
    				link.l1 = "Je suis ici pour vous, c'est d'Ogeron qui m'envoie...";
    				link.l1.go = "Step_F7_8";
				}
				else SaveCurrentQuestDateParam("questTemp"); //чтобы не глюкнуло во время боя
				// <-- типа опоздал...
            }
			if (npchar.id == "RockBrasilian" && pchar.questTemp.State == "empty")//квест №7, базар с Бразильцем в резиденции дОжерона.
            {
    			dialog.text = "Capitaine, je n'ai pas encore eu l'occasion de vous remercier.";
    			link.l1 = "Ce n'est rien, capitaine Rock...";
    			link.l1.go = "Step_F7_5";
            }
			if (npchar.id == "CaptainGay")//квест №8, базар с кэпом Геем.
            {
    			dialog.text = "Qui êtes-vous ?";
    			link.l1 = "Peu importe qui je suis. Le bonjour de John Morris. Il tient beaucoup à faire connaissance avec votre journal de bord.";
    			link.l1.go = "Step_F8_1";
            }
		break;
//<<<<<<<<<<<<===== Разброс диалогов по персонажам =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Спасение трёх горожан. Квест №1 **********************************
 		case "Step_F1_1":
			dialog.text = "Tu l'auras voulu ! Dis adieu à la vie...";
			link.l1 = "Oh, tu ne prends pas soin de tes oreilles...";
			link.l1.go = "Step_F1_2";
		break;
 		case "Step_F1_2":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			LAi_SetPlayerType(pchar);
			sld = characterFromId("Legran");
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER);
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "Fr1Legran_afterFightBandits");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
//********************************* Арест ГГ у Стэвезанта. Квест №2 **********************************
 		case "Step_F2_1":
			bDisableCharacterMenu = true; //закрываем Ф2
			LAi_SetPlayerType(pchar);
            DoReloadCharacterToLocation("Villemstad_prison",  "goto", "goto9");
			//StoreEquippedMaps(pchar); // ugeen
			pchar.MapsAtlasCount = 0;
			SetTempRemoveParam(pchar, "items");
			pchar.questTemp.money = sti(pchar.money)/2;
			RemoveCharacterEquip(pchar, BLADE_ITEM_TYPE);
			RemoveCharacterEquip(pchar, GUN_ITEM_TYPE);
			RemoveCharacterEquip(pchar, SPYGLASS_ITEM_TYPE);
			RemoveCharacterEquip(pchar, MAPS_ITEM_TYPE);
			pchar.money = 0;
			DeleteAttribute(pchar, "items");
			DoQuestCheckDelay("Fr2Letter_intoPrison_1", 20);
			AddQuestRecord("Fra_Line_2_DelivLetter", "2");
			AddQuestUserData("Fra_Line_2_DelivLetter", "sSex", GetSexPhrase("", "e"));
            DialogExit();
		break;
 		case "Step_F2_2":
			dialog.text = "Bon, bon, de quoi parles-tu ?";
			link.l1 = "Que tu assisteras gratuitement à mon exécution. Mais tu seras plus riche de quelques pièces si Stuyvesant fouille la cabine du capitaine de mon navire d'ici demain.";
			link.l1.go = "Step_F2_3";
		break;
 		case "Step_F2_3":
			dialog.text = "Pourquoi en as-tu besoin ?";
			link.l1 = "Pour qu'il prenne connaissance de mes papiers, de mon journal de bord et ainsi de suite. Il comprendra alors que je suis vraiment le messager du gouverneur général de Tortuga.";
			link.l1.go = "Step_F2_4";
		break;
 		case "Step_F2_4":
			dialog.text = "Ah, je vois... Eh bien, je peux arranger ça : l'un des officiers de Stuyvesant est mon beau-père.";
			link.l1 = "Allez, tu ne le regretteras pas. וcoute, tu sais pourquoi on m'a arrêté ? Je n'y comprends rien...";
			link.l1.go = "Step_F2_5";
		break;
 		case "Step_F2_5":
			dialog.text = "Des pirates, tous autant qu'ils sont... Et toi, tu as l'air d'un corsaire.";
			link.l1 = "Je n'ai pas discuté, donc... Bon, écoute, ne perds pas de temps, mets-toi au travail. Sinon, on va me pendre pour rien, c'est certain.";
			link.l1.go = "Step_F2_6";
		break;
 		case "Step_F2_6":
			dialog.text = "D'accord. Je te promets que les papiers de ton navire parviendront à Stuyvesant. Ensuite, prie pour que ces papiers soient convaincants\n"+
				          "Enfin, mon beau-père prendra lui-même quelques pièces dans tes affaires. דa ne te dérange pas ?";
			link.l1 = "Bien sמr que non ! Allez, ne perds pas de temps, mon ami.";
			link.l1.go = "Step_F2_7";
		break;
 		case "Step_F2_7":
			LAi_SetPlayerType(pchar);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 10);
            DialogExit();
			DoQuestCheckDelay("Fr2Letter_intoPrison_3", 10);
		break;
 		case "Step_F2_8":
			dialog.text = "Ne faites pas l'enfant, capitaine, tout a été éclairci\n"+
				          "L'un de mes officiers a décidé de fouiller votre cabine. Nous avons trouvé une lettre de marque française, lu le journal de bord, et tout s'est mis en place\n"+
						  "C'est exact, vous êtes bien un flibustier au service de la France. Je ne m'excuse pas, car c'était le règlement. Vous pouvez disposer, capitaine.";
			link.l1 = "Ravi de l'apprendre. Ce serait bête de mourir pour rien.";
			link.l1.go = "Step_F2_9";
		break;
 		case "Step_F2_9":
			dialog.text = "Tout ce qu'on vous a confisqué vous sera rendu. Transmettez mes meilleurs vœux à Bertrand. Et soyez prudent sur le chemin du retour : il s'est passé un tas de choses près de l'île ces derniers temps.";
			link.l1 = "Quoi exactement, monsieur ?";
			link.l1.go = "Step_F2_10";
		break;
 		case "Step_F2_10":
			dialog.text = "Rien de bon, capitaine, rien de bon... Enfin, ça ne vous regarde pas. Adieu.";
			link.l1 = "Adieu, monsieur le gouverneur général.";
			link.l1.go = "exit";
			bDisableCharacterMenu = false; //открываем Ф2
			AddDialogExitQuestFunction("FrLine_HoverGoOnPrison");
		break;

 		case "Step_F2_12":
			dialog.text = "Jamais, moi, " + GetFullName(npchar) + ", corsaire espagnol, je ne me suis rendu à un ladrón ! J'ai coulé vingt navires dans les parages de Curaçao, alors vous ne m'intimiderez pas. Mieux vaut accepter la mort, mais garder son honneur !";
			link.l1 = "Eh bien, accepte la mort, si c'est ce que tu veux. J'ai appris tout ce qu'il me fallait...";
			link.l1.go = "Step_F2_13";
		break;
 		case "Step_F2_13":
			AddQuestRecord("Fra_Line_2_DelivLetter", "5");
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
			pchar.questTemp.State = "Fr2Letter_NiceResult";
			DialogExit();
		break;
//********************************* Похищение донны Анны. Квест №3 **********************************
 		case "Step_F3_1":
			dialog.text = "José est mort... Dieu m'est témoin, je ne voulais pas cela... Il a trouvé la lettre que je lui avais écrite et m'a enfermée ici...";
			link.l1 = "Je sais, señora, je l'ai deviné... Je vous demande de me suivre. Soyez prudente, madame...";
			link.l1.go = "Step_F3_2";
		break;
 		case "Step_F3_2":
			pchar.questTemp.State = "Fr3TakeAnna_HavanaOut";
			Pchar.quest.Fr3TakeAnna_DelivShip.win_condition.l1 = "EnterToSea";
			Pchar.quest.Fr3TakeAnna_DelivShip.win_condition = "Fr3TakeAnna_DelivShip";
			LAi_SetActorType(npchar);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;
//********************************* Проблемы донны Анны. Квест №5 **********************************
 		case "Step_F5_1":
			dialog.text = "Oui, c'est cela, "+ GetSexPhrase("señor","señorita") +". Doña de Leyva est en danger de mort ! Le gouverneur général de La Havane, Francisco Oregón y Gascón, a mené l'enquête sur cette affaire et a découvert toutes les circonstances de la fuite de doña Anna à Tortuga\n"+
				          "Tout ce qu'il a appris, il l'a raconté aux parents de don José assassiné. Or, don José Ramírez de Leyva descend d'une ancienne famille castillane. Selon les lois de l'honneur, doña Anna doit payer son infidélité.";
			link.l1 = "Ils ne peuvent pas atteindre Tortuga...";
    		link.l1.go = "Step_F5_2";
		break;
 		case "Step_F5_2":
			dialog.text = "Vous vous trompez, "+ GetSexPhrase("señor","señorita") +". Les cousins de don José sont déjà arrivés ici. Je les ai vus, et croyez-moi, ce sont de vrais coupe-jarrets. Quand un noble castillan se venge, il ne craint pas le diable en personne !";
			link.l1 = "Eh bien, je ne leur promets pas le diable, mais je peux en avoir l'air moi-même. Pouvez-vous me dire oם les trouver ?";
    		link.l1.go = "Step_F5_3";
		break;
 		case "Step_F5_3":
			dialog.text = "Hier, ils sont partis dans la jungle, ils ne sont pas en ville. Apparemment, ils nouent des contacts avec des contrebandiers pour entrer secrètement à Tortuga.";
			link.l1 = "Il faut les intercepter dans la jungle ! S'ils réussissent à revenir en ville à temps, je devrai affronter toute la garnison espagnole. Merci, chère Inés. Je n'ai jamais cru à l'amitié entre femmes, mais vous, une femme courageuse, m'avez convaincu du contraire. Adieu.";
    		link.l1.go = "exit";
			pchar.questTemp.State = "Fr5AnnaHant_SeekHoseBrothers";
			AddQuestRecord("Fra_Line_5_KillAnnaHanters", "3");
			AddQuestUserData("Fra_Line_5_KillAnnaHanters", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Fra_Line_5_KillAnnaHanters", "sSex1", GetSexPhrase("", "e"));

			npchar.LifeDay = 1; // уберём нпс
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			locations[FindLocation("Mayak10")].DisableEncounters = true; //энкаутеры закроем
			LAi_LocationDisableOfficersGen("Mayak10", true); //офицеров не пускать
			Pchar.quest.Fr5Anna_InShore.win_condition.l1 = "location";
			Pchar.quest.Fr5Anna_InShore.win_condition.l1.location = "Mayak10";
			Pchar.quest.Fr5Anna_InShore.win_condition = "Fr5Anna_InShore";
		break;
 		case "Step_F5_4":
			dialog.text = "Ouf, c'est très bien. Maintenant, doña Anna peut respirer...";
			link.l1 = "Je suppose que oui.";
    		link.l1.go = "exit";
		break;
//********************************* Вызволение Рока Бразильца. Квест №7 **********************************
 		case "Step_F7_1":
    		if (LAi_group_GetTarget(pchar) <= 0)
			{
				dialog.text = "Je suis heureuse et ravie, "+ GetSexPhrase("l'ami","ma petite") +". Mais je ne vous connais pas ; pourriez-vous me dire qui vous a envoyé ici ?";
				link.l1 =  "Nul autre que monsieur Bertrand d'Ogeron. Je suppose que vous savez qui c'est... Bon, maintenant, quittons cet endroit pour rejoindre le navire, on nous attend à Tortuga. Savez-vous tenir une arme ?";
    			link.l1.go = "Step_F7_2";
			}
			else
			{
				dialog.text = "Je suis très heureux...";
				link.l1 = "Nous parlerons plus tard, il faut d'abord régler leur compte à tous ceux qui sont ici...";
    			link.l1.go = "Step_F7_Late";
			}
		break;
 		case "Step_F7_2":
    		if (LAi_group_GetTarget(pchar) <= 0)
			{
				dialog.text = "Hélas, non. Les saints pères du coin m'ont brisé les bras...";
				link.l1 =  "C'est fâcheux... Alors suivez-moi de près : nous allons forcer le passage.";
    			link.l1.go = "Step_F7_3";
			}
			else
			{
				dialog.text = "Hélas, non...";
				link.l1 = "Nous parlerons plus tard, il faut d'abord régler leur compte à tous ceux qui sont ici !";
    			link.l1.go = "Step_F7_Late";
			}
		break;
 		case "Step_F7_3":
			dialog.text = "D'accord, comme vous voudrez. Je n'ai pas vraiment le choix...";
			link.l1 = "Alors en avant, corsaire ! Et ne traînez pas.";
    		link.l1.go = "Step_F7_4";
		break;
 		case "Step_F7_4":
			bDisableFastReload = false;
			AddQuestRecord("Fra_Line_7_RockBras", "2");
			AddQuestUserData("Fra_Line_7_RockBras", "sSex", GetSexPhrase("", "e"));
			Pchar.quest.Fr7RockBras_DelivShip.win_condition.l1 = "location";
			Pchar.quest.Fr7RockBras_DelivShip.win_condition.l1.location = "Cuba1";
			Pchar.quest.Fr7RockBras_DelivShip.win_condition = "Fr7RockBras_DelivShip";
			LAi_SetActorType(npchar);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_ActorFollowEverywhere(npchar, "", -1);
			DialogExit();
		break;
 		case "Step_F7_5":
			dialog.text = "וcoutez, je veux vous remercier de m'avoir sauvé la vie. Je ne peux pas vous aider avec de l'argent : je dois verser une somme considérable au trésor de la France\n"+
				          "Mais je peux vous donner quelque chose qui compte bien plus que l'argent pour un corsaire.";
			link.l1 = "Je ne refuserai pas, d'autant que je suis très curieux...";
    		link.l1.go = "Step_F7_6";
		break;
		case "Step_F7_6":
            dialog.text = "Bref, écoutez-moi bien... Il y a un souterrain sous la ville de Fort-de-France, à la Martinique. Dans ce souterrain, j'ai caché une chose très précieuse et très utile pour nous autres..\n"+
				          "Je ne vous dirai pas ce que c'est, vous verrez bien... En tout cas, je vous donne ce que vous trouverez là-bas.";
			link.l1 = "Un cadeau inhabituel, c'est le moins qu'on puisse dire... Enfin, à cheval donné, on ne regarde pas les dents. Adieu, Rock, rétablissez-vous bien...";
            link.l1.go = "Step_F7_7";
        break;
		case "Step_F7_7":
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload3", "none", "", "", "", 6.0);
			DeleteAttribute(npchar, "RebirthPhantom");
         	npchar.LifeDay = 0; // уберём нпс
			pchar.GenQuestRandItem.FortFrance_Dungeon = true;
			pchar.GenQuestRandItem.FortFrance_Dungeon.randitem3 = "cirass5";
			DialogExit();
        break;
 		case "Step_F7_8":
			dialog.text = "Vous arrivez trop tard... Ils m'ont torturé toute la semaine... Maintenant... plus rien ne peut me sauver... euh-euh...";
			link.l1 = "Bon sang, il est mort !";
    		link.l1.go = "Step_F7_9";
		break;
 		case "Step_F7_9":
			bDisableFastReload = true;
			LAi_KillCharacter(npchar);
			DeleteAttribute(npchar, "RebirthPhantom");
         	npchar.LifeDay = 0; // уберём нпс
			pchar.questTemp.State = "Fr7RockBras_RockIsAgony";
			DialogExit();
		break;
 		case "Step_F7_Late":
			bDisableFastReload = true;
			LAi_ActorWaitDialog(npchar, pchar);
			DialogExit();
		break;
//********************************* Объехать трёх корсаров. Квест №8 **********************************
        case "Step_F8_1":
            dialog.text = "Oui, ce salaud ne peut pas venir me chercher lui-même, alors il envoie ses sbires ! J'espère que ton âme, avant d'aller en enfer, aura le temps de lui murmurer ce qui attend tous ceux qui osent...";
            link.l1 = "Assez. Au travail, capitaine...";
            link.l1.go = "Step_F8_2";
        break;
 		case "Step_F8_2":
			chrDisableReloadToLocation = true;
			LocatorReloadEnterDisable("PortRoyal_tavern", "reload2_back", true);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "CanFightCurLocation");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

	}
}
