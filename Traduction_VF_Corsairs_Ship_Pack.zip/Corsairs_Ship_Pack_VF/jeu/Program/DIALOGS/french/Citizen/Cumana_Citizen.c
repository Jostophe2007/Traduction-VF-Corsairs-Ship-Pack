// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			// Квест Изабеллы, розыск кэпа брига "wounds"
			if (CheckAttribute(pchar, "RomanticQuest.ShipToCumana"))
			{
                dialog.Text = "Je vous écoute.";
    			link.l1 = "Le navire « Cinq Plaies du Christ » est-il entré au port ?";
    			Link.l1.go = "RomanticQuest_1";
			}
		break;
		// ==> Квест Изабеллы, розыск кэпа брига "wounds"
		case "RomanticQuest_1":
			dialog.Text = "Oui, monsieur, il est entré. Il a été pris dans une tempête, a perdu son grand mât et a dמ revenir ici.";
			link.l1 = "Oם puis-je trouver le capitaine ?";
			Link.l1.go = "RomanticQuest_2";
		break;
		case "RomanticQuest_2":
			dialog.Text = "Il m'a semblé qu'il était allé à la taverne tout récemment.";
			link.l1 = "Merci.";
			Link.l1.go = "exit";
			DeleteAttribute(pchar, "RomanticQuest.ShipToCumana");
			Pchar.RomanticQuest.ShipToCumanaTavenrn = true;
			ref rChar = GetCharacter(NPC_GenerateCharacter("BrigCaptain", "shipowner_13", "man", "man", 20, SPAIN, -1, false));
            rChar.Dialog.Filename = "Quest\Isabella\BrigCaptain.c";
            FreeSitLocator("Cumana_tavern", "sit3");  // очистим стул
			ChangeCharacterAddressGroup(rChar, "Cumana_tavern", "sit", "sit3");
            LAi_SetSitType(rChar);
		break;
		// <== Квест Изабеллы, розыск кэпа брига "wounds"
		case "info":
        // заменить на описание неких НПС, по квестам
			dialog.text = "Est-ce que je travaille pour un réseau d'agents secrets de "+NationNameGenitive(sti(NPChar.nation))+" ?";
			link.l1 = "Très bien... Au revoir, alors.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;

		case "town":
        // заменить на описание как пройти, по квестам
			dialog.text = "Que voulez-vous que je vous dise ? Je ne sais pas. Je ne sais rien.";

            link.l1 = "Quel imbécile ! Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Alors, une autre question";
			link.l2.go = "new question";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
