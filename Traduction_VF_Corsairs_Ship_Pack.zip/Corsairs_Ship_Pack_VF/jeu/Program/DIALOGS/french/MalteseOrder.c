#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06

void ProcessDialogEvent()
{
	int license_price = sti(PChar.rank) * (2500) * (0.01 * (120 - GetSummonSkillFromName(PChar, SKILL_COMMERCE)));;
	int license_expires = rand(2);

	ref NPChar, sld;
	aref Link, NextDiag, arCapBase, arCapLocal;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// вызов диалога по городам <--
	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06
	if (!CheckAttribute(NPChar, "Portman")) NPChar.Portman = 0;

	int i, cn, iOfficer;
	ref chref, compref;
	ref rRealShip;
	string attrL, sTitle, sCapitainId, s1;
	string sColony;
	string offtype = "";

	String sLastSpeakDate = LastSpeakDate();

	bool ok, ok2;
	int iTest = FindColony(NPChar.City); // город магазина
	ref rColony;

	attrL = Dialog.CurrentNode;

	if(HasSubStr(attrL, "OfficerStockManBack_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.OfficerToStoreIdx = strcut(attrL, i+1, strlen(attrL)-1); // индех в конце
		Dialog.CurrentNode = "OfficerStockManBack";
	}

	if(HasSubStr(attrL, "OfficerStockSel_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.OfficerToStoreIdx = GetPassenger(PChar, sti(strcut(attrL, i+1, strlen(attrL)-1))); // индех в конце
		Dialog.CurrentNode = "OfficerStock_2";
	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "First time":
			NextDiag.TempNode = "First time";
			if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";
				dialog.text = "Mes salutations, " + GetAddress_Form(NPChar) + ". Il me semble que nous ne nous connaissons pas. Je suis "  + GetFullName(npchar)+ " – gouverneur du Chapitre de l'invasion espagnole des îles des Caraïbes.";
				Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je suis " + GetFullName(PChar) + ", capitaine du navire '" + PChar.ship.name + "'.";
			}
			else
			{
				dialog.text = LinkRandPhrase("Mes salutations, " + GetAddress_Form(NPChar) + ". Vous êtes ici pour affaires ?",
									"Bonjour, " + GetFullName(Pchar) + ". J'ai été informé de votre arrivée.",
									"Ah, capitaine " + GetFullName(Pchar) + ". Qu'est-ce qui vous amène ?");
				Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je voudrais vous parler.";
			}
			if (NPChar.id == "Wh_Jim")
			{
				dialog.text = "Capitaine ! Content de vous revoir. Qu'est-ce qui vous amène aujourd'hui ?";
				Link.l1 = "Bonjour, " + npchar.name + ". Nous avons quelque chose à discuter.";

			}
			Link.l1.go = "node_2";
		break;
		case "node_2":
			// Церковный генератор 1

			dialog.text = "Très bien. Je suis à votre service, " + GetFullName(PChar) + ".";

			Link.l3 = "Je veux laisser un officier ici pour qu'il s'entraîne.";
			Link.l3.go = "ShipStock_1";

			if (sti(NPChar.Portman) > 0)
			{
				Link.l4 = "Je veux reprendre mon officier.";
				Link.l4.go = "OfficerStockReturn_1";
			}

			Link.l15 = "Merci. Au revoir.";
			Link.l15.go = "exit";
		break;
		case "again":
			dialog.text = "Autre chose ?";

			Link.l3 = "Je veux laisser un officier ici pour qu'il s'entraîne.";
			Link.l3.go = "ShipStock_1";

			if (sti(NPChar.Portman) > 0)
			{
				Link.l4 = "Je veux reprendre mon officier.";
				Link.l4.go = "OfficerStockReturn_1";
			}

			Link.l15 = "Rien d'autre. Au revoir.";
			Link.l15.go = "exit";
		break;

		//<--------------------------- инфа по базе квествых кэпов

		case "ShipStock_1":
			dialog.text = "Qui voulez-vous laisser, exactement ?";
			for(i=0; i<GetPassengersQuantity(pchar); i++)
			{
				iOfficer = GetPassenger(pchar, i);
				sld = GetCharacter(iOfficer);
				if (CheckAttribute(sld, "prisoned") && (sld.prisoned == true)) continue;
				if (!GetRemovable(sld)) continue;
				attrL = "l"+i;
				Link.(attrL)	= "L'officier " + GetFullName(sld) + ".";
				Link.(attrL).go = "OfficerStockSel_" + i;
			}
			Link.l99 = "Merci, ce n'est pas nécessaire.";
			Link.l99.go = "exit";
		break;

		case "OfficerStock_2":
			chref = GetCharacter(sti(NPChar.OfficerToStoreIdx));

			if (!CheckAttribute(chref, "quest.officertype")) offtype = "Polyvalent";
			else offtype = XI_ConvertString(chref.quest.officertype);
			dialog.Text = "Vous avez choisi " + GetFullName(chref)+", spécialité : "+offtype+".";
			Link.l1 = "Oui. דa me convient.";
			Link.l1.go = "OfficerStock_3";
			Link.l99 = "Non, j'ai changé d'avis.";
			Link.l99.go = "exit";
		break;

		case "OfficerStock_3":
			chref = GetCharacter(sti(NPChar.OfficerToStoreIdx));
			chref.OfficerInStockMan = NPChar.id;
			// Warship 22.03.09 fix Не перенеслось с КВЛ 1.2.3
			chref.OfficerInStockMan.AltDate = GetQuestBookDataDigit(); // для печати
			SaveCurrentNpcQuestDateParam(chref, "OfficerInStockMan.Date"); // для расчёта
			RemovePassenger(pchar, chref);

			chref.location = "";
			chref.location.group = "";
			chref.location.locator = "";
			NPChar.Portman	= sti(NPChar.Portman) + 1;
			pchar.OfficerInStock = sti(pchar.OfficerInStock) + 1;//разобраться - что это. не могу найти, где оно используется.

			dialog.text = "D'accord. Vous pourrez le récupérer quand vous en aurez besoin.";
			Link.l1 = "Merci.";
			Link.l1.go = "again";
		break;

		case "OfficerStockReturn_1":
			dialog.text = "Qui reprenez-vous, exactement ?";
			cn = 1;
			for(i=1; i<MAX_CHARACTERS; i++)
			{
				makeref(chref, Characters[i]);
				if (CheckAttribute(chref, "OfficerInStockMan"))
				{
					if (chref.OfficerInStockMan == NPChar.id)
					{
						attrL = "l"+cn;
						if (!CheckAttribute(chref, "quest.officertype")) offtype = "Polyvalent";
						else offtype = XI_ConvertString(chref.quest.officertype);
						Link.(attrL)	= "L'officier " + GetFullName(chref) + ", spécialité : "+offtype+".";
						Link.(attrL).go = "OfficerStockManBack_" + i;
						cn++;
					}
				}
			}

			Link.l99 = "Non, j'ai changé d'avis.";
			Link.l99.go = "exit";
		break;
	  	case "OfficerStockManBack":
			chref = GetCharacter(sti(NPChar.OfficerToStoreIdx));
			dialog.Text = "Vous reprenez l'officier " + GetFullName(chref)+" ?";
			Link.l1 = "Oui.";
			Link.l1.go = "OfficerStockManBack2";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "OfficerStockManBack2":
			chref = GetCharacter(sti(NPChar.OfficerToStoreIdx));
			dialog.text = GetFullName(chref)+" a rejoint votre navire, capitaine.";
			Link.l1 = "Merci.";
			Link.l1.go = "again";
			DeleteAttribute(chref, "OfficerInStockMan");
			AddPassenger(pchar, chref, false);

			NPChar.Portman	= sti(NPChar.Portman) - 1;
			pchar.OfficerInStock = sti(pchar.OfficerInStock) - 1;

		break;

	}
}

void DelBakSkill(ref _compref)
{
	DelBakSkillAttr(pchar);
	ClearCharacterExpRate(pchar);
	RefreshCharacterSkillExpRate(pchar);
	SetEnergyToCharacter(pchar);

	DelBakSkillAttr(_compref);
	ClearCharacterExpRate(_compref);
	RefreshCharacterSkillExpRate(_compref);
	SetEnergyToCharacter(_compref);
}
