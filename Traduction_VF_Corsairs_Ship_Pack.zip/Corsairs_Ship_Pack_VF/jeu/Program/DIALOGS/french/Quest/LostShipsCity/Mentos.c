
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = LinkRandPhrase("Ha, une nouvelle tête ! Je suppose que la tempête ne nous empêchera pas de faire connaissance. Je suis " + GetFullName(npchar) + ", je fais partie de la milice locale.",
						"Alors, vous êtes la seule personne à avoir survécu à la tempête ? Eh bien, bienvenue dans la Cité. Je m'appelle " + GetFullName(npchar) + ", je travaille dans la police.",
						"Une nouvelle tête, à ce que je vois ! Bienvenue, comme on dit, mais vous pouvez déjà oublier la tempête. Je m'appelle " + GetFullName(npchar) + ", je suis inscrit dans la milice locale.");
					link.l1 = RandPhraseSimple("Salut, moi, c'est " + GetFullName(pchar) + ". C'est quoi, cette police ?", "Salutations. Je m'appelle " + GetFullName(pchar) + ". Et c'est quoi, cette milice ?");
					link.l1.go = "FT_1";
				}
				else
				{
					dialog.text = LinkRandPhrase("Ha, une nouvelle tête ! Eh bien, bonjour, et faisons connaissance. Je suis " + GetFullName(npchar) + ", je suis membre de la milice locale.",
						"Alors, vous êtes la seule personne à avoir survécu à la tempête ? Eh bien, bienvenue dans la Cité. Je m'appelle " + GetFullName(npchar) + ", je travaille dans la police.",
						"Une nouvelle tête dans la Cité, à ce que je vois ! Bienvenue, comme on dit. Je m'appelle " + GetFullName(npchar) + ", je suis inscrit dans la milice locale.");
					link.l1 = RandPhraseSimple("Salut, moi, c'est " + GetFullName(pchar) + ". C'est quoi, cette police ?", "Salutations. Je m'appelle " + GetFullName(pchar) + ". Et c'est quoi, cette milice ?");
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = LinkRandPhrase("Il y a un crime quelque part ?", "Que se passe-t-il, il y a une émeute dans la Cité ?", "Il s'est passé quelque chose ?");
				link.l1 = RandPhraseSimple("וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?", "J'ai besoin de trouver quelqu'un. Vous l'avez vu dans les parages ?");
				link.l1.go = "SeekCitizen";
				link.l2 = RandPhraseSimple("Je voudrais vous poser une question.", "J'ai une question à vous poser.");
				link.l2.go = "int_quests";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && npchar.id == "Ment_6" && CheckAttribute(pchar, "questTemp.LSC.additional.powder") && sti(pchar.questTemp.LSC.additional.powder))
				{
					link.l8 = "וcoutez, j'ai vraiment besoin de poudre et d'armes. L'amiral ne veut rien me donner, mais j'en ai vraiment besoin...";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew" && npchar.id == "Ment_6" && !CheckAttribute(pchar, "questTemp.LSC.crew.ment_6"))
				{
					link.l8 = "Salut, mon ami. Eh bien, le moment est venu. Nous partons.";
					link.l8.go = "SeekCrew";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew" && npchar.id == "Ment_6" && CheckAttribute(pchar, "questTemp.LSC.crew.ment_6"))
				{
					link.l8 = "Alors, comment allez-vous ?";
					link.l8.go = "SeekCrew2";
				}
				if (pchar.questTemp.LSC == "MechanicIsArrest_toResidence" && npchar.id == "Ment_6" && CheckAttribute(npchar, "quest.LSCofficer"))
				{
					link.l8 = "Eh bien, l'ami, on dirait que le moment est venu.";
					link.l8.go = "SeekCrew3";
				}
				if (pchar.questTemp.LSC == "MechanicIsArrest_toResidence" && npchar.id == "Ment_6" && !CheckAttribute(npchar, "quest.LSCofficer"))
				{
					link.l8 = "L'ami, nous avions parlé du fait que vous vouliez quitter cette île maudite avec moi.";
					link.l8.go = "SeekCrew4";
				}
				link.l10 = "Non, ça va.";
				link.l10.go = "exit";
			}
		break;

		case "FT_1":
			dialog.text = LinkRandPhrase("La police assure l'ordre et le respect de la Loi par les citoyens de la Cité.",
				"La police surveille tout ce qui se passe ici. En somme, c'est elle, le pouvoir dans la Cité...",
				"Dans les villes ordinaires, il y a un gouverneur avec une garnison de soldats. Ici, le gouverneur, c'est notre amiral, et la garnison, c'est nous, les miliciens.")
			link.l1 = RandPhraseSimple("Je vois...", "Maintenant, je comprends, merci pour l'explication.");
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez " + GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = LinkRandPhrase("Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "citoyenne") +".", "Parlez, je vous écoute.", "Je vous écoute attentivement.");
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = LinkRandPhrase("וcoutez, quelle est cette île ?", "Quelle est donc cette île étrange ?", "וcoutez, l'ami, quelle est cette île ?");
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = LinkRandPhrase("Vous avez essayé de partir d'ici ?", "Il y a peut-être un moyen de quitter cet endroit ?", "Vous avez essayé de vous enfuir d'ici en bateau ?");
				link.l2.go = "ansewer_2";
			}
			link.l10 = RandPhraseSimple("Pas de questions. Désolé, l'ami...", "Quelque chose m'est sorti de la tête, j'ai oublié...");
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = LinkRandPhrase("Cette île s'appelle la Cité des navires abandonnés. Vous faites désormais partie des citoyens de cette Cité.",
				"C'est un endroit très inhabituel, n'est-ce pas ? L'île s'appelle la Cité des navires abandonnés. Maintenant, vous allez vivre avec nous.",
				"C'est la Cité des navires abandonnés. Toute l'île est constituée de navires qui ont été amenés ici par un destin bien cruel...");
			link.l1 = RandPhraseSimple("Je vois.", "Je vois...");
			link.l1.go = "exit";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = LinkRandPhrase("Pourquoi donc ? On mange à notre faim, ici...",
				"C'est interdit par la Loi. En fait, personnellement, je n'en ai pas envie, tout me convient ici.",
				"Vous savez, tout ce que je voulais obtenir de la vie est ici. Pourquoi chercherais-je une vie meilleure ?");
			link.l1 = RandPhraseSimple("Je vois.", "Je vois...");
			link.l1.go = "exit";
			NextDiag.(NodePrevName).l2 = true;
		break;
		//диалог перед боем на Веласко
		case "OffNarval":
			dialog.text = LinkRandPhrase("Nous sommes prêts à attaquer, menez-nous.", "Nous vous attendions déjà... Allez, ne traînez pas.", "Envoyons ces « Narvals » en enfer !");
			link.l1 = "Bien !";
			link.l1.go = "exit";
		break;
		//диалог после боем на Веласко
		case "AffterFightN":
			dialog.text = LinkRandPhrase("On a réussi !", "Héhé, l'amiral sera content...", "דa y est, le clan des Narvals n'existe plus !");
			link.l1 = "Je ne vous retiens pas plus longtemps.";
			link.l1.go = "exit";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Pourquoi avez-vous besoin de poudre et d'armes ? Ici, c'est un poids mort.",
				"Tout est réglé.",
				"Je m'occupe de tout.",
                "Oh, vous êtes bien agaçant.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Ici, oui. Mais il y a des endroits oם ces marchandises sont nécessaires.",
				"Parfait !",
                "Ah, oui.",
				"Ouais.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Par exemple, en mer ?";
			link.l1 = "Hum... eh bien, disons.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Je vois... Vous savez, je vous aiderai si vous m'emmenez avec vous.";
			link.l1 = "D'accord, d'autant que j'ai justement besoin de bonne compagnie.";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Bien. Je peux faire sortir discrètement pas mal de choses de l'entrepכt... Combien d'armes et de poudre vous faut-il, et oם voulez-vous qu'on les livre ?";
			link.l1 = "Il me faut 10 quintaux de poudre et 50 armes. Il faut faire porter ça à la barque San Gabriel.";
			link.l1.go = "SeekGoods_4";
		break;
		case "SeekGoods_4":
			dialog.text = "D'accord, je m'en charge. N'oubliez pas de me prendre avec vous ensuite !";
			link.l1 = "Aucun risque, c'est dans mon intérêt, l'ami. Au revoir.";
			link.l1.go = "exit";
			AddCharacterGoods(pchar, GOOD_WEAPON, 50);
			AddCharacterGoods(pchar, GOOD_POWDER, 200);
			AddQuestRecord("ISS_MainLine", "58");
			pchar.questTemp.LSC.additional.powder = false;
		break;
		//поиски команды на корвет
		case "SeekCrew":
			dialog.text = "Parfait ! Quand ?";
			link.l1 = "Je suis justement en train de former l'équipage du navire, alors soyez le bienvenu. Allez au San Gabriel. Henrik Wedeker, qui s'y trouve, vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Oui, ce serait bien. Mais vous savez, je vais attendre ici pour l'instant.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "L'amiral est très mécontent de vous. Je pense qu'il s'apprête à vous tuer. Alors, je vais attendre ici et voir ce qui se passe. Si vous avez des ennuis avec Chad, je pourrai vous couvrir.";
			link.l1 = "Oui, ce serait bien. Vous savez, l'ami, quand tout ça sera fini, je veux vous prendre à bord de mon navire comme officier. Je vous garantis une solde mensuelle.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Proposition intéressante. Je crois que je vais accepter. Bon, en attendant, il faut faire en sorte que « tout ça » se termine bien pour nous.";
			link.l1 = "C'est ça ! Bon, attendez ici.";
			link.l1.go = "exit";
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			pchar.questTemp.LSC.crew.ment_6 = true;
			npchar.quest.LSCofficer = true;
			AddQuestRecord("ISS_MainLine", "61");
		break;

		case "SeekCrew2":
			dialog.text = "Tout va bien pour l'instant, mais gardez les yeux ouverts ! S'il y a une bagarre, je viendrai à la rescousse.";
			link.l1 = "Parfait ! Merci.";
			link.l1.go = "exit";
		break;

		case "SeekCrew3":
			dialog.text = "Je suis prêt. Entrez dans la résidence, j'y viendrai un peu plus tard.";
			link.l1 = "Entendu !";
			link.l1.go = "exit";
		break;

		case "SeekCrew4":
			dialog.text = "Oui, c'est vrai. Et qu'en dites-vous ?";
			link.l1 = "Si vous m'aidez maintenant, je vous prendrai comme officier avec une solde mensuelle convenable. Nous partons, et j'ai besoin de votre aide tout de suite.";
			link.l1.go = "SeekCrew4_1";
		break;
		case "SeekCrew4_1":
			dialog.text = "J'accepte. Que puis-je faire pour vous ?";
			link.l1 = "Apparemment, il va y avoir du grabuge sérieux à la résidence. Si vous vous rangez de mon cכté, c'est d'accord.";
			link.l1.go = "SeekCrew4_2";
		break;
		case "SeekCrew4_2":
			dialog.text = "Hum, l'amiral est un combattant redoutable. Mais je suis prêt à prendre le risque !";
			link.l1 = "Parfait ! Alors, mettons-nous d'accord : attendez ici, mais si une bagarre éclate, entrez dans la mêlée immédiatement.";
			link.l1.go = "SeekCrew4_3";
		break;
		case "SeekCrew4_3":
			dialog.text = "D'accord. Je ne vous laisserai pas tomber, capitaine.";
			link.l1 = "Eh bien, c'est gentil...";
			link.l1.go = "exit";
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			ref ment = CharacterFromID("Ment_5");
			ment.model = "officer_8";
			FaceMaker(ment);
			npchar.quest.LSCofficer = true;
			AddQuestRecord("ISS_MainLine", "68");
		break;
		//финальный разговор мента_6 перед посадкой на корвет
		case "MentOffIsLife":
			dialog.text = "Eh bien, on dirait qu'on s'en est sortis.";
			link.l1 = "Oui... Merci, mon ami, vous avez tenu parole. Je vous dois une fière chandelle.";
			link.l1.go = "MentOffIsLife_1";
		break;
		case "MentOffIsLife_1":
			Npchar.quest.OfficerPrice = (rand(4)+1)*1000;
			dialog.text = "Pas de problème. Je suis prêt à rejoindre votre équipage en tant qu'officier. Que me proposez-vous ?";
			link.l1 = "L'ami, ce n'est pas le moment de marchander. Fixez vous-même votre solde, on verra ça plus tard...";
			link.l1.go = "MentOffIsLife_2";
		break;
		case "MentOffIsLife_2":
			dialog.text = "D'accord, comme vous voudrez...";
			link.l1 = "וcoutez, l'amiral a arrêté le Mécanicien. Vous savez oם il est ?";
			link.l1.go = "MentOffIsLife_3";
		break;
		case "MentOffIsLife_3":
			dialog.text = "En prison, bien sמr. On l'a envoyé au Tartarus.";
			link.l1 = "Merci, vous m'avez beaucoup aidé. Maintenant, allez au San Gabriel, il y a moyen de rejoindre mon navire. Les autres citoyens de la Cité qui voulaient partir avec moi y sont déjà. Attendez-y Wedeker et moi.";
			link.l1.go = "MentOffIsLife_4";
		break;
		case "MentOffIsLife_4":
			dialog.text = "Bien, capitaine. Je vais juste jeter un coup d'œil par ici...";
			link.l1 = "D'accord, mais ne soyez pas en retard pour le navire.";
			link.l1.go = "exit_hire";
		break;
		case "exit_hire":
			DialogExit();
			DeleteAttribute(npchar, "city");
			chrDisableReloadToLocation = false;
			AddQuestRecord("ISS_MainLine", "66");
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			npchar.greeting = "Gr_questOfficer";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			npchar.HalfImmortal = true;  // Контузия
			npchar.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = true;

		break;
	}
	NextDiag.PrevNode = NodeName;
}
