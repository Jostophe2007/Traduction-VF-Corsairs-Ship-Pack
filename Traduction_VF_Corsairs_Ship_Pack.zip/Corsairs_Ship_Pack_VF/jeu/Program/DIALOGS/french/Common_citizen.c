// boal 25/04/04 общий диалог горожан
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Citizen\" + NPChar.City + "_Citizen.c";
    if (!HasCityDialogFile("Citizen", NPChar.City, "_Citizen.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Citizen\DefaultCity_Citizen.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Citizen\DefaultCity_Citizen.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}    // вызов диалога по городам <--
    ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 16/06/06
    int iTest, iTemp;
    iTest = FindColony(NPChar.City); // город
    ref rColony;
    string sTemp, sCity;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}

	String attrLoc = Dialog.CurrentNode;

	if(HasSubStr(attrLoc, "RumourAboutOwners_"))
	{
		NPChar.RumourOwnerType = FindStringAfterChar(attrLoc, "_");
		Dialog.CurrentNode = "RumourAboutOwners_TakeRumour";
	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
            LAi_group_Attack(NPChar, Pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":

            /*if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
				dialog.text = RandPhraseSimple("Spy? Guards!!!!!", "Guard! There is an enemy in the city!");
				link.l1 = "Shut up! I'm already leaving.";
				link.l1.go = "fight";
				break;
			}*/

			if (sti(NPChar.nation) == PIRATE)
			{
				if (sti(rColony.HeroOwn) == true) // наш горожанин
				{
				    dialog.text = RandPhraseSimple("Le bruit court que vous êtes le maître de cette ville, "+ GetSexPhrase("monsieur", "mademoiselle") +".", "Quelle belle rencontre : le chef de la ville en personne vient me poser une question.");
					link.l1 = RandPhraseSimple("J'ai changé d'avis. Bonne chance !", "Je regarde juste la ville. Au revoir.");
					link.l1.go = "exit";
					link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
					link.l2.go = "quests";//(перессылка в файл города)
					if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
		            {
		                if (Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)].id == Npchar.id)
		                {
							link.l3 = RandPhraseSimple("Je veux parler de questions financières.", "א propos de finances...");
							link.l3.go = "LoanForAll";//(перессылка в кредитный генератор)
						}
					}
					break;
				}
				else
				{ // пираты, не наши
				    dialog.text = RandPhraseSimple("Que voulez-vous ? Passez votre chemin.", "Arrêtez de me barrer la route, dégagez.");
					link.l1 = RandPhraseSimple("Vous savez quoi ? N'aboyez pas !", "Modérez votre ardeur. Sinon, je vais vite la refroidir !");
					link.l1.go = "exit";
					link.l2 = RandPhraseSimple("Je veux vous demander quelque chose.", "Un instant d'attention, juste une question.");
					link.l2.go = "quests";//(перессылка в файл города)
					if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
		            {
		                if (Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)].id == Npchar.id)
		                {
							link.l3 = RandPhraseSimple("Je veux parler de questions financières.", "א propos de finances...");
							link.l3.go = "LoanForAll";//(перессылка в кредитный генератор)
						}
					}
					break;
				}
			}
            if(NPChar.quest.meeting == "0")
			{
				NPChar.quest.meeting = "1";

                // homo 05/08/06
				dialog.Text =NPCharRepPhrase(npchar,
                                LinkRandPhrase("Je m'appelle ", "Je m'appelle ", "Vous pouvez m'appeler ")
                                +GetFullName(npchar)
                                +LinkRandPhrase(". Que voulez-vous ?", ". Je ne vous avais jamais vu."
                                +" Qui êtes-vous ?", ". Qui êtes-vous, et que me voulez-vous ?"),

        		                LinkRandPhrase("Mes salutations, " + GetAddress_Form(NPChar) + ". Je m'appelle " + GetFullName(npchar) + ". Comment vous appelez-vous ?",
                                 "Bonjour, " + GetAddress_Form(NPChar) + " ! Je suis " + GetFullName(npchar) + ". Puis-je connaître votre nom ?",
                                 "Oui, " + GetAddress_Form(NPChar) + ". Que vouliez-vous ? Au fait, je m'appelle " + GetFullName(npchar) + ". Et vous ?"));

				Link.l1 = pcharrepphrase(
                                LinkRandPhrase ("Mille tonnerres ! ", "Mille diables ! ", "Que le diable t'emporte ! ") + "Oui, je suis le capitaine "+ getFullName(Pchar)+ LinkRandPhrase(", vous n'avez pas entendu parler de moi"+NPCharSexPhrase(NPChar, ", canaille ?", "?"), " et "+ GetSexPhrase("le plus célèbre pirate", "la plus célèbre pirate") +" de ces eaux ! ", " et que je sois damné si ce n'est pas vrai !"),
 								LinkRandPhrase("Je suis le capitaine " + getFullName(Pchar) + ".", "Je m'appelle " + GetFullName(Pchar) +".", "Appelez-moi capitaine " + GetFullName(Pchar) +"."));

                //LinkRandPhrase("I am " + GetFullName(Pchar) + ", Captain.", "My name is " + GetFullName(Pchar) + ".", "You can call me Captain " + GetFullName(Pchar));				
				Link.l1.go = "Meeting";
				
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue6") && pchar.questTemp.AnjelikaTichPrologue6 == "ATP6")	//Sinistra Пролог Анжелики Шарп
				{					
					dialog.text = LinkRandPhrase("Toute la ville ne parle aujourd'hui que d'une seule nouvelle : la tentative ratée de prendre notre colonie.", "Non, mais quelle bravoure, quand même : ils ont décidé d'attaquer les fortifications de notre ville ! Et à quoi s'attendaient-ils ? Je pense que cette aventure était vouée à l'échec dès qu'elle est née dans la tête de celui qui l'a imaginée.", "Je l'avoue, quand la fusillade a commencé, j'ai paniqué.");
					link.l1 = "";
					link.l1.go = "exit";
					LAi_CharacterDisableDialog(npchar);
				}
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP" && pchar.questTemp.AnjelikaTichPrologue2 == "ATP2")	//Sinistra Пролог Анжелики Шарп
				{
					pchar.ATP_MirJitId = npchar.id;
					
					int Phrase2;
					Phrase2 = rand(1);
					if (Phrase2 == 0)
					{
						dialog.text = "Bonjour, Angelica, je suis si content de vous voir. Il fait un temps parfait pour une promenade aujourd'hui !";
						link.l1 = "Bonjour, " + npchar.name+", moi aussi, je suis contente de vous voir.";
						link.l1.go = "ATP_0_1";
					break;
					}
					if (Phrase2 == 1)
					{
						dialog.text = "Angelica, comme vous êtes belle. C'est un plaisir de vous regarder. Je vais au marché faire mes provisions.";
						link.l1 = "Merci du compliment, " + npchar.name+". Bonne chance à vous !";
						link.l1.go = "ATP_0_1";
					break;
					}
				}
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")	//Sinistra Пролог Анжелики Шарп
				{
					pchar.ATP_MirJitId = npchar.id;
					
					int Phrase;
					Phrase = rand(3);
					if (Phrase == 0)
					{
						dialog.text = "Bonjour, Angelica, Rebecca, je suis si content de vous voir. Il fait un temps parfait pour une promenade aujourd'hui !";
						link.l1 = "Bonjour, " + npchar.name+", nous aussi, nous sommes contentes de vous voir.";
						link.l1.go = "ATP_1";
					break;
					}
					if (Phrase == 1)
					{
						dialog.text = "Deux beautés, Angelica et Rebecca. C'est un plaisir de vous regarder. Je vais au marché faire mes provisions.";
						link.l1 = "Bonjour, " + npchar.name+".";
						link.l1.go = "ATP_2";
					break;
					}
					if (Phrase == 2)
					{
						dialog.text = ""+ NPCharSexPhrase(NPChar, "Bonjour, jeunes filles.", "Angelica, bonjour. Becky ! Vous êtes devenue une vraie femme d'intérieur, je suis content de vous voir.") +"";
						link.l1 = ""+ NPCharSexPhrase(NPChar, "Je crois que nous nous sommes déjà croisés ce matin, ou alors c'était hier à midi.", "Bonjour, " + npchar.name+".") +"";
						link.l1.go = "ATP_3";
					break;
					}
					if (Phrase == 3)
					{
						dialog.text = "Une journée magnifique, vous ne trouvez pas ? Une brise légère a un peu rabattu la chaleur habituelle.";
						link.l1 = "Hier matin, c'était pareil, et à midi le soleil brמlait déjà l'herbe.";
						link.l1.go = "ATP_4";
					break;
					}
				}
			}
			else
			{
				if(rand(5) == 1 && NPChar.sex == "woman" && !CheckAttribute(NPChar, "CitizenFindItem.NoQuest") && !CheckAttribute(PChar, "GenQuest.CitizenFindItem.StartQuest") && CheckAttribute(NPChar, "City"))
				{
					dialog.Text = "Capitaine, pourriez-vous m'aider pour quelque chose ?";
					link.l1 = LinkRandPhrase("Désolé, non. J'ai très peu de temps en ce moment.", "Désolé, je ne peux pas. Les affaires...", "Non, je ne peux pas. J'ai beaucoup de choses importantes à faire en ce moment.");
					link.l1.go = "CitizenFindItem_NoQuest";
					link.l2 = LinkRandPhrase("Bien sמr. De quoi s'agit-il ?", "Oui, je vais vous aider. Dites-moi de quoi il s'agit...", "Racontez-moi cette affaire plus en détail...");
					link.l2.go = "CitizenFindItem_1";
					NextDiag.TempNode = "First time";
					break;
				}

				if(CheckAttribute(PChar, "GenQuest.CitizenFindItem.CitizenID") && PChar.GenQuest.CitizenFindItem.CitizenID == NPChar.ID && CheckCharacterItem(PChar, "DOjeronRing"))
				{
					dialog.Text = "Oui, capitaine, je vous écoute.";
					link.l1 = NPChar.name + ", j'ai retrouvé votre alliance.";
					link.l1.go = "CitizenFindItem_Complete_1";
					break;
				}

				link.l1 = PCharRepPhrase("Je voulais en savoir un peu plus sur cette ville !", "Je voulais apprendre quelque chose sur la ville.");
				link.l1.go = "new question";
 				link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
				if (CheckCharacterItem(pchar, "CaptainBook"))
				{
					if((pchar.questTemp.different.GiveShipLetters.city == npchar.city) && CheckAttribute(pchar, "questTemp.different.GiveShipLetters"))
					{
						link.l2.go = "ShipLetters_7";// генератор  
					}
					else
					{
						link.l2.go = "quests";
					}
				}
				else
				{
					link.l2.go = "quests";//(перессылка в файл города)
				}
				if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
	            {
	                if (Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)].id == Npchar.id)
	                {
						link.l3 = RandPhraseSimple("Je veux parler de questions financières.", "א propos de finances...");
						link.l3.go = "LoanForAll";//(перессылка в кредитный генератор)
					}
				}
				// --> квестовый генератор мэра, поиск шпиёна на улице. eddy
				if (CheckAttribute(pchar, "GenQuest.SeekSpy.City") && pchar.location == (npchar.city + "_town"))
	            {
					link.l4 = NPCharSexPhrase(npchar, LinkRandPhrase("Halte ! Dites-moi immédiatement qui vous êtes ?! Je cherche un espion ennemi pour le compte du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
						"Halte immédiatement ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
						"Halte, l'ami ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville."),
						LinkRandPhrase("Femme, halte ! Dites-moi immédiatement qui vous êtes ?! Je cherche un espion ennemi pour le compte du gouverneur " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
						"Femme, je dois vous retenir ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
						"Attendez, ma belle ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville..."));
					link.l4.go = "SitySpy";
				}
				// <-- квестовый генератор мэра, поиск шпиёна на улице

				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskPeople") && !CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.AskedPeople") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_town")
	            {
					link.l5 = LinkRandPhrase("Vous savez", "Vous savez", "Vous savez quelque chose sur le fait") + " que l'église du coin a été volée récemment ?");
					link.l5.go = "Citiz_GenQuest_Church_2_1";
				}
				// <-- Квестовый генератор священника. Квест №2.

                dialog.Text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Oh, c'est vous, " + GetFullName(Pchar)
                        +" "+ GetSexPhrase("- vieille canaille", "- tête brמlée") +"", "Ravi de vous voir, "+ GetSexPhrase("vieux frère", "ma belle") +" "
                        + Pchar.name, "Oh, je vois "+ GetSexPhrase("le capitaine en personne", "la capitaine en personne") +" "
                         +GetFullName(Pchar))
                                        +LinkRandPhrase(". Je vous croyais déjà six pieds sous terre ! ", ". Et comme d'habitude,"+ GetSexPhrase("ivre mort. ", "déjà un peu pompette. ") +"", " Et toujours en liberté, à ce que je vois ! ")
                                        +LinkRandPhrase("Alors, dites-moi, que voulez-vous ?", " Que voulez-vous cette fois ?", "Vous venez encore m'importuner pour rien ?"),
                                        LinkRandPhrase(TimeGreeting() + ", capitaine !", "Bonjour, "+GetAddress_Form(NPChar)+" ", "Salutations, capitaine ")+GetFullName(Pchar)
                                        +LinkRandPhrase(". Que peut bien vouloir de moi "+ GetSexPhrase("un homme aussi respectable", "une fille aussi courageuse") +" ?", ". Pourquoi êtes-vous venu ?", ". Que voulez-vous savoir cette fois ?")

                                        ),

                        PCharRepPhrase(LinkRandPhrase("Bonjour, capitaine ", "Bonjour, oh, c'est vous, "+GetAddress_Form(NPChar)+" ", "Ah, capitaine ")
                                        +GetFullName(Pchar)
                                        +LinkRandPhrase(", je pensais qu'on ne se reverrait pas : ",
                                                         ", je ne peux pas dire que je suis content de vous voir, mais", " - toujours en vie, à ce que je vois, dommage, hein...")
                                        +LinkRandPhrase(" pourquoi êtes-vous ici ?", " pourquoi êtes-vous venu ?", " en quoi puis-je vous être"+NPCharSexPhrase(NPChar, " utile ?", " utile ?")),
                                        LinkRandPhrase(TimeGreeting() + ", le capitaine " + GetFullName(Pchar) + ". En quoi puis-je vous aider ?",
                                        "Oh, capitaine " + GetFullName(Pchar) + " ! Que voulez-vous savoir cette fois ?",
                                        "Bonjour, " + GetAddress_Form(NPChar) + " " + Pchar.lastname + ". Vous vouliez quelque chose ?"))
                                        );
	   			link.l6 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien, je vais à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
				link.l6.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "ShipLetters_7":
			dialog.text = "Quelles sont vos questions ?";
			link.l1 = "Le nom qui figure dans ces papiers vous dit-il quelque chose ?";
			link.l1.go = "ShipLetters_8";
		break;

		case "ShipLetters_8":
			dialog.text = LinkRandPhrase("Les papiers inconnus, ça ne m'intéresse pas, et puis je ne sais pas lire. Allez voir l'usurier, on dit qu'il a appris les lettres du diable.",
										"Je ne vois pas du tout de quoi vous parlez ; demandez plutכt à d'autres habitants de cette ville, capitaine " + GetFullName(Pchar) + ".",
										"Je ne sais même pas comment vous aider, capitaine " + GetFullName(Pchar) + ". Essayez de vous adresser à l'usurier, il saura peut-être ?");
			link.l1 = "Je suivrai volontiers votre conseil !";
			link.l1.go = "exit";
		break;

		case "Meeting":
		    dialog.Text  = NPCharRepPhrase(npchar, LinkRandPhrase("Vous ne mentez pas, capitaine " + GetFullName(Pchar)+" ?",
                                                                    "Alors, " + PChar.name+" ?",
                                                                    "Je me souviendrai de vous, " + GetFullName(Pchar)+".")
                                                                     + " Maintenant, dites-moi, je vous prie, ce qu'il vous faut ?",
                                                    LinkRandPhrase("Ravi de vous rencontrer, capitaine " + PChar.name,
                                                                    "Ravi de vous rencontrer, " + GetAddress_Form(NPChar) + " " + PChar.lastname,
                                                                     "C'est un plaisir, capitaine " + PChar.name) + ". Mais vous ne vouliez sans doute pas seulement connaître mon nom, n'est-ce pas ?");

            link.l1 = PCharRepPhrase("Je voulais apprendre quelque chose sur cette ville !", "Je voulais apprendre quelque chose sur la ville.");
			link.l1.go = "new question";
            Link.l2 = RandPhraseSimple("J'ai une question à vous poser.", "J'ai besoin de renseignements.");
			if (CheckCharacterItem(pchar, "CaptainBook"))
			{
				if((pchar.questTemp.different.GiveShipLetters.city == npchar.city) && CheckAttribute(pchar, "questTemp.different.GiveShipLetters"))
				{
					link.l2.go = "ShipLetters_7";// генератор  
				}
				else
				{
					Link.l2.go = "quests";
				}
			}
			else
			{
					link.l2.go = "quests";//(перессылка в файл города)
			}
			if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") && !CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
            {
                if (Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)].id == Npchar.id)
                {
					link.l3 = RandPhraseSimple("Je veux parler de questions financières.", "א propos de finances...");
					link.l3.go = "LoanForAll";//(перессылка в кредитный генератор)
				}
			}
			// --> квестовый генератор мэра, поиск шпиёна на улице. eddy
			if (CheckAttribute(pchar, "GenQuest.SeekSpy.City") && pchar.location == (npchar.city + "_town"))
	        {
				link.l4 = NPCharSexPhrase(npchar, LinkRandPhrase("Halte ! Dites-moi immédiatement qui vous êtes ?! Je cherche un espion ennemi pour le compte du gouverneur de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
					"Halte immédiatement ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
					"Halte, l'ami ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville."),
					LinkRandPhrase("Femme, halte ! Dites-moi immédiatement qui vous êtes ?! Je cherche un espion ennemi pour le compte du gouverneur " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " !",
					"Femme, je dois vous retenir ! J'agis dans l'intérêt de la ville de " + XI_ConvertString("Colony"+characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].city+"Gen") + " – pour le compte du gouverneur. Je cherche un agent ennemi en ville.",
					"Attendez, ma belle ! Le gouverneur d'ici, " + characters[GetCharacterIndex(pchar.GenQuest.SeekSpy.MayorId)].lastname + " tient vraiment à trouver un espion en ville..."));
				link.l4.go = "SitySpy";
			}
			// <-- квестовый генератор мэра, поиск шпиёна на улице
			// Квестовый генератор священника. Квест №2. Warship -->
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskPeople") && !CheckAttribute(NPChar, "GenQuest.ChurchQuest_2.AskedPeople") && NPChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_town")
	        {
				link.l5 = LinkRandPhrase("Vous savez", "Vous savez quelque chose sur le fait", "Vous savez quelque chose sur le fait") + " que l'église du coin a été volée récemment ?");
				link.l5.go = "Citiz_GenQuest_Church_2_1";
			}
			// <-- Квестовый генератор священника. Квест №2.

			Link.l6 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien, je vais à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			Link.l6.go = "exit";
		break;

		case "new question":
            dialog.text = NPCharRepPhrase(npchar,
		                PCharRepPhrase(LinkRandPhrase("Oh, oui, je serais ravi"+NPCharSexPhrase(NPChar, " ", "e ")+"de vous demander ce que vous voulez boire.", "Vous aimez bavarder, capitaine ? Eh bien, moi aussi... Surtout autour d'une chope de rhum.", "Oui, " + PChar.name + " ?"),
                                        LinkRandPhrase("Eh bien, que voulez-vous encore ?", "Je vois, capitaine "+PChar.name+", vous avez envie de bavarder ? ", "Vous m'avez épuisé avec vos questions, capitaine, il vaudrait mieux boire du rhum.")),
		                PCharRepPhrase(LinkRandPhrase("Que vouliez-vous savoir, "+ GetAddress_Form(NPChar) + " ?", "Je vous écoute, capitaine.", "Je dois y aller, alors posez vite vos questions, capitaine."),
                                        LinkRandPhrase("Je suis toujours heureux d'avoir une compagnie agréable, " + GetAddress_Form(NPChar) + " " + PChar.lastname + ".",
                                                        "Oui, " + GetAddress_Form(NPChar) + " ?",
                                                        "Vous aimez bavarder, capitaine ? Eh bien, moi aussi..."))
                            );

            // homo 25/06/06
			link.l1 = LinkRandPhrase ("Quelles histoires raconte-t-on à la taverne, par ici ?",
                                    "Quoi de neuf dans le coin ?",
                                    "Comment va la vie à terre ?");
			link.l1.go = "rumours_citizen";
			link.l2 = LinkRandPhrase("Pouvez-vous m'indiquer le chemin ?", "Je n'arrive pas à trouver mon chemin...", "Indiquez-moi le chemin...");
			link.l2.go = "town";  //(перессылка в файл города)
			if(Rand(1)==0)
			{
				link.l3 = LinkRandPhrase("Je voudrais savoir ce qu'on dit d'une certaine personne, par ici.", "Savez-vous ce qu'on dit d'une certaine personne, par ici ?", "J'aimerais savoir quelque chose sur les habitants.");
				if(rand(1) == 0 || PChar.location == "LaVega_Town" || PChar.location == "PuertoPrincipe_town"
				|| PChar.location == "Pirates_town" || PChar.location == "Panama_town" || !CheckAttribute(NPChar, "City"))
				{
					link.l3.go = "info"; //(перессылка в файл города)
				}
				else
				{
					link.l3.go = "RumourAboutOwners"; // Warship. Сделал по-другому - у жителя каждого города будет свой диалог.
				}
			}
			else
			{
				link.l3 = "Parlez-moi de votre colonie.";
				link.l3.go = "colony";
			}
            link.l4 = RandPhraseSimple("J'ai une affaire importante !", "J'ai une affaire pour vous.");
			link.l4.go = "quests";  //(перессылка в файл города)
			link.l5 = PCharRepPhrase(RandPhraseSimple("Vous m'avez entendu, je m'en vais.", "Non, rien, je vais à la taverne."),
                                        RandPhraseSimple("D'accord, rien. Bonne chance !", "Je regarde juste la ville. Au revoir."));
			link.l5.go = "exit";
		break;

		case "RumourAboutOwners":
			Dialog.Text = "Sur lequel des habitants voulez-vous en savoir plus ?";
			if(GetCharacterIndex(NPChar.city + "_Mayor") != -1)
			{
				link.l1 = "Sur le gouverneur.";
				link.l1.go = "RumourAboutOwners_Mayor";
			}
			if(GetCharacterIndex(NPChar.city + "_TavernKeeper") != -1)
			{
				link.l2 = "Sur le tavernier d'ici.";
				link.l2.go = "RumourAboutOwners_TavernKeeper";
			}
			if(GetCharacterIndex(NPChar.city + "_ShipYarder") != -1)
			{
				link.l3 = "Sur le propriétaire du chantier naval.";
				link.l3.go = "RumourAboutOwners_ShipYarder";
			}
			if(GetCharacterIndex(NPChar.city + "_Trader") != -1)
			{
				link.l4 = "Sur le propriétaire du magasin d'ici.";
				link.l4.go = "RumourAboutOwners_Trader";
			}
			link.l9 = "Sur personne. Oubliez.";
			link.l9.go = "exit";
			break;

		case "RumourAboutOwners_TakeRumour":
			sTemp = sRumourAboutOwners_CityRumour(NPChar.City, NPChar.RumourOwnerType);
			Dialog.Text = sTemp;
			link.l1 = "Merci.";
			link.l1.go = "exit";
			// Здесь можно делать проверка по квестам, какой слух выпал
			DeleteAttribute(PChar, "QuestTemp.RumoursAboutOwners");
			break;

		case "colony":
			dialog.text = LinkRandPhrase("Pour être honnête, je n'en sais pas grand-chose. Mais je peux vous dire certaines choses.",
                           "Qu'est-ce qui vous intéresse dans notre colonie ?", "Je vous en prie. Que voulez-vous entendre ?");
            switch(Rand(1))
			{
				case 0:
					link.l1 = "Quel genre de ville est-ce ?";
					link.l1.go = "colony_town";
				break;

				case 1:
					link.l1 = "Que savez-vous du fort qui protège la ville ?";
					link.l1.go = "fort";
				break;
            }
			link.l2 = "Parlons d'autre chose.";
			link.l2.go = "new question";
		break;
	  // to_do
		case "colony_town":
            dialog.text = "Oh, vous vous moquez de moi ? Ou vous plaisantez ? Regardez dans le coin droit de l'écran.";
			link.l1 = "C'est vrai, je suis bête.";
		    link.l1.go = "exit";
		break;

		case "fort":
            dialog.text = "Je n'en sais rien.";
			link.l1 = "Désolé.";
		    link.l1.go = "exit";
		break;
		//============================ Генератор мэра. Квест по розыску шпиона на улице ============================
		case "SitySpy":
			dialog.text = NPCStringReactionRepeat(NPCharSexPhrase(npchar, "Et alors, qu'est-ce que j'ai à voir là-dedans ? Je suis d'ici !", "Et alors, qu'est-ce que j'ai à voir là-dedans ? J'habite cette ville, et je ne veux rien savoir de ce genre !"),
				NPCharSexPhrase(npchar, "Qu'est-ce que vous me voulez encore ? Je vous ai déjà dit que je n'étais pas un espion !", "Je vous ai déjà dit que j'étais d'ici !"),
				NPCharSexPhrase(npchar, "Combien de fois faudra-t-il le répéter ? Laissez-moi tranquille, je suis d'ici !", "Pourquoi m'importunez-vous encore avec vos questions idiotes ?"),
				NPCharSexPhrase(npchar, "Quoi, encore ?! דa dépasse les bornes !!!", "וcoutez, laissez-moi enfin tranquille, je vous en prie !!"), "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Qui peut confirmer vos dires ?", "Oh, pardon, je vous ai déjà posé la question...",
                      "Désolé, il y a tellement de monde...", "D'accord, d'accord...", npchar, Dialog.CurrentNode);
		    link.l1.go = DialogGoNodeRepeat("SitySpy_1", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
			// ==> выбираем подтверждателя
			int num = FindNearCharacters(npchar, 20.0, -1.0, -1.0, 1.0, false, true);
			if(num > 0)
			{
				for(i = 0; i < num; i++)
				{
					iTemp = chrFindNearCharacters[i].index;
					if (CheckAttribute(&characters[iTemp], "CityType"))
					{
						if(characters[iTemp].CityType == "soldier" || characters[iTemp].CityType == "citizen")
						{
							break;
						}
					}
				}
				pchar.GenQuest.SeekSpy.Idx = chrFindNearCharacters[i].index; //индекс выбранного
				pchar.GenQuest.SeekSpy.Type = characters[sti(pchar.GenQuest.SeekSpy.Idx)].chr_ai.type; //тип кто помог
				pchar.GenQuest.SeekSpy.BaseIdx = npchar.index; //индекс
			}
		break;
		case "SitySpy_1":
			if (sti(pchar.GenQuest.SeekSpy.Idx) == -1 || sti(pchar.GenQuest.SeekSpy.Idx) == 1) //на всякий случай
			{
				dialog.text = "Mais n'importe qui ! וcoutez, pourquoi m'importunez-vous ?! Si vous avez un problème, allons voir le gouverneur, et nous tirerons tout ça au clair !",
				link.l1 = "Euh... Inutile peut-être de le déranger pour rien. Je vous crois...";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "N'importe qui dans cette ville ! " + NPCharSexPhrase(npchar, GetFullName(&characters[sti(pchar.GenQuest.SeekSpy.Idx)]) + " peut en témoigner, heureusement " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.Idx)], "il", "elle") + " est à deux pas d'ici.",
				"Oh, mon Dieu, au moins, " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.Idx)], GetAddress_FormToNPC(NPChar) + " " + characters[sti(pchar.GenQuest.SeekSpy.Idx)].lastname, GetFullName(&characters[sti(pchar.GenQuest.SeekSpy.Idx)])) + " peut-être.");
			link.l1 = "Eh bien, je vous écoute...";
		    link.l1.go = "SitySpy_2";
			sld = &characters[sti(pchar.GenQuest.SeekSpy.Idx)];
			sld.dialog.currentnode = "SeekSpy_Checking";
			pchar.GenQuest.SeekSpy.time = 4.0; //время на подбежать
			if (sld.chr_ai.type == "merchant") pchar.GenQuest.SeekSpy.time = 0.0; //мерчант базарит сразу
            LAi_SetActorTypeNoGroup(sld);
		break;
		case "SitySpy_2":
			sld = &characters[sti(pchar.GenQuest.SeekSpy.Idx)];
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorTurnToCharacter(npchar, sld);
			LAi_ActorDialog(sld, pchar, "", stf(pchar.GenQuest.SeekSpy.time), 0);
			DialogExit();
		break;
		//=================== ноды квеста мэра. поиск шпиона на улице, опрос свидетеля ==================
		case "SeekSpy_Checking":
			dialog.text = "Oui, je vous le confirme, " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)], "c'est bien quelqu'un du coin.", "c'est bien quelqu'un du coin.");
			link.l1 = RandPhraseSimple("J'ai compris. Merci de votre aide.", "Tout est clair. Merci de votre aide.");
			link.l1.go = "SeekSpy_Checking_1";
		break;
		case "SeekSpy_Checking_1":
			switch (pchar.GenQuest.SeekSpy.Type)
			{
				case "guardian": LAi_SetGuardianTypeNoGroup(npchar); break;
				case "patrol":   LAi_SetPatrolTypeNoGroup(npchar);   break;
				case "citizen":  LAi_SetCitizenTypeNoGroup(npchar);  break;
				case "merchant": LAi_SetMerchantTypeNoGroup(npchar); break;
			}
			LAi_SetCitizenTypeNoGroup(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)]);
			NextDiag.CurrentNode = "First Time";
			DialogExit();
		break;

		// Мини квест на поиск обручального кольца -->
		case "CitizenFindItem_1":
			dialog.text = "Le fait est que je me promenais hier hors de la ville et que j'ai perdu mon alliance..."+ GetSexPhrase("Capitaine, pourriez-vous la chercher ?", "Ma fille, aidez-moi à la retrouver, je vous en prie !") +"";
			link.l1 = "Bien sמr, "+ GetSexPhrase("Bien sמr ! Pour une si jolie femme, je suis prêt à tout !", "Je vais vous aider. L'וglise enseigne d'aider son prochain.") +"";
			link.l1.go = "CitizenFindItem_2";
			link.l2 = LinkRandPhrase("Non, je ne peux pas. Désolé. J'ai beaucoup à faire.", "Désolé, je ne peux pas. Je viens de me rappeler qu'il me reste une affaire à terminer...", "J'ai très peu de temps en ce moment, je ne peux donc pas vous aider...");
			link.l2.go = "CitizenFindItem_NoQuest";
			break;

		case "CitizenFindItem_2":
			dialog.text = ""+ GetSexPhrase("Capitaine", "Ma fille") +", c'est parfait ! Retrouvez cette bague, je vous en prie, car dans " + sti(NPChar.LifeDay) + " jours, mon mari rentre, et je ne voudrais pas qu'il me voie sans mon alliance.";
			link.l1 = RandPhraseSimple("Oם disiez-vous l'avoir perdue ?", "Alors, oם l'avez-vous perdue ?");
			link.l1.go = "CitizenFindItem_3";
		break;

		case "CitizenFindItem_3":
			dialog.text = "Juste à la sortie des portes de la ville...";
			link.l1 = "Bon, alors je vais chercher...";
			link.l1.go = "CitizenFindItem_4";
		break;

		case "CitizenFindItem_4":
			dialog.text = "Oui, allez-y. Et dépêchez-vous. N'oubliez pas, il ne vous reste que " + sti(NPChar.LifeDay) + " jour(s).";
			link.l1 = "Je m'en souviens.";
			link.l1.go = "exit";
			PChar.GenQuest.CitizenFindItem.StartQuest = true;
			PChar.GenQuest.CitizenFindItem.City = NPChar.City;
			PChar.GenQuest.CitizenFindItem.CitizenID = NPChar.ID;

			sCity = NPChar.City + "_ExitTown";

			//sTemp = "randitem" + (rand(1)+1); // Т.е. может получиться, что его вовсе найти не удастся. И это гуд.
			sTemp = "randitem1";
			Log_TestInfo("The ring will be in the locator - " + sTemp);
			PChar.GenQuest.CitizenFindItem.ItemLocator = sTemp;
			ChangeItemDescribe("DOjeronRing", "itmdescr_WeddingRing");
			items[FindItem("DOjeronRing")].Name = "itmname_WeddingRing";
			items[FindItem("DOjeronRing")].City = XI_ConvertString("Colony" + NPChar.City + "Gen");
			SetFunctionTimerCondition("CitizenFindItemMiniQuest_Timer", 0, 0, sti(NPChar.LifeDay), false);
			PChar.GenQuestRandItem.(sCity).(sTemp) = "DOjeronRing";
			SetGameModeCondition("CitizenFindItemMiniQuest_CheckItem");
		break;

		case "CitizenFindItem_NoQuest":
			DialogExit();
			NextDiag.CurrentNode = "First time";
			NPChar.CitizenFindItem.NoQuest = true; // Эта девушка квест больше не даст
		break;

		case "CitizenFindItem_Complete_1":
			dialog.text = ""+ GetSexPhrase("Capitaine", "Ma fille") +" ! Je suis si contente ! Comment puis-je vous remercier ?";
			link.l1 = "Non, merci, je l'ai fait de façon tout à fait désintéressée.";
			link.l1.go = "CitizenFindItem_Complete_2";
			link.l2 = "Une ou deux centaines de piastres ne seraient pas de refus...";
			link.l2.go = "CitizenFindItem_Complete_3";
			RemoveItems(PChar, "DOjeronRing", 1);
			DeleteAttribute(PChar, "GenQuest.CitizenFindItem");
			NPChar.CitizenFindItem.NoQuest = true;
			PChar.Quest.CitizenFindItemMiniQuest_Timer.over = "yes";
			BackItemDescribe("DOjeronRing");
			items[FindItem("DOjeronRing")].Name = "itmname_DOjeronRing";
			DeleteAttribute(&items[FindItem("DOjeronRing")], "City");
		break;

		case "CitizenFindItem_Complete_2":
			dialog.text = "Ah, "+ GetSexPhrase("capitaine, quelle personne merveilleuse vous êtes", "ma fille, vous êtes si noble") +" ! Je prierai pour vous à l'église, c'est certain ! Au revoir...";
			link.l1 = "Au revoir, " + npchar.name + ".";
			link.l1.go = "exit";
			ChangeCharacterReputation(PChar, 1);
			AddCharacterExpToSkill(PChar, "Leadership", 10);
			AddCharacterExpToSkill(PChar, "Fortune", 10);
		break;

		case "CitizenFindItem_Complete_3":
			iTemp = (rand(3)+1)*50;
			dialog.text = "Oh oui, bien sמr. Voici " + FindRussianMoneyString(iTemp) + ". C'est tout ce que j'ai. Prenez-les... Et au revoir.";
			link.l1 = "Au revoir, " + GetFullName(NPChar) + ".";
			link.l1.go = "exit";
			AddMoneyToCharacter(PChar, iTemp);
		break;
		// <-- Мини квест на поиск обручального кольца

		//=================== ноды квеста священника. поиск грабителей (квест №2)==================
		case "Citiz_GenQuest_Church_2_1":
			if(rand(3) != 1)
			{
				dialog.text = LinkRandPhrase("Non, je ne sais rien à ce sujet.", "Je ne sais rien sur cette question.", "Je ne sais rien.");
					link.l1 = LinkRandPhrase("D'accord, bien.", "D'accord, merci.", "D'accord, désolé.");
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Je ne sais rien à ce sujet, mais vous pouvez demander aux habitués de la taverne : ils vous diront sמrement quelque chose.", "Je ne peux rien vous dire, demandez plutכt à quelqu'un à la taverne.", "Je ne sais rien de précis, mais j'ai entendu qu'on en parlait à la taverne.");
				link.l1 = "Merci quand même.";
				link.l1.go = "exit";
			}

			NPChar.GenQuest.ChurchQuest_2.AskedPeople = true;
		break;

		//замечение по обнажённому оружию
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand " + GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		
		//Sinistra Пролог Анжелика Тич
		case "ATP_0_0":
			DialogExit();
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetCitizenType(sld);
			LAi_CharacterDisableDialog(sld);
			
			sld = CharacterFromID("AT_pr_Rebekka")
			LAi_SetActorType(sld);
			LAi_ActorFollow(sld, pchar, "", -1);
		break;
		
		case "ATP_0_1":
			DialogExit();
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetCitizenType(sld);
			LAi_CharacterDisableDialog(sld);
		break;
		
		case "ATP_1":
			DialogExit();
			StartInstantDialog("AT_pr_Rebekka", "Rebekka_s_mirnymi_jitelyami_1", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "ATP_1_1":
			dialog.text = "Merci, mais je vais bien, je continue mon chemin, bonne chance à vous !");
			link.l1 = "Bonne chance à vous aussi !";
			link.l1.go = "ATP_0_0";
		break;
		
		case "ATP_2":
			DialogExit();
			StartInstantDialog("AT_pr_Rebekka", "Rebekka_s_mirnymi_jitelyami_2", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "ATP_2_1":
			dialog.text = "Prenez soin de vous !");
			link.l1 = "Bonne journée !";
			link.l1.go = "ATP_0_0";
		break;
		
		case "ATP_3":
			DialogExit();
			StartInstantDialog("AT_pr_Rebekka", "Rebekka_s_mirnymi_jitelyami_3", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "ATP_3_1":
			dialog.text = "Bonne chance à vous !");
			link.l1 = "Merci !";
			link.l1.go = "ATP_0_0";
		break;
		
		case "ATP_4":
			DialogExit();
			StartInstantDialog("AT_pr_Rebekka", "Rebekka_s_mirnymi_jitelyami_4", "Quest\AngelikaTichLine\MechtySbyvautsya.c");
			
			sld = CharacterFromID(pchar.ATP_MirJitId)
			LAi_SetActorType(sld);
			LAi_ActorTurnToCharacter(sld, pchar);
		break;
		
		case "ATP_4_1":
			dialog.text = "Oui, oui. Votre sœur a tout à fait raison.");
			link.l1 = "Eh bien, très bien.";
			link.l1.go = "ATP_0_0";
		break;

	}
}
