
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Ah, alors c'est toi qui fais partie des derniers citoyens arrivés ? Eh bien, bienvenue.";
				link.l1 = "Merci. Je m'appelle " + GetFullName(pchar) + ".";
				link.l1.go = "FT_1";
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = "Bonjour. Vous vouliez quelque chose ?";
				link.l1 = "J'ai besoin d'argent.";
				link.l1.go = "GiveMoney";
				link.l10 = "Non, je passais juste te voir.";
				link.l10.go = "Exit";
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "וcoutez, nous avons à parler sérieusement. Je recrute un équipage.";
					link.l8.go = "SeekCrew";
				}
			}

			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FT_1":
			dialog.text = "Enchanté. Et moi, je m'appelle Augusto Brahms. Faisons connaissance.";
			link.l1 = "D'accord.";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Si tu as besoin d'argent, viens me voir, je pourrai te dépanner.";
			link.l1 = "Parfait, je m'en souviendrai...";
			link.l1.go = "Exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = "Toi, "+ GetSexPhrase("l'ami", "ma petite") +", tu ne sais pas à qui tu t'es frotté ! Et maintenant, c'en est fini de toi...";
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = "Hum, c'est drכle... Range ton arme.";
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand des hommes se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Je sais.",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "Assez, je suis fatiguée...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Tu le sais ? Comment ?",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			dialog.text = "Je sais beaucoup de choses... Tu veux que je parte avec toi ?";
			link.l1 = "Oui. Tu acceptes de rejoindre mon équipage ?";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Non. Je resterai ici jusqu'au dernier moment.";
			link.l1 = "D'ailleurs, il approche, ce dernier moment. Une tempête d'une force inouïe se dirige vers la Cité.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Je sais, mais je vais rester quand même. Je ne cours aucun danger.";
			link.l1 = "Tu es bizarre... Comme tu voudras.";
			link.l1.go = "exit";
		break;

		//занять бабла
		case "GiveMoney":
			if (CheckAttribute(npchar, "quest.loan"))
			{
				if (sti(npchar.quest.loan.qtyMoney) >= 1000000)
				{
					dialog.text = "Tu as complètement épuisé le quota qui t'était alloué. La ligne de crédit t'est fermée.";
					link.l1 = "Je vois.";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Je suis prêt à étudier ta demande.";
					link.l1 = "Parfait !";
					link.l1.go = "GiveMoney_1";
				}
			}
			else
			{
				dialog.text = "Bien. Tu connais les conditions auxquelles j'accorde des prêts ?";
				link.l1 = "Pas encore. Mais j'espère que tu vas me les dire.";
				link.l1.go = "GiveMoneyKn_1";
				npchar.quest.loan = true;
				npchar.quest.loan.qtyMoney = 0; //кол-во взятых денег
			}
		break;

		case "GiveMoneyKn_1":
			dialog.text = "Forcément. Donc, le montant du prêt est limité à un million de piastres. Tu peux me prendre n'importe quelle somme dans cette limite.";
			link.l1 = "Compris. Et à quel taux annuel ?";
			link.l1.go = "GiveMoneyKn_2";
		break;
		case "GiveMoneyKn_2":
			dialog.text = "Je n'ai pas de taux lié au temps. Tu dois simplement me rendre cinq fois la somme à la première demande de mon représentant attitré.";
			link.l1 = "Quoi ?!!!";
			link.l1.go = "GiveMoneyKn_3";
		break;
		case "GiveMoneyKn_3":
			dialog.text = "Tu as des problèmes d'audition ?";
			link.l1 = "Non, c'est juste que ça m'a un peu surpris...";
			link.l1.go = "GiveMoneyKn_4";
		break;
		case "GiveMoneyKn_4":
			dialog.text = "Je n'ai pas d'autres conditions, ni de préférences pour qui que ce soit.";
			link.l1 = "Hum, je vois...";
			link.l1.go = "GiveMoney_1";
		break;

		case "GiveMoney_1":
			dialog.text = "Combien d'argent veux-tu m'emprunter ?";
			Link.l1.edit = 4;
			Link.l1 = "";
			link.l1.go = "GiveMoney_2";
			Link.l2 = "Hum, je crois que je vais renoncer au prêt pour l'instant.";
			link.l2.go = "GiveMoney_disAgree";
		break;
		case "GiveMoney_2":
			iTemp = sti(dialogEditStrings[4]);
			if ((iTemp + sti(npchar.quest.loan.qtyMoney)) > 1000000)
			{
				dialog.text = "La somme demandée dépasse le quota fixé d'un million. Je peux te donner " + FindRussianMoneyString(1000000 - sti(npchar.quest.loan.qtyMoney)) + ", pas plus.";
				link.l1 = "Je vois...";
				link.l1.go = "exit";
			}
			else
			{
				if (iTemp <= 0)
				{
					dialog.text = "C'est une plaisanterie, hein ? Je ne te conseille pas de faire l'idiot avec moi.";
					link.l1 = "Hum, compris...";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Bien, je te remets la somme demandée avec plaisir.";
					link.l1 = "Excellent ! Tu m'as vraiment dépanné, l'ami.";
					link.l1.go = "GiveMoney_3";
					AddMoneyToCharacter(pchar, iTemp);
					npchar.quest.loan.qtyMoney = sti(npchar.quest.loan.qtyMoney) + iTemp;
				}
			}
		break;
		case "GiveMoney_3":
			dialog.text = "J'en suis ravi. J'espère que tu te souviendras des conditions de remboursement du prêt accordé. Quand le moment sera venu, tu devras rembourser cinq fois le montant de la dette. Et pour l'instant, cela fait " + FindRussianMoneyString(sti(npchar.quest.loan.qtyMoney) * 5) + ".";
			link.l1 = "Oui, je m'en souviens. Que se passe-t-il si je ne peux pas les rendre tout de suite ?";
			link.l1.go = "GiveMoney_4";
		break;
		case "GiveMoney_4":
			dialog.text = "Hum, il vaudrait mieux que tu les aies"+ GetSexPhrase(", l'ami", "") +". L'autre option, pour le dire gentiment, est très effrayante. Très...";
			link.l1 = "Compris. Bon, je vais essayer.";
			link.l1.go = "exit";
		break;
		case "GiveMoney_disAgree":
			dialog.text = "Eh bien, comme tu voudras. Réfléchis bien, tu changeras peut-être d'avis.";
			link.l1 = "Oui, bien sמr...";
			link.l1.go = "exit";
		break;
	}
}
