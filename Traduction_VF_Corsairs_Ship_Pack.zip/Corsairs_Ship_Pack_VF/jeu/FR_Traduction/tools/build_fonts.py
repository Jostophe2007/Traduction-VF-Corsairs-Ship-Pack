# -*- coding: utf-8 -*-
"""Generate French accented glyphs for the Storm-engine bitmap fonts.

Reads RESOURCE/INI/fonts_eng.ini + the font textures, composes accented glyphs
(é è ê ë à â ä ç î ï ô ö ù û ü œ « » + capitals) from the existing glyphs,
writes new textures  RESOURCE/Textures/fonts/<name> fr.tga.tx  and
RESOURCE/INI/fonts_fra.ini (the original files are never modified).

Letters that the INTERFACE_NORMAL font uses as icons (À É Ç ô ù ...) are also
exposed under Private-Use codepoints (U+E000 + latin-1 code); the French texts
are written with those codepoints (see frenc.py), so icons keep working.
"""
import os
import sys
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fontini import FontIni          # noqa: E402
from txtex import read_tx, write_tx  # noqa: E402
from frenc import PUA_MAP            # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
TEX_DIR = os.path.join(ROOT, 'RESOURCE', 'Textures')

LOWER = {  # char: (base, accent)
    'à': ('a', 'grave'), 'â': ('a', 'circ'), 'ä': ('a', 'diaer'),
    'ç': ('c', 'cedil'),
    'é': ('e', 'acute'), 'è': ('e', 'grave'), 'ê': ('e', 'circ'), 'ë': ('e', 'diaer'),
    'î': ('i', 'circ'), 'ï': ('i', 'diaer'),
    'ô': ('o', 'circ'), 'ö': ('o', 'diaer'),
    'ù': ('u', 'grave'), 'û': ('u', 'circ'), 'ü': ('u', 'diaer'),
}
UPPER = {
    'À': ('A', 'grave'), 'Â': ('A', 'circ'), 'Ä': ('A', 'diaer'),
    'Ç': ('C', 'cedil'),
    'É': ('E', 'acute'), 'È': ('E', 'grave'), 'Ê': ('E', 'circ'), 'Ë': ('E', 'diaer'),
    'Î': ('I', 'circ'), 'Ï': ('I', 'diaer'),
    'Ô': ('O', 'circ'), 'Ö': ('O', 'diaer'),
    'Ù': ('U', 'grave'), 'Û': ('U', 'circ'), 'Ü': ('U', 'diaer'),
}
LIG = {'œ': ('o', 'e'), 'Œ': ('O', 'E')}
QUOTES = {'«': '<', '»': '>'}
ALL_NEW = list(LOWER) + list(UPPER) + list(LIG) + list(QUOTES)

THR = 50  # alpha threshold for bbox


def premul(a):
    a = a.astype(np.float32)
    a[..., :3] *= a[..., 3:4] / 255.0
    return a


def unpremul(a):
    out = a.copy()
    al = np.maximum(out[..., 3:4], 1e-3)
    out[..., :3] = np.where(out[..., 3:4] > 0, out[..., :3] * 255.0 / al, 0)
    return np.clip(out + 0.5, 0, 255).astype(np.uint8)


def over(dst, src, x, y):
    """alpha-composite premultiplied float src onto premultiplied float dst at (x,y) (clipped)."""
    h, w = src.shape[:2]
    H, W = dst.shape[:2]
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0:
        return
    s = src[y0 - y:y1 - y, x0 - x:x1 - x]
    d = dst[y0:y1, x0:x1]
    a = s[..., 3:4] / 255.0
    dst[y0:y1, x0:x1] = s + d * (1 - a)


def bbox(alpha, thr=THR):
    ys, xs = np.nonzero(alpha > thr)
    if len(ys) == 0:
        return None
    return ys.min(), ys.max(), xs.min(), xs.max()


def resize_pm(img_pm, w, h):
    """resize premultiplied float RGBA with PIL (per channel, LANCZOS)."""
    w, h = max(1, int(round(w))), max(1, int(round(h)))
    chans = []
    for c in range(4):
        im = Image.fromarray(img_pm[..., c].astype(np.float32), 'F')
        chans.append(np.asarray(im.resize((w, h), Image.LANCZOS)))
    return np.clip(np.stack(chans, -1), 0, 255)


def shear_pm(img_pm, k):
    """horizontal shear (x' = x + k*(h-1-y)) -> leans right when k>0."""
    h, w = img_pm.shape[:2]
    extra = int(np.ceil(abs(k) * h)) + 1
    out = np.zeros((h, w + extra, 4), np.float32)
    for y in range(h):
        off = k * (h - 1 - y) if k > 0 else -k * y
        i = int(np.floor(off))
        f = off - i
        row = img_pm[y]
        out[y, i:i + w] += row * (1 - f)
        out[y, i + 1:i + 1 + w] += row * f
    return out


def crop_bbox(img_pm, thr=8):
    b = bbox(img_pm[..., 3], thr)
    if b is None:
        return img_pm[:1, :1] * 0
    y0, y1, x0, x1 = b
    return img_pm[y0:y1 + 1, x0:x1 + 1]


class TexFonts:
    """All glyph generation for one texture."""

    def __init__(self, tex_name, sections):
        self.tex_name = tex_name
        self.sections = sections
        self.prim = sections[0]
        path = os.path.join(TEX_DIR, tex_name.replace('\\', os.sep) + '.tx')
        self.t = read_tx(path)
        self.rgba = self.t['rgba']
        self.W, self.H = self.t['w'], self.t['h']
        self.xs = float(self.prim.prop('texture_xsize'))
        self.ys = float(self.prim.prop('texture_ysize'))
        self.sx = self.W / self.xs
        self.sy = self.H / self.ys
        self.chars = self.prim.chars

    # --- glyph access (pixel space) -----------------------------------
    def cell(self, c):
        x, y, w, h = self.chars[c]
        X0, Y0 = int(round(x * self.sx)), int(round(y * self.sy))
        X1, Y1 = int(round((x + w) * self.sx)), int(round((y + h) * self.sy))
        return premul(self.rgba[Y0:Y1, X0:X1])

    def has(self, c):
        return c in self.chars

    def metric_top(self, chars):
        tops = []
        for c in chars:
            if self.has(c):
                b = bbox(self.cell(c)[..., 3])
                if b:
                    tops.append(b[0])
        return int(np.median(tops)) if tops else None

    def metrics(self):
        self.cellh = int(round(self.chars['A'][3] * self.sy)) if self.has('A') else None
        self.x_top = self.metric_top(['x', 'z', 'v', 'u', 'n', 'm', 'r', 'w'])
        self.cap_top = self.metric_top(['E', 'H', 'T', 'N', 'M', 'I'])
        self.asc_top = self.metric_top(['l', 'd', 'b', 'h', 'k'])
        bl = []
        for c in ['x', 'n', 'm', 'u', 'z']:
            if self.has(c):
                b = bbox(self.cell(c)[..., 3])
                if b:
                    bl.append(b[1])
        self.base = int(np.median(bl)) if bl else None
        if self.base is None and self.has('E'):
            self.base = bbox(self.cell('E')[..., 3])[1]
        self.gap = max(1, int(round(self.cellh * 0.045)))

    # --- accents --------------------------------------------------------
    def diaer_from(self, with_dots, plain):
        if not (self.has(with_dots) and self.has(plain)):
            return None
        a, b = self.cell(with_dots), self.cell(plain)
        bt = bbox(b[..., 3])
        if bt is None:
            return None
        top = bt[0]
        part = a[:max(1, top - 1)]
        if bbox(part[..., 3]) is None:
            return None
        return crop_bbox(part)

    def accent_src(self, kind, upper):
        if kind == 'diaer':
            d = self.diaer_from('Ё', 'Е') if upper else self.diaer_from('ё', 'е')
            if d is None:
                d = self.diaer_from('ё', 'е') if upper else self.diaer_from('Ё', 'Е')
            return d
        if kind in ('grave', 'acute'):
            if self.has('`'):
                g = crop_bbox(self.cell('`'))
            elif self.has("'"):
                g = shear_pm(crop_bbox(self.cell("'")), -0.45)
                g = crop_bbox(g)
            else:
                return None
            return g if kind == 'grave' else g[:, ::-1].copy()
        if kind == 'circ':
            if self.has('^'):
                return crop_bbox(self.cell('^'))
            g = self.accent_src('grave', upper)
            if g is None:
                return None
            a = g[:, ::-1]
            h = g.shape[0]
            w = a.shape[1] + g.shape[1] - 1
            out = np.zeros((h, w, 4), np.float32)
            over(out, a, 0, 0)
            over(out, g, a.shape[1] - 1, 0)
            return out
        if kind == 'cedil':
            if self.has(','):
                return crop_bbox(self.cell(','))
            return None
        raise KeyError(kind)

    def stroke_params(self):
        """(stem width px, rgb color at the top of letters)"""
        if hasattr(self, '_stroke'):
            return self._stroke
        widths = []
        for c in ['l', 'i', 'I', 'd', 'h']:
            if not self.has(c):
                continue
            a = self.cell(c)[..., 3]
            b = bbox(a)
            if b is None:
                continue
            for y in range(b[0] + (b[1] - b[0]) // 3, b[0] + 2 * (b[1] - b[0]) // 3):
                row = a[y] > 110
                runs, n = [], 0
                for v in row:
                    if v:
                        n += 1
                    elif n:
                        runs.append(n); n = 0
                if n:
                    runs.append(n)
                if runs:
                    widths.append(max(runs))
        stem = float(np.median(widths)) if widths else max(2.0, self.cellh / 14.0)
        cols = []
        for c in ['o', 'e', 'a', 'n', 'u', 'x']:
            if not self.has(c):
                continue
            g = self.cell(c)
            b = bbox(g[..., 3])
            if b is None:
                continue
            band = g[b[0]:b[0] + max(2, (b[1] - b[0]) // 4)]
            m = band[..., 3] > 200
            if m.any():
                cols.append((band[..., :3][m] / (band[..., 3][m][:, None] / 255.0)).mean(0))
        col = np.mean(cols, 0) if cols else np.array([230, 200, 120], np.float32)
        self._stroke = (stem, col)
        return self._stroke

    def synth_stroke(self, h, kind, upper):
        """anti-aliased tapered stroke: acute (/) or grave (\\), premultiplied RGBA."""
        stem, col = self.stroke_params()
        r = max(0.9, stem * (0.42 if not upper else 0.38))
        w = max(2.0, h * (0.62 if h >= 8 else 0.95))
        W, H = int(np.ceil(w + 2 * r + 2)), int(np.ceil(h + 2 * r + 1))
        out = np.zeros((H, W, 4), np.float32)
        # segment from bottom point to top point
        if kind == 'acute':
            p0 = np.array([r + 1, H - r - 1]); p1 = np.array([W - r - 1, r + 0.5])
        else:
            p0 = np.array([W - r - 1, H - r - 1]); p1 = np.array([r + 1, r + 0.5])
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        d = p1 - p0
        t = np.clip(((xx - p0[0]) * d[0] + (yy - p0[1]) * d[1]) / (d @ d), 0, 1)
        px, py = p0[0] + t * d[0], p0[1] + t * d[1]
        dist = np.hypot(xx - px, yy - py)
        rad = r * (0.6 + 0.55 * t)   # thin at the bottom, thick at the top
        a = np.clip(rad + 0.5 - dist, 0, 1)
        out[..., 3] = a * 255
        out[..., :3] = a[..., None] * col[None, None, :]
        return crop_bbox(out, 4)

    def body_center_x(self, img, y0, y1):
        a = img[y0:y1, :, 3]
        ys, xs = np.nonzero(a > THR)
        if len(xs) == 0:
            b = bbox(img[..., 3])
            return (b[2] + b[3]) / 2.0 if b else img.shape[1] / 2.0
        return (xs.min() + xs.max()) / 2.0

    def make_accented(self, ch, base, kind):
        upper = ch.isupper()
        if not self.has(base):
            return None
        img = self.cell(base).copy()
        H, W = img.shape[:2]
        b = bbox(img[..., 3])
        if b is None:
            return None
        top_body = b[0]
        if base == 'i':  # dotless i
            cut = self.x_top - max(1, self.gap // 2)
            img[:max(0, cut)] = 0
            top_body = self.x_top
        # height a lowercase accent may use (reference for capitals too)
        lc_need = max(3, (self.x_top - (self.asc_top or 0)) - self.gap) if self.x_top else 6
        if upper and kind != 'cedil':
            want = max(3, int(round(lc_need * (0.62 if kind != 'diaer' else 0.5))))
            avail = (self.cap_top or top_body) - 2 * self.gap
            if avail < want and self.base and self.cellh and self.cellh >= 45:
                # shrink the capital (anchored on the baseline) to free room for the accent
                new_top = want + 2 * self.gap
                body_h = self.base - top_body
                f = max(0.72, min(1.0, (self.base - new_top) / float(max(1, body_h))))
                if f < 0.985:
                    g = crop_bbox(img, 4)
                    gb = bbox(img[..., 3], 4)
                    gh, gw = g.shape[:2]
                    g2 = resize_pm(g, gw * f, gh * f)
                    img = np.zeros_like(img)
                    nx = int(round(gb[2] + (gw - g2.shape[1]) / 2.0))
                    ny = int(round(self.base - (self.base - gb[0]) * f))
                    over(img, g2, nx, ny)
                    b = bbox(img[..., 3])
                    top_body = b[0]
        if kind in ('grave', 'acute'):
            if upper:
                hh = max(3, min(int(round(lc_need * 0.62)), (self.cap_top or top_body) - self.gap,
                                top_body - self.gap))
            else:
                hh = max(3, int(round(lc_need)))
            acc = self.synth_stroke(hh, kind, upper)
        else:
            acc = self.accent_src(kind, upper)
        if acc is None:
            return None
        ah, aw = acc.shape[:2]
        if kind == 'cedil':
            target_h = max(3, int(round(ah * 0.75)))
            sc = target_h / float(ah)
            acc = resize_pm(acc, aw * sc, target_h)
            ah, aw = acc.shape[:2]
            cx = self.body_center_x(img, b[1] - max(2, H // 12), b[1] + 1)
            ax = int(round(cx - aw / 2.0))
            ay = b[1] - int(round(ah * 0.25))
            if ay + ah > H:
                ay = H - ah
        else:
            if upper:
                zone_top = 0
                zone_bot = (self.cap_top if base not in ('I',) else top_body) - self.gap
                zone_bot = min(zone_bot, top_body - self.gap)
            else:
                lowest_top = self.asc_top if self.asc_top is not None else 0
                zone_top = max(0, lowest_top - self.gap)
                zone_bot = top_body - self.gap
            avail = zone_bot - zone_top
            if kind == 'diaer':
                maxh = max(2, avail)
                tgt_h = min(ah, maxh)
            elif kind in ('grave', 'acute'):
                tgt_h = min(ah, max(3, avail + self.gap))
            else:
                ref = self.accent_src('diaer', upper)
                ref_h = ref.shape[0] if ref is not None else ah
                tgt_h = min(ah, max(ref_h + max(1, ref_h // 2), 3), max(3, avail))
            sc = tgt_h / float(ah)
            nw = aw * sc
            maxw = (b[3] - b[2] + 1) * (0.95 if kind == 'circ' else 0.8)
            if kind == 'circ' and nw > maxw and base not in ('i', 'I'):
                nw = maxw
            if kind in ('grave', 'acute'):
                nw = aw * sc  # keep the synthesized stroke's aspect
            acc = resize_pm(acc, max(2, nw), max(2, tgt_h)) if (abs(nw - aw) > 0.5 or abs(tgt_h - ah) > 0.5) else acc
            ah, aw = acc.shape[:2]
            band0 = top_body
            band1 = top_body + max(2, (self.base - top_body) // 3) if self.base else top_body + 4
            cx = self.body_center_x(img, band0, band1)
            if kind == 'acute':
                cx += aw * 0.12
            elif kind == 'grave':
                cx -= aw * 0.12
            ax = int(round(cx - aw / 2.0))
            ay = max(0, zone_bot - ah)
            if ay < 0:
                ay = 0
        # widen canvas if accent goes out of the cell
        left_pad = max(0, -ax)
        right_pad = max(0, ax + aw - W)
        if left_pad or right_pad:
            canvas = np.zeros((H, W + left_pad + right_pad, 4), np.float32)
            over(canvas, img, left_pad, 0)
            img = canvas
            ax += left_pad
        over(img, acc, ax, ay)
        return img, base

    def make_lig(self, ch, a, b):
        if not (self.has(a) and self.has(b)):
            return None
        A, B = self.cell(a), self.cell(b)
        ba, bb = bbox(A[..., 3]), bbox(B[..., 3])
        if ba is None or bb is None:
            return None
        ov = max(1, int(round((ba[3] - ba[2] + 1) * 0.16)))
        offx = ba[3] + 1 - ov - bb[2]
        W = max(A.shape[1], offx + B.shape[1])
        out = np.zeros((A.shape[0], W, 4), np.float32)
        over(out, A, 0, 0)
        over(out, B, offx, 0)
        return out, a

    def make_quote(self, ch, src):
        if not self.has(src):
            return None
        S = self.cell(src)
        H = S.shape[0]
        g = crop_bbox(S)
        gh, gw = g.shape[:2]
        if self.x_top is not None and self.base is not None:
            sc = min(0.9, max(0.5, 0.78 * (self.base - self.x_top) / float(gh)))
        else:
            sc = 0.7
        g = resize_pm(g, gw * sc, gh * sc)
        gh, gw = g.shape[:2]
        sp = max(1, int(round(gw * 0.45)))
        margin = max(1, int(round(gw * 0.25)))
        W = margin * 2 + gw * 2 + sp - gw // 3
        out = np.zeros((H, W, 4), np.float32)
        if self.x_top is not None and self.base is not None:
            cy = (self.x_top + self.base) / 2.0
        else:
            b = bbox(S[..., 3]); cy = (b[0] + b[1]) / 2.0
        y = int(round(cy - gh / 2.0))
        x2 = margin + gw + sp - gw // 3
        over(out, g, margin, y)
        over(out, g, x2, y)
        return out, src

    def build(self, wanted):
        self.metrics()
        made = {}
        for ch in wanted:
            r = None
            if ch in LOWER:
                r = self.make_accented(ch, *LOWER[ch])
            elif ch in UPPER:
                r = self.make_accented(ch, *UPPER[ch])
            elif ch in LIG:
                r = self.make_lig(ch, *LIG[ch])
            elif ch in QUOTES:
                r = self.make_quote(ch, QUOTES[ch])
            if r is not None:
                made[ch] = r
        return made


def pack_and_write(tf, made, out_tex_name):
    """place glyph images in free space (expanding the texture if needed).
    returns {char: (x,y,w,h) logical, base_char} and writes texture."""
    sx, sy = tf.sx, tf.sy
    used_max_y = 0
    for sec in tf.sections:
        for (x, y, w, h) in sec.chars.values():
            used_max_y = max(used_max_y, y + h)
    items = []
    for ch, (img, base) in made.items():
        h_px, w_px = img.shape[:2]
        wl = int(np.ceil(w_px / sx))
        hl = int(np.ceil(h_px / sy))
        items.append((ch, img, base, wl, hl))

    def try_pack(y_start, y_end):
        x, y, rowh = 1, y_start, 0
        pos = {}
        for ch, img, base, wl, hl in items:
            if x + wl + 1 > tf.xs:
                x = 1
                y += rowh + 2
                rowh = 0
            if y + hl > y_end:
                return None
            pos[ch] = (x, y, wl, hl)
            x += wl + 2
            rowh = max(rowh, hl)
        return pos

    ys_new = tf.ys
    pos = try_pack(used_max_y + 2, tf.ys)
    rgba = tf.rgba
    if pos is None:
        ys_new = tf.ys * 2
        pos = try_pack(int(tf.ys) + 1, ys_new)
        if pos is None:
            raise RuntimeError('cannot pack glyphs into ' + tf.tex_name)
        big = np.zeros((tf.H * 2, tf.W, 4), np.uint8)
        big[:tf.H] = rgba
        rgba = big
    canvas = premul(rgba)
    for ch, img, base, wl, hl in items:
        x, y, wl, hl = pos[ch]
        X, Y = int(round(x * sx)), int(round(y * sy))
        canvas[Y:Y + img.shape[0], X:X + img.shape[1]] = 0
        over(canvas, img, X, Y)
    out = unpremul(canvas)
    fmt = tf.t['fmt']
    if fmt not in (21, 26):
        fmt = 21
    nm = tf.t['nmips']
    if nm > 1:
        hh, ww = out.shape[:2]
        nm = int(np.log2(max(hh, ww))) + 1
    out_path = os.path.join(TEX_DIR, out_tex_name.replace('\\', os.sep) + '.tx')
    write_tx(out_path, out, fmt, nmips=nm)
    return pos, ys_new, out


def main(preview_dir=None):
    ini = FontIni(os.path.join(ROOT, 'RESOURCE', 'INI', 'fonts_eng.ini'))
    by_tex = {}
    for sec in ini.sections.values():
        tex = sec.prop('texture')
        if tex:
            by_tex.setdefault(tex, []).append(sec)
    extra = {}
    overrides = {}
    report = []
    for tex, secs in by_tex.items():
        prim = secs[0]
        if not os.path.exists(os.path.join(TEX_DIR, tex.replace('\\', os.sep) + '.tx')):
            continue
        has_letters = any(('a' in s.chars or 'A' in s.chars) for s in secs)
        if not has_letters or 'keyboard' in tex.lower() or 'numbers' in tex.lower():
            continue
        tf = TexFonts(tex, secs)
        existing = set(prim.chars)
        is_icon_font = any(s.name.upper() == 'INTERFACE_NORMAL' for s in secs)
        wanted = []
        for ch in ALL_NEW:
            if ch in QUOTES:
                wanted.append(ch)  # replace the '"' alias by real guillemets
            elif ch not in existing or is_icon_font:
                wanted.append(ch)
        # fonts without lowercase latin: capitals only
        if 'a' not in prim.chars:
            wanted = [c for c in wanted if not c.islower()]
        made = tf.build(wanted)
        if not made:
            continue
        new_tex = tex[:-4] + ' fr.tga' if tex.lower().endswith('.tga') else tex + ' fr'
        pos, ys_new, out = pack_and_write(tf, made, new_tex)
        report.append('%-45s %3d glyphes -> %s (ysize %s -> %s)' % (tex, len(made), new_tex, tf.ys, ys_new))
        for sec in secs:
            ents = []
            for ch, (x, y, w, h) in pos.items():
                base = made[ch][1]
                # replicate the section's padding difference vs primary for the base glyph
                dx = dw = 0
                if base in sec.chars and base in prim.chars:
                    px, py, pw, ph = prim.chars[base]
                    qx, qy, qw, qh = sec.chars[base]
                    dx, dw = qx - px, qw - pw
                    if abs(dx) > 3 or abs(dw) > 6:
                        dx = dw = 0
                ent = (x + dx, y, max(1, w + dw), h)
                icon_sec = sec.name.upper() == 'INTERFACE_NORMAL'
                if not (icon_sec and ch in PUA_MAP):
                    ents.append((ch, ent))
                if ch in PUA_MAP:
                    ents.append((PUA_MAP[ch], ent))
            # PUA aliases for letters that already exist in the font (e.g. popup font)
            for ch, pua in PUA_MAP.items():
                if ch not in pos and ch in sec.chars and sec.name.upper() != 'INTERFACE_NORMAL':
                    ents.append((pua, sec.chars[ch]))
            # fallback: glyph could not be built -> show the unaccented letter
            for ch in list(LOWER) + list(UPPER):
                if ch in pos or ch in sec.chars:
                    continue
                base = (LOWER.get(ch) or UPPER.get(ch))[0]
                if base in sec.chars:
                    if not (sec.name.upper() == 'INTERFACE_NORMAL' and ch in PUA_MAP):
                        ents.append((ch, sec.chars[base]))
                    if ch in PUA_MAP:
                        ents.append((PUA_MAP[ch], sec.chars[base]))
            for ch, (a, b) in LIG.items():
                if ch not in pos and ch not in sec.chars and a in sec.chars:
                    ents.append((ch, sec.chars[a]))
            # drop entries for real chars that already exist (except guillemets)
            ents = [(c, e) for (c, e) in ents if c in QUOTES or c not in sec.chars
                    or sec.name.upper() == 'INTERFACE_NORMAL' and c not in sec.chars]
            extra[sec.name] = ents
            ov = {'Texture': new_tex}
            if ys_new != tf.ys:
                ov['Texture_ysize'] = str(int(ys_new))
            overrides[sec.name] = ov
        if preview_dir:
            im = Image.fromarray(out, 'RGBA')
            bg = Image.new('RGBA', im.size, (40, 40, 60, 255))
            bg.alpha_composite(im)
            bg.convert('RGB').save(os.path.join(preview_dir, os.path.basename(new_tex) + '.png'))
    # guillemets: remove old alias lines '"' -> they are replaced by appended entries (later keys win?)
    out_ini = os.path.join(ROOT, 'RESOURCE', 'INI', 'fonts_fra.ini')
    # rewrite: drop existing char_« / char_» lines where we provide new ones
    for name, ents in extra.items():
        newc = {c for c, _ in ents}
        sec = ini.sections[name]
        keep = []
        for line in sec.lines:
            s = line.strip()
            drop = False
            for c in ('«', '»'):
                if c in newc and s.startswith('char_' + c):
                    drop = True
            if not drop:
                keep.append(line)
        sec.lines = keep
    ini.write(out_ini, extra=extra, prop_override=overrides)
    print('\n'.join(report))
    print('ecrit:', out_ini)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else None)
