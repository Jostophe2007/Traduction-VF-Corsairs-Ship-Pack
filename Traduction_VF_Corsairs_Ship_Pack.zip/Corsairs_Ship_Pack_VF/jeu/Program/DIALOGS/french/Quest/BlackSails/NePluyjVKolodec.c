
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "BS_NPVK_1":	//Торговец
			dialog.text = "Capitaine, rien de personnel, mais une personne très influente m'a interdit de faire affaire avec vous. Aucune transaction, désolé";
			link.l1 = "Pardon, mais je ne comprends pas. Que s'est-il passé ?";
			link.l1.go = "BS_NPVK_2";
		break;

		case "BS_NPVK_2":
            dialog.text = "Adressez-vous à Mlle Guthrie : elle est arrivée récemment de Nassau et a pris en main le commerce des prises. Jackman lui-même vient la voir chapeau bas.";
            link.l1 = "Hum. Guthrie... דa me dit quelque chose. Bon, à plus tard.";
			link.l1.go = "exit";
		break;

		case "BS_NPVK_3":	//Гатри
            dialog.text = "Ah, voici notre capitaine à problèmes ! Vous voilà pour régler nos différends ? Réglons-les, mais je vous préviens : ces gars avec leurs mousquets ne sont pas là pour faire joli.";
            link.l1 = "Hum. Le fait est que les marchands des colonies, et même les pirates, ont cessé de faire affaire avec moi ; ils disent que c'est à cause de vous. Puis-je savoir de quoi il retourne ?";
			link.l1.go = "BS_NPVK_4";
		break;

		case "BS_NPVK_4":
            dialog.text = "Il s'agit de votre imprudence et, je pense, de votre inexpérience des affaires du Nouveau Monde. Permettez-moi de vous expliquer.";
            link.l1 = "Je vous écoute.";
			link.l1.go = "BS_NPVK_5";
		break;

		case "BS_NPVK_5":
            dialog.text = "L'ancien propriétaire de ce magasin, monsieur Voisier, était pour ainsi dire l'homme de confiance de notre famille. Toutes les marchandises prises par les pirates, et souvent par les corsaires, devenaient tout à fait légales grâce à ses efforts, et rapportaient des bénéfices à tout le monde. Y compris aux gouverneurs et aux commandants des escadres militaires\n"+
							"Et voilà qu'un brave capitaine décide que les règles ne s'appliquent pas à lui et se met à semer le chaos. L'argent, voyez-vous, aime la tranquillité.";
            link.l1 = "Votre « homme de confiance » était en fait lui-même un pirate, et il entravait le commerce dans l'archipel. Un marchand respecté est venu me trouver au nom de la communauté, et j'ai réglé le problème du mieux que j'ai pu. Je ne vois pas quels différends nous pourrions avoir, vous et moi ?";
			link.l1.go = "BS_NPVK_6";
		break;

		case "BS_NPVK_6":
            dialog.text = "Capitaine. Je peux mettre votre ton sur le compte de l'inexpérience et de l'incompréhension de la nature des choses, mais je vous préviens : encore un mot, et ce sont les armes qui parleront !";
            if (WhisperIsHere())
			{
				link.l1.go = "BS_NPVK_6_WhisperIsHere";
				break;
			}
			link.l1 = "Pour qui tu te prends, ma fille ?";	//Драка
			link.l1.go = "Fight_gatri";
			link.l2 = "Baissons d'un ton et trouvons une solution à nos « difficultés ».";
			link.l2.go = "BS_NPVK_7";
		break;

		case "BS_NPVK_6_1":
			link.l1 = "Pour qui tu te prends, ma fille ?";	//Драка
			link.l1.go = "Fight_gatri";
			link.l2 = "Baissons d'un ton et trouvons une solution à nos « difficultés ».";
			link.l2.go = "BS_NPVK_7";
		break;

		case "BS_NPVK_6_WhisperIsHere":
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.WhisperPGG, "BS_9_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
		break;

		case "Fight_gatri":
			AddQuestRecord("BSPrologue", "6");
			CloseQuestHeader("BSPrologue");
			PChar.BS_PiratesStoreMassacre = true;
			SaveCurrentQuestDateParam("BS_PiratesStoreMassacreDate");
			BS_SL_yes();
			DeleteAttribute(pchar, "BSStart");
			BS_QuestCleaning(true);			
			ChangeCharacterHunterScore(pchar, "enghunter", 200);
			pchar.questTemp.BlueBird = "declined";//Блокировка ЧП
			string killGatri;
			for (i = 1; i < 4; i++)
			{
				sld = CharacterFromID("gatri_grunt"+i);
				LAi_SetImmortal(sld, false);
				killGatri = "l"+i;
				pchar.quest.KillGatri.win_condition.(killGatri) = "NPC_Death";
				pchar.quest.KillGatri.win_condition.(killGatri).character = sld.id;
				pchar.quest.KillGatri1.win_condition.(killGatri) = "NPC_Death";
				pchar.quest.KillGatri1.win_condition.(killGatri).character = sld.id;
				LAi_group_MoveCharacter(sld, "EnemyFight");
				LAi_group_MoveCharacter(npchar, "EnemyFight");
				LAi_SetHP(sld, 200, 200);
			}
			killGatri = npchar.id;
			LAi_SetImmortal(npchar, false);
			npchar.Dialog.FileName = npchar.beforeGatriFileName;
			npchar.Dialog.CurrentNode = npchar.beforeGatriCurrentNode;
			pchar.quest.KillGatri.win_condition.(killGatri) = "NPC_Death";
			pchar.quest.KillGatri.win_condition.(killGatri).character = npchar.id;
			pchar.quest.KillGatri1.win_condition.(killGatri) = "NPC_Death";
			pchar.quest.KillGatri1.win_condition.(killGatri).character = npchar.id;
			pchar.quest.KillGatri.function = "LockWeapons";
			pchar.quest.KillGatri1.win_condition = "OpenTheDoors";
			chrDisableReloadToLocation = true;
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			AddDialogExitQuest("MainHeroFightModeOn");
            LAi_group_Attack(NPChar, Pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "BS_NPVK_7":
            dialog.text = "Régler nos différends, capitaine, sera simple pour vous. Il suffit de chasser les Anglais du fort de Nassau.";
			link.l1 = "C'est ça que vous appelez « simple » ? Déclarer la guerre à l'Angleterre ?";
			link.l1.go = "BS_NPVK_8";
		break;

		case "BS_NPVK_7_WhisperIsHere":
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.WhisperPGG, "BS_10_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
		break;

		case "BS_NPVK_8":
            dialog.text = "Pas de guerre. Juste une bande de pirates sous pavillon noir, qui pille une colonie lointaine et peu importante, puis disparaît à l'horizon. Il faudra des années à la Couronne pour trouver les moyens et l'énergie de tenter de reprendre la colonie, mais le plus probable, c'est qu'elle fermera tout simplement les yeux et fera comme si cette colonie n'avait jamais existé. La famille Guthrie fera tout son possible pour que ces yeux restent fermés.";
            link.l1 = "Votre famille se sent à l'étroit à Boston et à Philadelphie, et vous étendez votre zone d'influence ?";
			link.l1.go = "BS_NPVK_9";
		break;

		case "BS_NPVK_9":
            dialog.text = "Vous comprenez vite ! Détruisez le fort, tuez ou capturez la garnison. Les forces nécessaires, vous les trouverez vous-même, mais n'essayez même pas d'y faire participer les barons pirates du coin. Ce doit être l'initiative personnelle d'un pirate désespéré. Il est dans votre propre intérêt d'éviter toute publicité.";
            link.l1 = "Admettons que la ville soit prise. Et ensuite ? Vous avez bien un plan pour tenir la colonie ?";
			link.l1.go = "BS_NPVK_10";
		break;
		
		case "BS_NPVK_10":
            dialog.text = "Il y a un plan, prévenez-moi simplement quand vous partirez pour les Bahamas. Et en cas de succès, mes hommes et moi serons là-bas en un jour ou deux.";
            link.l1 = "La famille Guthrie se trouvera « tout à fait par hasard » dans les parages et viendra au secours des colons ? Astucieux. Et que se passera-t-il si je refuse de me lancer dans cette aventure ?";
			link.l1.go = "BS_NPVK_11";
		break;
		
		case "BS_NPVK_11":
            dialog.text = "Tous les chasseurs de primes de l'Ancien et du Nouveau Monde seront soudain pris d'une envie irrésistible de m'apporter votre tête. Je vous assure, capitaine, même les rois n'osent pas se brouiller avec la Maison de commerce Guthrie. Nous avons les moyens et les relations pour rendre la vie très difficile à n'importe qui.";
            link.l1 = "Pour qui tu te prends, ma fille ? Ha ! Une bande de boutiquiers et de comptables ! Je connais le meilleur moyen de régler nos différends : l'acier froid !";
			link.l1.go = "Fight_gatri";
			link.l2 = "Tout ça a l'air d'une folie complète, mais j'accepte ! Il me faut du temps pour me préparer. Je ne dirai pas combien, mais je vous préviendrai. א bientכt.";
			link.l2.go = "BS_NPVK_12";
		break;
		
		case "BS_NPVK_12":
            dialog.text = "Parfait. Et tout ce dont vous avez besoin, vous pouvez l'acheter dans ce magasin. Les entrepכts des Bermudes sont toujours à votre service. Vous me trouverez par l'intermédiaire du tavernier.";
            link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_NPVK_13";
			BS_SL_yes();
			AddQuestRecord("BSPrologue", "2");
			pchar.questTemp.BSPrologue.WaitingForNassauSiege = true;
		break;

		case "BS_NPVK_13":
            dialog.text = "Quoi encore ? Je ne vous retiens pas plus longtemps.";
			link.l1 = "...";
			link.l1.go = "BS_NPVK_14";
		break;
		
		case "BS_NPVK_14":
			DialogExit();
			DoReloadCharacterToLocation("Pirates_town", "reload", "reload6_back");
		break;
		
		case "Woman_FackYou":
			dialog.text = "Mon cœur, oם est-ce que tu crois aller comme ça ?! Tu avais pourtant l'air d'une personne bien comme il faut. Maintenant, tu ne t'en iras pas si facilement, mon joli cœur. On va te rogner les ailes...";
			link.l1 = "Tais-toi, idiote...";
			link.l1.go = "Fight_gatri";
			LAi_SetOwnerTypeNoGroup(npchar);
		break;
		
		case "BS_NPVK_15":
			dialog.text = "Le jour est venu ? Tout est prêt pour l'expédition ?";
			link.l1 = "Plus que jamais ! Vos hommes sont-ils prêts ?";
			link.l1.go = "BS_NPVK_16";
		break;
		
		case "BS_NPVK_16":
			dialog.text = "Nous serons dans les parages. Bonne chance, capitaine !";
			link.l1 = "Un peu de chance ne nous fera pas de mal. Allons-y !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("BS_ToNassauSiege_PiratesTown");
		break;
		
		case "BS_NPVK_17":
			dialog.text = "C'est fait, vos dettes sont effacées. Maintenant, quittez l'île ; je vous contacterai par l'intermédiaire des taverniers pirates s'il y a du travail dans vos cordes.";
			link.l1 = "J'ai ici une foule de coupe-jarrets qui viennent de goמter au sang. On ne les convaincra pas comme ça de remonter dans les chaloupes et de partir. Vous voyez ce que je veux dire ?";
			link.l1.go = "BS_NPVK_18";
		break;
		
		case "BS_NPVK_18":
			dialog.text = "Je comprends parfaitement. Eh bien, les entrepכts de la colonie sont à votre service : prenez tout ce que vous pourrez emporter et quittez enfin mon île !";
			link.l1 = "Voilà une approche professionnelle. C'est un plaisir de travailler avec quelqu'un de compréhensif !";
			link.l1.go = "BS_NPVK_18_exit";
			
		break;
		
		case "BS_NPVK_18_exit":
			NextDiag.CurrentNode = "BS_NPVK_19";
			DialogExit();
			SaveCurrentQuestDateParam("BSPrologueEnded");
			AddQuestRecord("BSPrologue", "3");
			CloseQuestHeader("BSPrologue");
			DeleteAttribute(pchar, "BSStart");
			pchar.BSInProgress = true;
			AddDialogExitQuestFunction("BS_NassauSiegeComplete");
		break;
		
		case "BS_NPVK_19":
			dialog.text = "C'est fait.";
			link.l1 = "Oui.";
			Link.l1.go = "BS_NPVK_19_loop";
		break;
		
		case "BS_NPVK_19_loop":
			NextDiag.CurrentNode = "BS_NPVK_19";
			DialogExit();
		break;
		
		case "BS_NPVK_20":
			dialog.text = NPCStringReactionRepeat("J'ai à faire pour l'instant.", "Revenez une autre fois.", "Ah, capitaine, ça fait plaisir de vous voir, mais pardonnez-moi, j'ai beaucoup à faire.", "Remettons ça à une autre fois, j'ai beaucoup de travail.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Euh, excusez-moi.", "Je le ferai.", "Je comprends.", "Je m'en vais.", npchar, Dialog.CurrentNode);
			Link.l1.go = "BS_NPVK_20_loop";			
		break;
		
		case "BS_NPVK_20_meet":
			if(!CheckAttribute(PChar, "GatriSalutation") || GetQuestPastDayParam ("GatriSalutation") > 0)
			{
				SaveCurrentQuestDateParam("GatriSalutation");
				dialog.text = "Bonjour.";
				link.l1 = "Salutations...";				
			}
			else
			{
				dialog.text = "Vous vouliez quelque chose ?";
				link.l1 = "Oui...";
			}
			Link.l1.go = "BS_NPVK_20";
		break;
		
		case "BS_NPVK_20_loop":
			NextDiag.CurrentNode = "BS_NPVK_20_meet";
			DialogExit();
		break;
	}
}
