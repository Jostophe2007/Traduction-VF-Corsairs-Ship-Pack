void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	int i;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string attrLoc = Dialog.CurrentNode;

	if (findsubstr(attrLoc, "AndreAbelQuestSetNationLicence_", 0) != -1)
 	{
		i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.LicenceNation = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
		Dialog.CurrentNode = "Andre_Abel_In_Tavern_Quest_Complete_2";
 	}

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = RandPhraseSimple("Salutations, capitaine...", "Content de vous voir, capitaine.");
			link.l1 = "Désolé, l'ami, j'ai du pain sur la planche. Je ne peux pas m'occuper de toi.";
			link.l1.go = "exit";
			if(GetCompanionQuantity(PChar) != COMPANION_MAX)
			{
				link.l2 = "Hum, je ne vous connais pas. On s'est déjà vus ?";
				link.l2.go = "Andre_Abel_1";
			}
		break;

		case "Andre_Abel_1":
			dialog.text = "Non, nous ne nous connaissons pas... Je m'appelle " + GetFullName(NPChar) + ". Je commande le navire '" + NPChar.ship.name + "'.";
			link.l1 = "Et moi, je suis " + GetFullName(PChar) + ". Vous vouliez quelque chose ?";
			link.l1.go = "Andre_Abel_2";
		break;

		case "Andre_Abel_2":
			dialog.text = "Capitaine, puis-je compter sur votre aide ? J'ai vraiment besoin d'une escorte jusqu'à Port-au-Prince.";
			link.l1 = "C'est tout ? Et moi qui pensais déjà...";
			link.l1.go = "Andre_Abel_3";
		break;

		case "Andre_Abel_3":
			dialog.text = "Mais je ne suis pas prêt à payer plus de 3 000 piastres pour ce travail, et il faut le faire en cinq jours.";
			link.l1 = "Hum, et à quoi tiennent des conditions aussi dures ?";
			link.l1.go = "Andre_Abel_5";
			link.l2 = "Non, je refuse. Vous me limitez trop dans le temps.";
			link.l2.go = "Andre_Abel_4";
		break;

		case "Andre_Abel_4":
			dialog.text = "Bien dommage...";
			link.l1 = "Ne m'en veuillez pas...";
			link.l1.go = "exit";
			NPChar.LifeDay = 0;
			NextDiag.TempNode = "Andre_Abel_No_Quest";
		break;

		case "Andre_Abel_No_Quest":
			dialog.text = RandPhraseSimple("Dommage que vous n'ayez pas la possibilité de m'aider...", "Bon, il va falloir attendre le passage d'une patrouille.");
			link.l1 = "Ne m'en veuillez pas...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Andre_Abel_No_Quest";
		break;

		case "Andre_Abel_5":
			dialog.text = "Le fait est que j'ai dépensé beaucoup de temps et d'argent pour réparer le navire. Maintenant, il faut beaucoup économiser et se dépêcher.";
			link.l1 = "Bon, j'accepte. Votre navire est prêt à appareiller ?";
			link.l1.go = "Andre_Abel_6";
			link.l2 = "Je crois que je vais refuser... J'avais d'autres projets, et votre proposition ne me pousse guère à les changer.";
			link.l2.go = "Andre_Abel_4";
		break;

		case "Andre_Abel_6":
			dialog.text = "Oui, le navire est entièrement prêt. Pendant que vous terminez vos affaires en ville, je vous attendrai ici.";
			link.l1 = "D'accord. א bientכt...";
			link.l1.go = "exit";
			SetQuestHeader("Andre_Abel_Quest");
			AddQuestRecord("Andre_Abel_Quest", "1");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			PChar.Quest.Andre_Abel_Quest_1Day_Left.over = "yes";
			PChar.QuestTemp.Andre_Abel_Quest_In_Progress = true;	// Флаг - квест начат
			SetFunctionTimerCondition("Andre_Abel_Quest_2Days_Left", 0, 0, 2, false);
			NextDiag.TempNode = "Andre_Abel_To_Sea_1";
		break;

		case "Andre_Abel_7":
			dialog.text = RandPhraseSimple("Nous avons eu de la chance avec le vent, capitaine " + GetFullName(PChar) + ".", "Fort-de-France est une jolie ville, mais pendant le temps oם j'y suis resté coincé, elle a eu le temps de m'ennuyer à mourir.");
			link.l1 = "Ne perdons pas de temps...";
			link.l1.go = "exit";
			NextDiag.Tempnode = "Andre_Abel_7";
		break;

		case "Andre_Abel_To_Sea_1":
			dialog.text = "Alors, on part déjà ?";
			link.l1 = "Oui. Donnez l'ordre de lever l'ancre.";
			link.l1.go = "Andre_Abel_To_Sea_2";
			link.l2 = "Non, j'ai encore des choses à faire.";
			link.l2.go = "Andre_Abel_To_Sea_1_1";
			NextDiag.TempNode = "Andre_Abel_To_Sea_1";
		break;

		case "Andre_Abel_To_Sea_1_1":
			dialog.text = "On ne pourrait pas se dépêcher ? Vous vous souvenez que je suis limité dans le temps.";
			link.l1 = "Je m'en souviens. Nous arriverons tous à temps...";
			link.l1.go = "exit";
			//	NextDiag.Tempnode = "Andre_Abel_To_Sea_1";
		break;

		case "Andre_Abel_To_Sea_2":
			dialog.text = "Eh bien, parfait.";
			link.l1 = "J'espère que cette traversée ne nous causera pas d'ennuis.";
			link.l1.go = "Andre_Abel_To_Sea_3";
			NextDiag.TempNode = "Andre_Abel_7";
		break;

		case "Andre_Abel_To_Sea_3":
			DialogExit();
			NextDiag.CurrentNode = "Andre_Abel_7";
			AddQuestRecord("Andre_Abel_Quest", "3");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			PChar.Quest.Andre_Abel_Quest_2Days_Left.over = "yes";
			SetFunctionTimerCondition("Andre_Abel_Quest_5_Days_Is_Left", 0, 0, 5, false);
			SetFunctionNPCDeathCondition("Andre_Abel_Quest_Andre_Is_Dead", "Andre_Abel", false);
			SetFunctionLocationCondition("Andre_Abel_Quest_Battle_With_Pirates_Squadron", "Hispaniola2", false);
			SetFunctionExitFromLocationCondition("Andre_Abel_Quest_Delete_Andre_From_Tavern", PChar.location, false);
		break;

		case "Andre_Abel_15Days_Left_1": // Это на случай, если время закончиться тогда, когда Абель будет подходить к ГГ в порту Порт-о-Принса
			if(PChar.location == "FortFrance_Tavern")	// Из таверны можно было не выходить fix
			{
				dialog.text = PChar.Name + ", vous m'avez déçu ! Je n'imagine pas quelle affaire peut obliger un capitaine libre à traîner dans ce maudit Fort-de-France pendant un demi-mois !";
				link.l1.go = "Andre_Abel_15Days_Left_In_FortFrance";
				break;
			}
			dialog.text = PChar.Name + ", vous m'avez déçu ! Nous ne sommes pas arrivés à Port-au-Prince en quinze jours !";
			link.l1 = "Sans rancune, l'ami, mais j'ai des choses plus importantes à faire qu'escorter une vieille galoche, et presque gratuitement.";
			link.l1.go = "Andre_Abel_15Days_Left_2";
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			LAi_LocationDisableOfficersGen("PortPax_town", false);
			LAi_SetImmortal(NPChar, true);
		break;

		case "Andre_Abel_15Days_Left_In_FortFrance":
			dialog.text = "Les termes du marché n'ont pas été respectés, je romps donc le contrat !";
			link.l1 = "Eh bien, ça va de soi...";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(NPChar);
		break;

		case "Andre_Abel_15Days_Left_2":
			dialog.text = "Je pense que vous comprenez qu'il ne peut être question d'aucune récompense !";
			link.l1 = "Qu'y a-t-il à ne pas comprendre ?";
			link.l1.go = "Andre_Abel_15Days_Left_3";
		break;

		case "Andre_Abel_15Days_Left_3":
			dialog.text = "J'espère que nous ne nous reverrons pas.";
			link.l1 = "Qui sait, qui sait...";
			link.l1.go = "Andre_Abel_15Days_Left_4";
		break;

		case "Andre_Abel_15Days_Left_4":
			DialogExit();
			NPChar.LifeDay = 0;
			LAi_CharacterDisableDialog(NPChar);
//			LAi_ActorGoToLocatorFunc(NPChar, "reload", "reload6_back", "Andre_Abel_Quest_Delete_Andre", 15);
			LAi_ActorGoToLocator(NPChar, "reload", "reload6_back", "", 15);
		break;

		case "Andre_Abel_In_PortPax":
			dialog.text = "Merci, capitaine, vous m'avez bien tiré d'affaire. Je vais vous payer vos services en lingots d'argent, il y en a même pour plus de trois mille. דa ne vous dérange pas ?";
			link.l1 = "Non, bien sמr... écoutez, pourquoi aviez-vous besoin d'une escorte ? Après tout, ni votre navire ni le contenu de sa cale n'ont une valeur particulière.";
			link.l1.go = "Andre_Abel_In_PortPax_2";
			Group_DeleteGroup("Andre_Abel_Quest_Pirates_Ships"); // На всякий случай
			//AddMoneyToCharacter(PChar, 3000);
			TakeNItems(pchar, "jewelry17", 33);
			Log_Info("Vous avez reçu des lingots d'argent");
			PlaySound("interface\important_item.wav");
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			LAi_LocationDisableOfficersGen("PortPax_town", false);
			LAi_SetImmortal(NPChar, true);
			PChar.Quest.Andre_Abel_Quest_5_Days_Is_Left.over = "yes";
		break;

		case "Andre_Abel_In_PortPax_2":
			dialog.text = "Hum, l'attaque pirate près d'Hispaniola, ça ne vous dit rien ?";
			link.l1 = "C'est donc ça ! Et moi qui n'avais pas pensé à relier cette attaque à votre présence dans l'escadre.";
			link.l1.go = "Andre_Abel_In_PortPax_3";
			link.l2 = "Qu'avez-vous fait pour agacer à ce point les pirates, qu'ils prennent le risque d'attaquer votre escorte sous les yeux du fort ?";
			link.l2.go = "Andre_Abel_In_PortPax_5";
		break;

		case "Andre_Abel_In_PortPax_3":
			dialog.text = "Oui, ces événements sont directement liés...";
			link.l1 = "Compris... Eh bien, bonne continuation !";
			link.l1.go = "Andre_Abel_In_PortPax_4";
		break;

		case "Andre_Abel_In_PortPax_4":
			DialogExit();
			AddQuestRecord("Andre_Abel_Quest", "9");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Andre_Abel_Quest");
			pchar.questdata.FleitOrion = 1;
			DeleteAttribute(pchar, "QuestTemp.AndreAbelQuest");
			PChar.Quest.Andre_Abel_Quest_Andre_Is_Dead.over = "yes";
			NPChar.LifeDay = 0;
			LAi_ActorGoToLocator(NPChar, "reload", "reload6_back", "", 15);
//			LAi_ActorGoToLocatorFunc(NPChar, "reload", "reload6_back", "Andre_Abel_Quest_Delete_Andre", 15);
		break;

		case "Andre_Abel_In_PortPax_5":
			dialog.text = "C'est une assez longue histoire... Je vous propose d'aller à la taverne, et là, autour d'une chope de rhum, je vous la raconterai.";
			link.l1 = "Eh bien, allons-y...";
			link.l1.go = "Andre_Abel_In_PortPax_6";
		break;

        case "Andre_Abel_In_PortPax_6":
			DialogExit();
			LAi_ActorSetSitMode(NPChar);
			LAi_SetSitType(PChar);
			FreeSitLocator("PortPax_tavern", "sit_front2");
			FreeSitLocator("PortPax_tavern", "sit_base2");
			ChangeCharacterAddressGroup(NPChar, "PortPax_tavern", "sit", "sit_front2");
			DoFunctionReloadToLocation("PortPax_tavern", "sit", "sit_base2", "Andre_Abel_Quest_Dialog_In_PortPax_Tavern");
		break;

		case "Andre_Abel_In_Tavern_1":
			dialog.text = "Bref, voilà... Il y a environ quatre mois, dans des circonstances peu favorables, j'ai rencontré Jackman...";
			link.l1 = "Attendez ! Vous ne parlez pas de ce Jackman qui dirige les pirates des Bermudes ?";
			link.l1.go = "Andre_Abel_In_Tavern_2";
		break;

		case "Andre_Abel_In_Tavern_2":
			dialog.text = "C'est bien de lui... Eh bien, Jackman, profitant de la situation, m'a proposé sa protection en échange de 50 pour cent de tous mes bénéfices. J'ai refusé. D'abord, parce que c'est du racket, et ensuite, je ne pensais pas que Jackman allait me causer des ennuis. Mais je me trompais...\n"
                          + "Un mois plus tard environ, près de la Guadeloupe, mon galion a été attaqué par deux goélettes sous pavillon pirate. J'ai réussi à m'en sortir par miracle, mais j'ai dמ jeter une partie de la cargaison par-dessus bord pour garder de la vitesse. Ce qui m'a sauvé, c'est que le fort de Basse-Terre nous a repérés à temps et a ouvert le feu...\n"
                          + "Quelques mois plus tard, j'ai croisé une escadre pirate au large de la Jamaïque... Sans une frégate de garde anglaise qui patrouillait les eaux cכtières, nous ne serions pas là à parler...\n"
                          + "Environ un demi-mois plus tard, je me suis joint à une petite caravane marchande à Fort-de-France. Là, j'ai déchargé mon galion malmené et je l'ai vendu, dans l'espoir de semer les hommes de Jackman... Puis j'ai acheté et équipé la flמte, j'ai pris un fret pour Port-au-Prince et j'ai attendu un compagnon de route. Mais les délais de l'affrètement m'ont obligé à chercher une escorte...\n" 
						  "Et la suite, vous la connaissez...";
			link.l1 = "Oui, l'ami, tu as de gros ennuis...";
			link.l1.go = "Andre_Abel_In_Tavern_3";
		break;

		case "Andre_Abel_In_Tavern_3":
			dialog.text = "Je me suis demandé bien des fois si j'aurais dמ accepter les conditions de Jackman à l'époque. Et vous savez ce que je vais vous dire ? Je serais déjà prêt à céder, mais maintenant, quelle raison aurait-il de s'occuper de quelqu'un dont les affaires partent à vau-l'eau..."
                          + "Hé, aidez-moi, hein ? Allez aux Bermudes voir Jackman.";
			link.l1 = "Et qu'est-ce que je vais lui dire ?!";
			link.l1.go = "Andre_Abel_In_Tavern_4";
		break;

		case "Andre_Abel_In_Tavern_4":
			dialog.text = "Dites-lui : voilà, André Abel regrette beaucoup de ne pas avoir accepté votre offre, il s'en repent... Dites-lui que mes affaires se sont pratiquement effondrées et que je ne présente plus aucun intérêt pour lui..."
                          + "Allez-y, hein ? Moi, je ne peux pas y aller : c'est la mort assurée.";
			link.l1 = "וcoute, André, tu sais seulement ce que tu demandes ? Je ne le connais pas du tout, et je ne suis rien pour lui.";
			link.l1.go = "Andre_Abel_In_Tavern_5";
			link.l2 = "Bien sמr, je peux essayer, mais les Bermudes sont à un demi-mois d'ici, et j'avais de tout autres projets...";
			link.l2.go = "Andre_Abel_In_Tavern_7";
		break;

		case "Andre_Abel_In_Tavern_5":
			dialog.text = "Oh, c'est dommage... Mais vous avez sans doute raison. Non, ce n'est pas ça... Adieu.";
			link.l1 = "Jackman vous laissera tranquille quand il verra que vous êtes ruiné... Ne désespérez pas comme ça.";
			link.l1.go = "Andre_Abel_In_Tavern_6";
		break;

		case "Andre_Abel_In_Tavern_6":
			DialogExit();
			NPChar.greeting = "pirat_common";
			NPChar.LifeDay = 0;
			NextDiag.CurrentNode = "Andre_Abel_In_PortPax_Tavern_No_Quest";
			CloseQuestHeader("Andre_Abel_Quest");
			pchar.questdata.FleitOrion = 1;
			DeleteAttribute(pchar, "QuestTemp.AndreAbelQuest");
			LAi_SetSitType(NPChar);
			LAi_SetPlayerType(PChar);
			DoFunctionReloadToLocation("PortPax_tavern", "tables", "stay3", "");
		break;

		case "Andre_Abel_In_PortPax_Tavern_No_Quest":
			dialog.text = LinkRandPhrase("J'aimerais tant que vous puissiez m'aider...", "Que dois-je faire maintenant ?", "Toutes mes affaires sont parties à vau-l'eau...");
			link.l1 = "André, sans rancune, mais vous exigez l'impossible.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Andre_Abel_In_PortPax_Tavern_No_Quest";
		break;

		case "Andre_Abel_In_Tavern_7":
			dialog.text = "Aidez-moi, hein ? En échange, je vous donnerai une licence commerciale au porteur. Une chose très utile, vous savez. Et une collection de bijoux. Alors, vous acceptez ?";
			link.l1 = "Bon sang ! D'accord, je vais aller voir Jackman, peut-être que quelque chose en sortira.";
			link.l1.go = "Andre_Abel_In_Tavern_8";
			link.l2 = "Non, traiter avec Jackman pour une récompense aussi douteuse, ce n'est pas pour moi.";
			link.l2.go = "Andre_Abel_In_Tavern_5";
		break;

		case "Andre_Abel_In_Tavern_8":
			dialog.text = "Formidable !.. Je vous attendrai ici, à la taverne. De toute façon, la mer est trop dangereuse pour moi en ce moment.";
			link.l1 = "Attendez... J'essaierai de ne pas traîner.";
			link.l1.go = "Andre_Abel_In_Tavern_9";
		break;

		case "Andre_Abel_In_Tavern_9":
			dialog.text = "Vous n'avez pas idée à quel point je vous suis reconnaissant.";
			link.l1 = "Priez plutכt pour moi. Et vous me remercierez quand je reviendrai avec de bonnes nouvelles.";
			link.l1.go = "Andre_Abel_In_Tavern_10";
		break;

		case "Andre_Abel_In_Tavern_10":
			ref rChar = CharacterFromID("Jackman");
			DialogExit();
			AddQuestRecord("Andre_Abel_Quest", "10");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			NextDiag.CurrentNode = "Andre_Abel_In_Tavern_Continue_Quest";
			LAi_SetSitType(NPChar);
			LAi_SetPlayerType(PChar);
			QuestSetCurrentNode("Jackman", "Andre_Abel_Quest_Jackman_Dialog_1");
			DoFunctionReloadToLocation("PortPax_tavern", "tables", "stay3", "");
		break;

		case "Andre_Abel_In_Tavern_Continue_Quest":
			dialog.text = "Alors, vous avez parlé à Jackman ? Il a accepté ?";
			if(!CheckAttribute(PChar, "QuestTemp.Andre_Abel_Quest_Complete"))
			{
				link.l1 = LinkRandPhrase("Pas encore.", "Ne vous en faites pas tant. Tout va s'arranger pour nous...", "André, détendez-vous... détendez-vous, amusez-vous, de toute façon, rien ne dépend de vous en ce moment.");
				link.l1.go = "exit";
				NextDiag.TempNode = "Andre_Abel_In_Tavern_Continue_Quest";
			}
			else
			{
				link.l1 = "Oui, tout s'est arrangé. Jackman ne vous menace plus.";
				link.l1.go = "Andre_Abel_In_Tavern_Quest_Complete_1";
			}
			break;

		case "Andre_Abel_In_Tavern_Quest_Complete_1":
			dialog.text = "Eh bien, Dieu merci ! Ce n'est pas pour rien que j'espérais tant en vous... Voici votre collection de bijoux, tenez. Et la licence commerciale promise, une universelle, de la Compagnie néerlandaise : avec elle, on vous accueillera dans presque tous les ports.";
			link.l1 = "Un paiement généreux. Merci à vous.";
			link.l1.go = "Andre_Abel_In_Tavern_Quest_Complete_2";
			TakeNItems(pchar, "icollection", 1);
			Log_Info("Vous avez reçu le trésor");
			PlaySound("interface\important_item.wav");
		break;

		case "Andre_Abel_In_Tavern_Quest_Complete_2":
			dialog.text = "Elle est valable 20 jours et reconnue dans les ports de toutes les couronnes. N'oubliez pas d'entrer au port sous un pavillon ami... Vous le savez très bien.";
			link.l1 = "Bien sמr que je le sais ! Merci... écoutez, comment vous êtes-vous procuré une telle licence ?";
			link.l1.go = "Andre_Abel_In_Tavern_Quest_Complete_3";
		break;

		case "Andre_Abel_In_Tavern_Quest_Complete_3":
			dialog.text = "Hum, pourquoi croyez-vous que Jackman me pourchassait dans toutes les Caraïbes ?"
                          + " Bon, maintenant, nous sommes quittes. Merci, et adieu...";
			link.l1 = "Hum, bonne continuation...";
			link.l1.go = "Andre_Abel_In_Tavern_Quest_Complete_4";
		break;

		case "Andre_Abel_In_Tavern_Quest_Complete_4":
			DialogExit();
			NPChar.LifeDay = 0;
			GiveUniLicence(20); // universal GWIK trade license
			SetCharacterShipLocation(NPChar, "none");	// Уберём корабль из порта
			NextDiag.CurrentNode = "Andre_Abel_In_Tavern_Quest_Complete_5";
			AddQuestRecord("Andre_Abel_Quest", "23");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Andre_Abel_Quest");
			pchar.questdata.FleitOrion = 1;
			DeleteAttribute(pchar, "QuestTemp.AndreAbelQuest");
		break;

		case "Andre_Abel_In_Tavern_Quest_Complete_5":
			dialog.text = LinkRandPhrase("Merci, "+ GetSexPhrase("l'ami", "ma petite") +", vous m'avez bien tiré d'affaire.", "Je suis content que vous ayez pu m'aider.", "Enfin, je peux faire des affaires en toute sécurité.");
			link.l1 = "Bonne chance à vous !.. Et ne vous faites plus prendre.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Andre_Abel_In_Tavern_Quest_Complete_5";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
