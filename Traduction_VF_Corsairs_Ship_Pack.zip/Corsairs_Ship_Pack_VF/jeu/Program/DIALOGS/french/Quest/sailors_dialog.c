// реплики солдат на палубе при разговоре в море
// форт-стража и комендант форта
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
        case "exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

        case "First time":
			dialog.text = "Parlez à notre capitaine. Je n'ai rien à vous dire.";
			Link.l1 = "Bien.";
			Link.l1.go = "exit";

			NextDiag.TempNode = "first time";
		break;
		//  на палубе -->
		case "On_Deck":
			dialog.text = "Parlez à notre capitaine. Je n'ai rien à vous dire.";
			Link.l1 = "Bien.";
			Link.l1.go = "exit";

			NextDiag.TempNode = "On_Deck";
/*
			// Первый церковный генератор
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.CapWaitOnTavern"))
			{
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithSailors"))
				{
					dialog.text = "Gospo"+ GetSexPhrase("din", "zha") +"Are you looking for someone?";
					Link.l1 = "Yeah, man. May I see captain of this vessel?";
					Link.l1.go = "ChurchQuest1_Node1";
				}
				else
				{
					dialog.text = "If you have any questions, please contact captain. He recently went ashore.";
					Link.l1 = "Good, good";
					Link.l1.go = "exit";
				}
				break;
			}
*/
			//--> eddy. квест мэра, закрываем выход с палубы и ноду даём нужную
			if (CheckAttribute(pchar, "GenQuest.DestroyPirate") && pchar.GenQuest.CaptainId == "MQPirate")
			{
	    		dialog.text = RandPhraseSimple("Tiens donc, te voilà en personne... Bon, puisque tu es là, va voir le cap'tain. Vous parlerez de tes tristes affaires...",
	                                           "Eh ben, tu ne manques pas d'air, "+ GetSexPhrase("l'ami", "ma petite") +" ! Je n'ai jamais vu ça... Va voir le capitaine, il va te parler.");
				Link.l1 = "Dommage...";
				Link.l1.go = "exit";
			}
			//<-- eddy. квест мэра, закрываем выход с палубы
		break;
/*
		case "ChurchQuest1_Node1":
			dialog.text = "You'd better look for it in the port.";
			Link.l1 = "Thank you, my dear.";
			Link.l1.go = "exit";
			NextDiag.TempNode = "On_Deck";
			PChar.GenQuest.ChurchQuest_1.CapWaitOnTavern = true;
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithSailors"); // Не спрашиваем моряков
		break;
*/
        //  на палубе <--

		// ugeen --> разговор с боцманом по генератору "A reason to hurry"
		case "On_MyShip_Deck":
			dialog.text = "Vous avez fait du raffut, capitaine ! Les gars et moi, on venait de commander une autre tournée quand on a entendu des cris dans la rue. On s'est précipités hors de la taverne, on a appris qu'on essayait de vous arrêter, et on a décidé de lever le camp et de quitter ce port inhospitalier.";
			link.l1 = "Oui, certains ont une drכle d'idée de la justice.";
			link.l1.go = "On_MyShip_Deck_1";
		break;

		case "On_MyShip_Deck_1":
		    if(pchar.questTemp.ReasonToFast == "speakSuccess_chain_A")
			{
				// карты не было
				dialog.text = "Capitaine ! Ne vous laissez pas abattre ! Puisqu'il était de toute façon impossible de partir en paix, on a profité de la pagaille pour rendre visite à un usurier du coin et alléger un peu ses coffres. Voici votre part : " + sti(pchar.questTemp.ReasonToFast.p9) + " piastres...";
			}
			if(pchar.questTemp.ReasonToFast == "speakSuccess_chain_B")
			{
				// карту отобрали
				GiveItem2Character(pchar, pchar.questTemp.ReasonToFast.p6);
				dialog.text = "Capitaine ! Ne vous laissez pas abattre ! Puisqu'il était de toute façon impossible de partir en paix, on a profité de la pagaille pour rendre visite à un usurier du coin et alléger un peu ses coffres. Et on a aussi pris une bonne lame dans la vitrine du prêteur sur gages. Voici votre part : " + sti(pchar.questTemp.ReasonToFast.p9) + " piastres et la lame...";
			}
			link.l1 = "דa tombe à pic. Bravo à vous !";
			link.l1.go = "On_MyShip_Deck_End";
			AddMoneyToCharacter(pchar, sti(pchar.questTemp.ReasonToFast.p9));
			pchar.Ship.Crew.Morale = MORALE_MAX;
			chrDisableReloadToLocation = false; // Откроем выход
			AddQuestRecord("ReasonToFast", "17");
			AddQuestUserData("ReasonToFast", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("ReasonToFast");
			DeleteAttribute(pchar, "TownEscape");
			DeleteAttribute(pchar, "questTemp.ReasonToFast");
			QuestOpenSeaExit();
		break;

		case "On_MyShip_Deck_End":
			DialogExit();
			AddDialogExitQuest("CanEnterToMap");
		break;

		// разговор с боцманом по генератору 'Операция Галеон'
		case "CapComission_OnShipDeck":
			dialog.text = "Capitaine, votre ami s'est enfui.";
			link.l1 = "Quel ami ?";
			link.l1.go = "CapComission_OnShipDeck1";
		break;

		case "CapComission_OnShipDeck1":
			dialog.text = "Ben, celui que vous avez sorti de prison.";
			link.l1 = "Comment avez-vous pu le laisser filer ?!!";
			link.l1.go = "CapComission_OnShipDeck2";
		break;

		case "CapComission_OnShipDeck2":
			dialog.text = "Et nous, qu'est-ce qu'on y peut ? Il a enjambé les barreaux des latrines pendant la nuit, soi-disant pour un besoin pressant, puis il est descendu le long du câble de l'ancre et s'est mis à nager... On a tiré, mais il faisait noir...";
			link.l1 = "Bon sang !!! Vous vous êtes complètement relâchés ! Je vais tous vous débarquer, vous irez couper la canne dans les plantations ! Laisser filer un oiseau aussi précieux !..";
			link.l1.go = "CapComission_OnShipDeck3";
		break;

		case "CapComission_OnShipDeck3":
			chrDisableReloadToLocation = false; // Откроем выход
			AddQuestRecord("CaptainComission2", "25");
			AddQuestUserData("CaptainComission2", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			CloseQuestHeader("CaptainComission2");
			ChangeOfficersLoyality("bad_all", 1);
			ChangeCharacterReputationToNeutral(pchar, -4);//отдалить от нейтральной на 4 единицы
			DeleteAttribute(pchar, "TownEscape");
			DeleteAttribute(pchar, "GenQuest.CaptainComission.canSpeakBoatswain");
			DeleteAttribute(pchar, "GenQuest.CaptainComission");
			QuestOpenSeaExit();
			DialogExit();
			AddDialogExitQuest("CanEnterToMap");
		break;
		// <-- ugeen

		// разговор с боцманом по ситуациям в трюме
		case "Hold_GenQuest_OnShipDeck":
			dialog.text = "Capitaine, pardon, on n'a pas fait attention : le prisonnier s'est évadé.";
			link.l1 = "Quel prisonnier ? Qui s'est évadé ?";
			link.l1.go = "Hold_GenQuest_OnShipDeck1";
		break;

		case "Hold_GenQuest_OnShipDeck1":
			dialog.text = "Ben, celui-là, comment il s'appelle déjà... " + pchar.GenQuest.Hold_GenQuest.CapName + ", ou quelque chose comme ça.";
			link.l1 = "Bon sang ! Mais oם est-ce que vous regardiez ?!";
			link.l1.go = "Hold_GenQuest_OnShipDeck2";
		break;

		case "Hold_GenQuest_OnShipDeck2":
			dialog.text = "Ben, il est sorti de la cale, il a sauté par-dessus le bastingage, et il a disparu. On n'a pas tiré pour ne pas faire de bruit, mais le temps de mettre le canot à l'eau, des pêcheurs l'avaient déjà repêché.";
			link.l1 = "Mais pourquoi est-ce que je vous paie une solde ! Le chef de quart sera fouetté et privé de sa ration de rhum pendant une semaine. Tout le monde à son poste ! On lève l'ancre...";
			link.l1.go = "Hold_GenQuest_OnShipDeck3";
		break;

		case "Hold_GenQuest_OnShipDeck3":
			chrDisableReloadToLocation = false; // Откроем выход
			sld = characterFromId(pchar.GenQuest.Hold_GenQuest.CapId);
			ReleasePrisoner(sld);
			CloseQuestHeader("HoldQuest");
			DeleteAttribute(pchar, "TownEscape");
			DeleteAttribute(pchar, "GenQuest.Hold_GenQuest.canSpeakSailor");
			DeleteAttribute(pchar, "GenQuest.Hold_GenQuest");
			QuestOpenSeaExit();
			DialogExit();
			AddDialogExitQuest("CanEnterToMap");
		break;

		case "Hold_GenQuest_OnShipDeck4":
			dialog.text = "Salut à vous, capitaine. Aucun incident à bord pendant votre absence...";
			link.l1 = "Bon, bon, je vois... Nous avons un prisonnier dans la cale, " + pchar.GenQuest.Hold_GenQuest.CapName + " de son nom. Envoie des hommes le conduire au port. Il est libre.";
			link.l1.go = "Hold_GenQuest_OnShipDeck5";
		break;

		case "Hold_GenQuest_OnShipDeck5":
			dialog.text = "Comment, je dois le relâcher pour de bon ? Je l'envoie en chaloupe, c'est ça ?";
			link.l1 = "Non, à dos de tortue... Il me semble que je me suis fait comprendre. Et qu'ils se dépêchent ! Nous devons lever l'ancre avant le début du jusant.";
			link.l1.go = "Hold_GenQuest_OnShipDeck3";
		break;

		// Warship 09.07.09 Базар с нашим матросом на палубе Мэри Селест -->
		case "On_MaryCeleste_Deck":
Dialog.text = "Capitaine, il n'y a personne sur ce navire ! Il y a quelque chose de louche... Tommy dit qu'il a vu un chat dans le gaillard d'avant, mais pas une âme qui vive...";
			Link.l1 = "Imbécile, un chat n'a pas d'âme. דa fait longtemps que tu n'as pas mis les pieds à l'église, on dirait... si tu y es jamais allé... Vous avez regardé dans la cabine du capitaine ? Il me faut le journal de bord.";
			Link.l1.go = "On_MaryCeleste_Deck_1";
		break;

		case "On_MaryCeleste_Deck_1":
Dialog.text = "On a tout examiné : pas de journal de bord, ni d'instruments de navigation. Il manque aussi le canot de poupe...";
			Link.l1 = "Le canot a été arraché par la tempête ?";
			Link.l1.go = "On_MaryCeleste_Deck_2";
		break;

		case "On_MaryCeleste_Deck_2":
Dialog.text = "Non, capitaine, le canot a été descendu au palan... Et puis... on a trouvé un dussack par terre, dans le gaillard d'avant. Ensanglanté ou rouillé, on ne sait pas. Regardez...";
			Link.l1 = "Pourquoi tu me fourres toutes sortes de saletés sous le nez ?! Fouillez la cale, et on s'en va... Oh, tout ça ne me plaît pas du tout...";
			Link.l1.go = "On_MaryCeleste_Last";
			NextDiag.TempNode = "On_MaryCeleste_Deck_SailorLast";
		break;

		case "On_MaryCeleste_Last":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetCitizenType(NPChar); // Чтоб по палубе ходил

			NPChar = GetRealShip(GetCharacterShipType(CharacterFromID("MaryCelesteCapitan")));
			NPChar.TurnRate = sti(PChar.QuestTemp.MaryCeleste.TurnRate); // Вернём маневренность, для интерфейса

			chrDisableReloadToLocation = false; // Откроем выход

			LaunchTransferMain(PChar, CharacterFromID("MaryCelesteCapitan"), "MaryCelesteTransfer");
		break;

		case "On_MaryCeleste_Deck_SailorLast":
			switch(rand(2))
			{
				case 0:
Dialog.text = "Capitaine, ça fait froid dans le dos, ici... Il serait peut-être temps de partir ?";
					Link.l1 = "Oui... Montez dans le canot.";
					Link.l1.go = "exit";
				break;

				case 1:
Dialog.text = "Capitaine, si vous comptez ramener ce navire bizarre au port, je ne resterai pas à son bord. Je préfère encore sauter par-dessus bord.";
					Link.l1 = "Je ne compte rien du tout... Moi-même, ça me donne la chair de poule.";
					Link.l1.go = "exit";
				break;

				case 2:
Dialog.text = "On peut le couler, hein, capitaine ?";
					Link.l1 = "Pour que les âmes des marins disparus qui vivent ici viennent nous hanter dans nos cauchemars ?";
					Link.l1.go = "On_MaryCeleste_Deck_SailorLast_1";
				break;
			}

			NextDiag.TempNode = "On_MaryCeleste_Deck_SailorLast";
		break;

		case "On_MaryCeleste_Deck_SailorLast_1":
Dialog.text = "Dieu nous en préserve, capitaine... Qu'est-ce que vous dites là !..";
			Link.l1 = "Ne pâlis pas comme ça, je plaisante... Montez dans le canot.";
			Link.l1.go = "exit";
		break;
		// <-- Базар с нашим матросом на палубе Мэри Селест

        //  на палубе <--
        case "On_Fort":
			dialog.text = RandPhraseSimple("Parlez au chef. Je n'ai rien à vous dire.", "Je suis de garde. Pour toute question, adressez-vous au commandant du fort.");
			Link.l1 = "Bien.";
			Link.l1.go = "exit";

			NextDiag.TempNode = "On_Fort";
		break;

		case "On_Fort_Head":
			dialog.text = RandPhraseSimple("Je suis terriblement occupé en ce moment. Laissez-moi tranquille.",
                                           "Ne m'empêchez pas de travailler. Nous n'avons rien à nous dire.");
			Link.l1 = "Dommage...";
			Link.l1.go = "exit";

			NextDiag.TempNode = "On_Fort_Head";
		break;

		case "Morgan_wait_you":
			Dialog.defAni = "dialog_stay1";
			Dialog.defCam = "1";
			Dialog.defSnd = "dialogs\0\017";
			Dialog.defLinkAni = "dialog_1";
			Dialog.defLinkCam = "1";
			Dialog.defLinkSnd = "dialogs\woman\024";
			Dialog.ani = "dialog_stay2";
			Dialog.cam = "1";
			Dialog.snd = "dialogs\0\009";

			dialog.text = RandPhraseSimple("Morgan voulait te dire « deux mots bien sentis »... Il est quelque part sur le pont.",
                                           "Héhé, va trouver Morgan. De mauvaises nouvelles t'attendent...");
			Link.l1 = "Bien.";
			Link.l1.go = "exit";

			NextDiag.TempNode = "Morgan_wait_you";
		break;
	}
}
