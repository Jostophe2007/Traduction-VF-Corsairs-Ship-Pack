
void ProcessDialogEvent()
{
	ref NPChar, sld, location;
	aref Link, NextDiag;
	string sTemp,sTemp1, str, str1;
	int	s1,s2,s3,s4,s5,p1,iColony;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	string iDay, iMonth, lastspeak_date;

	iDay           = environment.date.day;
	iMonth         = environment.date.month;
	lastspeak_date = iday + " " + iMonth;

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Brothel\" + NPChar.City + "_Brothel.c";
    if (HasCityDialogFile("Brothel", NPChar.City, "_Brothel.c") && LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}

	if (Dialog.CurrentNode == "SpecialExit")
	{
		LAi_SetCitizenTypeNoGroup(npchar);
		Dialog.CurrentNode = "exit";
	}
    // вызов диалога по городам <--
	switch(Dialog.CurrentNode)
	{
		// ============= хозяйка борделя =============
		case "First time":
			if (PChar.sex == "woman")
			{
				npchar.greeting = "hostess_lady";
			}
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase(""+ GetSexPhrase("Mon cher, quelles filles ?! La moitié de la garnison est à vos trousses, et vous venez au bordel !","Vous feriez mieux de filer d'ici... La moitié de la garnison est à vos trousses !") +"", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiote au point de vous accueillir en un moment pareil...", "Je vous prierai de quitter mon établissement, vous n'avez rien à faire ici !"),
					LinkRandPhrase(""+ GetSexPhrase("Essayez donc de toucher à mes filles, et je vous écorche vif !","Fichez le camp d'ici, espèce de garce !") +"", "Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Tu ferais mieux de te taire, idiote...", "Ferme-la, sinon ce sera pire..."));
				link.l1.go = "exit";
				break;
			}
			//homo Линейка Блада
            if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
            {
                dialog.Text = LinkRandPhrase("Tiens, docteur Blood ! " + TimeGreeting() + ".",
                                    "Ravie de vous voir, Peter Blood.",
                                    "C'est gentil de passer me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
                Link.l1 = "Hélas, je m'en vais déjà, " + NPChar.name + ". א plus tard.";
				Link.l1.go = "exit";
				break;
            }
			//-->> квест Кольцо Жозефины Лодет
			if (CheckAttribute(pchar, "questTemp.PDM_PK_UvestiNaVerh") && npchar.city == "SantoDomingo") 
			{
				dialog.text = "Que puis-je pour vous, " + GetAddress_Form(NPChar) + " ?";
				link.l1 = "וcoutez, " + npchar.name + ", j'aimerais passer un moment avec l'une de vos filles, je crois qu'elle s'appelle Francesca.";
				link.l1.go = "PDM_PK_UvestiNaVerh";
				break;
			}
			//<<-- квест Кольцо Жозефины Лодет
			//-->> квест пожертвования в церковь
			//результаты
			if (npchar.questChurch == "baster")
			{
				dialog.text = "Vous avez pris l'argent, mais vous ne l'avez pas donné ! Un vrai salaud, en un mot ! Je ne vous servirai plus dans mon établissement. Dehors !";
				link.l1 = "Hum, bon sang !";
				link.l1.go = "exit";
				link.l2 = "וcoutez, je comprends que vous m'en vouliez. Je le regrette sincèrement. Mais j'aimerais vous poser une question, et je pense que vous avez tout intérêt à y répondre.";
				link.l2.go = "quests";//(перессылка в файл города)
				break;
			}
			if (npchar.questChurch == "taken")
			{

				if (!CheckAttribute(pchar, "HellSpawnFinished"))
				{
					dialog.text = "Vous n'avez pas donné l'argent à l'église. Faites-le, vous avez jusqu'à la fin de la journée ! Vous me l'aviez promis !";
					link.l1 = "Oui, je m'en souviens. Je m'en occupe.";
					link.l1.go = "exit";
					break;
				}
				else
				{
					dialog.text = "Vous voilà de retour...";
					link.l1 = "J'ai vraiment essayé de vous aider en portant l'argent à l'église. Mais il s'avère que les bonnes actions sont contre-indiquées pour les gens comme moi. א cause de ma tentative, beaucoup d'innocents sont morts. Reprenez votre argent, je ne peux pas vous aider.";
					link.l1.go = "ResultChurch_2";
					break;
				}
			}
			if (npchar.questChurch == "yes")
			{
				dialog.text = "Vous avez fait le don ?";
				link.l1 = "Oui, j'ai tout fait. Le padre m'a demandé de vous dire que l'église avait accepté votre argent.";
				link.l1.go = "ResultChurch_1";
				break;
			}
			if (npchar.questChurch == "no")
			{
				dialog.text = "Vous avez fait le don ?";
				link.l1 = "וcoutez, " + npchar.name + " - l'église n'a pas voulu de votre argent. Je vous le rends.";
				link.l1.go = "ResultChurch_2";
				break;
			}

			//-->> дача развода на секс
			if (rand(3) == 1 && pchar.questTemp.different == "free" && PChar.sex != "woman" && GetNpcQuestPastDayWOInit(npchar, "questSex") > 180 && !CheckAttribute(npchar, "quest.selected") && !CheckAttribute(npchar, "quest.NotGoneToSex.over"))
			{
				if (!CheckAttribute(npchar, "quest.NotGoneToSex"))
				{
					dialog.text = "Oh, qu'on s'ennuie dans notre ville. Peut-être qu'un capitaine en vue comme vous saura chasser mon ennui ?";
					link.l5 = "Absolument ! Ce sera un plaisir de divertir une si belle dame.";
					link.l5.go = "toHostessSex";
					link.l8 = "Malheureusement, je n'ai pas le temps, " + npchar.name + ". Une autre fois...";
					link.l8.go = "exit";
					pchar.questTemp.different = "HostessSex";
					SetTimerFunction("SmallQuests_free", 0, 0, 1); //освобождаем разрешалку на миниквесты
					SaveCurrentNpcQuestDateParam(npchar, "questSex");
				}
				else
				{
					dialog.text = "La dernière fois, je vous ai attendu dans la chambre à l'étage, et vous n'êtes pas venu... Vous avez laissé passer votre chance.";
					link.l1 = "Oh, quel dommage...";
					link.l1.go = "exit";
					npchar.quest.NotGoneToSex.over = true; //больше вообще не говоить
				}
				break;
			}
			//<<-- развод на секс

			if (npchar.quest.meeting == "0")
			{
				dialog.text = RandPhraseSimple(TimeGreeting() + ". Bienvenue dans notre maison close. Je m'appelle " + npchar.name + ", c'est moi qui m'occupe de tout ici. "+ GetSexPhrase("Que puis-je faire pour vous, " + GetAddress_Form(NPChar) + "","J'avoue être un peu surprise de vous voir ici, " + GetAddress_Form(NPChar) + ", mais je peux vous assurer que nos services ne s'adressent pas qu'aux hommes.") +"",
				                               "Bienvenue dans mon humble établissement, "+ GetSexPhrase("étranger","ma belle") +". Permettez-moi de me présenter, je suis "+ NPChar.Name + ", la maîtresse de ce refuge pour les hommes en mal de tendresse. "+ GetSexPhrase("Que puis-je pour vous ?","Encore que nous ayons aussi de quoi satisfaire les femmes...") +"");
				npchar.quest.meeting = "1";
			}
			else
			{
				dialog.text = RandPhraseSimple(TimeGreeting() + ". Que puis-je faire pour vous, " + GetAddress_Form(NPChar) + " ?",
				                               TimeGreeting() + ". En quoi puis-je vous être utile, " + GetAddress_Form(NPChar) + " ?");
			}
			if (!CheckAttribute(pchar, "GenQuest.BrothelLock"))// нет запрета от Мэри
			{
				link.l2 = npchar.name + ", j'aimerais passer un moment avec l'une de vos filles.";
				link.l2.go = "Hostess_1";
			}
			link.l3 = "דa fait longtemps que je n'ai pas gâté mes gars. Je peux passer une commande en gros, pour les filles ?";
			link.l3.go = "ForCrew";
			link.l4 = "Vous avez l'air soucieuse, n'est-ce pas, "+npchar.name+" ?";
			link.l4.go = "works";
			link.l5 = "J'ai une question.";
			if (CheckCharacterItem(pchar, "CaptainBook") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakBrothelMadam"))
			{
				if((pchar.questTemp.different.GiveShipLetters.city == npchar.city) && CheckAttribute(pchar, "questTemp.different.GiveShipLetters"))
				{
					link.l4.go = "ShipLetters_1";// генератор  
				}
				else
				{
					link.l4.go = "quests";
				}
			}
			else
			{
			link.l5.go = "quests";//(перессылка в файл города)
			}
			//-->> квест поиска кольца мэра
			if (pchar.questTemp.different == "TakeMayorsRing" && pchar.questTemp.different.TakeMayorsRing.city == npchar.city && GetNpcQuestPastDayWOInit(npchar, "TakeMayorsRing") > 7)
			{
				link.l6 = "וcoutez, " + npchar.name + ", je cherche la bague du gouverneur. Il a fait la fête chez vous l'autre jour, et il l'a perdue.";
				link.l6.go = "TakeMayorsRing_H1";
				SaveCurrentNpcQuestDateParam(npchar, "TakeMayorsRing");
			}
			//<<-- квест поиска кольца мэра
			if (CheckAttribute(pchar,"drugstaken") && pchar.drugstaken >= 3)
			{
				link.l7 = "Je ne me sens pas bien. On dirait que la troisième pipe était de trop.";
				link.l7.go = "tubeheal";
			}
			link.l9 = "Rien. Je m'en vais déjà.";
			link.l9.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "tubeheal":
			pchar.questTemp.drugsprice = 1000*MOD_SKILL_ENEMY_RATE*3;
			dialog.text = "On dirait que vous avez vraiment fumé une saleté, capitaine. Heureusement, je peux vous aider. Mais cela prendra un peu de temps et vous coמtera "+pchar.questTemp.drugsprice+" piastres. Alors, d'accord ?";
			if (sti(pchar.money) >= sti(pchar.questTemp.drugsprice))
			{
				link.l1 = "Tout ce que vous voudrez, pourvu que ça passe.";
				link.l1.go = "tubeheal_1";
			}
			link.l2 = "Plutכt pas.";
			link.l2.go = "exit";
		break;

		case "tubeheal_1":
			AddMoneyToCharacter(pchar,-sti(pchar.questTemp.drugsprice));
			ClearDrugs();
			WasteTime(12);
			dialog.text = "Eh bien, vous avez bien meilleure mine maintenant. Je suppose que vous vous sentez parfaitement bien, non ?";
			link.l1 = "Absolument ! Je vous suis très reconnaissant"+GetSexPhrase(".","e.");
			link.l1.go = "exit";
		break;

		case "ShipLetters_1":
				pchar.questTemp.different.GiveShipLetters.speakBrothelMadam = true;
				dialog.text = RandPhraseSimple("Que voulez-vous, beau gosse ?","Je vous écoute attentivement, capitaine.");
				link.l1 = "וcoutez, " + npchar.name + ", j'ai trouvé ces papiers dans le salon particulier de votre établissement...";
				link.l1.go = "ShipLetters_2";
		break;
		case "ShipLetters_2":
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Voyons voir ! Hum... Un capitaine inconnu aurait perdu ces documents ? Je pense qu'il faudrait poser la question au maître de port.";
				link.l1 = "Peut-être, peut-être...";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Voyons voir ! Oh ! D'après le nom, ils appartiennent à l'un de mes estimés clients, un honorable citoyen de notre ville. Je peux lui remettre les documents moi-même.";
				link.l1	= "Plutכt pas...";
				link.l1.go = "exit";
				link.l2 = "Parfait ! C'est toujours un plaisir d'aider une personne respectable et un établissement convenable.";
				link.l2.go = "ShipLetters_3";
			}
		break;

		case "ShipLetters_3":
			TakeItemFromCharacter(pchar, "CaptainBook");
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "2");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;


		//#20171211-02 Allow reconciling with Hostess if promised donation missed.
		case "Reconcile_1":
		    sld = GetFreeHorseRef(npchar.city);
            int nRand = rand(1) + 2;
            int nPrice = sti(sld.quest.price) * nRand;
            //string sPrice = FindRussianMoneyString(nPrice);
            pchar.quest.reconcileHostess = nPrice;
            dialog.text = strreplace("Mon Dieu, j'admets entièrement que c'est ma faute, mais pour être honnête, j'ai été distraite et j'ai oublié le don promis. Y a-t-il un moyen de vous dédommager ?", "#thisamount", FindRussianMoneyString(nPrice));
            if (sti(pchar.money) >= nPrice)
            {
                link.l1 = "Eh bien, je suppose que oui. Et si vous me rendiez #thisamount ?";
                link.l1.go = "Reconcile_2";
                link.l2 = "Bien sמr. Tenez.";
                link.l2.go = "exit";
            }
            else
            {
                Link.l1 = "Pas question.";
                Link.l1.go = "exit";
            }
        break;
        case "Reconcile_2":
            AddMoneyToCharacter(pchar, -sti(pchar.quest.reconcileHostess));
            dialog.text = "Balivernes ! Laissez tomber.";
            link.l1 = "Très bien, poursuivez vos affaires. Et ne tentez plus votre chance à l'avenir.";
            link.l1.go = "exit";
            npchar.questChurch = "";
        break;
        case "Hostess_1":
			if (!CheckAttribute(npchar, "quest.selected"))
			{
				if (CheckNPCQuestDate(npchar, "quest.date"))
				{
					dialog.text = ""+ GetSexPhrase("Un client est toujours le bienvenu. Dites-moi, mon chou, vous avez déjà quelqu'un en vue, ou ça vous est égal ?","Eh bien, mes filles sauront vous aider... à vous aider. Vous avez quelqu'un en vue, ou ça vous est égal ?") +"";
					Link.l1 = ""+ GetSexPhrase("Hé, il me faut une fille tout de suite, et peu importe laquelle. Elles sont toutes mignonnes chez vous...","Oui, n'importe laquelle, pourvu qu'elle connaisse son affaire...") +"";
					Link.l1.go = "Hostess_NotChoice";
					Link.l2 = "Oui, il y en a une qui m'a plu...";
					Link.l2.go = "Hostess_Choice";
				}
				else
				{
					dialog.text = "Aujourd'hui, je ne peux plus vous donner de fille, j'ai d'autres clients que vous. Revenez demain, on s'occupera bien de vous !";
					Link.l1 = "Oh, quel dommage"+ GetSexPhrase(", j'y prenais tout juste goמt","") +"... Bon, tant pis.";
					Link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "Hum, vous avez déjà payé la fille. Alors occupez-vous d'elle de près, si j'ose dire, et ne me dérangez pas pour rien.";
				Link.l1 = "D'accord, j'y vais.";
				Link.l1.go = "exit";
			}
		break;

        case "Hostess_NotChoice":
			sld = GetFreeHorseRef(npchar.city);
			location = &locations[FindLocation(npchar.city + "_Brothel")];
			//#20171008-01 Brothel adjust changeover period
			if (sld.id == "none" || GetNpcQuestPastDayParam(location, "Brothel_date") > (BROTHEL_CHANGEDAYS - 2)) //98)
			{
				dialog.text = "Je n'ai aucune fille de libre pour le moment, il faudra revenir dans quelques jours.";
				Link.l1 = "D'accord, comme vous voudrez.";
				Link.l1.go = "exit";
			}
			else
			{
				dialog.text = ""+ GetSexPhrase("Eh bien, mon étalon, parfait !","Elles sont toutes expertes, soyez-en sמre.") +" Je peux vous proposer une jolie fille du nom de " + GetFullName(sld) + ", elle est libre en ce moment. Ce plaisir vous coמtera " + FindRussianMoneyString(sti(sld.quest.price)) + ". D'accord ?";
				Link.l1 = "Non, je crois que je vais refuser. C'est un peu cher...";
				Link.l1.go = "exit";
				if (sti(pchar.money) >= sti(sld.quest.price))
				{
					Link.l2 = "Bien sמr que je suis d'accord, quelle question ?!";
					Link.l2.go = "Hostess_NotChoice_agree";
					npchar.quest.choiceIdx = sld.index;
				}
				else
				{
					Link.l1 = "Ah, je n'ai pas assez d'argent sur moi pour le moment...";
					Link.l1.go = "exit";
				}
			}
		break;
        case "Hostess_NotChoice_agree":
			sld = &characters[sti(npchar.quest.choiceIdx)];
			if (sti(pchar.money) >= sti(sld.quest.price))
			{
				/*if (rand(4) == 0 && pchar.sex != "woman" && !CheckAttribute(pchar,"NoPriest") && GetCharacterSPECIALSimple(pchar, SPECIAL_L) >= 8)
				{
					dialog.text = "Great, dear, " + sld.name + " he will be waiting for you in the privacy room on the second floor. I'm sure you'll be sooo pleased...");
					Link.l1 = "Heh, well, I'm off...";
					Link.l1.go = "exit";
					AddMoneyToCharacter(pchar, -sti(sld.quest.price));
					sld.greeting = "Gr_Church";
					sld.model = "priest_2";
					sld.model.animation = "man";
					sld.name = "Padre Pedro";
					sld.lastname = "";
					sld.Dialog.Filename = "Common_Brothel.c";
					sld.dialog.currentnode = "Priest1";
					pchar.NoPriest = true;
					pchar.PedroID = sld.id;
					pchar.quest.Pedro.win_condition.l1 = "location";
					pchar.quest.Pedro.win_condition.l1.location = npchar.city + "_Brothel_room";
					pchar.quest.Pedro.function = "Pedro_Horse";
				}
				else
				{*/
					dialog.text = "Parfait, mon chou,  " + sld.name + " vous attendra dans le salon particulier, au premier étage.";
					Link.l1 = ""+ GetSexPhrase("Hé, eh bien, j'y vais","Bon, j'y cours") +"...";
					Link.l1.go = "exit";
					AddMoneyToCharacter(pchar, -sti(sld.quest.price));
					sld.dialog.currentnode = "Horse_ReadyFack";
				//}
				//--> таймер на возврат, чтобы не вечно ждали
				str = npchar.city;
				pchar.quest.(str).win_condition.l1            = "Timer";
				pchar.quest.(str).win_condition.l1.date.day   = GetAddingDataDay(0, 0, 1);
				pchar.quest.(str).win_condition.l1.date.month = GetAddingDataMonth(0, 0, 1);
				pchar.quest.(str).win_condition.l1.date.year  = GetAddingDataYear(0, 0, 1);
				pchar.quest.(str).win_condition               = "Brothel_checkVisitTime";
				pchar.quest.(str).HorseId = sld.id;
				pchar.quest.(str).locator = sld.location.locator;
				//<-- таймер на возврат, чтобы не вечно ждали
				ChangeCharacterAddressGroup(sld, npchar.city + "_Brothel_room", "goto", "goto"+(rand(2)+1));
				LocatorReloadEnterDisable(npchar.city + "_Brothel", "reload2_back", false); //открываем комнату
				npchar.quest.selected = true; //флаг взял девку у хозяйки
				SetNPCQuestDate(npchar, "quest.date"); //дату взятия запишем
				for(int n=0; n<MAX_CHARACTERS; n++)
				{
					makeref(sld, Characters[n]);
					if (sld.location == npchar.city+"_Brothel" && CheckAttribute(sld, "CityType") && sld.CityType == "horse")
					{
						sld.dialog.currentnode = "Horse_4";
					}
				}

				// генератор найденных бумаг
				if ((rand(4) == 1) && (pchar.questTemp.different == "free") && (!CheckCharacterItem(pchar, "CaptainBook")) && GetNpcQuestPastDayWOInit(npchar, "questShipLetters") > 10)
				{
					pchar.questTemp.different = "GiveShipLetters";
					pchar.questTemp.different.GiveShipLetters = "toBrothel";
					pchar.questTemp.different.GiveShipLetters.Id = GetFullName(npchar);
					pchar.questTemp.different.GiveShipLetters.city = npchar.city;
					pchar.questTemp.different.GiveShipLetters.variant = rand(2);
					p1 = rand(20 - MOD_SKILL_ENEMY_RATE*3) + 1; // даём хотя бы один день
					s1 = rand(80 - pchar.rank - p1) * 50 + rand(100);
					s2 = s1 * 2;
					s3 = s1 * rand(GetCharacterSPECIAL(pchar, "Luck")) + s1;
					s4 = s2 + s3;
					s5 = s4 * GetCharacterSPECIAL(pchar, "Charisma");
					pchar.questTemp.different.GiveShipLetters.price1 = s1;
					pchar.questTemp.different.GiveShipLetters.price2 = s2;
					pchar.questTemp.different.GiveShipLetters.price3 = s3;
					pchar.questTemp.different.GiveShipLetters.price4 = s4;
					pchar.questTemp.different.GiveShipLetters.price5 = s5;

					sld = ItemsFromID("CaptainBook");
					sld.CityName = XI_ConvertString("Colony" + npchar.city + "Gen");
					//ложим бумаги в итем
					sTemp = "_Brothel_room";
					sTemp1 = "_town";
					sld.shown = true;
					sld.startLocation = pchar.questTemp.different.GiveShipLetters.city + sTemp;
					sld.startLocator = "item" + (rand(4)+1);
					sld.endLocation = pchar.questTemp.different.GiveShipLetters.city + sTemp1;
					pchar.questTemp.different.GiveShipLetters.item = true; //флаг -  бумаги валяются в итемах
					Log_QuestInfo("Les papiers se trouvent à l'emplacement " + sld.startLocation + ", au locator " + sld.startLocator + " p1 : " + p1);

					pchar.quest.CheckShipLetters.win_condition.l1 = "location";
					pchar.quest.CheckShipLetters.win_condition.l1.location = sld.endLocation;
					pchar.quest.CheckShipLetters.function = "CheckShipLetters";

					SetTimerFunction("GiveShipLetters_null", 0, 0, p1); //освобождаем разрешалку на миниквесты
					SaveCurrentNpcQuestDateParam(npchar, "questShipLetters");
				}

				// генератор - "A reason to hurry"
				if((rand(5) == 2) && !CheckAttribute(pchar, "questTemp.ReasonToFast") && GetNpcQuestPastDayWOInit(npchar, "questReasonToFast") > 20)
				{
					iColony = FindColony(npchar.city);
					if( sti(Colonies[iColony].HeroOwn) == false && npchar.city != "Panama" && npchar.city != "Charles")
					{
						pchar.questTemp.ReasonToFast = "Begin";
						pchar.questTemp.ReasonToFast.city = npchar.city;
						sTemp1 = "_town";
						pchar.quest.CheckReasonToFast.win_condition.l1 = "location";
						pchar.quest.CheckReasonToFast.win_condition.l1.location = npchar.city + sTemp1;
						pchar.quest.CheckReasonToFast.function = "ReasonToFast_CheckHorse";
						SaveCurrentNpcQuestDateParam(npchar, "questReasonToFast");
					}
				}

			}
			else
			{
				dialog.text = "Tout irait bien, mais le fait est que " + sld.name + " n'est pas donnée, elle vaut bien " + FindRussianMoneyString(sti(sld.quest.price)) + ". Et à ce que je vois, vous n'avez pas assez d'argent. Revenez quand vous serez riche"+ GetSexPhrase(", mon chéri","") +"...";
				Link.l1 = "Eh, c'est toujours pareil...";
				Link.l1.go = "exit";
			}
		break;

        case "Hostess_Choice":
			dialog.text = "Je suis toujours contente quand naissent de tendres sentiments entre les filles et les clients... Dites-moi son nom.";
			Link.l1.edit = 9;
			Link.l1 = "";
			Link.l1.go = "Hostess_Choice_1";
		break;
        case "Hostess_Choice_1":
			sld = CheckHorsesName(npchar.city, 9);
			if (sld.id == "none")
			{
				dialog.text = "Hum, vous faites erreur, je n'ai pas de fille de ce nom dans l'établissement. Vous écorchez peut-être son nom.";
				Link.l1 = "Hum, mais je viens de lui parler.";
				Link.l1.go = "Hostess_Choice_2";
				Link.l2 = "Je ferais peut-être mieux de vérifier son nom. On en reparlera plus tard.";
				Link.l2.go = "exit";
			}
			else
			{
				dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
				Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
				Link.l1.go = "Hostess_NotChoice_agree";
				Link.l2 = "Non, ce n'est pas elle.";
				Link.l2.go = "Hostess_Choice_2";
				npchar.quest.choiceIdx = sld.index;
			}
		break;
        case "Hostess_Choice_2":
			dialog.text = "Alors il faut me redire son nom, je comprendrai peut-être de qui vous parlez.";
			Link.l1.edit = 9;
			Link.l1 = "";
			Link.l1.go = "Hostess_Choice_1";
			Link.l2 = "Je ferais peut-être mieux de vérifier son nom. On en reparlera plus tard.";
			Link.l2.go = "exit";
		break;
		//==> команда
		case "ForCrew":
			dialog.text = "Hum... Pour tout l'équipage ? Alors, vous voulez que vos gars se détendent comme il faut ? Eh bien, j'ai quelques filles très qualifiées qui sauront s'en charger... Vous me devez " + FindRussianMoneyString(GetCrewQuantity(pchar)*30) + ".";
			link.l1 = "D'accord, j'accepte de payer cette somme.";
			link.l1.go = "ForCrew_1";
			link.l2 = "Je pense qu'ils se débrouilleront bien tout seuls...";
			link.l2.go = "exit";
		break;

		case "ForCrew_1":
		    if (sti(Pchar.money) >= GetCrewQuantity(pchar)*30 && GetCrewQuantity(pchar)>0)
		    {
		        AddMoneyToCharacter(Pchar, -makeint(GetCrewQuantity(pchar)*30));

	            AddCrewMorale(Pchar, 10);
	            LAi_Fade("", "");
                AddTimeToCurrent(5 + rand(1), rand(30));
			    DialogExit();
		    }
		    else
		    {
		        dialog.text = "Ce ne sont pas mes affaires, bien sמr, mais il me semble que vous devriez d'abord gagner de l'argent pour l'équipage, et penser à son moral ensuite.";
			    link.l1 = "Peut-être, oui...";
			    link.l1.go = "exit";
		    }
		break;
		case "Woman_FackYou":
			dialog.text = "Mon chou, oם allez-vous comme ça ?! Eh bien, vous aviez l'air d'un capitaine convenable...\nMaintenant, vous ne vous en tirerez pas comme ça, " + GetSexPhrase("beau gosse", "ma belle") + ". On va vous rogner les ailes...";
			link.l1 = "Tais-toi, idiote...";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
		break;
		//просьба о пожертвовании в церкви
		case "toChurch":
			dialog.text = "Voyez-vous, je tiens un établissement qui... Disons que ce n'est pas tout à fait banal.";
			link.l1 = "Je comprends.";
			link.l1.go = "toChurch_1";
		break;
		case "toChurch_1":
			dialog.text = "Bien... Mais cela ne veut pas dire que je ne pense pas à mon âme. Bref, je voudrais faire un don à l'église. Mais il m'est difficile de m'y montrer : les regards en coin, les épouses qui chuchotent...";
			link.l1 = "Compris. Je ferai le don pour vous, ne vous inquiétez pas.";
			link.l1.go = "toChurch_2";
		break;
		case "toChurch_2":
			pchar.questTemp.different.HostessChurch.money = (rand(4)+1) * 300;
			dialog.text = "Bien, prenez ces " + FindRussianMoneyString(sti(pchar.questTemp.different.HostessChurch.money)) +  " pièces d'or. Faites-le tout de suite, s'il vous plaît...";
			link.l1 = "Je m'en occupe tout de suite, ne vous inquiétez pas.";
			link.l1.go = "toChurch_3";
			link.l2 = "Vous savez, j'ai fort à faire en ce moment. Pardonnez-moi.";
			link.l2.go = "toChurch_4";
		break;
		case "toChurch_3":
			dialog.text = "Parfait ! Passez me voir plus tard pour me raconter comment ça s'est passé...";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			pchar.questTemp.different.HostessChurch.city = npchar.city; //город
			pchar.questTemp.different = "HostessChurch_toChurch";
			SetTimerFunction("HostessChurch_null", 0, 0, 1); //освобождаем разрешалку на миниквесты и чистим структуру
			AddMoneyToCharacter(pchar, sti(pchar.questTemp.different.HostessChurch.money));
			ChangeCharacterReputation(pchar, 0.30);

			if(pchar.sex == "skeleton")
			{
				location = &locations[FindLocation(npchar.city + "_Town")];
				pchar.HellSpawnLocation = location.id;
				LocatorReloadEnterDisable(pchar.HellSpawnLocation, "reload7_back", true);
				//id Города
				//Log_Info(pchar.HellSpawnLocation);
				SaveCurrentQuestDateParam("pchar.questTemp.HellSpawn");
				pchar.quest.HellSpawn.win_condition.l1 = "locator";
				pchar.quest.HellSpawn.win_condition.l1.location = pchar.HellSpawnLocation;
				pchar.quest.HellSpawn.win_condition.l1.locator_group = "reload";
				pchar.quest.HellSpawn.win_condition.l1.locator = "reload7_back";
				pchar.quest.HellSpawn.function = "HellSpawn";
			}

		break;
		case "toChurch_4":
			dialog.text = "Désolée, vraiment désolée...";
			link.l1 = "Une autre fois.";
			link.l1.go = "exit";
			pchar.questTemp.different = "free";
			DeleteAttribute(pchar, "questTemp.different.HostessChurch");
			npchar.questChurch = ""; //нулим личный флаг квеста
			ChangeCharacterReputation(pchar, -1);
		break;

		case "ResultChurch_1":
			dialog.text = "Dieu merci, tout n'est pas encore perdu pour moi dans cette vie !.. Merci.";
			link.l1 = "Je vous en prie."+ GetSexPhrase("Pour vous, " + npchar.name + ", je suis prêt à tout...","") +"";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 3);
			AddCharacterExpToSkill(pchar, "Sneak", 20);
			npchar.questChurch = ""; //нулим личный флаг квеста
		break;
		case "ResultChurch_2":
			if (!CheckAttribute(pchar, "HellSpawnFinished"))
			{
				dialog.text = "Comment ça, vous ne l'avez pas fait ?! Oh, vous n'avez pas su convaincre le saint père ! Et moi qui espérais tant...";
				link.l1 = "Pardonnez-moi, mais c'est arrivé comme ça...";
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, -2);
			}
			else
			{
				DeleteAttribute(pchar, "HellSpawnFinished")
				dialog.text = "Oui, j'ai vu par la fenêtre quel massacre avait lieu en ville. Je n'aurais jamais cru que ma petite requête puisse mener à un tel...";
				link.l1 = "La prochaine fois, réfléchissez à deux fois avant de demander à un mort-vivant de faire une bonne action. דa ne mène à rien de bon.";
				link.l1.go = "exit";
				PChar.HellSpawn.SeekRebirth = true;
				ChangeCharacterReputation(pchar, 12);
				LocatorReloadEnterDisable(pchar.HellSpawnLocation, "reload7_back", false);
			}


			npchar.questChurch = ""; //нулим личный флаг квеста
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.different.HostessChurch.money));
		break;
		//Квест Кольцо Жозефины Лодет
		case "PDM_PK_UvestiNaVerh":
			dialog.text = "Oh, "+ GetSexPhrase("beau gosse","ma belle") +", Francesca est l'une des meilleures filles de notre établissement. Il vous faudra payer 3 000 pièces d'or.";
			link.l1 = "Oui, bien sמr.";
			link.l1.go = "PDM_PK_UvestiNaVerh_2";
			link.l2 = "J'ai changé d'avis.";
			link.l2.go = "exit";
		break;
		case "PDM_PK_UvestiNaVerh_2":
			if (sti(pchar.Money) >= 3000)
			{
				dialog.text = "Parfait, "+ GetSexPhrase("mon chou","ma chère") +". Francesca vous attendra dans le salon particulier, au premier étage.";
				link.l1 = "Hé, j'y vais...";
				link.l1.go = "PDM_PK_UvestiNaVerh_3";
				AddMoneyToCharacter(pchar, -3000);
			}
			else
			{
				dialog.text = "";
				link.l1 = "וcoutez, je n'ai pas assez d'argent sur moi pour l'instant, mais je vous l'apporterai plus tard.";
				link.l1.go = "exit";
			}
		break;
		case "PDM_PK_UvestiNaVerh_3":
			DoQuestReloadToLocation("SantoDomingo_Brothel_room", "reload", "reload1_back", "");
			sld = CharacterFromID("PDM_PK_Francheska")
			ChangeCharacterAddressGroup(sld, "SantoDomingo_Brothel_room", "goto", "goto2");
			sld.dialog.filename   = "Quest\PDM\Poteryanoe_Koltso.c";
			sld.dialog.currentnode   = "NaVerhuSFrancheska";
			chrDisableReloadToLocation = true;
			DeleteAttribute(pchar, "questTemp.PDM_PK_UvestiNaVerh");
		break;
		//поиски кольца губернатора
		case "TakeMayorsRing_H1":
			dialog.text = "Je n'ai trouvé aucune bague.";
			link.l1 = "Et vos filles ?";
			link.l1.go = "TakeMayorsRing_H2";
		break;
		case "TakeMayorsRing_H2":
			dialog.text = "Les filles non plus. Si un client oublie ou perd quelque chose, elles me l'apportent toujours. Personne ne m'a apporté la bague du gouverneur.";
			link.l1 = "Je vois... Et si quelqu'un avait quand même décidé de la garder ?";
			link.l1.go = "TakeMayorsRing_H3";
		break;
		case "TakeMayorsRing_H3":
			dialog.text = "C'est peu probable. Les filles ont le droit de garder les cadeaux des clients, c'est tout.";
			link.l1 = "Je vois... Merci, " + npchar.name + ".";
			link.l1.go = "exit";
		break;
		//------- развод на секс ------------
		case "toHostessSex":
			dialog.text = "Vous êtes adorable. Alors, que comptez-vous faire pour me divertir ?";
			link.l1 = "Quoi ?! Euh... Mais avec quoi ! J'ai la plus grosse... Euh... réputation... parmi les pirates. Voilà.";
			link.l1.go = "toHostessSex_1";
			link.l2 = "J'ai l'œil vif et la main ferme, et puis...";
			link.l2.go = "toHostessSex_2";
			link.l3 = "Madame, j'en ai tant vu en ce monde...";
			link.l3.go = "toHostessSex_3";
		break;
		case "toHostessSex_1":
			dialog.text = "Votre « réputation » ne m'intéresse pas. Adieu...";
			link.l1 = "Comment ça... ?";
			link.l1.go = "exit";
		break;
		case "toHostessSex_2":
			if (rand(1))
			{
				dialog.text = "וcoutez ! א part vous vanter, vous connaissez d'autres sujets de conversation ?! Racontez-moi donc une histoire amusante !";
				link.l1 = "Oh ! Une histoire. C'est possible ! Alors voilà...";
				link.l1.go = "SpeakHistory";
			}
			else
			{
				dialog.text = "וcoutez ! א part vous vanter, vous connaissez d'autres sujets de conversation ?! Vous ne savez pas du tout divertir une femme...";
				link.l1 = "Hum, il y a plein de sujets intéressants à aborder.";
				link.l1.go = "SpeakHistoryTwo";
			}
		break;
		case "toHostessSex_3":
			dialog.text = "Allez donc pleurer dans le gilet d'un marchand en ville. Et ça se dit pirate ?! Mmm, oם sont passés les vrais hommes ?";
			link.l1 = "Ce n'est pas ce que je voulais dire !";
			link.l1.go = "exit";
		break;
		//истории
		case "SpeakHistory":
			dialog.text = "Je vous écoute attentivement...";
			if (rand(1))
			{
				link.l1 = "J'ai une histoire sur la fois oם j'ai failli être dévoré par un requin. Vous voulez l'entendre ?";
				link.l1.go = "SpeakHistory_1";
			}
			else
			{
				link.l1 = "Une fois, on a pris un marchand, une belle prise, je vous le dis, et dans sa cale ! De l'or et de l'argent !!! Mille tonnerres, c'est vrai ! Ha ha ! Et il avait aussi de jolies poulettes à bord, si propres, si bien faites, on les a bien pelotées...";
				link.l1.go = "SpeakHistory_2";
			}
		break;
		case "SpeakHistory_1":
			dialog.text = "Oh ! Vous avez été attaqué par un requin ! Comment avez-vous réussi à vous en sortir ?!";
			link.l1 = "Eh bien, reprenons dans l'ordre. Un jour, on s'est retrouvés en plein calme plat, pas un souffle de vent, et une chaleur terrible. On a décidé de se baigner pour se rafraîchir un peu. Quel plaisir, je vous le dis, de plonger dans l'eau après une chaleur étouffante. Et je me suis tellement laissé emporter à nager et à plonger que je n'ai pas entendu les cris de la vigie : '" + GetAddress_Form(PChar) + ", attention ! Un requin ! Un requin !!!'. Et c'est là que je l'ai vu ! Je venais de plonger et j'ai aperçu sa silhouette sous moi. Quel monstre !!! Cinq fois plus gros que moi ! א ce moment-là, il fait demi-tour et fonce droit sur moi !..";
			link.l1.go = "SpeakHistory_3";
		break;
		case "SpeakHistory_2":
			dialog.text = "דa suffit ! J'en ai assez ! Vous n'êtes qu'un prétentieux, un narcissique ! Hors de ma vue !";
			link.l1 = "Hum, et pourquoi donc ?";
			link.l1.go = "exit";
		break;
		case "SpeakHistory_3":
			dialog.text = "Oh mon Dieu ! Et alors ?!";
			link.l1 = "Je comprends que mon salut est entre mes mains, je fais demi-tour et je nage de toutes mes forces vers la chaloupe ; là, les gars essaient de chasser le requin à coups de feu, mais on ne chasse pas un tel monstre... Je n'étais plus qu'à sept yards de la chaloupe, et un énorme aileron se dressait déjà derrière moi...";
			link.l1.go = "SpeakHistory_4";
		break;
		case "SpeakHistory_4":
			dialog.text = "Et vous ?!..";
			link.l1 = "Non, pas moi. Le mousse. Notre brave mousse. Il a vu que je n'aurais pas le temps de rejoindre la chaloupe, et il m'a lancé un sabre.";
			link.l1.go = "SpeakHistory_5";
		break;
		case "SpeakHistory_5":
			dialog.text = "Et vous l'avez taillé en pièces ! Vraiment ?! Vous n'avez pas découpé ce monstre ?";
			link.l1 = "Eh bien, bien sמr que je l'ai taillé en pièces ! Deux coups de mon fidèle sabre, et le terrible monstre était vaincu !";
			link.l1.go = "SpeakHistory_6";
			link.l2 = "Non, je ne l'ai pas découpé. Voyons, comment découper une bête aussi énorme ! J'ai été sauvé autrement...";
			link.l2.go = "SpeakHistory_7";
		break;
		case "SpeakHistory_6":
			dialog.text = "Hi hi... Vous êtes un piètre menteur ! Découper dans l'eau un monstre cinq fois plus gros que vous ? Je ne vous crois pas, vous êtes un fanfaron comme les autres ! Vous ne m'intéressez pas...";
			link.l1 = "Diable !! Dommage, pourtant...";
			link.l1.go = "exit";
		break;
		case "SpeakHistory_7":
			dialog.text = "Et comment ?! Comment vous êtes-vous échappé ?";
			link.l1 = "J'ai à peine eu le temps de saisir mon sabre et de me retourner que j'ai vu d'énormes mâchoires pleines de dents terribles foncer sur moi. Et je n'ai eu d'autre choix que de planter le sabre entre elles, en espérant que l'acier résisterait à la puissante poussée des mâchoires ! Et en effet, le requin a secoué sa gueule et il est parti dans les profondeurs, en me frappant au passage si fort de sa queue que j'ai été projeté à la surface ! Le temps que le requin se débarrasse du sabre et revienne régler ses comptes avec moi, j'étais déjà dans la chaloupe, et les gars ramaient de toutes leurs forces vers le navire... En souvenir de cette histoire, il me reste quelques cicatrices.";
			link.l1.go = "SpeakHistory_8";
		break;
		case "SpeakHistory_8":
			dialog.text = "Oh ! Des cicatrices !.. Montrez-les-moi...";
			link.l1 = "Je vais vous montrer ça tout de suite ! Je vais vous montrer ça, et ça !..";
			link.l1.go = "SpeakHistory_9";
			link.l2 = "Les montrer ? Ici ?! Euh, je peux être grossier, bien sמr, mais me déshabiller devant une dame, dans une pièce oם des inconnus peuvent entrer... Je pourrais vous compromettre.";
			link.l2.go = "SpeakHistory_10";
		break;
		case "SpeakHistory_9":
			dialog.text = "Pouah, quel rustre ! Vous n'avez aucune idée de la façon de se conduire avec une dame ! Je ne veux plus vous parler !";
			link.l1 = "Hum, attendez, et pour... ?";
			link.l1.go = "exit";
		break;
		case "SpeakHistory_10":
			dialog.text = "Oh, comme vous êtes noble ! J'en ai même oublié un instant de quel établissement j'étais la patronne. Vous êtes sans doute un peu rustre et... direct, mais il y a quelque chose d'attirant chez vous... et puis, je suis toujours curieuse de voir vos cicatrices ; montons dans la chambre à l'étage, personne ne nous y dérangera... Et vous aurez peut-être envie d'y voir quelque chose, vous aussi...";
			link.l1 = "Hum, voilà qui change tout !..";
			link.l1.go = "exit";
			pchar.questTemp.different.HostessSex = "toRoom";
			pchar.questTemp.different.HostessSex.city = npchar.city;
			AddDialogExitQuestFunction("SexWithHostess_goToRoom");
			pchar.quest.SmallQuests_free.over = "yes";
			SetTimerFunction("SexWithHostess_null", 0, 0, 1); //возврат хозяйки на место, если ГГ не прийдет в комнату
		break;

		case "Hostess_inSexRoom":
			dialog.text = "Ah, vous voilà...";
			link.l1 = "C'est bien moi, ma reine !";
			link.l1.go = "exit";
			pchar.quest.SexWithHostess_null.over = "yes"; //нулим таймер на не пришёл
			NextDiag.TempNode = "First time";
			AddDialogExitQuestFunction("SexWithHostess_fack");

			//pchar.GenQuest.BrothelCount = sti(pchar.GenQuest.BrothelCount) + 1;
			AddCharacterExpToSkill(pchar, "Leadership", 100);
            		AddCharacterExpToSkill(pchar, "Fencing", -50);
            		AddCharacterExpToSkill(pchar, "Pistol", -50);
            		AddCharacterHealth(pchar, 10);
		break;

		case "SpeakHistoryTwo":
			dialog.text = "Par exemple ?";
			link.l1 = "Par exemple, vous. Vraiment, un sujet inépuisable !";
			link.l1.go = "SpeakHistoryTwo_1";
		break;
		case "SpeakHistoryTwo_1":
			dialog.text = "Prudence, vous marchez sur le fil du rasoir...";
			link.l1 = "J'adore le risque ! L'assaut et la pression, voilà ma devise ! Dès que je vous ai vue, j'ai su que vous deviez être à moi ! Je n'ai jamais vu de silhouette aussi charmante ! Quelles formes, mon Dieu !..";
			link.l1.go = "SpeakHistoryTwo_2";
			link.l2 = "Je ferai attention.";
			link.l2.go = "SpeakHistoryTwo_3";
		break;
		case "SpeakHistoryTwo_2":
			dialog.text = "J'ai bien peur que ces formes ne soient pas pour vous. Vous avez laissé passer votre chance, mon petit insolent...";
			link.l1 = "Diable, comment ça ?!";
			link.l1.go = "exit";
		break;
		case "SpeakHistoryTwo_3":
			dialog.text = "Hum, alors je suis tout ouïe...";
			link.l1 = "J'ai vu bien des femmes, et ce n'est que maintenant que je comprends que, hélas, toutes ne savent pas s'habiller avec autant de raffinement que vous. J'étais sot et aveugle...";
			link.l1.go = "SpeakHistoryTwo_4";
		break;
		case "SpeakHistoryTwo_4":
			dialog.text = "Pourquoi tant d'autocritique ?";
			link.l1 = "J'aurais dמ accourir vers vous tout de suite !";
			link.l1.go = "SpeakHistoryTwo_5";
		break;
		case "SpeakHistoryTwo_5":
			dialog.text = "Pour quoi faire ?";
			link.l1 = "Pour vous inviter à l'étage, ma reine !";
			link.l1.go = "SpeakHistoryTwo_6";
			link.l2 = "Il m'a fallu beaucoup de temps pour comprendre et voir cette vérité. Le monde est pauvre et terne sans vous, mais dès que vous apparaissez, tout reprend vie, les oiseaux chantent plus fort, le ressac murmure doucement et, dans les rayons du soleil matinal, les fleurs écloses brillent de rosée sur leurs pétales...";
			link.l2.go = "SpeakHistoryTwo_7";
		break;
		case "SpeakHistoryTwo_6":
			dialog.text = "דa suffit ! Vous êtes trop prétentieux. Vous avez laissé passer votre chance.";
			link.l1 = "Ah, raté...";
			link.l1.go = "exit";
		break;
		case "SpeakHistoryTwo_7":
			dialog.text = "Oh !.. Et en plus, vous êtes romantique... et flatteur !";
			link.l1 = "Flatteur ? Pas du tout ! Je dis la vérité. Et je parle, hélas, en peu de mots. Mais c'est parce que tous les mots se sont évaporés à la vue de vos deux adorables, incroyablement grands...";
			link.l1.go = "SpeakHistoryTwo_8";
		break;
		case "SpeakHistoryTwo_8":
			dialog.text = "Quoi ?!!";
			link.l1 = "...yeux brillants.";
			link.l1.go = "SpeakHistoryTwo_9";
		break;
		case "SpeakHistoryTwo_9":
			dialog.text = "Oh ! Je pensais à autre chose. Continuez, je vous en prie.";
			link.l1 = "א vrai dire, je ne pensais pas non plus qu'à vos yeux...";
			link.l1.go = "SpeakHistoryTwo_10";
			link.l2 = "Comment auriez-vous pu penser à autre chose ? Bien sמr, je ne parlais que des yeux.";
			link.l2.go = "SpeakHistoryTwo_15";
		break;
		case "SpeakHistoryTwo_10":
			dialog.text = "Ah oui ? Et à quoi d'autre ? J'ai même peur de deviner.";
			link.l1 = "א votre cou ravissant, à votre incroyable décolleté, et j'en ai le souffle coupé rien qu'à penser à la beauté de votre poitrine !";
			link.l1.go = "SpeakHistoryTwo_11";
		break;
		case "SpeakHistoryTwo_11":
			dialog.text = "Insolent !..";
			link.l1 = "Peut-être... Et vous allez sans doute me chasser, mais... En regardant votre belle robe, je n'arrête pas de penser à ce qu'il y a dessous. Oh, pardon, j'oubliais...";
			link.l1.go = "SpeakHistoryTwo_12";
		break;
		case "SpeakHistoryTwo_12":
			dialog.text = "Insolent et menteur... et...";
			link.l1 = "Quoi ?";
			link.l1.go = "SpeakHistoryTwo_13";
		break;
		case "SpeakHistoryTwo_13":
			dialog.text = "Charmant coquin...";
			link.l1 = "Suis-je pardonné ?";
			link.l1.go = "SpeakHistoryTwo_14";
		break;
		case "SpeakHistoryTwo_14":
			dialog.text = "Peut-être... On étouffe ici, montons à l'étage, il y fait plus frais, et nous continuerons... la conversation.";
			link.l1 = "Avec grand plaisir !";
			link.l1.go = "exit";
			pchar.questTemp.different.HostessSex = "toRoom";
			pchar.questTemp.different.HostessSex.city = npchar.city;
			AddDialogExitQuestFunction("SexWithHostess_goToRoom");
			pchar.quest.SmallQuests_free.over = "yes";
			SetTimerFunction("SexWithHostess_null", 0, 0, 1); //возврат хозяйки на место, если ГГ не прийдет в комнату
		break;

		case "SpeakHistoryTwo_15":
			dialog.text = "Ah oui ? Et moi qui croyais que l'ensemble vous intéressait, pas des détails isolés. Rien que les yeux ! Je n'ai donc rien d'autre à regarder ?!";
			link.l1 = "Ce n'est pas ce que je voulais dire...";
			link.l1.go = "SpeakHistoryTwo_16";
		break;
		case "SpeakHistoryTwo_16":
			dialog.text = "Je sais très bien ce que vous vouliez dire ! Laide, avec des yeux globuleux ! Voilà !!! Dehors ! Vous me dégoמtez !";
			link.l1 = "Qu'est-ce qui vous prend, " + npchar.name + ", je n'en avais aucune idée !..";
			link.l1.go = "exit";
		break;
		// ================================== рядовой состав =======================================
        case "Horse_talk":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("Vous feriez mieux de quitter l'établissement !", "Toute la garde de la ville rכde dans les rues ! Vous feriez mieux de partir...", "Vous avez fait une bêtise, et vous venez chez nous ?! Non, une autre fois..."),
					LinkRandPhrase("Dehors !!", "Sale assassin, hors d'ici ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Hé, quelle idiote tu fais...", "Ferme-la, sinon ce sera pire..."));
				link.l1.go = "exit";
				break;
			}
			dialog.text = NPCStringReactionRepeat("Bonjour, " + GetAddress_Form(NPChar) + GetSexPhrase("", ", hi hi..") +". Il faut vous adresser à la patronne de l'établissement, toutes les commandes passent par elle.",
				"Oh, c'est encore vous. Je suis désolée, mais il faut d'abord régler toutes les questions avec la patronne. Je vous prie d'aller la voir.",
				"וcoutez, " + GetAddress_Form(NPChar) + GetSexPhrase(", j'espère vraiment que vous êtes aussi têtu dans d'autres domaines, et pas seulement en paroles... ","") +"encore une fois, je vous prie d'aller voir la patronne de l'établissement.",
				"Ah, " + GetAddress_Form(NPChar) + ""+ GetSexPhrase(", ce que vous êtes... insistant !",", hi hi... Vous êtes pressée, dites donc.") +" Il faut aller voir la patronne de l'établissement pour passer commande.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Comme vous voudrez"+ GetSexPhrase(", ma belle,", "") +", j'ai compris.", "Oh, oui, vous avez raison...",
                      ""+ GetSexPhrase("Vous pouvez en être sמre, ma belle, je suis têtu et fort comme un taureau !","Oui, oui...") +"", ""+ GetSexPhrase("Zut, j'ai dמ rater quelque chose... Pardon, ma jolie.","D'accord.") +"", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			Link.l2 = "Et oם est-elle ?";
			Link.l2.go = "Horse_1";
			Link.l3 = LinkRandPhrase(""+ GetSexPhrase("Argh, ma belle, je pourrais me noyer dans tes yeux...","Tu es tout simplement magnifique, ma jolie !") +"", ""+ GetSexPhrase("Vous savez, je n'avais pas vu une aussi belle femme depuis longtemps !","Vous savez, je n'avais pas croisé une aussi jolie fille depuis longtemps !") +"", ""+ GetSexPhrase("Oh, ma chérie, tu es incroyablement adorable.","Oh, j'en ai assez de tous ces rustres... Et toi, tu es tout simplement charmante !") +"");
			if (!CheckAttribute(npchar, "quest.choice"))
			{
				Link.l3.go = "Horse_2";
			}
			else
			{
				Link.l3.go = "HorseChoice_" + npchar.quest.choice;
			}
			//-->> квест поиска кольца мэра
			if (pchar.questTemp.different == "TakeMayorsRing" && pchar.questTemp.different.TakeMayorsRing.city == npchar.city && GetNpcQuestPastDayWOInit(npchar, "TakeMayorsRing") > 7)
			{
				link.l5 = LinkRandPhrase("וcoutez, "+ GetSexPhrase("ma belle","ma chérie") +", vous n'auriez pas trouvé une bague de fiançailles ici ? Un homme l'a perdue ici...",
					"Ma chérie, vous n'auriez pas trouvé par hasard une bague de fiançailles dans votre établissement ?",
					"וcoutez, "+ GetSexPhrase("mon petit poisson","ma jolie") +"Vous n'auriez pas vu une bague ici, une bague de fiançailles ?");
				link.l5.go = "TakeMayorsRing_S1";
				SaveCurrentNpcQuestDateParam(npchar, "TakeMayorsRing");
			}
			//<<-- квест поиска кольца мэра
            //--> Голл. линейка, квест №8. базар с девокой о Библиии.
			if (pchar.questTemp.State == "SeekBible_toFFBrothel" || pchar.questTemp.State == "SeekBible_toGirl")
            {
    			if (npchar.id == "HorseGen_"+FindLocation("FortFrance_Brothel")+"_1")
				{
					if (!CheckAttribute(npchar, "quest.HolLineTalk"))
					{
						dialog.text = "Tout ce que désire "+ GetSexPhrase("ce beau pirate","cette brave fille") +", ce sera exaucé...";
    					link.l4 = "וcoutez, il y a quelque temps, Jackman et sa bande sont venus s'amuser ici...";
    					link.l4.go = "Step_Hol8_1";
					}
					else
					{
						dialog.text = "Vous avez apporté les mille ?";
						link.l4 = "Voici votre argent, dites-moi immédiatement tout ce que vous savez.";
    					link.l4.go = "Step_Hol8_5";
						AddMoneyToCharacter(pchar, -1000);
					}
				}
            }
			//<-- Голл. линейка, квест №8. базар с девокой о Библиии.
			NextDiag.TempNode = "Horse_talk";
		break;
        case "Horse_1":
			dialog.text = "Elle est dans son bureau, vous pouvez y aller par ici, par la porte en face de la sortie sur la rue, ou bien depuis la rue, de l'autre cכté de la maison. Elle s'appelle " + characters[GetCharacterIndex(npchar.city + "_Hostess")].name + ".";
			Link.l1 = "Je vois, "+ GetSexPhrase("mon chou","ma chérie") +"Merci.";
			Link.l1.go = "exit";
		break;
        case "Horse_2":
			if (rand(1))
			{
				dialog.text = LinkRandPhrase("Oh, mon Dieu, comme c'est agréable à entendre ! וcoutez, je suis libre en ce moment, alors si vous me choisissez, vous ne le regretterez pas...", "Vous le pensez vraiment ? J'en suis très, très flattée... וcoutez, je suis libre en ce moment, vous pouvez donc me choisir."+ GetSexPhrase("Je vous promets une mer d'amour et un océan de tendresse...","") +"", ""+ GetSexPhrase("Vraiment ?! Hum, je ne vous le cache pas, je suis flattée, on ne m'adresse pas souvent de tels mots...","Eh, ma fille... ce que ces types ont pu me fatiguer...") +"וcoutez, je ne suis pas occupée pour le moment, alors je vous propose de me choisir. Je vous promets que vous serez satisfait...");
				link.l1 = "Hé, c'est toi que je choisis !";
				Link.l1.go = "Horse_3";
				Link.l2 = ""+ GetSexPhrase("Non, c'était juste un compliment à une jolie dame","C'était juste un compliment") +".";
				Link.l2.go = "exit";
				npchar.quest.choice = 0; //был базар, но ГГ потом отказался
			}
			else
			{
				dialog.text = LinkRandPhrase(""+ GetSexPhrase("Vous savez ce que je vais vous dire, mon cher ? Je n'ai pas besoin de conversations creuses. Passez à l'action !","Eh bien, il ne me manquait plus que ça : des compliments de la part d'une femme !") +"", ""+ GetSexPhrase("Vous aussi, vous vous imaginez que toutes les femmes aiment avec leurs oreilles ? Hum, c'est peine perdue... Si vous me voulez, payez la patronne de l'établissement, et épargnez-moi ces bavardages.","Ma fille, ne perdez pas votre temps en paroles. Si vous voulez quelque chose, payez...") +"", ""+ GetSexPhrase("Encore un amateur de sentiments... Payez et je serai à vous, mais sans ces mièvreries !","Qu'est-ce qui vous prend, ma chérie ? Si vous voulez du plaisir, payez, et ne perdez pas votre temps à bavarder !") +"");
				link.l1 = "Eh bien, quel caractère !";
				Link.l1.go = "exit";
				npchar.quest.choice = 2; //ГГ послали
			}
		break;
        case "Horse_3":
			dialog.text = characters[GetCharacterIndex(npchar.city + "_Hostess")].name + " règle tout dans son bureau. Allez la voir"+ GetSexPhrase(", mon héros,","") +" et donnez-lui mon nom : " + npchar.name + ". Je vous attendrai...";
			Link.l1 = "Je vois, ma jolie, j'arrive bientכt...";
			Link.l1.go = "exit";
			npchar.quest.choice = 1; //она согласная
			SetNPCQuestDate(npchar, "quest.choice");
		break;
        case "Horse_4":
			dialog.text = NPCStringReactionRepeat("Vous avez déjà payé la fille, elle vous attend, montez.",
				"Je vous ai dit de monter la rejoindre.",
				"וcoutez bien, je vous le répète encore une fois : montez la rejoindre...",
				"Inutile de parler, ça ne rentre pas...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, je sais.", "Je m'en souviens.",
                      "Inutile de me le répéter, je ne l'oublie pas.", "Hum, de quoi parlez-vous..", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			NextDiag.TempNode = "Horse_4";
		break;
		//===>> реакция на попытки пофлиртовыть, если флирт уже был
        case "HorseChoice_0":
			if (!CheckAttribute(npchar, "quest.sexHappend"))
			{
				dialog.text = NPCStringReactionRepeat("Je ne vous comprends pas."+ GetSexPhrase(" Tantכt vous faites des compliments, tantכt vous faites marche arrière. Drכle de type...","") +"",
					"Encore vos compliments ? Hum, allez voir la patronne, réglez tout avec elle.",
					"Hum, vous ne vous lassez pas ? Je vous ai dit d'aller voir la patronne de l'établissement.",
					"Ici, on n'a pas le droit d'insulter les clients, mais vous cherchez vraiment les ennuis...", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("C'est arrivé comme ça, vous savez...", "D'accord, je vais le faire.",
						"Oui, oui, j'ai compris...", "Hum, pardon, ma chère.", npchar, Dialog.CurrentNode);
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Merci du compliment. Si vous voulez de moi, allez voir la patronne de l'établissement. Comme d'habitude...";
				Link.l1 = "Je vois.";
				Link.l1.go = "exit";
			}
		break;
        case "HorseChoice_1":
			if (!CheckAttribute(npchar, "quest.sexHappend"))
			{
				if (!CheckNPCQuestDate(npchar, "quest.choice"))
				{
					dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Mon chou, on s'est déjà tout dit.","") +"Ne me faites pas attendre trop longtemps...",
						""+ GetSexPhrase("Hum, écoutez, mon chou, pour moi,","Pour moi,") +" tous vos mots sont très agréables, mais il est temps de passer aux choses sérieuses...",
						"וcoutez, vous ne pourriez pas plutכt régler ça avec la patronne ?",
						"Pour rien au monde !", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("Absolument !", "Oui, bien sמr !",
							"Je cours, je cours voir la patronne...",  npchar, Dialog.CurrentNode);
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Je vous attendais, mais vous ne m'avez même pas touchée ! Je ne peux pas dire que j'en sois ravie...";
					Link.l1 = "Euh, c'est arrivé comme ça...";
					Link.l1.go = "exit";
					npchar.quest.choice = 0; //был базар, но ГГ потом отказался
				}
			}
			else
			{
				dialog.text = "Ah, c'est encore vous, "+ GetSexPhrase("brave corsaire","ma belle") +" ! Si vous avez de nouveau besoin de moi, allez voir la patronne, vous ne le regretterez pas..."+ GetSexPhrase("Au fait, je vous ai reconnu, mon cher, mais nous devons accueillir tous les clients de la même façon, désolée...","") +"";
				Link.l1 = "Attendez-moi juste un petit peu, "+ GetSexPhrase("ma belle","ma mignonne") +" et on remet ça.";
				Link.l1.go = "exit";
				Link.l2 = "Je suis très content que tu te souviennes de moi, mais malheureusement, je ne peux pas passer la nuit avec toi pour le moment.";
				Link.l2.go = "HorseChoice_1_Add";
			}
		break;
        case "HorseChoice_2":
			if (!CheckAttribute(npchar, "quest.sexHappend"))
			{
				dialog.text = NPCStringReactionRepeat("Je vais vous dire, "+ GetSexPhrase("cher ami,","") +" vous feriez mieux de passer à l'action. Ce sera plus utile que de bavarder.",
					""+ GetSexPhrase("Hum, vous êtes bizarre,","Eh bien, qu'est-ce que vous avez,") +" vous répétez toujours la même chose...",
					"וcoutez, vous allez arrêter, à la fin ?!",
					"Hum, eh bien, rien de nouveau"+ GetSexPhrase(", encore de stupides tentatives de séduction. Si vous voulez coucher avec moi, allez voir la patronne de l'établissement, idiot !","...") +"", "block", 1, npchar, Dialog.CurrentNode);
				link.l1 = HeroStringReactionRepeat("Oui, j'ai entendu...", "Hum, voilà comment ça tourne...",
						"Hum, peut-être que ça suffit, peut-être pas...", "Surveille ton langage"+ GetSexPhrase(", espèce de bouc","") +"...", npchar, Dialog.CurrentNode);
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Ah, c'est encore vous ! "+ GetSexPhrase(" Et encore ces éloges idiots, rien ne change en ce monde... ","Je vous rappelle, ") +" si vous voulez "+ GetSexPhrase("coucher ensemble","vous amuser") +", payez la patronne de l'établissement, vos belles paroles ne m'intéressent pas...";
				Link.l1 = "Hé, qui en douterait...";
				Link.l1.go = "exit";
			}
		break;
        case "HorseChoice_1_Add":
			dialog.text = "Hum, je ne peux pas dire que ça m'ait fait plaisir... Dommage.";
			Link.l1 = "Pardon...";
			Link.l1.go = "exit";
			npchar.quest.choice = 0;
		break;
		//===>> секс
		case "Priest1":
			chrDisableReloadToLocation = true;
			dialog.text = "Salut à toi, mon fils. Allons, approche...";
			Link.l1 = "Qu'est-ce que c'est que ce bordel ? Non, n'approchez pas...";
			Link.l1.go = "SpecialExit";
			//--> кол-во посещений
			if (!CheckAttribute(npchar, "quest.sexHappend")) npchar.quest.sexHappend = 1;
			else npchar.quest.sexHappend = sti(npchar.quest.sexHappend) + 1;
			pchar.GenQuest.BrothelCount = sti(pchar.GenQuest.BrothelCount) + 1; // для Данек
			if(CheckAttribute(PChar, "chr_ai.HeavyTrauma"))//лечение травмы в борделе - Gregg
			{
				DeleteAttribute(PChar, "chr_ai.TraumaQ");
				DeleteAttribute(PChar, "chr_ai.HeavyTrauma");
				Log_Info("Vous vous êtes remis d'une blessure grave");
				CheckAndSetOverloadMode(pchar);
			}
			//<-- кол-во посещений
			str = npchar.city;
			pchar.quest.(str).win_condition.l1 = "ExitFromLocation";
			pchar.quest.(str).win_condition.l1.location = pchar.location;
			pchar.quest.(str).win_condition = "Brothel_checkVisitTime";
			pchar.questTemp.HorseQty = sti(pchar.questTemp.HorseQty) + 1; //счётчик
			NextDiag.TempNode = "Priest2";
			AddDialogExitQuest("PlaySex_1");

			/// кач от борделя
			if (CheckNPCQuestDate(pchar, "BrothelSex"))
			{
				AddCharacterHealth(pchar, 5);
				SetNPCQuestDate(pchar, "BrothelSex");
			}
			// изменение статусов
			ChangeCharacterReputation(pchar, -1);
			AddCharacterExpToSkill(pchar, "Luck", 500);
			AddCharacterExpToSkill(pchar, "Leadership", -50);
			AddCharacterExpToSkill(pchar, "Fencing", -15);
			AddCharacterExpToSkill(pchar, "Pistol", -15);
		break;

		case "Priest2":
			dialog.text = "דa vous a plu ? Vous avez une sacrée chance, vous êtes le premier que j'ai baptisé de ma dignité ; vous pouvez aller faire toutes les affaires que vous voulez, Dieu vous pardonnera.";
			Link.l1 = "Je n'ai pas de mots, padre...";
			Link.l1.go = "exit_2";
			NextDiag.TempNode = "Priest3";
		break;

		case "Priest3":
			dialog.text = "דa suffit pour aujourd'hui. Vous pouvez partir en paix.";
			Link.l1 = "Bordel de merde...";
			Link.l1.go = "exit";
			NextDiag.TempNode = "Priest3";
		break;

        case "Horse_ReadyFack":
			if (!CheckAttribute(npchar, "quest.choice")) npchar.quest.choice = 0;
			switch(npchar.quest.choice)
			{
				case "0":
					dialog.text = RandPhraseSimple("Je suis ravie de vous voir dans le salon particulier. "+ GetSexPhrase("Et qu'est-ce qu'on fait maintenant ?","Alors, on va s'amuser ?") +"", "Entrez, ne soyez pas timide"+ GetSexPhrase(", faites comme chez vous pendant les deux prochaines heures.",". Je saurai m'occuper de vous... vous divertir, ne vous en faites pas.") +"");
					Link.l1 = RandPhraseSimple("On ne va pas s'ennuyer, je crois...", ""+ GetSexPhrase("Amusons-nous, ma jolie !","Ne perdons pas de temps !") +"");
				break;
				case "1":
					dialog.text = "Ah, vous voilà, "+ GetSexPhrase("mon glorieux corsaire ! Je vous ai promis quelque chose et je suis prête à tenir parole,","ma jolie ! Vous n'oublierez jamais les deux heures qui viennent") +"...";
					Link.l1 = "Eh bien, voilà qui est tentant...";
				break;
				case "2":
					dialog.text = "Vous voilà enfin. Allez, ne perdons pas de temps !";
					Link.l1 = ""+ GetSexPhrase("Ne traînons pas, ma chatte...","Eh bien, montre-moi ce que tu sais faire...") +"";
				break;
			}
			Link.l1.go = "exit";
			//--> кол-во посещений
			if (!CheckAttribute(npchar, "quest.sexHappend")) npchar.quest.sexHappend = 1;
			else npchar.quest.sexHappend = sti(npchar.quest.sexHappend) + 1;
			pchar.GenQuest.BrothelCount = sti(pchar.GenQuest.BrothelCount) + 1; // для Данек
			if(CheckAttribute(PChar, "chr_ai.HeavyTrauma"))//лечение травмы в борделе - Gregg
			{
				DeleteAttribute(PChar, "chr_ai.TraumaQ");
				DeleteAttribute(PChar, "chr_ai.HeavyTrauma");
				Log_Info("Vous vous êtes remis d'une blessure grave");
				CheckAndSetOverloadMode(pchar);
			}
			//<-- кол-во посещений
			str = npchar.city;
			pchar.quest.(str).win_condition.l1 = "ExitFromLocation";
			pchar.quest.(str).win_condition.l1.location = pchar.location;
			pchar.quest.(str).win_condition = "Brothel_checkVisitTime";
			pchar.questTemp.HorseQty = sti(pchar.questTemp.HorseQty) + 1; //счётчик
			NextDiag.TempNode = "Horse_AfterSex";
			AddDialogExitQuest("PlaySex_1");

			/// кач от борделя
			if (CheckNPCQuestDate(pchar, "BrothelSex"))
			{
				AddCharacterHealth(pchar, 5);
				SetNPCQuestDate(pchar, "BrothelSex");
			}
			// изменение статусов
			ChangeCharacterReputation(pchar, -1);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Fencing", -15);
			AddCharacterExpToSkill(pchar, "Pistol", -15);
		break;

        case "Horse_AfterSex":
			if (CheckAttribute(pchar, "questTemp.ReasonToFast") && pchar.questTemp.ReasonToFast == "Begin")
			{
				dialog.text = "Capitaine, pourquoi êtes-vous si peu bavard ?";
				link.l1 = LinkRandPhrase("Vraiment...", "On bavardera la prochaine fois.", RandPhraseSimple("Je ne te paie pas pour parler.", "Mais toi, "+ GetSexPhrase("ma jolie","ma chérie") +", tu chantais comme un rossignol."));
				link.l1.go = "exit";
				link.l2 = ""+ GetSexPhrase("Tu as été si merveilleuse que j'en suis resté sans voix ! Rares sont les femmes qui allient tant de beauté et de tempérament","Oh, tu sais encore comment faire plaisir à une femme... Je suis ravie.") +".";
				link.l2.go = "Horse_ReasonToFast_1";
			}
			else
			{
				switch(npchar.quest.choice)
				{
					case "0":
						dialog.text = LinkRandPhrase("דa vous a plu ?", "Alors, qu'en dites-vous ? Tout va bien ?", "Alors, "+ GetSexPhrase("corsaire, tout"," tout") +" va bien ?");
						Link.l1 = RandPhraseSimple(""+ GetSexPhrase("Bien sמr que tout va bien,","Et toi, tu es vraiment... Tu sais") +".", ""+ GetSexPhrase("Tout va bien, ma jolie","Tu sais, je suis plutכt satisfaite") +".");
						Link.l1.go = "exit";
					break;
					case "1":

						if (sti(npchar.quest.sexHappend) > (rand(4)+5) && sti(pchar.questTemp.HorseLoot) < 3 && !CheckAttribute(npchar, "questTemp.HorseLoot"))
						{
							dialog.text = "וcoutez, ça fait longtemps que vous venez me voir, je me suis tant attachée à vous...";
							Link.l1 = "Oui, et moi aussi je viens te voir, pourquoi...";
							Link.l1.go = "HorseQuest";
						}
						else
						{
							dialog.text = LinkRandPhrase("Alors, ai-je tenu ma promesse ?", "Alors, "+ GetSexPhrase("je vous ai plu","je vous ai plu") +" ?", "J'espère "+ GetSexPhrase("que vous êtes satisfait, parce que moi, j'ai adoré,","que vous êtes contente. J'ai fait de mon mieux") +"...");
							Link.l1 = RandPhraseSimple("Oui, tout m'a vraiment plu.", ""+ GetSexPhrase("On a passé un excellent moment, tu as été au top !","Tout était tout simplement merveilleux !") +"");
							Link.l1.go = "exit";
						}
					break;
					case "2":
						dialog.text = RandPhraseSimple("Eh bien, c'est l'heure.", "C'est l'heure, "+ GetSexPhrase("corsaire,","") +" il est temps de partir.");
						Link.l1 = RandPhraseSimple("Oui, salut...", "Au revoir, et merci...");
						Link.l1.go = "exit";
					break;
				}
				NextDiag.TempNode = "Horse_AfterSex_2";
			}
		break;
        case "Horse_AfterSex_2":
			if(CheckAttribute(pchar,"GenQuest.EncGirl") && pchar.GenQuest.EncGirl == "Bag_BrothelRoom" && !CheckCharacterItem(pchar, "leather_bag"))
			{
				dialog.text = "Alors, ça vous a plu chez nous ?";
				link.l1 = "וcoute, ma jolie, tu n'aurais pas vu une valise quelque part par ici ?";
				link.l1.go = "EncGirl_GetBag";
			}
			else
			{
				dialog.text = LinkRandPhrase("Revenez nous voir un de ces jours...", "Au revoir, et à bientכt...", "Nous serons heureuses de vous revoir...");
				Link.l1 = "D'accord...";
				Link.l1.go = "exit";
				NextDiag.TempNode = "Horse_AfterSex_2";
			}
		break;

		case "EncGirl_GetBag":
			dialog.text = "C'est un coffre marron avec une poignée ?";
			link.l1 = "Oui, quelque chose comme ça...";
			link.l1.go = "EncGirl_GetBag1";
		break;

		case "EncGirl_GetBag1":
			dialog.text = "Comme on n'a pas retrouvé le propriétaire de ce coffre, Madame l'a emporté dans son boudoir.";
			link.l1 = "Merci, ma jolie. Au revoir.";
			link.l1.go = "exit";
			pchar.GenQuest.EncGirl = "Bag_BrothelHostess";
			NextDiag.TempNode = "Horse_AfterSex_2";
		break;
		//==> квест на лут
        case "HorseQuest":
			pchar.questTemp.HorseLoot = sti(pchar.questTemp.HorseLoot) + 1;
			npchar.questTemp.HorseLoot = true; //уже давала
			dialog.text = "Vous savez quoi, je voudrais vous dire quelque chose, ça pourra peut-être vous aider...";
			Link.l1 = "Hum, dites"+ GetSexPhrase(", ma chérie",", je vous écoute") +".";
			Link.l1.go = "HorseQuest_1";
		break;
        case "HorseQuest_1":
			dialog.text = "Récemment, un de mes clients était complètement ivre. Il parlait d'un trésor sur la cכte du Continent, il promettait de faire fortune...";
			Link.l1 = "Ce ne sont peut-être que des bavardages d'ivrogne.";
			Link.l1.go = "HorseQuest_2";
		break;
        case "HorseQuest_2":
			dialog.text = "Peut-être bien. Mais je ne pense pas qu'il se soit souvenu de quoi que ce soit ensuite, donc sa langue s'est déliée malgré lui.";
			Link.l1 = "Il a parlé d'un endroit précis ?";
			Link.l1.go = "HorseQuest_3";
		break;
        case "HorseQuest_3":
			sTemp = LinkRandPhrase("Shore55", "Shore9", "Shore_ship2");
			if (sTemp == "Shore55")
			{
				str = "la baie de San Juan del Norte";
				str1 = "box" + (rand(1)+1);
			}
			if (sTemp == "Shore9")
			{
				str = "la baie d'Amatique";
				str1 = "box1";
			}
			if (sTemp == "Shore_ship2")
			{
				str = "le golfe du Destin, près de Belize";
				str1 = "box2";
			}
         	pchar.GenQuestBox.(sTemp) = true;
			switch (pchar.questTemp.HorseLoot)
			{
				case "1":
					pchar.GenQuestBox.(sTemp).(str1).items.spyglass2 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry1 = 4;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry5 = 6;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry10 = 2;
					pchar.GenQuestBox.(sTemp).(str1).items.indian11 = 1;
					pchar.GenQuestBox.(sTemp).(str1).money = 15000;
				break;
				case "2":
					pchar.GenQuestBox.(sTemp).(str1).items.spyglass3 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry14 = 3;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry16 = 2;
					pchar.GenQuestBox.(sTemp).(str1).items.jewelry18 = 4;
					pchar.GenQuestBox.(sTemp).(str1).items.indian17 = 1;
					pchar.GenQuestBox.(sTemp).(str1).money = 19000;
				break;
				case "3":
					pchar.GenQuestBox.(sTemp).(str1).items.indian20 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.indian5 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.indian10 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.spyglass4 = 1;
					pchar.GenQuestBox.(sTemp).(str1).items.indian19 = 1;
					pchar.GenQuestBox.(sTemp).(str1).money = 24000;
				break;
			}
			dialog.text = "Il parlait tout seul de " + str + ".";
			Link.l1 = "Eh bien, merci pour l'information. Si un jour je m'y décide, j'irai jeter un œil à cet endroit.";
			Link.l1.go = "exit";
		break;

		// --> генератор - "A reason to hurry"
		case "Horse_ReasonToFast_1":
			dialog.text = "Alors revenez, je serai toujours contente de vous voir... Vous êtes si "+ GetSexPhrase("gentil, mon chou, pas comme les autres","gentille, ma belle, pas comme ces types") +" : ni bonjour, ni au revoir, et en plus ils cherchent à vous vexer...";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "Horse_ReasonToFast_2";
		break;

		case "Horse_ReasonToFast_2":
			pchar.questTemp.ReasonToFast.speakHorse = true;
			dialog.text = "Oui, il y avait un sergent de la garde juste avant vous. D'habitude, il ne vient pas chez nous, mais là, quelque chose l'a poussé. Et il m'a choisie... Il s'est agité, agité, puis il m'a traitée d'incapable et il est parti en courant vers je ne sais quelle baie. Il est parti si vite qu'il en a presque oublié son pantalon, ha ha ha...";
			link.l1 = "Vous ne savez donc pas, "+ GetSexPhrase("ma belle","ma chère") +" comment sont les hommes ? Il a dit à sa femme qu'il allait au bordel, à sa maîtresse qu'il était pressé de rejoindre sa femme, et il est allé patrouiller dans la baie. "+ GetSexPhrase("Ho ho ho ho !..","Ha ha ha !") +"";
			link.l1.go = "Horse_ReasonToFast_3";
		break;

		case "Horse_ReasonToFast_3":
			NextDiag.TempNode = "Horse_AfterSex_2";
			ReOpenQuestHeader("ReasonToFast");
			AddQuestRecord("ReasonToFast", "1");
			pchar.questTemp.ReasonToFast = "SpeakHorse";
			pchar.questTemp.ReasonToFast.GuardNation = npchar.nation;
			pchar.questTemp.ReasonToFast.cantSpeakOther = true;
			ReasonToFast_InitVariables();
			string TargetLocation = SelectQuestShoreLocation();
			if(TargetLocation != "") {
				Locations[FindLocation(TargetLocation)].DisableEncounters = true;
				pchar.quest.ReasonToFast_MeetPatrol.win_condition.l1 = "location";
				pchar.quest.ReasonToFast_MeetPatrol.win_condition.l1.location = TargetLocation;
				pchar.quest.ReasonToFast_MeetPatrol.function = "ReasonToFast_MeetPatrolShore";
				pchar.questTemp.ReasonToFast.PatrolLocation = TargetLocation;
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		// <-- генератор "A reason to hurry"

		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Exit_2":
			AddSimpleRumour("Vous savez ce que j'ai entendu ? C'est à n'y pas croire ! Le curé de notre église a décidé de passer du cכté obscur et il a couché avec une personne très influente et connue dans tout l'archipel.", sti(npchar.nation), 10, 1);
			npchar.lifeDay = 0;
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "", "", "", "OpenTheDoors_Priest", -1);
			chrDisableReloadToLocation = true;
			DialogExit();
		break;
		//поиски кольца мэра
		case "TakeMayorsRing_S1":
			if (CheckAttribute(pchar, "questTemp.different.TakeMayorsRing.item")) //если валяется в итемах
			{
				dialog.text = LinkRandPhrase("Non, "+ GetSexPhrase("mon chou","ma chère") +", malheureusement, je ne suis pas tombée dessus. J'aimerais vous aider, mais je ne peux pas...",
					"Non, "+ GetSexPhrase("beau gosse","ma belle") +", je n'ai pas vu la bague...",
					"Malheureusement, non. Je n'ai vu aucune bague.");
				link.l1 = "Dommage... Eh bien, merci.";
				link.l1.go = "exit";
			}
			else
			{
				if (npchar.id == "HorseGen_"+reload_location_index+"_1")
				{
					dialog.text = "C'est de la bague du gouverneur que vous parlez ?";
					link.l1 = "Exactement, ma jolie !";
					link.l1.go = "TakeMayorsRing_S2";
				}
				else
				{
					dialog.text = LinkRandPhrase("Non, "+ GetSexPhrase("mon chou","ma chère") +", malheureusement, je ne suis pas tombée dessus. J'aimerais vous aider, mais je ne peux pas...",
						"Non, "+ GetSexPhrase("beau gosse","ma belle") +", je n'ai pas vu la bague...",
						"Malheureusement, non. Je n'ai vu aucune bague.");
					link.l1 = "Dommage... Eh bien, merci.";
					link.l1.go = "exit";
				}
			}
		break;

		case "TakeMayorsRing_S2":
			dialog.text = "Désolée, mais cette bague, on me l'a offerte ! Je n'ai donc pas à la rendre.";
			link.l1 = "Offerte ?! Par qui ?";
			link.l1.go = "TakeMayorsRing_S3";
		break;
		case "TakeMayorsRing_S3":
			dialog.text = "Par le gouverneur lui-même, bien sמr !";
			link.l1 = "C'est qu'il était un peu éméché, pour ne pas dire plus. Il ne se souvient de rien du tout.";
			link.l1.go = "TakeMayorsRing_S4";
		break;
		case "TakeMayorsRing_S4":
			dialog.text = "Et alors, qu'est-ce que j'y peux ? S'il n'avait plus toute sa tête, c'est son problème !";
			link.l1 = "וcoute, ma chérie, c'est le gouverneur. Pourquoi te brouiller avec lui ? C'est une bague de fiançailles, tu comprends... Rends-la, ne t'attire pas d'ennuis pour une si petite chose.";
			link.l1.go = "TakeMayorsRing_S5";
		break;
		case "TakeMayorsRing_S5":
			if (rand(1) && sti(pchar.money)>5000)
			{
				dialog.text = "Je vous donnerai la bague, mais vous me paierez cinq mille piastres.";
				link.l1 = "D'accord, prends ton argent et donne-moi la bague.";
				link.l1.go = "TakeMayorsRing_S6";
			}
			else
			{
				dialog.text = "Hum, d'accord. Qu'il la reprenne !..";
				link.l1 = "Absolument, ma chérie !";
				link.l1.go = "exit";
				GiveItem2Character(pchar, "MayorsRing");
				pchar.questTemp.different.TakeMayorsRing = "HorseTakenRing";
				AddQuestRecord("SeekMayorsRing", "3");
				AddQuestUserData("SeekMayorsRing", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
				AddQuestUserData("SeekMayorsRing", "sName", GetFullName(npchar));
			}
		break;
		case "TakeMayorsRing_S6":
			dialog.text = "Tenez...";
			link.l1 = "Eh bien, parfait. Merci de ton aide, ma chérie.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -5000);
			GiveItem2Character(pchar, "MayorsRing");
			pchar.questTemp.different.TakeMayorsRing = "HorseTakenRingMoney";
			AddQuestRecord("SeekMayorsRing", "2");
			AddQuestUserData("SeekMayorsRing", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("SeekMayorsRing", "sName", GetFullName(npchar));
		break;
//********************************* Диалоги девки из борделя ФФ **********************************
  		case "Step_Hol8_1":
			dialog.text = "Et alors ?";
			link.l1 = "J'ai entendu dire qu'un des pirates proposait à la vente une sorte de livre, une sorte de Bible...";
			link.l1.go = "Step_Hol8_2";
		break;
  		case "Step_Hol8_2":
			dialog.text = "C'est bien ça, je m'en souviens... וcoutez, "+ GetSexPhrase("beau gosse, montons à l'étage","ma belle, payez-moi") +" et je répondrai à toutes vos questions. Il ne vous en coמtera que 1000 pièces...";
			link.l1 = ""+ GetSexPhrase("J'ai juste besoin de savoir quelque chose...","Vous faites quoi que ce soit gratuitement, au moins ?") +"";
			link.l1.go = "Step_Hol8_3";
		break;
  		case "Step_Hol8_3":
			dialog.text = ""+ GetSexPhrase("D'accord, je répondrai à toutes vos questions. Mais seulement à l'étage : ce n'est pas un endroit pour parler.","Hi hi hi... Vous avez besoin d'informations, moi d'argent. Si vous voulez, je peux vous donner non seulement des informations, mais aussi autre chose, si on monte à l'étage... Je vous connais. Seulement, ce sera plus cher, hi hi...") +"";
			link.l1 = ""+ GetSexPhrase("Ah, je n'ai pas le temps...","Je n'ai pas de temps pour ces bêtises.") +"";
			link.l1.go = "Step_Hol8_4";
		break;
  		case "Step_Hol8_4":
			dialog.text = ""+ GetSexPhrase("Oh, voilà un homme qui a peur de la tendresse d'une femme !!!","Oh, allez... Donnez-moi mille pièces, et je vous dirai tout ce que je sais.") +"";
            if (sti(pchar.money) >= 1000)
            {
    			link.l1 = "Voici votre argent, mais dites-moi ce que vous savez, ici et maintenant.";
    			link.l1.go = "Step_Hol8_5";
                AddMoneyToCharacter(pchar, -1000);
            }
            else
            {
    			link.l1 = ""+ GetSexPhrase("Je n'ai peur de rien, c'est juste que je n'ai pas d'argent...","") +"Je reviendrai dès que j'aurai les mille pièces...";
    			link.l1.go = "exit";
				npchar.quest.HolLineTalk = true;
            }
			NextDiag.TempNode = "Horse_talk";
		break;
		case "Step_Hol8_5":
			dialog.text = "Laurent de Graaf disait alors qu'il pouvait vendre un livre rare, une sorte de Bible.";
			link.l1 = "Hum, et alors ?";
			link.l1.go = "Step_Hol8_6";
		break;
		case "Step_Hol8_6":
			dialog.text = "Ils l'ont tourné et retourné entre leurs mains. Il y a un crucifix gravé sur la couverture, et impossible de comprendre de quel livre il s'agit. Il était écrit dans une langue inconnue, personne n'a même pu dire à peu près de quelle écriture il s'agissait.";
			link.l1 = "Hum, puisqu'il est à vendre, j'aimerais bien l'acheter. Comment puis-je trouver ce corsaire ?";
			link.l1.go = "Step_Hol8_7";
    	break;
		case "Step_Hol8_7":
			dialog.text = "Allez directement à Tortuga, c'est là que vous le trouverez. Comme je vous l'ai dit, il s'appelle Laurent de Graaf, c'est un célèbre flibustier, un Hollandais.";
			link.l1 = "Merci, j'y vais.";
			link.l1.go = "Step_Hol8_8";
    	break;
		case "Step_Hol8_8":
			dialog.text = "Dites, ce livre vaut vraiment de l'argent ?";
			link.l1 = "Difficile à dire, il faut le voir. Et qu'a dit de Graaf ? D'oם sait-il ce qu'il sait sur ce livre ?";
			link.l1.go = "Step_Hol8_9";
    	break;
		case "Step_Hol8_9":
			dialog.text = "Rien de spécial, personne ne l'écoutait vraiment. On avait autre chose en tête, et certainement pas la Bible...";
			link.l1 = "Compris. Merci, je vais aller chercher de Graaf.";
			link.l1.go = "exit";
			AddQuestRecord("Hol_Line_8_SeekBible", "4");
			AddQuestUserData("Hol_Line_8_SeekBible", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.State = "SeekBible_toTavern";
			NextDiag.TempNode = "Horse_talk";
    	break;
		//Даёт работу здесь Хозяйка
		case "works":
			//-->> дача квеста пожертвования в церковь
			if (rand(2) == 1 && pchar.questTemp.different == "free" && NPChar.GenQuest.BrothelQuest.GiveQuestDay != lastspeak_date && GetNpcQuestPastDayWOInit(npchar, "questChurch") > 45 && GetHour() < 20)
			{
				dialog.text = "וcoutez, j'ai un service à vous demander...";
				link.l1 = "Je vous écoute attentivement.";
				link.l1.go = "toChurch";
				//личные флаги хозяйки на взятие квеста
				npchar.questChurch = "taken";
				SaveCurrentNpcQuestDateParam(npchar, "questChurch");
				break;
			}
			//<<-- квест пожертвования в церковь
			dialog.text = "Nous allons bien. Merci de votre sollicitude.";
			link.l9 = "Si tout va bien, je vais vaquer à mes affaires.";
			link.l9.go = "exit";
			NPChar.GenQuest.BrothelQuest.GiveQuestDay = lastspeak_date;		// Если не дала сегодня, то токо на след день.
		break;
	}
}


ref GetFreeHorseRef(string City)
{
	ref rCharacter;
    int storeArray[8];
	int howStore = 0;
	for(int n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(rCharacter, Characters[n]);
		if (rCharacter.location == City+"_Brothel" && CheckAttribute(rCharacter, "CityType") && rCharacter.CityType == "horse")
		{
			storeArray[howStore] = n;
			howStore++;
		}
	}
	if (howStore == 0) return &NullCharacter;
	return &characters[storeArray[rand(howStore-1)]];
}

ref CheckHorsesName(string City, int num)
{
	ref rCharacter;
	string sTemp, sSeeked;
	sSeeked = GetStrSmallRegister(dialogEditStrings[num]);
	for(int n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(rCharacter, Characters[n]);
		if (rCharacter.location == City+"_Brothel" && CheckAttribute(rCharacter, "CityType") && rCharacter.CityType == "horse")
		{
			sTemp = GetStrSmallRegister(GetFullName(rCharacter));
			if (findsubstr(sSeeked, sTemp , 0) != -1)
				return rCharacter;
			sTemp = GetStrSmallRegister(rCharacter.lastname);
			if (findsubstr(sSeeked, sTemp , 0) != -1)
				return rCharacter;
			sTemp = GetStrSmallRegister(rCharacter.name);
			if (findsubstr(sSeeked, sTemp , 0) != -1)
				return rCharacter;
		}
	}
	return &NullCharacter;
}
