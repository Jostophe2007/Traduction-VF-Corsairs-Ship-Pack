void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, Diag;
	int i, iRnd, iRnd1;
	string sTemp, sGems;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit_1":
			AddDialogExitQuest("LandEnc_RapersTalk");
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "exit":
			LAi_SetCitizenTypeNoGroup(npchar);
			//#20200315-01
            npchar.chr_ai.type.checkFight = 999999.0;
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "Begin_1":
			LAi_RemoveCheckMinHP(npchar);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_type_actor_Reset(sld);
			}
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("Capitaine", "Mademoiselle") +" ! Pitié, protégez-moi ! Je vous en prie !", "Au secours ! "+ GetSexPhrase("וtranger", "Mademoiselle") +" ! Sauvez-moi, je vous en supplie !");
			link.l1 = LinkRandPhrase("Que s'est-il passé ?", "Qu'est-ce qui n'allait pas ?",RandPhraseSimple("Qu'y a-t-il ?", "Que se passe-t-il ?"));
			link.l1.go = "Begin_11";
		break;

		case "Begin_2":
			LAi_RemoveCheckMinHP(NPChar);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_type_actor_Reset(sld);
			}
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("Capitaine ! Capitaine", "Mademoiselle ! Mademoiselle") +", attendez !", "Attendez, "+ GetSexPhrase("capitaine", "mademoiselle") +" ! S'il vous plaît.");
			link.l1 = LinkRandPhrase("Que s'est-il passé ?", "Qu'est-ce qui n'allait pas ?",RandPhraseSimple("Qu'y a-t-il ?", "Que se passe-t-il ?"));
			link.l1.go = "Begin_21";
		break;

		case "Begin_3":
			LAi_RemoveCheckMinHP(NPChar);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_type_actor_Reset(sld);
			}
			dialog.text = "Ah, qui que vous soyez, aidez une pauvre fille, je vous en prie ! Ces gens préparent un mauvais coup !";
			link.l1 = LinkRandPhrase("Que s'est-il passé ?", "Qu'est-ce qui n'allait pas ?",RandPhraseSimple("Qu'y a-t-il ?", "Que se passe-t-il ?"));
			link.l1.go = "Begin_31";
		break;

		case "Begin_11":
			dialog.text = RandPhraseSimple("Ces gredins veulent abuser de moi ! Pour l'amour de Dieu, ne les laissez pas faire !", "Pour l'amour du Christ, protégez-moi de ces monstres ! Ils veulent me déshonorer !");
			link.l1 = "Pas de panique"+ GetSexPhrase(", ma belle", "") +". On va régler ça tout de suite.";
			link.l1.go = "exit_1";
		break;

		case "Begin_21":
			dialog.text = RandPhraseSimple("Des violeurs me poursuivent !"+ GetSexPhrase(" Sauriez-vous défendre l'honneur d'une dame ?", "") +"", "Capitaine, "+ GetSexPhrase("soyez un homme", "vous êtes une femme courageuse") +" : sauvez une jeune fille du déshonneur !");
			link.l1 = "Pas de panique"+ GetSexPhrase(", ma belle", "") +". On va régler ça tout de suite.";
			link.l1.go = "exit_1";
		break;

		case "Begin_31":
			dialog.text = "On me poursuit... Des bandits me poursuivent ! Dites-leur de me laisser tranquille !";
			link.l1 = "Pas de panique"+ GetSexPhrase(", ma belle", "") +". On va régler ça tout de suite.";
			link.l1.go = "exit_1";
		break;

		case "First time":
			LAi_RemoveCheckMinHP(npchar);
			for(i = 1; i <= 3; i++)
			{
				if (GetCharacterIndex("GangMan_" + i) == -1) continue;
				sld = CharacterFromID("GangMan_" + i);
				LAi_type_actor_Reset(sld);
			}
			dialog.text = LinkRandPhrase("א l'aide ! א l'aide ! Ces gens me suivent ! Sauvez-moi !",
				"Ah ! א l'aide, "+ GetSexPhrase("étranger", "mademoiselle") +" ! Sauvez-moi de ces gredins !",
				"Pitié, protégez-moi de ces gredins ! Je vous en prie !");
			Link.l1 = LinkRandPhrase("Que se passe-t-il ?", "Qu'y a-t-il ?", "Que s'est-il passé ?");


			Link.l1.go = "Node_2";
		break;

		case "Node_2":
			dialog.text = LinkRandPhrase("Ils... Ils veulent abuser de moi ! Je vous en supplie, ne les laissez pas faire ! Sauvez-moi !",
				"Ces brutes... elles veulent me faire quelque chose d'horrible... Protégez-moi d'elles, je vous en prie !",
				"Au nom de notre Seigneur, protégez-moi de ces monstres lubriques ! Ils veulent me déshonorer !");
			Link.l1 = "D'accord, voyons ça tout de suite.";
			Link.l1.go = "exit_1";
		break;

		case "ThanksForHelp":
			if(pchar.GenQuest.EncGirl == "Begin_11")
			{
				if(rand(1) == 0)
				{
					dialog.text = RandPhraseSimple("Merci, "+ GetSexPhrase("capitaine", "mademoiselle") +". J'ai eu si peur !", "Merci de m'avoir sauvée ! Je vous suis si reconnaissante !");
					link.l1 = "Voilà, "+ GetSexPhrase("ma belle", "ma chérie") +", calmez-vous : tout est fini maintenant.";
					link.l1.go = "Node_11";
				}
				else
				{
					dialog.text = "Ah, merci, "+ GetSexPhrase("noble seigneur ! Vous êtes un vrai gentilhomme !", "mademoiselle ! Vous m'avez sauvée !") +"";
					link.l1 = "Je ne pouvais pas faire autrement.";
					link.l1.go = "Node_12";
				}
			}
			if(pchar.GenQuest.EncGirl == "Begin_22")
			{
				if(rand(1) == 0)
				{
					dialog.text = "Ah, merci, "+ GetSexPhrase("noble seigneur ! Vous êtes un vrai gentilhomme !", "ma sauveuse ! Vous m'avez sauvé la vie !") +"";
					link.l1 = "Je ne pouvais pas faire autrement.";
					link.l1.go = "Node_12";
				}
				else
				{
					dialog.text = "Qu'avez-vous fait ?! Pourquoi les avez-vous tués ?! Maintenant, ils vont me rechercher ! Mon Dieu, pourquoi suis-je punie ainsi ?!";
					link.l1 = "Voilà comment on me remercie !";
					link.l1.go = "Node_22";
				}
			}
			if(pchar.GenQuest.EncGirl == "Begin_33")
			{
				dialog.text = "Mais qu'avez-vous fait, "+ GetSexPhrase("capitaine", "mademoiselle") +" ?! Pourquoi les avez-vous tués ?! C'est vraiment mon père qui les avait envoyés !.. Mon Dieu ! Il va me tuer...";
				link.l1 = "דa alors ! Et à quoi pensiez-vous quand vous criiez que des bandits vous poursuivaient ?!";
				link.l1.go = "Node_31";
			}
		break;

		case "Node_11":
			Diag.TempNode = "ThanksAgain";
			addMoneyToCharacter(pchar, makeint((sti(pchar.rank))*25 + frand(2)*500));
			dialog.text = "J'ai un peu d'argent sur moi, ne le dédaignez pas : prenez-le en signe de gratitude. Je vais raconter à tout le monde "+ GetSexPhrase("quel homme noble et courageux vous êtes", "quelle femme noble et courageuse vous êtes") +".";
			link.l1 = "D'accord, d'accord, racontez. Merci... Maintenant, rentrez chez vous.";
			link.l1.go = "exit";
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			Diag.CurrentNode = Diag.TempNode;
		break;

		case "Node_12":
			dialog.text = "Je n'arrive toujours pas à m'en remettre. Ne voudriez-vous pas "+ GetSexPhrase("raccompagner une dame", "me raccompagner") +" jusqu'à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + " ? C'est que maintenant, je vois des violeurs derrière chaque buisson.";
			link.l1 = RandPhraseSimple("Ne vous inquiétez pas tant... Bon, allons-y.", "Pourquoi êtes-vous si peureuse ? Allez, je vous raccompagne.");
			link.l1.go = "Node_121Next";
			link.l2 = "Je regrette, ma jolie, je n'ai pas le temps : des affaires m'attendent.";
			link.l2.go = "Node_3End";
		break;

		case "Node_22":
			dialog.text = "Je pensais que vous alliez juste leur faire peur !.. Vous devez m'emmener à la taverne de " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ". Je n'ai personne d'autre vers qui me tourner.";
			link.l1 = "Oh, merde ! Allons-y. Suivez-moi de près.";
			link.l1.go = "Node_122Next";
			link.l2 = "Oh non, "+ GetSexPhrase("ma belle", "ma chérie") +" ! Assez de surprises pour aujourd'hui. Cherchez-vous un autre protecteur.";
			link.l2.go = "Node_3End";
		break;

		case "Node_31":
			dialog.text = "Que devais-je faire ?! Mon père veut me marier au fils d'un usurier, ce baveux... Tout ça parce que son papa a plein de piastres dans ses coffres. Et moi, j'en aime un autre ! Emmenez-moi auprès de lui, je vous en prie.";
			link.l1 = "Il ne manquait plus que ça ! Bon, oם allez-vous maintenant ? Comment s'appelle votre élu, et oם dois-je vous conduire ?";
			link.l1.go = "Node_32";
			link.l2 = "Oh non, "+ GetSexPhrase("ma belle", "ma chérie") +" ! Assez de surprises pour aujourd'hui. Cherchez-vous un autre protecteur.";
			link.l2.go = "Node_3End";
		break;

		case "Node_32":
			pchar.GenQuest.EncGirl.sLoverId = GenerateRandomName(sti(npchar.nation), "man");
			dialog.text = "Il s'appelle " + pchar.GenQuest.EncGirl.sLoverId + ", il n'est pas d'ici. En ce moment, il vit à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ", il y cherchait du travail, mais c'est difficile en ce moment. Tout le monde dit que c'est la crise... Et de toute façon, je ne peux plus rentrer chez moi maintenant.";
			link.l1 = "La crise, vous dites ? Eh bien, eh bien... Pour un vrai pirate, la crise, c'est quand il y a un convoi à l'horizon et un calme plat sur la mer...";
			link.l1.go = "Node_12Next";
		break;

		case "Node_12Next":
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			Diag.TempNode = "Node_12End";
			Diag.CurrentNode = Diag.TempNode;
			pchar.GenQuest.EncGirl = "FindLover";
			pchar.GenQuest.EncGirl.MeetSoldiers = 2;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
		break;

		case "Node_121Next":
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			Diag.TempNode = "Node_253";
			pchar.GenQuest.EncGirl = "FindCoins";
			pchar.GenQuest.EncGirl.MeetSoldiers = 1;
			Diag.CurrentNode = Diag.TempNode;
			pchar.quest.EncGirl_DeathSimple.win_condition.l1 = "NPC_Death";
			pchar.quest.EncGirl_DeathSimple.win_condition.l1.character = npchar.id;
			pchar.quest.EncGirl_DeathSimple.function = "EncGirl_DeathSimple";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_town";
			pchar.quest.EncGirl_DeliveBack.function = "EncGirl_DeliveBack";
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
		break;

		case "Node_122Next":
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			Diag.TempNode = "Node_12End";
			pchar.GenQuest.EncGirl = "HorseToTavern";
			pchar.GenQuest.EncGirl.MeetSoldiers = 1;
			Diag.CurrentNode = Diag.TempNode;
			pchar.quest.EncGirl_DeathSimple.win_condition.l1 = "NPC_Death";
			pchar.quest.EncGirl_DeathSimple.win_condition.l1.character = npchar.id;
			pchar.quest.EncGirl_DeathSimple.function = "EncGirl_DeathSimple";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_tavern";
			pchar.quest.EncGirl_DeliveBack.function = "EncGirl_DeliveBack";
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
		break;

		case "Node_12End":
			Diag.TempNode = "Node_12End";
			dialog.text = RandPhraseSimple("Vous savez, "+ GetSexPhrase("capitaine", "mademoiselle") +", j'ai eu si peur que mes genoux en tremblent encore.", "Oh, j'ai eu une de ces peurs. Heureusement que Dieu vous a envoyé à temps.");
			link.l1 = RandPhraseSimple("Dieu merci, vous êtes saine et sauve.", "Ne vous en faites pas. Le principal, c'est que tout se soit bien terminé.");
			link.l1.go = "exit";
		break;

		case "Node_1Next": //не исользуется эта ветка... а ведёт к кладам и жемчугу
			dialog.text = RandPhraseSimple("Merci, "+ GetSexPhrase("capitaine", "mademoiselle") +", encore une fois. Je ne sais comment vous remercier.", "Merci beaucoup, "+ GetSexPhrase("capitaine", "mademoiselle") +". Je n'ose même pas imaginer ce que je serais devenue sans votre intervention.");
			link.l1 = RandPhraseSimple("Désormais, ça vous servira de leçon. Bon, bonne journée...", "Vous serez plus prudente la prochaine fois... Allez, rentrez chez vous, des affaires m'attendent.");
			link.l1.go = "Node_1End";
			link.l2 = "Peut-on être aussi imprudente ? Que faites-vous seule dans la jungle ?";
			link.l2.go = "Node_13";
		break;

		case "Node_1End":
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_3End":
			Diag.TempNode = "Node_3Final";
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			ChangeCharacterReputation(pchar, -3);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "Node_3Final":
			Diag.TempNode = "Node_3Final";
			dialog.text = RandPhraseSimple("Vous avez changé d'avis ?", "Capitaine, c'est bien que vous ayez changé d'avis !");
			link.l1 = RandPhraseSimple("Non, non, ma chère, sans moi.", "N'y comptez même pas...");
			link.l1.go = "exit";
		break;

		case "Node_13":
			pchar.GenQuest.EncGirl = "Begin_11";
			switch(sti(pchar.GenQuest.EncGirl.variant))
			{
				case 0:
					if(rand(1) == 0)
					{
						dialog.text = "Vous allez sans doute rire... Je cueillais de quoi faire un philtre d'amour... Une sorcière m'a dit qu'il existe une racine qui aide dans les affaires de cœur.";
						link.l1 = "Mon Dieu ! "+ GetSexPhrase("Qu'est-ce que les femmes vont s'imaginer", "Qu'est-ce que vous êtes allée imaginer") +" ?! Vous avez dמ en cueillir beaucoup, pour qu'une meute entière de soupirants vous coure après : vous avez eu du mal à les repousser. Ha ha ha ha... Bon, portez-vous bien.";
						link.l1.go = "Node_1End";
					}
					else
					{
						dialog.text = "J'avais juste décidé de me promener, de prendre l'air, de cueillir des herbes... Oui, j'ai dמ sortir au mauvais moment.";
						link.l1 = "Quelle imprudence ! Dieu merci, tout s'est bien terminé... Bon, bonne journée.";
						link.l1.go = "Node_1End";
					}
				break;
				case 1:
					dialog.text = "Ma maîtresse a égrené un collier de perles quelque part par ici pendant sa promenade. En rentrant, elle s'est mise à crier et m'a envoyée le chercher. Elle m'a dit : « Ne reviens pas avant d'avoir ramassé les perles. »... Et je ne connais même pas vraiment l'endroit. Et comment les retrouver, de toutes petites perles dans une herbe pareille ? Je tourne en rond, je ne sais pas quoi faire.";
					link.l1 = "Quel genre de collier ? Il serait peut-être moins cher d'en acheter un neuf que d'errer dans la jungle on ne sait oם ? Il y avait beaucoup de perles ?";
					link.l1.go = "Node_131";
				break;
				case 2:
					dialog.text = "J'ai hérité la carte de mon défunt père, mais ses amis ont voulu me la prendre. Du vivant de mon père, tout le monde tremblait devant lui, mais dès que je l'ai enterré, je n'ai plus eu de répit. D'abord, ils ont essayé de me racheter la carte, et quand j'ai refusé, ils se sont mis à me menacer. ";
					link.l1 = "Pourquoi ne l'avez-vous pas vendue ? Qu'a donc cette carte pour que des pirates la cherchent en bandes entières ?";
					link.l1.go = "Node_132";
				break;
			}
		break;

		case "Node_131":
			pchar.GenQuest.EncGirl.SmallCoins = rand(25) + 20;
			pchar.GenQuest.EncGirl.BigCoins = rand(15) + 5;
			dialog.text = "Il y avait là des perles de choix. On n'en trouve pas de pareilles à bas prix. Le collier comptait " + sti(pchar.GenQuest.EncGirl.BigCoins) + " grosses perles et " + sti(pchar.GenQuest.EncGirl.SmallCoins) + " petites. Si l'on pouvait retrouver de telles perles, on pourrait faire refaire un collier semblable sur commande.";
			link.l1 = "Oui, votre maîtresse vous a confié une tâche difficile... Eh bien, cherchez, puisqu'on vous l'a ordonné. Bonne journée.";
			link.l1.go = "Node_131End";
			link.l2 = "Votre entreprise est vaine... Chercher des perles dans une telle herbe, c'est comme chercher une aiguille dans une botte de foin. D'autant plus que vous ne connaissez pas l'endroit exact...";
			link.l2.go = "Node_133";
		break;

		case "Node_131End":
			Diag.TempNode = "Node_12End";
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			ChangeCharacterReputation(pchar, -2);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			pchar.quest.LandEnc_RapersBadExit.win_condition.l1 = "ExitFromLocation";
			pchar.quest.LandEnc_RapersBadExit.win_condition.l1.location = pchar.location;
			pchar.quest.LandEnc_RapersBadExit.win_condition = "LandEnc_RapersBadExit";
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_132":
			pchar.GenQuest.EncGirl.mapOwner = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			dialog.text = "Mon père y a marqué l'endroit oם il a caché ses trésors. Vous n'avez jamais entendu parler du célèbre pirate " + GetName( NAMETYPE_ORIG, pchar.GenQuest.EncGirl.mapOwner, NAME_VOC) + " ?";
			link.l1 = "Non, je n'en ai jamais entendu parler.";
			link.l1.go = "Node_132_1";
		break;

		case "Node_132_1":
			dialog.text = "Eh bien, " + GetName( NAMETYPE_ORIG, pchar.GenQuest.EncGirl.mapOwner, NAME_NOM) + " était mon père. Tout le monde avait peur de lui, personne n'osait même souffler mot. Maintenant, bien sמr, ils sont devenus insolents. Quand j'ai refusé de vendre la carte, ils ont dit qu'ils avaient eux aussi leur part dans ce trésor. J'ai voulu cacher la carte, mais ils m'ont retrouvée...";
			link.l1 = "Pourquoi la cacher ? Louez un navire et allez chercher vos trésors. Votre père ne les a pas cachés pour rien, si ?";
			link.l1.go = "Node_132_2";
		break;

		case "Node_132_2":
			dialog.text = "Facile à dire. Je n'ai pas d'argent pour un bateau, et j'ai peur... Comment vais-je tout déterrer, tout traîner... Et l'emporter oם ? N'importe qui me volera en chemin, et me prendra même la vie...";
			link.l1 = "Oui, c'est vrai... Bon, allez cacher votre carte. Seulement, n'oubliez pas l'endroit ensuite.";
			link.l1.go = "Node_132_2End";
			if(GetCharacterItem(pchar, "map_full") == 0)
			{
				link.l2 = "Hum, c'est juste. Dans ce cas, il valait mieux la vendre.";
				link.l2.go = "Node_132_3";
			}
			link.l3 = "Avez-vous essayé de trouver un compagnon de voyage ?";
			link.l3.go = "Node_132_8";
		break;

		case "Node_132_2End":
			Diag.TempNode = "Node_12End";
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_132_3":
			dialog.text = "Excusez-moi... Mon père m'a dit combien il avait caché là-bas. Qui va me payer une telle somme ?";
			link.l1 = "וcoutez, ne soyez pas gourmande. Aucun or ne vaut qu'on y laisse sa tête. Et vous n'auriez plus aucun souci : vous prenez l'argent et vous partez le sourire aux lèvres...";
			link.l1.go = "Node_132_4";
		break;

		case "Node_132_4":
			pchar.GenQuest.EncGirl.mapPrice = 20000 + 500 * sti(pchar.rank);
			dialog.text = "C'est tentant, bien sמr... Et combien m'en offrez-vous ?";
			link.l1 = "Je ne pense pas qu'elle puisse valoir plus de " + sti(pchar.GenQuest.EncGirl.mapPrice) + " piastres.";
			link.l1.go = "Node_132_5";
		break;

		case "Node_132_5":
			if((GetSummonSkillFromName(pchar, SKILL_COMMERCE) + GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) + GetSummonSkillFromName(pchar, SKILL_FORTUNE)) > (rand(220) + 100) && (makeint(pchar.money) >= sti(pchar.GenQuest.EncGirl.mapPrice)))
			{
				dialog.text = "Oh, le sort des femmes... J'accepte. Je vais enfin être débarrassée de ce cauchemar... Mieux vaut que cette carte vous revienne"+ GetSexPhrase(" - à vous, noble seigneur -", "") +" plutכt qu'à des escrocs.";
				link.l1 = "Voilà. Prenez l'argent, et ne le dépensez pas tout d'un coup.";
				link.l1.go = "Node_132_6";
			}
			else
			{
				dialog.text = "Non, "+ GetSexPhrase("capitaine", "mademoiselle") +". Je ne la vendrai pas. Quand je me marierai, mon mari et moi irons chercher le trésor...";
				link.l1 = "Eh bien, c'est votre affaire. De toute façon, personne d'autre ne vous paiera pour votre bout de papier.";
				link.l1.go = "Node_132_2End";
			}
		break;

		case "Node_132_6":
			AddMoneyToCharacter(pchar, -makeint(sti(pchar.GenQuest.EncGirl.mapPrice)));
			GiveItem2Character(pchar, "map_full");
			Diag.TempNode = "Node_12End";
			pchar.GenQuest.EncGirl = "close";
			sGlobalTemp = "Saved_CangGirl";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_132_8":
			dialog.text = "Oם les trouverais-je ? Les jeunes, on ne peut pas compter sur eux : ils vous grimpent tout de suite sous les jupes, ils n'ont même pas besoin de trésors. Et les vieux me font peur, ils me rappellent les amis de mon père, ils sont tous si rusés : on ne sait jamais à quoi s'attendre avec eux.";
			link.l1 = "Ha ha ha... Vous viendrez avec moi chercher le trésor ?";
			link.l1.go = "Node_132_9";
		break;

		case "Node_132_9":
			dialog.text = "Avec vous ?! Vraiment ? Seulement, ensuite, vous me ramènerez ici, à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ", d'accord ?!";
			link.l1 = "Allons-y, si vous me dites oם.";
			link.l1.go = "Node_132_10";
		break;

		case "Node_132_10":
			EncGirl_GenQuest_GetChestPlaceName();
			dialog.text = "Le trésor est caché dans une grotte, sur l'île de " + XI_ConvertString(pchar.GenQuest.EncGirl.islandId + "Voc") + ". Il faudra débarquer au lieu-dit " + XI_ConvertString(pchar.GenQuest.EncGirl.shoreId + "Gen") + " ; de là, je vous montrerai l'endroit moi-même... Mais on partage en deux !";
			link.l1 = "D'accord, d'accord, je ne vous léserai pas. Suivez-moi de près.";
			link.l1.go = "Node_132_11";
		break;

		case "Node_132_11":
			ReOpenQuestHeader("JungleGirl");
			AddQuestRecord("JungleGirl", "4");
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			AddQuestUserData("JungleGirl", "sPirateName", GetName( NAMETYPE_ORIG, pchar.GenQuest.EncGirl.mapOwner, NAME_GEN));
			AddQuestUserData("JungleGirl", "sTreasureLoc", XI_ConvertString(pchar.GenQuest.EncGirl.islandId));
			AddQuestUserData("JungleGirl", "sShore", XI_ConvertString(pchar.GenQuest.EncGirl.shoreId + "Gen"));
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city));
			pchar.quest.EncGirl_Death.win_condition.l1 = "NPC_Death";
			pchar.quest.EncGirl_Death.win_condition.l1.character = npchar.id;
			pchar.quest.EncGirl_Death.function = "EncGirl_Death";
			pchar.quest.EncGirl_FindChest.win_condition.l1 = "location";
			pchar.quest.EncGirl_FindChest.win_condition.l1.location = pchar.GenQuest.EncGirl.placeId;
			pchar.quest.EncGirl_FindChest.function = "EncGirl_FindChest";
			SetFunctionExitFromLocationCondition("EncGirl_AddPassenger", pchar.location, false);
			SetFunctionLocationCondition("EncGirl_DialogAtShore", pchar.GenQuest.EncGirl.shoreId, false);
			Diag.TempNode = "Node_12End";
			pchar.GenQuest.EncGirl = "GetChest";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_132_11_1":
			dialog.text = "Capitaine, maintenant, il faut trouver la grotte.";
			link.l1 = "Eh bien, cherchons.";
			link.l1.go = "exit";
			Diag.TempNode = "Node_132_11_2";
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
		break;

		case "Node_132_11_2":
			Diag.TempNode = "Node_132_11_2";
			dialog.text = "Capitaine, il faut trouver la grotte.";
			link.l1 = "Eh bien, cherchons.";
			link.l1.go = "exit";
		break;

		case "Node_132_12":
			dialog.text = "Voilà. Je l'ai trouvé !.. Comme disait mon père, il y a tout un tas de bijoux ici ! Votre moitié, comme convenu.";
			link.l1 = "Vous voyez comme c'était simple ? Et vous aviez peur.";
			link.l1.go = "Node_132_13";
		break;

		case "Node_132_13":
			dialog.text = "Ha ha ha !.. Je suis riche maintenant ! Vous prenez votre part tout de suite ?";
			link.l1 = "Pourquoi pas.";
			link.l1.go = "Node_132_15";
		break;

		case "Node_132_15":
			dialog.text = "Alors tenez, et aidez-moi à porter le trésor jusqu'au navire. Vous n'avez pas oublié que vous avez promis de me ramener chez moi ?";
			link.l1 = "Je n'ai pas oublié. Je vous ramènerai, c'est promis.";
			link.l1.go = "Node_132_16";
		break;

		case "Node_132_16":
			pchar.quest.EncGirl_DeathSimple.over = "yes";
			LAi_LocationDisableMonstersGen(pchar.location, false);
			chrDisableReloadToLocation = false;
			Log_Info("Vous avez reçu votre part du trésor");
			PlaySound("interface\important_item.wav");
			TakeNItems(pchar, "icollection", 1+drand(1));
			TakeNItems(pchar, "chest", 2+drand(6));
			TakeNItems(pchar, "jewelry1", 30+drand(15));
			TakeNItems(pchar, "jewelry2", 30+drand(15));
			TakeNItems(pchar, "jewelry3", 30+drand(15));
			TakeNItems(pchar, "jewelry11", 30+drand(15));
			TakeNItems(pchar, "jewelry5", 30+rand(10));
			TakeNItems(pchar, "jewelry15", 10+rand(10));
			TakeNItems(pchar, "jewelry18", 20+rand(10));
			TakeNItems(pchar, "jewelry14", 30+rand(10));
			TakeNItems(pchar, "jewelry7", 50+rand(20));
			AddQuestRecord("JungleGirl", "6");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sPirateName", GetName( NAMETYPE_ORIG, pchar.GenQuest.EncGirl.mapOwner, NAME_GEN));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city));
			pchar.GenQuest.EncGirl = "ChestGetted";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_town";
			pchar.quest.EncGirl_DeliveBack.function = "EncGirl_DeliveBack";
			pchar.quest.EncGirl_DeathAgain.win_condition.l1 = "NPC_Death";
			pchar.quest.EncGirl_DeathAgain.win_condition.l1.character = npchar.id;
			pchar.quest.EncGirl_DeathAgain.function = "EncGirl_DeathAgain";
			Diag.TempNode = "Node_132_17";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
		break;

		case "Node_132_17":
			Diag.TempNode = "Node_132_17";
			dialog.text = "C'est formidable d'être riche ! Je me sens comme une autre femme.";
			link.l1 = "Tant mieux pour vous.";
			link.l1.go = "exit";
		break;

		case "Node_132_18":
			dialog.text = "Voilà, capitaine. Mon voyage est terminé. Merci pour votre aide.";
			link.l1 = "Je vous en prie... Que comptez-vous faire de votre fortune ? Vous allez sans doute acheter une plantation, prendre des esclaves...";
			link.l1.go = "Node_132_19";
		break;

		case "Node_132_19":
			dialog.text = "Je ne sais pas, je n'ai pas encore décidé... Peut-être que j'irai en Europe...";
			link.l1 = "Eh bien, bonne continuation.";
			link.l1.go = "Node_132_20";
		break;

		case "Node_132_20":
			dialog.text = "Attendez... Il y avait ce petit objet dans le trésor de mon père. Je n'en ai pas besoin, mais à vous, il pourrait servir. Prenez-le en cadeau pour ce que vous avez fait pour moi... Je le prends sur ma part, ha ha ha...";
			link.l1 = "Oh, quel cadeau. Merci"+ GetSexPhrase(", ma belle", "") +". Je vous souhaite un bon mari...";
			link.l1.go = "Node_132_21";
		break;

		case "Node_132_21":
			chrDisableReloadToLocation = false;
			RemovePassenger(pchar, npchar);
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "8");
			AddGoodDeed("JungleGirl_Treasure", 1); // Gregg: доброе дело - довёз домой с кладом
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			CloseQuestHeader("JungleGirl");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_133":
			dialog.text = "Mais que dois-je faire ? Je ne peux pas désobéir à ma maîtresse ! Elle va m'écorcher vive trois fois.";
			link.l1 = "Attendez-moi à l'église de " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ", je vous apporterai des perles pour le collier.";
			link.l1.go = "Node_133_1";
			if(sti(pchar.money) >= 15000)
			{
				link.l2 = "Tenez, prenez 15 000 piastres : avec cet argent, à défaut d'acheter un collier entier, vous pourrez au moins racheter des perles, c'est certain.";
				link.l2.go = "Node_135";
			}
		break;

		case "Node_133_1":
			pchar.GenQuest.EncGirl = "GetCoins";
			pchar.quest.EncGirl_Coins.win_condition.l1 = "ExitFromLocation";
			pchar.quest.EncGirl_Coins.win_condition.l1.location = pchar.location;
			pchar.quest.EncGirl_Coins.function = "EncGirl_toChurch";
			pchar.quest.EncGirl_GetCoins.win_condition.l1 = "Timer";
			pchar.quest.EncGirl_GetCoins.win_condition.l1.date.day = GetAddingDataDay(0, 0, 10);
			pchar.quest.EncGirl_GetCoins.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 10);
			pchar.quest.EncGirl_GetCoins.win_condition.l1.date.year = GetAddingDataYear(0, 0, 10);
			pchar.quest.EncGirl_GetCoins.function = "EncGirl_GenQuest_GetCoins";
			Diag.TempNode = "Node_134";
			Diag.CurrentNode = Diag.TempNode;
			ReOpenQuestHeader("JungleGirl");
			AddQuestRecord("JungleGirl", "1");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city));
			AddQuestUserData("JungleGirl", "sText1", sti(pchar.GenQuest.EncGirl.BigCoins));
			AddQuestUserData("JungleGirl", "sText2", sti(pchar.GenQuest.EncGirl.SmallCoins));
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_134":
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("capitaine", "mademoiselle") +"Comme je suis contente de vous revoir ! Avez-vous réussi à réunir les perles pour le collier ?", "Bonjour, capitaine ! Alors, avez-vous apporté les perles ? Ma maîtresse est très nerveuse.");
			if (GetCharacterItem(pchar, "jewelry11") >= sti(pchar.GenQuest.EncGirl.BigCoins) && GetCharacterItem(pchar, "jewelry12") >= sti(pchar.GenQuest.EncGirl.SmallCoins))
			{
				link.l1 = "Oui. Voici vos perles. Remettez-les à votre maîtresse, et dites-lui de mieux choisir l'endroit la prochaine fois avant d'égrener son collier.";
				link.l1.go = "Node_134_1";
			}
			else
			{
				link.l1 = "Pas encore. Ce n'est pas si facile... Attendez, je les apporterai sans faute.";
				link.l1.go = "Node_134_2";
			}
		break;

		case "Node_134_1":
			TakeNItems(pchar, "jewelry11", -sti(pchar.GenQuest.EncGirl.BigCoins));
			TakeNItems(pchar, "jewelry12", -sti(pchar.GenQuest.EncGirl.SmallCoins));
			pchar.quest.EncGirl_GetCoins.over = "yes";
			pchar.quest.EncGirl_DeathSimple.over = "yes";
			dialog.text = "Ah, "+ GetSexPhrase("capitaine", "mademoiselle") +"Quelle chance j'ai eue de croiser votre route ! En signe de gratitude pour tout ce que vous avez fait pour moi, je veux vous offrir un objet et ces pierres. J'espère que tout cela vous sera très utile.";
			link.l1 = "Oh ! Merci à vous aussi"+ GetSexPhrase(", ma belle", "") +", je ne m'attendais pas à ça... Adieu, et soyez heureuse.";
			link.l1.go = "Node_134_End";
		break;

		case "Node_134_2":
			dialog.text = "Ah, "+ GetSexPhrase("capitaine", "mademoiselle") +", je compte vraiment sur vous.";
			link.l1 = "Et vous faites bien...";
			link.l1.go = "exit";
			LAi_SetStayType(NPChar);
		break;

		case "Node_134_End":
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			TakeNItems(pchar, "jewelry1", 15+drand(8));
			AddQuestRecord("JungleGirl", "2");
			AddGoodDeed("JungleGirl_Pearls", 1); // Gregg: доброе дело - собрал жемчуг в срок
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			CloseQuestHeader("JungleGirl");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_135":
			addMoneyToCharacter(pchar, -15000);
			ChangeCharacterReputation(pchar, 10);
			dialog.text = "Ah, "+ GetSexPhrase("capitaine", "mademoiselle") +", c'est la deuxième fois aujourd'hui que vous me tirez d'affaire. Merci infiniment. Je n'oublierai jamais votre bonté.";
			link.l1 = "Je vous en prie. Mes salutations à votre maîtresse...";
			link.l1.go = "Node_135End";
		break;

		case "Node_135End":
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			NPChar.lifeDay = 0;
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "ThanksForSave":
			if (npchar.city == "Bridgetown" || npchar.city == "Charles" || npchar.city == "FortFrance" || npchar.city == "Marigo" || npchar.city == "Panama" || npchar.city == "PortRoyal" || npchar.city == "SantoDomingo" || npchar.city == "Tortuga")
			{
				if(CheckAttribute(pchar, "GenQuest.EncGirl.Horse"))
				{
					iRnd = 2;
					pchar.GenQuest.EncGirl.BrothelCity = true;
				}
				else
				{
					iRnd = 1;
				}
			}
			else
			{
				iRnd = 1;
			}
			switch(rand(iRnd))
			{
				case 0:
					dialog.text = RandPhraseSimple("Vous n'auriez pas dמ leur donner l'argent. Ils mentent.", "Ne les croyez pas. Ils mentent tous... א moi aussi, ils ont proposé de l'argent.");
					link.l1 = "J'aurais dמ les tuer ?";
					link.l1.go = "Node_200";
				break;
				case 1:
					dialog.text = "Oh, quel noble geste ! On voit tout de suite que vous êtes "+ GetSexPhrase("un vrai gentilhomme", "une noble dame") +" ! Acceptez mes sincères remerciements... J'espère que vous n'avez pas cru ce que racontaient ces escrocs ?";
					link.l1 = "Peu importe. Une fille poursuivie dans la jungle par une bande d'affamés, c'est tout à fait naturel...";
					link.l1.go = "Node_210";
					link.l2 = "Voyons, "+ GetSexPhrase("ma belle", "ma chérie") +", comment pourrais-je les croire ?";
					link.l2.go = "Node_211";
				break;
				case 2:
					dialog.text = "Merci, capitaine. Je suis désolée de vous mêler à une histoire aussi désagréable, mais je n'avais pas d'autre choix.";
					link.l1 = "Oui, je vois que vous avez vous-même de gros ennuis. Comment est-ce arrivé ?";
					link.l1.go = "Node_220";
				break;
			}
		break;

		case "Node_200":
			if(rand(1) == 0)
			{
				dialog.text = "Peut-être... De toute façon, ils ne me laisseront pas tranquille.";
				link.l1 = "Euh, rentrez chez vous, vous n'avez plus rien à craindre.";
				link.l1.go = "Node_200End";
				link.l2 = "דa alors ! Pourquoi détestez-vous autant les hommes ?";
				link.l2.go = "Node_201";
			}
			else
			{
				dialog.text = "Non, bien sמr que non ! Mais ils ne me lâcheront pas pour autant. Emmenez-moi à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + ", je vous en prie.";
				link.l1 = "Rentrez chez vous, ils ne vous toucheront plus. Ils filent à la taverne dépenser l'argent qu'ils ont gagné si facilement.";
				link.l1.go = "Node_200End";
				link.l2 = RandPhraseSimple("Ne vous inquiétez pas tant... Bon, allons-y.", "Pourquoi êtes-vous si peureuse ? Allez, je vous raccompagne.");
				link.l2.go = "Node_121Next";
			}
		break;

		case "Node_201":
			dialog.text = "Non, que dites-vous là ? C'est juste que je connais bien ces gredins. Ce sont d'anciens amis de mon père. Ils cherchent l'endroit oם mon père a caché ses bijoux.";
			link.l1 = "Et votre père ?";
			link.l1.go = "Node_202";
		break;

		case "Node_202":
			dialog.text = "Il était capitaine d'un navire pirate. Il est mort récemment... Ils étaient tous si polis à l'enterrement, mais avec le temps, ils ont oublié mon père et leur conscience... Heureusement que je les ai remarqués. Dès qu'ils sauront oם est le trésor, je ne vivrai plus longtemps...";
			link.l1 = "Oui, c'est une triste histoire. Et que comptez-vous faire, vous cacher d'eux ?";
			link.l1.go = "Node_203";
		break;

		case "Node_203":
			dialog.text = "Je ne peux pas garder d'objets de valeur chez moi, il n'y a personne pour me protéger. Alors je vais à la grotte la nuit quand l'argent vient à manquer... Je vous en prie, escortez-moi jusqu'à la grotte, et je vous rendrai l'argent que vous leur avez donné... Je ne pense pas que les pirates oseront nous suivre tant que vous serez avec moi.";
			link.l1 = "Je regrette, ma chère, j'ai de tout autres projets. Vous irez chercher vos trésors une autre fois.";
			link.l1.go = "Node_200End";
			link.l2 = "Allons-y, si je ne vous fais pas peur.";
			link.l2.go = "Node_204";
		break;

		case "Node_204":
			dialog.text = "Je ne sais pas pourquoi, mais vous ne me faites pas peur...";
			link.l1 = "Eh bien, vous faites bien.";
			link.l1.go = "Node_205";
		break;

		case "Node_205":
			Diag.TempNode = "Node_206";
			EncGirl_GenerateChest(npchar);
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
		break;

		case "Node_206":
			Diag.TempNode = "Node_206";
			dialog.text = "Capitaine, vous avez promis de m'emmener à la grotte.";
			link.l1 = "Allons-y...";
			link.l1.go = "exit";
		break;

		case "Node_207":
			dialog.text = "Voilà, capitaine, j'ai pris autant qu'il me fallait. Nous pouvons rentrer.";
			link.l1 = "Je ne crois pas voir vos petits copains.";
			link.l1.go = "Node_208";
		break;

		case "Node_208":
			dialog.text = "Eh bien, Dieu merci. דa fera moins d'ennuis... Tenez, prenez ces lingots, ils devraient couvrir vos frais. Repartez "+ GetSexPhrase("seul ", "seule ") +": moi, je prendrai l'autre chemin...";
			link.l1 = "Eh bien, bonne chance, si vous n'avez pas peur.";
			link.l1.go = "Node_209";
		break;

		case "Node_209":
			LAi_LocationDisableMonstersGen(pchar.location, false);
			pchar.GenQuest.EncGirl.price = 1100*(rand(4)+5) + 200 * sti(pchar.rank);
			sGems = makeint(sti(pchar.GenQuest.EncGirl.price))/100;
			TakeNItems(pchar, "jewelry17", sGems);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			pchar.quest.EncGirl_RapersExit.win_condition.l1 = "ExitFromLocation";
			pchar.quest.EncGirl_RapersExit.win_condition.l1.location = pchar.location;
			pchar.quest.EncGirl_RapersExit.function = "EncGirl_MeetRapers";
			DialogExit();
		break;

		case "Node_200End":
			pchar.quest.LandEnc_RapersBadExit.over = "yes";
			AddDialogExitQuestFunction("EncGirl_GirlGoAway");
			DialogExit();
		break;

		case "Node_210":
			dialog.text = "Hum, "+ GetSexPhrase("capitaine", "mademoiselle") +"Je n'aime pas votre ironie.";
			link.l1 = "Vous êtes libre, "+ GetSexPhrase("ma jolie", "ma chère") +". Vous feriez mieux de vous dépêcher de rentrer en ville avant qu'ils ne vous suivent de nouveau.";
			link.l1.go = "Node_1End";
		break;

		case "Node_211":
			dialog.text = "J'ai eu tellement peur ! Vous ne voudriez pas m'accompagner jusqu'à la taverne de " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + " ? Sinon, j'ai peur qu'ils ne me suivent encore.";
			link.l1 = "Je suppose que vous avez raison. Allons-y...";
			link.l1.go = "Node_122Next";
			ChangeCharacterReputation(pchar, 1);
		break;

		case "Node_220":
			dialog.text = "Oh, capitaine, c'est une longue histoire, je ne pense pas qu'elle vous intéresse. Quoique... De toute façon, je ne peux plus me passer de votre aide. Accepteriez-vous de m'escorter jusqu'à la taverne de " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + " ? Sinon, j'ai peur qu'ils ne me lâchent pas.";
			link.l1 = "Je regrette, ma jolie, je n'ai pas le temps, des affaires m'attendent.";
			link.l1.go = "Node_221";
			link.l2 = "Pourquoi tant de mystères ?";
			link.l2.go = "Node_222";
		break;

		case "Node_221":
			ChangeCharacterReputation(pchar, -2);
			AddDialogExitQuestFunction("EncGirl_GirlGoAway");
			DialogExit();
		break;

		case "Node_222":
			dialog.text = "Comment ne pas être mystérieuse, quand tout le monde essaie de profiter de votre malheur ?";
			link.l1 = "Allons...";
			link.l1.go = "Node_223";
		break;

		case "Node_223":
			Diag.TempNode = "Node_224";
			pchar.GenQuest.EncGirl = "HorseToTavern";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_tavern";
			pchar.quest.EncGirl_DeliveBack.function = "EncGirl_DeliveBack";
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_224":
			chrDisableReloadToLocation = false;
			if (PChar.sex != "woman")
			{
				dialog.text = "Il y a trop de monde ici. Allons dans la chambre, j'ai quelque chose à vous dire.";
				link.l1 = LinkRandPhrase("J'ai déjà fait beaucoup pour vous, alors adieu.", "N'abusez pas de ma bienveillance. Adieu, ma chère.", "Vos histoires ne m'intéressent pas. Débrouillez-vous toute seule.");
				link.l1.go = "Node_226";
				link.l2 = "Hum, d'accord. Je vais demander les clés à l'aubergiste.";
				link.l2.go = "Node_227";
			}
			else
			{
				dialog.text = "Merci infiniment pour votre aide, ma douce. Je n'oublierai jamais votre gentillesse.";
				link.l1 = "Adieu. Soyez plus prudente désormais.";
				link.l1.go = "Node_226_1";
			}
		break;

		case "Node_225":
			chrDisableReloadToLocation = false;
			if (PChar.sex != "woman")
			{
				dialog.text = "Il y a trop de monde ici. Allons dans la chambre, j'ai quelque chose à vous dire.";
				link.l1 = LinkRandPhrase("J'ai déjà fait beaucoup pour vous, alors adieu.", "N'abusez pas de ma bienveillance. Adieu, ma chère.", "Vos histoires ne m'intéressent pas. Débrouillez-vous toute seule.");
				link.l1.go = "Node_226";
				link.l2 = "Hum, d'accord. Je vais demander les clés à l'aubergiste.";
				link.l2.go = "Node_227";
			}
			else
			{
				dialog.text = "Merci infiniment pour votre aide, ma douce. Je n'oublierai jamais votre gentillesse.";
				link.l1 = "Adieu. Soyez plus prudente désormais.";
				link.l1.go = "Node_226_1";
			}
		break;

		case "Node_226":
			ChangeCharacterReputation(pchar, -1);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_226_1":
			ChangeCharacterReputation(pchar, 3);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_227":
			pchar.GenQuest.EncGirl = "EncGirl_ToTavern";
			pchar.quest.EncGirl_inRoom.win_condition.l1 = "location";
			pchar.quest.EncGirl_inRoom.win_condition.l1.location = npchar.city + "_tavern_upstairs";
			pchar.quest.EncGirl_inRoom.function = "EncGirl_SpeakInRoom";
//			chrDisableReloadToLocation = true;
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_228":
			if(CheckAttribute(pchar, "GenQuest.EncGirl.Horse") && CheckAttribute(pchar, "GenQuest.EncGirl.BrothelCity") && sti(pchar.rank) > 15) // душещипательная история о невинной девочке попавшей в бордель
			{
				DeleteAttribute(pchar, "GenQuest.EncGirl.BrothelCity");
				dialog.text = "Vous voulez toujours entendre mon histoire ?";
				link.l1 = "Non, je crois que je dois y aller. Bonne continuation.";
				link.l1.go = "Node_232";
				link.l2 = "Racontez, puisque vous avez commencé.";
				link.l2.go = "Node_233";
			}
			else
			{
				dialog.text = "Ah, mon noble sauveur, enfin je peux vous remercier comme seules les femmes savent le faire. Quand je vous ai vu dans la jungle, tout s'est retourné en moi. J'ai oublié les violeurs et les feuilles de palmier coupantes qui me fouettaient les joues. J'ai oublié oם je courais, pourquoi je courais... Je ne voyais que vous. Et je ne désirais que vous... Et après ce que vous avez fait pour moi...";
				link.l1 = "דa alors ! Quel tempérament ! Vos poursuivants savaient après qui ils couraient...";
				link.l1.go = "Node_229"; // ГГ допрыгался - щас его попросту трахнут
				link.l2 = "וcoutez, ma jolie, je comprends votre enthousiasme, mais gardez votre tempérament pour vous.";
				link.l2.go = "Node_230"; // Послал в пешее эротическое путешествие
			}
		break;

		case "Node_229":
			dialog.text = "Eh bien, viens à moi, mon héros...";
			link.l1 = "Ah, ma belle...";
			link.l1.go = "exit";
			pchar.GenQuest.EncGirl = "EncGirl_facking";
			DoQuestCheckDelay("PlaySex_1", 3.0);
		break;

		case "Node_230":
			dialog.text = "Ah ! Comment pouvez-vous !.. Comment osez-vous ?! Goujat ! Une fille vient à lui corps et âme, et lui !..";
			link.l1 = "Si vous remuiez moins de la croupe et ne vous jetiez pas au cou du premier venu, vous auriez moins de problèmes. Sinon, on retrousse ses jupes, et ensuite, il faut venir vous secourir à travers la jungle...";
			link.l1.go = "Node_231";
		break;

		case "Node_231":
			dialog.text = "Eh bien, personne ne m'avait encore jamais dit ça ! Et je n'ai pas l'intention de le pardonner à qui que ce soit ! Souvenez-vous de mes paroles !";
			link.l1 = "Allez, ouste. Et remontez vos bas, sinon il faudra encore vous sauver...";
			link.l1.go = "Node_231_1";
		break;

		case "Node_231_1":
			LAi_LockFightMode(pchar, true);
			ChangeCharacterReputation(pchar, 1);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", sTemp, "none", "", "", "", -1.0);
			npchar.lifeDay = 0;
			DoQuestFunctionDelay("EncGirl_SetBerglar", 5.0);
			DialogExit();
		break;

		case "Node_232":
			ChangeCharacterReputation(pchar, -3);
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_233":
			pchar.GenQuest.EncGirl.Parents_City = GetQuestNationsCity(sti(pchar.GenQuest.EncGirl.nation));
			dialog.text = "Ma famille vit à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.Parents_City) + ". Je me suis retrouvée ici tout à fait par hasard : le navire sur lequel mon fiancé m'emmenait chez ses parents a été capturé par des pirates. Le navire a été emmené, et les passagers ont été débarqués dans une baie non loin d'ici. Mon fiancé est mort pendant l'abordage, et je suis tombée gravement malade pendant la traversée de la jungle. La tenancière d'un bordel du coin est venue me voir, et quand je me suis remise sur pied, elle a exigé que je rembourse en travaillant l'argent dépensé pour mes soins. Mais je n'avais rien d'une catin, et madame la tenancière, pour en tirer quelque chose, m'a vendue à des bandits. Vous connaissez la suite.";
			link.l1 = "Alors laissez tout tomber et rentrez chez vous ! Pourquoi vous laissez-vous traiter comme une esclave ?!";
			link.l1.go = "Node_234";
		break;

		case "Node_234":
			dialog.text = "Je ne peux pas ! Toutes mes affaires (des vêtements convenables, de l'argent, mes papiers) sont restées au bordel, dans un sac de voyage. Je l'ai caché dans la chambre des rendez-vous. Et dans une telle tenue, les marins du port ne me laisseront pas passer, encore moins voyager. Et qui me prendra à bord sans argent ni papiers ? Et maintenant, je ne peux même plus me montrer en ville... On me mettra en prison...";
			link.l1 = "Voilà bien un problème ! Préparez-vous, allons-y. Je vous emmène.";
			link.l1.go = "Node_235";
			link.l2 = "Attendez ici. Je vais chercher votre valise...";
			link.l2.go = "Node_236";
			if(sti(pchar.money) >= 5000)
			{
				link.l3 = "Mais qui s'intéresse à vos papiers ? Combien d'argent vous faut-il pour rentrer chez vous ?";
				link.l3.go = "Node_237";
			}
		break;

		case "Node_235":
			dialog.text = "Merci, capitaine... Mais je n'ai rien pour vous payer.";
			link.l1 = "Quel paiement ?! Allons-y avant qu'on ne remarque votre absence...";
			link.l1.go = "Node_240";
		break;

		case "Node_240":
			ReOpenQuestHeader("JungleGirl");
			AddQuestRecord("JungleGirl", "20");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.Parents_City));
			AddQuestUserData("JungleGirl", "sBrothelCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city + "Gen"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			OfficersReaction("bad");
			chrDisableReloadToLocation = false;
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "OpenTheDoors", 3.0);
			pchar.quest.EncGirl_DeliveToParents.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveToParents.win_condition.l1.location = pchar.GenQuest.EncGirl.Parents_City + "_town";
			pchar.quest.EncGirl_DeliveToParents.function = "EncGirl_DeliveToParents";
			DialogExit();
		break;

		case "Node_236":
			dialog.text = "Ah, capitaine, je n'osais même pas vous le demander.";
			link.l1 = "N'ayez pas peur. Je reviens vite.";
			link.l1.go = "Node_239";
		break;

		case "Node_239":
			ReOpenQuestHeader("JungleGirl");
			AddQuestRecord("JungleGirl", "21");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			pchar.quest.EncGirl_GenerateBag.win_condition.l1 = "location";
			if(GetSummonSkillFromName(pchar, SKILL_FORTUNE) > rand(100))
			{
				pchar.GenQuest.EncGirl = "Bag_BrothelRoomUp";
				pchar.quest.EncGirl_GenerateBag.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_Brothel_room";
			}
			else
			{
				pchar.GenQuest.EncGirl = "Bag_BrothelRoom";
				pchar.quest.EncGirl_GenerateBag.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_SecBrRoom";
			}
			pchar.quest.EncGirl_GenerateBag.function = "EncGirl_GenerateLeatherBag";

			pchar.quest.EncGirl_GetBagFail.win_condition.l1 = "Timer";
			pchar.quest.EncGirl_GetBagFail.win_condition.l1.date.day = GetAddingDataDay(0, 0, 1);
			pchar.quest.EncGirl_GetBagFail.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 1);
			pchar.quest.EncGirl_GetBagFail.win_condition.l1.date.year = GetAddingDataYear(0, 0, 1);
			pchar.quest.EncGirl_GetBagFail.function = "EncGirl_GenQuest_GetBag";

			pchar.quest.EncGirl_ExitRoom.win_condition.l1 = "ExitFromLocation";
			pchar.quest.EncGirl_ExitRoom.win_condition.l1.location = pchar.location;
			pchar.quest.EncGirl_ExitRoom.function = "EncGirl_ExitTavernRoom";

			AddDialogExitQuest("OpenTheDoors");
			DialogExit();
		break;

		case "Node_240_1":
			pchar.quest.EncGirl_GetBagFail.over = "yes";
			dialog.text = "Oh, je croyais qu'il vous était arrivé quelque chose.";
			if(CheckCharacterItem(pchar, "leather_bag"))
			{
				link.l1 = "Que pourrait-il m'arriver ? Tenez, voici vos affaires.";
				link.l1.go = "Node_241";
			}
			else
			{
				link.l1 = "וcoutez, je n'ai rien trouvé. Vous êtes sמre d'avoir laissé le sac dans la chambre des visites ?";
				link.l1.go = "Node_242";
			}
		break;

		case "Node_241":
			TakeNItems(pchar, "leather_bag", -1);
			dialog.text = "Merci, "+ GetSexPhrase("noble capitaine", "noble dame") +". Je n'oublierai jamais ce que vous avez fait pour moi. Et même si je n'ai rien, laissez-moi vous offrir cette amulette : c'est peut-être grâce à elle que j'ai survécu à l'attaque des pirates.";
			link.l1 = "Merci. Bon voyage. Adieu...";
			link.l1.go = "Node_243";
		break;

		case "Node_242":
			dialog.text = "On a trouvé ma cachette ?";
			if(sti(pchar.money) >= 5000)
			{
				link.l1 = "Combien d'argent vous faut-il pour rentrer chez vous ?";
				link.l1.go = "Node_237";
			}
			link.l2 = "Il se peut qu'on l'ait trouvée. Seulement, maintenant, nos chemins se séparent. Adieu !";
			link.l2.go = "Node_244";
		break;

		case "Node_243":
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			TakeNItems(pchar, pchar.GenQuest.EncGirl.item, 1);
			AddQuestRecord("JungleGirl", "23");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			CloseQuestHeader("JungleGirl");
			ChangeCharacterReputation(pchar, 1);
			AddGoodDeed("JungleGirl_BrothelHome", 1); // Gregg: доброе дело - довёз беглянку домой
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_244":
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			AddQuestRecord("JungleGirl", "23");
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			CloseQuestHeader("JungleGirl");
			ChangeCharacterReputation(pchar, -5);
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_245":
			dialog.text = "Merci, capitaine. Je n'arrive pas à croire que je suis chez moi. Je vous en prie, ne refusez pas, venez, je vais vous présenter à mes parents.";
			link.l1 = "וcoutez, "+ GetSexPhrase("ma belle", "ma chérie") +", je n'ai vraiment pas le temps. Ce sera pour une autre fois...";
			link.l1.go = "Node_246";
		break;

		case "Node_246":
			dialog.text = "Quel dommage... Eh bien, adieu, et que Dieu vous protège. Et même si je n'ai rien, laissez-moi vous offrir cette amulette.";
			link.l1 = "Merci ! Courez, courez faire plaisir à vos parents...";
			link.l1.go = "Node_247";
//			link.l2 = "Do you really think this is necessary?";
//			link.l2.go = "Node_248"
		break;

		case "Node_247":
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", sTemp, "none", "", "", "OpenTheDoors", -1.0);
			TakeNItems(pchar, pchar.GenQuest.EncGirl.item, 1);
			AddQuestRecord("JungleGirl", "24");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sName", pchar.GenQuest.EncGirl.name);
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.Parents_City));
			CloseQuestHeader("JungleGirl");
			npchar.lifeDay = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_248":
		break;

		case "Node_237":
			dialog.text = "Eh bien, je ne sais pas... Il faudra peut-être attendre un navire de passage pendant un moment. Mais je ne peux pas vous demander de l'argent.";
			if(makeint(pchar.money)>=5000)
			{
				link.l1 = "D'accord. Tenez, prenez 5 000 piastres. דa devrait suffire.";
				link.l1.go = "Node_237_1";
			}
			if(makeint(pchar.money)>=25000)
			{
				link.l2 = "D'accord. Tenez, prenez 25 000 piastres. Et rentrez chez vous.";
				link.l2.go = "Node_237_2";
			}
			if(makeint(pchar.money)>=35000)
			{
				link.l3 = "Je vois. Tenez, voici 35 000 piastres. Offrez-vous une cabine de luxe.";
				link.l3.go = "Node_237_3";
			}
		break;

		case "Node_237_1":
			AddMoneyToCharacter(pchar, -5000);
			ChangeCharacterReputation(pchar, -5);
			dialog.text = "Merci, "+ GetSexPhrase("noble capitaine", "noble dame") +". Je n'oublierai jamais ce que vous avez fait pour moi.";
			link.l1 = "Bon voyage. Adieu...";
			link.l1.go = "Node_238";
			pchar.GenQuest.EncGirl = "EncGirlFack_GetMoney";
		break;

		case "Node_237_2":
			AddMoneyToCharacter(pchar, -25000);
			ChangeCharacterReputation(pchar, 1);
			dialog.text = "Merci, "+ GetSexPhrase("noble capitaine", "noble dame") +". Je n'oublierai jamais ce que vous avez fait pour moi.";
			link.l1 = "Bon voyage. Adieu...";
			link.l1.go = "Node_238";
		break;

		case "Node_237_3":
			AddMoneyToCharacter(pchar, -35000);
			ChangeCharacterReputation(pchar, 2);
			dialog.text = "Merci, "+ GetSexPhrase("noble capitaine", "noble dame") +". Je n'oublierai jamais ce que vous avez fait pour moi.";
			link.l1 = "Bon voyage. Adieu...";
			link.l1.go = "Node_238";
		break;

		case "Node_238":
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "OpenTheDoors", -1.0);
			npchar.lifeDay = 0;
			if(pchar.GenQuest.EncGirl == "EncGirlFack_GetMoney")
			{
				AddSimpleRumour(RandPhraseSimple("Vous avez entendu ? Une catin a essayé de monter sur un navire sans papiers. On l'a attrapée et ramenée au bordel. On dit qu'elle doit une jolie somme à la tenancière.",
				"Vous savez la nouvelle ? On a attrapé dans notre port une catin sans papiers. On dit qu'elle s'est enfuie du bordel après avoir vidé les coffres de la tenancière. Ce repaire de maladies et de vols aurait dמ être fermé depuis longtemps. Après tout, nos enfants voient tout ça : qu'est-ce qu'ils peuvent bien en apprendre ?"), sti(pchar.GenQuest.EncGirl.nation), 3, 1);
			}
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
		break;

		case "Node_250":
			dialog.text = "Ne gâchez pas tout, capitaine ! Mon père veut me marier au fils d'un usurier, un monstre baveux... Tout ça parce que son papa a plein de piastres dans ses coffres ! Je préfère rester dans la jungle et me faire dévorer par les bêtes sauvages ! Ne m'envoyez pas en servitude pour la vie, je vous en supplie !";
			link.l1 = "Qu'est-ce qui vous prend, "+ GetSexPhrase("ma belle", "ma chérie") +", vous fuyez le mariage ? וpousez celui qui vous courtise, tant qu'il veut encore de vous. Le temps passera, et vous serez bien contente d'avoir même un monstre baveux, quand plus personne ne vous demandera en mariage...";
			link.l1.go = "Node_251";
		break;

		case "Node_251":
			pchar.GenQuest.EncGirl.sLoverId = GenerateRandomName(sti(npchar.nation), "man");
			dialog.text = "Non !.. Non, capitaine, j'aime un homme qui s'appelle " + pchar.GenQuest.EncGirl.sLoverId + " et, à part lui, je ne veux connaître personne ! Et mon père s'y oppose ! Il dit qu'à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) + " il n'est qu'un étranger qui ne trouvera jamais de travail ici, qu'il est sur le point de partir courir le monde et qu'il m'entraînera avec lui. Et moi, j'irais au bout du monde rien que pour être avec lui... Emmenez-moi auprès de lui, je vous en prie.";
			link.l1 = "D'accord, allons-y. Je réfléchirai en chemin à l'endroit oם vous déposer...";
			link.l1.go = "Node_252";
		break;

		case "Node_252":
			Diag.TempNode = "Node_253";
			ReOpenQuestHeader("JungleGirl");
			AddQuestRecord("JungleGirl", "9");
			AddQuestUserData("JungleGirl", "sText", pchar.GenQuest.EncGirl.FatherGen);
			AddQuestUserData("JungleGirl", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city));
			AddQuestUserData("JungleGirl", "sLover", pchar.GenQuest.EncGirl.sLoverId);
			pchar.GenQuest.EncGirl.MeetSoldiers = 2;
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
		break;

		case "Node_253":
			Diag.TempNode = "Node_253";
			dialog.text = "Capitaine, vous avez promis de m'emmener à " + XI_ConvertString("Colony" + pchar.GenQuest.EncGirl.city) +".";
			link.l1 = RandPhraseSimple("Je m'en souviens, je m'en souviens.", "Ne vous inquiétez pas, je vous raccompagnerai.");
			link.l1.go = "exit";
		break;

		case "Node_260":
			chrDisableReloadToLocation = false;
			if(rand(2) > 0)
			{
				dialog.text = RandPhraseSimple("Merci, "+ GetSexPhrase("capitaine", "mademoiselle") +", encore une fois. Je ne sais comment vous remercier.", "Merci beaucoup, "+ GetSexPhrase("capitaine", "mademoiselle") +". Je n'ose même pas imaginer ce que je serais devenue sans votre intervention.");
				link.l1 = RandPhraseSimple("Désormais, ça vous servira de leçon. Bon, bonne journée...", "Vous serez plus prudente la prochaine fois... Allez, rentrez chez vous, des affaires m'attendent.");
				link.l1.go = "Node_1End";
				link.l2 = "Peut-on être aussi imprudente ? Que faites-vous seule dans la jungle ?";
				link.l2.go = "Node_13";
			}
			else
			{
				dialog.text = "Ah, "+ GetSexPhrase("capitaine", "mademoiselle") +", je ne sais vraiment pas comment vous remercier.";
				link.l1 = "Il n'y a pas de quoi. C'est toujours un plaisir de rendre service...";
				link.l1.go = "Node_261";
			}
		break;

		case "Node_261":
			dialog.text = "Vous m'emmenez à la taverne ? Je dois y attendre ma tante et me reposer, j'ai eu tellement peur...";
			link.l1 = "Non, "+ GetSexPhrase("ma belle", "ma chérie") +", ce sera sans moi. J'ai déjà assez à faire comme ça.";
			link.l1.go = "Node_262";
			link.l2 = ""+ GetSexPhrase("Ah, ces femmes ! Elles ne peuvent pas faire un pas sans un homme ! ", "Et pourquoi êtes-vous si désemparée ? ") +"Allons-y...";
			link.l2.go = "Node_263";
		break;

		case "Node_262":
			sTemp = LAi_FindNearestFreeLocator2Pchar("reload");
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", sTemp, "none", "", "", "", -1.0);
			npchar.lifeday = 0;
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "Node_263":
			Diag.TempNode = "Node_224";
			pchar.GenQuest.EncGirl = "HorseToTavern";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1 = "location";
			pchar.quest.EncGirl_DeliveBack.win_condition.l1.location = pchar.GenQuest.EncGirl.city + "_tavern";
			pchar.quest.EncGirl_DeliveBack.function = "EncGirl_DeliveBack";
			Diag.CurrentNode = Diag.TempNode;
			AddDialogExitQuestFunction("EncGirl_GirlFollow");
			DialogExit();
			AddDialogExitQuest("pchar_back_to_player");
		break;

		case "ThanksForHelp_1":
			Diag.TempNode = "ThanksAgain";
			if(makeint(Pchar.reputation) > 80)
			{
				dialog.text = "J'ai un peu d'argent. Prenez-le en signe de ma gratitude !";
				Link.l1 = "Merci. Soyez prudente la prochaine fois.";
				Link.l1.go = "exit";
			}
			else
			{
				if(drand(1) == 0)
				{
					dialog.text = "Je dirai à tout le monde que vous m'avez sauvée ! Que tout le monde sache "+ GetSexPhrase("quel homme courageux et bon vous êtes", "quelle femme courageuse et bonne vous êtes") +" !";
					Link.l1 = "Merci. Vous feriez mieux de rentrer chez vous maintenant.";
					Link.l1.go = "exit";
				}
				else
				{
					addMoneyToCharacter(Pchar, makeint(PChar.rank)*100);
					dialog.text = "J'ai un peu d'argent. Prenez-le en signe de ma gratitude !";
					Link.l1 = "Merci. Soyez prudente la prochaine fois.";
					Link.l1.go = "exit";
				}
			}
		break;
        //#20200315-01
        case "CitizenNotBlade":
            npchar.chr_ai.type.checkFight = 999999.0;
            Diag.TempNode = "ThanksAgain";
			dialog.text = "J'ai un peu d'argent. Prenez-le en signe de ma gratitude !";
			Link.l1 = "Merci. Soyez prudente la prochaine fois.";
			Link.l1.go = "exit";
		break;
		case "ThanksAgain":
            Diag.TempNode = "ThanksAgain";
            dialog.text = "Je dirai à tout le monde que vous m'avez sauvée ! Que tout le monde sache "+ GetSexPhrase("quel homme courageux et bon vous êtes", "quelle femme courageuse et bonne vous êtes") +" !";
			Link.l1 = "Merci. Vous feriez mieux de rentrer chez vous maintenant.";
			Link.l1.go = "exit";
		break;
	}
}
