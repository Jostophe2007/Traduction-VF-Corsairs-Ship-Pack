// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils", "ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils", "ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(PChar.MysteriousIsland == "10" && PChar.MysteriousIsland.FindForser.Church == false && NPChar.City == "SantoDomingo")	//Загадочный остров
			{
				link.l1 = "Saint père, le nom de Davy Forser vous dit-il quelque chose ?";
				link.l1.go = "MysteriousIsland_1";
			}
		break;
		
		// Загадочный остров -->
		case "MysteriousIsland_1":
			PChar.MysteriousIsland.FindForser.Church = true;
			dialog.text = "Non, mon fils, je n'ai jamais entendu ce nom.";
			link.l1 = LinkRandPhrase("Oh, désolé...", "Merci quand même.", "א bientכt.");
			link.l1.go = "exit";
		break;
		// Загадочный остров <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}



