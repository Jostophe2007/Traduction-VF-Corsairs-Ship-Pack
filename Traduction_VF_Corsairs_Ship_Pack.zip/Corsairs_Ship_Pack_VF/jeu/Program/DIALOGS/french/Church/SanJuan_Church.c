// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	string sStr;
	
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils", "ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils", "ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//============= Изабелла Росселини ================
            if (CheckAttribute(Pchar, "RomanticQuest.PriestAsk"))
			{
				link.l2 = "Puis-je vous demander si l'épouse de don Salvator vient souvent à l'église ?";
				link.l2.go = "Romantic_1";
			}
			//Квест "Strange things are happening in the archipelago"
			if (CheckAttribute(Pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Dobro"))	//Письмо не вскрывали
			{
				link.l1 = "On m'a chargé de remettre cette lettre.";
				link.l1.go = "PKM_SvtvA_Ch1_1_Dobro";
				TakeItemFromCharacter(pchar, "PKM_SvtvA_pismo1");			
			}
			if (CheckAttribute(Pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Zlo"))	//Письмо вскрыли
			{
				link.l1 = "On m'a chargé de remettre cette lettre.";
				link.l1.go = "PKM_SvtvA_Ch1_1_Zlo";
				TakeItemFromCharacter(pchar, "PKM_SvtvA_pismo1");			
			}
			if (CheckAttribute(Pchar, "questTemp.PKM_SvtvA_Dostavka_Malty"))	//Доставили Мальтильца
			{
				link.l1 = "Votre mission est accomplie. Le navire que vous m'avez demandé d'escorter est au port.";
				link.l1.go = "PKM_SvtvA_Ch2_1";				
			}
		break;

		//Квест "Strange things are happening in the archipelago" (Доставили письмо)
		case "PKM_SvtvA_Ch1_1_Dobro":
			dialog.text = "Donnez-la-moi. Voyons, voyons... hum... C'est bien ce que je pensais ! Hum... Eh bien, vous avez fait du bon travail, mais permettez-moi de vous poser quelques questions.";
			link.l1 = "Oui, que voulez-vous savoir exactement ?";
			link.l1.go = "PKM_SvtvA_Ch1_2_Dobro";
			
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Dobro");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Zlo");
		break;

		case "PKM_SvtvA_Ch1_1_Zlo":
			dialog.text = "Donnez-la-moi. Voyons, voyons... hum... C'est bien ce que je pensais ! Au fait, qui a ouvert la lettre ?";
			link.l1 = "Personne ne l'a ouverte, voyons ! Vous me croyez capable d'une chose pareille ?!";
			link.l1.go = "PKM_SvtvA_Ch1_2_Zlo_Poka";
			link.l2 = "Vous avez deviné ?! Je savais bien que ça finirait mal.";
			link.l2.go = "PKM_SvtvA_Ch1_2_Zlo";
			
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Dobro");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_SanJuanChurch_1_Zlo");
		break;

		case "PKM_SvtvA_Ch1_2_Zlo":
			dialog.text = "Alors, qui a ouvert la lettre ?";
			link.l1 = "On m'attendait dans la baie oם je devais débarquer. Et je n'ai pas eu d'autre choix que de leur remettre la lettre. Des gens en robe rouge : ils savaient que j'accosterais là !";
			link.l1.go = "PKM_SvtvA_Ch1_3_Zlo";
		break;

		case "PKM_SvtvA_Ch1_3_Zlo":
			dialog.text = "Bien. Je vois que ce péché peut vous être pardonné. D'ailleurs, nous avions prévu une telle issue, et pour comprendre le vrai sens de cette lettre, il faut posséder certaines connaissances. Vous nous avez même aidés, d'une certaine façon, en trompant ces gens. Je crois que je peux même vous verser la somme promise.";
			link.l1 = "Oh, merci, merci !";
			link.l1.go = "PKM_SvtvA_Ch1_6";
			ChangeCharacterReputation(pchar, -15);
			AddMoneyToCharacter(pchar, 1000);
			AddQuestRecord("PKM_Animists", "13");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
		break;

		case "PKM_SvtvA_Ch1_2_Zlo_Poka":
			dialog.text = "Je vois que vous n'avez pas l'intention de vous repentir de ce que vous avez fait. Libre à vous, et maintenant, quittez l'église !";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "PKM_SvtvA_Ch1_3_Zlo_Poka";
			link.l2 = "Non, attendez, pardon ! Le diable m'a égaré !";
			link.l2.go = "PKM_SvtvA_Ch1_2_Zlo";
		break;

		case "PKM_SvtvA_Ch1_3_Zlo_Poka":
			DialogExit();

			ChangeCharacterReputation(pchar, -30);
			AddQuestRecord("PKM_Animists", "14");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PKM_Animists", "sSex2", GetSexPhrase("", "e"));
			CloseQuestheader("PKM_Animists");
			pchar.questdata.Satanisty = 1;
		break;

		case "PKM_SvtvA_Ch1_2_Dobro":
			dialog.text = "Avez-vous eu des ennuis en chemin ?";
			link.l1 = "Vous savez, " + GetFullName(CharacterFromID("FortFrance_Priest"))+"il m'a demandé de débarquer dans une baie isolée pour éviter les surprises, mais le fait est qu'on m'y attendait déjà...";
			link.l1.go = "PKM_SvtvA_Ch1_3_Dobro";
			if (CheckAttribute(Pchar, "questTemp.PKM_SvtvA_DralisVG"))	//Если дрались в городе
			{
				link.l1 = "Vous savez, de mystérieux individus en rouge m'attendaient déjà sur la jetée... Quand j'ai refusé de leur remettre la lettre, ils m'ont attaqué. Comme vous le voyez, je suis là, bien vivant, ce qu'on ne peut pas dire de mes assassins.";
				link.l1.go = "PKM_SvtvA_Ch1_4_Dobro";
			}
		break;

		case "PKM_SvtvA_Ch1_3_Dobro":
			dialog.text = "Vous voulez dire...";
			link.l1 = "Je ne veux jeter le soupçon sur personne, prenez-le simplement en considération. Quatre hommes en robe rouge m'ont accueilli dans la baie et s'intéressaient de très près à la lettre. Au point que j'ai dמ les tuer.";
			link.l1.go = "PKM_SvtvA_Ch1_4_Dobro";
		break;

		case "PKM_SvtvA_Ch1_4_Dobro":
			dialog.text = "Hum, je vois que " + GetFullName(CharacterFromID("FortFrance_Priest"))+" ne vous a vraiment pas confié cette affaire pour rien...";
			link.l1 = "Ce n'est pas tout. En fouillant les corps des assaillants, j'ai trouvé d'étranges médaillons au cou de chacun d'eux.";
			link.l1.go = "PKM_SvtvA_Ch1_5_Dobro";
		break;

		case "PKM_SvtvA_Ch1_5_Dobro":
			dialog.text = "Voyons-les... hum... Comme c'est intéressant... Mais revenons à nos affaires. Voici votre récompense.";
			link.l1 = "Merci.";
			link.l1.go = "PKM_SvtvA_Ch1_6";
			AddMoneyToCharacter(pchar, 4000);
			ChangeCharacterReputation(pchar, 2);
		break;
		
		case "PKM_SvtvA_Ch1_6":
			dialog.text = "Et j'ai une autre affaire pour vous ; si, bien sמr, vous acceptez de vous en charger, la rétribution sera bien plus généreuse que cette fois-ci.";
			link.l1 = "Et que voulez-vous que je fasse ?";
			link.l1.go = "PKM_SvtvA_Ch1_7";
		break;

		case "PKM_SvtvA_Ch1_7":
			dialog.text = "Un navire transportant des chevaliers de Malte, importants pour notre cause, doit arriver d'Europe. J'ai toutes les raisons de croire que ce navire est en danger, et votre mission est de le rejoindre près de l'île de Saint-Martin et de l'escorter jusqu'à notre port.";
			link.l1 = "Dites-moi le nom de ce navire, et je ferai de mon mieux.";
			link.l1.go = "PKM_SvtvA_Ch1_8";
		break;

		case "PKM_SvtvA_Ch1_8":
			dialog.text = "Vous devez donc rejoindre la barque « Maenez », commandée par un certain Jacquin de Masset, officier maltais.";
			link.l1 = "Parfait, ces informations suffisent. Je crois que je peux appareiller : plus tכt je le ferai, meilleures seront les chances de succès.";
			link.l1.go = "PKM_SvtvA_Ch1_9";
		break;
		
		case "PKM_SvtvA_Ch1_9":
			DialogExit();
			AddQuestRecord("PKM_Animists", "15");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			if (CheckAttribute(Pchar, "questTemp.PKM_SvtvA_DralisVG")) sStr = "la jetée";
			else sStr = "la plage";
			AddQuestUserData("PKM_Animists", "sStr", sStr);
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_DralisVG");
			
			//Корабль 'Маёнез'
			sld = GetCharacter(NPC_GenerateCharacter("Maltese", "Maltese", "man", "man", 10, SPAIN, -1, true));
			FantomMakeCoolFighter(sld, 10, 30, 30, "blade16", "pistol1", 50);
			SetSPECIAL(sld, 10, 6, 8, 10, 6, 5, 6);
			SetSelfSkill(sld, 18, 21, 70, 3, 40);
			SetShipSkill(sld, 60, 12, 18, 17, 32, 41, 60, 31, 26);
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
			sld.name = "Jacquin";
			sld.lastname = "de Masset";
			sld.loyality = 20;
			FantomMakeCoolSailor(sld, SHIP_BARQUE, "Maenez", CANNON_TYPE_CULVERINE_LBS16, 30, 50, 30);	//Корабль
			sld.AlwaysFriend = true;
			sld.Ship.Mode = "trade";
			Group_FindOrCreateGroup("PKM_SvtvA_Malta");
			Group_SetType("PKM_SvtvA_Malta", "war");
			Group_AddCharacter("PKM_SvtvA_Malta", "Maltese");
			Group_SetTaskAttack("PKM_SvtvA_Malta", "PKM_SvtvA_TL");
			SetCharacterGoods(sld, GOOD_FOOD, 500);
			SetCharacterGoods(sld, GOOD_FRUITS, 700);

			Group_SetGroupCommander("PKM_SvtvA_Malta", "Maltese");
			Group_SetAddress("PKM_SvtvA_Malta", "SentMartin", "quest_ships", "Quest_ship_7");
			Group_LockTask("PKM_SvtvA_Malta");
			
			//Корабль 'Тёмный Ангел'
			sld = GetCharacter(NPC_GenerateCharacter("PKM_SvtvA_TA", "Animists1", "man", "man", 10, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 12, 40, 50, "blade26", "pistol1", 80);
			sld.name = "Personnage";
			sld.lastname = "mystérieux";
			FantomMakeCoolSailor(sld, SHIP_LA_MARIANNA, "Dark Angel", CANNON_TYPE_CULVERINE_LBS24, 60, 60, 60);	//Корабль
			sld.AlwaysEnemy = true;
			Group_FindOrCreateGroup("PKM_SvtvA_TL");
			Group_SetType("PKM_SvtvA_TL", "war");
			Group_AddCharacter("PKM_SvtvA_TL", "PKM_SvtvA_TA");
			realships[sti(sld.ship.type)].HP = 6000;
			realships[sti(sld.ship.type)].SpeedRate = 13;
			realships[sti(sld.ship.type)].TurnRate  = 14;

			Group_SetGroupCommander("PKM_SvtvA_TL", "PKM_SvtvA_TA");
			Group_SetAddress("PKM_SvtvA_TL", "SentMartin", "quest_ships", "Quest_ship_7");
			Group_LockTask("PKM_SvtvA_TL");
			
			//Условия задания
			
			PChar.quest.PKM_SvtvA_TA_ploho.win_condition.l1 = "NPC_Death";		//Поражение
			PChar.quest.PKM_SvtvA_TA_ploho.win_condition.l1.character = "Maltese";
			PChar.quest.PKM_SvtvA_TA_ploho.win_condition = "PKM_SvtvA_Маёнез_потопили";
			
			PChar.quest.PKM_SvtvA_TA_horosho.win_condition.l1 = "NPC_Death";		//Победа
			PChar.quest.PKM_SvtvA_TA_horosho.win_condition.l1.character = "PKM_SvtvA_TA";
			PChar.quest.PKM_SvtvA_TA_horosho.win_condition = "PKM_SvtvA_Ангела_потопили";
		break;
		
		//Квест "Strange things are happening in the archipelago" (После сопровождения корабля мальтийских рыцарей)
		case "PKM_SvtvA_Ch2_1":
			dialog.text = "Vous avez fait du beau travail ! Mais dites-moi, y a-t-il eu des surprises pendant votre voyage ?";
			link.l1 = "Non, sauf que lorsque j'ai rejoint la barque, elle était attaquée par des pirates qui essayaient de la couler par tous les moyens.";
			link.l1.go = "PKM_SvtvA_Ch2_2";
		break;

		case "PKM_SvtvA_Ch2_2":
			dialog.text = "Compris. Permettez-moi maintenant de vous remettre votre récompense et de vous proposer une nouvelle affaire.";
			link.l1 = "Merci, mais quelle mission voulez-vous me confier ?";
			link.l1.go = "PKM_SvtvA_Ch2_3";
			AddMoneyToCharacter(pchar, 5000);
			PChar.quest.PKM_SvtvA_TA_ploho.over = "yes";
		break;

		case "PKM_SvtvA_Ch2_3":
			dialog.text = "Rien d'extraordinaire. Portez simplement cette lettre au père Clermont, en Martinique. Et veillez à ce qu'elle ne tombe entre les mains de personne d'autre que lui !";
			link.l1 = "Je vais le faire. Puis-je prendre congé ?";
			link.l1.go = "PKM_SvtvA_Ch2_4";
			GiveItem2Character(PChar, "PKM_SvtvA_pismo2");
		break;

		case "PKM_SvtvA_Ch2_4":
			dialog.text = "Vous le pouvez, et que Dieu soit avec vous.";
			link.l1 = "Amen.";
			link.l1.go = "exit";
			
			AddQuestRecord("PKM_Animists", "19");
			sld = CharacterFromID("Maltese");
			RemoveCharacterCompanion(pchar, sld);
			Group_SetAddress("PKM_SvtvA_Malta", "none", "", "");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Znakomstvo_s_Malta2");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Dostavka_Malty");
			
			PChar.quest.PKM_SvtvA_Zasada2.win_condition.l1 = "location";
			PChar.quest.PKM_SvtvA_Zasada2.win_condition.l1.location = "SanJuan_town";
			PChar.quest.PKM_SvtvA_Zasada2.win_condition = "PKM_SvtvA_Zasada2";
			
			bDisableFastReload = true;
		break;

		//Квест "The story of the Beautiful Isabella"
        case "Romantic_1":
			dialog.text = "Salvator Olevares ? Oui, mon fils, c'est une paroissienne assidue et respectable... Qu'y a-t-il ?";
			link.l1 = "Je demandais simplement, padre. Au revoir...";
			link.l1.go = "exit";
			DeleteAttribute(Pchar, "RomanticQuest.PriestAsk");
		break;

        case "Romantic_2":
			dialog.text = GetFullName(pchar) + ", prenez-vous Isabella de Valdez pour épouse, et jurez-vous de vivre avec elle dans la paix et l'harmonie jusqu'à ce que la mort vous sépare ?";
			link.l1 = "Oui, padre.";
			link.l1.go = "Romantic_3";
		break;
        case "Romantic_3":
			locCameraToPos(3.64, 3.25, -7.84, false);
			LAi_SetActorType(npchar);
			LAi_ActorTurnToLocator(npchar, "goto", "goto5");
			dialog.text = "Et vous, Isabella de Valdez, prenez-vous pour époux " + GetMainCharacterNameGen() + " et jurez-vous de vivre avec lui dans la paix et l'harmonie jusqu'à ce que la mort vous sépare ?";
			link.l1 = "Oui, padre.";
			link.l1.go = "Romantic_4";
		break;
        case "Romantic_4":
			locCameraToPos(-0.75, 3.85, -10.60, false);
			LAi_SetActorType(npchar);
			LAi_ActorTurnToLocator(npchar, "goto", "goto5");
			dialog.text = "Si quelqu'un parmi les présents connaît une raison pour laquelle cet homme et cette femme ne peuvent être unis, qu'il parle maintenant ou se taise à jamais.";
			link.l1 = "...";
			link.l1.go = "Romantic_5";
		break;
        case "Romantic_5":
			dialog.text = "Je vous déclare désormais mari et femme !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			AddDialogExitQuest("Romantic_Padre_3");
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
