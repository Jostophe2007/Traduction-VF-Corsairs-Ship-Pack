// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Demandez, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> проверка на квесты
			if (CheckAttribute(pchar, "questTemp.State.Store"))
            {
                link.l1 = "וcoutez, je cherche un marchand nommé Jacob Lopez de Fonseca. Il est venu ici pour affaires, mais il n'est toujours pas revenu.";
                link.l1.go = "Step_S2_1";
            }
            // <== проверка на квесты

		break;
//*************************** Квест №2 испанки, задание Инквизиции ***************************
 		case "Step_S2_1":
			dialog.text = NPCStringReactionRepeat("Je l'ai vu il y a environ un mois. Je dois dire que c'était une drכle de rencontre. Le matin, j'ai croisé Yakov dans la rue, nous nous sommes salués, et il m'a dit qu'il passerait me voir pour affaires à l'heure du déjeuner. Mais je ne l'ai plus revu depuis.",
                                                  "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet, je vous ai répondu.", "Je vous dis que vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" au sujet de ce Yakov.", "וcoutez, reculez et ne me gênez pas ! Vous avez perdu la boule ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Et il ne vous a rien dit de plus précis : oם il logeait, oם il allait ?", "Hum, eh bien...", "Oui, exactement, "+ GetSexPhrase("posé la question", "posé la question") +"...", "Désolé, " + npchar.name + "...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_S2_2", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;
 		case "Step_S2_2":
			dialog.text = "Non, rien.";
			link.l1 = "Compris... Merci.";
			link.l1.go = "exit";
			AddQuestRecord("Spa_Line_2_Inquisition", "11");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);
}

