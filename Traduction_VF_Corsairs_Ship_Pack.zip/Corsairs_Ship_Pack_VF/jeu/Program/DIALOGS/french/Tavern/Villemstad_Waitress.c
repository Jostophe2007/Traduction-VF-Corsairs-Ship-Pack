// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			//==> проверяем поле состояния квестов
            if (CheckAttribute(pchar, "questTemp.State.Usurer"))
            {
                dialog.text = "Vous voulez me dire quelque chose ?";
    			link.l1 = ""+ GetSexPhrase("Oui. Enfin, je veux dire que vous êtes ravissante, ma belle. Même avec des larmes dans les yeux.", "Pourquoi êtes-vous si bouleversée, ma petite ? Vous pleurez, on dirait ?") +"";
    			link.l1.go = "Step_S2_1";
            }
            //<== проверяем поле состояния квестов
		break;
//*************************** Квест №2 испанки, задание Инквизиции ***************************
 		case "Step_S2_1":
    		dialog.text = NPCStringReactionRepeat("Oh...", "Oh, nous en avons déjà parlé...", "וcoutez, nous avons parlé, et c'est tout...", "Pourquoi tourmentez-vous une pauvre fille ? "+ GetSexPhrase("Vous croyez que j'ai du chagrin et que vous êtes là pour me consoler ?", "") +"", "block", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Alors, qui est-ce, celui qui vous a fait du mal ? Je peux peut-être vous aider ?", "Oui, c'est vrai.", "D'accord, d'accord...", ""+ GetSexPhrase("Je ne crois rien du tout, ma belle. Tout va bien...", "D'accord...") +"", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_S2_2", "none", "none", "none", npchar, Dialog.CurrentNode);
 		break;
 		case "Step_S2_2":
    		dialog.text = "C'est le fils de l'usurier, Jansen ! Il... il...";
    		link.l1 = "(Quelle chance !) C'est justement cet homme que je cherche. Que vous a-t-il fait ? Et oם puis-je le trouver ?";
    		link.l1.go = "Step_S2_3";
 		break;
 		case "Step_S2_3":
    		dialog.text = "Il m'a trompée. Il m'a promis monts et merveilles, il m'a promis de m'épouser, et il a filé ! Il s'est enfui hier avec des pirates, sur un lougre, pour Fort Orange !";
    		link.l1 = "Quel gredin ! Je l'étriperai quand je le croiserai.";
    		link.l1.go = "Step_S2_4";
 		break;
 		case "Step_S2_4":
    		dialog.text = "Et s'il en meurt ? Dites-lui plutכt de ne pas se montrer à la taverne. Sinon, je lui arracherai les yeux !";
    		link.l1 = "D'accord, je transmettrai.";
    		link.l1.go = "exit";
            AddQuestRecord("Spa_Line_2_Inquisition", "6");
            Pchar.quest.Inquisition_AttackLugger.win_condition.l1 = "location";
            Pchar.quest.Inquisition_AttackLugger.win_condition.l1.location = "Jamaica";
            Pchar.quest.Inquisition_AttackLugger.win_condition = "Inquisition_AttackLugger";
            SetTimerCondition("Inquisition_LuggerTimeOver", 0, 0, 20, false);
 		break;



	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

