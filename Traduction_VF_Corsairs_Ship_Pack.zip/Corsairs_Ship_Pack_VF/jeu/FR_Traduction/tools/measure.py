import os, sys, collections
sys.path.insert(0, os.path.dirname(__file__))
from cparse import scan_literals, CYR, LETTERS
ROOT = sys.argv[1]
EN = os.path.join(ROOT, 'Program', 'DIALOGS', 'english')
RU = os.path.join(ROOT, 'Program', 'DIALOGS', 'russian')
tot_files = 0; cand = []; ident_like = 0; missing_ru = 0; cyr_in_en = 0
uniq = collections.Counter()
for dp, dn, fn in os.walk(EN):
    for f in fn:
        p = os.path.join(dp, f); rel = os.path.relpath(p, EN)
        src = open(p, 'rb').read().decode('utf-8', 'replace')
        rp = os.path.join(RU, rel)
        ruset = set()
        if os.path.exists(rp):
            rsrc = open(rp, 'rb').read().decode('utf-8', 'replace')
            ruset = {v for _, _, v in scan_literals(rsrc)}
        else:
            missing_ru += 1
        tot_files += 1
        for s, e, v in scan_literals(src):
            if not LETTERS.search(v):
                continue
            if v in ruset and not CYR.search(v):
                continue
            if CYR.search(v): cyr_in_en += 1
            cand.append(v); uniq[v] += 1
print('files', tot_files, 'missing_ru', missing_ru)
print('candidate literals', len(cand), 'chars', sum(map(len, cand)))
print('unique literals', len(uniq), 'chars', sum(map(len, uniq)))
print('with cyrillic', cyr_in_en)
