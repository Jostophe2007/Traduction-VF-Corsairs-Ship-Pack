#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Salut à mon ami, qui est aussi"+ GetSexPhrase(" un très brave homme", " une très brave fille") +". Qu'est-ce que je peux faire pour toi ?";
			link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
			link.l1.go = "SeekCitizen";
			link.l2 = "Je voudrais vous poser une question.";
			link.l2.go = "int_quests";
			link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
				"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
			link.l3.go = "rumours_LSC";
			link.l10 = "Rien...";
			link.l10.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je préfère m'en occuper moi-même. Je vais chercher.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Alors, comment ça va depuis ta sortie de prison ?";
				link.l1.go = "ansewer_1";
			}
			link.l10 = "Pas de questions. Désolé, l'ami...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Maintenant, je suis aux ordres de ma femme. J'ai donné ma parole de ne plus boire.";
			link.l1 = "Et tu as bien raison, bravo.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		//нерадивый муж Элис Тейлор
		case "InPrison":
			dialog.text = "Hé, "+ GetSexPhrase("l'ami", "ma petite") +" ! Tu veux bien m'aider ?";
			link.l1 = "Eh bien, en quoi puis-je t'aider ?";
			link.l1.go = "InPrison_1";
		break;
		case "InPrison_1":
			dialog.text = "Préviens ma femme que je me suis encore fourré dans le pétrin !";
			link.l1 = "Et qui est ta femme ?";
			link.l1.go = "InPrison_2";
		break;
		case "InPrison_2":
			dialog.text = "Alice Taylor, "+ GetSexPhrase("l'ami", "ma belle") +". C'est la propriétaire de la flמte Ceres Smithy. Et moi, je m'appelle Maxim Taylor.";
			link.l1 = "C'est un plaisir, Maxim.";
			link.l1.go = "InPrison_3";
		break;
		case "InPrison_3":
			dialog.text = "Pour moi aussi ! Alors, tu vas le faire ?";
			link.l1 = "Si je vois ta femme, je ne manquerai pas de la prévenir.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "2");
			pchar.questTemp.LSC.ElisHusband = "toElis";
			NextDiag.TempNode = "InPrison_wait";
		break;

		case "InPrison_wait":
			dialog.text = "Eh, "+ GetSexPhrase("l'ami", "ma belle") +", tu es mon seul espoir de sortir d'ici. Je t'en prie, trouve vite Alice...";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;

		case "DontRemember":
			dialog.text = NPCStringReactionRepeat("Qu'est-ce qu'il te faut, "+ GetSexPhrase("l'ami", "ma petite") +" ?",
				""+ GetSexPhrase("L'ami", "Ma belle") +", tu veux savoir autre chose ?",
				"Je ne me souviens de rien, le trou noir complet.",
                ""+ GetSexPhrase("L'ami", "Ma belle") +", il faut me sortir d'ici au plus vite. Bouge-toi, j'ai la gorge en feu...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Ta femme veut te faire sortir d'ici. Tu peux m'expliquer ce que tu as fait pour te retrouver là ?",
				"Non.",
                "Oui...",
				"Il va falloir prendre patience.", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("DontRemember_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "DontRemember_1":
			dialog.text = "Je ne me souviens de rien...";
			link.l1 = "Comment ça ? Rien du tout ?";
			link.l1.go = "DontRemember_2";
		break;
		case "DontRemember_2":
			dialog.text = "Absolument rien. J'ai perdu connaissance à la taverne. On dit que je suis allé à la résidence et que je m'en suis pris à l'amiral en personne ! Quelle horreur...";
			link.l1 = "Eh oui, il faut boire moins.";
			link.l1.go = "DontRemember_3";
		break;
		case "DontRemember_3":
			dialog.text = "Il le faudrait. Mais je n'y arrive pas !";
			link.l1 = "Héhé, bravo !";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "6");
			pchar.questTemp.LSC.ElisHusband = "toAdmiral";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
