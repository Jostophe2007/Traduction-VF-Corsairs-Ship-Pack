// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";

			if (CheckAttribute(pchar, "questTemp.PDM_ONV_SanJuan"))	//Квест "Witch Hunt"
            {
                link.l1 = "Le nom de Maria Carle vous dit-il quelque chose ?";
                link.l1.go = "PDM_ONV_SJ_1";
            }
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_PoiskPadre_Tavern"))	//Квест "Strange things are happening in the archipelago"
            {
                link.l1 = "J'aimerais savoir quelles rumeurs circulent sur l'enlèvement d'un prêtre d'ici.";
                link.l1.go = "PKM_SvtvA_PPT_1";
            }

            // ==> Проверяем поле состояния квестов. Эдди.
			switch(pchar.questTemp.State)
            {
                case "MorrisWillams_PinnaceNotFound":
                    link.l2 = "דa fait un moment que je ne suis pas venu ici... Quoi de neuf à San Juan ?";
                    link.l2.go = "Step_E6_1";
                break;
            }
		break;
        //---------------- квесты --------------------
        case "Step_E6_1":
			dialog.text = "En somme, tout est comme avant. La ville prospère.";
			link.l1 = "Je vois... Dites, la pinasse Santa Agueda est-elle entrée en ville ?";
			link.l1.go = "Step_E6_2";
		break;
        case "Step_E6_2":
			dialog.text = "Oui, elle est arrivée tout droit de, figurez-vous, Port Royal !";
			link.l1 = "Eh bien ! On a fait la paix avec les Anglais ?";
			link.l1.go = "Step_E6_3";
		break;
        case "Step_E6_3":
			dialog.text = "Disons que ce n'est pas la paix, mais ce n'est plus la guerre. Les Anglais ont des démêlés avec les Hollandais en ce moment, alors les relations s'améliorent dans l'Ancien Monde.";
			link.l1 = "Eh bien, c'est pour le mieux... Et oם est cette pinasse maintenant ?";
			link.l1.go = "Step_E6_4";
		break;
        case "Step_E6_4":
			dialog.text = "Elle a déchargé ses cales et elle est repartie. Maintenant, San Juan regorge d'indigo et d'argent. Les prix ont baissé...";
			link.l1 = "Alors la cargaison de la pinasse est vendue ?";
			link.l1.go = "Step_E6_5";
		break;
        case "Step_E6_5":
			dialog.text = "Bien sמr ! Et pourquoi avez-vous besoin de cette pinasse ?";
			link.l1 = "Oui, j'avais "+ GetSexPhrase("convenu", "convenu") +" qu'on me remettrait cette cargaison, et ils ont tout vendu ici...";
			link.l1.go = "Step_E6_6";
		break;
        case "Step_E6_6":
			dialog.text = "Eh bien, la prochaine fois, entendez-vous avec quelqu'un d'autre.";
			link.l1 = "C'est vrai, l'ami. Merci, porte-toi bien.";
			link.l1.go = "exit";
			pchar.questTemp.State = "MorrisWillams_2PinnaceNotFound";
		break;

		case "PDM_ONV_SJ_1":	//Квест "Witch Hunt"
			dialog.text = "Ce nom ne me dit rien. Mais vous avez de la chance : cet homme, à la table, a prononcé ce nom plus d'une fois en avalant son rhum avec une rage folle.";
			link.l1 = "Vous m'avez bien aidé. Merci !";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PDM_ONV_SanJuan");
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld = CharacterFromID("PDM_ONV_Viktor_Martos");
				sld.quest.questflag.model = "questionmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
		break;
		
		case "PKM_SvtvA_PPT_1":	//Квест "Strange things are happening in the archipelago"
			dialog.text = "Oui, toute la colonie en parle ! Imaginez, ils ont fait irruption dans l'église en plein jour et l'ont enlevé ! Personne n'a même eu le temps de cligner des yeux qu'ils avaient déjà disparu !";
			link.l1 = "Et qui étaient-ils ? Des gens en robe rouge ?";
			link.l1.go = "PKM_SvtvA_PPT_2";
		break;
		
		case "PKM_SvtvA_PPT_2":
			dialog.text = "Non. C'étaient de simples voyous. Mais c'est étrange que vous parliez de gens en robe rouge...";
			link.l1 = "Ah oui ? Pourquoi donc ?";
			link.l1.go = "PKM_SvtvA_PPT_3";
		break;
		
		case "PKM_SvtvA_PPT_3":
			dialog.text = "Le fait est qu'un type est apparu ici récemment, habillé exactement comme vous le dites...";
			link.l1 = "Vraiment ? Et que s'est-il passé ensuite ?";
			link.l1.go = "PKM_SvtvA_PPT_4";
		break;
		
		case "PKM_SvtvA_PPT_4":
			dialog.text = "Rien qui puisse vous intéresser. Ce sont nos problèmes internes.";
			link.l1 = "Vous pourriez peut-être m'en parler quand même ? Il me semble que ces deux événements sont liés.";
			link.l1.go = "PKM_SvtvA_PPT_5";
		break;
		
		case "PKM_SvtvA_PPT_5":
			dialog.text = "Vous avez peut-être raison. Je vais vous raconter. וcoutez\nIl y a trois ans, nous avions ici ce type à la chlamyde rouge. Si poli, jamais un mot de travers pour personne...";
			link.l1 = "Continuez.";
			link.l1.go = "PKM_SvtvA_PPT_6";
		break;
		
		case "PKM_SvtvA_PPT_6":
			dialog.text = "Eh bien, tout le monde s'est mis à le regarder de travers, mais il ne faisait rien de mal : il parlait avec les jeunes, et nous en étions même contents, pour une fois qu'ils ne traînaient pas dans les rues.";
			link.l1 = "Et ?";
			link.l1.go = "PKM_SvtvA_PPT_7";
		break;
		
		case "PKM_SvtvA_PPT_7":
			dialog.text = "Hé, et puis il s'est passé quelque chose. Voilà que tous les jeunes gars partent en je ne sais quelle randonnée avec lui\nLe fils du forgeron a carrément quitté la maison ; le forgeron est allé parler à ce type, il est ressorti de chez lui comme une bombe, et la nuit, il s'est soמlé et s'est noyé en allant sur le quai\nEt son fils ne s'en est même pas aperçu. Il vit comme si de rien n'était.";
			link.l1 = "Oui, tout ça est bien étrange. Oם puis-je trouver ce type ??";
			link.l1.go = "PKM_SvtvA_PPT_8";
		break;
		
		case "PKM_SvtvA_PPT_8":
			dialog.text = "Le fils du forgeron ? Oh, il traîne quelque part en ville. Et le type au capuchon a disparu on ne sait oם.";
			link.l1 = "D'accord, je vais aller lui parler. Comment s'appelle-t-il ?";
			link.l1.go = "PKM_SvtvA_PPT_9";
		break;
		
		case "PKM_SvtvA_PPT_9":
			dialog.text = "Il s'appelle Giordano.";
			link.l1 = "Merci.";
			link.l1.go = "PKM_SvtvA_PPT_10";
		break;
		
		case "PKM_SvtvA_PPT_10":
			DialogExit();
			
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_PoiskPadre_Tavern");
			AddQuestRecord("PKM_Animists", "25");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			
			sld = GetCharacter(NPC_GenerateCharacter("PKM_Jordano", "Jordano", "man", "man1", 10, PIRATE, -1, false));
			sld.name = "Giordano";
			sld.lastname = "";
			LAi_SetStayType(sld);
			sld.City = "SanJuan";
			sld.dialog.filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Джордано_1";
			ChangeCharacterAddressGroup(sld, "SanJuan_town", "patrol", "patrol16");
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

