void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref PChar = GetMainCharacter();
	string sName = PChar.name + " " + PChar.lastname;

	int iBricks = sti(PChar.BuildingColony.Blocks);
	int iPlanks = sti(PChar.BuildingColony.Planks);
	int iMahogany = sti(PChar.BuildingColony.Mahogany);
	int iEbony = sti(PChar.BuildingColony.Ebony);
	int iSlaves = sti(PChar.BuildingColony.Slaves);
	int iFood = sti(PChar.BuildingColony.Food);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que puis-je pour vous, "+GetSexPhrase("Herr Kapitan", "Fraulein")+" " + sName + " ?";
			if(PChar.ColonyBuilding.Stage != "3" && PChar.ColonyBuilding.Action != true)
			{
				link.l1 = "Je crois que vos services m'intéressent.";
				link.l1.go = "Building";
			}
			link.l2 = "Je voulais juste vous voir.";
			link.l2.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Hi1":
			dialog.text = "Guten Tag, "+GetSexPhrase("Herr Kapitan", "Fraulein")+" " + sName + " ! Vous ne croirez jamais ce qui m'est arrivé !";
			link.l1 = "Bonjour, monsieur Zalpfer, je ne m'attendais pas à vous voir ici. Que faites-vous là ?";
			link.l1.go = "Hi";
			NextDiag.TempNode = "First time";
		break;

		case "Hi":
			dialog.text = "C'est grâce à Morgan ! Ja, LUI seul, le seul à m'avoir écouté et à avoir compris le génie de mes inventions, qui servent désormais la Couronne d'Angleterre !\n"+
							"Je travaille actuellement à un nouveau projet qui me permettra de bâtir une ville entière en un temps record. Elle éclipsera toutes les autres colonies de l'archipel des Caraïbes, ja ! Je vous le dis ! Et peut-être même le monde entier, qui sait..."
			link.l1 = "Vraiment ? Voilà qui est intéressant.";
			link.l1.go = "First time";
		break;

		case "Building":
			dialog.text = "Que souhaitez-vous exactement ?";

			if(PChar.ColonyBuilding.Stage == "0")
			{
				link.l1 = "J'aimerais commencer à bâtir une colonie.";
				link.l1.go = "ColonyBuilding";
			}

			if(PChar.ColonyBuilding.Stage == "1")
			{
				link.l2 = "J'aimerais agrandir ma colonie, qui porte le nom de '" + PChar.ColonyBuilding.ColonyName + "'.";
				link.l2.go = "ColonyModification";
			}

			if(PChar.ColonyBuilding.Stage == "2")
			{
				link.l3 = "Je voudrais renforcer ma colonie, construire un fort pour la protéger.";
				link.l3.go = "ColonyFortBuildingNoNo";
			}

			link.l4 = "Désolé, mais je dois y aller. Les affaires m'attendent.";
			link.l4.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "ColonyBuilding":
	    	if(CheckAttribute(pchar, "VedekerDiscount"))//Скидка от Ведекера.
	    	{
				NPChar.NeedMoney = 1000000/2;
	    		dialog.text = "Hum... Bien. Je pense qu'il faut d'abord explorer les îles inhabitées pour voir si elles se prêtent à la construction d'une colonie. Par ailleurs, mon travail n'est évidemment pas gratuit, et il vous en coמtera "+(1000000)+" piastres. Cela dit, vous avez avec vous un technicien compétent. Avec son aide, nous pourrons réduire sensiblement la dépense, à environ "+NPChar.NeedMoney+" piastres, à condition bien sמr qu'il m'aide. Qu'en dites-vous ?";
	    	}
	    	else
	    	{
				NPChar.NeedMoney = 1000000;
		    	dialog.text = "Hum... Bien. Je pense qu'il faut d'abord explorer les îles inhabitées pour voir si elles se prêtent à la construction d'une colonie. Par ailleurs, mon travail n'est évidemment pas gratuit, et il vous en coמtera "+(1000000)+" piastres. Qu'en dites-vous ?";
		    }

			if(sti(PChar.money) >= sti(NPChar.NeedMoney))
			{
				link.l1 = "J'accepte.";
				link.l1.go = "ColonyBuilding_1";
			}
			else
			{
				link.l2 = "Je n'ai pas encore assez d'argent.";
				link.l2.go = "exit";
			}

			link.l3 = "Désolé, je dois y aller.";
			link.l3.go = "exit";
		break;

		case "ColonyBuilding_1": // Первый этап строительства - колония первого тира
			AddMoneyToCharacter(PChar, -sti(NPChar.NeedMoney));
			dialog.text = "Alors il faut explorer les îles inhabitées au plus vite.";
			link.l1 = "Je vais essayer d'appareiller au plus vite !";
			link.l1.go = "ColonyBuilding_exit";
			PChar.BuildingColony.Blocks = 500; // Кирпичи
			PChar.BuildingColony.Planks = 1000; // Доски
			PChar.BuildingColony.Mahogany = 500; // Красное дерево
			PChar.BuildingColony.Ebony = 250; // Чёрное дерево
			PChar.BuildingColony.Slaves = 200; // Рабы
			PChar.BuildingColony.Food = 400; // Провиант
		break;

		case "ColonyBuilding_2":
			dialog.text = ""+GetSexPhrase("Herr Kapitan", "Fraulein")+". Après avoir soigneusement examiné cette île, je suis arrivé à la conclusion que c'est exactement l'endroit oם il faut commencer la construction de la colonie. Les éclaireurs ont trouvé des traces de gisements, ce qui pourrait être économiquement avantageux pour la colonie, ja. De plus, son sol est le plus fertile de toutes les îles que nous avons visitées.";
			link.l1 = "Vous croyez, Albrecht, que je vais y faire pousser des ananas et du café ? Je suis corsaire, pas fermier !";
			link.l1.go = "ColonyBuilding_2_1";
		break;

		case "ColonyBuilding_2_1":
			dialog.text = "Ja ?! Et comment comptez-vous nourrir les habitants de la colonie ? En tirant bravement au canon sur les navires de passage pour exiger des vivres ? Dans ce cas, soit tout le monde mourra de faim, soit l'une des puissances vous fera payer une telle imprudence !";
			link.l1 = "Doucement, Albrecht.. Bon, je me suis un peu emballé !";
			link.l1.go = "ColonyBuilding_2_2";
		break;

		case "ColonyBuilding_2_2":
			dialog.text = "Et ne m'apprenez pas mon métier. Je ne vous apprends pas à égorger les gens, moi.";
			link.l1 = "Hum.. Et ensuite ?";
			link.l1.go = "ColonyBuilding_3";
			AddDialogExitQuest("ColonyBuildingCayman");
		break;

		case "ColonyBuilding_3":
			dialog.text = "Maintenant, il me faudra certaines marchandises nécessaires à la construction de la colonie. Des briques : " + FloatToString(iBricks,0) + " unités, des planches : " + iPlanks + " unités, de l'acajou : " + iMahogany + " unités, de l'ébène : " + iEbony + " unités, des vivres : " + iFood + " unités, et " + iSlaves + " esclaves. Dès que toutes les marchandises seront livrées, nous commencerons la construction, ja !";
			link.l1 = "D'accord.";
			link.l1.go = "exit";

			NextDiag.TempNode = "ColonyBuilding_4";
		break;

		case "ColonyBuilding_4":
			dialog.text = "Que vouliez-vous, capitaine ?";
			if(sti(PChar.BuildingColony.Blocks) == 0 && sti(PChar.BuildingColony.Planks) == 0 && sti(PChar.BuildingColony.Mahogany) == 0 && sti(PChar.BuildingColony.Ebony) == 0 && sti(PChar.BuildingColony.Slaves) == 0 && sti(PChar.BuildingColony.Food) == 0)
			{
				dialog.text = "J'ai le plaisir de vous annoncer, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +", que toutes les marchandises nécessaires ont été livrées. Nous commençons la construction ! D'après mes calculs, elle prendra un peu plus d'un mois.";
				link.l1 = "Voilà une bonne nouvelle ! J'attendrai avec impatience la fin de la construction.";
				link.l1.go = "exit";
				AddDialogExitQuest("ColonyBuilding_1");
				NextDiag.TempNode = "ColonyBuilding_6";
			}
			else
			{
				link.l1 = "Je voudrais vous remettre les marchandises nécessaires.";
				link.l1.go = "ColonyBuilding_5";
				NextDiag.TempNode = "ColonyBuilding_4";
			}
		break;

		case "ColonyBuilding_5":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchColonyBuilding(false, false);
		break;

		case "ColonyBuilding_6":
			dialog.text = "Ah, c'est vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! La construction bat son plein, ja !";
			link.l1 = "א plus tard.";
			link.l1.go = "exit";
		break;

		case "ColonyBuilding_7":
			dialog.text = "Guten Tag, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! J'ai le plaisir de vous annoncer que la construction de votre colonie est terminée ! Si vous avez de nouveau besoin de mes services, vous me trouverez dans votre colonie.";
			link.l1 = "Excellent, monsieur Zalpfer. Et maintenant, si vous voulez bien m'excuser, les affaires m'attendent.";
			pchar.questTemp.colonystate = sti(pchar.questTemp.colonystate) + 1;
			UnlockAchievement("AchBuildColony", 1);
			link.l1.go = "exit";
			NextDiag.TempNode = "ColonyBuilding_8";
			AddDialogExitQuest("ColonyBuilding_3");
		break;

		case "ColonyBuilding_exit":
			AddDialogExitQuest("ColonyBuilding");
			PChar.ColonyBuilding.Architector = NPChar.id;
			NextDiag.TempNode = "ColonyBuilding_8";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ColonyBuilding_8":
			dialog.text = "Guten Tag, " + sName + ". Vous vouliez quelque chose ?";
			link.l1 = "Non, rien. א plus tard.";
			link.l1.go = "exit";
		break;

		//---------------------------------------------------------------------------------------------------------

		case "ColonyModification":
			dialog.text = "Hum... C'est une tâche tout à fait réalisable. Mais comprenez bien que cela vous coמtera beaucoup d'argent. D'abord, nous devons nous retrouver dans une crique voisine pour discuter de tous les détails de la future construction.";
			link.l1 = "D'accord, à plus tard.";
			link.l1.go = "ColonyModification_exit";
		break;

		case "ColonyModification_1":
			dialog.text = "Vous voilà, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +". Eh bien, commençons. Avant de lancer la construction, nous devons choisir l'architecture de la future ville et de ses bâtiments.";
			link.l1 = "Hum... Voyons voir...";
			link.l1.go = "ColonyModification_6";
			NextDiag.TempNode = "ColonyModification_5";
		break;

		case "ColonyModification_2":
			AddQuestRecord("ColonyBuilding", "8");
			dialog.text = "Excellent, capitaine. Et je vous préviens tout de suite qu'il me faudra les marchandises suivantes pour la construction : des briques : " + iBricks + " unités, des planches : " + iPlanks + " unités, de l'acajou : " + iMahogany + " unités, de l'ébène : " + iEbony + " unités, des vivres : " + iFood + " unités, et " + iSlaves + " esclaves. Quand tout cela sera livré, nous commencerons la construction.";
			link.l1 = "Je vais essayer de livrer tout le nécessaire au plus vite.";
			link.l1.go = "ColonyModification_3";
			LAi_SetPlayerType(PChar);
			LAi_SetStayType(CharacterFromID("Builder"));
		break;

		case "ColonyModification_3":
			dialog.text = "Que vouliez-vous, capitaine ?";
			if(sti(PChar.BuildingColony.Blocks) == 0 && sti(PChar.BuildingColony.Planks) == 0 && sti(PChar.BuildingColony.Mahogany) == 0 && sti(PChar.BuildingColony.Ebony) == 0 && sti(PChar.BuildingColony.Slaves) == 0 && sti(PChar.BuildingColony.Food) == 0)
			{
				dialog.text = "J'ai le plaisir de vous annoncer, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" que toutes les marchandises nécessaires ont été livrées et que nous commençons la construction. D'après mes calculs, elle prendra un peu plus d'un mois et demi, ja !";
				link.l1 = "J'attendrai avec impatience la fin de la construction.";
				link.l1.go = "exit";
				AddDialogExitQuest("ColonyModification_2");
				NextDiag.TempNode = "ColonyBuilding_6";
			}
			else
			{
				link.l1 = "Je voudrais vous remettre les marchandises nécessaires.";
				link.l1.go = "ColonyBuilding_5";
				NextDiag.TempNode = "ColonyModification_3";
			}
		break;

		case "ColonyModification_4":
			dialog.text = "J'ai le plaisir de vous annoncer que l'agrandissement de la colonie " + PChar.ColonyBuilding.ColonyName + " est terminé ! Ce fut un plaisir de travailler avec vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +". Je crois que je vais rester ici encore un moment. Si vous voulez me retrouver, je serai à la résidence.";
			link.l1 = "Merci, " + npchar.name + ".";
			link.l1.go = "exit";
			pchar.questTemp.colonystate = sti(pchar.questTemp.colonystate) + 1;
			UnlockAchievement("AchBuildColony", 2);
			NextDiag.TempNode = "First time";
			AddDialogExitQuest("ColonyModification_4");
			PChar.quest.BuilderToTownhall.win_condition.l1 = "ExitFromLocation";
			PChar.quest.BuilderToTownhall.win_condition.l1.location = PChar.location;
			PChar.quest.BuilderToTownhall.win_condition = "BuilderToTownhall";
		break;

		case "ColonyModification_5":
			dialog.text = "C'est vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" " + sName + " ? On rediscute des détails de la construction ?";
			link.l1 = "Oui, je veux redéfinir l'architecture de la ville et des bâtiments.";
			link.l1.go = "ColonyModification_6";
			link.l2 = "Non, je voulais juste vous rendre visite.";
			link.l2.go = "exit";
			NextDiag.TempNode = "ColonyModification_5";
		break;

		case "ColonyModification_6":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchColonyBuilding(true, true);
		break;

		case "ColonyModification_exit":
			PChar.quest.ColonyModification_5.win_condition.l1 = "ExitFromLocation";
			PChar.quest.ColonyModification_5.win_condition.l1.location = PChar.location;
			PChar.quest.ColonyModification_5.win_condition = "ColonyModification_5";

			LAi_SetCitizenType(NPChar);
			AddDialogExitQuest("ColonyModification");
			NextDiag.TempNode = "ColonyBuilding_8";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//---------------------------------------------------------------------------------------------------------

		case "ColonyBuilding_Dominica":
			dialog.text = "C'est trop risqué de s'installer entre les îles de la France et de l'Angleterre : personne ne manquera l'occasion de s'approprier un morceau aussi appétissant, et vous vous retrouverez entre deux feux !";
			link.l1 = "Vous avez peut-être raison. Il faut explorer plus loin...";
			link.l1.go = "exit";
			AddDialogExitQuest("ColonyBuildingDominica");
		break;

		case "ColonyBuilding_Terks":
			dialog.text = "Non, non, les îles Turques sont trop près du repaire de ces maudits pirates, et ce serait de la folie de bâtir une colonie sous leur nez, ja !";
			link.l1 = "Vous avez peut-être raison. Il faut explorer plus loin...";
			link.l1.go = "exit";
			AddDialogExitQuest("ColonyBuildingTerks");
		break;

		//---------------------------------------------------------------------------------------------------------

		case "ColonyFortBuildingNoNo":
			dialog.text = "Hum... Je ne voudrais pas vous décevoir, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +", mais le relief de l'île ne permet pas de construire une fortification. Je peux vous proposer de construire une sorte de base de garde : elle vous permettra d'avoir une garnison impressionnante, capable de repousser n'importe quel rival, et de créer de bonnes conditions pour protéger efficacement le littoral. De plus, la base de garde fermera tous les accès terrestres à la colonie, ce qui renforcera sensiblement sa protection en cas d'attaque ennemie par la terre. Qu'en pensez-vous, "+GetSexPhrase("Herr", "Frau")+" Kapitan ?";
			link.l1 = "La colonie doit être protégée. Discutons donc plus en détail de la construction d'une base de garde.";
			link.l1.go = "ColonyFortBuilding";
			link.l2 = "Désolé, je dois y aller.";
			link.l2.go = "exit";
		break;

		case "ColonyFortBuilding":
			if(CheckAttribute(pchar, "VedekerDiscount"))
			{
				NPChar.NeedMoney = 1000000/2;
				dialog.text = "Je serai ravi de vous aider, ja ! Mais cela vous coמtera beaucoup d'argent. Pour mon travail, je veux recevoir "+Sti(NPChar.NeedMoney)+" pièces d'or.";
			}
			else
			{
				NPChar.NeedMoney = 1000000;
			    dialog.text = "Je serai ravi de vous aider, ja ! Mais cela vous coמtera beaucoup d'argent. Pour mon travail, je veux recevoir "+Sti(NPChar.NeedMoney)+" pièces d'or.";
			}
			if(sti(PChar.money) >= Sti(NPChar.NeedMoney))
			{
				link.l1 = "J'accepte.";
				link.l1.go = "ColonyFortBuilding_1";
			}
			else
			{
				link.l2 = "Je n'ai pas encore assez d'argent.";
				link.l2.go = "exit";
			}
			link.l3 = "Désolé, je dois y aller.";
			link.l3.go = "exit";
		break;

		case "ColonyFortBuilding_1":
			dialog.text = "Parfait, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! Retrouvez-moi à un endroit appelé « Plage déserte » : c'est là que seront posées les fondations de notre ouvrage défensif.";
			link.l1 = "א plus tard.";
			link.l1.go = "ColonyFortBuilding_to_port";
			AddDialogExitQuest("ColonyFortBuilding_1");
			AddMoneyToCharacter(PChar, -sti(NPChar.NeedMoney));
		break;

		case "ColonyFortBuilding_2":
			dialog.text = "Parfait, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! Retrouvez-moi à un endroit appelé « Plage déserte ».";
			link.l1 = "א plus tard.";
			link.l1.go = "ColonyFortBuilding_to_port";
		break;

		case "ColonyFortBuilding_3":
			
			dialog.text = "Pour la construction, il nous faudra les marchandises suivantes : des briques : " + iBricks + " unités, des planches : " + iPlanks + " unités, de l'acajou : " + iMahogany + " unités, de l'ébène : " + iEbony + " unités, des vivres : " + iFood + " unités, et " + iSlaves + " esclaves.";
			link.l1 = "Je vais essayer de livrer tout le nécessaire au plus vite.";
			link.l1.go = "ColonyFortBuilding_to_start_transfer_goods";
			AddDialogExitQuest("ColonyFortBuilding_4");
		break;

		case "ColonyFortBuilding_4":
			dialog.text = "Que vouliez-vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ?";
			if(sti(PChar.BuildingColony.Blocks) == 0 && sti(PChar.BuildingColony.Planks) == 0 && sti(PChar.BuildingColony.Mahogany) == 0 && sti(PChar.BuildingColony.Ebony) == 0 && sti(PChar.BuildingColony.Slaves) == 0 && sti(PChar.BuildingColony.Food) == 0)
			{
				dialog.text = "J'ai le plaisir de vous annoncer, capitaine, que toutes les marchandises nécessaires ont été livrées. Nous commençons la construction de la base ! Sauf événement surnaturel, dans un mois et demi, vous verrez ici un tout autre tableau, ja.";
				link.l1 = "D'accord, monsieur " + GetFullName(NPChar) + ".";
				link.l1.go = "exit";
				AddDialogExitQuest("ColonyFortBuilding_5");
				NextDiag.TempNode = "ColonyFortBuilding_5";
			}
			else
			{
				link.l1 = "Je voudrais vous remettre les marchandises nécessaires.";
				link.l1.go = "ColonyBuilding_5";
				NextDiag.TempNode = "ColonyFortBuilding_4";
			}
		break;

		case "ColonyFortBuilding_5":
			dialog.text = "Ah, c'est vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! La construction bat son plein !";
			link.l1 = "א plus tard.";
			link.l1.go = "exit";
		break;

		case "ColonyFortBuilding_6":
			dialog.text = "La base de garde de votre colonie est terminée ! Ce fut un plaisir de travailler avec vous, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +". Je rentre chez moi.";
			link.l1 = "Merci pour votre travail, monsieur Zalpfer.";
			link.l1.go = "exit";
			pchar.questTemp.colonystate = sti(pchar.questTemp.colonystate) + 1;
			UnlockAchievement("AchBuildColony", 3);
			NextDiag.TempNode = "First Time";
			AddDialogExitQuest("ColonyFortBuilding_7");
		break;

		case "ColonyFortBuilding_to_port":
			LAi_SetCitizenType(NPChar);
			NextDiag.TempNode = "ColonyBuilding_8";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ColonyFortBuilding_to_start_transfer_goods":
			NextDiag.TempNode = "ColonyFortBuilding_4";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ForSlave":
			dialog.text = RandPhraseSimple(RandPhraseSimple("Je suis si fatigué, je ne tiens plus debout.", "Je ne peux plus vivre comme ça !"), RandPhraseSimple("Ce travail est trop dur pour moi.", "Les contremaîtres ne m'ont pas laissé un pouce de peau intact !"));
			link.l1 = RandPhraseSimple("Désolé pour toi, l'ami.", "Tu me fais de la peine.");
			link.l1.go = "exit";
			NextDiag.TempNode = "ForSlave";
		break;

		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+GetSexPhrase("l'ami", "ma petite")+", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand"+GetSexPhrase("des hommes", "des filles")+" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
		break;

	}
}
