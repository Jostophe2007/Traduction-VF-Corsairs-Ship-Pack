
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "fight":
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "quest_fight":
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "DeliverToBander_Dead");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "First time":
			dialog.text = "Qui êtes-vous ?!";
			link.l1 = "Doucement, pas de bruit. C'est votre ami qui est au cachot qui m'envoie : " + pchar.questTemp.jailCanMove.Deliver.name + ". Vous connaissez quelqu'un de ce nom ?";
			link.l1.go = "Step_1";
			NextDiag.TempNode = "Second time";
		break;
		case "Step_1":
			dialog.text = "Comment pouvez-vous prouver que vous n'êtes pas un des limiers du gouverneur ?";
			link.l1 = "Je lui ai demandé de me donner un mot. Le voici.";
			link.l1.go = "Step_2";
			TakeItemFromCharacter(pchar, "Malyava");
		break;

		case "Step_2":
		dialog.text = "Bon... (il lit). Bon sang ! Il a fallu qu'il se mette dans un tel pétrin... Eh, une si belle affaire qui s'envole... וcoute, matelot, je vois "+ GetSexPhrase("que tu es un costaud", "que tu es une fille de combat") +". Et puis, tu m'as l'air d'être de la Confrérie. Tu ne voudrais pas gagner un peu d'argent ? Toi, tu y gagneras, et nous aussi.";
					link.l1 = "J'ai toujours envie de gagner un peu d'argent. Qu'est-ce que tu proposes ?";
					link.l1.go = "Step_3";

			break;

			case "Step_3":
			dialog.text = "Je peux te vendre une information. Je n'en ai pas besoin en ce moment, je ne peux pas en profiter, mais elle pourrait te servir. Seulement, pas gratuitement : ça coמte de l'argent, tu le sais. C'est une affaire juteuse, crois-moi.";
			link.l1 = "Combien voulez-vous ?";
			link.l1.go = "Step_4";
		break;

		case "Step_4":
			dialog.text = "50 000 piastres.";
			if(makeint(Pchar.money) >= 50000)
			{
			link.l1 = "Hum, c'est une grosse somme. Mais si ça en vaut la peine... J'accepte.";
			link.l1.go = "Step_5";
			}
			link.l2 = "Non. Je n'ai pas l'intention de payer pour une information inconnue venant d'un inconnu. Je n'achète pas chat en poche.";
			link.l2.go = "Step_no";
		break;

		case "Step_5":
			switch (sti(pchar.questTemp.jailCanMove.Deliver.good))
			{
				case 0://попытка грабежа
					dialog.text = "Bon, bon, très bien, "+ GetSexPhrase("tu es tombé dans le panneau, le pigeon", "tu es tombée dans le panneau, la gourde") +". Allez, donne-moi ton argent !";
				link.l1 = "Quel culot. Et ton ami disait que ses amis étaient généreux.";
				link.l1.go = "Step_fight";
				break;
				case 1://кидалово
					AddMoneyToCharacter(pchar, -50000);
					GetBandersTradeShore();
					GetBandersTradeGoods();
					GetBandersTradeNation();
					pchar.questTemp.jailCanMove.Deliver.terms = 10+rand(2);
					pchar.questTemp.jailCanMove.Deliver.ShipName1 = GenerateRandomNameToShip(sti(pchar.questTemp.jailCanMove.Deliver.Nation));
					pchar.questTemp.jailCanMove.Deliver.ShipName2 = GenerateRandomNameToShip(sti(pchar.questTemp.jailCanMove.Deliver.Nation));

					dialog.text = "Bon, écoute bien. J'ai appris de source sמre que dans les " + FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)) + " qui viennent, au large de "+ pchar.questTemp.jailCanMove.Deliver.Island.Areal +" passeront deux navires marchands "+ pchar.questTemp.jailCanMove.Deliver.add1 +" : le '"+ pchar.questTemp.jailCanMove.Deliver.ShipName1 +"' et '"+ pchar.questTemp.jailCanMove.Deliver.ShipName2 +"', les cales pleines de "+ pchar.questTemp.jailCanMove.Deliver.add +". Tu peux essayer de les intercepter.";
					link.l1 = "Parfait !";
					link.l1.go = "Step_lay";
				break;
				case 2://наведём на торговый корабль
					AddMoneyToCharacter(pchar, -50000);
					GetBandersTradeShore();
					GetBandersTradeGoods();
					GetBandersTradeNation();
					pchar.questTemp.jailCanMove.Deliver.terms = 10+rand(2);
					pchar.questTemp.jailCanMove.Deliver.ShipName1 = GenerateRandomNameToShip(sti(pchar.questTemp.jailCanMove.Deliver.Nation));
					pchar.questTemp.jailCanMove.Deliver.ShipName2 = GenerateRandomNameToShip(sti(pchar.questTemp.jailCanMove.Deliver.Nation));

					dialog.text = "Bon, écoute bien. J'ai appris de source sמre que dans les " + FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)) + " qui viennent, au large de "+ pchar.questTemp.jailCanMove.Deliver.Island.Areal +" passeront deux navires marchands "+ pchar.questTemp.jailCanMove.Deliver.add1 +" : le '"+ pchar.questTemp.jailCanMove.Deliver.ShipName1 +"' et '"+ pchar.questTemp.jailCanMove.Deliver.ShipName2 +"', les cales pleines de "+ pchar.questTemp.jailCanMove.Deliver.add +". Tu peux essayer de les intercepter.";
					link.l1 = "Parfait !";
					link.l1.go = "Step_trader";
				break;
				case 3://наведём на курьерский корабль
					AddMoneyToCharacter(pchar, -50000);
					GetBandersTradeShore();
					GetBandersTradeNation();
					pchar.questTemp.jailCanMove.Deliver.ShipName = GenerateRandomNameToShip(sti(pchar.questTemp.jailCanMove.Deliver.Nation));
					pchar.questTemp.jailCanMove.Deliver.terms = 5+rand(5);
					dialog.text = "Bon, écoute. J'ai appris de source sמre que dans les " + FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)) + " qui viennent, au large de "+ pchar.questTemp.jailCanMove.Deliver.Island.Areal +" passera un navire courrier de la "+ pchar.questTemp.jailCanMove.Deliver.add2 +" nommé '"+ pchar.questTemp.jailCanMove.Deliver.ShipName +"'. Il transporte tout un tas de bijoux. Tu peux essayer de l'intercepter.";
					link.l1 = "Parfait !";
					link.l1.go = "Step_cureer";
				break;
			}
			break;

		case "Step_fight":
			dialog.text = "S'il n'était pas aussi bête, il boirait du rhum à la taverne au lieu de croupir dans une casemate. Tu lui poseras toutes tes questions plus tard, ha ha ha ! Et maintenant, les piastres sur le tonneau, sinon, " + GetSexPhrase("vivant,", "vivante,") + " tu ne sortiras pas d'ici.";
			link.l1 = "Eh bien, on verra bien...";
			link.l1.go = "quest_fight";
			link.l2 = "D'accord, prends l'argent... La force n'est pas de mon cכté.";
			link.l2.go = "Step_takemoney";
		break;

		case "Step_takemoney":
			dialog.text = "Voilà"+ GetSexPhrase(" qui est bien, mon brave", " qui est bien, ma fille") +". Et notre ami commun te les rendra... Héhé, quand il sortira de taule. Allez, file d'ici sans faire de bruit...";
			link.l1 = "Maudit sois-tu !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -50000);
			AddQuestRecord("GivePrisonFree", "17");
			AddQuestUserData("GivePrisonFree", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("GivePrisonFree");
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "questTemp.jailCanMove.Deliver");
		break;

		case "Step_lay":
			dialog.text = "Bien sמr, pas pour rien... Voilà, maintenant, allez, dépêche-toi. Et sors discrètement, n'attire pas l'attention.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddQuestRecord("GivePrisonFree", "13");
			AddQuestUserData("GivePrisonFree", "sGoods", pchar.questTemp.jailCanMove.Deliver.add);
			AddQuestUserData("GivePrisonFree", "sDay", FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)));
			AddQuestUserData("GivePrisonFree", "sShipName1", pchar.questTemp.jailCanMove.Deliver.ShipName1);
			AddQuestUserData("GivePrisonFree", "sShipName2", pchar.questTemp.jailCanMove.Deliver.ShipName2);
			AddQuestUserData("GivePrisonFree", "sShoreName", pchar.questTemp.jailCanMove.Deliver.Island.Areal);
			pchar.quest.jailCanMoveDeliver_ShipsAttack.win_condition.l1 = "location";
            pchar.quest.jailCanMoveDeliver_ShipsAttack.win_condition.l1.location = pchar.questTemp.jailCanMove.Deliver.Island;//отправляем в локацию
            pchar.quest.jailCanMoveDeliver_ShipsAttack.function = "Deliver_lay";//придём - а там пусто
			SetFunctionTimerCondition("Deliver_TraderShipsOver", 0, 0, sti(pchar.questTemp.jailCanMove.Deliver.terms), false);//таймер
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
		break;

		case "Step_trader":
			dialog.text = "Bien sמr, pas pour rien... Voilà, maintenant, allez, dépêche-toi. Et sors discrètement, n'attire pas l'attention.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddQuestRecord("GivePrisonFree", "13");
			AddQuestUserData("GivePrisonFree", "sGoods", pchar.questTemp.jailCanMove.Deliver.add);
			AddQuestUserData("GivePrisonFree", "sDay", FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)));
			AddQuestUserData("GivePrisonFree", "sShipName1", pchar.questTemp.jailCanMove.Deliver.ShipName1);
			AddQuestUserData("GivePrisonFree", "sShipName2", pchar.questTemp.jailCanMove.Deliver.ShipName2);
			AddQuestUserData("GivePrisonFree", "sShoreName", pchar.questTemp.jailCanMove.Deliver.Island.Areal);
			pchar.quest.jailCanMoveDeliver_ShipsAttack.win_condition.l1 = "location";
            pchar.quest.jailCanMoveDeliver_ShipsAttack.win_condition.l1.location = pchar.questTemp.jailCanMove.Deliver.Island;//отправляем в локацию
            pchar.quest.jailCanMoveDeliver_ShipsAttack.function = "Deliver_CreateTraderShips";//создание кораблей
			SetFunctionTimerCondition("Deliver_TraderShipsOver", 0, 0, sti(pchar.questTemp.jailCanMove.Deliver.terms), false);//таймер
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
		break;

		case "Step_cureer":
			dialog.text = "Bien sמr, pas pour rien... Voilà, maintenant, allez, dépêche-toi. Et sors discrètement, n'attire pas l'attention.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddQuestRecord("GivePrisonFree", "14");
			AddQuestUserData("GivePrisonFree", "sDay", FindRussianDaysString(sti(pchar.questTemp.jailCanMove.Deliver.terms)));
			AddQuestUserData("GivePrisonFree", "sText", pchar.questTemp.jailCanMove.Deliver.add2);
			AddQuestUserData("GivePrisonFree", "sShipName", pchar.questTemp.jailCanMove.Deliver.ShipName);
			AddQuestUserData("GivePrisonFree", "sShoreName", pchar.questTemp.jailCanMove.Deliver.Island.Areal);
			pchar.quest.jailCanMoveDeliver_ShipsCAttack.win_condition.l1 = "location";
            pchar.quest.jailCanMoveDeliver_ShipsCAttack.win_condition.l1.location = pchar.questTemp.jailCanMove.Deliver.Island;//отправляем в локацию
            pchar.quest.jailCanMoveDeliver_ShipsCAttack.function = "Deliver_CreateCureerShips";//создание кораблей
			SetFunctionTimerCondition("Deliver_CureerShipsOver", 0, 0, sti(pchar.questTemp.jailCanMove.Deliver.terms), false);//таймер
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
		break;

		case "Step_no":
			dialog.text = "Eh bien, comme tu voudras. Alors, file, nous n'avons plus rien à nous dire.";
			link.l1 = "D'accord, au revoir.";
			link.l1.go = "exit";
			AddQuestRecord("GivePrisonFree", "16");
			AddQuestUserData("GivePrisonFree", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("GivePrisonFree", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("GivePrisonFree");
			LAi_SetWarriorTypeNoGroup(npchar);
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "questTemp.jailCanMove.Deliver");
		break;

		case "Second time":
			dialog.text = "Eh bien, quoi encore ? On t'a dit de partir discrètement.";
			link.l1 = "D'accord, je m'en vais...";
			link.l1.go = "exit";
			NextDiag.TempNode = "Second time";
		break;

		case "Man_FackYou":
			dialog.text = "Mais que dites-vous là, " + GetSexPhrase("va-nu-pieds, tu cherches", "idiote, tu cherches") + " toi-même le coup de couteau ?!";
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "fight";
		break;
	}
}

void GetBandersTradeShore()//выберем остров для торгашей и курьера
{
	pchar.questTemp.jailCanMove.Deliver.Island = GetRandomIslandId();
	pchar.questTemp.jailCanMove.Deliver.Island.Shore = GetIslandRandomShoreId(pchar.questTemp.jailCanMove.Deliver.Island);
	while (pchar.questTemp.jailCanMove.Deliver.Island.Shore == "")
	{
		pchar.questTemp.jailCanMove.Deliver.Island = GetRandomIslandId();
		pchar.questTemp.jailCanMove.Deliver.Island.Shore = GetIslandRandomShoreId(pchar.questTemp.jailCanMove.Deliver.Island);
		if (!isLocationFreeForQuests(pchar.questTemp.jailCanMove.Deliver.Island)) pchar.questTemp.jailCanMove.Deliver.Island.Shore = "";
	}
	pchar.questTemp.jailCanMove.Deliver.Island.Town = FindTownOnIsland(pchar.questTemp.jailCanMove.Deliver.Island);
	if (pchar.questTemp.jailCanMove.Deliver.Island.Town == "" || pchar.questTemp.jailCanMove.Deliver.Island.Town == "Caiman" || pchar.questTemp.jailCanMove.Deliver.Island.Town == "Terks" || pchar.questTemp.jailCanMove.Deliver.Island.Town == "Dominica" || pchar.questTemp.jailCanMove.Deliver.Island.Town == "StLucia")
	{
	pchar.questTemp.jailCanMove.Deliver.Island.Areal = GetConvertStr(pchar.questTemp.jailCanMove.Deliver.Island, "LocLables.txt") + "");
	}
	else
	{
	pchar.questTemp.jailCanMove.Deliver.Island.Areal = XI_ConvertString("Colony" + pchar.questTemp.jailCanMove.Deliver.Island.Town + "Gen");
	}
}

void GetBandersTradeGoods()//выберем товар для торгашей
{
switch (rand(6))
	{
		case 0:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_EBONY;
			pchar.questTemp.jailCanMove.Deliver.add = "bois d'ébène";
			break;
		case 1:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_MAHOGANY;
			pchar.questTemp.jailCanMove.Deliver.add = "acajou";
			break;
		case 2:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_SANDAL;
			pchar.questTemp.jailCanMove.Deliver.add = "bois de santal";
			break;
		case 3:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_COFFEE;
			pchar.questTemp.jailCanMove.Deliver.add = "café";
			break;
		case 4:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_SILK;
			pchar.questTemp.jailCanMove.Deliver.add = "soieries";
			break;
		case 5:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_FOOD;
			pchar.questTemp.jailCanMove.Deliver.add = "vivres";
			break;
		case 6:
			pchar.questTemp.jailCanMove.Deliver.Goods = GOOD_WEAPON;
			pchar.questTemp.jailCanMove.Deliver.add = "armes";
			break;
	}
}

void GetBandersTradeNation()//выберем нацию торгаша и курьера
{
switch (rand(3))
	{
		case 0:
			pchar.questTemp.jailCanMove.Deliver.Nation = SPAIN;
			pchar.questTemp.jailCanMove.Deliver.add1 = "espagnols";
			pchar.questTemp.jailCanMove.Deliver.add2 = "Compagnie espagnole des Indes occidentales";
			break;
		case 1:
			pchar.questTemp.jailCanMove.Deliver.Nation = FRANCE;
			pchar.questTemp.jailCanMove.Deliver.add1 = "français";
			pchar.questTemp.jailCanMove.Deliver.add2 = "Compagnie française des Indes occidentales";
			break;
		case 2:
			pchar.questTemp.jailCanMove.Deliver.Nation = HOLLAND;
			pchar.questTemp.jailCanMove.Deliver.add1 = "hollandais";
			pchar.questTemp.jailCanMove.Deliver.add2 = "Compagnie néerlandaise des Indes occidentales";
			break;
		case 3:
			pchar.questTemp.jailCanMove.Deliver.Nation = ENGLAND;
			pchar.questTemp.jailCanMove.Deliver.add1 = "anglais";
			pchar.questTemp.jailCanMove.Deliver.add2 = "Compagnie anglaise des Indes occidentales";
			break;
	}
}



