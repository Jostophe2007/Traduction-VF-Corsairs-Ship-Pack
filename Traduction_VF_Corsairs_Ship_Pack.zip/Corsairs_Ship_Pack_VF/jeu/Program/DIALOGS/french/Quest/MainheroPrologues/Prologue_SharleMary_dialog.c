void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	ref _location;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.id == "SharleMary")
			{
				chrDisableReloadToLocation = false;
				LAi_SetPlayerType(PChar);
				LAi_SetImmortal(NPChar, true);
				dialog.text = GetSexPhrase("Charles ! Tu es couvert de sang !", "Mary ! Tu es couverte de sang !");
				link.l1 = "Ce n'est rien. "+GetSexPhrase("Je me suis écorché", "Je me suis écorchée")+" sur les rochers du rivage. Et toi, ça va ? Ces démons empoisonnent leurs armes.";
				link.l1.go = "2";
				
				pchar.SharleMaryId = npchar.id;
			}

			if (npchar.id == "SMPirate1")
			{
				chrDisableReloadToLocation = false;
				LAi_SetPlayerType(PChar);
				LAi_SetImmortal(NPChar, true);
				dialog.text = "Regardez, les gars, quel joli couple s'est égaré sur notre plage ! La mer a malmené notre rafiot et emporté par-dessus bord un tiers de l'équipage, et voilà un tel cadeau ! א quelque chose malheur est bon, comme disait notre aumכnier, que Dieu ait son âme pécheresse !";
				link.l1 = "Nous avons fait naufrage près de ces cכtes, et nous vous demandons, en bons chrétiens, de nous aider à rejoindre une colonie amie, oם, sur mon honneur, je vous remercierai pleinement.";
				link.l1.go = "SMPirate1_2";
				if (CheckAttribute(pchar, "SharleMary.LowerIsDead"))
				{
					dialog.text = "Regardez, les gars, qui s'est égaré sur notre plage ! La mer a malmené notre rafiot et emporté par-dessus bord un tiers de l'équipage, et voilà un tel cadeau ! א quelque chose malheur est bon, comme disait notre aumכnier, que Dieu ait son âme pécheresse !";
					link.l1 = "J'ai fait naufrage près de ces cכtes, et je vous demande, en bons chrétiens, de m'aider à rejoindre une colonie amie, oם, sur mon honneur, je vous remercierai pleinement.";
					link.l1.go = "SMPirate1_3";
				}
			}
			if (npchar.id == "SMCrew1")
			{
				chrDisableReloadToLocation = false;
				LAi_SetPlayerType(PChar);
				LocatorReloadEnterDisable("Shore_ship2", "boat", false);
				bDisableCharacterMenu = false;
				bDisableLandEncounters = false;
				dialog.text = "Bon sang ! Si on avait su que tout tournerait comme ça, on ne se serait jamais évadés du bagne au début de cette tempête, et voilà que vous surgissez de nulle part et que vous tuez le dernier qui savait manœuvrer le navire.";
				link.l1 = "Moi aussi, je m'y connais en navigation. J'ai une proposition qui nous profitera à tous. Vous me prenez comme patron, et on file d'ici.";
				link.l1.go = "SMCrew1_2";
			}
			NextDiag.TempNode = "First time";
		break;

		case "SMCrew1_2":
			dialog.text = "Nous ne sommes pas en position de refuser. Montez à bord, je vous en prie.";
			link.l1 = "Parfait !";
			link.l1.go = "SMCrew1_3";
		break;
		case "SMCrew1_3":
			DialogExit();
			sld = characterFromID("SharleMary");
			DeleteAttribute(sld, "cirassId");
			LAi_SetHP(sld, 150.0, 150.0);
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "boat", "none", "", "", "", 5);
			if (pchar.sex == "man")
			{
				sld.Dialog.Filename = "Quest\MainheroPrologues\Mary_dialog.c";
				sld.dialog.currentnode = "hired";
			}
			if (pchar.sex == "woman")
			{
				sld.Dialog.Filename = "Enc_Officer_dialog.c";
				sld.dialog.currentnode = "hired";
			}
		break;
		case "SMPirate1_2":
			DialogExit();
			StartInstantDialog("SharleMary", "SMPirate1_3", "Quest\MainheroPrologues\Prologue_SharleMary_dialog.c");
		break;
		case "SMPirate1_3":
			dialog.text = "(au pirate) Oui, nos amis vous dédommageront pour le dérangement, et on vous comptera une bonne action, pour avoir aidé des gens dans le besoin.";
			link.l1 = "";
			link.l1.go = "SMPirate1_4";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorTurnToCharacter(npchar, CharacterFromID("SMPirate1"));
		break;
		case "SMPirate1_4":
			DialogExit();
			StartInstantDialog("SMPirate1", "SMPirate1_5", "Quest\MainheroPrologues\Prologue_SharleMary_dialog.c");
		break;
		case "SMPirate1_5":
			dialog.text = "וcoutez-les chanter, on se croirait à la messe. Les gars, ligotez-les !";
			link.l1 = "On verra bien !";
			if (CheckAttribute(pchar, "SharleMary.LowerIsDead"))
			{
				dialog.text = "וcoutez comme ça chante, on se croirait à la messe. "+GetSexPhrase("Les gars, ligotez-le !", "Les gars, ligotez la fille, puis amenez-la dans ma cabine.");
				link.l1 = "...";
				link.l1.go = "SMPirate1_5";
			}
			link.l1.go = "Exit_fight_pirates";
		break;

		case "2":
			dialog.text = ""+GetSexPhrase("Je vais bien, et je suis prête à me battre encore, oui !", "Non, je vais bien.");
			link.l1 = "Pourquoi es-tu "+GetSexPhrase("partie seule ?", "parti seul ?");
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Je "+GetSexPhrase(" croyais", " croyais")+" retrouver nos amis miskitos, mais ce sont des cannibales qui vivent ici. Il faut partir d'ici au plus vite. Allons sur la plage, peut-être que quelqu'un d'autre s'est échoué sur le rivage. Et il faut faire quelque chose pour ta blessure à la tête. Elle a l'air vilaine.";
			link.l1 = "Allons-y, "+GetSexPhrase("Mary", "Charles")+".";
			link.l1.go = "Exit_follow";
		break;



		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit_fight_pirates":
			NextDiag.CurrentNode = "5";
			AddDialogExitQuest("MainHeroFightModeOn");

			SharleMary_FightPirates();

			//LAi_group_Attack(NPChar, Pchar);
			//LAi_SetWarriorType(NPChar);
			//LAi_SetImmortal(NPChar, false);
			DialogExit();
		break;

		case "Exit_follow":
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetActorType(npchar);
			LAi_ActorFollow(npchar, pchar, "", -1);
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.rank = 3;
			SetSPECIAL(sld, 6, 6, 8, 5, 8, 8, 8);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			sld.quest.meeting = true;
			Npchar.CanTakeMushket = true;
			sld.HoldEquip = true;
			sld.HalfImmortal = true;  // Контузия
			LAi_SetImmortal(NPChar, false);
			if (bHalfImmortalPGG)
			{
				sld.immortalofficer = true;
				pchar.Option_ImmortalOfficers = "1";
			}
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			if (pchar.sex == "man")
			{
				sld.Dialog.Filename = "Quest\MainheroPrologues\Mary_dialog.c";
				sld.dialog.currentnode = "hired";
			}
			if (pchar.sex == "woman")
			{
				sld.Dialog.Filename = "Enc_Officer_dialog.c";
				sld.dialog.currentnode = "hired";
			}
			DialogExit();
		break;
	}
}
