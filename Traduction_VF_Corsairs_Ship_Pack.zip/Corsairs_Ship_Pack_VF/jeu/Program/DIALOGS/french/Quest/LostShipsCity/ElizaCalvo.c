#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					if (npchar.location == "SantaFlorentinaShipInside4") dialog.text = "Cette tempête était très violente, "+ GetSexPhrase("señor", "señorita") +", vous avez beaucoup de chance d'avoir pu arriver jusqu'à nous... Je m'appelle " + GetFullName(npchar) + ", je suis la propriétaire de cette maison.";
					else dialog.text = "Cette tempête était très violente, "+ GetSexPhrase("señor", "señorita") +", vous avez beaucoup de chance d'avoir pu arriver jusqu'à nous... Je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = GetFullName(pchar) + ", à votre service, señora. Dites-moi, combien de temps a duré cette tempête ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bonjour ! Je comprends que c'est vous qui avez été sauvé le dernier.";
					link.l1 = GetFullName(pchar) + ", à votre service, señora. Oui, c'est moi.";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				if (npchar.location == "SantaFlorentinaShipInside4") dialog.text = "Que voulez-vous dans ma maison, "+ GetSexPhrase("señor", "señorita") +" ?";
				else dialog.text = "Je vous écoute, "+ GetSexPhrase("señor", "señorita") +".";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous m'aiderez ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Pourriez-vous me raconter quelque chose d'intéressant, señora ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods" && !CheckAttribute(npchar, "quest.bombs"))
				{
					link.l8 = "Vous savez, je cherche certaines marchandises. Pourriez-vous m'aider ?";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekGoods" && CheckAttribute(npchar, "quest.bombs") && sti(npchar.quest.bombs))
				{
					link.l8 = "Je parle de bombes.";
					link.l8.go = "TakeBombs";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de venir avec moi sur le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FS_1":
			dialog.text = "Environ une semaine, je ne saurais le dire avec certitude. Vous savez, quand tout ça se passe autour de vous, on perd la notion du temps.";
			link.l1 = "Oui, je comprends.";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "Au fait, tous ceux qui arrivent dans la Cité doivent se présenter à l'amiral Chad Capper et obtenir la citoyenneté. Si vous ne l'avez pas encore fait, je vous conseille de vous dépêcher.";
			link.l1 = "Oם se trouve ce Chad Capper ?";
			link.l1.go = "FS_3";
		break;
		case "FS_3":
			dialog.text = "א la résidence de la Cité, sur le vaisseau de guerre « San Augustine ».";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Et moi, je m'appelle " + GetFullName(npchar) + ". Je suis la maîtresse de cette cabine, ou de cette maison, comme vous voudrez appeler ce refuge.";
			link.l1 = "Sans doute que « maison » est plus juste.";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Je le pense aussi. Eh bien, bienvenue chez moi.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre ! Il a enfreint la Loi !", "Police ! Au vol !!! C'est "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Hé,"+ GetSexPhrase("mon gars, range ça", "ma belle, range ça") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Je serai heureuse de vous aider si je le peux, bien sמr. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, mais je préfère m'en occuper moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pensais à l'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrées.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Les tempêtes sont-elles fréquentes ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l3 = "Dites-moi, depuis combien de temps vivez-vous ici ?";
				link.l3.go = "ansewer_3";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "Cette île s'appelle la Cité des navires abandonnés. Et ce nom, je vous le dis, est parfaitement juste sur le fond.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Assez fréquentes. C'est très effrayant, bien sמr, mais nous y sommes habitués...";
			link.l1 = "Eh oui, on n'a nulle part oם aller !";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "Depuis assez longtemps, environ trois ans. Pourquoi ?";
			link.l1 = "Oh, pour rien. Le défunt Hill Brunner était-il déjà là quand vous êtes arrivée ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Oui, bien sמr. C'était un ancien de la Cité. C'est dommage qu'il soit mort...";
			link.l1 = "Oui, c'est dommage...";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Si je le peux, je vous aiderai bien sמr.",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je cherche des boulets, des bombes, de la mitraille, des boulets ramés, des vivres, des médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Des bombes... Je crois que j'ai quelque chose de ce genre... Oui, c'est ça ! Combien vous en faut-il ?";
			link.l1 = "100 suffiront largement.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "J'en ai autant. Seulement, vous devez faire quelque chose pour moi, vous aussi.";
			link.l1 = "Toujours à votre service.";
			link.l1.go = "SeekGoods_3";
		break;
		case "SeekGoods_3":
			dialog.text = "Apportez-moi 10 grappes de raisin, trois bouteilles de vin et un luth. Je suis de bonne humeur en ce moment, je vais chanter et apprendre à jouer.";
			link.l1 = "Y a-t-il quelqu'un pour vous apprendre ?";
			link.l1.go = "SeekGoods_4";
		break;
		case "SeekGoods_4":
			dialog.text = ""+ GetSexPhrase("Vous faites allusion à vous-même ? Inutile, la place est prise...", "Oui, ne vous inquiétez pas.") +"";
			link.l1 = ""+ GetSexPhrase("Pas du tout, je demandais juste. ", "Oui... ") +"Je pense que si vous mangez autant de raisin et que vous buvez autant de vin, vous n'apprendrez sans doute pas à jouer.";
			link.l1.go = "SeekGoods_5";
		break;
		case "SeekGoods_5":
			dialog.text = "Mais ça ne vous regarde pas. Apportez ce que je vous ai dit, c'est tout.";
			link.l1 = "Bien, bien, comme vous voudrez.";
			link.l1.go = "exit";
			npchar.quest.bombs = true;
			AddQuestRecord("ISS_MainLine", "55");
		break;
		//проверка на соль
		case "TakeBombs":
			dialog.text = "Vous avez apporté ce que j'ai commandé ?";
            if (CheckCharacterItem(pchar, "Mineral2") && CheckCharacterItem(pchar, "potionwine") && sti(pchar.items.potionwine) >= 3 && CheckCharacterItem(pchar, "potion5") && sti(pchar.items.potion5) >= 10)
            {
				link.l1 = "Oui, j'ai tout. Je vous en prie, prenez.";
				link.l1.go = "TakeBombs_yes";
			}
			else
			{
				link.l1 = "Pas encore, je n'arrive pas à trouver. Vous ne voulez peut-être plus apprendre à jouer ?";
				link.l1.go = "TakeBombs_no";
			}
		break;
		case "TakeBombs_no":
			dialog.text = "Non...";
			link.l1 = "Compris.";
			link.l1.go = "exit";
		break;
		case "TakeBombs_yes":
			dialog.text = "D'accord. Vous pouvez prendre vos bombes.";
			link.l1 = "Merci. Y a-t-il un moyen de les faire porter jusqu'au San Gabriel ? Je vous en supplie.";
			link.l1.go = "TakeBombs_1";
			TakeNItems(pchar, "Mineral2", -1);
			TakeNItems(pchar, "potionwine", -3);
			TakeNItems(pchar, "potion5", -10);
		break;
		case "TakeBombs_1":
			dialog.text = "Jusqu'au « San Gabriel »... Bon, d'accord, j'arrangerai ça pour vos efforts. Je demanderai à mon élu, il s'occupera de tout.";
			link.l1 = "Parfait ! Merci beaucoup à vous et à votre élu. Il a beaucoup de chance...";
			link.l1.go = "TakeBombs_2";
		break;
		case "TakeBombs_2":
			dialog.text = "Merci..."+ GetSexPhrase("  Vous êtes un flatteur, je vois !", "") +"";
			link.l1 = ""+ GetSexPhrase("Parfois...", "") +" Bon, bonne journée.";
			link.l1.go = "exit";
			AddCharacterGoods(pchar, GOOD_BOMBS, 100);
			AddQuestRecord("ISS_MainLine", "56");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			npchar.quest.Bombs = false;
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Quelle franchise ! Et vous enfreignez la Loi comme ça ?";
			link.l1 ="Je n'ai pas le choix, je sauve ma vie. Je peux sauver la vכtre aussi.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Hum, expliquez-vous.";
			link.l1 = "Le fait est que la tempête qui approche va très probablement détruire la Cité. C'est le Mécanicien qui l'a calculé.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Compris... Bon, j'accepte d'aller sur votre navire. Que dois-je faire ?";
			link.l1 = "Allez sur le San Gabriel. Henrik Wedeker vous emmènera sur mon navire. Et ne tardez pas !";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, je serai bientכt sur le « San Gabriel ».";
			link.l1 = "Je vous en prie, dépêchez-vous...";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
