void ProcessDialogEvent()
{
	ref locLoad = &locations[reload_location_index];
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;
	string sTemp;
	bool hungry = true;
	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":

			//dialog.text = "Error";
			link.l1 = "...";
			link.l1.go = "Exit";
			npchar.quest.meeting = "1";

			if (npchar.id == "CrazyScientist")
			{
				dialog.text = "Allez, attends !";
				link.l1.go = "CS";
			}
			if (npchar.id == "FinalBot")
			{
				dialog.text = "(Vous remarquez le bot trop tard, seulement après avoir entendu le bruit d'un coup de feu.)";
				LAi_LocationFightDisable(locLoad, false);
				DeleteAttribute(locLoad, "box1");
				DeleteAttribute(locLoad, "box2");
				DeleteAttribute(locLoad, "box3");
				DeleteAttribute(locLoad, "box4");
				DeleteAttribute(locLoad, "box5");
				DeleteAttribute(locLoad, "box6");
				DeleteAttribute(locLoad, "box7");
				LAi_SetActorTypeNoGroup(npchar);
				LAi_ActorAnimation(npchar, "Shot", "pchar_back_to_player", 1.0);
				link.l1 = "Bon sang !";
				link.l1.go = "FB";
			}
			if (npchar.id == "wl_Pirate_Cap")
			{

				if (!CheckAttribute(npchar, "quest.meting"))
				{
				dialog.text = "Qu'est-ce que c'est que cette seiche sur mon pont ?! Présente-toi !";
				link.l1 = "Oם suis-je ? Comment suis-je arrivée ici ?";
				link.l1.go = "PC";
				npchar.quest.meting = 1;
				break;
				}
				if (npchar.quest.meting == 1)
				{
					dialog.text = "Tu as des choses intéressantes, j'ai décidé de toutes les garder pour moi pour l'instant. Tu ne vas sans doute pas t'y opposer. Ton pistolet, en revanche, est un engin très meurtrier, et il a un aspect inhabituel. Oם l'as-tu eu ?";
					link.l1 = "דa ne te regarde pas. Combien de temps vas-tu me garder ici ?";
					link.l1.go = "PC_2";
					npchar.quest.meting = 2;
				}
			}

			if (npchar.id == "AntonioDeSouza")
			{
				if (!CheckAttribute(npchar, "quest.meting"))
				{
					dialog.text = "דa alors, quel intéressant « spécimen » " + GetFullName(characterFromId("wl_Pirate_Cap"))+" m'a amené. Dis-moi, démon, de quel cercle de l'enfer viens-tu ?";
					link.l1 = "Je ne suis pas un démon.";
					link.l1.go = "ADS";
					npchar.quest.meting = 1;
					break;
				}
				if (npchar.quest.meting == 1)
				{
					dialog.text = "Alors, ça t'est revenu ?";
					link.l1 = "Vous n'auriez pas dמ commencer ça, mon père. Après tout, je peux me venger quand je sortirai.";
					link.l1.go = "ADS_2";
					npchar.quest.meting = 2;
					break;
				}
				if (npchar.quest.meting == 2)
				{
					dialog.text = "Ne compte pas sur ma pitié, alors tu ferais mieux de commencer à parler. Ce pistolet. C'est une invention anglaise ? Réponds-moi !";
					link.l1 = "D'accord. Je vais tout vous dire.";
					link.l1.go = "ADS_1_truth";
					npchar.quest.meting = 3;
					break;
				}
				if (npchar.quest.meting == 3)
				{
					dialog.text = "Alors ?";
					link.l1 = "Je n'ai rien de plus à vous dire.";
					pchar.Whisper.DeSouzaHits = 3;
					link.l1.go = "ADS_1_2";
					npchar.quest.meting = 4;
					break;
				}
				if (npchar.quest.meting == 4)
				{
					dialog.text = "Je n'ai vraiment pas envie d'interrompre notre charmante conversation, mais j'ai un rendez-vous avec le gouverneur aujourd'hui. Ne bouge pas d'ici, et ne t'ennuie pas trop de moi, héhé. Nous continuerons demain.";
					link.l1 = "...";
					link.l1.go = "ADS_4_exit";
					if(rand(100) < 90)
					{
						pchar.Whisper.IncqGuard_bad = true;
					}
					npchar.quest.meting = 5;
					break;
				}
			}
			if (npchar.id == "NineFingers")
			{
				if (!CheckAttribute(npchar, "quest.meting"))
				{
					dialog.text = "דa alors, une vraie beauté s'est égarée dans notre village ! Par quel destin ?";
					chrDisableReloadToLocation = false;
					link.l1 = "Oui, je fuis le bמcher de l'Inquisition.";
					link.l1.go = "NF";
					npchar.quest.meting = 1;
					break;
				}
				if (npchar.quest.meting == 1)
				{
					dialog.text = "Tu vois ça ? Le village a été attaqué par un détachement punitif venu de Santiago. Ils ne seraient pas venus pour ton âme ?";
					link.l1 = "Bon sang ! Tu as raison, les Espagnols sont sans doute sur ma piste. Que faisons-nous maintenant ?";
					AddMoneyToCharacter(npchar, 777);
					npchar.SaveItemsForDead = true;
					link.l1.go = "NF_2_1";
					npchar.quest.meting = 2;
					break;
				}
			}
			if (npchar.id == "Wh_Jack")
			{
				dialog.text = "Oם est notre capitaine ? Qu'est-ce que tu fiches avec son chapeau et sa lame ?";
				chrDisableReloadToLocation = true;
				link.l1 = "Le village a été attaqué par les Espagnols, votre capitaine est mort au combat.";
				link.l1.go = "Jack";
				break;
			}
			if (npchar.id == "Wh_Jim")
			{
				dialog.text = "Diable ! Tu as tué Jack ! Maintenant, c'est toi, notre capitaine, de plein droit.";
				link.l1 = "C'est vrai ? Comme ça ?";
				link.l1.go = "Jim";
				break;
			}
			if (npchar.id == "W_Lejitos")
			{
				if (!CheckAttribute(npchar, "quest.meting"))
				{
					Lai_SetPlayerType(pchar);
					npchar.DontChangeBlade = true; // нельзя снять или залутать оружие

					dialog.text = "Imbéciles. Vous devriez savoir qu'une bête acculée est dangereuse. Et je ne suis pas une bête quelconque, je suis un Jaguar. J'espère que vous avez eu le temps de prier votre dieu mort, car je vais maintenant vous envoyer le rejoindre !";
					link.l1.go = "exit_cave_entrance_fight";
					npchar.quest.meting = 1;
					break;
				}
				if (npchar.quest.meting == 1)
				{
					Lai_SetPlayerType(pchar);
					dialog.text = "J'aurais pu m'en charger moi-même, mais merci quand même pour cette intervention opportune. א ce que je vois, vous avez vos propres comptes à régler avec les Espagnols ?";
					link.l1 = "Oui, j'ai réussi à me faire quelques ennemis. Et que disiez-vous avant le combat, à propos du dieu mort ?";
					link.l1.go = "Lejitos";
					npchar.quest.meting = 2;
					break;
				}
			}
			if (npchar.id == "W_Chard")
			{
				if (!CheckAttribute(npchar, "quest.meting"))
				{
					Lai_SetPlayerType(pchar);
					dialog.text = "Et toi, qui es-tu ? Je ne crois pas avoir commandé de fille de bordel dans ma chambre.";
					link.l1 = "Alors, tu m'as fait venir ici juste pour te moquer de moi ? Encore une blague comme ça, et la « fille de bordel » t'ouvrira le ventre.";
					link.l1.go = "meet_chard";
					npchar.quest.meting = 1;
					break;
				}
				if (npchar.quest.meting == 1)
				{
					chrDisableReloadToLocation = false;
					if (CheckAttribute(pchar, "WhisperWonSword"))
					{
						dialog.text = "Félicitations pour ta victoire. Et tu joues bien, beaucoup mieux que les ivrognes du coin. Prends ton épée. Ce n'est pas une mauvaise lame, je n'ai même jamais eu à l'affמter. Et j'ai pourtant tué pas mal de pauvres diables avec, une autre se serait émoussée depuis longtemps...";
						link.l1 = "(Prendre l'épée)";
						link.l1.go = "chard_get_sword";
					}
					else
					{
						dialog.text = "Tu n'as pas de chance. Mais ne t'en fais pas, ça peut arriver à tout le monde ; je vois que cette lame t'est très chère, je regrette même d'avoir gagné. Je te propose une chose : si tu m'aides pour une affaire, je te la donnerai. De toute façon, je m'en suis déjà trouvé une nouvelle à la boutique du coin.";
						link.l1 = "Quel genre d'aide te faut-il ?";
						link.l1.go = "chard_discuss_quest";
					}
					npchar.quest.meting = 2;
					break;
				}
			}
			NextDiag.TempNode = "First time";
		break;

		case "Chinaman_plead":
			npchar.ChinamanAskedSword = true;
			WhisperSelectRandomUsurer();
			LAi_SetOfficerType(NPChar);
			dialog.Text = "Capitaine, je voudrais vous demander un service. Pouvez-vous m'écouter ?";
			Link.l1 = "Bien sמr que je vais t'écouter ! Tu es un bon officier, tu ne m'as encore jamais laissée tomber.";
			Link.l1.go = "Chinaman_plead_1";
		break;
		case "Chinaman_plead_1":
			dialog.Text = "Merci pour ces paroles flatteuses, capitaine. Alors, écoutez : avant d'être réduit en esclavage, j'avais une épée. Je la tenais de mon père, qui la tenait du sien, et ainsi de suite depuis plus de mille ans. Vous comprenez à quel point cette épée est importante pour moi ?";
			Link.l1 = "Je vois, c'est un héritage de famille.";
			Link.l1.go = "Chinaman_plead_2";
		break;
		case "Chinaman_plead_2":
			dialog.Text = "Pendant tout ce temps, je pensais que l'épée était perdue à jamais. Mais quand nous sommes entrés au port, j'ai entendu deux personnes parler. Elles parlaient d'un usurier, collectionneur d'objets rares venus des quatre coins du monde. La conversation portait justement sur l'« épée aux cinq anneaux ». La dernière fois, il est vrai, il y avait neuf anneaux sur mon épée, mais je suis tout de même sמr qu'il s'agissait de la mienne. Ces barbares ont dמ l'abîmer. Je vous en prie, capitaine, aidez-moi à la récupérer !";
			Link.l1 = "Un usurier, dis-tu ? Oם puis-je le trouver ?";
			Link.l1.go = "Chinaman_plead_3";
		break;
		case "Chinaman_plead_3":
			sld = characterFromId(pchar.Whisper.UsurerId);
			//Lai_SetStayType(npchar);
			dialog.Text = XI_ConvertString("Colony" + sld.city) +". C'est la ville qu'ont nommée ces gens.";
			NextDiag.TempNode = "Hired";
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			SetQuestHeader("WhisperChinamanRelic");
			AddQuestRecord("WhisperChinamanRelic", "1");
			AddQuestUserData("WhisperChinamanRelic", "sCity", XI_ConvertString("Colony" + sld.city+ "Gen"));
			Link.l1 = "Bon, si nous passons par cette ville, je passerai voir l'usurier.";
			Link.l1.go = "exit";
		break;
		case "Chinaman_plead_4":
			dialog.Text = "Merci, capitaine. Je sais que je vous dois déjà beaucoup. Mais si vous m'aidez, je jure de vous être fidèle jusqu'au bout.";
			Link.l1 = "Bon, si nous passons dans ces parages, je passerai voir l'usurier.";
			Link.l1.go = "exit";
		break;

		case "chard_waiting_quest_result":
			dialog.Text = "Alors, oם en êtes-vous avec notre affaire ?";
			if (!CheckAttribute(npchar,"DiscussedEsteban"))
			{
				Link.l2 = "Et quel est ton lien avec Esteban ? Tu n'es même pas espagnol.";
				Link.l2.go = "chard_discuss_esteban"
			}
			if (!CheckAttribute(pchar,"Whisper.FoundPortmanJournal") && !CheckAttribute(pchar,"Whisper.ActiveChardQuest"))
			{
				Link.l1 = "Désolée, mais je n'ai pas pu l'interroger. Ni récupérer les documents. Le navire de Portman a sombré...";
				Link.l1.go = "chard_failed"
				break;
			}
			if (CheckAttribute(pchar,"Whisper.FoundPortmanJournal"))
			{
				Link.l1 = "J'ai trouvé ce journal chez Portman. Je pense que la réponse à ta question s'y trouve.";
				Link.l1.go = "chard_check_journal"
				break;
			}
			if (CheckAttribute(pchar,"Whisper.BetrayChard"))
			{
				Link.l1 = "Ton idée ne m'a pas vraiment plu. Ce n'est rien de personnel, mais j'en ai parlé à Portman. Il a offert une récompense pour la restitution de son livre.";
				Link.l1.go = "chard_betrayed"
				break;
			}
			Link.l1 = "Rien pour l'instant.";
			Link.l1.go = "exit";

		break;
		case "chard_check_journal":
			Log_Info("Vous avez remis le journal");
			PlaySound("interface\important_item.wav");
			dialog.Text = "Voyons... Ici aussi, tout est chiffré. Il va me falloir un peu de temps. Quelques heures. Tu peux aller te promener en attendant.";
			Link.l1 = "J'attendrai ici.";
			Link.l1.go = "chard_check_journal_1";
		break;
		case "chard_check_journal_1":
			dialog.Text = "Tu ne me fais pas confiance ? Bon, tu peux t'allonger sur le lit en attendant.";
			Link.l1 = "...";
			Link.l1.go = "chard_check_journal_2";
		break;
		case "chard_check_journal_2":
			chrDisableReloadToLocation = true;
			LAi_Fade("", "");
			WaitDate("",0,0,0,12,3);
			RecalculateJumpTable();
			RefreshWeather();
			RefreshLandTime();
			NextDiag.TempNode = "chard_check_journal_after";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "chard_check_journal_after":
			AddQuestRecord("WhisperChardQuest", "8");
			chrDisableReloadToLocation = false;
			dialog.Text = "Si je comprends bien, le trésor se trouve à la Dominique. Je te dirai l'endroit plus précis quand nous y serons.";
			Link.l1 = "Alors, ne tardons pas. Prépare ton brick.";
			npchar.Ship.Type = GenerateShipExt(SHIP_NEUFCHATEL, true, npchar);
			npchar.Ship.name = "Favori de la Fortune";
			SetBaseShipData(npchar);
			npchar.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS16;
			SetCharacterGoods(npchar,GOOD_FOOD,500);
			SetCharacterGoods(npchar,GOOD_BALLS,500);
			SetCharacterGoods(npchar,GOOD_GRAPES,500);
			SetCharacterGoods(npchar,GOOD_KNIPPELS,500);
			SetCharacterGoods(npchar,GOOD_BOMBS,500);
			SetCharacterGoods(npchar,GOOD_POWDER,1000);
			SetCharacterGoods(npchar,GOOD_PLANKS,150);
			SetCharacterGoods(npchar,GOOD_SAILCLOTH,150);
			SetCharacterGoods(npchar,GOOD_RUM,200);
			SetCharacterGoods(npchar,GOOD_WEAPON,250);
			SetCharacterGoods(npchar,GOOD_MEDICAMENT,300);
			SetCharacterRemovable(npchar, false);
			SetCompanionIndex(pchar, -1, sti(NPChar.index));
			Link.l1.go = "exit_chard_setsail";
		break;
		case "exit_chard_setsail":
			NextDiag.TempNode = "chard_on_dominica";
			NextDiag.CurrentNode = NextDiag.TempNode;
			pchar.WhisperChardCompanion = true;
			DialogExit();
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", pchar.Whisper.EsFriendTown+"_tavern", "", "", "", 7);
			LocatorReloadEnterDisable(pchar.Whisper.EsFriendTown+"_tavern", "reload2_back", true);
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.Whisper.EsFriendTown+"_tavern_upstairs")], false);
			DeleteAttribute(pchar,"Whisper.EsFriendTown");

			pchar.quest.WhisperChardShore26.win_condition.l1          = "location";
			pchar.quest.WhisperChardShore26.win_condition.l1.location = "shore26";
			pchar.quest.WhisperChardShore26.function             = "WhisperChardShore";
			pchar.quest.WhisperChardShore27.win_condition.l1          = "location";
			pchar.quest.WhisperChardShore27.win_condition.l1.location = "shore27";
			pchar.quest.WhisperChardShore27.function             = "WhisperChardShore";
		break;
		case "chard_on_dominica":
			dialog.Text = "Nous y voilà. Le trésor est tout près, il reste à trouver la grotte.";
			Link.l1 = "Eh bien, allons-y.";
			Link.l1.go = "chard_follow";
		break;
		case "chard_follow":
			NextDiag.TempNode = "chard_in_cave";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			chrDisableReloadToLocation = false;
			LAi_ActorFollowEverywhere(npchar, "", -1);

			pchar.quest.WhisperChardCave.win_condition.l1          = "location";
			pchar.quest.WhisperChardCave.win_condition.l1.location = "Dominica_grot";
			pchar.quest.WhisperChardCave.function             = "WhisperChardCave";
		break;
		case "chard_in_cave":
			if (!CheckAttribute(pchar, "cursed.waitingSkull"))
			{
				pchar.cursed.waitingSkull = true;
				pchar.cursed.lockspawn = true;
			}
			if (CheckAttribute(pchar, "WhisperWonSword"))
			{
				dialog.Text = "Ha ha ha ! Et cette lame est pour moi ! Regarde comme elle est large. Et elle est agréablement lourde dans mes mains. Regarde dans le coffre, tu trouveras peut-être quelque chose d'intéressant pour toi.";
			}
			else
			{
				Log_Info("Vous avez récupéré votre épée");
				GiveItem2Character(pchar, "blade_whisper");
				EquipCharacterByItem(pchar, "blade_whisper");
				PlaySound("interface\important_item.wav");
				dialog.Text = "Ha ha ha ! Et cette lame est pour moi ! Regarde comme elle est large. Et elle est agréablement lourde dans mes mains. Et d'ailleurs, je te l'avais promis : je te rends ton épée légère comme une plume. N'oublie pas de regarder dans le coffre, tu trouveras peut-être quelque chose d'intéressant pour toi.";

			}
			Link.l1 = "Eh bien, tu es malin ! J'imagine que tu as déjà sorti tout ce qui avait le plus de valeur. Je vais jeter un œil...";
			Link.l1.go = "chard_exit_to_cave_entrance";

			ref _location = &locations[reload_location_index];
			//DeleteAttribute(_location, "box1");
			_location.box1.money = 300000;
			_location.box1.items.icollection = 1;
			_location.box1.items.Map_Best = 1;
			_location.box1.items.suit_2 = 1;
			//_location.box1.items.indian11 = 1;
			_location.box1.items.chest = 5;
			_location.box1.items.chest_quest = 2;
			_location.box1.items.jewelry1 = 30+rand(5);
			_location.box1.items.jewelry2 = 30+rand(5);
			_location.box1.items.jewelry3 = 30+rand(5);
			_location.box1.items.jewelry4 = 15+rand(5);
			_location.box1.items.jewelry6 = rand(55);
			_location.box1.items.jewelry7 = rand(70);
			_location.box1.items.jewelry10 = rand(55);
			_location.box1.items.jewelry14 = rand(55);
			_location.box1.items.jewelry15 = rand(8);
			_location.box1.items.jewelry18 = rand(90);

		break;
		case "chard_exit_to_cave_entrance":
			chrDisableReloadToLocation = false;
			NextDiag.TempNode = "chard_cave_entrance";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "Dominica_caveentrance", "", "", "", 7);
			pchar.quest.WhisperChardCave.win_condition.l1          = "location";
			pchar.quest.WhisperChardCave.win_condition.l1.location = "Dominica_caveentrance";
			pchar.quest.WhisperChardCave.function             = "WhisperChardCave";
		break;

		case "chard_cave_entrance":
			if (CheckAttribute(pchar, "cursed.lockspawn"))
			{
				DeleteAttribute(pchar, "cursed.waitingSkull");
				DeleteAttribute(pchar, "cursed.lockspawn");

			}
			pchar.quest.WhisperChardCave.win_condition.l1          = "location";
			pchar.quest.WhisperChardCave.win_condition.l1.location = pchar.location.from_sea;
			pchar.quest.WhisperChardCave.function             = "WhisperEngRevengeWarning";
			LocatorReloadEnterDisable("shore26", "boat", false);
			LocatorReloadEnterDisable("shore27", "boat", false);
			WhisperEnglandRevengel();
			pchar.ContraInterruptWaiting = true;
			dialog.Text = "Il faut reconnaître que nous avons touché le gros lot. Il y avait tant de butin là-dedans que je n'ai même pas de regret à le partager avec toi. J'ai de quoi boire pendant quelques années. Bon, on se sépare ?";
			Link.l2 = "Oui, moi aussi, je dois m'occuper de ma part. Bonne chance à toi.";
			Link.l2.go = "chard_exit_to_cave_entrance_1";
			if (CheckAttribute(pchar, "WhisperWonSword"))
			{
				Link.l1 = "Attends une minute, l'ami. Tu ne voudrais pas continuer à naviguer avec moi ? Je suis sמre que nous trouverons encore beaucoup de butin ensemble.";
				Link.l1.go = "chard_discuss_recruitment";
			}
		break;
		case "chard_discuss_recruitment":
			dialog.Text = "Hum... Je ne pars qu'avec ceux dont je suis absolument sמr de la chance. Tu m'as battu aux cartes, mais je ne suis pas aussi fort aux cartes qu'aux dés. Vérifions. Si la chance t'aime vraiment, tu gagneras, et je te suivrai jusqu'au bout du monde. Les règles sont les mêmes, en cinq victoires.";
			Link.l1 = "Bien. On joue.";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
            pchar.GenQuest.Dice.iRate     = 0;
            pchar.GenQuest.Dice.SitType   = false;
			Link.l1.go = "meet_chard_dice_begin_go";
			Link.l2 = "Non, je n'ai pas envie de jouer aujourd'hui, séparons-nous, alors. Bonne chance à toi.";
			Link.l2.go = "chard_exit_to_cave_entrance_1";
		break;
		case "meet_chard_dice_begin_go":
			chrDisableReloadToLocation = true;
			NextDiag.TempNode = "chard_after_dice_game";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchDiceGame();
			Lai_SetStayType(npchar);
		break;
		case "chard_after_dice_game":
			chrDisableReloadToLocation = false;

			if(CheckAttribute(pchar, "WhisperWonChard"))
			{
				LAi_SetImmortal(NPChar, false);
				SetCharacterRemovable(npchar, true);
				dialog.Text = "Oui, bonne chance à toi. Soit, je te confie ma vie.";
				Link.l1 = "Parfait. Tu feras un bon brמlot. Je plaisante... Allons-y.";
				Link.l1.go = "chard_hired";
			}
			else
			{
				dialog.Text = "On dirait que le destin lui-même s'en est mêlé. Malheureusement, ça ne va pas marcher entre nous.";
				Link.l1 = "Bon, d'accord. Alors, bonne chance à toi.";
				Link.l1.go = "chard_exit_to_cave_entrance_1";
			}
		break;
		case "chard_exit_to_cave_entrance_1":
			dialog.Text = "Et à toi. Garde toujours un as dans ta manche ! Voici un porte-bonheur pour toi, prélevé sur ma part.";
			RemoveCharacterCompanion(PChar, npchar);
			npchar.LifeDay = 0;
			TakeNItems(pchar, "indian11", 1);
			Log_Info("Vous avez reçu les haillons");
			PlaySound("interface\important_item.wav");
			Link.l1 = "Merci ! Adieu.";
			Link.l1.go = "chard_exit_to_cave_entrance_2";
		break;
		case "chard_hired":
			chrDisableReloadToLocation = false;
			DialogExit();
			Lai_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload2_back", "Dominica_grot", "", "", "", 12);
			SetCharacterPerk(npchar, "Adventurer");
			NPChar.Payment = true;
			//npchar.greeting = "Gr_QuestOfficer";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			npchar.HalfImmortal = true;  // Контузия
			npchar.loyality = MAX_LOYALITY;
			//AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = true;
			npchar.Dialog.CurrentNode = "hired";
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
		break;
		case "chard_exit_to_cave_entrance_2":
			chrDisableReloadToLocation = false;
			//NextDiag.TempNode = "chard_cave_entrance";
			//NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			Lai_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload2_back", "Dominica_grot", "", "", "", 12);
		break;

		case "chard_failed":
			dialog.Text = "Eh, il me semblait que le pari était bon, mais je n'aurais pas dמ te faire confiance. Disparais de ma vue...";
			LAi_SetImmortal(NPChar, true);
			npchar.LifeDay = 0;
			Link.l1 = "Ne te fâche pas comme ça, je m'en vais déjà.";
			Link.l1.go = "exit";
			LocatorReloadEnterDisable(pchar.Whisper.EsFriendTown+"_tavern", "reload2_back", true);
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.Whisper.EsFriendTown+"_tavern_upstairs")], false);
			DeleteAttribute(pchar,"Whisper.EsFriendTown");
		break;
		case "chard_betrayed":
			NPChar.rank = 77;
			LAi_SetHP(NPChar, 777.0, 777.0);
			if (CheckAttribute(pchar, "WhisperWonSword"))
			{
				NPChar.money = 77777;
			}
			else
			{
				NPChar.money = 277777;
			}
			chrDisableReloadToLocation = true;
			pchar.Whisper.BetrayChardKill = true;
			TakeNItems(npchar, "bible", 1);
			npchar.SaveItemsForDead = true;
			dialog.Text = "Eh, il me semblait que le pari était bon, mais je n'aurais pas dמ te faire confiance ; voyons qui aura de la chance aujourd'hui. Croisons le fer !";
			Link.l1 = "Je vois que pour toi, c'est le même jeu que les cartes. Tant pis pour toi.";
			Link.l1.go = "chard_fight";
			LocatorReloadEnterDisable(pchar.Whisper.EsFriendTown+"_tavern", "reload2_back", true);
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.Whisper.EsFriendTown+"_tavern_upstairs")], false);
			DeleteAttribute(pchar,"Whisper.EsFriendTown");
		break;
		case "chard_fight":
			Group_FindOrCreateGroup("EnemyFight");
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			AddDialogExitQuest("MainHeroFightModeOn");
			DialogExit();
			LAi_SetWarriorType(NPChar);
			LAi_SetImmortal(NPChar, false);
			//ref sld;
			LAi_group_MoveCharacter(npchar, "EnemyFight");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
		break;
		case "chard_discuss_esteban":
			npchar.DiscussedEsteban = true;
			dialog.Text = "Lui et moi étions de vieilles connaissances, nous avons même navigué sous la même voile quand nous étions simples matelots. Notre capitaine engageait tout le monde dans l'équipage, quelle que soit la nationalité. Mais c'était il y a bien des années. Finalement, Hernán est parti servir dans sa patrie, et moi, j'ai hérité du navire du capitaine. Nous ne nous étions pas revus depuis longtemps, mais récemment, nous nous sommes retrouvés et nous avons décidé de faire quelques parties de cartes. Il semble qu'au fil des années de service, il ait perdu toute sa chance d'autrefois, car je l'ai battu assez vite. Au final, il me devait une grosse somme. En vieil ami, je ne l'ai pas trop pressé de payer. Mais l'idée de devoir quelque chose à qui que ce soit, surtout à moi, ne lui plaisait pas, alors Hernán a décidé de piller tout le monde sans distinction jusqu'à réunir la somme, ce qui n'a visiblement pas plu à son employeur. Et finalement, il a dit qu'il partirait à la recherche du trésor du bordel, dont les objets de valeur couvriraient, paraît-il, largement sa dette de jeu. Je doutais de l'existence de ce trésor, et apparemment, j'avais raison. Je ne voulais pas le laisser partir, mais Hernán a insisté. Finalement, nous avons convenu qu'il me paierait au moins en partie avant de prendre la mer. J'ai pris cette épée et un autre objet, mais il semble que j'aie perdu à jamais la chance de récupérer le reste de la somme.";
			Link.l1 = "Tu as parlé d'un objet. Qu'est-ce que c'est ?";
			Link.l1.go = "chard_discuss_esteban_1";
			//Link.l1 = "Aren't you going to avenge your friend's death on me?";
			//Link.l1.go = "chard_discuss_esteban_1";
		break;
		case "chard_discuss_esteban_1":
			dialog.Text = "Je ne sais pas, ça m'a juste semblé être un joli bibelot. Je l'ai vendu dès le lendemain à un type encapuchonné qui s'est soudain présenté à moi.";
			Link.l1 = "א quoi ressemblait ce bibelot ?";
			Link.l1.go = "chard_discuss_esteban_2";
		break;
		case "chard_discuss_esteban_2":
			dialog.Text = "Une plaque de métal à laquelle étaient fixés un tas de tubes de verre et de leviers. Elle était aussi couverte d'inscriptions étranges et d'autres fanfreluches.";
			Link.l1 = "Bon sang, c'est ma machine à remonter le temps !";
			Link.l1.go = "chard_discuss_esteban_3";
		break;
		case "chard_discuss_esteban_3":
			dialog.Text = "Quoi ?";
			Link.l1 = "Rien. Oם est parti ton client ?";
			Link.l1.go = "chard_discuss_esteban_4";
		break;
		case "chard_discuss_esteban_4":
			dialog.Text = "Je n'en ai aucune idée. Après notre affaire, j'ai voulu le retrouver moi-même pour lui montrer deux ou trois autres objets à vendre, mais je n'y suis pas arrivé. Il semblait s'être volatilisé. Ni l'aubergiste ni le capitaine du port ne l'avaient vu. J'aurais presque cru ne l'avoir jamais vu moi-même, sans le poids de ma bourse. Il a peut-être payé ces gens une jolie somme pour qu'ils se taisent.";
			Link.l1 = "Je vois, encore une impasse, mais au moins, j'ai de l'espoir. Merci pour les informations.";
			Link.l1.go = "exit";
		break;
		case "chard_discuss_esteban_old":
			dialog.Text = "Tu avais tes propres comptes à régler avec lui, je ne peux pas te le reprocher. Et dans les Caraïbes, les gens s'entretuent tous les jours, ça m'est déjà devenu indifférent. Mais perdre un gros débiteur, c'est toujours dommage. Je ne te demanderai rien pour autant.";
			Link.l1 = "Je vois.";
			Link.l1.go = "exit";
		break;
		case "chard_discuss_quest":
			dialog.Text = "Je suis allé un jour aux Bermudes. Là, dans un souterrain, j'ai trouvé le trésor de quelqu'un, plein de bijoux de toutes sortes, ainsi qu'une bible. Au début, je l'ai mise de cכté sans y prêter attention, mais quand j'ai eu bu ma part du trésor, j'ai décidé de la feuilleter par curiosité. א part qu'elle était tout entière écrite en latin ou dans une autre langue étrange, elle n'avait rien de remarquable. Sauf quelques phrases soulignées, éparpillées dans tout le livre. Comme je l'ai compris plus tard, c'était un chiffre. Il nous a fallu plusieurs jours, à mon équipage et moi, pour le résoudre. Ce message caché parlait d'un trésor bien plus important, amassé par un groupe de corsaires ; les coordonnées de son emplacement étaient même jointes. Seulement, elles ne sont pas complètes, certaines pages sont abîmées. Il me manque un chiffre pour avoir l'emplacement exact. Le livre parlait aussi d'un certain Ralph Portman, soit un ami de celui qui a laissé la bible, soit son propriétaire. C'est peut-être une piste mince, et il y a peut-être beaucoup de gens de ce nom dans les Caraïbes, mais j'ai quand même creusé et j'ai découvert qu'il existe un corsaire de ce nom au service des Anglais. ";
			Link.l1 = "Tu m'as déjà raconté beaucoup de choses, mais tu n'en es pas venu au fait. Pourquoi as-tu besoin de moi ?";
			Link.l1.go = "chard_discuss_quest_1";
		break;
		case "chard_discuss_quest_1":
			//NextDiag.TempNode = "chard_discuss_quest_1";
			dialog.Text = "J'ai besoin que tu retrouves ce Portman et que tu découvres la coordonnée manquante, s'il l'a.";
			Link.l1 = "Pourquoi ne le fais-tu pas toi-même ?";
			Link.l1.go = "chard_discuss_quest_2";
		break;
		case "chard_discuss_quest_2":
			dialog.Text = "Vois-tu, je ne possède qu'un modeste brick, alors que Portman a plusieurs frégates. J'ai peur qu'en cas de combat, il ne reste de mon rafiot qu'une tache humide. Mais ton « Chien de Guerre » en viendra à bout sans problème.";
			Link.l1 = "Une corvette contre un groupe de frégates ? J'en doute.";
			Link.l1.go = "chard_discuss_quest_3";
		break;
		case "chard_discuss_quest_3":
			dialog.Text = "Tu viens sans doute de passer sur le « Chien de Guerre ». Cette corvette n'est en rien inférieure aux frégates, elle les surpasse même à bien des égards. Mais si tu doutes encore de tes capacités, tu peux aller voir Alexus.";
			Link.l1 = "Alexus ? Qui est-ce ?";
			Link.l1.go = "chard_discuss_quest_4";
			Link.l2 = "Bon, j'y réfléchirai. Mais oם chercher cet Anglais ?";
			Link.l2.go = "chard_discuss_quest_5";
		break;
		case "chard_discuss_quest_4":
			dialog.Text = "Eh bien, le maître charpentier de marine, le meilleur de tout l'archipel. Il a son propre chantier naval aux Bermudes. Tu peux lui montrer ton navire. Même si le « Chien de Guerre » est bon, je suis sמr qu'Alexus trouvera des moyens de l'améliorer. Alors, tu pourras venir à bout de n'importe quelle escadre sans problème.";
			Link.l2 = "Bon, j'y réfléchirai. Oם trouver cet Anglais ?";
			Link.l2.go = "chard_discuss_quest_5";
		break;
		case "chard_discuss_quest_5":
			NextDiag.TempNode = "chard_waiting_quest_result";
			//SaveCurrentNpcQuestDateParam(pchar,"Whisper.LastSeenPortman");
			pchar.Whisper.ActiveChardQuest = true;
			AddQuestRecord("WhisperChardQuest", "2");
			dialog.Text = "La dernière fois que je l'ai vu, c'était dans les eaux du coin, mais je n'ai pas osé agir, et il est reparti. Je pense que tu n'auras pas de mal à le trouver. Renseigne-toi auprès des capitaineries ; on l'a sמrement vu quelque part, et si tu t'en sors, reviens ici. Je combinerai les coordonnées et j'obtiendrai l'emplacement exact du trésor.";
			Link.l2 = "D'accord, au revoir.";
			Link.l2.go = "exit";
		break;
		case "chard_get_sword":
			Log_Info("Vous avez récupéré votre épée");
			GiveItem2Character(pchar, "blade_whisper");
			EquipCharacterByItem(pchar, "blade_whisper");
			PlaySound("interface\important_item.wav");
			RemoveCharacterEquip(npchar, BLADE_ITEM_TYPE);
			DeleteAttribute(npchar, "items");
			DeleteAttribute(npchar, "equip");
			GiveItem2Character(npchar, "pistol4");
			EquipCharacterbyItem(npchar, "pistol4");
			GiveItem2Character(npchar, "blade34");
			EquipCharacterByItem(npchar, "blade34");
			dialog.Text = "Puisque tu es là et que tu as un bon navire, ça t'ennuierait de m'aider pour une affaire ?";
			Link.l1 = "Quel genre d'aide te faut-il ?";
			Link.l1.go = "chard_discuss_quest";
		break;
		case "chard_not_played":
			dialog.Text = "Encore toi ? Tu as décidé de jouer avec moi ?";
			if (sti(pchar.money) >= 200000)
			{
				Link.l1 = "Bon, distribue les cartes.";
				Link.l1.go = "meet_chard_7_cardGame";
			}
			Link.l2 = "Non.";
			Link.l2.go = "exit";
		break;
		case "meet_chard":
			NextDiag.TempNode = "chard_not_played";
			dialog.Text = "Je t'ai fait appeler ? Pardon, je ne m'en souviens pas. J'étais sans doute trop soמl... Qui es-tu, au juste ?";
			Link.l1 = "Whisper. Capitaine de la corvette « Chien de Guerre ». ";
			Link.l1.go = "meet_chard_1";
		break;
		case "meet_chard_1":
			dialog.Text = "Capitaine ? Attends, oם est passé Esteban ?";
			Link.l1 = "Mort tragiquement aux îles Turques. Il est tombé dans une embuscade là-bas.";
			Link.l1.go = "meet_chard_2";
			Link.l2 = "J'ai tué ce salaud.";
			Link.l2.go = "meet_chard_3";
		break;
		case "meet_chard_2":
			dialog.Text = "Je lui avais pourtant dit qu'il y avait quelque chose de louche avec ce trésor. Je sentais le piège.";
			Link.l1 = "(Votre regard est attiré par la poignée familière d'une lame qui pend à la ceinture d'un inconnu.) Une minute... C'est mon épée ! ";
			Link.l1.go = "meet_chard_4";
		break;
		case "meet_chard_3":
			dialog.Text = "On ne peut pas dire le contraire, c'était une ordure, mais comment a-t-il osé mourir sans m'avoir remboursé d'abord ?";
			Link.l1 = "(Votre regard est attiré par la poignée familière d'une lame qui pend à la ceinture d'un inconnu.) Une minute... C'est mon épée ! ";
			Link.l1.go = "meet_chard_4";
		break;
		case "meet_chard_4":
			dialog.Text = "Je ne sais rien. Cette lame est à moi, je l'ai gagnée honnêtement aux cartes contre Esteban... Je crois que j'ai compris qui tu es, Whisper. Esteban parlait de la fille à qui il avait pris un pistolet et une épée. Ravi de te rencontrer enfin, je suis Michael Chard. Il m'avait assuré qu'il t'avait achevée.";
			Link.l1 = "Comme tu vois, je suis plus vivante que jamais, contrairement à ce fanfaron. Maintenant, rends-moi l'épée !";
			Link.l1.go = "meet_chard_5";
		break;
		case "meet_chard_5":
			dialog.Text = "Regardez-moi ça ! Je ne vais rien te donner comme ça, mais bon, je n'aime pas vraiment cette épée, elle est trop légère, je préfère les armes plus lourdes. Tu sais quoi ? Jouons aux cartes. Si tu gagnes, elle est à toi. Si je gagne, tu paies. Disons... deux cent mille.";
			Link.l1 = "Combien ? Tu t'es cogné la tête ?";
			Link.l1.go = "meet_chard_6";
			if (sti(pchar.money) >= 200000)
			{
				Link.l2 = "Bon, distribue les cartes.";
				Link.l2.go = "meet_chard_7_cardGame";
			}
			Link.l3 = "Une autre fois.";
			Link.l3.go = "exit";
		break;
		case "meet_chard_6":
			dialog.Text = "Je ne vais pas jouer pour moins. Soit on joue, soit tu fiches le camp.";
			if (sti(pchar.money) >= 200000)
			{
				Link.l1 = "Bon, distribue les cartes.";
				Link.l1.go = "meet_chard_7_cardGame";
			}
			Link.l2 = "Une autre fois.";
			Link.l2.go = "meet_chard_8";
		break;
		case "meet_chard_8":
			dialog.Text = "Reviens si tu changes d'avis.";
			Link.l1 = "Au revoir.";
			Link.l1.go = "exit";
		break;
		case "meet_chard_7_cardGame":
			NextDiag.TempNode = "First time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			dialog.Text = "Voilà qui nous va ! On joue en cinq victoires.";
			Link.l1 = "D'accord.";
			Link.l1.go = "meet_chard_Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
			int iLa_Puesta = 0;
			pchar.GenQuest.Cards.iRate     = sti(iLa_Puesta);
            pchar.GenQuest.Cards.SitType   = true;
		break;
		case "meet_chard_Cards_begin_go":
				chrDisableReloadToLocation = true;
                //Diag.CurrentNode = Diag.TempNode;
                DialogExit();
                LaunchCardsGame();
		break;

		case "LejitosOff":
			NPChar.Payment = true;
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			//npchar.greeting = "Gr_QuestOfficer";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			npchar.HalfImmortal = true;  // Контузия
			npchar.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = true;
			//LAi_SetWarriorType(NPChar);
			DialogExit();
		break;
		case "LejitosNoOff":
			DialogExit();
			NPChar.lifeday = 0;
			LAi_SetActorType(NPChar);
			LAi_ActorGoToLocation(npchar, "reload", "reload2_back", "none", "", "", "", 10);
		break;
		case "Lejitos":
			dialog.Text = "Je ne suis pas chrétien. Mes parents l'étaient, mais ils n'ont pas vécu assez longtemps pour m'imposer cette croyance. J'ai été trouvé, recueilli et élevé dans la tribu indienne des Guaranis. Ils m'ont ouvert les yeux sur la vraie foi et m'ont expliqué toute la vérité sur le Dieu chrétien.";
			Link.l1 = "Tu as vécu toute ta vie parmi les Indiens ?";
			Link.l1.go = "Lejitos_1";
		break;
		case "Lejitos_1":
			dialog.Text = "Malheureusement, les Espagnols ne m'ont pas accordé ce luxe. Un jour, je suis parti chasser, et quand je suis rentré chez moi avec le gibier, j'ai trouvé notre village en ruine. Toute la tribu avait été exterminée. Bien sמr, je me suis vengé, mais ça ne ramènera pas la tribu. Ensuite, je suis allé vivre chez les Espagnols, dans une société prétendument civilisée. Pendant quelques années, j'ai vécu en paix, à m'installer dans un nouvel endroit, jusqu'au jour oם quelqu'un a parlé au prêtre du coin des inoffensifs rituels indiens que j'accomplissais avant de manger. Celui-ci en a informé l'Inquisition, et la suite, je pense que tu peux la deviner. Depuis, je me cache des Espagnols dans les colonies hollandaises, mais même ici, ils ne me laissent pas en paix. Ce n'est ni le premier ni le dernier groupe de chasseurs qui vient chercher ma tête.";
			Link.l1 = "Personnellement, je me fiche de ce en quoi tu crois. Mais en tant que combattant, je vois que tu es une vraie bête. Tu veux entrer à mon service ? Je te le promets : dans mon équipage, tu tueras beaucoup d'Espagnols. Pour l'instant, j'ai l'intention de rattraper ce navire dont parlait l'une de ces ordures.";
			Link.l1.go = "Lejitos_2";
			Link.l2 = "Je ne crois pas que nous suivions le même chemin, l'ami. Adieu.";
			Link.l2.go = "LejitosNoOff";
		break;
		case "Lejitos_2":
			dialog.Text = "Tu es très persuasive. Bien sמr, je ne serais pas contre l'idée d'ajouter quelques scalps espagnols à ma collection.";
			Link.l1 = "C'est réglé. Au fait, on m'a dit que tu étais venu dans cette grotte pour le trésor. Tu as réussi à trouver quelque chose ?";
			Link.l1.go = "Lejitos_3";
		break;
		case "Lejitos_3":
			dialog.Text = "Ce n'est pas un trésor, mais une relique indienne. Je peux te la confier, mais je t'en prie, ne la vends pas. On la fondrait à coup sמr en lingots, et sa vraie valeur serait perdue à jamais.";
			Link.l1 = "Bon, allons-y.";
			Link.l1.go = "LejitosOff";
		break;

		case "DeSouzaHunter":
			dialog.Text = "דa alors, qui voilà ! On dirait que nous allons faire d'une pierre deux coups ! Cet impie d'Eligio suffirait déjà à faire plaisir à señor de Souza, mais si nous t'amenons toi aussi, nous aurons sמrement une prime !";
			Link.l1 = "De Souza, dis-tu ? Oם est-il ?";
			Link.l1.go = "DeSouzaHunter_1";
		break;
		case "DeSouzaHunter_1":
			AddQuestRecord("WhisperQuestline", "6");
			dialog.Text = "Quoi, tu as hâte de recevoir de lui une nouvelle dose de torture ? Je te rassure, tu n'attendras pas longtemps, car il est ici, pas loin, sur le navire. Nous avons mouillé dans une baie au nom ironique pour toi : la Cכte du Salut. Sur le navire, tous les instruments sont déjà prêts. Tu es Whisper, n'est-ce pas ? J'ai vu là-bas une vierge de fer avec ton nom dessus ; alors, tu y vas toi-même ? Ou tu veux d'abord recevoir une portion de notre part ? Je te pose la même question, señor Lejito.";
			Link.l1 = "Voyons maintenant qui va recevoir quoi de qui !";
			Link.l1.go = "exit_lejitos_speak";
		break;
		case "exit_lejitos_speak":
			DialogExit();
			sld = characterFromID("W_Lejitos");
			SetActorDialogAny2Pchar(sld.id, "", 2.0, 0.0);
			LAi_ActorFollow(sld, pchar, "ActorDialog_Any2Pchar", 4.0);
		break;
		case "exit_cave_entrance_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			DialogExit();
			LAi_SetWarriorType(NPChar);
			LAi_SetImmortal(NPChar, false);
			//ref sld;
			for (int i = 1; i <= 7; i++)
			{
				sld = characterFromID("DeSouzaHunter"+sti(i));
				LAi_SetWarriorType(sld);
				LAi_SetImmortal(sld, false);
				LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			}
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
		break;
		case "Smuggler":
			NextDiag.TempNode = "Smuggler";
			if (CheckAttribute(pchar, "Whisper.ContraSmuggler"))
			{
				dialog.Text = "Et toi, qui es-tu ? Que veux-tu ici ?";
				Link.l1 = "Nous avons une connaissance commune, toi et moi, nommée "+GetCharacterFullName("Tortuga_trader")+". J'ai apporté la marchandise, comme convenu.";
				Link.l1.go = "Whisper_contraband";
				Link.l2 = "Pas mal.";
				Link.l2.go = "exit";
			}
			else
			{
				dialog.Text = "L'affaire est faite, et maintenant, fiche le camp d'ici, tu n'as rien à faire ici !";
				Link.l1 = "Je m'en vais, mais pas besoin d'être insolent.";
				Link.l1.go = "exit";
			}

		break;
		case "Whisper_contraband":
			if(Pchar.Location != Pchar.location.from_sea)
			{
				dialog.Text = "Tout ça est très intéressant, mais oם est ton navire ? Ou tu as apporté toute la marchandise sur ton dos ?";
				Link.l1 = "Le navire viendra, je voulais d'abord vérifier l'endroit.";
				Link.l1.go = "Whisper_contraband_2";
				break;
			}
			if(GetSquadronGoods(Pchar, GOOD_EBONY) >= 100)
			{
				DeleteAttribute(pchar, "Whisper.ContraSmuggler");
				dialog.Text = "Je vois. Tout semble en ordre. Mes esclaves... enfin, les ouvriers vont tout décharger en un clin d'œil. Voici ton argent.";
				AddMoneyToCharacter(PChar, 50000);
				RemoveCharacterGoods(Pchar, GOOD_EBONY, 100);
				Link.l1 = "Une jolie somme, merci.";
				Link.l1.go = "Whisper_contraband_1";

				break;
			}
			if(GetSquadronGoods(Pchar, GOOD_EBONY) < 100 && GetSquadronGoods(Pchar, GOOD_EBONY) > 0)
			{
				dialog.Text = "Tu n'as pas assez de marchandise. Reviens quand tu en auras rassemblé assez.";
				Link.l1 = "C'est vrai. Attends, je vais en acheter encore et je reviens.";
				Link.l1.go = "Whisper_contraband_2";
				break;
			}
			if(GetSquadronGoods(Pchar, GOOD_EBONY) == 0)
			{
				dialog.Text = "Tu te moques de moi ? Tu n'as pas du tout la marchandise qu'il faut dans ta cale !";
				Link.l1 = "J'ai dמ la ranger quelque part. Ne bouge pas, je reviens tout de suite.";
				Link.l1.go = "Whisper_contraband_2";
			}
		break;
		case "Whisper_contraband_1":
			dialog.Text = "Au fait, si tu trouves encore quelque chose d'intéressant, apporte-le-nous tout de suite, parce que "+GetCharacterFullName("Tortuga_trader")+" compte bientכt arrêter ce genre d'affaires. Tu pourras toujours trouver l'un de nos représentants à la taverne.";
			WhisperRemoveSmugglersFromShore();
			AddQuestRecord("WhisperContraband", "3");
			CloseQuestHeader("WhisperContraband");
			Link.l1 = "D'accord, j'en tiendrai compte.";
			Link.l1.go = "exit";
			//pchar.quest.WhisperChinaman.win_condition.l1 = "ExitFromLocation";
			pchar.quest.WhisperChinaman.win_condition.l1 = "EnterToSea";
			pchar.quest.WhisperChinaman.function    = "WhisperChinaman";
			WhisperSmugglingPatrol();
			pchar.ContraInterruptWaiting = true;
			//CaptainComission_GenerateCoastalPatrol();

		break;
		case "Whisper_contraband_2":
			dialog.Text = "Et dépêche-toi, je ne compte pas passer ma vie dans cette baie.";
			Link.l1.go = "exit";
		break;

		case "Jim":
			dialog.text = "Après la façon dont tu as réglé son compte à Jack, personne dans l'équipage n'osera te contredire. Il tenait tout le monde en respect. En plus, nous avons une tradition à bord : à la mort de l'ancien capitaine, c'est le plus enragé des coupe-jarrets qui prend sa place, celui qui tue les autres prétendants au chapeau. Un capitaine pareil n'aurait pas peur de nous mener vers le butin le plus riche.";
			link.l1 = "Tu sais, votre tradition me plaît. Combien de capitaines se sont déjà succédé ?";
			link.l1.go = "Jim_1";
		break;
		case "Jim_1":
			dialog.text = "Pas mal. Ce n'est pas pour rien qu'on appelle ce navire la Veuve noire. Des gens de tout poil, de tout âge et des deux sexes ont occupé ce poste. En moyenne, un capitaine tient quelques mois, puis soit il meurt d'un accident ridicule, soit l'équipage se révolte. Bill a été le plus chanceux : il a tenu trois ans.";
			link.l1 = "Tu m'as brossé un tableau bien sombre. On dirait que ta « Veuve » est maudite. Mais on ne se débarrasse pas de moi si facilement. J'accepte de devenir capitaine, même si je ne peux pas dire que je m'y connaisse en conduite d'un navire.";
			link.l1.go = "Jim_2";
		break;
		case "Jim_2":
			SetQuestHeader("WhisperContraband");
			AddQuestRecord("WhisperContraband", "1");
			pchar.Whisper.Contraband = true;
			pchar.Whisper.FindDesouza = true;
			SetTimerCondition("W_Smuggling", 0, 0, 60, false);
			dialog.text = "Ce n'est rien, tu apprendras. Bill n'y arrivait pas non plus au début, et pourtant, c'est le meilleur capitaine que la Veuve ait connu. Nous t'aiderons au début, si besoin. Au fait, Bill avait aussi une carte de l'archipel sur lui ; si tu l'as trouvée, sers-t'en pour naviguer plus facilement, et si tu ne sais pas par oם commencer, regarde son journal de bord. Il y a des notes que Bill a rédigées. Nous devions livrer de la marchandise à quelqu'un à Tortuga, mais je ne connais pas tous les détails, alors tu ferais mieux de le lire toi-même.";
			link.l1 = "D'accord, je le lirai à loisir. Et oם est notre rafiot ?";
			link.l1.go = "Jim_EndLine";
		break;
		case "Jim_EndLine":
			dialog.text = "Juste ici, dans la baie. Viens au rivage et remonte dans la chaloupe. Autre chose : l'affaire que Bill préparait n'était sמrement pas tout à fait légale. Je te conseille de te changer et de mettre quelque chose de discret avant de t'y attaquer. On a plein de frusques à bord, tu pourras te trouver quelque chose.";
			TakeNItems(pchar, "suit_1", 1);
			Log_Info("Vous avez reçu les haillons");
			PlaySound("interface\important_item.wav");
			link.l1 = "...";
			link.l1.go = "Finish";
		break;
		case "Finish":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			chrDisableReloadToLocation = false;
			bDisableCharacterMenu = false;
			LocatorReloadEnterDisable("Santiago_ExitTown", "reload3", false);
			LocatorReloadEnterDisable("Havana_ExitTown", "reload4", false);
			LocatorReloadEnterDisable("PuertoPrincipe_ExitTown", "reload3", false);
			LocatorReloadEnterDisable("PuertoPrincipe_ExitTown", "reload1_back", false);
			LocatorReloadEnterDisable("PuertoPrincipe_ExitTown", "reload2_back", false);
			LocatorReloadEnterDisable("PuertoPrincipe_Port", "reload1_back", false);
			InterfaceStates.DisFastTravel = false;
			DeleteAttribute(Pchar, "questTemp.WhisperTutorial");
			bDisableLandEncounters = false;
			//DoReloadCharacterToLocation(Pchar.HeroParam.Location, Pchar.HeroParam.Group, Pchar.HeroParam.Locator);
			Lai_SetPlayerType(pchar);

			SetQuestHeader("WhisperQuestline");
			AddQuestRecord("WhisperQuestline", "1");
			AddQuestRecord("WhisperQuestline", "2");
			AddQuestUserData("WhisperQuestline", "sWhCapName", GetFullName(characterFromId("wl_Pirate_Cap")));
			//AddQuestRecord("WhisperQuestline", "3");

			SetQuestsCharacters();

			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", 25);
			for(i=1; i < 5; i++)
			{
				sld = CharacterFromID("Wh_Crew"+sti(i));
				LAi_SetActorType(sld);
				LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", 20);
			}
		break;
		case "Jack":
			dialog.text = "C'est vrai ? Ha ha ! Enfin, euh... C'est bien dommage, évidemment. Bon, donne-moi ses affaires et dégage.";
			link.l1 = "דa m'étonnerait. J'en aurai encore besoin.";
			link.l1.go = "Jack_1";
		break;
		case "Jack_1":
			dialog.text = "Tu n'as sans doute pas compris. Ce chapeau et cette lame, comme la couronne et le sceptre, sont les symboles du pouvoir sur la Veuve noire. Celui à qui ils appartiennent est le capitaine. J'ai longtemps patienté en attendant mon tour. Je n'ai pas étranglé le capitaine dans son sommeil pour accélérer les choses. J'en avais l'intention, mais je ne l'ai pas fait.";
			link.l1 = "א t'entendre, tu es une belle ordure, et te confier le pouvoir serait de la folie.";
			link.l1.go = "Jack_2";
		break;
		case "Jack_2":
			dialog.text = "Ah, espèce de canaille ! Je vais te...";
			link.l1 = "Essaie un peu.";
			link.l1.go = "Jack_fight";
		break;
		case "Jack_fight":
			Lai_SetPlayerType(pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
			//LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			LAi_SetImmortal(NPChar, false);
			PChar.quest.WhisperJimTalk.win_condition.l1 = "NPC_Death";
			PChar.quest.WhisperJimTalk.win_condition.l1.character = npchar.id;
			pchar.quest.WhisperJimTalk.function = "WhisperJimTalk";
			DialogExit();
		break;
		case "NF":
			dialog.text = "Si j'étais inquisiteur, moi aussi, j'aurais bien envie de te passer à la casserole. Ha, je plaisante ! Mais quand même, par ici, on ne voit pas d'un très bon œil une allure comme la tienne.";
			link.l1 = "דa, je l'avais compris.";
			link.l1.go = "NF_1";
		break;
		case "NF_1":
			dialog.text = "Faisons connaissance. Je suis Bill Neuf-Doigts.";
			link.l1 = "Whisper.";
			link.l1.go = "NF_2";
		break;
		case "NF_2":
			dialog.text = "Bon sang, tu as déjà un surnom de vraie corsaire ! Je vais te dire une chose, Whisper. Puisque tu te caches des Espagnols, ce serait bien que tu te fasses faire de nouveaux papiers pour pouvoir te cacher dans les colonies d'un autre pays.";
			link.l1 = "Et oם puis-je en trouver ?";
			link.l1.go = "NF_3";
		break;
		case "NF_3":
			dialog.text = "Ici même, dans notre bourgade, à la taverne. C'est le grand bâtiment derrière moi. Cherche un diplomate à l'une des tables. Il fera tout pour toi, et au mieux.";
			link.l1 = "Merci du conseil, je ne manquerai pas de le suivre.";
			link.l1.go = "NF_exit";
		break;
		case "NF_exit":
			Lai_SetPlayerType(pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.Whisper.BuyDocuments = true;
		break;
		case "NF_2_1":
			dialog.text = "Je ne sais pas pour toi, mais moi, je fonce vers mon navire et je file d'ici.";
			link.l1 = "...";
			link.l1.go = "NF_2_exit";
		break;
		case "NF_2_exit":
			//Lai_SetPlayerType(pchar);
			TakeNItems(npchar, "blade19", 1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_CharacterPlaySound(pchar, "People Fight\Player_Man_Shoot_01.wav");
			DoQuestFunctionDelay("WhisperKillNineFingers", 0.7);
			DialogExit();
			pchar.questTemp.Whisper.GetHat = true;
			DoQuestCheckDelay("TalkSelf_Quest", 2.5);
		break;
		case "Pirateguard":
			dialog.text = RandPhraseSimple("Que voulez-vous ? Passez votre chemin.", "Arrêtez de me barrer la route, dégagez.");
			link.l1 = RandPhraseSimple("Vous savez quoi ? N'aboyez pas !", "Modérez votre ardeur. Sinon, je vais vite la refroidir !");
			NextDiag.CurrentNode = "Pirateguard";
			link.l1.go = "exit";
		break;
		case "IncqGuard_bad":
			dialog.text = "Nous voilà seuls. Tu pensais vraiment que c'était fini ? Si c'est le cas, je dois te décevoir. Vois-tu, pendant que de Souza se repose ou s'occupe d'autres affaires, c'est moi qui le remplace ici. Je ne te poserai pas de questions, c'est le travail de l'inquisiteur. Je vais juste te rendre plus accommodante d'ici son arrivée, pour qu'il n'ait plus à t'arracher les réponses. Viens, je vais te présenter nos « jouets ». Nous avons reçu récemment une « roue », et tu auras l'honneur d'être la première à l'essayer. Allez, ne fais pas la timide. Et n'essaie pas de t'échapper, il y a beaucoup de gardes ici.";
			link.l1 = "(Le suivre en silence)";
			link.l1.go = "IncqGuard_bad_go_to_wheel";
		break;
		case "IncqGuard_bad_go_to_wheel":
			DialogExit();
			LAi_ActorGoToLocator(NPChar, "goto", "goto11", "WhisperLine_IncqGuard_bad_speaks", -1);
			LAi_ActorGoToLocator(PChar, "goto", "goto11", "WhisperLine_IncqGuard_bad_speaks", 10);
			Npchar.dialog.currentnode = "IncqGuard_bad_wheel";
			//DoQuestFunctionDelay("WhisperLine_IncqGuard_bad_speaks", 5);
		break;
		case "IncqGuard_bad_wheel":
			for (i=1; i<=4; i++)
			{
				sld = characterFromId("IncqGuard_"+i);
				LAi_SetActorTypeNoGroup(sld);
			}
			dialog.text = "Et voici notre petite merveille. Si je me souviens bien des instructions, il faut d'abord t'attacher à la roue, puis tourner lentement le levier. Les pointes en dessous vont irrémédiablement estropier et défigurer ton corps. Après ça, tu ne pourras sans doute plus marcher sans l'aide de quelqu'un... Bon, oם est passée la corde ?";
			link.l1 = "Pardon, mais je suis obligée de décliner ton offre. J'aurai encore besoin de mes jambes quand je chercherai un moyen de sortir d'ici. (Pendant qu'il hésite, vous lui arrachez son pistolet de l'étui d'un geste vif)";
			link.l1.go = "IncqGuard_bad_wheel_kill";
		break;
		case "IncqGuard_bad_wheel_kill":
			DialogExit();
			//RemoveCharacterEquip(npchar, BLADE_ITEM_TYPE);
			npchar.SaveItemsForDead = true;
			GiveItem2Character(pchar, "pistol3");
			EquipCharacterByItem(pchar, "pistol3");
			Lai_SetPlayerType(pchar);
			//AddDialogExitQuest("MainHeroFightModeOn");
			DoQuestFunctionDelay("WhisperLine_WhisperHits", 0.2);
		break;
		case "IncqGuard":
			dialog.text = "J'ai entendu dire qu'on parle de toi à la taverne du coin. Il paraît que tu as rossé à toi seule toute une bande de marins. C'est vrai ?";
			link.l1 = "Avec mes armes modernes, ce n'était pas difficile. Pourquoi tu me fixes comme ça ?";
			link.l1.go = "IncqGuard_1";
		break;
		case "IncqGuard_1":
			dialog.text = "Je n'ai jamais vu d'aussi belle fille de ma vie, et en plus avec des cheveux violets... tu... Tu es une sorcière ?";
			link.l1 = "Tu veux que je t'ensorcelle, toi aussi ?";
			link.l1.go = "IncqGuard_2";
		break;
		case "IncqGuard_2":
			dialog.text = "Que Dieu ait pitié de moi ! Je ne suis pas...";
			link.l1 = "...Abouda, kabouda, avara kadava !";
			link.l1.go = "IncqGuard_3";
		break;
		case "IncqGuard_3":
			dialog.text = "Tais-toi immédiatement, ou je te... sur-le-champ !";
			link.l1 = "Koumprana, vocamos, transforme-toi en grenouille, BADABOUM !";
			link.l1.go = "IncqGuard_4";
			Pchar.BaseNation = SPAIN;
			if (CheckAttribute(npchar,"quest.answer_1"))
			{
				link.l1 = "D'accord, je suis prêt.";
				link.l1.go = "IncqGuard_exit";
			}
		break;
		case "IncqGuard_4":
			dialog.text = "Aaaaah, au secours !!";
			npchar.quest.answer_1 = true;
			link.l1 = "...";
			link.l1.go = "IncqGuard_exit";
		break;
		case "IncqGuard_exit":
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Fortune", 150);
			
			Lai_SetPlayerType(pchar);
			InterfaceStates.Buttons.Save.enable = true;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();

			PChar.quest.WhisperEscape.win_condition.l1 = "locator";
			PChar.quest.WhisperEscape.win_condition.l1.location = "Santiago_Incquisitio";
			PChar.quest.WhisperEscape.win_condition.l1.locator_group = "reload";
			PChar.quest.WhisperEscape.win_condition.l1.locator = "reload1_back";
			PChar.quest.WhisperEscape.function = "WhisperEscape";
		break;
		case "ADS":
			dialog.text = "Vraiment ? Alors, dis-moi qui tu es. Des yeux et des cheveux de cette couleur, on n'en voit pas tous les jours, tu sais. Et quel est ce pistolet que " + GetFullName(characterFromId("wl_Pirate_Cap"))+" t'a pris ?";
			link.l1 = "Je... J'ai du mal à répondre.";
			link.l1.go = "ADS_1_lie";

		break;
		case "ADS_1":
			dialog.text = "Du futur, tu dis ? Et dans ce cas, qu'est-ce qu'il te fallait à notre époque ?";
			link.l1 = "Rien, je suis arrivée ici par accident. וcoutez, vous devez parler à Hernán Esteban et lui demander l'appareil que j'avais sur moi. Je vous montrerai comment il fonctionne, et je vous prouverai ce que je dis.";
			link.l1.go = "ADS_1_1";
		break;
		case "ADS_1_lie":
			dialog.text = "Tu comptes jouer les muettes avec moi ?";
			pchar.Whisper.DeSouzaHits = 0;
			link.l1 = "...";
			link.l1.go = "ADS_1_2";
		break;
		case "ADS_1_truth":
			dialog.text = "Je t'écoute. ";
			link.l2 = "Vous aurez peut-être du mal à le croire, mais je viens du futur. Quelques siècles plus tard, ce genre d'armes sera aussi répandu que les épées aujourd'hui. Et mon apparence ne semblera plus si étrange.";
			link.l2.go = "ADS_1";
		break;
		case "ADS_1_1":
			dialog.text = "דa suffit. Tu me prends pour un idiot ? Je ne croirai jamais aux voyages dans le temps. Tu aurais mieux fait de me raconter une autre histoire sur le Hollandais volant. Venons-en au fait. Si le pistolet n'est pas anglais, alors à qui est-il ? Aux Hollandais ?";
			pchar.Whisper.DeSouzaHits = 2;
			link.l1 = "...";
			link.l1.go = "ADS_1_2";
		break;
		case "ADS_1_2":
			DoQuestFunctionDelay("WhisperLine_DeSouzaHits", 0.5);
			DialogExit();
		break;
		case "ADS_2":
			dialog.text = "Tu oses encore me menacer ?! Espèce de garce !";
			pchar.Whisper.DeSouzaHits = 1;
			link.l1 = "...";
			link.l1.go = "ADS_1_2";
		break;
		case "ADS_3":
			dialog.text = "Tu l'auras cherché.";
			pchar.Whisper.DeSouzaHits = 2;
			link.l1 = "...";
			link.l1.go = "ADS_1_2";
		break;
		case "ADS_4_exit":
			LAi_SetActorTypeNoGroup(npchar);
			//LAi_SetActorType(pchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 7);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			DoQuestFunctionDelay("WhisperLine_IncqGuard", 8.0);
		break;


		case "PC":
			dialog.text = "C'est à moi de te poser la question ! Tu as un nom ?";
			link.l1 = "Whisper.";
			link.l1.go = "PC_1";
		break;
		case "PC_1":
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
			dialog.text = "Oh, tu ne me plais pas. Tu as l'air bien trop suspecte. Allez, les gars, montrez à notre nouvelle compagne de voyage le chemin de la cale, et attachez-la solidement. Je m'occuperai d'elle plus tard.";
			link.l1 = "Dans quel pétrin je me suis fourrée...";
			link.l1.go = "PC_nofight";
		break;
		case "PC_nofight":
			Pchar.model="PGG_Whisper_0_NoHat";
			DeleteAttribute(pchar,"cirassID");
			DoQuestFunctionDelay("WhisperHold", 0.5);
			DialogExit();
		break;
		case "PC_2":
			dialog.text = "Aussi longtemps qu'il le faudra. Ces objets ont l'air de valoir cher, tu as sמrement des parents riches. Je propose qu'on aille les voir pour exiger une rançon. Dès que j'aurai l'argent, tu seras libre. Alors, dans quelle colonie peut-on les trouver ?";
			link.l1 = "Je ne suis pas d'ici. Je n'ai pas de famille ici.";
			link.l1.go = "PC_2_1";
		break;
		case "PC_2_1":
			dialog.text = "Tu crois que ça va m'apitoyer ? Ou peut-être que tu me prends pour un imbécile ? Alors, tu te trompes lourdement. Tu sais, j'ai un ami qui saura te faire parler : Antonio de Souza. C'est le chef de l'Inquisition à Santiago, et j'ai dמ travailler avec lui une fois. Je vais te dire une chose : le type est très désagréable, mais il sait obtenir ce qu'il veut. Je lui ai amené un jour un pirate taciturne, et dès le lendemain, nous connaissions l'emplacement de quatre trésors enterrés. Le pauvre bougre est mort pendant ses aveux ; je n'ose même pas imaginer ce que de Souza te fera quand il te verra. Avec une couleur de cheveux pareille, ce sera sans doute directement le bמcher.";
			link.l1 = "Fais-moi peur tant que tu veux, je connais des histoires bien pires !";
			link.l1.go = "PC_2_2";
			link.l2 = "On ne peut vraiment pas s'arranger ?";
			link.l2.go = "PC_2_3";
		break;
		case "PC_2_2":
			dialog.text = "Je dis juste les choses comme elles sont. Courage. D'ici à ce qu'on arrive, tu as quelques jours pour te préparer à la rencontre la moins agréable de ta vie.";
			link.l1 = "...";
			link.l1.go = "PC_2_exit";
		break;
		case "PC_2_3":
			dialog.text = "J'ai bien peur que non. Je t'ai proposé une solution, mais tu t'es mise à esquiver la question. Que de Souza découvre lui-même s'il y a une rançon à tirer de toi, ou d'oם viennent de tels pistolets. Courage. D'ici à ce qu'on arrive, tu as quelques jours pour te préparer à la rencontre la moins agréable de ta vie.";
			link.l1 = "...";
			link.l1.go = "PC_2_exit";
			link.l2 = "Attends...";
			link.l2.go = "PC_2_exit";
		break;
		case "PC_2_exit":
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", 7);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.Whisper.HoldMonologue = true;
			DoQuestCheckDelay("TalkSelf_Quest", 3.0);

		break;

		case "FB":
			//CharacterPlayAction(npchar, "Shot");
			NextDiag.CurrentNode = NextDiag.TempNode;
			dialog.text = "(Vous n'êtes pas blessée, mais on ne peut pas en dire autant de l'appareil que vous tenez. La balle touche le redresseur quantique de particules, après quoi l'appareil s'allume et se met à fonctionner de manière aléatoire, en émettant une série de crépitements et de cliquetis)";
			PlayVoice("interface\beeping.wav");
			link.l1 = "Diable !";
			link.l1.go = "FB_exit";
		break;
		case "FB_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			dialog.text = "(Vous n'êtes pas blessée, mais on ne peut pas en dire autant de l'appareil que vous tenez. La balle touche le redresseur quantique de particules, après quoi l'appareil s'allume et se met à fonctionner de manière aléatoire, en émettant une série de crépitements et de cliquetis)";
			link.l1 = "Diable !";
			link.l1.go = "exit";
			DoReloadCharacterToLocation("Ship_Deck_Big","goto","goto5");
			PChar.quest.WhisperTeleport.win_condition.l1 = "location";
			PChar.quest.WhisperTeleport.win_condition.l1.location = "Ship_Deck_Big";
			PChar.quest.WhisperTeleport.function = "WhisperTeleport";
		break;
		case "CS":
			dialog.text = "Ce n'est pas un jouet, ma petite. Tu ne peux même pas imaginer ce dont cet objet est capable. Repose-le, lentement et avec précaution.";
			link.l1 = "Tu parles du redresseur quantique de particules ?";
			link.l1.go = "CS_1";
		break;
		case "CS_1":
			dialog.text = "Tu te rends compte au moins de ce que tu viens de dire ?";
			link.l1 = "Pas vraiment...";
			link.l1.go = "CS_1_1";
			link.l2 = "Bien sמr ! Je ne suis pas idiote.";
			link.l2.go = "CS_1_2";
		break;
		case "CS_1_1":
			dialog.text = "Même si le nom n'est pas très parlant, cet appareil permet de se déplacer dans l'espace et dans le temps. Mais la moindre utilisation peut réécrire entièrement toute la séquence temporelle. Ni toi ni moi ne naîtrons peut-être jamais. Alors, tu ferais mieux de le remettre à sa place, à l'abri des ennuis.";
			link.l1 = "וcoute, mon vieux, je n'ai pas le temps de régler mes comptes avec toi. Le client attend.";
			link.l1.go = "CS_2";
		break;
		case "CS_1_2":
			dialog.text = "Eh bien, alors, tu dois comprendre pourquoi il ne faut pas y toucher.";
			link.l1 = "וcoute, mon vieux, je n'ai pas le temps de régler mes comptes avec toi. Le client attend.";
			link.l1.go = "CS_2";
		break;
		case "CS_2":
			dialog.text = "Un client ? Je ne connais qu'un seul client possible qui soit au courant de cet appareil. Alors, tu es la carpette des corpos ? Tu fais tout ce qu'on te dit ?! Je te mettrais bien mon poing dans la figure, mais on m'a appris depuis l'enfance qu'on ne frappe pas les femmes...";
			link.l1 = "Pas d'insultes, s'il te plaît. Je suis une mercenaire libre. Je n'accepte que les contrats que je choisis.";
			link.l1.go = "CS_2_1";
		break;
		case "CS_2_1":
			dialog.text = "C'est ce que tu crois. En réalité, toi comme nous tous, nous sommes pris à l'hameçon depuis longtemps. Je suppose que tu as contracté assez de prêts, et qu'on t'a proposé de les effacer ? Pas besoin de répondre. J'ai moi-même travaillé pour Omnitech, et j'ai vu de l'intérieur tout leur système pourri.";
			link.l1 = "Hum. Le contrat ne disait pas que le « savant fou » était l'un de leurs anciens employés.";
			link.l1.go = "CS_3";
		break;
		case "CS_3":
			dialog.text = "Quel surnom ! J'ai les idées plus claires que toi ! Ce sont les corporations qui m'ont fait mettre au point le truc que tu tiens entre les mains : les fous, ce sont eux ! C'est pour ça que j'ai décidé de le leur cacher.";
			link.l1 = "Alors, tu as volé cet appareil à Omnitech ?";
			link.l1.go = "CS_3_1";
		break;
		case "CS_3_1":
			dialog.text = "J'ai bien peur que le mot « volé » ne s'applique pas ici. C'est à cent pour cent ma création. Mais oui, selon leur loi esclavagiste, toute propriété intellectuelle développée par un employé d'une corporation sur le territoire de la corporation appartient à la corporation. Mais tu peux quand même me traiter de voleur. Quand j'ai pris la machine à remonter le temps, j'ai aussi reprogrammé une douzaine de bots de la corporation, que tu as peut-être croisés en venant ici.";
			link.l1 = "Pourquoi une corporation aurait-elle besoin d'une machine à remonter le temps ?";
			link.l1.go = "CS_4";
		break;
		case "CS_4":
			dialog.text = "Voilà que tu commences à poser les bonnes questions. Pour retourner dans le passé et asservir l'humanité encore plus vite ! Avec un tel atout en réserve, tout le temps du monde, ils deviendront sans peine les maîtres absolus de tout ce qui est imaginable et inimaginable, et notre avenir sera encore plus triste que ce qui se passe dans le monde aujourd'hui.";
			LAi_SetImmortal(npchar, false);
			link.l1 = "Je te comprends, vraiment. Mais personnellement, je me fiche de ce qui arrivera au reste de l'humanité. Et je serai payée pour ce contrat, que je doive enjamber ton cadavre ou non !";
			link.l1.go = "CS_bad";
			link.l2 = "Si ce truc fait vraiment ce que tu dis, alors il vaut peut-être mieux ne pas le donner aux corporations. Je lui trouverai un bien meilleur usage entre mes mains.";
			link.l2.go = "CS_neutral";
			link.l3 = "Bon sang, tu as raison... Soit, prends-le et va-t'en d'ici. Je dirai au client que tu t'es enfui.";
			link.l3.go = "CS_good";
		break;
		case "CS_bad":
			dialog.text = "Quelle ordure tu fais, quand même.";
			ChangeCharacterReputation(pchar, -100);
			LAi_tmpl_afraid_SetAfraidCharacter(npchar,pchar,false);
			link.l1 = "La ferme !";
			Link.l1.go = "ExitSC";
		break;
		case "CS_neutral":
			dialog.text = "La cupidité... Je comprends ce sentiment. Eh bien, je suis désarmé, et je ne peux pas t'arrêter.";
			link.l1 = "Là-dessus, tu as parfaitement raison. Adieu.";
			link.l1.go = "ExitSC";
		break;
		case "CS_good":
			dialog.text = "Finalement, tu n'es pas du tout la créature sans âme que je croyais au début. Mais tu ferais mieux de garder l'appareil. S'ils ont pu me retrouver même dans ce trou perdu, c'est sans doute qu'on m'a collé un traceur, d'une façon ou d'une autre. Il est trop tard pour le chercher maintenant, alors je n'ai guère de chances de m'enfuir. Toi, en revanche, tu as encore une chance.";
			ChangeCharacterReputation(pchar, 100);
			link.l1 = "C'est plus que ce pour quoi j'avais signé. Mais je ne peux pas refuser, l'enjeu est trop important. Je te promets que les corporations n'auront pas cet appareil.";
			link.l1.go = "CS_good_1";
		break;
		case "CS_good_1":
			dialog.text = "Sois juste prudente en sortant d'ici. Mes capteurs indiquent que tu n'as pas détruit tous les bots. Je ne pourrai pas les désactiver à distance, alors tu devras t'en occuper toi-même.";
			link.l1 = "Oui, au revoir.";
			link.l1.go = "ExitSC";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "ExitSC":
			LAi_LocationFightDisable(locLoad, true);
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetActorTypeNoGroup(npchar);
			DialogExit();
		break;

		case "exit_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			//LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			//LAi_SetImmortal(npchar, false);
			//LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();
		break;

		case "OrderHunter":
			chrDisableReloadToLocation = false;
			//Lai_SetPlayerType(pchar);
			if(!CheckAttribute(pchar,"OrderHunter"))
			{
				SetQuestHeader("TheLastMass");
				if (startherotype == 2)
				{
					sTemp = "Tu ne pensais quand même pas pouvoir tuer le chef de l'Inquisition et t'en tirer si facilement ?";
					AddQuestRecord("TheLastMass", "1");
				}
				else
				{
					sTemp = "L'Inquisition a été informée de tes atrocités !";
					AddQuestRecord("TheLastMass", "1_1");
				}
				pchar.OrderHunter = "1";
				Link.l1 = "L'inquisiteur ? Je te conseille de retourner dans ton trou sous l'église de Santiago. Allez, file pendant que je suis de bonne humeur !";
				Link.l1.go = "OrderHunterMeeting";
				if (WhisperIsHere())
				{
					Link.l1 = "...";
					Link.l1.go = "OrderHunterMeetingWhisperIsHere";
				}
			}
			else
			{
				sTemp = " ";

				Link.l1 = "Encore ? Bon, prépare-toi à monter au ciel.";
				Link.l1.go = "OrderHunterBattle";

				if(sti(PChar.OrderHunter) == 2) {AddQuestRecord("TheLastMass", "2");}

				if(sti(PChar.OrderHunter) == 3)
				{
					Link.l1 = "Tu sais, tu n'es pas le premier inquisiteur à me traquer. Je pense que tu devines ce qui est arrivé aux autres. Dis-moi oם se trouve votre base, et je te laisserai partir vivant.";
					Link.l1.go = "OrderHunterNegotiate";
				}
				if(sti(PChar.OrderHunter) > 3)
				{
					Link.l2 = "Eh, vous n'apprenez vraiment rien... Encore quelqu'un qui veut mourir ?";
					Link.l2.go = "OrderHunterCheck";
				}
			}
			dialog.text = GetFullName(PChar) + " !"+ sTemp + "Je te traque depuis longtemps, et maintenant, enfin, tu vas recevoir le châtiment que tu mérites.";
			if (WhisperIsHere())
			{
				dialog.text = dialog.text + "\nCette sorcière de Whisper est avec toi ? Mes frères seront ravis d'apprendre que j'ai débarrassé l'וglise de deux ennemis à la fois !"
			}
		break;

		case "OrderHunterNegotiateWhisperIsHere":
			pchar.PrevNpc = npchar.id;
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.WhisperPGG, "OrderHunterNegotiateWhisperIsHere_1", "Quest\WhisperLine\Whisper.c");
		break;

		case "OrderHunterNegotiateWhisperIsHere_1":
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			W_RestoreOfficerDialog();
			dialog.text = "Voilà qui m'intéresse. Il faut absolument que nous allions à ce récif du Squelette.";
            Link.l1 = "Eh bien, je tiens parole, tu peux partir.";
			Link.l1.go = "OrderHunterPeace";
			Link.l2 = "Merci pour l'information. Ne le prends pas personnellement, mais je ne peux pas te laisser partir vivant pour que tu ailles prévenir de ma visite.";
			Link.l2.go = "OrderHunterBattle";
		break;

		case "OrderHunterNegotiate":
			dialog.text = "Hum... Soit. Je ne sais pas ce que je vaux, mais don Julio Iglesias te battra à coup sמr. Notre maison du Chapitre se trouve sur le récif du Squelette, dans la baie des Damnés. C'est à quelques jours à l'est des Caïmans.";

            Link.l1 = "N'est-ce pas un lieu un peu trop profané pour de « pieux » serviteurs de l'וglise ?";
			Link.l1.go = "OrderHunterNegotiate_1";
		break;

		case "OrderHunterNegotiate_1":
			dialog.text = "La mauvaise réputation de ce récif le protège plus sמrement que n'importe quels murs et canons. Tout le monde l'évite.";
			if (WhisperIsHere())
			{
				Link.l1.go = "OrderHunterNegotiateWhisperIsHere";
			}
			else
			{
				Link.l1 = "Eh bien, je tiens parole, tu peux partir.";
				Link.l1.go = "OrderHunterPeace";
				Link.l2 = "Merci pour l'information. Ne le prends pas personnellement, mais je ne peux pas te laisser partir vivant pour que tu ailles prévenir de ma visite.";
				Link.l2.go = "OrderHunterBattle";
			}

			AddQuestRecord("TheLastMass", "3");
			CaptureCapitol_SeaBattle();
			pchar.quest.CaptureCapitol_SeaBattleStarted.win_condition.l1          = "location";
			pchar.quest.CaptureCapitol_SeaBattleStarted.win_condition.l1.location = "Reefs";
			pchar.quest.CaptureCapitol_SeaBattleStarted.function             = "CaptureCapitol_SeaBattleStarted";
		break;

		case "OrderHunterMeetingWhisperIsHere":
			pchar.PrevNpc = npchar.id;
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.WhisperPGG, "OrderHunterMeetingWhisperIsHere_1", "Quest\WhisperLine\Whisper.c");
		break;

		case "OrderHunterMeetingWhisperIsHere_1":
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			W_RestoreOfficerDialog();
			dialog.text = "Encore l'Inquisition ? J'en ai la nausée. Si ça ne te dérange pas, "+pchar.name+", rends-moi service et tue-le.";
            Link.l1 = "On devrait peut-être lui laisser une chance de revenir à la raison. Inquisiteur, je te conseille de retourner dans ton trou sous l'église de Santiago. Allez, file pendant que je suis de bonne humeur !";
			Link.l1.go = "OrderHunterMeetingWhisperIsHere_2";
		break;

		case "OrderHunterMeetingWhisperIsHere_2":
			StartInstantDialog(pchar.PrevNpc, "OrderHunterMeeting", "Quest\WhisperLine\Whisper.c");
		break;

		case "OrderHunterMeeting":
			dialog.text = "Santiago n'est plus notre résidence principale dans les Caraïbes. Don Julio Iglesias est arrivé d'Europe et a entrepris la construction d'une nouvelle maison du Chapitre. Et à la suite des récents événements, notre ordre a reçu un financement presque illimité et sa propre escadre de guerre.";
            Link.l1 = "Tiens donc ! Comme c'est intéressant... Et oם se trouve votre nouvelle capitale ?";
			Link.l1.go = "OrderHunterMeeting_1";
		break;

		case "OrderHunterMeeting_1":
			dialog.text = "Dans un lieu secret, et sous bonne garde.";
            Link.l1 = "Réponse attendue. Puisque tu es encore là, j'imagine que tu as hâte d'aller au ciel.";
			Link.l1.go = "OrderHunterBattle";
		break;

		case "OrderHunterCheck":
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) > rand(150))
            {
                dialog.text = "Je crois que je ne suis pas prêt à t'affronter aujourd'hui. Le Seigneur t'a accordé du temps pour te repentir de tes péchés.";
                Link.l1 = "Eh bien, fiche le camp.";
                Link.l1.go = "OrderHunterPeace";
				Link.l2 = "J'espère que tu t'es déjà repenti des tiens, parce qu'il ne te reste plus de temps.";
				Link.l2.go = "OrderHunterBattle";
                AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 100);
            }
            else
            {
                dialog.text = "Ce n'est pas avec ton verbiage impie que tu vas m'intimider !";
			    Link.l1 = "Alors, je vais te faire taire avec ma lame.";
			    Link.l1.go = "OrderHunterBattle";
			    AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 50);
            }
		break;

		case "OrderHunterPeace":
            PChar.OrderHunter = sti(PChar.OrderHunter)+1;
			AddDialogExitQuest("GoAway_Hunters_Land");
            DialogExit();
        break;

		case "OrderHunterBattle":
			PChar.OrderHunter = sti(PChar.OrderHunter)+1;
            AddDialogExitQuest("Battle_Hunters_Land");
            DialogExit();
        break;

		case "OrderLeader":
			LAi_SetActorType(npchar);
			dialog.text = "Je vois que tu as réussi à briser la vie de nombre de mes frères. Mais comme l'a dit le Seigneur : « Que revivent tes morts ! Que leurs cadavres se relèvent ! Réveillez-vous et poussez des cris de joie, vous qui habitez la poussière ! »";

            Link.l1 = "Qu'est-ce que c'est que cette diablerie ?";
			Link.l1.go = "OrderLeader_exit";
		break;

		case "OrderLeader_exit":
			LAi_ActorGoToLocation(npchar, "reload", "reload2", "none", "", "", "", -1);
			DoQuestFunctionDelay("CaptureCapitol_ShoreBattleRaiseUndead", 3.5);
			DialogExit();
		break;

		case "OrderLeader_1":
			dialog.text = "On m'a acculé comme une bête sauvage. Mais je ne deviendrai pas comme elle, je ne céderai pas à la peur ! Non ! Je ne désespère pas : s'il m'est donné d'entrer aujourd'hui au royaume des Cieux, qu'il en soit ainsi. Mais j'espère encore que le Seigneur me donnera la force de vaincre son ennemi.";

			if (WhisperIsHere())
			{
				Link.l1.go = "OrderLeaderWhisperIsHere";
			}
			else
			{
				Link.l1 = "Qu'est-ce que c'était, là-haut ? J'ai l'impression qu'après tes accointances avec les esprits impurs, l'ennemi de Dieu, c'est plutכt toi, pas moi, et que la route de l'Enfer t'est toute tracée.";
				Link.l1.go = "OrderLeader_2";
			}
		break;

		case "OrderLeaderWhisperIsHere":
			pchar.PrevNpc = npchar.id;
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.WhisperPGG, "OrderLeaderWhisperIsHere_1", "Quest\WhisperLine\Whisper.c");
		break;

		case "OrderLeaderWhisperIsHere_1":
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			W_RestoreOfficerDialog();
			dialog.text = "Alors, c'est lui qui était derrière tout ça... Un fanatique dérangé ? Pour être honnête, je suis un peu déçue.";
			Link.l1.go = "OrderLeaderWhisperIsHere_2";
		break;

		case "OrderLeaderWhisperIsHere_2":
			SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
			StartInstantDialogNoType(pchar.PrevNpc, "OrderLeaderWhisperIsHere_3", "Quest\WhisperLine\Whisper.c");
		break;

		case "OrderLeaderWhisperIsHere_3":
			dialog.text = "N'est-ce pas toi, Whisper ? J'ai beaucoup entendu parler des déboires que tu as causés à mon frère, Antonio de Souza. Je pense qu'il serait heureux d'apprendre que je t'ai enfin envoyée en enfer, sorcière !";
			Link.l1 = "Qu'est-ce que c'était, là-haut ? J'ai l'impression qu'après tes accointances avec les esprits impurs, l'ennemi de Dieu, c'est plutכt toi, pas nous, et que ta route mène tout droit en Enfer.";
			Link.l1.go = "OrderLeader_2";
		break;

		case "OrderLeader_2":
			dialog.text = "Regarde l'icכne derrière moi. Saint Georges le Victorieux terrassant le dragon. Elle est belle, n'est-ce pas ? Je l'ai longuement contemplée, et je me suis demandé : et si l'on ne tuait pas le dragon, mais qu'on l'apprivoisait ? Comme l'homme apprivoise l'agneau et les autres créatures. Et ainsi, un jour, j'ai trouvé un moyen. Autrefois, ces gens étaient des serviteurs des ténèbres, mais j'ai réussi à dompter les forces de cette île maudite et à les mettre au service du bien. J'en ai fait des instruments entre les mains du Seigneur !";
            Link.l1 = "Au service de tes désirs pervers ? Je ne sais pas comment tu as fait, et je ne veux pas le savoir. Il y avait des âmes humaines dans ces corps pourrissants ! Au lieu de les libérer, tu les as laissées souffrir et se soumettre à tes caprices. Je ne pense pas que Dieu aurait apprécié. Mais maintenant, c'est fini, elles ont trouvé la paix.";
			Link.l1.go = "OrderLeader_3";
		break;

		case "OrderLeader_3":
			dialog.text = "Tu ne comprends pas, tout cela a été entrepris pour un plus grand bien. Quand mes efforts porteront leurs fruits, le Seigneur me pardonnera. Et peu importe que les gardiens de la grotte soient morts : toi et tes hommes, vous prendrez leur place !";

            Link.l1 = "דa m'étonnerait.";
			Link.l1.go = "OrderLeader_fight";
			if (startherotype == 2)
			{
				Link.l1 = "Ce ne serait pas mon fusil, par hasard, à ta ceinture ?";
				Link.l1.go = "OrderLeader_4";
			}
		break;

		case "OrderLeader_4":
			dialog.text = "Ah, tu l'as remarqué. J'ai trouvé cette arme parmi les documents du bureau de de Souza quand j'ai pris sa place. Tu dis que cette chose est à toi ? Je dois avouer que j'admire ce mécanisme : les pécheurs tombent par dizaines à chaque coup. Je pense que tu le sais toi-même. Et bientכt, tu vas même en faire l'expérience.";

            Link.l1 = "Raison de plus pour te tuer au plus vite !";
			Link.l1.go = "OrderLeader_fight";
		break;

		case "OrderLeader_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			DialogExit();
			CaptureCapitol_OnLeaderDeath();
			LAi_LocationFightDisable(locLoad, false);
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "CaptureCapitol");
			for (int j=1; j<=6; j++)
			{
				sld = CharacterFromID("MaltGuard_"+j);
				LAi_group_MoveCharacter(sld, "CaptureCapitol");
				ChangeCharacterAddressGroup(sld, pchar.location, "goto", "goto5");
			}

			LAi_group_SetHearRadius("CaptureCapitol", 100.0);
			LAi_group_FightGroupsEx("CaptureCapitol", LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
		break;

		case "CapitolCaptured":
			chrDisableReloadToLocation = false;
			pchar.quest.CaptureCapitol_Decision.win_condition.l1          = "location";
			pchar.quest.CaptureCapitol_Decision.win_condition.l1.location = "DeckWithReefs";
			pchar.quest.CaptureCapitol_Decision.function             = "CaptureCapitol_Decision";

			dialog.text = "Quel massacre, je n'ai jamais vu autant de cadavres de ma vie ! On les a bien arrangés, hein, capitaine ?";
            Link.l1 = "« On » ? Je ne me souviens pas de t'avoir vu parmi les combattants.";
			Link.l1.go = "CapitolCaptured_1";
		break;
		case "CapitolCaptured_1":
			dialog.text = "Ben, je défendais nos arrières, au cas oם ils essaieraient de nous encercler. Ne vous fâchez pas, capitaine, j'ai de quoi vous faire plaisir ! Pendant que, hum... je défendais les autres salles, j'ai pu les inspecter un peu. Il y a tout un entrepכt d'armes de toutes sortes, des tonnes de provisions, et le plus intéressant, c'est que j'ai trouvé une bibliothèque remplie de livres sur l'art militaire. On dirait que l'Inquisition comptait former ici sa propre armée.";

            Link.l1 = "Je me demande ce qu'on peut faire de tout ça. Le vendre à quelqu'un ?";
			Link.l1.go = "CapitolCaptured_2";
		break;
		case "CapitolCaptured_2":
			dialog.text = "On peut vendre, mais on peut aussi... C'est peut-être idiot, mais je pense qu'on pourrait se servir de cet endroit pour entraîner et entretenir notre propre armée ? Enfin, peut-être pas toute une armée, mais vous pourriez laisser vos officiers ici pour qu'ils gagnent de l'expérience.";

            Link.l1 = "Tu as raison, c'est idiot. On va tout vendre, et on n'en parlera plus.";
			Link.l1.go = "CapitolCaptured_3";
			Link.l2 = "On peut essayer. Ayons notre propre base, au cas oם.";
			Link.l2.go = "CapitolCaptured_4";
		break;
		case "CapitolCaptured_3":
			dialog.text = "D'accord. Alors, je vais vite dresser la liste de tout ce qu'il y a ici, et vous chercherez un acheteur.";

            Link.l1 = "Je pense que les usuriers seront trop heureux de récupérer tout ce bric-à-brac.";
			Link.l1.go = "CapitolCaptured_sell";
			Link.l2 = "Quoique... Gardons quand même cet endroit pour nous.";
			Link.l2.go = "CapitolCaptured_4";
		break
		case "CapitolCaptured_4":
			dialog.text = "Excellente idée, capitaine !";

            Link.l1 = "Reste ici et prends le commandement. Emmène quelques hommes avec toi. Tu feras un rat d'état-major : de toute façon, au combat, tu ne sers à rien.";
			Link.l1.go = "CapitolCaptured_keep";
		break;

		case "CapitolCaptured_keep":
			dialog.text = "Merci, capitaine ! Je ne vous décevrai pas.";
            Link.l1 = "On verra.";
			Link.l1.go = "exit";
		break;

		case "CapitolCaptured_sell":
			pchar.SellCapitol = true;
			DialogExit();
			if (CheckAttribute(pchar, "WhisperChSpokeToUsurer"))
			{
				AddQuestRecord("WhisperChinamanRelic", "4");
			}
		break;

		case "Beatrice":
			dialog.text = "On ne voit pas souvent de filles par ici. Vous aussi, vous comptez vous faire engager comme officier sur un navire ? Je ne vous conseille pas de tenter votre chance ici : les pirates du coin n'attendent qu'une chose de nous, et ce n'est pas du tout la connaissance des choses de la mer.";
            Link.l1 = "Je m'en souviendrai.";
			Link.l1.go = "exit";
			npchar.MetWhisper = true;
		break;

		case "Hugo_Lesopilka":
			dialog.text = "Ressers-moi donc, ma petite.";
            Link.l1 = "Je ne suis pas ta serveuse !";
			Link.l1.go = "exit";
		break;

		//Реакции
		case "WhisperIsHere_exit":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
		break;

		case "BS_WhisperIsHere":
			dialog.text = "On va encore devoir se battre contre l'Espagne ? Bah, j'ai l'habitude.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_1_WhisperIsHere":
			dialog.text = "Le petit oiseau ? Tu parles de Maxine ?";
			Link.l1 = "Oui. J'espère qu'elle est encore à Port Royal.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_2_WhisperIsHere":
			dialog.text = "On dirait qu'il ne reste pas grand-chose du « Ranger »...";
			Link.l1 = "Allons à Fort Orange. Les ivrognes du coin ont peut-être vu ce qui s'est passé ici.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_3_WhisperIsHere":
			dialog.text = "« Garde tes amis près de toi, et tes ennemis plus près encore. » Elle me plaît, cette Guthrie !";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_4_WhisperIsHere":
			dialog.text = "א mon avis, Anne a bien fait. Pas besoin de témoins dans notre affaire.";
			Link.l1 = "Je suppose que vous avez raison.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_5_WhisperIsHere":
			dialog.text = "J'ai un mauvais pressentiment. Reste sur tes gardes.";
			Link.l1 = "De quoi tu parles ? C'est fait, on peut enfin se détendre.";
			Link.l1.go = "BS_5_WhisperIsHere_1";
		break;

		case "BS_5_WhisperIsHere_1":
			dialog.text = "Se détendre, avec cent cinquante millions en jeu ? Dans des moments pareils, il faut être plus vigilant que jamais !";
			Link.l1 = "Ne t'énerve pas comme ça. Il ne va rien se passer.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_6_WhisperIsHere_1":
			dialog.text = "Oh, que je me sens mal... Je ne veux pas te faire de reproches, mais je t'avais dit de faire attention. Bon sang, je pensais que tu savais ce que tu faisais, et toi aussi, tu as bu ce poison.";
			Link.l1 = "Pardon, ça a été un peu inattendu, même pour moi. C'est Flint qui nous a empoisonnés ? Comment vont les autres ?";
			Link.l1.go = "BS_6_WhisperIsHere_2";
		break;

		case "BS_6_WhisperIsHere_2":
			dialog.text = "Je n'en sais pas plus que toi, je me suis réveillée il y a une demi-heure.";
			Link.l1 = "Bon, descendons. Quelqu'un à la taverne a peut-être entendu quelque chose.";
			Link.l1.go = "BS_6_WhisperIsHere_3";
		break;

		case "BS_6_WhisperIsHere_3":
			dialog.text = "Seulement, ne te presse pas, j'ai encore la tête qui tourne.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_7_WhisperIsHere":
			dialog.text = "Eh bien, il vous a bien roulés, ce Flint.";
			Link.l1 = "Il nous a tous roulés. Toi compris, puisque nous sommes associés.";
			Link.l1.go = "BS_7_WhisperIsHere_1";
		break;

		case "BS_7_WhisperIsHere_1":
			dialog.text = "Tu as raison, et j'ai hâte de lui casser la figure.";
			Link.l1 = "Moi aussi, mais seulement après qu'il nous aura expliqué pourquoi il a fait ça.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_8_WhisperIsHere":
			dialog.text = "« Ne vous montrez pas » ? Tu n'as pas peur qu'on se fasse massacrer là-bas pendant que Vane se terre ?";
			Link.l1 = "Toi et moi, on en a vu de toutes les couleurs. Tu as peur d'une misérable embuscade ?";
			Link.l1.go = "BS_8_WhisperIsHere_1";
		break;

		case "BS_8_WhisperIsHere_1":
			dialog.text = "Tu as raison. Alors, montre le chemin.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_9_WhisperIsHere":
			dialog.text = "Ne la mettons pas en colère. Il ne nous manquait plus qu'un ennemi de plus...";
			Link.l1.go = "BS_9_WhisperIsHere_1";
		break;

		case "BS_9_WhisperIsHere_1":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			StartInstantDialogNoType("Pirates_trader", "BS_NPVK_6_1", "Quest\BlackSails\NePluyjVKolodec.c");
		break;

		case "BS_10_WhisperIsHere":
			dialog.text = "Quoique... Ce serait sans doute plus simple de la tuer.";
			Link.l1.go = "BS_10_WhisperIsHere_1";
		break;

		case "BS_10_WhisperIsHere_1":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			StartInstantDialogNoType("Pirates_trader", "BS_NPVK_7_1", "Quest\BlackSails\NePluyjVKolodec.c");
		break;

		case "BS_11_WhisperIsHere":
			dialog.text = "Ces allées et venues sans but me fatiguent vraiment.";
			Link.l1 = "Moi aussi. Mais je sens que Silver est quelque part par ici. Retournons voir à la prison.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_12_WhisperIsHere":
			dialog.text = "דa, c'était une bagarre ! J'en ai même un peu transpiré.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_13_WhisperIsHere":
			dialog.text = "Qu'est-ce que tu vas faire de ta part ?";
			Link.l1 = "Je ne sais pas. Je pense arrêter la piraterie. Peut-être que je rebâtirai une colonie ou deux. Et toi ?";
			Link.l1.go = "BS_13_WhisperIsHere_1";
		break;

		case "BS_13_WhisperIsHere_1":
			dialog.text = "Je veux rentrer dans mon pays. L'argent m'y aidera peut-être.";
			Link.l1 = "C'est vraiment si cher ? Embarque comme passagère sur n'importe quel navire de passage, et en route !";
			Link.l1.go = "BS_13_WhisperIsHere_2";
		break;

		case "BS_13_WhisperIsHere_2":
			dialog.text = "Mon pays est très loin. J'ai bien peur que les navires n'y aillent pas.";
			Link.l1 = "Tu parles encore par énigmes. Bon, allons-y. Je pense que Silver a fini.";
			Link.l1.go = "BS_13_WhisperIsHere_3";
		break;

		case "BS_13_WhisperIsHere_3":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_SetPlayerType(pchar);
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			ChangeCharacterAddressGroup(npchar, "Pirates_tavern", "goto", "goto2");
			BSHangover_Cutscene_2("");
		break;

		case "BS_14_WhisperIsHere_1":
			dialog.text = "Eh... On dirait que nos rêves ne se réaliseront pas.";
			Link.l1 = "On dirait bien. Mais au moins, tu ne vas pas encore me quitter pour ton pays. J'ai pris l'habitude de t'avoir à mes cכtés, tu sais.";
			Link.l1.go = "BS_14_WhisperIsHere_2";
		break;

		case "BS_14_WhisperIsHere_2":
			dialog.text = "Oh, ne me fais pas rougir.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_15_WhisperIsHere":
			dialog.text = "Il va courir encore longtemps ?";
			Link.l1 = "Jusqu'à ce qu'il nous mène à son navire, j'imagine.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_16_WhisperIsHere":
			dialog.text = "Voilà le navire. On dirait que tu avais raison.";
			Link.l1 = "J'ai toujours raison.";
			Link.l1.go = "BS_16_WhisperIsHere_1";
		break;

		case "BS_16_WhisperIsHere_1":
			dialog.text = "Je pourrais discuter là-dessus, mais bon.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_17_WhisperIsHere":
			dialog.text = "Regardez, on a de la visite !";
			Link.l1.go = "BS_17_WhisperIsHere_1";
		break;

		case "BS_17_WhisperIsHere_1":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			StartInstantDialogNoType("Flint", "BS_PN_8_1", "Quest\BlackSails\Pogonya_Nachalas.c");
		break;

		case "BS_18_WhisperIsHere":
			dialog.text = "On dirait qu'on nous a refilé le boulot le plus « sale ».";
			Link.l1 = "Au revoir.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_19_WhisperIsHere":
			dialog.text = "Sortons prendre l'air. J'ai eu ma dose de souterrains pour aujourd'hui.";
			Link.l1 = "Oui, allons-y.";
			Link.l1.go = "WhisperIsHere_exit";
		break;

		case "BS_20_WhisperIsHere":
			dialog.text = "Je ne me sens pas bien...";
			Link.l1.go = "BS_20_WhisperIsHere_1";
		break;

		case "BS_20_WhisperIsHere_1":
			DialogExit();
			W_RestoreOfficerDialog();
			LAi_tmpl_SetFollow(npchar, GetMainCharacter(), -1.0);
			SetCharacterTask_Dead(npchar);
			DoQuestFunctionDelay("BSUrka_PoisonOfficers", 1);
			DoQuestFunctionDelay("BSUrka_PoisonSelf", 3.0);
			DoQuestFunctionDelay("BSUrka_Poison_Flint", 6.0);
		break;

		// <- Реакции
	}
}
