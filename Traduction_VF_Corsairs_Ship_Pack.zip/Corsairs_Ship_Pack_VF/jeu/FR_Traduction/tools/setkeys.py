# -*- coding: utf-8 -*-
"""Force the french value of specific text keys in the TM (after an import propagated duplicates).

usage: python -X utf8 setkeys.py <overrides.txt>
lines: <file><TAB><key><TAB><french>      (file = e.g. AddRumours.txt ; '#' starts a comment line)
       <file><TAB><key><TAB>=             (keep the english text)
"""
import os
import sys

sys.argv, _args = sys.argv[:1], sys.argv[1:]
import fr  # noqa: E402


def main(path):
    n = 0
    tms = {}
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\r\n')
        if not line.strip() or line.startswith('#'):
            continue
        f, k, v = line.split('\t', 2)
        en = dict(fr.text_units(f))
        if k not in en:
            print('  ! cle inconnue :', f, k)
            continue
        tm = tms.setdefault(f, fr.tm_text(f))
        tm[k] = en[k] if v.strip() == '=' else v
        n += 1
    for f, tm in tms.items():
        fr.jsave(os.path.join(fr.TM_DIR, 'texts', f + '.json'), tm)
    print('cles forcees :', n)


if __name__ == '__main__':
    main(_args[0])
