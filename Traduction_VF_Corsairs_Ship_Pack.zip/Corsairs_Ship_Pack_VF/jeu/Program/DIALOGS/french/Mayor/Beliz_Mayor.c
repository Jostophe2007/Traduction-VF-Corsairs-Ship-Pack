// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_ONV_VedmaKaznena"))	//Квест "The witch hunt.". Ведьма казнена
			{
				link.l1 = "Je vous rappelle que vous m'aviez demandé de livrer à la justice une femme liée au meurtre de votre secrétaire, Bartholomew Ulster.");
				link.l1.go = "PDM_ONV_VedmaKaznena";
			}
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;
		//************************** Квестовые штрумы ************************
       //==> Третий квест англ.линейки: нападение на Белиз.
        case "EngLine3Quest_BelizAttack":
			dialog.text = "Bon sang !!! Que vous faut-il"+ GetSexPhrase(", maudit ladron ", " ") +" ?!!";
			link.l1 = "Je vous le donne en mille.";
			link.l1.go = "Step_E3_1";
			AfterTownBattle();
        break;

        case "Step_E3_1":
            dialog.text = "L'or...";
			link.l1 = "Vous voyez, vous savez tout vous-même. Nous prenons l'or et nous partons, et vous restez en vie... à une condition.";
			link.l1.go = "Step_E3_2";
        break;

        case "Step_E3_2":
            dialog.text = "Quelle condition ?";
			link.l1 = "Vous allez me dire oם est caché l'or prêt à être expédié en Espagne.";
			link.l1.go = "Step_E3_3";
        break;

        case "Step_E3_3":
            dialog.text = "Et si je ne vous le dis pas ?";
			link.l1 = "Hum, d'abord, vous aurez très peur, ensuite, vous aurez très mal. Et puis vous me direz tout, mais vous ne pourrez plus vivre après tout ça : votre corps sera couvert de très graves blessures...";
			link.l1.go = "Step_E3_4";
        break;

        case "Step_E3_4":
            dialog.text = "Je ne doute pas une seconde que tout cela sera mis à exécution. J'en ai entendu parler..\n"+
                          "L'or est dans le fort. Fouillez-le bien, et vous le trouverez sans difficulté.";
			link.l1 = "Vous venez de sauver votre vie et votre santé. Félicitations, et je vous souhaite de rester en bonne santé à l'avenir, señor.";
			link.l1.go = "Step_E3_5";
        break;

        case "Step_E3_5":
            NextDiag.CurrentNode = "Cupture_after";
			DialogExit();
			SetReturn_Gover_Dialog_Exit(NPChar);
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_GrabbingTown", 1);
			LAi_LoginInCaptureTown(&characters[GetCharacterIndex("Henry Morgan")], true);
			LAi_LoginInCaptureTown(&characters[GetCharacterIndex("Jackman")], true);
			LAi_LoginInCaptureTown(&characters[GetCharacterIndex("John Morris")], true);
            DoReloadCharacterToLocation("Beliz_fort",  "goto", "goto61");
            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Henry Morgan")], "Beliz_fort", "goto", "goto13");
			LAi_SetStayType(characterFromID("Henry Morgan"));
			QuestSetCurrentNode("Henry Morgan", "Gold_found_in_fort"); // Gregg: через арбитраж хаба
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Jackman"))   // Эта фигня нужна для определения, взял ли ГГ этих перцев на дело. Если нет, то и их в форте не будет.
            {
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Jackman")], "Beliz_fort", "goto", "goto72");
                LAi_SetStayType(characterFromID("Jackman"));
                QuestSetCurrentNode("Jackman", "Gold_found_in_fort"); // Gregg: через арбитраж хаба
            }
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Morris"))
            {
                ChangeCharacterAddressGroup(&characters[GetCharacterIndex("John Morris")], "Beliz_fort", "goto", "goto01");
                LAi_SetStayType(characterFromID("John Morris"));
                characters[GetCharacterIndex("John Morris")].dialog.currentnode = "Gold_found_in_fort";
            }
            LAi_LocationFightDisable(&Locations[FindLocation("Beliz_fort")], true);
            // ==> Делёж золота. Можно не брать Джекмена и Джона Морриса вообще в эскадру.
            // === Квест будет выполнен, а золото поделено соответственно.
            pchar.questTemp.BelizGoldQty = 3300 / sti(pchar.questTemp.CompanionQuantity);   // Нужно для контроля продаж золота Моргану, чтоб не продавать возможно уже существующее у ГГ золото.
			// грузим ГГ и его эскадру (не квестовые)
            SetCharacterGoods(pchar, GOOD_GOLD, GetCargoGoods(pchar, GOOD_GOLD) + sti(pchar.questTemp.BelizGoldQty));// перегруз
            if (IsCompanion(characterFromID("Henry Morgan")))   {AddCharacterGoodsSimple(characterFromID("Henry Morgan"), GOOD_GOLD, sti(pchar.questTemp.BelizGoldQty));}
            if (IsCompanion(characterFromID("Jackman")))        {AddCharacterGoodsSimple(characterFromID("Jackman"), GOOD_GOLD, sti(pchar.questTemp.BelizGoldQty));}
            if (IsCompanion(characterFromID("John Morris")))    {AddCharacterGoodsSimple(characterFromID("John Morris"), GOOD_GOLD, sti(pchar.questTemp.BelizGoldQty));}
            Log_SetStringToLog("L'or espagnol est chargé dans les cales des navires.");
            InterfaceStates.Buttons.Save.enable = false;
            chrDisableReloadToLocation = true;
        break;
		
//********************** //Квест "The witch hunt.". Ведьма казнена ************************
		case "PDM_ONV_VedmaKaznena":
            dialog.text = "Ah oui, j'ai reçu une lettre du père Antonio de Souza au sujet de cette créature diabolique et de son sort. Vous avez bien agi, capitaine. Je vous remercie du fond du cœur pour votre aide dans cette affaire. J'imagine qu'il n'a pas été si facile de la trouver. Je vous offre une modeste rétribution de 50 000 escudos en témoignage de ma gratitude.";
            link.l1 = "Merci, monsieur le gouverneur. Au revoir !";
            link.l1.go = "PDM_ONV_Nagrada";
			AddMoneyToCharacter(pchar, 50000);
        break;

		case "PDM_ONV_Nagrada":
			AddQuestRecord("PDM_Ohota_na_vedmu", "15");
			AddQuestUserData("PDM_Ohota_na_vedmu", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Ohota_na_vedmu");
            pchar.questdata.OhotaNaVedmu = 1;
			DeleteAttribute(pchar, "questTemp.PDM_ONV_VedmaKaznena");
			AddCharacterExpToSkill(pchar, "Leadership", 300);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, SPAIN, 10);
			AddSimpleRumour("Capitaine, on dit que vous avez réussi à attraper la sorcière Maria Carle ! C'est vraiment vrai ?! Incroyable !!", SPAIN, 7, 1);

            DialogExit();
        break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

