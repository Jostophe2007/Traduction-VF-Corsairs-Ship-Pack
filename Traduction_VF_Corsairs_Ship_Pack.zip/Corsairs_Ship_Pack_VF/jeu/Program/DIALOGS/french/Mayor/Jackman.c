// Джекмен в Шарп-Тауне
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	string sLoc;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
            switch (npchar.angry.kind) //сюда расписываем реакцию ангри. В npchar.angry.name пробелы удалены!!!
            {
                case "repeat":
                    if (npchar.angry.name == "Firsttime") Dialog.CurrentNode = "AngryRepeat_1";
                    if (npchar.angry.name == "I_know_you_good") Dialog.CurrentNode = "AngryRepeat_2";
					if (npchar.angry.name == "BlueBird_1") Dialog.CurrentNode = "AngryRepeat_1";
                break;
            }
        }
    }
	
	if (!CheckAttribute(NPChar,"AbelQuestLetter") && CheckCharacterItem(pchar,"letter_1") && Items[GetItemIndex("letter_1")].describe == "itmdescr_Andre_Abel_Quest_Letter_2")
	{
		Dialog.CurrentNode = "Andre_Abel_Quest_Jackman_Dialog_7";
		NPChar.AbelQuestLetter = true;
	}
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================

	// Gregg: диспетчер отложенных докладов хаба — Джекман тоже общий для линий
	// (Орион / англ. / гол. / фр.), выдаём доклады по одному, когда он свободен;
	// если же узлом владеет линия, у которой в очереди лежит её более свежая
	// нода — отдаём её (внутрилинейный догон). HubReportPark в QuestsUtilite.c.
	if (!CheckAttribute(NPChar, "angry"))
	{
		string _hubRep = "";
		if (HubIsIdleNode("Jackman", Dialog.CurrentNode))
		{
			_hubRep = HubReportServe("Jackman");
			if (_hubRep == "") NPChar.dialog.hubActiveKey = "";
		}
		else
		{
			_hubRep = HubReportServeKey("Jackman", HubNodeKey(Dialog.CurrentNode));
		}
		if (_hubRep != "")
		{
			Dialog.CurrentNode = _hubRep;
			NextDiag.CurrentNode = _hubRep;
		}
	}
	switch(Dialog.CurrentNode)
	{
		case "First time":
			if(NPChar.quest.meeting == "0")		//Самый первый диалог
			{
				dialog.text = "Aha ! "  + GetFullName(pchar)+" ! Je savais que vous finiriez par vous montrer ! Qu'est-ce qui a bien pu vous amener ?";
				NPChar.quest.meeting = "1";
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue7_Jackman"))	//Sinistra Пролог Анжелика тич
				{
					dialog.text = "Bon, bon... La rumeur dit qu'une certaine usurpatrice est apparue dans l'archipel et que, cachée sous un faux nom, elle s'est mise à faire des affaires.";
					link.l1 = "Angelica Teach est mon vrai nom.";
					link.l1.go = "ATpr_F1";
					break;
				}
				if (!CheckAttribute(pchar, "questTemp.Vstuplenie_v_Bratstvo"))
				{
					link.l14 = "Je ne suis pas venue ici sans raison. On m'a dit que vous aviez besoin de moi.";
					link.l14.go = "Vstuplenie_v_Bratstvo_1";
				}
				if (CheckAttribute(pchar, "questTemp.Jackman_Zadanie"))
				{
					link.l14 = "Jackman, je cherche du travail ici...";
					link.l14.go = "Jackman_Zadanie";
				}
				// Gregg: «Чёрная Орхидея», глава 5 - награда за Левинсона, узлы BO_Jackman_*.
				// Атрибута может не быть вовсе, потому отдельная проверка: короткого замыкания в Storm нет.
				if (CheckAttribute(PChar, "DestinyGift"))
				{
					if (PChar.DestinyGift == "22")
					{
						link.l20 = "Je viens chercher la récompense. Frederik Levinson est mort.";
						link.l20.go = "BO_Jackman_1";
					}
				}
						// Gregg: «Чёрная Орхидея», глава 7 - покупка «Маленького ублюдка»
						if (CheckAttribute(PChar, "SmallMongrel"))
						{
							if (PChar.SmallMongrel == "4")
							{
								link.l21 = "Jackman, je veux vous acheter le Little Mongrel.";
								link.l21.go = "BO_SM_Jackman_1";
							}
						}
				link.l89 = "J'ai une question pour vous, Jackman.";
				link.l89.go = "Vopros";
				link.l99 = HeroStringReactionRepeat("Euh, j'ai oublié pourquoi je venais vous voir. Mais si je m'en souviens, je reviendrai. א plus tard, Jackman.",
												   "Bien sמr, Jackman. Je m'en vais déjà.",
												   "Désolé, Jackman. Je m'en vais déjà.",
												   "Oh...", npchar, Dialog.CurrentNode);
				link.l99.go = "exit";
			}
			else							//Уже знакомы
			{
				dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Vous avez une affaire pour moi ? Non ? Alors fichez le camp !","Ha, " + pchar.name + " ! Vous avez affaire à moi ? Non ? Alors ne me distrayez pas.") +"",
							 "Je crois avoir été clair.", "J'ai pourtant été clair, mais vous continuez à me distraire !",
							 "Bon, ça commence à ressembler à de l'insolence, et ça me fatigue.", "repeat", 3, npchar, Dialog.CurrentNode);
				NextDiag.TempNode = "First time";
				if (!CheckAttribute(pchar, "questTemp.Vstuplenie_v_Bratstvo"))
				{
					link.l14 = "Je ne suis pas venue ici sans raison. On m'a dit que vous aviez besoin de moi.";
					link.l14.go = "Vstuplenie_v_Bratstvo_1";
				}
				if (CheckAttribute(pchar, "questTemp.Jackman_Zadanie"))
				{
					link.l14 = "Jackman, je cherche du travail ici...";
					link.l14.go = "Jackman_Zadanie";
				}
				// Gregg: «Чёрная Орхидея», глава 5 - награда за Левинсона, узлы BO_Jackman_*.
				// Атрибута может не быть вовсе, потому отдельная проверка: короткого замыкания в Storm нет.
				if (CheckAttribute(PChar, "DestinyGift"))
				{
					if (PChar.DestinyGift == "22")
					{
						link.l20 = "Je viens chercher la récompense. Frederik Levinson est mort.";
						link.l20.go = "BO_Jackman_1";
					}
				}
						// Gregg: «Чёрная Орхидея», глава 7 - покупка «Маленького ублюдка»
						if (CheckAttribute(PChar, "SmallMongrel"))
						{
							if (PChar.SmallMongrel == "4")
							{
								link.l21 = "Jackman, je veux vous acheter le Little Mongrel.";
								link.l21.go = "BO_SM_Jackman_1";
							}
						}
				link.l89 = "J'ai une question pour vous, Jackman.";
				link.l89.go = "Vopros";
				link.l99 = HeroStringReactionRepeat("Euh, j'ai oublié pourquoi je venais vous voir. Mais si je m'en souviens, je reviendrai. א plus tard, Jackman.",
												   "Bien sמr, Jackman. Je m'en vais déjà.",
												   "Désolé, Jackman. Je m'en vais déjà.",
												   "Oh...", npchar, Dialog.CurrentNode);
				link.l99.go = "exit";
			}
		break;
		
		case "I_know_you_good":			//Очень хорошо друг друга знаем
            dialog.text = NPCStringReactionRepeat(GetFullName(pchar) + ", content de vous voir ! Qu'est-ce qui vous amène ?",
                         "Eh bien, que voulez-vous encore ?", "Combien de temps ça va durer ? Si vous n'avez rien à faire, ne dérangez pas les autres !",
                         "Vous êtes "+ GetSexPhrase("un bon corsaire","une brave fille") +", alors vivez pour l'instant. Mais je ne veux plus avoir affaire à vous ni vous parler.", "repeat", 1, npchar, Dialog.CurrentNode);
			if (!CheckAttribute(pchar, "questTemp.Vstuplenie_v_Bratstvo"))
			{
				link.l14 = "Je ne suis pas venue ici sans raison. On m'a dit que vous aviez besoin de moi.";
				link.l14.go = "Vstuplenie_v_Bratstvo_1";
			}
			if (CheckAttribute(pchar, "questTemp.Jackman_Zadanie"))
			{
				link.l14 = "Jackman, je cherche du travail ici...";
				link.l14.go = "Jackman_Zadanie";
			}
			// Gregg: «Чёрная Орхидея», глава 5 - награда за Левинсона, узлы BO_Jackman_*.
			// Атрибута может не быть вовсе, потому отдельная проверка: короткого замыкания в Storm нет.
			if (CheckAttribute(PChar, "DestinyGift"))
			{
				if (PChar.DestinyGift == "22")
				{
					link.l20 = "Je viens chercher la récompense. Frederik Levinson est mort.";
					link.l20.go = "BO_Jackman_1";
				}
			}
					// Gregg: «Чёрная Орхидея», глава 7 - покупка «Маленького ублюдка»
					if (CheckAttribute(PChar, "SmallMongrel"))
					{
						if (PChar.SmallMongrel == "4")
						{
							link.l21 = "Jackman, je veux vous acheter le Little Mongrel.";
							link.l21.go = "BO_SM_Jackman_1";
						}
					}
			link.l89 = "J'ai une question pour vous, Jackman.";
			link.l89.go = "Vopros";
			link.l99 = HeroStringReactionRepeat("Oui, en fait, je passais juste voir. Rien de spécial.",
                                               "Rien, comme ça...",
                                               "D'accord, Jackman, désolé...",
                                               "Bon sang, je l'ai bien cherché !!!", npchar, Dialog.CurrentNode);
			link.l99.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
		break;

 		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;
		case "Jackman_Zadanie":		//Здесь берём пиратские задания
			dialog.text = "Je n'ai pas de mission pour vous en ce moment.";
			link.l1 = "D'accord, Jackman, je reviendrai plus tard.";
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "begin" && !CheckAttribute(pchar, "QuestTemp.AndreAbelQuest"))	//Начало Пиратской Линейки: Найти Гудли
			{
				if(CheckAttribute(NPChar, "notQuestLine"))
				{
					dialog.text = "Le bruit court que vous êtes très bien vu des autorités anglaises. La lettre de marque ne rapporte plus rien ?! Je ne travaillerai pas avec vous : le risque d'être pendu à cause de vos affaires est trop grand. Ne demandez pas...";
					link.l1 = "Compris... Oui, en fait, je demandais juste. א tout hasard...";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Je n'ai pas de travail. Mais si vous n'avez rien à faire, allez à Puerto Príncipe et cherchez-y le capitaine Goodley. Il a presque toujours quelque chose.";
					link.l1 = "Quel genre de travail a-t-il ?";
					link.l1.go = "PL_Q1_2";
					//LockQuestLine(characterFromId("eng_guber")); // лочим английскую линейку
				}
			}
			if(sti(pchar.rank) >= 10 && !CheckAttribute(PChar, "questTemp.pirateVikingQuest"))	//Квест Осколок Прошлого
			{
				dialog.text = "J'ai du travail pour vous. On me dit que vous savez vous servir non seulement de votre épée, mais aussi de votre tête. וcoutez. Un Scandinave est apparu dans nos eaux il y a deux ou trois ans, un Danois ou un Suédois, peu importe. Il se fait appeler Ragnar. Son navire vaut le coup d'œil, et son équipage se compose uniquement de Normands. Et tout semblerait aller bien : il pirate un peu, gagne de quoi manger, mais il ne verse pas sa part au pot commun, il est insolent avec les gouverneurs, et il écoule ses prises on ne sait oם. Vous voyez de quoi il retourne ?";
				link.l1 = "Je comprends, il faut le punir pour qu'il serve d'exemple à tous. Oם puis-je trouver ce Viking ?";
				link.l1.go = "pirateVikingQuest_2";
				link.l2 = "Cette conversation ne me plaît pas. Au revoir...";
				link.l2.go = "exit";
				pchar.questTemp.pirateVikingQuest = "0";
			}
			if(CheckAttribute(PChar, "questTemp.pirateVikingQuest") && pchar.questTemp.pirateVikingQuest == "7" && npchar.city == pchar.questTemp.pirateVikingQuest.City)
			{
				dialog.text = "Je vois que vous avez des nouvelles ?"
				link.l1 = "Oui, j'ai tué ce Viking, et il était féroce, croyez-moi. D'habitude, quand ils sentent la mort, ils se mettent tous à parlementer, mais celui-là grognait, l'écume aux lèvres.";
				link.l1.go = "pirateVikingQuest_final";
			}
		break;
		case "Vopros":			//Вопросы по поводу заданий
			dialog.text = RandPhraseSimple("Eh bien, posez votre question.", "Que voulez-vous ?");
			link.l1 = "Pas de questions...";
			link.l1.go = "exit";
			//поиски шебеки Синяя Птица
			if (pchar.questTemp.BlueBird == "toBermudes")
			{
				link.l2 = "וcoutez, Jackman, voilà l'affaire... En somme, avez-vous eu dans votre port le chébec Oiseau bleu ?";
				link.l2.go = "BlueBird_1";
			}
			if (pchar.questTemp.BlueBird == "weWon")
			{
				link.l2 = "Imaginez-vous que j'ai attrapé le chébec « Oiseau bleu » !";
				link.l2.go = "BlueBird_6";
			}
			//пиратская линейка
			if (pchar.questTemp.piratesLine == "KillLoy_toJackman")
			{
				link.l3 = "Je cherche mon ami Edward Law, Alexus m'a dit qu'il était chez vous.";
				link.l3.go = "PL_Q3_1";
			}
			if (pchar.questTemp.piratesLine == "KillLoy_toTavernAgain")
			{
				dialog.text = ""+ GetSexPhrase("Que vous faut-il ?! Je ne suis pas d'humeur à répondre à vos questions !","Que vous faut-il, " + pchar.name + " ? Je suis très occupé en ce moment...") +"";
				link.l3 = "Il semble que vous et moi ayons une affaire commune : Edward Law.";
				link.l3.go = "PL_Q3_2";
			}
			if (CheckAttribute(pchar,"questTemp.piratesLine.T1") && pchar.questTemp.piratesLine.T1 == "KillLoy_GoodWork" && !CheckAttribute(npchar, "quest.PQ3"))
			{
				dialog.text = "Vous voilà de retour ! Et pas les mains vides !";
				link.l3 = "Je suis en mesure de vous annoncer qu'Edward Law est mort avec l'horreur dans les yeux et votre nom dans les oreilles.";
				link.l3.go = "PL_SEAWOLF";
			}
			if(CheckAttribute(pchar, "questTemp.piratesLine") && pchar.questTemp.piratesLine == "waiting_Q6") 
			{
				dialog.text = "Oh, qui vois-je ?! Je n'en crois pas mes yeux !";
				link.l3 = "Morgan m'envoie vous dire que le capitaine Goodley est mort.";
				link.l3.go = "PL_Q6_1";
			}
			if(CheckAttribute(pchar, "questTemp.piratesLine") && pchar.questTemp.piratesLine == "PL_Q6_AfterBattle") 
			{
				dialog.text = "John m'a déjà parlé de votre opération contre "+ GetSexPhrase("le sosie","le sosie") +". Avez-vous réussi à apprendre quelque chose de précis ?";
				link.l3 = "Nous avons pu parler, et c'est tout. Il était trop pressé. Je suppose qu'il avait peur de laisser échapper quelque chose de trop.";
				link.l3.go = "PL_Q6_after_1";
			}
			if (pchar.questTemp.piratesLine == "Panama_backToShip")
			{
				dialog.text = "Ah, content de vous voir, " + pchar.name + ". Eh bien, qu'avez-vous à me dire ?";
				link.l3 = "Savez-vous ce que Morgan a fait à Panama ?";
				link.l3.go = "PL_Q8";
			}
			//жемчужный генератор Шарпа
			if (pchar.questTemp.Sharp == "begin")
			{
				link.l4 = "וcoutez, il court des rumeurs sur la pêche aux perles dans les Caraïbes. Vous en avez entendu parler ?";
				link.l4.go = "SharpPearl_1";
			}
			//поиски супер-мушкета
			if (CheckAttribute(pchar, "questTemp.mushket2x2") && !CheckCharacterItem(pchar, "mushket2x2"))
			{
				link.l5 = "וcoutez, Jackman, le mot « Arrow » vous dit-il quelque chose ? L'un de vos gars s'appelle peut-être comme ça, ou bien c'est le nom d'un navire pirate ?";
				link.l5.go = "Mushket";
			}
			//поручение капитана - выкуп
			if (CheckAttribute(pchar, "GenQuest.CaptainComission") && NPChar.city == pchar.GenQuest.CaptainComission.PiratesCity)
			{
				if(CheckAttribute(pchar,"GenQuest.CaptainComission.toMayor"))
				{
					link.l6 = "Je viens au sujet de votre prisonnier.";
					link.l6.go = "CapComission1";
				}
				if(CheckAttribute(pchar,"GenQuest.CaptainComission.PirateShips"))
				{
					link.l6 = "Bonjour, Jackman, je viens pour votre mission.";
					link.l6.go = "CapComission3";
				}
				if(CheckAttribute(pchar,"GenQuest.CaptainComission.RepeatSpeak"))
				{
					link.l6 = "Je viens au sujet de votre prisonnier.";
					link.l6.go = "CapComission6";
				}
			}
		break;
		//Начало Пиратской Линейки
		case "Vstuplenie_v_Bratstvo_1":
			dialog.text = "Vraiment ? J'ai besoin de VOUS ? Je crois que c'est plutכt le contraire, non ? וcoutez-moi, "+GetSexPhrase("fiston","ma fille")+", j'ai entendu parler de vos exploits ici. Vous promettez beaucoup, à ce qu'on m'a dit. Vous deviendrez peut-être bientכt une légende ! Mais ça n'arrivera qu'après que quelqu'un vous aura coupé la tête. Comprenez bien, "+pchar.name+", les loups solitaires ne vivent pas longtemps, surtout chez les pirates. Tant que vous n'avez pas d'amis, vous avez toutes les chances de vous retrouver la gorge tranchée avant d'avoir eu le temps de couiner. Vous me comprenez, maintenant ?";
			link.l1 = "Non. Pas un traître mot. Répétez-le, cette fois en "+LinkRandPhrase("anglais", "français", "hollandais")+", d'accord ?";
			link.l1.go = "Vstuplenie_v_Bratstvo_2";
		break;
		case "Vstuplenie_v_Bratstvo_2":
			dialog.text = "וcoutez, "+GetSexPhrase("fiston","ma fille")+", vous êtes une vraie plaie, mais vous me plaisez. Et c'est la seule raison pour laquelle je n'ai pas ordonné aux gars de vous jeter à la mer avec un boulet attaché à la jambe. Maintenant, écoutez-moi bien. Nous qui avons rejoint les Frères de la Cכte pouvons vivre en paix sur cette île, et personne ne viendra ici : ni les Anglais, ni les Français, ni les Espagnols assoiffés de sang. Vous savez pourquoi ? Parce que s'ils viennent ici, nous les enverrons tout droit en enfer ! Jetez un œil par-dessus bord un jour de beau temps, et vous verrez combien de navires reposent au fond de cette baie. Tout ça, c'est notre œuvre. Vous voulez savoir comment ? C'est simple : nous ne nous battons pas entre nous tant que nous ne nous sommes pas débarrassés de la vraie menace, et nous savons toujours ce qui se passe et oם. J'ai des amis et des copains partout, et grâce à eux, je sais tout ce qui se passe ici, je garde un œil sur chaque homme, chaque femme et chaque enfant de ces îles. Je rencontre mes capitaines et je leur dis qui a payé pour sa vie et qui ne l'a pas fait. Je leur dis oם naviguent les marchands les plus gras, et oם la Royal Navy joue à ses petits jeux. Nous nous entraidons, et nous n'enfreignons pas les lois des Frères de la Cכte.";
			link.l1 = "Je vois. Et vous voulez que je rejoigne votre organisation ?";
			link.l1.go = "Vstuplenie_v_Bratstvo_3";
		break;
		case "Vstuplenie_v_Bratstvo_3":
			dialog.text = "Nous nous appelons les Frères de la Cכte. Et nous sommes des frères de la mer. א vrai dire, "+GetSexPhrase("le gars","la fille")+", ça m'est bien égal que vous soyez avec nous ou non. Mais si vous êtes avec nous, je vous le jure, vous vivrez bien plus longtemps. Et quand les ennuis vous rattraperont, vous saurez oם aller.";
			link.l1 = "Et que vous devrai-je en retour ?";
			link.l1.go = "Vstuplenie_v_Bratstvo_4";
		break;
		case "Vstuplenie_v_Bratstvo_4":
			dialog.text = "Pas grand-chose, croyez-moi. D'abord, vous devez me prévenir si ces vauriens complotent quelque chose contre nous. Et de temps en temps, je vous confierai quelques missions. Vous voyez, rien de spécial. Sauf qu'il vous faudra parfois prendre deux ou trois forts, ou capturer un vaisseau de ligne. Les affaires pirates habituelles, quoi. Bon sang, "+GetSexPhrase("le gars","la fille")+", ça va vous plaire !";
			link.l1 = "Bon... Et qu'est-ce que j'y gagne, au juste ? Je rejoins vos Frères pour obtenir une fameuse protection contre des ennemis incompréhensibles, et en échange, je dois piller, trahir des gouverneurs, couler des navires, ruiner des villes et me soמler avec toutes sortes de pirates mal lavés ? Eh bien, comment refuser. Je suis avec vous, Jackman. Oם dois-je signer ?";
			link.l1.go = "Vstuplenie_v_Bratstvo_6";
			link.l2 = "Hum, l'offre est tentante. Laissez-moi y réfléchir un moment.";
			link.l2.go = "Vstuplenie_v_Bratstvo_5";
		break;
		case "Vstuplenie_v_Bratstvo_5":
			dialog.text = "Réfléchissez autant que vous voudrez. Mais ailleurs. Vous ne voyez pas que je suis occupé ? Allez, dehors.";
			link.l1 = "Euh... א plus tard, Jackman.";
			link.l1.go = "exit";
		break;
		case "Vstuplenie_v_Bratstvo_6":
			dialog.text = "Parfait ! Et apprenez à parler comme un vrai pirate : qu'est-ce que c'est que ces manières de morveux, « Auriez-vous l'obligeance... » ! Pouah ! Bienvenue chez les Frères de la Cכte, capitaine. Je dirai aux gars que vous êtes des nכtres. Ils ne vous toucheront plus. Mais souvenez-vous : Morgan n'est pas des nכtres, alors ne bayez pas aux corneilles. S'il veut se débarrasser de vous, il n'aura pas peur de se mettre en travers des Frères. Maintenant, filez, "+pchar.name+". Je n'ai pas de mission pour vous en ce moment. Allez ! Du vent !";
			link.l1 = "Au revoir, Jackman. Je repasserai quand vous serez moins occupé.";
			link.l1.go = "exit";
			pchar.questTemp.Vstuplenie_v_Bratstvo = true;
			pchar.questTemp.Jackman_Zadanie = true;
		break;
		//Sinistra. Пролог Анжелика Тич
		case "ATpr_F1":
			dialog.text = "Maintenant, je n'en doute plus : vous êtes le portrait craché de votre mère.";
			link.l1 = "Vous connaissiez ma mère ?";
			link.l1.go = "ATpr_F2";
			DeleteAttribute(pchar, "questTemp.AnjelikaTichPrologue7_Jackman");
		break;
		case "ATpr_F2":
			dialog.text = "Oui, tout le monde la connaissait. Elle se pavanait ici comme une oie importante, l'élue de Barbe-Noire, rien de moins. Elle sifflait sur tout le monde, essayait d'imposer ses propres règles, mais personne n'osait la toucher.";
			link.l1 = "On dirait bien que c'était elle.";
			link.l1.go = "ATpr_F3";
		break;
		case "ATpr_F3":
			dialog.text = "Puis le vieil Edward l'a emmenée d'ici, et quand il s'est lassé d'elle, il l'a débarquée avec sa petite fille quelque part sur une île déserte. C'est pourquoi je m'attendais si peu à vous voir ici.";
			link.l1 = "Il nous a débarquées à Hispaniola ; moins d'un jour plus tard, nous avons atteint la colonie la plus proche.";
			link.l1.go = "ATpr_F4";
		break;
		case "ATpr_F4":
			dialog.text = "Franchement, ces vieilles histoires ne me tracassent guère. Dites-moi plutכt pourquoi vous êtes venue maintenant ?";
			link.l1 = "Par curiosité. Je m'en vais déjà.";
			link.l1.go = "exit";
		break;

		//Blackthorn. Квест викинга
		case "pirateVikingQuest_2":
			dialog.text = "Quelque part. Si je savais oם il se terre, j'irais moi-même en mer, malgré mes vieilles blessures et mon âge. Vous êtes quelqu'un de futé, vous trouverez bien. Une seule condition : ce Ragnar et tout son équipage doivent finir en nourriture pour les poissons, et je saurai me montrer généreux en or.";
			link.l1 = "Attendez les nouvelles. Et pour la révocation des lettres de marque, s'il y a du nouveau, prévenez-moi. א l'occasion, " + GetFullName(npchar)+".";
			link.l1.go = "exit";

			pchar.questTemp.pirateVikingQuest = "1";
			pchar.questTemp.pirateVikingQuest.City = npchar.city;
			pchar.questTemp.pirateVikingQuest.Areal = GetArealByCityName(pchar.questTemp.pirateVikingQuest.City);
			pchar.questTemp.pirateVikingQuest.Name = GetFullName(npchar);
			pchar.LastHearedViking = npchar.city;
			AddQuestRecord("pirateVikingQuest", "1");
			AddQuestUserData("pirateVikingQuest", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateVikingQuest.City + "Gen"));
			AddQuestUserData("pirateVikingQuest", "sName", pchar.questTemp.pirateVikingQuest.Name);
		break;
		case "pirateVikingQuest_final":
			CloseQuestHeader("pirateVikingQuest");
			pchar.questdata.OskolokProshlogo = 1;
			TakeNItems(pchar, "chest", 3);
			Log_Info("Vous avez reçu les coffres de crédit");
			dialog.text = "Oui, j'en ai entendu parler une fois. Un vrai berserker. Comme un vestige du passé. Tenez, prenez la récompense, vous l'avez méritée.";
			pchar.questTemp.pirateVikingQuest = "end";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//********************* пиратка, направление на квест №1 *********************
		case "PL_Q1_2":
			dialog.text = "Oui, vous pouvez lui demander quand et comment.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			pchar.questTemp.piratesLine = "toFirstQuest";
			AddQuestRecord("Pir_Line_0_Waiting", "2");
			
			sld = GetCharacter(NPC_GenerateCharacter("QuestPirate1", "officer_9", "man", "man", 20, PIRATE, -1, true));
			sld.name = "Capitaine";
			sld.lastname = "Goodley";
			sld.city = "PuertoPrincipe";
			sld.location	= "PuertoPrincipe_town";
			sld.location.group = "goto";
			sld.location.locator = "goto7";
			sld.dialog.filename   = "Quest\PiratesLine_dialog.c";
			sld.dialog.currentnode   = "PiratesMan1";
			sld.greeting = "Gr_EvilPirate";
			sld.talker = 8; //начать диалог
			sld.TiedItems.itm1.model = "HandsItems\meet";
			sld.TiedItems.itm1.locator = "Saber_hand";
			sld.TiedItems.itm2.model = "HandsItems\cup";
			sld.TiedItems.itm2.locator = "Saber_hand";
			LAi_SetLoginTime(sld, 6.0, 21.99);
			LAi_SetCitizenType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
		break;
		//********************* пиратка, квест №3, поиски Лоу *********************
		case "PL_Q3_1":
			dialog.text = "Un ami ?! Ho ! Hé, les gars ! Allez-y !!!";
			link.l1 = "Je n'ai pas compris !..";
			link.l1.go = "PL_Q3_fight";
		break;
		case "PL_Q3_fight":
			LAi_LocationFightDisable(&Locations[FindLocation("Pirates_townhall")], false);
			chrDisableReloadToLocation = true; // закрыть выход из локации.
            for (i=1; i<=3; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("QuestPir_"+i, "pirate_"+i, "man", "man", 100, PIRATE, 0, true));
                FantomMakeCoolFighter(sld, 100, 100, 100, "topor2", "pistol3", 100);
            	LAi_SetWarriorType(sld);
				LAi_SetImmortal(sld, true);
            	sld.Dialog.Filename = "Quest\EngLineNpc_2.c";
                LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
               	ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1");
            }
            LAi_group_SetLookRadius("PIRATE_CITIZENS", 100);
            LAi_group_SetRelation("PIRATE_CITIZENS", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("PIRATE_CITIZENS", LAI_GROUP_PLAYER, false);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "PL_Q3_2":
			LAi_group_SetRelation("PIRATE_CITIZENS", LAI_GROUP_PLAYER, LAI_GROUP_NEITRAL); // Gregg: clear pirate hostility to the player set by the PL_Q3 brawl, else it sticks for the rest of the game (resetGroupRel skips it due to the isactive gate)
			dialog.text = "Law ?! Qu'avez-vous à voir avec Law ?";
			link.l1 = "Je n'ai pas d'affaires avec Law. Il a contrarié Morgan d'une manière ou d'une autre, et on m'a chargé de régler ce différend. Vous comprenez maintenant pourquoi je le cherche ?";
			link.l1.go = "PL_Q3_3";
		break;
		case "PL_Q3_3":
			dialog.text = "Hum. Il a aussi joué un mauvais tour à Morgan ? Je ne peux pas dire que ça me chagrine beaucoup. Mais cette canaille m'a volé mon brick !";
			link.l1 = "Oui, je sais, le maître du chantier naval m'a tout raconté.";
			link.l1.go = "PL_Q3_4";
		break;
		case "PL_Q3_4":
			dialog.text = "Ouais, quelle oie, celui-là ! Il a de la sciure à la place de la cervelle ! Il faut le faire, croire que je vais lui écrire des lettres ! Un lièvre peut aller de ma résidence à sa niche en deux bonds ! Et le lendemain, il s'est ramené clopin-clopant ! Il voulait être payé pour le brick qu'il avait laissé filer. Quand mes gars ont flanqué ce raboteur à la porte, je lui ai dit : s'il n'y a pas de « Loup de mer », je l'écorche vif et j'enveloppe l'argent dans sa peau ! Pour que ce soit plus facile à porter.";;
			link.l1 = "Mais c'est un très bon maître, seulement il est bien distrait...";
			link.l1.go = "PL_Q3_5";
		break;
		case "PL_Q3_5":
			dialog.text = "Oui, je me suis emporté. Je ne le toucherai pas : personne de sensé ne se débarrasse de tels maîtres. Mais je suis fou de rage qu'on m'ait volé mon navire ! Et qu'Alexus tremble un peu, il sera plus malin la prochaine fois. " +
				"Vous dites donc que vous voulez tuer Edward Law. Comme vous l'avez compris, je le souhaite aussi. Je veux que le voleur sache pourquoi il meurt... Qu'il sache qu'on ne s'en tire pas comme ça avec Jackman ! Et que tout le monde le sache ! Voilà !!! Je veux donc vous demander de faire savoir à Law que la mort lui vient de moi, pas de Morgan, mais de MOI ! Je pense que vous me comprenez.";
			link.l1 = "D'accord, il l'entendra avant de mourir. Jackman, répondez-moi à une question.";
			link.l1.go = "PL_Q3_6";
		break;
		case "PL_Q3_6":
			dialog.text = "Laquelle ?";
			link.l1 = "Pourquoi avez-vous dit ça au sujet de Morgan ? Vous êtes censés être amis.";
			link.l1.go = "PL_Q3_7";
		break;
		case "PL_Q3_7":
			dialog.text = "Hum, des amis... Eh bien, je vais vous répondre, si vous comprenez... Les Frères de la Cכte, les gentilshommes de fortune, les trésors, les femmes, la gloire ! Des mots familiers, n'est-ce pas ? Quand nous sommes jeunes et naïfs, le romantisme de ces mots nous attire comme la flamme d'une bougie attire les papillons de nuit... et nous volons docilement vers elle. " +
				"Mais les gens sont tous différents : certains tournoient autour sans oser s'approcher, d'autres se brמlent et s'envolent, d'autres encore se consument sans mesurer leurs forces. Et celui dont les nerfs sont solides comme une baguette de fusil renaît dans ce feu, et le porte sur sa peau, brמlant tout autour de lui. Hum, je vois que vous ne comprenez pas oם je veux en venir... Vous connaissez sans doute l'expression : « L'homme est un loup pour l'homme » ? Eh bien, nous sommes tous une meute de loups... "+"La meute attrape des proies bien plus grosses qu'un loup solitaire. Mais la meute est menée par un chef, qui a toujours le plus gros morceau de la proie et la plus douce des louves. Tous les loups lui obéissent, mais ils attendent... Ils attendent qu'il commette une erreur ! Parce que chaque loup veut un plus gros morceau de la proie et une louve plus douce... Voilà le romantisme.";
			link.l1 = "Hum, j'aurais mieux fait de ne pas demander. Des papillons, des loups... La raison du plus fort est toujours la meilleure. J'ai été et je resterai un loup solitaire. Et tant pis si j'obtiens moins que la meute, mais "+ GetSexPhrase("je choisirai la louve que je veux","je ferai ce que j'aurai décidé") +".";
			link.l1.go = "PL_Q3_8";
		break;
		case "PL_Q3_8":
			dialog.text = "Ha ha ha, eh bien, filez, "+ GetSexPhrase("loup","louve") +" solitaire ! Et revenez avec le butin !";
			link.l1 = "Attendez-moi, je reviens bientכt.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			AddQuestRecord("Pir_Line_3_KillLoy", "12");
			pchar.questTemp.piratesLine = "KillLoy_2toTavernAgain";
		break;
		//после поисков Лоу
		case "PL_SEAWOLF":
			NextDiag.TempNode = "I_know_you_good";
			npchar.quest.PQ3 = true;
			int chComp;
			bool bOk = false;
			for (int i=0; i<=COMPANION_MAX; i++)
        	{
				chComp = GetCompanionIndex(pchar, i);
                if(chComp != -1 && RealShips[sti(characters[chComp].ship.type)].Name == "BrigSW1")
        		{
					bOk = true;
					break;
				}
			}
			if (bOk)
			{
				dialog.text = "Voilà les mots que j'attendais. Je vois que vous avez aussi réussi à récupérer mon brick ! Bravo. Vous avez prouvé que vous êtes un Loup ! Je respecte ce genre de personnes !";
				link.l1 = "Je suis un capitaine libre, Jackman. Mais vos paroles sont un honneur pour moi !";
				link.l1.go = "PL_SEAWOLF_2";
				link.l2 = "Vos paroles sont un honneur pour moi, Jackman ! Vous voulez récupérer le Loup de mer ? Je pense pouvoir vous le rendre. Je crois qu'il comptait beaucoup pour vous.";
				link.l2.go = "PL_SEAWOLF_3";
				
			}
			else
			{
				dialog.text = "Voilà les mots que j'attendais. Eh bien, merci, "+ GetSexPhrase("l'ami","ma petite") +". En récompense de vos efforts, je vous donne 20 mille piastres !";
				link.l1 = "Merci, Jackman ! Cet argent me sera utile.";
				link.l1.go = "exit";
				AddMoneyToCharacter(pchar, 20000);
				AddQuestRecord("Pir_Line_3_KillLoy", "20");
				AddQuestUserData("Pir_Line_3_KillLoy", "sSex", GetSexPhrase("", "e"));
			}
		break;
		case "PL_SEAWOLF_2":
			pchar.questTemp.BrigSW_gift = true;
			dialog.text = "Alors, de bon cœur, je vous donne le « Loup de mer » : qu'il soit vכtre de plein droit ! J'aimerais avoir "+ GetSexPhrase("un gars comme vous","une fille aussi hardie que vous") +" dans mon équipage !";
			link.l1 = "Merci du fond du cœur, Jackman !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "19");
		break;
		case "PL_SEAWOLF_3":
			dialog.text = "Inattendu ! Je ne m'attendais pas à une telle offre... J'accepte : après tout, le « Loup » tient une place importante dans mon cœur. Mais je ne peux pas vous laisser partir sans un cadeau pour ça. Tenez, prenez ceci. Vous ne pouvez même pas imaginer le mal que j'ai eu à me le procurer à l'époque, mais maintenant, je vous le donne la conscience tranquille. Servez-vous-en !"; //Также, отдаю тебе один из своих кораблей. Просто так, в знак хорошего отношения.
			link.l1 = "Merci du fond du cœur, Jackman !";
			link.l1.go = "exit";
			GiveItem2Character(pchar,"mushket6");
			log_info("Jackman vous a offert son Tromblon de la Tour !");
			int chComp1;
			ref swchar;
			if (RealShips[sti(pchar.ship.type)].Name == "BrigSW1")
			{
				DeleteAttribute(pchar, "ship");
				pchar.ship.name = "";
				pchar.ship.type = SHIP_NOTUSED;
			}
			else
			{
				for (int x=1; x<=COMPANION_MAX; x++)
				{
					chComp1 = GetCompanionIndex(pchar, x);
					if(chComp1 != -1 && RealShips[sti(characters[chComp1].ship.type)].Name == "BrigSW1")
					{
						swchar = &characters[chComp1];
						RemoveCharacterCompanion(PChar, swchar);
						AddPassenger(PChar, swchar, false);
						//swchar.ship.type = GenerateShipTop(SHIP_MIRAGE, true, swchar);
						break;
					}
				}
			}
			/*SetBaseShipData(swchar);
			swchar.ship.name = "Mirage";
			ref VeryRealShip = GetRealShip(sti(swchar.Ship.Type));
			DeleteAttribute(VeryRealShip,"EmblemedSails");
			DeleteAttribute(VeryRealShip,"shipsails");
			VeryRealShip.ship.upgrades.sails = 3;
			
			SetShipBermudeTuningSpeedRate(swchar);
			SetShipBermudeTuningTurnRate(swchar);
			SetShipBermudeTuningWindAgainstSpeed(swchar);
			SetShipBermudeTuningCapacity(swchar);
			SetShipBermudeTuningMaxCrew(swchar);
			SetShipBermudeTuningHP(swchar);
			SetShipBermudeTuningMastMultiplier(swchar);
			VeryRealShip.Tuning.CuBot = true;
			
			VeryRealShip.MaxCaliber = 20;
			VeryRealShip.Tuning.Cannon = true;
			VeryRealShip.CannonsQuantity = 22;
			swchar.Ship.Cannons.Type = CANNON_TYPE_CANNON_LBS20;
			
			SetCharacterGoods(swchar, GOOD_BALLS, 200);
			SetCharacterGoods(swchar, GOOD_GRAPES, 400);
			SetCharacterGoods(swchar, GOOD_KNIPPELS, 200);
			SetCharacterGoods(swchar, GOOD_BOMBS, 400);;
			SetCharacterGoods(swchar, GOOD_FOOD, 1000);
			SetCharacterGoods(swchar, GOOD_MEDICAMENT, 500);
			SetCharacterGoods(swchar, GOOD_POWDER, 2000);
			SetCharacterGoods(swchar, GOOD_WEAPON, 300);
			
			SetCrewQuantityFull(swchar);
			AddCrewMorale(swchar, 100);
			ChangeCrewExp(swchar, "Sailors", 100);
			ChangeCrewExp(swchar, "Cannoners", 100);
			ChangeCrewExp(swchar, "Soldiers", 100);*/
			AddQuestRecord("Pir_Line_3_KillLoy", "19_2");
			AddQuestUserData("Pir_Line_3_KillLoy", "sSex2", GetSexPhrase("", "e"));
		break;
		
		//********************* пиратка, квест №6. двойник *********************
		case "PL_Q6_1":
			dialog.text = "Voilà donc... La nouvelle n'est pas agréable... Et comment est-ce arrivé ?";
			link.l1 = "Je l'ai tué à la résidence de Morgan... Vous voyez, l'histoire est plutכt fâcheuse. Sur ses instructions, j'ai éliminé John Avory, mais il s'est avéré que c'était un homme de confiance de Morgan.";
			link.l1.go = "PL_Q6_2";
		break;
		case "PL_Q6_2":
			dialog.text = "Avory est mort, lui aussi ?";
			link.l1 = "Ouais... Bref, au bout du compte, Goodley a refusé d'avouer, lors de la confrontation chez Morgan, que c'était lui qui m'avait engagé contre Avory. Heureusement qu'Henry avait appris certaines choses auparavant, et je n'ai pas eu à me justifier.";
			link.l1.go = "PL_Q6_3";
		break;
		case "PL_Q6_3":
			dialog.text = "Ha, bravo ! Vous ne savez pas qu'on dit aussi que vous avez capturé Sid Bonnet, l'un de mes capitaines, et que vous l'avez livré aux Espagnols ?";
			link.l1 = "Moi ?!!";
			link.l1.go = "PL_Q6_4";
		break;
		case "PL_Q6_4":
			dialog.text = "Oui, c'est ce que disent les rumeurs. C'est pourquoi j'ai été un peu surpris de vous voir ici.";
			link.l1 = "Diable !! Il ne manquait plus que ça !";
			link.l1.go = "PL_Q6_5";
		break;
		case "PL_Q6_5":
			dialog.text = "Allez à la baie de Cozumel, au nord de Belize. John Leeds y mouille sur la frégate Antwerp, il a des problèmes avec son équipage. Je pense qu'il sera très intéressant pour vous de lui rendre visite...";
			link.l1 = "D'accord, Jackman, je vais le faire.";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			SetQuestHeader("Pir_Line_6_Jackman");
			AddQuestRecord("Pir_Line_6_Jackman", "2");
			AddQuestUserData("Pir_Line_6_Jackman", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.piratesLine = "PL6Brother_toSantaCatalina";
			//ставим Джона Лидса в залив Косумель
			sld = GetCharacter(NPC_GenerateCharacter("JohnLids", "officer_10", "man", "man", 30, sti(pchar.nation), -1, true));
			FantomMakeCoolSailor(sld, SHIP_FRIGATE, "Antwerpen", CANNON_TYPE_CULVERINE_LBS24, 80, 60, 60);
			sld.name = "John";
			sld.lastname = "Leeds";
			sld.dialog.filename   = "Quest\PiratesLine_dialog.c";
			sld.dialog.currentnode   = "First time";
			sld.DeckDialogNode = "JohnLids";
			sld.Abordage.Enable = false;
			sld.AnalizeShips = true;
			sld.AlwaysFriend = true;
			sld.ShipEnemyDisable = true;
			sld.Ship.Mode = "Pirate";
			sld.greeting = "Gr_MiddPirate";
			LAi_group_MoveCharacter(sld, LAI_GROUP_PLAYER_OWN);
			Group_AddCharacter("LidsGroup", "JohnLids");
			Group_SetGroupCommander("LidsGroup", "JohnLids");
			Group_SetAddress("LidsGroup", "Beliz", "quest_ships", "Quest_ship_11");
			Group_SetTaskNone("LidsGroup");
		break;

		case "PL_Q6_after_1":
			dialog.text = "C'est mauvais. Vous traînez une drכle de piste derrière vous, pleine de bizarreries. Jusqu'ici, la chance est de votre cכté, mais si vous trébuchez, c'est fini ! Morgan ne vous aidera pas.";
			link.l1 = "Je comprends. "+ GetSexPhrase("Le sosie","La « sœur »") +" savait manifestement quelque chose... Nous devons essayer de découvrir qui est derrière tout ça.";
			link.l1.go = "PL_Q6_after_2";
		break;
		case "PL_Q6_after_2":
			dialog.text = "C'est vrai. Eh bien, heureusement que vous êtes passé me voir et que vous avez éclairci quelques détails importants, pour ainsi dire. Maintenant, allez voir Morgan et parlez-lui de votre "+ GetSexPhrase("sosie","« sœur »") +".";
			link.l1 = "Oui, ce serait bien... Dites-moi, Jackman, qu'avez-vous pensé quand vous avez appris que j'avais livré Sid Bonnet aux Espagnols ?";
			link.l1.go = "PL_Q6_after_3";
		break;
		case "PL_Q6_after_3":
			dialog.text = "Hum, ça, vous ne voulez pas le savoir... Vous avez simplement de la chance que Leeds ait enfermé "+ GetSexPhrase("le sosie","la « sœur »") +" à Belize, et que "+ GetSexPhrase("l'homme","la fille") +" qui a livré Bonnet n'ait pas pu arriver ici avant vous.";
			link.l1 = "Compris. J'ai donc vraiment de la chance.";
			link.l1.go = "exit";
			SetQuestHeader("Pir_Line_6_Jackman");
			AddQuestRecord("Pir_Line_6_Jackman", "5");
			pchar.questTemp.piratesLine = "PL_Q6_AfterBattle_2";//фикс повторных диалогов на ту же тему
			QuestSetCurrentNode("Henry Morgan", "PL_Q7_begin");
			sld = characterFromId("Henry Morgan");
			LAi_SetHuberTypeNoGroup(sld);
			ChangeCharacterAddressGroup(sld, "PortRoyal_houseS1", "sit", "sit2");
		break;


		//********************* капитан Шарп *********************
		case "SharpPearl_1":
			dialog.text = "J'en ai entendu parler, mais je n'en sais pas grand-chose. Notre bien-aimé et respecté capitaine Sharp est le spécialiste de ces pêcheries ! C'est un grand amateur de perles, ha ha ha !";
			link.l1 = "Oם puis-je le trouver, ce Sharp ?";
			link.l1.go = "SharpPearl_2";
			pchar.questTemp.Sharp = "seekSharp";
		break;
		case "SharpPearl_2":
			dialog.text = "Je ne sais pas. Le capitaine Sharp, c'est l'insaisissable Joe. Quoique vous, vous en ayez besoin, apparemment. En général, il faut le chercher dans les bordels.";
			link.l1 = "Merci, Jackman.";
			link.l1.go = "exit";
		break;

        //********************** поиски Синей птицы ***********************
        case "BlueBird_1":
			dialog.text = NPCStringReactionRepeat("Mmm, ce rafiot est devenu célèbre, inutile de le dire... Et pourquoi avez-vous besoin de ce chébec ?",
				"Nous avons déjà parlé de ce chébec.",
				"Encore la même chose ?",
                "Quoi ?! Encore ?! Bon, j'en ai assez...", "repeat", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, voyez-vous, un groupe de camarades s'intéresse beaucoup à lui...",
				"Oui, Jackman, c'est ça.",
                "Hum, je me suis embrouillé dans mes notes, désolé...",
				"Aïe !..", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("BlueBird_2", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
  		break;
		case "BlueBird_2":
			dialog.text = "Héhé, ce ne seraient pas des marchands ? J'ai entendu dire qu'ils en prennent plein la figure, avec cet « Oiseau bleu ».";
			link.l1 = "Les marchands s'intéressent vraiment à ce chébec. Mais, vous savez, ce genre d'« oiseau » auquel on ne peut pas échapper me plaît. C'est en somme le voilier corsaire idéal !";
			link.l1.go = "BlueBird_3";
		break;
		case "BlueBird_3":
			dialog.text = "Ha, c'est juste ! Vous n'êtes pas le premier des Frères à la viser, mais personne ne l'a encore attrapée. Quant à moi, cet « oiseau » ne m'intéresse pas personnellement : il est trop petit pour les affaires sérieuses.";
			link.l1 = "Jackman, vous savez donc oם est le chébec ?";
			link.l1.go = "BlueBird_4";
		break;
		case "BlueBird_4":
			dialog.text = "Non, bien sמr que non. Je l'ai vu dans les eaux environnantes, mais il n'est pas entré au port.";
			link.l1 = "Pouvez-vous me dire oם, à votre avis, il faudrait chercher ?";
			link.l1.go = "BlueBird_5";
		break;
		case "BlueBird_5":
			dialog.text = "Non, j'y ai déjà réfléchi. Pas une seule idée valable.";
			link.l1 = "Compris. Eh bien, merci quand même, l'ami.";
			link.l1.go = "exit";
		break;

		case "BlueBird_6":
			dialog.text = NPCStringReactionRepeat("Hum, félicitations. Une sacrée chance, bon sang ! Bravo.",
				"Encore une fois, félicitations.",
				"Je l'ai déjà entendu...",
                "Ha, quel vantard vous faites, "+ GetSexPhrase("l'ami","ma petite") +", les Caraïbes n'ont encore jamais vu ça !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, Jackman. Un mot gentil fait toujours plaisir...",
				"Merci encore, Jackman.",
                "Oh, ouais...",
				"Je m'en vante !", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
        //********************** Английская линейка ***********************
 		case "EngLine_quests":
			dialog.text = "Content de voir un corsaire anglais sur mon île. Dites-moi ce qu'il vous faut.";
			link.l1 = "J'ai du travail pour vous. Le commanditaire est le gouverneur général de la Jamaïque.";
			link.l1.go = "Step_1";
  		break;

 		case "Step_1":
			dialog.text = "Très intéressant, continuez.";
			link.l1 = "Madiford a besoin d'une attaque contre Curaçao, et la richesse des marchands de cette ville ne nous fera pas de mal. Il y a maintenant à Curaçao beaucoup de marchands protestants qui ont refusé d'essayer le « brodequin espagnol » de l'Inquisition et ont quitté l'Espagne et le Portugal pour la Hollande. Et là oם il y a des marchands, il y a beaucoup d'or. Je vous propose de joindre l'utile à l'agréable.";
			link.l1.go = "Step_2";
  		break;

 		case "Step_2":
			dialog.text = "Hé... C'est tentant, mais je refuse.";
			link.l1 = "Et quelle est la raison de ce refus ?";
			link.l1.go = "Step_3";
  		break;

 		case "Step_3":
			dialog.text = "Le fait est qu'en plus des marchands et de leur or, il y a à Curaçao beaucoup de soldats hollandais, avec leurs mousquets, et des canons aux embrasures du fort.";
			link.l1 = "Les soldats espagnols ne vous font pas si peur...";
			link.l1.go = "Step_4";
  		break;

 		case "Step_4":
			dialog.text = "La seule chose qui me fasse peur, c'est l'état de mon foie. Mais voyez-vous, ouvrir le ventre d'un Espagnol, c'est sacré, alors que pour saigner un Hollandais, je ne recruterai pas grand monde. Alors ce sera sans moi.";
			link.l1 = "Vous y réfléchirez peut-être ?";
			link.l1.go = "Step_5";
  		break;

 		case "Step_5":
			dialog.text = "J'ai dit mon dernier mot. Et transmettez mes salutations à Madiford.";
			link.l1 = "Comme vous voudrez. Bonne journée.";
			link.l1.go = "exit";

            AddQuestRecord("Eng_Line_2_Talking", "4");
            pchar.questTemp.Count = makeint(sti(pchar.questTemp.Count) + 1);
            if (pchar.questTemp.Count == "4")   {pchar.questTemp.State = "after_talks_with_pirates";}
            NextDiag.TempNode = "First time";
  		break;

 		case "Lets_go_bussines":
			dialog.text = "Ravi de vous voir, " + pchar.name + ". Quel bon vent vous amène aux Bermudes ?";
			link.l1 = "Je suis ici pour affaires. Morgan et moi attaquons Belize, vous voulez en être ?";
			link.l1.go = "Step_6";
  		break;

 		case "Step_6":
            if (GetCompanionQuantity(pchar) != 4)
            {
    			dialog.text = "Hé, ma corvette est en rade, l'équipage est au complet, je suis prêt.";
    			link.l1 = "Alors nous agirons immédiatement !";
    			link.l1.go = "Step_7";
            }
            else
            {
    			dialog.text = "Vous avez assez de monde sans moi, alors ce sera sans moi cette fois.";
    			link.l1 = "Eh bien, comme vous voudrez, portez-vous bien.";
    			link.l1.go = "exit";
                NextDiag.TempNode = "First time";
            }
  		break;

 		case "Step_7":
			AddQuestRecord("Eng_Line_3_Morgan", "4");
            LAi_SetActorType(npchar);
            LAi_ActorSetStayMode(npchar);
            ChangeCharacterAddressGroup(npchar, "Pirates_townhall", "goto", "governor1");
            CharacterIntoCompanionAndGoOut(pchar, npchar, "reload", "reload1", 10, false);
            Fantom_SetBalls(npchar, "pirate");
            npchar.CompanionEnemyEnable = false;  // нет отпора при обстреле
            pchar.questTemp.CompanionQuantity = makeint(sti(pchar.questTemp.CompanionQuantity) + 1);
            pchar.questTemp.CompanionQuantity.Jackman = true;
            NextDiag.TempNode = "Have_hot_bussines";
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;

  		break;

	 	case "Have_hot_bussines":   // Если геймеру вдруг захочется ещё пообщаться, не знаю, сможет ли. Но на всякий случай.
			dialog.text = "Bon sang, le temps joue contre nous !";
            link.l1 = "Dépêchons-nous !";
			link.l1.go = "exit";
            NextDiag.TempNode = "Have_hot_bussines";
  		break;

	 	case "Gold_found_in_fort":    // Нода разговора в форте Куманы
            if (CheckAttribute(pchar, "questTemp.CompanionQuantity.Jackman") && !IsCompanion(characterFromID("Jackman")))
    		{
            	dialog.text = "Vous avez tout vu : ma corvette a été coulée par ces maudits Espagnols ! Mais peu importe, l'équipage s'en est tiré presque au complet, et nous avons continué à nous battre à terre\n"+
                              "Et la récompense de nos efforts sera l'or. Hé, ces maudits Espagnols ont essayé de cacher l'or. Mais vous aviez raison, l'or était bien là. Plus de trois tonnes d'or sont à nous !!!"+
                              "Je le dis, et mon âme chante. Je pourrais répéter ces mots pendant des siècles.";
            }
            else
            {
    			dialog.text = "Ces maudits Espagnols ont essayé de cacher l'or. Mais vous aviez raison, l'or était bien là. Plus de trois tonnes d'or sont à nous !!!"+
                              "Je le dis, et mon âme chante. Je pourrais répéter ces mots pendant des siècles.";
            }
            link.l1 = "Et moi, je pourrais les écouter pendant des siècles !";
			link.l1.go = "Step_8";
        break;

	 	case "Step_8":
			dialog.text = "Haha... Vous êtes un bon corsaire, " + GetFullName(pchar) + ". Je vous souhaite bonne chance, "+ GetSexPhrase("l'ami","ma belle") +". "+
                          "Mes gaillards rentrent au bercail après un beau travail. Sachez que les Bermudes seront toujours heureuses de vous voir.";
			link.l1 = "א la prochaine !";
			link.l1.go = "Step_9";
        break;

	 	case "Step_9":
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", 15.0);
            DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
        break;
        //********************** Голландская линейка ***********************
 		case "HolLine8_quest":
			dialog.text = "Je vous écoute, qu'est-ce qui vous amène ?";
			link.l1 = "Je suis ici pour affaires, je cherche un pirate qui a essayé de vendre une Bible peu ordinaire.";
			link.l1.go = "Step_H8_1";
  		break;
 		case "Step_H8_1":
			dialog.text = "Bon sang, il y avait quelque chose... Je n'arrive pas à m'en souvenir... Mais quelqu'un se vantait bel et bien d'un livre rare, en disant qu'il était chrétien...";
			link.l1 = "Et alors ?";
			link.l1.go = "Step_H8_2";
  		break;
 		case "Step_H8_2":
			dialog.text = "Rien. Je ne m'en souviens pas, j'ai juste saisi un bout de conversation... Et nous n'avions pas la tête à la Bible : nous faisions la fête dans un bordel, après tout !";
			link.l1 = "Hum, quel bordel ?";
			link.l1.go = "Step_H8_3";
  		break;
 		case "Step_H8_3":
			dialog.text = "Celui de Fort-de-France.";
			link.l1 = "Compris... Merci, Jackman.";
			link.l1.go = "exit";
			AddQuestRecord("Hol_Line_8_SeekBible", "3");
			pchar.questTemp.State = "SeekBible_toFFBrothel";
			NextDiag.TempNode = "First time";
  		break;
		//********************* Французская линейка *********************
        case "FraLine8_talk":
            dialog.text = "דa alors, le capitaine " + GetFullName(pchar) + " nous fait l'honneur de sa visite ! Je suis très content ! Crachez le morceau : je vois bien que vous brמlez de me raconter quelque chose d'intéressant.";
            link.l1 = "En fait, je n'ai rien de particulièrement intéressant à vous proposer. Il s'agit seulement de refuser de participer à la guerre qui s'annonce entre l'Angleterre et la Hollande.";
            link.l1.go = "Step_F8_1";
        break;
        case "Step_F8_1":
            dialog.text = "Ouais, rien d'intéressant en effet. D'ailleurs, je n'avais pas l'intention de me mêler de cette affaire. Toucher aux Hollandais, c'est une bêtise que seul un parfait idiot commettrait. Vos protecteurs vous ont donc fait faire un détour inutile.";
            link.l1 = "Pas inutile. Au moins, j'ai appris votre neutralité de votre bouche, et non par un tiers.";
            link.l1.go = "exit";
			pchar.questTemp.Count = makeint(pchar.questTemp.Count)+1;
			NextDiag.TempNode = "I_know_you_good";
			AddQuestRecord("Fra_Line_8_ThreeCorsairs", "5");
        break;
		//********************* Пиратская линейка *********************
		case "PL_Q8_deck":
			dialog.text = "Vous perdez votre temps sur mon pont. Nous devons aller à Portobelo de toute urgence !";
			link.l1 = "Oui, je m'en souviens...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;
		case "PL_Q8_deck_1":
			dialog.text = "Hum, vous perdez encore votre temps, je ne vous comprends pas...";
			link.l1 = "Ce n'est rien, ne vous inquiétez pas, Jackman.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;

		case "PL_Q8":
			dialog.text = "Je le sais, bien sמr...";
			link.l1 = "Qu'en dites-vous ?";
			link.l1.go = "PL_Q8_1";
		break;
		case "PL_Q8_1":
			dialog.text = "Je ne dirai rien. De toute façon, j'abandonne la course. Alors ne m'embêtez plus avec ces histoires.";
			link.l1 = "Bon sang, comment ça ?!";
			link.l1.go = "PL_Q8_2";
		break;
		case "PL_Q8_2":
			dialog.text = "C'est comme ça ! De toute façon, j'ai dit mon dernier mot !";
			link.l1 = "Hum, je vois...";
			link.l1.go = "exit";
			NextDiag.TempNode = "I_know_you_good";
			pchar.questTemp.piratesLine = "Panama_inEngland";
		break;
		//поиски супер-мушкета
		case "Mushket":
			dialog.text = "Hum, il existe bien un tel navire : un très bon brick, peut-être le meilleur de l'archipel. Seulement, ce n'est pas un de mes hommes qui le mène, mais un détraqué nommé Albert Sievert. Si je l'avais percé à jour tout de suite, jamais je n'aurais permis à maître Alexus de lui construire un tel bateau.";
			link.l1 = "Qu'est-ce qu'il a de si particulier ? Je dois le trouver.";
			link.l1.go = "Mushket_1";
			DeleteAttribute(pchar, "questTemp.mushket2x2");
		break;
		case "Mushket_1":
			dialog.text = "Je ne peux rien pour vous : il travaille pour son compte. On dit qu'il amasse de l'or pour rentrer en Europe. J'ai voulu le mettre au pas, mais il a envoyé deux de mes messagers par le fond, et j'ai cessé de le chercher. Et, bien sמr, il a cessé de venir aux Bermudes. Mais dans les autres ports non plus : son brick est trop reconnaissable, alors il traîne son ancre de crique en crique et échange toutes ses marchandises contre de l'or auprès des contrebandiers. Donc aucun de mes hommes ne le fréquente ; si j'apprends le contraire, je le jetterai à l'eau moi-même, l'ancre au cou.";
			link.l1 = "Ouais... Vous pouvez me conseiller quelque chose ?";
			link.l1.go = "Mushket_2";
		break;
		case "Mushket_2":
			dialog.text = "Il y avait un homme qui faisait équipe avec ce Sievert. Mais ça n'a pas collé : soit Sievert l'a laissé par-dessus bord, soit l'inverse. Ils sont bien pareils tous les deux, sinon ils ne se seraient sans doute pas associés. Il tient maintenant une petite taverne à Portobelo ; il s'appelle Rolando Pizarro, ou tout simplement le Renard. Il connaît peut-être ses mouillages. Et puis, cherchez ce brick en mer, vous ne le confondrez jamais avec un autre. Faites juste attention : il est vraiment fou...";
			link.l1 = "Je vois. Eh bien, merci, Jackman.";
			link.l1.go = "exit";
			pchar.questTemp.mushket2x2_stid = true;
			AddQuestRecord("SeekDoubleMushket", "2");
		break;

		//*************************** Квест "Orion fluyt accompaniment"Орион"" **********************
        case "Andre_Abel_Quest_Jackman_Dialog_1":
			dialog.text = "Que voulez-vous de moi, " + pchar.name + " ?";
			link.l1 = "Je suis ici pour affaires, Jackman...";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_2";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_2":
			dialog.text = "Dites-moi de quoi il s'agit.";
			link.l1 = "Je ne sais même pas par oם commencer... Bref, je pense que vous vous souvenez d'un marchand nommé André Abel ?";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_3";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_3":
			dialog.text = "Abel ?! Ha ha... Alors, ce coquin a retrouvé la raison ?! Vous m'apportez ma part de sa part ?";
			link.l1 = "Non. Grâce à vos efforts, il est complètement ruiné en ce moment, et il vous demande de cesser de le harceler. Il pense même à fermer boutique pour de bon.";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_4";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_4":
			dialog.text = "Et qui va m'empêcher de le pourchasser ? Vous ?! Vous croyez que je ne sais pas qu'il a changé de navire et qu'il est maintenant coincé à Port-au-Prince ?! Vous avez cru pouvoir me rouler ?! Soyons brefs : qu'il n'espère même pas m'échapper. Je n'aurai pas de repos tant que je n'aurai pas récupéré tout ce qui m'est dמ.";
			link.l1 = "Eh bien, c'est à vous de voir, bien sמr."+ GetSexPhrase(" Seulement, n'oubliez pas que la Terre est ronde et que la mer est vaste...","") +"";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_5";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_5":
			dialog.text = ""+ GetSexPhrase("Qu'avez-vous dit ?! Vous osez me menacer dans ma propre résidence ?! Les gars, allez, flanquez-moi ce jeune homme dehors !","Bien sמr que c'est à moi de voir, et à qui d'autre ! C'est tout ce que vous avez à dire, ou vous voulez ajouter quelque chose ?") +"";
			link.l1 = ""+ GetSexPhrase("Allons, Jackman, quelles menaces ? Je vous rappelais seulement que tout est entre les mains de la Providence.","C'est tout. Allez, Jackman.") +"";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_6";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_6":
			DialogExit();
			NextDiag.CurrentNode = "First time"; // Gregg: было =TempNode — залипало на ноде 1, Джекман выгонял повторно и плодил запись @11
			DoFunctionReloadToLocation("Pirates_town", "reload", "reload3", "Andre_Abel_Quest_After_First_Jackman_Dialog");
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_7":
			dialog.text = "Encore vous ? Si vous ne m'apportez pas l'argent d'Abel, mieux vaut faire demi-tour tout de suite et ne pas me mettre en rogne.";
			link.l1 = "Pas d'argent, mais une lettre de Morgan.";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_8";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_8":
			dialog.text = "Hum, une lettre de Morgan ? Eh bien, donnez-la !";
			link.l1 = "Tenez...";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_9";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_9":
			dialog.text = "Diable ! Encore cet Abel ?! Bon, qu'il vive pour l'instant, j'ai des affaires plus importantes.";
			link.l1 = "Voilà qui est parfait.";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_10";
			TakeItemFromCharacter(PChar, "letter_1");
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_10":
			dialog.text = "Dites simplement "+ GetSexPhrase("à votre ami","à ce type") +" que je ne pardonne pas les offenses ! Alors qu'il ne croise pas mon regard, s'il tient à la vie..."+ GetSexPhrase(" Et maintenant, disparaissez, vous et votre Abel !","") +"";
			link.l1 = "Je transmettrai tout tel quel. "+ GetSexPhrase("Portez-vous bien","Au revoir, Jackman") +".";
			link.l1.go = "Andre_Abel_Quest_Jackman_Dialog_11";
		break;

		case "Andre_Abel_Quest_Jackman_Dialog_11":
			DialogExit();
			NextDiag.TempNode = "First time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddQuestRecord("Andre_Abel_Quest", "22");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			PChar.QuestTemp.Andre_Abel_Quest_Complete = true;
		break;

		//*************************** Генератор "The Captain's order is a Ransom" **********************
		case "CapComission1":
			dialog.text = "Ho ho. Vous croyez que je n'ai qu'un seul prisonnier ? Dites-moi qui exactement vous avez en tête.";
			link.l1 = pchar.GenQuest.CaptainComission.SlaveName + ". Il est chez vous ?";
			link.l1.go = "CapComission2";
		break;

		case "CapComission2":
			DeleteAttribute(pchar,"GenQuest.CaptainComission.toMayor");
			if(CheckAttribute(pchar,"GenQuest.CaptainComission.DaysLeft"))
			{
				dialog.text = "Il y était. Je l'ai vendu à ce maudit planteur de la Barbade, le colonel Bishop, qui est passé la semaine dernière.";
				link.l1 = "Bon sang...";
				link.l1.go = "CapComission2_1";
			}
			else
			{
				dialog.text = "Ah, enfin. Je pensais le vendre à ce maudit planteur de la Barbade, il doit passer d'ici une ou deux semaines... Vous avez apporté la rançon ?";
				link.l1 = "וcoutez, Jackman, voilà l'affaire... En somme, je n'ai pas assez d'argent. Mais je suis prêt à payer de ma personne.";
				link.l1.go = "CapComission2_2";
				if(makeint(pchar.money) > 150000)
				{
					link.l2 = "Heureusement que vous ne l'avez pas vendu. Voici l'argent : 150 000 pièces d'or. Oם puis-je le récupérer ?"
					link.l2.go = "CapComission2_3";
				}
			}
		break;

		case "CapComission2_1":
			dialog.text = "Vous avez traîné trop longtemps... Au fait, quel lien avez-vous avec cet esclave ? Je me souviens avoir demandé une rançon à sa famille.";
			link.l1 = "Oui, je viens de la part de sa famille.";
			link.l1.go = "CapComission2_11";
		break;

		case "CapComission2_11":
			dialog.text = "Eh bien, vous arrivez trop tard, que voulez-vous que j'y fasse ?";
			link.l1 = "Dites-moi, combien l'avez-vous vendu, si ce n'est pas un secret ?";
			link.l1.go = "CapComission2_12";
		break;

		case "CapComission2_12":
			dialog.text = "Euh, ce n'est pas un secret, bien sמr, mais je ne vous le dirai pas. Sinon, vous allez rire, ha ha ha ha... Bon, au revoir.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddQuestRecord("CaptainComission1", "10");
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			CaptainComission_GenerateManager();
		break;

		case "CapComission2_2":
			if(rand(1) == 0)
			{
				dialog.text = "Hum hum... J'ai bien une affaire... Je ne sais même pas par oם commencer... En somme, il faut couler un pirate arrogant.";
				link.l1 = "On ne pourrait pas le supprimer dans la jungle ?";
				link.l1.go = "CapComission2_2_1";
			}
			else
			{
				dialog.text = "Alors, " + pchar.name + ", vous savez bien que ce n'est pas comme ça qu'on fait. Revenez avec l'argent, et vous aurez votre petit protégé, héhé.";
				link.l1 = "Eh bien, à plus tard.";
				link.l1.go = "CapComission2_4";
			}
		break;

		case "CapComission2_2_1":
			dialog.text = "Eh bien, vous savez, ce n'est pas comme ça qu'on règle les affaires sérieuses... Je n'ai pas besoin de sa mort, je dois décourager les trop zélés de lorgner ma part du butin. Quoique, s'il finit chez les poulpes, je n'en serai pas chagriné.";
			link.l1 = "Pourquoi n'envoyez-vous pas vos hommes à ses trousses ?";
			link.l1.go = "CapComission2_2_2";
		break;

		case "CapComission2_2_2":
			CaptainComission_GetRandomShore();
			pchar.GenQuest.CaptainComission.ShipName1 = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.GenQuest.CaptainComission.ShipName2 = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.GenQuest.CaptainComission.UnknownPirateName = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			sLoc = XI_ConvertString(pchar.GenQuest.CaptainComission.Island + "Abl");
			dialog.text = "Hum... En somme, un certain " + GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.UnknownPirateName, NAME_NOM) + " a convaincu quelques pirates que dans notre cachette, près de " + XI_ConvertString(pchar.GenQuest.CaptainComission.Island.Shore + "Gen") + " se trouve aussi leur part. Ils ont récemment levé l'ancre sur deux navires, '" + pchar.GenQuest.CaptainComission.ShipName1 + "' et '" + pchar.GenQuest.CaptainComission.ShipName2 + "', cap sur " + sLoc + ". Vous comprenez maintenant pourquoi je ne peux pas confier cette affaire à mes hommes ?";
			link.l1 = "Compris. Et de combien de temps est-ce que je dispose ?";
			link.l1.go = "CapComission2_2_3";
		break;

		case "CapComission2_2_3":
			dialog.text = "Je pense 12 à 15 jours, pas plus. Il m'importe qu'ils n'aient pas le temps d'atteindre la cachette, sinon il n'y aura plus aucun intérêt à les couler avec une cargaison de valeur à bord. Mieux vaut qu'ils l'amènent ici.";
			link.l1 = "D'accord, je prends cette affaire. Je vais essayer d'arriver à temps.";
			link.l1.go = "CapComission2_2_4";
		break;

		case "CapComission2_2_4":
			AddQuestRecord("CaptainComission1", "24");
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			AddQuestUserData("CaptainComission1", "sShipName1", pchar.GenQuest.CaptainComission.ShipName1);
			AddQuestUserData("CaptainComission1", "sShipName2", pchar.GenQuest.CaptainComission.ShipName2);
			AddQuestUserData("CaptainComission1", "sShoreName", XI_ConvertString(pchar.GenQuest.CaptainComission.Island.Shore + "Abl"));
			AddQuestUserData("CaptainComission1", "sShoreType", XI_ConvertString(GetIslandByArealName(pchar.GenQuest.CaptainComission.Island) + "Dat"));
			pchar.quest.CapComission_PirateAttack.win_condition.l1 = "location";
            pchar.quest.CapComission_PirateAttack.win_condition.l1.location = pchar.GenQuest.CaptainComission.Island;
            pchar.quest.CapComission_PirateAttack.function = "CaptainComission_GeneratePirateShips";
			SetFunctionTimerCondition("CaptainComission_PirateShipsOver", 0, 0, 15, false);
			pchar.GenQuest.CaptainComission.PirateShips = "goaway";
			DialogExit();
		break;

		case "CapComission2_3":
			dialog.text = "Ne vous inquiétez pas. Mes hommes vous l'amèneront à bord. Qui est-il pour vous ?";
			link.l1 = "Personne. Je rends service à un membre de sa famille.";
			link.l1.go = "CapComission2_31";
		break;

		case "CapComission2_31":
			dialog.text = "Ah, très bien. J'étais déjà contrarié d'avoir bradé votre homme à si bas prix. Ha ha ha ha... Bon, au revoir.";
			link.l1 = "Bonne journée.";
			link.l1.go = "CapComission2_32";
		break;

		case "CapComission2_32":
			AddQuestRecord("CaptainComission1", "9");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City));
			addMoneyToCharacter(pchar, -150000);
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission2_4":
			if(!CheckAttribute(pchar,"GenQuest.CaptainComission.RepeatSpeak"))
			{
				AddQuestRecord("CaptainComission1", "31");
				AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			}
			pchar.GenQuest.CaptainComission.RepeatSpeak = true;
			DialogExit();
		break;

		case "CapComission3":
			dialog.text = "Alors, " + GetFullName(pchar) + ", vous avez envoyé mon copain par le fond ? Hé hé hé...";
			if(pchar.GenQuest.CaptainComission.PirateShips == "goaway")
			{
				link.l1 = "Non. Je n'ai pas eu le temps de les rattraper. Et je ne les ai pas croisés sur le chemin du retour.";
				link.l1.go = "CapComission4";
			}
			if(pchar.GenQuest.CaptainComission.PirateShips == "died")
			{
				link.l1 = "Oui, comme convenu : je l'ai envoyé nourrir les requins.";
				link.l1.go = "CapComission5";
			}
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PirateShips");
		break;

		case "CapComission4":
			dialog.text = "Bon sang ! Rattrapés ou pas, quelle différence maintenant ? Eh bien, que proposez-vous ensuite ?";
			link.l1 = "Vous n'auriez pas une mission plus simple ?";
			link.l1.go = "CapComission4_1";
			link.l2 = "וcoutez, Jackman, cédez-moi ce prisonnier moins cher...";
			link.l2.go = "CapComission4_2";
		break;

		case "CapComission4_1":
			dialog.text = "Non.";
			link.l1 = "...Eh bien, alors, portez-vous bien...";
			link.l1.go = "CapComission4_3";
		break;

		case "CapComission4_2":
			dialog.text = "Moins cher ?!! Je viens de perdre ma cachette à cause de votre lenteur ! Et maintenant, je peux le céder plus cher ! Prenez-le pour 200 000 si vous voulez.";
			link.l1 = "C'est cher... Au revoir...";
			link.l1.go = "CapComission4_4";
			if(sti(pchar.money) >= 200000)
			{
				link.l2 = "Bon sang, tenez, voilà votre argent.";
				link.l2.go = "CapComission4_5";
			}
		break;

		case "CapComission4_3":
			ChangeCharacterReputation(pchar, -2);
			AddQuestRecord("CaptainComission1", "27");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_DAT));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PirateShips");
			DialogExit();
		break;

		case "CapComission4_4":
			ChangeCharacterReputation(pchar, -2);
			AddQuestRecord("CaptainComission1", "28");
			AddQuestUserData("CaptainComission1", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PirateShips");
			DialogExit();
		break;

		case "CapComission4_5":
			dialog.text = "Vous pouvez emmener le crève-la-faim...";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "CapComission4_6";
		break;

		case "CapComission4_6":
			addMoneyToCharacter(pchar, -200000);
			AddQuestRecord("CaptainComission1", "29");
			AddQuestUserData("CaptainComission1", "sName", ChangeNameCase(NAMETYPE_MAIN, pchar.GenQuest.CaptainComission.PirateName, NAME_NOM));
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PirateShips");
			pchar.GenQuest.CaptainComission.SlaveAddMoney = true;
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission5":
			dialog.text = "Ho ho ! Voilà du travail ! Prenez votre petit protégé et portez-vous bien.";
			link.l1 = "Merci. Portez-vous bien.";
			link.l1.go = "CapComission5_1";
		break;

		case "CapComission5_1":
			AddQuestRecord("CaptainComission1", "34");
			AddQuestUserData("CaptainComission1", "sName", pchar.GenQuest.CaptainComission.SlaveName);
			AddQuestUserData("CaptainComission1", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.CaptainComission.City + "Gen"));
			AddQuestUserData("CaptainComission1", "sCharName", pchar.GenQuest.CaptainComission.Name);
			DeleteAttribute(pchar,"GenQuest.CaptainComission.PirateShips");
			DialogExit();
			AddDialogExitQuestFunction("CaptainComission_GeneratePassengerSlave");
		break;

		case "CapComission6":
			dialog.text = "Vous avez apporté la rançon ? Je ne plaisantais pas quand j'ai dit que je le vendrais aux planteurs.";
			link.l1 = "וcoutez, "+ NPChar.name +", voilà l'affaire... En somme, je n'ai pas assez d'argent. Mais je suis prêt à payer de ma personne.";
			link.l1.go = "CapComission2_2";
			if(makeint(pchar.money) > 150000)
			{
				link.l2 = "Heureusement que vous ne l'avez pas vendu. Voici l'argent : 150 000 pièces d'or. Oם puis-je le récupérer ?"
				link.l2.go = "CapComission2_3";
			}
		break;

		// ============== Грабёж среди бела дня, попытка залезть в сундуки =========================
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Un vol en plein jour !!! Qu'est-ce qui se passe ?! Attendez un peu, "+ GetSexPhrase("l'ami","ma petite") +"...", "Hé, qu'est-ce que vous faites là ?! Pas question, vous avez décidé de me voler ? Eh bien, vous êtes fini...", "Attendez, oם allez-vous ? Vous êtes un voleur ! Eh bien, considérez que vous êtes cuit, ordure...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "PL_Q3_fight";
		break;

		// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		case "AngryRepeat_1":
            dialog.text = RandPhraseSimple(""+ GetSexPhrase("Fichez","Fichez") +" le camp d'ici !", "Sortez de chez moi !");
			link.l1 = "Ah...";
		    link.l1.go = "AngryExitAgainWithOut";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся с Джекменом через 10 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "Vous ne devriez pas me distraire de mes affaires avec des appels creux. Désormais, le résultat pourrait être plus fâcheux...";
        			link.l1 = "J'ai compris.";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
            }
    	break;
		case "AngryRepeat_2":
            dialog.text = RandPhraseSimple("Vous m'avez vraiment fatigué, je ne vous parle plus.", "Je ne veux pas parler avec vous, alors vous feriez mieux de ne pas m'embêter.");
			link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Hum, eh bien...");
		    link.l1.go = "AngryExitAgain";
            if (CheckAttribute(npchar, "angry.terms")) //примиряемся с Джекменом через 10 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms))
                {
         			dialog.text = "J'espère qu'à l'avenir, vous ne m'ennuierez pas avec des conversations creuses, sinon je devrai vous tuer. J'avoue que cela me serait très désagréable.";
        			link.l1 = "Jackman, vous pouvez être sמr que je ne le ferai pas...";
        			link.l1.go = NextDiag.TempNode;
        			CharacterDelAngry(npchar);
                }
            }
    	break;
		case "AngryExitAgain":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
		break;
		case "AngryExitAgainWithOut":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
            DoReloadCharacterToLocation("Pirates_town","reload","reload3");
		break;
		// <<<<<<<<<<<<============= блок нод angry =============================

		// ======================== Чёрные паруса ===============>>>>>>>>>>>>>>>
		case "Jackman_Defeated":
			sld = CharacterFromID("gatri_temp");
			sld.location.locator = "goto6";

			dialog.text = "Vous venez vous moquer de moi ?";
			link.l1 = "Pas du tout. Je me demande simplement pourquoi Guthrie vous a laissé la vie sauve.";
			link.l1.go = "Jackman_Defeated_1";
		break;
		case "Jackman_Defeated_1":
			dialog.text = "Cette garce rusée veut faire de moi un dirigeant fantoche. Elle sait que les Frères se disperseront en apprenant ma mort, parce qu'ils ne suivront certainement pas une femme"+ GetSexPhrase(".","... sans vouloir vous offenser.") +" Même une femme aussi dure que Guthrie. Mais ainsi, elle peut tout diriger à travers moi.";
			link.l1 = "Et cet arrangement vous convient ?";
			link.l1.go = "Jackman_Defeated_2";
		break;
		case "Jackman_Defeated_2":
			dialog.text = "Vous parlez ! Oui, j'écraserai cette catin contre le mur à la première occasion ! Ne croyez pas que Jackman ait renoncé, je reprendrai ce qui m'appartient.";
			link.l1 = "Je vous conseille de baisser la voix, sinon vous révélerez tous vos plans à Guthrie. Bon, au revoir.";
			link.l1.go = "Jackman_Defeated_exit";
		break;
		case "Jackman_Defeated_exit":
			npchar.Dialog.Filename = "Mayor\Jackman.c";
			NextDiag.CurrentNode = "I_know_you_good";
            DialogExit();

			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_3_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;
		// <<<<<<<<<<<<============= Чёрные паруса =============================

		//==> Gregg: Чёрная Орхидея, глава 5 - награда за Левинсона и след пятой части Меритора
		// Вход - ссылка в узлах "First time" и "I_know_you_good" при PChar.DestinyGift == "22".
		// Логика - Program\Quests\reaction_functions\blackorchid.c
		case "BO_Jackman_1":
			dialog.text = "Levinson ? Ha ! En voilà une nouvelle. Et oם l'avez-vous déniché ?";
			link.l1 = "Dans votre propre ville. Il louait la chambre à l'étage de la taverne et ne mettait jamais le nez dehors.";
			link.l1.go = "BO_Jackman_2";
		break;

		case "BO_Jackman_2":
			dialog.text = "Juste sous mon nez, donc... Mes gars ont retourné toute l'île et ratissé chaque baie, pendant qu'il payait sa pension à deux pas de ma résidence. Très bien. Jackman tient parole : dix mille pour Levinson, comme promis.";
			link.l1 = "Merci. Et encore une question, si vous avez une minute. Levinson portait sur lui une vieille plaque sculptée, un morceau brisé. Avez-vous entendu parler d'une pièce semblable entre d'autres mains ?";
			link.l1.go = "BO_Jackman_3";
			// Gregg: защита от повторной выплаты - до смены состояния узел можно открыть снова
			if (!CheckAttribute(PChar, "DestinyGift.JackmanPaid"))
			{
				PChar.DestinyGift.JackmanPaid = true;
				AddMoneyToCharacter(PChar, 10000);
			}
		break;

		case "BO_Jackman_3":
			dialog.text = "Oui. Il y avait un Espagnol, Bernaldinio Toranger, capitaine du Vulture. Il transportait des cargaisons à travers tout l'archipel, et aucun des nכtres n'a jamais réussi à le prendre : il échappait à toute poursuite comme par magie, et ceux qui le rattrapaient ne revenaient jamais. On disait que sa chance n'était pas la sienne, mais achetée, et qu'il la portait autour du cou. Peut-être mentait-on. Et puis il a tout simplement disparu : il a pris la mer, et ni lui ni le Vulture ne sont jamais revenus.";
			link.l1 = "Et oם dois-je le chercher maintenant ?";
			link.l1.go = "BO_Jackman_4";
		break;

		case "BO_Jackman_4":
			dialog.text = "Ne le cherchez pas, lui ; cherchez ceux qui se souviennent de lui. Un marchand ne peut pas vivre sans boutiquiers : renseignez-vous dans les colonies espagnoles, dans les magasins. Ils se souviennent de chaque homme qui leur a apporté des marchandises, et de tous ceux qui naviguaient avec lui. Maintenant, dehors, j'ai du travail par-dessus la tête.";
			link.l1 = "א la revoyure, Jackman.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftFindFiveMeritorChapter");
		break;
		//<== Gregg: Чёрная Орхидея


		// Gregg: The Black Orchid, chapter 7 - the Little Mongrel -->
		case "BO_SM_Jackman_1":
			dialog.text = "...(cesse de sourire)... Et que savez-vous d'elle ?";
			link.l1 = "Que ses équipages meurent. Tous, d'un seul coup. Pourquoi avez-vous pâli, Jackman ?";
			link.l1.go = "BO_SM_Jackman_2";
		break;

		case "BO_SM_Jackman_2":
			dialog.text = "Dix hommes dans les Caraïbes connaissent cette coque, et tous les dix tiennent leur langue. Lequel d'entre eux vous envoie ?";
			link.l1 = "Alehon Kendart.";
			link.l1.go = "BO_SM_Jackman_3";
		break;

		case "BO_SM_Jackman_3":
			dialog.text = "Le savant. Je me souviens de lui. Il court l'archipel en fourrant son nez là oם on ne le veut pas.";
			link.l1 = "Il fourre son nez partout, je vous l'accorde. Que voulez-vous pour elle ?";
			link.l1.go = "BO_SM_Jackman_4";
		break;

		case "BO_SM_Jackman_4":
			dialog.text = "Rien du tout. Je ne l'ai pas. Je l'ai cédée à Bill le Sanglant il y a une dizaine de jours ...(ricane)... paix à son âme.";
			link.l1 = "Paix à son âme, vraiment ? Combien de temps l'a-t-il gardée ?";
			link.l1.go = "BO_SM_Jackman_5";
		break;

		case "BO_SM_Jackman_5":
			dialog.text = "Bill est vivant, c'est son équipage qui ne l'est plus. Il l'a amarrée à Willemstad, et deux jours plus tard, on l'a enlevée de ses amarres. Juste sous le fort.";
			link.l1 = "Sous le fort. Les Hollandais ont de bonnes vigies.";
			link.l1.go = "BO_SM_Jackman_6";
		break;

		case "BO_SM_Jackman_6":
			dialog.text = "דa, demandez-le aux Hollandais. Je dors mieux depuis qu'elle n'est plus ici.";
			link.l1 = "C'est déjà ça. Dormir tranquille coמte cher, ces temps-ci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToCuracao");
		break;
		// Gregg: the Little Mongrel <--
	}
}
