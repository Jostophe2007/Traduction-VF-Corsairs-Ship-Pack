
void ProcessDialogEvent()
{
 	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\ItemTrader\" + NPChar.City + "_ItemTrader.c";
    if (!HasCityDialogFile("ItemTrader", NPChar.City, "_ItemTrader.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\ItemTrader\DefaultCity_ItemTrader.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\ItemTrader\DefaultCity_ItemTrader.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
			if (npchar.angry.name == "AscoldMerchant") Dialog.CurrentNode = "AngryQuest_AscoldMerchant";
        }
    }
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================
	switch(Dialog.CurrentNode)
	{
		// -----------------------------------Диалог первый - первая встреча
  		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

  		case "First time":
			//зачарованный город -->
			if (pchar.questTemp.MC == "toCaracas" && npchar.city == "Caracas")
			{
				dialog.text = LinkRandPhrase("Je commerce pour mon propre compte ici et je ne veux rien savoir des querelles. Ce ne sont pas mes affaires.",
					"Oui, il y a de l'agitation en ville, mais bon...",
					"Je ne pense pas que ces troubles nuisent à mon commerce. C'est le tavernier qui doit s'inquiéter.");
				link.l1 = "Je vois.";
				link.l1.go = "exit";
				break;
			}
			if (pchar.questTemp.MC == "toCaracasPadre" || pchar.questTemp.MC == "toCaracasTavern")
			{
				dialog.text = "On dit que vous êtes allé dans la taverne de ce loup-garou ! Alors, ça se passe comment ?";
				link.l1 = "Pas du tout...";
				link.l1.go = "exit";
				break;
			}
			//<-- зачарованный город
			
			//Загадочный остров -->
			if (CheckAttribute(pchar, "MysteriousIslandTorgovets"))
			{
				PChar.quest.MysteriousIslandWaitAction.win_condition.l1 = "Timer";
				PChar.quest.MysteriousIslandWaitAction.win_condition.l1.date.hour = sti(GetTime() + 1);
				PChar.quest.MysteriousIslandWaitAction.win_condition.l1.date.day = GetAddingDataDay(0, 0, 0);
				PChar.quest.MysteriousIslandWaitAction.win_condition.l1.date.month = GetAddingDataMonth(0, 0, 0);
				PChar.quest.MysteriousIslandWaitAction.win_condition.l1.date.year = GetAddingDataYear(0, 0, 0);
				PChar.quest.MysteriousIslandWaitAction.function = "MysteriousIslandWaitAction";
				DeleteAttribute(pchar, "MysteriousIslandTorgovets");
			}
			//<-- Загадочный остров

			dialog.text = NPCharSexPhrase(npchar, "Vous voulez acheter de l'équipement pour vous ou vos officiers, capitaine ? Alors vous êtes à la bonne adresse !", "Oh, capitaine, je savais que vous viendriez me voir !.. Je peux vous proposer de l'équipement pour vous et vos officiers, ainsi que bien d'autres choses utiles.");
			//--> Sinistra. Пролог Анжелика Тич
			if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")
			{
   				dialog.text = NPCharSexPhrase(npchar, "Approchez, choisissez, señorita. Tout est de première qualité !", "Oh, señorita, je savais que vous viendriez me voir !.. Choisissez sans vous gêner !");
			}
			if (CheckAttribute(npchar, "isFence"))
			{
				dialog.text = "Psst, "+ GetSexPhrase("l'ami","ma belle") +"... Vous cherchez des ingrédients rares pour l'artisanat ? J'en ai à revendre. Mais je ne montre pas ma marchandise à n'importe qui, ni pour quelques sous. Et ne demandez pas d'oם elle vient.";
				if (!CheckAttribute(npchar, "fenceFee")) npchar.fenceFee = 3 + dRand3(7); // LEO: access fee - 3-10 gold ingots (daily dRand, not save-scummable)
			}
			link.l1 = "Montrez-moi ce que vous avez là.";
			link.l1.go = "Trade_exit";
			// LEO: the fence shows his goods for gold ingots, or free under threat (if the player is a bloody killer)
			if (CheckAttribute(npchar, "isFence"))
			{
				link.l1.go = "Fence_Access";
				if (CheckAttribute(npchar, "fencePaid")) link.l1.go = "Trade_exit"; // LEO: already paid/dealt this generation - don't gate goods again
				if (sti(pchar.reputation) <= 10)
				{
					link.l7 = "Je vais te couper en deux sur-le-champ, chien ! Montre-moi ta camelote !";
					link.l7.go = "Fence_Threat";
				}
			}

   			link.l2 = "Je suis sur une autre affaire.";
			link.l2.go = "quests";
			// the fence buys any goods, no questions - a loophole to offload freight cargo without a guild debt
			if (CheckAttribute(npchar, "isFence") && Freight_CargoAboard())
			{
				link.l5 = "J'ai une certaine... cargaison. Ne demandez pas à qui elle est. דa vous intéresse ?";
				link.l5.go = "FenceFreight_Offer";
			}
			// cargo of an ALREADY-OVERDUE freight (guild debt active, creditors chasing) - offload to the fence to shake them off (risky)
			if (CheckAttribute(npchar, "isFence") && Freight_DebtCargoAboard())
			{
				link.l6 = "La guilde me cherche des noises à cause d'une certaine cargaison. Si elle venait à disparaître, et que vous teniez votre langue, vous la prendriez ?";
				link.l6.go = "FenceDebt_Offer";
			}
			// debt cargo is aboard but NOT the full load (rats ate some / sold part) - fence explains he won't take a partial load
			else if (CheckAttribute(npchar, "isFence") && Freight_DebtCargoPartial())
			{
				link.l6 = "La guilde me harcèle à cause d'une cargaison... le problème, c'est qu'elle n'est pas toute arrivée à bon port.";
				link.l6.go = "FenceDebt_Short";
			}
			//--> eddy. Аскольд, перехват на рендомного перца
			if (pchar.questTemp.Ascold == "Seek_powder" && !CheckAttribute(npchar, "quest.answer_2"))
			{
   				link.l4 = LinkRandPhrase("Avez-vous déjà vu une chose comme de la poudre de momie ?", "Vous vendez de la poudre de momie ?", "Dites, vous savez oם l'on peut se procurer de la poudre de momie ?");
				link.l4.go = "AscoldMerchant";
			}
			//<-- eddy. Аскольд, перехват на рендомного перца
			link.l3 = "Merci, ça ne m'intéresse pas.";
			link.l3.go = "exit";

			NextDiag.TempNode = "First time";
		break;

		// --- offloading freight cargo to the fence (scam loophole) ---
		case "FenceFreight_Offer":
			if (!Freight_CargoAboard())
			{
				dialog.text = "Hein ? Vous n'avez pas de cargaison. Ne me faites pas perdre mon temps.";
				link.l1 = "Mon erreur.";
				link.l1.go = "First time";
				break;
			}
			int ffPay = Freight_FencePrepare();
			dialog.text = "Hum... un joli lot. Je vous en donne "+ FindRussianMoneyString(ffPay) +" – et on se quitte comme si on ne s'était jamais vus. Marché conclu ?";
			link.l1 = "Marché conclu.";
			link.l1.go = "FenceFreight_Done";
			link.l2 = "J'ai changé d'avis.";
			link.l2.go = "First time";
		break;

		case "FenceFreight_Done":
			Freight_FenceSell();
			if (CheckAttribute(pchar, "GuildDebt"))
			{
				dialog.text = "L'argent est à vous. Mais... on dit que la guilde n'aime pas voir sa cargaison réapparaître ailleurs. Ce ne sont pas mes affaires, "+ GetSexPhrase("l'ami","ma belle") +".";
			}
			else
			{
				dialog.text = "Voici votre argent. Je n'ai vu aucune cargaison, je ne vous connais pas. א la revoyure, "+ GetSexPhrase("l'ami","ma belle") +".";
			}
			link.l1 = "א la revoyure.";
			link.l1.go = "exit";
		break;

		// --- offloading the cargo of an ALREADY-OVERDUE freight (debt active) to the fence: burying the evidence ---
		case "FenceDebt_Offer":
			if (!Freight_DebtCargoAboard())
			{
				dialog.text = "Quelle cargaison ? Vous n'avez rien de tel. Allez cuver votre vin.";
				link.l1 = "Mon erreur.";
				link.l1.go = "First time";
				break;
			}
			int fdPay = Freight_FenceDebtPrepare();
			dialog.text = "Des marchandises brמlantes, avec la guilde aux trousses... Bon, je prends le risque. Je vous en donne "+ FindRussianMoneyString(fdPay) +", et elle disparaît pour de bon, comme si elle n'avait jamais existé. Marché conclu ?";
			link.l1 = "Marché conclu. Prenez-la.";
			link.l1.go = "FenceDebt_Done";
			link.l2 = "J'ai changé d'avis.";
			link.l2.go = "First time";
		break;

		case "FenceDebt_Done":
			Freight_FenceSellDebt();
			if (CheckAttribute(pchar, "GuildDebt")) // the fence snitched - debt remains and grew
			{
				dialog.text = "L'argent est à vous... mais je vais être franc : une cargaison comme celle-là, les bonnes personnes en entendent vite parler. דa ne me regarde pas, "+ GetSexPhrase("l'ami","ma belle") +".";
			}
			else // debt cleared
			{
				dialog.text = "C'est fait. Il n'y a jamais eu de cargaison, je ne vous ai jamais vu. Que la guilde coure après le vent. א la revoyure, "+ GetSexPhrase("l'ami","ma belle") +".";
			}
			link.l1 = "א la revoyure.";
			link.l1.go = "exit";
		break;

		// debt cargo aboard but NOT the full load (rats ate some / sold part) - fence won't take a partial load, needs all of it per the invoice
		case "FenceDebt_Short":
			int gShort = sti(pchar.GuildDebt.GoodsType);
			dialog.text = "Oh non. La guilde compte sa cargaison jusqu'à la dernière balle, d'après le connaissement. Prenez-en la moitié, et c'est vous qu'on accusera du manque, et moi avec. Apportez tout ce qui figure sur les papiers de la dette ("+ sti(pchar.GuildDebt.GoodsQty) +" "+ GetGoodsNameAlt(gShort) +"), et ensuite on en reparlera.";
			link.l1 = "Compris. J'apporterai tout.";
			link.l1.go = "First time";
		break;

		case "Trade_exit":
            if (!CheckAttribute(npchar, "isFence") && CheckNPCQuestDate(npchar, "Item_date")) // fence stock is fixed (set once on spawn), no daily refresh
			{
				SetNPCQuestDate(npchar, "Item_date");
				GiveItemToTrader(npchar);
			}
			if (CheckAttribute(npchar, "isFence")) LAi_SetStayType(npchar); // fence stands still during trade (resumes wandering when window closes, see IDoExit)
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(npchar);
		break;

		// --- LEO: fence, access to goods for gold ingots (player's pocket first, then cabin chest) ---
		case "Fence_Access":
			int fAcc = sti(npchar.fenceFee);
			if (Fence_CountIngots() >= fAcc)
			{
				dialog.text = "Un coup d'œil sur une marchandise pareille coמte "+ fAcc +" lingots d'or. Marché conclu ?";
				link.l1 = "Tenez, "+ fAcc +" lingots.";
				link.l1.go = "Fence_Pay";
			}
			else
			{
				dialog.text = "Un coup d'œil sur une marchandise pareille coמte "+ fAcc +" lingots d'or. Et vous n'en avez pas autant. Revenez avec de l'or.";
			}
			link.l2 = "Trop cher. Une autre fois.";
			link.l2.go = "First time";
		break;

		case "Fence_Pay":
			int fPaid = Fence_TakeIngots(sti(npchar.fenceFee)); // LEO: actually removes ingots (pocket->chest), returns amount taken
			npchar.fencePaid = true; // LEO: don't charge ingots again this fence generation
			Log_Info("Payé le receleur pour jeter un œil : "+ fPaid +" lingots d'or.");
			LAi_SetStayType(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(npchar);
		break;

		// --- LEO: fence, free look under threat (player is a bloody killer) ---
		case "Fence_Threat":
			dialog.text = "D'accord, d'accord, calmez-vous ! Tenez, regardez... Je vais tout vous montrer, mais rangez votre lame.";
			link.l1 = "Voilà qui est mieux.";
			link.l1.go = "Fence_ThreatOpen";
		break;

		case "Fence_ThreatOpen":
			npchar.fencePaid = true; // LEO: already intimidated this generation - stop gating goods
			LAi_SetStayType(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchItemsTrade(npchar);
		break;
		//=================== ноды квеста мэра. поиск шпиона на улице, опрос свидетеля ==================
		case "SeekSpy_Checking":
			dialog.text = "Oui, je vous le confirme, " + NPCharSexPhrase(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)], "c'est bien quelqu'un du coin.", "c'est bien quelqu'un du coin.");
			link.l1 = RandPhraseSimple("J'ai compris. Merci de votre aide.", "Tout est clair. Merci de votre aide.");
			link.l1.go = "SeekSpy_Checking_1";
		break;
		case "SeekSpy_Checking_1":
			switch (pchar.GenQuest.SeekSpy.Type)
			{
				case "guardian": LAi_SetGuardianTypeNoGroup(npchar); break;
				case "patrol":   LAi_SetPatrolTypeNoGroup(npchar);   break;
				case "citizen":  LAi_SetCitizenTypeNoGroup(npchar);  break;
				case "merchant": LAi_SetMerchantTypeNoGroup(npchar); break;
			}
			LAi_SetCitizenTypeNoGroup(&characters[sti(pchar.GenQuest.SeekSpy.BaseIdx)]);
			NextDiag.CurrentNode = "First Time";
			DialogExit();
		break;
		//Квест Аскольда. Базары с уличными торговцами
		case "AscoldMerchant":
			if(npchar.city == pchar.questTemp.Ascold.MerchantColony && npchar.location.locator == "merchant1")
			{
				dialog.text = "Euh, "+ GetSexPhrase("mon cœur", "ma chérie") +", vous n'êtes pas au bon endroit. Il faut aller voir les chamans indiens, ou les sorciers, comme on les appelle là-bas...";
				link.l1 = "Et oם les trouver ? Personne ne sait rien, ou bien on sait, mais on ne dit rien.";
				link.l1.go = "AscoldMerchant_5";
			}
			else
			{
				//BlackThorn: более внятный поиск порошка.
				if (!CheckAttribute(npchar, "quest.answer_1") && rand(2)==0)
				{
					npchar.quest.answer_1 = "true";
					npchar.quest.answer_2 = "true";
					if (NationNameGenitive(sti(npchar.nation)) != NationNameGenitive(sti(pchar.questTemp.Ascold.dialogNation)))
					{
						dialog.text = "Désolé, mais nous ne tenons pas ce genre d'article. Vous devriez vous renseigner dans les colonies de "+ NationNameGenitive(sti(pchar.questTemp.Ascold.dialogNation))+".";
						link.l2 = "Merci pour l'information.";
						link.l2.go = "exit";
					}
					else if (XI_ConvertString("Colony" + pchar.questTemp.Ascold.MerchantColony) != XI_ConvertString("Colony" + npchar.city))
					{
						dialog.text = "Je ne trompe pas mes clients et je ne vends pas de camelote, mais il paraît que dans la colonie de "+ XI_ConvertString("Colony" + pchar.questTemp.Ascold.MerchantColony) +" on peut trouver de tout, des philtres d'amour à la poudre de momie.";
					}
					else
					{
						dialog.text = "Je n'en ai pas, mais quelqu'un en vendait en ville, c'est sמr. Renseignez-vous auprès des autres marchands.";
					}
					link.l2 = "Merci pour l'information.";
					link.l2.go = "exit";
				}
				else
				{
					npchar.quest.answer_1 = "true";
			dialog.text = NPCStringReactionRepeat(LinkRandPhrase("De la poudre de momie ? Je ne sais pas ce qu'est une momie.", "De la poudre de quoi ? De momie ? Qu'est-ce que c'est ?", "De la poudre de momie ? Qu'est-ce que c'est que ce truc ?"),
                     LinkRandPhrase("Vous me reposez encore la question ?", "Vous remettez ça sur le tapis...", "Et encore cette poudre ?"),
                     LinkRandPhrase(NPCharSexPhrase(npchar, "Je vous ai déjà répondu ! Que voulez-vous de plus ?", "Je vous ai déjà répondu ! Que voulez-vous de plus ?"),
                                    NPCharSexPhrase(npchar, "Je vous ai déjà dit tout ce que je jugeais nécessaire. Encore ces questions bizarres ?", "Je vous ai déjà dit tout ce que je jugeais nécessaire. Encore ces drכles de questions ?"),
                                    "Encore ces drכles de questions ? Je n'ai rien à ajouter à ce que j'ai dit !"),
                     LinkRandPhrase("Encore ?!! Encore ?!!", "Je n'ai pas de mots !!! Encore ?!", "Vous me reparlez de cette maudite poudre ?!"), "quest", 10, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("C'est le corps embaumé d'un וgyptien mort il y a des millénaires.",
                                               "Oui, je vous le redemande. Vous vous êtes souvenu de quelque chose ?",
                                               "Je vous le redemande, quelque chose a peut-être changé...",
                                               "Oui, je vous le redemande.", npchar, Dialog.CurrentNode);
            link.l1.go = DialogGoNodeRepeat("AscoldMerchant_2", "AscoldMerchant_3", "AscoldMerchant_4", "", npchar, Dialog.CurrentNode);
				}
			}
		break;

		case "AscoldMerchant_2":
			dialog.text = LinkRandPhrase("Non, nous n'avons pas besoin de ce genre d'article. Je n'en ai jamais vu. Et d'ailleurs, vous êtes le premier à me demander une marchandise aussi étrange. Je ne pense pas que la Sainte וglise apprécierait le commerce de tels objets. Ce n'est pas une plaisanterie, vous savez...",
                     NPCharSexPhrase(npchar, "Non, je n'ai jamais eu ce genre de marchandise. Et même si j'en avais eu, je ne l'aurais pas prise. Je vais régulièrement à l'église, je ne pense pas que l'Inquisition apprécierait ce genre de commerce.", "Non, je n'ai jamais eu ce genre de marchandise. Et même si j'en avais eu, je ne l'aurais pas prise. Je suis un bon paroissien, je ne pense pas que l'Inquisition apprécierait ce genre de commerce."),
                     NPCharSexPhrase(npchar, "Je n'ai jamais rien vu de tel. Et c'est sans doute tant mieux. Si ma femme l'apprenait, elle courrait aussitכt chez les inquisiteurs...", "Je n'ai jamais rien vu de tel. Et c'est sans doute tant mieux. Mon mari ne serait pas ravi de me voir faire ce commerce..."));
			Link.l1 = "Ah oui ? Bon, d'accord, si c'est non, c'est non...";
			Link.l1.go = "exit";
		break;

		case "AscoldMerchant_3":
			dialog.text = LinkRandPhrase(NPCharSexPhrase(npchar, "Je n'ai rien oublié. Je ne sais rien de vos momies et je ne veux rien savoir. Et je ne vous conseille pas de vous en mêler. Sinon, on vous accusera de sorcellerie, on vous excommuniera...", "Je n'ai rien oublié du tout. Je ne sais rien de vos momies et je ne veux rien savoir. Et je ne vous conseille pas de vous en mêler. Sinon, on vous accusera de sorcellerie, on vous excommuniera..."),
                                    "Je me souviens parfaitement de tout. Mais je ne veux pas parler de momies. La Sainte Inquisition aimerait bien s'occuper de cette affaire...",
                                    NPCharSexPhrase(npchar, "Je me souviens très bien de tout. Eh bien, si ma femme avait été au courant de telles propositions, la Sainte Inquisition s'en serait occupée depuis longtemps...", "Je me souviens très bien de tout. Et je crois que je vais appeler mon mari..."));
			Link.l1 = "Argh !! Vous dites de drכles de choses. Enfin bon...";
			Link.l1.go = "exit";
		break;

		case "AscoldMerchant_4":
			dialog.text = LinkRandPhrase(NPCharSexPhrase(npchar, "Rien n'a changé, absolument rien !!! Je n'ai vu de mort égyptien ni entier ni en poudre !", "Rien n'a changé, absolument rien !!! Je n'ai vu de mort égyptien ni en entier ni en poudre !"),
                                    NPCharSexPhrase(npchar, "Absolument rien n'a changé : je n'ai vu aucun cadavre en poudre et, j'espère bien, je n'en verrai jamais.", "Absolument rien n'a changé : je n'ai vu aucun cadavre en poudre et, j'espère bien, je n'en verrai jamais. Et si vous continuez avec vos questions idiotes, j'appelle mon mari..."),
                                    NPCharSexPhrase(npchar, "Changé ?!! וcoutez, je me suis bien fait comprendre ! Ce n'est donc pas clair que je n'ai pas affaire aux morts, en poudre ou entiers ?!!", "Changé ?!! וcoutez, j'ai été parfaitement claire ! Ce n'est donc pas clair que je ne touche pas aux morts, en poudre ou entiers ?!!"));
			Link.l1 = NPCharSexPhrase(npchar, "Ne vous énervez pas comme ça. Calmez-vous, vous n'avez rien vu, vous n'avez rien vu...", "Ne vous énervez pas comme ça. Calmez-vous, vous n'avez rien vu, eh bien, vous n'avez rien vu...");
			Link.l1.go = "exit";
		break;

		case "AscoldMerchant_5":
			dialog.text = "Voilà... Et personne ne vous le dira. L'Inquisition peut vous traquer pour bien moins que ça. Et à plus forte raison pour cela. Qui voudrait payer sa langue trop longue de sa vie ?";
			link.l1 = "Oh... J'en ai vraiment besoin. Quelqu'un m'a passé commande, mais ça fait longtemps que je n'arrive pas à en trouver.";
			link.l1.go = "AscoldMerchant_6";
		break;

		case "AscoldMerchant_6":
			dialog.text = "Une commande, dites-vous ? Votre client ne serait pas un limier de l'Inquisition ?";
			link.l1 = "Non, il n'en a pas l'air... Un marchand respectable, d'un magasin respectable. Pourquoi ferait-il ça ?!";
			link.l1.go = "AscoldMerchant_7";
		break;

		case "AscoldMerchant_7":
			dialog.text = "Il n'en a vraiment pas l'air... Bon, je vais vous vendre la poudre. Mais n'en parlez à personne. Et sachez que je ne vous connais pas, et que je le nierai jusqu'au Jugement dernier.";
			link.l1 = "Eh bien, c'est compréhensible...";
			link.l1.go = "AscoldMerchant_8";
		break;

		case "AscoldMerchant_8":
			dialog.text = "Vous me devez mille pièces.";
			if (sti(pchar.money) >= 1000)
			{
				Link.l1 = "Ce n'est pas donné, mais je ne peux pas marchander ici. Tenez.";
    		    Link.l1.go = "exit";
    		    pchar.questTemp.Ascold = "PowderWasSeek";
    		    AddMoneyToCharacter(pchar, -1000);
    		    GiveItem2Character(Pchar, "Powder_mummie");
			}
			else
			{
				link.l1 = "Bon sang ! Je n'ai pas autant sur moi. Je vais chercher l'argent et je reviens tout de suite. Attention, ne la vendez pas pendant que je cours...";
				link.l1.go = "exit";
			}
		break;

// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		case "AngryQuest_AscoldMerchant":
Dialog.text = RandPhraseSimple("Je ne veux plus traiter avec vous.", "Je ne vous vendrai plus rien.");
			Link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez. Apparemment, vous n'avez pas besoin d'argent.", "La perte n'est pas bien grande...");
		    Link.l1.go = "AngryExitAgain";
		    //===>> квест Аскольда, розыск порошка мумии.
            if (pchar.questTemp.Ascold == "Seek_powder" && npchar.city == pchar.questTemp.Ascold.MerchantColony && npchar.location.locator == "merchant1")
            {
Dialog.text = "Vous êtes très insistant, apparemment vous avez vraiment besoin de cette poudre.";
    			Link.l1 = "C'est exact. Et maintenant, je veux savoir si vous en avez vraiment. Et ne vous inquiétez pas, tout restera entre nous.";
    		    Link.l1.go = "AngStep_1";
            }
            if (CheckAttribute(npchar, "angry.terms")) //мирилка по квесту Аскольда через 10 дней.
            {
                if (GetNpcQuestPastDayParam(npchar, "angry.terms") > sti(npchar.angry.terms) && pchar.questTemp.Ascold != "Seek_powder")
                {
Dialog.text = NPCharSexPhrase(npchar, "J'espère vraiment que vous n'allez pas m'ennuyer avec vos demandes étranges. Je crois que je suis prêt à faire affaire avec vous.", "J'espère vraiment que vous n'allez pas m'importuner avec ces horribles achats de cadavres. Je crois que je suis prête à commercer avec vous.");
        			Link.l1 = RandPhraseSimple("Parfait !", "Excellent !");
        			Link.l1.go = "First time";
        			CharacterDelAngry(npchar);
                }
            }
    	break;
////////////////////////////////////////////////////////////////////////////////////////////////
		case "AngryExitAgain":
            DialogExit();
            DeleteAttribute(npchar, "angry.ok")
		break;

		case "AngStep_1":
Dialog.text = "J'en ai, mais pas pour tout le monde...\nJe vais vous en vendre. Mille pièces, et elle est à vous.";
            if (sti(pchar.money) >= 1000)
            {
    			Link.l1 = "D'accord, voici votre argent.";
    		    Link.l1.go = "AngryExitAgain";
    		    pchar.questTemp.Ascold = "PowderWasSeek";
    		    CharacterDelAngry(npchar);
    		    AddMoneyToCharacter(pchar, -1000);
    		    GiveItem2Character(Pchar, "Powder_mummie");
            }
            else
            {
    			Link.l1 = "Je n'ai pas cette somme sur moi pour le moment. Dès que je l'aurai réunie, je reviendrai vous voir.";
    		    Link.l1.go = "AngryExitAgain";
            }
    	break;
// <<<<<<<<<<<<============= блок нод angry =============================
	}
}
