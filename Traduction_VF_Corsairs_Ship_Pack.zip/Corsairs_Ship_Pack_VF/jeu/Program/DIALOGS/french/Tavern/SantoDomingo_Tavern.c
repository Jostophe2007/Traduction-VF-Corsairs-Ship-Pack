// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr7RockBras_toSeekPlace")
			{
				dialog.text = "Posez vos questions, "+ GetSexPhrase("señor", "señorita") +".";
				link.l1 = "J'ai entendu dire qu'on avait réussi récemment à capturer Rock le Brésilien, ce pirate !";
				link.l1.go = "Step_F7_1";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_PK_IshemKoltso"))	// Квест "The Lost Ring"
            {
                link.l1 = "Je cherche une bague qui appartenait à... à l'un de mes amis. Une bague d'une certaine valeur. Et cette bague se trouve quelque part dans cette ville. Vous en avez peut-être entendu parler ? Un gros saphir serti dans de l'or.";
                link.l1.go = "IshemKoltso";
            }
			if(PChar.MysteriousIsland == "10" && PChar.MysteriousIsland.FindForser.Tavern == false && NPChar.City == "SantoDomingo")	//Квест "The Mysterious Island"
			{
				link.l1 = "Un certain Davy Forser est-il venu chez vous ?";
				link.l1.go = "MysteriousIsland_2";
			}
		break;
//******************** Фр.линейка, квест №7. Спасение Рока Бразильца ******************
 	 	case "Step_F7_1":
			dialog.text = NPCStringReactionRepeat("Oui, c'est vrai, c'est arrivé. Une chance inouïe, je vous le dis, "+ GetSexPhrase("señor", "señorita") +".", "Vous m'avez déjà interrogé sur le Brésilien.",
				          "Encore le Brésilien ?", "Eh bien, combien de temps allons-nous parler de ces pirates ? Parlons d'autre chose...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("C'est vrai, c'est vrai... Et qu'est-ce qu'on lui a fait ? On l'a sans doute étranglé sur place.", ""+ GetSexPhrase("Je vous l'ai demandé", "Je vous l'ai demandé") +" ? Eh bien, oui, sans doute...", "Oui, exactement, "+ GetSexPhrase("je vous l'ai demandé", "je vous l'ai demandé") +", désolé...", "On peut parler d'autre chose...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_F7_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_F7_2":
			dialog.text = "Mais que dites-vous là, "+ GetSexPhrase("señor", "señorita") +". On l'a amené et montré à tout le monde. Puis on l'a remis aux saints pères...";
			link.l1 = "Et pourquoi les saints pères en ont-ils besoin ?";
			link.l1.go = "Step_F7_3";
        break;
 	 	case "Step_F7_3":
			dialog.text = "Hé, "+ GetSexPhrase("señor", "señorita") +", ce ne sont pas des confesseurs. Ces saints pères-là sont des moines militants ! L'Inquisition...";
			link.l1 = "Ah, l'affaire est claire. Eh bien, merci, l'ami.";
			link.l1.go = "exit";
        break;
//******************** Квест "The Lost Ring" ******************
		case "IshemKoltso":
			dialog.text = "Hum... Un saphir, dites-vous ? Oui, je me souviens avoir vu une bague comme celle dont vous parlez. Une fille l'a ; vous la connaissez peut-être, en tout cas la plupart des marins la connaissent bien, hé hé. Elle s'appelle Francesca. Je n'ai jamais rencontré une fille plus sotte, pour être honnête. Un soldat lui a offert cette bague il y a quelques années. Il était peut-être encore plus sot qu'elle, parce que cette bague vaut beaucoup d'argent. Oui, c'est sans doute la bague que vous cherchez ; alors, vous voulez organiser un concours avec vos officiers, à qui boira le plus ?";
			link.l1 = "Excellente idée ! Je crois que je vais amener l'équipage. Attendez-moi ici, ne bougez pas, je reviens vite.";
			link.l1.go = "IshemKoltso_2";
        break;
		
		case "IshemKoltso_2":
			DialogExit();
			
			AddQuestRecord("PDM_Poteryanoe_Koltso", "3");
			AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
			DeleteAttribute(pchar, "questTemp.PDM_PK_IshemKoltso");

			sld = GetCharacter(NPC_GenerateCharacter("PDM_PK_Francheska", "BaynesDaughterSTOK", "woman", "woman", 10, SPAIN, -1, false));
			sld.name = "Francesca";
			sld.lastname = "";
			sld.city = "SantoDomingo";
			sld.location	= "SantoDomingo_Brothel";
			sld.location.group = "goto";
			sld.location.locator = "goto3";
			sld.dialog.filename   = "Quest\PDM\Poteryanoe_Koltso.c";
			sld.dialog.currentnode   = "Francheska";
			LAi_SetCitizenType(sld);
			LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
			LAi_SetImmortal(sld, true);
        break;
		
		// Загадочный остров -->
		case "MysteriousIsland_2":
			PChar.MysteriousIsland.FindForser.Tavern = true;
			dialog.text = "Davy Forser ? Jamais entendu parler.";
			link.l1 = LinkRandPhrase("Oh, désolé...", "Merci quand même.", "א bientכt.");
			link.l1.go = "exit";
		break;
		// Загадочный Остров <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

