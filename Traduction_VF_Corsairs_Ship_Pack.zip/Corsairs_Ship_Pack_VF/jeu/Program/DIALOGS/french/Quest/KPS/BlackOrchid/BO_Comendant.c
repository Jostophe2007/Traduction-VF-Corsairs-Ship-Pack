// Gregg: The Tortuga commandant, the patrol, the false mayor and his daughter - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Circulez.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(il vous détaille tous les deux)... Deux mendiants dans une maison fermée à clé. Curieux.";
			link.l1 = "Nous dormons ici. La maison est vide.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Vide, peut-être, mais pas à personne. Cette maison est à moi, et elle a été louée il y a quinze jours. ...(il s'approche)... Montrez-moi vos mains.";
			link.l1 = "...(tend ses paumes)... Regardez, s'il le faut.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "...(il regarde longuement, puis recule)... Pas les bonnes callosités. Très bien. Soyez partis d'ici demain matin.";
			link.l1 = "Nous partirons.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyDialogInShelterEnd");
		break;

		case "4":
			dialog.text = "Oם ça.";
			link.l1 = "א l'hכtel de ville. Mendier.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(avec un sourire narquois)... Mendiez donc, personne ne vous en empêche. Seulement, entrez un par un et en silence. L'autre attend dehors.";
			link.l1 = "Il attendra.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyReloadToTownhall");
		break;

		case "7":
			dialog.text = "...(il se retourne)... Ah, c'est vous. Vos mains n'étaient pas les bonnes, finalement.";
			link.l1 = "Vous le saviez dès la maison.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyFirstBattleInTownhall");
		break;

		case "8":
			dialog.text = "...(d'une voix égale, sans ciller)... Vous vous êtes trompé de porte, capitaine. Ceci est la résidence du gouverneur.";
			link.l1 = "Je sais. Et je sais que vous n'êtes pas le gouverneur.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Je suis le gouverneur de Tortuga. Demandez à n'importe qui dans cette ville.";
			link.l1 = "Je demanderai à quelqu'un au-delà des portes. Là-bas, on répond encore avec ses propres mots.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "...(son ton change pour la première fois)... Vous n'en ferez rien.";
			link.l1 = "Je veux la clé que porte votre fille.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "...(son ton change enfin)... Alors c'est pour ça que vous êtes venu. Elle ne sait pas ce qu'elle porte, et elle ne l'apprendra pas. On ne l'emmènera pas d'ici.";
			link.l1 = "...(dégaine)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyBattleWithGovernor");
		break;

		case "13":
			dialog.text = "...(au sol, se tenant le flanc)... En haut. א son cou, au bout d'un cordon. Elle n'est ni à moi ni à vous.";
			link.l1 = "א qui, alors ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "א celui qui viendra chercher les deux clés. ...(il ferme les yeux)... La jeune fille n'a rien fait. Emmenez-la loin d'ici, vous m'entendez.";
			link.l1 = "En haut.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToTownhallRoom");
		break;

		case "15":
			dialog.text = "...(se plaque dans le coin)... Ne vous approchez pas. Je vous en prie.";
			link.l1 = "Ce n'est pas pour vous que je suis là. On vous fait sortir.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Mon père... Ce n'est pas mon père, n'est-ce pas ? Je l'ai compris le troisième jour, et il n'y avait personne à qui le dire.";
			link.l1 = "Vous avez bien compris. Et encore une chose : retirez la clé de votre cou, j'en ai besoin. Venez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyInTownhallRoomDialog");
		break;

		case "17":
			dialog.text = "...(sur le seuil, désemparé)... Le maire a ordonné... et il n'y a plus de maire.";
			link.l1 = "Il n'y a plus de maire. Partez, et n'empêchez personne de sortir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyRoomOfficersOut");
		break;

		case "21":
			dialog.text = "Capitaine. Nous ne vous retenons pas. ...(il s'écarte)... א vrai dire, nous vous remercions.";
			link.l1 = "Veillez sur la jeune fille.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyExitTortuga");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
