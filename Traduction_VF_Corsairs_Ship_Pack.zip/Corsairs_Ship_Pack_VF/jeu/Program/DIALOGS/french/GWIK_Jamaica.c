// Company envoy in Fort Orange: quest to open the GWIC office on Jamaica (Gregg)

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int stage = 0;
	if (CheckAttribute(pchar, "GWIK.Jamaica.Stage")) stage = sti(pchar.GWIK.Jamaica.Stage);
	// Gregg: the "word" path opens at high standing; the commandant's word (MayorOk) lowers the bar - the town has spoken for the Company
	bool bWord = false;
	if (GWIK_RepLevel() >= 4) bWord = true;
	if (CheckAttribute(pchar, "GWIK.Jamaica.MayorOk") && GWIK_RepLevel() >= 3) bWord = true;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (CheckAttribute(pchar, "GWIK.Jamaica.Done")) // quest finished - point to the permanent representative
			{
				dialog.text = "Le comptoir est ouvert, capitaine, et c'est en grande partie grâce à vous. Pour les affaires de la Compagnie, voyez maintenant notre représentant : il est à l'intérieur même du comptoir.";
				link.l1 = "Bonjour.";
				link.l1.go = "exit";
				break;
			}
			if (stage == 1) // briefing -> intercept the courier
			{
				dialog.text = "Vous venez de la part des directeurs ? Enfin, capitaine. Je suis "+ GetFullName(NPChar) +", l'homme de confiance de la Compagnie dans la région. C'est une affaire délicate, pas le genre dont on parle dans la rue.";
				link.l1 = "Je suis tout ouïe. De quoi s'agit-il ?";
				link.l1.go = "Jam_Brief1";
				link.l2 = "Laissez-moi d'abord jeter un œil à la ville.";
				link.l2.go = "exit";
				break;
			}
			if (stage == 2) // intercept the courier
			{
				if (CheckAttribute(pchar, "GWIK.Jamaica.CourierDone"))
				{
					dialog.text = "Le courrier est au fond ? Excellent. Le rapport n'arrivera pas : nous avons gagné du temps. Mais le comptoir ne s'ouvrira pas tout seul : parlons maintenant de l'approvisionnement.";
					link.l1 = "Je vous écoute.";
					link.l1.go = "Courier_Done";
					break;
				}
				if (CheckAttribute(pchar, "GWIK.Jamaica.CourierEscaped")) // courier reached port - the denunciation got through, offer a bribe
				{
					dialog.text = "Le courrier s'est glissé au port, et la dénonciation est sur le bureau du gouverneur. Mais tout n'est pas perdu : ce genre de papiers a tendance à disparaître quand une bourse bien remplie trouve les bonnes mains. Cent mille piastres, et le rapport sera oublié.";
					if (sti(pchar.money) >= 100000)
					{
						link.l1 = "Voici l'argent. Occupez-vous-en.";
						link.l1.go = "Courier_Bribe";
					}
					link.l2 = "Je n'ai pas autant en ce moment.";
					link.l2.go = "exit";
					break;
				}
				dialog.text = "Le courrier croise toujours dans nos eaux, capitaine : la corvette légère « Swift », commandée par le capitaine Page. Trouvez-la en mer au large de la Jamaïque et envoyez-la par le fond, avec la dénonciation. Et faites vite.";
				link.l1 = "Je pars l'intercepter.";
				link.l1.go = "exit";
				break;
			}
			if (stage == 3) // supply: escort a convoy from Curacao
			{
				if (CheckAttribute(pchar, "GWIK.Jamaica.ConvoyArrived")) // convoy delivered - take the cargo and move to the factor
				{
					if (sti(pchar.GWIK.Jamaica.ConvoyArrived) >= 2)
						dialog.text = "Les deux galions sont au port, on décharge les cales : vous avez mené le convoi sans une seule perte ! Le comptoir a maintenant ses réserves au complet. Il ne manque plus qu'un gérant expérimenté.";
					else
						dialog.text = "Votre galion est au port... et l'autre, donc, est au fond. Enfin, la moitié de la cargaison vaut mieux que rien : le comptoir a ses réserves. Il ne manque plus qu'un gérant expérimenté.";
					link.l1 = "Quel gérant ?";
					link.l1.go = "Supply_Deliver";
					break;
				}
				if (CheckAttribute(pchar, "GWIK.Jamaica.Convoy")) // escort in progress
				{
					dialog.text = "Le convoi est encore en mer ? Gardez bien ces galions, capitaine : sans la cargaison, le comptoir ne tiendra pas. Et gardez vos canons parés : des corvettes anglaises sont aux trousses du convoi.";
					link.l1 = "Je les ferai passer.";
					link.l1.go = "exit";
					break;
				}
				dialog.text = "Le comptoir est vide : il lui faut des marchandises et du capital. א Willemstad, sur Curaçao, notre gérant charge déjà deux galions de bois précieux et de soie. Allez-y, prenez le convoi sous escorte et menez-le à Fort Orange. La route est peu sמre : la rumeur de cette cargaison lancera les corvettes de la concurrence à vos trousses.";
				link.l1 = "Je pars chercher le convoi à Curaçao.";
				link.l1.go = "exit";
				break;
			}
			if (stage == 4) // the Company factor
			{
				if (CheckAttribute(pchar, "GWIK.Jamaica.FactorAboard"))
				{
					dialog.text = "Notre agent est à bord de votre navire ? Parfait. Qu'il reste sous votre protection pour l'instant : il n'a pas sa place à Fort Orange tant que le comptoir n'est pas ouvert."; // fallback for old saves without a stored name
					if (CheckAttribute(pchar, "GWIK.Jamaica.FactorLName")) dialog.text = "Monsieur "+ pchar.GWIK.Jamaica.FactorLName +" est à bord de votre navire ? Parfait. Qu'il reste sous votre protection pour l'instant : il n'a pas sa place à Fort Orange tant que le comptoir n'est pas ouvert.";
					link.l1 = "Compris. Et ensuite ?";
					link.l1.go = "Factor_Deliver";
					break;
				}
				dialog.text = "Le comptoir a besoin d'un gérant expérimenté. Notre agent attend au comptoir de la Compagnie à Saint-Martin, à Marigot : allez le chercher et amenez-le ici. Et restez sur vos gardes : nos gens ont vu une corvette anglaise tourner autour de ces cכtes depuis trois jours. La concurrence ne dort jamais.";
				link.l1 = "J'amènerai l'agent.";
				link.l1.go = "exit";
				break;
			}
			if (stage == 5) // finale: opening with a complication + choice of tone
			{
				if (CheckAttribute(pchar, "GWIK.Jamaica.FinalDone"))
				{
					dialog.text = "Le « Greyhound » de Gale est au fond : vous auriez dמ voir la tête des Anglais ! Maintenant, personne ne doutera du pavillon qui flotte sur ce comptoir. Il est temps de l'ouvrir : c'est votre victoire, capitaine.";
					link.l1 = "Ouvrons-le !";
					link.l1.go = "Final_OpenForce";
					break;
				}
				if (CheckAttribute(pchar, "GWIK.Jamaica.Tone") && pchar.GWIK.Jamaica.Tone == "force")
				{
					dialog.text = "Le corsaire Jeffrey Gale, sur le « Greyhound », rכde toujours au large de la Jamaïque. Envoyez-le par le fond et revenez : nous ouvrirons le comptoir la tête haute.";
					link.l1 = "Je pars le couler.";
					link.l1.go = "exit";
					break;
				}
				dialog.text = "L'agent est là, les marchandises sont dans l'entrepכt : il reste une étape. Mais la concurrence ne lâchera pas si facilement : elle essaiera sמrement de saboter l'ouverture. Comment allons-nous nous y prendre ?";
				link.l1 = "Accueillons-les au canon : qu'ils apprennent qui nous sommes.";
				link.l1.go = "Tone_Force";
				link.l2 = "Achetons-les, ça coמtera moins cher.";
				link.l2.go = "Tone_Gold";
				if (bWord)
				{
					link.l3 = "Réglons ça par la parole : j'ai un nom et des relations.";
					link.l3.go = "Tone_Word";
				}
				link.l4 = "Laissez-moi réfléchir.";
				link.l4.go = "exit";
				break;
			}
			dialog.text = "Pas d'ordres pour l'instant, capitaine. Repassez plus tard.";
			link.l1 = "Je le ferai.";
			link.l1.go = "exit";
		break;

		case "Jam_Brief1":
			dialog.text = "Ouvrir un comptoir de la Compagnie ici, en Jamaïque, c'est comme allumer un feu sous le nez des Anglais de Port Royal. Et ils en ont déjà flairé l'odeur : notre homme à la taverne a vu le gouverneur envoyer un courrier porteur d'une dénonciation vers un autre port anglais. Si ces papiers arrivent, ils étoufferont l'entreprise dans l'œuf.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "Jam_Brief2";
			link.l2 = "Quel est le risque pour moi, personnellement ?";
			link.l2.go = "Jam_BriefRisk";
		break;

		case "Jam_BriefRisk":
			dialog.text = "Officiellement, la Compagnie n'y est pour rien, et vous êtes un capitaine libre : il se passe des choses en mer. Mais les Heeren XVII n'oublient pas un tel service : un comptoir, une part de fondateur, une bonne réputation. Vous ne risquez pas plus que dans n'importe quelle autre affaire.";
			link.l1 = "Très bien. Et le courrier ?";
			link.l1.go = "Jam_Brief2";
		break;

		case "Jam_Brief2":
			dialog.text = "Interceptez le courrier en mer avant qu'il n'atteigne le port, et envoyez-le par le fond, papiers compris. Discrètement, et à coup sמr.";
			link.l1 = "Oם est-ce que je le trouve ?";
			link.l1.go = "Brief_Courier";
			link.l2 = "Laissez-moi me préparer.";
			link.l2.go = "exit";
		break;

		case "Brief_Courier":
			if (!GWIK_JamaicaSpawnCourier()) // courier didn't put to sea - don't dead-end the quest
			{
				dialog.text = "וtrange : notre informateur a perdu le courrier de vue. Repassez un peu plus tard, et je préciserai sa route.";
				link.l1 = "D'accord, je reviendrai.";
				link.l1.go = "exit";
				break;
			}
			pchar.GWIK.Jamaica.Stage = 2;
			AddQuestRecord("GWIK_JamaicaJob", "2");
			dialog.text = "Le courrier, c'est la corvette légère « Swift », commandée par le capitaine Jeremy Page : elle a déjà quitté les cכtes de la Jamaïque pour un port anglais. Ne la laissez pas y arriver. Et souvenez-vous : officiellement, la Compagnie n'y est pour rien.";
			link.l1 = "Considérez que c'est fait.";
			link.l1.go = "exit";
		break;

		case "Courier_Done":
			pchar.GWIK.Jamaica.Stage = 3;
			DeleteAttribute(pchar, "GWIK.Jamaica.CourierDone");
			AddQuestRecord("GWIK_JamaicaJob", "4");
			dialog.text = "א Willemstad, sur Curaçao, notre gérant charge déjà deux galions de bois précieux et de soie. Allez-y, prenez le convoi sous escorte et menez-le à Fort Orange. La route est peu sמre : la rumeur de cette cargaison lancera les corvettes de la concurrence à vos trousses.";
			link.l1 = "Je pars chercher le convoi à Curaçao.";
			link.l1.go = "exit";
		break;

		case "Courier_Bribe":
			if (sti(pchar.money) < 100000)
			{
				dialog.text = "Pour le pot-de-vin, il faut cent mille piastres, et vous n'avez pas autant sur vous, capitaine.";
				link.l1 = "Je trouverai l'argent.";
				link.l1.go = "exit";
				break;
			}
			AddMoneyToCharacter(pchar, -100000);
			DeleteAttribute(pchar, "GWIK.Jamaica.CourierEscaped");
			pchar.GWIK.Jamaica.Stage = 3;
			PlayStereoSound("notebook");
			AddQuestRecord("GWIK_JamaicaJob", "12");
			dialog.text = "C'est fait. La dénonciation s'est noyée dans les papiers des autres, comme si elle n'avait jamais existé. Maintenant, parlons approvisionnement : à Willemstad, sur Curaçao, on charge déjà deux galions de bois et de soie. Allez-y, prenez le convoi sous escorte et menez-le à Fort Orange : la concurrence enverra sמrement des corvettes à vos trousses.";
			link.l1 = "Je pars chercher le convoi à Curaçao.";
			link.l1.go = "exit";
		break;

		case "Supply_Deliver": // Gregg: convoy delivered - supply done, move to the factor stage
			if (CheckAttribute(pchar, "GWIK.Jamaica.ConvoyArrived") && sti(pchar.GWIK.Jamaica.ConvoyArrived) >= 2) GWIK_AddRep(10); // Gregg: bonus for a convoy delivered without loss
				DeleteAttribute(pchar, "GWIK.Jamaica.ConvoyArrived");
			pchar.GWIK.Jamaica.Stage = 4;
			PlayStereoSound("notebook");
			AddCharacterExpToSkill(pchar, SKILL_SAILING, 60);    // Gregg: navigation xp for running the supply convoy through pursuit
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 30); // Gregg: and command xp - escorting the squadron to Fort Orange
			AddQuestRecord("GWIK_JamaicaJob", "5");
			dialog.text = "Le bois et la soie de vos galions iront dans l'entreprise : le comptoir a ses réserves. Maintenant, il lui faut un gérant : notre agent attend au comptoir de Saint-Martin, à Marigot. Amenez-le ici.";
			link.l1 = "Je le ramènerai.";
			link.l1.go = "exit";
		break;

		case "Factor_Deliver":
			pchar.GWIK.Jamaica.Stage = 5;
			GWIK_JamaicaClearAmbush(); // if the interceptor was merely outrun, it has failed - remove it quietly
			AddCharacterExpToSkill(pchar, SKILL_SAILING, 50);    // Gregg: navigation xp for delivering the factor past the ambush
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 20); // Gregg: and a little command xp
			AddQuestRecord("GWIK_JamaicaJob", "7");
			dialog.text = "L'agent inspecte déjà les futurs entrepכts : excellent. Il reste une étape : l'ouverture. Mais la concurrence ne lâchera pas facilement : elle essaiera sמrement de la saboter. Comment allons-nous nous y prendre ?"; // fallback for old saves without a stored name
			if (CheckAttribute(pchar, "GWIK.Jamaica.FactorLName")) dialog.text = "Monsieur "+ pchar.GWIK.Jamaica.FactorLName +" inspecte déjà les futurs entrepכts : excellent. Il reste une étape : l'ouverture. Mais la concurrence ne lâchera pas facilement : elle essaiera sמrement de la saboter. Comment allons-nous nous y prendre ?";
			link.l1 = "Accueillons-les au canon : qu'ils apprennent qui nous sommes.";
			link.l1.go = "Tone_Force";
			link.l2 = "Achetons-les, ça coמtera moins cher.";
			link.l2.go = "Tone_Gold";
			if (bWord)
			{
				link.l3 = "Réglons ça par la parole : j'ai un nom et des relations.";
				link.l3.go = "Tone_Word";
			}
			link.l4 = "Laissez-moi réfléchir.";
			link.l4.go = "exit";
		break;

		case "Tone_Force":
			if (!GWIK_JamaicaSpawnFinal()) // privateer didn't spawn - don't latch the force path, keep the tone choice open
			{
				dialog.text = "וtrange, le corsaire ne se montre pas au large. Repassez plus tard, ou nous réglerons ça autrement.";
				link.l1 = "D'accord.";
				link.l1.go = "exit";
				break;
			}
			pchar.GWIK.Jamaica.Tone = "force";
			AddQuestRecord("GWIK_JamaicaJob", "8");
			dialog.text = "Voilà qui est parlé ! Les Anglais ont engagé un corsaire, un certain Jeffrey Gale, sur la corvette « Greyhound », déjà en route pour la Jamaïque. Allez à sa rencontre en mer et envoyez-le par le fond. Puis revenez, et nous ouvrirons le comptoir au grand jour, aux yeux de tous.";
			link.l1 = "Ce sera fait.";
			link.l1.go = "exit";
		break;

		case "Tone_Gold":
			if (sti(pchar.money) < 80000)
			{
				dialog.text = "Pour le pot-de-vin, il faut quatre-vingt mille piastres, et vous n'avez pas autant sur vous, capitaine.";
				link.l1 = "Je trouverai l'argent.";
				link.l1.go = "exit";
				break;
			}
			AddMoneyToCharacter(pchar, -80000);
			pchar.GWIK.Jamaica.Tone = "gold";
			GWIK_FinishJamaicaQuest(0);
			if (!CheckAttribute(pchar, "GWIK.Jamaica.Done")) // the opening fell through - refund, don't burn the choice
			{
				AddMoneyToCharacter(pchar, 80000);
				DeleteAttribute(pchar, "GWIK.Jamaica.Tone");
				dialog.text = "Un problème avec les papiers, capitaine... Votre argent reste chez vous pour l'instant. Repassez un peu plus tard, nous arrangerons ça.";
				link.l1 = "Très bien.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Sage décision. Quelques bourses bien remplies dans les bonnes mains, et les Anglais détourneront le regard au bon moment. C'est fait : le comptoir est ouvert ! La Compagnie n'oubliera pas votre rכle dans cette affaire.";
			link.l1 = "Tant mieux pour la Compagnie.";
			link.l1.go = "exit";
		break;

		case "Tone_Word":
			pchar.GWIK.Jamaica.Tone = "word";
			GWIK_FinishJamaicaQuest(0);
			if (!CheckAttribute(pchar, "GWIK.Jamaica.Done")) // the opening fell through - don't burn the choice
			{
				DeleteAttribute(pchar, "GWIK.Jamaica.Tone");
				dialog.text = "Un problème avec les papiers, capitaine... Repassez un peu plus tard, nous arrangerons ça.";
				link.l1 = "Très bien.";
				link.l1.go = "exit";
				break;
			}
			GWIK_AddRep(20); // bonus for the hardest path - only on success
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 100); // Gregg: large leadership xp for the purely diplomatic finale (the hardest path)
			dialog.text = "Votre nom ouvre vraiment des portes. Quelques mots aux bonnes personnes, et la tempête s'est calmée avant même d'éclater. Le comptoir est ouvert, et sans un seul coup de feu. La Compagnie l'apprécie hautement.";
			link.l1 = "C'est bien mieux ainsi.";
			link.l1.go = "exit";
		break;

		case "Final_OpenForce":
			GWIK_FinishJamaicaQuest(15);
			if (!CheckAttribute(pchar, "GWIK.Jamaica.Done")) // the opening fell through - don't lose the finale
			{
				dialog.text = "Un problème avec les papiers, capitaine... Repassez un peu plus tard, nous arrangerons ça.";
				link.l1 = "Très bien.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "C'est fait : le comptoir de la Compagnie des Indes occidentales à Fort Orange est ouvert, et sous notre pavillon ! C'est votre victoire, capitaine. La Compagnie ne l'oubliera pas.";
			link.l1 = "Pour la Compagnie !";
			link.l1.go = "exit";
		break;

		case "exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
