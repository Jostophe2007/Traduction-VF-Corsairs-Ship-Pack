// boal 08/04/04 общий диалог торговцев
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	int skullprice = (sti(PChar.rank) * 4000) - ((sti(PChar.rank) * 2400) * (0.01* (GetSummonSkillFromName(PChar, SKILL_COMMERCE))))+ 10000;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// LEO: приписка-надбавка (NameBonus/Tail) у имени торговца — только на экране заказов фрахта, чистим на каждом узле
	DeleteAttribute(NPChar, "NameBonus");
	DeleteAttribute(NPChar, "NameBonusTail");


	string iDay, iMonth, sTemp, sMoney, attrL;

	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;

	int iMoney;
	int iQuantityGoods;
	int iTradeGoods;
	int iTmp;

    bool ok;
	bool bTradeQuest = false;

	int iTest, cn, i;
	iTest = FindColony(NPChar.City); // город магазина
	ref rColony, chref;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}

    int iSeaGoods = LanguageOpenFile("ShipEatGood.txt"); // нужно заменить на GetGoodsNameAlt(idx)

    if (!CheckAttribute(npchar, "quest.item_date"))
    {
        npchar.quest.item_date = "";
    }
    if (!CheckAttribute(npchar, "quest.trade_date"))
    {
        npchar.quest.trade_date = "";
    }

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Store\" + NPChar.City + "_Store.c";
    if (!HasCityDialogFile("Store", NPChar.City, "_Store.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Store\DefaultCity_Store.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Store\DefaultCity_Store.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
    ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06
	string attrLoc   = Dialog.CurrentNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vous parlerai pas !", "Fuyez avant que les soldats ne vous transforment en passoire, "+ GetSexPhrase("l'ami", "ma petite") +"..."),
					LinkRandPhrase("Que voulez-vous, gredin ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin, sale pirate !", "Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, gredin ! On vous pendra bientכt dans notre fort, vous n'irez pas loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + ", et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			// должник гильдии: лавочники нации-кредитора до возврата долга встречают ТОЛЬКО разговором о долге
			if (CheckAttribute(pchar, "GuildDebt") && sti(NPChar.nation) == sti(pchar.GuildDebt.nation))
			{
				dialog.text = "(Le marchand vous reconnaît et s'assombrit.) La guilde a envoyé votre nom à tous les comptoirs, " + GetAddress_Form(NPChar) + ". Une cargaison détournée, un dédit... Tant que vous n'aurez pas réglé la dette, nous n'avons rien à nous dire. Payez, ou partez.";
				link.l1 = "Je viens pour la dette. Je veux la régler.";
				link.l1.go = "GuildDebt_Settle";
				link.l2 = "Je dois réunir l'argent. Je reviendrai.";
				link.l2.go = "exit";
				NextDiag.TempNode = "First time";
				break;
			}
			//homo Линейка Блада
            if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
            {
                dialog.Text = LinkRandPhrase("Tiens, docteur Blood ! " + TimeGreeting() + ".",
                                    "Ravie de vous voir, Peter Blood.",
                                    "C'est gentil de passer me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
                Link.l1 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l1.go = "exit";
				NextDiag.TempNode = "First time";
				break;
            }
			//Sinistra Пролог Анжелика Тич
            if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")
            {
                dialog.Text = "Bonjour, señorita ! Vous voulez acheter quelque chose ? Peut-être avez-vous besoin de sel ? J'ai beaucoup de sel ! Ah... Quel sel !",
                Link.l1 = "Señor, vous allez bien ?";
				Link.l1.go = "exit";
				break;
            }
			if (npchar.id != "Pirates_trader" && npchar.id != "Caiman_trader" && CheckAttribute(pchar, "BSStart"))
			{
				//Black sails
				if(pchar.questTemp.BlueBird == "over")
				{
					dialog.text = "Capitaine, rien de personnel, mais une personne très influente m'a interdit de commercer avec vous. Pas d'affaires, désolé.";
					link.l1 = "Pardon, mais je ne comprends pas. Que s'est-il passé ?";
					link.l1.go = "BS_NPVK_2";
					break;
				}
			}
            dialog.text = NPCharRepPhrase(npchar, "Nouveau client, nouvel or. "
							+ LinkRandPhrase("L'argent n'a pas d'odeur. ", "Les piastres n'ont pas d'odeur. ", "On ne vit pas que de vertu ! ")+
							+GetFullName(npchar)+  ", à votre service !",
			                + LinkRandPhrase("Ravi de rencontrer un nouveau client, ", "Heureux de rencontrer un nouveau client, ", "Bienvenue, ")
							+ GetAddress_Form(NPChar)+ ". Je m'appelle "  + GetFullName(npchar)+
							+ RandPhraseSimple(", ma boutique est à votre service.", ", je suis à votre service."));
			link.l1 = "Permettez-moi de me présenter. " +RandPhraseSimple("Je m'appelle", "Je suis")+ " du capitaine "+ GetFullName(pchar)+".";
			link.l1.go = "node_1";
			NextDiag.TempNode = "Second time";
			// Gregg: «Чёрная Орхидея», глава 5 - лавочник Портобелло помнит компаньона Торангеры.
			// Common_Store.c обслуживает ВСЕХ лавочников мода, поэтому гард обязателен. Отбираем
			// по городу, а не по id: id пережил бы только текущую расстановку, а City стоит
			// у всех 32 торговцев с этим диалогом (проверено по characters\init\*.c).
			// Чтение pchar.DestinyGift - ВЛОЖЕННЫМ if: короткого замыкания в Storm нет, и у игрока
			// без этого квеста атрибута попросту не существует.
			if (npchar.city == "PortoBello" && CheckAttribute(pchar, "DestinyGift"))
			{
				if (pchar.DestinyGift == "23")
				{
					link.l2 = "Dites-moi, avez-vous déjà entendu parler de Bernaldinio Toranger, capitaine du Vautour ?";
					link.l2.go = "BO_Estikos_1";
				}
			}
		break;

		//Black sails
		case "BS_NPVK_2":
            dialog.text = "Adressez-vous à Miss Guthrie, elle est arrivée récemment de Nassau et a pris en main le négoce des prises. Aux Bermudes, Jackman lui-même vient la saluer bien bas.";
            link.l1 = "Hum. Guthrie... דa me dit quelque chose. Bon, à plus tard.";
			link.l1.go = "exit";
			sld = CharacterFromID("Pirates_trader");
			if(sld.lastname != "Guthrie" && !CheckAttribute(PChar, "questTemp.BSPrologue.WaitingForNassauSiege") && !CheckAttribute(PChar, "BS_NassauWaitingForSiege"))
			{
				SetFunctionLocationCondition("BST_Pirates_Store", "Pirates_Store", false);
				BS_ReplaceTraderWithGatri();
				sld.Dialog.FileName = "Quest\BlackSails\NePluyjVKolodec.c";
				sld.Dialog.CurrentNode = "BS_NPVK_3";
				sld.sex = "woman";
				SetQuestHeader("BSPrologue");
				AddQuestRecord("BSPrologue", "1");

				for (i = 1; i < 4; i++)
				{
					sld = GetCharacter(NPC_GenerateCharacter("gatri_grunt"+i, GetPirateMushketerModel(), "man", "mushketer", 777, PIRATE, -1, false));
					LAi_SetWarriorType(sld);
					LAi_warrior_DialogEnable(sld, false);
					ChangeCharacterAddressGroup(sld, "Pirates_store", "goto", "goto"+i);
					LAi_SetImmortal(sld, true);
					LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
				}
			}
		break;
		//Black sails

		case "second time":
			if (LAi_group_GetPlayerAlarm() > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vous parlerai pas !", "Fuyez avant que les soldats ne vous transforment en passoire, "+ GetSexPhrase("l'ami", "ma petite") +"..."),
					LinkRandPhrase("Que voulez-vous, gredin ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin, sale pirate !", "Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, gredin ! On vous pendra bientכt dans notre fort, vous n'irez pas loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + ", et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			// должник гильдии: лавочники нации-кредитора до возврата долга встречают ТОЛЬКО разговором о долге
			if (CheckAttribute(pchar, "GuildDebt") && sti(NPChar.nation) == sti(pchar.GuildDebt.nation))
			{
				dialog.text = "(Le marchand vous reconnaît et s'assombrit.) La guilde a envoyé votre nom à tous les comptoirs, " + GetAddress_Form(NPChar) + ". Une cargaison détournée, un dédit... Tant que vous n'aurez pas réglé la dette, nous n'avons rien à nous dire. Payez, ou partez.";
				link.l1 = "Je viens pour la dette. Je veux la régler.";
				link.l1.go = "GuildDebt_Settle";
				link.l2 = "Je dois réunir l'argent. Je reviendrai.";
				link.l2.go = "exit";
				break;
			}

			if (npchar.id != "Pirates_trader" && npchar.id != "Caiman_trader" && CheckAttribute(pchar, "BSStart"))
			{
				//Black sails
				if(pchar.questTemp.BlueBird == "over")
				{
					dialog.text = "Capitaine, rien de personnel, mais une personne très influente m'a interdit de commercer avec vous. Pas d'affaires, désolé.";
					link.l1 = "Pardon, mais je ne comprends pas. Que s'est-il passé ?";
					link.l1.go = "BS_NPVK_2";
					break;
				}
			}

   			// проверка награды
			dialog.text = NPCharRepPhrase(npchar,
			                 pcharrepphrase(LinkRandPhrase("Capitaine ", "Mais c'est "+ GetSexPhrase("le grand", "la grande") +" ", "Qui vois-je ? C'est bien ") +GetFullName(pchar)+" ! "
							                 + LinkRandPhrase("On ne vous a pas encore pendu à une vergue ? Ha ha ! ", "On dit que vous avez rendu visite au diable des mers ! ", "Et moi qui avais entendu dire qu'on vous avait pendu à Port Royal. ")
											  + RandPhraseSimple("Ravi de vous voir !", "Bienvenue !"),
							                LinkRandPhrase("Bonjour, ", "Bienvenue, ", "Bonjour, ") + "capitaine"
											+ RandPhraseSimple(". Comment trouvez-vous", ". Que pensez-vous de")+" notre"+ RandPhraseSimple(" île ? ", " ville ? ")
											+ LinkRandPhrase("On n'est pas mal ici, ", "Un endroit formidable, ", ""+ GetSexPhrase("Il y a de belles filles ici, ", "Les gens sont accueillants ici, ") +"")+RandPhraseSimple("n'est-ce pas ?", "n'est-ce pas ?")),
							 pcharrepphrase(LinkRandPhrase("Capitaine ", "Oh, c'est encore vous, ", "Vous m'avez fait peur, ") + GetFullName(pchar)
							 				+ LinkRandPhrase(". Les mères effraient déjà les enfants désobéissants avec votre nom ! ", ". J'espère que vous n'avez pas de démêlés avec la loi ? ", ". Votre réputation laisse beaucoup à désirer. ")
											 +LinkRandPhrase("א quoi dois-je votre visite ?", "Que voulez-vous ?", "Pourquoi êtes-vous venu ?"),
							                "Bienvenue, capitaine " +GetFullName(pchar)+ LinkRandPhrase("! דa souffle un peu aujourd'hui, ",
											"! On dirait qu'une tempête se lève, ", "! Le vent forcit, ") +"n'est-ce pas ?"));

			link.l1 = NPCharRepPhrase(npchar,
			            pcharrepphrase(LinkRandPhrase("Tu es encore en vie, ", "Moi, je suis "+ GetSexPhrase("content", "contente") +", ", "On en a vu de meilleures, toi et moi, ")
									  +LinkRandPhrase("canaille !", "l'ami !", "vieux loup de mer !") +" Et moi qui"+ GetSexPhrase(" croyais", " croyais") +", "
									  +LinkRandPhrase("que ta femme t'avait déjà dévoré avec ta bière !", "que les termites t'avaient dévoré !", "que ta vieille t'avait fait passer de vie à trépas !"),
						               LinkRandPhrase("Bonjour, ", "Salut à vous, ", "Bonjour, ") + GetAddress_FormToNPC(NPChar)+ " " + GetFullName(Npchar)
									   +RandPhraseSimple(". Vous avez raison, ", ". Je suis tout à fait d'accord, ")
									   +LinkRandPhrase("et les "+ GetSexPhrase("mulâtresses d'ici sont tout simplement adorables", "habitants d'ici sont très aimables") +"", "difficile de dire le contraire", "et"+ GetSexPhrase(" les dames d'ici feraient tourner toutes les têtes", " les habitants sont vraiment très gentils") +"")+ "."),
						pcharrepphrase(RandPhraseSimple("Au diable ces bavardages, ", "Change de cap, ") +GetFullName(Npchar)+ " ! "
						              +LinkRandPhrase("Tu parles comme un perroquet ! ", "Et ne me fais pas tourner en bourrique ! ", "Tes paroles ne valent pas plus qu'un biscuit de mer ! ")
						              +RandPhraseSimple("Je "+ GetSexPhrase("suis venu", "suis venue") +" faire des achats !", "Qu'est-ce que tu fais assis là ?"),
						               "Bonjour, " + GetAddress_FormToNPC(NPChar)+ " ! Oui, mais hier, " + LinkRandPhrase("c'était le calme plat.",
									    "il faisait un temps magnifique.", "il n'y avait pas un souffle de vent.")));
			link.l1.go = "node_1";
			NextDiag.TempNode = "Second time";
			// Gregg: «Чёрная Орхидея», глава 5 - лавочник Портобелло помнит компаньона Торангеры
			if (npchar.city == "PortoBello" && CheckAttribute(pchar, "DestinyGift"))
			{
				if (pchar.DestinyGift == "23")
				{
					link.l2 = "Dites-moi, avez-vous déjà entendu parler de Bernaldinio Toranger, capitaine du Vautour ?";
					link.l2.go = "BO_Estikos_1";
				}
			}
		break;

		case "node_1":
			dialog.text = NPCStringReactionRepeat(NPCharRepPhrase(npchar,
			                                         pcharrepphrase(RandPhraseSimple("Haut les mains ! ", "Halte, inspection ! ") +LinkRandPhrase("Que vient donc chercher "+ GetSexPhrase("un gentilhomme", "un gentilhomme, oh, pardon, une dame") +" de fortune dans ma boutique, hé hé ?",
													                                 "Quelle bonne surprise pour ce pauvre vieux marchand ! Hé hé !", "Quel bon vent vous amène dans ma boutique ?"),
            														LinkRandPhrase("Ouvrez les sabords ! ", "Grappins le long du bord ! ", "Droit devant ! ")+RandPhraseSimple("Vous trouverez ici", "Dans ma boutique, vous trouverez")
																	+LinkRandPhrase(" les meilleurs prix de l'île. ", " un excellent choix de marchandises. ", " des marchandises de première qualité. ")
																	+RandPhraseSimple("Je suis à votre service", "Tout ce que vous voudrez")+", capitaine !"),
													 pcharrepphrase(RandPhraseSimple("Toutes les marchandises qu'il faut aux "+ GetSexPhrase("gentilshommes", "gentilshommes et aux dames") +" de fortune ! Hé hé ! Tant qu'on ne les a pas pendus à sécher au soleil !",
													                                 "Le vent fait danser les pendus sur le port et porte le cliquetis des chaînes. Mais les piastres n'ont pas d'odeur, pas vrai ?!"),
                 												"Vous souhaitez " +LinkRandPhrase("acheter les meilleures marchandises de " + NationNameGenitive(sti(NPChar.nation)), "acheter ou vendre une cargaison", "trouver un fret avantageux")
																	+RandPhraseSimple("? Je suis entièrement à votre disposition !", "? Ma boutique est à votre service !")
																	+RandPhraseSimple(" Ravi de vous voir", " Mettez-vous à l'aise") +", capitaine !")),
				                                  NPCharRepPhrase(npchar,
												  	 pcharrepphrase("Un conseil, capitaine : ne lésinez pas sur la mitraille. C'est plus facile de fouiller les morts !",
													                "J'ai vu au premier coup d'œil que vous étiez "+ GetSexPhrase("un malin", "une maline") +". " +RandPhraseSimple("Mais je vois maintenant que vous êtes "+ GetSexPhrase("un vrai héros", "une vraie casse-cou") +".", "Vous êtes "+ GetSexPhrase("jeune", "jeune") +" mais "
																	+RandPhraseSimple("vous avez l'esprit vif.", "on ne vous la fait pas."))),
													 pcharrepphrase("Je suis prêt à vous racheter toute la cargaison de vos prises. Vous voulez acheter de l'or ou de l'argent ? דa a toujours de la valeur !",
													                "Le commerce maritime est une affaire rentable, capitaine " + GetFullName(pchar)+", n'est-ce pas ?")),
												  NPCharRepPhrase(npchar,
												     RandPhraseSimple("Tous les soixante-quinze ne sont pas rentrés chez eux ! Ils ont sombré au fond de la mer ! " ,
													   RandPhraseSimple("Quinze hommes sur le coffre du mort !", "Bois, et le diable fera le reste !") +" Yo-ho-ho ! Et une bouteille de rhum. ")
													   +RandPhraseSimple("Que voulez-vous, capitaine ?", "Que voulez-vous acheter, capitaine ?"),
													 pcharrepphrase("Vous aimez marchander, capitaine " + GetFullName(pchar)+". En tant que client fidèle, je vous propose des prix très avantageux !",
													                "Très bien, capitaine " + GetFullName(pchar)+", par respect pour vous, je suis prêt à baisser encore un peu le prix ! Que voulez-vous ?")),
												  NPCharRepPhrase(npchar,
												     "Je vous jure, j'en ai assez de vous parler. "
													 +LinkRandPhrase("Achetez donc deux ou trois arachides. Les cochons adorent ça.", "Vous comptez qu'on vous cire les bottes au rhum, ici ?",
													 pcharrepphrase("Je connais votre engeance. א force de boire du rhum, vous finirez pendu.", "Comment votre mère a-t-elle pu vous laisser partir en mer ! En mer !!! Vous auriez mieux fait de "+ GetSexPhrase("devenir tailleur", "devenir couturière") +"...")),
													 pcharrepphrase(RandPhraseSimple("Je croyais ", "J'espérais ")+RandPhraseSimple("que vous aviez quitté notre île. ", "que je ne vous reverrais jamais. ")
													 +RandPhraseSimple("Les morts pèsent à votre cou comme des meules...", "Combien de marins avez-vous envoyés pourrir parmi les coraux ?!"),
													 "Capitaine " + GetFullName(pchar)+" ! Votre passion pour le commerce dépasse toutes mes attentes ! "
													 +RandPhraseSimple("Vous voulez faire vos derniers achats avant d'appareiller ?", "Vous voulez acheter quelque chose de spécial ?"))),
										"cycle", 10, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(NPCharRepPhrase(npchar,
			                                        pcharrepphrase("Allez, montre-moi ce que tu as, vieux pirate !",
													               "Je veux juste jeter un œil à vos marchandises, mon cher."),
													pcharrepphrase("Je le jure par la potence, " +GetFullName(npchar)+" tu ne me mèneras pas par le bout du nez ! Montre tes marchandises, tout de suite !",
													               "Voyons vos marchandises, " +GetAddress_FormToNPC(NPChar)+ ".")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("דa, c'est sמr ! Les morts ne mordent pas ! Bon, qu'est-ce que tu as dans ta cale ?",
													               "Toi, mon cher, occupe-toi plutכt de tes affaires. Quelles marchandises peux-tu me proposer ?"),
												    pcharrepphrase("Un jour, tu seras ma prise, hé hé. Je plaisante. Montre-moi tes marchandises.",
													               "Parlons commerce, " +GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+ ".")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Ce qu'il me faut ? Je veux acheter quelque chose !",
													               "L'ivrognerie te mènera au tombeau, " +GetFullName(npchar)+ ". Je dois voir tes marchandises."),
												    pcharrepphrase("Je les connais, tes remises ! Deux livres de cacao pour le prix de trois ! Montre tes marchandises, tout de suite",
													               "C'est toujours agréable. Marchandons.")),
											  "Montrez les marchandises, moins de paroles et plus d'actes. Je n'ai pas de temps à perdre.",
											  npchar, Dialog.CurrentNode);
			link.l1.go = "market";
			ChangeImport();
			link.l2 = HeroStringReactionRepeat(NPCharRepPhrase(npchar,
			                                        pcharrepphrase("Ah, ce que j'aimerais "+ GetSexPhrase("étriper", "étriper") +" quelqu'un ! Bon, venons-en au fait.",
													               "Passons à autre chose, mon cher"),
													pcharrepphrase("Caramba ! Je viens pour une tout autre affaire !",
													               "Je dois vous parler affaires, "+GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+".")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("J'ai affaire à toi, vieux pirate !",
													               "Passons aux affaires, mon cher !"),
													pcharrepphrase("Par le diable, on ne me la fait pas, canaille ! Je viens pour autre chose !",
													               "Je suis d'accord, " +GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+ ", mais je voudrais parler d'autre chose avec vous.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Tu es déjà soמl, l'ami ?! J'ai affaire à toi.",
													               "Je "+ GetSexPhrase("ne suis pas venu", "ne suis pas venue") +" pour commercer, mon cher. Je viens pour autre chose."),
													pcharrepphrase("Au diable tes prix, gredin ! J'ai affaire à toi.",
													               "Les remises, c'est toujours agréable, " + GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+ ", mais je viens pour autre chose.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Tiens ta langue, vieil ivrogne, j'ai affaire à toi.",
													               "Le rhum te sort par les yeux, je suppose. Remarque, tu ne m'enchantes pas non plus. Passons aux affaires."),
													pcharrepphrase("Tu m'as déjà plumé jusqu'à l'os, escroc ! J'ai affaire à toi.",
													               "Votre ironie est déplacée, j'ai une tout autre affaire à vous proposer.")),
											   npchar, Dialog.CurrentNode);
			link.l2.go = "business";
			link.l3 = HeroStringReactionRepeat(NPCharRepPhrase(npchar,
			                                        pcharrepphrase("Les affaires d'abord, le plaisir ensuite. Je veux te demander quelque chose.",
													               "Pas maintenant, j'ai besoin d'informations."),
													pcharrepphrase("Au diable les prix ! D'abord, tu vas me dire tout ce que je dois savoir.",
													               "Avec plaisir. Je voudrais savoir quelque chose.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Merci du conseil, vieux tueur. J'ai besoin de savoir quelque chose.",
													               "J'ai une question précise."),
												    pcharrepphrase("L'or peut attendre. Je veux savoir quelque chose.",
													               "Oui, je suis " + GetSexPhrase("d'accord", "d'accord") +". Je voudrais vous demander quelque chose.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Je crois que vous savez ce que je veux vous demander.",
													               "J'espère que vous répondrez à ma question."),
													pcharrepphrase("Tu as autre chose dans la tête que des étiquettes de prix ? Voilà ce que je veux te demander.",
													               "Ce n'est pas ça. J'ai besoin de renseignements.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Ne t'énerve pas comme ça, vieux ! Je veux juste te poser une question.",
													               "Ne t'inquiète pas autant, tu vas faire une attaque. Réponds à ma question et je m'en vais."),
													pcharrepphrase("Je n'attends pas de toi une parole intelligente, tu as une cervelle de cafard. Mais tu sais quelque chose.",
													               "Je ne vous retiendrai pas longtemps. Juste une question.")),
											   npchar, Dialog.CurrentNode);
			link.l3.go = "quests";
			//--> eddy. Аскольд, базар с рендомным торговцем
			if (pchar.questTemp.Ascold == "Seek_powder" && pchar.questTemp.Ascold.TraderId == npchar.id && !CheckAttribute(Pchar, "RomanticQuest.TalkInShop"))
			{
				link.l3.go = "AscoldTrader";
			}
			if (pchar.questTemp.Ascold == "PowderWasSeek" && pchar.questTemp.Ascold.TraderId == npchar.id)
			{
				link.l3.go = "AscoldTrader_WasSeek";
			}
			if (CheckAttribute(pchar, "Whisper.Contraband") && npchar.id == "Tortuga_trader" && GetSquadronGoods(Pchar, GOOD_EBONY) >= 100)
			{//Линейка Виспер
				link.l44 = "Bonjour. J'ai repris le travail inachevé de l'ancien capitaine de mon navire. D'après le journal de bord, je vous dois cent pièces d'ébène. Tout est dans ma cale, prêt à être déchargé.";
				link.l44.go = "Whisper_contraband";
			}
			if (CheckAttribute(pchar, "cursed.waitingSkull") && pchar.questTemp.Cursed.TraderId == npchar.id && !CheckAttribute(pchar, "cursed.Skullbought"))
			{
				link.l44 = "J'ai une question un peu inhabituelle à vous poser. Le fait est que je cherche un objet : "+ GetConvertStr("itmname_"+pchar.questTemp.Cursed.Item, "ItemsDescribe.txt") +". J'ai appris qu'il pourrait appartenir au propriétaire de cette boutique.";
				link.l44.go = "buy_skull";
			}
			if(CheckAttribute(pchar, "GenQuest.EncGirl"))
			{
				if(pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "store_keeper" && pchar.GenQuest.EncGirl.LoverCity == npchar.city)
				{
					link.l9 = "Bonjour, je viens à l'invitation de votre fils.";
					link.l9.go = "EncGirl_4";
					pchar.quest.EncGirl_GetLoverFather.over = "yes";
				}
				if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
				{
					if(pchar.GenQuest.EncGirl.Father == "store_keeper" && npchar.city == pchar.GenQuest.EncGirl.city)
					{
						link.l9 = "C'est au sujet de votre fille...";
						link.l9.go = "EncGirl_1";
					}
				}
			}
			//<-- eddy. Аскольд, базар с рендомным торговцем
			link.l11 = HeroStringReactionRepeat(NPCharRepPhrase(npchar,
			                                        pcharrepphrase("Salut, vieil ivrogne.",
													               "Bonne journée, "+GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+"."),
													pcharrepphrase("Caramba ! Ne bouge pas. Je reviendrai.",
													               "Ravi de vous voir, "+GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+" ! Au revoir !")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Larguez les amarres !",
													               "Au revoir, mon cher."),
													pcharrepphrase("Hé ! Qu'est-ce que tu caches là ? Du rhum ? Non ?! Bon, je vais aller me rincer le gosier.",
													               "Veuillez m'excuser, j'ai une affaire urgente en ville.")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Hé ! א la prochaine !",
													               "Je dois y aller. Au revoir, "+GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+" !"),
													pcharrepphrase("Et ne t'avise pas de me contredire ! Je n'ai pas le temps de discuter avec toi !",
													               "Il vaudrait peut-être mieux aller voir comment ça se passe à bord. Au revoir, "+GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+" !")),
											   NPCharRepPhrase(npchar,
											        pcharrepphrase("Qu'est-ce qui t'arrive, vieux ? C'est moi, " +GetFullName(pchar)+ " ! Cuve ton vin, je reviendrai plus tard.",
													               "J'ai bien peur que ton foie ne t'achève avant que je repasse par ici."),
													pcharrepphrase("Compte tes piastres, canaille ! Je reviendrai.",
													               ""+ GetSexPhrase("Ravi", "Ravie") +" de vous avoir vu, " + GetAddress_FormToNPC(NPChar)+ " " +GetFullName(npchar)+" !")),
											  npchar, Dialog.CurrentNode);
			link.l11.go = "exit";
		break;

		//Линейка Виспер
		case "Whisper_contraband":
			dialog.text = "Moins fort, ma fille ! C'est la première fois que tu viens aux Caraïbes ?";
			DeleteAttribute(pchar, "Whisper.Contraband");
			link.l1 = "Oui, il y a un problème ?";
			link.l1.go = "Whisper_contraband_1";
			link.l2 = "Non...";
			link.l2.go = "Whisper_contraband_1";
		break;
		case "Whisper_contraband_1":
			dialog.text = "En fait, le commerce de l'ébène est strictement interdit à Tortuga. J'ai beau le vouloir, je ne pourrai pas vous prendre la marchandise.";
			link.l1 = "Que dois-je faire, dans ce cas ? Chercher un autre acheteur ?";
			link.l1.go = "Whisper_contraband_2";
		break;
		case "Whisper_contraband_2":
			dialog.text = "Ne tirez pas de conclusions si vite. Bien sמr, nous ne pouvons pas décharger la marchandise directement au port, sous les yeux des gardes. Mais on peut contourner cette formalité. וloignez-vous un peu de la colonie et accostez sur la plage qu'on appelle l'Œil du Poisson. Elle se trouve dans le nord de l'île. Mes amis vous y attendront pour le paiement et le déchargement.";
			link.l1 = "Et si une patrouille remarque notre marché ?";
			link.l1.go = "Whisper_contraband_3";
		break;
		case "Whisper_contraband_3":
			dialog.text = "Dans ce cas, vous serez livré à vous-même. Si vous les voyez, mieux vaut filer. Mais ne vous inquiétez pas pour rien, les gardes ne mettent pas le nez à l'endroit que je vous ai indiqué.";
			pchar.Whisper.ContraSmuggler = true;
			WhisperPlaceSmugglersOnShore("Shore58");
			AddQuestRecord("WhisperContraband", "2");
			SetTimerCondition("W_Smuggling", 0, 0, 10, false);
			link.l1 = "D'accord. Alors je vais rejoindre la baie.";
			link.l1.go = "exit";
		break;
		//Линейка Виспер
		case "buy_skull":
			dialog.text = GetConvertStr("itmname_"+pchar.questTemp.Cursed.Item, "ItemsDescribe.txt") +" ? Je suis désolé, mais c'est un héritage de famille, il n'est pas à vendre. Il y a bien des années, mon grand-père l'a acheté à un pirate, et depuis, le crâne n'a jamais quitté les murs de cette boutique.";
			link.l1 = "Ne mentez pas. Pour vous autres marchands, tout a un prix, même votre propre mère. Combien voulez-vous pour ce crâne ?";
			link.l1.go = "buy_skull_1";
		break;

		case "buy_skull_1":
			dialog.text = sti(skullprice) + " et pas une pièce de moins.";
			if (sti(pchar.Money) >= skullprice)
            {
    			link.l1 = "Voici l'argent. Donnez-le-moi.";
				link.l1.go = "buy_skull_2";
			}
			link.l2 = "Pour ce prix-là, j'achèterais une douzaine de crânes pareils. Au revoir.";
			link.l2.go = "exit";
		break;

		case "buy_skull_2":
			pchar.cursed.Skullbought = true;
			AddQuestRecord("CursedSkeleton", "2");
			dialog.text = "Un plaisir de faire affaire avec vous.";
			AddMoneyToCharacter(pchar, -skullprice);
			GiveItem2Character(pchar, pchar.questTemp.Cursed.Item);
    		link.l1 = "Oui, au revoir.";
			link.l1.go = "exit";
		break;

		// Gregg: «Чёрная Орхидея», глава 5 - Джекмен советовал расспросить испанских лавочников
		// о Бернальдинио Торангере; в Портобелло след ведёт к его компаньону Фернандо Эстикосу.
		case "BO_Estikos_1":
			dialog.text = "Toranger ? Oui, je me souviens de lui. Un Espagnol, il commandait le Vautour et transportait des cargaisons dans toutes nos eaux. Un homme chanceux : les pirates ne l'ont jamais pris, et pourtant ils l'ont traqué. Et puis, d'un coup, il a disparu.";
			link.l1 = "Disparu ? Comment ça, disparu ?";
			link.l1.go = "BO_Estikos_2";
		break;

		case "BO_Estikos_2":
			dialog.text = "Comme on disparaît en mer, " + GetAddress_Form(NPChar) + ". Il a quitté le port et n'est jamais revenu. Ni lui, ni le navire, ni la cargaison qu'on ne m'a jamais payée. Je le connaissais à peine : je faisais toutes mes affaires avec son associé.";
			link.l1 = "Il avait un associé ? Il est vivant ?";
			link.l1.go = "BO_Estikos_3";
		break;

		case "BO_Estikos_3":
			dialog.text = "Vivant, si on peut appeler ça vivre. Fernando Estikos. Quand Bernaldinio a disparu, il s'est mis à boire, et depuis, il ne quitte plus notre taverne. Il y boit ses dernières pièces. Si vous voulez en savoir plus sur le Vautour, allez là-bas : personne d'autre ne vous dira quoi que ce soit.";
			link.l1 = "Merci, " + GetAddress_FormToNPC(NPChar) + " " + GetFullName(npchar) + ". Je vais passer à la taverne.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftToPortoBelloTavern");
		break;



		case "market":
//navy -->
			//занят ПГГ
//navy <--
			dialog.text = RandPhraseSimple("J'ai des sabres, des pistolets, des boulets, des bois précieux et bien d'autres marchandises ! Qu'est-ce qui vous intéresse ?", "Vous voulez acheter de l'or ou de l'argent ? Ou peut-être chercher une belle lame ?");
			link.l1 = pcharrepphrase(LinkRandPhrase("Ma cale est pleine de butin ! Les piastres n'ont pas d'odeur, pas vrai ?",
			                         "Il faut que je vide ma cale de son butin et que je la remplisse de ton or. Ha ha !",
									 "Tu vendrais ta propre mère pour des doublons sonnants ! Mais moi, j'ai juste besoin de me réapprovisionner."),
									 LinkRandPhrase("Je veux vendre ma cargaison et refaire mes provisions.",
			                         "Je veux acheter un objet en vente.",
									 "Montrez-moi les boulets, les bombes et les autres marchandises."));
			link.l1.go = "trade_1";
			link.l2 = LinkRandPhrase("Montrez-moi les sabres, les pistolets, et qu'avez-vous d'autre ?",
			                         "J'aurais bien besoin de deux nouveaux pistolets, de balles et d'une belle bague.",
									 "Des pierres précieuses, des idoles exotiques : voilà ce qui m'intéresse.");
			link.l2.go = "items";

			link.l3 = pcharrepphrase(RandPhraseSimple("Je m'en vais sans rien acheter. Allez !",
			                                          "Je vais me rincer le gosier. Ne bouge pas."),
									 RandPhraseSimple("Non, je ne suis pas d'humeur à faire des achats. Au revoir.",
									                  "Excusez-moi, j'ai une affaire urgente. Au revoir !"));
			link.l3.go = "exit";
		break;

		case "WasteTime":
			environment.time = 16.0;
			WasteTime(1);
			DialogExit();
		break;

		case "EncGirl_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Je vous ai ramené votre fugitive.";
			link.l1.go = "EncGirl_2";
		break;

		case "EncGirl_2":
			dialog.text = "Ah, capitaine, merci beaucoup ! Comment va-t-elle ? Elle est en bonne santé, elle n'est pas blessée ? דa fait un jour qu'elle s'est enfuie, la malheureuse. Est-ce que je lui veux du mal ? Je veux la marier... Le fiancé est riche, jeune, et pas laid du tout, il ne faut pas faire la fine bouche. Mais non ! Elle n'en fait qu'à sa tête, tout comme sa mère, que le diable l'emporte... Et elle ne serait même pas née si sa mère ne s'était pas enfuie à l'époque avec un benêt entreprenant... Enfin, à quoi bon se souvenir... La jeunesse est naïve, sotte... et cruelle.";
			link.l1 = "Bien sמr, vous êtes son père et c'est à vous de décider, mais à votre place, je ne précipiterais pas un mariage heureux...";
			link.l1.go = "EncGirl_3";
		break;

		case "EncGirl_3":
			dialog.text = "Qu'est-ce que vous y comprenez ? Vous avez des enfants ? Non ? Alors, quand vous en aurez, revenez me voir, et on en reparlera... oui... J'ai promis une récompense à qui me la ramènerait : veuillez l'accepter.";
			link.l1 = "Merci. Et tenez-la bien. Quelque chose me dit qu'elle ne va pas s'arrêter là.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirl_ToLoverParentsExit");
		break;

		case "EncGirl_4":
			if(sti(pchar.GenQuest.EncGirl.LoverFatherAngry) == 0)
			{
				dialog.text = "Ah, c'est donc vous "+ GetSexPhrase("le capitaine qui a ramené", "la fille qui a ramené") +" mon fils prodigue avec sa jeune fiancée ?";
				link.l1 = "Oui, je les ai aidés à s'enfuir.";
				link.l1.go = "EncGirl_5";
			}
			else
			{
				dialog.text = "Ah, vous voilà enfin,"+ GetSexPhrase(" mon bienfaiteur", " ma bienfaitrice") +". Vous attendez une récompense ?";
				link.l1 = "Eh bien, pas forcément une récompense, mais un peu de gratitude ferait plaisir.";
				link.l1.go = "EncGirl_6";
			}
		break;

		case "EncGirl_5":
			dialog.text = "Je vous suis très reconnaissant de ne pas avoir abandonné mon enfant dans l'embarras et de l'avoir aidé à se tirer avec honneur d'une situation aussi délicate. Permettez-moi de vous remercier comme je le peux. Acceptez cette modeste somme et un cadeau de ma part.";
			link.l1 = "Merci, ce fut un plaisir d'aider ces jeunes gens.";
			link.l1.go = "EncGirl_5_1";
		break;

		case "EncGirl_6":
			dialog.text = "Quelle gratitude ?! De la gratitude pour quoi ?! Non seulement ce benêt traîne sans travail depuis six mois, mais en plus il a trouvé le temps de s'amouracher ! Moi, à son âge, je dirigeais déjà ma propre affaire. Et voyez-moi ça, il est parti à la chasse ! Le gouverneur a une fille à marier, et celui-ci nous ramène une traînée sans feu ni lieu, Dieu me pardonne, et il demande la bénédiction paternelle !";
			link.l1 = "Hum, vous ne croyez donc pas aux sentiments sincères ?";
			link.l1.go = "EncGirl_6_1";
		break;

		case "EncGirl_5_1":
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.EncGirl.sum));
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "18");
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_6_1":
			dialog.text = "De quels sentiments parlez-vous ?! Quels sentiments ? Un adulte, une personne comme il faut, et puis voilà... Des sentiments ! Vous devriez avoir honte, vous les jeunes, de vous livrer à de telles choses, et de jouer les entremetteurs. La fille a été arrachée au nid de ses parents et la vie de mon nigaud est ruinée. Vous n'aurez aucune gratitude de ma part. Au revoir.";
			link.l1 = "Eh bien, portez-vous bien, vous aussi...";
			link.l1.go = "EncGirl_6_2";
		break;

		case "EncGirl_6_2":
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("JungleGirl", "19");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "trade_1":
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea) || (Pchar.location == "Caiman_Store");
		    if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
			    NextDiag.CurrentNode = NextDiag.TempNode;
			    DialogExit();
			    Pchar.PriceList.StoreManIdx = rColony.index; // boal 27.02.05
			    LaunchStore(sti(rColony.StoreNum));
			}
			else
			{
			    dialog.text = NPCharRepPhrase(npchar, pcharrepphrase("Vous vous moquez de moi ? Et oם est votre navire ? Il n'est pas au quai !",
				                                                     "Par le diable, on ne me la fait pas ! Votre navire n'est pas au quai !"),
													  pcharrepphrase("Je ne vois pas votre navire au port, capitaine " +GetFullName(pchar)+ ". J'espère que ce n'est pas le Hollandais volant ?",
													                 "Capitaine, il est plus commode de charger les marchandises depuis le quai. Amarrez le navire et revenez."));
				link.l1 = NPCharRepPhrase(npchar, pcharrepphrase("" +RandSwear()+"Quelle plaie !!! D'accord, vieille fouine, à plus tard !",
				                                                 "Je ne voulais pas vous tromper, " +GetFullName(npchar)+ ", le navire est de l'autre cכté de l'île."),
												  pcharrepphrase("Non, mon navire, c'est le Black Pearl. N'ayez pas peur ! Je plaisante !",
												                 "Merci du conseil, je ne manquerai pas de le suivre."));
			    link.l1.go = "exit";//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}
		break;

		case "storage_0":
			NPChar.MoneyForStorage = GetNpcQuestPastMonthParam(NPChar, "Storage.Date") * sti(NPChar.Storage.MoneyForStorage);
			if(sti(NPChar.MoneyForStorage) > 0)
			{
				dialog.text = "Je vous facturerai de nouveau la location : " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + ".";
				if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
				{
					link.l1 = "D'accord, je paie la location tout de suite.";
					link.l1.go = "storage_3";
				}
				else
				{
					link.l1 = "Je reviendrai plus tard.";
					link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "Entrez.";
				link.l1 = "Merci.";
				link.l1.go = "storage_2";
			}
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "exit";
		break;

		case "storage_01":
			dialog.text = "Non, "+ GetSexPhrase("mon cher", "ma belle") +", il vous attend. Je savais que vous ne laisseriez pas passer cette offre.";
			link.l1 = "Très bien. Je le loue.";
			link.l1.go = "storage_1";
			link.l2 = "Non, je m'en suis juste souvenu. J'en aurai peut-être besoin un jour...";
			link.l2.go = "exit";
		break;

		case "storage_1":
			NPChar.MoneyForStorage = GetStoragePriceExt(NPChar, pchar);
			dialog.text = "Comme vous le savez, le paiement se fait un mois d'avance.";
			if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
			{
				link.l1 = "Je m'en souviens, tenez.";
				link.l1.go = "storage_11";
			}
			else
			{
				link.l1 = "Bon sang. Je vais chercher l'argent.";
				link.l1.go = "exit";
			}
		break;

		case "storage_11":
			AddMoneyToCharacter(pchar, -makeint(NPChar.MoneyForStorage));
			NPChar.Storage.MoneyForStorage = NPChar.MoneyForStorage;
			NPChar.Storage.Activate = true;
			stores[sti(rColony.StoreNum)].Storage.Activate = true; // mirror rent flag onto store object - so store interface shows warehouse in the ship scroll
			SaveCurrentNpcQuestDateParam(NPChar, "Storage.Date");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchStorage(sti(rColony.StoreNum));
		break;

		case "storage_2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchStorage(sti(rColony.StoreNum));
		break;

		case "storage_3":
			AddMoneyToCharacter(pchar, -sti(NPChar.MoneyForStorage));
			NPChar.MoneyForStorage = GetStoragePriceExt(NPChar, pchar);
			NPChar.Storage.MoneyForStorage = NPChar.MoneyForStorage;
			SaveCurrentNpcQuestDateParam(NPChar, "Storage.Date");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchStorage(sti(rColony.StoreNum));
		break;

		case "storage_04":
			dialog.text = "Vous me libérez vraiment l'entrepכt ? Aïe aïe aïe, un si bel endroit, des conditions si avantageuses. Je vous assure qu'on ne vous proposera de tels services nulle part ailleurs dans les Caraïbes.";
			link.l1 = "Je vous l'ai dit : je le libère. Ou vous voudriez que je paie pour entreposer du vent ? Vous pouvez chercher un autre locataire.";
			link.l1.go = "storage_4";
			link.l2 = "On ne me proposera ça nulle part, dites-vous ? D'accord, je le garde pour l'instant. Mais le loyer est, comment dire... un peu élevé, en un mot.";
			link.l2.go = "exit";
		break;

		case "storage_4":
			NPChar.MoneyForStorage = GetNpcQuestPastMonthParam(NPChar, "Storage.Date") * sti(NPChar.Storage.MoneyForStorage);
			if(sti(NPChar.MoneyForStorage) > 0)
			{
				dialog.text = "Je vous facturerai de nouveau la location : " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + ".";
				if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
				{
					link.l1 = "D'accord.";
					link.l1.go = "storage_5";
				}
			}
			else
			{
				dialog.text = "Récupérez vos marchandises, et je fermerai l'entrepכt.";
				link.l1 = "D'accord.";
				link.l1.go = "storage_6";
			}
		break;

		case "storage_5":
			SetStorageGoodsToShip(&stores[sti(rColony.StoreNum)]);
			AddMoneyToCharacter(pchar, -sti(NPChar.MoneyForStorage));
			NPChar.Storage.NoActivate = true;
			DeleteAttribute(NPChar, "Storage.Activate");
			DeleteAttribute(&stores[sti(rColony.StoreNum)], "Storage.Activate"); // remove the mirror from the store object
			DialogExit();
		break;

		case "storage_6":
			SetStorageGoodsToShip(&stores[sti(rColony.StoreNum)]);
			DeleteAttribute(NPChar, "Storage.Activate");
			DeleteAttribute(&stores[sti(rColony.StoreNum)], "Storage.Activate"); // remove the mirror from the store object
			NPChar.Storage.NoActivate = true;
			DialogExit();
		break;

		case "items":
			if (npchar.quest.item_date != lastspeak_date)
			{
				GiveItemToTrader(npchar);
				npchar.quest.item_date = lastspeak_date;
			}
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
			LaunchItemsTrade(NPChar);
		break;

		case "business":
			iTest = 0;
    		//квест Синей Птицы, начальный диалог
			int iBlueBirdRank = 1;
			if (!bQuestsRank) iBlueBirdRank = 5; 	//Если стоит галочка, то убрать требования рангов у квестов
			if (pchar.questTemp.BlueBird == "begin" && sti(npchar.nation) != PIRATE && npchar.city != "Panama" && sti(pchar.rank) >= iBlueBirdRank)
			{
				dialog.text = RandPhraseSimple("Capitaine, aidez-nous, je vous en prie !!!", "Capitaine, je vous demande votre aide au nom de tous les marchands !");
				link.l1 = "Que s'est-il passé ? Comment puis-je vous aider ?";
				link.l1.go = "RBlueBird";
				break;
			}
//navy -->
			//занят ПГГ
			if(CheckAttribute(PChar, "CargoQuest.TraderID") && CheckAttribute(PChar, "CargoQuest.GiveTraderID")) bTradeQuest = pchar.CargoQuest.TraderID == NPChar.id || pchar.CargoQuest.GiveTraderID == NPChar.id;
			iTmp = CheckAvailableTaskForNPC(NPChar, PGG_TASK_WORKONSTORE);
			if (iTmp != -1 && !bTradeQuest)
			{
				dialog.text = "J'avais un travail, mais " + GetFullName(&Characters[iTmp]) + " s'est déjà engagé à le faire pour moi.";
				link.l1 = "Qu'est-ce que vous dites ! Bon, je reviendrai plus tard.";
				link.l1.go = "exit";
				break;
			}
//navy <--
			dialog.text = NPCharRepPhrase(npchar, "Qu'est-ce qui se passe ?! Racontez-moi tout dans l'ordre !", "Je vous écoute. De quelle affaire s'agit-il ?");
			// долг перед торговой гильдией: уладить можно в любом магазине нации торговца
			if (CheckAttribute(pchar, "GuildDebt") && sti(NPChar.nation) == sti(pchar.GuildDebt.nation))
			{
				link.lGuildDebt = "Je viens pour ma dette envers la guilde marchande. Je veux la régler.";
				link.lGuildDebt.go = "GuildDebt_Settle";
			}
			// loophole: bribe the guild clerk (before the deadline) - at the CONSIGNEE (the one we deliver to): goods and money off the books.
			// Storm && is not lazy - access CargoQuest.TraderID only inside the Freight_HasActive guard
			if (Freight_HasActive())
			{
				// convoy (type 7) excluded: serious state cargo, the clerk can't be bribed - only delivered to the commandant
				// a freight-blocked store (NoContraCity) offers no clerk bribe: the trader is sore at the player and waiting for the forfeit - shady deals with him here make no sense.
				// LEO: governor's escort also excluded - cargo is on the state convoy ships: bribing the clerk gains nothing (convoy leaves with the cargo, money wasted).
				if (pchar.CargoQuest.TraderID == npchar.id && sti(pchar.CargoQuest.iOrderType) != 7 && !CheckAttribute(pchar, "CargoQuest.GovEscortActive") && CheckQuestAttribute("generate_trade_quest_progress", "begin") && !CheckAttribute(pchar, "NoContraCity." + npchar.city))
				{
					link.lClerk = "(à voix basse) Et si ce connaissement... venait à disparaître ? La cargaison reste chez moi, rien dans les registres. Je paierai bien.";
					link.lClerk.go = "FreightClerk_Offer";
				}
			}
            ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea) || (Pchar.location.from_sea == "Shore17");
            if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
    			if (CheckQuestAttribute("generate_trade_quest_progress", "begin") || CheckQuestAttribute("generate_trade_quest_progress",  "failed"))
    			{
    				if (pchar.CargoQuest.TraderID == npchar.id )//&&  GetSquadronGoods(pchar, iQuestTradeGoods) >= iQuantityShipGoods)
    				{
    					if (sti(pchar.CargoQuest.iOrderType) == 5) // CARGO_SMUGGLE - a legit shopkeeper won't take contraband, need the smuggler agent
    					{
    						link.l2 = "J'ai... cette cargaison spéciale. Oם la voulez-vous ?";
    						link.l2.go = "smuggle_wrong_trader";
    					}
    					else if (sti(pchar.CargoQuest.iOrderType) == 6) // CARGO_GOVERNOR - state cargo, delivered to the residence
    					{
    						link.l2 = "Je transporte une cargaison d'וtat. Oם la voulez-vous ?";
    						link.l2.go = "governor_wrong_trader";
    					}
    					else if (sti(pchar.CargoQuest.iOrderType) == 7) // CARGO_FORTAMMO - ammunition, delivered to the fort commandant
    					{
    						link.l2 = "Je transporte une cargaison de munitions. Oם la voulez-vous ?";
    						link.l2.go = "fortammo_wrong_trader";
    					}
    					else
    					{
    						link.l2 = RandPhraseSimple("Il y a dans la cale de mon navire une cargaison pour votre boutique.", "Mon navire a été affrété pour livrer une cargaison à votre boutique. Les marchandises sont déjà en train d'être déchargées.");
    						link.l2.go = "generate_quest_2";
    					}
    				}
    				else
    				{
                        if (CheckQuestAttribute("generate_trade_quest_progress", "failed") && pchar.CargoQuest.GiveTraderID == npchar.id)
                        {
                            // LEO: failed freight - settle it with the employer who issued it. The generate_quest_failed node
                            // used to be orphaned (never routed to), so the player got stuck in the dead-end not_closed. Now we route to the failure settlement.
                            link.l2 = "Je sais que j'ai dépassé le délai du fret. Comment puis-je me racheter ?";
            				link.l2.go = "generate_quest_failed";
                        }
                        else if (!CheckQuestAttribute("generate_trade_quest_progress",  "failed") && pchar.CargoQuest.GiveTraderID == npchar.id && GetNationRelation2MainCharacter(sti(characters[GetCharacterIndex(pchar.CargoQuest.TraderID)].nation)) == RELATION_ENEMY)
                        {
                            link.l2 = "Malheureusement, je dois renoncer à mes engagements. La situation politique ne me permet pas de livrer la cargaison.";
            				link.l2.go = "generate_quest_cannot_done";
                        }
                        else
                        {
                            if (rand(1) == 1)
                            {
                                link.l2 = RandPhraseSimple("Je voudrais vous proposer d'affréter mon navire pour un transport de marchandises.",
								                           "J'ai un beau navire, et je peux livrer n'importe quelle cargaison oם vous voudrez.");
            				    link.l2.go = "generate_quest_not_closed";
        				    }
    				    }
    				}
    			}
    			else
    			{
    				link.l2 = "Vous ne voulez pas affréter un navire, " +GetAddress_FormToNPC(NPChar)+ " ? J'ai un navire fiable et des marins expérimentés.";
    				link.l2.go = "generate_quest";
    			}
    			// --> на кредитный генератор
    			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
    			{
	                link.l3 = pcharrepphrase(RandPhraseSimple("Eh, en mer, on s'épuise... Voilà l'affaire, l'ami : la question d'argent devient pressante.",
	                                                          "Bon, vieille canaille, parlons de nos affaires d'argent."),
	                                        RandPhraseSimple("Je voulais discuter avec vous de questions financières.",
	                                                         "Parlons finances, nous avons de quoi discuter."));,

	                link.l3.go = "LoanForAll";
                }
				//квест мэра - на связь с нашим шпионом
  				if (CheckAttribute(pchar, "GenQuest.Intelligence.SpyId") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "")
				{
					link.l4 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
						GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chercher quelque chose...");
					link.l4.go = "IntelligenceForAll";
				}
				// ----------------- квест получения Синей Птицы, сдаём квест -----------------
				if (pchar.questTemp.BlueBird == "weWon" && pchar.questTemp.BlueBird.traiderId == npchar.id)
				{
					link.l1 = "Je tiens à vous informer que j'ai réussi à accomplir votre mission. Le chébec « Oiseau bleu » n'importunera plus les marchands. Je viens chercher la rémunération convenue.";
					link.l1.go = "RBlueBirdWon";
				}
				if (pchar.questTemp.BlueBird == "DieHard" && pchar.questTemp.BlueBird.traiderId == npchar.id)
				{
					link.l1 = "Je dois vous informer que je n'ai pas réussi à couler le chébec « Oiseau bleu ». J'ai fait tout ce que j'ai pu...";
					link.l1.go = "RBlueBirdDieHard";
				}
				if (pchar.questTemp.BlueBird == "returnMoney" && pchar.questTemp.BlueBird.traiderId == npchar.id && sti(pchar.questTemp.BlueBird.count) > 0)
				{
					if (sti(pchar.questTemp.BlueBird.count) < 5)
					{
						link.l1 = "Comment vont les flמtes de vos collègues ? Tout va bien ?";
						link.l1.go = "RBlueBird_retMoney_1";
					}
					else
					{
						link.l1 = "Vous avez fini par entendre raison, vous voulez me donner l'argent que j'ai honnêtement gagné ?";
						link.l1.go = "RBlueBird_retMoney_3";
					}
				}
				// ----------------- квест получения Синей Птицы, продолжение -----------------
				//homo 25/06/06 слухи
                link.l6 = pcharrepphrase(RandPhraseSimple("Vous me racontez les derniers potins ? De toute façon, vous êtes coincé ici toute la journée.",
                                                          "Ne t'agite pas, vieille canaille, raconte-moi plutכt comment va la vie à terre ?"),
                                        RandPhraseSimple("J'ai l'impression d'être en mer depuis une éternité. Quoi de neuf dans le coin ?",
                                                         "Vous connaissez sמrement les dernières nouvelles ? Que s'est-il passé d'important ?"));,

    		    link.l6.go = "rumours_trader";

				// ugeen --> склад товаров для ГГ
				if(NPChar.city != "Pirates")
				{
					if(!CheckAttribute(NPChar, "Storage.NoActivate"))
					{
						link.l7 = "Est-il possible de vous louer un entrepכt ?";
						link.l7.go = "storage_rent";
					}
					if(CheckAttribute(NPChar, "Storage.NoActivate") && !CheckAttribute(NPChar, "Storage.Activate"))
					{
						link.l7 = "J'aimerais vous louer de nouveau un entrepכt.";
						link.l7.go = "storage_rent";
					}
				}
				if(CheckAttribute(NPChar, "Storage"))
				{
					if(CheckAttribute(NPChar, "Storage.Activate"))
					{
						stores[sti(rColony.StoreNum)].Storage.Activate = true; // re-sync rent mirror onto store object (existing saves: show warehouse in store scroll)
						link.l7 = "Menez-moi à l'entrepכt. Je veux voir dans quel état il est.";
						link.l7.go = "storage_0";
						link.l8 = "J'ai décidé de libérer l'entrepכt. Je n'en ai plus besoin.";
						link.l8.go = "storage_04";
					}
					else
					{
						if(!CheckAttribute(NPChar, "Storage.NoActivate") && CheckAttribute(pchar, "questTemp.BlueBird.speakWon"))
						{
							link.l7 = "Je me souviens que vous aviez parlé d'un entrepכt. La place est-elle encore prise ?";
							link.l7.go = "storage_01";
						}
					}
				}
				// <-- ugeen
				// <-- homo
				if (CheckOfficersPerk(pchar, "Trader"))
				{
					link.l8 = "Collègue, vous me feriez part des prix que vous connaissez ?";
					link.l8.go = "GetTradeInfo";
				}
				link.l99 = "Mais ce n'est pas le moment de parler.";
    			link.l99.go = "no_quests";
			}
			else
			{
                link.l1 = NPCharRepPhrase(npchar, pcharrepphrase("" +RandSwear()+"J'ai laissé mon navire de l'autre cכté de l'île. Je reviendrai plus tard !", "Excusez-moi, " +GetFullName(npchar)+ ", je reviendrai plus tard. Mon navire n'est pas encore arrivé au quai."), pcharrepphrase("Diable ! Ces fainéants n'ont pas mis le navire au chargement ! Je reviendrai plus tard !", "Désolé, je dois donner l'ordre d'amener votre navire au quai !"));
                link.l1.go = "exit";
    			// --> на кредитный генератор
    			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
    			{
	                link.l3 = pcharrepphrase(RandPhraseSimple("Eh, en mer, on s'épuise... Voilà l'affaire, l'ami : la question d'argent devient pressante.",
	                                                          "Bon, vieille canaille, parlons de nos affaires d'argent."),
	                                        RandPhraseSimple("Je voulais discuter avec vous de questions financières.",
	                                                         "Parlons finances, nous avons de quoi discuter."));,

	                link.l3.go = "LoanForAll";
                }
				//квест мэра - на связь с нашим шпионом
  				if (CheckAttribute(pchar, "GenQuest.Intelligence.SpyId") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "")
				{
					link.l7 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
						GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chercher quelque chose...");
					link.l7.go = "IntelligenceForAll";
				}
			}
		break;

		case "generate_quest":
			int slot; string sErr; string aName;
			int otype, g, qty, maxDays, dexp;
			string sToCity;

			if (sti(NPChar.nation) != PIRATE && GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY)
			{
				dialog.text = "Non, inutile ! Du moins tant que vous serez en froid avec " + NationNameAblative(sti(NPChar.nation)) + ".";
				link.l1 = "Dans ce cas, au revoir.";
				link.l1.go = "exit";
				break;
			}
			// refuse if reputation is too low / отказ при плохой репутации
			if (isBadReputation(pchar, 40))
			{
				dialog.text = RandSwear() + "N'est-ce pas, " + GetFullName(pchar)+ ", à votre sujet... " + RandPhraseSimple("il court de terribles rumeurs.", "on ne dit pas que du bien.") + " Je ne veux pas traiter avec vous.";
				link.l1 = RandPhraseSimple("Eh... il suffit qu'un homme trébuche pour que tout le monde lui crache dessus.", RandSwear()+ " Bon, il y a des choses plus intéressantes à faire en mer, " + GetFullName(npchar)+".");
				link.l1.go = "exit";
				break;
			}

			// === заказы на дневном рандоме (dRand): стабильны сутки и переживают перезагрузку ===
			RecalculateSquadronCargoLoad(pchar);
			sErr = "";
			if (GuildDebt_IsFreightBlocked()) sErr = "guilddebt"; // чёрные списки гильдии: присвоил фрахтовый груз - фрахтов не видать
				if (sErr == "" && CheckAttribute(pchar, "NoContraCity." + npchar.city)) sErr = "contrablock"; // кинул контра-фрахт ЭТОГО магазина - он не даёт НИКАКИХ фрахтов, пока не уладишь через связного
			// LEO: один фрахт из порта в сутки. Список заказов дневной и за сутки не меняется, а закрыть
			//   фрахт можно не доходя до адресата (слить конвой посыльному прямо в море) - без этого заказ
			//   крутился по кругу. Честной игре не мешает: рейс до адресата и обратно дольше суток.
			if (sErr == "" && CheckAttribute(pchar, "FreightLastTake.city"))
			{
				if (pchar.FreightLastTake.city == npchar.city && GetQuestPastDayParam("FreightLastTake") < 1) sErr = "takentoday";
			}

			for (slot = 1; slot <= 3; slot++)
			{
				aName = "iTradeNation" + slot;
				npchar.(aName) = GenerateNationTrade(sti(NPChar.nation));
			}
			if (sErr == "" && sti(npchar.iTradeNation1) < 0 && sti(npchar.iTradeNation2) < 0 && sti(npchar.iTradeNation3) < 0) sErr = "nofreight";

			if (sErr == "")
			{
				for (slot = 1; slot <= 3; slot++)
				{
					aName = "storeMan" + slot;
					npchar.(aName) = findStoreMan(NPChar, slot - 1);
				}
				if (sti(npchar.storeMan1) <= 0 || sti(npchar.storeMan2) <= 0 || sti(npchar.storeMan3) <= 0) sErr = "political";
			}

			if (sErr == "")
			{
				// в пиратских поселениях не выдаём контрабандный/губернаторский фрахт (нет официального губернатора, а контрабанда среди пиратов бессмысленна)
				bool bAllowSpecialFreight = (sti(NPChar.nation) != PIRATE);
				for (slot = 1; slot <= 3; slot++)
				{
					otype = RollCargoOrderType(slot, bAllowSpecialFreight);
					// loophole 2: if the player kept a contraband freight from this city, the brotherhood closed the channel - no more contra orders here (demote to standard)
					if (otype == 5 && CheckAttribute(pchar, "NoContraCity." + npchar.city)) otype = 1;

					aName = "storeMan" + slot;
					sToCity = Characters[sti(npchar.(aName))].city;

					// anti-softlock (all cities one nation / all pirate): governor(6)/commandant(7) to a pirate
					// destination or a fortless town has no one to deliver to (no governor/commandant) - demote to a normal order
					if (otype == 6 || otype == 7)
					{
						int iDestCol = FindColony(sToCity);
						if (iDestCol < 0) otype = 1;
						else
						{
							if (sti(Colonies[iDestCol].nation) == PIRATE) otype = 1;
							else if (otype == 7 && CheckAttribute(&Colonies[iDestCol], "HasNoFort")) otype = 1;
						}
					}
					aName = "iOrderType" + slot;     npchar.(aName) = otype;

					aName = "iTradeIsland" + slot;   npchar.(aName) = GetIslandByCityName(sToCity);
					maxDays = GetMaxDaysFromIsland2Island(GetArealByCityName(NPChar.city), GetArealByCityName(sToCity));

					g = -1;
					// КОНТРАБАНДА (5): возим РЕАЛЬНЫЙ контрабандный товар острова-отправителя (не топ-10).
					// Нет контрабанды на острове - контра-фрахт не даём: демотим в обычный (перезаписываем тип).
					if (otype == 5)
					{
						g = GetCargoContrabandGood(slot, NPChar.city);
						if (g < 0)
						{
							otype = 1;
							aName = "iOrderType" + slot;    npchar.(aName) = otype;
						}
					}
					// ГУБЕРНАТОРСКИЙ (6): возим товар АГРЕССИВНОГО СПРОСА (коричневый) магазина-отправителя.
					// Нет такого товара на острове - губ.фрахт не даём: демотим в обычный (перезаписываем тип).
					if (otype == 6)
					{
						g = GetCargoAggressiveGood(slot, NPChar.city);
						if (g < 0)
						{
							otype = 1;
							aName = "iOrderType" + slot;    npchar.(aName) = otype;
						}
					}
					// ЖИВАЯ ЭКОНОМИКА (базовые типы 0..4): возим то, что дёшево здесь и дорого у адресата
					if (g < 0 && otype <= 4) g = GetCargoLiveGood(slot, otype, NPChar.city, sToCity);
					if (g < 0) g = GetCargoOrderGood(otype, slot); // спец-типы и фоллбек, если выгодных пар нет
					aName = "iTradeGoods" + slot;    npchar.(aName) = g;

					qty = GetCargoOrderQty(otype, GetSquadronFreeSpace(pchar, g), slot);
					if (otype == 7) qty = GetFortConvoyRequiredWeight(); // конвой: объём не зависит от трюма ГГ (груз везут барки), храним требуемый ВЕС
					aName = "iQuantityGoods" + slot; npchar.(aName) = qty;

					dexp = GetCargoOrderDays(otype, maxDays, slot);
					aName = "iDaysExpired" + slot;   npchar.(aName) = dexp;
					aName = "iMaxDays" + slot;     npchar.(aName) = maxDays; // для премии эскорта (как у конвоя)

					// доля ГГ = 25% от прибыли перевозки по живым ценам; фоллбек - старая формула (спец-типы/нет пары)
					aName = "iMoney" + slot;
					npchar.(aName) = 0;
					if (otype <= 4) npchar.(aName) = GetCargoLiveMoney(otype, g, qty, NPChar.city, sToCity);
					if (otype == 7) npchar.(aName) = GetFortConvoyMoney(maxDays, dexp); // конвой: очень высокая плата за риски
					if (sti(npchar.(aName)) <= 0) npchar.(aName) = GetCargoOrderMoney(otype, qty, g, maxDays, dexp);

					// стоимость груза по живой цене отправителя - показывается в тексте заказа
					aName = "iCargoCost" + slot;
					if (otype == 7) npchar.(aName) = 0; // конвой: груз смешанный, стоимость в заказе не показываем
					else if (otype == 5) npchar.(aName) = 0; // LEO: контрабанда - стоимость груза в заказе НЕ показываем (лишняя сумма путала: платится только "моя доля")
						else if (otype == 6) npchar.(aName) = GetCargoBaseCost(g, qty); // губернаторский: по базовой стоимости
					else npchar.(aName) = GetCargoLiveCost(g, qty, NPChar.city);
					// LEO: фолбэк стоимости (как у оплаты выше) - магазин отправителя может вообще не торговать
					// этим товаром, тогда живая цена = 0. Чаще всего ловится на скоропорте: его товар берётся
					// из фикс-списка съестного БЕЗ сверки с ассортиментом магазина. Без фолбэка "(груз на N)"
					// молча пропадало из текста заказа.
					if (otype != 5)
					{
						if (otype != 7)
						{
							if (sti(npchar.(aName)) <= 0) npchar.(aName) = GetCargoBaseCost(g, qty);
						}
					}
				}
				if (sti(npchar.iQuantityGoods1) < 100 || sti(npchar.iQuantityGoods2) < 100 || sti(npchar.iQuantityGoods3) < 100) sErr = "shipsmall";
			}

			if (sErr == "guilddebt")
			{
				dialog.text = "Un fret ? Pour vous ?! (Le marchand referme brusquement son carnet de commandes.) La guilde vous a mis sur liste noire, "+GetAddress_Form(NPChar)+". Détourner la cargaison d'un autre, puis venir demander un nouveau fret... Quelle insolence.";
				link.l1 = "C'est ce qu'on verra. Bonne journée.";
				link.l1.go = "exit";
			}
			else if (sErr == "contrablock")
			{
				dialog.text = "(Le marchand secoue froidement la tête.) Un fret ? Après ce que vous avez fait de ma cargaison, "+GetAddress_Form(NPChar)+" ? N'y pensez même pas. Réglez vos comptes avec les bonnes personnes, et ensuite nous parlerons.";
				link.l1 = "Compris. Bonne journée.";
				link.l1.go = "exit";
			}
			else if (sErr == "takentoday")
			{
				dialog.text = NPCharRepPhrase(npchar, "Pas de commandes pour aujourd'hui, "+GetAddress_Form(NPChar)+". Revenez demain.", "Plus de commandes pour aujourd'hui, "+GetAddress_Form(NPChar)+". Repassez demain.");
				link.l1 = "Très bien, je reviendrai demain.";
				link.l1.go = "exit";
			}
			else if (sErr == "nofreight")
			{
				dialog.text = NPCharRepPhrase(npchar, "Eh, "+GetAddress_Form(NPChar)+", pas d'affrètement aujourd'hui. Revenez demain.", "Revenez demain. Je vous ferai peut-être une bonne offre.");
				link.l1 = "D'accord, je reviendrai demain.";
				link.l1.go = "exit";
			}
			else if (sErr == "political")
			{
				dialog.text = "La situation politique dans l'archipel ne me permet pas de commercer avec "+ XI_ConvertString(NationShortName(sti(NPChar.nation))+"hunter") + " en guerre contre tout le monde, et je suis le seul à qui il reste une boutique.";
				link.l1 = "Oh ! Désolé. Bonne journée.";
				link.l1.go = "exit";
			}
			else if (sErr == "shipsmall")
			{
				dialog.text = NPCharRepPhrase(npchar, "Votre misérable rafiot ne pourra pas contenir toute la cargaison, il n'y aura pas d'affaire aujourd'hui.", "Malheureusement, capitaine "+GetFullName(pchar)+", il me faut un navire plus grand que le vכtre pour livrer la cargaison.");
				link.l1 = NPCharRepPhrase(npchar, "J'ai un navire convenable, mais je comprends. Au revoir.", "Je vous comprends, les affaires avant tout. Au revoir.");
				link.l1.go = "exit";
			}
			else
			{
				SaveCurrentQuestDateParam("CargoQuest");
				// LEO: надбавка постоянного клиента (0-60%) к "моей доле" обычных фрахтов у ЭТОГО работодателя (не казённый конвой/эскорт).
				int iFreightLoy = Freight_LoyaltyPct(NPChar);
				// LEO: надбавку показываем У ИМЕНИ ("+X%" зелёным + " to the reward"), а не в тексте. 0% -> ничего.
				if (iFreightLoy >= 1) { NPChar.NameBonus = "+" + iFreightLoy + "%"; NPChar.NameBonusTail = " à la récompense"; }
				if (sti(npchar.iOrderType1) != 7) npchar.iMoney1 = sti(npchar.iMoney1) * (100 + iFreightLoy) / 100;
				if (sti(npchar.iOrderType2) != 7) npchar.iMoney2 = sti(npchar.iMoney2) * (100 + iFreightLoy) / 100;
				if (sti(npchar.iOrderType3) != 7) npchar.iMoney3 = sti(npchar.iMoney3) * (100 + iFreightLoy) / 100;
				NPChar.sNation1 = XI_ConvertString("Colony"+Characters[sti(npchar.storeMan1)].city);
				NPChar.sNation2 = XI_ConvertString("Colony"+Characters[sti(npchar.storeMan2)].city);
				NPChar.sNation3 = XI_ConvertString("Colony"+Characters[sti(npchar.storeMan3)].city);
				NPChar.sTemp1 = ""; NPChar.sTemp2 = ""; NPChar.sTemp3 = "";
				if (npchar.iTradeIsland1 != Characters[sti(npchar.storeMan1)].city) NPChar.sTemp1 = " sur l'île de "  + XI_ConvertString(npchar.iTradeIsland1+"Voc");
				if (npchar.iTradeIsland2 != Characters[sti(npchar.storeMan2)].city) NPChar.sTemp2 = " sur l'île de "  + XI_ConvertString(npchar.iTradeIsland2+"Voc");
				if (npchar.iTradeIsland3 != Characters[sti(npchar.storeMan3)].city) NPChar.sTemp3 = " sur l'île de "  + XI_ConvertString(npchar.iTradeIsland3+"Voc");

				dialog.text = "Un instant, je vais chercher mon registre. Voilà ce qu'il faut livrer en ce moment. Choisissez la commande qui vous convient le mieux.";
				link.l1 = "[" + GetCargoOrderName(sti(npchar.iOrderType1)) + "] " + "Je m'engage à livrer une cargaison : " + GetGoodsNameAlt(sti(npchar.iTradeGoods1)) + " – en quantité de " + FindRussianQtyStringClr(sti(npchar.iQuantityGoods1), "\7") + " – vers la ville de " + NPChar.sNation1 + NPChar.sTemp1 + GetCargoCostNoteClr(sti(npchar.iCargoCost1), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney1), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired1))) + ".";
				link.l1.go = "exit_trade1";
				link.l2 = "[" + GetCargoOrderName(sti(npchar.iOrderType2)) + "] " + "Je m'engage à livrer une cargaison : " + GetGoodsNameAlt(sti(npchar.iTradeGoods2)) + " – en quantité de " + FindRussianQtyStringClr(sti(npchar.iQuantityGoods2), "\7") + " – vers la ville de " + NPChar.sNation2 + NPChar.sTemp2 + GetCargoCostNoteClr(sti(npchar.iCargoCost2), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney2), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired2))) + ".";
				link.l2.go = "exit_trade2";
				link.l3 = "[" + GetCargoOrderName(sti(npchar.iOrderType3)) + "] " + "Je m'engage à livrer une cargaison : " + GetGoodsNameAlt(sti(npchar.iTradeGoods3)) + " – en quantité de " + FindRussianQtyStringClr(sti(npchar.iQuantityGoods3), "\7") + " – vers la ville de " + NPChar.sNation3 + NPChar.sTemp3 + GetCargoCostNoteClr(sti(npchar.iCargoCost3), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney3), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired3))) + ".";
				link.l3.go = "exit_trade3";
				// контрабандный заказ - только для неприметной эскадры (не больше 3 кораблей, каждый не мощнее 3 класса)
				if (sti(npchar.iOrderType1) == 5 && !CheckSmuggleFreightShips()) link.l1.go = "smuggle_need_small_fleet";
				if (sti(npchar.iOrderType2) == 5 && !CheckSmuggleFreightShips()) link.l2.go = "smuggle_need_small_fleet";
				if (sti(npchar.iOrderType3) == 5 && !CheckSmuggleFreightShips()) link.l3.go = "smuggle_need_small_fleet";
				// комендантский конвой: свой текст заказа (груз смешанный, везут казённые барки) + нужны 4 свободных места в эскадре
				if (sti(npchar.iOrderType1) == 7) link.l1 = "[" + GetCargoOrderName(7) + "] " + "Je m'engage à escorter un convoi : quatre navires de l'וtat chargés de poudre et de munitions pour le fort de " + NPChar.sNation1 + NPChar.sTemp1 + "\2" + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney1), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired1))) + ".";
				if (sti(npchar.iOrderType2) == 7) link.l2 = "[" + GetCargoOrderName(7) + "] " + "Je m'engage à escorter un convoi : quatre navires de l'וtat chargés de poudre et de munitions pour le fort de " + NPChar.sNation2 + NPChar.sTemp2 + "\2" + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney2), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired2))) + ".";
				if (sti(npchar.iOrderType3) == 7) link.l3 = "[" + GetCargoOrderName(7) + "] " + "Je m'engage à escorter un convoi : quatre navires de l'וtat chargés de poudre et de munitions pour le fort de " + NPChar.sNation3 + NPChar.sTemp3 + "\2" + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney3), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired3))) + ".";
				// governor subtype rolled AT GENERATION (stable by dRand), stored per slot - order is labelled
				// [Governor's escort] in the list, no submenu-confirm on taking
				DeleteAttribute(npchar, "GovSubtype1"); DeleteAttribute(npchar, "GovSubtype2"); DeleteAttribute(npchar, "GovSubtype3");
				if (sti(npchar.iOrderType1) == 6) npchar.GovSubtype1 = 1 + dRandSlotLow(1, 2); // 2 = ESCORT (~1/3, if conditions); 1/3 = plain governor. Swap is a SEPARATE 25-50% chance on non-escort (trade_quest_open)
				if (sti(npchar.iOrderType2) == 6) npchar.GovSubtype2 = 1 + dRandSlotLow(2, 2);
				if (sti(npchar.iOrderType3) == 6) npchar.GovSubtype3 = 1 + dRandSlotLow(3, 2);
				// subtype 2 + conditions (GovEscort_CanTake) -> [Governor's escort] label + escort-a-convoy text
				if (sti(npchar.iOrderType1) == 6 && sti(npchar.GovSubtype1) == 2 && GovEscort_CanTake()) npchar.iMoney1 = GetGovEscortMoney(sti(npchar.iMaxDays1), sti(npchar.iDaysExpired1)); // премия эскорта = % стоимости охраняемого груза
				if (sti(npchar.iOrderType2) == 6 && sti(npchar.GovSubtype2) == 2 && GovEscort_CanTake()) npchar.iMoney2 = GetGovEscortMoney(sti(npchar.iMaxDays2), sti(npchar.iDaysExpired2));
				if (sti(npchar.iOrderType3) == 6 && sti(npchar.GovSubtype3) == 2 && GovEscort_CanTake()) npchar.iMoney3 = GetGovEscortMoney(sti(npchar.iMaxDays3), sti(npchar.iDaysExpired3));
				if (sti(npchar.iOrderType1) == 6 && sti(npchar.GovSubtype1) == 2 && GovEscort_CanTake()) npchar.iCargoCost1 = GetGovEscortCargoValue(sti(npchar.iTradeGoods1)); // стоимость охраняемого груза (полная загрузка)
				if (sti(npchar.iOrderType2) == 6 && sti(npchar.GovSubtype2) == 2 && GovEscort_CanTake()) npchar.iCargoCost2 = GetGovEscortCargoValue(sti(npchar.iTradeGoods2)); // стоимость охраняемого груза (полная загрузка)
				if (sti(npchar.iOrderType3) == 6 && sti(npchar.GovSubtype3) == 2 && GovEscort_CanTake()) npchar.iCargoCost3 = GetGovEscortCargoValue(sti(npchar.iTradeGoods3)); // стоимость охраняемого груза (полная загрузка)
				if (sti(npchar.iOrderType1) == 6 && sti(npchar.GovSubtype1) == 2 && GovEscort_CanTake()) link.l1 = "[Escorte du gouverneur] Je m'engage à escorter un convoi transportant " + GetGoodsNameAlt(sti(npchar.iTradeGoods1)) + " – en quantité de " + FindRussianQtyStringClr(GetGovEscortCargoQty(sti(npchar.iTradeGoods1)), "\7") + " – vers la ville de " + NPChar.sNation1 + NPChar.sTemp1 + GetCargoCostNoteClr(sti(npchar.iCargoCost1), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney1), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired1))) + ".";
				if (sti(npchar.iOrderType2) == 6 && sti(npchar.GovSubtype2) == 2 && GovEscort_CanTake()) link.l2 = "[Escorte du gouverneur] Je m'engage à escorter un convoi transportant " + GetGoodsNameAlt(sti(npchar.iTradeGoods2)) + " – en quantité de " + FindRussianQtyStringClr(GetGovEscortCargoQty(sti(npchar.iTradeGoods2)), "\7") + " – vers la ville de " + NPChar.sNation2 + NPChar.sTemp2 + GetCargoCostNoteClr(sti(npchar.iCargoCost2), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney2), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired2))) + ".";
				if (sti(npchar.iOrderType3) == 6 && sti(npchar.GovSubtype3) == 2 && GovEscort_CanTake()) link.l3 = "[Escorte du gouverneur] Je m'engage à escorter un convoi transportant " + GetGoodsNameAlt(sti(npchar.iTradeGoods3)) + " – en quantité de " + FindRussianQtyStringClr(GetGovEscortCargoQty(sti(npchar.iTradeGoods3)), "\7") + " – vers la ville de " + NPChar.sNation3 + NPChar.sTemp3 + GetCargoCostNoteClr(sti(npchar.iCargoCost3), "\7") + ", ma part : " + FindRussianMoneyStringClr(sti(npchar.iMoney3), "\4") + ", dans un délai de " + FindRussianDaysString(makeint(sti(npchar.iDaysExpired3))) + ".";
				int iFreeSlots = COMPANION_MAX - GetCompanionQuantity(pchar);
				if (sti(npchar.iOrderType1) == 7 && iFreeSlots < 4) link.l1.go = "fortammo_need_slots";
				if (sti(npchar.iOrderType2) == 7 && iFreeSlots < 4) link.l2.go = "fortammo_need_slots";
				if (sti(npchar.iOrderType3) == 7 && iFreeSlots < 4) link.l3.go = "fortammo_need_slots";
				link.l4 = "Je dois y réfléchir.";
				link.l4.go = "exit";
			}
		break;

		case "exit_trade":
			AddDialogExitQuest("trade_quest_open");
			Nextdiag.CurrentNode = Nextdiag.TempNode;
			DialogExit();
		break;
		case "exit_trade1":
			dialog.text = "Parfait ! Permettez-moi de commencer le chargement.";
			link.l1 = "Allez-y, mon cher !";
			link.l1.go = "exit";
			pchar.CargoQuest.iDaysExpired = sti(npchar.iDaysExpired1);
    		pchar.CargoQuest.iTradeGoods = npchar.iTradeGoods1;
    		pchar.CargoQuest.iQuantityGoods = sti(npchar.iQuantityGoods1);
    		pchar.CargoQuest.iMoney = sti(npchar.iMoney1);
    		pchar.CargoQuest.iTradeNation = sti(npchar.iTradeNation1);
    		pchar.CargoQuest.iTradeColony = Characters[sti(npchar.storeMan1)].city;
    		pchar.CargoQuest.iTradeIsland = npchar.iTradeIsland1;
			pchar.CargoQuest.iOrderType = npchar.iOrderType1;
			if (sti(npchar.iOrderType1) == 7) dialog.text = "Excellent ! Les navires sont déjà dans le port, leurs capitaines se présenteront à vous en rade : le convoi est désormais sous vos ordres. Prenez-en soin, capitaine : la poudre est une cargaison nerveuse.";
			pchar.CargoQuest.TraderID     = Characters[sti(npchar.storeMan1)].id;
    		pchar.CargoQuest.GiveTraderID = NPChar.id;
			pchar.CargoQuest.GovSubtype = 0;
			if (sti(pchar.CargoQuest.iOrderType) == 6) pchar.CargoQuest.GovSubtype = sti(npchar.GovSubtype1); // подтип выпал при генерации (в списке уже подписан)
			if (sti(pchar.CargoQuest.GovSubtype) == 2 && GovEscort_CanTake()) dialog.text = "Excellent ! Le convoi de cargaison importante est déjà dans le port, ses capitaines se présenteront à vous en rade : les navires sont sous vos ordres. Menez-les à bon port, et vous serez payé.";
			AddDialogExitQuest("trade_quest_open");
			Nextdiag.CurrentNode = Nextdiag.TempNode;
		break;
		case "exit_trade2":
			dialog.text = "Parfait ! Permettez-moi de commencer le chargement.";
			link.l1 = "Allez-y, mon cher !";
			link.l1.go = "exit";
			pchar.CargoQuest.iDaysExpired = sti(npchar.iDaysExpired2);
    		pchar.CargoQuest.iTradeGoods = npchar.iTradeGoods2;
    		pchar.CargoQuest.iQuantityGoods = sti(npchar.iQuantityGoods2);
    		pchar.CargoQuest.iMoney = sti(npchar.iMoney2);
    		pchar.CargoQuest.iTradeNation = sti(npchar.iTradeNation2);
    		pchar.CargoQuest.iTradeColony = Characters[sti(npchar.storeMan2)].city;
    		pchar.CargoQuest.iTradeIsland = npchar.iTradeIsland2;
			pchar.CargoQuest.iOrderType = npchar.iOrderType2;
			if (sti(npchar.iOrderType2) == 7) dialog.text = "Excellent ! Les navires sont déjà dans le port, leurs capitaines se présenteront à vous en rade : le convoi est désormais sous vos ordres. Prenez-en soin, capitaine : la poudre est une cargaison nerveuse.";
			pchar.CargoQuest.TraderID     = Characters[sti(npchar.storeMan2)].id;
    		pchar.CargoQuest.GiveTraderID = NPChar.id;
			pchar.CargoQuest.GovSubtype = 0;
			if (sti(pchar.CargoQuest.iOrderType) == 6) pchar.CargoQuest.GovSubtype = sti(npchar.GovSubtype2); // подтип выпал при генерации (в списке уже подписан)
			if (sti(pchar.CargoQuest.GovSubtype) == 2 && GovEscort_CanTake()) dialog.text = "Excellent ! Le convoi de cargaison importante est déjà dans le port, ses capitaines se présenteront à vous en rade : les navires sont sous vos ordres. Menez-les à bon port, et vous serez payé.";
			AddDialogExitQuest("trade_quest_open");
			Nextdiag.CurrentNode = Nextdiag.TempNode;
		break;
		case "exit_trade3":
			dialog.text = "Parfait ! Permettez-moi de commencer le chargement.";
			link.l1 = "Allez-y, mon cher !";
			link.l1.go = "exit";
			pchar.CargoQuest.iDaysExpired = sti(npchar.iDaysExpired3);
    		pchar.CargoQuest.iTradeGoods = npchar.iTradeGoods3;
    		pchar.CargoQuest.iQuantityGoods = sti(npchar.iQuantityGoods3);
    		pchar.CargoQuest.iMoney = sti(npchar.iMoney3);
    		pchar.CargoQuest.iTradeNation = sti(npchar.iTradeNation3);
    		pchar.CargoQuest.iTradeColony = Characters[sti(npchar.storeMan3)].city;
    		pchar.CargoQuest.iTradeIsland = npchar.iTradeIsland3;
			pchar.CargoQuest.iOrderType = npchar.iOrderType3;
			if (sti(npchar.iOrderType3) == 7) dialog.text = "Excellent ! Les navires sont déjà dans le port, leurs capitaines se présenteront à vous en rade : le convoi est désormais sous vos ordres. Prenez-en soin, capitaine : la poudre est une cargaison nerveuse.";
			pchar.CargoQuest.TraderID     = Characters[sti(npchar.storeMan3)].id;
    		pchar.CargoQuest.GiveTraderID = NPChar.id;
			pchar.CargoQuest.GovSubtype = 0;
			if (sti(pchar.CargoQuest.iOrderType) == 6) pchar.CargoQuest.GovSubtype = sti(npchar.GovSubtype3); // подтип выпал при генерации (в списке уже подписан)
			if (sti(pchar.CargoQuest.GovSubtype) == 2 && GovEscort_CanTake()) dialog.text = "Excellent ! Le convoi de cargaison importante est déjà dans le port, ses capitaines se présenteront à vous en rade : les navires sont sous vos ordres. Menez-les à bon port, et vous serez payé.";
			AddDialogExitQuest("trade_quest_open");
			Nextdiag.CurrentNode = Nextdiag.TempNode;
		break;

		case "smuggle_need_small_fleet":
			dialog.text = "Chut, pas si fort... Une cargaison pareille voyage en silence. Avec une escadre de plus de trois voiles, ou un navire puissant au-dessus de la troisième classe, n'importe quelle patrouille vous repérera, et les bonnes personnes ne descendront même pas à terre. Prenez-vous quelque chose de plus modeste, et nous reparlerons de cette commande.";
			link.l1 = "Compris. Je reviendrai avec quelque chose de moins voyant.";
			link.l1.go = "exit";
		break;

		case "fortammo_need_slots":
			dialog.text = "C'est une commande de convoi, capitaine : quatre navires de l'וtat chargés de poudre navigueront sous votre flamme, chacun avec son propre équipage. Il me faut quatre places libres dans votre escadre. Faites de la place, et revenez : le travail en vaut la peine.";
			link.l1 = "Très bien, je vais réorganiser mon escadre et je reviens.";
			link.l1.go = "exit";
		break;

		// --- loophole: bribe the guild clerk (the cargo manifest "goes missing", no debt; 12-55% the clerk cheats - debt comes later) ---
		case "FreightClerk_Offer":
			int fcCost = Freight_BribePrepare();
			if (sti(pchar.money) < fcCost)
			{
				dialog.text = "Hé... une offre audacieuse. Seulement, le bon papier ne coמte pas rien : " + FindRussianMoneyString(fcCost) + ". Vous n'avez pas autant sur vous. Revenez avec l'argent.";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Le marchand jette un regard autour de lui et baisse la voix. Pour " + FindRussianMoneyString(fcCost) + " – le bon connaissement disparaîtra dans l'âtre, comme s'il n'avait jamais existé. La guilde aime l'ordre dans ses papiers... et les papiers se perdent parfois. Marché conclu ?";
			link.l1 = "Marché conclu. Voici l'argent.";
			link.l1.go = "FreightClerk_Done";
			link.l2 = "J'ai changé d'avis.";
			link.l2.go = "exit";
		break;

		case "FreightClerk_Done":
			// outcome (honest erase / cheat) is outwardly identical - betrayal only surfaces as a debt later
			Freight_BribeClerk();
			dialog.text = "Le marchand empoche les pièces et hoche légèrement la tête. Pour autant qu'on sache, ce connaissement n'a jamais existé. Maintenant, filez, et vite.";
			link.l1 = "Bien obligé.";
			link.l1.go = "exit";
		break;

		case "GuildDebt_Settle":
			int gdGoods = sti(pchar.GuildDebt.GoodsType);
			int gdQty   = sti(pchar.GuildDebt.GoodsQty);
			int gdSum   = sti(pchar.GuildDebt.sum);
			int gdComp  = sti(pchar.GuildDebt.GoodsComp);
			// last call: the cargo was sold to the fence, nothing to return in goods - money only
			if (CheckAttribute(pchar, "GuildDebt.NoGoods"))
			{
				dialog.text = "(Le marchand consulte le registre de la guilde et plisse les yeux.) Ah, c'est vous... Cette cargaison détournée a refait surface ailleurs, et la guilde n'est pas aveugle. Comme il ne reste plus de marchandises à rendre, l'affaire est vite réglée : le dédit en espèces, " + FindRussianMoneyString(gdSum) + ", et pas une piastre de moins. Sinon, les hommes des Guthrie viendront le récupérer eux-mêmes.";
				if (sti(pchar.money) >= gdSum)
				{
					link.l1 = "Voici la somme entière. Réglons cette affaire.";
					link.l1.go = "GuildDebt_PayMoney";
				}
				link.l3 = "Je dois réunir l'argent. Je reviendrai.";
				link.l3.go = "exit";
				break;
			}
			dialog.text = "(Le marchand consulte lentement le registre de la guilde.) Eh bien, eh bien... On vous reproche une cargaison détournée : " + GetGoodsNameAlt(gdGoods) + ", " + FindRussianQtyString(gdQty) + ". Le dédit s'élève à " + FindRussianMoneyString(gdSum) + ". La guilde acceptera soit l'argent, soit les marchandises elles-mêmes, avec un supplément d'un quart de leur valeur (" + FindRussianMoneyString(gdComp) + ").";
			if (sti(pchar.money) >= gdSum)
			{
				link.l1 = "Voici la somme entière. Oublions cette affaire.";
				link.l1.go = "GuildDebt_PayMoney";
			}
			bool bGdGoods = false;
			if (GetSquadronGoods(pchar, gdGoods) >= gdQty && sti(pchar.money) >= gdComp) bGdGoods = true;
			if (bGdGoods)
			{
				link.l2 = "Les marchandises sont dans ma cale, prenez-les. Voici le supplément.";
				link.l2.go = "GuildDebt_PayGoods";
			}
			link.l3 = "Je dois réunir l'argent. Je reviendrai.";
			link.l3.go = "exit";
		break;

		case "GuildDebt_PayMoney":
			AddQuestRecord("GuildDebt", "3");
			AddQuestUserData("GuildDebt", "sMoney", FindRussianMoneyString(sti(pchar.GuildDebt.sum)));
			AddMoneyToCharacter(pchar, -sti(pchar.GuildDebt.sum));
			dialog.text = "(Le marchand compte les piastres et vous raye du registre de la guilde.) Paiement accepté. La guilde va retirer la prime sur votre tête, et les listes noires seront brמlées. Ne jouez plus avec les cargaisons de la guilde, " + GetAddress_Form(NPChar) + ".";
			link.l1 = "Leçon retenue.";
			link.l1.go = "exit";
			GuildDebt_Close();
		break;

		case "GuildDebt_PayGoods":
			AddQuestRecord("GuildDebt", "4");
			AddQuestUserData("GuildDebt", "sSex", GetSexPhrase("", "e"));
			RemoveCharacterGoods(pchar, sti(pchar.GuildDebt.GoodsType), sti(pchar.GuildDebt.GoodsQty));
			AddMoneyToCharacter(pchar, -sti(pchar.GuildDebt.GoodsComp));
			dialog.text = "(Le marchand ordonne le déchargement et vous raye du registre de la guilde.) Les marchandises et le supplément sont acceptés. La guilde va retirer la prime sur votre tête, et les listes noires seront brמlées. Ne jouez plus avec les cargaisons de la guilde, " + GetAddress_Form(NPChar) + ".";
			link.l1 = "Leçon retenue.";
			link.l1.go = "exit";
			GuildDebt_Close();
		break;

		case "smuggle_wrong_trader":
			dialog.text = "Silence, vous ! Je suis un honnête marchand, je ne touche pas à ce genre de cargaison. Allez trouver les bonnes personnes : dans cette ville, il y a quelqu'un à qui parler de ce genre d'affaires. Et plus un mot là-dessus devant moi.";
			link.l1 = "Compris. Toutes mes excuses.";
			link.l1.go = "exit";
		break;

		case "governor_wrong_trader":
			dialog.text = "Les cargaisons d'וtat, ce n'est pas mon affaire, capitaine. Portez-la directement à la résidence, chez le gouverneur. C'est lui qui décidera oם la mettre.";
			link.l1 = "Compris. Je me rends à la résidence.";
			link.l1.go = "exit";
		break;

		case "fortammo_wrong_trader":
			dialog.text = "Des munitions ? Ce n'est pas pour une boutique, capitaine. Portez-les au commandant du fort : il gère l'arsenal de la garnison et réglera ses comptes avec vous.";
			link.l1 = "Compris. Je me rends chez le commandant.";
			link.l1.go = "exit";
		break;

		case "generate_quest_2":
			if (pchar.quest.generate_trade_quest_progress == "failed")
			{
				dialog.text = RandSwear() + "Vous vous êtes souvenu un peu tard de la mission qui vous avait été confiée, vous ne trouvez pas ? J'ai dמ recommander les marchandises. Au revoir.";
				link.l1 = "Pardonnez-moi, j'étais tellement pressé. Si je couvre vos pertes, cela rétablira peut-être ma réputation en affaires ?";
				link.l1.go = "generate_quest_failed";
				link.l9 = "Bonne journée.";
				link.l9.go = "exit";
				ChangeCharacterReputation(pchar, -1);
			}
			else
			{
                iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
                iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);

                dialog.text = "Exactement ! Je l'attendais depuis longtemps. Vous devez me livrer une cargaison : " +
                GetGoodsNameAlt(iTradeGoods) + " – en quantité de " + FindRussianQtyString(iQuantityGoods) + " – pour " +
                FindRussianMoneyString(sti(pchar.CargoQuest.iMoney)) + ".";
				link.l1 = "C'est exact.";
				link.l1.go = "generate_quest_ready";
			}
		break;

		case "generate_quest_ready":
            iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
            iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);

            // блок кидалова нас на бабки -->
            // === consignee store is BLOCKED (you scammed contraband there): the trader withholds the forfeit from your premium, paying off the debt via deliveries ===
            // (stores already paid off at the contact - NoUnblockWait - are skipped: debt settled, only the timed unblock remains)
            if (CheckAttribute(pchar, "NoContraCity." + npchar.city) && !CheckAttribute(pchar, "NoUnblockWait." + npchar.city))
            {
                string sCty = npchar.city; // accessor .(...) won't take npchar.city directly (it's an attribute, not a variable) - extract it
                if (GetSquadronGoods(pchar, iTradeGoods) < iQuantityGoods)
                {
                    int iMiss = iQuantityGoods - GetSquadronGoods(pchar, iTradeGoods);
                    dialog.text = "Vous n'avez pas apporté toutes les marchandises !! Il vous manque encore " + FindRussianQtyString(iMiss) + " à livrer.";
                    link.l9 = "Je vais compléter ce qui manque et je reviendrai.";
                    link.l9.go = "exit";
                    break;
                }
                int iPrem = makeint(pchar.CargoQuest.iMoney);
                if (GetQuestPastDayParam("CargoQuest") >= sti(pchar.CargoQuest.iDaysExpired)) iPrem = makeint(iPrem / 2);            // late - half pay
                else if (GetQuestPastDayParam("CargoQuest") * 2 < sti(pchar.CargoQuest.iDaysExpired)) iPrem = makeint(iPrem * 1.2); // early
                int iDebt = sti(pchar.NoContraCity.(sCty));
                int iTake = iPrem;
                if (iTake > iDebt) iTake = iDebt;   // no more than the remaining forfeit
                int iLeft = iDebt - iTake;
                AddMoneyToCharacter(pchar, iPrem - iTake);                                  // premium minus the withheld forfeit - into the player's purse
                RemoveCharacterGoods(pchar, iTradeGoods, iQuantityGoods);
                ref bstore = GetColonyByIndex(FindColony(npchar.city));
                AddStoreGoods(&stores[sti(bstore.StoreNum)], iTradeGoods, iQuantityGoods);
                pchar.quest.generate_trade_quest_progress = "";
                pchar.quest.generate_trade_quest.over = "yes";
                CloseQuestHeader("DELIVERY_TRADE_QUEST");
                AddCharacterExpToSkill(pchar, "Sailing", sti(pchar.rank) * 5);
                AddCharacterExpToSkill(pchar, "Leadership", sti(pchar.rank) * 3);
                AddCharacterExpToSkill(pchar, "COMMERCE", sti(pchar.rank) * 4);
                OfficersReaction("good");
                AchievementsCounter_genquests(1);
                if (iLeft <= 0)
                {
                    DeleteAttribute(pchar, "NoContraCity." + npchar.city);                  // forfeit paid in full - the store block is lifted
                    dialog.text = "(Le marchand compte les pièces et s'adoucit pour la première fois.) J'ai prélevé sur votre prime les derniers " + FindRussianMoneyString(iTake) + " du dédit, et la dette est réglée. Oublions le passé, " + GetAddress_Form(NPChar) + ": je suis prêt à travailler de nouveau avec vous.";
                }
                else
                {
                    pchar.NoContraCity.(sCty) = iLeft;                               // forfeit remainder - the block stands
                    dialog.text = "(Le marchand consulte son registre.) Je prends les marchandises, mais vous me devez encore quelque chose : cette affaire inachevée. Je retiens sur votre prime " + FindRussianMoneyString(iTake) + " du dédit. " + FindRussianMoneyString(iLeft) + " restent dus : réglez-les, et nous referons affaire.";
                }
                link.l1 = "C'est juste.";
                link.l1.go = "exit";
                break;
            }

            if (rand(8) == 1 && sti(Goods[iTradeGoods].Cost) <= 44 && GetQuestPastDayParam("CargoQuest") > 5)
            {
                dialog.text = RandSwear() + "Je dois vous présenter mes excuses, "+GetAddress_Form(NPChar)+
                              " : c'est que " + RandPhraseSimple("je suis dans une situation difficile et je ne pourrai pas payer vos services", "j'ai déjà obtenu cette cargaison ailleurs, à meilleur prix")+
                              ". En paiement de votre fret, je vous cède toute la cargaison que vous avez livrée.";
				link.l1 = RandSwear() + RandPhraseSimple("Et moi qui ai protégé cette satanée cargaison de tous les malheurs !!! J'ai tué deux cents rats à cause d'elle !",
                                                         "Vous me mettez dans une situation sans issue, je vais devoir accepter.");
				link.l1.go = "exit";
				ChangeCharacterReputation(pchar, 2);
				AddCharacterExpToSkill(pchar, "Sailing", 60);
				AddCharacterExpToSkill(pchar, "Leadership", 20);
				AddCharacterExpToSkill(pchar, "COMMERCE", 15);

				pchar.quest.generate_trade_quest_progress = "";
				pchar.quest.generate_trade_quest.over = "yes";

                AddQuestRecord("DELIVERY_TRADE_QUEST", "4");
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(iTradeGoods));
			    AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony",XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony+"Dat"));
                CloseQuestHeader("DELIVERY_TRADE_QUEST");

				AchievementsCounter_genquests(1);

                break;
            }
            // блок кидалова нас на бабки <--
			if (GetSquadronGoods(pchar, iTradeGoods) < iQuantityGoods)
			{
                iTmp = iQuantityGoods - GetSquadronGoods(pchar, iTradeGoods);
                dialog.text = "Vous n'avez pas apporté toutes les marchandises !! D'après les termes de l'accord, il manque encore "
                              + FindRussianQtyString(iTmp) + " de marchandises.";
				link.l9 = RandPhraseSimple("Oui, en effet. Il va falloir compléter ce qui manque. Je reviendrai.",
                                           RandSwear() +"Ces diables de rats ont abîmé cette satanée cargaison. Je vais compléter ce qui manque et je reviendrai.");
				link.l9.go = "exit";
                AddQuestRecord("DELIVERY_TRADE_QUEST", "8");
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sHaveNotQty", iTmp);
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(iTradeGoods));
			}
			else
			{
				if (GetQuestPastDayParam("CargoQuest") >= sti(pchar.CargoQuest.iDaysExpired))
				{
					dialog.text = "Vous avez 1 jour de retard. Je ne vous paierai donc que la moitié du prix.";
					link.l1 = "Eh, ça peut arriver à tout le monde, allons-y";
					link.l1.go = "exit";
					ChangeCharacterReputation(pchar, 3);
					AddCharacterExpToSkill(pchar, "Sailing", sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_I) );
					AddCharacterExpToSkill(pchar, "Leadership", sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_C));
					AddCharacterExpToSkill(pchar, "COMMERCE", sti(pchar.rank) * (GetCharacterSPECIALSimple(pchar, SPECIAL_C) + GetCharacterSPECIALSimple(pchar, SPECIAL_I)));

					AddMoneyToCharacter(pchar, makeint(sti(pchar.CargoQuest.iMoney)/2));
					Freight_AddLoyalty(); // LEO: +1% к будущей премии этого работодателя (груз доставлен, пусть и с опозданием)
					pchar.quest.generate_trade_quest_progress = "";
					pchar.quest.generate_trade_quest.over = "yes";
					RemoveCharacterGoods(pchar, makeint(pchar.CargoQuest.iTradeGoods), makeint(pchar.CargoQuest.iQuantityGoods));
					ref cstore = GetColonyByIndex(FindColony(npchar.city));
					AddStoreGoods(&stores[sti(cstore.StoreNum)],makeint(pchar.CargoQuest.iTradeGoods),makeint(pchar.CargoQuest.iQuantityGoods));

					OfficersReaction("good");

					AddQuestRecord("DELIVERY_TRADE_QUEST", "Late1Day");
					CloseQuestHeader("DELIVERY_TRADE_QUEST");

					AchievementsCounter_genquests(1);
				}
				else
				{
					dialog.text = "Parfait ! Voici votre récompense, capitaine " + GetFullName(pchar)+".";
					link.l1 = "Un plaisir de travailler avec vous.";
					link.l1.go = "exit";
					ChangeCharacterReputation(pchar, 3);

					AddCharacterExpToSkill(pchar, "Sailing", (GetQuestPastDayParam("CargoQuest") + 1) * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_I) );
					AddCharacterExpToSkill(pchar, "Leadership", (GetQuestPastDayParam("CargoQuest") + 1) * sti(pchar.rank) * GetCharacterSPECIALSimple(pchar, SPECIAL_C));
					AddCharacterExpToSkill(pchar, "COMMERCE", (GetQuestPastDayParam("CargoQuest") + 1) * sti(pchar.rank) * (GetCharacterSPECIALSimple(pchar, SPECIAL_C) + GetCharacterSPECIALSimple(pchar, SPECIAL_I)));

					int iReward = makeint(pchar.CargoQuest.iMoney);
					if (GetQuestPastDayParam("CargoQuest") * 2 < sti(pchar.CargoQuest.iDaysExpired)) iReward = makeint(iReward * 1.2);
					AddMoneyToCharacter(pchar, iReward);
					Freight_AddLoyalty(); // LEO: +1% к будущей премии этого работодателя за выполненный фрахт
					ChangeCharacterNationReputation(pchar, sti(npchar.nation), 1);
					pchar.quest.generate_trade_quest_progress = "";
					pchar.quest.generate_trade_quest.over = "yes";
					RemoveCharacterGoods(pchar, makeint(pchar.CargoQuest.iTradeGoods), makeint(pchar.CargoQuest.iQuantityGoods));
					ref custore = GetColonyByIndex(FindColony(npchar.city));
					AddStoreGoods(&stores[sti(custore.StoreNum)],makeint(pchar.CargoQuest.iTradeGoods),makeint(pchar.CargoQuest.iQuantityGoods));

					OfficersReaction("good");
					AddQuestRecord("DELIVERY_TRADE_QUEST", "2");
					AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(iTradeGoods));
					AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony",XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony+"Gen"));
					CloseQuestHeader("DELIVERY_TRADE_QUEST");

					AchievementsCounter_genquests(1);
				}
			}
		break;

		case "generate_quest_failed":
            iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
            iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);
            iMoney =  3*makeint(iQuantityGoods * sti(Goods[iTradeGoods].Cost) / sti(Goods[iTradeGoods].Units));
			dialog.text = "Bien... La somme de " + FindRussianMoneyString(iMoney) + " couvrira tout juste mes pertes dues à votre retard de livraison.";
			link.l1 = "Eh bien ! Pas question ! Je crois que je ne transporterai plus vos satanées cargaisons ! On en trouve bien assez en mer !";
			link.l1.go = "exit";
            if (sti(pchar.Money) >= iMoney)
            {
    			link.l2 = "Voici la somme demandée";
    			link.l2.go = "generate_quest_failed_2";
			}
            else
            {
                AddQuestRecord("DELIVERY_TRADE_QUEST", "7");
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sMoney", FindRussianMoneyString(iMoney));
    		    AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony",XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony+"Gen"));
            }
		break;

		case "generate_quest_failed_2":
            iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
            iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);
            iMoney =  3*makeint(iQuantityGoods * sti(Goods[iTradeGoods].Cost) / sti(Goods[iTradeGoods].Units));
			dialog.text = "Parfait. Je peux maintenant dire à mes collègues qu'on peut encore traiter avec vous.";
			link.l1 = "Merci ! Je ne vous décevrai pas la prochaine fois.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 10);
			AddCharacterExpToSkill(pchar, "Sailing", -100);
			AddCharacterExpToSkill(pchar, "Leadership", -50);
			AddCharacterExpToSkill(pchar, "COMMERCE", -100);

			AddMoneyToCharacter(pchar, -iMoney);
			pchar.quest.generate_trade_quest_progress = "";
			pchar.quest.generate_trade_quest.over = "yes";

            AddQuestRecord("DELIVERY_TRADE_QUEST", "5");
            AddQuestUserData("DELIVERY_TRADE_QUEST", "sMoney", FindRussianMoneyString(iMoney));
            AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(iTradeGoods));
		    AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony",XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony+"Gen"));
            CloseQuestHeader("DELIVERY_TRADE_QUEST");

			AchievementsCounter_genquests(1);
		break;

		case "generate_quest_not_closed":
            iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
            iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);

            dialog.text = "Hum. J'ai entendu dire que vous n'aviez pas encore rempli vos obligations pour le fret précédent, et vous demandez déjà un nouveau. Vous deviez livrer une cargaison : " +
            LanguageConvertString(iSeaGoods, "seg_" + Goods[iTradeGoods].Name)+ " à destination de " + XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony) + ".";
			link.l1 = "Oui, exactement ! Vous avez raison !";
			link.l1.go = "exit";
		break;

		case "generate_quest_cannot_done":
            dialog.text = RandSwear() + GetAddress_Form(NPChar) +" vous me laissez tomber !!! Vous pourriez peut-être essayer de régler ce problème ?";
			link.l1 = "D'accord. Je vais essayer de livrer la cargaison.";
			link.l1.go = "exit";
			link.l2 = "Non. Je ne peux pas. Désolé.";
			link.l2.go = "generate_quest_cannot_done_2";

		break;

		case "generate_quest_cannot_done_2":
		    iTradeGoods    =  makeint(pchar.CargoQuest.iTradeGoods);
            iQuantityGoods =  makeint(pchar.CargoQuest.iQuantityGoods);
            if (GetSquadronGoods(pchar, iTradeGoods) < iQuantityGoods)
			{
				dialog.text = "Un instant ! Mais il n'y a pas une telle quantité de marchandises à bord !! Il vous manque encore "
                              + FindRussianQtyString(iQuantityGoods - GetSquadronGoods(pchar, iTradeGoods)) + " de marchandises.";
				link.l9 = RandPhraseSimple("Oui, en effet. Il va falloir compléter ce qui manque.",
                                           RandSwear() +"Les rats du bord ont abîmé la cargaison. Je vais racheter ce qui manque et je reviendrai.");
				link.l9.go = "exit";
			}
			else
			{
                dialog.text = "Bien, je comprends... Je reprends les marchandises.";
    			link.l1 = "Merci. Je ne vous décevrai pas la prochaine fois !";
    			link.l1.go = "exit";
    			ChangeCharacterReputation(pchar, -3);

				pchar.quest.generate_trade_quest_progress = "";
				pchar.quest.generate_trade_quest.over = "yes";
				RemoveCharacterGoods(pchar, makeint(pchar.CargoQuest.iTradeGoods), makeint(pchar.CargoQuest.iQuantityGoods));

                AddQuestRecord("DELIVERY_TRADE_QUEST", "6");
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodQty", FindRussianQtyString(sti(pchar.CargoQuest.iQuantityGoods)));
                AddQuestUserData("DELIVERY_TRADE_QUEST", "sGoodGen", GetGoodsNameAlt(iTradeGoods));
    		    AddQuestUserData("DELIVERY_TRADE_QUEST", "sTargetColony",XI_ConvertString("Colony"+pchar.CargoQuest.iTradeColony+"Dat"));
                CloseQuestHeader("DELIVERY_TRADE_QUEST");
            }
		break;

		case "no_quests":
			dialog.text = "Je n'ai pas besoin de vos services pour le moment.";
			link.l1 = "Désolé. Alors parlons d'autre chose.";
			link.l1.go = "node_1";
		break;

        case "fight":
			DialogExit();
            NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "Exit":
			if (pchar.questTemp.Ascold == "canTakeQuest" && pchar.questTemp.Ascold.TraderId == npchar.id)//eddy. Аскольд, начало
			{
				dialog.Text = "Vous allez un peu partout. וcoutez, si vous trouvez quelque part de la poudre de momie égyptienne, ayez la bonté de me l'apporter. J'ai un client sérieux pour ça.";
				Link.l1 = "Bien.";
				Link.l1.go = "exit";
				SaveCurrentQuestDateParam("questTemp.Ascold");
				pchar.questTemp.Ascold = "Seek_powder";
				AddQuestRecord("Ascold", "1");
				AddQuestUserData("Ascold", "sName", GetFullName(npchar));
				AddQuestUserData("Ascold", "sCity", XI_ConvertString("Colony" + npchar.city + "Voc"));
			}
			else
			{
				Nextdiag.CurrentNode = Nextdiag.TempNode;
				DialogExit();
			}
		break;
		case "storage_rent":
			dialog.text = "Vous voulez donc louer l'un de nos entrepכts pour un loyer raisonnable ?";
			link.l1 = "Il est grand ? Et combien demandez-vous de loyer ?";
			link.l1.go = "storage_rent1";
		break;

		case "storage_rent1":
			NPChar.MoneyForStorage = GetStoragePriceExt(NPChar, pchar);
			if (NPChar.city == "Tortuga" || NPChar.city == "Villemstad" || NPChar.city == "PortRoyal" || NPChar.city == "Havana")
			{
				dialog.text = "Il est assez spacieux, même pour un entrepכt portuaire : une capacité de 100 000 quintaux. Pour " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + " par mois, je suis prêt à assurer la sécurité de vos marchandises. "+
				"Cela comprend la surveillance, la protection contre les inondations et la lutte contre les rongeurs. דa vous va ? Je garantis la discrétion, bien sמr.";
			}
			else
			{
				dialog.text = "Il est assez spacieux, même pour un entrepכt portuaire : une capacité de 50 000 quintaux. Pour " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + " par mois, je suis prêt à assurer la sécurité de vos marchandises. "+
				"Cela comprend la surveillance, la protection contre les inondations et la lutte contre les rongeurs. דa vous va ? Je garantis la discrétion, bien sמr.";
			}

			link.l1 = "Bien. Puis-je le visiter ?";
			link.l1.go = "storage_rent2";
			link.l2 = "C'est trop cher. Il doit y avoir de l'eau jusqu'aux genoux et des rats partout.";
			link.l2.go = "storage_rent3";
		break;

		case "storage_rent2":
			dialog.text = "Bien sמr, bien sמr. Seulement, euh... je vous demanderai de payer un mois d'avance.";
			if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
			{
				link.l1 = "Que vous êtes... intéressé. Prenez votre argent, je loue cette grange.";
				link.l1.go = "storage_11";
			}
			else
			{
				link.l1 = "Que vous êtes... intéressé. Je vais chercher l'argent.";
				link.l1.go = "exit";
			}
		break;

		case "storage_rent3":
			dialog.text = "Eh bien, comme vous voudrez. Si vous décidez de vous adresser à nous... Mais n'oubliez pas qu'un tel trésor ne restera pas vide longtemps. Ne tardez pas trop.";
			link.l1 = "Ne vous inquiétez pas. Si besoin, je vous le demanderai.";
			link.l1.go = "exit";
		break;
		
		case "GetTradeInfo":
			dialog.text = "Contre une petite récompense, c'est tout à fait possible. Je voudrais 15 000 piastres pour ces informations. Qu'en dites-vous ?";
			if (sti(pchar.money) >= 15000)
			{
				Link.l1 = "D'accord, voici votre argent.";
				link.l1.go = "GetTradeInfo2";
			}
			Link.l2 = "J'ai changé d'avis. Bonne journée.";
			link.l2.go = "exit";
		break;
		
		case "GetTradeInfo2":
			ref getcolony;
			int t;
			switch (sti(NPChar.nation))
			{
				case ENGLAND:
					for (t = 0; t< MAX_COLONIES; t++)
					{
						getcolony = &Colonies[t];
						if (getcolony.id != "Caiman" && getcolony.id != "Panama" && getcolony.nation != "none" && sti(getcolony.nation) != SPAIN && sti(getcolony.nation) != HOLLAND && sti(getcolony.nation) != PIRATE) SetPriceListByStoreMan(getcolony);
					}
				break;
				case FRANCE:
					for (t = 0; t< MAX_COLONIES; t++)
					{
						getcolony = &Colonies[t];
						if (getcolony.id != "Caiman" && getcolony.id != "Panama" && getcolony.nation != "none" && sti(getcolony.nation) != SPAIN && sti(getcolony.nation) != PIRATE) SetPriceListByStoreMan(getcolony);
					}
				break;
				case SPAIN:
					for (t = 0; t< MAX_COLONIES; t++)
					{
						getcolony = &Colonies[t];
						if (getcolony.id != "Caiman" && getcolony.id != "Panama" && getcolony.nation != "none" && sti(getcolony.nation) != ENGLAND && sti(getcolony.nation) != FRANCE && sti(getcolony.nation) != PIRATE) SetPriceListByStoreMan(getcolony);
					}
				break;
				case HOLLAND:
					for (t = 0; t< MAX_COLONIES; t++)
					{
						getcolony = &Colonies[t];
						if (getcolony.id != "Caiman" && getcolony.id != "Panama" && getcolony.nation != "none" && sti(getcolony.nation) != ENGLAND && sti(getcolony.nation) != PIRATE) SetPriceListByStoreMan(getcolony);
					}
				break;
				case PIRATE:
					for (t = 0; t< MAX_COLONIES; t++)
					{
						getcolony = &Colonies[t];
						if (getcolony.id != "Caiman" && getcolony.id != "Panama" && getcolony.nation != "none" && sti(getcolony.nation) != ENGLAND && sti(getcolony.nation) != FRANCE && sti(getcolony.nation) != SPAIN && sti(getcolony.nation) != HOLLAND) SetPriceListByStoreMan(getcolony);
					}
				break;
				
			}
			log_info("Vous avez reçu une liste des prix des colonies amies de l'archipel des Caraïbes.");
			PlayStereoSound("notebook");
			AddMoneyToCharacter(pchar,-15000);

			dialog.text = "...Voilà, toutes les informations dont vous avez besoin sont là. Je vous souhaite bonne chance !";
			Link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

	}
	LanguageCloseFile(iSeaGoods);
}

int findStoreMan(ref NPChar, int delta)
{
    ref ch;
	aref chNat;
	int n;
    int storeArray[30];
    int howStore = 0;
	bool ok;
		for (int i = 0; i < MAX_CHARACTERS; i++)
		{
			makeref(ch,Characters[i]);
			makearef(chNat,Characters[i].Nation);
			if (CheckAttribute(ch, "Dialog.Filename") && ch.Dialog.Filename == "Common_Store.c")
			{
				if (NPChar.id == ch.id) continue;
				if (NPChar.id == "Panama_trader" || ch.id == "Panama_trader") continue; //нельзя доплыть
				if (NPChar.id == "Caiman_trader" || ch.id == "Caiman_trader") continue;
				if (ch.location == "none") continue; // фикс для новых, невидимых до поры островов
				if (GetIslandByCityName(ch.city) == GetIslandByCityName(NPChar.city)) continue; // хрен вам, а не читы!
				ok = (GetNationRelation2MainCharacter(sti(chNat)) == RELATION_ENEMY) && (sti(chNat) != PIRATE);
				if (GetNationRelation(sti(chNat), sti(NPChar.Nation)) != RELATION_ENEMY && !ok)
				{
					storeArray[howStore] = i;
					howStore++;
				}
			}
		}
		if (howStore == 0)
		{
			return -1;
		}
		else
		{
			n = drand(howStore - 3) + delta;
			return storeArray[n];
		}
}

// ugeen -->
//--> расчёт аренды склада
int GetStoragePriceExt(ref NPChar, ref chref)
{
	/* float fLeadership = 1.5 - GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)/120.0; // учитываем авторитет
	float fCommerce = 1.5 - GetSummonSkillFromName(pchar, SKILL_COMMERCE)/120.0; // учитываем торговлю

	int price = makeint(2000 * MOD_SKILL_ENEMY_RATE*3 * fLeadership * fCommerce); */

	int price = makeint(2000 * MOD_SKILL_ENEMY_RATE*3);

	return price;
}
//<-- расчёт аренды склада
// --> перемещаем остатки груза со склада на корабль ГГ с перегрузом, пусть сам разбирается что делать со всем этим барахлом
void SetStorageGoodsToShip(ref pStorage)
{
	int iStoreQ;
	for (int i = 0; i< GOODS_QUANTITY; i++)
	{
		iStoreQ = GetStorageGoodsQuantity(pStorage, i);
		if (iStoreQ == 0) continue;
		SetCharacterGoods(pchar, i, GetCargoGoods(pchar, i) + iStoreQ);// перегруз
	}
}
