// Gregg: Andy Rejdol - alternative prologue "Desert Island" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\ddprologue.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Start_1":
			dialog.text = PChar.name + " ! Et en vie, en plus !";
			link.l1 = "Comme tu le vois. Et toi, tu es...";
			link.l1.go = "Start_2";
		break;

		case "Start_2":
			dialog.text = "...(l'interrompant)... Sacré démon ! Je le savais, je savais que tu ne crèverais pas, ni dans cet enfer sur le pont, ni en mer !";
			link.l1 = "Je sais que la question est étrange, mais qui es-tu ?";
			link.l1.go = "Start_3";
		break;

		case "Start_3":
			dialog.text = "Quoi ?! Tu ne me reconnais pas ?";
			link.l1 = "Non. Depuis que je me suis cogné la tête contre un canon, je ne me souviens de rien.";
			link.l1.go = "Start_4";
		break;

		case "Start_4":
			dialog.text = GetFullName(NPChar) + " ! Le fidèle maître d'équipage du capitaine " + GetMainCharacterNameGen() + ". Et la mémoire te reviendra, capitaine, j'en suis sמr. Bien des capitaines l'ont perdue un moment après un coup violent, puis se sont souvenus de tout.";
			link.l1 = "C'est rassurant. Tu es là depuis longtemps, " + NPChar.name + " ?";
			link.l1.go = "Start_5";
		break;

		case "Start_5":
			dialog.text = "Environ une heure. J'ai trouvé cette grotte par hasard en me cachant des coupe-jarrets de Sajfus. Si je ne l'avais pas trouvée, ils m'auraient trouvé, moi, et m'auraient fait la peau.";
			link.l1 = "Bon sang, alors Sajfus a déjà débarqué des hommes sur l'île ! Nous devons être extrêmement prud... ...(à voix basse)... Silence ! Tu entends ?";
			link.l1.go = "Start_6";
		break;

		case "Start_6":
			dialog.text = "Entendu quoi, " + PChar.name + " ?";
			link.l1 = "Quelqu'un descend ici. א couvert, vite. Si ce sont les hommes de Sajfus, il ne faut pas qu'ils nous repèrent, sinon nous sommes fichus.";
			link.l1.go = "Start_7";
		break;

		case "Start_7":
			dialog.text = "...(à voix basse)... Compris, cap'taine. James, cache-toi.";
			link.l1 = "Allez, plus vite.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameEnemyInGrot");
		break;

		case "Start_8":
			dialog.text = "Ouf, on s'en est tirés. Et maintenant, on fait quoi, cap'taine ? L'île est déserte et nous n'avons pas de navire.";
			link.l1 = "D'abord, nous nous reposons ici deux ou trois jours, et ensuite, nous verrons. Des navires font escale ici de temps en temps pour prendre des vivres et de l'eau douce. Nous essaierons de nous arranger avec leurs capitaines pour qu'ils nous emmènent au port le plus proche.";
			link.l1.go = "Start_9";
		break;

		case "Start_9":
			dialog.text = "Et tu as de quoi payer, cap'taine ? Nos poches sont vides.";
			link.l1 = "Hum. C'est vrai, nous n'avons pas de quoi payer. Tu as fouillé ce coffre, " + NPChar.name + " ?";
			link.l1.go = "Start_10";
		break;

		case "Start_10":
			dialog.text = "Et pourquoi le fouiller, qu'est-ce que je trouverais là-dedans ?";
			link.l1 = "Eh bien, je ne sais pas. Un capitaine a peut-être caché ici un peu d'or en prévision des jours difficiles. דa vaut la peine de vérifier.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameSearchedItems");
		break;

		case "Start_11":
			dialog.text = "Ha ! Cap'taine, tu avais raison ! Il y a bien quelque chose à prendre dans ce coffre.";
			link.l1 = "Maintenant, nous avons de quoi payer la traversée. Il ne reste plus qu'à attendre un navire. Chaque jour, nous descendrons à tour de rכle jusqu'au rivage pour surveiller l'horizon.";
			link.l1.go = "Start_12";
		break;

		case "Start_12":
			dialog.text = "Très bien, capitaine, c'est ce que nous ferons.";
			link.l1 = "Et maintenant, que tout le monde se repose. J'ai une chose à régler.";
			link.l1.go = "exit_special";
		break;

		// Gregg: same trick CSP uses in MainHero_dialog.c (Exit_Special) - open the character
		// build screen. The ChangePiratesExit flag is picked up in INTERFACE\character.c
		// when the screen closes, and the prologue continues.
		case "exit_special":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.SystemInfo.ChangePIRATES = true;
			PChar.StartDamnedDestiny.ChangePiratesExit = true;
			LaunchCharacter(PChar);
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
