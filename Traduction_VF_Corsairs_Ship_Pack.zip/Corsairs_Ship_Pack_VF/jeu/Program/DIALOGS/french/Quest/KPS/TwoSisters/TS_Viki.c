// Gregg: Viki Henderson and her sister Diana - "Two Sisters", the Martinique branch.
// Logic - Program\Quests\reaction_functions\twosisters.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Vous avez la bague ?";
			link.l1 = "Pas encore.";
			link.l1.go = "exit";
		break;

		// The brothel in Fort de France
		case "1":
			dialog.text = "Le capitaine cherche de quoi s'occuper ?";
			link.l1 = "Le capitaine cherche une femme prête à déménager.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(avec un rire bref)... א déménager. D'habitude, on demande autre chose. Et pour aller oם ?";
			link.l1 = "א San Juan, à Porto Rico. Une maison va ouvrir là-bas, et on a besoin de femmes.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "San Juan. ...(après un silence)... Et pourquoi moi ? Il y en a plein comme nous ici.";
			link.l1 = "On m'a dit que vous étiez la meilleure de la Martinique. On m'a menti ?";
			link.l1.go = "4";
			link.l2 = "Parce que vous êtes la première à m'avoir adressé la parole.";
			link.l2.go = "4";
		break;

		case "4":
			dialog.text = "On ne vous a pas menti. ...(sans sourire)... Très bien, je viendrai. Mais pas pour rien, et pas tout de suite.";
			link.l1 = "Combien ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Pas d'argent. Il y a une chose que je ne peux pas faire moi-même.";
			link.l1 = "Dites-la.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Tuer ma sœur. Diana Henderson, capitaine de la brigantine Amazone. Elle mouille à Puerto Príncipe, à Cuba.";
			link.l1 = "...(un silence)... Votre sœur ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Ma sœur. Par le sang, l'aînée, et la seule.";
			link.l1 = "Il y a une raison ?";
			link.l1.go = "8";
			link.l2 = "Ce que vous avez dit me suffit. Mais je veux savoir pourquoi.";
			link.l2.go = "8";
		break;

		case "8":
			dialog.text = "Oui. Quant à savoir si je vous la dirai, c'est une autre affaire.";
			link.l1 = "Vous me la direz, ou je n'y vais pas.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "...(après un silence)... Nous sommes venues ici ensemble, chez des parents. Les parents n'étaient plus là. Elle avait l'argent, elle a acheté le navire.";
			link.l1 = "Et vous ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Et moi, j'ai fini ici. Pendant deux ans, elle m'a donné de l'argent en me répétant chaque fois à quel point je lui faisais honte. Puis elle a cessé de m'en donner. La honte, elle, est restée.";
			link.l1 = "Et pour ça, vous voulez la faire tuer ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Tant qu'elle vivra, je n'irai nulle part. Elle me retrouverait aussi à San Juan, et elle écrirait à tous ceux qu'elle peut atteindre ce que je suis.";
			link.l1 = "C'est votre sœur.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Elle l'a été pendant vingt-cinq ans. ...(d'une voix égale)... Maintenant, c'est une femme qui a un navire, de l'argent et une bonne réputation.";
			link.l1 = "...(se taire)...";
			link.l1.go = "13";
		break;

		case "13":
			LAi_Fade("", "");
			dialog.text = "Je veux sa mort. C'est le seul prix, et il n'y en aura pas d'autre.";
			link.l1 = "Vous en êtes certaine ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Oui.";
			link.l1 = "Comment vous le prouver ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Elle porte la bague de famille à la main gauche. Retirez-la et apportez-la-moi.";
			link.l1 = "Très bien.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Alors à bientכt, capitaine. Je ne suis pas pressée.";
			link.l1 = "...(partir)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersVikiQuestStart");
		break;

		// Diana at Puerto Principe, after the fight with the hired man
		case "17":
			dialog.text = "...(rengainant sa lame)... Drכle d'endroit pour une promenade. Qui êtes-vous ?";
			link.l1 = "Je cherche Diana Henderson.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Vous l'avez trouvée. Continuez.";
			link.l1 = "C'est votre sœur qui m'envoie.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "...(sans surprise)... Encore de l'argent ?";
			link.l1 = "Non.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "Quoi, alors ? ...(elle regarde de plus près)... Mais je devine. C'est pour ça que vous êtes planté là avec une lame.";
			link.l1 = "Elle m'a demandé de vous tuer.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Ah, c'est ça. ...(d'un ton neutre)... Je m'attendais à un peu de méchanceté de sa part, mais pas à ça.";
			link.l1 = "Elle dit que vous ne lui avez pas laissé le choix.";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "J'ai payé pour elle pendant deux ans. Je lui ai proposé une place sur mon navire, plus d'une fois.";
			link.l1 = "Et elle ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Elle s'est habituée à vivre aux crochets des autres. Quand j'ai cessé de donner, il s'est avéré que tout était ma faute.";
			link.l1 = "Vous auriez pu lui parler.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Je l'ai fait. Chaque fois. ...(avec un regard en coin)... Vous avez essayé aussi, je vois.";
			link.l1 = "Je ne veux pas vous tuer.";
			link.l1.go = "25";
			link.l2 = "On m'a payé pour votre mort.";
			link.l2.go = "25";
		break;

		case "25":
			dialog.text = "Que vous le vouliez ou non n'a plus d'importance. Vous êtes venu ici pour ça, et je ne vais pas simplement vous laisser repartir.";
			link.l1 = "Alors finissons-en.";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Finissons-en.";
			link.l1 = "...(tirer la lame)...";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "...";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersVikiFirstFightWithDiana");
		break;

		// Diana is beaten down
		case "28":
			dialog.text = "...(haletante)... Eh bien ?";
			link.l1 = "Relevez-vous.";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Pourquoi ne m'avez-vous pas achevée ?";
			link.l1 = "Donnez-moi la bague, et je lui dirai que c'est fait.";
			link.l1.go = "30";
		break;

		case "30":
			dialog.text = "...(lentement)... Vous voulez dire que vous lui mentiriez. Elle serait tranquille, et moi, je resterais en vie.";
			link.l1 = "C'est comme ça que ça se passerait.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Remettre la bague de famille pour qu'elle finisse entre ses mains ? Non.";
			link.l1 = "C'est votre vie contre un bout d'or.";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Contre, alors. ...(elle lève sa lame)... Vous prendrez la bague sur un cadavre.";
			link.l1 = "...(lever votre arme)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersVikiNextFightWithDiana");
		break;

		// Viki takes the ring
		case "33":
			dialog.text = "Vous l'avez apportée ?";
			link.l1 = "...(remettre la bague)...";
			link.l1.go = "34";
		break;

		case "34":
			TakeNItems(PChar, "TwoSisters_Ring", -1);
			dialog.text = "...(elle regarde longuement la bague)... Alors c'est fait.";
			link.l1 = "Vous partez pour San Juan.";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Oui. ...(elle range la bague)... Et plus un mot à ce sujet, capitaine. Jamais.";
			link.l1 = "Alors, au navire.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersVikiQuestComplete");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
