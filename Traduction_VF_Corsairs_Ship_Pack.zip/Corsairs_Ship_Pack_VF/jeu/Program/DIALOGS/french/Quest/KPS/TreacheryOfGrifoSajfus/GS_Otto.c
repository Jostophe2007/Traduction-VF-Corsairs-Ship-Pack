// Gregg: Otto Groberg - quest "The Treachery of Grifo Sajfus" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\grifosajfus.c
// Nodes 1-2 - the stranger with the note in the pirate town, 3-15 - Otto himself in the
// tavern, 16-19 - the settling of accounts at Puerto Principe.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Capitaine " + GetFullName(PChar) + " ? On m'a dit de vous remettre ceci à votre arrivée.";
			link.l1 = "Qui vous l'a dit ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je ne sais pas. C'est peut-être écrit dans le billet.";
			link.l1 = "Très bien, donnez-moi le billet.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusTakeNotice");
		break;

		case "3":
			dialog.text = "Ah, capitaine " + PChar.name + ", je suis heureux que vous soyez enfin arrivé aux Bermudes. Je m'appelle Otto Groberg.";
			link.l1 = "Que voulez-vous, Otto ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Vous avez quelque chose qui aurait dמ être à moi.";
			link.l1 = "Et qu'est-ce que ce serait ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Les diamants, capitaine " + PChar.lastname + ", les diamants que vous avez trouvés aux îles Turques. Je suis prêt à vous les acheter.";
			link.l1 = "Le prix sera plusieurs fois celui des diamants ordinaires, et en outre...";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je connais le prix de ces diamants, capitaine " + PChar.lastname + ", et je suis prêt à vous donner en échange la marchandise la plus précieuse au monde.";
			link.l1 = "Et quelle est cette marchandise ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Vous ne devinez toujours pas, capitaine ?";
			link.l1 = "Parlez clairement, ne faites pas traîner.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "L'information, capitaine " + PChar.lastname + ". Je vous achèterai ces diamants contre des nouvelles fort intéressantes et extrêmement utiles pour vous.";
			link.l1 = "Vous me prenez pour un imbécile, Otto ? Vous croyez que je vais vous vendre des diamants contre des informations ?";
			link.l1.go = "9";
		break;

		// Gregg: without the alternative prologue the Piranha was never the player's -
		// they are after a legend, not their own ship
		case "9":
			if (CheckAttribute(PChar, "TreacheryOfGrifoSajfus.NoPiranha"))
			{
				dialog.text = "Contre des informations précieuses, capitaine. Des informations sur un navire de rêve, bien meilleur que ce fameux « Piranha » que vous cherchez.";
				link.l1 = "Meilleur que le « Piranha » ? On dit que rien de plus beau n'a jamais navigué dans les Caraïbes.";
			}
			else
			{
				dialog.text = "Contre des informations précieuses, capitaine. Des informations sur un navire de rêve, bien meilleur que le « Piranha » sur lequel vous naviguiez.";
				link.l1 = "Non, il n'y a jamais eu et il n'y aura jamais de navire meilleur que le « Piranha » !";
			}
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Vous vous trompez, capitaine. J'en connais un rayon sur le « Piranha ». Au chantier oם il a été construit, on a fabriqué deux autres navires. Les trois sont impossibles à distinguer en apparence. D'abord est venu le « Caméléon », avec des défauts évidents dans sa conception, puis le « Piranha », dont la construction a tenu compte de tous les défauts du « Caméléon »." + NewStr() + "Mais le sommet de l'art, c'est le navire qui a réuni toute l'expérience acquise en construisant le « Caméléon » et le « Piranha » : le « Marlin ». C'est ce navire que je vous propose de prendre. Avouez-le, capitaine, c'est une œuvre d'art. Vous devrez suer sang et eau pour l'avoir, bien sמr, mais il en vaut la peine.";
			link.l1 = "Eh bien, admettons que je vous vende les diamants, que vous me disiez oם trouver ce navire, que j'y aille et que je ne trouve rien.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "C'est une information vérifiée, capitaine. Mais si vous voulez des garanties, je suis prêt à vous en donner.";
			link.l1 = "Et quelles garanties ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Hum. Laissez-moi réfléchir. Je pourrais naviguer avec vous comme passager et vous le désigner quand nous le rattraperons. Je ne prendrai pas part au combat, mais je sais me défendre.";
			link.l1 = "Hum. Vous savez manier l'épée ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Pas plus mal que vos confrères corsaires. Ces garanties vous suffisent-elles ?";
			link.l1 = "Elles suffiront. Alors, oם vais-je trouver ce navire merveilleux ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Dans une semaine, le « Marlin » fera escale à Puerto Príncipe. Nous avons une dizaine de jours pour rejoindre Cuba, capitaine. Une fois qu'il sera pris, déposez-moi au port de Puerto Príncipe.";
			link.l1 = "Il n'y a pas de temps à perdre ! Il faut lever l'ancre immédiatement !";
			link.l1.go = "15";
		break;

		case "15":
			TakeNItems(PChar, "SajfusDiamondChest", -1);
			dialog.text = "Hé, et mes diamants ?";
			link.l1 = "Voici vos pierres, et maintenant, en avant.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusToPuertoPrincipe");
		break;

		case "16":
			if (PChar.TreacheryOfGrifoSajfus.MarlinSink == true)
			{
				dialog.text = "Mes condoléances, " + PChar.name + ", vous étiez près de la victoire, mais...";
				link.l1 = "Oui, je sais. C'est dommage, bien sמr, mais on n'y peut rien, la vie continue.";
				link.l1.go = "17";
			}
			else
			{
				dialog.text = "Félicitations, " + PChar.name + ". Vous êtes maintenant le capitaine de l'un des navires les plus rapides des Caraïbes.";
				link.l1 = "Vous aviez raison, ce navire est tout simplement magnifique ! La perfection même.";
				link.l1.go = "19";
			}
		break;

		case "17":
			dialog.text = "Combien d'autres navires rapides y a-t-il dans les Caraïbes ? Et vous en prendrez sמrement un !";
			link.l1 = "J'essaierai. Si une autre occasion se présente, je ne la laisserai pas passer.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Voilà qui est bien dit. Très bien, " + PChar.name + ", je n'ai pas le temps, je dois partir. Adieu.";
			link.l1 = "Portez-vous bien, Otto.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusOttoExit");
		break;

		case "19":
			dialog.text = "Encore une fois, félicitations ! Je boirais bien avec vous, mais je n'ai pas le temps, je dois partir. Adieu, " + PChar.name + ", et prenez soin du navire.";
			link.l1 = "Portez-vous bien, Otto.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TreacheryOfGrifoSajfusOttoExit");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
