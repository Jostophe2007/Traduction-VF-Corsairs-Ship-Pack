# -*- coding: utf-8 -*-
"""Encoding helpers for the French build.

The INTERFACE_NORMAL font of the game uses some Latin-1 letters as *icons*
(À É Ç ô ù û ...). In the French files these letters are therefore written with
substitute codepoints which fonts_fra.ini maps to the real accented glyphs in every font.
Translation memories keep normal Unicode; the conversion is applied when the French
game files are generated.

The substitutes must stay below the engine font table (USED_CODES, the original fonts
stop at U+2039): Private-Use codepoints (U+E0xx, used until 2026-11-19) are out of the
table -> "Codepoint < USED_CODES" asserts, wrong glyphs and random crashes (main menu
hints). Hebrew letters U+05D0-U+05DF are used instead: no font defines them, no game
text uses them, and they have no upper/lower case (lower/upper-casing leaves them alone).
"""

ICON_CONFLICTS = 'ÀÂÄÇÈÉÊËÎÏÖôöùûü'
PUA_MAP = {c: chr(0x05D0 + i) for i, c in enumerate(ICON_CONFLICTS)}
PUA_REV = {v: k for k, v in PUA_MAP.items()}
OLD_PUA_REV = {chr(0xE000 + ord(c)): c for c in ICON_CONFLICTS}   # codepoints of the first builds

_TABLE = {ord(k): v for k, v in PUA_MAP.items()}
# NB: '…' is NOT converted: the INTERFACE_NORMAL font uses it as an icon (sharp hit)
_TABLE[ord('’')] = "'"
_TABLE[ord('‘')] = "'"
_TABLE[ord(' ')] = ' '   # nbsp -> space (font has no nbsp glyph)
_TABLE[ord(' ')] = ' '


import re as _re
_ICON = _re.compile('⟦(.)⟧')


def to_game(s):
    """normal French text -> text written in the game files.
    ⟦X⟧ marks an icon character that must be kept as is (not converted)."""
    parts = _ICON.split(s)
    out = []
    for i, p in enumerate(parts):
        out.append(p if i % 2 else p.translate(_TABLE))
    return ''.join(out)


def from_game(s):
    return ''.join(PUA_REV.get(c, OLD_PUA_REV.get(c, c)) for c in s)
