#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Bonjour, "+ GetSexPhrase("señor", "señorita") +". C'est vous, la nouvelle tête qui a réussi à réchapper du dernier naufrage ?";
					link.l1 = "Oui, c'est moi. " + GetFullName(pchar) + " à votre service, señora...";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Bonjour, "+ GetSexPhrase("señor", "señorita") +". C'est donc vous, la nouvelle tête qui a survécu au dernier naufrage ?";
					link.l1 = "Oui, c'est moi. " + GetFullName(pchar) + " à votre service, señora...";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Vous avez besoin de quelque chose, "+ GetSexPhrase("señor", "señorita") +" ?";
				link.l1 = "Vous savez, je cherche quelqu'un. Vous l'avez vu ces derniers temps ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voulais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//покупка карты
				sld = characterFromId("LSC_Trader");
				if (CheckAttribute(sld, "quest.takeMap") && sld.quest.takeMap == "notTrade" && sld.quest.takeMap != "discount")
				{
					link.l4 = "Vous n'imaginez pas à quel point Eric Yost est cupide et égoïste !";
					link.l4.go = "takeMap";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Vous savez, je recrute un équipage pour partir d'ici. Je vous propose de m'accompagner jusqu'au continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "Vous êtes la seule personne à avoir survécu à cette tempête. Vous savez, vous avez beaucoup de chance, car votre navire s'est fracassé sur les récifs alors que la tempête avait déjà perdu de sa force. Au fait, je m'appelle " + GetFullName(npchar) + ".";
			link.l1 = "Eh bien, faisons connaissance, señora.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Enchantée ! Et moi, je m'appelle " + GetFullName(npchar) + ".";
			link.l1 = "Eh bien, faisons connaissance, señora.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez cacher votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, pourquoi courez-vous partout comme d'Artagnan, en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand"+ GetSexPhrase(" des hommes", " des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Si je l'ai vu, je vous le dirai sans faute. Alors, qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Pardonnez-moi, mais je ne comprends pas du tout de qui vous parlez. Pour vous aider, j'ai besoin d'un prénom et d'un nom.";
				Link.l1 = "Hum. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Hum, pardonnez-moi, mais c'est moi que vous cherchez. C'est moi.";
					link.l1 = "דa alors !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + ", vous parlez de lui ?";
					Link.l1 = "Exactement lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, je pense à quelqu'un d'autre.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "Vous parlez d'elle ?";
					Link.l1 = "C'est bien ça, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. Je peux peut-être essayer de vous redonner son nom ?";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je vous suis très reconnaissant, mais je ne veux me renseigner sur personne d'autre.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors vous devrez me redonner son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם il est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vu depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je n'ai aucune idée de l'endroit oם elle est.", "Je n'ai aucune idée de l'endroit oם il est en ce moment.", "Je ne l'ai pas vue depuis un bon moment. Alors je ne peux pas savoir.");
					link.l1 = RandPhraseSimple("Je vois.", "Je vois... Eh bien, merci.");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors il est sur ce navire en ce moment...", "Il est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, il est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vu...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc le voir là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez mieux, s'il vous plaît.", "Hum, alors elle est sur ce navire en ce moment...", "Elle est sur ce navire, c'est étrange que vous ne vous soyez pas encore rencontrés.");
						}
						else
						{
								dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Vous savez, je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Cherchez-la donc là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Pardonnez-moi, mais il est juste ici, " + npchar.quest.seekIdx.where + ". Il faut regarder attentivement.", "Hum, elle est ici, parmi nous !", "Si vous aviez regardé autour de vous plus attentivement, vous l'auriez sans doute déjà vue...");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Vous pouvez donc la voir là-bas.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci !", "Merci beaucoup.");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement.";
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Dites-moi, les tempêtes sont-elles fréquentes ici ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Pourriez-vous me dire, " + GetAddress_FormToNPC(NPChar) + ", ce qui mérite l'attention dans la Cité ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Quel genre d'homme est cet amiral ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l5 = "Dites-moi, êtes-vous arrivée ici avant Hill Brunner ?";
				link.l5.go = "ansewer_5";
			}
			link.l10 = "Je n'ai pas de questions à vous poser, pardonnez-moi.";
			link.l10.go = "exit";
		break;
		case "ansewer_4":
			dialog.text = "Non, non, c'est très rare. Vous savez, quand il y a une tempête chez nous, beaucoup d'hommes en font presque dans leur culotte, mais moi, ça m'est égal. Je n'ai pas peur des tempêtes !";
			link.l1 = "דa alors, quelle Espagnole courageuse vous êtes !";
			link.l1.go = "ansewer_4_1";
		break;
		case "ansewer_4_1":
			dialog.text = "Eh oui, je suis comme ça, "+ GetSexPhrase("señor", "señorita") +" !";
			link.l1 = "Eh bien, je vous souhaite de le rester, señora.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_1":
			dialog.text = "Cette île s'appelle la Cité des navires abandonnés. Nous sommes tous coupés du monde extérieur et nous vivons sans espoir de nous évader de cette cage...";
			link.l1 = "C'est vraiment si triste ? Je suis la seule personne à en avoir réchappé, j'ai eu de la chance. Apparemment, vous aussi, vous faites partie des chanceux.";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "De ce point de vue, bien sמr, oui. Mais si vous saviez comme on finit par se lasser de tout ça ! Rien de nouveau, rien que des épaves et la mort tout autour de nous. Nous vivons dans un cercle de malheurs, que c'est douloureux !..";
			link.l1 = "Eh oui...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Je pense que vous devriez d'abord visiter la taverne. Il y a une église et une boutique... Au fait, si vous n'êtes pas encore allé voir l'amiral, c'est là que vous devez aller en premier !";
			link.l1 = "D'accord, c'est ce que je vais faire. Merci.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "Chad Capper est un homme sérieux. On dit que dans une vie antérieure, il était capitaine pirate ! Il y a trois ans, il est arrivé ici et a aussitכt pris le pouvoir. Depuis, il est l'amiral permanent de la Cité.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_5":
			dialog.text = "Avant Hill Brunner ? Je suis si vieille que ça ?";
			link.l1 = "Non, pas du tout ! Pardonnez-moi...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l5 = true;
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Cependant, vous m'avez impressionnée...";
			link.l1 = "Comment ça, señora ?";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Vous avez enfreint la Loi, et vous faites comme si de rien n'était.";
			link.l1 = "Je sauve ma vie, je n'ai pas le choix. Si vous vous joignez à moi, vous serez sauvée, vous aussi.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Sauvée de quoi ?";
			link.l1 = "De la tempête qui approche et qui va détruire la Cité. Et ce ne sont pas des craintes en l'air, croyez-moi.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Et vous savez, je vous crois. D'ailleurs, j'en ai assez à en mourir de tout ce qu'il y a ici. Alors, je suis avec vous, capitaine.";
			link.l1 = "Excellent. Allez au San Gabriel au plus vite. Henrik Wedeker vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_4";
		break;
		case "SeekCrew_4":
			dialog.text = "Je vous ai compris. Je ferai tout comme vous l'avez dit.";
			link.l1 = "Je vous en prie, dépêchez-vous...";
			link.l1.go = "SeekCrew_all";
		break;
		//квест получения карты
		case "TakeMap":
			dialog.text = "Qu'est-ce qui vous arrive ?";
			link.l1 = "Vous savez, il veut littéralement me dépouiller !";
			link.l1.go = "TakeMap_1";
		break;
		case "TakeMap_1":
			dialog.text = "Ce n'est pas possible.";
			link.l1 = "Enfin, sans me mettre un couteau sous la gorge, bien sמr. Votre Eric Yost veut me vendre une carte de la Cité à un prix incroyable !";
			link.l1.go = "TakeMap_2";
		break;
		case "TakeMap_2":
			dialog.text = "Eh bien, ce n'est pas grave. Si vous avez quelque chose à vendre, vous avez le droit de fixer le prix que vous voulez. Et Eric est dans son droit, lui aussi.";
			link.l1 = "Eh bien, c'est un drכle de droit...";
			link.l1.go = "TakeMap_3";
		break;
		case "TakeMap_3":
			dialog.text = "Alors, vous avez vraiment besoin de cette carte ? Vous ne vous en sortez pas du tout sans elle ?";
			link.l1 = "Oui, c'est un peu difficile...";
			link.l1.go = "TakeMap_4";
		break;
		case "TakeMap_4":
			dialog.text = "Eh bien, je vais vous aider. Après tout, le Seigneur nous demande d'être miséricordieux envers notre prochain. Allez voir Eric demain, je lui dirai de baisser le prix de cette carte à un niveau raisonnable.";
			link.l1 = "Et il vous écoutera ?";
			link.l1.go = "TakeMap_5";
		break;
		case "TakeMap_5":
			dialog.text = "Sans aucun doute.";
			link.l1 = "Merci beaucoup !";
			link.l1.go = "exit";
			sld = characterFromId("LSC_Trader");
			sld.quest.takeMap = "discount";
			sld.quest.takeMap.name = GetFullName(npchar);
		break;
	}
	NextDiag.PrevNode = NodeName;
}
