
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int iTemp;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Rien à dire.";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_orient":
			for (i=1; i<=12; i++)
			{
				sld = characterFromId("CaracasCit_"+i);
                LAi_ActorStay(sld);
			}
			LAi_ActorTurnByLocator(npchar, npchar.location.group, npchar.location.locator);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
            LAi_group_Attack(NPChar, Pchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//замечение по обнажённому оружию
		case "CitizenNotBlade":
			dialog.text = "א Des Moines, on ne se promène pas avec une arme dégainée.";
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "DesMoinesCitizen";
		break;

		//бунтующие горожане в Каракасе
		case "CaracasMan":
			dialog.text = "Hé, "+ GetSexPhrase("matelot","ma belle") +" ! Tu veux participer, toi aussi ? Bienvenue !";
			link.l1 = "Je participerai peut-être, si tu me dis de quoi il s'agit.";
			link.l1.go = "CaracasMan_1";
		break;
		case "CaracasMan_1":
			dialog.text = "Ben, il y a un loup-garou, là, dans la taverne. On veut le faire chauffer – hic ! – sur un bמcher, haha !";
			link.l1 = "Tu es soמl, l'ami ! Va cuver ton vin !";
			link.l1.go = "CaracasMan_2";
		break;
		case "CaracasMan_2":
			dialog.text = "Que je crève si je mens ! Et j'ai bu, c'est pour le courage, et à mes frais ! On ne croise pas un loup-garou tous les jours, hein ?";
			link.l1 = "Un loup-garou, tu dis ? Bon, alors, qu'est-ce que tu attends ? Brמle-le !";
			link.l1.go = "CaracasMan_3";
		break;
		case "CaracasMan_3":
			dialog.text = "C'est que le tavernier, ce gredin, s'est enfermé ! Les gars sont allés chercher une poutre – hic ! – on va enfoncer la porte !";
			link.l1 = "Eh, avec vos yeux d'ivrognes, vous allez faire sauter la moitié de la ville ! Allez, laissez-moi passer, je vais découvrir qui est le loup-garou. Et si quelqu'un me suit, je lui coupe les oreilles !";
			link.l1.go = "exit_orient";
			DeleteAttribute(&locations[reload_location_index], "reload.l41.disable");
		break;
		//оборотень в Каракасе
		case "CaracasWervolf":
			dialog.text = "Qui êtes-vous et que vous faut-il ?";
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ". Mais qui êtes-vous ? Dehors, dans la rue, quelques gars très décidés s'apprêtent à vous rendre visite, et je doute qu'ils viennent vous offrir des cadeaux de Noël.";
			link.l1.go = "CaracasWervolf_1";
		break;
		case "CaracasWervolf_1":
			dialog.text = "Ils vont me brמler ! Mais Dieu sait que je suis innocent ! J'ai fui Maracaibo, une terrible malédiction qui s'est abattue sur tous les habitants de notre ville. Capitaine ! Vous pouvez m'aider. J'ai besoin de me confesser !";
			link.l1 = "Vous vous trompez d'adresse, mon cher. Je ne suis pas prêtre.";
			link.l1.go = "CaracasWervolf_2";
		break;
		case "CaracasWervolf_2":
			dialog.text = "Mais vous pouvez amener un prêtre ici, n'est-ce pas ?";
			link.l1 = ""+ GetSexPhrase("J'ai perdu tant d'âmes que je pourrai bien aider à en sauver au moins une.","Bien.") +" Attendez ici, tâchez de tenir bon !";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			pchar.questTemp.MC = "toCaracasPadre";
			iTemp = FindLocation("Caracas_tavern");
			DeleteAttribute(&locations[iTemp], "reload.l1.disable");
			DeleteAttribute(&locations[iTemp], "reload.l4.disable");
			LocatorReloadEnterDisable("Caracas_town", "reload7_back", false);
			locations[iTemp].reload.l2.disable = true;
			for (i=1; i<=12; i++)
			{
				sld = characterFromId("CaracasCit_"+i);
				sld.dialog.currentnode = "CaracasMan2";
				LAi_SetActorTypeNoGroup(sld);
				LAi_ActorWaitDialog(sld, pchar);
			}
		break;
		//горожане Каракаса на выходе из таверны
		case "CaracasMan2":
			dialog.text = "Alors ? Le loup-garou s'est enfui ?";
			link.l1 = "Voilà ce que tu vas faire : rentrer chez toi ! Il n'y a pas de loup-garou là-dedans !";
			link.l1.go = "exit_orient";
		break;
		//охрана Дес-Мойнеса в бухте
		case "ShoreGuard":
			dialog.text = "Hé, toi ! On n'a pas besoin d'étrangers ici. Fiche le camp !";
			link.l1 = "Une centaine de poulettes jaunes bien dodues t'apprendront peut-être à caqueter plus poliment ?";
			link.l1.go = "ShoreGuard_1";
		break;
		case "ShoreGuard_1":
			dialog.text = "Fais attention de ne pas"+ GetSexPhrase(" finir en coq rכti, mon coco"," finir en poule au pot, ma poulette") +" ! Si tu ne fais pas demi-tour de bon gré, on t'y forcera !";
			link.l1 = "Et qui peut m'interdire d'aller oם je veux ?";
			link.l1.go = "ShoreGuard_2";
		break;
		case "ShoreGuard_2":
			dialog.text = "Trois pouces d'acier entre les cכtes !";
			link.l1 = "Eh bien, comparons, pour voir quel acier est le meilleur ?";
			link.l1.go = "ShoreGuard_3";
		break;
		case "ShoreGuard_3":
			LocatorReloadEnterDisable("DesMoines_port", "gate_back", false);
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			AddDialogExitQuest("MainHeroFightModeOn");
			AddQuestRecord("MagicCity", "3");
			DialogExit();
		break;
		//жители Дес-Мойнеса обычные
		case "DMCitiz":
			NextDiag.TempNode = "DMCitiz";
			dialog.text = LinkRandPhrase("Que venez-vous faire dans notre ville ?", "Les visiteurs sont très rares dans notre ville. Et que vouliez-vous ?", "Je ne dirais pas que nous sommes contents de vous accueillir. Que venez-vous faire à Des Moines ?");
			link.l1 = "Voir comment vous vivez...";
			link.l1.go = "DesMoinesCitizen_1";
			if (pchar.questTemp.MC == "toByeBye")
			{
				dialog.text = LinkRandPhrase("Maudit sois-tu ! Pars tant que tu le peux encore...", "Allez, fiche le camp d'ici, lâche...", "Dehors ! Et que je ne te revoie plus ici...");
				link.l1 = "Sans faute !";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSister" || pchar.questTemp.MC == "toSeekSkull" || pchar.questTemp.MC == "toSeekQueen")
			{
				dialog.text = LinkRandPhrase("On dit que vous avez accepté de nous aider. Bonne chance à vous, capitaine...", "Que Dieu vous bénisse, "+ GetSexPhrase("señor capitaine ","señorita ") +" !", "Comme je souhaite que tout vous réussisse !");
				link.l1 = "Sans faute !";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "over")
			{
				dialog.text = ""+ GetSexPhrase("Señor, vous êtes notre sauveur","Señorita, vous êtes notre sauveuse") +" ! Que le Seigneur vous protège !";
				link.l1 = "Merci. Vous me touchez, vous me touchez...";
				link.l1.go = "exit";
			}
		break;
		case "DesMoinesCitizen_1":
			dialog.text = "Tout va bien.";
			link.l1 = "Eh bien, parfait !";
			link.l1.go = "DesMoinesCitizen_2";
		break;
		case "DesMoinesCitizen_2":
			dialog.text = "Je ne vous conseille pas de rester chez nous. Notre ville n'est pas très hospitalière...";
			link.l1 = "Hum... eh bien, c'est comme ça.";
			link.l1.go = "exit";
		break;
		//жители Дес-Мойнеса скелеты
		case "DMSkel":
			NextDiag.TempNode = "DMSkel";
			dialog.text = LinkRandPhrase("La malédiction s'est abattue sur nous !", "Notre ville est maudite !", "Vous voyez ce qui nous arrive ? Quel terrible malheur !");
			link.l1 = "Oui...";
			link.l1.go = "DesMoinesSkel_1";
			if (pchar.questTemp.MC == "toByeBye")
			{
				dialog.text = LinkRandPhrase("Maudit sois-tu ! Pars tant que tu le peux encore...", "Allez, fiche le camp d'ici, lâche...", "Dehors ! Et que je ne te revoie plus ici...");
				link.l1 = "Sans faute !";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSister" || pchar.questTemp.MC == "toSeekSkull" || pchar.questTemp.MC == "toSeekQueen")
			{
				dialog.text = LinkRandPhrase("On dit que vous avez accepté de nous aider. Bonne chance à vous, capitaine...", "Que Dieu vous bénisse, "+ GetSexPhrase("señor capitaine ","señorita ") +" !", "Comme je souhaite que tout vous réussisse !");
				link.l1 = "Sans faute !";
				link.l1.go = "exit";
			}
		break;
		case "DesMoinesSkel_1":
			dialog.text = "Puisque vous avez vu tout ce cauchemar, allez voir notre maire, Fernando Torres. Parlez-lui sans faute.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			LocatorReloadEnterDisable("DesMoines_town", "reload1_back", true);
		break;
		//глава городка обычный
		case "DMCitizHead":
			NextDiag.TempNode = "DMCitizHead";
			dialog.text = "Bonjour. Qu'est-ce qui vous amène à Des Moines ?";
			link.l1 = "Juste pour voir ce qu'il en est... Dites-moi, tout va bien dans la ville ?";
			link.l1.go = "DMCitizHead_1";
			if (pchar.questTemp.MC == "toByeBye")
			{
				dialog.text = "Allez-vous-en ! Je ne veux pas avoir affaire à vous.";
				link.l1 = "Hum... eh bien, tant pis.";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSister")
			{
				dialog.text = ""+ GetSexPhrase("Señor capitaine,","Señorita,") +" dès que vous apprendrez quelque chose de nouveau, prévenez-moi immédiatement, je vous prie. En fait, vous êtes notre dernier espoir de retrouver une vie normale.";
				link.l1 = "Je ferai tout mon possible pour lever cette terrible malédiction. Courage !";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSkull")
			{
				dialog.text = "Bonjour, capitaine ! Qu'avez-vous à me dire ?";
				link.l1 = "J'ai retrouvé Elizabeth Sheppard.";
				link.l1.go = "FoundLiz";
			}
			if (pchar.questTemp.MC == "toSeekQueen")
			{
				dialog.text = "Bonjour, capitaine ! Qu'avez-vous à me dire ?";
				link.l1 = "J'ai commencé à chercher le galion « Queen ». On dirait que c'est la dernière étape vers votre délivrance.";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "over")
			{
				dialog.text = "Vous avez levé la malédiction ? א un moment donné, tout est redevenu normal !";
				link.l1 = "Oui. J'ai retrouvé le galion « Queen » et j'ai fait tout ce qu'il fallait. C'est une joie d'avoir pu vous aider.";
				link.l1.go = "DMHeadOver";
			}
			if (CheckAttribute(pchar, "questTemp.MC.DesMoines"))
			{
				dialog.text = ""+ GetSexPhrase("Señor","Señorita") +", vous qui nous avez sauvés ! Vous vouliez quelque chose ?";
				link.l1 = "Non, rien de spécial...";
				link.l1.go = "exit";
			}
		break;
		case "DMCitizHead_1":
			dialog.text = "Tout va bien. Pourquoi cette question ?";
			link.l1 = "Vous savez, quand j'ai débarqué au port, des gens se sont jetés sur moi. Je ne comprends absolument pas pourquoi.";
			link.l1.go = "DMCitizHead_2";
		break;
		case "DMCitizHead_2":
			dialog.text = "Je ne peux rien vous dire à ce sujet. Je ne sais pas qui c'était.";
			link.l1 = "Je vois... Donc, vous dites que tout est calme à Des Moines.";
			link.l1.go = "DMCitizHead_3";
		break;
		case "DMCitizHead_3":
			dialog.text = "Tout à fait.";
			link.l1 = "Bon, je vois. Excusez-moi...";
			link.l1.go = "exit";
		break;

		case "FoundLiz":
			dialog.text = NPCStringReactionRepeat("Parfait ! Et qu'avez-vous appris ?",
				"Nous en avons déjà parlé, capitaine.",
				"Capitaine, nous en avons déjà parlé.",
                "Capitaine, combien de fois faudra-t-il le répéter ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Elizabeth ne sait ni comment ni pourquoi cette malédiction a été lancée. Mais elle a découvert comment la lever.",
				"Oui, je m'en souviens.",
                "Oui, bien sמr...",
				"Je suis comme ça, obstiné. Je crois que je vais continuer à demander la même chose : un miracle se produira peut-être ! Le sort tombera de lui-même, ou quelque chose d'autre...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("FoundLiz_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "FoundLiz_1":
			dialog.text = "Mon Dieu, capitaine ! L'espoir prend forme ! Dites-moi vite, comment faire ?";
			link.l1 = "Grâce au crâne de jade des Aztèques. Il faut se le procurer, et Elizabeth nous dira ce qu'il faut faire ensuite.";
			link.l1.go = "FoundLiz_2";
		break;
		case "FoundLiz_2":
			dialog.text = "Capitaine, je vous en prie, faites de votre mieux.";
			link.l1 = "C'est ce que je fais.";
			link.l1.go = "exit";
		break;

		case "DMHeadOver":
			dialog.text = "Merci infiniment ! Au nom de nos citoyens, j'ai le plaisir de vous annoncer que nous avons préparé une récompense pour vos efforts.";
			link.l1 = "Quelle récompense ?";
			link.l1.go = "DMHeadOver_1";
		break;
		case "DMHeadOver_1":
			dialog.text = "Vingt mille piastres ! Ce n'est peut-être pas grand-chose pour vous, mais notre ville s'est beaucoup appauvrie pendant ce maudit temps, alors c'est tout ce que nous avons.";
			link.l1 = "Allons, gardez cet argent pour vous. Vous en avez plus besoin en ce moment.";
			link.l1.go = "DMHeadOver_2";
			link.l2 = "J'accepte votre argent.";
			link.l2.go = "DMHeadOver_3";
			
			AddQuestRecord("MagicCity", "9");
			CloseQuestHeader("MagicCity");
			pchar.questdata.ZacharovanyGorod = 1;
			pchar.questTemp.MC.DesMoines = true;
			SetTimerFunction("MC_DesMoinesVozrojdenie", 0, 0, 7);
		break;
		case "DMHeadOver_2":
			dialog.text = "Merci encore. Honnêtement, je ne m'y attendais pas...";
			link.l1 = "Il n'y a pas de quoi. Vivez heureux, désormais.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 10);
		break;
		case "DMHeadOver_3":
			dialog.text = "Parfait ! Eh bien, tous mes vœux de bonheur, "+ GetSexPhrase("señor","señorita") +".";
			link.l1 = "א vous aussi, tous mes vœux.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 20000);
		break;

		//глава городка скелет
		case "DMSkelHead":
			NextDiag.TempNode = "DMSkelHead";
			dialog.text = "J'avais déjà oublié quand j'avais vu pour la dernière fois une personne vivante au milieu de la nuit, et pas un ignoble squelette !";
			link.l1 = "Mère de Dieu, vous avez un drכle d'endroit, ici ! Pour l'amour de Dieu, que se passe-t-il ?";
			link.l1.go = "DMSkelHead_1";
			if (pchar.questTemp.MC == "toByeBye")
			{
				dialog.text = "Allez-vous-en ! Je ne veux pas avoir affaire à vous.";
				link.l1 = "Hum... eh bien, tant pis.";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSister")
			{
				dialog.text = ""+ GetSexPhrase("Señor capitaine,","Señorita,") +" dès que vous apprendrez quelque chose de nouveau, prévenez-moi immédiatement, je vous prie. En fait, vous êtes notre dernier espoir de retrouver une vie normale.";
				link.l1 = "Je ferai tout mon possible pour lever cette terrible malédiction. Courage !";
				link.l1.go = "exit";
			}
			if (pchar.questTemp.MC == "toSeekSkull")
			{
				dialog.text = "Bonjour, capitaine ! Qu'avez-vous à me dire ?";
				link.l1 = "J'ai retrouvé Elizabeth Sheppard.";
				link.l1.go = "FoundLiz";
			}
			if (pchar.questTemp.MC == "toSeekQueen")
			{
				dialog.text = "Bonjour, capitaine ! Qu'avez-vous à me dire ?";
				link.l1 = "J'ai commencé à chercher le galion « Queen ». On dirait que c'est la dernière étape vers votre délivrance.";
				link.l1.go = "exit";
			}
		break;
		case "DMSkelHead_1":
			dialog.text = "Je vais vous raconter, si vous voulez ! De toute façon, vous n'irez pas loin avec cette histoire.";
			link.l1 = "Je ne suis pas du genre craintif, il n'y a rien qui puisse m'effrayer. Racontez.";
			link.l1.go = "DMSkelHead_2";
		break;
		case "DMSkelHead_2":
			dialog.text = "Un jour, le galion pirate « Queen » a accosté à notre cap. Les pirates vendaient ici des esclaves aux contrebandiers. Ils s'arrangent entre eux... "+
				"Les pirates ont vendu les esclaves, et puis ils se sont querellés entre eux. Une partie de l'équipage est restée ici, et les autres ont repris la mer avec le capitaine, sur le galion. C'est là que tout a commencé.";
			link.l1 = "Mais quoi donc ? Parlez franchement !";
			link.l1.go = "DMSkelHead_3";
		break;
		case "DMSkelHead_3":
			dialog.text = "Eh bien, ce que vous voyez. Pendant la journée, tout le monde est comme tout le monde, mais dès que le soleil se couche, c'est une véritable mascarade. On a compris que tout venait de ces pirates, qu'ils soient maudits ! Et même s'ils se changeaient eux aussi en squelettes la nuit, peu importe : tous ceux qui étaient restés chez nous ont été envoyés au bמcher, une belle nuit. דa n'a servi à rien...";
			link.l1 = "Oui, c'est une triste histoire...";
			link.l1.go = "DMSkelHead_4";
		break;
		case "DMSkelHead_4":
			dialog.text = "Bon, capitaine, vous connaissez maintenant notre secret et notre malheur. Vous comprenez que désormais, vous allez devoir les partager avec nous ?";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "DMSkelHead_5";
		break;
		case "DMSkelHead_5":
			dialog.text = "Je veux dire que vous n'avez pas le droit de quitter Des Moines. Personne n'a besoin de publicité.";
			link.l1 = "Je n'ai pas l'intention de rester ici.";
			link.l1.go = "DMSkelHead_6";
		break;
		case "DMSkelHead_6":
			dialog.text = "Les gardes du port vous ont honnêtement refusé l'entrée. Mais vous avez forcé le passage quand même. Alors, ne vous en prenez qu'à vous-même.";
			link.l1 = "Je ne vous conseille pas d'essayer de me retenir de force. J'ai forcé le passage des gardes pour venir ici, et je sortirai d'ici de toute façon...";
			link.l1.go = "DMSkelHead_7";
		break;
		case "DMSkelHead_7":
			dialog.text = "C'est peut-être vrai, mais personne ne vous retiendra de force. De toute façon, personne ne croira vos histoires, et si on les croit, on enverra l'Inquisition avec une centaine de soldats... et la vie de toute la ville sera sur votre conscience. Cependant, on dirait que vous en avez l'habitude...";
			link.l1 = "Bon sang, vous avez raison. Puis-je faire quelque chose pour vous aider ?";
			link.l1.go = "DMSkelHead_8";
			link.l2 = "Vous avez tout à fait raison, monsieur le maire. Qu'ai-je à faire de vous et de votre ville ? Faites de beaux rêves !";
			link.l2.go = "DMSkelHead_bye";
			LocatorReloadEnterDisable("DesMoines_town", "reload1_back", false); //выпускаем из города
		break;

		case "DMSkelHead_bye":
			dialog.text = "Vous de même, cher capitaine.";
			link.l1 = "Au revoir. Ne vous ennuyez pas...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, -20);
			AddQuestRecord("MagicCity", "4");
			AddQuestUserData("MagicCity", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("MagicCity", "sSex1", GetSexPhrase("", "e"));
			pchar.questTemp.MC = "toByeBye"; //флаг квеста
		break;

		case "DMSkelHead_8":
			dialog.text = "Lever la malédiction, c'est notre rêve. Le malheur, c'est que nous ne savons même pas ce qui se passe.";
			link.l1 = "C'est fâcheux... Il faudrait peut-être essayer de retrouver ce galion sur lequel les pirates sont partis ? On dirait que c'est la seule piste.";
			link.l1.go = "DMSkelHead_9";
		break;
		case "DMSkelHead_9":
			dialog.text = "Vous savez, récemment, une jeune femme est venue dans notre ville : Elizabeth Sheppard, je crois qu'elle s'appelait. Eh bien, cette demoiselle a loué une tartane à Maracaibo, a fait voile jusqu'à nous et a persuadé les gardes de la laisser venir me voir.";
			link.l1 = "Et alors ?";
			link.l1.go = "DMSkelHead_10";
		break;
		case "DMSkelHead_10":
			dialog.text = "Elle cherchait à savoir en détail ce qui s'était passé cette nuit-là entre les pirates. Je lui ai demandé pourquoi elle en avait besoin, mais elle s'est révélée être d'une autre trempe ! Elle n'a rien dit.";
			link.l1 = "Et vous l'avez laissée partir ?";
			link.l1.go = "DMSkelHead_11";
		break;
		case "DMSkelHead_11":
			dialog.text = "Je l'ai laissée partir. Elle ne nous a pas vus sous cette apparence monstrueuse. Voilà donc ce que je veux vous dire. Plus le temps passe depuis notre conversation, plus je suis convaincu que Mlle Elizabeth Sheppard sait quelque chose.";
			link.l1 = "Elle est anglaise ?";
			link.l1.go = "DMSkelHead_12";
		break;
		case "DMSkelHead_12":
			dialog.text = "Sans aucun doute. J'avoue que j'ai commis une erreur en la laissant partir comme ça. J'aurais dמ découvrir tout ce qu'elle savait. Maintenant, je vous demande de la retrouver et de découvrir tout ce qu'elle sait sur ces maudits pirates et le galion « Queen ».";
			link.l1 = "D'accord, c'est ce que je vais faire.";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 5);
			AddQuestRecord("MagicCity", "5");
			AddQuestUserData("MagicCity", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.MC = "toSeekSister"; //флаг квеста
			LocatorReloadEnterDisable("Charles_town", "housePirate", false);
			//ставим Лиз Шеппард
			sld = GetCharacter(NPC_GenerateCharacter("LizSheppard", "BaynesDaughterSTOK", "woman", "towngirl", 10, ENGLAND, -1, false));
			sld.name = "Elizabeth";
			sld.lastname = "Sheppard";
			sld.dialog.filename = "Quest\MagicCity.c";
			sld.dialog.currentnode = "LizBegin";
			LAi_SetCitizenType(sld);
			LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
			ChangeCharacterAddressGroup(sld, "Charles_PirateHouse", "goto", "goto1");
		break;
		//Элизабет Шеппард
		case "LizBegin":
			dialog.text = "Bonjour, capitaine. א quoi dois-je le plaisir de vous voir chez moi ?";
			link.l1 = "Bonjour, Elizabeth. Je m'appelle " + GetFullName(pchar) + ". Je viens vous parler d'une chose... une affaire très inhabituelle.";
			link.l1.go = "LizBegin_1";
		break;
		case "LizBegin_1":
			dialog.text = "Je vous écoute attentivement, capitaine.";
			link.l1 = "Il y a quelque temps, vous vous êtes rendue dans une petite colonie espagnole, Des Moines. Le maire de cette petite ville, Fernando Torres, que vous connaissez, je crois, m'a demandé de vous retrouver. Ce que j'ai fait avec plaisir.";
			link.l1.go = "LizBegin_2";
		break;
		case "LizBegin_2":
			dialog.text = "Vous me surprenez, capitaine. Continuez.";
			link.l1 = "Fernando vous demande votre aide.";
			link.l1.go = "LizBegin_3";
		break;
		case "LizBegin_3":
			dialog.text = "Comment puis-je l'aider ?";
			link.l1 = "Aidez-moi à retrouver le galion « Queen ».";
			link.l1.go = "LizBegin_4";
		break;
		case "LizBegin_4":
			dialog.text = "Pourquoi a-t-il besoin de ce galion ?";
			link.l1 = "Le fait est, mademoiselle, que les habitants de la ville associent à ce galion... l'apparition d'une épidémie soudaine qui a frappé la ville.";
			link.l1.go = "LizBegin_5";
		break;
		case "LizBegin_5":
			dialog.text = "La malédiction a donc frappé les habitants de Des Moines ?!";
			link.l1 = "Oui, c'est cela. Vous êtes donc au courant de la malédiction ?";
			link.l1.go = "LizBegin_6";
		break;
		case "LizBegin_6":
			dialog.text = "Bien sמr que je suis au courant ! Le fait est que le capitaine du galion « Queen » est une personne qui m'est très chère. Ces derniers temps, je ne fais qu'essayer de démêler cet écheveau et de briser ce sortilège diabolique.";
			link.l1 = "Et vous y arrivez ?";
			link.l1.go = "LizBegin_7";
		break;
		case "LizBegin_7":
			dialog.text = "En partie. Le fait est que je suis la fille d'un homme célèbre parmi les pirates. Mon père, le capitaine Staton, était le plus proche compagnon d'Edward Mansfield !";
			link.l1 = "Oh, c'est très honorable, mademoiselle...";
			link.l1.go = "LizBegin_8";
		break;
		case "LizBegin_8":
			dialog.text = "Alors, n'ayant pas d'autre choix, je me suis adressée à Jackman pour obtenir de l'aide. J'espère que vous savez de qui il s'agit ?";
			link.l1 = "Bien sמr !";
			link.l1.go = "LizBegin_9";
		break;
		case "LizBegin_9":
			dialog.text = "Ce que les pirates ont appris des esclaves indiens n'a fait que provoquer l'hilarité générale des corsaires. Mais moi, je ne plaisante pas, je l'ai vu de mes propres yeux !..";
			link.l1 = "Je l'ai vu aussi, Elizabeth. Des squelettes humains qui marchent et qui parlent, ce n'est pas un spectacle agréable. Alors, qu'ont appris mes collègues auprès des Indiens ?";
			link.l1.go = "LizBegin_10";
		break;
		case "LizBegin_10":
			dialog.text = "Seul un dieu aztèque des morts nommé Mictlantecuhtli a pu faire cela.";
			link.l1 = "Oh... Bon, que dois-je faire maintenant ?";
			link.l1.go = "LizBegin_11";
		break;
		case "LizBegin_11":
			dialog.text = "Il faut se procurer un crâne de jade, un artefact de ce dieu. Ce n'est qu'avec son aide qu'on pourra lever la malédiction.";
			link.l1 = "Et oם pensez-vous qu'il se trouve ?";
			link.l1.go = "LizBegin_12";
		break;
		case "LizBegin_12":
			dialog.text = "Dans la cité perdue des Aztèques.";
			link.l1 = "Elizabeth, que s'est-il passé au port, au juste ? Pourquoi cette malédiction s'est-elle abattue sur les habitants de Des Moines ?";
			link.l1.go = "LizBegin_13";
		break;
		case "LizBegin_13":
			dialog.text = "Je ne sais pas. Une nuit, il y a plus d'un an, j'ai entendu quelqu'un entrer dans la maison. Je suis descendue et j'ai vu un squelette décomposé. C'était terrible. J'ai crié. Le squelette a crié lui aussi et s'est enfui. Ce n'est qu'ensuite que j'ai compris que c'était le capitaine de la « Queen ». Et moi, je l'ai fait fuir !";
			link.l1 = "Vous savez, mademoiselle, vous êtes une jeune femme d'un rare sang-froid. La plupart des demoiselles, à votre place, en auraient eu le cœur brisé de peur.";
			link.l1.go = "LizBegin_14";
		break;
		case "LizBegin_14":
			dialog.text = "Il n'empêche que j'ai repoussé une personne qui m'est chère. Alors, j'ai fermement décidé de découvrir quel malheur avait frappé le capitaine de la « Queen » et de l'en délivrer !";
			link.l1 = "Bon sang, que c'est romantique ! Ce pauvre garçon a de la chance d'avoir une amie aussi fidèle.";
			link.l1.go = "LizBegin_15";
		break;
		case "LizBegin_15":
			dialog.text = "Capitaine, je vous prie de surveiller vos expressions. N'oubliez pas de qui la fille se tient devant vous ! Maintenant qu'il est clair que nous faisons en fait la même chose, je voudrais vous demander de vous procurer le crâne de jade du dieu des morts. Je ne peux pas le faire, vous le savez bien.";
			if (CheckCharacterItem(pchar, "SkullAztec"))
			{
				link.l1 = "J'ai déjà ce crâne, Elizabeth.";
				link.l1.go = "LizBegin_haveSkull";
			}
			else
			{
				link.l1 = "Eh bien, mademoiselle, je veux bien le faire, ne serait-ce qu'en mémoire de votre père. Donc, vous dites que ce crâne se trouve dans une cité indienne ?";
				link.l1.go = "LizBegin_seekSkull";
			}
		break;

		case "LizBegin_SeekSkull":
			dialog.text = "C'est exact. Dans la capitale aztèque abandonnée de Tenochtitlan.";
			link.l1 = "Compris. Si je parviens à me procurer ce crâne, je reviendrai d'abord ici, à Charlestown.";
			link.l1.go = "LizBegin_16";
			ChangeCharacterReputation(pchar, 3);
		break;
		case "LizBegin_16":
			dialog.text = "Bien, capitaine, je vous attendrai. Merci.";
			link.l1 = "Je vous en prie...";
			link.l1.go = "exit";
			AddQuestRecord("MagicCity", "6");
			AddQuestUserData("MagicCity", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("MagicCity", "sSex1", GetSexPhrase("", "e"));
			pchar.questTemp.MC = "toSeekSkull"; //флаг квеста
			NextDiag.TempNode = "LizCheckSkull";
		break;

		case "LizBegin_haveSkull":
			dialog.text = "Comment avez-vous réussi à vous le procurer ?!";
			link.l1 = "C'est une longue histoire... Dites-moi ce qu'il faut faire ensuite.";
			link.l1.go = "LizCheckSkull_1";
		break;
		//проверка черепа
		case "LizCheckSkull":
			dialog.text = "Vous avez rapporté le crâne de jade, capitaine ?";
			if (CheckCharacterItem(pchar, "SkullAztec"))
			{
				link.l1 = "Je l'ai, Elizabeth.";
				link.l1.go = "LizCheckSkull_Ok";
			}
			else
			{
				link.l1 = "Pas encore. Mais je m'en occupe.";
				link.l1.go = "exit";
			}
		break;
		case "LizCheckSkull_Ok":
			dialog.text = "Vous avez quand même réussi à vous le procurer !";
			link.l1 = "דa n'a pas été facile, je vous le dis... Que dois-je faire maintenant, mademoiselle ?";
			link.l1.go = "LizCheckSkull_1";
		break;
		case "LizCheckSkull_1":
			dialog.text = "Maintenant, nous avons un moyen de lever la malédiction. Il faut trouver le galion « Queen » et lever la malédiction qui pèse sur son capitaine.";
			link.l1 = "Le dieu aztèque des morts, celui qui m'a donné le crâne de jade, a dit entre autres que le crâne pouvait aider les vivants maudits. Mais il n'a pas expliqué comment les aider...";
			link.l1.go = "LizCheckSkull_2";
		break;
		case "LizCheckSkull_2":
			dialog.text = "Je suppose qu'il suffit d'apporter le crâne dans la cabine du capitaine de la « Queen ». Dans ce cas, la malédiction devrait disparaître d'elle-même.";
			link.l1 = "Peut-être... Et oם puis-je trouver ce galion ?";
			link.l1.go = "LizCheckSkull_3";
		break;
		case "LizCheckSkull_3":
			dialog.text = "Je ne sais pas. Le plus probable, c'est que le capitaine erre en mer, loin des villes. Regardez bien autour de vous, vous ne manquerez sמrement pas ce galion.";
			link.l1 = "Je vois. Bon, je vais me mettre à sa recherche.";
			link.l1.go = "exit";
			SetDanielleInWorld();
			AddQuestRecord("MagicCity", "7");
			pchar.questTemp.MC = "toSeekQueen"; //флаг квеста
			NextDiag.TempNode = "LizSeekQueen";
		break;
		case "LizSeekQueen":
			dialog.text = "Capitaine, avez-vous trouvé le galion « Queen » ?";
			link.l1 = "Pas encore...";
			link.l1.go = "exit";
			if (pchar.questTemp.MC == "over")
			{
				dialog.text = "Vous avez quand même levé la malédiction !";
				link.l1 = "Oui, j'ai réussi.";
				link.l1.go = "LizOver";
			}
		break;

		case "LizOver":
			dialog.text = "Mon Dieu, comme je suis heureuse pour ma sœur !";
			link.l1 = "Au fait, Elizabeth, pourquoi ne m'avez-vous pas dit tout de suite que la personne qui vous est chère est votre sœur ?";
			link.l1.go = "LizOver_1";
		break;
		case "LizOver_1":
			dialog.text = "Au cas oם...";
			link.l1 = "Je vois. Vous êtes bien la fille de votre père, ça se voit... Au fait, Danielle s'est engagée chez moi comme officier.";
			link.l1.go = "LizOver_2";
		break;
		case "LizOver_2":
			dialog.text = "Très bien. Je pense que vous saurez prendre soin d'elle, car elle a complètement perdu le sens de la mesure dans ses exploits de corsaire.";
			link.l1 = "Eh bien, je vais essayer.";
			link.l1.go = "LizOver_3";
		break;
		case "LizOver_3":
			dialog.text = "Au fait, capitaine, avant que vous ne partiez, je voudrais vous remercier par un présent. J'y ai réfléchi et j'ai décidé de vous donner l'objet que je tiens de mon père. C'est une amulette ancienne appelée « Janissaire ». D'après les rumeurs, le propriétaire d'un tel talisman rend son équipage beaucoup plus obéissant. J'espère qu'elle vous sera plus utile qu'à moi.";
			link.l1 = "דa alors, ça ne vous fait rien de vous séparer d'une telle chose, mademoiselle ? Eh bien, j'accepte volontiers votre cadeau !";
			Log_Info("Vous avez reçu un talisman");
			AddItems(pchar, "talisman4", 1);
			link.l1.go = "LizOver_4";
		break;
		case "LizOver_4":
			dialog.text = "Ce sera tout, je pense. Au revoir, capitaine !";
			link.l1 = "Au revoir, Elizabeth.";
			link.l1.go = "exit";
			npchar.lifeDay = 30;
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			NextDiag.TempNode = "LizOver_end";
		break;
		case "LizOver_end":
			dialog.text = "Vous vouliez quelque chose, capitaine ?";
			link.l1 = "Non, rien de spécial...";
			link.l1.go = "exit";
		break;
		//Даниэль на абордаже
		case "DanAbordage":
			dialog.text = "Je vais te saigner, maintenant !";
			link.l1 = "Hé, madame, qu'est-ce qui vous prend ?! Parlons, pourquoi vous jetez-vous sur moi comme une furie déchaînée ?!";
			link.l1.go = "DanAbordage_1";
		break;
		case "DanAbordage_1":
			dialog.text = "Nous n'avons rien à nous dire. Vous avez attaqué mon galion !";
			link.l1 = "Je devais pénétrer dans la cabine du capitaine, je n'avais pas d'autre solution !.. Attendez, ce galion est à vous ?";
			link.l1.go = "DanAbordage_2";
		break;
		case "DanAbordage_2":
			dialog.text = "Il est à moi depuis cinq ans.";
			link.l1 = "Alors, c'est vous, la personne chère au cœur d'Elizabeth... Et moi qui croyais qu'elle parlait d'un homme !";
			link.l1.go = "DanAbordage_3";
		break;
		case "DanAbordage_3":
			dialog.text = "Vous connaissez ma sœur Elizabeth ?";
			link.l1 = "C'est de sa part que je suis ici. Et vous, si je comprends bien, vous êtes sa sœur aînée, Danielle Sheppard ?";
			link.l1.go = "DanAbordage_4";
		break;
		case "DanAbordage_4":
			dialog.text = "Exactement ! Permettez-moi de vous demander qui vous êtes.";
			link.l1 = "On m'appelle capitaine " + GetFullName(pchar) + ". Je cherchais votre galion pour briser la malédiction. Racontez-moi comment la malédiction du dieu aztèque des morts est tombée sur vous.";
			link.l1.go = "DanAbordage_5";
		break;
		case "DanAbordage_5":
			dialog.text = "Alors c'était donc ça ! Et moi qui ne savais toujours pas quel genre d'épouvantail c'était, à Des Moines, dans la baie de Maracaibo. Vous savez sans doute que je suis la fille du capitaine Staton. Bien que je sois une femme, j'ai réussi à défendre mon droit d'être le capitaine de la « Queen ». "+
				"Un jour, aux Bermudes, j'ai engagé un maître d'équipage nommé Pierre Cabal. Ce fut une erreur, le monde n'a jamais vu pareil gredin. Au large de Santa Catalina, il a capturé un jeune Indien. Malheureusement, je ne l'ai appris que lorsque nous approchions déjà de Maracaibo. Le gredin avait décidé de le vendre et de garder l'argent pour lui. Il le justifiait en disant que l'Indien était personnellement sa prise légitime. "+
				"Il est clair que je ne pouvais pas permettre un tel abus. א Des Moines, au moment de la transaction, j'ai déclaré que soit nous vendions l'Indien au profit de tous, soit je le libérais. Finalement, j'ai dמ le relâcher. Mais ce gredin de Cabal a sorti un pistolet et a tiré dans le dos de l'Indien. Notre duel semblait inévitable. "+
				"Cependant, le destin en a décidé autrement. Dès que l'Indien est tombé dans l'herbe en gémissant, un terrible épouvantail couvert de plumes est apparu de nulle part, a saisi l'Indien mort et a annoncé d'une voix de tonnerre que mon équipage et moi étions désormais maudits. Et il a disparu.";
			link.l1 = "Je reconnais là Mictlantecuhtli en personne.";
			link.l1.go = "DanAbordage_6";
		break;
		case "DanAbordage_6":
			dialog.text = "Tout le monde est resté comme frappé par la foudre. Il n'était plus question de duel. Mais il était aussi impossible de reprendre Cabal à bord du galion. Alors, j'ai repris la mer avec la majeure partie de l'équipage. Seuls ceux qui sympathisaient avec Pierre sont restés.";
			link.l1 = "Et c'est alors que vous avez compris que la malédiction n'était pas une plaisanterie...";
			link.l1.go = "DanAbordage_7";
		break;
		case "DanAbordage_7":
			dialog.text = "La nuit même. Imaginez notre horreur !";
			link.l1 = "J'imagine. Au fait, la malédiction n'est pas tombée que sur vous, mais aussi sur les habitants de Des Moines.";
			link.l1.go = "DanAbordage_8";
		break;
		case "DanAbordage_8":
			dialog.text = "C'est le diable !";
			link.l1 = "Vous avez de la chance, Danielle, qu'Elizabeth vous ait reconnue dans le squelette qui est venu la voir la nuit. Et qu'elle se soit mise à agir.";
			link.l1.go = "DanAbordage_10";
		break;
		case "DanAbordage_10":
			dialog.text = "Cette chère petite Elizabeth ! Oui, il y a de quoi être fière de ma sœur. Alors, capitaine, si c'est pour lever la malédiction que vous êtes là, faites-le !";
			link.l1 = "On dirait que le travail est déjà fait. Je devais apporter le crâne de jade de Mictlantecuhtli près du capitaine du galion « Queen », et c'est chose faite.";
			link.l1.go = "DanAbordage_11";
		break;
		case "DanAbordage_11":
			dialog.text = "La malédiction a été levée ? Je ne vais plus me changer en squelette ?";
			link.l1 = "Je pense que non. C'est fini.";
			link.l1.go = "DanAbordage_12";
		break;
		case "DanAbordage_12":
			dialog.text = "Capitaine, comment pourrais-je vous remercier pour le service rendu ?";
			link.l1 = "Remerciez votre sœur... Quoique, vous savez, j'ai une proposition d'affaires à vous faire : venez chez moi comme officier. Je suis "+ GetSexPhrase("pirate","une corsaire") +", tout comme vous. Je pense que nous ferons du bon travail ensemble.";
			link.l1.go = "DanAbordage_13";
		break;
		case "DanAbordage_13":
			dialog.text = "Eh bien, pourquoi pas ? J'accepte.";
			link.l1 = "Parfait !";
			link.l1.go = "DanAbordage_14";
		break;
		case "DanAbordage_14":
			//чистим базу нпс-кэпов  -->
			DeleteAttribute(&NullCharacter, "capitainBase.Danielle");
			//<-- чистим базу нпс-кэпов
			AddQuestRecord("MagicCity", "8");
			pchar.questTemp.MC = "over"; //флаг квеста
			sld = GetCharacter(NPC_GenerateCharacter("DanielleOff", "Danielle", "woman", "Danielle", 25, PIRATE, -1, true));
			sld.name = "Danielle";
			sld.lastname = "Sheppard";
			sld.greeting = "Gr_Danielle";
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			SetSelfSkill(sld, 90, 60, 30, 60, 90);
			SetShipSkill(sld, 80, 20, 75, 75, 80, 20, 70, 60, 70);
			SetSPECIAL(sld, 6, 9, 9, 10, 8, 8, 10);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "ByWorker");
			SetCharacterPerk(sld, "IronWill");
			SetCharacterPerk(sld, "BladeDancer");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "FastReload");
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "SailsDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "MusketsShoot");
			SetCharacterPerk(sld, "AdvancedBattleState");
			SetCharacterPerk(sld, "ShipTurnRateUp");
			SetCharacterPerk(sld, "ShipSpeedUp");
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.HalfImmortal = true;  // Контузия
			sld.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			QuestAboardCabinDialogNotBattle();
            DialogExit();
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; перк растущей жизни докладывает Sync внутри
		break;
		
		case "Man_FackYou":
			dialog.text =LinkRandPhrase("Tu es un voleur, mon cher ! Gardes, arrêtez-le !!!", "דa alors ! J'ai à peine tourné les yeux que te voilà la tête la première dans le coffre ! Arrêtez le voleur !!!", "Gardes ! On vole !!! Arrêtez le voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "Nasilie_fight";
		break;
		case "Nasilie_fight":
			LAi_LocationFightDisable(&Locations[FindLocation("DesMoines_townhall")], false);
			chrDisableReloadToLocation = true; // закрыть выход из локации.
			LAi_SetWarriorType(npchar);
			LAi_group_MoveCharacter(npchar, "SPAIN_CITIZENS");
            LAi_group_SetLookRadius("SPAIN_CITIZENS", 100);
            LAi_group_SetRelation("SPAIN_CITIZENS", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("SPAIN_CITIZENS", LAI_GROUP_PLAYER, false);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}

void SetDanielleInWorld()
{
	//создаём кэпов
	ref sld = GetCharacter(NPC_GenerateCharacter("Danielle", "Danielle", "woman", "Danielle", 30, PIRATE, -1, true));
	sld.name = "Danielle";
	sld.lastname = "Sheppard";
	sld.dialog.filename   = "Quest\MagicCity.c";
	sld.dialog.currentnode   = "DanAbordage";
	sld.greeting = "";
	sld.GenQuest.CrewSkelModeClassic = true; //команда - скелеты
	FantomMakeCoolSailor(sld, SHIP_CATHERINE, "Queen", CANNON_TYPE_CANNON_LBS42, 90, 90, 90);
	RealShips[sti(sld.Ship.Type)].ship.upgrades.hull = 1;
	sld.Ship.Mode = "pirate";

	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	SetCharacterPerk(sld, "FastReload");
	SetCharacterPerk(sld, "HullDamageUp");
	SetCharacterPerk(sld, "SailsDamageUp");
	SetCharacterPerk(sld, "CrewDamageUp");
	SetCharacterPerk(sld, "CriticalShoot");
	SetCharacterPerk(sld, "LongRangeShoot");
	SetCharacterPerk(sld, "CannonProfessional");
	SetCharacterPerk(sld, "ShipDefenseProfessional");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "StormProfessional");
	SetCharacterPerk(sld, "SwordplayProfessional");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "CriticalHit");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "Tireless");
	SetCharacterPerk(sld, "HardHitter");
	SetCharacterPerk(sld, "GunProfessional");
	//в морскую группу кэпа
	string sGroup = "DanielleGroup";
	Group_FindOrCreateGroup(sGroup);
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	sld.quest = "InMap"; //личный флаг искомого кэпа
	sld.city = "SantaCatalina"; //определим колонию, из бухты которой с мушкетом выйдет
	sld.cityShore = GetIslandRandomShoreId(GetArealByCityName(sld.city));
	sld.quest.targetCity = SelectAnyColony(sld.city); //определим колонию, в бухту которой он придёт
	sld.quest.targetShore = GetIslandRandomShoreId(GetArealByCityName(sld.quest.targetCity));
	Log_TestInfo("Queen Galleon left: " + sld.city + " and headed to: " + sld.quest.targetShore);
	//==> на карту
	sld.mapEnc.type = "trade";
	//выбор типа кораблика на карте
	sld.mapEnc.worldMapShip = "quest_ship";
	sld.mapEnc.Name = "Queen";
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sld.quest.targetCity), GetArealByCityName(sld.city)) + 1; //дней доехать даём с запасом
	Map_CreateTrader(sld.cityShore, sld.quest.targetShore, sld.id, daysQty);
	//заносим Id кэпа в базу нпс-кэпов
	sTemp = sld.id;
	NullCharacter.capitainBase.(sTemp).quest = "Danielle"; //идентификатор квеста
	NullCharacter.capitainBase.(sTemp).questGiver = "none"; //запомним Id квестодателя для затирки в случае чего
	NullCharacter.capitainBase.(sTemp).Tilte1 = "MagicCity"; //заголовок квестбука
	NullCharacter.capitainBase.(sTemp).Tilte2 = "MagicCity"; //имя квеста в квестбуке
	NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
    NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
    NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
    NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
}

