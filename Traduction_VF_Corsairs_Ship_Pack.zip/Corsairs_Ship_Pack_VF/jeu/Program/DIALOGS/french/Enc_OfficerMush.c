void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ref    sld;
	string attr, attrLoc;
	int    iTemp, iTax, iFortValue;

    Pchar.quest.FreeRandomOfficerIdx = NPChar.index;

	switch(Dialog.CurrentNode)
	{
		case "CitizenNotBlade":
			dialog.text = "Capitaine, quelle sottise ! Rangez vos armes avant de provoquer des ennuis !";
			link.l1 = LinkRandPhrase("Bien.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			link.l1.go = "exit";
		break;

		//--> хорошист-саксонец
		case "Saxon":
			if (sti(PChar.reputation) > 60)//при низкой репутации - в сад
			{
				dialog.text = "Salutations, capitaine ! Je vous attends depuis toute la journée...";
				link.l1 = "Vous m'attendez ? Moi !? Je ne me souviens pas que nous nous connaissions.";
				link.l1.go = "Saxon_1";
			}
			else
			{
				dialog.text = ""+ GetSexPhrase("Sacré gaillard ! Regardez donc les flancs des navires, monsieur, et pas les décolletés des dames que vous croisez", "Madame ! Je vous prierais de ne pas essayer de flirter avec moi") +". Je suis peut-être à la retraite, mais l'ordre avant tout...";
				link.l1 = "Comme nous sommes délicats ! Passez votre chemin, vétéran.";
				link.l1.go = "exit";
				NextDiag.TempNode = "Saxon";
			}
		break;

		case "Saxon_1":
			dialog.text = "Il n'est jamais trop tard pour faire connaissance. Permettez-moi de me présenter : Magnus von Kokkai-Stade. J'ai servi différents rois et ducs aussi loin que je me souvienne. En Europe, je suis devenu lieutenant dans un régiment de mousquetaires payé par la Couronne espagnole... jusqu'à récemment.\nMais on a envoyé un neveu au gouverneur, que le diable l'emporte ! Ce jeune vaurien voulait un grade d'officier. Si bien que la garnison compte maintenant un Saxon de moins, mais un Espagnol de plus, ce qui n'est pas un échange équitable, si l'on tient compte de l'expérience, bien sמr !";
			link.l1 = "Très bien, monsieur. Mais vous n'avez toujours pas expliqué pourquoi vous m'attendiez ?";
			link.l1.go = "Saxon_2";
		break;

		case "Saxon_2":
			dialog.text = "Chaque matin, je viens au quai et je demande aux capitaines qui arrivent s'ils ont besoin d'un chef de compagnie d'abordage. D'anciens collègues vous ont recommandé comme un commandant très réputé, respecté, expérimenté et courageux"+ GetSexPhrase(".", ", bien que vous soyez une femme.") +" Je ne veux pas, dans la force de l'âge, servir sous les ordres d'un blanc-bec, ni finir dans une bande de brigands.";
			link.l1 = "Vous dites que vous étiez officier... ?";
			link.l1.go = "Saxon_3";
		break;

		case "Saxon_3":
			dialog.text = "Comment ça, « étais » ? Capitaine, je ne l'étais pas, je le suis. Me voici. Je suis officier, et je resterai officier. Si vous voulez de l'ordre et une épaule fidèle au combat, vous pouvez m'avoir, si nous nous entendons sur le prix. Je ne prendrai pas plus qu'il ne faut. Juste de quoi régler et solder mes dettes.";
			link.l1 = "Combien me coמteront à l'avenir votre œil fidèle, votre bras solide, votre épaule sמre et les autres qualités d'un fils des terres saxonnes ?";
			link.l1.go = "Saxon_4";
		break;

		case "Saxon_4":
			dialog.text = "Quarante mille de prime unique, et une petite solde par la suite. Je ne mendie pas d'argent en plus, je prendrai comme les autres, je mangerai à la marmite des officiers. Je vous demanderai des balles et de la poudre. Plus vous m'en fournirez, moins il y aura de raisons d'inquiétude et de déception, haha !";
			if(sti(Pchar.money) >= 40000)
			{
				link.l1 = "D'accord ! Voici votre argent ; réglez vos affaires et montez à bord, je vais faire préparer une chaloupe pour vous.";
				link.l1.go = "Saxon_check";
			}
			link.l2 = "Quelles exigences ! Ce fut un plaisir de vous rencontrer, herr officier, mais j'ai l'habitude de faire plus confiance à une bonne lame qu'au mousquet d'un autre dans mon dos.";
			link.l2.go = "exit";
			NextDiag.TempNode = "OnceAgain";
		break;

        case "OnceAgain":
            NextDiag.TempNode = "OnceAgain";
			dialog.text = "Quelle rencontre, capitaine ! Vous avez finalement décidé de renforcer votre équipage avec un brave mousquetaire ?";
			link.l1 = "Vous avez raison, herr officier, tout à fait raison. Rappelez-moi, à combien estimiez-vous vos services sur mon navire ?";
			link.l1.go = "Saxon_4";
            link.l2 = "Non, je n'ai pas décidé. Portez-vous bien, herr officier.";
			link.l2.go = "exit";
		break;

		case "Saxon_check":
            if (FindFreeRandomOfficer() == -1)//если перебор с офицерами
            {
                dialog.text = "Hum. Vous avez votre effectif complet d'officiers, capitaine. Revenez quand vous pourrez me donner un poste.";
    			link.l1 = "Bien.";
    			link.l1.go = "exit";
				NextDiag.TempNode = "OnceAgain";
    			break;
            }
			if (sti(PChar.reputation) <= 60)//повторная проверка репутации, для второго и далее заходов
			{
				dialog.text = "Hum... Vous savez, cap'taine, les gens ne disent pas du bien de vous. Je vous l'ai dit, je ne veux pas servir dans une bande de brigands !";
				link.l1 = "Comme nous sommes délicats ! Passez votre chemin, vétéran.";
				link.l1.go = "exit";
				NextDiag.TempNode = "OnceAgain";
			break;
			}
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 21 + MOD_SKILL_ENEMY_RATE*3)//при низком авторитете - в сад
			{
                dialog.text = "Hum. Rien de personnel, capitaine, mais même si l'on vous considère comme un héros, vos actes ne parlent pas encore beaucoup pour vous. Je veux être sמr de travailler pour une personne respectable. Je crois donc que j'attendrai avant de m'engager chez vous.";
    			link.l1 = "Eh bien, je ne fuis pas les difficultés, et je mange une canaille à chaque petit déjeuner. Vous entendrez bientכt parler de moi, n'en doutez pas. En attendant, portez-vous bien...";
    			link.l1.go = "exit";
				NextDiag.TempNode = "OnceAgain";
    			break;
            }
			dialog.text = "Parfait. Je jure de vous servir fidèlement. Vous ne regretterez pas l'argent dépensé pour moi.";
			link.l1 = "J'espère bien.";
			link.l1.go = "Exit_hire_Saxon";
		break;
		//<-- хорошист-саксонец

		//--> плохиш-пират
		case "Lostpirate":
			if (sti(PChar.reputation) < 40)//при повышенной репутации - в сад
			{
				dialog.text = "Salutations, cap'taine ! Quel bonheur de revoir des visages humains et d'entendre des voix vivantes, et non le vacarme dégoמtant de la gent ailée.";
				link.l1 = "Que faites-vous seul dans ce paradis isolé ? Vous étudiez les mœurs des oiseaux de mer ?";
				link.l1.go = "Lostpirate_1";
			}
			else
			{
				dialog.text = "Et vous avez de la chance, cap'taine ! J'ai failli vous tirer dessus en vous prenant pour mon brigand, hé hé";
				link.l1 = "On ne sait pas qui a eu le plus de chance. Vous auriez pu me manquer. Et moi qui voulais juste aider.";
				link.l1.go = "exit_Rep";
				link.l1 = "Vous auriez pu me manquer. Et je me demandais : je vous ai vu depuis le navire. Vous vivez en ermite ici ?";
				link.l1.go = "Lostpirate_1";
			}
		break;

		case "exit_Rep":
			NextDiag.TempNode = "Lostpirate";
			dialog.text = "Je ne manque jamais. Un coup, un cadavre. Et même deux, avec de la chance. Alors ne tentez plus le destin avec vos nobles intentions, le mousquet est chargé.";
			link.l1 = "Vous m'avez plu aussi, étranger. Et je crois que je vais suivre votre conseil.";
			link.l1.go = "exit";
		break;

		case "Lostpirate_1":
			dialog.text = "Vous n'avez pas deviné. Je suis plus poète que naturaliste. J'écris pour l'âme, et je me nourris de la chasse. Le doux murmure des muses divines s'entend clairement seul à seul avec la nature. En tant que poète, moi, Nicolas Rimalier, je suis peu connu. Pour l'instant. Mais je suis assez célèbre comme tireur d'élite. Créateur de blessures fatales et maestro des salves, pour ainsi dire. Qui a du talent en a pour tout.";
			link.l1 = "Hum, et comment un talent aussi multiple s'est-il retrouvé dans la baie d'une île déserte, sans navire, sans provisions et sans perspectives ?";
			link.l1.go = "Lostpirate_2";
		break;

		case "Lostpirate_2":
			dialog.text = "(chante) Il est dur de survivre en ce monde sans un mousquet fiable ; c'est peut-être plus facile ailleurs, mais pas ici, et pas pour un poète. Mon histoire peut paraître ridicule, mais tout est la faute d'un malheureux pari que j'ai fait, ma tête en jeu, avec le second. Il a eu la bêtise de m'accuser du retour bredouille de l'équipe de ravitaillement, parce que son tireur principal, rכle auquel j'étais affecté, ne saurait même pas toucher une carcasse de requin. Je dois avouer que je peux parfois me montrer trop aventureux. Cette fois, pour prouver mon adresse, je devais toucher une piastre lancée en l'air. Voulant se moquer de moi, le second m'a ordonné de tirer sans lâcher la pièce. Sa plaisanterie a mal tourné. La balle lui a arraché un doigt et lui a transpercé la main avec la pièce. Il s'avère que j'ai gagné le pari. Tout le monde l'a reconnu. C'est sans doute pour ça qu'on n'a guère mis d'ardeur à me rattraper, malgré les jurons terribles du second. Et tel que j'étais, une chanson dans l'âme et un mousquet en main, je me suis caché dans les fourrés. Le navire est parti, avec les provisions et les perspectives. Voilà toute l'histoire. Depuis longtemps, je vis donc en abattant des mouettes pour le petit déjeuner, le déjeuner et le dîner.";
			link.l1 = "Drכle d'histoire. Que comptez-vous faire maintenant ?";
			link.l1.go = "Lostpirate_check";
		break;

        case "OnceAgainLP":
            NextDiag.TempNode = "OnceAgainLP";
			dialog.text = "Alors, cap'taine, c'est mon talent de chanteur qui vous a séduit ? Ou mes armes à feu ? Je vous le dis, vous avez de la chance : je suis encore là !";
			link.l1 = "Vous êtes aussi un tricheur, à ce que je vois. Vous ne vouliez pas trouver une place sur un navire ?";
			link.l1.go = "Lostpirate_check";
            link.l2 = "C'est peut-être bien pour cette raison que l'équipage de mon navire ne s'est pas encore entretué. Quelqu'un croira peut-être vos histoires, mais aujourd'hui, je suis trop sobre pour ça.";
			link.l2.go = "exit";
		break;

		case "Lostpirate_check":
            if (FindFreeRandomOfficer() == -1)//если перебор с офицерами
            {
                dialog.text = "Hum. J'aimerais bien entrer à votre service... Mais je vois que vous avez votre effectif complet d'officiers, hélas. Et je n'ai pas l'intention de m'entasser au gaillard d'avant avec les matelots. Je vais donc devoir rester dans cette crique douillette.";
    			link.l1 = "Oui, je n'ai pas de poste vacant. Je repasserai peut-être plus tard.";
    			link.l1.go = "exit";
				NextDiag.TempNode = "OnceAgainLP";
    			break;
            }
			if (sti(PChar.reputation) >= 40)//повторная проверка репутации, для второго и далее заходов
			{
				if (!CheckAttribute(pchar, "RimalieDone"))
				{
					dialog.text = "Hum... Vous savez, cap'taine, vous ne me plaisez pas. Vous allez aussi me livrer aux autorités, et ce sera du joli... On peut s'attendre à tout de la part des saints. Je préfère rester ici, dans cette crique douillette.";
					link.l1 = "Bonne chance, œil-de-faucon ! Attention à ne pas retourner à l'état sauvage, ici...";
					link.l1.go = "exit";
					link.l2 = "Alors je vais abandonner tout de suite ? Un bon mousquetaire, ça se cherche, et vous en donnez bien l'impression.";
					link.l2.go = "LPGoodSide";
					NextDiag.TempNode = "OnceAgainLP";
				}
				else
				{
					dialog.text = "Puisque vous avez réussi à me réconcilier avec les contrebandiers, je ne ferai pas le difficile. 10 000 piastres, et je suis à vous.";
					if (sti(pchar.money)>= 10000)
					{
						link.l1 = "Voici votre argent. Et j'espère que vous tempérerez votre caractère querelleur.";
						link.l1.go = "Exit_hire_Lostpirate";
					}
					link.l2 = "Dès que j'aurai l'argent, tout de suite. Je l'ai un peu retardé.";
					link.l2.go = "exit";
				}
				break;
			}
			if (GetSummonSkillFromName(pchar, SKILL_FORTUNE) < 31)//при низком везении - в сад
			{
                dialog.text = "Sous les ordres d'un capitaine chanceux et facile à vivre, j'accepterais de continuer à courir les mers. Mais avec vous, on risque plutכt de récolter des coups de fouet que du courage.";
    			link.l1 = "Eh bien, si les muses ne vous attirent pas vers les lointains divins, ou si le diable ne vous emporte pas, nous nous reverrons. Très bientכt, je pense.";
    			link.l1.go = "exit";
				NextDiag.TempNode = "OnceAgainLP";
    			break;
            }
			dialog.text = "Prenez-moi comme tireur, vous ne le regretterez pas ! Je ferai même ma part pour le menu du jour : je vous donnerai tout le gibier, car rien n'est trop beau pour de vrais amis !";
			link.l1 = "Pourquoi pas ? J'espère que vous ne vous disputerez avec personne dans mon équipage.";
			link.l1.go = "Exit_hire_Lostpirate";
			link.l2 = "J'ai entendu votre histoire dans une autre version. Vous avez levé la main sur votre capitaine en faisant sauter sa lame d'un coup de feu, quand il a voulu vous arrêter pour tentative de mutinerie. J'aime les gars désespérés comme vous, mais je ne veux pas tester votre adresse au tir sur ma propre peau.";
			link.l2.go = "exit";
			NextDiag.TempNode = "OnceAgainLP";
		break;
		case "LPGoodSide":
			dialog.text = "Pour être honnête, j'en ai franchement assez de traîner ici. Réglez un problème et payez un petit supplément, et je pars avec vous.";
			link.l1 = "Et que voulez-vous ?";
			link.l1.go = "LPGoodSide_2";
		break;
		case "LPGoodSide_2":
			dialog.text = "Il y a longtemps que j'aurais pu regagner la civilisation, mais je me suis brouillé avec les gens d'ici. J'ai fait capoter une affaire avec les contrebandiers une fois : je voulais juste un repas normal et me procurer des balles et de la poudre. Et apparemment, ils ont graissé la patte au gouverneur d'ici, qui a donné l'ordre aux gardes. S'ils me voient, ils m'abattront sur place.";
			link.l1 = "Faire la paix avec les contrebandiers, alors ?";
			link.l1.go = "LPGoodSide_3";
		break;
		case "LPGoodSide_3":
			dialog.text = "Ce sont des gens susceptibles, ils vous retrouveraient sous terre. Jusqu'à présent, j'ai réussi à me cacher, mais je ne suis pas sמr que ça durera toujours. Je suppose qu'ils me retrouveraient même sur une autre île.";
			link.l1 = "Je vais essayer de faire quelque chose. Attendez mon retour.";
			link.l1.go = "LPGoodSide_4";
		break;
		case "LPGoodSide_4":
			dialog.text = "Eh bien, je vais essayer de vous faire confiance, et de ne pas vous loger par réflexe une balle dans le front à votre retour.";
			link.l1 = "Hé, si vous touchez la cible...";
			link.l1.go = "exit";
			pchar.RimalieGood = 1;
			NextDiag.TempNode = "OnceAgainLPGood";
			SetQuestHeader("Rimalie");
			AddQuestRecord("Rimalie", "1");
			AddQuestUserData("Rimalie", "sSex", GetSexPhrase("", "e"));
		break;
		case "OnceAgainLPGood":
			dialog.text = "Alors, oם en êtes-vous, capitaine ?";
			link.l1 = "Rien pour l'instant.";
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "RimalieDone"))
			{
				link.l1 = "Le problème est réglé. Vous pouvez rejoindre mon équipage. Au fait, combien vouliez-vous, déjà ?";
				link.l1.go = "Lostpirate_check";
				NextDiag.TempNode = "OnceAgainLP";
				AddQuestRecord("Rimalie", "3");
				CloseQuestHeader("Rimalie");
				pchar.questdata.Rimalie = 1;
			}
			else NextDiag.TempNode = "OnceAgainLPGood";
			pchar.questdata.Rimalie = 1;
		break;
		//<-- плохиш-пират

		//--> приказы
        case "hired":
			NextDiag.TempNode = "Hired";
			dialog.text = "Quels sont vos ordres ?";
			link.l2 = "Vous êtes renvoyée. Je me passerai de vos services !";
			link.l2.go = "AsYouWish";
            Link.l5 = "וcoute mon ordre !";
            Link.l5.go = "stay_follow";
			Link.l3 = "Je veux que vous gardiez une certaine distance avec la cible.";
			Link.l3.go = "TargetDistance";

			// по тёк локации определим можно ли тут приказать  -->
			if (IsEntity(loadedLocation))
            {
                if (CheckAttribute(loadedLocation, "fastreload"))
                {
                    iTemp = FindColony(loadedLocation.fastreload);
                    if (iTemp != -1)
                    {
                        sld = GetColonyByIndex(iTemp);
                        if (sti(sld.HeroOwn) == true && !CheckAttribute(sld, "OfficerIdx"))
                        {
							if(Locations[FindLocation(PChar.location)].islandId != "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
							{
								NPChar.ColonyIdx = iTemp;
								Link.l7 = "Je vous nomme gouverneur de cette ville !";
								Link.l7.go = "Gover_Hire";
							}
                        }
                    }
                }
            }
			if(PChar.ColonyBuilding.Stage != "0" && PChar.ColonyBuilding.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l8 = "Je veux vous nommer gouverneur de la colonie."" + PChar.ColonyBuilding.ColonyName + "", que nous avons bâtie sur l'île des Caïmans.";
						Link.l8.go = "ColonyBuilding_Hovernor_1";
					}
				}
			}

            link.l9 = "Rien. Repos.";
			link.l9.go = "exit";
        break;
		//<-- приказы


		//--> задать дистанцию стрельбы
		case "TargetDistance":
			dialog.text = "Laquelle exactement, capitaine ? Précisez-la en mètres, mais pas plus de 20.";
			link.l1 = "";
			Link.l1.edit = 3;
			link.l1.go = "TargetDistance_1";
		break;

		case "TargetDistance_1":
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp < 0)
			{
				dialog.text = "Capitaine, quel mauvais ton !";
				link.l1 = "Pardon, c'était une erreur...";
				link.l1.go = "exit";
				break;
			}
			if (iTemp == 0)
			{
				dialog.text = "Je resterai immobile, sans bouger. דa vous convient, capitaine ?";
				link.l1 = "Oui, c'est exactement ce qu'on attend de vous.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 0;
				break;
			}
			if (iTemp > 20)
			{
				dialog.text = "Je crois avoir dit que je ne peux pas rester à plus de 20 mètres de la cible.";
				link.l1 = "D'accord, gardez une distance de 20 mètres.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 20.0;
				break;
			}
			dialog.text = "Je comprends la mission, j'en prends note.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
			npchar.MusketerDistance = iTemp;
		break;
		//<-- задать дистанцию стрельбы

		//--> найм
        case "Exit_hire_Saxon":
			npchar.HalfImmortal = true;
			AddMoneyToCharacter(Pchar, -40000);
			npchar.MusketerDistance = 10;
			TakeNItems(npchar, "Mineral7", 1);
			TakeNItems(npchar, "indian17", 1);
			TakeNItems(npchar, "potionwine", 1);
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			npchar.Dialog.FileName = "Enc_Officer_dialog.c";
			NPChar.Dialog.TempNode = "hired";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Exit_hire_Lostpirate":
			if(CheckAttribute(pchar, "RimalieDone"))
			{
				AddMoneyToCharacter(pchar,-10000);
				npchar.reputation = 65;
				npchar.alignment = "good";
				DeleteAttribute(pchar,"RimalieDone");
			}
			pchar.questdata.Rimalie = 1;
			npchar.HalfImmortal = true;
			TakeNItems(pchar, "Mineral4", 5);
			Log_Info("Vous avez reçu des cormorans");
			PlaySound("interface\important_item.wav");
			npchar.MusketerDistance = 10;
			TakeNItems(npchar, "Mineral2", 1);
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			npchar.Dialog.FileName = "Enc_Officer_dialog.c";
			NPChar.Dialog.TempNode = "hired";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			locations[FindLocation("Shore59")].DisableEncounters = false; //энкаутеры в бухте откроем
			pchar.questdata.Rimalie = 1;
		break;
		//<-- найм

		//--> увольнение
		 case "AsYouWish":
			// проверка на море -->
			if (bSeaActive)
			{
				attr = Sea_FindNearColony();
				if (attr == "none")
				{
					dialog.text = "Capitaine, même si je ne comprends pas la raison d'une telle déclaration, revenons sur cette question à terre. Ou bien avez-vous décidé de me jeter tout simplement par-dessus bord ?";
					Link.l1 = "Hum... non, ce n'était pas mon intention. Restez jusqu'à ce que nous arrivions au port.";
					Link.l1.go = "Exit";
					break;
				}
			}
			// проверка на море <--
			dialog.text = "Comme vous voudrez, capitaine, c'est à vous de décider. Vous ne trouverez pas un second mousquetaire comme moi.";
			link.l1 = "Je crois que j'ai changé d'avis. J'ai encore besoin de vous.";
			link.l1.go = "exit";
			link.l2 = "Et tant mieux. Vous pouvez aller au diable.";
			link.l2.go = "Exit_Fire";
		break;

		case "exit_fire":
   			NextDiag.TempNode = "Fired";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Fired":
		      NextDiag.TempNode = "Fired";
		      dialog.text = "Je vous avais prévenu que je ne reviendrais pas sur votre navire. Je vais me faire engager par un autre capitaine.";
		      Link.l1 = "Je n'ai pas besoin de vous.";
		      Link.l1.go = "Exit";
	    break;
		//<-- увольнение

		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		//--> стоять-следовать
		case "stay_follow":
            dialog.Text = "Quels sont vos ordres ?";
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";
			if (!CheckAttribute(npchar, "AboardRestriction"))
			{
				Link.l4 = "Je vous demande de ne pas participer aux abordages. Prenez soin de vous.";
				Link.l4.go = "AboardRestriction";
			}
			else
			{
				Link.l4 = "J'ai changé d'avis, vous pouvez participer aux abordages.";
				Link.l4.go = "AboardAllowed";
			}
        break;

		case "AboardRestriction":
			npchar.AboardRestriction = true;
			dialog.text = "א vos ordres, capitaine. Je ne participerai pas aux abordages tant que vous ne me l'aurez pas de nouveau permis.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

		case "AboardAllowed":
			DeleteAttribute(npchar, "AboardRestriction");
			dialog.text = "א vos ordres, capitaine. Désormais, je participerai aux abordages.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

        case "Boal_Stay":
            Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
            AddDialogExitQuestFunction("LandEnc_OfficerStay");
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
            Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
        break;

        case "Boal_Follow":
            SetCharacterTask_FollowCharacter(Npchar, PChar);
            dialog.Text = "Il y a un changement de lieu !";
            Link.l1 = "Repos.";
            Link.l1.go = "Exit";
        break;
		//<-- стоять-следовать

		//////////////////////////////    офицер-наместник -->
		case "Gover_Hire":
            dialog.Text = "Ce serait un honneur !";
            Link.l1 = "Veillez à l'ordre et à la prospérité de la ville ; je viendrai de temps en temps percevoir le tribut.";
			Link.l1.go = "Exit_Gover_Hire";
            Link.l2 = "J'ai changé d'avis.";
            Link.l2.go = "Exit";
            NextDiag.TempNode = "Hired";
        break;

        case "Exit_Gover_Hire":
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            attr = sld.id + "_townhall";

            // снимем пассажира -->
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			// снимем пассажира <--
		    sld.OfficerIdx = sti(NPChar.index);
			ChangeCharacterAddressGroup(NPChar, attr, "sit", "sit1");
			LAi_SetHuberTypeNoGroup(NPChar);
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
            LAi_LoginInCaptureTown(NPChar, true);
			//  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_1");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
			NextDiag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Main":
            iTemp = GetNpcQuestPastDayParam(NPChar, "GoverTalkDate");
            if (iTemp > 0)
            {
				dialog.Text = "Quels sont vos ordres ? Votre dernière visite remonte à " + FindRussianDaysString(iTemp) + " déjà.";
			}
			else
			{
			    dialog.Text = "Quels sont vos ordres ?";
			}

            Link.l1 = "Combien d'impכts avez-vous perçus ?";
        	Link.l1.go = "Gover_Tax";
            Link.l8 = "On a besoin de vous sur le navire, je vous relève de vos fonctions en ville.";
            Link.l8.go = "Gover_Fire";
			Link.l9 = "Bonne journée.";
            Link.l9.go = "Exit";
            NextDiag.TempNode = "Gover_Main";
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
        break;

        case "Gover_Tax":
            iTemp = GetNpcQuestPastDayParam(NPChar, "StartTaxDate");
            iTax  = makeint((GetCharacterSkillSimple(NPChar, SKILL_COMMERCE) + GetCharacterSkillSimple(NPChar, SKILL_LEADERSHIP)) / 2);
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
			if (CheckAttribute(sld, "FortValue"))
			{
			    iFortValue = sti(sld.FortValue);
			}
			else
			{
			    iFortValue = 20;
			}
			NPChar.Gover_Tax_Sum = iFortValue*iTax*iTemp;
			dialog.Text = "Mes compétences me permettent de percevoir " + FindRussianMoneyString(iFortValue*iTax) + " par jour. En " + FindRussianDaysString(iTemp) + " j'ai perçu " + FindRussianMoneyString(sti(NPChar.Gover_Tax_Sum)) + ".";
			if (sti(NPChar.Gover_Tax_Sum) > 0)
			{
			    Link.l1 = "Je veux percevoir la totalité des impכts.";
            	Link.l1.go = "Gover_Tax_Get";
			}
			Link.l2 = "Merci pour vos services !";
            Link.l2.go = "Exit";
        break;

        case "Gover_Tax_Get":
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            AddMoneyToCharacter(Pchar, sti(NPChar.Gover_Tax_Sum));

			NextDiag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Fire":
            dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
            Link.l8 = "Voilà qui est bien.";
            Link.l8.go = "exit_hire";
            NextDiag.TempNode = "Hired";
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            DeleteAttribute(sld, "OfficerIdx");
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_2");
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
        break;
        //////////////////////////////    офицер-наместник <--

		//Указания для компаньона 19.02.08 -->
		case "Companion_Tasks":
			dialog.Text = "Je vous écoute attentivement.";
			Link.l1 = "Il s'agit de l'abordage.";
			Link.l1.go = "Companion_TaskBoarding";
			Link.l2 = "Il s'agit de votre navire.";
			Link.l2.go = "Companion_TaskChange";
			if(bBettaTestMode) // Только при бета-тесте
			{
			    Link.l3 = "Je veux que vous quittiez mon escadre pour un temps et que vous naviguiez par vos propres moyens.";
			    Link.l3.go = "CompanionTravel";
			}
			Link.l8 = "Rien pour l'instant.";
			Link.l8.go = "exit";
		break;

		case "Companion_TaskBoarding":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je veux que vous n'abordiez pas de navires. Prenez soin de vous et de votre équipage.";
			Link.l1.go = "Companion_TaskBoardingNo";
			Link.l2 = "J'ai besoin que vous abordiez les navires ennemis.";
			Link.l2.go = "Companion_TaskBoardingYes";
		break;

		case "Companion_TaskChange":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je ne veux pas que vous changiez de navire après un abordage. Il a trop de valeur.";
			Link.l1.go = "Companion_TaskChangeNo";
			Link.l2 = "Quand vous abordez vos ennemis, regardez s'il y a un bateau convenable, et prenez-le pour vous.";
			Link.l2.go = "Companion_TaskChangeYes";
		break;

		case "Companion_TaskBoardingNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = false;
		break;

		case "Companion_TaskBoardingYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = true;
		break;

		case "Companion_TaskChangeNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = false;
		break;

		case "Companion_TaskChangeYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = true;
		break;
		//<--
	}
}
