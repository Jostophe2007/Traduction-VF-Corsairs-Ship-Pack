// Gregg: Jule Gotie - quest "The Vanishing" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\disappearpeople.c
// Nodes 1-3 - the first visit, 4-7 - reading the tablet from the Inca temple.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Capitaine " + GetFullName(PChar) + " ? Qu'est-ce qui vous amène, cette fois ?";
			link.l1 = "Rien pour l'instant. Bonne journée.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Bonjour, capitaine ! Que puis-je faire pour vous ?";
			link.l1 = "Bonjour, monsieur Gotie. J'aimerais savoir ce que vous pensez de ces histoires de disparitions ? J'en sais moi-même quelque chose. Un homme m'a raconté qu'un certain capitaine pirate, Ben Gregori, avait trouvé un ancien trésor d'objets magiques : un coffret contenant trois vieilles pièces d'or et une petite fiole d'un liquide quelconque. Avec l'aide de quelqu'un, ce capitaine a réussi à lire l'inscription sur le couvercle et il s'est changé en momie, en squelette vivant. Que dites-vous de cette histoire ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Une histoire effroyable, capitaine. Je m'intéresse à l'ancienne culture indienne, et j'ai lu quelque chose de semblable dans de vieux livres. Cet homme devient plus fort en tuant des gens, n'est-ce pas ?";
			link.l1 = "Exactement, monsieur Gotie. Le navigateur du brick « Lucky Joker » a dit la même chose.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Le bien et le mal vivent cכte à cכte en ce monde. Là oם il y a un poison, il y a un antidote. Nous avons affaire à une ancienne malédiction inca : les pirates ont dמ trouver leur vieille cache. Voici ce que je vous dirai, capitaine : cherchez la vérité au temple abandonné qui se dresse quelque part sur le continent. Une visite là-bas vous aidera peut-être.";
			link.l1 = "Je comprends, monsieur Gotie, merci pour votre aide : je pars immédiatement.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleToTemple");
		break;

		case "4":
			TakeNItems(PChar, "DisappearPeople_Table", -1);
			dialog.text = "On dirait que c'est exactement ce qu'il nous fallait : il est question ici de trois anciennes pièces d'or !";
			link.l1 = "Oui, je le pense aussi. Le fait est que l'une d'elles est sur moi. Les deux autres, malheureusement, sont déjà à Ben Gregori.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Le capitaine Gregori doit absolument avoir la troisième pièce : sans elle, il ne peut pas quitter la grotte oם il a acquis son pouvoir magique. Ce n'est qu'en réunissant toutes les pièces qu'il pourra reprendre forme humaine sans perdre sa sorcellerie. Et il y a encore une chose importante : il ne peut être tué que par celui qui détient l'une des trois pièces d'or. Pour tous les autres, Gregori est immortel.";
			link.l1 = "Il s'ensuit donc qu'il est toujours dans la grotte de la Barbade ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Il s'ensuit, capitaine. S'il la quittait, il ne pourrait pas commettre tous ces méfaits dont nous sommes témoins. Et puis, il ne peut guère se promener dans les villes sous la forme d'une momie !";
			link.l1 = "Je pars immédiatement pour la Barbade : avec l'une de ces pièces, je peux le tuer.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Oui, c'est ainsi. Mais ce ne sera pas une mince affaire : il a déjà amassé un grand pouvoir.";
			link.l1 = "Adieu, monsieur Gotie, et souhaitez-moi bonne chance.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleToBarbados");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
