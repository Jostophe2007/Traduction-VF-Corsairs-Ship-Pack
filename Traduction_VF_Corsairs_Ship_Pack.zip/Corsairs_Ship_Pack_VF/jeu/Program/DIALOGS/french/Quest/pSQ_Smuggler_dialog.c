void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			if (Pchar.Location == Pchar.location.from_sea)
			{
				dialog.text = "Te voilà enfin. Je pensais que tu aurais la frousse. Personne ne t'a suivi ? C'est une affaire sérieuse.";
				link.l1 = "Personne ne m'a suivi. Et je n'ai rien à craindre : je ne vole pas des moutons, je fais affaire avec d'honnêtes contrebandiers. Ou bien non ?";
				link.l1.go = "pirateStartQuest_Smuggler3_1";
			}
			else
			{
				dialog.text = "Te voilà enfin. Seulement, je ne vois pas ton navire, "+ GetSexPhrase("l'ami", "ma petite") +". Oם est-ce qu'on met la marchandise ?";
				link.l1 = "C'est vrai, j'ai mouillé dans la mauvaise baie... J'arrive tout de suite !";
				link.l1.go = "exit";

			}
		break;
		case "pirateStartQuest_Smuggler3_1":
			dialog.text = "Héhé, bien dit. Bon, maintenant, dis-moi combien " + pchar.questTemp.pirateStartQuest.Name + " t'a payé pour trouver des esclaves.";
			link.l1 = "Bon, je t'avais prévenu que je n'avais pas le temps de jouer à vos petits jeux. Soit tu me vends des esclaves, soit j'irai en chercher ailleurs.";
			link.l1.go = "pirateStartQuest_Smuggler3_2";
		break;
		case "pirateStartQuest_Smuggler3_2":
			dialog.text = "Les esclaves sont dans cette cage, là-bas, regarde. Tout frais, pleins d'énergie. דa te va ?";
			if (sti(pchar.money) >= 15000)
			{
				link.l1 = "דa me va. Voici la moitié de la somme, vous aurez le reste après le chargement.";
				link.l1.go = "pirateStartQuest_Smuggler3_3";
			}
			link.l2 = "Pas si vite, l'ami : il me semble que cette marchandise vient de la goélette « Sentblue ». Dis-moi vite qui est l'informateur.";
			link.l2.go = "pirateStartQuest_Smuggler3_5";
			GiveItem2Character(npchar, "letter_open");
			ChangeItemDescribe("letter_open", "itmdescr_letter_open_pirateStartQuest");
			npchar.SaveItemsForDead  = true;
			npchar.DontClearDead = true;
			AddQuestRecord("pSQ", "5");
			AddQuestUserData("pSQ", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("pSQ", "sCity2", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City2 + "Gen"));
		break;
		case "pirateStartQuest_Smuggler3_3":
			dialog.text = "Les esclaves sont chargés. Réglons nos comptes, et filons avant que la patrouille nous tombe dessus.";
			link.l1 = "Pas si vite, l'ami : il me semble que cette marchandise vient de la goélette « Sentblue ». Si tu veux l'autre moitié, dis-moi qui est l'informateur.";
			link.l1.go = "pirateStartQuest_Smuggler3_5";
			AddMoneyToCharacter(pchar, -15000);
			AddMoneyToCharacter(npchar, 15000);
			AddCharacterGoods(pchar, GOOD_SLAVES, 100);
			AddQuestUserData("pSQ", "sText", "Mon employeur n'a pas besoin d'être au courant pour les esclaves.");
		break;
		case "pirateStartQuest_Smuggler3_5":
			dialog.text = "Bon sang ! Maintenant, tout est clair. Je vais devoir te secouer pour faire sortir l'argent, avec tes tripes et ta sale âme !";
			link.l1 = "Apparemment, vous n'êtes pas si sérieux que ça. Mais j'espère qu'au moins, vous n'êtes pas stupides, alors je vous propose une solution pacifique : vous me donnez le nom de l'informateur qui vous a livré la goélette et l'acheteur, et vous pourrez repartir d'ici vivants.";
			link.l1.go = "pirateStartQuest_Smuggler3_6";
		break;
		case "pirateStartQuest_Smuggler3_6":
			dialog.text = "C'est bien que tout ait tourné comme ça. L'endroit est retiré, tu n'aurais pas pu rêver d'une meilleure tombe, j'imagine. Quant à " + pchar.questTemp.pirateStartQuest.Name + ", qu'il aille se chercher d'autres espions.";
			link.l1 = "Oui, on dirait que je vais devoir te chatouiller le foie...";
			link.l1.go = "pirateStartQuest_Smuggler3_7";
		break;
		case "pirateStartQuest_Smuggler3_7":
			chrDisableReloadToLocation = true;
			RemoveGeometryFromLocation(pchar.questTemp.pirateStartQuest.Shore, "smg");

			for(i=1; i<=3; i++)
			{
				sld = CharacterFromID("psq2_" +i);
				LAi_SetImmortal(sld, false);
			}

			LAi_group_SetRelation("pirateStartQuest_Smuggler_group", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("pirateStartQuest_Smuggler_group", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("pirateStartQuest_Smuggler_group", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");

			pchar.quest.pirateStartQuest_Lether_fc.win_condition.l1 = "ExitFromLocation";
			pchar.quest.pirateStartQuest_Lether_fc.win_condition.l1.location = pchar.location;
			pchar.quest.pirateStartQuest_Lether_fc.function = "pirateStartQuest_Lether_fc";
		break;
	}
}





