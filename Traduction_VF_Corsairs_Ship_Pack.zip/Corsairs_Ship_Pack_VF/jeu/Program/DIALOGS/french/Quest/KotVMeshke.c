
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);						// 						АВТОРЫ И БЛАГОДАРНОСТИ
	makearef(Link, Dialog.Links);						// Идея квеста, диалоги и кодинг					- Sinistra
	makearef(NextDiag, NPChar.Dialog);					// Модель, текстура и анимация акулы				- IG Baron
														// Иконка кота										- Noctus
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "(appelant quelqu'un) Gatilio... Oם es-tu, mon ami ? Gatilio...";
			link.l1 = "Tu as perdu quelqu'un, petit ?";
			link.l1.go = "Знакомство_1";
		break;
		
		case "Знакомство_1":
			dialog.text = "Oh, pardonnez-moi, capitaine. Je ne vous avais pas remarqué. Je m'appelle Horatio, je suis pêcheur. J'habite ici, près du rivage, et je pêche toutes sortes de bêtes marines. C'est comme ça que je gagne ma vie.";
			link.l1 = "Je m'appelle " +GetFullName(pchar)+". Alors, que t'est-il arrivé ?";
			link.l1.go = "Знакомство_2";
		break;
		
		case "Знакомство_2":
			dialog.text = "Soit, je vais vous le raconter, "+pchar.name+". Une terrible tempête a éclaté tard hier soir. Et toutes mes affaires qui étaient sur le rivage ont été emportées en mer. Et voilà... Mon cher ami Gatilio aime beaucoup dormir dans mon coffre...";
			link.l1 = "Attends, QUOI !? Pourquoi le señor Gatilio est-il allé se mettre dans le coffre ?";
			link.l1.go = "Знакомство_3";
		break;
		
		case "Знакомство_3":
			dialog.text = "Parce que Gatilio avait très faim, et que je garde mon poisson dans le coffre.";
			link.l1 = "Mais si Gatilio était vraiment dans le coffre pendant la tempête, j'ai bien peur que le courant l'ait emporté et qu'il se soit noyé avec tes affaires. Il n'est plus en vie...";
			link.l1.go = "Знакомство_4";
		break;
		
		case "Знакомство_4":
			dialog.text = "Ce n'est pas vrai ! J'ai entendu un miaulement plaintif venant d'en face, il est sמrement vivant ! Je le sais !";
			link.l1 = "Alors ton Gatilio est un chat !? Pourquoi ne pas me l'avoir dit tout de suite ?";
			link.l1.go = "Знакомство_4_1";
			locCameraFromToPos(1.43, 5.67, -3.17, false, 56.59, 6.38, -11.15);
		break;
		
		case "Знакомство_4_1":
			DialogExit();
			npchar.dialog.filename = "Quest\KotVMeshke.c";
			npchar.dialog.currentnode = "Знакомство_5";
			LAi_SetActorType(npchar);
			LAi_ActorDialogDelay(npchar, pchar, "", 0.0);
		break;
		
		case "Знакомство_5":
			dialog.text = "Mais je l'ai dit. C'est mon ami. Comment n'avez-vous pas compris\nSi vous retrouvez mon coffre, vous pourrez tout garder en récompense. Le plus important, c'est que je veux retrouver mon cher ami Gatilio.";
			link.l1 = "D'accord, je vais chercher ton chat.";
			link.l1.go = "Согласие_1";
			link.l2 = "Il faut engager quelqu'un d'autre pour un travail aussi bizarre.";
			link.l2.go = "Отказ_1";
		break;
		
		case "Отказ_1":
			dialog.text = "Vous êtes un homme bien méchant, capitaine. Mais oui, vous avez raison, je ne vous confierais pas ce travail.";
			link.l1 = "א plus tard.";
			link.l1.go = "Отказ_2";
		break;
		
		case "Отказ_2":
			DialogExit();
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
			
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
		break;
		
		case "Согласие_1":
			dialog.text = "Merci, capitaine. Je vous attendrai avec mon Gatilio.";
			link.l1 = "Je reviens bientכt.";
			link.l1.go = "Согласие_2";
		break;
		
		case "Согласие_2":
			DialogExit();
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
			LAi_SetStayType(npchar);
			
			SetQuestHeader("CSP_KvM");
			AddQuestRecord("CSP_KvM", "1");
			AddQuestUserData("CSP_KvM", "sSex", GetSexPhrase("", "e"));
			
			sld = CharacterFromID("CSP_KvM_Ribak");
			sld.dialog.filename = "Quest\KotVMeshke.c";
			sld.dialog.currentnode = "ЕщёРаз_1";
			
			pchar.questTemp.CSP_KvM_PoiskGatilio = true;
			
			DeleteAttribute(&locations[FindLocation("SantoDomingo_town")], "private1.QuestClosed");
			
			PChar.quest.CSP_KvM_GatilioVSunduke.win_condition.l1 = "item";
			PChar.quest.CSP_KvM_GatilioVSunduke.win_condition.l1.item = "CSP_KvM_Gatilio";
			PChar.quest.CSP_KvM_GatilioVSunduke.win_condition = "CSP_KvM_GatilioVSunduke";
		break;
		
		case "ЕщёРаз_1":
			dialog.text = "Gatilio... Oם es-tu...";
			link.l1 = "Je vais retrouver ton chat, ne t'inquiète pas...";
			link.l1.go = "exit";
			NextDiag.TempNode = "ЕщёРаз_1";
		break;
		
		case "ВозвращаемГатилио_1":
			dialog.text = "Gatilio ! Je croyais que je ne te reverrais jamais... (il verse une larme) Gatilio...";
			link.l1 = "Je suis content que tout se soit bien terminé.";
			link.l1.go = "ВозвращаемГатилио_2";
			TakeItemFromCharacter(pchar, "CSP_KvM_Gatilio");
			Log_info("Vous avez ramené Gatilio");
		break;
		case "ВозвращаемГатилио_2":
			dialog.text = "Merci, capitaine "+GetFullName(pchar)+". Vous tenez parole. Je dirai à tout le monde quelle personne merveilleuse vous êtes.";
			link.l1 = "C'était vraiment un plaisir de t'aider, toi et ton chat. Adieu.";
			link.l1.go = "ВозвращаемГатилио_3";
		break;
		case "ВозвращаемГатилио_3":
			DialogExit();
			
			AddQuestRecord("CSP_KvM", "3");
			AddQuestUserData("CSP_KvM", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("CSP_KvM");
			pchar.questdata.KotVMeshke = 1;
			ChangeCharacterReputation(pchar, 2);
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Sailing", 150);
			InterfaceStates.Buttons.Save.enable = true;
			bDisableFastReload = false;
			DeleteAttribute(pchar, "questTemp.CSP_KvM_Akula");
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;
			AddSimpleRumour("On dit que vous avez sauvé un chat à Santo Domingo ! C'est incroyable !", SPAIN, 10, 1);
		break;
		
		
	}
}
