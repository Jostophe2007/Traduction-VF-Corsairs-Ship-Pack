// boal 08/04/06 общий диалог верфи
string sProf;
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
void ProcessDialogEvent()
{
	ref NPChar, sld, compref;
	aref Link, NextDiag;
	string sTemp;

	int iShipClass = GetCharacterShipClass(PChar); // Если корабля нет, вернёт 7 (лодка)
	int iRank = sti(PChar.rank);
	int iSumm;
	int comp;

	ref rRealShip;
	
	string attr;
	int amount;
	ref shTo;
	string s1;
	
	string sGood = "";
	aref aroot, arcur;
	int num, gooda, iGood, SG;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// вызов диалога по городам -->
	NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Shipyard\" + NPChar.City + "_Shipyard.c";
	if (!HasCityDialogFile("Shipyard", NPChar.City, "_Shipyard.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Shipyard\DefaultCity_Shipyard.c";
	if (LoadSegment(NPChar.FileDialog2))
	{
		ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Shipyard\DefaultCity_Shipyard.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
	// вызов диалога по городам <--
	if (NPChar.id != "Pirates_shipyarder") ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 16/06/06
	bool ok, ok1, ok2;
	int iTest = FindColony(NPChar.City); // город магазина
	ref rColony;
	string sFrom_sea = "";
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
		sFrom_sea = rColony.from_sea;
	}

	// генератор парусов по кейсу -->
	string attrLoc   = Dialog.CurrentNode;
	int i;
  	if (findsubstr(attrLoc, "SailsColorIdx_" , 0) != -1)
 	{
		i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.SailsColorIdx = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 		Dialog.CurrentNode = "SailsColorDone";
 	}
 	if (findsubstr(attrLoc, "SailsTypeChooseIDX_" , 0) != -1)
 	{
		i = findsubstr(attrLoc, "_" , 0);
	 	NPChar.SailsTypeChooseIDX = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 		Dialog.CurrentNode = "SailsTypeChoose2";
 	}
	if (findsubstr(attrLoc, "SailsTypeChoose_" , 0) != -1)
 	{
		i = findsubstr(attrLoc, "_" , 0);
	 	comp = strcut(attrLoc, i+1, strlen(attrLoc)-1); // индех в конце
 		Dialog.CurrentNode = "SailsTypeChoosen_selected";
 	}
	if(HasSubStr(attrLoc, "shiporderend2_"))
	{
		i = findsubstr(attrLoc, "_" , 0);

		sld = GetCharacter(sti(npchar.questTemp.NPCid));
		int iChar = GetPassenger(PChar, sti(strcut(attrLoc, i+1, strlen(attrLoc)-1))); //выбранный пассажир
		if (iChar == -1) compref = GetMainCharacter();	//пришёл нулевой пассажир, а это сам ГГ, но GetPassenger вернёт -1 в этом случае.
			else compref = GetCharacter(iChar);

		DeleteAttribute(compref, "ship");//зачем-то стираем корабль офицера, хотя его там и не должно быть
		compref.ship = "";

		aref	arTo, arFrom;
		makearef(arTo, compref.ship);
		makearef(arFrom, sld.Ship);
		CopyAttributes(arTo, arFrom);

		if (iChar != -1) 
		{
			CheckForReleaseOfficer(iChar);//увольнение офицера с должностей, если он не просто пассажир
			RemovePassenger(pchar, compref);
			SetCompanionIndex(pchar, -1, iChar);
			DelBakSkill(compref);
		}
		else pchar.location.from_sea = rColony.from_sea; 	//корабль берет ГГ и его в порт ставим

		int iClass = RealShips[sti(compref.Ship.Type)].Class;

		NPChar.reputation = sti(NPChar.reputation) + (8 - iClass);//минимальная репа ~12. две единицы репы ~ одна единица навыка корабела
		if (sti(NPChar.reputation)>100) NPChar.reputation = 100;
		WaitDate("",0,0,0, 0, 20);

		DeleteAttribute(npchar, "questTemp.ShipOrderDate");
		DeleteAttribute(npchar, "questTemp.ShipOrderTime");
		DeleteAttribute(npchar, "questTemp.NPCid");

		AddQuestRecordEx("ShipOrder", "ShipOrder", "End");
		pchar.ShipInOrder = sti(pchar.ShipInOrder) - 1;
		IncAndUnlock("AchShipOrder", 1);
		if (sti(pchar.ShipInOrder) < 1) CloseQuestHeader("ShipOrder");

		sld.id = "ShipOrder";//сбрасываем индекс к стандартному
		DeleteAttribute(sld, "ship");//затираем данные корабля
		sld.ship = "";
		LAi_SetCurHP(sld, 0.0);//ещё и убивать непися, чтоб точно очистился из массива?

		Dialog.CurrentNode = "exit";//закрываем диалог, ещё одно подтверждение уже не справшиваем
	}
 	// генератор парусов по кейсу <--
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ship_tunning_not_now":  // аналог выхода, со старых времён, много переделывать.
			LockControl("DlgDown3", false);
			LockControl("DlgUp3", false);
			DialogExit();
			NextDiag.CurrentNode = "Master_Ship";  // выход для тюнинга, нужно тут из-за LoadSegment
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		// Gregg: ==> "Two Sisters", chapter 10. Kendart's reward - a one-time fitting
		// of 42-pounder guns to a ship of second class or better.
		case "TwoSisters_1":
			if (GetCharacterShipClass(PChar) > 2)
			{
				dialog.text = "Vous ne caserez pas ça sur une baille comme la vכtre, la première bordée la mettrait en pièces. Revenez avec un navire de deuxième classe ou mieux.";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "J'en ai entendu parler. ...(il baisse la voix)... Ils sont dans mon hangar et ils attendent. On les installe ?";
				link.l1 = "Installez-les.";
				link.l1.go = "TwoSisters_2";
				link.l2 = "Je reviendrai plus tard.";
				link.l2.go = "exit";
			}
		break;

		case "TwoSisters_2":
			LAi_Fade("", "");
			dialog.text = "C'est fait, il est à vous. Ce qui ne tenait pas sur les sabords est parti dans la cale ; installez-les vous-même avec le bouton « tout installer ». Et attention : si vous démontez ces canons, vous ne pourrez pas les remettre, il n'y en a pas d'autres comme eux.";
			link.l1 = "Compris.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersSetCannons");
		break;
		// Gregg: <== "Two Sisters"

		case "First time":
			if (LAi_grp_playeralarm > 0)
			{
	   			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vais pas vous parler !", "Fuyez, "+ GetSexPhrase("l'ami", "ma petite") +" avant que les soldats ne vous transforment en passoire..."),
					LinkRandPhrase("Que voulez-vous, gredin ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin, sale pirate !", "Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + " ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + " et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			NextDiag.TempNode = "First time";

			//homo Линейка Блада
			if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
			{
				dialog.Text = LinkRandPhrase("Tiens, docteur Blood !" + TimeGreeting() + ".",
									"Ravie de vous voir, Peter Blood.",
									"C'est gentil d'être venu me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
				Link.l1 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l1.go = "exit";
				if(CheckAttribute(Pchar, "questTemp.CapBloodLine.ShipForJack") && Pchar.questTemp.CapBloodLine.ShipForJack == true)
				{
					Link.l2 = "Je dois aider un gars... un ami, je veux dire, à se rendre à Portobelo.";
					Link.l2.go = "Blood_Shipyard1";
				}
				break;
			}

			if(NPChar.quest.meeting == "0")
			{
				dialog.Text = TimeGreeting() + " ! Je suis "+ GetFullName(NPChar) + ", le propriétaire de ce chantier naval.";
				Link.l1 = "Ravi de vous rencontrer. Je suis le capitaine " + GetFullName(Pchar) + ".";
				Link.l1.go = "meeting";
				NPChar.quest.meeting = "1";
			}
			else
			{
				dialog.Text = pcharrepphrase("Oh, c'est encore vous ? Bah, l'argent n'a pas d'odeur.",
										TimeGreeting() + ". En quoi puis-je vous être utile, " + GetAddress_Form(NPChar) + " ?");
				Link.l1 = pcharrepphrase("C'est bien ça : je paie, vous travaillez.",
										"J'ai besoin des services du chantier naval.");
				Link.l1.go = "Shipyard";

				if (!CheckAttribute(npchar, "questTemp.ShipOrderTime"))
				{
				link.l14 = "Puis-je commander à votre chantier un navire qui corresponde à mes préférences personnelles ?";
				link.l14.go = "Shipyard1";
				}
				else
				{
				link.l14 = "Le navire que j'ai commandé est-il prêt ?";
				link.l14.go = "shiporder1";
				}
				if (sti(RealShips[sti(Pchar.Ship.Type)].class) < 7)
				{
					if ( NPChar.city == "Tortuga" || NPChar.city == "Villemstad" || NPChar.city == "PortRoyal" || NPChar.city == "Havana")
					{
						Link.l22 = "Et l'amélioration de mon navire ?";
						Link.l22.go = "ship_upgrades_start";
					}
				}
				
				if (GetNationRelation2MainCharacter(sti(NPChar.nation)) != RELATION_ENEMY || NPChar.city == "Caiman")
				{
					link.l11 = "J'ai besoin de canons pour mon navire.";
					link.l11.go = "Cannons";
				}
				link.l12 = "Je veux changer l'apparence de mon navire.";
				link.l12.go = "SailsGerald";
				// Gregg: "Two Sisters" - Kendart left a batch of 42-pounders with the shipwright.
				if (CheckAttribute(PChar, "TwoSisters.CanSetCannons"))
				{
					if (NPChar.city == "SanJuan")
					{
						link.l13 = "Kendart a parlé de certains canons de quarante-deux livres.";
						link.l13.go = "TwoSisters_1";
					}
				}
				//Jason --> генератор Призонер
				if (CheckAttribute(pchar, "GenQuest.Findship.Shipyarder") && NPChar.location == pchar.GenQuest.Findship.Shipyarder.City + "_shipyard")
				{
					ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
					if(sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
					{
						for(i = 1; i < COMPANION_MAX; i++)
						{
							int iTemp = GetCompanionIndex(PChar, i);
							if(iTemp > 0)
							{
								sld = GetCharacter(iTemp);
								NPchar.ShipCheck1 = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(RealShips[sti(sld.ship.type)].basetype), "Name")));
								NPchar.ShipCheck2 = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.Findship.Shipyarder.ShipType), "Name")));
								ok1 = (NPChar.ShipCheck1 == NPChar.ShipCheck2);
								ok2 = (sti(RealShips[sti(sld.ship.type)].basetype) == sti(pchar.GenQuest.Findship.Shipyarder.ShipType));
								if(GetRemovable(sld))
								{
									if (ok1 || ok2)
									{
										pchar.GenQuest.Findship.Shipyarder.CompanionIndex = sld.Index;
										pchar.GenQuest.Findship.Shipyarder.OK = 1;
										pchar.GenQuest.Findship.Shipyarder.ShipName = sld.Ship.Name;
										pchar.GenQuest.Findship.Shipyarder.Money = makeint(GetShipSellPrice(sld, CharacterFromID(NPChar.city + "_shipyarder"))*1.5);
									}
								}
							}
						}
					}
					if (CheckAttribute(pchar, "GenQuest.Findship.Shipyarder.OK") && sti(pchar.GenQuest.Findship.Shipyarder.OK) == 1)
					{
						link.l13 = "Je vous ai livré un navire de type "+GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.Findship.Shipyarder.ShipType), "Name")))+", comme vous l'aviez demandé.";
						link.l13.go = "Findship_check";
					}// <-- генератор Призонер
				}
				Link.l2 = "Je veux juste parler.";
				Link.l2.go = "quests"; //(перессылка в файл города)

				link.l15 = "Je voulais juste savoir si vous aviez du travail pour moi ?";
				link.l15.go = "AskQuest";

				// -->
				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l3 = "Je voulais vous parler de questions financières.";
					link.l3.go = "LoanForAll";
				}
  				if (CheckAttribute(pchar, "GenQuest.Intelligence") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "") //квест мэра - на связь с нашим шпионом
				{
					link.l7 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
						GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chez vous. Je dois récupérer quelque chose...");
					link.l7.go = "IntelligenceForAll";
				}
				//--> квест Аззи.
				if (CheckCharacterItem(pchar, "Azzy_bottle"))
				{
					link.l5 = "וcoutez, j'ai un objet, une boîte de fer-blanc. Il faut l'ouvrir avec précaution. Vous pouvez le faire ? Je paierai.";
					if (npchar.id == pchar.questTemp.Ascold.ShipyarderId)
					{
						link.l5.go = "AggryHelp";
						pchar.questTemp.Azzy = "Azzy_IHaveLamp";
					}
					else
					{
						link.l5.go = "AzzyTryTalk";
					}
				}
				//<-- на квест Аззи.
				//проверка выполнения квеста украсть чертёж на верфи
				if (CheckCharacterItem(pchar, "ShipyardsMap") && CheckAttribute(pchar, "questTemp.different.ShipyardsMap.Id") && pchar.questTemp.different.ShipyardsMap.Id == npchar.id)
				{
					link.l6 = "J'ai accompli votre mission. J'ai le plan provenant du chantier naval de " + XI_ConvertString("Colony" + pchar.questTemp.different.ShipyardsMap.city + "Gen") + ".";
					link.l6.go = "ShipyardsMapOk_1";
				}

				if(CheckAttribute(pchar, "GenQuest.EncGirl"))
				{
					if(pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "shipyard_keeper" && pchar.GenQuest.EncGirl.LoverCity == npchar.city)
					{
						link.l7 = "Bonjour, je viens à l'invitation de votre fils.";
						link.l7.go = "EncGirl_4";
						pchar.quest.EncGirl_GetLoverFather.over = "yes";
					}
					if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
					{
						if(pchar.GenQuest.EncGirl.Father == "shipyard_keeper" && npchar.city == pchar.GenQuest.EncGirl.city)
						{
							link.l8 = "C'est au sujet de votre fille...";
							link.l8.go = "EncGirl_1";
						}
					}
				}
				Link.l9 = "Je dois y aller.";
				Link.l9.go = "exit";
			}
		break;
		
		case "ship_upgrades_start":
			if (CheckAttribute(&RealShips[sti(Pchar.Ship.Type)],"Shipyarder"))
			{
				shTo = &RealShips[sti(pchar.Ship.Type)];
				if (sti(shTo.Shipyarder) != sti(NPChar.index))
				{
					dialog.Text = "Je ne peux rien faire pour votre navire.";
					Link.l1 = "Eh bien, si c'est non, c'est non. Au revoir !";
					Link.l1.go = "exit";
					break;
				}
			}
			if (CheckAttribute(&RealShips[sti(Pchar.Ship.Type)],"GoodsForUpgrade"))
			{
				dialog.Text = "Ah, encore vous. Voyons si vous avez apporté ce qu'il faut...";
				Link.l1 = "Alors, qu'est-ce que c'est ?";
				Link.l1.go = "ship_upgrades_2";
				if (bBettaTestMode)
				{
					Link.l2 = "LANCER L'AMוLIORATION";
					Link.l2.go = "ship_upgrades_do";
				}
			}
			else
			{
				NextDiag.CurrentNode = NextDiag.TempNode;
				DialogExit();
				LaunchShipUpgrades(npchar);
			}
		break;
		
		case "ship_upgrades_2":
			shTo = &RealShips[sti(pchar.Ship.Type)];
			sGood = "";
			makearef(aroot,shTo.GoodsForUpgrade);
			num = GetAttributesNum(aroot);
			gooda = 0;
			iGood = 0;
			SG = 0;
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				iGood = FindGood(sGood);
				gooda = sti(shTo.GoodsForUpgrade.(sGood));
				SG = GetSquadronGoods(pchar, iGood);
				if (gooda > 0 && SG > 0)
				{
					if (SG >= gooda)
					{
						RemoveCharacterGoods(pchar, iGood, gooda);
						shTo.GoodsForUpgrade.(sGood) = 0;
						log_info(XI_ConvertString(sGood)+" : livré en quantité de "+gooda+" sur "+gooda);
					}
					else 
					{
						RemoveCharacterGoods(pchar, iGood, SG);
						shTo.GoodsForUpgrade.(sGood) = sti(shTo.GoodsForUpgrade.(sGood))-SG;
						log_info(XI_ConvertString(sGood)+" : livré en quantité de "+SG+" sur "+gooda);
					}
				}
				else continue;
			}
			
			bool enough = true;				
			sGood = "";
			makearef(aroot,shTo.GoodsForUpgrade);
			num = GetAttributesNum(aroot);
			gooda = 0;
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				gooda = sti(shTo.GoodsForUpgrade.(sGood));
				if (gooda > 0)
				{
					enough = false;
				}
			}
			if (enough)
			{
				dialog.Text = "Toutes les marchandises sont là, faisons ces améliorations tout de suite.";
				Link.l1 = "Parfait, j'espère que ce ne sera pas long.";
				Link.l1.go = "ship_upgrades_do";
			}
			else 
			{
				dialog.Text = "D'après mes notes, il vous reste encore des marchandises à trouver. J'ai hâte de commencer.";
				Link.l1 = "Je fais au plus vite.";
				Link.l1.go = "ship_upgrades_exit";
			}
		break;
		
		case "ship_upgrades_do":
			shTo = &RealShips[sti(pchar.Ship.Type)];
			DeleteAttribute(shTo,"GoodsForUpgrade");
			makearef(aroot,shTo.UpgradePrepared);
			num = GetAttributesNum(aroot);
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				shTo.Upgrade.(sGood) = true;
				CheckForShipStatsChange(shTo,sGood); //чек на метод в шипсутилитах для обновления статов, пока пустышка
			}
			DeleteAttribute(shTo,"UpgradePrepared");
			DeleteAttribute(shTo,"Shipyarder");
			int uptime = num * (7-sti(shTo.class)+4);
			AddTimeToCurrent(uptime, 0);
			log_info("L'amélioration du navire est terminée.");
			log_info("Heures écoulées : "+uptime+".");
			dialog.Text = "...C'est fait, allez l'essayer. Mieux que neuf !";
			Link.l1 = "Merci pour votre travail. Au revoir !";
			Link.l1.go = "ship_upgrades_exit";
		break;
		
		case "ship_upgrades_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;


		case "AskQuest":
				//--->> квест украсть чертёж на верфи
				if (rand(1) && pchar.questTemp.different == "free" && GetNpcQuestPastDayWOInit(npchar, "questShipyardsMap") > 7 && !CheckAttribute(pchar, "questTemp.different.ShipyardsMap") && GetSummonSkillFromName(pchar, SKILL_SNEAK) > 25)
				{
					dialog.text = "וcoutez, j'ai une affaire importante pour vous. J'espère que vous pourrez m'aider...";
					link.l1 = "Voyons de quoi il s'agit.";
					link.l1.go = "ShipyardsMap_1";
					SaveCurrentNpcQuestDateParam(npchar, "questShipyardsMap");
					break;
				}

				/* автор - Jason (BlackMark Studio); перенос в CSP - Nathaniel ---------- */
				if (drand(4) == 2 && !CheckAttribute(pchar, "GenQuest.Findship.Shipyarder"))
				{
					if (!CheckAttribute(npchar, "Findship") || GetNpcQuestPastDayParam(npchar, "Findship") >= 20)
					{
						SelectFindship_ShipType(sti(npchar.nation)); //выбор типа корабля
						pchar.GenQuest.Findship.Shipyarder.ShipBaseName = GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.Findship.Shipyarder.ShipType), "Name") + ""));
						pchar.GenQuest.Findship.Shipyarder.City = npchar.city; //город квестодателя
						dialog.text = "Oui, j'ai un problème à régler. J'ai reçu une commande. Mon client a besoin au plus vite d'un navire de type " + pchar.GenQuest.Findship.Shipyarder.ShipBaseName + ". Mais je n'ai pas un tel navire au chantier en ce moment, et je n'ai pas non plus la possibilité d'en construire un en deux mois. \nSi vous pouviez me livrer un tel navire, je vous en serais très reconnaissant, et je vous paierais une fois et demie son prix de vente.";
						link.l1 = "Proposition intéressante !";
						link.l1.go = "Findship";
						link.l2 = "דa ne m'intéresse pas.";
						link.l2.go = "Findship_exit";
						SaveCurrentNpcQuestDateParam(npchar, "Findship");
						break;
					}
				}

				dialog.Text = "Eh bien, voilà qui nous surprend ! Tout le monde vient me demander de l'aide ici... Vous êtes sמr que votre navire n'a pas besoin de réparations ?";
				link.l1 = pcharrepphrase("C'est bien ça : je paie, vous travaillez.",
										"J'ai vraiment besoin des services du chantier naval.");
				link.l1.go = "Shipyard";
				link.l2	= "Pas cette fois, au revoir.";
				link.l2.go = "exit";
		break;

		case "Meeting":
				dialog.Text = "Eh bien, je suis ravi de rencontrer un nouveau client. Mon chantier est à votre service.";
				Link.l1 = "Parfait, " + GetFullName(NPChar) + ". Voyons ce que vous pouvez me proposer.";
				Link.l1.go = "Shipyard";

				link.l14 = "Puis-je commander à votre chantier un navire qui corresponde à mes préférences personnelles ?";
				link.l14.go = "Shipyard1";

				if (GetNationRelation2MainCharacter(sti(NPChar.nation)) != RELATION_ENEMY)
				{
					link.l13 = "J'ai besoin de canons pour mon navire.";
					link.l13.go = "Cannons";
				}
				link.l12 = "Je veux changer l'apparence de mon navire.";
				link.l12.go = "SailsGerald";
				Link.l2 = "Je veux juste parler.";
				link.l2.go = "quests";

				link.l15 = "Je voulais juste savoir si vous aviez du travail pour moi ? ";
				link.l15.go = "AskQuest";
				// -->
				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l3 = "Je voulais vous parler de questions financières.";
					link.l3.go = "LoanForAll";//(перессылка в файл города)
				}
  				if (CheckAttribute(pchar, "GenQuest.Intelligence") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "") //квест мэра - на связь с нашим шпионом
				{
					link.l7 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
						GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chez vous. Je dois récupérer quelque chose...");
					link.l7.go = "IntelligenceForAll";
				}
				//--> квест Аззи.
				if (CheckCharacterItem(pchar, "Azzy_bottle"))
				{
					link.l5 = "וcoutez, j'ai un objet, une boîte de fer-blanc. Il faut l'ouvrir avec précaution. Vous pouvez le faire ? Je paierai.";
					if (npchar.id == pchar.questTemp.Ascold.ShipyarderId)
					{
						link.l5.go = "AggryHelp";
						pchar.questTemp.Azzy = "Azzy_IHaveLamp";
					}
					else
					{
						link.l5.go = "AzzyTryTalk";
					}
				}
				//<-- на квест Аззи.
				if(CheckAttribute(pchar, "GenQuest.EncGirl"))
				{
					if(pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "shipyard_keeper" && pchar.GenQuest.EncGirl.LoverCity == npchar.city)
					{
						link.l8 = "Bonjour, je viens à l'invitation de votre fils.";
						link.l8.go = "EncGirl_4";
						pchar.quest.EncGirl_GetLoverFather.over = "yes";
					}
					if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
					{
						if(pchar.GenQuest.EncGirl.Father == "shipyard_keeper" && npchar.city == pchar.GenQuest.EncGirl.city)
						{
							link.l9 = "C'est au sujet de votre fille...";
							link.l9.go = "EncGirl_1";
						}
					}
				}
				if (CheckCharacterItem(pchar, "CaptainBook") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakShipyard"))
				{
					if(CheckAttribute(pchar, "questTemp.different.GiveShipLetters") && (pchar.questTemp.different.GiveShipLetters.city == npchar.city))
					{
						link.l10 = "Que pouvez-vous me dire du propriétaire de ces documents ?";
						link.l10.go = "ShipLetters_6";// генератор  "Found documents"
					}
				}
				Link.l11 = "Je dois y aller. Merci.";
				Link.l11.go = "exit";
		break;

		case "ShipLetters_6":
			pchar.questTemp.different.GiveShipLetters.speakShipyard = true;
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Voyons voir ! Non, je n'ai jamais eu ce client. Je pense que vous devriez aller voir le capitaine du port.";
				link.l1 = "Sans aucun doute....";
				link.l1.go = "exit";
			}
			else
			{
				sTemp = "Voyons voir, capitaine ! Oui ! Ce sont les documents de bord d'un bon ami à moi, on pourrait même dire de mon client préféré. Je suis sמr qu'il sera ravi de cette trouvaille, et qu'il vous versera même une prime.";
				sTemp = sTemp + "Je pense pouvoir vous proposer quelque chose comme " + sti(pchar.questTemp.different.GiveShipLetters.price2) + " pièces d'or en son nom";
				dialog.text = sTemp;
				link.l1	= "דa n'en vaut peut-être pas la peine...";
				link.l1.go = "exit";
				link.l2 = "Merci, " + GetFullName(NPChar) + " ! Transmettez mes salutations à votre ami.";
				link.l2.go = "ShipLetters_7";
			}
		break;

		case "ShipLetters_7":
			TakeItemFromCharacter(pchar, "CaptainBook");
			addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price2));
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "4");
			AddQuestUserData("GiveShipLetters", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Je vous ai ramené votre fugitive.";
			link.l1.go = "EncGirl_2";
		break;

		case "EncGirl_2":
			dialog.text = "Capitaine, merci beaucoup ! Comment va-t-elle ? Elle est en bonne santé, pas blessée ? דa fera bientכt un jour qu'elle s'est enfuie, la malheureuse. Est-ce que je lui veux du mal ? Je voulais la marier à un fiancé riche et jeune... Et s'il n'est pas beau, ce n'est pas la beauté qui fait le bonheur. Mais non ! Elle n'en fait qu'à sa tête, tout comme sa mère, que le... \nOh, elle ne serait même pas née si sa mère ne s'était pas enfuie à l'époque avec un benêt entreprenant... mais que voulez-vous... La jeunesse est naïve, sotte... et cruelle.";
			link.l1 = "Bien sמr, vous êtes son père et c'est à vous de décider, mais à votre place, je ne précipiterais pas le mariage...";
			link.l1.go = "EncGirl_3";
		break;

		case "EncGirl_3":
			dialog.text = "Qu'est-ce que vous y comprenez ? Vous avez des enfants ? Non ? Alors, quand vous en aurez, revenez me voir, et on en reparlera... \nOui... J'ai promis une récompense à qui me la ramènerait : veuillez l'accepter.";
			link.l1 = "Merci. Et tenez-la bien. Quelque chose me dit qu'elle ne s'arrêtera pas là.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("EncGirl_ToLoverParentsExit");
		break;

		case "EncGirl_4":
			if(sti(pchar.GenQuest.EncGirl.LoverFatherAngry) == 0)
			{
				dialog.text = "Ah, c'est donc vous "+ GetSexPhrase("le capitaine qui a ramené", "la fille qui a ramené") +" mon fils prodigue avec sa jeune fiancée ?";
				link.l1 = "Oui, je les ai aidés à s'enfuir.";
				link.l1.go = "EncGirl_5";
			}
			else
			{
				dialog.text = "Ah, vous voilà"+ GetSexPhrase(", mon bienfaiteur", ", ma bienfaitrice") +". Vous attendez une récompense ?";
				link.l1 = "Eh bien, pas forcément une récompense, mais un peu de gratitude ne ferait pas de mal.";
				link.l1.go = "EncGirl_6";
			}
		break;

		case "EncGirl_5":
			dialog.text = "Je vous suis très reconnaissant de ne pas avoir abandonné mon enfant dans l'embarras et de l'avoir aidé à se tirer avec honneur d'une situation aussi délicate. Permettez-moi de vous remercier comme je le peux. Acceptez cette modeste somme et un cadeau de ma part.";
			link.l1 = "Merci, ce fut un plaisir d'aider ces jeunes gens.";
			link.l1.go = "EncGirl_5_1";
		break;

		case "EncGirl_6":
			dialog.text = "Quelle gratitude ?! De la gratitude pour quoi ?! Non seulement ce benêt traîne sans travail depuis six mois, mais en plus il a trouvé le temps de s'amouracher ! Moi, à son âge, je dirigeais déjà ma propre affaire. Et voyez-moi ça, il est parti à la chasse ! Le gouverneur a une fille à marier, et celui-ci nous ramène une traînée sans feu ni lieu, Dieu me pardonne, et il demande la bénédiction paternelle !";
			link.l1 = "Hum, vous ne croyez donc pas aux sentiments sincères ?";
			link.l1.go = "EncGirl_6_1";
		break;

		case "EncGirl_5_1":
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.EncGirl.sum));
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "18");
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_6_1":
			dialog.text = "De quels sentiments parlez-vous ?! Quels sentiments ? Un adulte, une personne comme il faut, et puis voilà... Des sentiments ! Vous devriez avoir honte, vous les jeunes, de vous livrer à de telles choses, et de jouer les entremetteurs. La fille a été arrachée au nid de ses parents et la vie de mon nigaud est ruinée. Vous n'aurez aucune gratitude de ma part. Au revoir.";
			link.l1 = "Eh bien, portez-vous bien, vous aussi...";
			link.l1.go = "EncGirl_6_2";
		break;

		case "EncGirl_6_2":
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("JungleGirl", "19");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		/* Nathaniel (12.03.21): генераторный квест "Ship Search" */
		case "Findship_exit":
			DialogExit();
			DeleteAttribute(pchar, "GenQuest.Findship.Shipyarder");
		break;
		/* -------------------------------------------------------- */

		case "Findship":
			pchar.GenQuest.Findship.Shipyarder = "begin";
			pchar.GenQuest.Findship.Shipyarder.Name = GetFullName(npchar);
			pchar.GenQuest.Findship.Shipyarder.City = npchar.city;
			ReOpenQuestHeader("Findship");
			AddQuestRecord("Findship", "1");
			AddQuestUserData("Findship", "sCity", XI_ConvertString("Colony"+pchar.GenQuest.Findship.Shipyarder.City+"Gen"));
			AddQuestUserData("Findship", "sName", pchar.GenQuest.Findship.Shipyarder.Name);
			AddQuestUserData("Findship", "sShip", pchar.GenQuest.Findship.Shipyarder.ShipBaseName);
			SetFunctionTimerCondition("Findship_Over", 0, 0, 60, false);
			DialogExit();
		break;

		case "Findship_check":
			dialog.text = "Parfait ! Je suis heureux que vous ayez accompli cette mission si vite. Oם est ce navire ?";
			link.l1 = "En ce moment, le navire de type " + pchar.GenQuest.Findship.Shipyarder.ShipBaseName + " ''" + pchar.GenQuest.Findship.Shipyarder.ShipName + " '' mouille en rade. Vous pouvez commencer l'inspection...";
			link.l1.go = "Findship_complete";
		break;

		case "Findship_complete":
			pchar.quest.Findship_Over.over = "yes";//снять прерывание
			sld = GetCharacter(sti(pchar.GenQuest.Findship.Shipyarder.CompanionIndex));

			SetCrewQuantityOverMax(Pchar, GetCrewQuantity(Pchar) + GetCrewQuantity(sld));//добавляем число матросов с отдаваемого корабя на корабль ГГ сверх лимита

			RemoveCharacterCompanion(PChar, sld);//удаляем корабль вместе с матросами
			AddPassenger(pchar, sld, false);
			AddTroopersCrewToOther(Pchar);//делим сверхлимитных матросов с корабля ГГ по эскадре
			dialog.text = "Voici votre argent, " + GetAddress_Form(npchar) + ". Votre rémunération s'élève à " + FindRussianMoneyString(sti(pchar.GenQuest.Findship.Shipyarder.Money)) + ". Je vous remercie sincèrement pour le travail accompli. N'oubliez pas de repasser me voir. Au revoir !";
			link.l1 = "Bonne journée, " + GetAddress_FormToNPC(npchar) + " " + npchar.lastname + ".";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.Findship.Shipyarder.Money));
			AddQuestRecord("Findship", "3");
			AddQuestUserData("Findship", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.Findship.Shipyarder.Money)));
			CloseQuestHeader("Findship");
			DeleteAttribute(pchar, "GenQuest.Findship.Shipyarder");
		break;
		//<-- генератор Поиск корабля

		case "shipyard":
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
			if (sti(Pchar.Ship.Type) == SHIP_NOTUSED || ok)
			{
				NextDiag.CurrentNode = NextDiag.TempNode;
				DialogExit();
				LaunchShipyard(npchar);
			}
			else
			{
				dialog.text = NPCharRepPhrase(npchar, pcharrepphrase("Vous vous moquez de moi ? Et oם est votre navire ? Il n'est pas au quai !",
																	 "Par le diable, on ne me la fait pas ! Votre navire n'est pas au quai !"),
													  pcharrepphrase("Je ne vois pas votre navire au port, capitaine " +GetFullName(pchar)+ ". J'espère que ce n'est pas le Hollandais volant ?",
																	 "Capitaine, il est plus commode de réparer le navire au bassin. Amarrez le navire et revenez."));
				link.l1 = NPCharRepPhrase(npchar, pcharrepphrase("" +RandSwear()+"Quelle plaie !!! D'accord, vieille fouine, à plus tard !",
																 "Je ne voulais pas vous tromper, " +GetFullName(npchar)+ ", mon navire est de l'autre cכté de l'île."),
												  pcharrepphrase("Non, mon navire s'appelle le Black Pearl... Je vous ai fait peur ! Ha, je plaisante !",
																 "Merci du conseil, je ne manquerai pas de le suivre."));
				link.l1.go = "exit";
			}
		break;

		case "shiporderend":
			bool ok_ship = (sFrom_sea == "") || (Pchar.location.from_sea == sFrom_sea);
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok_ship)
			{
				if (GetCompanionQuantity(pchar) < COMPANION_MAX)
				{
					dialog.Text = "א lequel de vos officiers dois-je le confier ?";
					int _curCharIdx;
					int q = 0;
					int nListSize = GetPassengersQuantity(pchar);
					for(i=0; i<nListSize; i++)
						{
						_curCharIdx = GetPassenger(pchar,i);
						sld = GetCharacter(_curCharIdx);
							if (_curCharIdx!=-1)
							{
								ok = CheckAttribute(&characters[_curCharIdx], "prisoned") && sti(characters[_curCharIdx].prisoned) == true;
								if (!CheckAttribute(sld,"HPminusDaysNeedtoRestore"))
								{
									if (!ok && GetRemovable(&characters[_curCharIdx]))
									{
										attrLoc = "l"+i;
										sProf = "";
										if (IsOfficer(sld)) sProf += "(abordeur)";
										if (sti(pchar.Fellows.Passengers.navigator) == sti(sld.index)) sProf += "(navigateur)";
										if (sti(pchar.Fellows.Passengers.boatswain) == sti(sld.index)) sProf += "(maître d'équipage)";
										if (sti(pchar.Fellows.Passengers.cannoner) == sti(sld.index)) sProf += "(canonnier)";
										if (sti(pchar.Fellows.Passengers.doctor) == sti(sld.index)) sProf += "(médecin)";
										if (sti(pchar.Fellows.Passengers.carpenter) == sti(sld.index)) sProf += "(charpentier)";
									    if (sti(pchar.Fellows.Passengers.treasurer) == sti(sld.index)) sProf += " (trésorier)";
										Link.(attrLoc)	= GetFullName(&characters[_curCharIdx]) + sProf;
										Link.(attrLoc).go = "shiporderend2_" + i;
										q++;
									}
								}
							}
						}
					attrLoc = "l"+nListSize;
					if (q == 0)
						{
						Link.(attrLoc) = RandSwear() + "J'ai oublié d'amener un capitaine pour ce navire.";
						Link.(attrLoc).go = "exit";
						}
					else
						{
						Link.(attrLoc) = "Non, j'ai changé d'avis.";
						Link.(attrLoc).go = "exit";
						}
				}
				else
				{
					dialog.text = "Votre escadre est trop grande. Il n'y a plus assez de place dans la rade pour vos navires.";
					Link.l99 = "Oui, c'est vrai. Je le récupérerai une autre fois.";
					Link.l99.go = "exit";
				}
			}
			else			
			{
				dialog.text = "Hum... Je ne vois pas votre navire amiral au port. Et vous ne pouvez récupérer votre navire qu'ici.";
				if (sti(Pchar.Ship.Type) == SHIP_NOTUSED)	//фикс - забираем себе, если нет корабля
				{
					Link.l99	= "Oui, je suis justement sans navire, je vais donc le récupérer moi-même.";
					Link.l99.go = "shiporderend2_-1";
				}
				else
				{
					Link.l99 = "Oui, vous avez raison. Je l'avais oublié.";
					Link.l99.go = "exit";
				}
			}
		break;

		case "shiporder1":
			if (CheckAttribute(npchar, "questTemp.chest"))
			{
				dialog.Text = "Les travaux avancent. Avez-vous apporté les matériaux que je vous ai demandés ?";
				if (checkOrderMatherial(NPChar))
				{
					Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
					Link.l1.go = "shiporder2";
				}
				link.l2 = "Les circonstances ont changé, je veux annuler la commande.";
				link.l2.go = "shipordercancel";
				link.l3 = "Non. Je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
				int timeleft = sti(npchar.questTemp.ShipOrderTime) - GetNpcQuestPastDayParam(npchar, "questTemp.ShipOrderDate");
				string sAdd = "";
				switch (timeleft)
				{
				case 1: sAdd = " Il sera prêt demain !"; break;
				case 2: sAdd = " Il sera prêt après-demain !"; break;
				}
				if (timeleft < 1)
				{//готов
				dialog.text = "Capitaine" +GetFullName(pchar)+ " ! Le navire est prêt et, par le diable, vous ne serez pas déçu. Tout correspond strictement à vos souhaits.";
				link.l1 = "דa fait plaisir à entendre. Puis-je le récupérer ?";
				link.l1.go = "shiporderend";
				}
				else
				{//не готов
				dialog.text = "Ne vous inquiétez pas ! Les travaux suivent strictement le plan prévu, " + sAdd;
				link.l1 = "Je vois. Je reviendrai plus tard.";
				link.l1.go = "exit";
				link.l2 = "Les circonstances ont changé, je veux annuler la commande.";
				link.l2.go = "shipordercancel";
				}
			}
		break;

		case "shiporder2":
			string sTemp2 = GiveOrderMatherial(NPChar);
			if (sTemp2 == "")
			{
				DeleteAttribute(npchar,"questTemp.chest");//Всё доставили
				AddQuestRecordEx("ShipOrder", "ShipOrder", "t3");
				AddQuestUserData("ShipOrder", "cityName3", XI_ConvertString("Colony" + npchar.city + "Gen"));
				dialog.Text = "Très bien. Le compte y est. Il ne faut rien de plus.";
				Link.l1 = "Parfait, quand le navire sera-t-il prêt ?";
				Link.l1.go = "shiporder1";
				link.l2 = "Les circonstances ont changé, je veux annuler la commande.";
				link.l2.go = "shipordercancel";
			}
			else
			{
				dialog.Text = "Il vous faut encore livrer... euh... je vais consulter mes notes... Voilà : " + sTemp2;
				AddQuestRecordEx("ShipOrder", "ShipOrder", "t2");
				AddQuestUserData("ShipOrder", "cityName2", XI_ConvertString("Colony" + npchar.city + "Gen"));
				AddQuestUserData("ShipOrder", "TuningMaterial2", sTemp2);
				Link.l1 = "Tout est clair. Je reviendrai quand j'aurai le reste.";
				Link.l1.go = "exit";
				link.l2 = "Les circonstances ont changé, je veux annuler la commande.";
				link.l2.go = "shipordercancel";
			}
		break;

		case "shipordercancel2":
			AddQuestRecordEx("ShipOrder", "ShipOrder", "Lose");
			AddQuestUserData("ShipOrder", "sSex", GetSexPhrase("", "e"));
			pchar.ShipInOrder = sti(pchar.ShipInOrder) - 1;
			if (sti(pchar.ShipInOrder) < 1) CloseQuestHeader("ShipOrder");

			sld = GetCharacter(sti(npchar.questTemp.NPCid));
			DeleteAttribute(npchar, "questTemp.ShipOrderDate");
			DeleteAttribute(npchar, "questTemp.ShipOrderTime");
			DeleteAttribute(npchar, "questTemp.NPCid");
			sld.id = "ShipOrder";//сбрасываем индекс к стандартному, чтобы этот номер массива в следующий раз можно было занять
			DeleteAttribute(npchar, "questTemp.chest"));//фикс - стирание необходимости доставки материала
			DeleteAttribute(sld, "ship");//затираем данные корабля
			DeleteAttribute(npchar, "questTemp.chest"));//убираем необходимость доставки материалов
			sld.ship = "";
			LAi_SetCurHP(sld, 0.0);//ещё и убивать непися, чтоб точно очистился из массива?

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "shipordercancel":
			dialog.text = "Attendez, capitaine ! Nous avons fixé les conditions. Nous pouvons rompre cet accord, mais je ne pourrai pas vous rendre l'argent. Tout a déjà été dépensé en matériaux et en salaires. ";
			link.l1 = "Je m'en souviens, mais les circonstances sont ainsi faites. Je ne peux pas attendre que ce navire soit terminé.";
			link.l1.go = "shipordercancel2";
			link.l2 = "Vous avez raison, je préfère attendre que le navire commandé soit prêt.";
			link.l2.go = "exit";
		break;

		case "shipyard1":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchShipyard1(npchar);
		break;

		case "Cannons":
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				NextDiag.CurrentNode = NextDiag.TempNode;
				DialogExit();
				LaunchCannons(sti(rColony.StoreNum));
			}
			else
			{
				dialog.text = NPCharRepPhrase(npchar, pcharrepphrase("Vous vous moquez de moi ? Et oם est votre navire ? Il n'est pas au quai !",
																	 "Par le diable, on ne me la fait pas ! Votre navire n'est pas au quai !"),
													  pcharrepphrase("Je ne vois pas votre navire au port, capitaine " +GetFullName(pchar)+ ". J'espère que ce n'est pas le Hollandais volant ?",
																	 "Capitaine, il est plus commode de réparer le navire au bassin. Amarrez le navire et revenez."));
				link.l1 = NPCharRepPhrase(npchar, pcharrepphrase("" +RandSwear()+"Quelle plaie !!! D'accord, vieille fouine, à plus tard !",
																 "Je ne voulais pas vous tromper, " +GetFullName(npchar)+ ", mon navire est de l'autre cכté de l'île."),
												  pcharrepphrase("Non, mon navire s'appelle le Black Pearl... Je vous ai fait peur ! Ha, je plaisante !",
																 "Merci du conseil, je ne manquerai pas de le suivre."));
				link.l1.go = "exit";
			}
		break;

		case "SailsGerald":
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
			if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
			{
				/*NextDiag.CurrentNode = NextDiag.TempNode;
				DialogExit();
				npchar.sailsgerald = "gerald";
				LaunchSailsGeraldScreen(npchar);*/
				dialog.text = "Sur quel navire ?";
				Link.l1 = "Le navire amiral.";
				Link.l1.go = "SailsTypeChoose_"+1;
				for(int z = 1; z < COMPANION_MAX; z++)
				{
					int cnn = GetCompanionIndex(pchar, z);
					if(cnn != -1)
					{
						string ln = "l"+(z+1);
						Link.(ln) = "Le navire ''"+characters[cnn].ship.name+"''";
						Link.(ln).go = "SailsTypeChoose_"+(z+1);
					}
				}
				Link.l9 = "Non, j'ai changé d'avis.";
				Link.l9.go = "exit";
				break;
				dialog.text = "Changer la couleur des voiles coמtera " +
							  FindRussianMoneyString(GetSailsTuningPrice(Pchar, npchar, SAILSCOLOR_PRICE_RATE))+
							  "Poser de nouvelles armoiries coמtera " +
							  FindRussianMoneyString(GetSailsTuningPrice(Pchar, npchar, SAILSGERALD_PRICE_RATE)) +
							  ", le prix du changement de toile dépend du matériau.";

				link.l1 = "Choisir une nouvelle couleur.";
				link.l1.go = "SailsColorChoose";
				link.l2 = "Peindre de nouvelles armoiries.";
				link.l2.go = "SailsGeraldChoose";

				// Паруса ЛГ
				if(!CheckForFlyingDuchmanSails(PChar))
				{
					link.l3 = "Changer le matériau des voiles."; // Материал изменить нельзя, если стоят паруса ЛГ
					link.l3.go = "SailsTypeChoose";
					link.l4 = "Je veux des voiles terrifiantes, comme celles du légendaire vaisseau fantכme !";
					link.l4.go = "FlyingDutchmanSails";
				}
				else
				{
					link.l4 = "Je veux retirer les voiles terrifiantes.";
					link.l4.go = "FlyingDutchmanSails_Clear";
				}

				Link.l9 = "J'ai changé d'avis.";
				Link.l9.go = "exit";
			}
			else
			{
				dialog.text = NPCharRepPhrase(npchar, pcharrepphrase("Vous vous moquez de moi ? Et oם est votre navire ? Il n'est pas au quai !",
																	 "Par le diable, on ne me la fait pas ! Votre navire n'est pas au quai !"),
													  pcharrepphrase("Je ne vois pas votre navire au port, capitaine " +GetFullName(pchar)+ ". J'espère que ce n'est pas le Hollandais volant ?",
																	 "Capitaine, il est plus commode de charger et de réparer le navire au bassin. Amarrez le navire et revenez."));
				link.l1 = NPCharRepPhrase(npchar, pcharrepphrase("" +RandSwear()+"Quelle plaie !!! D'accord, vieille fouine, à plus tard !",
																 "Je ne voulais pas vous tromper, " +GetFullName(npchar)+ ", mon navire est de l'autre cכté de l'île."),
												  pcharrepphrase("Non, mon navire s'appelle le Black Pearl... Je vous ai fait peur ! Ha, je plaisante !",
																 "Merci du conseil, je ne manquerai pas de le suivre."));
				link.l1.go = "exit";
			}
		break;

		// Warship 16.06.09 Паруса ЛГ
		case "FlyingDutchmanSails":
			if(iShipClass < 4)
			{
				iSumm = (10 / iShipClass) * iRank * MOD_SKILL_ENEMY_RATE*3 * 10; // Цена за установку парусов
				dialog.text = "Je viens d'inventer une géométrie de voile intéressante : elle ressemble à une voile en lambeaux, pour que les boulets ramés et les boulets fassent moins de dégâts. D'ailleurs, on peut la coudre dans un tissu non tissé. Je pense qu'un tel jeu de voiles vous coמtera, pour votre navire, " + FindRussianMoneyString(iSumm) + ".";

				if(sti(PChar.money) >= iSumm)
				{
					Link.l1 = "Parfait ! דa me convient.";
					Link.l1.go = "FlyingDutchmanSails_SetDuchman";
				}

				Link.l2 = "Quel prix absurde ! N'y pensez plus.";
				Link.l2.go = "exit";
			}
			else
			{
				dialog.text = "De telles voiles auraient l'air ridicules sur votre navire. Trouvez-vous un navire plus imposant...";
				Link.l1 = "Je vais chercher ailleurs...";
				Link.l1.go = "exit";
			}
		break;

		case "FlyingDutchmanSails_SetDuchman":
			iSumm = (10 / iShipClass) * iRank * MOD_SKILL_ENEMY_RATE*3 * 10; // Цена за установку парусов

			AddMoneyToCharacter(PChar, -iSumm);

			dialog.text = "Parfait. Nous ferons tout pour le mieux.";
			Link.l1 = "Merci.";
			Link.l1.go = "exit";

			SetShipSailsFromFile(PChar, "ships/parus_common_torn.dds"); // Паруса ЛГ

			WaitDate("", 0, 0, 0, 0, 10);
		break;

		// Убрать паруса ЛГ
		case "FlyingDutchmanSails_Clear":
			iSumm = (10 / iShipClass) * iRank * MOD_SKILL_ENEMY_RATE*3 * 10; // Цена за установку парусов

			dialog.text = "Bon, s'il faut les retirer, on les retire. Cela vous coמtera " + FindRussianMoneyString(iSumm) + ".";

			if(sti(PChar.money) >= iSumm)
			{
				Link.l1 = "Parfait ! דa me convient.";
				Link.l1.go = "FlyingDutchmanSails_SetNormal";
			}

			Link.l2 = "Quel prix absurde ! N'y pensez plus.";
			Link.l2.go = "exit";
		break;

		case "FlyingDutchmanSails_SetNormal":
			rRealShip = GetRealShip(sti(PChar.Ship.Type));

			iSumm = (10 / iShipClass) * iRank * MOD_SKILL_ENEMY_RATE*3 * 10; // Цена за установку парусов

			AddMoneyToCharacter(PChar, -iSumm);

			dialog.text = "Parfait. Nous ferons tout pour le mieux.";
			Link.l1 = "Merci.";
			Link.l1.go = "exit";

			DeleteAttribute(rRealShip, "EmblemedSails.normalTex")

			WaitDate("", 0, 0, 0, 0, 10);
		break;

		case "SailsTypeChoosen_selected":
		npchar.sailsgerald = "sails";
		DialogExit();
		LaunchSailsGeraldScreen(npchar,&characters[GetCompanionIndex(pchar, comp-1)]);
		break;

		case "SailsTypeChoose2":
			NPChar.SailsTypeMoney = GetSailsTypePrice(sti(RealShips[sti(Pchar.Ship.Type)].ship.upgrades.sails),
													  sti(NPChar.SailsTypeChooseIDX),
													  stf(NPChar.ShipCostRate),
													  sti(RealShips[sti(Pchar.Ship.Type)].Price));

			dialog.text = "En ce moment, vous avez des voiles en '" + GetSailsType(sti(RealShips[sti(Pchar.Ship.Type)].ship.upgrades.sails)) +
						  "', vous avez choisi '"+ GetSailsType(sti(NPChar.SailsTypeChooseIDX))+
						  "'. Le remplacement coמte " + FindRussianMoneyString(sti(NPChar.SailsTypeMoney)) +". On les change ?";

			if (sti(NPChar.SailsTypeMoney) <= sti(Pchar.Money))
			{
				Link.l1 = "Oui.";
				Link.l1.go = "SailsTypeChooseDone";
			}
			Link.l99 = "Non.";
			Link.l99.go = "exit";
		break;

		case "SailsTypeChooseDone":
			AddMoneyToCharacter(Pchar, -sti(NPChar.SailsTypeMoney));
			dialog.text = "Parfait ! Nous ferons tout pour le mieux.";
			Link.l9 = "Merci.";
			Link.l9.go = "exit";

			RealShips[sti(Pchar.Ship.Type)].ship.upgrades.sails = sti(NPChar.SailsTypeChooseIDX);
			WaitDate("",0,0,0, 0, 10);
		break;

		case "SailsColorChoose":
			if (GetSailsTuningPrice(Pchar, npchar, SAILSCOLOR_PRICE_RATE) <= sti(Pchar.Money))
			{
				dialog.text = "Quelle couleur met-on ? Prix : " + FindRussianMoneyString(GetSailsTuningPrice(Pchar, npchar, SAILSCOLOR_PRICE_RATE)) + ".";
				for (i = 0; i < SAILS_COLOR_QUANTITY; i++)
				{
					if (CheckSailsColor(Pchar, i))
					{
						attrLoc = "l" + i;
						Link.(attrLoc) = SailsColors[i].name;
						Link.(attrLoc).go = "SailsColorIdx_" + i;
					}
				}
				Link.l99 = "J'ai changé d'avis.";
				Link.l99.go = "exit";
			}
			else
			{
				dialog.text = "Revenez quand vous aurez l'argent.";
				Link.l9 = "Bien.";
				Link.l9.go = "exit";
			}
		break;

		case "SailsColorDone":
			AddMoneyToCharacter(Pchar, -GetSailsTuningPrice(Pchar, npchar, SAILSCOLOR_PRICE_RATE));
			dialog.text = "D'accord. Peinture des voiles, couleur : "+ GetStrSmallRegister(SailsColors[sti(NPChar.SailsColorIdx)].name) +".";
			Link.l9 = "Merci.";
			Link.l9.go = "exit";

			SetSailsColor(Pchar, sti(NPChar.SailsColorIdx));
			WaitDate("",0,0,0, 0, 10);
		break;

		// квест украсть чертёж на верфи
		case "ShipyardsMap_1":
			dialog.text = "J'ai besoin de me procurer un plan important. Un plan très important...";
			link.l1 = "Hum. Quel plan, et oם puis-je me le procurer ?";
			link.l1.go = "ShipyardsMap_2";
		break;
		case "ShipyardsMap_2":
			pchar.questTemp.different = "ShipyardsMap";
			pchar.questTemp.different.ShipyardsMap = "toTarget";
			pchar.questTemp.different.ShipyardsMap.Id = npchar.id; //квестодатель
			pchar.questTemp.different.ShipyardsMap.city = findShipyardCity(npchar);
			if (pchar.questTemp.different.ShipyardsMap.city == "none")
			{
				dialog.text = "Désolé, je me suis trompé. Je ne peux pas vous proposer ce travail.";
				link.l1 = "Eh bien, tant pis !";
				DeleteAttribute(pchar,"questTemp.different.ShipyardsMap");
				break;
			}
			pchar.questTemp.different.ShipyardsMap.what = LinkRandPhrase("corvette", "flמte", "frégate");
			pchar.questTemp.different.ShipyardsMap.chance = rand(6); //ценность чертежа
			if (rand(12) < GetCharacterSPECIAL(pchar, "Charisma"))
			{
				pchar.questTemp.different.ShipyardsMap.skladFight = false; //не будет драки на складе
			}
			else
			{
				pchar.questTemp.different.ShipyardsMap.skladFight = true; //будет драка на складе
			}
			pchar.questTemp.different.ShipyardsMap.sklad = rand(3)+1; //сколько денег попросят на складе за открытие двери
			pchar.questTemp.different.ShipyardsMap.fightQty = 2 + rand(3); //количество бойцов на верфи
			dialog.text = "J'ai appris qu'au chantier naval de " + XI_ConvertString("Colony" + pchar.questTemp.different.ShipyardsMap.city + "Gen") + " on construit actuellement un tout nouveau navire de type " + pchar.questTemp.different.ShipyardsMap.what + ". J'ai besoin du plan d'après lequel on y travaille.";
			link.l1 = "Et que dois-je faire ?";
			link.l1.go = "ShipyardsMap_3";
		break;
		case "ShipyardsMap_3":
			dialog.text = "Me l'apporter. Le problème, c'est qu'en raison de sa valeur, le plan est sans cesse sous les yeux du propriétaire du chantier. Ou, pour être précis, sur son bureau.";
			link.l1 = "Et que proposez-vous ?";
			link.l1.go = "ShipyardsMap_4";
		break;
		case "ShipyardsMap_4":
			dialog.text = "Hum, je vous propose de me rapporter le plan. Comment vous vous y prendrez, c'est votre affaire. Je suis prêt à bien payer ce travail, même si beaucoup dépendra de la valeur réelle des informations contenues dans le plan.";
			link.l1 = "Comment ça ?";
			link.l1.go = "ShipyardsMap_5";
		break;
		case "ShipyardsMap_5":
			dialog.text = "Si le projet comporte des solutions techniques nouvelles que je ne connais pas, la somme sera assez importante. Sinon, la rémunération sera modeste... Alors, vous acceptez de vous charger de l'affaire ?";
			link.l1 = "Non, ça ne m'intéresse pas. Livrer un chat en poche me paraît un travail bien ingrat.";
			link.l1.go = "ShipyardsMap_disagree";
			link.l2 = "Je crois que je vais le faire. J'accepte !";
			link.l2.go = "ShipyardsMap_agree";
		break;

		case "ShipyardsMap_disagree":
			dialog.text = "Hum, eh bien, c'est dommage.";
			link.l1 = "Moi aussi...";
			link.l1.go = "exit";
			pchar.questTemp.different = "free";
			DeleteAttribute(pchar, "questTemp.different.ShipyardsMap");
		break;
		case "ShipyardsMap_agree":
			dialog.text = "Eh bien, bonne chance alors. Je vous attendrai avec les résultats. Vous n'avez pas de délai.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			sld = ItemsFromID("ShipyardsMap");
			sld.shown = true;
			sld.startLocation = pchar.questTemp.different.ShipyardsMap.city + "_Shipyard";
			sld.startLocator = "item1";
			sld.ShipName = pchar.questTemp.different.ShipyardsMap.what;
			SetTimerFunction("SmallQuests_free", 0, 0, 0); //освобождаем разрешалку на миниквесты
			ReOpenQuestHeader("ShipyardsMap");
			AddQuestRecord("ShipyardsMap", "1");
			AddQuestUserData("ShipyardsMap", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ShipyardsMap", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("ShipyardsMap", "sTarget", XI_ConvertString("Colony" + pchar.questTemp.different.ShipyardsMap.city + "Voc"));
			AddQuestUserData("ShipyardsMap", "sShip", pchar.questTemp.different.ShipyardsMap.what);
		break;

		case "Allarm":
			dialog.text = "Espèce de salaud ! Qu'est-ce que vous faites ?! Attendez un peu, je vais vous donner une leçon. Allez, les gars, prenez les haches !";
			link.l1 = "Les haches ?";
			link.l1.go = "fight";
			LAi_SetPlayerType(pchar);
			AddCharacterExpToSkill(pchar, "FencingLight", 10);
			AddCharacterExpToSkill(pchar, "Fencing", 10);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 10);
			ChangeCharacterReputation(pchar, -1);
			for (i=1; i<=sti(pchar.questTemp.different.ShipyardsMap.fightQty); i++)
			{
				iTemp = 10 + rand(10);
				sld = GetCharacter(NPC_GenerateCharacter("shipowner_"+i, "shipowner_"+(rand(15)+1), "man", "man", iTemp, sti(pchar.nation), 0, true));
				FantomMakeCoolFighter(sld, iTemp, 70, 70, "topor"+(rand(2)+1), "pistol2", 10);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, npchar.chr_ai.group);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			}
		break;

		case "Allarm_1":
			dialog.text = "Vous me menacez ?! Allez, les gars, prenez les haches !";
			link.l1 = "Les haches ?";
			link.l1.go = "fight";
			ChangeCharacterReputation(pchar, -1);
			for (i=1; i<=5; i++)
			{
				iTemp = 10 + rand(10);
				sld = GetCharacter(NPC_GenerateCharacter("shipowner_"+i, "shipowner_"+(rand(15)+1), "man", "man", iTemp, sti(pchar.nation), 0, true));
				FantomMakeCoolFighter(sld, iTemp, 70, 70, "topor"+(rand(2)+1), "pistol2", 10);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, npchar.chr_ai.group);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			}
		break;

		case "ShipyardsMapOk_1":
			sTemp = pchar.questTemp.different.ShipyardsMap.what;
			dialog.text = "Parfait ! Eh bien, voyons ce qu'il a de si fameux, " + strcut(sTemp, 0, strlen(sTemp)-2) + "...";
			link.l1 = "Regardez.";
			link.l1.go = "ShipyardsMapOk_2";
		break;

		case "ShipyardsMapOk_2":
			TakeItemFromCharacter(pchar, "ShipyardsMap");
			if (rand(9)<3)
			{
				GiveItem2Character(pchar, "Ship_Print_5");
				Log_info("Vous avez reçu un plan détaillé.");
				dialog.text = "Bon, bon... hum, je dois vous décevoir. Je n'y vois rien d'utile. Vous pouvez le garder.";
				link.l1 = "Vous refusez de me payer pour l'avoir apporté ?";
				link.l1.go = "ShipyardsMapOk_3";
			}
			else
			{
				switch (sti(pchar.questTemp.different.ShipyardsMap.chance))
				{
					case 0:
					dialog.text = "Bon, bon... hum, je dois vous décevoir. Je n'y vois rien d'utile pour moi. Vous avez dמ prendre la mauvaise chose.";
					link.l1 = "Vous avez commandé ce qui était sur la table. C'est exactement ce que je vous ai apporté"+ GetSexPhrase("", "") +". Je ne comprends rien à ces plans !";
					link.l1.go = "ShipyardsMapOk_3";
					break;
					case 1:
						dialog.text = "Oui, ce plan a une certaine valeur. Je suis prêt à vous le payer " + FindRussianMoneyString(1500 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)) + ". Je vous paierai en lingots d'argent. דa vous convient ?";
						link.l1 = "Non, bien sמr ! Parfait !";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 2;
						TakeNItems(pchar, "jewelry17", makeint(1500 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)/100));
					break;
					case 2:
						dialog.text = "Oui, ce plan a une certaine valeur. Je suis prêt à vous le payer " + FindRussianMoneyString(3000 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)) + ". Je vous paierai en lingots d'or. דa vous convient ?";
						link.l1 = "Non, bien sמr ! Parfait !";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 2;
						TakeNItems(pchar, "jewelry5", makeint(3000 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)/200));
					break;
					case 3:
						dialog.text = "Oui, ce plan a une certaine valeur. Je suis prêt à vous le payer " + FindRussianMoneyString(4500 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)) + ".";
						link.l1 = "Parfait !";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 2;
						AddMoneyToCharacter(pchar, 4500 * GetCharacterSPECIALSimple(PChar, SPECIAL_L));
					break;
					case 4:
						dialog.text = "Oui, ce plan a une valeur considérable. Je suis prêt à vous le payer " + FindRussianMoneyString(6000 * GetCharacterSPECIALSimple(PChar, SPECIAL_L)) + ".";
						link.l1 = "Parfait !";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 2;
						AddMoneyToCharacter(pchar, 6000 * GetCharacterSPECIALSimple(PChar, SPECIAL_L));
					break;
					case 5:
						dialog.text = "Oh ! Voilà un plan très, très précieux ! Je suis prêt à vous en donner 60 000 pièces d'or. Je vous paierai en coffres de crédit. דa vous convient ?";
						link.l1 = "Non, bien sמr ! Parfait !";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 5;
						TakeNItems(pchar, "chest", (GetCharacterSPECIALSimple(PChar, SPECIAL_L)+5)/3);//У3 - 2 сундука, У4-6 - 3, У7-9 - 4, У10 - 5
					break;
					case 6:
						dialog.text = "Oui, ce plan a une certaine valeur. Mais je n'ai pas d'argent disponible en ce moment, je peux donc vous donner l'un des coffres de matériaux d'artisanat.";
						link.l1 = "Bon, s'il n'y a rien d'autre, va pour ça.";
						link.l1.go = "ShipyardsMapOk_5";
						NPChar.reputation = sti(NPChar.reputation) + 2;
						TakeNItems(pchar, "Chest_Craftsmans", 1);
						Log_info("Vous avez reçu le coffre de l'artisan.")
					break;
				}
				if (sti(NPChar.reputation)>100) NPChar.reputation = 100;
			}
		break;

		case "ShipyardsMapOk_3":
			dialog.text = "Hélas, je ne peux rien payer du tout pour ça. Je suis désolé, mais ce papier ne me sert à rien.";
			link.l1 = "Hum, je ne trouve pas ça très honnête, mais je ne vais pas faire d'esclandre.";
			link.l1.go = "ShipyardsMapOk_4";
			link.l2 = "Rendez-moi mon argent ! Sinon je vous saigne !";
			link.l2.go = "Allarm_1";
		break;
		case "ShipyardsMapOk_4":
			dialog.text = "Comprenez-moi bien, vous auriez pu le jeter tranquillement à la décharge. Ce plan ne vaut rien.";
			link.l1 = "Je vous comprends...";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.different.ShipyardsMap");
			AddQuestRecord("ShipyardsMap", "3");
			AddQuestUserData("ShipyardsMap", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ShipyardsMap", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			CloseQuestHeader("ShipyardsMap");

			AchievementsCounter_genquests(1);
		break;

		case "ShipyardsMapOk_5":
			dialog.text = "Veuillez recevoir ceci. Merci pour le travail accompli.";
			link.l1 = "Je vous en prie...";
			link.l1.go = "exit";
			AddCharacterExpToSkill(pchar, "Commerce", 20);
			ChangeCharacterReputation(pchar, 5);
			AddMoneyToCharacter(pchar, sti(pchar.questTemp.different.ShipyardsMap.chance)*1000);
			AddQuestRecord("ShipyardsMap", "4");
			AddQuestUserData("ShipyardsMap", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ShipyardsMap", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("ShipyardsMap", "iMoney", sti(pchar.questTemp.different.ShipyardsMap.chance)*1000);
			CloseQuestHeader("ShipyardsMap");

			AchievementsCounter_genquests(1);

			DeleteAttribute(pchar, "questTemp.different.ShipyardsMap");
		break;

		////////////////////////////////////////////////homo линейка Блада/////////////////////////////////////////
		case "Blood_Shipyard1":
			dialog.text = "Hum, eh bien, tout dépend de qui est votre ami et pourquoi il doit se rendre à Portobelo, docteur.";
			link.l1 = "Celui-là... Mon ami, c'est... C'est une belle jeune femme... Hum, j'ai oublié son nom, il est si facile à oublier...";
			link.l1.go = "Blood_Shipyard2";
			link.l2 = "Mon cher ami est un flibustier qui a récemment perdu son navire en attaquant une frégate militaire.";
			link.l2.go = "Blood_Shipyard3";
			link.l3 = "Vous avez entendu parler de lui. C'est un corsaire... Il se fait appeler Rolando Pizarro, la Terreur des Sept Mers, et ainsi de suite...";
			link.l3.go = "Blood_Shipyard4";
		break;

		case "Blood_Shipyard2":
			dialog.text = "Une jeune femme ? Votre ami, qui est en fait une jeune femme au nom insignifiant, veut se rendre à Portobelo ? Vous vous moquez de moi, docteur ?";
			link.l1 = "Je n'en avais aucune idée, monsieur ! J'essaie juste, euh, de l'aider. Enfin, lui... Elle, je veux dire. Un ami. Oui.";
			link.l1.go = "Blood_Shipyard5";

		break;
		case "Blood_Shipyard3":
			dialog.text = "Et oם est-ce arrivé ?";
			link.l1 = "C'était... Euh, que le diable m'emporte ! J'ai oublié.";
			link.l1.go = "exit";
			CloseQuestHeader("PirateQuest");
			Pchar.questTemp.CapBloodLine.ShipForJack = false;

		break;
		case "Blood_Shipyard4":
			dialog.text = "Vous voulez dire un ancien corsaire... C'est bien ça ?";
			link.l1 = "Euh... eh bien, oui... ancien. Vous le connaissez ?";
			link.l1.go = "Blood_Shipyard6";
		break;

		case "Blood_Shipyard5":
			dialog.text = "Bon, je vais vous croire pour cette fois. Il y a en ville un homme nommé John Miner. Parlez-lui, il vient de m'acheter une corvette.";
			link.l1 = "Merci beaucoup.";
			link.l1.go = "Exit";
			LoginMainer();
			AddQuestRecord("PirateQuest", "2");
		break;

		case "Blood_Shipyard6":
			dialog.text = "Comme vous l'avez bien remarqué, j'ai entendu parler de lui. Je ne sais pas qui était Rolando Pizarro avant d'apparaître chez les Frères de la Cכte. Mais je me souviens bien de son navire, le Danse avec les loups. Un beau nom, et un beau navire... Il l'était.";
			link.l1 = "Quoi ?! Il n'en a pas dit un mot... dans notre conversation, je veux dire.";
			link.l1.go = "Blood_Shipyard7";
		break;

		case "Blood_Shipyard7":
			dialog.text = "Maintenant, il tient sa langue : la vie lui a donné une leçon. Après avoir fait quelques riches prises, il a voulu se hisser au sommet des Frères de la Cכte, en essayant d'écarter Morgan lui-même. Vous savez, cette idée de la Libertalia de Sharp et tout le reste. Il parlait beaucoup et bien, et bien sמr, il y a eu des gens pour croire à ces sornettes et le suivre... Qui aurait cru que tout tournerait ainsi...";
			link.l1 = "On l'a trahi ? Il y a eu une mutinerie ?";
			link.l1.go = "Blood_Shipyard8";
		break;

		case "Blood_Shipyard8":
			dialog.text = "Non, tout s'est passé de façon bien plus banale... Comme dans la vraie vie. Pizarro n'avait aucune intention de créer une Libertalia : il voulait juste s'asseoir dans un beau fauteuil, dans son propre manoir de Port Royal, et regarder les jeunes corsaires trembler et ramper devant lui. Vous savez, cet éternel désir de punir et de gracier à sa guise, de distribuer les grades ou une balle de plomb dans le cœur... Et, bien sמr, la gloire... C'est ce que nous voulons tous, n'est-ce pas ? Seulement, le fond de l'affaire a fini par éclater. Morgan voulait le pendre sur-le-champ, vous en avez sans doute entendu parler : il déteste les rebelles. Pizarro a donc été cueilli au chaud dans sa cabine, dès que Morgan a eu toutes les preuves.";
			link.l1 = "Une histoire très instructive. Il faudra que je la propose à un romancier. Mais, et ce navire pour ce, euh... amoureux de la vérité ?";
			link.l1.go = "Blood_Shipyard9";
			link.l2 = "Et comment Rolando a-t-il réussi à s'échapper ?";
			link.l2.go = "Blood_Shipyard10";
		break;

		case "Blood_Shipyard9":
			dialog.text = "Trouvez en ville un homme nommé John Miner, il vient d'acheter une corvette. Je pense qu'un passager pour Portobelo ne sera pas de trop pour lui.";
			link.l1 = "Merci beaucoup.";
			link.l1.go = "Exit";
			LoginMainer();
			AddQuestRecord("PirateQuest", "2");
		break;

		case "Blood_Shipyard10":
			dialog.text = "D'habitude, chez Morgan, le procès est court : pas plus long que la poudre ne met à brמler dans le bassinet de son pistolet. Mais avec ce « favori du peuple », il a traîné... si bien que Pizarro s'est enfui chez les Espagnols. Il a filé sous le nez de l'amiral, prouvant que le renard n'est pas seulement une bête rusée, mais aussi agile.";
			link.l1 = "Hum, mais comment a-t-il berné l'amiral des Frères de la Cכte ? דa pourra peut-être servir à l'avenir.";
			link.l1.go = "Blood_Shipyard11";
		break;

		case "Blood_Shipyard11":
			dialog.text = "Je ne pense pas que ce soit la bonne méthode, mais si ça vous intéresse : il est resté trois jours et trois nuits à Port Royal, puis l'un de ses complices a réussi à lui faire passer une robe de femme. Et une certaine Lady Taylor a quitté le fort sans encombre, en assurant au commandant que son cher Pizarro était traité dignement. Ensuite, cette dame est montée à bord d'un navire au port... et le renard s'est échappé de sa cage. Il s'est échappé, puis il a réapparu. Seulement, les Frères de la Cכte savaient déjà ce qu'il valait, et même l'amiral ne le cherche plus... il ne veut sans doute pas se salir les mains.";
			link.l1 = "Donc, si je comprends bien, inutile de le livrer aux autorités, puisque personne ne le cherche. Très instructif. Mais comment l'emmener à Portobelo ?";
			link.l1.go = "Blood_Shipyard12";
		break;

		case "Blood_Shipyard12":
			dialog.text = "Il vous faut le capitaine Miner, John Miner : il équipe la corvette qu'il vient d'acquérir. Cherchez-le en ville.";
			link.l1 = "Merci beaucoup.";
			link.l1.go = "Exit";
			LoginMainer();
			AddQuestRecord("PirateQuest", "3");
		break;

	}
}

string findShipyardCity(ref NPChar)
{
	int n, nation;
	int storeArray[MAX_COLONIES];
	int howStore = 0;

	for(n=0; n<MAX_COLONIES; n++)
	{
		nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
		if (sti(colonies[n].nation) != PIRATE && colonies[n].id != "Panama" && colonies[n].id != "DesMoines" && colonies[n].nation != "none" && GetIslandByCityName(npchar.city) != colonies[n].islandLable) //здесь прописываем города, где нет верфи
		{
			if (GetCharacterIndex(colonies[n].id + "_shipyarder") != -1)
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
	}
	if (howStore == 0) return "none";
	nation = storeArray[rand(howStore-1)];
	return colonies[nation].id;
}

// проверка какой уже цвет есть
bool CheckSailsColor(ref chr, int col)
{
	int	st = GetCharacterShipType(chr);
	ref	shref;

	if (st != SHIP_NOTUSED)
	{
		shref = GetRealShip(st);
		st = -1;
		if (!CheckAttribute(shref, "ShipSails.SailsColor"))  st = 0; // нету - это белый
		if (CheckAttribute(shref, "SailsColorIdx"))  st = sti(shref.SailsColorIdx);
		if (st == col) return false;
	}
	return true;
}

bool CheckSailsGerald(ref chr)
{
	int	st = GetCharacterShipType(chr);
	ref	shref;
	if (st != SHIP_NOTUSED)
	{
		shref = GetRealShip(st);
		if (CheckAttribute(shref, "GeraldSails"))  return true;
	}
	return false;
}

string GetSailsType(int _type)
{
	switch (_type)
	{
		case 1 : return "Chanvre";  break;
		case 2 : return "Lin";	 break;
		case 3 : return "Coton";  break;
		case 4 : return "Toile noire";  break;
	}
	return "Chanvre";
}

int GetSailsTypePrice(int _asis, int _tobe, float _shipCostRate, int _price)
{
	int ret;
	ret = _tobe - _asis;

	if (ret < 0) ret = 0;

	return makeint((ret*_price*0.05 + _price*0.05)*_shipCostRate / 10) * 10;
}

// Warship Ghdjthrf на паруса ЛГ
bool CheckForFlyingDuchmanSails(ref _char)
{
	ref realShip;
	int shipType = sti(_char.Ship.Type);

	if(shipType == SHIP_NOTUSED) return false;

	realShip = GetRealShip(shipType);

	if(CheckAttribute(realShip, "EmblemedSails.normalTex") && realShip.EmblemedSails.normalTex == "ships/parus_common_torn.dds")
	{
		return true;
	}

	return false;
}

void SelectFindship_ShipType(int iNation)
{
	int iRank, pcharRank;
	pcharRank = sti(pchar.rank);
	iRank = 6;
	if (pcharRank > 4) iRank = 5;
	if (pcharRank > 9) iRank = 4;
	if (pcharRank > 14) iRank = 3;
	if (pcharRank > 19) iRank = 2;
	if (pcharRank > 25) iRank = 1;
	pchar.GenQuest.Findship.Shipyarder.ShipType = GetShipTypeExtNotNation(iRank, iRank, "", iNation);
}


void DelBakSkill(ref _compref)
{
	DelBakSkillAttr(pchar);
	ClearCharacterExpRate(pchar);
	RefreshCharacterSkillExpRate(pchar);
	SetEnergyToCharacter(pchar);

	DelBakSkillAttr(_compref);
	ClearCharacterExpRate(_compref);
	RefreshCharacterSkillExpRate(_compref);
	SetEnergyToCharacter(_compref);
}

string GiveOrderMatherial(ref NPChar)
{
	int amount;
	string sGood1, sItem2;
	string sLeft = "";
	int idLngFile = LanguageOpenFile("ItemsDescribe.txt");

	for (int k=1;k<10;k++)
	{
		sGood1 = g_ShipBermudeTuningGoods[k];
		amount = GetSquadronGoods(Pchar, FindGood(sGood1)) - sti(NPChar.questtemp.(sGood1));
		if (amount < 0) amount = amount + sti(NPChar.questtemp.(sGood1)); else amount = sti(NPChar.questtemp.(sGood1));
		RemoveCharacterGoods(Pchar, FindGood(sGood1), amount);
		NPChar.questtemp.(sGood1) = sti(NPChar.questtemp.(sGood1)) - amount;
		amount = sti(NPChar.questtemp.(sGood1));
		if (amount > 0) sLeft += NewStr() + XI_ConvertString(sGood1) + " - " + amount + " unités, ";

		sItem2 = g_ShipBermudeTuningItems[k];
		amount = GetCharacterItemWithCabin(pchar, sItem2, true) - sti(NPChar.questtemp.(sItem2));
		if (amount < 0) amount = amount + sti(NPChar.questtemp.(sItem2)); else amount = sti(NPChar.questtemp.(sItem2));
		TakeNItemsWithCabin(pchar, sItem2, -amount, false);
		NPChar.questtemp.(sItem2) = sti(NPChar.questtemp.(sItem2)) - amount;
		amount = sti(NPChar.questtemp.(sItem2));
		if (amount > 0) sLeft += NewStr() + LanguageConvertString(idLngFile, Items[FindItem(sItem2)].name) + " - " + amount + " unités, ";
	}
		sItem2 = "chest";
		amount = GetCharacterItemWithCabin(pchar, sItem2, true) - sti(NPChar.questtemp.(sItem2));
		if (amount < 0) amount = amount + sti(NPChar.questtemp.(sItem2)); else amount = sti(NPChar.questtemp.(sItem2));
		TakeNItemsWithCabin(pchar, sItem2, -amount, false);
		NPChar.questtemp.(sItem2) = sti(NPChar.questtemp.(sItem2)) - amount;
		amount = sti(NPChar.questtemp.(sItem2));
		if (amount > 0) sLeft += NewStr() + "Coffres de pièces :" + amount + " unités.";

	return sLeft; //возвращаем строку со списком оставшегося, или строка пустая
}

bool CheckOrderMatherial(ref NPChar)
{
	int amount;
	string sGood1, sItem2;
	string sLeft = "";
	int idLngFile = LanguageOpenFile("ItemsDescribe.txt");

	for (int k=1;k<10;k++)
	{
		sGood1 = g_ShipBermudeTuningGoods[k];
		if (sti(NPChar.questtemp.(sGood1)) > 0 && GetSquadronGoods(pchar, FindGood(sGood1)) > 0) return true;

		sItem2 = g_ShipBermudeTuningItems[k];
		if (sti(NPChar.questtemp.(sItem2)) > 0 && GetCharacterItem(pchar, sItem2) > 0) return true;
	}
		sItem2 = "chest";
		if (sti(NPChar.questtemp.(sItem2)) > 0 && GetCharacterItem(pchar, sItem2) > 0) return true;

	return false; //ничего не привезли
}
