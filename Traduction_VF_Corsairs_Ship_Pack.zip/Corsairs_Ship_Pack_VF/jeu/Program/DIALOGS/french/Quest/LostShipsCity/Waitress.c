
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
        case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			NextDiag.TempNode = "First time";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = "Je ne veux pas vous parler ! Vous avez attaqué des citoyens !!";
				link.l1 = "Comme vous voudrez..."
				link.l1.go = "exit";
				break;
			}
			//после завала Хилла Брюннера
			if (pchar.questTemp.LSC == "barmenIsDead")
			{
				dialog.Text = "Ah, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", vous êtes déjà au courant de notre malheur ?";
				link.l4 = "Quel malheur ? Que s'est-il passé ?";
				link.l4.go = "NB_1";
				pchar.questTemp.LSC = "barmenIsDeadYouKnow";
				break;
			}
			if (pchar.questTemp.LSC == "barmenIsDeadYouKnow" || pchar.questTemp.LSC == "toArmo_BrunnerDead")
			{
				dialog.Text = "Ah, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", quel cauchemar ! Quelle horreur !!";
				link.l4 = "Oui, Armo, je suis au courant. C'est triste pour Hill, bien triste...";
				link.l4.go = "NBB_1";
				break;
			}
			if(NPChar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.Text = "Oui, oui, je vous connais ! C'est cette tempête qui a détruit votre navire. Eh bien, c'est votre destin, et maintenant, il est lié au nכtre ! Nous sommes tous prisonniers de cette île...";
					Link.l1 = "Oui, j'ai remarqué...";
					link.l1.go = "FT_1";
				}
				else
				{
					dialog.Text = "Oui, oui, je vous connais ! C'est votre navire qui a sombré ici en dernier. Eh bien, c'est votre destin, et maintenant, il est lié au nכtre ! Nous sommes tous prisonniers de cette île...";
					Link.l1 = "Oui, j'ai remarqué...";
					Link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +" ?";
				Link.l1 = "Je veux vous poser quelques questions, " + npchar.name + ".";
				Link.l1.go = "int_quests";
				link.l10 = "Oh, rien, en fait...";
				link.l10.go = "exit";
				//рассказываем ей о том, что, возможно, за убийством Хилла стоят касперы
				if (pchar.questTemp.LSC == "toSeekMechanik" && !CheckAttribute(pchar, "questTemp.LSC.Armo"))
				{
					link.l4 = "וcoutez, Armo, j'ai quelques idées sur la mort de Hill.";
					link.l4.go = "AboutCasper_1";
				}
				//наводка на первого
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 0)
				{
					link.l4 = "Armo, y a-t-il du nouveau pour le premier rendez-vous ?";
					link.l4.go = "Casper1";
				}
				//ждём втогого
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 2 && CheckAttribute(pchar, "questTemp.LSC.Armo.waiting"))
				{
					link.l4 = "Armo, je tiens à vous dire que mon premier rendez-vous a été un succès...";
					link.l4.go = "WaitCasper1";
				}
				//наводка на второго
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 2 && !CheckAttribute(pchar, "questTemp.LSC.Armo.waiting"))
				{
					link.l4 = "Armo, y a-t-il du nouveau pour le deuxième rendez-vous ?";
					link.l4.go = "Casper2";
				}
				//ждём третьего
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 4 && CheckAttribute(pchar, "questTemp.LSC.Armo.waiting"))
				{
					link.l4 = "Armo, le deuxième, c'est réglé.";
					link.l4.go = "WaitCasper2";
				}
				//наводка на третьего
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 4 && !CheckAttribute(pchar, "questTemp.LSC.Armo.waiting"))
				{
					link.l4 = "Armo, y a-t-il du nouveau pour le troisième rendez-vous ?";
					link.l4.go = "Casper3";
				}
                //опоздал или упустил вызванного каспера
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 11 && npchar.name == "Armo")
				{
					link.l4 = "Armo, je suis désolé, mais je crois que j'ai raté le rendez-vous, finalement.";
					link.l4.go = "CasperLate";
				}
                //опоздал или упустил вызванного каспера
				if (pchar.questTemp.LSC == "toSeekMechanik" && CheckAttribute(pchar, "questTemp.LSC.Armo") && sti(pchar.questTemp.LSC.Armo) == 15 && npchar.name == "Armo")
				{
					link.l4 = "Armo, voilà comment ça s'est passé...";
					link.l4.go = "CasperAllFight";
				}
				if (pchar.questTemp.LSC == "seekMillionAndHalf" && npchar.name == "Armo" && !CheckAttribute(npchar, "quest.giveMoney"))
				{
					link.l4 = "וcoutez, Armo, j'ai des ennuis d'argent...";
					link.l4.go = "askMoney";
				}
				//освобождение мужа Элис Тейлор
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toWaitress")
				{
					link.l5 = "Vous vous souvenez de la nuit oם Maxim Taylor a bu chez vous ?" + npchar.name + "";
					link.l5.go = "ELTHusb_SF";
				}
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, vous ne sauriez pas oם l'on peut se procurer des marchandises ?";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "וcoutez, nous devons avoir une conversation sérieuse. Je recrute un équipage pour quitter cet endroit à bord d'un navire.";
					link.l8.go = "SeekCrew";
				}
			}
		break;
		case "FT_1":
			dialog.text = "Eh bien, faisons connaissance. Je m'appelle " + GetFullName(npchar) + ". Et vous ?";
			link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je suis capitaine... Kof, ex-capitaine...";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Vous êtes donc le capitaine du navire qui a sombré ?! J'imagine combien votre conscience vous tourmente pour la mort de vos hommes. Oh, je suis désolée, désolée...";
			link.l1 = "Oui, pas de problème, en fait..";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = "Je vous appellerai "+ GetSexPhrase("« monsieur le capitaine »", "simplement « mademoiselle »") +" ! דa ne vous dérange pas ?";
			link.l1 = "דa ne me dérange pas, " + npchar.name + ". Appelez-moi comme vous voudrez...";
			link.l1.go = "exit";
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Demandez, capitaine.";
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "C'est un peu inconfortable ici, vous ne trouvez pas ? Il y a toujours des tempêtes...";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Comment êtes-vous arrivée ici ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Vous ne voulez pas partir d'ici ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "וcoutez, quels clans prospèrent ici ? Je veux parler des « Narvals » et des « Caspers ».";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5"))
			{
				link.l5 = "וcoutez, je n'arrive toujours pas vraiment à m'orienter dans la Cité. Oם pourrais-je trouver une carte, ou quelque chose de ce genre...";
				link.l5.go = "ansewer_5";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l6") && CheckActiveQuest("LSC_findDekster"))
			{
				link.l6 = "וcoutez, " + npchar.name ", savez-vous quelque chose sur Leighton Dexter ?";
				link.l6.go = "ansewer_6";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l7") && CheckAttribute(pchar, "questTemp.LSC.LegroHelp") && pchar.questTemp.LSC.LegroHelp == "over" && npchar.name == "Armo")
			{
				link.l7 = "J'ai entendu dire que vous fréquentiez Thomas Boyle ?";
				link.l7.go = "ansewer_7";
			}
			link.l10 = "Vous savez, j'ai oublié ce que je voulais demander. Pardon de vous avoir dérangée...";
			link.l10.go = "exit";
		break;
		case "ansewer_3":
			dialog.text = "Des tempêtes, oui... Mais vous êtes marin, vous en avez l'habitude.";
			link.l1 = "Oui, mais quand même... C'est un peu lugubre.";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Ne vous découragez pas, ça arrive à tous ceux qui échouent ici. Tout s'arrangera, l'essentiel est de ne pas faire de bêtises.";
			link.l1 = "Des bêtises ?";
			link.l1.go = "ansewer_3_2";
		break;
		case "ansewer_3_2":
			dialog.text = "Ne vous disputez pas avec l'amiral, respectez la Loi, et tout ira bien.";
			link.l1 = "Compris... Merci pour votre soutien.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_1":
			dialog.text = "Comme tout le monde ici. Notre navire a sombré, j'ai réussi à remonter à la nage. En général, vous savez, très peu de gens remontent des navires qui coulent. Il y a un drכle de courant ici, ou quelque chose comme ça... Bref, je ne sais pas, mais le fait, comme on dit, est là.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Hi hi, tout le monde veut partir d'ici. Seulement, c'est impossible.";
			link.l1 = "Vous êtes sמr ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Oui, malheureusement. Les navires ne font qu'arriver ici, plus personne n'en repart. Et la construction de nouveaux navires est interdite par la Loi.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "Hum... Je vais vous dire une chose très simple, et j'espère que vous vous en souviendrez bien. Ne vous frottez pas à eux !!";
			link.l1 = "Qu'y a-t-il ?";
			link.l1.go = "ansewer_4_1";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_4_1":
			dialog.text = "Le fait est qu'on vous tuera, tout simplement. C'est arrivé plus d'une fois avec les nouveaux, alors ne répétez pas les erreurs de vos prédécesseurs. דa me ferait beaucoup de peine de voir votre cadavre flotter par-dessus bord.";
			link.l1 = "Merci, j'en tiendrai compte.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_5":
			dialog.text = "Une carte ? Eric Yorst en a une ! C'est le propriétaire du magasin.";
			link.l1 = "Oם se trouve le magasin ?";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Sur le galion « Esmeralda », "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +".";
			link.l1 = "Je comprends. Merci beaucoup, " + npchar.name + ".";
			link.l1.go = "int_quests";
		break;
		case "ansewer_6":
			dialog.text = ""+ GetSexPhrase("Monsieur le capitaine", "Mademoiselle") +", je ne sais rien de Leighton Dexter. Et je ne veux rien savoir.";
			link.l1 = "Hum, eh bien, désolé...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l6 = true;
		break;
		case "ansewer_7":
			dialog.text = "Oui, c'est vrai. Et pourquoi cette question, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +" ?";
			link.l1 = "Pour rien... Tant mieux pour vous !";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l7 = true;
		break;
		//смерть Брюннера
		case "NB_1":
			dialog.text = "Hill Brunner a été tué !!";
			link.l1 = "Quoi ?! Ce n'est pas possible !..";
			link.l1.go = "NB_2";
		break;
		case "NB_2":
			dialog.text = "Si, c'est vrai ! Mon Dieu, je n'arrive toujours pas à me remettre de ce cauchemar.";
			link.l1 = "Armo, racontez-moi comment c'est arrivé.";
			link.l1.go = "NB_3";
		break;
		case "NBB_1":
			dialog.text = "Oh, mon Dieu, j'ai travaillé pour lui si longtemps ! Quel brave homme c'était !";
			link.l1 = "Oui, c'est sמr... Armo, racontez-moi comment c'est arrivé.";
			link.l1.go = "NB_3";
		break;
		case "NB_3":
			dialog.text = "Oh, c'est terrible ! Je ne peux pas m'en souvenir sans frissonner...";
			link.l1 = "Armo, je vous demande de vous ressaisir et de me raconter comment ça s'est passé.";
			link.l1.go = "NB_4";
		break;
		case "NB_4":
			dialog.text = "Bon... Vers minuit, Hill est descendu à la cave. Comme il y restait plus de deux heures, j'y suis allée pour le presser, car je devais servir les clients. Et je l'ai trouvé là...";
			link.l1 = "Il était vraiment mort ?";
			link.l1.go = "NB_5";
		break;
		case "NB_5":
			dialog.text = "Oui, il avait le crâne fendu. Oh, je ne peux pas m'en souvenir sans pleurer...";
			link.l1 = "וcoutez, avez-vous vu quelqu'un aux alentours ? Sortir de la cave, par exemple...";
			link.l1.go = "NB_6";
		break;
		case "NB_6":
			dialog.text = "Non, personne.";
			link.l1 = "Mille diables ! On n'y comprend rien... וcoutez, vous a-t-il dit quelque chose avant de mourir ? Rappelez-vous des détails...";
			link.l1.go = "NB_7";
		break;
		case "NB_7":
			dialog.text = "Euh, je ne sais pas si ça vous sera utile, mais il m'a demandé si je connaissais des citoyens qui vivaient ici avant lui.";
			link.l1 = "Et qu'avez-vous répondu ?";
			link.l1.go = "NB_8";
		break;
		case "NB_8":
			dialog.text = "J'ai répondu que non. Et puis il m'a demandé si j'avais entendu, dans les conversations des clients, parler d'une sorte de mécanicien...";
			link.l1 = "Et qu'avez-vous répondu ?";
			link.l1.go = "NB_9";
		break;
		case "NB_9":
			dialog.text = "Ce que je n'avais pas entendu.";
			link.l1 = "C'est bien vrai ?";
			link.l1.go = "NB_10";
		break;
		case "NB_10":
			dialog.text = "Bien sמr ! Pourquoi mentirais-je à mon patron ?!";
			link.l1 = "Oui, en effet... Eh bien, merci, Armo.";
			link.l1.go = "NB_11";
		break;
		case "NB_11":
			dialog.text = "Pour quoi faire ?";
			link.l1 = "D'être une si gentille fille.";
			link.l1.go = "NB_12";
		break;
		case "NB_12":
			dialog.text = "Hum... Vous savez, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", je ne plaisante pas, là.";
			link.l1 = "Je ne plaisante pas non plus... Bon, Armo, ne soyez pas triste. La vie est ainsi faite : les gens meurent...";
			link.l1.go = "NB_13";
		break;
		case "NB_13":
			dialog.text = "Encore faut-il que ce soit de mort naturelle !.. "+ GetSexPhrase("Monsieur le capitaine", "Mademoiselle") +", promettez-moi que si vous apprenez quoi que ce soit sur cette affaire, vous me le direz.";
			link.l1 = "Je vous le promets, Armo.";
			link.l1.go = "NB_14";
		break;
		case "NB_14":
			dialog.text = "Merci. J'aimerais vraiment savoir qui a fait ça. Ce salaud n'a pas le droit de vivre !";
			link.l1 = "Oui, oui, je suis d'accord avec vous...";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toAdmiralBarmenDead";
			npchar.quest.meeting = "1";
			if (CheckAttribute(pchar, "questTemp.LSC.knowMechanic"))
			{
				AddQuestRecord("ISS_MainLine", "26");
				AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
				DeleteAttribute(pchar, "questTemp.LSC.knowMechanic");
			}
			else
			{
				AddQuestRecord("ISS_MainLine", "25");
				AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("ISS_MainLine", "sSex1", GetSexPhrase("", "e"));
			}
		break;

		case "AboutCasper_1":
			dialog.text = "Parlez, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +".";
			link.l1 = "On dirait que le clan des Caspers est derrière tout ça.";
			link.l1.go = "AboutCasper_2";
		break;
		case "AboutCasper_2":
			dialog.text = "Vous êtes sמr ?";
			link.l1 = "Oui, c'est certain. J'ai rendu visite à l'amiral, je lui ai posé des questions sur l'enquête du meurtre de Hill, je voulais de l'aide. Résultat : on m'a dit de ne pas fouiner dans cette affaire. Carrément et sans détour.";
			link.l1.go = "AboutCasper_3";
		break;
		case "AboutCasper_3":
			dialog.text = "Qu'est-ce que les « Caspers » ont à voir là-dedans ?";
			link.l1 = "Il s'avère qu'ils sont étroitement liés à l'amiral. Très étroitement... Et apparemment, l'amiral les couvre maintenant.";
			link.l1.go = "AboutCasper_4";
		break;
		case "AboutCasper_4":
			dialog.text = "Je vois... Je veux venger Hill.";
			link.l1 = "Je vais entrer en guerre contre le clan des Caspers.";
			link.l1.go = "AboutCasper_5";
		break;
		case "AboutCasper_5":
			dialog.text = "Vous comptez faire ça "+ GetSexPhrase("seul ", "seule ") +" ?";
			link.l1 = "Eh bien, oui. L'amiral ne m'aidera pas, cette fois.";
			link.l1.go = "AboutCasper_6";
		break;
		case "AboutCasper_6":
			dialog.text = "Ils vous tueront. Cela ne fait aucun doute, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +".";
			link.l1 = "Eh bien, on verra bien...";
			link.l1.go = "AboutCasper_7";
		break;
		case "AboutCasper_7":
			dialog.text = "Voici comment je peux vous aider. Le fait est que j'apporte à manger à ces salauds, sur le San Gabriel. J'y ai bon nombre d'admirateurs. Je leur donnerai rendez-vous, et vous vous occuperez d'eux en tête-à-tête.";
			link.l1 = "Ho ! Pas une mauvaise idée...";
			link.l1.go = "AboutCasper_8";
		break;
		case "AboutCasper_8":
			dialog.text = "Oם vous sera-t-il commode d'organiser ces rencontres ?";
			link.l1 = "Hum, je ne sais pas. א vrai dire, peu m'importe oם je retrouve "+ GetSexPhrase("ces gaillards", "l'ennemi") +"...";
			link.l1.go = "AboutCasper_9";
		break;
		case "AboutCasper_9":
			dialog.text = "Hi hi, bien dit... Revenez demain, je vous dirai à quelle heure est le rendez-vous.";
			link.l1 = "D'accord, Armo. Merci.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "33");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC.Armo = 0; //флаг на мочилово касперов. чётные - готовность Армо, нечётные - флаг questAction
			SaveCurrentQuestDateParam("questTemp.LSC"); //запомним дату базара
		break;
		//первый каспер
		case "Casper1":
			if (GetQuestPastDayParam("questTemp.LSC") > 0 && GetHour() < 20)
			{
				dialog.text = "Aujourd'hui, à minuit, un casper nommé Denis Hopfer viendra me faire la cour sur le gaillard d'arrière de la flמte Ceres Smithy. Faites attention, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", si vous attaquez Hopfer trop près du San Gabriel, les autres bandits pourront entendre le bruit du combat, et alors, c'en est fini de vous.";
				link.l1 = "Je comprends, Armo.";
				link.l1.go = "Casper1_1";
			}
			else
			{
				dialog.text = "Pas encore, attendez.";
				link.l1 = "Compris.";
				link.l1.go = "exit";
			}
		break;
		case "Casper1_1":
			dialog.text = "Je vous en prie, ne soyez pas en retard au rendez-vous, ce serait indécent de votre part...";
			link.l1 = ""+ GetSexPhrase("Héhé, c'est juste. Je serai au rendez-vous à minuit, droit comme une baïonnette !", "Oui, les filles comme il faut ne sont pas en retard. Je serai à l'heure, n'en doutez pas.") +"";
			link.l1.go = "exit";
			pchar.questTemp.LSC.Armo = 1; //чтобы сработал questAction на полночь
			AddQuestRecord("ISS_MainLine", "34");
		break;

		case "WaitCasper1":
			dialog.text = "Parfait, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". On continue ?";
			link.l1 = "Bien sמr, Armo !";
			link.l1.go = "WaitCasper1_1";
		break;
		case "WaitCasper1_1":
			dialog.text = "Alors revenez demain, j'arriverai peut-être à en faire sortir un autre.";
			link.l1 = "Je vous comprends.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.LSC.Armo.waiting");
			DeleteAttribute(pchar, "questTemp.LSC.Armo.Interrapt");
			SaveCurrentQuestDateParam("questTemp.LSC"); //запомним дату базара
		break;
		//второй каспер
		case "Casper2":
			if (GetQuestPastDayParam("questTemp.LSC") > 0 && GetHour() < 20)
			{
				dialog.text = "Oui, il y en a. Au même endroit, à la même heure, j'ai donné rendez-vous à un casper nommé Serge Chambon. Un vrai godelureau, qui me fait la cour depuis longtemps...";
				link.l1 = "Hé, il ne vous importunera plus bien longtemps.";
				link.l1.go = "Casper2_1";
			}
			else
			{
				dialog.text = "Pas encore, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". Attendez.";
				link.l1 = "Je vois.";
				link.l1.go = "exit";
			}
		break;
		case "Casper2_1":
			dialog.text = "Bon, c'est très bien. Alors, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", ne soyez pas en retard sur le gaillard d'arrière de la flמte « Ceres Smithy ». Je ne pense pas que vous devriez décevoir Serge.";
			link.l1 = "Pas question, Armo.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.Armo = 3; //чтобы сработал questAction на полночь
			AddQuestRecord("ISS_MainLine", "37");
		break;

		case "WaitCasper2":
			dialog.text = "Très bien, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". On essaie de recommencer ?";
			link.l1 = "Si possible, Armo.";
			link.l1.go = "WaitCasper2_1";
		break;
		case "WaitCasper2_1":
			dialog.text = "C'est possible. Revenez demain, j'espère avoir le temps de m'arranger avec quelqu'un d'autre.";
			link.l1 = "D'accord, Armo. Merci.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.LSC.Armo.waiting");
			DeleteAttribute(pchar, "questTemp.LSC.Armo.Interrapt");
			SaveCurrentQuestDateParam("questTemp.LSC"); //запомним дату базара
		break;
		//третий каспер
		case "Casper3":
			if (GetQuestPastDayParam("questTemp.LSC") > 0 && GetHour() < 20)
			{
				dialog.text = "Oui, bien sמr. Felipe Armas m'attendra au même endroit que les fois précédentes, à la même heure. Un gredin comme on n'en a jamais vu.";
				link.l1 = "Eh bien, occupons-nous de lui aussi...";
				link.l1.go = "Casper3_1";
			}
			else
			{
				dialog.text = "Pas encore, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". Attendez.";
				link.l1 = "Je vois.";
				link.l1.go = "exit";
			}
		break;
		case "Casper3_1":
			dialog.text = "Parfait ! Eh bien, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", bonne chance.";
			link.l1 = "Merci, j'en aurai besoin.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.Armo = 5; //чтобы сработал questAction на полночь
			AddQuestRecord("ISS_MainLine", "38");
		break;
		//прерывания хода квеста Армо
		case "CasperLate":
			dialog.text = "Vous savez quoi, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +", je ne risque pas ma vie pour que vous preniez vos promesses à la légère. Je ne vais plus vous aider. Je suis désolée.";
			link.l1 = "Oh, quel dommage...";
			link.l1.go = "exit";
			pchar.questTemp.LSC.Armo = 12; //Отмазала девка
			AddQuestRecord("ISS_MainLine", "35");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
		break;
		case "CasperAllFight":
			dialog.text = "Oui, je sais. Tout le clan vous est tombé dessus d'un coup : ils ont dמ entendre le bruit de votre combat. L'essentiel, c'est que vous ayez réussi. Je suis heureuse pour vous, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +".";
			link.l1 = "Merci, Armo.";
			link.l1.go = "exit";
			pchar.questTemp.LSC.Armo = 16; //чтобы диалога больше не было
		break;
		//Армо мертва
		case "ArmoIsDead":
			dialog.text = "Bonjour. Je vous connais, vous êtes "+ GetSexPhrase("ce nouveau citoyen avec qui", "cette nouvelle citoyenne avec qui") +" Armo était très amie.";
			link.l1 = "Oui, c'est ça.";
			link.l1.go = "ArmoIsDead_1";
		break;
		case "ArmoIsDead_1":
			dialog.text = "C'est dommage qu'Armo soit morte. Personne ne sait qui l'a tuée. Dans la taverne, on l'a seulement entendue crier à l'étage. Comme par hasard, il n'y avait personne à ce moment-là. Quand les gens sont accourus à son cri, elle gisait, la gorge tranchée, dans une mare de son propre sang...";
			link.l1 = "Armo est morte à cause de moi, c'est certain !";
			link.l1.go = "ArmoIsDead_2";
		break;
		case "ArmoIsDead_2":
			dialog.text = "Eh bien, les larmes ne guérissent pas le chagrin, comme on dit... Vous savez, en mémoire d'Armo, je vous appellerai comme elle : "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". דa ne vous dérange pas ?";
			link.l1 = "Bien sמr que non.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;
		//Если Армо жива, то даёт денег
		case "askMoney":
			dialog.text = "Vous avez besoin d'argent, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +" ? Et pour quoi faire ?";
			link.l1 = "Pour une chose très nécessaire à toute la Cité. C'est une question de vie ou de mort !";
			link.l1.go = "askMoney_1";
		break;
		case "askMoney_1":
			dialog.text = "Je vous crois, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". Je peux vous donner mes économies, d'autant que je n'en ai pas besoin.";
			link.l1 = "Vous m'obligeriez beaucoup, Armo.";
			link.l1.go = "askMoney_2";
		break;
		case "askMoney_2":
			dialog.text = "Cent mille, c'est tout ce que je peux vous offrir.";
			link.l1 = "Parfait !";
			link.l1.go = "askMoney_3";
		break;
		case "askMoney_3":
			dialog.text = "Alors prenez-les. Et je vous souhaite bonne chance.";
			link.l1 = "Merci, Armo !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 100000);
			npchar.quest.giveMoney = true;
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("De quelles marchandises parlons-nous, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +" ?",
				"Vous m'avez déjà posé la question.",
				"On m'a déjà demandé...",
                "Vous m'avez déjà interrogée sur ces marchandises. דa ne suffit pas ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de bombes, de boulets ramés, de vivres, de poudre, d'armes, de médicaments...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Pour les bombes et le reste, on peut demander aux maîtresses de maison des navires. Si vous ne les connaissez pas, ce sont Alice Taylor, Aurélie Bertin, Lea Toors et Eliza Calvo. Pour le reste, je n'en ai aucune idée.";
			link.l1 = "Je vois... Merci.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_MainLine", "48");
			AddQuestUserData("ISS_MainLine", "sName", GetFullName(npchar));
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = NPCStringReactionRepeat("Et alors ?",
				"Nous en avons déjà parlé.",
				"Nous en avons déjà discuté, je le répète pour la deuxième fois.",
                "Assez, je suis fatiguée...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Je veux vous inviter à rejoindre mon équipage.",
				"Ouais... Désolé, j'ai oublié.",
                "Comme vous voudrez...",
				"Bon, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekCrew_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekCrew_1":
			if (npchar.name == "Armo")
			{
				dialog.text = "Non, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". Thomas et moi restons en Ville.";
				link.l1 = "Qu'est-ce que votre Thomas vient faire là-dedans ?! En restant ici, vous risquez votre vie.";
				link.l1.go = "SeekCrew_2";
			}
			else
			{
				dialog.text = "Non, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +". Je reste ici, dans ma taverne.";
				link.l1 = "En restant ici, vous risquez votre vie.";
				link.l1.go = "SeekCrew_2";
			}
		break;
		case "SeekCrew_2":
			dialog.text = "Pourquoi ?";
			link.l1 = "La tempête qui approche va probablement détruire la Cité.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Il y en a déjà eu tant, de ces tempêtes ; nous survivrons bien à une de plus.";
			link.l1 = "Vous avez tort... Bon, d'accord, comme vous voudrez.";
			link.l1.go = "exit";
		break;
		//освобождение мужа Элис Тейлор
		case "ELTHusb_SF":
			dialog.text = "Je m'en souviens, "+ GetSexPhrase("monsieur le capitaine", "mademoiselle") +".";
			link.l1 = "Racontez-moi, je vous prie, comment ça s'est passé.";
			link.l1.go = "ELTHusb_SF_1";
		break;
		case "ELTHusb_SF_1":
			dialog.text = "Oui, il n'y a pas grand-chose à raconter. Taylor est resté chez nous trois heures et il est reparti « à quatre pattes ». Comme toujours, d'ailleurs.";
			link.l1 = "Compris... Il est parti seul ?";
			link.l1.go = "ELTHusb_SF_2";
		break;
		case "ELTHusb_SF_2":
			dialog.text = "Avec Gilles Baru, qui le tenait par le bras.";
			link.l1 = "Attendez. Il s'avère donc que Gilles Barou l'a raccompagné chez lui ?";
			link.l1.go = "ELTHusb_SF_3";
		break;
		case "ELTHusb_SF_3":
			dialog.text = "Eh bien, oui.";
			link.l1 = "Ah ! Merci, ma chère.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "8");
			pchar.questTemp.LSC.ElisHusband = "toZhilBaru";
		break;

	}
	NextDiag.PrevNode = NodeName;
}

