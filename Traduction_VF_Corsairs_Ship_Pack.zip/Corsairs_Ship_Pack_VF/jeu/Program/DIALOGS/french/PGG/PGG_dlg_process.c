void ProcessDialogEvent()
{
	int i, n, iPggRel;
	int iRnd = -1;
	int iAns;
	bool bOk;
	float locx, locy, locz;
	string sTmp, sLoc;
	ref NPChar, sld;
	aref link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	// LEO: у имени ПГГ — отношение (голова, NameBonusColor) + репутация (хвост, NameBonusTailColor), оба числа ГРАДИЕНТОМ 0..100; лейблы белым (\6), число \2 (сброс к градиенту сегмента).
	iPggRel = PGG_ChangeRelation2MainCharacter(NPChar, 0);
	NPChar.NameBonusColor = PGG_RelationColorRGB(iPggRel);
	NPChar.NameBonus = "\6(relation : \2" + iPggRel + "\6)";
	NPChar.NameBonusTailColor = PGG_RelationColorRGB(sti(NPChar.reputation));
	NPChar.NameBonusTail = "\6 (rép. : \2" + sti(NPChar.reputation) + "\6)";

	InitDynamicValues(NPChar);

  ProcessDuelDialog(NPChar, link, NextDiag);

	if (Dialog.CurrentNode == "First time" && CheckAttribute(NPChar, "meeting")) Dialog.CurrentNode = "Second time";

	switch(Dialog.CurrentNode)
	{
	case "Enemy_town":
		PGG_Dlg_Meet(NPChar, link, NextDiag);
		break;
	case "First time":
		PGG_Dlg_Meet(NPChar, link, NextDiag);
		break;
	case "Second time":
		PGG_Dlg_Meet(NPChar, link, NextDiag);
		break;
	case "PGG_ThanksForHelp": // LEO: PGG thanks for help in the sea skirmish (deck dialog)
		PGG_Dlg_Meet(NPChar, link, NextDiag);
		break;
	case "Exit_PGG_ThanksForHelp":
		if (CheckAttribute(NPChar, "PGG_PlayerHelped") && sti(NPChar.PGG_PlayerHelped) == 1)
		{
			PGG_ChangeRelation2MainCharacter(NPChar, 5); // +5 only if player/companion actually sank pirates (flag set by ShipDead)
		}
		DeleteAttribute(NPChar, "PGG_PlayerHelped");
		DeleteAttribute(NPChar, "DeckDialogNode");
		NextDiag.CurrentNode = "Second time";
		DialogExit();
		break;
	case "officer":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "officer_hired":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "companion":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "companion_pay":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "officer_pay":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "companion_leave":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "companion_stay":
		PGG_Dlg_Hire(NPChar, link, NextDiag);
		break;
	case "Exit_Companion_Leave":
		chrDisableReloadToLocation = false;
		RemoveCharacterCompanion(PChar, NPChar);

		NPChar.PGGAi.IsPGG = true;
		NPChar.RebirthPhantom = true;
		NPChar.PGGAi.location.town = PGG_TownForRelease(NPChar);

		LAi_SetWarriorTypeNoGroup(NPChar);
		NextDiag.CurrentNode = "Second Time";
		DialogExit();
		break;

	case "Exit_Companion_Stay":
		GetCharacterPos(NPChar, &locx, &locy, &locz);
		sTmp = LAi_FindNearestFreeLocator("reload", locx, locy, locz);
		LAi_ActorGoToLocation(NPChar, "reload", sTmp, "none", "", "", "", 5.0);

		AddMoneyToCharacter(PChar, -(makeint(NPChar.Quest.Companion.Price)));
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		break;

//==================================================
// Quests
//==================================================
//==== BETTA_TEST ====
	case "BT_Quest":
		PGG_Dlg_BT(NPChar, link, NextDiag);
		break;
	case "BT_Quest_1":
		PGG_Dlg_BT(NPChar, link, NextDiag);
		break;
	case "BT_Quest_2":
		PGG_Dlg_BT(NPChar, link, NextDiag);
		break;
	case "quest":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "quest_onStay":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Meeting":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Work":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Work_1":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_NotWork":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Work_2":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_AfterTavernTalk":
		PChar.GenQuest.PGG_Quest = 1;
		PChar.GenQuest.PGG_Quest.Stage = 0;
		PChar.GenQuest.PGG_Quest.PGGid = NPChar.id;

		Group_AddCharacter("PGGQuest", NPChar.id);
		Group_SetGroupCommander("PGGQuest", NPChar.id);
		Group_SetAddress("PGGQuest", Islands[GetCharacterCurrentIsland(PChar)].id, "Quest_Ships", "Quest_Ship_1");
		Group_SetTaskNone("PGGQuest");

		SetTimerConditionParam("PGGQuest1_RemoveShip_Timer", "PGGQuest1_RemoveShip_Timer", 0, 0, 0, MakeInt(GetHour() + 6), false);
		PChar.Quest.PGGQuest1_RemoveShip_Timer.function = "PGG_Q1RemoveShip";

		NPChar.Ship.Mode = "Pirate";
		NPChar.DeckDialogNode = "Quest_1_Ship";
		NPChar.Nation.Bak = NPChar.Nation;
		NPChar.Nation = GetCityNation(GetCurrentTown());
		NPChar.AlwaysFriend = true;
		NPChar.Abordage.Enable = false; //нельзя брать на абордаж
		SetCharacterRelationBoth(sti(PChar.index), sti(NPChar.index), RELATION_FRIEND);

		ReOpenQuestHeader(PGGQuestID);
		if (isPGGInitiative) {
			AddQuestRecord(PGGQuestID, "q1_Tavern");
		} else {
			AddQuestRecord(PGGQuestID, "q1_Tavern_1");
			AddQuestUserData(PGGQuestID, "sSex", GetSexPhrase("", "e"));
		}
		AddQuestUserData(PGGQuestID, "sShipName", NPChar.Ship.Name);
		AddQuestUserData(PGGQuestID, "sPGGName", GetFullName(NPChar));

		NextDiag.CurrentNode = "Quest_1_Work_2";
		DialogExit();
		if (NPChar.Chr_Ai.Type == "actor") 	LAi_ActorGoToLocation(NPChar, "reload", "reload1_back", "none", "", "", "", 20);

		break;

	case "Quest_1_Ship":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Ship_1":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Ship_Detail":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Ship_Detail_1":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Ship_Accept":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_Accept":
		ReOpenQuestHeader(PGGQuestID);

		PGG_Disband_Fleet(NPChar);
		if (sti(PChar.GenQuest.PGG_Quest.Stage) < 2)
		{
			PChar.GenQuest.PGG_Quest.Stage = 2;
			PGG_Q1AcceptedQuestDeleteFantom("");
			Map_ReleaseQuestEncounter(NPChar.id);
			group_DeleteGroup(NPChar.id+"_Group");
			if (sti(PChar.GenQuest.PGG_Quest.Template))
			{
				PGG_Q1PlaceShipsNearIsland();
			}
			else
			{
				Locations[FindLocation(PChar.GenQuest.PGG_Quest.Island.Shore)].DisableEncounters = true;

				PChar.Quest.PGGQuest1_CheckStartState.win_condition.l1 = "Location";
				PChar.Quest.PGGQuest1_CheckStartState.win_condition.l1.Location = PChar.GenQuest.PGG_Quest.Island.Shore;
				PChar.Quest.PGGQuest1_CheckStartState.function = "PGG_Q1CheckStartState";
			}
			PChar.Quest.PGGQuest1_PGGDead.win_condition.l1 = "NPC_Death";
			PChar.Quest.PGGQuest1_PGGDead.win_condition.l1.Character = PChar.GenQuest.PGG_Quest.PGGid;
			PChar.Quest.PGGQuest1_PGGDead.function = "PGG_Q1PGGDead";

			SetTimerCondition("PGGQuest1_Time2Late", 0, 0, sti(PChar.GenQuest.PGG_Quest.Days), false);
			PChar.Quest.PGGQuest1_Time2Late.function = "PGG_Q1Time2Late";

			NPChar.PGGAi.IsPGG = false;
			NPChar.PGGAi.location.town = "none";
			NPChar.CompanionEnemyEnable = true;
			DeleteAttribute(NPChar, "PGGAi.Task");
			DeleteAttribute(NPChar, "PGGAi.LockService");
			DeleteAttribute(NPChar, "AlwaysFriend");

			SetCompanionIndex(PChar, -1, sti(NPChar.index));
			SetCharacterRemovable(NPChar, false);

			SetBaseShipData(NPChar);
			DeleteAttribute(NPChar, "ship.sails");
			RepairMasts(NPChar);
			DeleteAttribute(NPChar, "ship.blots");

			Fantom_SetCannons(NPChar, "pirate");
			Fantom_SetBalls(NPChar, "pirate");
		}
		NextDiag.CurrentNode = "Quest_1_Ship_Accept";
		DialogExit();
		break;

	case "Quest_1_Ship_Refuse":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_Refuse":
		if (sti(PChar.GenQuest.PGG_Quest.Stage) != -1)
		{
			PChar.GenQuest.PGG_Quest.Stage = -1;
			PChar.Quest.PGGQuest1_RemoveShip.win_condition.l1 = "ExitFromLocation";
			PChar.Quest.PGGQuest1_RemoveShip.win_condition.l1.Location = PChar.location;
			PChar.Quest.PGGQuest1_RemoveShip.function = "PGG_Q1RemoveShip";

			AddQuestRecord(PGGQuestID, "q1_Close");
			AddQuestUserData(PGGQuestID, "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader(PGGQuestID);
			
			DeleteAttribute(NPChar, "AlwaysFriend");
			SaveCurrentQuestDateParam("QuestTalk");
		}
		NPChar.Dialog.CurrentNode = "Quest_1_Ship_Refuse";
		NPChar.DeckDialogNode = "Quest_1_Ship_Refuse";
		DialogExit();
		break;

	case "Quest_1_Ship_BadWay":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_Ship_BadWay_1":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_DeckFight":
		GetCharacterPos(NPChar, &locx, &locy, &locz);
		DeleteAttribute(NPChar, "AlwaysFriend");
		LAi_SetImmortal(NPChar, true);
		LAi_SetActorType(NPChar);

		sTmp = LAi_FindNearestFreeLocator("reload", locx, locy, locz);
		LAi_ActorRunToLocation(NPChar, "reload", sTmp, "none", "", "", "", 5.0);
		LAi_LocationFightDisable(&Locations[FindLocation(PChar.location)], false);

		//группа может быть занята, а проверок по группам у нас нет... :(
		if (!CheckAttribute(PChar, "questTemp.PGGContra.Know")) sTmp = "PGGTmp";
		else sTmp = "PGGQst";
		PChar.GenQuest.PGG_Quest.GrpID = sTmp;

		for (i=1; i<5; i++)
		{
			sld = CharacterFromID("saylor_0" + i);
			LAi_group_MoveCharacter(sld, sTmp);
		}
		LAi_group_FightGroups(LAI_GROUP_PLAYER, sTmp, true);
		LAi_group_SetCheck(sTmp, "PGG_Q1AfterDeckFight");
		chrDisableReloadToLocation = true;

		PGG_ChangeRelation2MainCharacter(NPChar, -20);
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		LAi_SetFightMode(PChar, true);
		break;

	case "Quest_1_Time2Late":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_2Late":
		LAi_SetPlayerType(PChar);
		if (sti(PChar.GenQuest.PGG_Quest.Stage) != -1)
		{
			PChar.GenQuest.PGG_Quest.Stage = -1;
			RemoveCharacterCompanion(PChar, NPChar);

			NPChar.PGGAi.IsPGG = true;
			NPChar.RebirthPhantom = true;

			LAi_SetWarriorTypeNoGroup(NPChar);
			LAi_group_MoveCharacter(NPChar, "GroupDeck");

			PChar.Quest.PGGQuest1_Clear.win_condition.l1 = "ExitFromLocation";
			PChar.Quest.PGGQuest1_Clear.win_condition.l1.Location = PChar.location;
			if (PChar.location == "Ship_deck") PChar.quest.Munity = "Deads";
			PChar.Quest.PGGQuest1_Clear.function = "PGG_Q1EndClear";
		}
		NextDiag.CurrentNode = "Quest_1_Failed";
		DialogExit();
		break;

	case "Quest_1_CheckResult":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_NotPay":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_Failed":
		if (sti(PChar.GenQuest.PGG_Quest.Stage) != -1)
		{
			AddMoneyToCharacter(PChar, -(sti(PChar.GenQuest.PGG_Quest.FailedPaySum)));
			AddQuestRecord(PGGQuestID, "q1_FailPay");
			AddQuestUserData(PGGQuestID, "sPsName", GetFullName(NPchar));
		}
		ChangeCharacterReputation(NPChar, 10);
		CloseQuestHeader(PGGQuestID);
		RemoveCharacterCompanion(PChar, NPChar);

		if (PChar.Location == "Ship_deck")
		{
			PChar.Quest.PGGQuest1_FailedExitSea.win_condition.l1 = "ExitFromSea";
			PChar.Quest.PGGQuest1_FailedExitSea.function = "PGG_Q1EndClear";
		}
		else
		{
			PChar.Quest.PGGQuest1_FailedExitLoc.win_condition.l1 = "ExitFromLocation";
			PChar.Quest.PGGQuest1_FailedExitLoc.win_condition.l1.Location = PChar.location;
			PChar.Quest.PGGQuest1_FailedExitLoc.function = "PGG_Q1EndClear";
		}
		PGG_ChangeRelation2MainCharacter(NPChar, -10);

		LAi_SetImmortal(NPChar, true);
		//что б не били сопровождение.
		for (i = 1; i < sti(PChar.GenQuest.PGG_Quest.GrpID.Qty); i++)
		{
			sld = CharacterFromID("pirate_" + i);
			LAi_SetImmortal(sld, true);
		}

		NextDiag.CurrentNode = "Quest_1_Failed";
		DialogExit();
		if (NPChar.Chr_Ai.Type == "actor") LAi_SetWarriorTypeNoGroup(NPChar);
		break;

	case "Quest_1_Failed":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Quest_1_End":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
	case "Exit_Quest_1_FailedFight":
		RemoveCharacterCompanion(PChar, NPChar);

		ChangeCharacterReputation(NPChar, -5);
		LAi_LockFightMode(PChar, false);
		LAi_LocationFightDisable(&Locations[FindLocation(PChar.location)], false);
		LAi_group_SetRelation("PGGTmp", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
		LAi_group_FightGroups(LAI_GROUP_PLAYER, "PGGTmp", true);
		LAi_group_SetCheck("PGGTmp", "PGG_Q1AfterDeckFight");

		PChar.GenQuest.PGG_Quest.GrpID = "PGGTmp";
		chrDisableReloadToLocation = true;

		Group_AddCharacter("PGGQuest", NPChar.id);
		Group_SetGroupCommander("PGGQuest", NPChar.id);
		Group_SetAddress("PGGQuest", PChar.GenQuest.PGG_Quest.GrpLocation, "Quest_Ships", PChar.GenQuest.PGG_Quest.GrpLoc);
		Group_SetTaskNone("PGGQuest");

		PGG_ChangeRelation2MainCharacter(NPChar, -15);

		GetCharacterPos(NPChar, &locx, &locy, &locz);
		NextDiag.CurrentNode = "Second Time";
		DialogExit();

		sTmp = LAi_FindNearestFreeLocator("reload", locx, locy, locz);
		Log_TestInfo("go to loc " + sTmp + " " + NPChar.location);
		if (PChar.location != "Ship_Deck") sTmp = "sea";
		NPChar.location = PChar.location;

		PChar.questTemp.Chr2Remove = NPChar.id;
		LAi_ActorRunToLocator(NPChar, "reload", sTmp, "RemoveCharacterFromLocation", 5.0);

		LAi_SetImmortal(NPChar, true);
		LAi_SetFightMode(PChar, true);
		break;

	case "Exit_Quest_1_End":
		DeleteAttribute(NPChar, "Greed");
		RemoveCharacterCompanion(PChar, NPChar);
		ChangeCharacterReputation(PChar, 5);
		PGG_ChangeRelation2MainCharacter(NPChar, 30);
		NPChar.PGGAi.location.town = PGG_FindRandomTownByNation(sti(NPChar.nation));
		NPChar.PGGAfterShare = true;
		NPChar.PGGAi.AfterSail.TaskCounter = 0;
		i = sti(PChar.GenQuest.PGG_Quest.Goods.Part);
		RemoveCharacterGoods(PChar, sti(PChar.GenQuest.PGG_Quest.Goods), i);
		PChar.Quest.PGGQuest1_EndExitLoc.win_condition.l1 = "ExitFromLocation";
		PChar.Quest.PGGQuest1_EndExitLoc.win_condition.l1.Location = PChar.location;
		PChar.Quest.PGGQuest1_EndExitLoc.function = "PGG_Q1EndClear";
		AddQuestRecord(PGGQuestID, "q1_OkShare");
		CloseQuestHeader(PGGQuestID);

		//что б не били сопровождение.
		for (i = 1; i < sti(PChar.GenQuest.PGG_Quest.GrpID.Qty); i++)
		{
			sld = CharacterFromID("pirate_" + i);
			LAi_SetImmortal(sld, true);
		}

		LAi_SetImmortal(NPChar, true);
		NextDiag.CurrentNode = "Quest_1_End";
		DialogExit();
  		LAi_SetWarriorType(NPChar); // сброс группы ГГ
		LAi_group_MoveCharacter(NPChar, LAI_GROUP_PLAYER);
		break;

	case "Quest_1_SharePrise":
		PGG_Dlg_Quest(NPChar, link, NextDiag);
		break;
		case "Quest_1_NotPayShore":
			PGG_Dlg_Quest(NPChar, link, NextDiag);
			break;
		case "Exit_Quest_1_AllyFight":
			RemoveCharacterCompanion(PChar, NPChar);
			LAi_SetImmortal(NPChar, true);
			LAi_LocationFightDisable(&Locations[FindLocation(PChar.location)], false);
			LAi_LockFightMode(PChar, false);
			LAi_SetFightMode(PChar, true);
			for(i = 0; i < LAi_numloginedcharacters; i++)
			{
				int idx1 = LAi_loginedcharacters[i];
				if(idx1 >= 0)
				{
					//Пропустим главного персонажа или офицера
					if(idx1 == nMainCharacterIndex) continue;
					sld = &Characters[idx1];
					if (CheckAttribute(sld,"wouldfight")) LAi_group_MoveCharacter(sld, "PGGAlly");
				}
			}
			LAi_group_SetRelation("PGGAlly", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(LAI_GROUP_PLAYER, "PGGAlly", true);
			chrDisableReloadToLocation = true;
			LAi_group_SetCheck("PGGAlly", "OpenTheDoors");
			PChar.GenQuest.PGG_Quest.GrpID = "PGGAlly";
			NextDiag.CurrentNode = "Second Time";
			PChar.questTemp.Chr2Remove = NPChar.id;
			AddDialogExitQuestFunction("RunToBoat");
			DeleteAttribute(PChar, "GenQuest.PGG_Quest");
			DialogExit();
		break;
//===================================
//              Exits
//===================================
	case "Exit":
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		if (NPChar.Chr_Ai.Type == "actor") LAi_SetWarriorTypeNoGroup(NPChar);
		break;

	case "Exit_PIRATES":
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		LAi_SetPlayerType(PChar);
		break;

	case "Exit_2":
		if (CheckAttribute(PChar, "GenQuest.PGG_Quest")) DeleteAttribute(PChar, "GenQuest.PGG_Quest");
		NextDiag.CurrentNode = NextDiag.TempNode;
		DialogExit();
		if (NPChar.Chr_Ai.Type == "actor") LAi_SetWarriorTypeNoGroup(NPChar);
		break;

	case "Exit_Smugglers_Fight":
		NextDiag.CurrentNode = "Second Time";
		DialogExit();
		NPChar.willDie = true;
		CloseQuestHeader("Gen_StrangeInfo");
		LAi_group_FightGroups(LAI_GROUP_PLAYER, "PGGTmp", true);
		LAi_SetFightMode(PChar, true);
		break;

	case "Exit_ShowParam":
		NextDiag.CurrentNode = "Second Time";
		DialogExit();

		PChar.SystemInfo.OnlyShowCharacter = true;
		LaunchCharacter(NPChar);
		break;
	}
}


// PGG_Dlg_Meet: extracted conversation cases (dispatched from main switch)
void PGG_Dlg_Meet(ref NPChar, aref link, aref NextDiag)
{
	int i, n; int iRnd = -1; int iAns; bool bOk; float locx, locy, locz; string sTmp, sLoc; ref sld;
	switch(Dialog.CurrentNode)
	{
	case "Enemy_town":
		Dialog.text = "Hum... Je suis un casse-cou, bien sמr, mais c'est risqué... Eh bien, non, je vais suivre ma propre route...";
		link.l1 = RandPhraseSimple("Eh... Tant pis...", "Bonne journée.");
		link.l1.go = "Exit";
		break;

	case "PGG_ThanksForHelp": // LEO: thanks for help in the sea skirmish against pirates
		Dialog.Text = RandPhraseSimple(
			"Mille diables, " + GetFullName(PChar) + " ! Vous tombez à pic : sans vos canons, ces chiens auraient envoyé mon navire par le fond. Je vous dois une fière chandelle !",
			"Par le diable des mers en personne, " + GetFullName(PChar) + " ! Sans vous et vos canons, je nourrirais les poissons à l'heure qu'il est. Je ne l'oublierai jamais !"
		);
		link.l1 = "C'était un plaisir de vous aider.";
		link.l1.go = "Exit_PGG_ThanksForHelp";
		break;

	case "First time":
		if (!CheckAttribute(PChar, "questTemp.DuelTimer"))
		{//Запускаем счётчик для отката
			PChar.questTemp.DuelTimer = true;
			SaveCurrentQuestDateParam("PChar.questTemp.DuelCooldown");
		}

		if (CheckAttribute(NPChar, "PGGAi.location.town.back") && CheckAttribute(PChar, "questTemp.PGGContra.Know"))
		{
			ContrabandDialog(link);
			break;
		}

		if(rand(10) == 0)
		{
			iRnd = rand(MAX_PGG_QUEST_STORIES - 1);
			Dialog.Text = PGG_QuestStories[iRnd];
		}
		else {
			iRnd = rand(MAX_PGG_STORIES - 1);
			iAns = rand(MAX_PGG_MEET_REP - 1);
			Dialog.Text = PGG_Stories[iRnd] + LinkRandPhrase("... Que le diable m'emporte !.. ", "...Qu'un serpent me morde !.. ", "... Retenez-moi, ou je fais un malheur !.. ") + PCharRepPhrase(PGG_Meet_BadRep[iAns], PGG_Meet_GoodRep[iAns]);
		}

		if (sti(PChar.Ship.Type) != SHIP_NOTUSED) {
			link.l1 = PCharRepPhrase(
				RandSwear() + RandPhraseSimple(
					"Je suis le capitaine " + GetFullName(PChar) + ".",
					"Je commande le navire '" + PChar.Ship.Name + "' et une bonne centaine de fils de chienne prêts à tout ! Héhé ! Je m'appelle " + GetFullName(PChar) + "."
				),
				RandPhraseSimple(
					"Permettez-moi de me présenter : capitaine " + GetFullName(PChar) + ".", 
					"Nous n'avons pas encore été présentés. Je commande le navire '" + PChar.Ship.Name + "', qui bat pavillon de " + NationNameGenitive(sti(PChar.nation)) + " ; mon nom est " + GetFullName(PChar) + "."
				)
			);
		} else {
			link.l1 = "Permettez-moi de me présenter : je m'appelle " + GetFullName(PChar) + ". Le hasard a voulu que je me retrouve sans navire.";
		}

		link.l1.go = "Second time";
		NPChar.onceGreeting = true;
		NPChar.meeting = true;
		break;

	case "Second time":
		if (CheckAttribute(NPChar, "PGGAi.location.town.back") && CheckAttribute(PChar, "questTemp.PGGContra.Know")) {
			ContrabandDialog(link);
			break;
		}
		
		// если репа позволяет, общаемся по-человечески
		if (PGG_ChangeRelation2MainCharacter(NPChar, 0) >= PGG_REL_FRIENDLY)
		{
			iRnd = rand(MAX_PGG_STORIES - 1);
			iAns = rand(MAX_PGG_MEET_REP - 1);
			Dialog.Text = PGG_Stories[iRnd] + PCharRepPhrase(PGG_Meet_BadRep[iAns], PGG_Meet_GoodRep[iAns]) + 
				RandPhraseSimple("Quelles nouvelles ?", "Quoi de neuf dans l'archipel ?");

			if(rand(10) == 0)
			{
				iRnd = rand(MAX_PGG_QUEST_STORIES - 1);
				Dialog.Text = PGG_QuestStories[iRnd] + PCharRepPhrase("Quelles nouvelles ?", "Quoi de neuf dans l'archipel ?");
			}
		} else {
			Dialog.text = RandPhraseSimple(
				"Qu'est-ce qu'il vous faut" + GetFullName(PChar) + " ?", 
				RandPhraseSimple(
					"Qui est-ce ? Oh, vous... Fichez le camp, je ne suis pas d'humeur...", 
					"Oh, c'est vous... Passez votre chemin, je ne suis pas d'humeur..."
				)
			);
		}

		link.l1 = "Et cette affaire ?";
		link.l1.go = "quest";


		link.lgame = "Vous ne voulez pas vous détendre ?";
		link.lgame.go = "Play_Game";

		if(!CheckAttribute(PChar, "PGG_hired"))
		{
			if (sti(PChar.Ship.Type) != SHIP_NOTUSED && sti(NPChar.Ship.Type) != SHIP_NOTUSED)
			{
				link.l2 = "J'ai réfléchi... Vous voulez vous joindre à moi ? " + 
					"א deux navires, nous pourrions faire de belles choses.";
				link.l2.go = "companion";
			}

			if (sti(NPChar.Ship.Type) == SHIP_NOTUSED)
			{
				link.l3 = RandPhraseSimple(
					"Voulez-vous rejoindre mon navire comme officier ?", 
					"Un officier comme vous pourrait bien m'être utile. Qu'en dites-vous ?"
				);
				link.l3.go = "officer";
			}
		}

		// потерял корабль, переопределяем все выше сказанное
		if (sti(NPChar.Ship.Type) == SHIP_NOTUSED) {
			Dialog.Text = RandPhraseSimple(
				"Oh, malheur à moi, malheur à moi... Mon navire est au fond !", 
				"Qui vois-je ?! Quel bon vent vous amène dans nos parages ? Mais je me retrouve sans navire..."
			);
		}

		// первый раз встретили, переопределяем все выше сказанное
		if (CheckAttribute(NPChar, "onceGreeting")) {
			Dialog.Text = "Allons, tout le monde ici me connaît ! Je suis " + GetFullName(NPChar);
			if (sti(NPChar.Ship.Type) != SHIP_NOTUSED) {
				Dialog.Text = Dialog.Text + ", capitaine de " + XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen") + " '" + NPChar.Ship.Name + "'";
			}
			Dialog.Text = Dialog.Text + ". C'est un plaisir, que puis-je faire pour vous" + NPCharSexPhrase(NPChar, "ous", "ous") + " ?";
			DeleteAttribute(NPChar, "onceGreeting");
		}
		
		if (bBettaTestMode)
		{
			link.l5 = "(Bêta-test) Quêtes.";
			link.l5.go = "BT_Quest";
			link.l6 = "(Bêta-test) Duels.";
			link.l6.go = "outraged";
		}

		if (GetQuestPastDayParam("PChar.questTemp.DuelCooldown") >= 3 || bBettaTestMode)
		{
			if (sti(PChar.reputation < PGG_REP_LOW) && PGG_ChangeRelation2MainCharacter(NPChar, 0) <= PGG_REL_FRIENDLY && !isSetSail && GetCurrentTown() != "Pirates")
			{
				link.l8 = PCharRepPhrase(
					"Cette taverne est trop petite pour nous deux. Je veux que vous disparaissiez.",
					"Si tu savais à qui tu parles, tu chanterais sur un autre ton, " + NPCharSexPhrase(NPChar, "salaud", "traînée du port") + "."
				);
				link.l8.go = "outraged";
			}
		}

		link.l9 = "Pas mal.";
		link.l9.go = "exit";
		NextDiag.TempNode = "Second time";
		break;


//==================================================
// Officer
//==================================================
	}
}

// PGG_Dlg_Hire: extracted conversation cases (dispatched from main switch)
void PGG_Dlg_Hire(ref NPChar, aref link, aref NextDiag)
{
	int i, n; int iRnd = -1; int iAns; bool bOk; float locx, locy, locz; string sTmp, sLoc; ref sld;
	switch(Dialog.CurrentNode)
	{
	case "officer":
		//раз в день.
		if (CheckAttribute(NPChar, "Officer_Talk") && GetNpcQuestPastDayParam(NPChar, "Officer_Talk") < 1 && !bPGGLogShow && !CheckAttribute(NPChar, "HiringMoneyPaid"))
		{
			Dialog.Text = RandPhraseSimple(
				"Je vous ai déjà dit que ça ne m'intéressait pas.", 
				"Je croyais que nous avions déjà tout réglé."
			);
			link.l1 = RandPhraseSimple("Comment ai-je pu l'oublier ?!", "C'est vrai. Bon, salut.");
			link.l1.go = "exit";
			break;
		}

		//если уже был офицером, то посылает нафиг.
		if (CheckAttribute(NPChar, "PGGAi.Officer"))
		{
			Dialog.Text = RandPhraseSimple("Hum... sans doute pas. Je n'ai pas envie de recommencer.", "Et vous croyez que je vais mordre deux fois à l'hameçon ?!!");
			link.l1 = RandPhraseSimple("Comme vous voudrez...", "Eh bien... prenez soin de vous.");
			link.l1.go = "exit";
			break;
		}

		//если отношение ниже 70, то в 70 процентов случаев откажет...
		if (PGG_ChangeRelation2MainCharacter(NPChar, 0) < PGG_REL_HIRE_MIN && drand(100) < 70)
		{
			Dialog.Text = RandPhraseSimple("Hum.. Plutכt non...", "Non, ce n'est pas pour moi ! Je ne veux pas être officier !");
			link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Eh bien, bonne continuation.");
			link.l1.go = "exit";
			NPChar.HiringMoney = sti(NPChar.rank)*PGG_HIRE_FORCE_PRICE_PER_RANK;
			link.l2 = "Alors je vais vous faire une offre que vous ne pourrez plus refuser : " + NPChar.HiringMoney +  " piastres.";
			link.l2.go = "officer_pay";

			SaveCurrentNpcQuestDateParam(NPChar, "Officer_Talk");
			break;
		}
		
		if (FindFreeRandomOfficer() < 1)
		{
			Dialog.Text = RandPhraseSimple(
				"Oui, vous avez déjà votre effectif complet.", 
				"Je ne pense pas que vous ayez l'étoffe pour me commander."
			);
			link.l1 = RandPhraseSimple("Dommage...", "Ce n'est donc pas le destin.");
			link.l1.go = "exit";
			
			SaveCurrentNpcQuestDateParam(NPChar, "Officer_Talk");
			break;
		}

		if (!CheckAttribute(NPChar, "Quest.Officer.Price")) NPChar.Quest.Officer.Price = 10000 + sti(NPChar.rank)*500*MOD_SKILL_ENEMY_RATE*3 - MakeInt(GetSummonSkillFromNameToOld(PChar, SKILL_COMMERCE)*1000);
		
		Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
			RandPhraseSimple(
				"C'est ce qu'il vous faut ! Nos lames boiront le sang ennemi ! Un seul problème : j'ai besoin de " + NPChar.Quest.Officer.Price + " piastres pour payer mes dettes.",
				"Vous avez l'air d'un vrai loup de mer. Et si vous acceptez de payer " + NPChar.Quest.Officer.Price + " piastres, alors nous pourrons peut-être travailler ensemble."
			),
			LinkRandPhrase(
				"Votre offre me flatte beaucoup. J'accepte, pour la somme très raisonnable de " + NPChar.Quest.Officer.Price + " piastres.",
				"Hum... Vous avez l'air d'avoir navigué. Je devrais peut-être accepter l'offre, si vous acceptez de me payer " + NPChar.Quest.Officer.Price + " piastres.",
				"Je pense que nous allons travailler ensemble, capitaine. En tout, " + NPChar.Quest.Officer.Price + " piastres, et nous topons là."
			)
		);

		MakeRandomLinkOrderTwo(link, 
			PCharRepPhrase(RandSwear() + 
				RandPhraseSimple(
					"דa me convient. Mais j'espère que vous n'exigerez pas autant chaque jour.", 
					"C'est sacrément cher, mais je pense que vous le valez."
				),
				LinkRandPhrase(
					"D'accord. Considérez-vous comme enrכlé dans l'équipage.", 
					"Hum... Je crois que je peux me séparer de cette somme.", 
					"On dirait que vous valez cet argent. Tenez !"
				)
			), "officer_hired",
			PCharRepPhrase(RandSwear() + 
				RandPhraseSimple(
					"Vous ne valez pas autant. Adieu...", 
					"C'est sacrément cher, je ne vais pas jeter autant d'argent par les fenêtres."
				),
				LinkRandPhrase(
					"Ouais... La cupidité n'est pas un vice...", 
					"Vous vous moquez de moi ? Pour une telle somme, je peux m'acheter une douzaine de types comme vous.", 
					"C'est du vol... Oם voulez-vous que je trouve une telle somme ?"
				)
			), "exit"
		);

		link.l3 = "Hum... Et vous, qu'est-ce que vous valez ?";
		link.l3.go = "Exit_ShowParam";
		break;

	case "officer_hired":
		if (!CheckAttribute(NPChar, "HiringMoneyPaid") && sti(PChar.money) < sti(NPChar.Quest.Officer.Price))
		{
			Dialog.Text = "On dirait que vous avez un problème d'argent, capitaine.";
			link.l1 = "Ah... En effet.";
			link.l1.go = "exit";
			break;
		}

		Restore_PGG(NPChar);
		PChar.questTemp.HiringOfficerIDX = NPChar.index;
		if (NPChar.model.animation == "man" || NPChar.model.animation == "YokoDias" || NPChar.model.animation == "Milenace") NPChar.CanTakeMushket = true;
		if(NPChar.model == "PGG_Whisper_6") EquipCharacterByItem(NPChar, "suit_1");
		if (!CheckAttribute(NPChar, "HiringMoneyPaid")) AddMoneyToCharacter(PChar, -(makeint(NPChar.Quest.Officer.Price)));
		AddDialogExitQuestFunction("PGG_BecomeHiredOfficer");
		NPChar.loyality = MakeInt(PGG_ChangeRelation2MainCharacter(NPChar, 0)*0.3)

		if (NPChar.sex == "woman") {
			NPChar.greeting = "Gr_Danielle";
		}

		DeleteAttribute(NPChar, "Quest.Officer");
		DeleteAttribute(NPChar, "PGGAi.Task");
		DeleteAttribute(NPChar, "PGGAi.LockService");
		
		Dialog.Text = RandPhraseSimple("Parfait !", "Je n'ai jamais douté de vous, capitaine.");
		link.l1 = "Ne soyez pas en retard pour le départ.";
		link.l1.go = "exit";
		break;

//==================================================
// Companion
//==================================================
	case "companion":
		//раз в день.
		if (CheckAttribute(NPChar, "Companion_Talk") && GetNpcQuestPastDayParam(NPChar, "Companion_Talk") < 1 && !bPGGLogShow  && !CheckAttribute(NPChar, "HiringMoneyPaid"))
		{
			Dialog.Text = RandPhraseSimple("Je vous ai déjà dit que ça ne m'intéressait pas.", "Je croyais que nous avions tout réglé.");
			link.l1 = RandPhraseSimple("Comment ai-je pu l'oublier ?!", "C'est vrai. Bon, salut.");
			link.l1.go = "exit";
			break;
		}

		// если разница в кораблях больше 1 класса, отказываем
		if (GetCharacterShipClass(PChar) - 1 > GetCharacterShipClass(NPChar))
		{
			Dialog.Text = RandPhraseSimple("Naviguer avec vous !?? Trouvez-vous un navire plus gros !", "Je ne pense pas que ça m'intéresse !");
			link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Eh bien, bonne continuation.");
			link.l1.go = "exit";

			SaveCurrentNpcQuestDateParam(NPChar, "Companion_Talk");
			break;
		}

		if (GetCompanionQuantity(PChar) >= COMPANION_MAX) {
			MaxCompanionsExceededDialog(link, NPChar)
			SaveCurrentNpcQuestDateParam(NPChar, "Companion_Talk");
			break;
		}

		//если отношение ниже 70, то в 100 процентов случаев откажет...
		if (PGG_ChangeRelation2MainCharacter(NPChar, 0) < PGG_REL_HIRE_MIN)
		{
			Dialog.Text = RandPhraseSimple(
				"Hum.. Sans doute pas... Je ne vous connais pas du tout. Pour commencer, nous devrions faire une affaire ensemble, un de ces jours.", 
				"Non, merci. Je n'aime pas naviguer sous les ordres d'un autre. Et je ne vous connais pas du tout. Il faudrait d'abord faire une affaire ensemble avant de nous faire de telles propositions."
			);
			link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Eh bien, bonne continuation.");
			link.l1.go = "exit";
			NPChar.HiringMoney = sti(NPChar.rank)*PGG_HIRE_FORCE_PRICE_PER_RANK;
			link.l2 = "Alors je vais vous faire une offre que vous ne pourrez plus refuser : "+ NPChar.HiringMoney+ " piastres.";
			link.l2.go = "companion_pay";

			SaveCurrentNpcQuestDateParam(NPChar, "Companion_Talk");
			break;
		}

		SetCompanionIndex(PChar, -1, sti(NPChar.index));
		Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
			RandPhraseSimple(
				"Vous me plaisez ! Marché conclu ! J'entends déjà les piastres tinter dans nos poches !",
				"T'es pas mal, "+ GetSexPhrase("le gars", "la fille") +"... Je crois qu'on va travailler ensemble !"
			),
			LinkRandPhrase(
				"Votre proposition me plaît. J'accepte.",
				"C'est intéressant. Moi aussi, je pense qu'ensemble, nous pouvons faire plus !", 
				"דa pourrait être intéressant. Marché conclu."
			)
		);
		link.l1 = RandPhraseSimple("Parfait, je vous attends en mer !", "Marché conclu ! Nous allons faire une sacrée équipe.");
		link.l1.go = "exit";

		Restore_PGG(NPChar);
		NPChar.PGGAi.IsPGG = false;
		NPChar.PGGAi.location.town = "none";
		NPChar.Dialog.TempNode = "hired";
		NPChar.Dialog.FileName = "Enc_Officer_dialog.c";
		NPChar.Payment = true;
		NPChar.Money   = 0;

		if (NPChar.model.animation == "man" || NPChar.model.animation == "YokoDias" || NPChar.model.animation == "Milenace") NPChar.CanTakeMushket = true;
		if(NPChar.model == "PGG_Whisper_6") EquipCharacterByItem(NPChar, "suit_1");
		PGG_Disband_Fleet(NPChar);
		SetBaseShipData(NPChar);
		DeleteAttribute(NPChar, "ship.sails");
		RepairMasts(NPChar);
		DeleteAttribute(NPChar, "ship.blots");
		Fantom_SetCannons(NPChar, "pirate");
		Fantom_SetBalls(NPChar, "pirate");

		DeleteAttribute(NPChar, "PGGAi.Task");
		DeleteAttribute(NPChar, "PGGAi.LockService");
		SetCharacterRemovable(NPChar, true);
		SaveCurrentNpcQuestDateParam(NPChar, "Companion.CheckRelation");
		LAi_SetImmortal(NPChar, false);

		break;

	case "companion_pay":
		if (sti(PChar.money) < sti(NPChar.HiringMoney))
		{
			NotEnoughMoneyDialog(link, NPChar);
			break;
		}
		
		Dialog.Text = RandSwear() + "Je ne peux vraiment pas."
		PGG_ChangeRelation2MainCharacter(NPChar, 100);
		AddMoneyToCharacter(PChar, -sti(NPChar.HiringMoney));
		NPChar.HiringMoneyPaid = true;

		link.l1 = "Voici votre argent.";
		link.l1.go = "companion";

		break;

	case "officer_pay":
		if (sti(PChar.money) < sti(NPChar.HiringMoney))
		{
			NotEnoughMoneyDialog(link, NPChar);
			break;
		}
		
		Dialog.Text = RandSwear() + "Je ne peux vraiment pas."
		PGG_ChangeRelation2MainCharacter(NPChar, 100);
		AddMoneyToCharacter(PChar, -sti(NPChar.HiringMoney));
		NPChar.HiringMoneyPaid = true;
		link.l1 = "Voici votre argent.";
		link.l1.go = "officer_hired";
	break;

	case "companion_leave":		
		Dialog.Text = RandSwear() + NPCharRepPhrase(NPChar,
			RandPhraseSimple("Que le requin te dévore !!! Je quitte l'escadre !", "Ma patience est à bout ! Je m'en vais."),
			RandPhraseSimple("J'en ai assez, amiral !... Je vais suivre ma propre route !", "J'en ai assez ! Je quitte l'escadre.")
		);

		link.l1 = PCharRepPhrase(
			RandPhraseSimple("Eh bien, fiche le camp " + NPCharSexPhrase(NPChar, "et bon vent", "d'ici, radine") + " !", "Va au diable" + NPCharSexPhrase(NPChar, ".", ", espèce de mousse !")),
			RandPhraseSimple("Bon, je ne te retiens pas.", "Libre à toi. Bon vent !")
		);
		link.l1.go = "Exit_Companion_Leave";

		link.l2 = PCharRepPhrase(
			RandPhraseSimple("Euh... Et si je vous offrais une petite prime ?", "Caramba !!! Pourquoi ne restez-vous pas ? Je veux bien même verser une prime à votre équipage !"),
			RandPhraseSimple("C'est dommage de se séparer... Une petite récompense réglera peut-être nos différends ?", "Et une augmentation ?")
		);
		link.l2.go = "companion_stay";
		
		break;

	case "companion_stay":
		if (CheckAttribute(NPChar, "Quest.Companion.Price"))
		{
			Dialog.Text = RandPhraseSimple("Une fois m'a suffi. Je ne crois plus à vos promesses !", "Aucune somme ne pourra me tenter. Ma décision est définitive !");
			link.l1 = RandPhraseSimple("Eh bien, dans ce cas, bonne continuation.", "Alors dehors, et que je ne vous revoie plus !");
			link.l1.go = "Exit_Companion_Leave";
			break;
		}

		NPChar.Quest.Companion.Price = 2*GetSalaryForShip(NPChar);
		Dialog.Text = RandSwear() + NPCharRepPhrase(NPChar,
			RandPhraseSimple(
				"Une prime ? Parfait ! Une somme de " + NPChar.Quest.Companion.Price + " piastres me conviendra.",
				"Peut-être que si vous versez à mon équipage " + NPChar.Quest.Companion.Price + " piastres, je le convaincrai de rester."
			),
			RandPhraseSimple(
				"Bien ! Je suis prêt" + NPCharSexPhrase(NPChar, "", "e") + " à rester pour une modeste prime de " + NPChar.Quest.Companion.Price + " piastres !",
				NPChar.Quest.Companion.Price + " piastres nous suffiront, à moi et à mon équipage, pour un moment."
			)
		);
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Vous vous moquez de moi ! Fichez le camp.", 
				"Ha... non, je préfère dépenser cet argent pour quelque chose de plus utile !"
			),
			RandPhraseSimple(
				"Ah non, pas question. Je ne suis pas si riche !", 
				"Adieu. Je ne veux pas payer autant."
			)
		);
		link.l1.go = "Exit_Companion_Leave";

		if (sti(PChar.money) >= sti(NPChar.Quest.Companion.Price))
		{
			link.l2 = PCharRepPhrase(
				RandPhraseSimple(
					"Parfait ! Voici l'argent de la prime !", 
					"Je savais bien que ce n'était qu'une question d'argent !"
				),
				RandPhraseSimple(
					"Parfait ! דa me fait plaisir que vous restiez !", 
					"Voici la prime promise. Et nous voilà de nouveau ensemble."
				)
			);
			link.l2.go = "Exit_Companion_Stay";
		}
		break;

	}
}

// PGG_Dlg_BT: extracted conversation cases (dispatched from main switch)
void PGG_Dlg_BT(ref NPChar, aref link, aref NextDiag)
{
	int i, n; int iRnd = -1; int iAns; bool bOk; float locx, locy, locz; string sTmp, sLoc; ref sld;
	switch(Dialog.CurrentNode)
	{
	case "BT_Quest":
		Dialog.Text = "Choisissez un modèle !";
		link.l1 = "Modèle de quête 1 : en mer.";
		link.l1.go = "BT_Quest_1";
		link.l2 = "Modèle de quête 2 : à terre.";
		link.l2.go = "BT_Quest_2";
		break;

	case "BT_Quest_1":
		NPChar.PGGAi.ActiveQuest.QstNumber = 0;
		NPChar.PGGAi.ActiveQuest.QstNumber.Template = 1;
		Dialog.Text = "SוLECTIONNו ! Modèle de quête 1 : en mer.";
		link.l1 = "Ah oui...";
		link.l1.go = "quest";
		break;
	case "BT_Quest_2":
		NPChar.PGGAi.ActiveQuest.QstNumber = 0;
		NPChar.PGGAi.ActiveQuest.QstNumber.Template = 0;
		Dialog.Text = "SוLECTIONNו ! Modèle de quête 1 : à terre.";
		link.l1 = "Ah oui...";
		link.l1.go = "quest";
		break;
//==== BETTA_TEST ====

	}
}

// PGG_Dlg_Quest: extracted conversation cases (dispatched from main switch)
void PGG_Dlg_Quest(ref NPChar, aref link, aref NextDiag)
{
	int i, n; int iRnd = -1; int iAns; bool bOk; float locx, locy, locz; string sTmp, sLoc; ref sld;
	switch(Dialog.CurrentNode)
	{
	case "quest":
		chrDisableReloadToLocation = false;

		Dialog.Text = RandPhraseSimple("De quoi vous parlez ? Hic... Vous ne voyez pas que mes amis et moi, on se repose !.. Hic..", "Euh... Pas d'affaires aujourd'hui !");
		link.l1 = "Je vois...";
		link.l1.go = "exit";

		if (!PGG_IsQuestAvaible() && !isSetSail) {
			Log_TestInfo("Wrong location for PP")
			break; // локация не подходит
		}

		if (CheckAttribute(NPChar, "mapEnc") && findsubstr(NPChar.mapEnc.Name, "merchants" , 0) != -1) // ПГГ с прицепом
		{
			Dialog.Text = "J'ai assez à faire en ce moment. Tu ne vois pas que je ne navigue pas " + NPCharSexPhrase(NPChar, "seul", "seule") + " ?";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			break;
		}

		if (!CheckAttribute(PChar, "Ship.Type") || sti(PChar.Ship.Type) == SHIP_NOTUSED) // гг без корабля
		{
			PCharNoShipDialog(link, NPChar);
			break;
		}

		if (!CheckAttribute(NPChar, "Ship.Type") || sti(NPChar.Ship.Type) == SHIP_NOTUSED) // пгг без корабля
		{
			PGGNoShipDialog(link, NPChar);
			break;
		}

		if (GetCharacterShipClass(PChar) > 5) // класс не подходит
		{
			PCharShipClassIsLowDialog(link, NPChar);
			break;
		}

		if (GetCompanionQuantity(PChar) >= COMPANION_MAX) // компаньонов максимальное количество
		{
			MaxCompanionsExceededDialog(link, NPChar);
			break;
		}

		int iDays = GetQuestPastDayParam("QuestTalk");
		if (isSetSail && iDays < PGG_PP_COOLDOWN_SEA) // поймали в море и с прошлого ПП прошло менее недели
		{
			Log_TestInfo("Time has not passed since the previous PP (the zero day of NG creation is also considered)")
			Log_TestInfo(" days have passed: " + iDays + ", days left: " + sti(PGG_PP_COOLDOWN_SEA - iDays))
			PGGQuestNotEnoughtTimePassedDialog(link, NPChar);
			break;
		}

		if (iDays < PGG_PP_COOLDOWN_TOWN) // поймали в городе и с прошлого ПП прошло менее двух недель
		{
			Log_TestInfo("Time has not passed since the previous PP (the zero day of NG creation is also considered)")
			Log_TestInfo(" days have passed: " + iDays + ", days left: " + sti(PGG_PP_COOLDOWN_TOWN - iDays))
			PGGQuestNotEnoughtTimePassedDialog(link, NPChar);
			break;
		}

		// квест Виспер постоянно ломал ПП
		if (CheckAttribute(PChar, "PGGWhisperComplete") || CheckAttribute(pchar, "PGGWhisperQuest")) {
			if (CheckAttribute(PChar, "GenQuest.PGG_Quest") && NPChar.name != "Whisper")
			DeleteAttribute(PChar, "GenQuest.PGG_Quest");
		}

 		// TODO: тут неведомая хуйня, вот это иногда багает и так и остается флажок, будто мы на ПП еще, хотя квест закрыт
		// пытался дебажить, но причину найти не смог, вроде во всех исходах мы подчищаем это
		// есть подозрение, что были ошибки до подчистки флага -> мы вылетели к хуям, либо скипнули дальнейшую обработку -> флаг так и остался в подвешенном состоянии
		if (CheckAttribute(PChar, "GenQuest.PGG_Quest"))
		{
			bool toSkip = PGGQuestAlreadyActive(link, NPChar);
			if (toSkip) {
				break;
			}
		}

		if (drand1(100) > 60 || isSetSail) // шанс 40% на дельце, либо поймали в море
		{
			Dialog.Text = "Qu'est-ce que c'est que cette conversation ? Remarquez, vous tombez bien. J'ai une affaire pour vous !";
			link.l1 = "Hum. De quoi parlez-vous ?";

			if (isSetSail) link.l1.go = "Quest_1_Ship";
			else link.l1.go = "Quest_1_Work";

			NPChar.PGGAi.ActiveQuest = true;
			isPGGInitiative = true;
			PChar.GenQuest.PGG_Quest = 1; // чтоб не достовали другие ПГГ
			SaveCurrentQuestDateParam("QuestTalk");
		}

		break;

	case "quest_onStay": // ПГГ сам подходит
		chrDisableReloadToLocation = false;
		SaveCurrentQuestDateParam("QuestTalk");
		Dialog.Text = "Attention !!! Oh ! Je crois que je vous connais, vous êtes une célébrité ! J'ai beaucoup entendu parler de vous."; 

		if (CheckAttribute(NPChar, "meeting") && sti(NPChar.meeting))
		{
			link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Comment allez-vous ?";
			link.l1.go = "Quest_1_Work";
			break;
		}
			
		link.l1 = PCharRepPhrase(
			RandSwear() + RandPhraseSimple(
				"Je suis le capitaine " + GetFullName(PChar) + ".",
				"Je commande le navire '" + PChar.Ship.Name + "' et une bonne centaine de fils de chienne prêts à tout ! Héhé ! " + 
				"Je m'appelle " + GetFullName(PChar) + "."
			),
			RandPhraseSimple(
				"Permettez-moi de me présenter : capitaine " + GetFullName(PChar) + ".", 
				"Nous n'avons pas encore été présentés" +
				". Je commande le navire '" + PChar.Ship.Name + "', qui bat pavillon de " + NationNameGenitive(sti(PChar.nation)) + 
				". Je m'appelle " + GetFullName(PChar) + "."
			)
		);
		link.l1.go = "Quest_1_Meeting";
		break;

	//=========== Первый квест ==========
	case "Quest_1_Meeting":
		Dialog.Text = "Je suis " + GetFullName(NPChar) + ", capitaine de " + XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen") + " '" + NPChar.Ship.Name + "'" +
		NPCharSexPhrase(NPChar, 
			NPCharRepPhrase(NPChar, ". Le corsaire le plus célèbre de toute la Terre Ferme.", ". Un simple marin."), 
			NPCharRepPhrase(NPChar, ". La plus célèbre conquérante des mers de toutes les Caraïbes.", ". Une pirate tout ce qu'il y a de plus ordinaire.")
		);
		link.l1 = "Oui, je me souviendrai de vous maintenant.";
		link.l1.go = "Quest_1_Work";
		NPChar.meeting = true;
		break;

	case "Quest_1_Work":
		GeneratePGGQuestLocation(NPChar);

		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"J'ai une excellente affaire pour vous et vos diables. ",
				"Unissons nos forces, et nous pourrons décrocher le gros lot ! Bien sמr, il faudra tuer quelques personnes. Héhé."
			),
			RandPhraseSimple(
				"J'ai une proposition d'affaires pour vous, capitaine. ",
				"Capitaine, votre réputation est bien connue, c'est pourquoi je veux vous proposer de participer à une affaire alléchante. "
			)
		) + RandPhraseSimple(
			"Entre nous. Discutons de tout ça sur mon pont, à bord du '" + NPChar.Ship.Name + "', autour d'un tonnelet d'excellente bière. Aujourd'hui.", 
			"Inutile d'en parler ici, nous discuterons sur mon navire, le '" + NPChar.Ship.Name + "', au calme. Ne tardez pas à venir."
		);

		link.l1 = PCharRepPhrase(
			RandSwear() + RandPhraseSimple(
				"Au diable les délais ! Je veux connaître les bonnes nouvelles vite, et les mauvaises encore plus vite !",
				"Inutile de traîner ! Il y a une chambre à la taverne, nous en discuterons là-bas !"
			),
			RandPhraseSimple(
				"Pourquoi ne pas discuter de votre proposition tout de suite, dans une chambre de la taverne ?",
				"Je crains de ne pas avoir envie de visiter votre navire. Si vous avez besoin de quelque chose, dites-le ici !"
			)
		);
		link.l1.go = "Quest_1_Work_1";

		link.l2 = PCharRepPhrase(
			RandPhraseSimple(
				"J'y serai ! Mais si vous me faites perdre mon temps, je vous arrache la langue !",
				RandSwear() + "Attendez-moi, j'espère que ça en vaut la peine. Et ne vous avisez pas de me rouler !"
			),
			RandPhraseSimple(
				"J'accepte votre invitation avec plaisir, capitaine.",
				"Vous piquez ma curiosité. Bien sמr que je viendrai."
			)
		);
		link.l2.go = "Exit_Quest_1_AfterTavernTalk";
		break;

	case "Quest_1_Work_1":
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Tu en as sans doute assez du tangage ! Va donc te trouver une maman avec une tétine !!!",
				"Alors, "+ GetSexPhrase("l'ami", "ma petite") +", tu as fait dans ton froc de peur ?!! Dégage ! Tu n'es pas de taille."
			),
			RandPhraseSimple(
				"Non, ce n'est pas ça. Je ne vais pas te forcer : l'or ne t'intéresse pas, c'est tout.",
				"C'est ça ou rien. C'est toi qui vois. Les amateurs d'or ne manquent pas."
			)
		);
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Ha ! Tu ne manques pas de piquant ! Et tu n'as pas peur... Je viendrai !",
				"Vous savez insister, capitaine. Attendez-moi."
			),
			RandPhraseSimple(
				"D'accord, j'accepte.",
				"Vous savez convaincre. Je veux bien discuter affaires sur votre navire."
			)
		);
		link.l1.go = "Exit_Quest_1_AfterTavernTalk";

		link.l2 = PCharRepPhrase(
			RandPhraseSimple(
				"Ha ! Tu t'es imaginé" + NPCharSexPhrase(NPChar, "", "e") + " pouvoir m'attirer sur ton navire pour me tuer ? דa ne marchera pas !",
				"Tes paroles ne valent pas un sou ! Je ne veux rien avoir à faire avec toi !"
			),
			RandPhraseSimple(
				"Une offre douteuse. Je dois refuser.",
				"Ce fut un plaisir de vous rencontrer, capitaine " + GetFullName(NPChar) + ". Adieu."
			)
		);
		link.l2.go = "Quest_1_NotWork";
		break;

	case "Quest_1_NotWork":
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Du rhum pour moi ! Et toi, disparais de ma vue !",
				"Nous avons déjà tout réglé, n'est-ce pas ?"
			),
			RandPhraseSimple(
				"Passe ton chemin, je suis occupé" + NPCharSexPhrase(NPChar, "", "e") + ".",
				"Je crois que toi et moi, nous n'avons pas de sujets communs."
			)
		);
		link.l1 = RandSwear();
		link.l1.go = "Exit_2";

		SaveCurrentQuestDateParam("QuestTalk");
		break;

	case "Quest_1_Work_2":
		Dialog.Text = "Je te l'ai dit, je suis prêt" + NPCharSexPhrase(NPChar, "", "e") + " : je t'attends sur le navire !";
		link.l1 = "Euh... Bien sמr...";
		link.l1.go = "Exit";
		NextDiag.TempNode = "Quest_1_Work_2";
		break;

	case "Quest_1_Ship":
		PChar.Quest.PGGQuest1_RemoveShip_Timer.Over = "yes";

		if (GetCharacterShipClass(PChar) > 5) // класс не подходит
		{
			PCharShipClassIsLowDialog(link, NPChar);

			PChar.Quest.PGGQuest1_RemoveEnd.win_condition.l1 = "ExitFromLocation";
			PChar.Quest.PGGQuest1_RemoveEnd.win_condition.l1.Location = PChar.location;
			PChar.Quest.PGGQuest1_RemoveEnd.function = "PGG_Q1RemoveShip";
			break;
		}

		if (GetCompanionQuantity(PChar) >= COMPANION_MAX) // компаньонов максимальное количество
		{
			MaxCompanionsExceededDialog(link, NPChar);

			PChar.Quest.PGGQuest1_RemoveEnd.win_condition.l1 = "ExitFromLocation";
			PChar.Quest.PGGQuest1_RemoveEnd.win_condition.l1.Location = PChar.location;
			PChar.Quest.PGGQuest1_RemoveEnd.function = "PGG_Q1RemoveShip";
			break;
		}

		PChar.GenQuest.PGG_Quest.Stage = 1;
		if (isSetSail) {
			GeneratePGGQuestLocation(NPChar)

			Dialog.Text = "Vous avez bien choisi votre moment pour monter sur mon pont, capitaine ! " + 
			"J'ai une bonne affaire pour vous : rafler une marchandise mal gardée.";
		} else {
			Dialog.Text = RandPhraseSimple(
				"Bienvenue à bord, capitaine !",
				"Bien, maintenant je suis sמr qu'il n'y a pas d'oreilles indiscrètes, mes marins sont déjà au courant."
			) + " La proposition : s'emparer d'une petite marchandise sans surveillance.";
		}
		link.l1 = RandPhraseSimple(
			"Qu'y a-t-il de si difficile ? Et pourquoi partages-tu ça avec moi" + NPCharSexPhrase(NPChar, "", ", ma chère") + " ?",
			"Sans surveillance ? " + NPCharSexPhrase(NPChar, "Tu plaisantes, l'ami", "Tu plaisantes, ma jolie") + " !"
		);
		link.l1.go = "Quest_1_Ship_1";

		break;

	case "Quest_1_Ship_1":
		Dialog.Text = RandPhraseSimple(
			"Eh bien, il y a des gens qui la considèrent comme la leur, mais il faudra les convaincre du contraire.",
			"Bien sמr, il faudra tuer quelques personnes. Mais ce n'est pas une raison pour refuser, si ?!"
		);
		link.l1 = PCharRepPhrase(RandSwear() + 
			RandPhraseSimple(
				"Au fait !",
				"דa sent déjà le bon massacre ! Oם sont-ils ?"
			),
			RandPhraseSimple(
				"J'aimerais connaître les détails de votre proposition.",
				"Que voulez-vous me proposer exactement ?"
			)
		);
		link.l1.go = "Quest_1_Ship_Detail";

		link.l2 = PCharRepPhrase(
			RandPhraseSimple(
				"Vous me cachez quelque chose. Je ne veux pas me mêler de ça avec vous !",
				"דa a l'air simple, mais je ne vous crois pas ! Vous voulez tirer les marrons du feu avec les mains des autres ? Pas d'accord !"
			),
			RandPhraseSimple(
				"L'offre est tentante, mais je dois refuser.",
				"Non, depuis l'enfance, je ne prends pas ce qui est aux autres, je préfère qu'on me le donne. Je passe mon tour."
			)
		);
		link.l2.go = "Quest_1_Ship_Refuse";
		break;

	case "Quest_1_Ship_Detail":
		while (PChar.GenQuest.PGG_Quest.Island == "") GeneratePGGQuestLocation(NPChar);
		sTmp = "Un convoi appartenant à " + NationNameGenitive(sti(PChar.GenQuest.PGG_Quest.Nation)) + ", qui transporte ";
		PChar.GenQuest.PGG_Quest.Goods.Text = GetStrSmallRegister(XI_ConvertString(Goods[sti(PChar.GenQuest.PGG_Quest.Goods)].Name + "Acc"));
		sTmp += PChar.GenQuest.PGG_Quest.Goods.Text;

		if (PChar.GenQuest.PGG_Quest.Island.Town == "" || PChar.GenQuest.PGG_Quest.Island.Town == "Caiman" ||
			PChar.GenQuest.PGG_Quest.Island.Town == "Terks" || PChar.GenQuest.PGG_Quest.Island.Town == "Dominica" ||
			PChar.GenQuest.PGG_Quest.Island.Town == "StLucia")
		{
			sLoc = GetConvertStr(PChar.GenQuest.PGG_Quest.Island, "LocLables.txt");
		}
		else
		{
			sLoc = XI_ConvertString("Colony" + PChar.GenQuest.PGG_Quest.Island.Town + "Gen");
		}

		if (sti(PChar.GenQuest.PGG_Quest.Template))
		{
			sLoc = GetConvertStr(PChar.GenQuest.PGG_Quest.Island, "LocLables.txt"); // LEO: тут нужно имя ОСТРОВА (Бермуды), а не поселения (Шарп-Таун)
			sTmp +=	", va passer près de " + sLoc + " du cכté de " + GetConvertStr(PChar.GenQuest.PGG_Quest.Island.Shore, "LocLables.txt") + ", car ils ont dמ s'écarter de leur route habituelle.";
		}
		else
		{
			sTmp += ", a été pris dans une tempête près de " + sLoc + " et a sombré. Mais ils ont réussi à sauver une partie de la cargaison et ont débarqué au lieu-dit " + 
				GetConvertStr(PChar.GenQuest.PGG_Quest.Island.Shore, "LocLables.txt") + ". Ils attendent maintenant l'arrivée de leur escadre.";
		}

		Dialog.Text = sTmp;
		link.l1 = PCharRepPhrase(RandSwear() + 
			RandPhraseSimple(
				"Ne traînez pas, dites-moi tout vite !",
				"J'avais vu juste à votre sujet. Que savez-vous d'autre ?"
			),
			RandPhraseSimple(
				"Très intéressant, continuez !",
				"Je suis tout ouïe !"
			)
		);
		link.l1.go = "Quest_1_Ship_Detail_1";

		link.l2 = PCharRepPhrase(
			RandPhraseSimple(
				"Ce n'est pas une mauvaise affaire, mais je refuse. Je n'ai aucun intérêt à me battre avec " + NationNameAblative(sti(PChar.GenQuest.PGG_Quest.Nation)) + ".",
				"Un convoi ? Sans surveillance ? Il y a un millier de soldats avec lui ! דa ne va pas. Je m'en vais."
			),
			RandPhraseSimple(
				"Non, monsieur, je ne me bats pas contre " + NationNameAblative(sti(PChar.GenQuest.PGG_Quest.Nation)) + ", ça ne m'intéresse pas.",
				"Ma réponse est non ! Je ne vais pas me brouiller avec " + NationNameAblative(sti(PChar.GenQuest.PGG_Quest.Nation)) + " !"
			)
		);
		link.l2.go = NPCharRepPhrase(NPChar, "Quest_1_Ship_BadWay", "Quest_1_Ship_Refuse");

		if (sti(PChar.GenQuest.PGG_Quest.Template))
		{
			AddQuestRecord(PGGQuestID, "q1_Detail_A");
		}
		else
		{
			AddQuestRecord(PGGQuestID, "q1_Detail_B");
		}
		AddQuestUserData(PGGQuestID, "sNation", NationNameGenitive(sti(PChar.GenQuest.PGG_Quest.Nation)));
		AddQuestUserData(PGGQuestID, "sGoods", PChar.GenQuest.PGG_Quest.Goods.Text);
		AddQuestUserData(PGGQuestID, "sColony", sLoc);
		AddQuestUserData(PGGQuestID, "sShore", GetConvertStr(PChar.GenQuest.PGG_Quest.Island.Shore, "LocLables.txt"));
		break;

	case "Quest_1_Ship_Detail_1":
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Dans " + FindRussianDaysString(sti(PChar.GenQuest.PGG_Quest.Days)) + " le convoi sera parti, et nous ne pourrons plus le rattraper.",
				"Nous avons exactement " + FindRussianDaysString(sti(PChar.GenQuest.PGG_Quest.Days)) + " pour les tailler en pièces et ramasser le butin !"
			),
			RandPhraseSimple(
				"Nous disposons de " + FindRussianDaysString(sti(PChar.GenQuest.PGG_Quest.Days)) + " pour toute l'opération.",
				"Il faut se dépêcher, " + PChar.Name + ". Nous n'avons que " + FindRussianDaysString(sti(PChar.GenQuest.PGG_Quest.Days)) + "."
			)
		);
		link.l1 = RandPhraseSimple(
			"On y arrivera ! Nous appareillons aujourd'hui.", 
			"Ne traînons pas. Donnez l'ordre d'appareiller aujourd'hui."
		);
		link.l1.go = "Exit_Quest_1_Accept";

		AddQuestRecord(PGGQuestID, "q1_Accept");
		AddQuestUserData(PGGQuestID, "nDays", FindRussianDaysString(sti(PChar.GenQuest.PGG_Quest.Days)));

		break;

	case "Quest_1_Ship_Accept":
		Dialog.Text = "Ne traînons pas ! Allons-y !";
		link.l1 = "Allons-y !";
		link.l1.go = "Exit";
		NextDiag.TempNode = "Quest_1_Ship_Accept";
		break;

	case "Quest_1_Ship_Refuse":
		Dialog.Text = RandSwear() + "Vous me décevez, capitaine. Vous pensiez que je vous invitais à "+ RandPhraseSimple("la messe du dimanche ?!!", "un goמter d'enfants ?!!");
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"C'est ton affaire" + NPCharSexPhrase(NPChar, "", ", ma chère") + ". Et c'est à moi de décider.",
				"Je ne veux pas sécher au soleil au bout d'une corde pour deux ou trois piastres."
			),
			RandPhraseSimple(
				"Ma décision est définitive, capitaine.",
				"Nous n'avons plus rien à nous dire."
			)
		);
		link.l1.go = "Exit_Quest_1_Refuse";
		break;

	case "Quest_1_Ship_BadWay":
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Allons, tout se passera comme sur des roulettes, et personne n'en saura rien. On égorgera tout le monde.",
				"Je t'ai donné l'information, et tu veux faire le coup sans moi ? Va te faire voir !"
			),
			RandPhraseSimple(
				"Oם courez-vous comme ça, capitaine ? Pas chez les autorités, j'espère ?",
				"Il est très imprudent d'entrer dans l'antre du tigre en pensant pouvoir en ressortir facilement."
			)
		);
		link.l1 = PCharRepPhrase(RandSwear() + 
			RandPhraseSimple(
				"Va au diable des mers ! Moi, capitaine " + GetFullName(pchar) + ", je n'ai pas d'ordres à recevoir de toi ! Je m'en vais !",
				"Par le diable, tu commences à m'énerver !"
			),
			RandPhraseSimple(
				"Votre proposition ne m'intéresse pas, et nous n'avons plus rien à nous dire. Adieu.",
				"Je crois que nous n'avons plus rien à nous dire. J'ai à faire."
			)
		);
		link.l1.go = "Quest_1_Ship_BadWay_1";
		break;

	case "Quest_1_Ship_BadWay_1":
		Dialog.Text = RandSwear() + PCharRepPhrase(
			RandPhraseSimple(
				"Sus à "+ GetSexPhrase("lui", "elle") +" ! Attachez-"+ GetSexPhrase("le", "la") +" au canon ! Voyons de quelle couleur sont ses tripes !!!",
				"Hé, Johnny ! Henderson ! Attrapez ce salaud ! Sus à "+ GetSexPhrase("lui", "elle") +" ! Bloquez l'accès à la chaloupe !!!"
			),
			RandPhraseSimple(
				"Dommage, capitaine ! J'espère que vous vous sentirez à l'aise dans notre cale. Ensuite, nous déciderons de ce que nous ferons de vous.",
				"Les esclaves blancs ne vivent pas longtemps, capitaine, alors décidez-vous : soit Hands vous loge une balle de mousquet dans la tête, soit vous passez le reste de votre vie dans les carrières."
			)
		);
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Je vais te faire bouffer tes sales tripes, " + GetFullName(NPChar) + " !!!",
				"וcartez-vous ! Ordures ! Je vais vous fendre le crâne comme une citrouille pourrie !"
			),
			RandPhraseSimple(
				"Votre offre est inacceptable... Et très imprudente !!!",
				"Et votre hospitalité laisse à désirer... וcartez-vous !!!"
			)
		);
		link.l1.go = "Exit_Quest_1_DeckFight";
		break;

	case "Quest_1_Time2Late":
		DeleteAttribute(&Locations[FindLocation(PChar.GenQuest.PGG_Quest.Island.Shore)], "DisableEncounters");
		chrDisableReloadToLocation = false;
		SaveCurrentQuestDateParam("QuestTalk");

		PChar.Quest.PGGQuest1_PGGDead.Over = "Yes";
		PChar.Quest.PGGQuest1_GroupDead.Over = "Yes";
		PChar.Quest.PGGQuest1_CheckStartState.Over = "Yes";

		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Tonnerre de Brest ! On arrive trop tard ! Et tout ça à cause de vous, bande de feignants ! Il n'y a plus rien à partager avec vous maintenant, " + GetFullName(PChar) + ". Hissez la voile d'étai ! Choquez le hunier en douceur ! ",
				"Alors, " + GetFullName(pchar) + ", je n'aurais pas dמ m'associer avec vous. Le butin m'a filé entre les doigts comme de l'eau. Adieu !"
			),
			RandPhraseSimple(
				"Ils sont partis ! Tout est de la faute de votre lenteur ! Nos chemins se séparent, " + GetFullName(PChar) + ".",
				"Nous ne rattraperons pas le convoi, on peut ranger les avirons. Je n'aurais pas dמ m'associer avec vous ! Adieu."
			)
		)
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Et au diable ce convoi ! Les pêcheurs de perles ne valent pas moins, et sans aucun risque !",
				"La chance est avec nous, la journée n'est pas finie ! La mer est pleine de pauvres marchands qui n'attendent que nous pour leur prendre leur argent !"
			),
			RandPhraseSimple(
				"C'est vraiment dommage qu'une opération aussi brillante se soit terminée en fiasco complet ! Adieu !",
				"L'homme propose, mais Dieu dispose... Adieu !"
			)
		);
		link.l1.go = "Exit_Quest_1_2Late";

		AddQuestRecord(PGGQuestID, "q1_Time2Late");
		CloseQuestHeader(PGGQuestID);
		break;

	case "Quest_1_CheckResult":
		if (PChar.location == PChar.GenQuest.PGG_Quest.Island.Shore)
		{
			Locations[FindLocation(PChar.GenQuest.PGG_Quest.Island.Shore)].DisableEncounters = false;
		}
		else
		{
			PChar.quest.Munity = "Deads";
		}
		chrDisableReloadToLocation = false;
		SaveCurrentQuestDateParam("QuestTalk");

		//не взяли груз...
		PChar.GenQuest.PGG_Quest.FailedPaySum = sti(PChar.GenQuest.PGG_Quest.Days)*100000;
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Espèce de "+ GetSexPhrase("salaud sanguinaire", "garce sanguinaire") +" ! Tout est parti au diable des mers ! " + FindRussianMoneyString(sti(PChar.GenQuest.PGG_Quest.FailedPaySum)) + " sur le tonneau, et que je ne te revoie plus !",
				"Tu te crois l'amiral Nelson ? Tu as coulé tout le butin, "+ GetSexPhrase("imbécile", "idiote") +" ! Donne-moi " + FindRussianMoneyString(sti(PChar.GenQuest.PGG_Quest.FailedPaySum)) + " et dégage !"
			),
			RandPhraseSimple(
				"Tu as décidé de faire la guerre ici ! דa ne vaut rien du tout ! Je suppose qu'on oubliera tout si tu nous verses " + FindRussianMoneyString(sti(PChar.GenQuest.PGG_Quest.FailedPaySum)) + ".",
				"Vos méthodes sont inacceptables dans ce genre d'affaires ! Vous avez tout fait échouer ! Payez immédiatement notre part, soit " + FindRussianMoneyString(sti(PChar.GenQuest.PGG_Quest.FailedPaySum)) + " et allez oם bon vous semble ! "
			)
		);
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Sans moi, tu nourrirais les crabes à l'heure qu'il est, noyé" + NPCharSexPhrase(NPChar, "", "e") + NPCharSexPhrase(NPChar, ", espèce de rapiat !", ", espèce de guenon maladroite !"),
				"Il aurait mieux valu laisser le navire amiral aborder ton rafiot : tu serais déjà au fond, et tu n'empesterais plus l'air ! "
			),
			RandPhraseSimple(
				"Vos exigences sont déplacées, et vos insinuations sont insultantes !",
				"Il n'y avait aucune clause de pénalité dans le contrat, je ne paierai donc pas !"
			)
		);
		link.l1.go = "Quest_1_NotPay";

		if (sti(PChar.money) >= sti(PChar.GenQuest.PGG_Quest.FailedPaySum))
		{
			link.l2 = PCharRepPhrase(
				RandPhraseSimple(
					"Je ne peux pas me battre contre vous en ce moment, et vous le savez ! וtouffez-vous avec vos piastres ! Tenez !",
					"Des piastres !!! Bon, la fortune n'est pas de mon cכté en ce moment. J'accepte."
				),
				RandPhraseSimple(
					"Vos exigences sont scandaleuses, mais je ne semble pas avoir le choix.",
					"Vous avez un appétit démesuré, mais je dois accepter !"
				)
			);
			link.l2.go = "Exit_Quest_1_Failed";
		}
		
		if (sti(PChar.GenQuest.PGG_Quest.Goods.Taken) <= MakeInt(sti(PChar.GenQuest.PGG_Quest.Goods.Qty)/3)) {
			AddQuestRecord(PGGQuestID, "q1_Fail");
			break;
		}

		PChar.GenQuest.PGG_Quest.Ok = 1;
		Dialog.Text = PCharRepPhrase(
			"Une affaire chaude ! Le butin s'élève à " + PChar.GenQuest.PGG_Quest.Goods.Taken + " " + PChar.GenQuest.PGG_Quest.Goods.Text + ".",
			"Bien joué, capitaine ! Le butin s'élève à " + PChar.GenQuest.PGG_Quest.Goods.Taken + " " + PChar.GenQuest.PGG_Quest.Goods.Text + "."
		);
		DeleteAttribute(PChar, "PGGShoreQuest");
		int greedyPGG = 0;
		string greed = "";
		
		float CrewValue = 0.5;
		if (GetCrewQuantity(NPChar) >= GetSquadronCrew(pchar)) 
		{
			CrewValue = 0.4;
			if (makefloat(GetCrewQuantity(NPChar))/makefloat(GetSquadronCrew(pchar)) > 3.0) CrewValue = 0.8;
			else CrewValue = CrewValue + (makefloat(GetCrewQuantity(NPChar))/makefloat(GetSquadronCrew(pchar)) * 0.1);
			
		}
		else 
		{
			if (makefloat(GetCrewQuantity(NPChar))/makefloat(GetSquadronCrew(pchar)) < 0.3) CrewValue = 0.2;
			else CrewValue = makefloat(GetCrewQuantity(NPChar))/makefloat(GetSquadronCrew(pchar));
		}
		if (makeint(NPChar.reputation) < PGG_REP_GOOD && PGG_ChangeRelation2MainCharacter(NPChar, 0) < PGG_REL_HIRE_MIN && drand(200) > sti(GetSummonSkillFromName(PChar, SKILL_LEADERSHIP)))
		{
			greedyPGG = 2;
			greed = "Et je ne te conseille pas de faire le malin.";
			NPChar.Greed = true;
			CrewValue += 0.2;
		}
		if (CrewValue < 0.2) CrewValue = 0.2;
		if (CrewValue > 0.8) CrewValue = 0.8;
		
		PChar.GenQuest.PGG_Quest.Goods.Part = MakeInt(sti(PChar.GenQuest.PGG_Quest.Goods.Taken)*(CrewValue));

		Dialog.Text = Dialog.Text + PCharRepPhrase(" Ma part est de ", " La part qui revient à mon navire est de ") + PChar.GenQuest.PGG_Quest.Goods.Part + ". "+greed;
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"C'est juste ! Les chaloupes sont déjà en train d'être chargées !", 
				"Oui, c'est juste... Une parole donnée vaut plus que l'argent."
			),
			RandPhraseSimple(
				"Vos calculs sont justes. J'accepte.", 
				"Votre partage est irréprochable."
			)
		);
		link.l1.go = "Exit_Quest_1_End";

		if (!CheckAttribute(NPChar, "Greed")) {
			link.l2 = PCharRepPhrase(
				RandPhraseSimple(
					"Et tu réclames encore ta part ? On devrait te pendre à la vergue, sans attendre !",
					"Une part ? Ici, c'est chacun pour soi, et si tu n'as rien eu, c'est ton problème !"
				),
				RandPhraseSimple(
					"Je ne pense pas que vous puissiez compter sur quoi que ce soit.",
					"Ma réponse est non ! Je ne vais pas partager avec " + NPCharSexPhrase(NPChar, "des escrocs de ton espèce", "de la racaille de ton espèce") + " !"
				)
			);
		} else {
			link.l2 = "Tu essaies de me rouler ? Dans ce cas, je prends tout pour moi !";
		}
		link.l2.go = "Quest_1_NotPay";
		break;

	case "Quest_1_NotPay":
		Dialog.Text = PCharRepPhrase(
			RandPhraseSimple(
				"Non, ce n'est pas ça ! Je ne vais pas discuter ! Adieu !",
				"Ne versons pas le sang et n'aggravons pas l'échec ! Vous aurez plus de chance la prochaine fois !"
			),
			RandPhraseSimple(
				"Eh bien, adieu, capitaine, je ne suis pas en position d'insister...",
				"Les dégâts de mon navire et mes pertes ne me permettent pas d'exiger une solution équitable. Je laisse ça à votre conscience, capitaine !"
			)
		);
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"Bon vent !", 
				"Sept pieds d'eau sous la quille !"
			),
			RandPhraseSimple(
				"Adieu ! Je pense que l'air frais du large vous fera du bien !",
				"J'espère que vos échecs ne rendront pas votre caractère encore plus détestable, adieu !"
			)
		);
		link.l1.go = "Exit_Quest_1_Failed";

		PChar.GenQuest.PGG_Quest.Stage = -1;

		if (!CheckAttribute(NPChar, "Greed"))	ChangeCharacterReputation(PChar,-20);
		else	NPChar.PGG_Hunter = true;
		DeleteAttribute(NPChar, "Greed");

		bOk = makeint(NPChar.reputation) < PGG_REP_GOOD && PGG_ChangeRelation2MainCharacter(NPChar, 0) < 75;
		if (bOk || CheckAttribute(PChar, "GenQuest.PGG_Quest.Ok"))
		{
			PChar.GenQuest.PGG_Quest.Stage = 4;
			Dialog.Text = PCharRepPhrase(
				RandPhraseSimple(
					"Tu ne comprends pas ! Avec ça, tu aurais pu racheter ta vie ! Attrapez-moi "+ GetSexPhrase("ce salaud", "cette garce") +" !",
					"Tu crois sans doute qu'on plaisante ? On va te faire passer sous la quille, et tu changeras vite d'avis !"
				),
				RandPhraseSimple(
					"Il va falloir abréger votre vie, capitaine ! Si vous ne voulez pas être aimable, faites connaissance avec saint Martin !",
					"Vous ne me laissez pas le choix, " + GetFullName(PChar) + " ! Je prendrai mon dמ, que vous le vouliez ou non !"
				)
			);
			link.l1 = PCharRepPhrase(
				RandPhraseSimple(
					"Par le diable, tu vas me le payer !!!",
					"Yo-ho ! Viens donc me chercher, capitaine " + GetFullName(PChar) + " ! "
				),
				RandPhraseSimple(
					"L'entaille sera longue et profonde ! ",
					"Tu veux mourir tout de suite ou souffrir un peu ?"
				)
			);
			link.l1.go = "Exit_Quest_1_FailedFight";
		}
		break;

	case "Quest_1_Failed":
		Dialog.Text = "Je ne veux plus faire affaire avec vous !";
		link.l1 = "Pas besoin.";
		link.l1.go = "Exit";
		NextDiag.TempNode = "Quest_1_Failed";
		break;

	case "Quest_1_End":
		Dialog.Text = "Aujourd'hui, nous mettons le cap sur " + XI_ConvertString("Colony"+NPChar.PGGAi.location.town) + " pour boire le butin ! Si tu veux, joins-toi à nous ! En tout cas, c'était un plaisir de faire affaire avec toi ! Bonne chance.";
		link.l1 = "Toi aussi.";
		link.l1.go = "Exit";
		NextDiag.TempNode = "Quest_1_End";
		break;

	case "Quest_1_SharePrise":
		chrDisableReloadToLocation = false;
		SaveCurrentQuestDateParam("QuestTalk");
		Dialog.Text = PCharRepPhrase(
			NPCharSexPhrase(NPChar, "C'était un vrai massacre, dommage qu'il n'y ait pas eu de filles avec eux", "Un vrai carnage, sacré boulet ramé ! Dommage que ça se soit terminé si vite") + " ! Le butin s'élève à " + PChar.GenQuest.PGG_Quest.Goods.Taken + " " + PChar.GenQuest.PGG_Quest.Goods.Text + ".", 
			"Pas mal, capitaine ! Le butin s'élève à " + PChar.GenQuest.PGG_Quest.Goods.Taken + " " + PChar.GenQuest.PGG_Quest.Goods.Text + "."
		);

		PChar.PGGShoreQuest = true;
		PChar.GenQuest.PGG_Quest.Parts = 2;
		i = sti(PChar.GenQuest.PGG_Quest.Parts);
		PChar.GenQuest.PGG_Quest.Goods.Part = MakeInt(sti(PChar.GenQuest.PGG_Quest.Goods.Taken) / i);
    SetCharacterGoods(PChar, sti(PChar.GenQuest.PGG_Quest.Goods), sti(PChar.GenQuest.PGG_Quest.Goods.Taken) + GetCargoGoods(PChar, sti(PChar.GenQuest.PGG_Quest.Goods)));
		
		Dialog.Text = Dialog.Text + " Ma part est de " + PChar.GenQuest.PGG_Quest.Goods.Part + ".";
		link.l1 = PCharRepPhrase(
			RandPhraseSimple(
				"דa me va, que le diable m'emporte !", 
				"Oui, c'est juste, que le diable m'emporte !"
			),
			RandPhraseSimple(
				"Vos calculs sont justes. J'accepte.", 
				"Votre partage est irréprochable."
			)
		);
		link.l1.go = "Exit_Quest_1_End";
		if (sti(pchar.reputation) < PGG_REP_GOOD)
		{
			link.l2 = RandPhraseSimple(
				"Et tu réclames encore ta part ? On devrait te pendre à la vergue, sans attendre !",
				"Une part ? Ici, c'est chacun pour soi, et si tu n'as rien eu, c'est ton problème !"
			);
			link.l2.go = "Quest_1_NotPayShore";
		}
		break;
		
		case "Quest_1_NotPayShore":
			Dialog.Text = RandPhraseSimple(
					"Il va falloir abréger votre vie, capitaine ! Si vous ne voulez pas être aimable, faites connaissance avec saint Martin !",
					"Vous ne me laissez pas le choix, " + GetFullName(PChar) + " ! Je prendrai mon dמ, que vous le vouliez ou non !"
				);
			link.l1 = RandPhraseSimple(
					"Par le diable, tu vas me le payer !!!",
					"Yo-ho ! Viens donc me chercher, capitaine " + GetFullName(PChar) + " ! "
				);
			link.l1.go = "Exit_Quest_1_AllyFight";

			PChar.GenQuest.PGG_Quest.Stage = -1;

			if (!CheckAttribute(NPChar, "Greed")) ChangeCharacterReputation(PChar,-20);
			else NPChar.PGG_Hunter = true;
			DeleteAttribute(NPChar, "Greed");
			AddQuestRecord(PGGQuestID, "q1_OkNotShare");
			CloseQuestHeader(PGGQuestID);
		break;
		
	}
}
