// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			// ==> Анжелика Тич: Портниха знатной дамы
			if(CheckAttribute(pchar, "questTemp.AT_PZD_Rostovshik"))
			{
				DeleteAttribute(pchar, "questTemp.AT_PZD_Rostovshik")
				link.l1 = "Dites-moi, mynheer, êtes-vous marié ?";
				link.l1.go = "AT_PZD_Rost_1";
				break;
			}
			// <== Анжелика Тич: Портниха знатной дамы
		break;
		
		//============ Анжелика Тич: Портниха знатной дамы
		case "AT_PZD_Rost_1":
    		dialog.text = "J'avoue que c'est une question des plus inattendues. Me voilà quelque peu embarrassé.";
    		link.l1 = "J'aimerais acheter une robe digne du haut rang de votre épouse.";
    		link.l1.go = "AT_PZD_Rost_2";
 		break;
		case "AT_PZD_Rost_2":
    		dialog.text = "Ah, c'est donc ça ! Je suis marié, mais voyez-vous, ma femme est une dame bien en chair. Je crains que, même si elle accepte de vous vendre quelque chose de sa garde-robe, il vous faille plus d'une journée pour la retoucher.";
    		link.l1 = "Dommage, je n'ai justement pas autant de temps.";
    		link.l1.go = "AT_PZD_Rost_3";
 		break;
		case "AT_PZD_Rost_3":
    		dialog.text = "Renseignez-vous auprès des marchands de la ville, ils trouveront peut-être la robe qu'il vous faut.";
    		link.l1 = "Merci, je vais suivre votre conseil. Au revoir.";
    		link.l1.go = "AT_PZD_Rost_3";
 		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

