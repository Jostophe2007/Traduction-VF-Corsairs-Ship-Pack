// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "MorrisWillams_ArrestedToUsurer")
            {
                link.l1 = "Je dois vous parler de Morris Williams.";
                link.l1.go = "Step_E6_1";
            }
			if (pchar.questTemp.State == "MorrisWillams_AfterFightGoRedmond")
            {
                link.l1 = "Vous ne reverrez plus vos associés.";
                link.l1.go = "Step_E6_5";
            }
		break;

		case "Step_E6_1":
			dialog.text = "Qu'est-il arrivé à Morris Williams ?";
			link.l1 = "Vous ne savez pas qu'il est en prison ?!";
			link.l1.go = "Step_E6_2";
		break;
		case "Step_E6_2":
			dialog.text = "Si, bien sמr. Que s'est-il passé, il est mort ?";
			link.l1 = "Non, il n'est pas mort, mais il souffre beaucoup. Vous savez sans doute qu'il a simplement joué de terrible malchance, sinon la dette vous aurait été remboursée.";
			link.l1.go = "Step_E6_3";
		break;
		case "Step_E6_3":
			dialog.text = "Mais elle n'est pas remboursée !";
			link.l1 = "Alors ça vous est égal qu'un corsaire pourrisse en prison ?!";
			link.l1.go = "Step_E6_4";
		break;
		case "Step_E6_4":
			dialog.text = "Je ne me soucie que de ma propre santé, le reste m'est égal, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je ne veux plus en parler.";
			link.l1 = "Je n'en resterai pas là. Nous nous reverrons...";
			link.l1.go = "exit";
            pchar.questTemp.State = "MorrisWillams_ArrestedSeekInfo";
            AddQuestRecord("Eng_Line_6_MorrisWillams", "18");
		break;
		case "Step_E6_5":
			dialog.text = "De qui parlez-vous ?";
			link.l1 = "Je parle des contrebandiers avec qui vous traitez. Je les ai "+ GetSexPhrase("saignés", "saignés") +" à blanc.";
			link.l1.go = "Step_E6_6";
		break;
		case "Step_E6_6":
			dialog.text = "Hum... Et que voulez-vous ?";
			link.l1 = "Les reconnaissances de dette de Morris Williams, pour commencer. Et laissez tranquille la famille Atterbury, qui a eu l'imprudence de vous emprunter de l'argent il y a un an.";
			link.l1.go = "Step_E6_7";
		break;
		case "Step_E6_7":
			dialog.text = "Et c'est un pirate qui me dit ça ?!! Bon, Williams sera libéré immédiatement.";
			link.l1 = "Ce n'est pas tout. Pour mon silence sur vos affaires de contrebande, vous me paierez... 10 000 par mois.";
			link.l1.go = "Step_E6_8";
		break;
		case "Step_E6_8":
			dialog.text = "Haha ! Non, je ne paierai pas\n"+
                     "Vous ne pouvez plus prouver mon lien avec la contrebande : ce n'est que votre parole contre la mienne\n"+
                     "Mais je ne veux pas de scandale, alors je vous fais des concessions au sujet de Williams. Vous n'aurez rien de plus. Adieu.";
			link.l1 = "Adieu. Et n'oubliez pas ce que vous m'avez promis.";
			link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "empty";
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "5";
            //ChangeCharacterReputation(pchar, -2); // за попытку шантажа TO_DO eddy
            AddCharacterExpToSkill(pchar, "Accuracy", 80);
            AddCharacterExpToSkill(pchar, "Commerce", 50);
            AddCharacterExpToSkill(pchar, "Sneak ", 70);
            AddCharacterExpToSkill(pchar, "Fencing  ", 100);
            AddCharacterExpToSkill(pchar, "Defence  ", 50);
            AddQuestRecord("Eng_Line_6_MorrisWillams", "22");
            CloseQuestHeader("Eng_Line_6_MorrisWillams");
			ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Morris_Willams")], "PortRoyal_tavern", "sit", "sit1");
			characters[GetCharacterIndex("Morris_Willams")].dialog.currentnode = "Willams_NiceTalking";
            LAi_SetSitTypeNoGroup(characterFromID("Morris_Willams"));
		break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

