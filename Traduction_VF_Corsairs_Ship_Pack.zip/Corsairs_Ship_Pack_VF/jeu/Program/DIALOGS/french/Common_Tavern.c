#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
#include "interface\ship.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\" + NPChar.City + "_Tavern.c";
    if (!HasCityDialogFile("Tavern", NPChar.City, "_Tavern.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\DefaultCity_Tavern.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Tavern\DefaultCity_Tavern.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	int iTest, iTemp;
	string sTemp;
    iTest = FindColony(NPChar.City); // город
    ref rColony;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}
	bool ok;
	ref FortChref = GetFortCommander(NPChar.City);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vous parlerai pas !", "Fuyez, "+ GetSexPhrase("l'ami", "ma petite") +" avant que les soldats ne vous transforment en passoire..."),
					LinkRandPhrase("Que voulez-vous, "+ GetSexPhrase("gredin", "gredine") +" ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin"+ GetSexPhrase(", sale pirate !", "") +"", "Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + ", et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "exit";
				break;
			}
            // homo линейка капитана Блада
            if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
            {
                dialog.Text = LinkRandPhrase("Tiens, docteur Blood ! " + TimeGreeting() + ".",
                                    "Ravie de vous voir, Peter Blood.",
                                    "C'est gentil de passer me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
                Link.l1 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l1.go = "exit";

                if(Pchar.questTemp.CapBloodLine.stat == "WakerOffer")
                {
            		link.l2 = "Pouvez-vous me dire, mon ami " + npchar.name + ", comment trouver le docteur Wacker ?";
            		link.l2.go = "TStep_0";
                }

                if(Pchar.questTemp.CapBloodLine.stat == "PrepareToEscape")
                {
            		link.l2 = "J'ai une affaire délicate à vous proposer.";
            		link.l2.go = "TStep_1";
                }

                if(Pchar.questTemp.CapBloodLine.stat == "needMoney" && CheckAttribute(pchar, "questTemp.CapBloodLine.QuestRaff") && pchar.questTemp.CapBloodLine.QuestRaff == true)
                {
            		link.l2 = "Je m'intéresse à un homme nommé Raphael Guinness. Comment puis-je le trouver ?";
            		link.l2.go = "TStep_5";
                }
                break;
    		}
			//Sinistra пролог Анжелики Тич
			if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue"))
            {
                dialog.Text = "Bonjour, señorita.";
                Link.l1 = "Bonjour, " + npchar.name + ".";
				Link.l1.go = "At_pr_1";
                break;
    		}

			if (drand2(100)==0 && sti(pchar.rank) >= 20 && GetCharacterItem(Pchar, "map_full") <= 0)
			{
				if (!CheckAttribute(pchar, "questTemp.UniquePirate.Drake") || !CheckAttribute(pchar, "questTemp.UniquePirate.Barbarigo") || !CheckAttribute(pchar, "questTemp.UniquePirate.BlackBeard") || !CheckAttribute(pchar, "questTemp.UniquePirate.Levasser"))
				{
					dialog.text = "Capitaine, j'ai une carte au trésor qui traîne ici, elle doit avoir beaucoup de valeur. דa vous intéresse ?";
					link.l1 = "Bien sמr ! Combien en demandez-vous ?";
					link.l1.go = "SpecialMapBuy";
					link.l2 = "Je m'en passerai, je crois. On ne sait jamais qui a gribouillé ça, c'est peut-être même un faux.";
					link.l2.go = "exit";
					break;
				}
			}

			//зачарованный город -->
			if (pchar.questTemp.MC == "toCaracas" && npchar.city == "Caracas")
			{
				dialog.text = "Pour l'amour de Dieu, capitaine, sauvez-moi ! Ils vont tout détruire ! Ma taverne !";
				link.l1 = "Vous avez un loup-garou, ou quoi ?";
				link.l1.go = "MCTavern";
				break;
			}
			if (pchar.questTemp.MC == "toCaracasWervolf" && npchar.city == "Caracas")
			{
				dialog.text = "Capitaine, vous aviez promis d'aller voir le loup-garou...";
				link.l1 = "Je m'en souviens.";
				link.l1.go = "exit";
				break;
			}
			if (pchar.questTemp.MC == "toCaracasPadre" && npchar.city == "Caracas")
			{
				dialog.text = "Alors, qu'en dites-vous, capitaine ? Vous l'avez trouvé ?";
				link.l1 = "Oui. Mais ce n'est pas le moment d'en parler, je vous raconterai tout plus tard...";
				link.l1.go = "exit";
				break;
			}
			if (pchar.questTemp.MC == "toCaracasTavern" && npchar.city == "Caracas")
			{
				dialog.text = "Capitaine, ravi de vous voir !";
				link.l1 = "Qu'est-il arrivé à votre client ?";
				link.l1.go = "MCCaracasAfter";
				break;
			}
			//<-- зачарованный город

			if(NPChar.quest.meeting == "0")
			{
				if (npchar.city == "Pirates")
				{
					dialog.Text = "Tiens, voilà encore "+ GetSexPhrase("un fringant capitaine", "une brave navigatrice") +" qui arrive ! Mettez-vous à l'aise, "+ GetSexPhrase("monsieur", "mademoiselle") +". Je m'appelle Lucky Rosin, et je suis toujours à votre service. Il fait beau aujourd'hui, n'est-ce pas ? Un peu de rhum ?";
					Link.l1 = "Comment avez-vous dit que vous vous appeliez ? La Résine ? Je ne savais pas qu'il y avait des Castillans parmi les pirates !";
					Link.l1.go = "Pirates_1";
					NPChar.quest.meeting = "1";
					break;
				}
				if (npchar.city == "Charles")
				{
					dialog.Text = "Bienvenue, " + GetAddress_Form(NPChar) + ". א manger, à boire et de quoi se distraire, le tout à prix raisonnable ! Je m'appelle " + GetFullName(npchar) + ". Je suis le patron de cette taverne.";
					Link.l1 = "Steed le Borgne ? J'ai entendu parler de vous. On dit que, récemment encore, vous étiez célèbre pour votre chasse aux galions espagnols. Difficile à croire...";
					Link.l1.go = "Charles_1";
					NPChar.quest.meeting = "1";
					break;
				}
				if (npchar.city == "Portobello")
				{
					dialog.Text = "Bienvenue, " + GetAddress_Form(NPChar) + ". א manger, à boire et de quoi se distraire, le tout à prix raisonnable ! Je m'appelle " + GetFullName(npchar) + ", mais on me connaît surtout sous le nom de Renard catalan. Je suis le patron de cette taverne.";
					Link.l1 = "Le Renard catalan ? J'ai entendu parler de vous. On dit qu'autrefois, vous avez secoué les Anglais à la Barbade : vous avez capturé un brick militaire dans le port de la Barbade avec une vieille baille, et vous l'avez littéralement volé sous le nez du fort.";
					Link.l1.go = "Portobello_1";
					NPChar.quest.meeting = "1";
					break;
				}
				if (npchar.city == "FortFrance")
				{
					dialog.Text = "Bienvenue, " + GetAddress_Form(NPChar) + ". " + GetFullName(NPChar)+" à votre service ! Et permettrez-vous à votre fidèle serviteur de vous recommander la seule chose qui, à son avis, vaille quelque chose en ce monde : un peu de rhum ? Hé hé hé !";
					Link.l1 = "Ah, " + npchar.name+", la chose la plus précieuse au monde, c'est l'information.";
					Link.l1.go = "FortFrance_1";
					NPChar.quest.meeting = "1";
					break;
				}
				if (npchar.city == "Nassau")
				{
					dialog.Text = "Qu'est-ce que vous avez à me regarder comme ça ? Vous ne vous attendiez pas à ce qu'une femme dirige tout ici ?! Ha ! " + GetFullName(NPChar)+" va montrer à tout le monde qu'elle a encore de beaux restes !";
					Link.l1 = "Hé, oם avez-vous appris ces manières ?";
					Link.l1.go = "Nassau_1";
					NPChar.quest.meeting = "1";
					break;
				}
				dialog.Text = "Bienvenue, " + GetAddress_Form(NPChar) + ". א manger, à boire et de quoi se distraire, le tout à prix raisonnable !";
				Link.l1 = "Voyons voir... Je suis " + GetFullName(pchar) + ".";
				Link.l1.go = "meeting";
				NPChar.quest.meeting = "1";
			}
			else
			{
				// Квестовый генератор священника. Квест №1. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_1.CurPortManColony + "_tavern")
		        {
		            if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NoMoneyToBarmen"))
		            {
		            	iTemp = sti(PChar.GenQuest.ChurchQuest_1.MoneyToBarmen);
		            	dialog.Text = "Alors, capitaine, vous m'avez apporté " + FindRussianMoneyString(iTemp) + ".";
		            	if(sti(PChar.Money) >= iTemp)
		            	{
							link.l1 = "Oui, je les ai apport"+ GetSexPhrase("ées", "ées") +". Les voici...";
							link.l1.go = "Tavern_ChurchGenQuest1_Node_4_1";
						}
						else
						{
							link.l1 = "Non, pas encore"+ GetSexPhrase("", "") +"...";
							link.l1.go = "exit";
						}
		            }
		            else
		            {
		            	dialog.Text = "Que désirez-vous, "+ GetSexPhrase("monseigneur", "madame") +" ?";
						link.l1 = "Une bouteille de rhum pour mon ami, à la table là-bas.";
						link.l1.go = "Tavern_ChurchGenQuest1_Node_1";
					}
					break;
				}
				// <-- Квестовый генератор священника. Квест №1.

				////////////////
				//Линейка Виспер
				////////////////
				if(startherotype == 2 && CheckAttribute(pchar, "Whisper.FindDesouza") && !CheckAttribute(pchar, "Whisper.Contraband") && sti(pchar.money) >= 10000 && npchar.nation!=3)
				{
					bool Whisper_cnd = GetCharacterSkill(pchar,SKILL_SAILING)>= 65 && pchar.rank >=5 && GetCharacterShipClass(PChar) <= 4;
					if (pchar.rank >=10 || Whisper_cnd)
					{
						dialog.Text = "Capitaine, vous ne devriez pas vous promener comme ça. J'ai entendu dire que l'Inquisition recherchait une fille avec la même couleur de cheveux. Vous devriez vous couvrir, ou quelque chose comme ça.";
						DeleteAttribute(pchar, "Whisper.FindDesouza")
						Link.l1 = "De qui tenez-vous ça ?";
						Link.l1.go = "w_find_desouza";
						break;
					}
				}
				if (CheckAttribute(pchar, "Whisper.NanoCostume") && !CheckAttribute(pchar, "Whisper.AfterWarDog") && sti(Pchar.Ship.Type) != SHIP_NOTUSED && sti(RealShips[sti(pchar.Ship.Type)].BaseType) == SHIP_WH_CORVETTE_QUEST && npchar.id != "Pirates_tavernkeeper")
				{
					pchar.Whisper.AfterWarDog = true;
					dialog.Text = "Bonjour. Ce ne serait pas votre corvette qui vient d'accoster dans notre port ?";
					Link.l1 = "Disons que c'est la mienne, qu'est-ce que ça peut vous faire ?";
					Link.l1.go = "w_meet_esteban_friend";
					break;
				}

				// <-- Линейка Виспер
				// ЧП
				if (GetQuestPastDayParam("BSPrologueEnded") > 7 && CalculateSquadronPowerPchar() >= 200 && sti(npchar.nation) == PIRATE && npchar.id != "Caiman_tavernkeeper" && !CheckAttribute(pchar,"BSOnTheHorizon"))
				{
					pchar.BSOnTheHorizon = true;
					BSBons_SeaBattle(false);
					dialog.text = "Hé, ce ne serait pas notre espoir et notre soutien, la radieuse Miss Guthrie, qui vous cherche ?";
					link.l1 = "Oh mon Dieu ! Qu'est-ce que c'est, cette fois ?";
					link.l1.go = "BS_CPNG_2";
					break;
				}
				// ЧП
				dialog.Text = LinkRandPhrase("Hé, " + GetAddress_Form(NPChar) + " " + PChar.name + " ! " + TimeGreeting() + ".",
                                    "Qui vois-je ! Ravi de vous voir, " + GetAddress_Form(NPChar) + " " + PChar.name + ".",
                                    "C'est gentil de passer me voir, " + GetFullName(pchar) + ". Qu'est-ce que je vous sers aujourd'hui ?");
				Link.l1 = "Y a-t-il des gars sur l'île prêts à prendre la mer ?";
				Link.l1.go = "crew hire";
				Link.l2 = "J'espère que vous pourrez répondre à quelques questions.";
				Link.l2.go = "int_quests";
				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}


				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
		            	{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}
				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Avez-vous une chambre de libre ? J'aimerais séjourner ici quelque temps.");
				link.l3.go = "room";
				Link.l4 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l4.go = "exit";
			}
			// Gregg: "The Vanishing" (ported from Damned Destiny) - the pointer to monsieur Gotie
			if (CheckAttribute(PChar, "DisappearPeople"))
			{
				if (PChar.DisappearPeople == "3")
				{
					link.l40 = "Salut, vieil ami ! Quelles nouvelles ?";
					link.l40.go = "DisappearPeople_1";
				}
				// Gregg: the first keeper names only the country. There are three Dutch
				// colonies, so without a second hint the search is a walk through all of
				// them. Any of the three answers: Marigo points at the house, the other
				// two send the player to Saint Martin.
				if (PChar.DisappearPeople == "4")
				{
					// однородная цепочка || - смешивать её с && в одном if нельзя
					if (NPChar.id == "Marigo_tavernkeeper" || NPChar.id == "Villemstad_tavernkeeper" || NPChar.id == "FortOrange_tavernkeeper")
					{
						link.l42 = "Oם pourrais-je trouver un certain monsieur Gotie ? Un savant, dit-on, spécialiste des antiquités indiennes.";
						link.l42.go = "DisappearPeople_3";
					}
				}
			}
			// Gregg: quest "The Monkey Ship" (ported from Damned Destiny) - the lead to the
			// church of Beliz. Ask the Bas-Terre tavernkeeper: that is where Allen hooked us.
			if (CheckAttribute(PChar, "CaptainMonkey"))
			{
				if (PChar.CaptainMonkey == "3")
				{
					if (NPChar.id == "BasTer_tavernkeeper")
					{
						link.l41 = "Dites-moi, un type en guenilles nommé Allen Gladstonn est-il passé par ici ?";
						link.l41.go = "CaptainMonkey_1";
					}
				}
			}
		break;

		case "BS_CPNG_2":
            dialog.text = "Je n'en ai aucune idée. Mais son messager m'a demandé de façon très convaincante de dire au capitaine "+pchar.name+" qu'une personne a rendez-vous avec " + GetSexPhrase("lui", "elle") + " à la résidence des Guthrie, aux Bahamas. Et si j'étais ce capitaine, je ne tarderais pas.";
            link.l1 = "D'accord, compris.";
			link.l1.go = "exit";
			SetQuestHeader("BSOnTheHorizon");
			AddQuestRecord("BSOnTheHorizon", "1");
			LocatorReloadEnterDisable("Nassau_town", "gate1", true);
			LocatorReloadEnterDisable("Nassau_ExitTown", "reload2_back", true);
			PChar.quest.BSOnTheHorizon_start.win_condition.l1 = "location";
			PChar.quest.BSOnTheHorizon_start.win_condition.l1.location = "Nassau_town";
			PChar.quest.BSOnTheHorizon_start.function = "BSOnTheHorizon_start";
		break;

		case "SpecialMapBuy":
			pchar.questTemp.SpecialMapPrice = 100000+drand(50000);
			aref item;
			Items_FindItem("map_full", &item);
			string type = GetUniquePirateName();
			FillMapForUniqueTreasure(item, type);
			type = GetUniquePirateNameString(type);
			dialog.Text = "Je ne la céderai pas à moins de "+pchar.questTemp.SpecialMapPrice+" piastres. D'après les rumeurs, c'est la carte au trésor de "+type+" en personne. Sans la taverne, j'aurais peut-être essayé d'équiper une expédition de recherche.";
			if (sti(pchar.money)>sti(pchar.questTemp.SpecialMapPrice))
			{
				link.l1 = "Caramba, joli prix, quand même. Bon, je la prends.";
				link.l1.go = "SpecialMapBuy_1";
			}
			link.l2 = "א ce prix-là ? Vous m'avez pris pour "+GetSexPhrase("un imbécile.", "une imbécile.")+"Allons donc !";
			link.l2.go = "exit";
		break;

		case "SpecialMapBuy_1":
			AddMoneyToCharacter(pchar,-sti(pchar.questTemp.SpecialMapPrice));
			GiveItem2Character(pchar, "map_full");
			dialog.Text = "Tenez, j'espère qu'elle en vaudra la peine. Bonne chasse au trésor, capitaine !";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		case "Meeting":
			// Квестовый генератор священника. Квест №1. Warship -->
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_1.CurPortManColony + "_tavern")
	        {
	            dialog.Text = "Que désirez-vous, "+ GetSexPhrase("monseigneur", "madame") +" ?";
				link.l1 = "Une bouteille de rhum pour mon ami, à la table là-bas.";
				link.l1.go = "Tavern_ChurchGenQuest1_Node_1";
				break;
			}
			// <-- Квестовый генератор священника. Квест №1.
			if (npchar.city == "Pirates")
			{
				dialog.Text = "Oh, ne prenez pas mes paroles trop à cœur, " + GetAddress_Form(NPChar) + ". J'aime ronchonner, et parfois me plaindre de la vie... Bon, je vous écoute attentivement, capitaine.";
				Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
				Link.l1.go = "crew hire";
				Link.l2 = NPChar.name + ", parlons-en...";
				Link.l2.go = "int_quests";

				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}

				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}

				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? Je voulais séjourner ici quelque temps.");
				link.l3.go = "room";
				Link.l4 = "Je repasserai sans doute plus tard.";
				Link.l4.go = "exit";
				break;
			}

			if (npchar.city == "Charles")
			{
				dialog.Text = "Oui, d'une manière générale, je suis toujours heureux de parler avec "+ GetSexPhrase("un compagnon agréable", "une jolie compagne") +"... Bon, alors, que vouliez-vous, " + GetAddress_Form(NPChar) + " ?";
				Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
				Link.l1.go = "crew hire";
				Link.l2 = NPChar.name + ", parlons-en...";
				Link.l2.go = "int_quests";
				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}
				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}
				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? Je voulais séjourner ici quelque temps.");
				link.l3.go = "room";
				Link.l4 = "Je repasserai sans doute plus tard.";
				Link.l4.go = "exit";
				break;
			}

			if (npchar.city == "Portobello")
			{
				dialog.Text = "Oh, je suis toujours content de bavarder, "+ GetSexPhrase("l'ami", "ma petite") +". Après tout, vous êtes maintenant mon ami, sachez-le, " + GetAddress_Form(NPChar) + ". Que voulez-vous ?";
				Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
				Link.l1.go = "crew hire";
				Link.l2 = NPChar.name + ", parlons-en...";
				Link.l2.go = "int_quests";

				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}
				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}

				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? J'aimerais séjourner ici quelque temps.");
				link.l3.go = "room";
				Link.l4 = "Je repasserai sans doute plus tard.";
				Link.l4.go = "exit";
				break;
			}
			
			if (npchar.city == "FortFrance")
			{
				dialog.Text = "Je suis un vieux tavernier jovial, et je suis toujours heureux de vous remonter le moral, "+ GetSexPhrase("mon ami", "ma chère") +". Un peu de rhum ? Hi hi hi.";
				Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
				Link.l1.go = "crew hire";
				Link.l2 = NPChar.name + ", parlons-en...";
				Link.l2.go = "int_quests";

				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}
				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}

				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? J'aimerais séjourner ici quelque temps.");
				link.l3.go = "room";
				Link.l4 = "Je repasserai sans doute plus tard.";
				Link.l4.go = "exit";
				break;
			}
			
			if (npchar.city == "Nassau")
			{
				dialog.Text = "Que voulez-vous, "+pchar.name+" ? Vous êtes venu vous rincer le gosier ?";
				Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
				Link.l1.go = "crew hire";
				Link.l2 = NPChar.name + ", parlons-en...";
				Link.l2.go = "int_quests";

				if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
				{
					link.l21 = "וcoutez, il faut que nous parlions finances.";
					link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
				}
				// Квестовый генератор священника. Квест №2. Warship -->
				if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
				{
					link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
					link.l10.go = "Tavern_GenQuest_Church_2_1";
				}

				// <-- Квестовый генератор священника. Квест №2.
				link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? J'aimerais séjourner ici quelque temps.");
				link.l3.go = "room";
				if (!CheckAttribute(pchar, "questTemp.Istoria_InesDias"))	//Инес Диас расскажет о себе
				{
					link.l35 = "Parlez-moi de vous. Comment êtes-vous devenu le patron de cette taverne ?";
					link.l35.go = "Istoria_InesDias_1";
				}
				Link.l4 = "Je repasserai sans doute plus tard.";
				Link.l4.go = "exit";
				break;
			}
			dialog.Text = "Oh, vous verrez bien par vous-même, " + GetAddress_Form(NPChar) + ". Je m'appelle " + GetFullName(npchar) + ". Je suis le patron de cette taverne.";
			Link.l1 = "J'ai besoin d'un équipage, " + npchar.name + ".";
			Link.l1.go = "crew hire";
			Link.l2 = NPChar.name + ", parlons-en...";
			Link.l2.go = "int_quests";
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
			{
				link.l21 = "וcoutez, il faut que nous parlions finances.";
				link.l21.go = "LoanForAll";//(перессылка в кредитный генератор)
			}
			// Квестовый генератор священника. Квест №2. Warship -->
			if(CheckAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen") && PChar.location == PChar.GenQuest.ChurchQuest_2.QuestTown + "_tavern")
	        {
				link.l10 = LinkRandPhrase("Pouvez-vous me dire quelque chose sur le récent vol commis dans une église ?", "Que savez-vous du récent vol commis dans l'église d'ici ?", "Avez-vous entendu parler du récent vol commis dans l'église d'ici ?");
				link.l10.go = "Tavern_GenQuest_Church_2_1";
			}
			// <-- Квестовый генератор священника. Квест №2.
			link.l3 = pcharrepphrase("Il y a une niche de libre dans ton nid à punaises ?", "Vous avez une chambre de libre ? J'aimerais séjourner ici quelque temps.");
			link.l3.go = "room";
			Link.l4 = "Je repasserai sans doute plus tard.";
			Link.l4.go = "exit";
			// Gregg: "The Vanishing" (ported from Damned Destiny) - the pointer to monsieur Gotie
			if (CheckAttribute(PChar, "DisappearPeople"))
			{
				if (PChar.DisappearPeople == "3")
				{
					link.l40 = "Salut, vieil ami ! Quelles nouvelles ?";
					link.l40.go = "DisappearPeople_1";
				}
				// Gregg: the first keeper names only the country. There are three Dutch
				// colonies, so without a second hint the search is a walk through all of
				// them. Any of the three answers: Marigo points at the house, the other
				// two send the player to Saint Martin.
				if (PChar.DisappearPeople == "4")
				{
					// однородная цепочка || - смешивать её с && в одном if нельзя
					if (NPChar.id == "Marigo_tavernkeeper" || NPChar.id == "Villemstad_tavernkeeper" || NPChar.id == "FortOrange_tavernkeeper")
					{
						link.l42 = "Oם pourrais-je trouver un certain monsieur Gotie ? Un savant, dit-on, spécialiste des antiquités indiennes.";
						link.l42.go = "DisappearPeople_3";
					}
				}
			}
			// Gregg: quest "The Monkey Ship" (ported from Damned Destiny) - the lead to the
			// church of Beliz. Ask the Bas-Terre tavernkeeper: that is where Allen hooked us.
			if (CheckAttribute(PChar, "CaptainMonkey"))
			{
				if (PChar.CaptainMonkey == "3")
				{
					if (NPChar.id == "BasTer_tavernkeeper")
					{
						link.l41 = "Dites-moi, un type en guenilles nommé Allen Gladstonn est-il passé par ici ?";
						link.l41.go = "CaptainMonkey_1";
					}
				}
			}
		break;

		// Gregg: THE VANISHING (ported from Damned Destiny) -->
		case "DisappearPeople_1":
			dialog.text = "Quelles nouvelles voulez-vous que je vous raconte ? Presque chaque famille a perdu quelqu'un. L'un a perdu un frère ou une sœur, l'autre ses enfants ! Une terrible affaire.";
			link.l1 = "וcoute, mon ami, y a-t-il quelqu'un dans ta ville, ou ailleurs, qui pourrait expliquer tout ça ?";
			link.l1.go = "DisappearPeople_2";
		break;

		case "DisappearPeople_2":
			dialog.text = "Non, je ne crois pas. Mais on m'a dit qu'il existait un tel homme : un savant, un historien, un grand spécialiste de la culture indienne, un certain monsieur Gotie. C'est un Hollandais, mais je ne sais pas oם il vit exactement ; dans l'une des colonies des Pays-Bas, je suppose. Mais je doute qu'il en sache quelque chose, lui non plus.";
			link.l1 = "Merci, l'ami. Je vais me mettre en route.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleToGotie");
		break;

		case "DisappearPeople_3":
			if (NPChar.id == "Marigo_tavernkeeper")
			{
				dialog.text = "Gotie ? Tout près, à cכté de l'église. Sortez sur la place : c'est la maison en face, au coin, la porte sous l'auvent. Attention, il n'ouvre pas à tout le monde : il garde ses livres comme de l'or.";
				link.l1 = "Merci, je vais aller le voir.";
			}
			else
			{
				dialog.text = "J'ai entendu parler de lui. Il s'est installé à Saint-Martin, à Marigot : la maison en face de l'église, au coin. On dit que même son seuil est enseveli sous les papiers.";
				link.l1 = "Va pour Marigot. Merci.";
			}
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleGotieFound");
		break;
		// Gregg: THE VANISHING <--

		// Gregg: THE MONKEY SHIP (ported from Damned Destiny) -->
		case "CaptainMonkey_1":
			dialog.text = "Gladstonn ? Oui, je le connais. Il mendiait à l'église d'ici, jusqu'au jour oם il a disparu. Et il y a environ une semaine, on me l'a rappelé : un marchand du Continent est passé et m'a parlé d'un type en guenilles tout pareil.";
			link.l1 = "Et oם l'a-t-il vu ?";
			link.l1.go = "CaptainMonkey_2";
		break;

		case "CaptainMonkey_2":
			dialog.text = "א Belize, à l'église. Il était assis sur un banc avec l'air le plus pieux du monde et mendiait des sous aux paroissiens. Le marchand en a été tout surpris : entre ces murs sacrés, disait-il, avec des yeux de renard devant un poulailler.";
			link.l1 = "Merci, l'ami. Je crois que je vais rendre visite à ce saint homme.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyBarmanTold");
		break;
		// Gregg: THE MONKEY SHIP <--

		case "crew hire":
			ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
			if (NPChar.id == "Caiman_tavernkeeper") ok = true;
			ok = sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok;

			// здесь убираю условие
			if (!ok)
			{
				Dialog.text = "Pourquoi avez-vous besoin de marins ? Je ne vois pas votre navire au port.";
				link.l1 = RandPhraseSimple("Exact... Je l'ai amarré au mauvais endroit.", "J'ai oublié d'entrer au port...");
				link.l1.go = "exit";
				break;
			}
			//здесь меняю дату
            if (makeint(environment.time) > 24.0 || makeint(environment.time) < 0.0)
			{
				Dialog.text = "D'habitude, il y a beaucoup de gens dans ma taverne qui veulent devenir marins, mais il est trop tard maintenant, ils ne commenceront à se montrer qu'au matin. Vous voulez louer une chambre et les attendre ?";
				link.l1 = "D'accord. Vous avez des chambres libres ?";
				link.l1.go = "room";
				link.l2 = "La chambre ne m'intéresse pas pour le moment. א plus tard.";
				link.l2.go = "exit";
			}
			else
			{
                if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
                {
                    Dialog.text = "Vous croyez que quelqu'un viendra vous voir alors que vous êtes en guerre avec nous ? Estimez-vous heureux que je n'appelle pas la garde.";
					link.l1 = "Merci.";
					link.l1.go = "exit";
                }
                else
                {
					if (CheckAttribute(FortChref, "Fort.Mode") && sti(FortChref.Fort.Mode) == FORT_DEAD)
					{
						Dialog.text = "Il n'y a personne en ce moment. Lors du récent assaut contre la ville, la plupart des candidats sont morts, et les autres se sont cachés si bien qu'on ne les retrouve plus.";
						link.l1 = "Oh, quel dommage !";
						link.l1.go = "exit";
						break;
					}
					if (CheckAttribute(NPChar, "CrewHired.PGGId") && GetNpcQuestPastDayParam(NPChar, "CrewHired") < 1 && GetCrewQuantity(rColony) == 0 && drand(100) > 90)
					{
						Dialog.text = "Désolé, mais il n'y a personne ici en ce moment. Tout le monde est parti avec le brave capitaine " + GetFullName(CharacterFromID(NPChar.CrewHired.PGGId)) + ".";
						link.l1 = "Oh, quel dommage !";
						link.l1.go = "exit";
					}
					else
					{
						if(bPartitionSet)
						{
							if(GetPartitionAmount("CrewPayment") > 0)
							{	
								if(IsEquipCharacterByArtefact(pchar, "talisman11"))
								{
									DeleteAttribute(NPChar, "CrewHired"); //на всяк случай.
									NextDiag.CurrentNode =  NextDiag.TempNode;
									DialogExit();
									LaunchHireCrew();							
								}
								else
								{
									dialog.text = "Capitaine, on dit que vous êtes pingre. Je n'ai personne qui veuille rejoindre votre équipage.";
									link.l1 = "Je vois...";
									link.l1.go = "exit";
								}
							}	
							else
							{
								DeleteAttribute(NPChar, "CrewHired"); //на всяк случай.
								NextDiag.CurrentNode =  NextDiag.TempNode;
								DialogExit();
								LaunchHireCrew();
							}
						}
						else
						{
							DeleteAttribute(NPChar, "CrewHired"); //на всяк случай.
							NextDiag.CurrentNode =  NextDiag.TempNode;
							DialogExit();
							LaunchHireCrew();
						}
					}
				}
			}
		break;
	////////////////////////////////////////////////////////=============================================///////////////////////////////////////////////////////
        case "int_quests":
			dialog.text = "Je suis "+NPCharSexPhrase(NPChar, "tout ouïe", "à l'écoute")+".";
			link.l1 = "Je cherche du travail. Vous m'aidez ?";
			link.l1.go = "work";
			//homo 15/06/06 слухи
			link.l2 = LinkRandPhrase("Vous me racontez les dernières nouvelles ?", "Quoi de neuf dans le coin ?",
                                    "Comment va la vie à terre ?");
			link.l2.go = "rumours_tavern";
			//homo
			// LEO: call the doctor — option if the fleet has wounded, healing isn't paid, and no doctor summoned yet (l17 - l9 is taken by the captain's commission quest)
			if (Wounded_FleetTotal(pchar) > 0 && !CheckAttribute(pchar, "Ship.Crew.woundedTavernHeal") && !CheckAttribute(pchar, "woundedDocPending"))
			{
				link.l17 = "Mes marins ont été blessés au combat. Y a-t-il un médecin dans cette ville ?";
				link.l17.go = "call_doctor";
			}
			link.l3 = "Je suis sur une autre affaire.";
			link.l3.go = "quests";
			// LEO: наводка на бухту наёмного пирата (l18) - только когда срок "захвата" вышел и бухта ещё не открыта
			if (HiredPirate_IsReadyForLead())
			{
				link.l18 = "Vous avez entendu parler d'un corsaire engagé qui se terre quelque part avec une prise pour moi ?";
				link.l18.go = "HiredPirate_AskBarman";
			}
			if (CheckAttribute(pchar, "GenQuest.SeekSpy.City")) //квест мэра по поиску шпиона
			{
				link.l4 = "J'agis pour le compte du gouverneur. Dites-moi, avez-vous remarqué quelqu'un de suspect en ville ces derniers temps ?";
				if (pchar.GenQuest.SeekSpy.City == "0")
				{
					link.l4.go = "SeekSpy_Seen";
				}
				else
				{
					link.l4.go = "SeekSpy_NotSeen";
				}
			}
			if(CheckAttribute(pchar, "GenQuest.EncGirl"))
			{
				if(pchar.GenQuest.EncGirl == "EncGirlFack_fighted")
				{
					link.l5 = "Vous ne sauriez pas oם je peux trouver " + pchar.GenQuest.EncGirl.name +" ?";
					link.l5.go = "EncGirl_1";
				}
				if(pchar.GenQuest.EncGirl == "toParents" || pchar.GenQuest.EncGirl == "FindLover")
				{
					link.l6 = "Vous ne sauriez pas oם je dois chercher " + pchar.GenQuest.EncGirl.sLoverId + " ?";
					link.l6.go = "EncGirl_3";
				}
				if(pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "tavern_keeper" && pchar.GenQuest.EncGirl.LoverCity == npchar.city)
				{
					link.l7 = "Bonjour, je viens à l'invitation de votre fils.";
					link.l7.go = "EncGirl_4";
					pchar.quest.EncGirl_GetLoverFather.over = "yes";
				}
			}
			if(CheckAttribute(pchar, "QuestTemp.Andre_Abel_Quest_PortPax_TavernOwner_Speek"))
			{
				link.l8 = "Pouvez-vous me dire oם chercher Andre Abel ?";
				link.l8.go = "Andre_Abel_Quest_TavernOwner_Dialog_1";
			}
			if(CheckAttribute(pchar, "GenQuest.CaptainComission") && NPChar.city == pchar.GenQuest.CaptainComission.City && CheckAttribute(pchar, "GenQuest.CaptainComission.Speak_Tavern"))
			{
				if(pchar.GenQuest.CaptainComission.variant == "A0")
				{
					if(pchar.GenQuest.CaptainComission.Speak_Tavern == true)
					{
						link.l9 = "Hé, est-ce que " + pchar.GenQuest.CaptainComission.Name + " est passé par ici ?";
						link.l9.go = "CaptainComission_3";
					}
					else
					{
						link.l9 = "Vous ne sauriez pas oם je dois chercher " + pchar.GenQuest.CaptainComission.Name + " ?";
						link.l9.go = "CaptainComission_1";
					}
				}

				if(pchar.GenQuest.CaptainComission.variant == "A2" && pchar.GenQuest.CaptainComission == "Begin_1")
				{
					link.l9 = "Vous ne sauriez pas oם je peux trouver le capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " ?";
					link.l9.go = "CaptainComission_Tavern7";
				}
				if(pchar.GenQuest.CaptainComission.variant == "A3" && pchar.GenQuest.CaptainComission == "Begin_1")
				{
					if(pchar.GenQuest.CaptainComission.Speak_Tavern == true)
					{
						link.l9 = "Hé, " + GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_NOM) + " est venu ici ?";
						link.l9.go = "CaptainComission_3";
					}
					else
					{
						link.l9 = "Savez-vous quelque chose sur le capitaine de patrouille " + GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")) + " " + pchar.GenQuest.CaptainComission.Name + " ?";
						link.l9.go = "CaptainComission_Tavern1";
						if(!CheckAttribute(pchar, "GenQuest.CaptainComission.GetRumour"))
						{
							pchar.GenQuest.CaptainComission.GetRumour = true;
							SaveCurrentQuestDateParam("GenQuest.CaptainComission.GetRumour");
						}
					}
				}
			}
			if(CheckAttribute(pchar, "GenQuest.Hold_GenQuest") && NPChar.city == pchar.GenQuest.Hold_GenQuest.City && pchar.GenQuest.Hold_GenQuest.Speak_Tavern == false )
			{
				link.l10 = "Pouvez-vous me dire oם trouver un monsieur du nom de " + pchar.GenQuest.Hold_GenQuest.Name + " ?";
				link.l10.go = "hold_genquest1";
			}
			if (CheckCharacterItem(pchar, "CaptainBook") && CheckAttribute(pchar, "questTemp.different.GiveShipLetters") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakTavern") && (pchar.questTemp.different.GiveShipLetters.city == npchar.city))
			{
				link.l11 = "Il se trouve que j'ai trouvé des documents de bord....";
				link.l11.go = "ShipLetters_4";
			}

                        //ОЗГ
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
	    		if(pchar.questTemp.Headhunter == "hunt_carlos" && npchar.city == pchar.questTemp.Headhunter.City)
	    		{
	    			link.l12 = "Pouvez-vous me dire oם chercher Carlos Cashier ?";
	    			link.l12.go = "Seek_Carlos";
	    		}
			}

			//zagolski. начальный квест пирата
			if(CheckAttribute(pchar, "questTemp.pirateStartQuest") && pchar.questTemp.pirateStartQuest == "1" && GetArealByCityName(npchar.city) == pchar.questTemp.pirateStartQuest.Areal && npchar.city != pchar.questTemp.pirateStartQuest.City)
			{
				if (!CheckAttribute(pchar, "questTemp.pirateStartQuest.TavernInfo"))
				{
					link.l12 = "וcoute, mon ami, tu peux me dire si personne ne vend d'esclaves par ici ?";
					link.l12.go = "pirateStartQuest_Tavern";
				}
				else
				{
					if (sti(pchar.money) >= 500)
					{
						link.l12 = "Je vous ai apporté 500 piastres. Dites-moi ce que vous savez.";
						link.l12.go = "pirateStartQuest_Tavern_2";
					}
				}
			}
			//Gregg: --> "Помощь святой инквизиции" (перенос из К:ПС)
				// Gregg: l19, а не l14 - l14 в этом узле уже занята ниже по коду
				// и молча затирала эти ссылки: в Storm выигрывает последнее присваивание.
				// Gregg: гард обязателен: короткого замыкания в Storm нет, и связка
				// pchar.HelpSacredInquisition == "1" && ... читает атрибут ещё до того,
				// как он появится. Пока квест не начат - рантайм-ошибка на каждый заход.
				if (CheckAttribute(pchar, "HelpSacredInquisition"))
				{
				if (pchar.HelpSacredInquisition == "1" && NPChar.City == "Santiago")
				{
					link.l19 = "Dites-moi, un certain Nathan Rich a-t-il déjà séjourné ici ?";
					link.l19.go = "HSI_Tavern_1";
				}
				if (pchar.HelpSacredInquisition == "2" && NPChar.City == "BasTer")
				{
					link.l19 = "Nathan Rich s'est-il montré par ici ?";
					link.l19.go = "HSI_Tavern_5";
				}
				if (pchar.HelpSacredInquisition == "4" && NPChar.City == "BasTer")
				{
					link.l19 = "Vous connaissez un certain François Defau ?";
					link.l19.go = "HSI_Tavern_7";
				}
				if (pchar.HelpSacredInquisition == "6" && NPChar.City == "Tortuga")
				{
					link.l19 = "Pourriez-vous me dire oם trouver la femme de François Defau ?";
					link.l19.go = "HSI_Tavern_11";
				}
				}
			//Gregg: <-- "Помощь святой инквизиции"

			//Gregg: --> "Товар для Ричарда Тилльманна" (перенос из К:ПС)
				if (CheckAttribute(pchar, "UneasyDelivery"))
				{
				if (pchar.UneasyDelivery == "1" && NPChar.City == "Bridgetown")
				{
					link.l21 = "Oם trouver le marchand Richard Tillman ?";
					link.l21.go = "UD_Tavern_1";
				}
				}
			//Gregg: <-- "Товар для Ричарда Тилльманна"

			//Gregg: --> "Легенда о призрачном свете" (перенос из К:ПС)
				// Gregg: гард обязателен - короткого замыкания в Storm нет
				if (CheckAttribute(pchar, "MoonStone"))
				{
					if (pchar.MoonStone == "2" && NPChar.City == "SentJons")
					{
						link.l20 = "Pourriez-vous me dire oם trouver Adam Cromwell ?";
						link.l20.go = "MoonLightStone_1";
					}
					if (pchar.MoonStone == "4" && NPChar.City == "Charles")
					{
						link.l20 = "Dites-moi, un certain Francis Ivo vit-il dans cette colonie ?";
						link.l20.go = "MoonLightStone_2";
					}
					if (pchar.MoonStone == "7" && NPChar.City == "FortFrance")
					{
						link.l20 = "Oם puis-je trouver Klein ?";
						link.l20.go = "MoonLightStone_5";
					}
				}
			//Gregg: <-- "Легенда о призрачном свете"
			//Lipsar квест История Давней дружбы--->
				if(CheckAttribute(Pchar, "Quest.Luke") && Pchar.Quest.Luke == "1" && NPChar.City == "LaVega")
				{
					link.l13 = "וcoutez, je cherche l'homme qui était assis à la table à droite de la porte. Vous savez oם il est ?";
					link.l13.go = "LukeQuest_1";
					sld = CharacterFromID("Maks");
					ChangeCharacterAddressGroup(sld, "none", "none", "none");
				}
				if(CheckAttribute(Pchar, "Luke.SpawnMaks") && Pchar.Luke.SpawnMaks == "1")
				{
					sld = CharacterFromID("Maks");
					if(NPChar.Location == sld.City)
					{
						link.l13 = "וcoutez, je cherche un homme nommé Maximilian Weber. Vous savez oם il est ?";
						link.l13.go = "MaksQuest_1";
					}
				}
				//<---Lipsar квест История Давней дружбы
				// Gregg: without the guard the engine throws «missed attribute:
				// tohmaspetit_search» for anyone who talks to a keeper before the quest starts
				if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_Search"))
				{
					bool bTohmasDone = false;
					if (CheckAttribute(pchar, "questdata.TohmasPetit")) bTohmasDone = (sti(pchar.questdata.TohmasPetit) == 1);
					// Борода: квест закрыт, а флаг поиска остался - чистим на месте, иначе фраза висит вечно
					// и плодит записи в завершённом квесте. Заодно лечит старые сейвы.
					if (bTohmasDone)
					{
						DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search");
					}
					else
					{
						if (pchar.QuestTemp.TohmasPetit_Search == "active" && npchar.location == "BasTer_tavern")
						{
							link.l16 = "וcoutez, mon brave, je cherche une personne nommée Thomas Petit. Sauriez-vous par hasard oם la trouver ?";
							link.l16.go = "TohmasPetit_BarmanBranch";
						}
					}
				}

			link.l14 = "Auriez-vous des nouvelles de mes collègues en mer ?";
			link.l14.go = "PGGInfo";

			link.l15 = "Merci, rien. Au revoir.";
			link.l15.go = "exit";
		break;

		// LEO: barman gives the lead to the hired privateer's bay
		case "HiredPirate_AskBarman":
			HiredPirate_BarmanLead();
			dialog.text = "(il baisse la voix) Oui, la rumeur court. Votre homme se terre à " + pchar.GenQuest.HiredPirate.BayName + ", au large de " + XI_ConvertString(pchar.GenQuest.HiredPirate.BayIsland + "Gen") + ". Mettez le cap dessus et débarquez : vous le trouverez là-bas.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		// LEO: call the doctor — the keeper summons him, the doctor walks up himself (spawned on exit), deal is with him
		case "call_doctor":
			pchar.woundedDocPending = "1"; // LEO: dedup - don't spawn multiple doctors (cleared in the daily tick food.c / by the option gate)
			dialog.text = "Des blessés, hein ? Il y a un médecin compétent tout près, il passe souvent chez moi. Hé, docteur ! Venez par ici, c'est votre partie ! Il arrive tout de suite, capitaine, arrangez-vous avec lui.";
			AddDialogExitQuest("spawn_tavern_doctor");
			link.l1 = "Merci, mon ami.";
			link.l1.go = "exit";
		break;

		//-------------------------------------------
		case "PGGInfo":
			int rep = pchar.reputation;
			int repcheck = 40;
			if (IsCharacterPerkOn(pchar, "Adventurer"))
			{
				repcheck = 10;
			}

			if (rep < repcheck)
			{
				dialog.text = "Je sais peut-être quelque chose, mais on ne peut pas confier ce genre d'informations à quelqu'un de votre réputation. Alors fichez le camp d'ici avec vos questions, capitaine !";
				link.l1 = "Bon, d'accord, je m'en vais !";
				link.l1.go = "exit";
			}
			else
			{
				int cost = 4000 + makeint(500 * sti(PChar.rank) * MOD_SKILL_ENEMY_RATE*3/2);
				if (IsCharacterPerkOn(pchar, "Agent"))
				{
					cost = makeint(cost/2);
				}
				dialog.text = "Hum, eh bien, je sais peut-être quelque chose... Mais ça ne sera pas donné, capitaine. Je vous demanderai pour ça "+cost+" et pas un sou de moins ! דa vous convient ?";
				if (sti(pchar.money) >= cost)
				{
					link.l1 = "D'accord, voici votre argent. Maintenant, dites-moi ce que vous savez.";
					link.l1.go = "PGGInfo_2";
				}
				link.l2 = "Peut-être une autre fois.";
				link.l2.go = "exit";
			}
		break;

		case "PGGInfo_2":
			int cost1 = 4000 + makeint(500 * sti(PChar.rank) * MOD_SKILL_ENEMY_RATE*3/2);
			if (IsCharacterPerkOn(pchar, "Agent"))
			{
				cost1 = makeint(cost1/2);
			}
			AddMoneyToCharacter(pchar, -cost1);
			pchar.buyPGGinfo = 1;//купили инфо
			SaveCurrentQuestDateParam("buy_PGG_info");
			AddDialogExitQuestFunction("OpenPGGInformation");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "pirateStartQuest_Tavern":
			dialog.text = "Vous êtes sérieux ?! Dans la colonie pirate voisine, ce genre d'affaire se règle très simplement.";
			link.l1 = "J'y suis allé. Ils n'ont plus rien en ce moment, et je ne peux pas attendre : une très bonne affaire est en train de m'échapper. Je n'ai que quelques jours, après je n'en aurai plus besoin.";
			link.l1.go = "pirateStartQuest_Tavern_1";
		break;
		case "pirateStartQuest_Tavern_1":
			dialog.text = "Hum, eh bien, je sais peut-être quelque chose... Mais je ne parlerai pas pour rien, je ne fais pas la charité. Mes informations valent 500 piastres. Payez ou partez.";
			if (sti(pchar.money) >= 500)
			{
				link.l1 = "D'accord, voici 500 piastres pour vous... Dites-moi ce que vous savez.";
				link.l1.go = "pirateStartQuest_Tavern_2";
			}
			else
			{
				link.l1 = "Je n'ai pas assez d'argent... Je reviendrai quand je l'aurai.";
				link.l1.go = "exit";
				pchar.questTemp.pirateStartQuest.TavernInfo = "";
			}
		break;
		case "pirateStartQuest_Tavern_2":
			AddMoneyToCharacter(pchar, -500);
			dialog.text = "Eh bien, je ne sais pas. Cette affaire relève de la justice, alors personne ne vous proposera d'esclaves ouvertement. Les planteurs les achètent eux-mêmes là oם ils peuvent en trouver. א moins de demander aux contrebandiers. Mais les pirates ont pris ce commerce en main depuis longtemps, et rares sont ceux qui oseraient s'en prendre ouvertement à leur monopole...";
			link.l1 = "Compris. Savez-vous si la goélette Sentblue est entrée récemment dans votre port ?";
			link.l1.go = "pirateStartQuest_Tavern_3";
		break;
		case "pirateStartQuest_Tavern_3":
			dialog.text = "Le « SentBlue » ? Non, il n'est certainement pas entré. Et ce nom ne me dit rien.";
			link.l1 = "D'accord, merci. Vous m'avez été d'une grande aide. א plus tard.";
			link.l1.go = "exit";

			PChar.questTemp.pirateStartQuest = "2";
			pchar.questTemp.pirateStartQuest.City2 = npchar.city;
			DeleteAttribute(pchar, "questTemp.pirateStartQuest.TavernInfo");
			AddQuestRecord("pSQ", "2");
			AddQuestUserData("pSQ", "sCity2", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City2 + "Gen"));
		break;


		case "hold_genquest1":
			switch(sti(pchar.GenQuest.Hold_GenQuest.TavernVariant))
			{
				case 0:
					dialog.text = LinkRandPhrase("Comment dites-vous ? " + pchar.GenQuest.Hold_GenQuest.Name + " ? Hum, je n'en ai jamais entendu parler.",
						"Vous êtes sמr qu'il est de notre colonie ? C'est juste que je n'en ai jamais entendu parler.",
						"Il n'y a jamais eu personne de ce nom dans notre colonie. Je n'en ai pas entendu parler depuis que je vis ici.");
					link.l1 = "Vous êtes sמr ?";
					link.l1.go = "hold_genquest2";
				break;

				case 1:
					switch (drand(3))
					{
						case 0:
							pchar.GenQuest.Hold_GenQuest.foundStr = "à l'église";
							pchar.GenQuest.Hold_GenQuest.found = "church";
						break;
						case 1:
							if (npchar.city != "Panama")
							{
								pchar.GenQuest.Hold_GenQuest.foundStr = "au chantier naval";
								pchar.GenQuest.Hold_GenQuest.found = "shipyard";
							}
							else
							{
								pchar.GenQuest.Hold_GenQuest.foundStr = "à l'église";
								pchar.GenQuest.Hold_GenQuest.found = "church";
							}
						break;
						case 2:
							pchar.GenQuest.Hold_GenQuest.foundStr = "chez l'usurier";
							pchar.GenQuest.Hold_GenQuest.found = "bank";
						break;
						case 3:
							pchar.GenQuest.Hold_GenQuest.foundStr = "au magasin";
							pchar.GenQuest.Hold_GenQuest.found = "store";
						break;
					}
					dialog.text = "Allez " + pchar.GenQuest.Hold_GenQuest.foundStr + ", il y est d'habitude.";
					link.l1 = "Merci, je ne manquerai pas d'y passer.";
					link.l1.go = "hold_genquest3";
				break;

				case 2:
					dialog.text = LinkRandPhrase(
						RandPhraseSimple("Que dites-vous ? " + pchar.GenQuest.Hold_GenQuest.Name + " ? Hum, je n'en ai jamais entendu parler. Vous êtes sמr qu'il est de notre colonie ?",
						"Eh eh eh... Dieu seul sait oם le chercher maintenant, au paradis ou en enfer. Il est mort... ça fait deux ans qu'il est mort, et tout le monde vient me poser des questions sur lui, fouiner, on ne lui laisse pas de repos, le pauvre..."),
						RandPhraseSimple("Vous ne le trouverez plus, en tout cas pas dans ce monde. Il n'y a pas si longtemps, il est mort de la fièvre jaune... Dieu ait son âme... Et quel dur à cuire c'était ! Dans sa jeunesse, dit-on, il en a fait de belles, Dieu nous en garde ! Et voilà : la camarde est venue, souvenez-vous de son nom...",
						"Hé, raté ! Il est parti depuis longtemps. Il est allé rejoindre ses enfants, ou en Europe, personne ne sait. Il a juste fait ses bagages et il a filé."),
						"Ah, ce ne serait pas ce " + pchar.GenQuest.Hold_GenQuest.Name + " que vous cherchez, celui qui s'est soudain enrichi et s'est acheté une maison en Nouvelle-Albion ? Et dire qu'il fut un temps oם je lui offrais du rhum à crédit ! Il me doit de l'argent à ce jour. Alors allez donc le récupérer maintenant ! Non, les gens ne se souviennent pas du bien qu'on leur a fait...");
					link.l1 = "Compris. Eh bien, merci quand même.";
					link.l1.go = "hold_genquest4";
				break;

				case 3:
					dialog.text = "Et oם le chercher, sinon dans notre taverne ? Il vient souvent ici : il noie ses vieux péchés dans le rhum, hé hé. Revenez plus tard ; s'il se montre, je lui dirai de vous attendre.";
					link.l1 = "Merci, je repasserai.";
					link.l1.go = "hold_genquest5";
				break;
			}
			pchar.GenQuest.Hold_GenQuest.Speak_Tavern = true;
		break;

		case "hold_genquest2":
			dialog.text = "Comment pourrais-je ne pas en être sמr, alors que je connais tous les colons d'ici comme ma poche ? דa fait des années que je tiens cette taverne\n"+
				"Je les ai vus sous toutes les coutures : ceux que leur femme ramène à la maison, ceux qui regagnent toujours le port tout seuls, la cale pleine, et ceux qu'il a fallu mettre dehors en échange. Et vous venez me demander si je suis « sמr » !";
			link.l1 = "Eh bien, merci quand même...";
			link.l1.go = "exit";
			pchar.GenQuest.Hold_GenQuest = "prisoner_escaped";
			AddQuestRecord("HoldQuest", "7");
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.CapName);
			AddDialogExitQuestFunction("Hold_GenQuest_PrisonerEscaped");
		break;

		case "hold_genquest3":
			Hold_GenQuest_GenerateChar();
			AddQuestRecord("HoldQuest", "8");
			AddQuestUserData("HoldQuest", "sCity", XI_ConvertString("Colony" + pchar.GenQuest.Hold_GenQuest.City + "Gen"));
			AddQuestUserData("HoldQuest", "sFoundChar", pchar.GenQuest.Hold_GenQuest.foundStr);
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.Name);
			SetFunctionTimerConditionParam("Hold_GenQuest_FindCharTimeIsOver", 0, 0, 1, MakeInt(24 - GetHour()), false);
			DialogExit();
		break;

		case "hold_genquest4":
			AddQuestRecord("HoldQuest", "13");
			AddQuestUserData("HoldQuest", "sName", pchar.GenQuest.Hold_GenQuest.CapName);
			AddQuestUserData("HoldQuest", "sNameChar", pchar.GenQuest.Hold_GenQuest.Name);
			AddQuestUserData("HoldQuest", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("HoldQuest");
			DeleteAttribute(pchar, "GenQuest.Hold_GenQuest");
			DialogExit();
		break;

		case "hold_genquest5":
			SetFunctionTimerConditionParam("Hold_GenQuest_GetMapTimeIsOver", 0, 0, 1, MakeInt(24 - GetHour()), false);
			DialogExit();
			AddDialogExitQuestFunction("Hold_GenQuest_GenerateMapChar");
		break;

		case "CaptainComission_1":
			dialog.text = LinkRandPhrase("Il vient souvent ici, mais en ce moment on ne le voit pas. Repassez me voir de temps en temps ; s'il se montre, je lui dirai de vous attendre.", "Il vient souvent ici. Si vous repassez plus tard, vous le trouverez sמrement.", "Passez de temps en temps, il vient souvent ici. Je lui dirai que vous le cherchiez.");
			link.l1 = "Merci, je reviendrai plus tard...";
			link.l1.go = "CaptainComission_2";
			pchar.GenQuest.CaptainComission.Speak_Tavern = true;
		break;

		case "CaptainComission_2":
			pchar.quest.CapComission_ExitFromTavern.win_condition.l1 = "ExitFromLocation";
			pchar.quest.CapComission_ExitFromTavern.win_condition.l1.location = pchar.location;
			pchar.quest.CapComission_ExitFromTavern.function = "CaptainComission_GenerateChar";

			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "CaptainComission_3":
			dialog.text = "Il est venu. Il doit être assis quelque part par ici...";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "GenQuest.CaptainComission.Speak_Tavern");
		break;

		case "CaptainComission_Tavern1":
			pchar.GenQuest.CaptainComission.Speak_Tavern = true;
			dialog.text = "Qui ne le connaît pas ? דa fait des jours qu'on ne parle que de ça dans la colonie.";
			link.l1 = "Pouvez-vous m'en dire plus ?";
			link.l1.go = "CaptainComission_Tavern2";
		break;

		case "CaptainComission_Tavern2":
			dialog.text = "Mais c'est difficile à croire, parce qu'on n'a retrouvé ni le propriétaire de ce navire, ni les marchandises... On fouille encore toutes les baies.";
			link.l1 = "Vraiment ? Personne de l'équipage n'a avoué oם se trouvait la cachette ?";
			link.l1.go = "CaptainComission_Tavern3";
		break;

		case "CaptainComission_Tavern3":
			dialog.text = "Personne !.. Je ne comprends pas pourquoi le gouverneur a cru si facilement à cette calomnie. Après tout, le capitaine  " + pchar.GenQuest.CaptainComission.Name + " était bien vu, et sa façon de tenir son équipage, n'importe quel amiral la lui envierait, croyez-moi.";
			link.l1 = " Oם dois-je chercher les membres de l'équipage qui ont survécu ?";
			link.l1.go = "CaptainComission_Tavern4";
		break;


		case "CaptainComission_Tavern4":
			dialog.text = "Eh bien, je n'en sais rien, ils les ont tous emmenés... Mais non, il en reste un, mais il ne vous sera sans doute d'aucune utilité. Il a été commotionné, il était canonnier sur le " + pchar.GenQuest.CaptainComission.Name + ". On l'a retrouvé sans connaissance dans une baie deux jours après ce malheureux incident. D'abord, on l'a envoyé à l'hכpital comme un héros, puis, quand les choses ont tourné autrement, on l'a jeté au cachot et on a essayé de l'interroger, mais on a fini par décider qu'il fallait encore le soigner.";
			link.l1 = "Il est donc dans la colonie en ce moment ?";
			link.l1.go = "CaptainComission_Tavern5";
		break;

		case "CaptainComission_Tavern5":
			pchar.GenQuest.CaptainComission.CanoneerName = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			dialog.text = "Oui, il s'appelle " + GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_NOM) + "; il passe parfois ici mendier du rhum. Si je le vois, je lui dirai de vous attendre.";
			link.l1 = "Merci, je reviendrai plus tard.";
			link.l1.go = "CaptainComission_Tavern6";
		break;

		case "CaptainComission_Tavern6":
			AddQuestRecord("CaptainComission2", "39");
			AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")));
			AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			AddQuestUserData("CaptainComission2", "sCharName", GetName( NAMETYPE_ORIG, pchar.GenQuest.CaptainComission.CanoneerName, NAME_ABL));
			AddQuestUserData("CaptainComission2", "sShipName", pchar.GenQuest.CaptainComission.ShipTypeName);
			SetFunctionExitFromLocationCondition("CaptainComission_GenerateCanoneer", pchar.location, false);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "CaptainComission_Tavern7":
			DeleteAttribute(pchar, "GenQuest.CaptainComission.Speak_Tavern");
			dialog.text = "Comment ne pas le connaître ? Bien sמr que je le connais. Pourquoi avez-vous besoin de lui ?";
			link.l1 = "J'ai une affaire pour lui.";
			link.l1.go = "CaptainComission_Tavern8";
		break;

		case "CaptainComission_Tavern8":
			dialog.text = "Je me méfierais de cette « affaire », à votre place, " + GetAddress_Form(pchar) + ". " + pchar.GenQuest.CaptainComission.Name + " a été arrêté, soupçonné d'un crime commis en service, et maintenant les limiers du gouverneur ratissent l'île à la recherche de ses complices.";
			link.l1 = "Vraiment... Qu'a-t-il fait ?";
			link.l1.go = "CaptainComission_Tavern9";
		break;

		case "CaptainComission_Tavern9":
			dialog.text = "Je ne sais pas ce qu'il y a de vrai là-dedans, mais on dit qu'il aurait caché la cargaison qu'il avait confisquée à un navire pirate de passage. Seulement, personne n'a réussi à retrouver ni le pirate ni la cargaison. Je ne comprends pas pourquoi le gouverneur a cru si facilement à cette calomnie. Après tout, le capitaine " + pchar.GenQuest.CaptainComission.CapName + "  était bien vu, et c'est un excellent soldat, croyez-moi, " + GetAddress_Form(pchar) + ".";
			link.l1 = "Eh bien, merci de l'avertissement. Bonne journée.";
			link.l1.go = "CaptainComission_Tavern10";
		break;

		case "CaptainComission_Tavern10":
			if(!CheckAttribute(pchar, "GenQuest.CaptainComission.GetRumour"))
			{
				pchar.GenQuest.CaptainComission.GetRumour = true;
				SaveCurrentQuestDateParam("GenQuest.CaptainComission.GetRumour");
				SetFunctionTimerConditionParam("CaptainComission_TimeIsOver", 0, 0, 2, MakeInt(24 - GetHour()), false);
				AddQuestRecord("CaptainComission2", "19");
				AddQuestUserData("CaptainComission2", "sShipType", GetStrSmallRegister(XI_ConvertString(GetBaseShipParamFromType(sti(pchar.GenQuest.CaptainComission.ShipType), "Name") + "Acc")));
				AddQuestUserData("CaptainComission2", "sName", pchar.GenQuest.CaptainComission.Name);
			}
			DialogExit();
		break;

		case "EncGirl_1":
			dialog.text = " Pourquoi avez-vous besoin d'elle ?";
			link.l1 = "J'ai une affaire pour elle...";
			link.l1.go = "EncGirl_2";
		break;

		case "EncGirl_2":
			dialog.text = "La moitié des hommes de notre colonie ont affaire à elle. Si les femmes l'avaient attrapée, elles l'auraient jetée toute nue hors des portes de la ville.";
			link.l1 = "Oh. "+ GetSexPhrase("On dirait que je suis tout au bout d'une longue file d'attente. Si quelqu'un la demande, dites-lui de m'attendre en premier", "Je vois") +"...";
			link.l1.go = "exit";
			pchar.quest.EncGirl_SpeakTavernKeeper.over = "yes";
			DeleteAttribute(pchar, "GenQuest.EncGirl");
		break;

		case "EncGirl_3":
			dialog.text = "Il vient souvent ici en espérant trouver du travail, mais en ce moment on ne le voit pas. Repassez me voir de temps en temps ; s'il se montre, je lui dirai de vous attendre.";
			link.l1 = "Merci, je reviendrai plus tard...";
			link.l1.go = "exit";
			pchar.GenQuest.EncGirl = "FindingLover";
			pchar.quest.EncGirl_ExitTavern.win_condition.l1 = "ExitFromLocation";
			pchar.quest.EncGirl_ExitTavern.win_condition.l1.location = pchar.location;
			pchar.quest.EncGirl_ExitTavern.function = "EncGirl_GenerateLover";
		break;

		case "EncGirl_4":
			if(sti(pchar.GenQuest.EncGirl.LoverFatherAngry) == 0)
			{
				dialog.text = "Ah, c'est donc vous "+ GetSexPhrase("le capitaine qui a ramené", "la fille qui a ramené") +" mon fils prodigue avec sa jeune fiancée ?";
				link.l1 = "Oui, je les ai aidés à s'enfuir.";
				link.l1.go = "EncGirl_5";
			}
			else
			{
				dialog.text = "Ah, vous voilà enfin, "+ GetSexPhrase(" mon bienfaiteur", " ma bienfaitrice") +". Vous attendez une récompense ?";
				link.l1 = "Eh bien, pas forcément une récompense, mais un peu de gratitude ferait plaisir.";
				link.l1.go = "EncGirl_6";
			}
		break;

		case "EncGirl_5":
			dialog.text = "Je vous suis très reconnaissant de ne pas avoir abandonné mon enfant dans l'embarras et de l'avoir aidé à se tirer avec honneur d'une situation aussi délicate. Permettez-moi de vous remercier comme je le peux. Acceptez cette modeste somme et un cadeau de ma part.";
			link.l1 = "Merci, ce fut un plaisir d'aider ces jeunes gens.";
			link.l1.go = "EncGirl_5_1";
		break;

		case "EncGirl_6":
			dialog.text = "Quelle gratitude ?! De la gratitude pour quoi ?! Non seulement ce benêt traîne sans travail depuis six mois, mais en plus il a trouvé le temps de s'amouracher ! Moi, à son âge, je dirigeais déjà ma propre affaire. Et voyez-moi ça, il est parti à la chasse ! Le gouverneur a une fille à marier, et celui-ci nous ramène une traînée sans feu ni lieu, Dieu me pardonne, et il demande la bénédiction paternelle !";
			link.l1 = "Hum, vous ne croyez donc pas aux sentiments sincères ?";
			link.l1.go = "EncGirl_6_1";
		break;

		case "EncGirl_5_1":
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.EncGirl.sum));
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "18");
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_6_1":
			dialog.text = "De quels sentiments parlez-vous ?! Quels sentiments ? Un adulte, une personne comme il faut, et puis voilà... Des sentiments ! Vous devriez avoir honte, vous les jeunes, de vous livrer à de telles choses, et de jouer les entremetteurs. La fille a été arrachée au nid de ses parents et la vie de mon nigaud est ruinée. Vous n'aurez aucune gratitude de ma part. Au revoir.";
			link.l1 = "Eh bien, portez-vous bien, vous aussi...";
			link.l1.go = "EncGirl_6_2";
		break;

		case "EncGirl_6_2":
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("JungleGirl", "19");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ShipLetters_4":
			pchar.questTemp.different.GiveShipLetters.speakTavern = true;
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Voyons voir ! Hum... Vous êtes capitaine vous-même. Je pense que vous devriez aller voir le capitaine du port.";
				link.l1 = "Merci du conseil.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Voyons voir ! Oh ! D'après le nom, ils appartiennent à l'un de mes habitués, un homme très convenable. Je peux remettre moi-même les documents à leur propriétaire.";
				link.l1	= "Plutכt pas...";
				link.l1.go = "exit";
				link.l2 = "Heureux d'avoir pu lui être utile.";
				link.l2.go = "ShipLetters_end";
			}
		break;

		case "ShipLetters_end":
			TakeItemFromCharacter(pchar, "CaptainBook");
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "3");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//эскорт-пассажиры
		case "work":
		ok = (rColony.from_sea == "") || (Pchar.location.from_sea == rColony.from_sea);
		if (sti(Pchar.Ship.Type) != SHIP_NOTUSED && ok)
		{
			// Gregg: "Goods for Richard Tillman" (ported from Damned Destiny) - the entry for
			// those who did not take the alternative prologue: there the lugger crew hands it over.
			// The innkeeper only names the merchant and opens his door - Tillman himself is not
			// in the tavern, he is at home, as in the original.
			int iTillmanRankReq = 1;
			if (!bQuestsRank) iTillmanRankReq = 3;
			if (!CheckAttribute(PChar, "UneasyDelivery") && PChar.location == "Bridgetown_tavern" && sti(pchar.rank) >= iTillmanRankReq)
			{
				dialog.text = "Il y a du travail. Le marchand Richard Tillman cherche un capitaine : il a une cargaison à transporter. Sa maison est juste ici, près de la sortie vers la plantation, vous la trouverez.";
				link.l1 = "Merci, voilà du travail trouvé.";
				link.l1.go = "exit";
				Log_TestInfo("Goods for Richard Tillman - quest given by the Bridgetown innkeeper");
				UneasyDeliveryStartFromTavern();
				break;
			}
			int  iOrionRankReq = 1;
			if (!bQuestsRank) iOrionRankReq = 5;	//Если стоит галочка, то убрать требования рангов у квестов
			if (!CheckAttribute(PChar, "QuestTemp.AndreAbelQuest_StartQuest") && PChar.location == "FortFrance_tavern" && sti(pchar.rank) >= iOrionRankReq)
			{
				dialog.text = "Parlez à ce type, là-bas, à droite de l'escalier. Il a une sorte de problème.";
				link.l1 = "Merci !";
				link.l1.go = "exit";
				Log_TestInfo("Сопровождение флейта 'Орион' - сгенерился квестодатель в sit, sit7");
				PChar.QuestTemp.AndreAbelQuest_StartQuest = true;
				PChar.QuestTemp.AndreAbelQuest = true;

				// Потереть для начала новой игры -->
				sld = GetCharacter(NPC_GenerateCharacter("Andre_Abel" , "officer_19", "man", "man", 10, FRANCE, -1, true));
				FantomMakeCoolFighter(sld, 10, 30, 35, "blade9", "pistol2", 10);
				FantomMakeCoolSailor(sld, SHIP_FLEUT, "Orion", CANNON_TYPE_CANNON_LBS16, 30, 30, 30);
				sld.name = "Andre";
				sld.lastname = "Abel";
				sld.SaveItemsForDead = true; // сохранять на трупе вещи
				sld.DontClearDead = true; // не убирать труп через 200с
				sld.dialog.FileName = "Quest\Andre_Abel_Dialog.c";
				sld.greeting = "cit_quest";
				LAi_SetSitType(sld);
				LAi_SetImmortal(sld, true);	// До поры нельзя убить
				SetCharacterGoods(sld, GOOD_SILK, 700);
				SetCharacterGoods(sld, GOOD_TOBACCO, 500);
				FreeSitLocator("FortFrance_tavern", "sit7");
				ChangeCharacterAddressGroup(sld, "FortFrance_tavern", "sit", "sit7");
				SetFunctionTimerCondition("Andre_Abel_Quest_1Day_Left", 0, 0, 1, false);
				// <-- Потереть для начала новой игры
				break;
			}
			if (sti(NPChar.nation) != PIRATE && GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY)
			{
				dialog.text = RandPhraseSimple("Je me moque de savoir qui je sers : l'argent n'a pas de nationalité. Mais je ne vous aiderai pas, parce que vous naviguez sous le pavillon de " + NationNameGenitive(sti(pchar.nation)) + " - je n'y peux rien.", "Je ne suis qu'un simple tavernier, mais je n'ai aucune envie de coopérer avec " + NationNameAblative(sti(pchar.nation)) + ".");
				link.l1 = RandPhraseSimple("Hum, vous avez raison...", "Eh bien, comme vous voudrez...");
				link.l1.go = "exit";
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				dialog.text = RandPhraseSimple("D'habitude, les passagers ne manquent pas. Mais il est peu probable qu'il y ait parmi eux un naïf qui se décide à voyager sur votre navire. Votre mauvaise réputation vous précède, et la réputation d'un capitaine honnête, ça se mérite.", "Des marchands qui ont besoin d'une escorte viennent souvent me voir. Mais votre mauvaise réputation vous suit partout, et je ne recommanderai vos services à personne. Je tiens trop à ma propre réputation.");
				link.l1 = RandPhraseSimple("Oui, ne croyez pas tous les ragots...", "Oui, on ne peut pas faire taire tout le monde...", "Eh, les gens sont devenus bien peureux...");
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Il y a du travail, si vous n'avez pas peur d'aller dans les colonies pirates ou dans les ports des nations ennemies. C'est d'ailleurs généralement la seule chose pour laquelle les marchands s'adressent à moi : ils cherchent une escorte, ou bien ce sont des passagers qui n'osent pas passer par la capitainerie. Quelque chose de précis vous intéresse ?";
			link.l1 = "Eh bien, ça ne me fait pas peur. Je prendrais bien l'escorte.";
			link.l1.go = "work_1";
			link.l2 = "Il y a des passagers ? Je les emmènerai jusqu'en enfer, pourvu qu'ils paient.";
			link.l2.go = "work_2";
			link.l3 = "Non, ce genre de travail n'est pas pour moi. Merci.";
			link.l3.go = "exit";
		}
		else
		{
		dialog.text = "Oם est votre navire ? Amarrez votre bateau au quai, et ensuite nous parlerons de travail.";
		link.l1 = "Hum, c'est vrai...";
		link.l1.go = "exit";
		}
		break;

		case "work_1":
			if (!CheckAttribute(npchar, "work_date") || GetNpcQuestPastDayParam(npchar, "work_date") >= 1 || bBettaTestMode)
    		{
				if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 5 || makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)) < 1)//при низком авторитете и на 7 класс не даём
				{
				dialog.text = "Désolé, mais je n'ai personne qui souhaite voyager avec vous.";
				link.l1 = "Compris. Comme vous voudrez.";
                link.l1.go = "exit";
				break;
				}
				//конвой
                if (!CheckQuestAttribute("generate_convoy_quest_progress", "begin"))
                {
					if (GetCompanionQuantity(PChar) == COMPANION_MAX)
					{
						dialog.text = "Hum, mais votre escadre est trop grande pour une escorte. Vous risqueriez de perdre vos propres navires au lieu de sauver ceux des autres.";
						link.l1 = "Allons, je ne perdrai pas les miens, sauf à en vendre un ou deux... Bon, je reviendrai plus tard si je me décide.";
						link.l1.go = "exit";
					}
					else
					{
						if (drand(8) > 1)
						{
							dialog.text = "Eh bien, parlez à ce type, là-bas, qui vient d'entrer dans la taverne. Il a demandé une escorte aujourd'hui.";
							link.l1 = RandPhraseSimple("Vous le connaissez bien ? Ce n'est pas une sorte de pirate ?", "Et qui est-ce ? Vaut-il la peine de traiter avec lui ?");
							link.l1.go = "ConvoyAreYouSure";
						}
            			else
            			{
            				dialog.text = "Aujourd'hui, comme par hasard, personne n'est venu demander d'escorte. Revenez dans quelques jours, quelqu'un se présentera peut-être.";
							link.l1 = RandPhraseSimple("D'accord, tant pis.", "Oui, pas de chance... Eh bien, au revoir.");
							link.l1.go = "exit";
						}
            		}
                }
				else
				{
					dialog.text = "Vous avez décidé de former une caravane ? Vous avez déjà quelqu'un à escorter : terminez d'abord avec lui, puis cherchez-en un autre. Sinon, vous ne saurez pas qui protéger en cas d'attaque.";
					link.l1 = RandPhraseSimple("Voilà le problème... Bon, bonne journée.", "Oui, en effet, je n'y avais pas pensé. Bon, au revoir.");
					link.l1.go = "exit";
        		}
    		}
    		else
    		{
				dialog.text = "Il n'y a personne aujourd'hui. Revenez dans quelques jours.";
				link.l1 = "D'accord. Comme vous voudrez.";
                link.l1.go = "exit";
    		}
		break;

		case "work_2":
			if (!CheckAttribute(npchar, "work_date") || GetNpcQuestPastDayParam(npchar, "work_date") >= 1 || bBettaTestMode)
    		{
				if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 5 || makeint(7-sti(RealShips[sti(Pchar.Ship.Type)].Class)) < 1)//при низком авторитете и на 7 класс не даём
				{
				dialog.text = "Désolé, mais je n'ai personne qui souhaite voyager avec vous.";
				link.l1 = "Compris. Comme vous voudrez.";
                link.l1.go = "exit";
				break;
				}
		         // пассажир
				if (drand(6) > 1)
				{
					dialog.Text = "Ce type qui est entré dans la taverne demandait récemment un navire de passage pour se rendre quelque part. Si vous voulez, parlez-lui.";
					link.l1 = RandPhraseSimple("Quel genre de type ? Ce n'est pas un escroc, ou un homme recherché ?", "Et qui est-ce ? Il n'y aura pas de problèmes avec lui ?");
					Link.l1.go = "PassangerAreYouSure";
				}
				else
				{
					dialog.text = "Non, personne n'a rien demandé aujourd'hui. Un autre jour, peut-être...";
					link.l1 = RandPhraseSimple("Eh bien non, ce n'est pas ça. Qu'est-ce qu'il y a là...", "Oui, pas de chance... Eh bien, au revoir.");
					link.l1.go = "exit";
				}
            }
    		else
    		{
				dialog.text = "Il n'y a personne aujourd'hui. Revenez dans quelques jours.";
				link.l1 = "D'accord. Comme vous voudrez.";
                link.l1.go = "exit";
    		}
        break;

        case "ConvoyAreYouSure":
		    dialog.text = LinkRandPhrase("Qui sait ? Vous avez demandé, j'ai répondu.", "Eh bien, c'est à vous de voir. Je ne me porterais garant de personne ici.", "Décidez par vous-même, toutes sortes de gens viennent chez moi. C'est une taverne, pas la résidence du gouverneur.");
			Link.l1 = "Eh bien, merci, nous allons discuter du prix.";
			Link.l1.go = "exit";
			pchar.quest.destination = findTraderCity(npchar);
			pchar.ConvoyQuest.City = npchar.city;
			AddDialogExitQuest("prepare_for_convoy_quest");
			SaveCurrentNpcQuestDateParam(npchar, "work_date");
        break;

        case "PassangerAreYouSure":
		    dialog.text = LinkRandPhrase("Qui sait ? Vous avez demandé, j'ai répondu.", "Eh bien, c'est à vous de voir. Je ne me porterais garant de personne ici.", "Décidez par vous-même, toutes sortes de gens viennent chez moi. C'est une taverne, pas la résidence du gouverneur.");
			Link.l1 = "D'accord, voyons quel genre de type c'est.";
			Link.l1.go = "exit";
			sGlobalTemp = findPassangerCity(npchar);
			pchar.GenQuest.GetPassenger_City = npchar.city;
			AddDialogExitQuest("prepare_for_passenger_quest");
			SaveCurrentNpcQuestDateParam(npchar, "work_date");
        break;

		// Gregg: --> "Помощь святой инквизиции" (перенос из К:ПС)
		case "HSI_Tavern_1":
			dialog.text = "Ah, vous voulez parler de cet ivrogne qui me doit encore vingt-cinq pièces ?";
			link.l1 = "C'est bien lui. A-t-il dit oם il allait ?";
			link.l1.go = "HSI_Tavern_2";
		break;

		case "HSI_Tavern_2":
			dialog.text = "Il a peut-être dit quelque chose. Et alors ? Qui va me payer ses vingt-cinq pièces, maintenant ?";
			// Gregg: в оригинале деньги списывались ЗДЕСЬ, при показе реплики, а не по выбору.
			// Игрок платил, даже если жал вторую строку. Списание перенесено в узел 3.
			if (sti(pchar.money) >= 25)
			{
				link.l1 = "Très bien. Je paierai pour lui, et vous me direz tout ce que vous savez.";
				link.l1.go = "HSI_Tavern_3";
			}
			else
			{
				link.l1 = "Je n'ai pas ce genre de somme sur moi.";
				link.l1.go = "HSI_Tavern_3";
			}
		break;

		case "HSI_Tavern_3":
			dialog.text = "Bon. Je vais vous le dire, par simple pitié. Un beau jour, cet ivrogne s'est mis à raconter à tout le monde une histoire d'artefact antique des dieux : celui qui le posséderait détiendrait le pouvoir du Seigneur lui-même. C'est là qu'il est allé trop loin. Un malin, quand même : une fois dessoמlé, il a vu qu'il s'était fourré dans de beaux draps jusqu'en haut du mât, et il a filé à bord d'un navire avant que l'Inquisition n'ait vent de l'affaire.";
			if (sti(pchar.money) >= 25)
			{
				AddMoneyToCharacter(pchar, -25);
				dialog.text = "Voilà qui est parler. וcoutez. Un beau jour, cet ivrogne s'est mis à raconter à tout le monde une histoire d'artefact antique des dieux : celui qui le posséderait détiendrait le pouvoir du Seigneur lui-même. C'est là qu'il est allé trop loin. Un malin, quand même : une fois dessoמlé, il a vu qu'il s'était fourré dans de beaux draps jusqu'en haut du mât, et il a filé à bord d'un navire avant que l'Inquisition n'ait vent de l'affaire.";
			}
			link.l1 = "Alors, il a dit oם il allait, oui ou non ?";
			link.l1.go = "HSI_Tavern_4";
		break;

		case "HSI_Tavern_4":
			dialog.text = "Laissez-moi réfléchir... Ah oui, il a parlé une ou deux fois de Basse-Terre, en Guadeloupe.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionFirstToBasTer");
		break;

		case "HSI_Tavern_5":
			dialog.text = "Il y avait bien un homme comme ça. Il me louait une chambre à l'étage, et ses affaires y sont encore, je crois. Mais vous ne rattraperez pas l'homme lui-même : il a pris la mer il y a une semaine.";
			link.l1 = "Pris la mer ? Pour aller oם ?";
			link.l1.go = "HSI_Tavern_6";
		break;

		case "HSI_Tavern_6":
			dialog.text = "דa, je ne sais pas.";
			link.l1 = "Bon. Bonne journée à vous.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionToRichHouse");
		break;

		case "HSI_Tavern_7":
			dialog.text = "Non... Attendez, si, je me souviens. Il y en avait un qui portait ce nom. Mais il est parti quelque part il n'y a pas longtemps.";
			link.l1 = "Oם ça ?";
			link.l1.go = "HSI_Tavern_8";
		break;

		case "HSI_Tavern_8":
			dialog.text = "Oh, vous savez, je ne suis pas là pour me souvenir de chaque détail inutile.";
			if (sti(pchar.money) >= 500)
			{
				link.l1 = "Et si je vous donnais cinq cents pesos, le détail deviendrait-il utile et vous rafraîchirait-il la mémoire ?";
				link.l1.go = "HSI_Tavern_9";
			}
			else
			{
				link.l1 = "Hum...";
				link.l1.go = "exit";
			}
		break;

		case "HSI_Tavern_9":
			AddMoneyToCharacter(pchar, -500);
			dialog.text = "Voilà, c'est mieux. Il me semble qu'il a parlé des portes de la ville. Il est sorti des murs, à ce qu'il paraît.";
			link.l1 = "Il est parti seul ?";
			link.l1.go = "HSI_Tavern_10";
		break;

		case "HSI_Tavern_10":
			dialog.text = "Seul. Pourquoi ?";
			link.l1 = "Simple curiosité, rien de plus.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionToBasTerExitTown");
		break;

		case "HSI_Tavern_11":
			dialog.text = "Bien sמr. Elle habite tout près, mais à cette heure-ci, elle fait sמrement la tournée des marchands ambulants.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("HelpSacredInquisitionFindJacklin");
		break;
		// Gregg: <-- "Помощь святой инквизиции"

		// Gregg: --> "Товар для Ричарда Тилльманна"
		case "UD_Tavern_1":
			dialog.text = "Tillman, vous dites ? Sa maison est près de la porte qui mène à la plantation, vous ne pouvez pas manquer la porte. Il n'en sort jamais, vous le trouverez donc chez lui.";
			link.l1 = "Près de la plantation. Merci.";
			link.l1.go = "exit";
		break;
		// Gregg: <-- "Товар для Ричарда Тилльманна"

		// Gregg: --> "Легенда о призрачном свете" (перенос из К:ПС)
		case "MoonLightStone_1":
			dialog.text = "Mais il est assis juste ici, dans la taverne.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			pchar.MoonStone = "3";
		break;

		case "MoonLightStone_2":
			dialog.text = "Peut-être. דa m'est sorti de la tête, je ne sais comment.";
			link.l1 = "Cinq cents pièces d'or vous la rafraîchiraient peut-être ?";
			link.l1.go = "MoonLightStone_3";
		break;

		case "MoonLightStone_3":
			dialog.text = "Non... ça ne me revient toujours pas.";
			// Gregg: в оригинале тысяча списывалась ЗДЕСЬ, при показе реплики, а не по
			// выбору - игрок платил, даже уходя во вторую строку. Списание в узле 4.
			if (sti(pchar.money) >= 1000)
			{
				link.l1 = "Et mille ?";
				link.l1.go = "MoonLightStone_4";
			}
			else
			{
				link.l1 = "Si vous ne me dites pas tout de suite ce qu'il me faut, vous allez amèrement le regretter.";
				link.l1.go = "MoonLightStone_4";
			}
		break;

		case "MoonLightStone_4":
			if (sti(pchar.money) >= 1000) AddMoneyToCharacter(pchar, -1000);
			dialog.text = "Hum... דa me revient ! Comment ai-je pu oublier : il loge ici même, à l'étage.";
			link.l1 = "Voilà qui est mieux.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneToNevisTavernRoom");
		break;

		case "MoonLightStone_5":
			dialog.text = "Il m'a dit que vous viendriez. Il vous attend hors de la ville.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MoonStoneToFortFranceExit");
		break;
		// Gregg: <-- "Легенда о призрачном свете"

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		// LEO: payment for a brawl in the common room (Tavern_BrawlBarmanCome). The captain's purse
		//      picks the branch - there is no "pay or not": if he has the money it is taken. -->
		case "BrawlFine_pay":
			NextDiag.TempNode = "First time";
			AddMoneyToCharacter(Pchar, -TAVERNBRAWL_FINE);
			dialog.text = "Capitaine, votre homme vient de mettre ma salle sens dessus dessous. Je n'ai pas de videurs et je n'appellerai pas la garde, mais la casse doit être payée : je vous prends " + TAVERNBRAWL_FINE + " pesos, et nous nous quittons bons amis.";
			link.l1 = LinkRandPhrase("C'est juste. Mes hommes, ma facture.", "Tenez. Et servez-lui un verre ensuite, de ma part.", "Moins cher que je ne pensais.");
			link.l1.go = "exit";
		break;

		case "BrawlFine_no":
			NextDiag.TempNode = "First time";
			AddDialogExitQuestFunction("Tavern_BrawlKickOut");
			dialog.text = "Capitaine, votre homme vient de mettre ma salle sens dessus dessous. La casse coמte " + TAVERNBRAWL_FINE + " pesos, et vos poches n'en contiennent pas autant. Alors dehors, et emmenez vos hommes avec vous.";
			link.l1 = RandPhraseSimple("...", "Nous reviendrons.");
			link.l1.go = "exit";
		break;
		// LEO: payment for a brawl in the common room <--

		case "room":
			if (CheckAttribute(PChar, "questTemp.BSPrologue.WaitingForNassauSiege") && pchar.location == "Pirates_Tavern")
			{
				dialog.text = "Je suis désolé, capitaine, mais toutes les places sont prises en ce moment.";
				link.l1 = "Dommage...";
				link.l1.go = "exit";
				break;
			}
			//Квест Виспер
			if (CheckAttribute(pchar, "Whisper.EsFriendTown") && pchar.location == pchar.Whisper.EsFriendTown+"_tavern")
			{
				dialog.text = "Désolé, capitaine, mais toutes les places sont occupées en ce moment.";
				link.l1 = "Désolé...";
				link.l1.go = "exit";
				break;
			}
			//Квест Виспер

			if (CheckAttribute(pchar, "ContraInterruptWaiting"))
			{
				dialog.text = "Je suis désolé, mais je ne peux pas louer de chambre en ce moment. Il y a quelques minutes, une troupe de soldats a fait irruption dans la taverne et s'est mise à fouiller mes chambres. Ils cherchent des contrebandiers, vous comprenez. Seulement, avec leurs règlements de comptes, ils me gâchent les affaires... Revenez plus tard, capitaine.";
				if (sti(npchar.nation == PIRATE))
				{
					dialog.text = "Je suis désolé, mais je ne peux pas louer de chambre en ce moment. Le dernier locataire a décidé d'y installer un bordel, ou pire. Le lit est cassé, et ça sent la porcherie... Revenez plus tard, capitaine.";
				}
				link.l1 = "Je vois.";
				link.l1.go = "exit";
				break;
			}

   			/*if (chrDisableReloadToLocation || CheckAttribute(pchar, "questTemp.different.Church_NightGuard")) //кто-то должен подойти к ГГ.
			{
				dialog.text = "The room is occupied now, " + GetAddress_Form(NPChar) + "I can't help you.";
				link.l1 = "Sorry, very sorry...";
				link.l1.go = "exit";
				break;
			}*/
			if (CheckAttribute(pchar, "questTemp.State.Open") && npchar.id == "Tortuga_tavernkeeper")//исп.линейка, квест №6, блокировка спать в комнате
			{
				dialog.text = "Vous m'avez payé une semaine d'avance, je ne peux pas vous prendre plus d'argent. La chambre est à vous, allez vous reposer...";
				link.l1 = "D'accord, l'ami, merci.";
				link.l1.go = "exit";
				break;
			}
			//-->> квест официантки
			if (pchar.questTemp.different == "FackWaitress_toRoom")
			{
				dialog.text = "Vous voulez louer une chambre ? Pas de problème. Ce sera 100 pièces, et vous pourrez y aller.";
				if (sti(pchar.money) >= 100)
				{
					link.l1 = "Prends ton argent et ouvre la chambre, l'ami...";
					link.l1.go = "exit";
					AddMoneyToCharacter(pchar, -100);
					LocatorReloadEnterDisable(npchar.city + "_tavern", "reload2_back", false);
					pchar.questTemp.different = "FackWaitress_toRoomUp";
				}
				else
				{
					link.l1 = "Hum, je crois que je reviendrai plus tard...";
					link.l1.go = "exit";
				}
				break;
			}
			if (pchar.questTemp.different == "FackWaitress_toRoomUp")//квест официантки
			{
				dialog.text = "La chambre est à vous, allez vous reposer...";
				link.l1 = "D'accord, l'ami, merci.";
				link.l1.go = "exit";
				break;
			}
			//<<-- квест официантки
			// --> квест "The Girl in the Jungle"
			if(CheckAttribute(pchar, "GenQuest.EncGirl.city") && npchar.city == pchar.GenQuest.EncGirl.city)
			{
				if(pchar.GenQuest.EncGirl == "EncGirl_ToTavern")
				{
					dialog.text = "Vous voulez louer une chambre ? Pas de problème. Ce sera 50 pièces, et vous pourrez y aller.";
					if (sti(pchar.money) >= 50)
					{
						link.l1 = "Prends ton argent et ouvre la chambre, l'ami...";
						link.l1.go = "exit";
						AddMoneyToCharacter(pchar, -50);
						LocatorReloadEnterDisable(npchar.city + "_tavern", "reload2_back", false);
						pchar.GenQuest.EncGirl = "EncGirl_toRoomUp";
					}
					else
					{
						link.l1 = "Hum, je crois que je reviendrai plus tard...";
						link.l1.go = "exit";
					}
					break;
				}
				if (pchar.GenQuest.EncGirl == "EncGirl_toRoomUp")//квест  по спасению тётки в пампасах
				{
					dialog.text = "La chambre est à vous, allez vous reposer...";
					link.l1 = "D'accord, l'ami, merci.";
					link.l1.go = "exit";
					break;
				}
			}
			// <-- квест "The Girl in the Jungle"
			dialog.text = "Combien de temps comptez-vous rester ?";
			if(!isDay())
			{
				link.l1 = "Jusqu'au matin.";
				link.l1.go = "room_day";
			}
			else
			{
				link.l1 = "Jusqu'à la nuit.";
				link.l1.go = "room_night";
				link.l2 = "Jusqu'au lendemain matin.";
				link.l2.go = "room_day_next";
			}
		break;

		case "room_day":
			dialog.text = "Ce sera 5 pièces d'or.";
			if (makeint(pchar.money) >= 5)
			{
				link.l1 = "Marché conclu. Voici votre argent.";
				link.l1.go = "room_day_wait";
			}
			link.l2 = pcharrepphrase("Vous louez les appartements royaux ? Non, à ce prix-là, je préfère rester dans la salle commune.",
            "Hélas, apparemment, un luxe tel que dormir dans un lit n'est pas pour ma bourse. Je passerai la nuit dans la salle commune.");
			link.l2.go = "hall_day_wait";
			link.l3 = "Pas maintenant. Parlons d'autre chose.";
			link.l3.go = "int_quests";
		break;

		case "room_day_next":
			dialog.text = "Ce sera 10 pièces d'or.";
			if (makeint(pchar.money) >= 10)
			{
				link.l1 = "Marché conclu. Voici votre argent.";
				link.l1.go = "room_day_wait_next";
			}
			link.l2 = pcharrepphrase("Vous louez les appartements royaux ? Non, à ce prix-là, je préfère rester dans la salle commune.",
            "Hélas, apparemment, un luxe tel que dormir dans un lit n'est pas pour ma bourse. Je passerai la nuit dans la salle commune.");
			link.l2.go = "hall_day_wait";
			link.l3 = "Pas maintenant. Parlons d'autre chose.";
			link.l3.go = "int_quests";
		break;

		case "room_night":
			dialog.text = "Ce sera 5 pièces d'or.";
			if (makeint(pchar.money) >= 5)
			{
				link.l1 = "Marché conclu. Voici votre argent.";
				link.l1.go = "room_night_wait";
			}
			link.l2 = pcharrepphrase("Vous louez les appartements royaux ? Non, à ce prix-là, je préfère rester dans la salle commune.",
            "Hélas, apparemment, un luxe tel que dormir dans un lit n'est pas pour ma bourse. Je passerai la nuit dans la salle commune.");
			link.l2.go = "hall_night_wait";
			link.l3 = "Pas maintenant. Parlons d'autre chose.";
			link.l3.go = "int_quests";
		break;

		case "room_night_wait":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddMoneyToCharacter(pchar, -5);
			AddDialogExitQuest("sleep_in_tavern");
			TavernWaitDate("wait_night");
		break;

		case "hall_night_wait":
			if (cRand(3) == 1)
            {
                Dialog.text = "Dehors, espèce de salaud ! On ne reste pas assis gratis dans la salle commune.";
				link.l1 = "D'accord, d'accord... Je m'en vais déjà.";
				link.l1.go = "exit";
            }
            else
            {
				DialogExit();
				NextDiag.CurrentNode = NextDiag.TempNode;
				TavernWaitDate("wait_night");
			}
		break;

		case "room_day_wait":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddMoneyToCharacter(pchar, -5);
			AddDialogExitQuest("sleep_in_tavern");
			TavernWaitDate("wait_day");
		break;

		case "room_day_wait_next":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddMoneyToCharacter(pchar, -10);
			AddDialogExitQuest("sleep_in_tavern");
			TavernWaitDate("wait_day");
		break;

		case "hall_day_wait":
			if (drand(1) == 1)
            {
                Dialog.text = "Dehors, espèce de salaud ! On ne reste pas assis gratis dans la salle commune.";
				link.l1 = "D'accord, d'accord... Je m'en vais déjà.";
				link.l1.go = "exit";
            }
            else
            {
				DialogExit();
				NextDiag.CurrentNode = NextDiag.TempNode;
				TavernWaitDate("wait_day");
			}
		break;

		case "tavern_keeper":
			NextDiag.TempNode = "First time";

			dialog.text = "Mes chers, je vous prie de cesser ce chahut dans ma taverne, sinon j'appelle la garde !";
			link.l1 = "D'accord, d'accord, je m'en vais déjà.";
			link.l1.go = "exit_sit";
		break;

		case "exit_sit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("exit_sit");
		break;
		//==> eddy. квест мэра, вопросы не замечал ли шпиона
		case "SeekSpy_Seen":
			dialog.text = NPCStringReactionRepeat("Hum, laissez-moi réfléchir... Vous savez, il y a un type qui ne m'inspire pas confiance, personnellement. Il a l'air d'un citoyen ordinaire, mais il traîne par ici et en ville, et il pose des questions bizarres. Il ne viendra sans doute pas ici, je l'ai éconduit hier, mais cherchez en ville.",
				"Nous avons déjà parlé de ce sujet, je n'ai rien de plus à vous dire.", "Encore la même chose... Je vous ai déjà tout dit.", "Combien de fois faut-il me poser la même question ?!", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, l'ami. Bon, je vais aller chercher ce type.", "Hum, eh bien, désolé...",
                      "Hum, oui...", "Désolé, l'ami...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;
		case "SeekSpy_NotSeen":
			dialog.text = NPCStringReactionRepeat("Non, je n'ai vu personne qui m'ait paru suspect.",
				"Nous avons déjà parlé de ce sujet, je n'ai rien de plus à vous dire.", "Encore la même chose... Je vous ai déjà tout dit.", "Combien de fois faut-il me poser la même question ?!", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Eh bien, merci quand même, l'ami.", "Hum, désolé...",
                      "Hum, oui...", "Désolé, l'ami...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
		break;

		//==> homo линейка Блада
		case "TStep_0":
			dialog.text = "Tout droit, jusqu'au bout. Je ne vous ai rien dit.";
			link.l1 = "Merci.";
			link.l1.go = "Exit";
			int n= FindLocation("Bridgetown_tavern");
            locations[n].reload.l2.disable = false;
		break;

		case "TStep_1":
			dialog.text = "Qu'est-ce qui vous amène chez moi, cher docteur ?";
			link.l1 = "Une affaire de la vie courante... J'aurais bien besoin de quelques coutelas et d'une paire de pistolets, au cas oם, cher ami. Pouvez-vous arranger ça, ou m'indiquer quelqu'un qui pourrait s'en charger ? Vous comprenez, inutile pour moi d'aller au magasin...";
			link.l1.go = "TStep_2";
		break;

		case "TStep_2":
			dialog.text = "Eh bien, bien sמr que non.";
			link.l1 = "Vous ne pouvez pas ? Ou cela n'a pas de sens ?";
			link.l1.go = "TStep_3";
            if (makeint(pchar.money) >= 500)
            {
    			link.l1 = "Ne vous ai-je pas dit que j'avais une prime pour une personne bien informée, d'un montant de... disons, trois cents piastres ? Et souvenez-vous de la façon dont j'ai soigné votre fille, sans ménager ni ma peine ni mon temps.";
    			link.l1.go = "TStep_4";
            }
		break;

		case "TStep_3":
			dialog.text = "Je ne peux pas vous aider, docteur.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
		break;

		case "TStep_4":
			dialog.text = "Bien sמr que j'ai ce qu'il vous faut, docteur Blood. M. Griffin, à qui vous avez réduit une fracture il n'y a pas longtemps, est un vieil armurier de métier. Sa maison se trouve près du domaine du gouverneur Steed : allez le voir. Je suis sמr qu'il ne vous refusera rien.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -300);
			Pchar.questTemp.CapBloodLine.stat = "PrepareToEscape1";
			AddQuestRecord("WeaponsForEscape", "2");

		break;

		case "TStep_5":
            pchar.questTemp.CapBloodLine.QuestRaff = false;
			dialog.text = "Je crois que je me souviens de celui-là... Ou ce n'était pas lui... דa n'a pas l'air d'être lui...";
            if (makeint(pchar.money) >= 200)
            {
    			link.l1 = "Deux cents piastres vous rafraîchiraient-elles la mémoire ?";
    			link.l1.go = "TStep_6";
            }
			link.l2 = "C'est lui, oui ou non ?";
			link.l2.go = "TStep_7";
		break;

		case "TStep_6":
            AddMoneyToCharacter(pchar, -200);
			dialog.text = "Bien sמr ! Bien sמr que c'est lui ! Il est passé tout récemment, il a parlé d'acheter un navire... Je ne sais pas exactement lequel ni à qui.";
			link.l1 = "Et que savez-vous d'autre ? Il me semble que pour 200 piastres, vous pouvez vous souvenir de bien plus de détails que du simple fait qu'il est passé ici.";
			link.l1.go = "TStep_8";
		break;

		case "TStep_7":
			dialog.text = "Non, hélas... Ce n'est certainement pas lui. Je me suis trompé, ça arrive.";
			link.l1 = "Agaçant...";
			link.l1.go = "TStep_10";
		break;

		case "TStep_8":
			dialog.text = "Je pense que vous le trouverez au chantier naval, si vous vous dépêchez.";
			link.l1 = "Merci beaucoup.";
			link.l1.go = "TStep_9";
		break;

		case "TStep_9":
            AddQuestRecord("UsurerQuest", "2");
            sld = GetCharacter(NPC_GenerateCharacter("QStranger", "citiz_7", "man", "man", 10, ENGLAND, 1, false));
            sld.dialog.filename = "Quest\CapBloodLine\questNPC.c";
			sld.greeting = "Gr_bankeer";
            sld.name = "Alex";       //fix имени
            sld.lastname = "Winner";
            sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(sld, sTemp);
            LAi_SetStayTypeNoGroup(sld);
            ChangeCharacterAddressGroup(sld, "Bridgetown_Shipyard", "goto", "goto1");
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "TStep_10":
            sld = GetCharacter(NPC_GenerateCharacter("QStranger", "citiz_7", "man", "man", 10, ENGLAND, 1, false));
            sld.dialog.filename = "Quest\CapBloodLine\questNPC.c";
			sld.greeting = "Gr_bankeer";
            sld.name = "Alex";    //fix имени
            sld.lastname = "Winner";
            sTemp = GetNationNameByType(ENGLAND) + "_citizens";
            LAi_group_MoveCharacter(sld, sTemp);
            LAi_SetStayTypeNoGroup(sld);
            ChangeCharacterAddressGroup(sld, "CommonRoom_MH7", "goto", "goto1");
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;
		//==> Sinistra пролог Анжелики Тич
		case "AT_pr_1":
			dialog.text = "Vous savez, si mes clients se mettent à se battre ici par votre faute, je serai obligé de déposer une réclamation pour les dégâts à votre nom.";
			link.l1 = "Señor " + npchar.name+", vous savez comme personne prononcer le mot « dehors » avec autant de discrétion et de tact.";
			link.l1.go = "AT_pr_2";
		break;
		case "AT_pr_2":
			dialog.text = "Pas du tout, je suis content d'avoir n'importe quel client.";
			link.l1 = "Bien sמr, bien sמr.";
			link.l1.go = "exit";
			NextDiag.TempNode = "AT_pr_3";
		break;
		case "AT_pr_3":
			dialog.text = "Je vous sers quelque chose ?";
			link.l1 = "Non, rien.";
			link.l1.go = "exit";
			NextDiag.TempNode = "AT_pr_3";
		break;
		//зачарованный город
		case "MCTavern":
			dialog.text = "Non, non ! C'est en haut, le client ; on dit que c'est vraiment un loup-garou, vous qui êtes "+ GetSexPhrase("un homme courageux", "une fille courageuse") +" ! Je vous en prie, faites quelque chose ! Si ces gens de la rue font irruption ici... J'ai peur d'imaginer ce qui va se passer !";
			link.l1 = "Je ne sais pas qui a le plus peur, de vous ou de ceux qui sont derrière la porte. Bon, je vais parler à votre client.";
			link.l1.go = "exit";
			LAi_group_Delete("EnemyFight");
			pchar.questTemp.MC = "toCaracasWervolf";
			DeleteAttribute(&locations[reload_location_index], "reload.l2.disable");
			sld = GetCharacter(NPC_GenerateCharacter("CaracasWervolf", "trader_14", "man", "man", 10, PIRATE, -1, true));
			sld.dialog.filename = "Quest\MagicCity.c";
			sld.dialog.currentnode = "CaracasWervolf";
			sld.location	= "Caracas_tavern_upstairs";
			sld.location.group = "goto";
			sld.location.locator = "goto1";
			sld.BreakTmplAndFight = true;
			sld.reactionOnFightModeOn = true;
			LAi_SetActorType(sld);
			LAi_ActorWaitDialog(sld, pchar);
			LAi_group_MoveCharacter(sld, "EnemyFight");
		break;

		case "MCCaracasAfter":
			dialog.text = "Dieu merci, j'en suis débarrassé ! J'ai dמ ouvrir la porte, parce que la plupart des gens de cette foule étaient mes clients ! Deux ou trois bouteilles de rhum cassées, c'est un petit prix à payer...";
			link.l1 = "Je vous demande ce qu'il est advenu du client.";
			link.l1.go = "MCCaracasAfter_1";
		break;
		case "MCCaracasAfter_1":
			dialog.text = "Oh, du loup-garou ? On l'a envoyé au bמcher, bien sמr. Vous n'avez pas vu la fumée qui monte du cכté de l'église ? Voilà comment il brמle, ce loup-garou...";
			link.l1 = "Eh bien, vous êtes rapides, vous autres, je vois ça.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MC_endCaracas");
		break;

		//*************************** Квест "Orion fluyt accompaniment"Орион"" **********************
		case "Andre_Abel_Quest_TavernOwner_Dialog_1":
			dialog.text = "Ah, capitaine " + GetFullName(pchar) + " ! Andre Abel a été tué il y a deux jours. Les assassins l'attendaient juste à l'entrée de la taverne... Oh, quel dommage ! Quel homme agréable c'était : généreux, courtois, il n'élevait jamais la voix, ne se battait jamais. Et voilà, une mort pareille ! Aïe aïe aïe...";
			link.l1 = "Eh bien !.. Je ne m'attendais pas à un tel retournement. Je plains sincèrement ce pauvre gars, sincèrement...";
			link.l1.go = "Andre_Abel_Quest_TavernOwner_Dialog_2";
		break;

		case "Andre_Abel_Quest_TavernOwner_Dialog_2":
			DialogExit();
			AddQuestRecord("Andre_Abel_Quest", "13");
			AddQuestUserData("Andre_Abel_Quest", "sSex", GetSexPhrase("", "e"));
			CloseQuestheader("Andre_Abel_Quest");
			pchar.questdata.FleitOrion = 1;
			DeleteAttribute(pchar, "QuestTemp.AndreAbelQuest");
			DeleteAttribute(PChar, "QuestTemp.Andre_Abel_Quest_PortPax_TavernOwner_Speek");
			pchar.questdata.FleitOrion = 1;
		break;

		//******************* ноды квеста священника. поиск грабителей (квест № 2)**********************
		case "Tavern_GenQuest_Church_2_1":
			dialog.text = "Je n'en sais pas grand-chose... Vous feriez mieux de demander à l'un des habitués.";
			link.l1 = "D'accord, merci.";
			link.l1.go = "exit";
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen");
		break;

		//******************* ноды квеста священника. вернуть рукописи (квест № 1)**********************
		case "Tavern_ChurchGenQuest1_Node_1":
			dialog.text = "Nous ne servons pas à crédit, "+ GetSexPhrase("monsieur", "mademoiselle") +".";
			link.l1 = "J'ai l'habitude de payer en espèces sonnantes, mon cher. Ou bien l'or n'est plus accepté ici ?";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_2";
		break;

		case "Tavern_ChurchGenQuest1_Node_2":
			dialog.text = "Pardonnez-moi,"+ GetSexPhrase("monsieur", "madame") +" le capitaine, mais votre ami a des dettes, et je pensais...";
			link.l1 = "Pensez moins, mon cher, et servez plus vite. Alors, combien mon vaillant ami vous doit-il ?";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_3";
		break;

		case "Tavern_ChurchGenQuest1_Node_3":
			iTemp = (rand(3)+1)*10;
			PChar.GenQuest.ChurchQuest_1.MoneyToBarmen = iTemp;
			if(rand(1) == 0) // "If it's simple and gives it away right away"
			{
				dialog.text = FindRussianMoneyString(iTemp) + ", "+ GetSexPhrase("monsieur", "mademoiselle") +"Capitaine, il a laissé en gage des livres d'église : c'est tout ce qu'il avait de valeur sur lui.";
				if(sti(PChar.money) >= iTemp)
				{
					link.l1 = "Prenez ces pièces et donnez-moi les manuscrits. Attention, ce n'est pas un tonneau de bière, mais les écrits des justes de Dieu !";
					link.l1.go = "Tavern_ChurchGenQuest1_Node_4_1";
				}
				else
				{
					link.l1 = "Attendez un peu... Je vais vous apporter cet argent.";
					link.l1.go = "exit";
					PChar.GenQuest.ChurchQuest_1.NoMoneyToBarmen = true;
				}
			}
			else // "If it's not simple"
			{
				dialog.text = FindRussianMoneyString(iTemp) + ", "+ GetSexPhrase("monsieur", "mademoiselle") +" capitaine.";
				link.l1 = "Je vais payer sa dette et reprendre ce qu'il a laissé en gage.";
				link.l1.go = "Tavern_ChurchGenQuest1_Node_4_2";
			}
		break;

		case "Tavern_ChurchGenQuest1_Node_4_1":
			DialogExit();
			AddMoneyToCharacter(PChar, -sti(PChar.GenQuest.ChurchQuest_1.MoneyToBarmen));
			AddItems(PChar, "Bible", 1);	// Даём рукописи
			items[FindItem("Bible")].Name = "itmname_ChurchGenQuest1Bible";	// Меняем имя. Потом поменять обратно!
			ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest1Bible"); // Меняем дескрайб. Потом поменять обратно!
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"); // Переменная. Потом удалить!
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithBarmen");
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "8");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"));
			AddQuestUserData(sQuestTitle, "sName", GetFullName(CharacterFromID("ChurchGenQuest1_Cap")));
			PChar.GenQuest.ChurchQuest_1.Complete = true; // Квест выполнен
			SetFunctionTimerCondition("Church_GenQuest1_DeleteCapitan", 0, 0, 2, false);
		break;

		case "Tavern_ChurchGenQuest1_Node_4_2":
			dialog.text = "Non, "+ GetSexPhrase("monsieur", "mademoiselle") +", ça ne marchera pas.";
			link.l1 = "Comment ça, « ça ne marchera pas » ?! La dette du capitaine est réglée : il est content. Vous recevez votre argent : vous êtes content. On me rend le gage : je suis satisfait. Tout le monde est content, et tout va bien. Pourquoi est-ce que ça ne « marcherait » pas ?";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_4_2_1";
		break;

		case "Tavern_ChurchGenQuest1_Node_4_2_1":
			dialog.text = "Parce que je n'ai pas besoin d'argent. Je connais trop bien votre capitaine, et je n'espérais même pas qu'il puisse un jour payer sa dette et réclamer ces manuscrits.";
			link.l1 = "Comment ça, vous n'avez pas besoin d'argent ? Vous vouliez donc garder les livres ? Mais pourquoi, au nom de Dieu ?!";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_4_2_2";
		break;

		case "Tavern_ChurchGenQuest1_Node_4_2_2":
			dialog.text = "Justement au nom du Seigneur, "+ GetSexPhrase("monsieur", "mademoiselle") +". Mon petit garçon était très malade, et ma femme et moi avons fait le vœu de faire un don à l'église si le Créateur délivrait l'enfant de la fièvre. La miséricorde de Dieu est infinie, l'enfant est vivant et en bonne santé, et maintenant nous devons accomplir notre vœu. Et voilà que, juste à point, arrive le capitaine " + PChar.GenQuest.ChurchQuest_1.CapFullName + " et qu'il laisse en gage des livres d'église. Je ne pouvais pas tolérer une telle indécence, payer sa boisson avec la Parole de Dieu, et j'ai décidé aujourd'hui de faire don de ces livres au curé de notre paroisse.";
			link.l1 = "C'est sans aucun doute une bonne action, mais sachez que ces manuscrits appartiennent à un autre prêtre, ou plutכt, pas à un prêtre, mais à un puissant évêque, mon guide spirituel, qui sera très en colère, et maudira peut-être quiconque y touchera... J'aimerais vous les racheter et les lui remettre sains et saufs.";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_4_2_3";
		break;

		case "Tavern_ChurchGenQuest1_Node_4_2_3":
			dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +" capitaine... Bien sמr, je vous les donne, et je n'ai besoin d'aucun argent. Dites seulement un mot en notre faveur à l'évêque, qu'il nous bénisse et prenne en compte l'accomplissement de notre vœu...";
			link.l1 = "Bien sמr, mon cher, le vœu vous sera compté, à vous et à votre femme, car, après tout, vous avez sacrifié l'argent en rendant les manuscrits à qui ils appartiennent, et peu importe dans quelle église nous allons, nous sommes tous sous le même Dieu. Donnez-les-moi, et bonne chance à vous...";
			link.l1.go = "Tavern_ChurchGenQuest1_Node_4_2_4";
		break;

		case "Tavern_ChurchGenQuest1_Node_4_2_4":
			DialogExit();
			AddItems(PChar, "Bible", 1);	// Даём рукописи
			items[FindItem("Bible")].Name = "itmname_ChurchGenQuest1Bible";	// Меняем имя. Потом поменять обратно!
			ChangeItemDescribe("Bible", "itmdescr_ChurchGenQuest1Bible"); // Меняем дескрайб. Потом поменять обратно!
			items[FindItem("Bible")].City = XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Gen"); // Переменная. Потом удалить!
			AddMoneyToCharacter(PChar, -sti(PChar.GenQuest.ChurchQuest_1.MoneyToBarmen));
			DeleteAttribute(PChar, "GenQuest.ChurchQuest_1.NeedToDialogWithBarmen");
			sQuestTitle = PChar.GenQuest.ChurchQuest_1.QuestTown + "ChurchGenQuest1";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest1", "9");
			AddQuestUserData(sQuestTitle, "sColony", XI_ConvertString("Colony" + PChar.GenQuest.ChurchQuest_1.QuestTown + "Acc"));
			PChar.GenQuest.ChurchQuest_1.Complete = true; // Квест выполнен
			SetFunctionTimerCondition("Church_GenQuest1_DeleteCapitan", 0, 0, 2, false);
		break;

		case "Pirates_1":
			dialog.text = "Partout, vous autres gentilshommes"+ GetSexPhrase("", " et dames") +" de fortune, vous voyez des Espagnols ! Les riches prises vous ont complètement tourné la tête... Pas La Résine, mais Lucky Rosin, ou bien le Violoneux chanceux, si vous préférez. Vous en avez peut-être entendu parler ? En fait, je m'appelle Waynard d'Alto... Mais ça ne vous dira sans doute rien. De nos jours, peu de gens s'intéressent à l'histoire, hé hé. Bon, passons.";
			link.l1 = "Attendez... Il me semble que je me souviens. Vous êtes ce corsaire qui s'est brouillé avec la couronne de France et qui a disparu il y a quelques années ! Par le diable et sa fourche ! Quelle rencontre ! Et j'ai entendu dire que le Violoneux s'amuse parfois à pincer les Espagnols et les Français, en souvenir du bon vieux temps !";
			link.l1.go = "Pirates_2";
		break;
		case "Pirates_2":
			dialog.text = "Doucement dans les virements de bord, "+ GetSexPhrase("monsieur", "mademoiselle") +". Ceux qui jacassent trop attirent le mauvais vent. Si vous voyez ce que je veux dire.";
			link.l1 = "Oui, vous avez peut-être raison. Laissons là les bavardages et passons aux affaires.";
			link.l1.go = "meeting";
		break;

		case "Charles_1":
			dialog.text = "Eh bien, vous avez raison de ne pas y croire. Les gens mentent... Bon, un jour, une caravane espagnole s'est présentée, dispersée par une tempête, et j'ai dמ l'escorter jusqu'à la Jamaïque. Ce n'était pas vraiment La Havane, hé hé hé...";
			link.l1 = "Oh, il y a quelque chose que vous ne me dites pas... Bon, je ne vais pas insister. Passons aux affaires.";
			link.l1.go = "meeting";
		break;

		case "Portobello_1":
			dialog.text = "Oui, oui, oui, c'est bien comme ça que ça s'est passé, " + GetAddress_Form(NPChar) + " ! Les gens disent la vérité. Tout l'archipel connaît les exploits du Renard catalan !";
			link.l1 = "Et j'ai aussi entendu dire que vous étiez à couteaux tirés avec Morgan. Et que vous avez passé un mois dans la prison de Port Royal. Et que vous vous êtes échappé des cachots en vous faisant passer pour Lady Taylor...";
			link.l1.go = "Portobello_2";
		break;

		case "Portobello_2":
			dialog.text = "Chut... N'en parlez pas si fort, "+ GetSexPhrase("l'ami", "ma petite") +". Tout ça, ce sont des ragots... des racontars. Bah, Morgan ne m'attrapera jamais ici, hé hé.";
			link.l1 = "D'accord, " + npchar.name + ", on a bavardé, maintenant passons aux affaires.";
			link.l1.go = "meeting";
		break;
		
		case "FortFrance_1":
			dialog.text = "Hé hé hé ! Des informations, dites-vous ? Vous êtes à la bonne adresse, capitaine. J'ai entendu dire qu'une marchande, la Virginie Audric, s'était échouée sur des récifs, quelque part entre notre bienheureuse Martinique et la Guadeloupe. Personne n'a jamais entendu parler de récifs à cet endroit, alors je pense que ce récif-là avait au moins 12 canons ! Hé hé hé ! Alors, vous ne voulez pas une chope de rhum pour vous calmer les nerfs ? Hé hé hé !";
			link.l1 = "Terriblement drכle, " + npchar.name+". Exprimez-vous plus clairement, sinon vous allez finir par vous rendre malade à force de rire.";
			link.l1.go = "FortFrance_2";
		break;
		
		case "FortFrance_2":
			dialog.text = "Plus clairement ? Hé hé. Bon, à tous points de vue, il est temps d'être un peu sérieux.";
			link.l1 = "Vous plaisantez. VOUS ? SוRIEUX ? Bien sמr, c'est impossible. א quoi est-ce que je pensais ?";
			link.l1.go = "FortFrance_3";
		break;
		
		case "FortFrance_3":
			dialog.text = "Oh, "+ GetSexPhrase("l'ami", "ma chérie") +". Je suis tout à fait sérieux. Hé hé hé hé. Vraiment.";
			link.l1 = "D'accord, " + npchar.name+". On a ri, maintenant venons-en au fait.";
			link.l1.go = "meeting";
		break;
		
		case "Nassau_1":
			dialog.text = "Ha, les jeunots qui n'ont pas encore vraiment flairé la vie ! Bon, excite-toi, excite-toi, joue les "+ GetSexPhrase("loup de mer", "louve de mer") +", mais attention à ne pas tomber sur quelqu'un de vraiment coriace !";
			link.l1 = "Euh... J'ai bien compris ? Vous vous appelez " + npchar.name+" ?";
			link.l1.go = "Nassau_2";
		break;
		
		case "Nassau_2":
			dialog.text = "Oui, c'est mon nom depuis la minute oם j'ai poussé mon premier cri pour annoncer ma naissance, dans une sale bicoque des faubourgs de Lisbonne.";
			link.l1 = "Eh bien, moi, je m'appelle " + GetFullName(pchar)+".";
			link.l1.go = "meeting";
		break;
		
		//Инес Диас рассказывает историю о себе
		case "Istoria_InesDias_1":
			pchar.questTemp.Istoria_InesDias = "Istoria_InesDias";
			dialog.text = "Oh mon Dieu ! J'ai déjà raconté cette histoire cent fois !";
			link.l1 = "Je comprends que vous en ayez terriblement assez de raconter votre vie à tout le monde, mais peut-être ferez-vous une exception pour moi ?";
			link.l1.go = "Istoria_InesDias_2";
			link.l2 = "Alors racontez-la une cent unième fois, oם est le problème ? La langue n'a pas d'os, elle supportera bien l'épreuve.";
			link.l2.go = "Istoria_InesDias_2";
		break;
		case "Istoria_InesDias_2":
			dialog.text = "Ha ! Vous savez convaincre les gens, petit morveux ! Bon, soit, écoutez.";
			link.l1 = "Pour l'instant, je n'entends que des insultes. Vous allez peut-être commencer votre histoire, finalement ?";
			link.l1.go = "Istoria_InesDias_3";
		break;	
		case "Istoria_InesDias_3":
			dialog.text = "Taisez-vous et écoutez, et n'interrompez pas vos aînés ! C'était il y a longtemps, il y a environ 30 ans, je n'étais qu'une jeune fille. Le bruit de la mer me tournait la tête, l'odeur des algues qui pourrissaient sur le rivage, les nuits étoilées et les étreintes brמlantes...";
			link.l1 = "Continuez.";
			link.l1.go = "Istoria_InesDias_4";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;		
		case "Istoria_InesDias_4":
			dialog.text = "Un jour, un jeune marin de la marine militaire, comment s'appelait-il déjà ? Oh, peu importe, bref, il m'a convaincue de partir avec lui pour un pays fabuleux, oם l'on peut s'enrichir vite et oם tout le monde vit heureux.";
			link.l1 = "Il voulait parler du Nouveau Monde ?";
			link.l1.go = "Istoria_InesDias_5";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;
		case "Istoria_InesDias_5":
			dialog.text = "Pas bête, "+GetSexPhrase("le gars", "la fille")+". Oui, c'est exactement comme ça que ça s'est passé ; comme je vous l'ai dit, j'étais jeune, on me tournait facilement la tête, et j'ai accepté sa proposition insensée.";
			link.l1 = "Mais comment un simple marin a-t-il pu vous faire monter à bord d'un navire de guerre ? C'est interdit.";
			link.l1.go = "Istoria_InesDias_6";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;	
		case "Istoria_InesDias_6":
			dialog.text = "Vous savez tout ! Ha, nous avions imaginé un plan rusé, du moins c'est ce qui nous semblait à l'époque, et il m'a cachée dans la cale, parmi les ballots de biscuits.";
			link.l1 = "Et que s'est-il passé ensuite ?";
			link.l1.go = "Istoria_InesDias_7";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;	
		case "Istoria_InesDias_7":
			dialog.text = "Et ensuite, bien sמr, on m'a trouvée. Je ne supportais pas du tout le roulis, si bien qu'une heure à peine après l'appareillage, je me suis mise à hurler et à appeler à l'aide, persuadée que j'allais mourir et que mes minutes étaient comptées. Comment voulez-vous qu'une jeune sotte se tienne, quand son estomac est sur le point de lui sortir par la bouche ?";
			link.l1 = "Continuez.";
			link.l1.go = "Istoria_InesDias_8";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;
		case "Istoria_InesDias_8":
			dialog.text = "Mon marin a été exécuté pour avoir enfreint le règlement du bord, et on s'apprêtait à me faire passer sous la quille, puis à me jeter en pâture aux requins, mais heureusement, un navire battant pavillon noir est apparu à l'horizon.";
			link.l1 = "De Charybde en Scylla, voilà ce que ça me rappelle.";
			link.l1.go = "Istoria_InesDias_9";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;
		case "Istoria_InesDias_9":
			dialog.text = "Et vous n'êtes pas loin de la vérité. On m'a jetée dans une cabine pendant la bataille, pour s'occuper de moi ensuite ; mais par la volonté de la Providence, quelque chose a mal tourné, et les pirates ont vaincu ces soi-disant guerriers.";
			link.l1 = "Et vous êtes tombée entre les mains des pirates ?";
			link.l1.go = "Istoria_InesDias_10";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;
		case "Istoria_InesDias_10":
			dialog.text = "Quelque chose comme ça. C'est un tout jeune garçon qui a ouvert ma cabine. Mon Dieu, qu'il était beau ! J'ai oublié d'un coup mes peurs en voyant sa silhouette dans l'encadrement de la porte, sa main robuste serrant un sabre d'abordage taché de sang.";
			link.l1 = "Et ensuite ?";
			link.l1.go = "Istoria_InesDias_11";
			link.l2 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l2.go = "meeting";
		break;
		case "Istoria_InesDias_11":
			dialog.text = "C'est tout ce que vous avez besoin de savoir ! Ne faites pas rougir une vieille femme !";
			link.l1 = "Je ne voulais pas...";
			link.l1.go = "Istoria_InesDias_12_1";
			link.l2 = "Vous, rougir ? Ne faites pas semblant : vous en avez vu d'autres, et vous essayez de jouer les jeunes filles timides.";
			link.l2.go = "Istoria_InesDias_12_2";
			link.l3 = "J'ai déjà tout compris. Passons aux affaires.";
			link.l3.go = "meeting";
		break;
		case "Istoria_InesDias_12_1":
			dialog.text = "Vous ne vouliez pas ? Vous vous moquez de moi ?!";
			link.l1 = "Racontez-moi peut-être simplement ce qui s'est passé ensuite... comment vous vous êtes retrouvée à terre.";
			link.l1.go = "Istoria_InesDias_13";
		break;
		case "Istoria_InesDias_12_2":
			dialog.text = "Que nous sommes perspicaces, c'en est fou. Vous irez sans doute loin, si vous ne mourez pas prématurément.";
			link.l1 = "Continuez votre histoire, " + npchar.name+".";
			link.l1.go = "Istoria_InesDias_13";
		break;
		case "Istoria_InesDias_13":
			dialog.text = "Bon, bon, je continue. C'est là, à bord, que j'ai rencontré celui que tout le monde connaît aujourd'hui sous le nom d'Isenbrandt Jurksen. א l'époque, ce n'était qu'un beau garçon aux yeux bleus, et je crois que je lui plaisais aussi, hein ! Après tout, c'est cette nuit-là qu'il est devenu le commandant de son premier navire, en abattant l'ancien capitaine en duel à cause de moi.";
			link.l1 = "Et que s'est-il passé ensuite ?";
			link.l1.go = "Istoria_InesDias_14";
		break;
		case "Istoria_InesDias_14":
			dialog.text = "Nous avons navigué ensemble, et j'adorais cette vie, bon sang ! Et puis nous nous sommes disputés pour une broutille, et j'ai armé mon propre navire ; heureusement, les piastres tintaient dans mon corset.";
			link.l1 = "Vous êtes devenue capitaine d'un navire pirate ?";
			link.l1.go = "Istoria_InesDias_15";
		break;
		case "Istoria_InesDias_15":
			dialog.text = "Oui, bon sang ! Et une bonne capitaine ! Tous les marchands de ces eaux me craignaient, ma tête était mise à prix, mais j'avais de la chance, et j'échappais à mes poursuivants, ou bien je les anéantissais.";
			link.l1 = "Et ? Que s'est-il passé ensuite ?";
			link.l1.go = "Istoria_InesDias_16";
		break;
		case "Istoria_InesDias_16":
			dialog.text = "Et puis j'ai été blessée lors de l'abordage d'une corvette anglaise, commandée par un type obstiné qui me pourchassait depuis plusieurs mois ; une fois rétablie, j'ai décidé de tout laisser tomber : ma santé n'était plus la même, j'ai soudain eu envie d'une vie tranquille quelque part à terre, et j'ai ouvert une taverne sur ce bout de terre.";
			link.l1 = "Une histoire intéressante. Merci de me l'avoir racontée, mais parlons d'autre chose maintenant.";
			link.l1.go = "meeting";
		break;

		//ОЗГ
		case "Seek_Carlos":
		if (pchar.questTemp.Headhunter.Chance == 1)
		{
			dialog.text = "Ha ! Il est donc quelque part par ici, dans la taverne ! Je l'ai vu il y a environ cinq minutes. Regardez, il doit être là.";
		}
		else
		{
			dialog.text = "Hum... Il était chez moi il y a environ une heure. Et maintenant, il est parti : au bordel, il me semble, c'est là qu'il voulait aller.";
		}
		link.l1 = "Merci ! Vous m'avez beaucoup aidé !";
		link.l1.go = "exit";
		pchar.questTemp.Headhunter = "hunt_carlos_fight";
		break;
		//ОЗГ

		//Виспер
		case "w_find_desouza":
			dialog.text = "Oui, des types sont venus ici, ils posaient des questions. Ils n'ont bien sמr pas dit qu'ils travaillaient pour l'Inquisition, mais on ne me la fait pas. J'ai tout de suite remarqué une marque en forme de crucifix sur le poignet de l'un d'eux. C'est la marque que les inquisiteurs font aux anciens criminels quand ils les recrutent dans leur ordre.";
			link.l1 = "Vous êtes très perspicace, pour un simple aubergiste. Mais pourquoi avez-vous décidé de me parler de ces types, et non pas de leur parler de moi ?";
			link.l1.go = "w_find_desouza_1";
		break;
		case "w_find_desouza_1":
			dialog.text = "Eh bien, d'abord, je n'aime pas trop les inquisiteurs, et ensuite, ils sont partis depuis longtemps. Vous, en revanche, vous aimeriez peut-être savoir oם.";
			link.l1 = "Et oם donc ?";
			link.l1.go = "w_find_desouza_2";
		break;
		case "w_find_desouza_2":
			dialog.text = "Et nous voilà à la raison principale pour laquelle je vous ai raconté tout ça. Bien sמr, ce genre d'information coמte de l'argent. Dix mille.";
			link.l1 = "Tenez. Allez, racontez, ne traînez pas.";
			link.l1.go = "w_find_desouza_3";
		break;
		case "w_find_desouza_3":
			AddMoneyToCharacter(pchar, -10000);
			dialog.text = "Ah, voilà qui est tout autre chose. Ils sont partis pour un port hollandais.";
			link.l1 = "Et plus précisément ?";
			link.l1.go = "w_find_desouza_4";
		break;
		case "w_find_desouza_4":
			dialog.text = "Plus précisément, je ne sais pas, mais les Hollandais n'ont pas beaucoup de ports aux Caraïbes, vous les trouverez sמrement.";
			AddQuestRecord("WhisperQuestline", "4");
			pchar.Whisper.FindDesouzaHol = true;
			link.l1 = "D'accord, au revoir.";
			link.l1.go = "exit";
		break;
		case "w_meet_esteban_friend":
			dialog.text = "L'un de mes clients vous a demandé. Il a dit qu'il cherchait le capitaine du « Chien de guerre » pour une affaire importante.";
			link.l1 = "De quoi s'agit-il ?";
			link.l1.go = "w_meet_esteban_friend_1";
		break;
		case "w_meet_esteban_friend_1":
			dialog.text = "Vous le saurez de sa propre bouche. Il est dans sa chambre en ce moment.";
			link.l1 = "Voilà qui m'intrigue. Je vais aller lui parler.";
			link.l1.go = "exit";
			pchar.Whisper.EsFriendTown = FindStringBeforeChar(npchar.id, "_tavernkeeper");
			WhisperSpawn_Chard();
		break;

		//Виспер

		//Lipsar Квест История Давней Дружбы
		case "MaksQuest_1":
			dialog.text = "Vous cherchez sans doute ce type louche au chapeau et au pourpoint vert.";
			link.l1 = "Merci de votre aide.";
			link.l1.go = "exit";
			DeleteAttribute(Pchar, "Luke.SpawnMaks");
		break;
		case "LukeQuest_1":
			bDisableFastReload = true;
			dialog.text = "Dès que vous êtes parti, des gens sont entrés dans la taverne, lui ont parlé, et ils sont partis ensemble. Et oם, je n'en sais rien.";
			link.l1 = "דa alors ! א quoi ressemblaient-ils, vous pouvez me le dire ?";
			link.l1.go = "LukeQuest_2";
		break;
		case "LukeQuest_2":
			dialog.text = "Des pirates typiques, ils n'avaient rien de particulier.";
			link.l1 = "D'accord, merci pour l'information.";
			link.l1.go = "exit";
			link.l2 = "D'accord, merci pour l'information. Tenez, en signe de gratitude.";
			link.l2.go = "Pay1000";
			Pchar.Luke.Info = "Fight";
			AddDialogExitQuest("ChangeLukesHome");
		break;
		case "Pay1000":
			dialog.text = "Merci, " + GetSexPhrase("monsieur", "madame") + ", je ne m'y attendais pas."
			link.l1 = "Ce n'est rien pour moi.";
			link.l1.go = "exit";
			AddMoneyToCharacter(Pchar, -1000);
			Pchar.Luke.Info = "Peace";
		break;
		case "TohmasPetit_BarmanBranch":
			// Борода: путь читаем ОДИН раз - ветки ниже удаляют сам атрибут,
			// и следующие проверки падали с "missed attribute"
			string sTohmasSearchPath = "";
			if (CheckAttribute(pchar, "QuestTemp.TohmasPetit_Search.Path")) sTohmasSearchPath = pchar.QuestTemp.TohmasPetit_Search.Path;

			if (sTohmasSearchPath == "TooLate")
			{
				dialog.text = "Ah, Thomas Petit ? Mais il est pratiquement à mi-chemin de l'Europe à l'heure qu'il est. Il a fait ses bagages, il est monté à bord bras dessus bras dessous avec sa charmante Madeline LeBlanc, il a fait de chaleureux adieux à son ami Gaston de Leroy, sur le quai, et il a mis le cap sur l'Ancien Monde. Il disait qu'il en avait par-dessus la tête de ce coin. Au fait, capitaine, vous ne voudriez pas vous rincer le gosier avec un bon rhum de la Jamaïque, ou louer une chambre pour la nuit ?";
				link.l1 = "Vraiment... Eh bien, merci pour l'information. Je passe mon tour pour la boisson et le repos, le devoir m'appelle. Portez-vous bien.";
				link.l1.go = "exit";
				AddQuestRecord("TohmasPetit", "TohmasPetit_TooLate");
				CloseQuestHeader("TohmasPetit");
				pchar.questdata.TohmasPetit = 1;
				TohmasPetit_ClearQuestTemp(); // Борода: квест закрыт - снимаем временные атрибуты
			}
			
			if (sTohmasSearchPath == "just_left")
			{
				dialog.text = "Thomas ? Eh bien, l'un des habitués a dit l'avoir vu avec sa bien-aimée, Madeline LeBlanc, il y a environ une heure. Ce beau parleur tenait la demoiselle fermement par la main et filait tête baissée vers la capitainerie. Mais oם ils sont allés ensuite, Dieu seul le sait, je ne les ai plus revus. Capitaine, vous aimeriez peut-être commander une bouteille de bon vin après votre voyage ?";
				link.l1 = "א la capitainerie, dites-vous ? Je n'ai pas le temps pour votre vin, aubergiste, chaque minute compte !";
				link.l1.go = "exit";
				AddQuestRecord("TohmasPetit", "TohmasPetit_JustLeft");
				DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search");
				pchar.QuestTemp.TohmasPetit_Search.PortOffice = "active";
			}
			
			if (sTohmasSearchPath == "near_left")
			{
				dialog.text = "Thomas, dites-vous ? Un ivrogne du coin prétend l'avoir vu sur le quai il y a quelques instants. Il dit que Thomas et sa Madeline LeBlanc ont fait leurs adieux à leur ami, Gaston de Leroy, et qu'ils sont montés en hâte à bord d'un navire nommé « Atlantica ». Le navire vient tout juste de lever l'ancre, il n'a donc pas encore eu le temps de quitter les eaux de l'île. Je vous sers une chope de bière, capitaine ? Vous pourrez vous reposer en attendant que le calme passe !";
				link.l1 = "Gardez votre bière pour les ivrognes du port ! Si l'« Atlantica » vient tout juste de partir avec ce couple, je peux encore l'intercepter sur les récifs extérieurs. Il est temps de hisser les voiles !";
				link.l1.go = "exit";
				AddQuestRecord("TohmasPetit", "TohmasPetit_NearLeft");
				DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search");
				AddDialogExitQuest("TohmasPetit_SpawnShipOnBattleMap");
			}
			
			if (sTohmasSearchPath == "left_late")
			{
				dialog.text = "Thomas Petit ? Vous arrivez trop tard, capitaine. Il est parti hier avec sa belle Madeline LeBlanc. Leur vieil ami, un officier d'ici nommé Gaston de Leroy, les a accompagnés sur le quai. Ils se sont serré la main, ont échangé quelques mots, et Thomas est monté à bord de l'« Atlantica », bras dessus bras dessous avec sa chérie. Quant aux détails de leur route, je ne les connais pas. Vous restez un peu ? Je peux vous proposer une excellente chambre aux draps propres.";
				link.l1 = "Et l'officier était là, lui aussi... וvidemment, ils sont de mèche. Merci pour la proposition, aubergiste, mais je n'ai pas le temps de me reposer maintenant. Je vais tirer de mon navire jusqu'au dernier nœud, mais je rattraperai cet « Atlantica » en haute mer !";
				link.l1.go = "exit";
				AddQuestRecord("TohmasPetit", "TohmasPetit_LeftLate");
				DeleteAttribute(pchar, "QuestTemp.TohmasPetit_Search");
				AddDialogExitQuest("TohmasPetit_SpawnShipOnGlobalMap");
			}
		break;
	}
}

string findTraderCity(ref NPChar)
{
	int n, nation;
    int storeArray[MAX_COLONIES];
    int howStore = 0;

	for(n=0; n<MAX_COLONIES; n++)
	{
		nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
		if (colonies[n].id != "Panama" && colonies[n].nation != "none" && GetIslandByCityName(npchar.city) != colonies[n].islandLable) //не на свой остров
		{
			if (nation == RELATION_ENEMY || sti(npchar.nation) == PIRATE)
		{
			storeArray[howStore] = n;
			howStore++;
		}
	}
	}
	if (howStore == 0) return "none";
	nation = storeArray[cRand(howStore-1)];
	return colonies[nation].id;
}

string findPassangerCity(ref NPChar)
{
	int n, nation;
    int storeArray[MAX_COLONIES];
    int howStore = 0;

	for(n=0; n<MAX_COLONIES; n++)
	{
		nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
		if (colonies[n].nation != "none" && colonies[n].id != "Panama" && GetIslandByCityName(npchar.city) != colonies[n].islandLable) //не на свой остров
		{
			if (nation == RELATION_ENEMY || sti(npchar.nation) == PIRATE)
			{
			storeArray[howStore] = n;
			howStore++;
		}
	}
	}
	if (howStore == 0) return "none";
	nation = storeArray[cRand(howStore-1)];
	return colonies[nation].id;
}
