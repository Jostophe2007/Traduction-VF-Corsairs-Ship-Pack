// Dialog of the easter-egg talking skeleton in the graveyard chapel (quest "Laying the Dead to Rest")
// The skeleton tells one of ten versions of why the unquiet dead rise here.
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "exit":
			DialogExit();
		break;

		case "First time":
			// mark that the player has seen/spoken with the skeleton - then the watcher can be asked about it
			if (CheckAttribute(pchar, "GenQuest.GraveyardQuest")) pchar.GenQuest.GraveyardQuest.ChapelSkelMet = true;
			dialog.text = "Ne te presse pas de dégainer, capitaine. Je ne suis pas de ceux qui rכdent la nuit en grinçant des dents contre les vivants. Je reste juste assis ici, dans cette vieille chapelle, et je réfléchis... Puisque tu as rendu le repos aux autres, tu voudras peut-être bien m'écouter, moi aussi ?";
			link.l1 = "D'oם vient toute cette engeance de morts-vivants, au juste ?";
			link.l1.go = "Story";
			link.l2 = "Je n'ai pas le temps de bavarder avec des os. Adieu.";
			link.l2.go = "exit";
		break;

		case "Story":
			switch (rand(9))
			{
				case 0:
					dialog.text = "La terre est mauvaise ici, capitaine. On dit que la chapelle a été bâtie sur un vieil autel païen, d'avant l'arrivée des Blancs. Le sang versé ici pour les idoles a imprégné le sol lui-même. Alors les morts ne trouvent pas le repos : c'est la terre elle-même qui les recrache.";
				break;
				case 1:
					dialog.text = "Il y en avait un... un savant, en robe noire. Il fouillait les cryptes la nuit, en murmurant du latin au-dessus des ossements. Un jour, il a disparu, et depuis, les morts se relèvent. Je pense qu'il n'est jamais mort : il est quelque part près d'ici, à tirer nos ficelles comme un marionnettiste.";
				break;
				case 2:
					dialog.text = "C'est le rite. Le vieux prêtre, qui savait mettre correctement les morts en terre, n'est plus là depuis longtemps. Les nouveaux enterrent les gens n'importe comment, sans les paroles qu'il faut. Une âme mal accompagnée ne peut pas partir : alors, elle revient dans le corps qu'elle a laissé.";
				break;
				case 3:
					dialog.text = "La peste, capitaine. Il y a cent ans, elle a fauché la moitié de la ville. On les a enterrés dans des fosses communes, à la hâte, sans aucun rite : on les y a jetés et recouverts de chaux. Tant de morts outragés au même endroit... Ils se souviennent qu'on les a traités comme des ordures. Et ils sont en colère.";
				break;
				case 4:
					dialog.text = "Sous la crypte, il y a quelque chose que tu ferais mieux de ne pas connaître. Un vieux sceau, et dessous, quelque chose qui dort ou qui attend. Tant que le sceau tient, cela ne fait qu'attirer les morts à soi, en les relevant pour les mettre à son service. Mais si quelqu'un le brisait... Mieux vaut ne pas en arriver là.";
				break;
				case 5:
					dialog.text = "Demande plutכt au gardien pourquoi il s'accroche autant à ce cimetière sans jamais en franchir les limites. Il en sait plus qu'il n'en dit. J'ai dans l'idée qu'il a conclu un marché avec quelqu'un il y a longtemps, et qu'il le paie maintenant, année après année, avec nos os.";
				break;
				case 6:
					dialog.text = "Il y a de l'or maudit ici, capitaine. Un pirate a enterré son trésor en plein dans une tombe, et il l'a frappé d'une malédiction, pour que le mort garde le butin. Seulement, la malédiction s'est répandue sur tout le cimetière. Maintenant, ils montent tous la garde, sans même savoir sur quoi.";
				break;
				case 7:
					dialog.text = "C'est la pleine lune, voilà tout. Certaines nuits, la lune pend bas ici, rouge comme du fer rouillé. Ces nuits-là, le voile entre l'autre monde et celui-ci s'amincit jusqu'à n'être plus qu'un cheveu. Les morts entendent l'appel et se relèvent, non par méchanceté, mais parce qu'ils ne comprennent pas qu'ils sont déjà morts.";
				break;
				case 8:
					dialog.text = "On racontait l'histoire d'une fille enterrée vivante : on l'avait crue morte, emportée par la fièvre. Elle s'est réveillée sous terre et a hurlé jusqu'à s'étouffer. Depuis, sa rancune réveille les autres. On dit que certaines nuits, on entend encore gratter sous la terre.";
				break;
				case 9:
					dialog.text = "Ou peut-être qu'il n'y a pas de grand secret du tout. Peut-être qu'on ne veut tout simplement pas partir. C'est calme ici, c'est familier. Qui voudrait s'en aller dans des ténèbres inconnues quand on peut rester là oם l'on a vécu sa vie ? Vous, les vivants, vous vous accrochez à la vie. Et nous, les morts, nous nous accrochons à la mort.";
				break;
			}
			// упоминание СТАРШЕГО: пасхалка могла выпасть после его убийства ЛИБО когда он вовсе не поднялся
			if (CheckAttribute(pchar, "GenQuest.GraveyardQuest.AvengerKilled"))
			{
				dialog.text = dialog.text + "\n\nEt encore une chose... C'est donc toi qui as rendu le repos à l'ANCIEN ? Le guerrier du tertre le plus éloigné, celui qui s'est levé pour venger notre sommeil troublé ? De son vivant, il maniait si bien la lame que Mictlantecuhtli lui-même, seigneur du royaume des morts, l'a marqué et l'a appelé dans sa garde après sa mort... Si tu as vaincu un élu du dieu des morts, pourquoi te craindrais-je ? Voilà pourquoi je te parle si librement.";
			}
			else
			{
				dialog.text = dialog.text + "\n\nEt encore une chose... Remercie le ciel que l'ANCIEN ne se soit pas levé : le guerrier du tertre le plus éloigné doit dormir profondément. De son vivant, il maniait si bien la lame que Mictlantecuhtli lui-même, seigneur du royaume des morts, l'a marqué et l'a appelé dans sa garde après sa mort. Si tu l'avais réveillé, qui sait lequel de vous deux serait encore debout.";
			}
			DeleteAttribute(NPChar, "dialog"); // one tale at a time: the skeleton won't talk again (until the next easter egg)
			link.l1 = RandPhraseSimple("Merci pour l'histoire. Repose en paix.", "Voilà donc ce qu'il en est... Va-t'en, vieux tas d'os.");
			link.l1.go = "exit";
		break;
	}
}
