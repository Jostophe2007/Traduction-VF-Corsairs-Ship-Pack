// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
			int izpqRank = 1;
			if (!bQuestsRank) izpqRank = 12; 	//Если стоит галочка, то убрать требования рангов у квестов
            dialog.text = "Parlez, je vous écoute.";
			if (sti(PChar.rank) >= izpqRank && pchar.questTemp.zpq != "begin" && pchar.questTemp.zpq != "failed" && pchar.questTemp.zpq != "completed")
			{
				link.l1 = "Officier, je vois que vous avez l'air très soucieux. Puis-je vous aider en quelque chose ?";
				link.l1.go = "zpq_prs1";
			}
			if (pchar.questTemp.zpq == "begin" && GetSquadronGoods(pchar, GOOD_POWDER) >= 50000 && GetQuestPastDayParam("pchar.questTemp.zpq") >= 7)
			{
				link.l2 = "Je m'empresse de vous informer que la cargaison de poudre a été livrée. Le navire est prêt à être déchargé.";
				link.l2.go = "zpq_ex";
			}
			if (pchar.questTemp.zpq == "begin")
			{
				link.l3 = "Je veux annuler notre contrat de livraison de poudre. Il s'est révélé trop embarrassant...";
				link.l3.go = "zpq_fld2";
			}
			link.l4 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Bonne journée.";
			link.l4.go = "Exit";
		break;

		case "zpq_prs1":
		if(!isBadReputation(pchar, 70))
		{
			dialog.text = "Hum, peut-être, peut-être... Grâce à votre bonne réputation, je me risquerai peut-être à vous faire confiance. Sinon, je n'aborderais même pas un tel sujet. Le fait est que nous avons besoin d'une assez grosse cargaison délicate ; il vous faudra donc un navire avec une grande cale et le goמt du risque. Et vous devez promettre que les informations que vous recevrez ne parviendront à aucune oreille indiscrète. Si l'une de ces conditions vous gêne, dites-le-moi tout de suite. Je pense que vous me comprenez...";
			link.l1 = "Voilà qui est fort intrigant. Et même si je ne devine pas de quelle cargaison il s'agit, je suis prêt à tenter ma chance si le paiement est convenable. Quoi qu'il en soit, je vous donne ma parole.";
			link.l1.go = "zpq_prs2";
			link.l2 = "Non, sans doute pas... Ma parole m'obligerait à me charger d'une affaire qui me paraît déjà très douteuse. Je ne m'en mêlerai pas...";
			link.l2.go = "zpq_fld";
		}
		else
		{
			dialog.text = "Votre réputation ne me permet pas de faire des affaires sérieuses avec vous. Veuillez quitter la pièce. Nous sommes capables de régler nos problèmes nous-mêmes.";
			link.l1 = "Eh bien, à vous de voir...";
			link.l1.go = "exit";
		}
		break;
		case "zpq_fld":
			dialog.text = "Eh bien, au moins, vous avez refusé honnêtement, sans détour... Je n'ose pas vous retenir.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			pchar.questTemp.zpq = "failed";
		break;
		case "zpq_fld2":
			dialog.text = "Hum, je dois avouer que je ne m'attendais pas à une telle dérobade. Je dois vous demander de partir... Et souvenez-vous de votre promesse de ne pas divulguer les informations reçues.";
			link.l1 = "Pardonnez-moi, je vous prie...";
			link.l1.go = "exit";
    			ChangeCharacterReputation(pchar, -10);

			if (pchar.questTemp.zpq == "begin")
			{
				AddQuestRecord("zpq", "6");
				AddQuestUserData("zpq", "sSex", GetSexPhrase("", "e"));
				CloseQuestHeader("zpq");
				pchar.questdata.OpasnyGruz = 1;
			}
			pchar.questTemp.zpq = "failed";
		break;
		case "zpq_prs2":
			dialog.text = "Parfait. Le fait est qu'une longue tempête récente a détrempé une bonne quantité de poudre dans les arsenaux de notre fort. J'espère que je n'ai pas besoin de vous expliquer dans quelle situation délicate nous nous trouvons. En cas de siège sérieux, le fort aura du mal à opposer une résistance digne de ce nom, nous ne tiendrons pas longtemps.";
			link.l1 = "Maintenant, on comprend de quelle cargaison vous avez besoin. Et de quelle quantité parlons-nous ?";
			link.l1.go = "zpq_prs3";
		break;
		case "zpq_prs3":
			dialog.text = "Il nous faut 50 000 charges de poudre. Je paierai 300 000 piastres pour l'ensemble de la cargaison... c'est un très bon prix, vous savez. Notre situation nous oblige à payer un tel prix, même si j'ai dמ faire de gros efforts pour convaincre le trésorier du gouverneur... La saison des tempêtes ne nous permet pas d'utiliser les voies d'approvisionnement habituelles, et nous ne pouvons pas ébruiter une telle affaire...";
			link.l1 = "Compris... le prix est vraiment bon. Au fait, vous avez parlé d'un certain risque.";
			link.l1.go = "zpq_prs4";
		break;
		case "zpq_prs4":
			dialog.text = "Je voulais dire qu'une telle quantité de poudre dans la cale peut être très dangereuse pendant le transport. De mémoire, il y a eu plusieurs cas de navires qui ont explosé à cause d'une étincelle accidentelle, et si en plus on tombe dans une tempête... Pendant le transport, même le convoi se tient à l'écart d'un tel brמlot potentiel, parce qu'au moindre incident, tout le monde volera en éclats !..";
			link.l1 = "Je vois... Mais je ne parle pas en l'air : considérez que la commande est acceptée.";
			link.l1.go = "zpq_prs5";
			link.l2 = "Oh, señor... Vous racontez des choses terribles... Je n'ai plus envie de m'en mêler.";
			link.l2.go = "zpq_fld2";
		break;
		case "zpq_prs5":
			dialog.text = "Parfait, je suis si content que nous ayons conclu un marché. Nous réglerons immédiatement après la livraison, vous n'avez pas à vous en inquiéter. La cargaison doit être livrée au plus tכt dans une semaine : c'est le temps qu'il me faut pour réunir tout l'argent. Même si je comprends qu'il sera difficile de réunir un tel lot, et que je ne vous impose pas de délai, tâchez tout de même de ne pas tarder.";
			link.l1 = "Tout est très clair pour moi, señor. Je commence immédiatement.";
			link.l1.go = "zpq_prs5_ok";
		break;
		case "zpq_prs5_ok":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.zpq = "begin";
			//pchar.questTemp.zpq.time = 20;//не вижу использования этого
			AddQuestRecord("zpq", "1");
			AddQuestUserData("zpq", "sSex", GetSexPhrase("", "e"));
			SaveCurrentQuestDateParam("pchar.questTemp.zpq");
		break;
		case "zpq_ex":
			dialog.text = "Ah, enfin ! Je croyais que vous aviez oublié notre accord. Je vais immédiatement ordonner d'envoyer des soldats pour le déchargement. La poudre, ça ne supporte pas la précipitation, héhé !";
			link.l1 = "Tout ça est très bien, señor, mais je dois vous rappeler le paiement.";
			link.l1.go = "zpq_ex2";
			RemoveCharacterGoods(pchar, GOOD_POWDER, 50000);
			AddCharacterExpToSkill(pchar, "Sailing", 500);
			AddCharacterExpToSkill(pchar, "Fortune", 500);

            		pchar.quest.zpq_sld1_fc.win_condition.l1 = "location";
            		pchar.quest.zpq_sld1_fc.win_condition.l1.location = "Cumana_ExitTown";
            		pchar.quest.zpq_sld1_fc.function = "zpq_sld1_fc";
		break;
		case "zpq_ex2":
			dialog.text = "Oui, oui, bien sמr. On vous paiera 150 000 piastres tout de suite, comme convenu.";
			link.l1 = "Vous vous moquez de moi, señor ?! Le contrat était de 300 000, et je ne céderai pas une piastre !";
			link.l1.go = "zpq_ex3";
			link.l2 = "Je commence à penser que vous essayez de me rouler ; je ne partirai donc pas d'ici sans mes 450 000 piastres !";
			link.l2.go = "zpq_ex4";
			link.l3 = "Hum... Je vois que les circonstances ont changé. Eh bien, je suis prêt à accepter la somme indiquée pour ne pas envenimer la situation.";
			link.l3.go = "zpq_ex5";
		break;
		case "zpq_ex3":
			if (GetSummonSkillFromName(pchar, "Leadership") > 50)
			{
				dialog.text = "Ah oui... exactement ! 300 000 piastres. J'avais oublié, veuillez m'excuser. L'âge, vous savez, la mémoire n'est plus ce qu'elle était... Bien sמr, voici votre argent. Ce fut un plaisir de traiter avec vous. Maintenant, si vous voulez bien m'excuser, des affaires m'attendent...";
				link.l1 = "Pour moi aussi, ce fut un plaisir, señor. Bonne journée.";
				link.l1.go = "exit";
				pchar.questTemp.zpq = "completed";
            			AddQuestRecord("zpq", "2");
				AddQuestUserData("zpq", "sSex", GetSexPhrase("", "e"));
				CloseQuestHeader("zpq");
				pchar.questdata.OpasnyGruz = 1;
				pchar.questTemp.zpq.sum = 300000;
				AddMoneyToCharacter(pchar, makeint(pchar.questTemp.zpq.sum));
			}
			else
			{
				dialog.text = "Comment ça ?!! Prenez l'argent et fichez le camp, sinon vous allez pourrir dans ces casemates !";
				link.l1 = "Oui, señor, vous êtes un menteur ! Je vous conseille de me donner de bon gré l'argent convenu, sinon je reprends la marchandise !";
				link.l1.go = "zpq_ex_agry";
				link.l2 = "Pardonnez-moi, je vous prie... Bon, je prends la somme proposée et nous en restons là.";
				link.l2.go = "zpq_ex5";
			}
		break;
		case "zpq_ex4":
				dialog.text = "Quelle insolence ! Je n'ai pas encore perdu la tête, et je me souviens parfaitement que notre marché était de 300 000 pi... Oh, bon sang ! Vous ne m'aurez pas !";
				link.l1 = "Ne vous emportez pas. Pensez plutכt au fait qu'il y a, au pied des murs de votre fort, un brמlot tout prêt, rempli de poudre à ras bord. Je n'ai qu'à siffler, et vos fortifications ne seront plus que ruines.";
				link.l1.go = "zpq_ex6";
		break;
		case "zpq_ex6":
			if (GetSummonSkillFromName(pchar, "Leadership") > 75)
			{
				dialog.text = "Euh... un argument de poids. 450 000 piastres, dites-vous ? Tenez, voici votre argent... Et maintenant, si vous voulez bien m'excuser, des affaires m'attendent...";
				link.l1 = "Bonne journée, señor. Au revoir.";
				link.l1.go = "exit";
				pchar.questTemp.zpq = "completed";
            			AddQuestRecord("zpq", "5");
				CloseQuestHeader("zpq");
				pchar.questdata.OpasnyGruz = 1;
				pchar.questTemp.zpq.sum = 450000;
				AddMoneyToCharacter(pchar, makeint(pchar.questTemp.zpq.sum));
			}
			else
			{
				dialog.text = "Quoi ?! Je suis un officier de combat ! Qui essayez-vous d'effrayer"+ GetSexPhrase(", morveux", ", morveuse") +" ?! Gardes, sus à "+ GetSexPhrase("lui", "elle") +" !!!";
				link.l1 = "Eh bien, tenez bon, rats des casemates...";
				link.l1.go = "zpq_ex_war";
			}
		break;
		case "zpq_ex5":
			dialog.text = "Parfait ! Vous avez fait le bon choix. Prenez l'argent, et au revoir. Ce fut un plaisir de traiter avec vous. Ha ha ha !";
			link.l1 = "Au revoir...";
			link.l1.go = "exit";
			pchar.questTemp.zpq = "completed";
            		AddQuestRecord("zpq", "3");
			AddQuestUserData("zpq", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("zpq");
			pchar.questdata.OpasnyGruz = 1;
			pchar.questTemp.zpq.sum = 150000;
			AddMoneyToCharacter(pchar, makeint(pchar.questTemp.zpq.sum));
		break;
		case "zpq_ex_agry":
			dialog.text = "Oh, espèce de salaud !!! Gardes, sus à "+ GetSexPhrase("lui", "elle") +" !!!";
			link.l1 = "Argh !! Je vais devoir prendre l'argent sur ton cadavre...";
			link.l1.go = "zpq_ex_war";
		break;
        	case "zpq_ex_war":

			DialogExit();

			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetFightMode(PChar, true);
			Flag_Change(PIRATE);
			pchar.questTemp.zpq = "failed";
            		AddQuestRecord("zpq", "4");
			CloseQuestHeader("zpq");
			pchar.questdata.OpasnyGruz = 1;
			pchar.questTemp.zpq.sum = 150000;
			AddMoneyToCharacter(npchar, makeint(sti(pchar.questTemp.zpq.sum)*2 + rand(5000)));
			GiveItem2Character(npchar, "blade20");
			EquipCharacterbyItem(npchar, "blade20");
			npchar.SaveItemsForDead  = true;
			npchar.DontClearDead = true;
			npchar.cirassId = Items_FindItemIdx("cirass4");

			chrDisableReloadToLocation = true;

			string slai_group = GetNationNameByType(sti(npchar.nation))  + "_citizens";

			LAi_group_AttackGroup(slai_group, LAI_GROUP_PLAYER);
			LAi_group_SetCheck(slai_group, "OpenTheDoors");

			AddSimpleRumour("Il s'en passe, des choses, ici !! Le bruit court qu'à Cumaná, un prisonnier s'est échappé des casemates, a tué tous les gardes du fort, a pillé le trésor et a disparu ! דa alors !..", SPAIN, 5, 1);

		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

