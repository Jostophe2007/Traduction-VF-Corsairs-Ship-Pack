
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Je vous écoute, " + PChar.lastname;
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Attendez, capitaine, j'ai à vous parler de toute urgence.";
			link.l1 = "Je vous écoute attentivement.";
			link.l1.go = "2";	
		break;
		
		case "2":
			dialog.text = "La conversation est très importante, et les oreilles indiscrètes sont de trop. Je vous attends hors de la ville.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandToCharlesExitTown");
		break;
		
		case "3":
			dialog.text = "Le fait est que vous êtes devenu par hasard le propriétaire d'un objet qui m'appartient de droit. Je vous demande de me le donner.";
			link.l1 = "De quel droit parlez-vous ? La première partie de la carte, c'est Jim Smith qui me l'a donnée, et vous n'avez rien à voir là-dedans !";
			link.l1.go = "4";	
		break;
		
		case "4":
			dialog.text = "Le fait est, capitaine " + PChar.name + ", que contrairement à vous, j'ai moi aussi participé à cette expédition, et vous avez touché par hasard à une histoire dont vous n'avez aucune idée.";
			link.l1 = "Jim Smith m'a raconté son histoire, et je vais aller au fond de cette affaire.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Jim Smith n'était qu'un pion dans cette partie, et il est simplement resté en vie par hasard. L'affaire est bien plus grave que vous ne le pensez. Je vous conseille de me donner toutes les parties de la carte et de tout oublier au plus vite.";
			link.l1 = "Au diable ! Je ne suis pas de ceux qui s'arrêtent à mi-chemin ! Dites-moi ce que vous savez de cette histoire !";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Je vous croyais plus intelligent que vous ne l'êtes en réalité. Je vais devoir prendre ce morceau de carte sur votre cadavre !";
			link.l1 = "Vous me privez de la possibilité d'apprendre ce que vous êtes seul à savoir, car les cadavres ne parlent pas ! Défendez-vous !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandFightWithDubben");
		break;

		case "7":
			dialog.text = "D'accord, capitaine " + PChar.name + ", j'accepte vos conditions. וcoutez bien, vous allez apprendre bien des choses intéressantes.";
			link.l1 = "Je vous écoute, " + npchar.name + " !";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Le capitaine du Starfish, Davy Forser, et moi avions conclu un marché. Vous allez tout comprendre. Davy Forser savait à l'avance qu'il était impossible de quitter cette île en emportant ses trésors : l'équipage du Starfish était condamné à périr. Deux navires sont arrivés sur l'île en même temps. La frégate de Davy Forser et mon brick, le Cutty Clark. J'ai discrètement mouillé mon navire de l'autre cכté de l'île : c'étaient les conditions. Le capitaine Davy Forser disait que sans lui, personne ne pourrait revenir sur l'île chercher les trésors, et que les prendre maintenant, c'était la mort assurée. Il fallait donc en rapporter une certaine chose, puis « mourir » officiellement aux yeux de son équipage. Il m'avait promis de revenir sur l'île chercher l'or la fois suivante. Alors, disait-il, on pourrait toucher à l'or. Tout n'est que devinettes, bon sang ! Quand nous avons accosté au port le plus proche, le capitaine avait disparu. En s'enfuyant, il a emporté la carte grâce à laquelle mon navigateur avait mené le navire jusqu'à l'île. J'ai essayé de le poursuivre, mais ce scélérat avait saboté mon compas, j'ai dמ faire demi-tour ; plus tard, quand j'ai appris que plusieurs marins du Starfish avaient échappé à la mort, je me suis mis à les chercher pour m'emparer du premier exemplaire de la carte, et c'est là que vous m'avez devancé. Je ne connais que le sort du quatrième rescapé de ce sauvetage miraculeux, Diego Marquez. Il est en ce moment en prison à Santo Domingo, pour une dette envers un usurier du coin. C'est peut-être lui qui détient la seconde partie de la carte.";
			link.l1 = "Oui, vous m'avez raconté bien des choses intéressantes, monsieur " + NPChar.name + ". Bon, nous avons une partie de la carte, il faut faire voile vers Santo Domingo pour la seconde.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousIslandToSantoDomingo");
		break;

		case "9":
			dialog.text = "Que le diable vous emporte ! Vous maniez fort bien l'épée !";
			link.l1 = "Si l'affaire est aussi grave que vous le dites, je vous propose d'unir nos efforts. Alors, dites-moi tout ce que vous savez !";
			link.l1.go = "7";

			bDisableOfficers = false;	
		break;
		
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
