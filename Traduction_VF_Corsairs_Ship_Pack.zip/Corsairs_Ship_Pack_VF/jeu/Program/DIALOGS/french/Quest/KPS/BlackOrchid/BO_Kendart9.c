// Gregg: Alehon Kendart - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: Kendart waits for the hero four times this chapter - split by quest state
			if (PChar.FindAndDestroy == "2")
			{
				dialog.text = "Vous avez trouvé Bartelemi ?";
				link.l1 = "Oui. Mort.";
				link.l1.go = "5";
			}
			else
			{
				if (PChar.FindAndDestroy == "6")
				{
					dialog.text = "J'ai examiné les papiers de Fisher. Asseyez-vous.";
					link.l1 = "Je vous écoute.";
					link.l1.go = "25";
				}
				else
				{
					if (PChar.FindAndDestroy == "8")
					{
						dialog.text = "Montrez-moi ce qu'il y avait dans le coffre.";
						link.l1 = "Une clé en or et une lettre de Fisher.";
						link.l1.go = "30";
					}
					else
					{
						if (PChar.FindAndDestroy == "10")
						{
							dialog.text = "Clovis a répondu.";
							link.l1 = "Qu'écrit-il ?";
							link.l1.go = "35";
						}
						else
						{
						// Gregg: the return from Tortuga. In K:PS the glass was opened by a separate
						// screen (UnlockClock.c) which CSP has not got, so the scene plays here.
						// Gregg: the return from Puerto Rico, the close of the chapter.
						if (PChar.FindAndDestroy == "15")
						{
							dialog.text = "...(il se lève pour vous accueillir)... Vivant. Et le vaisseau de ligne ?";
							link.l1 = "Silencieux. Et l'homme qui le commandait est mort.";
							link.l1.go = "45";
						}
						else
						{
						if (PChar.FindAndDestroy == "13")
						{
							dialog.text = "...(il lève les yeux)... De retour. Vivants tous les deux. La clé ?";
							link.l1 = "Les deux. Les voici.";
							link.l1.go = "38";
						}
						else
						{
							dialog.text = "Je travaille. Repassez plus tard.";
							link.l1 = "Je ne vous dérangerai pas.";
							link.l1.go = "exit";
						}
						}
						}
					}
				}
			}
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(sans lever la tête)... Raul est mort cette nuit. Il savait que ça arriverait, et la veille, il m'a tout raconté.";
			link.l1 = "Tout, à propos de quoi ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Du sablier. Il y a trente ans, Andersen lui a ordonné non seulement de le fabriquer, mais d'y enfermer une puissance. Raul a construit deux niveaux de protection, chacun avec sa propre clé. Ouvrir le sablier avec les deux clés, c'est libérer ce qu'il contient, et le détruire.";
			link.l1 = "Et sans les clés ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Sans les clés, le sablier ne se brise pas, ne coule pas et ne s'ouvre pas. J'ai essayé. Les clés ont été perdues il y a plus de trente ans, et sur la seconde, je n'ai absolument rien.";
			link.l1 = "Alors commençons par la première.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "La première clé est en or, d'une forme inhabituelle. Rick Fisher, un corsaire anglais, l'a prise sur le corps d'Andersen, dans sa cabine, pendant l'abordage. Raul se trouvait dans le même réduit et a tout vu.";
			link.l1 = "Oם est Fisher, maintenant ?";
			link.l1.go = "5a";
		break;

		case "5a":
			dialog.text = "Rick a abandonné le métier il y a deux ans et a laissé à son fils Bruce la frégate Seeker et, dit-on, cette même clé. Bruce, il faut le supposer, poursuit l'affaire de son père : chercher ce que la clé ouvre.";
			link.l1 = "Comment le trouver ?";
			link.l1.go = "6a";
		break;

		case "6a":
			dialog.text = "C'est là le plus difficile. Mais j'ai trouvé un homme qui cherche Bruce depuis plus longtemps que moi : un Français, Moris Bartelemi. Rick Fisher lui a autrefois pris le Seeker, et Moris n'a jamais pu s'en remettre.";
			link.l1 = "Et oם est-il ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Dans trois jours, sa barquentine Anna mouillera devant San Juan. Parlez-lui.";
			link.l1 = "J'attendrai l'Anna.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyStart");
		break;

		case "5":
			dialog.text = "...(un long silence)... Alors cette piste-là aussi est coupée. Très bien. Qu'avait-il sur lui ?";
			link.l1 = "Un pistolet chargé qu'il n'a jamais eu le temps de tirer.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Jamais eu le temps. ...(il retourne le pistolet)... Moris ne chassait pas Bruce seul, il avait sa propre escadre. Quelqu'un parmi ces hommes est toujours en vie et doit savoir oם chercher le jeune Fisher.";
			link.l1 = "Vous avez un nom ?";
			link.l1.go = "7b";
		break;

		case "7b":
			dialog.text = "Harvey Murom. Depuis trois mois, il est assis à la taverne de San Juan, à boire aux frais des autres. Demandez-lui.";
			link.l1 = "Je le ferai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyFindKharviMurom");
		break;

		case "18":
			dialog.text = "Une clé. ...(il la lève vers la lumière)... Une clé ordinaire. De l'acier, un panneton simple, on en fait à la douzaine dans n'importe quel port.";
			link.l1 = "Ordinaire ? Je l'ai prise sur Bruce Fisher.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Je vous crois. דa n'en fait pas pour autant la clé en or de forme inhabituelle. Bruce a passé trente ans à chercher ce qu'ouvrait la clé de son père, et il semble avoir trouvé quelque chose : ce qu'il portait sur lui, ce n'était pas cette clé, mais une autre.";
			link.l1 = "Alors à quoi sert celle-ci ?";
			link.l1.go = "20a";
		break;

		case "20a":
			dialog.text = "C'est ce que je vais découvrir. Bruce devait prendre des notes, et vous avez rapporté ses papiers avec lui. Donnez-moi quelques jours.";
			link.l1 = "Examinez-les. J'attendrai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyFindUnlocker");
		break;

		case "25":
			dialog.text = "J'ai trouvé. Le jeune Fisher tenait ses notes avec soin, et je l'en remercie. C'est la clé d'un coffre, et ce coffre se trouve dans une grotte près de Cumaná.";
			link.l1 = "Pourquoi là, justement ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Parce que Rick Fisher l'a caché là oם personne n'aurait l'idée de chercher : parmi des forçats évadés des carrières. Ils le gardent depuis huit ans sans pouvoir l'ouvrir, car la clé était chez Bruce.";
			link.l1 = "La clé est chez moi, maintenant.";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Oui. Seulement, en huit ans, la serrure s'est complètement grippée, alors emportez un crochet, sinon vous y serez encore ce soir.";
			link.l1 = "Un crochet, je peux en trouver un. Cumaná, donc.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyFindMines");
		break;

		case "30":
			dialog.text = "...(il lit la lettre deux fois)... La voilà, la clé en or. Et voici enfin la seconde clé. Fisher écrit qu'il l'a vendue il y a vingt ans à un Français, et que le Français l'a donnée à sa fille.";
			link.l1 = "Qui est le père ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Le gouverneur de Tortuga. La clé pend au cou de sa fille comme un bijou, et elle n'a très probablement aucune idée de ce que c'est.";
			link.l1 = "Tortuga, donc.";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Oui, mais pas par la force. Je connais un corsaire, Clovis Dubois, un guetteur né. Contre rémunération, il découvrira tout sur la jeune fille : quand elle sort, oם elle va, combien d'hommes l'accompagnent.";
			link.l1 = "Combien prend-il ?";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Trois cent mille. C'est cher, mais moins cher que de prendre une ville. Je les prélèverai sur ce que nous avons tiré du Petit Bâtard ; reposez-vous pendant ce temps, Clovis a besoin de quinze jours.";
			link.l1 = "Qu'il compte. Je serai de retour dans quinze jours.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyWaitTime");
		break;

		case "35":
			dialog.text = "La réponse ne me plaît pas. La jeune fille ne quitte jamais l'hכtel de ville, et personne n'a vu le gouverneur depuis un mois.";
			link.l1 = "Qu'est-ce que ça veut dire ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Clovis pense que ce n'est pas le gouverneur qui siège dans cet hכtel de ville, mais quelqu'un qui porte sa peau. Et la jeune fille y est retenue, elle aussi. Il vous attendra à Tortuga, à l'endroit qu'on appelle " + GetConvertStr("Shore58", "LocLables.txt") + ".";
			link.l1 = "J'y vais.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToTortuga");
		break;

		case "38":
			dialog.text = "...(il pose les deux clés sur la table et les regarde longuement)... Trente ans. L'une prise sur un mort, l'autre au cou d'une jeune fille, et elles sont cכte à cכte comme si on les avait forgées hier.";
			link.l1 = "Ouvrez-le.";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "...(il sort le sablier et le pose devant lui)... Reculez, capitaine. Je ne sais pas ce qui va en sortir, et je vous veux entier.";
			link.l1 = "...(recule)...";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "...(il introduit la première clé et la tourne ; elle résiste)... Et la seconde... ...(un déclic)...";
			link.l1 = "...(se tait)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyOpenClock");
		break;

		case "42":
			dialog.text = "...(un long silence)... Le sablier est ouvert. Les deux clés ont tourné, le sable s'est écoulé, et c'est devenu un objet ordinaire. Et puis cet homme est arrivé en parlant d'un navire.";
			link.l1 = "Quel navire ?";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Un vaisseau de ligne noir, sans aucune lumière, qui fait route vers Porto Rico, et la tempête l'accompagne. Il est apparu à l'heure exacte oם nous avons ouvert le sablier, et je ne prends pas ça pour une coïncidence.";
			link.l1 = "Ce qu'il y avait à l'intérieur est sorti.";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "On dirait bien. ...(il pose le sablier sur la table)... Raul disait qu'on pouvait détruire cette puissance, mais qu'elle ne disparaîtrait pas : elle serait libérée. Il n'a pas dit en quoi.";
			link.l1 = "Alors nous le verrons par nous-mêmes.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyToPuertoRico");
		break;

		case "45":
			dialog.text = "...(un long silence)... Voilà, c'est fini. Trente ans, et tout cela a tenu en un seul coup de feu. ...(il prend le sablier sur la table)... Regardez : plus de sable, plus de crâne, l'argent s'est éclairci. Un objet ordinaire.";
			link.l1 = "Tout à fait ordinaire ?";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Pas tout à fait. Il y reste quelque chose, seulement maintenant, ça se tait. ...(il vous le tend)... Prenez-le. J'ai du mal à le regarder, et vous aurez de quoi vous souvenir de tout ça.";
			link.l1 = "Je le prends.";
			link.l1.go = "47";
		break;

		case "47":
			dialog.text = "Et reposez-vous. Passez me voir dans six semaines : il y a une affaire, mais ni vous ni moi ne devrions y toucher maintenant.";
			link.l1 = "Dans six semaines, donc.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
