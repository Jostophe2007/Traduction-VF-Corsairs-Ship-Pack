void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sTemp;
	bool bOk;
	ref shTo;
	string cnd;
	DeleteAttribute(&Dialog,"Links");
	int i;

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Quest_Whisper_1":
			dialog.text = "Bon, le travail n'est pas facile, mais le gros lot qu'on peut décrocher vaut le risque.";
			link.l1 = "דa, je l'avais deviné. Je veux les détails.";
			link.l1.go = "Quest_Whisper_2";
		break;

		case "Quest_Whisper_2":
			dialog.text = "Attends, on dirait que quelqu'un vient. Je vais fermer la porte à clé.";
			link.l1 = "...";
			link.l1.go = "Quest_Whisper_2_exit";
			pchar.WhisperPGG = npchar.id;
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);

			for (i = 1; i < 4; i++)
			{
				sld = GetCharacter(NPC_GenerateCharacter("PGG_Whisper_Incquisitor"+i, "PGG_Vincento_"+(2+i), "man", "man", sti(pchar.rank) + MOD_SKILL_ENEMY_RATE*3, PIRATE, 0, true));
				ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1_back");
				cnd = "l"+i;
				pchar.quest.QuestWhisper_RoomFight.win_condition.(cnd) = "NPC_Death";
				pchar.quest.QuestWhisper_RoomFight.win_condition.(cnd).character = sld.id;
				LAi_group_MoveCharacter(sld, "Quest_Whisper_Enemy");
			}
			pchar.quest.QuestWhisper_RoomFight.function = "QuestWhisper_RoomFight";
		break;

		case "Quest_Whisper_2_exit":
			DialogExit();
			sld = CharacterFromId("PGG_Whisper_Incquisitor3");
			sld.Dialog.Filename = "Quest\WhisperLine\Whisper_PGG.c";
			sld.dialog.currentnode   = "Quest_Whisper_3";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "Quest_Whisper_3":
			dialog.text = "On te tient, Whisper !";
			link.l1 = "...";
			link.l1.go = "Quest_Whisper_3_exit";
		break;

		case "Quest_Whisper_3_exit":
			DialogExit();
			sld = CharacterFromId(pchar.WhisperPGG);
			sld.Dialog.Filename = "Quest\WhisperLine\Whisper_PGG.c";
			sld.dialog.currentnode   = "Quest_Whisper_4";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "Quest_Whisper_4":
			dialog.text = "Bon sang ! C'est toi qui les as amenés ici pour avoir ma peau ?";
			link.l1 = "C'est la première fois que je vois ces types !";
			link.l1.go = "Quest_Whisper_4_exit";
		break;

		case "Quest_Whisper_4_exit":
			StartInstantDialog("PGG_Whisper_Incquisitor3", "Quest_Whisper_5", "Quest\WhisperLine\Whisper_PGG.c");
		break;

		case "Quest_Whisper_5":
			dialog.text = "Enfin, nous t'avons retrouvée, sorcière ! Maintenant, tu vas payer pour tes méfaits !";
			link.l1.go = "Quest_Whisper_5_exit";
		break;

		case "Quest_Whisper_5_exit":
			StartInstantDialog(pchar.WhisperPGG, "Quest_Whisper_6", "Quest\WhisperLine\Whisper_PGG.c");
		break;

		case "Quest_Whisper_6":
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			LAi_SetImmortal(npchar, true);
			dialog.text = "Ce que vous pouvez me fatiguer, à la fin !";
			link.l1.go = "Quest_Whisper_6_exit";
			pchar.WhisperId = npchar.id;
		break;

		case "Quest_Whisper_6_exit":
			npchar.dialog.CurrentNode = "Quest_Whisper_8";
			StartInstantDialog("PGG_Whisper_Incquisitor3", "Quest_Whisper_7", "Quest\WhisperLine\Whisper_PGG.c");
		break;

		case "Quest_Whisper_7":
			dialog.text = "Prépare-toi à aller en enfer avec ton âme damnée !";
			link.l1 = "Je n'avais pas envie de me mêler de vos histoires avec elle, mais « âme damnée », je trouve ça plutכt insultant.";
			link.l1.go = "Quest_Whisper_7_fight";
			link.l2 = "Et merde, je me tire !";
			link.l2.go = "Quest_Whisper_7_flee";
		break;
		case "Quest_Whisper_7_fight":
			sld = CharacterFromId(pchar.WhisperId);
			LAi_SetWarriorTypeNoGroup(sld);
			for (i = 1; i < 4; i++)
			{
				sld = CharacterFromId("PGG_Whisper_Incquisitor"+i);
				LAi_SetWarriorTypeNoGroup(sld);
			}

			DialogExit();
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "Quest_Whisper_7_flee":
			DialogExit();
			sld = CharacterFromId(pchar.WhisperId);
			DoReloadCharacterToLocation(sld.PGGAi.location.town + "_tavern","goto","goto1");
			chrDisableReloadToLocation = false;
		break;

		case "Quest_Whisper_8":
			if (HasSubStr(pchar.location,"upstairs"))
			{
				dialog.text = "דa va, tu es en vie ?";
				link.l1 = "Tout va bien. Dis-moi plutכt ce qui se passe ici, bon sang ?!";
				link.l1.go = "Quest_Whisper_9";
			}
			else
			{
				dialog.text = "Tu as le culot de revenir me voir après m'avoir laissée tomber ?! Je ne veux plus faire affaire avec toi.";
				link.l1 = "Eh bien, pas besoin !";
				link.l1.go = "Quest_Whisper_end";
			}
		break;

		case "Quest_Whisper_9":
			dialog.text = "Comme tu vois, je ne manque pas d'ennemis dans cet archipel. Toi aussi, tu en as, non ?";
			link.l1 = "Oui, mais pas de ce genre-là ! Comment as-tu fait pour te mettre l'Inquisition à dos ?";
			link.l1.go = "Quest_Whisper_10";
		break;

		case "Quest_Whisper_10":
			dialog.text = "C'est une longue histoire. Mais je peux te dire que l'Inquisition n'est pas qu'un ordre qui combat les hérétiques. En réalité, ils ne répugnent pas à se mêler de politique, et de manière générale, ils sont depuis longtemps embourbés dans la corruption et le mensonge. Ils ont le pouvoir d'accuser n'importe qui d'hérésie, de le brמler et de confisquer ses biens au profit de leur propre trésor, et ils ne se privent pas d'en user. Ils m'ont fait quelque chose de ce genre autrefois, mais j'ai réussi à m'échapper au dernier moment. Depuis, l'Inquisition me pourchasse.";
			link.l1 = "J'ai l'impression que tu ne me dis pas tout... Ce n'est pas que je défende l'Inquisition, mais tu as vraiment l'air d'une sorcière. Tu peux me raconter comment c'est arrivé ?";
			link.l1.go = "Quest_Whisper_11";
		break;

		case "Quest_Whisper_11":
			dialog.text = "Peut-être que je te le raconterai une autre fois, quand je te connaîtrai mieux. En attendant, parlons affaires. Tu veux gagner de l'argent, non ?";
			link.l1 = "Bon, raconte.";
			link.l1.go = "Quest_Whisper_12";
		break;

		case "Quest_Whisper_12":
			dialog.text = "Pour faire court, je te propose de piller ensemble une ville espagnole.";
			link.l1 = "דa a un rapport avec nos « invités » de tout à l'heure ?";
			link.l1.go = "Quest_Whisper_13";
		break;

		case "Quest_Whisper_13":
			dialog.text = "Ce n'est pas la première fois, et loin d'être la dernière, qu'ils viennent me chercher. Il faut en finir. Je vais frapper l'Inquisition là oם ça fait le plus mal : l'argent. Et de l'argent, ils en ont beaucoup. Des montagnes d'or confisquées pendant des années à des citoyens espagnols condamnés. Il y a un mois, je suis tombée sur une escadre de chasseurs tout juste équipée aux frais de ce trésor, et composée uniquement de vaisseaux de ligne. J'ai réussi à les repousser, mais ma fidèle corvette prenait l'eau, et j'ai dמ l'abandonner. Le navire que j'ai récupéré ensuite ne convient pas du tout au plan que j'ai en tête, alors j'aurai besoin de l'aide de quelqu'un comme toi.";
			link.l1 = "Alors, tu veux te venger d'eux... Et oם se trouve leur trésor ? א Santiago ?";
			link.l1.go = "Quest_Whisper_14";
		break;


		case "Quest_Whisper_14":
			dialog.text = "Oui. Là-bas, sous l'église, se trouve leur résidence principale dans les Caraïbes. S'y faufiler pour les dévaliser ne marchera pas : il y a là-dedans bien plus d'un coffre d'objets de valeur. Pour la même raison, nous ne pouvons pas attaquer la ville par la terre : nous n'aurions tout simplement pas le temps de tout emporter avant que les soldats du fort ne s'en aperçoivent. Non, il faudra prendre la ville par la mer, en détruisant d'abord le fort.";
			link.l1 = "N'est-ce pas un plan suicidaire ? Il y a sans doute des milliers de soldats dans la garnison du fort, et en plus, la ville est gardée par une escadre de navires de guerre. Quel que soit ce trésor, ça n'en vaut sמrement pas la peine.";
			link.l1.go = "Quest_Whisper_15";
		break;

		case "Quest_Whisper_15":
			dialog.text = "N'oublie pas : nous n'aurons pas seulement le trésor de l'Inquisition, mais aussi le butin du pillage de la ville. Et pour les défenses, je peux t'aider.";
			link.l1 = "Comment ça, m'aider ?";
			link.l1.go = "Quest_Whisper_16";
		break;

		case "Quest_Whisper_16":
			dialog.text = "Je sais comment pousser le gouverneur à faire sortir l'escadre et une partie des soldats du fort. Si tu lui chuchotes à l'oreille qu'on m'a vue à Puerto Príncipe, je ne doute pas qu'il enverra toutes ses forces pour m'attraper. Je suis recherchée sur cette île depuis longtemps.";
			link.l1 = "Tu crois qu'il va me croire comme ça, sur parole ?";
			link.l1.go = "Quest_Whisper_18";
		break;

		case "Quest_Whisper_18":
			dialog.text = "דa m'étonnerait. J'ai bien peur que tu doives d'abord lui rendre quelques services pour gagner ses bonnes grâces, et seulement ensuite lui raconter cette histoire.";
			link.l1 = "Plusieurs ?";
			link.l1.go = "Quest_Whisper_19";
		break;

		case "Quest_Whisper_19":
			dialog.text = "Je pense que trois suffiront à dissiper ses moindres doutes sur ta sincérité et ta bienveillance. Dès que ce sera fait, prépare-toi à prendre la mer et à donner immédiatement l'assaut au fort par tes propres moyens, car mon navire détournera l'escadre de garde.";
			link.l1 = "D'accord, j'en suis. Oם pourrai-je te trouver quand j'aurai fini de séduire le gouverneur ?";
			link.l1.go = "Quest_Whisper_20";
			link.l2 = "Tu sais, je n'ai pas envie de m'embarquer là-dedans. Je ne doute pas qu'après ça, l'Espagne mettra ma tête à prix.";
			link.l2.go = "Quest_Whisper_19_1";
		break;

		case "Quest_Whisper_19_1":
			dialog.text = "Tu ne changeras pas d'avis ? Je ne te reproposerai pas cette affaire. Mais si tu acceptes, rien ne presse : je comprends qu'il te faudra bien te préparer pour l'assaut.";
			link.l1 = "Certain.";
			link.l1.go = "Quest_Whisper_end";
			link.l2 = "D'accord, j'en suis. Oם pourrai-je te trouver quand j'aurai fini de séduire le gouverneur ?";
			link.l2.go = "Quest_Whisper_20";
		break;

		case "Quest_Whisper_20":
			dialog.text = "Ne t'en fais pas pour moi, je serai près de Cuba. Dès que tu auras fait ta part du plan, je te trouverai moi-même.";
			pchar.PGGWhisperLetter = true;
			link.l1 = "Eh bien, au travail.";
			link.l1.go = "Quest_Whisper_accept";
		break;

		case "Quest_Whisper_end":
			LocatorReloadEnterDisable("Santiago_Town", "basement1", false);
			npchar.dialog.filename = "PGG_dialog.c";
			npchar.dialog.currentnode = "First time";
			npchar.PGGWhisperQuestEnd = true;
			DialogExit();
			CloseQuestHeader("PGGWhisper");
			DeleteAttribute(npchar, "PGGAi.DontUpdate");
			DeleteAttribute(pchar, "PGGWhisperQuest");
			DeleteAttribute(pchar, "PGGWhisperLetter");
			DeleteAttribute(pchar, "PGGWhisperLetterSent");
			DeleteAttribute(pchar, "PGGWhisperLetterSentFail");
			DeleteAttribute( Colonies[FindColony("Santiago")], "DontSetShipInPort");
		break;

		case "Quest_Whisper_accept":
			npchar.PGGAi.DontUpdate = true;
			if (!CheckAttribute(pchar, "PGGWhisperQuest"))
			{
				SetQuestHeader("PGGWhisper");
				AddQuestRecord("PGGWhisper", "1");
				pchar.PGGWhisperQuest = true;
			}
			npchar.dialog.currentnode = "Quest_Whisper_report";
			if (CheckAttribute(NPChar, "payment") && npchar.payment == true)
			{
				CheckForReleaseOfficer(sti(npchar.index));
				RemovePassenger(pchar, npchar);
				RemoveCharacterCompanion(pchar, npchar);
				LAi_SetWarriorType(npchar);
				npchar.location = "none";
				npchar.PGGAi.location.town = PGG_TownForRelease(npchar);
				npchar.PGGAi.IsPGG = true;
				int n = 0;
				int aShips[SHIP_OCEAN];
				for (i = 0; i <= SHIP_OCEAN; i++)
				{
					if (CheckAttribute(&ShipsTypes[i], "Class") && sti(ShipsTypes[i].Class) == GetCharacterShipClass(PChar))
					{
						aShips[n] = i;
						n++;
					}
				}
				i = rand(n-1);
				int iType = aShips[i];
				PGG_DebugLog(npchar.id + " Changed ship");
				npchar.Ship.Type = GenerateShipExt(iType, rand(1), npchar);
				SetBaseShipData(npchar);
				if (!CheckAttribute(npchar, "Ship.Name")) SetRandomNameToShip(npchar);
				PGG_UpdateShipEquip(npchar);
				npchar.PGGAi.OwnShip = true;	
			}
			DialogExit();
		break;

		case "Quest_Whisper_report":
			dialog.text = "Encore toi ! Tu as d'autres questions ?";

			if (CheckAttribute(pchar, "PGGWhisperLetterSentFail"))
			{
				DeleteAttribute(pchar, "PGGWhisperLetterSentFail");
				link.l1 = link.l1 + " Mais il n'a pas voulu me croire. Pardon, ça n'a pas marché.";
				link.l1.go = "Quest_Whisper_report_fail";
				break;
			}

			link.l1 = "Non, je ne fais que passer.";
			link.l1.go = "Quest_Whisper_accept";
			link.l2 = "Oui. דa m'est sorti de la tête. Rappelle-moi, c'est quoi, notre affaire, à toi et moi ?";
			link.l2.go = "Quest_Whisper_report_1";
			link.l3 = "J'ai réfléchi... Ton affaire ne me plaît pas. Pardonne-moi, mais je passe mon tour.";
			link.l3.go = "Quest_Whisper_report_fail";
		break;

		case "Quest_Whisper_report_1":
			dialog.text = "Quoi ?! Tu te moques de moi ? Quand on a la tête sur les épaules, on note ce genre de choses dans son journal. Je vais faire comme si je n'avais pas entendu ta question.";
			link.l1 = "Je plaisante.";
			link.l1.go = "Quest_Whisper_accept";
		break;

		case "Quest_Whisper_report_fail":
			dialog.text = "Compris. On dirait que je vais devoir trouver un autre moyen. Merci de me l'avoir dit. Salut.";
			link.l1 = "Salut.";
			link.l1.go = "Quest_Whisper_end";
			//не забыть закрытие квеста
		break;
		case "Quest_Whisper_ToSiege":
			chrDisableReloadToLocation = false;
			dialog.text = "Les navires du port lèvent l'ancre, on dirait que notre plan fonctionne.";
			link.l1 = "Qu'est-ce que tu fais ici ? Ton navire n'est pas censé détourner l'escadre en ce moment ?";
			link.l1.go = "Quest_Whisper_ToSiege_1";
		break;
		case "Quest_Whisper_ToSiege_1":
			dialog.text = "Mon navigateur s'en chargera tout seul. Tu ne pensais quand même pas que j'allais te laisser tout le plaisir ?";
			link.l1 = "C'est quoi, cet équipement ? Je n'ai jamais rien vu de pareil.";
			link.l1.go = "Quest_Whisper_ToSiege_2";
		break;
		case "Quest_Whisper_ToSiege_2":
			dialog.text = "Et tu n'en verras sans doute nulle part ailleurs. Bon, assez bavardé. Allons à la chaloupe avant que les gardes me reconnaissent. J'espère que ton navire suffira pour prendre cette ville.";
			link.l1 = "Allons-y, on verra bien.";
			link.l1.go = "exit";
			LAi_LoginInCaptureTown(npchar, true);
			LAi_SetActorTypeNoGroup(npchar);
			LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			AddQuestRecord("PGGWhisper", "4");
		break;
		case "Quest_Whisper_AfterSiege":
			chrDisableReloadToLocation = false;
			LocatorReloadEnterDisable("Santiago_Town", "basement1", false);
			dialog.text = "On a réussi ! Reste le dernier effort : la résidence de l'Inquisition. L'entrée se trouve sous l'escalier de l'église. Entre dès que tu le peux. Si tu veux, tu peux d'abord aller voir le gouverneur, je t'attendrai.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollow(npchar, PChar, "", -1);

			PChar.quest.QuestWhisper_Incq.win_condition.l1 = "location";
			PChar.quest.QuestWhisper_Incq.win_condition.l1.location = "Santiago_Incquisitio";
			PChar.quest.QuestWhisper_Incq.function = "QuestWhisper_Incq";
		break;

		case "Quest_Whisper_Incq_fall":
			dialog.text = "Oh, j'ai la tête qui éclate... Je vois qu'on a gagné, finalement ?";
			link.l1 = "Tu as survécu ? Quand je t'ai vue tomber, j'ai craint le pire.";
			link.l1.go = "Quest_Whisper_Incq";
		break;

		case "Quest_Whisper_Incq":

			dialog.text = "Allez, leurs trésors doivent être quelque part par ici.";
			if (!CheckAttribute(npchar, "FailedRecruitment"))	dialog.text = "C'était bien plus facile que je ne le pensais. " + dialog.text;
			link.l1 = "D'accord, mais reprenons un peu notre souffle.";
			link.l1.go = "exit";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorFollow(npchar, PChar, "", -1);

			PChar.quest.QuestWhisper_Incq_4.win_condition.l1 = "locator";
			PChar.quest.QuestWhisper_Incq_4.win_condition.l1.location = "Santiago_Incquisitio";
			PChar.quest.QuestWhisper_Incq_4.win_condition.l1.locator_group = "box";
			PChar.quest.QuestWhisper_Incq_4.win_condition.l1.locator = "box2";
			PChar.quest.QuestWhisper_Incq_4.function = "QuestWhisper_Incq_4";

			ref _location = &locations[reload_location_index];
			_location.box2.money = 50000;
			_location.box2.items.icollection = 1;
			_location.box2.items.chest = 3;
			_location.box2.items.jewelry1 = 20+rand(5);
			_location.box2.items.jewelry2 = 20+rand(5);
			_location.box2.items.jewelry3 = 20+rand(5);
			_location.box2.items.jewelry4 = 11+rand(5);
			_location.box2.items.BackPack3 = 1;
			ChangeItemName("DeSouzaCross", "itmname_DeSouzaCross_DH");
		break;

		case "Quest_Whisper_Incq_1":
			dialog.text = "Bon sang !! Oם est mon fusil ?! Il devait être ici !";
			link.l1 = "Un fusil ? Je ne sais pas, je n'ai rien vu de tel. Mais regarde-moi ce tas d'objets précieux !";
			link.l1.go = "Quest_Whisper_Incq_2";
		break;

		case "Quest_Whisper_Incq_2":
			dialog.text = "Je me fiche d'eux. Ce qui m'intéresse, ce sont les armes qu'on m'a prises ici lors de ma précédente « visite ». Et puis, il devrait y avoir bien plus d'objets de valeur. Il n'y avait pas assez d'inquisiteurs ici non plus. Et parmi ceux qui étaient là, aucun des plus influents. Bon sang, quelque chose m'a échappé ! L'Inquisition doit avoir une autre résidence dont je n'ai pas entendu parler.";
			link.l1 = "Peut-être, mais le butin me convient. Comment on le partage ?";
			link.l1.go = "Quest_Whisper_Incq_3";
		break;

		case "Quest_Whisper_Incq_3":
			dialog.text = "Tu peux tout garder pour toi : après tout, c'est toi qui as fait le travail. Et le butin du pillage de la ville aussi. Je suis venue ici pour me débarrasser d'un vieil ennemi agaçant et récupérer mon fusil, pas pour cette poignée de pièces tachées de sang.";
			link.l1 = "Tu parles sérieusement ? Elle est plutכt grosse, ta poignée, tu sais.";
			link.l1.go = "Quest_Whisper_Incq_4";
		break;

		case "Quest_Whisper_Incq_4":
			dialog.text = "Ne nous attardons pas. Les forces espagnoles restantes peuvent revenir en ville à tout moment.";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "Quest_Whisper_Incq_5";
		break;

		case "Quest_Whisper_Incq_5":
			AddQuestRecord("PGGWhisper", "5");
			DialogExit();
			LAi_SetPlayerType(pchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
			chrDisableReloadToLocation = false;

			PChar.quest.QuestWhisper_Incq_5.win_condition.l1 = "location";
			PChar.quest.QuestWhisper_Incq_5.win_condition.l1.location = "Santiago_Town";
			PChar.quest.QuestWhisper_Incq_5.function = "QuestWhisper_Incq_5";
		break;

		case "Quest_Whisper_Finish":
			pchar.PGGWhisperComplete = true;
			DeleteAttribute(npchar, "PGGAi.DontUpdate");
			CloseQuestHeader("PGGWhisper");
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "LockMapReload");
			DeleteAttribute(pchar, "PGGWhisperLetter");
			DeleteAttribute(pchar, "PGGWhisperLetterSent");
			DeleteAttribute( Colonies[FindColony("Santiago")], "DontSetShipInPort");

			dialog.text = "Mon navire est déjà dans le port. Je ne sais pas combien de temps les Espagnols mettront à le suivre, mais je ne vais pas attendre pour le savoir. Je ne te conseille pas de rester ici non plus.";
			link.l1 = "Eh bien, adieu.";
			link.l1.go = "Quest_Whisper_Finish_NoHire";
			link.l2 = "Les Espagnols, l'Inquisition... Maintenant, tes ennemis sont aussi les miens. Et si on s'associait pour continuer à les combattre ensemble ? Qui sait, on finira peut-être par avoir la peau de l'Inquisition...";
			link.l2.go = "Quest_Whisper_Finish_Hire";
		break;

		case "Quest_Whisper_Finish_NoHire":
			npchar.dialog.filename = "PGG_dialog.c";
			npchar.dialog.currentnode = "First time";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			DialogExit();
		break;

		case "Quest_Whisper_Finish_Hire_1":
			npchar.dialog.filename = "Enc_Officer_dialog.c";
			npchar.dialog.currentnode = "hired";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			DialogExit();
		break;

		case "Quest_Whisper_Finish_Hire":
			if (CheckAttribute(npchar, "FailedRecruitment"))
			{
				dialog.text = "Désolée, mais je crois que je serai plus en sécurité seule.";
				link.l1 = "Comme tu voudras.";
				link.l1.go = "Quest_Whisper_Finish_NoHire";
			}
			else
			{
				if (SetCompanionIndex(pchar, -1, sti(NPChar.index)) != -1)
				{
					Dialog.Text = NPCharRepPhrase(NPChar, RandSwear() +
							RandPhraseSimple("Offre tentante ! Bien ! Je te tiens compagnie !", "Toi, tu ne manques pas de flair, capitaine... Je crois qu'on va bien travailler ensemble !"),
							LinkRandPhrase("Votre proposition me plaît. J'accepte.",
							"Eh bien... Moi aussi, je pense qu'ensemble, on peut faire plus !", "דa pourrait être amusant. Marché conclu."));
					link.l1 = RandPhraseSimple("Parfait, je vous attends en mer !", "C'est dit ! Nous allons faire une sacrée équipe.");
					link.l1.go = "Quest_Whisper_Finish_Hire_1";

					if (CheckAttribute(NPChar, "PGGAi.Task.SetSail"))
					{
						PGG_Disband_Fleet(npchar);
					}

					NPChar.PGGAi.IsPGG = false;
					NPChar.PGGAi.location.town = "none";
					if (NPChar.model.animation == "man" || NPChar.model.animation == "YokoDias" || NPChar.model.animation == "Milenace") Npchar.CanTakeMushket = true;
					if(npchar.model == "PGG_Whisper_6") EquipCharacterByItem(NPChar, "suit_1");
					NPChar.Payment = true;
					NPChar.Money   = 0;
					SetBaseShipData(NPChar);

					DeleteAttribute(NPChar,"ship.sails");
					RepairMasts(NPChar);
					DeleteAttribute(NPChar,"ship.blots");

					Fantom_SetCannons(NPChar, "pirate");
					Fantom_SetBalls(NPChar, "pirate");

					DeleteAttribute(NPChar, "PGGAi.Task");
					DeleteAttribute(NPChar, "PGGAi.LockService");
					SetCharacterRemovable(NPChar, true);
					SaveCurrentNpcQuestDateParam(NPChar, "Companion.CheckRelation");

					NPChar.HalfImmortal = true;  // Контузия
					NPChar.OfficerWantToGo.DontGo = true; //не пытаться уйти
					NPChar.loyality = MAX_LOYALITY;

					LAi_SetActorTypeNoGroup(npchar);
					LAi_ActorFollow(npchar, PChar, "", -1);
				}
				else
				{
					Dialog.Text = RandPhraseSimple("On dirait que tu as déjà assez de compagnons.", "Tu as déjà tant de navires. Pourquoi en voudrais-tu un de plus ?");
					link.l1 = "Oui... Je crois que tu as raison.";
					link.l1.go = "Quest_Whisper_Finish_NoHire";
				}
			}
		break;
	}
}
