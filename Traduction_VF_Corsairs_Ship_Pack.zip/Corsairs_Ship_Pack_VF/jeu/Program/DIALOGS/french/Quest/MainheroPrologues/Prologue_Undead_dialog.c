void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	ref _location;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
		break;

		case "Gravedigger":
			dialog.text = GetSexPhrase("Il", "Elle")+" bouge !!! Sainte Vierge, pitié !";
			link.l1 = "DES CERVEAUX !!!";
			link.l1.go = "exit_fight";
			
			//	Здесь прописываем каюты, где появится письмо =====>			
			PChar.quest.UP_KrovPismo1.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo1.win_condition.l1.location = "My_Cabin_Small";
			PChar.quest.UP_KrovPismo1.win_condition = "UP_KrovPismo";

			PChar.quest.UP_KrovPismo2.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo2.win_condition.l1.location = "My_Cabin_Small2";
			PChar.quest.UP_KrovPismo2.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo3.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo3.win_condition.l1.location = "My_Cabin_Medium";
			PChar.quest.UP_KrovPismo3.win_condition = "UP_KrovPismo";

			PChar.quest.UP_KrovPismo4.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo4.win_condition.l1.location = "My_Cabin_Medium1";
			PChar.quest.UP_KrovPismo4.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo5.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo5.win_condition.l1.location = "My_Cabin_Medium2";
			PChar.quest.UP_KrovPismo5.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo6.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo6.win_condition.l1.location = "My_New_Cabin1";
			PChar.quest.UP_KrovPismo6.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo7.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo7.win_condition.l1.location = "My_New_Cabin2";
			PChar.quest.UP_KrovPismo7.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo8.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo8.win_condition.l1.location = "My_New_Cabin3";
			PChar.quest.UP_KrovPismo8.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo9.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo9.win_condition.l1.location = "My_Cabin_Huge";
			PChar.quest.UP_KrovPismo9.win_condition = "UP_KrovPismo";
			
			PChar.quest.UP_KrovPismo10.win_condition.l1 = "location";
			PChar.quest.UP_KrovPismo10.win_condition.l1.location = "My_Cabin_Quest";
			PChar.quest.UP_KrovPismo10.win_condition = "UP_KrovPismo";			
			//	<===== Здесь прописываем каюты, где появится письмо
			
			//	Читаем письмо
			PChar.quest.UP_DrugPridet.win_condition.l1 = "item";
			PChar.quest.UP_DrugPridet.win_condition.l1.item = "UP_PismoZagadka";
			PChar.quest.UP_DrugPridet.win_condition = "UP_DrugPridet";
		break;

		case "DeadmansGod":
			dialog.text = "Sais-tu qui je suis ?";
			link.l1 = "La Mort.";
			link.l1.go = "DeadmansGod_1";
			LAi_CharacterPlaySoundAtOnce(NPChar, "DeadmansGod_0");
		break;
		case "DeadmansGod_1":
			dialog.text = "Je suis l'équilibre ! Je sépare les âmes de la chair et je veille à l'équilibre entre le monde des vivants et celui des morts. Tout ce qui vit passera devant mon tribunal. Tu es l'accusé.";
			link.l1 = "Je me souviens... La vie... C'est un autre dieu qui doit me juger. Pas toi !";
			link.l1.go = "DeadmansGod_2";
			LAi_CharacterPlaySoundAtOnce(NPChar, "DeadmansGod_1");
		break;
		case "DeadmansGod_2":
			dialog.text = "La mort t'a surpris loin des lieux oם ton dieu est puissant. Et qu'en a-t-il à faire de vous autres, cupides, vicieux, mécréants ?";
			link.l1 = "Laisse-moi...";
			link.l1.go = "DeadmansGod_3";
			LAi_CharacterPlaySoundAtOnce(NPChar, "DeadmansGod_2");
		break;
		case "DeadmansGod_3":
			dialog.text = "SILENCE ! Tu ne mérites ni repos ni châtiment. Tes ancêtres ne sont pas ici, et ton dieu est impuissant ici : il n'y a de place ni pour ton âme ni pour tes cendres.\n Je pourrais effacer ce qui reste de toi des réalités et des probabilités ! Facilement ! Même si je suis un juge impartial, je ne refuse pas de jouer avec l'esclave d'un dieu étranger. Je vais prendre ta mort et te donner en échange la NON-VIE.\n Il y en a d'autres comme toi, et ils se sont éveillés. Et ce qu'il en adviendra... hum... J'espère que ce ne sera pas ennuyeux. Tu entends ces coups ? Ces imbéciles brisent le couvercle de ton cercueil. Va, avant que je change d'avis !";
			link.l1 = "...";
			link.l1.go = "DeadmansGod_4";
			LAi_CharacterPlaySoundAtOnce(NPChar, "DeadmansGod_3");
		break;
		case "DeadmansGod_4":
			DialogExit();
			DoReloadCharacterToLocation("Common_CryptBig2", "goto", "goto9");
			PlaySound("interface\grob.waw");
			DoQuestFunctionDelay("Undead_Start_Graveyard", 0.1);
			DoQuestFunctionDelay("Undead_Start_Graveyard_1", 1.0);
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			LAi_SetWarriorType(NPChar);
			LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			LAi_SetImmortal(npchar, false);
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DialogExit();
		break;
		
		case "PGG_Undead_1":
			dialog.text = "(incantation) Armenamo -- delcamano -- MRISTO !";
			link.l1 = "Euh, qui es-tu, et comment es-tu arrivé ici ?";
			link.l1.go = "PGG_Undead_2";
		break;
		
		case "PGG_Undead_2":
			dialog.text = "Des forces d'outre-monde nous appellent. Tu n'entends pas leur appel ?";
			link.l1 = "J'ai cessé d'entendre des voix depuis longtemps, maintenant je m'occupe de mes affaires.";
			link.l1.go = "PGG_Undead_3";
		break;
		
		case "PGG_Undead_3":
			dialog.text = "Je suis ici pour une raison. וcoute, nous n'avons pas beaucoup de temps. Si nous n'accédons pas à sa demande, même nos derniers os se dissoudront sous son influence. Il est puissant et très autoritaire. Je ne sais même pas comment le décrire. Il n'y a jamais eu une telle puissance dans notre monde. Je n'ai pas le temps de t'expliquer les détails, tu dois bien te préparer pour ma prochaine visite. Je ne peux pas le contrכler, c'est lui qui me dirige vers toi. Il te faut simplement deux fois plus d'expérience que maintenant. א bientכt, mon camarade d'os...";
			link.l1 = "Quoi ? Hé, attends ! Oם vas-tu ?";
			link.l1.go = "PGG_Undead_4";
		break;
		
		case "PGG_Undead_4":
			DialogExit();
			sld = CharacterFromID("PGG_Undead")
			LAi_ActorGoToLocation(sld, "reload", "reload1", "none", "", "", "UD_DrugUshel", -1);
			pchar.questTemp.UndeadPrologue3 = "UP3";
		break;
		
		case "PGG_Undead_5":
			dialog.text = "Dépêche-toi, il arrive !";
			link.l1 = "Encore toi, qu'est-ce qu'il y a ? Raconte-moi tout, sinon nos os vont s'éparpiller dans toute la ville !";
			link.l1.go = "PGG_Undead_6";
			TakeItemFromCharacter(pchar, "UP_PismoZagadka");
		break;
		
		case "PGG_Undead_6":
			dialog.text = "Le moment est venu ! Sa force et sa puissance se jouent de moi. Je ne suis plus moi-même. Nous devons trouver notre maître ! Il règne sur nous tous, même sur les dieux de ce monde ! Il me semble qu'il ne reculera devant rien. Allez, il faut le trouver, vite !";
			link.l1 = "Tu peux expliquer le problème normalement ? Quoi ? Qui ! Pourquoi ? Quel autre maître ? Mon maître, c'est Mictlantecuhtli. C'est le seul à qui je puisse obéir, pour l'instant.";
			link.l1.go = "PGG_Undead_7";
		break;
		
		case "PGG_Undead_7":
			dialog.text = "Mon but était de te mener à lui. Mais ce n'est pas si simple : au début, je l'avais, mais ensuite, on me l'a enlevé, vivant. Je n'ai rien pu faire d'autre que me cacher. Pardonne-moi, mon seigneur... Oh non, mon seigneur, tu n'es pas... ! Je m'embrouille ! Lil... Lila... דa y est, la douleur me tente ! Je ne peux pas m'en sortir... ! Aide-moi, je t'en prie !";
			link.l1 = "Au travail ! Qu'est-ce qui te retient autant, camarade d'os ? Allez, calme-toi et raconte-moi plus en détail : que devons-nous faire ? Je t'aiderai, je te le promets !";
			link.l1.go = "PGG_Undead_7_1";
		break;
		
		case "PGG_Undead_7_1":
			dialog.text = "D'accord. Il y a un... très inhabituel... Le sujet, je... je... je ne peux pas l'appeler par son nom, pardonne-moi... Il suffit de le trouver, ensuite tu comprendras et tu verras par toi-même. Il suffit de prendre le large, et il t'amènera lui-même des vivants. Prépare-toi simplement bien. Même s'Il est contre les vivants, il leur donne quand même de la force.";
			link.l1 = "... ... Je... Je... Je n'ai pas de mots. Bon, rassemble tes os, allons-y. J'espère que je saurai démêler tout ça.";
			link.l1.go = "PGG_Undead_8";
		break;
		
		case "PGG_Undead_8":
			dialog.text = "Ramasse d'autres de nos osselets dans les grottes et les souterrains. Il peut y avoir beaucoup de vivants, et ils sont tous sous son influence.";
			link.l1 = "Compris. Et toi, oם vas-tu ? Tu viens parcourir l'archipel avec moi ? Qu'est-ce que tu es, sinon un indigène ?";
			link.l1.go = "PGG_Undead_9";
		break;
		
		case "PGG_Undead_9":
			dialog.text = "Oui ? Alors je serai heureux de me joindre à toi. Espérons qu'ensemble, nous pourrons tenir tête à lui et à tous les vivants.";
			link.l1 = "C'est de la folie. Je suis dans le pétrin. Je voulais commencer une nouvelle vie ici, honorer les dieux. Bon, voyons ce qui nous attend.";
			link.l1.go = "PGG_Undead_10";
		break;
		
		case "PGG_Undead_10":
			DialogExit();
			
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "", "", "", "", -1);
			DoQuestCheckDelay("UD_DrugUshel_2", 1.5);
			
			sld = CharacterFromID("PGG_Undead");
			sld.name = "Terrible";
			sld.lastname = "";
			sld.FaceId = 537;
			SetSPECIAL(sld, 8, 10, 8, 3, 8, 10, 8);
			GiveItem2Character(sld, "mushket");
			SetCharacterPerk(sld, "BasicDefense");
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "Gunman");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "Energaiser");
			AddItems(sld, "bullet", 20);
			AddItems(sld, "GunPowder", 20);
			LAi_SetHP(sld, 180.0, 180.0);
			AddPassenger(pchar, sld, false);
			SetCharacterRemovable(sld, true);
			sld.HalfImmortal = true;
			sld.loyality = MAX_LOYALITY;
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			sld.OfficerWantToGo.DontGo = true;
		break;
	}
}
