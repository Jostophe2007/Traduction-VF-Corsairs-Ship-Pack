// Gregg: Алехон Кендарт - «Чёрная Орхидея», глава 6 «Испанская щедрость» (перенос из К:ПС).
// Логика - Program\Quests\reaction_functions\blackorchid.c
// Оригинал реплик - DamnedDestiny\Alehon Kendart.c, ветка SpanishGenerosity_1..55.
//   1-16  - комната наверху в таверне Ле-Франсуа: план, брат, отдача Орхидеи;
//   20-21 - копия готова, подделка на руки;
//   25    - после сделки: спрятать подделку в гроте Доминики;
//   30-34 - ратуша Сан-Хуана: колония наша, денег нет, эскадра на подходе;
//   40-42 - после победы, вход в главы 7-9.
//
// Gregg: ОТСТУПЛЕНИЯ ОТ ОРИГИНАЛА.
// 1. Испанцам уходит ПОДДЕЛКА. В К:ПС Кендарт срезал настоящей Орхидее срок действия
//    до трёх суток и продавал её - у нас Орхидея вечный оберег, срезать нечего.
// 2. Мотив выдан не одной репликой в узле 9, как в оригинале, а собран: зацепку про
//    взятого вместо него человека Кендарт роняет ещё в гроте Теркса (BO_Kendart.c, 6a-6b),
//    здесь она досказывается. И игрок предъявляет ему его же слова из узла 7 главы 5.
// 3. «Все испанцы такие» из оригинала (узел 10) переписано: учёный, который делает
//    выводы по опросу на улице, - слабое место оригинала. Отвечает жёстче и точнее.
// 4. Про уничтожение Орхидеи Кендарт больше не заговаривает: мотив исчерпан.
// 5. Балаган про гарем (узлы 15-18 оригинала) выброшен - он ломает сцену, в которой
//    человек только что рассказал, как пытали его брата.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name;


	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Allez, " + sName + ". Chacun de nous a du travail.";
			link.l1 = "Portez-vous bien, Alejon.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Asseyez-vous, " + sName + ". J'ai entendu dire que l'Espagne vous offrait de l'argent pour l'Orchidée. C'est vrai ?";
			link.l1 = "Oui. Cinq millions, puis dix. J'ai refusé. Comment le savez-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "J'écoute les Caraïbes plus attentivement qu'il n'y paraît. Donc : je veux que vous acceptiez.";
			link.l1 = "...(lentement)... Accepter de vendre l'Orchidée. א l'Espagne.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "C'est ça.";
			link.l1 = "Alejon, dans la grotte des îles Turques, vous m'avez dit mot pour mot : « Tout ça pour que l'Orchidée vous revienne, à vous, et non à l'Espagne. » Ce sont vos mots. Je m'en souviens bien.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "...(sans la moindre gêne)... Ce sont les miens. Et je ne les retire pas. L'Espagne n'aura pas l'Orchidée noire.";
			link.l1 = "Alors qu'aura-t-elle pour ses millions ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Une copie. La même pierre noire, la même monture, le même poids : l'œil ne les distinguera pas. Elle ne gardera aucune chaleur ; la chaleur dépasse mon art. J'ai passé vingt ans à rendre l'Orchidée impuissante : je peux fabriquer une chose vide en six semaines.";
			link.l1 = "Et ils prendront un caillou ramassé dans la rue pour le plus grand artefact des Caraïbes ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Oui. Vous, vous l'avez tenue, et vous savez qu'elle réchauffe la main ; à Madrid, on ne la connaît que par des papiers et des ouï-dire. Et souvenez-vous de ce qu'on vous a dit de l'Orchidée pendant tous ces mois : son pouvoir ne vient pas tout de suite à son possesseur. C'est vrai, et c'est ce qui rend toute vérification impossible. Alboretto le croit lui-même : ce n'est pas un escroc, c'est un messager.";
			link.l1 = "Très bien. Alors, une autre question. Vous n'avez pas besoin d'argent, Alejon ; vous avez vécu vingt ans dans un trou avec une pierre dans votre poche. Pourquoi voulez-vous cela ?";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "...(un long silence)... Vous vous souvenez de ce que je vous ai dit dans la grotte ? Qu'on avait pris un homme qui n'avait jamais entendu parler de l'Orchidée.";
			link.l1 = "Je m'en souviens. Vous ne m'avez pas tout dit.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "C'était mon frère. On ne le traquait pas pour l'Orchidée : on le traquait pour savoir oם j'étais. Il ne le savait pas. Il n'avait rien à leur dire. Ils l'ont torturé pendant quatre jours.";
			link.l1 = "Qui ça ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Des hommes munis d'un mandat de la Couronne espagnole. C'est alors que je suis parti dans la grotte, et que j'ai compris qu'il ne fallait pas cacher l'Orchidée, mais la défaire. Pendant vingt ans, j'ai cru que cela suffirait.";
			link.l1 = "Tous les Espagnols ne sont pas comme ça, Alejon.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "Pas tous. Et je n'ai pas l'intention de noyer les pêcheurs de Santiago. Mais ce ne sont pas des pêcheurs qui ont donné l'ordre, et ce n'est pas un pêcheur qui paiera. C'est la Couronne qui paiera : en argent, et en colonie.";
			link.l1 = "Une colonie ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Demandez San Juan en échange de l'Orchidée. Et vingt-cinq millions en plus. L'Espagne paiera : ils sont certains de reprendre la ville dans le mois, avec l'Orchidée en main.";
			link.l1 = "Alors que ce qu'ils auront en main, c'est un caillou qui vaut trois pesos.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Exactement. Ils devront reprendre la ville avec ce qu'ils ont, et non avec ce qu'ils ont acheté.";
			link.l1 = "Pourquoi San Juan ? Il y a des colonies plus riches dans les Caraïbes.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Parce qu'elle est à l'écart, qu'elle a un bon fort et un port profond. Et parce que de là, je pourrai continuer à travailler sans regarder par-dessus mon épaule. J'ai besoin d'un coin à moi, " + sName + ", et vous, vous avez besoin d'une base.";
			link.l1 = "Et c'est moi qui devrai repousser la flotte espagnole.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Oui. Alors, le moment venu, vous devrez avoir un navire capable de tenir tête à un vaisseau de ligne. Je vous laisserai tout le temps qu'il faudra. Mieux vaut tard qu'en sloop.";
			link.l1 = "Et une garnison ? Nous ne tiendrons pas une ville vide une semaine.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Il y aura une garnison, un gouverneur et deux navires dans le port. C'est ma part du travail, et elle est déjà à moitié faite.";
			link.l1 = "Bien. De quoi avez-vous besoin de ma part, maintenant ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "De l'Orchidée. Pendant six semaines. On ne peut pas faire une copie sans avoir l'original sous les yeux.";
			link.l1 = "...(retirant l'Orchidée)... Six semaines sans elle. Retenez bien ceci, Alejon : si vous disparaissez avec, je vous retrouverai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityFirstTimer");
		break;

		case "20":
			dialog.text = "C'est fait, " + sName + ". Les voici toutes les deux. Pouvez-vous dire laquelle est la vraie ?";
			link.l1 = "...(retournant les deux pierres)... Non.";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Moi non plus, si je ne l'avais pas marquée. Celle-ci, avec l'égratignure sur la tige, est la vכtre. Mettez-la et ne l'enlevez pas. Apportez l'autre à Alboretto, à Santiago, et annoncez le prix : San Juan et vingt-cinq millions. Pas un peso de moins.";
			link.l1 = "Et s'il refuse ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Il ne refusera pas. Il a déjà doublé le prix deux fois de lui-même. Il a l'ordre de rapporter l'Orchidée à n'importe quel prix, et il le sait.";
			link.l1 = "Alors j'y vais.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityGetFake");
		break;

		case "25":
			dialog.text = "J'ai entendu dire qu'on vous avait compté votre acompte. L'affaire avance donc.";
			link.l1 = "Un million. Le reste, ils le promettent par virement. Et maintenant ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Maintenant, une cache. Ils ont cédé la ville, mais ils n'auront pas la pierre de la main à la main : Alboretto n'apprendra l'emplacement qu'une fois sa garnison débarquée à La Havane. Portez la contrefaçon dans la grotte de la Dominique et laissez-la dans le coffre.";
			link.l1 = "Pourquoi tant de précautions, si San Juan est déjà à nous ?";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Parce que la contrefaçon sera découverte tכt ou tard, et qu'à ce moment-là, je veux qu'une mer nous sépare de leurs soldats. Allez, " + sName + ". Et revenez au François.";
			link.l1 = "Très bien, Alejon.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityToGrot");
		break;

		case "30":
			dialog.text = "San Juan est à nous, " + sName + ". Entièrement et sans partage. Je ne pensais pas vivre assez longtemps pour voir ça.";
			link.l1 = "Et l'argent ? Les vingt-cinq millions sont arrivés ?";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "...(avec une grimace)... Le million de l'acompte, c'est tout ce que nous verrons. Le virement a été annulé il y a trois jours. Quelqu'un à Séville a eu l'idée de montrer la pierre à un homme qui avait tenu l'Orchidée entre ses mains.";
			link.l1 = "Donc, la copie a été découverte. Et vite.";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "Plus vite que je ne l'avais calculé. Je l'avoue : c'est mon erreur, et sans doute pas la dernière. Mais on ne nous reprendra pas la colonie d'un trait de plume. Il faudra la reprendre avec une flotte.";
			link.l1 = "Et la flotte, je suppose, a déjà appareillé.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "L'escadre de l'amiral Merkes. Quatre flammes : le vaisseau de ligne Altea, les vaisseaux Aheldio et Escolta, et l'Andromeda d'Alboretto : on l'a envoyé avec eux pour qu'il contemple son œuvre. Ils seront là d'un jour à l'autre.";
			link.l1 = "Et moi, de quoi je dispose ?";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Le vaisseau de ligne dans le port est celui de Cristobal Kuvalda. Il dit que vous vous connaissez : que vous vous êtes battus cכte à cכte au village des pêcheurs de perles, contre Feregueyro.";
			link.l1 = "C'est vrai. א l'époque non plus, il n'avait pas demandé dans quoi il s'embarquait. Oם a-t-il trouvé un vaisseau de ligne ?";
			link.l1.go = "34a";
		break;

		case "34a":
			dialog.text = "Il l'a pris. א qui, je ne l'ai pas demandé, et il ne l'a pas dit. Nous devons à Cristobal plus qu'un navire : sa parole compte dans la Confrérie de la Cכte, et c'est lui qui a proposé San Juan aux corsaires comme nouvelle base. La moitié de la garnison de la ville, ce sont ses hommes.";
			link.l1 = "Donc, la ville est tenue par des pirates qu'il a rassemblés. Et si demain, celui qui commande ici ne leur plaît plus ?";
			link.l1.go = "34b";
		break;

		case "34b":
			dialog.text = "S'il ne leur plaît plus, vous vous en occuperez. Mais j'ai fait courir le bruit que vous portiez l'Orchidée noire et que vous en aviez hérité une part. Au port, on y croit. Le second capitaine est Roger Belami, du vaisseau Reginald, un homme de Kuvalda. Tous les deux sont sous vos ordres pour la bataille.";
			link.l1 = "דa suffira. Y a-t-il autre chose que je devrais savoir ?";
			link.l1.go = "34c";
		break;

		case "34c":
			dialog.text = "Une chose. Le trésor de l'escadre se trouve dans la cale de l'Altea. Prenez le navire amiral à l'abordage, et nous récupérerons au moins une partie de ce qu'on ne nous a pas payé.";
			link.l1 = "Et si je ne le prends pas ?";
			link.l1.go = "35";
		break;

		case "35":
			dialog.text = "Alors il coulera avec lui. Ne risquez pas un navire pour de l'argent, " + sName + ". La ville compte davantage.";
			link.l1 = "Compris. Je vais me préparer.";
			AddDialogExitQuestFunction("SpanishGenerosityToFinal");
			link.l1.go = "exit";
		break;

		case "40":
			dialog.text = "L'escadre de l'amiral Merkes n'est plus, " + sName + ". Vous avez réussi.";
			link.l1 = "Nous avons réussi. Et maintenant, qu'en est-il de l'Orchidée, Alejon ?";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Rien. Elle est à vous, et qu'elle y reste. J'ai passé vingt ans à lui retirer son pouvoir pour la donner à quelqu'un qui n'en ferait pas commerce. Aujourd'hui, je l'ai trouvé.";
			link.l1 = "Vous regrettiez pourtant de ne pas avoir pu la détruire.";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "C'est vrai. Et maintenant, je pense que ce n'était pas nécessaire : ce qu'il en reste ne fera de personne un assassin. Reposez-vous, " + sName + ". Dans un mois ou deux, passez à l'hכtel de ville : j'aurai pour vous une conversation bien plus intéressante que celle-ci.";
			link.l1 = "J'y passerai, Alejon.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SpanishGenerosityHappyEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
