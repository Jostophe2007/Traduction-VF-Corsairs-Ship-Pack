// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions, "+ GetSexPhrase("mon fils", "ma fille") +" ?", "Demandez, je vous écoute..."), "Je vous écoute, parlez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "Et pour la troisième fois, je vous le dis, "+ GetSexPhrase("mon fils", "ma fille") +" : posez votre question.",
                          "Un homme d'וglise a tant de responsabilités, et voilà que vous me dérangez, "+ GetSexPhrase("mon fils", "ma fille") +"...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Pas maintenant, padre..."), "Oui, je n'ai pas grand-chose à dire pour l'instant...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Excusez-moi, saint père...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "MorrisWillams_ArrestedSeekInfo" || pchar.questTemp.State == "MorrisWillams_ArrestedSeekInfoFather")
            {
                link.l1 = "Saint père, dites-moi, l'usurier d'ici fait-il partie de vos paroissiens ?";
                link.l1.go = "Step_E6_1";
            }
		break;
		
        case "Step_E6_1":
			dialog.text = "Oui, il fréquente l'église, mais très rarement.";
			link.l1 = "Quel genre d'homme est-ce ?";
			link.l1.go = "Step_E6_2";
		break;

        case "Step_E6_2":
			dialog.text = "Il m'est difficile de dire du mal des gens\n"+
                          "Je vous conseillerais de vous adresser à l'une de nos paroissiennes, Gillian Atterbury. Je sais qu'elle a de sérieux problèmes avec cet homme. Vous pourrez peut-être même l'aider d'une manière ou d'une autre\n"+
                          "Gillian est une bonne paroissienne : en général, elle vient à l'église chaque jour à partir de onze heures du matin et prie pendant deux ou trois heures\n"+
                          "Sinon, vous pouvez la croiser en ville.";
			link.l1 = "Merci, saint père.";
			link.l1.go = "exit";
			pchar.questTemp.State = "MorrisWillams_ArrestedSeekInfoWomen";
			AddQuestRecord("Eng_Line_6_MorrisWillams", "19");
			AddQuestUserData("Eng_Line_6_MorrisWillams", "sSex", GetSexPhrase("", "e"));
            ref sld = GetCharacter(NPC_GenerateCharacter("Gillian Atterbury", "girl_8", "woman", "towngirl", 5, ENGLAND, 100, false));
        	sld.name 	= "Gillian";
        	sld.lastname = "Atterbury";
        	LAi_SetCitizenType(sld);
            sld.Dialog.Filename = "Quest\EngLineNpc_2.c";
            LAi_group_MoveCharacter(sld, "ENGLAND_CITIZENS");
           	ChangeCharacterAddressGroup(sld, "PortRoyal_town", "goto", "goto1");
			LAi_SetFanatic(sld, "PortRoyal_church", "sit", "sit1", 11.0, 14.0);
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

