// The Company's factor - meeting him in person before the voyage to Fort Orange, the Jamaica office quest (Gregg)

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (CheckAttribute(pchar, "GWIK.Jamaica.FactorAboard")) // already agreed - he is "taking his things to the pier"
			{
				dialog.text = "On porte déjà mes coffres au quai, capitaine. א bientכt à bord.";
				link.l1 = "א bientכt à bord.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Capitaine "+ GetFullName(pchar) +" ? Enfin ! "+ GetFullName(NPChar) +", agent de la Compagnie, à votre service : c'est moi que vous devez conduire à Fort Orange. Pendant dix ans, j'ai tenu les entrepכts de Willemstad, et voilà que les Heeren XVII me confient un comptoir entier... Je l'avoue, je n'arrive toujours pas à y croire.";
			link.l1 = "Parlez-moi de vous. א qui est-ce que je donne une cabine ?";
			link.l1.go = "Factor_About";
			link.l2 = "Faites vos bagages : nous partons immédiatement.";
			link.l2.go = "Factor_Go";
		break;

		case "Factor_About":
			dialog.text = "Toutes mes batailles se livrent dans les registres : recettes, dépenses, connaissements. Là, je vous le dis, je ne connais pas la défaite. Mais je ne vous le cacherai pas, la traversée m'inquiète : la concurrence a le bras long, et au port, on murmure qu'il y a une corvette anglaise au large de la Jamaïque. Je ne suis pas un combattant, capitaine. Tout mon espoir repose sur vous et vos canonniers.";
			link.l1 = "Mes canons ne sont pas là pour la décoration. Faites vos bagages.";
			link.l1.go = "Factor_Go";
			link.l2 = "Je vais me préparer pour la traversée, et je reviendrai vous chercher.";
			link.l2.go = "exit";
		break;

		case "Factor_Go":
			GWIK_JamaicaFactorBoard();
			dialog.text = "Entendu, capitaine. Mes affaires seront prêtes d'ici un quart d'heure : je les ferai porter directement au quai. Alors, cap sur Fort Orange. Si Dieu le veut, nous passerons sans encombre.";
			link.l1 = "Nous passerons. א bientכt à bord.";
			link.l1.go = "exit";
		break;

		case "exit":
			if (!CheckAttribute(pchar, "GWIK.Jamaica.FactorAboard")) LAi_SetOwnerType(NPChar); // Gregg: sailing postponed - he stays standing and waiting (not a frozen actor)
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
