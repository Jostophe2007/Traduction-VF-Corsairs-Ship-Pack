// Gregg: Harvey Murom, once of Bartelemi squadron - «Чёрная Орхидея», глава 9 «Найти и уничтожить».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Laissez-moi tranquille, je suis occupé.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Voyez ce que le vent nous amène. Qu'est-ce que le vieux Harvey vous doit ?";
			link.l1 = "On dit que tu as navigué dans l'escadre de Moris Bartelemi.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(il pose sa chope)... C'est vrai. Quatre ans, et pendant ces quatre ans, nous avons chassé un seul homme.";
			link.l1 = "Bruce Fisher.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Lui-même. Nous avons retourné tout le continent. ...(avec un sourire en coin)... Et pendant tout ce temps, il était sous notre nez, et il n'est jamais entré dans un port.";
			link.l1 = "Comment ça, jamais entré ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Exactement. Le Seeker reste en mer toute l'année. Les vivres lui sont apportés en chaloupe, contre de l'argent. Pas de douane, pas de gens du port, pas de papiers. Son père vivait de la même façon, sur la fin.";
			link.l1 = "Et oם mouille-t-il ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Il change. Deux mouillages, il fait l'aller-retour entre les deux, et nulle part ailleurs. Je vous les nommerai, à une condition.";
			link.l1 = "Laquelle ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Prenez-le vivant et demandez-lui pourquoi il a fait ça à Moris. ...(il regarde la table)... Moris m'a payé mes gages pendant quatre ans, et ça fait quatre jours que je ne l'ai pas vu.";
			link.l1 = "Je le lui demanderai.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("FindAndDestroyGetKharviInformation");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
