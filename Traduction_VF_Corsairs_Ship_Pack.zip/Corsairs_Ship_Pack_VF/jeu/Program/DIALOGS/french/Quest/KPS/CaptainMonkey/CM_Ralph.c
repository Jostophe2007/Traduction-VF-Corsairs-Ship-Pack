// Gregg: Ralph Vatterson and his wife Emily - quest "The Monkey Ship" (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\captainmonkey.c
// Nodes 1-3 - the rescued prisoner in the grotto, 4-6 - the couple's meeting by the
// bank, 7 - the failure branch, if Allen reached the money first.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sLocation = PChar.CaptainMonkey.BankID;
	sLocation = XI_ConvertString("Colony" + sLocation + "Dat");

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Capitaine, je ne sais même pas comment vous remercier...";
			link.l1 = "Inutile de me remercier. Il n'y a pas longtemps, j'étais littéralement à votre place, et je m'en suis sorti par miracle. Que voulaient-ils de vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "De l'argent, mon argent, quoi d'autre. Ils m'ont fait écrire une lettre à ma femme, Emily, lui demandant de retirer toutes nos économies chez l'usurier et de les remettre à ce gredin de Gladstone. Sinon, Allen me promettait une mort longue et douloureuse. Il est sans doute déjà en route. Ma maison est à " + sLocation + ".";
			link.l1 = "Quand lui avez-vous donné la lettre ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Hier matin, monsieur.";
			link.l1 = "Nous pouvons encore arriver à temps. Suivez-moi jusqu'à mon navire.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyToBankColony");
		break;

		case "4":
			dialog.text = "Mon chéri, par quel miracle es-tu ici ? On m'a remis la lettre ce matin, j'allais justement faire ce que tu m'as demandé...";
			link.l1 = "...";
			link.l1.go = "5";
		break;

		case "5":
			SetCameraDialogMode(CharacterFromID("Ralph Vatterson"));
			dialog.text = "Oh, ma chérie, comme je suis heureux de te voir ! Je me suis libéré de captivité grâce à ce courageux capitaine, qui s'appelle " + GetFullName(PChar) + ". Dis-moi, mon amour, oם est ce « gentleman » à qui tu devais remettre notre argent ?";
			link.l1 = "...";
			link.l1.go = "6";
		break;

		case "6":
			SetCameraDialogMode(NPChar);
			dialog.text = "L'homme qui m'a remis la lettre a dit qu'il m'attendrait au-delà des portes de la ville.";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyFromBankToExitTown");
		break;

		case "7":
			dialog.text = "?!...";
			link.l1 = "Pardonne-moi, l'ami. J'ai fait tout ce que j'ai pu.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("CaptainMonkeyBankTimeIsLeftClosedQuest");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
