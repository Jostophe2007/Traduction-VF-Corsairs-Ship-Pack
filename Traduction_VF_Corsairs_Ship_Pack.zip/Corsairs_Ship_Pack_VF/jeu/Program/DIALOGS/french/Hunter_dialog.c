void ProcessDialogEvent()
{
	ref NPChar, TempChar;
	aref Link, Diag;

	int iTemp;
	string sTemp, sTemp1;
	string sGroup;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(Diag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		// -----------------------------------Диалог первый - первая встреча
		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

		case "First time":
			chrDisableReloadToLocation = false;
			//Lai_SetPlayerType(pchar);
			dialog.text = GetFullName(PChar) + " ! "+"דa fait longtemps qu'on te suit à la trace, et maintenant, on te tient enfin.";
			if (SFheadhunters(NPChar.id)) dialog.text = "Alors, tu as mis la main sur beaucoup d'argent et tu crois que personne ne viendra le chercher ?"; // СФ
			if (HasSubStr(NPChar.id, "BShh")) dialog.text = "Des gens influents m'ont demandé de vous transmettre les salutations de la famille Guthrie.";
			Link.l1 = "Qui êtes-vous et que me voulez-vous ?";
			Link.l1.go = "meeting";
			if (!HasSubStr(NPChar.id, "BShh")) PChar.GenQuest.HunterStart = true;
		break;

		case "meeting":
			dialog.text = XI_ConvertString(Nations[sti(NPChar.nation)].Name) + " : on a mis un bon prix sur ta tête, et peu importe qu'on te livre"+ GetSexPhrase(" mort ou vif", " morte ou vive") +".";
			Link.l1 = "Je suis prêt à vous payer davantage si vous me laissez tranquille.";
			Link.l1.go = "Cost_Head";
            // boal 08.04.04 -->
            if (GetSummonSkillFromNameToOld(PChar, SKILL_SNEAK) > 2 || bBettaTestMode)
            {
    			TempChar = characterFromID("Bug Fixer");
    			SetRandomNameToCharacter(TempChar);
    			Link.l2 = ""+ GetSexPhrase("Excusez-moi, mais on dirait que vous faites erreur. Je suis "+ GetFullName(TempChar) + " – marchand bien connu dans la région", "On dirait que vous me confondez avec quelqu'un d'autre. Je suis une simple fille, mon père est "+ GetFullName(TempChar) + " – marchand bien connu dans la région") +".";
    			Link.l2.go = "lier";
			}
            Link.l3 = "Eh bien, tentez votre chance.";
			Link.l3.go = "battle";
		break;

        case "lier":
            if (GetSummonSkillFromName(pchar, SKILL_SNEAK) > rand(150) || bBettaTestMode)
            {
                dialog.text = "Oh ! Nous avons dמ faire erreur, pardonnez-nous, "+ GetAddress_Form(NPChar) + ".";
                Link.l1 = "Bien sמr, ça arrive...";
                Link.l1.go = "lier_2";
                AddCharacterExpToSkill(pchar, SKILL_SNEAK, 100);
            }
            else
            {
                dialog.text = "On dirait que vous mentez !";
                Link.l1 = "Je suis prêt à vous payer davantage si vous me laissez tranquille.";
			    Link.l1.go = "Cost_Head";
			    Link.l2 = "Eh bien, tentez votre chance.";
			    Link.l2.go = "battle";
			    AddCharacterExpToSkill(pchar, SKILL_SNEAK, 50);
            }

        break;

        case "lier_2":
            AddDialogExitQuest("GoAway_Hunters_Land");
            if (CheckAttribute(PChar, "GenQuest.HunterStart")) // только ОЗГи, а не кладоисатели
            {   // запись в СЖ
	            AddQuestRecord("HeadHunter", "HeadHunter_free");
				AddQuestUserData("HeadHunter", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("HeadHunter", "sNation", NationNameGenitive(sti(NPChar.Nation)));
				AddQuestUserData("HeadHunter", "sLoc", GetLocHunterName());
                DeleteAttribute(PChar, "GenQuest.HunterStart");
				CloseQuestHeader("HeadHunter");
            }
            DialogExit();
        break;
        // boal <--

        case "battle":
            AddDialogExitQuest("Battle_Hunters_Land");    // BOAL Весь код я перенёс сюда по всем нациям, просто не переименовал
            if (CheckAttribute(PChar, "GenQuest.HunterStart")) // только ОЗГи, а не кладоисатели
            {   // запись в СЖ
	            AddQuestRecord("HeadHunter", "HeadHunter_battle");
				AddQuestUserData("HeadHunter", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("HeadHunter", "sNation", NationNameGenitive(sti(NPChar.Nation)));
				AddQuestUserData("HeadHunter", "sLoc", GetLocHunterName());
                DeleteAttribute(PChar, "GenQuest.HunterStart");
				CloseQuestHeader("HeadHunter");
            }
            DialogExit();
        break;

        case "Cost_Head2":
            AddMoneyToCharacter(pchar, -sti(PChar.HunterCost));

            AddDialogExitQuest("GoAway_Hunters_Land");

            if (CheckAttribute(PChar, "GenQuest.HunterStart")) // только ОЗГи, а не кладоисатели
            {   // запись в СЖ
	            AddQuestRecord("HeadHunter", "HeadHunter_Buy");
				AddQuestUserData("HeadHunter", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("HeadHunter", "sNation", NationNameGenitive(sti(NPChar.Nation)));
				AddQuestUserData("HeadHunter", "sLoc", GetLocHunterName());
                DeleteAttribute(PChar, "GenQuest.HunterStart");
				CloseQuestHeader("HeadHunter");
            }
            DialogExit();
        break;

        case "Cost_Head":
			dialog.text = "Je pense que " + PChar.HunterCost + " piastres nous conviendront.";
            if(makeint(Pchar.money) < sti(PChar.HunterCost))
            {
                Link.l1 = "Je n'ai pas assez d'argent.";
                Link.l1.go = "NoMoney";
            }else{
                Link.l1 = "Voici votre argent, prenez-le et disparaissez.";
                Link.l1.go = "Cost_Head2";
                Link.l2 = "Une telle somme pour de la racaille comme vous... Je préfère tous vous découper ici !!!";
                Link.l2.go = "battle";
            }
		break;


        case "NoMoney":
			dialog.text = "Dans ce cas, la conversation est terminée !";
			Link.l1 = "Vous ne me prendrez pas vivant.";
			Link.l1.go = "battle";
		break;

		case "TreasureHunter":
			dialog.text = "Un instant, "+ GetSexPhrase("l'ami", "ma petite") +"... Je crois que vous avez quelque chose d'intéressant. Les trésors trouvés, il faut les partager avec ses proches.";
            Link.l1 = "D'accord, je suis prêt à vous payer pour que vous me laissiez tranquille.";
			Link.l1.go = "Cost_Head";
            // boal 08.04.04 -->
            if (GetSummonSkillFromNameToOld(PChar, SKILL_SNEAK) > 3)
            {
    			TempChar = characterFromID("Bug Fixer");
    			SetRandomNameToCharacter(TempChar);
    			Link.l2 = ""+ GetSexPhrase("Excusez-moi, mais on dirait que vous faites erreur. Je suis "+ GetFullName(TempChar) + " – personnalité bien connue dans la région, et non un chasseur de trésors ", "On dirait que vous me confondez avec quelqu'un d'autre. Je suis une simple fille, pas une chasseuse de trésors ! Mon père est "+ GetFullName(TempChar) + " – personnalité bien connue dans la région") +" !";
    			Link.l2.go = "TreasureHunterLier";
			}
            Link.l3 = "Eh bien, il est temps que vos têtes se séparent de vos corps.";
			Link.l3.go = "battle";
		break;

		case "TreasureHunterLier":
            if (GetSummonSkillFromName(pchar, SKILL_SNEAK) > rand(150))
            {
                dialog.text = "Oh ! Nous avons dמ faire erreur, pardonnez-nous, "+ GetAddress_Form(NPChar)+".";
                Link.l1 = "Bien sמr, ça arrive...";
                Link.l1.go = "lier_2";
                AddCharacterExpToSkill(pchar, SKILL_SNEAK, 100);
            }
            else
            {
                dialog.text = "On dirait que vous mentez !";
			    Link.l1 = "Alors écoutez chanter mon sabre.";
			    Link.l1.go = "battle";
			    AddCharacterExpToSkill(pchar, SKILL_SNEAK, 50);
            }
        break;

		// генератор "A reason to hurry"
		case "ReasonToFast_THunter_1":
			if(CheckAttribute(pchar, "GenQuest.CannotWait"))	DeleteAttribute(pchar, "GenQuest.CannotWait");
			dialog.text = "Voici venir notre or. Ce n'est pas pour rien qu'on t'a guetté.";
			link.l1 = RandPhraseSimple("De quoi parlez-vous, messieurs ? Je suis "+ GetSexPhrase("représentant", "représentante") +" de la Compagnie néerlandaise des Indes occidentales et je ne fais que passer ! "+ GetSexPhrase("Je me suis arrêté", "Je me suis arrêtée") +" pour admirer la cכte !", "Il me semble que vous me confondez avec quelqu'un d'autre. Je suis "+ GetSexPhrase("le naturaliste Jacques-François Paganel", "la naturaliste Marie-Thérèse") +" et je collecte des échantillons de la flore locale. Voulez-vous jeter un œil à ma collection de feuilles de yucca ? C'est ici qu'on trouve les spécimens les plus curieux !");
			link.l1.go = "ReasonToFast_THunter_2";
			link.l2 = "Qu'est-ce que vous voulez ?! וcartez-vous !";
			link.l2.go = "ReasonToFast_THunter_2";
		break;

		case "ReasonToFast_THunter_2":
			ReasonToFast_ClearTreasureBox(pchar.questTemp.ReasonToFast.Treasure.Location);
			dialog.text = "Eh non, " + GetSexPhrase("mon brave", "ma jolie") + ". דa ne marchera pas comme ça... Nous savons de source sמre que la carte de " + GetName( pchar.questTemp.ReasonToFast.mapIdx, pchar.questTemp.ReasonToFast.map, NAME_GEN) +" est entre vos mains. Et c'était un sacré avare, ses coffres débordaient de piastres. Alors nous ne repartirons pas les mains vides.";
			link.l1 = "Vous avez raison. Les coffres étaient pleins. Seulement, vous ne les aurez pas. Vous pouvez aller à la grotte, il reste encore deux ou trois seaux percés.";
			link.l1.go = "ReasonToFast_THunter_3";
			if(ReasonToFast_CheckTreasureQty("icollection", sti(pchar.questTemp.ReasonToFast.p8)) >= sti(pchar.questTemp.ReasonToFast.p8)
				&& ReasonToFast_CheckTreasureQty("Chest", sti(pchar.questTemp.ReasonToFast.p7)) >= sti(pchar.questTemp.ReasonToFast.p7))
			{
				link.l2 = "Vous avez raison, prenez vos trésors. Mais ils ne vous porteront pas bonheur : il y a trop de sang dessus...";
				link.l2.go = "ReasonToFast_THunter_4";
			}
		break;

		case "ReasonToFast_THunter_3":
			dialog.text = ""+ GetSexPhrase("Eh, capitaine. Si jeune, vous auriez dמ vivre encore longtemps, ", "Oh, ma fille. Si jeune, vous auriez dמ vivre encore longtemps") +"...";
			link.l1 = "Je n'ai pas l'intention de mourir !";
			link.l1.go = "ReasonToFastTHunter_Fight";
		break;

		case "ReasonToFast_THunter_4":
			dialog.text = "Voilà les paroles sensées d'une personne raisonnable !";
			link.l1 = "Maudits soyez-vous, vous et vos trésors...";
			link.l1.go = "ReasonToFast_THunter_GoAway";
		break;

		case "ReasonToFast_THunter_GoAway":
			iTemp = ReasonToFast_CheckTreasureQty("icollection", sti(pchar.questTemp.ReasonToFast.p8));
			if(iTemp > 0)
			{
				ReasonToFast_GetTreasure("icollection", iTemp );
				Log_Info(XI_ConvertString("You give item"));
				PlayStereoSound("interface\important_item.wav");
			}

			iTemp = ReasonToFast_CheckTreasureQty("Chest", sti(pchar.questTemp.ReasonToFast.p7));
			if(iTemp > 0)
			{
				ReasonToFast_GetTreasure("Chest", iTemp);
				Log_Info(XI_ConvertString("You give item"));
				PlayStereoSound("interface\important_item.wav");
			}
			if(pchar.questTemp.ReasonToFast == "GetTreasure")
			{
				AddQuestRecord("ReasonToFast", "24");
				AddQuestUserData("ReasonToFast", "sName", GetName( pchar.questTemp.ReasonToFast.mapIdx, pchar.questTemp.ReasonToFast.map, NAME_GEN));
				CloseQuestHeader("ReasonToFast");
			}
			DialogExit();
			AddDialogExitQuest("ReasonToFast_GoAway_Hunters_Land");
		break;

		case "ReasonToFastTHunter_Fight":
			sGroup = "LAND_HUNTER";
			sTemp = "LandHunter0";
			iTemp = sti(pchar.HunterCost.Qty);
			chrDisableReloadToLocation = true;
			LAi_SetPlayerType(pchar);
			LAi_SetFightMode(pchar, true);
			for(i = 1; i <= iTemp; i++)
			{
				sld = CharacterFromID(sTemp + i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, sGroup);
			}

			LAi_group_SetRelation(sGroup, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(sGroup, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(sGroup, "OpenTheDoors");
			LAi_group_SetCheck(sGroup, "ReasonToFast_TrHuntersDied");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "ReasonToFast_HunterShore1":
			dialog.text = "Hé, "+ GetSexPhrase("l'ami", "ma petite") +" ! " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " a dit que vous aviez quelque chose pour nous.";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "ReasonToFast_HunterShore11";
			pchar.quest.ReasonToFast_SetHunterPort_1.over = "yes";
			pchar.quest.ReasonToFast_SetHunterPort_2.over = "yes";
		break;

		case "ReasonToFast_HunterShore11":
			if(pchar.questTemp.ReasonToFast == "GetMap")
			{
				dialog.text = "La carte de " + GetName( pchar.questTemp.ReasonToFast.mapIdx, pchar.questTemp.ReasonToFast.map, NAME_GEN);
				link.l1 = "Prenez-la, et saluez de ma part " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + ". Dites-lui que nous nous reverrons bientכt...";
				link.l1.go = "ReasonToFast_HunterShore12_1";
				link.l2 = GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " se trompe lourdement s'il croit que je vais lui tirer les marrons du feu.";
				link.l2.go = "ReasonToFast_HunterShore23";
			}
			if(pchar.questTemp.ReasonToFast == "LakeyExitSuccess")
			{
				dialog.text = "Tout ce que vous avez volé au gouverneur.";
				if(ReasonToFast_CheckTreasureQty("icollection", sti(pchar.questTemp.ReasonToFast.p8)) >= sti(pchar.questTemp.ReasonToFast.p8)
					&& ReasonToFast_CheckTreasureQty("Chest", sti(pchar.questTemp.ReasonToFast.p7)) >= sti(pchar.questTemp.ReasonToFast.p7))
				{
					link.l1 = "Prenez-la, et saluez de ma part " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + ". Dites-lui que nous nous reverrons bientכt...";
					link.l1.go = "ReasonToFast_HunterShore12_2";
				}
				link.l2 = GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " se trompe lourdement s'il croit que je vais lui tirer les marrons du feu.";
				link.l2.go = "ReasonToFast_HunterShore23";
			}
			pchar.quest.ReasonToFast_SetHunterPort_1.over = "yes";
			pchar.quest.ReasonToFast_SetHunterPort_2.over = "yes";
			chrDisableReloadToLocation = false;
		break;

		case "ReasonToFast_HunterShore12_1":
			TakeNItems(pchar, "mapQuest", -1);
			AddQuestRecord("ReasonToFast", "20");
			AddQuestUserData("ReasonToFast", "sText", "la carte");
			AddQuestUserData("ReasonToFast", "sName", GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN));
			CloseQuestHeader("ReasonToFast");
			DialogExit();
			AddDialogExitQuest("ReasonToFast_GoAway_Hunters_Land");
		break;

		case "ReasonToFast_HunterShore12_2":
			iTemp = ReasonToFast_CheckTreasureQty("icollection", sti(pchar.questTemp.ReasonToFast.p8));
			if(iTemp > 0)
			{
				ReasonToFast_GetTreasure("icollection", iTemp );
				Log_Info(XI_ConvertString("You give item"));
				PlayStereoSound("interface\important_item.wav");
			}

			iTemp = ReasonToFast_CheckTreasureQty("Chest", sti(pchar.questTemp.ReasonToFast.p7));
			if(iTemp > 0)
			{
				ReasonToFast_GetTreasure("Chest", iTemp);
				Log_Info(XI_ConvertString("You give item"));
				PlayStereoSound("interface\important_item.wav");
			}
			AddQuestRecord("ReasonToFast", "20");
			AddQuestUserData("ReasonToFast", "sText", "les objets de valeur");
			AddQuestUserData("ReasonToFast", "sName", GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN));
			CloseQuestHeader("ReasonToFast");
			DialogExit();
			ReasonToFast_ClearTreasureBox(pchar.questTemp.ReasonToFast.city + "_townhall");
			ReasonToFast_ClearTreasureBox(pchar.questTemp.ReasonToFast.LakeyLocation);
			AddDialogExitQuest("ReasonToFast_GoAway_Hunters_Land");
		break;

		case "ReasonToFast_HunterShore2":
			dialog.text = "Hé, "+ GetSexPhrase("l'ami", "ma petite") +" ! " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN) + " a quelques questions à te poser.";
			link.l1 = "Pourquoi ne leur demande-t-il pas lui-même ?";
			link.l1.go = "ReasonToFast_HunterShore21";
			chrDisableReloadToLocation = false;
		break;

		case "ReasonToFast_HunterShore21":
			dialog.text = "Quel gâchis... Vous avez fait échouer l'opération, ce qui nous a fait perdre " + sti(pchar.questTemp.ReasonToFast.p10) + " piastres. Alors vous me devez de l'argent.";
			link.l1 = "Prenez-la, et saluez de ma part " + GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_DAT) + ". Dites-lui que nous nous reverrons bientכt...";
			link.l1.go = "ReasonToFast_HunterShore22";
			link.l2 = GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_NOM) + " se trompe lourdement s'il croit que je vais lui tirer les marrons du feu.";
			link.l2.go = "ReasonToFast_HunterShore23";
		break;

		case "ReasonToFast_HunterShore22":
			if(makeint(pchar.money) >= sti(pchar.questTemp.ReasonToFast.p10))
			{
				AddMoneyToCharacter(pchar, -makeint(sti(pchar.questTemp.ReasonToFast.p10)));
				AddQuestRecord("ReasonToFast", "20");
				AddQuestUserData("ReasonToFast", "sText", "l'argent");
				AddQuestUserData("ReasonToFast", "sName", GetName( NAMETYPE_MAIN, pchar.questTemp.ReasonToFast.p3, NAME_GEN));
				DialogExit();
				AddDialogExitQuest("ReasonToFast_GoAway_Hunters_Land");
			}
			else
			{
				dialog.text = "Vous n'avez pas assez d'argent ! Eh bien, vous avez fait votre choix... ";
				link.l1 = "Il y a bien longtemps...";
				link.l1.go = "ReasonToFastTHunter_Fight";
				if(pchar.questTemp.ReasonToFast == "LakeyExitSuccess" || pchar.questTemp.ReasonToFast == "LakeyExitFail")
				{
					pchar.quest.ReasonToFast_SetPirateShip.win_condition.l1 = "MapEnter";
					pchar.quest.ReasonToFast_SetPirateShip.function = "ReasonToFast_PreparePirateShip";
				}
			}
		break;

		case "ReasonToFast_HunterShore23":
			dialog.text = "Eh bien, vous avez fait votre choix...";
			link.l1 = "Il y a bien longtemps...";
			link.l1.go = "ReasonToFastTHunter_Fight";
			if(pchar.questTemp.ReasonToFast == "LakeyExitSuccess" || pchar.questTemp.ReasonToFast == "LakeyExitFail")
			{
				pchar.quest.ReasonToFast_SetPirateShip.win_condition.l1 = "MapEnter";
				pchar.quest.ReasonToFast_SetPirateShip.function = "ReasonToFast_PreparePirateShip";
			}
		break;
		// генератор "A reason to hurry"
	}
}
string GetLocHunterName()
{
	int nLoc = FindLocation(Pchar.location);
	int nFile = LanguageOpenFile("LocLables.txt");
	string ret = "";

	if(nFile >= 0)
	{
		if (CheckAttribute(&locations[nLoc], "islandId"))
		{
			if (locations[nLoc].islandId != "Mein")
			{
				ret = "l'île de " + LanguageConvertString(nFile, locations[nLoc].islandId);
			}
			else
			{
				ret = "la Terre Ferme";
			}
		}
		//
        if (CheckAttribute(&locations[nLoc], "fastreload"))
		{
			ret += " (" +LanguageConvertString(nFile, locations[nLoc].fastreload + " Town") + ")";
		}
		//ret += LanguageConvertString(nFile, locations[nLoc].id.label);
		LanguageCloseFile( nFile );
	}
	return ret;
}
