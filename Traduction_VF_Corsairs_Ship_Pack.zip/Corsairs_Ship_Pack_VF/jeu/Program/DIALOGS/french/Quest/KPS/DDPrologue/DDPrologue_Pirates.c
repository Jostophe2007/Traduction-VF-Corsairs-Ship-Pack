// Gregg: Pierre Arnu and Rene Matezh, Sajfus's men in the grotto - alternative prologue
// "Desert Island" (ported from Damned Destiny). The scene is overheard: the player sits in
// cover, and both sides of the exchange are the pirates talking to each other.
// Logic - Program\Quests\reaction_functions\ddprologue.c

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Pierre Arnu : Et pourquoi on est venus se fourrer ici ? Il n'y a personne, et il ne peut y avoir personne. Sous une telle grêle de mitraille, personne n'a la moindre chance de survivre.";
			link.l1 = "René Matezh : Le capitaine a ordonné de passer l'île au peigne fin. Arrête de geindre et fouille la grotte.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Pierre Arnu : Ah non, je n'irai pas plus loin là-dedans, c'est encore plus sinistre qu'ici, et je me fiche des ordres du capitaine.";
			link.l1 = "René Matezh : Ah oui ? Tu oserais désobéir à un ordre du capitaine ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Pierre Arnu : Et pourquoi tu n'y vas pas toi-même, puisque tu es si malin ? Vas-y, faufile-toi là-dedans, et moi, je regarderai ce qu'ils te feront.";
			link.l1 = "René Matezh : ...(avec un sourire narquois)... Et qui exactement me ferait quelque chose, là-dedans ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Pierre Arnu : Tu n'en as donc pas entendu parler ?";
			link.l1 = "René Matezh : Parler de quoi ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Pierre Arnu : Des abominables créatures qui vivent dans ces grottes et tuent tous ceux qui entrent sur leur territoire.";
			link.l1 = "René Matezh : ...(avec un sourire narquois)... Des contes pour faire peur aux petits enfants.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Pierre Arnu : ...(avec colère)... Des contes ? Eh bien, si ce sont des contes, tu n'as rien à craindre. Vas-y, faufile-toi là-dedans, et je te suivrai.";
			link.l1 = "René Matezh : Hum... Euh... En fait, tu as raison, il n'y a sans doute personne ici, pas besoin de fouiller.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Pierre Arnu : Quoi, tu as perdu ton courage ? Tu as peur, coquin.";
			link.l1 = "René Matezh : Je n'ai pas peur ! Je me suis simplement... Je me suis simplement souvenu de notre mitraille, et... Sous une telle grêle de feu, personne n'aurait vraiment survécu. C'est dit, allons-nous-en.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Pierre Arnu : Tu as perdu ton courage, René, ne le nie pas, je le vois bien. Bon, filons d'ici, cet endroit me donne la chair de poule.";
			link.l1 = "René Matezh : Attends. Nous dirons au capitaine que nous avons fouillé cette grotte de fond en comble, compris ?";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Pierre Arnu : Non, il vaut mieux que tu le lui dises tout seul, il te fait plus confiance.";
			link.l1 = "René Matezh : Soit, je le lui dirai. C'est dit, filons d'ici.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartGameEnemyInGrotExit");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
