// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.State == "Sp9SaveCumana_toPortoBello")//квест №9 испанки.
			{
				dialog.text = "Qui êtes-vous et que vous faut-il ?";
				link.l1 = "Je m'appelle " + GetFullName(pchar) + ", veuillez lire ce document. C'est une lettre de créance à mon nom, signée par le gouverneur général Francisco Oregon y Gascon.";
				link.l1.go = "Step_S10_1";
			}
			if (pchar.questTemp.State == "Sp9SaveCumana_toCompOut")//квест №9 испанки, после того, как 0 компаньонов.
			{
				dialog.text = "Alors, capitaine, content de vous voir. Qu'avez-vous à me dire ?";
				link.l1 = "Je viens pour la mission. זtes-vous prêt à mettre ces galions à ma disposition ?";
				link.l1.go = "Step_S10_5";
			}
			if (pchar.questTemp.piratesLine == "Panama_toPortoBello")//пиратка, штурм Панамы
			{
				dialog.text = "";
				link.l1 = "";
				link.l1.go = "Step_S10_5";
			}
		break;
        //==> Девятый квест исп.линейки: сопроводить четыре золотых галеона.
        case "Step_S10_1":
			dialog.text = "Oui, je vois. Très bien, je vous attendais depuis longtemps. Connaissez-vous le but de votre venue ici ?";
			link.l1 = "Dans les grandes lignes, je dois escorter quelques navires quelque part...";
			link.l1.go = "Step_S10_2";
  			TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
        break;
        case "Step_S10_2":
			dialog.text = "Hum, c'est exact. Je vous confie quatre galions chargés d'or. Vous devez les mener sains et saufs jusqu'à l'île inhabitée des Caïmans. Tout est clair pour vous ?";
			link.l1 = "Pas vraiment... Si vous permettez, je vais donner mon avis sur la question.";
			link.l1.go = "Step_S10_3";
        break;
        case "Step_S10_3":
			dialog.text = "Oui, bien sמr.";
			link.l1 = "Je comprends quand il s'agit de mener des galions chargés d'or jusqu'à une ville fortifiée, sous la protection d'un fort puissant. Mais les emmener sur une île déserte...";
			link.l1.go = "Step_S10_4";
        break;
        case "Step_S10_4":
			dialog.text = "C'est le point de ralliement d'une grande escadre qui part pour l'Ancien Monde. Une puissante flotte espagnole venant de Belize vous y attendra. Il n'y a donc pas lieu de s'inquiéter : c'est notre nouvelle ruse tactique pour lutter contre les ladrones. Avant, ils guettaient les approches de Belize, mais cette fois, seuls des galions militaires renforcés en sortiront, et les pirates ne pourront rien contre eux\n"+
				          "Tout est clair pour vous, maintenant ?";
			link.l1 = "Presque. Et oם sont ces galions, oם sont leurs capitaines ?";
			link.l1.go = "Step_S10_5";
        break;
        case "Step_S10_5":
			if (GetCompanionQuantity(pchar) > 1)
			{
				dialog.text = "Les capitaines seront placés sous vos ordres dès que vous aurez renvoyé les navires supplémentaires de votre escadre. Vous ne devez garder qu'un seul de vos navires.";
				link.l1 = "Je comprends. Je reviendrai vous voir plus tard, dès que j'aurai réglé la question de mon escadre...";
				link.l1.go = "exit";
				pchar.questTemp.State = "Sp9SaveCumana_toCompOut";
			}
			else
			{
				dialog.text = "Les galions sont en rade de Portobelo, et leurs capitaines sont immédiatement placés sous vos ordres. En fait, vous pouvez commencer la mission tout de suite.";
				link.l1 = "Très bien. Suis-je limité dans le temps ?";
				link.l1.go = "Step_S10_6";
			}
        break;
        case "Step_S10_6":
			dialog.text = "Non, l'important est que tous les galions arrivent aux Caïmans sains et saufs, avec le même contenu qu'aujourd'hui. Je veux parler de l'or. Il y en a actuellement 5 000 unités dans les cales des navires, soit 10000 quintaux.";
			link.l1 = "Je comprends. Eh bien, je me mets au travail.";
			link.l1.go = "Step_S10_7";
        break;
        case "Step_S10_7":
            pchar.questTemp.State = "Sp9SaveCumana_toCompOut";
			AddQuestRecord("Spa_Line_9_FourGolgGaleons", "2");
			AddQuestUserData("Spa_Line_9_FourGolgGaleons", "sSex", GetSexPhrase("", "e"));
            ref sld;
            for (int i=1; i<=4; i++)
            {
                sld = GetCharacter(NPC_GenerateCharacter("Captain_"+i, "trader_"+(rand(15)+1), "man", "man", 15, SPAIN, -1, true));
                FantomMakeCoolSailor(sld, SHIP_ROTERLOW, "", CANNON_TYPE_CANNON_LBS16, 30, 15, 15);
                FantomMakeCoolFighter(sld, 15, 10, 10, BLADE_SHORT, "pistol1", 0);
                sld.Ship.Cargo.Goods.Balls = 48;
                sld.Ship.Cargo.Goods.Grapes = 10;
                sld.Ship.Cargo.Goods.Knippels = 48;
                sld.Ship.Cargo.Goods.Bombs = 48;
                sld.Ship.Cargo.Goods.Weapon = 0;
                sld.Ship.Cargo.Goods.Powder = 80;
				sld.Ship.Cargo.Goods.Food = 300;
				sld.Ship.Cargo.Goods.Gold= 1250;
				SetCharacterRemovable(sld, false);
				sld.CompanionEnemyEnable = false;
				sld.Abordage.Enable = false; // НЕЛЬЗЯ!
                SetCompanionIndex(pchar, -1, sti(sld.index));
                Pchar.quest.Sp9SaveCumana_toCaimanBattle.win_condition.l1 = "location";
                Pchar.quest.Sp9SaveCumana_toCaimanBattle.win_condition.l1.location = "Caiman";
                Pchar.quest.Sp9SaveCumana_toCaimanBattle.win_condition = "Sp9SaveCumana_toCaimanBattle";
            }
			DialogExit();
        break;
		//************************** Квестовые штрумы ************************
		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;
        //==> пиратка, штурм Панамы
        case "PQ8_MayorPortoBello":
			dialog.text = "Diable !!! Avec quelle rapidité vous avez pris la ville !";
			link.l1 = "Ha ! Je comprends votre surprise. Mais ce n'est qu'un début...";
			link.l1.go = "Step_P1_1";
			AfterTownBattle();
        break;
        case "Step_P1_1":
			dialog.text = "Nous savions qu'une attaque contre Panama se préparait. Vous avez pris ma ville, mais vous ne prendrez jamais Panama... La jungle détruira toute votre meute.";
			link.l1 = "Ce n'est plus votre affaire. Au fait, comment avez-vous eu vent de l'expédition ?";
			link.l1.go = "Step_P1_2";
        break;
        case "Step_P1_2":
			dialog.text = "Moi ? Par le gouverneur général. Et comment il l'a appris, je n'en ai aucune idée.";
			link.l1 = "Je vois. Eh bien, c'est intéressant...";
			link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
            SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
			AddDialogExitQuestFunction("PQ8_MorganInPortoBello");
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

