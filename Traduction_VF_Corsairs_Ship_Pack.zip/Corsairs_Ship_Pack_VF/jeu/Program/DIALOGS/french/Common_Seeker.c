void ProcessDialogEvent()
{
	ref NPChar;
    ref Pchar = GetMainCharacter();
    aref Link, NextDiag;

    DeleteAttribute(&Dialog, "Links");

    makeref(NPChar, CharacterRef);
    makearef(Link, Dialog.Links);
    makearef(NextDiag, NPChar.Dialog);
	switch(Dialog.CurrentNode)
	{
        case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "FirstTime":
			dialog.text = "Bonjour. J'agis pour le compte du gouverneur et je cherche un espion ennemi en ville. Qui êtes-vous ?";
			link.l1 = "Bonjour. Je n'habite pas cette ville, mais je ne suis pas un espion. Allons voir le gouverneur, il confirmera.";
			link.l1.go = "TryNotBeCut";
			if (CheckNationLicence(sti(npchar.nation)))
			{
				link.l1 = "J'ai " + GetRusNameNationLicence(sti(npchar.nation)) + ", je suis donc ici en toute légalité. Veuillez en prendre connaissance...";
				link.l1.go = "LicenceOk";
			}
			if (pchar.sex == "Skeleton")	//Проверка на скелета
			{
				if	(GetCharacterEquipSuitID(pchar)== "suit_1")
				{
					link.l1 = "Bonjour. Vous n'allez pas me croire, mais je suis un mort-vivant.";
					link.l1.go = "TryNotBeCut";
				}
				else
				{
					dialog.text = "UN SQUELETTE VIVANT ? Vous êtes sorti d'un coffre ? Retournez-y !";
					link.l1 = "Pas question ! Je vais me régaler de ton sang !";
					link.l1.go = "exit";
					AddDialogExitQuest("SeekerFight");
				}
			}
		break;
		case "TryNotBeCut":
			if(pchar.SpySeeker == "Enemy" && (10 + rand(50) + rand(50)) > sti(pchar.skill.sneak))
			{
				dialog.text = "J'ai l'impression que vous me mentez. Mais bon, allons voir le gouverneur.";
				link.l1 = "Je ne vais nulle part avec vous ! Défendez-vous !";
				link.l1.go = "exit";
				AddDialogExitQuest("SeekerFight");
			}
			else
			{
				dialog.text = "Bon, inutile. Je vous crois. Bonne chance !";
				link.l1 = "Voilà qui est bien. Bonne chance !";
				link.l1.go = "exit";
				AddCharacterExpToSkill(pchar, "Fortune", 100);
				AddCharacterExpToSkill(pchar, "Sneak", 100);
				AddDialogExitQuest("SpySeekerGood");
				if (pchar.sex == "Skeleton")
				{
					dialog.text = "Ha ha, bonne blague ! Mais je vois que vous n'êtes pas un espion, je ne vous dérangerai donc plus.";
				}
			}
		break;
		case "LicenceOk":
			dialog.text = "Bien. Je ne vous retiens pas plus longtemps."
			link.l1 = "Parfait, au revoir.";
			link.l1.go = "exit";
			AddDialogExitQuest("SpySeekerGood");
		break;
	}
}
