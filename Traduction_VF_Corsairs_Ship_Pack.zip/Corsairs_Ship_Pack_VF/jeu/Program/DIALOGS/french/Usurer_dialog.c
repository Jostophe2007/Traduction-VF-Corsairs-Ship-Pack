// boal 25/04/04 общий диалог Usurer
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06
void ProcessDialogEvent()
{
	ref NPChar, chr, sld;
	aref Link, NextDiag;
	string NPC_Area, sTemp, sTitle;
	int LoanSum, LoanInterest, LoanPeriod, LoanResult, iPastMonths, DepositSum, DepositInterest, DepositResult, iNum, iTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string iDay, iMonth, s1;
	iDay = environment.date.day;
	iMonth = environment.date.month;
	string lastspeak_date = iday + " " + iMonth;

	NPC_Area = Npchar.City;

	// вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Usurer\" + NPChar.City + "_Usurer.c";
    if (!HasCityDialogFile("Usurer", NPChar.City, "_Usurer.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Usurer\DefaultCity_Usurer.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Usurer\DefaultCity_Usurer.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 16/06/06

	if (!CheckAttribute(npchar, "quest.trade_date"))
    {
        npchar.quest.trade_date = "";
    }
    if (!CheckAttribute(npchar, "quest.FindCitizenNoShip"))
    {
        npchar.quest.FindCitizenNoShip = 0;
    }

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
		break;

		case "First time":
			if(!CheckAttribute(npchar, "CapitolMoney")) npchar.CapitolMoney = 500000 + drand(30) * 50000;
			if (LAi_group_GetPlayerAlarm() > 0)
			{
				if(pchar.questTemp.Slavetrader == "After_enterSoldiers" && pchar.questTemp.Slavetrader.UsurerId == npchar.id)
				{
					dialog.text = "Dépêchez-vous, " + pchar.name + ". Et moi, je vais faire le ménage ici...";
					link.l1 = "On prend la mer !";
					link.l1.go = "exit";
					break;
				}
				//работорговец
				//проклятый идол
				if(pchar.questTemp.PDM_CI_RostBlago == "PDM_CI_RostBlago")
				{
					dialog.text = "Je ne sais même pas comment vous remercier, " + pchar.name + ". Ces bandits m'importunaient depuis longtemps.";
					link.l1 = "Ce n'est rien. Vous m'avez déjà rendu un grand service en acceptant cette idole. J'espère qu'elle vous portera beaucoup de chance, haha !";
					link.l1.go = "exit";
					break;
				}

       			dialog.text = NPCharRepPhrase(pchar,
					LinkRandPhrase("L'alarme a été donnée en ville, on vous cherche partout ! א votre place, je ne m'attarderais pas ici.", "Toute la garde de la ville ratisse les rues à votre recherche. Je ne suis pas idiot, je ne vous parlerai pas !", "Fuyez, "+ GetSexPhrase("l'ami", "ma petite") +" avant que les soldats ne vous transforment en passoire..."),
					LinkRandPhrase("Que voulez-vous, "+ GetSexPhrase("gredin", "gredine") +" ?! La garde de la ville est déjà sur vos traces, vous n'irez pas loin"+ GetSexPhrase(" – sale pirate", "") +" !", " Sale assassin, hors de chez moi ! Gardes !!", "Je n'ai pas peur de vous, ordure ! On vous pendra bientכt dans notre fort, vous n'irez pas bien loin..."));
				link.l1 = NPCharRepPhrase(pchar,
					RandPhraseSimple("Hé, l'agitation, ça ne me fait pas peur...", "Ils ne m'attraperont jamais."),
					RandPhraseSimple("Ferme ta gueule, " + GetWorkTypeOfMan(npchar, "") + ", ou je t'arrache ta sale langue !", "Hé, " + GetWorkTypeOfMan(npchar, "") + ", et en plus, il veut attraper des pirates ! Je vais te dire une chose, mon vieux : tiens-toi tranquille et tu vivras..."));
				link.l1.go = "fight";
				break;
			}
			//homo Линейка Блада
            if (CheckAttribute(Pchar, "questTemp.CapBloodLine") && Pchar.questTemp.CapBloodLine == true)
            {
                if(Pchar.questTemp.CapBloodLine.stat == "needMoney" && !CheckAttribute(pchar, "questTemp.CapBloodLine.QuestRaff"))
                {
                    dialog.text = "Bonjour, docteur Blood. Voudriez-vous m'aider pour une affaire ? Bien sמr, vous recevrez une généreuse prime.";
                    Link.l1 = "Je me demande de quoi il s'agit ?";
    				Link.l1.go = "CapBloodUsurer_5";
                    break;
                }
                dialog.Text = LinkRandPhrase("Tiens, docteur Blood ! " + TimeGreeting() + ".",
                                    "Ravie de vous voir, Peter Blood.",
                                    "C'est gentil de passer me voir, " + GetFullName(pchar) + ". Comment va le colonel Bishop ?");
                Link.l1 = "Hélas, je m'en vais déjà, " + npchar.name + ". א plus tard.";
				Link.l1.go = "exit";
                if(CheckAttribute(Pchar, "questTemp.CapBloodLine.Ogl") && Pchar.questTemp.CapBloodLine.Ogl == false)//homo линейка Блада
                {
                    Link.l2 = "Je viens pour affaires.";
    				Link.l2.go = "CapBloodUsurer_1";
                }
				break;
            }
			//пиратка, квест №5, заглушка на возврат бабла -->
			if (CheckAttribute(npchar, "PLQ5Money") && CheckAttribute(pchar, "questTemp.piratesLine.PLQ5Money")) 
			{
				dialog.text = "Vous m'avez apporté les 50 000 ?";
				link.l1 = "Pas encore, je m'en occupe. Patientez.";
				link.l1.go = "exit";
				link.l2 = "J'ai bien peur de ne pas m'en sortir avec cette affaire. Considérez que j'ai refusé.";
				link.l2.go = "StepPL5End_close";
				if (sti(pchar.money) >= 50000)
				{
					link.l3 = "Oui, j'ai récupéré vos 50 000, et je vous les rends.";
					link.l3.go = "StepPL5End_1";
				}
				break;
			}
			//<--пиратка, квест №5, заглушка на возврат бабла

			//-->работорговец
			if (pchar.questTemp.Slavetrader.UsurerId == npchar.id)
			{
				if (pchar.questTemp.Slavetrader == "canTakeQuest")
				{
					dialog.Text = "Ah, enfin, je reçois la visite d'"+ GetSexPhrase("un digne capitaine", "une digne dame") +", et non de ces philistins à moitié idiots qui croient que je plante leurs piastres dans la cour de la banque et que je les récolte chaque mois pour leur payer des intérêts. Ils tremblent pour chaque sou, sans se douter le moins du monde des ruses auxquelles le pauvre usurier doit recourir pour ne pas mourir de faim lui-même, et leur permettre malgré tout de s'acheter une oie pour Noël.";
					Link.l1 = "Je pense que vos déposants ne seraient pas ravis d'entendre de tels propos de la bouche d'une personne à qui ils confient leurs économies.";
					Link.l1.go = "GiveTaskSlave";
					npchar.quest.slave = "current";//чтобы камнем не долбил
					break;
				}
				if (pchar.questTemp.Slavetrader == "TakeShoreCap_end")
				{
					dialog.Text = "...";
					Link.l1 = "Bon, vieux furet, maintenant, tu vas devoir te donner du mal pour tout m'expliquer ! Au lieu d'esclaves, toute une compagnie de soldats m'attendait dans la cale du navire ! J'ai eu du mal à m'en débarrasser ! Je bous de colère, alors dépêche-toi de t'expliquer !";
					Link.l1.go = "Slaveshore_5";
					break;
				}
				if (pchar.questTemp.Slavetrader == "Win_HavanaFort")
				{
					dialog.Text = "Ah, vous voilà enfin ! Des rumeurs sur votre raid audacieux courent déjà dans tout l'archipel. Content de vous voir !";
					Link.l1 = "Je préférerais l'anonymat à une telle gloire... C'est trop dangereux.";
					Link.l1.go = "Win_Havana_Fort";
					break;
				}
				if (pchar.questTemp.Slavetrader == "Havana_seekslaves")
				{
					dialog.Text = "Vous avez apporté les cinq mille esclaves ?";
					if (GetSquadronGoods(Pchar, GOOD_SLAVES) >= 5000)
					{
						Link.l1 = "Oui. Ils sont dans mes cales.";
						Link.l1.go = "Havana_Fort_yesA";
					}
					else
					{
						Link.l1 = "Non, je m'en occupe encore.";
						Link.l1.go = "exit";
					}
					break;
				}
				if (pchar.questTemp.Slavetrader == "End_quest_bad")
				{
					dialog.Text = "Hum... Vous êtes encore en vie ? וtrange... Eh bien, je suppose que ce ne sera pas pour longtemps. Soldats ! א l'aide ! Il y a un bandit ici !";
					link.l1 = "Le salaud !";
					link.l1.go = "exit";
					LAi_group_Attack(NPChar, Pchar);
					break;
				}
				if(pchar.questTemp.Slavetrader == "wait_6" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_6") > 6)
				{
					dialog.Text = "Bonjour. Je m'appelle " + GetFullName(npchar) + ". Que puis-je faire pour vous ?";
					link.l1 = "Oh ! Et que faites-vous ici, ma chère ?";
					link.l1.go = "Usurer_Escape";
					break;
				}
			}
			//<--работорговец

			dialog.text = NPCStringReactionRepeat("Bonjour, " + GetAddress_Form(npchar) + ". Comment puis-je vous aider ?",
				"Oh, c'est encore vous ? Bienvenue, " + GetAddress_Form(npchar) + ". Que voulez-vous cette fois ?",
				"Hum, encore vous, " + GetAddress_Form(npchar) + "... Eh bien, ça me fait plaisir de vous revoir pour la deuxième fois de la journée. Que voulez-vous ?",
                "Oh, " + GetAddress_Form(npchar) + ", vous n'imaginez pas à quel point les clients peuvent parfois être envahissants... Que voulez-vous ?" , "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Rien, je passais juste regarder et bavarder.",
				"Encore moi. Et encore une fois, j'ai décidé de bavarder, comme ça.",
                "Oui, encore moi. Et encore une fois sans affaire précise, juste pour discuter.",
				"Oui, la vie d'usurier n'est pas toujours facile... Et je n'ai besoin de rien, je voulais juste bavarder...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			link.l2 = "Je veux discuter de nos relations financières.";
			link.l2.go = "LoanUsurer";//(на кредитный генератор)
			link.l3 = "J'ai besoin de quelques informations... Bref, j'ai une question.";
			link.l3.go = "quests";//(перессылка в файл города)

			//линейка ГПК, закладка миллиона на депозит
			if (CheckAttribute(pchar, "questTemp.LSC.usurerId") && pchar.questTemp.LSC.usurerId == npchar.id)
			{
				if (pchar.questTemp.LSC == "SignOnPoorMurder")
				{
					link.l4 = "וcoutez, vous auriez dמ recevoir un dépכt à mon nom.";
					link.l4.go = "ISS_deposit";
				}
				if (pchar.questTemp.LSC == "PoorMurderExecute")
				{
					link.l4 = "Je dois retirer un dépכt d'un million de piastres que vous détenez.";
					link.l4.go = "ISS_takeDeposit";
					DeleteAttribute(pchar, "questTemp.LSC.usurerId");
				}
			}
			//квесты мэра, проникновение во враждебный город
  			if (CheckAttribute(pchar, "GenQuest.Intelligence") && pchar.GenQuest.Intelligence.SpyId == npchar.id && pchar.GenQuest.Intelligence == "") //квест мэра - на связь с нашим шпионом
			{
				link.l7 = RandPhraseSimple("Je viens de la part de quelqu'un. Le gouverneur " + GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + ".",
					GetFullName(characterFromId(pchar.GenQuest.Intelligence.MayorId)) + " m'a envoyé chercher quelque chose...");
				link.l7.go = "IntelligenceForAll";
			}
			//<<<<---------------- пиратка, квест №5. --------------------
			if (CheckAttribute(pchar, "questTemp.piratesLine.Q5.city_1") && npchar.city == pchar.questTemp.piratesLine.Q5.city_1)
			{
				if (pchar.questTemp.piratesLine == "PL5Hunter_toFirstUsurer")
				{
					link.l5 = "On dit que vous avez engagé John Avory.";
					link.l5.go = "StepPL5First_1";
				}
				if (pchar.questTemp.piratesLine == "PL5Hunter_toFirst")
				{
					link.l5 = "Dites-moi, vous avez engagé John Avory ?";
					link.l5.go = "StepPL5First_1";
				}
			}
			if (CheckAttribute(pchar, "questTemp.piratesLine.Q5.city_2") && npchar.city == pchar.questTemp.piratesLine.Q5.city_2)
			{
				if (pchar.questTemp.piratesLine == "PL5Hunter_toSecondUsurer")
				{
					link.l5 = "On dit que vous avez eu des ennuis avec John Avory...";
					link.l5.go = "StepPL5Second_0";
				}
				if (pchar.questTemp.piratesLine == "PL5Hunter_toSecond")
				{
					link.l5 = "Dites-moi, vous avez engagé John Avory pour faire des courses ?";
					link.l5.go = "StepPL5Second_1";
				}
			}
			if (CheckAttribute(pchar, "questTemp.piratesLine.Q5.city_3") && npchar.city == pchar.questTemp.piratesLine.Q5.city_3)
			{
				if (pchar.questTemp.piratesLine == "PPL5Hunter_toThirdUsurer" || pchar.questTemp.piratesLine == "PPL5Hunter_toThird")
				{
					link.l5 = "Je cherche John Avory, il est venu vous voir ?";
					link.l5.go = "StepPL5Third_1";
				}
			}
			if (CheckAttribute(pchar, "questTemp.piratesLine.Q5.city_4") && npchar.city == pchar.questTemp.piratesLine.Q5.city_4)
			{
				if (pchar.questTemp.piratesLine == "PL5Hunter_toFourth")
				{
					link.l5 = "J'ai entendu dire qu'il vous était arrivé un malheur, vous avez peut-être besoin d'aide ?";
					link.l5.go = "StepPL5Four_1";
				}
			}
			//-------------------- пиратка, квест №5. ---------------->>>>
			//-->> сдача квеста найти потерянный драгоценный камень
			if (CheckCharacterItem(pchar, "UsurersJew") && CheckAttribute(npchar, "quest.usurersJewel.type"))
			{
				link.l6 = "J'ai retrouvé votre objet : " + npchar.quest.usurersJewel.type + ". Tenez.";
				link.l6.go = "usurersJewel_R1";
			}
			if (CheckAttribute(npchar, "quest.usurersJewel.type") && !CheckCharacterItem(pchar, "UsurersJew"))
			{
				link.l6 = "Je crois que je renonce à chercher la pierre. Je ne pense pas pouvoir la trouver.";
				link.l6.go = "jewelCancel";
			}
			//<<-- сдача квеста найти потерянный драгоценный камень
			if(CheckAttribute(pchar, "GenQuest.EncGirl") && pchar.GenQuest.EncGirl == "toLoverFather" && pchar.GenQuest.EncGirl.LoverFather == "usurer_keeper")
			{
				link.l9 = "Bonjour, je viens à l'invitation de votre fils.";
				link.l9.go = "EncGirl_4";
				pchar.quest.EncGirl_GetLoverFather.over = "yes";
			}
			if (CheckCharacterItem(pchar, "CaptainBook") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakUsurer"))
			{
				link.l10 = "Je voudrais savoir qui est le propriétaire de ces documents.";
				link.l10.go = "ShipLetters_Usurer1";
			}
			//-->работорговец
			if (pchar.questTemp.Slavetrader.UsurerId == npchar.id)
			{
				if (pchar.questTemp.Slavetrader == "Seek_slaves")
				{
					link.l8 = "Je viens pour votre commande d'esclaves.";
					link.l8.go = "Checkslaves";
				}
				if (pchar.questTemp.Slavetrader == "goaway")
				{
					link.l8 = "Bonjour, " + npchar.name + ", je viens pour votre mission.";
					link.l8.go = "Takeslaves_4_lose";
				}
				if (pchar.questTemp.Slavetrader == "goaway_pinas")
				{
					link.l8 = "Bonjour, " + npchar.name + ", je viens pour votre mission.";
					link.l8.go = "Pinas_lose";
				}
				if (pchar.questTemp.Slavetrader == "died")
				{
					link.l8 = "Bonjour, " + npchar.name + ", je viens pour votre mission.";
					link.l8.go = "Takeslaves_4_win";
				}
				if (pchar.questTemp.Slavetrader == "wait" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait") > 20)
				{
					link.l8 = "Je suis là, comme convenu. Alors, ce travail ?";
					link.l8.go = "Takeslaves_3";
				}
				if (pchar.questTemp.Slavetrader == "waitship")
				{
					link.l8 = "Comme convenu, me voilà. Alors, ce travail ?";
					link.l8.go = "Takeslaves_3";
				}
				if (pchar.questTemp.Slavetrader == "wait_1" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_1") > 30)
				{
					link.l8 = "Bonjour, " + npchar.name + ". Comment allez-vous ? Y a-t-il une nouvelle mission ?";
					link.l8.go = "EscapeSlave";
				}
				if (pchar.questTemp.Slavetrader == "escapeslave_win")
				{
					link.l8 = "Votre mission est accomplie. J'ai réussi à retrouver les esclaves fugitifs, même si ça n'a pas été facile.";
					link.l8.go = "Escape_slaves_win";
				}
				if (pchar.questTemp.Slavetrader == "wait_2" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_2") > 30)
				{
					link.l8 = "Bonjour, " + npchar.name + ". Je suis là, comme convenu, pour une autre affaire lucrative.";
					link.l8.go = "Slaveshore";
				}
				if (pchar.questTemp.Slavetrader == "goodbye")
				{
					link.l8 = "J'ai de mauvaises nouvelles, " + npchar.name + ". Je n'ai pas réussi à capturer la brigantine.";
					link.l8.go = "Brig_lose";
				}
				if (pchar.questTemp.Slavetrader == "goodbye_1")
				{
					link.l8 = "וcoutez, " + npchar.name + ". J'ai rattrapé la brigantine, mais je n'ai trouvé aucun document. Vous êtes sמr qu'ils y étaient ?";
					link.l8.go = "Letter_lose";
				}
				if (pchar.questTemp.Slavetrader == "winbrig")
				{
					link.l8 = "J'ai de bonnes nouvelles, " + npchar.name + ". J'ai réussi à rattraper la brigantine et à récupérer les papiers. Les voici.";
					link.l8.go = "Brig_win";
				}
				if (pchar.questTemp.Slavetrader == "wait_3" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_3") > 30)
				{
					link.l8 = "Bonjour, " + npchar.name + ". Alors, vous m'avez déjà préparé une nouvelle affaire ?";
					link.l8.go = "SlaveGalleon";
				}
				if (pchar.questTemp.Slavetrader == "wingalleon")
				{
					link.l8 = "" + npchar.name + ", j'ai réussi à intercepter votre soi-disant « galion ».";
					link.l8.go = "Wingalleon";
				}
				if (pchar.questTemp.Slavetrader == "lostgalleon")
				{
					link.l8 = "" + npchar.name + ", pardonnez-moi, mais je n'ai pas pu capturer ce galion.";
					link.l8.go = "Lostgalleon";
				}
				if (pchar.questTemp.Slavetrader == "wait_4" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_4") > 4)
				{
					link.l8 = "Bonjour, " + npchar.name + ". Je viens chercher mon argent.";
					link.l8.go = "FindRat";
				}
				if (pchar.questTemp.Slavetrader == "wincorvette")
				{
					link.l8 = "" + npchar.name + ", votre mission est accomplie. Ce salaud de Gontier est mort, ainsi que tout son équipage.";
					link.l8.go = "Wincorvette";
				}
				if (pchar.questTemp.Slavetrader == "lostcorvette")
				{
					link.l8 = "" + npchar.name + ", je regrette beaucoup : j'ai manqué François Gontier, alors que je l'ai suivi jusqu'à Tortuga. Mais là-bas, il a réussi à s'échapper à bord de sa corvette, sous mon nez.";
					link.l8.go = "lostcorvette";
				}
				if (pchar.questTemp.Slavetrader == "wait_5" && GetQuestPastDayParam("pchar.questTemp.Slavetrader_wait_5") > 30)
				{
					link.l8 = "Bonjour, " + npchar.name + ". Alors, dites-moi quelle affaire brמlante vous m'avez préparée.";
					link.l8.go = "Havana_fort";
				}
			}
			//<--работорговец
			//Капитул
			if(CheckAttribute(pchar, "SellCapitol"))
			{
				link.lCapitol = "J'ai quelque chose qui pourrait vous intéresser. Jetez un œil à cette liste.";
				link.lCapitol.go = "SellCapitol";
			}
			//Китайская реликвия
			if(CheckAttribute(pchar, "Whisper.UsurerId") && npchar.id == pchar.Whisper.UsurerId)
			{
				if (!CheckAttribute(pchar, "WhisperChSpokeToUsurer"))
				{
					link.lWhisper = "Bonjour. On m'a dit que vous possédiez un ancien sabre chinois. C'est vrai ?";
					link.lWhisper.go = "Whisper_china_relic";
				}
				else
				{
					if (CheckCharacterGeneratedItem(PChar, "topor_emperor") != "")
					{
						link.lWhisper = "Je vous ai apporté la hache impériale.";
						link.lWhisper.go = "Whisper_china_relic_finish_topor";
					}
					if (CheckCharacterItem(pchar, "sculMa1") && CheckCharacterItem(pchar, "sculMa2") && CheckCharacterItem(pchar, "sculMa3"))
					{
						link.lWhisper1 = "Je vous ai apporté trois crânes de cristal.";
						link.lWhisper1.go = "Whisper_china_relic_finish_sculma";
					}
					if(CheckAttribute(pchar, "SellCapitol"))
					{
						link.lCapitol = "J'ai trouvé quelque chose de plus intéressant que ce que vous m'aviez demandé. Jetez un œil à cette liste.";
						link.lCapitol.go = "Whisper_china_relic_finish_capitol";
					}
				}
			}
			//Нежданное наследство
			if (CheckAttribute(PChar, "UnexpectedInheritance"))
            {
				if(!CheckAttribute(pchar, "UnexpectedInheritance_translator"))
				{
					link.lUnexpectedInheritance = "Vous proposez des services de traduction ? J'ai un document intéressant en latin.";
					link.lUnexpectedInheritance.go = "UnexpectedInheritance_translate";
				}
				else
				{
					if(npchar.id == pchar.UnexpectedInheritance_translator && GetNpcQuestPastDayWOInit(npchar, "UnexpectedInheritance_translate") > 0 && sti(pchar.money) >= 1000)
					{
						link.lUnexpectedInheritance = "Vous proposez des services de traduction ? J'ai un document intéressant en latin.";
						link.lUnexpectedInheritance.go = "UnexpectedInheritance_translate_end";
					}
				}
            }


			NextDiag.TempNode = "First time";
		break;

		//Нежданное наследство
		case "UnexpectedInheritance_translate":
			dialog.text = "D'habitude, non, mais pour dix mille...";
			if(sti(pchar.money) >= 10000)
			{
				link.l1 = "Voici votre argent.";
				link.l1.go = "UnexpectedInheritance_translate_end";
			}
			link.l2 = "Vos prix sont complètement délirants. Je crois que je vais partir.";
			link.l2.go = "exit";

		break;

		case "UnexpectedInheritance_translate_end":
			dialog.text = "Voyons... Hum... Ce n'est pas vraiment du latin, c'est du latin vulgaire. Attendez une minute, voilà.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -10000);
			UnexpectedInheritanceTranslatePart(pchar.UnexpectedInheritance);
			DeleteAttribute(pchar, "UnexpectedInheritance_translator");
			DeleteAttribute(pchar, "UnexpectedInheritance");

		break;
		//Капитул
		case "SellCapitol":
			dialog.text = "Hum, c'est vraiment une liste intéressante. Pour tout cela, je suis disposé à vous donner "+npchar.CapitolMoney+" piastres. Qu'en dites-vous ?";
			link.l1 = "Marché conclu. Vous pourrez tout récupérer sur le récif du Squelette. Voici les coordonnées. C'est sמr, vous pouvez y envoyer un navire.";
			link.l1.go = "SellCapitol_1";
			link.l2 = "Ce ne sera pas assez. Je vais chercher un autre acheteur, sans rancune.";
			link.l2.go = "exit";
		break;
		case "SellCapitol_1":
			AddMoneyToCharacter(pchar, sti(npchar.CapitolMoney));
			DeleteAttribute(pchar, "SellCapitol");
			Log_Info("Vous avez révélé l'emplacement du Chapitre");
			PlaySound("interface\important_item.wav");
			CloseQuestHeader("TheLastMass");
			dialog.text = "Un plaisir de faire affaire avec vous. J'espère que vous ne mentez pas et que tout sera bien en place. Sinon...";
			link.l1 = "Je n'ai aucune envie de rencontrer vos amis chasseurs de primes. Je vous l'assure, tout est là-bas. Au revoir.";
			link.l1.go = "exit";
		break;
		//Виспер - Китайская реликвия
		case "Whisper_china_relic_finish_topor":
			dialog.text = "דa alors ! Elle est encore plus somptueuse que je ne l'imaginais. Je n'ose pas imaginer comment vous l'avez obtenue.";
			s1 = CheckCharacterGeneratedItem(PChar, "topor_emperor");
			if ((sti(PChar.Items.(s1)) == 1) && (PChar.equip.blade == s1))
			{
				RemoveCharacterEquip(PChar, BLADE_ITEM_TYPE);
			}
			TakeItemFromCharacter(PChar, s1);
			Log_Info("Vous avez remis la hache impériale");
			PlaySound("interface\important_item.wav");
			link.l1 = "Inutile, montrez-moi plutכt le sabre, enfin.";
			link.l1.go = "Whisper_china_relic_finish";
		break;
		case "Whisper_china_relic_finish_sculma":
			dialog.text = "Vous les avez vraiment trouvés ?! Pour être franc, je n'osais même pas l'espérer.";
			TakeItemFromCharacter(pchar, "sculMa1");
			TakeItemFromCharacter(pchar, "sculMa2");
			TakeItemFromCharacter(pchar, "sculMa3");
			Log_Info("Vous avez remis les crânes de cristal");
			PlaySound("interface\important_item.wav");
			link.l1 = "Maintenant, je veux voir le sabre.";
			link.l1.go = "Whisper_china_relic_finish";
		break;
		case "Whisper_china_relic_finish_capitol":
			DeleteAttribute(pchar, "SellCapitol");
			CloseQuestHeader("TheLastMass");
			dialog.text = "Hum, c'est vraiment une liste intéressante. Je suis disposé à vous donner le sabre en échange. Oם puis-je trouver toutes ces choses ?";

			Log_Info("Vous avez révélé l'emplacement du Chapitre");
			PlaySound("interface\important_item.wav");
			link.l1 = "Sur le récif du Squelette. Voici les coordonnées. C'est sמr, vous pouvez y envoyer un navire. Alors, ce sabre ? J'aimerais le voir au plus vite.";
			link.l1.go = "Whisper_china_relic_finish";
		break;
		case "Whisper_china_relic_finish":
			DeleteAttribute(pchar, "WhisperChSpokeToUsurer");
			DeleteAttribute(pchar, "Whisper.UsurerId");
			pchar.Whisper.GiveChinaSword = true;
			CloseQuestHeader("WhisperChinamanRelic");
			GiveItem2Character(pchar, "blade_china");
			Log_Info("Vous avez reçu un sabre chinois");
			PlaySound("interface\important_item.wav");
			dialog.text = "Bien sמr ! Le voici, une beauté. J'ai essayé de le garder en bon état, alors prenez-en soin, je vous prie.";
			link.l1 = "Ne vous inquiétez pas, je le remettrai à quelqu'un qui le chérira comme la prunelle de ses yeux : son vrai propriétaire. Au revoir.";
			link.l1.go = "exit";
		break;
		case "Whisper_china_relic":
			dialog.text = "C'est exact. א en juger par les ornements de la lame, il appartenait à une famille célèbre et influente. Pourquoi vous intéressez-vous à lui ?";
			link.l1 = "Combien en voulez-vous ? J'aimerais l'acheter.";
			link.l1.go = "Whisper_china_relic_1";
		break;
		case "Whisper_china_relic_1":
			dialog.text = "L'acheter ? Je regrette, mais je ne vends rien de ma collection.";
			link.l1 = "Dommage. Alors, peut-être accepteriez-vous de l'échanger contre un autre objet ?";
			link.l1.go = "Whisper_china_relic_2";
		break;
		case "Whisper_china_relic_2":
			dialog.text = "Hum, c'est possible. Je cherche depuis longtemps la hache impériale. C'est un symbole du pouvoir, en or et incrusté de pierreries. On dit qu'un pirate des Caraïbes la possède à coup sמr. J'aimerais aussi obtenir trois crânes de cristal toltèques : blanc, rose et bleu. Si vous les trouvez tous les trois, je serai heureux de faire l'échange avec vous.";
			link.l1 = "Je vois. Y a-t-il un indice sur l'endroit oם l'on peut se procurer ces objets ?";
			link.l1.go = "Whisper_china_relic_3";
		break;
		case "Whisper_china_relic_3":
			dialog.text = "Si je le savais, je ne vous demanderais rien. Mais je ne suis pas pressé, revenez quand vous les aurez trouvés. Je n'ai pas l'intention de me séparer du sabre de sitכt.";
			pchar.WhisperChSpokeToUsurer = true;
			AddQuestRecord("WhisperChinamanRelic", "2");
			link.l1 = "Bon, cherchons. Au revoir.";
			link.l1.go = "exit";
		break;
		//

		//<<<<----------генератор -"Ship's documents". ------
		case "ShipLetters_Usurer1":
			pchar.questTemp.different.GiveShipLetters.speakUsurer = true;
			dialog.text = "Il faut beaucoup de temps pour examiner en détail tous ces papiers, et mon temps coמte cher.";
			link.l1 = "Peut-être que " + sti(pchar.questTemp.different.GiveShipLetters.price1) + " pièces d'or compenseront votre dur labeur ?";
			link.l1.go = "ShipLetters_Usurer2";
			link.l2 = "Comme vous voudrez. Au revoir !";
			link.l2.go = "exit";
		break;

		case "ShipLetters_Usurer2":
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.different.GiveShipLetters.price1));
			pchar.questTemp.different.GiveShipLetters.speakUsurer_1 = true;
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 0)
			{
				dialog.text = "Voyons ! Non, c'est la première fois que je vois ce nom. Montrez ces papiers à la capitainerie du port.";
				link.l1 = "Excusez-moi, mais nous étions convenus que vous me parleriez de ce capitaine !";
				link.l1.go = "ShipLetters_Usurer2_1";
			}
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 1)
			{
				s1 = "Eh bien, alors... Je connais le propriétaire de ce navire. Ce n'est peut-être pas le plus riche, mais c'est un homme très aisé.";
				dialog.text = s1 + "On dit qu'il fait de la contrebande avec succès depuis longtemps. N'est-ce pas ce que vous vouliez entendre ?";
				link.l1 = "א vous entendre, on peut donc conclure...";
				link.l1.go = "ShipLetters_Usurer2_2";
			}
			if(sti(pchar.questTemp.different.GiveShipLetters.variant) == 2)
			{
				s1 = "Oui... Je ne sais même pas si vous avez eu de la chance de le trouver.";
				dialog.text = s1 + "Les documents sont établis au nom de notre navire de patrouille coloniale, et son capitaine est connu pour ses principes et la rigueur de ses mœurs.";
				link.l1 = "Un patrouilleur ? Sous les ordres du commandant ?";
				link.l1.go = "ShipLetters_Usurer2_3";
			}
		break;

		case "ShipLetters_Usurer2_1":
			dialog.text = "Nous étions convenus que je jetterais un œil à ces papiers, rien de plus. Je n'ose pas vous retenir plus longtemps.";
			link.l1 = "Merci quand même...";
			link.l1.go = "exit";
		break;

		case "ShipLetters_Usurer2_2":
			dialog.text = "א vous de tirer vos conclusions. Notre commandant « observe de près » depuis longtemps, devinez qui ? Et voilà des factures qui ne portent pas le cachet de la douane...";
			link.l1 = "Je devine. Merci, mon cher !";
			link.l1.go = "exit";
		break;

		case "ShipLetters_Usurer2_3":
			s1 = "C'est exact. D'ailleurs, les contrebandiers du coin en veulent beaucoup à ce capitaine.";
			dialog.text = s1 + "Comme je l'ai dit, le propriétaire de ces papiers est très strict et ne porte pas les contrevenants dans son cœur.";
			link.l1 = "Je devine. Merci, mon cher !";
			link.l1.go = "exit";
		break;

		case "EncGirl_4":
			if(sti(pchar.GenQuest.EncGirl.LoverFatherAngry) == 0)
			{
				dialog.text = "Ah, c'est donc vous "+ GetSexPhrase("le capitaine qui a ramené", "la fille qui a ramené") +" mon fils prodigue avec sa jeune fiancée ?";
				link.l1 = "Oui, je les ai aidés à s'enfuir.";
				link.l1.go = "EncGirl_5";
			}
			else
			{
				dialog.text = "Ah, vous voilà enfin,"+ GetSexPhrase(" mon bienfaiteur", " ma bienfaitrice") +". Vous attendez une récompense ?";
				link.l1 = "Eh bien, pas forcément une récompense, mais un peu de gratitude ferait plaisir.";
				link.l1.go = "EncGirl_6";
			}
		break;

		case "EncGirl_5":
			dialog.text = "Je vous suis très reconnaissant de ne pas avoir abandonné mon enfant dans l'embarras et de l'avoir aidé à se tirer avec honneur d'une situation aussi délicate. Permettez-moi de vous remercier comme je le peux. Acceptez cette modeste somme et un cadeau de ma part.";
			link.l1 = "Merci, ce fut un plaisir d'aider ces jeunes gens.";
			link.l1.go = "EncGirl_5_1";
		break;

		case "EncGirl_6":
			dialog.text = "Quels remerciements ? Pour quelle gratitude ? Non seulement ce nigaud traîne sans travail depuis six mois, mais il a trouvé le temps de faire le joli cœur ! Moi, à son âge, je menais déjà mes propres affaires. Et voyez-vous ça, il est parti chasser ! Le gouverneur a une fille à marier, et celui-là ramène une espèce de traînée sans racines, que Dieu me pardonne, et demande la bénédiction paternelle !";
			link.l1 = "Hum, vous ne croyez donc pas aux sentiments sincères ?";
			link.l1.go = "EncGirl_6_1";
		break;

		case "EncGirl_5_1":
			AddMoneyToCharacter(pchar, sti(pchar.GenQuest.EncGirl.sum));
			GiveItem2Character(pchar, pchar.GenQuest.EncGirl.item);
			AddQuestRecord("JungleGirl", "18");
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "EncGirl_6_1":
			dialog.text = "Quels sentiments ?! De quels sentiments parlez-vous ? Un adulte, une personne comme il faut, et pourtant... Des sentiments ! Vous devriez avoir honte, vous les jeunes, de vous livrer à de telles affaires et de jouer les entremetteurs. La fille a été arrachée au nid de ses parents, et la vie de mon benêt est gâchée. Vous n'aurez aucune gratitude de ma part. Au revoir.";
			link.l1 = "Eh bien, portez-vous bien, vous aussi...";
			link.l1.go = "EncGirl_6_2";
		break;

		case "EncGirl_6_2":
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("JungleGirl", "19");
			AddQuestUserData("JungleGirl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("JungleGirl", "sSex1", GetSexPhrase("", "e"));
			CloseQuestHeader("JungleGirl");
			DeleteAttribute(pchar, "GenQuest.EncGirl");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//<<<<---------------- пиратка, квест №5. --------------------
		case "StepPL5First_1":
			dialog.text = "Je l'ai engagé, et il s'est très bien acquitté de ma mission. Cependant, hi hi, on dit qu'il s'est tellement soמlé à la taverne qu'il a confondu l'ivrogne du coin avec mon débiteur.";
			link.l1 = "Il a dit oם il allait ? Peut-être qu'un autre usurier a besoin d'aide ?";
			link.l1.go = "StepPL5First_2";
		break;
		case "StepPL5First_2":
			dialog.text = "Je n'en sais rien, les problèmes des autres ne me regardent pas.";
			link.l1 = "Il est clair qu'ils ne vous regardent pas. Mais peut-être a-t-il dit quelque chose en passant ?";
			link.l1.go = "StepPL5First_3";
		break;
		case "StepPL5First_3":
			pchar.questTemp.piratesLine.Q5.city_2 = GetQuestNationsCity(SPAIN);
			dialog.text = "Oui, il me semble qu'il comptait continuer vers le nord de la Terre Ferme, chez les Espagnols. Mais je ne sais pas oם exactement... Attendez, il a parlé de " + XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_2 + "Voc") + ". Mais vous comprenez que je ne peux pas en garantir l'exactitude.";
			link.l1 = "Je vois. Merci.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "4");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity1", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_1 + "Gen"));
			AddQuestUserData("Pir_Line_5_Hunter", "sCity2", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_2 + "Acc"));
			AddQuestUserData("Pir_Line_5_Hunter", "sIsland", XI_ConvertString(GetIslandByCityName(pchar.questTemp.piratesLine.Q5.city_2) + "Voc"));
			pchar.questTemp.piratesLine = "PL5Hunter_toSecond";
		break;

		case "StepPL5Second_0":
			dialog.text = "Euh, ce n'est pas qu'il y ait un problème...";
			link.l1 = "Hum, donc vous l'avez engagé ?";
			link.l1.go = "StepPL5Second_1";
		break;
		case "StepPL5Second_1":
			dialog.text = "Engagé, oui. Il a fait son travail, il a récupéré la dette en entier. C'est seulement à la taverne qu'il s'est mis à raconter qu'il aurait soutiré au débiteur une somme bien supérieure à ce qu'il devait, et qu'il m'aurait roulé en me le cachant\n"+
				"Personnellement, je ne comprends pas du tout oם est la tromperie, ni pourquoi cette histoire amuse tant tout le monde ?! C'est un peu vexant, bien sמr ; si j'avais su plus tכt que le débiteur disposait d'une telle somme...\n"+
				"Bref, j'ai poussé un soupir de soulagement quand John Avory a quitté notre ville. Et maintenant, je ne veux plus entendre parler de lui !";
			link.l1 = "Je vois. Et oם il est allé, bien sמr, vous ne le savez pas...";
			link.l1.go = "StepPL5Second_2";
		break;
		case "StepPL5Second_2":
			pchar.questTemp.piratesLine.Q5.city_3 = GetQuestNationsCity(FRANCE);
			dialog.text = "Je pense que ce garnement est parti chez les Français. J'ai surpris par hasard sa conversation dans un bordel. J'y étais allé pour affaires, pas pour l'usage auquel cet établissement est destiné...";
			link.l1 = "Mon cher, ce que vous faisiez là-bas m'est égal. Merci pour les informations sur Avory.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "6");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_3));
			AddQuestUserData("Pir_Line_5_Hunter", "sIsland", XI_ConvertString(GetIslandByCityName(pchar.questTemp.piratesLine.Q5.city_3) + "Voc"));
			pchar.questTemp.piratesLine = "PL5Hunter_toThird";
		break;

		case "StepPL5Third_1":
			dialog.text = "John exécute régulièrement mes commandes, il vient juste d'en terminer une...";
			link.l1 = "Oם peut-il être maintenant ?";
			link.l1.go = "StepPL5Third_2";
		break;
		case "StepPL5Third_2":
			dialog.text = "Dieu seul le sait. Voyez-vous, John est bon exécutant, mais il a le sang très chaud. Récemment, à la taverne, Dieu pardonne à son âme pécheresse, il a poignardé un homme. C'est pourquoi je ne pose pas de questions inutiles à John...";
			link.l1 = "Je vois... Mais peut-être avez-vous au moins une idée de l'endroit oם il a pu aller ?";
			link.l1.go = "StepPL5Third_3";
		break;
		case "StepPL5Third_3":
			pchar.questTemp.piratesLine.Q5.city_4 = GetQuestNationsCity(Holland);
			dialog.text = "Si mon avis vous intéresse, je pense qu'il est parti à " + XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_4) + ".";
			link.l1 = "Hum... Puis-je connaître les raisons de cette conclusion ?";
			link.l1.go = "StepPL5Third_4";
		break;
		case "StepPL5Third_4":
			dialog.text = "Bien sמr. Voyez-vous, le fait est qu'à " + XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_4 + "Voc") + " un usurier a été dévalisé récemment.";
			link.l1 = "Ah, je comprends ! Merci beaucoup.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "8");
			AddQuestUserData("Pir_Line_5_Hunter", "sCity1", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_3 + "Gen"));
			AddQuestUserData("Pir_Line_5_Hunter", "sCity2", XI_ConvertString("Colony" + pchar.questTemp.piratesLine.Q5.city_4 + "Gen"));
			AddQuestUserData("Pir_Line_5_Hunter", "sIsland", XI_ConvertString(GetIslandByCityName(pchar.questTemp.piratesLine.Q5.city_4) + "Voc"));
			pchar.questTemp.piratesLine = "PL5Hunter_toFourth";
		break;

		case "StepPL5Four_1":
			dialog.text = "Non, non, merci. Je n'ai plus besoin d'aide, j'ai engagé John Avory hier, c'est le meilleur dans ce domaine ! Oh, sans vouloir vous vexer, vous êtes aussi"+ GetSexPhrase("l'un", "l'une") +" des meilleurs, c'est juste qu'Avory est venu me voir avant vous... Euh, excusez-moi, comment avez-vous dit que vous vous appeliez ?";
			link.l1 = GetFullName(pchar) + ".";
			link.l1.go = "StepPL5Four_2";
		break;
		case "StepPL5Four_2":
			dialog.text = "Oui, oui, j'ai entendu parler de vous... il me semble... Alors, de quoi je parlais ? Ah oui, imaginez-vous, un individu fait irruption, me met un couteau sous la gorge et se met à me dévaliser ! Moi !!! Vous vous rendez compte, en plein jour...";
			link.l1 = "Pardon de vous interrompre, mais de qui parlez-vous en ce moment ?";
			link.l1.go = "StepPL5Four_3";
		break;
		case "StepPL5Four_3":
			dialog.text = "...tout l'argent qui manque. Comment ça, de qui ?! Du voleur, bien sמr ! Oh, mon argent ! Enfin, peu importe, John Avory va lui montrer ! Avory, c'est une force ! Une puissance !.. Il a eu l'audace de se vanter que j'avais le bras trop court pour l'atteindre aux Bermudes...";
			link.l1 = "Qui ? Avory ?!";
			link.l1.go = "StepPL5Four_4";
		break;
		case "StepPL5Four_4":
			dialog.text = "Mais qu'est-ce qu'Avory vient faire là-dedans ? Le voleur, bien sמr ! וcoutez, pourquoi est-ce que vous m'interrompez tout le temps ?!";
			link.l1 = "Pardon. Et si je vous rapportais le butin ? דa ne vous contrarierait pas trop ?";
			link.l1.go = "StepPL5Four_5";
		break;
		case "StepPL5Four_5":
			dialog.text = "Euh... eh bien... en principe, peu m'importe qui me rend l'argent, mais débrouillez-vous vous-même. Vos affaires avec lui ne me regardent pas.";
			link.l1 = "Pas de problème. John et moi, nous ne vous mêlerons pas à ça. Alors, de combien d'argent parlons-nous ?";
			link.l1.go = "StepPL5Four_6";
		break;
		case "StepPL5Four_6":
			dialog.text = "Cinquante mille ! Si vous me les rapportez tous, votre récompense sera de cinq mille.";
			link.l1 = "Comment s'appelait le voleur ?";
			link.l1.go = "StepPL5Four_7";
		break;
		case "StepPL5Four_7":
			dialog.text = "Vous croyez qu'il s'est présenté ?! Oם avez-vous vu des voleurs aussi polis ? D'ailleurs, John n'a pas posé ce genre de questions.";
			link.l1 = "D'accord. Marché conclu ! Attendez-moi, je reviens bientכt !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_5_Hunter", "9");
			pchar.questTemp.piratesLine = "PL5Hunter_toBermudes";
			npchar.PLQ5Money = true; //метка на ростовщика, которому должен бабла
			//здесь ставим прерывание на вход в дом Орри в Шарп-Тауне
            Pchar.quest.PQ5_inOrryHouse.win_condition.l1 = "location";
            Pchar.quest.PQ5_inOrryHouse.win_condition.l1.location = "Pirates_houseS1";
            Pchar.quest.PQ5_inOrryHouse.function = "PQ5_inOrryHouse";
		break;

		case "StepPL5End_close":
			dialog.text = "C'est mal, vous me décevez beaucoup. J'ai l'impression que vous me cachez quelque chose... Enfin, soit.";
			link.l1 = "Exactement ! Tout va bien, l'ami.";
			link.l1.go = "exit";
			DeleteAttribute(npchar, "PLQ5Money");
    		ChangeCharacterReputation(pchar, -50);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -20);
		break;

		case "StepPL5End_1":
			dialog.text = "Bon sang, que je suis content ! Dites-moi, qu'est-il arrivé à ce salaud qui m'a volé ?";
			link.l1 = "Il a eu ce qu'il méritait, il ne vous embêtera plus...";
			link.l1.go = "StepPL5End_2";
		break;
		case "StepPL5End_2":
			dialog.text = "Parfait, bon, je suis prêt à compter mon argent. Commençons...";
			link.l1 = "Je vous en prie, recevez.";
			link.l1.go = "StepPL5End_3";
		break;
		case "StepPL5End_3":
			dialog.text = "Parfait ! C'est tout simplement parfait ! Tout y est. Voici vos 5 000, comme convenu.";
			link.l1 = "Merci...";
			link.l1.go = "StepPL5End_4";
			DeleteAttribute(npchar, "PLQ5Money");
			AddMoneyToCharacter(pchar, -45000);
    		ChangeCharacterReputation(pchar, 10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 5);
		break;
		case "StepPL5End_4":
			dialog.text = "Eh bien, je suis toujours content de vous voir chez moi. Et je tiens à vous dire que je parlerai à tout le monde de votre zèle et de votre honnêteté. Cet arrogant d'Avory ne vous arrive pas à la cheville, personne ne vous égale...";
			link.l1 = "Vous allez me faire rougir... Bon, au revoir.";
			link.l1.go = "exit";
		break;
		//-------------------- пиратка, квест №5. ---------------->>>>

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////		Кредитный генератор Loan
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		case "LoanUsurer":
			dialog.text = "Discutons. Je vous écoute attentivement.";
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 26)//при низком авторитете даётся гарантированный квест на камень
			{
				link.l1 = "Avez-vous une affaire qui nécessite une aide extérieure ?";
				link.l1.go = "Quest_gemstone";
			}
			else
			{
				link.l1 = "Avez-vous une affaire qui nécessite une aide extérieure ?";
				link.l1.go = "Loan_GiveWork";
			}
			if (npchar.city == "villemstad" && !CheckAttribute(pchar, "questTemp.KSM_DVR_Rostovshik"))	//Квест в Виллемстад "Money in growth"
			{
				link.l1 = "Avez-vous une affaire qui nécessite une aide extérieure ?";
				link.l1.go = "KSM_DVR_1";
			}
			if (npchar.city == "DesMoines" && CheckAttribute(pchar, "questTemp.MCzagadka"))	// Sinistra Иммунитет от квеста "Зачарованный город" (не даём квесты)
			{
				DeleteAttribute(link, "l1");
			}
			if (!CheckAttribute(NPChar,"StorageOpen"))
			{
				link.l11 = "Puis-je louer chez vous un coffre pour mes effets personnels ?";
				link.l11.go = "PersonalStorage";
			}
			else
			{
				link.l11 = "Ouvrez mon coffre.";
				link.l11.go = "PersonalStorage_Open";
			}
			//найти должника
			if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen") && pchar.GenQuest.Loan.FindCitizenNpcharId == NPChar.id)
            {
                link.l2 = "Je viens pour la mission concernant le débiteur.";
                link.l2.go = "FindCitizen_1";
            }
			//доставить сундук
            if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && pchar.GenQuest.LoanChest.ChestNpcharId == NPChar.id)
            {
                link.l3 = "Je viens pour la mission de livraison du prêt.";
                link.l3.go = "TakeChest_1";
            }
            if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
            {
                link.l4 = "Je vous ai apporté votre crédit.";
                link.l4.go = "TakeChest_2";
            }
			// Gregg: [БЕТА] выбор генерируемого варианта должника, как в конторе ГВИК
			if (bBettaTestMode)
			{
				// Gregg: только когда квеста нет - иначе выдача молча стирает идущий экземпляр
				if (!CheckAttribute(pchar, "GenQuest.LoanCap"))
				{
				link.l14 = "[BETA] Menu de test de la quête du débiteur.";
				link.l14.go = "LoanCap_BetaMenu";
				}
			}
			// Gregg: должник-капитан
			// Gregg: экземпляр, сохранённый на прошлой схеме состояния, закрываем -
			// иначе глобальный гейт выдачи встал бы у всех ростовщиков навсегда
			LoanCap_Migrate();
			if (CheckAttribute(pchar, "GenQuest.LoanCap.UsurerId"))
			{
				if (pchar.GenQuest.LoanCap.UsurerId == NPChar.id)
				{
					if (pchar.GenQuest.LoanCap.Stage == "offered")
					{
						link.l12 = "J'ai changé d'avis au sujet de votre capitaine.";
						link.l12.go = "LoanCap_GiveWork_1";
						link.l13 = "Trouvez-vous un autre chasseur pour ce capitaine.";
						link.l13.go = "LoanCap_Refuse";
					}
					else
					{
						link.l12 = "Je viens au sujet du capitaine qui vous doit de l'argent.";
						link.l12.go = "LoanCap_Report";
					}
				}
			}
			//кредиты
            if(CheckAttribute(Pchar, "Quest.Loans." + (NPC_Area)) && makeint(Pchar.Quest.Loans.(NPC_Area)) == true)
			{
				iPastMonths = GetPastTime("Month", makeint(Pchar.Quest.Loans.(NPC_Area).StartYear),makeint(Pchar.Quest.Loans.(NPC_Area).StartMonth),makeint(Pchar.Quest.Loans.(NPC_Area).StartDay), makefloat(Pchar.Quest.Loans.(NPC_Area).StartTime), getDataYear(),getDataMonth(),GetDataDay(), GetTime());
				Pchar.Quest.Loans.(NPC_Area).Result = CalcUsurerSumWithInterest(makeint(Pchar.Quest.Loans.(NPC_Area).Sum), makeint(Pchar.Quest.Loans.(NPC_Area).Interest), iPastMonths+1);// boal 23.01.2004
				if(makeint(PChar.money) >= makeint(Pchar.Quest.Loans.(NPC_Area).Result))
				{
					Link.l5 = "Je vous dois "+ FindRussianMoneyString(sti(Pchar.Quest.Loans.(NPC_Area).Result)) + LinkRandPhrase(". Je peux rembourser ma dette.", ". En ce moment, je suis en mesure de vous rembourser.", ". Il est temps de régler nos comptes, enfin.");
					Link.l5.go = "loan_return";
					sTemp = "credit";
				}
			}
			else
			{
				Link.l6 = LinkRandPhrase("Je veux emprunter de l'argent.", "J'ai un besoin urgent de quelques piastres.", "Que diriez-vous d'un petit prêt ?");
				Link.l6.go = "loan";
				if(makeint(Pchar.money) >= 100)
				{
					Link.l7 = LinkRandPhrase("J'aimerais placer de l'argent pour qu'il fructifie.", "Acceptez-vous de garder du butin pirate ?", "Puis-je laisser un peu d'or pour les mauvais jours ?");
					Link.l7.go = "deposit";
				}
			}
			if(CheckAttribute(Pchar, "Quest.Deposits." + (NPC_Area)) && makeint(Pchar.Quest.Deposits.(NPC_Area)) == true)
			{
				iPastMonths = GetPastTime("Month", makeint(Pchar.Quest.Deposits.(NPC_Area).StartYear),makeint(Pchar.Quest.Deposits.(NPC_Area).StartMonth),makeint(Pchar.Quest.Deposits.(NPC_Area).StartDay), makefloat(Pchar.Quest.Deposits.(NPC_Area).StartTime), getDataYear(),getDataMonth(),GetDataDay(), GetTime());

				DepositResult = makeint(Pchar.Quest.Deposits.(NPC_Area).Sum);
				if (DepositResult > sti(NPChar.UsurerDeposit)*1000) DepositResult = sti(NPChar.UsurerDeposit)*1000;
				DepositResult = DepositResult/100 * makeint(Pchar.Quest.Deposits.(NPC_Area).Interest); //процент с учетом максимальной суммы вклада
				Pchar.Quest.Deposits.(NPC_Area).Result = makeint(Pchar.Quest.Deposits.(NPC_Area).Sum) + DepositResult*iPastMonths;//фикс - теперь могут быть неснятые проценты

				Link.l8 = LinkRandPhrase("Je veux retirer mon dépכt.", "Il est temps de reprendre l'argent que vous gardez pour moi.", "J'ai besoin de mon or et des intérêts accumulés.");
				Link.l8.go = "Deposit_return";
			}
			/* Обмен драгоценных камней */
			link.l10 = "Je veux échanger quelques pierres précieuses.";
			link.l10.go = "Gems_exchange_1";
			//выход
			if (sTemp == "credit")
			{
				link.l9 = LinkRandPhrase("Je me souviens avoir pris un prêt, mais je ne suis pas encore en mesure de rembourser...", "Je sais que je vous dois de l'argent, mais je n'en ai pas en ce moment. Je vous rembourserai plus tard...", "Je me souviens que je vous dois de l'argent, mais pour le moment, je n'ai pas les fonds suffisants pour rembourser le prêt. Je le ferai plus tard.");
				link.l9.go = "Loan_Remind";
			}
			else
			{
				link.l9 = "Erreur de ma part, je n'ai pas d'affaires financières avec vous. Au revoir.";
				link.l9.go = "exit";
			}
		break;
		//Ветка для персонального хранилища
		case "PersonalStorage":
			dialog.text = "Oui, je propose ce service à mes clients. Je peux vous garantir que rien ne disparaîtra jamais de mes chambres fortes. Le service coמte 10 000 piastres d'un coup, puis 1 500 pour chaque mois suivant. La sécurité, c'est une affaire coמteuse et pleine de soucis, vous savez. Voulez-vous vous inscrire ?";
			if (sti(pchar.money) >= 10000)
			{
				link.l1 = "Bien sמr, voici votre argent.";
				link.l1.go = "PersonalStorage_2";
			}
			link.l2 = "Une autre fois, peut-être...";
			link.l2.go = "exit";
		break;
		case "PersonalStorage_2":
			AddMoneyToCharacter(Pchar, -10000);
			NPChar.StorageOpen = "Opened";
			NPChar.StoragePrice = 1500;
			SaveCurrentNpcQuestDateParam(NPChar, "Storage.Date");
			DeleteAttribute(NPChar, "items");
			dialog.text = "Bien, tout est payé, rendez-vous au coffre, je vous prie.";
			link.l1 = "(Ouvrir le coffre)";
			link.l1.go = "PersonalStorage_Open_2";
		break;
		case "PersonalStorage_Open":
			NPChar.MoneyForStorage = GetNpcQuestPastMonthParam(NPChar, "Storage.Date") * sti(NPChar.StoragePrice);
			if(sti(NPChar.MoneyForStorage) > 0)
			{
				dialog.text = "On vous facturera la location du coffre pour encore " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + ".";
				if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
				{
					link.l1 = "D'accord, je paie la location tout de suite.";
					link.l1.go = "PersonalStorage_Open_1";
				}
				else
				{
					link.l1 = "Je reviendrai plus tard.";
					link.l1.go = "exit";
				}
			}
			else
			{
				dialog.text = "... Tout est en ordre, vous pouvez aller à la chambre forte.";
				link.l1 = "(Ouvrir le coffre)";
				link.l1.go = "PersonalStorage_Open_2";
			}
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "exit";
		break;
		case "PersonalStorage_Open_1":
			AddMoneyToCharacter(Pchar, -sti(NPChar.MoneyForStorage));
			SaveCurrentNpcQuestDateParam(NPChar, "Storage.Date");
			dialog.text = "... Tout est en ordre, vous pouvez aller à la chambre forte.";
			link.l1 = "(Ouvrir le coffre)";
			link.l1.go = "PersonalStorage_Open_2";
		break;
		case "PersonalStorage_Open_2":
			DialogExit();
			LaunchItemsBox(npchar);
		break;
		//=============================  даём или не даём работу - сундуки и должники
		case "Loan_GiveWork":
            // проверка на проф пригодность -->
            if (isBadReputation(pchar, 40))
            {
                dialog.text = RandSwear() + "Tu es " + GetFullName(pchar) + ", n'est-ce pas ? " +
                              RandPhraseSimple("Il court des rumeurs terribles sur toi", "On ne dit pas que du bien de toi") + ". Je ne veux pas faire affaire avec toi.";
				link.l1 = RandPhraseSimple("Eh... Quand quelqu'un trébuche, tout le monde lui crache dessus.", RandSwear() + "Eh bien, tant pis !");
				link.l1.go = "exit";
                break;
            }
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 26)//при низком авторитете не даём
			{
            dialog.text = "Non, heureusement, tout va bien pour moi.";
			link.l9 = "Désolé, je dois y aller.";
		    link.l9.go = "exit";
			break;
			}
            // проверка на проф пригодность <--
            dialog.text = "Non, heureusement, tout va bien pour moi.";

			if (npchar.quest.trade_date != lastspeak_date || bBettaTestMode)
			{
                npchar.quest.trade_date = lastspeak_date;
                iNum = rand(3);
                if (sti(Pchar.Ship.Type) == SHIP_NOTUSED)
                {
                    iNum = 0; // всегда первый
                }
                switch (iNum)
                {
					case 0: // найти потерянный драгоценный камень
						if (pchar.questTemp.different == "free" && !CheckAttribute(npchar, "quest.usurersJewel") && GetNpcQuestPastDayWOInit(npchar, "usurersJewel") > 7 && !CheckAttribute(pchar, "questTemp.different.SeekUsurersJewel") && npchar.city != "Charles" && !CheckAttribute(npchar, "quest.slave"))
						{
							dialog.text = "Vous tombez à pic ! Je veux vous confier une mission.";
							link.l1 = "Je vous écoute attentivement. De quoi s'agit-il ?";
							link.l1.go = "usurersJewel_1";
							npchar.quest.usurersJewel = "inSeek"; //личный флаг ростовщика на взятый квест
							SaveCurrentNpcQuestDateParam(npchar, "usurersJewel");
						}
					break;

                    case 1: // доставить сундуки
                        if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest")) break;

                        iNum = findChestMan(Npchar);
                        if (iNum > 0)
                        {
                            chr = &Characters[iNum];
                            pchar.GenQuest.LoanChest.Chest      = 2 + drand(2);
                            pchar.GenQuest.LoanChest.Money      = (3 + cRand(sti(pchar.GenQuest.LoanChest.Chest)))*400 * GetCharacterSPECIALSimple(PChar, SPECIAL_L) + cRand(20)*250;
                            pchar.GenQuest.LoanChest.TargetIdx  =  iNum;
                            pchar.GenQuest.LoanChest.Time       = 20 + rand(15);
							sTemp = "";
							if (npchar.city != chr.city)
							{
								sTemp = " sur l'île de " + XI_ConvertString(GetIslandByCityName(chr.city)+"Voc");
							}
                            dialog.text = "J'ai besoin d'une personne de confiance pour une mission importante. Vous devez livrer un prêt : " + pchar.GenQuest.LoanChest.Chest +
									" coffres d'or à "+ XI_ConvertString("Colony"+chr.city+"Acc") + sTemp + " à un homme nommé " +
									GetFullName(chr) + ". C'est un " + GetWorkTypeOfMan(chr, "") +
									"du coin. Vous recevrez " + FindRussianMoneyString(sti(pchar.GenQuest.LoanChest.Money)) + " pour ce travail. Il faut le faire en " + FindRussianDaysString(sti(pchar.GenQuest.LoanChest.Time)) + ".";
                            link.l1 = "J'accepte !";
                			link.l1.go = "LoanUsurer_ChestWork_1";
            			}
                    break;
					
					case 2 : // найти должника
                        if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizen")) break;

                        if (sti(Pchar.Ship.Type) == SHIP_NOTUSED && sti(npchar.quest.FindCitizenNoShip) < 2)
                        {
                            iNum = findCitizenMan(Npchar, true);
                            npchar.quest.FindCitizenNoShip = sti(npchar.quest.FindCitizenNoShip) + 1; // знатичит на суше без корабля
                        }
                        else
                        {
                            iNum = findCitizenMan(Npchar, false);
                        }
                        if (iNum > 0)
                        {
                            chr = &Characters[iNum];
                            pchar.GenQuest.Loan.FindCitizenMoney   = (7 + cRand(sti(PChar.rank)))*1000 * GetCharacterSPECIALSimple(PChar, SPECIAL_L) + cRand(20)*200 * GetCharacterSPECIALSimple(PChar, SPECIAL_L);
                            pchar.GenQuest.Loan.FindCitizenPercent = makeint(sti(pchar.GenQuest.Loan.FindCitizenMoney) / (3+rand(2)));
                            pchar.GenQuest.Loan.FindCitizenIdx  =  iNum;
							pchar.GenQuest.Loan.FindCitizenChance1 = rand(2);
							pchar.GenQuest.Loan.FindCitizenChance2 = rand(1);
							pchar.GenQuest.Loan.FindCitizenChance3 = rand(1);
							sTemp = "";
							if (npchar.city != chr.city)
							{
								sTemp = " sur l'île de " + XI_ConvertString(GetIslandByCityName(chr.city)+"Voc");
							}
                            dialog.text = "Oui, vous tombez bien. J'ai une affaire délicate à régler. "+
                                     GetFullName(chr) + ", qui vit à " + XI_ConvertString("Colony"+chr.city+"Voc") + sTemp + ", me doit " + FindRussianMoneyString(sti(pchar.GenQuest.Loan.FindCitizenMoney)) +
                                     ". Si vous me rapportez toute la somme, vous pourrez garder les intérêts accumulés. D'ailleurs, ils s'élèvent à " + FindRussianMoneyString(sti(pchar.GenQuest.Loan.FindCitizenPercent)) + ".";
                            link.l1 = "Je m'en charge !";
                			link.l1.go = "LoanUsurer_GiveWork_1";
            			}
                    break;

					// Gregg: должник-капитан. Морской вариант выбивания долга
					case 3:
						LoanCap_Migrate(); // Gregg: см. приветствие
						if (CheckAttribute(pchar, "GenQuest.LoanCap")) break;
						if (CheckAttribute(npchar, "quest.LoanCap")) break;
						// Gregg: ростовщик, которого поймали на завышении, месяц дуется
						if (GetNpcQuestPastDayWOInit(npchar, "LoanCapOffended") <= 30) break;
						if (sti(Pchar.Ship.Type) == SHIP_NOTUSED) break;

						LoanCap_MakeOffer(npchar);

						dialog.text = "J'ai quelque chose de plus sérieux que les querelles de boutiquiers. Le capitaine " + pchar.GenQuest.LoanCap.CapName + ", maître du " +
							pchar.GenQuest.LoanCap.ShipType + " '" + pchar.GenQuest.LoanCap.ShipName + "', me doit " +
							FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.Sum)) + " et a préféré prendre la mer plutכt que de venir me voir. " +
							"Rapportez le principal ; les intérêts accumulés, soit " + FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.Percent)) +
							", sont à vous. Vous avez " + FindRussianDaysString(sti(pchar.GenQuest.LoanCap.Days)) + ".";
						link.l1 = "J'accepte. Oם dois-je le chercher ?";
						link.l1.go = "LoanCap_GiveWork_1";
						link.l2 = "Poursuivre un débiteur à travers tout l'archipel ? Non, merci.";
						link.l2.go = "LoanCap_Refuse";
					break;
    			}
    		}
            else
            {
                dialog.text = "Je vous ai déjà tout dit.";
            }
            link.l9 = "Désolé, je dois y aller.";
		    link.l9.go = "exit";
		break;
		
		case "Quest_gemstone":
            // проверка на проф пригодность -->
            if (isBadReputation(pchar, 40))
            {
                dialog.text = RandSwear() + "Tu es " + GetFullName(pchar) + ", n'est-ce pas ? " +
                              RandPhraseSimple("Il court des rumeurs terribles sur toi", "On ne dit pas que du bien de toi") + ". Je ne veux pas faire affaire avec toi.";
				link.l1 = RandPhraseSimple("Eh... Quand quelqu'un trébuche, tout le monde lui crache dessus.", RandSwear() + "Eh bien, tant pis !");
				link.l1.go = "exit";
                break;
            }
            // проверка на проф пригодность <--
			dialog.text = "Non, heureusement, tout va bien pour moi.";
			// найти потерянный драгоценный камень
			if (pchar.questTemp.different == "free" && !CheckAttribute(npchar, "quest.usurersJewel") && GetNpcQuestPastDayWOInit(npchar, "usurersJewel") > 7 && !CheckAttribute(pchar, "questTemp.different.SeekUsurersJewel") && npchar.city != "Charles" && !CheckAttribute(npchar, "quest.slave"))
			{
				dialog.text = "Vous tombez à pic ! Je veux vous confier une mission.";
				link.l1 = "Je vous écoute attentivement. De quoi s'agit-il ?";
				link.l1.go = "usurersJewel_1";
				npchar.quest.usurersJewel = "inSeek"; //личный флаг ростовщика на взятый квест
				SaveCurrentNpcQuestDateParam(npchar, "usurersJewel");
			}
			link.l9 = "Désolé, je dois y aller.";
		    link.l9.go = "exit";
		break;
		//============== boal нахождение должника ===============
		case "LoanUsurer_GiveWork_1":
            pchar.GenQuest.Loan.FindCitizen = true;
            pchar.GenQuest.Loan.FindCitizenNpcharId = Npchar.id;
            dialog.text = "Parfait. Je vous attends au plus vite.";
			link.l9 = "Je ne vous décevrai pas !";
			link.l9.go = "exit";
            chr = &Characters[sti(pchar.GenQuest.Loan.FindCitizenIdx)];
			sTemp = "";
			if (npchar.city != chr.city)
			{
				sTemp = " sur l'île de " + XI_ConvertString(GetIslandByCityName(chr.city)+"Voc");
			}
			ReOpenQuestHeader("Gen_LoanFindCitizen");
            AddQuestRecord("Gen_LoanFindCitizen", "1");
            AddQuestUserData("Gen_LoanFindCitizen", "sName", GetFullName(chr));
            AddQuestUserData("Gen_LoanFindCitizen", "sCity", XI_ConvertString("Colony"+chr.city+"Voc") + sTemp);
			AddQuestUserData("Gen_LoanFindCitizen", "sFromCity", XI_ConvertString("Colony"+Npchar.city+"Gen"));
			AddQuestUserData("Gen_LoanFindCitizen", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.Loan.FindCitizenMoney)));
			AddQuestUserData("Gen_LoanFindCitizen", "sMyMoney", FindRussianMoneyString(sti(pchar.GenQuest.Loan.FindCitizenPercent)));
		break;

		// Gregg: --> [БЕТА] тестовое меню: выдать должника в заданном варианте
		case "LoanCap_BetaMenu":
			dialog.text = "[BETA] Quelle variante de débiteur faut-il générer ?";
			link.l1 = "Ordinaire : une canaille, la somme est honnête.";
			link.l1.go = "LoanCap_BetaPlain";
			link.l2 = "Débiteur honnête (ruiné).";
			link.l2.go = "LoanCap_BetaHonest";
			link.l3 = "L'usurier a gonflé la dette.";
			link.l3.go = "LoanCap_BetaLied";
			link.l4 = "Débiteur honnête + somme gonflée.";
			link.l4.go = "LoanCap_BetaBoth";
			link.l9 = "Retour.";
			link.l9.go = "exit";
		break;

		case "LoanCap_BetaPlain":
			pchar.questTemp.LoanCapBeta = "plain";
			dialog.text = "[BETA] Variante configurée.";
			link.l1 = "Continuez.";
			link.l1.go = "LoanCap_BetaIssue";
		break;

		case "LoanCap_BetaHonest":
			pchar.questTemp.LoanCapBeta = "honest";
			dialog.text = "[BETA] Variante configurée.";
			link.l1 = "Continuez.";
			link.l1.go = "LoanCap_BetaIssue";
		break;

		case "LoanCap_BetaLied":
			pchar.questTemp.LoanCapBeta = "lied";
			dialog.text = "[BETA] Variante configurée.";
			link.l1 = "Continuez.";
			link.l1.go = "LoanCap_BetaIssue";
		break;

		case "LoanCap_BetaBoth":
			pchar.questTemp.LoanCapBeta = "both";
			dialog.text = "[BETA] Variante configurée.";
			link.l1 = "Continuez.";
			link.l1.go = "LoanCap_BetaIssue";
		break;

		case "LoanCap_BetaIssue":
			// Gregg: чистим текущий экземпляр и кулдауны, потом выдаём заново
			if (sti(Pchar.Ship.Type) == SHIP_NOTUSED)
			{
				DeleteAttribute(pchar, "questTemp.LoanCapBeta");
				dialog.text = "[BETA] Un navire est nécessaire : c'est une quête maritime.";
				link.l9 = "Compris.";
				link.l9.go = "exit";
				break;
			}
			LoanCap_Clear();
			DeleteAttribute(npchar, "LoanCapOffended");
			LoanCap_MakeOffer(npchar);
			dialog.text = "[BETA] Variante configurée, délai réinitialisé. Attribution de la mission.";
			link.l1 = "Continuez.";
			link.l1.go = "LoanCap_GiveWork_1";
		break;
		// Gregg: <-- [БЕТА] тестовое меню

		// Gregg: --> должник-капитан
		case "LoanCap_GiveWork_1":
			pchar.GenQuest.LoanCap.Stage = "seek";
			LoanCap_Launch(npchar);
			npchar.quest.LoanCap = "work";
			dialog.text = "Il a levé l'ancre ici et s'est déclaré à notre capitainerie. Renseignez-vous là-bas, on y tient le registre des départs. Et ne traînez pas : la mer est vaste.";
			link.l9 = "Je m'en occupe.";
			link.l9.go = "exit";
			ReOpenQuestHeader("Gen_LoanCapDebt");
			// Gregg: плейсхолдер ЗАГОЛОВКА заполняется отдельным вызовом - AddQuestUserData
			// цепляется к последней ЗАПИСИ и до заголовка не достаёт
			AddQuestUserDataForTitle("Gen_LoanCapDebt", "sCapName", pchar.GenQuest.LoanCap.CapName);
			AddQuestRecord("Gen_LoanCapDebt", "1");
			AddQuestUserData("Gen_LoanCapDebt", "sCapName", pchar.GenQuest.LoanCap.CapName);
			AddQuestUserData("Gen_LoanCapDebt", "sShipTypeName", pchar.GenQuest.LoanCap.ShipType);
			AddQuestUserData("Gen_LoanCapDebt", "sShipName", pchar.GenQuest.LoanCap.ShipName);
			AddQuestUserData("Gen_LoanCapDebt", "sUsurerName", pchar.GenQuest.LoanCap.UsurerName);
			AddQuestUserData("Gen_LoanCapDebt", "sFromCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("Gen_LoanCapDebt", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.Sum)));
			AddQuestUserData("Gen_LoanCapDebt", "sMyMoney", FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.Percent)));
			AddQuestUserData("Gen_LoanCapDebt", "sTime", FindRussianDaysString(sti(pchar.GenQuest.LoanCap.Days)));
		break;

		case "LoanCap_Refuse":
			dialog.text = "Comme vous voudrez. Quelqu'un de plus accommodant se présentera.";
			link.l9 = "Je n'en doute pas.";
			link.l9.go = "exit";
			LoanCap_Clear();
		break;

		// Gregg: отчёт. Ветка выбирается ОДНОЙ проверкой стадии, а не набором догадок
		// о том, собраны ли деньги. Сколько ГГ несёт - в LoanCap_Held(), сколько
		// ростовщик вправе оставить себе - в LoanCap_Demand(); эти числа стоят и в репликах.
		case "LoanCap_Report":
			link.l9 = "Rien. Laissez tomber.";
			link.l9.go = "exit";
			// Gregg: очная ставка НЕ закрывает квест - она меняет цифру, по которой
			// потом идёт расчёт. Раньше она была отдельной концовкой, и деньги в ней
			// двигались вслепую.
			if (pchar.GenQuest.LoanCap.Knows == "yes")
			{
				link.l4 = "D'abord, à propos de votre chiffre. Il a emprunté " + FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.RealSum)) + ".";
				link.l4.go = "LoanCap_Confront";
			}

			if (pchar.GenQuest.LoanCap.Stage == "seek")
			{
				dialog.text = "Je vous écoute.";
				link.l1 = "Je ne l'ai pas encore trouvé. Je m'en occupe.";
				link.l1.go = "exit";
				break;
			}
			if (pchar.GenQuest.LoanCap.Stage == "fighting")
			{
				dialog.text = "Je vous écoute.";
				link.l1 = "Nous ne sommes pas parvenus à un accord. Ce n'est pas fini.";
				link.l1.go = "exit";
				break;
			}
			if (pchar.GenQuest.LoanCap.Stage == "note")
			{
				dialog.text = "Alors ? Vous l'avez trouvé ?";
				link.l1 = "Oui. Il n'y a rien à prendre : il est ruiné. Voici sa reconnaissance de dette.";
				link.l1.go = "LoanCap_NoteReport";
				break;
			}
			if (pchar.GenQuest.LoanCap.Stage == "prisoner")
			{
				dialog.text = "Alors ? Vous l'avez trouvé ?";
				link.l1 = "Il n'a pas d'argent. Mais il est lui-même dans ma cale.";
				link.l1.go = "LoanCap_CaptiveReport";
				break;
			}
			if (pchar.GenQuest.LoanCap.Stage == "spared")
			{
				dialog.text = "Alors ? Vous l'avez trouvé ?";
				link.l5 = "Je l'ai trouvé. Et je l'ai laissé partir.";
				link.l5.go = "LoanCap_Spared_Report";
				break;
			}
			if (pchar.GenQuest.LoanCap.Stage == "promised")
			{
				dialog.text = "Enfin. Qu'avez-vous pour moi ?";
				link.l3 = "La dette est réglée. Je la paie moi-même : " + FindRussianMoneyString(LoanCap_Demand()) + ".";
				link.l3.go = "LoanCap_SelfPay";
				// Gregg: путь отступления. Без него ГГ, потративший деньги после
				// обещания, не мог ни заплатить, ни отказаться - квест висел вечно.
				link.l6 = "J'ai changé d'avis. Oubliez mon idée à propos de sa dette.";
				link.l6.go = "LoanCap_Renege";
				break;
			}

			// Gregg: paid / forced - деньги у ГГ
			dialog.text = "Enfin. Vous avez l'argent ?";
			link.l1 = "Je l'ai. " + FindRussianMoneyString(LoanCap_Held()) + ", comme convenu.";
			link.l1.go = "LoanCap_Pay";
			link.l2 = "Il n'y a pas d'argent. Considérez que c'est une dette qu'il ne remboursera jamais.";
			link.l2.go = "LoanCap_Keep";
		break;

		// Gregg: очная ставка. Квест НЕ закрывается: ростовщик признаёт настоящую цифру,
		// и дальше расчёт идёт по ней - разницу он возвращает при передаче денег.
		case "LoanCap_Confront":
			// Gregg: обещать возврат разницы можно только если ГГ эту разницу и правда
			// привёз. Снял ровно настоящий долг - возвращать нечего, и говорить об этом
			// нельзя: расчёт потом не двинет ни песо, и реплика окажется враньём.
			dialog.text = "Il vous a donc donné son propre compte... Et vous avez cru le débiteur plutכt que moi. Eh bien, capitaine. Je l'avoue : j'ai arrondi le chiffre à mon avantage. Sa dette est de " + FindRussianMoneyString(LoanCap_RealSum()) + ", et je ne prendrai pas un peso de plus. La différence est à vous dès que nous aurons réglé nos comptes.";
			if (LoanCap_Held() <= LoanCap_RealSum())
			{
				dialog.text = "Il vous a donc donné son propre compte... Et vous avez cru le débiteur plutכt que moi. Eh bien, capitaine. Je l'avoue : j'ai arrondi le chiffre à mon avantage. Sa dette est de " + FindRussianMoneyString(LoanCap_RealSum()) + ". Et vous-même ne lui avez pas pris un peso de plus : moins il y aura de mots entre nous, mieux ce sera.";
			}
			link.l1 = "Voilà qui est mieux.";
			link.l1.go = "LoanCap_Report";
			pchar.GenQuest.LoanCap.Knows = "shown"; // Gregg: предъявлено. Отсюда LoanCap_Demand() считает по настоящему долгу
			ChangeCharacterReputation(pchar, 2);
			// Gregg: запись должна совпадать с репликой. Излишка нет - нет и обещания
			// вернуть разницу, иначе журнал обещает деньги, которых не будет.
			sTemp = "16";
			if (LoanCap_Held() <= LoanCap_RealSum()) sTemp = "26";
			AddQuestRecord("Gen_LoanCapDebt", sTemp);
			SaveCurrentNpcQuestDateParam(npchar, "LoanCapOffended"); // Gregg: пойман на обмане - работы больше не даст
		break;

		// Gregg: расчёт. Ростовщик берёт LoanCap_Demand(), излишек возвращает - это и есть
		// выигрыш ветки с уточнением суммы.
		case "LoanCap_Pay":
			if (sti(pchar.Money) < LoanCap_Held())
			{
				dialog.text = "Vous avez l'argent, dites-vous ? Pourtant, votre bourse est vide. Revenez quand vous l'aurez réuni.";
				link.l9 = "Nous nous reverrons.";
				link.l9.go = "exit";
				break;
			}
			// Gregg: ГГ снял с должника меньше, чем ростовщик считает своим. Так бывает,
			// когда настоящий долг известен, но в лицо ростовщику ещё не сказан.
			if (LoanCap_Shortage() > 0)
			{
				dialog.text = "Je compte... et il en manque. D'après ma reconnaissance de dette, il devait " + FindRussianMoneyString(LoanCap_Demand()) + ", et voici " + FindRussianMoneyString(LoanCap_Held()) + ". Il manque " + FindRussianMoneyString(LoanCap_Shortage()) + ". Soit vous vous expliquez, capitaine, soit vous rapportez le reste.";
				link.l9 = "Je vais m'expliquer.";
				link.l9.go = "exit";
				break;
			}
			dialog.text = "Voilà qui est sérieux. Les intérêts sont à vous, j'ai récupéré ce qui m'appartient. Repassez.";
			// Gregg: излишек считаем от ФАКТИЧЕСКИ снятого, а не от разницы объявленной и
			// настоящей сумм: ГГ мог снять с должника и ту, и другую.
			if (LoanCap_Change() > 0)
			{
				dialog.text = "Comptons. Le principal de la dette est de " + FindRussianMoneyString(LoanCap_Demand()) + ", comme je l'ai reconnu. Vous avez apporté " + FindRussianMoneyString(LoanCap_Change()) + " de trop : reprenez-les, avec les intérêts en plus. Je n'ai plus de travail pour vous, mais un compte est un compte.";
			}
			link.l9 = "Sans faute.";
			link.l9.go = "exit";
			AddMoneyToCharacter(pchar, -1 * LoanCap_Held());
			if (LoanCap_Change() > 0) AddMoneyToCharacter(pchar, LoanCap_Change());
			pchar.GenQuest.LoanCap.Held = 0;
			AddCharacterExpToSkill(pchar, "Commerce", makeint(pchar.rank) * 4);
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 8);
			// Gregg: репутацию за силовой сбор ГГ получил в момент убийства должника,
			// здесь только запись. AddQuestUserData цепляется к ПОСЛЕДНЕЙ записи - строго после неё.
			if (pchar.GenQuest.LoanCap.Stage == "forced")
			{
				AddQuestRecord("Gen_LoanCapDebt", "5");
			}
			else
			{
				AddQuestRecord("Gen_LoanCapDebt", "4");
				AddGoodDeedRepeat(1); // Gregg: доброе дело - долг взыскан без крови
			}
			CloseQuestHeader("Gen_LoanCapDebt");
			AchievementsCounter_genquests(1);
			LoanCap_Clear();
		break;

		// Gregg: расписка вместо денег. Ростовщику она стоит меньше живых песо, и платит
		// он соответственно - половину оговорённых процентов.
		case "LoanCap_NoteReport":
			dialog.text = "Du papier... Enfin, c'est mieux que rien : maintenant, il me doit selon de nouvelles conditions, et un tribunal l'acceptera. Vous ne m'avez pas apporté d'argent, capitaine, alors je vous compterai la moitié : " + FindRussianMoneyString(makeint(LoanCap_Fee() / 2)) + ". Sans rancune.";
			link.l9 = "דa ira.";
			link.l9.go = "exit";
			AddMoneyToCharacter(pchar, makeint(LoanCap_Fee() / 2));
			AddCharacterExpToSkill(pchar, "Commerce", makeint(pchar.rank) * 6);
			AddQuestRecord("Gen_LoanCapDebt", "20");
			AddGoodDeedRepeat(1); // Gregg: доброе дело - разорившегося не тронул
			CloseQuestHeader("Gen_LoanCapDebt");
			AchievementsCounter_genquests(1);
			LoanCap_Clear();
		break;

		// Gregg: должник передан живьём. Корабль и груз ГГ уже забрал формой трофея,
		// здесь только гонорар.
		case "LoanCap_CaptiveReport":
			dialog.text = "Dans votre cale, dites-vous... Eh bien, capitaine, c'est mieux que de l'argent : un débiteur vivant remboursera jusqu'au dernier peso en travaillant, et pendant des années. Amenez-le ici. Les intérêts sont à vous : " + FindRussianMoneyString(LoanCap_Fee()) + ".";
			link.l9 = "Prenez-le.";
			link.l9.go = "exit";
			AddMoneyToCharacter(pchar, LoanCap_Fee());
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 6);
			AddQuestRecord("Gen_LoanCapDebt", "25");
			CloseQuestHeader("Gen_LoanCapDebt");
			AchievementsCounter_genquests(1);
			LoanCap_DeliverCaptive();
			LoanCap_Clear();
		break;

		// Gregg: ГГ закрыл чужой долг из своего кармана - расчёт и награда здесь
		case "LoanCap_SelfPay":
			if (sti(pchar.Money) < LoanCap_Demand())
			{
				dialog.text = "Payer pour lui, dites-vous ? Votre bourse n'est pas de cet avis. Revenez avec l'argent.";
				link.l9 = "Je reviendrai.";
				link.l9.go = "exit";
				break;
			}
			dialog.text = "Avec votre propre argent ? Pour un inconnu ? Enfin, c'est votre affaire, capitaine. La dette est close, la reconnaissance est brמlée. Je ne vous comprends pas, mais je respecte ça.";
			link.l9 = "Pas besoin de comprendre.";
			link.l9.go = "exit";
			AddMoneyToCharacter(pchar, -1 * LoanCap_Demand());
			ChangeCharacterReputation(pchar, 3);
			OfficersReaction("good");
			AddGoodDeedRepeat(1); // Gregg: доброе дело - вытащил человека из долговой ямы
			AddQuestRecord("Gen_LoanCapDebt", "15");
			CloseQuestHeader("Gen_LoanCapDebt");
			AchievementsCounter_genquests(1);
			LoanCap_DebtorTip();
			LoanCap_Clear();
		break;

		// Gregg: ГГ отказался от обещания закрыть чужой долг
		case "LoanCap_Renege":
			dialog.text = "Vous avez changé d'avis. Naturellement. La parole d'un capitaine vaut exactement ce qu'on veut bien payer pour elle. Bonne journée.";
			link.l9 = "Bonjour.";
			link.l9.go = "exit";
			ChangeCharacterReputation(pchar, -5);
			OfficersReaction("bad");
			AddQuestRecord("Gen_LoanCapDebt", "17");
			CloseQuestHeader("Gen_LoanCapDebt");
			LoanCap_Clear();
		break;

		// Gregg: ГГ отпустил должника и пришёл сказать об этом в лицо
		case "LoanCap_Spared_Report":
			dialog.text = "Vous l'avez laissé partir. Vous avez donc décidé de jouer les bienfaiteurs avec mon argent. Curieux. Passez votre chemin, capitaine.";
			link.l9 = "J'y vais.";
			link.l9.go = "exit";
			AddGoodDeedRepeat(1); // Gregg: доброе дело - простил чужой долг
			CloseQuestHeader("Gen_LoanCapDebt");
			AchievementsCounter_genquests(1);
			LoanCap_OffendUsurer();
			LoanCap_Clear();
		break;

		case "LoanCap_Keep":
			dialog.text = RandSwear() + "C'est donc ainsi que vous comprenez notre accord. Très bien. Passez votre chemin, capitaine. Partez, tout simplement.";
			link.l9 = "Bonjour.";
			link.l9.go = "exit";
			// Gregg: присвоить чужой долг - тяжёлый удар по репутации, а не мелкая шалость
			ChangeCharacterReputation(pchar, -12);
			OfficersReaction("bad");
			AddQuestRecord("Gen_LoanCapDebt", "9");
			CloseQuestHeader("Gen_LoanCapDebt");
			LoanCap_SetAmbush();
			LoanCap_Clear();
		break;
		// Gregg: <-- должник-капитан

		case "FindCitizen_1": //проверка выполнения квеста
            dialog.text = "Je suis tout ouïe.";
            if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone"))
            {
                link.l1 = "Votre mission est accomplie !";
                link.l1.go = "finish_work";
                link.l2 = "J'ai réussi à trouver le débiteur, mais je n'ai pas pu lui soutirer l'argent.";
                //if (GetCharacterSkillToOld(PChar, SKILL_FORTUNE) >= rand(11))
               // {
                //    link.l2.go = "finish_work_bad";
                //}
               // else
               // {
                    link.l2.go = "finish_work_lie";
              //  }
            }

            if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
            {
                link.l1 = "J'ai réussi à trouver le débiteur, mais je n'ai pas pu lui soutirer l'argent.";
                link.l1.go = "finish_work_bad";
            }
            link.l3 = "J'ai décidé que votre mission de recherche de débiteur n'est pas pour moi : je l'annule.";
            link.l3.go = "finish_work_cancel";
            //link.l9 = "No. Nothing.";
			//link.l9.go = "exit";
		break;

		case "finish_work":
            if (sti(pchar.Money) >= sti(pchar.GenQuest.Loan.FindCitizenMoney))
            {
                dialog.text = "Voilà qui est bien !";
    			link.l9 = "Je vous en prie !";
    			link.l9.go = "exit";
    			AddMoneyToCharacter(Pchar, -1*sti(pchar.GenQuest.Loan.FindCitizenMoney));
    			DeleteAttribute(pchar, "GenQuest.Loan");
    			DeleteAttribute(Pchar, "quest.LoanFindCitizenTimer");
    			AddCharacterExpToSkill(Pchar, "Commerce", makeint(Pchar.rank) * 3);
    			AddCharacterExpToSkill(Pchar, "Leadership", makeint(Pchar.rank) * 6);
    			ChangeCharacterReputation(pchar, 1);
    			OfficersReaction("good");
    			AddQuestRecord("Gen_LoanFindCitizen", "4");
                CloseQuestHeader("Gen_LoanFindCitizen");
			}
			else
			{
			    dialog.text = "Parfait ! Mais oם est mon argent ? Le temps presse.";
    			link.l9 = "Bientכt !";
    			link.l9.go = "exit";
    		}
		break;

		case "finish_work_bad":
            dialog.text = "C'est très, très mal ! Vous n'êtes pas capable de faire votre travail !";
			link.l9 = "Cet homme n'était vraiment pas riche, mais vous avez raison : c'est mon travail.";
			link.l9.go = "exit";
			DeleteAttribute(pchar, "GenQuest.Loan");
			DeleteAttribute(Pchar, "quest.LoanFindCitizenTimer");
			ChangeCharacterReputation(pchar, -1);
			AddQuestRecord("Gen_LoanFindCitizen", "5");
			AddQuestUserData("Gen_LoanFindCitizen", "sSex", GetSexPhrase("", "e"));
            CloseQuestHeader("Gen_LoanFindCitizen");
		break;

		case "finish_work_cancel":
            if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizenDone") || CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
            {
                dialog.text = "Mais il me semble que vous me trompez ! Je sais avec certitude que vous lui avez parlé. Rendez-moi mon argent !";
                link.l1 = "Oui, vous avez raison, voici l'argent.";
    			link.l1.go = "finish_work";
    			link.l2 = "Mais il a refusé de payer !";
    			if (CheckAttribute(pchar, "GenQuest.Loan.FindCitizenFalied"))
                {
    			   link.l2.go = "finish_work_bad";
    			}
    			else
    			{
    			   link.l2.go = "finish_work_bad_2";
    			}
    			//link.l9 = "I don't have time right now. I'll come back later.";
    			//link.l9.go = "exit";
    			//ChangeCharacterReputation(pchar, -1);
			}
            else
            {
                ChangeCharacterReputation(pchar, -1);
                dialog.text = "C'est mal, je comptais sur vous.";
                link.l1 = "Oui, vous avez raison, mais c'est la vie.";
    			link.l1.go = "exit";
    			DeleteAttribute(pchar, "GenQuest.Loan");
    			DeleteAttribute(Pchar, "quest.LoanFindCitizenTimer");
    			AddQuestRecord("Gen_LoanFindCitizen", "6");
				AddQuestUserData("Gen_LoanFindCitizen", "sSex", GetSexPhrase("", "e"));
                CloseQuestHeader("Gen_LoanFindCitizen");
            }
		break;

		case "finish_work_bad_2":
			ChangeCharacterReputation(pchar, -3);
            dialog.text = "Vous avez déjà montré que le mensonge ne vous fait pas peur. Rendez-moi mon argent !";
			link.l1 = "Je vous dis que je n'ai pas d'argent !";
    		link.l1.go = "finish_work_hanter";
			if (sti(pchar.Money) >= sti(pchar.GenQuest.Loan.FindCitizenMoney))
			{
            link.l2 = "Oui, vous avez raison, voici l'argent.";
    		link.l2.go = "finish_work";
			}
		break;

		case "finish_work_lie":
            dialog.text = "Hum, vraiment ?";
            link.l1 = "Bien sמr !";
    		link.l1.go = "finish_work_cancel";
		break;

		case "finish_work_hanter":
            dialog.text = "Ah, vraiment ? Et vous croyez que je vais en rester là ? Vous allez avoir de gros ennuis, qui vous coמteront bien plus cher que cet argent, je vous le promets. Dehors !";
            link.l1 = "Vous ne me faites pas peur. Bon séjour !";
    		link.l1.go = "exit";
			ChangeCharacterHunterScore(pchar, NationShortName(sti(npchar.Nation)) + "hunter", 40);
			DeleteAttribute(pchar, "GenQuest.Loan");
    		DeleteAttribute(Pchar, "quest.LoanFindCitizenTimer");
    		AddQuestRecord("Gen_LoanFindCitizen", "7");
            CloseQuestHeader("Gen_LoanFindCitizen");
		break;

		//============== boal доставка сундуков ===============
		case "LoanUsurer_ChestWork_1":
            pchar.GenQuest.LoanChest.TakeChest = true;
            pchar.GenQuest.LoanChest.ChestNpcharId = Npchar.id;
            dialog.text = "Je compte beaucoup sur vous.";
			link.l9 = "Je ne vous décevrai pas !";
			link.l9.go = "exit";
			TakeNItems(pchar, "Chest", sti(pchar.GenQuest.LoanChest.Chest));
			SetTimerCondition("LoanChestTimer", 0, 0, sti(pchar.GenQuest.LoanChest.Time), false);
			// немного весёлой жизни
            TraderHunterOnMap();
            chr  = &Characters[sti(pchar.GenQuest.LoanChest.TargetIdx)];
			sTemp = "";
			if (npchar.city != chr.city)
			{
				sTemp = GetConvertStrWithReplace("Variable_which_on", "Interface.txt", "#space#", " ") + XI_ConvertString(GetIslandByCityName(chr.city)+"Voc");
			}
			ReOpenQuestHeader("Gen_LoanTakeChest");
            AddQuestRecord("Gen_LoanTakeChest", "1");
            AddQuestUserData("Gen_LoanTakeChest", "sFromCity", XI_ConvertString("Colony"+Npchar.city+"Gen"));
			AddQuestUserData("Gen_LoanTakeChest", "sQty", pchar.GenQuest.LoanChest.Chest);
			AddQuestUserData("Gen_LoanTakeChest", "sCity", XI_ConvertString("Colony"+chr.city+"Acc") + sTemp);
			AddQuestUserData("Gen_LoanTakeChest", "sName", GetFullName(chr));
			AddQuestUserData("Gen_LoanTakeChest", "sType", GetWorkTypeOfMan(chr, ""));
			AddQuestUserData("Gen_LoanTakeChest", "sMoney", FindRussianMoneyString(sti(pchar.GenQuest.LoanChest.Money)));
			AddQuestUserData("Gen_LoanTakeChest", "sDay", FindRussianDaysString(sti(pchar.GenQuest.LoanChest.Time)));
		break;

		case "TakeChest_1":
            dialog.text = "Je suis tout ouïe.";
            link.l1 = "J'ai décidé que votre mission de livraison de prêt n'est pas pour moi : je l'annule.";
            link.l1.go = "TakeChestFinish_work_cancel";
            link.l9 = "Non. Rien.";
			link.l9.go = "exit";
		break;

		case "TakeChestFinish_work_cancel":
            if (GetCharacterItem(pchar, "Chest") >= sti(pchar.GenQuest.LoanChest.Chest))
            {
                ChangeCharacterReputation(pchar, -1);
                dialog.text = "C'est mal, je comptais sur vous.";
                link.l1 = "Oui, vous avez raison, mais c'est la vie.";
    			link.l1.go = "exit";
    			TakeNItems(pchar, "Chest", -sti(pchar.GenQuest.LoanChest.Chest));
    			DeleteAttribute(pchar, "GenQuest.LoanChest");
    			DeleteAttribute(Pchar, "quest.LoanChestTimer");
                AddQuestRecord("Gen_LoanTakeChest", "5");
				AddQuestUserData("Gen_LoanTakeChest", "sSex", GetSexPhrase("", "e"));
                CloseQuestHeader("Gen_LoanTakeChest");
			}
			else
			{
                dialog.text = "Je serais peut-être prêt à annuler votre mission si vous me RENDEZ tous les coffres.";
                link.l1 = "Je reviendrai plus tard.";
    			link.l1.go = "Exit";
			}
		break;
		//============== кредиты ===============
		case "loan":
            if (sti(NPChar.nation) == PIRATE)
            {
                dialog.text = "Non, je ne peux pas vous aider. Dans notre coin agité, je ne peux proposer que des services de garde d'argent.";
                if(makeint(Pchar.money) >= 100)
				{
	                Link.l1 = "D'accord, voyons le montant.";
	                Link.l1.go = "deposit";
				}
                Link.l2 = "דa ne m'intéresse pas.";
				link.l2.go = "exit";
                break;
            }
			// проверка на проф пригодность -->
            if (isBadReputation(pchar, 40))
            {
                dialog.text = RandSwear() + "Tu es " + GetFullName(pchar) + ", n'est-ce pas ? " +
                              RandPhraseSimple("Il court des rumeurs terribles sur toi", "On ne dit pas que du bien de toi") + ". Je ne veux pas faire affaire avec toi.";
				link.l1 = RandPhraseSimple("Eh... Quand quelqu'un trébuche, tout le monde lui crache dessus.", RandSwear() + " Eh bien, tant pis !");
				link.l1.go = "exit";
                break;
            }
            // проверка на проф пригодность <--
			Dialog.snd = "voice\USDI\USDI016";
			dialog.text = "Oh, je vous en prie. De combien d'argent avez-vous besoin ?";
			Link.l1 = "J'ai besoin d'un prêt à court terme, pour une petite somme";
			Link.l1.go = "Small";
			Link.l2 = "Je voudrais une somme correcte, pour une durée moyenne";
			Link.l2.go = "Medium";
			Link.l3 = "J'ai besoin d'un prêt à long terme, pour une somme très importante.";
			Link.l3.go = "Large";
		break;

		case "small":
			Pchar.Quest.Loans.(NPC_Area).Sum = 5000*makeint(Pchar.rank);
			Dialog.snd = "voice\USDI\USDI017";
			dialog.text = "Excellent. C'est toujours plus simple avec les petites sommes : il y a moins de risques. Je peux vous proposer " + FindRussianMoneyString(sti(Pchar.Quest.loans.(NPC_Area).sum)) + "...";
			Link.l1 = "D'accord. א quel taux ?";
			Link.l1.go = "Interest_1";
			Link.l2 = "Hélas, cette somme ne me convient pas. Changeons-la.";
			Link.l2.go = "Loan";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
			Pchar.Quest.Loans.(NPC_Area).Interest = PcharReputation();
		break;

		case "Medium":
			Pchar.Quest.Loans.(NPC_Area).Sum = 10000*makeint(Pchar.rank);
			Dialog.snd = "voice\USDI\USDI018";
			dialog.text = "Pas de problème. J'espère que " + FindRussianMoneyString(sti(Pchar.Quest.Loans.(NPC_Area).sum)) + " vous aideront à résoudre vos problèmes. C'est une somme assez importante.";
			Link.l1 = "D'accord. א quel taux d'intérêt ?";
			Link.l1.go = "Interest_2";
			Link.l2 = "Hélas, cette somme ne me convient pas. Changeons-la.";
			Link.l2.go = "Loan";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
			Pchar.Quest.Loans.(NPC_Area).Interest = PcharReputation();
		break;

		case "Large":
			Pchar.Quest.Loans.(NPC_Area).Sum = 20000*makeint(Pchar.rank);
			Dialog.snd = "voice\USDI\USDI019";
			dialog.text = "Mmm... C'est risqué... Mais d'accord, je veux bien vous accorder un prêt d'un montant de " + FindRussianMoneyString(sti(Pchar.Quest.Loans.(NPC_Area).sum)) + ". Comme vous le comprenez, capitaine, c'est vraiment beaucoup d'argent. Je vous prie de prendre cette affaire au sérieux.";
			Link.l1 = "D'accord. א quel taux ?";
			Link.l1.go = "Interest_3";
			Link.l2 = "Hélas, cette somme ne me convient pas. Changeons-la.";
			Link.l2.go = "Loan";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
			Pchar.Quest.Loans.(NPC_Area).Interest = PcharReputation();
		break;

		case "Interest_1":
			Dialog.snd = "voice\USDI\USDI020";
			dialog.text = Pchar.Quest.Loans.(NPC_Area).Interest + " % d'intérêt par mois. Vu ce que je sais de vous, je ne peux pas vous offrir de meilleures conditions pour l'instant.";
			Link.l1 = "דa me convient parfaitement. Reste à fixer l'échéance.";
			Link.l1.go = "Period_1";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "Interest_2":
			Dialog.snd = "voice\USDI\USDI020";
			dialog.text = Pchar.Quest.Loans.(NPC_Area).Interest + " % d'intérêt par mois. Vu ce que je sais de vous, je ne peux pas vous offrir de meilleures conditions pour l'instant.";
			Link.l1 = "דa me convient parfaitement. Reste à fixer l'échéance.";
			Link.l1.go = "Period_2";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "Interest_3":
			Dialog.snd = "voice\USDI\USDI020";
			dialog.text = Pchar.Quest.Loans.(NPC_Area).Interest + " % d'intérêt par mois. Vu ce que je sais de vous, je ne peux pas vous offrir de meilleures conditions pour l'instant.";
			Link.l1 = "דa me convient parfaitement. Reste à fixer l'échéance.";
			Link.l1.go = "Period_3";
			Link.l3 = "Je crois qu'il vaut mieux pour moi ne pas m'endetter. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "Period_1":
			Pchar.Quest.Loans.(NPC_Area).Period = 3;
			Dialog.snd = "voice\USDI\USDI021";
			dialog.text =  "Vu ce que j'ai entendu dire de vous, " + Pchar.name + ", j'attendrai le remboursement de ce prêt pendant " + FindRussianMonthString(sti(Pchar.Quest.Loans.(NPC_Area).Period)) + ". Passé ce délai, comme vous le comprenez, je prendrai des mesures.";
			Link.l1 = "Eh bien, j'accepte volontiers vos conditions... Et votre argent.";
			Link.l1.go = "LoanGranted";
			Link.l3 = "Hélas, nous ne sommes pas tombés d'accord. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "Period_2":
			Pchar.Quest.Loans.(NPC_Area).Period = 6;
			Dialog.snd = "voice\USDI\USDI021";
			dialog.text =  "Vu ce que j'ai entendu dire de vous, " + Pchar.name + ", j'attendrai le remboursement de ce prêt pendant " + FindRussianMonthString(sti(Pchar.Quest.Loans.(NPC_Area).Period)) + ". Passé ce délai, comme vous le comprenez, je prendrai des mesures.";
			Link.l1 = "Eh bien, j'accepte volontiers vos conditions... Et votre argent.";
			Link.l1.go = "LoanGranted";
			Link.l3 = "Hélas, nous ne sommes pas tombés d'accord. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "Period_3":
			Pchar.Quest.Loans.(NPC_Area).Period = 12;
			Dialog.snd = "voice\USDI\USDI021";
			dialog.text =  "Vu ce que j'ai entendu dire de vous, " + Pchar.name + ", j'attendrai le remboursement de ce prêt pendant " + FindRussianMonthString(sti(Pchar.Quest.Loans.(NPC_Area).Period)) + ". Passé ce délai, comme vous le comprenez, je prendrai des mesures.";
			Link.l1 = "Eh bien, j'accepte volontiers vos conditions... Et votre argent.";
			Link.l1.go = "LoanGranted";
			Link.l3 = "Hélas, nous ne sommes pas tombés d'accord. Au revoir.";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "LoanGranted":
			Dialog.snd = "voice\USDI\USDI022";
			dialog.text = "J'en suis sincèrement heureux. Mais permettez-moi de vous prévenir. Je fais ce métier depuis longtemps, et je sais récupérer les fonds investis. Alors, si vous aviez l'idée d'empocher mon argent, mieux vaut y renoncer ; je ne veux pas vous offenser, je vous préviens simplement.";
			Link.l1 = "Hum... Bon, bon. Bonne journée.";
			Link.l1.go = "LoanGranted_exit";
		break;

		case "Loan_Remind":
			Dialog.snd = "voice\USDI\USDI023";
			dialog.text = "Eh bien, voyez-vous... Les intérêts tombent goutte à goutte. Et il ne vous reste plus beaucoup de temps.";
			Link.l1 = "Ne vous inquiétez pas. א plus tard.";
			Link.l1.go = "exit";
		break;

		case "loan_return":
			addMoneyToCharacter(Pchar, -(makeint(Pchar.Quest.Loans.(NPC_Area).Result)));
			int iPastDays = GetPastTime(" days", makeint(Pchar.Quest.Loans.(NPC_Area).StartYear),makeint(Pchar.Quest.Loans.(NPC_Area).StartMonth),makeint(Pchar.Quest.Loans.(NPC_Area).StartDay), makefloat(Pchar.Quest.Loans.(NPC_Area).StartTime), getDataYear(),getDataMonth(),GetDataDay(), GetTime());
			AddCharacterExpToSkill(Pchar, "Leadership", makeint(Pchar.Quest.Loans.(NPC_Area).Sum) / 5000 * ((iPastDays+15)/30) );//фикс - опыта начисляем, если прошло пару недель, увеличил бонус - проценты всё равно же платим, и больше чем прокачивая торговлю не сходя с места
			DeleteAttribute(PChar, "quest.Loans_" + NPC_Area); // bug fix
			DeleteAttribute(PChar, "quest.Loans " + NPC_Area);
			Dialog.snd1 = "voice\USDI\USDI024";
			Dialog.snd2 = "voice\USDI\USDI025";
			Dialog.snd3 = "voice\USDI\USDI026";
			dialog.text = LinkRandPhrase("Oh, c'est tout simplement merveilleux ! Chaque fois que vous aurez besoin d'argent, je serai à votre service.", "Merci. C'est très agréable de traiter avec une personne sérieuse qui sait rembourser une dette à temps. Parce que, vous savez, il arrive toutes sortes de choses...",  "Oh, ce n'est pas pour rien que j'avais tant confiance en vous, " + GetAddress_Form(NPChar) + " ! J'espère que ce n'est pas la dernière fois que vous ferez appel à mes services !");
			Link.l1 = LinkRandPhrase("Je veux emprunter de l'argent.", "J'ai un besoin urgent de quelques piastres.", "Que diriez-vous d'un petit prêt ?");
			Link.l1.go = "loan";
			if(makeint(PChar.money) >= 100)
			{
				Link.l2 = LinkRandPhrase("J'aimerais placer mon argent pour qu'il fructifie.", "Acceptez-vous de garder du butin pirate ?", "Puis-je laisser de l'or pour les mauvais jours ?");
				Link.l2.go = "deposit";
			}
			Link.l3 = "Au revoir, " + npchar.name + ".";
			Link.l3.go = "ExitDelLoan1";
		break;

		case "deposit":
			if ( !CheckAttribute(Pchar, "Quest.Deposits." + (NPC_Area)+".Result"))
			{
			    Pchar.Quest.Deposits.(NPC_Area).Result = 0;//fix
			}
			if ( sti(Pchar.Quest.Deposits.(NPC_Area).Result >= sti(NPChar.UsurerDeposit)*1000))
			{
				dialog.text = "Excusez-moi, capitaine, mais la somme que vous m'avez déjà confiée est trop importante pour une banque de province. Je n'ai tout simplement pas de quoi faire fructifier une telle somme pour pouvoir verser des intérêts sur votre dépכt. Et puis, l'absence de protection digne de ce nom, vous savez... Bref, j'espère que vous me comprenez bien ? En tout cas, je ne peux pas accepter plus de " +
						FindRussianMoneyString(MakeMoneyShow(sti(NPChar.UsurerDeposit)*1000, MONEY_SIGN,MONEY_DELIVER)) + ".";
				Link.l1 = "Dommage, je vais devoir m'adresser à un autre usurier.";
				Link.l1.go = "Exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Voilà qui est raisonnable ! Alors, combien d'argent voulez-vous placer ?", "Bien. Croyez-moi, la somme que vous me confierez vous attendra saine et sauve, et même avec des intérêts... D'ailleurs, de quelle somme s'agit-il ?", "Je vois que vous savez comment va la vie. Combien voulez-vous me confier en dépכt ?") + " En tout cas, je ne peux pas accepter plus de " +
							FindRussianMoneyString(MakeMoneyShow(sti(NPChar.UsurerDeposit)*1000 - sti(Pchar.Quest.Deposits.(NPC_Area).Result), MONEY_SIGN,MONEY_DELIVER)) + ".";
				link.l1.edit = 3;
				link.l1 = "";
				Link.l1.go = "result";
			}
		break;

		case "result":
			bool isPatentSameNation = pchar.PatentNation == NationShortName(sti(npchar.nation));
			int iPercents = makeint((GetSummonSkillFromName(pchar, "Commerce")+GetSummonSkillFromName(pchar, "Leadership"))/10.0/4.0 + 0.66) + 1;
			Pchar.QuestTemp.Deposits.(NPC_Area).Interest = iPercents + CheckAttribute(pchar, "EquipedPatentID") *  isPatentSameNation * 2;
			Pchar.QuestTemp.Deposits.(NPC_Area).Sum = dialogEditStrings[3];
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp <= 0)
			{
				dialog.text = "Vous plaisantez ?";
				link.l1 = "Hum, pardon, j'ai fait erreur..";
				link.l1.go = "exit";
				break;
			}
			if (iTemp > sti(pchar.money))
			{
				dialog.text = "Hum, vous n'avez malheureusement pas assez d'argent sur vous. Ne faisons pas les idiots...";
				link.l1 = "Euh... D'accord.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Bien. Je suis disposé à vous proposer des intérêts sur cette somme... mm... disons " + Pchar.QuestTemp.Deposits.(NPC_Area).Interest + " %. Par mois, bien sמr.";
			Link.l1 = "דa me va.";
			Link.l1.go = "Deposit_placed";
			Link.l2 = "Je ferais mieux de changer la somme.";
			Link.l2.go = "Deposit";
			Link.l3 = "On dirait que je ferais mieux de garder mon argent. Bonne journée.";
			Link.l3.go = "Exit";
		break;

		case "Deposit_placed":
			Dialog.snd = "voice\USDI\USDI033";
			if ( !CheckAttribute(Pchar, "Quest.Deposits." + (NPC_Area)+".Result"))
			{
			    Pchar.Quest.Deposits.(NPC_Area).Result = 0;//fix
			}
			// boal limit
			if ( (sti(Pchar.Quest.Deposits.(NPC_Area).Result) + sti(Pchar.QuestTemp.Deposits.(NPC_Area).Sum)) > sti(NPChar.UsurerDeposit)*1000)
			{
			    dialog.text = "Excusez-moi, capitaine, mais cette somme est trop importante pour une banque de province. Je n'ai tout simplement pas de quoi faire fructifier une telle somme pour pouvoir verser des intérêts sur votre dépכt. Et puis, l'absence de protection digne de ce nom, vous savez... Bref, j'espère que vous me comprenez bien ? En tout cas, je ne peux pas accepter plus de " +
						FindRussianMoneyString(MakeMoneyShow(sti(NPChar.UsurerDeposit)*1000, MONEY_SIGN,MONEY_DELIVER)) + ".";
				Link.l1 = "Dommage, je vais devoir m'adresser à un autre usurier.";
				Link.l1.go = "Exit";
			}
			else
			{
				dialog.text = "Désormais, même la plus violente tempête ne vous laissera pas sans moyens de subsistance. Si vous décidez de retirer votre dépכt, venez quand vous voulez.";
				Link.l1 = "Bien. Bonne journée.";
				Link.l1.go = "Deposit_Exit";
			}
		break;

		case "Deposit_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			Pchar.Quest.Deposits.(NPC_Area).Interest = sti(Pchar.QuestTemp.Deposits.(NPC_Area).Interest);
			Pchar.Quest.Deposits.(NPC_Area).Sum      = sti(Pchar.QuestTemp.Deposits.(NPC_Area).Sum);

			AddMoneyToCharacter(Pchar, -(makeint(Pchar.Quest.Deposits.(NPC_Area).Sum)));
			//pchar.questTemp.depositcount = sti(pchar.questTemp.depositcount) + makeint(Pchar.Quest.Deposits.(NPC_Area).Sum);
			//if(sti(pchar.questTemp.depositcount) >= 50000000) UnlockAchievement("bank_money", 3);
			// общий долг
			Pchar.Quest.Deposits.(NPC_Area).Sum = sti(Pchar.Quest.Deposits.(NPC_Area).Result) + sti(Pchar.Quest.Deposits.(NPC_Area).Sum);
			Pchar.Quest.Deposits.(NPC_Area) = true;
			Pchar.Quest.Deposits.(NPC_Area).StartDay = getDataDay();
			Pchar.Quest.Deposits.(NPC_Area).StartMonth = getDataMonth();
			Pchar.Quest.Deposits.(NPC_Area).StartYear = getDataYear();
			Pchar.Quest.Deposits.(NPC_Area).StartTime = getTime();
			CheckForAchievement();
			DialogExit();
		break;

		case "Deposit_return":
			Dialog.snd = "voice\USDI\USDI034";
			dialog.text = "D'après les taux convenus la dernière fois, et compte tenu du temps écoulé, j'ai calculé que je vous dois " + FindRussianMoneyString(sti(Pchar.Quest.Deposits.(NPC_Area).Result)) + "... Vous voulez vraiment retirer cet argent ?";
			Link.l1 = "Absolument. Donnez-moi tout.";
			Link.l1.go = "Deposit_return_1";
			Link.l2 = "J'aimerais reprendre une partie de mon dépכt.";
			Link.l2.go = "Deposit_return_2";
			Link.l3 = "Vous savez, vous avez raison. Qu'il reste encore un peu. Bonne journée.";
			Link.l3.go = "Exit";
		break;

		case "Deposit_return_1":
			addMoneyToCharacter(Pchar, makeint(Pchar.Quest.Deposits.(NPC_Area).Result));
			//pchar.questTemp.depositcount = sti(pchar.questTemp.depositcount) - makeint(Pchar.Quest.Deposits.(NPC_Area).ClearDeposite);
			//pchar.questTemp.depositcount = sti(pchar.questTemp.depositcount) - makeint(Pchar.Quest.Deposits.(NPC_Area).Result);
			//if(sti(pchar.questTemp.depositcount) >= 50000000) UnlockAchievement("bank_money", 3);
			Dialog.snd = "voice\USDI\USDI035";
			dialog.text = "Oh... דa me fait presque de la peine de m'en séparer. Je m'y étais habitué, en quelque sorte. Eh bien, revenez me voir.";
			Link.l1 = "Si nécessaire, je reviendrai. Bon séjour.";
			Link.l1.go = "Exit";
			CheckForAchievement();
			DeleteAttribute(Pchar, "quest.Deposits." + (NPC_Area));
		break;

		case "Deposit_return_2":
			link.l1.edit = 3;
			link.l1 = "";
			Link.l1.go = "Deposit_return_3";
			dialog.text = "Et combien voulez-vous retirer ?";
		break;

		case "Deposit_return_3":
			iTemp = sti(dialogEditStrings[3]);
			CheckForAchievement();
			if (iTemp <= 0 || iTemp > sti(Pchar.Quest.Deposits.(NPC_Area).Sum))
			{
				dialog.text = "Vous plaisantez ?";
				link.l1 = "Hum, pardon, j'ai fait erreur..";
				link.l1.go = "exit";
				break;
			}
			if (iTemp <= sti(Pchar.Quest.Deposits.(NPC_Area).Result))
			{
				AddMoneyToCharacter(pchar,iTemp);
				if (sti(Pchar.Quest.Deposits.(NPC_Area).Result) == iTemp)
				{
					DeleteAttribute(Pchar, "quest.Deposits." + (NPC_Area));
					dialog.text = "Recevez, et signez ici.";
					link.l1 = "Parfait !";
					link.l1.go = "exit";
				}
				else
				{
					Pchar.Quest.Deposits.(NPC_Area).Sum = sti(Pchar.Quest.Deposits.(NPC_Area).Result)-iTemp;
					Pchar.Quest.Deposits.(NPC_Area).Result = Pchar.Quest.Deposits.(NPC_Area).Sum;
					Pchar.Quest.Deposits.(NPC_Area).StartDay = getDataDay();
					Pchar.Quest.Deposits.(NPC_Area).StartMonth = getDataMonth();
					Pchar.Quest.Deposits.(NPC_Area).StartYear = getDataYear();
					Pchar.Quest.Deposits.(NPC_Area).StartTime = getTime();
					dialog.text = "Prenez, et signez ici. Le solde de votre dépכt est de "+FindRussianMoneyString(sti(Pchar.Quest.Deposits.(NPC_Area).Result))+".";
					link.l1 = "Parfait !";
					link.l1.go = "exit";
				}
				//pchar.questTemp.depositcount = sti(pchar.questTemp.depositcount) - iTemp;
				//if(sti(pchar.questTemp.depositcount) >= 50000000) UnlockAchievement("bank_money", 3);
			}
		break;

		case "DeadMotherfucker":
			Dialog.TempNode = "DeadMotherFucker_1";
			Dialog.snd = "voice\USDI\USDI035";
			dialog.text = "Vous êtes encore en vie ? Vous voulez sans doute me rembourser ? Au diable ! א cause de vous, j'ai perdu plus que vous ne pourrez jamais me rendre ! Je n'aurai de repos qu'une fois que j'aurai vu votre cadavre !";
            Link.l1 = "Je veux juste régler nos affaires à l'amiable.";
			Link.l1.go = "LoanRestore_1";
			Link.l2 = LinkRandPhrase("Eh bien, on verra ! Mais n'oubliez pas que vous pourriez facilement devenir un cadavre vous-même !", "Vous me menacez ?! Eh bien, voyons ce que vous allez faire...", "L'argent n'est pas le plus important dans la vie. Il ne faut pas se tuer, ni tuer les autres, pour lui.");
			Link.l2.go = "ExitDelLoan2";
		break;

		case "DeadMotherFucker_1":
			Dialog.snd = "voice\USDI\USDI035";
			dialog.text = "Sortez de chez moi ! Que je ne vous revoie plus !";
			Link.l1 = "...";
			Link.l1.go = "ExitDelLoan2";
            Dialog.TempNode = "DeadMotherFucker_1";
		break;
		// boal обратимость факапства -->
		case "LoanRestore_1":
            iPastMonths = GetPastTime("Month", makeint(Pchar.Quest.Loans.(NPC_Area).StartYear),makeint(Pchar.Quest.Loans.(NPC_Area).StartMonth),makeint(Pchar.Quest.Loans.(NPC_Area).StartDay), makefloat(Pchar.Quest.Loans.(NPC_Area).StartTime), getDataYear(),getDataMonth(),GetDataDay(), GetTime());
			Pchar.Quest.Loans.(NPC_Area).Result = CalcUsurerSumWithInterest(makeint(Pchar.Quest.Loans.(NPC_Area).Sum), makeint(Pchar.Quest.Loans.(NPC_Area).Interest), iPastMonths+1);
			dialog.text = "Oui ? Et que proposez-vous ?";
			Link.l1 = "Je vous dois la somme de " + FindRussianMoneyString(sti(Pchar.Quest.Loans.(NPC_Area).Result)) + ". Je vous la rends.";
			Link.l1.go = "DeadMotherFucker_1";
            if (sti(Pchar.Money) >= 2*sti(Pchar.Quest.Loans.(NPC_Area).Result))
            {
    			Link.l2 = "Pour améliorer nos relations, je vous propose de vous rembourser le double de ma dette : " + FindRussianMoneyString(2*sti(Pchar.Quest.Loans.(NPC_Area).Result)) + ".";
    			Link.l2.go = "LoanRestore_2";
			}
		break;

		case "LoanRestore_2":
			dialog.text = "Voilà qui est autre chose ! On peut encore s'entendre avec vous.";
			Link.l1 = "Merci. Je ne vous décevrai plus.";
			Link.l1.go = "ExitDelLoan2";
			NextDiag.TempNode = "First time";
			addMoneyToCharacter(Pchar, -2*sti(Pchar.Quest.Loans.(NPC_Area).Result));
			DeleteAttribute(PChar, "quest.Loans_" + NPC_Area);
			DeleteAttribute(PChar, "quest.Loans." + NPC_Area);
			ChangeCharacterHunterScore(PChar, NationShortName(sti(NPChar.nation)) + "hunter", -30);
			ChangeCharacterReputation(pchar, 2);
		break;

		case "ExitDelLoan1":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			DeleteAttribute(Pchar, "quest.Loans." + (NPC_Area));
		break;

		case "ExitDelLoan2":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			DeleteAttribute(Pchar, "quest.Loans." + (NPC_Area));
			DeleteAttribute(Pchar, "quest.Deposits." + (NPC_Area));
		break;

        case "LoanGranted_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;

			AddMoneyToCharacter(Pchar, makeint(Pchar.Quest.Loans.(NPC_Area).Sum));
			Pchar.Quest.Loans.(NPC_Area) = true;
			Pchar.Quest.Loans.(NPC_Area).StartDay = getDataDay();
			Pchar.Quest.Loans.(NPC_Area).StartMonth = getDataMonth();
			Pchar.Quest.Loans.(NPC_Area).StartYear = getDataYear();
			Pchar.Quest.Loans.(NPC_Area).StartTime = getTime();

			sTemp = "Loans_" + NPC_Area;
			SetTimerCondition(sTemp, 0, makeint(Pchar.Quest.Loans.(NPC_Area).Period), 0, false);
			pchar.quest.(sTemp).CityId = NPC_Area;
			pchar.quest.(sTemp).win_condition = "LoansForAll";

			DialogExit();
			npchar.quest.trade_date = lastspeak_date; // дыра с прокачкой была
		break;
		//поиски драгоценного камня за гордом
		case "usurersJewel_1":
			sld = ItemsFromID("UsurersJew");
			switch (rand(3))
			{
				case 0:
					sld.JevelType = "un diamant";
					sld.model = "DiamondA";
					sld.picIndex = 2;
					sld.Jewel = "jewelry5";
				break;
				case 1:
					sld.JevelType = "un rubis";
					sld.model = "RubyA";
					sld.picIndex = 3;
					sld.Jewel = "jewelry5";
				break;
				case 2:
					sld.JevelType = "une émeraude";
					sld.model = "EmeraldA";
					sld.picIndex = 4;
					sld.Jewel = "jewelry5";
				break;
				case 3:
					sld.JevelType = "un saphir";
					sld.model = "SapphireA";
					sld.picIndex = 1;
					sld.Jewel = "jewelry5";
				break;
			}
			dialog.text = "Vous savez, un grand malheur m'est arrivé. J'ai perdu " + sld.JevelType + " d'une taille magnifique. Mais le plus désagréable n'est même pas là. Le pire, c'est que cette pierre n'est pas à moi !";
			link.l1 = "Et alors ? Achetez " + sld.JevelType + " de remplacement, et c'est réglé.";
			link.l1.go = "usurersJewel_2";
			npchar.quest.usurersJewel.type = sld.JevelType; //тип камня
			npchar.quest.usurersJewel.money = (cRand(6)+2) * 500 + 1000; //вознаграждение
			npchar.quest.usurersJewel.jewel = sld.Jewel;//камешек
		break;
		case "usurersJewel_2":
			dialog.text = "Oh, si seulement c'était aussi simple ! Le fait est que la pierre en question – " + npchar.quest.usurersJewel.type + " – est unique en son genre. Un client me l'a confiée pour en faire une bague. Je ne trouve rien de semblable par la taille et la forme...";
			link.l1 = "Oh, c'est vraiment un problème. Eh bien, comment puis-je vous aider ?";
			link.l1.go = "usurersJewel_3";
		break;
		case "usurersJewel_3":
			dialog.text = "Retrouvez ma pierre, " + npchar.quest.usurersJewel.type + " : c'est tout ce que je demande !";
			link.l1 = "Oם l'avez-vous perdue ?";
			link.l1.go = "usurersJewel_4";
		break;
		case "usurersJewel_4":
			dialog.text = "Dans la jungle, juste à la sortie de la ville. J'aime parfois m'y promener dans le silence. דa me réconforte...";
			link.l1 = "Voyez-vous, j'exerce un métier un peu différent. Je ne suis ni détective ni "+ GetSexPhrase("valet de pied", "femme de chambre") +". Retrouver vos objets perdus ne m'intéresse pas.";
			link.l1.go = "usurersJewel_out";
			link.l2 = "Euh, bon, je veux bien me charger de chercher la pierre perdue. Quelle est la récompense pour ce travail ?";
			link.l2.go = "usurersJewel_5";
		break;

		case "usurersJewel_out":
			dialog.text = "Mmm, dommage. Apparemment, je me suis trompé sur votre compte. Veuillez m'excuser...";
			link.l1 = "Pas de problème.";
			link.l1.go = "exit";
			DeleteAttribute(npchar, "quest.usurersJewel");
			ChangeCharacterReputation(pchar, -1);
		break;
		case "jewelCancel":
			dialog.text = "Mmm, dommage. Apparemment, je me suis trompé sur votre compte. Veuillez m'excuser...";
			link.l1 = "Pas de problème.";
			link.l1.go = "exit";
			OfficersReaction("good");
			AddQuestRecord("SeekUsurersJewel", "7");
			AddQuestUserData("SeekUsurersJewel", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("SeekUsurersJewel", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			CloseQuestHeader("SeekUsurersJewel");
			DeleteAttribute(npchar, "quest.usurersJewel");
			DeleteAttribute(pchar, "questTemp.different.SeekUsurersJewel");
			// LEO: отказ от квеста -> убираем камень из джунглей, иначе игрок найдёт «ничей» камень (всплывашка «нашёл»), но сдать будет некому (давний баг)
			sld = ItemsFromID("UsurersJew");
			sld.shown = false;
			ChangeCharacterReputation(pchar, -1);
		break;
		case "usurersJewel_5":
			dialog.text = "Si vous retrouvez la pierre perdue, " + npchar.quest.usurersJewel.type + ", je paierai bien. Je tiens à préciser que le temps presse.";
			link.l1 = "Hum, c'est bien. Bon, je pars à sa recherche. Attendez le résultat.";
			link.l1.go = "exit";
			pchar.questTemp.different = "SeekUsurersJewel";
			pchar.questTemp.different.SeekUsurersJewel = true;
			//ложим камень
			sld = ItemsFromID("UsurersJew");
			sld.shown = true;
			sld.startLocation = npchar.city + "_ExitTown";
			sld.startLocator = "item" + (rand(14)+1);
			sld.CityName = XI_ConvertString("Colony" + npchar.city + "Gen");
			Log_QuestInfo("La pierre se trouve au locator " + sld.startLocator);
			SetTimerFunction("SmallQuests_free", 0, 0, 1); //освобождаем разрешалку на миниквесты
			ReOpenQuestHeader("SeekUsurersJewel");
			AddQuestRecord("SeekUsurersJewel", "1");
			AddQuestUserDataForTitle("SeekUsurersJewel", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("SeekUsurersJewel", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("SeekUsurersJewel", "sName", GetFullName(npchar));
			AddQuestUserData("SeekUsurersJewel", "sJewType", npchar.quest.usurersJewel.type);
		break;

		case "usurersJewel_R1":
			dialog.text = "Parfait ! Oui, oui, c'est bien elle, ma pierre perdue, " + npchar.quest.usurersJewel.type + "... Eh bien, je suis heureux, très heureux. Je suis prêt à vous payer une récompense pour votre travail.";
			link.l1 = "Très bien.";
			link.l1.go = "usurersJewel_R2";
			TakeItemFromCharacter(pchar, "UsurersJew");
		break;
		case "usurersJewel_R2":
			dialog.text = "Merci encore. Vous pourrez vous adresser à moi à tout moment, je vous écouterai toujours.";
			link.l1 = "Merci, voyons...";
			link.l1.go = "exit";
			ChangeCharacterReputation(pchar, 2);
			OfficersReaction("good");
			AddCharacterExpToSkill(pchar, "Leadership", 15);
			AddCharacterExpToSkill(pchar, "Fortune", 25);
			AddMoneyToCharacter(pchar, sti(npchar.quest.usurersJewel.money));
			TakeNItems(pchar, npchar.quest.usurersJewel.jewel, 1);
			Log_Info("Vous avez reçu un lingot d'or");
			PlaySound("interface\important_item.wav");
			DeleteAttribute(pchar, "questTemp.different.SeekUsurersJewel");
			AddQuestRecord("SeekUsurersJewel", "6");
			AddQuestUserData("SeekUsurersJewel", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("SeekUsurersJewel", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("SeekUsurersJewel", "sJewType", npchar.quest.usurersJewel.type);
			CloseQuestHeader("SeekUsurersJewel");
			DeleteAttribute(npchar, "quest.usurersJewel");
		break;

        //============== Линейка Блада =============== homo

		case "CapBloodUsurer_1":
			dialog.text = "Je n'accorde pas de fonds aux biens vivants du colonel, monsieur.";
			link.l1 = "Et pourtant, vous l'avez fait.";
			link.l1.go = "CapBloodUsurer_2";
		break;

		case "CapBloodUsurer_2":
			dialog.text = "Quoi ?! De quoi parlez-vous ?";
			if (sti(pchar.money) >= 5000)
			{
    			link.l1 = "Calmez-vous. Je vous apporte le prêt qu'a contracté le vieux canonnier Ogle. Cinq mille tout rond.";
    			link.l1.go = "CapBloodUsurer_3";
            }
            else
            {
    			link.l1 = "Je vous parle du prêt qu'a contracté le vieux canonnier. Cinq mille tout rond. Je vous le rembourse.";
    			link.l1.go = "CapBloodUsurer_4";
            }
		break;


		case "CapBloodUsurer_3":
            AddMoneyToCharacter(pchar, -5000);
            Pchar.questTemp.CapBloodLine.Ogl = true;
            AddQuestRecord("OglQuest", "2");
			dialog.text = "Oh... Merci, monsieur.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "CapBloodUsurer_4":
			dialog.text = "Vous avez apporté l'argent pour Ogle ?";
			if (sti(pchar.money) >= 5000)
			{
    			link.l1 = "C'est exact.";
    			link.l1.go = "CapBloodUsurer_3";
            }
            else
            {
    			link.l1 = "Malheureusement non, mais je l'apporterai bientכt.";
    			link.l1.go = "Exit";
    			NextDiag.TempNode = "CapBloodUsurer_4";
            }
		break;

		case "CapBloodUsurer_5":
			dialog.text = "Un homme de la ville m'a emprunté de l'argent tכt ce matin. Le fait est que... il m'a trompé. Il s'est présenté sous le nom de Raphael Guinness, qui vient souvent me voir, et, à vrai dire, il lui ressemble un peu. Je lui ai prêté 30 000 piastres, mais ensuite, Rafe est entré, et...";
			link.l1 = "Vous voulez que je retrouve cet homme ? Pourquoi pensez-vous qu'il est encore en ville ?";
			link.l1.go = "CapBloodUsurer_6";
		break;

		case "CapBloodUsurer_6":
			dialog.text = "Il est en ville, je vous l'assure. Personne n'a encore pris la mer aujourd'hui. Et vous recevrez 10 % en prime, soit 3 000 piastres. Qu'en dites-vous ?";
			link.l1 = "Vous savez, je crois que je vais vous aider.";
			link.l1.go = "CapBloodUsurer_7";
			link.l2 = "Ne comptez pas sur moi.";
			link.l2.go = "Exit";
			NextDiag.TempNode = "First time";
			PChar.questTemp.CapBloodLine.QuestRaff = false;
		break;

		case "CapBloodUsurer_7":

            AddQuestRecord("UsurerQuest", "1");
            PChar.questTemp.CapBloodLine.QuestRaff = true;
            NextDiag.CurrentNode = "CapBloodUsurer_8";
			DialogExit();
		break;

		case "CapBloodUsurer_8":
			dialog.text = "Alors, vous avez réussi ?";
			if (sti(pchar.money) >= 27000)
			{
    			link.l1 = "Oui, voici votre argent, moins mes dix pour cent.";
    			link.l1.go = "exit";
    			AddMoneyToCharacter(pchar, -27000);
                Pchar.quest.QUsurer.over = "yes";
                NextDiag.TempNode = "First time"; // fix многократной отдачи денег
		   		CloseQuestHeader("UsurerQuest");
            }
            else
            {
    			link.l1 = "Malheureusement non, mais je l'apporterai bientכt.";
    			link.l1.go = "Exit";
    			NextDiag.TempNode = "CapBloodUsurer_8";
            }
		break;
		//работорговец
		int iSlaveMoney;
		int amount;
		case "GiveTaskSlave":
			pchar.questTemp.Slavetrader.iSlaveQuantity = 300 + rand(100);
			pchar.questTemp.Slavetrader.iSlaveMoney = sti(pchar.questTemp.Slavetrader.iSlaveQuantity) * 250;
			dialog.Text = "Oh, laissez donc ! Nous sommes des gens sérieux, inutile de prêter attention aux commérages de toute cette racaille prête à s'étrangler pour un doublon espagnol, mais qui ne lèvera pas le petit doigt pour en faire deux. Je cherche une personne à qui je veux proposer une affaire sérieuse. Quelqu'un de courageux et d'actif, d'honnête et de ponctuel, mais pas encombré... euh... de scrupules excessifs en matière de morale. Et j'espère vraiment trouver cette personne en vous.";
			Link.l1 = "Cela dépendra beaucoup de l'« affaire » que vous allez me proposer.";
			Link.l1.go = "GiveTaskSlave_1";
		break;

		case "GiveTaskSlave_1":
			dialog.Text = "Bien, écoutez. Il n'y a pas d'affaire plus lucrative dans toutes les Caraïbes en ce moment que la traite des esclaves. Je ne suis pas planteur, mais j'ai un acheteur sמr pour cette marchandise, et pas qu'un seul. Bref, il me faut des esclaves, en quantité : " + pchar.questTemp.Slavetrader.iSlaveQuantity + " têtes. Je suis prêt à payer 250 piastres pour chacun d'eux : c'est un bon prix, vous en conviendrez. Le montant total de la transaction sera de " + FindRussianMoneyString(sti(pchar.questTemp.Slavetrader.iSlaveMoney)) + ".";
			Link.l1 = "Non, je ne fais pas dans la traite des esclaves. Cherchez un autre assistant, qui ne s'embarrasse pas de conscience.";
			Link.l1.go = "exit_slaves";
			Link.l2 = "Hum, l'offre est vraiment tentante. Je la prendrais bien. Avec quelle urgence vous faut-il ces esclaves ?";
			Link.l2.go = "GiveTaskSlave_2";
		break;

		case "exit_slaves":
			dialog.Text = "Euh, peu de gens veulent se baisser pour ramasser l'or qui traîne à leurs pieds. Je suis déçu... Adieu, et n'allez pas bavarder sur notre conversation : j'ai le bras long...";
			Link.l1 = "Je vois que vous avez les mains sales... et la langue aussi, d'ailleurs. Bonne journée.";
			Link.l1.go = "exit";
			pchar.questTemp.Slavetrader = "End_quest";
			DeleteAttribute(npchar, "quest.slave");
		break;

		case "GiveTaskSlave_2":
			dialog.Text = "Je ne vous impose pas de délai, mais essayez quand même de vous dépêcher. La demande en « bois d'ébène » est énorme. Si vous faites vos preuves à mes yeux, de telles commandes vous arriveront sans interruption, je vous l'assure.";
			Link.l1 = "Je le crois volontiers. Bon, attendez de bonnes nouvelles.";
			Link.l1.go = "exit";
			pchar.questTemp.Slavetrader = "Seek_slaves"; // это ввод имени квеста и состояния квеста
			AddQuestRecord("Slavetrader", "1");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			AddQuestUserData("Slavetrader", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData("Slavetrader", "sQty", makeint(pchar.questTemp.Slavetrader.iSlaveQuantity));
			AddQuestUserData("Slavetrader", "sSum", makeint(pchar.questTemp.Slavetrader.iSlaveMoney));
		break;

		case "Checkslaves":
			amount = GetSquadronGoods(Pchar, GOOD_SLAVES) - sti(pchar.questTemp.Slavetrader.iSlaveQuantity);
			dialog.Text = "Alors, vous avez réussi à vous procurer le lot convenu de « bois d'ébène » ?";
            if (amount < 0)
			{
				Link.l1 = "Pas encore. Je voulais juste m'assurer que notre accord tient toujours.";
            	Link.l1.go = "exit";
			}
			else
			{
				Link.l1 = "C'est fait. Tout le lot est dans mes cales.";
				if(amount != 0 && (GetSquadronGoods(Pchar, GOOD_SLAVES) <= makeint(sti(pchar.questTemp.Slavetrader.iSlaveQuantity) * 1.5))) Link.l1.go = "TakeMoreslaves1";
				else Link.l1.go = "Takeslaves";
			}

		break;

		case "TakeMoreslaves1":
			dialog.Text = "Je vois que vous avez plus de « bois d'ébène » que convenu. Voulez-vous que je vous prenne tout, au-delà de notre accord ?";
			Link.l1 = "Hum... Oui, prenez tout !";
			Link.l1.go = "TakeMoreslaves2";
			Link.l2 = "Non, mon cher, le reste est pour mes besoins personnels."
			Link.l2.go = "Takeslaves";
		break;

		case "TakeMoreslaves2":
			dialog.Text = "Parfait ! Mes hommes vont les emmener... Ne vous inquiétez pas pour la douane ni pour le commandant du fort. J'ai monté cette affaire en grand, il n'y aura donc aucun problème, et personne ne vous accusera de contrebande.";
			Link.l1 = "Je vois que tout est déjà arrangé ici ! Et le paiement ?";
			Link.l1.go = "TakesMoreslaves3";
		break;

		case "TakesMoreslaves3":
			amount = GetSquadronGoods(Pchar, GOOD_SLAVES);
			RemoveCharacterGoods(Pchar, GOOD_SLAVES, amount);
			AddMoneyToCharacter(pchar, makeint(amount * 250));
			dialog.Text = "Tenez, je vous en prie... Je ne perds pas de mots. Restez avec moi, capitaine, et bientכt, vous aurez tant de piastres qu'il faudra un galion entier pour les transporter !";
			Link.l1 = "Ce serait bien... Bon, et ensuite ?";
			Link.l1.go = "Takeslaves_2";
		break;

		case "Takeslaves":
			amount = sti(pchar.questTemp.Slavetrader.iSlaveQuantity);
			dialog.Text = "Parfait ! Mes hommes vont les emmener... Ne vous inquiétez pas pour la douane ni pour le commandant du fort. J'ai monté cette affaire en grand, il n'y aura donc aucun problème, et personne ne vous accusera de contrebande.";
			Link.l1 = "Je vois que tout est déjà arrangé ici ! Et le paiement ?";
			Link.l1.go = "Takeslaves_1";
			RemoveCharacterGoods(Pchar, GOOD_SLAVES, amount);
		break;

		case "Takeslaves_1":
			AddMoneyToCharacter(pchar, makeint(pchar.questTemp.Slavetrader.iSlaveMoney));
			dialog.Text = "Tenez, je vous en prie... Je ne perds pas de mots. Restez avec moi, capitaine, et bientכt, vous aurez tant de piastres qu'il faudra un galion entier pour les transporter !";
			Link.l1 = "Ce serait bien... Bon, et ensuite ?";
            Link.l1.go = "Takeslaves_2";
		break;

		case "Takeslaves_2":
			dialog.Text = "Ensuite ? Eh bien, revenez dans trois semaines, une grosse commande se prépare. Je pense que tout sera réglé d'ici là.";
			Link.l1 = "D'accord. א bientכt...";
            Link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "2");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			pchar.questTemp.Slavetrader = "wait";
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait");//запомнить дату
		break;

		case "Takeslaves_3":
			if (4-sti(RealShips[sti(pchar.ship.type)].Class) < 0)//проверка класса корабля
			{
				dialog.Text = "Il y aura du travail. Mais il y a un problème : votre navire est faible. Je ne veux pas faire échouer l'affaire, ni vous envoyer à une mort certaine. Puisque le temps presse, procurez-vous un navire plus solide, au moins une barquentine, et de préférence un brick ou une brigantine. א la rigueur, une flמte. Et ne traînez pas, nous risquons de rater le moment.";
				Link.l1 = "Bien sמr, nous allons régler cette question. א plus tard.";
            	Link.l1.go = "Takeslaves_3_smallship";
			}
			else
			{
				dialog.Text = "Enfin ! Je vous attendais. Venons-en au fait. Comme vous le savez, il y a des concurrents dans toutes les affaires. J'en ai, moi aussi. Ces canailles avides et sans scrupules cherchent toujours à vous voler un client sous le nez ! Bref, je veux éliminer l'une de ces canailles et en tirer un bon profit.";
				Link.l1 = "Je suis tout ouïe.";
            	Link.l1.go = "Takeslaves_4";
			}
		break;

		case "Takeslaves_3_smallship":
			pchar.questTemp.Slavetrader = "waitship";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Takeslaves_4":
			Slavetrader_GetRandomShore();//выбор бухты
			pchar.questTemp.Slavetrader.ShipName = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.questTemp.Slavetrader.UnknownPirateName = "l" + rand(GetNamesCount(NAMETYPE_ORIG) - 1);
			dialog.text = "Excellent. Donc. Ce scélérat, surnommé " + GetName( NAMETYPE_ORIG, pchar.questTemp.Slavetrader.UnknownPirateName, NAME_NOM) + " , a amené une cargaison d'esclaves d'Afrique, et il se trouve maintenant en un lieu appelé « " + XI_ConvertString(pchar.questTemp.Slavetrader.Island.Shore + "Gen") + " », sur l'île de " + XI_ConvertString(pchar.questTemp.Slavetrader.Island) + ". Il y attend les contrebandiers. Son galion s'appelle « " + pchar.questTemp.Slavetrader.ShipName + " ». Cette affaire doit être contrecarrée, coמte que coמte !";
			link.l1 = "Hum, et les esclaves ? Pas question de les noyer !";
			link.l1.go = "Takeslaves_5";
		break;

		case "Takeslaves_5":
			dialog.Text = "Pourquoi diable ? " + GetName( NAMETYPE_ORIG, pchar.questTemp.Slavetrader.UnknownPirateName, NAME_NOM) + " est très mal vu, et personne ne sera fâché qu'il disparaisse. Vous capturez le galion, vous l'envoyez par le fond, vous m'apportez la marchandise, et je la vends. D'après mes informations, il a au moins quinze cents esclaves à bord : une énorme cargaison.";
			Link.l1 = "דa alors ! C'est vraiment beaucoup. Et la rémunération ?";
            Link.l1.go = "Takeslaves_6";
			Link.l2 = "Non, mon cher, ces intrigues ne sont pas pour moi. Pourquoi devrais-je me brouiller avec les contrebandiers ?";
            Link.l2.go = "exit_slaves_1";
		break;

		case "exit_slaves_1":
			dialog.Text = "Ouais, on dirait que je me suis trompé sur votre compte... Adieu, et oubliez notre conversation. Et si vous ne voulez pas d'ennuis, je vous conseille de ne pas parler de ce que vous avez entendu ici. Comme vous pouvez le constater, tout est sous contrכle dans ma ville. Et si vous trichez et que vous tentez d'aborder le « " + pchar.questTemp.Slavetrader.ShipName + " » pour votre propre compte, je ferai en sorte qu'on vous pende au gibet. Retenez bien ça.";
			Link.l1 = "Pas d'inquiétude : je ne fais pas dans la dénonciation. Et je n'ai pas besoin non plus de votre galion d'esclaves. Bonne journée.";
            Link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "8");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";//конец квеста, зачищать атрибут нельзя
		break;

		case "Takeslaves_6":
			dialog.Text = "Comme je vous donne toutes les informations sur l'emplacement de la cargaison, ce qui vous évite de courir les mers à la recherche d'une proie, la paie sera, vous le comprenez, un peu plus basse. 200 piastres par esclave. Mais ça reste une somme énorme : environ trois cent mille si tout se passe bien.";
			Link.l1 = "דa me va. Combien de temps ai-je pour l'opération ?";
            Link.l1.go = "Takeslaves_7";
			Link.l2 = "Ho ho ! Vous parlez comme si ces esclaves allaient nager tout seuls jusque dans ma cale ! Vous voulez que mes hommes risquent leur tête sous la mitraille pour un prix aussi ridicule ? Augmentez la récompense, ou je ne le ferai pas.";
            Link.l2.go = "exit_slaves_1";
		break;

		case "Takeslaves_7":
			dialog.text = "Je pense, pas plus de deux semaines. Si vous êtes en retard, il aura le temps de décharger, et l'occasion sera perdue.";
			link.l1 = "Il va falloir se dépêcher. Attendez-moi avec de bonnes nouvelles. א plus tard.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "3");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetrader.ShipName);
			AddQuestUserData("Slavetrader", "sShoreName", XI_ConvertString(pchar.questTemp.Slavetrader.Island.Shore + "Abl"));
			AddQuestUserData("Slavetrader", "sShoreType", XI_ConvertString(GetIslandByArealName(pchar.questTemp.Slavetrader.Island) + "Voc"));
			pchar.quest.Slavetrader_ShipsAttack.win_condition.l1 = "location";
            pchar.quest.Slavetrader_ShipsAttack.win_condition.l1.location = pchar.questTemp.Slavetrader.Island;//отправляем в локацию
            pchar.quest.Slavetrader_ShipsAttack.function = "Slavetrader_CreateSlaveShips";//создание кораблей
			SetFunctionTimerCondition("Slavetrader_SlaveShipsOver", 0, 0, 15, false);	//таймер
			pchar.questTemp.Slavetrader = "wait1";	//это заглушка
		break;

		case "Takeslaves_4_lose":
			dialog.text = "Alors, " + GetFullName(pchar) + ", comment s'est passée l'opération ? א en juger par votre mine abattue, vous avez échoué.";
			link.l1 = "Vous avez bien raison... Je... eh bien... j'ai atteint l'île trop tard. Il avait sמrement déjà levé l'ancre, puisque je n'ai trouvé personne. J'ai dמ louvoyer tout le long : le vent soufflait sans cesse de face, bon sang...";
			link.l1.go = "Takeslaves_5_lose";
		break;

		case "Takeslaves_4_win":
			dialog.text = "Alors, " + GetFullName(pchar) + ", quelle est la prise du jour ? On m'a déjà informé que " + GetName( NAMETYPE_ORIG, pchar.questTemp.Slavetrader.UnknownPirateName, NAME_NOM) + " fait des bulles au fond de l'eau.";
			link.l1 = "Oui, j'ai fait juste à temps ! " + GetName( NAMETYPE_ORIG, pchar.questTemp.Slavetrader.UnknownPirateName, NAME_NOM) + " chargeait les esclaves sur un navire de contrebandiers. J'ai dמ envoyer ses clients rendre visite à Davy Jones par la même occasion, alors vous avez nettement moins de concurrents.";
			link.l1.go = "Takeslaves_5_win";
		break;

		case "Takeslaves_5_lose":
			dialog.text = "Ouais, on dirait que je me suis trompé sur votre compte. Vous avez traîné ? Ou peut-être que vous avez eu la frousse et que vous avez quitté le champ de bataille ? Bon. Peu importe maintenant. Vous avez gâché une excellente idée, et je ne veux plus faire affaire avec vous. Fichez le camp, et oubliez tout ce que vous avez vu et entendu ici.";
			link.l1 = "Eh bien, adieu.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "5_5");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Takeslaves_5_win":
			pchar.questTemp.Slavetrader.Nation = npchar.nation
			amount = 1600 - GetSquadronGoods(Pchar, GOOD_SLAVES);
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			iSlaveMoney = makeint(sTemp)*200;
			if (amount < 0)
			{
				dialog.text = "Je vois que je ne me suis pas trompé sur votre compte : "+ GetSexPhrase("vous êtes un sacré forban", "vous êtes une sacrée flibustière") +". C'est le genre de personne qu'il me faut. Vous avez parfaitement rempli la mission : vous avez plus de mille cinq cents esclaves dans vos cales ! Mais malheureusement, je ne peux accepter que mille six cents unités de marchandise : je n'ai tout simplement pas plus d'argent pour l'instant. Vous devrez vendre le reste des esclaves vous-même. Votre récompense est donc de 320000 piastres.";
				link.l1 = "Merci. C'est un plaisir de faire affaire avec vous, " + npchar.name + " !";
				link.l1.go = "Takeslaves_6_win";
				AddMoneyToCharacter(pchar, 320000);
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, 1600);
				AddQuestRecord("Slavetrader", "6_1");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				break;
			}
			if (amount >= 0 && amount < 200)
			{
				dialog.text = "Je vois que je ne me suis pas trompé sur votre compte : "+ GetSexPhrase("vous êtes un sacré forban", "vous êtes une sacrée flibustière") +". C'est le genre de personne qu'il me faut. Vous avez parfaitement rempli la mission : vous avez amené "+ sTemp +" esclaves. Votre récompense est de " + FindRussianMoneyString(iSlaveMoney) + ".";
				link.l1 = "Merci. C'est un plaisir de faire affaire avec vous, " + npchar.name + " !";
				link.l1.go = "Takeslaves_6_win";
				AddMoneyToCharacter(pchar, makeint(iSlaveMoney));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "6");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoney));
				break;
			}
			if (amount >= 200 && amount < 600)
			{
				dialog.text = "Eh bien, vous avez surmonté une situation difficile avec honneur. Et même si la marchandise est moins abondante que je ne l'espérais, je suis tout de même satisfait. Donc, vous avez amené "+ sTemp +" esclaves. Votre récompense est de " + FindRussianMoneyString(iSlaveMoney) + "";
				link.l1 = "Merci. C'est un plaisir de faire affaire avec vous, " + npchar.name + " !";
				link.l1.go = "Takeslaves_6_win";
				AddMoneyToCharacter(pchar, makeint(iSlaveMoney));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "6");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoney));
				break;
			}
			if (amount >= 600 && amount < 1100)
			{
				dialog.text = "Oui... Bien sמr, c'est compréhensible, mais je comptais sur davantage. Vous n'avez amené que "+ sTemp +" esclaves. Bon, allez, d'un autre cכté, vous avez éliminé la concurrence, ça vaut quelque chose aussi. Votre récompense est de " + FindRussianMoneyString(iSlaveMoney) + ".";
				link.l1 = "Merci. Merci de votre compréhension, " + npchar.name + " !";
				link.l1.go = "Takeslaves_6_win";
				AddMoneyToCharacter(pchar, makeint(iSlaveMoney));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "6");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoney));
				break;
			}
			if (amount >= 1100 && amount < 1600)
			{
				dialog.text = "C'est certainement très divertissant, mais... euh... On dirait que je me suis trompé sur votre compte. Qu'est-ce que vous m'avez apporté ? "+ sTemp +" esclaves ? Et oם est le reste de la marchandise ? Et ne me dites pas que vous l'avez noyée. Vous l'avez vendue aux contrebandiers, ou pire encore, à ce salaud de Voisier, des Bermudes. Disparaissez de ma vue, je ne veux plus rien avoir à faire avec vous.";
				link.l1 = "Portez-vous bien.";
				link.l1.go = "node_hanter_1";
				break;
			}
			dialog.text = "C'est certainement très divertissant, mais... Oם sont les esclaves ? Oם est notre marchandise ? Et ne me dites pas que vous l'avez noyée. Vous l'avez vendue aux contrebandiers, ou pire encore, à ce salaud de Voisier, des Bermudes. Disparaissez de ma vue, je ne veux plus rien avoir à faire avec vous.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "node_hanter_1";
		break;

		case "node_hanter_1":
			dialog.text = "Ce n'est pas tout. Je ne laisse personne me mener par le bout du nez ! Et vous allez payer votre trahison : je vous causerai des ennuis, n'en doutez pas. Maintenant, fichez le camp !";
			link.l1 = "Au diable vous et votre traite d'esclaves !";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "9");
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			ChangeCharacterHunterScore(pchar, NationShortName(sti(pchar.questTemp.Slavetrader.Nation)) + "hunter", 30);
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Takeslaves_6_win":
			dialog.text = "Je vois que nous avons bien travaillé ensemble, " + pchar.name + ". J'en suis très content. Revenez me voir dans un mois environ : je vous trouverai peut-être un travail dans vos cordes. Je prépare justement quelque chose.";
			link.l1 = "Je passerai sans faute ! Travailler avec vous rapporte de bons dividendes.";
			link.l1.go = "Takeslaves_7_win";
		break;

		case "Takeslaves_7_win":
			dialog.text = "דa vous rapportera une fortune... Oui, autre question, " + pchar.name + " : n'avez-vous rien trouvé d'inhabituel dans la cabine du galion lors de l'abordage ?";
			link.l1 = "Non, je n'ai rien vu d'aussi inhabituel. Il devait y avoir quelque chose ?";
			link.l1.go = "Nostatue";
			if (CheckCharacterItem(pchar, "statue1"))
			{
				link.l2 = "Vous voulez parler de cette statue ?";
				link.l2.go = "Yestatue";
			}
		break;

		case "Nostatue":
			dialog.text = "Peut-être que oui, peut-être que non... Bon, si on ne l'a pas trouvée, on ne l'a pas trouvée. On se revoit dans un mois. Au revoir !";
			link.l1 = "א plus tard, " + npchar.name + ".";
			link.l1.go = "exit";
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_1");
			pchar.questTemp.Slavetrader = "wait_1";
		break;

		case "Yestatue":
			dialog.text = "Oui, exactement ! C'est une statue de l'ancien dieu indien Xochipilli. Elle était donc bien dans la cabine de ce salaud... Puis-je la regarder de plus près ?";
			link.l1 = "Bien sמr, tenez.";
			link.l1.go = "Yestatue_1";
			RemoveItems(PChar, "statue1", 1);
		break;

		case "Yestatue_1":
			Log_Info("Vous avez remis la statue de Xochipilli");
			PlaySound("interface\important_item.wav");
			dialog.text = "Bon, bon... Sans aucun doute, c'est bien elle. וcoutez, " + pchar.name + ", vendez-moi cette statue. Je suis prêt à la payer cent mille pièces d'or.";
			link.l1 = "Cent mille ? Hum... J'accepte. Prenez-la !";
			link.l1.go = "Buystatue";
			link.l2 = "Non, je ne la vendrai pas. La valeur de cette statuette ne se mesure pas à l'or qu'on peut en tirer. Je m'y connais en objets de culte indiens.";
			link.l2.go = "Nobuystatue";
		break;

		case "Buystatue":
			dialog.text = "Excellent ! Je suis content que nous soyons d'accord. Prenez votre argent. Et je vous attends dans un mois. Au revoir.";
			link.l1 = "א plus tard, " + npchar.name + ".";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 100000);
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_1");
			pchar.questTemp.Slavetrader = "wait_1";
		break;

		case "Nobuystatue":
			dialog.text = "Voyez-vous, j'ai vraiment besoin de cette statue ! Je suis tout à fait d'accord avec vous : elle n'a pas de valeur marchande, n'importe quel marchand ignorant ne vous en donnerait pas deux mille. Mais puisque vous vous y connaissez vraiment en rituels indiens, et que vous refusez de la vendre pour une telle somme, si vous ne voulez pas d'argent pour elle, je vous propose un échange. J'ai quelque chose qui pourrait vous intéresser. Tenez, regardez. Un magnifique habit de noble ! Tout droit venu d'Europe ! On n'en trouve pas dans les Caraïbes. Tous les gouverneurs ne peuvent pas se vanter d'en posséder un. Appréciez !\n Il vaut bien plus que cent mille, mais sa vraie valeur, vous le comprenez, ne se mesure pas non plus en argent. Je vous propose cet habit en échange de la statue. Elle n'est pas la seule dans les Caraïbes. Vous êtes marin, vous pourrez en trouver d'autres. Mais pour moi, c'est plus difficile. Alors, vous acceptez ?";
			link.l1 = "Héhé... Pourquoi pas, j'accepte. Donnez-moi cet habit, et gardez la statue.";
			link.l1.go = "Nobuystatue_yes";
			link.l2 = "Non. La statue a plus de valeur pour moi que ce magnifique habit. Je la garde.";
			link.l2.go = "Nobuystatue_no";
		break;

		case "Nobuystatue_yes":
			dialog.text = "Excellent ! Je suis content que nous soyons d'accord. Ce superbe vêtement est désormais à vous. Prenez-le. Et je vous attends dans un mois. Au revoir.";
			link.l1 = "א plus tard, " + npchar.name + ".";
			link.l1.go = "exit";
			TakeNItems(pchar, "suit_3", 1);
			Log_Info("Vous avez reçu un habit de noble");
			PlaySound("interface\important_item.wav");
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_1");
			pchar.questTemp.Slavetrader = "wait_1";
		break;

		case "Nobuystatue_no":
			dialog.text = "Dommage, vraiment dommage... Eh bien, reprenez-la. Je ne vous juge pas : la statue a vraiment de la valeur pour un marin. On se revoit dans un mois. Au revoir.";
			link.l1 = "א plus tard.";
			link.l1.go = "exit";
			TakeNItems(pchar, "statue1", 1);
			Log_Info("Vous avez reçu la statue de Xochipilli");
			PlaySound("interface\important_item.wav");
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_1");
			pchar.questTemp.Slavetrader = "wait_1";
		break;

		case "EscapeSlave":
			dialog.text = "Vous tombez à pic, " + pchar.name + ". J'ai une mission, si vous êtes disposé à vous y mettre tout de suite.";
			link.l1 = "Bien sמr, je m'y mets.";
			link.l1.go = "EscapeSlave_1";
		break;

		case "EscapeSlave_1":
			dialog.text = "Parfait ! Venons-en au fait. Vous avez entendu les dernières nouvelles ?";
			link.l1 = "Euh... De quoi parlez-vous ? Il y a beaucoup de nouvelles, et chaque jour, il y en a une autre.";
			link.l1.go = "EscapeSlave_2";
		break;

		case "EscapeSlave_2":
			dialog.text = "Cette nouvelle concerne directement notre affaire. Curaçao a connu la plus massive évasion d'esclaves de l'histoire du Nouveau Monde ! Plus d'un millier d'âmes se sont enfuies, et au passage, plusieurs comptoirs hollandais ont été massacrés et incendiés.";
			link.l1 = "Intéressant. Continuez.";
			link.l1.go = "EscapeSlave_3";
		break;

		case "EscapeSlave_3":
			dialog.text = "Mais ils ne se sont pas contentés de s'évader : ils ont réussi, chose incroyable, à quitter l'île ! Sans laisser de traces. Stuyvesant est furieux. Mais peu importe... L'important, c'est que je vous demande d'aller à Curaçao, de découvrir tous les détails de ce qui s'est passé, de retrouver ces fugitifs et de les capturer, et bien sמr de ne pas les livrer à la justice hollandaise, dont les lois leur réservent un sort très triste, mais de me les amener. Je paierai 300 piastres par esclave : j'ai entendu dire que ce sont de très bons esclaves.";
			link.l1 = "La mission est claire. Je mets le cap sur Curaçao. Attendez-moi avec de bonnes nouvelles.";
			link.l1.go = "EscapeSlave_yes";
			link.l2 = "Vous savez, je ne vais pas faire ça. Je ne priverai pas de leur liberté des gens qui l'ont gagnée au péril de leur vie. Ils la méritent.";
			link.l2.go = "EscapeSlave_no";
		break;

		case "EscapeSlave_no":
			dialog.text = "Dommage, vraiment dommage... Je ne m'attendais pas à un tel coup de votre part, au moment le plus inopportun... Je pense que vous comprenez que notre coopération ne peut pas continuer après ça. Au revoir.";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "8");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "EscapeSlave_yes":
			Slavetrader_GetEscapeShore();
			pchar.questTemp.Slavetrader.ShipName = GenerateRandomNameToShip(HOLLAND);
			pchar.questTemp.Slavetrader = "EscapeSlave_Villemstad";
			AddQuestRecord("Slavetrader", "22_1");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			DialogExit();
		break;

		case "Escape_slaves_win":
			int iSlaveMoneyH;
			string sNum;
			amount = 1100 - GetSquadronGoods(Pchar, GOOD_SLAVES);
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			iSlaveMoney = makeint(sTemp)*300;
			sNum = GetSquadronGoods(Pchar, GOOD_SLAVES) - 1100;
			iSlaveMoneyH = makeint(sNum)*100;
			if (amount < 0)
			{
				dialog.text = "Héhé ! Oui, non seulement vous avez superbement rempli une mission difficile, mais vous avez aussi amené plus d'esclaves que prévu : "+ sTemp +" esclaves. Mais les "+ sNum +" esclaves en trop ne viennent clairement pas des fugitifs de Curaçao. Je paierai 100 piastres pour chacun d'eux. Je suppose que vous ne serez pas lésé. Votre récompense est de 330000 piastres pour le lot principal d'esclaves, et de " + FindRussianMoneyString(iSlaveMoneyH) + " pour le dépassement de la norme, pour ainsi dire.";
				link.l1 = "Ha ha ha, on ne vous la fait pas, à vous ! Faites à votre façon, " + npchar.name + " !";
				link.l1.go = "Escape_slaves_win_1";
				AddMoneyToCharacter(pchar, 330000);
				AddMoneyToCharacter(pchar, makeint(iSlaveMoneyH));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "22_5");
				AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoneyH));
				break;
			}
			if (amount < 101 && amount >= 0)
			{
				dialog.text = "Vous avez parfaitement rempli une mission difficile, et vous avez amené "+ sTemp +" esclaves. Votre récompense est de " + FindRussianMoneyString(iSlaveMoney) + ".";
				link.l1 = "Merci. C'est un plaisir de faire affaire avec vous, " + npchar.name + " !";
				link.l1.go = "Escape_slaves_win_1";
				AddMoneyToCharacter(pchar, makeint(iSlaveMoney));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "22_6");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoney));
				break;
			}
			if (amount >= 100 && amount < 600)
			{
				dialog.text = "Vous avez rempli une mission difficile, et même si la marchandise est moins abondante que je ne l'espérais, je suis tout de même satisfait. Donc, vous avez amené "+ sTemp +" esclaves. Votre récompense est de " + FindRussianMoneyString(iSlaveMoney) + ".";
				link.l1 = "Merci. C'est un plaisir de faire affaire avec vous, " + npchar.name + " !";
				link.l1.go = "Escape_slaves_win_1";
				AddMoneyToCharacter(pchar, makeint(iSlaveMoney));
				RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
				AddQuestRecord("Slavetrader", "22_6");
				AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
				AddQuestUserData("Slavetrader", "sQty", sTemp);
				AddQuestUserData("Slavetrader", "sMoney", makeint(iSlaveMoney));
				break;
			}
			if (amount >= 600 && amount < 1100)
			{
				dialog.text = "Vous les avez trouvés ? Hum... Eh bien, qu'est-ce que vous m'avez apporté ? "+ sTemp +" esclaves ? Et oם est le reste de la marchandise ? Et ne me dites pas que vous l'avez noyée. Vous l'avez vendue aux contrebandiers, ou pire, à ce salaud de Voisier, des Bermudes. Disparaissez de ma vue, je ne veux plus rien avoir à faire avec vous.";
				link.l1 = "Portez-vous bien.";
				link.l1.go = "node_hanter_1";
				break;
			}
			dialog.text = "Vous les avez trouvés ? Oם sont les esclaves ? Oם est notre marchandise ? Et ne me dites pas que vous l'avez noyée. Vous l'avez vendue aux contrebandiers, ou pire, à ce salaud de Voisier, des Bermudes. Disparaissez de ma vue, je ne veux plus rien avoir à faire avec vous.";
			link.l1 = "Portez-vous bien.";
			link.l1.go = "node_hanter_1";
		break;

		case "Escape_slaves_win_1":
			dialog.text = "Je suis très content de vous, " + pchar.name + ". Très content. Revenez dans un mois : d'ici là, je nous aurai préparé une autre affaire lucrative.";
			link.l1 = "Le plaisir est partagé, " + npchar.name + ". Je viendrai sans faute dans un mois.";
			link.l1.go = "exit";
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_2");
			pchar.questTemp.Slavetrader = "wait_2";
		break;

		case "Slaveshore":
			dialog.text = "Vous arrivez à point nommé, " + pchar.name + ". J'ai justement besoin des services d'un marin courageux et pas trop scrupuleux, héhé. Voulez-vous bien faire une course pour moi ?";
			link.l1 = "Oui, je vous écoute attentivement.";
			link.l1.go = "Slaveshore_1";
		break;

		case "Slaveshore_1":
			pchar.questTemp.Slavetrader.Island = Islands[GetCharacterCurrentIsland(pchar)].id;
			pchar.questTemp.Slavetrader.Island.Shore = GetIslandRandomShoreId(pchar.questTemp.Slavetrader.Island);
			pchar.questTemp.Slavetrader.ShipName = GenerateRandomNameToShip(sti(NPChar.nation));
			pchar.questTemp.Slavetrader.Nation = NPChar.nation;
			dialog.text = "Cette fois, c'est très simple. Aujourd'hui, au lieu-dit « " + XI_ConvertString(pchar.questTemp.Slavetrader.Island.Shore + "Gen") + " », a jeté l'ancre la pinasse « " + pchar.questTemp.Slavetrader.ShipName + " », sous le pavillon de " + NationNameGenitive(sti(npchar.nation)) + ". En secret, avec l'aide des contrebandiers du coin, on y a déjà chargé un gros lot de « bois d'ébène », au moins deux mille têtes. L'équipage de la pinasse : de simples matelots de port, un capitaine marchand. Bref, des guerriers sans valeur. Votre tâche est la même que d'habitude : abordez le navire, prenez la marchandise et apportez-la-moi. Paiement selon notre tarif : 200 piastres par unité de marchandise. Tout comme d'habitude.";
			link.l1 = "Hum... Pas tout à fait comme la dernière fois. Vous me proposez d'attaquer un navire de vos compatriotes !";
			link.l1.go = "Slaveshore_2";
		break;

		case "Slaveshore_2":
			dialog.text = "Je ne vous comprends pas bien, " + pchar.name + ". Quelle différence ça fait, la nation de ce navire ? Ou est-ce d'une importance capitale pour vous ?";
			link.l1 = "Pour moi ? Je m'en fiche, l'or n'a pas de nationalité ! דa m'a juste un peu surpris...";
			link.l1.go = "Slaveshore_3_yes";
			link.l2 = "Oui, ça compte. Me brouiller avec " + NationNameAblative(sti(npchar.nation)) + "ne fait pas partie de mes projets.";
			link.l2.go = "Slaveshore_3_no";
		break;

		case "Slaveshore_3_no":
			dialog.text = "Vraiment ? Vous plaisantez ? Bon, si c'est comme ça, alors fichez le camp. Et oubliez tout ce que vous avez vu et entendu ici !";
			link.l1 = "Bon séjour, " + npchar.name + ".";
			link.l1.go = "node_hanter_1";
		break;

		case "Slaveshore_3_yes":
			dialog.text = "Qu'est-ce qui vous a surpris ? Que je ne m'intéresse pas non plus à la nationalité des pièces d'or ? Je vous assure que c'est le cas, et il est étrange que vous ne l'ayez pas encore remarqué. De plus, des préférences patriotiques excessives sont tout simplement nuisibles pour un banquier professionnel, à moins, bien sמr, qu'il ne compte finir ses jours sur le parvis d'une église, mais passons la philosophie. Venons-en au fait : le navire restera dans nos eaux jusqu'à minuit, vous n'avez donc pas beaucoup de temps. On lance l'opération ?";
			link.l1 = "Oui, " + npchar.name + ", je m'y mets immédiatement.";
			link.l1.go = "Slaveshore_4";
		break;

		case "Slaveshore_4":
			dialog.text = "Excellent. Je ne doute pas une seconde du succès de notre entreprise. Bonne chance, " + pchar.name + ".";
			link.l1 = "Merci ! א plus tard.";
			link.l1.go = "exit";
            AddQuestRecord("Slavetrader", "10");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetrader.ShipName);
			pchar.quest.Slavetrader_ShoreAttack.win_condition.l1 = "location";
            pchar.quest.Slavetrader_ShoreAttack.win_condition.l1.location = pchar.questTemp.Slavetrader.Island;//отправляем в локацию
            pchar.quest.Slavetrader_ShoreAttack.function = "Slavetrader_CreateShoreShips";//создание кораблей
			SetFunctionTimerCondition("Slavetrader_ShoreShipsOver", 0, 0, 1, false);	//таймер
			pchar.questTemp.Slavetrader = "wait1";	//заглушка
		break;

		case "Pinas_lose":
		dialog.text = "Alors, " + GetFullName(pchar) + ", comment s'est passée l'opération ? א en juger par votre mine abattue, vous avez échoué.";
			link.l1 = "Vous avez bien raison... Je... eh bien... trop tard. Je me suis attardé à la taverne, et quand je suis sorti, il n'y avait plus personne en mer.";
			link.l1.go = "Takeslaves_5_lose";
		break;

		case "Slaveshore_5":
			dialog.text = "" + pchar.name + "Calmez-vous, je vous en prie. Ce n'est pas ma faute ! Bon sang, on m'a prévenu trop tard... C'est une trahison ! L'un de mes hommes de confiance m'a piégé !";
			link.l1 = "Bon, je vois que vous ne mentez pas. Heureusement pour vous, le capitaine de la pinasse a lâché avant de mourir que nos affaires étaient découvertes. Sans cette phrase, je vous aurais déjà achevé... Mais vous m'aviez dit, maudit sac d'écus, que tout était sous contrכle ici, sur l'île !";
			link.l1.go = "Slaveshore_6";
		break;

		case "Slaveshore_6":
			dialog.text = "L'embuscade n'a pas été organisée par les autorités locales, sinon j'en aurais tout su... " + pchar.name + ", ce n'est pas le moment de jurer et de s'insulter. Vous et moi sommes tous deux en danger de mort : nous avons été trahis par l'un de mes anciens associés, mais nous avons réussi à apprendre que toutes les preuves réunies, un paquet de documents, sont en route vers notre gouverneur général. Si elles tombent entre ses mains, nous sommes finis ! Et vous en premier, d'ailleurs.";
			link.l1 = "Alors, c'est ce que voulait dire ce gredin de capitaine !";
			link.l1.go = "Slaveshore_7";
		break;

		case "Slaveshore_7": //выбор острова, куда бригантина пойдёт
			switch (sti(NPChar.nation))
            {
                case HOLLAND :
					pchar.questTemp.Slavetraderbrig.Island = "Curacao";
                break;
                case FRANCE :
					pchar.questTemp.Slavetraderbrig.Island = "Tortuga";
                break;
                case SPAIN :
					pchar.questTemp.Slavetraderbrig.Island = "Cuba2";
                break;
                case ENGLAND :
					pchar.questTemp.Slavetraderbrig.Island = "Jamaica";
                break;
			}
			pchar.questTemp.Slavetraderbrig.ShipName = GenerateRandomNameToShip(sti(NPChar.nation));//имя бригантины
			pchar.questTemp.Slavetrader.Nation = NPChar.nation;
			dialog.text = "וcoutez bien. Nous avons encore une chance. Le paquet a été envoyé par la brigantine « " + pchar.questTemp.Slavetraderbrig.ShipName + " ». C'est tout ce que je sais. Les papiers sont emportés chez le gouverneur général, à sa résidence sur l'île de " + XI_ConvertString(pchar.questTemp.Slavetraderbrig.Island) + ". Vous devez l'intercepter, l'aborder et trouver ces documents compromettants.";
			link.l1 = "C'est tout ce que j'ai à faire. Eh bien, priez pour vous et pour moi, et espérez que je la rattraperai. Et à mon retour, nous reprendrons cette conversation. Et ne croyez pas que je vais en rester là !";
			link.l1.go = "Slaveshore_8";
			AddQuestRecord("Slavetrader", "14");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetraderbrig.ShipName);
			AddQuestUserData("Slavetrader", "sIsland", XI_ConvertString(GetIslandByArealName(pchar.questTemp.Slavetraderbrig.Island)));
			pchar.quest.Slavetrader_BrigAttack.win_condition.l1 = "location";
            pchar.quest.Slavetrader_BrigAttack.win_condition.l1.location = pchar.questTemp.Slavetraderbrig.Island;//отправляем в локацию
            pchar.quest.Slavetrader_BrigAttack.function = "Slavetrader_CreateBrig";//создание бригантины
			SetFunctionTimerCondition("Slavetrader_BrigOver", 0, 0, 15, false);	//таймер
			pchar.questTemp.Slavetrader = "wait1";	//это нода ожидания, пустая
		break;

		case "Slaveshore_8":
			dialog.text = "L'essentiel, c'est de trouver le paquet ! Je ne serai en sécurité que si vous me le rapportez... Bon sang... " + pchar.name + ", on dirait que nous avons un problème...";
			link.l1 = "Qu'y a-t-il encore ?";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("Slavetrader_enterSoldiers");
			break;

		case "Brig_lose":
			dialog.text = "Malédiction... Et moi qui comptais tant sur vous, " + pchar.name + ". Bon, nous ne pouvons plus faire affaire ensemble. Si je n'arrive pas à étouffer l'enquête à prix d'or, je serai obligé de m'enfuir. Et je ne vous conseille pas de rester ici non plus : les soldats peuvent débarquer à tout moment. Adieu.";
			link.l1 = "Au revoir, " + npchar.name + ".";
			link.l1.go = "exit";
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Letter_lose":
			dialog.text = "Ils y étaient. J'en suis certain. Bon, nous ne pouvons plus faire affaire ensemble : ce n'est plus sמr. Adieu.";
			link.l1 = "Au revoir, " + npchar.name + ".";
			link.l1.go = "exit";
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Brig_win":
			dialog.text = "Parfait ! Je n'ai pas douté de vous une seule minute, " + pchar.name + ". Remettez-moi les papiers, je vous en prie, sinon je n'aurai pas l'esprit tranquille.";
			link.l1 = "Tenez.";
			link.l1.go = "Brig_win_1";
		break;

		case "Brig_win_1":
			RemoveItems(PChar, "letter_1", 1);
			dialog.text = "Excellent... Maintenant, vous pouvez être tranquille. Le gouverneur général n'apprendra rien, et j'ai déjà réglé toutes les questions avec les autorités locales, même si j'ai dמ beaucoup m'agiter, croyez-moi.";
			link.l1 = "Tout cela est bien beau, mais ne pensez-vous pas que vous devriez me dédommager du préjudice moral et matériel causé par vos actes irréfléchis ?";
			link.l1.go = "Brig_win_2";
		break;

		case "Brig_win_2":
			dialog.text = "Absolument, " + pchar.name + ". De plus, je vous dois beaucoup. Et j'ai hâte de poursuivre notre coopération. Mais je vous prie de comprendre ma situation : j'ai engagé d'énormes dépenses ; la loyauté du gouverneur et du commandant ne coמte pas rien. En plus, j'ai dמ étouffer le meurtre d'une patrouille dans ma résidence...";
			link.l1 = "Vous voulez dire que vous n'avez pas l'intention de couvrir mes pertes ?!";
			link.l1.go = "Brig_win_3";
		break;

		case "Brig_win_3":
			dialog.text = "Ne vous emportez pas, " + pchar.name + ". J'ai vraiment des problèmes d'argent en ce moment, alors je vous propose un règlement d'un genre un peu différent.";
			link.l1 = "Alors, je vous écoute attentivement.";
			link.l1.go = "Brig_win_4";
		break;

		case "Brig_win_4":
			dialog.text = "Il y a environ un an, mon associé et moi avons été pris dans une violente tempête au large de la cכte sud de la Terre Ferme. Les navires se sont brisés sur les rochers près de Boca de la Sierpe, et bien qu'ils n'aient pas tenu longtemps à flot, nous avons réussi à mettre notre cargaison à terre : des coffres de bijoux, qui contenaient un gros lot de pierres et de joyaux. La baie est accueillante, là-bas, et il n'a pas été difficile de cacher les trésors, mais dès que la tempête s'est calmée, les Indiens nous ont attaqués. C'est ainsi que sont morts les quelques survivants du naufrage, dont mon associé. Avec une poignée de marins, j'ai réussi à m'enfuir en chaloupe, nous avons atteint Cumaná sans encombre, mais je n'ai pas osé retourner chercher les coffres. Je suis sמr que les sauvages du coin protègent bien leur cכte contre les intrusions, et mon trésor par la même occasion. Mais vous êtes "+ GetSexPhrase("un homme fort et courageux", "une femme forte et courageuse") +" : vous saurez très bien vous débrouiller avec cette bande de Peaux-Rouges, et il y a vraiment beaucoup de bijoux là-bas : ils couvriront toutes les pertes que vous avez subies, ainsi que les frais de l'expédition vers le sud de la Terre Ferme.";
			link.l1 = "Hum... D'accord. Alors, je crois que je vais aller à Cumaná. J'espère que vous ne me mentez pas. Et n'oubliez pas : si vous essayez de me rouler, je vous retrouverai, même sous terre !";
			link.l1.go = "Brig_win_5";
		break;

		case "Brig_win_5":
			dialog.text = "Vous pouvez en être sמr, " + pchar.name + ", tout ce que j'ai dit est vrai. Bon, je vous attends dans un mois environ : j'ai déjà en vue une affaire qui doit renforcer la position chancelante de mon commerce. א plus tard.";
			link.l1 = "א plus tard, " + npchar.name + ".";
			link.l1.go = "exit";
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_3");
			pchar.questTemp.Slavetrader = "wait_3";
			pchar.GenQuestRandItem.Shore18 = true;
			pchar.GenQuestRandItem.Shore18.randitem1 = "sculMa1";
			Pchar.quest.Slavetrader_Bonanza.win_condition.l1 = "location";
            Pchar.quest.Slavetrader_Bonanza.win_condition.l1.location = "Shore18";
            Pchar.quest.Slavetrader_Bonanza.function = "Slavetrader_Bonanza";
		break;

		case "SlaveGalleon":
			dialog.text = "Vous voilà, " + pchar.name + ". Parfait, vous êtes à l'heure, comme toujours. Avant d'en venir au cœur du sujet, j'aimerais vous informer de la situation actuelle du marché aux esclaves dans l'archipel. Je pense que ça vous sera utile. Savez-vous ce que signifie le mot « repartimientos » ?";
			link.l1 = "Hum... Non, " + npchar.name + ", je ne sais pas ce que c'est. Mais à l'oreille, ça ressemble à « prendre quelque chose à quelqu'un ». J'ai raison ?";
			link.l1.go = "SlaveGalleon_1";
		break;

		case "SlaveGalleon_end":
			dialog.text = "Vous m'avez vraiment surpris. Qu'attendiez-vous de moi ? Dehors !";
			link.l1 = "Les affaires illégales, et plus encore le trafic d'êtres humains, c'est trop déprimant moralement. Bon séjour.";
			link.l1.go = "node_hanter_1";
		break;

		case "SlaveGalleon_1":
			dialog.text = "Vous êtes très proche de la vérité, " + pchar.name + ". Il s'agit bien de prendre, et précisément, la liberté. Le repartimiento est une façon rusée d'asservir les Indiens sous des prétextes pseudo-légaux plausibles, pacifiquement, pour ainsi dire. Les autorités espagnoles l'emploient envers la population indigène de la Terre Ferme. Voulez-vous entendre les détails ?";
			link.l1 = "Pourquoi pas ?";
			link.l1.go = "SlaveGalleon_2";
		break;

		case "SlaveGalleon_2":
			dialog.text = "Des représentants de la Couronne espagnole visitent les villages indiens. Là, par une tromperie cynique et sous la menace directe, ils forcent les Indiens à leur acheter à des prix fabuleux toutes sortes de camelote inutile : viande avariée, vieux rasoirs et autres. Et à crédit, en plus ; au bout d'un certain temps, disons un an, les envoyés reviennent et exigent le paiement. Si les Indiens ne peuvent pas payer, et c'est le plus souvent le cas, les Espagnols emmènent une partie des hommes valides, soi-disant pour un temps, afin qu'ils remboursent leur dette en travaillant et « apprennent à cultiver la terre » ; vous comprenez que ces Indiens ne reviennent jamais dans leurs villages. C'est ainsi que nos crédules frères à la peau rouge finissent dans les plantations de canne à sucre et les comptoirs d'acajou.";
			link.l1 = "Héhé, eh bien, il fallait y penser... Les Indiens ne résistent pas quand on les emmène comme esclaves ? Ou ils ne comprennent pas ?";
			link.l1.go = "SlaveGalleon_3";
		break;

		case "SlaveGalleon_3":
			dialog.text = "Ils comprennent sans doute, mais peu osent protester ouvertement quand on leur met sous le nez un papier portant l'empreinte du pouce de leur chef. Bien sמr, cette tactique s'emploie plutכt contre des tribus pacifiques, comme les Arawaks, par exemple, ou les Miskitos. Avec les belliqueux Itzás et les Akawaïos, et plus encore les Caraïbes, ce genre de manœuvre ne marche pas : là-bas, même la force ne suffit pas toujours. Mais passons directement à votre mission.";
			link.l1 = "Je sens déjà l'odeur du gros argent ! Je vous écoute, " + npchar.name + ".";
			link.l1.go = "SlaveGalleon_4";
		break;

		case "SlaveGalleon_4":
			Slavetrader_GetHispanShore();
			sTemp = pchar.questTemp.SlavetraderAreal.add;
			pchar.questTemp.Slavetrader.ShipName = GenerateRandomNameToShip(SPAIN);
			dialog.text = "Un galion lourd nommé " + pchar.questTemp.Slavetrader.ShipName + " partira " + sTemp + " dans quelques jours. Il transporte une énorme cargaison d'esclaves, environ 3 000 personnes : des Indiens, amenés de divers villages du bas Orénoque, capturés selon la tactique des repartimientos. Le galion se rend à Santiago : les plantations de sucre de Cuba ont cruellement besoin de main-d'œuvre. Votre tâche est de capturer ce galion avec sa cargaison. Le paiement de la marchandise est, comme d'habitude, de 200 piastres par unité.";
			link.l1 = "Héhé ! C'est tentant. J'accepte.";
			link.l1.go = "SlaveGalleon_5";
			link.l2 = "Vous savez, vos repartimientos ne me plaisent pas, c'est trop cynique. Je crois que je ne vais pas me charger de cette affaire.";
			link.l2.go = "SlaveGalleon_end";
		break;

		case "SlaveGalleon_5":
			sTemp = pchar.questTemp.SlavetraderAreal.add;
			dialog.text = "Eh bien, alors, je vous souhaite bonne chance. Gardez à l'esprit que ce galion est commandé par un officier de marine très expérimenté. Le combat contre lui ne sera pas facile, alors préparez-vous bien. Et ne perdez pas de temps : il lui faudra quinze à vingt jours pour aller " + sTemp + " à Santiago. Tâchez de ne pas le manquer, ouvrez l'œil : vous distinguerez facilement ce galion des autres navires ! J'allais oublier ! En plus, le navire sera rempli de toutes sortes de babioles indiennes : les Peaux-Rouges paient leurs dettes avec les produits de leur artisanat et des objets de culte. Si vous trouvez quelque chose d'inhabituel sur le galion, emportez-le absolument et apportez-le-moi : je paierai généreusement chaque trouvaille de valeur.";
			link.l1 = "Je vous comprends. Je pars immédiatement.";
			link.l1.go = "exit";
			SlavetraderGalleonInWorld();
			SetFunctionTimerCondition("Slavetrader_SlaveGalleonOver", 0, 0, 21, false);
			pchar.questTemp.Slavetrader = "wait1";
			AddQuestRecord("Slavetrader", "18");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetrader.ShipName);
			AddQuestUserData("Slavetrader", "sAreal", sTemp);
		break;

		case "Lostgalleon":
			dialog.text = "Eh, " + pchar.name + ", c'était mon dernier espoir... C'est pour ça que je vous ai confié l'affaire : personne d'autre n'aurait pu s'en charger, de toute façon... Mais, apparemment, vous non plus. Bon, disons-nous adieu. Après l'échec d'hier et les mauvaises rumeurs qui ont suivi, toute ma clientèle a fui. Je suis pratiquement ruiné, et je vais peut-être devoir quitter cette ville. Mais je ne vous en veux pas : la tâche était très difficile. Eh... Adieu, " + pchar.name + ".";
			link.l1 = "Je regrette vraiment, " + npchar.name + " que tout se soit passé ainsi. Sincèrement. Peut-être que les choses vont encore s'arranger. Au revoir.";
			link.l1.go = "exit";
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Wingalleon":
			pchar.questTemp.Slavetrader.Nation = npchar.nation;
			amount = 3000 - GetSquadronGoods(Pchar, GOOD_SLAVES);
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			iSlaveMoney = makeint(sTemp)*200;
			if(amount < 1)
			{
				dialog.text = "Ouf, quel soulagement... Ce n'est pas pour rien que je vous ai fait confiance, pas pour rien... Mais pourquoi cette ironie ? Quelque chose ne va pas ?";
				link.l1 = "Il se trouve, mon cher, que votre galion n'était pas du tout un galion... Ou alors un très gros galion... Diable !! C'était un vaisseau de ligne ! Et vous ne m'aviez pas prévenu ! Cependant, je l'ai capturé. J'ai "+ sTemp +" esclaves dans mes cales, et je veux bien vous les livrer. Selon notre accord, vous me devez " + FindRussianMoneyString(iSlaveMoney) + ". Et une compensation pour la désinformation serait la bienvenue.";
				link.l1.go = "Wingalleon_1";
			}
			else
			{
			dialog.text = "Vous avez trouvé le galion ? Oם sont les esclaves ? Il devait y en avoir au moins trois mille ! Bon sang, il n'y a que des canailles et des traîtres autour de moi ! Je ne m'attendais pas à ça de qui que ce soit, mais de vous... Vous étiez mon dernier espoir, et si c'est comme ça... Je le jure, je dépenserai le reste de ma fortune et je finirai sur le parvis d'une église, mais je ferai en sorte que toute la flotte de " + NationNameGenitive(sti(npchar.nation)) + " vous donne la chasse ! Disparaissez de ma vue !";
				link.l1 = "Hum...";
				link.l1.go = "Wingalleon_goaway";
			}
		break;

		case "Wingalleon_goaway":
			AddQuestRecord("Slavetrader", "9");
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			ChangeCharacterHunterScore(pchar, NationShortName(sti(pchar.questTemp.Slavetrader.Nation)) + "hunter", 70);
			pchar.questTemp.Slavetrader = "End_quest";
			DialogExit();
		break;

		case "Wingalleon_1":
			dialog.text = "Que dites-vous là ! Je le jure, je ne le savais pas. Ce devait être un galion lourd, mais pas un vaisseau de ligne ! Apparemment, quelque chose a changé au dernier moment... Mais vous l'avez fait ! Pour ce qui est de compter l'argent et de couvrir vos frais imprévus, je suis tout à fait d'accord, je reconnais tout, mais il y a une circonstance de force majeure : je n'ai tout simplement pas une somme aussi importante en ce moment. Les problèmes récents... Enfin, vous savez tout vous-même. Mais ne vous emportez pas trop, " + pchar.name + " – pour l'amour de Dieu ! Vous me livrez la marchandise, je la vends (le client attend déjà), et dans cinq jours, j'aurai toute la somme, et je vous paierai intégralement. Vous pouvez y compter. Et pour vous rassurer, je suis prêt à vous donner tout l'argent liquide que j'ai en ce moment : tous mes coffres de crédit.";
			link.l1 = "Hum... Je comptais toucher l'argent maintenant. Si vous saviez quel combat j'ai dמ livrer ! Oh, bon... Je me mets à votre place. Mais n'oubliez pas : essayez seulement de me rouler, et je vous retrouverai jusqu'en Europe !";
			link.l1.go = "Wingalleon_yes";
			link.l2 = "Vous savez quoi, " + npchar.name + ", allez au diable. Ce n'est pas ce qui était convenu. Vous n'imaginez même pas quel combat j'ai dמ livrer. Je garde tous les esclaves pour moi, et je les écoulerai sans votre intermédiaire.";
			link.l2.go = "Wingalleon_no";
		break;

		case "Wingalleon_no":
			dialog.text = "Ah, c'est sur ce ton qu'on parle, maintenant ! Alors, tant que j'étais une vache à lait pour vous, tout vous convenait, et dès qu'il s'agit d'un délai, vous me piétinez pour mener vos affaires de votre cכté. Et vous oubliez au passage que c'est moi qui vous ai indiqué cette proie... Je le jure, je dépenserai le reste de ma fortune et je finirai sur le parvis d'une église, mais je ferai en sorte que toute la flotte de " + NationNameGenitive(sti(npchar.nation)) + " vous donne la chasse ! Disparaissez de ma vue !";
			link.l1 = "Ne me faites pas peur, sac d'écus vide. Je donnerai votre flotte à manger aux crabes. Bon séjour !";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "9");
			CloseQuestHeader("Slavetrader");
			ChangeCharacterHunterScore(pchar, NationShortName(sti(pchar.questTemp.Slavetrader.Nation)) + "hunter", 70);
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Wingalleon_yes":
			dialog.text = "Merci de votre compréhension, " + pchar.name + ". Je vous le promets, tout se passera au mieux, vos menaces sont donc inutiles ; prenez ceci comme acompte. Il y a là quinze coffres. Dix seront déduits lors du règlement final, et prenez-en cinq pour vous, en dédommagement du préjudice moral. Revenez chercher le reste dans cinq jours. N'oubliez pas d'apporter tous les objets indiens que vous avez trouvés sur le navire capturé... si on en a trouvé, bien sמr. De toute façon, je n'ai rien à vous proposer pour eux pour l'instant.";
			link.l1 = "Dans cinq jours exactement, " + npchar.name + ". Dans cinq jours exactement...";
			link.l1.go = "Wingalleon_yes_1";
		break;

		case "Wingalleon_yes_1":
			TakeNItems(pchar, "chest", 15);
			Log_Info("Vous avez reçu les coffres de crédit");
			PlaySound("interface\important_item.wav");
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_4");
			pchar.questTemp.Slavetrader = "wait_4";
			AddQuestRecord("Slavetrader", "20");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			pchar.questTemp.Slavetrader.iSlaveMoney = makeint(sTemp)*200-120000;
			RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
			DialogExit();
		break;

		case "FindRat":
			dialog.text = "Comme promis, " + pchar.name + ", je suis prêt à vous payer. Les esclaves sont vendus, le client est satisfait, et nous aussi. Avec l'acompte, la somme qui vous revient est de " + FindRussianMoneyString(sti(pchar.questTemp.Slavetrader.iSlaveMoney)) + ". Je vous en prie, prenez votre argent.";
			link.l1 = "Parfait, " + npchar.name + ". C'est agréable d'avoir affaire à un homme qui sait tenir parole...";
			link.l1.go = "FindRat_1";
		break;

		case "FindRat_1":
			AddMoneyToCharacter(pchar, makeint(pchar.questTemp.Slavetrader.iSlaveMoney));
			dialog.text = "Vous pouvez toujours me croire sur parole, " + pchar.name + ". Je ne vous ai encore jamais donné de raison d'en douter. Et il en sera toujours ainsi. L'honnêteté entre associés est le fondement du succès dans toute affaire commune. Maintenant, à propos des objets indiens. Montrez-moi ce que vous avez là, sinon, en collectionneur passionné, je vais mourir d'impatience.";
			link.l1 = "Hum... Regardez, je vous en prie.";
			link.l1.go = "FindRat_2";
		break;

		case "FindRat_2":
			if (CheckCharacterItem(pchar, "indian15"))
			{
				dialog.text = "Là ! Merveilleux ! La tête olmèque en basalte ! C'est un objet rare. Je voulais l'avoir dans ma collection depuis longtemps. Je vous en offre 30 000, ou un échange contre une statuette de Tlaloc : j'en ai deux.";
				link.l1 = "Je prends l'argent.";
				link.l1.go = "BG_money";
				link.l2 = "J'échange cet objet contre une statuette de Tlaloc.";
				link.l2.go = "BG_change";
				link.l3 = "Je garde cet objet pour moi.";
				link.l3.go = "BG_no";
			}
			else
			{
				dialog.text = "Bon, bon... Malheureusement, il n'y a rien qui puisse m'intéresser.";
				link.l1 = "Eh bien, tant pis, comme vous voudrez.";
				link.l1.go = "BG_PF";
			}
		break;

		case "BG_money":
			dialog.text = "Merveilleux ! Voici vos 30 000, et cette tête olmèque est à moi désormais.";
			link.l1 = "Bien. Eh bien, si c'est tout ce qui vous intéresse...";
			link.l1.go = "BG_PF";
			AddMoneyToCharacter(pchar, 30000);
			Log_Info("Vous avez remis la tête en basalte");
			PlaySound("interface\important_item.wav");
			RemoveItems(PChar, "indian15", 1);
		break;

		case "BG_change":
			dialog.text = "Merveilleux ! Voici votre statuette, et cette tête olmèque est désormais à moi.";
			link.l1 = "Bien. Eh bien, si c'est tout ce qui vous intéresse...";
			link.l1.go = "BG_PF";
			Log_Info("Vous avez remis la tête en basalte");
			Log_Info("Vous avez reçu une statuette de Tlaloc");
			PlaySound("interface\important_item.wav");
			RemoveItems(PChar, "indian15", 1);
			TakeNItems(pchar, "indian19", 1);
		break;

		case "BG_no":
			dialog.text = "Eh bien, comme vous voudrez. C'est dommage, quand même, dommage...";
			link.l1 = "Eh bien, si c'est tout ce qui vous intéresse...";
			link.l1.go = "BG_PF";
		break;

		case "BG_PF":
			dialog.text = "Attendez ! Laissez-moi regarder encore...";
			link.l1 = "Je vous en prie, regardez, choisissez.";
			link.l1.go = "PF_check";
		break;

		case "PF_check":
			if (CheckCharacterItem(pchar, "indian2"))
			{
				dialog.text = "Là ! Je ne l'avais pas remarquée tout de suite ! Cette figurine d'enfant indien m'intéresse. Un sujet très intéressant, je vous le dis... Je suis prêt à la payer 20 000 piastres, ou à l'échanger contre une amulette de Xiuhcoatl.";
				link.l1 = "Je prends l'argent.";
				link.l1.go = "PF_money";
				link.l2 = "J'échange cet objet contre une amulette de Xiuhcoatl.";
				link.l2.go = "PF_change";
				link.l3 = "Je garde cet objet pour moi.";
			link.l3.go = "PF_no";
			}
			else
			{
				dialog.text = "Non, euh... Finalement, vous n'avez rien de ce qu'il me faut.";
				link.l1 = "Eh bien ! Tant pis.";
				link.l1.go = "FindRat_3";
			}
		break;

		case "PF_money":
			dialog.text = "Merveilleux ! Voici vos 20 000, et cette figurine est à moi désormais.";
			link.l1 = "Bien. Cette affaire me convient parfaitement.";
			link.l1.go = "FindRat_3";
			AddMoneyToCharacter(pchar, 20000);
			Log_Info("Vous avez remis une figurine effrayante");
			PlaySound("interface\important_item.wav");
			RemoveItems(PChar, "indian2", 1);
		break;

		case "PF_change":
			dialog.text = "Merveilleux ! Voici votre amulette, et cette figurine est désormais à moi.";
			link.l1 = "Bien. Cette affaire me convient parfaitement.";
			link.l1.go = "FindRat_3";
			Log_Info("Vous avez remis une figurine effrayante");
			Log_Info("Vous avez reçu l'amulette de Xiuhcoatl");
			PlaySound("interface\important_item.wav");
			RemoveItems(PChar, "indian2", 1);
			TakeNItems(pchar, "indian6", 1);
		break;

		case "PF_no":
			dialog.text = "Eh bien, comme vous voudrez. C'est dommage, quand même, dommage...";
			link.l1 = "J'ai besoin de cette statuette pour moi, pardon.";
			link.l1.go = "FindRat_3";
		break;

		case "FindRat_3":
			dialog.text = "Eh bien... En capturant ce galion... pardon, ce vaisseau de ligne, vous m'avez littéralement sauvé. Je suis heureux de travailler avec vous, " + pchar.name + ". Je n'ai sans doute jamais eu de meilleur agent que vous.";
			link.l1 = "C'est flatteur, je ne vous le cacherai pas. Mais vous exagérez un peu mes mérites...";
			link.l1.go = "FindRat_4";
		break;

		case "FindRat_4":
			dialog.text = "Je suis tout à fait sérieux. Et c'est précisément parce que vous avez des capacités aussi remarquables, et parce que j'ai toute confiance en vous, que je vous demande d'accomplir ma prochaine mission.";
			link.l1 = "Héhé ! Inattendu ! Je vous écoute attentivement. Oם est le prochain galion d'esclaves ?";
			link.l1.go = "FindRat_5";
		break;

		case "FindRat_5":
			dialog.text = "Cette fois, j'aurai pour vous une tâche différente, qui n'a rien à voir avec les esclaves. דa vous surprend ? Je paierai bien pour cette mission... Je vous paierai très bien.";
			link.l1 = "Venons-en au fait.";
			link.l1.go = "FindRat_6";
		break;

		case "FindRat_6":
			dialog.text = "Cette affaire est directement liée aux événements récents, dans lesquels vous avez d'ailleurs joué un rכle... Donc, comme vous le savez, je fais un commerce illégal : la traite des esclaves. Vous savez aussi que j'engage des corsaires comme vous pour faire mes courses. Récemment, l'un de mes hommes, pour une raison qui m'est totalement incompréhensible, m'a trahi : il m'a dénoncé et a réuni des preuves m'accusant, moi et mes hommes de confiance, de traite illégale d'esclaves. Vous avez vu les conséquences : un navire chargé de soldats est arrivé ici d'une colonie voisine, eh bien... Vous connaissez la suite ; c'est à grand-peine que nous avons réussi à régler la situation, et à cacher les circonstances de la destruction de la pinasse et du meurtre de soldats dans ma maison. Comme vous le comprenez, une trahison ne peut rester impunie. De plus, je ne peux pas vivre et travailler en paix en sachant que ce rat est en vie et se promène dans l'archipel. J'ai lancé des chasseurs de primes aux trousses de ce scélérat, mais pour l'instant, le résultat est nul ; je vous demande de vous charger personnellement de cette affaire. D'autant que la trahison de ce scélérat vous concerne directement.";
			link.l1 = "Hum... Ce scélérat mérite d'être pendu à la vergue ! Donnez-moi plus d'informations sur lui, et bien sמr, le montant de la rémunération.";
			link.l1.go = "FindRat_7";
		break;

		case "FindRat_7":
			dialog.text = "Ne vous inquiétez pas pour la récompense. Je vous paierai grassement pour l'avoir éliminé, et pas seulement en argent. Je ne lésinerai pas sur les plus belles pièces de ma collection indienne. Maintenant, parlons de lui. Ce rat s'appelle François Gontier, et il y a longtemps, pour brouiller les pistes (car il sait que je le pourchasse), il a vendu sa frégate dans l'un des chantiers navals de l'archipel, et il a disparu. J'ai réussi à apprendre par mes collègues qu'on l'a vu récemment à Panama. Vous devriez peut-être commencer vos recherches par là.";
			link.l1 = "Bon, je pars immédiatement.";
			link.l1.go = "FindRat_8";
		break;

		case "FindRat_8":
			dialog.text = "Je vous souhaite bonne chance. Et méfiez-vous : ce scélérat de Gontier est un marin très expérimenté, et il a un équipage de coupe-jarrets désespérés. Il n'a rien à perdre, il se battra donc avec l'énergie du désespoir.";
			link.l1 = "J'en ai vu de plus redoutables... Mais je tiendrai compte de vos paroles. Au revoir, et soyez tranquille : je le trouverai, même en enfer.";
			link.l1.go = "exit";
			pchar.questTemp.Slavetrader.ShipName = GenerateRandomNameToShip(SPAIN);
			AddQuestRecord("Slavetrader", "21");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			pchar.questTemp.Slavetrader = "FindRatPanama";
		break;

		case "Wincorvette":
			dialog.text = "Parfait ! Qu'il écrive maintenant ses dénonciations aux méduses. Personne n'ose me faire des saletés impunément ! Merci, " + pchar.name + " : vous êtes tout simplement irremplaçable.";
			link.l1 = "Merci, " + npchar.name + ", pour cette appréciation flatteuse de mes actes. Et le paiement ?";
			link.l1.go = "Wincorvette_1";
		break;

		case "Wincorvette_1":
			dialog.text = "Oui, bien sמr. Je paierai ce travail des plus difficiles en conséquence. Je vous offre la fierté de ma collection, la statuette d'Atlaua, gratuitement. J'espère que vous savez que ce n'est pas une simple babiole ?";
			link.l1 = "דa alors, quel cadeau ! Oui, je sais, c'est le « seigneur des eaux », une statue magique. Une chose bien utile pour un marin.";
			link.l1.go = "Wincorvette_2";
		break;

		case "Wincorvette_2":
			dialog.text = "En plus, je vous paierai 100 000 piastres de prime et 50 000 piastres pour couvrir vos frais de voyage.";
			link.l1 = "Merci, " + npchar.name + ". Encore une fois, c'est un plaisir de travailler avec vous.";
			link.l1.go = "Wincorvette_3";
			Log_Info("Vous avez reçu l'idole d'Atlaua");
			PlaySound("interface\important_item.wav");
			TakeNItems(pchar, "indian18", 1);
		break;

		case "Wincorvette_3":
			dialog.text = "Eh bien, comme d'habitude, je vous attends chez moi dans un mois. Une affaire de très grande envergure se prépare, et vous aurez besoin d'une escadre bien équipée. Je vous prie de prendre mes paroles au sérieux et de bien vous préparer. Si ça marche, vous et moi, nous serons riches.";
			link.l1 = "D'accord, " + npchar.name + ". Je viendrai armé jusqu'aux dents.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 150000);
			AddQuestRecord("Slavetrader", "21_13");
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_5");
			pchar.questTemp.Slavetrader = "wait_5";
		break;

		case "Lostcorvette":
			dialog.text = "Dommage, vraiment dommage... Bon, ne vous désolez pas trop : bien d'autres avant vous n'ont pas réussi à attraper cet escroc. Ce n'est rien, je finirai par le coincer, et je vous attends dans un mois. Une affaire de très grande envergure se prépare, et vous aurez besoin d'une escadre bien équipée. Je vous prie de prendre mes paroles au sérieux et de bien vous préparer. Si ça marche, vous et moi, nous serons riches.";
			link.l1 = "D'accord, " + npchar.name + ". Je viendrai armé jusqu'aux dents.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_14");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_5");
			pchar.questTemp.Slavetrader = "wait_5";
		break;

		case "Havana_fort":
			dialog.text = "Vous tombez à pic, " + pchar.name + " ! Je commençais à m'inquiéter, et j'allais envoyer quelqu'un à votre recherche ; commençons ! La tâche qui vous attend cette fois sera très sérieuse, mais la récompense sera à la hauteur. Après l'opération, vous recevrez un million, voire plus.";
			link.l1 = "Voilà qui est parlé ! Je vous écoute attentivement, " + npchar.name + ".";
			link.l1.go = "Havana_fort_1";
		break;

		case "Havana_fort_1":
			dialog.text = "Au cours du mois dernier, des Indiens réduits en esclavage ont été amenés à La Havane de toute la Terre Ferme, par petits lots ; en plus, plusieurs galions chargés de « bois d'ébène » sont arrivés d'Afrique et y ont déchargé. En ce moment, il y a au moins cinq mille esclaves à La Havane, derrière les hautes murailles du fort.";
			link.l1 = "Je sens que ce ne sera rien de moins que l'assaut de La Havane.";
			link.l1.go = "Havana_fort_2";
		break;

		case "Havana_fort_2":
			dialog.text = "Vous avez tout compris, " + pchar.name + ". C'est exactement ce que je veux que vous fassiez. Vous, et personne d'autre. Je ne pense pas qu'aucun de mes autres agents soit capable de mener une opération aussi sérieuse ; vous allez bien vous charger de cette affaire ?";
			link.l1 = "Pour être franc, " + npchar.name + ", ça me prend un peu de court. Je ne pensais pas que votre activité était aussi... de grande envergure. Bien sמr que je m'en charge. " + RandSwear() + "";
			link.l1.go = "Havana_fort_3";
			link.l2 = "Vous savez quoi, " + npchar.name + ", ça dépasse les bornes. J'en ai assez de vos surprises. Avec votre cupidité, je vais devoir déclarer la guerre à l'Espagne demain. Si vous avez besoin de ces esclaves, prenez La Havane d'assaut vous-même.";
			link.l2.go = "Havana_fort_not";
		break;

		case "Havana_fort_not":
			dialog.text = "Je ne m'attendais pas à ça de votre part. Je ne m'y attendais pas... Qu'est-ce que je vais bien pouvoir dire au client maintenant ? Bon. Si vous ne voulez pas, je chercherai un autre exécutant. Adieu, " + pchar.name + ". Je ne pense pas que je ferai encore appel à vos services. Et souvenez-vous : vous avez volontairement renoncé à une affaire qui aurait pu nourrir tous vos descendants jusqu'à la septième génération.";
			link.l1 = "On ne peut pas gagner tout l'argent du monde. Vous n'avez jamais entendu le dicton « qui trop embrasse mal étreint » ? Bonne journée, " + npchar.name + ".";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "8");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Slavetrader");
			pchar.questTemp.Slavetrader = "End_quest";
		break;

		case "Havana_fort_3":
			dialog.text = "Je ne doutais pas d'entendre exactement cette réponse. Quelques détails : le fort de La Havane n'est pas facile à prendre, mais en ce moment, la tâche est devenue encore plus difficile. Deux vaisseaux de ligne croisent sans cesse le long des cכtes de La Havane : ils gardent les approches de la ville depuis la mer. Vous devrez vous débarrasser de ces navires avant de lancer l'assaut...";
			link.l1 = "Compris. Ce n'est pas la première fois que je livre bataille à des vaisseaux de ligne. Combien de temps ai-je ?";
			link.l1.go = "Havana_fort_4";
		break;

		case "Havana_fort_4":
			dialog.text = "Peu. Trois semaines, pas plus. Ensuite, les esclaves seront envoyés vers les comptoirs espagnols de Cuba. Vous devriez donc vous dépêcher.";
			link.l1 = "Alors, ne tardons pas. J'y vais !";
			link.l1.go = "Havana_fort_5";
		break;

		case "Havana_fort_5":
			dialog.text = "Une minute ! " + pchar.name + ", vous et moi n'avons jamais eu de malentendus ni de désaccords. Mais je tiens quand même à vous informer de l'état actuel des choses. Je compte sur vous, et le client compte sur moi ; lui et moi avons déjà investi des forces et des fonds dans cette entreprise, et pas qu'un peu, pour obtenir les informations que je viens de vous fournir. Tous les esclaves capturés, les cinq mille unités de marchandise, doivent m'être livrés sains et saufs, sinon nous prendrons des mesures très, très radicales contre vous. Je vous prie de ne pas vous offenser de cet avertissement, mais d'en prendre simplement note.";
			link.l1 = "Ne vous inquiétez pas, " + npchar.name + ", je sais ce que sont les affaires. א plus tard.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "24");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Slavetrader", "sName", GetFullName(npchar));
			pchar.quest.Slavetrader_HavanaAttack.win_condition.l1 = "location";
            pchar.quest.Slavetrader_HavanaAttack.win_condition.l1.location = "Cuba2";//отправляем в локацию
            pchar.quest.Slavetrader_HavanaAttack.function = "Slavetrader_CreateLineShips";//создание линейных кораблей
			SetFunctionTimerCondition("Slavetrader_HavanaOver", 0, 0, 20, false);	//таймер
			characters[GetCharacterIndex("Havana_Mayor")].dialog.captureNode = "Slavetrader_HavanaAttack"; //капитулянтская нода мэра
			pchar.questTemp.Slavetrader = "wait1";
		break;

		case "Win_Havana_Fort":
			pchar.quest.Slavetrader_FiveTSlavesOver.over = "yes";
			amount = 5000 - GetSquadronGoods(Pchar, GOOD_SLAVES);
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			if (amount < 1)
			{
				dialog.text = "Alors, quels sont les résultats de votre victoire, en équivalent matériel, pour ainsi dire ?";
				link.l1 = "J'ai " + sTemp + " esclaves dans mes cales.";
				link.l1.go = "Havana_Fort_yes";
				break;
			}
			if (amount < 4500 && amount >= 1)
			{
				dialog.text = "Bon, bon... Vous avez oublié ce que je vous avais dit ? Vous deviez m'amener au moins cinq mille esclaves, mais pour une raison ou une autre, vous n'en avez que " + sTemp + ". Comment est-ce arrivé ?";
				link.l1 = "Euh... Tout le monde n'a pas supporté le voyage dans les cales depuis La Havane...";
				link.l1.go = "Havana_Fort_no";
				break;
			}
			dialog.text = "Bon, bon... Vous avez décidé de me rouler ? Vous avez oublié ce que je vous avais dit ? Oם sont mes esclaves ? Oם sont-ils, je vous le demande ?!";
			link.l1 = "Euh... Il s'est passé une chose...";
			link.l1.go = "Havana_Fort_no";
		break;

		case "Havana_Fort_no":
			dialog.text = "Bon. Pas besoin d'explications. Je vous donne une semaine pour me livrer au moins cinq mille esclaves, selon notre accord. Sinon, vous ne pourrez vous en prendre qu'à vous-même !";
			link.l1 = "D'accord, d'accord, ne vous énervez pas, vous les aurez, vos cinq mille esclaves !";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "29");
			SetFunctionTimerCondition("Slavetrader_HavanaSeekOver", 0, 0, 7, false);
			pchar.questTemp.Slavetrader = "Havana_seekslaves";
		break;

		case "Havana_Fort_yes":
			dialog.text = "Parfait ! Comme toujours, vous avez brillamment accompli ma mission. Je suis très, très content de vous.";
			link.l1 = "Je n'ai pas à me plaindre de moi non plus... Mais ça me plaira encore plus quand je toucherai l'argent de la marchandise.";
			link.l1.go = "Havana_Fort_yes_1";
		break;

		case "Havana_Fort_yesA":
		dialog.text = "Eh bien, j'en suis très, très heureux. Malgré le retard, vous avez brillamment accompli ma mission.";
			link.l1 = "Bon, maintenant, je veux toucher le prix de la marchandise.";
			link.l1.go = "Havana_Fort_yes_1";
			pchar.quest.Slavetrader_HavanaSeekOver.over = "yes";
		break;

		case "Havana_Fort_yes_1":
			sTemp = GetSquadronGoods(Pchar, GOOD_SLAVES);
			iSlaveMoney = makeint(sTemp)*200;
			pchar.questTemp.Slavetrader.lastmoney = iSlaveMoney;
			dialog.text = "Oui, absolument. Je vais remettre les esclaves au client, il paiera, et vous recevrez votre argent. Exactement comme la dernière fois. Faisons le compte : vous avez amené " + sTemp + " esclaves. En conséquence, la somme qui vous revient est de " + FindRussianMoneyString(iSlaveMoney) + ". Dans une semaine, venez me voir pour le règlement.";
			link.l1 = "D'accord, " + npchar.name + ", entendu. Attendez-moi dans une semaine. Mais attention...";
			link.l1.go = "Havana_Fort_yes_2";
			RemoveCharacterGoods(Pchar, GOOD_SLAVES, sTemp);
		break;

		case "Havana_Fort_yes_2":
			dialog.text = "" + pchar.name + "Je vous en prie, n'en dites pas plus. Nous sommes associés, et il ne peut y avoir ni tromperie ni méfiance entre associés. Je vous ai promis beaucoup d'argent : vous l'avez eu ; je vous ai promis des missions lucratives : vous les avez. J'ai remboursé vos frais et couvert vos dépenses, même dans les moments les plus difficiles pour mon commerce. Pouvez-vous me reprocher de ne pas avoir tenu parole une seule fois ?";
			link.l1 = "Euh... non.";
			link.l1.go = "Havana_Fort_yes_3";
		break;

		case "Havana_Fort_yes_3":
			dialog.text = "Vous voyez... " + pchar.name + ", vous êtes mon meilleur agent, et j'ai hâte de continuer à faire affaire avec vous. Peut-être devriez-vous cesser d'exprimer sans cesse votre méfiance à mon égard, et qui plus est, dans une telle situation... sous une forme aussi rude ?";
			link.l1 = "D'accord, " + npchar.name + ". Comprenez-moi simplement : un million, ce n'est pas une petite somme.";
			log_info("Vous avez reçu un khanda.");
			log_info("Vous avez reçu un talisman « Beazel ».");
			log_info("Vous avez reçu une cuirasse d'honneur.");
			TakeNItems(pchar, "blade42",1);
			TakeNItems(pchar, "talisman16",1);
			TakeNItems(pchar, "cirass5",1);
			link.l1.go = "Havana_Fort_yes_4";
		break;

		case "Havana_Fort_yes_4":
			dialog.text = "Je vous comprends parfaitement, mais comprenez aussi qu'il faut d'abord vendre la marchandise, et seulement ensuite toucher l'argent.";
			link.l1 = "Bon. Admettons que nous nous comprenons.";
			link.l1.go = "Havana_Fort_yes_5";
		break;

		case "Havana_Fort_yes_5":
			dialog.text = "Parfait. Je vous attends chez moi dans une semaine. Et maintenant, je dois préparer l'affaire avec le client.";
			link.l1 = "Alors, je ne vous dérange pas plus. א dans une semaine, " + npchar.name + ".";
			link.l1.go = "exit";
			pchar.questTemp.Slavetrader.Name = npchar.name;
			AddQuestRecord("Slavetrader", "32");
			SaveCurrentQuestDateParam("pchar.questTemp.Slavetrader_wait_6");
			SetFunctionTimerCondition("Slavetrader_UsurerEscape", 0, 0, 8, false);
			pchar.questTemp.Slavetrader = "wait_6";
			pchar.questTemp.Slavetrader.Cityname = npchar.city +"_town";
			LocatorReloadEnterDisable(npchar.city +"_town", "reload8_back", true);//чтобы не ходил неделю сюда вообще
		break;
		
		case "Betrayal":
			dialog.text = "Quoi ? Comment avez-vous su que j'étais ici, capitaine ?";
			link.l1 = "Vos marins n'auraient pas dמ parler autant. D'après ce que j'ai compris, vous vouliez me rouler, maintenant que notre affaire atteignait le million de pesos.";
			link.l1.go = "Betrayal_1";
		break;
		
		case "Betrayal_1":
			dialog.text = "Que vous êtes malin... Je savais que c'était une mauvaise idée, après tout. Et j'ai mal choisi mon équipage, puisqu'ils vous ont mis sur ma piste.";
			link.l1 = "Et que dois-je faire de vous maintenant ? Vous devez comprendre que je ne peux pas vous laisser partir comme ça, avec tout ça, gratuitement.";
			link.l1.go = "Betrayal_2";
		break;
		
		case "Betrayal_2":
			dialog.text = "Aucun doute là-dessus. Mais nous étions associés, pouvez-vous vous mettre à ma place ? J'ai eu des problèmes pour vendre les esclaves. Je n'ai pas pu en tirer la somme espérée, et je n'aurais pas pu vous payer correctement. Alors, j'ai dמ trouver une solution...";
			link.l1 = "C'est une fâcheuse nouvelle. Mais vous vous enfuyiez non seulement avec mon argent, mais aussi avec les dépכts d'autres gens ?";
			link.l1.go = "Betrayal_3";
		break;
		
		case "Betrayal_3":
			dialog.text = "Quelle perspicacité. Oui, c'est exact. J'espère vraiment que nous pourrons nous entendre. Je vous paierai tout ce que j'ai promis, avec des intérêts, et nous oublierons ce... malentendu. Alors, qu'en dites-vous ?";
			link.l1 = "Je veux en finir pacifiquement, notre collaboration n'a pas été si mauvaise avant les derniers événements. Je ne verserai pas votre sang ici. J'accepte.";
			link.l1.go = "Betrayal_4_1";
			link.l2 = "Après toutes ces sottises, vous espérez de la clémence ? Je ferais mieux de vous écorcher vif et de tout prendre pour moi !";
			link.l2.go = "Betrayal_4_2";
		break;
		
		case "Betrayal_4_1":
			dialog.text = "Je suis vraiment heureux de votre décision. Alors, voyons... "+FindRussianMoneyString(sti(pchar.questTemp.Slavetrader.lastmoney))+". Je pense qu'environ 250 000 en coffres de crédit apaiseront votre déception ? Après ça, mon destin est entre vos mains.";
			link.l1 = "Oui. Je mentirais en disant que ces retrouvailles ont été heureuses, mais le résultat me convient. Au revoir !";
			link.l1.go = "Betrayal_4_1_exit";
			AddMoneyToCharacter(pchar,sti(pchar.questTemp.Slavetrader.lastmoney));
			TakeNItems(pchar,"Chest",15);
			log_info("Vous avez reçu 15 coffres de crédit.");
		break;
		
		case "Betrayal_4_1_exit":
			QuestAboardCabinDialogSurrender();
			DialogExit();
			AddQuestRecord("Slavetrader", "34");
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "wait1";
		break;
		
		case "Betrayal_4_2":
			dialog.text = "Eh bien, j'espérais une solution pacifique, mais hélas... א la garde !";
			link.l1 = "...";
			link.l1.go = "exit";
			int moneytotal = sti(pchar.questTemp.Slavetrader.lastmoney)+200000+rand(200000);
			NPChar.money = moneytotal;
			Locations[FindLocation(PChar.location)].box1.items.Chest = 5;
			LAi_SetCurHPMax(NPChar);
			AddQuestRecord("Slavetrader", "35");
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "wait1";
			AddDialogExitQuestFunction("QuestAboardCabinDialogExitWithBattleNoParam");
		break;

		case "Usurer_Escape":
			dialog.text = "Ce que je fais ici ? Hum... C'est ma banque. Je viens de l'acheter il y a quelques jours. Comme vous êtes mon premier client, je peux vous proposer des conditions de prêt très avantageuses...";
			link.l1 = "Au diable les prêts ! Oם est " + pchar.questTemp.Slavetrader.Name + " ?";
			link.l1.go = "Usurer_Escape_1";
		break;

		case "Usurer_Escape_1":
			dialog.text = "Chut, chut, ne criez pas ! Il n'est plus ici depuis longtemps.";
			link.l1 = "Comment ça ?";
			link.l1.go = "Usurer_Escape_2";
		break;

		case "Usurer_Escape_2":
			dialog.text = "Vous ne savez pas ? Il a disparu il y a une semaine. Puis on a découvert qu'il avait emporté l'argent de tous ses déposants. On dit que même le gouverneur y a laissé des plumes. Il a abandonné cette maison, et je l'ai rachetée à la ville.";
			link.l1 = "Oם a-t-il disparu ? Comment ?";
			link.l1.go = "Usurer_Escape_3";
		break;

		case "Usurer_Escape_3":
			dialog.text = "J'ai entendu dire qu'il avait quitté notre colonie par la mer... Je vois qu'il vous doit de l'argent, à vous aussi... Beaucoup ?";
			link.l1 = "Plus d'un million ! Bon, je vais quand même attraper ce rat ! On ne sait pas oם il est parti ? Sur quel navire ?";
			link.l1.go = "Usurer_Escape_4";
		break;

		case "Usurer_Escape_4":
			dialog.text = "Personne ne sait. Rien. Du tout. Il semble avoir disparu. Il était là, et il n'y est plus. Ce jour-là, une flמte a quitté le port, soit la « Mauritius », soit la « Mavrodi » : il a sans doute disparu à son bord.";
			link.l1 = "Bon sang ! Il fallait que je fasse confiance à un tel scélérat ! Sa bassesse se sentait à un mille ! Et moi, naïvement, j'ai cru que nous étions vraiment associés ! Mais il va le regretter... Bon, " + npchar.name + " : pardonnez ma grossièreté... Au revoir.";
			link.l1.go = "Usurer_Escape_5";
		break;

		case "Usurer_Escape_5":
		string sColony;
		sColony = npchar.city;
		SetNull2Deposit(sColony);
			dialog.text = "Ce n'est rien, je comprends tout. Si vous avez besoin d'argent, ou au contraire si vous voulez ouvrir un dépכt, je suis toujours à votre service.";
			link.l1 = "Merci. Mais je préfère garder mon argent. Bonne journée.";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "33");
			AddQuestUserData("Slavetrader", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("Slavetrader");
			pchar.questdata.Rabotorgovets = 1;
			pchar.questTemp.Slavetrader = "wait1";
		break;

		//<--работорговец
		
		//Квест "Money in growth" -->
		
		case "KSM_DVR_1":
			dialog.text = "Oui, oui. Une affaire délicate... Un homme, Simon Barton, m'a emprunté une somme assez importante, à un bon taux. Oui, mais il n'est pas pressé de la rendre.";
			link.l1 = "La situation est désagréable. Pourquoi avez-vous prêté de l'argent à une personne aussi douteuse ?";
			link.l1.go = "KSM_DVR_2";
		break;

		case "KSM_DVR_2":
			dialog.text = "Simon semblait être un homme d'affaires plutכt prospère. Mais toute sa fortune a sombré en un jour, avec le navire qui lui appartenait... Et maintenant, il boit l'or qu'il m'a emprunté.";
			link.l1 = "Je peux rendre visite à M. Simon et lui demander de vous rembourser.";
			link.l1.go = "KSM_DVR_3";
			link.l2 = "Recouvrer des dettes ne m'intéresse pas. Au revoir.";
			link.l2.go = "KSM_DVR_2_2";
		break;
		
		case "KSM_DVR_2_2":
			DialogExit();
			pchar.questTemp.KSM_DVR_Rostovshik = true;
		break;

		case "KSM_DVR_3":
			pchar.Quest.KSM_DVR_Dengi.FindCitizenMoney = ((7 + Rand(sti(PChar.rank)))/2)*350 * GetCharacterSPECIALSimple(PChar, SPECIAL_L) + Rand(20)*10 * GetCharacterSPECIALSimple(PChar, SPECIAL_L);
			int KSM_DVR_Schitaem = pchar.Quest.KSM_DVR_Dengi.FindCitizenMoney;
			if(KSM_DVR_Schitaem < 10000) { KSM_DVR_Schitaem = 10000 + drand2(1000); }
			if(KSM_DVR_Schitaem > 30000) { KSM_DVR_Schitaem = 30000 + drand2(1000); }
			dialog.text = "Il a pris " + KSM_DVR_Schitaem + " piastres... Ce serait formidable si vous pouviez en récupérer au moins la moitié. En plus, votre part dépend aussi de la somme que vous réussirez à rapporter.";
			link.l1 = "א mon avis, c'est juste. Oם dois-je chercher M. Barton ?";
			link.l1.go = "KSM_DVR_4";
		break;

		case "KSM_DVR_4":
			dialog.text = "On dirait que Simon a un peu perdu la tête à cause de ses ennuis. Il reste assis toute la journée dans la baie de Palm Beach, à attendre que son navire apparaisse à l'horizon...";
			link.l1 = "Je le trouverai.";
			link.l1.go = "KSM_DVR_4_1";
		break;
		
		case "KSM_DVR_4_1":
			DialogExit();
			pchar.questTemp.KSM_DVR_Rostovshik = true;
			SetQuestHeader("KSM_DVR");
			AddQuestRecord("KSM_DVR", "1");
			
			sld = GetCharacter(NPC_GenerateCharacter("KSM_DVR_Saiman", "trader_14", "man", "man", 3, PIRATE, -1, false));
			sld.name = "Simon";
			sld.lastname = "Barton";
			sld.dialog.filename = "Quest\KSM\Dengi_v_rost.c";
			sld.dialog.currentnode = "simon_bazar";
			LAi_SetStayType(sld);
			LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "Shore22", "smugglers", "smugglerload");
			
			for (i=1; i<=3; i++)									//Количество
			{
				sTemp = "pirate_"+(rand(4)+1);
				sld = GetCharacter(NPC_GenerateCharacter("KSM_DVR_SaimanOhrana_"+i, sTemp, "man", "man", sti(pchar.rank), PIRATE, -1, true));
				sld.dialog.filename = "Quest\KSM\Dengi_v_rost.c";
				sld.dialog.currentnode = "simon_helper_bazar";
				LAi_SetStayType(sld);
				LAi_SetImmortal(sld, true);
				ChangeCharacterAddressGroup(sld, "Shore22", "smugglers",  "smuggler0"+i);
			}
			AddGeometryToLocation("Shore22", "smg");
		break;
		
		//<-- Квест "Money in growth"

		/* Обмен камней */
		case "Gems_exchange_1":
			DialogExit();
			LaunchItemsExchange();
		break;
	}
}

int findCitizenMan(ref NPChar, bool bCity)
{
    ref ch;
	int n, nation;
    int storeArray[MAX_COLONIES];
    int howStore = 0;

	if (bCity && sti(Pchar.Ship.Type) == SHIP_NOTUSED)
	{
		ch = GetCharacter(NPC_GenerateCharacter("LoanFindingMan", "citiz_"+(rand(11)+1), "man", "man", 10, sti(npchar.nation), -1, false));
		ch.dialog.filename = "Common_citizen.c";
		ch.city = npchar.city;
		ch.RebirthPhantom = true;
		LAi_NoRebirthDisable(ch);
		LAi_SetCitizenType(ch);
		LAi_group_MoveCharacter(ch, GetNationNameByType(sti(npchar.nation)) + "_citizens");
		PlaceCharacter(ch, "goto", npchar.city + "_town");
	}
	else
	{
		for(n=0; n<MAX_COLONIES; n++)
		{
			nation = GetNationRelation(sti(npchar.nation), sti(colonies[n].nation));
			if (nation != RELATION_ENEMY && colonies[n].nation != "none")
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
		if (howStore == 0) return -1;
		nation = storeArray[cRand(howStore-1)];
		ch = GetCharacter(NPC_GenerateCharacter("LoanFindingMan", "citiz_"+(rand(11)+1), "man", "man", 10, sti(colonies[nation].nation), -1, false));
		ch.dialog.filename = "Common_citizen.c";
		ch.city = colonies[nation].id;
		ch.RebirthPhantom = true;
		LAi_NoRebirthDisable(ch);
		LAi_SetCitizenType(ch);
		LAi_group_MoveCharacter(ch, GetNationNameByType(sti(colonies[nation].nation)) + "_citizens");
		PlaceCharacter(ch, "goto", colonies[nation].id + "_town");
	}
	return sti(ch.index);
}

int findChestMan(ref NPChar)
{
    ref ch;
	int n;
    int storeArray[TOTAL_CHARACTERS];
    int howStore = 0;
	string sTemp, sCity;

	for(n=2; n<MAX_CHARACTERS; n++)
	{
		makeref(ch,Characters[n]);
		sTemp = ch.id;
		if (CheckAttribute(ch, "City") && ch.id != "Jackman") sCity = ch.City;
		else continue;
		if (sti(ch.nation) == PIRATE) continue; // пираты не имеют реплик
		// Gregg: у квестовых персонажей City есть, а id с имени города НЕ начинается
		// (LoanCap_N, SeekCitizCap_N и т.п.) - короткий id даёт strcut "Invalid range"
		if (strlen(sTemp) < strlen(sCity) + 2) continue;
		sTemp = strcut(sTemp, strlen(sCity)+1, strlen(sTemp)-1);
		// магазины
		if (sTemp == "trader")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
        // мэры
		if (sTemp == "Mayor")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman") continue;
			if (ch.location != ch.Default) continue; //захвачанных мэров не надо
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
        // верфисты
		if (sTemp == "shipyarder")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman" || ch.City == "DesMoines") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
		// тавернщики
		if (sTemp == "tavernkeeper")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
	    // церковники
		if (sTemp == "Priest")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
		// ростовщики
		if (sTemp == "usurer")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
		// начальники портов
		if (sTemp == "PortMan")
		{
            if (NPChar.city == ch.city) continue;
            if (ch.location == "none" || ch.City == "Caiman" || ch.City == "DesMoines") continue;
            storeArray[howStore] = n;
            howStore++;
            continue;
		}
    }
    if (howStore == 0)
    {
        return -1;
    }
    else
    {
        return storeArray[cRand(howStore-1)];
    }
}

void SlavetraderGalleonInWorld()
{
	//создаём галеон с рабами
	ref sld;
	string sName;
	sName = pchar.questTemp.Slavetrader.ShipName;
	sld = GetCharacter(NPC_GenerateCharacter("GaleonCap", "", "man", "man", 45, SPAIN, -1, true));
 	SetCaptanModelByEncType(sld, "war");
	FantomMakeCoolSailor(sld, SHIP_INGERMANLAND, sName, CANNON_TYPE_CANNON_LBS32, 100, 100, 100);
	FantomMakeCoolFighter(sld, 45, 100, 100, "blade28", "pistol5", 100);//создание фантома кэпа
	sld.Ship.Mode = "war";
	DeleteAttribute(sld, "SinkTenPercent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	sld.WatchFort = true; //видеть форты
	sld.AlwaysEnemy = true;
	sld.SuperShooter  = true;
	SetCharacterPerk(sld, "StormProfessional");
	SetCharacterPerk(sld, "SwordplayProfessional");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "CriticalHit");
	SetCharacterPerk(sld, "MusketsShoot");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "Tireless");
	SetCharacterPerk(sld, "HardHitter");
	SetCharacterPerk(sld, "GunProfessional");
	SetCharacterGoods(sld, GOOD_SLAVES, 3000 + rand(200));//положить в трюм рабов
	sld.ship.Crew.Morale = 100;
	ChangeCrewExp(sld, "Sailors", 100);
	ChangeCrewExp(sld, "Cannoners", 100);
	ChangeCrewExp(sld, "Soldiers", 100);
	//в морскую группу кэпа
	string sGroup = "SlaveGalleon";
	Group_FindOrCreateGroup(sGroup);
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	pchar.quest.SlaveHalleon_AfterBattle.win_condition.l1 = "Group_Death";//условие победы
	pchar.quest.SlaveHalleon_AfterBattle.win_condition.l1.group = "SlaveGalleon";//какую группу уничтожить
	pchar.quest.SlaveHalleon_AfterBattle.function = "Slavetrader_SlaveHalleon_AfterBattle";//это победа
	sld.city = pchar.questTemp.Slavetrader.Island; //определим колонию, из бухты которой выйдет
	sld.cityShore = pchar.questTemp.Slavetrader.Island.Shore;
	sld.quest.targetCity = "Santiago"; //определим колонию, в бухту которой он придёт
	sld.quest.targetShore = GetIslandRandomShoreId(GetArealByCityName(sld.quest.targetCity));
	Log_TestInfo("The cap of the galleon came out of: " + sld.city + " and headed to: " + sld.quest.targetShore);
	//==> на карту
	sld.mapEnc.type = "trade";
	//выбор типа кораблика на карте
	sld.mapEnc.worldMapShip = "quest_ship";
	sld.mapEnc.Name = "Galion '" + sName + " '";
	int daysQty = 20; //дней доехать даём с запасом
	Map_CreateTrader(sld.cityShore, sld.quest.targetShore, sld.id, daysQty);//вот он, сам запуск энкаунтера
	sld.lifeDay = 20;
}


int PcharReputation()
{
	//Pchar.Quest.Loans.(NPC_Area).Interest = 22 - makeint((GetSummonSkillFromName(pchar, "Commerce")+GetSummonSkillFromName(pchar, "Leadership"))/10);
	return makeint(42 - sti(pchar.reputation)*0.33);
}

void CheckForAchievement()
{
	int deposits = 0;
	if (CheckAttribute(pchar, "Quest.Deposits")) // не треться при возврате
	{
		aref quest;
		aref quests;
		makearef(quests,Characters[GetMainCharacterIndex()].Quest.Deposits);

		int nQuestsNum = GetAttributesNum(quests);

		for(int n = 0; n < nQuestsNum; n++)
		{
			quest = GetAttributeN(quests,n);

			string sQuestName = GetAttributeName(quest);
			if (CheckAttribute(Pchar, "Quest.Deposits."+sQuestName+".Sum"))
			{
				int iPastMonths = GetPastTime("Month", makeint(Pchar.Quest.Deposits.(sQuestName).StartYear),makeint(Pchar.Quest.Deposits.(sQuestName).StartMonth),makeint(Pchar.Quest.Deposits.(sQuestName).StartDay), makefloat(Pchar.Quest.Deposits.(sQuestName).StartTime), getDataYear(),getDataMonth(),GetDataDay(), GetTime());
				deposits += CalcUsurerSumWithInterest(makeint(Pchar.Quest.Deposits.(sQuestName).Sum), makeint(Pchar.Quest.Deposits.(sQuestName).Interest), iPastMonths);
			}
		}
	}
	if(deposits >= 50000000) UnlockAchievement("bank_money", 3);
}
