// Gregg: Alejon Kendart - "Two Sisters", chapter 10 of the K:PS story line.
// Logic - Program\Quests\reaction_functions\twosisters.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Kendart is waited on three times in this chapter - split by quest state
			if (PChar.TwoSisters == "3")
			{
				dialog.text = "Vivant. ...(il regarde le bandage)... Je ne vous demanderai rien. Asseyez-vous et racontez.";
				link.l1 = "Ce médaillon. Il vous dit quelque chose ?";
				link.l1.go = "17";
				break;
			}
			if (PChar.TwoSisters == "6")
			{
				dialog.text = "Les quatre sont là, je les ai vues moi-même. La maison ouvrira dans la semaine.";
				link.l1 = "Alors j'ai mérité mon pain.";
				link.l1.go = "28";
				break;
			}
			if (PChar.TwoSisters == "1")
			{
				dialog.text = "Entrez, il faut que nous parlions. Et je vous le dis tout de suite : l'affaire est idiote.";
				link.l1 = "Continuez.";
				link.l1.go = "1";
				break;
			}
			dialog.text = "Tout est calme pour l'instant. Passez si quelque chose se présente.";
			link.l1 = "Je le ferai.";
			link.l1.go = "exit";
		break;

		// The setup
		case "1":
			dialog.text = "Vous vous souvenez de vous être plaint qu'il n'y avait pas de bordel à San Juan ?";
			link.l1 = "Je ne me souviens de rien de tel.";
			link.l1.go = "2";
			link.l2 = "Oui. Et alors ?";
			link.l2.go = "2";
		break;

		case "2":
			dialog.text = "Maintenant, ce sont les corsaires qui se plaignent. Depuis deux semaines, et de plus en plus fort chaque jour.";
			link.l1 = "Qu'ils se plaignent.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Qu'ils se plaignent, oui. Seulement, après les plaintes viennent les coups de couteau sur les quais, et ensuite, la moitié d'entre eux partent chez les Français.";
			link.l1 = "Et qu'attendez-vous de moi ?";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Persuader quatre femmes de s'installer à San Juan et les amener ici.";
			link.l1 = "...(un long silence)... Vous êtes sérieux ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Tout à fait. Nous sommes assis sur un baril de poudre, mon cher associé.";
			link.l1 = "Envoyez quelqu'un d'autre.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Quelqu'un d'autre, elles l'enverront au diable. Vous, elles vous écouteront peut-être.";
			link.l1 = "Quel compliment.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "C'est celui que vous aurez. Et puis, vous avez promis d'aider cette colonie, et je ne suis pas le seul à l'avoir entendu.";
			link.l1 = "C'est vrai. Bon, qui sont-elles ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Ce sont les pirates qui ont dressé la liste eux-mêmes. Quatre : Viki Henderson à la Martinique, Natali Remis aux Bermudes, et les sœurs Lus à Tortuga.";
			link.l1 = "Henderson, celle du bordel de Fort-de-France ?";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Elle-même. Dites que vous venez de ma part, et elle vous écoutera.";
			link.l1 = "Et comment suis-je censé les convaincre ? Aller les voir et les inviter ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Vous trouverez bien. Elles ne viendront pas pour rien, chacune demandera son prix.";
			link.l1 = "Alors je vais aussi travailler pour elles.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Tout est possible.";
			link.l1 = "...(un lourd soupir)...";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Arrêtez de soupirer et mettez-vous au travail. Le temps presse.";
			link.l1 = "...(partir)...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersStart");
		break;

		// The satanist's medallion
		case "17":
			dialog.text = "...(il prend le médaillon)... Oui. Oם l'avez-vous trouvé ?";
			link.l1 = "Sur un cadavre, dans la maison des sœurs Lus. Le corps a disparu ensuite.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Alors écoutez. Une secte porte ces médaillons, ils se font appeler les animatistes. On sait peu de choses sur eux, et tout est abject.";
			link.l1 = "Oם dois-je les chercher ?";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Il y a quinze ans, leur repaire se trouvait près de Belize, l'espagnole. C'est à cette époque que des gens ont commencé à y disparaître, d'abord un par un, puis par dizaines.";
			link.l1 = "Les a-t-on chassés ?";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "On a essayé. La garnison du fort a perdu les trois quarts de ses hommes, et Belize a perdu son gouverneur. Après ça, personne ne s'en est plus mêlé.";
			link.l1 = "Et personne n'a jamais découvert qui ils sont ?";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Le nouveau gouverneur a offert cent mille à quiconque expliquerait les disparitions. Un homme du nom de Meril Kreno a empoché l'argent.";
			link.l1 = "Qu'a-t-il expliqué ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "Rien. Il a écrit un mémoire sur la fièvre des marais, il a touché sa récompense, et les gens ont continué à disparaître.";
			link.l1 = "Kreno est vivant ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Vivant, et il habite à Belize, dans la maison voisine de la capitainerie. Si quelqu'un sait quelque chose sur ce médaillon, c'est lui.";
			link.l1 = "Alors j'irai le voir.";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "Pas de front, " + GetFullName(PChar) + ". Ce n'est pas le genre d'homme qu'on effraie.";
			link.l1 = "Encore une chose. Ce sataniste s'est relevé après avoir été tué.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "...(grimace)... Ou bien il n'avait jamais été tué. On me l'a raconté deux fois, et les deux conteurs étaient ivres.";
			link.l1 = "Moi, j'étais sobre.";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "C'est pour ça que je vous écoute. Si vous apprenez quoi que ce soit, faites-le-moi savoir, et je ressortirai les vieux papiers.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersLusQuestToBeliz");
		break;

		// The end
		case "28":
			dialog.text = "Vous l'avez fait. La maison est ouverte, les corsaires sont contents, et moi aussi. ...(après un silence)... א propos de Kreno, d'ailleurs, vous aviez raison.";
			link.l1 = "א propos de quoi ?";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "De rien. Des papiers vieux de quinze ans, signés de sa main, et plus rien à chercher : vous l'avez enterré.";
			link.l1 = "Alors c'est fini.";
			link.l1.go = "31";
		break;

		case "31":
			dialog.text = "Attendez, ne partez pas. Pendant que vous étiez en mer, un chargement de canons nous est arrivé.";
			link.l1 = "Quels canons ?";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "...(plus bas)... Des pièces de quarante-deux livres. Ne me demandez pas d'oם. Si vous les voulez, nous vous les installerons.";
			link.l1 = "Je les veux.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Alors j'en toucherai un mot au charpentier de marine. Dites-lui quand vous serez prêt.";
			link.l1 = "Je suis prêt tout de suite.";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "...(d'un air rusé)... וvidemment. Deux choses, alors. Le navire doit être de deuxième classe ou mieux, et on ne les installe qu'une fois : si vous les retirez, vous ne pourrez plus les remettre.";
			link.l1 = "Compris. Merci, Alejon.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("TwoSistersEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
