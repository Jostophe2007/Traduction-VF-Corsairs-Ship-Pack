// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Eh bien, laissez-moi deviner... Encore rien d'important ?",
                          "וcoutez, moi, je m'occupe de finances, pas de répondre aux questions...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Vous avez deviné, désolé...", "Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> Квест Аззи
			if (CheckAttribute(pchar, "questTemp.Azzy.GiveMoney"))
            {
                link.l5 = "Je viens de la part d'Azzi. Vous devez avoir quelque chose de prêt pour moi.";
                link.l5.go = "Step_Az_1";
            }
			if (!CheckAttribute(pchar, "questTemp.Azzy.GiveMoney") && pchar.questTemp.Azzy == "HowToKnowAzzy")
            {
                link.l5 = "וcoutez, je dois trouver Azzi de toute urgence.";
                link.l5.go = "Step_Az_4";
            }
		break;
        // ==> Квест Аззи. Дача трёх лимонов ГГ по поручению Аззи.
		case "Step_Az_1":
			dialog.text = "Très bien. Trois millions en espèces vous attendent, " + GetAddress_Form(NPChar) + ". Voulez-vous les recevoir tout de suite ?";
			Link.l1 = "Oui, et la somme entière.";
			Link.l1.go = "Step_Az_2";
		break;
		case "Step_Az_2":
			dialog.text = "Je vous en prie, " + GetAddress_Form(NPChar) + ". Y a-t-il autre chose ?";
			Link.l1 = "Non, rien d'autre... Dites, quelle affaire avez-vous avec cet Azzie ? Je demande ça par simple curiosité...";
			Link.l1.go = "Step_Az_3";
            DeleteAttribute(pchar, "questTemp.Azzy.GiveMoney");
            AddMoneyToCharacter(pchar, 3000000);
		break;
		case "Step_Az_3":
			dialog.text = ""+ GetSexPhrase("Monsieur", "Mademoiselle") +", je vous conseille de ne pas poser trop de questions. Avec Azzie, c'est dangereux pour la vie. Si c'est tout, laissez-moi vaquer à mes affaires...";
			Link.l1 = "Oui, bien sמr ! Merci pour l'argent.";
			Link.l1.go = "exit";
		break;
		case "Step_Az_4":
            dialog.text = NPCStringReactionRepeat("Vous cherchez Azzi ? Je ne vous conseille pas de le chercher. Je vous ai déjà dit que c'était dangereux pour la vie.", "Je ne veux plus en parler.", "Non, j'en ai assez...", "Je ne dirai rien.", "block", 0, npchar, Dialog.CurrentNode);
			Link.l1 = HeroStringReactionRepeat("Il y va de ma vie. J'en ai besoin : si vous savez comment le trouver, dites-le-moi, je vous en prie.", "Je comprends...", "Pardon...", "Eh bien, alors vous n'avez vraiment rien à dire.", npchar, Dialog.CurrentNode);
			Link.l1.go = DialogGoNodeRepeat("Step_Az_5", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;
		case "Step_Az_5":
			dialog.text = "Malheureusement, je ne sais pas. Je n'en ai aucune idée\n"+
                     "Vous savez, j'ai pris ces cinq millions sans vraiment penser aux conséquences. Oui, cinq exactement, puisque deux d'entre eux m'étaient destinés en paiement de mon travail\n"+
                     "Eh bien, ces deux millions, une somme énorme, m'ont littéralement ruiné. Je ne veux pas entrer dans les subtilités des opérations financières, mais croyez-moi : il y a là quelque chose de louche\n"+
                     "Je me suis toujours cru très perspicace. Mais comment ai-je pu ne rien deviner cette fois, je n'en sais rien.";
			Link.l1 = "Tout est clair... Merci.";
			Link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

