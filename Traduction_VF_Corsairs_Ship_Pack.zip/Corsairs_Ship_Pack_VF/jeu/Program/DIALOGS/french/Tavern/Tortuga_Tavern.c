// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Tous les potins de la ville de "+ GetCityName(npchar.city) +" à votre service. Que voulez-vous savoir ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "Pourquoi répétez-vous comme un perroquet ? Toujours la même chose...", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Oui...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.Slavetrader == "FindRatTortuga")
            {
                link.l1 = "Dites, oם puis-je trouver François Gontier ? Il devrait être arrivé à Tortuga à l'heure qu'il est.";
                link.l1.go = "Tortuga_ratT_1";
            }
            // ==> Проверяем поле состояния квестов.
            switch(pchar.questTemp.State)
            {
                case "WormEnglPlans_WormPicarder": //Голландская линейка, квест №3. узнаем о Пеьере Пикардийце.
                    link.l1 = "Dites, vous connaissez le flibustier Pierre Picardy ?";
                    link.l1.go = "Step_H3_1";
                break;
                case "DelivLettTortuga_toStranger": //Голландская линейка, квест №7. узнаем о ожидающем ГГ человеке.
                    link.l1 = "וcoutez, vous n'êtes pas au courant ? On m'attend ici, je "+ GetSexPhrase("suis arrivé", "suis arrivée") +" de Curaçao...";
                    link.l1.go = "Step_H7_1";
                break;
                case "DelivLettTortuga_AfterRape": //Голландская линейка, квест №7. пытаемся узнать, кто был грабитель.
                    link.l1 = "Oם est cet homme qui m'attendait dans la chambre à l'étage ?";
                    link.l1.go = "Step_H7_2";
                break;
                case "SeekBible_toTavern": //Голландская линейка, квест №8. узнаем, где Лоран де Граф.
                    link.l1 = "Savez-vous oם je peux trouver le flibustier Laurent de Graaf ?";
                    link.l1.go = "Step_H8_1";
                break;
                case "TakeRockBras_toTortuga": //Испанская линейка, квест №3. узнаем, где Рок Бразилец.
                    link.l1 = "L'ami, tu peux me dire comment trouver Rock le Brésilien ?";
                    link.l1.go = "Step_S3_1";
                break;
                case "Sp4Detection_toTortuga": //Испанская линейка, квест №4. узнаем о донне Анне.
                    link.l1 = "Quoi de neuf à Tortuga ?";
                    link.l1.go = "Step_S4_1";
                break;
                case "Sp6TakeMess_toTotuga": //Испанская линейка, квест №6. узнаем о вестовом
                    link.l1 = "Dites, les Hollandais de Curaçao viennent-ils souvent chez vous ?";
                    link.l1.go = "Step_S6_1";
                break;
                case "Sp6TakeMess_waitMessanger": //Испанская линейка, квест №6. узнаем о вестовом
                    link.l1 = "Dites, les Hollandais de Curaçao viennent-ils souvent chez vous ?";
                    link.l1.go = "Step_S6_1";
                break;
				if(PChar.Dozor == "8")
              	{
                    link.l2 = "Le brave capitaine est sur la piste de l'Escadre insaisissable.";
                    link.l2.go = "Dozor_1";
              	}
            }
            // <== Проверяем поле состояния квестов.
        break;
//===================================== Голл. линейка, квест №3 =========================================
 	 	case "Step_H3_1":
			dialog.text = NPCStringReactionRepeat("Comment ne pas le connaître ? Il m'a loué une chambre et il a payé un an d'avance !", "Hé, vous ne m'avez pas déjà "+ GetSexPhrase("posé la question", "posé la question") +" à ce sujet ?",
				          "Hum, nous avons déjà parlé de Pierre...", "Vous voulez bien arrêter de me distraire ? Je peux envoyer chercher Pierre si vous tenez vraiment à le voir.", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Eh bien ! Apparemment, il ne manque pas d'argent...", ""+ GetSexPhrase("Je vous l'ai demandé", "Je vous l'ai demandé") +" ? Eh bien, oui, sans doute...", "Oui, c'est vrai, on en a parlé, désolé...", "Non, ce n'est pas la peine. "+ GetSexPhrase("Vous savez,", "Vous savez,") +"Je le trouverai...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H3_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H3_2":
			dialog.text = "Bien sמr ! Récemment, Morgan l'a invité à participer à l'attaque des mines d'argent espagnoles. Apparemment, ils sont arrivés là-bas à temps.";
			link.l1 = "Il a de la chance, que dire...";
			link.l1.go = "Step_H3_3";
        break;
 	 	case "Step_H3_3":
			dialog.text = "Mais il n'est pas dans sa chambre en ce moment, revenez plus tard, vous pourrez alors le trouver.";
			link.l1 = "Merci, c'est ce que je vais faire.";
			link.l1.go = "exit";
            pchar.questTemp.Talks.Tavern = true;
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "7");
        break;
//============================ Голл. линейка, квест №7. узнаем о ожидающем ГГ челе =======================
 	 	case "Step_H7_1":
			dialog.text = NPCStringReactionRepeat("Je suis au courant. Montez à la chambre à l'étage, un type vous y attend.", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" aujourd'hui.", "Encore ?", "Vous voulez bien ne pas me distraire de mon travail ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Merci, mon vieux.", "Vous avez raison, "+ GetSexPhrase("posé la question", "posé la question") +"...", "Désolé...", "D'accord, je n'insiste pas. Désolé...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("exit", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
 	 	case "Step_H7_2":
			dialog.text = NPCStringReactionRepeat("Il est parti il y a environ une heure, il a dit que vous seriez en retard...", "Vous m'avez déjà "+ GetSexPhrase("posé la question", "posé la question") +" aujourd'hui.", "Encore ?", "Vous voulez bien ne pas me distraire de mon travail ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Bon sang ! Qui est-ce, et oם est-il allé, vous le savez ?", "C'est vrai, "+ GetSexPhrase("posé la question", "posé la question") +"...", "Hum, désolé...", "D'accord, je n'insiste pas. Désolé...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_H7_3", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
  	 	case "Step_H7_3":
			dialog.text = "Il est arrivé ici avant-hier, il a tout de suite dit qu'il attendait quelqu'un. Il s'intéressait aux navires venant de Curaçao. C'est donc vous qu'il attendait. Et je ne sais pas oם il est allé.";
			link.l1 = "Et vous ne savez rien du tout sur lui ?";
			link.l1.go = "Step_H7_4";
        break;
  	 	case "Step_H7_4":
			dialog.text = "Je ne l'avais jamais vu avant, mais c'est un bon client, il a payé sa chambre deux fois le prix. Je ne peux rien vous dire de plus.";
			link.l1 = "Eh bien, merci quand même...";
			link.l1.go = "exit";
        break;
//============================ Голл. линейка, квест №8. узнаем о Лоране де Графе =======================
  	 	case "Step_H8_1":
			dialog.text = "Vous ne le trouverez pas à Tortuga en ce moment. Il a quitté la ville il y a quelques semaines. Il est sans doute encore en train d'étriper les Espagnols...";
			link.l1 = "Oם est-il allé, vous le savez avec certitude ?";
			link.l1.go = "Step_H8_2";
        break;
  	 	case "Step_H8_2":
			dialog.text = "Ce n'est pas vraiment l'usage, chez les flibustiers, de répandre ses projets.";
			link.l1 = "Compris... Et à qui puis-je demander ?";
			link.l1.go = "Step_H8_3";
        break;
  	 	case "Step_H8_3":
			dialog.text = "Pourquoi en avez-vous besoin ?";
			link.l1 = "J'ai besoin de lui de toute urgence, pour une affaire très importante. "+ GetSexPhrase("Je l'ai cherché", "Je l'ai cherché") +" aux Bermudes, maintenant je le cherche ici. Je suis "+ GetSexPhrase("moi-même hollandais", "moi-même hollandaise") +", comme Laurent...";
			link.l1.go = "Step_H8_4";
        break;
   	 	case "Step_H8_4":
			dialog.text = "Bon, je vais vous le dire, si c'est nécessaire. J'ai entendu dire qu'il croise près de Carthagène. De Graaf dispose de la frégate Cominte.";
			link.l1 = "Compris. Merci, mon ami.";
			link.l1.go = "exit";
            pchar.questTemp.State = "SeekBible_toDeGraf";
            AddQuestRecord("Hol_Line_8_SeekBible", "5");
            Pchar.quest.SeekBible_SaveDeGraf.win_condition.l1 = "location";
            Pchar.quest.SeekBible_SaveDeGraf.win_condition.l1.location = "Cartahena";
            Pchar.quest.SeekBible_SaveDeGraf.win_condition = "SeekBible_SaveDeGraf";
        break;
//============================ Исп. линейка, квест №3. узнаем о Роке Бразильце =======================
  	 	case "Step_S3_1":
			dialog.text = "דa dépend de la raison. C'est urgent à quel point ?";
			link.l1 = "J'ai besoin de lui de toute urgence, j'ai une affaire sérieuse à régler avec lui.";
			link.l1.go = "Step_S3_2";
        break;
  	 	case "Step_S3_2":
			dialog.text = "Alors c'est un problème. Rock est parti en direction de Maracaibo sur sa corvette ; il croisera dans les parages jusqu'à ce qu'il attrape un galion avec un butin convenable.";
			link.l1 = "Voilà donc ! C'est parfait, car je dois justement me rendre dans cette région. J'espère l'y rencontrer. Merci.";
			link.l1.go = "Step_S3_3";
        break;
  	 	case "Step_S3_3":
			dialog.text = "Je vous en prie...";
			link.l1 = "Porte-toi bien, mon vieux.";
			link.l1.go = "exit";
            pchar.questTemp.State = "TakeRockBras_toNearestMaracaibo";
            AddQuestRecord("Spa_Line_3_RockBrasilian", "2");
			pchar.quest.TakeRockBras_toRock.win_condition.l1 = "location";
			pchar.quest.TakeRockBras_toRock.win_condition.l1.location = "Maracaibo";
			pchar.quest.TakeRockBras_toRock.win_condition = "TakeRockBras_toRock";
        break;
//============================ Испанская линейка, квест №4. узнаем о донне Анне. =======================
  	 	case "Step_S4_1":
			dialog.text = "Oui, tout est pareil, nous sommes en guerre contre ces maudits papistes.";
			link.l1 = "Ah, voilà une bonne chose. Et des papistes, vous en avez en ville ? Elles sont chaudes, à ce qu'on dit, leurs femmes...";
			link.l1.go = "Step_S4_2";
        break;
  	 	case "Step_S4_2":
			dialog.text = "Jusqu'à récemment, il n'y en avait aucune. Mais maintenant, notre estimé gouverneur général d'Ogeron a une chèvre espagnole, oh, très belle. Le gouverneur général est tout simplement heureux, et il a le sourire aux lèvres du matin au soir. Je ne sais pas ce qu'il en est la nuit, hi hi...";
			link.l1 = "Voilà donc ! Et qui est cette femme audacieuse ?";
			link.l1.go = "Step_S4_3";
        break;
  	 	case "Step_S4_3":
			dialog.text = "Doña Anna, c'est son nom. J'ai entendu dire qu'elle venait de La Havane.";
			link.l1 = "Les flibustiers ne sont pas encore allés jusqu'à La Havane. Comment est-elle arrivée chez d'Ogeron, capturée sur un galion espagnol ?";
			link.l1.go = "Step_S4_4";
        break;
  	 	case "Step_S4_4":
			dialog.text = "Non, c'est réciproque. Doña Anna aime notre gouverneur général autant qu'il l'aime. J'ai entendu dire qu'ils s'étaient rencontrés dans l'Ancien Monde. C'est l'un des officiers de confiance du gouverneur général, Henri d'Estre, qui l'a amenée à Tortuga ; personne ne sait oם il l'a trouvée.";
			link.l1 = "Compris... Et oם est cet Henri d'Estre maintenant ?";
			link.l1.go = "Step_S4_5";
        break;
  	 	case "Step_S4_5":
			dialog.text = "Chez lui, sans doute. Il a une maison ici, sur l'île.";
			link.l1 = "Je vois que Tortuga prospère, et j'en suis très, très heureux"+ GetSexPhrase("content", "contente") +". Porte-toi bien, l'ami.";
			link.l1.go = "exit";
            pchar.questTemp.State = "Sp4Detection_toDEstre";
            AddQuestRecord("Spa_Line_4_MirderDetection", "5");
        break;
//============================ Испанская линейка, квест №6. перехватить вестового. =======================
  	 	case "Step_S6_1":
			dialog.text = NPCStringReactionRepeat("Il y en a, mais qu'est-ce que ça peut vous faire ?",
                          "Les Hollandais ? Parfois, parfois...", "Nous avons déjà parlé des Hollandais aujourd'hui...",
                          "Je ne veux plus parler des Hollandais...", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'attends ici un homme de Willemstad. Il va donc falloir que je vous loue une chambre pour une semaine.",
                      "Parfait !", "On en a parlé, c'est vrai...", "D'accord, comme vous voudrez...", npchar, Dialog.CurrentNode);
			link.l1.go =  DialogGoNodeRepeat("Step_S6_2", "none", "none", "none", npchar, Dialog.CurrentNode);
        break;
  	 	case "Step_S6_2":
			dialog.text = "Pas de problème, la chambre est libre. Payez 35 pièces la semaine et installez-vous.";
			link.l1 = "Je vous paierai cent pièces pour la semaine, qu'est-ce que c'est, 35 pièces ? Des miettes...";
			link.l1.go = "Step_S6_3";
        break;
  	 	case "Step_S6_3":
			dialog.text = "Hé, eh bien, merci, "+ GetSexPhrase("homme généreux", "dame généreuse") +". Je ne refuserai pas l'argent. Et vous pouvez occuper la chambre tout de suite, elle est ouverte.";
			link.l1 = "Merci.";
			link.l1.go = "exit";
			pchar.questTemp.State.Open = 1;
			LocatorReloadEnterDisable("Tortuga_tavern", "reload2_back", false);
            AddMoneyToCharacter(pchar, -100);
            if (CheckAttribute(pchar, "questTemp.State.Sp6Ok"))
            {
                SetTimerCondition("Sp6TakeMess_waitingBoy", 0, 0, rand(7)+1, false);
                DeleteAttribute(pchar, "questTemp.State.Sp6Ok");
            }
            else
            {
                pchar.questTemp.State.Sp6Ok = 1;
            }
        break;

		case "Tortuga_ratT_1":
			dialog.text = "François Gontier ? Et qui est ce type ? Je ne connais personne de ce nom.";
			link.l1 = "Eh bien, c'est le capitaine de la corvette '" + pchar.questTemp.Slavetrader.ShipName + "'.";
			link.l1.go = "Tortuga_ratT_2";
        break;

		case "Tortuga_ratT_2":
			dialog.text = "Je n'en ai aucune idée, "+ GetSexPhrase("l'ami", "madame") +". Et aucune corvette de ce nom n'a accosté dans notre port, j'en suis certain.";
			link.l1 = "Bon, avez-vous vu des inconnus en ville ces derniers temps ?";
			link.l1.go = "Tortuga_ratT_3";
        break;

		case "Tortuga_ratT_3":
			dialog.text = "Ha, quelle question stupide ! C'est une ville portuaire, pas un village. Des inconnus arrivent ici tous les jours... Cela dit, j'ai entendu parler de drכles de types qui se sont montrés récemment chez nous : ils se promènent toujours ensemble, à cinq, la main sur la garde de leur sabre, comme dans une colonie ennemie. La patrouille les a déjà contrכlés : non, tout est en ordre. Mais ils ne sont certainement pas arrivés sur une corvette : ni au port ni en rade, pas une seule corvette, vous comprenez ?";
			link.l1 = "Euh... Bon, je vois. Merci, " + npchar.name + ".";
			link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_8");
			pchar.questTemp.Slavetrader = "wait1";//затычка
        break;

            // DOZOR -->
		case "Dozor_1":
			TakeNItems(PChar, "Dozor_Mekakhrom", 1);
			dialog.text = "Ah ! C'est donc vous, le veilleur ? Vous avez donc déjà résolu trois énigmes, bravo ! Voici un Meckachrome avec la quatrième énigme. Bonne chance pour en venir à bout, elle sera un peu plus difficile que les autres.";
			link.l1 = "Au revoir.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DozorTortugaTavernGetItem");
		break;
			// DOZOR <--

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

