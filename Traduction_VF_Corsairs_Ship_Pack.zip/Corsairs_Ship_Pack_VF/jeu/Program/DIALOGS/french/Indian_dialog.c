// диалог индейцев в поселениях
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	int i, iTemp;
	string sTemp;
	bool bOk;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Il n'y a rien à dire !";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		// ==> индейцы в поселении
		case "IndianMan":
			NextDiag.TempNode = "IndianMan";
			dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Visage pâle", "Squaw blanche") +" veut parler ?", 
				"Encore toi, "+ GetSexPhrase("visage pâle", "squaw blanche") +".", 
				""+ GetSexPhrase("Visage pâle aime parler. Il ressemble à une squaw.", "Squaw blanche aime parler.") +"",
                "Les esprits m'amènent le visage pâle, "+ GetSexPhrase("frère", "sœur") +".", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui.", 
				"Oui, c'est encore moi.",
                "Très poétique.", 
				"דa me fait plaisir aussi de te voir.", npchar, Dialog.CurrentNode);
			link.l1.go = "IndPearlMan_1";
			
			/*if (npchar.quest.meeting == "0")
			{
				dialog.text = "Hello, white brother. Do you want to say Indian?";
				link.l1 = "Greetings, son of the jungle. I'm glad to see you, but it's time for me to continue my journey.";
				link.l1.go = "exit";
				link.l2 = "Yes. I've heard that you can buy interesting things from you. Don't you have anything to sell?";
				link.l2.go = "select_trade";
				npchar.quest.meeting = "1";
			}*/
		break;
		
		case "IndPearlMan_1":
			dialog.text = "Dis-moi ce qui t'amène.";
			link.l1 = "Rien de spécial, je voulais juste t'écouter...";
			link.l1.go = "exit";
		break;
		
		case "IndianWoman":
			NextDiag.TempNode = "IndianWoman";
			dialog.text = NPCStringReactionRepeat(""+ GetSexPhrase("Visage pâle", "Squaw blanche") +" veut parler ?", 
				"Encore toi, yalanaui ?", 
				""+ GetSexPhrase("Visage pâle", "Squaw blanche") +" aime parler.",
                "Les esprits m'amènent un visage pâle, "+ GetSexPhrase("mon frère", "ma sœur") +".", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui.", 
				"Oui, c'est encore moi.",
                "Très poétique.", 
				"דa me fait plaisir aussi de te voir.", npchar, Dialog.CurrentNode);
			link.l1.go = "IndianWoman_1";
		break;
		
		case "IndianWoman_1":
			dialog.text = LinkRandPhrase(""+npchar.name+", je t'écoute, "+ GetSexPhrase("fils de la mer", "fille de la mer") +".", "Que voulez-vous, " + npchar.name+", "+ GetSexPhrase("visage pâle", "squaw blanche") +" ?", "Mes oreilles sont ouvertes à tes paroles, visage pâle.");
			/*if (CheckIndianGift() && !CheckAttribute(npchar, "quest.gift"))
			{
				link.l1 = LinkRandPhrase("I have something for you. Do you want to see it?", "Do you want me to show you something interesting? You'll like it...", "I have something that will please you, child of the jungle... Do you want to take a look?");
				link.l1.go = "gift";
			}*/
			link.l9 = "Rien de spécial, je voulais juste t'écouter...";
			link.l9.go = "exit";
		break;
		
		case "Shoko_1":
			dialog.text = "Ahau, yalanaui.";
			link.l9 = "Bonjour, ma belle. Je m'appelle "+pchar.name+". Comment vous appelez-vous ?";
			link.l9.go = "Shoko_2";
		break;
		
		case "Shoko_2":
			dialog.text = "Shoko.";
			link.l9 = "Pouvez-vous me parler un peu de votre peuple, Shoko ?";
			link.l9.go = "Shoko_3";
		break;
		
		case "Shoko_3":
			dialog.text = "Lilachil pel ukuchu lutilili, chin tu kult.";
			link.l9 = "C'est très intéressant. Puis-je marchander avec quelqu'un ici ?";
			link.l9.go = "Shoko_4";
		break;
		
		case "Shoko_4":
			dialog.text = "Dolin vaughan hinch of pain. Bash kulyuchu nahau ?";
			link.l9 = "Euh, bon... Je vais demander à quelqu'un d'autre. Au revoir !";
			link.l9.go = "exit";
			NextDiag.TempNode = "ShokoAgain";
		break;
		
		case "ShokoAgain":
			dialog.text = "Ahau, yalanaui. Mache esh.";
			link.l9 = "Moi aussi, ça me fait plaisir de te voir.";
			link.l9.go = "exit";
			NextDiag.TempNode = "ShokoAgain";
		break;
		
		case "Chani_1":
			dialog.text = "Capono bambule, gucho. Je suis Chani, fille de Chaka Bakir, chaman de la tribu des Shaganumbi.";
			link.l1 = "Je m'appelle " + GetFullName(pchar)+", je suis capitaine du navire « " + PChar.Ship.Name + " ». C'est le hasard qui m'a mené sur ces terres, et je découvre les traditions locales.";
			link.l1.go = "Chani_2";
		break;
		
		case "Chani_2":
			dialog.text = "Puisque tu es capitaine, tu es quelqu'un d'important. Ce n'est pas facile pour moi de demander ça, mais nous avons besoin de ton aide, yalanaui.";
			link.l1 = "Que puis-je faire pour vous ?";
			link.l1.go = "Chani_3";
			link.l2 = "Pardon, mais je n'ai pas le temps pour tes problèmes en ce moment.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Chani_1";
		break;
		
		case "Chani_3":
			dialog.text = "Les Blancs prélèvent un tribut sur nous, ils nous forcent à leur donner nos perles. Ils demandaient peu, et nous donnions autant qu'ils demandaient. Mais récemment, un homme très important est venu ici, Manuel de Moreno, avec une grande armée, et il a exigé que nous récoltions 800 grosses perles.\nNous avons donné tout ce que nous avions, mais ce n'était pas assez. Nous devons encore 500 grosses perles à Manuel de Moreno, mais nous n'avons plus rien. Sinon, il a promis de raser notre village.\nJe t'en prie, capitaine, aide-nous à payer ce tribut, et en échange, je te promets un élixir, les Larmes d'Ix Chel, qui t'aidera à améliorer ta santé.";
			link.l1 = "D'accord, je trouverai ces 500 grosses perles et je te les apporterai.";
			link.l1.go = "Chani_4";
			if (sti(pchar.items.jewelry11) >= 500)
			{
				link.l1 = "J'ai 500 grosses perles sur moi. Maintenant, ton village sera en sécurité.";
				link.l1.go = "Chani_Zhemchug2";
			}
			link.l2 = "Ton village me fait de la peine, mais je ne peux pas t'aider.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Chani_1";
		break;
		
		case "Chani_4":
			dialog.text = "Merci, yalanaui. Tu as bon cœur. Je t'attendrai.";
			link.l1 = "Dès que j'aurai réuni la quantité qu'il faut, je reviendrai te voir.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Chani_Zhemchug";
			npchar.quest.takePearls = "seek";
			npchar.quest.takePearls.Qty = 0; //кол-во жемчужин
			
			SetQuestHeader("ShamanChani");
			AddQuestRecord("ShamanChani", "1");
		break;
		
		case "Chani_Zhemchug":
			dialog.text = "Je suis contente de te voir, yalanaui.";
			link.l1 = "Chani, je veux te donner mes perles.";
			link.l1.go = "Chani_Zhemchug2";
			link.l2 = "Il est temps pour moi de partir...";
			link.l2.go = "exit";
			NextDiag.TempNode = "Chani_Zhemchug";
		break;
		
		case "Chani_Zhemchug2":
			iTemp = GetCharacterItem(pchar, "jewelry11");
			npchar.quest.takePearls.Qty = sti(npchar.quest.takePearls.Qty) + iTemp;
			DeleteAttribute(pchar, "items.jewelry11");
			if (sti(npchar.quest.takePearls.Qty) < 500)
			{
				dialog.text = "Comptons. Cette fois, tu m'as apporté des grosses perles : "+ GetSexPhrase("", "") +" " + FindRussianQtyString(iTemp) + " – en tout, tu m'en as remis "+ GetSexPhrase("", "") +" " + FindRussianQtyString(sti(npchar.quest.takePearls.Qty)) + " – il t'en reste encore à apporter " + FindRussianQtyString(500 - sti(npchar.quest.takePearls.Qty)) + ".";
				link.l1 = "Je vois. Je reviendrai bientכt avec d'autres perles, Chani.";
				link.l1.go = "exit";
				AddQuestRecord("ShamanChani", "2");
				AddQuestUserData("ShamanChani", "iQty", 500 - sti(npchar.quest.takePearls.Qty));
			}
			else
			{
				dialog.text = "Merci aux dieux ! Tu as prouvé, "+pchar.name+", que notre village est aussi ta maison. Maintenant, je suis sמre que les Indiens seront en sécurité.";
				link.l1 = "דa me fait très plaisir à entendre, Chani.";
				link.l1.go = "Chani_12";
				ChangeCharacterReputation(pchar, 1);
				AddQuestRecord("ShamanChani", "3");
			}
		break;
		
		case "Chani_12":
			dialog.text = "Je veux te faire notre précieux cadeau, les Larmes d'Ix Chel. Elles t'aideront à retrouver la santé si tu te sens mal.";
			link.l1 = "C'est un cadeau très précieux, merci.";
			link.l1.go = "Chani_13";
			GiveItem2Character(PChar, "potion7");
			Log_info("La chamane vous a remis les Larmes d'Ix Chel");
			PlaySound("Interface\important_item.wav");
		break;
		
		case "Chani_13":		
			dialog.text = "Reviens nous voir, à l'avenir, je trouverai du travail pour toi.";
			link.l1 = "Je passerai sans faute. א bientכt !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Chani_21";
			SetTimerCondition("CSP_Chani_2quest", 0, 0, 14, false);
		break;
		
		case "Chani_21":		
			dialog.text = "Bienvenue dans notre village, yalanaui. Tu voulais quelque chose ?";
			link.l1 = " Je ne faisais que passer. א bientכt !";
			link.l1.go = "exit";
			NextDiag.TempNode = "Chani_21";
			if (CheckAttribute(pchar, "quest.Chani_2quest"))
			{
				dialog.text = "Te revoilà, gucho. Tu tombes à pic. J'ai besoin de ton aide.";
				link.l1 = "Et de quoi s'agit-il cette fois ?";
				link.l1.go = "Chani_22";
			}
		break;
		
		case "Chani_22":		
			dialog.text = "Tagana, l'un de nos guerriers les plus forts. Je l'ai envoyé accomplir une tâche, et je ne l'ai jamais revu.";
			link.l1 = "Tu peux être plus précise ? Oם as-tu envoyé Tagana, et qu'avait-il à faire ? ";
			link.l1.go = "Chani_23";
		break;
		
		case "Chani_23":		
			dialog.text = "Il devait partir très loin, en terre étrangère, pour y trouver quelque chose dont j'ai grand besoin. ";
			link.l1 = "Je pourrais le chercher. Mais s'il est parti seul, il est plus probable qu'il soit mort dans la nature.";
			link.l1.go = "Chani_24";
		break;
		
		case "Chani_24":		
			dialog.text = "Tagana est trop malin pour devenir la proie des bêtes sauvages.";
			link.l1 = "Est-il assez malin pour les hommes ? Il est peut-être devenu la proie d'une patrouille.";
			link.l1.go = "Chani_25";
		break;
		
		case "Chani_25":		
			dialog.text = "Les soldats, avec leurs lances de tonnerre, ne remarqueraient même pas Tagana : il est comme un jaguar qui se glisse dans le feuillage.";
			link.l1 = "Et quelle était la tâche de Tagana ?";
			link.l1.go = "Chani_26";
		break;
		
		case "Chani_26":		
			dialog.text = "Il devait obtenir des cannibales une décoction spéciale, dont j'ai besoin pour un rituel vaudou qui protégera le village.";
			link.l1 = "Et si je te procure cette décoction ?";
			link.l1.go = "Chani_28";
			if (sti(pchar.items.StrangePotion) >= 1)
			{
				link.l1 = "J'ai cette étrange décoction sur moi. Dans la jungle, des sauvages agressifs m'ont attaqué ; l'un d'eux avait ce flacon sur lui. Je pense que ce sont eux qui ont causé la perte de ton Tagana.";
				link.l1.go = "Chani_30";
			}
			link.l2 = "Le sort de Tagana me peine, mais je ne peux pas t'aider.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Chani_21";
		break;

		case "Chani_28":
			dialog.text = "Si tu me procures cette décoction, je te promets de te servir fidèlement et d'aller oם tu iras.";
			link.l1 = "D'accord, Chani. Si je trouve la bonne décoction, je reviendrai te voir.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Chani_29";
			AddQuestRecord("ShamanChani", "4");
			PChar.quest.CSP_Chani_PoiskOtvara.win_condition.l1 = "item";
			PChar.quest.CSP_Chani_PoiskOtvara.win_condition.l1.item = "StrangePotion";
			PChar.quest.CSP_Chani_PoiskOtvara.win_condition = "CSP_Chani_PoiskOtvara";
			pchar.questTemp.СhaniJidkost = "СhaniJidkost";
		break;
		
		case "Chani_29":
			dialog.text = "Contente de te voir, gucho. Tu m'apportes la décoction ?";
			link.l1 = "Pas encore, Chani, mais je la trouverai sans faute.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Chani_29";
			if (sti(pchar.items.StrangePotion) >= 1)
			{
				link.l1 = "Tiens, regarde, je pense que c'est ce que tu cherches. Je l'ai ramassée sur le cadavre d'un cannibale.";
				link.l1.go = "Chani_30";
			}
		break;
		
		case "Chani_30":		
			dialog.text = "Parfait ! Laisse-moi un peu de temps pour accomplir le rite de protection du village, et je t'accompagnerai dans ton voyage, sur ton grand canot.";
			link.l1 = "Bien, je t'attendrai, Chani.";
			link.l1.go = "Chani_31";
			DeleteAttribute(pchar, "quest.Chani_2quest");
			DeleteAttribute(pchar, "questTemp.СhaniJidkost");
			AddItems(pchar, "StrangePotion", -1);
			Log_info("Vous avez remis l'étrange liquide.");
		break;
				
		case "Chani_31":
			DialogExit();
			
			sld = CharacterFromID("Chani");
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true;
			sld.loyality = MAX_LOYALITY;
			AddPassenger(pchar, sld, false);
			SetShipRemovable(sld, true);
			SetCharacterRemovable(sld, true);
			sld.HalfImmortal = true;
			sld.location = "None";
			sld.Dialog.CurrentNode = "hired";
			sld.Payment = true;
			
			AddQuestRecord("ShamanChani", "6");
			CloseQuestHeader("ShamanChani");
			pchar.questdata.ShamankaChani = 1;
		break;
		
		//замечание по обнаженному оружию от персонажей типа citizen			
		case "CitizenNotBlade":
			dialog.text = RandPhraseSimple("Range tes armes, yalanaui, avant que nous ne t'y obligions !", "Ne tente pas le sort, visage pâle ! Range ton sabre !");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Pas d'inquiétude, je le range déjà...");
			link.l1.go = "exit";
		break;
		
		case "Woman_FackYou":
			dialog.text = "Au voleur !";
			link.l1 = "Tais-toi, imbécile...";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

	}
}
