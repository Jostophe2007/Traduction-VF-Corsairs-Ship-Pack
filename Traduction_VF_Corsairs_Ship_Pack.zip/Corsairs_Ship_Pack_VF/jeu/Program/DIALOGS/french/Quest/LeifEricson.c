// Квестовые атакующий кэпа, 10 штук в комплекте.
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
    int i;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
            if (pchar.questTemp.Ascold == "Ascold_MummyIsLive")
            {
            	dialog.text = "Tu t'es débrouillé avec mes serviteurs, c'est bien. Maintenant, dis-moi, en quelle année sommes-nous ?";
        		link.l1 = environment.date.year + "... Que diable se passe-t-il ?!!";
        		link.l1.go = "Step_8";
            }
            if (pchar.questTemp.Ascold == "Ascold_BodyChange")
            {
            	dialog.text = "Bien, tout va bien maintenant. Es-tu prêt à accomplir ton destin ?";
        		link.l1 = "Qu'as-tu fait ?!! וcoute, Leif, foutu Eriksson, le monde a beaucoup changé pendant tout ce temps. Il y a beaucoup de Blancs ici, maintenant.";
        		link.l1.go = "Step_25";
            }
            if (pchar.questTemp.Ascold == "Ascold_SkelSlave")
            {
            	dialog.text = "Maintenant, tu es prêt. Je te donne la permission de quitter le tombeau.";
        		link.l1 = "Qu'arrivera-t-il à mon corps ?";
        		link.l1.go = "Step_27";
            }
            if (pchar.questTemp.Ascold == "Ascold_ImMummy")
            {
            	dialog.text = "Fais ton travail, capre.";
        		link.l1 = "D'accord, Leif.";
        		link.l1.go = "exit";
            }
            if (pchar.questTemp.Ascold == "Ascold_MummyFoundItems")
            {
            	dialog.text = "Ah, te voilà enfin ! Oם sont les objets que je t'ai envoyé chercher ?";
                if  (CheckCharacterItem(pchar, "sculMa1") && CheckCharacterItem(pchar, "sculMa2") && CheckCharacterItem(pchar, "sculMa3") && CheckCharacterItem(pchar, "indian22"))
                {
                	link.l1 = "Je les ai. Prends-les et rends-moi mon corps !";
            		link.l1.go = "Step_29";
                }
                else
                {
                	link.l1 = "Je ne les ai pas...";
            		link.l1.go = "Step_30";
                }
            }
            if (pchar.questTemp.Ascold == "Ascold_BackMyBody")
            {
            	dialog.text = "Maintenant, je te libère. Tu peux partir, la sortie est libre.";
        		link.l1 = "Merci. J'espère que nous ne nous reverrons plus.";
        		link.l1.go = "Step_31";
            }
            if (pchar.questTemp.Ascold == "Ascold_ReturnToAscold")
            {
            	dialog.text = "Adieu, capre...";
        		link.l1 = "Adieu, Leif.";
        		link.l1.go = "exit";
            }
		break;

 		case "Exit":
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Step_8":
        	dialog.text = "Voici ce qui se passe maintenant : toi et moi, nous parlons\n"+
                          "Et le grand événement que j'attendais depuis six siècles s'est déjà produit : je me suis éveillé de mon sommeil.";
    		link.l1 = "(à part) Que le diable m'emporte ! (à voix haute) Et on dirait que c'est moi qui t'ai réveillé...";
    		link.l1.go = "Step_9";
		break;

        case "Step_9":
        	dialog.text = "Quel est ton nom, et qui es-tu ? Réponds-moi, et tu vivras.";
    		link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je suis corsaire.";
    		link.l1.go = "Step_10";
    		link.l2 = "Le ton n'est-il pas un peu haut pour un crâne galeux ?";
    		link.l2.go = "ToDeath";
		break;

        case "ToDeath":
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
    		LAi_SetPlayerType(pchar);
		    LAi_LocationFightDisable(&Locations[FindLocation("Guadeloupe_Cave")], false);
			LAi_SetFightMode(pchar, true);
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Step_10":
        	dialog.text = "Que veut dire « capre » ?";
    		link.l1 = "Un capre, c'est un corsaire... Un flibustier, un pirate...";
    		link.l1.go = "Step_11";
		break;

        case "Step_11":
        	dialog.text = "Qu'est-ce qu'un « flibustier », un « pirate » ?";
    		link.l1 = "Eh bien, comment te l'expliquer... Je suis "+ GetSexPhrase("un marin libre et un guerrier libre", "une femme marin, libre comme l'oiseau") +". J'ai mon propre navire, et je fais ce que je crois juste.";
    		link.l1.go = "Step_12";
		break;

        case "Step_12":
        	dialog.text = "Ha ha ! Oui, toi et moi, nous sommes "+ GetSexPhrase("frères de sang", "du même sang") +" ! Je suis heureux que mon plan ait été réalisé par une âme sœur. C'est un signe de grande chance pour moi...";
    		link.l1 = "Quel plan ?";
    		link.l1.go = "Step_13";
		break;

        case "Step_13":
        	dialog.text = "Quel plan ? Ha ha ha... Tu es là, à parler avec moi, avec un homme mort depuis plus de six siècles !"+
                          "Voilà mon plan. Mon message à mes descendants a donc été trouvé...";
    		link.l1 = "Quoi... Qui es-tu ?";
    		link.l1.go = "Step_14";
		break;

        case "Step_14":
        	dialog.text = "Je m'appelle Leif Eriksson. Comme toi, je suis marin et guerrier, mon propre maître\n"+
                          "Seulement, moi, j'ai navigué sur les mers au nord d'ici.";
    		link.l1 = "En venant ici, j'ai entendu dire que Leif l'Heureux était enterré ici. C'est toi ?";
    		link.l1.go = "Step_15";
		break;

        case "Step_15":
        	dialog.text = "Oui. Je suis Leif l'Heureux, fils d'Erik le Rouge, descendant des anciens Suiones, Viking et jórsalafari.";
    		link.l1 = "Alors tu es un Viking, de ce peuple barbare qui a ravagé l'Europe il y a six cents ans ?";
    		link.l1.go = "Step_16";
		break;

        case "Step_16":
        	dialog.text = "Viking n'est pas un peuple, corsaire. Viking, c'est un mode de vie, un métier de marin et de guerrier\n"+
                          "Et toi, "+ GetSexPhrase("guerrier libre", "marin libre") +", tu nous traites de barbares ? Il y a six cents ans, nous étions les meilleurs guerriers et les meilleurs marins de la terre. Je suis allé à Jórsalir et j'ai pris part à la campagne contre Rome, et mon frère possédait la Gardariki !";
    		link.l1 = "Mais comment es-tu arrivé en Amérique ? Christophe Colomb a découvert l'Amérique il y a cent cinquante ans !";
    		link.l1.go = "Step_17";
		break;

        case "Step_17":
        	dialog.text = "C'est ainsi que tu appelles ces grandes terres, l'Amérique ? Ha ha ha. וcoute-moi bien, "+ GetSexPhrase("corsaire libre", "guerrière") +"\n"+
                          "א l'été 986 de notre ère, le Viking norvégien Bjarni Herjólfsson, qui se rendait au Groenland, a été dérouté vers une terre nouvelle et inconnue, mais il n'y a pas accosté\n"+
                          "En l'an 1000, moi, Leif Eriksson, je suis parti à la recherche de cette terre. J'ai trouvé l'île du Helluland (la terre de Baffin), puis le Markland (le Labrador) et le Vinland (Terre-Neuve). J'ai fondé un établissement au Vinland\n"+
                          "Deux ans plus tard, je suis allé plus loin et j'ai trouvé cette grande terre. J'y ai accosté beaucoup plus au nord.";
    		link.l1 = "Ce n'est pas possible ! Alors c'est ainsi que l'Amérique a été découverte, il y a six siècles...";
    		link.l1.go = "Step_18";
		break;

        case "Step_18":
        	dialog.text = "J'ai découvert cette terre en 1002\n"+
                          "Puis je me suis enfoncé à l'intérieur et j'ai vu que cette terre était sans fin et habitée par des hommes à la peau rouge.";
    		link.l1 = "Les Indiens...";
    		link.l1.go = "Step_19";
		break;

        case "Step_19":
        	dialog.text = "Non, chaque tribu se nomme autrement\n"+
                          "Pendant vingt ans, j'ai vécu dans la tribu des Toltèques, qui me vénéraient, moi, un homme blanc, comme une divinité. Vingt ans plus tard, je suis retourné à l'établissement que j'avais fondé au Vinland et j'y ai laissé un testament à mes descendants\n"+
                          "Six cents ans plus tard, il a été exécuté. Exécuté par toi.";
    		link.l1 = "Formidable ! Bon, salut ?..";
    		link.l1.go = "Step_20";
		break;

        case "Step_20":
        	dialog.text = "Ne te presse pas, je vais d'abord te faire un cadeau inestimable pour ma libération.";
    		link.l1 = "Oh, j'adore ce genre d'affaires. Et quel est ce cadeau ?";
    		link.l1.go = "Step_21";
		break;

        case "Step_21":
        	dialog.text = "Ta vie. Je te la donne en remerciement.";
    		link.l1 = "Formidable... Bon, salut ?..";
    		link.l1.go = "Step_22";
		break;

        case "Step_22":
        	dialog.text = "Ne te presse pas. Pour mon cadeau, tu vas faire quelque chose pour moi.";
    		link.l1 = "Hum, et que dois-je faire ?";
    		link.l1.go = "Step_23";
    		link.l2 = "Au diable, espèce de singe pourri ! Tu ferais mieux de goמter à l'acier...";
    		link.l2.go = "ToDeath";
		break;

        case "Step_23":
        	dialog.text = "Je sens qu'il y a une grande ville tout près. Là-bas, chez le personnage le plus important de la ville, se trouvent les choses dont j'ai besoin, je sens leur présence\n"+
                          "Tu dois m'apporter trois crânes de cristal toltèques, un blanc, un rose et un bleu, ainsi qu'un objet ancien qu'on appelle la chose étrange. Alors je deviendrai plus fort et je pourrai reconstituer mon corps. Le monde attend son maître...";
    		link.l1 = "(à part) Je veux seulement sortir de cette crypte, et je ne vais rien traîner jusqu'ici, qu'il cherche un imbécile... (à voix haute) D'accord, je peux partir ?";
    		link.l1.go = "Step_24";
		break;

        case "Step_24":
        	dialog.text = "En gros, oui. Juste encore une petite chose, pour que tu reviennes vite\n"+
                          "Je te prends ton corps pour un temps, et je te donne le mien. Pour un temps aussi.";
    		link.l1 = "Quoi ?!!!";
    		link.l1.go = "Body_Change";
		break;

        case "Body_Change":
			if (findsubstr(pchar.model.animation, "mushketer" , 0) != -1) SetMainCharacterToMushketer("", false);
			LAi_SetPlayerType(pchar);
            bDisableCharacterMenu = true; //закрываем Ф2
            // ==> меняем модели
            Pchar.questTemp.Ascold.heroFaceId    = pchar.FaceId;
            Pchar.questTemp.Ascold.heroAnimation = pchar.model.animation;
			Pchar.questTemp.Ascold.reputation    = pchar.reputation;
			Pchar.questTemp.Ascold.nation		 = pchar.nation;
			Pchar.questTemp.Ascold.relation      = GetNationRelation2MainCharacter(FRANCE);
			if (CheckAttribute(pchar, "heromodel")) {Pchar.questTemp.Ascold.heromodel = pchar.heromodel; DeleteAttribute(pchar, "heromodel");}
			SetNationRelation2MainCharacter(FRANCE, RELATION_ENEMY);
            npchar.model = pchar.model;
			npchar.model.animation = pchar.model.animation;
            // FaceMaker(npchar);
			npchar.FaceId = Pchar.questTemp.Ascold.heroFaceId;
			DeleteAttribute(npchar, "heromodel");
            SetNewModelToChar(npchar);
            pchar.model = "Mummy";
            pchar.model.animation = "man";
            pchar.FaceId = 207; //мумия
            //FaceMaker(pchar);
            SetNewModelToChar(pchar);
            pchar.questTemp.Ascold = "Ascold_BodyChange";
    		LAi_SetCitizenType(npchar);

            //==> убираем офицеров
			StoreOfficers_Ascold(pchar);  // запомним офицеров во временном хранилище
            for (i=1; i<=MAX_NUM_FIGHTERS; i++)
            {
                string officers = "Fellows.Passengers.Officers."+"id"+i;
                if(CheckAttribute(pchar, officers))
                {
                     RemoveOfficersIndex(pchar, sti(pchar.(officers)));
                }
            }

            //<== убираем офицеров
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Step_25":
        	dialog.text = "Et alors ?";
    		link.l1 = "Et le fait que la ville sur l'île soit française, et non toltèque, aztèque ou peuplée d'autres bêtes à peau rouge ? Je ne peux pas me promener dans une ville française comme ça !";
    		link.l1.go = "Step_26";
		break;

        case "Step_26":
        	dialog.text = "Inutile de te promener, il faut prendre la ville. Et je te donnerai mes serviteurs pour t'aider, ils suffiront pour prendre la ville.";
    		link.l1 = "...";
    		link.l1.go = "exit";
            for (i=1; i<=6; i++)
            {
				sld = GetCharacter(NPC_GenerateCharacter("MySkel"+i, "Skel"+(rand(3)+1), "skeleton", "skeleton", 30, PIRATE, 0, true));
				FantomMakeCoolFighter(sld, 20, 70, 70, "topor2", "pistol3", 50);
				ChangeCharacterAddressGroup(sld, pchar.location, "goto",  "goto"+(rand(2)+1));
				LAi_SetActorType(sld);
				LAi_ActorFollowEverywhere(sld, "", -1);
            }
            pchar.questTemp.Ascold = "Ascold_SkelSlave";
		break;

        case "Step_27":
        	dialog.text = "Ne t'inquiète pas, je te le rendrai entier. Je n'ai pas besoin de ton corps, il ne me plaît pas\n"+
                          "C'est tout, tu peux partir.";
    		link.l1 = "D'accord, je t'apporterai tout ça. En attendant, sois très prudent.";
    		link.l1.go = "Step_28";
		break;

        case "Step_28":
            PChar.GenQuest.CrewSkelModeClassic = true; //команда - скелеты
  		    chrDisableReloadToLocation = false; // открыть выход из локации.
            pchar.questTemp.Ascold = "Ascold_ImMummy";
            //==> потом вернуть
            Pchar.location.from_sea.save = Pchar.location.from_sea;
            Pchar.location.from_sea = "none";
            Pchar.Ship.Crew.Quantity.save = Pchar.Ship.Crew.Quantity;
            Pchar.Ship.Crew.Quantity = 1000;
            Pchar.GenQuest.HunterScore2Pause = 1; //НЗГ не начисляются
			Pchar.GenQuest.ReputationNotChange = 1; //репутацию не менять
			Pchar.NationAgressivePatentDisable = true; //патент не отбирать
            ChangeCharacterAddress(characterFromID("Ascold"), "None", "");
            //<== потом вернуть
            Pchar.quest.Ascold_MummyFightTown.win_condition.l1 = "location";
            Pchar.quest.Ascold_MummyFightTown.win_condition.l1.location = "BasTer_ExitTown";
            Pchar.quest.Ascold_MummyFightTown.win_condition = "Ascold_MummyFightTown";

            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Step_29":
            DeleteAttribute(PChar, "GenQuest.CrewSkelModeClassic"); // команда-скелеты в нормальное сост.
            bDisableCharacterMenu = false; //открываем Ф2
            bDisableLandEncounters = false;
            TakeItemFromCharacter(pchar, "sculMa1");
            TakeItemFromCharacter(pchar, "sculMa2");
            TakeItemFromCharacter(pchar, "sculMa3");
            TakeItemFromCharacter(pchar, "indian22");
            //==> вертаем
            Pchar.location.from_sea = Pchar.location.from_sea.save;
            DeleteAttribute(PChar, "location.from_sea.save");
            Pchar.Ship.Crew.Quantity = Pchar.Ship.Crew.Quantity.save;
            DeleteAttribute(PChar, "Ship.Crew.Quantity.save");

            ChangeCharacterAddressGroup(&characters[GetCharacterIndex("Ascold")], "BasTer_houseSp1", "goto", "goto1");
           	LAi_SetStayTypeNoGroup(characterFromID("Ascold"));
           	SetLocationCapturedState("BasTer_town", false);
            // ==> возвращаем модели
            pchar.model = npchar.model;
            pchar.model.animation = Pchar.questTemp.Ascold.heroAnimation;
            pchar.FaceId          = Pchar.questTemp.Ascold.heroFaceId;
			pchar.reputation	  = Pchar.questTemp.Ascold.reputation;
			pchar.nation		  = Pchar.questTemp.Ascold.nation;
			SetNationRelation2MainCharacter(FRANCE, sti(Pchar.questTemp.Ascold.relation));
			if (CheckAttribute(Pchar, "questTemp.Ascold.heromodel")) pchar.heromodel = Pchar.questTemp.Ascold.heromodel;
            //FaceMaker(pchar);
            SetNewModelToChar(pchar);
            npchar.model = "Mummy";
			npchar.model.animation = "man";
            FaceMaker(npchar);
            SetNewModelToChar(npchar);
            DeleteAttribute(PChar, "questTemp.Ascold.heroFaceId");
            DeleteAttribute(PChar, "questTemp.Ascold.heroAnimation");
            DeleteAttribute(PChar, "questTemp.Ascold.reputation");
			DeleteAttribute(PChar, "questTemp.Ascold.relation");
			DeleteAttribute(pchar, "questTemp.Ascold.heromodel");
			DeleteAttribute(PChar, "GenQuest.HunterScore2Pause"); //вертаем начисление нзг
			DeleteAttribute(PChar, "GenQuest.ReputationNotChange"); //вертаем смену репы
			DeleteAttribute(PChar, "NationAgressivePatentDisable"); //вертаем отдачу патента
            chrDisableReloadToLocation = true; // закрыть выход из локации.
            RestoreOfficers_Ascold(pchar); // LEO: вернуть абордажников на слоты после возврата тела (раненых тоже); в AfterAttackMummy станет no-op
            pchar.questTemp.Ascold = "Ascold_BackMyBody";
            NextDiag.TempNode = "First time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

        case "Step_30":
        	dialog.text = "Tu ne récupéreras pas ton corps tant que tu ne l'auras pas trouvé.";
    		link.l1 = "Je vais chercher...";
    		link.l1.go = "exit";
		break;

        case "Step_31":
        	dialog.text = "C'est dans ton intérêt. Je ne vais pas te faire d'autres cadeaux inestimables.";
    		link.l1 = "Je comprends. Bon, porte-toi bien, si je puis dire...";
    		link.l1.go = "exit";
    		chrDisableReloadToLocation = false; // открыть выход из локации.
			bDisableFastReload = false;
    		pchar.questTemp.Ascold = "Ascold_ReturnToAscold";
    		characters[GetCharacterIndex("Ascold")].dialog.currentnode = "AfterAttackMummy";
		break;
	}
}


