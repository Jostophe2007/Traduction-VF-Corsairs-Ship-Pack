// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Je vous écoute, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, j'avais oublié...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";

				if(PChar.Dozor == "10")
                {
                	link.l1 = "Le brave capitaine a engagé le combat avec l'Escadre insaisissable.";
                	link.l1.go = "Dozor_1";
                }

                if(PChar.Dozor == "11")
                {
                	link.l1 = "Je viens au sujet de la Veille...";
                	link.l1.go = "Dozor_7";
                }
            // ==> Проверяем поле состояния квестов.
            if (pchar.questTemp.State == "Inquisition_toCuracao" || pchar.questTemp.State == "Inquisition_afterFrancisco")// квест №2 голл. линейки.
            {
                if (!CheckAttribute(pchar, "questTemp.State.Store"))
                {
                    dialog.text = "Vous n'avez pas l'air d'un simple client. Que vous faut-il ?";
        			link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Vous avez péché, mon ami, gravement péché. C'est la Sainte Inquisition qui m'envoie : on vous offre le pardon du pape, et l'indulgence vous coמtera 50 mille.";
        			link.l1.go = "Step_S2_1";
                }
                else
                {
                    if (CheckPassengerInCharacter(pchar, "JacowDeFonseka"))
                    {
                        dialog.text = "Vous avez réussi ! Je vous suis très reconnaissant ! Voici la somme demandée, 100 mille pour nous deux.";
            			link.l1 = "Eh bien, très bien. Je peux vous féliciter : tout s'est réglé au mieux.";
            			link.l1.go = "Step_S2_7";
                        AddMoneyToCharacter(pchar, 100000);
                        pchar.questTemp.State.Store = "Ok";
                        AddQuestRecord("Spa_Line_2_Inquisition", "14");
                        RemovePassenger(pchar, characterFromId("JacowDeFonseka"));
                    }
                    else
                    {
                        if (pchar.questTemp.State.Store != "Ok")
                        {
                            dialog.text = "Vous avez appris quelque chose sur Yakov ?";
                			link.l1 = "Pas encore, mais je m'en occupe.";
                			link.l1.go = "exit";
                		}
                		else
                		{
                            dialog.text = "Yakov et moi vous sommes reconnaissants. Même si vous êtes venu avec de mauvaises nouvelles, vous nous avez rendu un grand service. Merci.";
                			link.l1 = "Oui, pas de problème.";
                			link.l1.go = "exit";
                		}
                    }
                }
            }
            // <== Проверяем поле состояния квестов.
		break;
//*************************** Квест №2 испанки, задание Инквизиции ***************************
 		case "Step_S2_1":
    		dialog.text = "Même si mes affaires allaient mieux, je serais incapable de payer une telle somme. Je ne trompe pas les gens et je ne m'enrichis pas sur leur dos. Tout mon argent est en circulation en ce moment.";
    		link.l1 = "Vous refusez donc de payer ?";
    		link.l1.go = "Step_S2_2";
 		break;
 		case "Step_S2_2":
    		dialog.text = "Si j'avais cette somme à ma disposition, j'aurais payé.";
    		link.l1 = "Je vois que vous ne saisissez pas tout à fait le fond de l'affaire, mon ami. Même à supposer que j'aie pitié de vous, ce qui pourrait bien me coמter ma carrière, les inquisiteurs ne vous laisseront pas en paix, oם que vous alliez et oם que vous vous cachiez. S'ils vous ont mis sur leur liste noire, vous êtes perdu. Bref, si vous ne payez pas, je devrai vous tuer.";
    		link.l1.go = "Step_S2_3";
 		break;
 		case "Step_S2_3":
    		dialog.text = "Il me semble vous avoir déjà expliqué que je n'ai pas assez d'argent.";
    		link.l1 = "Si vous tenez si peu à votre vie que vous ne l'estimez même pas à 50 mille, pas de problème : je vais vous faire la peau.";
    		link.l1.go = "Step_S2_4";
 		break;
 		case "Step_S2_4":
    		dialog.text = "Permettez-moi une curiosité : suis-je le seul à qui l'on fait un tel honneur, ou y a-t-il d'autres candidats à l'indulgence ?";
    		link.l1 = "Hum, voilà une question pertinente ! Je voulais justement vous demander oם se trouve votre associé, Jacob Lopez de Fonseca !?";
    		link.l1.go = "Step_S2_5";
 		break;
 		case "Step_S2_5":
    		dialog.text = "J'aimerais bien le savoir, moi aussi... Attendez, je crois avoir trouvé une issue acceptable pour nous deux\n"+
                          "Pour l'instant, je n'ai même pas la moitié de cette somme. Mais si vous acceptez de me rendre un service, d'ici là, j'aurai réuni l'argent nécessaire.";
    		link.l1 = "Je suis tout ouïe.";
    		link.l1.go = "Step_S2_6";
 		break;
 		case "Step_S2_6":
    		dialog.text = "Mon associé, Jacob Lopez de Fonseca, est parti pour Panama pour affaires, et il a disparu. C'est un homme honnête et bon. Je m'inquiète pour lui\n"+
                          "Si vous le retrouvez, nos deux familles pourront réunir ensemble la somme demandée.";
    		link.l1 = "Hum, je crois que je vais accepter... préparez 50 mille pour vous et autant pour votre associé. א plus tard.";
    		link.l1.go = "exit";
            AddQuestRecord("Spa_Line_2_Inquisition", "3");
	    AddQuestUserData("Spa_Line_2_Inquisition", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State.Store = 1;
            Pchar.quest.Inquisition_fightForJacow.win_condition.l1 = "location";
            Pchar.quest.Inquisition_fightForJacow.win_condition.l1.location = "Panama_houseSp1";
            Pchar.quest.Inquisition_fightForJacow.win_condition = "Inquisition_fightForJacow";
 		break;
 		case "Step_S2_7":
    		dialog.text = "Oui, en effet. Vous nous avez rendu un grand service en retrouvant Yakov. Merci.";
    		link.l1 = "Oui, pas de problème. Au revoir.";
    		link.l1.go = "exit";
            if (CheckCharacterItem(pchar, "Bible"))
            {
        		link.l2 = "וcoutez, Jacob m'a demandé de me procurer un certain livre, un évangile qui vous est très cher, celui de Judas, je crois...";
        		link.l2.go = "Step_S2_8";
            }
 		break;
 		case "Step_S2_8":
    		dialog.text = "Et alors ?";
    		link.l1 = "Hum, voilà, j'ai réussi. J'ai l'évangile.";
    		link.l1.go = "Step_S2_9";
    		link.l2 = "Oh, rien de spécial... Au revoir.";
    		link.l2.go = "exit";
 		break;
 		case "Step_S2_9":
    		dialog.text = "דa alors !!! וcoutez, je vous en prie, donnez-le-moi. C'est très important pour notre communauté janséniste, vous ne pouvez pas imaginer les épreuves que les jansénistes ont traversées pour posséder cet évangile...";
    		link.l1 = "Eh bien, si, je l'imagine très bien. Prenez-le.";
    		link.l1.go = "Step_S2_10";
 		break;
 		case "Step_S2_10":
    		dialog.text = "Ô Seigneur tout-puissant, c'est LUI, l'וvangile de Judas Iscariote !!!"+
                          "וcoutez, vous devez savoir que la récompense pour avoir retrouvé cette relique est d'un million...";
    		link.l1 = "Quoi ?!!";
    		link.l1.go = "Step_S2_11";
    		TakeItemFromCharacter(pchar, "Bible");
 		break;
 		case "Step_S2_11":
    		dialog.text = "Oui, oui, un million. Et je suis heureux de vous le remettre !";
    		link.l1 = "Et moi, heureux de le prendre... Je crois que je vais y aller, la tête me tourne...";
    		link.l1.go = "Step_S2_12";
    		AddMoneyToCharacter(pchar, 1000000);
 		break;
 		case "Step_S2_12":
    		dialog.text = "Allez, mon ami. Au revoir, toute notre communauté vous en sera reconnaissante jusqu'à la fin de ses jours ! Ah, j'imagine ce qui va commencer quand tout le monde apprendra que l'artefact disparu de Samuel Kohane a été retrouvé...";
    		link.l1 = "Au revoir, je ne vous dérange pas plus longtemps...";
    		link.l1.go = "exit";
 		break;

		// DOZOR -->
		case "Dozor_1":
			dialog.text = "Ah ! Vous jouez à la Veille ? Et ça vous plaît ?";
			link.l1 = "Tout simplement génial !";
			link.l1.go = "Dozor_2";
			link.l2 = "Ce n'est pas l'extase, bien sמr, mais ça peut être intéressant.";
			link.l2.go = "Dozor_2";
			link.l3 = "Cette Veille, c'est n'importe quoi !";
			link.l3.go = "Dozor_2";
		break;

		case "Dozor_2":
			dialog.text = "Vous savez, un capitaine m'a raconté un jour qu'il avait lui aussi joué à la Veille. D'abord, ils sont allés à Port Royal, en Jamaïque, puis ils ont fait irruption à Hispaniola, dans la ville espagnole de Santo Domingo, ensuite ils sont passés à San Juan, à Porto Rico, après quoi ils ont fait irruption dans l'anglaise Charlestown, sur l'île de Niévès. Après Niévès, ils ont visité la colonie anglaise d'Antigua, puis l'avant-dernière île : la Martinique, au repaire pirate du François. Mais ils n'ont pas su résoudre la dernière énigme, vous imaginez ? Ils sont tombés sur une énigme vraiment inaccessible.";
			link.l1 = "J'aimerais mieux recevoir un Meckachrome que d'écouter de telles histoires.";
			link.l1.go = "Dozor_3";
		break;

		case "Dozor_3":
			dialog.text = "(rit doucement) Eh, capitaine, vous n'avez donc pas deviné ? C'est moi qui remplace le Meckachrome ! Et je viens de vous raconter l'énigme suivante !";
			link.l1 = "L'énigme suivante ? Ces sornettes, c'était donc ma prochaine mission ?";
			link.l1.go = "Dozor_4";
		break;

		case "Dozor_4":
			dialog.text = "Oui. Je vais répéter l'énigme. וcoutez bien. D'abord, ils sont allés à Port Royal, en Jamaïque, puis ils ont fait irruption à Hispaniola, dans la ville espagnole de Santo Domingo, ensuite ils sont passés à San Juan, à Porto Rico, après quoi ils ont fait irruption dans l'anglaise Charlestown, sur l'île de Niévès. Après Niévès, ils ont visité la colonie anglaise d'Antigua, puis l'avant-dernière île : la Martinique, au repaire pirate du François. Mais ils n'ont pas su résoudre la dernière énigme, vous imaginez ? Ils sont tombés sur une énigme vraiment inaccessible.";
			link.l1 = "Et l'indice ? Oם est-il ?";
			link.l1.go = "Dozor_5";
		break;

		case "Dozor_5":
			dialog.text = "Il n'y a pas d'indice ici ! Vous devez simplement deviner oם aller ensuite.";
			link.l1 = "Mais vous pouvez bien me donner un conseil ?";
			link.l1.go = "Dozor_6";
		break;

		case "Dozor_6":
            dialog.text = "Ni conseil, ni indice. « En el interior del itinerario », comme disent les Espagnols ! Bonne chance ! Dès que vous aurez résolu l'énigme, donnez-moi la réponse.";
            link.l1 = "Je suis prêt à répondre tout de suite.";
			link.l1.go = "Dozor_8";
			link.l2 = "J'ai besoin d'un peu de temps pour y réfléchir. Mais je reviendrai répondre, c'est sמr.";
			link.l2.go = "exit";
			PChar.Dozor = "11";
			AddQuestRecord("Dozor", "10");
			TakeNItems(PChar, "Dozor_Mekakhrom", -1);
		break;

		case "Dozor_7":
			dialog.text = "Alors, capitaine, oם en êtes-vous ? Vous avez percé l'énigme ?";
			link.l1 = "Oui, je l'ai percée, et je suis prêt à donner la bonne réponse.";
			link.l1.go = "Dozor_8";
			link.l2 = "Non, pas encore.";
			link.l2.go = "exit";
		break;

		case "Dozor_8":
			dialog.text = "Alors, l'île ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Dozor_9";
		break;

		case "Dozor_9":
			string sString = GetStrSmallRegister(dialogEditStrings[1]);

			if(sString == "maria galante" || sString == "marie-galante" || sString == "marie galante")
			{
				dialog.text = "Et le lieu de destination ?";
				Link.l1.edit = 1;
				Link.l1 = "";
				Link.l1.go = "Dozor_10";
			}
			else
			{
				dialog.text = "Faux, capitaine. Réfléchissez encore.";
				link.l1 = "Argh !";
				link.l1.go = "exit";
			}

		break;

		case "Dozor_10":
			string sExString = GetStrSmallRegister(dialogEditStrings[1]);
			if(sExString == "cape inaccessible" || sExString == "cap inaccessible" || sExString == "le cap inaccessible")
			{
				dialog.text = "C'est exact, capitaine ! La phrase clé : « Le brave capitaine a engagé le combat avec l'Escadre insaisissable ».";
				Link.l1 = "Merci, et au revoir.";
				Link.l1.go = "exit";
				AddDialogExitQuestFunction("DozorToGuadeloupeShore");
			}
			else
			{
				dialog.text = "Non, capitaine, c'est faux. Essayez encore.";
				link.l1 = "Bon sang !";
				link.l1.go = "exit";
			}
		break;
 		// <-- DOZOR

	}
	UnloadSegment(NPChar.FileDialog2);
}

