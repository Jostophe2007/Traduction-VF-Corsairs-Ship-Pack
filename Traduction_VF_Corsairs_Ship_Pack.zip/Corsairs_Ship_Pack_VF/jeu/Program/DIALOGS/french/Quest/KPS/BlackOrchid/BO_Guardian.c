// Gregg: The fort guard and the ghost of Joe Newman - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "...(barre le passage vers l'escalier)... Capitaine, personne ne descend ce soir. C'est sa nuit, et ces nuits-là, on ne descend pas.";
			link.l1 = "C'est justement pour ça que je suis venu. וcartez-vous.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoNewmanToPrison");
		break;

		case "2":
			dialog.text = "...(très doucement)... Depuis bien des années, vous êtes le premier à me battre. Dites-moi votre nom.";
			link.l1 = "Capitaine " + PChar.lastname + ".";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Un beau nom. Pourquoi restez-vous planté là ? Achevez-moi. Le combat était loyal.";
			link.l1 = "Ce n'est pas pour ça que je suis venu. J'ai besoin de votre aide.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "De l'aide. De moi. D'un homme qui n'a pas franchi ce mur depuis cinquante ans.";
			link.l1 = "Raul Esperanto. On l'a amené ici il y a une trentaine d'années.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "...(un long silence)... Raul. Je m'en souviens. Il est resté ici environ sept mois, et je l'ai vu deux fois. א sa mine, j'avais jugé qu'il ne passerait pas l'hiver.";
			link.l1 = "Il est mort ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Il s'est évadé. De cette prison, d'oם personne ne s'est évadé depuis cinquante ans.";
			link.l1 = "Alors il est peut-être en vie.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Il est en vie. דa, je le sais. Si je vous dis oם le chercher, cela dépendra de la raison pour laquelle vous le voulez.";
			link.l1 = "Comment sauriez-vous oם il est ? Vous ne sortez jamais.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Les prisonniers sortent. Et reviennent. Et parlent. Alors, pourquoi le voulez-vous ? La vérité. J'entendrai la différence.";
			link.l1 = "Il y a des années, il a fabriqué une chose qui tue. Je veux l'arrêter, et je ne le peux pas sans lui.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "La vérité. Très bien. Alors écoutez.";
			link.l1 = "Attendez. Avant de vous écouter : combien de gardes avez-vous tués ?";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "...(sans se vexer)... Vous voulez savoir si je suis un monstre.";
			link.l1 = "Oui.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "La première fois que je suis apparu ici, ils sont venus sur moi avec des sabres et des mousquets. J'ai essayé de leur expliquer que je ne touche personne. Ils n'ont pas écouté. Depuis, chaque homme qui descend le jour qui est le mien descend pour m'achever. Une fois par an, le commandant en engage un nouveau.";
			link.l1 = "Et vous m'avez pris pour un autre.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Que pouvais-je voir d'autre en vous ?";
			link.l1 = "Et les prisonniers ? Le commandant dit que vous leur faites peur.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Le commandant dit beaucoup de choses. Les prisonniers sont les seuls à me parler. C'est par eux que j'ai entendu parler d'Esperanto. Il est à Cuba.";
			link.l1 = "א Cuba. Vous en êtes sמr ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "C'est ce qu'a dit l'un d'eux, il y a une dizaine d'années. C'est toute l'aide que je peux vous apporter.";
			link.l1 = "דa suffit. Merci.";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Puisque nous y sommes, demandez-moi quelque chose en retour. C'est plus juste ainsi.";
			link.l1 = "Alors je vais le faire. Que voulez-vous ?";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Expliquez au commandant ce que je suis. Racontez-lui ce que je vous ai dit.";
			link.l1 = "Je le ferai.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "...(après un silence)... Non. N'en faites rien.";
			link.l1 = "Pourquoi pas ?";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Parce qu'il ne vous croira pas, et qu'il se souviendra de vous. Mon nom ne se répare plus. Le vכtre n'a pas à en être sali.";
			link.l1 = "J'essaierai quand même.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "N'essayez pas. Ce sera là votre aide. Allez, capitaine.";
			link.l1 = "Adieu, Joe.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoNewmanExit");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
