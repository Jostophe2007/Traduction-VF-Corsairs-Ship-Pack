#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Salutations, "+ GetSexPhrase("nouveau citoyen", "nouvelle citoyenne") +" de la Cité ! Nous sommes très heureux de vous voir. Pardonnez-moi, j'ai oublié de me présenter. Je m'appelle " + GetFullName(npchar) + ", je vis ici.";
					link.l1 = "Je l'avais remarqué. Eh bien, moi, c'est " + GetFullName(pchar) + ". Dis-moi, vous vivez dans des tempêtes continuelles, ici ?";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Salutations, "+ GetSexPhrase("nouveau citoyen", "nouvelle citoyenne") +" de la Cité ! Nous sommes très heureux de vous voir. Pardonnez-moi, j'ai oublié de me présenter. Je m'appelle " + GetFullName(npchar) + ", je vis ici.";
					link.l1 = "Je l'avais remarqué.. Eh bien, moi, c'est" + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Tu voulais quelque chose ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//поиск товаров на корвет
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoutez, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de quitter ces lieux avec moi pour le continent.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "Non, non, tout sera réglé d'ici demain soir. Au fait, si tu n'as pas encore rendu visite à l'amiral, je te conseille de te dépêcher. Il se trouve sur le navire « San Augustine ». Tu dois le voir avant la fin de la tempête.";
			link.l1 = "D'accord, compris.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Si tu n'as pas encore rendu visite à l'amiral, je te conseille de te dépêcher. Il se trouve sur le navire « San Augustine ».";
			link.l1 = "D'accord, compris.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, vous vous prenez pour d'Artagnan, à courir partout en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes", "des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Je vais essayer de redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Dis-moi, tu sais pourquoi tant de navires sont rassemblés ici ? C'est un cas extraordinaire ! Et pourquoi ne coulent-ils pas ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Quel genre d'homme est l'amiral ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "Qu'est-ce que vous avez d'intéressant ici ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l5") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l5 = "Depuis combien de temps êtes-vous ici ?";
				link.l5.go = "ansewer_5";
			}
			link.l10 = "Pas de questions. Désolé, l'ami...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +". Si vous êtes arrivé ici, oubliez tout ce que vous avez vécu avant. On ne peut pas partir d'ici, malheureusement...";
			link.l1 = "Diable !!";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_2":
			dialog.text = "Personne ne le sait avec certitude. Il semble y avoir une sorte de courant, très fort, qui fait dériver tous les navires jusqu'ici. Et puis les algues...";
			link.l1 = "Des algues ? Hum... Il y a peut-être une sorte de haut-fond sous nous, des récifs ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "Je n'en sais rien, et je ne te conseille pas de chercher à le savoir. On peut nager en surface sans crainte, mais si on plonge... Bref, on n'a plus jamais revu ceux qui ont essayé.";
			link.l1 = "Et les noyés ne sont même pas remontés ensuite ?";
			link.l1.go = "ansewer_2_2";
		break;
		case "ansewer_2_2":
			dialog.text = "Non, personne n'a même plus revu un bout de leurs vêtements.";
			link.l1 = "Bon sang, ça donne la chair de poule...";
			link.l1.go = "ansewer_2_3";
		break;
		case "ansewer_2_3":
			dialog.text = "Ce n'est rien, tu t'y habitueras.";
			link.l1 = "Je n'ai pas trop envie de m'y habituer...";
			link.l1.go = "ansewer_2_4";
		break;
		case "ansewer_2_4":
			dialog.text = "Je comprends, mais il le faut. Et si tu n'arrives pas à t'y faire ici, tu deviendras fou. Et alors, tu es légalement mort !";
			link.l1 = "Quoi ?!";
			link.l1.go = "ansewer_2_5";
		break;
		case "ansewer_2_5":
			dialog.text = "Tu iras au fond avec une charge de lest au cou. Voilà !";
			link.l1 = "Oui, vous avez de drכles de règles, quand même...";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "L'amiral, c'est le gouverneur de notre Cité. En fait, autrefois, on élisait l'amiral, mais maintenant, Chad Capper n'y tient pas vraiment, apparemment...";
			link.l1 = "Qu'est-ce qui vous fait dire ça ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Oui, parce que l'élection de l'amiral est devenue un sujet tabou dans la Cité. On n'en parle pas... Et je ne te le conseille pas non plus.";
			link.l1 = "Hum, je vois.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_4":
			dialog.text = "D'intéressant ? Eh bien, je ne sais pas ce qui t'intéresse... Il y a une taverne, une boutique, une église et la résidence, bien sמr.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_5":
			dialog.text = "דa fait un an et demi, depuis...";
			link.l1 = "Je vois. Hill Brunner tenait déjà la taverne...";
			link.l1.go = "ansewer_5_1";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_5_1":
			dialog.text = "Oui, c'est ça.";
			link.l1 = "Bon, je vois...";
			link.l1.go = "int_quests";
		break;
		//поиск товаров на корвет
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Que cherchez-vous exactement ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Vous m'avez déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Des bombes, des boulets, de la mitraille, des boulets ramés, des vivres, des médicaments, de la poudre, des armes...",
				"Ouais... Désolé, j'ai oublié.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Des armes ? Tu en as déjà une.";
			link.l1 = "J'ai besoin de beaucoup d'armes.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Compris. Bon, alors, c'est chez l'amiral. Il n'y a que lui qui ait de la poudre et des armes.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Ce n'est pas une blague, "+ GetSexPhrase("l'ami", "" + pchar.name + "") +" ?";
			link.l1 ="Pas du tout. J'ai un navire et je t'invite à rejoindre l'équipage.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "Oh, diable ! Pince-moi...";
			link.l1 = "L'ami, je n'ai pas le temps. Il me faut ta réponse.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Merci pour l'invitation ! Bien sמr que j'accepte.";
			link.l1 = "Parfait ! Maintenant, va tout de suite au San Gabriel. Le Mécanicien te fera passer sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "J'y cours. Je prendrai mes affaires en chemin.";
			link.l1 = "Seulement, fais vite. Ne t'attarde nulle part !";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
