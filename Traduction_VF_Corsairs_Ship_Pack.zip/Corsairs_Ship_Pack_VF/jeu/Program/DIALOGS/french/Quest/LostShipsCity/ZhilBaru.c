#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Salutations ! Si je comprends bien, c'est vous "+ GetSexPhrase("l'homme qui a réchappé", "la jeune femme qui a réchappé") +" de la dernière tempête. Permettez-moi de me présenter, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "C'est un plaisir. Eh bien, moi, c'est " + GetFullName(pchar) + ".";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Salutations ! Si je comprends bien, c'est vous "+ GetSexPhrase("l'homme qui a réchappé", "la jeune femme qui a réchappé") +" du dernier naufrage. Permettez-moi de me présenter, je m'appelle " + GetFullName(npchar) + ".";
					link.l1 = "C'est un plaisir. Eh bien, moi, c'est " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				dialog.text = "Que vouliez-vous, "+ GetSexPhrase("monsieur", "mademoiselle") +" ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				//освобождение мужа Элис Тейлор
				if (CheckAttribute(pchar, "questTemp.LSC.ElisHusband") && pchar.questTemp.LSC.ElisHusband == "toZhilBaru")
				{
					link.l5 = "Je dois vous parler de Maxim Taylor.";
					link.l5.go = "ELTHusb_SF";
				}
				//поиски команды на корвет
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;
		case "FS_1":
			dialog.text = "Alors, comment trouvez-vous notre Cité livrée aux éléments, pour ainsi dire ?";
			link.l1 = "Vous savez, je ne suis pas tout à fait dans mon assiette en ce moment, car j'ai tout perdu, et tout le monde. Alors, pour l'instant, mes impressions sont terribles.";
			link.l1.go = "FS_2";
		break;
		case "FS_2":
			dialog.text = "Bien sמr, c'est compréhensible ! Pardonnez mon manque de tact... Vous savez, la tempête va bientכt passer.";
			link.l1 = "Je sais, merci.";
			link.l1.go = "FT_1";
		break;
		case "FT_1":
			dialog.text = "Vous savez, c'est très bien que notre Cité accueille une personne aussi agréable que vous. Très bien.";
			link.l1 = "Qu'est-ce qui vous fait croire que je suis agréable ?";
			link.l1.go = "FT_2";
		break;
		case "FT_2":
			dialog.text = "Euh... C'est l'impression que j'ai eue.";
			link.l1 = ""+ GetSexPhrase("Quand on a des impressions, on se signe, l'ami. C'est clair ?", "Eh bien, merci du compliment !") +"";
			link.l1.go = "FT_3";
		break;
		case "FT_3":
			dialog.text = ""+ GetSexPhrase("Très clair, très clair !..", "Je vous en prie. Si vous avez des questions, n'hésitez pas.") +"";
			link.l1 = ""+ GetSexPhrase("Bon, voilà qui est bien...", "Bien sמr...") +"";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Mais c'est un voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que vous voilà la tête la première dans le coffre !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("ce voleur !", "cette voleuse !"));
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux journal !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveuse...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, pourquoi courez-vous partout comme d'Artagnan, en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux", "à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami", "ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand"+ GetSexPhrase(" des hommes", " des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;

		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Je vais essayer de redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je vais chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez mieux.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, "+GetAddress_FormToNPC(NPChar)+".", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je vous écoute attentivement, "+ GetSexPhrase("l'ami", "mademoiselle") +".";
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "וcoutez, quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Connaissez-vous les raisons pour lesquelles cette île s'est formée ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l3 = "Dites-moi, depuis combien de temps traînez-vous ici ?";
				link.l3.go = "ansewer_3";
			}
			link.l10 = "Pas de questions. Pardonnez-moi...";
			link.l10.go = "exit";
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés, "+ GetSexPhrase("l'ami", "mademoiselle") +". Ici, tout est un peu différent du continent...";
			link.l1 = "Et qu'entendez-vous par là ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Ici, c'est une autre vie, avec sa propre Loi ! En principe, les règles sont plutכt bonnes et assez justes. Alors je suppose que vous vous plairez ici.";
			link.l1 = "Hum, je l'espère.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "Non, et personne ne le sait. On parle d'un courant puissant, puis d'algues, puis de récifs de corail, mais personne n'en sait rien avec certitude.";
			link.l1 = "Quelqu'un a-t-il essayé de le découvrir ?";
			link.l1.go = "ansewer_2_1";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_2_1":
			dialog.text = "On dit qu'il y a eu des tentatives, mais tout s'est très, très mal terminé...";
			link.l1 = "Hum, je vois.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_3":
			dialog.text = "Traîner ? Bien dit... דa fait environ trois ans que j'use mes fonds de culotte ici.";
			link.l1 = "דa fait longtemps. Vous n'êtes pas fatigué ?";
			link.l1.go = "ansewer_3_1";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_3_1":
			dialog.text = "Peut-être bien que je suis fatigué...";
			link.l1 = "Hill Brunner était-il déjà là quand vous êtes arrivé ?";
			link.l1.go = "ansewer_3_2";
		break;
		case "ansewer_3_2":
			dialog.text = "Il était là, bien sמr. Il connaissait tout le monde dans la Cité. C'est dommage pour Hill, c'était un très brave homme...";
			link.l1 = "J'accepte.";
			link.l1.go = "int_quests";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "Pardon, je n'ai pas compris. Qu'avez-vous dit ?";
			link.l1 ="Je vous propose de quitter la Cité pour le continent, dans l'équipage de mon navire.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = "En voilà une proposition ! Et vous avez vraiment un navire à flot ?";
			link.l1 = "Oui, j'en ai un.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Eh bien, il n'y a pas à réfléchir. Je pars avec vous.";
			link.l1 = "Bien. Maintenant, allez au San Gabriel. Henrik Wedeker vous transférera sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "Je cours juste chercher mes affaires, et je suis à votre disposition.";
			link.l1 = "Parfait !";
			link.l1.go = "SeekCrew_all";
		break;
		//освобождение мужа Элис Тейлор
		case "ELTHusb_SF":
			dialog.text = "Je vous écoute.";
			link.l1 = "J'ai appris que vous aviez quitté la taverne ensemble le jour oם Taylor a été arrêté. Que s'est-il passé ? Comment s'est-il retrouvé à la résidence de l'amiral ?";
			link.l1.go = "ELTHusb_SF_1";
		break;
		case "ELTHusb_SF_1":
			dialog.text = "Pardonnez-moi, mais en quoi cela vous regarde-t-il ?";
			link.l1 = "Le fait est que Maxim Taylor va finir ses jours dans une cage sur le Tartarus. En guise de punition, l'amiral l'a condamné à la perpétuité.";
			link.l1.go = "ELTHusb_SF_2";
		break;
		case "ELTHusb_SF_2":
			dialog.text = "דa alors !..";
			link.l1 = "Exactement. Je me soucie des Taylor, c'est pourquoi je veux savoir ce qui s'est passé.";
			link.l1.go = "ELTHusb_SF_3";
		break;
		case "ELTHusb_SF_3":
			dialog.text = "Bon sang, je ne pensais pas que ça irait jusque-là...";
			link.l1 = "Expliquez-vous.";
			link.l1.go = "ELTHusb_SF_4";
		break;
		case "ELTHusb_SF_4":
			dialog.text = "Oh, comment dire... Bref, je voulais faire une farce à l'amiral. Il nous a eus, avec ses lois...";
			link.l1 = "Et quel rapport avec Taylor ?";
			link.l1.go = "ELTHusb_SF_5";
		break;
		case "ELTHusb_SF_5":
			dialog.text = "Aucun, en fait. C'est juste que ce jour-là, nous buvions un verre à la taverne et nous parlions justement de ça. Eh bien, quand Taylor et moi sommes rentrés, je l'ai emmené au San Augustine et je lui ai proposé de dire son mécontentement à l'amiral en face. C'est ce qu'il a fait.";
			link.l1 = "Oh oh, pas mal... Cependant, je ne dirais pas que c'est très honorable d'un point de vue moral.";
			link.l1.go = "ELTHusb_SF_6";
		break;
		case "ELTHusb_SF_6":
			dialog.text = "Je comprends que je n'ai pas bien agi. C'est pourquoi j'irai voir l'amiral et je lui dirai que nous ne faisions que plaisanter.";
			link.l1 = "Eh bien, parfait. J'irai voir Capper, moi aussi, je tâcherai de faire libérer Taylor au plus vite.";
			link.l1.go = "ELTHusb_SF_7";
		break;
		case "ELTHusb_SF_7":
			dialog.text = "Au revoir. J'espère que l'amiral ne me tuera pas.";
			link.l1 = "דa m'étonnerait.";
			link.l1.go = "exit";
			AddQuestRecord("ISS_ElisHusband", "9");
			pchar.questTemp.LSC.ElisHusband = "toAdmiralGood";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
