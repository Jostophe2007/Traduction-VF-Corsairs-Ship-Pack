# Glossaire FR — Corsairs Ship Pack

Règles générales
- Vouvoiement par défaut entre PNJ et capitaine ; tutoiement seulement pour les registres très familiers (pirates entre eux, « buddy », « mate »).
- Héros masculin par défaut quand l'anglais est neutre ; paires `GetSexPhrase` traduites en paires FR (« monsieur|madame »).
- Journal de quêtes : écrire en évitant l'accord au féminin (pas de `@<sSex>` ; préférer l'auxiliaire *avoir*).
- Typographie : espace avant ? ! : ; — guillemets « » ; pas de « " » dans les dialogues ; « ... » plutôt que « … ».
- Ne jamais toucher aux balises `#xxx#`, `@<xxx>`, `\n`.

Compétences (skills) : Autorité (Leadership) · Escrime / Armes légères, moyennes, lourdes · Armes à feu / Pistolets ·
Fortune · Navigation · Précision · Artillerie (Cannons) · Abordage · Réparation · Défense · Commerce · Discrétion
Caractéristiques PIRATES : Puissance (P) · Intuition (I) · Réflexes (R) · Ascendant (A) · Talent (T) · Endurance (E) · Succès (S)
Talents (perks/abilities) · Points de compétence

Grades navals : Mousse, Matelot, Maître d'équipage, Lieutenant, Capitaine de corvette (3e rang), Capitaine de frégate (2e),
Capitaine de vaisseau (1er), Contre-amiral, Vice-amiral, Amiral, Navarque

Métiers / lieux : taverne, tavernier · magasin, marchand · chantier naval, constructeur naval · usurier · capitainerie,
capitaine de port · gouverneur (général) · commandant · église, prêtre/padre · prison, geôlier · bordel, tenancière ·
entrepôt · contrebandiers · officier, second, maître d'équipage (bosco), navigateur, canonnier, médecin, trésorier, charpentier

Navires : lougre, sloop, cotre, goélette, brick, brigantin, corvette, frégate, galion, flûte, pinasse, chébec, polacre,
tartane, barque, caravelle, caraque, vaisseau de ligne, brûlot, canonnière
Artillerie : canon, couleuvrine, mortier, « canons de 12 livres » ; boulets, mitraille, boulets ramés (knippels), bombes, poudre
Manœuvre : bâbord, tribord, proue, poupe, coque, voiles, gréement, mâts, cale, port en lourd, nœuds, carénage

Marchandises : toile à voile, planches, esclaves, blé, ébène, cacao, sucre, vin, lin, rhum, tabac, café, acajou, cannelle,
coprah, paprika, fruits, bière, soie, vêtements, coton, santal, cuir, huile, vivres, or, argent, soie à voiles, cordages,
bois de gaïac, résine, fer, outils, briques, armes, médicaments

Nations : Angleterre/anglais, France/français, Espagne/espagnol, Hollande/hollandais, pirates ; lettre de marque, corsaire,
flibustier, boucanier
Monnaie : piastres (« gold » = or / pièces d'or selon contexte)
