// Ришард Шамбон - контрабандист
#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;

	bool hungry = true;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);
	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "(Voici le petit de ces monstres démesurés que vous exterminez depuis quelques heures. Ce n'est peut-être que votre imagination, mais en regardant le crabe, vous sentez sa tristesse.)";
				npchar.quest.meeting = "1";
				link.l1 = "Désolé, mon vieux, mais je n'avais pas le choix. C'était ma vie ou la leur.";
				link.l1.go = "crab_meat";

				link.l2 = "דa alors, j'en ai raté un. Crève, sale bête !";
				link.l2.go = "crab_fight";
				//link.l3 = "Нire";
				//link.l3.go = "crab_hire";


				NextDiag.TempNode = "First time";
				break;
			}
			else
			{
				if (!CheckAttribute(npchar, "quest.answer_1"))
				{
					dialog.text = "(Le crabe vous regarde comme s'il attendait quelque chose.)";
					link.l1 = "Tu as faim ?";
					link.l1.go = "crab_meat_1";
					link.l2 = "Désolé, mais j'ai des choses plus importantes à faire en ce moment.";
					link.l2.go = "exit";


				}
				else
				{
					dialog.text = "(Le crabe fait claquer sa pince en guise de salut.)";
					link.l1 = "Bonjour à toi aussi, mon vieux.";
					link.l1.go = "exit";

				}
			}
			NextDiag.TempNode = "First time";
		break;

		case "crab_fight": // первая встреча
            DialogExit();
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
			sld.SaveItemsForDead = true;
		break;

		case "crab_meat":
			dialog.text = "(Le crabe gratte le pont du navire avec une triste compréhension.)";
			link.l1 = "Je ne sais même pas comment te consoler... Bon sang, maintenant, il n'y a plus personne pour s'occuper de toi. Tu as faim ?";
			link.l1.go = "crab_meat_1";

		break;

		case "crab_meat_1":
			dialog.text = "(Le crabe fait claquer sa pince d'un air approbateur, anticipant sa friandise.)";

			if (CheckCharacterItem(pchar, "food1") || CheckCharacterItem(pchar, "food2") || CheckCharacterItem(pchar, "food3") || CheckCharacterItem(pchar, "food4") || CheckCharacterItem(pchar, "food5"))
			{
				link.l1 = "Tiens !";
				link.l1.go = "crab_meat_2";
			}
			link.l2 = "Attends ici, je vais te trouver quelque chose.";
			link.l2.go = "exit";
		break;

		case "crab_meat_2":
			dialog.text = "(Le crabe dévore avidement la nourriture de votre main tendue, puis plonge sans façon dans votre sac et mange toutes les autres provisions.)";
			RemoveItems(PChar, "food1", 100);
			RemoveItems(PChar, "food2", 100);
			RemoveItems(PChar, "food3", 100);
			RemoveItems(PChar, "food4", 100);
			RemoveItems(PChar, "food5", 100);
			npchar.quest.answer_1 = "true";
			link.l1 = "Doucement, mon vieux ! Pas tout d'un coup ! Bon, je dois y aller. Je repasserai peut-être te voir un de ces jours.";
			link.l1.go = "exit";
		break;

		case "crab_hire":
			dialog.text = "(Un crabe énorme s'approche de vous. Instinctivement, votre main cherche votre arme, mais vous vous retenez. Pour une raison ou une autre, il vous semble que cette créature a des intentions amicales.)";
			link.l1 = "C'est toi, le crabe ? Eh bien, tu as grandi ! C'est avec ma nourriture que tu as pris autant de poids ? Ou bien tu es un autre... Il vaut peut-être mieux que je ne le sache pas. Que fais-tu ici ?";
			link.l1.go = "crab_hire_1";
		break;
		case "crab_hire_1":
			dialog.text = "(Le crabe émet une série de cliquetis)";
			link.l1 = "Bon sang. Je ne te comprends pas, mais j'espère que toi, tu me comprends. Tu as l'air intelligent, et pas aussi méchant que tes congénères. Tu ne voudrais pas t'enfuir d'ici avec moi ?";
			link.l1.go = "crab_hire_2";
		break;
		case "crab_hire_2":
			dialog.text = "(La créature émet un son que vous prenez pour un accord)";
			link.l1 = "J'ai une affaire urgente, mais en attendant, rejoins ce navire là-bas, je te retrouverai bientכt.";
			link.l1.go = "exit_hire";
		break;
		case "exit_hire":
			DeleteAttribute(npchar, "city");
			chrDisableReloadToLocation = false;
		/*
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			npchar.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");

			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.dialog.CurrentNode = "First time";
			NPChar.quest.meeting = true;
			*/



			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.loyality = MAX_LOYALITY;

			npchar.Dialog.Filename = "Enc_OfficerCrab.c";
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Npchar.cirassId = Items_FindItemIdx("cirass5");  // предмета нет, но влияение есть
			NextDiag.CurrentNode = NextDiag.TempNode;
			npchar.OfficerWantToGo.DontGo = true;
			npchar.CompanionDisable = true;

			DialogExit();
		break;


// <-- специальные реакции

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetWarriorType(npchar);
			DialogExit();
		break;
	}
}
