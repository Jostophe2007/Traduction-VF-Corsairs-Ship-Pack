// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? Encore des questions étranges...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question... Ce sont des marques d'attention ?",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis..", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "Soukins_toPuertoPrincipe")
			{
				link.l1 = "וcoutez, "+ GetSexPhrase("ma belle", "ma jolie") +", j'ai besoin de savoir ce que Sawkins prépare. J'en ai vraiment besoin...";
				link.l1.go = "PL_Q7_1";
			}
			if (pchar.questTemp.piratesLine == "Soukins_seekRings" && CheckCharacterItem(pchar, "jewelry18") && CheckCharacterItem(pchar, "jewelry7"))
			{
				link.l1 = "Je "+ GetSexPhrase("t'ai apporté", "t'ai apporté") +" ce que tu voulais. Voici tes bagues.";
				link.l1.go = "PL_Q7_3";
			}
		break;
		case "PL_Q7_1":
			dialog.text = "Apportez-moi une bague sertie d'une émeraude et une bague sertie d'un rubis. Et ensuite, je pourrai peut-être vous aider...";
			link.l1 = "Je ne les ai pas...";
			link.l1.go = "PL_Q7_2";
			pchar.questTemp.piratesLine = "Soukins_seekRings";
			if (CheckCharacterItem(pchar, "jewelry18") && CheckCharacterItem(pchar, "jewelry7"))
            {
				link.l2 = "Voici tes bagues, ma chérie...";
				link.l2.go = "PL_Q7_3";
			}
		break;
		case "PL_Q7_2":
			dialog.text = "Désolée, mais c'est ma condition, et elle est catégorique.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
		break;
		case "PL_Q7_3":
			dialog.text = "Mmm, comme elles sont belles !.. Merci. Alors, que vouliez-vous savoir ?";
			link.l1 = "J'ai besoin de savoir ce que Richard Sawkins prépare. Tu es au courant ?";
			link.l1.go = "PL_Q7_4";
			TakeItemFromCharacter(pchar, "jewelry7");
			TakeItemFromCharacter(pchar, "jewelry18");
		break;
		case "PL_Q7_4":
			dialog.text = "Non.";
			link.l1 = "Alors pourquoi diable me fais-tu tourner en bourrique ?!!";
			link.l1.go = "PL_Q7_5";
		break;
		case "PL_Q7_5":
			dialog.text = "Je vous dis que je sais comment le découvrir. Alors, écoutez bien. Richard est un homme méticuleux, il note tout dans son journal. Il faut vous le procurer, voilà tout.";
			link.l1 = "Ha ! Tu peux me dire comment faire ?";
			link.l1.go = "PL_Q7_6";
		break;
		case "PL_Q7_6":
			dialog.text = "Je vais vous le dire. Prenez le journal à sa résidence. Il y reste tout le temps pendant la journée, vous n'en sortirez donc pas vivant si vous osez prendre le journal. Mais la nuit...";
			link.l1 = "Mais la nuit, tout est fermé !";
			link.l1.go = "PL_Q7_7";
		break;
		case "PL_Q7_7":
			dialog.text = "Grimpez par la fenêtre à l'arrière de la maison. Seulement, il vous faudra une échelle pour y monter.";
			link.l1 = "Et oם puis-je m'en procurer une ?";
			link.l1.go = "PL_Q7_8";
		break;
		case "PL_Q7_8":
			dialog.text = "Je ne sais pas...";
			link.l1 = "Hum, eh bien, merci quand même.";
			link.l1.go = "exit";
			pchar.questTemp.piratesLine = "Soukins_toWindow";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

