
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag, arRld, arDis;
	int i, Qty;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//--------------------------------- служанка в резиденции ---------------------------------
		case "ResWoman":
			NextDiag.TempNode = "ResWoman";
			if (isBadReputation(pchar, 40))
			{
				dialog.text = LinkRandPhrase("Vous feriez mieux de sortir d'ici, " + GetAddress_Form(NPChar) + ". Il n'y a rien à faire pour "+ GetSexPhrase("un type comme vous", "une effrontée comme vous") +" dans la maison du gouverneur...", "Va-t'en, "+ GetSexPhrase("voleur", "voleuse") +" ! Comment as-tu fait pour entrer ici ?", "Eh bien, on en est arrivé là. Toutes sortes d'abominations rכdent dans la maison du gouverneur de " + XI_ConvertString("Colony" + npchar.city + "Gen") + " !");
				link.l1 = RandPhraseSimple("Du calme, imbécile...", "Surveille ton langage...");
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Bonjour. Je suis au service du gouverneur. Je m'appelle " + GetFullName(NPChar) + ".", "Je fais le ménage dans cette pièce, " + GetAddress_Form(NPChar) + ".", "Vous savez, " + GetAddress_Form(NPChar) + ", notre gouverneur est un brave homme, et il paie bien ses domestiques...");
				link.l1 = RandPhraseSimple("Très bien.", "Hum, très bien...");
				link.l1.go = "exit";
			}
		break;
		case "Woman_FackYou":
			dialog.text = "Oh, mais qu'est-ce qu'il fait ?! Et moi, pauvre imbécile, je me promène sans rien remarquer... א la garde !!!";
			link.l1 = "Tais-toi, idiote...";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
		break;
		//--------------------------------- слуга в резиденции ---------------------------------
		case "ResMan":
			NextDiag.TempNode = "ResMan";
			if (isBadReputation(pchar, 40))
			{
				dialog.text = LinkRandPhrase(""+ GetSexPhrase("Fiche le camp d'ici, canaille", "Fiche le camp d'ici, canaille") +" !", "Sortez immédiatement de la maison du gouverneur, "+ GetSexPhrase("gredin", "gredine") +" !", "Je me fiche de ce qui t'amène dans la maison du gouverneur de " + XI_ConvertString("Colony" + npchar.city + "Gen") + ". Mais je vais te donner un conseil : fiche le camp d'ici !");
				link.l1 = RandPhraseSimple("Du calme...", "Fais attention, ne t'étrangle pas avec tes mots !");
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Bonjour. Je suis domestique chez le gouverneur. Je m'appelle " + GetFullName(NPChar) + ".", "Je veille à l'ordre ici, " + GetAddress_Form(NPChar) + ".", "Vous savez, " + GetAddress_Form(NPChar) + ", notre gouverneur est un brave homme, et il paie bien ses domestiques...");
				link.l1 = RandPhraseSimple("Très bien.", "Hum, très bien...");
				link.l1.go = "exit";
			}
		break;
		case "Man_FackYou":
			dialog.text = "Quoi, tu as osé "+ GetSexPhrase("", "") +"vouloir voler le gouverneur ?! Gardes, arrêtez "+ GetSexPhrase("le voleur", "la voleuse") +" !!";
			link.l1 = "Ferme ta bouche...";
			link.l1.go = "fight";
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
		break;
		//--------------------------------- солдат в резиденции ---------------------------------
		case "ResGuard":
			NextDiag.TempNode = "ResGuard";
			if (isBadReputation(pchar, 40))
			{
				dialog.text = LinkRandPhrase(""+ GetSexPhrase("Tu ferais mieux de t'en aller d'ici, l'ami", "Tu ferais mieux de t'en aller d'ici, ma belle") +"...", "Fichez le camp d'ici !", "Dis donc, ce ne serait pas la mauvaise porte"+ GetSexPhrase("", "") +" ? C'est la maison du gouverneur de " + XI_ConvertString("Colony" + npchar.city + "Gen") + ". Tu ferais mieux de partir !");
				link.l1 = RandPhraseSimple("Je partirai quand je le voudrai !", "Occupe-toi de tes affaires...");
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = LinkRandPhrase("Aujourd'hui, on m'a affecté au bureau du gouverneur. Pas un mauvais poste...", "Je garde la maison du gouverneur, " + GetAddress_Form(NPChar) + ".", "Ma tâche est de garder la maison du gouverneur.");
				link.l1 = RandPhraseSimple("Parfait.", "Hum, je vois...");
				link.l1.go = "exit";
			}
		break;
	}
}
