# -*- coding: utf-8 -*-
"""Fill a batch from base-key translations (for keys declined with Russian case suffixes).

usage: python fill.py <mapping.txt> <out.fr.txt>
mapping.txt lines:  BaseKey<TAB>French          (same text for every case variant)
                    BaseKey<TAB>Title|lower      (Title for the base key / capitalised english, lower otherwise)
                    =<id><TAB>French             (explicit translation for one batch id)
Batch units whose key is BaseKey or BaseKey+(Gen|Dat|Acc|Abl|Voc|s) are filled; others are reported.
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr  # noqa: E402

SUF = re.compile(r'^(.*?)(Gen|Dat|Acc|Abl|Voc)?(#\d+)?$')


def main(mp_path, out_path):
    mp = json.load(open(os.path.join(fr.WORK, 'batch_map.json'), encoding='utf-8'))
    base, explicit = {}, {}
    for line in open(mp_path, encoding='utf-8').read().split('\n'):
        line = line.rstrip('\r')
        if not line.strip() or '\t' not in line:
            continue
        k, v = line.split('\t', 1)
        if k.startswith('='):
            explicit[k[1:].strip()] = v
        else:
            base[k.strip()] = v
    cache = {}
    out, missing = [], []
    for bid in sorted((b for b in mp if b.isdigit()), key=int):
        dom, f, key = mp[bid]
        if bid in explicit:
            out.append('%s\t%s' % (bid, explicit[bid]))
            continue
        m = SUF.match(key)
        b, suf = m.group(1), m.group(2)
        cand = [key.split('#')[0], b]
        tr = None
        for c in cand:
            if c in base:
                tr = base[c]
                break
        if tr is None:
            missing.append(bid)
            continue
        if '|' in tr:
            title, low = tr.split('|', 1)
            if f not in cache:
                cache[f] = dict(fr.text_units(f))
            en = cache[f].get(key, '')
            use_title = (suf is None) or (en[:1].isupper() and not en[:1].isdigit())
            tr = title if use_title else low
        out.append('%s\t%s' % (bid, tr))
    open(out_path, 'w', encoding='utf-8').write('\n'.join(out) + '\n')
    print('rempli: %d, manquants: %s' % (len(out), ' '.join(missing) if missing else 'aucun'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
