// это всякая мелочь по изабелле: кэп брига, брат, офицер при аресте и пр.
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
            NextDiag.TempNode = "First time";
			dialog.text = "Buenos días, señor ! Vous ne seriez pas le capitaine de ce navire qui est en rade ?";
			link.l1 = "Vous êtes le capitaine des Cinq Plaies du Christ ?";
			link.l1.go = "ShipToDomingoTavenr_2";
			link.l2 = "Non, ce n'est pas moi.";
			link.l2.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "ShipToDomingoTavenr_2":
			dialog.text = "C'est bien moi, señor. Maudite tempête ! Mon brick ne reprendra pas la mer de sitכt. Caramba ! Et moi, comme un fait exprès, j'ai pris un passager. Ce qu'il peut jurer, Mère de Dieu !"+
				          "Il promet de m'écorcher vif, mais je ne vais pas boucher toutes les fissures de la coque avec mon derrière. Il doit absolument aller à San Juan, et pas un seul navire ne va là-bas. Le seigneur est noble, très noble, je serais heureux de le servir, mais je ne peux pas !";
			link.l1 = "Votre passager ne serait pas, par hasard, don Miguel de Valdez ? Je pourrais l'emmener à San Juan.";
			link.l1.go = "ShipToDomingoTavenr_3";
		break;

		case "ShipToDomingoTavenr_3":
            NextDiag.TempNode = "ShipToDomingoTavenr_Temp";
			dialog.text = "Si, señor ! Exactement ! Don Miguel de Valdez ! Oh, señor, que Dieu vous bénisse !";
			link.l1 = "Eh bien, faites-lui plaisir et envoyez-le sur mon navire. Je l'attendrai au port.";
			link.l1.go = "exit";
			Pchar.quest.Romantic_Brother.win_condition.l1           = "location";
        	Pchar.quest.Romantic_Brother.win_condition.l1.location  = "Cumana_town";
        	Pchar.quest.Romantic_Brother.win_condition              = "Romantic_Brother";
        	Pchar.GenQuest.Hunter2Pause = true; // ОЗГи на паузу.
        	AddQuestRecord("Romantic_Line", "6");
			npchar.LifeDay = 2;
            SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
		break;

		case "ShipToDomingoTavenr_Temp":
            NextDiag.TempNode = "ShipToDomingoTavenr_Temp";
            dialog.text = "Oh, señor, que Dieu vous bénisse !";
			link.l1 = "Ce sont des choses qui arrivent. Nous nous arrangerons.";
			link.l1.go = "exit";
		break;
		// братан Изабеллы
		case "Romantic_Brother_1":
            NextDiag.TempNode = "Romantic_Brother_2";
            dialog.text = "Bonjour ! Vous êtes le capitaine " + GetFullName(Pchar)+" ? Je suis don Miguel de Valdez. Je me rends à San Juan.";
			link.l1 = "Bienvenue à bord, don Miguel. Oui, je suis le capitaine " + GetFullName(Pchar)+". J'espère que le voyage vous sera agréable.";
			link.l1.go = "Step_1";
		break;
		case "Step_1":
			AddQuestRecord("Romantic_Line", "7");
			OfficersReaction("good");
			AddCharacterExpToSkill(pchar, "Sailing", 40);
			AddCharacterExpToSkill(pchar, "Leadership", 20);
			AddPassenger(pchar, NPChar, false);
			SetCharacterRemovable(NPChar, false);
            Pchar.quest.Romantic_Brother_port.win_condition.l1           = "location";
        	Pchar.quest.Romantic_Brother_port.win_condition.l1.location  = "SanJuan_town";
        	Pchar.quest.Romantic_Brother_port.win_condition              = "Romantic_Brother_port";
            // немного весёлой жизни
            TraderHunterOnMap();
            LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			chrDisableReloadToLocation = false;
			bDisableFastReload = false;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Romantic_Brother_2":
            NextDiag.TempNode = "Romantic_Brother_2";
            dialog.text = "Merci pour votre aide !";
			link.l1 = "Croyez-moi, ce n'est pas du tout un fardeau pour moi.";
			link.l1.go = "exit";
		break;

		case "Romantic_Brother_port_1":
            NextDiag.TempNode = "Romantic_Brother_2";
            dialog.text = "Merci. Maintenant, allons rendre visite à ma sœur.";
			link.l1 = "Je vous en prie. Bien sמr.";
			link.l1.go = "Step_2";
		break;
		case "Step_2":
			RemovePassenger(pchar, NPChar);
            Pchar.quest.Romantic_Brother_House.win_condition.l1           = "location";
        	Pchar.quest.Romantic_Brother_House.win_condition.l1.location  = "SanJuan_houseSp6";
        	Pchar.quest.Romantic_Brother_House.win_condition              = "Romantic_Brother_House";
            chrDisableReloadToLocation = false;
			LAi_SetActorType(npchar);
            LAi_ActorRunToLocation(npchar, "reload", "houseSp6", "", "goto", "goto4", "", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Romantic_Brother_Thanks":
            NextDiag.TempNode = "Romantic_Brother_Thanks";
            dialog.text = "Capitaine, merci beaucoup pour le service rendu. C'est formidable que vous vous soyez trouvé à Cumaná. On ne peut pas compter sur l'aide de Salvator...";
			link.l1 = "Ce n'est rien, Miguel. Tout va bien. L'essentiel, c'est que votre sœur soit heureuse...";
			link.l1.go = "Step_3";
		break;
		case "Step_3":
            dialog.text = "Nous vous attendons ce soir, capitaine.";
			link.l1 = "J'y serai sans faute, Miguel.";
			link.l1.go = "exit";
		break;
		//разборки Сальватора с братом
		case "TalkNearHouse_1":
            dialog.text = "Escroc ! C'est toi qui as volé l'argent de ma sœur avec de fausses lettres de change ! Voleur et assassin !";
			link.l1 = "Oui, c'est moi ! J'avais diablement besoin de cet argent ! Et toi, tiens ta langue, blanc-bec, ou je te la coupe en vitesse ! Et à ta sœur aussi...";
			link.l1.go = "TalkNearHouse_2";
		break;
		case "TalkNearHouse_2":
            dialog.text = "Si on ne te pend pas avant, gredin ! Ici, on ne fait pas de cérémonies avec les gens de ton espèce ! Demain, tu seras derrière les barreaux !";
			link.l1 = "Tu as choisi ton destin, blanc-bec !";
			link.l1.go = "TalkNearHouse_3";
		break;
		case "TalkNearHouse_3":
			DialogExit();
			AddDialogExitQuest("Romantic_DeadBrother_1");
		break;
		//офицер в доме Сальватора при аресте
		case "ArrestInHome_2":
			ref rColony = GetColonyByIndex(FindColony("SanJuan"));
			if (sti(rColony.HeroOwn))
			{
				dialog.text = "Capitaine ?!.. Pardon, on nous a signalé qu'il y avait un assassin ici !";
				link.l1 = "Calmez-vous. L'assassin vient de s'éclipser. Si vous n'aviez pas essayé de me retenir...";
				link.l1.go = "ArrestInHome_5";
			}
			else
			{
				dialog.text = "Capitaine " + GetFullName(pchar) + ", au nom de la loi, vous êtes en état d'arrestation !";
				link.l1 = "Officier, ce gredin de Salvator Olevares est le véritable assassin. Il a ruiné sa femme avec de fausses lettres de change !";
				link.l1.go = "ArrestInHome_3";
			}
		break;
		case "ArrestInHome_3":
			dialog.text = "Vous avez des preuves ? Oם sont ces lettres de change ?";
			if (CheckCharacterItem(pchar, "Order"))
			{
				link.l1 = "Je les ai, officier !";
				link.l1.go = "ArrestInHome_Have";
			}
			else
			{
				link.l1 = "Miguel en a parlé, je l'ai entendu moi-même...";
				link.l1.go = "ArrestInHome_NotHave";
			}
		break;
		case "ArrestInHome_Have":
			dialog.text = "Bon, nous allons tirer ça au clair. Je pense qu'elles seront prises en considération. En attendant, rendez vos armes et suivez-moi !";
			link.l1 = "Me rendre à votre merci ?! Non, je doute fort que tout soit examiné comme il faut.";
			link.l1.go = "ArrestInHome_4";
		break;
		case "ArrestInHome_4":
			dialog.text = "Dans ce cas, capitaine, je serai contraint d'employer la force.";
			link.l1 = "Et dans ce cas, je serai contraint de résister à une arrestation illégale.";
			link.l1.go = "FightInHouse";
		break;

		case "ArrestInHome_NotHave":
			dialog.text = "Capitaine, le commandant entendra votre témoignage. Maintenant, rendez vos armes et suivez-moi !";
			link.l1 = "Caramba, on dirait que mon affaire est mal engagée : je n'ai que ma parole !";
			link.l1.go = "ArrestInHome_4";
		break;
		case "ArrestInHome_4":
			dialog.text = "Le tribunal en décidera... Rendez vos armes immédiatement !";
			link.l1 = "Hum... Non, officier, je préfère m'en aller. Et je vous déconseille d'essayer de m'arrêter...";
			link.l1.go = "FightInHouse";
		break;

		case "FightInHouse":
			DialogExit();
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_LocationFightDisable(&Locations[FindLocation("SanJuan_houseSp6")], false);
			AddQuestRecord("Romantic_Line", "10");
		break;

		case "ArrestInHome_5":
			dialog.text = "Pardonnez-moi, mais je ne pouvais pas savoir que c'était vous. Pardonnez-moi encore...";
			link.l1 = "Allez, je vais essayer de rattraper ce gredin. Bon, vous êtes libre !";
			link.l1.go = "exit";
			AddQuestRecord("Romantic_Line", "31");
		break;
		//засада в доме Сальватора, диалог с наёмным убийцей
		case "AmbushBandit":
			dialog.text = "Tiens, tiens... On dirait que nous avons fini par attendre...";
			link.l1 = "Vous m'attendiez ? Et à qui ai-je l'honneur de parler ?";
			link.l1.go = "AmbushBandit_1";
		break;
		case "AmbushBandit_1":
			dialog.text = "Nous t'attendions, mon cher, toi...";
			link.l1 = "Comme c'est agréable d'être attendu...";
			link.l1.go = "AmbushBandit_fight";
		break;
		case "AmbushBandit_fight":
			LAi_LocationFightDisable(&locations[FindLocation("SanJuan_houseSp6")], false);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			AddQuestRecord("Romantic_Line", "12");
		break;
		//абордаж брига, где Изабеллу типа держат
		case "BrigAbordage":
			dialog.text = "Bon sang ! Pourquoi diable avez-vous attaqué mon navire ?!!";
			link.l1 = "Vous avez deux problèmes, capitaine : vous avez contacté la mauvaise personne et embarqué la mauvaise passagère.";
			link.l1.go = "BrigAbordage_1";
		break;
		case "BrigAbordage_1":
			dialog.text = "Exprimez-vous plus clairement...";
			link.l1 = "Je récupère Isabella Olevares, et vous me dites oם est Salvator. Dans ce cas, vous restez en vie.";
			link.l1.go = "BrigAbordage_2";
		break;
		case "BrigAbordage_2":
			dialog.text = "Sinon ?";
			link.l1 = "Sinon, je vous tue sur-le-champ, gredin !";
			link.l1.go = "BrigAbordage_3";
		break;
		case "BrigAbordage_3":
			dialog.text = "Eh bien, on verra qui tuera qui...";
			link.l1 = "Hum, le combat précédent ne vous a pas suffi ? Eh bien, voyons...";
			link.l1.go = "BrigAbordage_4";
		break;
  		case "BrigAbordage_4":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("Romantic_TaklInCabinBrig");
            pchar.quest.Romantic_BrigDieHard.over = "yes";
			pchar.quest.Romantic_AfterBrigSunk.over = "yes";
            Island_SetReloadEnableGlobal("PortoBello", true);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//засада в Порто Белло
		case "AmbushPotroBello":
			dialog.text = "Enfin, nous vous attendions ! Salutations au capitaine du brick l'Enthousiaste. Oם est la dame ?";
			link.l1 = "Isabella ?";
			link.l1.go = "AmbushPotroBello_1";
		break;
		case "AmbushPotroBello_1":
			dialog.text = "Oui, Isabella.";
			link.l1 = "Sur mon navire.";
			link.l1.go = "AmbushPotroBello_2";
		break;
		case "AmbushPotroBello_2":
			dialog.text = "Alors amenez-la ici... Ou plutכt non, attendez : nous ferions mieux d'aller nous-mêmes sur votre navire et de l'étrangler discrètement. Il ne faut pas qu'elle se promène en ville.";
			link.l1 = "Pourquoi l'amener ici depuis San Juan ?";
			link.l1.go = "AmbushPotroBello_3";
		break;
		case "AmbushPotroBello_3":
			dialog.text = "Ce n'est pas à toi d'en décider, l'ami...";
			link.l1 = "Hum, c'est vrai, c'est l'affaire de Salvator. Et oם est Salvator lui-même ? Il ne veut pas dire adieu à sa femme ?";
			link.l1.go = "AmbushPotroBello_4";
		break;
		case "AmbushPotroBello_4":
			dialog.text = "Il n'est pas là, il est parti pour affaires. Alors nous faisons notre travail, et nous sommes libres.";
			link.l1 = "Compris... Et oם se trouve Salvator ? Comment puis-je le trouver ?";
			link.l1.go = "AmbushPotroBello_5";
		break;
		case "AmbushPotroBello_5":
			dialog.text = "Salvator trouve tout seul ceux dont il a besoin, et Salvator est le seul à savoir oם se trouve Salvator en ce moment... Hé, tu es bien curieux !";
			link.l1 = "C'est vrai, je ne suis pas le capitaine du brick l'Enthousiaste, mais celui qui a envoyé le brick l'Enthousiaste par le fond...";
			link.l1.go = "AmbushPotroBello_6";
		break;
		case "AmbushPotroBello_6":
			dialog.text = "Il fallait être bête à ce point ! דa y est, l'ami, il est temps pour toi de mourir...";
			link.l1 = "Merci, mais je crois que je vais rester encore un peu...";
			link.l1.go = "AmbushPotroBello_7";
		break;
		case "AmbushPotroBello_7":
			LAi_LocationFightDisable(&locations[FindLocation("PortoBello_houseF2")], false);
            LAi_SetWarriorType(npchar);
            LAi_group_MoveCharacter(npchar, "EnemyFight");
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("EnemyFight", "Romantic_TalkPortoBello");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//доставка Изабеллы Росите в Белиз
		case "Rosita":
			dialog.text = "Bienvenue chez moi, señor. Qui êtes-vous ?";
			link.l1 = "Bonjour, señora. Je suis le capitaine " + GetFullName(pchar) + ", mais je suppose que mon nom ne vous dira rien.";
			link.l1.go = "Rosita_1";
		break;
		case "Rosita_1":
			dialog.text = "En effet, je ne le connais pas. Alors, à quoi dois-je l'honneur de vous voir chez moi ?";
			link.l1 = "Señora, j'agis pour le compte de votre cousine, Isabella Olevares.";
			link.l1.go = "Rosita_2";
		break;
		case "Rosita_2":
			dialog.text = "Poursuivez, señor.";
			link.l1 = "La señora Isabella a exprimé le désir de venir chez vous, et j'ai exaucé sa demande avec plaisir.";
			link.l1.go = "Rosita_3";
		break;
		case "Rosita_3":
			dialog.text = "Mon Dieu, capitaine, vous avez vraiment amené Isabella ici, saine et sauve ?!";
			link.l1 = "C'est exact, señora. Elle est sur mon navire et se prépare à débarquer.";
			link.l1.go = "Rosita_4";
		break;
		case "Rosita_4":
			dialog.text = "Ah, señor, je ne sais même pas comment vous remercier ! Une suite de malheurs tragiques s'est abattue sur Isabella : elle a perdu son père et son frère, et son mari a disparu ! Vous ne pouvez pas imaginer...";
			link.l1 = "Si, señora, je sais tout cela. Dites-moi, Salvator Olevares s'est-il montré chez vous ?";
			link.l1.go = "Rosita_5";
		break;
		case "Rosita_5":
			dialog.text = "Non, il n'est pas venu ici, il a disparu sans laisser de traces. Pourquoi me demandez-vous cela, capitaine ?";
			link.l1 = "Je pense qu'il vaut mieux qu'Isabella vous raconte tout elle-même. Je me suis assuré que votre maison était sמre pour Isabella, et je vais vous l'envoyer tout de suite. Prenez soin d'elle, señora, elle a beaucoup souffert ces derniers temps...";
			link.l1.go = "Rosita_6";
		break;
		case "Rosita_6":
			dialog.text = "Merci pour tout ce que vous avez fait pour Isabella, señor " + pchar.name + ". Je prierai pour vous...";
			link.l1 = "D'accord, señora Rosita, je n'y vois pas d'objection : priez.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Rosita_after";
            Pchar.quest.Romantic_BelizCityTalk.win_condition.l1 = "location";
            Pchar.quest.Romantic_BelizCityTalk.win_condition.l1.location = "Beliz_town";
            Pchar.quest.Romantic_BelizCityTalk.win_condition = "Romantic_BelizCityTalk";
			//снимем прерывания на засады на всякий случай
			pchar.quest.Romantic_AmbushInHouse.over = "yes";
			pchar.quest.Romantic_AmbushInPortoBello.over = "yes";
		break;
		case "Rosita_after":
			dialog.text = "Capitaine " + GetFullName(pchar) + ", je suis contente de vous voir.";
			link.l1 = "Moi de même, señora.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Rosita_after";
		break;
		//Росита переживает, что Изабелла пропала
		case "BackRosita":
			dialog.text = "Oh, c'est vous, capitaine " + pchar.name + ". Vous tombez à pic ! C'est Dieu qui vous envoie !";
			link.l1 = "Que s'est-il passé, Rosita ? Salvator est venu ici ?";
			link.l1.go = "BackRosita_1";
		break;
		case "BackRosita_1":
			dialog.text = "Non, Salvator n'est pas venu. Mais il est arrivé quelque chose à Isabella ! Elle a disparu !";
			link.l1 = "Comment ça, disparu ? Quand ?";
			link.l1.go = "BackRosita_2";
		break;
		case "BackRosita_2":
			dialog.text = "Hier matin, elle est allée au marché avec une servante, et personne ne l'a revue depuis !";
			link.l1 = "Señora Rosita, je pars à sa recherche immédiatement !";
			link.l1.go = "BackRosita_3";
		break;
		case "BackRosita_3":
			dialog.text = "Que saint François vous vienne en aide !";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "BackRosita_after";
			pchar.RomanticQuest = "SeekIsabella";
			pchar.quest.SeekIsabella_exitTown.win_condition.l1 = "locator";
			pchar.quest.SeekIsabella_exitTown.win_condition.l1.location = "Beliz_ExitTown";
			pchar.quest.SeekIsabella_exitTown.win_condition.l1.locator_group = "quest";
			pchar.quest.SeekIsabella_exitTown.win_condition.l1.locator = "detector1";
			pchar.quest.SeekIsabella_exitTown.function = "SeekIsabella_exitTown";
			AddQuestRecord("Romantic_Line", "21");
			//миортвая служанка
			sld = GetCharacter(NPC_GenerateCharacter("ServantGirl", "girl_6", "woman", "towngirl", 5, SPAIN, 30, false));
			LAi_SetActorType(sld);
			LAi_ActorSetLayMode(sld);
			LAi_CharacterDisableDialog(sld);	// LEO: файла диалога у неё нет - разговор кончался вылетом
			ChangeCharacterAddressGroup(sld, "Beliz_ExitTown", "goto", "goto17");
			locations[FindLocation("Beliz_ExitTown")].DisableEncounters = true; //энкаутеры запретим
			//охранник Изабеллы в шахте
            sld = GetCharacter(NPC_GenerateCharacter("Bandit", "officer_6", "man", "man", 35, PIRATE, -1, true));
            FantomMakeCoolFighter(sld, 35, 85, 75, "topor2", "pistol3", 60);
			LAi_SetWarriorType(sld);
			LAi_CharacterDisableDialog(sld);	// LEO: то же - охранник без файла диалога
			LAi_warrior_SetStay(sld, true);
			LAi_group_MoveCharacter(sld, LAI_GROUP_MONSTERS);
			ChangeCharacterAddressGroup(sld, "Beliz_Cave_2", "goto", "goto4");
			LAi_LocationDisableOfficersGen("Beliz_Cave_2", true); //офицеров не пускать
			LAi_LocationDisableMonstersGen("Beliz_Cave_2", true); //монстров не генерить
			pchar.quest.Romantic_BanditIsDead.win_condition.l1 = "NPC_Death";
			pchar.quest.Romantic_BanditIsDead.win_condition.l1.character = "Bandit";
			pchar.quest.Romantic_BanditIsDead.win_condition = "Romantic_BanditIsDead";
		break;
		case "BackRosita_after":
			dialog.text = "Vous avez retrouvé Isabella ?!";
			link.l1 = "Pas encore, señora, je cherche...";
			link.l1.go = "exit";
		break;
		//если Изабелла погибла где-нить при похищении
		case "IsabellaIsDead_Beliz":
			dialog.text = "Capitaine, vous avez retrouvé Isabella ?";
			link.l1 = "Oui, Rosita, je l'ai retrouvée. Mais sur le chemin de la ville, nous avons été attaqués, et Isabella est morte...";
			link.l1.go = "IsabellaIsDead_Beliz_1";
			NextDiag.TempNode = "IsabellaIsDead_Beliz_after";
		break;
		case "IsabellaIsDead_Beliz_1":
			dialog.text = "Je n'arrive pas à y croire... Elle comptait tant sur vous ! Que Dieu ait son âme...";
			link.l1 = "Rosita, je meurs de chagrin !!";
			link.l1.go = "exit";
		break;
		case "IsabellaIsDead_Beliz_after":
			dialog.text = "Capitaine, je ne veux plus vous voir, adieu.";
			link.l1 = "Adieu, Rosita...";
			link.l1.go = "exit";
		break;
		//после спасения Изабеллы в пещере
		case "SavedIsabella":
			dialog.text = "Isabella !!";
			link.l1 = "Rosita !";
			link.l1.go = "SavedIsabella_1";
		break;
		case "SavedIsabella_1":
			dialog.text = "Tu vas bien ! Le Seigneur soit loué !";
			link.l1 = "Maintenant et toujours, et pour les siècles des siècles...";
			link.l1.go = "SavedIsabella_2";
		break;
		case "SavedIsabella_2":
			dialog.text = "Que s'est-il passé ? Oם étais-tu ? Et oם est Conchita ?";
			link.l1 = "Rosita, Salvator m'a enlevée. Et Conchita est morte : c'est mon mari qui l'a tuée...";
			link.l1.go = "SavedIsabella_3";
		break;
		case "SavedIsabella_3":
			dialog.text = "Le salaud ! Il faut tout raconter au gouverneur pour qu'il fasse arrêter Salvator immédiatement !";
			link.l1 = "Salvator est mort, lui aussi. Mon ange gardien m'a retrouvée et m'a délivrée... Salvator l'a attaqué, lui aussi, mais il a été tué sous mes yeux.";
			link.l1.go = "SavedIsabella_4";
		break;
		case "SavedIsabella_4":
			dialog.text = "Isabella, ce cauchemar est-il enfin terminé ?";
			link.l1 = "Oui, Rosita, c'est fini...";
			link.l1.go = "SavedIsabella_5";
		break;
		case "SavedIsabella_5":
			dialog.text = "Une fois de plus, ton fidèle chevalier a résolu tous les problèmes... Isabella, tu as beaucoup de chance d'avoir un tel admirateur !";
			link.l1 = "Ah, cousine, c'est bien vrai ! Rosita, je te raconterai les autres nouvelles plus tard, mais pour l'instant, ne retenons pas mon sauveur.";
			link.l1.go = "exit";
			NextDiag.TempNode = "SavedIsabella_after";
			AddDialogExitQuest("Romantic_DelivToRosita_2");
		break;
		case "SavedIsabella_after":
			dialog.text = "Capitaine, vous êtes vraiment un homme, un vrai !";
			link.l1 = "Hum, Rosita, merci du compliment...";
			link.l1.go = "exit";
			NextDiag.TempNode = "SavedIsabella_after";
		break;
		//Нападения на ГГ и Изабеллу в церкви
		case "AmbushInChurch":
			dialog.text = "Capitaine, le bonjour de Salvator !";
			link.l1 = "Salvator est mort, calmez-vous...";
			link.l1.go = "AmbushInChurch_1";
		break;
		case "AmbushInChurch_1":
			dialog.text = "Malheureusement, la fête est payée, cap'taine, et seul le client peut tout annuler...";
			link.l1 = "Je le répète encore une fois : Salvator est mort ! Vous n'avez donc rien de sacré ? C'est un mariage, dans la maison de Dieu !";
			link.l1.go = "AmbushInChurch_2";
		break;
		case "AmbushInChurch_2":
			dialog.text = "דa suffit, le temps des paroles est terminé...";
			link.l1 = "Argh !..";
			link.l1.go = "exit";
			AddDialogExitQuest("Romantic_fightInChurch_1");
		break;
		//базар с Роситой после убийства Изабеллы
		case "IsabellaIsDead":
			dialog.text = "Capitaine " + GetFullName(pchar) + ", contente de vous voir. Quelles nouvelles ? Vous avez déjà épousé Isabella ?";
			link.l1 = "Les nouvelles ne pourraient pas être pires, Rosita. Isabella est morte, elle a été assassinée dans l'église, au pied de l'autel. Les assaillants étaient trop nombreux...";
			link.l1.go = "IsabellaIsDead_1";
		break;
		case "IsabellaIsDead_1":
			dialog.text = "Oh, mon Dieu, pauvre Isabella !! Elle a tant souffert, elle n'a vraiment pas eu de chance avec son mari\n"+
				          "Puis vous êtes arrivé, et j'ai cru que son destin avait enfin changé pour le mieux. Mais on n'échappe pas à son destin, apparemment...";
			link.l1 = "Oh, Rosita, comme c'est dur pour moi !..";
			link.l1.go = "IsabellaIsDead_2";
		break;
		case "IsabellaIsDead_2":
			dialog.text = "Je vous comprends, capitaine... Pardonnez-moi, je dois prévenir toute ma famille : nous devons prendre le deuil...";
			link.l1 = "Oui, Rosita, je comprends...";
			link.l1.go = "exit";
			npchar.LifeDay = 0;
			NextDiag.TempNode = "IsabellaIsDead_after";
		break;
		case "IsabellaIsDead_after":
			dialog.text = "Capitaine, que vouliez-vous ?";
			link.l1 = "Rien, Rosita, je voulais juste rendre visite à la cousine de mon Isabella...";
			link.l1.go = "exit";
			NextDiag.TempNode = "IsabellaIsDead_after";
		break;
		//базар с Роситой, если ГГ отбился в церкви
		case "IsabellaIsMyWife":
			dialog.text = "Señor " + pchar.name + ", contente de vous voir ! Nous sommes parents, maintenant !";
			link.l1 = "Oui, señora Rosita. Isabella et moi nous sommes mariés...";
			link.l1.go = "IsabellaIsMyWife_1";
		break;
		case "IsabellaIsMyWife_1":
			dialog.text = "C'est très bien, capitaine. Isabella mérite mieux que ce gredin de Salvator !";
			link.l1 = "Je suis entièrement d'accord avec vous. Et je ne veux même pas penser à Salvator : je l'ai envoyé rejoindre ses ancêtres, et j'en suis très satisfait...";
			link.l1.go = "IsabellaIsMyWife_2";
		break;
		case "IsabellaIsMyWife_2":
			dialog.text = "Señor " + pchar.name + ", vous êtes un vrai chevalier ! Prenez soin d'Isabella... Au fait, si vous avez des problèmes avec elle, une dispute par exemple, vous serez toujours le bienvenu chez moi : je serai heureuse de vous aider.";
			link.l1 = "D'accord, cousine Rosita...";
			link.l1.go = "exit";
			NextDiag.TempNode = "IsabellaIsMyWife_after";
		break;
		case "IsabellaIsMyWife_after":
			dialog.text = "Ravie de vous voir, cousin " + pchar.name + " !";
			link.l1 = "Moi de même, señora Rosita.";
			link.l1.go = "exit";
			NextDiag.TempNode = "IsabellaIsMyWife_after";
		break;
		//семейная жизнь ГГ
		case "IsabellaIsWife":
			dialog.text = NPCStringReactionRepeat("Bonjour, cousin. Je suis si contente de vous voir ! Comment va Isabella ?",
				"Vous revenez me voir, cousin ? Nous venons de parler.",
				"Cousin, qu'y a-t-il encore ?! Vous n'apprendrez rien de nouveau de ma bouche !",
				"וcoutez, capitaine, si vous êtes aussi casse-pieds à la maison, je plains ma pauvre cousine Isabella !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Bonjour, cousine Rosita. Isabella va bien.",
				"Oui, c'est vrai, à l'instant... Pardonnez-moi, Rosita, je ne vous dérangerai plus...",
				"Ah oui ? Bon, d'accord...",
				"Non, Rosita, à la maison, je suis un ange incarné...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("IsabellaIsWife_1", "none", "none", "none", npchar, Dialog.CurrentNode);
			NextDiag.TempNode = "IsabellaIsWife";
		break;
		case "IsabellaIsWife_1":
			dialog.text = "Vous vouliez me demander quelque chose, capitaine ?";
			link.l1 = "Non, Rosita, je suis juste passé voir comment vous alliez.";
			link.l1.go = "exit";
			if (pchar.RomanticQuest == "over")
			{
				link.l2 = "Rosita, je ne sais même pas comment le dire... Isabella s'est enfermée dans la maison et ne veut pas me laisser entrer !";
				link.l2.go = "HorseCheck";
				break;
			}
			if (pchar.RomanticQuest == "TheDoosIsClosed")
			{
				link.l2 = "Rosita, je ne sais même pas comment le dire... Isabella s'est enfermée dans la maison et ne veut pas me laisser entrer !";
				link.l2.go = "TheDoosIsClosed";
			}
			sld = characterFromID("Isabella");
			if (CheckAttribute(sld, "angry")) //если Изабелла сидит на ангри
			{
				if (sld.angry.name == "NewLife_Budget_Pay")
				{
					link.l3 = "Vous savez, Rosita, j'ai eu des problèmes d'argent, et Isabella m'en veut beaucoup...";
					link.l3.go = "Budget";
				}
				if (sld.angry.name == "NewLife_KnowPirates")
				{
					link.l4 = "Imaginez-vous, Rosita, qu'Isabella a appris, je ne sais comment, que je n'avais pas complètement abandonné la course, comme je l'avais promis avant le mariage...";
					link.l4.go = "KnowPirates";
				}
				if (sld.angry.name == "NewLife_Present")
				{
					link.l5 = "Rosita, voilà l'affaire... Bref, Isabella me boude terriblement, elle ne veut plus parler à son mari. Voilà !";
					link.l5.go = "Present";
				}
			}
		break;
		case "TheDoosIsClosed":
			dialog.text = "Je vois... Vous avez dמ commettre une faute grave, capitaine. Vous êtes resté longtemps loin de la maison ?";
			link.l1 = "Hum, eh bien, comment dire... En gros, oui. Mais je suis marin, Rosita, et mon métier, c'est de prendre la mer sans arrêt.";
			link.l1.go = "TheDoosIsClosed_1";
		break;
		case "TheDoosIsClosed_1":
			dialog.text = "Je comprends, capitaine... Bon, je peux arranger cette affaire. Rentrez chez vous, tout ira bien...";
			link.l1 = "Rosita, vous êtes tout simplement un miracle !";
			link.l1.go = "TheDoosIsClosed_2";
		break;
		case "TheDoosIsClosed_2":
			dialog.text = "Ne me couvrez pas trop d'éloges, " + pchar.name + ". Je vous conseillerais de revenir à la raison et d'être plus souvent à la maison.";
			link.l1 = "Cousine, c'est exactement ce que je vais faire. Au revoir...";
			link.l1.go = "exit";
			AddQuestRecord("Romantic_Line", "30");
			LocatorReloadEnterDisable("SanJuan_town", "houseSp6", false);
			pchar.RomanticQuest = "OpenTheDoosOfHouse";
		break;

		case "Budget":
			dialog.text = "Quoi, de telles dettes ?";
			link.l1 = "Oui, Rosita. Isabella m'a demandé plusieurs fois de rembourser la dette, mais, comme par un fait exprès, je n'avais pas d'argent à ce moment-là.";
			link.l1.go = "Budget_1";
		break;
		case "Budget_1":
			dialog.text = "Hum, c'est fâcheux... Bon, je vais vous dire ce qu'il faut faire. Offrez-lui des émeraudes : une bague, un collier, et une simple pierre. Elle adore ces pierres, et je pense qu'elle se laissera attendrir...";
			link.l1 = "Je crois que je vais faire ça ! Merci, Rosita. Au revoir.";
			link.l1.go = "exit";
		break;

		case "KnowPirates":
			dialog.text = "Hum, cousin, pardonnez-moi la question, mais « pas complètement », qu'est-ce que ça veut dire ?";
			link.l1 = "Eh bien, vous savez, ce sont eux qui m'attaquent, alors que voulez-vous que je fasse ? J'attaque, bien sמr !";
			link.l1.go = "KnowPirates_1";
		break;
		case "KnowPirates_1":
			dialog.text = "Hum, je vois... Donc, vous, capitaine, vous n'y êtes absolument pour rien ?";
			link.l1 = "C'est exactement ça, cousine : voilà la définition exacte de ma participation à la piraterie !";
			link.l1.go = "KnowPirates_2";
		break;
		case "KnowPirates_2":
			dialog.text = "Je vois... Eh bien, le seul conseil que je puisse vous donner, c'est d'apaiser la cousine Isabella.";
			link.l1 = "Volontiers, mais avec quoi ?";
			link.l1.go = "KnowPirates_3";
		break;
		case "KnowPirates_3":
			dialog.text = "Des pierres diverses, et d'autres choses. Par exemple, moi, je vous offrirais un saphir, un diamant, un rubis, une grosse perle, et en plus une bague en or ornée d'un rubis...";
			link.l1 = "Hum, voilà une idée !.. Merci, Rosita, c'est ce que je vais faire, cousine ! Au revoir...";
			link.l1.go = "exit";
		break;

		case "Present":
			dialog.text = "Que s'est-il passé ?";
			link.l1 = "Oh, rien de spécial... J'ai décidé de lui offrir un cadeau, mais je n'ai rien trouvé qui convienne.";
			link.l1.go = "Present_1";
		break;
		case "Present_1":
			dialog.text = "Hum, ce n'est rien... Cousin, il y a quelque chose que vous ne me dites pas.";
			link.l1 = "Oui, en courant à droite à gauche, j'ai oublié que je lui avais déjà promis un cadeau... Bref, je le lui ai promis de nouveau. Et comme ça quatre fois...";
			link.l1.go = "Present_2";
		break;
		case "Present_2":
			dialog.text = "Vous avez exagéré, capitaine ! Qui supporterait ça ?!";
			link.l1 = "Il est clair que j'ai exagéré, mais que dois-je faire maintenant ?";
			link.l1.go = "Present_3";
		break;
		case "Present_3":
			dialog.text = "Faites ceci : offrez-lui enfin un cadeau. Prenez trois pépites d'or et cinq lingots d'argent. Je pense qu'Isabella se laissera attendrir...";
			link.l1 = "Oh, cousine Rosita, que ferais-je sans vous ! Je file chercher de l'or et de l'argent. Au revoir...";
			link.l1.go = "exit";
		break;

		case "HorseCheck":
			dialog.text = "Oui, je le sais. Et je veux vous dire ceci, capitaine : votre mariage est rompu, de façon unilatérale.";
			link.l1 = "Qu'est-ce que c'est que cette histoire ? Ce n'est quand même pas le pape lui-même qui l'a rompu ?";
			link.l1.go = "HorseCheck_1";
		break;
		case "HorseCheck_1":
			dialog.text = "Le mariage est dissous de fait, vous ne reverrez plus jamais Isabella.";
			link.l1 = "Je n'y comprends rien, mais que se passe-t-il ?";
			link.l1.go = "HorseCheck_2";
		break;
		case "HorseCheck_2":
			dialog.text = "Vous ne savez pas ? Eh bien, je vais vous dire de quoi il retourne.";
			link.l1 = "Oui, ayez cette bonté.";
			link.l1.go = "HorseCheck_3";
		break;
		case "HorseCheck_3":
			dialog.text = "Il fallait moins courir les bordels, mon cher ! Isabella peut pardonner beaucoup de choses, mais jamais une trahison !";
			link.l1 = "Bon sang !! Et qui le lui a dit ? On m'a calomnié !";
			link.l1.go = "HorseCheck_4";
		break;
		case "HorseCheck_4":
			dialog.text = "Inutile de jouer les hypocrites, les informations qu'Isabella a reçues sont plus que fiables. Adieu, capitaine...";
			link.l1 = "Euh... Adieu, Rosita...";
			link.l1.go = "exit";
			npchar.LifeDay = 0;
			NextDiag.TempNode = "HorseCheck_Bue";
			CloseQuestHeader("Romantic_Line");
			pchar.questdata.IstoriyaIzabely = 1;
		break;
		case "HorseCheck_Bue":
			dialog.text = "Je ne veux plus vous parler.";
			link.l1 = "...";
			link.l1.go = "exit";
			NextDiag.TempNode = "HorseCheck_Bue";
		break;
	}
}
