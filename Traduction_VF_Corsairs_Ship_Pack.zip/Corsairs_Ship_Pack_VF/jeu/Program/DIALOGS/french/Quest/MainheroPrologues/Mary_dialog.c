// BOAL новый диалог офицера и компаньона 21/06/06
void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);
	makearef(NextDiag, NPChar.Dialog);

	ref    sld;
	string attr, attrLoc;
	int    iTemp, iTax, iFortValue;

	bool bGoldMine = false;
	bool bSilverMine = false;
	bool bIronMine = false;

	if(CheckAttribute(PChar, "ColonyBuilding.GoldMine.BuildingTime"))
	{
		bGoldMine = PChar.ColonyBuilding.GoldMine == true && PChar.ColonyBuilding.GoldMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.SilverMine.BuildingTime"))
	{
		bSilverMine = PChar.ColonyBuilding.SilverMine == true && PChar.ColonyBuilding.SilverMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.IronMine.BuildingTime"))
	{
		bIronMine = PChar.ColonyBuilding.IronMine == true && PChar.ColonyBuilding.IronMine.BuildingTime == false;
	}

	switch(Dialog.CurrentNode)
	{
        case "First time":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = RandPhraseSimple("Hé, capitaine, la moitié de la garnison vous court après ici. Ce n'est clairement pas le moment de rejoindre votre équipage !", "Vous proposez de forcer le chemin jusqu'au navire en se battant ? Non, une autre fois, cap'taine...");
				link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Oui, je n'avais pas"+ GetSexPhrase(" l'intention", " l'intention") +" de vous engager.");
				link.l1.go = "exit";
				break;
			}
			Diag.TempNode = "OnceAgain";
			dialog.text = "Vous avez besoin d'un officier, capitaine ?";
			if (FindFreeRandomOfficer() > 0)
			{
    			Link.l1 = "Un officier ? א quoi êtes-vous bon ?";
    			Link.l1.go = "Node_2";
			}
			Link.l2 = "Non, j'ai mon effectif complet.";
			Link.l2.go = "Exit";
		break;

		case "CitizenNotBlade":
			dialog.text = "Charles, quelle bêtise ! Range ton arme avant de causer des ennuis !";
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			link.l1.go = "exit";
		break;

		case "hired":
			Diag.TempNode = "Hired";
			// если шлялся по борделям - устроит небольшой скандал 
			if (sti(pchar.GenQuest.BrothelCount) >= 1 && LAi_grp_playeralarm == 0 && NPChar.id == "SharleMary" && NPChar.name == "Mary")
			{
				dialog.Text = ""+pchar.name+" ! Il faut que je te parle, oui ! Sérieusement !";
				Link.l1 = "Qu'est-ce qui ne va pas, Mary ?";
				Link.l1.go = "Mary_brothel";
				break;
			}
			dialog.text = LinkRandPhrase("Je suis tout ouïe, mon amour !", "Oui, ma joie, je ferai tout ce que tu diras !", "Tu as une mission pour moi, mon amour ?");
			// диалог компаньона на корабле.
			if (CheckAttribute(NPChar, "IsCompanionClone"))
			{
				Link.l2 = "Mary, j'ai quelques ordres pour toi.";
				Link.l2.go = "Companion_Tasks";
				break;
			}
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
			{
				Link.l2 = LinkRandPhrase (LinkRandPhrase("Ma chérie, ", "Mon cœur, ", "Mary, ") + "j'ai une instruction pour toi.", LinkRandPhrase("Ma chérie, ", "Mon cœur, ", "Mary, ") + "j'ai besoin de te consulter.", LinkRandPhrase("Ma chérie, ", "Mon cœur, ", "Mary, ") + "il faut qu'on fasse quelque chose.");
	            Link.l2.go = "stay_follow";
			}	
           		// boal отчёт о корабле
			if(CheckAttribute(NPChar, "treasurer") && NPChar.treasurer == 1)
			{
			    Link.l8 = "Mary, fais-moi un rapport complet sur le navire.";
			    Link.l8.go = "QMASTER_1";

			    Link.l11 = "Je veux que tu achètes des marchandises pendant notre escale dans la colonie.";
			    Link.l11.go = "QMASTER_2";
			}

			for(iTemp=1; iTemp<=3; iTemp++) // Нужно, чтоб была свободная группа
			{
				attr = "Companion" + iTemp;
				if (CheckAttribute(PChar, "CompanionTravel."+(attr)+".ID"))
				{
					if (PChar.CompanionTravel.(attr).ID == NPChar.ID)
					{
						Link.l4 = "Mary, retourne dans l'escadre.";
						Link.l4.go = "CompanionTravel_ToSquadron";
					}
				}
			}
			//Предлагаем сэкс Мэри Каспер (для Шарля)
			if (PChar.location == Get_My_Cabin() && CheckAttribute(npchar, "quest.daily_sex") && npchar.id == "SharleMary")
			{
				DeleteAttribute(link, "l3");
			}
			if (PChar.location == Get_My_Cabin() && !CheckAttribute(npchar, "quest.daily_sex") && npchar.id == "SharleMary")
			{
				Link.l3 = RandPhraseSimple("Mon cœur, je veux être seul avec toi maintenant. דa ne te dérange pas ?", "Mon cœur, et si on... se retrouvait seuls ?");
				Link.l3.go = "Mary_cabin_sex";
			}
			if (!CheckAttribute(npchar, "quest.daily_sex") && sti(pchar.money) >= 10)
			{
				if (PChar.location == "SentJons_tavern" || PChar.location == "PortRoyal_tavern" || PChar.location == "Charles_tavern" || PChar.location == "Bridgetown_tavern" || 
					PChar.location == "PortSpein_tavern" || PChar.location == "Villemstad_tavern" || PChar.location == "Marigo_tavern" || PChar.location == "FortOrange_tavern" || 
					PChar.location == "Nassau_tavern" || PChar.location == "FortFrance_tavern" || PChar.location == "BasTer_tavern" || PChar.location == "LeFransua_tavern" || 
					PChar.location == "Tortuga_tavern" || PChar.location == "Caracas_tavern" || PChar.location == "Cumana_tavern" || PChar.location == "Cartahena_tavern" || 
					PChar.location == "Maracaibo_tavern" || PChar.location == "PortoBello_tavern" || PChar.location == "SantaCatalina_tavern" || PChar.location == "Beliz_tavern" || 
					PChar.location == "SantoDomingo_tavern" || PChar.location == "SanJuan_tavern" || PChar.location == "Santiago_tavern" || PChar.location == "Havana_tavern" || 
					PChar.location == "PuertoPrincipe_tavern" || PChar.location == "PortPax_tavern" || PChar.location == "LaVega_tavern" || PChar.location == "Pirates_tavern" || 
					PChar.location == "Panama_tavern" || PChar.location == "DesMoines_tavern")
					{
						Link.l3 = RandPhraseSimple("Mon cœur, et si on louait une chambre pour rester ensemble ?", "Ma chérie, j'ai vraiment envie d'être seul avec toi... on pourrait peut-être louer une chambre et tout oublier pendant deux ou trois heures ?");
						Link.l3.go = "Mary_room_sex";
					}
			}
			if (!CheckAttribute(pchar, "questTemp.FUNY_SHIP_FIND") && NPChar.sex == "woman" && GetCharacterItem(PChar, "mineral4") >= 25)
            {
                Link.l4 = "Regarde la collection intéressante que j'ai réunie !";
				Link.l4.go = "FUNY_SHIP_1";
            }

            // по тёк локации определим можно ли тут приказать  -->
            if (IsEntity(loadedLocation))
            {
                if (CheckAttribute(loadedLocation, "fastreload"))
                {
                    iTemp = FindColony(loadedLocation.fastreload);
                    if (iTemp != -1)
                    {
                        sld = GetColonyByIndex(iTemp);
                        if (sti(sld.HeroOwn) == true && !CheckAttribute(sld, "OfficerIdx"))
                        {
							if(Locations[FindLocation(PChar.location)].islandId != "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
							{
								NPChar.ColonyIdx = iTemp;
								Link.l7 = "Je te nomme gouverneur de cette ville !";
								Link.l7.go = "Gover_Hire";
							}
                        }
                    }
                }
            }
            if(PChar.ColonyBuilding.Stage != "0" && PChar.ColonyBuilding.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l8 = "Je veux te nommer gouverneur de la colonie " + PChar.ColonyBuilding.ColonyName + ", que nous avons bâtie sur l'île des Caïmans.";
						Link.l8.go = "ColonyBuilding_Hovernor_1";
					}
				}
			}

			if(PChar.ColonyBuilding.Stage == "3" && PChar.Colony.Guardians.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l9 = "Je veux vous nommer à la tête de la base de sécurité que nous avons bâtie pour renforcer la défense de notre colonie '" + PChar.ColonyBuilding.ColonyName + "'.";
						Link.l9.go = "ColonyGuarding_Hovernor_1";
					}
				}
			}

			if(bGoldMine || bSilverMine || bIronMine)
			{
				if(PChar.Mines.Commander == "")
				{
					if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
					{
						if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
						{
							Link.l10 = "Je veux vous nommer gérant des mines qui se trouvent sur cette île.";
							Link.l10.go = "MinesCommander_Hire";
						}
					}
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.Plantation.Commander == "")
				{
					if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
					{
						if(Locations[FindLocation(PChar.location)].islandId == "Caiman")
						{
							Link.l11 = "Je veux te nommer régisseuse de la plantation qui se trouve près de la colonie " + PChar.ColonyBuilding.ColonyName + " et qui lui appartient.";
							Link.l11.go = "PlantationCommander_Hire";
						}
					}
				}
			}
            Link.l12 = "Rien. Repos.";
            Link.l12.go = "Exit";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
			{
				Link.l12 = LinkRandPhrase ("Je n'arrive pas à te quitter des yeux, " + LinkRandPhrase("mon talisman roux.", "ma belle lionne.", "ma beauté."), "Je voulais juste t'admirer, " + LinkRandPhrase("mon talisman roux.", "ma belle lionne.", "ma beauté."), "Tu me plais, " + LinkRandPhrase("mon talisman aux cheveux roux.", "ma belle lionne.", "ma beauté."));
	            Link.l12.go = "Exit";
			}
        break;

		case "FUNY_SHIP_1":
		    dialog.text = "Quelle horreur ! Charles, éloigne ça de moi, c'est une puanteur insupportable... Tu crois à toutes ces bêtises de la vieille légende sur la jeunesse éternelle ?";
   			Link.l1 = "Non, bien sמr, pardon. Je vais jeter toute cette masse puante par-dessus bord.";
            Link.l1.go = "exit";
            Link.l2 = "Oui, j'y crois ! Et en plus, je vais vérifier. Allez, approche, ma chérie !";
            Link.l2.go = "FUNY_SHIP_2";
        break;

        case "FUNY_SHIP_2":
		    dialog.text = "Quelle puanteur ! Pouah... Mais ça marche : je me sens plus forte, et même, euh, plus sexy.";
   			Link.l1 = "Voilà ! Et vous aviez peur, votre jupe n'est même pas froissée. Lavez-vous les mains, maintenant.";
            Link.l1.go = "FUNY_SHIP_3";
        break;

        case "FUNY_SHIP_3":
            PChar.questTemp.FUNY_SHIP_FIND = false;
            DialogExit();
			NextDiag.CurrentNode = "Hired";

			TakeNItems(pchar, "mineral4", -25);
			AddSPECIALValue(Npchar, SPECIAL_S, 1);
			AddSPECIALValue(Npchar, SPECIAL_P, 1);
			AddSPECIALValue(Npchar, SPECIAL_E, 1);
			AddSPECIALValue(Npchar, SPECIAL_C, 1);
			AddSPECIALValue(Npchar, SPECIAL_I, 1);
			AddSPECIALValue(Npchar, SPECIAL_A, 1);
			AddSPECIALValue(Npchar, SPECIAL_L, 1);
        break;

		case "MaryCabinHelp_1":
			dialog.text = "Charles, je ne peux pas rester les bras croisés ! Je vais m'inquiéter... et m'ennuyer...";
            Link.l1 = "Mon soleil, tu m'es si chère que je ne peux pas te mettre en danger !";
            Link.l1.go = "exit";
			pchar.MaryCabinHelp = !sti(pchar.MaryCabinHelp);
		break;
		
		case "MaryCabinHelp_2":
			dialog.text = "J'irai au bout du monde avec toi, oui !";
            Link.l1 = "Ma chérie !";
            Link.l1.go = "exit";
			pchar.MaryCabinHelp = !sti(pchar.MaryCabinHelp);
		break;

		case "TransferGoodsEnable":
			Diag.CurrentNode = "Hired";
			DialogExit();
			LaunchTransferGoodsScreen(); // Интерфейс автозакупки товаров
		break;

		case "ShowParam_exit":
			Diag.CurrentNode = "OnceAgain";
			NPChar.quest.meeting = true;
			DialogExit();

			PChar.SystemInfo.OnlyShowCharacter = true;
            LaunchCharacter(NPChar);
		break;

		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_hire":
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.CanTakeMushket = true;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire":
			//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}
			//navy <--
			Diag.TempNode = "Fired";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;

			DialogExit();
		break;

        case "QMASTER_1":
			if(sti(PChar.Ship.Type) == SHIP_NOTUSED)
			{
				dialog.text = "Charles, mais nous n'avons pas de navire !";
				Link.l1 = "Merci de me le rappeler...";
				Link.l1.go = "Exit";
				Diag.TempNode = "Hired";
				break;
			}
            dialog.text = "Le navire est magnifique, Charles, oui ! La brèche sous la ligne de flottaison a été colmatée après la dernière bataille, les voiles ont séché. Qu'est-ce que tu voulais ? Ne me regarde pas comme ça, je n'ai jamais étudié pour être trésorière.";
            Link.l1 = "Pardon, Mary, je n'y avais vraiment pas pensé.";
            Link.l1.go = "Exit";
            Diag.TempNode = "Hired";
        break;
		
		case "QMASTER_2":
            dialog.text = "Charles, je n'ai besoin de rien acheter. J'ai des vêtements, j'ai une lame. Mais merci pour ton attention, ça me fait très plaisir, oui !";
            Link.l1 = "C'est ce que je voulais dire... Bon, ma chérie, oublie ça, ce n'est rien.";
            Link.l1.go = "Exit";
            Diag.TempNode = "Hired";
        break;

        // boal 05.09.03 offecer need to go to abordage -->
        case "stay_follow":
            dialog.text = "Quels sont vos ordres ?";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
				{
				dialog.text = LinkRandPhrase("Et qu'est-ce que tu mijotes ?", "Tu veux tuer quelqu'un ? Je suis avec toi, oui !", "Et qu'est-ce que tu mijotes ?");
				}
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
				{
				Link.l1 = "Mary, attends-moi ici, ne bouge pas !";
				Link.l1.go = "Boal_Stay";
				}
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
				{
				Link.l2 = "Mary, il faut y aller !";
				Link.l2.go = "Boal_Follow";
				}
            // boal 05.09.03 offecer need to go to abordage <--

			if (findsubstr(npchar.model, "PGG" , 0) != -1 && !CheckAttribute(npchar, "CanTakeMushket"))
			{
				Link.l3 = "Puis-je te confier un mousquet ?";
				Link.l3.go = "CheckMushket";
			}
			if (findsubstr(npchar.model.animation, "mushketer" , 0) != -1)
			{
				Link.l3 = "Je veux que tu restes à une certaine distance de la cible.";
				Link.l3.go = "TargetDistance";
			}
			if (!CheckAttribute(npchar, "AboardRestriction"))
			{
				Link.l4 = "Je vous demande de ne pas participer aux abordages. Prenez soin de vous.";
				Link.l4.go = "AboardRestriction";
			}
			else
			{
				Link.l4 = "J'ai changé d'avis, vous pouvez participer aux abordages.";
				Link.l4.go = "AboardAllowed";
			}
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
			{
				if(Pchar.MaryCabinHelp == true)
				{
					Link.l14 = "Pendant le combat dans la cabine, je me battrai seul.";
					Link.l14.go = "MaryCabinHelp_1";
				}
				else
				{
					Link.l14 = "Pendant le combat dans la cabine, nous nous battrons ensemble, cכte à cכte.";
					Link.l14.go = "MaryCabinHelp_2";
				}		
			}
			
			link.l9 = "En t'admirant, j'ai oublié ce que je voulais dire...";
			link.l9.go = "exit";
		break;

		case "AboardRestriction":
			npchar.AboardRestriction = true;
			dialog.text = "א vos ordres, capitaine. Je ne participerai pas aux abordages tant que vous ne me l'aurez pas de nouveau permis.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
				{
				dialog.text = "Charles, tu es fou ! Et s'il t'arrive quelque chose et que je ne suis pas là... א nous deux, on va tous leur montrer, oui !";
				Link.l1 = "Mary, c'est hors de question, tu m'es chère, et je veux que tu sois en sécurité.";
				Link.l1.go = "exit";
				}
		break;

		case "AboardAllowed":
			DeleteAttribute(npchar, "AboardRestriction");
			dialog.text = "א vos ordres, capitaine. Désormais, je participerai aux abordages.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
			if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
				{
				dialog.text = "Bie-e-en ! Je suis contente que tu ne m'aies pas oubliée, maintenant, on va détruire les ennemis ensemble, oui !";
				Link.l1 = "דa me fait plaisir à entendre, mon amour !";
				Link.l1.go = "exit";
				}
		break;

		case "CheckMushket":
			if (findsubstr(npchar.model.animation, "man" , 0) != -1 || findsubstr(npchar.model.animation, "YokoDias" , 0) != -1 || findsubstr(npchar.model.animation, "Milenace" , 0) != -1)
			{
				if (findsubstr(npchar.model.animation, "man2_ab" , 0) == -1)	Npchar.CanTakeMushket = true;
			}

			if (CheckAttribute(npchar, "CanTakeMushket"))
			{
				dialog.text = "Bien sמr, Charles !";
				Link.l1 = "Parfait, alors nous te trouverons quelque chose, si possible.";
				Link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Mieux vaut pas, Charles. Je pourrais te toucher par accident.";
				Link.l1 = "C'est vrai, tu es très douée à l'arme blanche.";
				Link.l1.go = "exit";
			}
		break;

		case "TargetDistance":
			dialog.text = "Laquelle, Charles ? Montre-la-moi, mais pas à plus de 20 mètres.";
			link.l1 = "";
			Link.l1.edit = 3;
			link.l1.go = "TargetDistance_1";
		break;
		case "TargetDistance_1":
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp < 0)
			{
				dialog.text = "Charles, je n'ai pas entendu !";
				link.l1 = "Je répète tout de suite...";
				link.l1.go = "exit";
				break;
			}
			if (iTemp == 0)
			{
				dialog.text = "Je vais rester sur place, sans bouger. Charles, ça te va ?";
				link.l1 = "Oui, c'est exactement ce que je veux que tu fasses, Mary.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 0;
				break;
			}
			if (iTemp > 20)
			{
				dialog.text = "Je crois avoir dit que je ne peux pas rester à plus de 20 mètres de la cible.";
				link.l1 = "D'accord, garde tes distances à 20 mètres.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 20.0;
				break;
			}
			dialog.text = "Mission comprise, je suis prêt"+NPCharSexPhrase(npchar, "", "e")+" ! Oui !";
			link.l1 = "Parfait.";
			link.l1.go = "exit";
			npchar.MusketerDistance = iTemp;
		break;

        // boal 05.09.03 offecer need to go to abordage -->
	      case "Boal_Stay":
             //SetCharacterTask_Stay(Characters[Npchar.index]); // it's a mistic but here doesn't work :(
             //Log_SetStringToLog(Npchar.id +" "+Npchar.index);
              Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
              AddDialogExitQuestFunction("LandEnc_OfficerStay");
		      Diag.TempNode = "Hired";
		      dialog.text = "Il y a un changement de lieu !";
		      Link.l1 = "Repos.";
		      Link.l1.go = "Exit";
			  if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
			  {
				dialog.text = "Je t'attendrai ici, mon amour !";
				Link.l1 = "Je reviens tout de suite, mon amour, ne t'ennuie pas";
				Link.l1.go = "Exit";
			  }
		      Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
	      break;
	      case "Boal_Follow":
		      SetCharacterTask_FollowCharacter(Npchar, PChar); // it works here!!!
		      Diag.TempNode = "Hired";
		      dialog.text = "Il y a un changement de lieu !";
		      Link.l1 = "Repos.";
		      Link.l1.go = "Exit";
			  if (NPChar.id == "SharleMary" && NPChar.name == "Mary")
			  {
				dialog.text = "Nous voilà de nouveau ensemble, oui !";
				Link.l1 = "Oui, Mary, tu as raison, comme toujours !";
				Link.l1.go = "Exit";
			  }
	      break;
        // boal 05.09.03 offecer need to go to abordage <--

		//////////////////////////////    офицер-наместник -->
		case "Gover_Hire":
            dialog.Text = "Ce serait un honneur !";
            Link.l1 = "Veillez à l'ordre et à la prospérité de la ville ; je viendrai de temps en temps percevoir le tribut.";
			Link.l1.go = "Exit_Gover_Hire";
            Link.l2 = "J'ai changé d'avis.";
            Link.l2.go = "Exit";
            Diag.TempNode = "Hired";
        break;

        case "Exit_Gover_Hire":
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            attr = sld.id + "_townhall";

            // снимем пассажира -->
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			// снимем пассажира <--
		    sld.OfficerIdx = sti(NPChar.index);
			ChangeCharacterAddressGroup(NPChar, attr, "sit", "sit1");
			LAi_SetHuberTypeNoGroup(NPChar);
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
            LAi_LoginInCaptureTown(NPChar, true);
			//  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_1");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
			Diag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Main":
            iTemp = GetNpcQuestPastDayParam(NPChar, "GoverTalkDate");
            if (iTemp > 0)
            {
				dialog.Text = "Quels sont les ordres ? Ta dernière visite remonte à " + FindRussianDaysString(iTemp) + " déjà.";
			}
			else
			{
			    dialog.Text = "Quels sont vos ordres ?";
			}

            Link.l1 = "Combien d'impכts avez-vous perçus ?";
        	Link.l1.go = "Gover_Tax";
            Link.l8 = "On a besoin de vous sur le navire, je vous relève de vos fonctions en ville.";
            Link.l8.go = "Gover_Fire";
			Link.l9 = "Bonne journée.";
            Link.l9.go = "Exit";
            Diag.TempNode = "Gover_Main";
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
        break;

        case "Gover_Tax":
            iTemp = GetNpcQuestPastDayParam(NPChar, "StartTaxDate");
            iTax  = makeint((GetCharacterSkillSimple(NPChar, SKILL_COMMERCE) + GetCharacterSkillSimple(NPChar, SKILL_LEADERSHIP)) / 2);
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
			if (CheckAttribute(sld, "FortValue"))
			{
			    iFortValue = sti(sld.FortValue);
			}
			else
			{
			    iFortValue = 20;
			}
			NPChar.Gover_Tax_Sum = iFortValue*iTax*iTemp;
			dialog.Text = "Mes compétences me permettent de percevoir " + FindRussianMoneyString(iFortValue*iTax) + " par jour. En " + FindRussianDaysString(iTemp) + " j'ai perçu " + FindRussianMoneyString(sti(NPChar.Gover_Tax_Sum)) + ".";
			if (sti(NPChar.Gover_Tax_Sum) > 0)
			{
			    Link.l1 = "Je veux percevoir la totalité des impכts.";
            	Link.l1.go = "Gover_Tax_Get";
			}
			Link.l2 = "Merci pour vos services !";
            Link.l2.go = "Exit";
        break;

        case "Gover_Tax_Get":
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            AddMoneyToCharacter(Pchar, sti(NPChar.Gover_Tax_Sum));

			Diag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Fire":
            dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
            Link.l8 = "Voilà qui est bien.";
            Link.l8.go = "exit_hire";
            Diag.TempNode = "Hired";
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            DeleteAttribute(sld, "OfficerIdx");
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_2");
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
        break;
        //////////////////////////////    офицер-наместник <--

		//Указания для компаньона 19.02.08 -->
		case "Companion_Tasks":
			dialog.Text = "Que voulais-tu, mon amour ?";
			Link.l1 = "Il s'agit de l'abordage.";
			Link.l1.go = "Companion_TaskBoarding";
			Link.l2 = "Il s'agit de votre navire.";
			Link.l2.go = "Companion_TaskChange";
			// if(bBettaTestMode) // Только при бета-тесте
			// {
			    Link.l3 = "Je veux que vous quittiez mon escadre pour un temps et que vous naviguiez par vos propres moyens.";
			    Link.l3.go = "CompanionTravel";
			// }
			Link.l8 = "Rien pour l'instant.";
			Link.l8.go = "exit";
		break;

		case "Companion_TaskBoarding":
			dialog.Text = "";
			Link.l1 = "Je veux que tu ne montes pas à l'abordage des navires. Prends soin de toi et de ton équipage.";
			Link.l1.go = "Companion_TaskBoardingNo";
			Link.l2 = "J'ai besoin que vous abordiez les navires ennemis.";
			Link.l2.go = "Companion_TaskBoardingYes";
		break;

		case "Companion_TaskChange":
			dialog.Text = "";
			Link.l1 = "Je ne veux pas que vous changiez de navire après un abordage. Il a trop de valeur.";
			Link.l1.go = "Companion_TaskChangeNo";
			Link.l2 = "Quand tu aborderas l'ennemi, regarde s'il y a un navire convenable, et prends-le pour toi.";
			Link.l2.go = "Companion_TaskChangeYes";
		break;

		case "Companion_TaskBoardingNo":
			dialog.Text = "Compris, oui !";
			Link.l1 = "C'est bien, ma fille !";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = false;
		break;

		case "Companion_TaskBoardingYes":
			dialog.Text = "Compris, oui !";
			Link.l1 = "C'est bien, ma fille !";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = true;
		break;

		case "Companion_TaskChangeNo":
			dialog.Text = "Compris, oui !";
			Link.l1 = "C'est bien, ma fille !";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = false;
		break;

		case "Companion_TaskChangeYes":
			dialog.Text = "Compris, oui !";
			Link.l1 = "C'est bien, ma fille !";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = true;
		break;
		//<--

		// Самостоятельное плавание компаньона -->
		case "CompanionTravel":
			if(GetAttrValue(PChar, "CompanionTravel") == 3) // Если уже троих отпустил
			{
				dialog.Text = "Charles, je ne quitterai pas ton escadre, puisque tu as déjà détaché trois navires.";
					Link.l1 = "Oui, je suppose que tu as raison.";
					Link.l1.go = "exit";
				break;
			}

			dialog.Text = "Pas de problème, Charles. Oם dois-je aller ?";
			Link.l1 = "Va à la ville...";
			Link.l1.go = "Travel_Towns";

			Link.l2 = "Va au repaire pirate...";
			Link.l2.go = "TravelToPiratesTowns";

			Link.l3 = "Va sur une île déserte...";
			Link.l3.go = "TravelToNomanIslands";

			Link.l99 = "J'ai changé d'avis. Rien du tout.";
			Link.l99.go = "exit";
		break;

		case "Travel_Towns":
			dialog.Text = "Oם sera le lieu de rendez-vous, Charles ?";
			for(iTemp=0; iTemp<MAX_COLONIES; iTemp++)
			{
				sld = &colonies[iTemp];
				attr = sld.ID;
				if(sld.nation == "none" || sld.nation == PIRATE || attr == "Panama") continue;
				attrLoc = "l" + iTemp;
				NPChar.Temp.(attr) = attr;
				Link.(attrLoc) = "א " + XI_ConvertString("Colony" + attr + "Voc");
				if (IsColonyEnemyToMainCharacter(attr)) {
					Link.(attrLoc).go = "CompanionTravel_EnemyColony";
					continue;
				}
				Link.(attrLoc).go = "CompanionTravelToColony_" + attr;
			}
			Link.l99 = "J'ai changé d'avis. Rien du tout.";
			Link.l99.go = "exit";
		break;

		case "TravelToPiratesTowns":
			dialog.Text = "Lequel exactement ?";
				Link.l1 = "Sharp-Town";
				Link.l1.go = "TravelToPirates";
				Link.l2 = "Le François";
				Link.l2.go = "TravelToLeFransua";
				Link.l3 = "La Vega";
				Link.l3.go = "TravelToLaVega";
				Link.l4 = "Puerto Príncipe";
				Link.l4.go = "TravelToPuertoPrincipe";
				Link.l6 = "Tu sais, reste pour l'instant, j'ai changé d'avis.";
				Link.l6.go = "exit";
		break;
		case "TravelToNomanIslands":
			dialog.Text = "Lequel exactement ?";
				Link.l1 = "Caiman";
				Link.l1.go = "TravelToCaiman";
				Link.l2 = "Dominica";
				Link.l2.go = "TravelToDominica";
				Link.l3 = "טles Turques";
				Link.l3.go = "TravelToTerks";
				Link.l4 = "Sainte-Lucie";
				Link.l4.go = "TravelToLucia";
				Link.l5 = "Tu sais, reste pour l'instant, j'ai changé d'avis.";
				Link.l5.go = "exit";
		break;

		case "TravelToCaiman":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_2;									// Companion index
				cn_2 = GetCompanionIndex(PChar, i);
				if (cn_2 == -1) continue;
				if (NPChar.name == characters[cn_2].name) NPChar.realcompanionidx = &characters[cn_2].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Caiman";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Caiman"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Caiman" + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLucia":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_3;									// Companion index
				cn_3 = GetCompanionIndex(PChar, i);
				if (cn_3 == -1) continue;
				if (NPChar.name == characters[cn_3].name) NPChar.realcompanionidx = &characters[cn_3].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "StLucia";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("StLucia"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("StLucia" + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToDominica":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_4;									// Companion index
				cn_4 = GetCompanionIndex(PChar, i);
				if (cn_4 == -1) continue;
				if (NPChar.name == characters[cn_4].name) NPChar.realcompanionidx = &characters[cn_4].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Dominica";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Dominica"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Dominica" + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToTerks":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_5;									// Companion index
				cn_5 = GetCompanionIndex(PChar, i);
				if (cn_5 == -1) continue;
				if (NPChar.name == characters[cn_5].name) NPChar.realcompanionidx = &characters[cn_5].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Terks";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Terks"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Terks" + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLaVega":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_6;									// Companion index
				cn_6 = GetCompanionIndex(PChar, i);
				if (cn_6 == -1) continue;
				if (NPChar.name == characters[cn_6].name) NPChar.realcompanionidx = &characters[cn_6].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "LaVega";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("LaVega"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToPuertoPrincipe":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_7;									// Companion index
				cn_7 = GetCompanionIndex(PChar, i);
				if (cn_7 == -1) continue;
				if (NPChar.name == characters[cn_7].name) NPChar.realcompanionidx = &characters[cn_7].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "PuertoPrincipe";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("PuertoPrincipe"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToFortOrange":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_8;									// Companion index
				cn_8 = GetCompanionIndex(PChar, i);
				if (cn_8 == -1) continue;
				if (NPChar.name == characters[cn_8].name) NPChar.realcompanionidx = &characters[cn_8].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "FortOrange";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("FortOrange"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToPirates":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_9;									// Companion index
				cn_9 = GetCompanionIndex(PChar, i);
				if (cn_9 == -1) continue;
				if (NPChar.name == characters[cn_9].name) NPChar.realcompanionidx = &characters[cn_9].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Pirates";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Pirates"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLeFransua":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_10;									// Companion index
				cn_10 = GetCompanionIndex(PChar, i);
				if (cn_10 == -1) continue;
				if (NPChar.name == characters[cn_10].name) NPChar.realcompanionidx = &characters[cn_10].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "LeFransua";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("LeFransua"))/300+1.0);
			dialog.Text = "Alors, tu veux que je me rende à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+" Kapitan ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;

		int nFind = findSubStr(Dialog.CurrentNode, "CompanionTravelToColony_", 0);
		string idxVal;
		string nodName;
		if (nFind == 0)
		{
			idxVal = strcut(Dialog.CurrentNode, 24, strlen(Dialog.CurrentNode) - 1);
			nodName = "CompanionTravelToColony_" + idxVal;
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn;									// Companion index
				cn = GetCompanionIndex(PChar, i);
				if (cn == -1) continue;
				if (NPChar.name == characters[cn].name) NPChar.realcompanionidx = &characters[cn].index;
			}
			aref rCTravel;
			makearef(rCTravel, characters[sti(NPChar.realcompanionidx)].CompanionTravel);
			rCTravel.ToColonyID = NPChar.Temp.(idxVal);
			rCTravel.Days = makeint(GetDistanceToColony2D(NPChar.Temp.(idxVal)) / 300 + 1.0);
			dialog.Text = "Vous avez choisi la colonie de " + XI_ConvertString("Colony" + rCTravel.ToColonyID + "Gen") + " Kapitan ?";
			Link.l1 = "Oui, c'est elle.";
			Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
			break;
		}

		case "CompanionTravel_EnemyColony":
			dialog.Text = "Capitaine, mais je ne peux pas vous attendre dans une colonie qui nous est hostile !";
				Link.l1 = "Tu sais, oublie tous ces voyages...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoCrew":
			dialog.Text = "Cap'taine, il n'y a presque plus de marins sur le navire ! Quelle navigation ?!";
				Link.l1 = "Oui, c'est vrai. Il n'y a presque plus d'équipage...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoFood":
			dialog.Text = "Cap'taine, je n'ai pas assez de vivres à bord pour ce voyage.";
				Link.l1 = "Oui, tu as raison. Le voyage attendra...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoHP":
			dialog.Text = "Cap'taine, mais mon navire est en mauvais état. Il n'est pas sage pour moi de prendre la mer seul dans de telles conditions !";
				Link.l1 = "Oui, tu as raison. Ton navire a besoin de réparations.";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_PrepareStart":
			int iShip = sti(characters[sti(NPChar.realcompanionidx)].ship.type);
			ref refBaseShip = GetRealShip(iShip);
			if (sti(refBaseShip.hp)/4>sti(characters[sti(NPChar.realcompanionidx)].ship.hp))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoHP";
				break;
			}
			if (sti(refBaseShip.MinCrew)>GetCrewQuantity(characters[sti(NPChar.realcompanionidx)]))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoCrew";
				break;
			}
			if (sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days)+30>CalculateShipFood(characters[sti(NPChar.realcompanionidx)]))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoFood";
				break;
			}
			dialog.Text = "Tout est clair. Pour aller à " + XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen") + " il me faut " + sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days) + " jours. Que dois-je faire à mon arrivée ?";
			if (sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days) == 1)
			{
			dialog.Text = "Tout est clair. " + XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen") + " est tout près, j'y serai aujourd'hui même. Que dois-je faire là-bas ?";
			}
			Link.l1 = "Attends-moi en rade pendant un mois.";
			Link.l1.go = "CompanionTravel_PrepareStart_2";
			Link.l2 = "Tu sais, j'ai changé d'avis. Reste avec moi pour l'instant...";
			Link.l2.go = "exit";
		break;

		case "CompanionTravel_PrepareStart_2":
			dialog.Text = "C'est clair, capitaine. Je pars immédiatement.";
				Link.l1 = "Oui, vas-y.";
				Link.l1.go = "CompanionTravel_Start";
		break;

		case "CompanionTravel_Start":
			Diag.CurrentNode = "CompanionTravel_LastNode";
			NPChar.quest.meeting = true;
			CompanionTravel_SetTraveller(NPChar);
			DialogExit();
		break;

		case "CompanionTravel_LastNode":
Dialog.text = RandPhraseSimple("Aujourd'hui, je reprends la mer...",
			"N'oublie pas de me retrouver à " + XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Dat") + ".");
				link.l2 = "...";
				link.l2.go = "Exit";
				Diag.TempNode = "CompanionTravel_LastNode";
		break;

		case "CompanionTravel_ToSquadron":
			if(GetCompanionQuantity(PChar) < COMPANION_MAX)
			{
				dialog.text = "Moi aussi, je le souhaite. Désormais, mon navire est de nouveau sous ton commandement, cap'.";
					Link.l1 = "Bien.";
					Link.l1.go = "exit";
					Diag.TempNode = "hired";
					CompanionTravel_DeleteSpecialShipAttributes(NPChar);
					Group_DeleteGroup(NPChar.CompanionTravel.GroupID); // Потрём группу
					SetCompanionIndex(PChar, -1, sti(NPChar.index));
					PChar.CompanionTravel = sti(PChar.CompanionTravel) - 1; // Этого компаньона взяли обратно в эскадру
					AddQuestRecord("CompanionTravel", "2");
					AddQuestUserData("CompanionTravel", "sCapName", GetFullName(NPChar)); 
					AddQuestUserData("CompanionTravel", "sShipInfo", GetStrSmallRegister(XI_ConvertString(RealShips[sti(NPChar.Ship.Type)].Basename + "Dat")) + " '" + NPChar.Ship.name + "'");
					if(GetAttrValue(PChar, "CompanionTravel") == 0) CloseQuestHeader("CompanionTravel");
					DeleteAttribute(NPChar, "CompanionTravel");
					for(iTemp=1; iTemp<=3; iTemp++) // Нужно, чтоб была свободная группа
					{
						attr = "Companion" + iTemp;
						if (CheckAttribute(PChar, "CompanionTravel."+(attr)+".ID"))
						{
							if (PChar.CompanionTravel.(attr).ID == NPChar.ID)
							{
								DeleteAttribute(PChar, "CompanionTravel."+(attr));
								DeleteAttribute(NPChar, "Tasks.Clone");
							}
						}
					}
			}
			else
			{
				dialog.text = "Cap'taine, vous avez déjà une escadre de cinq rafiots, oם mettrez-vous le sixième ? Bref, je vous attendrai ici sur mon navire : tous ces nouveaux compagnons ne sont pas fiables, leurs navires couleront très vite, et vous reviendrez me chercher.";
					Link.l1 = "Eh, tu as une sacrée tête. Tu ne devrais pas être capitaine, mais amiral !";
					Link.l1.go = "exit";
					Diag.TempNode = "CompanionTravel_ToSquadron_2";
					NPChar.DeckDialogNode = "CompanionTravel_ToSquadron_2"; // ставим снова эту ноду
			}
		break;

		case "CompanionTravel_ToSquadron_2":
			dialog.text = "Ah, capitaine. Vous voilà de retour, comme je l'avais dit. Alors, une place s'est-elle libérée dans l'escadre ?";
			if(GetCompanionQuantity(PChar) < COMPANION_MAX)
			{
				Link.l1 = "Oui, " + npchar.name + ", une place s'est libérée. Bienvenue dans l'escadre.";
				Link.l1.go = "exit";
				Diag.TempNode = "hired";
				CompanionTravel_DeleteSpecialShipAttributes(NPChar);
				Group_DeleteGroup(NPChar.CompanionTravel.GroupID);
				SetCompanionIndex(PChar, -1, sti(NPChar.index));
				PChar.CompanionTravel = sti(PChar.CompanionTravel) - 1; // Этого компаньона взяли обратно в эскадру
				AddQuestRecord("CompanionTravel", "2");
				AddQuestUserData("CompanionTravel", "sCapName", GetFullName(NPChar)); 
				AddQuestUserData("CompanionTravel", "sShipInfo", GetStrSmallRegister(XI_ConvertString(RealShips[sti(NPChar.Ship.Type)].Basename + "Dat")) + " '" + NPChar.Ship.name + "'");
				if(GetAttrValue(PChar, "CompanionTravel") == 0) CloseQuestHeader("CompanionTravel");
				DeleteAttribute(NPChar, "CompanionTravel");
				for(iTemp=1; iTemp<=3; iTemp++) // Нужно, чтоб была свободная группа
				{
					attr = "Companion" + iTemp;
					if (CheckAttribute(PChar, "CompanionTravel."+(attr)+".ID"))
					{
						if (PChar.CompanionTravel.(attr).ID == NPChar.ID)
						{
							DeleteAttribute(PChar, "CompanionTravel."+(attr));
							DeleteAttribute(NPChar, "Tasks.Clone");
						}
					}
				}
			}
			else
			{
				Link.l1 = "Pas encore, malheureusement.";
				Link.l1.go = "exit";
				Diag.TempNode = "CompanionTravel_ToSquadron_2";
				NPChar.DeckDialogNode = "CompanionTravel_ToSquadron_2";
			}
		break;

		//////////////////////////////    офицер-наместник <--


	        // COLONY BUILDING
		case "ColonyBuilding_Hovernor_1":
			dialog.Text = "C'est un honneur pour moi d'être le gouverneur de votre colonie !";
			Link.l1 = "Veillez à l'ordre et à la prospérité de la ville. Vous aurez beaucoup à surveiller. Je viendrai ici de temps en temps.";
			Link.l1.go = "ColonyBuilding_Hovernor_2";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

	        case "ColonyBuilding_Hovernor_2":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.ColonyBuilding.Hovernor = NPChar.id;
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			Diag.TempNode = "ColonyBuilding_Hovernor";

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "Caiman_townhall", "sit", "sit1");
			LAi_SetHuberType(NPChar);

			//PChar.quest.SetHovernorToColonyResidence.win_condition.l1 = "ExitFromLocation";
			//PChar.quest.SetHovernorToColonyResidence.win_condition.l1.location = PChar.location;
			//PChar.quest.SetHovernorToColonyResidence.win_condition = "SetHovernorToColonyResidence";

			DialogExit();
	        break;

		case "ColonyBuilding_Hovernor":
			if(PChar.ColonyBuilding.AutoPurchaseFirst == true && PChar.ColonyBuilding.Store.BuildingTime == false && PChar.ColonyBuilding.AutoPurchaseFirst.Disable != true)
			{
				dialog.Text = "Bonjour, capitaine. Un magasin a récemment ouvert dans notre colonie, et je veux vous parler de certains avantages de cet important bâtiment.";
				Link.l1 = "Continuez.";
				Link.l1.go = "ColonyBuilding_AutoStore_1";
				break;
			}

			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes de la colonie.";
			Link.l1.go = "ColonyBuilding_Hovernor_3";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "ColonyBuilding_Hovernor_4";
			Link.l3 = "J'ai décidé de voir ce que tu deviens, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "ColonyBuilding_Hovernor";
		break;

		case "ColonyBuilding_Hovernor_3":
			dialog.Text = "Hum... Quelles affaires voulez-vous connaître ?";
			Link.l1 = "Je m'intéresse à l'état de la colonie et à ses capacités financières.";
			Link.l1.go = "ColonyBuilding_Hovernor_3_1";
			Link.l2 = "Je m'intéresse à l'état de préparation de la garnison et à la santé des habitants.";
			Link.l2.go = "ColonyBuilding_Hovernor_3_2";
			Link.l3 = "Je veux renommer la colonie et revoir l'apparence des soldats.";
			Link.l3.go = "ColonyBuilding_Hovernor_3_3";
			Link.l4 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l4.go = "Exit";

		break;

		case "ColonyBuilding_AutoStore_1":
			PChar.ColonyBuilding.AutoPurchaseFirst.Disable = true;
			dialog.Text = "Avec un magasin en activité, vous pouvez assurer l'achat automatique des marchandises de première nécessité, afin que les citoyens de la colonie et la garnison qui la garde reçoivent à temps médicaments et vivres. Adressez-vous à notre marchand si cela vous intéresse.";
			Link.l1 = "Intéressant. Parlons d'autre chose.";
			Link.l1.go = "ColonyBuilding_Hovernor_3";
		break;

		case "ColonyBuilding_Hovernor_3_1":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColony();
		break;

		case "ColonyBuilding_Hovernor_3_2":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColonyLandGuard();
		break;

		case "ColonyBuilding_Hovernor_3_3":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColonyBuilding(true, false);
		break;

		case "ColonyBuilding_Hovernor_4":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "ColonyBuilding_Hovernor_5";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
		break;

		case "ColonyBuilding_Hovernor_5":
			PChar.ColonyBuilding.Hovernor = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			Diag.TempNode = "Hired";
		break;

		case "ColonyBuilding_Expidition_End":
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. Notre expédition vient de se terminer. On a trouvé sur l'île des terres très fertiles et, surtout, des gisements de minerai.";
			Link.l1 = "Hum, eh bien, c'est très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

		case "ColonyBuilding_Mines_End":
			PChar.ColonyBuilding.MineMessage = true;
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. La construction des mines est terminée. Il vous faut maintenant nommer un chef des mines. C'est avec lui que vous réglerez toutes les affaires liées à cette activité.";
			Link.l1 = "Hum, eh bien, c'est très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

		case "ColonyBuilding_Plantation_End":
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. La construction de la plantation est terminée. Il vous faut maintenant nommer un chef de la plantation. C'est avec lui que vous réglerez toutes les affaires liées à cette activité.";
			Link.l1 = "Hum, eh bien, c'est très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

        	// Начальник рудников
		case "MinesCommander_1":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes des mines.";
			Link.l1.go = "MinesCommander_2";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "MinesCommander_Remove";
			Link.l3 = "J'ai décidé de voir ce que tu deviens, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "MinesCommander_1";
		break;

		case "MinesCommander_2":
			Diag.TempNode = "MinesCommander_1";
			DialogExit();
			LaunchMines();
		break;

		case "MinesCommander_Remove":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "MinesCommander_Removed";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "MinesCommander_1";
		break;

		case "MinesCommander_Removed":
			PChar.Mines.Commander = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			Diag.TempNode = "Hired";
		break;

		case "MinesCommander_Hire":
			dialog.Text = "Bien. Je vais essayer de répondre à vos attentes.";
			Link.l1 = "Très bien. Remplissez vos fonctions.";
			Link.l1.go = "MinesCommander_Hired";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

		case "MinesCommander_Hired":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "Caiman_Mines_Comendant_House", "barmen", "stay");

			LAi_SetStayType(NPChar);
			PChar.Mines.Commander = NPChar.id;
			Diag.CurrentNode = "MinesCommander_1";
			Diag.TempNode = "MinesCommander_1";

			//PChar.quest.SetCommanderToMinesOffice.win_condition.l1 = "ExitFromLocation";
			//PChar.quest.SetCommanderToMinesOffice.win_condition.l1.location = PChar.location;
			//PChar.quest.SetCommanderToMinesOffice.win_condition = "SetCommanderToMinesOffice";

			DialogExit();
		break;

        	// Начальник плантации
		case "PlantationCommander_1":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes de la plantation.";
			Link.l1.go = "PlantationCommander_2";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "PlantationCommander_Remove";
			Link.l3 = "J'ai décidé de voir ce que vous devenez, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_2":
			DialogExit();
			LaunchPlantation();
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_Remove":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "PlantationCommander_Removed";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_Removed":
			PChar.Plantation.Commander = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			Diag.TempNode = "Hired";
		break;

		case "PlantationCommander_Hire":
			dialog.Text = "Bien. Je vais essayer de répondre à vos attentes.";
			Link.l1 = "Très bien. Remplissez vos fonctions.";
			Link.l1.go = "PlantationCommander_Hired";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

		case "PlantationCommander_Hired":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.Plantation.Commander = NPChar.id;
			Diag.CurrentNode = "PlantationCommander_1";
			Diag.TempNode = "PlantationCommander_1";

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "CaimanPlantationOffice", "goto", "goto1");
			LAi_SetStayType(NPChar);

			//PChar.quest.SetCommanderToPlantationOffice.win_condition.l1 = "ExitFromLocation";
			//PChar.quest.SetCommanderToPlantationOffice.win_condition.l1.location = PChar.location;
			//PChar.quest.SetCommanderToPlantationOffice.win_condition = "SetCommanderToPlantationOffice";

			DialogExit();
		break;

	        // Помошник по охране - начальник гарнизона
		case "ColonyGuarding_Hovernor_1":
			dialog.Text = "Hum... Je pense pouvoir m'acquitter de la tâche qui m'est confiée.";
			Link.l1 = "Bien sמr que vous le pourrez, sinon... euh... Vous pouvez commencer !";
			Link.l1.go = "ColonyGuarding_Hovernor_2";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

	        case "ColonyGuarding_Hovernor_2":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.Colony.Guardians.Hovernor = NPChar.id;

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "LandGuardingHeadHouse", "goto", "goto3");
			LAi_SetStayType(NPChar);

			Diag.CurrentNode = "ColonyGuarding_Hovernor";
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
	        break;

		case "ColonyGuarding_Hovernor":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître l'état actuel de la défense.";
			Link.l1.go = "ColonyGuarding_Hovernor_3";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "ColonyGuarding_Hovernor_4";
			Link.l3 = "Je veux parler du recrutement d'hommes pour la garnison qui garde notre colonie.";
			Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_1";
			Link.l4 = "J'ai décidé de voir ce que vous devenez, " + npchar.name + ".";
			Link.l4.go = "Exit";
			Diag.TempNode = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_3":
			dialog.Text = "Hum... Quelles affaires voulez-vous connaître ?";
			Link.l1 = "Je m'intéresse à la question du littoral.";
			Link.l1.go = "ColonyGuarding_Hovernor_3_1";
			Link.l2 = "Je m'intéresse à l'état de préparation de la garnison et à la santé des habitants.";
			Link.l2.go = "ColonyGuarding_Hovernor_3_2";
			Link.l3 = "Je m'intéresse à l'état de préparation de la garde cכtière.";
			Link.l3.go = "ColonyGuarding_Hovernor_3_3";
			Link.l4 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l4.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_3_1":
		    	CheckDeadColonyGuard();
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
			LaunchColonyGuardiang();
		break;

		case "ColonyGuarding_Hovernor_3_2":
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
			LaunchColonyLandGuard();
		break;

		case "ColonyGuarding_Hovernor_3_3":
			CheckDeadColonyGuard();

			if(GetColonyGuardsShipsQuantity() < 1)
			{
				dialog.Text = "Capitaine, il n'y a pas de navires dans l'escadre en ce moment...";
				Link.l1 = "Ah oui, j'oubliais...";
				Link.l1.go = "exit";
				PChar.Colony.Guardians.BaseComplete = false;
				break;
			}

			string sBaseComplete = "";

			if(PChar.Colony.Guardians.BaseComplete == true)
			{
				sBaseComplete = "les navires sont entièrement réapprovisionnés chaque semaine et toujours prêts au combat. Actuellement, la somme nécessaire pour cela est de " + GetCostForBaseCompletationAllGuards() + " piastres.";
			}
			else
			{
				sBaseComplete = "les navires cכtiers ne sont pas réapprovisionnés. Mais il est possible de les inspecter chaque semaine et de compléter leur armement et leur équipage, afin de pouvoir repousser les gredins à tout moment.";
			}

			dialog.Text = "Hum... Pour l'instant, " + sBaseComplete;

			if(PChar.Colony.Guardians.BaseComplete == true)
			{
				Link.l1 = "Je pense qu'il vaut mieux suspendre le réapprovisionnement hebdomadaire pour le moment. Le trésor n'est pas extensible...";
				Link.l1.go = "ColonyGuarding_Hovernor_3_3_3";
			}
			else
			{
				if(PChar.Colony.Guardians.BaseComplete.First == true)
				{
					Link.l1 = "Parlez-m'en davantage.";
					Link.l1.go = "ColonyGuarding_Hovernor_3_3_1";
				}
				else
				{
					Link.l1 = "Je pense qu'il est temps de reprendre l'entretien hebdomadaire de la garde cכtière.";
					Link.l1.go = "ColonyGuarding_Hovernor_3_3_2";
				}
			}

			Link.l2 = "Excusez-moi, des affaires m'attendent.";
			Link.l2.go = "Exit";
			Diag.CurrentNode = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_3_3_1":
			PChar.Colony.Guardians.BaseComplete.First = false;
			dialog.Text = "Chaque semaine, les navires de la garde cכtière seront inspectés : ceux qui la composent seront complétés en munitions et en matériel indispensable manquants, et leur équipage sera renforcé. Mais pour que tout cela fonctionne, il faudra engager certaines dépenses, qui dépendent des navires équipés. Par exemple, il faudra pour l'instant verser " + GetCostForBaseCompletationAllGuards() + " piastres par semaine, prises sur le trésor de la colonie. Si cette somme vient à manquer, alors, hélas, il n'y aura rien pour réapprovisionner les navires. Qu'en dites-vous ?";
			Link.l1 = "C'est une chose utile. J'autorise le versement régulier des fonds du trésor de la colonie.";
			Link.l1.go = "ColonyGuarding_Hovernor_3_3_2";
			Link.l2 = "Je crois que nous nous en passerons pour l'instant.";
			Link.l2.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_3_3_2":
			PChar.Colony.Guardians.BaseComplete = true;
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
		break;

		case "ColonyGuarding_Hovernor_3_3_3":
			PChar.Colony.Guardians.BaseComplete = false;
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
		break;

		case "ColonyGuarding_Hovernor_4":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "ColonyGuarding_Hovernor_5";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_5":
			PChar.Colony.Guardians.Hovernor = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			Diag.TempNode = "Hired";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_1":
			dialog.Text = "Très bien, capitaine. Que puis-je faire pour vous à ce sujet ?";
			Link.l1 = "J'aimerais en savoir plus sur cette possibilité.";
			Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Info";
			Link.l2 = "Je veux connaître le coמt de l'entretien du recrutement.";
			Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Costs";
			Link.l3 = "Il faut revoir la liste des sites pour lesquels le recrutement de la garnison est assuré.";
			Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Set";
			Link.l4 = "Non, j'ai changé d'avis.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Info":
			dialog.Text = "Je peux recruter moi-même des hommes pour la garnison, afin que notre colonie et ses installations puissent toujours repousser l'ennemi et mater les habitants et les esclaves rebelles. Mais, vous le comprenez bien, cela coמtera bien plus cher qu'un recrutement ordinaire dans les tavernes de l'archipel. א chaque fois, la garnison sera complétée selon la configuration actuelle des garnisons. La garnison peut être recrutée pour tous les sites : notre colonie, la plantation et les mines. א chaque fois, le trésor de la colonie doit contenir la somme permettant de recruter la garnison d'un site donné. Si cette somme n'est pas dans le trésor, le recrutement, bien entendu, n'aura pas lieu.";
			Link.l1 = "Merci pour l'information, " + npchar.name + ".";
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Costs":
			dialog.Text = "Pour quels sites souhaitez-vous connaître le coמt du recrutement ?";

			if(PChar.ColonyBuilding.Stage != "0")
			{
				Link.l1 = "La colonie.";
				Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Colony";
			}
			if(PChar.Mines.GoldMine == true || PChar.Mines.SilverMine == true || PChar.Mines.IronMine == true)
			{
				Link.l2 = "Les mines.";
				Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Mines";
			}
			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				Link.l3 = "La plantation.";
				Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Plantation";
			}

			Link.l4 = "Désolé, je dois y aller.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Colony":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison de la colonie, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Colony", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Colony", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Mines":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison des mines, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Mines", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Mines", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Plantation":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison de la plantation, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Plantation", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Plantation", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "D'accord.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Set":
			dialog.Text = ColonyGuardingAutoCrewHireGetWork();

			if(PChar.ColonyBuilding.Stage != "0")
			{
				if(PChar.Colony.Guardians.Colony.AutoCrewHire == false)
				{
					Link.l1 = "Je veux profiter de la possibilité de recruter une garnison pour protéger la colonie.";
					Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_1";
				}
				else
				{
					Link.l1 = "Je veux suspendre le recrutement de la garnison qui protège la colonie.";
					Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_1";
				}
			}

			if(PChar.Mines.GoldMine == true || PChar.Mines.SilverMine == true || PChar.Mines.IronMine == true)
			{
				if(PChar.Colony.Guardians.Mines.AutoCrewHire == false)
				{
					Link.l2 = "Je veux profiter de la possibilité de recruter une garnison pour protéger les mines.";
					Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_1";
				}
				else
				{
					Link.l2 = "Je veux suspendre le recrutement de la garnison qui protège les mines.";
					Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_1";
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.Colony.Guardians.Plantation.AutoCrewHire == false)
				{
					Link.l3 = "Je veux profiter de la possibilité de recruter une garnison pour protéger la plantation.";
					Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_1";
				}
				else
				{
					Link.l3 = "Je veux suspendre le recrutement de la garnison qui protège la plantation.";
					Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_1";
				}
			}

			Link.l4 = "Désolé, je dois y aller.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_2":
			PChar.Colony.Guardians.Colony.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_2":
			PChar.Colony.Guardians.Mines.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_2":
			PChar.Colony.Guardians.Plantation.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison de la colonie ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_2";
			link.l2 = LinkRandPhrase("Laissons cela !", "J'ai peut-être changé d'avis..", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_2":
			PChar.Colony.Guardians.Colony.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison des mines ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_2";
			link.l2 = LinkRandPhrase("Laissons cela !", "J'ai peut-être changé d'avis..", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_2":
			PChar.Colony.Guardians.Mines.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison de la plantation ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr..");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_2";
			link.l2 = LinkRandPhrase("Laissons cela !", "J'ai peut-être changé d'avis...", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_2":
			PChar.Colony.Guardians.Plantation.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;
		// <-- Самостоятельное плавание компаньона
		
		// секс - Мэри не отказывает никогда
		case "Mary_cabin_sex":
			dialog.text = RandPhraseSimple(""+pchar.name+", il n'y a pas de plus grande joie pour moi que d'être dans tes bras, oui... Allons-y !", ""+pchar.name+" – si c'était possible, je ne te quitterais pas d'une minute. Allons-y !");
			link.l1 = RandPhraseSimple("Tu es la meilleure du monde, ma fille...", "Tu es tout simplement adorable, ma beauté...");
			link.l1.go = "Mary_cabin_sex_go";
		break;
		
		case "Mary_room_sex":
			dialog.text = RandPhraseSimple(""+pchar.name+", il n'y a pas de plus grande joie pour moi que d'être dans tes bras, oui... Allons-y !", ""+pchar.name+" – si c'était possible, je ne te quitterais pas d'une minute. Allons-y !");
			link.l1 = RandPhraseSimple("Tu es la meilleure du monde, ma fille...", "Tu es tout simplement adorable, ma beauté...");
			link.l1.go = "Mary_room_sex_go";
		break;
		
		case "Mary_cabin_sex_go":
			DialogExit();
			chrDisableReloadToLocation = true;//закрыть локацию
			AddCharacterExpToSkill(pchar, "Leadership", 40);
            AddCharacterExpToSkill(npchar, "Leadership", 40);
            AddCharacterExpToSkill(pchar, "Fencing", 15);
            AddCharacterExpToSkill(npchar, "Fencing", 15);
            AddCharacterExpToSkill(pchar, "Pistol", 15);
            AddCharacterExpToSkill(npchar, "Pistol", 15);
            AddCharacterHealth(pchar, 12);
            AddCharacterHealth(npchar, 12);
			LAi_SetCurHPMax(pchar);
			LAi_SetCurHPMax(npchar);
   			AddDialogExitQuest("PlaySex_1");
			NextDiag.CurrentNode = "Mary_sex_after";
		break;
		
		case "Mary_room_sex_go":
			DialogExit();
			chrDisableReloadToLocation = true;//закрыть локацию
			AddCharacterExpToSkill(pchar, "Leadership", 40);
            AddCharacterExpToSkill(npchar, "Leadership", 40);
            AddCharacterExpToSkill(pchar, "Fencing", 15);
            AddCharacterExpToSkill(npchar, "Fencing", 15);
            AddCharacterExpToSkill(pchar, "Pistol", 15);
            AddCharacterExpToSkill(npchar, "Pistol", 15);
			AddCharacterHealth(pchar, 12);
            AddCharacterHealth(npchar, 12);
			LAi_SetCurHPMax(pchar);
			LAi_SetCurHPMax(npchar);
			if (sti(pchar.money) >= 10) AddMoneyToCharacter(pchar, -10);
			if (npchar.chr_ai.type == "actor")
			{
				LAi_SetOfficerType(npchar);
				LAi_group_MoveCharacter(npchar, LAI_GROUP_PLAYER);
			}
			if (findsubstr(locations[FindLocation(pchar.location)].id, "tavern_upstairs" , 0) == -1)
			{
			DoQuestReloadToLocation(pchar.location+"_upstairs", "quest", "quest4", "");
			ChangeCharacterAddressGroup(npchar, pchar.location+"_upstairs", "quest", "quest3");
			}
			DoQuestCheckDelay("PlaySex_1", 2.1);
			NextDiag.CurrentNode = "Mary_sex_after";
		break;
		
		case "Mary_sex_after":
			dialog.text = RandPhraseSimple("Mon chéri, tu as été formidable, comme toujours !", "Tout était tout simplement merveilleux, mon chéri !");
			link.l1 = RandPhraseSimple("Je suis heureux que tu sois comblée, lumière de mon âme...", "Je t'adore, Mary...");
			link.l1.go = "exit";
			sld = characterFromID("SharleMary");
			sld.Dialog.Filename = "Quest\MainheroPrologues\Mary_dialog.c";
			sld.dialog.currentnode = "hired";
			LAi_SetOfficerType(sld);
			chrDisableReloadToLocation = false;//открыть локацию
			npchar.quest.daily_sex = true;
			SetFunctionTimerCondition("Mary_SexReady", 0, 0, 5, false);
		break;
		
		case "Mary_givemesex":	// требует секса, если давно не давал
			dialog.text = RandPhraseSimple(""+pchar.name+", ça fait si longtemps qu'on n'a pas été ensemble... Tu m'as complètement oubliée, oui ! Mon chéri, j'ai envie de me détendre : louons une chambre et filons !", ""+pchar.name+", tu t'es complètement plongé dans les affaires, et je commence à soupçonner que tu m'as complètement oubliée ! Mon chéri, j'ai vraiment envie... d'être seule avec toi. Louons une chambre, oui !");
			link.l1 = "Mary, ma chérie, qu'est-ce que tu racontes, « tu m'as oubliée » ? Quelle bêtise... Mais c'est vrai que je suis débordé par tous ces problèmes, ils n'en finissent pas. Pardonne-moi, ma fille. Bien sמr, montons, et que le monde entier attende !";
			link.l1.go = "Mary_room_sex_go";
		break;
		
		// ругается за то, что ходил по борделям, ГГ изворачивается
		case "Mary_brothel":
			dialog.text = "Oui, ce n'est pas ça ! Je ne te plais plus, c'est ça ? Dis-le-moi !";
			link.l1 = "En voilà une autre ! Mary, qu'est-ce que c'est que ces bêtises ? Qu'est-ce qui te fait croire ça ?";
			link.l1.go = "Mary_brothel_1";
		break;
		
		case "Mary_brothel_1":
			dialog.text = "Alors pourquoi es-tu allé voir ces garces, ces filles de bordel ? Je le sais, oui, ne nie pas ! Je ne te suffis pas quand on fait l'amour, c'est ça ? (en pleurant) Dis-le-moi...";
			link.l1 = "Mary, Mary... Calme-toi, je t'en prie, ma fille. Oui, je suis allé au bordel, mais seulement pour affaires. Tu vois, pour affaires, pas pour m'amuser !";
			link.l1.go = "Mary_brothel_2";
		break;
		
		case "Mary_brothel_2":
			dialog.text = "Et dans la chambre des catins aussi, tu es monté « pour affaires », hein ? (en sanglotant) Tu me mens, "+pchar.name+" !";
			link.l1 = "Mary, ma chérie, arrête enfin... J'avais vraiment affaire avec la tenancière du bordel. Et je suis aussi monté à l'étage... Tiens, la dernière fois, à la demande personnelle du gouverneur, qui m'avait prié d'y retrouver son alliance perdue. Comment aurais-je pu refuser à Sa Seigneurie ?";
			link.l1.go = "Mary_brothel_5";
		break;
		
		case "Mary_brothel_5":
			dialog.text = "";
			link.l1 = "Tu vois ? Je te le dis, ce sont des visites d'affaires. Mary, je n'ai vraiment besoin de personne d'autre que toi. Tu es la meilleure, honnêtement ! Tu crois vraiment que je vais aller voir de sales catins du port quand je t'ai, toi ? Comment as-tu pu imaginer une chose pareille ?";
			link.l1.go = "Mary_brothel_6";
		break;
		
		case "Mary_brothel_6":
			dialog.text = ""+pchar.name+"... C'est vraiment vrai ? Tu ne mens pas ? Tu n'étais pas avec elles ?";
			link.l1 = "Mary, ma chérie, il n'y a personne d'autre que toi pour moi, vraiment. Approche, ma chère. Laisse-moi te serrer dans mes bras... Essuie tes larmes, et arrête enfin d'être jalouse ! Bon, si tu veux, je n'irai plus dans les bordels !";
			link.l1.go = "Mary_brothel_7";
		break;
		
		case "Mary_brothel_7":
			dialog.text = "Oui, je veux !.. "+pchar.name+", je suis jalouse parce que je t'aime... Et je ne veux pas te perdre, oui ! Tu entends ? Je tuerai n'importe quelle traînée qui osera t'approcher !";
			link.l1 = "Chut, chut... ma petite maîtresse. Tu n'auras besoin de tuer personne. Et tu ne me perdras pas, je te le promets. Voilà, calme-toi. Tu es la seule et la meilleure au monde...";
			link.l1.go = "Mary_brothel_8";
		break;
		
		case "Mary_brothel_8":
			DialogExit();
			SetLaunchFrameFormParam("Quelques minutes ont passé", "", 0, 5);
			LaunchFrameForm();
			pchar.GenQuest.BrothelLock = true; // всё, больше не походишь по борделям :)
			DeleteAttribute(pchar, "GenQuest.BrothelCount");
		break;
	}
}

void FireImmortalOfficer(ref chr)
{
	if (CheckAttribute(chr, "ImmortalOfficer"))
	{
		DeleteAttribute(chr, "ImmortalOfficer")
		pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) - 1);
	}
}
