# -*- coding: utf-8 -*-
"""Render sample French text with fonts_fra.ini (approximation of the engine's renderer)."""
import os
import sys
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fontini import FontIni          # noqa: E402
from txtex import read_tx            # noqa: E402
from frenc import to_game            # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SAMPLES = [
    "Où êtes-vous, capitaine ? À bord ! Ça, c'est l'État.",
    "Élevé, naïve, Noël, cœur, Œuvre, maître, sûr, août, île",
    "« Écoutez » ÉTÉ ÎLE ÊTRE ÀÇÈÉÊËÎÏÔÖÙÛÜŒ àâäçéèêëîïôöùûüœ",
]


def render(ini_path, out_dir, sections=None, scale=1.0):
    ini = FontIni(ini_path)
    cache = {}
    for name, sec in ini.sections.items():
        if sections and name not in sections:
            continue
        tex = sec.prop('texture')
        p = os.path.join(ROOT, 'RESOURCE', 'Textures', tex.replace('\\', os.sep) + '.tx')
        if not os.path.exists(p) or ('a' not in sec.chars and 'A' not in sec.chars):
            continue
        if p not in cache:
            cache[p] = read_tx(p)
        t = cache[p]
        rgba = t['rgba']
        sx = t['w'] / float(sec.prop('texture_xsize'))
        sy = t['h'] / float(sec.prop('texture_ysize'))
        lh = int(float(sec.prop('height', '30')) * sy) + 6
        space = float(sec.prop('spacebar', '8') or 8)
        interval = float(sec.prop('symbol_interval', '1') or 1)
        lines = []
        for s in SAMPLES:
            s = to_game(s)
            x = 4.0
            glyphs = []
            for c in s:
                if c == ' ':
                    x += space * sx
                    continue
                if c not in sec.chars:
                    glyphs.append((None, x)); x += 8 * sx
                    continue
                gx, gy, gw, gh = sec.chars[c]
                X0, Y0 = int(round(gx * sx)), int(round(gy * sy))
                X1, Y1 = int(round((gx + gw) * sx)), int(round((gy + gh) * sy))
                glyphs.append((rgba[Y0:Y1, X0:X1], x))
                x += gw * sx + interval * sx
            lines.append((glyphs, int(x) + 8))
        W = max(w for _, w in lines)
        H = lh * len(lines) + 8
        img = Image.new('RGBA', (W, H), (30, 30, 45, 255))
        for i, (glyphs, _) in enumerate(lines):
            for g, x in glyphs:
                if g is None:
                    for yy in range(4, lh - 8):
                        img.putpixel((int(x) + 2, i * lh + yy), (255, 0, 0, 255))
                    continue
                gi = Image.fromarray(np.ascontiguousarray(g), 'RGBA')
                img.alpha_composite(gi, (int(x), i * lh + 4))
        if scale != 1.0:
            img = img.resize((int(W * scale), int(H * scale)), Image.LANCZOS)
        img.convert('RGB').save(os.path.join(out_dir, 'prev_%s.png' % name))
        print('ok', name, W, H)


if __name__ == '__main__':
    out = sys.argv[1]
    secs = sys.argv[2].split(',') if len(sys.argv) > 2 and sys.argv[2] else None
    render(os.path.join(ROOT, 'RESOURCE', 'INI', 'fonts_fra.ini'), out, secs,
           float(sys.argv[3]) if len(sys.argv) > 3 else 1.0)
