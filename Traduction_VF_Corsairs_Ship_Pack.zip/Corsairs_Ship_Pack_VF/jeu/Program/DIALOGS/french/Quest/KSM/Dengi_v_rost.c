
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sBlade;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "simon_helper_bazar":
			dialog.text = "Joins-toi à nous, capitaine ! Simon le Fou paie la tournée, il suffit d'entrer un peu dans son jeu si tu veux boire.";
			link.l1 = "Bien sמr que je me joins à vous. Lequel d'entre vous est Simon ?";
			link.l1.go = "1";
		break;

		case "1":
			dialog.text = "Celui-là, avec le chapeau.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "Exit";
			NextDiag.TempNode = "simon_helper_bazar";
		break;

		case "simon_bazar":
			dialog.text = "Oh, un néophyte ! Tu es venu t'incliner devant le Maître des mers ?";
			link.l1 = "Pas vraiment. Je suis venu parler de l'argent que tu as emprunté à...";
			link.l1.go = "6";
		break;

		case "6":
			int KSM_DVR_Schitaem2 = pchar.Quest.KSM_DVR_Dengi.FindCitizenMoney;
			if(KSM_DVR_Schitaem2 < 10000) { KSM_DVR_Schitaem2 = 10000 + drand2(1000); }
			if(KSM_DVR_Schitaem2 > 30000) { KSM_DVR_Schitaem2 = 30000 + drand2(1000); }
			dialog.text = "Le maître des mers n'a pas besoin d'argent ! Tu ferais mieux de boire avec nous et de ME louer comme il faut !";
			link.l1 = "Simon, tu as emprunté " + KSM_DVR_Schitaem2 + " piastres à un usurier, tu ferais mieux de t'en souvenir...";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Tu me fatigues, mouche agaçante. Il est temps pour toi de mourir... Les gars, envoyez "+GetSexPhrase("ce gêneur au cimetière", "cette gêneuse au cimetière")+" !";
			link.l1 = "Bon sang !";
			link.l1.go = "Draka";
		break;

		case "Draka":
			DialogExit();
			LAi_SetFightMode(pchar, true);
			sld = CharacterFromID("KSM_DVR_Saiman");
			LAi_SetActorType(sld);
			for (i=1; i<=3; i++)									//Количество
			{
				sld = CharacterFromID("KSM_DVR_SaimanOhrana_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
				LAi_SetImmortal(sld, false);
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "KSM_DVR_Pobeda");

			chrDisableReloadToLocation = true;
		break;

		case "dolg_bazar_1":
			dialog.text = "Merci, capitaine "+pchar.name+".";
			link.l1 = "Pourquoi diable as-tu tué cet hurluberlu ?";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Une balle, c'est le meilleur remède contre la folie, capitaine. Et puis... Ne méritait-il pas de mourir, après avoir ordonné qu'on te tue ?";
			link.l1 = "Peut-être... Bon, puisque Simon est mort grâce à tes efforts, tu peux voir combien d'argent il nous a laissé.";
			link.l1.go = "Smotrim";
		break;

		case "Smotrim":
			DialogExit();
			LAi_Fade("", "");
			sld = CharacterFromID("Villemstad_usurer");
			LAi_SetActorType(sld);
			DoQuestCheckDelay("KSM_DVR_Smotrim_2", 0.5);
		break;

		case "dolg_bazar_2":
			int KSM_DVR_Dengi = sti(pchar.Quest.KSM_DVR_Dengi.FindCitizenMoney);
			int KSM_DVR_Nashli = KSM_DVR_Dengi - (KSM_DVR_Dengi / 4);
			dialog.text = "Formidable ! Il y a plus de " + KSM_DVR_Nashli + " piastres !";
			link.l1 = "Et combien m'en reviennent ?";
			link.l1.go = "9";
		break;

		case "9":
			int KSM_DVR_Dengi2 = pchar.Quest.KSM_DVR_Dengi.FindCitizenMoney;
			int KSM_DVR_Nashli2 = KSM_DVR_Dengi2 - (KSM_DVR_Dengi2 / 4);
			int KSM_DVR_Nagrada = KSM_DVR_Nashli2 / 2;
			dialog.text = "" + KSM_DVR_Nagrada + " piastres, capitaine. Prends-les, elles sont à toi.";
			link.l1 = "Merci.";
			link.l1.go = "Konets";
			AddMoneyToCharacter(pchar, sti(KSM_DVR_Nagrada));
			AddCharacterExpToSkill(pchar, "Leadership", 100);
		break;

		case "Konets":
			DialogExit();
			LAi_SetActorType(npchar);
			LAi_ActorRunToLocation(npchar, "reload", "reload1", "none", "", "", "OpenTheDoors", -1);

			AddQuestRecord("KSM_DVR", "2");
			CloseQuestHeader("KSM_DVR");
			pchar.questdata.DengiRost = 1;
			DeleteAttribute(pchar, "Quest.KSM_DVR_Dengi");

			PChar.quest.KSM_DVR_RostovshikDomoy.win_condition.l1 = "ExitFromLocation";
			PChar.quest.KSM_DVR_RostovshikDomoy.win_condition.l1.location = PChar.location;
			PChar.quest.KSM_DVR_RostovshikDomoy.win_condition = "KSM_DVR_RostovshikDomoy";
		break;
	}
}
