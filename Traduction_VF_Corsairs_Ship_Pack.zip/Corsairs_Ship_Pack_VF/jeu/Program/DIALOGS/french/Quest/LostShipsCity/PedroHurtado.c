#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);//homo 25/06/06

	string NodeName = Dialog.CurrentNode;
	string NodePrevName = "";
	if (CheckAttribute(NextDiag, "PrevNode")) NodePrevName = NextDiag.PrevNode;

	switch(Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			if (npchar.quest.meeting == "0")
			{
				npchar.quest.meeting = "1";
				if (CheckAttribute(loadedLocation, "storm"))
				{
					dialog.text = "Ah, alors c'est toi qui as survécu à la tempête ? Eh bien, parfait ! Faisons connaissance. Je m'appelle " + GetFullName(npchar) + ", et toi ?";
					link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FS_1";
				}
				else
				{
					dialog.text = "Ah, alors tu fais partie des derniers arrivés ? Je vois... Eh bien, faisons connaissance. Je m'appelle " + GetFullName(npchar) + ", et toi ?";
					link.l1 = "Je m'appelle " + GetFullName(pchar) + ".";
					link.l1.go = "FT_1";
				}
			}
			else
			{
				//квест проникновения в дом хозяина магазина
				if (pchar.questTemp.LSC != "AdmiralIsWaiting" && !CheckAttribute(npchar, "quest.store"))
				{
					dialog.text = ""+ GetSexPhrase("L'ami","Ma belle") +", tu voudrais faire une petite affaire ?";
					link.l1 = "Dis-moi de quelle affaire il s'agit.";
					link.l1.go = "StBegin_1";
					break;
				}
				// <-- квесты
				dialog.text = "Tu voulais quelque chose ?";
				link.l1 = "וcoutez, je cherche quelqu'un. Vous savez oם il est en ce moment ?";
				link.l1.go = "SeekCitizen";
				link.l2 = "Je voudrais vous poser une question.";
				link.l2.go = "int_quests";
				link.l3 = LinkRandPhrase("Vous pouvez me raconter quelque chose d'intéressant ?",
					"Quoi de neuf dans la Cité ?", "Eh, j'écouterais bien les derniers potins...");
				link.l3.go = "rumours_LSC";
				if (CheckAttribute(npchar, "quest.store") && npchar.quest.store == "waiting" && npchar.chr_ai.type == LAI_TYPE_STAY)
				{
					link.l4 = "Bon, allons-y, franchissons cette terrible porte.";
					link.l4.go = "StStart_1";
				}
				if (pchar.questTemp.LSC == "toSeekGoods")
				{
					link.l8 = "וcoute, je cherche certaines marchandises.";
					link.l8.go = "SeekGoods";
				}
				if (pchar.questTemp.LSC == "toSeekPeopleInCrew")
				{
					link.l8 = "Tu sais, je recrute un équipage pour partir d'ici. Je te propose de venir avec moi comme matelot.";
					link.l8.go = "SeekCrew";
				}
				link.l10 = "Rien...";
				link.l10.go = "exit";
			}
		break;

		case "FS_1":
			dialog.text = "Enchanté. Ne fais pas attention à la tempête, elle va bientכt finir. Les gens d'ici sont solidaires, alors deviens citoyen "+ GetSexPhrase("","ne") +" de la Cité, et tout ira bien. En somme, bienvenue dans la Cité !";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;
		case "FT_1":
			dialog.text = "Enchanté. Bon, habitue-toi un peu. Les gens d'ici vivent en assez bonne entente, alors bienvenue dans la Cité, comme on dit...";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//обнаружение ГГ в сундуках
		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Au voleur !!! Violation de la Loi de la Cité !", "דa alors ! J'ai à peine tourné les yeux que te voilà la tête la première dans le coffre ! Tu as enfreint la Loi !", "Police ! Au vol !!! Attrapez "+ GetSexPhrase("son","sa") +" !");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
		break;
		case "Woman_FackYou":
			dialog.text = "Ah, c'est comme ça ?! Vous allez fouiller les coffres ?! Maintenant, les citoyens et la police vont vous mettre en pièces comme un vieux chiffon !";
			link.l1 = "Quel imbécile !..";
			link.l1.go = "exit_setOwner";
			LAi_group_Attack(NPChar, Pchar);
		break;
		//замечение по обнажённому оружию
		case "LSCNotBlade":
			dialog.text = LinkRandPhrase("וcoutez, vous devriez ranger votre arme. דa me rend un peu nerveux...", "Vous savez, ici, ce n'est pas l'usage d'agiter un sabre. Rangez votre arme.", "Dites donc, vous vous prenez pour les trois mousquetaires, à courir partout en agitant votre épée ? Rangez votre arme, ça ne convient pas "+ GetSexPhrase("à un homme sérieux","à une jeune fille") +"...");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;
		case "CitizenNotBlade":
			if (loadedLocation.type == "town")
			{
				dialog.text = NPCharSexPhrase(NPChar, "וcoutez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.", "Vous savez, en tant que citoyen de cette ville, je vous demande de ne pas vous promener ici l'arme au clair.");
				link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			}
			else
			{
				dialog.text = NPCharSexPhrase(NPChar, "Attention dans les virages, "+ GetSexPhrase("l'ami","ma petite") +", quand vous courez une arme à la main. Je pourrais m'énerver...", "Je n'aime pas quand "+ GetSexPhrase("des hommes","des gens") +" se promènent devant moi l'arme au poing. דa me fait peur...");
				link.l1 = RandPhraseSimple("Compris.", "Je la range.");
			}
			link.l1.go = "exit";
			NextDiag.TempNode = "First Time";
		break;


		//ищем человека
		case "SeekCitizen":
			dialog.text = "Qui cherchez-vous ?";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;
		case "SeekCitizen_Choice_1":
			sld = CheckLSCCitizen();
			if (sld.id == "none")
			{
				dialog.text = "Je ne comprends pas de qui vous parlez. J'ai besoin de connaître le prénom et le nom de cette personne.";
				Link.l1 = "Je vois. Laissez-moi essayer de vous redonner son nom.";
				Link.l1.go = "SeekCitizen_Choice_2";
				Link.l2 = "Merci, je préfère le chercher moi-même.";
				Link.l2.go = "exit";
			}
			else
			{
				if (sld.id == npchar.id)
				{
					dialog.text = "Mais c'est moi !";
					link.l1 = "דa alors, c'est bien vous !";
					link.l1.go = "exit";
					break;
				}
				if (sld.sex == "man")
				{
					dialog.text = GetFullName(sld) + "vous parlez de lui ?";
					Link.l1 = "Oui, oui, c'est bien ça, c'est lui.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas de lui. Laissez-moi vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				else
				{
					dialog.text = GetFullName(sld) + "vous parlez d'elle ?";
					Link.l1 = "Oui, c'est d'elle qu'il s'agit.";
					Link.l1.go = "SeekCitizen_agree";
					Link.l2 = "Non, pas d'elle. וcoutez, laissez-moi essayer de vous redonner son nom.";
					Link.l2.go = "SeekCitizen_Choice_2";
				}
				Link.l3 = "Vous savez, je ne veux me renseigner sur personne d'autre. Au revoir.";
				Link.l3.go = "exit";
				npchar.quest.seekIdx = sld.index;
			}
		break;
        case "SeekCitizen_Choice_2":
			dialog.text = "Alors redites-moi son prénom et son nom.";
			Link.l1.edit = 3;
			Link.l1 = "";
			Link.l1.go = "SeekCitizen_Choice_1";
		break;

		case "SeekCitizen_agree":
			sld = &characters[sti(npchar.quest.seekIdx)];
			npchar.quest.seekIdx.where = WhereLSCCitizen(sld);
			if (npchar.quest.seekIdx.where == "none")
			{
				if (sld.sex == "man")
				{
					dialog.text = LinkRandPhrase("Je ne sais pas, je ne l'ai pas vu depuis longtemps.", "Le diable seul sait oם il est...", "Je ne l'ai pas vraiment vu, alors je ne sais pas.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = LinkRandPhrase("Je ne l'ai pas vue depuis un bon moment, désolé.", "Je n'ai aucune idée de l'endroit oם elle est en ce moment.", "Hum, je ne sais pas oם elle pourrait être en ce moment.");
					link.l1 = RandPhraseSimple("Je vois.", "Désolé...");
					link.l1.go = "exit";
				}
			}
			else
			{
				if (sld.sex == "man")
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str1 = npchar.location.locator;
						string Str2 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str1, 0, 5) == strcut(Str2, 0, 5))
						{
							dialog.text = LinkRandPhrase("Il est ici, sur ce navire. Regardez bien.", "Ha, mais il est ici, sur ce navire !", "Il est sur ce navire, c'est étrange que vous ne l'ayez pas encore vu.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Il est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais il est ici, parmi nous !", "Oם regardez-vous ? Il traîne par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vu tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisé récemment, " + npchar.quest.seekIdx.where + ". Cherchez-le donc là-bas.", "א ce que je sais, il est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
				else
				{
					if (sld.location == "LostShipsCity_town")
					{
						string Str3 = npchar.location.locator;
						string Str4 = sld.location.locator;
						if (npchar.location == sld.location && strcut(Str3, 0, 5) == strcut(Str4, 0, 5))
						{
							dialog.text = LinkRandPhrase("Elle est ici, sur ce navire. Regardez bien.", "Ha, mais elle est ici, sur ce navire !", "Elle est sur ce navire, c'est étrange que vous ne l'ayez pas encore vue.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					else
					{
						if (npchar.location == sld.location)
						{
							dialog.text = LinkRandPhrase("Elle est donc ici, " + npchar.quest.seekIdx.where + ". Regardez bien.", "Mais elle est ici, parmi nous !", "Oם regardez-vous ? Elle se promène quelque part par ici.");
						}
						else
						{
							dialog.text = LinkRandPhrase("Je l'ai vue tout récemment, " + npchar.quest.seekIdx.where + ".", "Je l'ai croisée récemment, " + npchar.quest.seekIdx.where + ". Nous avons même parlé, elle et moi.", "א ce que je sais, elle est maintenant " + npchar.quest.seekIdx.where + ".");
						}
					}
					link.l1 = RandPhraseSimple("Oui, je vois. Merci, l'ami.", "Merci !");
					link.l1.go = "exit";
				}
			}
		break;
		//вопросы
		case "int_quests":
			dialog.text = "Je t'écoute. Demande tout ce que tu veux.";
			if (!CheckAttribute(NextDiag, NodeName+".l5"))
			{
				link.l5 = "Maudite tempête ! Vous en avez souvent, des comme ça ?";
				link.l5.go = "ansewer_5";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l1"))
			{
				link.l1 = "Quelle est cette île ?";
				link.l1.go = "ansewer_1";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l2"))
			{
				link.l2 = "Qu'y a-t-il de remarquable dans la Cité ?";
				link.l2.go = "ansewer_2";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l3"))
			{
				link.l3 = "Et toi, comment es-tu arrivé ici ?";
				link.l3.go = "ansewer_3";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l4"))
			{
				link.l4 = "J'ai entendu parler plus d'une fois, sur le continent, d'une טle de la Justice. Ce ne serait pas votre Cité, par hasard ?";
				link.l4.go = "ansewer_4";
			}
			if (!CheckAttribute(NextDiag, NodeName+".l6") && pchar.questTemp.LSC == "toSeekOldCitizen")
			{
				link.l6 = "וcoute, tu vis dans la Cité depuis longtemps ?";
				link.l6.go = "ansewer_6";
			}
			link.l10 = "Pas de questions. Désolé, l'ami...";
			link.l10.go = "exit";
		break;
		case "ansewer_5":
			dialog.text = "דa arrive, bien sמr... Au fait, il faut que tu ailles voir l'amiral Chad Capper, si tu ne l'as pas encore fait.";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l5 = true;
		break;
		case "ansewer_1":
			dialog.text = "C'est la Cité des navires abandonnés, "+ GetSexPhrase("l'ami","" + pchar.name + "") +". Ici vivent tous ceux qui ont réussi à réchapper des naufrages. Toi aussi, maintenant.";
			link.l1 = "Oui, moi aussi, maintenant... Dis-moi, pourquoi ça arrive ici ? Il y a une explication à tous ces naufrages ?";
			link.l1.go = "ansewer_1_1";
			NextDiag.(NodePrevName).l1 = true;
		break;
		case "ansewer_1_1":
			dialog.text = "Personne n'en sait rien avec certitude. Les navires semblent heurter les récifs. Disons qu'ils sont portés vers les récifs par le courant... Mais ce n'est qu'une supposition. Personne n'en sait rien avec certitude.";
			link.l1 = "Et personne n'a essayé de savoir ?";
			link.l1.go = "ansewer_1_2";
		break;
		case "ansewer_1_2":
			dialog.text = "On a essayé, bien sמr. Seulement, c'est une mauvaise idée : les plus curieux meurent. Alors je ne te conseille pas d'être trop pressé non plus. Soit tu meurs, soit tu perds la boule...";
			link.l1 = "Oui, drכles de perspectives...";
			link.l1.go = "ansewer_1_3";
		break;
		case "ansewer_1_3":
			dialog.text = "Puisque tu as échoué ici, accepte ton sort et vis comme tout le monde. Voilà mon conseil.";
			link.l1 = "Eh bien, merci pour le conseil.";
			link.l1.go = "int_quests";
		break;
		case "ansewer_2":
			dialog.text = "D'abord, il faut que tu ailles voir l'amiral de la Cité au plus vite, si ce n'est pas encore fait. Ensuite, tu peux visiter la taverne et la boutique. Il y a aussi une église.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l2 = true;
		break;
		case "ansewer_3":
			dialog.text = "Oui, comme tout le monde : par un naufrage"+ GetSexPhrase(", l'ami","") +"...";
			link.l1 = "Compris.";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l3 = true;
		break;
		case "ansewer_4":
			dialog.text = "Je n'en sais rien... En somme, "+ GetSexPhrase("l'ami","" + pchar.name + "") +", c'est ta Cité maintenant, pas seulement la nכtre.";
			link.l1 = "Ha, voilà qui est bien !";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l4 = true;
		break;
		case "ansewer_6":
			dialog.text = "Un an et demi, pas plus.";
			link.l1 = "Je vois...";
			link.l1.go = "int_quests";
			NextDiag.(NodePrevName).l6 = true;
		break;
		//квест проникновения в кабинет хозяина магазина
		case "StBegin_1":
			dialog.text = "Il y a ici un endroit oם il y a beaucoup d'argent...";
			link.l1 = "Et alors ?";
			link.l1.go = "StBegin_2";
		break;
		case "StBegin_2":
			dialog.text = "Je te propose d'y aller et de le ramasser. Ensuite, on partagera les gains en deux.";
			link.l1 = "En principe, je ne suis pas contre. Et oם est cet endroit ?";
			link.l1.go = "StBegin_3";
		break;
		case "StBegin_3":
			dialog.text = "Sur le galion « Esmeralda ». C'est là que se trouve la boutique, mais dans l'autre moitié du navire. Si on y va l'après-midi, on ne trouvera pas le propriétaire de la boutique, Eric Yost, et moi, je peux ouvrir la porte.";
			link.l1 = "Si le propriétaire de la boutique n'est pas là et que tu peux ouvrir la porte, pourquoi m'appelles-tu ? Tu perds la moitié de l'argent.";
			link.l1.go = "StBegin_4";
		break;
		case "StBegin_4":
			dialog.text = "Eh bien, ce n'est pas si simple. Eric a engagé trois gros bras, ils vivent là-bas en permanence. Je ne peux pas m'en charger seul, mais toi, tu le peux.";
			link.l1 = "Héhé, maintenant, c'est clair...";
			link.l1.go = "StBegin_5";
		break;
		case "StBegin_5":
			dialog.text = "Alors, tu acceptes ?";
			link.l1 = "Eh bien, on peut essayer. Faisons cette affaire, l'argent me sera utile.";
			link.l1.go = "StBegin_6";
			link.l2 = "Non, ça ne m'intéresse pas. Voler, tu sais...";
			link.l2.go = "StBegin_not";
		break;
		case "StBegin_not":
			dialog.text = "Eh bien, comme tu veux, "+ GetSexPhrase("l'ami","ma petite") +"...";
			link.l1 = "Oui, au revoir.";
			link.l1.go = "exit";
			npchar.quest.store = "over";
		break;
		case "StBegin_6":
			dialog.text = "Parfait ! Alors, mettons-nous d'accord. Tu vaques à tes affaires pour l'instant, et dès que tu le pourras, va sur l'Esmeralda ; l'après-midi, je t'attendrai là-bas sur le gaillard d'arrière, à cכté de la porte au-dessus de laquelle est clouée une tête de mort. On verra bien ce qu'il en est...";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
			pchar.quest.LCS_SetPedroHurtado.win_condition.l1 = "ExitFromLocation";
			pchar.quest.LCS_SetPedroHurtado.win_condition.l1.location = pchar.location;
			pchar.quest.LCS_SetPedroHurtado.function = "LCS_SetPedroHurtado";
			npchar.quest.store = "waiting";
			AddQuestRecord("ISS_takeStoreMoney", "1");
		break;
		case "StStart_1":
			dialog.text = "Parfait ! Alors, j'ouvre ?";
			link.l1 = "Oui, ouvre.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("LSC_PedroRunOpenDoor");
		break;
		case "StStart_Opened":
			dialog.text = "La porte est ouverte, tu peux passer.";
			link.l1 = "Parfait ! Et toi, que vas-tu faire ?";
			link.l1.go = "StStart_3";
		break;
		case "StStart_3":
			dialog.text = "Je vais t'attendre ici, dehors.";
			link.l1 = "D'accord, attends.";
			link.l1.go = "exit";
			NextDiag.TempNode = "StResult";
			npchar.quest.store.money = pchar.money;
			AddQuestRecord("ISS_takeStoreMoney", "2");
			AddQuestUserData("ISS_takeStoreMoney", "sSex", GetSexPhrase("", "e"));
			AddDialogExitQuestFunction("LSC_PedroGoWaiting");
		break;
		case "StResult":
			dialog.text = "Alors, "+ GetSexPhrase("l'ami","ma petite") +", le travail est fait, à ce que je vois ?";
			link.l1 = "Oui, tout va bien, j'ai tué les trois gardes.";
			link.l1.go = "StResult_1";
		break;
		case "StResult_1":
			dialog.text = "Bon, je ne m'attendais pas à autre chose. Tu "+ GetSexPhrase("es un bon guerrier","sais te battre") +" et ça se voit au premier coup d'œil... Et maintenant, partageons le butin.";
			if (sti(pchar.money) <= sti(npchar.quest.store.money))
			{
				link.l1 = "וcoute, je n'ai rien trouvé. Il n'y avait pas d'argent. J'ai tout fouillé, mais l'argent est introuvable.";
				link.l1.go = "StResult_2";
			}
			else
			{
				npchar.quest.store.money = sti(pchar.money) - sti(npchar.quest.store.money); //чистая выручка
				link.l1 = "J'ai trouvé " + FindRussianMoneyString(sti(npchar.quest.store.money)) + " en tout. La moitié est à toi, comme convenu.";
				link.l1.go = "StResult_3";
			}
		break;
		case "StResult_2":
			dialog.text = "Oui, je ne m'attendais pas à ce résultat... Bon, tant pis. L'argent, ici, c'est comme la boue, j'en trouverai ailleurs...";
			link.l1 = "C'est vrai aussi.";
			link.l1.go = "StResult_4";
			AddQuestRecord("ISS_takeStoreMoney", "3");
			AddQuestUserData("ISS_takeStoreMoney", "sSex", GetSexPhrase("", "e"));
		break;
		case "StResult_3":
			dialog.text = "Eh bien, parfait ! Je suis content que tout se soit si bien terminé... Bon, à la prochaine, "+ GetSexPhrase("l'ami","ma petite") +". En cas de problème, fais-moi signe.";
			link.l1 = "Absolument.";
			link.l1.go = "StResult_4";
			AddMoneyToCharacter(pchar, -makeint(sti(npchar.quest.store.money)/2));
			AddQuestRecord("ISS_takeStoreMoney", "4");
			CloseQuestHeader("ISS_takeStoreMoney");
		break;
		case "StResult_4":
			npchar.quest.store = "over"; //флаг этого миниквеста
			LAi_SetLoginTime(npchar, 6.0, 21.99);
			LAi_SetLSCoutType(npchar);
			LAi_group_MoveCharacter(npchar, "TmpEnemy");
			SaveCurrentNpcQuestDateParam(npchar, "location");
			NextDiag.TempNode = "First time";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "SeekGoods":
			dialog.text = NPCStringReactionRepeat("Quel genre de marchandises ?",
				"Vous m'avez déjà posé la question.",
				"Vous l'avez déjà demandé...",
                "Tu m'as déjà interrogé sur ces marchandises. Je ne sais rien !", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("J'ai besoin de boulets, de bombes, de boulets ramés, de vivres, de médicaments, de poudre, d'armes...",
				"Oui... Pardon, ça m'était sorti de la tête.",
                "Ah, oui.",
				"Je comprends...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("SeekGoods_1", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "SeekGoods_1":
			dialog.text = "Pourquoi en as-tu besoin ?";
			link.l1 = "Comme ça, au cas oם.";
			link.l1.go = "SeekGoods_2";
		break;
		case "SeekGoods_2":
			dialog.text = "Eh bien, les bombes, les boulets et autres munitions, on peut les obtenir auprès des maîtresses de maison des navires. Il y en a beaucoup. Mais la poudre et les armes, c'est uniquement l'amiral.";
			link.l1 = "Je vois. Eh bien, merci.";
			link.l1.go = "exit";
		break;
		//найм команды
		case "SeekCrew":
			dialog.text = "דa alors !.. Je ne suis plus dans le coup.";
			link.l1 = "J'attends une réponse.";
			link.l1.go = "SeekCrew_1";
		break;
		case "SeekCrew_1":
			dialog.text = ""+ GetSexPhrase("L'ami","" + pchar.name + "") +", tu as vraiment un navire qui peut partir d'ici ?";
			link.l1 = "Oui.";
			link.l1.go = "SeekCrew_2";
		break;
		case "SeekCrew_2":
			dialog.text = "Alors, il n'y a pas à réfléchir ! J'accepte.";
			link.l1 = "Parfait ! Va tout de suite au San Gabriel, oם le Mécanicien te fera passer sur mon navire.";
			link.l1.go = "SeekCrew_3";
		break;
		case "SeekCrew_3":
			dialog.text = "D'accord, je rassemble vite mes affaires.";
			link.l1 = "Ne sois pas en retard !";
			link.l1.go = "SeekCrew_all";
		break;
	}
	NextDiag.PrevNode = NodeName;
}
