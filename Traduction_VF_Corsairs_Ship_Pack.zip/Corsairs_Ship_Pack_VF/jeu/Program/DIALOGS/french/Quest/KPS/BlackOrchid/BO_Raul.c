// Gregg: Raul Esperanto - «Чёрная Орхидея», глава 8 «Рауль Эсперанто».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: the cane has been asked for but not yet brought
			if (CheckAttribute(PChar, "RaulEsperanto.Stick"))
			{
				dialog.text = "Vous l'avez trouvée ?";
				link.l1 = "Pas encore. Je cherche.";
				link.l1.go = "exit";
			}
			else
			{
			// Gregg: gratitude only once the old man is actually out, that is at "12".
			// At "11" he still sits in the cellar and has nothing to thank anyone for.
			if (PChar.RaulEsperanto == "12")
			{
				dialog.text = "Je ne sais pas comment vous remercier, capitaine.";
				link.l1 = "Inutile.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Que voulez-vous... Vous ne voyez pas que je vais déjà assez mal sans vous.";
				link.l1 = "Tenez encore un peu, Raul.";
				link.l1.go = "exit";
			}
			}
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Qui est là. Je ne vous vois pas.";
			link.l1 = "Capitaine " + PChar.lastname + ". Je suis venu vous sortir d'ici.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "...(un long silence)... On ne sort personne d'ici. On les emporte.";
			link.l1 = "Aujourd'hui, vous sortirez à pied. Vous pouvez marcher ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Non. J'ai du mal à tenir debout. Il me faut un bâton, n'importe lequel. J'avais une canne ; ils me l'ont prise quand ils m'ont arrêté, et je ne pense pas qu'ils l'aient jetée.";
			link.l1 = "Je vais la chercher.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoFindStick");
		break;

		case "4":
			dialog.text = "...(il prend la canne à deux mains)... C'est bien elle. Maintenant, je crois que je vais y arriver.";
			link.l1 = "Alors au navire. Il est au port.";
			link.l1.go = "5";
			TakeNItems(PChar, "RaulEsperanto_Stick", -1);
		break;

		case "5":
			dialog.text = "Oם allons-nous, capitaine ?";
			link.l1 = "א San Juan. Porto Rico.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "...(il s'arrête)... Chez les Espagnols.";
			link.l1 = "...(sourit)... Vous n'êtes plus au courant, Raul. San Juan n'est plus espagnole depuis un bon moment.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "א qui est-elle, alors ?";
			link.l1 = "Je vous raconterai en chemin. Maintenant, marchons.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("RaulEsperantoReturnToSanJuan");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
