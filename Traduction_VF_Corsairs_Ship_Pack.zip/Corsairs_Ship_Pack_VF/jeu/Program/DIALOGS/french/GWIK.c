
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	int price = 50000;
	if (CheckOfficersPerk(pchar, "Trader")) price = 10000;
	int uniDays, uniPrice;
	int uniPerDay = 1000 + sti(pchar.rank) * 50; // price per day: 1000 + hero level * 50

	// price report subscription: a month with delivery every 5 days
	int subPrice = 80000;
	if (CheckOfficersPerk(pchar,"Trader")) subPrice = 20000;

	// bill of exchange service
	int billFee = 5; // commission, %
	if (CheckOfficersPerk(pchar,"Trader")) billFee = 3;
	int billSum, billPay, cash;

	// contract and auction
	int iGood, cQty, cPrice, cCargo, sell, aQty, aPrice, toBuy, added, cn, i, iClass;
	ref rItem;
	string sItemName;
	string sNode = "";
	string sPartnerId = GWIK_PartnerId(NPChar.id); // partner office (mail/delivery) - next open office in the ring
	string sPartner = "à Curaçao";
	if (sPartnerId == "GVIK_char") sPartner = "à Saint-Martin";
	if (sPartnerId == "FortOrange_GWIK_char") sPartner = "en Jamaïque";

	// Company shareholding: shareholder discounts on office services
	int shareLvl = 0;
	if (CheckAttribute(pchar,"GWIK.Share.Level")) shareLvl = sti(pchar.GWIK.Share.Level);
	int shareDisc = 0;
	if (shareLvl == 1) shareDisc = 10;
	if (shareLvl == 2) shareDisc = 25;
	if (shareLvl == 3) shareDisc = 50;
	int shareCost = 100000; // price of the next share level
	if (shareLvl == 1) shareCost = 250000;
	if (shareLvl == 2) shareCost = 500000;

	// Company assignments
	int iJob;
	int jobMailPay = 8000 + sti(pchar.rank) * 800;
	int jobRansom = 20000 + sti(pchar.rank) * 1000;
	int jobRansomPay = 8000 + sti(pchar.rank) * 800;
	int jobRivalPay = 25000 + sti(pchar.rank) * 1500;
	int jobConvoyBonus = 15000 + sti(pchar.rank) * 1000;
	string sJobCity;
	bool ok, bPrimary, bExtra, bElite, bMap, bTube, bTreasure, bMutiny, bDodged;
	if (shareDisc > 0)
	{
		price = makeint(price * (100 - shareDisc) / 100);
		subPrice = makeint(subPrice * (100 - shareDisc) / 100);
		uniPerDay = makeint(uniPerDay * (100 - shareDisc) / 100);
		if (shareLvl >= 2 && billFee > 1) billFee = billFee - 1;
		if (shareLvl >= 3 && billFee > 1) billFee = billFee - 1;
	}
	// dividends and assignments grow with the share level
	int shareRate = 2;                  // % dividends a month: shareholder
	if (shareLvl == 2) shareRate = 3;   // partner
	if (shareLvl >= 3) shareRate = 4;   // associate
	int jobCooldown = 4 - shareLvl;     // assignment cooldown: 4 / 3 / 2 / 1 days
	if (shareLvl > 0)                   // +15% to Company rewards per share level
	{
		jobMailPay     = makeint(jobMailPay     * (100 + shareLvl * 15) / 100);
		jobRansomPay   = makeint(jobRansomPay   * (100 + shareLvl * 15) / 100);
		jobRivalPay    = makeint(jobRivalPay    * (100 + shareLvl * 15) / 100);
		jobConvoyBonus = makeint(jobConvoyBonus * (100 + shareLvl * 15) / 100);
	}

	// Gregg: trophy-ship pick dispatcher (node name TrophySell_<companion index> -> shared node Trophy_Do)
	sNode = Dialog.CurrentNode;
	if (findsubstr(sNode, "TrophySell_", 0) != -1)
	{
		i = findsubstr(sNode, "_", 0);
		pchar.GWIK.TrophyPick = strcut(sNode, i + 1, strlen(sNode) - 1);
		Dialog.CurrentNode = "Trophy_Do";
	}
	// Gregg: the "unexpected offer" - when a high-standing Companion asks for a job, preempt the rotation once with the Jamaica office quest
	if (sNode == "Job_Ask" && GWIK_JamaicaEligible() && !CheckAttribute(pchar, "GWIK.Jamaica.Offered"))
	{
		pchar.GWIK.Jamaica.Offered = true;
		Dialog.CurrentNode = "Jamaica_Offer";
	}

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Salutations. Je suis " + GetFullName(NPChar) + ", représentant du comptoir de la Compagnie néerlandaise des Indes occidentales sur l'île de Saint-Martin. Veuillez vous présenter.";
			if (NPChar.id == "GWIK_char") dialog.text = "Salutations. Je suis " + GetFullName(NPChar) + ", représentant du comptoir de la Compagnie néerlandaise des Indes occidentales sur l'île de Curaçao. Veuillez vous présenter.";
			if (NPChar.id == "FortOrange_GWIK_char") // Gregg: the manager is the very factor the player delivered; remembers the voyage and how the English were dealt with
			{
				dialog.text = "Capitaine "+ GetFullName(PChar) +" ! C'est donc à vous que la Compagnie doit ce comptoir. Je suis "+ GetFullName(NPChar) +", le gérant. Tout fonctionne déjà : listes de prix, lettres de change, marchandises confisquées, missions, exactement comme à Willemstad, et pour vous qui l'avez fondé, en priorité absolue.";
				if (CheckAttribute(pchar, "GWIK.Jamaica.Founder"))
				{
					dialog.text = "Capitaine "+ GetFullName(PChar) +" ! Vous, je ne vous oublierai jamais : je suis venu jusqu'à ce comptoir à bord de votre navire. Maintenant, je le dirige, et pour vous qui l'avez fondé, tout est en priorité absolue : listes de prix, lettres de change, marchandises confisquées, missions.";
					if (CheckAttribute(pchar, "GWIK.Jamaica.Tone"))
					{
						if (pchar.GWIK.Jamaica.Tone == "force") dialog.text = "Capitaine "+ GetFullName(PChar) +" ! Vous, je ne vous oublierai jamais : je suis venu jusqu'à ce comptoir à bord de votre navire. Le port parle encore à mi-voix du « Greyhound » de Gale : après cette leçon, les Anglais se tiennent bien à l'écart de nous. Pour vous qui l'avez fondé, tout est en priorité absolue : listes de prix, lettres de change, marchandises confisquées, missions.";
						if (pchar.GWIK.Jamaica.Tone == "gold") dialog.text = "Capitaine "+ GetFullName(PChar) +" ! Vous, je ne vous oublierai jamais : je suis venu jusqu'à ce comptoir à bord de votre navire. L'affaire avait alors été réglée en douce : l'or de la Compagnie sait se taire, et les Anglais regardent ailleurs. Pour vous qui l'avez fondé, tout est en priorité absolue : listes de prix, lettres de change, marchandises confisquées, missions.";
						if (pchar.GWIK.Jamaica.Tone == "word") dialog.text = "Capitaine "+ GetFullName(PChar) +" ! Vous, je ne vous oublierai jamais : je suis venu jusqu'à ce comptoir à bord de votre navire. Le comptoir a ouvert sans un seul coup de feu : votre nom s'est révélé plus fort que les canons. Pour vous qui l'avez fondé, tout est en priorité absolue : listes de prix, lettres de change, marchandises confisquées, missions.";
					}
				}
			}
			Link.l1 = "Bonjour, " + GetFullName(NPChar) + ". Je suis " + GetFullName(PChar) + ", capitaine du navire '" + PChar.ship.name + "'.";
			link.l1.go = "Meet_2";
			if (NPChar.id == "FortOrange_GWIK_char") // the founder - the manager already knows the player, special reply
			{
				Link.l1 = "דa fait plaisir de voir Fort Orange sous le pavillon de la Compagnie.";
				link.l1.go = "Meet_2";
			}
		break;

		case "Exit":
			NextDiag.CurrentNode = "Meet_2";
			DialogExit();
		break;

		case "Meet_2":
			GWIK_CheckContract(NPChar);
			GWIK_CheckAuction(NPChar);
			// safety: if the quest timer was lost (old save), re-arm it
			if (shareLvl > 0 && !CheckAttribute(pchar, "quest.GWIK_DividendTick")) SetTimerFunction("GWIK_DividendTick", 0, 1, 0);
			if (CheckAttribute(pchar, "GWIK.Subscription") && !CheckAttribute(pchar, "quest.GWIK_SubscriptionTick")) SetTimerFunction("GWIK_SubscriptionTick", 0, 0, 5);
			if (!CheckAttribute(npchar, "met")) dialog.text = "Ravi de vous rencontrer, capitaine. Qu'est-ce qui vous amène ?";
			else dialog.text = "Qu'est-ce qui vous amène, capitaine ?";
			if (NPChar.id == "FortOrange_GWIK_char" && CheckAttribute(pchar, "GWIK.Jamaica.Founder")) dialog.text = "Toujours content de vous voir, capitaine. Qu'est-ce qui vous amène ?"; // Gregg: the manager-factor knows the player well - "nice to meet you" would be off
			if (!CheckAttribute(pchar, "GwikTimer") && !CheckAttribute(pchar,"GWIK.Subscription"))
			{
				Link.l1 = "J'aimerais vous acheter des informations sur les prix pratiqués dans les magasins de l'archipel.";
				link.l1.go = "trade_info";
			}
			if (!CheckAttribute(pchar,"GWIK.Subscription"))
			{
				Link.l4 = "Est-il possible de recevoir régulièrement vos relevés de prix, par courrier ?";
				link.l4.go = "Subscribe_Ask";
			}
			else
			{
				Link.l4 = "J'aimerais prolonger mon abonnement aux relevés de prix. (jours restants : " + pchar.GWIK.Subscription + ")";
				link.l4.go = "Subscribe_Ask";
			}
			Link.l2 = "J'aimerais acheter une licence commerciale universelle.";
			link.l2.go = "UniLicense_Ask";
			Link.l5 = "Quelles marchandises la Compagnie achète-t-elle en ce moment ?";
			link.l5.go = "Contract_Info";
			Link.l6 = "Qu'y a-t-il aujourd'hui à la vente des marchandises confisquées ?";
			link.l6.go = "Auction_Info";
			Link.l7 = "J'ai une affaire d'argent à régler.";
			link.l7.go = "GWIK_Finance";
			Link.l10 = "La Compagnie a-t-elle des missions pour moi ?";
			link.l10.go = "Job_Ask";
			if (CheckAttribute(pchar, "GWIK.Job"))
			{
				if (pchar.GWIK.Job == "mail" && pchar.GWIK.Job.Target == NPChar.id)
				{
					Link.l11 = "J'ai un paquet de votre comptoir partenaire.";
					link.l11.go = "Job_MailDone";
				}
				if (pchar.GWIK.Job == "ransom" && CheckAttribute(pchar, "GWIK.Job.Rescued"))
				{
					Link.l11 = "Je vous ramène votre capitaine, racheté aux pirates.";
					if (CheckAttribute(pchar, "GWIK.Job.Mutiny")) Link.l11 = "Je vous ramène votre capitaine fugitif : de force, aux fers."; // Gregg: mutiny - not ransomed, taken by boarding
					link.l11.go = "Job_RansomDone";
				}
				if (pchar.GWIK.Job == "ransom" && CheckAttribute(pchar, "GWIK.Job.CaptiveDeadKnown"))
				{
					Link.l11 = "Triste nouvelle : les pirates ont tué votre capitaine, je n'ai pas pu le sauver.";
					link.l11.go = "GWIK_RansomDeadReport";
				}
				if (pchar.GWIK.Job == "ransom" && CheckAttribute(pchar, "GWIK.Job.MutinyReturnedSelf"))
				{
					Link.l11 = "Votre capitaine fugitif est revenu à la raison : je l'ai convaincu de rentrer ; il est déjà en route pour vous rejoindre.";
					link.l11.go = "GWIK_MutinyReturnReport";
				}
				if (pchar.GWIK.Job == "ransom" && CheckAttribute(pchar, "GWIK.Job.MutinyReportReady"))
				{
					Link.l11 = "Triste nouvelle : votre capitaine s'est mutiné et a rejoint les pirates.";
					link.l11.go = "GWIK_MutinyReport";
				}
				if (pchar.GWIK.Job == "ransom" && CheckAttribute(pchar, "GWIK.Job.MutinyKilled"))
				{
					Link.l11 = "Votre capitaine fugitif a résisté à son arrestation : j'ai dמ l'abattre.";
					link.l11.go = "GWIK_MutineerKilledReport";
				}
				if (pchar.GWIK.Job == "rival" && CheckAttribute(pchar, "GWIK.Job.Done"))
				{
					Link.l11 = "Le navire de vos rivaux n'est plus un problème.";
					if (CheckAttribute(pchar, "GWIK.Job.RivalLand")) Link.l11 = "L'homme de vos rivaux n'est plus un problème."; // Gregg: land variant - killed ashore, there was no ship
					link.l11.go = "Job_RivalDone";
				}
			}
			if (CheckAttribute(pchar, "GWIK.ConvoyBonus.Done"))
			{
				Link.l12 = "Le navire de la Compagnie est arrivé à destination. Je viens pour la prime.";
				link.l12.go = "Job_ConvoyBonus";
			}
			if (GWIK_RepLevel() >= 2)
			{
				Link.l15 = "La Compagnie voudrait-elle d'un navire capturé de mon escadre ?";
				link.l15.go = "Trophy_Ask";
			}
			Link.l14 = "Comment la Compagnie voit-elle nos relations ?";
			link.l14.go = "GWIK_Standing";
				if (NPChar.id == "GWIK_char" && CheckAttribute(pchar,"GWIK.Jamaica.Stage") && sti(pchar.GWIK.Jamaica.Stage) == 3 && !CheckAttribute(pchar,"GWIK.Jamaica.Convoy") && !CheckAttribute(pchar,"GWIK.Jamaica.ConvoyArrived")) // Gregg: take the supply convoy under escort (stage 3) - loaded ONLY at Curacao
				{
					Link.l20 = "Je viens pour le convoi destiné au comptoir de la Jamaïque.";
					link.l20.go = "Jamaica_Convoy";
				}
				if (GWIK_JamaicaEligible() && CheckAttribute(pchar, "GWIK.Jamaica.Offered")) // Gregg: return to the postponed Jamaica office offer
				{
					Link.l18 = "J'ai réfléchi à votre offre concernant le comptoir de la Jamaïque.";
					link.l18.go = "Jamaica_Offer";
				}
			if (NPChar.id == "GVIK_char" && CheckAttribute(pchar,"GWIK.Jamaica.Stage") && sti(pchar.GWIK.Jamaica.Stage) == 4 && !CheckAttribute(pchar,"GWIK.Jamaica.FactorAboard")) // Gregg: collect the factor for the Jamaica office (stage 4) - he waits ONLY in Marigo
				{
					Link.l19 = "Je viens pour l'agent destiné au comptoir de la Jamaïque.";
					link.l19.go = "Jamaica_Factor";
				}
				if (bBettaTestMode)
			{
				Link.l16 = "[BETA] Menu de test de la GWIC.";
				link.l16.go = "GWIK_BetaMenu";
			}
			Link.l3 = "Je passais juste vous saluer, bonne journée.";
			link.l3.go = "exit";
			npchar.met = 1;
		break;

		case "GWIK_Finance": // Gregg: office money-services sub-branch (share + bill) - grouped out of Meet_2 to declutter the main menu
			dialog.text = "Que puis-je pour vous cכté finances, capitaine ?";
			if (shareLvl == 0)
			{
				Link.l1 = "Pourrais-je investir dans les affaires de la Compagnie ?";
				link.l1.go = "Share_Ask";
			}
			if (shareLvl > 0 && shareLvl < 3)
			{
				Link.l1 = "J'aimerais augmenter ma part dans la Compagnie.";
				link.l1.go = "Share_Ask";
			}
			if (shareLvl > 0)
			{
				Link.l2 = "J'aimerais investir davantage dans ma part.";
				link.l2.go = "Share_Topup";
			}
			if (shareLvl > 0)
			{
				Link.l3 = "Je viens pour mes dividendes.";
				link.l3.go = "Share_Dividends";
			}
			// Gregg: the bill goes last - share and dividends are the standing business with the Company, a bill is a one-off service
			if (!CheckAttribute(pchar,"GWIK.Bill"))
			{
				Link.l4 = "J'aimerais tirer une lettre de change sur votre comptoir partenaire.";
				link.l4.go = "Bill_Ask";
			}
			else
			{
				if (pchar.GWIK.Bill.From != NPChar.id)
				{
					Link.l4 = "J'ai une lettre de change de votre Compagnie à encaisser.";
					link.l4.go = "Bill_Cash";
				}
				else
				{
					Link.l4 = "Rappelez-moi, oם puis-je encaisser ma lettre de change ?";
					link.l4.go = "Bill_Where";
				}
			}
			Link.l5 = "Revenons à d'autres sujets.";
			link.l5.go = "Meet_2";
		break;

		case "GWIK_Standing": // Gregg: player's standing with the Company
			iJob = GWIK_RepLevel(); // reuse iJob as the reputation level
			sJobCity = "client de passage";
			if (iJob == 1) sJobCity = "connaissance de la Compagnie";
			if (iJob == 2) sJobCity = "personne de confiance";
			if (iJob == 3) sJobCity = "ami de la Compagnie";
			if (iJob == 4) sJobCity = "pilier de la Compagnie";
			dialog.text = "Dans nos registres, vous figurez au rang de « "+ sJobCity +" ». La Compagnie apprécie les gens qui ont fait leurs preuves : plus votre nom pèse chez nous, plus les portes s'ouvrent : lots spéciaux, rachat de vos prises, missions de confiance.";
			link.l1 = "Merci. Je vais continuer dans cette voie.";
			link.l1.go = "Meet_2";
		break;

		case "GWIK_BetaRep": // [BETA] Gregg: instantly set reputation for the Jamaica quest gate (rep>=3)
				pchar.GWIK.Rep = 350; // level 3 threshold ("friend of the Company")
				if (!CheckAttribute(pchar, "GWIK.Share")) // Gregg: grant the Companion share too - quarterly cooldowns make it slow to grind by hand now
				{
					pchar.GWIK.Share.Pool = 0;
					pchar.GWIK.Share.Invested = 0;
					pchar.GWIK.Share.Date = GetQuestBookDataDigit();
					SetTimerFunction("GWIK_DividendTick", 0, 1, 0);
				}
				pchar.GWIK.Share.Level = 3;
				if (sti(pchar.GWIK.Share.Invested) < 850000) pchar.GWIK.Share.Invested = 850000; // nominal of the three instalments (100+250+500k)
				dialog.text = "[BETA] Accordé : réputation « ami de la Compagnie » (350, niveau 3) et part d'associé (850000 investis). Il ne reste plus, pour la quête de la Jamaïque, qu'un Fort Orange hollandais.";
				link.l1 = "Compris.";
				link.l1.go = "GWIK_BetaMenu";
			break;

			case "GWIK_BetaOpenFO": // [BETA] Gregg: open the Fort Orange office without the quest (step 2 test)
				GWIK_OpenFortOrangeOffice();
				dialog.text = "[BETA] Le comptoir de Fort Orange est ouvert : lieu, porte et représentant sont en place. Faites voile vers la Jamaïque ; l'entrée est la maison avec la porte reload_H3.";
				link.l1 = "Mettons les voiles.";
				link.l1.go = "GWIK_BetaMenu";
			break;

			case "GWIK_BetaMenu": // [BETA] Gregg: single GWIC test menu - quest conditions and launching generators in a chosen variant
				dialog.text = "[BETA] Menu de test de la GWIC. Que faut-il configurer ?";
				Link.l1 = "Conditions de la quête de la Jamaïque : réputation « ami de la Compagnie » + part d'associé.";
				link.l1.go = "GWIK_BetaRep";
				Link.l2 = "Ouvrir le comptoir de Fort Orange (sans la quête).";
				link.l2.go = "GWIK_BetaOpenFO";
				Link.l3 = "Mission « rival » : au mouillage près d'une île.";
				link.l3.go = "GWIK_BetaRivalStatic";
				Link.l4 = "Mission « rival » : en croisière en mer.";
				link.l4.go = "GWIK_BetaRivalMoving";
				Link.l5 = "Mission « rançon » : intermédiaire aux Bermudes.";
				link.l5.go = "GWIK_BetaRansomAgent";
				Link.l6 = "Mission « rançon » : captif à bord d'un pirate.";
				link.l6.go = "GWIK_BetaRansomPirate";
				Link.l7 = "Mission « rançon » : captif tué (échec).";
				link.l7.go = "GWIK_BetaRansomDead";
				Link.l8 = "Mission « courrier » : paquet brמlant (intercepté à la sortie).";
				link.l8.go = "GWIK_BetaMailHot";
				Link.l9 = "Mission « escorte » : avec une embuscade à destination.";
				link.l9.go = "GWIK_BetaConvoyAmbush";
				Link.l10 = "Mission « rançon » : le capitaine s'est mutiné (devenu pirate).";
					link.l10.go = "GWIK_BetaRansomMutiny";
				Link.l11 = "Mission « rival » : à terre (un homme dans une taverne, duel).";
				link.l11.go = "GWIK_BetaRivalLand";
				Link.l12 = "Envoyer la lettre du rang suivant (cadeau : carte / livre / prime).";
				link.l12.go = "GWIK_BetaRankLetter";
				Link.l13 = "Retour.";
				link.l13.go = "Meet_2";
			break;

			case "GWIK_BetaRankLetter": // [BETA] Gregg: deliver the rank letter right now, skipping the reputation threshold and the three-day post. Each press sends the next tier; after the fourth the cycle restarts
				iJob = 0;
				if (CheckAttribute(pchar, "GWIK.RankLetter.Sent")) iJob = sti(pchar.GWIK.RankLetter.Sent);
				iJob = iJob + 1;
				if (iJob > 4) iJob = 1;
				pchar.GWIK.RankLetter.Sent = iJob - 1; // so the "already sent for this rank" guard lets it through
				pchar.GWIK.RankLetter.Pending = iJob;
				GWIK_RankLetter("beta");
				dialog.text = "[BETA] La lettre du rang "+ iJob +" a été livrée. Vérifiez le journal de bord et votre inventaire.";
				link.l1 = "Ensuite.";
				link.l1.go = "GWIK_BetaMenu";
			break;

			case "GWIK_BetaRivalStatic": // [BETA] Gregg: give the rival assignment as the static variant (bypassing drand and the cooldown)
				GWIK_DropRivalJob(); // clear the current assignment and old ship
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRival = "static"; // read and cleared in GWIK_SpawnRival
				dialog.text = "[BETA] Variante « au mouillage près d'une île » configurée. Attribution de la mission.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RivalGo";
			break;

			case "GWIK_BetaRivalMoving": // [BETA] Gregg: give the rival assignment as the moving variant (bypassing drand and the cooldown)
				GWIK_DropRivalJob();
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRival = "moving";
				dialog.text = "[BETA] Variante « en croisière en mer » configurée. Attribution de la mission.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RivalGo";
			break;

			case "GWIK_BetaRivalLand": // [BETA] Gregg: give the rival assignment as the land variant (bypassing drand and the cooldown)
				GWIK_DropRivalJob();
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRival = "land";
				dialog.text = "[BETA] Variante « homme dans une taverne » configurée. Attribution de la mission. La cible prendra place dès que vous entrerez dans la taverne de la colonie.";
				link.l1 = "Continuez.";
				link.l1.go = "Job_RivalGo";
			break;

			case "GWIK_BetaRansomAgent": // [BETA] Gregg: give the ransom job via the Bermuda mediator (bypassing drand and the cooldown)
				GWIK_FinishRansomJob(); // clear the current ransom (safe if none)
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRansom = "agent"; // read and cleared in Job_RansomGo
				dialog.text = "[BETA] Variante « intermédiaire aux Bermudes » configurée. Attribution de la mission.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RansomGo";
			break;

			case "GWIK_BetaRansomPirate": // [BETA] Gregg: give the ransom job as 'captive aboard a cruising pirate' (bypassing drand and the cooldown)
				GWIK_FinishRansomJob();
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRansom = "pirate";
				dialog.text = "[BETA] Variante « à bord d'un pirate » configurée. Attribution de la mission.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RansomGo";
			break;

			case "GWIK_BetaRansomDead": // [BETA] Gregg: give the ransom job with the 'captive killed' outcome (failure test, bypassing drand and the cooldown)
				GWIK_FinishRansomJob();
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRansom = "dead";
				dialog.text = "[BETA] Issue « captif tué » configurée. Attribution de la mission (vous l'apprendrez de l'intermédiaire aux Bermudes).";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RansomGo";
			break;

			case "GWIK_BetaMailHot": // [BETA] Gregg: give the mail job as a 'hot parcel' (agent on the way out, bypassing drand and the cooldown)
				DeleteAttribute(pchar, "GWIK.Job");
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceMail = "hot"; // read and cleared in Job_MailGo
				dialog.text = "[BETA] « Paquet brמlant » configuré. Attribution de la mission de courrier : l'agent vous interceptera à la sortie.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_MailGo";
			break;

			case "GWIK_BetaConvoyAmbush": // [BETA] Gregg: give the escort WITH an ambush off the destination (bypassing drand and the cooldown)
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceConvoy = "ambush"; // read and cleared in Job_ConvoyGo
				dialog.text = "[BETA] Embuscade configurée. Attribution de l'escorte : des pirates attendent au large de l'île de destination.";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_ConvoyGo";
			break;

			case "GWIK_BetaRansomMutiny": // [BETA] Gregg: give the ransom job with the 'captain mutinied' twist (bypassing drand and the cooldown)
				GWIK_FinishRansomJob(); // clear the current ransom (safe if none)
				DeleteAttribute(pchar, "GWIK.JobDate");
				DeleteAttribute(pchar, "GWIK.Job.Date");
				pchar.GWIK.BetaForceRansom = "mutiny"; // read and cleared in Job_RansomGo
				dialog.text = "[BETA] Rebondissement « capitaine mutiné » configuré. Attribution de la mission (vous l'apprendrez de l'« intermédiaire » aux Bermudes).";
				link.l1 = "Ensuite.";
				link.l1.go = "Job_RansomGo";
			break;

			case "Trophy_Ask": // Gregg: Company buys a captured squadron ship (rep>=2)
			if (CheckAttribute(pchar, "GWIK.TrophyDate") && GetNpcQuestPastDayParam(pchar, "GWIK.TrophyDate") < sti(pchar.GWIK.TrophyCD))
			{
				dialog.text = "La Compagnie vous a acheté un navire récemment, capitaine. Les caisses ne sont pas sans fond : repassez plus tard.";
				link.l1 = "Compris. Je reviendrai plus tard.";
				link.l1.go = "Meet_2";
				break;
			}
			bMap = false; // reused: whether any eligible ship was found
			for (i = 1; i < COMPANION_MAX; i++)
			{
				cn = GetCompanionIndex(pchar, i);
				if (cn < 0) continue;
				rItem = GetCharacter(cn);
				if (!GetRemovable(rItem)) continue;
				if (!GetShipRemovable(rItem)) continue;
				aPrice = GWIK_TrophyPrice(rItem);
				sNode = "l" + i;
				link.(sNode) = XI_ConvertString(RealShips[sti(rItem.Ship.Type)].BaseName) + " (cap. " + GetFullName(rItem) + ") - " + FindRussianMoneyString(aPrice);
				link.(sNode).go = "TrophySell_" + cn;
				bMap = true;
			}
			if (!bMap)
			{
				dialog.text = "Vous n'avez dans votre escadre aucun navire que la Compagnie accepterait, capitaine.";
				link.l1 = "Je vois.";
				link.l1.go = "Meet_2";
				break;
			}
			dialog.text = "La Compagnie veut bien acheter un navire capturé, pour une partie de sa valeur, frais déduits, bien sמr. Lequel proposez-vous ?";
			link.l99 = "J'ai changé d'avis.";
			link.l99.go = "Meet_2";
		break;

		case "Trophy_Do": // Gregg: the deal itself (dispatcher target TrophySell_<idx>)
			cn = sti(pchar.GWIK.TrophyPick);
			if (cn < 0)
			{
				dialog.text = "Il y a un problème avec ce navire, capitaine. Recommençons.";
				link.l1 = "D'accord.";
				link.l1.go = "Trophy_Ask";
				break;
			}
			rItem = GetCharacter(cn);
			if (!IsCompanion(rItem))
			{
				dialog.text = "Ce navire ne fait plus partie de votre escadre, capitaine.";
				link.l1 = "Hum, c'est bien vrai.";
				link.l1.go = "Meet_2";
				break;
			}
			aPrice = GWIK_TrophyPrice(rItem);
			sItemName = XI_ConvertString(RealShips[sti(rItem.Ship.Type)].BaseName);
			iClass = GetCharacterShipClass(rItem); // Gregg: read the trophy class BEFORE the sale - GWIK_SellTrophyShip nulls the ship type (would otherwise return 7)
			if (iClass < 1) iClass = 1;
			if (iClass > 7) iClass = 7;
			GWIK_SellTrophyShip(rItem); // Gregg: officer -> passenger, crew -> across the squadron and tavern, cargo & cannons -> local shop; ship goes to the Company
			AddMoneyToCharacter(pchar, aPrice);
			GWIK_AddRep(10);
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, (7 - iClass + 1) * 25); // Gregg: leadership & commerce xp for the deal; inverse of ship class (cl.1 -> 175, cl.7 -> 25)
			AddCharacterExpToSkill(pchar, SKILL_COMMERCE,   (7 - iClass + 1) * 25);
			pchar.GWIK.TrophyCD = 14 + drand(7); // cooldown 14..21 days (daily rng)
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.TrophyDate");
			PlayStereoSound("notebook");
			dialog.text = sItemName +" passe à la Compagnie, et voici vos "+ FindRussianMoneyString(aPrice) +". Un plaisir de faire affaire avec vous, capitaine.";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Share_Ask":
			if (shareLvl > 0 && CheckAttribute(pchar, "GWIK.Share.LevelDate") && GetNpcQuestPastDayParam(pchar, "GWIK.Share.LevelDate") < 90) // Gregg: expanding the share - no more than once a quarter (like the top-up)
			{
				dialog.text = "Vous avez augmenté votre part il n'y a pas longtemps, capitaine. La Compagnie n'établit une nouvelle part qu'une fois par trimestre au plus : repassez plus tard.";
				link.l1 = "Très bien, je reviendrai.";
				link.l1.go = "Meet_2";
				break;
			}
			if (shareLvl == 0)
			{
				dialog.text = "La Compagnie est toujours heureuse d'accueillir des capitaines fiables parmi ses actionnaires. Une part coמte "+ FindRussianMoneyString(shareCost) +" et donne droit à une remise de 10 % sur tous les services de nos comptoirs, ainsi qu'à des dividendes mensuels : 2 % de la somme investie. Avec le temps, vous pourrez augmenter votre participation. Vous en êtes ?";
			}
			if (shareLvl == 1)
			{
				dialog.text = "Faire passer votre part au rang de partenaire vous coמtera encore "+ FindRussianMoneyString(shareCost) +". Un partenaire bénéficie d'une remise de 25 % sur les services des comptoirs, d'une commission réduite sur les lettres de change et d'un second lot à chaque vente de marchandises confisquées. Et les dividendes passent à 3 % par mois, sur une somme bien plus importante. On l'établit ?";
			}
			if (shareLvl == 2)
			{
				dialog.text = "Une part d'associé, c'est encore "+ FindRussianMoneyString(shareCost) +". En échange : demi-tarif sur tous les services des comptoirs, la commission la plus basse sur les lettres de change, 4 % par mois de dividendes sur toute la somme investie et les meilleures conditions pour nos missions. Marché conclu ?";
			}
			if (sti(pchar.money) >= shareCost)
			{
				link.l1 = "Oui, voici l'argent.";
				link.l1.go = "Share_Buy";
			}
			else
			{
				link.l1 = "Hum, je n'ai pas autant sur moi...";
				link.l1.go = "Meet_2";
			}
			link.l2 = "Non, je n'ai pas envie de me séparer d'une telle somme.";
			link.l2.go = "Meet_2";
		break;

		case "Share_Buy":
			if (shareLvl > 0 && CheckAttribute(pchar, "GWIK.Share.LevelDate") && GetNpcQuestPastDayParam(pchar, "GWIK.Share.LevelDate") < 90) // Gregg: cooldown safety
			{
				dialog.text = "Pas si vite, capitaine : la Compagnie n'établit une nouvelle part qu'une fois par trimestre au plus.";
				link.l1 = "Compris.";
				link.l1.go = "Meet_2";
				break;
			}
			if (sti(pchar.money) < shareCost)
			{
				dialog.text = "Vous n'avez pas assez d'argent, capitaine.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -shareCost);
			if (shareLvl == 0)
			{
				pchar.GWIK.Share.Pool = 0;
				pchar.GWIK.Share.Invested = 0;
				pchar.GWIK.Share.Date = GetQuestBookDataDigit();
				SetTimerFunction("GWIK_DividendTick", 0, 1, 0);
			}
			pchar.GWIK.Share.Level = shareLvl + 1;
			pchar.GWIK.Share.Invested = sti(pchar.GWIK.Share.Invested) + shareCost;
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.Share.LevelDate"); // Gregg: quarterly expansion cooldown starts now
			GWIK_AddRep(35); // Gregg: reputation for joining/expanding the share
			PlayStereoSound("notebook");
			if (shareLvl == 0)
			{
				dialog.text = "Bienvenue parmi les actionnaires de la Compagnie ! Les papiers sont établis et consignés dans votre journal de bord. Les dividendes sont versés une fois par mois : vous pourrez les toucher dans n'importe lequel de nos comptoirs.";
			}
			else
			{
				dialog.text = "Félicitations pour l'augmentation de votre participation ! Les papiers ont été refaits, les nouvelles conditions s'appliquent dès cette minute.";
			}
			link.l1 = "Un plaisir de faire affaire avec vous. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Share_Dividends":
			cash = 0;
			if (CheckAttribute(pchar,"GWIK.Share.Pool")) cash = sti(pchar.GWIK.Share.Pool);
			if (cash > 0)
			{
				AddMoneyToCharacter(pchar, cash);
				pchar.GWIK.Share.Pool = 0;
				PlayStereoSound("notebook");
				dialog.text = "Depuis le dernier versement, on a porté à votre crédit "+ FindRussianMoneyString(cash) +". Les voici, jusqu'à la dernière pièce. La Compagnie vous remercie de votre confiance !";
			}
			else
			{
				dialog.text = "Rien ne s'est encore accumulé, capitaine. Les dividendes sont versés une fois par mois : "+ shareRate +" % de la somme investie. Dès que le courrier vous préviendra, passez dans n'importe quel comptoir.";
			}
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
			link.l2 = "Autre chose ?";
			link.l2.go = "Meet_2";
		break;

		case "Share_Topup":
			if (CheckAttribute(pchar, "GWIK.Share.TopupDate") && GetNpcQuestPastDayParam(pchar, "GWIK.Share.TopupDate") < 90)
			{
				dialog.text = "Vous avez augmenté votre part récemment, capitaine. La Compagnie n'accepte les investissements supplémentaires qu'une fois par trimestre au plus : repassez plus tard.";
				link.l1 = "D'accord, je repasserai plus tard.";
				link.l1.go = "Meet_2";
				break;
			}
			dialog.text = "Bien sמr. Un investissement supplémentaire augmentera votre participation, et avec elle vos dividendes. Nous acceptons de 100000 à 200000 piastres, une fois par trimestre au plus. Combien voulez-vous déposer ?";
			link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "Share_TopupCalc";
			link.l2 = "Une autre fois, peut-être.";
			link.l2.go = "Meet_2";
		break;

		case "Share_TopupCalc":
			cash = sti(dialogEditStrings[1]); // cash is used as the investment sum
			if (cash < 100000)
			{
				dialog.text = "Un investissement supplémentaire, c'est au moins 100000 piastres, capitaine. Proposez une autre somme.";
				link.l1 = "D'accord, essayons encore.";
				link.l1.go = "Share_Topup";
				link.l2 = "Alors, laissons tomber.";
				link.l2.go = "Meet_2";
				break;
			}
			if (cash > 200000) cash = 200000; // the Company won't take more than 200000 at once
			if (sti(pchar.money) < cash)
			{
				dialog.text = "Vous n'avez pas autant sur vous, capitaine. Proposez une somme plus modeste.";
				link.l1 = "D'accord, essayons encore.";
				link.l1.go = "Share_Topup";
				link.l2 = "Alors, laissons tomber.";
				link.l2.go = "Meet_2";
				break;
			}
			dialog.text = "Vous ajoutez "+ FindRussianMoneyString(cash) +" à votre part. Les dividendes seront versés sur la participation augmentée. On l'établit ?";
			link.l1 = "Oui, voici l'argent.";
			link.l1.go = "Share_TopupBuy";
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "Meet_2";
		break;

		case "Share_TopupBuy":
			cash = sti(dialogEditStrings[1]);
			if (cash > 200000) cash = 200000;
			if (cash < 100000 || sti(pchar.money) < cash)
			{
				dialog.text = "Quelque chose ne colle pas, capitaine. Recommençons.";
				link.l1 = "D'accord.";
				link.l1.go = "Share_Topup";
				break;
			}
			AddMoneyToCharacter(pchar, -cash);
			pchar.GWIK.Share.Invested = sti(pchar.GWIK.Share.Invested) + cash;
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.Share.TopupDate");
			PlayStereoSound("notebook");
			dialog.text = "C'est fait ! Votre participation a augmenté de "+ FindRussianMoneyString(cash) +". Le prochain investissement supplémentaire : pas avant un trimestre.";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Job_Ask":
			// active assignment - a reminder
			if (CheckAttribute(pchar, "GWIK.Job"))
			{
				if (pchar.GWIK.Job == "mail")
				{
					if (pchar.GWIK.Job.Target == NPChar.id)
					{
						dialog.text = "Vous avez donc le paquet de nos partenaires sur vous ? Alors, donnez-le-moi !";
						link.l1 = "Oui, le voici.";
						link.l1.go = "Job_MailDone";
					}
					else
					{
						dialog.text = "Vous transportez le paquet de la Compagnie pour notre comptoir "+ sPartner +". Le plus tכt sera le mieux : douze jours, souvenez-vous.";
						link.l1 = "Je suis déjà en route.";
						link.l1.go = "Meet_2";
						link.l2 = "J'ai bien peur de ne pas pouvoir le livrer. Je vous rends le paquet.";
						link.l2.go = "Job_Drop";
					}
					break;
				}
				if (pchar.GWIK.Job == "ransom")
				{
					if (CheckAttribute(pchar, "GWIK.Job.Rescued"))
					{
						dialog.text = "Vous avez ramené notre capitaine ? Remettez-le-nous : la Compagnie n'oubliera pas ce service.";
						link.l1 = "Oui, il est à bord de mon navire.";
						link.l1.go = "Job_RansomDone";
					}
					else
					{
						if (CheckAttribute(pchar, "GWIK.Job.Force")) // chose the force path - the sloop is at sea
						{
							dialog.text = "Vous avez choisi de vous passer de la rançon : c'est audacieux. Le navire pirate « "+ pchar.GWIK.Job.ForceShipName +" », avec notre capitaine à son bord, se trouve toujours quelque part au large des Bermudes. Ramenez-le-nous, vivant de préférence.";
							link.l1 = "Je le ramènerai.";
							link.l1.go = "Meet_2";
							link.l2 = "דa ne marche pas. J'abandonne.";
							link.l2.go = "Job_Drop";
						}
						else
						{
							dialog.text = "Notre capitaine est toujours aux mains des pirates. L'intermédiaire attend à la taverne du repaire pirate des Bermudes ; la rançon est de "+ FindRussianMoneyString(jobRansom) +". La Compagnie vous remboursera tout, et y ajoutera une prime de "+ jobRansomPay +" piastres.";
							link.l1 = "Je m'en souviens. J'y vais.";
							link.l1.go = "Meet_2";
							link.l2 = "Cette mission est au-dessus de mes forces. J'abandonne.";
							link.l2.go = "Job_Drop";
						}
					}
					break;
				}
				if (pchar.GWIK.Job == "rival")
				{
					if (CheckAttribute(pchar, "GWIK.Job.Done"))
					{
						dialog.text = "On dit que nos rivaux ont perdu un navire... La Compagnie est prête à régler le compte.";
						if (CheckAttribute(pchar, "GWIK.Job.RivalLand")) dialog.text = "On dit qu'une place s'est libérée à la table de nos rivaux à "+ XI_ConvertString("Colony" + pchar.GWIK.Job.City) +"... La Compagnie est prête à régler le compte.";
						link.l1 = "Oui, c'est chose faite.";
						link.l1.go = "Job_RivalDone";
					}
					else
					{
						dialog.text = "Le navire de nos rivaux – "+ GWIK_RivalShipStr() +" – se trouve toujours "+ GWIK_JobPlaceStr() +". Faites en sorte qu'il ne revienne jamais au port. Et dépêchez-vous : il ne restera pas là éternellement.";
						if (CheckAttribute(pchar, "GWIK.Job.RivalLand")) dialog.text = "Leur homme, "+ pchar.GWIK.Job.RivalName +", passe toujours ses soirées à la taverne de "+ XI_ConvertString("Colony" + pchar.GWIK.Job.City) +". Il ne prend jamais la mer, c'est donc là qu'il faudra le chercher. Et dépêchez-vous : il ne restera pas éternellement dans cette ville.";
						if (CheckAttribute(pchar, "GWIK.Job.RivalOutTown")) dialog.text = "On dit que vous l'avez déjà provoqué en duel. "+ pchar.GWIK.Job.RivalName +" vous attend aux portes de "+ XI_ConvertString("Colony" + pchar.GWIK.Job.City) +" – lame au clair, et visiblement à bout de patience. Ne le faites pas trop attendre."; // Gregg: the duel is already called - he is no longer in the tavern
						link.l1 = "Je m'en occupe.";
						link.l1.go = "Meet_2";
						link.l2 = "J'ai changé d'avis. Je me retire de cette affaire.";
						link.l2.go = "Job_Drop";
					}
					break;
				}
			}
			// already escorting?
			if (CheckQuestAttribute("generate_convoy_quest_progress", "begin"))
			{
				dialog.text = "Vous escortez déjà un navire. Menez-le d'abord à destination ; ensuite, nous parlerons de nouvelles missions.";
				link.l1 = "C'est juste.";
				link.l1.go = "Meet_2";
				break;
			}
			// cooldown
			ok = false;
			if (CheckAttribute(pchar, "GWIK.JobDate") && GetNpcQuestPastDayParam(pchar, "GWIK.JobDate") < jobCooldown) ok = true;
			if (ok)
			{
				dialog.text = "Rien pour vous en ce moment, capitaine. Repassez dans quelques jours : la Compagnie trouve toujours du travail.";
				link.l1 = "D'accord, je repasserai.";
				link.l1.go = "Meet_2";
				break;
			}
			// generate an offer and keep it until a decision is made
			if (!CheckAttribute(pchar, "GWIK.JobOffer"))
			{
				iJob = drand(3); // Gregg: assignment type via drand - deterministic per day, F9-proof
				if (iJob == 0)
				{
					ok = (GetCompanionQuantity(PChar) < COMPANION_MAX);
					if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) < 5) ok = false;
					if (sti(Pchar.Ship.Type) == SHIP_NOTUSED) ok = false;
					if (!ok) iJob = 1;
				}
				pchar.GWIK.JobOffer = iJob;
			}
			iJob = sti(pchar.GWIK.JobOffer);
			if (iJob == 0)
			{
				dialog.text = "Oui, il y en a. Un navire de la Compagnie chargé d'une cargaison précieuse a besoin d'une escorte fiable jusqu'à l'une des colonies. Le capitaine paiera l'escorte à l'arrivée (fixez le prix avec lui vous-même), et la Compagnie y ajoutera sa propre prime : "+ FindRussianMoneyString(jobConvoyBonus) +" , à toucher dans n'importe quel comptoir. Vous acceptez ?";
				link.l1 = "J'accepte. Oם est le capitaine ?";
				link.l1.go = "Job_ConvoyGo";
			}
			if (iJob == 1)
			{
				dialog.text = "Oui, il y en a. Un paquet de documents d'affaires doit être livré à notre comptoir "+ sPartner +" – dans douze jours au plus tard. La Compagnie paiera "+ FindRussianMoneyString(jobMailPay) +". Vous acceptez ?";
				link.l1 = "J'accepte. Donnez-moi le paquet.";
				link.l1.go = "Job_MailGo";
			}
			if (iJob == 2)
			{
				dialog.text = "Oui, et c'est une affaire délicate. Des pirates ont capturé un capitaine de la Compagnie et exigent une rançon de "+ FindRussianMoneyString(jobRansom) +". Leur intermédiaire se tient à la taverne du repaire pirate des Bermudes. Rachetez notre homme et amenez-le dans n'importe quel comptoir : la Compagnie vous remboursera la rançon et y ajoutera une prime de "+ jobRansomPay +" piastres. Vous acceptez ?";
				link.l1 = "J'accepte. Préparez l'argent.";
				link.l1.go = "Job_RansomGo";
			}
			if (iJob == 3)
			{
				dialog.text = "Il y a une affaire... qui ne figurera dans aucun registre. Les rivaux de la Compagnie se sont pris d'affection pour ces eaux, et ils transportent leurs cargaisons bien trop bon marché. La Compagnie paie "+ FindRussianMoneyString(jobRivalPay) +" si cette nuisance disparaît, et la manière dont vous vous en chargerez ne nous regarde pas. Vous acceptez ?"; // Gregg: text kept NEUTRAL - the variant (ship at anchor / ship at sea / man in a tavern) is only rolled in Job_RivalGo
				link.l1 = "J'accepte. Donnez-moi le lieu.";
				link.l1.go = "Job_RivalGo";
			}
			link.l2 = "Non, ce n'est pas pour moi.";
			link.l2.go = "Job_Refuse";
		break;

		case "Job_Refuse":
			DeleteAttribute(pchar, "GWIK.JobOffer");
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Comme vous voudrez. La Compagnie trouvera quelqu'un d'autre pour ce travail.";
			link.l1 = "Bonjour.";
			link.l1.go = "Meet_2";
		break;

		case "Jamaica_Offer": // Gregg: special quest - opening the Fort Orange office
			dialog.text = "Capitaine, un mot qui n'est pas destiné à d'autres oreilles. Les Heeren XVII, les directeurs de la Compagnie, ont décidé d'ouvrir un comptoir en Jamaïque, à Fort Orange, juste sous le nez de l'anglaise Port Royal. Une affaire délicate et de longue haleine : il faut quelqu'un des nכtres qui ait fait ses preuves. Le choix de la Compagnie s'est porté sur vous.";
			link.l1 = "Pourquoi Fort Orange, justement ? Dites-m'en plus.";
			link.l1.go = "Jamaica_Offer2";
			link.l2 = "C'est un honneur. J'en suis.";
			link.l2.go = "Jamaica_Accept";
			link.l3 = "Laissez-moi y réfléchir.";
			link.l3.go = "Meet_2";
		break;

		case "Jamaica_Offer2": // Gregg: exposition - why the Company wants Jamaica and what's in it for the player
			dialog.text = "Fort Orange est le seul port hollandais au cœur même des eaux anglaises. Qui y possède des entrepכts tient le commerce de la moitié de l'archipel. Les Heeren XVII sont prêts à investir, mais ne peuvent agir ouvertement : Port Royal étoufferait l'entreprise dans l'œuf. Il faut quelqu'un qui ait un nom, un navire et des nerfs d'acier. En échange : une part de cofondateur dans la nouvelle succursale, et la gratitude de la Compagnie, qui vaut beaucoup.";
			link.l1 = "Vous avez su me convaincre. J'en suis.";
			link.l1.go = "Jamaica_Accept";
			link.l2 = "Laissez-moi y réfléchir.";
			link.l2.go = "Meet_2";
		break;

		case "Jamaica_Accept":
			GWIK_StartJamaicaQuest();
			dialog.text = "Excellent. Notre émissaire vous attend à Fort Orange : c'est un homme de confiance de la Compagnie, cherchez-le à la résidence. Il dirige l'affaire sur place et vous mettra au courant. Et souvenez-vous : pas un mot de tout ceci à qui que ce soit.";
			link.l1 = "Je pars immédiatement.";
			link.l1.go = "exit";
		break;

		case "Jamaica_Factor": // Gregg: the factor (stage 4) walks in from the street and introduces himself (GWIK_Factor.c) - no middleman
			if (!CheckAttribute(pchar, "GWIK.Jamaica.FactorId"))
			{
				GWIK_JamaicaSpawnFactorInOffice();
				dialog.text = "Il attend ce jour depuis des mois, capitaine : il tourne autour du comptoir depuis ce matin... Ah, le voilà, quand on parle du loup. Il vous dira tout lui-même.";
				link.l1 = "Je le vois. Nous allons parler.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Monsieur "+ pchar.GWIK.Jamaica.FactorLName +" vous attend là oם vous l'avez rencontré. Parlez-lui, et en route.";
			link.l1 = "J'y vais.";
			link.l1.go = "exit";
		break;

		case "Jamaica_Convoy": // Gregg: take the supply convoy under escort at Curacao (stage 3)
			if (GetCompanionQuantity(pchar) > COMPANION_MAX - 2)
			{
				dialog.text = "Je le ferais volontiers, capitaine, mais deux galions n'entreront pas dans votre escadre : il n'y a pas de place. Libérez deux places et revenez.";
				link.l1 = "Je vais faire de la place.";
				link.l1.go = "Meet_2";
				break;
			}
			if (sti(pchar.money) < 50000)
			{
				dialog.text = "Voilà comment ça marche : le convoi appartient à la Compagnie, mais la part du fondateur est la vכtre. Cinquante mille piastres dans l'entreprise, et les galions sont à vous jusqu'à Fort Orange. Vous avez cette somme sur vous ?";
				link.l1 = "Je vais réunir l'argent.";
				link.l1.go = "Meet_2";
				break;
			}
			dialog.text = "Deux galions sont chargés à ras bord : acajou, bois de santal, balles de soie, de quoi monter un beau comptoir. Votre part de fondateur, c'est cinquante mille dans l'entreprise, et je placerai le convoi sous vos ordres. Menez-le jusqu'à Fort Orange et gardez-le bien : les Anglais ont déjà eu vent de cette cargaison.";
			link.l1 = "Marché conclu. Préparez les galions.";
			link.l1.go = "Jamaica_Convoy_Go";
			link.l2 = "Laissez-moi y réfléchir.";
			link.l2.go = "Meet_2";
		break;

		case "Jamaica_Convoy_Go":
			if (!GWIK_JamaicaSpawnConvoy()) // failed (no free slots) - don't dead-end
			{
				dialog.text = "Hmph, il n'y avait finalement pas de place pour les galions dans votre escadre. Libérez deux places et revenez.";
				link.l1 = "Je vais faire de la place.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -50000);
			PlayStereoSound("notebook");
			AddQuestRecord("GWIK_JamaicaJob", "15");
			dialog.text = "Bonne chance, capitaine. Les galions prendront la mer derrière vous : gardez-les sous vos canons. L'émissaire vous accueillera à Fort Orange. Bon vent !";
			link.l1 = "Cap sur Fort Orange.";
			link.l1.go = "exit";
		break;

		case "Job_ConvoyGo":
			DeleteAttribute(pchar, "GWIK.JobOffer");
			sJobCity = findTraderCity_GWIK(NPChar);
			if (sJobCity == "none")
			{
				dialog.text = "Hum, on dirait que notre capitaine a déjà levé l'ancre. Pas de chance : repassez une autre fois.";
				link.l1 = "דa arrive...";
				link.l1.go = "Meet_2";
				break;
			}
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			pchar.quest.destination = sJobCity;
			pchar.ConvoyQuest.City = NPChar.city;
			DeleteAttribute(pchar, "GWIK.ConvoyBonus"); // Gregg: clear the old node together with .Done - otherwise a bonus for an undelivered convoy
			pchar.GWIK.ConvoyBonus = jobConvoyBonus; // Company bonus on top of the trader's pay
			AddDialogExitQuest("prepare_for_convoy_quest");
			ReOpenQuestHeader("GWIK_ConvoyJob"); // Gregg: Company escort journal
			AddQuestRecord("GWIK_ConvoyJob", "1");
			AddQuestUserData("GWIK_ConvoyJob", "sCity", XI_ConvertString("Colony" + sJobCity + "Gen")); // Gregg: запись говорит «до <города>» - родительный
			AddQuestUserData("GWIK_ConvoyJob", "sMoney", FindRussianMoneyString(jobConvoyBonus));
			// Gregg: RARE chance of an ambush (~25%) off the destination island (own stream drand1); the escort already catches the world map's random encounters, so keep it rare. Beta forces/disables
			bMap = false;
			if (drand1(3) == 0) bMap = true;
			if (CheckAttribute(pchar, "GWIK.BetaForceConvoy")) { bMap = false; if (pchar.GWIK.BetaForceConvoy == "ambush") bMap = true; DeleteAttribute(pchar, "GWIK.BetaForceConvoy"); }
			DeleteAttribute(pchar, "GWIK.ConvoyAmbush"); // reset from a previous escort
			if (bMap) bMap = GWIK_ConvoySpawnAmbush(sJobCity); // didn't spawn (no locator) - escort without an ambush
			dialog.text = "Excellent ! Et voici notre capitaine : discutez des détails avec lui.";
			if (bMap) dialog.text = "Excellent ! Et voici notre capitaine. Seulement... on dit que des pirates rכdent au large de "+ XI_ConvertString("Colony" + sJobCity + "Gen") +". Gardez vos canons parés, capitaine.";
			link.l1 = "Je vais lui parler tout de suite.";
			link.l1.go = "exit";
		break;

		case "Job_MailGo":
			DeleteAttribute(pchar, "GWIK.JobOffer");
			pchar.GWIK.Job = "mail";
			pchar.GWIK.Job.Target = sPartnerId;
			sJobCity = GWIK_OfficeCityById(sPartnerId);
			pchar.GWIK.Job.Pay = jobMailPay;
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.Job.Date");
			PlayStereoSound("notebook");
			ReOpenQuestHeader("GWIK_MailJob");
			AddQuestRecord("GWIK_MailJob", "1");
			AddQuestUserData("GWIK_MailJob", "sCity", XI_ConvertString("Colony" + sJobCity + "Voc")); // Gregg: запись говорит «в конторе в <городе>» - предложный
			AddQuestUserData("GWIK_MailJob", "sMoney", FindRussianMoneyString(jobMailPay));
			dialog.text = "Voici le paquet, il est déjà parmi vos papiers. Remettez-le en main propre à notre représentant "+ sPartner +". Et souvenez-vous : mieux vaut ne pas briser les sceaux de la Compagnie, nous avons le bras long.";
			link.l1 = "Je le livrerai intact. Au revoir !";
			link.l1.go = "exit";
			iJob = drand1(2); // Gregg: 1/3 - a 'hot parcel': a rival agent intercepts you on the street of the office's town (own stream drand1, job type = drand(3))
			if (CheckAttribute(pchar, "GWIK.BetaForceMail")) { iJob = 0; DeleteAttribute(pchar, "GWIK.BetaForceMail"); }
			if (iJob == 0)
			{
				pchar.GWIK.Job.Hot = true;
				pchar.GWIK.Job.HotTown = GWIK_OfficeCityById(NPChar.id) + "_town"; // the current office's town - the agent will intercept you there in the street
				DeleteAttribute(pchar, "quest.GWIK_MailAgent.over");
				pchar.quest.GWIK_MailAgent.win_condition.l1 = "Location";
				pchar.quest.GWIK_MailAgent.win_condition.l1.location = pchar.GWIK.Job.HotTown;
				pchar.quest.GWIK_MailAgent.win_condition = "GWIK_MailAgentArrive";
				pchar.quest.GWIK_MailAgent.function = "GWIK_MailAgentArrive";
			}
		break;

		case "Job_RansomGo":
			DeleteAttribute(pchar, "GWIK.JobOffer");
			pchar.GWIK.Job = "ransom";
			pchar.GWIK.Job.Ransom = jobRansom;
			pchar.GWIK.Job.Bonus = jobRansomPay;
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.Job.Date");
			iJob = drand2(1); // Gregg: ransom sub-variant via drand2 (own stream! job type - drand(3), sea rival - drand1); 0 mediator on Bermuda, 1 captive aboard a cruising pirate
			if (CheckAttribute(pchar, "GWIK.BetaForceRansom")) { iJob = 0; if (pchar.GWIK.BetaForceRansom == "pirate") iJob = 1; if (pchar.GWIK.BetaForceRansom == "dead") pchar.GWIK.Job.CaptiveDead = true; if (pchar.GWIK.BetaForceRansom == "mutiny") pchar.GWIK.Job.Mutiny = true; DeleteAttribute(pchar, "GWIK.BetaForceRansom"); }
			if (iJob == 1 && GWIK_RansomForceSpawn("")) // variant "aboard a pirate": spawn the patrolling pirate off a random colony straight away, skipping the mediator
			{
				ReOpenQuestHeader("GWIK_RansomJob");
				AddQuestRecord("GWIK_RansomJob", "9");
				AddQuestUserData("GWIK_RansomJob", "sShip", pchar.GWIK.Job.ForceShipName);
				AddQuestUserData("GWIK_RansomJob", "sCap", pchar.GWIK.Job.ForceCapName);
				AddQuestUserData("GWIK_RansomJob", "sCity", XI_ConvertString("Colony" + pchar.GWIK.Job.PirateCity + "Gen"));
				AddQuestUserData("GWIK_RansomJob", "sBonus", FindRussianMoneyString(jobRansomPay));
				dialog.text = "Notre capitaine n'est pas aux Bermudes : un pirate du nom de "+ pchar.GWIK.Job.ForceCapName +" le retient à bord du navire « "+ pchar.GWIK.Job.ForceShipName +" ». Il croise au large de "+ XI_ConvertString("Colony" + pchar.GWIK.Job.PirateCity + "Gen") +". Interceptez-le et abordez-le : la Compagnie ajoutera une prime de "+ FindRussianMoneyString(jobRansomPay) +". Mais si vous l'envoyez par le fond, vous noierez aussi le captif.";
				// Gregg: she is still in port for the first two days (GWIK_RansomPutToSea) - say so, or we send the player to waters where there is no ship yet
				if (CheckAttribute(pchar, "GWIK.Job.PirateInPort")) dialog.text = "Notre capitaine n'est pas aux Bermudes : un pirate du nom de "+ pchar.GWIK.Job.ForceCapName +" le retient à bord du navire « "+ pchar.GWIK.Job.ForceShipName +" ». Pour l'instant, il mouille dans le port de "+ XI_ConvertString("Colony" + pchar.GWIK.Job.PirateCity + "Gen") +" – il charge encore sa cargaison, mais il prendra la mer d'ici un jour ou deux. Interceptez-le et abordez-le : la Compagnie ajoutera une prime de "+ FindRussianMoneyString(jobRansomPay) +". Mais si vous l'envoyez par le fond, vous noierez aussi le captif.";
				link.l1 = "Je le trouverai et je l'aborderai.";
				link.l1.go = "exit";
				break;
			}
			GWIK_StartRansomJob();
			if (!CheckAttribute(pchar, "GWIK.Job.Mutiny") && !CheckAttribute(pchar, "GWIK.Job.CaptiveDead")) // Gregg: mutually exclusive rare twists of the mediator variant (unless forced by beta)
			{
				if (drand1(19) == 0) pchar.GWIK.Job.Mutiny = true; // ~1/20 (drand1 - own stream): there's no captive, the captain turned pirate himself (you learn it from the 'go-between' on Bermuda)
				else if (drand3(9) == 0) pchar.GWIK.Job.CaptiveDead = true; // ~1/10 (drand3 - own stream): the captive will be killed for insolence; you learn it from the mediator (failure with a token compensation)
			}
			ReOpenQuestHeader("GWIK_RansomJob");
			AddQuestRecord("GWIK_RansomJob", "1");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(jobRansom));
			AddQuestUserData("GWIK_RansomJob", "sBonus", FindRussianMoneyString(jobRansomPay));
			dialog.text = "Souvenez-vous : la taverne du repaire pirate des Bermudes, la rançon est de "+ FindRussianMoneyString(jobRansom) +", à payer de vos propres fonds. La Compagnie vous remboursera tout dès que notre homme aura atteint l'un de nos comptoirs. Bonne chance, capitaine.";
			link.l1 = "Votre capitaine sera bientכt ici.";
			link.l1.go = "exit";
		break;

		case "Job_RivalGo":
			DeleteAttribute(pchar, "GWIK.JobOffer");
			sJobCity = findRivalCity_GWIK(NPChar);
			pchar.GWIK.Job = "rival";
			ok = false;
			if (sJobCity != "none") ok = GWIK_SpawnRival(sJobCity);
			if (!ok)
			{
				// no suitable spot found - replace with a mail run
				pchar.GWIK.Job = "mail";
				pchar.GWIK.Job.Target = sPartnerId;
				sJobCity = GWIK_OfficeCityById(sPartnerId);
				pchar.GWIK.Job.Pay = jobMailPay;
				SaveCurrentNpcQuestDateParam(pchar, "GWIK.Job.Date");
				PlayStereoSound("notebook");
				ReOpenQuestHeader("GWIK_MailJob");
				AddQuestRecord("GWIK_MailJob", "1");
				AddQuestUserData("GWIK_MailJob", "sCity", XI_ConvertString("Colony" + sJobCity + "Voc")); // Gregg: та же запись #1 при подмене поручения - предложный
				AddQuestUserData("GWIK_MailJob", "sMoney", FindRussianMoneyString(jobMailPay));
				dialog.text = "Hum... les circonstances ont changé, le navire de nos rivaux est déjà parti. Mais puisque vous êtes là, livrez un paquet à notre comptoir "+ sPartner +", la rémunération est de "+ FindRussianMoneyString(jobMailPay) +". Le paquet est déjà parmi vos papiers.";
				link.l1 = "D'accord.";
				link.l1.go = "exit";
				break;
			}
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.Job.Date");
			pchar.GWIK.Job.Pay = jobRivalPay;
			ReOpenQuestHeader("GWIK_RivalJob");
			if (CheckAttribute(pchar, "GWIK.Job.RivalLand")) // Gregg: land variant - the target is not a ship but a man in a colony tavern
			{
				AddQuestRecord("GWIK_RivalJob", "6");
				AddQuestUserData("GWIK_RivalJob", "sCity", XI_ConvertString("Colony" + pchar.GWIK.Job.City + "Voc")); // Gregg: запись #6 говорит «в <городе> обосновался» - предложный (в записи #1 та же переменная идёт после «в водах», там родительный)
				AddQuestUserData("GWIK_RivalJob", "sName", pchar.GWIK.Job.RivalName);
				AddQuestUserData("GWIK_RivalJob", "sMoney", FindRussianMoneyString(jobRivalPay));
				dialog.text = "Cette fois, l'affaire ne se passe pas en mer. Leur homme, "+ pchar.GWIK.Job.RivalName +", est installé à la taverne de "+ XI_ConvertString("Colony" + pchar.GWIK.Job.City + "Gen") +" et, de là, il casse tous nos prix. Lui-même ne prend jamais la mer : c'est quelqu'un de prudent. Le reste vous regarde, la Compagnie ne posera pas de questions.";
				// Gregg: a hint about the charter - otherwise nobody will find the prize on the body. The attribute is set in GWIK_SpawnRivalLand only when the player holds no licence of their own
				if (CheckAttribute(pchar, "GWIK.Job.RivalLicence")) dialog.text = dialog.text + " Et voici le plus curieux : il commerce sous notre propre charte, obtenue par des intermédiaires. Il porte le document sur lui. S'il ne nous revenait jamais, la Compagnie s'en remettrait.";
				link.l1 = "Je le trouverai.";
				link.l1.go = "exit";
				break;
			}
			AddQuestRecord("GWIK_RivalJob", "1");
			AddQuestUserData("GWIK_RivalJob", "sCity", XI_ConvertString("Colony" + pchar.GWIK.Job.City + "Gen"));
			AddQuestUserData("GWIK_RivalJob", "sShip", GWIK_RivalShipStr()); // Gregg: type + ship name
			AddQuestUserData("GWIK_RivalJob", "sMoney", FindRussianMoneyString(jobRivalPay));
			dialog.text = "Nos gens ont vu leur navire : "+ GWIK_RivalShipStr() +" - "+ GWIK_JobPlaceStr() +". Le reste vous regarde, la Compagnie ne posera pas de questions. Et dépêchez-vous : il ne restera pas là longtemps.";
			link.l1 = "Considérez-le comme déjà coulé.";
			link.l1.go = "exit";
		break;

		case "Job_Drop":
			if (pchar.GWIK.Job == "mail")
			{
				GWIK_MailAgentCleanup(); // Gregg: remove the 'hot parcel' agent if any
				AddQuestRecord("GWIK_MailJob", "4");
				CloseQuestHeader("GWIK_MailJob");
			}
			if (pchar.GWIK.Job == "ransom")
			{
				AddQuestRecord("GWIK_RansomJob", "4");
				CloseQuestHeader("GWIK_RansomJob");
				GWIK_FinishRansomJob();
			}
			if (pchar.GWIK.Job == "rival")
			{
				AddQuestRecord("GWIK_RivalJob", "5");
				CloseQuestHeader("GWIK_RivalJob");
				GWIK_DropRivalJob();
			}
			DeleteAttribute(pchar, "GWIK.Job"); // for mail; the others are already cleaned up
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Dommage. La Compagnie préfère les capitaines qui vont jusqu'au bout.";
			link.l1 = "Les circonstances sont plus fortes que moi. Au revoir.";
			link.l1.go = "exit";
		break;

		case "Job_MailDone":
			ok = (GetNpcQuestPastDayParam(pchar, "GWIK.Job.Date") <= 12);
			cash = jobMailPay;
			if (CheckAttribute(pchar, "GWIK.Job.Pay")) cash = sti(pchar.GWIK.Job.Pay); // the sum promised at the briefing
			// Gregg: slipped the interception and carried the parcel through without ever talking to the agent - a full outcome,
			// not "the content failed to fire". Flags read BEFORE the cleanup: GWIK.Job is deleted below. Separate ifs - Storm will not compile a compound assignment with CheckAttribute
			bDodged = false;
			if (CheckAttribute(pchar, "GWIK.Job.HotDodge")) bDodged = true;
			if (CheckAttribute(pchar, "GWIK.Job.HotResolved")) bDodged = false; // the talk did happen after all - ordinary outcome
			GWIK_MailAgentCleanup(); // Gregg: remove the 'hot parcel' agent if left over (BEFORE deleting GWIK.Job - it reads MailAgentId)
			DeleteAttribute(pchar, "GWIK.Job");
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			PlayStereoSound("notebook");
			if (ok)
			{
				AddMoneyToCharacter(pchar, cash);
				GWIK_AddRep(10); // Gregg: reputation for mail delivered on time
				AddCharacterExpToSkill(pchar, SKILL_SAILING, 40);    // Gregg: navigation xp for a courier run delivered on time
				AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 15); // Gregg: and a little command xp for the completed Company job
				AddQuestRecord("GWIK_MailJob", "2");
				AddQuestUserData("GWIK_MailJob", "sCity", XI_ConvertString("Colony" + NPChar.city + "Voc")); // Gregg: запись #2 говорит «контора в <городе>» - предложный
				AddQuestUserData("GWIK_MailJob", "sMoney", FindRussianMoneyString(cash));
				CloseQuestHeader("GWIK_MailJob");
				dialog.text = "Sceaux intacts, délai respecté : c'est un plaisir de traiter avec un professionnel. Voici vos "+ FindRussianMoneyString(cash) +".";
			}
			else
			{
				AddMoneyToCharacter(pchar, makeint(cash / 2));
				AddQuestRecord("GWIK_MailJob", "3");
				AddQuestUserData("GWIK_MailJob", "sMoney", FindRussianMoneyString(makeint(cash / 2)));
				CloseQuestHeader("GWIK_MailJob");
				dialog.text = "Les sceaux sont intacts, mais vous êtes en retard, capitaine. La Compagnie paie la moitié : "+ FindRussianMoneyString(makeint(cash / 2)) +". Soyez plus rapide la prochaine fois.";
			}
			if (bDodged) // Gregg: the parcel was hot, yet the rivals' men never got near you - the Company knows and appreciates it
			{
				GWIK_AddRep(3);
				ReOpenQuestHeader("GWIK_MailJob"); // appending to an already closed header works (as with the Heeren XVII letter)
				AddQuestRecord("GWIK_MailJob", "9");
				CloseQuestHeader("GWIK_MailJob");
				dialog.text = dialog.text + " Et encore une chose, capitaine : des hommes sans aucun lien avec la Compagnie se renseignaient sur ce paquet. Vous n'avez pas pris le temps de faire leur connaissance, et c'est tant mieux.";
			}
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Job_RansomDone":
			cash = sti(pchar.GWIK.Job.Ransom) + jobRansomPay;
			if (CheckAttribute(pchar, "GWIK.Job.Bonus")) cash = sti(pchar.GWIK.Job.Ransom) + sti(pchar.GWIK.Job.Bonus); // the sums promised at the briefing
			ok = CheckAttribute(pchar, "GWIK.Job.Force"); // taken by force - no ransom paid, bonus plus a premium
			bMutiny = CheckAttribute(pchar, "GWIK.Job.Mutiny"); // Gregg: capture BEFORE GWIK_FinishRansomJob deletes GWIK.Job, else the mutiny delivery text below never fires
			if (ok)
			{
				cash = jobRansomPay;
				if (CheckAttribute(pchar, "GWIK.Job.Bonus")) cash = sti(pchar.GWIK.Job.Bonus);
				cash = makeint(cash * 125 / 100); // +25% for the combat risk
			}
			AddMoneyToCharacter(pchar, cash);
			GWIK_FinishRansomJob();
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			PlayStereoSound("notebook");
			GWIK_AddRep(13); // Gregg: reputation for the delivered captain
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 30); // Gregg: command xp for the returned captain (force-path combat xp already granted at sea)
			if (bMutiny) AddQuestRecord("GWIK_RansomJob", "21"); // Gregg: mutiny - dragged the runaway back by force, no ransom; own record without "reimbursed the ransom"
			else AddQuestRecord("GWIK_RansomJob", "3");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RansomJob");
			dialog.text = "Vous nous avez ramené l'un des meilleurs capitaines de la Compagnie ! Voici le remboursement de la rançon et la prime promise : "+ FindRussianMoneyString(cash) +" au total. La Compagnie n'oublie pas de tels services.";
			if (ok) dialog.text = "Vous avez arraché notre capitaine aux pirates par la force, sans la moindre rançon ? Audacieux, et méritoire ! Pour votre hardiesse, la Compagnie vous verse la prime promise, avec un supplément : "+ FindRussianMoneyString(cash) +" en tout. La Compagnie apprécie les gens comme vous.";
			if (ok && bMutiny) dialog.text = "Vous avez ramené notre fugitif aux fers ? Eh bien, le traître l'a bien cherché. Pour votre hardiesse, la prime avec un supplément : "+ FindRussianMoneyString(cash) +" en tout. La Compagnie s'occupera de lui désormais.";
			link.l1 = "Ce fut un plaisir d'aider. Au revoir !";
			link.l1.go = "exit";
		break;

		case "GWIK_RansomDeadReport": // Gregg: report the captive's death - paid by the COMPANY (not the pirate), a token compensation for the trouble, no rep penalty
			cash = 2000 + sti(pchar.rank) * 200;
			AddMoneyToCharacter(pchar, cash);
			AddQuestRecord("GWIK_RansomJob", "11");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RansomJob");
			GWIK_FinishRansomJob(); // remove the mediator + GWIK.Job (we're speaking to the office rep, not the mediator - safe)
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Je suis navré de l'apprendre. Enfin, les pirates sont les pirates : ce n'est pas votre faute, capitaine. Voici un petit quelque chose pour votre peine : "+ FindRussianMoneyString(cash) +". La Compagnie se souvient de ceux qui ont essayé.";
			link.l1 = "Merci. Au revoir.";
			link.l1.go = "exit";
		break;

		case "GWIK_MutinyReturnReport": // Gregg: the runaway returned to the Company on his own (successful persuasion) - a positive report: bonus + reputation, no ransom, no battle
			cash = jobRansomPay;
			if (CheckAttribute(pchar, "GWIK.Job.Bonus")) cash = sti(pchar.GWIK.Job.Bonus);
			AddMoneyToCharacter(pchar, cash);
			GWIK_FinishRansomJob(); // remove the runaway from the tavern + GWIK.Job (we're speaking to the office rep, not to him - safe)
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			PlayStereoSound("notebook");
			GWIK_AddRep(13); // Gregg: reputation for the returned captain
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 30); // Gregg: command xp for bringing the runaway to his senses
			AddQuestRecord("GWIK_RansomJob", "17");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RansomJob");
			dialog.text = "Ah, c'est donc vous que je dois remercier ? Notre capitaine s'est bien rendu de lui-même : il a dit que vous l'aviez ramené à la raison. La Compagnie fermera les yeux sur son égarement, et vous recevez la prime promise : "+ FindRussianMoneyString(cash) +". Régler les affaires sans effusion de sang est un don rare.";
			link.l1 = "Ce fut un plaisir d'aider. Au revoir !";
			link.l1.go = "exit";
		break;

		case "GWIK_MutineerKilledReport": // Gregg: the runaway resisted and was cut down aboard his ship - a bounty for stopping the traitor; no prisoner, no rep penalty
			cash = 3000 + sti(pchar.rank) * 300;
			AddMoneyToCharacter(pchar, cash);
			AddQuestRecord("GWIK_RansomJob", "20");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RansomJob");
			GWIK_FinishRansomJob();
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			GWIK_AddRep(8); // Gregg: small reputation for stopping the defector (the Company would have preferred him alive)
			dialog.text = "Vous l'avez abattu, hein ? Une triste fin, mais un renégat qui court chez les pirates ne mérite pas mieux. Nous l'aurions préféré vivant, pour faire un exemple... Enfin, voici une prime pour votre peine : "+ FindRussianMoneyString(cash) +". L'affaire est close.";
			link.l1 = "Merci. Au revoir.";
			link.l1.go = "exit";
		break;

		case "GWIK_MutinyReport": // Gregg: report that the captain turned pirate and refused to return - a token compensation for the trouble, no rep penalty
			cash = 2000 + sti(pchar.rank) * 200;
			AddMoneyToCharacter(pchar, cash);
			AddQuestRecord("GWIK_RansomJob", "16");
			AddQuestUserData("GWIK_RansomJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RansomJob");
			GWIK_FinishRansomJob(); // remove the runaway from the tavern + GWIK.Job (we're speaking to the office rep, not to him - safe)
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			dialog.text = "Il a retourné sa veste, alors... Dommage, mais ça arrive : on ne peut pas retenir tout le monde. Ce n'est pas votre faute, capitaine. Voici un petit quelque chose pour votre peine : "+ FindRussianMoneyString(cash) +". La Compagnie s'occupera elle-même du déserteur.";
			link.l1 = "Merci. Au revoir.";
			link.l1.go = "exit";
		break;

		case "Job_RivalDone":
			cash = jobRivalPay;
			if (CheckAttribute(pchar, "GWIK.Job.Pay")) cash = sti(pchar.GWIK.Job.Pay); // the sum promised at the briefing
			AddMoneyToCharacter(pchar, cash);
			pchar.quest.GWIK_RivalDead.over = "yes";
			pchar.quest.GWIK_RivalGone.over = "yes";
			DeleteAttribute(pchar, "GWIK.Job");
			SaveCurrentNpcQuestDateParam(pchar, "GWIK.JobDate");
			PlayStereoSound("notebook");
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 30); // Gregg: command xp for the covert operation (the sinking already granted combat xp)
			AddQuestRecord("GWIK_RivalJob", "3"); // user data strictly after the record
			AddQuestUserData("GWIK_RivalJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_RivalJob");
			dialog.text = "La Compagnie sait se montrer reconnaissante... et discrète. Voici vos "+ FindRussianMoneyString(cash) +". Cette conversation, bien entendu, n'a jamais eu lieu.";
			link.l1 = "Quelle conversation ? Au revoir.";
			link.l1.go = "exit";
		break;

		case "Job_ConvoyBonus":
			cash = sti(pchar.GWIK.ConvoyBonus);
			AddMoneyToCharacter(pchar, cash);
			DeleteAttribute(pchar, "GWIK.ConvoyBonus");
			PlayStereoSound("notebook");
			AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 25); // Gregg: command xp for an exemplary escort (sea skills already granted by the base convoy quest)
			AddQuestRecord("GWIK_ConvoyJob", "3"); // Gregg: journal - bonus collected
			AddQuestUserData("GWIK_ConvoyJob", "sMoney", FindRussianMoneyString(cash));
			CloseQuestHeader("GWIK_ConvoyJob");
			dialog.text = "Notre capitaine a déjà fait son rapport au comptoir : l'escorte a été exemplaire. Voici la prime promise par la Compagnie : "+ FindRussianMoneyString(cash) +".";
			link.l1 = "Un plaisir de travailler avec la Compagnie. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Subscribe_Ask":
			if (!CheckAttribute(pchar,"GWIK.Subscription"))
			{
				dialog.text = "Bien sמr, capitaine. Un abonnement mensuel : tous les cinq jours, notre courrier vous apportera un relevé de prix à jour pour tout l'archipel, oם que vous soyez. Le prix est de "+ FindRussianMoneyString(subPrice) +", et le premier relevé vous est remis tout de suite. דa vous intéresse ?";
			}
			else
			{
				dialog.text = "Prolonger l'abonnement d'un mois vous coמtera la même somme : "+ FindRussianMoneyString(subPrice) +". On y va ?";
			}
			if (sti(pchar.money) >= subPrice)
			{
				link.l1 = "Oui, voici l'argent.";
				link.l1.go = "Subscribe_Buy";
			}
			else
			{
				link.l1 = "Hum, je n'ai pas autant sur moi...";
				link.l1.go = "Meet_2";
			}
			link.l2 = "Non, je m'en passerai.";
			link.l2.go = "Meet_2";
		break;

		case "Subscribe_Buy":
			AddMoneyToCharacter(pchar, -subPrice);
			PlayStereoSound("notebook");
			if (CheckAttribute(pchar,"GWIK.Subscription"))
			{
				pchar.GWIK.Subscription = sti(pchar.GWIK.Subscription) + 30;
				dialog.text = "C'est fait, votre abonnement est prolongé. Les courriers de la Compagnie ne vous feront pas attendre.";
			}
			else
			{
				pchar.GWIK.Subscription = 30;
				SetTimerFunction("GWIK_SubscriptionTick", 0, 0, 5);
				GWIK_RefreshAllPrices();
				log_info("Vous avez reçu une liste des prix de tous les magasins de l'archipel des Caraïbes.");
				dialog.text = "Tout est prêt ! Voici votre premier relevé, les suivants vous seront livrés tous les cinq jours. Bon commerce, capitaine !";
			}
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Contract_Info":
			iGood = sti(NPChar.GWIK.Contract.Good);
			cQty = sti(NPChar.GWIK.Contract.Qty);
			cPrice = sti(NPChar.GWIK.Contract.Price);
			if (cQty <= 0)
			{
				dialog.text = "Le contrat d'achat actuel a déjà été rempli, et pas sans votre aide, capitaine. La Compagnie enverra une nouvelle liste de besoins d'ici deux jours.";
				link.l1 = "Je repasserai plus tard.";
				link.l1.go = "Meet_2";
				break;
			}
			cCargo = GetSquadronGoods(pchar, iGood); // Gregg: count the holds of the whole squadron, as with confiscated-goods purchase
			dialog.text = "La Compagnie achète : "+ XI_ConvertString(Goods[iGood].name) +", "+ cQty +" unités à "+ FindRussianMoneyString(cPrice) +" l'unité, bien au-dessus du prix du marché. Les cales de votre escadre en contiennent actuellement "+ cCargo +" unités.";
			if (cCargo > 0)
			{
				link.l1 = "Excellent, je livre tout de suite.";
				link.l1.go = "Contract_Sell";
			}
			link.l2 = "C'est noté. Merci pour l'information.";
			link.l2.go = "Meet_2";
		break;

		case "Contract_Sell":
			iGood = sti(NPChar.GWIK.Contract.Good);
			cQty = sti(NPChar.GWIK.Contract.Qty);
			cPrice = sti(NPChar.GWIK.Contract.Price);
			cCargo = GetSquadronGoods(pchar, iGood); // Gregg: total across the squadron
			sell = cCargo;
			if (sell > cQty) sell = cQty;
			if (sell <= 0)
			{
				dialog.text = "Hum, il n'y a pas une seule unité de la marchandise demandée dans les cales de votre escadre, capitaine.";
				link.l1 = "Erreur de ma part, je vous prie de m'excuser.";
				link.l1.go = "Meet_2";
				break;
			}
			GWIK_RemoveGoodsSquadron(pchar, iGood, sell); // Gregg: remove in cascade - flagship, then squadron ships
			AddMoneyToCharacter(pchar, sell * cPrice);
			NPChar.GWIK.Contract.Qty = cQty - sell;
			PlayStereoSound("notebook");
			if (cQty - sell <= 0)
			{
				SaveCurrentNpcQuestDateParam(NPChar, "GWIK.ContractDate"); // countdown to the next contract
				GWIK_AddRep(10); // Gregg: reputation for a fully closed contract
				AddCharacterExpToSkill(pchar, SKILL_COMMERCE, 40);   // Gregg: trade xp for a fully closed contract (turn-in pays via direct AddMoney, bypassing the trade engine)
				AddCharacterExpToSkill(pchar, SKILL_LEADERSHIP, 10); // Gregg: and a little command xp for the completed job
				dialog.text = "Reçu : "+ sell +" unités, voici vos "+ FindRussianMoneyString(sell * cPrice) +". Le contrat est entièrement soldé : la Compagnie apprécie les fournisseurs comme vous ! Une nouvelle commande arrivera d'ici deux jours.";
			}
			else
			{
				dialog.text = "Reçu : "+ sell +" unités, voici vos "+ FindRussianMoneyString(sell * cPrice) +". La Compagnie est prête à acheter "+ (cQty - sell) +" unités de plus au même prix.";
			}
			link.l1 = "Un plaisir de faire affaire avec vous. Au revoir !";
			link.l1.go = "exit";
			link.l2 = "Autre chose ?";
			link.l2.go = "Meet_2";
		break;

		case "Auction_Info":
			bPrimary = false;
			if (CheckAttribute(NPChar,"GWIK.Auction") && !CheckAttribute(NPChar,"GWIK.Auction.SoldOut")) bPrimary = true;
			bExtra = false;
			if (shareLvl >= 2 && CheckAttribute(NPChar,"GWIK.AuctionExtra") && !CheckAttribute(NPChar,"GWIK.AuctionExtra.SoldOut")) bExtra = true;
			bElite = false; // Gregg: Companion exclusive - rare DAILY offer (drand, F9-proof); map and spyglass never on the same day (one drand(29), different check values)
			if (shareLvl >= 3 && GetCharacterItem(pchar,"map_full") < 1 && drand(29) == 0) bElite = true;
			if (shareLvl >= 3 && GetCharacterItem(pchar,"spyglass5") < 1 && drand(29) == 15) bElite = true;
			if (!bPrimary && !bExtra && !bElite)
			{
				dialog.text = "Hélas, le lot du jour est déjà vendu. Des marchandises confisquées arrivent régulièrement : repassez dans quelques jours.";
				link.l1 = "Je n'y manquerai pas.";
				link.l1.go = "Meet_2";
				break;
			}
			if (bPrimary)
			{
				if (NPChar.GWIK.Auction == "goods")
				{
					iGood = sti(NPChar.GWIK.Auction.Good);
					aQty = sti(NPChar.GWIK.Auction.Qty);
					aPrice = sti(NPChar.GWIK.Auction.Price);
					dialog.text = "Aujourd'hui, on met aux enchères une cargaison confisquée : "+ XI_ConvertString(Goods[iGood].name) +", "+ aQty +" unités à "+ FindRussianMoneyString(aPrice) +" l'unité, bien en dessous du prix du marché. Le lot entier vous coמtera "+ FindRussianMoneyString(aQty * aPrice) +".";
					if (sti(pchar.money) >= aPrice)
					{
						link.l1 = "Je le prends ! Autant qu'il en tient dans la cale.";
						link.l1.go = "Auction_BuyGoods";
					}
				}
				else
				{
					rItem = ItemsFromID(NPChar.GWIK.Auction.Item);
					aPrice = sti(NPChar.GWIK.Auction.Price);
					sItemName = GetConvertStr(rItem.name, "ItemsDescribe.txt");
					dialog.text = "Aujourd'hui, on met aux enchères un objet confisqué dans la cabine d'un capitaine : "+ sItemName +". Le prix : "+ FindRussianMoneyString(aPrice) +", bien en dessous de ce que demandent les boutiques.";
					if (sti(pchar.money) >= aPrice)
					{
						link.l1 = "Je le prends, sans poser de questions !";
						link.l1.go = "Auction_BuyItem";
					}
				}
			}
			else
			{
				if (bExtra) dialog.text = "Le lot principal est déjà parti, mais la Compagnie en a mis un autre de cכté pour ses actionnaires.";
				else dialog.text = "Les marchandises confisquées du jour sont toutes réservées, mais la Compagnie garde toujours quelque chose de spécial pour ses plus proches partenaires.";
			}
			if (bExtra)
			{
				link.l3 = "Qu'est-ce qui est réservé aux actionnaires ?";
				link.l3.go = "Auction_InfoExtra";
			}
			if (bElite)
			{
				link.l4 = "Que garde la Compagnie pour ses plus proches partenaires ?";
				link.l4.go = "Auction_Elite";
			}
			link.l2 = "Non, je n'en ai pas besoin.";
			link.l2.go = "Meet_2";
		break;

		case "Auction_InfoExtra":
			if (!CheckAttribute(NPChar,"GWIK.AuctionExtra") || CheckAttribute(NPChar,"GWIK.AuctionExtra.SoldOut"))
			{
				dialog.text = "Ce lot a déjà été vendu, capitaine.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			if (NPChar.GWIK.AuctionExtra == "goods")
			{
				iGood = sti(NPChar.GWIK.AuctionExtra.Good);
				aQty = sti(NPChar.GWIK.AuctionExtra.Qty);
				aPrice = sti(NPChar.GWIK.AuctionExtra.Price);
				dialog.text = "Pour les actionnaires, une cargaison de plus : "+ XI_ConvertString(Goods[iGood].name) +", "+ aQty +" unités à "+ FindRussianMoneyString(aPrice) +" l'unité. Le lot entier : "+ FindRussianMoneyString(aQty * aPrice) +".";
				if (sti(pchar.money) >= aPrice)
				{
					link.l1 = "Je le prends ! Autant qu'il en tient dans la cale.";
					link.l1.go = "Auction_BuyGoodsExtra";
				}
			}
			else
			{
				rItem = ItemsFromID(NPChar.GWIK.AuctionExtra.Item);
				aPrice = sti(NPChar.GWIK.AuctionExtra.Price);
				sItemName = GetConvertStr(rItem.name, "ItemsDescribe.txt");
				dialog.text = "Pour les actionnaires, un objet de plus provenant de la cabine d'un capitaine : "+ sItemName +". Le prix : "+ FindRussianMoneyString(aPrice) +".";
				if (sti(pchar.money) >= aPrice)
				{
					link.l1 = "Je le prends, sans poser de questions !";
					link.l1.go = "Auction_BuyItemExtra";
				}
			}
			link.l2 = "Non, je n'en ai pas besoin.";
			link.l2.go = "Meet_2";
		break;

		case "Auction_BuyGoods":
			iGood = sti(NPChar.GWIK.Auction.Good);
			aQty = sti(NPChar.GWIK.Auction.Qty);
			aPrice = sti(NPChar.GWIK.Auction.Price);
			toBuy = makeint(sti(pchar.money) / aPrice); // how much we can afford
			if (toBuy > aQty) toBuy = aQty;
			added = GWIK_LoadGoodsSquadron(pchar, iGood, toBuy); // how much fits in the holds of the flagship and squadron
			if (added <= 0)
			{
				dialog.text = "J'ai bien peur qu'il ne reste plus de place dans votre cale, même pour un seul sac, capitaine. Dommage, c'est un beau lot.";
				link.l1 = "Dommage, en effet...";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -(added * aPrice));
			PlayStereoSound("notebook");
			if (added < aQty)
			{
				NPChar.GWIK.Auction.Qty = aQty - added; // Gregg: the remainder of the lot stays on sale instead of burning
				dialog.text = "Votre cale a pris "+ added +" unités, soit "+ FindRussianMoneyString(added * aPrice) +". La Compagnie vous garde le reste du lot ("+ (aQty - added) +" unités).";
			}
			else
			{
				NPChar.GWIK.Auction.SoldOut = true;
				dialog.text = "Le lot entier est à vous, capitaine : "+ added +" unités pour "+ FindRussianMoneyString(added * aPrice) +". Une excellente affaire !";
			}
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Auction_BuyItem":
			aPrice = sti(NPChar.GWIK.Auction.Price);
			if (sti(pchar.money) < aPrice)
			{
				dialog.text = "Vous n'avez pas assez d'argent, capitaine.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -aPrice);
			GiveItem2Character(pchar, NPChar.GWIK.Auction.Item);
			NPChar.GWIK.Auction.SoldOut = true;
			PlayStereoSound("notebook");
			dialog.text = "Félicitations pour votre achat ! La pièce est en état de marche : son ancien propriétaire, hélas, n'est plus en mesure de se plaindre.";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Auction_BuyGoodsExtra":
			iGood = sti(NPChar.GWIK.AuctionExtra.Good);
			aQty = sti(NPChar.GWIK.AuctionExtra.Qty);
			aPrice = sti(NPChar.GWIK.AuctionExtra.Price);
			toBuy = makeint(sti(pchar.money) / aPrice); // how much we can afford
			if (toBuy > aQty) toBuy = aQty;
			added = GWIK_LoadGoodsSquadron(pchar, iGood, toBuy); // how much fits in the holds of the flagship and squadron
			if (added <= 0)
			{
				dialog.text = "J'ai bien peur qu'il ne reste plus de place dans votre cale, même pour un seul sac, capitaine. Dommage, c'est un beau lot.";
				link.l1 = "Dommage, en effet...";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -(added * aPrice));
			PlayStereoSound("notebook");
			if (added < aQty)
			{
				NPChar.GWIK.AuctionExtra.Qty = aQty - added; // Gregg: the remainder of the lot stays on sale instead of burning
				dialog.text = "Votre cale a pris "+ added +" unités, soit "+ FindRussianMoneyString(added * aPrice) +". La Compagnie vous garde le reste du lot ("+ (aQty - added) +" unités).";
			}
			else
			{
				NPChar.GWIK.AuctionExtra.SoldOut = true;
				dialog.text = "Le lot entier est à vous, capitaine : "+ added +" unités pour "+ FindRussianMoneyString(added * aPrice) +". Une excellente affaire !";
			}
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Auction_BuyItemExtra":
			aPrice = sti(NPChar.GWIK.AuctionExtra.Price);
			if (sti(pchar.money) < aPrice)
			{
				dialog.text = "Vous n'avez pas assez d'argent, capitaine.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -aPrice);
			GiveItem2Character(pchar, NPChar.GWIK.AuctionExtra.Item);
			NPChar.GWIK.AuctionExtra.SoldOut = true;
			PlayStereoSound("notebook");
			dialog.text = "Félicitations pour votre achat ! La pièce est en état de marche : son ancien propriétaire, hélas, n'est plus en mesure de se plaindre.";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Auction_Elite": // Gregg: exclusive lots for the Company's partners (share lvl 3)
			bMap = false;
			if (GetCharacterItem(pchar,"Map_Best") < 1 && drand(29) == 0) bMap = true;
			bTube = false;
			if (GetCharacterItem(pchar,"spyglass5") < 1 && drand(29) == 15) bTube = true;
			bTreasure = false;
			if (GetCharacterItem(pchar,"map_full") < 1 && drand(29) == 28) bTreasure = true;
			if (!bMap && !bTube && !bTreasure)
			{
				dialog.text = "Vous avez déjà pris tout ce que la Compagnie gardait pour ses partenaires, capitaine.";
				link.l1 = "Compris. Au revoir.";
				link.l1.go = "Meet_2";
				break;
			}
			dialog.text = "Pour les partenaires de la Compagnie, des pièces tirées de réserves spéciales, jamais mises en vente au tout-venant :";
			if (bMap)
			{
				link.l1 = "La carte complète de l'archipel : 500000 piastres.";
				link.l1.go = "Auction_BuyMap";
			}
			if (bTube)
			{
				link.l2 = "Une longue-vue exclusive : 350000 piastres.";
				link.l2.go = "Auction_BuyTube";
			}
			if (bTreasure)
			{
				link.l2 = "Une carte au trésor : 30000 piastres.";
				link.l2.go = "Auction_BuyTreasure";
			}
			link.l3 = "Une autre fois.";
			link.l3.go = "Meet_2";
		break;

		case "Auction_BuyMap":
			if (sti(pchar.money) < 500000)
			{
				dialog.text = "Vous n'avez pas autant sur vous, capitaine. La carte coמte 500000 piastres.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -500000);
			GiveItem2Character(pchar, "Map_Best");
			PlayStereoSound("notebook");
			dialog.text = "Excellent choix ! Cette carte a été dessinée par les meilleurs cartographes de la Compagnie : tout l'archipel, jusqu'au dernier haut-fond et au dernier récif. Gardez-la précieusement.";
			link.l1 = "Inestimable. Merci !";
			link.l1.go = "exit";
		break;

		case "Auction_BuyTube":
			if (sti(pchar.money) < 350000)
			{
				dialog.text = "Vous n'avez pas autant sur vous, capitaine. La longue-vue coמte 350000 piastres.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -350000);
			GiveItem2Character(pchar, "spyglass5");
			PlayStereoSound("notebook");
			dialog.text = "Une belle pièce ! Ce genre de longue-vue se fabrique à l'unité : à travers elle, vous distinguerez même les améliorations du navire d'autrui. Une grande rareté.";
			link.l1 = "Exactement ce qu'il me fallait. Merci !";
			link.l1.go = "exit";
		break;
		
		case "Auction_BuyTreasure":
			if (sti(pchar.money) < 30000)
			{
				dialog.text = "Vous n'avez pas autant sur vous, capitaine. La carte coמte 30000 piastres.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -30000);
			GiveItem2Character(pchar, "map_full");
			PlayStereoSound("notebook");
			dialog.text = "Excellent choix ! J'espère que vous y trouverez un beau butin.";
			link.l1 = "Merci !";
			link.l1.go = "exit";
		break;

		case "Bill_Ask":
			dialog.text = "Le service des lettres de change de la Compagnie est à votre disposition. Vous déposez une somme ici, et vous recevez une lettre au porteur payable dans n'importe lequel de nos autres comptoirs. Inutile de risquer de transporter de l'or dans des eaux infestées de pirates. La commission est de "+ billFee +" % à l'émission, la somme minimale est de 10000 piastres. Combien déposons-nous ?";
			link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "Bill_Calc";
			link.l2 = "J'ai changé d'avis. Une autre fois.";
			link.l2.go = "Meet_2";
		break;

		case "Bill_Calc":
			billSum = sti(dialogEditStrings[1]);
			if (billSum < 10000)
			{
				dialog.text = "On ne peut pas tirer une lettre de change de moins de 10000 piastres, capitaine. Proposez une autre somme.";
				link.l1 = "D'accord, essayons encore.";
				link.l1.go = "Bill_Ask";
				link.l2 = "Alors, laissons tomber.";
				link.l2.go = "Meet_2";
				break;
			}
			if (sti(pchar.money) < billSum)
			{
				dialog.text = "Vous n'avez pas autant sur vous, capitaine. Proposez une somme plus modeste.";
				link.l1 = "D'accord, essayons encore.";
				link.l1.go = "Bill_Ask";
				link.l2 = "Alors, laissons tomber.";
				link.l2.go = "Meet_2";
				break;
			}
			billPay = billSum - makeint(billSum * billFee / 100);
			dialog.text = "Vous déposez "+ FindRussianMoneyString(billSum) +", et "+ FindRussianMoneyString(billPay) +" vous seront versés dans n'importe lequel de nos autres comptoirs. Je l'établis ?";
			link.l1 = "Oui, voici l'argent.";
			link.l1.go = "Bill_Buy";
			link.l2 = "Non, j'ai changé d'avis.";
			link.l2.go = "Meet_2";
		break;

		case "Bill_Buy":
			billSum = sti(dialogEditStrings[1]);
			if (billSum < 10000 || sti(pchar.money) < billSum)
			{
				dialog.text = "Quelque chose ne colle pas, capitaine. Recommençons.";
				link.l1 = "D'accord.";
				link.l1.go = "Bill_Ask";
				break;
			}
			AddMoneyToCharacter(pchar, -billSum);
			pchar.GWIK.Bill = billSum - makeint(billSum * billFee / 100);
			pchar.GWIK.Bill.From = NPChar.id;
			pchar.GWIK.Bill.Date = GetQuestBookDataDigit(); // printed in the ship's log
			PlayStereoSound("notebook");
			dialog.text = "C'est fait ! Une lettre de change de "+ FindRussianMoneyString(sti(pchar.GWIK.Bill)) +" est dans vos papiers, et l'inscription a été faite dans votre journal de bord. Présentez-la dans n'importe lequel de nos autres comptoirs, et on vous paiera jusqu'à la dernière pièce.";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Bill_Cash":
			cash = sti(pchar.GWIK.Bill);
			AddMoneyToCharacter(pchar, cash);
			DeleteAttribute(pchar, "GWIK.Bill");
			PlayStereoSound("notebook");
			dialog.text = "La lettre est parfaitement en règle. Voici vos "+ FindRussianMoneyString(cash) +", jusqu'à la dernière pièce, comme la Compagnie l'avait promis.";
			link.l1 = "Un plaisir de faire affaire avec vous. Au revoir !";
			link.l1.go = "exit";
		break;

		case "Bill_Where":
			dialog.text = "Votre lettre a été établie par ce comptoir-ci, elle sera payée dans n'importe lequel de nos autres comptoirs. Ce sont les règles de la Compagnie : sinon, à quoi bon transférer de l'argent ?";
			link.l1 = "C'est vrai, merci.";
			link.l1.go = "Meet_2";
		break;

		case "UniLicense_Ask":
			dialog.text = "La licence commerciale universelle de notre Compagnie vous permet d'entrer librement dans les villes de n'importe quelle nation, même hostile, du moment que votre navire arbore le pavillon de cette nation. Vous fixez vous-même la durée, mais pas moins de dix jours. Le prix est de "+ FindRussianMoneyString(uniPerDay) +" par jour. Pour combien de jours dois-je l'établir ?";
			link.l1.edit = 1;
			link.l1 = "";
			link.l1.go = "UniLicense_Calc";
			link.l2 = "J'ai changé d'avis. Une autre fois.";
			link.l2.go = "Meet_2";
		break;

		case "UniLicense_Calc":
			uniDays = sti(dialogEditStrings[1]);
			if (uniDays < 10)
			{
				dialog.text = "Je regrette, capitaine, mais je ne peux pas délivrer de licence pour moins de dix jours. Proposez une autre durée.";
				link.l1 = "D'accord, essayons encore.";
				link.l1.go = "UniLicense_Ask";
				link.l2 = "Alors, laissons tomber.";
				link.l2.go = "Meet_2";
				break;
			}
			if (uniDays > 3650) uniDays = 3650; // Gregg: upper cap of 10 years - guards against int overflow (negative price would credit money)
			uniPrice = uniDays * uniPerDay;
			if (sti(pchar.money) >= uniPrice)
			{
				dialog.text = "Une licence de "+ uniDays +" jours vous coמtera "+ FindRussianMoneyString(uniPrice) +". Je l'établis ?";
				link.l1 = "Oui, voici l'argent.";
				link.l1.go = "UniLicense_Buy";
			}
			else
			{
				dialog.text = "Une licence de "+ uniDays +" jours coמterait "+ FindRussianMoneyString(uniPrice) +", mais vous n'avez pas autant sur vous, capitaine.";
			}
			link.l2 = "Je vais changer la durée.";
			link.l2.go = "UniLicense_Ask";
			link.l3 = "א la réflexion, laissons tomber.";
			link.l3.go = "Meet_2";
		break;

		case "UniLicense_Buy":
			uniDays = sti(dialogEditStrings[1]);
			if (uniDays < 10) uniDays = 10;
			if (uniDays > 3650) uniDays = 3650; // Gregg: upper cap of 10 years - guards against int overflow
			uniPrice = uniDays * uniPerDay;
			if (sti(pchar.money) < uniPrice)
			{
				dialog.text = "Vous n'avez pas assez d'argent pour une telle licence, capitaine.";
				link.l1 = "Dommage.";
				link.l1.go = "Meet_2";
				break;
			}
			AddMoneyToCharacter(pchar, -uniPrice);
			GiveUniLicence(uniDays);
			PlayStereoSound("notebook");
			dialog.text = "C'est fait ! Voici votre licence commerciale universelle, valable "+ uniDays +" jours ; elle est maintenant dans vos papiers. Avec elle, vous pouvez entrer dans les villes de n'importe quelle nation, à condition d'arborer son pavillon. Bon commerce, capitaine !";
			link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
		break;

		case "trade_info":
			dialog.text = "Oui, j'ai ces informations, et je peux vous les communiquer. Cela fera "+ FindRussianMoneyString(price) +".";
			if (sti(pchar.money) >= price)
			{
				Link.l1 = "D'accord, voici votre argent.";
				link.l1.go = "trade_info_2";
			}
			Link.l2 = "J'ai changé d'avis. Bonne journée.";
			link.l2.go = "exit";
		break;

		case "trade_info_2":
			for (i = 0; i< MAX_COLONIES; i++)
			{
                ref rcolony = &Colonies[i];
			    if (rcolony.id != "Caiman" && rcolony.id != "Panama" && rcolony.nation != "none") SetPriceListByStoreMan(rcolony);
            }
			log_info("Vous avez reçu une liste des prix de tous les magasins de l'archipel des Caraïbes.");
			PlayStereoSound("notebook");
			AddMoneyToCharacter(pchar,-price);

			dialog.text = "...Voilà, toutes les informations dont vous avez besoin sont là. Je vous souhaite bonne chance !";
			Link.l1 = "Merci. Au revoir !";
			link.l1.go = "exit";
			pchar.GwikTimer = true;
			SetTimerFunction("RefreshGWIK", 0, 0, 15);
		break;
	}
}

string findTraderCity_GWIK(ref NPChar) // colony for escorting a Company ship (not hostile to Holland, not the current island)
{
	int n;
	int cityArray[MAX_COLONIES];
	int howCity = 0;
	for (n=0; n<MAX_COLONIES; n++)
	{
		if (colonies[n].id == "Panama") continue;
		if (colonies[n].nation == "none") continue;
		if (GetIslandByCityName(npchar.city) == colonies[n].islandLable) continue;
		if (GetNationRelation(HOLLAND, sti(colonies[n].nation)) == RELATION_ENEMY) continue;
		cityArray[howCity] = n;
		howCity++;
	}
	if (howCity == 0) return "none";
	return colonies[cityArray[cRand(howCity-1)]].id;
}

string findRivalCity_GWIK(ref NPChar) // a rival colony (England/France), not the current island
{
	int n;
	int cityArray[MAX_COLONIES];
	int howCity = 0;
	bool okNation;
	for (n=0; n<MAX_COLONIES; n++)
	{
		if (colonies[n].id == "Panama") continue;
		if (colonies[n].nation == "none") continue;
		if (GetIslandByCityName(npchar.city) == colonies[n].islandLable) continue;
		okNation = (sti(colonies[n].nation) == ENGLAND) || (sti(colonies[n].nation) == FRANCE);
		if (!okNation) continue;
		cityArray[howCity] = n;
		howCity++;
	}
	if (howCity == 0) return "none";
	return colonies[cityArray[cRand(howCity-1)]].id;
}
