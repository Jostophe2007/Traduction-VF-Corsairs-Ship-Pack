// Соукинс в Пуэрто-Принсипе
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
            dialog.text = "Vous avez affaire à moi ? Non ? Alors "+ GetSexPhrase("fichez le camp d'ici", "ne me distrayez pas, je vous prie.") +"";
			link.l1 = "Je m'en vais déjà.";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
			if (pchar.questTemp.piratesLine == "Soukins_toPuertoPrincipe")
			{
				link.l1 = "Richard, j'ai entendu dire que vous réunissiez des hommes pour une action contre les Espagnols. Je voulais y prendre part.";
				link.l1.go = "PL_Q7_1";
			}


			if(!CheckAttribute(PChar, "questTemp.pirateStartQuest"))
			{
				link.l2 = "Pourriez-vous me trouver du travail ?";
				link.l2.go = "pirateStartQuest";
			}
			else
			{
				if(pchar.questTemp.pirateStartQuest == "3" && !CheckAttribute(PChar, "questTemp.pirateStartQuest.many") && npchar.city == pchar.questTemp.pirateStartQuest.City)
				{
					link.l2 = "Je suis sur la piste, mais j'ai besoin d'argent : 30 000 piastres pour attirer un rat hors de son trou.";
					link.l2.go = "pirateStartQuest_many";
				}
				if(pchar.questTemp.pirateStartQuest == "3" && GetCharacterItem(pchar, "letter_open") > 0 && npchar.city == pchar.questTemp.pirateStartQuest.City)
				{
					link.l2 = "Regardez quelle lettre j'ai trouvée sur le cadavre d'un des contrebandiers.";
					link.l2.go = "pirateStartQuest_info_1";
				}
				if(pchar.questTemp.pirateStartQuest == "5" && npchar.city == pchar.questTemp.pirateStartQuest.City)
				{
					link.l2 = "Le travail est fait. Norman Vigo et sa baille sont partis chez le diable des mers.";
					link.l2.go = "pirateStartQuest_final";
				}
			}
			if(sti(pchar.rank) >= 10 && !CheckAttribute(PChar, "questTemp.pirateVikingQuest"))
			{
				link.l3 = "Avez-vous une affaire intéressante pour moi ?";
				link.l3.go = "pirateVikingQuest";
			}
			else
			{
				if(pchar.questTemp.pirateVikingQuest == "7" && npchar.city == pchar.questTemp.pirateVikingQuest.City)
				{
					dialog.text = "Je vois que vous avez des nouvelles ?"
					link.l1 = "Oui, je l'ai tué, et il était féroce, croyez-moi. D'habitude, quand ils sentent la mort, ils se mettent tous à parlementer, mais celui-là grognait, l'écume aux lèvres.";
					link.l1.go = "pirateVikingQuest_final";
				}
			}
		break;

 		case "Exit":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		//Blackthorn. Квест викинга
		case "pirateVikingQuest":
			dialog.text = "J'ai un travail pour vous. Il paraît que vous ne vous êtes pas seulement servi de votre épée, mais aussi de votre tête. וcoutez. Il y a quelques années, un Scandinave est apparu dans nos eaux, un Danois ou un Suédois, peu importe ; il se fait appeler Ragnar. Son navire est un vrai spectacle, et l'équipage n'est composé que de Normands. Et tout semble bien aller : il pirate un peu, gagne son pain, mais il ne verse pas sa part au pot commun, il est grossier avec les gouverneurs, et il revend ses prises on ne sait oם. Vous comprenez de quoi il est question ?";
			link.l1 = "Je comprends, il faut le punir pour en faire un exemple. Seulement, ce n'est pas conforme aux lois des Frères de la Cכte. Bon, ce pirate est allé trop loin, alors qu'on souffle aux autorités oם il se terre. Et personne n'aura rien à nous reprocher, à nous, honnêtes corsaires.";
			link.l1.go = "pirateVikingQuest_1";
			link.l2 = "Cette conversation ne me plaît pas. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateVikingQuest = "0";
		break;
		case "pirateVikingQuest_1":
			dialog.text = "Les lois des Frères, le Code, l'honneur pirate... Pff... Ce sont des enfantillages. Rappelez-vous aussi la Libertalia que Sharp a essayé de bâtir. Ha ha ! Ici, nous avons un équilibre des forces : les autorités ferment les yeux sur nos affaires, tant que nous ne gênons pas les leurs. Et si la paix est signée en Europe ? Alors les lettres de marque seront révoquées, et tous les braves corsaires deviendront des criminels en un instant. Et les escadres punitives arriveront. Pour nous attraper, vous et moi. Et des capitaines comme ce Viking ternissent la réputation de nous tous. Vous saisissez ?";
			link.l1 = "Je comprends, vous m'avez donné matière à réflexion. Oם puis-je trouver ce Viking ?";
			link.l1.go = "pirateVikingQuest_2";
		break;
		case "pirateVikingQuest_2":
			dialog.text = "Quelque part. Si je savais oם il se terre, j'irais moi-même en mer, malgré mes vieilles blessures et mon âge. Vous êtes quelqu'un de futé, vous trouverez bien. Une seule condition : ce Ragnar et tout son équipage doivent finir en nourriture pour les poissons, et je saurai me montrer généreux en or.";
			link.l1 = "Attendez les nouvelles. Et pour la révocation des lettres de marque, s'il y a du nouveau, prévenez-moi. א l'occasion, " + GetFullName(npchar)+".";
			link.l1.go = "exit";

			pchar.questTemp.pirateVikingQuest = "1";
			pchar.questTemp.pirateVikingQuest.City = npchar.city;
			pchar.questTemp.pirateVikingQuest.Areal = GetArealByCityName(pchar.questTemp.pirateVikingQuest.City);
			pchar.questTemp.pirateVikingQuest.Name = GetFullName(npchar);
			pchar.LastHearedViking = npchar.city;
			AddQuestRecord("pirateVikingQuest", "1");
			AddQuestUserData("pirateVikingQuest", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateVikingQuest.City + "Gen"));
			AddQuestUserData("pirateVikingQuest", "sName", pchar.questTemp.pirateVikingQuest.Name);
		break;
		case "pirateVikingQuest_final":
			CloseQuestHeader("pirateVikingQuest");
			pchar.questdata.OskolokProshlogo = 1;
			TakeNItems(pchar, "chest", 3);
			Log_Info("Vous avez reçu les coffres de crédit");
			dialog.text = "Oui, j'en ai entendu parler une fois. Un vrai berserker. Comme un vestige du passé. Tenez, prenez la récompense, vous l'avez méritée.";
			pchar.questTemp.pirateVikingQuest = "end";
			link.l1 = "Merci.";
			link.l1.go = "exit";
		break;

		//zagolski. начальный квест за пирата ===================================
		case "pirateStartQuest":
			dialog.text = "Hum... du travail, dites-vous ? C'est même très bien que vous soyez venu me voir. Il me faut justement quelqu'un d'extérieur. Je dois me renseigner sur quelque chose dans la colonie voisine, et mes gars y sont connus comme le loup blanc. Je ne promets pas beaucoup d'argent, mais il y aura bien quelque chose à gratter.";
			link.l1 = "Voilà qui est bien. De quoi s'agit-il ?";
			link.l1.go = "pirateStartQuest_1";
			link.l2 = "Désolé, je ne vais pas risquer un sou. Au revoir...";
			link.l2.go = "exit";
			pchar.questTemp.pirateStartQuest = "0";
		break;
		case "pirateStartQuest_1":
			dialog.text = "Voici l'affaire : il y a environ un mois, je me suis entendu avec le capitaine de la goélette Sentblue pour qu'il livre 200 esclaves, à revendre à un planteur de la colonie voisine. Les délais sont déjà serrés, le client s'impatiente, et hier on m'a informé qu'on avait vu cette goélette dans les eaux de l'île. Mais !.. Le capitaine ne s'est pas présenté. Et aujourd'hui, le planteur a exigé le remboursement de son acompte, en disant qu'on lui avait proposé les esclaves ailleurs : plus cher, certes, mais tout le lot d'un coup.";
			link.l1 = "Et alors ? Je dois vous trouver 200 esclaves en quelques jours, pour que vous ne perdiez pas l'acompte ? Et tout ça pour trois sous ?";
			link.l1.go = "pirateStartQuest_2";
		break;
		case "pirateStartQuest_2":
			dialog.text = "Non, bien sמr. J'ai l'air d'un idiot ? De toute façon, je ne rendrai pas l'acompte. Mais il me faut la preuve que les esclaves qu'on lui a remis sont mon lot. Et vous, trouvez simplement ceux qui lui ont proposé un nouveau marché, et vous aurez vos 10 000 piastres. Le reste, c'est mon affaire. Alors, ça marche ?";
			link.l1 = "J'accepte ! Et qui ça pourrait être ? Vous avez une idée ?";
			link.l1.go = "pirateStartQuest_3";
			link.l2 = "Non, désolé : aller je ne sais oם, chercher je ne sais qui, et tout ça pour seulement 10 000.";
			link.l2.go = "exit";
		break;
		case "pirateStartQuest_3":
			dialog.text = "Si j'avais le moindre indice, je me serais passé de vos services. Ils serviraient déjà d'appât à calmars avant la nuit. Mais ce qui m'intéresse surtout, c'est autre chose : comment ont-ils appris l'existence de la cargaison du Sentblue et de mon client ? Tout s'est arrangé très vite pour eux. Vous saisissez ?";
			link.l1 = "Oui, c'est clair, quelqu'un vend des informations.";
			link.l1.go = "pirateStartQuest_4";

			pchar.questTemp.pirateStartQuest = "1";
			pchar.questTemp.pirateStartQuest.City = npchar.city;
			pchar.questTemp.pirateStartQuest.Areal = GetArealByCityName(pchar.questTemp.pirateStartQuest.City);
			pchar.questTemp.pirateStartQuest.Name = GetFullName(npchar);

			AddQuestRecord("pSQ", "1");
			AddQuestUserData("pSQ", "sCity", XI_ConvertString("Colony" + pchar.questTemp.pirateStartQuest.City + "Gen"));
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);
		break;
		case "pirateStartQuest_4":
			dialog.text = "Voilà ! C'est lui que je cherche. Donc, éliminer discrètement les concurrents et récupérer les esclaves, ce n'est pas le principal dans cette affaire. Il me faut l'informateur, ou plutכt, sa tête au bout d'une pique. Vous comprenez maintenant pourquoi aucun de mes hommes ne doit être au courant de cette mission ? Tant que je ne saurai pas qui vend les informations, je soupçonnerai tout le monde. Et je n'en ai vraiment pas envie...";
			link.l1 = "Compris... Donc, on agit discrètement et sans faire de vagues. Je pars à sa recherche.";
			link.l1.go = "exit";
		break;

		case "pirateStartQuest_many":
			dialog.text = "Trente mille, dites-vous ? C'est beaucoup d'argent... Je ne peux vous donner que 5 000 piastres, c'est tout ce que j'ai pour le moment. Mais si vous voulez filer avec, je vous retrouverai et je vous pendrai à la palissade la plus proche ! Avec moi, ce genre de plaisanterie ne marche pas.";
			link.l1 = "Donnez-moi les cinq mille...";
			link.l1.go = "pirateStartQuest_many_1";
		break;
		case "pirateStartQuest_many_1":
			dialog.text = "Tenez. J'attends les résultats de vos recherches.";
			link.l1 = "Tout ira bien.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 5000);
			pchar.questTemp.pirateStartQuest.many = "";
		break;

		//------------------------------------
		case "pirateStartQuest_info_1":
			dialog.text = "Ha ! Excellente nouvelle ! J'étais sמr que vous y arriveriez. J'ai obtenu des informations très intéressantes.";
			link.l1 = "J'ai fait mon travail. Je veux mes dix mille.";
			link.l1.go = "pirateStartQuest_info_2";
			TakeItemFromCharacter(pchar, "letter_open");
		break;
		case "pirateStartQuest_info_2":
			dialog.text = "Bien sמr, voici la récompense promise. Mais ne vous pressez pas, je veux vous confier une autre affaire. Pfiefer est un homme de l'équipage de Norman Vigo, qui navigue sur le cotre Normandy. Je suis sמr que Norman Vigo est l'informateur, même s'il est des nכtres. On l'a vu récemment dans les eaux de l'île : votre mission est d'envoyer ce rat au diable des mers. La première fois, vous ne m'avez pas déçu, alors cette fois encore, je compte sur vous. 15 000 piastres. Marché conclu ?";
			link.l1 = "J'accepte ! Considérez que ce traître de Norman Vigo est déjà mort.";
			link.l1.go = "pirateStartQuest_info_3";
			link.l2 = "Vous savez quoi, je ne veux pas me mêler de ça... Et je n'ai pas le temps. Désolé, mais je passe mon tour.";
			link.l2.go = "pirateStartQuest_info_noex";
			AddMoneyToCharacter(pchar, 10000);
		break;
		case "pirateStartQuest_info_noex":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
		break;
		case "pirateStartQuest_info_3":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			pchar.questTemp.pirateStartQuest = "4";

			AddQuestRecord("pSQ", "7");
			AddQuestUserData("pSQ", "sName", pchar.questTemp.pirateStartQuest.Name);

			pchar.quest.zpq_seaBattle.win_condition.l1 = "location";
			pchar.quest.zpq_seaBattle.win_condition.l1.location = pchar.questTemp.pirateStartQuest.Areal;
			pchar.quest.zpq_seaBattle.function = "pirateStartQuest_seaBattle";
		break;

		case "pirateStartQuest_final":
			dialog.text = "On sait, on sait. Mes hommes ont observé le combat et m'ont déjà rapporté avec quelle adresse vous vous en êtes tiré. Eh bien, vous avez fait votre travail comme il faut. Voici la récompense promise de 15 000 piastres. Et merci, vous m'avez bien aidé.";
			link.l1 = "Tout va bien, ça me fait plaisir d'aider ! Et maintenant, j'ai à faire, je me suis déjà attardé ici. א plus tard !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 15000);
			pchar.questTemp.pirateStartQuest = "0";
			CloseQuestHeader("pSQ");
			pchar.questdata.TravlyaKrys = 1;
			group_DeleteGroup("pirateStartQuest_Smuggler_group");
		break;

		//пиратка, квест №7
		case "PL_Q7_1":
			dialog.text = "Dites-moi votre nom.";
			link.l1 = GetFullName(pchar) + ".";
			link.l1.go = "PL_Q7_2";
		break;
		case "PL_Q7_2":
			dialog.text = "Héhé, ne serais-tu pas"+ GetSexPhrase(" le sbire de Morgan, l'ami ", " la petite amie de Morgan, hein ") +" ?";
			link.l1 = "Je travaille pour Henry, mais pourquoi parler de "+ GetSexPhrase("sbire ", "« petite amie » ") +" ?";
			link.l1.go = "PL_Q7_3";
		break;
		case "PL_Q7_3":
			dialog.text = "Et pourtant, vous ne me convenez pas. Hé, la garde ! Venez tous ici ! Abattez-moi ce larbin...";
			link.l1 = "Pourquoi faites-vous ça ?";
			link.l1.go = "fight";
			LAi_SetPlayerType(pchar);
			pchar.questTemp.piratesLine = "Soukins_FightinResidence";
			for (i=1; i<=5; i++)
			{
				iTemp = 10 + rand(10);
				sld = GetCharacter(NPC_GenerateCharacter("questPirate_"+i, "pirate_"+i, "man", "man", 25, PIRATE, 10, true));
				FantomMakeCoolFighter(sld, 25, 70, 70, "blade26", "pistol6", 20);
				LAi_SetWarriorType(sld);
				LAi_warrior_SetStay(sld, true);
				LAi_group_MoveCharacter(sld, npchar.chr_ai.group);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			}
		break;
		case "PL_Q7_5":
			dialog.text = "Qu'est-ce que vous fichez à débarquer ici sans invitation ?!! Ah, je crois que je vous connais... Hé, la garde, venez tous ici ! Abattez-moi "+ GetSexPhrase("ce sbire", "cette engeance de Morgan") +" !";
			link.l1 = "Hé, hé, qu'est-ce qui se passe ?!";
			link.l1.go = "fight";
			LAi_SetPlayerType(pchar);
			pchar.questTemp.piratesLine = "Soukins_FightinResidence";
			for (i=1; i<=5; i++)
			{
				iTemp = 10 + rand(10);
				sld = GetCharacter(NPC_GenerateCharacter("questPirate_"+i, "pirate_"+i, "man", "man", 25, PIRATE, 10, true));
				FantomMakeCoolFighter(sld, 25, 70, 70, "blade26", "pistol6", 20);
				LAi_SetWarriorType(sld);
				LAi_warrior_SetStay(sld, true);
				LAi_group_MoveCharacter(sld, npchar.chr_ai.group);
				ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1");
			}
		break;
		//пиратка, квест №8
		case "PL_Q8_deck":
			dialog.text = "Et comment Morgan a-t-il pu mettre"+ GetSexPhrase(" un tel crétin", " une fille") +" à la tête d'une escadre ? Je n'arrive pas à l'imaginer...";
			link.l1 = "Hum, vous ne devriez pas faire ça, Richard.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;
		case "PL_Q8_deck_1":
			dialog.text = "דa recommence. C'est bien ce que je disais !";
			link.l1 = "Ne vous en faites pas pour moi.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_1";
		break;

		case "PL_Q8_deck_2":
			dialog.text = "Alors, que faites-vous encore sur mon pont ? Vous croyez qu'après avoir pris d'assaut Portobelo, vous pourrez vous promener ici tranquillement ?";
			link.l1 = "...";
			link.l1.go = "PL_Q8_deck_3";
		break;
		case "PL_Q8_deck_3":
			dialog.text = "וcoutez, vous feriez mieux de partir d'ici... Je n'ai rien à vous dire. Tout se décidera à Panama : là-bas, chacun montrera de quoi il est capable.";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "PL_Q8_deck_4";
		break;
		case "PL_Q8_deck_4":
			dialog.text = "Je n'ai pas de comptes à vous rendre, vous n'êtes pas mon ami. Alors fichez le camp d'ici.";
			link.l1 = "D'accord, au revoir. Si vous ne voulez pas parler...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_5";
			npchar.DeckDialogNode = "PL_Q8_deck_5";
		break;
		case "PL_Q8_deck_5":
			dialog.text = "Je ne veux pas vous parler !";
			link.l1 = "Hum, eh bien, c'est compréhensible...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PL_Q8_deck_5";
			npchar.DeckDialogNode = "PL_Q8_deck_5";
		break;
		//в бухте Дарьенский залив
		case "Shore48":
			dialog.text = "Bon, nous sommes arrivés à la baie. Maintenant, il faut avancer à travers la jungle. Mes hommes et moi sommes prêts, nous pouvons y aller.";
			link.l1 = "D'accord, compris.";
			link.l1.go = "Shore48_1";
		break;
		case "Shore48_1":
			LAi_LocationFightDisable(&Locations[FindLocation("Shore48")], false);
			chrDisableReloadToLocation = false;
			LAi_SetWarriorTypeNoGroup(npchar);
			NextDiag.TempNode = "Shore48_over";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		case "Shore48_over":
			dialog.text = "Qu'est-ce qu'on attend ? Allez, bougez-vous jusqu'à Panama !!";
			link.l1 = "Hum, ça, c'est sמr...";
			link.l1.go = "exit";
		break;
		//после штурма у стен Панамы
		case "PQ8_exitTown":
			dialog.text = "Que voulez-vous ?";
			link.l1 = "וcoutez, je sais que ça ne va pas vous plaire, mais Morgan m'a ordonné de vous tuer pendant notre marche à travers la jungle.";
			link.l1.go = "PQ8_exitTown_1";
		break;
		case "PQ8_exitTown_1":
			dialog.text = "Et vous croyez que je vais vous croire ?";
			link.l1 = "Vous pouvez ne pas me croire, mais c'est la vérité.";
			link.l1.go = "PQ8_exitTown_2";
		break;
		case "PQ8_exitTown_2":
			dialog.text = "Plus d'une fois, vous avez fourré votre nez dans mes affaires et fait échouer mes plans. Vous êtes le chiot de Morgan. Et maintenant, vous voulez me bluffer, c'est ça ?";
			link.l1 = "Allez au diable, Richard... Espèce d'idiot !";
			link.l1.go = "PQ8_exitTown_3";
		break;
		case "PQ8_exitTown_3":
			dialog.text = "Bien sמr que j'irai... א Panama. Mais vous, vous n'entrerez pas dans la ville. Alors fichez le camp tant que vous êtes encore en un seul morceau...";
			link.l1 = "Diable !..";
			link.l1.go = "exit";
			LAi_warrior_DialogEnable(npchar, false);
		break;
	}
}
