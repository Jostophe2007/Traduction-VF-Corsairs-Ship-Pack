// диалог по городам
// Это мастер тюнинга
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    if ( sti(Pchar.Ship.Type) != SHIP_NOTUSED && !S_armor(Pchar))
    {
	    int   	cannonQ       = sti(RealShips[sti(Pchar.Ship.Type)].CannonsQuantity);
		int   	cannonMax     = sti(RealShips[sti(Pchar.Ship.Type)].MaxCaliber);
		int		cannonMaxQ    = 0;
		if (CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "CannonsQuantityMax")) cannonMaxQ = sti(RealShips[sti(Pchar.Ship.Type)].CannonsQuantityMax);
		int   	shipClass     = sti(RealShips[sti(Pchar.Ship.Type)].Class);
		//int   shipPrice     = sti(RealShips[sti(Pchar.Ship.Type)].Price);
		int   	shipCapacity  = sti(RealShips[sti(Pchar.Ship.Type)].Capacity);
		float 	shipSpeedRate = stf(RealShips[sti(Pchar.Ship.Type)].SpeedRate);
		float 	MastMulti     = stf(RealShips[sti(Pchar.Ship.Type)].MastMultiplier);
		int   	shipMaxCrew   = sti(RealShips[sti(Pchar.Ship.Type)].MaxCrew);
		int   	shipHP        = sti(RealShips[sti(Pchar.Ship.Type)].HP);
		float 	shipTurnRate  = stf(RealShips[sti(Pchar.Ship.Type)].TurnRate);
		float 	shipWindAgainst = stf(RealShips[sti(Pchar.Ship.Type)].WindAgainstSpeed);
		int		cannonDiff		= cannonMaxQ - cannonQ;
		int		hullArmor		= sti(RealShips[sti(Pchar.Ship.Type)].HullArmor);
		int 	iCaliber;

/*
		if(cannonDiff >= 2)
		{
			cannonDiff = 2;
			cannonMaxQ = cannonQ + cannonDiff;
		}
		else
		{
			cannonDiff = 0;
		}
*/
		float fBasePrice = 0.0;
		if(shipClass <= 4){ fBasePrice = stf(RealShips[sti(Pchar.Ship.Type)].Price) / 20 * MOD_SKILL_ENEMY_RATE*3;}

		//int  zWorkPrice  = makeint(8000 * ((7-shipClass) * MOD_SKILL_ENEMY_RATE*3) * fQuestShip);
		int sundukSum = makeint((7-shipClass)*1.0);

	    int  cannonMatherial1 = makeint(cannonQ * 2 + 35 * (7-shipClass) - 20);
	    int	 cannonMatherial2 = makeint((7-shipClass)/2);
		if (cannonMatherial2 < 1) cannonMatherial2 = 1;
	    int	 cannonMatherial3 = sundukSum;
		int  cannonWorkPrice  = makeint(100 * cannonQ * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  capacityMatherial1 = makeint(35 * (7-shipClass) + shipCapacity * 7/100);
	    int	 capacityMatherial2 = makeint(10 * (7-shipClass)+10);
	    int  capacityMatherial3 = sundukSum;
		int  capacityWorkPrice  = makeint(2 * shipCapacity * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  SpeedRateMatherial1 = makeint(shipHP * 25/1000 + 70 * (7-shipClass));
	    int	 SpeedRateMatherial2 = makeint(5 * (7-shipClass));
	    int	 SpeedRateMatherial3 = sundukSum;
		int  SpeedRateWorkPrice  = makeint(100 * shipSpeedRate * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

		int  MastMultiplierMatherial1 = makeint(shipHP * 25/1000 + 70 * (7-shipClass));
	    int	 MastMultiplierMatherial2 = makeint(10 * (7-shipClass));
	    int	 MastMultiplierMatherial3 = sundukSum;
		int  MastMultiplierMatherialWorkPrice  = makeint(100 * MastMulti * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  MaxCrewMatherial1 = makeint(shipMaxCrew * 6/10 + 50 * (7-shipClass));
	    int	 MaxCrewMatherial2 = makeint(6 * (7-shipClass)+3);
	    int	 MaxCrewMatherial3 = sundukSum;
		int  MaxCrewWorkPrice  =  makeint(15 * shipMaxCrew * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  TurnRateMatherial1 = makeint(shipHP * 25/1000 + 375/shipClass+20);
	    int	 TurnRateMatherial2 = makeint(5 * (7-shipClass)+2);
	    int	 TurnRateMatherial3 = sundukSum;
		int  TurnRateWorkPrice  = makeint(30 * shipTurnRate * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  HPMatherial1 = makeint(35 * (7-shipClass) + shipHP * 7/100);
	    int	 HPMatherial2 = makeint(5 * (7-shipClass)*3);
	    int	 HPMatherial3 = sundukSum;
		int  HPWorkPrice  = makeint(shipHP * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

	    int  WindAgainstMatherial1 = makeint(shipHP * 25/1000 + 750/shipClass+20);
	    int	 WindAgainstMatherial2 = makeint(6 * (7-shipClass)+1);
	    int	 WindAgainstMatherial3 = sundukSum;
		int  WindAgainstWorkPrice  = makeint(300 * shipWindAgainst * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);
		
		int  HullArmorMaterial1 = makeint(shipHP * 25/1000 + 750/shipClass+20);
	    int	 HullArmorMaterial2 = makeint(20 * (7-shipClass)+1);
	    int	 HullArmorMaterial3 = sundukSum;
		int  HullArmorPrice  = makeint(300 * shipSpeedRate * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);

		int quantityMatherial1 = makeint(cannonQ * 2 + 35 * (7-shipClass) - 20);
		int quantityMatherial2 = makeint((7-shipClass)/2);
			if (quantityMatherial2 < 1) quantityMatherial2 = 1;
		int quantityMatherial3 = sundukSum;
		int cannonQWorkPrice = makeint(100 * cannonMaxQ * MOD_SKILL_ENEMY_RATE*3 + fBasePrice);
		int AllMatherial1 = cannonMatherial1 + quantityMatherial1;
		int AllMatherial2 = cannonMatherial2 + quantityMatherial2;
		int AllMatherial3 = cannonMatherial3 + quantityMatherial3;
		int cannonAllWorkPrice = cannonWorkPrice + cannonQWorkPrice;
		//int  zWorkPriceAll  = zWorkPrice * 2;


		float discount = 1.0;
  		if (CheckAttribute(NPChar, "Discount"))
		{
		    discount = 0.75;
		}

	    cannonMatherial1 = cannonMatherial1 * discount;
	    cannonMatherial2 = cannonMatherial2 * discount;
		cannonMatherial3 = cannonMatherial3 * discount;
		if (cannonMatherial3 < 1) cannonMatherial3 = 1;
	    cannonWorkPrice  = cannonWorkPrice * discount;

		quantityMatherial1 = quantityMatherial1 * discount;
		quantityMatherial2 = quantityMatherial2 * discount;
		quantityMatherial3 = quantityMatherial3 * discount;
		if (quantityMatherial3 < 1) quantityMatherial3 = 1;
		cannonQWorkPrice = cannonQWorkPrice * discount;

		AllMatherial1 = AllMatherial1 * discount;
		AllMatherial2 = AllMatherial2 * discount;
		AllMatherial3 = AllMatherial3 * discount;
		if (AllMatherial3 < 1) AllMatherial3 = 1;
		cannonAllWorkPrice = cannonAllWorkPrice * discount;

	    capacityMatherial1 = capacityMatherial1 * discount;
	    capacityMatherial2 = capacityMatherial2 * discount;
		capacityMatherial3 = capacityMatherial3 * discount;
		if (capacityMatherial3 < 1) capacityMatherial3 = 1;
	    capacityWorkPrice  = capacityWorkPrice * discount;

	    SpeedRateMatherial1 = SpeedRateMatherial1 * discount;
	    SpeedRateMatherial2 = SpeedRateMatherial2 * discount;
		SpeedRateMatherial3 = SpeedRateMatherial3 * discount;
		if (SpeedRateMatherial3 < 1) SpeedRateMatherial3 = 1;
	    SpeedRateWorkPrice  = SpeedRateWorkPrice * discount;

		MastMultiplierMatherial1 = MastMultiplierMatherial1 * discount;
	    MastMultiplierMatherial2 = MastMultiplierMatherial2 * discount;
		MastMultiplierMatherial3 = MastMultiplierMatherial3 * discount;
		if (MastMultiplierMatherial3 < 1) MastMultiplierMatherial3 = 1;
	    MastMultiplierMatherialWorkPrice  = MastMultiplierMatherialWorkPrice * discount;

	    MaxCrewMatherial1 = MaxCrewMatherial1 * discount;
	    MaxCrewMatherial2 = MaxCrewMatherial2 * discount;
		MaxCrewMatherial3 = MaxCrewMatherial3 * discount;
		if (MaxCrewMatherial3 < 1) MaxCrewMatherial3 = 1;
	    MaxCrewWorkPrice  = MaxCrewWorkPrice * discount;

	    TurnRateMatherial1 = TurnRateMatherial1 * discount;
	    TurnRateMatherial2 = TurnRateMatherial2 * discount;
		TurnRateMatherial3 = TurnRateMatherial3 * discount;
		if (TurnRateMatherial3 < 1) TurnRateMatherial3 = 1;
	    TurnRateWorkPrice  = TurnRateWorkPrice * discount;

	    HPMatherial1 = HPMatherial1 * discount;
	    HPMatherial2 = HPMatherial2 * discount;
		HPMatherial3 = HPMatherial3 * discount;
		if (HPMatherial3 < 1) HPMatherial3 = 1;
	    HPWorkPrice  = HPWorkPrice * discount;

	    WindAgainstMatherial1 = WindAgainstMatherial1 * discount;
	    WindAgainstMatherial2 = WindAgainstMatherial2 * discount;
		WindAgainstMatherial3 = WindAgainstMatherial3 * discount;
		if (WindAgainstMatherial3 < 1) WindAgainstMatherial3 = 1;
	    WindAgainstWorkPrice  = WindAgainstWorkPrice * discount;
		
		HullArmorMaterial1 = HullArmorMaterial1 * discount;
	    HullArmorMaterial2 = HullArmorMaterial2 * discount;
		HullArmorMaterial3 = HullArmorMaterial3 * discount;
		if (HullArmorMaterial3 < 1) HullArmorMaterial3 = 1;
	    HullArmorPrice  = HullArmorPrice * discount;

		if (cannonMatherial2 < 1) cannonMatherial2 = 1;
		if (quantityMatherial2 < 1) quantityMatherial2 = 1;
	}

	int i;
	int iTemp;
	string attr, attrLoc;
	int amount;
	ref shTo;
	string sTemp;
	string s1;
	
	string sGood = "";
	aref aroot, arcur;
	int num, gooda, iGood, SG;

	switch (Dialog.CurrentNode)
	{

		// -----------------------------------Диалог первый - первая встреча
		case "First time":  // перехват основного диалога, только один раз
			if(NPChar.quest.meeting == "0")
			{
				Dialog.Text = "Hé... Quel sale climat... Je m'appelle " + GetFullName(npchar) + " et, que le diable m'emporte, je suis le meilleur constructeur de navires de ces îles perdues. Mais cette humidité me met à terre...";
				Link.l1 = pcharrepphrase("Mille requins, il ne me manquait plus que des ronchonnements séniles. Je m'appelle " + GetFullName(pchar) + ", vous avez sמrement entendu parler de moi.",
					"Ce n'est pas l'humidité, c'est la vieillesse, mon cher. Je m'appelle " + GetFullName(pchar) + ", vous avez sמrement entendu parler de moi.");
				Link.l1.go = "node_1";
				npchar.quest.meeting = "1";
			}
			else // нужно, если по квестам будет сброс на  "First time"
			{
				dialog.text = "Ah, c'est encore vous, encore avec vos problèmes... kha... kha.";
				link.l1 = pcharrepphrase("Vous avez raison, c'est encore moi. Mais parlons affaires avant que vous ne rendiez l'âme à Dieu.",
					"Vous avez bonne mémoire. Et maintenant, si vous le permettez, passons à des questions plus concrètes.");
				link.l1.go = "node_3";
				link.l2 = pcharrepphrase("Vous m'avez épuisé avec vos ronchonnements. Adieu.",
					"Je dois y aller, désolé de vous avoir dérangé..");
				link.l2.go = "exit";
			}
			NextDiag.TempNode = "Master_Ship";
			Dialog.CurrentNode = "Master_Ship";
		break;

		case "Master_Ship":
			dialog.text = "Ah, c'est encore vous, encore avec vos problèmes... kha... kha.";
			link.l1 = pcharrepphrase("Vous avez raison, c'est encore moi. Mais parlons affaires avant que vous ne rendiez l'âme à Dieu.",
	            "Vous avez bonne mémoire. Et maintenant, si vous le permettez, passons à des questions plus concrètes.");
			link.l1.go = "node_3";
			link.l2 = pcharrepphrase("Vous m'avez épuisé avec vos ronchonnements. Adieu.",
				"Je dois y aller, désolé de vous avoir dérangé..");
			link.l2.go = "exit";
			NextDiag.TempNode = "Master_Ship";
		break;

		case "node_1":
			dialog.text = "Ah, la jeunesse, la jeunesse, pas moyen d'obtenir de vous le moindre respect. Des têtes brמlées, des bras solides, que vous faut-il de plus ?";
			link.l1 = pcharrepphrase("C'est vrai. Mais tכt ou tard, tout a une fin, et on dirait que votre heure approche...",
				"Quelque chose me dit que, dans votre jeunesse, vous n'aviez pas beaucoup de respect pour l'âge non plus. Je me trompe ?");
			link.l1.go = "node_2";
		break;

		case "node_2":
			dialog.text = "Ne contredisez pas vos aînés, "+ GetSexPhrase("blanc-bec", "gamine") +" !";
			link.l1 = pcharrepphrase("D'accord, d'accord, ne vous mettez pas dans tous vos états, vous allez nous faire une attaque. Je ne veux pas qu'on m'accuse de la mort du meilleur constructeur de navires des Caraïbes. Passons aux affaires.",
				"Je vous pardonne cette rudesse, uniquement par respect pour votre âge. Maintenant, si vous avez fini, passons aux affaires.");
			link.l1.go = "node_3";
			link.l2 = pcharrepphrase("דa suffit, j'en ai assez de vos sermons ! Adieu !",
				"Je vois que nous ne trouverons pas de terrain d'entente. Adieu.");
			link.l2.go = "exit";
		break;

		case "node_3":
			dialog.text = "Kha, kha... On ne laisse aucun repos au vieil homme. Que me voulez-vous encore, " + GetAddress_Form(NPChar) + " ? ";
			link.l1 = pcharrepphrase("J'ai besoin des services du chantier naval.", "Je veux recourir aux services de votre chantier naval.");
			link.l1.go = "shipyard_dlg";
            Link.l2 = "J'ai une question.";
			Link.l2.go = "quests"; //(пересылка в файл города)
			// -->
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
			{
				link.l3 = "Je voulais vous parler de questions financières.";
				link.l3.go = "LoanForAll";//(перессылка в файл города)
			}
			link.l9 = pcharrepphrase("Diable, j'ai deux ou trois choses urgentes à faire, au revoir.", "Je dois y aller maintenant, désolé.");
			link.l9.go = "exit";
			NextDiag.TempNode = "Master_Ship";
		break;

		case "shipyard_dlg":
			dialog.Text = "Je peux vous proposer des travaux à la pièce : j'améliore les caractéristiques des rafiots du coin. Ici, ils ne savent pas du tout construire de vrais navires.";
			link.l1 = "Non, je n'ai pas besoin d'améliorations, je veux juste recourir aux services du chantier naval.";
			link.l1.go = "shipyard";

			if (!CheckAttribute(npchar, "questTemp.ShipOrderTime"))
			{
				link.l5 = "Puis-je commander à votre chantier un navire qui corresponde à mes préférences personnelles ?";
				link.l5.go = "Shipyard1";
			}
			else
			{
				link.l5 = "Le navire que j'ai commandé est-il prêt ?";
				link.l5.go = "shiporder1";
			}
			Link.l2 = "Formidable ! Justement, je dois préparer mon bateau. Pouvez-vous jeter un œil à ce qu'on peut faire ?";
			Link.l2.go = "ship_tunning_start";
			if (sti(RealShips[sti(Pchar.Ship.Type)].class) < 7)
			{
				Link.l22 = "Et l'amélioration de mon navire ?";
				Link.l22.go = "ship_upgrades_start";
			}
			if ((RealShips[sti(Pchar.Ship.Type)].name == "Flyingdutchman1") && (pchar.location.from_sea == "Pirates_town"))
			{
				link.l7 = "Maître, j'ai ici un bateau un peu particulier...";
				link.l7.go = "DutchmanRepair1";
			}

			link.l3 = "J'ai besoin de canons pour mon navire.";
			link.l3.go = "Cannons";
			link.l4 = "Je veux changer l'apparence de mon navire.";
			link.l4.go = "SailsGerald";
			Link.l9 = "Je ne suis pas d'accord avec vous. On trouve parfois de très bons navires dans ces eaux. Adieu.";
			Link.l9.go = "ship_tunning_not_now";
		break;
		
		case "ship_upgrades_start":
			if (CheckAttribute(&RealShips[sti(Pchar.Ship.Type)],"Shipyarder"))
			{
				shTo = &RealShips[sti(pchar.Ship.Type)];
				if (sti(shTo.Shipyarder) != sti(NPChar.index))
				{
					dialog.Text = "Je ne peux rien faire pour votre navire.";
					Link.l1 = "Eh bien, si c'est non, c'est non. Au revoir !";
					Link.l1.go = "exit";
					break;
				}
			}
			if (CheckAttribute(&RealShips[sti(Pchar.Ship.Type)],"GoodsForUpgrade"))
			{
				dialog.Text = "Ah, encore vous. Voyons si vous avez apporté ce qu'il faut...";
				Link.l1 = "Alors, qu'en est-il, maître ?";
				Link.l1.go = "ship_upgrades_2";
				if (bBettaTestMode)
				{
					Link.l2 = "LANCER L'AMוLIORATION";
					Link.l2.go = "ship_upgrades_do";
				}
			}
			else
			{
				NextDiag.CurrentNode = NextDiag.TempNode;
				DialogExit();
				LaunchShipUpgrades(npchar);
			}
		break;
		
		case "ship_upgrades_2":
			shTo = &RealShips[sti(pchar.Ship.Type)];
			sGood = "";
			makearef(aroot,shTo.GoodsForUpgrade);
			num = GetAttributesNum(aroot);
			gooda = 0;
			iGood = 0;
			SG = 0;
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				iGood = FindGood(sGood);
				gooda = sti(shTo.GoodsForUpgrade.(sGood));
				SG = GetSquadronGoods(pchar, iGood);
				if (gooda > 0 && SG > 0)
				{
					if (SG >= gooda)
					{
						RemoveCharacterGoods(pchar, iGood, gooda);
						shTo.GoodsForUpgrade.(sGood) = 0;
						log_info(XI_ConvertString(sGood)+" : livré en quantité de "+gooda+" sur "+gooda);
					}
					else 
					{
						RemoveCharacterGoods(pchar, iGood, SG);
						shTo.GoodsForUpgrade.(sGood) = sti(shTo.GoodsForUpgrade.(sGood))-SG;
						log_info(XI_ConvertString(sGood)+" : livré en quantité de "+SG+" sur "+gooda);
					}
				}
				else continue;
			}
			
			bool enough = true;				
			sGood = "";
			makearef(aroot,shTo.GoodsForUpgrade);
			num = GetAttributesNum(aroot);
			gooda = 0;
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				gooda = sti(shTo.GoodsForUpgrade.(sGood));
				if (gooda > 0)
				{
					enough = false;
				}
			}
			if (enough)
			{
				dialog.Text = "Toutes les marchandises sont là, faisons ces améliorations maintenant...";
				Link.l1 = "Parfait, j'espère que ce ne sera pas long.";
				Link.l1.go = "ship_upgrades_do";
			}
			else 
			{
				dialog.Text = "D'après mes notes, il vous reste encore des marchandises à apporter. J'ai hâte de commencer, alors allez vite les chercher...";
				Link.l1 = "Je fais aussi vite que je peux, maître !";
				Link.l1.go = "ship_upgrades_exit";
			}
		break;
		
		case "ship_upgrades_do":
			shTo = &RealShips[sti(pchar.Ship.Type)];
			DeleteAttribute(shTo,"GoodsForUpgrade");
			makearef(aroot,shTo.UpgradePrepared);
			num = GetAttributesNum(aroot);
			for (i = 0; i < num; i++)
			{
				arcur = GetAttributeN(aroot,i);
				sGood = GetAttributeName(arcur);
				shTo.Upgrade.(sGood) = true;
				CheckForShipStatsChange(shTo,sGood); //чек на метод в шипсутилитах для обновления статов, пока пустышка
			}
			DeleteAttribute(shTo,"UpgradePrepared");
			DeleteAttribute(shTo,"Shipyarder");
			int uptime = num * (7-sti(shTo.class)+4);
			AddTimeToCurrent(uptime, 0);
			log_info("L'amélioration du navire est terminée.");
			log_info("Heures écoulées : "+uptime+".");
			dialog.Text = "...C'est fait, allez l'essayer. Mieux que neuf !";
			Link.l1 = "Merci pour votre travail acharné, maître. Au revoir !";
			Link.l1.go = "ship_upgrades_exit";
		break;
		
		case "ship_upgrades_exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Discount_1":
			dialog.Text = "Moins cher ? Hum, je veux bien accorder une remise de 20 pour cent sur une amélioration, mais seulement à un professionnel qui s'y connaît en navires.";
			Link.l1 = "Cher monsieur, vous avez devant vous un capitaine professionnel, et je connais mon navire de la quille à la pomme du mât. Va pour la remise !";
			Link.l1.go = "Discount_2";
			Link.l9 = "Bon... il faudra peut-être se passer de la remise.";
			Link.l9.go = "ship_tunning_start";
		break;

		case "Discount_2":
			dialog.Text = "Un capitaine professionnel, dites-vous ? Eh bien, nous allons vérifier ça tout de suite !";
			Link.l1 = "Autant que vous voudrez !";
			Link.l1.go = "Discount_3";
			LockControl("DlgDown3", true);
			LockControl("DlgUp3", true);
		break;

  		case "Discount_3":
            NPChar.SeaQuestions = rand(sti(NullCharacter.SeaQuestions));
            sTemp = sTemp = "q" + NPChar.SeaQuestions;
			dialog.Text = NullCharacter.SeaQuestions.(sTemp);

   			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Discount_4";
			Link.l9 = "Je crois que je vais devoir me passer de la remise.";
			Link.l9.go = "ship_tunning_not_now";
		break;

		case "Discount_4":
   			sTemp = "a" + NPChar.SeaQuestions;
			if (DozorAnswerOk(GetStrSmallRegister(dialogEditStrings[1]), NullCharacter.SeaQuestions.(sTemp)))
			{
				dialog.text = "C'est exact !! Un capitaine qui s'y connaît vraiment"+ GetSexPhrase("", ", même si c'est une femme") +". Vous méritez une remise !";
				link.l1 = "Je vous avais dit que je m'y connaissais. Au fait.";
				link.l1.go = "ship_tunning_start";
				NPChar.Discount = true;
				LockControl("DlgDown3", false);
				LockControl("DlgUp3", false);
			}
			else
			{
				dialog.text = "Non, ce n'est pas ça. Vous voulez peut-être réessayer ?";
				link.l1 = "Oui, je vais réessayer.";
				link.l1.go = "Discount_5";
				link.l2 = "Non, cette question est trop compliquée pour moi.";
				link.l2.go = "ship_tunning_not_now";
			}
		break;

		case "Discount_5":
            sTemp = sTemp = "q" + NPChar.SeaQuestions;
			dialog.Text = NullCharacter.SeaQuestions.(sTemp);
   			Link.l1.edit = 1;
			Link.l1 = "";
			Link.l1.go = "Discount_4";
			Link.l9 = "Non, je ne pense pas en être capable.";
			Link.l9.go = "ship_tunning_not_now";
		break;

		case "ship_tunning_again":
			dialog.Text = RandPhraseSimple("Ah... C'est encore vous... Vous avez décidé de faire retaper votre bateau une fois de plus ?",
			RandPhraseSimple("Salutations, capitaine. Vous n'êtes toujours pas satisfait de votre bateau ?",
                                           "Eh... Pas une minute de tranquillité avec vous, vous ne laissez pas le vieil homme se concentrer.. Il vous fallait encore des améliorations ?"));
			Link.l1 = "Oui. C'est bien ça. Pouvons-nous voir ce qu'on peut faire d'autre ?";
			Link.l1.go = "ship_tunning_start";
			link.l2 = "Non, je n'ai pas besoin d'améliorations, je veux juste recourir aux services du chantier naval.";
			link.l2.go = "shipyard";

			if (!CheckAttribute(npchar, "questTemp.ShipOrderTime"))
			{
				link.l6 = "Puis-je commander à votre chantier un navire qui corresponde à mes préférences personnelles ?";
				link.l6.go = "Shipyard1";
			}
			else
			{
				link.l6 = "Le navire que j'ai commandé est-il prêt ?";
				link.l6.go = "shiporder1";
			}

			if ((RealShips[sti(Pchar.Ship.Type)].name == "Flyingdutchman1") && (pchar.location.from_sea == "Pirates_town"))
			{
				link.l7 = "Maître, j'ai ici un bateau un peu particulier...";
				link.l7.go = "DutchmanRepair1";
			}

			link.l3 = "J'ai besoin de canons pour mon navire.";
			link.l3.go = "Cannons";
			link.l31 = "Je veux changer l'apparence de mon navire.";
			link.l31.go = "SailsGerald";
            Link.l4 = "J'ai une question.";
			Link.l4.go = "quests"; //(пересылка в файл города)
			// -->
			if (CheckAttribute(pchar, "GenQuest.LoanChest.TakeChest") && sti(pchar.GenQuest.LoanChest.TargetIdx) == sti(NPChar.index))
			{
				link.l5 = "Je voulais vous parler de questions financières.";
				link.l5.go = "LoanForAll";//(пересылка в файл города)
			}
			Link.l9 = "Non. Je suis satisfait de ce que j'ai.";
			Link.l9.go = "ship_tunning_not_now_2";
		break;

        case "ship_tunning_not_now_2":
			dialog.Text = "Oui, je vois que vous réfléchissez, vous aussi ! Vous irez loin ! Revenez quand vous vous serez décidé, et ne me dérangez pas pour rien.";
			Link.l1 = RandPhraseSimple("Merci ! Bonne journée.", "Au revoir, maître. Vous pourriez vous passer de sarcasmes.");
			Link.l1.go = "ship_tunning_not_now";
		break;

        case "ship_tunning_start":
			if ( sti(Pchar.Ship.Type) == SHIP_NOTUSED || Pchar.location.from_sea != "Pirates_town")
            {
                dialog.Text = "Oם est le navire ? Pourquoi me faites-vous tourner en bourrique ?!";
			    Link.l1 = "C'est vrai, ça... Qu'est-ce qui me prend... Pardon.";
			    Link.l1.go = "ship_tunning_not_now";
            }
            else
            {
			    if (GetHour() == 13)
			    {
					dialog.Text = "Je suis un bourreau de travail, bien sמr, mais j'ai aussi droit à ma pause déjeuner. Revenez plus tard !";
			        Link.l1 = "Je vois...";
			        Link.l1.go = "ship_tunning_not_now";
			    }
			    else
			    {
                    if (shipClass == 7)
                    {
						dialog.Text = "Euh... Je ne travaille pas sur les embarcations. Une baille reste une baille, quelles que soient les incantations que vous prononcez dessus.";
    			        Link.l1 = "Je vois...";
    			        Link.l1.go = "ship_tunning_not_now";
    			        break;
                    }
					if (S_armor(pchar)) // СФ
					{
						dialog.text = NPCStringReactionRepeat("Voyons ce que nous avons là. Non... ça, je ne m'en charge pas.", "Je ne comprends rien du tout à la technique de votre navire. Comment voulez-vous que je l'améliore ?", "Je vous ai tout dit. Je ne prends pas ce bateau.", 
                          				"דa suffit ! Ma patience est à bout ! Vous n'avez pas d'autres questions ?!", "block", 2, npchar, Dialog.CurrentNode);
						link.l1 = HeroStringReactionRepeat("Hum. D'accord...", "En effet...",
                      					"Hum, quand même...", "דa alors ?..", npchar, Dialog.CurrentNode);
						Link.l1.go = "ship_tunning_not_now";
						break;
    					}
                    s1 = "Bon, bon... Voyons ce que nous avons là... Tiens donc : " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) + ".";
    			    if (sti(RealShips[sti(Pchar.Ship.Type)].Stolen) == true && !CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning"))
    			    {
    			        s1 = s1 + " Bah ! Ce navire est passé entre bien des mains. C'est pour ça qu'il est si usé. Vous avez une lettre de marque de corsaire ? Bon, je plaisante... venons-en au fait.";
    			    }
    			    s1 = s1 + " Que voulez-vous en faire ?";
                    dialog.Text = s1;

					if (RealShips[sti(Pchar.Ship.Type)].BaseName == "Wh_corvette_quest")
					{//Капремонт пса
						dialog.text = "Alors, le « Chien de guerre ». Qu'allons-nous en faire ?";
						if(!CheckAttribute(npchar, "WarDogUpgrade"))
						{
							npchar.WarDogUpgrade = "start";
							dialog.text = "Voyons... דa alors ! C'est une plaisanterie ? Le « Chien de guerre » ? Vous êtes venu rouvrir ma vieille blessure ?";
							link.l1 = "Quoi ? De quoi parlez-vous ?";
							link.l1.go = "WarDogUpgrade_1";
							break;
						}
						if(CheckAttribute(pchar, "TitanicIsDown"))
						{
							link.lWarDogUpgrade = "Vous n'êtes pas encore au courant ? L'insubmersible a sombré. La réputation de votre élève est traînée dans la boue pour toujours. ";
							link.lWarDogUpgrade.go = "WarDogUpgrade_8";
						}
						if(CheckAttribute(npchar, "WarDogUpgradePayment") && sti(pchar.money) >= 1000000)
						{
							link.lWarDogUpgrade = "Je vous ai apporté votre million. J'espère que cette remise à neuf en vaut vraiment la peine.";
							link.lWarDogUpgrade.go = "WarDogUpgrade_pay";
						}

					}
					
					if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.HullArmor"))
                    {
    			        Link.l0 = "Renforcer le blindage de la coque.";
    			        Link.l0.go = "ship_tunning_HullArmor";
    			    }
					if (cannonMax < 36 && cannonDiff > 0 && !CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.Cannon"))
					{
						Link.l1 = "Augmenter le calibre et le nombre maximal de canons.";
						Link.l1.go = "ship_tunning_cannon_all";
					}
					else
					{
						if (cannonMax < 36 && !CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.Cannon"))
						{
							Link.l1 = "Augmenter le calibre des canons.";
							Link.l1.go = "ship_tunning_cannon";
						}
						else
						{
							if (cannonDiff > 0)
							{
								Link.l1 = "Augmenter le nombre maximal de canons.";
								Link.l1.go = "ship_c_quantity";
							}
						}
					}

    			   /*  if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.Capacity"))
                    {
    			        Link.l2 = "Increase the deadweight.";
    			        Link.l2.go = "ship_tunning_Capacity";
    			    } */
					if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.MastMultiplier"))
                    {
    			        Link.l3 = "Renforcer la solidité des mâts.";
    			        Link.l3.go = "ship_tunning_MastMultiplier";
    			    }
					/* if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.SpeedRate"))
                    {
    			        Link.l4 = "Increase the speed.";
    			        Link.l4.go = "ship_tunning_SpeedRate";
    			    }
    			    if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.TurnRate"))
                    {
    			        Link.l5 = "Increase maneuverability.";
    			        Link.l5.go = "ship_tunning_TurnRate";
    			    }
    			    if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.MaxCrew"))
                    {
    			        Link.l6 = "Add room for the crew.";
    			        Link.l6.go = "ship_tunning_MaxCrew";
    			    }
    			    if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.HP"))
                    {
    			        Link.l7 = "Increase the strength of the hull.";
    			        Link.l7.go = "ship_tunning_HP";
    			    }
    			    if (!CheckAttribute(&RealShips[sti(Pchar.Ship.Type)], "Tuning.WindAgainstSpeed"))
                    {
    			        Link.l8 = "Increase the turn to the backwind.";
    			        Link.l8.go = "ship_tunning_WindAgainst";
    			    } */
    			    Link.l10 = "Attendez ! J'ai changé d'avis.";
    			    Link.l10.go = "ship_tunning_not_now_2";
			    }
			}
		break;

		////////////////////////////////////////// калибр и количество орудий  ////////////////////////////////////////////////////
		case "ship_tunning_cannon_all":
			s1 = "Voyons ce qu'on peut faire. Canons actuellement à bord : " + cannonQ + ", nombre maximal possible : " + cannonMaxQ + ", ";
			s1 = s1 + " calibre maximal : " + cannonMax + ". Pour renforcer les sabords et consolider les affמts, il me faudra : ébène - "+AllMatherial1 + ".";
			/* s1 = s1 + "I'm old, and I'm not going to rot in this hole forever, so I'll get to work: treasures-"+AllMatherial2 + ", chests of gold - "+AllMatherial3 + ", "; */
			s1 = s1 + " Prix : " + cannonAllWorkPrice + " piastres pour les frais de travail. Vous savez, ce n'est pas une mince affaire... Ah oui, et l'argent se paie d'avance.";

			dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_cannon_all_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			/* if (!CheckAttribute(NPChar, "Discount"))
			{
				Link.l3 = "Why is it so expensive? Is there any way to reduce the prices?";
				Link.l3.go = "Discount_1";
			} */
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_cannon_all_complite";
			}
		break;

		case "ship_tunning_cannon_all_start":
			amount = cannonAllWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
				NPChar.Tuning.Cannon = true;

				NPChar.Tuning.Matherial1 = AllMatherial1; // чёрное дерево
				NPChar.Tuning.Matherial2 = AllMatherial2; // кожа
				NPChar.Tuning.Matherial3 = AllMatherial3;
				NPChar.Tuning.ShipType       = Pchar.Ship.Type;
				NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
				DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_cannon_all_again";
				dialog.text = "Très bien. J'attends les matériaux.";
				link.l1 = "Je file chercher les matériaux...";
				link.l1.go = "Exit";

				ReOpenQuestHeader("ShipTuning");
				AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour augmenter le calibre et le nombre de canons de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
					" ; le maître constructeur a demandé :" + NewStr() + "ébène - " + NPChar.Tuning.Matherial1 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
				dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_cannon_all_again":
			if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
			{
				NextDiag.TempNode = "ship_tunning_cannon_all_again";
				dialog.Text = "Les canons attendent. Vous avez apporté ce que j'ai demandé ?";
				Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
				Link.l1.go = "ship_tunning_cannon_all_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
				DeleteAttribute(NPChar, "Tuning");
				NextDiag.TempNode = "ship_tunning_again";
				dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer..";
				Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
				Link.l1.go = "Exit";
				AddQuestRecord("ShipTuning", "Lose");
				AddQuestUserData("ShipTuning", "sSex", GetSexPhrase("", "e"));
				CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_cannon_all_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_EBONY, "icollection", "chest");

			if(sti(NPChar.Tuning.Matherial1) < 1 )
			{
				DeleteAttribute(NPChar, "Tuning");
				NextDiag.TempNode = "ship_tunning_again";
				dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
				link.l1 = "J'attends.";
				link.l1.go = "ship_tunning_cannon_all_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_cannon_all_again";
				dialog.Text = "Vous devez apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

				AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".");
			}
		break;

		case "ship_tunning_cannon_all_complite":
			AddTimeToCurrent(8, 30);
			shTo = &RealShips[sti(Pchar.Ship.Type)];
			DeleteAttribute(NPChar, "Tuning");

			// изменим калибр орудий
			SetShipBermudeTuningMaxCaliber(Pchar);

			// изменим количество орудий
			shTo.rcannon = sti(shTo.rcannon) + cannonDiff/2;
			shTo.lcannon = sti(shTo.rcannon);
			shTo.CannonsQuantity = sti(shTo.rcannon) + sti(shTo.lcannon) + sti(shTo.fcannon) + sti(shTo.bcannon);

			Pchar.Ship.Cannons.Borts.cannonl = sti(shTo.lcannon);
			Pchar.Ship.Cannons.Borts.cannonr = sti(shTo.rcannon);
			Pchar.Ship.Cannons.Borts.cannonf = sti(shTo.fcannon);
			Pchar.Ship.Cannons.Borts.cannonb = sti(shTo.bcannon);
			Pchar.Ship.Cannons = sti(shTo.CannonsQuantity);

			// finish <--
			NextDiag.TempNode = "ship_tunning_again";
			s1 = "... Bon, il semble que ce soit tout... Vous pouvez augmenter le calibre et acheter davantage de canons.";
			s1 = s1 + " Ce que vous pouvez d'ailleurs faire dans mon chantier naval.";
			dialog.Text = s1;
			Link.l1 = "Merci ! Je vérifierai tout, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;


		////////////////////////////////////////// только количество орудий  ////////////////////////////////////////////////////
		case "ship_c_quantity":
			s1 = "Voyons ce qu'on peut faire. Canons actuellement à bord : " + cannonQ + ", nombre maximal possible : " + cannonMaxQ + ".";
			s1 = s1 + " דa ne vous coמtera pas bon marché : pour de nouveaux affמts, il me faudra : ébène - "+quantityMatherial1;
			/* s1 = s1 + "Besides, I'll take on the job: treasures-"+quantityMatherial2+ ", chests of gold - "+quantityMatherial3+ ", "; */
			s1 = s1 + " ainsi que " + cannonQWorkPrice + " piastres pour les frais de travail. Vous savez, ce n'est pas une mince affaire... Ah oui, et l'argent se paie d'avance.";
			dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_c_quantity_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			/* if (!CheckAttribute(NPChar, "Discount"))
			{
				Link.l3 = "Why is it so expensive? Is there any way to reduce the prices?";
				Link.l3.go = "Discount_1";
			} */
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_c_quantity_complite";
			}

		break;

		case "ship_c_quantity_start":
			amount = cannonQWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
				NPChar.Tuning.Cannon = true;

				NPChar.Tuning.Matherial1 = quantityMatherial1; // чёрное дерево
				NPChar.Tuning.Matherial2 = quantityMatherial2; // кожа
			        NPChar.Tuning.Matherial3 = quantityMatherial3;
				NPChar.Tuning.ShipType       = Pchar.Ship.Type;
				NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
				DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_c_quantity_again";
				dialog.text = "Très bien. J'attends les matériaux.";
				link.l1 = "Je file chercher les matériaux...";
				link.l1.go = "Exit";

				ReOpenQuestHeader("ShipTuning");
				AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour augmenter le nombre de canons de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " ébène - " + NPChar.Tuning.Matherial1 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
				dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_c_quantity_again":
			if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
			{
				NextDiag.TempNode = "ship_c_quantity_again";
				dialog.Text = "Les canons attendent. Vous avez apporté ce que j'ai demandé ?";
				Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
				Link.l1.go = "ship_c_quantity_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
				DeleteAttribute(NPChar, "Tuning");
				NextDiag.TempNode = "ship_tunning_again";
				dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
				Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
				Link.l1.go = "Exit";
				AddQuestRecord("ShipTuning", "Lose");
				CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_c_quantity_again_2":
			checkMatherial(Pchar, NPChar, GOOD_EBONY, "icollection", "chest");

			if(sti(NPChar.Tuning.Matherial1) < 1 )
			{
				DeleteAttribute(NPChar, "Tuning");
				NextDiag.TempNode = "ship_tunning_again";
				dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
				link.l1 = "J'attends.";
				link.l1.go = "ship_c_quantity_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_c_quantity_again";
				dialog.Text = "Vous devez apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

				AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".");
			}
		break;

		case "ship_c_quantity_complite":
			AddTimeToCurrent(6, 30);
			shTo = &RealShips[sti(Pchar.Ship.Type)];
			DeleteAttribute(NPChar, "Tuning");

			// изменим количество орудий
			shTo.rcannon = sti(shTo.rcannon) + cannonDiff/2;
			shTo.lcannon = sti(shTo.rcannon);
			shTo.CannonsQuantity = sti(shTo.rcannon) + sti(shTo.lcannon) + sti(shTo.fcannon) + sti(shTo.bcannon);

			Pchar.Ship.Cannons.Borts.cannonl = sti(shTo.lcannon);
			Pchar.Ship.Cannons.Borts.cannonr = sti(shTo.rcannon);
			Pchar.Ship.Cannons.Borts.cannonf = sti(shTo.fcannon);
			Pchar.Ship.Cannons.Borts.cannonb = sti(shTo.bcannon);
			Pchar.Ship.Cannons = sti(shTo.CannonsQuantity);
			shTo.Tuning.Cannon = true;
			// finish <--
			NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vous pouvez acheter des canons supplémentaires.";
			Link.l1 = "Merci !";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;

		////////////////////////////////////////// только калибр орудий ////////////////////////////////////////////////////
		case "ship_tunning_cannon":
			s1 = "Voyons ce que nous pouvons faire. Canons actuellement à bord : " + cannonQ + ", calibre maximal : " + cannonMax + ".";

			s1 = s1 + " Pour renforcer les sabords et les affמts des canons lourds, il me faudra : ébène - "+ cannonMatherial1 + ".";
			/* s1 = s1 + " And for the job I'll take: treasures-"+ cannonMatherial2 + ", chests of gold - "+ cannonMatherial3 + ", "; */
			s1 = s1 + " Prix : " + cannonWorkPrice + " piastres pour les frais de travail. Vous savez, ce n'est pas une mince affaire... Ah oui, et l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_cannon_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			/* if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Why is it so expensive? Is there any way to reduce the prices?";
				Link.l3.go = "Discount_1";
			} */
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_cannon_complite";
			}
		break;

		case "ship_tunning_cannon_start":
		    amount = cannonWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
				NPChar.Tuning.Cannon = true;
			    NPChar.Tuning.Matherial1 = cannonMatherial1; // чёрное дерево
			    NPChar.Tuning.Matherial2 = cannonMatherial2; // кожа
			    NPChar.Tuning.Matherial3 = cannonMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_cannon_again";
                dialog.text = "Très bien. J'attends les matériaux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour augmenter le calibre des canons de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " ébène - " + NPChar.Tuning.Matherial1 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_cannon_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_cannon_again";
				dialog.Text = "Les canons attendent. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_cannon_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer..";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";
			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_cannon_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_EBONY, "icollection", "chest");

		    if(sti(NPChar.Tuning.Matherial1) < 1 )
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_cannon_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_cannon_again";
				dialog.Text = "Vous devez apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : ébène - "+ sti(NPChar.Tuning.Matherial1) + ".");
			}
		break;

		case "ship_tunning_cannon_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningMaxCaliber(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vous pouvez changer de calibre : je garantis la qualité.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;

		////////////////////////////////////////// трюм ////////////////////////////////////////////////////
		case "ship_tunning_Capacity":
			s1 = "Voyons ce qu'on peut faire. La capacité de votre navire est actuellement de "+ shipCapacity;

			s1 = s1 + ". Pour des cloisons allégées, il me faudra : bois de santal - "+ capacityMatherial1 + ".";
			s1 = s1 + " En paiement de mon travail, je prendrai : lingots d'or - "+ capacityMatherial2 + ", coffres d'or - "+ capacityMatherial3 + ", ";
			s1 = s1 + " ainsi que " + capacityWorkPrice + " piastres pour les frais de travail. Il semble que ce soit tout. Ah oui, l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est d'accord. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_Capacity_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_Capacity_complite";
			}

		break;

		case "ship_tunning_Capacity_start":
		    amount = capacityWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = capacityMatherial1; // красное дерево GOOD_MAHOGANY
			    NPChar.Tuning.Matherial2 = capacityMatherial2; //  GOOD_OIL
			    NPChar.Tuning.Matherial3 = capacityMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_Capacity_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour augmenter la capacité de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " bois de santal - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " lingots d'or - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or. Apparemment, le vieux est fou de bijoux. Bah, chacun ses faiblesses...");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_Capacity_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_Capacity_again";
				dialog.Text = "La cale attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_Capacity_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_Capacity_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_SANDAL, "jewelry5", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_Capacity_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_Capacity_again";
				dialog.Text = "Vous devez apporter : bois de santal - "+ sti(NPChar.Tuning.Matherial1) + ", lingots d'or - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : bois de santal - "+ sti(NPChar.Tuning.Matherial1) + ", lingots d'or - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_Capacity_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningCapacity(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vous pouvez charger à ras bord : je garantis la qualité du travail.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;

		////////////////////////////////////////// SpeedRate ////////////////////////////////////////////////////
		case "ship_tunning_SpeedRate":
			s1 = "Voyons ce qu'on peut faire. La vitesse de votre navire est actuellement de " + shipSpeedRate;

			s1 = s1 + " nœuds. Pour les nouvelles voiles, il me faudra : soie - "+ SpeedRateMatherial1 + ".";
			s1 = s1 + " Je suis vieux, et je n'ai pas l'intention de pourrir éternellement dans ce trou, alors pour le travail, je prendrai : coffres d'or - "+ SpeedRateMatherial3 + ", diamants bien taillés - "+ SpeedRateMatherial2 + ", ainsi que " + SpeedRateWorkPrice + " piastres pour les frais de travail. Il semble que ce soit tout. Ah oui, et l'argent se paie d'avance.";

            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_SpeedRate_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_SpeedRate_complite";
			}

		break;

		case "ship_tunning_SpeedRate_start":
		    amount = SpeedRateWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = SpeedRateMatherial1; // GOOD_SAILCLOTH
			    NPChar.Tuning.Matherial2 = SpeedRateMatherial2; //  GOOD_SILK
			    NPChar.Tuning.Matherial3 = SpeedRateMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_SpeedRate_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour augmenter la vitesse de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " soie - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " diamants - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or. Apparemment, le vieux est fou de bijoux. Bah, chacun ses faiblesses...");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_SpeedRate_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_SpeedRate_again";
				dialog.Text = "Le travail attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_SpeedRate_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_SpeedRate_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_SILK, "jewelry2", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_SpeedRate_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_SpeedRate_again";
				dialog.Text = "Vous devez apporter : soie - "+ sti(NPChar.Tuning.Matherial1) + ", diamants - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Je dois apporter : soie - "+ sti(NPChar.Tuning.Matherial1) + ", diamants - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_SpeedRate_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningSpeedRate(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vous pouvez prendre le vent toutes voiles dehors. Essayez donc !";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		////////////////////////////////////////// MastMultiplier ////////////////////////////////////////////////////
		case "ship_tunning_MastMultiplier":
			s1 = "Voyons ce qu'on peut faire. La solidité des mâts de votre navire est actuellement de " + MastMulti;

			s1 = s1 + ". Pour renforcer les mâts, il me faudra : planches - "+ MastMultiplierMatherial1 + ".";
			s1 = s1 + " Prix : " + SpeedRateWorkPrice + " piastres pour les frais de travail. Il semble que ce soit tout. Ah oui, et l'argent se paie d'avance.";

            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_MastMultiplier_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			/* if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Why is it so expensive? Is it possible to reduce the prices?";
				Link.l3.go = "Discount_1";
			} */
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_MastMultiplier_complite";
			}

		break;

		case "ship_tunning_MastMultiplier_start":
		    amount = SpeedRateWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = MastMultiplierMatherial1; // GOOD_SAILCLOTH
			    NPChar.Tuning.Matherial2 = MastMultiplierMatherial2; //  GOOD_SILK
			    NPChar.Tuning.Matherial3 = MastMultiplierMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_MastMultiplier_again";
                dialog.text = "Très bien. J'attends les matériaux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Pour renforcer les mâts de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " planches - " + NPChar.Tuning.Matherial1 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_MastMultiplier_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_MastMultiplier_again";
				dialog.Text = "Le travail attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_MastMultiplier_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_MastMultiplier_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_PLANKS, "jewelry11", "chest");

		    if(sti(NPChar.Tuning.Matherial1) < 1 )
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_MastMultiplier_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_MastMultiplier_again";
				dialog.Text = "Vous devez apporter : planches - "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Je dois apporter : planches - "+ sti(NPChar.Tuning.Matherial1) + ".");
			}
		break;

		case "ship_tunning_MastMultiplier_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
		    SetShipBermudeTuningMastMultiplier(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vos mâts peuvent désormais encaisser les boulets ramés sans crainte. Essayez donc !";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		////////////////////////////////////////// MaxCrew ////////////////////////////////////////////////////
		case "ship_tunning_MaxCrew":
			s1 = "Voyons ce que nous pouvons faire. L'équipage maximal de votre navire, surcharge comprise, est actuellement de " + shipMaxCrew + " hommes.";

			s1 = s1 + " Pour des hamacs supplémentaires et le capitonnage des coffres, il me faudra : cuir - "+ MaxCrewMatherial1 + ".";
			s1 = s1 + " En paiement, je prendrai : saphirs - "+ MaxCrewMatherial2 + ", coffres d'or - "+ MaxCrewMatherial3 + ", ainsi que " + MaxCrewWorkPrice + " piastres pour les frais de travail. C'est à peu près tout. Ah oui, et l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_MaxCrew_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_MaxCrew_complite";
			}
		break;

		case "ship_tunning_MaxCrew_start":
		    amount = MaxCrewWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = MaxCrewMatherial1; // GOOD_FRUITS
			    NPChar.Tuning.Matherial2 = MaxCrewMatherial2; //  GOOD_CLOTHES
			    NPChar.Tuning.Matherial3 = MaxCrewMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_MaxCrew_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Pour augmenter l'équipage de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " cuir - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " saphirs - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or. Apparemment, le vieux est fou de bijoux. Bah, chacun ses faiblesses...");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_MaxCrew_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_MaxCrew_again";
				dialog.Text = "L'affaire attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_MaxCrew_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_MaxCrew_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_LEATHER, "jewelry1", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_MaxCrew_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_MaxCrew_again";
				dialog.Text = "Vous devez apporter : cuir - "+ sti(NPChar.Tuning.Matherial1) + ", saphirs - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : cuir - "+ sti(NPChar.Tuning.Matherial1) + ", saphirs - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_MaxCrew_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
		    SetShipBermudeTuningMaxCrew(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Recrutez des marins, il y a de la place pour tout le monde.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;

		////////////////////////////////////////// TurnRate ////////////////////////////////////////////////////
		case "ship_tunning_TurnRate":
			s1 = "Voyons ce qu'on peut faire. La manœuvrabilité de ce navire est actuellement de " + shipTurnRate;

			s1 = s1 + " ; pour des voiles supplémentaires qui le rendront plus vif, il me faudra : toile - "+ TurnRateMatherial1 + ".";
			s1 = s1 + " Et pour le travail, je prendrai : coffres d'or - "+ TurnRateMatherial3 + ", rubis - "+ TurnRateMatherial2 + ", ainsi que " + TurnRateWorkPrice + " piastres pour les frais de travail. Vous comprenez bien que je n'ai pas l'intention de mourir dans ce taudis... C'est sans doute tout. Ah oui, l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_TurnRate_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_TurnRate_complite";
			}

		break;

		case "ship_tunning_TurnRate_start":
		    amount = TurnRateWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = TurnRateMatherial1; // GOOD_PLANKS
			    NPChar.Tuning.Matherial2 = TurnRateMatherial2; //  GOOD_LINEN
				NPChar.Tuning.Matherial3 = TurnRateMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_TurnRate_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Pour augmenter la manœuvrabilité de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " toile - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " rubis - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or. Apparemment, le vieux est fou de bijoux. Bah, chacun ses faiblesses...");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_TurnRate_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_TurnRate_again";
				dialog.Text = "Le travail attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. Une partie a été livrée.";
			    Link.l1.go = "ship_tunning_TurnRate_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_TurnRate_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_LINEN, "jewelry3", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_TurnRate_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_TurnRate_again";
				dialog.Text = "Vous devez apporter : toile - "+ sti(NPChar.Tuning.Matherial1) + ", rubis - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : toile - "+ sti(NPChar.Tuning.Matherial1) + ", rubis - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_TurnRate_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningTurnRate(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vous pouvez tourner la barre.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		////////////////////////////////////////// HP ////////////////////////////////////////////////////
		case "ship_tunning_HP":
			s1 = "Voyons ce que nous pouvons faire. La solidité de la coque est actuellement de " + shipHP;

			s1 = s1 + ". Pour renforcer le bordé, il me faudra : acajou - "+ HPMatherial1 + ".";
			s1 = s1 + " Pour le travail, je prendrai : lingots d'argent - "+ HPMatherial2 + ", coffres d'or - "+ HPMatherial3 + ", ainsi que " + HPWorkPrice + " piastres pour les frais de travail... Mes petits-enfants me pressent depuis longtemps de rentrer en Europe, et je ne veux pas revenir les mains vides, vous comprenez... C'est sans doute tout. Ah oui, l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_HP_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_HP_complite";
			}

		break;

		case "ship_tunning_HP_start":
		    amount = HPWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1 = HPMatherial1; // GOOD_EBONY
			    NPChar.Tuning.Matherial2 = HPMatherial2; //  GOOD_SANDAL
				NPChar.Tuning.Matherial3 = HPMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
			    DeleteAttribute(NPChar, "Discount");

				NextDiag.TempNode = "ship_tunning_HP_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Pour renforcer la coque de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " acajou - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " lingots d'argent - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or... Il dit qu'il part pour l'Europe ; le vieux diable ment sans doute.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_HP_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_HP_again";
				dialog.Text = "Le travail attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. J'ai réussi à en trouver une partie.";
			    Link.l1.go = "ship_tunning_HP_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_HP_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_MAHOGANY, "jewelry17", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_HP_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_HP_again";
				dialog.Text = "Vous devez apporter : acajou - "+ sti(NPChar.Tuning.Matherial1) + ", lingots d'argent - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : acajou - "+ sti(NPChar.Tuning.Matherial1) + ", lingots d'argent - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_HP_complite":
		    AddTimeToCurrent(6, 30);
		    shTo = &RealShips[sti(Pchar.Ship.Type)];
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningHP(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			if(shTo.BaseName == "Flyingdutchman") // ЛГ
			{
				dialog.text = "Ouais... J'ai vu bien des navires dans ma vie, mais jamais une telle saleté ni une telle odeur de moisi dans une cabine de capitaine. Vous devriez faire le ménage plus souvent ! Quoi qu'il en soit, nous avons refait la cabine et renforcé la coque : elle encaissera sans problème quelques coups au but.";
				Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
				Link.l1.go = "Exit";
				shTo.CabinType = "Cabin_Quest";
			}
			else
			{
				dialog.Text = "... Il semble que ce soit tout... Je vous garantis qu'il sera désormais très difficile de couler ce navire !";
				Link.l1 = "Merci ! Mais mieux vaut ne pas en faire l'expérience.";
				Link.l1.go = "Exit";
			}

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		////////////////////////////////////////// WindAgainstSpeed ////////////////////////////////////////////////////
		case "ship_tunning_WindAgainst":
			s1 = "Voyons ce qu'on peut faire. La marche au près est actuellement de " + FloatToString(shipWindAgainst, 2);

			s1 = s1 + ". Pour qu'il file mieux contre le vent, il me faudra : coton - "+ WindAgainstMatherial1 + ", ";
			s1 = s1 + " et en paiement, je prendrai : émeraudes - "+ WindAgainstMatherial2 + ", coffres d'or - "+ WindAgainstMatherial3 + ", ainsi que " + WindAgainstWorkPrice + " piastres pour les frais de travail. Ce n'est pas une mince affaire... Il semble que ce soit tout. Ah oui, l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_WindAgainst_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Pourquoi est-ce si cher ? Est-il possible de baisser les prix ?";
				Link.l3.go = "Discount_1";
			}
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_WindAgainst_complite";
			}
		break;

		case "ship_tunning_WindAgainst_start":
		    amount = WindAgainstWorkPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1     = WindAgainstMatherial1;
			    NPChar.Tuning.Matherial2     = WindAgainstMatherial2;
			    NPChar.Tuning.Matherial3     = WindAgainstMatherial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
                DeleteAttribute(NPChar, "Discount");
				NextDiag.TempNode = "ship_tunning_WindAgainst_again";
                dialog.text = "Très bien. J'attends le matériau et mes bijoux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Pour améliorer la marche au près de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " coton - " + NPChar.Tuning.Matherial1 + "," + NewStr() + " émeraudes - "+ NPChar.Tuning.Matherial2+ "," + NewStr() + " coffres d'or - " + NPChar.Tuning.Matherial3 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or. Le vieux est devenu fou avec ses babioles.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_WindAgainst_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_WindAgainst_again";
			    dialog.Text = "La marche au près attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. Une partie a été livrée.";
			    Link.l1.go = "ship_tunning_WindAgainst_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_WindAgainst_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_COTTON, "jewelry4", "chest");

		    if(sti(NPChar.Tuning.Matherial2) < 1 && sti(NPChar.Tuning.Matherial1) < 1 && sti(NPChar.Tuning.Matherial3) < 1)
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_WindAgainst_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_WindAgainst_again";
                dialog.Text = "Vous devez apporter : coton - "+ sti(NPChar.Tuning.Matherial1) + ", émeraudes - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : soie - "+ sti(NPChar.Tuning.Matherial1) + ", émeraudes - "+ sti(NPChar.Tuning.Matherial2) + ", coffres - "+ sti(NPChar.Tuning.Matherial3) + ".");
			}
		break;

		case "ship_tunning_WindAgainst_complite":
		    AddTimeToCurrent(6, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningWindAgainstSpeed(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Votre navire remontera mieux au vent désormais.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		////////////////////////////////////////// HullArmor ////////////////////////////////////////////////////
		case "ship_tunning_HullArmor":
			s1 = "Voyons ce qu'on peut faire. Le blindage de la coque est actuellement de " + hullArmor;

			s1 = s1 + ". Pour renforcer la coque, il me faudra : fer - "+ HullArmorMaterial1;
			s1 = s1 + " ainsi que " + HullArmorPrice + " piastres pour les frais de travail. Ce n'est pas une mince affaire... Il semble que ce soit tout. Ah oui, l'argent se paie d'avance.";
            dialog.Text = s1;
			Link.l1 = "C'est bon. J'accepte les conditions. Tout ce qui a été convenu sera livré.";
			Link.l1.go = "ship_tunning_HullArmor_start";
			Link.l2 = "Non. דa ne me convient pas.";
			Link.l2.go = "ship_tunning_not_now";
			/* if (!CheckAttribute(NPChar, "Discount"))
			{
			    Link.l3 = "Why is it so expensive? Is it possible to reduce the prices?";
				Link.l3.go = "Discount_1";
			} */
			if (bBettaTestMode)
			{
				Link.l4 = "CHARGER IMMוDIATEMENT !";
				Link.l4.go = "ship_tunning_HullArmor_complite";
			}
		break;

		case "ship_tunning_HullArmor_start":
		    amount = HullArmorPrice;
		    if(makeint(Pchar.money) >= amount)
			{
				AddMoneyToCharacter(Pchar, -amount);
			    NPChar.Tuning.Money  = amount;
			    NPChar.Tuning.Matherial1     = HullArmorMaterial1;
			    NPChar.Tuning.Matherial2     = HullArmorMaterial2;
			    NPChar.Tuning.Matherial3     = HullArmorMaterial3;
			    NPChar.Tuning.ShipType       = Pchar.Ship.Type;
			    NPChar.Tuning.ShipName       = RealShips[sti(Pchar.Ship.Type)].BaseName;
                DeleteAttribute(NPChar, "Discount");
				NextDiag.TempNode = "ship_tunning_HullArmor_again";
                dialog.text = "Très bien. J'attends les matériaux.";
			    link.l1 = "Je file chercher les matériaux...";
			    link.l1.go = "Exit";

			    ReOpenQuestHeader("ShipTuning");
			    AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText",  "Pour renforcer le blindage de mon navire de type " + XI_ConvertString(RealShips[sti(Pchar.Ship.Type)].BaseName) +
				" ; le maître constructeur exige :" + NewStr() + " fer - " + NPChar.Tuning.Matherial1 + "." + NewStr() + " א titre d'acompte, j'ai versé " + NPChar.Tuning.Money + " pièces d'or.");
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_not_now";
                dialog.text = "Je ne vois pas l'acompte...";
				link.l1 = "Je reviendrai plus tard.";
				link.l1.go = "Exit";
			}
		break;

		case "ship_tunning_HullArmor_again":
		    if (sti(NPChar.Tuning.ShipType) == sti(Pchar.Ship.Type) && NPChar.Tuning.ShipName      == RealShips[sti(Pchar.Ship.Type)].BaseName)
		    {
                NextDiag.TempNode = "ship_tunning_HullArmor_again";
			    dialog.Text = "Le blindage attend. Vous avez apporté ce que j'ai demandé ?";
			    Link.l1 = "Oui. Une partie a été livrée.";
			    Link.l1.go = "ship_tunning_HullArmor_again_2";
				Link.l2 = "Je veux recourir aux services du chantier naval.";
				Link.l2.go = "PayToRapair1";
				link.l3 = "Non, je m'en occupe encore.";
				link.l3.go = "exit";
			}
			else
			{
			    DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
			    dialog.Text = "Il me semble, "+ GetSexPhrase("monsieur", "mademoiselle") +", que vous avez changé de navire depuis notre accord. Il va falloir tout recalculer...";
			    Link.l1 = "C'est arrivé. Dommage pour l'acompte perdu...";
			    Link.l1.go = "Exit";

			    AddQuestRecord("ShipTuning", "Lose");
			    CloseQuestHeader("ShipTuning");
			}
		break;

		case "ship_tunning_HullArmor_again_2":
		    checkMatherial(Pchar, NPChar, GOOD_IRON, "jewelry12", "chest");

		    if(sti(NPChar.Tuning.Matherial1) < 1 )
			{
				DeleteAttribute(NPChar, "Tuning");
                NextDiag.TempNode = "ship_tunning_again";
                dialog.text = "Tout est en ordre ! Bravo ! Je me mets au travail...";
			    link.l1 = "J'attends.";
			    link.l1.go = "ship_tunning_HullArmor_complite";
			}
			else
			{
				NextDiag.TempNode = "ship_tunning_HullArmor_again";
                dialog.Text = "Vous devez apporter : fer - "+ sti(NPChar.Tuning.Matherial1) + ".";
				link.l1 = "Bien.";
				link.l1.go = "Exit";

                AddQuestRecord("ShipTuning", "t1");
				AddQuestUserData("ShipTuning", "sText", "Je dois apporter : fer - "+ sti(NPChar.Tuning.Matherial1) + ".");
			}
		break;

		case "ship_tunning_HullArmor_complite":
		    AddTimeToCurrent(12, 30);
		    DeleteAttribute(NPChar, "Tuning");
			SetShipBermudeTuningHullArmor(Pchar);
            NextDiag.TempNode = "ship_tunning_again";
			dialog.Text = "... Il semble que ce soit tout... Vos flancs encaisseront désormais les boulets avec bien plus d'assurance.";
			Link.l1 = "Merci ! Je vais vérifier ça, sans faute.";
			Link.l1.go = "Exit";

			AddQuestRecord("ShipTuning", "End");
			CloseQuestHeader("ShipTuning");
		break;
		///////////////////////////////  квестовые ветки
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Tout récemment, vous avez essayé de me poser une question...", "Dans mon chantier naval, et même dans toute la ville, je n'ai jamais vu de gens aussi obstinément curieux.",
                          "Eh bien, quelles questions ? Mon métier, c'est de construire des navires, alors allons-y.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Hum, tout de même...", "Allons-y...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (!CheckAttribute(npchar, "Step_Door"))
			{
				link.l2 = "וcoutez, je veux passer, mais la porte est fermée...";
				link.l2.go = "Step_Door_1";
			}
        // ==> Перехват на квесты
            if (CheckAttribute(pchar, "questTemp.State.SeekBible"))// квест №2, поиск Евангелие
            {
                if (!CheckCharacterItem(pchar, "Bible"))
                {
                    dialog.text = "Dites-moi...";
        			link.l2 = "וcoutez, je veux savoir oם est passé, dans votre chantier naval, un certain homme qui fuyait ses poursuivants ?";
        			link.l2.go = "Step_S2_1";
                }
                else
                {
                    dialog.text = "Oh, content de vous voir. Ce n'était donc pas pour rien que je vous ai laissé entrer : vous avez survécu et vous m'avez débarrassé de cette saleté... Dites-moi, qui était-ce ?";
        			link.l2 = "Mieux vaut que vous ne le sachiez pas, vous dormirez mieux. Bon, au revoir, et merci encore de m'avoir ouvert la porte.";
        			link.l2.go = "exit";
                }
            }
			if (pchar.questTemp.piratesLine == "KillLoy_toAlexus")
			{
				link.l1 = "Edward Law est-il venu vous voir ?";
				link.l1.go = "PL_Q3_1";
			}
			if (CheckAttribute(pchar, "questTemp.piratesLine.T1") && !CheckAttribute(npchar, "quest.PQ4"))
            {
				if (CheckAttribute(pchar, "questTemp.BrigSW_gift"))
				{
					link.l1 = "Jackman m'a donné le « Loup de mer » !";
					link.l1.go = "PL_Q3_SW1";
				}
				if (pchar.questTemp.piratesLine.T1 == "KillLoy_LoyIsDied")
				{
					link.l1 = "Je n'ai pas de très bonnes nouvelles au sujet de votre brick, celui que Law a emmené...";
					link.l1.go = "PL_Q3_SW2";
				}
			}
			if ((pchar.questTemp.different == "GiveShipLetters") && !CheckAttribute(pchar, "questTemp.different.GiveShipLetters.speakAlexus"))
			{
				link.l1 = "Je veux vous proposer une affaire.";
				link.l1.go = "Al_ShipLetters_1";// генератор  "Found documents"
				pchar.questTemp.different.GiveShipLetters.speakAlexus = true;
			}
			if (pchar.questTemp.BlueBird == "toSeekBermudes") //шебека Синяя Птица
			{
				link.l1 = "וcoutez, j'ai besoin de savoir une chose au sujet de votre souterrain...";
				link.l1.go = "BlueBird_1";
			}
			if (CheckCharacterItem(pchar, "Ship_Print_1")) NPChar.print1 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_2")) NPChar.print2 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_3")) NPChar.print3 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_4")) NPChar.print4 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_5")) NPChar.print5 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_6")) NPChar.print6 = 0;
			if (CheckCharacterItem(pchar, "Ship_Print_1") || CheckCharacterItem(pchar, "Ship_Print_2") || CheckCharacterItem(pchar, "Ship_Print_3") || CheckCharacterItem(pchar, "Ship_Print_4") || CheckCharacterItem(pchar, "Ship_Print_5") || CheckCharacterItem(pchar, "Ship_Print_6"))
            {
				if (!CheckAttribute(npchar, "questTemp.ShipOrderTime"))
				{
					link.l3 = "J'ai trouvé quelque chose d'inhabituel, ça ressemble beaucoup à un plan, vous voulez bien y jeter un œil ?";
					link.l3.go = "blueprint";
				}

			}
			if (pchar.location.from_sea == "Pirates_town")
			{
				if (CheckAttribute(RealShips[sti(Pchar.Ship.Type)],"Blueprint") || CheckAttribute(RealShips[sti(Pchar.Ship.Type)],"QuestShip"))
				{
					if (!CheckAttribute(RealShips[sti(Pchar.Ship.Type)],"savesBonus"))
					{
						link.l99 = "Maître, aucun constructeur n'arrive à comprendre oם, ni avec quoi, mon navire a été construit. Pouvez-vous m'aider ?";
						link.l99.go = "setshipmat";
					}
				}
			}
        // <== Перехват на квесты
		break;
		
		case "setshipmat":
			dialog.text = "Comment ça ? Voyons... Ha, votre navire a été construit soit par des pirates, soit par des contrebandiers. Il y a beaucoup de marques différentes, je me souviens même de certaines. En général, leurs plans sont rudimentaires, rien de spécial. Si vous voulez, je peux essayer de le reconstruire. Vous voulez que je commence maintenant ?"
			link.l1 = "Bien sמr, allons-y.";
			link.l1.go = "setshipmat_go";
			link.l2 = "Pas le temps pour l'instant, je dois y aller.";
			link.l2.go = "exit";
		break;
		
		case "setshipmat_go":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchShipyard3(npchar);
		break;

		case "blueprint":
			dialog.text = "Hum... Vous m'avez apporté une chose plutכt intéressante. Non, ce n'est pas un plan au sens habituel du terme. C'est un ensemble de solutions de construction navale, et c'est très inhabituel. Grâce à lui, on peut tirer le maximum de n'importe quel navire. Si vous voulez, je peux essayer de vous construire un navire, contre rétribution. Alors, qu'en dites-vous ?"
			link.l1 = "Bien sמr, commençons.";
			link.l1.go = "blueprint_ordership";
			link.l2 = "C'est certainement très intéressant, mais peut-être une autre fois.";
			link.l2.go = "exit";
		break;

		case "blueprint_ordership":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LaunchShipyard2(npchar);
		break;
//*************************** Генератор - "Found ship's documents" **************

		case "Al_ShipLetters_1":
			dialog.text = "Exposez vos conditions.";
			s1 = "Par un heureux hasard, je me suis retrouvé avec un jeu de documents de bord parfaitement en règle, qui ne figure encore sur aucun avis de recherche.";
			s1 = s1 + "Le navire est à flot et n'a pas été rayé du registre, ne vous inquiétez pas. C'est juste que son propriétaire a réussi à égarer ces papiers...";
			link.l1 = s1;
			link.l1.go = "Al_ShipLetters_2";
		break;
		case "Al_ShipLetters_2":
			s1 = "Voyons ça ! En effet, les marques sont toutes fraîches. Eh bien, la chance vous sourit, "+ GetSexPhrase("monsieur", "mademoiselle") +" ! ";
			s1 = s1 + "Il me fallait justement un tel jeu, et je vous offre en échange " + sti(pchar.questTemp.different.GiveShipLetters.price5) + " piastres. Qu'en dites-vous ?";
			dialog.text = s1;
			link.l1 = "Une générosité vraiment royale ! Bien sמr que j'accepte !";
			link.l1.go = "Al_ShipLetters_3";
			link.l2 = "Plutכt pas.";
			link.l2.go = "exit";
		break;
		case "Al_ShipLetters_3":
			TakeItemFromCharacter(pchar, "CaptainBook");
			addMoneyToCharacter(pchar, sti(pchar.questTemp.different.GiveShipLetters.price5));
			ChangeCharacterReputation(pchar, -1);
			OfficersReaction("bad");
			pchar.questTemp.different = "free";
			pchar.quest.GiveShipLetters_null.over = "yes"; //снимаем таймер
			AddQuestRecord("GiveShipLetters", "9");
			CloseQuestHeader("GiveShipLetters");
			DeleteAttribute(pchar, "questTemp.different.GiveShipLetters");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

//*************************** Пиратка, квест №3, поиски Лоу ***************************
		case "PL_Q3_1":
			dialog.text = "Il est venu... Et pourquoi en avez-vous besoin ?";
			link.l1 = "Euh, lui et Morgan ne sont pas d'accord sur quelques questions d'éthique. Ne mettez pas ma patience à l'épreuve, maître, je le poursuis depuis la Martinique.";
			link.l1.go = "PL_Q3_3";
			link.l2 = "Je suis son ami, nous ne nous sommes pas vus depuis longtemps, et on m'a dit à la taverne qu'il était venu ici...";
			link.l2.go = "PL_Q3_2";
		break;
		case "PL_Q3_2":
			dialog.text = "Ah oui. Un ami, donc. C'est bien... c'est même parfait ! Vous, voilà ce qu'il faut faire : allez voir Jackman et dites-lui que vous cherchez votre ami Edward Law. Jackman vous aidera\nIl a peut-être encore votre ami chez lui. Allez, allez, vous le retrouverez là-bas.";
			link.l1 = "Merci ! J'y cours !";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "10");
			pchar.questTemp.piratesLine = "KillLoy_toJackman";
		break;
		case "PL_Q3_3":
			dialog.text = "Vous le cherchez donc sur ordre de Morgan ? Enfin quelqu'un qui s'occupe de ce salaud ! Vous imaginez ? Il m'a dupé ! Il m'a apporté une lettre de Jackman me demandant de remettre le « Loup de mer » au porteur de cette lettre...";
			link.l1 = "Le « Loup de mer » ?";
			link.l1.go = "PL_Q3_4";
		break;
		case "PL_Q3_4":
			dialog.text = "Le Loup de mer est un brick. Mon brick ! Ma plus belle création ! J'y ai mis toute mon âme. Il est beau, magnifique, envoמtant ! Quand le soleil couchant traverse ses voiles, impossible d'en détacher les yeux. Au lever du soleil, quand le beau gaillard hisse ses voiles, on dirait une fleur de magnolia épanouie ! Et comme il glisse sur les vagues...";
			link.l1 = "Hum, maître, revenons-en à notre Law.";
			link.l1.go = "PL_Q3_5";
		break;
		case "PL_Q3_5":
			dialog.text = "Pardon ? Ah oui. Edward Law. Je construisais le brick de Jackman, je l'avais presque terminé, et voilà Law avec la lettre. Bref, j'ai donné le brick, et quand je suis allé chez Jackman pour me faire payer, il s'est avéré que la lettre était fausse. Jackman était contrarié... très... très contrarié. Quand je suis sorti de chez lui, vous... Euh... Quand je suis parti, Jackman m'a dit : « Je vous respecte, maître, mais je dois récupérer le brick. » Alors je me disais, puisque vous cherchez ce Law de toute façon, vous pourriez peut-être retrouver mon brick aussi ?";
			link.l1 = "Maître, je vous aiderai, bien sמr, mais seulement si vous cessez de gémir et me dites clairement : OÙ EST LAW ?!";
			link.l1.go = "PL_Q3_6";
		break;
		case "PL_Q3_6":
			dialog.text = "Demandez donc au tavernier. Les taverniers, c'est une drכle d'engeance, ils savent tout sur tout le monde. Il sait sמrement oם ce gredin est parti avec mon brick.";
			link.l1 = "Pfff, vous m'avez fait perdre tant de temps. Bon, allez, maître.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "11");
			pchar.questTemp.piratesLine = "KillLoy_toTavernAgain";
			//садим капитана Гудли в таверну
			sld = GetCharacter(NPC_GenerateCharacter("CapGoodly", "officer_9", "man", "man", 20, PIRATE, -1, true));
			sld.name = "Capitaine";
			sld.lastname = "Goodley";
			sld.city = "Pirates";
			sld.dialog.filename   = "Quest\PiratesLine_dialog.c";
			sld.dialog.currentnode   = "CapGoodly";
			sld.greeting = "Gr_EvilPirate";
			LAi_SetSitType(sld);
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
            FreeSitLocator("Pirates_tavern", "sit2");
         	ChangeCharacterAddressGroup(sld, "Pirates_tavern", "sit", "sit2");
		break;

		case "PL_Q3_SW1":
			dialog.text = "Je vous ai vu, je vous ai vu arriver. Je n'ai pas pu me retenir, j'ai couru au port pour voir.\nUn cadeau digne de ce nom. Félicitations et merci ! Vous avez sauvé le vieil homme.";
			npchar.quest.PQ4 = true;
			link.l1 = "Voilà donc comment je vous ai sauvé...";
			link.l1.go = "exit";
		break;
		case "PL_Q3_SW2":
			npchar.quest.PQ4 = true;
			dialog.text = "Bon sang ! Je le savais... Et alors ?";
			link.l1 = "Il a coulé, je suis désolé....";
			link.l1.go = "PL_Q3_SW3";
		break;
		case "PL_Q3_SW3":
			dialog.text = "Oui, c'est fâcheux.";
			link.l1 = "Ne vous en faites pas, tout ira bien...";
			link.l1.go = "exit";
		break;
//*************************** шебека Синяя Птица ***************************
		case "BlueBird_1":
			dialog.text = "Ce n'est pas le mien. Au contraire, j'essaie de ne laisser personne y entrer, pour leur propre bien.";
			link.l1 = "Ah, bon, je vois. En fait, voici ma question. Des marchandises entrent-elles en ville par ce souterrain ?";
			link.l1.go = "BlueBird_2";
		break;
		case "BlueBird_2":
			dialog.text = "Haha, non, bien sמr que non, même si le souterrain traverse de part en part. Jugez vous-même : il faudrait être idiot pour porter des charges sur son dos à travers ce trou, alors qu'on peut louer n'importe quelle tartane et tout amener tranquillement par la mer.";
			link.l1 = "Eh bien, et si quelqu'un ne veut pas qu'on le sache en ville ?";
			link.l1.go = "BlueBird_3";
		break;
		case "BlueBird_3":
			dialog.text = "Vous croyez que si quelqu'un se met à transporter des marchandises de mon chantier naval jusqu'à la ville, personne ne le remarquera ?";
			link.l1 = "Hum, oui, c'est juste... Donc personne ne transporte rien par votre chantier naval ?";
			link.l1.go = "BlueBird_4";
		break;
		case "BlueBird_4":
			dialog.text = "Non, personne ne transporte rien, vous pouvez en être sמr.";
			link.l1 = "Eh bien, merci beaucoup !";
			link.l1.go = "exit";
			AddQuestRecord("Xebeca_BlueBird", "5");
			pchar.questTemp.BlueBird = "toCavern";
			pchar.quest.BlueBird_inCavern.win_condition.l1 = "locator";
			pchar.quest.BlueBird_inCavern.win_condition.l1.location = "Bermudes_Cavern";
			pchar.quest.BlueBird_inCavern.win_condition.l1.locator_group = "quest";
			pchar.quest.BlueBird_inCavern.win_condition.l1.locator = "BlueBird";
			pchar.quest.BlueBird_inCavern.function = "BlueBird_inCavern";
			LAi_LocationDisableMonstersGen("Bermudes_Cavern", true); //монстров не генерить
			LAi_LocationDisableOfficersGen("Bermudes_Cavern", true); //офицеров не пускать
		break;
//*************************** Открывание двери ***************************
 		case "Step_Door_1":
			dialog.text = "C'est exact. Pour passer par ici, vous devez me payer 20 000 pièces. Si vous ne payez pas, je n'ouvre pas : on n'entre pas ici comme dans un moulin. D'ailleurs, vous n'avez rien à faire là-bas...";
			if(sti(pchar.money) >= 20000)
			{
    			link.l1 = "Voici votre argent, ouvrez.";
    			link.l1.go = "Step_Door_2";
            }
            else
            {
    			link.l1 = "Je n'ai pas assez d'argent.";
    			link.l1.go = "Step_Door_3";
            }
            link.l2 = "Il ne manquait plus que ça ! Payer pour une porte, maintenant.";
    		link.l2.go = "exit";
		break;
 		case "Step_Door_2":
			npchar.Step_Door = true; // fix
			dialog.text = "Entrez, la porte est ouverte. Et ne me remerciez pas !";
			link.l1 = "Eh bien, merci, " + npchar.name + "...";
			link.l1.go = "exit";
			LocatorReloadEnterDisable("Pirates_Shipyard", "reload2", false);
            AddMoneyToCharacter(pchar, -20000);
			pchar.quest.CloseBermudesDungeonDoor.win_condition.l1 = "MapEnter";
            pchar.quest.CloseBermudesDungeonDoor.win_condition = "CloseBermudesDungeonDoor";
		break;
 		case "Step_Door_3":
			dialog.text = "Eh bien, quand vous les aurez, revenez. Et n'essayez pas de me convaincre : c'est inutile...";
			link.l1 = "Argh, eh bien, les mots me manquent !";
			link.l1.go = "exit";
		break;
//*************************** Квест №2, диалоги с Франциско на выходе из Инквизиии ***************************
 		case "Step_S2_1":
			dialog.text = NPCStringReactionRepeat("Ouh, voilà une bonne question... Et pourquoi en avez-vous besoin ?", "J'ai déjà tout dit : la porte est ouverte.", "Je le répète encore une fois : la porte est ouverte.", "וcoutez, combien de temps encore, hein ?", "block", 0, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Il a un livre qui ne lui appartient pas. C'est un voleur.", "J'ai compris...", "Je vois...", "Je suis d'une obstination incompréhensible...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_S2_2", "none", "none", "none", npchar, Dialog.CurrentNode);
		break;
 		case "Step_S2_2":
			dialog.text = "Je vois. Vous savez, ses poursuivants, des marins, m'ont déjà posé la question. Puis un marchand est venu et a essayé de savoir, lui aussi. Je ne leur ai rien dit.";
			link.l1 = "Pourquoi ?";
			link.l1.go = "Step_S2_3";
		break;
 		case "Step_S2_3":
			dialog.text = "Je ne voulais pas charger mon âme d'un péché : ils n'en seraient pas sortis vivants s'ils étaient entrés là-dedans... א vous, je peux le dire, vous êtes, comment dire, "+ GetSexPhrase("pas du genre timide, et costaud avec ça...", "une fille qui sait se battre, vous savez manier le sabre.") +"";
			link.l1 = "Oם seraient-ils allés ?";
			link.l1.go = "Step_S2_4";
		break;
 		case "Step_S2_4":
			dialog.text = "Là oם est allé ce voleur. Par cette porte, à ma droite.";
			link.l1 = "Et derrière la porte, il y a quoi ? Et pourquoi ne laissez-vous personne y entrer ?";
			link.l1.go = "Step_S2_5";
		break;
 		case "Step_S2_5":
			dialog.text = "Derrière la porte, il y a un souterrain ; qui l'a construit, je n'en sais rien : quand je suis devenu propriétaire, il était déjà là. Je ne laisse entrer personne parce que c'est dangereux là-dedans, très dangereux. Le voleur semble s'y être volatilisé...\n"+
                          "Je ne sais pas qui vit là-dedans, ni ce qui y vit. Mais parfois, on entend de là-bas des cris à vous glacer le sang...";
			link.l1 = "Raison de plus... hum, bon, faites-moi entrer.";
			link.l1.go = "Step_S2_6";
		break;
 		case "Step_S2_6":
			dialog.text = "Entrez, c'est ouvert... J'espère vous revoir en ce bas monde.";
			link.l1 = "Vous me reverrez, n'en doutez pas.";
			link.l1.go = "exit";
            LocatorReloadEnterDisable("Pirates_Shipyard", "reload2", false);
            LocatorReloadEnterDisable("Shore3", "reload2_back", false);
            Pchar.quest.Inquisition_fightInDangeon.win_condition.l1 = "location";
            Pchar.quest.Inquisition_fightInDangeon.win_condition.l1.location = "Bermudes_Dungeon";
            Pchar.quest.Inquisition_fightInDangeon.win_condition = "Inquisition_fightInDangeon";
         	pchar.GenQuestBox.Terks_Grot = true;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry5 = 200;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry17 = 300;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade33 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade28 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade34 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade32 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade23 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.pistol5 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.pistol10 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.pistol6 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.potion2 = 5;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian18 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry7 = 5;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.blade5 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.potion2 = 10;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.potionwine = 3;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry1 = 100;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry2 = 80;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry3 = 60;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry4 = 45;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.icollection = 1;
			pchar.GenQuestBox.Bermudes_Dungeon.box1.items.chest = 5;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.jewelry14= 10;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian6 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian11 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian15 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian12 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.indian18 = 1;
            pchar.GenQuestBox.Bermudes_Dungeon.box1.items.Bible = 1;
		break;
		case "PayToRapair1":
			if (pchar.paytorepair != pchar.dayRandom && CheckAttribute(PChar, "paytorepair")) DeleteAttribute(PChar, "paytorepair");
			dialog.text = "Mon cher, j'ai déjà tout préparé pour améliorer votre navire, et vous voulez que je laisse tout tomber comme ça ?!";
			link.l1 = "Je vous comprends. J'espère que 15 000 000 piastres régleront la question ?"
			link.l1.go = "PayToRapair2";
			link.l2 = "Bon, laissez tomber.";
			link.l2.go = "exit";
			if (CheckAttribute(PChar, "paytorepair"))
			{
				dialog.text = "Vous devriez prendre plus soin de votre navire ! Vous m'avez déjà fatigué aujourd'hui... Bon, que vous faut-il ?";
				link.l1 = "Je dois réparer le navire."
				link.l1.go = "shipyard";
				link.l2 = "J'ai besoin de canons pour mon navire.";
				link.l2.go = "Cannons";
			}

		break;
		case "PayToRapair2":
			pchar.paytorepair = pchar.dayRandom;
			AddMoneyToCharacter(pchar, -15000);
			dialog.text = "Voilà qui est mieux ! Que vous faut-il ?";
			link.l1 = "Je dois réparer le navire."
			link.l1.go = "shipyard";
			link.l2 = "J'ai besoin de canons pour mon navire.";
			link.l2.go = "Cannons";
		break;

		//Капремонт пса
		case "WarDogUpgrade_1":
			dialog.text = "Vraiment ? Comme si vous ignoriez que c'est moi qui l'ai conçu en personne.";
			link.l1 = "C'est donc votre création ? Je dois reconnaître que vous avez fait du beau travail.";
			link.l1.go = "WarDogUpgrade_2";
		break;

		case "WarDogUpgrade_2":
			dialog.text = "Oh, ne me faites pas rire. Je sais que c'est une épave. Quand je l'ai fait, j'étais jeune, inexpérimenté, bête. Si je le concevais aujourd'hui, je ne referais pas les vieilles erreurs.";
			link.l1 = "C'est vraiment si grave ? Pour moi, ce bateau reste formidable. Meilleur que bien des bateaux que j'ai vus dans les Caraïbes.";
			link.l1.go = "WarDogUpgrade_3";
		break;

		case "WarDogUpgrade_3":
			dialog.text = "Il pourrait être bien plus rapide, plus manœuvrant, plus solide...";
			link.l1 = "Vraiment ? Vous ne voulez pas le perfectionner ? Corriger vos erreurs, pour ainsi dire.";
			link.l1.go = "WarDogUpgrade_4";
		break;

		case "WarDogUpgrade_4":
			dialog.text = "Je ne crois pas. J'ai beaucoup d'autres choses à faire en ce moment, et le Chien a besoin d'une refonte complète qui demandera beaucoup de temps et d'efforts. Et puis, je n'ai plus l'âge... Ces derniers temps, je n'ai guère envie de revenir à mes anciens projets. Quoique, si vous me rendez un service, mademoiselle, soit, j'y réfléchirai. ";
			link.l1 = "Que voulez-vous ?";
			link.l1.go = "WarDogUpgrade_5";
		break;

		case "WarDogUpgrade_5":
			dialog.text = "Il y a dans l'archipel un constructeur prétentieux, je ne le montrerai pas du doigt. Il se croit le meilleur du monde, meilleur même que moi, et il s'en vante à la moindre occasion, mais ce qu'il ne dit pas aux gens, c'est que toutes ses « idées géniales » sont en fait mes vieux plans, que j'ai abandonnés pour une raison ou une autre.\nVoyez-vous, c'était mon apprenti, jusqu'au jour oם il m'a volé mes esquisses révolutionnaires de construction navale et s'est enfui chez les Anglais. Récemment, il a prétendu avoir construit un navire insubmersible. Le « Titanic », c'est ainsi qu'il l'a appelé. Quel manque de goמt ! Pouah !";
			link.l1 = "Le « Titanic »... דa me dit quelque chose. Oם ai-je bien pu entendre ça ? Enfin, peu importe, continuez.";
			link.l1.go = "WarDogUpgrade_5_1";
		break;

		case "WarDogUpgrade_5_1":
			dialog.text = "Il l'a vendu à un corsaire anglais, qui s'en sert pour piller les ports espagnols du Continent. On dit que ce capitaine est devenu si arrogant qu'il ne prête aucune attention aux navires qui passent, tant qu'ils ne l'attaquent pas, même s'ils arborent le Jolly Roger. Mais si vous l'attaquez, je vous garantis qu'il rendra les coups au décuple.\n Je veux que vous effaciez ce sourire suffisant du visage de mon élève et que vous cassiez son jouet. Coulez l'« insubmersible », et je me mettrai au plan du « Chien de guerre ».";
			link.l1 = "Je me dis qu'il vaudrait peut-être mieux essayer de l'aborder ? Et s'il est vraiment insubmersible ?";
			link.l1.go = "WarDogUpgrade_6";

		break;

		case "WarDogUpgrade_6":
			dialog.text = "Si mon apprenti avait conçu un navire bien à lui, il serait impossible de le couler. Mais je doute que cette tête de mule ait pu saisir l'idée derrière mes calculs. Et puis, au moment du vol, ce plan n'était pas tout à fait prêt, il doit donc forcément avoir des points faibles.\nOubliez l'abordage ! Non seulement il y a là-bas assez d'hommes pour peupler deux villes, mais en plus, vous ne feriez que confirmer la rumeur sur son invincibilité : on dit qu'on ne peut le vaincre qu'en massacrant tout l'équipage. Envoyez-le simplement par le fond.";
			link.l1 = "Avez-vous des conseils sur la façon de s'y prendre ?";
			link.l1.go = "WarDogUpgrade_6_2";
		break;

		case "WarDogUpgrade_6_2":
			dialog.text = "Je ne sais même pas... א vrai dire, je ne sais pas casser les navires, je n'ai fait que les construire toute ma vie. Mais vous pouvez essayer de bourrer deux ou trois bricks de poudre et de vous en servir comme brמlots, si bien sמr vous arrivez à convaincre l'équipage de risquer sa vie.";
			link.l1 = "Vos méthodes sont bien radicales. Et vous dites que vous ne savez pas casser les choses. Bon, je trouverai bien un moyen. Alors, oם puis-je trouver ce navire ?";
			link.l1.go = "WarDogUpgrade_6_1";
		break;

		case "WarDogUpgrade_6_1":
			sld = GetCharacter(NPC_GenerateCharacter("W_Titanic", "off_eng_1", "man", "man", 99, ENGLAND, -1, true));
			FantomMakeCoolestSailor(sld, SHIP_PRINCE, "Titanic", CANNON_TYPE_CANNON_LBS48, 100, 100, 100);
			ref W_Titanic = &RealShips[sti(sld.Ship.Type)];
			W_Titanic.HP = 30000;
			W_Titanic.MastMultiplier = 0.01;
			W_Titanic.TurnRate = 10;
			W_Titanic.MaxCrew = 3500;
			W_Titanic.MinCrew = 3000;
			W_Titanic.SpeedRate = 14;
			W_Titanic.WindAgainstSpeed = 4;
			//W_Titanic.HullArmor = 60;
			W_Titanic.Capacity = 100000;

			SetCrewQuantityFull(sld);
			ProcessHullRepair(sld, 100.0);

			sld.ship.Crew.Morale = 100;
			ChangeCrewExp(sld, "Sailors", 50);
			ChangeCrewExp(sld, "Cannoners", 50);
			ChangeCrewExp(sld, "Soldiers", 50);

			AddItems(sld, "talisman3", 1);
			EquipCharacterByItem(sld, "talisman3");

			SetHalfPerksToChar(sld, true);
			SetCharacterPerk(sld, "CannonProfessional");

			sld.rank = 60;
			SetSelfSkill(sld, 100, 100, 100, 100, 100);
			SetShipSkill(sld, 100, 100, 100, 100, 100, 100, 100, 100, 100);

			SetSPECIAL(sld, 10, 10, 10, 10, 10, 10, 10);
			SetCharacterGoods(sld,GOOD_FOOD,5000);
			SetCharacterGoods(sld,GOOD_BALLS,50000);
			SetCharacterGoods(sld,GOOD_GRAPES,0);
			SetCharacterGoods(sld,GOOD_KNIPPELS,0);
			SetCharacterGoods(sld,GOOD_BOMBS,50000);
			SetCharacterGoods(sld,GOOD_POWDER,100000);
			SetCharacterGoods(sld,GOOD_PLANKS,150);
			SetCharacterGoods(sld,GOOD_SAILCLOTH,150);
			SetCharacterGoods(sld,GOOD_RUM,200);
			SetCharacterGoods(sld,GOOD_WEAPON,600);
			SetCharacterGoods(sld,GOOD_MEDICAMENT,300);

			sld.Abordage.Enable = false;
			sld.Tasks.CanBoarding = false;
			sld.CantBoardEnemies = true;
			//sld.AlwaysFriend = true;
			sld.AlwaysEnemy = true;
			sld.DontRansackCaptain = true;
			sld.AlwaysSandbankManeuver = true;
			Group_FindOrCreateGroup("WarDog");
			Group_SetType("WarDog", "pirate");
			Group_AddCharacter("WarDog", sld.id);
			Group_SetGroupCommander("WarDog", sld.id);
			SetCharacterRelationBoth(sti(sld.index), GetMainCharacterIndex(), RELATION_ENEMY);

			LAi_SetImmortal(sld, false);
			//Group_SetPursuitGroup("WarDog", PLAYER_GROUP);
			Group_SetTaskAttack("WarDog", PLAYER_GROUP);
			Group_LockTask("WarDog");

			WhisperTitanic_ToRandomTown()
			Group_SetAddress("WarDog", pchar.TitanicCity, "Quest_ships", "reload_fort1_siege");
			pchar.TitanicIsKicking = true;
			SetFunctionNPCDeathCondition("WhisperTitanic_Is_Dead", "W_Titanic", false);
			pchar.quest.WhisperTitanic_SurrenderFort.win_condition.l1          = "location";
			pchar.quest.WhisperTitanic_SurrenderFort.win_condition.l1.location = pchar.TitanicCity;
			pchar.quest.WhisperTitanic_SurrenderFort.function             = "WhisperTitanic_SurrenderFort";

			SetQuestHeader("WhisperTitanic");
			AddQuestRecord("WhisperTitanic", 1);
			AddQuestUserData("WhisperTitanic", "sCity", XI_ConvertString("Colony" + pchar.TitanicCity + "Gen"));
			dialog.text = "On dit qu'il assiège une colonie espagnole en ce moment. Les Espagnols ne cessent d'envoyer des renforts, mais le « Titanic » coule escadre après escadre. Il en a sans doute encore pour longtemps avant de raser la ville. J'allais oublier : avant de partir, vous pouvez commander quelques améliorations mineures pour le « Chien de guerre ». Elles s'ajouteront à la refonte.";
			link.l1 = "Eh bien, voyons ce qu'on peut améliorer.";
			link.l1.go = "ship_tunning_start";
		break;

		case "WarDogUpgrade_7":
			dialog.text = "Alors, comment allez-vous faire plaisir au vieil homme ?";
			link.l1 = "Rien pour l'instant.";
			link.l1.go = "exit";
			if(CheckAttribute(pchar, "TitanicIsDown"))
			{
				link.l1 = "L'insubmersible a sombré. La réputation de votre élève est traînée dans la boue pour toujours. Mais je dois reconnaître que votre élève n'était pas un manche : ça n'a pas été facile.  ";
				link.l1.go = "WarDogUpgrade_8";
			}
		break;

		case "WarDogUpgrade_8":
			DeleteAttribute(pchar, "TitanicIsDown");
			dialog.text = "Oui, bonne nouvelle. Je devrais avoir plus de clients maintenant. On dit que le Titanic est parti quelque part vers le nord, oם il a heurté un énorme bloc de glace qui lui a joliment percé la coque.";
			link.l1 = "Qui vous a raconté de telles sornettes ? C'est moi qui l'ai coulé !";
			link.l1.go = "WarDogUpgrade_9";
		break;

		case "WarDogUpgrade_9":
			dialog.text = "Vraiment ? Bon, bon, je vous crois.";
			link.l1 = "Alors, et l'amélioration du Chien ? Vous aviez promis de vous en occuper si je vous aidais avec le Titanic.";
			link.l1.go = "WarDogUpgrade_10";
		break;

		case "WarDogUpgrade_10":
			dialog.text = "Euh, bon... J'ai fait deux ou trois nouveaux plans, en réfléchissant à ce qu'on pouvait améliorer\nCe sera long, donc ça vous coמtera un million de piastres. ";
			link.l1 = "Quoi ?! Ce n'est pas ce dont nous étions convenus.";
			link.l1.go = "WarDogUpgrade_11";
		break;

		case "WarDogUpgrade_11":
			npchar.WarDogUpgradePayment = true;
			AddQuestRecord("WhisperTitanic", 3);
			dialog.text = "Ma chère, ça va demander énormément de travail. Croyez-moi, dans d'autres conditions, j'aurais exigé bien plus, et pas seulement de l'argent. Et cette somme, c'est juste pour ne pas mourir de faim pendant que je travaille.";
			if(sti(pchar.money) >= 1000000)
			{
				link.l1 = "Voici votre million, vieil avare.";
				link.l1.go = "WarDogUpgrade_pay";
			}
			link.l2 = "Ouais. Il faut que j'y réfléchisse.";
			link.l2.go = "exit";
		break;

		case "WarDogUpgrade_pay":
			DeleteAttribute(npchar, "WarDogUpgradePayment");
			dialog.text = "Eh bien, mettons-nous au travail...";
			addMoneyToCharacter(pchar, -1000000);
			link.l1 = "Allez-y, je jetterai un œil.";
			link.l1.go = "WarDogUpgrade_pay_2";
		break;

		case "WarDogUpgrade_pay_2":
			AddQuestRecord("WhisperTitanic", 4);
			CloseQuestHeader("WhisperTitanic");
			shTo = &RealShips[sti(Pchar.Ship.Type)];
			iCaliber = sti(shTo.MaxCaliber);
			switch(iCaliber)
			{
				case 28:
					iCaliber = 4;
				break;
				case 32:
					iCaliber = 5;
				break;
			}
			iCaliber = iCaliber + 1;
			switch(iCaliber)
			{
				case 5:
					iCaliber = 32;
				break;
				case 6:
					iCaliber = 36;
				break;
			}
			shTo.MaxCaliber = iCaliber;

			SetShipTuningAdditiveF(Pchar, "SpeedRate", 2.0);
			SetShipTuningAdditiveF(Pchar, "TurnRate", 10.0);
			SetShipTuningAdditiveI(Pchar, "HP", 1000);
			SetShipTuningAdditiveI(Pchar, "MaxCrew", 120);
			SetShipTuningAdditiveF(Pchar, "WindAgainstSpeed", 1.0);
			SetShipTuningAdditiveI(Pchar, "Capacity", 700);
			shTo.HullArmor = 30;
			shTo.OptCrew = 300;

			DeleteAttribute(npchar, "WarDogUpgradePayment");
			DialogExit();
			AddCharacterExpToSkill(pchar, "Repair", 5000);
			SetLaunchFrameFormParam("Un mois a passé. En regardant travailler Alexus, vous avez beaucoup appris sur la construction navale et la charpenterie.", "", 0.1, 15.0);
			LaunchFrameForm();
			WaitDate("",0,0,30, 0, 20);
			npchar.dialog.currentnode = "WarDogUpgrade_pay_1";
		break;

		case "WarDogUpgrade_pay_1":
			dialog.text = "Eh bien, voilà. Maintenant, je n'ai vraiment pas honte de compter le « Chien » parmi mes œuvres. Vous pouvez prendre la mer. Faites juste attention, je ne voudrais pas que mon travail soit gâché.";
			link.l1 = "D'accord, je vais aller l'essayer.";
			link.l1.go = "exit";
		break;
		//<-Капремонт пса

		case "DutchmanRepair1":
		    dialog.text = "Oh oh oh, est-ce vraiment le Hollandais volant ?! Je ne pensais pas pouvoir un jour le voir de mes propres yeux. א vrai dire, je n'ai jamais cru à cette histoire, mais c'est une véritable légende ! Une puissance de feu incroyable, une coque d'une solidité fantastique, et avec ça, comme il file vite sur les flots, le beau gaillard... Qu'est-ce qui ne va pas chez lui ?";
            link.l1 = "Ce navire est magnifique, maître, mais vous voyez vous-même dans quel état il est. Des flancs couverts de végétation, des fissures dans le pont, des boiseries gauchies : il est complètement impresentable, et dangereux pour les marins : on a l'impression qu'il va tomber en morceaux d'un instant à l'autre.";
			link.l1.go = "DutchmanRepair2";
		break;

		case "DutchmanRepair2":
			dialog.text = "Hum... et il me semblait qu'un tel aspect était plutכt un atout pour un capitaine de votre partie... Enfin, ce n'est pas à moi d'en juger. Bon, je peux réparer ce navire, mais c'est un travail très laborieux qui exigera de sérieuses ressources. Il faudra refaire entièrement le bordé et apporter plusieurs modifications à la structure ; seule la membrure restera intacte. Je prendrai un million de piastres pour ça.";
			if (sti(PChar.money) >= 1000000)
			{
				link.l1 = "Le prix fait mal, mais le bien-être du navire compte plus pour moi. Voici votre argent.";
				link.l1.go = "DutchmanRepair3";
			}
			link.l2 = "Euh, c'est un peu juste pour ma bourse... Je reviendrai plus tard.";
			link.l2.go = "exit";
		break;

		case "DutchmanRepair3":
			AddMoneyToCharacter(PChar, -1000000);
			AddTimeToCurrent(8, 0);

			bool HullSpecial = false;
			bool SailsSpecial = false;
			bool CannonsSpecial = false;
			bool CuBot = false;
			bool BotPack = false;
			bool HighBort = false;

			bool TuneHP = false;
			bool TuneMast = false;
			bool TuneSpeed = false;
			bool TuneTurn = false;
			bool TuneWA = false;
			bool TuneCap = false;
			bool TuneMaxCrew = false;

			shTo = &RealShips[sti(Pchar.Ship.Type)];
			int HullArm = shTo.HullArmor;

			Pchar.Ship.Cannons.Borts.cannonl = sti(shTo.lcannon) + 2;
			Pchar.Ship.Cannons.Borts.cannonr = sti(shTo.rcannon) + 2;
			Pchar.Ship.Cannons.Borts.cannonf = sti(shTo.fcannon);
			Pchar.Ship.Cannons.Borts.cannonb = sti(shTo.bcannon);
			Pchar.Ship.Cannons = sti(shTo.CannonsQuantity) + 4;

			aref arTo, arFrom;
			makearef(arFrom, pchar.Ship.Cannons);
			makearef(arTo, pchar.tempFD);
		    CopyAttributes(arTo,arFrom);//запоминаем состояние пушек во временном атрибуте

			float MM = stf(shTo.MastMultiplier);
			string ShipName = pchar.ship.name;

			if (CheckAttribute(shTo, "Tuning.HullSpecial")) HullSpecial = true;
			if (CheckAttribute(shTo, "Tuning.SailsSpecial")) SailsSpecial = true;
			if (CheckAttribute(shTo, "Tuning.CannonsSpecial")) CannonsSpecial = true;
			if (CheckAttribute(shTo, "Tuning.CuBot")) CuBot = true;
			if (CheckAttribute(shTo, "Tuning.BotPack")) BotPack = true;
			if (CheckAttribute(shTo, "Tuning.HighBort")) HighBort = true;

			if (CheckAttribute(shTo, "Tuning.HP")) TuneHP = true;
			if (CheckAttribute(shTo, "Tuning.MastMultiplier")) TuneMast = true;
			if (CheckAttribute(shTo, "Tuning.SpeedRate")) TuneSpeed = true;
			if (CheckAttribute(shTo, "Tuning.TurnRate")) TuneTurn = true;
			if (CheckAttribute(shTo, "Tuning.WindAgainstSpeed")) TuneWA = true;
			if (CheckAttribute(shTo, "Tuning.Capacity")) TuneCap = true;
			if (CheckAttribute(shTo, "Tuning.MaxCrew")) TuneMaxCrew = true;

			pchar.DontRefresh = true;
			pchar.Ship.Type = GenerateShipExt(SHIP_FLYINGDUTCHMAN_N, true, pchar);
			SetBaseShipData(pchar);
			pchar.ship.name = ShipName;
			shTo = &RealShips[sti(Pchar.Ship.Type)];
			//shTo.HullArmor = HullArm;
			shTo.MastMultiplier = MM;

			makearef(arFrom, pchar.tempFD);
			makearef(arTo, pchar.Ship.Cannons);
		    CopyAttributes(arTo,arFrom);//копируем старые пушки на новый корабль
			DeleteAttribute(pchar, "tempFD");//удаляем временный атрибут
			pchar.Ship.Cannons.borts.cannonl.damages.c27 = 1.0; //прописываем 4 дополнительных пушки
			pchar.Ship.Cannons.borts.cannonl.damages.c28 = 1.0;
			pchar.Ship.Cannons.borts.lcannon.damages.c27 = 1.0;
			pchar.Ship.Cannons.borts.lcannon.damages.c28 = 1.0;
			pchar.Ship.Cannons.borts.cannonr.damages.c27 = 1.0;
			pchar.Ship.Cannons.borts.cannonr.damages.c28 = 1.0;
			pchar.Ship.Cannons.borts.rcannon.damages.c27 = 1.0;
			pchar.Ship.Cannons.borts.rcannonl.damages.c28 = 1.0;

			if (TuneHP)
			{
				shTo.HP = sti(shTo.HP) + makeint(sti(shTo.HP)/5);
				shTo.Tuning.HP = true;
			}
			if (TuneMast)
			{
				shTo.Tuning.MastMultiplier = true;
			}
			if (TuneSpeed)
			{
				shTo.SpeedRate = (stf(shTo.SpeedRate) + stf(shTo.SpeedRate)/10.0);
				shTo.Tuning.SpeedRate = true;
			}
			if (TuneTurn)
			{
				shTo.TurnRate = (stf(shTo.TurnRate) + stf(shTo.TurnRate)/5.0);
				shTo.Tuning.TurnRate = true;
			}
			if (TuneWA)
			{
				shTo.WindAgainstSpeed = FloatToString(stf(shTo.WindAgainstSpeed) + 0.5* stf(shTo.WindAgainstSpeed) / stf(shTo.Class) + 0.005, 2);
				shTo.Tuning.WindAgainstSpeed = true;
			}
			if (TuneCap)
			{
				shTo.Capacity = sti(shTo.Capacity) + makeint(sti(shTo.Capacity)/5);
				shTo.Tuning.Capacity = true;
			}
			if (TuneMaxCrew)
			{
				shTo.MaxCrew = sti(shTo.MaxCrew) + makeint(sti(shTo.MaxCrew)/10);
				shTo.Tuning.MaxCrew = true;
			}

			if (HullSpecial)
			{
				shTo.Tuning.HullSpecial = 1;
				shTo.price = makeint(sti(shTo.price)*1.5);
			}
			if (SailsSpecial)
			{
				shTo.Tuning.SailsSpecial = 1;
				shTo.price = makeint(sti(shTo.price)*1.35);
			}
			if (CannonsSpecial)
			{
				shTo.Tuning.CannonsSpecial = 1;
				shTo.price = makeint(sti(shTo.price)*1.25);
			}
			if (CuBot)
			{
				shTo.Tuning.CuBot = 1;
				shTo.price = makeint(sti(shTo.price)*1.4);
			}
			if (BotPack)
			{
				shTo.Tuning.BotPack = 1;
				shTo.price = makeint(sti(shTo.price)*1.5);
				shTo.Capacity = sti(shTo.Capacity) + makeint(sti(shTo.Capacity)/2);
				shTo.HP = sti(shTo.HP) - makeint(sti(shTo.HP)/2);
				if (pchar.ship.hp > sti(shTo.HP)) pchar.ship.hp = sti(shTo.HP);
			}
			if (HighBort)
			{
				shTo.Tuning.HighBort = 1;
				shTo.price = makeint(sti(shTo.price)*1.4);
			}

			dialog.text = "Parfait, je commence la réparation... C'est prêt ! Votre légende va briller de nouveaux feux.";
			link.l1 = "Merci, maître.";
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

void checkMatherial(ref Pchar, ref NPChar, int good1, int good2, int good3)
{
    int amount;

    amount = GetSquadronGoods(Pchar, good1) - sti(NPChar.Tuning.Matherial1);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial1);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial1);
    }
    RemoveCharacterGoods(Pchar, good1, amount);
    NPChar.Tuning.Matherial1 = sti(NPChar.Tuning.Matherial1) - amount;

    /* amount = GetCharacterItemWithCabin(pchar, good2, true) - sti(NPChar.Tuning.Matherial2);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial2);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial2);
    }
    TakeNItemsWithCabin(pchar, good2, -amount, false);
    NPChar.Tuning.Matherial2 = sti(NPChar.Tuning.Matherial2) - amount;

    amount = GetCharacterItemWithCabin(pchar, good3, true) - sti(NPChar.Tuning.Matherial3);
    if (amount < 0)
    {
       amount = amount + sti(NPChar.Tuning.Matherial3);
    }
    else
    {
        amount = sti(NPChar.Tuning.Matherial3);
    }
    TakeNItemsWithCabin(pchar, good3, -amount, false);
    NPChar.Tuning.Matherial3 = sti(NPChar.Tuning.Matherial3) - amount; */
}
