
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":
			dialog.text = "Quoi ? Qui êtes-vous ? Que me voulez-vous ?";
			link.l1 = "Pardon de vous avoir dérangé. Au revoir.";
			link.l1.go = "exit";
			link.l2 = "Du calme, du calme. Qui êtes-vous ?";
			link.l2.go = "Next_1";
			LAi_CharacterPlaySound(NPChar, "GR_Kakovi_Merzavczi");
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
		break;

		case "Next_1":
            dialog.text = "Je m'appelle Albrecht Zalpfer, mais je n'ai aucune envie de vous parler.";
            link.l1 = "Hum... Pardonnez-moi, mais je ne comprends pas, monsieur, pourquoi ne pas discuter ?";
			link.l1.go = "Next_2";
			link.l2 = "Oh, eh bien, si c'est comme ça, au revoir.";
			link.l2.go = "exit";
		break;

		case "Next_2":
            dialog.text = "Parce que j'ai l'intention de quitter cette île oם ne vivent que des gredins. Je suis la voix qui crie dans le désert ! Personne ne veut m'écouter, personne ne veut entrer dans une ère nouvelle, ya !";
            link.l1 = "וcoutez, vous ne perdrez rien à me raconter ce qui s'est passé.";
			link.l1.go = "Next_4";
			link.l2 = "Quelle est donc cette ère nouvelle ?";
			link.l2.go = "Next_3";
		break;

		case "Next_3":
            dialog.text = "Il n'y aura pas d'ère nouvelle, pas de progrès, et tout ça à cause de ces crétins bornés qui n'ont pas assez de cervelle pour m'écouter, ya. Je dois quitter cette île, et au plus vite. Je déteste être ici.";
            link.l1 = "Oui, c'est dommage. Bon sang, pas de progrès, rendez-vous compte ! וcoutez, vous ne perdrez rien à me raconter ce qui s'est passé.";
			link.l1.go = "Next_4";
		break;

		case "Next_4":
			sld = CharacterFromID("Charles_shipyarder");
            dialog.text = "J'ai travaillé plusieurs années au chantier naval de ce gredin de "+sld.name+". Ah, comme assistant. Et puis il m'a renvoyé parce que je lui avais demandé des ouvriers pour réaliser ma dernière invention !"+
							" Je lui ai dit que cette invention ouvrirait une ère nouvelle dans la construction navale, que ce serait une véritable révolution, ya ! Mais on m'a mis sous les verrous à la minute même oם le gouverneur a entendu dire que je préparais une révolution\n"+
							"On m'a relâché il n'y a pas longtemps, mais personne ne veut m'embaucher, et me voilà sans le sou.";
            link.l1 = "Oui, on dirait que vous avez vraiment été incompris. Alors, en quoi consiste votre découverte ?";
			link.l1.go = "Next_5";
			link.l2 = "J'ai une idée, monsieur. Si vous avez travaillé dans un chantier naval, vous devez beaucoup savoir sur la construction des navires. Je vous engage comme charpentier, et vous quitterez cette île qui vous déplaît tant.";
			link.l2.go = "Next_6";
		break;

		case "Next_5":
			sld = CharacterFromID("Charles_shipyarder");
            dialog.text = "Aha ! Je m'en doutais ! Je soupçonnais que vous étiez l'un des espions de mon ancien patron, le maître charpentier "+sld.name+". Ah ! Je ne dirai plus un mot ! D'abord, vous me jetez en prison, et ensuite vous voulez voler mon invention ? Vous n'êtes tous que des gredins ! Des gredins, ya ! Je ne vous parlerai plus !";
            link.l1 = "Euh, l'ami, il m'est arrivé de voler, surtout des navires, mais des idées ? Jamais ! Et qu'est-ce que je ferais de vos inventions ? Je n'y connais rien en construction navale. Je voulais juste savoir...";
			link.l1.go = "Next_7";
		break;

		case "Next_6":
            dialog.text = "CHARPENTIER ? Qu'entends-je, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ? Vous voulez m'engager, moi, le plus remarquable inventeur de notre siècle, comme un misérable artisan de bord ? Vous êtes dans votre... quoique... J'accepte ! J'ai horreur de cette misérable île anglaise ! Parfait ! Je fais juste mes bagages, et on ne me reverra plus ! Je suis prêt, "+ GetSexPhrase("Herr", "Fräulein") +" ! Oם est votre navire ?";
            link.l1 = "Au port, bien sמr, monsieur Zalpfer. J'espère que vous ne changerez pas d'avis et que vous serez à bord au moment de lever l'ancre.";
			link.l1.go = "Next_8";
		break;

		case "Next_7":
			sld = CharacterFromID("Charles_shipyarder");
            dialog.text = "Jamais ! Vous êtes "+ GetSexPhrase("un menteur", "une menteuse") +", "+ GetSexPhrase("un escroc", "une voleuse") +" tout comme votre maître "+sld.name+", ya ! Quand on m'a relâché de prison, je suis allé voir ce gredin et j'ai exigé qu'il me rende mes plans. Mais il s'est contenté de rire et m'a dit qu'il les avait brמlés. Ha ! Mais je sais, je sais qu'il les a gardés pour lui, ya, et maintenant il veut découvrir l'essence même de cette invention ; eh bien, non ! Qu'il se casse la tête ! Je ne vous parlerai plus !";
            link.l1 = "Pardonnez-moi, monsieur l'inventeur, mais vous devriez réfléchir à la conception de votre tête. Il y manque assurément quelque chose. Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Next_9";
		break;

		case "Next_9":
            dialog.text = "Ha ! C'est vous ! Vous êtes un espion ! Vous voulez voler le secret de mon invention géniale : je ne vous dirai rien !";
			link.l1 = "J'ai une idée, monsieur. Si vous avez travaillé au chantier naval, vous devez vous y connaître. Je vous engage comme charpentier, et vous quitterez cette île qui vous déplaît tant.";
			link.l1.go = "Next_6";
            link.l2 = "Euh, du calme, du calme. Je ne tenais pas vraiment à vous parler. Bonne journée.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Next_9";
		break;

		case "Next_8":
            dialog.text = "Mais sachez une chose : je quitterai votre navire dès que nous aurons atteint Port Royal. J'ai entendu dire que le gouverneur, là-bas, est un homme compréhensif, capable d'apprécier le génie de mon invention.";
            link.l1 = "Sans aucun doute, monsieur Zalpfer, et maintenant, rendez-vous à mon navire.";
			link.l1.go = "Cod_1"
			if (pchar.rank >= 1 && pchar.rank <= 4)
			{
				pchar.questTemp.PDM_AZ_6rang = true;
			}
		break;

		case "Cod_1":
			SetQuestHeader("ColonyBuilding");
			AddQuestRecord("ColonyBuilding", "0.1");
			AddQuestUserData("ColonyBuilding", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ColonyBuilding", "sSex1", GetSexPhrase("", "e"));
			sld = CharacterFromID("Albreht_Zalpfer");
			SetCharacterRemovable(sld, true);
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			LAi_RemoveLoginTime(sld);
			sld.loyality = MAX_LOYALITY;
			sld.Payment = true;
			sld.quest.OfficerPrice = sti(pchar.rank)*10;
			sld.OfficerWantToGo.DontGo = true;
			sld.rank = 4;
			SetSelfSkill(sld, 5, 40, 5, 5, 5);
			SetShipSkill(sld, 5, 5, 5, 5, 5, 35, 5, 5, 5);
			Pchar.quest.PDM_Albreht_Vhod.win_condition.l1           = "location";
        	Pchar.quest.PDM_Albreht_Vhod.win_condition.l1.location  = "PortRoyal_town";
        	Pchar.quest.PDM_Albreht_Vhod.win_condition              = "PDM_Albreht_Vhod";
			LAi_SetActorType(sld);
			LAi_ActorRunToLocation(sld, "reload", "reload1", "", "", "", "", -1);
			//sld.dialog.filename = "Quest\PDM\Albreht_Zalpfer.c";
			//sld.dialog.currentnode = "Pl_1";
			DialogExit();
		break;

		/*case "Pl_1":
            dialog.text = "I'm going to leave your ship as soon as we reach Port Royal. I have heard that the governor there is an understanding man and is able to appreciate the genius of my invention.";
            link.l1 = "Yes, Mr. Zalpfer, I remember.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pl_1";
		break;*/

		case "Ja_1":
			sld = CharacterFromID("Charles_shipyarder");
            dialog.text = "Merci, "+ GetSexPhrase("Herr", "Fräulein") +" "+pchar.name+". Vous m'avez donné la chance de fuir ce nid d'intrigues, et je vous en suis très reconnaissant\n"+
							"En gage de ma gratitude, je vous prie d'accepter ces plans qui révèlent l'essence de mon invention. Si la nouvelle de ma mort vous parvient, ou si ce gredin de "+sld.name+" tente de s'approprier le titre d'inventeur, je veux que ces papiers ne restent qu'entre vos mains, ya. Toute personne qui s'y connaît un peu en mécanique comprendra ce qui y est écrit.";
            link.l1 = "Merci, Albrecht, "+ GetSexPhrase("ravi", "ravie") +" de vous avoir aidé. Adieu.";
			link.l1.go = "Finish";
			AddQuestRecord("ColonyBuilding", "0.2");
			RemovePassenger(pchar, NPChar);
			RemoveCharacterCompanion(pchar, NPChar);
			NextDiag.TempNode = "Ja_2";
		break;

		case "Ja_2":
            dialog.text = "Oh ! C'est incroyable, "+ GetSexPhrase("Herr Kapitan", "Fraulein") +" ! Ils sont tous si stupides ! Ils n'ont tout simplement pas su comprendre à quel point je suis génial, vous imaginez ? Je devrais aller à Londres, à la Société royale ! Ou à l'Académie de Paris ! Seuls des gens de là-bas sauront apprécier mon cerveau. Ya, je devrais faire voile vers l'Angleterre. Emmenez-moi en Angleterre. Immédiatement...";
            link.l1 = "Pardon, Albrecht, mais pour l'instant, je n'ai pas"+ GetSexPhrase(" l'intention", " l'intention") +" de faire voile vers l'Europe. J'ai encore beaucoup d'affaires en cours ici.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Ja_2";
		break;

		case "Finish":
			Log_info("Plans reçus d'Albrecht Zalpfer.");
			PlaySound("Interface\important_item.wav");
			if (CheckAttribute(pchar, "questTemp.PDM_AZ_6rang"))
			{
				GiveItem2Character(PChar, "Ship_Print_6");
			}
			else
			{
				GiveItem2Character(PChar, "Ship_Print_5");
			}
			DeleteAttribute(pchar, "questTemp.PDM_AZ_6rang");
			AddCharacterExpToSkill(pchar, "Sailing", 130);
			ChangeCharacterReputation(pchar, 3);
			LAi_SetCitizenType(npchar);
			npchar.lifeday = 0;
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

	}
}
