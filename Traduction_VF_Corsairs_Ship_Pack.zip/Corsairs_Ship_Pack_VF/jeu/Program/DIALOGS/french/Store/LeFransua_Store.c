// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{

	switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 7 - provisions for the frigate, and the dock hands
			if (CheckAttribute(PChar, "SmallMongrel"))
			{
				if (PChar.SmallMongrel == "7")
				{
					link.l30 = "La question va vous paraître étrange, mais une frégate lourde a-t-elle fait escale dans votre baie ?";
					link.l30.go = "BO_SM_ST_1";
				}
				if (PChar.SmallMongrel == "12")
				{
					link.l31 = "Je cherche deux dockers, Frank et Janson. Ils...";
					link.l31.go = "BO_SM_ST_3";
				}
			}
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?"), "Il y a quelque temps, dans mon magasin, vous avez essayé de me poser une question...", "C'est la troisième question aujourd'hui. Je dois faire du commerce, pas dire des bêtises...",
                          "Encore des questions ? Et si on faisait plutכt des affaires ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Oui, exactement, j'ai essayé...",
                      "Oui, c'est vraiment la troisième fois...", "Hum, faisons peut-être des affaires...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "KillLoy_toSeek")
			{
				link.l1 = "Excusez-moi, Edward Law vous a-t-il acheté un navire ?";
				link.l1.go = "PL_Q3_1";
			}
		break;
		//пиратка, квест №3, поиски Лоу
		case "PL_Q3_1":
			dialog.text = NPCStringReactionRepeat("Moi ?! Vous me confondez avec quelqu'un d'autre, je suis marchand, mais les navires... Je ne vends pas de navires ! Vous, "+ GetSexPhrase("jeune homme", "ma fille") +" devez vous adresser aux constructeurs du chantier naval. Oui, à eux, et à moi pour tout le reste !",
				"Vous me l'avez déjà demandé. Non, il n'en a pas acheté.",
				"Non, "+ GetSexPhrase("jeune homme", "jeune demoiselle") +", non...",
                "Oh, que vous êtes pénible !!!", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Oui, mais il n'y a pas de chantier naval dans votre ville !",
				"Je vois...",
                "Oui, je vois...",
				"Hum, je m'en vais déjà...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q3_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q3_2":
			dialog.text = "Je n'y peux rien : j'aurais beau le vouloir, un chantier naval ne va pas sortir de terre. Demandez à quelqu'un d'autre...";
			link.l1 = "C'est juste... eh bien, merci quand même.";
			link.l1.go = "exit";
			AddQuestRecord("Pir_Line_3_KillLoy", "3");
		break;

		// Gregg: The Black Orchid, chapter 7 -->
		case "BO_SM_ST_1":
			dialog.text = "Oui, une. Mes gars lui ont chargé des vivres, une demi-journée de portage.";
			link.l1 = "Son capitaine a-t-il dit oם il allait ?";
			link.l1.go = "BO_SM_ST_2";
		break;

		case "BO_SM_ST_2":
			dialog.text = "Il n'a rien dit du tout. Il a payé sans marchander et il est parti. J'aime ce genre de clients.";
			link.l1 = "Il a payé sans marchander et n'a rien dit. Il était pressé, donc. Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelInLeFransua");
		break;

		case "BO_SM_ST_3":
			dialog.text = "...(l'interrompant)... Ils ont été enlevés !";
			link.l1 = "Quoi ?!";
			link.l1.go = "BO_SM_ST_4";
		break;

		case "BO_SM_ST_4":
			dialog.text = "...(s'étranglant de rire)... Enlevés et enfermés. Dans l'arrière-boutique. Pour que Frank ne file pas boire du rhum avant l'ouverture. Allez-y, ils sont tous les deux là-dedans.";
			link.l1 = "Très drכle. Menez-moi à vos prisonniers.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToLeFransuaStoreRoom");
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);
}

