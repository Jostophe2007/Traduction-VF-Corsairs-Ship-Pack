
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "א qui ai-je l'honneur de parler ?";
			link.l1 = "Euh... Je m'appelle " + GetFullName(pchar) + " – je suis capitaine du navire « " + PChar.Ship.Name + " ».";
			link.l1.go = "talk_1";
			if (bBettaTestMode && !CheckAttribute(pchar,"ScamFanActive"))
			{
				link.l2 = "Invoquer le Kraken";
				link.l2.go = "Kraken";
			}
			NextDiag.TempNode = "First time";
		break;

		case "meeting":
			dialog.text = "א quoi dois-je ce plaisir, capitaine " + GetFullName(pchar) + " ?";
			link.l1 = "J'aimerais me renseigner sur les prochains combats.";
			link.l1.go = "ArenaBattle_1";
			link.l2 = "J'aimerais m'entraîner.";
			link.l2.go = "academy";
			if (CheckAttribute(pchar,"ScamFanActive") && !CheckAttribute(pchar,"KnowScam"))
			{
				link.l3 = "Vous ne sauriez pas, par hasard, quelque chose sur ce « fan » du champion ? ";
				link.l3.go = "legend";
			}
			link.l99 = "Je voulais juste vous voir, " + GetFullName(NPChar) + ". א plus tard.";
			link.l99.go = "exit";
			if (bBettaTestMode && !CheckAttribute(pchar,"ScamFanActive"))
			{
				link.l4 = "Invoquer le Kraken";
				link.l4.go = "Kraken";
			}
			NextDiag.TempNode = "meeting";
		break;

		/////////////////////////////////////////////////////////////////////////////////////////
		/////////// Бои на арене - возможность сделать ставки или самому участвовать ////////////
		/////////////////////////////////////////////////////////////////////////////////////////
		case "ArenaBattle_1":
			if(GetCharacterItem(PChar, "ArenaBilet") > 0)
			{
				dialog.text = "Capitaine, vous alliez assister à la compétition.";
				link.l1 = "Ah oui, c'est vrai.";
				link.l1.go = "exit";
				break;
			}

			if(CheckAttribute(PChar, "Arena"))
			{
				if(PChar.AcademyLand.Begin == true)
				{
					dialog.text = "Hum... א mon avis, vous n'avez pas terminé l'entraînement dont nous avons récemment convenu.";
					link.l1 = "Euh, ah bon ? Dans ce cas, permettez-moi de prendre congé.";
					link.l1.go = "exit";
				}
				else
				{
					if(PChar.Arena == "Generate")
					{
						dialog.text = "Si cela vous intéresse, les prochains combats auront lieu sous peu.";
						link.l1 = "Oui, ça m'intéresse. J'aimerais en savoir plus.";
						link.l1.go = "ArenaBattle_2";
						link.l2 = "Hum... Merci pour l'information, mais je n'ai sans doute pas le temps pour ça en ce moment...";
						link.l2.go = "exit";
					}
					else
					{
						if(PChar.Arena == "Prepare")
						{
							dialog.text = "Hum... א mon avis, capitaine, vous devriez déjà être sur le lieu de l'événement : vous avez déjà choisi la compétition !";
							link.l1 = "Ah bon ? Euh... J'y cours !";
							link.l1.go = "exit";
						}
						else
						{
							dialog.text = "Malheureusement, capitaine " + GetFullName(pchar) + ", aucun combat n'est prévu pour l'instant.";
							link.l1 = "Pardon. Alors, à plus tard !";
							link.l1.go = "exit";
						}
					}
				}
			}
			else
			{
				dialog.text = "Malheureusement, capitaine " + GetFullName(pchar) + ", aucun combat n'est prévu pour l'instant.";
				link.l1 = "Pardon. Alors, à plus tard !";
				link.l1.go = "exit";
			}

		break;

		case "ArenaBattle_2":
			dialog.text = "Voulez-vous participer à un duel ou essayer de gagner un peu d'argent ?";
			link.l1 = "J'aimerais participer, ou bien parier.";
			link.l1.go = "ArenaBattle_3";
			link.l3 = "Si c'est possible, j'aimerais juste regarder.";
			link.l3.go = "ArenaBattle_5";
		break;

		case "ArenaBattle_3":
			NextDiag.CurrentNode = "Meeting";
			DialogExit();
			LaunchArena(false);
		break;

		case "ArenaBattle_5":
			int iMoney = sti(PChar.Arena.ViewCost);
			dialog.text = "Hum... Je peux peut-être vous offrir cette possibilité. Pour " + iMoney + " pièces d'or, bien sמr.";

			if(sti(PChar.money) >= iMoney)
			{
				link.l1 = "D'accord. Les voici, vos " + iMoney + " piastres.";
				link.l1.go = "ArenaBattle_6";
			}
			else
			{
				link.l1 = "Oh... Je ne peux sans doute pas me permettre ce genre de divertissement. Je reviendrai une autre fois.";
				link.l1.go = "exit";
			}

			link.l2 = "Et puis quoi encore, payer pour un spectacle minable !";
			link.l2.go = "exit";
		break;

		case "ArenaBattle_6":
			AddMoneyToCharacter(PChar, -sti(PChar.Arena.ViewCost));
			GiveItem2Character(PChar, "ArenaBilet");
			dialog.text = "Parfait. Prenez ce billet et montrez-le à l'entrée... ...(sourit)...";
			link.l1 = "Héhé. Merci.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("PrepareArenaOdds");
			PChar.Arena.Mode.NotOdd = true;
		break;

		/////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////// ТРЕНИРОВКИ ////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////
		case "academy":
			if(GetCharacterItem(PChar, "ArenaBilet") > 0)
			{
				dialog.text = "Capitaine, vous alliez assister à la compétition.";
				link.l1 = "Ah oui, c'est vrai.";
				link.l1.go = "exit";
				break;
			}

			if(PChar.AcademyLand.Can == false)
			{
				if(PChar.AcademyLand.Begin == true)
				{
					dialog.text = "Hum... א mon avis, vous n'avez pas encore terminé l'entraînement précédent...";
					link.l1 = "Euh, ah bon ? Dans ce cas, permettez-moi de prendre congé.";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Hum... Je ne peux pas vous fournir d'hommes pour ça pour le moment. Revenez plus tard.";
					link.l1 = "Eh bien, c'est dommage.";
					link.l1.go = "exit";
				}
			}
			else
			{
				if(PChar.Arena != "Prepare")
				{
					dialog.text = "Hum... Quel type d'épreuve voulez-vous essayer ?";
					link.l1 = "Voyons voir.";
					link.l1.go = "academy_land";
				}
				else
				{
					dialog.text = "Hum... א mon avis, capitaine, vous avez déjà choisi la compétition ! Ce n'est pas le moment de vous entraîner.";
					link.l1 = "Ah bon ? Euh... J'y cours !";
					link.l1.go = "exit";
				}
			}
		break;

		case "academy_land":
			NextDiag.CurrentNode = "Meeting";
			DialogExit();
			LaunchAcademyLand();
		break;

		case "academy_sea":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		/////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////// ПЕРВАЯ ВСТРЕЧА ////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////
		case "talk_1":
			dialog.text = "Ravi de vous rencontrer, capitaine. Je m'appelle " + GetFullName(NPChar) + ". Hum... Pour être franc, je n'ai jamais entendu parler de vous. Qu'est-ce qui vous amène ici, capitaine ?";
			link.l1 = "Eh bien, comment dire. J'ai tendance à explorer des territoires encore jamais vus. C'est comme ça que j'ai trouvé votre colonie. Mais quel genre de colonie est-ce donc ?";
			link.l1.go = "talk_2";
		break;

		case "talk_2":
			dialog.text = "Oh, c'est une très longue histoire dont je n'aime pas me souvenir... Mais elle vaut sans doute d'être racontée... Quoique vous l'ayez peut-être déjà entendue.";
			link.l1 = "Hum... Je ne me souviens de rien.";
			link.l1.go = "talk_3";
		break;

		case "talk_3":
			dialog.text = "Il y a quelques années, un grand navigateur a décidé de bâtir une colonie sur cette île. Le transport des marchandises nécessaires a duré des mois, et la colonie se construisait. Une fois la construction du fort achevée, on a décidé de passer à celle de la colonie proprement dite... Mais soudain, les puissances coloniales ont eu vent de ce nouveau chantier et ont décidé d'intervenir. Presque tout le monde a été tué, et le fort comme les débuts de la nouvelle colonie ont été détruits... Il y avait ce petit camp oם vivaient les ouvriers et les esclaves. Tous ceux qui vivent aujourd'hui dans ce village étaient eux aussi promis à la mort, mais nous avons été sauvés par un heureux hasard : à ce moment-là, nous étions partis loin dans la jungle chercher du bois, et à notre retour, nous avons découvert ce désastre... Tous ceux qui vivent maintenant dans ce village sont des bâtisseurs et des hommes de l'équipage de ce capitaine.";
			link.l1 = "Oui... C'est une triste histoire. Mais que faites-vous ici ?";
			link.l1.go = "talk_4";
		break;

		case "talk_4":
			dialog.text = "Il nous a fallu longtemps pour nous remettre d'un tel désastre, d'autant plus que nous nous sommes retrouvés seuls sur une île déserte. Nous avons dמ manger des plantes et des insectes. Mais avec le temps, nous avons réussi à bâtir ce village, et plus tard, une fois un peu plus forts, nous avons commencé à nous entraîner sans relâche ; et ces bâtisseurs et ces esclaves qui avaient failli mourir de faim et tenaient à peine une épée ont pu, grâce à une endurance et une volonté incroyables, bien apprendre l'art de l'escrime. Bientכt, notre bourgade a été remarquée par des navires inconnus qui passaient par là, et des rumeurs sur notre village ont commencé à se répandre dans toutes les Caraïbes. Le temps a passé, et aujourd'hui, nous pouvons dire que sans le malheur qui nous est arrivé, rien de tout cela n'aurait peut-être existé : ces esclaves auraient continué à pourrir en travaillant pour de gros marchands dans des conditions insupportables, et nous nous serions partagé quelques sous en vénérant notre capitaine... Maintenant, divers tournois ont lieu ici de temps en temps, des duels aux grands tournois, et on peut aussi parier. On ne peut participer qu'en payant, mais si vous gagnez, tout l'argent sera à vous ! Et bien sמr, nous pouvons vous fournir des hommes pour différents types d'entraînement. Moyennant une petite somme, bien sמr.";
			link.l1 = "Très intéressant ! Je pense que j'aimerais "+ GetSexPhrase("","") +"recourir à vos services.";
			link.l1.go = "meeting";
			NextDiag.TempNode = "meeting";
		break;
		// говорим при первой встрече <--

		// На арене -->
		case "FightInArena_1":
			dialog.text = "Salutations, capitaine " + GetFullName(pchar) + ". Vous allez affronter un adversaire de valeur. Le duel se déroule en plusieurs manches, jusqu'à trois victoires de l'un des participants. Bonne chance !";
			link.l1 = "Merci pour l'information, " + NPChar.lastname + ".";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ArenaDuelTalkWithEnemy");
		break;

		case "FightInArena_2":
			switch(sti(PChar.Arena.Duel.Win))
			{
				case 0:
					dialog.text = LinkRandPhrase("Vous avez perdu, capitaine " + GetFullName(PChar) + " ! La prochaine fois, la chance vous sourira peut-être !", "Dommage que vous ayez échoué, capitaine " + pchar.name + ".", "Eh, la victoire vous a échappé de peu ! Bon, vous aurez peut-être plus de chance la prochaine fois.");
					link.l1 = LinkRandPhrase("Eh... Pas de chance.", "Mais vous avez vu comment je lui suis rentré dedans ?!", "Votre arène, c'est n'importe quoi !");
					link.l1.go = "exit";
					AddDialogExitQuestFunction("ArenaDuelTheEnd");
				break;

				case 1:
					dialog.text = LinkRandPhrase("Vous l'avez eu, cap'tain ! J'étais de votre cכté. Vous avez honnêtement mérité vos gains. Tenez, ces " + sti(PChar.Arena.Duel.Prize) + " pièces d'or vous reviennent de droit.", "Comment vous l'avez battu, capitaine ! Et cette première passe ! J'ai admiré vos actions. Vous méritez bien vos " + sti(PChar.Arena.Duel.Prize) + " pièces d'or.", "Vous avez encore prouvé à tout le monde qui fait la loi ici. Félicitations, voici vos " + sti(PChar.Arena.Duel.Prize) + " pièces d'or en guise de prix.");
					link.l1 = LinkRandPhrase("Merci ! א bientכt.", "Merci, mon cher. Je reviendrai sans faute la prochaine fois.", "Héhé !");
					link.l1.go = "exit";
					AddMoneyToCharacter(PChar, sti(PChar.Arena.Duel.Prize));
					AddDialogExitQuestFunction("ArenaDuelTheEnd");
				break;
			}
		break;

		case "FightInArena_3":
			dialog.text = LinkRandPhrase("Ha ha ha ! Bienvenue en enfer, capitaine " + GetFullName(pchar) + " ! Vous allez devoir faire de sérieux efforts pour sortir vainqueur de ce combat contre ces monstres de la nature.", "Alors, vous vous sentez d'attaque pour affronter les rejetons du diable"+ GetSexPhrase("","") +" ?", "Ah, vous voilà, capitaine. Héhé, le public vous attend.");
			link.l1 = LinkRandPhrase("Vous en avez vu d'autres.", "Je vais les réduire en bouillie !", "Prépare l'argent, l'ami.");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartArenaEtapsBattle");
		break;

		case "FightInArena_4":
			switch(sti(PChar.Arena.Etaps.Win))
			{
				case 0:
					dialog.text = LinkRandPhrase("Ces créatures ont failli vous mettre en pièces ! La prochaine fois, vous aurez peut-être plus de chance.", "Oui, oui, elles ont failli vous dévorer ! Ha ha ha !", "Vous leur avez bien mis la pâtée, à ces créatures ! Mais vous n'avez pas eu assez de force pour toutes. Revenez donc.");
					link.l1 = LinkRandPhrase("Oui, vous avez des sabres complètement émoussés ! Et puis, le toit est tout de travers...", "Oם avez-vous trouvé ces monstres ?! Bon, peu importe, je reviendrai ! Dites-le-leur...", "Je n'ai simplement pas eu de chance !");
					link.l1.go = "exit";
					AddDialogExitQuestFunction("ArenaEtapsTheEnd");
				break;

				case 1:
					dialog.text = LinkRandPhrase("Comme vous les avez arrangés ! J'aimerais qu'il y ait plus de combattants comme vous ! Vous avez honnêtement mérité vos gains. Tenez, ces " + sti(PChar.Arena.Etaps.Prize) + " piastres vous reviennent de droit. Revenez quand vous voulez.", "Ouais, je ne m'attendais pas à ce que ce soit si rapide. Oui, vous savez y faire : ce n'est pas n'importe quel brave qui ose affronter ces créatures. Voici vos gains : " + sti(PChar.Arena.Etaps.Prize) + " pièces d'or.", "Elles ont failli tomber en miettes sous votre lame ! Quel combat ! Voici vos gains : " + sti(PChar.Arena.Etaps.Prize) + " pièces d'or.");
					link.l1 = LinkRandPhrase("Héhé. Personne ne peut me battre !", "Commandez-moi une fournée de ces créatures. Je reviendrai sans faute !", "Vous avez vu comment j'ai coupé la pince de ce crabe ?!");
					link.l1.go = "exit";
					AddMoneyToCharacter(PChar, sti(PChar.Arena.Etaps.Prize));
					AddDialogExitQuestFunction("ArenaEtapsTheEnd");
				break;
			}
		break;

		case "FightInArena_5":
			dialog.text = LinkRandPhrase("Vous voilà, capitaine " + GetFullName(pchar) + " ! Eh bien, vous tombez à pic : tous les participants sont réunis, et plus rien ne nous empêche de commencer notre tournoi.", "Salutations, capitaine " + GetFullName(PChar) + ". Vous allez avoir des combats très difficiles, je vous le promets. Enfin, si vous passez le premier tour, bien sמr. Haha !", "J'espère que vous allez rabattre le caquet de ces prétentieux, capitaine " + pchar.name + ".");
            PlayVoice("Kopcapkz\Voices\Arena\ArenaHead_"+rand(7)+".wav");
			link.l1 = LinkRandPhrase("Dites à ces participants qu'ils n'ont aucune chance contre moi !", "Commençons : j'ai hâte de rosser quelqu'un !", "Le prix sera pour moi, n'en doutez même pas.");
			AddDialogExitQuestFunction("ArenaTournamentTalkWithRandEnemy");
			bDisableCharacterMenu = true;
			string sQuest = "AT_LooserDetector_1_4";
			PChar.quest.(sQuest).win_condition.l1 = "locator";
			PChar.quest.(sQuest).win_condition.l1.location = "FencingTown_Arena";
			PChar.quest.(sQuest).win_condition.l1.locator_group = "item";
			PChar.quest.(sQuest).win_condition.l1.locator = "looser_detector";
			PChar.quest.(sQuest).function = "ArenaTournamentLooserDetector";
		break;


		case "FightInArena_7":
			bDisableCharacterMenu = false;
			switch(sti(PChar.Arena.Tournament.Win))
			{
				case 0:
					dialog.text = LinkRandPhrase("Oui, le tournoi a été un succès ! Vous avez livré de beaux combats, capitaine ! Mais la chance n'était pas de votre cכté. Nous vous attendrons de nouveau : peut-être que la prochaine fois, la victoire sera pour vous.", "Je comptais sur vous, cap'tain, mais vous avez failli finir étalé par terre ! Pouah.", "Eh, pas de chance. Vous n'avez sans doute pas assez dormi.");
					link.l1 = LinkRandPhrase("J'ai juste un peu, hum, mal à la tête... Au revoir.", "L'adversaire a utilisé des techniques interdites : je vais porter plainte.", "Bon, peu importe, je reviendrai.");
					link.l1.go = "exit";
					AddDialogExitQuestFunction("ArenaTournamentTheEnd");
				break;

				case 1:
					AddMoneyToCharacter(PChar, sti(PChar.Arena.Tournament.Money));

					IncAndUnlock("AchTurnir", 1);

					/*if (rand(3) == 0 && !CheckAttribute(pchar,"ScamFanActive"))
					{
						pchar.quest.SpawnScamFan.win_condition.l1 = "Location";
						pchar.quest.SpawnScamFan.win_condition.l1.location = "FencingTown_ExitTown";
						pchar.quest.SpawnScamFan.win_condition = "SpawnScamFan";
						pchar.ScamFanActive = true;
					}*/

					bool nopirate = false;
					if (!CheckAttribute(pchar,"questTemp.UniquePirate.Drake") || !CheckAttribute(pchar,"questTemp.UniquePirate.Barbarigo") || !CheckAttribute(pchar,"questTemp.UniquePirate.BlackBeard") || !CheckAttribute(pchar,"questTemp.UniquePirate.Levasser")) nopirate = true;
					if (sti(pchar.questTemp.tournamentcount) == 3 && nopirate)
					{
						aref item;
						Items_FindItem("map_full", &item);
						string type = GetUniquePirateName();
						FillMapForUniqueTreasure(item, type);
						type = GetUniquePirateNameString(type);
						GiveItem2Character(pchar, "map_full");
						dialog.text = LinkRandPhrase("Oui, le tournoi a été un succès. Et c'est vous qui l'avez remporté ! Pour être franc, je ne pouvais pas détacher les yeux de votre façon de manier les armes ! Maintenant, ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or vous reviennent de droit.", "Capitaine, le titre de champion est à vous ! Même les rivaux les plus féroces ne s'attendaient pas à une telle maîtrise des armes ! Prenez votre prix : ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or.", "Oui, vous les avez presque tous mis en pièces ! Quelle poigne ! Ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or sont à vous de droit.");
						dialog.text = dialog.text + "  Puisque vous avez déjà remporté trois fois le tournoi, nous avons décidé de vous préparer quelque chose de spécial... D'après les rumeurs, cette carte au trésor serait celle du célèbre "+type+". Je pense que vous saurez trouver ce que ce scélérat a caché.";
						link.l1 = "C'est un cadeau vraiment royal de votre part ! Je vous en suis très reconnaissant"+GetSexPhrase(" !","e !");
						link.l1.go = "exit";
					}
					else
					{
						dialog.text = LinkRandPhrase("Oui, le tournoi a été un succès. Et c'est vous qui l'avez remporté ! Pour être franc, je ne pouvais pas détacher les yeux de votre façon de manier les armes ! Maintenant, ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or vous reviennent de droit.", "Capitaine, le titre de champion est à vous ! Même les rivaux les plus féroces ne s'attendaient pas à une telle maîtrise des armes ! Prenez votre prix : ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or.", "Oui, vous les avez presque tous mis en pièces ! Quelle poigne ! Ces " + sti(PChar.Arena.Tournament.Money) + " pièces d'or sont à vous de droit.");
						int randreward = drand2(100);
						string reward;
						if (randreward < 6)
						{
							int quality = 1;
							if (pchar.rank <= 6) quality = 1;
							if (pchar.rank >= 12) quality = 2;
							if (pchar.rank >= 18) quality = 3;
							if (pchar.rank > 24) quality = 4;
							reward = "book"+quality+"_"+sti(drand(13)+1);
						}
						if (randreward >5 && randreward < 17)
						{
							switch (drand(12))
							{
								case 0: reward = "blade19"; break;
								case 1: reward = "blade22"; break;
								case 2: reward = "blade36"; break;
								case 3: reward = "blade05"; break;
								case 4: reward = "blade31"; break;
								case 5: reward = "blade34"; break;
								case 6: reward = "blade40"; break;
								case 7: reward = "blade46"; break;
								case 8: reward = "blade15"; break;
								case 9: reward = "blade21"; break;
								case 10: reward = "blade01"; break;
								case 11: reward = "blade010"; break;
								case 12: reward = "topor2"; break;
							}
						}
						if (randreward >16 && randreward < 28)
						{
							switch (drand(8))
							{
								case 0: reward = "pistol6"; break;
								case 1: reward = "pistol_grapebok"; break;
								case 2: reward = "pistol11"; break;
								case 3: reward = "mushket"; break;
								case 4: reward = "mushket_Arguebuze"; break;
								case 5: reward = "mushket_Temppo"; break;
								case 6: reward = "mushket_mushketon1"; break;
								case 7: reward = "mushket_SHZ"; break;
								case 8: reward = "flint_mushketon"; break;
							}
						}
						if (randreward >17 && randreward < 39)
						{
							switch (drand(2))
							{
								case 0: reward = "cirass2"; break;
								case 1: reward = "cirass3"; break;
								case 2: reward = "cirass4"; break;
							}
						}
						if (randreward >38 && randreward < 50)
						{
							switch (drand(7))
							{
								case 0: reward = "indian1"; break;
								case 1: reward = "indian10"; break;
								case 2: reward = "indian15"; break;
								case 3: reward = "indian18"; break;
								case 4: reward = "indian19"; break;
								case 5: reward = "indian20"; break;
								case 6: reward = "indian21"; break;
								case 7: reward = "indian22"; break;
							}
						}
						if (randreward > 49)
						{
							GiveItem2Character(pchar,"Chest");
							reward = "icollection";
						}
						GiveItem2Character(pchar,reward);

						int idLngFile = LanguageOpenFile("ItemsDescribe.txt");
						aref item1;
						Items_FindItem(reward, &item1);
						string sTemp = LanguageConvertString(idLngFile, item1.name); 
						if (HasSubStr(reward, "book")) sTemp = sTemp + " (livre)";
						dialog.text = dialog.text + " En plus du prix en argent, nous avons aussi décidé de vous offrir un cadeau spécial pour votre victoire. Le voici : " + sTemp + ".";
						LanguageCloseFile(idLngFile);
						link.l1 = LinkRandPhrase("Vous doutiez vraiment de moi !", "Je vous montrerai plus d'une fois qui fait la loi ici. Et maintenant, repos.", "Ha ha ha, pitoyables insectes ! Des rivaux pareils, je les casse comme des noix à l'abordage. D'ailleurs, les noix, c'est bon pour la santé.");
						link.l1.go = "exit";
					}
					AddDialogExitQuestFunction("ArenaTournamentTheEnd");
				break;
			}
		break;

		case "FightInArena_8":
			dialog.text = LinkRandPhrase("Ah, vous voilà, capitaine " + GetFullName(pchar) + ". Ravi de vous voir ici. J'espère que la chance vous sourit aujourd'hui.", "Ah, vous voilà, capitaine " + pchar.name + ". Votre pari doit absolument être gagnant !", "Ah, vous voilà, capitaine " + pchar.name + ". Je pense que la chance sera de votre cכté aujourd'hui, pas comme la dernière fois...") + " Prenez place : allez là-ba-a-as...(il montre la gauche)... et montez dans la tour.";
			link.l1 = LinkRandPhrase("Ce n'est pas de la chance, c'est du calcul à froid. Vous verrez, je vais gagner.", "La chance ne m'a encore jamais fait faux bond.", "Préparez mon argent.");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartArenaOddsContinue");
		break;

		case "FightInArena_9":
			switch(sti(PChar.Arena.Odds.Win))
			{
				case 0:
					dialog.text = LinkRandPhrase("Ouais, les combats étaient superbes ! Mais malheureusement, votre pari n'a pas payé... Nous vous attendrons de nouveau : peut-être que la prochaine fois, vous aurez plus de réussite dans vos paris.", "Vous n'avez pas eu de chance aujourd'hui, capitaine. Mais le jeu continue ! Euh...", "Ce combattant a failli vous rapporter beaucoup d'argent. Mais ça n'a pas marché.");
					link.l1 = LinkRandPhrase("Je ne joue pas comme ça !! Donnez-moi l'argent !", "Oh, pas de chance. Mais vous avez vu comment il l'a frappé avant de tomber...", "Bon, peu importe, je récupérerai mon dמ, soyez-en sמr !");
					link.l1.go = "exit";
					AddDialogExitQuestFunction("ArenaOddsTheEnd");
				break;

				case 1:
					dialog.text = LinkRandPhrase("Ouais, les combats étaient superbes ! En plus, votre pari a payé, et maintenant, ces " + sti(PChar.Arena.Odds.Prize) + " piastres vous reviennent de droit. Honnêtement, j'avais une autre idée de l'issue des combats, mais il semble que je connaisse encore trop mal le rapport des forces...", "דa alors ! Personne n'avait prévu une telle tournure, mais vous avez su désigner le bon vainqueur ! Bravo, bravo ! Voici vos " + sti(PChar.Arena.Odds.Prize) + " pièces d'or en guise de prix.", "Eh bien, vous êtes un capitaine et un expert ! Démêler ainsi le rapport de forces des duellistes ! Oh, mon Dieu ! Personne n'avait prévu une telle tournure, mais vous avez su désigner le bon vainqueur ! Bravo, bravo ! Voici vos " + sti(PChar.Arena.Odds.Prize) + " pièces d'or !");
					link.l1 = LinkRandPhrase("Héhé, apprenez tant que je suis là"+ GetSexPhrase("","") +".", "Eh bien, le talent, ça ne se perd pas. Je vous conseille d'écouter les autres de temps en temps.", "Merci. Je reviendrai ici sans faute.");
					link.l1.go = "exit";
					AddMoneyToCharacter(PChar, sti(PChar.Arena.Odds.Prize));
					AddDialogExitQuestFunction("ArenaOddsTheEnd");
				break;
			}
		break;

		case "FightInArena_10":

			dialog.text = LinkRandPhrase("Vous voilà, " + GetFullName(pchar) + " ! Bienvenue à nos combats. J'espère que notre spectacle vous plaira.", "Salutations, cap'tain. Aujourd'hui, nous prévoyons des combats très sérieux.", "Je suis sמr que notre spectacle vous plaira.") + " Prenez place : allez là-ba-a-as...(il montre la gauche)... et montez dans la tour.";
			link.l1 = LinkRandPhrase("Moi aussi, je suis ravi"+ GetSexPhrase("","e") +" d'être ici. Je prendrai place avec plaisir.", "J'espère qu'on organise ici de vrais combats, et pas des chamailleries de bac à sable.", "Allez, commencez donc votre spectacle.");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("StartArenaOddsContinue");
		break;

		case "FightInArena_11":
			dialog.text = LinkRandPhrase("Oui, les combats ont clairement été un succès ! Je n'ai pas eu le temps d'admirer assez l'habileté de ces gens à manier les armes. Nous serons ravis de vous revoir. En attendant, à nos prochains combats !", "Oui, les gars ne se sont clairement pas trompés : quelle passion, quelle maîtrise !", "Vous devriez participer vous-même à nos événements.");
			link.l1 = LinkRandPhrase("Les combats m'ont plu autant qu'à vous. Merci, et au revoir.", "Oui, les combats étaient réussis. Je reviendrai ici avec plaisir.", "Arrgh ! La prochaine fois, c'est moi qui participerai à ces événements"+ GetSexPhrase("","") +" : alors, ils verront ce qu'est un vrai duel.");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ArenaOddsTheEnd");
		break;

		case "EnemyFightInArena_1":
			dialog.text = LinkRandPhrase("Alors, tu vas me donner ton argent bien gentiment"+ GetSexPhrase("","") +" ? J'ai hâte de te voir perdre.", "Oui, je vais te mettre en pièces, insecte !", "Prépare-toi à repartir les mains vides, minable !");
			link.l1 = LinkRandPhrase("Héhé. Ne te décourage pas, l'ami. Passons aux choses sérieuses.", "Ferme-la, noix de coco pourrie. Je vais te réduire en charpie.", "Haha, voyons maintenant lequel de nous deux repartira les mains vides.");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ArenaDuelStartBattleWithEnemy");
		break;

		case "FightInArena_6":
			dialog.text = RandSwear() + LinkRandPhrase("Contre moi, tu ne connaîtras que l'échec !",+ GetFullName(pchar) + " ?! Je te mets en pièces si tu te mets en travers de mon chemin !", "Hé, toi ! Tu vas regretter d'avoir mis les pieds ici !");
			link.l1 = LinkRandPhrase("Maintenant, c'est toi qui vas repartir les mains vides !", "Haha, ce pitoyable bâtard ose discuter avec moi ?", "Là, tu commences à me plaire...");
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ArenaTournamentGo");
		break;
		// На арене <--

		//--------------------------------- мужик ---------------------------------
		case "HouseMan":
			NextDiag.TempNode = "HouseMan";
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = PCharRepPhrase(LinkRandPhrase("L'alarme a été donnée en ville. On dirait qu'il est temps que je prenne les armes...", "Ce ne serait pas toute la garde de la ville qui te court après ? א moi, soldats !!!", "Tu ne trouveras pas refuge chez moi. Mais tu trouveras quelques pouces d'acier froid sous les cכtes !"),
					LinkRandPhrase("Qu'est-ce que tu veux, canaille ?! La garde de la ville est déjà sur ta piste, tu n'iras pas loin, sale pirate !", "Sale assassin ! Gardes !!!", "Je n'ai pas peur de toi, ordure ! On va bientכt te pendre dans notre fort, tu n'iras pas loin..."));
				link.l1 = PCharRepPhrase(RandPhraseSimple("On dirait que tu en as assez de vivre...", "Héhé, il n'y a donc pas de citoyens paisibles à " + XI_ConvertString("Colony" + npchar.city + "Gen") + " !"),
					RandPhraseSimple("Va au diable !", "Héhé, il te reste quelques secondes à vivre..."));
				link.l1.go = PCharRepPhrase("exit_setOwner", "fight");
				break;
			}
			if (isBadReputation(pchar, 40))
			{
				if (CheckAttribute(pchar, "questTemp.HouseEncTimer"))
				{
					dialog.text = "Je t'avais prévenu. Maintenant, à toi de voir si tu veux t'y frotter ou non...";
					link.l1 = "Hé !";
					link.l1.go = "exit";
				}
				else
				{
					dialog.text = "Qu'est-ce que tu veux dans ma maison, canaille ?! Je te donne dix secondes pour sortir d'ici !";
					link.l1 = LinkRandPhrase("Héhé, on me connaît ici aussi !", "Ma réputation me précède...", "Hum, je vois.");
					link.l1.go = "exit_GoOut";
				}
			}
			else
			{
				if (IsDay())
				{
					dialog.text = NPCStringReactionRepeat("C'est un plaisir de vous accueillir chez moi. Vous venez me voir pour affaires ?",
						"Que puis-je faire pour vous ?",
						"Hum, que puis-je faire pour vous ?",
						"Excusez-moi, si vous n'avez pas besoin de moi, je vous prie de ne pas me déranger...", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("Non, je visite juste la ville, je fais connaissance avec les habitants...",
						"Oh, rien de spécial...",
						"Rien...",
						"D'accord, comme vous voudrez.", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("HouseMan_1", "exit_setOwner", "exit_setOwner", "exit_setOwner", npchar, Dialog.CurrentNode);
				}
				else
				{
					dialog.text = NPCStringReactionRepeat("Pardon, mais vous vous présentez chez moi au mauvais moment : il fait nuit. Je vous prie de quitter ma maison !",
						"Je vous ai déjà dit qu'il est tard. Partez, s'il vous plaît.",
						"Je ne veux pas manquer de politesse, mais j'insiste pour que vous quittiez ma maison immédiatement !",
						"Qu'est-ce que c'est que ça ?! Gardes, au voleur !!!", "block", 1, npchar, Dialog.CurrentNode);
					link.l1 = HeroStringReactionRepeat("Bon, je comprends...",
						"Oui, tout de suite...",
						"Bon, ne vous énervez pas.",
						"Taisez-vous, quels voleurs ?!", npchar, Dialog.CurrentNode);
					link.l1.go = DialogGoNodeRepeat("exit_close", "exit_setOwner", "exit_setOwner", "fight", npchar, Dialog.CurrentNode);
				}
			}
		break;

		case "HouseMan_1":
			dialog.text = "Oh, permettez-moi de me présenter : " + GetFullName(npchar) + ". Nous sommes heureux de vous voir : les lois de l'hospitalité ne sont pas de vains mots dans notre ville.";
			link.l1 = GetFullName(pchar) + ", avec votre permission...";
			link.l1.go = "exit_setOwner";
		break;

		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Tu es un voleur, mon cher ! Gardes, arrêtez-le !!!", "דa alors ! J'ai à peine tourné les yeux que te voilà la tête la première dans le coffre ! Arrêtez le voleur !!!", "Gardes ! On vole !!! Arrêtez le voleur !!!");
			link.l1 = "Ah, diable !!!";
			link.l1.go = "fight";
			link.l2 = "Encore un bruit, et c'en est fait de toi !..";
			link.l2.go = "FackYou_1";
			link.l3 = "Je... Je... Je vais tout rendre !..";
			link.l3.go = "FackYou_2";
		break;

		case "FackYou_1":
			dialog.text = "Quoi ? Tu ne manques pas d'audace, à ce que je vois... Fiche le camp, maudite ordure !";
			link.l1 = "Bon sang !..";
			if(NPChar.sex == "man")
			{
				link.l1.go = "fight";
			}
			else
			{
				link.l1.go = "exit_setOwner3";
			}
		break;

		case "FackYou_2":
			dialog.text = "Bien sמr que tu vas tout rendre... Hum, paie " + sti(PChar.StealItemsMoney) +  " pièces d'or tout de suite, et tu pourras sortir à quatre pattes. Je te garantis que tout se passera bien.";
			if(sti(PChar.money)>= sti(PChar.StealItemsMoney))
			{
				link.l1 = "D'accord... Voici votre argent.";
				link.l1.go = "exit_setOwner2";
			}
			else
			{
				link.l2 = "Mais je n'ai pas assez d'argent... Pardon...";
				link.l2.go = "FackYou_3";
			}
			link.l3 = "Et puis quoi encore ! Je prendrai ici tout ce que je veux !";

			if(NPChar.sex == "man")
			{
				link.l3.go = "fight";
			}
			else
			{
				link.l3.go = "exit_setOwner3";
			}
		break;

		case "FackYou_3":
			dialog.text = "Qu'est-ce que tu as dit, espèce de rapace ?";
			link.l1 = "Bon sang !..";

			if(NPChar.sex == "man")
			{
				link.l1.go = "fight";
			}
			else
			{
				link.l1.go = "exit_setOwner3";
			}
		break;

		case "exit_setOwner":
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_setOwner2":
			AddMoneyToCharacter(PChar, -sti(PChar.StealItemsMoney));
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "exit_setOwner3":
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			LAi_SetOwnerTypeNoGroup(npchar);
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			LAi_SetOwnerTypeNoGroup(npchar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "legend":
			dialog.text = "Oh, vous parlez sans doute de Scam Games ? Vous avez vraiment eu la malchance qu'il s'accroche à vous ?";
			link.l1 = "Mais qui est-ce, au juste ?";
			link.l1.go = "legend_1";
		break;

		case "legend_1":
			dialog.text = "La rumeur dit que c'était autrefois un fieffé imbécile, un vrai fan des championnats d'escrime. Un jour, il lui est arrivé quelque chose, et depuis, il ne mange plus, ne boit plus, et rien ne lui fait plus le moindre mal. Croyez-moi, ça fait très longtemps qu'on essaie de se débarrasser de lui.";
			link.l1 = "Il a l'air complètement inoffensif... Mais s'il se comporte toujours comme ça, je vous comprends parfaitement.";
			link.l1.go = "legend_2";
		break;

		case "legend_2":
			dialog.text = "Vous aurez peut-être la chance de trouver un moyen de vous en débarrasser sans quitter l'archipel. Toutes ses précédentes « victimes » sont parties pour l'Europe, et on n'en a plus jamais entendu parler.";
			link.l1 = "Vous avez une idée là-dessus ?";
			link.l1.go = "legend_3";
		break;

		case "legend_3":
			dialog.text = "Je ne sais même pas quoi vous dire. א moins que les dieux puissent vous aider. Nous avons déjà essayé tous les moyens possibles et imaginables pour nous en débarrasser.";
			link.l1 = "Les dieux, alors... Oui, ça semble complètement désespéré, mais merci quand même.";
			link.l1.go = "exit";
			pchar.quest.RidScamFan.win_condition.l1 = "Location";
			pchar.quest.RidScamFan.win_condition.l1.location = "Temple_skulls";
			pchar.quest.RidScamFan.win_condition = "RidScamFan";
			pchar.KnowScam = true;
		break;

		case "Kraken":
			dialog.text = "Le Kraken a été invoqué.";
			link.l1 = "Je vais à ta rencontre.";
			link.l1.go = "exit";
			pchar.quest.SpawnScamFan.win_condition.l1 = "Location";
			pchar.quest.SpawnScamFan.win_condition.l1.location = "FencingTown_ExitTown";
			pchar.quest.SpawnScamFan.win_condition = "SpawnScamFan";
			pchar.ScamFanActive = true;
			AddDialogExitQuestFunction("ArenaTournamentTheEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
