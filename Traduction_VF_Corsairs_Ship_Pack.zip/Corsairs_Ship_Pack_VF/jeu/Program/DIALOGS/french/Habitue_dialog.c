#include "DIALOGS\french\Common_Duel.c" //navy
#include "DIALOGS\french\Rumours\Common_rumours.c"  //homo 25/06/06

void ProcessDialogEvent()
{
    ref NPChar, d;
	aref Link, Diag;
	string NPC_Meeting, TempInfoCharacterID_1, TempInfoCharacterID_2, sQuestTitle;
	int DonationSize;

	// Warship 18.05.08
	int iLa_Puesta; // La puesta - это ставка по-испански

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);

    ProcessCommonDialogRumors(NPChar, Link, Diag);//homo 25/06/06
    ProcessDuelDialog(NPChar, Link, Diag); //navy

	int iEnemyDice, iPCDice;
	// boal 13.03.2004 -->
	int d1,d2,d3,d4;
	bool ok;
	// boal 13.03.2004 <--
    ref sld;

	if (npchar.quest.Meeting != LastSpeakDate())
	{
		npchar.quest.last_theme = makeint(rand(1));
		npchar.quest.last_theme_game = makeint(rand(1));
		npchar.quest.Meeting = LastSpeakDate();
		npchar.money = 100 + rand(10) * makeint(50 * sti(PChar.rank) * (10.0 / MOD_SKILL_ENEMY_RATE*3));
        if (bBettaTestMode)
        {
            Dialog.CurrentNode = "Beta_test";
        }
		if (CheckAttribute(PChar, "BSLookingForAgentDialugue") && pchar.location == "SentJons_tavern" && npchar.id != "BSAgent")
		{
			Dialog.CurrentNode = "BSAgentDialugueFirst";
		}
	}

	switch (Dialog.CurrentNode)
	{
		// -----------------------------------Диалог первый - первая встреча

		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
		break;

        case "Beta_test":
            dialog.text = "C'est le menu de choix du type d'ivrogne (bêta-test)";
			link.l1 = "Va pour un ivrogne";
			link.l1.go = "Beta_test_alc";
            link.l2 = "Joueur de cartes";
			link.l2.go = "Beta_test_card";
			link.l3 = "Joueur de dés";
			link.l3.go = "Beta_test_dice";
		break;

		case "Beta_test_alc":
            dialog.text = "Ivrogne sélectionné";
			link.l1 = "Continuer";
			link.l1.go = "First time";
			npchar.quest.last_theme = 0;
		    npchar.quest.last_theme_game = 0;
		break;

		case "Beta_test_card":
            dialog.text = "Joueur de cartes (30 % de chances qu'il vous envoie promener la première fois)";
			link.l1 = "Continuer";
			link.l1.go = "First time";
			npchar.quest.last_theme = 1;
		    npchar.quest.last_theme_game = 0;
		break;

		case "Beta_test_dice":
            dialog.text = "Joueur de dés (30 % de chances qu'il vous envoie promener la première fois)";
			link.l1 = "Continuer";
			link.l1.go = "First time";
			npchar.quest.last_theme = 1;
		    npchar.quest.last_theme_game = 1;
		break;
		
		case "BSAgentDialugueFirst":
			dialog.text = RandPhraseSimple(RandPhraseSimple("Ne me cache pas la lumière, je ne vois plus les mouches dans ma chope !", "Que voulez-vous ?"), RandPhraseSimple("Pas question de dessoמler, tu ne m'en empêcheras pas !", "T'as quelque chose à boire ?"));
			link.l1 = "La pêche a été bonne.";
			link.l1.go = "BSAgentDialugueSecond";
		break;
		
		case "BSAgentDialugueSecond":	
			dialog.text = RandPhraseSimple(RandPhraseSimple("Va cuver ton vin !", "Faut bien manger un morceau !"), RandPhraseSimple("Quoi ? De quoi tu parles ?", "Je ne vois pas de quoi tu parles !"));
			link.l1 = "...";
			link.l1.go = "exit";
		break;

		case "First time":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = LinkRandPhrase("Je suis peut-être soמl, mais pas idiot. Si je bois avec toi, les soldats vont m'attraper moi aussi ! Non merci...", "Je ne suis pas un ennemi de la ville oם je vis. Je ne boirai pas avec toi !" , ""+ GetSexPhrase("L'ami", "Ma belle") +", tu ferais mieux de dégager d'ici gentiment...");
				link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Hé, t'as un peu trop forcé sur la bouteille ! Mauvais moment.");
				link.l1.go = "exit";
				break;
			}
            ok = CheckFreeSitFront(npchar); //checkAttribute(npchar, "Default.ToLocator"); // есть куда сесть
			if(CheckAttribute(pchar, "questTemp.HabitueSpeakDisable") && rand(1) == 0) // если дуэлянт то каждый второй посылает нафик
			{
				dialog.text = "Ha, "+ GetSexPhrase("monsieur", "mademoiselle") +", j'ai entendu parler de toi, bien sמr, bien sמr, héhé. Dans les tavernes, on dit que tu es un bagarreur et un duelliste, et que tu as déjà envoyé une dizaine d'âmes devant le Seigneur pour des histoires d'ivrognes. וcoute, nos gens ne sont pas des timides, bien sמr, mais personne n'a envie de se faire étriper pour une chope de rhum. Moi, j'ai même peur de m'asseoir à la même table que toi, alors je crois que je vais y aller.";
				link.l1 = LinkRandPhrase("Bon débarras !", "Roule, tant que je suis de bonne humeur...", "Allez, allez ! Déguerpis, nourriture à poissons !");
				link.l1.go = "exit";
				link.l2 = "Attends, je voulais te demander quelque chose....";
				link.l2.go = "talk_habitue_duel";
				break;
			}

            dialog.text = "Ne me cache pas la lumière, il n'y a pas de mouches dans la chope !";
            link.l1 = "Je m'en vais...";
		    link.l1.go = "exit";
		    if (!chrDisableReloadToLocation)
		    {
	            switch (npchar.quest.last_theme)
				{
					case "0": //пьяный.
						dialog.text = "Hic ! Oh, "+ GetSexPhrase("mon gars, t'as l'air d'un vieux loup de mer", "ma fille, t'as l'air d'un vrai loup de mer") +" ! Tu me paies pas un verre de rhum ?";
						link.l1 = "Je suis peut-être " + GetSexPhrase("loup de mer", "louve de mer") +", mais ça ne veut pas dire que je vais boire avec n'importe quel déchet...";
						link.l1.go = "exit";

						if (makeint(pchar.money) >= 100 && ok) // только старые острова окучены на сесть
						{
							link.l2 = "Avec plaisir, je te tiendrai compagnie.";
							link.l2.go = "talk_with_alchogol";
						}
						else
						{
	                        link.l2 = "Pourquoi donc ?";
							link.l2.go = "talk_with_alchogol_song";
						}
					break;

					case "1":
	                    if (rand(3) != 1 && ok)
	                    {
							switch (sti(npchar.quest.last_theme_game))
							{
							    case 0 :
									// Игра в карты boal 20/05/05 -->
	                                if (CheckNPCQuestDate(npchar, "Card_date_begin"))
									{
										Dialog.text = RandPhraseSimple("On joue aux cartes ?", "Jouons cartes sur table. Tu en es ?");
										link.l1 = "Pourquoi pas ?";
										link.l1.go = "Cards_begin";
										link.l2 = "Quelles sont les règles du jeu ?";
										link.l2.go = "Cards_Rule";
										link.l3 = "Pas maintenant.";
										link.l3.go = "exit";

										// Dolphin -> генератор возврата выигрыша
										// 1 раз в 15 дней + 30% вероятность + нет активного такого же квеста
										//flag = sti(npchar.nation)!=PIRATE && pchar.location != "Pirates_tavern" && pchar.location != "FortOrange_tavern" && pchar.location != "Dominica_tavern" && pchar.location != "Guibraltar_tavern" && pchar.location != "Fishing_Settlement_tavern" && pchar.location != "Panama_tavern";
										//Log_Info(" days: "+GetQuestPastDayParam("CasinoGenerator_timer")+" надо > 15 Шанс: "+sti(npchar.GenQuest)+" надо < 30");
										//if (flag && GetQuestPastDayParam("CasinoGenerator_timer") > 15 && sti(npchar.GenQuest) < 15 && !CheckAttribute(pchar, "HOTP_CasinoQuest") && !CheckAttribute(npchar, "CasinoQuest.decline"))
										if (drand(100) < 9 && !CheckAttribute(pchar, "HOTP_CasinoQuest") && !CheckAttribute(npchar, "CasinoQuest.decline") && !CheckAttribute(pchar, "questTemp.KIP_Looser") && (pchar.location != "Pirates_tavern") && (pchar.location != "LaVega_tavern") && (pchar.location != "PuertoPrincipe_tavern") && (pchar.location != "LeFransua_tavern") && (pchar.location != "FortOrange_tavern") && (pchar.location != "Panama_tavern") && (pchar.location != "Fishing_Settlement_tavern") && (pchar.location != "Guibraltar_tavern") && (pchar.location != "Dominica_tavern") && (pchar.location != "Caiman_tavern") && (pchar.location != "DesMoines_tavern"))
										{
											DeleteAttribute(link, "l2");
											DeleteAttribute(link, "l3");
											link.l1 = "Et avec quoi tu vas jouer ? Je vois que tu n'as même pas de quoi payer une pinte de bière.";
											link.l1.go = "HOTP_CasinoQuest_1";
										}

									}
									else
					    			{
Dialog.text = "Non, je ne veux plus jouer aux cartes avec toi.";
						    			link.l1 = "Eh bien, tant pis.";
						    			link.l1.go = "exit";
									}
			                        // Игра в карты boal 20/05/05 <--
		                        break;

								case 1:
								// кости
		    						// Игра в кости boal 13/07/05 -->
	                                if (CheckNPCQuestDate(npchar, "Dice_date_begin"))
									{
Dialog.text = RandPhraseSimple("On jette les dés ?", "Je te propose une partie de dés. Tu en es ?");
										link.l1 = "Pourquoi pas ?";
										link.l1.go = "Dice_begin";
										link.l2 = "Quelles sont les règles du jeu ?";
										link.l2.go = "Dice_Rule";
										link.l3 = "Pas maintenant.";
										link.l3.go = "exit";

										// Dolphin -> генератор возврата выигрыша
										// 1 раз в 15 дней + 30% вероятность + нет активного такого же квеста
										//flag = sti(npchar.nation)!=PIRATE && pchar.location != "FortOrange_tavern" && pchar.location != "Dominica_tavern" && pchar.location != "Guibraltar_tavern" && pchar.location != "Fishing_Settlement_tavern" && pchar.location != "Panama_tavern";
										//Log_Info(" days: "+GetQuestPastDayParam("CasinoGenerator_timer")+" надо > 15 Шанс: "+sti(npchar.GenQuest)+" надо < 30");
										//if (flag && GetQuestPastDayParam("CasinoGenerator_timer") > 15 && sti(npchar.GenQuest) < 15 && !CheckAttribute(pchar, "HOTP_CasinoQuest") && !CheckAttribute(npchar, "CasinoQuest.decline"))
										if (drand(100) < 9 && !CheckAttribute(pchar, "HOTP_CasinoQuest") && !CheckAttribute(npchar, "CasinoQuest.decline") && !CheckAttribute(pchar, "questTemp.KIP_Looser") && (pchar.location != "Pirates_tavern") && (pchar.location != "LaVega_tavern") && (pchar.location != "PuertoPrincipe_tavern") && (pchar.location != "LeFransua_tavern") && (pchar.location != "Panama_tavern") && (pchar.location != "Fishing_Settlement_tavern") && (pchar.location != "Guibraltar_tavern") && (pchar.location != "Dominica_tavern") && (pchar.location != "Caiman_tavern") && (pchar.location != "DesMoines_tavern"))
										{
											DeleteAttribute(link, "l2");
											DeleteAttribute(link, "l3");
											link.l1 = "Et avec quoi tu vas jouer ? Je vois que tu n'as même pas de quoi payer une pinte de bière.";
											link.l1.go = "HOTP_CasinoQuest_1";
										}

									}
									else
					    			{
Dialog.text = "Non, je ne veux plus jouer aux dés avec toi.";
					    				link.l1 = "Eh bien, tant pis.";
					    				link.l1.go = "exit";
									}
			                        // Игра в кости boal 13/07/05 <--
			                        //navy --> Дуэли
									if (CheckAttribute(NPchar, "Quest.DiceCheats") && sti(NPchar.Quest.DiceCheats) >= 1) // && sti(NPChar.Quest.HeroLose))
									{
					    				link.l9 = RandSwear() + "Tu as triché !!!";
					    				link.l9.go = "outraged";
									}
									//navy <--
			    				break;
	    					} //switch
						}
	        			else
	        			{
	                        dialog.text = RandPhraseSimple("Fiche le camp de ma table !", "Et... quoi ? Qui c'est ? hic... Dégage !");
	                        link.l1 = RandPhraseSimple("L'ivrognerie perd ton âme pécheresse : reprends tes esprits !", "Ne sois pas grossier avec moi.");
	        			    link.l1.go = "exit";
	        			    link.l2 = RandPhraseSimple("Comment tu me parles, espèce de brute ! Je vais t'apprendre les bonnes manières.", "Je vais te taper sur la tête, tu vas dessoמler en un instant.");
	        	            link.l2.go = "tavern_keeper";
							if (SharleMaryIsHere() && PChar.sex != "woman" && rand(2) == 2)
							{
								link.l1 = "";
								link.l1.go = "Mary_Zastupaetsya_1";
								DeleteAttribute(link, "l2");
								pchar.Mary.hamila.npcharID = npchar.id;
							}
	        			}
					break;
				}
			}
			Diag.TempNode = "First time";
	    break;

		case "Mary_Zastupaetsya_1":
			StartInstantDialogNoType(pchar.SharleMaryId, "Mary_Zastupaetsya_2", "Habitue_dialog.c");
		break;

		case "Mary_Zastupaetsya_2":
			dialog.text = RandPhraseSimple("(à l'ivrogne) Je vais t'arracher la gorge !", "(à l'ivrogne) Tu vas avoir affaire à moi, sale trogne !");
	        link.l1 = "Du calme, du calme, Mary, il a compris.";
	        link.l1.go = "Mary_Zastupaetsya_3";
			LAi_SetActorTypeNoGroup(npchar);
			LAi_ActorTurnToCharacter(npchar, CharacterFromID(pchar.Mary.hamila.npcharID));
		break;

		case "Mary_Zastupaetsya_3":
			DialogExit();

			sld = characterFromID("SharleMary");
			sld.Dialog.Filename = "Quest\MainheroPrologues\Mary_dialog.c";
			sld.dialog.currentnode = "hired";
			LAi_SetOfficerType(sld);
		break;

		case "talk_habitue_duel":
			dialog.text = "Rien du tout, "+ GetSexPhrase("monsieur", "mademoiselle") +", je ne te dirai rien ! Et il est peu probable que quelqu'un d'autre accepte, parce que les conversations avec toi finissent mal... Mais la mémoire des gens est courte : tu verras, dans un mois ou deux, toutes tes aventures seront oubliées. א moins, bien sמr, que tu ne rafraîchisses la mémoire des gens, héhé... Adieu, "+ GetSexPhrase("monsieur", "mademoiselle") +". ";
			link.l1 = "Bon, d'accord....";
			link.l1.go = "exit";
		break;

	    // карты -->
	    case "Cards_Rule":
   			dialog.text = XI_ConvertString("CardsRules")
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Cards_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Cards_begin":
			Diag.tempnode = "Cards_Node";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			pchar.questTemp.friend_in_tavern = npchar.id;
			AddDialogExitQuest("alc");
		break;

		case "Cards_Node":
			Diag.tempNode = "first time";

			Dialog.text = "Alors, fixons la mise (entrez la mise).";
			link.l1 = "100";
			link.l1.edit = 1;
			link.l1.go = "Cards_Node_2";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit_sit";
		break;

		case "Cards_Node_2":
			iLa_Puesta = GetStrSmallRegister(dialogEditStrings[1]);
            if (!CheckCardsGameSmallRate())
		    {
                dialog.text = "Tu as la réputation d'un tricheur sans égal. Je ne jouerai pas du tout aux cartes avec toi.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit_sit";
			    break;
		    }

			if (sti(PCHar.Money) < sti(iLa_Puesta)*3)
		    {
                dialog.text = "Eh bien, "+ GetSexPhrase("l'ami", "ma chérie") +", tu es à sec. Reviens quand tu seras riche.";
                link.l1 = "D'accord.";
			    link.l1.go = "exit_sit";
			    break;
		    }

			if (sti(NPChar.Money) < sti(iLa_Puesta)*3)
		    {
                dialog.text = "J'ai déjà tout perdu, ce n'est pas mon jour.";
                link.l1 = "D'accord.";
			    link.l1.go = "exit_sit";
			    break;
		    }
		else
		{
			if(sti(iLa_Puesta) < 50)
			{
				dialog.text = "Hé, tu te moques de moi ?! Jouer pour " + iLa_Puesta + " pièces d'or ?! Changeons la mise, sinon je ne jouerai pas avec toi !";
				link.l1 = "Oui, peut-être. Il faut augmenter la mise.";
				link.l1.go = "Cards_begin_2";
				link.l2 = "J'ai changé d'avis, je ne joue plus.";
				link.l2.go = "exit_sit";
				break;
			}

			if(sti(iLa_Puesta) > 1000)
			{
				dialog.text = "Jouer pour une telle somme ? Non, épargne-moi... Changeons la mise !";
				link.l1 = "Oui, tu as raison. Il faut baisser la mise";
				link.l1.go = "Cards_begin_2";
				link.l2 = "J'ai changé d'avis, je ne joue plus.";
				link.l2.go = "exit_sit";
				break;
			}
			dialog.text = "Bon, jouons " + iLa_Puesta + " pièces par carte.";
			link.l1 = "Distribue !";
			link.l1.go = "Cards_begin_go";
			pchar.GenQuest.Cards.npcharIdx = npchar.index;
			pchar.GenQuest.Cards.iRate     = sti(iLa_Puesta);
            pchar.GenQuest.Cards.SitType   = true;
		}
		break;

		case "Cards_begin_2":
			dialog.text = "Alors, quelle sera la mise ? (Entrez la mise).";
			link.l1 = "50";
			link.l1.edit = 1;
			link.l1.go = "Cards_Node_2";
			link.l2 = "Je crois que je ne jouerai pas...";
			link.l2.go = "exit_sit";
		break;

		case "Cards_begin_go":
			// анлим игры в день SetNPCQuestDate(npchar, "Card_date_begin");
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			LaunchCardsGame();
		break;

		case "Cards_begin_go":
                Diag.CurrentNode = Diag.TempNode;
                DialogExit();
                LaunchCardsGame();
		break;
	    // карты <--
	    // КОСТИ -->
	    case "Dice_Rule":
   			dialog.text = XI_ConvertString("DiceRules");
			link.l1 = "Eh bien, commençons !";
			link.l1.go = "Dice_begin";
			link.l3 = "Non, ce n'est pas pour moi...";
			link.l3.go = "exit";
		break;

		case "Dice_begin":
			Diag.tempnode = "Dice_Node";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			pchar.questTemp.friend_in_tavern = npchar.id;
			AddDialogExitQuest("alc");
		break;

		case "Dice_Node":
		    Diag.tempNode = "first time";

Dialog.text = "Fixons la mise (entrez la mise).";
			link.l1 = "50";
			link.l1.edit = 1;
			link.l1.go = "Dice_Node_2";
		//	link.l2 = "Давай по 200 золотых за кубик";
		//	link.l2.go = "Dice_Node_500";
			link.l3 = "Je crois que je vais y aller.";
			link.l3.go = "exit_sit";
		break;

		case "Dice_Node_2":
			iLa_Puesta = GetStrSmallRegister(dialogEditStrings[1]);
            if (!CheckDiceGameSmallRate())
		    {
				dialog.text = "Tu as la réputation d'un tricheur sans égal. Je ne jouerai pas du tout aux dés avec toi.";
                link.l1 = "Ce ne sont que des mensonges ! Bon, comme vous voudrez.";
			    link.l1.go = "exit_sit";
			    break;
		    }

			if (sti(pchar.Money) < sti(iLa_Puesta)*6)
		    {
                dialog.text = GetSexPhrase("L'ami", "Ma belle") +", tu es à sec. Reviens quand tu seras riche.";
                link.l1 = "D'accord.";
			    link.l1.go = "exit_sit";
			    break;
		    }

			if (sti(npchar.Money) < sti(iLa_Puesta)*6)
		    {
                dialog.text = "J'ai déjà tout perdu, ce n'est pas mon jour.";
                link.l1 = "D'accord.";
			    link.l1.go = "exit_sit";
			    break;
		    }
		else
		{
			if(sti(iLa_Puesta) < 50)
			{
				dialog.text = "Hé, tu te moques de moi ?! Jouer " + iLa_Puesta + " pièces d'or par lancer ?! Changeons la mise, sinon je ne jouerai pas avec toi !";
				link.l1 = "Oui, peut-être. Il faut augmenter la mise.";
				link.l1.go = "Dice_begin_2";
				link.l2 = "J'ai changé d'avis, je ne joue plus.";
				link.l2.go = "exit_sit";
				break;
			}

			if(sti(iLa_Puesta) > 1000)
			{
				dialog.text = "Jouer aux dés pour une telle somme ? Non, changeons la mise !";
				link.l1 = "Oui, tu as raison. Il faut baisser la mise";
				link.l1.go = "Dice_begin_2";
				link.l2 = "J'ai changé d'avis, je ne joue plus.";
				link.l2.go = "exit_sit";
				break;
			}
			dialog.text = "Bon, nous jouons " + iLa_Puesta + " pièces par lancer.";
			link.l1 = "Allons-y !";
			link.l1.go = "Dice_begin_go";
			pchar.GenQuest.Dice.npcharIdx = npchar.index;
			pchar.GenQuest.Dice.iRate     = sti(iLa_Puesta);
            pchar.GenQuest.Dice.SitType   = true;
		}
		break;

		case "Dice_begin_2":
			dialog.text = "Alors, quelle sera la mise ? (Entrez la mise).";
			link.l1 = "50";
			link.l1.edit = 1;
			link.l1.go = "Dice_Node_2";
			link.l2 = "Je crois que je ne jouerai pas...";
			link.l2.go = "exit_sit";
			break;

		case "Dice_begin_go":
            // анлим игры в день SetNPCQuestDate(npchar, "Dice_date_begin");

                Diag.CurrentNode = Diag.TempNode;
                DialogExit();
                LaunchDiceGame();
		break;
		//////  1
	    case "GhostShip_Speak_1":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
            npchar.GhostShip_Speak_Yet = true;
            pchar.GenQuest.GhostShip.lastspeak_date = LastSpeakDate();
   			dialog.text = "Eh bien... Hic ! J'ai vu une chose terrible : un vaisseau fantכme, avec seulement des morts à bord... On dit qu'il navigue ici depuis Christophe Colomb...";
			link.l1 = "Tu mens, sans doute !";
			link.l1.go = "GhostShip_Speak_1_2";
		break;

		case "GhostShip_Speak_1_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Moi, je mens ? Hic ! דa fait deux semaines que je bois pour oublier ce que j'ai vu... comment il est entré dans la baie avec ses voiles noires en lambeaux...";
			link.l1 = "Et comment as-tu survécu ?";
			link.l1.go = "GhostShip_Speak_1_3";
		break;

		case "GhostShip_Speak_1_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Eh bien, dès que j'ai vu qu'ils accostaient, j'en ai sali mon pantalon. Hic !.. Et ne rigole pas !";
			link.l1 = "Oh... Tu es un sacré menteur, tu as complètement perdu la tête.";
			link.l1.go = "exit_sit";
			pchar.GenQuest.GhostShip.AskAbout = "1";
			AddQuestRecord("GhostShipQuest", pchar.GenQuest.GhostShip.AskAbout);
		break;
		//////  2
		case "GhostShip_Speak_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
            npchar.GhostShip_Speak_Yet = true;
            pchar.GenQuest.GhostShip.lastspeak_date = LastSpeakDate();
            dialog.text = "דa arrive ? Qu'est-ce qui se passe ici ? Mais on dit que le Hollandais volant a encore envoyé la caravane d'or par le fond.";
			link.l1 = "Quel Hollandais ?";
			link.l1.go = "GhostShip_Speak_2_2";
		break;

		case "GhostShip_Speak_2_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Le « volant » ! Le vaisseau fantכme a donc refait surface dans l'archipel. Il semblait avoir disparu depuis des années... J'ai dמ être en enfer. Et puis, tout est maudit à bord, et les balles ne leur font rien.";
			link.l1    = "Et quoi, on ne peut pas les tuer ?";
			link.l1.go = "GhostShip_Speak_2_3";
		break;

		case "GhostShip_Speak_2_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Parfois, ils prenaient des villes d'assaut, massacraient toute la garnison du fort, et il y avait des milliers de soldats dans le fort ! Remarquez, j'ai entendu dire qu'on les avait coulés une fois, mais qu'est-ce que ça peut leur faire, à des morts : ils traînent le navire par le fond jusqu'au rivage, le réparent tant bien que mal et recommencent leurs horreurs.";
			link.l1 = "Oh, ce que les gens peuvent inventer... « Le traîner par le fond », rien que ça. Enfin, merci, c'est une histoire intéressante.";
			link.l1.go = "exit_sit";
			pchar.GenQuest.GhostShip.AskAbout = "2";
			AddQuestRecord("GhostShipQuest", "2");
		break;
		//////  3
		case "GhostShip_Speak_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
            npchar.GhostShip_Speak_Yet = true;
            pchar.GenQuest.GhostShip.lastspeak_date = LastSpeakDate();

			if (!CheckAttribute(pchar, "GenQuest.GhostShip.LastBattle") &&
                             CheckAttribute(pchar, "GenQuest.GhostShip.NeedCoins")  &&
                            !CheckAttribute(npchar, "quest.GhostShipHelp")          &&
                            !CheckAttribute(pchar, "GenQuest.GhostShipWorkId")      &&
                            rand(2) == 1)
            {
                dialog.text = "Eh bien, on dit qu'ils comptaient encore piller un fort. Je ne sais pas lequel ; demandez aux gouverneurs, quelqu'un a peut-être besoin d'aide.";
                link.l1 = "דa alors ! Merci, je dois y aller.";
    			link.l1.go = "exit_sit";
                break;
            }

            dialog.text = "Le « Hollandais volant » ? Oui, ce navire existe, même si beaucoup n'y croient pas.";
			if(CheckAttribute(Pchar, "GhostShip.AlreadyTalked"))
			{
				link.l1 = "Ah, j'en ai déjà entendu parler, passons";
				link.l1.go = "exit";
			}
            if (sti(PChar.GenQuest.GhostShip.KillMe) > 0 || sti(PChar.GenQuest.GhostShip.DeadByMe) > 0)
            {
                link.l1 = "Oui, je l'ai vu ! J'ai failli y laisser ma peau. Oם puis-je le trouver ?";
            }
            else
            {
				link.l1 = "Bon, je te crois. Oם puis-je le trouver ?";
			}
			link.l1.go = "GhostShip_Speak_3_2";
		break;

		case "GhostShip_Speak_3_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "On dit qu'il se trouve maintenant près de la mystérieuse île de Khael Roa.";
			if(!CheckAttribute(PChar, "GhostShip.AlreadyTalked"))
			{
				link.l1    = "Et dis-moi, mon cher, oם chercher cette île ?";
				link.l1.go = "GhostShip_Speak_3_3";
			}
			else
			{
				link.l1 = "Eh bien, je lui rendrai visite.";
				GhostShipOnMap();
				link.l1.go = "exit_sit";
			}
		break;

		case "GhostShip_Speak_3_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "La rumeur dit qu'elle se trouve quelque part dans le triangle que forment les îles de Saint-Martin, de Niévès et d'Antigua.";
			link.l1 = "Eh bien, je vais essayer de le trouver, voir à quoi ressemble ce fantכme.";
			link.l1.go = "exit_sit";
			pchar.GenQuest.GhostShip.AskAbout = "2";// вечный генератор
			AddQuestRecord("GhostShipQuest", "3");
			Pchar.GhostShip.AlreadyTalked = true;
			GhostShipOnMap();
		break;
		/////////////////////////////////////////////
        case "talk_with_alchogol_song":
			dialog.text = "Eh bien... Hic ! Il y a des moments oם tout va bien, et même très bien... Hic ! Mais pourquoi, on ne peut pas l'expliquer... Hic ! C'est peut-être à cause du rhum... Hic ! Du rhum noir de la Jamaïque... Hic ! Tends ton verre, je te sers !";
			link.l1 = "Et ensuite ?";
			link.l1.go = "talk_with_alchogol_song_2";
			link.l2 = "Allons donc !";
			link.l2.go = "exit";
		break;

		case "talk_with_alchogol_song_2":
			dialog.text = "Les chopes qui scintillent, les visages, les talons aussi... Hic ! Et le plancher sur la tête... Je bois toujours avec tout le monde et partout... Hic ! Oם est la gnכle ? Il m'en faut !";
			link.l1 = "Et ensuite ?";
			link.l1.go = "talk_with_alchogol_song_3";
			link.l2 = "Allons donc !";
			link.l2.go = "exit";
		break;

		case "talk_with_alchogol_song_3":
			dialog.text = "Quand le cœur est lourd et la poitrine glacée, avale deux ou trois chopes de rhum ! Et sans soucis ni mensonges, tout s'arrangera soudain autour de toi. Tu comprendras que je suis ton meilleur ami !";
			link.l1 = "Allons donc !";
			link.l1.go = "exit";
		break;

		case "talk_with_alchogol":
			Diag.TempNode = "begin_sit";
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			pchar.questTemp.friend_in_tavern = npchar.id;
			AddDialogExitQuest("alc");
		break;

		case "begin_sit":
			Diag.TempNode = "first time";
			dialog.snd = "Voice\HADI\HADI028";
			dialog.text = LinkRandPhrase("Hic ! דa, je comprends ! C'est comme ça qu'on fait chez nous ! Alors, quoi ? Tu me paies une chope de rhum ?",
						"Asseyez-vous, " + GetAddress_Form(npchar) + ", prenons une tasse de bon rhum de la Jamaïque. דa ne fait jamais de mal à la santé. Et pour quelqu'un qui s'intéresse aux affaires, il n'y a pas de meilleur endroit qu'une taverne, je vous le dis... Un peu d'argent, deux ou trois chopes de bonne gnכle, et vous apprendrez tout ce que vous voulez... et même plus. Faites confiance à un vieil habitué...",
						"Hé hé, asseyez-vous, "+ GetSexPhrase("mon cher monsieur", "madame") +", buvons un coup... Pourquoi ne pas boire un coup en bonne compagnie ? Dans notre taverne du port, on peut parfois entendre des choses très intéressantes, si l'on a de la patience et qu'on boit à petites gorgées pour ne pas rouler sous la table... Tantכt un capitaine charge plus qu'il ne faut à bord et se met à se vanter de ses aventures, tantכt quelqu'un qui sait des choses les laisse échapper une fois éméché... Il y a toutes sortes de gens ici, et beaucoup ont quelque chose à raconter, croyez-moi, "+ GetSexPhrase("monseigneur", "madame") +".");
			link.l1 = "Facilement ! Aubergiste, apporte du rhum !";
			link.l1.go = "sit_2";
		break;

		// Церковный генератор. Квест №2 -->
		case "Alcogol_GenQuest_Church_2_1":
			dialog.text = "Et ce n'est pas tout ! J'ai entendu dire qu'on s'est déjà mis à piller les églises !";
				link.l1 = "Eh bien, seuls des pirates sont capables de ça...";
				link.l1.go = "Alcogol_GenQuest_Church_2_2";
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskPeople");
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskBarmen");
				DeleteAttribute(PChar, "GenQuest.ChurchQuest_2.AskAlcash");
			break;

		case "Alcogol_GenQuest_Church_2_2":
			dialog.text = "Des pirates, tu parles ! De simples crapules de terre ferme, et visiblement des gens d'ici : comment des pirates sauraient-ils quand le tronc de l'église est plein à ras bord ? Et ils ne s'y frotteraient pas.";
				link.l1 = "Des gaillards courageux, tout de même. Bravement, ils ont forcé le frêle verrou de l'église...";
				link.l1.go = "Alcogol_GenQuest_Church_2_3";
			break;

		case "Alcogol_GenQuest_Church_2_3":
			dialog.text = "Pas si frêle que ça. Et ils sont malins, pas besoin de force. Qui irait les soupçonner ?!";
				link.l1 = "Tu as raison. Toute la paroisse, en se serrant la ceinture, économisait une pièce de plus pour la porter au tronc de l'église, et maintenant, quelques malins se sont enrichis d'un seul coup ? Ils ne vont pas s'en tirer comme ça, on les rattrapera au bout du monde.";
				link.l1.go = "Alcogol_GenQuest_Church_2_4";
			break;

		case "Alcogol_GenQuest_Church_2_4":
			dialog.text = "Non. Qui les attrapera ? Ils ont volé les offrandes, et on ne se souvient même plus de leur nom : ils ont filé hors de la ville. Et la jungle est grande, cherche-les maintenant jusqu'au Jugement dernier. Et dans un mois ou deux, cette affaire sera complètement oubliée. Je vais te dire autre chose...";
				link.l1 = "Eh bien, tu sais, les gens ne pardonnent pas ce genre de chose.";
				link.l1.go = "Alcogol_GenQuest_Church_2_5";
			break;

		case "Alcogol_GenQuest_Church_2_5":
			dialog.text = "Les gens ont la mémoire comme un esquif percé. Les gens pardonneront. Mais Dieu ?! Il voit tout... Voilà de qui il faut avoir peur ! Il y a une dizaine d'années, une histoire terrible est arrivée à l'un de mes amis : pour avoir manqué de respect au Créateur, il a failli finir entre les dents du diable des mers...";
				link.l1 = "Désolé, l'ami, j'écouterai ton histoire une autre fois. Salut.";
				link.l1.go = "Alcogol_GenQuest_Church_2_6";
			break;

		case "Alcogol_GenQuest_Church_2_6":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("exit_sit");
			string sGenLocation = QuestGetGangLocation(PChar.GenQuest.ChurchQuest_2.QuestTown);
			PChar.GenQuest.ChurchQuest_2.QuestGangJungle = sGenLocation;
			SetFunctionLocationCondition("Church_GenQuest2_GenerateBandits", sGenLocation, false);
			locations[FindLocation(sGenLocation)].DisableEncounters = true;
			PChar.GenQuest.ChurchQuest_2.WayOfShortVariant = true; // Нужно для проверки при убийстве банды
			SetFunctionTimerConditionParam("Church_GenQuest2_TimeIsLeft", 0, 0, 1, MakeInt(24 - GetHour()), false);
			Log_TestInfo("The bandits who robbed the church will be in the location - " + sGenLocation + " Time to search for them - 1 day");
			sQuestTitle = PChar.GenQuest.ChurchQuest_2.QuestTown + "ChurchGenQuest2";
			AddQuestRecordEx(sQuestTitle, "ChurchGenQuest2", "2");
			break;
		// <-- Церковный генератор. Квест №2
		//--> работорговец
			case "Jamaica_ratH_1":
				dialog.text = "Ah, François ! Je me souviens, je me souviens de lui... Non, je ne sais pas. Mais je vais te dire une chose : interroge notre serveuse à son sujet. Tant qu'il a vécu ici, elle courait le voir toutes les nuits. Une coureuse, en un mot. Il lui a peut-être dit quelque chose.";
				link.l1 = "Merci, l'ami, pour ce bon conseil. Je vais aller lui parler.";
				link.l1.go = "exit_sit";
				pchar.questTemp.Slavetrader = "FindRatJamaica_W";
			break;

			case "EscapeSlave_Villemstad_H1":
				dialog.text = "Ouais, ce qu'on ne voit pas en mer... Voilà ce qui est arrivé lors du dernier voyage...";
				link.l1 = "Eh bien, raconte, mais n'exagère pas trop. Je vais te resservir du rhum en attendant.";
				link.l1.go = "EscapeSlave_Villemstad_H2";
			break;

			case "EscapeSlave_Villemstad_H2":
				dialog.text = "Je vous le jure sur la croix, noble "+ GetSexPhrase("monseigneur", "madame") +" : je l'ai vu de mes propres yeux... Un navire arrive, et au lieu d'un équipage, il y a à bord des bestioles... euh... des singes gorilles... Bref, des macaques, que le diable les emporte...";
				link.l1 = "Quoi ?! Et dis-moi, mon cher, tu ne descendrais pas une bouteille pendant ton quart ?";
				link.l1.go = "EscapeSlave_Villemstad_H3";
			break;

			case "EscapeSlave_Villemstad_H3":
				dialog.text = "Que je reste ici pour toujours si je mens ! Tu n'as jamais entendu parler du navire des singes ? Eh bien, c'était lui... Que les crevettes me dévorent !";
				link.l1 = "Qu'est-ce que c'est que ce navire des singes ? Non, je n'en ai pas entendu parler.";
				link.l1.go = "EscapeSlave_Villemstad_H4";
			break;

			case "EscapeSlave_Villemstad_H4":
				dialog.text = "Oh... Et moi, je te dis que je l'ai vu de mes propres yeux. C'était pendant une tempête, " + pchar.questTemp.SlavetraderAreal.add + ". Il faisait nuit noire, et voilà qu'il surgit de nulle part : un navire aux voiles en lambeaux... Il avait la misaine brisée, et la grand-voile, et le beaupré, et le gaillard d'avant, et, et, et... Bref, tout était cassé chez lui ! Et il filait droit contre le vent, comme si de rien n'était ! Il y avait sur le pont des tas de singes en haillons, comme des phoques sur une roquerie ! Et à la barre, un gorille, un vrai ! Neuf pieds de haut, une chemise rouge, et sur la poitrine, au lieu d'une croix, des dents de requin... Les yeux qui brמlent, les dents qui brillent : il nous a vus et il a hurlé d'une voix inhumaine...";
				link.l1 = "Eh bien, là, tu mens complètement, mon frère. Ce qu'on ne s'imagine pas avec des yeux d'ivrogne. Tu vas aussi me dire que sur sa poupe était inscrit « Hollandais volant ».";
				link.l1.go = "EscapeSlave_Villemstad_H5";
			break;

			case "EscapeSlave_Villemstad_H5":
				dialog.text = "Euh, non, ce n'était pas le « Hollandais ». Je te dis que je ne mens pas ! C'était une barque, et sur sa poupe était écrit " + pchar.questTemp.Slavetrader.ShipName + ".";
				link.l1 = "Khe-rkh !! Bon sang ! Je crois que je sais de quels singes il s'agissait... En effet, le rhum délie les langues, il suffit d'écouter.";
				link.l1.go = "EscapeSlave_Villemstad_H6";
			break;

			case "EscapeSlave_Villemstad_H6":
				dialog.text = "Eh bien, je te le disais ! Et tu ne me crois pas !.. Allez, buvons un dernier coup et c'est tout... Je jette l'ancre.";
				link.l1 = "Bon, merci pour cette histoire intéressante. Je dois y aller. Bonne journée, l'ami.";
				link.l1.go = "exit_sit";
				Pchar.quest.Slavetrader_EscapeSlave.win_condition.l1 = "location";
				Pchar.quest.Slavetrader_EscapeSlave.win_condition.l1.location = pchar.questTemp.Slavetrader.Island.Shore;
				Pchar.quest.Slavetrader_EscapeSlave.function = "Slavetrader_EscapeSlaveInShore";
				AddQuestRecord("Slavetrader", "22_4");
				AddQuestUserData("Slavetrader", "sAreal", pchar.questTemp.SlavetraderAreal.add);
				pchar.questTemp.Slavetrader = "FindMayak";
			break;

			//ОЗГ, Крыса
			case "Rat_Tavern_1":
			dialog.text = "Il y a eu une affaire, mais qu'est-ce que ça peut vous faire, capitaine ? Les marins voient la terre ferme, le rhum et les filles, et ils deviennent idiots d'un coup : s'il y avait quelque chose sous leur chapeau, ça ne se remarque pas ici.";
			link.l1 = "C'est ça, bien sמr... c'est juste qu'un de mes amis est navigateur sur cette pinasse, et son capitaine a oublié de se faire enregistrer au port. Et j'ai appris qu'ils avaient mouillé ici, alors je me suis dit : allons voir un vieil ami. Vous avez entendu oם ils allaient ?";
			link.l1.go = "Rat_Tavern_2";
			break;

			case "Rat_Tavern_2":
			dialog.text = "Et qui y comprendrait quelque chose, capitaine ? J'ai seulement entendu ces marins se vanter : ils allaient peloter les catins françaises au bordel quand ils commenceraient à boire leur or, celui que le patron leur paierait pour le voyage. Peut-être sont-ils partis pour l'Ancien Monde, ou peut-être ailleurs. Et ils n'ont rien dit d'autre : ils braillaient des chansons et commandaient du rhum.";
			link.l1 = "Peloter les Françaises, dites-vous... Bon, je dois y aller. Merci pour l'information !";
			link.l1.go = "exit_sit";
			CreateRatOfficer();
			Pchar.quest.Headhunter_Rattortuga.win_condition.l1 = "location";
			Pchar.quest.Headhunter_Rattortuga.win_condition.l1.location = "Tortuga";
			Pchar.quest.Headhunter_Rattortuga.function = "Headhunter_CreateRatpinasse";
			pchar.questTemp.Headhunter = "Rat_tortuga";
			SetFunctionTimerCondition("Headhunter_PinasseOver", 0, 0, 30, false);
			AddQuestRecord("Headhunt", "14");
		break;

		case "sit_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			AddMoneyToCharacter(pchar, -2);
			//navy --> Alcohol - rum count;
			if (CheckAttribute(pchar, "questTemp.Rum"))
			{
				pchar.questTemp.Rum = sti(pchar.questTemp.Rum) + 1;
			}
			else pchar.questTemp.Rum = 1;
			//<-- navy
			WaitDate("",0,0,0, 0, 30);
			dialog.text = LinkRandPhrase("Tu es "+ GetSexPhrase("un vrai pote", "une vraie matelote") +" ! Faisons connaissance !",
			                             "Hic ! Quel rhum ! Bon... Trinquons !",
										 "א ta santé et à ta générosité !");
			link.l1 = "Oh, un rhum bien capricieux. Bon, je dois y aller, amuse-toi bien.";
			link.l1.go = "exit_sit";
			if (makeint(pchar.money) >=2)
			{
				link.l2 = "Prenons encore une tasse.";
				link.l2.go = "sit_3";
			}

            link.l4 = LinkRandPhrase("J'ai l'impression d'être en mer depuis une éternité. Quoi de neuf dans le coin ?",
                                    "Dis-moi, de quoi on parle en ce moment ? Ce n'est pas pour rien que je t'abreuve de rhum...",
                                    "Dis-moi, mon frère, quelles histoires courent dans les tavernes ?");
		    link.l4.go = "rumours_habitue";
		    //homo
		break;

		case "sit_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			int iSituation = makeint(rand(5));
			switch (iSituation)
			{
				case 0:
					if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
					dialog.text = "Oh ! Voilà une idée sensée !";
					link.l1 = "Aubergiste ! Apporte du rhum !";
					link.l1.go = "sit_2";
				break;

				case 1:
					if(rand(1) == 0)
					{
						if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
						dialog.text = RandPhraseSimple("Vous voilà, " + GetAddress_Form(NPChar) + "Tu crois sans doute que tout le monde t'admire, hein ? Mais pour moi, tu n'es qu'un voleur et un assassin ordinaire. Ils ont même inventé le « pirate bla-bla » ! Un bandit reste un bandit, en mer comme sur terre...",
							"Hic ! "+ GetSexPhrase("Sa... salopard", "Or... ordure") +" ! Tu v-veux me soמler, hic ! Et me voler mon argent !");
						link.l1 = "Je vois que tu as déjà trop chargé à bord... Va cuver, et moi, je dois y aller.";
						link.l1.go = "exit_sit";
						link.l2 = "Ton ton ne me plaît pas, l'ami. Tu aurais dמ tenir ta langue.";
						link.l2.go = "sit_case_2_enemy";
						link.l3 = "Qui tu traites de bandit, rat de terre ?! Voyons comment tu chantes avec un trou dans le ventre !";
						link.l3.go = "sit_case_2_enemy2";
					}
					else
					{
						if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
						dialog.text = RandPhraseSimple("Pourquoi tu me fixes comme ça ? Je suppose que tu veux me soמler et me faire les poches ?! Il y a toutes sortes de racailles ici ! Hic !.. Un honnête homme ne peut même plus entrer dans une taverne !",
							"Tu me respectes ? Tu me respectes, je te demande ?!! Sinon, gare à toi... Je ne laisserai rien passer : en plein entre les deux yeux... et c'est tout, commande une messe pour le repos de ton âme.");
						link.l1 = "L'ami, je vois que tu as la cale pleine. Tu devrais rentrer chez toi... Et moi, je dois y aller.";
						link.l1.go = "exit_sit";
						link.l2 = "Pas si vite, mon gars. Sais-tu seulement à qui tu parles...";
						link.l2.go = "sit_case_2_enemy1";
						link.l3 = "Qu'est-ce que tu regardes comme ça ?! Je vais te remettre les idées en place !";
						link.l3.go = "sit_case_2_enemy2";
					}
					link.l4 = "Calme-toi ! Qu'est-ce qui te prend ? Je suis ton seul vrai ami !";
					link.l4.go = "sit_case_2_friend";
				break;

				case 2:
					if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
					dialog.text = "וcoute ! Tu es q-q-quelqu'un de bien ! T-tu pourrais peut-être m'aider dans... dans... dans une petite affaire ?";
					link.l1 = "Non, je crois qu'il est temps pour moi de partir.";
					link.l1.go = "exit_sit";
					link.l2 = "B-bien sמr ! Après tout, nous sommes... hic... amis !";
					link.l2.go = "sit_case_3";
				break;

				case 3:
					if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
					if (IsCharacterPerkOn(pchar, "Adventurer") || IsCharacterPerkOn(pchar, "Agent"))
					{
						if (GetSummonSkillFromName(pchar, SKILL_SNEAK) > rand(110))
						{
						dialog.text = "...Et alors j'ai saisi son épée par la l-lame et...";
							link.l1 = "Arrête, mais qu'est-ce que tu croyais !";
							link.l1.go = "sit_case_6";
						}
						else
						{
							dialog.text = "...Et alors j'ai saisi son épée par la l-lame et...";
							link.l1 = "... et-hic ! Et elle me dit...";
						link.l1.go = "sit_2";
						}
					}
					else
					{
						if (GetSummonSkillFromName(pchar, SKILL_SNEAK) > rand(110))
						{
						dialog.text = "...Et alors j'ai saisi son épée par la l-lame et...";
							link.l1 = "... et elle me dit...";
							link.l1.go = "sit_2";
						}
						else
						{
							dialog.text = "...Et alors j'ai saisi son épée par la l-lame et...";
							link.l1 = "... et-hic ! Et elle me dit...";
						link.l1.go = "sit_case_4_exit";
						}
					}
				break;

				case 4:
					if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
					dialog.text = "א toi ! Ah, diable ! Qui c'est, celui-là ?!";
					link.l1 = "Hein ? Quoi ? Oם ? Il m'a semblé voir quelque chose.";
					link.l1.go = "sit_2";// to_do "sit_case_5_exit";
				break;

                case 5:
					if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
                    if (!CheckAttribute(pchar , "GenQuest.GhostShip.LastBattleEnd") && !checkAttribute(npchar, "GhostShip_Speak_Yet") && pchar.GenQuest.GhostShip.lastspeak_date != LastSpeakDate() && pchar.rank >= 10)
					{
                        dialog.text = "Prenons encore une tasse.";
                        link.l1 = "Oh, un rhum bien capricieux. Bon, je dois y aller, amuse-toi bien.";
						link.l1.go = "exit_sit";
						switch (sti(pchar.GenQuest.GhostShip.AskAbout))
						{
							case 0 :
								link.l2 = "Quelles histoires courent dans les tavernes ?";
								link.l2.go = "GhostShip_Speak_1";
							break;

							case 1 :
								link.l2 = "Quelles choses intéressantes se passent dans ces eaux ?";
								link.l2.go = "GhostShip_Speak_2";
							break;

							case 2 :
								link.l2 = "Dis-moi, mon frère, que sais-tu du vaisseau fantכme, le Hollandais volant ?";
								link.l2.go = "GhostShip_Speak_3";
							break;
						}
					}
					else
					{
	         			dialog.text = "Bois-moi ça !";
						link.l1 = "Cul sec !";
						link.l1.go = "sit_2";
					}
                break;
			}
		break;

		case "sit_case_5_exit": // дуэль
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("fighting");
		break;

		case "sit_case_6": // откуп
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Quoi donc ?";
			link.l1 = "Tu as donc décidé de me voler ? Tu ne voudrais pas une épée dans la poitrine ?";
			link.l1.go = "sit_case_61";
		break;

		case "sit_case_61": // откуп
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.text = "Non, non, je ne veux pas d'ennuis ! Prends 1000 piastres et laisse-moi tranquille, je t'en prie.";
			AddMoneyToCharacter(pchar, 1000);
			link.l1 = "Soit, d'accord. Je te pardonne pour cette fois.";
			link.l1.go = "exit_sit";
		break;

		case "sit_case_4_exit":
			//navy --> Alcohol
			if (CheckAttribute(pchar, "questTemp.Rum"))
			{
				if (sti(pchar.questTemp.Rum) < 3) LAi_AlcoholSetDrunk(pchar, 51, 5600);
				else LAi_AlcoholSetDrunk(pchar, 71, sti(pchar.questTemp.Rum)*2800);
			}
			//<-- navy
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			pchar.questTemp.friend_in_tavern = npchar.id;
			AddDialogExitQuest("without_memory");
		break;

		case "sit_case_3":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.snd = "Voice\HADI\HADI037";
			dialog.text = "Le fait est que j'ai é-été insulté par l'un des s-soldats. Voilà !";
			link.l1 = "Un s-soldat ? N-non, je crois que je vais passer mon tour.";
			link.l1.go = "exit_sit";
			link.l2 = "Calme-toi ! Qu'est-ce qui te prend ? Je suis ton seul vrai ami !";
			link.l2.go = "sit_2";
		break;

		case "sit_case_2_friend":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.snd = "Voice\HADI\HADI038";
			dialog.text = "Toi ? Q-quel ami es-tu ?! N-non ! Tu veux... hic... Tu veux me tuer ! Voilà !";
			link.l1 = "Bon, je vois que tu en as assez pour aujourd'hui. Adieu.";
			link.l1.go = "exit_sit";
			link.l2 = "Quoi ? Oui, je vais te prouver tout de suite que je ne veux pas te tuer ! Je vais te donner un coup de main... hic... Je vais te la couper !";
			link.l2.go = "sit_case_2_friend_2";
		break;

		case "sit_case_2_friend_2":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.snd = "Voice\HADI\HADI039";
			dialog.text = "Ah ! וloignez-moi "+ GetSexPhrase("cet homme", "cette femme") +" !!";
			link.l1 = "Du calme... hic... דa ne fera pas mal !";
			link.l1.go = "tavern_keeper";
		break;
/*
		case "sit_case_2_enemy":
			dialog.snd = "Voice\HADI\HADI040";
			dialog.text = RandSwear() + "I'll carve you up like a pig!";
			link.l1 = "We'll see about that!";
//			link.l1.go = "tavern_keeper";
			link.l1.go = "fight_right_now"; //navy -- битва в таверне без базаров! :)
		break;
*/
		case "sit_case_2_enemy":
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
			dialog.snd = "Voice\HADI\HADI040";
			dialog.text = "Ne me fais pas peur !.. Je ne suis pas tombé sur le bon, hic !.. Les gens comme toi ont leur place au gibet, comme n'importe qui ! Tu as beau faire la roue, on sent ton poisson pourri à une lieue. Et je n'ai pas l'intention de choisir mes mots avec des gens comme t-hic toi !";
			link.l1 = "Bah, qu'attendre d'un tel ivrogne. Je vais prendre l'air...";
			link.l1.go = "exit_sit1";
			link.l2 = "Et toi, mon garçon, tu vas trop loin. Je vais te faire ravaler tes paroles !";
			link.l2.go = "sit_case_2_enemy3";
		break;

		case "sit_case_2_enemy1":
			dialog.snd = "Voice\HADI\HADI040";
			dialog.text = "Qu'est-ce que c'est ?! Je vais te tenir de ces mains-là... Hic !.. Personne ne m'a encore échappé !";
			link.l1 = "Sale ivrogne, il m'a gâché une si belle soirée. Bon, va attraper tes cafards, je crois que je vais y aller.";
			link.l1.go = "exit_sit1";
			link.l2 = RandSwear() + "Je vois que tu n'as pas l'intention de te calmer. Je vais devoir te donner une leçon de bonnes manières.";
			link.l2.go = "sit_case_2_enemy3";
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
		break;

		case "sit_case_2_enemy2":
			ChangeCharacterReputation(pchar, -2);
			if(rand(1) == 0)
			{
				dialog.text = LinkRandPhrase("Viens par ici, canaille ! Tu vas en prendre pour ton grade !", RandSwear() + "Maintenant, je vais te découper comme il faut !", "Ha ! Allez, marin, voyons ce que tu vaux sur terre !");
				link.l1 = RandPhraseSimple(RandPhraseSimple("Je te jure que tu vas le regretter !!!", "Je vais te raccourcir ta sale langue jusqu'aux oreilles !"), RandPhraseSimple("Je vais te vider comme un hareng !", "Je te jure que je vais te faire taire !!!"));
				link.l1.go = "fight_right_now";
			}
			else
			{
				dialog.text = "Allez, les gars ! Débarrassons notre ville de cette vermine !";
				link.l1 = RandPhraseSimple(RandSwear() + "Eh bien, priez, salauds !", "Oh, tu n'es pas seul, en plus !!! Eh bien, vous aurez de la compagnie en enfer !");
				link.l1.go = "fight_right_now_1";
			}
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
		break;

		case "sit_case_2_enemy3":
			ChangeCharacterReputation(pchar, 2);
			if(rand(1) == 0)
			{
				dialog.text = LinkRandPhrase("Viens par ici, canaille ! Tu vas en prendre pour ton grade !", RandSwear() + "Maintenant, je vais te découper comme il faut !", "Ha ! Allez, marin, voyons ce que tu vaux sur terre !");
				link.l1 = RandPhraseSimple(RandPhraseSimple("Je te jure que tu vas le regretter !!!", "Je vais te raccourcir ta sale langue jusqu'aux oreilles !"), RandPhraseSimple("Je vais te vider comme un hareng !", "Je te jure que je vais te faire taire !!!"));
				link.l1.go = "fight_right_now";
			}
			else
			{
				dialog.text = "Allez, les gars ! Débarrassons notre ville de cette vermine !";
				link.l1 = RandPhraseSimple(RandSwear() + "Eh bien, priez, salauds !", "Oh, tu n'es pas seul, en plus !!! Eh bien, vous aurez de la compagnie en enfer !");
				link.l1.go = "fight_right_now_1";
			}
			if(Pchar.chr_ai.type != LAI_TYPE_SIT) LAi_SetSitType(pchar);
		break;

		case "exit_sit":
			//navy --> Alcohol
			if (CheckAttribute(pchar, "questTemp.Rum"))
			{
				if (sti(pchar.questTemp.Rum) < 3) LAi_AlcoholSetDrunk(pchar, 51, 5600);
				else LAi_AlcoholSetDrunk(pchar, 71, sti(pchar.questTemp.Rum)*2800);
			}
			//<-- navy
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("exit_sit");
		break;

		case "exit_sit1":
			ChangeCharacterReputationToNeutral(pchar, 2);
			//navy --> Alcohol
			if (CheckAttribute(pchar, "questTemp.Rum"))
			{
				if (sti(pchar.questTemp.Rum) < 3) LAi_AlcoholSetDrunk(pchar, 51, 5600);
				else LAi_AlcoholSetDrunk(pchar, 71, sti(pchar.questTemp.Rum)*2800);
			}
			//<-- navy
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("exit_sit");
		break;


		case "tavern_keeper":
			//navy --> Alcohol
			if (CheckAttribute(pchar, "questTemp.Rum"))
			{
				if (sti(pchar.questTemp.Rum) < 3) LAi_AlcoholSetDrunk(pchar, 51, 5600);
				else LAi_AlcoholSetDrunk(pchar, 71, sti(pchar.questTemp.Rum)*2800);
			}
			//<-- navy
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();
			AddDialogExitQuest("tavern_keeper");
		break;

		//------------------------------------------------------------------------------------------------------------------
		// Dolphin -> Генератор возврата выигрыша
		case "HOTP_CasinoQuest_1":
			pchar.questTemp.KIP_Looser = "KIP_Looser";
			//SetTimerFunction("LooserGenerator_NewGeneratorQuest", 0, 0, 15);
			npchar.CasinoQuest.decline = true;	// второй раз говорить об этому уже не будет
			dialog.text = "Vous avez raison, "+ GetSexPhrase("l'ami", "ma petite") +". J'ai perdu tout ce que j'avais l'autre jour. Je crois que la fortune a décidé de se moquer de moi. C'était comme une obsession.";
			link.l1 = RandSwear()+"Qui est ce veinard ?";
			link.l1.go = "HOTP_CasinoQuest_2";
		break;

		case "HOTP_CasinoQuest_2":
			dialog.text = "Je ne rigole pas, capitaine ! Je dois récupérer cet argent à tout prix, et j'ai besoin d'aide. Vous avez l'air d'avoir de la jugeote, "+ GetSexPhrase("le gars", "la fille") +", et vous devez comprendre que je ne peux pas le faire moi-même : je suis trop connu ici.";
			link.l1 = "Qu'est-ce que vous insinuez ?";
			link.l1.go = "HOTP_CasinoQuest_3";
		break;

		case "HOTP_CasinoQuest_3":
			dialog.text = "Aidez-moi à récupérer cet argent, et je vous remercierai comme personne ne vous a jamais remercié.";
			link.l1 = "Je ne pense pas que ce soit possible.";
			link.l1.go = "exit";
			link.l2 = "Voyons ce qu'on peut faire.";
			link.l2.go = "HOTP_CasinoQuest_5";

			Diag.TempNode = "First time";
		break;

		case "HOTP_CasinoQuest_5":
			int KIP_Kto_Ukral
			KIP_Kto_Ukral = rand(1);
			if (KIP_Kto_Ukral == 0)
			{
				dialog.text = "Celui avec qui je jouais, c'est le propriétaire du magasin d'ici. Il m'a plumé jusqu'à l'os, et maintenant il doit bien rire de moi. Il faut lui donner une leçon "+
							"Je vous propose de fouiller discrètement les coffres de sa réserve. Sept bourses devraient encore s'y trouver. Il faut le faire avant la fin de la journée. Demain, il sera trop tard.";
				link.l1 = "Désolé, l'ami, mais ce travail n'est pas pour moi.";
				link.l1.go = "exit";
				link.l2 = "Je vais le faire.";
				link.l2.go = "exit_CasinoQuest_Magazin";

				Diag.TempNode = "First time";
			break;
			}
			if (KIP_Kto_Ukral == 1)
			{
				dialog.text = "Celui avec qui je jouais, c'est le propriétaire du chantier naval. Il m'a plumé jusqu'à l'os, et maintenant il doit bien rire de moi. Il faut lui donner une leçon\n"+
							"Je vous propose de fouiller discrètement les coffres de sa réserve. Sept bourses devraient encore s'y trouver. Il faut le faire avant la fin de la journée. Demain, il sera trop tard.";
				link.l1 = "Désolé, l'ami, mais ce travail n'est pas pour moi.";
				link.l1.go = "exit";
				link.l2 = "Je vais le faire.";
				link.l2.go = "exit_CasinoQuest_Verf";

				Diag.TempNode = "First time";
			break;
			}
		break;

		case "exit_CasinoQuest_Magazin":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();

			pchar.HOTP_CasinoQuest.npcharID = npchar.id;
			AddDialogExitQuestFunction("LooserGenerator_sart_Magazin");
		break;

		case "exit_CasinoQuest_Verf":
			Diag.CurrentNode = Diag.TempNode;
			DialogExit();

			pchar.HOTP_CasinoQuest.npcharID = npchar.id;
			AddDialogExitQuestFunction("LooserGenerator_sart_Verf");
		break;
	}
}

bool CheckFreeSitFront(ref _npchar)
{
 	ref rCharacter; //ищем
	int n;

	if (!CheckAttribute(_npchar, "Default.ToLocator")) return false;

	for (n=0; n<MAX_CHARACTERS; n++)
	{
		makeref(rCharacter, Characters[n]);
		if (CheckAttribute(rCharacter, "location") && rCharacter.location == _npchar.location)
		{
            if (rCharacter.location.locator == _npchar.Default.ToLocator)
                return  false;
		}
    }
    return  true;
}
