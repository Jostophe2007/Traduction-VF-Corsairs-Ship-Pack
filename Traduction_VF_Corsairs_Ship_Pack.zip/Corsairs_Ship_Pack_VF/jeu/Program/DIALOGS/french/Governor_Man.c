string sNationNameglobal;
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref aData;
	aref Link, NextDiag, arName;

	DeleteAttribute(&Dialog, "Links");

	ref arItem;

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
    string attrLoc, QuestName, sTemp;
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOff");
			LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "", -1);
		break;
		case "First Time":
			dialog.text = "Bonjour, vous êtes " + GetFullName(pchar) + ", n'est-ce pas ?";
			link.l1 = "Oui, c'est exact. Que se passe-t-il au juste ?";
			link.l1.go = "Invite";
		break;
		case "Invite":
			string sNationName = GetNationNameByType(sti(npchar.nation));
			sNationNameglobal = GetNationNameByType(sti(npchar.nation));
			dialog.text = "Vos services rendus à " + NationNameGenitive(sti(npchar.nation)) + " n'ont pas échappé à l'attention. Le gouverneur général en personne vous invite à venir lui présenter vos respects.\nVous pouvez vous présenter quand bon vous semble.";
			link.l1 = "Magnifique ! Je lui rendrai visite sans faute, si possible. Au revoir, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "exit";
			sld = CharacterFromID(NationShortName(sti(npchar.nation))+"_guber");
			sld.dialog.CurrentNode = "GivePatent";
			chrDisableReloadToLocation = false;
			pchar.(sNationName).quest.mayor.done = true;
		break;
	}
}