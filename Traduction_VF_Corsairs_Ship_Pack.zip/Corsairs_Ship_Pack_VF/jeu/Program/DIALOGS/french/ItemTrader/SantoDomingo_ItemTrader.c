// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), "Encore des questions, " + GetAddress_Form(NPChar) + "...", "Des questions, des questions... Et si on faisait plutכt du commerce, " + GetAddress_Form(NPChar) + " ?",
                          "וcoutez, combien de conversations creuses peut-on avoir ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("Pas de questions...", "Je n'ai rien à dire pour le moment."), "Eh, encore...",
                      "Oui, il vaut vraiment mieux marchander...", "Hum, désolé, marchand...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PDM_PK_IshemKoltso"))	// Квест "The Lost Ring"
            {
                link.l1 = "Je cherche une bague qui appartenait à... à l'un de mes amis. Une bague d'une certaine valeur. Et cette bague se trouve quelque part dans cette ville. Vous en avez peut-être entendu parler ? Un gros saphir serti dans de l'or.";
                link.l1.go = "IshemKoltso";
            }
		break;

//******************** Квест "The Lost Ring" ******************
		case "IshemKoltso":
			int Phrase;
                Phrase = rand(4);
                if (Phrase == 0)
                {
					dialog.text = "Vous me prenez pour qui, un joaillier ? Cette question n'est vraiment pas pour moi.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
                if (Phrase == 1)
                {
					dialog.text = "J'ai bien une bague, mais elle porte " + LinkRandPhrase("un rubis", "une émeraude", "un diamant") + ".";
					link.l1 = "Tant mieux pour vous.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 2)
                {
					dialog.text = "Je ne vends pas de bagues.";
					link.l1 = "Désolé.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 3)
                {
					dialog.text = "Je n'ai pas de bagues, désolé.";
					link.l1 = "Bon, je vais chercher ailleurs.";
					link.l1.go = "exit";
				break;
				}
				if (Phrase == 4)
                {
					dialog.text = "Hum... Un saphir, dites-vous ? Oui, j'en ai bien vu une, j'en suis sמr"+ NPCharSexPhrase(NPChar, "", "e") +" : une bague comme celle dont vous parlez. Une fille la porte ; vous la connaissez peut-être, du moins la plupart des marins la connaissent bien. Elle s'appelle Francesca. Pour être honnête, je n'ai jamais rencontré fille plus sotte. Un soldat lui a offert cette bague il y a deux ou trois ans. Il était peut-être encore plus sot qu'elle, car cette bague vaut beaucoup d'argent. Oui, c'est sans doute la bague que vous cherchez.";
					link.l1 = "Merci, " + npchar.name+", vous ne pouvez pas savoir à quel point vous m'avez rendu service. א plus tard.";
					link.l1.go = "exit";

					AddQuestRecord("PDM_Poteryanoe_Koltso", "3");
					AddQuestUserData("PDM_Poteryanoe_Koltso", "sSex", GetSexPhrase("", "e"));
					DeleteAttribute(pchar, "questTemp.PDM_PK_IshemKoltso");

					sld = GetCharacter(NPC_GenerateCharacter("PDM_PK_Francheska", "BaynesDaughterSTOK", "woman", "woman", 10, SPAIN, -1, false));
					sld.name = "Francesca";
					sld.lastname = "";
					sld.city = "SantoDomingo";
					sld.location	= "SantoDomingo_Brothel";
					sld.location.group = "goto";
					sld.location.locator = "goto3";
					sld.dialog.filename   = "Quest\PDM\Poteryanoe_Koltso.c";
					sld.dialog.currentnode   = "Francheska";
					LAi_SetCitizenType(sld);
					LAi_group_MoveCharacter(sld, "SPAIN_CITIZENS");
					LAi_SetImmortal(sld, true);
				break;
				}
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

