// Генерируемый скелет-босс из пещеры
#include "DIALOGS\french\Rumours\Common_rumours.c"
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	float locx, locy, locz;

	ref cursedLocLoad = &locations[reload_location_index];
	bool hungry = true;
	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	//ref itm;
	int skullgen = drand1(2)+1;
	string cursed_artifact = "sculMa"+sti(skullgen); // Квестовый предмет

	ProcessCommonDialogRumors(NPChar, Link, NextDiag);
	switch(Dialog.CurrentNode)
	{
		case "First time":
			if (npchar.quest.meeting == "0")
			{
				scareOfficers(50);
				dialog.text = "Comment oses-tu troubler la paix de mon tombeau, misérable ?! Et tu fouilles dans mes affaires ! דa mérite une leçon.";
				npchar.quest.meeting = "1";
				link.l1 = "Zut, je pensais que personne ne vivait ici. Excuse-moi, je m'en vais tout de suite.";
				link.l1.go = "meeting_1";
				//Если мы пришли по церковному квесту
				if(CheckAttribute(cursedLocLoad, "DestroyGhost"))
				{
					link.l1 = "Je suis ici pour débarrasser cet endroit de la souillure ! Arrière, créature impure ! Au nom de Dieu, je te conjure...";
					link.l1.go = "meeting_2";
					break;
				}
				link.l3 = "Crève, sale engeance !";
				link.l3.go = "skel_fight";
				if (CheckAttribute(pchar, "questTemp.AnjelikaTichPrologue") && pchar.questTemp.AnjelikaTichPrologue == "ATP")	//Sinistra Пролог Анжелика Тич
				{
					dialog.text = "N'aie pas peur de moi, je suis un gentil mort-vivant. Prends ce que tu veux, ne te prive de rien.";
					link.l1 = "(sous le choc) Mère de Dieu !";
					link.l1.go = "AT_pr_Uhoju";
					npchar.lifeday = 0;
					DeleteAttribute(link, "l2");
					DeleteAttribute(link, "l3");
				}
				NextDiag.TempNode = "First time";
				break;
			}
			else if (npchar.quest.meeting == "2")
			{
				dialog.text = "Je t'ai donné une chance de sauver ta misérable vie, mais tu ne l'as pas saisie. ";
				DeleteAttribute(pchar, "cursed.waitingSkull");
				LAi_SetPlayerType(PChar);



				link.l1 = "Diable, comment t'es-tu retrouvé ici ? Attends, je peux encore trouver ton crâne !";
				link.l1.go = "end_quest_battle";
				link.l2 = "Mille sabords !..";
				link.l2.go = "skel_fight";
				if(CheckCharacterItem(pchar, pchar.questTemp.Cursed.Item) && CheckAttribute(pchar, "cursed.Skullbought"))
				{
					dialog.text = "Je sais que tu as le crâne. Donne-le-moi.";
					link.l1 = "Prends-le, et laisse-moi enfin tranquille !";
					link.l1.go = "end_quest";
					link.l2 = "Et puis quoi encore. Maintenant, le crâne est à moi. Merci du tuyau, sans toi, je ne l'aurais pas trouvé.";
					link.l2.go = "end_quest_battle";
				}

			}
			else
			{
				dialog.text = "Des questions ?";
				npchar.quest.meeting = "1";

				link.l1 = "Quand je t'aurai rendu le crâne, que comptes-tu faire ? Tu vas annuler le pacte et accepter la mort ?";
				link.l1.go = "question";
				link.l2 = "J'ai décidé de t'envoyer au repos d'une autre manière, plus efficace !";
				link.l2.go = "skel_fight";
				link.l3 = "Non.";
				link.l3.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "question":
			dialog.text = "J'y réfléchis depuis longtemps. Avec le crâne, je pourrai retrouver ma vie d'avant, mon corps. Je me trouverai peut-être même un navire, et je retrouverai ma sinistre réputation. Non, je n'ai pas vraiment l'intention de mourir.";
			link.l1 = "Bon, je vais le chercher.";
			link.l1.go = "question";
			link.l2 = "Même si cette vie s'obtient au prix de milliers de morts ? Ah non, il faut que je t'arrête !";
			link.l2.go = "skel_fight";
		break;
		case "end_quest_battle":
			dialog.text = "Trop tard, je me trouverai un chercheur plus accommodant.";
			link.l1 = "Caramba !";
			link.l1.go = "skel_fight";
			if(CheckCharacterItem(pchar, pchar.questTemp.Cursed.Item) && CheckAttribute(pchar, "cursed.Skullbought"))
				{
					dialog.text = "Tu n'aurais pas dמ commencer ça, personne n'a jamais réussi à me vaincre sous cette forme.";
					link.l1 = "Il y a un début à tout !";
					link.l1.go = "skel_fight";
				}

		break;

		case "end_quest":
			dialog.text = "Merci. Comme promis, tu es libre. Pour te récompenser de tes efforts, je vais même te donner un livre. Il n'y avait pas grand-chose à faire pendant les longues années que j'ai passées dans cette grotte, alors je l'ai lu et relu. Je dois avouer que c'est une lecture passionnante. J'y ai découvert quelque chose de nouveau à chaque fois.";
			TakeItemFromCharacter(pchar, pchar.questTemp.Cursed.Item);
			string book = PickAbook();
			GiveItem2Character(pchar, book);
			LAi_SetImmortal(npchar, true);
			link.l1 = "דa alors, merci !";
			CloseQuestHeader("CursedSkeleton");
			link.l1.go = "Exit_1";
		break;

		case "skel_fight":
			AddDialogExitQuest("MainHeroFightModeOn");
			npchar.SaveItemsForDead = true;
			LAi_group_Attack(NPChar, Pchar);
			LAi_SetWarriorType(NPChar);
			SetSkeletonsToLocation(cursedLocLoad);
			LAi_group_MoveCharacter(NPChar, LAI_GROUP_MONSTERS);
			LAi_SetImmortal(npchar, false);
			npchar.quest.meeting = "0";
			LAi_group_SetRelation(LAI_GROUP_MONSTERS, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			DeleteAttribute(pchar, "cursed.Skullbought");
			CloseQuestHeader("CursedSkeleton");
            DialogExit();
		break;

		case "meeting_1":
			dialog.text = "Ah non, tu ne t'en tireras pas si facilement. J'ai besoin d'aide pour une affaire. Si tu réussis, je te laisserai la vie et la liberté. Et ce qui arrivera en cas d'échec ou de refus, mieux vaut pour toi ne pas le savoir.";
			link.l1 = "Et de quelle aide as-tu besoin ?";
			link.l1.go = "meeting_3";

			link.l2 = "Je préfère encore te tailler en pièces !";
			link.l2.go = "skel_fight";
		break;

		case "meeting_2":
			dialog.text = "Tu n'as aucune chance contre moi. Tes sortilèges ne te serviront à rien ici, et le Seigneur ne t'entendra pas.";
			npchar.quest.answer_1 = "true";
			TakeNItems(NPCHAR, "Chest_ammo", 2 + sti(pchar.rank)*0.1);
			TakeNItems(NPCHAR, "Chest_quest", 1 );
			link.l1 = "C'est ce qu'on verra ! Seigneur, guide ma main pour que je puisse frapper cet impur à ta gloire !";
			link.l1.go = "skel_fight";
		break;

		case "meeting_3":
			dialog.text = "Vois-tu, je n'ai pas toujours été comme ça. Dans une vie antérieure, j'avais mon propre navire, tout comme toi. Je dirai même plus : j'étais un corsaire dont le nom semait la terreur dans toutes les colonies. Mais c'était il y a trop longtemps pour que quelqu'un s'en souvienne.";
			link.l2 = "...";
			link.l2.go = "meeting_5";
			link.l1 = "Viens-en au fait.";
			link.l1.go = "meeting_4";
		break;
		case "meeting_4":
			dialog.text = "Ne m'interromps pas, misérable ! Sinon, ta vie s'achèvera ici et maintenant !";
			link.l1 = "Pardon, continue.";
			link.l1.go = "meeting_5";

			link.l2 = "J'en ai déjà assez. Je vais abréger tes souffrances tout de suite !";
			link.l2.go = "skel_fight";
		break;
		case "meeting_5":
			dialog.text = "De mon vivant, la chance me souriait, et j'ai amassé beaucoup de butin précieux. Et quand j'ai décidé de me retirer, je comptais enterrer une partie de mon butin dans le coffre qui est à cכté de toi. Il n'y a rien dedans maintenant, bien sמr, car j'ai été sauvagement assassiné ici même, sans avoir pu terminer ce que j'avais commencé.";
			link.l1 = "Et qui a fait ça ?";
			link.l1.go = "meeting_6";

			link.l2 = "Tout ça est très intéressant, mais il est temps pour moi de regagner mon navire, et pour toi de rejoindre l'autre monde !";
			link.l2.go = "skel_fight";
		break;
		case "meeting_6":
			dialog.text = "Mon propre second ! Je le considérais comme mon meilleur ami, mais il m'a trahi, et il a même entraîné l'équipage avec lui. Tout ça à cause de ce maudit crâne, que le diable l'emporte.";
			link.l1 = "Quel crâne ?";
			link.l1.go = "meeting_7";
		break;
		case "meeting_7":
			SelectCursedRendom();
			pchar.questTemp.Cursed.Item = cursed_artifact;
			dialog.text = "J'ai eu la bêtise de conclure un marché, ivre, avec un type aux yeux de chat. J'ai compris trop tard que c'était un démon. Il m'a donné ce "+ GetConvertStr("itmname_"+pchar.questTemp.Cursed.Item, "ItemsDescribe.txt") +" en me disant que tant que je porterais cet objet sur moi, la chance ne me quitterait pas.\nMais tout a un prix. Pour que l'effet dure, il faut régulièrement envoyer les âmes d'autres gens dans l'autre monde, sinon une malédiction prend la place de la chance ; c'est comme ça que je me suis retrouvé dans cet état.";
			link.l1.go = "meeting_7_1";
		break;
		case "meeting_7_1":
			dialog.text = "Pour annuler le pacte avec le démon, il fallait enterrer le crâne loin des vivants. C'est ce que j'allais faire ici. Je suppose que je n'avais pas tué depuis trop longtemps et que je m'en suis rendu compte trop tard : je n'ai pas vu l'effet bénéfique du crâne se changer en effet néfaste et retourner mon meilleur ami contre moi. Le pire, c'est qu'avec cette malédiction, on ne peut ni vivre pleinement, ni mourir.";
			link.l1 = "Si je comprends bien, tu veux retrouver ce " + GetConvertStr("itmname_"+pchar.questTemp.Cursed.Item, "ItemsDescribe.txt") +" ?";
			link.l1.go = "meeting_8";
		break;
		case "meeting_8":
			dialog.text = "Oui. Et je sais même oם il pourrait être. De mon vivant, mon équipage et moi écoulions notre butin chez un marchand de "+ XI_ConvertString("Colony" + pchar.questTemp.Cursed.TownId + "Gen") +". Mon second n'a sמrement pas compris la vraie valeur de cet objet, et il l'a vendu avec le reste de mes affaires. Vas-y immédiatement, je ne peux plus attendre.";
			link.l1 = "D'accord...";
			link.l1.go = "meeting_9";
		break;
		case "meeting_9":
			dialog.text = "Je te donne exactement un mois pour trouver le crâne. Sinon, tu le regretteras. Et ne crois pas qu'il te suffira de sortir d'ici pour te débarrasser de moi : j'ai lié mon âme à la tienne, alors je n'aurai aucun mal à te retrouver, même au bout du monde.";

			ReOpenQuestHeader("CursedSkeleton");
			AddQuestRecord("CursedSkeleton", "1");
			AddQuestUserData("CursedSkeleton", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("CursedSkeleton", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("CursedSkeleton", "scityName", XI_ConvertString("Colony" + pchar.questTemp.Cursed.TownId));
			npchar.lifeday = 0;
			link.l1 = "Arrête de me faire peur. Je vais t'aider. Je mets le cap sur "+ XI_ConvertString("Colony" + pchar.questTemp.Cursed.TownId + "Acc") +".";
			pchar.cursed.waitingSkull = true;
			link.l1.go = "exit";
		break;
		
		case "AT_pr_Uhoju":
			DialogExit();
			
			sld = CharacterFromID("CursedSkeleton")
			ChangeCharacterAddressGroup(sld, "none", "", "");
		break;


// <-- специальные реакции

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_SetWarriorType(NPChar);
			DialogExit();
		break;
		case "Exit_1":
			NextDiag.CurrentNode = NextDiag.TempNode;
			ChangeCharacterAddress(npchar, "none", "");
			npchar.lifeday = 0;
			DeleteAttribute(pchar, "cursed.Skullbought");
			chrDisableReloadToLocation = false;
			DialogExit();
		break;
	}
}

void SelectCursedRendom()
{
		int n, nation;
		int storeArray[MAX_COLONIES];
		int howStore = 0;
		for(n=0; n<MAX_COLONIES; n++)
		{
			if (colonies[n].nation != "none" && sti(colonies[n].nation) != PIRATE)
			{
				storeArray[howStore] = n;
				howStore++;
			}
		}
		nation = storeArray[drand(howStore-1)];
		pchar.questTemp.Cursed.TownId = colonies[nation].id;
		pchar.questTemp.Cursed.TraderId = colonies[nation].id + "_trader";

}

string PickAbook()
{
	int quality = 1;
	if (pchar.rank <= 10) quality = 1;
	if (pchar.rank >= 10) quality = 2;
	if (pchar.rank >= 20) quality = 3;
	if (pchar.rank > 30) quality = 4;
	string book = "book"+quality+"_"+sti(drand(13)+1);
	if (CheckForBookReady(book)) book = RegenerateBook(quality);
	return book;
}
