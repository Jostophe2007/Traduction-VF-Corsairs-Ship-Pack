// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.piratesLine == "Soukins_toPuertoPrincipe")
			{
				link.l1 = "Le bruit court que Sawkins réunit des hommes pour une certaine affaire. Vous n'en savez rien ?";
				link.l1.go = "PL_Q7_1";
			}
			if (CheckAttribute(pchar, "questTemp.PDM_Novaya_Rodina.IshemHugo"))
			{
				link.l2 = "Avez-vous vu Hugo Sawmill par ici ?";
				link.l2.go = "PDM_Gde_Lesopilka";
			}
		break;
		//пиратка, квест №7, попытка узнать о планах Соукинса
		case "PL_Q7_1":
			dialog.text = NPCStringReactionRepeat("Oui, quelque chose se prépare. Richard compte sans doute encore pincer les Espagnols.",
				"Nous avons déjà parlé de ce sujet.",
				"Vous me reparlez encore des projets de Richard ?",
                "Je ne vous donnerai pas de nouveaux conseils.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Compris... Et quand, et oם, vous ne savez pas ?",
				"Oui, c'est vrai.",
                "Oui, encore...",
				"Hum, merci quand même...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("PL_Q7_2", "", "", "", npchar, Dialog.CurrentNode);
		break;
		case "PL_Q7_2":
			dialog.text = "Ha, vous alors ! Richard ne révèle jamais ce genre de choses avant le tout dernier moment, même à ses capitaines. Et vous venez me le demander...";
			link.l1 = "Eh bien, on ne sait jamais. Je demande parce que je me demande si je dois m'engager dans cette affaire. Qu'en pensez-vous ?";
			link.l1.go = "PL_Q7_3";
		break;
		case "PL_Q7_3":
			dialog.text = "Je ne sais pas, "+ GetSexPhrase("le grand", "la grande") +" - à vous de décider. Sawkins a la réputation d'être un capitaine chanceux. Mais personnellement, j'irais avec lui : Richard prépare cette affaire avec un soin presque maladif. Il passe ses journées à la résidence à griffonner dans son journal...";
			link.l1 = "Hé, je vois... Eh bien, merci du conseil.";
			link.l1.go = "exit";
		break;
		//Квест "New Homeland", Ищем Лесопилку
		case "PDM_Gde_Lesopilka":
			dialog.text = "Il était là, les chasseurs de primes anglais sont venus pour lui, il s'est éclipsé par la porte de derrière à temps.";
			link.l1 = "Et alors ? Oם est-il allé ?";
			link.l1.go = "PDM_Gde_Lesopilka_2";
		break;

		case "PDM_Gde_Lesopilka_2":
			dialog.text = "Mmm... Pour 1000 pièces d'or, je vous dirai la route.";
			if (sti(pchar.Money) >= 1000)
			{
				link.l1 = "Tenez, voici votre argent. Alors, oם est-il allé ?";
				link.l1.go = "PDM_Gde_Lesopilka_3";
				link.l2 = "Je n'ai pas autant d'argent en ce moment.";
				link.l2.go = "exit";
			}
			else
			{
				link.l1 = "Je n'ai pas autant d'argent en ce moment.";
				link.l1.go = "exit";
			}
		break;

		case "PDM_Gde_Lesopilka_3":
			DeleteAttribute(pchar, "questTemp.PDM_Novaya_Rodina.IshemHugo");
			dialog.text = "Il est parti pour La Vega, cherchez-le là-bas.";
			link.l1 = "Merci, à plus tard.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, -1000);
			sld = CharacterFromID("Hugo_Lesopilka")
			ChangeCharacterAddressGroup(sld, "LaVega_Tavern", "sit", "sit10");
			AddQuestRecord("PDM_Novaya_Rodina", "3");
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

