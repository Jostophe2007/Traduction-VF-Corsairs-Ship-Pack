// boal 25/04/04 общий диалог солдат форта
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

    // вызов диалога по городам -->
    NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Fort\" + NPChar.City + "_Fort.c";
    if (!HasCityDialogFile("Fort", NPChar.City, "_Fort.c")) NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Fort\DefaultCity_Fort.c";
    if (LoadSegment(NPChar.FileDialog2))
	{
        ProcessCommonDialog(NPChar, Link, NextDiag);
		UnloadSegment(NPChar.FileDialog2);
	}
	else
	{
		NPChar.FileDialog2 = "DIALOGS\" + LanguageGetLanguage() + "\Fort\DefaultCity_Fort.c";
	    if (LoadSegment(NPChar.FileDialog2))
		{
	        ProcessCommonDialog(NPChar, Link, NextDiag);
			UnloadSegment(NPChar.FileDialog2);
		}
	}
    // вызов диалога по городам <--
    int iTest, iTemp;
	string sTemp;
    iTest = FindColony(NPChar.City); // город
    ref rColony;
	if (iTest != -1)
	{
		rColony = GetColonyByIndex(iTest);
	}
	switch(Dialog.CurrentNode)
	{
		case "Exit":
			sTemp = npchar.location;
			if (findsubstr(sTemp, "_townhall" , 0) != -1) AddDialogExitQuest("MainHeroFightModeOff");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "fight":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "First time":
            NextDiag.TempNode = "First time";
			// самовоз казённого конвоя (сделка с посыльным-агентом): страж форта узнаёт ГГ по опознавательному флагу - пропускает к коменданту
			if (FortAgent_LandGraceIdx(sti(NPChar.index)))
			{
				if (CheckAttribute(pchar, "FortAgentDeliver.delivered")) // cargo already handed to the commandant - different lines (during the +1 day grace before cleanup)
					dialog.text = LinkRandPhrase(
						"Ah, le capitaine du convoi de poudre ! Votre affaire avec le commandant est réglée : bon voyage, je ne vous retiens pas.",
						"C'est vous qui avez remis le convoi au commandant ? Tout est en ordre. Bonne route, capitaine.",
						"Nous sommes au courant : vos affaires ici sont terminées. La voie est libre, capitaine, bon vent.");
				else
					dialog.text = LinkRandPhrase(
						"Ah, c'est donc vous qui amenez le convoi de poudre et de munitions ! Sous le pavillon convenu, comme prévu. Passez, capitaine, le commandant vous attend.",
						"Un capitaine avec le convoi de poudre pour la garnison ? On nous a prévenus : vous arborez les couleurs convenues, comme annoncé. Passez, le commandant va vous recevoir.",
						"Ah, ce convoi-là ! On a repéré votre flamme depuis la mer. Entrez dans le fort, capitaine, le commandant attend ses munitions depuis longtemps.");
				link.l1 = LinkRandPhrase("Bien obligé, soldat.", "Bon service, soldat.", "Merci. Portez-vous bien.");
				link.l1.go = "exit";
				break;
			}
			if (GetNationRelation2MainCharacter(sti(NPChar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
			{
				dialog.text = RandPhraseSimple("Un espion ? Rendez vos armes !! Suivez-moi !", "Agent ennemi !! Tout de suite, sus à "+ GetSexPhrase("lui", "elle") +" !");
				link.l1 = RandPhraseSimple("Ferme-la, petit idiot !", "Qu'importe !");
				link.l1.go = "fight";
			}
			else
			{
				// eddy. проверяем, не казачок ли. -->
				if (GetRelation2BaseNation(sti(npchar.nation)) == RELATION_ENEMY && sti(NPChar.nation) != PIRATE)
				{
					dialog.text = RandPhraseSimple("Qui êtes-vous et que voulez-vous ici ?", "Halte ! Qui êtes-vous ? א quel titre essayez-vous d'entrer dans le fort ?");
					//==> по лицензии
					if (CheckNationLicence(sti(npchar.nation)))
					{
						link.l1 = "Officier, j'ai " + GetRusNameNationLicence(sti(npchar.nation)) + ", je suis donc ici en toute légalité. Veuillez en prendre connaissance...";
						link.l1.go = "LicenceOk";
					}
					else
					{
						//==> по флагу
						// заглушка на пирата
						if (sti(pchar.nation) == PIRATE)
						{
    						dialog.text = RandPhraseSimple("Des pirates dans le fort ?! Sus à "+ GetSexPhrase("lui", "elle") +" !!!", "Un pirate qui fouine par ici !! Sus à "+ GetSexPhrase("lui", "elle") +" !!!");
							link.l1 = RandPhraseSimple("Oui, pirate, et alors...", "Hé, essayez donc de m'attraper...");
							link.l1.go = "fight";
							break;
						}
						if (findsubstr(pchar.location.from_sea, "_town" , 0) != -1) //если причалил в городе
						{
							link.l1 = "Vous ne voyez donc pas flotter au mât de mon navire le pavillon de " + NationNameGenitive(sti(pchar.nation)) + " ?!";
						}
						else //если причалил не в городе
						{
							link.l1 = "J'ai jeté l'ancre près de " + XI_ConvertString(GetIslandByCityName(npchar.city)+"Gen") + " sous le pavillon de " + NationNameGenitive(sti(pchar.nation)) + ". Qu'est-ce que vous ne comprenez pas ?";
						}
						if (GetSummonSkillFromName(pchar, SKILL_SNEAK) < (10+rand(50)+rand(50)))
						{
							link.l1.go = "PegYou";
						}
						else
						{
							link.l1.go = "NotPegYou";
						}
					}
				}
				// <-- eddy. проверяем, не казачок ли.
				else
				{
					if (sti(NPChar.nation) == PIRATE)
					{
						if (sti(rColony.HeroOwn)) // наш горожанин
						{
			         		switch (rand(10))
							{
								case 0:
									dialog.text = "Eh, capitaine, qu'on était bien avec vous en mer ! Combien de navires on a coulés sous vos ordres ! Et ici...";
									link.l1 = "Et ici, mon ami, tu as sans cesse sous les yeux de charmantes femmes, comme on n'en voit jamais en mer.";
									link.l1.go = "exit";
								break;

								case 1:
									dialog.text = "Capitaine, pourquoi cette punition ?! On n'est pas des rats de terre !";
									link.l1 = "Du calme, matelot ! Tu occupes un poste important et honorable, alors arrête de geindre.";
									link.l1.go = "exit";
								break;

								case 2:
									dialog.text = "Comment ça se passe en mer, capitaine ? On la reverra un jour ?";
									link.l1 = "Bien sמr, matelot ! Fais-toi relever de ta garde, va sur le quai et profite de la mer autant que tu veux.";
									link.l1.go = "exit";
								break;

								case 3:
									dialog.text = "Je dois me plaindre, capitaine : on veut tous retourner en mer. Ce service à terre nous reste en travers de la gorge !";
									link.l1 = "J'en ai assez de ces jérémiades ! Vous avez assez de gnכle à terre ! Servez là oם le capitaine vous l'ordonne ! Sinon, il faudra en pendre un pour l'exemple.";
									link.l1.go = "exit";
								break;

								case 4:
									dialog.text = "Je vais vous confier un secret, capitaine : le nouveau gouverneur est un concussionnaire et un voleur. Mais bien sמr, ce ne sont pas mes affaires...";
									link.l1 = "Tu as raison, corsaire : ton travail, c'est de monter la garde et de maintenir l'ordre. Quant à pendre le gouverneur à une vergue, c'est mon affaire. Bien joué !";
									link.l1.go = "exit";
								break;

								case 5:
									dialog.text = "Merci de ne pas nous oublier, capitaine ! On vous suivra dans le feu et dans l'eau !";
									link.l1 = "Je vous connais, bande de canailles ! Vous n'aimez que l'or. Ce soir, on fait la fête à la taverne, c'est ma tournée. N'oubliez pas de passer.";
									link.l1.go = "exit";
								break;

								case 6:
									dialog.text = "Eh, capitaine ! Des gardiens de l'ordre, nous, des corsaires ?! דa fait longtemps qu'on n'a pas eu une vraie affaire !";
									link.l1 = "Ne te relâche pas, corsaire ! Des armadas ennemies rכdent autour de nos îles, un bain de sang peut éclater à tout moment.";
									link.l1.go = "exit";
								break;

								case 7:
									dialog.text = "Capitaine, on dit que les autorités royales envoient encore une escadre par ici ?";
									link.l1 = "Bien sמr, corsaire. Tant que nous serons en vie, il n'y aura jamais de paix. Même en enfer, il faudra se battre contre les diables !";
									link.l1.go = "exit";
								break;

								case 8:
									dialog.text = "Yo-ho-ho ! Quelle fête on a faite hier, capitaine ! Dommage que vous n'ayez pas été là.";
									link.l1 = "Peu importe, je me rattraperai. Et je ne vous envie pas, les gars.";
									link.l1.go = "exit";
								break;

								case 9:
									dialog.text = "Je vais vous confier un secret, capitaine, puisque vous ne nous avez jamais fait de tort : hier, avec les gars, on a fait la fête avec une poulette ici...";
									link.l1 = "Eh, corsaire, la corde te réclame !";
									link.l1.go = "exit";
								break;

								case 10:
									dialog.text = "Capitaine ! Libérez-moi de ce maudit service ! Je ne peux pas jouer les gardiens de la loi ici !";
									link.l1 = "Rappelle-toi plutכt que ce n'est pas facile non plus de prendre le quart de nuit sur un navire. Le service, mon frère, c'est le service partout.";
									link.l1.go = "exit";
								break;
							}
							link.l2 = RandPhraseSimple("J'ai une affaire importante !", "J'ai une affaire pour vous.");
							link.l2.go = "quests";//(перессылка в файл города)
							break;
						}
					}
					switch (rand(10))
					{
						case 0: ////////////////////////////////////////
							dialog.text = "Vous ne voyez pas que je suis de service ? Ne me dérangez pas.";
							link.l1 = "Bon, bon...";
							link.l1.go = "exit";
						break;

						case 1:
							dialog.text = "Vous voulez me signaler quelque chose de suspect ?";
							link.l1 = "Non, rien de tel ; d'ailleurs, je suis capitaine. Je vois que vous n'écoutez plus ? Au revoir.";
							link.l1.go = "exit";
						break;

						case 2: ///////////////////////////////////////////
							dialog.text = "N'oubliez pas qu'il s'agit d'une installation militaire ! Alors, du calme ici.";
							link.l1 = "D'accord, j'en tiendrai compte.";
							link.l1.go = "exit";
						break;

						case 3:
							dialog.text = "Quel temps, et moi, je dois rester planté là. Eh, en ville au moins il y a des filles, mais ici il n'y a que des rats de garnison...";
							link.l1 = ""+ GetSexPhrase("Désolé. Mais je ne peux rien pour toi, c'est ton travail.", "Hé ! Je ne suis pas une fille, moi ?") +"";
							link.l1.go = "exit";
						break;

						case 4: ///////////////////////////////////////////
							dialog.text = "Si vous voulez bavarder, trouvez quelqu'un d'autre ; moi, je dois maintenir l'ordre, et je n'ai pas le temps de jacasser avec vous.";
							link.l1 = "Non, je voulais juste "+ GetSexPhrase("vérifier", "vérifier") +" si vous étiez encore en vie, vous êtes planté là comme une statue.";
							link.l1.go = "exit";
						break;

						case 5: ////////////////////////////////////////////
							dialog.text = "Vous croyez que la vie de garnison, c'est un jeu ? Pas du tout ! C'est un travail très exigeant et dangereux. Je me souviens...";
							link.l1 = "Vous me raconterez ça une autre fois, je suis pressé.";
							link.l1.go = "exit";
						break;

						case 6: ////////////////////////////////////////////
							dialog.text = "Faites attention ici, c'est un fort ! Du calme...";
							link.l1 = "Comme vous voudrez, soldat.";
							link.l1.go = "exit";
						break;

						case 7:
							dialog.text = "Hé ! Vous n'auriez pas de l'eau ? Je meurs de soif.";
							link.l1 = "Non, l'ami, patience...";
							link.l1.go = "exit";
						break;

						case 8://///////////////////////////////////////////
							dialog.text = ""+ GetSexPhrase("Oh, quel ennui dans cette garnison, il n'y a que des rustres comme vous autour ! Alors que la garnison de la ville s'engraisse...", "Hé, la belle ! Que diriez-vous d'un petit flirt avec un brave soldat ?") +"";
							link.l1 = ""+ GetSexPhrase("Et ça s'appelle « servir » ? Attention, tu vas laisser passer un espion !", "Ton travail, c'est de maintenir l'ordre... et de ravaler ta bave.") +"";
							link.l1.go = "exit";
						break;

						case 9://///////////////////////////////////////////
							dialog.text = ""+ GetSexPhrase("Vous avez l'air d'un dur à cuire ! Vous voulez rejoindre la garnison du fort ? Nous avons une caserne spacieuse, deux repas par jour, et à boire gratuitement.", "Oh, vous ne pouvez pas imaginer, ma belle, comme c'est agréable de rencontrer une personne aussi charmante que vous dans ce trou perdu !") +"";
							link.l1 = ""+ GetSexPhrase("C'est diablement tentant, mais je dois refuser. L'exercice de caserne, ce n'est pas pour moi.", "Merci du compliment, soldat, ça me fait très plaisir.") +".";
							link.l1.go = "exit";
						break;

						case 10:
							dialog.text = "Cette chaleur... Je donnerais la moitié de ma vie pour retourner en Europe.";
							link.l1 = "Oui, je vois que le climat d'ici ne vous réussit pas.";
							link.l1.go = "exit";
						break;
					}
					link.l3 = "Oh... je vois. Je voulais vous demander...";
					link.l3.go = "quests";//(перессылка в файл города)
				}
			}
		break;
		//============================== ноды на разборки при распознавании =========================
		case "PegYou":
			if (IsCharacterPerkOn(pchar, "Adventurer") || IsCharacterPerkOn(pchar, "Agent"))
			{
				dialog.text = RandPhraseSimple("J'ai l'impression que c'est une supercherie... Allons voir le commandant, "+ GetSexPhrase("mon cher", "ma chère") +", nous tirerons ça au clair là-bas...", "Hum, quelque chose me dit que vous n'êtes pas "+ GetSexPhrase("celui", "celle") +" que vous prétendez être... Rendez immédiatement votre arme, " + GetAddress_Form(npchar) + ", et suivez-moi pour la suite de la procédure !");
				link.l1 = RandPhraseSimple("Pourquoi ne me croyez-vous pas ?", "Pourquoi de telles conclusions ?");
				switch (rand(1))
				{
					case 0: link.l1.go = "NotPegYou"; break;
					else link.l1.go = "PegYou_2"; break;
				}
			}
			else
			{
				dialog.text = RandPhraseSimple("J'ai l'impression que c'est une supercherie... Allons au bureau du commandant, "+ GetSexPhrase("mon cher", "ma chère") +", nous tirerons ça au clair là-bas...", "Hum, quelque chose me dit que vous n'êtes pas "+ GetSexPhrase("celui", "celle") +" que vous prétendez être... Rendez immédiatement votre arme, " + GetAddress_Form(npchar) + ", et suivez-moi pour la suite de la procédure !");
				link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
				link.l1.go = "fight";

			}
			if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
			{
				AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
				pchar.questTemp.stels.landSolder = GetDataDay();
			}
		break;
		case "PegYou_2":
		dialog.text = RandPhraseSimple("Ne me racontez pas d'histoires ! Rendez vos armes !", "Bon, c'est un espion, aucun doute... Rendez-vous immédiatement !");
		link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
		link.l1.go = "fight";
		if (sti(pchar.questTemp.stels.landSolder) != GetDataDay())
		{
			AddCharacterExpToSkill(pchar, SKILL_SNEAK, 40);
			pchar.questTemp.stels.landSolder = GetDataDay();
		}
		break;
		case "NotPegYou":
			dialog.text = RandPhraseSimple("Ah, je vois... C'est bon, vous pouvez passer, " + GetAddress_Form(pchar) + ".", "Je suis un peu fatigué par la garde... C'est bon, " + GetAddress_Form(pchar) + ", excusez-moi.");
			link.l1 = "Voilà !";
			link.l1.go = "exit";
			if (!CheckAttribute(pchar, "questTemp.stels.landFort") || sti(pchar.questTemp.stels.landFort) != GetDataDay())
			{
				AddCharacterExpToSkill(pchar, SKILL_SNEAK, 80);
				pchar.questTemp.stels.landFort = GetDataDay();
			}
		break;
		case "LicenceOk":
			iTemp = GetDaysContinueNationLicence(sti(npchar.nation));
			if (iTemp == -1)
			{
				dialog.text = "Votre licence doit être retirée, car elle a expiré et n'est donc plus valable. Rendez vos armes et suivez-moi pour la suite de la procédure !";
				link.l1 = RandPhraseSimple("Tu parles !", "א la saint-glinglin...");
				link.l1.go = "fight";
				TakeNationLicence(sti(npchar.nation));
				AddCharacterExpToSkill(pchar, SKILL_SNEAK, 20); // враг, которого узнали - потом будет умнее - бонус в скрытность
			}
			if (iTemp == 0)
			{
				dialog.text = "Hum, c'est en règle. Permettez-moi toutefois de vous signaler que votre licence expire aujourd'hui. Je vous laisse passer pour cette fois, mais il vous faudra en obtenir une nouvelle.";
				link.l1 = "Merci, je m'en occuperai à la première occasion.";
				link.l1.go = "exit";
			}
			if (iTemp > 0 && iTemp <= 10)
			{
				dialog.text = "Hum, c'est en règle. Permettez-moi toutefois de vous signaler que votre licence expire bientכt : elle n'est plus valable que " + FindRussianDaysString(iTemp) + ". Alors gardez-le à l'esprit, " + GetAddress_Form(npchar) + ".";
				link.l1 = "Merci, j'en prendrai une nouvelle à la première occasion.";
				link.l1.go = "exit";
			}
			if (iTemp > 10)
			{
				dialog.text = LinkRandPhrase("Bien, très bien, votre licence est encore valable " + FindRussianDaysString(iTemp) + ". Vous pouvez passer.", "Tout est en ordre, "+GetAddress_Form(npchar)+". Vous pouvez entrer librement en ville, votre licence est encore valable " + FindRussianDaysString(iTemp) + ". Désolé de vous avoir dérangé.", "Tout va bien, " + GetAddress_Form(npchar) + ", je ne vous retiens pas.");
				link.l1 = RandPhraseSimple("Parfait. Bonne journée.", "Merci, officier.");
				link.l1.go = "exit";
			}
		break;

		//замечение по обнажённому оружию
		case "SoldierNotBlade":
			dialog.text = LinkRandPhrase("Pourquoi diable courez-vous en ville l'arme au clair ? Rangez votre arme immédiatement !", "Je vous ordonne de rengainer votre arme immédiatement !", "Hé, "+ GetSexPhrase("l'ami", "ma petite") +" Arrêtez d'effrayer les gens ! Rengainez votre arme.");
			link.l1 = LinkRandPhrase("D'accord.", "D'accord.", "Comme vous voudrez...");
			link.l1.go = "exit";
			link.l2 = LinkRandPhrase("Au diable tout ça !", "Tu rêves...", "א la saint-glinglin.");
			link.l2.go = "fight";
			npchar.greeting = "soldier_common";
			NextDiag.TempNode = "First Time";
		break;
	}
}
