// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
 	switch(Dialog.CurrentNode)
	{
        case "quests":
            // Gregg: The Black Orchid, chapter 8 - asking after Esperanto at the Charlestown prison
            if (NPChar.City == "Charles")
            {
                if (CheckAttribute(PChar, "RaulEsperanto"))
                {
                    if (PChar.RaulEsperanto == "1")
                    {
                        link.l30 = "Je cherche un homme qu'on vous a amené il y a une trentaine d'années. Raul Esperanto, un Espagnol.";
                        link.l30.go = "BO_RE_Prison_1";
                    }
                }
            }
            dialog.text = "Parlez, je vous écoute.";
			link.l1 = "Je "+ GetSexPhrase("me suis trompé", "me suis trompée") +". Adieu.";
			link.l1.go = "Exit";
		break;
        case "BO_RE_Prison_1":
            dialog.text = "Trente ans. ...(ricane)... Mes registres remontent à dix ans, le reste a brמlé. Mais un Espagnol nommé Esperanto, je m'en souviendrais : nous n'en gardons pas ici.";
            link.l1 = "Il n'y a donc aucune trace ?";
            link.l1.go = "BO_RE_Prison_2";
        break;

        case "BO_RE_Prison_2":
            dialog.text = "Aucune. Et ce n'est pas à moi qu'il faut demander. ...(baisse la voix)... Une fois par mois, il y a un vieil homme dans notre cave. Il était détenu ici du temps de mon prédécesseur, et rien n'a changé depuis, sauf qu'il est mort.";
            link.l1 = "Un fantכme ?";
            link.l1.go = "BO_RE_Prison_3";
        break;

        case "BO_RE_Prison_3":
            dialog.text = "Appelez ça comme vous voudrez. Il s'appelait Joe Newman. Il se souvient de tous ceux qui ont été détenus ici et, contrairement à moi, il n'a rien oublié. Seulement, personne ne descend le voir : il a tué quatre hommes.";
            link.l1 = "Je descendrai.";
            link.l1.go = "BO_RE_Prison_4";
        break;

        case "BO_RE_Prison_4":
            dialog.text = "C'est votre affaire, capitaine. Son jour vient une fois par mois, et vous le reconnaîtrez quand il viendra : ce jour-là, personne ici ne descend, même pas pour chercher du vin.";
            link.l1 = "J'attendrai ce jour.";
            link.l1.go = "exit";
            AddDialogExitQuestFunction("RaulEsperantoNewmanTime");
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
