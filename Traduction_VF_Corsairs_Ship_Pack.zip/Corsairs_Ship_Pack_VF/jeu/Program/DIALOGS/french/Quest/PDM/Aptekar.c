
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	int Bonus = sti(pchar.rank);
	if (Bonus <= 6) Bonus = 1;
	if (Bonus >= 7 && Bonus <= 12) Bonus = 1.2;
	if (Bonus >= 13) Bonus = 1.5;
	int Plata1 = 3000 + 200 * sti(pchar.rank) * Bonus;
	int Plata2 = 15000 + 500 * sti(pchar.rank) * Bonus;
	pchar.PDM_Apt_Plata1.Money = 3000 + 200 * sti(pchar.rank) * Bonus;
	pchar.PDM_Apt_Plata2.Money = 15000 + 500 * sti(pchar.rank) * Bonus;

	int i, iOfficer;
	string attrL, offtype;
	ref chref;

	attrL = Dialog.CurrentNode;

	if(HasSubStr(attrL, "OfficerConfusedSel_"))
	{
		i = findsubstr(attrL, "_" , 0);
		NPChar.OfficerToHealConfuse = GetPassenger(PChar, sti(strcut(attrL, i+1, strlen(attrL)-1))); // индех в конце
		Dialog.CurrentNode = "OfficerConfused";
	}

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Salutations, je suis docteur en alchimie et en médecine. Je m'appelle Alumnus. Et vous, comment vous appelez-vous, "+ GetSexPhrase("jeune homme", "ma fille") +" ?";
			link.l1 = "Vous pouvez m'appeler "+pchar.name+".";
			link.l1.go = "Alumnus_PervoeZadanie_1";
		break;
		
		case "Alumnus_PervoeZadanie_1":
			dialog.text = "Vous tombez bien, "+pchar.name+" ! וcoutez, pourriez-vous me rendre un petit service ? Je ne peux pas m'absenter longtemps...";
			link.l1 = "Que dois-je faire ?";
			link.l1.go = "Alumnus_PervoeZadanie_2";
		break;
		
		case "Alumnus_PervoeZadanie_2":
			dialog.text = "L'un de mes patients est alité ici, à Marigot, il s'appelle Budevin. Il faut lui apporter son médicament, et il paiera lui-même la livraison.";
			link.l1 = "דa n'a pas l'air compliqué. Je vais lui apporter le médicament.";
			link.l1.go = "Alumnus_PervoeZadanie_3";
			link.l2 = "Docteur Alumnus, engagez-vous un coursier, j'ai des affaires plus sérieuses à régler.";
			link.l2.go = "Alumnus_PervoeZadanie_Net";
		break;
		
		case "Alumnus_PervoeZadanie_3":
			dialog.text = "Oh, je savais que vous ne refuseriez pas, "+pchar.name+", merci ! Pour trouver sa maison, il faut monter vers le haut de la ville, elle se trouve près de la sortie vers la jungle. Tenez, prenez le médicament. Revenez me voir, je vous trouverai du travail.";
			link.l1 = "Je repasserai sans faute. Au revoir !";
			link.l1.go = "Alumnus_PervoeZadanie_4";
			NextDiag.TempNode = "Alumnus_PervoeZadanie_3_EsheRaz";
		break;
		
		case "Alumnus_PervoeZadanie_3_EsheRaz":
			dialog.text = "Vous avez apporté le médicament à Budevin ?";
			link.l1 = "Pas encore, mais je serai bientכt chez lui.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_PervoeZadanie_3_EsheRaz";
		break;
		
		case "Alumnus_PervoeZadanie_4":
			DialogExit();
			NextDiag.CurrentNode = NextDiag.TempNode;
			SetQuestHeader("PDM_Aptekar");
			AddQuestRecord("PDM_Aptekar", "1");
			GiveItem2Character(PChar, "PDM_Heal_Poroshok");
			
			sld = GetCharacter(NPC_GenerateCharacter("PDM_Markus", "prison_3", "man", "man", 10, HOLLAND, -1, false));
			sld.name	= "Budevin";
			sld.lastname	= "";
			sld.Dialog.Filename = "Quest\PDM\Aptekar.c";
			sld.dialog.currentnode   = "Markus_1";
			LAi_SetGroundSitType(sld);
			LAi_SetImmortal(sld, true);
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			ChangeCharacterAddressGroup(sld, "Smallhome_K2", "quest", "quest1");
		break;
		
		case "Alumnus_PervoeZadanie_Net":
			dialog.text = "Je suis navré, "+pchar.name+". Je suis occupé en ce moment, je ne peux donc pas vous examiner.";
			link.l1 = "Bon, alors, je m'en vais.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_Obijen";
		break;
		
		case "Alumnus_Obijen":
			dialog.text = "Bonjour, "+pchar.name+". Comment puis-je vous aider ?";
			link.l1 = "Je passais juste.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_Obijen";
		break;
		
		case "Markus_1":
			dialog.text = "(tousse)... Oui, que vouliez-vous ?";
			link.l1 = "Je viens de la part du docteur Alumnus, il m'a demandé de vous remettre ce médicament.";
			link.l1.go = "Markus_2";
			locCameraFromToPos(1.00, 2.00, 0.00, false, -4.00, -1.20, -4.00);
		break;
		
		case "Markus_2":
			dialog.text = "Oh, "+GetAddress_Form(NPChar)+"Vous tombez à pic, cette douleur est insupportable... Des bandits m'ont attaqué la nuit dernière. Ils m'ont pris tout ce que j'avais de valeur, mais Dieu merci, je suis resté en vie. Les gardes les cherchent encore, mais j'espère que les scélérats auront ce qu'ils méritent.";
			link.l1 = "Oui, il vous est arrivé une fâcheuse histoire. Le docteur Alumnus a dit que vous paieriez la livraison.";
			link.l1.go = "Markus_3";
			TakeItemFromCharacter(pchar, "PDM_Heal_Poroshok");
		break;
		
		case "Markus_3":
			dialog.text = "Ah oui, bien sמr. Tenez, "+Plata1+" piastres, elles sont à vous. J'aimerais bien dormir, maintenant...";
			link.l1 = "Rétablissez-vous, mynheer, je vous laisse.";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, sti(Plata1));
			AddCharacterExpToSkill(pchar, "Leadership", 60);
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
			AddQuestRecord("PDM_Aptekar", "2");
			AddQuestUserData("PDM_Aptekar", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("PDM_Aptekar", "sSex2", GetSexPhrase("", "e"));
			
			sld = CharacterFromID("Doktor_Alumnus");
			sld.dialog.filename   = "Quest\PDM\Aptekar.c";
			sld.dialog.currentnode   = "Alumnus_VtoroeZadanie";
		break;

		case "Alumnus_VtoroeZadanie":
			dialog.text = "Ah, c'est vous, "+ GetSexPhrase("mon jeune et impatient capitaine", "ma jeune et impatiente amie") +" ! Que voulez-vous de moi ?";
			link.l1 = "Je voulais savoir si vous aviez besoin d'aide.";
			link.l1.go = "Alumnus_VtoroeZadanie_2";
		break;

		case "Alumnus_VtoroeZadanie_2":
			dialog.text = "Oui, en effet, j'ai besoin d'aide en ce moment. Il me faut une petite quantité d'une herbe rare qui pousse sur les îles des Caraïbes. Je ne peux pas préparer mes miraculeuses décoctions curatives sans elle. Si vous pouviez me procurer cette herbe, je pourrais vous soigner, vous et vos officiers, de toutes les blessures et maladies. J'ai acheté un jour un peu de cette herbe à un Indien... Comment s'appelait-il déjà ? Ah oui, Tuantuh.";
			link.l1 = "Parlez-moi de ce Tuantuh.";
			link.l1.go = "Alumnus_VtoroeZadanie_3";
		break;

		case "Alumnus_VtoroeZadanie_3":
			dialog.text = "Il est assez étrange... Même les gens de sa tribu l'évitent. Il navigue d'une île à l'autre sur son embarcation, récoltant diverses herbes rares et remèdes, puis il les vend aux médecins, aux apothicaires et aux sages-femmes. Mais il me semble que c'est un homme intelligent, malgré ses manies : il m'a donné quelques conseils très utiles sur les maladies locales et la psychologie des Indiens. Il vit à l'écart des gens, et on l'a vu pour la dernière fois quelque part aux Bahamas. Comme il a une embarcation, il vit près de la mer, sur les rochers.";
			link.l1 = "Je vous rapporterai cette herbe. Comment s'appelle-t-elle ?";
			link.l1.go = "Alumnus_VtoroeZadanie_4";
		break;

		case "Alumnus_VtoroeZadanie_4":
			dialog.text = "Ah. C'est là qu'il y a un petit problème. Je ne me souviens plus de son nom exact. Je suis sמr que Tuantuh me l'a donné quand il me l'a vendue, mais j'ai tout simplement oublié ce nom, il sonne extrêmement bizarrement à une oreille européenne, vous savez.";
			link.l1 = "Et comment dois-je chercher cette herbe si je ne sais pas comment elle s'appelle ?";
			link.l1.go = "Alumnus_VtoroeZadanie_5";
		break;

		case "Alumnus_VtoroeZadanie_5":
			dialog.text = "Eh bien, je vais vous dire comment reconnaître cette herbe. Son odeur rappelle à la fois la cannelle et l'anis. Un mélange plutכt odorant, je dois dire. Je pense que c'est dמ à l'influence de Neptune et d'Europe sur le processus de maturation de cette herbe. Hindenburg a écrit tout un ouvrage sur l'influence des planètes extérieures sur la maturation des herbes pendant l'équinoxe de printemps. Cependant, je m'égare.";
			link.l1 = "Oui, vous vous égarez. Merci pour la leçon. Je vais essayer de vous trouver cette herbe. א plus tard.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_VtoroeZadanie_6";

			sld = GetCharacter(NPC_GenerateCharacter("Pablo_Loco", "indsar1", "man", "man", 10, PIRATE, -1, false));
			sld.name = "Tuantuh";
			sld.lastname = "";
			sld.greeting = "GR_Pablo_Loco";
			LAi_group_MoveCharacter(sld, "PIRATE_CITIZENS");
			LAi_SetStayType(sld);
			sld.dialog.filename   = "Quest\PDM\Aptekar.c";
			sld.dialog.currentnode   = "Pablo_Loco_FT";
			ChangeCharacterAddressGroup(sld, "Shore68", "quest", "quest18");

			AddQuestRecord("PDM_Aptekar", "3");
			AddQuestUserData("PDM_Aptekar", "sSex", GetSexPhrase("", "e"));
		break;

		case "Alumnus_VtoroeZadanie_6":
			dialog.text = "Bon retour ! Avez-vous réussi à trouver la plante qu'il me faut ?";
			link.l1 = "Pas encore, docteur. Je poursuis mes recherches.";
			link.l1.go = "exit";
			link.l2 = "Docteur, rappelez-moi comment reconnaître cette herbe.";
			link.l2.go = "Alumnus_Novoe_Kak_Opoznat";
			NextDiag.TempNode = "Alumnus_VtoroeZadanie_6";
		break;

		case "Alumnus_Novoe_Kak_Opoznat":
			dialog.text = "Souvenez-vous : cette herbe rare pousse sur les îles des Caraïbes, son odeur rappelle à la fois la cannelle et l'anis. Je pense que c'est dמ à l'influence de Neptune et d'Europe sur le processus de maturation de cette herbe. Hindenburg a écrit tout un ouvrage sur l'influence des planètes extérieures sur la maturation des herbes pendant l'équinoxe de printemps...";
			link.l1 = "Bien, docteur, ça suffit, je file.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_VtoroeZadanie_6";
		break;

		case "Pablo_Loco_FT":
			dialog.text = "Ah ! Toi désirer l'or, n'est-ce pas ? Toi désirer beaucoup d'or. Aveugle"+ GetSexPhrase(" et fou", " et folle") +" ! Toi vraiment pas te soucier de l'état de ton âme ?";
			link.l1 = "De quoi parles-tu ? Qui es-tu ?";
			link.l1.go = "Pablo_Loco_1";
			NextDiag.TempNode = "Pablo_Loco_ER_1";
		break;

		case "Pablo_Loco_ER_1":
			dialog.text = "Toi vouloir jeter ta cupidité à la mer ?";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "Pablo_Loco_ER_2";
		break;

		case "Pablo_Loco_ER_2":
			dialog.text = "La cupidité rend ton cœur aussi lourd que l'or lui-même. Ton devoir, c'est de la jeter à la mer pour te purifier.";
			link.l1 = "Raconte-moi ton histoire.";
			link.l1.go = "Pablo_Loco_2";
		break;

		case "Pablo_Loco_1":
			dialog.text = "Moi être Tuantuh. Celui dont les oreilles aspirent au chant des oiseaux et aux voix de ses frères, mais n'entendent que des cris et des hurlements. Celui dont le nez aspire au parfum des fleurs et de la mer salée, mais ne sent que l'âcre poudre noire.";
			link.l1 = "Tu es sans aucun doute un homme malheureux. Raconte-moi ton histoire.";
			link.l1.go = "Pablo_Loco_2";
			link.l2 = "Ton esprit est clairement parti se promener, et moi, j'ai des affaires urgentes partout. Adieu.";
			link.l2.go = "exit";
		break;

		case "Pablo_Loco_2":
			dialog.text = "Moi vivre à Inachetla. Moi être trouvé dans un canot qui dérivait sur l'océan, petit enfant vivant au milieu de nombreux morts. Moi grandir fort. Moi sentir l'esprit de cette île, et moi sentir l'esprit de la mer. Mes frères pêchaient en mer dans de petits canots. Ils tiraient la vie de la mer. Mais ensuite, la mer leur apporte la mort.";
			link.l1 = "Que voulez-vous dire ?";
			link.l1.go = "Pablo_Loco_3";
		break;

		case "Pablo_Loco_3":
			dialog.text = "Un jour, mes frères virent d'énormes navires en mer. Ils n'avaient jamais vu de si grands navires, et ils crurent que c'étaient d'immenses oiseaux ailés envoyés par les dieux. Ils se dirigèrent vers ces navires en criant et en agitant leurs lances en un joyeux salut. Mais ce n'étaient pas les navires des dieux. C'étaient les navires des hommes blancs. Les Visages pâles avoir peur de mes frères et croire qu'on les attaque. Alors ils tuèrent mes frères, puis ils allèrent dans mon village et tuèrent tous ceux qui s'y trouvaient, tous sauf moi, qui étais de nouveau vivant au milieu des morts. Alors maintenant, moi être le seul qui reste à sentir l'esprit de l'île et de la mer. Voilà mon histoire.";
			link.l1 = "Je compatis à ta perte... Euh, c'est toi, Tuantuh, l'herboriste ?";
			link.l1.go = "Pablo_Loco_Trava";
		break;

		case "Pablo_Loco_Trava":
			dialog.text = "Oui, c'est moi. Moi sentir l'esprit de la nature : l'appel de la mer, le murmure des graines, le rire des fleurs. Tuantuh : voilà qui je suis.";
			link.l1 = "En effet. Le « rire des fleurs », hein ? C'est, euh, très intéressant. Bon, Tuantuh, j'ai besoin d'une herbe qui sent...";
			link.l1.go = "Pablo_Loco_5";
		break;

		case "Pablo_Loco_5":
			dialog.text = "Que sentir cette herbe ?";
			Link.l1.edit = 1;
			Link.l1 = "";
			link.l1.go = "Pablo_Loco_Pravilno";
			NextDiag.TempNode = "Pablo_Loco_5";
		break;

		case "Pablo_Loco_Pravilno":
			string answer = GetStrSmallRegister(dialogEditStrings[1])
			if (HasSubStr(answer, "cannelle") && HasSubStr(answer, "anis"))
			{
Dialog.text = "Elle sentir la cannelle et l'anis ? Moi connaître cette sorte d'herbe. Elle peut guérir, ou elle peut tuer. Dis-moi, pourquoi toi avoir besoin de cette herbe ?";
				Link.l1 = "C'est pour le docteur Alumnus.";
				Link.l1.go = "Pablo_Loco_6";
				break;
			}
			else
			{
Dialog.text = "Moi pas connaître d'herbes avec cette odeur.";
				{
					Link.l1 = "Je vais réessayer tout de suite.";
					Link.l1.go = "Pablo_Loco_5";
				}
				link.l2 = "Je dois y réfléchir.";
				link.l2.go = "exit";
			}
		break;

		case "Pablo_Loco_6":
			dialog.text = "Alors, Alumnus, tu dis ? Moi savoir de cet homme qu'il être un sage fou. Il être dangereux de donner le tzescatlat umtat aux mains d'un « homme de savoir ». Mais moi savoir qu'il ne se servira pas de l'herbe pour tuer quelqu'un exprès : ce n'est pas ce genre d'homme. Très bien. Pour trouver cette herbe, moi avoir besoin d'un canot, car moi devoir naviguer jusqu'à l'endroit oם elle pousse. Les herbes ne poussent pas toutes au même endroit, homme blanc.";
			link.l1 = "Je t'en achèterai un.";
			link.l1.go = "Pablo_Loco_7";
		break;

		case "Pablo_Loco_7":
			dialog.text = "Non, non ! Toi pas pouvoir « acheter » un canot ! La contagion de l'or gâter l'esprit du canot ! Toi devoir construire un canot de tes propres mains et de ton propre cœur, et ne pas l'infecter avec le poison de l'or !";
			link.l1 = "Tu es quelqu'un de difficile, Tuantuh, tu le sais ? Bon, d'accord : que dois-je faire pour t'aider à construire un canot ?";
			link.l1.go = "Pablo_Loco_8";
		break;

		case "Pablo_Loco_8":
			dialog.text = "Moi avoir besoin d'un arbre spécial. Cet arbre s'appelle teshkatali. Si tu veux que moi trouver ton herbe, tu dois m'apporter l'arbre teshkatali. Il pousse sur le continent, dans la jungle, près de la lagune de Caratasca.";
			link.l1 = "L'arbre teshkatali ? Je comprends et je n'oublierai pas. Adieu, Tuantuh. Je reviendrai.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pablo_Loco_9";

			PChar.quest.PDM_Apt_Prihov_v_buhtu.win_condition.l1 = "location";
			PChar.quest.PDM_Apt_Prihov_v_buhtu.win_condition.l1.location = "Shore10";
			PChar.quest.PDM_Apt_Prihov_v_buhtu.win_condition = "PDM_Apt_Prihov_v_buhtu";

			AddQuestRecord("PDM_Aptekar", "4");
		break;

		case "Pablo_Loco_9":
			dialog.text = "Pourquoi toi me déranger ? La seule chose dont moi avoir besoin de toi, c'est l'arbre teshkatali. Quand toi me l'apporter, moi me construire un nouveau canot. Et ensuite, toi recevoir le tzescatlat umtat. Moi n'avoir rien d'autre à dire.";
			link.l1 = "Je comprends. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pablo_Loco_9";
		break;

		case "Nashel_Derevo":
			dialog.text = "Encore toi ? Toi avoir apporté l'arbre teshkatali ?";
			link.l1 = "J'ai l'arbre qu'il te faut. Le voici. Maintenant, vas-y, construis ton canot pour pouvoir me rapporter mon tzeska... tla... la... moumat... ou je ne sais quel nom a cette maudite herbe.";
			link.l1.go = "Nashel_Derevo_2";
		break;

		case "Nashel_Derevo_2":
			TakeItemFromCharacter(pchar, "PDM_Derevo_Teshkali");
			dialog.text = "Revenir dans une semaine, moi avoir alors l'herbe qu'il te faut.";
			link.l1 = "Laisse-moi appeler mes marins : avec eux, tu construiras ce canot cinq fois plus vite.";
			link.l1.go = "Nashel_Derevo_3";
		break;

		case "Nashel_Derevo_3":
			dialog.text = "(il vous regarde d'un air furieux)";
			link.l1 = "Bon, bon, je ne te dérangerai pas. א dans une semaine.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pablo_Loco_Stroit_lodku";

			SetTimerCondition("PDM_Apt_Lodka_Postroena", 0, 0, 7, false);

			AddQuestRecord("PDM_Aptekar", "7");
		break;

		case "Pablo_Loco_Stroit_lodku":
			dialog.text = "Le canot peut-être pas encore prêt, revenir plus tard.";
			link.l1 = "D'accord, Tuantuh, fais comme tu peux.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Pablo_Loco_Stroit_lodku";
		break;

		case "Pablo_Loco_Lodka_Postroena":
			dialog.text = "Homme blanc, moi trouver ton herbe.";
			link.l1 = "Merci, Tuantuh. Toi pas t'inquiéter, cette herbe pas apporter la mort, mais servir la médecine. Moi dire adieu à toi.";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(npchar);
			npchar.lifeday = 0;

			AddCharacterExpToSkill(pchar, "Sailing", 150);
			AddCharacterExpToSkill(pchar, "Repair", 150);

			GiveItem2Character(PChar, "PDM_Trava_Tzes_Umrat");
			AddQuestRecord("PDM_Aptekar", "8");

			sld = CharacterFromID("Doktor_Alumnus");
			sld.dialog.filename   = "Quest\PDM\Aptekar.c";
			sld.dialog.currentnode   = "Alumnus_Finish_Zadanie";
		break;

		case "Alumnus_Finish_Zadanie":
			dialog.text = "Vous voilà de retour. Formidable. M'avez-vous rapporté l'herbe que je vous ai demandée, "+ GetSexPhrase("mon jeune capitaine ", "madame ") +" ?";
			link.l1 = "Tzescatlat umtat ?";
			link.l1.go = "Alumnus_Finish_Zadanie_2";
		break;

		case "Alumnus_Finish_Zadanie_2":
			dialog.text = "Pardon, quoi ??";
			link.l1 = "La voici.";
			link.l1.go = "Alumnus_Finish_Zadanie_3";
		break;

		case "Alumnus_Finish_Zadanie_3":
			dialog.text = "Ah ! Vous l'avez apportée ! Quelle chance ! Je peux maintenant préparer mes propres décoctions médicinales, et aussi poursuivre une recherche inachevée !";
			link.l1 = "Dites-moi, docteur, si ce n'est pas un secret, à quoi vous sert cette herbe puante ?";
			link.l1.go = "A_pravda_ZACHEM???";
			TakeItemFromCharacter(pchar, "PDM_Trava_Tzes_Umrat");
		break;

		case "A_pravda_ZACHEM???":
			dialog.text = "Voyez-vous, "+ GetSexPhrase("mon jeune capitaine", "madame") +", je vais résoudre le plus grand mystère de la philosophie naturelle : le secret de l'immortalité ! Avec cette herbe, je compte créer une potion qui me permettra de vivre éternellement !";
			link.l1 = "Je vois. Bon, si après avoir avalé cette potion, vous découvrez soudain que les boulets rebondissent sur vous, faites-le-moi savoir.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Alumnus_Lechenie_s_voprosom";

			CloseQuestHeader("PDM_Aptekar");
			AddGoodDeed("PDM_Aptekar", 3); // Gregg: доброе дело
		break;

		case "Alumnus_Lechenie_s_voprosom":	//Для Грегга
			dialog.text = "... mais ici, l'élément du feu est représenté par l'arכme de la cannelle, dont la prédominance est équilibrée par l'odeur... Oh, capitaine, je ne m'étais pas aperçu de votre présence, que puis-je faire pour vous ?";
			link.l1 = "Bonjour, docteur Alumnus, je voudrais que vous examiniez mes officiers blessés.";
			link.l1.go = "CheckForConfuse";
			link.l2 = "Pourquoi votre porte est-elle fermée cכté rue ? Vous perdez des clients.";
			link.l2.go = "Alumnus_Lechenie_s_voprosom_2";
			link.l3 = "Je passais juste prendre de vos nouvelles. Au revoir.";
			link.l3.go = "exit";	//Для выхода
			if(CheckAttribute(PChar, "Luke.BadPoison"))
			{
				link.l4 = "Docteur, j'ai vraiment besoin de votre aide, j'ai été victime d'un poison très puissant !";
				link.l4.go = "LukePoison";
			}
		break;

		case "Alumnus_Lechenie_s_voprosom_2":
			dialog.text = "Voyez-vous, ma maison se trouve juste entre les docks et la taverne ; si je laisse la porte ouverte, des visiteurs de passage entrent sans cesse ici et essaient de renverser l'une de mes teintures. J'ai dמ ensuite ramener à la raison un de ces « invités » pendant toute une semaine, et je ne manque pas du tout de clients : tout le monde en ville connaît cette boutique, du gouverneur au débardeur.";
			link.l1 = "D'accord, je comprends. Pouvez-vous examiner mes officiers blessés ?";
			link.l1.go = "CheckForConfuse";
			link.l2 = "C'était très intéressant. Au revoir.";
			link.l2.go = "exit";

			NextDiag.TempNode = "Alumnus_Lechenie";
		break;

		case "Alumnus_Lechenie":
			dialog.text = "... mais ici, l'élément du feu est représenté par l'arכme de la cannelle, dont la prédominance est équilibrée par l'odeur... Oh, capitaine, je ne m'étais pas aperçu de votre présence, que puis-je faire pour vous ?";
			link.l1 = "Bonjour, docteur Alumnus, je voudrais faire examiner mes officiers blessés.";
			link.l1.go = "CheckForConfuse";
			link.l2 = "Je passais juste prendre de vos nouvelles. Au revoir.";
			link.l2.go = "exit";
			if(CheckAttribute(PChar, "Luke.BadPoison"))
			{
				link.l3 = "Docteur, j'ai vraiment besoin de votre aide, j'ai été victime d'un poison très puissant !";
				link.l3.go = "LukePoison";
			}
		break;

		case "CheckForConfuse":
			dialog.text = "Qui exactement a besoin de soins, capitaine ?";
			for(i=0; i<GetPassengersQuantity(pchar); i++)
			{
				iOfficer = GetPassenger(pchar, i);
				sld = GetCharacter(iOfficer);
				if (!GetRemovable(sld)) continue;
				if (!CheckAttribute(sld, "HPminusDaysNeedtoRestore")) continue;
				attrL = "l"+i;
				Link.(attrL)	= "L'officier " + GetFullName(sld) + ".";
				Link.(attrL).go = "OfficerConfusedSel_" + i;
			}
			Link.l99 = "Personne pour le moment.";
			Link.l99.go = "exit";
		break;

		case "OfficerConfused":
			chref = GetCharacter(sti(NPChar.OfficerToHealConfuse));

			if (!CheckAttribute(chref, "quest.officertype")) offtype = "Polyvalent";
			else offtype = XI_ConvertString(chref.quest.officertype);
			dialog.Text = "Vous voulez dire " + GetFullName(chref)+", spécialité : "+offtype+".";
			Link.l1 = "Oui, exactement.";
			Link.l1.go = "OfficerConfused_2";
			Link.l99 = "Non, j'ai changé d'avis.";
			Link.l99.go = "exit";
		break;

		case "OfficerConfused_2":
			chref = GetCharacter(sti(NPChar.OfficerToHealConfuse));
			if (CheckAttribute(chref, "chr_ai.max_hp")) npchar.HealPrice = (makeint(chref.chr_ai.max_hp)*100)+makeint((sti(chref.rank)*500)*(MOD_SKILL_ENEMY_RATE*3/2));
			else npchar.HealPrice = (makeint(chref.health.maxhp)*100)+makeint((sti(chref.rank)*500)*(MOD_SKILL_ENEMY_RATE*3/2));
			dialog.Text = "D'après mes prévisions, cet officier est à "+(sti(chref.HPminusDaysNeedtoRestore)-sti(chref.HPminusDays))+" jours d'une guérison naturelle complète... Je pourrais essayer d'accélérer le rétablissement, mais cela vous coמtera "+FindRussianMoneyString(sti(npchar.HealPrice));
			if (sti(pchar.money)>=sti(npchar.HealPrice))
			{
				Link.l1 = "D'accord, je peux payer.";
				Link.l1.go = "OfficerConfused_3";
			}
			Link.l99 = "Plutכt non, je suis encore un peu à court d'argent.";
			Link.l99.go = "exit";
		break;

		case "OfficerConfused_3":
			chref = GetCharacter(sti(NPChar.OfficerToHealConfuse));
			AddMoneyToCharacter(pchar,-sti(npchar.HealPrice));
			LAi_Fade("", "");
			WaitDate("",0,0,0, 0, 60);
			DeleteAttribute(chref, "HPminusDays");
			DeleteAttribute(chref, "HPminusDaysNeedtoRestore");
			DeleteAttribute(chref, "Doctored"); // как при естественном выздоровлении (time_events CheckOfficersHPMinus)
			// LEO: heavy trauma (chr_ai.HeavyTrauma, -30% skill) wasn't cleared anywhere for officers
			// (CheckTrauma only handled the main char, apothecary ignored it) - the healer cures it too:
			DeleteAttribute(chref, "chr_ai.HeavyTrauma");
			DeleteAttribute(chref, "chr_ai.Trauma");
			DeleteAttribute(chref, "chr_ai.TraumaQ");
			UnmarkCharacter(chref);
			ReturnAutoOfficers(); // вылеченный возвращается на свои прежние должности СРАЗУ (фикс: не возвращался)
			Log_Info("L'officier " + GetFullName(chref) + " a recouvré la santé.");
			dialog.Text = "J'ai réussi à guérir complètement " + GetFullName(chref) + ". Même si je dois avouer que ce fut très difficile... Est-ce tout, ou quelqu'un d'autre a-t-il besoin de mon aide ?";
			Link.l1 = "Non, il y en a encore qui ont besoin de soins.";
			Link.l1.go = "CheckForConfuse";
			Link.l99 = "C'est tout pour l'instant. Merci pour votre aide.";
			Link.l99.go = "exit";
		break;

		case "LukePoison":
			dialog.text = "Capitaine, laissez-moi vous examiner... Oui, ce poison a été fabriqué à partir d'herbes très rares et nocives ! Mais ne vous inquiétez pas, je sais comment le soigner. Et maintenant, "+pchar.name+", allongez-vous sur le lit, je vais bientכt m'occuper de vous.";
			link.l1 = "";
			link.l1.go = "exit";
			AddDialogExitQuest("HealingPoison");
		break;
		
		//обнаружение ГГ в сундуках
		case "Man_FackYou":
			dialog.text = LinkRandPhrase("Un vol en plein jour !!! Qu'est-ce qui se passe ?! Attendez un peu, "+ GetSexPhrase("l'ami","ma petite") +"...", "Hé, qu'est-ce que vous faites là ?! Pas question, vous avez décidé de me voler ? Eh bien, vous êtes fini...", "Attendez, oם allez-vous ? Vous êtes un voleur ! Eh bien, considérez que vous êtes cuit, ordure...");
			link.l1 = LinkRandPhrase("Diable !!", "Caramba !!", "Oh, bon sang !");
			link.l1.go = "fight_owner";
		break;
		case "fight_owner":
			LAi_SetOwnerTypeNoGroup(NPChar);
			LAi_group_Attack(NPChar, Pchar);
			if (rand(3) != 1) SetNationRelation2MainCharacter(sti(npchar.nation), RELATION_ENEMY);
			NextDiag.CurrentNode = "First time";
			DialogExit();
		break;
	}
}
