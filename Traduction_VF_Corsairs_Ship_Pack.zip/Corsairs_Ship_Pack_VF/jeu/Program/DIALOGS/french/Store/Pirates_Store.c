// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
	bool bOk;
	switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat("Demandez, que voulez-vous ?",
                          "Nous venons justement d'aborder ce sujet. Vous avez dמ oublier...", "C'est la troisième fois aujourd'hui que vous me parlez d'une affaire...",
                          "וcoutez, ici, c'est un magasin, les gens viennent y acheter. Ne me distrayez pas !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous savez, " + npchar.name + ", une autre fois.", "Exactement, "+ GetSexPhrase("oublié", "oublié") +" quelque chose...",
                      "Oui, c'est vraiment la troisième fois...", "Euh, je ne le ferai plus...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";

			if(CheckAttribute(pchar, "questTemp.BlueBird"))
			{
				if (pchar.questTemp.BlueBird == "toBermudes")
				{
					link.l1 = "Mon cher, je cherche un navire peu ordinaire, le chébec Oiseau bleu. En avez-vous entendu parler ? Je suis prêt à payer pour toute information à son sujet...";
					link.l1.go = "BlueBird_1";
				}
				bOk = pchar.questTemp.BlueBird == "weWon" || pchar.questTemp.BlueBird == "returnMoney" || pchar.questTemp.BlueBird == "over";
	    		if (bOk && !CheckAttribute(pchar, "questTemp.BlueBird.speakWon"))
    			{
		    		link.l1 = "Oם est Pascal Voisier ?";
	    			link.l1.go = "BlueBird_3";
    			}
			}
			if (bBettaTestMode)
			{
				link.l5 = "LOCATION D'ENTREPÔT";
				link.l5.go = "storage_rent1";
			}
		break;
		case "BlueBird_1":
			dialog.text = NPCStringReactionRepeat("Je ne sais rien de ce navire. Si c'est tout ce que vous vouliez, partez.",
				"Encore ? Je vous ai tout dit.",
				"Quoi, encore la même chose ?",
                "Mais quand est-ce que ça finira ?! Je vous en prie, ne me distrayez pas de mon travail !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Vous n'êtes pas très aimable, mon cher !",
				"Oui, oui, je m'en souviens...",
                "Ouais.",
				"D'accord, d'accord...", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("BlueBird_2", "exit", "exit", "exit", npchar, Dialog.CurrentNode);
		break;
		case "BlueBird_2":
			dialog.text = "Je ne suis pas votre cher, je n'ai pas eu le plaisir de siffler du rhum avec vous et de cuver sous une palissade.";
			link.l1 = "Fils de chienne... (à voix basse). Je demandais, c'est tout. Eh bien, merci !";
			link.l1.go = "exit";
			AddQuestRecord("Xebeca_BlueBird", "2");
			AddQuestUserData("Xebeca_BlueBird", "sSex", GetSexPhrase("", "e"));
		break;

		case "BlueBird_3":
			if ( sti(pchar.Ship.Type) == SHIP_NOTUSED || pchar.location.from_sea != "Pirates_town")
			{
				dialog.text = "Il a quitté l'île sans explication. On dit qu'il était mêlé à l'histoire du chébec « Oiseau bleu ».";
				link.l1 = "Je connais cette histoire.";
				link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Il a quitté l'île sans explication. On dit qu'il était mêlé à l'histoire du chébec « Oiseau bleu ». J'ai une offre alléchante pour vous. Elle pourrait vous intéresser.";
				link.l1 = "Vraiment ? Eh bien, exposez-moi votre offre alléchante.";
				link.l1.go = "storage_rent";
			}
			pchar.questTemp.BlueBird.speakWon = true;
		break;

		case "storage_rent":
			dialog.text = "Après les événements que vous savez, des locaux propres au stockage se sont libérés. Vous ne voudriez pas les louer pour une somme raisonnable ? Vous auriez votre propre entrepכt...";
			link.l1 = "Un entrepכt, dites-vous ? C'est tentant... Il est grand ? Et combien demandez-vous pour la location ?";
			link.l1.go = "storage_rent1";
		break;

		case "storage_rent1":
			NPChar.MoneyForStorage = GetStoragePriceExt(NPChar, pchar);
			dialog.text = "Il est assez spacieux, même pour un entrepכt portuaire : une capacité de 50000 quintaux. Pour " + FindRussianMoneyString(sti(NPChar.MoneyForStorage)) + " par mois, je suis prêt à assurer la sécurité de vos marchandises. "+
				"Cela comprend la garde, la protection contre les inondations et la chasse aux rongeurs. דa vous va ? Et je garantis la discrétion, bien entendu.";
			link.l1 = "Bien. Puis-je le visiter ?";
			link.l1.go = "storage_rent2";
			link.l2 = "C'est trop cher. Il doit y avoir de l'eau jusqu'aux genoux et des rats partout.";
			link.l2.go = "storage_rent3";
		break;

		case "storage_rent2":
			dialog.text = "Bien sמr, bien sמr. Seulement, euh... je vous demanderai de payer un mois d'avance.";
			if(sti(pchar.money) >= sti(NPChar.MoneyForStorage))
			{
				link.l1 = "Que vous êtes... intéressé. Prenez votre argent, je loue cette grange.";
				link.l1.go = "storage_11";
			}
			else
			{
				link.l1 = "Que vous êtes... intéressé. Je vais chercher l'argent.";
				link.l1.go = "exit";
			}
		break;

		case "storage_rent3":
			dialog.text = "Eh bien, comme vous voudrez. Si vous vous décidez, adressez-vous à nous. Sachez seulement qu'un tel trésor ne restera pas longtemps libre. Ne tardez pas trop.";
			link.l1 = "Ne vous inquiétez pas. Si besoin, je vous le demanderai.";
			link.l1.go = "exit";
		break;
	}
	UnloadSegment(NPChar.FileDialog2);
}

