// Gregg: Alehon Kendart - «Чёрная Орхидея», глава 7 «Маленький ублюдок».
// Логика - Program\Quests\reaction_functions\blackorchid.c.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			// Gregg: the clock is found - that is the only errand he is waiting on
			if (PChar.SmallMongrel == "17")
			{
				dialog.text = "Enfin. Qu'avez-vous apporté ?";
				link.l1 = "Ceci. Pris à bord du Petit Bâtard.";
				link.l1.go = "16";
			}
			else
			{
				dialog.text = "Je travaille. Repassez plus tard.";
				link.l1 = "Je ne vous dérangerai pas.";
				link.l1.go = "exit";
			}
			NextDiag.TempNode = "First time";
		break;

		case "1":
			dialog.text = "Ah, c'est vous. Bien. Asseyez-vous, ce sera long... et j'ai peur que ce ne soit pas agréable.";
			link.l1 = "Désagréable comment ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "En ce que je vais vous demander une chose qui pourrait vous tuer. Et je ne peux pas vous promettre que je comprendrais ce qui vous a tué.";
			link.l1 = "On a déjà essayé de me tuer. דa n'a pas encore marché.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "On. Il ne s'agit peut-être pas de gens. Depuis trente ans, je tiens que rien n'est inexplicable, seulement inexpliqué. C'est le premier cas oם je n'en suis pas certain.";
			link.l1 = "Venez-en au fait, Alejon.";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Au fait. Avez-vous entendu parler du Petit Bâtard ?";
			link.l1 = "Non. Un homme ou un navire ?";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Un navire. Une frégate lourde. Ce sont les Espagnols qui l'ont baptisée ainsi, et pas par affection. Il y a une quinzaine d'années, deux flמtes qui faisaient route de Maracaibo à Belize l'ont croisée au large de la baie d'Amatique. Vide, à la dérive, pas une âme à bord.";
			link.l1 = "Et ils l'ont prise comme prise, bien sמr.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Oui. Ils ont mis trente-deux hommes à bord comme équipage de prise et ont poursuivi leur route. Au matin, tout l'équipage était pendu aux vergues. Trente-deux corps. Personne n'avait rien entendu dans la nuit, et la mer était calme.";
			link.l1 = "Quelqu'un a bien dמ survivre pour le raconter.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Un marin. Il a atteint Belize, et c'est moi qui l'ai écouté. Il pouvait à peine parler, et quinze jours plus tard, il est mort, sans que le chirurgien puisse dire de quoi.";
			link.l1 = "Une seule histoire n'est qu'une seule histoire.";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "C'est exactement ce que je me suis dit à l'époque. Et puis, des années plus tard, un pirate du nom de Jacob m'a raconté la même chose. א une différence près : son équipage de prise n'avait pas été pendu, mais fusillé et entassé dans la cale.";
			link.l1 = "Et Jacob était le seul survivant.";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Le seul. Et l'Espagnol aussi était le seul. Vous voyez ce qui me déplaît ? Pas les morts. La mer a son lot de morts. Ce qui me déplaît, c'est qu'à chaque fois, il reste exactement un témoin pour raconter.";
			link.l1 = "Comme si quelqu'un voulait que l'histoire se répande.";
			link.l1.go = "10";
		break;

		case "10":
			dialog.text = "...(après un silence)... C'est la pensée que je m'étais interdite. Il vous a fallu une minute.";
			link.l1 = "Et oם est-il maintenant ?";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "Il y a un mois, on m'a dit que Jackman l'avait. וchouée près de la colonie pirate des Bermudes, avec quatre hommes pour la garder. Jackman est près de ses sous, mais ce n'est pas un imbécile, et il ne la garderait pas pour rien.";
			link.l1 = "Alors il faut l'acheter.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "L'acheter et la fouiller. Entièrement : la cale, les cabines, le bordage. Si vous ne trouvez rien, remorquez-la jusqu'à San Juan, et nous la démonterons planche par planche. Seulement, ne dormez pas à bord, je vous en supplie, et n'y laissez aucun de vos hommes.";
			link.l1 = "Je ne le ferai pas.";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Et encore une chose. Si quelque chose tourne mal, larguez-la et partez. Je trouverai un autre moyen. Je ne trouverai pas un autre vous.";
			link.l1 = "Bien sentimental, pour un homme de science.";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "...(sèchement)... Ce n'est pas du sentiment, c'est de l'arithmétique. Allez-y, maintenant.";
			link.l1 = "Je pars pour les Bermudes.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelStart");
		break;

		case "16":
			dialog.text = "...(levant le sablier vers la lumière)... Un sablier. Un travail ancien, l'argent a noirci. Et qu'est-ce qui vous a tant frappé là-dedans ?";
			link.l1 = "Regardez le bulbe. Un crâne dans un anneau d'os.";
			link.l1.go = "17";
			TakeNItems(PChar, "DamnedClock", -1);
		break;

		case "17":
			dialog.text = "Je le vois. Le crâne et les os croisés, je connais, c'est barbouillé sur tous les pavillons qui naviguent. Mais l'anneau...";
			link.l1 = "Je ne l'ai jamais vu nulle part.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Et moi, je crois que si. Il y a très longtemps. Et voici le plus fâcheux : je me souviens du symbole, mais je ne me souviens pas du tout oם je l'ai vu.";
			link.l1 = "Alors essayez de vous en souvenir.";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "J'essaierai. Votre part est faite, le reste est la mienne. Seulement, la mémoire n'obéit pas aux ordres, pas même aux miens. Donnez-moi un mois.";
			link.l1 = "Vous avez votre mois.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "א bientכt, capitaine. Et merci. Ces trente-deux pendus, j'étais seul à les avoir en tête depuis bien longtemps.";
			link.l1 = "Adieu, Alejon.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelEnd");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
