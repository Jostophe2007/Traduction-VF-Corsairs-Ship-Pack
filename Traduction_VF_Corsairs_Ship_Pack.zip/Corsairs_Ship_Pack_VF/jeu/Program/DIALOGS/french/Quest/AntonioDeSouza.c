// диалоговый файл №1 на голландку
void ProcessDialogEvent()
{
	ref NPChar, sld;
	aref Link, NextDiag;
	int i;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	float locx, locy, locz;

    switch (Dialog.CurrentNode)
    {
        case "First time":
            dialog.text = NPCStringReactionRepeat("Que voulez-vous, "+ GetSexPhrase("mon fils","ma fille") +" ?",
                         "Encore vous ? Vous avez oublié de dire quelque chose ?", ""+ GetSexPhrase("Mon fils","Ma fille") +", qu'est-ce qui vous tracasse ? Pourquoi venez-vous me voir pour la énième fois aujourd'hui sans rien dire ?",
                         "וcoutez, " + GetFullName(pchar) + ", si vous n'avez rien à dire, inutile de venir ici.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat("Rien de spécial, padre...",
                                               "Non, comme ça...",
                                               "Rien à dire, padre...",
                                               "D'accord, padre...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
//>>>>>>>>>>>>========= Разброс диалогов =====================
			if (CheckAttribute(pchar, "questTemp.PDM_ONV_OhotaNaVedmu"))	//Квест "Witch Hunt"
			{
				dialog.text = "... cette ville est embourbée dans le péché ! Mais bientכt, nous délivrerons les gens des sombres filets de Satan par le feu et la volonté de notre Seigneur ! Euh... que voulez-vous, "+ GetSexPhrase("mon fils","ma fille") +" ?";
				link.l1 = "Saint Père, je sais qu'il y a ici une sorcière nommée Maria, une ancienne prostituée du port. Par son art noir, elle a déjà tué deux personnes : le capitaine Miguel Cuenda, et le bon hidalgo Bartholomew, mort avant d'avoir pu se repentir. C'était un serviteur du gouverneur de Belize. Je prie Dieu que la Sainte Inquisition la punisse pour ses péchés.";
				link.l1.go = "Inqizitor_2";
				break;
			}
			if (pchar.questTemp.MC == "toByeBye")	//Квест 'Зачарованный город'
			{
				dialog.text = "Que voulez-vous à la Sainte Inquisition ?!";
				link.l1 = "Mon père, j'ai affaire à vous. Ne refusez pas "+ GetSexPhrase("à un fervent catholique","à une fervente catholique") +" une minute d'attention";
				link.l1.go = "MCIncq";
				pchar.questTemp.MC = "Incquisitio";
				break;
			}
			if (pchar.questTemp.State == "Inquisition_toDeSouza")//Квест №2, базар с гл.Инквизитором
			{
                dialog.text = "Bienvenue dans le giron de l'וglise, "+ GetSexPhrase("mon fils","ma fille") +".";
    			link.l1 = "Padre, je suis ici sur ordre du gouverneur général...";
    			link.l1.go = "Step_S2_1";
            }
			if (pchar.questTemp.State == "Inquisition_toCuracao")
			{
                if (CheckAttribute(pchar, "questTemp.State.Store") || CheckAttribute(pchar, "questTemp.State.Usurer"))
                {
                    dialog.text = "Ravi de vous voir, " + GetFullName(pchar) + ". Vous venez faire votre rapport sur la mission ?";
        			link.l1 = "Padre, j'ai rendu visite à toutes les personnes que vous avez mentionnées.";
        			link.l1.go = "Step_S2_12";
        			link.l2 = "Peut-être pas encore, monseigneur. Je vais encore y travailler...";
        			link.l2.go = "exit";
                }
                else
                {
                    dialog.text = "Vous avez reçu une mission, "+ GetSexPhrase("mon fils","ma fille") +". Au travail.";
        			link.l1 = "Très bien, monseigneur...";
        			link.l1.go = "exit";
                }
            }
			if (pchar.questTemp.State == "Inquisition_afterFrancisco")
			{
                if (CheckAttribute(pchar, "questTemp.State.Store") || CheckAttribute(pchar, "questTemp.State.Usurer"))
                {
                    dialog.text = "Ravi de vous voir, " + GetFullName(pchar) + ". Vous venez faire votre rapport sur la mission ?";
        			link.l1 = "Monseigneur, j'ai rendu visite à toutes les personnes que vous avez mentionnées.";
        			link.l1.go = "Step_S2_12";
        			link.l2 = "Peut-être pas encore, monseigneur. Je vais encore y travailler...";
        			link.l2.go = "exit";
                }
                else
                {
                    dialog.text = "Que s'est-il passé, "+ GetSexPhrase("mon fils","ma fille") +" ? Vous avez besoin de l'absolution de vos péchés ?";
        			link.l1 = "Non, monseigneur. Ce n'est pas pour ça que je reviens. א l'instant, un certain Francisco de San Agostinho m'a abordé et s'est mis à me chanter de vrais trilles de rossignol sur la moralité de votre mission. Il sait oם je vais et pourquoi. Vous ne trouvez pas ça étrange ?";
        			link.l1.go = "Step_S2_11";
                }
            }
			if (pchar.questTemp.State == "Inquisition_backAllGood" || pchar.questTemp.State == "Inquisition_backPartGood" || pchar.questTemp.State == "Inquisition_backBad")
			{
                dialog.text = ""+ GetSexPhrase("Mon fils","Ma fille") +", vous pouvez retourner à La Havane. Je n'ai plus besoin de vous...";
    			link.l1 = "Très bien, monseigneur.";
    			link.l1.go = "exit";
            }
			if (pchar.questTemp.State == "TakeRockBras_RockTaken")
			{
                dialog.text = "Je vous écoute, "+ GetSexPhrase("mon fils","ma fille") +". Qu'est-ce qui vous amène ?";
    			link.l1 = "Monseigneur, conformément à l'ordre reçu du gouverneur général de La Havane, don Francisco Oregón y Gascón, je remets à la Sainte Inquisition le célèbre brigand Rock le Brésilien, capturé par mes soins lors de la chaude bataille de Maracaibo.";
    			link.l1.go = "Step_S3_1";
            }

        break;

//<<<<<<<<<<<<===== Разброс диалогов  =====================
        case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;

//********************************* Задания Инквизиции. Квест №2 **********************************
 		case "Step_S2_1":
			dialog.text = "Je sais, "+ GetSexPhrase("mon fils","ma fille") +". Je vous attendais. Alors, votre mission.\n"+
                          "Il y a quelques personnes qui vivent dans les ténèbres, et nous ne pouvons pas encore les aider à voir la lumière. Ce sont les païens florentins Joao Ilhajo, Josef Nunen de Fonquezao et Jacob Lopez de Fonseca. Nous avons pu découvrir qu'ils étaient sous l'influence de la doctrine hérétique de Jansénius.\n"+
                          "Nous libérons les âmes des adeptes de la secte janséniste de leurs liens impies en brמlant leurs corps sur le bמcher. Mais ils ne l'apprécient pas, ils n'apprécient pas le salut de leur âme que nous leur offrons...";
			link.l1 = "Excusez-moi, monseigneur, j'ai une question. Si, bien sמr, vous me permettez de la poser.";
			link.l1.go = "Step_S2_2";
		break;
 		case "Step_S2_2":
			dialog.text = "Demandez, "+ GetSexPhrase("mon fils","ma fille") +".";
			link.l1 = "J'ai entendu dire que les jansénistes croient au Christ de la même façon que les catholiques. Pourquoi les brמler, s'ils sont chrétiens eux aussi ?";
			link.l1.go = "Step_S2_3";
		break;
 		case "Step_S2_3":
			dialog.text = "Jansénius a perverti les dogmes de l'וglise : nous avons des désaccords sur la question de concilier l'existence du libre arbitre humain avec la nécessité de la grâce divine, sans laquelle le salut de l'homme est impossible.";
			link.l1 = "N'est-il pas possible de s'entendre, c'est-à-dire de régler les différends par la négociation ?";
			link.l1.go = "Step_S2_4";
		break;
 		case "Step_S2_4":
			dialog.text = "C'est impossible, "+ GetSexPhrase("mon fils","ma fille") +". Les ennemis de l'וglise n'attendent que de détourner les âmes égarées de leur Pasteur. Personne n'a le droit d'interpréter à sa guise les postulats de la foi chrétienne, et encore moins de les mettre en doute. Personne !\n"+
                          "De plus, les jansénistes se sont souillés d'un crime qui ne sera jamais pardonné. Il y a une vingtaine d'années, l'un des premiers adeptes de cette secte, Samuel Cohen, a volé d'anciens documents de l'וglise dans nos archives de Séville !";
			link.l1 = "דa alors ! J'ai toujours cru que la Sainte Inquisition était irréprochable. Comment cela a-t-il pu arriver ?";
			link.l1.go = "Step_S2_5";
		break;
 		case "Step_S2_5":
			dialog.text = "Avec l'aide de l'ennemi du genre humain, "+ GetSexPhrase("mon fils","ma fille") +" ! Nous affrontons ses machinations à chaque minute, mais parfois, il prend le dessus sur l'un de nos frères. C'est ce qui s'est passé cette fois : notre archiviste de Séville a succombé au péché mortel de cupidité...";
			link.l1 = "Il a tout avoué ?";
			link.l1.go = "Step_S2_6";
		break;
 		case "Step_S2_6":
			dialog.text = "Il a avoué, s'est repenti et a purifié son âme, comment pourrait-il en être autrement ? Nous sommes heureux d'avoir pu l'aider. Je suis sמr que le Seigneur a accueilli son âme...";
			link.l1 = "Amen... Alors, quelle sera ma mission ?";
			link.l1.go = "Step_S2_7";
		break;
 		case "Step_S2_7":
			dialog.text = "Vous devez rendre visite aux marchands en fuite, dans un but précis.";
			link.l1 = "Savez-vous oם ils sont maintenant ?";
			link.l1.go = "Step_S2_8";
		break;
 		case "Step_S2_8":
			dialog.text = "Bien sמr, "+ GetSexPhrase("mon fils","ma fille") +". D'abord, ils ont fui aux Pays-Bas, mais ils n'y ont pas trouvé leur place : l'hérésie calviniste est très jalouse des autres hérésies.\n"+
                          "Ensuite, ils sont partis pour le Nouveau Monde, et ils ont maintenant fondé une communauté sectaire sur l'île de Curaçao. Votre tâche est d'obtenir de ces hérétiques, d'ailleurs des gens très riches, qu'ils achètent le pardon du pape.\n"+
                          "L'indulgence coמtera 50 000 chacun. Et s'ils refusent, alors, pour la plus grande gloire de Dieu, je vous autorise à prendre des mesures extrêmes.";
			link.l1 = "50 000 chacun, et en cas de désobéissance, je peux faire d'eux ce que je veux. J'ai bien compris ?";
			link.l1.go = "Step_S2_9";
		break;
 		case "Step_S2_9":
			dialog.text = "Oui, "+ GetSexPhrase("mon fils","ma fille") +", vous avez bien compris...";
			link.l1 = "Mais 50 000 peuvent-ils racheter les péchés des jansénistes devant le Seigneur ?";
			link.l1.go = "Step_S2_10";
		break;
 		case "Step_S2_10":
			dialog.text = "Non, bien sמr que non. Mais il faut bien commencer quelque part. Nous devons tourner leurs regards vers le Seigneur, et c'est ce que vous allez faire. Tout est clair pour vous, vous sentez-vous de taille à accomplir la mission ?";
			link.l1 = "Oui, monseigneur, je commence immédiatement !!";
			link.l1.go = "exit";
    		pchar.questTemp.State = "Inquisition_toCuracao";
            AddQuestRecord("Spa_Line_2_Inquisition", "2");
            Pchar.quest.Inquisition_MeetFrancisco.win_condition.l1 = "location";
            Pchar.quest.Inquisition_MeetFrancisco.win_condition.l1.location = "Santiago_town";
            Pchar.quest.Inquisition_MeetFrancisco.win_condition = "Inquisition_MeetFrancisco";
		break;
 		case "Step_S2_11":
			dialog.text = "Merci pour l'avertissement, "+ GetSexPhrase("mon fils","ma fille") +". Une douceur excessive envers les hérétiques ne fait qu'accroître la souffrance de leurs âmes. Je m'occuperai de Francisco, il ne vous dérangera plus. Prenez ceci en signe de reconnaissance. Je suppose que vous en aurez besoin...";
			link.l1 = "Merci, saint père.";
			link.l1.go = "exit";
			pchar.questTemp.State = "Inquisition_toCuracao";
            GiveItem2Character(pchar,"DeSouzaCross");
		break;
 		case "Step_S2_12":
			dialog.text = "Et quels sont les résultats, "+ GetSexPhrase("mon fils","ma fille") +" ?";
			link.l1 = "Je n'ai réussi à obtenir d'argent d'aucune de ces personnes.";
			link.l1.go = "Step_S2_NotMoney";
            if (pchar.questTemp.State.Usurer == "Ok")
            {
    			link.l1 = "Je n'ai réussi à obtenir l'argent que de Joseph Nunen de Fonquezao, un usurier de Curaçao.";
    			link.l1.go = "Step_S2_OnlyUsurer";
            }
            if (pchar.questTemp.State.Store == "Ok")
            {
    			link.l1 = "Je n'ai réussi à obtenir l'argent que de Joao Ilhajo, le propriétaire du magasin de Curaçao, et de son associé Jacob Lopez de Fonseca.";
    			link.l1.go = "Step_S2_OnlyStore";
            }
            if (pchar.questTemp.State.Store == "Ok" && pchar.questTemp.State.Usurer == "Ok")
            {
    			link.l1 = "Le travail est entièrement accompli, Saint Père. J'ai réussi à obtenir l'argent des trois jansénistes que vous avez mentionnés.";
    			link.l1.go = "Step_S2_All";
            }
		break;
 		case "Step_S2_NotMoney":
			dialog.text = "Vos paroles ont attristé mon âme... Vous n'avez pas su accomplir la plus simple des tâches.";
			link.l1 = "Saint Père, j'ai essayé de toutes mes forces...";
			link.l1.go = "Step_S2_13";
		break;
 		case "Step_S2_13":
			dialog.text = "Je comprends que la diligence est une grande vertu humaine... Allez à La Havane, "+ GetSexPhrase("mon fils","ma fille") +", je n'ai plus besoin de vous...";
			link.l1 = "Très bien, monseigneur. Adieu...";
			link.l1.go = "exit";
            pchar.questTemp.State = "Inquisition_backBad";
            AddQuestRecord("Spa_Line_2_Inquisition", "15");
            DeleteAttribute(pchar, "questTemp.State.Store");
            DeleteAttribute(pchar, "questTemp.State.Usurer");
            DeleteAttribute(pchar, "questTemp.State.SeekBible");
		break;
 		case "Step_S2_OnlyUsurer":
            if (sti(pchar.money) >= 50000)
            {
                dialog.text = "Eh bien, une tâche à moitié accomplie, c'est déjà bien, "+ GetSexPhrase("mon fils","ma fille") +"... Mais ça aurait pu être mieux.";
    			link.l1 = "Saint Père, j'ai essayé de toutes mes forces...";
    			link.l1.go = "Step_S2_14";
            }
            else
            {
                dialog.text = "Euh, la tâche est accomplie, mais oם sont les 50 000 ? Allez, "+ GetSexPhrase("mon fils","ma fille") +", et revenez avec l'argent pour le rapport de mission.";
    			link.l1 = "Pardonnez-moi, monseigneur, je l'ai oublié sur le navire. Je reviens tout de suite...";
    			link.l1.go = "exit";
                NextDiag.TempNode = "Step_S2_OnlyUsurer";
            }
		break;
 		case "Step_S2_14":
			dialog.text = "Bien, bien, bon... Alors, faisons le calcul. Selon la Chancellerie pontificale, le recouvrement de l'argent d'un débiteur équivaut à la découverte d'un trésor. L'inventeur du trésor a droit à 20 à 30 pour cent de sa valeur au prix du marché, selon la valeur du trésor.\n"+
                          "On prélève sur le produit la dîme de l'וglise : 10 pour cent, c'est pour ça qu'on l'appelle la dîme, héhé. Votre récompense totale s'élève donc à... voyons... 9 000 piastres. Recevez-la, "+ GetSexPhrase("mon fils","ma fille") +", signez ici, et vous êtes libre.";
			link.l1 = "Merci, monseigneur. Adieu...";
			link.l1.go = "exit";
            if (CheckCharacterItem(pchar, "Bible"))
            {
    			link.l2 = "Attendez, monseigneur. J'ai encore quelque chose pour vous...";
    			link.l2.go = "Step_S2_17";
            }
			pchar.questTemp.State = "Inquisition_backPartGood";
			AddMoneyToCharacter(pchar, -41000);
			AddQuestRecord("Spa_Line_2_Inquisition", "16");
            DeleteAttribute(pchar, "questTemp.State.Store");
            DeleteAttribute(pchar, "questTemp.State.Usurer");
            DeleteAttribute(pchar, "questTemp.State.SeekBible");
			NextDiag.TempNode = "First time";
		break;
 		case "Step_S2_OnlyStore":
            if (sti(pchar.money) >= 100000)
            {
                dialog.text = "Eh bien, une tâche à moitié accomplie, c'est déjà bien, "+ GetSexPhrase("mon fils","ma fille") +"... Mais ça aurait pu être mieux.";
    			link.l1 = "Saint Père, j'ai essayé de toutes mes forces...";
    			link.l1.go = "Step_S2_15";
            }
            else
            {
                dialog.text = "Euh, la tâche est accomplie, mais oם sont les 100 000 ? Allez, "+ GetSexPhrase("mon fils","ma fille") +", et revenez avec l'argent pour le rapport de mission.";
    			link.l1 = "Pardonnez-moi, monseigneur, je l'ai oublié sur le navire. Je reviens tout de suite...";
    			link.l1.go = "exit";
                NextDiag.TempNode = "Step_S2_OnlyStore";
            }
		break;
 		case "Step_S2_15":
			dialog.text = "Bien, bien, bon... Alors, faisons le calcul. Selon la Chancellerie pontificale, le recouvrement de l'argent d'un débiteur équivaut à la découverte d'un trésor. L'inventeur du trésor a droit à 20 à 30 pour cent de sa valeur au prix du marché, selon la valeur du trésor.\n"+
                          "On prélève sur le produit la dîme de l'וglise : 10 pour cent, c'est pour ça qu'on l'appelle la dîme, héhé. Au total, votre récompense s'élève à... voyons... 18 000 piastres. Recevez-la, "+ GetSexPhrase("mon fils","ma fille") +", signez ici, et vous êtes libre.";
			link.l1 = "Merci, monseigneur. Adieu...";
			link.l1.go = "exit";
            if (CheckCharacterItem(pchar, "Bible"))
            {
    			link.l2 = "Attendez, padre. J'ai encore quelque chose pour vous...";
    			link.l2.go = "Step_S2_17";
            }
			pchar.questTemp.State = "Inquisition_backPartGood";
			AddMoneyToCharacter(pchar, -82000);
			AddQuestRecord("Spa_Line_2_Inquisition", "16");
            DeleteAttribute(pchar, "questTemp.State.Store");
            DeleteAttribute(pchar, "questTemp.State.Usurer");
            DeleteAttribute(pchar, "questTemp.State.SeekBible");
			NextDiag.TempNode = "First time";
		break;
 		case "Step_S2_All":
            if (sti(pchar.money) >= 150000)
            {
                dialog.text = "Très bien, "+ GetSexPhrase("mon fils","ma fille") +" ! 150 000, c'est une contribution importante à la cause de notre Ordre. Nous vous en sommes reconnaissants...";
    			link.l1 = "Saint Père, j'ai essayé de toutes mes forces...";
    			link.l1.go = "Step_S2_16";
            }
            else
            {
                dialog.text = "Euh, la tâche est accomplie, mais oם sont les 150 000 ? Allez, "+ GetSexPhrase("mon fils","ma fille") +", et revenez avec l'argent pour le rapport de mission.";
    			link.l1 = "Pardonnez-moi, monseigneur, je l'ai oublié sur le navire. Je reviens tout de suite...";
    			link.l1.go = "exit";
                NextDiag.TempNode = "Step_S2_All";
            }
		break;
 		case "Step_S2_16":
			dialog.text = "Bien, bien, bon... Alors, faisons le calcul. Selon la Chancellerie pontificale, le recouvrement de l'argent d'un débiteur équivaut à la découverte d'un trésor. L'inventeur du trésor a droit à 20 à 30 pour cent de sa valeur au prix du marché, selon la valeur du trésor.\n"+
                          "On prélève sur le produit la dîme de l'וglise : 10 pour cent, c'est pour ça qu'on l'appelle la dîme, héhé. Au total, votre récompense s'élève à... voyons... 27 000 piastres. Recevez-la, "+ GetSexPhrase("mon fils","ma fille") +", signez ici, et vous êtes libre.";
			link.l1 = "Merci, monseigneur. Adieu...";
			link.l1.go = "exit";
            if (CheckCharacterItem(pchar, "Bible"))
            {
    			link.l2 = "Attendez, monseigneur. J'ai encore quelque chose pour vous...";
    			link.l2.go = "Step_S2_17";
            }
			pchar.questTemp.State = "Inquisition_backAllGood";
			AddMoneyToCharacter(pchar, -123000);
			AddQuestRecord("Spa_Line_2_Inquisition", "17");
            DeleteAttribute(pchar, "questTemp.State.Store");
            DeleteAttribute(pchar, "questTemp.State.Usurer");
            DeleteAttribute(pchar, "questTemp.State.SeekBible");
			NextDiag.TempNode = "First time";
		break;
 		case "Step_S2_17":
			dialog.text = "Et qu'y a-t-il, "+ GetSexPhrase("mon fils","ma fille") +" ?";
			link.l1 = "Saint Père, je me souviens que vous m'avez parlé d'un certain Samuel Cohen, qui avait volé d'anciens documents de l'וglise dans vos archives de Séville...";
			link.l1.go = "Step_S2_18";
		break;
 		case "Step_S2_18":
			dialog.text = "C'est arrivé, et alors ?";
			link.l1 = "N'aurait-il pas volé un certain וvangile écrit par l'un des premiers apכtres, pas le plus digne, plutכt le contraire...";
			link.l1.go = "Step_S2_19";
		break;
 		case "Step_S2_19":
			dialog.text = "Il est interdit ne serait-ce que d'en parler ! Mais continuez, "+ GetSexPhrase("mon fils","ma fille") +", car vous m'avez beaucoup surpris...";
			link.l1 = "Eh bien, monseigneur, j'ai trouvé ce livre. Le voici.";
			link.l1.go = "Step_S2_20";
		break;
 		case "Step_S2_20":
			dialog.text = "Sainte Vierge, Mère de Dieu !!! Une telle chance, nous n'osions même pas en rêver ! Nous ne pensions qu'à l'endroit d'oם surgirait ce pamphlet hérétique et à ce que nous ferions alors.\n"+
                          "Quel poids en moins !.. "+ GetSexPhrase("mon fils","ma fille") +", pour récompense d'un tel acte, je vous absous de tous vos péchés, et de trois autres d'avance !";
			link.l1 = "Je me réjouis sincèrement d'avoir pu vous aider, Saint Père...";
			link.l1.go = "Step_S2_21";
			TakeItemFromCharacter(pchar, "Bible");
		break;
 		case "Step_S2_21":
			dialog.text = "Ce n'est pas tout, "+ GetSexPhrase("mon fils","ma fille") +". La Sainte Inquisition, en signe de gratitude pour votre service, vous offre cette magnifique armure de protection incrustée d'or.\n"+
                          "Cependant, la valeur de cette cuirasse n'est pas dans ses incrustations. Sa vraie valeur réside dans sa grande fiabilité : c'est ce dont vous avez le plus besoin, je crois...";
			link.l1 = "C'est vrai, padre. Je tiens à ma peau, d'une certaine façon... Eh bien, merci aussi pour ça. Et maintenant, permettez-moi de prendre congé, Saint Père.";
			link.l1.go = "Step_S2_22";
		break;
 		case "Step_S2_22":
			dialog.text = "Oui, oui, bien sמr. Moi aussi, je vais courir écrire la bonne nouvelle à Séville !";
			link.l1 = "Adieu, monseigneur.";
			link.l1.go = "exit";
            GiveItem2Character(pchar, "cirass5");
		break;
//********************************* Захват Рока Бразильца. Квест №3 **********************************
 		case "Step_S3_1":
            if (CheckPassengerInCharacter(pchar, "RockBrasilian"))
            {
    			dialog.text = "Excellent travail, "+ GetSexPhrase("mon fils","ma fille") +" ! Je suis émerveillé !";
    			link.l1 = "Je peux le dire sans fausse modestie : capturer ce gredin n'a pas été facile. Pour cela, j'ai dמ aborder une corvette bourrée de racaille pirate de Tortuga.";
    			link.l1.go = "Step_S3_2";
            }
            else
            {
    			dialog.text = "Pourtant, il n'est pas dans votre cale ! "+ GetSexPhrase("mon fils","ma fille") +", allez me chercher Rock le Brésilien.";
    			link.l1 = "Très bien, monseigneur...";
    			link.l1.go = "exit";
            }
		break;
 		case "Step_S3_2":
			dialog.text = "Eh bien, faites-moi amener ce ladrón immédiatement, j'ai hâte de commencer l'enquête. Et je vous prie de vous rendre aussi chez le gouverneur général.";
			link.l1 = "Très bien, monseigneur.";
			link.l1.go = "exit";
			//NPChar.LifeDay = 10;
    	    //SaveCurrentNpcQuestDateParam(NPChar, "LifeTimeCreate");
			AddQuestRecord("Spa_Line_3_RockBrasilian", "6");
			pchar.questTemp.State = "TakeRockBras_RockGiven";
			sld = characterFromId("RockBrasilian");
			ReleasePrisoner(sld);
     	    sld.LifeDay = 0; // уберём нпс
		break;
//********************************* Квест "Witch Hunt" **********************************		
		case "Inqizitor_2":
			dialog.text = "Ah, que votre âme soit éternellement bénie pour votre action juste, "+ GetSexPhrase("mon fils","ma fille") +". Nous nous occuperons de cette sorcière.";
			link.l1 = "Je l'espère, Saint Père. Bonne journée.";
			link.l1.go = "KAZN";
			AddBonusEnergyToCharacter(pchar, 25);
			PlaySound("Interface\new_level.wav");
			Log_info("Vous avez reçu la bénédiction de l'inquisiteur.");
			Log_info("Votre énergie a augmenté de 25 pour toujours.");
			DeleteAttribute(pchar, "questTemp.PDM_ONV_OhotaNaVedmu");
		break;

		case "KAZN":
			DialogExit();
			TavernWaitDate("wait_night");
			PostVideoAndQuest("Witch",50,"PDM_ONV_Kazn_NEW");
			//DoQuestReloadToLocation("Santiago_town", "officers", "reload8_2", "PDM_ONV_KaznVedmi");
		break;
//**************************** сдаём зачарованный Дес-Мойнес ********************************
		case "MCIncq":
			dialog.text = "Je vous écoute, "+ GetSexPhrase("mon fils","ma fille") +".";
			link.l1 = "Je veux vous parler de ce lieu diabolique oם le diable se promène la nuit !";
			link.l1.go = "MCIncq_1";
		break;
		case "MCIncq_1":
			dialog.text = "...";
			link.l1 = "C'est la ville de Des Moines, dans la lagune de Maracaibo. Il faut la brמler !";
			link.l1.go = "MCIncq_2";
		break;
		case "MCIncq_2":
			dialog.text = "Oui... nous le ferons, "+ GetSexPhrase("mon fils","ma fille") +". Dieu vous remercie pour votre fidèle service envers l'וglise.";
			link.l1 = "Dieu soit loué !";
			link.l1.go = "MCIncq_3";
		break;
		case "MCIncq_3":
			dialog.text = "Acceptez 50 000 piastres en récompense de vos efforts.";
			link.l1 = "Toute ma gratitude, Votre Sainteté !";
			link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 50000);
			CloseQuestHeader("MagicCity");
			pchar.questdata.ZacharovanyGorod = 1;
			SetTimerFunction("MC_DesMoinesVozrojdenie", 0, 0, 1);
		break;

    }
}
