
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag, forName;
	string sTemp, sGem, sTitle;
	int iTemp;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);
	
	int iRang = sti(PChar.rank);
	float fRandom = FRAND(1) + 1;

	float fLuck = GetCharacterSkillToOld(PChar, SKILL_FORTUNE);
	if(fLuck < 1.1) { fLuck = 1.1; }
	fLuck /= 10;

	int iMoney = iRang * 500 * fLuck * fRandom + drand(100);
	if(iMoney < 500) { iMoney = 500 + drand2(100); }
	if(iMoney > 10000) { iMoney = 9900 + drand2(100); }

	switch(Dialog.CurrentNode)
	{
		case "First time":
			dialog.text = "Il n'y a rien à dire.";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//--------------------------- линейка ГПК --------------------------------
		//заказчик устранения всех нищих
		case "Begin_PoorKill":
			dialog.text = "Bonjour, capitaine. Accepteriez-vous de parler affaires avec moi ?";
			link.l1 = "Pourquoi pas ? Avec plaisir !";
			link.l1.go = "Begin_PoorKill_1";
		break;

		case "Begin_PoorKill_close":
			dialog.text = "Hum, je vois... Eh bien, c'est dommage.";
			link.l1 = "...";
			link.l1.go = "Exit";
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
			ChangeCharacterReputation(pchar, 10);
			pchar.questTemp.LSC = "PoorIsGood";
			SetQuestHeader("ISS_PoorsMurder");
			AddQuestRecord("ISS_PoorsMurder", "12");
			AddQuestUserData("ISS_PoorsMurder", "sSex", GetSexPhrase("", "e"));
		break;

		case "Begin_PoorKill_1":
			dialog.text = "Parfait ! On voit tout de suite une personne qui a le sens des affaires.";
			link.l1 = "Au fait, mon cher.";
			link.l1.go = "Begin_PoorKill_2";
		break;
		case "Begin_PoorKill_2":
			dialog.text = "Ha ha, votre poigne me plaît ! Bon, je vous propose d'abord de faire connaissance. Je m'appelle " + GetFullName(npchar) + ". Excusez-moi, mais je me suis renseigné sur vous, et je sais que vous êtes le capitaine " + GetFullName(pchar) + ". Je sais aussi que vous êtes corsaire. C'est bien ça ?";
			link.l1 = "C'est exact. Vous êtes bien renseigné sur moi. Et vous, quel est votre métier ?";
			link.l1.go = "Begin_PoorKill_3";
		break;
		case "Begin_PoorKill_3":
			dialog.text = "Je suis un homme d'affaires, disons.";
			link.l1 = "Très bien. Et quelle affaire avez-vous avec moi ?";
			link.l1.go = "Begin_PoorKill_4";
		break;
		case "Begin_PoorKill_4":
			dialog.text = "Oui, à vrai dire, ce n'est rien pour "+ GetSexPhrase("un homme aussi courageux", "une fille aussi courageuse") +" que vous. Le fait est que mon employeur est sérieusement préoccupé par l'état de la morale et des mœurs dans les îles des Caraïbes. Oui, c'est ça !";
			link.l1 = "Ravi pour votre employeur. Mais je ne suis pas un grand moraliste...";
			link.l1.go = "Begin_PoorKill_5";
		break;
		case "Begin_PoorKill_5":
			dialog.text = "Mais comme « infirmier des bois », vous ferez merveille !";
			link.l1 = "De quoi parlez-vous ? Je répète : au fait, mon cher...";
			link.l1.go = "Begin_PoorKill_6";
		break;
		case "Begin_PoorKill_6":
			dialog.text = "Bon, d'accord. J'ai besoin que vous débarrassiez les villes des mendiants et des miséreux. Et partout, dans chaque ville, quelle que soit la nation. Nous sommes prêts à vous payer un million de piastres pour ce travail !";
			link.l1 = "Hé, c'est tentant. Un million, ça ne se trouve pas sous le pas d'un cheval...";
			link.l1.go = "Begin_PoorKill_7";
			link.l2 = "Pour qui me prenez-vous ? Pour un chasseur de primes ?! Fichez le camp, l'ami, tant que vous êtes entier...";
			link.l2.go = "Begin_PoorKill_close";
		break;
		case "Begin_PoorKill_7":
			dialog.text = "Un million, ça ne pousse pas sur les arbres non plus, mon cher, héhé...";
			link.l1 = "Vous êtes un plaisantin, je vois ! Discutons des conditions du marché.";
			link.l1.go = "Begin_PoorKill_8";
		break;
		case "Begin_PoorKill_8":
			dialog.text = "Avec plaisir ! Donc, je fais un dépכt d'un million de piastres à votre nom chez un usurier, disons celui de cette ville. Un dépכt. Une fois la mission accomplie, vous pourrez retirer cet argent.";
			link.l1 = "Et l'avance ? Je vais devoir beaucoup voyager.";
			link.l1.go = "Begin_PoorKill_9";
		break;
		case "Begin_PoorKill_9":
			dialog.text = "Désolé, mais il ne peut être question d'avance. C'est tout à fait inacceptable.";
			link.l1 = "Hum, c'est triste... Et le délai ? Suis-je limité dans le temps ?";
			link.l1.go = "Begin_PoorKill_10";
		break;
		case "Begin_PoorKill_10":
			dialog.text = "Pratiquement pas. Faites le travail et touchez votre million. Je suppose que vous ne traînerez pas, héhé...";
			link.l1 = "Hum, alors au travail. Oם et quand pourrai-je vérifier qu'un dépכt existe bien à mon nom ?";
			link.l1.go = "Begin_PoorKill_11";
		break;
		case "Begin_PoorKill_11":
			dialog.text = "Chez l'usurier du coin, dès aujourd'hui. Et vous pourrez retirer votre million sur notification de ma part. Quand je ne verrai plus de mendiants dans les rues des villes, je ferai aussitכt savoir à l'usurier que vous avez rempli vos obligations.";
			link.l1 = "Eh bien, marché conclu !";
			link.l1.go = "Begin_PoorKill_12";
		break;
		case "Begin_PoorKill_12":
			dialog.text = "Parfait. Eh bien, nous ne nous reverrons pas, adieu. Je suis content d'avoir obtenu votre accord pour ce travail. J'espère que la mission sera accomplie au plus vite.";
			link.l1 = "Adieu. Au fait, quel est cet employeur que ces va-nu-pieds dérangent tant ?";
			link.l1.go = "Begin_PoorKill_13";
		break;
		case "Begin_PoorKill_13":
			dialog.text = "Désolé, mais je ne peux pas le dire.";
			link.l1 = "Hum, bon, d'accord. Adieu...";
			link.l1.go = "Begin_PoorKill_14";
		break;
		case "Begin_PoorKill_14":
			SetQuestHeader("ISS_PoorsMurder");
			AddQuestRecord("ISS_PoorsMurder", "1");
			AddQuestUserData("ISS_PoorsMurder", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_PoorsMurder", "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			pchar.quest.ISS_Murder1.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder1.win_condition.l1.character = "SentJons_Poorman";
			pchar.quest.ISS_Murder1.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder2.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder2.win_condition.l1.character = "Bridgetown_Poorman";
			pchar.quest.ISS_Murder2.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder3.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder3.win_condition.l1.character = "Beliz_Poorman";
			pchar.quest.ISS_Murder3.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder4.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder4.win_condition.l1.character = "Caracas_Poorman";
			pchar.quest.ISS_Murder4.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder5.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder5.win_condition.l1.character = "Cartahena_Poorman";
			pchar.quest.ISS_Murder5.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder6.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder6.win_condition.l1.character = "Cumana_Poorman";
			pchar.quest.ISS_Murder6.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder7.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder7.win_condition.l1.character = "BasTer_Poorman";
			pchar.quest.ISS_Murder7.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder8.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder8.win_condition.l1.character = "Havana_Poorman";
			pchar.quest.ISS_Murder8.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder9.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder9.win_condition.l1.character = "PortRoyal_Poorman";
			pchar.quest.ISS_Murder9.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder10.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder10.win_condition.l1.character = "FortFrance_Poorman";
			pchar.quest.ISS_Murder10.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder11.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder11.win_condition.l1.character = "Charles_Poorman";
			pchar.quest.ISS_Murder11.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder12.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder12.win_condition.l1.character = "PortoBello_Poorman";
			pchar.quest.ISS_Murder12.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder13.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder13.win_condition.l1.character = "PortPax_Poorman";
			pchar.quest.ISS_Murder13.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder14.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder14.win_condition.l1.character = "Santiago_Poorman";
			pchar.quest.ISS_Murder14.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder15.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder15.win_condition.l1.character = "Marigo_Poorman";
			pchar.quest.ISS_Murder15.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder16.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder16.win_condition.l1.character = "Tortuga_Poorman";
			pchar.quest.ISS_Murder16.function = "ISS_MurderSignExecute";
			pchar.quest.ISS_Murder17.win_condition.l1 = "NPC_Death";
			pchar.quest.ISS_Murder17.win_condition.l1.character = "PortSpein_Poorman";
			pchar.quest.ISS_Murder17.function = "ISS_MurderSignExecute";
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
			pchar.questTemp.LSC = "SignOnPoorMurder";
			pchar.questTemp.LSC.killCost = 17; //счётчик убитых нищих на декремент
			pchar.questTemp.LSC.usurerId = npchar.city + "_usurer"; //флаг на депозит у ростовщика
			LAi_SetActorTypeNoGroup(NPChar);
			LAi_ActorRunToLocation(NPChar, "reload", "gate_back", "none", "", "", "CanFightCurLocation", -1);
			LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], true);
			chrDisableReloadToLocation = true;
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//воришка ключа
		case "GiveKeyMan":
			dialog.text = "Quoi ?";
			link.l1 = "Hum, écoutez, c'est vous, le Maître des Clés ?";
			link.l1.go = "GiveKeyMan_1";
		break;
		case "GiveKeyMan_1":
			dialog.text = "Oui, c'est moi. Qui êtes-vous ?";
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ".";
			link.l1.go = "GiveKeyMan_2";
		break;
		case "GiveKeyMan_2":
			dialog.text = "Et que vous faut-il, capitaine " + GetFullName(pchar) + " ?";
			link.l1 = "וcoutez, c'est vous qui avez fabriqué les coffres de la maison du gouverneur général Stuyvesant ? Je veux m'en commander un, avec une serrure.";
			link.l1.go = "GiveKeyMan_3";
		break;
		case "GiveKeyMan_3":
			dialog.text = "Celui avec la serrure, c'est moi. Et je peux dire sans exagérer que vous êtes à la bonne adresse. Je suis le plus célèbre Maître des Clés ! Il est vrai que j'ai un homonyme, un salaud aux yeux bridés, mais il ne m'arrive pas à la cheville. Le vrai Maître des Clés, c'est donc moi !";
			link.l1 = "Eh bien, parfait ! Voilà ce que je veux : il me faut exactement le même coffre que celui du gouverneur général.";
			link.l1.go = "GiveKeyMan_4";
		break;
		case "GiveKeyMan_4":
			dialog.text = "Hé, je ne fais pas de coffres identiques, ce n'est pas une manufacture, vous savez ! Chacune de mes pièces est unique. Et oם a-t-on jamais vu mettre des serrures identiques ? Les clés iraient alors partout.";
			link.l1 = "Tu sais, l'ami, c'est justement de ça que je parle...";
			link.l1.go = "GiveKeyMan_5";
		break;
		case "GiveKeyMan_5":
			dialog.text = "Ha ! Vous êtes un client difficile, à ce que je vois...";
			link.l1 = "C'est ça, mon ami !!! Pour une commande difficile, des honoraires difficiles...";
			link.l1.go = "GiveKeyMan_6";
		break;
		case "GiveKeyMan_6":
			dialog.text = "Des honoraires difficiles, vous dites ? Je comprends qu'il ne vous faut que la clé.";
			link.l1 = "C'est exact.";
			link.l1.go = "GiveKeyMan_7";
		break;
		case "GiveKeyMan_7":
			npchar.quest.price = makeint((6666 * ((sti(pchar.rank))/2.0)*MOD_SKILL_ENEMY_RATE*3*(100-(GetCharacterSkill(pchar, SKILL_LEADERSHIP)/2)))/100);
			if (sti(pchar.money) >= sti(npchar.quest.price))
			{
				dialog.text = "Mmm... Bien ! Je veux " + FindRussianMoneyString(sti(npchar.quest.price)) + " pour cette clé.";
				link.l1 = "Caramba, pas mal comme prix !";
				link.l1.go = "GiveKeyMan_10";
			}
			else
			{
				dialog.text = "Ho ho ho, "+ GetSexPhrase("l'ami, tu es fauché", "ma petite, tu es fauchée") +" !!! De quels honoraires puis-je parler avec toi ?! Tu sais, celui qui a le vent qui siffle dans les poches n'est pas mon client. Et oם avais-je les yeux ?";
				link.l1 = "Qu'est-ce que ça veut dire ?!";
				link.l1.go = "GiveKeyMan_8";
			}
		break;
		case "GiveKeyMan_8":
			dialog.text = "דa veut dire, "+ GetSexPhrase("l'ami", "ma petite") +", que même mes services ordinaires sont au-dessus de tes moyens, alors les spéciaux, n'en parlons pas. Reviens quand tu auras gagné des piastres, mais pour l'instant, ne me dérange pas.";
			link.l1 = "D'accord, je te retrouverai plus tard...";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toMasterKeysNoMoney";
			NextDiag.TempNode = "GiveKeyMan_NoMoney";
		break;
		case "GiveKeyMan_NoMoney":
			npchar.quest.price = makeint((6666 * ((sti(pchar.rank))/2.0)*MOD_SKILL_ENEMY_RATE*3*(100-(GetCharacterSkill(pchar, SKILL_LEADERSHIP)/2)))/100);
			if (sti(pchar.money) >= sti(npchar.quest.price))
			{
				dialog.text = "Eh bien, voilà qui est mieux, comme on dit... Revenons à notre conversation sur la clé. Bref, je suis prêt à vous la fabriquer, disons, pour " + FindRussianMoneyString(sti(npchar.quest.price)) + ".";
				link.l1 = "Héhé, pas mal !!";
				link.l1.go = "GiveKeyMan_10";
			}
			else
			{
				dialog.text = "Ne me dérangez même pas avec vos propositions. Vous n'avez pas assez. Je n'ai pas besoin de tels clients.";
				link.l1 = "Hum, je vais vous aider avec un peu plus d'argent.";
				link.l1.go = "exit";
			}
		break;
		case "GiveKeyMan_10":
			dialog.text = "Je n'ai pas l'habitude de mégoter. Vous voyez, je suis le Maître des Clés ! Bref, crachez et qu'on n'en parle plus. Il n'y a pas d'autre solution !";
			link.l1 = "Hum, on dirait qu'il n'y a vraiment pas d'échappatoire... écoutez, vous ne pourriez pas baisser un peu le prix ?";
			link.l1.go = "GiveKeyMan_11";
		break;
		case "GiveKeyMan_11":
			dialog.text = "Non, "+ GetSexPhrase("l'ami", "ma petite") +". Tu sais ce que tu demandes...";
			link.l1 = "Prenez. Oם est ma clé ?";
			link.l1.go = "GiveKeyMan_12";
			AddMoneyToCharacter(pchar, -sti(npchar.quest.price));
		break;
		case "GiveKeyMan_12":
			dialog.text = "Il faut la fabriquer. Revenez me voir dans deux jours. J'habite dans une maison près de l'escalier qui mène à l'église.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
			SetTimerFunction("LSC_openMasterHouse", 0, 0, 2);
			LocatorReloadEnterDisable("Villemstad_town", "houseSp5", true);
			npchar.location = "none";
			AddQuestRecord("ISS_PoorsMurder", "6");
		break;

		case "GiveKeyManInside":
			dialog.text = "Ah, vous voilà !";
			link.l1 = "Oui, me voilà ! Oם est ma clé ?";
			link.l1.go = "GiveKeyManInside_1";
		break;
		case "GiveKeyManInside_1":
			dialog.text = "La clé ? Hum, vous savez, ça m'ennuie de vous le dire, mais le gouverneur général tient vraiment à vous parler.";
			link.l1 = "Tu m'as balancé, vaurien ?!";
			link.l1.go = "GiveKeyManInside_2";
		break;
		case "GiveKeyManInside_2":
			dialog.text = "Et que vouliez-vous que je fasse ? Je ne suis pas mon propre ennemi... Bref, il y a des soldats ici, ils vont vous escorter...";
			link.l1 = "Oh, parasite ! Pourquoi as-tu pris l'argent, alors ?!";
			link.l1.go = "GiveKeyManInside_3";
		break;
		case "GiveKeyManInside_3":
			dialog.text = "Au travail. J'ai fait la clé, comme promis. Je tiens parole !";
			link.l1 = "Eh bien, eh bien...";
			link.l1.go = "exit";
			npchar.lifeDay = 0;
			AddDialogExitQuestFunction("LSC_enterSoldiers");
		break;
		//арестовывающий офицер
		case "MK_HollOfficer":
			dialog.text = "Suivez-moi, capitaine !";
			link.l1 = "Oם ça ?";
			link.l1.go = "MK_HollOfficer_1";
		break;
		case "MK_HollOfficer_1":
			dialog.text = "Au cachot provisoire. Le temps de tirer les choses au clair, pour ainsi dire... Et n'essayez pas de faire le malin, sinon je serai obligé d'employer la force !";
			link.l1 = "Eh, officier, le problème, c'est que je vais devoir employer la force moi aussi...";
			link.l1.go = "MK_HollOfficer_2";
		break;
		case "MK_HollOfficer_2":
			LAi_LocationFightDisable(&Locations[FindLocation("Villemstad_houseSp5")], false);
			LAi_SetWarriorTypeNoGroup(npchar);
            LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
            LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
            LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//заказчик нищих в Мариго
		case "PKInMarigo":
			dialog.text = "Hum, je ne pensais pas vous revoir ! Vous avez déjà accompli la mission ? Des problèmes avec le dépכt ?";
			link.l1 = "Non, le dépכt va bien. Vous savez, le fait est que je n'arrive pas à trouver un des vagabonds : Dan le Taquin.";
			link.l1.go = "PKInMarigo_1";
		break;
		case "PKInMarigo_1":
			dialog.text = "Ne vous en faites pas pour lui, vous ne le trouverez plus. Occupez-vous des autres.";
			link.l1 = "Je vois... Mais quand même, oם est le Taquin ?";
			link.l1.go = "PKInMarigo_2";
		break;
		case "PKInMarigo_2":
			dialog.text = "Je ne suis pas clair ? Dan le Taquin ne figure pas sur la liste de la commande. Vous me comprenez ?";
			link.l1 = "Je comprends, bien sמr. Mais quand même, j'aimerais vraiment savoir oם il est.";
			link.l1.go = "PKInMarigo_3";
		break;
		case "PKInMarigo_3":
			dialog.text = "Votre insistance ne me plaît pas. Si vous continuez, vous suivrez le Taquin tout droit.";
			link.l1 = "Alors, il est mort...";
			link.l1.go = "PKInMarigo_4";
		break;
		case "PKInMarigo_4":
			dialog.text = "On ne peut plus mort. Et maintenant, expliquez-vous, je vous prie, sur votre curiosité !";
			link.l1 = "Bien. Je sais que vous êtes le représentant de la Compagnie néerlandaise des Indes occidentales dans les Caraïbes. Je sais aussi que vous faites des affaires avec le gouverneur général Stuyvesant. Et je veux aussi savoir pourquoi diable les vagabonds du coin vous déplaisaient.";
			link.l1.go = "PKInMarigo_5";
		break;
		case "PKInMarigo_5":
			dialog.text = "Vous n'en voulez pas un peu trop ?";
			link.l1 = "Ce ne sont pas toutes mes questions. Je veux tout savoir sur l'טle !";
			link.l1.go = "PKInMarigo_6";
		break;
		case "PKInMarigo_6":
			dialog.text = "Avez-vous la moindre idée de ce dans quoi vous vous fourrez, capitaine ? Naviguez à votre guise, plumez quelques marchands : ça, passe encore. Mais se frotter à une compagnie qui possède tout l'océan Indien, c'est de la folie.\n"+
				"Remplissez vos obligations, retirez le dépכt, et continuez à faire vos coups à votre guise, personne ne vous touchera. Mais votre curiosité vous mènera très vite au tombeau. Je vous donne une dernière chance, capitaine, de repartir d'ici en paix.";
			link.l1 = "Je ne crois pas que je vais saisir cette chance. Je veux aussi en savoir plus sur les produits de luxe dont vous craignez tant de voir baisser les prix...";
			link.l1.go = "PKInMarigo_7";
		break;
		case "PKInMarigo_7":
			dialog.text = "Euh, capitaine, je crains que votre compte ne soit bon. Comme disait un de mes amis, aujourd'hui décédé : « J'en savais trop... ».";
			link.l1 = "Alors, que comptes-tu faire, furet des Indes occidentales ?";
			link.l1.go = "PKInMarigo_8";
		break;
		case "PKInMarigo_8":
			dialog.text = "Je vais te tuer. Et tout de suite ! Gardes !!!";
			link.l1 = "Ne perds pas ta culotte en me tuant...";
			link.l1.go = "PKInMarigo_9";
		break;
		case "PKInMarigo_9":
			chrDisableReloadToLocation = true;
			LAi_LocationFightDisable(loadedLocation, false);

			TeleportCharacterToLocator(npchar, "goto", "goto3");
			LAi_group_Delete("OliverTrust");
			LAi_group_MoveCharacter(npchar, "OliverTrust");

			for (int i = 1; i <= 2; i++)
			{
				ref sld = SetFantomOfficer("reload", "reload1", HOLLAND, "");
				// FantomMakeCoolFighter(sld, 40, 100, 100, "blade28", "pistol4", 200 + 10 * MOD_SKILL_ENEMY_RATE*3); // annoer, я всё понимаю, но это ебля без вазелина уже (LEO)
				FantomMakeCoolFighter(sld, sti(Pchar.rank), 25+drand(50), 25+drand(50), "blade31", "pistol2", 20/*  + 10 * MOD_SKILL_ENEMY_RATE*3 */);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "OliverTrust");
			}

			LAi_group_SetHearRadius("OliverTrust", 100.0);
			LAi_group_SetRelation("OliverTrust", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("OliverTrust", LAI_GROUP_PLAYER, true);
            LAi_group_SetCheck("OliverTrust", "OpenTheDoors");

            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//мент в Протекторе
		case "LSCQuestMent":
			dialog.text = "Eh bien, dites-moi, quelles sont vos nouvelles ?";
			link.l1 = "De quoi parlez-vous ?";
			link.l1.go = "LSCQuestMent_1";
		break;
		case "LSCQuestMent_1":
			dialog.text = "Arrêtez de faire semblant ! André m'a tout raconté de vos allusions.";
			link.l1 = "Quel idiot !..";
			link.l1.go = "LSCQuestMent_2";
		break;
		case "LSCQuestMent_2":
			dialog.text = "André Labor est un citoyen respectueux des lois de cette ville. Mais vous allez devoir tout me raconter au sujet de Dan le Taquin, sinon, demain, c'est l'Amiral qui s'occupera de vous.";
			link.l1 = "Alors, il ne sait encore rien ? Mais c'est merveilleux !.. Hum, je crains que vous ne deviez mourir.";
			link.l1.go = "LSCQuestMent_3";
		break;
		case "LSCQuestMent_3":
			dialog.text = "Quoi ?!! André, à moi !";
			link.l1 = "Ah, le charpentier fait le guet ? C'est parfait aussi !";
			link.l1.go = "LSCQuestMent_4";
		break;
		case "LSCQuestMent_4":
			AddQuestRecord("ISS_MainLine", "9");
			pchar.questTemp.LSC = "afterFightInProtector";
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetWarriorTypeNoGroup(npchar);
			sld = characterFromId("AndreLabor");
			LAi_SetWarriorType(sld);
			LAi_group_MoveCharacter(sld, "EnemyFight");
			ChangeCharacterAddressGroup(sld, pchar.location, "reload",  "reload1");
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//одиночный нарвал, которого надо замочить
		case "LSCQuestNarval":
			dialog.text = "Qu'est-ce que vous faites ici ?!";
			link.l1 = "Moi ? Eh bien, comment vous dire...";
			link.l1.go = "LSCQuestNarval_1";
		break;
		case "LSCQuestNarval_1":
			dialog.text = "Tu es idiot ? Tu ne sais pas que c'est le territoire des Narvals ?";
			link.l1 = "Oui, je sais...";
			link.l1.go = "LSCQuestNarval_2";
		break;
		case "LSCQuestNarval_2":
			dialog.text = "Tu es fou ? Tu cherches la mort ?";
			link.l1 = "Eh bien, oui... Seulement la tienne. Désolé, l'ami, mais je vais devoir te tuer.";
			link.l1.go = "LSCQuestNarval_3";
		break;
		case "LSCQuestNarval_3":
			AddQuestRecord("ISS_MainLine", "11");
			AddQuestUserData("ISS_MainLine", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.LSC = "toAdmNarvalRing";
			LAi_LocationFightDisable(loadedLocation, false);
			LAi_SetWarriorTypeNoGroup(npchar);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "OpenTheDoors");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		//--------------------------- дача шебеки Синяя Птица --------------------------------
		//капитан шебеки Синяя Птица
		case "SharpCapitain":
			dialog.text = "Qu'est-ce que vous fichez, bon sang, "+ GetFullName(pchar) + " ?";
			link.l1 = "Rien de personnel, ce ne sont que des affaires. On m'a offert une généreuse récompense pour fermer ta boutique.";
			link.l1.go = "SharpCapitain_1";
			link.l2 = "Assez parlé, défends-toi !";
			link.l2.go = "SharpCapitain_fight";
		break;

		case "SharpCapitain_1":
			dialog.text = "Le diable... Vous ne comprenez rien : après quelques voyages seulement pour chercher des perles, vous seriez bien plus riche qu'avec n'importe quel paiement unique de votre employeur. Mais maintenant, c'est trop tard : sans informateur, les tartanes des pêcheurs de perles sont perdues pour nous à jamais...";
			link.l1 = "Oublie les perles, cette broutille ne mérite pas ton attention. Je connais des sources de revenus plus juteuses. Rejoins mon équipage, et tu nageras dans la richesse !";
			link.l1.go = "SharpCapitain_2";
			link.l2 = "Assez parlé, défends-toi !";
			link.l2.go = "SharpCapitain_fight";
		break;

		case "SharpCapitain_2":
			dialog.text = "Dans ma situation actuelle, il serait stupide de refuser... La richesse, vous dites ? Eh bien, je suis à votre service, capitaine !";
			link.l1 = "Bienvenue dans l'équipage, corsaire !";
			link.l1.go = "Sharp_hired";
		break;

		case "Sharp_hired":
			bQuestDisableMapEnter = false;
			characters[GetCharacterIndex("Sharp")].lifeDay = 0;
			sld = GetCharacter(NPC_GenerateCharacter("SharpOf", "Sharp", "man", "man", 20, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 15, 70, 70, "blade25", "pistol6", 120);
			sld.name = "Bartholomew";
			sld.lastname = "Sharp";
			sld.greeting = "Gr_Officer";
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			sld.HoldEquip = true;
			sld.HalfImmortal = true;  // Контузия
			//SetSelfSkill(sld, 30, 30, 30, 30, 30);
			//SetShipSkill(sld, 30, 50, 30, 35, 80, 35, 30, 35, 30);
			SetSelfSkill(sld, 40, 40, 40, 40, 40);
			SetShipSkill(sld, 50, 50, 50, 50, 60, 40, 30, 40, 30);
			SetSPECIAL(sld, 6, 10, 8, 5, 8, 8, 10);
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			AddItems(sld, "talisman11", 1);
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			QuestAboardCabinDialogNotBattle();
            DialogExit();
		break;

		case "SharpCapitain_fight":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			Npchar.SaveItemsForDead = true;
		break;

		case "PGG_cabin":
			// LEO: сбитого при живой охране НЕ лечим - если игрок решит его добить, это будет добивание,
			//   а не свежий бой с полного здоровья. Капитану без гвардии лечение оставлено как было.
			if (!CheckAttribute(npchar, "PGG_CabinBeaten")) LAi_SetCurHPMax(npchar);
			ref chr = CharacterFromID(npchar.CaptanId);
			chr.willDie = true;
			dialog.text = "Bientכt, tu nourriras les poissons, "+ GetFullName(pchar) + " ! Je te le garantis !";
			link.l1 = "Toi et moi, nous sommes collègues, pourquoi nous entretuer pour rien ? Si on unissait plutכt nos forces ?";
			link.l1.go = "PGG_cabin_1";
			link.l2 = "L'assurance te mènera au tombeau. Défends-toi !";
			link.l2.go = "PGG_cabin_fight";
		break;

		case "PGG_cabin_1":
			int hirePrice = sti(npchar.rank) * 10000 + 100000;
			npchar.hirePrice = hirePrice;
			dialog.text = "Naviguer avec toi ? Plutכt mourir\nQuoique, il est toujours temps pour ça. Je viendrai peut-être avec toi, si tu peux satisfaire mon appétit. D'abord, je veux "+npchar.hirePrice+" piastres, ici et maintenant.";
			if(makeint(Pchar.money) >= sti(npchar.hirePrice))
			{
				link.l1 = "Quel appétit tu as. Mais soit, j'accepte. Voici ton argent.";
				link.l1.go = "PGG_cabin_2";
			}
			else
			{
				link.l1 = "Combien ?! Je n'ai jamais vu autant d'argent de ma vie. דa me coמtera moins cher de te tuer !";
				link.l1.go = "PGG_cabin_fight";
			}
			link.l2 = "De l'assurance, et de la cupidité en plus. Non, toi et moi, on ne trouvera pas de langage commun. Défends-toi !";
			link.l2.go = "PGG_cabin_fight";
		break;
		case "PGG_cabin_2":
			dialog.text = "Bon sang, j'aurais dמ demander plus... Mais un marché vaut plus que l'argent, je suis à votre service.";
			AddMoneyToCharacter(Pchar, -sti(npchar.hirePrice));
			link.l1 = "Bienvenue dans l'équipage !";
			link.l1.go = "PGG_hired";
		break;

		case "PGG_hired":
			bQuestDisableMapEnter = false;
			chr = CharacterFromID(npchar.CaptanId);
			Restore_PGG(chr);
			sld = GetCharacter(NPC_GenerateCharacter(npchar.CaptanId+"Of", "none", chr.sex, chr.model.animation, 1, PIRATE, -1, false));
			ChangeAttributesFromCharacter(sld, chr, true);
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			if (sld.sex != "woman")
			{
				sld.greeting = "Gr_Officer";
			}
			else
			{
				if(rand(1) == 0)
				{
					sld.greeting = "Gr_Danielle";
				}
				else
				{
					sld.greeting = "GR_marycasper";
				}
			}
			if (sld.model.animation == "man") sld.CanTakeMushket = true;
			if (HasSubStr(sld.model, "Whisper"))
			{
				sld.CanTakeMushket = true;
				if(sld.model == "PGG_Whisper_6") EquipCharacterByItem(sld, "suit_1");
			}
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			sld.HoldEquip = true;
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			QuestAboardCabinDialogNotBattle();
            DialogExit();
		break;

		case "PGG_cabin_fight":
				QuestAboardCabinDialogExitWithBattle("");
				// LEO: сбитого именно ДОБИВАЕМ, а не деремся с ним заново - на выходе ставим 10 ХП, ровно
				//   как каютным капитанам фрахт-охотников (узел QuestAboardCabinDialog_Finish). Просто «не
				//   лечить» тут мало: пока он ждал конца драки с охраной, запас подтягивала регенерация.
				if (CheckAttribute(npchar, "PGG_CabinBeaten")) LAi_SetHP(npchar, 10.0, LAi_GetCharacterMaxHP(npchar));
				DialogExit();
				AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "zpqCapitain":
			dialog.text = "Je peux continuer comme ça toute la journée. Donne-moi l'argent pour la poudre, "+ GetFullName(pchar) + ", si tu veux vivre.";
			if(makeint(Pchar.money) >= 300000)
			{
				link.l1 = "Ton navire a été capturé, et tout l'équipage a été tué. Mais tu te bats plutכt bien. Je pense te laisser la vie, et même te donner de l'argent pour la poudre, si tu acceptes de naviguer sous mes ordres. Sinon...";
				link.l1.go = "zpqCapitain_1";
			}

			link.l2 = "J'en ai vu de plus menaçants ! De moi, tu n'auras qu'une lame entre les cכtes !";
			link.l2.go = "zpqCapitain_fight";
		break;

		case "zpqCapitain_1":
			dialog.text = "Inutile de continuer. De toute façon, je ne sortirai pas d'ici vivant. J'accepte.";
			AddMoneyToCharacter(Pchar, -300000);
			link.l1 = "Bienvenue dans l'équipage, corsaire !";
			link.l1.go = "zpq_hired";
		break;

		case "zpq_hired":
			bQuestDisableMapEnter = false;
			characters[GetCharacterIndex(npchar.id)].lifeDay = 0;
			sld = GetCharacter(NPC_GenerateCharacter("zpqCaptainOf", "Lil_Jim_0", "man", "man", 25, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 25, 105, 105, "blade23", "pistol3", 10);
			sld.name 	= "Petit";
			sld.lastname = "Jimmy";
			sld.greeting = "Gr_Officer";

			sld.rank = 25;
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			sld.HoldEquip = true;
			sld.HalfImmortal = true;  // Контузия
			sld.HeroModel = "Lil_Jim_0,Lil_Jim_1,Lil_Jim_2,Lil_Jim_3,Lil_Jim_4,Lil_Jim_5";
			SetSelfSkill(sld, 80, 80, 75, 80, 80);
			SetShipSkill(sld, 60, 75, 75, 75, 65, 70, 70, 60, 70);
			SetSPECIAL(sld, 9, 9, 10, 10, 8, 10, 10);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "ByWorker");
			SetCharacterPerk(sld, "Ciras");
			SetCharacterPerk(sld, "Gunman");
			SetCharacterPerk(sld, "Sliding");
			SetCharacterPerk(sld, "CriticalHit");
			SetCharacterPerk(sld, "IronWill");
			SetCharacterPerk(sld, "BladeDancer");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "FastReload");
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "SailsDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "MusketsShoot");
			SetCharacterPerk(sld, "AdvancedBattleState");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "LongRangeShoot");
			SetCharacterPerk(sld, "SwordplayProfessional");
			SetCharacterPerk(sld, "ShipTurnRateUp");
			SetCharacterPerk(sld, "ShipSpeedUp");
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; растущую жизнь докладывает Sync внутри
			//SetCharacterPerk(sld, "Medic");
			AddItems(sld, "talisman13", 1);
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			QuestAboardCabinDialogNotBattle();
            DialogExit();
		break;

		case "zpqCapitain_fight":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
			Npchar.SaveItemsForDead = true;
		break;

		case "BlueBirdCapitain":
			dialog.text = "J'aimerais bien savoir qui vous êtes...";
			link.l1 = "Je m'appelle " + GetFullName(pchar) + ". Je suis corsaire.";
			link.l1.go = "BlueBirdCapitain_1";
		break;
		case "BlueBirdCapitain_1":
			dialog.text = "Et pourquoi diable as-tu attaqué mon chébec ?!!";
			link.l1 = "C'est un ordre, je dois t'envoyer par le fond. Tu as trop gâché tes relations avec les marchands...";
			link.l1.go = "BlueBirdCapitain_2";
		break;
		case "BlueBirdCapitain_2":
			dialog.text = "Et c'est un corsaire qui parle ?! Je suppose que tu n'aimes pas non plus les marchands...";
			link.l1 = "C'est un travail, l'ami, rien de personnel. Dis-moi plutכt comment toi et Pascal restez en contact. Tu n'as pas idée du mal que j'ai eu à te trouver.";
			link.l1.go = "BlueBirdCapitain_3";
		break;
		case "BlueBirdCapitain_3":
			dialog.text = "דa ne te regarde pas, caramba ! Merci pour ce petit répit, et maintenant, continuons !";
			link.l1 = "Eh bien, d'accord...";
			link.l1.go = "BlueBirdCapitain_4";
		break;

			case "BlueBirdCapitain_4":
			dialog.text = "Attends... וcoute, je vais te proposer autre chose. J'ai perdu, c'est fini, laisse-moi partir, hein ?! Et je glisserai peut-être un mot en ta faveur à mon employeur ! Tu n'as pas idée de ce dans quoi tu t'es fourré !" ;
			link.l1 = "Eh non, mon vieux. Pas de témoins, comme on dit ! Rien de personnel, les affaires sont les affaires.";
			link.l1.go = "BlueBirdCapitain_5";
			/*link.l2 = "Ha! That's interesting! And you know, Ja- I agree. We still need to look for an officer like you. But look - if you decide to make jokes, I'll send you overboard in a jiffy!";
			link.l2.go = "BlueBirdCapitain_6";*/
		break;

		case "BlueBirdCapitain_6":
			dialog.text = "La mise en garde est inutile, capitaine. Pour moi, maintenant, l'endroit le plus sמr de l'archipel, c'est votre navire. Ne doutez pas de moi. Je suis content que nous ayons un accord.";
			link.l1 = "Bienvenue dans l'équipage, corsaire !";
			link.l1.go = "Ja_hired";
		break;

		case "Ja_hired":
			bQuestDisableMapEnter = false;
			characters[GetCharacterIndex("Jafar")].lifeDay = 0;
			sld = GetCharacter(NPC_GenerateCharacter("Jafarry", "QuestCaptain", "man", "man", 25, PIRATE, -1, true));
			FantomMakeCoolFighter(sld, 25, 70, 70, "blade14", "pistol6", 100);
			sld.name = "Ja";
			sld.lastname = "Preston";
			sld.greeting = "Gr_Officer";
			sld.rank = 25;
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			sld.quest.meeting = true;
			sld.HoldEquip = true;
			sld.HalfImmortal = true;  // Контузия
			sld.HeroModel = "QuestCaptain,QuestCaptain_1,QuestCaptain_2,QuestCaptain_3,QuestCaptain_4,QuestCaptain_5";
			SetSelfSkill(sld, 80, 80, 75, 80, 80);
			SetShipSkill(sld, 60, 50, 60, 60, 65, 70, 60, 60, 60);
			SetSPECIAL(sld, 9, 9, 10, 10, 8, 10, 10);
			SetCharacterPerk(sld, "Energaiser"); // скрытый перк даёт 1.5 к приросту энергии, даётся ГГ и боссам уровней
			SetCharacterPerk(sld, "AdvancedDefense");
			SetCharacterPerk(sld, "ByWorker");
			SetCharacterPerk(sld, "Ciras");
			SetCharacterPerk(sld, "Gunman");
			SetCharacterPerk(sld, "Sliding");
			SetCharacterPerk(sld, "CriticalHit");
			SetCharacterPerk(sld, "IronWill");
			SetCharacterPerk(sld, "BladeDancer");
			SetCharacterPerk(sld, "GunProfessional");
			SetCharacterPerk(sld, "FastReload");
			SetCharacterPerk(sld, "HullDamageUp");
			SetCharacterPerk(sld, "SailsDamageUp");
			SetCharacterPerk(sld, "CrewDamageUp");
			SetCharacterPerk(sld, "MusketsShoot");
			SetCharacterPerk(sld, "AdvancedBattleState");
			SetCharacterPerk(sld, "ShipDefenseProfessional");
			SetCharacterPerk(sld, "LongRangeShoot");
			SetCharacterPerk(sld, "SwordplayProfessional");
			SetCharacterPerk(sld, "ShipTurnRateUp");
			SetCharacterPerk(sld, "ShipSpeedUp");
			//SetCharacterPerk(sld, "Medic");
			AddItems(sld, "talisman14", 1);
			sld.quest.OfficerPrice = sti(pchar.rank)*500;
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			sld.OfficerWantToGo.DontGo = true; //не пытаться уйти
			sld.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			QuestAboardCabinDialogNotBattle();
            DialogExit();
			SetFantomHP(sld); // LEO: ХП по силе, выносливости и рангу; перк растущей жизни докладывает Sync внутри
		break;

		case "BlueBirdCapitain_5":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//капитаны флейтов торговцев
		case "BlueBirdTrader":
			dialog.text = "Bon sang, pourquoi nous avez-vous attaqués ?!!";
			link.l1 = "C'est le châtiment de ton maître, l'ami. Je n'ai rien contre toi.";
			link.l1.go = "BlueBirdTrader_1";
		break;
		case "BlueBirdTrader_1":
			dialog.text = "דa fait plaisir à entendre...";
			link.l1 = "Maintenant, tu prends la chaloupe, et avec le reste de l'équipage, tu peux retourner auprès de ton maître. Dis-lui que " + GetFullName(pchar) + " lui envoie " + GetSexPhrase("ses","ses") + " salutations.";
			link.l1.go = "BlueBirdTrader_2";
		break;
		case "BlueBirdTrader_2":
			dialog.text = "Je lui transmettrai vos salutations, c'est certain.";
			link.l1 = "Alors, c'est tout. Vis, pour l'instant...";
			link.l1.go = "BlueBirdTrader_3";
		break;
		case "BlueBirdTrader_3":
			QuestAboardCabinDialogNotBattle();
            DialogExit();
		break;
		//--------------------------- жемчужный промысел, Шарп --------------------------------
		//капитан Шарп, первый базар на палубе
		case "DeckSharp":	//на палубе
			dialog.text = ""+ GetSexPhrase("Salut, l'ami. א quoi dois-je le plaisir de te voir sur mon brick", "Ho ho, quelle visite ! א quoi dois-je le plaisir de vous voir sur mon brick, belle amazone") +" ?";
			link.l1 = "Salutations au capitaine Bartholomew Sharp ! J'ai eu du mal à vous trouver...";
			link.l1.go = "DeckSharp_1";
			npchar.quest.meeting = true;
			//блокировка генератора, если взят грабёж от Моргана
			if (pchar.questTemp.piratesLine == "PearlQ4_toTerks")
			{
				dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +"Je suis occupé en ce moment ! Je ne peux rien pour vous. Sans rancune...";
				link.l1 = "D'accord, l'ami...";
				link.l1.go = "exit";
				NextDiag.TempNode = "DeckSharp_overBad";
				pchar.questTemp.Sharp = "seekSharp"; //опять начинаем с борделей
				pchar.questTemp.Sharp.brothelChance = rand(10);
				DeleteAttribute(pchar, "questTemp.Sharp.PearlAreal");
				AddQuestRecord("SharpPearl", "13");
				CloseQuestHeader("SharpPearl");
			}
		break;
		case "DeckSharp_1":
			dialog.text = "Oui, ce n'est pas facile... Alors, qu'est-ce qui t'amène ?";
			link.l1 = "Tu sais, l'ami, je veux rendre visite aux pêcheries de perles. Pour arrondir mes fins de mois, pour ainsi dire...";
			link.l1.go = "DeckSharp_2";
		break;
		case "DeckSharp_2":
			dialog.text = "Oh, mon âme sœur !!! Alors, oם est le problème ? Vas-y !";
			link.l1 = "Le problème, c'est que je ne sais pas oם ils pêchent. Ils sont très discrets et se déplacent sans cesse ! Je suis venu te demander conseil, en tant qu'expert en la matière.";
			link.l1.go = "DeckSharp_3";
		break;
		case "DeckSharp_3":
			dialog.text = "Ouais, bon, les pêcheurs de perles sont rusés de nos jours, on ne les attrape pas à mains nues\nBon, je vais t'aider la première fois, te donner un tuyau sur la pêche.";
			link.l1 = "Oh, Sharp, mon ami, merci !";
			link.l1.go = "DeckSharp_4";
		break;
		case "DeckSharp_4":
			dialog.text = "Bon, ne me remercie pas trop\nBref, écoute notre stratégie. Les pêcheurs de perles se comportent très prudemment : ils ne pêchent que depuis des îles désertes, ou loin des curieux, pour ainsi dire. \nIl faut les cueillir à chaud, justement quand ils sont en mer !";
			link.l1 = "וcoute, comment sais-tu oם ils pêchent en ce moment ?";
			link.l1.go = "DeckSharp_5";
		break;
		case "DeckSharp_5":
			dialog.text = "C'est mon grand secret. Je ne le dirai à personne. "+ GetSexPhrase("", "Même pas à une mignonne comme toi. ") +"N'insiste même pas !";
			link.l1 = "Hum, bon, comme tu voudras...";
			link.l1.go = "DeckSharp_6";
		break;
		case "DeckSharp_6":
			GetPerlShore(); //где промысел ведётся
			sTemp = "";
			if (CheckAttribute(pchar, "questTemp.Sharp.PearlAreal.add")) sTemp = pchar.questTemp.Sharp.PearlAreal.add;
			dialog.text = "Alors écoute bien. Il y a sur l'île de " + XI_ConvertString(pchar.questTemp.Sharp.PearlAreal + "Voc") + " un endroit appelé " + GetConvertStr(pchar.questTemp.Sharp.PearlAreal.Shore, "LocLables.txt") +
				sTemp + ". Si tu y arrives d'ici " + FindRussianDaysString(sti(pchar.questTemp.Sharp.PearlAreal.terms)) + ", tu y trouveras les pêcheurs de perles.";
			link.l1 = "Je comprends. Merci, Bartholomew.";
			link.l1.go = "DeckSharp_7";
		break;
		case "DeckSharp_7":
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("Appelle-moi capitaine Sharp ! Je préfère.", "Pour toi, ma belle, c'est Barty tout court.") +".", ""+ GetSexPhrase("Je préfère qu'on m'appelle capitaine Sharp.", "Pour une mignonne comme toi, c'est simplement Barty.") +" !");
			link.l1 = "Hum, je vois. Merci, "+ GetSexPhrase("capitaine Sharp", "Barty") +". Tu m'as rendu un fier service !";
			link.l1.go = "DeckSharp_8";
		break;
		case "DeckSharp_8":
			dialog.text = RandPhraseSimple(""+ GetSexPhrase("Il n'y a pas de quoi, l'ami : si tu as besoin de quoi que ce soit, adresse-toi à moi...", "Reviens me voir, ma belle. Ou peut-être qu'on se retrouvera un jour, pour ainsi dire, dans un cadre moins officiel ?") +"", ""+ GetSexPhrase("Aider ses collègues, c'est un devoir sacré, pour ainsi dire... Repasse quand tu veux, je t'aiderai !", "Repasse quand tu veux, je t'aiderai. " + pchar.name + ", ou peut-être poursuivrons-nous notre conversation... dans un endroit plus confortable ?") +"");
			link.l1 = ""+ GetSexPhrase("Sans faute, capitaine Sharp !!", "Tu es un coureur de jupons incorrigible, Barty. א bientכt !") +"";
			link.l1.go = "DeckSharp_8exit";
		break;
		case "DeckSharp_8exit":
			sTemp = "";
			if (CheckAttribute(pchar, "questTemp.Sharp.PearlAreal.add")) sTemp = pchar.questTemp.Sharp.PearlAreal.add;
			NextDiag.TempNode = "DeckSharp_over";
			npchar.DeckDialogNode = "NewDeckSharp"; //новая нода на палубу
			pchar.questTemp.Sharp = "toPearl"; //флаг квеста - на промысел!!!
			AddQuestRecord("SharpPearl", "5");
			AddQuestUserData("SharpPearl", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("SharpPearl", "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData("SharpPearl", "iDay", FindRussianDaysString(sti(pchar.questTemp.Sharp.PearlAreal.terms)));
			AddQuestUserData("SharpPearl", "sAreal", XI_ConvertString(pchar.questTemp.Sharp.PearlAreal + "Voc"));
			AddQuestUserData("SharpPearl", "sTarget", GetConvertStr(pchar.questTemp.Sharp.PearlAreal.Shore, "LocLables.txt") + sTemp);
			pchar.quest.SeaPearl_login.win_condition.l1 = "location";
			pchar.quest.SeaPearl_login.win_condition.l1.location = pchar.questTemp.Sharp.PearlAreal.Island;
			pchar.quest.SeaPearl_login.function = "SeaPearl_login";
			SetTimerFunction("SeaPearl_Late", 0, 0, sti(pchar.questTemp.Sharp.PearlAreal.terms));
			if (pchar.location != "Deck_Near_Ship")
			{
				LAi_SetActorTypeNoGroup(npchar);
				LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "OpenTheDoors", 15.0);
			}
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
		//капитан Шарп, последующие разговоры на палубе
		case "NewDeckSharp":
			dialog.text = "Oh, qui vois-je ?! Salut à toi, "+ GetSexPhrase("mon camarade", "ma beauté") +" !";
			link.l1 = "Bonjour, capitaine Sharp. Comment ça va ?";
			link.l1.go = "NewDeckSharp_1";
			//блокировка генератора, если взят грабёж от Моргана
			if (pchar.questTemp.piratesLine == "PearlQ4_toTerks")
			{
				dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +"Je suis occupé en ce moment ! Je ne peux rien pour vous. Sans rancune...";
				link.l1 = "D'accord, l'ami...";
				link.l1.go = "exit";
				NextDiag.TempNode = "DeckSharp_overBad";
				pchar.questTemp.Sharp = "seekSharp"; //опять начинаем с борделей
				pchar.questTemp.Sharp.brothelChance = rand(10);
				DeleteAttribute(pchar, "questTemp.Sharp.PearlAreal");
				AddQuestRecord("SharpPearl", "13");
				CloseQuestHeader("SharpPearl");
			}
		break;
		case "NewDeckSharp_1":
			dialog.text = "Oui, tout va bien, "+ GetSexPhrase("l'ami", "ma chérie") +", je ne peux pas me plaindre\nAlors, dis-moi, qu'est-ce qui t'amène cette fois ?";
			link.l1 = "Oui, toujours pour la même chose, l'ami : un tuyau sur les pêcheries...";
			link.l1.go = "NewDeckSharp_2";
		break;
		case "NewDeckSharp_2":
			if (pchar.questTemp.Sharp.SeekSpy == "alwaysKnow" || pchar.questTemp.Sharp.SeekSpy == "over")
			{
				chrDisableReloadToLocation = false;
				npchar.location = "none";
				Map_ReleaseQuestEncounter(npchar.id);
				dialog.text = "Vous savez, "+ GetSexPhrase("l'ami", "ma chérie") +", j'ai un problème avec cette affaire. J'ai perdu un homme de confiance de l'équipage, et avec lui... Bref, je ne sais pas oם sont les pêcheurs.";
				link.l1 = "Oui, c'est triste... Bon, c'est la vie. Adieu, Sharp.";
				link.l1.go = "exit";
				CloseQuestHeader("SharpPearl");
				NextDiag.TempNode = "DeckSharp_noWork";
				pchar.questTemp.Sharp = "over";
			}
			else
			{
				dialog.text = "Hum, c'est sמrement une bonne affaire. Mais je ne peux pas user de ma source pour toi, "+ GetSexPhrase("l'ami ", "ma jolie ") +": il faut bien que je vive, moi aussi !";
				link.l1 = "Quelle source dois-je utiliser ?";
				link.l1.go = "NewDeckSharp_3";
			}
		break;
		case "NewDeckSharp_3":
			dialog.text = "Une source ordinaire. "+ GetSexPhrase("דa ne te regarde pas, en fait", "Ne sois pas curieuse, je ne te le dirai pas de toute façon") +".\nBon, je peux te donner un tuyau, mais pas pour rien. Tu dois me dédommager du manque à gagner, "+ GetSexPhrase("l'ami", "ma chérie") +".";
			link.l1 = "Hum, combien veux-tu ?";
			link.l1.go = "NewDeckSharp_4";
		break;
		case "NewDeckSharp_4":
			dialog.text = "Eh bien, je pense qu'une somme de " + FindRussianMoneyString(sti(pchar.questTemp.Sharp.price)) + " me suffira.";
			link.l1 = "Hé, mon ami le capitaine Sharp, qu'est-ce qui te prend ? C'est trop pour moi en ce moment ! Sois sympa, baisse un peu le prix.";
			link.l1.go = "NewDeckSharp_noMoney";
			if (sti(pchar.money) >= sti(pchar.questTemp.Sharp.price))
			{
				link.l2 = "Bon, d'accord, l'ami. Prends ta compensation !";
				link.l2.go = "NewDeckSharp_GiveMoney";
			}
		break;

		case "NewDeckSharp_GiveMoney":
			dialog.text = "Eh bien, parfait ! J'aime cette façon de faire, "+ GetSexPhrase("l'ami", "ma chérie") +".";
			link.l1 = "Parfait. Alors, ce tuyau ?";
			link.l1.go = "DeckSharp_6";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.Sharp.price));
		break;
		case "NewDeckSharp_noMoney":
			if ((sti(pchar.questTemp.Sharp.price)*10) < sti(pchar.money))
			{
				if (pchar.location == "Deck_Near_Ship")
				{
					dialog.text = ""+ GetSexPhrase("Salut, Hagel ! Qu'est-ce que tu fais, " + pchar.name + " ? Tu m'as pris pour un pigeon ?! Je ne suis pas un menteur, je suis le CAPITAINE SHARP !! דa sonne fier, compris ?! Tu crois que je ne sais pas que tu as beaucoup d'argent ? Je le sais, l'ami, je le sais très bien. Alors, allez, crache ou débarrasse mon pont, aux quatre vents par rapport au sud-ouest !", "Salut, Hagel ! " + pchar.name + ", bien sמr, tu es une fille belle et combative, mais je ne suis pas un menteur, je suis le CAPITAINE SHARP ! דa sonne fier ! Tu crois que je ne sais pas que tu as beaucoup d'argent ? Je le sais, ma chérie, je le sais très bien. Nous avons des relations d'affaires... Hum, dommage, d'ailleurs, que ce ne soient que des affaires. Bref, soit tu craches, soit tu cherches tes plongeurs toute seule") +"..";
					link.l1 = ""+ GetSexPhrase("Bartholomew, qu'est-ce qui te prend de t'emballer comme ça ?! Tu grinces comme un mât... Je ne suis pas venu chez toi pour passer la serpillière ou affמter une ancre. Alors fais attention à ce que tu dis. Souviens-toi à qui tu parles.", "Bartholomew, pourquoi tu t'énerves comme ça ? Fais attention à tes expressions, je ne suis pas une fille de bordel, ne l'oublie pas.") +"...";
				}
				else
				{
					dialog.text = ""+ GetSexPhrase("Tu ne comprends pas, ou tu me prends pour un pigeon ? Pourquoi tu me traites comme ça, tu crois que je ne sais pas que tu as une jolie somme d'argent ? Je le sais, l'ami, je le sais très bien. Alors, allez, crache, ou cherche les pêcheurs de perles quelque part au sud-sud-est d'ici, par exemple.", "Hé, " + pchar.name + ", tu essaies de me rouler ? Tu crois que je ne sais pas que tu as une jolie somme d'argent ? Je le sais, ma belle, je le sais très bien. Nous avons des relations d'affaires... Du moins pour l'instant. Alors, soit tu partages avec moi, soit tu cherches les pêcheurs de perles quelque part au sud-sud-est d'ici, par exemple.") +"...";
					link.l1 = "Bartholomew, ne commence pas, tu grinces comme un mât. Souviens-toi à qui tu parles...";
				}
				link.l1.go = "NewDeckSharp_5";
			}
			else
			{
				if (sti(pchar.questTemp.Sharp.price.evil))
				{	//Шарп не в настроении
					dialog.text = "Non, "+ GetSexPhrase("l'ami", "ma chérie") +"Pas aujourd'hui ! דa ne va pas fort pour moi non plus, et voilà que tu arrives avec tes demandes. Je ne me suis pas engagé comme mécène. L'argent sur le tonneau, en somme...";
					link.l1 = "Ouais, c'est dommage, Sharp, c'est dommage. Je pensais que tu étais un véritable ami...";
					link.l1.go = "NewDeckSharp_7";
					if (sti(pchar.money) >= sti(pchar.questTemp.Sharp.price))
					{
						link.l2 = "Oui, pas moyen d'y échapper. Mais il me manque vraiment des perles pour un bonheur caribéen complet... Prends ta compensation !";
						link.l2.go = "NewDeckSharp_GiveMoney";
					}
				}
				else
				{
					dialog.text = "Bon, d'accord, soit, aujourd'hui je suis d'une bonté démesurée... Je vais t'aider !";
					link.l1 = "Voilà qui est bien ! דa, c'est fraternel, entre Frères de la Cכte !.. Alors, ce tuyau, bienfaiteur Sharp ?";
					link.l1.go = "DeckSharp_6";
				}
			}
		break;
		case "NewDeckSharp_5":
			dialog.text = "Bon, désolé, je me suis emporté. Mais ça ne change rien au fond de l'affaire. Ne fais pas cette tête, " + pchar.name + ", ça n'arrange pas le teint... Bref, l'argent sur le tonneau, ou tu n'auras pas de tuyau.";
			link.l1 = "D'accord, prends ta compensation !";
			link.l1.go = "NewDeckSharp_6";
			link.l2 = "Non, je vais laisser tomber cette affaire. Une autre fois...";
			link.l2.go = "NewDeckSharp_7";
		break;
		case "NewDeckSharp_6":
			dialog.text = "Voilà qui est autre chose ! Je respecte le capitaine et les collègues !"+ GetSexPhrase("", " Et puis, une fille tout simplement merveilleuse !") +"";
			link.l1 = "C'est réciproque, Sharp, c'est réciproque. Alors, ce tuyau ?";
			link.l1.go = "DeckSharp_6";
			AddMoneyToCharacter(pchar, -sti(pchar.questTemp.Sharp.price));
		break;
		case "NewDeckSharp_7":
			dialog.text = "Eh bien, comme tu voudras. Adieu !";
			link.l1 = "Bonne journée...";
			link.l1.go = "NewDeckSharp_7exit";
		break;
		case "NewDeckSharp_7exit":
			AddQuestRecord("SharpPearl", "10");
			CloseQuestHeader("SharpPearl");
			pchar.questTemp.Sharp = "seekSharp"; //опять начинаем с борделей
			pchar.questTemp.Sharp.brothelChance = rand(10);
			NextDiag.TempNode = "DeckSharp_overBad";
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
			if (pchar.location != "Deck_Near_Ship")
			{
				LAi_SetActorTypeNoGroup(npchar);
				LAi_ActorGoToLocation(npchar, "reload", "reload1", "none", "", "", "OpenTheDoors", 15.0);
			}
		break;

		case "DeckSharp_over":
			dialog.text = "On a tout réglé, "+ GetSexPhrase("l'ami", "ma petite") +". א ta place, je ne perdrais pas de temps.";
			link.l1 = "Oui, capitaine Sharp.";
			link.l1.go = "exit";
		break;
		case "DeckSharp_overBad":
			dialog.text = "On en a déjà parlé...";
			link.l1 = "Oui...";
			link.l1.go = "exit";
		break;
		case "DeckSharp_noWork":
			dialog.text = "Je ne peux pas t'aider, "+ GetSexPhrase("mon ami", "ma chérie") +". Je souffre de ne rien faire. Maintenant, il va falloir chasser les galions à nouveau...";
			link.l1 = "Eh bien, bon retour, l'ami !";
			link.l1.go = "exit";
			CloseQuestHeader("SharpPearl");
		break;
		//капитан Шарп, первый разговор в городе на улице
		case "CitySharp":
			if (npchar.quest.meeting == "0")
			{
				dialog.text = "Ah, capitaine " + pchar.name + " ! Je t'écoute attentivement.";
				link.l1 = "Bartholomew, je suis si content de te voir ! J'ai dמ te chercher, mais j'ai eu de la chance dans cette ville...";
				link.l1.go = "CitySharp_1";
				npchar.quest.meeting = true;
			}
			else
			{
				dialog.text = "Oh, qui vois-je dans cette ville ?! C'est le capitaine " + pchar.lastname + ", un collègue et un camarade !";
				link.l1 = "Oui, Bartholomew, c'est moi.";
				link.l1.go = "CitySharp_2";
			}
		break;

		case "CitySharp_1":
			dialog.text = "Alors, à quoi dois-je tant d'attention ?";
			link.l1 = "Tu vois, je vais rendre visite aux pêcheries de perles, et toi, tu es un expert reconnu en la matière.";
			link.l1.go = "DeckSharp_2";
		break;
		case "CitySharp_2":
			dialog.text = ""+ GetSexPhrase("Eh, mon ami, ça fait plaisir de te voir ! Bon, commençons, peut-être... D'abord la taverne, ensuite les filles. Tu préfères quoi, une mulâtresse ou une blanche ? J'ai de ces relations ici, tu vas être secoué", "Ah, " + pchar.name + ", quand je te vois, mon cœur s'arrête déjà") +" !";
			link.l1 = "וcoutez, "+ GetSexPhrase("Sharp", "Bartholomew") +", je n'ai pas la tête à ça en ce moment. Désolé. Je viens te voir pour affaires.";
			link.l1.go = "CitySharp_3";
			//блокировка генератора, если взят грабёж от Моргана
			if (pchar.questTemp.piratesLine == "PearlQ4_toTerks")
			{
				dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +", je suis occupé en ce moment ! Je ne peux rien pour toi. Sans rancune...";
				link.l1 = "D'accord, l'ami...";
				link.l1.go = "exit";
				NextDiag.TempNode = "DeckSharp_overBad";
				pchar.questTemp.Sharp = "seekSharp"; //опять начинаем с борделей
				pchar.questTemp.Sharp.brothelChance = rand(10);
				DeleteAttribute(pchar, "questTemp.Sharp.PearlAreal");
				AddQuestRecord("SharpPearl", "13");
				CloseQuestHeader("SharpPearl");
			}
		break;
		case "CitySharp_3":
			dialog.text = "Bon, euh, "+ GetSexPhrase("ce n'est pas si intéressant", "c'est toujours comme ça") +"... Quelle est l'affaire ?";
			link.l1 = "Oui, j'ai décidé de débarrasser les pêcheurs de perles de leur superflu...";
			link.l1.go = "NewDeckSharp_2";
		break;
		//капитан Шарп в борделе
		case "BrothelSharp":
			dialog.text = ""+ GetSexPhrase("Oh, oh, " + pchar.lastname + " ! Mon ami !! Monte avec moi à l'étage, on va bien s'amuser !!!", "Oh, oh, " + pchar.name + ", c'est toi, ma belle ? Eh bien, maintenant, je vais encore ne penser qu'à toi pendant toute une semaine...") +"";
			link.l1 = ""+ GetSexPhrase("Non, l'ami, je ne peux pas maintenant, je suis occupé", "Allons, Bartholomew, toute une semaine, rien que ça..") +". Je suis là pour affaires.";
			link.l1.go = "BrothelSharp_1";
			//блокировка генератора, если взят грабёж от Моргана
			if (pchar.questTemp.piratesLine == "PearlQ4_toTerks")
			{
				dialog.text = ""+ GetSexPhrase("L'ami", "Ma belle") +"Je suis occupé en ce moment ! Je ne peux rien pour vous. Sans rancune...";
				link.l1 = "D'accord, l'ami...";
				link.l1.go = "exit";
				NextDiag.TempNode = "DeckSharp_overBad";
				pchar.questTemp.Sharp = "seekSharp"; //опять начинаем с борделей
				pchar.questTemp.Sharp.brothelChance = rand(10);
				DeleteAttribute(pchar, "questTemp.Sharp.PearlAreal");
				AddQuestRecord("SharpPearl", "13");
				CloseQuestHeader("SharpPearl");
			}
		break;
		case "BrothelSharp_1":
			dialog.text = ""+ GetSexPhrase("Raconte...", "Oh, je te dis la vérité, " + pchar.name + ", bon, qu'est-ce que tu as ?") +"";
			link.l1 = "Je veux de nouveau rendre visite aux pêcheurs de perles, les secouer un peu.";
			link.l1.go = "NewDeckSharp_2";
		break;
		//Эмилио Гарсиа. в бухте Сан-Хуна дель Норте
		case "SharpSeekSpy_Emi":
			dialog.text = "Bon sang, on nous écoute !!";
			link.l1 = "...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SharpSeekSpy_caveDialog");
		break;
		case "SharpSeekSpy_fri":
			dialog.text = "Ah, c'est le capitaine " + pchar.name + " ! Je ne m'attendais pas à vous voir ici...";
			link.l1 = "Hé, surprise ! On se connaît, l'ami ?";
			link.l1.go = "SharpSeekSpy_fri_1";
		break;
		case "SharpSeekSpy_fri_1":
			dialog.text = "Eh bien, comment dire... Vous ne m'avez peut-être pas remarqué, mais moi, je me souviens bien de vous, quand vous êtes venu sur notre brick, le Sharpnose.";
			link.l1 = "Ha ! Alors tu es de l'équipage de Sharp ?! Je suis donc à la bonne adresse.";
			link.l1.go = "SharpSeekSpy_fri_2";
		break;
		case "SharpSeekSpy_fri_2":
			dialog.text = "Je ne comprends pas ce que vous voulez dire, capitaine.";
			link.l1 = "Tu vois, l'ami, j'étais très curieux de savoir d'oם Sharp tient ses tuyaux sur les tartanes des pêcheurs. Maintenant, je le sais.";
			link.l1.go = "SharpSeekSpy_fri_3";
		break;
		case "SharpSeekSpy_fri_3":
			dialog.text = "Capitaine, Sharp pourrait tuer pour ce secret...";
			link.l1 = "Ouais, et me voilà."+ GetSexPhrase(" J'en ai fait dans mon froc", " J'ai eu peur") +". D'ailleurs, quelqu'un aux pêcheries de perles tient beaucoup à ce secret...";
			link.l1.go = "SharpSeekSpy_fri_4";
		break;
		case "SharpSeekSpy_fri_4":
			dialog.text = "Et qui est cet amateur de mystères ?";
			link.l1 = "Mm-hum...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SharpSeekSpy_caveDialog_2");
		break;
		case "SharpSeekSpy_Emi_1":
			dialog.text = "Ce n'est pas clair ? Un des officiers, bien sמr !\nBref, il faut "+ GetSexPhrase("le", "la") +" tuer. Pour la cause...";
			link.l1 = "Eh bien, essaie donc...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SharpSeekSpy_caveDialog_3");
		break;
		//--------------------------- квест официантки --------------------------------
		//грабитель
		case "WaitressBerglar":
			dialog.text = "Allez, l'ami, vide tes poches.";
			link.l1 = "Quoi ?!";
			link.l1.go = "WaitressBerglar_1";
		break;
		case "WaitressBerglar_1":
			dialog.text = "Allez, vite, sans discuter. Je n'aime pas ça...";
			link.l1 = "C'est un piège !! Et " + pchar.questTemp.different.FackWaitress.Name + ", elle travaille avec vous, c'est ça ?";
			link.l1.go = "WaitressBerglar_2";
		break;
		case "WaitressBerglar_2":
			dialog.text = "En duo, en duo... Retourne tes poches, ou je te plante !";
			link.l1 = "Au diable ! Pour mes poches, c'est moi qui tue n'importe qui...";
			link.l1.go = "WaitressBerglar_fight";
			link.l2 = "Tiens, morveux ! Mais tu ne t'en tireras pas si facilement...";
			link.l2.go = "WaitressBerglar_take";
		break;
		case "WaitressBerglar_take":
			dialog.text = "Bien sמr que ça ne suffira pas, qui dit le contraire ? Eh bien, adieu, mon ami. Et souviens-toi : tu n'es pas assez beau pour que les serveuses se jettent à ton cou sur-le-champ. דa te servira de leçon !";
			link.l1 = "דa, c'est sמr !..";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("WaitressFack_outRoom");
		break;
		case "WaitressBerglar_fight":
			dialog.text = "Eh bien, comme vous voudrez...";
			link.l1 = "Je sais, je sais, l'ami...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("WaitressFack_fight");
		break;
		//официантка
		case "Waitress":
			dialog.text = "Me voilà ! Je t'ai manqué, beau gosse ?";
			link.l1 = "Je n'ai pas eu le temps...";
			link.l1.go = "Waitress_1";
		break;
		case "Waitress_1":
			dialog.text = "Eh bien, alors ne perdons pas de temps !";
			link.l1 = "Hé, d'accord !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("WaitressFack_fack");
		break;
		//--------------------------- догнать кэпа, потерявшего судовой журнал --------------------------------
		//встретил в городе
		case "PortmansCap":
			dialog.text = "Bonjour. Je m'appelle " + GetFullName(npchar) + ". Je suis capitaine de " + GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Acc")) + " '" + npchar.Ship.name + "'.";
			link.l1 = "Parfait ! Je vous ai enfin trouvé.";
			link.l1.go = "PortmansCap_1";
		break;
		case "PortmansCap_1":
			dialog.text = "Trouvé ?!";
			link.l1 = "Oui. Bref, je vous ai apporté votre journal de bord, celui que vous avez oublié chez le capitaine du port de " + XI_ConvertString("Colony" + npchar.quest.firstCity + "Gen") + ".";
			link.l1.go = "PortmansCap_2";
		break;
		case "PortmansCap_2":
			dialog.text = "Diable, c'est donc là que je l'ai « planté » ! Oui, cette perte a failli provoquer une mutinerie à bord...";
			link.l1 = "Eh bien, tout est bien qui finit bien. Prenez votre journal, et parlons de ma rémunération pour ce travail.";
			link.l1.go = "PortmansCap_3";
		break;
		case "PortmansCap_3":
			if (sti(npchar.quest.stepsQty) == 1)
			{
				dialog.text = "Je n'ai pas encore commencé de nouveau journal, j'allais justement le faire, alors je vous paierai le maximum de ce que je peux me permettre : " + FindRussianMoneyString(sti(npchar.quest.money)) + " et quelques-uns de mes bijoux personnels.";
				link.l1 = "Eh bien, pas mal. Prenez votre journal.";
				link.l1.go = "PortmansCap_4";
			}
			else
			{
				if (sti(npchar.quest.stepsQty) < 5)
				{
					npchar.quest.money = makeint(sti(npchar.quest.money) / sti(npchar.quest.stepsQty)); //уменьшаем вознаграждение
					dialog.text = "Hum, vous savez, j'ai déjà commencé un nouveau journal. Cependant, j'ai encore besoin de l'ancien, il faut que je reporte tout dans le nouveau. Je peux donc vous le reprendre pour " + FindRussianMoneyString(sti(npchar.quest.money)) + " et quelques-uns de mes bijoux personnels.";
					link.l1 = "Voilà qui est réglé. Reprenez votre journal !";
					link.l1.go = "PortmansCap_4";
				}
				else
				{
					dialog.text = "C'est que j'ai déjà commencé un nouveau journal. Et j'y ai reporté de mémoire toutes les notes de l'ancien : je suis resté assis à écrire pendant deux jours. Je n'ai donc plus du tout besoin de l'ancien journal. Et je ne peux rien payer pour lui.";
					link.l1 = "Rien du tout ? Je vous ai donc couru après pour rien ?";
					link.l1.go = "PortmansCap_5";
				}
			}
		break;
		case "PortmansCap_4":
			dialog.text = "Merci. Eh bien, bonne journée, "+ GetSexPhrase("l'ami", "ma petite") +".";
			link.l1 = "א vous de même...";
			link.l1.go = "exit";
			sTemp = "Timer_" + npchar.id;
			pchar.quest.(sTemp).over = "yes"; //снимаем таймер на выход в море
			npchar.LifeDay = 2; // через пару дней снимаем кэпа
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			group_DeleteGroup("PorpmansShip_" + npchar.index); //чистим группу, на всякий случай
			sld = characterFromId(npchar.quest.firstCity + "_PortMan");
			sTitle = sld.id + "PortmansBook_Delivery";
			AddQuestRecordEx(sTitle, "PortmansBook_Delivery", "3");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.City + "Dat"));
			AddQuestUserData(sTitle, "sCity2", XI_ConvertString("Colony" + sld.city + "Gen"));
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			sGem = pchar.questTemp.PortmansJornal.gem;
			TakeNItems(pchar, sGem, 12+drand(10));
			DeleteAttribute(pchar, "questTemp.PortmansJornal.gem");
			DeleteAttribute(sld, "quest.PortmansJornal");
			sld.quest = ""; //освобождаем личный флаг квеста для портмана
        	AddCharacterExpToSkill(pchar, "Repair", makeint(400/sti(npchar.quest.stepsQty)));
    		AddMoneyToCharacter(pchar, sti(npchar.quest.money));
    		ChangeCharacterReputation(pchar, 2);
			TakeItemFromCharacter(pchar, "PortmansBook");
			NextDiag.TempNode = "PortmansCap_inDeck_over";
		break;
		case "PortmansCap_5":
			dialog.text = "Hé, quand on s'engage, il faut faire vite.";
			link.l1 = "Hum, c'est vrai aussi... Bon, prenez votre journal, comme ça, pour rien.";
			link.l1.go = "exit";
			sTemp = "Timer_" + npchar.id;
			pchar.quest.(sTemp).over = "yes"; //снимаем таймер на выход в море
			npchar.LifeDay = 2; // через пару дней снимаем кэпа
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			group_DeleteGroup("PorpmansShip_" + npchar.index); //чистим группу, на всякий случай
			sld = characterFromId(npchar.quest.firstCity + "_PortMan");
			sTitle = sld.id + "PortmansBook_Delivery";
			AddQuestRecordEx(sTitle, "PortmansBook_Delivery", "3");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.City + "Dat"));
			AddQuestUserData(sTitle, "sCity2", XI_ConvertString("Colony" + sld.city + "Gen"));
			CloseQuestHeader("Caiman_PortManPortmansBook_Delivery");

			AchievementsCounter_genquests(1);

			DeleteAttribute(sld, "quest.PortmansJornal");
			sld.quest = ""; //освобождаем личный флаг квеста для портмана
        	AddCharacterExpToSkill(pchar, "Repair", makeint(200/sti(npchar.quest.stepsQty)));
			TakeItemFromCharacter(pchar, "PortmansBook");
			NextDiag.TempNode = "PortmansCap_inDeck_over";
		break;
		//догнал в море
		case "PortmansCap_inDeck":
			if (isBadReputation(pchar, 20))
			{
				dialog.text = "Bienvenue sur le pont de mon navire. א vrai dire, j'ai déjà eu peur : je croyais que c'était Steed Hunter le Borgne qui avait décidé de me chasser...";
				link.l1 = "Non, l'ami, je suis bon aujourd'hui. Je vous cherchais pour vous aider.";
			}
			else
			{
				dialog.text = "Bienvenue sur mon pont ! Que vouliez-vous ?";
				link.l1 = "Je vous cherchais, l'ami. J'ai eu du mal à vous rattraper...";
			}
			link.l1.go = "PortmansCap_inDeck_1";
		break;
		case "PortmansCap_inDeck_1":
			dialog.text = "Vous me cherchiez ? Et pourquoi ?";
			link.l1 = "Vous avez oublié votre journal de bord à la capitainerie de " + XI_ConvertString("Colony" + npchar.quest.firstCity + "Gen") + " – je l'ai avec moi ! C'est pour ça que je vous cherchais.";
			link.l1.go = "PortmansCap_inDeck_2";
		break;
		case "PortmansCap_inDeck_2":
			if (sti(npchar.quest.stepsQty) == 1)
			{
				dialog.text = "Bon sang, c'est donc là que je l'ai perdu !.. C'est un service inestimable, mon ami, je n'ai pas de mots. J'ai failli perdre mon statut de capitaine... Merci infiniment.";
				link.l1 = "Et la récompense ?";
				link.l1.go = "PortmansCap_inDeck_3";
			}
			else
			{
				if (sti(npchar.quest.stepsQty) < 5)
				{
					npchar.quest.money = makeint(sti(npchar.quest.money) / sti(npchar.quest.stepsQty)); //уменьшаем вознаграждение
					dialog.text = "Bon sang, c'est donc là que je l'ai perdu !.. Merci, bien sמr, mais le fait est que vous m'avez cherché longtemps, et j'en ai déjà commencé un nouveau. Cependant, j'ai besoin d'y reprendre certaines choses, alors je vais vous reprendre le journal. Mais je ne peux pas payer beaucoup...";
					link.l1 = "Combien pouvez-vous donner ?";
					link.l1.go = "PortmansCap_inDeck_3";
				}
				else
				{
					dialog.text = "Bon sang, c'est donc là que je l'ai perdu !.. Merci, bien sמr, mais le fait est que vous m'avez cherché longtemps, et j'en ai déjà commencé un nouveau. J'ai reporté de mémoire les anciennes notes, je n'en ai donc pas besoin.";
					link.l1 = "Quoi, vous n'avez plus du tout besoin de votre ancien journal ?";
					link.l1.go = "PortmansCap_inDeck_5";
				}
			}
		break;
		case "PortmansCap_inDeck_3":
			dialog.text = "Je suis prêt à vous verser " + FindRussianMoneyString(sti(npchar.quest.money)) + " et à vous donner quelques-uns de mes bijoux personnels. C'est tout ce que je peux me permettre.";
			link.l1 = "Bon, d'accord. Voici votre journal de bord.";
			link.l1.go = "PortmansCap_inDeck_4";
		break;
		case "PortmansCap_inDeck_4":
			dialog.text = "Merci encore. Adieu, mon ami, et portez-vous bien.";
			link.l1 = "Vous aussi, portez-vous bien.";
			link.l1.go = "exit";
			npchar.LifeDay = 30; // через десять дней снимаем кэпа
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			npchar.quest = "over"; //флаг кэпа квест закончен. энкаутер доплывёт до назначения и исчезнет
			sld = characterFromId(npchar.quest.firstCity + "_PortMan");
			sTitle = sld.id + "PortmansBook_Delivery";
			AddQuestRecordEx(sTitle, "PortmansBook_Delivery", "2");
			AddQuestUserData(sTitle, "sTargetCity", XI_ConvertString("Colony" + npchar.quest.targetCity + "Acc"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + sld.city + "Gen"));
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			sGem = pchar.questTemp.PortmansJornal.gem;
			TakeNItems(pchar, sGem, 12+drand(10));
			DeleteAttribute(pchar, "questTemp.PortmansJornal.gem");
			DeleteAttribute(sld, "quest.PortmansJornal");
			sld.quest = ""; //освобождаем личный флаг квеста для портмана
        	AddCharacterExpToSkill(pchar, "Sailing", makeint(400/sti(npchar.quest.stepsQty)));
    		AddMoneyToCharacter(pchar, sti(npchar.quest.money));
    		ChangeCharacterReputation(pchar, 5);
			TakeItemFromCharacter(pchar, "PortmansBook");
			npchar.DeckDialogNode = "PortmansCap_inDeck_over";
			NextDiag.TempNode = "PortmansCap_inDeck_over";
		break;
		case "PortmansCap_inDeck_5":
			dialog.text = "Absolument, mon ami : vous m'avez cherché trop longtemps, il fallait vous dépêcher.";
			link.l1 = "Hé, j'aurais dמ garder le journal, comme ça on ne se serait pas servi de moi. Bon, prenez votre journal gratuitement, je n'en ai pas besoin non plus.";
			link.l1.go = "exit";
			npchar.LifeDay = 30; // через десять дней снимаем кэпа
			SaveCurrentNpcQuestDateParam(npchar, "LifeTimeCreate");
			npchar.quest = "over"; //флаг кэпа квест закончен. энкаутер доплывёт до назначения и исчезнет
			sld = characterFromId(npchar.quest.firstCity + "_PortMan");
			sTitle = sld.id + "PortmansBook_Delivery";
			AddQuestRecordEx(sTitle, "PortmansBook_Delivery", "2");
			AddQuestUserData(sTitle, "sTargetCity", XI_ConvertString("Colony" + npchar.quest.targetCity + "Acc"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + sld.city + "Gen"));
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);

			DeleteAttribute(sld, "quest.PortmansJornal");
			sld.quest = ""; //освобождаем личный флаг квеста для портмана
        	AddCharacterExpToSkill(pchar, "Sailing", makeint(200/sti(npchar.quest.stepsQty)));
			TakeItemFromCharacter(pchar, "PortmansBook");
			npchar.DeckDialogNode = "PortmansCap_inDeck_over";
			NextDiag.TempNode = "PortmansCap_inDeck_over";
		break;
		case "PortmansCap_inDeck_over":
			dialog.text = "Il semble que tout soit déjà réglé.";
			link.l1 = "Oui, c'est vrai...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PortmansCap_inDeck_over";
		break;
		//--------------------------- розыск украденного корабля --------------------------------
		case "SeekCap_inDeck":
			dialog.text = "Salutations. Que vous faut-il sur mon navire ?";
			link.l1 = "Rien de spécial, je voulais échanger des nouvelles. Vous avez peut-être quelque chose à vendre...";
			link.l1.go = "SeekCap_inDeck_1";
		break;
		case "SeekCap_inDeck_1":
			dialog.text = "Rien n'est à vendre, et je n'ai pas de nouvelles. Et d'ailleurs, à vrai dire, votre présence sur mon pont n'est pas souhaitée. J'ai été clair, j'espère ?";
			link.l1 = "Oui, c'est beaucoup plus clair... Bon, adieu, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "SeekCap_inDeck_over";
			sld = characterFromId(npchar.quest.cribCity + "_PortMan");
			sTitle = sld.id + "Portmans_SeekShip";
			AddQuestRecordEx(sTitle, "Portmans_SeekShip", "4");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.quest.cribCity + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName)));
		break;
		case "SeekCap_inDeck_over":
			dialog.text = "Je vous ai dit que vous n'aviez rien à faire ici !";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
			NextDiag.TempNode = "SeekCap_inDeck_over";
		break;
		//абордаж
		case "SeekCap":
			dialog.text = "Pourquoi nous avez-vous attaqués ?!!";
			link.l1 = "Je dois rendre le navire à son propriétaire.";
			link.l1.go = "SeekCap_1";
		break;
		case "SeekCap_1":
			dialog.text = "Quel propriétaire ?! Le propriétaire, c'est moi !";
			link.l1 = "Non, ce n'est pas comme ça. א qui appartient le navire, je l'ignore, mais je sais qu'il a été volé à son mouillage dans un des ports. Je dois le remettre à sa place.";
			link.l1.go = "SeekCap_2";
		break;
		case "SeekCap_2":
			dialog.text = "Diable ! Eh bien, tout n'est pas encore perdu pour moi. Je vais quand même essayer de t'envoyer dans l'autre monde...";
			link.l1 = "Eh bien, essaie...";
			link.l1.go = "SeekCap_3";
		break;
		case "SeekCap_3":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//--------------------------- ночное бдение в церкви --------------------------------
		case "ChurchBerglar":
			dialog.text = "דa alors ! Qu'est-ce que vous faites ici ?!";
			link.l1 = "Je garde l'église.";
			link.l1.go = "ChurchBerglar_1";
		break;
		case "ChurchBerglar_1":
			dialog.text = "Hé, ça alors... Et comment ça se passe ?";
			link.l1 = "On dirait que ça se passe.";
			link.l1.go = "ChurchBerglar_2";
		break;
		case "ChurchBerglar_2":
			dialog.text = "Désolé, bien sמr, "+ GetSexPhrase("mon ami", "ma belle") +", mais tu ne peux pas sortir d'ici. Je suis vraiment désolé, tu n'aurais pas dמ te charger de cette garde...";
			link.l1 = "Ha ! Moi, je ne suis pas désolé du tout. Piller des églises, c'est trop. Alors je vais t'envoyer rejoindre tes ancêtres sans le moindre remords.";
			link.l1.go = "ChurchBerglar_fight";
		break;
		case "ChurchBerglar_fight":
			LAi_LocationFightDisable(&locations[FindLocation(pchar.location)], false);
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck("EnemyFight", "CannotFightCurLocation");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//--------------------------- поиск кэпов, дача квеста горожанином --------------------------------
		//========= квесты мужиков ===========
		case "SCQ_man":
			/*dialog.text = LinkRandPhrase("Hello, Captain. I want to ask you to help me.",
				"Captain! Would you do me a favor? The fact is, I need help.",
				"Captain, I'm asking for your help!");
			link.l1 = 
			link.l1.go = "SCQ_exit";
			link.l2 = RandPhraseSimple("What's the matter with you?", "State the essence of the problem. Maybe I can help.");
			link.l2.go = "SCQ_man_1";*/
			dialog.text = "Bonjour, capitaine. Puis-je vous parler ?";
			link.l1 = RandPhraseSimple("Je suis occupé. Pas aujourd'hui.", "Je n'ai pas le temps de vous écouter en ce moment.");
			link.l1.go = "SCQ_exit";
			link.l2 = "Qu'est-ce qui vous arrive ?";
			link.l2.go = "SCQ_man_1";
		break;
		case "SCQ_exit":
			//минус один шанс, что следующий квестодатель сам заговорит
			sld = &locations[FindLocation(npchar.location)];
			if(!CheckAttribute(sld, "questSeekCap")) sld.questSeekCap = 0;
			if (sti(sld.questSeekCap) > 0) sld.questSeekCap = sti(sld.questSeekCap)-1;
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
			DeleteAttribute(npchar, "talker");
            DialogExit();
		break;
		case "SCQ_exit_clear":
			//минус один шанс, что следующий квестодатель сам заговорит
			sld = &locations[FindLocation(npchar.location)];
			if (sti(sld.questSeekCap) > 0) sld.questSeekCap = sti(sld.questSeekCap)-1;
			sld = characterFromId(npchar.quest.SeekCap.capId); //капитан
			sld.lifeDay = 0;
			Map_ReleaseQuestEncounter(sld.id);
			string sGroup = "SeekCapShip_" + sld.index;
			group_DeleteGroup(sGroup);
			sTemp = "SCQ_" + sld.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть кэпа
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть квестодателя
			npchar.lifeDay = 0;
			LAi_CharacterDisableDialog(npchar);
            DialogExit();
		break;
		//выбираем квест
		case "SCQ_man_1":
			/*switch (npchar.quest.SeekCap.numQuest)
			{
				case "0":
					dialog.text = "A year ago, a captain undertook to deliver me" + XI_ConvertString("Colony" + SelectNotEnemyColony(NPChar) + "Acc") + But on board his ship, I was thrown into the hold and then sold into slavery. I got out of this mess with great difficulty, several times I was on the verge of life and death... Anyway, I want to remind my 'friend' that I'm still alive.";
					link.l1 = "What do you mean? Describe exactly what you want.";
					link.l1.go = "SCQ_Slave";
				break;
				case "1":
					dialog.text = "The fact is that my wife was kidnapped. One captain, a pirate, was rumored to be courting her here as best he could. At one time, his wife did not even leave the house, he was so annoying. I tried to involve the city authorities in this problem, to no avail. And so we waited, it's called...";
					link.l1 = "What did you wait for?";
					link.l1.go = "SCQ_RapeWife";
				break;
				case "2":
					dialog.text = "You know, I'm looking for my countryman, with whom three years ago we went here from the Old World in search of a new life. It so happened that we lost each other on the road. But recently I found out that my countryman has become a merchant captain! I've been trying to find him, but I can't handle it on my own.";
					link.l1 = "Why? A lot of captains, including me, can take you anywhere.";
					link.l1.go = "SCQ_Friend";
				break;
			}*/
			switch (npchar.quest.SeekCap.numQuest)
			{
				case "0":
					dialog.text = "Le fait est qu'on m'apprend le latin à l'église du coin, mais je n'ai personne avec qui m'exercer pendant mon temps libre...";
					link.l1 = "Apprendre le latin, c'est louable, mais qu'est-ce que j'ai à voir avec ça ?";
					link.l1.go = "SCQ_ProverkaZnaniy";
				break;
				case "1":
					dialog.text = "Le fait est qu'on m'apprend le latin à l'église du coin, mais je n'ai personne avec qui m'exercer pendant mon temps libre...";
					link.l1 = "Apprendre le latin, c'est louable, mais qu'est-ce que j'ai à voir avec ça ?";
					link.l1.go = "SCQ_ProverkaZnaniy";
				break;
				case "2":
					dialog.text = "Le fait est qu'on m'apprend le latin à l'église du coin, mais je n'ai personne avec qui m'exercer pendant mon temps libre...";
					link.l1 = "Apprendre le latin, c'est louable, mais qu'est-ce que j'ai à voir avec ça ?";
					link.l1.go = "SCQ_ProverkaZnaniy";
				break;
			}
		break;
		//Латынь - Sinistra
		case "SCQ_ProverkaZnaniy":
			dialog.text = "Je vais bientכt passer l'examen, et je ne suis même pas sמr de mes connaissances. Vous voulez bien m'aider ?";
			link.l1 = "Euh... Et que dois-je faire ?";
			link.l1.go = "SCQ_ProverkaZnaniy_2";
			link.l2 = "Je n'ai rien d'autre à faire...";
			link.l2.go = "SCQ_exit";
		break;
		
		case "SCQ_ProverkaZnaniy_2":
			dialog.text = "Je vais vous dire une phrase en latin, et vous devrez la répéter après moi sans faute. Je vous donne 16 secondes pour ça. Si vous réussissez en moins de 16 secondes, j'augmenterai votre récompense. Vous êtes prêt ?";
			link.l1 = "Essayons. Allez-y !";
			link.l1.go = "SCQ_ProverkaZnaniy_3";
			link.l2 = "Je suis capitaine, pas polyglotte. Pardonnez-moi.";
			link.l2.go = "SCQ_exit";
		break;
		
		case "SCQ_ProverkaZnaniy_3":
			Log_info("Vous devez répéter le texte en 16 secondes");
			SetShowTimer(16.0);
			DoQuestCheckDelay("SCQ_Zachet_Skorostrel", 8.0);
			DoQuestCheckDelay("SCQ_Zachet_VremyVishlo", 15.6);
			pchar.StudentZachet = npchar.id;
			int Phrase;
			Phrase = rand(23);
			Link.l1.edit = 1;
			Link.l1 = "";
			link.l1.go = "SCQ_ProverkaZnaniy_4";
			if (Phrase == 0)
			{
				dialog.text = "aktum atke tractatum visema";
			break;
			}
			if (Phrase == 1)
			{
				dialog.text = "Abeunt Studio in mores fiat";
			break;
			}
			if (Phrase == 2)
			{
				dialog.text = "kunkta supersilio moventis";
			break;
			}
			if (Phrase == 3)
			{
				dialog.text = "desies reheartia placebitum";
			break;
			}
			if (Phrase == 4)
			{
				dialog.text = "et fabula partem veris abet";
			break;
			}
			if (Phrase == 5)
			{
				dialog.text = "omo omini lopus est dongrat";
			break;
			}
			if (Phrase == 6)
			{
				dialog.text = "letum non omnia finit denov";
			break;
			}
			if (Phrase == 7)
			{
				dialog.text = "memento kuya pulvis espunir";
			break;
			}
			if (Phrase == 8)
			{
				dialog.text = "nec sutor ultra crepidam s";
			break;
			}
			if (Phrase == 9)
			{
				dialog.text = "omnis ars imitatio es natur";
			break;
			}
			if (Phrase == 10)
			{
				dialog.text = "porta di itinari longissima";
			break;
			}
			if (Phrase == 11)
			{
				dialog.text = "reheartio est mater studiorum";
			break;
			}
			if (Phrase == 12)
			{
				dialog.text = "Ciro do venintibus ossa sapit";
			break;
			}
			if (Phrase == 13)
			{
				dialog.text = "silentium est aurum nikhil kur";
			break;
			}
			if (Phrase == 14)
			{
				dialog.text = "sudore et sanguine periculum";
			break;
			}
			if (Phrase == 15)
			{
				dialog.text = "Tempus edax rerum veritas ne";
			break;
			}
			if (Phrase == 16)
			{
				dialog.text = "te amo est verum turbinem encore";
			break;
			}
			if (Phrase == 17)
			{
				dialog.text = "usus es optimus magister patri";
			break;
			}
			if (Phrase == 18)
			{
				dialog.text = "ut tensio sik vis poena negoti";
			break;
			}
			if (Phrase == 19)
			{
				dialog.text = "Vinum verba ministerium meridim";
			break;
			}
			if (Phrase == 20)
			{
				dialog.text = "ansia philosophi anima bellum";
			break;
			}
			if (Phrase == 21)
			{
				dialog.text = "annus oribilis pluvialis mundi";
			break;
			}
			if (Phrase == 22)
			{
				dialog.text = "ignis et akya kausa sitio ubi";
			break;
			}
			if (Phrase == 23)
			{
				dialog.text = "Ingustis Amisi appliance camera";
			break;
			}
		break;
		
		case "SCQ_ProverkaZnaniy_4":
			if ("aktum atke tractatum visema" == GetStrSmallRegister(dialogEditStrings[1]) || "abeunt studio in mores fiat" == GetStrSmallRegister(dialogEditStrings[1]) || "kunkta supersilio moventis" == GetStrSmallRegister(dialogEditStrings[1]) || "desies reheartia placebitum" == GetStrSmallRegister(dialogEditStrings[1]) 
				|| "et fabula partem veris abet" == GetStrSmallRegister(dialogEditStrings[1]) || "omo omini lopus est dongrat" == GetStrSmallRegister(dialogEditStrings[1]) || "letum non omnia finit denov" == GetStrSmallRegister(dialogEditStrings[1]) || "memento kuya pulvis espunir" == GetStrSmallRegister(dialogEditStrings[1])
				|| "nec sutor ultra crepidam s" == GetStrSmallRegister(dialogEditStrings[1]) || "omnis ars imitatio es natur" == GetStrSmallRegister(dialogEditStrings[1]) || "porta di itinari longissima" == GetStrSmallRegister(dialogEditStrings[1]) || "reheartio est mater studiorum" == GetStrSmallRegister(dialogEditStrings[1])
				|| "ciro do venintibus ossa sapit" == GetStrSmallRegister(dialogEditStrings[1]) || "silentium est aurum nikhil kur" == GetStrSmallRegister(dialogEditStrings[1]) || "sudore et sanguine periculum" == GetStrSmallRegister(dialogEditStrings[1]) || "tempus edax rerum veritas ne" == GetStrSmallRegister(dialogEditStrings[1])
				|| "te amo est verum turbinem encore" == GetStrSmallRegister(dialogEditStrings[1]) || "usus es optimus magister patri" == GetStrSmallRegister(dialogEditStrings[1]) || "ut tensio sik vis poena negoti" == GetStrSmallRegister(dialogEditStrings[1]) || "vinum verba ministerium meridim" == GetStrSmallRegister(dialogEditStrings[1])
				|| "ansia philosophi anima bellum" == GetStrSmallRegister(dialogEditStrings[1]) || "annus oribilis pluvialis mundi" == GetStrSmallRegister(dialogEditStrings[1]) || "ignis et akya kausa sitio ubi" == GetStrSmallRegister(dialogEditStrings[1]) || "ingustis amisi appliance camera" == GetStrSmallRegister(dialogEditStrings[1]))
			{
				Dialog.text = "Excellent, vous parlez bien latin, capitaine. Maintenant, je suis absolument sמr de réussir l'examen ! Voici votre récompense : "+ sti(iMoney) +" piastres.";
				Link.l1 = "Ce n'était pas difficile. Bonne chance à vous !";
				Link.l1.go = "SCQ_Proverka_Znani_Final";
				
				Event("QuestDelayExit", "sl", "", 0);
				DeleteAttribute(pchar, "showTimer");
				ClearAllLogStrings();
				
				AddMoneyToCharacter(pchar, sti(iMoney));
				if (!CheckAttribute(pchar, "questTemp.SCQ_Zachet_Skorostrel"))
				{
					Dialog.text = "INCROYABLE ! Vous parlez parfaitement latin ! Maintenant, je suis motivé pour passer l'examen, et je réussirai sans faute ! Merci, mon ami. Voici votre récompense : "+ sti(iMoney) +" piastres et un passe-partout.";
					TakeNItems(PChar, "Lockpick", 1);
					Log_info("Vous avez reçu un passe-partout");
					PlaySound("Interface\important_item.wav");
				}
				AddCharacterExpToSkill(pchar, "Leadership", 30);
				AddCharacterExpToSkill(pchar, "Commerce", 30);
				break;
			}
			else
			{
				Dialog.text = "Non ! Ce n'est pas ça ! Vous êtes un capitaine bien inculte, je n'aurais pas dמ vous demander.";
				Link.l1 = "Eh bien, fiche le camp.";
				Link.l1.go = "SCQ_Proverka_Znani_Final";
				
				Event("QuestDelayExit", "sl", "", 0);
				DeleteAttribute(pchar, "showTimer");
				ClearAllLogStrings();
			}
		break;
		
		case "SCQ_Proverka_Znani_Final":
			DialogExit();
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
			LAi_SetCitizenType(npchar);
			DeleteAttribute(npchar, "talker");
			DeleteAttribute(pchar, "StudentZachet");
			DeleteAttribute(pchar, "questTemp.SCQ_Zachet_Skorostrel");
		break;
		
		case "SCQ_Proverka_Znani_VremyVishlo":
			Log_info("Vous n'avez pas réussi");
			dialog.text = "Vous ne savez même pas aligner deux mots. Je n'aurais pas dמ vous demander...";
			link.l1 = "Eh bien, fiche le camp.";
			link.l1.go = "SCQ_Proverka_Znani_Final";
		break;
		
		// квест бывшего раба, которого негодяй-кэп взял в плен
		case "SCQ_Slave":
			dialog.text = "Je veux que vous le trouviez et que vous l'envoyiez dans l'autre monde. J'ai tellement soif de vengeance que je n'arrive même plus à manger...";
			link.l1 = "Je vois... Je pense pouvoir vous aider à l'occasion. Dites-moi le nom du capitaine et celui du navire sur lequel il navigue.";
			link.l1.go = "SCQ_Slave_1";
			link.l2 = "Désolé, ça ne m'intéresse pas.";
			link.l2.go = "SCQ_exit";
		break;
		case "SCQ_Slave_1":
			npchar.quest.SeekCap = "manSlave"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, PIRATE);
			dialog.text = "Le capitaine s'appelle " + npchar.quest.SeekCap.capName + ". Il navigue sur un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")) + " nommé '" + npchar.quest.SeekCap.shipName + "'. Pour ce travail, je vous paierai " + FindRussianMoneyString(sti(npchar.quest.money)) + " et tous mes bijoux personnels.";
			link.l1 = "Je vois. Bon, je serai plus attentif pendant mes voyages dans les Caraïbes. Si je croise ce capitaine, il est fichu...";
			link.l1.go = "SCQ_Slave_2";
			link.l2 = "Je ne lèverai pas le petit doigt pour une telle somme. Cherchez un imbécile ailleurs.";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_Slave_2":
			dialog.text = "Ouf, voilà ce que je rêvais d'entendre !.. Oh, je peux déjà manger ! Je devrais prendre un en-cas...";
			link.l1 = "Allez, l'ami. Dès que j'aurai fait le travail, je viendrai te trouver ici, en ville.";
			link.l1.go = "SCQ_Slave_3";
		break;
		case "SCQ_Slave_3":
			dialog.text = "D'accord, je vous attendrai à l'église du coin. Ensuite, je vous paierai.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_manResult";
			sTitle = npchar.city + "SCQ_manSlave";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_manSlave", "1");
			AddQuestUserDataForTitle(sTitle, "sName", GetFullName(npchar));
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sName2", GetFullName(npchar));
		break;
		//пират похитил жену у ситизена
		case "SCQ_RapeWife":
			dialog.text = "Mon inaction relative a eu de tristes conséquences. Ce salaud a enlevé ma femme et l'a emmenée en mer sur son navire. Je vous demande de retrouver cette canaille !";
			link.l1 = "Hum, eh bien, pourquoi irais-je me brouiller avec mes collègues ?";
			link.l1.go = "SCQ_RapeWife_1";
		break;
		case "SCQ_RapeWife_1":
			npchar.quest.SeekCap = "manRapeWife"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, PIRATE);
			makearef(forName, npchar.quest.SeekCap);
			forName.nation = npchar.nation;
			forName.sex = "woman";
			SetRandomNameToCharacter(forName); //npchar.quest.SeekCap.name - имя жены ситизена
			forName.lastname = npchar.lastname; //фамилия как и у мужа есно
			dialog.text = "Je ne suis pas riche, mais je donnerai volontiers tout ce que j'ai ! Si vous libérez ma femme et me la ramenez, je vous paierai " + FindRussianMoneyString(sti(npchar.quest.money)) + " et je vous donnerai tous mes bijoux personnels.";
			link.l1 = "Hum, bon, je suis prêt à m'occuper de cette affaire. Comment s'appelle ce capitaine si amoureux, quel navire a-t-il ? Et comment s'appelle votre femme ?";
			link.l1.go = "SCQ_RapeWife_2";
			link.l2 = "Non, l'ami, pour une telle somme, je ne m'en charge pas. Désolé...";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_RapeWife_2":
			dialog.text = "Elle s'appelle " + npchar.quest.SeekCap.name + ". Ce salaud de capitaine s'appelle " + npchar.quest.SeekCap.capName + ", il navigue sur un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")) + " nommé '" + npchar.quest.SeekCap.shipName + "'.";
			link.l1 = "Tu sais ce qui flotte, l'ami : les déchets. Les capitaines, eux, naviguent...";
			link.l1.go = "SCQ_RapeWife_3";
		break;
		case "SCQ_RapeWife_3":
			dialog.text = "Oui, oui, bien sמr, excusez-moi ! Je ne suis pas marin, vous savez...";
			link.l1 = "Ce n'est rien, ne vous en faites pas. Bon, maintenant, attendez-moi avec les résultats des recherches.";
			link.l1.go = "SCQ_RapeWife_4";
		break;
		case "SCQ_RapeWife_4":
			dialog.text = "Merci infiniment ! Je vous attendrai à l'église du coin. Mais je vous en supplie, dépêchez-vous. J'ai très peur pour ma femme...";
			link.l1 = "Je ferai tout ce que je peux. Attendez.";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_manResult";
			sTitle = npchar.city + "SCQ_manRapeWife";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_manRapeWife", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sName2", npchar.quest.SeekCap.name + " " + npchar.quest.SeekCap.lastname);
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
		break;
		//поиски земляка
		case "SCQ_Friend":
			dialog.text = "Le fait est que mon compatriote n'a pas acquis de biens immobiliers ici. Sa maison, c'est son navire. Il m'est donc très difficile de l'attraper, il est sans cesse en mouvement. Et je ne peux pas me permettre de perdre mon temps en voyages inutiles, je dois gagner ma vie.";
			link.l1 = "Si vous n'avez pas d'argent, je ne peux rien faire pour vous...";
			link.l1.go = "SCQ_Friend_1";
		break;
		case "SCQ_Friend_1":
			npchar.quest.SeekCap = "manFriend"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, sti(npchar.nation));
			dialog.text = "Je peux vous payer " + FindRussianMoneyString(sti(npchar.quest.money)) + " pour ce travail, et je vous donnerai tous mes bijoux personnels. C'est tout ce que je peux me permettre pour l'instant.";
			link.l1 = "La somme me convient, je suis prêt à m'en charger. D'ailleurs, vous pouvez venir avec moi comme passager : ainsi, vous n'aurez pas à rejoindre votre compatriote quand il sera retrouvé.";
			link.l1.go = "SCQ_Friend_2";
			link.l2 = "C'est trop peu pour moi. Alors cherchez quelqu'un d'autre pour cette affaire.";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_Friend_2":
			dialog.text = "Non, je crois que je vais rester ici. Je ne sais pas combien de temps les recherches dureront, et je risque de manquer d'argent. Et ici, j'ai du travail.";
			link.l1 = "Je comprends. Bon, dites-moi maintenant qui est votre ami et quel navire il a.";
			link.l1.go = "SCQ_Friend_3";
		break;
		case "SCQ_Friend_3":
			dialog.text = "Il s'appelle " + npchar.quest.SeekCap.capName + ". א ce que je sais, il a un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Gen")) + " nommé '" + npchar.quest.SeekCap.shipName + "'.";
			link.l1 = "Je vois. Eh bien, dès que je croiserai votre compatriote, je lui dirai sans faute que vous le cherchez.";
			link.l1.go = "SCQ_Friend_4";
		break;
		case "SCQ_Friend_4":
			dialog.text = "Merci. J'attendrai votre arrivée à l'église du coin. Je suppose que je devrai vous payer une fois le travail fait.";
			link.l1 = "Bien sמr. Bon, bonne journée, attendez le résultat des recherches.";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_manResult";
			sTitle = npchar.city + "SCQ_manFriend";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_manFriend", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sSex1", GetSexPhrase("", "e"));
		break;

		// --- результаты мужских квестов ---
		case "SCQ_manResult":
			dialog.text = "Bonjour, capitaine. Y a-t-il des résultats pour mon affaire ?";
			link.l1 = "Rappelez-moi, de quoi s'agissait-il ?";
			link.l1.go = "SCQ_manResult_exit";
			switch (npchar.quest.SeekCap)
			{
				case "manSlaveover":
					dialog.text = "א votre air, je devine que j'ai enfin été vengé. C'est bien ça ?";
					link.l1 = "Exactement. " + npchar.quest.SeekCap.capName + " est mort, et son navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName)) + " est par le fond.";
					link.l1.go = "SCQR_manSlave";
				break;
				case "manRapeWifeover":
					dialog.text = "Vous avez retrouvé ma femme ! C'est vrai ?!";
					link.l1 = "Vraiment. Elle est sur mon navire, comme passagère. Vous pouvez la reprendre, si " + npchar.quest.SeekCap.name + " " + npchar.quest.SeekCap.lastname + " est bien votre femme...";
					link.l1.go = "SCQR_manRapeWife";
				break;
				case "manFriendover":
					dialog.text = "Bonjour, capitaine. Avez-vous retrouvé mon compatriote ?";
					link.l1 = "Oui, je l'ai retrouvé. Je lui ai dit que vous l'attendiez ici. Tout s'est donc bien terminé.";
					link.l1.go = "SCQR_manFriend";
				break;
			}
		break;
		case "SCQ_manResult_exit":
			switch (npchar.quest.SeekCap)
			{
				case "manSlave":
					dialog.text = "Quoi, vous avez oublié que je vous ai engagé pour me venger d'un capitaine nommé " + npchar.quest.SeekCap.capName + " pour l'année que j'ai passée en esclavage ?!";
					link.l1 = "Je n'ai rien oublié.. Je m'en occupe, patientez.";
					link.l1.go = "exit";
				break;
				case "manRapeWife":
					dialog.text = "Je n'en crois pas mes oreilles ! Vous avez oublié que vous m'aviez promis de retrouver et de libérer ma femme ? Elle a été enlevée par un pirate nommé " + npchar.quest.SeekCap.capName + " !";
					link.l1 = "Je n'ai pas oublié votre femme. C'est juste que les recherches n'ont encore rien donné. Ce n'est pas si simple, patientez...";
					link.l1.go = "exit";
				break;
				case "manFriend":
					dialog.text = "Attendez... Vous avez oublié votre promesse de retrouver mon compatriote, un capitaine marchand nommé " + npchar.quest.SeekCap.capName + " ?";
					link.l1 = "Je n'ai pas oublié, mais je ne l'ai pas encore trouvé. Patientez...";
					link.l1.go = "exit";
				break;
			}
		break;

		case "SCQR_manSlave":
			dialog.text = "Excellent, je ne me suis pas trompé sur vous ! Donc, comme convenu, voici vos " + FindRussianMoneyString(sti(npchar.quest.money)) + " et des bijoux. Merci pour votre dur labeur.";
			link.l1 = "Hum, je vous en prie...";
			link.l1.go = "SCQ_exit";
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 10+drand(8));
			sTitle = npchar.city + "SCQ_manSlave";
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);
		break;
		case "SCQR_manRapeWife":
			dialog.text = "Mon Dieu, vous m'avez littéralement ramené à la vie ! Recevez, je vous prie, vos " + FindRussianMoneyString(sti(npchar.quest.money)) + " et des bijoux. Et sachez que nous prierons pour vous jusqu'à la fin de nos jours !";
			link.l1 = "Priez, ça ne me dérange pas.";
			link.l1.go = "SCQ_exit";
			sld = characterFromId("manRapeWife_" + npchar.City);
			RemovePassenger(pchar, sld);
			sld.lifeDay = 0;
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 12+drand(8));
			sTitle = npchar.city + "SCQ_manRapeWife";
			CloseQuestHeader(sTitle);
			AddGoodDeed("SCQ_manRapeWife", 3); // Gregg: доброе дело

			AchievementsCounter_genquests(1);
		break;
		case "SCQR_manFriend":
			dialog.text = "Parfait !.. Voici ce que je vous ai promis : " + FindRussianMoneyString(sti(npchar.quest.money)) + " et des bijoux. Et merci, capitaine.";
			link.l1 = "Je t'en prie, l'ami. Adieu...";
			link.l1.go = "SCQ_exit";
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 8+drand(8));
			sTitle = npchar.city + "SCQ_manFriend";
			CloseQuestHeader(sTitle);
			AddGoodDeed("SCQ_manFriend", 3); // Gregg: доброе дело

			AchievementsCounter_genquests(1);
		break;
		//========= квесты баб ===========
		/*case "SCQ_woman":
			dialog.text = LinkRandPhrase("Hello, Captain. I wanted to ask you a favor.",
				"Captain! Help the woman, be so kind...",
				"Captain, do not refuse."+ GetSexPhrase("the lady", "to me") +"help.");
			link.l1 = RandPhraseSimple("I'm busy, beauty, not today!", "I'm sorry, " + GetAddress_FormToNPC(NPChar) + "but I don't have time at the moment...");
			link.l1.go = "SCQ_exit";
			link.l2 = RandPhraseSimple("What's the matter with you, " + GetAddress_FormToNPC(NPChar) + " ?", "State the essence of the problem, " + GetAddress_FormToNPC(NPChar) + ". I will try to help you.");
			link.l2.go = "SCQ_woman_1";
		break;*/
		case "SCQ_woman":
			dialog.text = "Bonjour, capitaine. Puis-je vous parler ?";
			link.l1 = RandPhraseSimple("Pas le temps, ma belle, pas aujourd'hui !", "Désolé, " + GetAddress_FormToNPC(NPChar) + ", mais je n'ai pas le temps en ce moment...");
			link.l1.go = "SCQ_exit";
			link.l2 = "Qu'est-ce qui vous arrive, " + GetAddress_FormToNPC(NPChar) + " ?";
			link.l2.go = "SCQ_woman_1";
		break;
		//выбираем квест
		case "SCQ_woman_1":
			/*switch (npchar.quest.SeekCap.numQuest)
			{
				case "0":
					dialog.text = "My husband is engaged in commerce - delivers goods to merchants all over the district. So, he went to sea more than three months ago, and still hasn't returned!";
					link.l1 = "Do you think something happened to him?";
					link.l1.go = "SCQ_Hasband";
				break;
				case "1":
					dialog.text = ""+ GetSexPhrase("Captain, I look at you and see a brave captain, an excellent thug.", "Captain, I see you are a strong and brave woman, you will shut any man up.") +"...";
					link.l1 = "What are you talking about, " + GetAddress_FormToNPC(NPChar) + " ?";
					link.l1.go = "SCQ_Revenge";
				break;
				case "2":
					dialog.text = "Captain, help me, I beg you! My husband got caught by pirates! Can you save him?";
					link.l1 = "Wait, I don't really understand who got to whom...";
					link.l1.go = "SCQ_Pirates";
				break;
			}*/
			switch (npchar.quest.SeekCap.numQuest)
			{
				case "0":
					dialog.text = "Le fait est que je m'ennuie beaucoup et que je n'ai personne avec qui m'amuser. Peut-être... Vous voulez bien jouer à cache-cache avec moi ?";
					link.l1 = "א cache-cache ? Et quelles sont les règles du jeu ?";
					link.l1.go = "SCQ_Prytki";
				break;
				case "1":
					dialog.text = "Le fait est que je m'ennuie beaucoup et que je n'ai personne avec qui m'amuser. Peut-être... Vous voulez bien jouer à cache-cache avec moi ?";
					link.l1 = "א cache-cache ? Et quelles sont les règles du jeu ?";
					link.l1.go = "SCQ_Prytki";
				break;
				case "2":
					dialog.text = "Le fait est que je m'ennuie beaucoup et que je n'ai personne avec qui m'amuser. Peut-être... Vous voulez bien jouer à cache-cache avec moi ?";
					link.l1 = "א cache-cache ? Et quelles sont les règles du jeu ?";
					link.l1.go = "SCQ_Prytki";
				break;
			}
		break;
		
		//Прятки - Sinistra
		case "SCQ_Prytki":
			dialog.text = "Vous fermez les yeux et vous comptez jusqu'à cinq, et moi, je me cache quelque part dans la ville. Si vous me trouvez, je vous promets que vous ne repartirez pas sans récompense.";
			link.l1 = "Bon, jouons, héhé.";
			link.l1.go = "SCQ_Prytki_1";
			link.l2 = "Non, je ne vais pas jouer à ces jeux d'enfant... Vous feriez mieux de trouver quelqu'un d'autre.";
			link.l2.go = "SCQ_Prytki_Net";
		break;
		
		case "SCQ_Prytki_Net":
			DialogExit();
			
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
			DeleteAttribute(npchar, "talker");
		break;
		
		case "SCQ_Prytki_1":
			dialog.text = "Parfait, maintenant, fermez vos beaux yeux et commencez à compter.";
			link.l1 = "Un... deux... trois...";
			link.l1.go = "SCQ_Prytki_2";
			pchar.DevushkaVPrytki = npchar.id;
		break;
		
		case "SCQ_Prytki_2":
			DialogExit();
			
			SetLaunchFrameFormParam("On ferme les yeux un instant...", "SCQ_Prytki_VremyPoshlo", 0, 2.5);
			LaunchFrameForm();
			InterfaceStates.Buttons.Save.enable = false;
			bDisableFastReload = true;
			chrDisableReloadToLocation = true;
			
			sld = CharacterFromID(pchar.DevushkaVPrytki);
			sld.fixteleport = true;
			if (rand(1) == 0)
			{
				pchar.DvP = PlaceCharacter(sld, RandPhraseSimple("goto", "patrol"), "random_must_be");
			}
			else
			{
				pchar.DvP = PlaceCharacter(sld, "reload", "random_must_be");
			}
			DeleteAttribute(sld, "talker");
			LAi_SetStayType(sld);
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld.quest.questflag.model = "questionmarkB";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
		break;
		
		case "SCQ_Prytki_Dengi":		
			dialog.text = "Oh, hi hi. Vous êtes un bon détective, capitaine, soit, voici vos "+ sti(iMoney) +" piastres.";
			link.l1 = "Merci, ma belle, j'ai été content de passer du temps avec toi. Adieu.";
			link.l1.go = "SCQ_Prytki_Dengi_Final";
			
			Event("QuestDelayExit", "sl", "", 0);
			PChar.quest.SCQ_Prytki_PokinuliZonu.over = "yes";
			DeleteAttribute(pchar, "showTimer");
			DeleteAttribute(pchar, "DvP");
			DeleteAttribute(pchar, "BlockingTalker");
			ClearAllLogStrings();
			
			AddMoneyToCharacter(pchar, sti(iMoney));
			AddCharacterExpToSkill(pchar, "Sneak", 30);
			AddCharacterExpToSkill(pchar, "Fortune", 30);
		break;
		
		case "SCQ_Prytki_Dengi_Final":
			DialogExit();
			npchar.lifeday = 0;
			LAi_CharacterDisableDialog(npchar);
			LAi_SetCitizenType(npchar);
			UnmarkCharacter(npchar);
			InterfaceStates.Buttons.Save.enable = true;
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
		break;
		
		case "SCQ_Prytki_Trah":
			dialog.text = "Oh, hi hi. Vous êtes un bon détective, capitaine. Louons une chambre à la taverne, je vous récompenserai comme il se doit.";
			link.l1 = "Eh bien, allons-y.";
			link.l1.go = "SCQ_Prytki_Trah_2";
			link.l2 = "Désolé, ma petite, mais je viens de me rappeler que j'ai une affaire en suspens. Je dois y aller.";
			link.l2.go = "SCQ_Prytki_Dengi_Final";
			
			Event("QuestDelayExit", "sl", "", 0);
			PChar.quest.SCQ_Prytki_PokinuliZonu.over = "yes";
			DeleteAttribute(pchar, "showTimer");
			DeleteAttribute(pchar, "BlockingTalker");
			ClearAllLogStrings();
			UnmarkCharacter(npchar);
			
			AddCharacterExpToSkill(pchar, "Sneak", 30);
			AddCharacterExpToSkill(pchar, "Fortune", 30);
		break;
		
		case "SCQ_Prytki_Trah_2":
			DoQuestReloadToLocation(npchar.city+"_tavern_upstairs", "quest", "quest4", "SCQ_Prytki_V_Komnate");
			ChangeCharacterAddressGroup(npchar, npchar.city+"_tavern_upstairs", "quest", "quest3");
		break;
		
		case "SCQ_Prytki_Trah_3":
			dialog.text = "Ah, capitaine, j'ai hâte d'être dans vos bras chauds...";
			link.l1 = "Viens ici, ma belle...";
			link.l1.go = "exit";
			
			NextDiag.TempNode = "SCQ_Prytki_Trah_4";
			AddDialogExitQuest("PlaySex_1");
			
			AddCharacterHealth(pchar, 5);
			LAi_SetCurHPMax(pchar);
			ChangeCharacterReputation(pchar, -1);
			AddCharacterExpToSkill(pchar, "Leadership", 30);
			AddCharacterExpToSkill(pchar, "Fencing", -15);
			AddCharacterExpToSkill(pchar, "Pistol", -15);
			if (sti(pchar.money) >= 10) AddMoneyToCharacter(pchar, -10);			
			LAi_SetStayType(npchar);
			npchar.lifeday = 0;
			
			InterfaceStates.Buttons.Save.enable = true;
			bDisableFastReload = false;
			chrDisableReloadToLocation = false;
		break;
		
		case "SCQ_Prytki_Trah_4":
			dialog.text = "C'était génial !";
			link.l1 = "Je suis heureux, ma chatte. Moi aussi, ça m'a plu.";
			link.l1.go = "exit";
			LAi_CharacterDisableDialog(npchar);
		break;
		
		case "SCQ_Prytki_Ooops_Eto_Lovushka":
			dialog.text = "";
			link.l1 = "Bon, nous voilà seuls... Alors, de quelle récompense parlais-tu ?";
			link.l1.go = "SCQ_Prytki_Ooops_Eto_Lovushka_2";
			npchar.lifeday = 0;
		break;
		
		case "SCQ_Prytki_Ooops_Eto_Lovushka_2":
			DialogExit();
			DoQuestCheckDelay("SCQ_Prytki_V_Komnate_Ooops_Eto_Lovushka", 1.2);
			LAi_SetActorType(pchar);
			LAi_ActorTurnToLocator(PChar, "reload", "reload1");
		break;
		
		case "SCQ_Prytki_Ooops_Eto_Lovushka_3":
			dialog.text = "Hé, "+GetSexPhrase("mammouth puant", "ma lapine")+", donne tout ce que tu as de valeur. Sinon, tu le regretteras.";
			link.l1 = "Ah, c'est comme ça... Je ne m'y attendais pas... Eh bien, tu l'as cherché !";
			link.l1.go = "SCQ_Prytki_Ooops_Eto_Lovushka_4";
		break;
		
		case "SCQ_Prytki_Ooops_Eto_Lovushka_4":
			DialogExit();
			for (i=1; i<=2; i++)
			{
				sld = CharacterFromID("Bandit_Prytki_"+i);
				LAi_SetWarriorType(sld);
				LAi_group_MoveCharacter(sld, "EnemyFight");
			}
			LAi_group_SetRelation("EnemyFight", LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups("EnemyFight", LAI_GROUP_PLAYER, false);
			LAi_group_SetCheck("EnemyFight", "SCQ_Prytki_V_Komnate_Final");
			LAi_SetFightMode(pchar, true);
		break;

		//жещина разыскивает мужа-торговца
		case "SCQ_Hasband":
			dialog.text = "Je ne sais pas, mais j'espère vraiment qu'il est juste occupé par son travail. Il aurait pu envoyer un message, il sait que je m'inquiète !";
			link.l1 = "La mer est agitée en ce moment, tout peut arriver...";
			link.l1.go = "SCQ_Hasband_1";
		break;
		case "SCQ_Hasband_1":
			npchar.quest.SeekCap = "womanHasband"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, sti(npchar.nation));
			dialog.text = "Voilà ! Vous voyez de quoi je parle. א votre allure, "+ GetSexPhrase("vous êtes un capitaine courageux", "vous êtes une fille courageuse") +". C'est pourquoi je voulais vous demander de retrouver mon mari. Je suis prête à vous payer pour cela " + FindRussianMoneyString(sti(npchar.quest.money)) + " et à vous donner mes bijoux.";
			link.l1 = "Bien. Si je croise votre mari en mer ou ailleurs, je l'informerai de votre inquiétude. Dites-moi le nom de votre mari et quel navire il a.";
			link.l1.go = "SCQ_Hasband_2";
			link.l2 = "Une telle somme ne m'intéresse pas. Malheureusement, je dois refuser...";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_Hasband_2":
			dialog.text = "Il s'appelle " + npchar.quest.SeekCap.capName + ". Et il travaille sur un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")) + " nommé '" + npchar.quest.SeekCap.shipName + "'.";
			link.l1 = "Je vois. Bon, maintenant, patientez. Et tâchez de rester surtout à l'église, pour que je n'aie pas à vous chercher dans toute la ville...";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_womanResult";
			sTitle = npchar.city + "SCQ_womanHasband";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_womanHasband", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
		break;
		//месть отвергнутой женщины
		case "SCQ_Revenge":
			dialog.text = ""+ GetSexPhrase("Je veux dire, mon cher, que je veux vous engager pour ce que vous savez faire, pour ainsi dire... ", "Je veux que vous m'aidiez. J'espère que vous me comprendrez, entre femmes. ") +"Un capitaine m'a fort contrariée, je voudrais qu'il meure.";
			link.l1 = "Oh, oh, oh ! Mon Dieu ! Et que vous a-t-il fait, ce misérable ?";
			link.l1.go = "SCQ_Revenge_1";
		break;
		case "SCQ_Revenge_1":
			dialog.text = "Ce salaud m'a trompée. Il a fait semblant que je lui plaisais, il m'a même fait la cour. Et il s'est avéré qu'il avait besoin de quelque chose de mon mari ! Et quand cet escroc a obtenu son prêt, il s'est soudain révélé qu'il n'avait rien voulu dire de tel...";
			link.l1 = "Hum, peut-être que c'était vraiment le cas ?";
			link.l1.go = "SCQ_Revenge_2";
		break;
		case "SCQ_Revenge_2":
			dialog.text = "Vous me prenez pour une idiote ?! Je ne saurais pas faire la différence entre une cour et des bavardages ?";
			link.l1 = "Non, voyons...";
			link.l1.go = "SCQ_Revenge_3";
		break;
		case "SCQ_Revenge_3":
			dialog.text = "Il s'est juste servi de moi, ce salaud ! Je ne le lui pardonnerai jamais !..";
			link.l1 = "Hum... Vous ne pourriez pas vous calmer ? Allez, un jour ou deux passeront, et tout changera...";
			link.l1.go = "SCQ_Revenge_4";
		break;
		case "SCQ_Revenge_4":
			dialog.text = "דa va changer ?! "+ GetSexPhrase("Vous êtes un moraliste, pas un pirate", "Apparemment, vous ne vous êtes jamais trouvée dans une telle situation ! Eh oui, qui prendrait le risque... Et moi, je ne suis qu'une faible femme...") +" !";
			link.l1 = ""+ GetSexPhrase("Allons, allons ! ", "") +"Je veux juste savoir à quel point vos intentions sont sérieuses.";
			link.l1.go = "SCQ_Revenge_5";
		break;
		case "SCQ_Revenge_5":
			dialog.text = "Bon sang, "+ GetSexPhrase("vous ne savez tout simplement pas ce qu'est la vengeance d'une femme repoussée", "vous êtes une femme, vous devriez comprendre ce que c'est d'être repoussée ! Je veux me venger") +" !..";
			link.l1 = ""+ GetSexPhrase("C'est vrai, ça ne m'est jamais arrivé", "Vous savez, certaines se contentent de pleurer, c'est tout") +"...";
			link.l1.go = "SCQ_Revenge_6";
		break;
		case "SCQ_Revenge_6":
			dialog.text = ""+ GetSexPhrase("Estimez-vous heureux. Une femme repoussée et déçue dans ses attentes est une furie, un diable en jupons ! Rien ne peut apaiser sa colère", "Mais moi, je ne suis pas comme ça. Et rien ne peut apaiser ma colère") +" !\nAlors je veux que vous le tuiez vous-même. Et avant de mourir, il doit savoir qui a tout organisé...";
			link.l1 = "Hum, je ne sais même pas quoi dire... Et combien êtes-vous prête à payer pour ça ?";
			link.l1.go = "SCQ_Revenge_7";
		break;
		case "SCQ_Revenge_7":
			npchar.quest.SeekCap = "womanRevenge"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, PIRATE);
			dialog.text = "C'est tout ce que j'ai. Je vous donnerai mes bijoux et " + FindRussianMoneyString(sti(npchar.quest.money)) + " ! דa vous conviendra ?";
			link.l1 = "Bon, ça m'intéresse. Dites-moi qui est votre offenseur, de quel navire est-il capitaine ?";
			link.l1.go = "SCQ_Revenge_8";
			link.l2 = ""+ GetSexPhrase("Je vais peut-être faire preuve de solidarité masculine. ", "") +"Je regrette, ce sera sans moi...";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_Revenge_8":
			dialog.text = "Ce gredin s'appelle " + npchar.quest.SeekCap.capName + ", il est capitaine d'un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Acc")) + " nommé '" + npchar.quest.SeekCap.shipName + "'.";
			link.l1 = "Considérez votre commande comme acceptée, " + GetAddress_FormToNPC(NPChar) + ", et attendez-moi à l'église du coin. J'espère que maintenant, vous allez vous détendre un peu...";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_womanResult";
			sTitle = npchar.city + "SCQ_womanRevenge";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_womanRevenge", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipTypeName2", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Gen")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sName2", GetFullName(npchar));
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sSex1", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sSex2", GetSexPhrase("", "e"));
		break;
		//муж женщины попал в плен к пиратам
		case "SCQ_Pirates":
			dialog.text = "Je vais vous expliquer. Le fait est que mon mari, un homme tout à fait ordinaire, a été capturé par des pirates ! Ils ont tué tout le monde, n'ont épargné personne...";
			link.l1 = "C'est donc que le capitaine a osé résister. S'ils s'étaient rendus, personne n'aurait été blessé.";
			link.l1.go = "SCQ_Pirates_1";
		break;
		case "SCQ_Pirates_1":
			dialog.text = "Peut-être, mais mon mari n'y est absolument pour rien. Il n'était qu'un passager sur ce navire. Alors, pour sauver sa vie, il a dמ dire qu'il était fabuleusement riche. Les pirates l'ont épargné, et ne l'ont même pas jeté dans la cale.";
			link.l1 = "Comment le savez-vous ?";
			link.l1.go = "SCQ_Pirates_2";
		break;
		case "SCQ_Pirates_2":
			dialog.text = "Mon mari a réussi à m'envoyer une lettre oם il dit que tout va bien pour lui. On le garde dans une cabine, pas comme les autres prisonniers.";
			link.l1 = "Et que comptez-vous faire ? דa ne peut pas durer longtemps. Tכt ou tard, les pirates finiront par le démasquer.";
			link.l1.go = "SCQ_Pirates_3";
		break;
		case "SCQ_Pirates_3":
			dialog.text = "Vous êtes pirate, vous aussi, n'est-ce pas ? Oui, oui, je sais... Je vous en supplie, aidez-nous, sauvez mon mari ! Dans sa lettre, il a décrit le navire pirate et donné le nom du capitaine. Vous le trouverez assez facilement !";
			link.l1 = "Ce n'est pas aussi simple que vous le croyez. Tous les prisonniers sont la prise légitime du capitaine qui a capturé le navire. Et je ne peux pas faire ça en peu de temps.";
			link.l1.go = "SCQ_Pirates_4";
		break;
		case "SCQ_Pirates_4":
			dialog.text = "Mais vous pouvez essayer ! D'ailleurs, il y a du temps pour les recherches. Mon mari est loin d'être bête : il s'est fait passer pour un marchand de l'Ancien Monde, alors les pirates n'exigent pas tout de suite de l'argent pour lui, c'est trop loin pour aller le chercher. Si vous le libérez, je vous donnerai tout ce que j'ai !";
			link.l1 = "Et qu'avez-vous ?";
			link.l1.go = "SCQ_Pirates_5";
		break;
		case "SCQ_Pirates_5":
			npchar.quest.SeekCap = "womanPirates"; //личный флаг ситизена на квест
			SetSeekCapCitizenParam(npchar, PIRATE);
			dialog.text = "Un petit peu : " + FindRussianMoneyString(sti(npchar.quest.money)) + " et tous mes bijoux... Mais je prierai pour votre âme jusqu'à la fin de mes jours !";
			link.l1 = "Oui, vraiment un petit peu... Bon, soit, je suis prêt à vous aider à l'occasion.";
			link.l1.go = "SCQ_Pirates_6";
			link.l2 = "Désolé, mais c'est trop peu pour que j'attaque un collègue, un membre de la Confrérie.";
			link.l2.go = "SCQ_exit_clear";
		break;
		case "SCQ_Pirates_6":
			dialog.text = "Merci, merci !!";
			link.l1 = "Si tout s'arrange, vous me remercierez ; pour l'instant, ce n'est pas la peine. Dites-moi le nom de votre mari et tout ce que vous savez sur ces pirates.";
			link.l1.go = "SCQ_Pirates_7";
		break;
		case "SCQ_Pirates_7":
			makearef(forName, npchar.quest.SeekCap);
			forName.nation = npchar.nation;
			forName.sex = "man";
			SetRandomNameToCharacter(forName); //npchar.quest.SeekCap.name - имя жены ситизена
			forName.lastname = npchar.lastname; //фамилия как и у жены есно
			dialog.text = "Mon mari s'appelle " + GetFullName(forName) + ". Le capitaine pirate s'appelle " + npchar.quest.SeekCap.capName + ", il sévit sur un navire de type " + GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")) + " nommé '" + npchar.quest.SeekCap.shipName + "'.";
			link.l1 = "Je vois. Bon, maintenant, attendez et espérez que j'aurai de la chance dans mes recherches. Tâchez de rester à l'église, pour que je puisse vous y trouver.";
			link.l1.go = "exit";
			//==> ставим квестодателя в церковь
			pchar.quest.SeekShip_Stay.win_condition.l1 = "ExitFromLocation";
			npchar.location = npchar.city + "_church";
			npchar.location.locator = "goto2";
            pchar.quest.SeekShip_Stay.win_condition.l1.location = pchar.location;
			pchar.quest.SeekShip_Stay.function = "SeekShip_Stay";
			pchar.quest.SeekShip_Stay.Idx = npchar.index;
			NextDiag.TempNode = "SCQ_womanResult";
			sTitle = npchar.city + "SCQ_womanPirates";
			ReOpenQuestHeader(sTitle);
			AddQuestRecordEx(sTitle, "SCQ_womanPirates", "1");
			AddQuestUserDataForTitle(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony" + npchar.city + "Gen"));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Dat")));
			AddQuestUserData(sTitle, "sShipTypeName2", GetStrSmallRegister(XI_ConvertString(npchar.quest.SeekCap.shipTapeName + "Gen")));
			AddQuestUserData(sTitle, "sShipName", npchar.quest.SeekCap.shipName);
			AddQuestUserData(sTitle, "sCapName", npchar.quest.SeekCap.capName);
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sName2", GetFullName(forName));
			AddQuestUserData(sTitle, "sSex", GetSexPhrase("", "e"));
			AddQuestUserData(sTitle, "sSex1", GetSexPhrase("", "e"));
		break;
		// --- результаты женских квестов ---
		case "SCQ_womanResult":
			dialog.text = "Oh, capitaine, je suis si heureuse de vous voir ! Dites-moi vite, qu'avez-vous appris sur mon affaire ?";
			link.l1 = "Hum, rappelez-moi, " + GetAddress_FormToNPC(NPChar) + ", de quelle affaire parlons-nous ?";
			link.l1.go = "SCQ_womanResult_exit";
			switch (npchar.quest.SeekCap)
			{
				case "womanHasbandover":
					dialog.text = "Ah, capitaine, j'ai reçu une lettre de mon mari ! Il y écrit que vous l'avez retrouvé.";
					link.l1 = "Oui, c'est vrai, " + GetAddress_FormToNPC(NPChar) + ". Votre mari, " + npchar.quest.SeekCap.capName + ", est vivant et en bonne santé. Il était juste très occupé, pour ainsi dire...";
					link.l1.go = "SCQR_womanHasband";
				break;
				case "womanRevengeover":
					dialog.text = "Qu'en dites-vous, capitaine ? Avez-vous fait ce que je vous ai demandé ? Le capitaine " + npchar.quest.SeekCap.capName + " est mort ?";
					link.l1 = "Oui, il est mort, " + GetAddress_FormToNPC(NPChar) + ". Avant de mourir, il a appris qui avait causé sa perte. La dernière chose qu'il a entendue en ce monde, c'est votre nom.";
					link.l1.go = "SCQR_womanRevenge";
				break;
				case "womanPiratesover":
					dialog.text = "Vous avez finalement libéré mon mari ! Je vous en supplie, dites-moi, c'est vrai ?!!";
					link.l1 = "Oui, il est sur mon navire en ce moment. Vous pouvez le reprendre, si " + npchar.quest.SeekCap.name + " " + npchar.quest.SeekCap.lastname + " est bien votre mari...";
					link.l1.go = "SCQR_womanPirates";
				break;
			}
		break;
		case "SCQ_womanResult_exit":
			switch (npchar.quest.SeekCap)
			{
				case "womanHasband":
					dialog.text = "Vous avez oublié que vous m'aviez promis de retrouver mon mari ? Il s'appelle " + npchar.quest.SeekCap.capName + " !";
					link.l1 = "Oh, oui, bien sמr... Je n'ai rien oublié. Je n'ai simplement pas encore réussi à le trouver.";
					link.l1.go = "exit";
				break;
				case "womanRevenge":
					dialog.text = "Je n'ai pas bien compris ! Vous avez oublié que vous devez envoyer dans l'autre monde mon offenseur, un capitaine nommé " + npchar.quest.SeekCap.capName + " ?!";
					link.l1 = "Allons, " + GetAddress_FormToNPC(NPChar) + ", pas du tout. Votre commande est en cours, patientez...";
					link.l1.go = "exit";
				break;
				case "womanPirates":
					dialog.text = "Mon Dieu, capitaine, vous avez oublié que vous m'aviez promis de délivrer mon mari ?!";
					link.l1 = "Je n'ai rien oublié. Je m'en occupe. Patientez, " + GetAddress_FormToNPC(NPChar) + " " + npchar.lastname + ".";
					link.l1.go = "exit";
				break;
			}
		break;

		case "SCQR_womanHasband":
			dialog.text = "Mon Dieu, comme je vous suis reconnaissante ! Ah, au fait, voici vos " + FindRussianMoneyString(sti(npchar.quest.money)) + ". Et merci encore !";
			link.l1 = "Hum, je vous en prie...";
			link.l1.go = "SCQ_exit";
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 8+drand(8));
			sTitle = npchar.city + "SCQ_womanHasband";
			CloseQuestHeader(sTitle);
			AddGoodDeed("SCQ_womanHasband", 3); // Gregg: доброе дело

			AchievementsCounter_genquests(1);
		break;
		case "SCQR_womanRevenge":
			dialog.text = "Parfait ! Eh bien, voici vos " + FindRussianMoneyString(sti(npchar.quest.money)) + " et des bijoux. Adieu.";
			link.l1 = "Au revoir...";
			link.l1.go = "SCQ_exit";
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 10+drand(8));
			TakeNItems(pchar, "jewelry14", rand(3));
			TakeNItems(pchar, "jewelry13", rand(3));
			TakeNItems(pchar, "jewelry10", rand(3));
			TakeNItems(pchar, "jewelry15", rand(3));
			TakeNItems(pchar, "jewelry16", rand(3));
			TakeNItems(pchar, "jewelry18", rand(3));
			TakeNItems(pchar, "jewelry6", rand(3));
			TakeNItems(pchar, "jewelry7", rand(3));
			sTitle = npchar.city + "SCQ_womanRevenge";
			CloseQuestHeader(sTitle);

			AchievementsCounter_genquests(1);
		break;
		case "SCQR_womanPirates":
			dialog.text = "Bien sמr que c'est lui !!! Mon Dieu, capitaine, comme je vous suis reconnaissante ! Voici vos " + FindRussianMoneyString(sti(npchar.quest.money)) + ". Je prierai pour vous chaque jour de ma vie !";
			link.l1 = "C'est gentil, priez...";
			link.l1.go = "SCQ_exit";
			sld = characterFromId("womanPirates_" + npchar.City);
			RemovePassenger(pchar, sld);
			sld.lifeDay = 0;
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть горожанина-квестодателя
			AddMoneyToCharacter(pchar, sti(npchar.quest.money));
			TakeNItems(pchar, npchar.quest.gem, 12+drand(8));
			sTitle = npchar.city + "SCQ_womanPirates";
			CloseQuestHeader(sTitle);
			AddGoodDeed("SCQ_womanPirates", 3); // Gregg: доброе дело

			AchievementsCounter_genquests(1);
		break;
		//========= разыскиваемый капитан-работорговец ===========
		case "CitizCap": //встреча на суше
			switch (npchar.quest.SeekCap)
			{
				case "manSlave":
					dialog.text = "Salutations à mon collègue. Que voulais-tu"+ GetSexPhrase(", mon ami", ", ma chère") +" ?";
					link.l1 = "Tu t'appelles " + GetFullName(npchar) + ", n'est-ce pas ?";
					link.l1.go = "CCmanSlave";
				break;
			}
		break;
		case "CCmanSlave":
			dialog.text = "Oui, c'est ça !";
			link.l1 = "Alors, pas de chance pour toi. Je vais te dire un nom, et tu vas essayer de te souvenir de cette personne : " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + ". Tu te souviens ?";
			link.l1.go = "CCmanSlave_1";
		break;
		case "CCmanSlave_1":
			dialog.text = "Hum, je me souviens...";
			link.l1 = "Eh bien, il est très fâché contre toi, l'ami. Il est donc temps de payer pour avoir vendu un homme libre comme esclave.";
			link.l1.go = "CCmanSlave_2";
		break;
		case "CCmanSlave_2":
			dialog.text = "Payer ?! De quoi parles-tu ?";
			link.l1 = "De ceci : je vais te tuer ici même.";
			link.l1.go = "CCmanSlave_3";
		break;
		case "CCmanSlave_3":
			dialog.text = "Réfléchis, "+ GetSexPhrase("mon ami", "ma belle") +", pour qui te donnes-tu tant de mal ! C'est un être humain tout à fait insignifiant. Sa place est dans les plantations de canne !";
			link.l1 = "Eh bien, ce n'est pas à toi de distribuer les places. Tu vas donc devoir répondre de ce que tu as fait !";
			link.l1.go = "CCmanSlave_4";
		break;
		case "CCmanSlave_4":
			dialog.text = "Ho ! Eh bien, je répondrai comme je pourrai !";
			link.l1 = "Allez, allez...";
			link.l1.go = "CCmanSlave_fight";
		break;
		case "CCmanSlave_fight":
			NextDiag.TempNode = "CitizCap_inDeck_exit";
			npchar.DeckDialogNode = "CitizCap_inDeck_exit";
			LAi_group_Attack(NPChar, Pchar);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "CitizCap_inDeck": //встреча на палубе
			dialog.text = "Que veux-tu sur mon pont ?";
			link.l1 = "Je veux te demander : tu transportes des passagers ?";
			link.l1.go = "CitizCap_inDeck_1";
		break;
		case "CitizCap_inDeck_1":
			dialog.text = "Qu'est-ce que ça peut te faire ?";
			link.l1 = "Je demande, comme ça...";
			link.l1.go = "CitizCap_inDeck_2";
		break;
		case "CitizCap_inDeck_2":
			dialog.text = "Comme ça... écoute, fiche le camp d'ici tant que je t'en laisse l'occasion. Tu ne me plais pas !";
			link.l1 = "D'accord, d'accord, ne t'énerve pas. Je m'en vais déjà...";
			link.l1.go = "exit";
			NextDiag.TempNode = "CitizCap_inDeck_exit";
			npchar.DeckDialogNode = "CitizCap_inDeck_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen")));
		break;
		case "CitizCap_inDeck_exit":
			dialog.text = "On a déjà parlé, n'insiste pas !";
			link.l1 = "Je n'insiste pas.";
			link.l1.go = "exit";
			NextDiag.TempNode = "CitizCap_inDeck_exit";
		break;

		//========= Gregg: должник-капитан, генератор ростовщика ===========
		// Стадия (pchar.GenQuest.LoanCap.Stage) решает всё: seek - ищем, fighting - бой
		// объявлен, дальше шесть развязок. Сцена разговора живёт на самом собеседнике
		// (npchar.LoanCapScene), ставится в точке входа и читается только через CheckAttribute.
		// С должника снимается ВСЕГДА полная названная сумма: спорить о её размере -
		// разговор не с ним, а с ростовщиком. Знание настоящей цифры (Knows) окупается
		// именно там: ростовщик извиняется и возвращает разницу.
		case "LoanCap": //встреча на суше
			// Gregg: должник на берег не сходит - LoanCap_FromMapToCity ставит его
			// только на рейд. Узел оставлен заглушкой на случай чужого хука.
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Mon erreur, désolé.";
			link.l1.go = "exit";
		break;

		case "LoanCap_inDeck": //встреча на палубе
			npchar.LoanCapScene = "deck";
			if (LoanCap_Stage() == "")
			{
				dialog.text = "Et qui êtes-vous donc ?! Hors de mon pont !";
				link.l1 = "Je m'en vais déjà.";
				link.l1.go = "exit";
				break;
			}
			if (LoanCap_Stage() == "fighting")
			{
				dialog.text = "Cette conversation est terminée ! Quittez mon navire tant que vous le pouvez encore !";
				link.l1 = "Nous nous reverrons.";
				link.l1.go = "exit";
				NextDiag.TempNode = "LoanCap_inDeck_again";
				break;
			}
			if (LoanCap_Stage() != "seek")
			{
				dialog.text = "Encore vous ? Nous sommes quittes, passez votre chemin.";
				link.l1 = "Je m'en vais, je m'en vais.";
				link.l1.go = "exit";
				break;
			}
			dialog.text = "Et qui êtes-vous donc ?! Hors de mon pont, tant que vous le pouvez encore !";
			link.l1 = "Capitaine " + GetFullName(npchar) + " ? Nous devons parler d'argent, vous et moi.";
			link.l1.go = "LoanCap_inDeck_1";
		break;

		case "LoanCap_inDeck_1":
			dialog.text = "D'argent ?.. Non, non, vous me confondez avec quelqu'un d'autre. Je ne dois rien à personne !";
			link.l1 = "Je n'ai jamais parlé de dette. J'ai donc bien trouvé mon homme.";
			link.l1.go = "LoanCap_inDeck_2";
		break;

		case "LoanCap_inDeck_2":
			// Gregg: сюда возвращаются после ухода "надо подумать", и квест мог за это
			// время закрыться. Разбор состояния целиком лежит в LoanCap_inDeck - шлём
			// туда одной ссылкой, а не дублируем проверки.
			npchar.LoanCapScene = "deck";
			if (LoanCap_Stage() != "seek")
			{
				dialog.text = "Nous nous sommes tout dit, je crois.";
				link.l1 = "Pas tout à fait.";
				link.l1.go = "LoanCap_inDeck";
				break;
			}
			dialog.text = "Pff... Et maintenant ? Vous allez me découper ici même, devant mon propre équipage ?";
			link.l1 = "Pas besoin de découper qui que ce soit. Payez-moi " + FindRussianMoneyString(LoanCap_Collect()) + " et je fais demi-tour avec ma chaloupe.";
			link.l1.go = "LoanCap_inDeck_Press";
			// Gregg: знает настоящий долг - вправе требовать именно его. Проверки Авторитета
			// тут нет: у должника отпадает причина упираться, он спорил не с суммой, а с наценкой.
			if (pchar.GenQuest.LoanCap.Knows != "no")
			{
				link.l5 = "Je ne veux que ce que vous avez réellement emprunté : " + FindRussianMoneyString(LoanCap_RealSum()) + ". Pas un peso de plus.";
				link.l5.go = "LoanCap_inDeck_Fair";
			}
			link.l8 = "Je vous fais grâce de la dette. Vivez, et ne croisez plus ma route.";
			link.l8.go = "LoanCap_Story_Forgive";
			// Gregg: разговор о долге открыт и честному должнику, и при завышенной сумме.
			// Два отдельных if вместо ||: смешанной логики в проекте избегаем.
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				link.l3 = "Attendez. Réglons cette dette qui est la vכtre.";
				link.l3.go = "LoanCap_Story";
			}
			if (LoanCap_IsLied())
			{
				link.l3 = "Attendez. Réglons cette dette qui est la vכtre.";
				link.l3.go = "LoanCap_Story";
			}
			// Gregg: уйти, ничего не решив. Без этого узел был кольцом без двери.
			// Gregg: уйти, ничего не решив - и вернуться к тому же разговору. Без явного
			// TempNode следующая беседа уезжает в case "First time" ("Не о чем говорить"):
			// узел, с которого продолжать, движку не назван, и он берёт умолчание диалога.
			NextDiag.TempNode = "LoanCap_inDeck_2";
			link.l9 = "Je dois réfléchir. Nous nous reverrons.";
			link.l9.go = "exit";
		break;

		case "LoanCap_inDeck_Press":
			// Gregg: нажим - и он же точка, где выясняется, что брать нечего.
			// Разорившемуся Авторитет не поможет: денег от него не прибавится.
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				dialog.text = "Payer ?.. Avec quoi ? וcoutez-moi, capitaine. Une tempête au large des îles du Vent, la cargaison par-dessus bord et la moitié de l'équipage avec. Le chantier naval m'a pris tout ce que j'avais, et autant encore. Je ne me suis pas enfui : je ne pouvais tout simplement pas payer.";
				link.l1 = "Montrez-moi ce qui reste.";
				link.l1.go = "LoanCap_inDeck_Broke";
				break;
			}
			iTemp = 40 + rand(25);
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) >= iTemp)
			{
				dialog.text = "Le diable vous emporte. J'ai assez entendu parler de vous pour ne pas vérifier si c'est vrai. Prenez et partez avant que je change d'avis.";
				link.l1 = "Raisonnable. Vivez en paix.";
				link.l1.go = "LoanCap_inDeck_Pay";
			}
			else
			{
				dialog.text = "Ha ! Et qui êtes-vous pour que je vous paie ? א moi, les gars ! Il ne quittera pas ce pont vivant !";
				link.l1 = "Voyons qui ne le quittera pas.";
				link.l1.go = "LoanCap_inDeck_Refuse";
			}
		break;

		case "LoanCap_inDeck_Broke":
			// Gregg: разорившийся должник. Денег нет - есть бумага, чужая совесть и нож.
			dialog.text = "Tenez, regardez. Le coffre est vide, la cale est vide, l'équipage n'a pas vu un peso depuis trois mois. Découpez-moi si vous voulez : ça ne fera pas apparaître d'argent.";
			link.l1 = "Alors, écrivez-moi une reconnaissance de dette. Je lui apporterai du papier au lieu d'argent.";
			link.l1.go = "LoanCap_inDeck_Note";
			if (sti(pchar.Money) >= LoanCap_Demand())
			{
				// Gregg: цифру называем, только пока она окончательная. Узнав настоящую
				// сумму, ГГ ещё не знает, сколько заплатит: признает ростовщик обман -
				// отдаст настоящую, не признает - объявленную.
				link.l2 = "Je vais régler votre dette moi-même : " + FindRussianMoneyString(LoanCap_Demand()) + ". Estimez-vous heureux.";
				if (pchar.GenQuest.LoanCap.Knows != "no")
				{
					link.l2 = "Je vais régler votre dette moi-même. Et je lui ferai accepter le vrai chiffre, pas celui qu'il a inventé.";
				}
				link.l2.go = "LoanCap_Story_Pay";
			}
			// Gregg: спросить настоящую сумму имеет смысл, только пока ГГ её не знает
			if (LoanCap_IsLied())
			{
				if (pchar.GenQuest.LoanCap.Knows == "no")
				{
					link.l3 = "Combien lui avez-vous emprunté ? La somme exacte.";
					link.l3.go = "LoanCap_Story_Sum";
				}
			}
			link.l8 = "Vous savez quoi ? Vivez. Réglez ça entre vous.";
			link.l8.go = "LoanCap_Story_Forgive";
			// Gregg: уйти, ничего не решив - и вернуться к тому же разговору. Без явного
			// TempNode следующая беседа уезжает в case "First time" ("Не о чем говорить"):
			// узел, с которого продолжать, движку не назван, и он берёт умолчание диалога.
			NextDiag.TempNode = "LoanCap_inDeck_2";
			link.l9 = "Je dois réfléchir. Nous nous reverrons.";
			link.l9.go = "exit";
		break;

		case "LoanCap_inDeck_Note":
			dialog.text = "Du papier ?.. Comme vous voudrez. Il me reste une plume, la dernière chose que je possède. Voici : ma signature, la date, la somme. Qu'il s'étouffe avec.";
			link.l1 = "דa ira.";
			link.l1.go = "LoanCap_inDeck_NoteEnd";
		break;

		case "LoanCap_inDeck_NoteEnd":
			LoanCap_Outcome("note", "19", 0);
			dialog.text = "Adieu, capitaine. Au moins, quelqu'un a choisi de ne pas sortir le couteau.";
			link.l1 = "Bon vent.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_Done";
			npchar.DeckDialogNode = "LoanCap_inDeck_Done";
		break;

		case "LoanCap_inDeck_Pay":
			dialog.text = "Maintenant, dehors.";
			link.l1 = "Adieu.";
			link.l1.go = "exit";
			// Gregg: деньги, репутация, запись и срок отчёта - всё в одной функции.
			LoanCap_Outcome("paid", "12", LoanCap_Collect());
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 10);
			NextDiag.TempNode = "LoanCap_inDeck_Done";
			npchar.DeckDialogNode = "LoanCap_inDeck_Done";
		break;

		case "LoanCap_inDeck_Done":
			dialog.text = "Nous sommes quittes. Que voulez-vous de plus ?";
			link.l1 = "Rien. Bon vent.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_Done";
		break;

		case "LoanCap_inDeck_Refuse":
			// Gregg: палубный разговор закрыт, но не навсегда - в каюте после абордажа
			// он начнётся заново.
			dialog.text = "Hors de mon navire !";
			link.l1 = "Nous nous reverrons.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_again";
			npchar.DeckDialogNode = "LoanCap_inDeck_again";
		break;

		case "LoanCap_inDeck_again":
			dialog.text = "Cette conversation est terminée ! Hors de mon navire !";
			link.l1 = "Elle est terminée quand je le dis.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_again";
		break;

		case "LoanCap_Board": //абордаж, разговор в каюте
			npchar.LoanCapScene = "cabin";
			if (LoanCap_Stage() == "")
			{
				dialog.text = "Je me rends ! Que me voulez-vous ?";
				link.l1 = "Plus rien. Vivez.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			// Gregg: страховка от повторной выплаты. Стадия fighting сюда НЕ попадает:
			// бой объявлен, но не доведён - разговор можно продолжить.
			if (LoanCap_Stage() == "paid")
			{
				dialog.text = "Encore vous ?! Je vous ai tout donné, il ne me reste rien !";
				link.l1 = "Calmez-vous. Ce n'est pas pour ça que je suis là.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			if (LoanCap_Stage() == "forced")
			{
				dialog.text = "Encore vous ?! Je vous ai tout donné, il ne me reste rien !";
				link.l1 = "Calmez-vous. Ce n'est pas pour ça que je suis là.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			if (LoanCap_Stage() == "note")
			{
				dialog.text = "Vous avez votre reconnaissance de dette. Que voulez-vous de plus ?";
				link.l1 = "Rien. Mon erreur.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			if (LoanCap_Stage() == "spared")
			{
				dialog.text = "Vous m'avez laissé partir ! Que voulez-vous de plus ?";
				link.l1 = "Rien. Mon erreur.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			if (LoanCap_Stage() == "promised")
			{
				dialog.text = "Vous avez promis de régler ma dette ! Ou vous avez changé d'avis ?";
				link.l1 = "Non. Vivez en paix.";
				link.l1.go = "LoanCap_Board_Done";
				break;
			}
			dialog.text = "Assez ! Assez, je me rends ! Que voulez-vous ? La cargaison ? Le navire ? Prenez ce que vous voulez, mais ne me tuez pas !";
			link.l1 = "Je veux la dette que vous n'avez jamais remboursée. " + pchar.GenQuest.LoanCap.UsurerName + " vous salue bien.";
			link.l1.go = "LoanCap_Board_1";
		break;

		case "LoanCap_Board_1":
			dialog.text = "Ah, c'est donc ça... וcoutez, je n'ai pas toute la somme en ce moment. Ce n'est tout de même pas une raison pour tuer un homme ! Donnez-moi encore deux mois, et je rembourserai jusqu'au dernier peso, je le jure !";
			link.l1 = "L'argent. Tout de suite. " + FindRussianMoneyString(LoanCap_Collect()) + ". Je ne le demanderai pas deux fois.";
			link.l1.go = "LoanCap_Board_Press";
			// Gregg: см. палубу
			if (pchar.GenQuest.LoanCap.Knows != "no")
			{
				link.l5 = "Je ne veux que ce que vous avez réellement emprunté : " + FindRussianMoneyString(LoanCap_RealSum()) + ". Pas un peso de plus.";
				link.l5.go = "LoanCap_Board_Fair";
			}
			link.l2 = "Vous n'avez pas deux mois. Vous avez moi, et mes hommes d'abordage.";
			link.l2.go = "LoanCap_Board_Fight";
			link.l3 = "Je vous fais grâce de la dette. Vivez, et souvenez-vous à qui vous deviez de l'argent.";
			link.l3.go = "LoanCap_Board_Leave";
			// Gregg: два отдельных if вместо ||, см. палубный узел
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				link.l4 = "Attendez. Réglons cette dette qui est la vכtre.";
				link.l4.go = "LoanCap_Story";
			}
			if (LoanCap_IsLied())
			{
				link.l4 = "Attendez. Réglons cette dette qui est la vכtre.";
				link.l4.go = "LoanCap_Story";
			}
		break;

		case "LoanCap_Board_Press":
			// Gregg: то же, что на палубе - у разорившегося Авторитет денег не выбьет
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				dialog.text = "Je n'ai rien ! Une tempête au large des îles du Vent, la cargaison par-dessus bord et la moitié de l'équipage avec. Le chantier naval m'a pris jusqu'au dernier clou. Fouillez la cale si vous ne me croyez pas.";
				link.l1 = "Nous allons la fouiller.";
				link.l1.go = "LoanCap_Board_Broke";
				break;
			}
			iTemp = 40 + rand(25);
			if (GetSummonSkillFromName(pchar, SKILL_LEADERSHIP) >= iTemp)
			{
				dialog.text = "Bon ! Bon, que le diable vous emporte. Dans le coffre sous la couchette. Tout y est, intérêts compris. Prenez-le et quittez mon navire.";
				link.l1 = "Un choix raisonnable.";
				link.l1.go = "LoanCap_Board_Pay";
			}
			else
			{
				dialog.text = "Et pourquoi n'iriez-vous pas au diable ! Vous croyez que parce que vous êtes monté à bord, je vais ramper à plat ventre ? א moi, les gars !";
				link.l1 = "Comme vous voudrez.";
				link.l1.go = "LoanCap_Board_Fight";
			}
		break;

		case "LoanCap_Board_Broke":
			// Gregg: трюм и правда пуст. Взять с него можно только его самого -
			// корабль и груз ГГ и так получит на форме трофея.
			dialog.text = "Vide, comme je vous l'avais dit. Alors ? Et maintenant, par-dessus bord avec moi ?";
			link.l1 = "Pire. Vous venez avec moi. Il vous aura vous, à la place de l'argent.";
			link.l1.go = "LoanCap_Board_Prisoner";
			if (LoanCap_IsLied())
			{
				if (pchar.GenQuest.LoanCap.Knows == "no")
				{
					link.l2 = "Combien lui avez-vous emprunté ? La somme exacte.";
					link.l2.go = "LoanCap_Story_Sum";
				}
			}
			link.l3 = "Vivez. Je n'ai que faire des cadavres.";
			link.l3.go = "LoanCap_Board_Leave";
		break;

		case "LoanCap_Board_Prisoner":
			dialog.text = "...Aux fers, alors. Soit. La prison pour dettes vaut encore mieux que le fond de la mer. Passez devant, capitaine.";
			link.l1 = "Avance.";
			link.l1.go = "exit";
			LoanCap_Outcome("prisoner", "24", 0);
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 6);
			// Gregg: квестовый плен по образцу ГВИК - берёт ОДНОГО реального капитана
			// (пишет GenQuest.LastQuestPrisonerIdx) и ставит DontRansackCaptain, чтобы
			// форма трофея не выдала второго пленника. Пленника усыновляет LoanCap_CapIsDeath.
			AddDialogExitQuestFunction("QuestAboardCabinDialogQuestSurrender");
		break;

		case "LoanCap_Board_Pay":
			LoanCap_Outcome("paid", "3", LoanCap_Collect());
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 6);
			// Gregg: именно Surrender, а не NotBattle - иначе движок закрывает абордаж
			// по ветке "капитан убит" и корабль засчитывается потопленным
			QuestAboardCabinDialogSurrender();
			DialogExit();
		break;

		// Gregg: --> честное требование: ГГ снимает настоящий долг, наценка остаётся
		// у должника. Развязка та же, что при удачном нажиме, но сумма другая.
		case "LoanCap_inDeck_Fair":
			// Gregg: разорившемуся платить нечем и по настоящей цифре. Без этой
			// проверки честное требование обходило весь разбор с разорением и
			// снимало деньги с того, у кого их нет.
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				dialog.text = "Le vrai chiffre ou celui qu'il a inventé, je n'ai rien pour payer, capitaine. Une tempête au large des îles du Vent, la cargaison par-dessus bord et la moitié de l'équipage avec. Le chantier naval m'a pris tout ce que j'avais, et autant encore.";
				link.l1 = "Montrez-moi ce qui reste.";
				link.l1.go = "LoanCap_inDeck_Broke";
				break;
			}
			dialog.text = "...Vous avez donc vérifié. C'est bien ce que j'ai emprunté, au mot près. Tenez, et dites-lui qu'il n'aura pas un peso de plus de ma part.";
			link.l1 = "Je le lui dirai.";
			link.l1.go = "LoanCap_inDeck_FairPay";
		break;

		case "LoanCap_inDeck_FairPay":
			LoanCap_Outcome("paid", "12", LoanCap_RealSum());
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 10);
			dialog.text = "...Vous avez donc vérifié. C'est bien ce que j'ai emprunté, au mot près. Tenez, et dites-lui qu'il n'aura pas un peso de plus de ma part.";
			link.l1 = "Je le lui dirai.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_Done";
			npchar.DeckDialogNode = "LoanCap_inDeck_Done";
		break;

		case "LoanCap_Board_Fair":
			// Gregg: см. палубу
			if (pchar.GenQuest.LoanCap.Honest == "yes")
			{
				dialog.text = "Le vrai chiffre ou celui qu'il a inventé, je n'ai rien pour payer. Une tempête au large des îles du Vent, la cargaison par-dessus bord et la moitié de l'équipage avec. Le chantier naval a pris le reste.";
				link.l1 = "Montrez-moi ce qui reste.";
				link.l1.go = "LoanCap_Board_Broke";
				break;
			}
			dialog.text = "...Vous avez donc vérifié. C'est bien ce que j'ai emprunté. Dans le coffre sous la couchette, prenez-le. Et dites-lui qu'il n'aura pas un peso de plus de ma part.";
			link.l1 = "Je le lui dirai.";
			link.l1.go = "LoanCap_Board_FairPay";
		break;

		case "LoanCap_Board_FairPay":
			LoanCap_Outcome("paid", "3", LoanCap_RealSum());
			AddCharacterExpToSkill(pchar, "Leadership", makeint(pchar.rank) * 6);
			QuestAboardCabinDialogSurrender();
			DialogExit();
		break;
		// Gregg: <-- честное требование

		// Gregg: --> разговор о долге. Узлы общие для палубы и каюты, сцена в questTemp
		case "LoanCap_Story":
			dialog.text = "Régler ? Une dette est une dette. Je l'ai contractée, je ne l'ai pas remboursée, vous êtes venu. Il n'y a rien à régler.";
			if (pchar.GenQuest.LoanCap.Honest == "yes") dialog.text = "Qu'y a-t-il à régler ? Une tempête, la cargaison par-dessus bord, le chantier naval a pris le reste. Je ne me suis pas enfui : je ne pouvais tout simplement pas payer.";
			link.l1 = "Bien. Revenons aux affaires.";
			link.l1.go = "LoanCap_Story_Return";
			if (LoanCap_IsLied())
			{
				if (pchar.GenQuest.LoanCap.Knows == "no")
				{
					link.l2 = "Combien lui avez-vous emprunté ? La somme exacte.";
					link.l2.go = "LoanCap_Story_Sum";
				}
			}
			link.l4 = "Vous savez quoi ? Je vous fais grâce de la dette. Réglez ça entre vous.";
			link.l4.go = "LoanCap_Story_Forgive";
		break;

		// Gregg: возврат в основной разговор ТОЛЬКО ссылкой. DialogExit() из каюты
		// оставлял ГГ актёром без управления - штатный выход оттуда лишь через
		// каютные хелперы.
		case "LoanCap_Story_Return":
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = "Bien. Revenons aux affaires.";
			link.l1.go = "LoanCap_inDeck_2";
			sTemp = "deck";
			if (CheckAttribute(npchar, "LoanCapScene")) sTemp = npchar.LoanCapScene;
			if (sTemp == "cabin") link.l1.go = "LoanCap_Board_1";
		break;

		case "LoanCap_Story_Sum":
			// Gregg: должник называет настоящую цифру. Проверок нет намеренно: это
			// не выбивание денег, а слова, и стоят они ровно столько, сколько стоит
			// разговор с ростовщиком потом.
			dialog.text = "J'ai emprunté " + FindRussianMoneyString(sti(pchar.GenQuest.LoanCap.RealSum)) + ". Il vous a donné un autre chiffre ? וvidemment. Seulement, je ne peux rien prouver : c'est lui qui détient la reconnaissance de dette.";
			link.l1 = "Je m'occuperai de lui moi-même. De vous, ce qu'il a réclamé.";
			link.l1.go = "LoanCap_Story_Learn";
			link.l9 = "Un joli mensonge. Revenons aux affaires.";
			link.l9.go = "LoanCap_Story_Return";
		break;

		case "LoanCap_Story_Learn":
			dialog.text = "Si vous pouvez vraiment lui faire accepter ça, je vous serai doublement redevable.";
			link.l1 = "Je le ferai.";
			link.l1.go = "LoanCap_inDeck_2";
			sTemp = "deck";
			if (CheckAttribute(npchar, "LoanCapScene")) sTemp = npchar.LoanCapScene;
			if (sTemp == "cabin") link.l1.go = "LoanCap_Board_1";
			LoanCap_LearnRealSum();
		break;

		case "LoanCap_Story_Forgive":
			dialog.text = "Vous... vous êtes sérieux ? Allez, capitaine. Si Dieu le veut, nous nous reverrons dans de meilleures conditions.";
			link.l1 = "Nous nous reverrons.";
			link.l1.go = "LoanCap_Story_Forgive_End";
		break;

		case "LoanCap_Story_Forgive_End":
			// Gregg: сцену читаем ПЕРВОЙ строкой, до любого вызова - порядок тут не
			// косметика: раньше выход из каюты определялся по атрибуту, который к этому
			// моменту успевала снести развязка, и ГГ оставался актёром без управления.
			sTemp = "deck";
			if (CheckAttribute(npchar, "LoanCapScene")) sTemp = npchar.LoanCapScene;
			if (sTemp == "cabin")
			{
				LoanCap_Outcome("spared", "10", 0);
				QuestAboardCabinDialogSurrender();
				DialogExit();
				break;
			}
			LoanCap_Outcome("spared", "10", 0);
			dialog.text = "Vous... vous êtes sérieux ? Allez, capitaine. Si Dieu le veut, nous nous reverrons dans de meilleures conditions.";
			link.l1 = "Nous nous reverrons.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_Done";
			npchar.DeckDialogNode = "LoanCap_inDeck_Done";
		break;

		case "LoanCap_Story_Pay":
			dialog.text = "Vous... vous êtes sérieux ? Capitaine, je... וcoutez, je ne sais pas quoi dire. Mais je n'en resterai pas là : une fois à terre, je ferai circuler la nouvelle d'un gros marchand qui navigue sans escorte. Descendez à terre, et vous en entendrez parler.";
			link.l1 = "Considérons que nous sommes quittes.";
			link.l1.go = "LoanCap_Story_Pay_End";
		break;

		case "LoanCap_Story_Pay_End":
			// Gregg: здесь только обещание. Деньги уходят у ростовщика, по факту расчёта.
			// LoanCap_DebtorTip() отсюда НЕ зовём: GenerateMerchant() в морской локации
			// падает на Colonies[FindColony("")]. Наводку выдаёт ростовщик.
			sTemp = "deck";
			if (CheckAttribute(npchar, "LoanCapScene")) sTemp = npchar.LoanCapScene;
			if (sTemp == "cabin")
			{
				LoanCap_Outcome("promised", "13", 0);
				QuestAboardCabinDialogSurrender();
				DialogExit();
				break;
			}
			LoanCap_Outcome("promised", "13", 0);
			dialog.text = "Adieu, capitaine. Et merci.";
			link.l1 = "Bon vent.";
			link.l1.go = "exit";
			NextDiag.TempNode = "LoanCap_inDeck_Done";
			npchar.DeckDialogNode = "LoanCap_inDeck_Done";
		break;
		// Gregg: <-- разговор о долге

		case "LoanCap_Board_Leave":
			LoanCap_Outcome("spared", "10", 0);
			QuestAboardCabinDialogSurrender();
			DialogExit();
		break;

		// Gregg: выход из каюты без развязки - квест закрыт либо развязка уже была
		case "LoanCap_Board_Done":
			QuestAboardCabinDialogSurrender();
			DialogExit();
		break;

		case "LoanCap_Board_Fight":
			LoanCap_ArmForce();
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("LoanCap_afterCabinFight");
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		//========= разыскиваемый кэп, похитивший чужую жену ===========
		case "RapeWifeCap":  //встреча на суше
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Salutations à mon collègue ! Tu voulais quelque chose, mon ami ?";
			link.l1 = "Je voulais savoir si tu avais enlevé à " + XI_ConvertString("Colony" + npchar.quest.cribCity + "Gen") + " une femme nommée " + GetFullName(sld) + " ?";
			link.l1.go = "RapeWifeCap_1";
		break;
		case "RapeWifeCap_1":
			dialog.text = "Hé, c'est exact, elle est dans ma cabine ! Tu es fort, petit diable !.. Pourquoi tu demandes ?";
			link.l1 = "L'ami, cette dame est mariée. Tu as enlevé une femme mariée !";
			link.l1.go = "RapeWifeCap_2";
		break;
		case "RapeWifeCap_2":
			dialog.text = "Et alors ? Elle me plaît, c'est tout. Et je ne vais pas laisser un va-nu-pieds se mêler de nos relations sous prétexte qu'il est son mari, tu vois !..";
			link.l1 = "Permets-moi de te dire que la Confrérie n'apprécie pas ce genre de tours.";
			link.l1.go = "RapeWifeCap_3";
		break;
		case "RapeWifeCap_3":
			dialog.text = "Tu essaies de me faire la morale, ici ? La Confrérie n'a rien à voir dans cette affaire, alors tes discours ne mèneront à rien. Elle est à moi, point final !";
			link.l1 = "Ne t'énerve pas, je demandais juste... Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RapeWifeCap_exit";
			npchar.DeckDialogNode = "RapeWifeCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen")));
		break;
		case "RapeWifeCap_exit":
			dialog.text = "On a déjà parlé des femmes. Je ne veux plus en discuter !";
			link.l1 = "D'accord...";
			link.l1.go = "exit";
			NextDiag.TempNode = "RapeWifeCap_exit";
		break;
		case "RapeWifeCap_inDeck":  //встреча на палубе
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Je suis heureux d'accueillir un collègue sur mon pont ! De quoi voulais-tu discuter avec moi, "+ GetSexPhrase("mon ami", "ma belle") +" ?";
			link.l1 = "Je voulais savoir si tu avais enlevé une femme à " + XI_ConvertString("Colony" + npchar.quest.cribCity + "Gen") + " nommée " + GetFullName(sld) + " ?";
			link.l1.go = "RapeWifeCap_1";
		break;
		case "RapeWifeCap_inDeck_1":
			dialog.text = "Hé, c'est exact, elle est dans ma cabine ! Tu es fort, petit diable !.. Pourquoi tu demandes ?";
			link.l1 = "L'ami, cette dame est mariée. Tu as enlevé une femme mariée !";
			link.l1.go = "RapeWifeCap_inDeck_2";
		break;
		case "RapeWifeCap_inDeck_2":
			dialog.text = "Et alors ? Elle me plaît, c'est tout. Et je ne vais pas laisser un va-nu-pieds se mêler de nos relations sous prétexte qu'il est son mari, tu vois !..";
			link.l1 = "Permets-moi de te dire que la Confrérie n'apprécie pas ce genre de tours.";
			link.l1.go = "RapeWifeCap_inDeck_3";
		break;
		case "RapeWifeCap_inDeck_3":
			dialog.text = "Tu essaies de me faire la morale, ici ? La Confrérie n'a rien à voir dans cette affaire, alors tes discours ne mèneront à rien. Elle est à moi, point final !";
			link.l1 = "Ne t'énerve pas, je demandais juste... Bon, salut, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RapeWifeCap_exit";
			npchar.DeckDialogNode = "RapeWifeCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen")));
		break;
		case "RapeWifeCap_Board": //абордаж
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Qu'est-ce qu'il te faut, gredin ?!!";
			link.l1 = "Je viens pour la femme que tu as enlevée à son mari. Souviens-toi de " + XI_ConvertString("Colony"+npchar.quest.cribCity) + " ! Elle s'appelle " + sld.quest.SeekCap.name + " " + sld.quest.SeekCap.lastname + ".";
			link.l1.go = "RapeWifeCap_Board_1";
		break;
		case "RapeWifeCap_Board_1":
			dialog.text = "Diable !! Tu ne la verras pas plus que tes propres oreilles !";
			link.l1 = "Ha, imbécile !! Mes oreilles, je les vois dans le miroir ! Et les tiennes, je vais te les couper tout de suite...";
			link.l1.go = "RapeWifeCap_Board_2";
		break;
		case "RapeWifeCap_Board_2":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogFree(); // важный метод
			LAi_group_SetRelation(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(LAI_GROUP_BRDENEMY, "CitizSeekCap_afterCabinFight");
			pchar.GenQuest.CitizSeekCap.label = npchar.quest.SeekCap; //флаг квеста для нпс
			pchar.GenQuest.CitizSeekCap.nation = npchar.nation;	//нацию для нпс
			pchar.GenQuest.CitizSeekCap.sex = "woman";
			pchar.GenQuest.CitizSeekCap.ani = "towngirl";
			pchar.GenQuest.CitizSeekCap.model = "girl_"+(rand(7)+1); //модель для нпс
			pchar.GenQuest.CitizSeekCap.WifeCity = npchar.quest.cribCity; //исходный город для нпс
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			pchar.GenQuest.CitizSeekCap.WifeName = sld.quest.SeekCap.name; //имя и фамилию для нпс
			pchar.GenQuest.CitizSeekCap.WifeLastname = sld.quest.SeekCap.lastname;
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//========= похищенная жена ===========
		case "manRapeWife_Board":
			dialog.text = "Qui êtes-vous ?";
			link.l1 = "Bonjour. Je vous cherche pour le compte de votre mari. Maintenant que vous êtes libre, je dois vous ramener auprès de lui.";
			link.l1.go = "manRapeWife_Board_1";
		break;
		case "manRapeWife_Board_1":
			dialog.text = "Ce n'est pas un rêve ?! C'est vrai ?!";
			link.l1 = "La pure vérité, " + GetAddress_FormToNPC(NPChar) + ".";
			link.l1.go = "manRapeWife_Board_2";
		break;
		case "manRapeWife_Board_2":
			dialog.text = "Gloire à Dieu tout-puissant !!! Je suis prête, partons d'ici vite !";
			link.l1 = "D'accord, " + GetAddress_FormToNPC(NPChar) + ", préparez-vous à rentrer auprès de votre mari.";
			link.l1.go = "exit";
			//уберём жену из каюты
			npchar.location = "none";
			npchar.location.locator = "";
			LAi_SetPlayerType(pchar);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "6");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony"+npchar.quest.cribCity+"Acc"));
		break;
		//========= разыскиваемый земляк-торговый кэп ===========
		case "FriendCap": //встреча на суше
			dialog.text = "Bonjour ! Heureux d'accueillir à terre un capitaine, un collègue, pour ainsi dire...";
			link.l1 = TimeGreeting() + "Et moi, je vous cherchais pour affaires.";
			link.l1.go = "FriendCap_1";
		break;
		case "FriendCap_1":
			dialog.text = "Je vous écoute attentivement.";
			link.l1 = "Le fait est que votre compatriote, avec qui vous êtes venu ici de l'Ancien Monde, vous cherche : " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + ". Ce nom vous dit quelque chose ?";
			link.l1.go = "FriendCap_2";
		break;
		case "FriendCap_2":
			dialog.text = "Ha, bien sמr ! Et oם habite-t-il ?";
			link.l1 = "א " + XI_ConvertString("Colony"+npchar.quest.cribCity+"Dat") + ". Je lui ai proposé de venir avec moi, mais il a refusé. Il vous demande de passer le voir.";
			link.l1.go = "FriendCap_3";
		break;
		case "FriendCap_3":
			dialog.text = "Bien sמr, je le ferai. Merci infiniment !.. Vous savez, à votre allure, je dirais que vous êtes un pirate !";
			link.l1 = "C'est exact. Mais je suis de bonne humeur aujourd'hui, vous n'avez donc rien à craindre. Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "FriendCap_exit";
			npchar.DeckDialogNode = "FriendCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony"+npchar.quest.cribCity+"Acc"));
			sTemp = "SecondTimer_" + npchar.id;
			pchar.quest.(sTemp).over = "yes"; //снимаем установленный таймер на выход в море
			npchar.lifeDay = 0;
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть кэпа
			sld = characterFromId("QuestCitiz_" + npchar.quest.cribCity);
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			//удаляем запись в базе кэпов
			makearef(forName, NullCharacter.capitainBase);
			DeleteAttribute(forName, npchar.id);
		break;
		case "FriendCap_exit":
			dialog.text = "Tout va bien, pas de problème ? Excusez-moi, je suis un peu inquiet...";
			link.l1 = "Tout va bien, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "FriendCap_exit";
		break;
		case "FriendCap_inDeck": //встреча на палубе
			dialog.text = TimeGreeting() + ". Que me voulez-vous ? Je ne suis qu'un capitaine marchand, et...";
			link.l1 = "Je sais, l'ami. Ne soyez pas si nerveux, on dit que c'est mauvais pour la santé. Je suis là pour affaires.";
			link.l1.go = "FriendCap_inDeck_1";
		break;
		case "FriendCap_inDeck_1":
			dialog.text = "De quelle affaire s'agit-il ?";
			link.l1 = "Votre compatriote vous cherche : " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + ". Vous connaissez quelqu'un de ce nom ?";
			link.l1.go = "FriendCap_inDeck_2";
		break;
		case "FriendCap_inDeck_2":
			dialog.text = "Oh, oh, il m'a finalement retrouvé ! Très bien... Excusez-moi pour ce mauvais accueil, vous savez, j'ai cru, pécheur que je suis, que vous étiez un pirate.";
			link.l1 = "C'est exact. Mais vous ne courez aucun danger pour l'instant. On m'a demandé de vous transmettre un message, c'est fait.. Votre compatriote, d'ailleurs, vit et travaille à " + XI_ConvertString("Colony"+npchar.quest.cribCity+"Dat") + ".";
			link.l1.go = "FriendCap_inDeck_3";
		break;
		case "FriendCap_inDeck_3":
			dialog.text = "דa alors !.. Vous êtes "+ GetSexPhrase("un homme noble", "une noble fille") +". Merci !";
			link.l1 = "Je vous en prie. Adieu, et portez-vous bien, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "FriendCap_exit";
			npchar.DeckDialogNode = "FriendCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony"+npchar.quest.cribCity+"Acc"));
			npchar.quest = "outMap"; //доходит до нужной точки - и исчезает
			sld = characterFromId("QuestCitiz_" + npchar.quest.cribCity);
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			//удаляем запись в базе кэпов
			makearef(forName, NullCharacter.capitainBase);
			DeleteAttribute(forName, npchar.id);
		break;
		//========= разыскиваемый муж-торговец ===========
		case "HasbandCap": //встреча на суше
			dialog.text = "Bonjour. Vous vouliez quelque chose ?";
			link.l1 = "Tu t'appelles " + GetFullName(npchar) + ", n'est-ce pas ?";
			link.l1.go = "HasbandCap_1";
		break;
		case "HasbandCap_1":
			dialog.text = "Oui, c'est moi.";
			link.l1 = "דa paraît bête, bien sמr, mais votre femme m'a demandé de vous dire qu'elle s'inquiète beaucoup pour vous.";
			link.l1.go = "HasbandCap_2";
		break;
		case "HasbandCap_2":
			dialog.text = "Ha ! Eh bien, ça se comprend... En fait, je suis tellement pris par le travail que je n'ai pas la tête à ça en ce moment. Les offres lucratives se succèdent, je ne peux pas laisser passer un bénéfice possible juste parce que ma femme s'inquiète.";
			link.l1 = "C'est sמr, mais vous pourriez au moins lui écrire que tout va bien.";
			link.l1.go = "HasbandCap_3";
		break;
		case "HasbandCap_3":
			dialog.text = "Oui, vous avez raison. Je vais lui écrire immédiatement !.. Merci infiniment de vous intéresser à nos affaires de famille !";
			link.l1 = "Je vous en prie, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "HasbandCap_inDeck_exit";
			npchar.DeckDialogNode = "HasbandCap_inDeck_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			sTemp = "SecondTimer_" + npchar.id;
			pchar.quest.(sTemp).over = "yes"; //снимаем установленный таймер на выход в море
			npchar.lifeDay = 0;
			sTemp = "SCQ_" + npchar.index;
			pchar.quest.(sTemp).over = "yes"; //снимаем прерывание смерть кэпа
			sld = characterFromId("QuestCitiz_" + npchar.quest.cribCity);
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			//удаляем запись в базе кэпов
			makearef(forName, NullCharacter.capitainBase);
			DeleteAttribute(forName, npchar.id);
		break;
		case "HasbandCap_inDeck": //встреча на палубе
			dialog.text = "Bonjour. א quoi dois-je l'honneur de vous voir sur mon navire ?";
			link.l1 = "Tu t'appelles " + GetFullName(npchar) + ", n'est-ce pas ?";
			link.l1.go = "HasbandCap_inDeck_1";
		break;
		case "HasbandCap_inDeck_1":
			dialog.text = "Oui, c'est moi.";
			link.l1 = "דa paraît bête, bien sמr, mais votre femme m'a demandé de vous dire qu'elle s'inquiète beaucoup pour vous.";
			link.l1.go = "HasbandCap_inDeck_2";
		break;
		case "HasbandCap_inDeck_2":
			dialog.text = "Ouf, bon sang ! Et moi, franchement, j'ai eu peur : je croyais que c'était le célèbre chasseur de primes, Steed Hunter le Borgne, qui me suivait. Eh bien, heureusement que je me suis trompé...\nVous savez, je suis tellement pris par le travail que je n'ai pas la tête à ça en ce moment. Les offres lucratives se succèdent, je ne peux pas laisser passer un bénéfice possible juste parce que ma femme s'inquiète.";
			link.l1 = "C'est sמr, mais vous pourriez au moins lui écrire que tout va bien.";
			link.l1.go = "HasbandCap_inDeck_3";
		break;
		case "HasbandCap_inDeck_3":
			dialog.text = "Oui, vous avez raison. Je le ferai sans faute au premier port de déchargement... Merci infiniment de vous intéresser à nos affaires de famille !";
			link.l1 = "Je vous en prie, l'ami.";
			link.l1.go = "exit";
			NextDiag.TempNode = "HasbandCap_inDeck_exit";
			npchar.DeckDialogNode = "HasbandCap_inDeck_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			npchar.quest = "outMap"; //доходит до нужной точки - и исчезает
			sld = characterFromId("QuestCitiz_" + npchar.quest.cribCity);
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			//удаляем запись в базе кэпов
			makearef(forName, NullCharacter.capitainBase);
			DeleteAttribute(forName, npchar.id);
		break;
		case "HasbandCap_inDeck_exit":
			dialog.text = "Encore une fois, merci...";
			link.l1 = "Ce n'est rien, ce n'est pas la peine.";
			link.l1.go = "exit";
			NextDiag.TempNode = "HasbandCap_inDeck_exit";
		break;
		//========= разыскиваемый капитан-обманщик ===========
		case "RevengeCap": //встреча на суше
			dialog.text = "Content de vous voir dans cette ville, capitaine. Vous avez besoin de quelque chose ?";
			link.l1 = ""+ GetSexPhrase("Vous savez, capitaine... Pff, je ne sais même pas comment le dire !", "Oui, en effet.") +"";
			link.l1.go = "RevengeCap_1";
		break;
		case "RevengeCap_1":
			dialog.text = ""+ GetSexPhrase("Dites-le comme c'est.", "Je me demande ce que c'est ?") +"";
			link.l1 = ""+ GetSexPhrase("Hum, c'est ce que je vais faire... Bref.  ", "") +"J'ai une question pour vous. Vous connaissez une dame nommée " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + " ?";
			link.l1.go = "RevengeCap_2";
		break;
		case "RevengeCap_2":
			dialog.text = "Hé, eh bien, oui, je la connais. J'ai eu le malheur, pour ainsi dire, d'avoir affaire à elle. Une sotte, je vous le dis...";
			link.l1 = "Hum... Eh bien, cette sotte m'a engagé pour vous tuer"+ GetSexPhrase(" – voilà, mon ami..", "") +".";
			link.l1.go = "RevengeCap_3";
		break;
		case "RevengeCap_3":
			dialog.text = "Eh bien, c'est tout simplement ridicule...";
			link.l1 = ""+ GetSexPhrase("Ce le serait, si ce n'était pas si triste... Désolé, mais il y a une récompense pour votre tête", "Il n'y a rien de drכle. Il y a une récompense pour votre tête") +". Et j'ai bien l'intention de la toucher.";
			link.l1.go = "RevengeCap_4";
		break;
		case "RevengeCap_4":
			dialog.text = "Ho ho !.. Vous êtes sérieux, capitaine ?";
			link.l1 = ""+ GetSexPhrase("Plus que jamais, mon ami...", "Je n'ai jamais été aussi sérieuse !") +"";
			link.l1.go = "RevengeCap_5";
		break;
		case "RevengeCap_5":
			dialog.text = ""+ GetSexPhrase("Quel ami es-tu, imbécile ?! Tu ne mérites même pas qu'on t'appelle capitaine. Un larbin aux ordres d'une furie querelleuse, voilà ce que tu es", "Bon sang ! Une furie querelleuse en a engagé une autre ! Qu'est-ce que c'est que ces histoires ?") +" !";
			link.l1 = ""+ GetSexPhrase("Ah oui ?!", "Vous vous êtes servi d'elle à des fins égoïstes, pas étonnant qu'elle ait décidé de se venger.") +"";
			link.l1.go = "RevengeCap_6";
		break;
		case "RevengeCap_6":
			dialog.text = ""+ GetSexPhrase("Eh bien, comment voulais-tu que je t'appelle ? Peu importe le nom, le fond ne changera pas...", "La solidarité féminine, c'est ça ?!") +"";
			link.l1 = ""+ GetSexPhrase("", "Vous savez, je suppose que c'est la même chose. ") +"Sortez votre lame !";
			link.l1.go = "RevengeCap_7";
			link.l2 = "Vous savez... Vivez, pour l'instant. Je ne veux pas souiller les rues de cette ville avec votre sang, ici même. Nous nous reverrons !";
			link.l2.go = "exit";
			NextDiag.TempNode = "RevengeCap_6lf";
		break;
		case "RevengeCap_6lf":
			dialog.text = GetSexPhrase("Ah !.. Le défenseur des filles opprimées ! Bien sמr, je me souviens de vous. Que vous faut-il ?", "Ah !.. L'employée d'une furie querelleuse ? Que vous faut-il ?");
			link.l1 = GetSexPhrase("Je suis venu te tuer, gredin.", "La méchante furie veut ta mort, salaud. Meurs !");
			link.l1.go = "RevengeCap_7";
			link.l2 = "Rien. Vaquez à vos occupations.";
			link.l2.go = "exit";
			NextDiag.TempNode = "RevengeCap_6lf";
		break;
		case "RevengeCap_7":
			NextDiag.TempNode = "RevengeCapCap_exit";
			npchar.DeckDialogNode = "RevengeCapCap_exit";
			npchar.quest.SeekCap = "womanRevengeFight"; //флаг квеста для зачёта в прерывании на убийство
			LAi_group_Attack(NPChar, Pchar);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		case "RevengeCapCap_exit":
			dialog.text = "J'ai déjà parlé avec vous. "+ GetSexPhrase("Dehors, gredin", "Dehors, misérable") +"...";
			link.l1 = ""+ GetSexPhrase("Gredin", "La méchante") +" ?! Très bien...";
			link.l1.go = "exit";
			NextDiag.TempNode = "RevengeCapCap_exit";
		break;
		case "RevengeCap_inDeck": //встреча на палубе
			dialog.text = "Content de vous voir sur mon pont, capitaine. Qu'est-ce qui vous amène ?";
			link.l1 = "J'ai une question pour vous. Vous connaissez une dame nommée " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + " ?";
			link.l1.go = "RevengeCap_inDeck_1";
		break;
		case "RevengeCap_inDeck_1":
			dialog.text = "Hé, eh bien, oui, je la connais. J'ai eu le malheur, pour ainsi dire, d'avoir affaire à elle. Une sotte, je vous le dis...";
			link.l1 = "Hé, eh bien, cette sotte m'a engagé pour vous tuer"+ GetSexPhrase(", mon ami. Voilà..", "") +".";
			link.l1.go = "RevengeCap_inDeck_2";
		break;
		case "RevengeCap_inDeck_2":
			dialog.text = "Hi hi... Capitaine, ne me faites pas rire. Si vous n'avez rien d'autre à me dire, alors adieu.";
			link.l1 = "Eh bien, adieu. Mais souvenez-vous de ce que je vous ai dit..";
			link.l1.go = "RevengeCap_inDeck_3";
		break;
		case "RevengeCap_inDeck_3":
			dialog.text = "Absolument, capitaine, comment donc ?!";
			link.l1 = "Bonne journée.";
			link.l1.go = "exit";
			NextDiag.TempNode = "RevengeCapCap_inDeck_exit";
			npchar.DeckDialogNode = "RevengeCapCap_inDeck_exit";
			npchar.quest.SeekCap = "womanRevengeFight"; //флаг квеста для зачёта в прерывании на убийство
		break;
		case "RevengeCapCap_inDeck_exit":
			dialog.text = "Je ne veux plus parler de ce sujet, capitaine. C'est ridicule.";
			link.l1 = "Eh bien, comme vous voudrez...";
			link.l1.go = "exit";
			NextDiag.TempNode = "RevengeCapCap_exit";
		break;
		case "RevengeCap_board": //абордаж
			dialog.text = "Qu'est-ce qui se passe, bon sang ?! Pourquoi avez-vous attaqué mon navire ?!";
			link.l1 = "Pour le compte "+ GetSexPhrase("d'une certaine dame, ", "d'une femme") +" du nom de " + GetFullName(&characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)]) + ". Cette personne vous dit quelque chose ?";
			link.l1.go = "RevengeCap_board_1";
		break;
		case "RevengeCap_board_1":
			dialog.text = "Diable !!! Je n'arrive pas à y croire..."+ GetSexPhrase("", " Une méchante furie en a engagé une autre !") +"";
			link.l1 = ""+ GetSexPhrase("Il le faudra pourtant.", "Il est temps de répondre de tes actes ignobles !") +"";
			link.l1.go = "RevengeCap_board_2";
		break;
		case "RevengeCap_board_2":
			dialog.text = "Eh bien, je ne vais pas mourir si facilement. Merci pour la conversation, elle m'a donné plus de force."+ GetSexPhrase(" Mais toi, son larbin,", " Et toi, sa copine,") +" je t'enverrai dans l'autre monde, avec cette furie !";
			link.l1 = "Essaie donc, que dire d'autre ?";
			link.l1.go = "RevengeCap_board_3";
		break;
		case "RevengeCap_board_3":
			LAi_SetCurHPMax(npchar);
			//==> флаг квеста сменим у оригинального кэпа
			characters[sti(npchar.baseCapIdx)].quest.SeekCap = "womanRevengeFight";
			QuestAboardCabinDialogFree(); // важный метод
			LAi_group_SetRelation(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, true);
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//========= вызволение мужа из пиратских затрюмков =========
		case "PiratesCap_inDeck": //встреча на палубе
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Heureux de vous voir sur mon pont. Puis-je vous être utile ?";
			link.l1 = "Probablement, oui. Je cherche un homme nommé " + sld.quest.SeekCap.name + " " + sld.quest.SeekCap.lastname + ".";
			link.l1.go = "PiratesCap_1";
		break;
		case "PiratesCap_inDeck_1":
			dialog.text = "Cet homme est mon prisonnier, et je compte en tirer une bonne rançon.";
			link.l1 = "Je veux le récupérer.";
			link.l1.go = "PiratesCap_inDeck_2";
		break;
		case "PiratesCap_inDeck_2":
			dialog.text = "Désolé, mais c'est impossible. Si c'est tout, je vous prie de quitter mon navire.";
			link.l1 = "Très bien, capitaine, comme vous voudrez.";
			link.l1.go = "exit";
			NextDiag.TempNode = "PiratesCapCap_exit";
			npchar.DeckDialogNode = "PiratesCapCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen")));
		break;
		case "PiratesCapCap_exit":
			dialog.text = "Nous avons déjà parlé de mon prisonnier. Rien n'a changé.";
			link.l1 = "Je vois...";
			link.l1.go = "exit";
		break;
		case "PiratesCap": //встреча на суше
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Salutations, capitaine. Puis-je vous être utile ?";
			link.l1 = "Probablement, oui. Je cherche un homme nommé " + sld.quest.SeekCap.name + " " + sld.quest.SeekCap.lastname + ".";
			link.l1.go = "PiratesCap_1";
		break;
		case "PiratesCap_1":
			dialog.text = "Cet homme est mon prisonnier, et je compte en tirer une bonne rançon.";
			link.l1 = "Je veux le récupérer.";
			link.l1.go = "PiratesCap_2";
		break;
		case "PiratesCap_2":
			dialog.text = "Désolé, mais ce n'est pas possible.";
			link.l1 = "Dommage...";
			link.l1.go = "exit";
			NextDiag.TempNode = "PiratesCapCap_exit";
			npchar.DeckDialogNode = "PiratesCapCap_exit";
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "5");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sShipTypeName", GetStrSmallRegister(XI_ConvertString(RealShips[sti(npchar.Ship.Type)].BaseName + "Gen")));
		break;
		case "PiratesCap_Board": //абордаж
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			dialog.text = "Diable ! Qu'est-ce que ça veut dire, bon sang ?!!";
			link.l1 = "J'ai besoin de votre prisonnier, du nom de " + sld.quest.SeekCap.name + " " + sld.quest.SeekCap.lastname + ".";
			link.l1.go = "PiratesCap_Board_1";
		break;
		case "PiratesCap_Board_1":
			dialog.text = "Ha ! Eh bien, non, seulement sur mon cadavre...";
			link.l1 = "Comme vous voudrez.";
			link.l1.go = "PiratesCap_Board_2";
		break;
		case "PiratesCap_Board_2":
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogFree(); // важный метод
			LAi_group_SetRelation(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, LAI_GROUP_ENEMY);
			LAi_group_FightGroups(LAI_GROUP_BRDENEMY, LAI_GROUP_PLAYER, true);
			LAi_group_SetCheck(LAI_GROUP_BRDENEMY, "CitizSeekCap_afterCabinFight");
			pchar.GenQuest.CitizSeekCap.label = npchar.quest.SeekCap; //флаг квеста для нпс
			pchar.GenQuest.CitizSeekCap.nation = npchar.nation;	//нацию для нпс
			pchar.GenQuest.CitizSeekCap.model = "citiz_"+(rand(9)+1); //модель для нпс
			pchar.GenQuest.CitizSeekCap.sex = "man";
			pchar.GenQuest.CitizSeekCap.ani = "man";
			pchar.GenQuest.CitizSeekCap.WifeCity = npchar.quest.cribCity; //исходный город для нпс
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			pchar.GenQuest.CitizSeekCap.WifeName = sld.quest.SeekCap.name; //имя и фамилию для нпс
			pchar.GenQuest.CitizSeekCap.WifeLastname = sld.quest.SeekCap.lastname;
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;
		//========= пленный муж ===========
		case "womanPirates_Board":
			dialog.text = "Qui êtes-vous ?";
			link.l1 = "Je me présente : capitaine " + GetFullName(pchar) + ", n'ayez pas peur, je viens vous chercher pour vous ramener auprès de votre femme.";
			link.l1.go = "womanPirates_Board_1";
		break;
		case "womanPirates_Board_1":
			dialog.text = "Bon sang, ce n'est pas un rêve ?!";
			link.l1 = "Je vous assure, ce n'est pas un rêve... Bon, c'est fait, maintenant filons d'ici.";
			link.l1.go = "exit";
			//уберём мужа из каюты
			npchar.location = "none";
			npchar.location.locator = "";
			LAi_SetPlayerType(pchar);
			AddPassenger(pchar, npchar, false);
			SetCharacterRemovable(npchar, false);
			sld = &characters[GetCharacterIndex("QuestCitiz_"+npchar.quest.cribCity)];
			sld.quest.SeekCap = sld.quest.SeekCap + "over"; //дополняем флаг квест до 'выполнен'
			sTitle = npchar.quest.cribCity + "SCQ_" + npchar.quest.SeekCap;
			AddQuestRecordEx(sTitle, "SCQ_" + npchar.quest.SeekCap, "6");
			AddQuestUserData(sTitle, "sName", GetFullName(npchar));
			AddQuestUserData(sTitle, "sCity", XI_ConvertString("Colony"+npchar.quest.cribCity+"Acc"));
		break;
		//несчастный мушкетёр
		case "OffMushketer":
			dialog.text = "Mes salutations, "+ GetSexPhrase("cher invité", "chère invitée") +". Que vouliez-vous ici ?";
			link.l1 = "Faire connaissance. Je me présente : capitaine " + GetFullName(pchar) + ".";
			link.l1.go = "OffM_1";
		break;
		case "OffM_1":
			dialog.text = "Ravi de faire votre connaissance, capitaine. En quoi puis-je vous aider ?";
			link.l1 = "Oh, rien de spécial... Vous avez l'air d'un militaire. Vous êtes toujours en service ?";
			link.l1.go = "OffM_2";
		break;
		case "OffM_2":
			dialog.text = "Plus maintenant, j'ai été renvoyé.";
			link.l1 = "Je vois. Et qu'étiez-vous dans l'armée ?";
			link.l1.go = "OffM_4";
		break;
		case "OffM_4":
			dialog.text = "Mousquetaire. J'étais le meilleur tireur du régiment !";
			link.l1 = "Ha, j'ai besoin de gens comme vous. Vous voulez rejoindre mon équipage comme officier ?";
			link.l1.go = "OffM_5";
		break;
		case "OffM_5":
			dialog.text = "Merci pour l'offre, mais je dois refuser.";
			link.l1 = "Dites-moi pourquoi ? Si ce n'est pas un secret, bien sמr...";
			link.l1.go = "OffM_6";
		break;
		case "OffM_6":
			dialog.text = "C'est à cause d'un traumatisme psychique. Je ne peux pas prendre les armes !";
			link.l1 = "Tout ça est étrange. Mais comment vous battiez-vous dans l'armée ?";
			link.l1.go = "OffM_7";
		break;
		case "OffM_7":
			dialog.text = "Vous voyez, j'avais à l'époque un mousquet anglais, qui vaut une fortune. Deux canons, une culasse améliorée qui permet de recharger plus vite. Bref, une véritable œuvre d'art, le travail d'un maître.\n"+
				"Et je me suis tellement attaché à cette arme que je n'en reconnais aucune autre.";
			link.l1 = "Et oם est ce mousquet miracle maintenant ?";
			link.l1.go = "OffM_8";
		break;
		case "OffM_8":
			dialog.text = "Ah, ça fait mal rien que d'y penser... Quand je suis venu ici de l'Ancien Monde, nous avons été attaqués par des pirates. J'ai voulu ouvrir le feu sur eux, et croyez-moi, j'aurais tué bon nombre de ces voyous. Mais notre équipage s'est jeté sur moi et m'a cloué au sol !..";
			link.l1 = "Croyez-moi, ils ont bien fait. Au moins, vous êtes encore en vie.";
			link.l1.go = "OffM_9";
		break;
		case "OffM_9":
			dialog.text = "En vie, mais sans mon mousquet ! Et quelle vie est-ce là !..";
			link.l1 = "Bah, il en existe peut-être un autre pareil...";
			link.l1.go = "OffM_10";
		break;
		case "OffM_10":
			dialog.text = "Vous croyez ? Hum, écoutez, si vous retrouvez mon mousquet à deux canons, alors je vous rejoindrai comme officier. Je vous le promets.";
			link.l1 = "Bon, je vous ai compris. Et qui s'est emparé de votre navire ?";
			link.l1.go = "OffM_11";
		break;
		case "OffM_11":
			dialog.text = "C'était il y a deux ans, et depuis, je vivote. Je n'ai pas vu qui étaient ces pirates, j'étais ligoté avec un sac sur la tête. L'équipage criait quelque chose à propos d'une flèche, mais je ne sais pas ce que c'est.";
			link.l1 = "Oui, quelle situation... Bon, comme on dit, on cherchera. Si je tombe sur votre mousquet, je l'apporterai ici sans faute.";
			link.l1.go = "OffM_12";
		break;
		case "OffM_12":
			dialog.text = "Merci. J'attendrai avec impatience.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
			pchar.questTemp.mushket2x2 = true;
			AddQuestRecord("SeekDoubleMushket", "1");
			NextDiag.TempNode = "OffM_result";
		break;

		case "OffM_result":
			dialog.text = "Vous avez retrouvé mon mousquet ?";
			if (CheckCharacterItem(pchar, "mushket2x2"))
			{
				link.l1 = "Oui, mon ami, je l'ai retrouvé. Le voici, un mousquet à deux canons, il n'y en a pas d'autre comme lui.";
				link.l1.go = "OffM_result_1";
			}
			else
			{
				link.l1 = "Pas encore. Mais je m'en occupe.";
				link.l1.go = "exit";
			}
		break;
		case "OffM_result_1":
			dialog.text = "Formidable ! Eh bien, la vie ne fait que commencer !";
			link.l1 = "Bien. Maintenant, j'attends que vous teniez votre promesse de devenir mon officier.";
			link.l1.go = "OffM_result_2";
			TakeItemFromCharacter(pchar, "mushket2x2");
			Npchar.quest.OfficerPrice = sti(pchar.rank)*300;
		break;
		case "OffM_result_2":
			dialog.text = "Ma parole est de fer. Je suis prêt. Discutons seulement du montant de ma solde. Pour mon fidèle service, je veux recevoir " + FindRussianMoneyString(sti(Npchar.quest.OfficerPrice)) + " par mois.";
			link.l1 = "Vous ne trouvez pas que c'est trop ?";
			link.l1.go = "OffM_trade";
			link.l1 = "Bon, d'accord, j'accepte.";
			link.l1.go = "OffM_Ok";
		break;
		case "OffM_trade":
			dialog.text = "Non, je vaux bien plus.";
			link.l1 = "Bon, d'accord, j'accepte.";
			link.l1.go = "OffM_Ok";
		break;
		case "OffM_Ok":
			Npchar.quest.OfficerPrice.add = sti(pchar.rank)*1000;
			dialog.text = "Bien. Mais ce n'est pas tout. J'exige une somme forfaitaire, pour ainsi dire. J'ai été sans travail, je dois donc payer mes dettes. Je pense que " + FindRussianMoneyString(sti(Npchar.quest.OfficerPrice.add)) + " me conviendront.";
			link.l1 = "Quoi ?!!";
			link.l1.go = "OffM_Ok_1";
		break;
		case "OffM_Ok_1":
			dialog.text = "Et rien d'autre... Bref, décidez.";
			if (sti(pchar.money) < sti(Npchar.quest.OfficerPrice.add))
			{
				link.l1 = "Je n'ai pas assez d'argent.";
				link.l1.go = "OffM_noMoney";
			}
			else
			{
				link.l1 = "C'est très cher pour moi.";
				link.l1.go = "OffM_noMoney";
				link.l2 = "D'accord, j'accepte.";
				link.l2.go = "OffM_Ok_3";
			}
			NextDiag.TempNode = "OffM_TWO";
		break;
		case "OffM_noMoney":
			dialog.text = "Alors revenez quand vous serez riche. Bonne chance.";
			link.l1 = "Merci...";
			link.l1.go = "exit";
		break;
		case "OffM_Ok_3":
			dialog.text = "Eh bien, voilà qui est tout autre chose ! Je suis prêt à vous servir fidèlement.";
			link.l1 = "Parfait. Bienvenue dans l'équipage.";
			link.l1.go = "exit_hire";
		break;
		case "exit_hire":
			AddQuestRecord("SeekDoubleMushket", "3");
			CloseQuestHeader("SeekDoubleMushket");
			pchar.questdata.NaitiMushket = 1;
			AddMoneyToCharacter(pchar, -sti(Npchar.quest.OfficerPrice.add));
			npchar.perks.list.Gunman = "1";
			AddItems(npchar, "bullet", 50);
			AddItems(npchar, "GunPowder", 50);
			npchar.IsMushketer = true;
			Npchar.CanTakeMushket = true;
			npchar.model = "MusketeerEnglish_2";
			// Прописка всех моделей для кирас. -->
        	npchar.HeroModel = "MusketeerEnglish_2,MusketeerEnglish_2_1,MusketeerEnglish_2_2,MusketeerEnglish_2_3,MusketeerEnglish_2_4,MusketeerEnglish_2_5,MusketeerEnglish_2,MusketeerEnglish_2,MusketeerEnglish_2";
	        // Прописка всех моделей для кирас. <--
			npchar.model.animation = "mushketer";
			GiveItem2Character(npchar, "mushket2x2");
			npchar.IsMushketer.LastGunID = -1;
			npchar.equip.gun = "mushket2x2";
			EquipCharacterByItem(NPChar, "mushket2x2");
			npchar.IsMushketer.MushketID = "mushket2x2";
			npchar.MusketerDistance = 10.0;
			npchar.isMusketer = true;
			npchar.isMusketer.weapon = true;
			npchar.greeting = "Gr_questOfficer";
			npchar.Dialog.Filename = "Enc_Officer_dialog.c";
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.OfficerWantToGo.DontGo = true; //не пытаться уйти
			npchar.loyality = MAX_LOYALITY;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			NextDiag.CurrentNode = NextDiag.TempNode;
			NPChar.quest.meeting = true;
			LAi_MethodDelay("FrameGiveMushket",0.1);
			DialogExit();
		break;
		case "OffM_TWO":
			dialog.text = "Alors, oם en êtes-vous cכté finances ? Je vous rappelle que je veux " + FindRussianMoneyString(sti(Npchar.quest.OfficerPrice.add)) + " d'indemnité unique et " + FindRussianMoneyString(sti(Npchar.quest.OfficerPrice)) + " de solde mensuelle.";
			if (sti(pchar.money) < sti(Npchar.quest.OfficerPrice.add))
			{
				link.l1 = "Non, je n'y arriverai pas encore...";
				link.l1.go = "OffM_noMoney";
			}
			else
			{
				link.l1 = "C'est très cher pour moi.";
				link.l1.go = "OffM_noMoney";
				link.l2 = "D'accord, j'accepte.";
				link.l2.go = "OffM_Ok_3";
			}
			NextDiag.TempNode = "OffM_TWO";
		break;
	}
}


void GetPerlShore()
{
	switch (rand(5))
	{
		case 0:
			pchar.questTemp.Sharp.PearlAreal = "Mein";
			pchar.questTemp.Sharp.PearlAreal.Island = "Beliz";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore_ship2";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_8";
			pchar.questTemp.Sharp.PearlAreal.add = ". C'est près de Belize.";
			break;
		case 1:
			pchar.questTemp.Sharp.PearlAreal = "Mein";
			pchar.questTemp.Sharp.PearlAreal.Island = "Cumana";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore18";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_8";
			pchar.questTemp.Sharp.PearlAreal.add = ". C'est près de Cumaná.";
			break;
		case 2:
			pchar.questTemp.Sharp.PearlAreal = "Dominica";
			pchar.questTemp.Sharp.PearlAreal.Island = "Dominica";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore26";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_3";
			break;
		case 3:
			pchar.questTemp.Sharp.PearlAreal = "Terks";
			pchar.questTemp.Sharp.PearlAreal.Island = "Terks";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore56";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_1";
			break;
		case 4:
			pchar.questTemp.Sharp.PearlAreal = "Caiman";
			pchar.questTemp.Sharp.PearlAreal.Island = "Caiman";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore17";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_1";
			break;
		case 5:
			pchar.questTemp.Sharp.PearlAreal = "StLucia";
			pchar.questTemp.Sharp.PearlAreal.Island = "StLucia";
			pchar.questTemp.Sharp.PearlAreal.Shore = "Shore65";
			pchar.questTemp.Sharp.PearlAreal.locator = "Quest_ship_1";		//ЕСТЬ ли локатор Quest_ship_1 на СантаЛюсии?
			break;
	}
	pchar.questTemp.Sharp.PearlAreal.terms = rand(5) + 5; //сроки
	pchar.questTemp.Sharp.PearlAreal.qtyShips = rand(6) + 6; //кол-во тартан ловцов
	pchar.questTemp.Sharp.PearlAreal.SmallPearlQty = 0; //для итогового подсчёта
	pchar.questTemp.Sharp.PearlAreal.BigPearlQty = 0;
}

void SetSeekCapCitizenParam(ref npchar, int iNation)
{
	//создаём кэпов
	int Rank = sti(pchar.rank) + 5;
	if (Rank > 30) Rank = 30;
	ref sld = GetCharacter(NPC_GenerateCharacter("SeekCitizCap_" + npchar.index, "", "man", "man", Rank, iNation, -1, true));
	switch (npchar.quest.SeekCap)
	{
		case "manSlave":
			SetCaptanModelByEncType(sld, "pirate");
			SetShipToFantom(sld, "pirate", true);
			sld.Ship.Mode = "pirate";
			sld.dialog.currentnode = "CitizCap";
			sld.DeckDialogNode = "CitizCap_inDeck";
		break;
		case "manRapeWife":
			SetCaptanModelByEncType(sld, "pirate");
			SetShipToFantom(sld, "pirate", true);
			sld.Ship.Mode = "pirate";
			sld.dialog.currentnode = "RapeWifeCap";
			sld.DeckDialogNode = "RapeWifeCap_inDeck";
		break;
		case "manFriend":
			SetCaptanModelByEncType(sld, "trade");
			SetShipToFantom(sld, "trade", true);
			sld.Ship.Mode = "trade";
			sld.dialog.currentnode = "FriendCap";
			sld.DeckDialogNode = "FriendCap_inDeck";
		break;
		case "womanHasband":
			SetCaptanModelByEncType(sld, "trade");
			SetShipToFantom(sld, "trade", true);
			sld.Ship.Mode = "trade";
			sld.dialog.currentnode = "HasbandCap";
			sld.DeckDialogNode = "HasbandCap_inDeck";
		break;
		case "womanRevenge":
			SetCaptanModelByEncType(sld, "pirate");
			SetShipToFantom(sld, "pirate", true);
			sld.Ship.Mode = "pirate";
			sld.dialog.currentnode = "RevengeCap";
			sld.DeckDialogNode = "RevengeCap_inDeck";
		break;
		case "womanPirates":
			SetCaptanModelByEncType(sld, "pirate");
			SetShipToFantom(sld, "pirate", true);
			sld.Ship.Mode = "pirate";
			sld.dialog.currentnode = "PiratesCap";
			sld.DeckDialogNode = "PiratesCap_inDeck";
		break;
	}
	sld.dialog.filename = "Quest\ForAll_dialog.c";
	DeleteAttribute(sld, "Sinking Percent");
	DeleteAttribute(sld, "SaveItemsForDead");
	DeleteAttribute(sld, "DontClearDead");
	DeleteAttribute(sld, "AboardToFinalDeck");
	DeleteAttribute(sld, "Sinking Percent");
	DeleteAttribute(sld, "DontRansackCaptain");
	sld.AlwaysSandbankManeuver = true;
	sld.AnalizeShips = true;  //анализировать вражеские корабли при выборе таска
	sld.DontRansackCaptain = true; //не сдаваться
	SetCharacterPerk(sld, "FastReload");
	SetCharacterPerk(sld, "HullDamageUp");
	SetCharacterPerk(sld, "SailsDamageUp");
	SetCharacterPerk(sld, "CrewDamageUp");
	SetCharacterPerk(sld, "CriticalShoot");
	SetCharacterPerk(sld, "LongRangeShoot");
	SetCharacterPerk(sld, "CannonProfessional");
	SetCharacterPerk(sld, "ShipDefenseProfessional");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "ShipTurnRateUp");
	SetCharacterPerk(sld, "StormProfessional");
	SetCharacterPerk(sld, "SwordplayProfessional");
	SetCharacterPerk(sld, "AdvancedDefense");
	SetCharacterPerk(sld, "CriticalHit");
	SetCharacterPerk(sld, "Sliding");
	SetCharacterPerk(sld, "Tireless");
	SetCharacterPerk(sld, "HardHitter");
	SetCharacterPerk(sld, "GunProfessional");
	//в морскую группу кэпа
	string sGroup = "SeekCapShip_" + sld.index;
	Group_FindOrCreateGroup(sGroup);
	Group_SetTaskAttackInMap(sGroup, PLAYER_GROUP);
	Group_LockTask(sGroup);
	Group_AddCharacter(sGroup, sld.id);
	Group_SetGroupCommander(sGroup, sld.id);
	SetRandGeraldSail(sld, sti(sld.Nation));
	//записываем данные в структуры портмана и кэпа
	npchar.quest.SeekCap.capId = sld.id //Id искомого кэпа
	npchar.quest.SeekCap.capName = GetFullName(sld); //имя искомого кэпа
	npchar.quest.SeekCap.shipName = sld.Ship.name; //имя украденного корабля
	npchar.quest.SeekCap.shipTapeName = RealShips[sti(sld.Ship.Type)].BaseName; //название украденного корабля
	npchar.quest.money = ((sti(RealShips[sti(sld.Ship.Type)].basetype)+1) * 1000) + (sti(pchar.rank)*500); //вознаграждение
	npchar.quest.gem = GenQuestCitizen_GenerateGem(); //камешки
	sld.quest = "InMap"; //личный флаг искомого кэпа
	sld.quest.SeekCap = npchar.quest.SeekCap; //запишем кэпу флаг квеста
	sld.quest.nation = iNation; //запомним базовую нацию кэпа
	sld.city = SelectAnyColony(npchar.city); //определим колонию, откуда кэп-вор выйдет
	sld.quest.targetCity = SelectAnyColony2(npchar.city, sld.city); //определим колонию, куда он придёт
	Log_TestInfo("The Wanted Cap" + sld.id + " out of: " + sld.city + " and headed to: " + sld.quest.targetCity);
	sld.quest.cribCity = npchar.city; //город, где ошивается квестодатель
	//==> на карту
	sld.mapEnc.type = "trade";
	//выбор типа кораблика на карте
	switch (npchar.quest.SeekCap)
	{
		case "manSlave":	 sld.mapEnc.worldMapShip = "Galleon_red"; break;
		case "manRapeWife":	 sld.mapEnc.worldMapShip = "Galleon_red"; break;
		case "manFriend":	 sld.mapEnc.worldMapShip = "Galleon_red"; break; //стояла модель кораблекрушенца ranger
		case "womanHasband": sld.mapEnc.worldMapShip = "Galleon_red"; break; //стояла модель кораблекрушенца ranger
		case "womanRevenge": sld.mapEnc.worldMapShip = "Galleon_red"; break;
		case "womanPirates": sld.mapEnc.worldMapShip = "Galleon_red"; break;
	}
	sld.mapEnc.Name = XI_ConvertString(npchar.quest.SeekCap.shipTapeName) + " '" + npchar.quest.SeekCap.shipName + "'";
	int daysQty = GetMaxDaysFromIsland2Island(GetArealByCityName(sld.quest.targetCity), GetArealByCityName(sld.city)) + 1; //дней доехать даём с запасом
	Map_CreateTrader(sld.city, sld.quest.targetCity, sld.id, daysQty);
	//прерывание на смерть кэпа
	string sTemp = "SCQ_" + sld.index;
	pchar.quest.(sTemp).win_condition.l1 = "NPC_Death";
	pchar.quest.(sTemp).win_condition.l1.character = sld.id;
	pchar.quest.(sTemp).function = "SCQ_seekCapIsDeath";
	pchar.quest.(sTemp).CapId = sld.id;
	//прерывание на смерть квестодателя
	sTemp = "SCQ_" + npchar.index;
	pchar.quest.(sTemp).win_condition.l1 = "NPC_Death";
	pchar.quest.(sTemp).win_condition.l1.character = npchar.id;
	pchar.quest.(sTemp).function = "SCQ_CitizenIsDeath";
	pchar.quest.(sTemp).CapId = sld.id;
	pchar.quest.(sTemp).CitizenId = npchar.id;
	//заносим Id кэпа в базу нпс-кэпов
	sTemp = sld.id;
	NullCharacter.capitainBase.(sTemp).quest = "citizen"; //идентификатор квеста
	NullCharacter.capitainBase.(sTemp).questGiver = npchar.id; //запомним Id квестодателя для затирки в случае чего
	NullCharacter.capitainBase.(sTemp).Tilte1 = sld.quest.cribCity + "SCQ_" + npchar.quest.SeekCap; //заголовок квестбука
	NullCharacter.capitainBase.(sTemp).Tilte2 = "SCQ_" + npchar.quest.SeekCap; //имя квеста в квестбуке
	NullCharacter.capitainBase.(sTemp).checkTime = daysQty + 2;
    NullCharacter.capitainBase.(sTemp).checkTime.control_day = GetDataDay();
    NullCharacter.capitainBase.(sTemp).checkTime.control_month = GetDataMonth();
    NullCharacter.capitainBase.(sTemp).checkTime.control_year = GetDataYear();
}

string GenQuestCitizen_GenerateGem() // камни
{
	string itemID;
	switch(rand(5))
	{
		case 0:
			itemID = "jewelry1";
		break;
		case 1:
			itemID = "jewelry2";
		break;
		case 2:
			itemID = "jewelry3";
		break;
		case 3:
			itemID = "jewelry4";
		break;
		case 4:
			itemID = "jewelry5";
		break;
		case 5:
			itemID = "jewelry17";
		break;
	}
	return itemID;
}
