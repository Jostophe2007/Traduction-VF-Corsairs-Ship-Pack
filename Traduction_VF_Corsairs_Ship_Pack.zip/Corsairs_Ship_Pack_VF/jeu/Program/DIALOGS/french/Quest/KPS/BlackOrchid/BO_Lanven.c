// Gregg: Stefan Lanven - the "Black Orchid" trilogy (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\blackorchid.c
// The player's employer through the second half of chapter 4:
//   1-27  - the first meeting in the Fort de France residence, the truth about Levinson
//           and the list of the seven seekers;
//   28-34 - the report on Brian George's chest, the task of finding the lock combination;
//   35-36 - the book is open, Lanven needs four days;
//   37-50 - the book proves worthless, but there is word of Matilda.
// Nodes 51-60 of the original belong to the "Deadly Smoking" quest and were not ported.
// The squadron carrying Matilda to the Bay of Doom is frigates here, not ships of the
// line - see the comment in MysteriousArtefactStefanLanvenIsPassenger.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sName = PChar.name;

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Dépêchez-vous, le temps n'attend pas !";
			link.l1 = "J'y vais.";
			link.l1.go = "exit";

			if (PChar.MysteriousArtefact == "12")
			{
				dialog.text = "Comment vont vos affaires ?";
				link.l1 = "Je m'en occupe du mieux que je peux.";
				link.l1.go = "exit";
			}
			if (PChar.MysteriousArtefact == "15")
			{
				dialog.text = "Avez-vous ouvert le livre ?";
				link.l1 = "Pas encore.";
				link.l1.go = "exit";
			}
			if (PChar.MysteriousArtefact == "16")
			{
				TakeNItems(PChar, "MysteriousArtefact_Coin", -1);
				TakeNItems(PChar, "MysteriousArtefact_Book", -1);
				dialog.text = "Avez-vous ouvert le livre ?";
				link.l1 = "Oui. Tenez, prenez-le.";
				link.l1.go = "35";
			}
			if (PChar.MysteriousArtefact == "17")
			{
				dialog.text = "Je dois finir de lire le livre.";
				link.l1 = "Très bien, je reviendrai plus tard.";
				link.l1.go = "exit";
			}
			if (PChar.MysteriousArtefact == "18")
			{
				dialog.text = "Dépêchez-vous, le temps n'attend pas !";
				link.l1 = "Je suis déjà en train de me préparer pour le voyage.";
				link.l1.go = "exit";
			}
		break;

		case "1":
			dialog.text = "Bonjour, capitaine " + PChar.lastname + ". Je suis heureux de vous voir vivant et en assez bonne santé.";
			link.l1 = "Vous êtes Stefan Lanven ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je suis Stefan Lanven, même si je préfère qu'on m'appelle Stefano. דa me plaît davantage : il y a quelque chose d'italien dans la sonorité, voyez-vous.";
			link.l1 = "Quelque chose d'italien ? Pardonnez-moi, je ne vous suis pas.";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "L'Italie, mon ami, l'Italie. Une terre aux horizons merveilleux, à la beauté inoubliable, aux filles délicieuses, la patrie du meilleur vin du monde. Et le Colisée ! Rien qu'un regard sur ce majestueux édifice vaut le voyage, sur la beauté de ses arches. \nAu premier regard, le Colisée laisse le voyageur sans voix et le retient, contemplant sans fin ce grandiose ouvrage de mains humaines. Je ne cesserai jamais de regretter d'avoir échangé ces lieux merveilleux contre la grisaille morne de ces colonies françaises abandonnées de Dieu.";
			link.l1 = "Dans les îles des Caraïbes, vous trouverez bien des beautés intactes qui vous conquerront par leur... par leur... par leur... comment dire...";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Ne vous donnez pas la peine de chercher l'épithète qui convient, mon ami. Les limites de votre intellect sont trop étroites, et le vocabulaire nécessaire pour décrire avec éloquence les étendues des Caraïbes s'est épuisé depuis longtemps.";
			link.l1 = "...(retenant sa colère)... וcoutez, Stefano, pourrions-nous en venir directement aux affaires ? Je n'ai aucune envie d'écouter ces sornettes.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Pardonnez-moi, capitaine. Parfois, le poète en moi s'éveille, ainsi que la nostalgie de l'Italie, la terre oם j'ai trouvé le bonheur et l'amour éternel en la personne de la belle Sophia, dont la beauté m'a foudroyé ; je suis tombé amoureux au premier regard, et...";
			link.l1 = "Vous me parlerez de votre amour une autre fois.";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "C'est bien dommage. J'avais compté trouver en vous un compagnon intelligent et un auditeur attentif. Il semble que je me sois trompé. Très bien, venons-en aux affaires.";
			link.l1 = "...(pour lui-même : enfin !)...";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Capitaine " + PChar.lastname + ", je sais que vous cherchez un certain artefact, la prétendue Orchidée noire. Je vous préviens tout de suite : nier, objecter, dire quelque chose comme « vous devez faire erreur » ou « non, j'entends parler de cet artefact pour la première fois » est parfaitement inutile. \nJe suis excellemment informé et je sais toujours tout. Eh bien, moi aussi, je cherche l'Orchidée noire, et depuis longtemps. Mais il y a un problème qui entrave grandement mes recherches. Savez-vous lequel ?";
			link.l1 = "Vous n'avez pas assez d'argent ?";
			link.l1.go = "8";
			link.l2 = "Quelqu'un vous gêne beaucoup ?";
			link.l2.go = "9";
			link.l3 = "On en sait trop peu sur l'artefact ?";
			link.l3.go = "10";
		break;

		case "8":
			dialog.text = "Le problème n'est pas l'argent, capitaine " + PChar.lastname + " ; de l'argent, j'en ai à revendre. J'ai besoin d'un homme qui ait la tête sur les épaules : quelqu'un qui prenne vite la bonne décision, juge correctement une situation, trouve une issue là oם il semble ne pas y en avoir. Autrement dit, j'ai besoin de vous.";
			link.l1 = "Je croyais que ma mission était autre : trouver Matilda et la tuer.";
			link.l1.go = "11";
		break;

		case "9":
			dialog.text = "Des ennemis, j'en ai à revendre, mais le problème est ailleurs. J'ai besoin d'un homme qui ait la tête sur les épaules : quelqu'un qui prenne vite la bonne décision, juge correctement une situation, trouve une issue là oם il semble ne pas y en avoir. Autrement dit, j'ai besoin de vous, capitaine " + PChar.lastname + ".";
			link.l1 = "Je croyais que ma mission était autre : trouver Matilda et la tuer.";
			link.l1.go = "11";
		break;

		case "10":
			dialog.text = "Non, capitaine, ce n'est pas ça. Sur l'Orchidée noire, j'en sais beaucoup. J'ai besoin d'un homme qui ait la tête sur les épaules : quelqu'un qui prenne vite la bonne décision, juge correctement une situation, trouve une issue là oם il semble ne pas y en avoir. Autrement dit, j'ai besoin de vous, capitaine " + PChar.lastname + ".";
			link.l1 = "Je croyais que ma mission était autre : trouver Matilda et la tuer.";
			link.l1.go = "11";
		break;

		case "11":
			dialog.text = "...(d'un ton moqueur)... Tuer Matilda ? Vous croyez vraiment que je vous ai tiré de cette cage pour ça seulement ? Inutile de répondre, je sais que oui. Mais vous avez en partie raison : tכt ou tard, vous devrez la tuer. \nMais sa mort n'est qu'une partie de mon grand dessein. Si ce dessein réussit, nous aurons l'Orchidée noire. Et vous m'aiderez à le réaliser. Ah, et au fait, considérez-vous toujours Frederick Levinson comme un ami ?";
			link.l1 = "...(pour lui-même : le rusé démon, il est au courant pour Frederick aussi)... Pourquoi me demandez-vous ça ? Mes affaires avec Levinson ne vous regardent pas.";
			link.l1.go = "12";
		break;

		case "12":
			dialog.text = "Je pense le contraire. Vous avez promis d'aider Frederick à chercher l'Orchidée, au nom d'une vieille amitié, pour ainsi dire. Mais vous n'avez aucune idée de qui est Frederick Levinson. Vous souvenez-vous d'avoir été attaqué, il y a quelques années, par deux navires espagnols au large de Niévès ? Je vois que oui. \nEh bien, ils n'étaient pas là par hasard. Ces navires vous attendaient, vous et le capitaine Anthony, pour vous attaquer et vous détruire. Et ils agissaient sur l'indication de Frederick Levinson. L'homme que vous considérez comme un ami depuis toutes ces années. Vous êtes ébranlé, mais j'ai jugé bon que vous le sachiez.";
			link.l1 = "...(lourdement)... Comment le savez-vous ?";
			link.l1.go = "13";
		break;

		case "13":
			dialog.text = "Après l'affaire de Porto Rico, le capitaine Anthony vous a beaucoup aidé. Vous avez dמ lui donner sa part et partager le butin en trois plutכt qu'en deux, comme prévu au départ. Frederick en a été amèrement contrarié : il comptait sur la moitié et n'a eu qu'un tiers. \nMais, jugeant sensément qu'insister pour avoir sa moitié lui coמterait plus que ça ne valait, il a accepté un tiers. Ensuite, il a quitté l'escadre et mis le cap sur Porto Rico, oם il a parlé au gouverneur des hommes qui avaient enlevé sa fille, c'est-à-dire vous et Anthony, sans rien dire de son propre rכle, et il a signalé que vous faisiez route vers Niévès. \nLe gouverneur a envoyé deux navires à votre poursuite. De nuit, ils vous ont rattrapés au large de Niévès et vous ont coulés. Pourtant, de sources sמres, on sait que vous deviez être abordés, pour qu'on puisse récupérer l'or espagnol. Pourquoi ils ont désobéi à cet ordre, je l'ignore. Le gouverneur a récompensé Levinson par la lettre de marque royale dont il rêvait. \nPendant un temps, Frederick a travaillé pour l'Espagne, jusqu'à ce qu'il apprenne par hasard l'existence de l'Orchidée noire. Sur quoi, trahissant l'Espagne, il s'est lancé à sa recherche. Vous connaissez la suite : vous l'avez sauvé près de la grotte des Bermudes, il vous a parlé de l'Orchidée, et vous avez accepté de l'aider, alors qu'il était évident qu'il se servait de vous.";
			link.l1 = "Donc, Levinson était dans les Caraïbes pendant tout ce temps ? Il n'est jamais allé en Europe ?";
			link.l1.go = "14";
		break;

		case "14":
			dialog.text = "Jamais. Levinson travaillait pour les Espagnols pendant tout ce temps.";
			link.l1 = "Alors tout ce qu'il m'a raconté sur Alejon Kendart, sur l'Escadre insaisissable, n'était que mensonge ?";
			link.l1.go = "15";
		break;

		case "15":
			dialog.text = "Les histoires de l'Escadre insaisissable et du vieux Kendart ne sont pas des inventions. Elles sont vraies.";
			link.l1 = "Je n'y comprends rien. Frederick disait avoir rencontré Kendart en Europe, dans sa propre ferme.";
			link.l1.go = "16";
		break;

		case "16":
			dialog.text = "Un mensonge. Levinson l'a inventé pour que vous, " + sName + ", croyiez qu'il était vraiment allé en Europe. Il a appris l'histoire de Kendart d'une autre source : laquelle, je l'ignore.";
			link.l1 = "Et moi qui considérais ce rat comme un ami.";
			link.l1.go = "17";
		break;

		case "17":
			dialog.text = "Vous aurez l'occasion de le lui rendre. Et maintenant, laissez-moi vous dire une chose. Beaucoup de gens connaissent l'Orchidée noire. Tous ne croient pas qu'elle existe ; la plupart prennent ces histoires pour une jolie légende. Parmi ceux qui y croient, seule une poignée essaie de la trouver. Et parmi eux, très peu arrivent à quoi que ce soit. \nIl y en a sept qui sont allés très loin. Le premier se tient devant vous. La deuxième est Matilda. Le troisième n'est autre que votre « ami » Frederick Levinson. Le quatrième est Brian George, que vous avez tué. Le cinquième est un Hollandais qu'on appelle Tulipe. Le sixième est un personnage mystérieux, sir Andrew Murdoch. Le septième, c'est vous.";
			link.l1 = "Moi ? Comparé à ce que vous savez, je ne sais absolument rien.";
			link.l1.go = "18";
		break;

		case "18":
			dialog.text = "Les autres n'en savent même pas autant. Vous connaissez les sept chercheurs. Vous connaissez les anciens possesseurs de l'Orchidée : don Pedro de la Encantario, amiral de l'Escadre insaisissable, le vieil Alejon Kendart, Alvarez Istilochos et, en dernier, Bertrand Grenadier.";
			link.l1 = "Grenadier et Istilochos ont possédé l'Orchidée ?!";
			link.l1.go = "19";
		break;

		case "19":
			dialog.text = "Oui, je pensais bien que vous devineriez. Istilochos l'a possédée. Vous connaissez l'histoire de la mort mystérieuse de son compagnon : on l'a retrouvé mort dans sa propre cabine. Istilochos a utilisé l'un des pouvoirs de l'Orchidée, il est passé dans la cabine d'un autre navire et il l'a tué.";
			link.l1 = "N'importe qui aurait pu le faire : n'importe quel marin, n'importe quel homme de l'équipage.";
			link.l1.go = "20";
		break;

		case "20":
			dialog.text = "D'après les marins, il y avait une faible lueur argentée dans la cabine. La même lueur régnait dans la cabine du vaisseau de ligne Azor quand Kendart a disparu. L'Orchidée noire laisse cette lueur derrière elle quand on utilise l'un de ses pouvoirs.";
			link.l1 = "Et Grenadier ? D'oם venait l'Orchidée entre ses mains ? Attendez ! Alors, il...";
			link.l1.go = "21";
		break;

		case "21":
			dialog.text = "Vous y êtes enfin. Oui, Bertrand savait que l'Orchidée était chez Istilochos. Pendant le conseil de guerre précédant l'assaut de Port-au-Prince, il l'a volée, et ensuite, il l'a tué. Il y en a cependant trois autres qui ont possédé l'Orchidée, ou du moins qui l'ont tenue : le docker Giancarlo, le mendiant Jack Strbeton et enfin moi, Stefan Lanven. Même si moi, je n'ai fait que la voir, sans jamais la tenir.";
			link.l1 = "Comment cela ? Dans quelles circonstances ?";
			link.l1.go = "22";
		break;

		case "22":
			dialog.text = "...(avec colère)... דa, je ne vous le dirai jamais. N'essayez même pas de le demander. Compris ?";
			link.l1 = "Comme vous voudrez. Alors, une autre question. Comment l'Orchidée noire a-t-elle pu tomber entre les mains d'un docker et d'un mendiant ?";
			link.l1.go = "23";
		break;

		case "23":
			dialog.text = "Tout est embrouillé. L'ordre dans lequel l'Orchidée est passée d'un homme à l'autre est difficile à établir, mais j'y suis parvenu. Le premier à la trouver a été le docker Giancarlo. En se reposant sur la jetée, il a vu une faible lueur dans l'eau. \nIl a plongé et a remonté l'Orchidée noire, devenant ainsi son premier possesseur. Giancarlo l'a montrée à son ami, le mendiant Jack Strbeton. Le lendemain, Giancarlo a été tué, et l'Orchidée s'est retrouvée chez Strbeton. Ensuite, elle est passée à Istilochos, on ne sait pas exactement comment. Puis est venu Grenadier, dont vous connaissez l'histoire. \nEnsuite, c'est moi qui l'ai possédée, et après moi, l'amiral don Pedro de la Encantario. Alejon Kendart a été le dernier. Après lui, personne n'a revu l'Orchidée, et personne ne sait oם elle est passée. C'est ce que j'essaie de découvrir.";
			link.l1 = "...(se souvenant, à mi-voix)... Désormais, l'Orchidée noire est à sa véritable place...";
			link.l1.go = "24";
		break;

		case "24":
			dialog.text = "...(avec agitation)... Qu'est-ce que vous venez de dire ?!";
			link.l1 = "C'est Frederick Levinson qui me l'a dit, à la taverne. Ou plutכt, c'est Alejon Kendart qui l'a dit, et Levinson me l'a répété.";
			link.l1.go = "25";
		break;

		case "25":
			dialog.text = "...(pensivement)... Hum... " + sName + ", je dois y réfléchir. Que le diable m'emporte, ce sont des mots diablement importants, diablement importants. Hum... Une véritable place. Qu'est-ce que cela peut vouloir dire ?";
			link.l1 = "Peut-être devrions-nous chercher là oם le docker Giancarlo l'a trouvée la première fois ?";
			link.l1.go = "26";
		break;

		case "26":
			dialog.text = "Non. J'en suis sמr. Ce serait trop simple. Et Giancarlo n'a sמrement pas été le premier à trouver l'Orchidée. Très bien, " + sName + ", voici votre première mission. D'abord, conduisez-moi à Port-au-Prince : mes affaires à la Martinique sont terminées. \nEnsuite, fouillez de fond en comble la maison de Brian George : vous avez la clé de son coffre, servez-vous-en. Rendez-moi compte des résultats ; je vous attendrai à la résidence du gouverneur.";
			link.l1 = "Une dernière question. Croyez-vous vraiment que Brian George était un chercheur de l'Orchidée noire ? D'après les habitants, c'était...";
			link.l1.go = "27";
		break;

		case "27":
			dialog.text = "Un ivrogne, tout à fait. Mais ce n'était qu'une couverture, pour que personne ne le soupçonne. דa n'a pas marché, comme vous le voyez : Levinson l'a percé à jour, et moi aussi, j'ai deviné que Brian jouait un jeu. Assez, " + sName + ", il n'y a pas de temps à perdre ; nous devons gagner Port-au-Prince immédiatement.";
			link.l1 = "Alors ne perdons pas de temps.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactStefanLanvenIsPassenger");
		break;

		case "28":
			dialog.text = "Enfin ! Je commençais à croire que le commandant avait tout gâché et que vous étiez mort.";
			link.l1 = "Le commandant a exécuté votre ordre et attend l'argent que vous lui avez promis. Stefano, j'ai réussi à ouvrir le coffre de la maison de Brian George !";
			link.l1.go = "29";
		break;

		case "29":
			dialog.text = "Je vois que vous aviez hâte de me le dire ! Qu'avez-vous trouvé ?";
			link.l1 = "Une pièce étrange et un livre muni d'une serrure astucieuse.";
			link.l1.go = "30";
			link.l2 = "Cinq cent mille piastres, une pièce étrange et un livre muni d'une serrure astucieuse.";
			link.l2.go = "31";
		break;

		case "30":
			dialog.text = "...(sourit)... Et les cinq cent mille piastres ? Vous aviez décidé de ne rien en dire ? Peu importe, gardez-les, vous l'avez mérité. Alors, qu'est-ce que ce livre à l'étrange serrure ?";
			link.l1 = "Tenez, regardez ! Il faut deviner une combinaison de chiffres que seul Brian George connaissait.";
			link.l1.go = "32";
		break;

		case "31":
			dialog.text = "Gardez l'argent, vous l'avez mérité. Alors, qu'est-ce que ce livre à l'étrange serrure ?";
			link.l1 = "Tenez, regardez ! Il faut deviner une combinaison de chiffres que seul Brian George connaissait.";
			link.l1.go = "32";
		break;

		case "32":
			dialog.text = "...(il examine longuement et attentivement la serrure)... Ah, je vois. Une serrure astucieuse ; ce n'est pas la première que je rencontre. Oui, sans la bonne combinaison, impossible de la contourner.";
			link.l1 = "Vous connaissez peut-être quelqu'un qui s'y connaît en serrures ? Un Maître des Clés, par exemple.";
			link.l1.go = "33";
		break;

		case "33":
			dialog.text = "Bien sמr, mais laissez-moi vous dire ceci : n'ayez jamais, jamais recours à leurs services. Des fripouilles rusées. Vous connaissez l'histoire du Maître des Clés de Curaçao ? Un capitaine lui avait commandé une clé importante, et le scélérat a non seulement demandé un prix exorbitant, mais il a aussi fait venir des soldats chez lui quand le capitaine est venu la chercher. Le capitaine a abattu les soldats et a pris sa clé, mais il a épargné le Maître. Alors, je n'ai aucune intention de m'adresser à eux.";
			link.l1 = "Mais Brian George, le seul qui connaissait la combinaison, est mort. Nous pourrions peut-être essayer toutes les combinaisons possibles ? L'une d'elles doit bien fonctionner.";
			link.l1.go = "34";
		break;

		case "34":
			dialog.text = "Ah, et il y en a dix mille. Donc, " + sName + ", voici votre deuxième mission : découvrir cette combinaison. Brian a sמrement laissé un indice quelque part, sa mémoire était une passoire. Quand vous l'aurez, revenez me voir.";
			link.l1 = "Très bien. Je comprends.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactNeedOpenBook");
		break;

		case "35":
			dialog.text = "Magnifico ! Excellent, " + sName + ", tout simplement excellent, vous avez réussi !";
			link.l1 = "Qu'écrit Brian dans ce livre ?";
			link.l1.go = "36";
		break;

		case "36":
			dialog.text = "Tout concerne l'Orchidée noire ! Il y en a tellement ! Plus de cinquante pages. Voici ce que nous allons faire, " + sName + " : il me faut du temps pour le lire entièrement. Revenez me voir dans quatre jours.";
			link.l1 = "Compris. Dans quatre jours.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactTimerReadBook");
		break;

		case "37":
			dialog.text = "Cinquante-sept pages de paperasse inutile ! Le crétin !";
			link.l1 = "Quoi ?";
			link.l1.go = "38";
		break;

		case "38":
			dialog.text = "Ce n'est pas de vous que je parle, " + sName + ". Vous avez fait du bon travail, vous avez trouvé la bonne combinaison. C'est ce Brian George qui est un parfait crétin ! Quatre jours de perdus !";
			link.l1 = "Allez-vous enfin me dire ce qui s'est passé ?";
			link.l1.go = "39";
		break;

		case "39":
			dialog.text = "Ce qui s'est passé ? Brian George est un crétin, voilà ce qui s'est passé.";
			link.l1 = "C'est la troisième fois que je l'entends. Qu'y a-t-il d'écrit dans ce livre ?";
			link.l1.go = "40";
		break;

		case "40":
			dialog.text = "Ce qui est écrit dans ce livre, c'est que Brian George était un crétin.";
			link.l1 = "Stefano, je suis sérieux. J'en ai assez de l'entendre ; je veux savoir ce qu'il y a dans le livre. Soit vous me le donnez et je le lis moi-même, soit vous cessez de passer vos nerfs et vous me le dites.";
			link.l1.go = "41";
		break;

		case "41":
			dialog.text = "Bon, bon. Alors, " + sName + " : Brian George était un crétin. Savez-vous comment il cherchait l'Orchidée noire ? Il fouillait bêtement et méthodiquement les grottes de l'archipel des Caraïbes.";
			link.l1 = "Mais s'il faisait ça, c'est qu'il savait qu'il fallait chercher l'Orchidée sous terre.";
			link.l1.go = "42";
		break;

		case "42":
			dialog.text = "Ce crétin ne savait absolument rien. Il errait simplement d'île en île, rampait dans les grottes et cherchait. La raison pour laquelle il cherchait sous terre est écrite dès la première page ; écoutez : « Il n'y a pas d'endroits plus sמrs dans les Caraïbes que les grottes, c'est donc là précisément qu'il faut chercher l'Orchidée noire ».";
			link.l1 = "...(d'un air sombre)... Une absurdité totale. Quel crétin.";
			link.l1.go = "43";
		break;

		case "43":
			dialog.text = "Exactement, " + sName + ". Et le pire, c'est tout ce temps et tous ces efforts gaspillés : entrer dans la maison de ce crétin, prendre le livre, trouver la combinaison.";
			link.l1 = "...(avec de l'espoir dans la voix)... Mais avez-vous trouvé au moins quelque chose d'utile dedans ?";
			link.l1.go = "44";
		break;

		case "44":
			dialog.text = "Rien du tout, " + sName + ". Pas un seul mot utile. Mais il n'y a pas de raison de désespérer ; il y a aussi de bonnes nouvelles. La première et la plus importante concerne Matilda. Je la tiens de mon homme à Santiago. Il signale que dans deux jours, deux frégates quitteront Santiago. Elles mettront le cap sur la baie de la Perdition, à l'ouest de La Havane, sur le continent. C'est Matilda qui commandera l'expédition. Vous voyez oם je veux en venir ?";
			link.l1 = "Je crois que oui. Matilda part à la recherche de l'Orchidée noire ?";
			link.l1.go = "45";
		break;

		case "45":
			dialog.text = "Exactement. Même si elle ne peut guère espérer la trouver là-bas, la baie de la Perdition est liée d'une manière ou d'une autre à l'Orchidée, j'en suis certain. Donc, " + sName + ", voici votre troisième mission. Vous allez naviguer jusqu'à la baie de la Perdition et découvrir ce que Matilda y cherche. Préparez-vous bien : une rencontre avec deux frégates de la flotte espagnole ne sera pas une partie de plaisir. Des questions ?";
			link.l1 = "Que dois-je faire de Matilda si je la rencontre ?";
			link.l1.go = "46";
		break;

		case "46":
			dialog.text = "Agissez selon les circonstances, " + sName + ". Je n'ai pas d'instructions précises à ce sujet. Si vous en avez l'occasion, tirez-lui tout ce que vous pourrez. Sinon, tuez-la, tout simplement.";
			link.l1 = "Je comprends, Stefano. Je suis prêt.";
			link.l1.go = "47";
		break;

		case "47":
			dialog.text = "Attendez, j'ai encore deux nouvelles. L'un des chercheurs de l'Orchidée est mort : sir Andrew Murdoch. Une balle dans la tête, à Port Royal. On dit que la bande de Clive y est pour quelque chose.";
			link.l1 = "Bien sמr ! Clive et Jacky en parlaient le jour oם j'ai réussi à surprendre leur conversation. Jacky se vantait de son beau coup de feu et de la satisfaction de Tulipe. Ils parlaient de Murdoch !";
			link.l1.go = "48";
		break;

		case "48":
			dialog.text = "C'est possible, mais ça n'a plus guère d'importance maintenant. Murdoch est mort. Et nous ne saurons jamais ce qu'il savait de l'Orchidée. Il n'avait pas de maison à lui, alors...";
			link.l1 = "Hum... Un titre honorifique de sir, et pas de maison à lui. Tout cela est étrange. Et la troisième nouvelle ?";
			link.l1.go = "49";
		break;

		case "49":
			dialog.text = "La troisième va vous plaire. Frederick Levinson s'est brouillé avec Jackman pour une raison ou une autre, et Jackman a mis sa tête à prix pour dix mille piastres. Frederick n'a pas réussi à quitter l'île à temps : son Concombre de mer a été mis en pièces depuis la cכte par des canons de quarante-deux livres. Maintenant, toute la population des Bermudes traque le pauvre bougre.";
			link.l1 = "On n'envie pas le vieux Levinson. Mais Frederick est un vieux renard, il s'en sort toujours. Je me souviens, quand les Espagnols nous avaient cloués sur place à Porto Rico, Frederick...";
			link.l1.go = "50";
		break;

		case "50":
			dialog.text = "Ce n'est pas le moment des histoires, " + sName + ", faites route vers la baie de la Perdition. Et préparez votre rafiot au combat. Deux Espagnols de la flotte, ce n'est pas une plaisanterie.";
			link.l1 = "Nous avons déjà navigué, nous connaissons le métier.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("MysteriousArtefactToDeadShore");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
