// BOAL новый диалог офицера и компаньона 21/06/06
void ProcessDialogEvent()
{
	ref NPChar, d;
	aref Link, Diag, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makeref(d, Dialog);
	makearef(Diag, NPChar.Dialog);
	makearef(NextDiag, NPChar.Dialog);

	ref    sld;
	string attr, attrLoc;
	int    iTemp, iTax, iFortValue;

	bool bGoldMine = false;
	bool bSilverMine = false;
	bool bIronMine = false;

	if(CheckAttribute(PChar, "ColonyBuilding.GoldMine.BuildingTime"))
	{
		bGoldMine = PChar.ColonyBuilding.GoldMine == true && PChar.ColonyBuilding.GoldMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.SilverMine.BuildingTime"))
	{
		bSilverMine = PChar.ColonyBuilding.SilverMine == true && PChar.ColonyBuilding.SilverMine.BuildingTime == false;
	}
	if(CheckAttribute(PChar, "ColonyBuilding.IronMine.BuildingTime"))
	{
		bIronMine = PChar.ColonyBuilding.IronMine == true && PChar.ColonyBuilding.IronMine.BuildingTime == false;
	}

	switch(Dialog.CurrentNode)
	{
        case "First time":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = RandPhraseSimple("Hé, capitaine, la moitié de la garnison vous court après ici. Ce n'est clairement pas le moment de rejoindre votre équipage !", "Vous proposez de forcer le chemin jusqu'au navire en se battant ? Non, une autre fois, cap'taine...");
				link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Je n'avais pas"+ GetSexPhrase(" l'intention", " l'intention") +" de vous engager.");
				link.l1.go = "exit";
				break;
			}
			Diag.TempNode = "OnceAgain";
			dialog.text = "Vous avez besoin d'un officier, capitaine ?";
			if (FindFreeRandomOfficer() > 0)
			{
    			Link.l1 = "Un officier ? א quoi êtes-vous bon ?";
    			Link.l1.go = "Node_2";
			}
			Link.l2 = "Non, j'ai mon effectif complet.";
			Link.l2.go = "Exit";
			if (pchar.sex == "Skeleton")
			{
				dialog.text = LinkRandPhrase("Hic... Oh, quoi ?", "Je me repose, ne me dérangez pas !", RandSwear()+ "J'ai une mouche dans ma chope !");
				Link.l1 = "...";
    			Link.l1.go = "exit";
				DeleteAttribute(link, "l2");
				NextDiag.TempNode = "First time";
			}
		break;

		case "CitizenNotBlade":
			dialog.text = "Capitaine, quelle sottise ! Rangez vos armes avant de provoquer des ennuis !";
			link.l1 = LinkRandPhrase("Bien.", "D'accord.", "Ne vous inquiétez pas, je les range déjà...");
			link.l1.go = "exit";
		break;

		// LEO: капитан казённого судна из эскортируемого конвоя - подчиняется своему начальству, командного
		//   списка нет (см. подробнее в русской версии файла).
		case "ConvoyCap_Escort":
			Diag.TempNode = "ConvoyCap_Escort"; // закрепляем ноду: exit делает CurrentNode = TempNode
			dialog.text = "Nous naviguons dans votre sillage, capitaine. Mes ordres viennent de mes supérieurs, mon affaire est de livrer la cargaison.";
			link.l1 = LinkRandPhrase("Bien. Gardez l'allure.", "Bien, restez près de nous.", "Compris. Poursuivons.");
			link.l1.go = "exit";
		break;

		case "hired":
			Diag.TempNode = "Hired";
			// только наняли -->
			bool companiontravel = false;
			if (IsCompanionTravel(NPChar)) companiontravel = true;

			// LEO: компаньон В ПУТИ по нашему поручению - никаких команд/торговли/возврата на месте,
			//   только сообщение "на задании" (иначе латать кучу дыр). Покрывает и палубу (реальный NPChar),
			//   и кают-компанию (клон -> реальный через realcompanionidx). Блокируем ТОЛЬКО пока в рейсе
			//   (OutboundLive/Meeting); когда ждёт в порту - команды/возврат снова доступны.
			int iCTreal = GetCharacterIndex(NPChar.id);
			if (CheckAttribute(NPChar, "realcompanionidx")) iCTreal = sti(NPChar.realcompanionidx);
			bool bCTonRoute = false;
			if (iCTreal >= 0)
			{
				if (CheckAttribute(&characters[iCTreal], "CompanionTravel.OutboundLive")) bCTonRoute = true;
				if (CheckAttribute(&characters[iCTreal], "CompanionTravel.Meeting")) bCTonRoute = true;
				if (CheckAttribute(&characters[iCTreal], "CompanionTravel.OutfitTravel")) bCTonRoute = true;
			}
			if (bCTonRoute)
			{
				dialog.text = "Je suis en mission pour vous, capitaine, et je ne peux pas quitter mon cap. Dès que j'aurai terminé la tâche et rejoint l'escadre, je serai de nouveau prêt à recevoir des ordres.";
				if (iCTreal >= 0 && CheckAttribute(&characters[iCTreal], "CompanionTravel.OutfitTravel"))
					dialog.text = "Je pars équiper un navire, capitaine : j'en choisirai un au chantier naval, je recruterai un équipage, je ferai des provisions et je vous rattraperai. Dès que j'aurai fini, je serai à votre service.";
				Link.l1 = "Bien. Bon vent.";
				Link.l1.go = "exit";
				break;
			}

			if (IsCompanion(NPChar) && !companiontravel)
			{
				Dialog.text = "Aujourd'hui, nous reprenons la mer !";
				link.l2 = "Ouais... Moi aussi, ça me fait plaisir.";
				link.l2.go = "Exit";
				break;
			}
			if (Npchar.location.group == "sit" && !isShipInside(pchar.location))
			{
				dialog.text = "Je finis mon verre, capitaine, et je monte à bord. Ne vous inquiétez pas, je serai là avant le départ.";
				Link.l1 = "Très bien. Si tu es en retard, je te ferai briquer le pont !";
				Link.l1.go = "Exit";
				break;
			}
			// только наняли <--
   			dialog.text = "Que voulez-vous, capitaine ?";
			if (NPChar.id == "James_Callow")
			{
				dialog.text = "Vous voulez botter quelques derrières ? Je suis à votre disposition !";
			}
			if (NPChar.id == "Tichingitu")
			{
				dialog.text = "Tichingitu vous écoute, capitaine "+pchar.name+" !";
			}
			if (NPChar.id == "Andreas_Fickler")
			{
				dialog.text = "Qu'est-ce que v-vous voulez, "+pchar.name+" ?";
			}
			if (NPChar.sex == "skeleton" && PChar.sex == "skeleton")
			{
				dialog.text = "Que voulez-vous, monseigneur ?";
			}
			// диалог компаньона на корабле.
			if (CheckAttribute(NPChar, "IsCompanionClone"))
			{
				Link.l2 = "J'ai quelques ordres pour vous.";
				Link.l2.go = "Companion_Tasks";
				break;
			}

			if (isOfficer(Npchar)) // проверка для кампуса, где слотовые офы
			{
	            Link.l2 = "וcoute mon ordre !";
	            Link.l2.go = "stay_follow";
	            // LEO: снарядить безлошадного офицера кораблём - ТОЛЬКО на суше (не в море/каюте - вплавь не пойдёт),
	            //   где на текущем регионе/острове есть верфь. Снарядится тут и догонит эскадру компаньоном-капитаном.
	            if (!bSeaActive && !isShipInside(pchar.location))
	            {
	                if (!CheckAttribute(NPChar, "Ship.Type") || sti(NPChar.Ship.Type) == SHIP_NOTUSED)
	                {
	                    if (CompanionTravel_HasFreeSlot() && CompanionTravel_CanOutfitHere())
	                    {
	                        Link.loutfit = "וquipez-vous d'un navire de classe et rattrapez-nous en mer.";
	                        Link.loutfit.go = "OfficerOutfit_Start";
	                    }
	                }
	            }
            }

			//aw013 --> Найм на постоянку
			bool bOk = !CheckAttribute(PChar, "questTemp.MunityOfficerID") || PChar.questTemp.MunityOfficerID != NPChar.id;
			if (!bHalfImmortalPGG)
			{
				if (!CheckAttribute(NPChar, "OfficerWantToGo.DontGo"))
				{					
					if (bOk)
					{
						Link.l3contract = "J'ai une proposition à vous faire.";
						Link.l3contract.go = "contract";
					}
				}
			}
			else
			{
				if (!CheckAttribute(pchar,"Option_ImmortalOfficers"))
				{
					pchar.Option_ImmortalOfficers = "0";
				}
				if (sti(pchar.Option_ImmortalOfficers) < makeint(GetCharacterSPECIAL(pchar,"Charisma")*2) && !CheckAttribute(npchar,"ImmortalOfficer"))
				{
					if (bOk)
					{
						Link.l3contract = "J'ai une proposition à vous faire.";
						Link.l3contract.go = "contract";
					}
				}
			}
			//aw013 <-- Найм на постоянку
			
			if (companiontravel)
			{
				// LEO: ВСТРЕЧА в порту - живой расчёт по торговому рейсу + долг за аренду склада (оба вживую, без телепорта).
				CompanionTravel_SettleTrade(NPChar);
				CompanionTravel_TryPayStorageDebt(true);
				// LEO: подсказка ждущего на рейде - остаток УГОВОРЁННОГО срока (месяц), с учётом припасов (min).
				//   Считает ВНИЗ по мере ожидания (реальный лимит стоянки = CompanionTravel_WaitDaysLeft).
				if (iCTreal >= 0)
				{
					int iWaitDays = CompanionTravel_WaitDaysLeft(&characters[iCTreal]);
					dialog.text = "Je vous attends, capitaine. Comme convenu, je peux encore rester en rade " + FindRussianDaysString(iWaitDays) + ", pas davantage.";
				}
				Link.l99 = "Retournez à l'escadre, officier.";
				Link.l99.go = "CompanionTravel_ToSquadron";
				Link.l5 = "Je dois vérifier votre cargaison.";
				Link.l5.go = "CompanionTravel_Transfer";
			}
			
			//Расторжение контракта
			
			if (CheckAttribute(npchar, "ImmortalOfficer"))
			{
				Link.l6 = "Je veux résilier le contrat qui nous lie.";
				Link.l6.go = "cancelcontract1";
			}
			
           		// boal отчёт о корабле
			if(CheckAttribute(NPChar, "treasurer") && NPChar.treasurer == 1)
			{
			    Link.l8 = "Faites-moi un rapport complet sur le navire, " + GetStrSmallRegister(XI_ConvertString("treasurer")) + ".";
			    Link.l8.go = "QMASTER_1";
				if (NPChar.id == "Andreas_Fickler")
				{
					Link.l8 = "Faites-moi un rapport complet sur le navire, Andreas.";
					Link.l8.go = "QMASTER_1";
				}
				
			    Link.l11 = "Voyons combien de marchandises et d'objets il faut acheter dans les magasins.";
			    Link.l11.go = "TransferGoodsEnable";
				// LEO: приказ обходить город при сходе на берег - по умолчанию казначей этого НЕ делает.
				//   Флаг живёт на самом офицере, гейт рейда - Treasurer_PortRun (StoreUtilite.c).
				// ⚠️ Отдельными if - у Storm && не ленивый, и sti() от отсутствующего атрибута даст ошибку.
				bool bTreasurerRuns = false;
				if (CheckAttribute(NPChar, "TreasurerPortRun"))
				{
					if (sti(NPChar.TreasurerPortRun) == 1) bTreasurerRuns = true;
				}
				if (bTreasurerRuns)
				{
					Link.l13 = "Désormais, restez à bord : je passerai moi-même au magasin et chez les colporteurs.";
					Link.l13.go = "TreasurerPortRunOff";
				}
				else
				{
					Link.l13 = "Quand nous descendrons à terre, je veux que vous fassiez vous-même le tour de la ville : passez au magasin, examinez les marchandises des colporteurs et achetez ce dont nous avons besoin.";
					Link.l13.go = "TreasurerPortRunOn";
				}
			}

			if (npchar.id != "Sharp_Sibling" && npchar.id != "SharleMary")
			{
				Link.l4 = "Officier, je n'ai plus besoin de vos services.";
				Link.l4.go = "AsYouWish";
				if (NPChar.sex == "skeleton" && PChar.sex == "skeleton")
				{
					Link.l4 = "Tu m'as déçu, mon frère ! Disparais de ma vue !";
					Link.l4.go = "exit_fire_1";
				}
			}

			// приколы -->
			if (PChar.sex == "woman" && !CheckAttribute(pchar, "questTemp.MainHeroWoman"))
			{//Запускаем счётчик для отката
				pchar.questTemp.MainHeroWoman = true;
				SaveCurrentQuestDateParam("pchar.questTemp.MainHeroWomanSex");
			}

            if (PChar.location == Get_My_Cabin() && npchar.id != "Sharp_Sibling" && GetQuestPastDayParam("pchar.questTemp.MainHeroWomanSex") >= 5)
            {
    			if (PChar.sex == "woman" && NPChar.sex == "man")
    			{
					Link.l3 = RandPhraseSimple("Puisque nous sommes dans la cabine, et si nous... Regarde, il y a un lit ici aussi... si moelleux...",
	                                           "Regarde le grand lit de ma cabine. Tu ne voudrais pas le partager avec moi ?");
	                if (drand(70) < sti(GetSummonSkillFromName(pchar, SKILL_LEADERSHIP)) || CheckAttribute(npchar, "devoted"))
	                {
	                    Link.l3.go = "Love_Sex_Yes";
	                }
	                else
	                {
	                    Link.l3.go = "Love_Sex";
	                }
                }
            }

			if (PChar.location == Get_My_Cabin() && npchar.id != "Sharp_Sibling")
            {
    			if (PChar.sex != "woman" && NPChar.sex == "woman")
    			{
					Link.l3 = RandPhraseSimple("Puisque nous sommes dans la cabine, et si nous... Regarde, il y a un lit ici aussi... si moelleux...",
	                                           "Regarde le grand lit de ma cabine. Tu ne voudrais pas le partager avec moi ?");
	                if (sti(pchar.GenQuest.BrothelCount) > 4+rand(3))
	                {
	                    Link.l3.go = "Man_Love_Sex_Yes";
	                }
	                else
	                {
	                    Link.l3.go = "Man_Love_Sex";
	                }
                }
                if (!CheckAttribute(pchar, "questTemp.FUNY_SHIP_FIND") && NPChar.sex == "woman" && GetCharacterItem(PChar, "mineral4") >= 25)
                {
                    Link.l4 = "Regarde la collection intéressante que j'ai réunie !";
            		Link.l4.go = "FUNY_SHIP_1";
                }
            }		

            // по тёк локации определим можно ли тут приказать  -->
            if (IsEntity(loadedLocation))
            {
                if (CheckAttribute(loadedLocation, "fastreload"))
                {
                    iTemp = FindColony(loadedLocation.fastreload);
                    if (iTemp != -1)
                    {
                        sld = GetColonyByIndex(iTemp);
                        if (sti(sld.HeroOwn) == true && !CheckAttribute(sld, "OfficerIdx"))
                        {
							if(Locations[FindLocation(PChar.location)].islandId != "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
							{
								NPChar.ColonyIdx = iTemp;
								Link.l7 = "Je vous nomme gouverneur de cette ville !";
								Link.l7.go = "Gover_Hire";
							}
                        }
                    }
                }
            }
            if(PChar.ColonyBuilding.Stage != "0" && PChar.ColonyBuilding.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l8 = "Je veux vous nommer gouverneur de la colonie '" + PChar.ColonyBuilding.ColonyName + "', que nous avons bâtie sur l'île des Caïmans.";
						Link.l8.go = "ColonyBuilding_Hovernor_1";
					}
				}
			}

			if(PChar.ColonyBuilding.Stage == "3" && PChar.Colony.Guardians.Hovernor == "")
			{
				if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
				{
					if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
					{
						Link.l9 = "Je veux vous nommer à la tête de la base de sécurité que nous avons bâtie pour renforcer la défense de notre colonie '" + PChar.ColonyBuilding.ColonyName + "'.";
						Link.l9.go = "ColonyGuarding_Hovernor_1";
					}
				}
			}

			if(bGoldMine || bSilverMine || bIronMine)
			{
				if(PChar.Mines.Commander == "")
				{
					if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
					{
						if(Locations[FindLocation(PChar.location)].islandId == "Caiman" && !CheckAttribute(NPChar, "HPminusDaysNeedtoRestore"))
						{
							Link.l10 = "Je veux vous nommer gérant des mines qui se trouvent sur cette île.";
							Link.l10.go = "MinesCommander_Hire";
						}
					}
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.Plantation.Commander == "")
				{
					if(CheckAttribute(&Locations[FindLocation(PChar.location)], "islandId"))
					{
						if(Locations[FindLocation(PChar.location)].islandId == "Caiman")
						{
							Link.l11 = "Je veux vous nommer gérant de la plantation qui se trouve près de la colonie '" + PChar.ColonyBuilding.ColonyName + "' et qui lui appartient.";
							Link.l11.go = "PlantationCommander_Hire";
						}
					}
				}
			}
			/*
			if(npchar.id == "Mechanic1")
			{
				if (CheckCharacterItem(pchar, "pistolcolt") || CheckCharacterItem(pchar, "pistol7shotgun"))
				{
					Link.lcraftMechanic = "Mechanic, I have a question for you, just about your specialty.";
					Link.lcraftMechanic.go = "mechanic_craft_ammo";
				}
				if (CheckAttribute(pchar, "craftingAmmo"))
				{
					Link.lcraftMechanic = "How are you doing? Did you manage to make something?";
					Link.lcraftMechanic.go = "mechanic_craft_ammo_finish";
				}
			}*/
			if (CheckAttribute(pchar, "WhisperPGG") && npchar.id == pchar.WhisperPGG)
			{
				if (CheckAttribute(pchar, "CabinHelp"))
				{
					if(Pchar.CabinHelp == true)
					{
						Link.WhisperCabinHelp = "Je ne veux plus que vous m'accompagniez dans les cabines.";
						Link.WhisperCabinHelp.go = "WhisperCabinHelp";
					}
					else
					{
						Link.WhisperCabinHelp = "Je veux que vous m'aidiez dans les cabines.";
						Link.WhisperCabinHelp.go = "WhisperCabinHelp";
					}
				}
				if(GetCharacterItem(npchar, "pistol7shotgun") >= 1)
				{
					Link.WhisperWeapons = "Vous avez une arme peu ordinaire. Puis-je la voir ?";
					Link.WhisperWeapons.go = "WhisperWeapons";
				}

			}
			if(npchar.id == "W_chinaman" && CheckAttribute(pchar, "Whisper.GiveChinaSword") && CheckCharacterItem(pchar, "blade_china"))
			{
				Link.wChinaSword = "Regardez ce que j'ai pour vous. דa n'a pas été facile, mais j'ai quand même récupéré votre épée.";
				Link.wChinaSword.go = "w_give_china_sword";
			}
            Link.l12 = "Rien. Repos.";
            Link.l12.go = "Exit";
			if (NPChar.id == "Andreas_Fickler")
			{
				Link.l12 = "Calme-toi, Andreas. Continue à compter l'argent.";
				Link.l12.go = "Exit";
			}
        break;

		case "FUNY_SHIP_1":
		    dialog.text = "Oh, quelle horreur ! Capitaine, éloignez ça de moi, quelle puanteur insupportable... Vous croyez à toutes ces sornettes de la vieille légende sur l'obtention d'un combattant invincible ?";
   			Link.l1 = "Non, bien sמr, pardon. Je vais jeter toute cette masse puante par-dessus bord.";
            Link.l1.go = "exit";
            Link.l2 = "Oui, j'y crois ! Et je vais même vérifier. Allez, approchez-vous !";
            Link.l2.go = "FUNY_SHIP_2";
        break;

        case "FUNY_SHIP_2":
		    dialog.text = "Quelle puanteur ! Pouah... Mais ça marche, je me sens plus forte et même, euh, plus belle.";
   			Link.l1 = "Voilà ! Et vous aviez peur, votre jupe n'est même pas froissée. Lavez-vous les mains, maintenant.";
            Link.l1.go = "FUNY_SHIP_3";
        break;

        case "FUNY_SHIP_3":
            PChar.questTemp.FUNY_SHIP_FIND = false;
            DialogExit();
			NextDiag.CurrentNode = "Hired";

			TakeNItems(pchar, "mineral4", -25);
			AddSPECIALValue(Npchar, SPECIAL_S, 1);
			AddSPECIALValue(Npchar, SPECIAL_P, 1);
			AddSPECIALValue(Npchar, SPECIAL_E, 1);
			AddSPECIALValue(Npchar, SPECIAL_C, 1);
			AddSPECIALValue(Npchar, SPECIAL_I, 1);
			AddSPECIALValue(Npchar, SPECIAL_A, 1);
			AddSPECIALValue(Npchar, SPECIAL_L, 1);
        break;

		case "WhisperCabinHelp":
			dialog.text = "D'accord.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
			pchar.CabinHelp = !sti(pchar.CabinHelp);
		break;

		case "WhisperWeapons":
			dialog.text = "Vous pouvez prendre mon épée si vous voulez. Mais je ne confierai mon fusil à personne : j'ai eu trop de mal à le récupérer, vous savez. Et je ne pense pas que quelqu'un d'autre que moi saura s'en servir.";
            Link.l2 = "Je vois.";
            Link.l2.go = "exit";
			Link.l1 = "Je vois. Vous utilisez des munitions spéciales ?";
            Link.l1.go = "WhisperWeapons_1";
		break;
		case "WhisperWeapons_1":
			dialog.text = "Ouais. On ne peut guère en acheter dans les Caraïbes, alors je les fabrique moi-même. Je n'en fais pas beaucoup, mais je pense m'améliorer avec le temps et pouvoir en faire davantage.";
            Link.l2 = "Je vois.";
            Link.l2.go = "exit";
		break;

		case "w_give_china_sword":
			dialog.text = "Je n'en crois pas mes yeux... C'est vraiment elle, l'épée de ma famille. Je n'ai rien à vous offrir en retour, si ce n'est ma dévotion éternelle. Si vous me confiez votre protection, je protégerai votre vie avant la mienne.";
			TakeItemFromCharacter(pchar, "blade_china");
			if (pchar.equip.blade == "blade_china")
			{
				RemoveCharacterEquip(pchar, BLADE_ITEM_TYPE);
			}
			LAi_SetHP(npchar, 100.0 + LAi_GetCharacterMaxHP(npchar), 100.0 + LAi_GetCharacterMaxHP(npchar));
			AddBonusEnergyToCharacter(npchar, 50);
			GiveItem2Character(npchar, "blade_china");
			EquipCharacterByItem(npchar, "blade_china");
			npchar.Skill.Sailing    = sti(npchar.Skill.Sailing) + 20;
			if (sti(npchar.Skill.Sailing) > 100) npchar.Skill.Sailing = 100;
			npchar.Skill.FencingHeavy  = sti(npchar.Skill.FencingHeavy) + 20;
			if (sti(npchar.Skill.FencingHeavy) > 100) npchar.Skill.FencingHeavy = 100;
			npchar.perks.FreePoints_self = sti(npchar.perks.FreePoints_self) + 1;
			npchar.perks.FreePoints_ship = sti(npchar.perks.FreePoints_ship) + 2;
			npchar.rank = sti(npchar.rank) + 5;
			npchar.perks.list.AgileMan = "1";
			ApplayNewSkill(npchar, "AgileMan", 0);
			npchar.devoted = true;
			DeleteAttribute(pchar, "Whisper.GiveChinaSword")
            link.l1 = "La loyauté me suffit. Bon, je vous laisse seul avec votre « jouet ».";
			link.l1.go = "exit";
		break;

		case "mechanic_craft_ammo_finish":
		    dialog.text = "Ne me pressez pas, capitaine. Je vous ai dit quand j'aurais fini.";
            link.l1 = "D'accord, pardon. J'ai juste hâte de tirer.";
			link.l1.go = "exit";
			if (GetQuestPastDayParam("pchar.questTemp.craftingAmmo") >= sti(pchar.ammoCraftDays))
			{
				dialog.text = "Et comment ! Prenez-les, je vous prie. J'en ai fait 50. Attention, ne les utilisez pas toutes d'un coup.";
				link.l1 = "Merci. Vous êtes un génie !";
				link.l1.go = "exit";
				DeleteAttribute(pchar, "craftingAmmo");
				switch(pchar.ammoCrafttype)
				{
					case "shotgun":
						TakeNItems(Pchar, "12_gauge", 50);
					break;
					case "colt":
						TakeNItems(Pchar, "GunCap_colt", 50);
						TakeNItems(Pchar, "shotgun_cartridge", 50);
					break;
					case "both":
						TakeNItems(Pchar, "12_gauge", 50);
						TakeNItems(Pchar, "GunCap_colt", 50);
						TakeNItems(Pchar, "shotgun_cartridge", 50);
					break;
				}
			}
        break;
		case "mechanic_craft_ammo":
			if (!CheckAttribute(npchar, "ammoCraftedOnce"))
			{
				dialog.text = "Vraiment ? Vous m'intriguez, capitaine.";
				link.l1 = "Le fait est que je possède un certain dispositif : une arme. Elle fonctionne correctement, mais il faut des munitions spéciales pour l'utiliser. Vous serait-il difficile d'en fabriquer ?";
				link.l1.go = "mechanic_craft_ammo_1";
			}
			else
			{
				dialog.text = "Vous voulez que je vous fabrique encore des munitions ?";
				link.l1 = "Vous lisez dans mes pensées.";
				link.l1.go = "mechanic_craft_ammo_1";
			}
        break;
		case "mechanic_craft_ammo_1":
			if (!CheckAttribute(npchar, "ammoCraftedOnce"))
			{
				dialog.text = "Hum... Puis-je voir votre dispositif ?";
			}
			else
			{
				dialog.text = "Rappelez-moi, je vous prie, quel genre de dispositif vous avez là ?";
			}
			link.l1 = "Vous savez, laissez tomber.";
			link.l1.go = "exit";
			if (!CheckCharacterItem(pchar, "pistolcolt") && CheckCharacterItem(pchar, "pistol7shotgun"))
			{
				pchar.ammoCrafttype = "shotgun";
				link.l2 = "(Montrer le fusil)";
				link.l2.go = "mechanic_craft_ammo_3";
			}
			if (CheckCharacterItem(pchar, "pistolcolt") && !CheckCharacterItem(pchar, "pistol7shotgun"))
			{
				pchar.ammoCrafttype = "colt";
				link.l2 = "(Montrer le revolver)";
				link.l2.go = "mechanic_craft_ammo_3";
			}
			if (CheckCharacterItem(pchar, "pistolcolt") && CheckCharacterItem(pchar, "pistol7shotgun"))
			{
				pchar.ammoCrafttype = "both";
				link.l2 = "(Lui montrer le fusil et le revolver)";
				link.l2.go = "mechanic_craft_ammo_3";
			}
        break;
		case "mechanic_craft_ammo_3":
			pchar.ammoCrafPrice = 50000;
			pchar.ammoCraftDays = 14;
			string sDays = " jours.";
			if (pchar.ammoCrafttype == "both")
			{
				pchar.ammoCraftPrice = 100000;
				pchar.ammoCraftDays = 21;
				sDays = " jour.";
			}
			string sTemp = "Je prendrai " + pchar.ammoCraftPrice + " piastres pour le travail. Tout sera prêt dans environ " + pchar.ammoCraftDays + sDays;
		    if (!CheckAttribute(npchar, "ammoCraftedOnce"))
			{
				dialog.text = "Un mécanisme curieux. Bon, laissez-moi regarder de plus près\nVous avez là un dispositif très intéressant, capitaine ! Oui, je pense pouvoir fabriquer des munitions qui conviendraient. Mais, vous savez, ça prendra du temps et de l'argent pour le matériel, et mon travail aussi a un prix. " + sTemp;
			}
			else
			{
				dialog.text = "Ah oui, je m'en souviens maintenant. " + sTemp;
			}
			if (sti(pchar.money)>=sti(pchar.ammoCraftPrice))
			{
				link.l1 = "Dans ce cas, au travail. Voici l'argent.";
				link.l1.go = "mechanic_craft_ammo_4";
			}
			link.l2 = "Je n'ai pas l'argent pour de telles dépenses en ce moment. Nous en reparlerons une autre fois.";
			link.l2.go = "exit";
			npchar.ammoCraftedOnce = true;
        break;
		case "mechanic_craft_ammo_4":
			AddMoneyToCharacter(pchar, -sti(pchar.ammoCraftPrice));
			pchar.craftingAmmo = true;
			SaveCurrentQuestDateParam("pchar.questTemp.craftingAmmo");
			dialog.text = "א vos ordres, capitaine !";
			link.l1 = "J'attendrai vos résultats avec impatience.";
			link.l1.go = "exit";
        break;

		case "Love_Sex_Yes":
		    dialog.text = RandPhraseSimple("Ce serait peut-être un péché de refuser une telle beauté.",
                                           "Pour vous, capitaine, je ferais n'importe quoi.");
            link.l1 = RandPhraseSimple("Oh, oui !", "Futée, la fille ! Si tu t'appliques, tu auras peut-être une prime ce mois-ci.");
			link.l1.go = "Love_Sex_Yes_2";
        break;

        case "Love_Sex_Yes_2":
            AddCharacterExpToSkill(pchar, "Leadership", 100);
            AddCharacterExpToSkill(pchar, "Fencing", -50);// утрахала
            AddCharacterExpToSkill(pchar, "Pistol", -50);
            AddCharacterHealth(pchar, 10);
			SaveCurrentQuestDateParam("pchar.questTemp.MainHeroWomanSex");
   			AddDialogExitQuest("PlaySex_1");
			NextDiag.CurrentNode = "After_sex";
			DialogExit();
        break;

        case "After_sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Vous êtes à la hauteur, comme toujours, capitaine.",
                                           "Capitaine, j'espère que tout vous a plu, j'ai fait de mon mieux.");
            link.l1 = RandPhraseSimple("Oui, nous avons passé un excellent moment.", "Ouais. Maintenant, revenons à nos affaires.");
			link.l1.go = "exit";
        break;

        case "Love_Sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Quoi !!!?? Capitaine, ça fait longtemps que vous n'êtes pas descendu à terre ou allé au bordel ?", "Je ne comprends pas de quoi vous parlez.");
            link.l1 = RandPhraseSimple("Eh bien, réfléchis... Tu es si beau, et sous mes ordres, en plus.", "Eh bien, je ne peux pas aller au bordel quand tu es à mes cכtés !");
			link.l1.go = "Love_Sex_2";
			link.l2 = RandPhraseSimple("Pardon, beau gosse, c'était très difficile de ne pas proposer..", "Eh.. Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Love_Sex_2":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Capitaine ! Maîtrisez-vous ! Ou appelez vos matelots pour ça !", "Le fait que je sois officier et que je vous obéisse en principe, capitaine, ne veut rien dire !");
            link.l1 = RandPhraseSimple("Mon chou, ne résiste pas. Je ne peux plus me retenir. Allons-y...", "Je suis ton capitaine ! Et je te l'ordonne !");
			link.l1.go = "Love_Sex_3";
			link.l2 = RandPhraseSimple("Pardon, mon petit, c'était très difficile de ne pas proposer..", "Eh... Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Love_Sex_3":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("דa suffit ! Vous allez le payer ! Et tout de suite !", "Rouler sur le lit avec vous ? Eh bien, voyons maintenant qui est capable de quoi..");
            link.l1 = "Euh... de quoi tu parles ?";
			link.l1.go = "Love_Sex_4";
        break;

        case "Love_Sex_4":
            ChangeCharacterReputation(pchar, -15);
            CheckForReleaseOfficer(GetCharacterIndex(Npchar.id));
			RemovePassenger(Pchar, Npchar);
			PGG_ReleaseOfficerFlags(Npchar); // LEO: ПГГ уходит дракой - вернуть его в мир, иначе застрянет с офицерским диалогом
            LAi_SetWarriorType(Npchar);
            LAi_group_MoveCharacter(Npchar, "TmpEnemy");
            LAi_group_SetHearRadius("TmpEnemy", 100.0);
            LAi_group_FightGroupsEx("TmpEnemy", LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
			DeleteAttribute(Npchar, "HalfImmortal");
			if (!CheckAttribute(Npchar, "PGGAi")) Npchar.LifeDay = 0; // LEO: ПГГ живёт в постоянном слоте, стирать его нельзя - гейт как в LeaveBattle.c и food.c
			if (PChar.location == Get_My_Cabin() || findsubstr(PChar.location, "_tavern" , 0) != -1)
            {
				LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
                LAi_group_SetCheck("TmpEnemy", "CannotFightCurLocation");
				LAi_group_SetCheck("TmpEnemy", "MainHeroFightModeOff");
            }
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;

		//Мужской ГГ
		case "Man_Love_Sex_Yes":
		    dialog.text = RandPhraseSimple("Je pourrais peut-être céder à un tel bourreau des cœurs.",
                                           "Eh bien, c'est mieux que de dépenser son argent avec des filles des rues.");
            link.l1 = RandPhraseSimple("Oh, oui !", "Futée, la fille ! Je ne peux pas aller au bordel quand j'ai une mignonne comme toi à mes cכtés !");
			link.l1.go = "Man_Love_Sex_Yes_2";
        break;

        case "Man_Love_Sex_Yes_2":
            pchar.GenQuest.BrothelCount = 0;
            AddCharacterExpToSkill(pchar, "Leadership", 100);
            AddCharacterExpToSkill(pchar, "Fencing", -50);// утрахала
            AddCharacterExpToSkill(pchar, "Pistol", -50);
            AddCharacterHealth(pchar, 10);

   			AddDialogExitQuest("PlaySex_1");
			NextDiag.CurrentNode = "Man_After_sex";
			DialogExit();
        break;

        case "Man_After_sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Hum... étrange, je vous croyais capable de mieux...",
                                           "Capitaine, vous pouvez de nouveau réfléchir avec votre tête, et non avec... ? Revenons à nos affaires.");
            link.l1 = RandPhraseSimple("Comment parles-tu à ton supérieur !", "Je suis capable de beaucoup si je rassemble mes esprits.");
			link.l1.go = "exit";
        break;

        case "Man_Love_Sex":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Quoi !!!?? Capitaine, ça fait longtemps que vous n'êtes pas descendu à terre ou allé au bordel ?", "Je ne sais pas de quoi vous parlez.");
            link.l1 = RandPhraseSimple("Eh bien, réfléchis toi-même... Tu es une telle beauté, et sous mes ordres, en plus.", "Eh bien, je ne peux pas aller au bordel quand tu es à mes cכtés !");
			link.l1.go = "Man_Love_Sex_2";
			link.l2 = RandPhraseSimple("Pardon, ma belle, c'était très difficile de ne pas proposer...", "Eh... Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Man_Love_Sex_2":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("Capitaine ! Maîtrisez-vous ! Ou appelez vos matelots pour ça !", "Le fait que je sois officier et que je vous obéisse en principe, capitaine, ne veut rien dire !");
            link.l1 = RandPhraseSimple("Mon chou, ne résiste pas. Je ne peux plus me retenir. Allons-y...", "Je suis ton capitaine ! Et je te l'ordonne !");
			link.l1.go = "Man_Love_Sex_3";
			link.l2 = RandPhraseSimple("Pardon, ma belle, c'était très difficile de ne pas proposer..", "Eh... Bon, laisse tomber...");
			link.l2.go = "exit";
        break;

        case "Man_Love_Sex_3":
            NextDiag.TempNode = "Hired";
		    dialog.text = RandPhraseSimple("דa suffit ! Vous allez le payer ! Et tout de suite !", "Rouler sur le lit avec vous ? Eh bien, voyons maintenant qui est capable de quoi..");
            link.l1 = "Euh... de quoi tu parles ?";
			link.l1.go = "Man_Love_Sex_4";
        break;

        case "Man_Love_Sex_4":
            ChangeCharacterReputation(pchar, -15);
            CheckForReleaseOfficer(GetCharacterIndex(Npchar.id));
			RemovePassenger(Pchar, Npchar);
			PGG_ReleaseOfficerFlags(Npchar); // LEO: ПГГ уходит дракой - вернуть его в мир, иначе застрянет с офицерским диалогом
            LAi_SetWarriorType(Npchar);
            LAi_group_MoveCharacter(Npchar, "TmpEnemy");
            LAi_group_SetHearRadius("TmpEnemy", 100.0);
            LAi_group_FightGroupsEx("TmpEnemy", LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
			DeleteAttribute(Npchar, "HalfImmortal");
			if (!CheckAttribute(Npchar, "PGGAi")) Npchar.LifeDay = 0; // LEO: ПГГ живёт в постоянном слоте, стирать его нельзя - гейт как в LeaveBattle.c и food.c
			if (PChar.location == Get_My_Cabin() || findsubstr(PChar.location, "_tavern" , 0) != -1)
            {
				LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
                LAi_group_SetCheck("TmpEnemy", "CannotFightCurLocation");
				LAi_group_SetCheck("TmpEnemy", "MainHeroFightModeOff");
            }
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
        break;
        // приколы <--

		case "TransferGoodsEnable":
			Diag.CurrentNode = "Hired";
			DialogExit();
			LaunchTransferGoodsScreen(); // Интерфейс автозакупки товаров
		break;

		// LEO: приказ казначею обходить город - лавка и лоточники, закупки по спискам, отчёт.
		//   Снятие прейскуранта приказа НЕ требует и идёт всегда - за ним казначей никуда не ходит.
		//   Флаг читает Treasurer_PortRun (StoreUtilite.c), снимает его officers.c при уходе из команды.
		case "TreasurerPortRunOn":
			NPChar.TreasurerPortRun = 1;
			dialog.text = "Comme vous voudrez, capitaine. Une fois à terre, je passerai au magasin et chez les colporteurs, j'achèterai selon vos listes et je vous remettrai un rapport.";
			link.l1 = "D'accord.";
			link.l1.go = "exit";
		break;

		case "TreasurerPortRunOff":
			NPChar.TreasurerPortRun = 0;
			dialog.text = "Comme vous voudrez. Désormais, le magasin et les colporteurs sont votre affaire, et je m'en tiendrai aux registres.";
			link.l1 = "C'est ça.";
			link.l1.go = "exit";
		break;

		case "ShowParam_exit":
			Diag.CurrentNode = "OnceAgain";
			NPChar.quest.meeting = true;
			DialogExit();

			PChar.SystemInfo.OnlyShowCharacter = true;
            LaunchCharacter(NPChar);
		break;

		// LEO: explanation after a tavern brawl (Tavern_OfficerBrawlCheck), the reason is picked in advance -->
		case "Brawl_1":
			Diag.TempNode = "Hired";
			dialog.text = "Capitaine, ce coquin jouait avec des dés pipés. Il en avait deux paires, dont une dans sa manche. Je ne joue pas à ce genre de jeu.";
			Link.l1 = RandPhraseSimple("Les tricheurs sont les mêmes partout. Bon, laisse tomber.", "Et tu en as récupéré beaucoup ?");
			Link.l1.go = "exit";
		break;

		case "Brawl_2":
			Diag.TempNode = "Hired";
			dialog.text = "Il a traité notre navire de baignoire percée, capitaine. Devant tout le monde. Je navigue dessus, et je ne laisserai pas passer ça.";
			Link.l1 = RandPhraseSimple("Baignoire ou pas, elle flotte encore. Mais merci pour l'honneur du navire.", "La prochaine fois, parie de l'argent dessus, pas tes poings.");
			Link.l1.go = "exit";
		break;

		case "Brawl_3":
			Diag.TempNode = "Hired";
			dialog.text = "Une vieille dette, capitaine. Il me doit encore vingt pièces depuis l'an dernier, et dès qu'il m'a vu, il a plongé le nez dans sa chope.";
			Link.l1 = RandPhraseSimple("Vingt pièces ? Et tout ce tapage pour ça ?", "Les dettes doivent être payées, rien à redire.");
			Link.l1.go = "exit";
		break;

		case "Brawl_4":
			Diag.TempNode = "Hired";
			dialog.text = "Il disait des horreurs sur vous, capitaine. Des choses que je ne répéterai pas. Je sers sous vos ordres, et je ne resterai pas assis à écouter ça.";
			Link.l1 = RandPhraseSimple("On dit pire sur mon compte. Mais j'apprécie.", "Tu ne peux pas cogner sur toutes les langues d'ivrogne des Caraïbes.");
			Link.l1.go = "exit";
		break;

		case "Brawl_5":
			Diag.TempNode = "Hired";
			dialog.text = "Il prétendait avoir passé le détroit de Magellan. Je lui ai poliment demandé, et il n'a pas su nommer un seul cap. Je n'aime pas qu'on se paie la tête des marins.";
			Link.l1 = RandPhraseSimple("Dans une taverne, tout le monde a passé le détroit. D'habitude après la troisième chope.", "Tu aurais pu simplement en rire.");
			Link.l1.go = "exit";
		break;

		case "Brawl_6":
			Diag.TempNode = "Hired";
			dialog.text = "Il a renversé ma chope, capitaine, et n'a même pas pensé à s'excuser. Ici, le rhum ne coמte pas moins cher que la poudre, notez bien.";
			Link.l1 = RandPhraseSimple("Pour une chope de rhum ? Au moins, c'est une raison honnête.", "דa valait un nez cassé ?");
			Link.l1.go = "exit";
		break;

		case "Brawl_7":
			Diag.TempNode = "Hired";
			dialog.text = "Il pelotait la serveuse, capitaine. Elle lui apportait sa boisson, et il a posé les mains sur elle. Elle était au bord des larmes, et personne n'a levé le petit doigt.";
			Link.l1 = RandPhraseSimple("Pour celle-là, je ne te le reprocherai pas.", "Défendre une fille ? Louable, mais le bleu reste.");
			Link.l1.go = "exit";
		break;

		case "Brawl_8":
			Diag.TempNode = "Hired";
			dialog.text = "Il a dit que les officiers se cachent derrière le dos des autres au combat. Il me l'a dit à moi, capitaine. Après tout ce que nous avons traversé. Alors je lui ai montré oם je me cache.";
			Link.l1 = RandPhraseSimple("Tu n'es pas un lâche, je l'ai vu moi-même.", "Agiter la langue est toujours plus facile que manier une lame.");
			Link.l1.go = "exit";
		break;

		case "Brawl_9":
			Diag.TempNode = "Hired";
			dialog.text = "Il se vantait d'avoir navigué sur mon ancien navire et d'y avoir été presque second. Je me souviens de chaque visage de cet équipage, et il n'en faisait pas partie. Se cacher derrière les tombes des autres.";
			Link.l1 = RandPhraseSimple("Mentir sur les vivants, c'est bête ; sur les morts, c'est ignoble. Je comprends.", "Et il a reconnu son erreur ?");
			Link.l1.go = "exit";
		break;

		case "Brawl_10":
			Diag.TempNode = "Hired";
			dialog.text = "Que dire, capitaine... J'avais trop bu. J'étais assis tranquillement, et puis sa tête ne m'est pas revenue. C'est ma faute.";
			Link.l1 = RandPhraseSimple("Honnête, au moins. Va cuver.", "La prochaine fois, compte tes chopes, pas les têtes des autres.");
			Link.l1.go = "exit";
		break;
		// LEO: explanation after a tavern brawl <--

		case "exit":
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_hire":
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
			npchar.CanTakeMushket = true;
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
			if (!CheckAttribute(npchar,"norespec"))
			{
				npchar.SystemInfo.ChangePIRATES = true; //пояснение касательно респека. нужно ставить в функцию ниже реф на офицера
				LaunchCharacter(npchar); //в некоторых случаях он не совпадает с персонажем, с которым идёт диалог, так что нужно внимание
			}
		break;

		case "exit_fire":
			//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}
			//navy <--
			Diag.TempNode = "Fired";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;

			DialogExit();
		break;

		//aw013 --> Найм на постоянку
		case "contract":
			dialog.text = "Je vous écoute attentivement, capitaine.";
			Link.l1 = "Vous êtes un bon officier et vous me convenez parfaitement. Je veux vous proposer de signer un contrat avec moi.";
			Link.l1.go = "contract2";
		break;

		case "contract2":
			dialog.text = "Merci pour ces aimables paroles, capitaine. Et quelles sont les conditions du contrat ?";
			Link.l1 = "Une grosse prime unique. Un meilleur équipement, "+ NPCharSexPhrase(NPChar, "vous le comprenez", "vous le comprenez") +" bien. La durée du contrat est de 10 ans. Vous pourrez partir à la fin du terme et, si tout nous convient à tous les deux, nous le prolongerons.";
			Link.l1.go = "contract3";
		break;

		case "contract3":
			NPChar.contractMoney = makeint(sti(NPChar.rank)*MOD_SKILL_ENEMY_RATE*3*1000);
			dialog.text = "C'est une offre tentante, on ne peut pas dire. De quoi mettre un peu d'argent de cכté pour une vieillesse tranquille. Et pour les petites primes du personnel permanent ?";
			if (sti(Pchar.money) >= sti(NPChar.contractMoney))
			{
				Link.l1 = "Je n'ai rien contre ; est-ce que " + sti(NPChar.contractMoney) + " pièces d'or vous suffiraient tout de suite ?";
				Link.l1.go = "contract4";
			}
			Link.l2 = "Je n'ai rien contre, mais reparlons-en plus tard.";
			Link.l2.go = "Exit";
		break;

		case "contract4":
			dialog.text = "Tout à fait, capitaine. J'accepte.";
			AddMoneyToCharacter(Pchar, -sti(NPChar.contractMoney));
			SetCharacterPerk(NPChar, "EnergyPlus");
			SetCharacterPerk(NPChar, "HPPlus");
			NPChar.OfficerWantToGo.DontGo = true;
			NPChar.loyality = MAX_LOYALITY;
			NPChar.Reputation = REPUTATION_NEUTRAL;
			DeleteAttribute(NPChar, "alignment");
			if (bHalfImmortalPGG)
			{
				if (!CheckAttribute(pchar, "Option_ImmortalOfficers"))
				{
					pchar.Option_ImmortalOfficers = "1";
				}
				else
				{
					pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) + 1);
				}
				NPChar.ImmortalOfficer = true;
				NPChar.HalfImmortal = true;  // Контузия
			}
			// DeleteAttribute(NPChar, "contractMoney");//Mett: это можно заблокировать по желанию, мб потом понадобиться для перерасчёта суммы контракта
			Link.l1 = "Parfait ! Marché conclu.";
			Link.l1.go = "Exit";
		break;
		
		case "cancelcontract1":
			dialog.text = "Voilà qui est inattendu, capitaine. Et de quoi suis-je " + NPCharSexPhrase(NPChar, "coupable ?", "coupable ?");
			Link.l1 = "Oubliez ça, je me suis " + GetSexPhrase("trompé.", "trompée.");
			Link.l1.go = "Exit";
			Link.l2 = "Vos compétences ne me satisfont pas.";
			Link.l2.go = "cancelcontract2";
		break;
			
		case "cancelcontract2":
			NPChar.contractMoney = makeint(sti(NPChar.rank)*MOD_SKILL_ENEMY_RATE*3*1000);
			dialog.text = "Bon, eh bien, si vous payez le dédit prévu par le contrat, je n'aurai rien à redire.";
			if (sti(Pchar.money) >= sti(NPChar.contractMoney))
			{
				Link.l1 = "Comme vous voudrez, " + sti(NPChar.contractMoney) + " pièces d'or, ça vous suffira tout de suite ?";
				Link.l1.go = "cancelcontract3";
			}
			Link.l2 = "J'ai des problèmes d'argent en ce moment, nous reparlerons de tout ça plus tard.";
			Link.l2.go = "Exit";
		break;
			
		case "cancelcontract3":
			dialog.text = "Tout à fait, capitaine. J'accepte" + NPCharSexPhrase(NPChar, ".", ".");
			AddMoneyToCharacter(Pchar, -sti(NPChar.contractMoney));
			pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) - 1);
			NPChar.OfficerWantToGo.DontGo = false;
			NPChar.HalfImmortal = false;
			NPchar.loyalty = MAX_LOYALITY / 2;
			DeleteAttribute(npchar, "ImmortalOfficer");
			if (rand(sti(pchar.reputation)) >= 50)
			{
				NPchar.alignment  = "good";
				NPchar.reputation = 61 + rand(29);
			}
			else
			{
				NPchar.alignment = "bad";
				NPchar.reputation = 39 - rand(29);
			}
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "Exit";
		break;
		
		//aw013 <-- Найм на постоянку
		// boal 29.05.04 офицер хочет свалить -->
        case "WantToGo":
			chrDisableReloadToLocation = false;
			Diag.TempNode = "Hired";
			dialog.text = LinkRandPhrase(LinkRandPhrase("Capitaine, voilà l'affaire... En somme, je demande mon congé. Il y a longtemps que j'aurais dמ me marier, jeter l'ancre dans un port tranquille et avoir des enfants, mais à courir d'un endroit à l'autre, je n'ai rien bâti. Dans ma vieillesse, il n'y aura personne pour me servir à boire.", "Capitaine, donnez-moi mon congé ; voilà tant d'années que je parcours le monde, et je n'ai rien vu, au fond. Je veux goמter à une autre vie, jeter l'ancre et regarder le monde avec d'autres yeux.", "Capitaine, le service en mer, ce n'est pas mal, bien sמr : c'est rentable et on vit toutes sortes d'aventures, mais il faut penser à soi. Jeter l'ancre dans un port tranquille, acheter une maison et avoir des enfants. Vous allez me laisser partir."), LinkRandPhrase("Capitaine, excusez-moi, bien sמr, mais ces régimes de quarts et de discipline sont si ennuyeux que ça en devient écœurant. Je veux goמter un temps à la vie libre. Je comprends que vous n'attendrez pas, alors je demande mon congé.", "Capitaine, il se trouve que j'ai un bateau ici. Il faut bien un jour se mettre à son compte. Laissez-moi partir libre : donnez-moi mon congé.", "Capitaine, on m'a proposé une place au port d'ici. Il y a longtemps que je rêve de jeter l'ancre et de fonder une famille. Donnez-moi mon congé : une telle occasion ne se représentera pas."), LinkRandPhrase("Capitaine, j'en ai déjà assez de la mer. Les médecins disent que c'est une idiosyncrasie. Laissez-moi partir, pour l'amour du Christ, sinon un jour, je n'y tiendrai plus : je me jetterai par-dessus bord.", "Capitaine, je crois qu'il est temps pour moi de me poser et de trouver un endroit plus tranquille. Les balles perdues commencent à me faire peur ; avant chaque abordage, je prie le Sauveur de me garder en vie... Et la nuit, je rêve des innocents : ils implorent tous grâce... Donnez-moi mon congé, soyez humain.", "Capitaine, les vieilles blessures me font souffrir : je n'ai plus de forces, et la récente commotion ne me laisse pas de répit. Encore un peu, et vous me chasserez vous-même, et alors qui me prendra à son service ? Donnez-moi mon congé : je me remettrai et je chercherai un endroit plus tranquille."));
			Link.l1 = RandPhraseSimple(LinkRandPhrase("Hum, tout le monde va filer comme ça... Mais je ne vais pas te forcer : va, si tu as décidé.", "Eh bien, la raison est claire. Tכt ou tard, tout a une fin. Va... N'oublie pas que tu m'as fait de la peine.", "Quelles gens ! Ils essaient de filer au moment le plus inopportun !.. Va, quel soldat ferais-tu maintenant..."), LinkRandPhrase("Difficile à croire. Il y a quelque chose que tu ne me dis pas... Bon, quoi qu'il en soit, je ne t'ai pas fait jurer sur la Bible, alors va, la conscience tranquille.", "Je ne m'attendais pas à entendre ça de ta part ! Tant de temps cכte à cכte... J'aurais pu soupçonner n'importe qui, mais pas toi. Je n'aime vraiment pas être déçu par les gens... Fais tes bagages et ne te mets plus en travers de mon chemin.", "C'est une affaire sérieuse : je ne vais pas te retenir... Même si tu vas beaucoup me manquer."));
			Link.l1.go = "WantToGo_free";
			if (sti(Pchar.money) >= sti(NPChar.rank)*250)
			{
				Link.l2 = LinkRandPhrase("Ouais, tu vois comment ça a tourné... Et moi qui comptais sur toi... Bon, puisque la décision est prise, séparons-nous. Voici "+sti(NPChar.rank)*250+" pièces d'or pour tes loyaux services. Et ne m'en veux pas si jamais je t'ai fait du tort" + GetSexPhrase(".", "."), "Eh bien, je ne t'en veux pas et je ne retiens que le bon. Puisque tu as décidé, va. Prends "+sti(NPChar.rank)*250+" pièces d'or pour la route. דa sert toujours.", "Je vois... דa devait arriver tכt ou tard. Je te fais cadeau de "+sti(NPChar.rank)*250+" pièces d'or pour refaire ta vie. Et soigne-toi : le service en mer, ce n'est pas du sucre, ça laisse des traces pour la vie...");
				Link.l2.go = "Im_kind_A2_1";
			}
			Link.l3 = LinkRandPhrase("Voilà donc. Tu te rends compte que ton départ, en ce moment, c'est un coup de couteau dans le dos ? Je ne peux pas te laisser partir maintenant : n'y pense même pas, ne le demande pas.", "En voilà une nouvelle ! Ce genre de chose se dit à l'avance. Alors oublie ta vie privée pour l'instant. Le moment venu, c'est moi qui te proposerai ton congé.", "Pas de congé. Chaque homme compte. Je ne peux pas, au gré des caprices de chacun, éparpiller l'équipage. Tu serviras jusqu'à ce que j'en décide autrement.");
			Link.l3.go = "WantToGo_Stay";
		break;

		case "Im_kind_A2_1":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*250)));
			ChangeOfficersLoyality("good_all", 1);
			ChangeCharacterReputation(pchar, 1);
			dialog.text = "Merci, capitaine ! Quelle générosité inattendue. Il me reste quelques-unes de vos affaires, voulez-vous que je vous les rende ?";
			Link.l1 = "Oui, je suppose... Ce n'est pas facile de trouver une bonne lame en ce moment...";
			Link.l1.go = "Get_out_А2_chang";
			Link.l2 = "Inutile. Garde-les en souvenir de ton service sous mes ordres...";
			Link.l2.go = "WantToGo_free";
		break;
		case "WantToGo_Stay":
			dialog.text = RandPhraseSimple("Mais comment ça ? Les esclaves, on les débarque sur le rivage, et encore. Et moi, je ne suis pas un esclave, et j'ai le droit de décider de mon sort !", "Capitaine, n'ai-je pas mérité, par tout mon zèle, le droit de décider de mon propre sort ?");
			Link.l1 = LinkRandPhrase("Je vois qu'on ne peut pas te retenir si facilement. Et un soutien financier ? Ce genre de chose est toujours utile : pour faire son nid dans un port tranquille, et pour soigner sa santé...", "Bon, parlons autrement. Combien d'argent te faut-il pour rester ?", "Tu as raison sur ce point. Que dirais-tu d'une prime unique ?");
			Link.l1.go = "WantToGo_Stay_2";
			Link.l2 = PCharRepPhrase(
				RandPhraseSimple("Ah non, là, tu te trompes... Tant que tu usais tes fonds de culotte à la taverne, tu pouvais décider de ton sort toi-même... Mais dès que tu es monté sur mon navire, c'est moi qui décide pour toi.", "Hum, voilà une déclaration sérieuse. Tu as sans doute oublié comment je t'ai trouvé dans une taverne puante, sans un sou en poche. Oui, on ne peut même pas te montrer de l'or de loin : il se change aussitכt en rhum, et là, tu peux « décider de ton sort »."),
				LinkRandPhrase("Tant que tu es à mon service, c'est moi qui prends les décisions. Retourne à tes fonctions, je te prie, si tu ne veux pas ruiner complètement tes relations avec moi !", "Hum. Voilà une déclaration sérieuse. Mais tu n'as pas encore remboursé par ton travail tout l'argent qui t'a été versé. J'ai donc le droit de considérer ta démarche comme une tentative de chantage.", "Je vois... Et rappelons-nous la charte du navire. Le deuxième article dit : « Si quelqu'un décide de déserter... Qu'on le débarque sur un rivage désert avec une flasque de poudre, une flasque d'eau, un fusil et des balles. » Que penses-tu de ce rebondissement ?"));
			Link.l2.go = "WantToGo_Stay_force";
		break;

	case "WantToGo_Stay_2":
		dialog.text = LinkRandPhrase("Eh bien, voilà qui change tout. "+sti(NPChar.rank)*500+" pièces d'or, et je reste.", "Eh bien, peut-être que pour "+sti(NPChar.rank)*500+" pièces d'or, je resterais.", "Hum, puisque cette conversation a commencé, alors pour "+sti(NPChar.rank)*500+" je resterais.");
		if (sti(Pchar.money) >= sti(NPChar.rank)*500)
		{
			Link.l1 = RandPhraseSimple("Voilà qui est réglé.", "Très bien. Même si tu aurais pu être plus modeste...", "Quel appétit ! Bon, puisque j'ai promis, tiens.");
			Link.l1.go = "WantToGo_Stay_ForMoney";
		}
		Link.l2 = LinkRandPhrase("Eh bien, tu exagères. Pour une telle somme, on peut engager deux officiers. Il est sans doute plus simple de te laisser partir.", "Tu t'estimes bien haut. Je crois que je vais te rendre ta liberté. Mais tu verras : la vie au-dehors n'est pas couverte de miel non plus.", "Je ne suis pas prêt à payer une telle somme. Tu peux partir, mais ne demande pas à revenir : je ne pardonne pas la trahison.");
		Link.l2.go = "WantToGo_free";
	break;

	case "WantToGo_Stay_force":
		Npchar.loyality = makeint(Npchar.loyality) - 2;
		dialog.text = "Eh bien, si c'est ainsi, je reste... Mais sachez que j'agis contre ma volonté...";
		Link.l1 = LinkRandPhrase("Voilà qui est bien. Retourne à tes fonctions, et nous reprendrons cette conversation plus tard.", "Remonte à bord tout de suite. Et la prochaine fois, réfléchis bien avant de demander ton congé.", "Voilà. Le service, c'est le service, il n'y a pas de place pour tes fantaisies.");
		Link.l1.go = "exit";
	break;

	case "WantToGo_Stay_ForMoney":
		Diag.TempNode = "Hired";
		if (NPChar.sex != "woman")
		{
			NPChar.greeting = "Gr_Officer";
		}
		AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*500)));
		Npchar.loyality = makeint(Npchar.loyality) + 1;
            Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
			NPChar.location = "none";
			LAi_SetOfficerType(NPChar);
		break;

		case "WantToGo_free":
			//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				Diag.CurrentNode = Diag.TempNode;
				DialogExit();
				break;
			}
			//navy <--
            Diag.TempNode = "WantToGo_free_Yet";
		Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "WantToGo_free_Yet":
            Diag.TempNode = "WantToGo_free_Yet";
		dialog.text = LinkRandPhrase ("Vous ne me croirez pas, capitaine, mais c'est un poids en moins.", "Merci, capitaine, de ne pas me retenir. Je veux essayer autre chose dans ma vie.", "Eh, je vais m'habituer à la liberté. Je ne me rends compte que maintenant à quel point le service en mer me dégoמte.");
		Link.l1 = RandPhraseSimple("Eh bien, je te souhaite plein de succès...", "Va te promener. Ton service est terminé.");
		Link.l1.go = "exit";
	break;
	// boal 29.05.04 офицер хочет свалить <--

	// пассажир возмущён игроком и сваливает -->
	case "WantToRemove":
        chrDisableReloadToLocation = false;
		if (Npchar.alignment == "good")
		{
			dialog.text = RandPhraseSimple(LinkRandPhrase("Capitaine, je ne veux pas violer ma conscience en me livrant au brigandage pour le profit.", "Capitaine, je ne veux plus prendre part à vos atrocités. Je ne suis pas un boucher, je suis un officier.", "Capitaine, vos manières de bandit m'empêchent de rester plus longtemps dans l'équipage."), LinkRandPhrase("Capitaine, je dois avouer que mon engagement chez vous a été une malheureuse erreur. Je ne suis absolument pas prêt à sacrifier mon nom honnête pour de l'argent.", "Capitaine, des coupe-jarrets de tout le Nouveau Monde se sont réunis sur votre navire : pour une personne convenable, c'est dégoמtant d'entrer au carré. Je ne veux plus servir dans un tel équipage.", "Capitaine, vous avez recruté des escrocs dans l'équipage : il n'y a personne avec qui échanger un mot gentil. Le cœur n'y est plus du tout pour un tel service.")) + "Au revoir.";
			Link.l1 = "Quoi ?!! J'ai un navire de guerre, pas une pension pour nobles ! Tu peux aller au diable !";
			Link.l1.go = "exit_fire_1";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l2 = "Je savais depuis longtemps que tu partirais... Ce genre de service n'est pas fait pour toi. Mais je n'ai rien à te reprocher. Voici "+sti(NPChar.rank)*500+" pièces d'or pour toi, elles te seront utiles jusqu'à ce que tu trouves un travail qui te plaise.";
				Link.l2.go = "Im_kind_A2";
			}
			Link.l3 = LinkRandPhrase("Ouais. Voilà donc la chanson. La part qu'on t'a versée de chaque pillage ne te brמle pas les mains ? Ou tu vas filer d'ici tout droit dans un monastère pour expier tes péchés ? Alors, glisse un mot pour nous ! Ah ha ha ha...", "Hum, voilà une déclaration sérieuse. Et oם regardait ta conscience immaculée quand nous pillions les marchands ensemble ? Avec quoi vas-tu la laver ? Tu vas sans doute courir griffonner une dénonciation, pour pouvoir te balancer au gibet en bonne compagnie...", "דa alors, bravo !.. Tu as sans doute oublié comment je t'ai trouvé dans une taverne puante, sans un sou en poche. Oui, comme officier, tu ne vaux rien, et en plus, tu manges le pain gratuit.");
			Link.l3.go = "WantToGo_stop";
			}
			else
			{
            dialog.text = RandPhraseSimple(LinkRandPhrase("Capitaine, vos jeux de noblesse ne me plaisent pas du tout. Je ne vais pas changer mes habitudes pour votre tranquillité d'esprit. Adieu.", "Capitaine, je ne peux plus rester à votre service. On a perdu tant de temps : on aurait déjà pu faire fortune par la simple course. Je m'en vais.", "Capitaine, j'en ai assez de tels collègues. Inutile même d'aller au carré : il n'y a que des fils à maman, personne avec qui boire du rhum. Je m'en vais."), LinkRandPhrase("Capitaine, je suis un officier de combat, et votre navire ressemble plutכt à une barge de transport. Ce genre de service n'est pas pour moi, je m'en vais. Adieu.", "Capitaine, vous avez recruté des gens à l'esprit bien propre dans l'équipage : il n'y a personne avec qui boire du rhum et échanger un mot. Le cœur n'y est plus du tout pour un tel service, alors adieu.", "Capitaine, je croyais servir un vrai corsaire. Et que faisons-nous ? Rien que de la charité ! Je ne veux pas perdre mon temps, je m'en vais."));
			Link.l1 = RandPhraseSimple("Eh bien, oui. Avec ton attitude envers le service, ça devait arriver tכt ou tard. Bon, je ne te retiendrai pas.", "Une telle déclaration ne m'a pas surpris. Il y a longtemps que ton attitude envers le service ne me satisfait plus.") + "Bonne journée.";
			Link.l1.go = "exit_fire_1";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l2 = "Je savais que tu partirais... Ce genre de service n'est pas fait pour toi. Mais je n'ai rien à te reprocher. Voici "+sti(NPChar.rank)*500+" pièces d'or. Elles te seront utiles pendant que tu cherches une nouvelle place.";
				Link.l2.go = "Im_kind_A2";
			}
			Link.l3 = RandPhraseSimple("Hum. Voilà une déclaration sérieuse. Mais tu n'as pas encore gagné tout l'argent qui t'a été versé. J'ai donc le droit de considérer ta démarche comme une désertion.", "Je vois... Et rappelons-nous la charte du navire. Le deuxième article dit : « Si quelqu'un décide de déserter... Qu'on le débarque sur un rivage désert avec une flasque de poudre, une flasque d'eau, un fusil et des balles. » Que penses-tu de ce rebondissement ?");
			Link.l3.go = "WantToGo_stop";
		}
		break;

		case "WantToGo_stop":
			if (Npchar.alignment == "good")
			{
				dialog.text = LinkRandPhrase("N'essayez pas de m'insulter ! Comme tout le monde, je sers pour de l'argent, mais j'ai le droit de choisir un travail qui me plaît.", "Je suis un homme libre ! Et j'ai le droit de changer de travail quand bon me semble.", "Je ne suis pas un esclave qui sert pour sa pitance, alors ma conscience est tranquille ! Mais je ne vais pas continuer à participer à ce brigandage !");
				Link.l1 = "Ah non, c'est là que tu te trompes... Tant que tu bavais sur une chope à la taverne, oui, tu pouvais choisir n'importe quel travail... Mais une fois monté sur mon navire, c'est fini... Le seul chemin du retour, c'est avec un boulet au cou, héhé... Et encore faut-il te raccourcir la langue, pour que dans l'autre monde tu ne laisses pas échapper ce qu'il ne faut pas...";
				if (makeint(Pchar.Rank) > makeint(NPchar.Rank))
				{
					Link.l1.go = "WantToGo_stop_stay";
				}
				else
				{
					Link.l1.go = "WantToGo_stop_fight";
				}
				Link.l2 = "Bon, d'accord. Va... Mais Dieu te garde de me croiser en haute mer. Je te jure que tu regretteras de ne pas être resté à mes cכtés.";
				Link.l2.go = "exit_fire_5";
			}
			else
			{
				dialog.text = LinkRandPhrase("N'essayez pas de m'intimider ! Comme tout le monde, je sers pour de l'argent, et j'ai le droit de choisir un travail qui me plaît.", "Je suis un homme libre ! Et j'ai le droit de changer de travail quand bon me semble.", "Je ne suis pas votre esclave ! Et je n'ai pas l'intention de continuer à végéter sur votre baille !");
				Link.l1 = "Ah non, c'est là que tu te trompes... Tant que tu bavais sur une chope à la taverne, oui, tu pouvais choisir n'importe quel travail... Mais une fois monté sur mon navire, c'est fini... Le seul chemin du retour, c'est avec un boulet au cou, héhé... Et il faut te raccourcir la langue, pour que dans l'autre monde tu ne laisses pas échapper ce qu'il ne faut pas...";
				if (makeint(Pchar.Rank) > makeint(NPchar.Rank))
				{
					Link.l1.go = "WantToGo_stop_stay";
				}
				else
				{
					Link.l1.go = "WantToGo_stop_fight";
				}
				Link.l2 = "Bon, d'accord. Va... Mais Dieu te garde de me croiser en haute mer. Je te jure que tu regretteras de ne pas être resté à mes cכtés.";
				Link.l2.go = "exit_fire_5";
			}
		break;

		case "WantToGo_stop_stay":
			dialog.text = RandPhraseSimple("Si les choses tournent ainsi, je reste : je n'ai tout simplement pas le choix. Mais sachez que je ne le fais pas de mon plein gré...", "Eh bien, si c'est ainsi, je reste... Mais sachez que j'agis contre ma volonté...");
			Link.l1 = RandPhraseSimple("Voilà qui est bien... Sers jusqu'à ce que je décide de te flanquer dehors.", "Voilà qui est bien : sers pour l'instant... Et c'est moi qui déciderai quand te chasser.");
			Link.l1.go = "WantToGo_Munity"; //этот линк ведёт к бегству
		break;

		case "WantToGo_stop_fight":
			dialog.text = NPCharRepPhrase(NPChar, "Vous ne me ferez jamais changer d'avis ! Vous êtes mal tombé !", "Vous croyez sans doute pouvoir effrayer un officier de combat ?! Ce n'est pas la première fois que je regarde la mort en face. Et à tout prendre, mieux vaut mourir dans un combat loyal qu'au cours d'un lâche brigandage !");
			Link.l1 = NPCharRepPhrase(NPChar, "Eh bien... chacun choisit son destin. J'espère que tu as fait ta prière avant de venir me voir.", "Si j'avais su qui tu étais quand je t'ai ramassé dans une taverne, à la dérive et sans le sou, je jure que je t'aurais plutכt laissé crever. Et il n'est pas trop tard pour arranger ça...");
			Link.l1.go = "WantToGo_stop_fight_1";
			Link.l2 = NPCharRepPhrase(NPChar, "Bon, va, puisque tu tiens tant à ta liberté. Mais sache que tu n'auras aucune recommandation de ma part.", "Bon, d'accord. Va... Mais Dieu te garde de tomber entre mes mains en haute mer. Je te jure que tu regretteras de ne pas être resté à mes cכtés.");
			Link.l2.go = "exit_fire_5";
		break;

		case "WantToGo_stop_fight_1":
			ChangeOfficersLoyality("bad_all", 1);
			ChangeCharacterReputation(pchar, -1);
			dialog.text = NPCharRepPhrase(NPChar, "Ne me faites pas peur ! Lequel de vos blancs-becs ose élever la voix contre moi ?! Si j'étais capitaine, ils seraient déjà riches ! Et vous avez fait pousser... la bienveillance, et maintenant vous tremblez que l'équipage passe de mon cכté ?!", "Laissez tomber vos manières, vous ne me faites pas peur ! Adieu.");
			Link.l1 = NPCharRepPhrase(NPChar, "Non, mon gars, tu ne vivras pas jusqu'à l'échafaud. Un tel luxe n'est pas pour toi...", "Pas si vite, mon gars, je ne t'ai pas encore payé...");
			Link.l1.go = "Get_out_fight";
		break;
		///////////////////////////////////////////////////////////////////////////////////
		case "WantToGo_Munity":	//zagolski. отыгрыш бегство офицера
			Diag.TempNode = "Hired";
			if (!CheckAttribute(PChar, "questTemp.MunityOfficerID") || PChar.questTemp.MunityOfficerID != NPChar.id)
			{
				Pchar.questTemp.MunityOfficerID = Npchar.id;
				Pchar.questTemp.MunityOfficerID.begin = "1";
				SetFunctionTimerCondition("mOfficer_fc", 0, 0, 1, false);
			}
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.location = "none";
			LAi_SetOfficerType(NPChar);
			DialogExit();
		break;
		////////////////////////////////////////////////////////////////////
		// пассажир возмущён игроком и сваливает <--

		case "Node_2":
			dialog.text = NPCharRepPhrase(Npchar, RandSwear() + "Je suis le meilleur "+ XI_ConvertString(Npchar.quest.officertype) + " de ces eaux. " + Npchar.quest.officertype_2 + "Je peux vous rendre service en m'engageant chez vous.",
                                    "Eh bien, on dit que je ne suis pas un mauvais " + XI_ConvertString(Npchar.quest.officertype) + ". " + Npchar.quest.officertype_2 + "Prenez-moi dans votre équipage, capitaine, et voyez par vous-même.");
			Link.l1 = "Combien voulez-vous ?";
			Link.l1.go = "price";
			Link.l2 = "Et que pensez-vous de vous-même en tant que spécialiste ?";
			Link.l2.go = "ShowParam_exit";
			Link.l3 = "Désolé, j'ai déjà un " + XI_ConvertString(Npchar.quest.officertype) + " dans mon équipage.";
			Link.l3.go = "Exit";
		break;

		case "OnceAgain":
			if (LAi_grp_playeralarm > 0)
			{
       			dialog.text = RandPhraseSimple("Hé, capitaine, la moitié de la garnison vous court après ici. Ce n'est clairement pas le moment de rejoindre votre équipage !", "Vous proposez de forcer le chemin jusqu'au navire en se battant ? Non, une autre fois, cap'taine...");
				link.l1 = RandPhraseSimple("Eh bien, comme vous voudrez...", "Je n'avais pas l'intention de vous engager.");
				link.l1.go = "exit";
				break;
			}
			Diag.TempNode = "OnceAgain";
			dialog.text = "Vous avez changé d'avis, capitaine ? Vous avez décidé qu'un nouveau " + XI_ConvertString(Npchar.quest.officertype) + " vous ferait du bien ?";
			// boal -->
			if (FindFreeRandomOfficer() > 0)
			{
                Link.l1 = "Peut-être bien. Combien voulez-vous ?";
                Link.l1.go = "price";
			}
			Link.l2 = "Comment vous en sortez-vous dans votre partie ?";
			Link.l2.go = "ShowParam_exit";
			// boal <--
			Link.l3 = "J'ai mon effectif complet. Portez-vous bien.";
			Link.l3.go = "exit";
		break;

		case "price":
			dialog.text = "Je pense que nous pouvons nous entendre sur " + Npchar.quest.OfficerPrice + " piastres.";
			Link.l1 = "Vous n'en voulez pas un peu trop ?";
			Link.l1.go = "trade";
			Link.l2 = "D'accord. Considérez-vous comme enrכlé dans l'équipage.";
			Link.l2.go = "hire";
			Link.l3 = "Vous ne valez pas cet argent. Au revoir.";
			Link.l3.go = "exit";
		break;

		case "trade":
			if (GetSummonSkillFromNameToOld(pchar, SKILL_COMMERCE) >= Rand(12) && (sti(Npchar.quest.OfficerPrice) - GetCharacterSkillToOld(Pchar, "commerce")*100) >= sti(Npchar.quest.OfficerLowPrice))// bug fix
			{
				Npchar.quest.OfficerPrice = makeint(makeint(Npchar.quest.OfficerPrice) - GetCharacterSkillToOld(Pchar, "commerce")*100); // пусть будет коммерция перса голой
				dialog.text = "Bon... Je suis peut-être prêt à accepter même " + Npchar.quest.OfficerPrice + " piastres. Qu'en dites-vous ?";
				Link.l1 = "Voilà qui est mieux. Vous êtes engagé.";
				Link.l1.go = "hire";
				Link.l2 = "Je trouve toujours que c'est trop. Au revoir.";
				Link.l2.go = "exit";
			}
			else
			{
				dialog.text = "Hélas, capitaine, je vaux exactement ce que j'ai demandé. Si c'est trop cher pour vous, cherchez quelqu'un d'autre.";
				Link.l1 = "Très bien, j'accepte. Je vous prends.";
				Link.l1.go = "hire";
				Link.l2 = "C'est ce que je vais faire. Bonne journée.";
				Link.l2.go = "exit";
			}
		break;

		case "hire":
			if(makeint(Pchar.money) >= makeint(Npchar.quest.OfficerPrice))
			{
				IncAndUnlock("officers", 1);

				AddMoneyToCharacter(Pchar, -(makeint(Npchar.quest.OfficerPrice)));
				Diag.TempNode = "OnboardSoon";
				dialog.text = "Merci, capitaine. Vous ne regretterez pas de m'avoir donné cet or.";
				Link.l1 = "J'aime à le croire.";
				Link.l1.go = "Exit_hire";
			}
			else
			{
				dialog.text = "Hé, on dirait que vous avez des problèmes d'argent ! Désolée, capitaine, mais je ne travaille pas à crédit.";
				Link.l1 = "Oh, bon sang !";
				Link.l1.go = "Exit";
			}
		break;

		case "OnboardSoon":
			Diag.TempNode = "OnboardSoon";
			dialog.text = "Je finis mon verre, capitaine, et je monte à bord. Ne vous inquiétez pas, je serai là avant le départ.";
			Link.l1 = "Très bien. Si tu es en retard, je te ferai briquer le pont !";
			Link.l1.go = "Exit";
		break;

        case "QMASTER_1":
			if(sti(PChar.Ship.Type) == SHIP_NOTUSED)
			{
				dialog.text = "Capitaine, mais nous n'avons pas de navire !";
				Link.l1 = "Merci de me le rappeler...";
				Link.l1.go = "Exit";
				Diag.TempNode = "Hired";
				break;
			}
            dialog.text = "Activité maximale des rats à bord : " +
            FloatToString(50.0 / (2.0+GetSummonSkillFromNameToOld(PChar, SKILL_REPAIR) + GetSummonSkillFromNameToOld(PChar,SKILL_SNEAK)), 1) +
            " % de la quantité de marchandises. Pour "+GetCrewQuantity(PChar) + " marins, il nous faut  " + makeint((GetCrewQuantity(PChar)+6) / 10) + " unités de vivres par jour. Et ceci sans compter les esclaves transportés.";
            Link.l1 = "Merci.";
            Link.l1.go = "Exit";
			if (NPChar.id == "Andreas_Fickler")
			{
				dialog.text = "Activité maximale des r-r-rats à bord : " +
				FloatToString(50.0 / (2.0+GetSummonSkillFromNameToOld(PChar, SKILL_REPAIR) + GetSummonSkillFromNameToOld(PChar,SKILL_SNEAK)), 1) +
				" % de la quantité de marchandises. Pour "+GetCrewQuantity(PChar) + " marins, il f-faut " + makeint((GetCrewQuantity(PChar)+6) / 10) + " unités de v-vivres par jour. Et ceci sans compter les esclaves t-t-transportés.";
				Link.l1 = "Merci, mon ami bègue.";
				Link.l1.go = "Exit";
			}
            Diag.TempNode = "Hired";
        break;

        // boal 05.09.03 offecer need to go to abordage -->
        case "stay_follow":
            dialog.text = "Quels sont vos ordres ?";
			if (NPChar.id == "Andreas_Fickler")
			{
				dialog.text = "Q-quels sont vos ordres ?";
			}
            Link.l1 = "Reste ici !";
            Link.l1.go = "Boal_Stay";
            Link.l2 = "Suis-moi et ne traîne pas !";
            Link.l2.go = "Boal_Follow";
            // boal 05.09.03 offecer need to go to abordage <--

			if (findsubstr(npchar.model, "PGG" , 0) != -1 && !CheckAttribute(npchar, "CanTakeMushket"))
			{
				Link.l3 = "Puis-je te confier un mousquet ?";
				Link.l3.go = "CheckMushket";
			}
			if (findsubstr(npchar.model.animation, "mushketer" , 0) != -1)
			{
				Link.l3 = "Je veux que tu restes à une certaine distance de la cible.";
				Link.l3.go = "TargetDistance";
			}
			if (!CheckAttribute(npchar, "AboardRestriction"))
			{
				Link.l4 = "Je vous demande de ne pas participer aux abordages. Prenez soin de vous.";
				Link.l4.go = "AboardRestriction";
			}
			else
			{
				Link.l4 = "J'ai changé d'avis, vous pouvez participer aux abordages.";
				Link.l4.go = "AboardAllowed";
			}
		break;

		case "AboardRestriction":
			npchar.AboardRestriction = true;
			dialog.text = "א vos ordres, capitaine ! Je ne participerai pas aux abordages tant que vous ne me l'aurez pas de nouveau permis.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

		case "AboardAllowed":
			DeleteAttribute(npchar, "AboardRestriction");
			dialog.text = "א vos ordres, capitaine ! Désormais, je participerai aux abordages.";
            Link.l1 = "Voilà qui est bien.";
            Link.l1.go = "exit";
		break;

		case "CheckMushket":
			if (findsubstr(npchar.model.animation, "man" , 0) != -1 || findsubstr(npchar.model.animation, "YokoDias" , 0) != -1 || findsubstr(npchar.model.animation, "Milenace" , 0) != -1)
			{
				if (findsubstr(npchar.model.animation, "man2_ab" , 0) == -1)	Npchar.CanTakeMushket = true;
			}

			if (CheckAttribute(npchar, "CanTakeMushket"))
			{
				dialog.text = "א vos ordres, capitaine !";
				Link.l1 = "Parfait, alors nous te trouverons quelque chose, si possible.";
				Link.l1.go = "exit";
			}
			else
			{
				dialog.text = "Mieux vaut pas, capitaine. Je vous tirerais encore dessus par inadvertance.";
				Link.l1 = "Dommage, dommage...";
				Link.l1.go = "exit";
			}
		break;

		case "TargetDistance":
			dialog.text = "Laquelle exactement, capitaine ? Précisez-la en mètres, mais pas plus de 20.";
			link.l1 = "";
			Link.l1.edit = 3;
			link.l1.go = "TargetDistance_1";
		break;
		case "TargetDistance_1":
			iTemp = sti(dialogEditStrings[3]);
			if (iTemp < 0)
			{
				dialog.text = "Capitaine, quel mauvais ton !";
				link.l1 = "Pardon, c'était une erreur...";
				link.l1.go = "exit";
				break;
			}
			if (iTemp == 0)
			{
				dialog.text = "Je resterai immobile, sans bouger. דa vous convient, capitaine ?";
				link.l1 = "Oui, c'est exactement ce qu'on attend de vous.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 0;
				break;
			}
			if (iTemp > 20)
			{
				dialog.text = "Je crois avoir dit que je ne peux pas rester à plus de 20 mètres de la cible.";
				link.l1 = "D'accord, gardez une distance de 20 mètres.";
				link.l1.go = "exit";
				npchar.MusketerDistance = 20.0;
				break;
			}
			dialog.text = "Je comprends la mission, j'en prends note.";
			link.l1 = "Bien.";
			link.l1.go = "exit";
			npchar.MusketerDistance = iTemp;
		break;

		case "AsYouWish":
			// проверка на море -->
			if (bSeaActive)
			{
				attr = Sea_FindNearColony();
				if (attr == "none")
				{
					dialog.text = "Capitaine, même si je ne comprends pas la raison d'une telle déclaration, revenons sur cette question à terre. Ou bien avez-vous décidé de me jeter tout simplement par-dessus bord ?";
					Link.l1 = "Hum... non, ce n'était pas mon intention. Restez jusqu'à ce que nous arrivions au port.";
					Link.l1.go = "Exit";
					break;
				}
			}
			// проверка на море <--
			if (makeint(PChar.reputation) >= 40 && makeint(NPChar.reputation) < 40) //герой против злодея
			{
				dialog.text = RandPhraseSimple(LinkRandPhrase("En voilà une nouvelle !", "Quelle bonne surprise, vraiment ?!", "Pourquoi tout à coup ?!"), RandPhraseSimple("Capitaine, vous avez perdu la tête ? Annoncer une telle nouvelle de but en blanc !", "דa alors ! Et qu'est-ce qui ne va pas chez moi ?"));
				Link.l1 = RandPhraseSimple(LinkRandPhrase("J'ai décidé de remettre de l'ordre dans l'escadre. Et comme tes relations avec tes collègues ne me plaisent pas, ", "Tes qualités n'étaient pas aussi bonnes que ce qu'on avait signé au moment de l'engagement, alors", "Il n'y aura pas de coupe-jarrets ni d'escrocs dans mon équipage ! Donc, "), LinkRandPhrase("J'ai appris que tu fais passer du rhum en douce et que tu soמles l'équipage, ce qui sape son moral. Donc, ", "J'en ai par-dessus la tête de tes manières de brigand, je ne vais pas les supporter éternellement. Alors, ", "Tu passes ton temps au carré à jouer aux cartes ou aux dés, en détournant les autres officiers de leur service. דa ne peut pas durer indéfiniment, alors")) + " fais tes bagages et quitte le navire.";
				if (makeint(Pchar.Rank) > makeint(NPchar.Rank))
				{
					Link.l1.go = "Get_out_A1_peace";
				}
				else
				{
					Link.l1.go = "Get_out_A1_strife";
				}
				break;
			}
			if (makeint(PChar.reputation) >= 40 && makeint(NPChar.reputation) >= 40) // герой против героя
			{
				dialog.text = RandPhraseSimple(RandPhraseSimple("Puis-je connaître les raisons de cette décision ?", "Une telle décision a sמrement de bonnes raisons ?"), RandPhraseSimple("Expliquez-vous, je vous prie, capitaine.", "C'est très inattendu. Mais j'aimerais connaître les raisons."));
				if (NPChar.id == "Andreas_Fickler")
				{
					dialog.text = RandPhraseSimple(RandPhraseSimple("P-puis-je connaître les r-r-raisons de cette décision ?", "U-une telle décision a s-sמrement de bonnes r-raisons ?"), RandPhraseSimple("E-e-expliquez-vous, je vous prie, capitaine.", "C'est très i-inattendu. M-mais j'aimerais connaître les raisons."));
				}
				Link.l1 = RandPhraseSimple(LinkRandPhrase("Ton attitude envers tes fonctions ne me satisfait absolument pas.", "Malheureusement, tu n'as pas fait un bon officier, et tu n'en feras sans doute jamais un...", "Tu es un bon officier, et tu as bien servi, mais ici, nos chemins se séparent. Et ne me demande pas pourquoi."), LinkRandPhrase("Je t'avais prévenu que ta passion pour le rhum te perdrait. Comment faire confiance au combat à un homme incapable de remettre son sabre au fourreau ?", "Pour parler franchement, tu n'as pas fait un marin... Je pense que tu réussiras mieux à terre.", "Il y a longtemps que tes compétences ne me satisfont plus, mais maintenant, j'ai enfin trouvé un digne remplaçant."));
				Link.l1.go = "Get_out_A2";
				break;
			}
			if (makeint(PChar.reputation) < 40 && makeint(NPChar.reputation) >= 40) // злодей против героя
			{
				dialog.text = RandPhraseSimple(RandPhraseSimple("Hum. Puis-je connaître les raisons ?", "Voilà une déclaration sérieuse. Puis-je vous demander ce qui ne va pas, au juste ?"), RandPhraseSimple("Expliquez-vous, je vous prie, capitaine.", "J'espère qu'il y a de bonnes raisons à une telle déclaration ?"));
				Link.l1 = RandPhraseSimple(LinkRandPhrase("Tes compétences ne me satisfont pas du tout, alors", "Malheureusement, tu n'as pas fait un bon officier. Donc, ", "J'en ai par-dessus la tête de tes élans de noblesse. Je n'ai pas l'intention de les supporter éternellement, alors, "), LinkRandPhrase("J'ai entendu dire que c'est toi qui pousses l'équipage à la désobéissance. Il n'y aura pas de mutinerie sur mon navire ! Et tu n'as pas à me remercier de ne pas t'avoir jeté dehors plus tכt... Donc, ", "Tes nobles principes t'honorent, mais ils vont à l'encontre de la vie de brigand d'un corsaire libre. Donc, ", "Ton attitude envers tes fonctions ne me satisfait absolument pas. Donc, ")) + "fais tes bagages et quitte le navire.";
				if (makeint(Pchar.Rank) > makeint(NPchar.Rank))
				{
					Link.l1.go = "Get_out_A3_peace";
				}
				else
				{
					Link.l1.go = "Get_out_A3_strife";
				}
				break;

			}
			if (makeint(PChar.reputation) < 40 && makeint(NPChar.reputation) < 40) // злодей против злодея
			{
				dialog.text = RandPhraseSimple(LinkRandPhrase("Capitaine, je ne m'attendais pas du tout à un tel tournant ! Pouvez-vous m'expliquer ce qui s'est passé ?", "Capitaine, quelle mouche vous a piqué ?!", "Que voulez-vous dire, capitaine ?!"), RandPhraseSimple("Comment ça, capitaine ?! Ce matin encore, tout allait bien, et voilà que...", "דa alors ! Vous pourriez trouver quelques mots pour m'expliquer ?"));
				Link.l1 = RandPhraseSimple(LinkRandPhrase("Tu es d'une incompétence rare : tu aurais dמ être mousse sur un caboteur. J'ai été patient trop longtemps déjà. Alors, ", "Il y a longtemps que tu ne me satisfais plus, mais maintenant, j'ai enfin trouvé un digne remplaçant. Alors, ", "J'ai appris que tu fais passer du rhum en douce et que tu soמles l'équipage, ce qui sape son moral. Donc, "), LinkRandPhrase("א ton engagement, tu disais qu'on ne trouverait pas de meilleur officier dans toute la flotte, mais en fait, tu t'es révélé un fainéant ordinaire, alors", "Je t'avais prévenu que ta boisson finirait mal. Pourquoi dois-je tout faire à ta place ? Alors, ", "Au lieu de faire ton service, tu restes collé au carré à jouer aux cartes ou aux dés. J'espère que tu ne croyais pas que ça pourrait durer indéfiniment ? Alors, ")) + "fais tes bagages et fiche le camp.";
				Link.l1.go = "Get_out_A4";
				break;
			}
		break;

		case "Get_out_A1_peace":
			dialog.text = RandPhraseSimple(LinkRandPhrase("Voilà donc ! Eh bien, c'est votre affaire. Mais sachez-le : je ne reviendrai pas chez vous. C'est vous qui me supplierez...", "Je dois avouer que vos jeux de noblesse ne me plaisent pas non plus. Alors adieu...", "Eh bien, allez au diable ! Restez avec vos flagorneurs. C'est trop pour moi, un « héros » !"), LinkRandPhrase("Oui, vous ne m'avez jamais plu : ce n'est pas un navire, c'est une barge de transport. Ils ont monté une pension pour nobles...", "Oui, j'en ai moi-même assez de tels collègues. Inutile même d'aller au carré : rien que des fils à maman, à croire qu'on les a choisis...", "Très bien, capitaine, comme vous voudrez. Mais, Dieu m'est témoin, j'ai la conscience tranquille..."));
			Link.l1 = "Attends. Je ne peux pas laisser le navire sans officier en ce moment. Mais nous reprendrons cette conversation plus tard.";
			Link.l1.go = "exit_bad";
			Link.l2 = "Alors, va avec Dieu.";
			Link.l2.go = "Exit_Fire_1";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l3 = "Ne te fâche pas. J'ai pour toi une indemnité de départ de "+sti(NPChar.rank)*500+" pièces d'or. J'espère que cela réglera toutes les questions.";
				Link.l3.go = "Get_out_А1_ForMoney";
			}
		break;

		case "Get_out_A1_strife":
			dialog.text = LinkRandPhrase("Permettez ! Que veut dire « quitter le navire » ?! Je n'ai pas exposé ma tête à la mitraille pour que vous me jetiez dehors quand bon vous semble !", "Ha ! « Quitter le navire » ! Vous croyez que je vais me laisser jeter dehors comme un chaton ?!", "Doucement, capitaine, ce n'est pas comme ça qu'on règle les choses entre gens sérieux. Je ne me laisserai pas traiter comme un bleu.");
			Link.l1 = "Bon, reste. Mais seulement jusqu'à ce que je trouve un digne remplaçant." ;
			Link.l1.go = "exit_bad";
			Link.l2 = "Je le répète : ton service est terminé. Tu peux faire tes bagages.";
			Link.l2.go = "Get_out_A1_strife_1";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l3 = "Ne te fâche pas. J'ai pour toi une indemnité de départ de "+sti(NPChar.rank)*500+" pièces d'or. J'espère que cela réglera toutes les questions.";
				Link.l3.go = "Get_out_А1_ForMoney";
			}
		break;

		case "Get_out_A1_strife_1":
			dialog.text = RandPhraseSimple("Oui, je n'ai pas très envie de rester avec vous. Mais je ne vais pas quitter le navire sans compensation !", "Oui, maintenant, je ne resterai pas moi-même sur votre baille. Ayez seulement l'obligeance de me payer d'abord une compensation !") + " "+sti(NPChar.rank)*1000+" pièces d'or, et nous nous oublierons l'un l'autre.";
			Link.l1 = "Je me suis emporté... Accepte mes excuses, et retourne à ton poste.";
			Link.l1.go = "exit_bad1";
			Link.l2 = "De quel argent peut-on parler, alors que tu touchais régulièrement ta part ? Tout ça ressemble fort à de l'extorsion !";
			Link.l2.go = "Get_out_А1_strife_battle";
			if (sti(Pchar.money) >= sti(NPChar.rank)*1000)
			{
				Link.l3 = "Bon. Rends l'équipement, et tu auras ce que tu demandes.";
				Link.l3.go = "Get_out_А1_chang";
			}
		break;

		case "Get_out_А1_ForMoney":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*500)));
			ChangeCharacterReputation(pchar, 1);
			dialog.text = "Eh bien, voilà qui est tout autre chose. Adieu !";
			Link.l1 = "J'espère que nos chemins ne se croiseront plus.";
			Link.l1.go = "Exit_Fire_1";
		break;

		case "Get_out_А1_strife_battle":
			dialog.text = LinkRandPhrase("Considérez ça comme une compensation pour le préjudice moral. Je ne laisserai personne me traiter ainsi ! Et celui qui l'osera le regrettera amèrement !", "Ce n'est pas de l'extorsion, mais une compensation pour le temps perdu ! Et je l'obtiendrai, coמte que coמte !", "J'ai passé trop de temps au service d'"+ GetSexPhrase("un chevalier blanc", "une sainte-nitouche") +" comme vous. Pendant ce temps, on aurait pu s'enrichir en pillant les marchands. Maintenant, je veux compenser ce manque à gagner.");
			if (sti(Pchar.money) >= sti(NPChar.rank)*1000)
			{
				Link.l1 = "Bon. Voici ton argent... Maintenant, fiche le camp !";
				Link.l1.go = "Get_out_А1_ForMoney_angry";
			}
			Link.l2 = "Tu t'oublies ! Je ne laisserai aucun imbécile élever la voix contre moi !";
			Link.l2.go = "Get_out_А1_strife_death";
		break;

		case "Get_out_А1_strife_death":
			ChangeCharacterReputation(pchar, 1);
			OfficersReaction("good");
			dialog.text = "Allez, allez, capitaine ! Montrez-moi de quoi vous êtes capable face à un adversaire sérieux !";
			Link.l1 = "Dieu m'est témoin, je ne voulais pas ça !";
			Link.l1.go = "Get_out_fight";
		break;

		case "Get_out_А1_ForMoney_angry":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*1000)));
			ChangeCharacterReputation(pchar, -1);
			OfficersReaction("bad");
			dialog.text = "Eh bien, voilà qui est tout autre chose. Adieu !";
			Link.l1 = "J'espère que nos chemins ne se croiseront plus.";
			Link.l1.go = "Exit_Fire_1";
		break;

		case "Get_out_A2":
			dialog.text = RandPhraseSimple(LinkRandPhrase("Eh bien, ce n'est donc pas le destin. Adieu, capitaine, ne m'en voulez pas trop...", "Dommage, capitaine. Mais, Dieu m'est témoin, j'ai essayé. Adieu.", "Eh bien, capitaine, on ne peut jamais vous contenter !.. Portez-vous bien."), LinkRandPhrase("Dommage, capitaine. J'ai vraiment aimé servir avec vous.", "C'est ainsi que ça se passe... Mais je ne vous en veux pas, adieu.", "Vous êtes injuste envers moi, capitaine. Mais je respecte votre décision. Adieu."));
			if (NPChar.id == "Andreas_Fickler")
			{
				dialog.text = RandPhraseSimple(LinkRandPhrase("Eh bien, ce n'est donc pas le destin. A-a-adieu, c-capitaine, ne m'en voulez pas trop...", "Dommage, c-capitaine. Mais, Dieu m'est témoin, j'ai essayé. A-a-adieu.", "Eh bien, capitaine, on ne peut jamais vous contenter !.. Portez-vous bien."), LinkRandPhrase("Dommage, c-capitaine. J'ai v-vraiment aimé servir avec vous.", "C'est ainsi que ça se passe... M-m-mais je ne vous en veux pas, a-adieu.", "Vous n'êtes pas très gentil avec moi, capitaine. Mais je respecte votre décision. A-adieu."));
			}
			Link.l1 = "Attends, j'ai changé d'avis. Nous reprendrons cette conversation plus tard.";
			Link.l1.go = "exit_good";
			Link.l2 = "Ne t'en fais pas. Bonne chance à toi...";
			Link.l2.go = "exit_fire_2";
			Link.l3 = "Attends... Je t'ai bien équipé. Il faut rendre les affaires : j'ai tout un tas de gens à équiper...";
			Link.l3.go = "Return_items_A2";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l4 = "Attends... Je ne veux pas te laisser partir les mains vides. Prends "+sti(NPChar.rank)*500+" pièces d'or, elles te seront utiles pendant que tu cherches un nouveau travail.";
				Link.l4.go = "Im_kind_A2";
			}
		break;

		case "Return_items_A2":
			ChangeOfficersLoyality("bad_all", 1);
			dialog.text = "Oui, bien sמr, prenez-les...";
			Link.l1 = "Je savais que tu me comprendrais bien...";
			Link.l1.go = "Get_out_А2_chang";
		break;

		case "Im_kind_A2":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*500)));
			ChangeOfficersLoyality("good_all", 1);
			ChangeCharacterReputation(pchar, 1);
			dialog.text = "Merci, capitaine ! Quelle générosité inattendue. Il me reste quelques-unes de vos affaires, voulez-vous que je vous les rende ?";
			Link.l1 = "Oui, je suppose... Ce n'est pas facile de trouver une bonne lame en ce moment...";
			Link.l1.go = "Get_out_А2_chang";
			Link.l2 = "Inutile. Garde-les en souvenir de ton service sous mes ordres...";
			Link.l2.go = "exit_fire_2";
		break;

		case "Get_out_A3_peace":
			dialog.text = RandPhraseSimple(LinkRandPhrase("Eh bien, c'est votre affaire. Mais sachez-le : je ne reviendrai pas chez vous, même si je dois mourir de faim.", "Je dois avouer que vos manières de gangster ne me plaisent pas non plus. Alors, ça devait arriver tכt ou tard... Et inutile d'inventer des raisons.", "Eh bien, restez avec vos coupe-jarrets. Pour une personne convenable, c'est une honte d'entrer au carré de votre navire. Vous en avez fait un bordel, que Dieu me pardonne !"), LinkRandPhrase("Je dois avouer que le cœur n'y est plus pour un tel service, moi non plus. Vous avez recruté des escrocs dans l'équipage : il n'y a personne avec qui échanger un mot gentil.", "Oui, si vous traitez le personnel ainsi, tout le monde vous fuira. Inutile d'inventer des raisons.", "Je me console en pensant que notre antipathie est réciproque. Portez-vous bien."));
			Link.l1 = "Attends. Ce n'est pas le bon moment pour te renvoyer. Mais tous les griefs restent valables.";
			Link.l1.go = "exit_bad";
			Link.l2 = "Va, va. Je me passerai de tes sermons.";
			Link.l2.go = "exit_fire_3";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l3 = "Attends. Je vais te donner "+sti(NPChar.rank)*500+" pièces d'or. Sinon, tu vas crever au pied d'une palissade, et c'est moi qui en répondrai devant Dieu.";
				Link.l3.go = "Get_out_А3_ForMoney";
			}
		break;

		case "Get_out_А3_ForMoney":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*500)));
			ChangeCharacterReputation(pchar, 1);
			ChangeOfficersLoyality("good_all", 1);
			dialog.text = LinkRandPhrase("Merci quand même. Adieu...", "Merci de votre compréhension. Portez-vous bien.", "Maintenant, nous sommes quittes. Bonne journée...");
			Link.l1 = "Je savais que tu me comprendrais bien...";
			Link.l1.go = "exit_fire_3";
		break;

		case "Get_out_A3_strife":
			dialog.text = LinkRandPhrase("Mais, capitaine, dans ce cas, je me retrouve complètement fauché. Vous ne voulez pas m'envoyer du navire directement mendier sur le parvis, n'est-ce pas ?", "Vous êtes injuste envers moi, capitaine. Mais je suis prêt à oublier ma rancune si je reçois une compensation convenable.", "Et c'est comme ça que vous me remerciez pour toutes mes blessures de guerre ? Je pense qu'on ne peut pas se passer d'une compensation en argent.");
			Link.l1 = "Bon, j'ai changé d'avis. Reste pour l'instant, mais nous reprendrons cette conversation plus tard.";
			Link.l1.go = "exit_bad";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l2 = "Eh bien, tu n'as pas à t'en faire pour ça. Voici "+sti(NPChar.rank)*500+" pièces d'or. Je pense que ça suffira pour commencer.";
				Link.l2.go = "Get_out_А3_ForMoney";
				Link.l3 = "Je vais te donner l'argent. Mais c'est grâce à moi que tu es bien équipé : il faut rendre les affaires.";
				Link.l3.go = "Return_items_A3";
			}
			Link.l4 = "דa alors ! Et la part que tu touches régulièrement ?! Je savais que tout finirait en jérémiades et en mendicité.";
			Link.l4.go = "Get_out_A3_strife_1";
		break;

		case "Return_items_A3":
			dialog.text = "Je savais que vous diriez ça, mais vous ne pourrez récupérer l'équipement que quand j'aurai reçu "+sti(NPChar.rank)*1000+" pièces d'or. Ou alors, il faudra me le prendre sur mon cadavre.";
			Link.l1 = "Bon, garde ton argent.";
			Link.l1.go = "Get_out_А3_chang";
			Link.l2 = "Tu as perdu la tête ?! Exiger une telle somme pour ce que je t'ai donné gratuitement ! On dirait qu'un vice aussi bas que la cupidité l'a enfin emporté chez mon prétendu obligé.";
			Link.l2.go = "Get_out_A3_strife_1";
		break;

		case "Get_out_A3_strife_1":
			dialog.text = "Ne vous avisez pas de m'insulter ! Je ne suis peut-être pas le meilleur de la marine, mais je suis quand même un officier de combat. Et je me ferai respecter, même d'un ignorant comme vous !";
			Link.l1 = "Si ce n'est pas encore clair pour toi, je le répète : inutile de mendier, tu n'auras rien de toute façon.";
			Link.l1.go = "Get_out_А3_strife_death";
		break;

		case "Get_out_А3_strife_death":
			ChangeCharacterReputation(pchar, -1);
			OfficersReaction("bad");
			dialog.text = "Eh bien, j'obtiendrai réparation quand même !!";
			Link.l1 = "Oui, c'est un défi ! Eh bien, comme tu voudras...";
			Link.l1.go = "Get_out_fight";
		break;

		case "Get_out_A4":
			dialog.text = RandPhraseSimple(LinkRandPhrase("C'est toujours comme ça ! On donne toute son âme au service, et vlan, dehors, et sans indemnité !", "Qu'est-ce que c'est que cette déveine ?! א peine engagé, on vous flanque un coup de pied au derrière. Je ne sais plus à quel saint me vouer...", "Les voilà bien ! C'est le troisième renvoi de l'année, et tous des lundis. Ne vous montrez jamais à ces capitaines avec la gueule de bois !"), LinkRandPhrase("Bon, d'accord, soit. Seulement, Dieu nous garde de nous revoir.", "Eh bien, c'est votre affaire. Mais sachez-le : vous ne trouverez pas de meilleur officier, de toute façon.", "Très bien, capitaine, comme vous voudrez. Mais, Dieu m'est témoin, j'ai la conscience nette..."));
			Link.l1 = "Attends. Ce n'est pas le bon moment pour te renvoyer. Mais tous les griefs restent valables.";
			Link.l1.go = "exit_good";
			Link.l2 = RandPhraseSimple("File, file. Et remercie Dieu que je sois de bonne humeur aujourd'hui.", "Allez, allez. Officier, tu l'es comme moi je suis évêque.");
			Link.l2.go = "exit_fire_4";
			if (sti(Pchar.money) >= sti(NPChar.rank)*500)
			{
				Link.l3 = "Attends. J'ai pour toi "+sti(NPChar.rank)*500+" pièces d'or. Sinon, tu vas crever au pied d'une palissade, et c'est moi qui en répondrai devant Dieu.";
				Link.l3.go = "Get_out_А4_ForMoney";
			}
			Link.l4 = "Attends... Je t'ai bien équipé. Il faut rendre les affaires.";
			Link.l4.go = "Return_items_A4";
		break;

		case "Get_out_А4_ForMoney":
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*500)));
			ChangeCharacterReputation(pchar, 1);
			ChangeOfficersLoyality("good_all", 1);
			dialog.text = LinkRandPhrase("Merci beaucoup, capitaine ! Voilà qui s'appelle du respect...", "Merci de votre compréhension. Portez-vous bien.", "Maintenant, nous sommes quittes. Bonne journée...");
			Link.l1 = "Bonne journée. Seulement, ne laisse pas tout à la taverne la plus proche.";
			Link.l1.go = "exit_fire_4";
		break;

		case "Return_items_A4":
			if (makeint(Pchar.Rank) > makeint(NPchar.Rank))
			{
				dialog.text = LinkRandPhrase("Et maintenant, vous me prenez aussi mon équipement ! Que le diable emporte tout ça ! Ma parole, je vais devenir pêcheur...", "Je vois que vous avez décidé de me plumer complètement. Eh bien, prenez. Il ne me reste plus qu'à mendier sur le parvis...", "Merci beaucoup ! Voilà qu'on a décidé de me dépouiller, en plus. Oh, quel destin !.. Prenez, que le diable emporte tout ça...");
				Link.l1 = "Allez, allez. Officier, tu l'es comme moi je suis évêque.";
				Link.l1.go = "Get_out_А4_chang_1";
			}
			else
			{
				dialog.text = RandPhraseSimple("Comme vous voudrez, capitaine, mais donnez-moi d'abord "+sti(NPChar.rank)*1000+" pièces d'or. Considérons ça comme une compensation pour le préjudice moral.", "Très bien. La seule chose que je veux obtenir, ce sont "+sti(NPChar.rank)*1000+" pièces d'or en compensation de ce dur service.");
				if (sti(Pchar.money) >= sti(NPChar.rank)*1000)
				{
					Link.l1 = "Quelle canaille ! Bon, garde ton argent.";
					Link.l1.go = "Get_out_А4_chang";
				}
				Link.l2 = "Tu es fou ?! Oser demander autant d'argent pour ce que j'ai payé moi-même !";
				Link.l2.go = "Get_out_A4_strife";
				Link.l3 = "Ah ha ! Je plaisantais ! Comment pourrais-je jeter un vieil ami comme une vieille savate !";
				Link.l3.go = "exit_bad1";
			}
		break;

		case "Get_out_A4_strife":
			ChangeCharacterReputation(pchar, -1);
			ChangeOfficersLoyality("bad_all", 1);
			dialog.text = "Eh bien, alors vous n'aurez rien ! Je ne bougerai pas d'ici avant d'avoir entendu sonner mon or !";
			Link.l1 = RandPhraseSimple("Tu vas plutכt entendre sonner ma lame !", "Alors on t'emportera les pieds devant !");
			Link.l1.go = "Get_out_fight";
		break;

		case "Get_out_fight":
			if(CheckAttribute(Npchar, "HalfImmortal")) DeleteAttribute(Npchar, "HalfImmortal");
			CheckForReleaseOfficer(GetCharacterIndex(Npchar.id));
			RemovePassenger(Pchar, Npchar);
			PGG_ReleaseOfficerFlags(Npchar); // LEO: ПГГ уходит дракой - вернуть его в мир, иначе застрянет с офицерским диалогом
			LAi_CharacterDisableDialog(NPChar);
			LAi_SetWarriorType(Npchar);
			LAi_group_MoveCharacter(Npchar, "TmpEnemy");
			LAi_group_SetHearRadius("TmpEnemy", 100.0);
			LAi_group_FightGroupsEx("TmpEnemy", LAI_GROUP_PLAYER, true, Pchar, -1, false, false);
			Npchar.SaveItemsForDead = true;
			if (PChar.location == Get_My_Cabin() || findsubstr(PChar.location, "_tavern" , 0) != -1 || findsubstr(PChar.location, "_store" , 0) != -1)
            {
				LAi_LocationFightDisable(&Locations[FindLocation(pchar.location)], false);
				LAi_group_SetCheck("TmpEnemy", "CannotFightCurLocation");
				LAi_group_SetCheck("TmpEnemy", "MainHeroFightModeOff");
            }
			DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

	    case "Get_out_А1_chang": // интерфейс обмена
			Diag.TempNode = "Fired_1";
			LAi_CharacterDisableDialog(NPChar);
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*1000)));
			ChangeCharacterReputation(pchar, -1);
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.rank = 0;
			DialogExit();
			LaunchCharacterItemChange(npchar);
			RemovePassenger(Pchar, npchar);
		break;

		case "Get_out_А2_chang": // интерфейс обмена
			Diag.TempNode = "Fired_2";
			LAi_CharacterDisableDialog(NPChar);
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.rank = 0;
			DialogExit();
			LaunchCharacterItemChange(npchar);
			RemovePassenger(Pchar, npchar);
		break;

		case "Get_out_А3_chang": // интерфейс обмена
			Diag.TempNode = "Fired_3";
			LAi_CharacterDisableDialog(NPChar);
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*1000)));
			ChangeCharacterReputation(pchar, 1);
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.rank = 0;
			DialogExit();
			LaunchCharacterItemChange(npchar);
			RemovePassenger(Pchar, npchar);
		break;

		case "Get_out_А4_chang_1": // интерфейс обмена
			Diag.TempNode = "Fired_4";
			LAi_CharacterDisableDialog(NPChar);
			ChangeCharacterReputation(pchar, -1);
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.rank = 0;
			DialogExit();
			LaunchCharacterItemChange(npchar);
			RemovePassenger(Pchar, npchar);
		break;

		case "Get_out_А4_chang": // интерфейс обмена
			Diag.TempNode = "Fired_4";
			LAi_CharacterDisableDialog(NPChar);
			AddMoneyToCharacter(Pchar, -(makeint(sti(NPChar.rank)*1000)));
			ChangeCharacterReputation(pchar, 1);
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			NPChar.rank = 0;
			DialogExit();
			LaunchCharacterItemChange(npchar);
			RemovePassenger(Pchar, npchar);
		break;

	    case "exit_bad":
			Npchar.loyality = makeint(Npchar.loyality) - 3;
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_bad1":
			Npchar.loyality = makeint(Npchar.loyality) - 2;
			ChangeOfficersLoyality("bad_all", 1);
			ChangeCharacterReputation(pchar, -1);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_good":
			Npchar.loyality = makeint(Npchar.loyality) - 1;
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire_1":	//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}	//navy <--
			Diag.TempNode = "Fired_1";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire_2":	//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}	//navy <--
			Diag.TempNode = "Fired_2";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire_3":	//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}	//navy <--
			Diag.TempNode = "Fired_3";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire_4":	//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}	//navy <--
			Diag.TempNode = "Fired_4";
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar);
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "exit_fire_5":	//navy -->
			if (CheckAttribute(NPChar, "PGGAi"))
			{
				pchar.questTemp.FiringOfficerIDX = NPChar.index;
				AddDialogExitQuestFunction("PGG_FireOfficer");
				DialogExit();
				break;
			}	//navy <--
			Diag.TempNode = "Fired_1";
			OfficersReaction("good");
			Pchar.questTemp.FiringOfficerIDX = GetCharacterIndex(Npchar.id);
			AddDialogExitQuestFunction("LandEnc_OfficerFired");
			FireImmortalOfficer(npchar)
			Diag.CurrentNode = Diag.TempNode;
			NPChar.quest.meeting = true;
			DialogExit();
		break;

		case "Fired_1":
			Diag.TempNode = "Fired_1";
			dialog.text = "Eh bien, quoi encore ? Il me semble que nous avons déjà tout réglé ! Je ne remettrai plus jamais les pieds sur votre navire.";
			Link.l1 = RandPhraseSimple("Va, va. La perte est mince.", "Va, va. Je ne te retiens pas.");
			Link.l1.go = "Exit";
		break;

		case "Fired_2":
			Diag.TempNode = "Fired_2";
			dialog.text = "Y a-t-il autre chose, capitaine ? Il me semblait que nous avions déjà tout réglé...";
			Link.l1 = "Non, rien. Je voulais juste te dire adieu...";
			Link.l1.go = "Exit";
		break;

		case "Fired_3":
			Diag.TempNode = "Fired_3";
			dialog.text = "Capitaine, toutes les questions sont réglées, les griefs sont exprimés. Vous ne voulez pas dire que vous avez changé d'avis après tout ça.";
			Link.l1 = "Va, va. La perte est mince.";
			Link.l1.go = "Exit";
		break;

		case "Fired_4":
			Diag.TempNode = "Fired_4";
			dialog.text = "Capitaine, quelles autres questions peut-il y avoir ? א vrai dire, je suis très fâché contre vous, et je n'ai aucune envie de revenir...";
			Link.l1 = "Va, va. Comme si j'avais tellement besoin de toi : tu ne fais que salir le pont.";
			Link.l1.go = "Exit";
		break;
        // boal 05.09.03 offecer need to go to abordage -->
	    case "Boal_Stay":
            Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(Npchar.id);
            AddDialogExitQuestFunction("LandEnc_OfficerStay");
		    Diag.TempNode = "Hired";
		    dialog.text = "א vos ordres, capitaine !";
		    Link.l1 = "Repos.";
		    Link.l1.go = "Exit";
		    Npchar.chr_ai.tmpl = LAI_TMPL_STAY;
			if (NPChar.sex == "skeleton" && PChar.sex == "skeleton")
			{
				dialog.text = "J'obéis, j'obéis, mon seigneur !";
			}
	    break;
	    case "Boal_Follow":
		    SetCharacterTask_FollowCharacter(Npchar, PChar); // it works here!!!
		    Diag.TempNode = "Hired";
		    dialog.text = "א vos ordres, capitaine !";
		    Link.l1 = "Repos.";
		    Link.l1.go = "Exit";
			if (NPChar.sex == "skeleton" && PChar.sex == "skeleton")
			{
				dialog.text = "J'obéis, j'obéis, mon seigneur !";
			}
	    break;
        // boal 05.09.03 offecer need to go to abordage <--

		//////////////////////////////    офицер-наместник -->
		case "Gover_Hire":
            dialog.Text = "Ce serait un honneur !";
            Link.l1 = "Veillez à l'ordre et à la prospérité de la ville ; je viendrai de temps en temps percevoir le tribut.";
			Link.l1.go = "Exit_Gover_Hire";
            Link.l2 = "J'ai changé d'avis.";
            Link.l2.go = "Exit";
            Diag.TempNode = "Hired";
        break;

        case "Exit_Gover_Hire":
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            attr = sld.id + "_townhall";

            // снимем пассажира -->
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			// снимем пассажира <--
		    sld.OfficerIdx = sti(NPChar.index);
			ChangeCharacterAddressGroup(NPChar, attr, "sit", "sit1");
			LAi_SetHuberTypeNoGroup(NPChar);
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
            LAi_LoginInCaptureTown(NPChar, true);
			//  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_1");
			AddQuestUserData("Gen_CityCapture", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
			Diag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Main":
            iTemp = GetNpcQuestPastDayParam(NPChar, "GoverTalkDate");
            if (iTemp > 0)
            {
				dialog.Text = "Quels sont vos ordres ? Votre dernière visite remonte à " + FindRussianDaysString(iTemp) + " déjà.";
			}
			else
			{
			    dialog.Text = "Quels sont vos ordres ?";
			}

            Link.l1 = "Combien d'impכts avez-vous perçus ?";
        	Link.l1.go = "Gover_Tax";
            Link.l8 = "On a besoin de vous sur le navire, je vous relève de vos fonctions en ville.";
            Link.l8.go = "Gover_Fire";
			Link.l9 = "Bonne journée.";
            Link.l9.go = "Exit";
            Diag.TempNode = "Gover_Main";
            SaveCurrentNpcQuestDateParam(NPChar, "GoverTalkDate");
        break;

        case "Gover_Tax":
            iTemp = GetNpcQuestPastDayParam(NPChar, "StartTaxDate");
            iTax  = makeint((GetCharacterSkillSimple(NPChar, SKILL_COMMERCE) + GetCharacterSkillSimple(NPChar, SKILL_LEADERSHIP)) / 2);
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
			if (CheckAttribute(sld, "FortValue"))
			{
			    iFortValue = sti(sld.FortValue);
			}
			else
			{
			    iFortValue = 20;
			}
			NPChar.Gover_Tax_Sum = iFortValue*iTax*iTemp;
			dialog.Text = "Mes compétences me permettent de percevoir " + FindRussianMoneyString(iFortValue*iTax) + " par jour. En " + FindRussianDaysString(iTemp) + " j'ai perçu " + FindRussianMoneyString(sti(NPChar.Gover_Tax_Sum)) + ".";
			if (sti(NPChar.Gover_Tax_Sum) > 0)
			{
			    Link.l1 = "Je veux percevoir la totalité des impכts.";
            	Link.l1.go = "Gover_Tax_Get";
			}
			Link.l2 = "Merci pour vos services !";
            Link.l2.go = "Exit";
        break;

        case "Gover_Tax_Get":
            SaveCurrentNpcQuestDateParam(NPChar, "StartTaxDate");
            AddMoneyToCharacter(Pchar, sti(NPChar.Gover_Tax_Sum));

			Diag.CurrentNode = "Gover_Main";
            DialogExit();
        break;

        case "Gover_Fire":
            dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
            Link.l8 = "Voilà qui est bien.";
            Link.l8.go = "exit_hire";
			npchar.norespec = true;
            Diag.TempNode = "Hired";
            sld = GetColonyByIndex(sti(NPChar.ColonyIdx));
            DeleteAttribute(sld, "OfficerIdx");
            //  СЖ -->
			ReOpenQuestHeader("Gen_CityCapture");
            AddQuestRecord("Gen_CityCapture", "t3_2");
			AddQuestUserData("Gen_CityCapture", "sCity", XI_ConvertString("colony" + sld.id));
			AddQuestUserData("Gen_CityCapture", "sName", GetFullName(NPChar));
			//  СЖ <--
        break;
        //////////////////////////////    офицер-наместник <--

		//Указания для компаньона 19.02.08 -->
		// LEO: компаньон в рейсе по нашему поручению - команды/торговля/возврат недоступны, пока не вернётся.
		case "CompanionTravel_OnMission":
			dialog.Text = "Je suis en mission pour vous, capitaine, et je ne peux pas quitter mon cap. Dès que j'aurai terminé la tâche et rejoint l'escadre, je serai de nouveau prêt à recevoir des ordres.";
			int iCTom = GetCharacterIndex(NPChar.id);
			if (CheckAttribute(NPChar, "realcompanionidx")) iCTom = sti(NPChar.realcompanionidx);
			if (iCTom >= 0 && CheckAttribute(&characters[iCTom], "CompanionTravel.OutfitTravel"))
				dialog.Text = "Je pars équiper un navire, capitaine : j'en choisirai un au chantier naval, je recruterai un équipage, je ferai des provisions et je vous rattraperai. Dès que j'aurai fini, je serai à votre service.";
			Link.l1 = "Bien. Bon vent.";
			Link.l1.go = "exit";
		break;

		// LEO: сбор компаньона в таверне после коммерческого рейса - выручка + офицером в каюту (CollectFromTavern)
		case "CompanionCommerce_Collect":
			if (FindFreeRandomOfficer() <= 0) // LEO: нет свободного места под офицера в каюте - не берём с перебором
			{
				dialog.Text = "Capitaine, mais oם me mettriez-vous ? La cabine est déjà pleine : il n'y a pas de place pour une âme de plus. Libérez une place, et je reprendrai du service : j'attendrai ici.";
				Link.l1 = "C'est vrai. Je reviendrai te chercher plus tard.";
				Link.l1.go = "exit";
				break;
			}
			int iPrCT;
			iPrCT = 0;
			if (CheckAttribute(NPChar, "CompanionTravel.Proceeds")) iPrCT = sti(NPChar.CompanionTravel.Proceeds);
			string sOpCT;
			sOpCT = "sell";
			if (CheckAttribute(NPChar, "CompanionTravel.CommerceOp")) sOpCT = NPChar.CompanionTravel.CommerceOp;
			if (sOpCT == "auction")
				dialog.Text = "Capitaine ! Le navire est mis aux enchères à la capitainerie : vous toucherez le produit de la coque auprès du capitaine du port une fois qu'il sera vendu. Et voici ce que j'ai obtenu pour la cargaison et les canons : " + FindRussianMoneyString(iPrCT) + ". Prêt à reprendre du service.";
			else if (sOpCT == "store")
				dialog.Text = "Capitaine ! Le navire est en dépכt à la capitainerie, sous la garde d'un veilleur : récupérez-le là-bas quand vous en aurez besoin. Prêt à reprendre du service.";
			else
				dialog.Text = "Capitaine ! C'est fait, le navire est vendu. Voici tout le produit de la vente : " + FindRussianMoneyString(iPrCT) + ". Prêt à reprendre du service.";
			Link.l1 = "Beau travail. Viens avec moi.";
			Link.l1.go = "CompanionCommerce_Collect_Done";
		break;

		case "CompanionCommerce_Collect_Done":
			CompanionTravel_CollectFromTavern(NPChar);
			dialog.Text = "א vos ordres, capitaine ! Content de reprendre du service.";
			Link.l1 = "...";
			Link.l1.go = "exit";
		break;

		case "Companion_Tasks":
			// LEO: если этот компаньон уже в рейсе по поручению - команды недоступны (кают-компания = клон,
			//   реальный через realcompanionidx). Пока в пути (OutboundLive/Meeting) - только "на задании".
			int iCTr2 = GetCharacterIndex(NPChar.id);
			if (CheckAttribute(NPChar, "realcompanionidx")) iCTr2 = sti(NPChar.realcompanionidx);
			if (iCTr2 >= 0)
			{
				if (CheckAttribute(&characters[iCTr2], "CompanionTravel.OutboundLive") || CheckAttribute(&characters[iCTr2], "CompanionTravel.Meeting") || CheckAttribute(&characters[iCTr2], "CompanionTravel.OutfitTravel"))
				{
					dialog.Text = "Je suis en mission pour vous, capitaine, et je ne peux pas quitter mon cap. Dès que j'aurai terminé la tâche et rejoint l'escadre, je serai de nouveau prêt à recevoir des ordres.";
					if (CheckAttribute(&characters[iCTr2], "CompanionTravel.OutfitTravel"))
						dialog.Text = "Je pars équiper un navire, capitaine : j'en choisirai un au chantier naval, je recruterai un équipage, je ferai des provisions et je vous rattraperai. Dès que j'aurai fini, je serai à votre service.";
					Link.l1 = "Bien. Bon vent.";
					Link.l1.go = "exit";
					break;
				}
			}
			// LEO: перед выбором задачи чистим стейл-маркеры прошлого (возможно отменённого) рейса - иначе рейс
			//   "жди на рейде" (Task не ставит) унаследовал бы Task="commerce"/"storage" и на прибытии ошибочно
			//   ликвидировал бы корабль / полез в склад. Коммерция/склад заново ставят свой Task в префиксе.
			if (iCTr2 >= 0)
			{
				DeleteAttribute(&characters[iCTr2], "CompanionTravel.Task");
				DeleteAttribute(&characters[iCTr2], "CompanionTravel.CommerceOp");
				DeleteAttribute(&characters[iCTr2], "CompanionTravel.StoreMode");
				DeleteAttribute(&characters[iCTr2], "CompanionTravel.Return");
			}
			dialog.Text = "Je vous écoute attentivement.";
			Link.l1 = "Il s'agit de l'abordage.";
			Link.l1.go = "Companion_TaskBoarding";
			Link.l2 = "Il s'agit de votre navire.";
			Link.l2.go = "Companion_TaskChange";
			// LEO: самостоятельные рейсы (вольное плавание / склад / коммерция / торговля) - только при свободном слоте:
			//   их всего 3 (SetTraveller). Заняты тремя капитанами - внятно отказываем (иначе рейс сломался бы).
			if (CompanionTravel_HasFreeSlot())
			{
			    Link.l3 = "Je veux que vous quittiez mon escadre pour un temps et que vous naviguiez par vos propres moyens.";
			    Link.l3.go = "CompanionTravel";
			    Link.l4 = "J'ai besoin que tu transportes une cargaison jusqu'à notre entrepכt.";
			    Link.l4.go = "Travel_Storage";
			    // LEO: рейс ОТЧУЖДАЕТ корабль (CommerceOp: продать на верфи / на торги / на стоянку) мимо
			    //   расчёта с хозяином, а у конкурента-компаньона судно своё. Склад выше - перетарка ГРУЗА.
			    if (!PGG_IsCompanionOwnShip(NPChar))
			    {
			        Link.l5 = "Emmène ton navire dans une ville.";
			        Link.l5.go = "Travel_Commerce";
			    }
			    // закупка в городе - только если есть казначей (он выдаст деньги). Нет казначея - пункт скрыт.
			    if (IsPCharHaveTreasurer())
			    {
			    	Link.l6 = "Emmène ton navire dans une ville pour faire du commerce.";
			    	Link.l6.go = "Travel_Buy";
			    }
			    // сбор выручки с торгов - только если где-то реально есть накопленная выручка
			    if (CompanionTravel_HasAuctionMoney())
			    {
			    	Link.l7 = "Récupère les recettes de nos ventes aux enchères.";
			    	Link.l7.go = "Auction_Collect";
			    }
			}
			else
			{
			    dialog.Text = "Je vous écoute, cap'taine. Mais notez bien : trois capitaines sont déjà partis de leur cכté. Attendez que l'un d'eux revienne avant d'en envoyer un autre.";
			}
			Link.l8 = "Rien pour l'instant.";
			Link.l8.go = "exit";
		break;

		// LEO: сбор выручки с торгов - объезд городов маршрутом ближайшего соседа, деньги при встрече
		case "Auction_Collect":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cnAu;
				cnAu = GetCompanionIndex(PChar, i);
				if (cnAu == -1) continue;
				if (NPChar.name == characters[cnAu].name) NPChar.realcompanionidx = &characters[cnAu].index;
			}
			dialog.Text = "Je ferai la tournée de nos ventes aux enchères, je récupérerai toutes les recettes et je les rapporterai. Quel est l'ordre, cap'taine ?";
			Link.l1 = "Récupère tout et reviens me trouver avec l'argent.";
			Link.l1.go = "Auction_Go_Return";
			Link.l3 = "Récupère tout et attends-moi au large de la dernière ville.";
			Link.l3.go = "Auction_Go_Wait";
			Link.l8 = "Laisse tomber.";
			Link.l8.go = "exit";
		break;

		case "Auction_Go_Return":
			Diag.CurrentNode = "CompanionTravel_LastNode";
			NPChar.quest.meeting = true;
			CompanionTravel_StartAuctionRun(NPChar, true);
			DialogExit();
		break;

		case "Auction_Go_Wait":
			Diag.CurrentNode = "CompanionTravel_LastNode";
			NPChar.quest.meeting = true;
			CompanionTravel_StartAuctionRun(NPChar, false);
			DialogExit();
		break;

		// LEO: снаряжение офицера кораблём - выбор класса (авто-смета, показываем доступные по деньгам ГГ)
		case "OfficerOutfit_Start":
			dialog.text = "Quel genre de navire dois-je prendre, capitaine ? J'en choisirai un au chantier naval, je recruterai un équipage, je ferai des provisions et je vous rattraperai en mer. Donnez-moi un peu plus, et je vous rendrai le reste.";
			Link.l1 = "Un navire de guerre.";
			Link.l1.go = "OfficerOutfit_TWar";
			Link.l2 = "Un navire marchand.";
			Link.l2.go = "OfficerOutfit_TTrade";
			Link.l3 = "N'importe lequel fera l'affaire.";
			Link.l3.go = "OfficerOutfit_TAny";
			Link.l0 = "Laisse tomber.";
			Link.l0.go = "exit";
		break;

		case "OfficerOutfit_TWar":
			PChar.questTemp.OutfitType = "war";
			dialog.text = "Un navire de guerre, compris. De quelle classe, capitaine ?";
			int iRankW = sti(NPChar.rank);
			bool bAnyW = false;
			int iEstW;
			iEstW = CompanionTravel_EstimateOutfitBudget(6, "war");
			if (iEstW > 0 && iRankW >= CompanionTravel_ClassMinRank(6)) { Link.l6 = "Classe 6 (" + FindRussianMoneyStringClrMinus(iEstW, "\3") + ")"; Link.l6.go = "OfficerOutfit_Go6"; bAnyW = true; }
			iEstW = CompanionTravel_EstimateOutfitBudget(5, "war");
			if (iEstW > 0 && iRankW >= CompanionTravel_ClassMinRank(5)) { Link.l5 = "Classe 5 (" + FindRussianMoneyStringClrMinus(iEstW, "\3") + ")"; Link.l5.go = "OfficerOutfit_Go5"; bAnyW = true; }
			iEstW = CompanionTravel_EstimateOutfitBudget(4, "war");
			if (iEstW > 0 && iRankW >= CompanionTravel_ClassMinRank(4)) { Link.l4 = "Classe 4 (" + FindRussianMoneyStringClrMinus(iEstW, "\3") + ")"; Link.l4.go = "OfficerOutfit_Go4"; bAnyW = true; }
			iEstW = CompanionTravel_EstimateOutfitBudget(3, "war");
			if (iEstW > 0 && iRankW >= CompanionTravel_ClassMinRank(3)) { Link.l3 = "Classe 3 (" + FindRussianMoneyStringClrMinus(iEstW, "\3") + ")"; Link.l3.go = "OfficerOutfit_Go3"; bAnyW = true; }
			iEstW = CompanionTravel_EstimateOutfitBudget(2, "war");
			if (iEstW > 0 && iRankW >= CompanionTravel_ClassMinRank(2)) { Link.l2 = "Classe 2 (" + FindRussianMoneyStringClrMinus(iEstW, "\3") + ")"; Link.l2.go = "OfficerOutfit_Go2"; bAnyW = true; }
			if (!bAnyW) dialog.text = "Un tel navire de guerre est encore hors de notre portée, capitaine : soit le grade, soit les caisses.";
			Link.l0 = "Retour.";
			Link.l0.go = "OfficerOutfit_Start";
		break;

		case "OfficerOutfit_TTrade":
			PChar.questTemp.OutfitType = "merchant";
			dialog.text = "Un navire marchand, compris. De quelle classe, capitaine ?";
			int iRankT = sti(NPChar.rank);
			bool bAnyT = false;
			int iEstT;
			iEstT = CompanionTravel_EstimateOutfitBudget(6, "merchant");
			if (iEstT > 0 && iRankT >= CompanionTravel_ClassMinRank(6)) { Link.l6 = "Classe 6 (" + FindRussianMoneyStringClrMinus(iEstT, "\3") + ")"; Link.l6.go = "OfficerOutfit_Go6"; bAnyT = true; }
			iEstT = CompanionTravel_EstimateOutfitBudget(5, "merchant");
			if (iEstT > 0 && iRankT >= CompanionTravel_ClassMinRank(5)) { Link.l5 = "Classe 5 (" + FindRussianMoneyStringClrMinus(iEstT, "\3") + ")"; Link.l5.go = "OfficerOutfit_Go5"; bAnyT = true; }
			iEstT = CompanionTravel_EstimateOutfitBudget(4, "merchant");
			if (iEstT > 0 && iRankT >= CompanionTravel_ClassMinRank(4)) { Link.l4 = "Classe 4 (" + FindRussianMoneyStringClrMinus(iEstT, "\3") + ")"; Link.l4.go = "OfficerOutfit_Go4"; bAnyT = true; }
			iEstT = CompanionTravel_EstimateOutfitBudget(3, "merchant");
			if (iEstT > 0 && iRankT >= CompanionTravel_ClassMinRank(3)) { Link.l3 = "Classe 3 (" + FindRussianMoneyStringClrMinus(iEstT, "\3") + ")"; Link.l3.go = "OfficerOutfit_Go3"; bAnyT = true; }
			iEstT = CompanionTravel_EstimateOutfitBudget(2, "merchant");
			if (iEstT > 0 && iRankT >= CompanionTravel_ClassMinRank(2)) { Link.l2 = "Classe 2 (" + FindRussianMoneyStringClrMinus(iEstT, "\3") + ")"; Link.l2.go = "OfficerOutfit_Go2"; bAnyT = true; }
			if (!bAnyT) dialog.text = "Un tel navire marchand est encore hors de notre portée, capitaine : soit le grade, soit les caisses.";
			Link.l0 = "Retour.";
			Link.l0.go = "OfficerOutfit_Start";
		break;

		case "OfficerOutfit_TAny":
			PChar.questTemp.OutfitType = "";
			dialog.text = "N'importe lequel, compris. De quelle classe, capitaine ?";
			int iRankA = sti(NPChar.rank);
			bool bAnyA = false;
			int iEstA;
			iEstA = CompanionTravel_EstimateOutfitBudget(6, "");
			if (iEstA > 0 && iRankA >= CompanionTravel_ClassMinRank(6)) { Link.l6 = "Classe 6 (" + FindRussianMoneyStringClrMinus(iEstA, "\3") + ")"; Link.l6.go = "OfficerOutfit_Go6"; bAnyA = true; }
			iEstA = CompanionTravel_EstimateOutfitBudget(5, "");
			if (iEstA > 0 && iRankA >= CompanionTravel_ClassMinRank(5)) { Link.l5 = "Classe 5 (" + FindRussianMoneyStringClrMinus(iEstA, "\3") + ")"; Link.l5.go = "OfficerOutfit_Go5"; bAnyA = true; }
			iEstA = CompanionTravel_EstimateOutfitBudget(4, "");
			if (iEstA > 0 && iRankA >= CompanionTravel_ClassMinRank(4)) { Link.l4 = "Classe 4 (" + FindRussianMoneyStringClrMinus(iEstA, "\3") + ")"; Link.l4.go = "OfficerOutfit_Go4"; bAnyA = true; }
			iEstA = CompanionTravel_EstimateOutfitBudget(3, "");
			if (iEstA > 0 && iRankA >= CompanionTravel_ClassMinRank(3)) { Link.l3 = "Classe 3 (" + FindRussianMoneyStringClrMinus(iEstA, "\3") + ")"; Link.l3.go = "OfficerOutfit_Go3"; bAnyA = true; }
			iEstA = CompanionTravel_EstimateOutfitBudget(2, "");
			if (iEstA > 0 && iRankA >= CompanionTravel_ClassMinRank(2)) { Link.l2 = "Classe 2 (" + FindRussianMoneyStringClrMinus(iEstA, "\3") + ")"; Link.l2.go = "OfficerOutfit_Go2"; bAnyA = true; }
			if (!bAnyA) dialog.text = "C'est encore hors de notre portée, capitaine : soit le grade, soit les caisses.";
			Link.l0 = "Retour.";
			Link.l0.go = "OfficerOutfit_Start";
		break;

		case "OfficerOutfit_Go6":
			Diag.CurrentNode = "CompanionTravel_OnMission";
			CompanionTravel_DispatchOutfit(NPChar, 6, PChar.questTemp.OutfitType);
			DialogExit();
		break;
		case "OfficerOutfit_Go5":
			Diag.CurrentNode = "CompanionTravel_OnMission";
			CompanionTravel_DispatchOutfit(NPChar, 5, PChar.questTemp.OutfitType);
			DialogExit();
		break;
		case "OfficerOutfit_Go4":
			Diag.CurrentNode = "CompanionTravel_OnMission";
			CompanionTravel_DispatchOutfit(NPChar, 4, PChar.questTemp.OutfitType);
			DialogExit();
		break;
		case "OfficerOutfit_Go3":
			Diag.CurrentNode = "CompanionTravel_OnMission";
			CompanionTravel_DispatchOutfit(NPChar, 3, PChar.questTemp.OutfitType);
			DialogExit();
		break;
		case "OfficerOutfit_Go2":
			Diag.CurrentNode = "CompanionTravel_OnMission";
			CompanionTravel_DispatchOutfit(NPChar, 2, PChar.questTemp.OutfitType);
			DialogExit();
		break;

		case "Companion_TaskBoarding":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je veux que vous n'abordiez pas les navires ennemis. Prenez soin de vous et de votre équipage.";
			Link.l1.go = "Companion_TaskBoardingNo";
			Link.l2 = "J'ai besoin que vous abordiez les navires ennemis.";
			Link.l2.go = "Companion_TaskBoardingYes";
		break;

		case "Companion_TaskChange":
			dialog.Text = "Que voulez-vous ?";
			Link.l1 = "Je ne veux pas que vous changiez de navire après un abordage. Il a trop de valeur.";
			Link.l1.go = "Companion_TaskChangeNo";
			Link.l2 = "Quand vous abordez vos ennemis, regardez s'il y a un bateau convenable, et prenez-le pour vous.";
			Link.l2.go = "Companion_TaskChangeYes";
		break;

		case "Companion_TaskBoardingNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = false;
		break;

		case "Companion_TaskBoardingYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanBoarding = true;
		break;

		case "Companion_TaskChangeNo":
			dialog.Text = "C'est exact.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = false;
		break;

		case "Companion_TaskChangeYes":
			dialog.Text = "Ce sera fait.";
			Link.l1 = "Repos.";
			Link.l1.go = "exit";
			NPChar.Tasks.CanChangeShipAfterBoarding = true;
		break;
		//<--

		// Самостоятельное плавание компаньона -->
		case "CompanionTravel":
			if (AICapturedTrap_IsCompanionShipInfected(NPChar)) // LEO: with a plague aboard we don't send the ship off on its own (epidemic loophole)
			{
				dialog.Text = "Capitaine, pour l'amour de Dieu ! Il y a la peste à bord : les marins tombent les uns après les autres. Je ne peux pas partir seul maintenant : le premier port ne nous laissera pas approcher à portée de canon, et en haute mer, nous périrons tous. Attendons que la maladie passe.";
				Link.l1 = "Tu as raison. Attendons d'abord que la maladie passe.";
				Link.l1.go = "exit";
				break;
			}
			if(GetAttrValue(PChar, "CompanionTravel") == 3) // Если уже троих отпустил
			{
				dialog.Text = "Capitaine, je ne quitterai pas votre escadre, puisque vous avez déjà détaché trois navires.";
					Link.l1 = "Oui, je suppose que tu as raison.";
					Link.l1.go = "exit";
				break;
			}

			dialog.Text = "Pas de problème, cap'taine. Oם dois-je aller ?";
			Link.l1 = "Va à la ville...";
			Link.l1.go = "Travel_Towns";

			Link.l2 = "Va au repaire pirate...";
			Link.l2.go = "TravelToPiratesTowns";

			Link.l3 = "Va sur une île déserte...";
			Link.l3.go = "TravelToNomanIslands";

			Link.l99 = "J'ai changé d'avis. Rien du tout.";
			Link.l99.go = "exit";
		break;

		// LEO: список только тех городов, где у нас арендован склад
		case "Travel_Storage":
			if (!CompanionTravel_HasAnyStorage())
			{
				dialog.Text = "Mais nous n'avons d'entrepכt nulle part, cap'taine. Il faut d'abord conclure un contrat de location avec un marchand : ensuite, je transporterai la marchandise.";
				Link.l1 = "C'est vrai. Je vais m'en occuper.";
				Link.l1.go = "exit";
				break;
			}
			dialog.Text = "Vers quel entrepכt dois-je cingler, capitaine ?";
			for(iTemp=0; iTemp<MAX_COLONIES; iTemp++)
			{
				sld = &colonies[iTemp];
				attr = sld.ID;
				if(sld.nation == "none" || attr == "Panama") continue;
				if(!CompanionTravel_HasStorage(attr)) continue;
				attrLoc = "l" + iTemp;
				NPChar.Temp.(attr) = attr;
				Link.(attrLoc) = "Vers " + XI_ConvertString(CompanionTravel_ColonyTextId(attr, "Voc"));
				if (IsColonyEnemyToMainCharacter(attr))
				{
					Link.(attrLoc).go = "CompanionTravel_EnemyColony";
					continue;
				}
				Link.(attrLoc).go = "CompanionTravelToStorage_" + attr;
			}
			Link.l99 = "J'ai changé d'avis. Rien du tout.";
			Link.l99.go = "exit";
		break;

		// LEO: коммерческий рейс - город, куда компаньон свезёт свой корабль на продажу/торги (штатные города)
		case "Travel_Commerce":
			dialog.Text = "Dans quelle ville dois-je emmener le navire, capitaine ?";
			for(iTemp=0; iTemp<MAX_COLONIES; iTemp++)
			{
				sld = &colonies[iTemp];
				attr = sld.ID;
				if(sld.nation == "none" || attr == "Panama") continue;
				// LEO: пиратские города берём, ТОЛЬКО если у них есть порт-управление (портман) - все коммерческие
				//   операции требуют его. Шарп-Таун (Pirates) имеет ПУ+верфь, прочие пиратские поселения - нет.
				if(sld.nation == PIRATE && GetCharacterIndex(attr + "_PortMan") < 0) continue;
				attrLoc = "l" + iTemp;
				NPChar.Temp.(attr) = attr;
				Link.(attrLoc) = "Vers " + XI_ConvertString("Colony" + attr + "Acc");
				if (IsColonyEnemyToMainCharacter(attr))
				{
					Link.(attrLoc).go = "CompanionTravel_EnemyColony";
					continue;
				}
				Link.(attrLoc).go = "CompanionTravelToCommerce_" + attr;
			}
			Link.l99 = "J'ai changé d'avis. Laisse tomber.";
			Link.l99.go = "exit";
		break;

		// LEO: закупочный рейс - города с магазином (стор глобален, закупка доступна удалённо). Панама/необитайки - мимо.
		case "Travel_Buy":
			dialog.Text = "Dans quelle ville dois-je faire du commerce, capitaine ?";
			for(iTemp=0; iTemp<MAX_COLONIES; iTemp++)
			{
				sld = &colonies[iTemp];
				attr = sld.ID;
				if(sld.nation == "none" || attr == "Panama") continue;
				if(!CheckAttribute(&colonies[iTemp], "StoreNum")) continue; // нет магазина - закупаться негде (у пиратов свой StoreNum, FindStore их не матчит)
				attrLoc = "l" + iTemp;
				NPChar.Temp.(attr) = attr;
				Link.(attrLoc) = "א " + XI_ConvertString("Colony" + attr + "Voc");
				if (IsColonyEnemyToMainCharacter(attr))
				{
					Link.(attrLoc).go = "CompanionTravel_EnemyColony";
					continue;
				}
				Link.(attrLoc).go = "CompanionTravelToBuy_" + attr;
			}
			Link.l99 = "J'ai changé d'avis. Laisse tomber.";
			Link.l99.go = "exit";
		break;

		case "Travel_Towns":
			dialog.Text = "Oם sera le lieu de rendez-vous, capitaine ?";
			for(iTemp=0; iTemp<MAX_COLONIES; iTemp++)
			{
				sld = &colonies[iTemp];
				attr = sld.ID;
				if(sld.nation == "none" || sld.nation == PIRATE || attr == "Panama") continue;
				attrLoc = "l" + iTemp;
				NPChar.Temp.(attr) = attr;
				Link.(attrLoc) = "א " + XI_ConvertString("Colony" + attr + "Voc");
				if (IsColonyEnemyToMainCharacter(attr)) {
					Link.(attrLoc).go = "CompanionTravel_EnemyColony";
					continue;
				}
				Link.(attrLoc).go = "CompanionTravelToColony_" + attr;
			}
			Link.l99 = "J'ai changé d'avis. Rien du tout.";
			Link.l99.go = "exit";
		break;

		case "TravelToPiratesTowns":
			dialog.Text = "Lequel exactement ?";
				Link.l1 = "Repaire pirate";
				Link.l1.go = "TravelToPirates";
				Link.l2 = "Le François";
				Link.l2.go = "TravelToLeFransua";
				Link.l3 = "La Vega";
				Link.l3.go = "TravelToLaVega";
				Link.l4 = "Puerto Príncipe";
				Link.l4.go = "TravelToPuertoPrincipe";
				Link.l6 = "Tu sais, reste pour l'instant, j'ai changé d'avis.";
				Link.l6.go = "exit";
		break;
		case "TravelToNomanIslands":
			dialog.Text = "Lequel exactement ?";
				Link.l1 = "Caïmans";
				Link.l1.go = "TravelToCaiman";
				Link.l2 = "Dominica";
				Link.l2.go = "TravelToDominica";
				Link.l3 = "טles Turques";
				Link.l3.go = "TravelToTerks";
				Link.l4 = "Sainte-Lucie";
				Link.l4.go = "TravelToLucia";
				Link.l5 = "Tu sais, reste pour l'instant, j'ai changé d'avis.";
				Link.l5.go = "exit";
		break;

		case "TravelToCaiman":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_2;									// Companion index
				cn_2 = GetCompanionIndex(PChar, i);
				if (cn_2 == -1) continue;
				if (NPChar.name == characters[cn_2].name) NPChar.realcompanionidx = &characters[cn_2].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Caiman";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Caiman"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Caiman" + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLucia":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_3;									// Companion index
				cn_3 = GetCompanionIndex(PChar, i);
				if (cn_3 == -1) continue;
				if (NPChar.name == characters[cn_3].name) NPChar.realcompanionidx = &characters[cn_3].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "StLucia";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("StLucia"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("StLucia" + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToDominica":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_4;									// Companion index
				cn_4 = GetCompanionIndex(PChar, i);
				if (cn_4 == -1) continue;
				if (NPChar.name == characters[cn_4].name) NPChar.realcompanionidx = &characters[cn_4].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Dominica";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Dominica"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Dominica" + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToTerks":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_5;									// Companion index
				cn_5 = GetCompanionIndex(PChar, i);
				if (cn_5 == -1) continue;
				if (NPChar.name == characters[cn_5].name) NPChar.realcompanionidx = &characters[cn_5].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Terks";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Terks"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Terks" + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLaVega":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_6;									// Companion index
				cn_6 = GetCompanionIndex(PChar, i);
				if (cn_6 == -1) continue;
				if (NPChar.name == characters[cn_6].name) NPChar.realcompanionidx = &characters[cn_6].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "LaVega";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("LaVega"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToPuertoPrincipe":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_7;									// Companion index
				cn_7 = GetCompanionIndex(PChar, i);
				if (cn_7 == -1) continue;
				if (NPChar.name == characters[cn_7].name) NPChar.realcompanionidx = &characters[cn_7].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "PuertoPrincipe";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("PuertoPrincipe"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToFortOrange":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_8;									// Companion index
				cn_8 = GetCompanionIndex(PChar, i);
				if (cn_8 == -1) continue;
				if (NPChar.name == characters[cn_8].name) NPChar.realcompanionidx = &characters[cn_8].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "FortOrange";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("FortOrange"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToPirates":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_9;									// Companion index
				cn_9 = GetCompanionIndex(PChar, i);
				if (cn_9 == -1) continue;
				if (NPChar.name == characters[cn_9].name) NPChar.realcompanionidx = &characters[cn_9].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "Pirates";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("Pirates"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;
		case "TravelToLeFransua":
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn_10;									// Companion index
				cn_10 = GetCompanionIndex(PChar, i);
				if (cn_10 == -1) continue;
				if (NPChar.name == characters[cn_10].name) NPChar.realcompanionidx = &characters[cn_10].index;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID = "LeFransua";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days = makeint(GetDistanceToColony2D("LeFransua"))/300+1.0);
			dialog.Text = "Alors, vous voulez que j'aille à "+XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen")+", capitaine ?";
			Link.l1 = "Oui, c'est vrai.";
            Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
            Link.l2.go = "exit";
        break;

		int nFind = findSubStr(Dialog.CurrentNode, "CompanionTravelToColony_", 0);
		string idxVal;
		string nodName;
		if (nFind == 0)
		{
			idxVal = strcut(Dialog.CurrentNode, 24, strlen(Dialog.CurrentNode) - 1);
			nodName = "CompanionTravelToColony_" + idxVal;
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cn;									// Companion index
				cn = GetCompanionIndex(PChar, i);
				if (cn == -1) continue;
				if (NPChar.name == characters[cn].name) NPChar.realcompanionidx = &characters[cn].index;
			}
			aref rCTravel;
			makearef(rCTravel, characters[sti(NPChar.realcompanionidx)].CompanionTravel);
			rCTravel.ToColonyID = NPChar.Temp.(idxVal);
			rCTravel.Days = makeint(GetDistanceToColony2D(NPChar.Temp.(idxVal)) / 300 + 1.0);
			dialog.Text = "Vous avez choisi la colonie de " + XI_ConvertString("Colony" + rCTravel.ToColonyID + "Gen") + ", capitaine ?";
			Link.l1 = "Oui, c'est elle.";
			Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
			break;
		}

		// LEO: выбран город с нашим складом. Маршрут считается так же, как для обычной колонии,
		//   но рейс помечается задачей - по прибытии компаньон работает со складом, а не просто ждёт.
		int nFindSt = findSubStr(Dialog.CurrentNode, "CompanionTravelToStorage_", 0);
		string stVal;
		if (nFindSt == 0)
		{
			stVal = strcut(Dialog.CurrentNode, 25, strlen(Dialog.CurrentNode) - 1);
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cnSt;
				cnSt = GetCompanionIndex(PChar, i);
				if (cnSt == -1) continue;
				if (NPChar.name == characters[cnSt].name) NPChar.realcompanionidx = &characters[cnSt].index;
			}
			aref rCTravelSt;
			makearef(rCTravelSt, characters[sti(NPChar.realcompanionidx)].CompanionTravel);
			rCTravelSt.ToColonyID = NPChar.Temp.(stVal);
			rCTravelSt.Days = makeint(GetDistanceToColony2D(NPChar.Temp.(stVal)) / 300 + 1.0);
			rCTravelSt.Task = "storage"; // рейс на склад: по прибытии перетарка, затем возврат к ГГ
			DeleteAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Return"); // сброс с прошлого раза
			dialog.Text = "L'entrepכt de " + XI_ConvertString(CompanionTravel_ColonyTextId(rCTravelSt.ToColonyID, "Voc")) + ", capitaine. La traversée prend " + FindRussianDaysString(sti(rCTravelSt.Days)) + ".";
			Link.l1 = "Veille à ce que tout soit prêt pour appareiller.";
			Link.l1.go = "CompanionTravel_PrepareStart"; // проверки корпуса/команды/провианта, затем выбор задачи
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
			break;
		}

		// LEO: выбран город коммерческого рейса - маршрут как обычно, задача "commerce" (операция выбирается в PrepareStart)
		int nFindCom = findSubStr(Dialog.CurrentNode, "CompanionTravelToCommerce_", 0);
		string comVal;
		if (nFindCom == 0)
		{
			comVal = strcut(Dialog.CurrentNode, 26, strlen(Dialog.CurrentNode) - 1);
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cnCom;
				cnCom = GetCompanionIndex(PChar, i);
				if (cnCom == -1) continue;
				if (NPChar.name == characters[cnCom].name) NPChar.realcompanionidx = &characters[cnCom].index;
			}
			aref rCTravelCom;
			makearef(rCTravelCom, characters[sti(NPChar.realcompanionidx)].CompanionTravel);
			rCTravelCom.ToColonyID = NPChar.Temp.(comVal);
			rCTravelCom.Days = makeint(GetDistanceToColony2D(NPChar.Temp.(comVal)) / 300 + 1.0);
			rCTravelCom.Task = "commerce";
			DeleteAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.CommerceOp"); // сброс с прошлого раза
			DeleteAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.StoreMode");
			dialog.Text = "Vers " + XI_ConvertString(CompanionTravel_ColonyTextId(rCTravelCom.ToColonyID, "Acc")) + ", capitaine. La traversée prend " + FindRussianDaysString(sti(rCTravelCom.Days)) + ".";
			Link.l1 = "Veille à ce que tout soit prêt pour appareiller.";
			Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
			break;
		}

		// LEO: закупочный рейс - выбран город. Task="buy"; товар купится в трюм при отправке (Companion_BuyCargo).
		int nFindBuy = findSubStr(Dialog.CurrentNode, "CompanionTravelToBuy_", 0);
		string buyVal;
		if (nFindBuy == 0)
		{
			buyVal = strcut(Dialog.CurrentNode, 21, strlen(Dialog.CurrentNode) - 1);
			for (i = 1; i < COMPANION_MAX; i++)
			{
				int cnBuy;
				cnBuy = GetCompanionIndex(PChar, i);
				if (cnBuy == -1) continue;
				if (NPChar.name == characters[cnBuy].name) NPChar.realcompanionidx = &characters[cnBuy].index;
			}
			aref rCTravelBuy;
			makearef(rCTravelBuy, characters[sti(NPChar.realcompanionidx)].CompanionTravel);
			rCTravelBuy.ToColonyID = NPChar.Temp.(buyVal);
			rCTravelBuy.Days = makeint(GetDistanceToColony2D(NPChar.Temp.(buyVal)) / 300 + 1.0);
			rCTravelBuy.Task = "buy";
			dialog.Text = "Vers " + XI_ConvertString(CompanionTravel_ColonyTextId(rCTravelBuy.ToColonyID, "Acc")) + " pour commercer, capitaine. Cela prend " + FindRussianDaysString(sti(rCTravelBuy.Days)) + " à l'aller, et autant au retour.";
			Link.l1 = "Veille à ce que tout soit prêt pour appareiller.";
			Link.l1.go = "CompanionTravel_PrepareStart";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "exit";
			break;
		}

		// LEO: перетарка - ПОСЛЕДНИЙ шаг рейса на склад. Открываем ШТАТНЫЙ интерфейс склада города
		//   назначения; окно работает только с трюмом компаньона (см. storage.c), а при его закрытии
		//   снимается манифест И СРАЗУ ПРОИСХОДИТ ОТПРАВКА. Возврат в диалог не нужен - штатного
		//   "интерфейс -> обратно в диалог" в движке нет (Common_Store тоже делает DialogExit).
		case "CompanionTravel_StorageCargo":
			int iStoreCT;
			iStoreCT = CompanionTravel_GetStoreNum(characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID);
			if (iStoreCT < 0)
			{
				dialog.Text = "Une affaire délicate, cap'taine : nous n'avons pas d'entrepכt là-bas, après tout.";
				Link.l1 = "C'est vrai. Oublie ça.";
				Link.l1.go = "exit";
				break;
			}
			PChar.CompanionTravel.StorageChrIdx = sti(NPChar.realcompanionidx);
			PChar.CompanionTravel.PendingSendNpc = sti(NPChar.index); // кого отправить при закрытии окна
			CompanionTravel_StorageSnapshot(iStoreCT);
			DialogExit();
			LaunchStorage(iStoreCT);
		break;

		// LEO: закупочный рейс - открываем ШТАТНЫЙ магазин города назначения (окно на трюм компаньона, store.c BuyChrIdx). Return=true: с товаром обратно в эскадру.
		case "Companion_BuyCargo":
			int iBuyStore;
			iBuyStore = sti(colonies[FindColony(characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID)].StoreNum); // стор колонии напрямую (FindStore не матчит пиратов)
			if (iBuyStore < 0)
			{
				dialog.Text = "Bizarre, cap'taine : il n'y a pas de magasin là-bas.";
				Link.l1 = "C'est vrai. Oublie ça.";
				Link.l1.go = "exit";
				break;
			}
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Return = true; // с товаром обратно в эскадру
			PChar.CompanionTravel.BuyChrIdx = sti(NPChar.realcompanionidx);
			PChar.CompanionTravel.PendingSendNpc = sti(NPChar.index);
			PChar.CompanionTravel.BuyStoreNum = iBuyStore;
			CompanionTravel_BuySnapshot(sti(NPChar.realcompanionidx));
			DialogExit();
			LaunchStore(iBuyStore);
		break;

		// LEO: то же, но по закупке компаньон ЖДЁТ на рейде города (Return не ставим).
		case "Companion_BuyCargo_Wait":
			int iBuyStoreW;
			iBuyStoreW = sti(colonies[FindColony(characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID)].StoreNum); // стор колонии напрямую (FindStore не матчит пиратов)
			if (iBuyStoreW < 0)
			{
				dialog.Text = "Bizarre, cap'taine : il n'y a pas de magasin là-bas.";
				Link.l1 = "C'est vrai. Oublie ça.";
				Link.l1.go = "exit";
				break;
			}
			DeleteAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Return"); // остаётся ждать на рейде
			PChar.CompanionTravel.BuyChrIdx = sti(NPChar.realcompanionidx);
			PChar.CompanionTravel.PendingSendNpc = sti(NPChar.index);
			PChar.CompanionTravel.BuyStoreNum = iBuyStoreW;
			CompanionTravel_BuySnapshot(sti(NPChar.realcompanionidx));
			DialogExit();
			LaunchStore(iBuyStoreW);
		break;

		case "CompanionTravel_EnemyColony":
			dialog.Text = "Capitaine, mais je ne peux pas vous attendre dans une colonie qui nous est hostile !";
				Link.l1 = "Tu sais, oublie tous ces voyages...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoCrew":
			dialog.Text = "Cap'taine, il n'y a presque plus de marins sur le navire ! Quelle navigation ?!";
				Link.l1 = "Oui, c'est vrai. Il n'y a presque plus d'équipage...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoFood":
			dialog.Text = "Cap'taine, je n'ai pas assez de vivres à bord pour ce voyage.";
				Link.l1 = "Oui, tu as raison. Le voyage attendra...";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_NoHP":
			dialog.Text = "Cap'taine, mais mon navire est en mauvais état. Il n'est pas sage pour moi de prendre la mer seul dans de telles conditions !";
				Link.l1 = "Oui, tu as raison. Ton navire a besoin de réparations.";
				Link.l1.go = "exit";
		break;

		case "CompanionTravel_PrepareStart":
			int iShip = sti(characters[sti(NPChar.realcompanionidx)].ship.type);
			ref refBaseShip = GetRealShip(iShip);
			if (sti(refBaseShip.hp)/4>sti(characters[sti(NPChar.realcompanionidx)].ship.hp))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoHP";
				break;
			}
			if (sti(refBaseShip.MinCrew)>GetCrewQuantity(characters[sti(NPChar.realcompanionidx)]))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoCrew";
				break;
			}
			// LEO: рейд/склад ждут месяц на месте - нужен запас на 30 дн.; коммерческий рейс сразу распродаёт корабль -> хватит запаса на дорогу (10)
			int iFoodBuf;
			iFoodBuf = 30;
			if (CheckAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Task") && characters[sti(NPChar.realcompanionidx)].CompanionTravel.Task == "commerce") iFoodBuf = 10;
			if (sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days)+iFoodBuf>CalculateShipFood(characters[sti(NPChar.realcompanionidx)]))
			{
				dialog.Text = "Je vois un problème, cap'taine...";
				Link.l1 = "Laquelle ?";
				Link.l1.go = "CompanionTravel_NoFood";
				break;
			}
			dialog.Text = "Tout est clair. Pour aller à " + XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen") + " il me faut " + sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days) + " jours. Que dois-je faire à mon arrivée ?";
			if (sti(characters[sti(NPChar.realcompanionidx)].CompanionTravel.Days) == 1)
			{
			dialog.Text = "Tout est clair. " + XI_ConvertString("Colony" + characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID + "Gen") + " est tout près, j'y serai aujourd'hui même. Que dois-je faire là-bas ?";
			}
			// LEO: рейс на склад - вместо "жди на рейде" две складские задачи, обе ведут к перетарке
			//   (последний шаг), а не сразу к отправке.
			if (CheckAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Task")
			 && characters[sti(NPChar.realcompanionidx)].CompanionTravel.Task == "buy")
			{
				Link.l1 = "Va commercer et reviens me trouver.";
				Link.l1.go = "Companion_BuyCargo";
				Link.l3 = "Va commercer et attends-moi au large.";
				Link.l3.go = "Companion_BuyCargo_Wait";
			}
			else if (CheckAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Task")
			 && characters[sti(NPChar.realcompanionidx)].CompanionTravel.Task == "commerce")
			{
				Link.l1 = "Vends-le au chantier naval.";
				Link.l1.go = "Commerce_Sell";
				Link.l3 = "Mets-le aux enchères à la capitainerie.";
				Link.l3.go = "Commerce_Auction";
				Link.l4 = "Mets-le en dépכt à la capitainerie.";
				Link.l4.go = "Commerce_Store";
			}
			else if (CheckAttribute(&characters[sti(NPChar.realcompanionidx)], "CompanionTravel.Task")
			 && characters[sti(NPChar.realcompanionidx)].CompanionTravel.Task == "storage")
			{
				Link.l1 = "Entrepose la cargaison là-bas et attends-moi au large.";
				Link.l1.go = "CompanionTravel_StorageCargo";
				Link.l3 = "Entrepose la cargaison et reviens me trouver.";
				Link.l3.go = "CompanionTravel_PrepareStart_Back";
			}
			else
			{
				Link.l1 = "Attends-moi en rade pendant un mois.";
				Link.l1.go = "CompanionTravel_PrepareStart_2";
			}
			Link.l2 = "Tu sais, j'ai changé d'avis. Reste avec moi pour l'instant...";
			Link.l2.go = "exit";
		break;

		// LEO: рейс на склад с возвратом - ставим флаг и ведём к перетарке (отправка при закрытии окна)
		case "CompanionTravel_PrepareStart_Back":
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.Return = true;
			dialog.Text = "Compris, cap'taine. Je trie la cargaison, et je reviens aussitכt vous trouver.";
			Link.l1 = "Alors, trie ce qu'il faut emporter.";
			Link.l1.go = "CompanionTravel_StorageCargo";
		break;

		case "CompanionTravel_PrepareStart_2":
			dialog.Text = "C'est clair, capitaine. Je pars immédiatement.";
				Link.l1 = "Oui, vas-y.";
				Link.l1.go = "CompanionTravel_Start";
		break;

		// LEO: коммерческий рейс - выбор операции над кораблём (устанавливает CommerceOp, дальше штатный Start)
		case "Commerce_Sell":
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.CommerceOp = "sell";
			dialog.Text = "Compris, cap'taine. Je déchargerai le navire au chantier naval et je vous attendrai à la taverne de là-bas avec le produit de la vente.";
			Link.l1 = "Appareille.";
			Link.l1.go = "CompanionTravel_Start";
			Link.l2 = "Vous savez, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Commerce_Auction":
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.CommerceOp = "auction";
			dialog.Text = "Compris, capitaine. Je mettrai le navire aux enchères à la capitainerie et je vous attendrai à la taverne. Vous toucherez le produit de la coque auprès du capitaine du port une fois qu'il sera vendu.";
			Link.l1 = "Appareille.";
			Link.l1.go = "CompanionTravel_Start";
			Link.l2 = "Vous savez, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		// LEO: хранение корабля в ПУ - оставить компаньона при судне ИЛИ нанять сторожа. Плата не вперёд, а при
		//   снятии корабля в "Корабли в ПУ" (штатный долг PortStock_GetReturnDebt, зависит от города/нации).
		case "Commerce_Store":
			dialog.Text = "Comment dois-je laisser le navire en dépכt à la capitainerie, capitaine ? Nous réglerons le mouillage quand nous viendrons le récupérer.";
			Link.l1 = "Reste avec lui toi-même : surveille le navire.";
			Link.l1.go = "Commerce_StoreKeep";
			Link.l2 = "Engage un veilleur, et reviens me trouver.";
			Link.l2.go = "Commerce_StoreWatch";
			Link.l9 = "Vous savez, j'ai changé d'avis.";
			Link.l9.go = "exit";
		break;

		case "Commerce_StoreKeep":
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.CommerceOp = "store";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.StoreMode = "keep";
			dialog.Text = "Compris, cap'taine. J'emmène le navire en dépכt à la capitainerie et je reste avec lui. Venez nous récupérer tous les deux là-bas quand vous aurez besoin de nous.";
			Link.l1 = "Appareille.";
			Link.l1.go = "CompanionTravel_Start";
			Link.l2 = "Vous savez, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "Commerce_StoreWatch":
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.CommerceOp = "store";
			characters[sti(NPChar.realcompanionidx)].CompanionTravel.StoreMode = "watch";
			dialog.Text = "Compris, capitaine. Je mets le navire en dépכt sous la garde d'un veilleur, et je reviens vous attendre à la taverne.";
			Link.l1 = "Appareille.";
			Link.l1.go = "CompanionTravel_Start";
			Link.l2 = "Vous savez, j'ai changé d'avis.";
			Link.l2.go = "exit";
		break;

		case "CompanionTravel_Start":
			Diag.CurrentNode = "CompanionTravel_LastNode";
			NPChar.quest.meeting = true;
			CompanionTravel_SetTraveller(NPChar);
			DialogExit();
		break;

		case "CompanionTravel_LastNode":
			Dialog.text = RandPhraseSimple("Aujourd'hui, je reprends la mer...",
			"N'oubliez pas notre rendez-vous à " + XI_ConvertString(CompanionTravel_ColonyTextId(characters[sti(NPChar.realcompanionidx)].CompanionTravel.ToColonyID, "Voc")) + ".");
				link.l2 = "...";
				link.l2.go = "Exit";
				Diag.TempNode = "CompanionTravel_LastNode";
		break;
		
		case "CompanionTravel_Transfer":
			DialogExit();
			pchar.TransferChar = NPChar.index;
			PostEvent("LaunchIAfterFrame",1,"sl", "TransferMain", 2);
		break;

		case "CompanionTravel_ToSquadron":
			if(GetCompanionQuantity(PChar) < COMPANION_MAX)
			{
				dialog.text = "א vos ordres, capitaine ! De nouveau sous votre commandement.";
					Link.l1 = "Bien.";
					Link.l1.go = "exit";
					Diag.TempNode = "hired";
					CompanionTravel_DeleteSpecialShipAttributes(NPChar);
					Group_DeleteGroup(NPChar.CompanionTravel.GroupID); // Потрём группу
					SetCompanionIndex(PChar, -1, sti(NPChar.index));
					PChar.CompanionTravel = sti(PChar.CompanionTravel) - 1; // Этого компаньона взяли обратно в эскадру
					AddQuestRecord("CompanionTravel", "2");
					AddQuestUserData("CompanionTravel", "sCapName", GetFullName(NPChar)); 
					AddQuestUserData("CompanionTravel", "sShipInfo", GetStrSmallRegister(XI_ConvertString(RealShips[sti(NPChar.Ship.Type)].Basename + "Voc")) + " '" + NPChar.Ship.name + "'");
					if(GetAttrValue(PChar, "CompanionTravel") == 0) CloseQuestHeader("CompanionTravel");
					CompanionTravel_RestoreDialog(NPChar); // LEO: вернуть исходную ноду (до удаления CompanionTravel c Saved*)
					DeleteAttribute(NPChar, "CompanionTravel");
					for(iTemp=1; iTemp<=3; iTemp++) // Нужно, чтоб была свободная группа
					{
						attr = "Companion" + iTemp;
						if (CheckAttribute(PChar, "CompanionTravel."+(attr)+".ID"))
						{
							if (PChar.CompanionTravel.(attr).ID == NPChar.ID)
							{
								DeleteAttribute(PChar, "CompanionTravel."+(attr));//фикс - удаляем всю ветку
								DeleteAttribute(NPChar, "Tasks.Clone");
							}
						}
					}
			}
			else
			{
				dialog.text = "Cap'taine, vous avez déjà une escadre de cinq rafiots, oם mettrez-vous le sixième ? Bref, je vous attendrai ici sur mon navire : tous ces nouveaux compagnons ne sont pas fiables, leurs navires couleront très vite, et vous reviendrez me chercher.";
					Link.l1 = "Eh, tu as une sacrée tête. Tu ne devrais pas être capitaine, mais amiral !";
					Link.l1.go = "exit";
					Diag.TempNode = "CompanionTravel_ToSquadron_2";
					NPChar.DeckDialogNode = "CompanionTravel_ToSquadron_2"; // ставим снова эту ноду
			}
		break;

		case "CompanionTravel_ToSquadron_2":
			dialog.text = "Ah, capitaine. Vous voilà de retour, comme je l'avais dit. Alors, une place s'est-elle libérée dans l'escadre ?";
			if(GetCompanionQuantity(PChar) < COMPANION_MAX)
			{
				Link.l1 = "Oui, " + npchar.name + ", une place s'est libérée. Bienvenue dans l'escadre.";
				Link.l1.go = "exit";
				Diag.TempNode = "hired";
				CompanionTravel_DeleteSpecialShipAttributes(NPChar);
				Group_DeleteGroup(NPChar.CompanionTravel.GroupID);
				SetCompanionIndex(PChar, -1, sti(NPChar.index));
				PChar.CompanionTravel = sti(PChar.CompanionTravel) - 1; // Этого компаньона взяли обратно в эскадру
				AddQuestRecord("CompanionTravel", "2");
				AddQuestUserData("CompanionTravel", "sCapName", GetFullName(NPChar)); 
				AddQuestUserData("CompanionTravel", "sShipInfo", GetStrSmallRegister(XI_ConvertString(RealShips[sti(NPChar.Ship.Type)].Basename + "Voc")) + " '" + NPChar.Ship.name + "'");
				if(GetAttrValue(PChar, "CompanionTravel") == 0) CloseQuestHeader("CompanionTravel"); 
				CompanionTravel_RestoreDialog(NPChar); // LEO: вернуть исходную ноду (до удаления CompanionTravel c Saved*)
					DeleteAttribute(NPChar, "CompanionTravel");
				for(iTemp=1; iTemp<=3; iTemp++) // Нужно, чтоб была свободная группа
				{
					attr = "Companion" + iTemp;
					if (CheckAttribute(PChar, "CompanionTravel."+(attr)+".ID"))
					{
						if (PChar.CompanionTravel.(attr).ID == NPChar.ID)
						{
							DeleteAttribute(PChar, "CompanionTravel."+(attr));
							DeleteAttribute(NPChar, "Tasks.Clone");
						}
					}
				}
			}
			else
			{
				Link.l1 = "Pas encore, malheureusement.";
				Link.l1.go = "exit";
				Diag.TempNode = "CompanionTravel_ToSquadron_2";
				NPChar.DeckDialogNode = "CompanionTravel_ToSquadron_2";
			}
		break;

		//////////////////////////////    офицер-наместник <--


	        // COLONY BUILDING
		case "ColonyBuilding_Hovernor_1":
			dialog.Text = "C'est un honneur pour moi d'être le gouverneur de votre colonie !";
			Link.l1 = "Veillez à l'ordre et à la prospérité de la ville. Vous aurez beaucoup à surveiller. Je viendrai ici de temps en temps.";
			Link.l1.go = "ColonyBuilding_Hovernor_2";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

	        case "ColonyBuilding_Hovernor_2":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.ColonyBuilding.Hovernor = NPChar.id;
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			Diag.TempNode = "ColonyBuilding_Hovernor";

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "Caiman_townhall", "sit", "sit1");
			LAi_SetHuberType(NPChar);


			DialogExit();
	        break;

		case "ColonyBuilding_Hovernor":
			if(PChar.ColonyBuilding.AutoPurchaseFirst == true && PChar.ColonyBuilding.Store.BuildingTime == false && PChar.ColonyBuilding.AutoPurchaseFirst.Disable != true)
			{
				dialog.Text = "Bonjour, capitaine. Un magasin a récemment ouvert dans notre colonie, et je veux vous parler de certains avantages de cet important bâtiment.";
				Link.l1 = "Continuez.";
				Link.l1.go = "ColonyBuilding_AutoStore_1";
				break;
			}

			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes de la colonie.";
			Link.l1.go = "ColonyBuilding_Hovernor_3";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "ColonyBuilding_Hovernor_4";
			Link.l3 = "Je passe juste voir ce que vous devenez, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "ColonyBuilding_Hovernor";
		break;

		case "ColonyBuilding_Hovernor_3":
			dialog.Text = "Hum... Quelles affaires voulez-vous connaître ?";
			Link.l1 = "Je m'intéresse à l'état de la colonie et à ses capacités financières.";
			Link.l1.go = "ColonyBuilding_Hovernor_3_1";
			Link.l2 = "Je m'intéresse à l'état de préparation de la garnison et à la santé des habitants.";
			Link.l2.go = "ColonyBuilding_Hovernor_3_2";
			Link.l3 = "Je veux renommer la colonie et revoir l'apparence des soldats.";
			Link.l3.go = "ColonyBuilding_Hovernor_3_3";
			Link.l4 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l4.go = "Exit";

		break;

		case "ColonyBuilding_AutoStore_1":
			PChar.ColonyBuilding.AutoPurchaseFirst.Disable = true;
			dialog.Text = "Avec un magasin en activité, vous pouvez assurer l'achat automatique des marchandises de première nécessité, afin que les citoyens de la colonie et la garnison qui la garde reçoivent à temps médicaments et vivres.\nAdressez-vous à notre marchand si cela vous intéresse.";
			Link.l1 = "Intéressant. Parlons d'autre chose.";
			Link.l1.go = "ColonyBuilding_Hovernor_3";
		break;

		case "ColonyBuilding_Hovernor_3_1":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColony();
		break;

		case "ColonyBuilding_Hovernor_3_2":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColonyLandGuard();
		break;

		case "ColonyBuilding_Hovernor_3_3":
			Diag.TempNode = "ColonyBuilding_Hovernor";
			DialogExit();
			LaunchColonyBuilding(true, false);
		break;

		case "ColonyBuilding_Hovernor_4":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "ColonyBuilding_Hovernor_5";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
		break;

		case "ColonyBuilding_Hovernor_5":
			PChar.ColonyBuilding.Hovernor = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			npchar.norespec = true;
			Diag.TempNode = "Hired";
		break;

		case "ColonyBuilding_Expidition_End":
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. Notre expédition vient de se terminer. On a trouvé sur l'île des terres très fertiles et, surtout, des gisements de minerai.";
			Link.l1 = "Hum, eh bien, très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

		case "ColonyBuilding_Mines_End":
			PChar.ColonyBuilding.MineMessage = true;
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. La construction des mines est terminée. Il vous faut maintenant nommer un chef des mines. C'est avec lui que vous réglerez toutes les affaires liées à cette activité.";
			Link.l1 = "Hum, eh bien, c'est très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

		case "ColonyBuilding_Plantation_End":
			Diag.CurrentNode = "ColonyBuilding_Hovernor";
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". J'ai des nouvelles pour vous. La construction de la plantation est terminée. Il vous faut maintenant nommer un chef de la plantation. C'est avec lui que vous réglerez toutes les affaires liées à cette activité.";
			Link.l1 = "Hum, eh bien, c'est très bien. א plus tard.";
			Link.l1.go = "exit";
		break;

        	// Начальник рудников
		case "MinesCommander_1":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes des mines.";
			Link.l1.go = "MinesCommander_2";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "MinesCommander_Remove";
			Link.l3 = "Je passe juste voir ce que vous devenez, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "MinesCommander_1";
		break;

		case "MinesCommander_2":
			Diag.TempNode = "MinesCommander_1";
			DialogExit();
			LaunchMines();
		break;

		case "MinesCommander_Remove":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "MinesCommander_Removed";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "MinesCommander_1";
		break;

		case "MinesCommander_Removed":
			PChar.Mines.Commander = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			npchar.norespec = true;
			Diag.TempNode = "Hired";
		break;

		case "MinesCommander_Hire":
			dialog.Text = "Bien. Je vais essayer de répondre à vos attentes.";
			Link.l1 = "Très bien. Remplissez vos fonctions.";
			Link.l1.go = "MinesCommander_Hired";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

		case "MinesCommander_Hired":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "Caiman_Mines_Comendant_House", "barmen", "stay");

			LAi_SetStayType(NPChar);
			PChar.Mines.Commander = NPChar.id;
			Diag.CurrentNode = "MinesCommander_1";
			Diag.TempNode = "MinesCommander_1";


			DialogExit();
		break;

        	// Начальник плантации
		case "PlantationCommander_1":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître les affaires courantes de la plantation.";
			Link.l1.go = "PlantationCommander_2";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "PlantationCommander_Remove";
			Link.l3 = "J'ai décidé de voir ce que vous devenez, " + npchar.name + ".";
			Link.l3.go = "Exit";
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_2":
			DialogExit();
			LaunchPlantation();
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_Remove":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "PlantationCommander_Removed";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "PlantationCommander_1";
		break;

		case "PlantationCommander_Removed":
			PChar.Plantation.Commander = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			npchar.norespec = true;
			Diag.TempNode = "Hired";
		break;

		case "PlantationCommander_Hire":
			dialog.Text = "Bien. Je vais essayer de répondre à vos attentes.";
			Link.l1 = "Très bien. Remplissez vos fonctions.";
			Link.l1.go = "PlantationCommander_Hired";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

		case "PlantationCommander_Hired":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.Plantation.Commander = NPChar.id;
			Diag.CurrentNode = "PlantationCommander_1";
			Diag.TempNode = "PlantationCommander_1";

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "CaimanPlantationOffice", "goto", "goto1");
			LAi_SetStayType(NPChar);


			DialogExit();
		break;

	        // Помошник по охране - начальник гарнизона
		case "ColonyGuarding_Hovernor_1":
			dialog.Text = "Hum... Je pense pouvoir m'acquitter de la tâche qui m'est confiée.";
			Link.l1 = "Bien sמr que vous le pourrez, sinon... euh... Vous pouvez commencer !";
			Link.l1.go = "ColonyGuarding_Hovernor_2";
			Link.l2 = "J'ai changé d'avis.";
			Link.l2.go = "Exit";
			Diag.TempNode = "Hired";
		break;

	        case "ColonyGuarding_Hovernor_2":
			CheckForReleaseOfficer(sti(NPChar.index));
			RemovePassenger(pchar, NPChar);
			PChar.Colony.Guardians.Hovernor = NPChar.id;

			LAi_Fade("", "");
			ChangeCharacterAddressGroup(NPChar, "LandGuardingHeadHouse", "goto", "goto3");
			LAi_SetStayType(NPChar);

			Diag.CurrentNode = "ColonyGuarding_Hovernor";
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
	        break;

		case "ColonyGuarding_Hovernor":
			dialog.Text = "Bonjour, capitaine " + GetFullName(pchar) + ". Que puis-je faire pour vous ?";
			Link.l1 = "Je veux connaître l'état actuel de la défense.";
			Link.l1.go = "ColonyGuarding_Hovernor_3";
			Link.l2 = "Je veux vous relever de vos fonctions, " + npchar.name + ".";
			Link.l2.go = "ColonyGuarding_Hovernor_4";
			Link.l3 = "Je veux parler du recrutement d'hommes pour la garnison qui garde notre colonie.";
			Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_1";
			Link.l4 = "J'ai décidé de voir ce que vous devenez, " + npchar.name + ".";
			Link.l4.go = "Exit";
			Diag.TempNode = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_3":
			dialog.Text = "Hum... Quelles affaires voulez-vous connaître ?";
			Link.l1 = "Je m'intéresse à la question du littoral.";
			Link.l1.go = "ColonyGuarding_Hovernor_3_1";
			Link.l2 = "Je m'intéresse à l'état de préparation de la garnison et à la santé des habitants.";
			Link.l2.go = "ColonyGuarding_Hovernor_3_2";
			Link.l3 = "Je m'intéresse à l'état de préparation de la garde cכtière.";
			Link.l3.go = "ColonyGuarding_Hovernor_3_3";
			Link.l4 = "Désolé, " + npchar.name + "Je dois prendre congé.";
			Link.l4.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_3_1":
		    	CheckDeadColonyGuard();
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
			LaunchColonyGuardiang();
		break;

		case "ColonyGuarding_Hovernor_3_2":
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
			LaunchColonyLandGuard();
		break;

		case "ColonyGuarding_Hovernor_3_3":
			CheckDeadColonyGuard();

			if(GetColonyGuardsShipsQuantity() < 1)
			{
				dialog.Text = "Capitaine, il n'y a pas de navires dans l'escadre en ce moment...";
				Link.l1 = "Ah oui, j'oubliais...";
				Link.l1.go = "exit";
				PChar.Colony.Guardians.BaseComplete = false;
				break;
			}

			string sBaseComplete = "";

			if(PChar.Colony.Guardians.BaseComplete == true)
			{
				sBaseComplete = "les navires sont entièrement réapprovisionnés chaque semaine et toujours prêts au combat. Actuellement, la somme nécessaire pour cela est de " + GetCostForBaseCompletationAllGuards() + " piastres.";
			}
			else
			{
				sBaseComplete = "les navires cכtiers ne sont pas réapprovisionnés. Mais il est possible de les inspecter chaque semaine et de compléter leur armement et leur équipage, afin de pouvoir repousser les gredins à tout moment.";
			}

			dialog.Text = "Hum... Pour l'instant, " + sBaseComplete;

			if(PChar.Colony.Guardians.BaseComplete == true)
			{
				Link.l1 = "Je pense qu'il vaut mieux suspendre le réapprovisionnement hebdomadaire pour le moment. Le trésor n'est pas extensible...";
				Link.l1.go = "ColonyGuarding_Hovernor_3_3_3";
			}
			else
			{
				if(PChar.Colony.Guardians.BaseComplete.First == true)
				{
					Link.l1 = "Parlez-m'en davantage.";
					Link.l1.go = "ColonyGuarding_Hovernor_3_3_1";
				}
				else
				{
					Link.l1 = "Je pense qu'il est temps de reprendre l'entretien hebdomadaire de la garde cכtière.";
					Link.l1.go = "ColonyGuarding_Hovernor_3_3_2";
				}
			}

			Link.l2 = "Excusez-moi, des affaires m'attendent.";
			Link.l2.go = "Exit";
			Diag.CurrentNode = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_3_3_1":
			PChar.Colony.Guardians.BaseComplete.First = false;
			dialog.Text = "Les navires cכtiers seront inspectés chaque semaine : ceux qui gardent actuellement le littoral seront complétés en munitions et en matériel manquants, et leur équipage sera renforcé.\nMais pour que tout cela fonctionne, il faudra engager certaines dépenses, qui dépendent des navires que vous équipez. Par exemple, il faudra désormais verser " + GetCostForBaseCompletationAllGuards() + " piastres par semaine, prises sur le trésor de la colonie. Si cette somme vient à manquer, alors, hélas, il n'y aura rien pour réapprovisionner les navires. Qu'en dites-vous ?";
			Link.l1 = "C'est une chose utile. J'autorise le versement régulier des fonds du trésor de la colonie.";
			Link.l1.go = "ColonyGuarding_Hovernor_3_3_2";
			Link.l2 = "Je crois que nous nous en passerons pour l'instant.";
			Link.l2.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_3_3_2":
			PChar.Colony.Guardians.BaseComplete = true;
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
		break;

		case "ColonyGuarding_Hovernor_3_3_3":
			PChar.Colony.Guardians.BaseComplete = false;
			Diag.TempNode = "ColonyGuarding_Hovernor";
			DialogExit();
		break;

		case "ColonyGuarding_Hovernor_4":
			dialog.Text = "Vous êtes sמr ?";
			Link.l1 = "Oui.";
			Link.l1.go = "ColonyGuarding_Hovernor_5";
			Link.l2 = "Non, j'ai changé d'avis.";
			Link.l2.go = "Exit";
		break;

		case "ColonyGuarding_Hovernor_5":
			PChar.Colony.Guardians.Hovernor = "";
			dialog.Text = "Merveilleux ! זtre un rat de terre, ce n'est pas mon destin.";
			Link.l1 = "Voilà qui est bien.";
			Link.l1.go = "exit_hire";
			npchar.norespec = true;
			Diag.TempNode = "Hired";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_1":
			dialog.Text = "Très bien, capitaine. Que puis-je faire pour vous à ce sujet ?";
			Link.l1 = "J'aimerais en savoir plus sur cette possibilité.";
			Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Info";
			Link.l2 = "Je veux connaître le coמt de l'entretien du recrutement.";
			Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Costs";
			Link.l3 = "Il faut revoir la liste des sites pour lesquels le recrutement de la garnison est assuré.";
			Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Set";
			Link.l4 = "Non, j'ai changé d'avis.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Info":
			dialog.Text = "Je peux moi-même recruter des hommes pour la garnison, afin que notre colonie et ses installations puissent toujours repousser l'ennemi et mater les citoyens et les esclaves rebelles. Mais, vous l'imaginez bien, cela coמtera bien plus cher qu'un recrutement ordinaire dans les tavernes de l'archipel. א chaque fois, la garnison sera complétée selon la configuration actuelle des garnisons.\nLa garnison peut être recrutée pour tous les sites : notre colonie, la plantation et les mines. א chaque fois, le trésor de la colonie doit contenir la somme permettant de recruter la garnison d'un site donné. Si cette somme n'est pas dans le trésor, le recrutement, bien entendu, n'aura pas lieu.";
			Link.l1 = "Merci pour l'information, " + npchar.name + ".";
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Costs":
			dialog.Text = "Pour quels sites souhaitez-vous connaître le coמt du recrutement ?";

			if(PChar.ColonyBuilding.Stage != "0")
			{
				Link.l1 = "La colonie.";
				Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Colony";
			}
			if(PChar.Mines.GoldMine == true || PChar.Mines.SilverMine == true || PChar.Mines.IronMine == true)
			{
				Link.l2 = "Les mines.";
				Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Mines";
			}
			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				Link.l3 = "La plantation.";
				Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Plantation";
			}

			Link.l4 = "Désolé, je dois y aller.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Colony":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison de la colonie, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Colony", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Colony", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Mines":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison des mines, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Mines", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Mines", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Cost_Plantation":
			dialog.Text = "א l'heure actuelle, le coמt du recrutement de la garnison de la plantation, compte tenu de son effectif actuel, est de " + ColonyGuardingGetCostForObject("Plantation", false) + " pièces d'or ; pour une garnison complète, sans tenir compte de l'effectif actuel : " + ColonyGuardingGetCostForObject("Plantation", true) + " pièces d'or.";
			Link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			Link.l1.go = "ColonyGuarding_Hovernor";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Set":
			dialog.Text = ColonyGuardingAutoCrewHireGetWork();

			if(PChar.ColonyBuilding.Stage != "0")
			{
				if(PChar.Colony.Guardians.Colony.AutoCrewHire == false)
				{
					Link.l1 = "Je veux profiter de la possibilité de recruter une garnison pour protéger la colonie.";
					Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_1";
				}
				else
				{
					Link.l1 = "Je veux suspendre le recrutement de la garnison qui protège la colonie.";
					Link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_1";
				}
			}

			if(PChar.Mines.GoldMine == true || PChar.Mines.SilverMine == true || PChar.Mines.IronMine == true)
			{
				if(PChar.Colony.Guardians.Mines.AutoCrewHire == false)
				{
					Link.l2 = "Je veux profiter de la possibilité de recruter une garnison pour protéger les mines.";
					Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_1";
				}
				else
				{
					Link.l2 = "Je veux suspendre le recrutement de la garnison qui protège les mines.";
					Link.l2.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_1";
				}
			}

			if(PChar.ColonyBuilding.Plantation == true && PChar.ColonyBuilding.Plantation.BuildingTime == false)
			{
				if(PChar.Colony.Guardians.Plantation.AutoCrewHire == false)
				{
					Link.l3 = "Je veux profiter de la possibilité de recruter une garnison pour protéger la plantation.";
					Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_1";
				}
				else
				{
					Link.l3 = "Je veux suspendre le recrutement de la garnison qui protège la plantation.";
					Link.l3.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_1";
				}
			}

			Link.l4 = "Désolé, je dois y aller.";
			Link.l4.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Colony_2":
			PChar.Colony.Guardians.Colony.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Mines_2":
			PChar.Colony.Guardians.Mines.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_1":
			dialog.text = "Vous êtes sמr, capitaine ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_2";
			link.l2 = LinkRandPhrase("Mm... Vous avez peut-être raison, mieux vaut y réfléchir encore.", "J'ai changé d'avis.", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_On_Plantation_2":
			PChar.Colony.Guardians.Plantation.AutoCrewHire = true;
			dialog.text = "Très bien, capitaine ! Je m'occupe de cette question dès aujourd'hui.";
			link.l1 = "Voilà qui est bien.";
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison de la colonie ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_2";
			link.l2 = LinkRandPhrase("Oui, c'est un ordre !", "J'ai sans doute changé d'avis...", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Colony_2":
			PChar.Colony.Guardians.Colony.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison des mines ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_2";
			link.l2 = LinkRandPhrase("Oui, c'est un ordre !", "J'ai sans doute changé d'avis...", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Mines_2":
			PChar.Colony.Guardians.Mines.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_1":
			dialog.text = "Voulez-vous vraiment suspendre le recrutement de la garnison de la plantation ?";
			link.l1 = LinkRandPhrase("Oui.", "Absolument.", "Bien sמr que j'en suis sמr.");
			link.l1.go = "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_2";
			link.l2 = LinkRandPhrase("Oui, c'est un ordre !", "J'ai sans doute changé d'avis...", "Euh... Non, je n'en suis pas sמr.");
			link.l2.go = "exit";
		break;

		case "ColonyGuarding_Hovernor_AutoCrewHire_Off_Plantation_2":
			PChar.Colony.Guardians.Plantation.AutoCrewHire = false;
			dialog.text = "Comme vous voudrez, capitaine.";
			link.l1 = LinkRandPhrase("Merci.", "Je vois.", "Bien.");
			link.l1.go = "exit";
		break;
		// <-- Самостоятельное плавание компаньона
	}
}

void FireImmortalOfficer(ref chr)
{
	if (CheckAttribute(chr, "ImmortalOfficer"))
	{
		DeleteAttribute(chr, "ImmortalOfficer")
		pchar.Option_ImmortalOfficers = sti(sti(pchar.Option_ImmortalOfficers) - 1);
	}
}
