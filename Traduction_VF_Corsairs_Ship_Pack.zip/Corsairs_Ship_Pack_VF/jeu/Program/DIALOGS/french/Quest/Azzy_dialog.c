
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog,"Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

// ============================================================================
// ============================= блок angry ==========>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckAttribute(npchar, "angry") && !CheckAttribute(npchar, "angry.ok"))
    {
        npchar.angry.ok = 1;
        if (!CheckAttribute(npchar, "angry.first")) //ловушка первого срабатывания
        {
            NextDiag.TempNode = NextDiag.CurrentNode;
            Dialog.CurrentNode = "AngryExitAgain";
            npchar.angry.first = 1;
        }
        else
        {
			Dialog.CurrentNode = "AngryQuest";
        }
    }
// <<<<<<<<<<<<<<<<<<<<<<======= блок angry ===================================
// ============================================================================

	switch(Dialog.CurrentNode)
	{
		// ----------------------------------- Диалог первый - первая встреча
		case "First time":
        	dialog.text = "Bonjour, " + GetFullName(pchar) + ". Le vent frais, la mer... J'aime ça. C'est bien ce genre de tenue qu'on porte maintenant ?";
    		link.l1 = "Oui, la tenue est parfaite... J'étais à l'instant au chantier naval de " + XI_ConvertString("Colony"+pchar.questTemp.Ascold.ShipyarderColony+"Gen") + " !!! Qu'est-ce que je fais ici ?! Qu'est-ce qui se passe, bon sang ?!!";
    		link.l1.go = "Step_1";
		break;

		case "Step_1":
        	dialog.text = "Ne t'inquiète pas tant\n"+
                          "Premièrement, je ne suis pas un vulgaire diable, mais un démon ! Je t'ai emprunté, nous allons parler, et ensuite je te remettrai à ta place\n"+
                          "Et deuxièmement, merci d'avoir ouvert la lampe.";
    		link.l1 = "Quoi ?! Encore ?!!!";
    		link.l1.go = "Step_2";
		break;

		case "Step_2":
        	dialog.text = "Tu parles de Leif Eriksson ? Ne t'inquiète pas, je ne vais pas te forcer à me trouver des objets ni à prendre des villes d'assaut\n"+
                          "J'ai passé beaucoup de temps dans cette lampe, j'ai bien d'autres choses à faire en ce moment.";
       		link.l1 = "Et l'échange de corps ? Tu ne vas pas faire ça non plus ?";
    		link.l1.go = "Step_3";
		break;

		case "Step_3":
        	dialog.text = "Non. C'est interdit par la circulaire 15315/28. Et pourquoi ?";
    		link.l1 = "Ouf, tant mieux... écoute, Leif est-il plus puissant que toi, démon ?";
    		link.l1.go = "Step_4";
		break;

		case "Step_4":
        	dialog.text = "Qu'est-ce qui te fait dire ça ? Ah, parce qu'il a échangé les corps deux fois ?"+
                          "Je suis un démon, et pas des moindres dans notre hiérarchie. Je peux te donner n'importe quoi, y compris n'importe quel corps. Cependant, la circulaire 15315/28 du Département de l'audit et du contrכle de l'Enfer n'autorise pas l'échange de corps sans le consentement de la mort et les documents correspondants\n"+
                          "Et Leif n'est qu'un petit escroc, qui a glané des rituels occultes indiens et a réussi à m'invoquer. Et le plus triste, c'est qu'il a réussi à me tromper, même si tout était de ma faute...";
    		link.l1 = "Comment ça ? Pardon pour la question, bien sמr, mais c'est très intéressant.";
    		link.l1.go = "Step_5";
		break;

		case "Step_5":
        	dialog.text = "Oui, pas de problème. J'éprouve une certaine gratitude envers toi, parce que tu as ouvert cette boîte en fer-blanc au lieu de la remettre à l'וglise\n"+
                          "Donc, ce salaud de Leif, sur ses vieux jours, s'est mis à réfléchir au moyen d'obtenir l'immortalité, et toutes les routes qui mènent à ce but passent par l'Enfer\n"+
                          "Leif, qui avait alors parcouru la moitié du continent qu'on appelle aujourd'hui l'Amérique et visité de nombreuses tribus locales, avait appris pas mal de sortilèges puissants. Autrement dit, il était devenu un bon sorcier, au sens européen du terme. D'ailleurs, le tour de la transmigration des âmes entre deux corps, il l'a appris des Aztèques\n"+
                          "En Europe, il s'adonnait aussi à l'obscurantisme (il a eu de la chance et a reçu un surnom : l'Heureux), il savait donc que si un démon se trouve à proximité au moment de la mort, l'âme ne quitte pas le corps pour le Jugement dernier\n"+
                          "Et Leif a trouvé chez les Toltèques un rituel efficace d'invocation des démons. Il a lancé le rituel et, malheureusement, c'est moi qu'il a invoqué.";
    		link.l1 = "Alors comment a-t-il réussi à te tromper, puisque les démons savent tout !";
    		link.l1.go = "Step_6";
		break;

		case "Step_6":
        	dialog.text = "Nous savons, c'est vrai. Mais vois-tu, nous utilisons cette procédure d'invocation pour recevoir l'âme et le corps d'un mortel directement en Enfer, en évitant le bureau du Jugement dernier\n"+
                          "Les imbéciles de mortels ne manquent pas : ils essaient de nous enfermer dans une bouteille spécialement préparée, pour que nous exaucions leurs désirs. Sous le serment de ne pas fermer la bouteille, en gage de leur propre âme, nous y entrons tranquillement, et l'instant d'après, la bouteille se retrouve toujours fermée\n"+
                          "Les mortels croient que l'affaire est dans le sac, mais chacun de nous porte au doigt une bague de diamant, justement pour ce genre de cas. En s'en servant comme d'un coupe-verre, nous nous libérons, et nous prenons l'âme et le corps par-dessus le marché.";
    		link.l1 = "Et Leif ne s'est pas servi d'une bouteille, mais d'une boîte en fer-blanc...";
    		link.l1.go = "Step_7";
		break;

		case "Step_7":
        	dialog.text = "Exactement. C'est dans ce genre de boîtes qu'on enferme les démons orientaux, les djinns esclaves. Leif s'est servi de la lampe du génie pour m'emprisonner\n"+
                          "Et il a fallu qu'il fasse la procédure d'invocation le lendemain de la nuit de Walpurgis, ma fête préférée sur Terre\n"+
                          "Comme toujours, j'avais passé cette fête dans une gaieté extrême. J'aime bien, vois-tu, séduire les filles de la Terre, et les sorcières gothiques sont si chaudes\n"+
                          "Bref, avec la gueule de bois, je n'ai même pas vu oם j'allais. C'est comme ça que je me suis fait prendre. Et après mon emprisonnement, Leif a envoyé à sa famille une lettre oם il décrivait le rituel de sa résurrection. Le Français de La Fontaine a trouvé cette lettre, et toi, tu as mis le rituel en marche.";
    		link.l1 = "וcoute, tes collègues démons n'auraient pas pu te libérer ?";
    		link.l1.go = "Step_8";
		break;

		case "Step_8":
        	dialog.text = "Non, je n'étais pas de service à ce moment-là, j'avais pris un congé illimité. Et ceux qui traînent sur Terre en quête de distractions personnelles, le bureau de l'Enfer ne les aime pas trop. Alors je suis dans le pétrin, ne me fais pas tourner en bourrique.";
    		link.l1 = "Oui, je ne sais même pas quoi dire...";
    		link.l1.go = "Step_9";
		break;

		case "Step_9":
        	dialog.text = "Et que dire ? Le démon fanfaron Azzie, comme le dernier des pigeons de la Terre.";
    		link.l1 = "Oh, tu t'appelles donc Azzie ?! Ravi de faire ta connaissance.";
    		link.l1.go = "Step_10";
		break;

		case "Step_10":
        	dialog.text = "Moi aussi. Vu que cette rencontre a abouti à ma libération, j'en suis doublement content\n"+
                          "Cependant, maintenant, tu connais mon nom et tu peux accomplir le rituel de mon invocation. J'espère que tu ne me dérangeras pas pour rien\n"+
                          "Je n'aime vraiment pas ça, vois-tu. Alors je serai de mauvaise humeur, et ma bonne disposition envers toi disparaîtra en un instant. Et quand je suis en colère, je fais peur...";
    		link.l1 = "Je ne connais même pas les rituels. Je suis un parfait profane en la matière. Il faudrait que je coure chez les Toltèques, ou je ne sais qui, chez qui Leif a pris le rite...";
    		link.l1.go = "Step_11";
		break;

		case "Step_11":
        	dialog.text = "Vois par toi-même, je ne t'aiderai certainement pas sur ce point. Tout ce dont tu as besoin, ou plutכt tout ce que tu veux prendre, je te le donnerai maintenant.";
    		link.l1 = "Hum... Des cadeaux des mauvais esprits ? Franchement, je ne me souhaite aucun mal.";
    		link.l1.go = "Step_12";
		break;

		case "Step_12":
        	dialog.text = "Le bien, le mal... Les deux faces d'une même pièce\n"+
                          "Le zoroastrisme, à l'époque du roi perse Darius, est la première religion de l'histoire de l'humanité à s'être approchée de la compréhension de l'essence des choses, mais le prophète Zoroastre était très loin de la vérité\n"+
                          "Le bien et le mal sont souvent si étroitement mêlés qu'il est très difficile de les distinguer. Et l'essence de ce qui se passe est toujours loin d'être claire.";
    		link.l1 = "Comment ça ?";
    		link.l1.go = "Step_13";
		break;

		case "Step_13":
        	dialog.text = "C'est difficile à expliquer exactement en termes humains, mais prenons un exemple\n"+
                          "Supposons que tu aies guéri quelqu'un d'une grave maladie : c'est une bonne action. Mais ta bonne action est une mauvaise action envers sa malheureuse belle-fille\n"+
                          "Ou supposons que tu aies estropié quelqu'un : c'est le mal. Mais cette mauvaise action sera une bénédiction pour cette même belle-fille, qui souffre de son tyran de beau-père.";
    		link.l1 = "Hum, voilà donc comment c'est...";
    		link.l1.go = "Step_14";
		break;

		case "Step_14":
        	dialog.text = "En fin de compte, les forces du mal et du bien, dans leur affrontement, commettent des actes difficiles à qualifier de façon univoque\n"+
                          "Ainsi, il n'est absolument pas nécessaire que je me mette à semer le mal autour de toi dès maintenant. Rien ne m'y oblige, même si je suis un démon.";
    		link.l1 = "Alors, je peux faire des vœux, et tu les exauceras ?";
    		link.l1.go = "Step_15";
		break;

		case "Step_15":
        	dialog.text = "En principe, oui. Cependant, il y a un très grand MAIS\n"+
                          "Il tient au fait que nos relations avec les mortels sont réglementées par des circulaires. Je t'ai déjà donné un exemple : l'échange de corps\n"+
                          "Je ne peux agir que dans le cadre de ces règles. Alors, parlons de tes vœux.";
        	link.l1 = "Avec plaisir.";
    		link.l1.go = "Wishes";
		break;

		case "Wishes":
            dialog.text = LinkRandPhrase("Je t'écoute attentivement. Que veux-tu ?", "Alors, que veux-tu ?" , "Je t'écoute. Que veux-tu ?");
    		link.l1 = "Que tu tues mes ennemis.";
    		link.l1.go = "ToKillEnemy";
    		link.l2 = "De l'argent.";
    		link.l2.go = "ToGiveMoney";
    		link.l4 = "Du rhum.";
    		link.l4.go = "ToGiveRum";
    		link.l5 = "Un bon navire.";
    		if(!CheckAttribute(pchar, "GenQuest.GhostShip.LastBattle"))	link.l5.go = "ToShip";
			else link.l5.go = "ToShipAlt";
    		link.l6 = "L'immortalité.";
    		link.l6.go = "ToImmortal";
    		link.l7 = "Devenir gouverneur général de la Jamaïque.";
    		link.l7.go = "ToGovernor";
    		link.l8 = "Devenir "+ GetSexPhrase("le plus fort, le plus adroit, le plus malin, le plus chanceux","la plus forte, la plus adroite, la plus maligne, la plus chanceuse") +"...";
    		link.l8.go = "ToAddSpecial";
    		link.l9 = "C'est tout, je ne veux rien de plus. De toute façon, rien ne me vient à l'esprit.";
    		link.l9.go = "ToEnd";
		break;

		case "ToKillEnemy":
			dialog.text = NPCStringReactionRepeat("Tuer des gens selon ta volonté ? Une façon complètement erronée de comprendre les forces du Mal.",
                                           "Nous avons déjà parlé de ce souhait.",
                                           "Je t'ai dit que nous avions déjà parlé de ce vœu. Ne m'énerve pas, je pourrais perdre patience.",
                                           "Bon, on dirait que tu es complètement dérangé. Alors, adieu, et bonne mort.", "quest", 0, npchar, Dialog.CurrentNode);
            link.l1 = HeroStringReactionRepeat("Je n'ai pas bien compris... Et qu'est-ce que la compréhension vient faire là-dedans ?", "Oui, c'est vrai, c'est tout. Parlons du reste.", "Pardon, je ne voulais pas t'énerver. Continuons.", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
			link.l1.go = DialogGoNodeRepeat("Step_16", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_16":
        	dialog.text = "Oui, je te le dis, " + GetFullName(pchar) + " : les forces du mal, à de très rares exceptions près, ne tuent pas les gens. Les histoires d'horreur que te racontent depuis l'enfance nourrices et grands-mères ne sont que des contes de fées.";
    		link.l1 = "Mais vous êtes après nos âmes !";
    		link.l1.go = "Step_17";
		break;

    	case "Step_17":
        	dialog.text = "C'est vrai, tout comme les forces du bien chassent ces mêmes âmes\n"+
                          "Tuer quelqu'un ne veut pas du tout dire que son âme ira en Enfer : c'est le conseil du Jugement dernier qui en décide. La tâche des forces des ténèbres est de faire pencher la décision en notre faveur\n"+
                          "Et on y parvient non pas en tuant quelqu'un, mais en flattant ses vices. Ce sont ses propres actes qui doivent nous livrer son âme. Les passions dans l'âme d'un mortel doivent passer de la braise qui couve à la flamme dévorante, et chacun a une telle braise dans son âme...";
    		link.l1 = "Hum, entre dans n'importe quelle grotte de l'archipel, c'est plein de tes semblables. Si tu rêvasses un peu, ils te font sauter la tête, sans trop se soucier de flatter mes vices...";
    		link.l1.go = "Step_18";
		break;

		case "Step_18":
        	dialog.text = "Oh, ça... Ces foules démentes n'ont pas grand-chose à voir avec les forces du mal. Les âmes de certains défunts n'arrivent pas au bureau du Tribunal suprême, il y a plusieurs raisons à cela\n"+
                          "Nous avons des démons indiens, ils sont regroupés dans un département à part, que dirige le dieu aztèque Mictlantecuhtli. C'est cette bande qui force une âme, ayant déjà perdu conscience après la mort, à diriger un cadavre, et pas forcément le sien\n"+
                          "Faire bouger un cadavre est une tâche coמteuse et pénible, mais à ce que je sais, ils ont trouvé le moyen d'y atteler des élémentaux tirés de l'énergie naturelle pure. Si bien que ces cadavres ambulants sont en somme autonomes\n"+
						  "Je n'ai aucune idée de la raison pour laquelle les Peaux-Rouges en ont besoin. Ils restent entre eux, leur département ne rend de comptes qu'à la haute direction. Ils sont bizarres\n"+
                          "De plus, tuer des personnes sans justification est interdit par la circulaire 55115/13.";
    		link.l1 = "Alors, tu ne pourras tuer personne selon ma volonté ?";
    		link.l1.go = "Step_19";
		break;

		case "Step_19":
        	dialog.text = "Si, je peux. Je passerai au fil de l'épée toute la ville la plus proche, si tu le souhaites. Il n'y a qu'une condition : je prendrai ton âme immortelle pour ce service\n"+
                          "Mais d'abord, je déchirerai et dévorerai ton corps : je suis un démon, et le Département du contrכle et de l'audit de l'Enfer surveille de près l'exécution de leurs fonctions officielles par les démons\n"+
						  "Mais si tu es si sanguinaire, je peux te donner cette épée maudite, elle t'aidera à tuer tes ennemis\n"+
                          "D'accord ?";
			log_info("Vous avez reçu l'épée d'Iris.");
			TakeNItems(pchar,"blade013",1);			  
    		link.l1 = "D'accord, donne-moi ton épée. Je n'ai pas du tout l'intention de vendre mon âme. Parlons d'autres vœux.";
    		link.l1.go = "Wishes";
		break;

		case "ToGiveMoney":
        	dialog.text = NPCStringReactionRepeat("C'est possible.", "Nous avons déjà parlé de ce vœu.", "Je le répète, nous avons déjà parlé de ce vœu, tu ne devrais pas m'ennuyer.", "On dirait que tu es la personne la plus ennuyeuse et la plus assommante de ce monde. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
            link.l1 = HeroStringReactionRepeat("Et alors, tu vas exiger mon âme en échange ?", "C'est vrai, nous en avons parlé. Parlons d'autres vœux.", "Pardon, je ne voulais pas t'énerver. Continuons.", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
            link.l1.go = DialogGoNodeRepeat("Step_20", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_20":
        	dialog.text = "En fait, c'est ce que font les démons : l'argent, les bijoux, l'or, et ensuite, l'âme file tout droit en enfer. Mais je suis un démon, je n'ai pas l'intention de m'abaisser à une petite escroquerie\n"+
                          "D'ailleurs, tu m'as rendu un service, je ne veux pas te faire de mal.";
    		link.l1 = "Ou-ou-ouf, ça fait plaisir...";
    		link.l1.go = "Step_21";
		break;

		case "Step_21":
        	dialog.text = "Je vais te procurer de l'argent. Mais je ne te le donnerai pas moi-même\n"+
                          "א Charlestown, va voir un usurier, il s'appelle " + GetFullName(characterFromId("Charles_usurer")) + ". Dis-lui qu'il te doit trois millions, et tu recevras immédiatement la somme entière.";
    		link.l1 = "Hum, il t'a déjà vendu son âme ?";
    		link.l1.go = "Step_22";
    		pchar.questTemp.Azzy.GiveMoney = 1;
		break;

		case "Step_22":
        	dialog.text = "Ha ha ha ! Tout homme qui prête de l'argent à intérêt nous a déjà vendu son âme\n"+
                          "Certains ne s'en rendent simplement pas compte. Jusqu'à un certain moment..\n"+
                          "Bon, ne nous dispersons pas. Tu es content ? Ou ton âme réclame-t-elle encore l'exaucement de ses vœux ? Ha ha !";
    		link.l1 = "Ou-ou-ouf, j'aimerais revoir la liste des prix.";
    		link.l1.go = "Wishes";
		break;

		case "ToGovernor":
        	dialog.text = NPCStringReactionRepeat("Très bien. Désormais, tu es gouverneur de la Jamaïque. Pas de problème.",
                                                  "Tu es déjà devenu gouverneur.",
                                                  "Je t'ai déjà fait gouverneur de la Jamaïque. Je recommence ?",
                                                  "On dirait que tu es la personne la plus stupide de la Terre. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Alors, je peux aller dans ma résidence de Port Royal ? Et la flotte anglaise des Caraïbes sera sous mes ordres ? Et je pourrai correspondre avec le roi ?", "Oui, c'est vrai. Je veux devenir gouverneur de la Jamaïque...", "Je ne sais même pas si ça en vaut la peine ?", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_25", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_25":
        	dialog.text = "Eh bien, comment te dire... C'est plus compliqué.";
    		link.l1 = "Quelles difficultés ? Tu m'as fait gouverneur de la Jamaïque !";
    		link.l1.go = "Step_26";
		break;

		case "Step_26":
        	dialog.text = "C'est vrai. Cependant, je t'ai seulement fait gouverneur, je n'ai eu aucun effet sur le monde qui t'entoure.";
    		link.l1 = "Alors, les gens autour de moi ne me percevront pas comme un gouverneur ? Alors à quoi bon tout ça ?";
    		link.l1.go = "Step_27";
		break;

		case "Step_27":
        	dialog.text = "Comment le saurais-je, à quoi ça te sert ? Tu voulais être gouverneur, je t'ai fait gouverneur\n"+
                          "Cependant, pour que le monde extérieur te perçoive comme un gouverneur, je vais devoir changer le cours des événements dans le passé\n"+
                          "Je vais devoir simuler toute la chaîne d'événements qui t'a mené au fauteuil de gouverneur. Par conséquent, les événements du monde environnant et les gens qui t'entourent seront aussi modifiés. א quoi cela mènera en fin de compte, même moi, je ne peux pas le dire avec certitude\n"+
                          "Autrement dit, il se peut très bien que le monde change au point d'en être méconnaissable. Et il faudra que je me débarrasse de la réalité existante, conformément à la circulaire départementale 315/188\n"+
                          "Es-tu prêt à un tel retournement ?";
    		link.l1 = "Non, pas prêt ! Tout est compliqué, chez toi...";
    		link.l1.go = "Step_28";
		break;

		case "Step_28":
        	dialog.text = "א la place, prends ce bracelet. Porte-le au poignet, et tout le monde t'aimera, tu verras, tu seras gouverneur, hé.";
			log_info("Vous avez reçu « le Calomniateur ».");
			TakeNItems(pchar,"talisman17",1);
    		link.l1 = "C'est toujours ça... Voyons ce que tu as d'autre à me proposer.";
    		link.l1.go = "Wishes";
		break;

		case "ToImmortal":
        	dialog.text = dialog.text = NPCStringReactionRepeat("Tu veux l'immortalité ? C'est possible. Précisons seulement ce que tu entends exactement par le mot immortalité. Tu veux que ton âme ne quitte pas ton corps pour les diverses raisons qui causent d'ordinaire la mort ? C'est ça ?",
                                    "Nous avons déjà parlé de l'immortalité.",
                                    "Je le répète, nous avons déjà parlé de la question de l'immortalité, tu ne devrais pas m'agacer.",
                                    "On dirait que tu es la personne la plus stupide du monde sublunaire. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Eh bien, en fait, oui...", "Oui, exactement, la question de l'immortalité est close.", "Nous avons tout discuté et tout réglé, tu as tout à fait raison !", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_29", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_29":
        	dialog.text = "דa peut s'arranger. Seulement, tu dois comprendre que les blessures qu'on t'infligera au combat entraîneront la décomposition de ton corps\n"+
                          "Bientכt, tu deviendras l'une de ces créatures qui infestent les catacombes d'ici : un cadavre vivant, semblable à mon ami Leif. C'est de ça que nous parlons ?";
    		link.l1 = "Non, pas de ça. Pour être précis, je veux que les lames et les balles de l'ennemi ne puissent pas blesser mon corps.";
    		link.l1.go = "Step_30";
		break;

		case "Step_30":
        	dialog.text = "Maintenant, c'est clair. Seulement, ce n'est pas l'immortalité, c'est l'invulnérabilité. On peut arranger ça\n"+
                          "Seulement, il y a un problème : une lourde charge de travail pour la mise en œuvre. Lier l'âme au corps pour toujours, c'est une broutille. Mais garder le corps intact sous une grêle de balles, ça demande une sérieuse dépense d'énergie.";
    		link.l1 = "Quoi ?! Azzie, tu es un démon, un être surnaturel. Tu peux tout faire, et tu viens me parler de charge de travail...";
    		link.l1.go = "Step_31";
		break;

		case "Step_31":
        	dialog.text = "Qu'est-ce que tu croyais ? Nous vivons tous selon les lois de l'univers, c'est juste que tu ne connais pas ces lois\n"+
                          "Bref, voilà : si tu veux l'invulnérabilité, je te dirai que tu dois fournir un certain travail.";
    		link.l1 = "Je veux. Dis-moi ce que je dois faire.";
    		link.l1.go = "Step_32";
		break;

		case "Step_32":
        	dialog.text = "Donc, tu signes un contrat avec le Département de la comptabilité humaine de l'Enfer. En vertu de ce contrat, tu dois fournir à ce Département infernal la quantité nécessaire d'énergie vitale, que les Chinois appellent le qi\n"+
                          "L'énergie naturelle pure, qui nourrit tous ces mauvais esprits des grottes et des catacombes, convient aussi.";
    		link.l1 = "Comment l'assurer ? Que dois-je faire exactement pour obtenir cette énergie ?";
    		link.l1.go = "Step_33";
		break;

		case "Step_33":
        	dialog.text = "Tu dois faire ce que tu fais déjà tous les jours : envoyer des gens et des mauvais esprits dans l'autre monde\n"+
                          "Et le Département de l'Enfer crédite automatiquement l'énergie libérée sur ton compte, qui sert à assurer ton invulnérabilité.";
    		link.l1 = "On ne peut pas faire autrement ? J'envoie bien des gens dans l'autre monde tous les jours, mais je le fais de mon plein gré...";
    		link.l1.go = "Step_34";
		break;

		case "Step_34":
        	dialog.text = "וcoutez, "+ GetSexPhrase("mon cher","ma chère") +", je te rends un immense service. Tu crois que de tels contrats avec le Département de l'enregistrement des humains de l'Enfer, ça se trouve sous le pas d'un cheval ?"+
                          "De tels contrats sont rares et exclusifs. Il n'y a pas d'autre moyen, il n'y a pas de miracles en ce monde.";
    		link.l1 = "Combien de gens ou de mauvais esprits dois-je tuer pour que mon système d'invulnérabilité fonctionne normalement ?";
    		link.l1.go = "Step_35";
		break;

		case "Step_35":
        	dialog.text = "C'est le Département, en tant que maître d'œuvre, qui le détermine. Mais il n'y a pas de problème particulier : quelques unités par jour, et c'est tout\n"+
                          "Je te le dis, tu le fais tous les jours. Je ne vois pas de problème..\n"+
                          "Alors, tu es d'accord ?";
    		link.l1 = "Oui, d'accord. Je dois signer avec mon sang ?";
    		link.l1.go = "Step_36";
    		link.l2 = "Non, je ne suis pas d'accord. Que tout reste comme avant. Voyons ce que tu as d'autre pour exaucer mes vœux.";
    		link.l2.go = "Wishes";
		break;

		case "Step_36":
        	dialog.text = "Avec ton sang ?! Hé, oם as-tu lu ces romans d'épouvante bon marché ?"+
                          "Dis simplement : « Moi, " + GetFullName(pchar) + ", en pleine possession de mes moyens, je conclus un contrat avec le démon Azzie pour assurer l'invulnérabilité de mon corps. »";
    		link.l1 = "Moi, " + GetFullName(pchar) + ", en pleine possession de mes moyens, je conclus un contrat avec le démon Azzie pour assurer l'invulnérabilité de mon corps.";
    		link.l1.go = "Step_37";
		break;

		case "Step_37":
        	dialog.text = "Eh bien, c'est fait. Le texte du contrat a été inscrit pour toi dans le journal de bord, lis-le à ton aise\n"+
                          "Mes félicitations. Tu es désormais complètement invulnérable.";
    		link.l1 = "C'est formidable ! וcoute, je veux voir ce que tu peux encore me proposer pour exaucer mes vœux.";
    		link.l1.go = "Wishes";
    		LAi_SetImmortal(pchar, true);
            SetQuestHeader("ContractWithHell");
            AddQuestRecord("ContractWithHell", "1");
			AddQuestUserData("ContractWithHell", "Conrtragent", GetFullName(pchar));
            pchar.questTemp.Azzy.Immortal = 1;
            SaveCurrentQuestDateParam("questTemp.Azzy");
            SaveCurrentQuestDateParam("questTemp.Azzy.Immortal");
            pchar.questTemp.Azzy.Immortal.AllQuota = 0;
            pchar.questTemp.Azzy.Immortal.DayQuota = 3; //ежедневный норматив
            pchar.questTemp.Azzy.Immortal.CurBalance = 0;
            pchar.questTemp.Azzy.Immortal.CurKilled = 0;
            pchar.questTemp.Azzy.Immortal.Penalty = 0;
            pchar.questTemp.Azzy.Immortal.EarlyKilled = Statistic_AddValue(PChar, "Solder_s", 0) +
                                                 Statistic_AddValue(PChar, "Solder_g", 0) +
                                                 Statistic_AddValue(PChar, "Warrior_s", 0) +
                                    	         Statistic_AddValue(PChar, "Warrior_g", 0) +
                                    	         Statistic_AddValue(PChar, "Citizen_s", 0) +
                                    	         Statistic_AddValue(PChar, "Citizen_g", 0) +
                                    	         Statistic_AddValue(PChar, "Monster_s", 0) +
                                    	         Statistic_AddValue(PChar, "Monster_g", 0);
            AddQuestRecord("Azzy_HellSign", "1");
			AddQuestUserData("Azzy_HellSign", "sName", GetMainCharacterNameGen());
			AddQuestUserData("Azzy_HellSign", "DayQuota", pchar.questTemp.Azzy.Immortal.DayQuota);
			AddQuestUserData("Azzy_HellSign", "AllQuota", pchar.questTemp.Azzy.Immortal.AllQuota);
			AddQuestUserData("Azzy_HellSign", "CurKilled", pchar.questTemp.Azzy.Immortal.CurKilled);
			AddQuestUserData("Azzy_HellSign", "CurBalance", pchar.questTemp.Azzy.Immortal.CurBalance);
		break;

		case "ToGiveRum":
        	dialog.text = NPCStringReactionRepeat("Tu as plein d'argent. Tu ne peux pas te payer du rhum ?",
                                    "Encore le rhum ? La question est réglée...",
                                    "Ne m'énerve pas, je ne veux pas me répéter.",
                                    "On dirait que tu es la personne la plus stupide du monde sublunaire. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Je peux, et je le fais. Mais tu sais, aujourd'hui il y a de l'argent, demain il n'y en aura peut-être plus. Et j'ai toujours envie de rhum !", "C'est vrai, nous avons tout réglé !", "Désolé...", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_38", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_38":
        	dialog.text = "Eh bien, ça peut s'arranger. Convenons ainsi : si tu as besoin de rhum, tu pourras en obtenir gratuitement au magasin de Port-au-Prince, auprès d'un marchand nommé " + GetFullName(characterFromId("PortPax_trader")) + ".";
    		link.l1 = "D'accord, ce serait formidable ! Du rhum gratuit, c'est le rêve d'un pirate ! Et je ne te devrai rien pour ça ?";
    		link.l1.go = "Step_39";
    		pchar.questTemp.Azzy.GiveRum = 1;
		break;

		case "Step_39":
        	dialog.text = "Rien. Je le fais sur mes propres ressources, je n'implique personne d'autre.";
    		link.l1 = "Voilà qui est bien. Bon, voyons ce que tu as encore d'intéressant pour exaucer mes vœux ?";
    		link.l1.go = "Wishes";
		break;

		case "ToAddSpecial":
        	dialog.text = NPCStringReactionRepeat("דa peut s'arranger. Alors, que veux-tu exactement ?",
                                    "Je t'ai envoyé chez une certaine personne, je ne vois pas l'intérêt de me répéter.",
                                    "Ne m'énerve pas, je ne veux pas me répéter.",
                                    "On dirait que tu es la personne la plus stupide du monde sublunaire. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Eh bien, je ne sais pas... De la force, ça ne ferait pas de mal, de la chance...", "Oui, c'est vrai, je trouverai le chemin pour aller la voir...", "Désolé...", "Comment ça, adieu ?!", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_40", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_40":
        	dialog.text = "Compris. Bref, il y a un bordel à Tortuga, tenu par une certaine Margarita. Cette femme est une sorcière, elle peut faire ce dont tu as besoin. Le temps que tu arrives chez elle, je me serai arrangé avec elle.";
    		link.l1 = "D'accord, j'irai la voir, merci. Et quels autres vœux peut-on faire ?";
    		link.l1.go = "Wishes";
    		pchar.questTemp.Azzy.AddSpecial = 1;
		break;

		case "ToShip":
        	dialog.text = NPCStringReactionRepeat("Que veut dire « bon » ?",
                                    "Nous avons déjà parlé des navires...",
                                    "Je comprends ton rêve du Hollandais volant, mais nous avons déjà tout discuté.",
                                    "On dirait que tu es la personne la plus stupide du monde sublunaire. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Qu'il surpasse n'importe quel navire existant en vitesse, que les voiles ne se déchirent ni sous le vent ni sous les boulets ramés, que les boulets rebondissent sur ses flancs sans faire de dégâts...", "Oui, les navires, c'est mon sujet préféré...", "Je parlais du Black Pearl, mais tout est vrai quand même.", "Comment ça, adieu ?! Et les navires ?", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_41", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;
		
		case "ToShipAlt":
        	dialog.text = NPCStringReactionRepeat("Que veut dire « bon » ?",
                                    "Nous avons déjà parlé des navires...",
                                    "Tu reparles du Hollandais volant ?! Assez avec les navires !",
                                    "On dirait que tu es la personne la plus stupide du monde sublunaire. Adieu.", "quest", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Qu'il surpasse n'importe quel navire existant en vitesse, que les voiles ne se déchirent ni sous le vent ni sous les boulets ramés, que les boulets rebondissent sur ses flancs sans faire de dégâts...", "Oui, les navires, c'est mon sujet préféré...", "Je parlais du Black Pearl...", "Comment ça, adieu ?! Et les navires ?", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_41", "Wishes", "Wishes", "", npchar, Dialog.CurrentNode);
		break;

		case "Step_41":
        	dialog.text = "Je ne ferai pas ça : c'est très cher.";
    		link.l1 = "Et le « Hollandais volant » ?";
			if(!CheckAttribute(pchar, "GenQuest.GhostShip.LastBattle"))	link.l1.go = "Step_42";
			else link.l1.go = "Step_42Alt";
		break;

		case "Step_42":
        	dialog.text = "Le « Hollandais volant » est sous le coup d'une grave malédiction. Toute une bande de démons indiens ne s'occupe que de suivre l'état de cette malédiction et de la maintenir en état de marche\n"+
                          "Ou tu vas me demander de rejoindre ton équipage pour assurer la sécurité de ton vaisseau et le maintenir en bon état ?!";
    		link.l1 = "Non, bien sמr, je n'y ai même pas pensé, cher Azzie...";
    		link.l1.go = "Step_43";
		break;

		case "Step_42Alt":
        	dialog.text = "Tu sais tout du Hollandais volant. Tu vas continuer à me faire tourner la tête ?";
    		link.l1 = "Non, bien sמr, je n'y ai même pas pensé, cher Azzie...";
    		link.l1.go = "Step_43";
		break;

		case "Step_43":
        	dialog.text = "Et c'est bien, car ce n'est pas sans danger pour toi\n"+
                          "Attends, pourtant, je ne me souviens pas exactement, mais la protection de la coque du navire est assurée dans le cadre d'un des contrats avec les mortels\n"+
                          "Bref, je te conseille de passer au chantier naval des Bermudes, c'est le Maître qui le dirige, il remet en état les voiliers du coin.";
    		link.l1 = "Cher Azzie, merci du conseil, je ne manquerai pas de le suivre. Maintenant, puis-je entendre autre chose au sujet de l'exaucement des vœux ?";
    		link.l1.go = "Wishes";
            if (CheckAttribute(pchar, "questTemp.Azzy.Immortal"))
		    {
            	dialog.text = "Attends, nous avons signé un contrat pour ton invulnérabilité. Eh bien, ce contrat prévoit aussi la sécurité de la coque de ton navire, pour que tu ne le coules pas par inadvertance en plein océan. Sinon, arrange-toi ensuite avec les sirènes pour qu'elles te tirent de l'abîme...";
        		link.l1 = "Azzie, c'est tout simplement formidable ! Puis-je entendre encore autre chose au sujet de l'exaucement des vœux ?";
		    }
		break;

		case "ToEnd":
        	dialog.text = "Tu m'as vraiment épuisé, mais j'ai mis ma patience à l'épreuve. Et que les anges ne viennent plus dire que les démons sont des créatures sauvages et effrénées\n"+
                          "C'était agréable de parler avec toi. Si jamais tu oses m'invoquer, je te promets qu'au moins, je t'écouterai, au lieu de dévorer ton corps sur-le-champ. Ha ha ha\n"+
                          "Au revoir, "+ GetSexPhrase("corsaire","" + pchar.name + "") +".";
    		link.l1 = "Adieu, Azzie. Merci.";
    		link.l1.go = "Back_Exit";
		break;

 		case "Back_Exit":
            LAi_LocationFightDisable(&Locations[FindLocation("Shore28")], false);
            LAi_LocationDisableOfficersGen("Shore28", false); // LEO: вернуть офицеров на Shore28 после сцены с демоном
 		    ChangeCharacterAddress(characterFromID("Azzy"), "None", "");
 		    DoReloadCharacterToLocation(pchar.questTemp.Ascold.ShipyarderColony + "_Shipyard", "reload", "reload2");
 		    LAi_SetPlayerType(PChar);
 		    NextDiag.TempNode = "Second time";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

 		case "Azzy_Exit":
            LAi_LocationDisableOfficersGen("Shore28", false); // LEO: вернуть офицеров на Shore28 после сцены с демоном
 		    ChangeCharacterAddress(characterFromID("Azzy"), "None", "");
 		    LAi_SetPlayerType(PChar);
 		    NextDiag.TempNode = "Death";
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

 		case "Exit":
            NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Second time":
        	dialog.text = "Allons bon, on m'appelle encore... " + GetFullName(pchar) + ", tu sais que je ne supporte pas ça. Maintenant, tu vas devoir te donner beaucoup de mal pour m'expliquer la raison.";
    		link.l1 = "Azzie, je veux rompre le contrat d'invulnérabilité.";
    		link.l1.go = "Step_44";
		break;

		case "Step_44":
        	dialog.text = "Pourquoi, tout à coup ? De tels contrats ne courent pas les rues. L'invulnérabilité, tu sais...";
    		link.l1 = "Azzie !!! Ton bureau de l'Enfer fait sans cesse monter les enjeux ! Je risque ma vie !!!";
    		link.l1.go = "Step_45";
		break;

		case "Step_45":
        	dialog.text = "Et ton âme immortelle. Qu'est-ce que tu croyais ? Fricoter avec les forces du mal mène un mortel en Enfer.";
    		link.l1 = "Azzie ! Je veux résilier le contrat. Il y a un paragraphe dans le texte qui prévoit ce cas. Mais il fallait que nous nous rencontrions, alors je t'ai appelé.";
    		link.l1.go = "Step_46";
		break;

		case "Step_46":
        	dialog.text = "Hum, bien. Dis : « Avec le consentement d'Azzie, je résilie le contrat de mon invulnérabilité. » Et c'est tout.";
    		link.l1 = "Avec le consentement d'Azzie, je résilie le contrat de mon invulnérabilité !!!";
    		link.l1.go = "Step_47";
		break;

		case "Step_47":
        	dialog.text = "Hum, avec quel sentiment c'est dit ! Bon, ce n'est rien : tu es de nouveau vulnérable. Le contrat est résilié.";
    		link.l1 = "Merci, Azzie. Tu m'as sauvé plus que la vie...";
    		link.l1.go = "Step_48";
			pchar.questTemp.Azzy = "over";
    		LAi_SetImmortal(pchar, false);
    		DeleteAttribute(pchar, "questTemp.Azzy.Immortal");
    		DeleteQuestHeader("ContractWithHell");
    		DeleteQuestHeader("Azzy_HellSign");
		break;

		case "Step_48":
        	dialog.text = "C'est vrai. Bon, disons-nous adieu, mortel. Pour toujours cette fois, car une nouvelle invocation te coמtera la vie\n"+
                          "Essaie d'expier tes péchés, tu y arriveras peut-être. Adieu...";
    		link.l1 = "Adieu, Azzie. Je ferai de mon mieux.";
    		link.l1.go = "Azzy_Exit";
			npchar.lifeDay = 0;
		break;
		//помощь ГГ, если вляпался с долгом у ростовщика ГПК
		case "ClimeUsurer":
			dialog.text = "Héhé... Alors, "+ GetSexPhrase("l'ami, on s'est fourré dans le pétrin","ma belle, on s'est fourrée dans le pétrin") +" ?";
			link.l1 = "Azzie, bon sang, je suis si content de te voir !!!";
			link.l1.go = "ClimeUsurer_1";
		break;
		case "ClimeUsurer_1":
			dialog.text = "Ne jure pas, je n'aime pas ça, qu'est-ce que tu crois faire ?";
			link.l1 = "Je croyais que c'était fini, que c'était ma fin. Maintenant, je ne le crois plus. Azzie, comme je suis content de te voir, mon ami !..";
			link.l1.go = "ClimeUsurer_2";
		break;
		case "ClimeUsurer_2":
			dialog.text = "Oui, et je dois l'avouer, moi aussi. Tu m'amuses, mortel. Il te faut toujours quelque chose, tu te mêles toujours de ce qui ne te regarde pas, et maintenant, tu as eu affaire aux démons indiens. C'était à prévoir...";
			link.l1 = "Azzie, je n'aurais jamais pu imaginer qu'on en arriverait là ! Au fait, oם suis-je, tu le sais ?";
			link.l1.go = "ClimeUsurer_3";
		break;
		case "ClimeUsurer_3":
			dialog.text = "Tu es à Tenochtitlan, l'ancienne capitale abandonnée des Aztèques. Le démon qui t'a pris s'appelle Mictlantecuhtli. Il se fait passer ici pour le roi des Aztèques morts.";
			link.l1 = "דa alors... Azzie, sors-moi de là, mon ami !";
			link.l1.go = "ClimeUsurer_4";
		break;
		case "ClimeUsurer_4":
			dialog.text = "Je ne sais même pas... Il t'a eu en bonne et due forme. Pourquoi as-tu pris l'argent ?";
			link.l1 = "Azzie, si j'avais su, je n'y serais allé pour rien au monde ! Je te le jure...";
			link.l1.go = "ClimeUsurer_5";
		break;
		case "ClimeUsurer_5":
			dialog.text = "Allez, je te crois : je vais te sortir d'ici, mais à l'avenir, regarde mieux oם tu mets les pieds. Tu me comprends ?";
			link.l1 = "Je comprends, je ne suis pas idiot.";
			link.l1.go = "ClimeUsurer_6";
		break;
		case "ClimeUsurer_6":
			dialog.text = "Bon, adieu, mortel.";
			link.l1 = "Merci, Azzie, du fond du cœur...";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("ClimeUsurer_haveMoney");
		break;

// ======================== блок нод angry ===============>>>>>>>>>>>>>>>
		//==> попытки дать денег
		case "AngryQuest":
            Dialog.text = GetFullName(pchar)+ ", il y a dans ce monde des choses bien plus intéressantes et agréables que de s'occuper d'un tel nigaud.";
			Link.l1 = "וcoute...";
		    Link.l1.go = "AngStep_1";
    	break;

		case "AngStep_1":
            Dialog.text = "Je n'écouterai rien ! Adieu, mortel...";
			Link.l1 = "...";
		    Link.l1.go = "Back_Exit";
            DeleteAttribute(npchar, "angry.ok");
            Dialog.CurrentNode = "Back_Exit";
    	break;

		case "AngryExitAgain":
            LAi_LocationDisableOfficersGen("Shore28", false); // LEO: вернуть офицеров на Shore28 после сцены с демоном
 		    ChangeCharacterAddress(characterFromID("Azzy"), "None", "");
 		    LAi_SetPlayerType(PChar);
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
            DeleteAttribute(npchar, "angry.ok");
		break;

// <<<<<<<<<<<<============= блок нод angry =============================
	}
}


