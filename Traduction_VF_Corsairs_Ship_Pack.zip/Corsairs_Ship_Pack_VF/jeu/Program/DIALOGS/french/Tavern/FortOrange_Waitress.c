// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (pchar.questTemp.Slavetrader == "FindRatJamaica_W")
            {
                link.l1 = "וcoute, ma chérie, on dit que tu as été très proche de mon ami François Gontier. Très proche...";
                link.l1.go = "Jamaica_ratW_1";
            }

			if (pchar.questTemp.Slavetrader == "FindRatJamaica_WP")
            {
				if (CheckCharacterItem(pchar, "jewelry15"))
				{
					link.l1 = "Je t'apporte tes pendentifs. Tiens.";
					link.l1.go = "Jamaica_ratW_5";
				}
				else
				{
					link.l1 = "Rien pour l'instant. Je cherche tes pendentifs.";
					link.l1.go = "exit";
				}
            }

		break;

        case "DefenceOrange": //Голландская линейка, квест №4, защита форта Оранж.
            dialog.text = "Oh, "+ GetSexPhrase("mynheer", "madame") +", je suis juste heureuse d'être en vie ! Et je suis aussi heureuse...";
            link.l2 = "Et de quoi d'autre ?";
            link.l2.go = "Step_H4_1";
        break;

        case "Step_H4_1":
			dialog.text = ""+ GetSexPhrase("Et je suis aussi heureuse de voir un capitaine et un officier aussi formidable ! Tout le fort vous est reconnaissant, vous venez de nous sauver !", "Et je suis aussi heureuse qu'il existe au monde des femmes aussi courageuses ! Tout le fort vous est reconnaissant, vous venez de nous sauver !") +"";
			link.l1 = "Allons, "+ GetSexPhrase("ma belle", "ma fille") +", je n'ai fait que mon devoir...";
			link.l1.go = "exit";
			NextDiag.TempNode = "First time";
		break;

		case "Jamaica_ratW_1":
            dialog.text = "Oui, c'est vrai, et alors ? Je suis une fille célibataire, je fréquente qui je veux. François est un marin très remarquable, pas comme nos pêcheurs et nos paysans du coin. Il est tellement... Ah ! Et quels cadeaux il m'a faits !";
            link.l1 = "Stop, stop, ça suffit ! Je connais les mérites de mon ami, inutile de me les vanter. Ce qui s'est passé entre vous m'est égal, mariez-vous si ça vous chante. Je dois le retrouver d'urgence, tu comprends ? Tu sais oם il est parti ?";
            link.l1.go = "Jamaica_ratW_2";
        break;

		case "Jamaica_ratW_2":
            dialog.text = "Hi hi... Vous êtes son "+ GetSexPhrase("copain", "amie, hi hi") +", et vous ne savez pas oם il est parti. C'est drכle !";
            link.l1 = "Il n'y a rien de drכle, ma petite. Nous avions convenu de nous retrouver en Jamaïque, pour partir ensuite en expédition ensemble... Si tu vois ce que je veux dire. Je ne peux pas le faire seul, et lui, il a filé on ne sait oם !";
            link.l1.go = "Jamaica_ratW_3";
        break;

		case "Jamaica_ratW_3":
            dialog.text = "Je comprends. Eh bien, puisqu'une expédition si lucrative vous attend, et que vous êtes amis, François et vous... Je vais vous dire oם il est allé, mais pas pour rien.";
            link.l1 = "Hum... Combien veux-tu ?";
            link.l1.go = "Jamaica_ratW_4";
        break;

		case "Jamaica_ratW_4":
            dialog.text = "Pouah, "+ GetSexPhrase("que c'est vulgaire", "quelle grossière vous faites") +". Je n'ai pas besoin d'argent. François m'avait promis des pendentifs d'émeraude, je m'en suis déjà vantée auprès de mes amies, et il a filé... Apportez-moi les pendentifs, et je vous dirai oם il est allé.";
            link.l1 = "Oh, la rusée ! Tu sais quoi demander : ce genre de bijoux, on n'en trouve pas chez les marchands. Bon, tu auras tes pendentifs.";
            link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_5");
			pchar.questTemp.Slavetrader = "FindRatJamaica_WP";
        break;

		case "Jamaica_ratW_5":
            dialog.text = "Oh, qu'ils sont beaux ! Maintenant, toutes mes amies vont crever de jalousie !";
            link.l1 = "Transmets-leur mes condoléances. Maintenant, j'attends que tu me dises oם est parti François.";
            link.l1.go = "Jamaica_ratW_6";
			RemoveItems(PChar, "jewelry15", 1);
        break;

		case "Jamaica_ratW_6":
            dialog.text = "Oui, oui, "+ GetSexPhrase("mynheer", "madame") +". François a pris la route de Cuba, vers La Havane";
            link.l1 = "Merci, ma chérie. C'est tout ce que je voulais savoir.";
            link.l1.go = "exit";
			AddQuestRecord("Slavetrader", "21_6");
			pchar.questTemp.Slavetrader = "FindRatHavana";
        break;


	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

