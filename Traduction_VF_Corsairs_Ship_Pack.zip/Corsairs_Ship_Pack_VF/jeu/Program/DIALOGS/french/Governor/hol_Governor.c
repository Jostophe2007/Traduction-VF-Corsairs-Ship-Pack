// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    ref sld;
    int i, tempQty, chComp, iShip, iBaseType;
    string tempStr;
    switch (Dialog.CurrentNode)
	{
		case "quests":
            dialog.text = RandPhraseSimple("Quelles questions ?", "Que voulez-vous ?");
			link.l1 = RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment.");
		    link.l1.go = "exit";
			if (pchar.questTemp.State == "Fr2Letter_toCuracao")
			{
                dialog.text = "Je vous écoute.";
                link.l1 = "Monsieur le gouverneur général, on m'a chargé de vous remettre une lettre.";
                link.l1.go = "Step_F2_1";
			}
			if (pchar.questTemp.State == "Fr2Letter_NiceResult")
			{
                dialog.text = "Encore vous ? C'est encore la sacoche de Tortuga ?";
                link.l1 = "Pas cette fois, monsieur le gouverneur général. J'ai de bonnes nouvelles pour vous.";
                link.l1.go = "Step_F2_4";
			}
			if (pchar.questTemp.LSC == "toTalkStuvesant")
			{
				link.l1 = "Je voudrais vous interroger sur une personne. Ne me refusez pas la courtoisie d'une réponse.";
				link.l1.go = "TizerFind";
			}
		break;

		case "work_1":  // работа на благо короны - линейка нации
            // сюда вход только с патентом, проверка выше
            dialog.text = LinkRandPhrase("Vous êtes au service de la République des Provinces-Unies ! Je vous prie de commencer immédiatement la mission qui vous a été confiée !",
                                         "Je ne vous cacherai pas que beaucoup de choses dépendent de la réussite de vos actions. Alors, remplissez vos obligations !",
                                         "J'attends votre rapport sur l'exécution de ma mission de confiance, pas des réactions stupides.");
            link.l1 = RandPhraseSimple("Je commence immédiatement, mynheer", "Je suis déjà en train de m'en occuper...");
            link.l1.go = "exit";

        	switch (pchar.questTemp.State)   // что делаем в данный момент
            {
                case "empty":   // Нет взятых квестов
                    if (GetQuestPastDayParam("questTemp") < sti(pchar.questTemp.Waiting_time))
                    {
                        dialog.text = LinkRandPhrase("Je n'ai pas de mission de confiance pour vous pour le moment. Vous pouvez revenir à ma résidence plus tard...",
                                                     "Veuillez m'excuser, je suis très occupé en ce moment !",
                                                     "Occupez-vous de vos affaires de corsaire pour l'instant, je n'ai pas de mission pour vous en ce moment.");
                        link.l1 = "Bien, mynheer.";
                        link.l1.go = "exit";
                    }
                    else
                    {
						switch(pchar.questTemp.CurQuestNumber)   // Взятие квестов начиная со второго
                        {
                            case "2":
                                dialog.text = "J'ai une nouvelle mission pour vous. Il faut acheter à Fort Orange un lot de café, d'ébène, d'acajou et de santal préparé pour Curaçao. Partez immédiatement ; voici les papiers nécessaires : remettez-les au gouverneur de Fort Orange.";
                                link.l1 = "Vous avez dit acheter ?";
                                link.l1.go = "Step_2_1";
                            break;
                            case "3":
                                dialog.text = "Je dois vous informer que nous sommes en guerre contre l'Angleterre, une nouvelle guerre commerciale a commencé.";
                                link.l1 = "Voilà donc...";
                                link.l1.go = "Step_3_1";
                            break;
                            case "4":
                                if (CheckAttribute(pchar, "questTemp.GoodWormRusult"))
                                {
                                    dialog.text = "Vous avez obtenu une information de la plus haute importance. Madiford n'a pas en ce moment les forces nécessaires pour nous causer de sérieux ennuis à Curaçao, mais ils veulent détruire Fort Orange, qui est juste à cכté d'eux, à la Jamaïque.";
                                    link.l1 = "Oui, mynheer, je le sais.";
                                    link.l1.go = "Step_4_1";
                                }
                                else
                                {
                                    dialog.text = "Vous n'avez pas su mener à bien la mission précédente. D'autres braves l'ont accomplie à votre place. Je vous donne maintenant l'occasion de vous racheter. D'après les informations que j'ai reçues, j'ai conclu que Madiford n'est pas assez fort pour nous causer de sérieux ennuis à Curaçao, mais qu'ils veulent détruire Fort Orange, qui se trouve à cכté d'eux, à la Jamaïque.";
                                    link.l1 = "Je vois...";
                                    link.l1.go = "Step_4_1";
                                }
                            break;
                            case "5":
                                dialog.text = "Voici donc votre prochaine mission. Elle consiste à escorter trois flמtes chargées jusqu'à la colonie de boucaniers de La Vega, chez Edward Mansfield.";
                                link.l1 = "Compris, mynheer.";
                                link.l1.go = "Step_5_1";
                            break;
                            case "6":
                                dialog.text = "Vous voilà, je vous attendais.";
                                link.l1 = "א votre service, mynheer.";
                                link.l1.go = "Step_6_1";
                            break;
                            case "7":
                                dialog.text = "J'ai une mission sérieuse pour vous. Je dois faire parvenir une dépêche au gouverneur général de Tortuga, Bertrand d'Ogeron. Cela concerne nos actions dans la guerre de Dévolution de la France contre l'Espagne. Cette correspondance est strictement confidentielle, je vous demande donc de comprendre à quel point je vous fais confiance. Cette dépêche ne doit parvenir à personne d'autre qu'au gouverneur général de Tortuga, c'est une exigence catégorique !";
                                link.l1 = "Compris, mynheer. Tout sera exécuté comme il se doit : monsieur d'Ogeron recevra cette dépêche.";
                                link.l1.go = "Step_7_1";
                            break;
                            case "8":
                                dialog.text = "J'ai une demande personnelle à vous faire. Mon ami, le chef de la communauté janséniste de Curaçao, que vous avez amené sur l'île, demande qu'on lui envoie un officier intelligent. Je n'ai personne de mieux que vous. Il s'agit de retrouver quelque chose dont il a grand besoin. Bref, Aaron vous expliquera tout lui-même ; il est chez lui en ce moment, rendez-lui visite.";
                                link.l1 = "Compris, mynheer. Je vais le voir immédiatement.";
                                link.l1.go = "exit";
                                pchar.questTemp.State = "SeekBible_toAaron";
                                AddQuestRecord("Hol_Line_8_SeekBible", "1");
								AddQuestUserData("Hol_Line_8_SeekBible", "sSex", GetSexPhrase("", "e"));
                                SaveCurrentQuestDateParam("questTemp");
								sld = characterFromId("Chumakeiro");
								LAi_SetStayTypeNoGroup(sld);
                                ChangeCharacterAddressGroup(sld, "Villemstad_houseS3", "goto", "goto1");
                            break;
                            case "9":
                                dialog.text = "Nous rencontrons de sérieuses difficultés pour construire des vaisseaux de ligne de fort tonnage dans nos chantiers européens : des ports peu profonds, voyez-vous... Je réfléchissais hier à ce triste fait, et une idée brillante m'est venue à l'esprit !";
                                link.l1 = "Laquelle, mynheer ?";
                                link.l1.go = "Step_9_1";
                            break;
                            case "10":
                                dialog.text = "Bon sang, " + pchar.name + " ! Vous aviez raison quand vous m'avez suggéré de laisser ici, dans les Caraïbes, l'escadre que vous avez capturée...";
                                link.l1 = "Que s'est-il passé, mynheer ?";
                                link.l1.go = "Step_10_1";
                            break;
                            case "11":
                                dialog.text = "Vous voilà ! J'attendais votre venue à la résidence.";
                                link.l1 = "Que s'est-il passé, mynheer ?";
                                link.l1.go = "Step_11_1";
                            break;
                            case "12":
                                dialog.text = "Je m'empresse de vous informer que nous avons désigné la ville espagnole qui sera attaquée. C'est Maracaibo. Les habitants de la ville devront prêter allégeance à la République des Provinces-Unies !";
                                link.l1 = "Bon choix, mynheer.";
                                link.l1.go = "Step_12_1";
                            break;
                        }
                    }
                break;

                case "":           // Квест №1, доставка главы янсенистов мистера Аарона.
                    dialog.text = "Eh bien, j'ai une mission très importante pour vous. Je pense que vous saurez vous en acquitter\n"+
                                  "Voici l'affaire : bon nombre de protestants d'Europe ont commencé récemment à arriver à Curaçao, principalement de Flandre et de Bourgogne, oם l'Inquisition fait rage. Récemment, des partisans de la doctrine de Jansénius sont aussi arrivés chez nous. Pour diriger la communauté janséniste, l'influent janséniste Aaron Mendes Chumaqueiro est arrivé à Saint-Martin sur un navire de ligne français venu de Hollande\n"+
                                  "C'est un grand négociant, une vieille connaissance à moi et un grand ami. Rendez-vous à Marigot et amenez-le-moi : la communauté janséniste d'ici a grand besoin de lui.";
                    link.l1 = "Permettez-moi de vous demander : qui sont les jansénistes ?";
                    link.l1.go = "Step_1_1";
                break;
                case "SeekChumakeiro_GoToVillemstad":
                    dialog.text = "Eh bien, Aaron m'a déjà tout raconté. Beau travail, "+ GetSexPhrase("mynheer","madame") +". Revenez me voir dans quelque temps, il me semble que je continuerai à faire appel à vos services.";
                    link.l1 = "Bien, mynheer.";
                    link.l1.go = "exit";
                    pchar.questTemp.State = "empty";
                    SaveCurrentQuestDateParam("questTemp");
                    pchar.questTemp.CurQuestNumber = "2";
                    pchar.questTemp.Waiting_time = "7";
                    CloseQuestHeader("Hol_Line_1_Chumakeiro");
					AddTitleNextRate(sti(NPChar.nation), 1);
					AddCharacterExpToSkill(pchar, "Leadership", 100);
					AddCharacterExpToSkill(pchar, "Pistol", 150);
					AddCharacterExpToSkill(pchar, "Grappling", 120);
					ChangeCharacterReputation(pchar, 5);
					ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
					//слухи
					AddSimpleRumour("Vous savez, notre gouverneur général, Stuyvesant, a engagé le capitaine " + GetMainCharacterNameGen() + " pour ramener son ami de Marigot jusqu'ici, à Willemstad. Et vous savez, la mission a été accomplie avec succès.", HOLLAND, 5, 1);
                break;
                case "TakeFoodCuracao_toOrangeStore":
                    dialog.text = "Alors, capitaine, qu'est-ce qui vous amène à Curaçao ?";
                    link.l1 = "J'exécute votre mission de livraison de la cargaison de Fort Orange, mynheer.";
                    if (GetQuestPastDayParam("questTemp") > 60)
                    {
                        dialog.text = "Je vous avais demandé de me livrer tout le lot dans les 60 jours. Vous avez échoué....";
                        link.l1 = "C'est exact, je n'ai pas eu le temps, il y a eu de sérieux problèmes de vent...";
                    }
                    link.l1.go = "Step_2_5";
                break;
                case "WormEnglPlans_SurrenderWorkMorgan":
                    dialog.text = "Vous voilà enfin ! Dites-moi immédiatement ce que vous avez appris.";
                    link.l1 = "Mansfield ne sait rien des plans de Madiford. Mais j'ai appris que Madiford essayait de pousser les corsaires à attaquer Curaçao. On peut donc supposer que Madiford a reçu l'ordre d'ouvrir les hostilités contre les Pays-Bas dans la mer des Caraïbes.";
                    link.l1.go = "Step_3_3";
                break;
                case "WormEnglPlans_SaveOfficer":
                    dialog.text = "Vous voilà enfin ! Dites-moi immédiatement ce que vous avez découvert.";
                    link.l1 = "Mansfield ne sait rien des plans de Madiford. L'amiral des corsaires, Henry Morgan, suppose qu'il existe un ordre d'attaquer les colonies hollandaises.";
                    link.l1.go = "Step_3_3";
                break;
                case "WormEnglPlans_GoodRusultWorm":
                    dialog.text = "Qu'avez-vous découvert ?";
                    link.l1 = "Madiford prépare une attaque contre Fort Orange. On prépare la garnison de Port Royal à l'assaut. Madiford a essayé de persuader les corsaires d'attaquer Curaçao, mais il a échoué. Madiford n'a donc pas les forces nécessaires pour une opération plus importante que l'assaut de Fort Orange.";
                    link.l1.go = "Step_3_7";
                break;
                case "DefenceOrange_LateRiseOrange":
                    dialog.text = "Dites-moi, qu'en est-il de Fort Orange ?";
                    link.l1 = "Mynheer, je n'ai pas pu venir au secours de Fort Orange. Les malheureux habitants ont été exterminés, Fort Orange n'existe plus en tant que colonie hollandaise...";
                    link.l1.go = "Step_4_2";
                break;
                case "DefenceOrange_DieHard":
                    dialog.text = "Dites-moi, qu'en est-il de Fort Orange ?";
                    link.l1 = "Mynheer, je n'ai pas pu venir au secours de Fort Orange. Nous nous sommes battus, mais les Anglais étaient plus forts. Nous avons dמ fuir pour sauver nos vies... Malheureusement, Fort Orange n'existe plus en tant que colonie hollandaise...";
                    link.l1.go = "Step_4_2";
                break;
                case "DefenceOrange_LandingDestroyed":
                    dialog.text = "Dites-moi, qu'en est-il de Fort Orange ?";
                    link.l1 = "Mynheer, la mission est accomplie. Tous les navires et toutes les troupes de débarquement des Anglais ont été détruits alors qu'ils tentaient de forcer l'entrée de la ville. Elle n'est plus en danger.";
                    link.l1.go = "Step_4_4";
                break;
                case "DefenceOrange_SquadronDestroyed":
                    dialog.text = "Dites-moi, qu'en est-il de Fort Orange ?";
                    link.l1 = "Mynheer, j'ai réussi à détruire les navires anglais en mer. Mais malheureusement, je n'ai pas pu résister aux troupes terrestres anglaises. Fort Orange a été détruit...";
                    link.l1.go = "Step_4_5";
                break;
                case "ThreeFleutes_DieHard":
                    dialog.text = "On m'a déjà informé que vous n'avez pas su sauver les flמtes qui vous avaient été confiées. De plus, vous avez fui le champ de bataille !";
                    link.l1 = "Mynheer, au large d'Hispaniola, toute une escadre espagnole m'est tombée dessus ! Les forces étaient trop inégales...";
                    link.l1.go = "Step_5_3";
                break;
                case "ThreeFleutes_AllFleuts":
                    dialog.text = "Rapportez-moi ce qui vous est arrivé ?";
                    link.l1 = "Mynheer, au large d'Hispaniola, toute une escadre espagnole m'est tombée dessus ! Mais j'ai réussi à sauver les navires qui m'avaient été confiés.";
                    link.l1.go = "Step_5_4";
                break;
                case "ThreeFleutes_LostFleuts":
                    dialog.text = "On m'a déjà informé que vous n'avez pas su sauver les flמtes qui vous avaient été confiées. C'est très fâcheux.";
                    link.l1 = "Mynheer, toute une escadre espagnole m'est tombée dessus au large d'Hispaniola !";
                    link.l1.go = "Step_5_9";
                break;
                case "RevengeMansfield_FromMorganWithResult":
                    dialog.text = "Alors, content de vous voir. Quelles nouvelles allez-vous m'annoncer ?";
                    link.l1 = "Eh bien, que dire ? On ne peut pas envier la ville de Santiago ni son gouverneur !";
                    link.l1.go = "Step_6_2";
                break;
                case "DelivLettTortuga_NotFoundLetter":
                    dialog.text = "Rapportez-moi les résultats de votre mission.";
                    link.l1 = "J'ai remis avec succès votre dépêche à d'Ogeron.";
                    link.l1.go = "Step_7_2";
                break;
                case "DelivLettTortuga_LetterFound":
                    dialog.text = "Rapportez-moi les résultats de votre mission.";
                    link.l1 = "J'ai remis avec succès votre dépêche à d'Ogeron.";
                    link.l1.go = "Step_7_8";
                break;
                case "DelivLettTortuga_WaitingNews":
                    if (GetQuestPastDayParam("questTemp") > 30)
                    {
                        dialog.text = "Eh bien, nous avons tous beaucoup de chance. D'Ogeron, ce vieux renard, a eu l'idée de chiffrer la lettre d'une manière que je connais. Les Espagnols ne pourront donc rien prouver directement.";
                        link.l1 = "Gloire au Seigneur !";
                        link.l1.go = "Step_7_20";
                    }
                    else
                    {
                        dialog.text = "Je n'ai pas encore de nouvelles de d'Ogeron. Revenez plus tard.";
                        link.l1 = "Bien, mynheer.";
                        link.l1.go = "exit";
                    }
                break;
                case "SeekBible_BadResult":
                    dialog.text = "Chumaqueiro m'a informé que vous n'avez pas su accomplir sa mission.";
                    link.l1 = "En somme, oui. J'ai fait tout ce que j'ai pu.";
                    link.l1.go = "Step_8_1";
                break;
                case "SeekBible_GoodResult":
                    dialog.text = ""+ GetSexPhrase("Mon ami","Madame") +", Aaron et sa communauté sont en extase religieuse. Il m'a dit que vous aviez réussi à faire quelque chose de très important pour lui. Dites-moi, de quoi s'agit-il ?";
                    link.l1 = "Je cherche pour lui un objet perdu. Un livre, un ancien traité chrétien.";
                    link.l1.go = "Step_8_2";
                break;
                case "TakeThreeShips_toAbordage":
                    dialog.text = "Alors, que me dites-vous de votre mission ? Oם en est la capture des navires ?";
                    tempQty = 0;
                    int money = 0;
                    for (i=1; i<=COMPANION_MAX; i++)
                	{
                        chComp = GetCompanionIndex(pchar,i);
                        if(chComp != -1)
                		{
                			sld = GetCharacter(chComp);
                    		iShip = sti(sld.ship.type);
                    		iBaseType = sti(RealShips[iShip].basetype);
                            if (iBaseType == SHIP_SANTAANNA || iBaseType == SHIP_OCEAN || iBaseType == SHIP_MANOWAR || iBaseType == SHIP_SANFELIPE || iBaseType == SHIP_VICTORY || iBaseType == SHIP_SOLEY)
                            {
                                tempQty++;
                                RemoveCharacterCompanion(pchar, sld);
                                AddPassenger(pchar, sld, false);
                               money += 75000;
                            }
                        }
                    }
                    if (money > 0) AddMoneyToCharacter(pchar, money);
                    if (tempQty == 0)
                    {
                        link.l1 = "Pour l'instant, je n'ai rien réussi à capturer qui soit digne de votre attention. Mais je m'en occupe, patientez, mynheer...";
                        link.l1.go = "exit";
                    }
                    else
                    {
						if (CheckShipTypeInSquadron(SHIP_TRINITY) > 0 || CheckShipTypeInSquadron(SHIP_ZWAAN) > 0)
						{
							dialog.text = "Vous pensiez me tromper ? Il y a dans votre escadre des vaisseaux de guerre sortis des chantiers hollandais.";
							link.l1 = "Pardon, mynheer. Pour l'instant, je n'ai rien réussi à capturer qui soit digne de votre attention. Mais je m'en occupe, patientez, mynheer...";
                            link.l1.go = "exit";
							break;
						}
                        if (sti(pchar.questTemp.QtyShips) > tempQty)
                        {
                            if (tempQty > 1)
                            {
                                link.l1 = "Pas mal, mynheer. Je suis prêt à vous remettre " + tempQty +  " navires.";
                            }
                            else
                            {
                                link.l1 = "Pas mal, mynheer. Je suis prêt à vous remettre un navire.";
                            }
                            link.l1.go = "Step_9_5";
                            pchar.questTemp.QtyShips = sti(pchar.questTemp.QtyShips) - tempQty;
                            AddQuestRecord("Hol_Line_9_TakeThreeShips", "2");
                            AddQuestUserData("Hol_Line_9_TakeThreeShips", "QtyTook", tempQty);
                            AddQuestUserData("Hol_Line_9_TakeThreeShips", "QtyElse", pchar.questTemp.QtyShips);
                        }
                        else
                        {
                            AddQuestRecord("Hol_Line_9_TakeThreeShips", "3");
                            link.l1 = "Parfait, mynheer. La mission est entièrement accomplie.";
                            link.l1.go = "Step_9_6";
                            DeleteAttribute(pchar, "questTemp.QtyShips");
                        }
                     }
                break;
                case "SpaAttackCuracao_GoodWork":
                    dialog.text = "J'ai tout vu ! C'était tout simplement formidable !";
                    link.l1 = "Merci, ma participation au combat a été assez modeste...";
                    link.l1.go = "Step_10_3";
                break;
                case "SpaAttackSentMartin_Late":
                    dialog.text = "Faites votre rapport : avez-vous réussi à protéger Saint-Martin ?";
                    link.l1 = "Mynheer, j'ai agi trop tard pour tout faire à temps... Marigot est désormais une ville espagnole.";
                    link.l1.go = "Step_11_5";
                break;
                case "SpaAttackSentMartin_GoodWork":
                    dialog.text = "Faites votre rapport : avez-vous réussi à protéger Saint-Martin ?";
                    link.l1 = "J'ai réussi, mynheer. Le siège de la ville de Saint-Martin par l'escadre espagnole a été levé. Les Espagnols sont vaincus.";
                    link.l1.go = "Step_11_8";
                break;
                case "OccupyMaracaibo_toWeWon":
                    dialog.text = "Je suis déjà au courant, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", on m'a déjà fait rapport de votre brillante victoire !";
                    link.l1 = "Mynheer, j'ai réussi à prendre Maracaibo. C'est désormais une colonie hollandaise.";
                    link.l1.go = "Step_12_3";
                break;
                case "QuestLineBreake":
                    dialog.text = "Je ne traite pas avec les gens qui manquent à leur parole. Je n'ai rien de plus à vous dire.";
                    link.l1 = "...";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
                case "EndOfQuestLine":
                    dialog.text = "Agissez de façon indépendante dans l'intérêt des Pays-Bas, je compte sur votre bon sens.";
                    link.l1 = "Bien, mynheer.";
                    link.l1.go = "exit";
                    bWorldAlivePause   = false; // Конец линейки
                break;
            }
        break;
        //********************** Квест №1, доставка главы янсенистов мистера Аарона. ************************
        case "Step_1_1":
            dialog.text = "Un mouvement religieux chrétien, si cela vous intéresse\n"+
                          "Il est né de la rédaction par Jansénius, en 1640, d'un traité théologique sur saint Augustin. Les jésuites soulignent la proximité de la doctrine janséniste avec les dogmes protestants et persécutent les adeptes de ce courant religieux. Louis XIV a lui aussi mis les jansénistes hors la loi\n"+
                          "L'établissement de la communauté ici, sous ma protection, est une étape très importante pour le développement des colonies hollandaises des Caraïbes. Le fait est que la plupart d'entre eux sont des nobles, des officiers, des bourgeois et de grands négociants. Ce genre de personnes ne sera pas de trop ici\n"+
                          "Eh bien, si vous êtes prêt, veuillez procéder immédiatement à la mission.";
            link.l1 = "Je suis prêt, mynheer. Attendez-moi bientכt de retour.";
            link.l1.go = "Step_1_2";
            link.l2 = "Désolé, mais je suis très occupé en ce moment. Plus tard, je serai prêt à accomplir cette mission.";
            link.l2.go = "exit";
        break;
        case "Step_1_2":
            SaveCurrentQuestDateParam("questTemp");
    		// остальные линейки в сад -->
    		pchar.questTemp.NationQuest = HOLLAND;
    		// остальные линейки в сад <--
    		pchar.questTemp.State = "SeekChumakeiro_ToAaronHouse";
            sld = GetCharacter(NPC_GenerateCharacter("Chumakeiro", "usurer_4", "man", "man", 10, HOLLAND, -1, false));
        	sld.name 	= "Aaron Mendes";
        	sld.lastname = "Chumakeiro";
            sld.Dialog.Filename = "Quest\HolLineNpc_1.c";
			sld.greeting = "Gr_padre";
        	LAi_SetHuberStayType(sld);
        	LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
            ChangeCharacterAddressGroup(sld, "Marigo_RoomHouseF1", "goto", "goto1");
            AddQuestRecord("Hol_Line_1_Chumakeiro", "1");
			AddQuestUserData("Hol_Line_1_Chumakeiro", "sSex", GetSexPhrase("", "e"));
            Pchar.quest.SeekChumakeiro_intoMarigoHouse.win_condition.l1 = "location";
            Pchar.quest.SeekChumakeiro_intoMarigoHouse.win_condition.l1.location = "Marigo_houseF1";
            Pchar.quest.SeekChumakeiro_intoMarigoHouse.win_condition = "SeekChumakeiro_intoMarigoHouse";
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;
        //********************** Квест №2, закупка и доставка товара из Форт Оранж. ************************
        case "Step_2_1":
            dialog.text = "Justement, acheter. Fort Orange nous fait de très bons prix pour l'achat de ce lot de marchandises. Dès que vous présenterez mes lettres de créance au gouverneur de Fort Orange, vous obtiendrez des prix réduits\n"+
                          "Le lot préparé pour vous comprend 400 unités de chaque article. Les prix seront pour vous environ dix fois inférieurs aux prix actuels\n"+
                          "D'après mes calculs, je vous alloue 17700 pièces d'or pour l'achat. Veuillez les recevoir.";
            link.l1 = "Si vous avez calculé cette opération, pouvez-vous me dire combien pèse ce lot en quintaux ? Je dois planifier le transport.";
            link.l1.go = "Step_2_2";
        break;
        case "Step_2_2":
            dialog.text = "Bien sמr, je vais vous le dire. Au total, le poids du lot entier est de 5 600 quintaux.";
            link.l1 = "Hum, ça fait beaucoup... Mynheer, je suis "+ GetSexPhrase("un capitaine libre","une capitaine libre, pas une marchande") +", et je n'aime pas trop ces opérations de transport de marchandises...";
            link.l1.go = "Step_2_3";
        break;
        case "Step_2_3":
            dialog.text = "C'est justement parce que vous êtes, pour ainsi dire, "+ GetSexPhrase("un capitaine libre","une capitaine libre, et non une marchande") +", que je fais appel à vous pour cette mission. J'ai besoin que cette cargaison arrive ici saine et sauve, et il me semble que c'est "+ GetSexPhrase("un capitaine libre","une corsaire") +" qui saura en garantir l'intégrité et la sécurité\n"+
                          "Les Espagnols rכdent, les Anglais ne nous témoignent pas de sentiments amicaux, il y a des pirates à foison... Je vous prie donc de bien me comprendre..\n"+
                          "Je n'accepterai pas que vous refusiez cette mission. Au travail ! Et souvenez-vous qu'il me faut tout le lot, les 5 600 quintaux, ici, à Willemstad, dans deux mois au plus tard.";
            link.l1 = "Hum, ouais... Très bien, mynheer, je vais le faire. Vous ne me laissez pas le choix.";
            link.l1.go = "Step_2_4";
        break;
        case "Step_2_4":
            dialog.text = "Je suis très content que vous ayez accepté. Eh bien, je vous attends avec la cargaison.";
            link.l1 = "א plus tard, mynheer.";
            link.l1.go = "exit";
            pchar.questTemp.State = "TakeFoodCuracao_toOrangeMayor";
            AddQuestRecord("Hol_Line_2_TakeFoodCuracao", "1");
            ChangeItemDescribe("Trust", "itmdescr_Trust_HolLineQ2");
            GiveItem2Character(pchar,"Trust");
            AddMoneyToCharacter(pchar, 17700);
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.EbonyQtyElseNeed = 400;
            pchar.questTemp.CoffeeQtyElseNeed = 400;
            pchar.questTemp.MahoganyQtyElseNeed = 400;
            pchar.questTemp.SandalQtyElseNeed = 400;
        break;
        case "Step_2_5":
            if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed")) pchar.questTemp.EbonyQty = pchar.Ship.Cargo.Goods.Ebony;
            if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed")) pchar.questTemp.CoffeeQty = pchar.Ship.Cargo.Goods.Coffee;
            if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed")) pchar.questTemp.MahoganyQty = pchar.Ship.Cargo.Goods.Mahogany;
            if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed")) pchar.questTemp.SandalQty = pchar.Ship.Cargo.Goods.Sandal;
            for (i=1; i<=COMPANION_MAX; i++)
        	{
                chComp = GetCompanionIndex(pchar,i);
                if(chComp != -1)
        		{
        			sld = GetCharacter(chComp);
                    if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed")) pchar.questTemp.EbonyQty = sti(pchar.questTemp.EbonyQty) + sti(sld.Ship.Cargo.Goods.Ebony);
                    if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed")) pchar.questTemp.CoffeeQty = sti(pchar.questTemp.CoffeeQty) + sti(sld.Ship.Cargo.Goods.Coffee);
                    if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed")) pchar.questTemp.MahoganyQty = sti(pchar.questTemp.MahoganyQty) + sti(sld.Ship.Cargo.Goods.Mahogany);
                    if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed")) pchar.questTemp.SandalQty = sti(pchar.questTemp.SandalQty) + sti(sld.Ship.Cargo.Goods.Sandal);
                }
            }
            tempStr = "Mynheer, j'ai apporté les marchandises suivantes :\n";
            if (CheckAttribute(pchar, "questTemp.EbonyQty"))
            {
                if (sti(pchar.questTemp.EbonyQty > 0)) tempStr = tempStr + " וbène - " + pchar.questTemp.EbonyQty + " unités.";
            }
            if (CheckAttribute(pchar, "questTemp.CoffeeQty"))
            {
                if (sti(pchar.questTemp.CoffeeQty > 0)) tempStr = tempStr + " Café - " + pchar.questTemp.CoffeeQty + " unités.";
            }
            if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed"))
            {
                if (sti(pchar.questTemp.MahoganyQty > 0)) tempStr = tempStr + " Acajou - " + pchar.questTemp.MahoganyQty + " unités.";
            }
            if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed"))
            {
                if (sti(pchar.questTemp.SandalQty > 0)) tempStr = tempStr + " Santal - " + pchar.questTemp.SandalQty + " unités.";
            }
            dialog.text = "Dites-moi combien et quoi vous avez apporté de Fort Orange.";
            link.l1 = tempStr;
            link.l1.go = "Step_2_6";
            if (tempStr == "Mynheer, I brought the following items:\n")
            {
                link.l1 = "Mynheer, je suis en train de m'en occuper. Pour l'instant, rien de nouveau n'a été livré, veuillez m'excuser...";
                link.l1.go = "exit";
                DeleteAttribute(pchar, "questTemp.EbonyQty");
                DeleteAttribute(pchar, "questTemp.CoffeeQty");
                DeleteAttribute(pchar, "questTemp.MahoganyQty");
                DeleteAttribute(pchar, "questTemp.SandalQty");
            }
        break;
        case "Step_2_6":
            tempStr = "Bon, faisons le point.";
            if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed"))
            {
                HolLine2_NullGoods();
                if (sti(pchar.questTemp.EbonyQty) >= sti(pchar.questTemp.EbonyQtyElseNeed))
                {
                    tempStr = tempStr + " Vous avez livré la totalité de l'ébène.";
                    HolLine2_NullGoods();
                    AddCharacterGoods(pchar, GOOD_EBONY, sti(pchar.questTemp.EbonyQty)-sti(pchar.questTemp.EbonyQtyElseNeed));
                    DeleteAttribute(pchar, "questTemp.EbonyQtyElseNeed");
                }
                else
                {
                    if (sti(pchar.questTemp.EbonyQty > 0))
                    {
                        tempStr = tempStr + " J'accepte " + pchar.questTemp.EbonyQty + " unités d'ébène.";
                        pchar.questTemp.EbonyQtyElseNeed = sti(pchar.questTemp.EbonyQtyElseNeed) - sti(pchar.questTemp.EbonyQty);
                        HolLine2_NullGoods();
                    }
                }
            }
            if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed"))
            {
                if (sti(pchar.questTemp.CoffeeQty) >= sti(pchar.questTemp.CoffeeQtyElseNeed))
                {
                    tempStr = tempStr + " Vous avez livré tout le lot de café.";
                    HolLine2_NullGoods();
                    AddCharacterGoods(pchar, GOOD_COFFEE, sti(pchar.questTemp.CoffeeQty)-sti(pchar.questTemp.CoffeeQtyElseNeed));
                    DeleteAttribute(pchar, "questTemp.CoffeeQtyElseNeed");
                }
                else
                {
                    if (sti(pchar.questTemp.CoffeeQty > 0))
                    {
                        tempStr = tempStr + " J'accepte " + pchar.questTemp.CoffeeQty + " unités de café.";
                        pchar.questTemp.CoffeeQtyElseNeed = sti(pchar.questTemp.CoffeeQtyElseNeed) - sti(pchar.questTemp.CoffeeQty);
                        HolLine2_NullGoods();
                    }
                }
            }
            if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed"))
            {
                if (sti(pchar.questTemp.MahoganyQty) >= sti(pchar.questTemp.MahoganyQtyElseNeed))
                {
                    tempStr = tempStr + " Vous avez livré tout le lot d'acajou.";
                    HolLine2_NullGoods();
                    AddCharacterGoods(pchar, GOOD_MAHOGANY, sti(pchar.questTemp.MahoganyQty)-sti(pchar.questTemp.MahoganyQtyElseNeed));
                    DeleteAttribute(pchar, "questTemp.MahoganyQtyElseNeed");
                }
                else
                {
                    if (sti(pchar.questTemp.MahoganyQty > 0))
                    {
                        tempStr = tempStr + " J'accepte " + pchar.questTemp.MahoganyQty + " unités d'acajou.";
                        pchar.questTemp.MahoganyQtyElseNeed = sti(pchar.questTemp.MahoganyQtyElseNeed) - sti(pchar.questTemp.MahoganyQty);
                        HolLine2_NullGoods();
                    }
                }
            }
            if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed"))
            {
                if (sti(pchar.questTemp.SandalQty) >= sti(pchar.questTemp.SandalQtyElseNeed))
                {
                    tempStr = tempStr + " Vous avez réussi à livrer tout le lot de santal.";
                    HolLine2_NullGoods();
                    AddCharacterGoods(pchar, GOOD_SANDAL, sti(pchar.questTemp.SandalQty)-sti(pchar.questTemp.SandalQtyElseNeed));
                    DeleteAttribute(pchar, "questTemp.SandalQtyElseNeed");
                }
                else
                {
                    if (sti(pchar.questTemp.SandalQty > 0))
                    {
                        tempStr = tempStr + " J'accepte " + pchar.questTemp.SandalQty + " unités de santal.";
                        pchar.questTemp.SandalQtyElseNeed = sti(pchar.questTemp.SandalQtyElseNeed) - sti(pchar.questTemp.SandalQty);
                        HolLine2_NullGoods();
                    }
                }
            }
            DeleteAttribute(pchar, "questTemp.EbonyQty");
            DeleteAttribute(pchar, "questTemp.CoffeeQty");
            DeleteAttribute(pchar, "questTemp.MahoganyQty");
            DeleteAttribute(pchar, "questTemp.SandalQty");
            dialog.text = tempStr;
            link.l1 = "Très bien, mynheer.";
            link.l1.go = "Step_2_7";
        break;
        case "Step_2_7":
            tempStr = "";
            if (!CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed") && !CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed") && !CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed") && !CheckAttribute(pchar, "questTemp.SandalQtyElseNeed"))
            {
                if (GetQuestPastDayParam("questTemp") > 60)
                {
                    dialog.text = "Vous avez effectué la livraison en totalité, c'est bien. Cependant, ma demande prévoyait la livraison des marchandises sous deux mois. Ce délai n'a pas été respecté.";
                    link.l1 = "Mynheer, la mission s'est révélée difficile, je n'avais pas assez de navires spacieux pour accélérer le transport...";
                    link.l1.go = "Step_2_8";
                }
                else
                {
                    dialog.text = "Vous avez effectué la livraison en totalité. Et de plus, dans les délais ! Je tiens à vous informer qu'il était extrêmement important pour Curaçao de recevoir cette cargaison à temps.";
                    link.l1 = "Tant mieux si j'ai pu accomplir la mission au mieux.";
                    link.l1.go = "Step_2_11";
                }
            }
            else
            {
                dialog.text = "Je vous prie de terminer le travail que vous avez commencé. Il me faut tout le lot de Fort Orange, jusqu'au dernier quintal.";
                link.l1 = "Bien, mynheer, tout sera livré à Willemstad.";
                link.l1.go = "exit";
                AddQuestRecord("Hol_Line_2_TakeFoodCuracao", "3");
                if (CheckAttribute(pchar, "questTemp.EbonyQtyElseNeed")) AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "EbonyQtyElseNeed", pchar.questTemp.EbonyQtyElseNeed);
                else AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "EbonyQtyElseNeed", "livré");
                if (CheckAttribute(pchar, "questTemp.CoffeeQtyElseNeed")) AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "CoffeeQtyElseNeed", pchar.questTemp.CoffeeQtyElseNeed);
                else AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "CoffeeQtyElseNeed", "livré");
                if (CheckAttribute(pchar, "questTemp.MahoganyQtyElseNeed")) AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "MahoganyQtyElseNeed", pchar.questTemp.MahoganyQtyElseNeed);
                else AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "MahoganyQtyElseNeed", "livré");
                if (CheckAttribute(pchar, "questTemp.SandalQtyElseNeed")) AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "SandalQtyElseNeed", pchar.questTemp.SandalQtyElseNeed);
                else AddQuestUserData("Hol_Line_2_TakeFoodCuracao", "SandalQtyElseNeed", "livré");
            }
        break;
        case "Step_2_8":
            dialog.text = "Je comprends, mais vous devez comprendre que je suis guidé par de grands desseins et que je dois simplement suivre scrupuleusement mes instructions.\n"+
                          "Pour la raison évoquée ci-dessus, le montant de la rétribution pour cette opération commerciale est fortement réduit\n"+
                          "Je ne pourrais pas vous donner plus de 15 000 pièces d'or.";
            link.l1 = "Hum, kof, mmm... Eh bien, merci quand même...";
            link.l1.go = "Step_2_9";
        break;
        case "Step_2_9":
            dialog.text = "Toujours à votre service, capitaine. Revenez me voir de temps en temps, je pourrai peut-être vous trouver encore du travail.";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "Step_2_10";
            AddMoneyToCharacter(pchar, 15000);
            pchar.questTemp.Waiting_time = "30";
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 1);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le capitaine " + GetFullName(pchar) + " a accepté une opération commerciale : la livraison de vivres depuis Fort Orange. Le capitaine a accompli la mission, mais n'a pas respecté les délais.", HOLLAND, 5, 1);
        break;
        case "Step_2_10":
            AddQuestRecord("Hol_Line_2_TakeFoodCuracao", "4");
            CloseQuestHeader("Hol_Line_2_TakeFoodCuracao");
			DeleteAttribute(pchar, "GenQuest.HL2_AgainDiscount");  //сносим дисконтные цены
        	pchar.GenQuest.StoreGoods.StoreIdx = FortOrange_STORE; //восстанавливаем старые цены и кол-во
        	pchar.GenQuest.StoreGoods.HL2_QtyPriceIsBack = true;
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "3";
            NextDiag.CurrentNode = NextDiag.TempNode;
            DialogExit();
        break;
        case "Step_2_11":
            dialog.text = "Le montant de la rétribution pour la réussite de cette commande est donc de 75 000 pièces d'or. Avouez que c'est une digne récompense.";
            link.l1 = "Sans aucun doute, mynheer...";
            link.l1.go = "Step_2_12";
        break;
        case "Step_2_12":
            dialog.text = "Parfait ! Et maintenant, je vous prie de me laisser : les affaires... Revenez me voir dans quelques jours, peut-être un peu plus.";
            link.l1 = "Bien, mynheer, je vais essayer.";
            link.l1.go = "Step_2_10";
            AddMoneyToCharacter(pchar, 75000);
            pchar.questTemp.Waiting_time = "2";
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			AddCharacterExpToSkill(pchar, "Sailing", 100);
			AddCharacterExpToSkill(pchar, "FencingLight", 150);
			AddCharacterExpToSkill(pchar, "Fencing", 150);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 120);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 2);
			//слухи
			AddSimpleRumour("Vous avez entendu ? Le capitaine " + GetFullName(pchar) + " a accepté une opération commerciale : la livraison de vivres depuis Fort Orange. Le capitaine l'a menée à bien, et rapidement en plus !", HOLLAND, 5, 1);
        break;
        //********************** Квест №3, Узнать о планах англичан в связи с торговой войной ************************
        case "Step_3_1":
            dialog.text = "L'épicentre de la guerre se trouve dans les eaux cכtières d'Europe et dans l'océan Indien, mais ici, dans les Caraïbes, cette guerre aura aussi ses répercussions\n"+
                          "J'ai besoin d'informations sur les plans des Anglais, précises et absolument fiables. Il y a une colonie de boucaniers sur l'île d'Hispaniola, oם vivent principalement des Français, mais aussi beaucoup de Hollandais. Eh bien, le chef des boucaniers est Edward Mansfield\n"+
                          "Son nom a été anglicisé ; son vrai nom est Edward Mansvelt, il est hollandais. Edward est l'homme de confiance du gouverneur général anglais, sir Thomas Madiford, pour tout ce qui touche au pillage des Espagnols.";
            link.l1 = "Hum, intéressant...";
            link.l1.go = "Step_3_2";
        break;
        case "Step_3_2":
            dialog.text = "Votre mission est la suivante : remettez cette lettre à Mansfield ; elle lui demande son aide. Persuadez-le de vous dire ce qu'il sait des plans anglais. Il ne fait aucun doute qu'ils nous attaquent. Nous devons savoir ce qu'ils vont faire.";
            link.l1 = "Compris, mynheer. Je m'y mets.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
    		pchar.questTemp.State = "WormEnglPlans_toMansfield";
    		AddQuestRecord("Hol_Line_3_WormEnglishPlans", "1");
            ChangeItemDescribe("letter_1", "itmdescr_letter_1_HolLineQ3");
            GiveItem2Character(pchar,"letter_1");
            QuestSetCurrentNode("Edward Mansfield", "HolLine3_WormEngPlans");
        break;
        case "Step_3_3":
            dialog.text = "Poursuivez votre rapport.";
            link.l1 = "En fait, il n'y a rien de plus à rapporter. C'est tout.";
            link.l1.go = "Step_3_4";
        break;
        case "Step_3_4":
            dialog.text = "Il s'avère que nous n'avons que des suppositions, et rien de concret. Avez-vous appris quelque chose sur les plans précis des Anglais ?";
            link.l1 = "Non, mynheer. Je n'ai rien pu apprendre de précis.";
            link.l1.go = "Step_3_5";
        break;
        case "Step_3_5":
            dialog.text = "Vous n'avez pas accompli la mission. Je vais devoir confier cette tâche à d'autres personnes, plus habiles. Et j'ai perdu mon temps. Vous m'avez beaucoup déçu.";
            link.l1 = "Mynheer, donnez-moi, je vous prie, l'occasion de me racheter.";
            link.l1.go = "Step_3_6";
        break;
        case "Step_3_6":
            dialog.text = "Pas dans cette affaire : trop de temps a été perdu. Bon, venez me voir de temps en temps, je pourrai peut-être vous trouver une affaire qui vous convienne.";
            link.l1 = "Merci, mynheer.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_3_WormEnglishPlans", "5");
			AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("Hol_Line_3_WormEnglishPlans", "sSex1", GetSexPhrase("", "e"));
            CloseQuestHeader("Hol_Line_3_WormEnglishPlans");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "30";
			ChangeCharacterReputation(pchar, -3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sneak", -100);
			AddCharacterExpToSkill(pchar, "Sailing", -100);
			//слухи
			AddSimpleRumour("Le bruit court que le capitaine " + GetFullName(pchar) + " a échoué dans une certaine mission secrète de Stuyvesant liée à la grande politique...", HOLLAND, 5, 1);
        break;
        case "Step_3_7":
            dialog.text = "Parfait ! Je sais maintenant tout ce que j'ai besoin de savoir. Revenez me voir dans deux jours, je prendrai une décision sur la riposte à cette menace anglaise... Vous avez fait du bon travail, votre récompense est de 50 000.";
            link.l1 = "Merci, mynheer.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_3_WormEnglishPlans");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "4";
            pchar.questTemp.Waiting_time = "3";
            pchar.questTemp.GoodWormRusult = true;
            AddMoneyToCharacter(pchar, 50000);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sailing", 150);
			AddCharacterExpToSkill(pchar, "Repair", 250);
			//слухи
			AddSimpleRumour("Le bruit court que c'est le capitaine " + GetFullName(pchar) + " qui a mené à bien la mission de découvrir les plans des Anglais dans cette nouvelle guerre.", HOLLAND, 5, 1);
        break;
        //********************** Квест №4, Защитить Форт Оранж ************************
        case "Step_4_1":
            dialog.text = "Partez immédiatement pour Fort Orange : vous devez intercepter à temps l'expédition anglaise, sinon c'en est fini de notre colonie, ils détruiront la ville et feront tout le monde prisonnier. Partez tout de suite, vous devez comprendre que beaucoup de choses dépendent de votre rapidité.";
            if (CheckAttribute(pchar, "questTemp.GoodWormRusult"))
            {
                link.l1 = "Compris, mynheer. Je commence immédiatement.";
            }
            else
            {
                link.l1 = "Je comprends, mynheer, merci de votre confiance. Soyez sמr que cette fois, je ne vous décevrai pas ! Je commence immédiatement.";
            }
            link.l1.go = "exit";
            DeleteAttribute(pchar, "questTemp.GoodWormRusult");
            AddQuestRecord("Hol_Line_4_DefenceOrange", "1");
			AddQuestUserData("Hol_Line_4_DefenceOrange", "sSex", GetSexPhrase("", "e"));
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "DefenceOrange_toFortOrange";
            Pchar.quest.DefenceOrange_FightNearJamaica.win_condition.l1 = "location";
            Pchar.quest.DefenceOrange_FightNearJamaica.win_condition.l1.location = "Jamaica";
            Pchar.quest.DefenceOrange_FightNearJamaica.win_condition = "DefenceOrange_FightNearJamaica";
			locations[FindLocation("FortOrange_port")].DisableEncounters = true;
        break;
        case "Step_4_2":
            dialog.text = "Bon sang ! Nous n'avons pas su protéger les citoyens de la République des Provinces-Unies contre les Anglais sanguinaires. C'est très fâcheux : notre présence déjà modeste dans la région des Caraïbes est désormais complètement affaiblie.";
            link.l1 = "Je suis désolé, j'ai fait tout ce que j'ai pu...";
            link.l1.go = "Step_4_3";
        break;
        case "Step_4_3":
            dialog.text = "Eh bien, néanmoins, je vous prie de passer me voir de temps en temps. J'aurai peut-être quelque chose à vous faire faire.";
            link.l1 = "Bien, mynheer. Je vous rendrai visite sans faute.";
            link.l1.go = "exit";
			//--> огонь и пламень убираем
			DeleteAttribute(&locations[FindLocation("FortOrange_town")], "hidden_effects");
			DeleteAttribute(&locations[FindLocation("FortOrange_ExitTown")], "hidden_effects");
			//<-- огонь и пламень
			DeleteAttribute(&locations[FindLocation("FortOrange_port")], "DisableEncounters"); //энкаутеры вернём
            CloseQuestHeader("Hol_Line_4_DefenceOrange");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "30";
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("On dit que vous n'avez pas su protéger les malheureux habitants de Fort Orange contre les Anglais. Oh, c'est bien dommage...", HOLLAND, 5, 1);
        break;
        case "Step_4_4":
            dialog.text = "Parfait ! Je suis sincèrement content que ce soit vous qui ayez su faire vos preuves dans une situation aussi dangereuse. Votre récompense pour le travail accompli est de 100 000 pièces. De plus, je vous prie de revenir un peu plus tard, j'aurai une autre mission pour vous.";
            link.l1 = "Bien, mynheer. Je me présenterai sans faute à votre résidence d'ici un mois au plus tard.";
            link.l1.go = "exit";
			AddTitleNextRate(sti(NPChar.nation), 1);
            AddMoneyToCharacter(pchar, 100000);
            CloseQuestHeader("Hol_Line_4_DefenceOrange");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "5";
            //==> на всякий случай дублируем снятие восторгов.
            QuestSetCurrentNode("FortOrange_Mayor", "First time");
            QuestSetCurrentNode("FortOrange_waitress", "First time");
            QuestSetCurrentNode("FortOrange_tavernkeeper", "First time");
            QuestSetCurrentNode("FortOrange_trader", "First time");
			DeleteAttribute(&locations[FindLocation("FortOrange_port")], "DisableEncounters"); //энкаутеры вернём
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 180);
			AddCharacterExpToSkill(pchar, "Grappling", 200);
			AddCharacterExpToSkill(pchar, "Defence", 170);
			AddCharacterExpToSkill(pchar, "Cannons", 220);
			AddCharacterExpToSkill(pchar, "Fortune", 150);
			//слухи
			AddSimpleRumour("On dit que c'est vous qui avez protégé les habitants de Fort Orange contre les Anglais. Permettez-moi de vous exprimer mon admiration !", HOLLAND, 5, 1);
        break;
        case "Step_4_5":
            dialog.text = "Bon sang ! Vous avez fait la moitié du travail, et il ne vous a manqué que peu de chose pour sauver les malheureux habitants de Fort Orange !";
            link.l1 = "C'est exact, mynheer. Il ne me restait plus de forces pour une attaque à terre. Je suis désolé...";
            link.l1.go = "Step_4_6";
        break;
        case "Step_4_6":
            dialog.text = "Oui, c'est triste. Les malheureux habitants de Fort Orange.\nVous pouvez compter sur moi pour vous confier encore des missions.";
            link.l1 = "Compris, mynheer. Merci.";
            link.l1.go = "exit";
			//--> огонь и пламень убираем
			DeleteAttribute(&locations[FindLocation("FortOrange_town")], "hidden_effects");
			DeleteAttribute(&locations[FindLocation("FortOrange_ExitTown")], "hidden_effects");
			//<-- огонь и пламень
			DeleteAttribute(&locations[FindLocation("FortOrange_port")], "DisableEncounters"); //энкаутеры вернём
            CloseQuestHeader("Hol_Line_4_DefenceOrange");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "5";
            pchar.questTemp.Waiting_time = "15";
			ChangeCharacterReputation(pchar, -4);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -150);
			AddCharacterExpToSkill(pchar, "Grappling", -150);
			AddCharacterExpToSkill(pchar, "Defence", -150);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
			Pchar.quest.DefenceOrange_FightInShore.over = "yes";
			Pchar.quest.DefenceOrange_FightInExitTown.over = "yes";
			//слухи
			AddSimpleRumour("On dit que vous avez défait l'escadre anglaise à Fort Orange, mais que les Anglais ont été plus forts au combat terrestre. C'est bien, bien dommage...", HOLLAND, 5, 1);
        break;

		//********************** Квест №5, Сопроводить три флейта к Мэнсфилду ************************
        case "Step_5_1":
            dialog.text = "Ce n'est pas tout. Je vous confie le commandement de l'escadre. Vous aurez la charge de vendre la cargaison au magasin des flibustiers et de leur acheter des vivres. Les carcasses qu'ils abattent par centaines sont de très bonne qualité. Naturellement, pour que l'affaire soit rentable, vous devez veiller à ce que toutes les flמtes atteignent les cכtes d'Hispaniola en un seul morceau.";
            link.l1 = "Je comprends tout.";
            link.l1.go = "Step_5_2";
        break;
        case "Step_5_2":
            dialog.text = "Alors, allez-y, mais sans précipitation excessive. Faites preuve de prudence. Et souvenez-vous que vous devez me livrer 7000 quintaux de vivres sur les flמtes. Les flמtes seront mises à votre disposition par le capitaine du port.";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_5_ThreeFleutes", "1");
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "ThreeFleutes_toPortMan";
        break;
        case "Step_5_3":
            dialog.text = "Il m'est difficile de parler à un capitaine qui s'est révélé être "+ GetSexPhrase("un vulgaire lâche","une vulgaire lâche") +" ! Je vous prie de me quitter immédiatement, je suis extrêmement déçu.";
            link.l1 = "Bien, mynheer. Je tiens à dire que je suis vraiment désolé...";
            link.l1.go = "Step_5_10";
            pchar.questTemp.Waiting_time = "100";
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
			//слухи
			AddSimpleRumour("Le bruit court que notre gouverneur général vous a mis à la porte de sa résidence pour lâcheté !", HOLLAND, 5, 1);
        break;

        case "Step_5_4":
            tempQty = sti(pchar.Ship.Cargo.Goods.Food);
			for (i=1; i<=COMPANION_MAX; i++)
        	{
                chComp = GetCompanionIndex(pchar,i);
                if(chComp != -1)
        		{
					sld = GetCharacter(chComp);
					iShip = sti(sld.ship.type);
                    iBaseType = sti(RealShips[iShip].basetype);
                    if (iBaseType == SHIP_FLEUT) tempQty = tempQty + sti(sld.Ship.Cargo.Goods.Food); //считаем только у флейтов
                }
            }
            tempQty = tempQty / 10; //вес от кол-ва
            dialog.text = "Excellent ! Je ne m'attendais pas à moins. Maintenant, dites-moi, avez-vous apporté les 7000 quintaux de vivres dont j'ai besoin ?";
            if (tempQty >= 7000)
            {
                link.l1 = "Oui, mynheer, tout va bien.";
                link.l1.go = "Step_5_5";
            }
            else
            {
                link.l1 = "Mynheer, je n'ai pas pu tout livrer. Au total, j'ai apporté " + tempQty + " quintaux de vivres";
                link.l1.go = "Step_5_8";
            }
        break;
        case "Step_5_5":
            dialog.text = "Eh bien, vous savez non seulement vous battre, mais vous êtes aussi "+ GetSexPhrase("un gestionnaire avisé","une gestionnaire avisée") +". Je vous suis reconnaissant pour la réussite de cette opération très dangereuse. Votre récompense est de 60 000 pièces, veuillez les recevoir. Veuillez me remettre les vivres livrés.";
            link.l1 = "Merci, mynheer.";
            link.l1.go = "Step_5_6";
            tempQty = sti(pchar.Ship.Cargo.Goods.Food);
            for (i=1; i<=3; i++)
            {
                sld = characterFromID("Captain_"+i);
				if (sld.id != "none")
				{
        			tempQty = tempQty + sti(sld.Ship.Cargo.Goods.Food);
					RemoveCharacterCompanion(pchar, sld);
					sld.LifeDay = 0;
				}
            }
            pchar.Ship.Cargo.Goods.Food = tempQty - 70000; //в пачке - 10 шт.
            AddMoneyToCharacter(pchar, 60000);
            pchar.questTemp.Waiting_time = "2";
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 180);
			AddCharacterExpToSkill(pchar, "Grappling", 200);
			AddCharacterExpToSkill(pchar, "Defence", 170);
			AddCharacterExpToSkill(pchar, "Cannons", 220);
			AddCharacterExpToSkill(pchar, "Fortune", 150);
        break;
        case "Step_5_6":
            dialog.text = "Eh bien, je vous attendrai chez moi dans quelques jours.";
            link.l1 = "Compris, mynheer. Avant de partir, je dois vous annoncer une très mauvaise nouvelle : Edward Mansfield a été tué lors d'une attaque espagnole contre la colonie de boucaniers.";
            link.l1.go = "Step_5_7";
        break;
        case "Step_5_7":
            dialog.text = "Bon sang, quelle terrible nouvelle ! Eh bien, merci pour l'information, "+ GetSexPhrase("mon ami","madame") +". Je plains Mansfield...";
            link.l1 = "Oui, mynheer. C'était un brave homme... Sur ce, permettez-moi de prendre congé.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_5_ThreeFleutes");
            pchar.GenQuest.StoreGoods.HL5_QtyPriceIsBack = true;
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "6";
        break;
        case "Step_5_8":
            if (tempQty > 4000)
            {
                dialog.text = "Eh bien, vous savez vous battre, mais vous n'êtes pas "+ GetSexPhrase("un gestionnaire avisé","une gestionnaire avisée") +". Néanmoins, je vous suis reconnaissant pour cette opération globalement réussie. Votre récompense est de 20 000 pièces, veuillez les recevoir. Je retire tous les vivres.";
                link.l1 = "Bien, mynheer.";
                AddMoneyToCharacter(pchar, 20000);
				AddTitleNextRate(sti(NPChar.nation), 3);
            }
            else
            {
                dialog.text = "Vous plaisantez ? Et oם est le reste des vivres ? Oui, je vois que vous êtes un escroc ! Vous n'aurez pas de récompense.";
                link.l1 = "Non, mynheer, j'ai honnêtement fait de mon mieux pour accomplir vos missions insensées ! C'est tout ce que j'ai pu apporter...";
            }
            link.l1.go = "Step_5_6";
            for (i=1; i<=3; i++)
            {
                sld = characterFromID("Captain_"+i);
				if (sld.id != "none")
				{
					RemoveCharacterCompanion(pchar, sld);
					sld.LifeDay = 0;
				}
            }
            pchar.Ship.Cargo.Goods.Food = 0;
            pchar.questTemp.Waiting_time = "7";
			ChangeCharacterReputation(pchar, -5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Sailing", -250);
			AddCharacterExpToSkill(pchar, "Grappling", -250);
			AddCharacterExpToSkill(pchar, "Defence", -250);
			AddCharacterExpToSkill(pchar, "Cannons", -250);
        break;
        case "Step_5_9":
            dialog.text = "Ce n'est pas une excuse ! Je vous ai confié des navires hollandais pour une mission élémentaire. Vous n'avez pas su l'accomplir. Je ne veux plus vous voir !";
            link.l1 = "Bien, mynheer. Je m'en vais, même si je ne me sens pas coupable.";
            link.l1.go = "Step_5_10";
            pchar.questTemp.Waiting_time = "30";
			ChangeCharacterReputation(pchar, -3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Sailing", -150);
			AddCharacterExpToSkill(pchar, "Grappling", -150);
			AddCharacterExpToSkill(pchar, "Defence", -150);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
            for (i=1; i<=COMPANION_MAX; i++)
        	{
                chComp = GetCompanionIndex(pchar,i);
                if(chComp != -1)
        		{
        			sld = GetCharacter(chComp);
        			tempStr = sld.id;
                    if (findsubstr(tempStr, "Captain_", 0) != -1)
                    {
                        RemoveCharacterCompanion(pchar, sld);
                        sld.LifeDay = 0;
			    i--;
                    }
                }
            }
        break;
        case "Step_5_10":
            dialog.text = "Vous avez sans doute fait tout ce que vous pouviez. Je pourrai peut-être vous trouver encore du travail, mais pas maintenant...";
            link.l1 = "Compris, mynheer. Avant de partir, je dois vous annoncer une très mauvaise nouvelle : Edward Mansfield a été tué lors d'une attaque espagnole contre la colonie de boucaniers.";
            link.l1.go = "Step_5_11";
        break;
        case "Step_5_11":
            dialog.text = "Bon sang, comme si je n'avais pas eu assez de mauvaises nouvelles aujourd'hui ! Merci néanmoins pour l'information. Je plains Mansfield...";
            link.l1 = "Oui, mynheer. C'était un brave homme. Sur ce, permettez-moi de prendre congé.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_5_ThreeFleutes");
            pchar.GenQuest.StoreGoods.HL5_QtyPriceIsBack = true;
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "6";
			//слухи
			AddSimpleRumour("On dit que c'est vous qui avez apporté la nouvelle de la mort d'Edward Mansfield. Pauvre vieux...", HOLLAND, 5, 1);
		break;
        //********************** Квест №6, узнать о планах мщения за Мэнсфилда ************************
        case "Step_6_1":
            dialog.text = "L'attaque espagnole contre la colonie de boucaniers et la mort de Mansfield auront de graves conséquences sur l'équilibre des forces dans la région des Caraïbes. Je ne suis pas sמr que nous devions faire quoi que ce soit à ce sujet\n"+
                          "Il est tout à fait possible que les Frères de la Cכte partent d'eux-mêmes, comme ils l'ont fait plus d'une fois, venger la mort d'un flibustier aussi respecté. Nous devons donc coordonner nos actions\n"+
                          "Allez voir Henry Morgan et apprenez de lui ce qu'ils comptent faire. Si Morgan décide de vous associer à une opération de représailles, considérez que vous avez ma permission d'y participer.";
            link.l1 = "Bien, mynheer. C'est avec joie que je participerai à une cause aussi noble.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_6_RevengeMansfield", "1");
			AddQuestUserData("Hol_Line_6_RevengeMansfield", "sSex", GetSexPhrase("", "e"));
            pchar.questTemp.State = "RevengeMansfield_toMorgan";
            QuestSetCurrentNode("Henry Morgan", "HolLine6_fromStuvesant");
            SaveCurrentQuestDateParam("questTemp");
        break;
        case "Step_6_2":
            dialog.text = "Alors, je vous écoute.";
            link.l1 = "Morgan m'a chargé d'une mission de reconnaissance. J'ai appris que le gouverneur Jimenez serait bientכt en ville. Le sort de Santiago est scellé.";
            link.l1.go = "Step_6_3";
        break;
        case "Step_6_3":
            dialog.text = "Voilà qui est bien... Morgan n'a pas jugé nécessaire de vous associer à l'assaut de la ville ?";
            link.l1 = "Non, ce sont les Anglais qui participeront directement à l'assaut ; pour des raisons bien connues, nous ne pouvons pas réunir nos escadres.";
            link.l1.go = "Step_6_4";
        break;
        case "Step_6_4":
            dialog.text = "C'est juste. Eh bien, comme on dit, tout est pour le mieux ! L'essentiel, c'est que Mansvelt soit vengé : c'était un brave homme et un digne fils de sa patrie.";
            link.l1 = "Je suis tout à fait d'accord avec vous, mynheer.";
            link.l1.go = "Step_6_5";
        break;
        case "Step_6_5":
            dialog.text = "Pour cette mission réussie, vous recevrez une récompense de 20 000 pièces. Revenez me voir à ma résidence dans quelque temps. J'aurai de nouveau une mission pour vous.";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "exit";
            AddMoneyToCharacter(pchar, 20000);
            CloseQuestHeader("Hol_Line_6_RevengeMansfield");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "7";
            pchar.questTemp.Waiting_time = "4";
			AddCharacterExpToSkill(pchar, "FencingLight", 350);
			AddCharacterExpToSkill(pchar, "Fencing", 350);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 320);
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			//слухи
			AddSimpleRumour("Le bruit court que vous avez réussi à mener une mission de reconnaissance contre les Espagnols... Félicitations.", HOLLAND, 5, 1);
        break;
        //********************** Квест №7, Доставка письма д'Ожерону ************************
        case "Step_7_1":
            dialog.text = "Si l'on vous attaque, ce pli doit être détruit immédiatement, quelle que soit l'issue attendue du combat.";
            link.l1 = "Bien, mynheer. Je m'y mets.";
            link.l1.go = "exit";
            AddQuestRecord("Hol_Line_7_DelivLettTortuga", "1");
            pchar.questTemp.State = "DelivLettTortuga_toDOjeron";
            SaveCurrentQuestDateParam("questTemp");
            ChangeItemDescribe("letter_2", "itmdescr_letter_2_HolLineQ7");
            GiveItem2Character(pchar,"letter_2");
        break;
        case "Step_7_2":
            dialog.text = "Parfait ! Je suis heureux que tout se soit si bien réglé.";
            link.l1 = "Hum, pas si bien que ça, mynheer. Le fait est que monsieur d'Ogeron a écrit une dépêche en réponse pour vous.";
            link.l1.go = "Step_7_3";
        break;
        case "Step_7_3":
            dialog.text = "Pourquoi pas si bien ? Tout va bien, donnez-la-moi.";
            tempStr = "Kof, kof... Le fait est qu'on me l'a volée en plein Tortuga.";
            switch (pchar.questTemp.State.KingResult)
            {
                case "BrigNotFound":
                    tempStr = tempStr + "J'ai pris en chasse le brick des voleurs, mais je n'ai pas pu récupérer la dépêche.";
                break;
                case "BrigSunk":
                    tempStr = tempStr + "J'ai pris en chasse le brick des voleurs et je l'ai coulé, mais je n'ai pas pu trouver la dépêche. Je ne sais pas oם elle est.";
                break;
                case "BrigAborded":
                    tempStr = tempStr + "J'ai pris en chasse le brick des voleurs. Le capitaine du brick capturé m'a appris que ce sont les Espagnols qui avaient organisé l'attaque contre moi. Mais la dépêche n'était déjà plus sur le brick : elle est tombée entre les mains des Espagnols.";
                break;
                case "WarshipSunk":
                    tempStr = tempStr + "J'ai pris en chasse le brick des voleurs. Le capitaine du brick capturé m'a appris que ce sont les Espagnols qui avaient organisé l'attaque contre moi. J'ai rattrapé le galion sur lequel ils étaient partis vers Santa Catalina, mais le galion a été coulé au combat et la dépêche n'a pas été retrouvée. Je ne sais pas oם elle se trouve en ce moment.";
                break;
            }
            link.l1 = tempStr;
            link.l1.go = "Step_7_4";
        break;
        case "Step_7_4":
            dialog.text = "Quoi ?!!!";
            link.l1 = "Je suis vraiment désolé, mynheer...";
            link.l1.go = "Step_7_5";
        break;
        case "Step_7_5":
            dialog.text = "Vous comprenez seulement ce que vous avez fait ?!";
            link.l1 = "א peu près, mynheer...";
            link.l1.go = "Step_7_6";
        break;
        case "Step_7_6":
            dialog.text = "Bref, voilà. Je ne veux pas vous voir chez moi tant que je n'aurai pas appris de d'Ogeron le contenu de la dépêche. Et priez pour qu'il n'y ait rien de « ce genre » dedans !";
            link.l1 = "Compris, mynheer. Je vous présente encore mes excuses...";
            link.l1.go = "Step_7_7";
        break;
        case "Step_7_7":
            dialog.text = "Dehors !!!";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "exit";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.State = "DelivLettTortuga_WaitingNews";
            DeleteAttribute(pchar, "questTemp.State.KingResult");
            BackItemDescribe("letter_1");
			ChangeCharacterReputation(pchar, -10);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", -170);
			AddCharacterExpToSkill(pchar, "Defence", -130);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " s'est fait littéralement jeter dehors de la résidence du gouverneur général...", HOLLAND, 5, 1);
        break;

        case "Step_7_20":
            dialog.text = "Et c'est plus que vrai ! Maintenant, je vous prie de me laisser, je n'ai pas d'affaire pour vous. Peut-être y aura-t-il quelque chose à l'avenir, mais pas maintenant.";
            link.l1 = "Bien, mynheer. Merci, mynheer.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_7_DelivLettTortuga");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "40";
			ChangeCharacterReputation(pchar, -3);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -2);
			AddCharacterExpToSkill(pchar, "Repair", -170);
			AddCharacterExpToSkill(pchar, "Defence", -130);
			AddCharacterExpToSkill(pchar, "Cannons", -150);
        break;

        case "Step_7_8":
            dialog.text = "Parfait ! Je suis heureux que tout se soit si bien réglé.";
            link.l1 = "Oui, et plus encore. Vous ne pouvez même pas imaginer : les Espagnols s'en sont pris à moi en plein Tortuga.";
            link.l1.go = "Step_7_9";
        break;
        case "Step_7_9":
            dialog.text = "דa alors ! Et alors ?";
            link.l1 = "Ils voulaient m'enlever la dépêche de réponse de d'Ogeron.";
            link.l1.go = "Step_7_10";
        break;
        case "Step_7_10":
            dialog.text = "Vous l'avez ?";
            link.l1 = "Bien sמr, mynheer. Tout va bien, la voici !";
            link.l1.go = "Step_7_11";
        break;
        case "Step_7_11":
            dialog.text = "Je vous suis plus que reconnaissant pour votre rapidité et votre courage. Vous avez peut-être évité une crise politique en Europe.";
            link.l1 = "Monsieur d'Ogeron m'a exposé la situation, je comprends de quoi il s'agit.";
            link.l1.go = "Step_7_12";
            TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
        break;
        case "Step_7_12":
            dialog.text = "Eh bien, j'ai le plaisir de vous annoncer que la récompense pour cette mission est de 150 000.";
            link.l1 = "Formidable, mynheer ! Et merci.";
            link.l1.go = "Step_7_13";
        break;
        case "Step_7_13":
            dialog.text = "Je vous attendrai chez moi dans quelque temps. Je crois que j'aurai encore des missions pour UN TEL officier !";
            link.l1 = "Je passerai chez vous régulièrement, sans faute.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_7_DelivLettTortuga");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "8";
            pchar.questTemp.Waiting_time = "10";
            DeleteAttribute(pchar, "questTemp.State.KingResult");
            AddMoneyToCharacter(pchar, 150000);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 6);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 200);
			AddCharacterExpToSkill(pchar, "Sneak", 300);
			AddCharacterExpToSkill(pchar, "Cannons", 250);
			AddCharacterExpToSkill(pchar, "Accuracy", 350);
			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + ", qui faisait office de messager, a connu une sérieuse mésaventure : les Espagnols ont soudain attaqué ce capitaine en plein Tortuga. Mais "+ GetSexPhrase("il est sorti","elle est sortie") +" vainqueur du combat.", HOLLAND, 5, 1);
        break;
        //********************** Квест №8, Поиски Евангелие для Аарона ************************
        case "Step_8_1":
            dialog.text = "Mais ce n'était pas suffisant. Je suis stupéfait de votre échec : vous n'avez pas su accomplir la mission la plus simple. Bon, venez me voir de temps en temps, je pourrai peut-être vous trouver quelque chose que vous saurez faire.";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_8_SeekBible");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "9";
            pchar.questTemp.Waiting_time = "30";
			ChangeCharacterReputation(pchar, -2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), -1);
			AddCharacterExpToSkill(pchar, "Repair", -270);
			AddCharacterExpToSkill(pchar, "Sneak", -260);
			AddCharacterExpToSkill(pchar, "Cannons", -300);
			AddCharacterExpToSkill(pchar, "FencingLight", -270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", -230);
			AddCharacterExpToSkill(pchar, "Fencing", -250);
 			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " a accepté une mission inhabituelle : la recherche d'un mystérieux traité biblique. Accepté, mais pas accompli...", HOLLAND, 5, 1);
		break;
        case "Step_8_2":
            dialog.text = "Ah, c'est donc ça... Eh bien, très bien. J'espère qu'il vous a remercié comme il se doit ?";
            link.l1 = "Et plus encore, mynheer.";
            link.l1.go = "Step_8_3";
        break;
        case "Step_8_3":
            dialog.text = "Parfait. C'est peut-être tout. Je n'ai pas encore besoin de vous, vous pouvez vaquer à vos affaires. Mais d'ici deux semaines, venez me voir, j'aurai sמrement une nouvelle mission pour vous.";
            link.l1 = "Toujours à votre service, mynheer.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_8_SeekBible");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "9";
            pchar.questTemp.Waiting_time = "2";
			TakeItemFromCharacter(pchar, "LegransMap");
			ChangeCharacterReputation(pchar, 2);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 270);
			AddCharacterExpToSkill(pchar, "Sneak", 260);
			AddCharacterExpToSkill(pchar, "Cannons", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 230);
			AddCharacterExpToSkill(pchar, "Fencing", 250);
 			//слухи
			AddSimpleRumour("On dit que le capitaine " + GetFullName(pchar) + " a accepté une mission inhabituelle : la recherche d'un mystérieux traité biblique. Et on dit que le traité a été retrouvé.", HOLLAND, 5, 1);
        break;
        //********************** Квест №9, Захват линейных кораблей. ************************
        case "Step_9_1":
            dialog.text = "Si nous ne pouvons pas construire de grands navires, nous devons les capturer !";
            link.l1 = "וtonnant ! Comme tout ce qui est génial...";
            link.l1.go = "Step_9_2";
        break;
        case "Step_9_2":
            dialog.text = "Hum, c'est juste... Je vous demande donc de mettre au moins quatre navires de premier rang, c'est-à-dire des vaisseaux de ligne, à la disposition de la flotte hollandaise.";
            link.l1 = "Hum... Pas mal, peut-être...";
            link.l1.go = "Step_9_3";
        break;
        case "Step_9_3":
            dialog.text = "Je le pense aussi. Capturez au moins quatre navires, amenez-les à Curaçao, au port de Willemstad, et remettez-les-moi en personne. On vous paiera 50 000 pièces pour chacun des navires remis. Pensez-vous pouvoir vous charger de cette mission ?";
            link.l1 = "Je suppose que oui.";
            link.l1.go = "Step_9_4";
        break;
        case "Step_9_4":
            dialog.text = "Alors ne perdons pas de temps : mettez-vous au travail immédiatement.";
            link.l1 = "Bien, mynheer, je commence immédiatement.";
            link.l1.go = "exit";
            pchar.questTemp.QtyShips = 4;
            pchar.questTemp.State = "TakeThreeShips_toAbordage";
            AddQuestRecord("Hol_Line_9_TakeThreeShips", "1");
            SaveCurrentQuestDateParam("questTemp");
        break;
        case "Step_9_5":
            if (sti(pchar.questTemp.QtyShips)>1)
            {
                dialog.text = "Excellent, mais la mission n'est pas encore entièrement accomplie : vous devez fournir à notre flotte encore " + pchar.questTemp.QtyShips + " navires. Ne perdez pas de temps, j'attends de bonnes nouvelles de votre part.";
            }
            else
            {
                dialog.text = "Excellent, mais la mission n'est pas encore entièrement accomplie : vous devez fournir à notre flotte un navire de plus. Ne perdez pas de temps, j'attends de bonnes nouvelles de votre part.";
            }
            link.l1 = "Bien, mynheer, je ferai tout ce qu'il faut.";
            link.l1.go = "exit";
        break;
        case "Step_9_6":
            dialog.text = "Parfait ! Je vais immédiatement ordonner d'envoyer les navires capturés dans l'océan Indien.";
            link.l1 = "Pourquoi là-bas, si je puis me permettre, mynheer ?";
            link.l1.go = "Step_9_7";
        break;
        case "Step_9_7":
            dialog.text = "Parce qu'il y a là-bas un affrontement actif avec le Portugal. Et en ce moment même, les Portugais ont remporté quelques succès. Je pense que cette escadre rétablira l'équilibre.";
            link.l1 = "Eh bien, voyez vous-même. Mais à votre place, je ne serais pas aussi optimiste quant à la situation ici, dans les Caraïbes.";
            link.l1.go = "Step_9_8";
        break;
        case "Step_9_8":
            dialog.text = "Que voulez-vous dire ?";
            link.l1 = "Ne pensez-vous pas que ces navires pourraient être utiles ici ? Pour renforcer la protection des colonies hollandaises, par exemple.";
            link.l1.go = "Step_9_9";
        break;
        case "Step_9_9":
            dialog.text = "Eh bien, non, bien sמr. Rien ne nous menace, soyez tranquille quant au sort des colonies hollandaises.";
            link.l1 = "Bien, mynheer. Cependant, ce calme me paraît trompeur. D'ailleurs, la Hollande est tout de même en guerre contre l'Angleterre.";
            link.l1.go = "Step_9_10";
        break;
        case "Step_9_10":
            dialog.text = "La phase active des combats est passée. Les Anglais n'ont pas le temps de s'occuper de nous, ils ont des problèmes avec les Espagnols. D'ailleurs, l'évaluation de la situation politique ne vous regarde pas.";
            link.l1 = "Je donnais simplement mon avis...";
            link.l1.go = "Step_9_11";
        break;
        case "Step_9_11":
            dialog.text = "Votre avis a été pris en compte. Et maintenant, je vais vous demander de me laisser. Mais dans quelque temps, j'aimerais vous revoir chez moi.";
            link.l1 = "Bien, mynheer.";
            link.l1.go = "exit";
			AddTitleNextRate(sti(NPChar.nation), 1);
            CloseQuestHeader("Hol_Line_9_TakeThreeShips");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "10";
            pchar.questTemp.Waiting_time = "20";
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Sailing", 290);
			AddCharacterExpToSkill(pchar, "Leadership", 100);
			AddCharacterExpToSkill(pchar, "Commerce", 250);
			AddCharacterExpToSkill(pchar, "Pistol", 350);
			//слухи
			AddSimpleRumour("Capitaine, vous avez capturé tant de vaisseaux de ligne que c'en est tout simplement époustouflant !", HOLLAND, 5, 1);
        break;
        //********************** Квест №10, Оборона Кюрасао. ************************
        case "Step_10_1":
            dialog.text = "On m'a informé qu'une grande escadre espagnole approchait de Curaçao. Je ne sais pas si nous pourrons résister à une attaque... Je n'ai aucune idée de la façon dont l'Espagne a réussi à rassembler de telles forces dans les eaux des Caraïbes, et en si peu de temps\n"+
                          "Cependant, nous y réfléchirons plus tard, si nous survivons. Maintenant, je vous prie de mettre tout votre savoir et tout votre talent au service du fort et de l'escadre de garde pour repousser l'attaque. Sans votre aide, je suis certain que nous serons écrasés.";
            link.l1 = "Je ferai de mon mieux. Je pense que nous allons les repousser.";
            link.l1.go = "Step_10_2";
        break;
        case "Step_10_2":
            dialog.text = "Eh bien, je compte sur vous !";
            link.l1 = "א après la bataille.";
            link.l1.go = "exit";
            pchar.questTemp.State = "SpaAttackCuracao_toBattle";
            AddQuestRecord("Hol_Line_10_SpaAttackCuracao", "1");
 		 AddQuestUserData("Hol_Line_10_SpaAttackCuracao", "sSex", GetSexPhrase("", "e"));
            SaveCurrentQuestDateParam("questTemp");
            Pchar.quest.SpaAttackCuracao_Battle.win_condition.l1 = "location";
            Pchar.quest.SpaAttackCuracao_Battle.win_condition.l1.location = "Curacao";
            Pchar.quest.SpaAttackCuracao_Battle.win_condition = "SpaAttackCuracao_Battle";
        break;
        case "Step_10_3":
            dialog.text = "Je suis d'un autre avis : votre participation au combat a été décisive ! Je ne pense pas que l'argent soit ce qui compte le plus dans votre vie, mais je vous prie d'accepter 200 000 pièces en récompense pour avoir sauvé la ville.";
            link.l1 = "Vraiment, mynheer, je ne mérite sans doute pas ça...";
            link.l1.go = "Step_10_4";
        break;
        case "Step_10_4":
            dialog.text = "Je ne veux rien entendre : les Pays-Bas doivent encourager de telles personnes par tous les moyens. Un point c'est tout ! Et maintenant, je dois recueillir le plus d'informations possible sur les raisons de l'attaque espagnole contre Curaçao. Je vous prie de revenir me voir dans quelques jours ; apparemment, ce n'est pas tout...";
            link.l1 = "Bien, mynheer, je serai chez vous à ce moment-là.";
            link.l1.go = "exit";
			AddTitleNextRate(sti(NPChar.nation), 1);
            AddMoneyToCharacter(pchar, 200000);
            CloseQuestHeader("Hol_Line_10_SpaAttackCuracao");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "11";
            pchar.questTemp.Waiting_time = "3";
			AddTitleNextRate(sti(NPChar.nation), 1);
			ChangeCharacterReputation(pchar, 7);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Repair", 270);
			AddCharacterExpToSkill(pchar, "Sneak", 260);
			AddCharacterExpToSkill(pchar, "Cannons", 300);
			AddCharacterExpToSkill(pchar, "FencingLight", 270);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 230);
			AddCharacterExpToSkill(pchar, "Fencing", 250);
			//слухи
			AddSimpleRumour("Vous nous avez sauvés, capitaine ! Repousser une attaque aussi puissante, c'est tout simplement magnifique !", HOLLAND, 5, 5);
        break;
        //********************** Квест №11, Спасение Мариго от испанцев. ************************
        case "Step_11_1":
            dialog.text = "C'est bien ce qui s'est passé. On dirait que nous avons trop joué à « aider les Français »...";
            link.l1 = "Que voulez-vous dire, mynheer ?";
            link.l1.go = "Step_11_2";
        break;
        case "Step_11_2":
            dialog.text = "Vous savez que Louis XIV mène contre l'Espagne la guerre de Dévolution pour le prétendu héritage espagnol : la Flandre et la Bourgogne. Bien que ces territoires ne fassent pas partie de la République des Provinces-Unies, ils sont néanmoins liés à la Hollande par la langue et la culture. C'est pourquoi nous faisons tout notre possible pour aider les Français dans cette guerre : financièrement, bien sמr\n"+
                          "Il semble que l'Espagne ait sérieusement décidé de tarir ce flot d'argent avec lequel Louis paie généreusement la guerre. C'est une décision bien calculée, je dois dire, car la France est dans une situation financière très difficile, et sans notre argent, Louis n'aura tout simplement plus de quoi payer la conduite de la guerre\n"+
                          "J'ai appris aujourd'hui que Curaçao n'est pas la seule colonie hollandaise à avoir été attaquée. Saint-Martin est elle aussi assiégée.";
            link.l1 = "Bon sang...";
            link.l1.go = "Step_11_3";
        break;
        case "Step_11_3":
            dialog.text = "Je vous prie de rassembler toutes vos forces et de vous rendre immédiatement à Saint-Martin pour aider les assiégés. Vous devez essayer de sauver la ville de la destruction à temps.";
            link.l1 = "Je ferai de mon mieux, mynheer. Comptez sur moi.";
            link.l1.go = "Step_11_4";
        break;
        case "Step_11_4":
            dialog.text = "Oui, il semble que je n'aie tout simplement pas le choix.";
            link.l1 = "Je pars immédiatement.";
            link.l1.go = "exit";
            pchar.questTemp.State = "SpaAttackSentMartin_toBattle";
            AddQuestRecord("Hol_Line_11_SpaAttackSentMartin", "1");
            SaveCurrentQuestDateParam("questTemp");
            Pchar.quest.SpaAttackSentMartin_Battle.win_condition.l1 = "location";
            Pchar.quest.SpaAttackSentMartin_Battle.win_condition.l1.location = "SentMartin";
            Pchar.quest.SpaAttackSentMartin_Battle.win_condition = "SpaAttackSentMartin_Battle";
            SetTimerCondition("SpaAttackSentMartin_YouLate", 0, 0, 10, false);
        break;
        case "Step_11_5":
            dialog.text = "C'est fâcheux. Mais on n'y peut rien, c'est la vie.";
            link.l1 = "J'en suis vraiment désolé...";
            link.l1.go = "Step_11_6";
        break;
        case "Step_11_6":
            dialog.text = "Vous avez fait tout ce que vous pouviez, l'alerte vous est parvenue trop tard. Bon, assez parlé de ça ! Je vous prie de venir à ma résidence dans un mois environ. Ne perdez pas de temps : remettez vos navires en état, recrutez un équipage, refaites le plein de munitions. Bref, préparez-vous bien à la riposte. Il me semble que le moment est venu pour les Pays-Bas d'agrandir leurs possessions coloniales dans les Caraïbes.";
            link.l1 = "Et quelle ville devra devenir hollandaise ?";
            link.l1.go = "Step_11_7";
        break;
        case "Step_11_7":
            dialog.text = "Je ne le sais pas encore. Tout dépend des informations que j'obtiendrai prochainement.";
            link.l1 = "Compris, mynheer. Je serai chez vous dans un mois.";
            link.l1.go = "exit";
            CloseQuestHeader("Hol_Line_11_SpaAttackSentMartin");
            pchar.questTemp.State = "empty";
            SaveCurrentQuestDateParam("questTemp");
            pchar.questTemp.CurQuestNumber = "12";
            pchar.questTemp.Waiting_time = "30";
        break;
        case "Step_11_8":
            dialog.text = "Parfait, "+ GetSexPhrase("mon ami","" + pchar.name + "") +", tout simplement formidable. Je n'ai jamais douté de vous.";
            link.l1 = "דa fait plaisir à entendre, mynheer.";
            link.l1.go = "Step_11_9";
        break;
        case "Step_11_9":
            dialog.text = "Votre récompense pour avoir sauvé Saint-Martin est de 200 000 pièces. Veuillez les recevoir.";
            link.l1 = "Merci, mynheer.";
            link.l1.go = "Step_11_10";
            AddMoneyToCharacter(pchar, 200000);
			AddTitleNextRate(sti(NPChar.nation), 2);
			ChangeCharacterReputation(pchar, 6);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 1);
			AddCharacterExpToSkill(pchar, "Pistol", 430);
			AddCharacterExpToSkill(pchar, "Fortune", 460);
			AddCharacterExpToSkill(pchar, "Accuracy", 420);
			AddCharacterExpToSkill(pchar, "Grappling", 450);
			//слухи
			AddSimpleRumour("On dit que vous avez sauvé Saint-Martin de la destruction ! Beau travail, capitaine !", HOLLAND, 5, 1);
        break;
        case "Step_11_10":
            dialog.text = "Je vous prie aussi de venir à ma résidence dans un mois environ. Ne perdez pas de temps : remettez vos navires en état, recrutez un équipage, refaites le plein de munitions. Bref, préparez-vous bien à la riposte. Les Espagnols sont épuisés, et c'est maintenant le moment pour les Pays-Bas d'agrandir leurs possessions coloniales dans les Caraïbes.";
            link.l1 = "Et quelle ville devra devenir hollandaise ?";
            link.l1.go = "Step_11_7";
        break;
        //********************** Квест №12, Захват Венесуэллы. ************************
        case "Step_12_1":
            dialog.text = "Je le pense aussi. Eh bien, mettez-vous au travail.";
            link.l1 = "Je suis prêt pour l'opération : la ville de Maracaibo sera hollandaise !";
            link.l1.go = "Step_12_2";
        break;
        case "Step_12_2":
            dialog.text = "Qu'il en soit ainsi !";
            link.l1 = "Je pars immédiatement, mynheer.";
            link.l1.go = "exit";
            pchar.questTemp.State = "OccupyMaracaibo_toFight";
            AddQuestRecord("Hol_Line_12_OccupyMaracaibo", "1");
            SaveCurrentQuestDateParam("questTemp");
			characters[GetCharacterIndex("Maracaibo_Mayor")].dialog.captureNode = "HolLine12Quest_Occupy"; //капитулянтская нода мэра
        break;
        case "Step_12_3":
            dialog.text = "J'ai déjà envoyé un rapport sur cette acquisition à la métropole. Notre וtat, notre jeune nation, a soif de victoires ! Et nous faisons tout pour la prospérité de la République des Provinces-Unies\n"+
                          "Vous avez donc fait du bon travail. Je n'ai plus de missions pour vous. Mais j'espère sincèrement que vos actions futures dans la région des Caraïbes seront tout aussi efficaces et tout aussi fructueuses.";
            link.l1 = "Je pense que vous pouvez compter sur moi, mynheer. Le bien des Pays-Bas passe avant tout !";
            link.l1.go = "Step_12_4";
        break;
        case "Step_12_4":
            dialog.text = "Voilà des paroles dignes "+ GetSexPhrase("d'un grand guerrier et d'un vrai patriote","d'une grande guerrière et d'une vraie patriote") +" ! Et maintenant, je vous prie d'accepter de ma part 300 000 pièces en paiement de vos loyaux services.";
            link.l1 = "Merci, mynheer.";
            link.l1.go = "Step_12_5";
            AddMoneyToCharacter(pchar, 300000);
        break;
        case "Step_12_5":
            dialog.text = "Eh bien, maintenant, dites-moi, quels sont vos projets ?";
            link.l1 = "Dormir tout mon soמl, mynheer. Et ensuite, nous verrons.";
            link.l1.go = "Step_12_6";
        break;
        case "Step_12_6":
            dialog.text = "Eh bien, je n'ose pas vous déranger.";
            link.l1 = "Au revoir, mynheer.";
            link.l1.go = "exit";
            DeleteAttribute(pchar, "questTemp.Waiting_time");
            pchar.questTemp.State = "EndOfQuestLine";
			CloseQuestHeader("Hol_Line_12_OccupyMaracaibo");
			bWorldAlivePause   = false; // Конец линейки
			AddTitleNextRate(sti(NPChar.nation), 4);
			ChangeCharacterReputation(pchar, 5);
			ChangeCharacterNationReputation(pchar, sti(NPChar.nation), 20);
			AddCharacterExpToSkill(pchar, "Repair", 630);
			AddCharacterExpToSkill(pchar, "Sneak", 490);
			AddCharacterExpToSkill(pchar, "FencingLight", 530);
			AddCharacterExpToSkill(pchar, "FencingHeavy", 530);
			AddCharacterExpToSkill(pchar, "Fencing", 530);
			AddCharacterExpToSkill(pchar, "Pistol", 530);
			AddCharacterExpToSkill(pchar, "Fortune", 660);
			AddCharacterExpToSkill(pchar, "Accuracy", 520);
			AddCharacterExpToSkill(pchar, "Grappling", 750);
			//слухи
			AddSimpleRumour("Capitaine, on dit que vous avez réussi à vous emparer du Venezuela ! דa alors...", HOLLAND, 5, 1);
        break;

        //********************** Французская линейка. Квест №2, доставка письма д'Ожерона. ************************
        case "Step_F2_1":
            dialog.text = "Oui, oui, merci... et vous affirmez que c'est le gouverneur général d'Ogeron qui vous a remis cette lettre ?";
            link.l1 = "Bien sמr ! J'ai l'honneur d'être au service du roi de France.";
            link.l1.go = "Step_F2_2";
            TakeItemFromCharacter(pchar, "letter_1");
            BackItemDescribe("letter_1");
        break;
        case "Step_F2_2":
            dialog.text = "Mais vous n'êtes pas officier. D'Ogeron n'a donc plus de soldats ? Il me semble plutכt que vous êtes au service des Frères de la Cכte, que vous avez intercepté cette lettre et que vous êtes ici pour espionner ! Gardes, sus à "+ GetSexPhrase("lui","elle") +" !!!";
            link.l1 = "וcoutez, monsieur...";
            link.l1.go = "Step_F2_3";
        break;
        case "Step_F2_3":
			pchar.questTemp.State = "Fr2Letter_Arrest";
			for (i=1; i<=3; i++)
			{
				tempStr = "sold_hol_"+i;
				if (i==3) tempStr = "off_hol_1";
				sld = GetCharacter(NPC_GenerateCharacter("Guard_"+i, tempStr, "man", "man", 30, HOLLAND, 0, true));
				sld.Dialog.Filename = "Quest\FraLineNpc_2.c";
				FantomMakeCoolFighter(sld, 30, 70, 60, "blade34", "pistol2", 70);
         		ChangeCharacterAddressGroup(sld, pchar.location, "reload", "reload1_back");
				LAi_SetWarriorType(sld);
			}
			LAi_SetActorType(pchar);
            LAi_SetActorType(sld);
            SetActorDialogAny2Pchar(sld.id, "", -1, 0.0);
		    LAi_ActorFollow(pchar, sld, "ActorDialog_Any2Pchar", 0.0);
			DialogExit();
        break;
 		case "Step_F2_4":
    		dialog.text =  NPCStringReactionRepeat("Je vous écoute attentivement.",
            "Nous avons déjà parlé de ce sujet...", "Encore ?", "Assez !", "block", 0, npchar, Dialog.CurrentNode);
    		link.l1 = HeroStringReactionRepeat("Monsieur le gouverneur général, à ma connaissance, des pirates sévissaient près de Curaçao ; ils ont coulé deux douzaines de navires.", "Oui, exactement...", "Non, désolé...", "Désolé...", npchar, Dialog.CurrentNode);
    		link.l1.go = DialogGoNodeRepeat("Step_F2_5", "none", "none", "none", npchar, Dialog.CurrentNode);
 		break;
        case "Step_F2_5":
            dialog.text = "C'est exact. Eh bien, et alors ?";
            link.l1 = "J'ai réussi à retrouver les bandits en ville et à suivre leur piste jusqu'au galion qui chassait les navires hollandais. Ces bandits se sont révélés être des corsaires espagnols.";
            link.l1.go = "Step_F2_6";
        break;
        case "Step_F2_6":
            dialog.text = "Et oם est ce galion ?";
            link.l1 = "Par le fond, près de la plage des Palmiers. Je l'ai abordé et j'ai tué l'équipage. J'ai interrogé le capitaine avant sa mort, il ne peut donc y avoir aucun doute : c'est bien le galion qui vous harcelait.";
            link.l1.go = "Step_F2_7";
        break;
        case "Step_F2_7":
            dialog.text = "Eh bien, que dire : c'est tout simplement formidable ! Vous avez rendu un grand service à la ville. Je dois avouer que je croyais que c'était l'œuvre des Frères de la Cכte...";
            link.l1 = "Je m'en doutais, monsieur, c'est pourquoi j'ai mené ces recherches. Les flibustiers n'attaquent pas les navires hollandais.";
            link.l1.go = "Step_F2_8";
        break;
        case "Step_F2_8":
            dialog.text = "Heureusement que je ne vous ai pas fait pendre... Eh bien, je suppose que vous méritez une récompense. Je suis prêt à vous payer 20 000 pièces d'or pour le galion pirate coulé. Cela vous convient-il ?";
            link.l1 = "Sans aucun doute, monsieur, cela suffit. Maintenant, permettez-moi de prendre congé : il est temps pour moi de rentrer. Au revoir.";
            link.l1.go = "exit";
			AddMoneyToCharacter(pchar, 20000);
			AddQuestRecord("Fra_Line_2_DelivLetter", "6");
			AddQuestUserData("Fra_Line_2_DelivLetter", "sSex", GetSexPhrase("", "e"));
        break;
		// --------------------- линейка ГПК, вопрос о Тизере ---------------------
		case "TizerFind":
			dialog.text = "Si je connais cette personne, je vous répondrai sans hésiter, capitaine.";
			link.l1 = "Je m'intéresse à Teaser Dan, mynheer.";
			link.l1.go = "TizerFind_1";
		break;
		case "TizerFind_1":
			dialog.text = "Il est bien étrange que vous vous intéressiez à un mendiant, un vagabond, un forçat et un ancien esclave !";
			link.l1 = "Un forçat ?";
			link.l1.go = "TizerFind_2";
		break;
		case "TizerFind_2":
			dialog.text = "C'est exact ! Pour sa participation aux troubles, il a été déchu de ses droits de citoyen hollandais et condamné aux travaux forcés. Cependant, le navire qui le transportait a été capturé par des pirates, et Teaser lui-même a été vendu comme esclave par ceux-ci...";
			link.l1 = "Diable, quel destin intéressant !";
			link.l1.go = "TizerFind_3";
		break;
		case "TizerFind_3":
			dialog.text = "Je n'y vois rien d'intéressant ! Et pourquoi vous intéressez-vous aux criminels ?";
			link.l1 = "Mynheer, le fait est que... En somme, je m'occupe de recueillir des exemples d'art populaire. Vous savez, quand je rentrerai dans l'Ancien Monde, je veux écrire un livre sur mes aventures dans le Nouveau. Voilà tout, monsieur... Et Teaser est un personnage très pittoresque !";
			link.l1.go = "TizerFind_4";
		break;
		case "TizerFind_4":
			dialog.text = "Vous êtes sérieux ?";
			link.l1 = "Absolument. J'ai eu l'occasion d'apprendre par les habitants de votre ville les histoires que Teaser racontait en public. C'est très intéressant, vous savez... Bien sמr, je comprends que tout cela n'est que mensonges, mais comme c'est divertissant ! Un matériau parfait pour un livre.";
			link.l1.go = "TizerFind_5";
		break;
		case "TizerFind_5":
			dialog.text = "Hum, j'encourage l'écriture. Ce sont de nouvelles terres, de nouveaux héros, de nouveaux horizons sur l'océan sans bornes... Oui, c'est très intéressant. Mais je ne m'attendais pas à de tels penchants de votre part, capitaine !";
			link.l1 = "Mynheer, il y a encore bien des choses que vous ignorez à mon sujet.";
			link.l1.go = "TizerFind_6";
		break;
		case "TizerFind_6":
			dialog.text = "Compris. Eh bien, je serais heureux de vous aider au sujet de Teaser Dan, mais je ne sais pas oם il est. Je n'en ai aucune idée. Le fait est que ce vagabond a troublé l'ordre public plus d'une fois, et j'ai dמ lui appliquer des mesures répressives. Je crois qu'il a quitté l'île.";
			link.l1 = "Dommage... Et je comprends que vous ne savez pas oם.";
			link.l1.go = "TizerFind_7";
		break;
		case "TizerFind_7":
			dialog.text = "Je vous ai déjà dit que je n'en avais aucune idée. Je vous suggère de décrire Curaçao telle qu'elle est, sans les sornettes idiotes d'un ancien esclave. Croyez-moi, votre ouvrage n'en sera que meilleur.";
			link.l1 = "Eh bien, je chercherai de la matière sur votre île. Merci !";
			link.l1.go = "exit";
			pchar.questTemp.LSC = "toLicencer";
			AddQuestRecord("ISS_PoorsMurder", "9");
			AddQuestUserData("ISS_PoorsMurder", "sSex", GetSexPhrase("", "e"));
			AddQuestUserData("ISS_PoorsMurder", "sSex1", GetSexPhrase("", "e"));
		break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}
