// Gregg: Cristobal Kuvalda, a hired axeman - the "Black Orchid" trilogy (ported from
// Damned Destiny). Logic - Program\Quests\reaction_functions\blackorchid.c
// The headman of the pearl divers' village asks the player to fetch Kuvalda before
// Feregueyro's servants fall upon the village:
//   First time - the stock line;
//   1-2 - at the cave mouth, right after the fight with the Aztecs: talked into going back;
//   3-8 - the village has held; Kuvalda brags about his stroke. All three answers
//         come out at the same place - go and report to the headman.
// In the original the player called the headman Rodrigo, though HeadMan_1 is given a
// random name when generated - here he is simply "the headman".

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	string sBro = GetSexPhrase("frère", "sœur");

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Ce sont les serviteurs de Feregueyro, " + sBro + " ! Il faut prévenir le village : Feregueyro est de retour !";
			link.l1 = "Le chef du village est déjà prévenu, ils se préparent à défendre les lieux. Et on m'a envoyé te chercher : le village a besoin de toi.";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je sais, j'allais justement y courir moi-même. Que le diable l'emporte, il faut se dépêcher, il n'y a plus une minute à perdre ! Ah, et une dernière chose. Merci pour le coup de main, " + sBro + ".";
			link.l1 = "Ce n'est rien, Cristobal. Le temps presse : courons au village.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftToPearlVillageJungle");
		break;

		case "3":
			dialog.text = "Ha, c'était un vrai massacre ! Tu m'as vu étendre un de ces misérables, " + sBro + " ?";
			link.l1 = "Je n'ai pas eu le temps de te regarder, j'avais bien assez à faire de mon cכté.";
			link.l1.go = "4";
			link.l2 = "Non, mais je jetais un coup d'œil de ton cכté de temps en temps pour voir comment tu t'en sortais.";
			link.l2.go = "6";
			link.l3 = "Bien sמr que je l'ai vu. Un beau coup.";
			link.l3.go = "8";
		break;

		case "4":
			dialog.text = "C'est mauvais, " + sBro + ". Au combat, il faut garder un œil sur ses amis : l'un d'eux peut avoir besoin d'aide, et alors, tu cours le tirer d'affaire.";
			link.l1 = "Très bien, je m'en souviendrai. Je garderai l'œil ouvert.";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "C'est bon. Va, " + sBro + ", annonce que nous les avons repoussés, et moi, je t'attendrai ici.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftInPearlVillageToOfficerHouse");
		break;

		case "6":
			dialog.text = "Ah, si tu avais vu ça ! L'un d'eux me fonce dessus, alors je me retourne comme un gamin à la foire et je lui donne un coup du plat de la hache. Je voulais juste l'assommer, mais j'ai mal mesuré le coup, et je lui ai défoncé le crâne.";
			link.l1 = "Entraîne-toi à mesurer tes coups quand tu veux seulement assommer quelqu'un.";
			link.l1.go = "7";
		break;

		case "7":
			dialog.text = "Très bien, " + sBro + ", va annoncer que nous les avons repoussés, et moi, je t'attendrai ici.";
			link.l1 = "Très bien.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DestinyGiftInPearlVillageToOfficerHouse");
		break;

		case "8":
			dialog.text = "J'en ai été surpris moi-même. Je voulais juste l'assommer, mais j'ai mal mesuré le coup, et je l'ai tué.";
			link.l1 = "Entraîne-toi à mesurer tes coups quand tu veux seulement assommer quelqu'un.";
			link.l1.go = "7";
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
