
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit()
		break;
		
		case "First time":
			dialog.text = "Si vous venez pour le transport de marchandises, le paiement des droits ou un recrutement, il faut vous rendre dans l'aile droite du bâtiment. Cette aile-ci abrite l'Amirauté, qui ne s'occupe que des navires au service de Sa Majesté.";
			Link.l1 = "Je vois. Bonne journée.";
			link.l1.go = "exit";
			if (pchar.questTemp.AnjelikaTichPrologue3 == "ATP3")
			{
				dialog.text = "";
				Link.l1 = "Je m'appelle Angelica Remedios, j'ai un message urgent pour le gouverneur. On m'a dit qu'il était ici en ce moment.";
				link.l1.go = "AT_pr_Pochta1";
			}
			if (pchar.questTemp.AnjelikaTichPrologue3_1 == "ATP3_1")
			{
				dialog.text = "Vous cherchez votre chemin ?";
				Link.l1 = "Non. Tout va bien, je m'en vais.";
				link.l1.go = "exit";
			}
		break;
		
		//Sinistra Пролог Анжелика Тич
		case "AT_pr_Pochta1":
			dialog.text = "Remedios ? Vous êtes une parente de l'ancien gouverneur de notre colonie de La Vega.";
			Link.l1 = "Exactement. Alors, le gouverneur est-il ici ?";
			link.l1.go = "AT_pr_Pochta2";
		break;
		
		case "AT_pr_Pochta2":
			dialog.text = "Oui, bien sמr. Montez à l'étage.";
			Link.l1 = "Merci.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.AnjelikaTichPrologue3");
			pchar.questTemp.AnjelikaTichPrologue3_1 = "ATP3_1";
			
			sld = CharacterFromID("SantoDomingo_Mayor")
			sld.model = "huber_spa";
			sld.greeting = "";
			sld.Dialog.Filename = "Quest\AngelikaTichLine\MechtySbyvautsya.c";
			sld.dialog.currentnode = "ATpr_SD_Gubernator_1";
			LAi_SetStayType(sld);
			ChangeCharacterAddressGroup(sld, "SantoDomingo_Admiralty", "quest", "quest4");
			
			sld = GetCharacter(NPC_GenerateCharacter("ATpr_SD_Off_Guber_1", "off_spa_1", "man", "man", 30, SPAIN, -1, false));
			LAi_SetActorType(sld);
			LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "SantoDomingo_Admiralty", "quest", "quest8");
			
			sld = GetCharacter(NPC_GenerateCharacter("ATpr_SD_Off_Guber_2", "off_spa_2", "man", "man", 30, SPAIN, -1, false));
			LAi_SetActorType(sld);
			LAi_SetImmortal(sld, true);
			ChangeCharacterAddressGroup(sld, "SantoDomingo_Admiralty", "quest", "quest2");
		break;
		
		case "Strajniki":
			dialog.text = RandPhraseSimple("Je vous ai à l'œil.", ""+ GetSexPhrase("Señor", "Señorita") +", ceci est un établissement d'וtat : veuillez vous y conduire comme il se doit.");
			Link.l1 = RandPhraseSimple("Je m'en souviendrai.", "J'ai compris.");
			link.l1.go = "exit";
			NextDiag.TempNode = "Strajniki";
		break;
	}
}
