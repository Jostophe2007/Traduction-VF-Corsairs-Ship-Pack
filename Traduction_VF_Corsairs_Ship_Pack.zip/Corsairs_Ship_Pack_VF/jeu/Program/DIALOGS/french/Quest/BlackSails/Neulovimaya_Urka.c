
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		//Заменить хозяйку борделя в ПР на Максин. Пускать на глобалке английских охотников (скоростые) 2-3 третьеклассника.//по поводу охотников. сейчас спавнится только один рядом с Бермудами. так как переезжаем на Багамы - спавнить фиолетового догонялу от Пуэрто Принсибе и ещё одного у Ямайки. для огоньку 7.04.2023

		//Прибыли в ПР. Идём в бордель к мадам. Опа, сюрприз. Это Макс //помимо квестовых диалогов, на будущее, её нужно сделать мадам в ПР по завершению квеста. если возможно, то с дармовыми шлюхами. типо по старой дружбе. ну или лично с ней дармовой перепихон. пусть отрабатывает лям =) 7.04.2023

		case "BS_NU_1":	//Максин
			dialog.text = "...";
			link.l1 = "Félicitations pour ta promotion ! C'est inattendu, cela dit.";
			link.l1.go = "BS_NU_2";
		break;

		case "BS_NU_2":
            dialog.text = "Mes salutations, "+pchar.name+". Tu as décidé de te détendre ou de distraire ton équipage ?";
            link.l1 = "J'ai besoin de ton aide. Je sais que les filles des bordels voient et entendent beaucoup de choses, et j'aimerais t'acheter quelques informations.";
			link.l1.go = "BS_NU_3";
		break;

		case "BS_NU_3":
            dialog.text = "Tu as besoin d'un tuyau sur une grosse proie ? Pas besoin de payer, je te le donnerai en retour : après tout, je te suis redevable.";
            link.l1 = "Ce n'est pas un tuyau qu'il nous faut, mais la moindre piste sur la plus grosse proie qu'on puisse imaginer ! Tu comprends ce que je veux dire ?";
			link.l1.go = "BS_NU_4";
		break;

		case "BS_NU_4":
            dialog.text = "L'Urca de Lima ! Flint ne s'embarrasse pas de broutilles. Je sais quelque chose, mais ce n'est pas gratuit, désolée.";
            link.l1 = "Fixe ton prix.";
			link.l1.go = "BS_NU_5";
		break;

		case "BS_NU_5":
            dialog.text = "Une part égale, comme associée. Et quelque chose de gratuit de ma part. Sur les corsaires anglais.";
            link.l1 = "Tu sais que les parts doivent être négociées avec tous les participants de l'entreprise ? Ou bien tu veux une part de ma part ?";
			link.l1.go = "BS_NU_6";
		break;

		case "BS_NU_6":
            dialog.text = "Je sais, et c'est pour ça que je pars avec toi. Et quand nous rencontrerons les autres associés, j'espère que nous parviendrons à un accord profitable à toutes les parties.";
            link.l1 = "D'accord, tu as gagné, on part tout de suite !";
			link.l1.go = "BS_NU_7";
		break;

		case "BS_NU_7":
            dialog.text = "Attends une minute. Une chose à propos des Anglais. Une escadre menée par le vaisseau de guerre Scarborough est arrivée dans les Caraïbes. On dit que c'est le renseignement militaire de l'Amirauté. Ils n'entrent pas dans les ports anglais, ils ne rendent pas de comptes aux gouverneurs. Beaucoup de corsaires et de pirates ont déjà disparu. Et certains ont été revus, mais ils faisaient comme s'ils n'étaient pas ceux qu'on croyait. Il se passe quelque chose d'étrange.";
            link.l1 = "J'ai déjà eu affaire plusieurs fois à des corsaires sous pavillon anglais. Rien de spécial. Mais ces Anglais sont très tenaces. D'une ténacité suicidaire.";
			link.l1.go = "BS_NU_8";
		break;

		case "BS_NU_8":
            dialog.text = "C'est tout ce que je sais d'eux. Je suis prête à partir.";
            link.l1 = "Allons-y. Attends, cependant. Tu as entendu parler de Charles Vane ? Il s'est montré dans les colonies ?";
			link.l1.go = "BS_NU_9";
		break;

		case "BS_NU_9":
            dialog.text = "Des pêcheurs ont repêché l'épave du Ranger près de la baie de Portland. Quelqu'un a entendu parler d'un combat non loin de l'île, renseigne-toi à la taverne. Ici ou à Fort Orange. Sur Charles lui-même, je n'ai rien entendu."; //посещать саму бухту - не нужно. сразу по завершению диалога, садить алкашей со слухом нужным и в ПР и в ФО. либо там либо там, по отработке слуха - следующая стадия 7.04.2023
            link.l1 = "C'est déjà ça. Il faudra vérifier. Monte à bord, je vais faire le tour des tavernes, les ivrognes du coin ont peut-être vu quelque chose. Demande à Sandro Thorn de te conduire à ta cabine, on ne sait jamais. Mes gars sont bien dressés, mais ils pourraient ne pas laisser passer une si jolie fille sans rien dire.";
			AddQuestRecord("BSUrka", "1");
			SetQuestHeader("BSUrka");
			CloseQuestHeader("BSChaseBegun");
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_NU_9_exit";
			pchar.BSUrka_Negril = true;
			PChar.quest.BSUrka_Negril.win_condition.l1 = "location";
			PChar.quest.BSUrka_Negril.win_condition.l1.location = "Shore36";
			PChar.quest.BSUrka_Negril.function = "BSUrka_Negril";
			SetFunctionExitFromLocationCondition("BS_RestoreMaksHostess", pchar.location, false);
		break;

		case "BS_NU_9_exit":
            dialog.text = "On se voit sur le navire, capitaine.";
            link.l1 = "Oui, à plus tard.";
			link.l1.go = "exit";
			NextDiag.TempNode = "BS_NU_9_exit";
		break;
		//Запись в СЖ: «Таинственные английские военные, пропавший Вейн и новый компаньон в нашем дельце на сто пятьдесят миллионов. Нужно проверить информацию о разбившемся 'Рейнджере' у местных выпивох и выдвигаться на Багамы. Как бы не упустить денежный галеон». 7.04.2023

		//бухта Портленд запись в СЖ: «Сломанные мачты, куски обшивки, рваный такелаж и прочий мусор. Нужно расспросить местных о случившемся» // для особо въедливых это можно и оставить. хз. только перенести триггер в бухту Портленд 7.04.2023

		//В форт Оранж или в Порт Рояле в таверне у бармена ничего. Выпиваем с алкашом – бинго. кстати слух в текущих фиксах ловится очень не сразу. нужен гарантированный алкаш 7.04.2023

		case "BS_NU_10":	//Алкоголик
            dialog.text = "א ta santé ! Ouh, il est bon, ce rhum. Si tu avais vu ce qui s'est passé dans la baie il y a deux jours ! Un brick pirate, tout cabossé par les boulets, avec des voiles de vaisseau fantכme, a livré bataille à deux frégates espagnoles. Et là, sortis de nulle part, de derrière le cap, trois pirates sur des corvettes ! On ne savait plus qui poursuivait qui. Les Espagnols se sont mis ensemble bâbord amures et ont ouvert le feu par batteries. Une corvette a été transpercée de la proue à la poupe, ça hurlait ! On l'entendait jusqu'au fort ! Bref, celle qui avait été touchée s'est aussitכt couchée sur le flanc et a commencé à couler, et les deux autres, à coups de bordées, ont mis la frégate en pièces presque à bout portant. Et le brick, celui qui fuyait les Espagnols, a soudain repris courage : il a jeté l'ancre à bâbord et viré brutalement autour de sa chaîne, si fort qu'il en a perdu un mât. Et il s'est mis à canonner le pirate par le travers. Bref, ils ont coulé la seconde corvette, avec l'Espagnol survivant. Hé, j'ai la gorge sèche.";
            link.l1 = "Tiens, bois encore un coup. Et alors, qu'est-ce qui s'est passé ensuite ? Quelle histoire ! Je vois ce combat comme si j'y étais !";
			link.l1.go = "BS_NU_11";
		break;

		case "BS_NU_11":
            dialog.text = "Ouh. דa fait du bien, merci bien. Bon. Le pirate, sur la corvette rescapée, a compris que ça tournait mal ; il s'est mis vent arrière et a filé à toutes voiles vers l'horizon ! Et sur le brick, ils ont coupé la chaîne d'ancre et se sont jetés bord contre bord sur la frégate. א l'abordage, donc. Et ils ont fini par vaincre les Espagnols ! La frégate a hissé le pavillon noir, a lâché une bordée sur le brick en lambeaux et est partie quelque part vers le nord. Une bataille pareille, on pourrait en faire un tableau ! Toute la cכte est couverte d'épaves !";
            link.l1 = "Merci pour l'histoire. Avec un tel talent, tu devrais écrire des livres !"; // хорошо бы вообще именного НПС под этот слух сделать Александр Оливье Эксквемелин. кто в теме пиратской истории - тот поймёт отсылку 7.04.2023
			link.l1.go = "exit";
		break;

		//Запись в СЖ: «Вейн жив, обзавёлся новым кораблём и выполнил свою часть по отвлечению сопровождения. Каков корсар! Надеюсь, увидимся на Багамах»

		//Выходим в море, спауним фиолетовую энку (англичане). Файт. Три фрегата, кэп флагмана – Билли Бонс. Берём на абордаж. Файт в каюте, после «убиения» - диалог.ВАЖНО! это ключевой момент для второго фварианта финала! Если убить Билла, то идём по первой ветке, если согласились, то по BS_Final_3 7.04.2023

		case "BS_NU_12":	//Билли Бонс
            dialog.text = "Halte ! Il faut que nous parlions !";
            link.l1 = "Tiens, tiens, tiens. Le second de Flint en personne, et voilà qu'il est capitaine anglais. Qu'est-ce que ça veut dire ?";
			link.l1.go = "BS_NU_13";
		break;

		case "BS_NU_13":
            dialog.text = "J'ai toujours été, et je suis toujours, capitaine anglais, ou plutכt commandant ! Renseignement de l'Amirauté, commandant William Blackham, à votre service.";
            link.l1 = "Et pourquoi diable le renseignement de l'Amirauté me pourchasse-t-il ? Tous ces corsaires que j'ai coulés, ils étaient à vous aussi ?";
			link.l1.go = "BS_NU_14";
		break;

		case "BS_NU_14":
            dialog.text = "Des corsaires, des pirates graciés qui sont passés au service de Sa Majesté. Beaucoup de zèle, mais malheureusement peu de savoir-faire.";
            link.l1 = "Je vois. De la chair à canon. Alors, que me veut votre service ?";
			link.l1.go = "BS_NU_15";
		break;

		case "BS_NU_15":
            dialog.text = "Flint. Ou plutכt le capitaine James McGraw, traître, voleur, assassin. Ancien officier de la marine de Sa Majesté, coupable du meurtre de Lord Hamilton, de sa femme, et d'une centaine d'autres crimes. Toutes mes tentatives pour arrêter ou tuer cet homme ont échoué, et je vous propose, à vous qui êtes son compagnon de confiance, d'aider un représentant de la Marine royale à arrêter ou à éliminer le traître !";
            link.l1 = "Et quel intérêt aurais-je à faire ça ?";
			link.l1.go = "BS_NU_16";
		break;

		case "BS_NU_16":	//Тут выбор
            dialog.text = "Le pardon royal pour vous et vos hommes, quatre cent mille livres en argent et la possibilité d'une brillante carrière à l'Amirauté. Sans compter la gratitude de la famille Hamilton, qui, croyez-moi, vaut beaucoup !";
            link.l1 = "Va au diable, Billy, avec ton pardon et ta Majesté ! Je ne trahis pas mes amis ! Et cette amitié me rapportera bien plus que tout ce que tu pourrais m'offrir ! Prêt à continuer ? Crève !";
			link.l1.go = "Fight_Billi_Bons";
			link.l2 = "Je vais y réfléchir. Comment puis-je te contacter ?"; //собственно вот вариант для второй финалки 7.04.2023
			link.l2.go = "BS_NU_17";
		break;

		case "Fight_Billi_Bons":
			AddQuestRecord("BSUrka", "4");
			pchar.BSBonsKilled = true;
			LAi_SetCurHPMax(npchar);
			QuestAboardCabinDialogExitWithBattle("");
            DialogExit();
			AddDialogExitQuest("MainHeroFightModeOn");
		break;

		case "BS_NU_17":
            dialog.text = "א Antigua, dans une taverne, mon homme vous attendra. Mot de passe : « La pêche a été bonne. La prise, un vrai régal pour les yeux. »";
            link.l1 = "א bientכt, sir William.";
			link.l1.go = "Accept_Billi_Bons";
		break;
		
		case "Accept_Billi_Bons":
			pchar.BSBonsAccept = true;
			AddQuestRecord("BSUrka", "5");
            SetFunctionExitFromLocationCondition("BS_Billi_Bons", pchar.location, false);
			BS_Billi_Bons_NotEnemy();
			Map_ReleaseQuestEncounter(npchar.id);
			QuestAboardCabinDialogSurrender();			
		break;

		//Расходимся миром. В таверну Антигуа поселить непися за стол. имеется ввиду, что корабль отпускаем после абордажа, он становится зелёным. для особо упоротых, а таких хватает - как в "потрёпанном корабле" сделать его "прозрачным", чтоб не не дамажился и не брался на абордаж 7.04.2023

		//Запись в СЖ если убили Билла: «Ситуация с английскими рейдерами прояснилась. Надо же. Разведка адмиралтейства! Нужно предупредить Флинта. Где-то всё ещё охотится ‘Скарборо’ и с этим, нужно что-то делать. В путь. На Багамы».

		//Запись в СЖ если приняли сторону Билла: «Я принял(ла) косвенно предложение Бонса, то есть Блэкхэма. Но сначала 'Урка'! Такую добычу нельзя упускать. Нужно записать пароль для встречи со связным на Антигуа. «Рыбалка успешной была. Улов – загляденье»»

		//При любом раскладе – рейдеров, на глобалке выключаем.

		//Пиздуем на Багамы. По улицам гуляют Бонни и Рекхэм. Просто гуляют с обычными для нпс диалогами.

		//В доме Флинт, Сильвер, Гатри, Вейн. С нами приходит Макс. Если согласились топить за Англию – про «Скарборо» нет веток.

		case "BS_NU_18":	//Флинт
            dialog.text = "Enfin, tout le monde est là. Qui est la dame qui t'accompagne, "+pchar.name+" ?";
            link.l1 = "Je vous présente Maxine. Euh... Elle tient un bordel à Port Royal.";
			link.l1.go = "BS_NU_18_1";
		break;

		case "BS_NU_18_1":
			DialogExit();
			StartInstantDialogNoType("BS_Vein", "BS_NU_19", "Quest\BlackSails\Neulovimaya_Urka.c");
		break;

		case "BS_NU_19":	//Вейн
            dialog.text = "דa alors, Max ! Tu es montée bien haut ! N'oublie pas que la chute fait mal, très mal !";
            link.l1 = "";
			link.l1.go = "BS_NU_19_1";
		break;

		case "BS_NU_19_1":
			DialogExit();
			sld = CharacterFromID("BS_Maks");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_20";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_20":	//Максин
            dialog.text = "Je m'en souviendrai, merci, Charles. Messieurs, j'ai les informations dont vous avez besoin sur le galion chargé de monnaie, et je propose de vous les vendre contre une part égale du butin.";
            link.l1 = "";
			link.l1.go = "BS_NU_20_1";
		break;
		case "BS_NU_20_1":
			DialogExit();
			sld = CharacterFromID("Gatri_temp");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_21";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_NU_21":	//Гатри
            dialog.text = "Une de tes connaissances, Charlie ? La patronne d'un bordel ? Quelqu'un me chantait des histoires d'amour éternel et de fidélité jusqu'à la tombe, et pendant ce temps, il courait les catins !";
            link.l1 = "";
			link.l1.go = "BS_NU_21_1";
		break;
		case "BS_NU_21_1":
			DialogExit();
			StartInstantDialogNoType("Flint", "BS_NU_21_2", "Quest\BlackSails\Neulovimaya_Urka.c");
		break;
		case "BS_NU_21_2":	//Флинт
            dialog.text = "Les affaires d'abord, Eleanor ! Une part égale, mademoiselle Maxine, implique une participation et des risques égaux. J'espère que vos informations en valent la peine. Exposez-les, et nous examinerons votre place dans notre association.";
            link.l1 = "";
			link.l1.go = "BS_NU_21_3";
		break;
		case "BS_NU_21_3":
			DialogExit();
			sld = CharacterFromID("BS_Maks");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_22";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_NU_22":	//Максин
            dialog.text = "D'après ce que je sais, votre chasse à l'Urca a échoué. Le fait est qu'elle a pris un autre itinéraire, sans passer par La Havane : tout cela n'était qu'une diversion. Et je sais oם le navire est allé !";
            link.l1 = "Incroyable ! Comment le sais-tu ? Par tes employées ?";
			link.l1.go = "BS_NU_23";
		break;
		case "BS_NU_23":
            dialog.text = "L'Urca a reçu l'ordre formel de ne faire escale dans aucun port et de recourir à des capitaines de confiance pour le ravitaillement et le transport des troupes. L'un de ces capitaines a des goמts particuliers, et seul mon établissement peut les satisfaire. Deux ou trois visites, et il en a tant chanté qu'on pourrait le pendre, le fusiller ou l'écarteler au choix, ou tout à la fois.";
            link.l1 = "";
			link.l1.go = "BS_NU_23_1";
		break;
		case "BS_NU_23_1":
			DialogExit();
			StartInstantDialogNoType("BS_Vein", "BS_NU_24", "Quest\BlackSails\Neulovimaya_Urka.c");
		break;
		case "BS_NU_24":	//Вейн
            dialog.text = "Quels goמts, au juste ?";
            link.l1 = "";
			link.l1.go = "BS_NU_24_1";
		break;
		case "BS_NU_24_1":
			DialogExit();
			sld = CharacterFromID("BS_Maks");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_25";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;
		case "BS_NU_25":	//Максин
            dialog.text = "Que cela reste un secret. Donc, l'Urca de Lima va longer la cכte du continent et jeter l'ancre près de la cכte ouest de Curaçao, oם elle attendra une escadre d'escorte venue de La Havane, puis partira de là pour l'Europe, en passant au large de la Barbade et de la Trinité. Ai-je mérité ma part, messieurs ?";
            link.l1 = "";
			link.l1.go = "BS_NU_25_1";
		break;
		case "BS_NU_25_1":
			DialogExit();
			StartInstantDialogNoType("Flint", "BS_NU_26", "Quest\BlackSails\Neulovimaya_Urka.c");
		break;
		case "BS_NU_26":	//Флинт
            dialog.text = "Tout à fait. Mais je vous demanderai de tenir compagnie à Mlle Guthrie, ici, sur l'île. Quant à nous, nous devons préparer les navires et prendre la mer sans tarder ! La cכte ouest de Curaçao est dangereuse, avec ses grains soudains et ses courants imprévisibles, qui pourraient facilement nous entraîner, nous et notre prise, sous les canons de Willemstad. Il faut calculer l'itinéraire avec plus de soin.";
            link.l1 = "";
			link.l1.go = "BS_NU_26_exit";
			AddQuestRecord("BSUrka", "6");
		break;

		case "BS_NU_26_exit":
			DialogExit();
			NextDiag.CurrentNode = "BS_NU_28";
			SetFunctionLocationCondition("BS_BSUrka_NassauFlintDialogue", "Nassau_town", false);
			DoReloadCharacterToLocation("Nassau_Town", "officers", "HouseS1_3");
		break;
		//Запись в СЖ: «Макс дала важную информацию. Испанцы предвидели охоту за галеоном и запутали следы. Но болтливые и похотливые людишки рушат любые планы и вскрывают любые тайны. Заметка себе: «Не болтать в борделях!»»

		//Все сваливают из резиденции. Остаётся ГГ и Флинт.

		case "BS_NU_28":	//Флинт
			pchar.quest.BSUrka_Fail1.win_condition.c1 = "NPC_Death";
			pchar.quest.BSUrka_Fail1.win_condition.c1.character ="Flint";
			PChar.quest.BSUrka_Fail1.function = "BSUrka_Fail";

			pchar.quest.BSUrka_Fail2.win_condition.c1 = "NPC_Death";
			pchar.quest.BSUrka_Fail2.win_condition.c1.character ="BS_Vein";
			PChar.quest.BSUrka_Fail2.function = "BSUrka_Fail";

			SetCompanionIndex(PChar, -1, GetCharacterIndex(npchar.id));//Флинт присоединяется к эскадре
			Flag_Change(PIRATE);
			SetCharacterGoods(npchar, GOOD_FOOD, 1200+rand(500));
			SetCharacterGoods(npchar, GOOD_MEDICAMENT, 1200+rand(500));
			SetCharacterGoods(npchar, GOOD_RUM, 500+rand(250));
			LAi_SetImmortal(npchar, false);

			SetShipRemovable(npchar, false);
			SetCharacterRemovable(npchar, false);
            dialog.text = "";
            link.l1 = "Un dernier effort ?";
			if (CheckAttribute(pchar, "BSBonsAccept"))
			{
				link.l1.go = "BS_NU_29_Ya_Shpion";
			}
			else
			{
				link.l1.go = "BS_NU_29_Ya_Ne_Krisa";
			}
		break;

		//Если мы остались верны Флинту, то следующий диалог:

		case "BS_NU_29_Ya_Ne_Krisa":
            dialog.text = "Je crains que ce ne soit pas le dernier.";
			if(CheckAttribute(pchar, "BSBonsKilled"))
			{
				link.l1 = "J'ai rencontré ton second au large de la Jamaïque. Le commandant William Blackham. Bones. Billy Bones.";
				link.l1.go = "BS_NU_30_Ya_Ne_Krisa";
			}
			else
			{
				link.l1 = "Nous avons traversé beaucoup de choses ensemble. Tu peux compter sur moi, quoi qu'il arrive.";
				link.l1.go = "BS_NU_32_Ya_Ne_Krisa";
			}
		break;

		case "BS_NU_30_Ya_Ne_Krisa":
            dialog.text = "Commandant ? Hum... Je le soupçonnais d'être un espion, mais à la solde de Jackman. Mais l'Amirauté...";
            link.l1 = "Ils veulent ta tête pour le meurtre de Lord Hamilton, et cætera, et cætera. Il m'a promis monts et merveilles.";
			link.l1.go = "BS_NU_31_Ya_Ne_Krisa";
		break;

		case "BS_NU_31_Ya_Ne_Krisa":
            dialog.text = "Mais tu ne l'as pas écouté ? Pourquoi ?";
            link.l1 = "Cent cinquante millions de raisons sonnantes et trébuchantes, nom d'un chien ! Et je ne vends pas mes amis.";
			link.l1.go = "BS_NU_32_Ya_Ne_Krisa";
		break;

		case "BS_NU_32_Ya_Ne_Krisa":
            dialog.text = "Tu me fais honneur en m'offrant ton amitié. Je l'accepte avec joie. Voici ma main.";
            link.l1 = "Et voici la mienne. Bon ? Il est temps de voir ce que devient l'insaisissable Urca !";
			link.l1.go = "BS_NU_32_exit";
		break;

		case "BS_NU_32_exit":
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			ChangeCharacterAddressGroup(sld, "Nassau_town", "reload", "houseS1");
			sld.dialog.currentnode = "BS_NU_33_Ya_Ne_Krisa";
			LAi_SetStayTypeNoGroup(sld);
			sld.talker = 10;
		break;

		//Если мы предаём Флинта, то следующий диалог: //для второй финалки 7.04.2023

		case "BS_NU_29_Ya_Shpion":
            dialog.text = "Je crains que ce ne soit pas le dernier.";
            link.l1 = "...";
			link.l1.go = "BS_NU_30_Ya_Shpion_exit";
		break;
		
		case "BS_NU_30_Ya_Shpion_exit":
            LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "none", "", "", "", -1);
			DialogExit();
			sld = CharacterFromID("BS_Vein");
			ChangeCharacterAddressGroup(sld, "Nassau_town", "reload", "houseS1");
			sld.dialog.currentnode = "BS_NU_33_Ya_Shpion";
			LAi_SetStayTypeNoGroup(sld);
			sld.talker = 10;
		break;

		//Ставим Моржа и Вейна на ТФ «Рейнджер» в эскадру. На выходе из резиденции говорим с Вейном.

		//Если мы остались верны Флинту, то следующий диалог:

		case "BS_NU_33_Ya_Ne_Krisa":
            dialog.text = "De quoi avez-vous parlé, Flint et toi ?";
            link.l1 = "Nous avons préparé l'expédition. J'ai entendu parler de ton combat contre les Espagnols ! Et je vois que tu as un nouveau navire. Il fallait le faire ! Comment as-tu même survécu ?";
			link.l1.go = "BS_NU_34_Ya_Ne_Krisa";
		break;

		case "BS_NU_34_Ya_Ne_Krisa":
            dialog.text = "J'ai une sacrée veine, je n'ai pas d'autre explication moi-même.";
            link.l1 = "Si seulement j'avais une goutte de ta chance. Bon, il est temps de se mettre en route.";
			link.l1.go = "BS_NU_34_exit";
		break;

		//Если мы предаём Флинта, то следующий диалог:

		case "BS_NU_33_Ya_Shpion":
            dialog.text = "De quoi avez-vous parlé, Flint et toi ?";
            link.l1 = "Il y a quelque chose dont nous devons parler. Mais ce sera après l'Urca.";
			link.l1.go = "BS_NU_34_Ya_Shpion";
		break;

		case "BS_NU_34_Ya_Shpion":
			
            dialog.text = "Comme tu voudras. En route.";
            link.l1 = "";
			link.l1.go = "BS_NU_34_exit";
		break;

		case "BS_NU_34_exit":
			chrDisableReloadToLocation = false;
			FantomMakeCoolestSailor(npchar, SHIP_DIANA, "Ranger", CANNON_TYPE_CANNON_LBS32, 100, 100, 100);
			SetCompanionIndex(PChar, -1, GetCharacterIndex(npchar.id));//вейн присоединяется к эскадре
			BSRepairShip(npchar);
			SetCharacterGoods(npchar, GOOD_FOOD, 1200+rand(500));
			SetCharacterGoods(npchar, GOOD_MEDICAMENT, 1200+rand(500));
			SetCharacterGoods(npchar, GOOD_RUM, 500+rand(250));
			SetShipRemovable(npchar, false);
			SetCharacterRemovable(npchar, false);
			LAi_SetImmortal(npchar, false);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "reload1_back", "", "", "", "", -1);
			BSUrka_Curacao_SeaBattle();
            pchar.quest.BSUrka_Curacao_SeaBattle.win_condition.l1 = "EnterToSea";
			pchar.quest.BSUrka_Curacao_SeaBattle.function    = "BSUrka_Curacao_SeaBattle";
			DialogExit();
		break;

		//Выходим в море, чешем до Кюрасао. С западной стороны выходим на локалку. Сюрпрайз. Урки нету! Зато есть 6-8 испанских фрегатов и линейников. Адовое мочилово. После боя, ТП на палубу Флинта.

		case "BS_NU_35":
            dialog.text = "";
            link.l1 = "Presque tout concorde, mais oם est l'Urca ?";
			link.l1.go = "BS_NU_36";
		break;

		case "BS_NU_36":
			chrDisableReloadToLocation = false;
			DeleteAttribute(pchar, "LockShoreReload");
            dialog.text = "Du calme, nous avons repêché quelques Espagnols, on les interroge en ce moment. Nous allons mouiller en rade du cap des Calvinistes. Nous parlerons à terre.";
            link.l1 = "";
			link.l1.go = "exit";
			pchar.LockMapReload = "D'abord, nous devons interroger les Espagnols capturés au cap des Calvinistes.";
			pchar.quest.BSUrka_Curacao_Shore.win_condition.l1          = "location";
			pchar.quest.BSUrka_Curacao_Shore.win_condition.l1.location = "Shore23";
			pchar.quest.BSUrka_Curacao_Shore.function             = "BSUrka_Curacao_Shore";
		break;

		//Доплываем до мыса Кальвинистов, выходим на берег. На берегу испанский офицер, Флинт, Вейн, Бонни.

		case "BS_NU_37":	//Флинт
            DeleteAttribute(pchar, "LockMapReload");
			dialog.text = "Nous sommes à Curaçao ; vous serez libérés sans qu'on vous fasse de mal si nous obtenons les informations qui nous intéressent. Sinon, vous connaissez ma réputation ! Et ne tardez pas à vous décider.";
            link.l1 = "";
			link.l1.go = "BS_NU_381";
		break;

		case "BS_NU_381":
			DialogExit();
			sld = CharacterFromID("BSUrka_Prisoner");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_38";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_38":	//Испанский офицер
			sld = CharacterFromId("Flint");
			LAi_SetActorTypeNoGroup(sld);
			LAi_ActorTurnToCharacter(sld, npchar);
            dialog.text = "Maudits cabrones ! L'enfer vous attend tous ! Mais j'accepte vos conditions ! Le navire qui vous intéresse a été emporté par un grain en direction du continent. Il a été malmené par la tempête et sera réparé dans l'une des baies. C'est tout ce que je peux vous dire.";
            link.l1 = "";
			link.l1.go = "BS_NU_391";
		break;

		case "BS_NU_391":
			DialogExit();
			sld = CharacterFromID("Flint");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_39";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_39":	//Флинт
            dialog.text = "Merci, vous pouvez partir.";
            link.l1 = "";
			link.l1.go = "BS_NU_401";
		break;

		case "BS_NU_401":
			DialogExit();
			sld = CharacterFromID("BS_Bony");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_40";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_40":	//Бонни убивает испанца
            dialog.text = "Partir ? Pas question, bon sang !";
            link.l1 = "";
			link.l1.go = "exit";
			DoQuestFunctionDelay("BSUrka_BonyHits", 0.3);
		break;

		case "BS_NU_41":	//Вейн
            dialog.text = "Qu'est-ce qui te prend, Anne ? Tu as perdu la tête ?";
            link.l1 = "";
			link.l1.go = "BS_NU_421";
		break;

		case "BS_NU_421":
			DialogExit();
			sld = CharacterFromID("BS_Bony");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_42";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_42":	//Бонни
            dialog.text = "Les recherches traînaient en longueur, et il y a déjà eu trop de surprises pour qu'on relâche ce prisonnier, qui nous amènerait une nouvelle escadre sur le dos !";
            link.l1 = "";
			link.l1.go = "BS_NU_431";
		break;

		case "BS_NU_431":
			DialogExit();
			sld = CharacterFromID("Flint");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";
			sld.dialog.currentnode   = "BS_NU_43";
			pchar.InstantDialog = sld.id;
			DoQuestFunctionDelay("InstantDialog", 0);
		break;

		case "BS_NU_43":	//Флинт
            dialog.text = "Monsieur Vane, surveillez vos subordonnés ! C'est la dernière frasque que je tolérerai.";
            link.l1 = "";
			link.l1.go = "BS_NU_44";
		break;

		case "BS_NU_44":	//Флинт
			sld = CharacterFromID("BS_Bony");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
			sld = CharacterFromID("BS_Vein");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
            dialog.text = "Anne, dans la chaloupe ! Pas un mot ! Nous parlerons plus tard.";
            link.l1 = "Il est temps de fouiller un paquet de criques. Au travail !";
			link.l1.go = "BS_NU_44_exit";
		break;

		case "BS_NU_44_exit":
			AddQuestRecord("BSUrka", "7");
			DialogExit();
			sld = CharacterFromID("Flint");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
			chrDisableReloadToLocation = false;
			BSUrka_PlaceUrka();
			pchar.quest.BSUrka_Found.win_condition.l1          = "location";
			pchar.quest.BSUrka_Found.win_condition.l1.location = "Cumana";
			pchar.quest.BSUrka_Found.function             = "BSUrka_Found";
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_4_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
		break;

		//Запись в СЖ: «Охота затянулась, и нервы начинают сдавать. Нужно разобраться с этим поскорее, пока мы не передрались»

		//Выходим в море. Ищем по бухтам Мурку. Мурка в Лос Текос. В бухте ставим раздолбаный имперский галеон под названием «Урка де Лима». Взаимодействовать с ней нельзя. Она просто декорация. На рейде – испанский мановар. Файт.

		//После потопления самовара, запись в СЖ: «Наконец то! Вот она 'Урка'. Её сильно потрепало штормом и команды не видно на борту. Высаживаемся на берег!»

		//На берегу – адский файт. Испанцев лучше пускать волнами, чтоб не лагало всё к херам штук по 30 и так пять раз. Флинта, Вейна, Сильвера – лучше сделать либо бессмертными, либо очень толстыми на момент файта.

		//После победы запись в СЖ: «Дело сделано, столько крови я никогда не проливал(ла) за один раз. Нет сил, даже говорить. Грузим сундуки на корабли и отчаливаем, пока на шум не налетела береговая охрана».

		//Ставим табличку «Прошло 3 часа, сундуки погружены на корабли»

		//Подходит Флинт

		case "BS_NU_45":	//Флинт
            dialog.text = "C'est fait ; nous ferons le partage aux Bahamas. Il est temps de partir.";
            link.l1 = "";
			link.l1.go = "BS_NU_45_exit";
		break;

		case "BS_NU_45_exit":
			RemoveCharacterCompanion(PChar, npchar);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", -1);
			DialogExit();
			
			PChar.quest.BSUrka_Nassau_Ending.win_condition.l1 = "location";
			PChar.quest.BSUrka_Nassau_Ending.win_condition.l1.location = "Nassau_OfisGatri";
			PChar.quest.BSUrka_Nassau_Ending.function = "BSUrka_Nassau_Ending";
			PChar.quest.BSUrka_Pirates_town_residence.win_condition.l1 = "locator";
			PChar.quest.BSUrka_Pirates_town_residence.win_condition.l1.location = "Nassau_town";
			PChar.quest.BSUrka_Pirates_town_residence.win_condition.l1.locator_group = "reload";
			PChar.quest.BSUrka_Pirates_town_residence.win_condition.l1.locator = "houseS1";
			PChar.quest.BSUrka_Pirates_town_residence.function = "BSUrka_Pirates_town_residence";

			sld = CharacterFromID("BS_Bony");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
			sld = CharacterFromID("BS_Silver");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);
			sld = CharacterFromID("BS_Rakham");
			LAi_SetActorType(sld);
			LAi_ActorGoToLocation(sld, "reload", "sea", "none", "", "", "", -1);

			sld = CharacterFromID("BS_Vein");
			sld.dialog.filename = "Quest\BlackSails\Neulovimaya_Urka.c";				
			if (CheckAttribute(pchar, "BSBonsAccept"))
			{
				sld.dialog.currentnode = "BS_NU_46_Ya_Shpion";
			}
			else
			{
				sld.dialog.currentnode = "BS_NU_46_Ya_Ne_Krisa";	
			}
			LAi_SetActorType(sld);
			LAi_ActorDialog(sld, pchar, "", -1, 0);
		break;

		//Флинт уходит на корабль. Остаётся Вейн.

		//Если мы остались верны Флинту, то следующий диалог:

		case "BS_NU_46_Ya_Ne_Krisa":	//Вейн
			RemoveCharacterCompanion(PChar, npchar);
			dialog.text = "J'avais presque cessé de croire que ce galion existait. Tu te bats bien. Viens me trouver après tout ça, nous pourrons peut-être faire quelques affaires ensemble !";
            link.l1 = "Je ne suis pas près de repartir pour un nouveau coup ! Tu me comprends, mais merci pour la proposition ! Toi aussi, tu es un sacré corsaire !";
			link.l1.go = "BS_NU_47_Ya_Ne_Krisa";
		break;

		case "BS_NU_47_Ya_Ne_Krisa":
            dialog.text = "Je suis un pirate. On ne m'attire pas avec une lettre de marque. Je n'aime pas les uniformes.";
            link.l1 = "Il est temps de partir pour les Bahamas. Allons-y.";
			link.l1.go = "BS_NU_47_Ya_Ne_Krisaexit";
		break;

		case "BS_NU_47_Ya_Ne_Krisaexit":
			chrDisableReloadToLocation = false;
			RemoveCharacterCompanion(PChar, npchar);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", -1);
			DialogExit();
			AddQuestRecord("BSUrka", "9");
			pchar.BSBonsSpawned = true;
			BSBons_SeaBattle(true);
			if (WhisperIsHere())
			{
				SaveOldDialog(CharacterFromID(pchar.WhisperPGG));
				StartInstantDialogNoType(pchar.WhisperPGG, "BS_5_WhisperIsHere", "Quest\WhisperLine\Whisper.c");
			}
			PChar.quest.BSChaseBegun_Fail.over = "yes";
			PChar.quest.BSUrka_Fail1.over = "yes";
			PChar.quest.BSUrka_Fail2.over = "yes";
			PChar.quest.BSUrka_Curacao_EndSeaBattle.over = "yes";
			PChar.quest.BSUrka_SeaBattleEnded.over = "yes";
		break;

		//Если мы предаём Флинта, то следующий диалог://финалка номер два ! 7.04.2023

		case "BS_NU_46_Ya_Shpion":	//Вейн
            dialog.text = "Tu voulais me parler de quelque chose ? Avant l'effort final.";
            link.l1 = "Oui, il y a quelque chose. Au large de la Jamaïque, j'ai croisé Billy Bones, qui n'est pas Bones du tout, mais un officier du renseignement naval britannique. Ne m'interromps pas ! Ils veulent la tête de Flint, en échange de la bienveillance des autorités coloniales et d'une récompense. Quatre cent mille livres en argent. En monnaie locale, ça fait deux millions et demi chacun, si tu en es. Qu'est-ce que tu en dis ?";
			link.l1.go = "BS_NU_47_Ya_Shpion";
		break;

		case "BS_NU_47_Ya_Shpion":
            dialog.text = "Un morceau de tous ces millions espagnols et une récompense de la Couronne britannique ? En échange de la tête de ce fils de pute arrogant ? Comment comptes-tu t'y prendre ?";
            link.l1 = "Si nous l'attaquons en mer maintenant, nos propres équipages nous hacheront menu. Flint est un demi-dieu pour eux en ce moment ! Au retour, après le partage, quand tout le monde sera ivre, nous le coincerons. Vivant, on pourra encore en tirer un peu d'argent.";
			link.l1.go = "BS_NU_48_Ya_Shpion";
		break;

		case "BS_NU_48_Ya_Shpion":
            dialog.text = "J'en suis, même si cette affaire pue la merde ; mais voir son regard quand il comprendra qu'il s'est fait avoir, ça vaut le coup !";
            link.l1 = "Alors cette nuit, après le partage. Bon, on nous observe. Allons-y.";
			link.l1.go = "BS_NU_48_Ya_Shpionexit";
		break;
		
		case "BS_NU_48_Ya_Shpionexit":
			chrDisableReloadToLocation = false;
			RemoveCharacterCompanion(PChar, npchar);
			LAi_SetActorType(npchar);
			LAi_ActorGoToLocation(npchar, "reload", "sea", "none", "", "", "", -1);
			DialogExit();
			AddQuestRecord("BSUrka", "10");
			PChar.quest.BSChaseBegun_Fail.over = "yes";
			PChar.quest.BSUrka_Fail1.over = "yes";
			PChar.quest.BSUrka_Fail2.over = "yes";
			PChar.quest.BSUrka_Curacao_EndSeaBattle.over = "yes";
			PChar.quest.BSUrka_SeaBattleEnded.over = "yes";
		break;

		//Если мы остались верны Флинту, то следующая запись в СЖ: «Осталось самое интересное – делёжка добычи! Пора отправляться на Бермуды»

		//Если мы предаём Флинта, то следующая запись в СЖ: «Вейн в деле, делим добычу и ловим Флинта. Надо постараться оставить его в живых. Пора на Багамы»

		//Если решили не продавать Флинтушку – на глобалке догоняет фиолетовая энка. «Скарборо» линейник первого ранг. С ним пара фрегатов. Никаких диалогов, просто замес в море. По окончанию – запись в СЖ «Скарборо» на дне. Остался только Джекман»

		//Если решили продать, англичан нету, спокойно идём до бермуд.// это важно! Скарборо будет в другом месте 7.04.2023

		//В обоих вариантах – при выходе на локалку Бермуд – атакует эскадра Джекмена. Джекмен на «Нептуне». Бах-бах. Абордируем «Нептуна» файт с Джекменом. Диалог

		//Селим Гатри и Макс в резиденцию, в магаз – рандомного челика.

		//Высаживаемся, идём в резиденцию. ГГ, Флинт, Вейн, Гатри, Макс

		case "BS_NU_50":	//Флинт
            dialog.text = "C'est fait : on décharge l'or des navires dans l'entrepכt de Mlle Guthrie, et nous le compterons et le partagerons dès que ce sera terminé. En attendant, je propose de boire à la réussite de notre affaire ! Vous êtes le meilleur équipage avec lequel j'aie jamais traité. א votre santé ! Cul sec !";
            link.l1 = "Cul sec !";
			link.l1.go = "BS_NU_50exit";
		break;

		case "BS_NU_50exit":	//Флинт
			DialogExit();
			BSUrka_Poison();
		break;

		//Типа пьём и валимся с ног все, кроме Флинта, Флинт уходит из резиденции. Нас отравили.

	}
}
