// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "On va encore poser des questions ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(PChar.MysteriousIsland == "2" && Characters[GetCharacterIndex("Jimm Smith")].location == PChar.location)
			{
				link.l1 = "וcoute, l'ami, tu pourrais me dire quelque chose sur ce marin avec qui j'étais assis récemment ?";
				link.l1.go = "MysteriousIsland_1";
			}
		break;
		
		// Загадочный Остров -->
		case "MysteriousIsland_1":
			dialog.text = "Oh, vous parlez de Jim Smith ! Que voulez-vous que je vous dise, " + GetAddress_Form(NPChar) + ". Il boit comme un trou tous les jours, et quand il est soמl à mort, il répète qu'il va bientכt partir d'ici pour l'église de Charlestown. C'est la même chose tous les jours !";
			if(sti(PChar.money) >= 500)
			{
				AddMoneytoCharacter(PChar, -500);
				link.l1 = "Merci, " + npchar.name + ", prends ces 500 pièces : les gens aussi désintéressés que toi sont bien rares de nos jours.";
				link.l1.go = "exit";			
			}
			else
			{
				link.l1 = "Merci, " + npchar.name + ".";
				link.l1.go = "exit";
			}
			AddDialogExitQuestFunction("MysteriousIslandToCharlesChurch");
		break;
		// Загадочный Остров <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

