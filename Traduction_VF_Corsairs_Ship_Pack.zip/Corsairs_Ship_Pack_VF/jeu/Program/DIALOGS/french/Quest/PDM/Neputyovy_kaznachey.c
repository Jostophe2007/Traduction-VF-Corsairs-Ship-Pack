
void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;
	string sBlade;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar,CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	int Plata1 = 14000 * MOD_SKILL_ENEMY_RATE*3 * 0.21;
	int Plata2 = 14000 * MOD_SKILL_ENEMY_RATE*3 * 0.31;

	pchar.PDM_NK_Plata2.Money = 14000 * MOD_SKILL_ENEMY_RATE*3 * 0.31;

	int Sila = 25 + MOD_SKILL_ENEMY_RATE*3 * 2.8;
	int DopHP = 40 + MOD_SKILL_ENEMY_RATE*3 * 10;
	int Rank = sti(pchar.rank) - 5 + MOD_SKILL_ENEMY_RATE*3 * 1.2;
	if (Rank < 1) Rank = 1;

	switch(Dialog.CurrentNode)
	{
		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "First time":							//Автор Sinistra
			dialog.text = "Q-qui êtes-vous ?";
			link.l1 = "Capitaine "+pchar.name+". Et vous ?";
			link.l1.go = "Fickler_1";
			PlayVoice("Kopcapkz\Voices\PDM\Andreas Fickler.wav");
			DeleteAttribute(npchar, "talker");
			UnmarkCharacter(npchar);
		break;

		case "Fickler_1":
			dialog.text = "A-a-andreas Fickler, à v-votre service.";
			link.l1 = "Pourquoi tu trembles comme ça, l'ami ?";
			link.l1.go = "Fickler_2";
		break;

		case "Fickler_2":
			dialog.text = "V-v-vous t-t-trembleriez aussi si q-quelqu'un voulait vous tuer !";
			link.l1 = "Quelqu'un veut te tuer ?";
			link.l1.go = "Fickler_3";
		break;

		case "Fickler_3":
			dialog.text = "Oui, "+ GetSexPhrase("mynheer", "mevrouw") +". Je n'arrive pas à dormir. Je suis complètement brisé. Et tout ça à cause de cette maudite poudre !";
			link.l1 = "דa a l'air d'être une drכle d'histoire. Vide ton sac, l'ami.";
			link.l1.go = "Fickler_4";
		break;

		case "Fickler_4":
			dialog.text = "Bon, je-je crois que je peux vous faire confiance. Je suis le trésorier... J'étais le trésorier de la caravelle Sea Gull. Notre c-c-capitaine a acheté trop de poudre, alors que je lui avais conseillé de ne pas le faire ! J'ai dמ entreposer des barils à des endroits qui ne convenaient pas. Sur la dunette, par exemple. Et l'un de nos marins sans cervelle s'est soמlé jusqu'à en perdre la raison. Je leur avais dit de ne pas fumer sur la dunette, mais cet abruti d'ivrogne s'est assis en plein sur un baril de poudre et... et...";
			link.l1 = "Il a allumé sa pipe ?";
			link.l1.go = "Fickler_5";
		break;

		case "Fickler_5":
			dialog.text = "Oui... Et puis il l'a laissée tomber... Et il est parti tout droit en enfer. Avec la dunette, la barre et la moitié du navire. Les m-m-matelots ont éteint le feu, mais toute la cargaison était déjà perdue. Et le c-capitaine a dit que je ne verrais pas l'aube ! Il est à la taverne en ce moment, à noyer sa colère dans le rhum. Mais j'ai peur qu'il ne s'arrête pas à boire. Et ensuite, il sortira son c-coutelas et me tuera ici même, sur la place !";
			link.l1 = "Une histoire vraiment drכle. Ne t'inquiète pas, Andreas. Je vais t'aider.";
			link.l1.go = "Fickler_6";
			link.l2 = "Bon, fais attention avec la poudre à l'avenir. Allez, profite bien des quelques heures qui te restent. Adieu.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Fickler_8";
		break;

		case "Fickler_6":
			dialog.text = "C-c-comment ?";
			link.l1 = "Je ne sais pas. Je trouverai quelque chose. Attends-moi ici.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Fickler_7";

			if (MOD_SKILL_ENEMY_RATE == 3 && bHardAnimations) sld = GetCharacter(NPC_GenerateCharacter("PDM_NK_Viktor", "officer_15", "man", "man_fast", 10, PIRATE, -1, false));
			else sld = GetCharacter(NPC_GenerateCharacter("PDM_NK_Viktor", "officer_15", "man", "man", 10, PIRATE, -1, false));
			sld.name = "Victor";
			sld.lastname = "Bretier";
			FreeSitLocator("Villemstad_tavern", "sit12");
			sld.city = "Villemstad";
			sld.location	= "Villemstad_tavern";
			if (bHardBoss) sld.AlwaysReload = true;//перезарядка независимо от Дозарядки
			sld.location.group = "sit";
			sld.location.locator = "sit12";
			LAi_SetSitType(sld);
			sld.dialog.filename   = "Quest\PDM\Neputyovy_kaznachey.c";
			sld.dialog.currentnode   = "Viktor";

			SetQuestHeader("PDM_Neputyovy_kaznachey");
			AddQuestRecord("PDM_Neputyovy_kaznachey", "1");
		break;

		case "Fickler_7":
			PlayVoice("Kopcapkz\Voices\PDM\Andreas Fickler.wav");
			dialog.text = "Capitaine Victor ! Oh, c'est vous, oui... Vous m'avez fait une peur bleue. Vous avez vu V-v-victor ?");
			link.l1 = "Pas encore. Mais ne t'inquiète pas, je m'occupe de lui.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Fickler_7";
		break;

		case "Fickler_8":
			PlayVoice("Kopcapkz\Voices\PDM\Andreas Fickler.wav");
			dialog.text = "Ah ! Attendez ! Ne m'approchez pas ! Ah... c'est vous. Bon, il va bientכt me trouver...";
			link.l1 = "Ne t'inquiète pas, Andreas. Je m'occupe de lui.";
			link.l1.go = "Fickler_6";
			link.l2 = "Bon, profite bien des quelques heures qui te restent. Adieu.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Fickler_8";
		break;

		case "Viktor":
			PlayVoice("Kopcapkz\Voices\PDM\Gavrila Dubinin.wav");
			dialog.text = "Toi ! Hé, toi ! Tu n'as pas vu par ici un trésorier à lunettes sans cervelle du nom d'Andreas ? C'est à cause de lui que je suis ruiné ! Un parasite ! Je vais le tuer ! Il m'a ruiné !";
			link.l1 = "Tiens, tiens, tiens. Tu es Victor Bretier.";
			link.l1.go = "Viktor_2";
		break;

		case "Viktor_2":
			dialog.text = "Oui, je suis Victor. Et ce chien puant a fait brמler la moitié de mon navire avec ces maudits barils de poudre ! Je vais l'écorcher vif !";
			link.l1 = "Calme-toi, l'ami. Andreas est sous ma protection.";
			link.l1.go = "Viktor_3";
		break;

		case "Viktor_3":
			dialog.text = "Quoi ? Sous ta protection ? Mais qui es-tu, toi ?!";
			link.l1 = "Je me présente : capitaine "+pchar.name+". Et si tu touches ne serait-ce qu'un cheveu de sa tête, je brמlerai l'autre moitié de ton navire.";
			link.l1.go = "Viktor_4";
		break;

		case "Viktor_4":
			dialog.text = "Maudit pirate ! Pour qui te prends-tu ? Y a-t-il une justice en ce monde contre ces pirates effrontés ? Ils oppriment les honnêtes capitaines, en mer comme sur terre ! Oם est la justice ?";
			link.l1 = "Tu menaces de tuer ton trésorier, et tu parles de justice ? Je ne pense pas que le gouverneur prendra à la légère le meurtre d'un innocent sur ses terres.";
			link.l1.go = "Viktor_5";
		break;

		case "Viktor_5":
			dialog.text = "Innocent ? J'ai perdu ma cargaison à cause de cet idiot ! " + Plata1 + " pièces d'or ! Si ce n'est plus ! Je trouverai oם il se cache !";
			link.l1 = "Je préfère te hacher menu plutכt que de laisser Andreas passer un mauvais quart d'heure.";
			link.l1.go = "Viktor_Bitva";
			if (sti(pchar.Money) >= Plata2)
			{
				link.l2 = "" + Plata1 + " pièces d'or ? Et c'est pour ça que tu fais tant d'histoires ? Tiens. Je couvre tes pertes, maintenant, laisse Andreas tranquille.";
				link.l2.go = "Zaplati_ED";
			}
			else
			{
				link.l2 = "" + Plata1 + " pièces d'or ? Ce n'est pas une bien grosse cargaison.";
				link.l2.go = "Zaplati_ED";
			}
			link.l3 = "דa alors ! Et tu sais quoi, cherche ton Andreas oם tu veux, je ne te dérangerai pas.";
			link.l3.go = "Konec";
			NextDiag.TempNode = "Viktor_VernulsyDengi";
		break;

		case "Zaplati_ED":
			dialog.text = "J'ai dit " + Plata1 + " ? Non, je me suis trompé ! Au moins " + Plata2 + " !";
			link.l1 = "Eh bien, tu ne manques pas d'aplomb, Victor ! Je préfère te hacher menu plutכt que de laisser Andreas passer un mauvais quart d'heure.";
			link.l1.go = "Viktor_Bitva";
			if (sti(pchar.Money) >= Plata2)
			{
				link.l2 = "Tiens, prends ton argent. Bon vent, Victor.";
				link.l2.go = "Zaplati_2";
			}
			else
			{
				link.l2 = "Je t'apporterai " + Plata2 + " pièces d'or. Mais souviens-toi : une seule bordée de mon navire transformera ton rafiot en passoire, alors ne touche pas Andreas du bout du doigt !";
				link.l2.go = "exit";
			}
			NextDiag.TempNode = "Viktor_VernulsyDengi";
			AddQuestRecord("PDM_Neputyovy_kaznachey", "2");
			AddQuestUserData("PDM_Neputyovy_kaznachey", "sMoney", FindRussianMoneyString(sti(pchar.PDM_NK_Plata2.Money)));
		break;
		
		case "Konec":
			DialogExit();
			
			sld = CharacterFromID("PDM_NK_Viktor");
			sld.lifeday = 0;
			sld.dialog.filename   = "Quest\PDM\Neputyovy_kaznachey.c";
			sld.dialog.currentnode   = "Viktor_Poka";
			
			sld = CharacterFromID("Andreas_Fickler");
			sld.lifeday = 0;
			
			AddQuestRecord("PDM_Neputyovy_kaznachey", "7");
			AddQuestUserData("PDM_Neputyovy_kaznachey", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Neputyovy_kaznachey");
			pchar.questdata.NeputyovyKaznachey = 1;
		break;
		
		case "Zaplati_ND":
			dialog.text = "";
			link.l1 = "Eh bien, tu ne manques pas d'aplomb, Victor ! Je préfère te hacher menu plutכt que de laisser Andreas passer un mauvais quart d'heure.";
			link.l1.go = "Viktor_Bitva";
			link.l2 = "D'accord, dès que j'aurai l'argent, je viendrai te trouver.";
			link.l2.go = "exit";
			NextDiag.TempNode = "Zaplati_ND";
		break;

		case "Zaplati_2":
			AddMoneyToCharacter(pchar, -sti(Plata2));
			AddCharacterExpToSkill(pchar, "Leadership", 150);
			AddCharacterExpToSkill(pchar, "Commerce", 220);
			AddCharacterExpToSkill(pchar, "Sneak", 150);
			sld = CharacterFromID("PDM_NK_Viktor");
			sld.dialog.filename   = "Quest\PDM\Neputyovy_kaznachey.c";
			sld.dialog.currentnode   = "Viktor_Poka";
			sld.lifeday = 0;
			sld = CharacterFromID("Andreas_Fickler");
			sld.dialog.filename   = "Quest\PDM\Neputyovy_kaznachey.c";
			sld.dialog.currentnode   = "Fickler_11";
			AddQuestRecord("PDM_Neputyovy_kaznachey", "3");
			AddQuestUserData("PDM_Neputyovy_kaznachey", "sSex", GetSexPhrase("", "e"));
			DialogExit();
		break;

		case "Viktor_Poka":
			PlayVoice("Kopcapkz\Voices\PDM\Gavrila Dubinin.wav");
			dialog.text = "Que ta rate éclate ! Qu'est-ce qu'il te faut encore ?";
			link.l1 = "Rien. Adieu.";
			link.l1.go = "exit";
			NextDiag.TempNode = "Viktor_Poka";
		break;

		case "Viktor_VernulsyDengi":
			PlayVoice("Kopcapkz\Voices\PDM\Gavrila Dubinin.wav");
			dialog.text = "Encore toi ? Qu'est-ce qu'il te faut ?";
			link.l1 = "Je veux juste payer pour ton ancien trésorier, Andreas.";
			link.l1.go = "Viktor_VernulsyDengi_2";
		break;

		case "Viktor_VernulsyDengi_2":
			dialog.text = "Tu as apporté l'argent ?";
			if (sti(pchar.Money) >= Plata2)
			{
				link.l1 = "" + Plata2 + " pièces d'or. Voilà.";
				link.l1.go = "Zaplati_2";
			}
			else
			{
				link.l1 = "Je n'ai pas assez d'argent pour l'instant, Victor, mais je reviendrai plus tard payer pour Andreas.";
				link.l1.go = "exit";
			}
			link.l2 = "J'en ai assez de me faire balader dans tout l'archipel à cause de ta stupide cargaison. Tu aurais pu te bouger les fesses cent fois pour gagner ton argent toi-même, vieux schnock !";
			link.l2.go = "Konec";
			NextDiag.TempNode = "Viktor_VernulsyDengi";
		break;

		case "Viktor_Bitva":
			dialog.text = "Tu vas regretter ces paroles, crétin !";
			link.l1 = "Moins de mots, et passons aux actes !";
			link.l1.go = "fight_right_now";
			sld = CharacterFromID("PDM_NK_Viktor");
			if (MOD_SKILL_ENEMY_RATE <= 2)
			{
				FantomMakeCoolFighter(sld, Rank, Sila, Sila, "blade34", "Pistol1", DopHP);
			}
			else
			{
				FantomMakeCoolFighter(sld, Rank, Sila, Sila, "blade34", "Pistol2", DopHP);
			}
			sld.SaveItemsForDead = true;
			sld.DontChangeBlade = true;
			sld.DontChangeGun = true;
			AddMoneyToCharacter(sld, 15000);
			GiveItem2Character(sld, "Litsenzia");
			GiveItem2Character(sld, "mineral9");
			AddItems(sld, "jewelry1", rand(7)+2);
			AddItems(sld, "jewelry3", rand(7)+2);
			AddItems(sld, "jewelry6", 1);

			PChar.quest.PDM_NK_Viktor.win_condition.l1 = "NPC_Death";
			PChar.quest.PDM_NK_Viktor.win_condition.l1.character = "PDM_NK_Viktor";
			PChar.quest.PDM_NK_Viktor.win_condition = "PDM_NK_Viktor";

			PChar.quest.PDM_NK_Litsenzia.win_condition.l1 = "item";
			PChar.quest.PDM_NK_Litsenzia.win_condition.l1.item = "Litsenzia";
			PChar.quest.PDM_NK_Litsenzia.win_condition = "PDM_NK_Litsenzia";
		break;

		case "fight_right_now":
			PChar.questTemp.duel.enemy = NPChar.id;
			AddDialogExitQuestFunction("Duel_Prepare_Fight");
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;

		case "Fickler_11":
			PlayVoice("Kopcapkz\Voices\PDM\Andreas Fickler.wav");
			dialog.text = "C-c-capitaine "+pchar.name+" ! Oh, c'est vous, "+ GetSexPhrase("mynheer", "mevrouw") +" ! Vous m'avez fait peur. Vous avez déjà parlé à V-victor ?");
			link.l1 = "Oui. Il ne te touchera plus. Tu peux retourner sans crainte sur ta Sea Gull.";
			link.l1.go = "Fickler_12";
		break;

		case "Fickler_12":
			dialog.text = "Merci ! M-mille fois m-m-merci ! V-vous m'avez sauvé la vie ! Mais je ne peux pas retourner sur mon navire. Je serais la risée de l'équipage. Et ce, alors que je suis un bon t-trésorier avec dix ans d'expérience. Je n'ai aucune envie de retourner sur la Sea Gull. Euh... Vous auriez peut-être besoin d'un t-t-trésorier, capitaine ?");
			link.l1 = "Je pense que ça pourrait être utile. Tu es engagé. Mais ne t'avise pas d'approcher de la sainte-barbe !";
			link.l1.go = "Fickler_13";
			link.l2 = "Pardon, mais je n'ai pas besoin de trésorier en ce moment.";
			link.l2.go = "Fickler_NeNujen";
		break;

		case "Fickler_13":
			dialog.text = "Merci, capitaine ! Vous ne le r-r-regretterez pas !");
			link.l1 = "Bienvenue à bord, Andreas.";
			link.l1.go = "Fickler_Nanyat";
			sld = CharacterFromID("Andreas_Fickler");
			sld.Dialog.Filename = "Enc_Officer_dialog.c";
			AddDialogExitQuestFunction("LandEnc_OfficerHired");
			Pchar.questTemp.HiringOfficerIDX = GetCharacterIndex(sld.id);
			ChangeCharacterReputation(sld, 80);
			sld.rank = 10;
			SetSPECIAL(sld, 4, 6, 4, 10, 10, 7, 6);
			SetSelfSkill(sld, 5, 5, 5, 5, 5);
			SetShipSkill(sld, 30, 60, 5, 5, 5, 5, 5, 5, 30);
			sld.loyality = MAX_LOYALITY;
			SetCharacterPerk(sld, "BasicCommerce");
			SetCharacterPerk(sld, "AdvancedCommerce");
			sld.greeting = "GR_Andreas_Fickler";
			LAi_SetImmortal(sld, false);
			sld.HalfImmortal = true;
		break;

		case "Fickler_NeNujen":
			AddQuestRecord("PDM_Neputyovy_kaznachey", "6");
			AddQuestUserData("PDM_Neputyovy_kaznachey", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Neputyovy_kaznachey");
			pchar.questdata.NeputyovyKaznachey = 1;
			sld = CharacterFromID("Andreas_Fickler");
			sld.lifeday = 0;
			LAi_CharacterDisableDialog(sld);
			DialogExit();
		break;

		case "Fickler_Nanyat":
			sld = CharacterFromID("Andreas_Fickler");
			SetCharacterRemovable(sld, true);
			sld.Payment = true;
			sld.quest.OfficerPrice = sti(pchar.rank)*50;
			sld.OfficerWantToGo.DontGo = true;
			LAi_SetActorType(sld);
			LAi_ActorRunToLocation(sld, "reload", "reload1", "", "", "", "", -1);
			NextDiag.CurrentNode = NextDiag.TempNode;
			AddQuestRecord("PDM_Neputyovy_kaznachey", "5");
			AddQuestUserData("PDM_Neputyovy_kaznachey", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PDM_Neputyovy_kaznachey");
			pchar.questdata.NeputyovyKaznachey = 1;
			DialogExit();
		break;

	}
}
