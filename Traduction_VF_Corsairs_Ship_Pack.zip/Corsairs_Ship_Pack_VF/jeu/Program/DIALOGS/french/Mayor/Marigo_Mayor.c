// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Que vouliez-vous ? Demandez.", "Je vous écoute, quelle est la question ?"), "Pour la deuxième fois aujourd'hui, vous essayez de me poser une question...", "Pour la troisième fois aujourd'hui, vous essayez encore de me poser une question...",
                          "Mais quand est-ce que ça finira ?! J'ai tant à faire pour administrer les affaires de la ville, et vous, vous essayez de me poser toutes sortes de questions !", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Pas maintenant, ce n'est ni le lieu ni le moment..."), "Oui, c'est vrai... Mais pas maintenant, plus tard...",
                      "Je vous demanderai, je vous demanderai... Seulement plus tard...", "Désolé, " + GetAddress_FormToNPC(NPChar) + "...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_Gde_Deti"))	//Sinistra квест "Strange things are happening in the archipelago"
			{
				link.l1 = "Je viens à la demande des femmes qui sont assises dans le pavillon de votre résidence.";
				Link.l1.go = "PKM_Animists_1";
			}
			if (CheckAttribute(pchar, "questTemp.PKM_SvtvA_Gubernator_Final"))	//Sinistra квест "Strange things are happening in the archipelago"
			{
				link.l1 = "Votre mission est accomplie, et les enfants sont rendus à leurs parents, fous de joie.";
				Link.l1.go = "PKM_SvtvA_Final";
			}
		break;

		case "Cupture_after":
            dialog.text = RandPhraseSimple("Vous avez déjà tout pris. Que vous faut-il de plus ?", "Reste-t-il vraiment quelque chose que vous n'ayez pas emporté ?");
            link.l1 = RandPhraseSimple("Je jette un dernier coup d'œil...", "Je vérifie, au cas oם j'aurais oublié de prendre quelque chose...");
            link.l1.go = "exit";
            NextDiag.TempNode = "Cupture_after";
		break;
		//==> Sinistra квест "Strange things are happening in the archipelago"
		case "PKM_Animists_1":
			dialog.text = "Ah, vous vouliez parler de ça...";
			link.l1 = "Pardonnez-moi de vous le rappeler, mais votre devoir est d'assurer la sécurité des habitants de la colonie.";
			link.l1.go = "PKM_Animists_2";
        break;
		
		case "PKM_Animists_2":
			dialog.text = "Vous ne tenez pas votre langue, capitaine. Si vous ne voulez pas perdre ma faveur, abstenez-vous à l'avenir de telles déclarations. Quant à ces femmes... Votre réputation me permet de vous révéler quelques détails.";
			link.l1 = "Je suis tout ouïe.";
			link.l1.go = "PKM_Animists_3";
        break;
		
		case "PKM_Animists_3":
			dialog.text = "Vers trois heures du matin, le capitaine d'un navire marchand qui entrait au port a vu une frégate noire quitter l'île toutes voiles dehors.\nLe matin, on a trouvé deux soldats morts dans le port, dont l'un serrait dans sa main un morceau d'étrange étoffe rouge.\nIl est probable que les enfants enlevés ne soient plus sur l'île. Nous n'avons pas les fonds nécessaires pour équiper une expédition de recherche. De toute évidence, il ne sera pas facile de les retrouver, capitaine.\nCependant, si vous voulez prendre part au sort de ces femmes, je suis prêt à vous donner les pouvoirs nécessaires. Je vous promets une récompense en cas de succès.";
			link.l1 = "Oui, mynheer. Je veux retrouver les enfants et les rendre à leurs mères éplorées. Le capitaine qui a vu la frégate a-t-il déjà quitté l'île ?";
			link.l1.go = "PKM_Animists_4";
			link.l2 = "Non, mynheer. Je ne travaille pas sans avance. Au revoir.";
			link.l2.go = "PKM_Animists_NET";
        break;
		
		case "PKM_Animists_NET":
			DialogExit();
			AddQuestRecord("PKM_Animists", "2");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			CloseQuestHeader("PKM_Animists");
			pchar.questdata.Satanisty = 1;
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Gde_Deti");
			
			sld = CharacterFromID("PKM_SvtvA_Devushka_1")
			sld.lifeday = 0;
			sld = CharacterFromID("PKM_SvtvA_Devushka_2")
			sld.lifeday = 0;
			sld = CharacterFromID("PKM_SvtvA_Devushka_3")
			sld.lifeday = 0;
        break;
		
		case "PKM_Animists_4":
			dialog.text = "Vous acceptez cette affaire ?! Excellent ! Je suppose que vous trouverez le capitaine à la taverne. Son navire est encore au port.";
			link.l1 = "Je n'ose pas vous prendre plus de temps, mynheer.";
			link.l1.go = "PKM_Animists_5";
        break;
		
		case "PKM_Animists_5":
			DialogExit();
			AddQuestRecord("PKM_Animists", "3");
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Gde_Deti");
			
			sld = GetCharacter(NPC_GenerateCharacter("PKM_SvpvA_Capitan_1", "officer_32", "man", "man", 10, HOLLAND, -1, true));
			sld.name = "Gered";
			sld.lastname = "Drabbe";
			FreeSitLocator("Marigo_tavern", "sit3");
			sld.Dialog.Filename = "Quest\PKM\Strannie_veshi_tvorytsya_v_arhipelage.c";
			sld.dialog.currentnode = "Capitan_v_taverne_1";
			LAi_SetSitType(sld);
			if(InterfaceStates.EnabledQuestsMarks)
			{
				sld.quest.questflag.model = "questionmarkY";
				sld.quest.questflag.technique = GetTechNameForSign();
			}
			LAi_group_MoveCharacter(sld, "HOLLAND_CITIZENS");
			ChangeCharacterAddressGroup(sld, "Marigo_tavern", "sit", "sit3");			
        break;
		
		case "PKM_SvtvA_Final":
			dialog.text = "Une heureuse conclusion à cette fâcheuse histoire. Je suis heureux de vous récompenser, capitaine. Je sais qu'on peut compter sur vous dans les affaires délicates.";
			link.l1 = "Merci, mynheer.";
			link.l1.go = "exit";
			DeleteAttribute(pchar, "questTemp.PKM_SvtvA_Gubernator_Final");
			AddMoneyToCharacter(pchar, 30000);
            AddCharacterExpToSkill(pchar, "Leadership", 200);
			AddQuestRecord("PKM_Animists", "38");
			AddQuestUserData("PKM_Animists", "sSex", GetSexPhrase("", "e"));
			pchar.questTemp.PKM_Animists_GuberMarigo = true;
			if (CheckAttribute(pchar, "questTemp.PKM_Animists_MamaDeti") && CheckAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo") && CheckAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon") && CheckAttribute(pchar, "questTemp.PKM_Animists_PadreDominges"))
			{
				CloseQuestHeader("PKM_Animists");
				pchar.questdata.Satanisty = 1;
				UnlockAchievement("AchStrannyeDela", 3);
				DeleteAttribute(pchar, "questTemp.PKM_Animists_MamaDeti");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_GuberMarigo");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_OtetsKlermon");
				DeleteAttribute(pchar, "questTemp.PKM_Animists_PadreDominges");
			}
        break;
		
        //==> Одиннадцатый квест исп.линейки: разорение Виллемстада и Мариго.
        case "SpaLine11Quest_DestrHol":
			dialog.text = "Pourquoi l'Espagne a-t-elle attaqué les colonies hollandaises ? Nous ne sommes pas en guerre !!";
			link.l1 = "De facto, vous menez une guerre aux cכtés des Français. Vous les aidez avec de l'argent.";
			link.l1.go = "Step_S11_1";
			AfterTownBattle();
        break;
        case "Step_S11_1":
			dialog.text = "Avez-vous des preuves ?";
			link.l1 = "Nous n'en avons pas besoin. Votre puissance commerciale dans les Caraïbes est sapée depuis longtemps ; essayez donc maintenant de prêter de l'argent à Louis, si vous trouvez encore des fonds disponibles...";
			link.l1.go = "Step_S11_2";
        break;
        case "Step_S11_2":
			dialog.text = "Maudite Espagne...";
			link.l1 = "Faites attention à vos paroles, sinon je vous tranche la gorge ! Mynheer le Hollandais...";
			link.l1.go = "exit";
            AddQuestRecord("Spa_Line_11_DestrHolland", "3");
            pchar.questTemp.Q11_Marigo = 1;
            NextDiag.TempNode = "Cupture_after";
            Statistic_AddValue(Pchar, NationShortName(sti(NPChar.nation)) + "_TakeTown", 1);
			AddDialogExitQuestFunction("TWN_ExitForPay");
            SetReturn_Gover_Dialog_Exit(NPChar);
            chrDisableReloadToLocation = false;
        break;
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

