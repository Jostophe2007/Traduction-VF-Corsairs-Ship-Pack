// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Des questions, " + GetAddress_Form(NPChar) + " ?", "Tout ce que vous voudrez, " + GetAddress_Form(NPChar) + " ?"), ""+ GetSexPhrase("Hum, vous ne seriez pas en train de m'importuner, " + GetAddress_Form(NPChar) + " ? ", "Encore ces questions étranges ? Ma fille, vous devriez boire un peu de rhum, ou quelque chose comme ça...") +"", "C'est la troisième fois aujourd'hui que vous me parlez d'une question..."+ GetSexPhrase("Ce sont des marques d'attention ?", "") +"",
                          "Vous allez encore me poser la question, " + GetAddress_Form(NPChar) + " ?", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Non, non, vous êtes très belle...",
                      "Pas du tout, ma chère, c'est la sénilité...", "Non, quelles questions...", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
			if(CheckAttribute(pchar, "Whisper.FindDesouzaHolWaitress"))
			{
				DeleteAttribute(pchar, "Whisper.FindDesouzaHolWaitress")
				link.l1 = "Votre patron, "+GetCharacterFullName("Marigo_tavernkeeper")+", m'a dit que des types suspects, avec une marque en forme de crucifix sur le bras, vous avaient abordée. Je les cherche. Pouvez-vous m'en dire plus sur ce qu'ils demandaient ?";
				link.l1.go = "FindDesouzaHolWaitress";
				break;
			}
		break;

		case "FindDesouzaHolWaitress":
			dialog.text = "Il y en avait, oui. D'ailleurs, ils vous cherchaient aussi. En tout cas, vous correspondez à la description qu'ils m'ont donnée.";
			link.l1 = "Pourquoi cherchaient-ils quelqu'un comme moi ?";
			link.l1.go = "FindDesouzaHolWaitress_1";
		break;
		case "FindDesouzaHolWaitress_1":
			dialog.text = "Malheureusement, ils ne l'ont pas dit. Mais ils ne cherchaient pas que vous : ils avaient une liste de plusieurs dizaines de personnes à l'apparence peu commune, pour la plupart des Espagnols. Ils disaient que tous ces gens étaient des criminels recherchés. L'un d'eux, il s'avère, avait été vu récemment en ville, alors ces types marqués sont partis à sa poursuite. C'était il y a à peine deux heures.";
			link.l1 = "Et dans quelle direction sont-ils partis chercher ce type ?";
			link.l1.go = "FindDesouzaHolWaitress_2";
		break;
		case "FindDesouzaHolWaitress_2":
			dialog.text = "Capitaine, toute cette histoire me met un peu mal à l'aise. Dites-moi, pourquoi vous cherchent-ils ?";
			link.l1 = "J'ai de vieux comptes à régler avec eux. Leur chef est un sadique et un fou. Il torture les gens pour le plaisir. Ces gens sont dangereux, il faut les arrêter.";
			link.l1.go = "FindDesouzaHolWaitress_3";
		break;
		case "FindDesouzaHolWaitress_3":
			dialog.text = "Je n'y comprends toujours rien, mais allez savoir pourquoi, j'ai envie de vous croire. Eligio non plus ne ressemblait pas au dangereux criminel que ces gens m'ont décrit.";
			link.l1 = "Eligio ? C'est lui que les inquisiteurs recherchent ?";
			link.l1.go = "FindDesouzaHolWaitress_4";
		break;
		case "FindDesouzaHolWaitress_4":
			dialog.text = "C'étaient donc des inquisiteurs ? Pourquoi ne l'avez-vous pas dit tout de suite, capitaine ? Il faut chasser cette racaille catholique de notre colonie protestante à coups de balai ! Des inquisiteurs ! Pauvre Eligio...";
			link.l1 = "Dites-moi oם ils sont allés. Je pourrai peut-être encore le sauver.";
			link.l1.go = "FindDesouzaHolWaitress_5";
		break;
		case "FindDesouzaHolWaitress_5":
			dialog.text = "L'un des clients a dit qu'Eligio était allé à la grotte pour vérifier des rumeurs sur un trésor.";
			link.l1 = "Merci pour l'information, j'y cours.";
			link.l1.go = "exit";
			PChar.quest.WhisperHuntersCaveEntrance.win_condition.l1 = "location";
			PChar.quest.WhisperHuntersCaveEntrance.win_condition.l1.location = "Marigo_CaveEntrance";
			PChar.quest.WhisperHuntersCaveEntrance.function = "WhisperHuntersCaveEntrance";
			AddQuestRecord("WhisperQuestline", "5");
		break;

	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

