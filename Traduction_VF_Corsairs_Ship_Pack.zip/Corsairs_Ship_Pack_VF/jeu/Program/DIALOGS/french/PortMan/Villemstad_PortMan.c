// диалог по городам
void ProcessCommonDialogEvent(ref NPChar, aref Link, aref NextDiag)
{
    switch (Dialog.CurrentNode)
	{
		case "quests":
			// Gregg: The Black Orchid, chapter 7 - the frigate taken off the moorings
			if (CheckAttribute(PChar, "SmallMongrel"))
			{
				if (PChar.SmallMongrel == "6")
				{
					link.l30 = "J'ai entendu dire qu'on avait volé une frégate à vos amarres. C'est vrai ?";
					link.l30.go = "BO_SM_PM_1";
				}
			}
			dialog.text = NPCStringReactionRepeat(RandPhraseSimple("Quelles questions ?", "Que voulez-vous, " + GetAddress_Form(NPChar) + " ?"), "Vous avez essayé de me poser une question il y a peu, " + GetAddress_Form(NPChar) + "...", "C'est la troisième fois aujourd'hui que vous me parlez d'une question...",
                          "וcoutez, si vous ne venez pas pour les affaires du port, ne m'embêtez pas avec vos questions.", "block", 1, npchar, Dialog.CurrentNode);
			link.l1 = HeroStringReactionRepeat(RandPhraseSimple("J'ai changé d'avis...", "Je n'ai rien à dire pour le moment."), "Hum, il est arrivé quelque chose à ma mémoire...",
                      "Oui, c'est vraiment la troisième fois...", "Désolé, mais les affaires du port ne m'intéressent pas pour l'instant.", npchar, Dialog.CurrentNode);
			link.l1.go = "exit";
            // ==> квест №5 голл.линейки, забрать три флейта.
            if (pchar.questTemp.State == "ThreeFleutes_toPortMan")
            {
    			link.l1 = "Je viens de la part de Stuyvesant. Je dois prendre le commandement de trois flמtes.";
    			link.l1.go = "Step_H5_1";
            }
			//работорговец
			if (pchar.questTemp.Slavetrader == "EscapeSlaveVillemstad_P")
            {
    			link.l1 = "J'aimerais en savoir plus sur la barque qui a disparu la nuit suivant la révolte des esclaves.";
    			link.l1.go = "EscapeSlave_Villemstad_P1";
            }
			//ОЗГ, Крыса
			if(CheckAttribute(pchar, "questTemp.Headhunter"))
			{
    			if (pchar.questTemp.Headhunter == "Rat" && pchar.questTemp.Headhunter.countV == 0)
    			{
    				link.l1 = "J'ai entendu dire que récemment, un navire marchand a disparu après avoir quitté votre port. Pouvez-vous m'en dire davantage ?";
	    			link.l1.go = "Rat_portmanV";
	    		}
			}
		break;

//************************************* Диалоги по голл.линейке *******************************
		case "Step_H5_1":
    		if (GetCompanionQuantity(pchar) == 1)
            {
                dialog.text = "Je vous en prie. Trois flמtes sont à votre disposition.";
    			link.l1 = "Parfait.";
    			link.l1.go = "exit";
				AddDialogExitQuestFunction("HL5_portManGiveFleuts");
            }
            else
            {
                dialog.text = "Oui, je suis au courant. Cependant, pour prendre le commandement des flמtes, vous devez vous séparer de votre escadre. Je vous prie de le faire, puis de revenir me voir.";
    			link.l1 = "D'accord, c'est ce que je vais faire.";
    			link.l1.go = "exit";
            }
		break;
		//работорговец
		case "EscapeSlave_Villemstad_P1":
				dialog.text = "Hum... Et pourquoi diable cela vous intéresse-t-il tout à coup ?";
				link.l1 = "J'agis sur instructions de Peter Stuyvesant, le gouverneur général. Il y a des raisons de croire que des esclaves en fuite sont mêlés à la disparition du navire. Je vous demande donc de m'apporter toute l'aide possible dans les recherches.";
				link.l1.go = "EscapeSlave_Villemstad_P2";
		break;

		case "EscapeSlave_Villemstad_P2":
				dialog.text = "Compris. Mais malheureusement, je ne peux pas faire grand-chose pour vous aider. Une barque nommée " + pchar.questTemp.Slavetrader.ShipName + " a disparu pendant la nuit, personne n'a rien vu ni entendu. Le veilleur a disparu sans laisser de traces\nLes recherches n'ont rien donné, d'ailleurs, puisqu'il n'y avait aucune trace. La ville était en émoi : tout le monde s'attendait à une attaque des esclaves et se préparait à se défendre...";
				link.l1 = "Oui, il n'y a vraiment pas beaucoup d'informations. Mais merci quand même. Au revoir.";
				link.l1.go = "exit";
				AddQuestRecord("Slavetrader", "22_3");
				AddQuestUserData("Slavetrader", "sShipName", pchar.questTemp.Slavetrader.ShipName);
				pchar.questTemp.Slavetrader = "EscapeSlaveVillemstad_H";
		break;

		//ОЗГ, Крыса
		case "Rat_portmanV":
			dialog.text = "Oui, il y a deux semaines environ, le galion lourd Santa Anna a quitté le port et, à ce qu'on dit, n'est pas arrivé à destination. Personne ne l'a revu depuis, mais pourquoi cela vous intéresse-t-il ?";
			link.l1 = "Disons que c'est un intérêt personnel. Vous vous souvenez de détails ?";
			link.l1.go = "Rat_portmanV_1";
		break;

		case "Rat_portmanV_1":
			dialog.text = "De quoi pourrais-je me souvenir, attendez... Oui, voici l'inscription : le galion lourd Santa Anna a appareillé avec une cargaison d'ébène à bord, plus de six cents unités. Voilà... Il ne s'est pas présenté au port de destination. Il semble que ce soit tout.";
			link.l1 = "Dites-moi, quels navires ont quitté le port le même jour que ce galion, ou le lendemain ?";
			link.l1.go = "Rat_portmanV_2";
		break;

		case "Rat_portmanV_2":
			dialog.text = "Voyons voir. Ce jour-là, ont quitté le port : la pinasse Adelaide, le galion Medemblink et la frégate Zultchen.";
			link.l1 = "Merci !";
			link.l1.go = "CheckV";
			pchar.questTemp.Headhunter.count = sti(pchar.questTemp.Headhunter.count) + 1;
			pchar.questTemp.Headhunter.countV = 1;
		break;

		case "CheckV":
			if(pchar.questTemp.Headhunter.count == 3)
			{
				pchar.questTemp.Headhunter = "Rat_Tavern";
				pchar.questTemp.Headhunter.Ratrumcity = npchar.city;
				AddQuestRecord("Headhunt", "13");
			}
			else
			{
				AddQuestRecord("Headhunt", "12_3");
			}
			DialogExit();
		break;




		// Gregg: The Black Orchid, chapter 7 -->
		case "BO_SM_PM_1":
			dialog.text = "C'est exact. Et je ne vois toujours pas comment. La nuit était claire, la garde était à son poste, la chaîne était intacte.";
			link.l1 = "J'ai l'intention de la retrouver. Avez-vous une idée de qui a pu faire ça ?";
			link.l1.go = "BO_SM_PM_2";
		break;

		case "BO_SM_PM_2":
			dialog.text = "Capitaine, je respecte votre zèle, mais elle n'a pas besoin d'être retrouvée. Elle nous a assez apporté comme ça.";
			link.l1 = "Assez de quoi ? Jusqu'ici, je n'ai entendu parler que du vol.";
			link.l1.go = "BO_SM_PM_3";
		break;

		case "BO_SM_PM_3":
			dialog.text = "Deux hommes écrasés par une vergue tombée pendant qu'ils nettoyaient son pont. Une chaloupe avec l'équipe d'inspection qui chavire par mer d'huile, et quatre hommes coulés avec tout leur barda. Voilà ce qui est consigné.";
			link.l1 = "Et qu'est-ce qui n'est pas consigné ?";
			link.l1.go = "BO_SM_PM_4";
		break;

		case "BO_SM_PM_4":
			dialog.text = "...(après un silence)... Le gouverneur a demandé qu'on n'en parle pas. Retrouvez-la, capitaine, s'il le faut. Le lendemain de sa disparition, des marchands ont vu une frégate pirate faire route vers la Martinique.";
			link.l1 = "La Martinique, donc. Merci pour votre franchise, le gouverneur n'en saura rien par moi.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("SmallMongrelToLeFransua");
		break;
		// Gregg: <--
	}
	UnloadSegment(NPChar.FileDialog2);  // если где-то выход внутри switch  по return не забыть сделать анлод
}

