// Gregg: Bill Matthew and Ben Gregori - quest "The Vanishing" (ported from Damned Destiny).
// Logic - Program\Quests\reaction_functions\disappearpeople.c
// Nodes 1-6 - the rescued navigator's tale, 7-9 - the talk with Gregori in the Barbados cave.

void ProcessDialogEvent()
{
	ref NPChar;
	aref Link, NextDiag;

	DeleteAttribute(&Dialog, "Links");

	makeref(NPChar, CharacterRef);
	makearef(Link, Dialog.Links);
	makearef(NextDiag, NPChar.Dialog);

	switch (Dialog.CurrentNode)
	{
		case "First time":
			NextDiag.TempNode = "First time";
			dialog.text = "Que voulez-vous ?";
			link.l1 = "Pas mal.";
			link.l1.go = "exit";
		break;

		case "1":
			dialog.text = "Merci de m'avoir aidé, capitaine : sans vous, ils m'auraient tué et pris la pièce.";
			link.l1 = "De quelle pièce parlez-vous ?";
			link.l1.go = "2";
		break;

		case "2":
			dialog.text = "Je ferais peut-être mieux de vous raconter mon histoire. J'étais autrefois navigateur à bord du brick pirate « Lucky Joker ». Un jour, nous avons décidé de cacher notre butin dans la grotte de la Barbade, et tout à fait par hasard, nous sommes tombés sur un ancien trésor inca. En plus des bijoux, nous avons trouvé un coffret contenant une fiole d'un liquide quelconque et trois vieilles pièces d'or. Aucun de nous n'avait jamais rien vu de pareil. Nous avons partagé le butin : l'une de ces pièces m'est revenue, et le capitaine a pris le coffret pour lui.";
			link.l1 = "Hum, et que s'est-il passé ensuite ?";
			link.l1.go = "3";
		break;

		case "3":
			dialog.text = "Quelque temps plus tard, le capitaine Gregori a réussi à trouver un homme capable de lire l'inscription sur le couvercle de ce coffret. Il s'est avéré que celui qui détenait son contenu pouvait atteindre les esprits indiens maléfiques en récitant l'incantation du couvercle et en mêlant son propre sang au liquide de la fiole. C'est exactement ce qu'a fait notre capitaine, et il s'est changé en momie, en squelette vivant : un esprit maléfique est entré en lui ! De plus, Gregori a acquis un pouvoir inexplicable sur son équipage, et il a changé certains des hommes en squelettes du même genre avec ce liquide maléfique." + NewStr() + "וtrangement, ses sortilèges n'avaient aucune prise sur moi : maintenant, je comprends que c'est cette vieille pièce qui m'a sauvé. Avec le temps, j'ai réussi à m'enfuir et j'ai changé de métier : sur la recommandation de mon beau-père, on m'a pris comme navigateur à bord d'un navire marchand. Voici le problème : plus Gregori et son équipage tuent de gens, plus il devient fort.";
			link.l1 = "Et ?..";
			link.l1.go = "4";
		break;

		case "4":
			dialog.text = "Mais pour une raison quelconque, il doit réunir les trois pièces. L'une est revenue à Gregori lors du partage du trésor, une autre était détenue par notre maître d'équipage, qui a été tué il n'y a pas longtemps à Basse-Terre : il s'était enfui avec moi à l'époque, et nous nous retrouvions de temps en temps. La deuxième pièce est donc sמrement déjà à lui. Et si vous n'étiez pas arrivé à temps, la troisième aurait été entre ses mains, elle aussi.";
			link.l1 = "Vous me racontez des choses vraiment curieuses !";
			link.l1.go = "5";
		break;

		case "5":
			dialog.text = "Je ne dis que la vérité. Et pour être tout à fait franc, cette pièce me brמle les doigts : ils finiront par m'atteindre de toute façon !";
			link.l1 = "Pourquoi en êtes-vous si sמr ?";
			link.l1.go = "6";
		break;

		case "6":
			dialog.text = "Comment pourrait-il en être autrement ! Le capitaine Gregori a besoin des trois pièces d'or des Incas ! Je vais vous dire une chose, capitaine : vous pourriez peut-être gagner cette guerre contre les esprits. Moi, on me tuera sמrement, et alors tout le monde apprendra ce qu'est le vrai mal.";
			link.l1 = "Très bien, donnez-moi cette pièce, et je vais essayer d'aller au fond de cette affaire.";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleTakeCoin");
		break;

		case "7":
			dialog.text = "Aha, ma pièce est venue à moi sur ses deux jambes !";
			link.l1 = "Il ne reste plus rien d'humain en toi, capitaine Gregori ! Ce que ces esprits indiens maléfiques ont fait de toi ! Tu ressembles à un singe mort, que je sois foudroyé !";
			link.l1.go = "8";
		break;

		case "8":
			dialog.text = "Qu'est-ce que tu comprends, misérable petit homme ! La force et le pouvoir, voilà ce qui compte, le reste ne vaut pas plus pour moi qu'une morue rongée jusqu'à l'arête. Et maintenant, je vais te prendre la chose qui m'a tant manqué.";
			link.l1 = "Tu la prendras, si tu arrives à tenir une épée correctement avec ces os pourris !";
			link.l1.go = "9";
		break;

		case "9":
			dialog.text = "Blanc-bec insensé ! Je vais te montrer ce que j'ai accompli pendant ce temps ! Prépare-toi à mourir !";
			link.l1 = "Aha !";
			link.l1.go = "exit";
			AddDialogExitQuestFunction("DisappearPeopleFinalFight");
		break;

		case "Exit":
			NextDiag.CurrentNode = NextDiag.TempNode;
			DialogExit();
		break;
	}
}
